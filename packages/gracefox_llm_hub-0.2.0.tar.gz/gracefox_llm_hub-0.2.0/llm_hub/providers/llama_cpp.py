"""llama.cpp提供商 - 包含Token计数器"""

import subprocess
import os
import re
import logging
from typing import Dict, Any, List, Generator, Union

from llm_hub.providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse

logger = logging.getLogger(__name__)


class LlamaCppTokenCounter(BaseTokenCounter):
    """llama.cpp 精确Token计数器"""
    
    def __init__(self, executable: str = "./llama.exe", model_path: str = ""):
        self.executable = executable
        self.model_path = model_path
        self._available = None
    
    def _check_available(self) -> bool:
        if self._available is not None:
            return self._available
        
        if not os.path.exists(self.executable) or not os.path.exists(self.model_path):
            self._available = False
            return False
        
        self._available = True
        return True
    
    def count(self, text: str) -> int:
        if not self._check_available():
            return self._fallback_count(text)
        
        try:
            result = subprocess.run(
                [self.executable, "-m", self.model_path, "--tokenize", "--prompt", text],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                match = re.search(r'tokenized to (\d+) tokens', result.stdout)
                if match:
                    return int(match.group(1))
            
            return self._fallback_count(text)
        except Exception as e:
            logger.warning(f"llama.cpp token计数失败: {e}")
            return self._fallback_count(text)
    
    def _fallback_count(self, text: str) -> int:
        chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english_words = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return chinese_chars + int(english_words * 0.75) + 2


class LlamaCppProvider(BaseProvider):
    """llama.cpp提供商"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.executable = config.get("llama_exe_path", config.get("executable", "./llama.exe"))
        self.model_path = config.get("model_path", "")
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            self._token_counter = LlamaCppTokenCounter(self.executable, self.model_path)
        return self._token_counter
    
    def is_available(self) -> bool:
        return os.path.exists(self.executable) and os.path.exists(self.model_path)
    
    def _build_command(self, prompt: str, **kwargs) -> List[str]:
        return [
            self.executable,
            "-m", self.model_path,
            "-p", prompt,
            "-n", str(kwargs.get("max_tokens", 512)),
            "--temp", str(kwargs.get("temperature", 0.7)),
            "--top-k", str(kwargs.get("top_k", 40)),
            "--top-p", str(kwargs.get("top_p", 0.95)),
            "--repeat_penalty", str(kwargs.get("repeat_penalty", 1.1))
        ]
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        if not self.is_available():
            raise RuntimeError("llama.cpp not available")
        
        messages = conversation.get_messages()
        prompt = "\n".join([f"{m['role']}: {m['content']}" for m in messages])
        prompt += "\nassistant: "
        
        return self.complete(prompt, **kwargs)
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        if not self.is_available():
            raise RuntimeError("llama.cpp not available")
        
        cmd = self._build_command(prompt, **kwargs)
        stream = kwargs.get("stream", False)
        
        try:
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1
            )
            
            if stream:
                def generate():
                    for line in process.stdout:
                        if line.strip():
                            yield line.strip()
                    process.wait()
                return StreamResponse(generate())
            else:
                output, error = process.communicate(timeout=kwargs.get("timeout", 60))
                if error:
                    raise RuntimeError(f"llama.cpp error: {error}")
                return Response(content=output.strip(), model=self.model_path)
                
        except Exception as e:
            raise RuntimeError(f"llama.cpp error: {e}")
    
    def health_check(self) -> bool:
        return self.is_available()