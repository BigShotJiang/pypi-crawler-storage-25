"""提供商基类 - 包含Token计数器基类"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Generator, Union, Optional
from functools import lru_cache

from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse
from llm_hub.core.exceptions import TokenLimitError


class BaseTokenCounter(ABC):
    """Token计数器基类 - 每个provider实现自己的精确计数器"""
    
    @abstractmethod
    def count(self, text: str) -> int:
        """计算单个文本的token数"""
        pass
    
    def count_messages(self, messages: List[Dict[str, str]]) -> int:
        """计算消息列表的token数（包含格式开销）"""
        total = 0
        for msg in messages:
            total += self.count(msg.get("content", ""))
            total += 4  # 每条消息的格式开销
        total += 2  # 回复的格式开销
        return total
    
    def count_conversation(self, conversation) -> int:
        """计算对话对象的token数"""
        if hasattr(conversation, 'get_messages'):
            messages = conversation.get_messages()
        elif hasattr(conversation, 'messages'):
            if hasattr(conversation.messages, '__iter__'):
                messages = [{"role": m.role, "content": m.content} for m in conversation.messages]
            else:
                messages = []
        else:
            messages = []
        return self.count_messages(messages)
    
    def truncate(self, text: str, max_tokens: int, suffix: str = "...") -> str:
        """按token数截断文本"""
        if self.count(text) <= max_tokens:
            return text
        
        # 二分查找截断点
        left, right = 0, len(text)
        while left < right:
            mid = (left + right + 1) // 2
            if self.count(text[:mid]) <= max_tokens - self.count(suffix):
                left = mid
            else:
                right = mid - 1
        
        return text[:left] + suffix
    
    def validate_token_limit(self, text: str, max_tokens: int) -> None:
        """验证token限制"""
        if self.count(text) > max_tokens:
            raise TokenLimitError(
                f"Text exceeds token limit: {self.count(text)} > {max_tokens}"
            )


class FallbackTokenCounter(BaseTokenCounter):
    """备用Token计数器 - 简单估算（当精确计数器不可用时）"""
    
    def count(self, text: str) -> int:
        chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english_words = len([w for w in text.split() if any(c.isalpha() for c in w)])
        other_chars = len(text) - chinese_chars - sum(len(w) for w in text.split())
        return max(1, chinese_chars + int(english_words * 0.75) + int(other_chars * 0.5))


class BaseProvider(ABC):
    """LLM提供商基类"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.debug = config.get("debug", False)
        self._token_counter: Optional[BaseTokenCounter] = None
    
    @abstractmethod
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        """对话"""
        pass
    
    @abstractmethod
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        """文本补全"""
        pass
    
    @abstractmethod
    def health_check(self) -> bool:
        """健康检查"""
        pass
    
    @abstractmethod
    def get_token_counter(self) -> BaseTokenCounter:
        """获取该provider的Token计数器（每个provider实现自己的精确计数）"""
        pass
    
    def _log(self, message: str):
        """调试日志"""
        if self.debug:
            print(f"[{self.__class__.__name__}] {message}")