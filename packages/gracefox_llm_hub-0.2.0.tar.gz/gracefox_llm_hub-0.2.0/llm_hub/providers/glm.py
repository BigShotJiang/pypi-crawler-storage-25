"""智谱 GLM 提供商 - 包含Token计数器"""

import json
import logging
import requests
from typing import Dict, Any, List, Generator, Union

from llm_hub.providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse, StreamChunk, StreamEventType

logger = logging.getLogger(__name__)


class GLMTokenCounter(BaseTokenCounter):
    """智谱GLM 精确Token计数器"""
    
    def __init__(self, use_local: bool = True):
        self.use_local = use_local
        self._tokenizer = None
    
    def _get_tokenizer(self):
        if self._tokenizer is None and self.use_local:
            try:
                from transformers import AutoTokenizer
                self._tokenizer = AutoTokenizer.from_pretrained(
                    "THUDM/glm-4-9b-chat",
                    trust_remote_code=True
                )
                logger.info("GLM本地tokenizer加载成功")
            except Exception as e:
                logger.warning(f"GLM本地tokenizer加载失败: {e}")
                self.use_local = False
        return self._tokenizer
    
    def count(self, text: str) -> int:
        tokenizer = self._get_tokenizer()
        if tokenizer:
            try:
                return len(tokenizer.encode(text))
            except Exception as e:
                logger.warning(f"GLM token计数失败: {e}")
        
        chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english_words = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return chinese_chars + int(english_words * 0.75) + 2


class GLMProvider(BaseProvider):
    """智谱 GLM 提供商"""
    
    def __init__(self, config: dict):
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.model = config.get("model", "glm-4-flash")
        self.api_url = config.get("api_url", "https://open.bigmodel.cn/api/paas/v4")
        self.show_thinking = config.get("show_thinking", True)
        self.use_local_tokenizer = config.get("use_local_tokenizer", True)
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            self._token_counter = GLMTokenCounter(self.use_local_tokenizer)
        return self._token_counter
    
    def _get_headers(self) -> Dict:
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        messages = conversation.get_messages()
        stream = kwargs.get("stream", self.config.get("stream", False))
        
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
            "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95)),
            "stream": stream
        }
        
        self._log(f"GLM Request: {payload}")
        
        response = requests.post(
            f"{self.api_url}/chat/completions",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            return StreamResponse(self._stream_chat(response))
        else:
            data = response.json()
            response.close()
            return self._parse_response(data)
    
    def _stream_chat(self, response) -> Generator:
        accumulated_content = ""
        
        for line in response.iter_lines():
            if not line:
                continue
            
            try:
                line = line.decode('utf-8')
            except UnicodeDecodeError:
                continue
            
            if line.startswith("data: "):
                line = line[6:]
            
            if line == "[DONE]":
                yield StreamChunk(
                    type=StreamEventType.DONE,
                    content="",
                    accumulated=accumulated_content
                )
                break
            
            try:
                data = json.loads(line)
                choices = data.get("choices", [])
                if choices:
                    delta = choices[0].get("delta", {})
                    content = delta.get("content", "")
                    if content:
                        accumulated_content += content
                        yield StreamChunk(
                            type=StreamEventType.CONTENT,
                            content=content,
                            delta=content,
                            accumulated=accumulated_content
                        )
            except json.JSONDecodeError:
                continue
        
        response.close()
    
    def _parse_response(self, data: Dict) -> Response:
        choices = data.get("choices", [])
        content = choices[0].get("message", {}).get("content", "") if choices else ""
        
        return Response(
            content=content,
            model=data.get("model", self.model),
            usage=data.get("usage"),
            finish_reason=choices[0].get("finish_reason") if choices else None,
            raw=data
        )
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        try:
            response = requests.get(
                f"{self.api_url}/models",
                headers=self._get_headers(),
                timeout=10
            )
            success = response.status_code == 200
            response.close()
            return success
        except Exception:
            return False