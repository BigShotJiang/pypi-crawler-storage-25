"""百度文心 (ERNIE) 提供商 - 包含Token计数器"""

import json
import logging
import requests
import time
from typing import Dict, Any, List, Union

from llm_hub.providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response

logger = logging.getLogger(__name__)


class ErnieTokenCounter(BaseTokenCounter):
    """百度文心 精确Token计数器"""
    
    def __init__(self, tokenizer_path: str = None):
        self.tokenizer_path = tokenizer_path
        self._tokenizer = None
    
    def _get_tokenizer(self):
        if self._tokenizer is None and self.tokenizer_path:
            try:
                from transformers import AutoTokenizer
                self._tokenizer = AutoTokenizer.from_pretrained(
                    self.tokenizer_path,
                    trust_remote_code=True
                )
                logger.info(f"文心tokenizer加载成功: {self.tokenizer_path}")
            except Exception as e:
                logger.warning(f"文心tokenizer加载失败: {e}")
                self.tokenizer_path = None
        return self._tokenizer
    
    def count(self, text: str) -> int:
        tokenizer = self._get_tokenizer()
        if tokenizer:
            try:
                return len(tokenizer.encode(text))
            except Exception as e:
                logger.warning(f"文心token计数失败: {e}")
        
        chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english_words = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return chinese_chars + int(english_words * 0.75) + 2


class ErnieProvider(BaseProvider):
    """百度文心提供商"""
    
    def __init__(self, config: dict):
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.secret_key = config.get("secret_key")
        self.model = config.get("model", "ernie-3.5-8k")
        self.api_url = config.get("api_url", "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop")
        self.tokenizer_path = config.get("tokenizer_path")
        
        self._access_token = None
        self._token_expire = 0
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            self._token_counter = ErnieTokenCounter(self.tokenizer_path)
        return self._token_counter
    
    def _get_access_token(self) -> str:
        if self._access_token and time.time() < self._token_expire:
            return self._access_token
        
        url = "https://aip.baidubce.com/oauth/2.0/token"
        params = {
            "grant_type": "client_credentials",
            "client_id": self.api_key,
            "client_secret": self.secret_key
        }
        
        response = requests.post(url, params=params, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        self._access_token = data.get("access_token")
        expires_in = data.get("expires_in", 2592000)
        self._token_expire = time.time() + expires_in - 3600
        
        return self._access_token
    
    def _get_headers(self) -> Dict:
        return {"Content-Type": "application/json"}
    
    def _get_api_url(self) -> str:
        token = self._get_access_token()
        return f"{self.api_url}/chat/{self.model}?access_token={token}"
    
    def chat(self, conversation: Conversation, **kwargs) -> Response:
        messages = conversation.get_messages()
        
        system_prompt = None
        user_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system_prompt = msg["content"]
            else:
                user_messages.append(msg)
        
        payload = {
            "messages": user_messages,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95)),
            "penalty_score": kwargs.get("penalty_score", 1.0)
        }
        
        if system_prompt:
            payload["system"] = system_prompt
        
        response = requests.post(
            self._get_api_url(),
            json=payload,
            headers=self._get_headers(),
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        data = response.json()
        response.close()
        
        return self._parse_response(data)
    
    def _parse_response(self, data: Dict) -> Response:
        result = data.get("result", "")
        
        usage = {
            "prompt_tokens": data.get("usage", {}).get("prompt_tokens", 0),
            "completion_tokens": data.get("usage", {}).get("completion_tokens", 0),
            "total_tokens": data.get("usage", {}).get("total_tokens", 0)
        }
        
        return Response(
            content=result,
            model=self.model,
            usage=usage,
            finish_reason=data.get("finish_reason"),
            raw=data
        )
    
    def complete(self, prompt: str, **kwargs) -> Response:
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        try:
            self._get_access_token()
            return True
        except Exception:
            return False