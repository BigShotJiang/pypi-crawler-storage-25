"""Ollama提供商 - 包含Token计数器"""

import json
import logging
import requests
from typing import Dict, Any, List, Generator, Union

from llm_hub.providers.base import BaseProvider, BaseTokenCounter, FallbackTokenCounter
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse, StreamChunk, StreamEventType

logger = logging.getLogger(__name__)


class OllamaTokenCounter(BaseTokenCounter):
    """Ollama 精确Token计数器"""
    
    def __init__(self, base_url: str = "http://localhost:11434", model: str = "llama2"):
        self.base_url = base_url.rstrip('/')
        self.model = model
        self._cache = {}
        self._tiktoken_encoding = None
        
        try:
            import tiktoken
            self._tiktoken_encoding = tiktoken.get_encoding("cl100k_base")
            logger.info("Ollama使用tiktoken作为备选")
        except ImportError:
            pass
    
    def count(self, text: str) -> int:
        if text in self._cache:
            return self._cache[text]
        
        try:
            response = requests.post(
                f"{self.base_url}/api/tokenize",
                json={"model": self.model, "text": text},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                tokens = data.get("tokens", [])
                token_count = len(tokens)
                self._cache[text] = token_count
                return token_count
        except Exception as e:
            logger.debug(f"Ollama tokenize API失败: {e}")
        
        return self._fallback_count(text)
    
    def _fallback_count(self, text: str) -> int:
        if self._tiktoken_encoding:
            return len(self._tiktoken_encoding.encode(text))
        
        chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english_words = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return chinese_chars + int(english_words * 0.75) + 2


class OllamaProvider(BaseProvider):
    """Ollama提供商"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get("ollama_url", "http://localhost:11434")
        self.api_url = f"{self.base_url}/api"
        self.model = config.get("model", "llama2")
    
    def get_token_counter(self) -> BaseTokenCounter:
        if self._token_counter is None:
            self._token_counter = OllamaTokenCounter(self.base_url, self.model)
        return self._token_counter
    
    def _get_headers(self) -> Dict:
        return {"Content-Type": "application/json"}
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        messages = conversation.get_messages()
        stream = kwargs.get("stream", self.config.get("stream", False))
        
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "stream": stream,
            "options": {
                "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
                "num_predict": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
                "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95))
            }
        }
        
        response = requests.post(
            f"{self.api_url}/chat",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            return StreamResponse(self._stream_chat(response))
        else:
            data = response.json()
            response.close()
            return Response(
                content=data.get("message", {}).get("content", ""),
                model=self.model,
                raw=data
            )
    
    def _stream_chat(self, response) -> Generator:
        accumulated_content = ""
        
        for line in response.iter_lines():
            if not line:
                continue
            
            try:
                line = line.decode('utf-8')
            except UnicodeDecodeError:
                continue
            
            try:
                data = json.loads(line)
                
                if "message" in data and "content" in data["message"]:
                    content = data["message"]["content"]
                    if content:
                        accumulated_content += content
                        yield StreamChunk(
                            type=StreamEventType.CONTENT,
                            content=content,
                            delta=content,
                            accumulated=accumulated_content
                        )
                
                if data.get("done", False):
                    yield StreamChunk(
                        type=StreamEventType.DONE,
                        content="",
                        accumulated=accumulated_content,
                        metadata={
                            "total_duration": data.get("total_duration"),
                            "load_duration": data.get("load_duration"),
                            "eval_count": data.get("eval_count")
                        }
                    )
                    break
                    
            except json.JSONDecodeError:
                continue
        
        response.close()
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        stream = kwargs.get("stream", self.config.get("stream", False))
        
        payload = {
            "model": kwargs.get("model", self.model),
            "prompt": prompt,
            "stream": stream,
            "options": {
                "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
                "num_predict": kwargs.get("max_tokens", self.config.get("max_tokens", 2000))
            }
        }
        
        response = requests.post(
            f"{self.api_url}/generate",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            return StreamResponse(self._stream_complete(response))
        else:
            data = response.json()
            response.close()
            return Response(
                content=data.get("response", ""),
                model=self.model,
                raw=data
            )
    
    def _stream_complete(self, response) -> Generator:
        accumulated_content = ""
        
        for line in response.iter_lines():
            if not line:
                continue
            
            try:
                line = line.decode('utf-8')
            except UnicodeDecodeError:
                continue
            
            try:
                data = json.loads(line)
                
                if "response" in data:
                    content = data["response"]
                    if content:
                        accumulated_content += content
                        yield StreamChunk(
                            type=StreamEventType.CONTENT,
                            content=content,
                            delta=content,
                            accumulated=accumulated_content
                        )
                
                if data.get("done", False):
                    yield StreamChunk(
                        type=StreamEventType.DONE,
                        content="",
                        accumulated=accumulated_content
                    )
                    break
                    
            except json.JSONDecodeError:
                continue
        
        response.close()
    
    def list_models(self) -> List[str]:
        try:
            response = requests.get(f"{self.api_url}/tags", timeout=10)
            if response.status_code == 200:
                models = response.json().get("models", [])
                return [m["name"] for m in models]
            return []
        except Exception:
            return []
    
    def health_check(self) -> bool:
        try:
            response = requests.get(f"{self.base_url}", timeout=5)
            success = response.status_code == 200
            response.close()
            return success
        except Exception:
            return False