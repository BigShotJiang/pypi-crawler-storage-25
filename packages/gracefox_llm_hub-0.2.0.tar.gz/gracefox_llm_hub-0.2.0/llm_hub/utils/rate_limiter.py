"""速率限制器"""

import time
import threading
from functools import wraps
from typing import Dict, Optional, Callable
from collections import deque


class RateLimiter:
    """速率限制器（线程安全）"""
    
    def __init__(self, calls_per_minute: int = 60, burst_limit: int = 10):
        self.calls_per_minute = calls_per_minute
        self.burst_limit = burst_limit
        self._calls: deque = deque()
        self._burst_count = 0
        self._lock = threading.RLock()
        self._last_reset = time.time()
    
    def acquire(self) -> bool:
        with self._lock:
            now = time.time()
            
            while self._calls and now - self._calls[0] > 60:
                self._calls.popleft()
            
            if now - self._last_reset >= 1.0:
                self._burst_count = 0
                self._last_reset = now
            
            if len(self._calls) >= self.calls_per_minute:
                return False
            
            if self._burst_count >= self.burst_limit:
                return False
            
            self._calls.append(now)
            self._burst_count += 1
            
            return True
    
    def wait_and_acquire(self, timeout: float = 30.0) -> bool:
        start_time = time.time()
        while time.time() - start_time < timeout:
            if self.acquire():
                return True
            time.sleep(0.1)
        return False
    
    def get_stats(self) -> Dict:
        with self._lock:
            now = time.time()
            while self._calls and now - self._calls[0] > 60:
                self._calls.popleft()
            
            return {
                "calls_last_minute": len(self._calls),
                "burst_count": self._burst_count,
                "limit_per_minute": self.calls_per_minute,
                "burst_limit": self.burst_limit
            }
    
    def reset(self):
        with self._lock:
            self._calls.clear()
            self._burst_count = 0
            self._last_reset = time.time()


class RateLimitedClient:
    """带速率限制的客户端包装器"""
    
    def __init__(self, client, calls_per_minute: int = 60):
        self.client = client
        self._limiter = RateLimiter(calls_per_minute)
        self._waiting_calls = 0
        self._lock = threading.RLock()
    
    def __getattr__(self, name):
        attr = getattr(self.client, name)
        
        if callable(attr):
            @wraps(attr)
            def rate_limited(*args, **kwargs):
                with self._lock:
                    self._waiting_calls += 1
                try:
                    if not self._limiter.wait_and_acquire():
                        raise RuntimeError(f"Rate limit exceeded. Max {self._limiter.calls_per_minute} calls per minute.")
                    return attr(*args, **kwargs)
                finally:
                    with self._lock:
                        self._waiting_calls -= 1
            return rate_limited
        
        return attr
    
    def get_rate_limit_stats(self) -> Dict:
        stats = self._limiter.get_stats()
        with self._lock:
            stats["waiting_calls"] = self._waiting_calls
        return stats