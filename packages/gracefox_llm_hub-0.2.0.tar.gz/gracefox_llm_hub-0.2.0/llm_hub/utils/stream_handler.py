"""流式事件处理器"""

from typing import Callable, Optional, Dict, Any, Generator
from enum import Enum

from llm_hub.models.response import StreamChunk, StreamEventType


class StreamHandler:
    """流式事件处理器"""
    
    def __init__(self):
        self._on_thinking: Optional[Callable] = None
        self._on_content: Optional[Callable] = None
        self._on_code_block: Optional[Callable] = None
        self._on_tool_call: Optional[Callable] = None
        self._on_error: Optional[Callable] = None
        self._on_done: Optional[Callable] = None
        
        self._in_code_block = False
        self._code_buffer = ""
        self._code_lang = ""
    
    def on_thinking(self, callback: Callable):
        self._on_thinking = callback
        return self
    
    def on_content(self, callback: Callable):
        self._on_content = callback
        return self
    
    def on_code_block(self, callback: Callable):
        self._on_code_block = callback
        return self
    
    def on_tool_call(self, callback: Callable):
        self._on_tool_call = callback
        return self
    
    def on_error(self, callback: Callable):
        self._on_error = callback
        return self
    
    def on_done(self, callback: Callable):
        self._on_done = callback
        return self
    
    def _normalize_chunk(self, chunk) -> StreamChunk:
        if isinstance(chunk, StreamChunk):
            return chunk
        elif isinstance(chunk, str):
            return StreamChunk(
                type=StreamEventType.CONTENT,
                content=chunk,
                delta=chunk
            )
        elif isinstance(chunk, dict):
            return StreamChunk(
                type=StreamEventType(chunk.get("type", "content")),
                content=chunk.get("content", ""),
                delta=chunk.get("delta", chunk.get("content", "")),
                accumulated=chunk.get("accumulated", ""),
                metadata=chunk.get("metadata")
            )
        else:
            return StreamChunk(
                type=StreamEventType.CONTENT,
                content=str(chunk),
                delta=str(chunk)
            )
    
    def process(self, stream_generator: Generator) -> str:
        accumulated = ""
        
        for chunk in stream_generator:
            normalized = self._normalize_chunk(chunk)
            
            if normalized.type == StreamEventType.THINKING:
                if self._on_thinking:
                    self._on_thinking(normalized)
            
            elif normalized.type == StreamEventType.CONTENT:
                self._detect_code_blocks(normalized.delta)
                
                if self._on_content:
                    self._on_content(normalized)
                accumulated += normalized.delta
            
            elif normalized.type == StreamEventType.TOOL_CALL:
                if self._on_tool_call:
                    self._on_tool_call(normalized)
            
            elif normalized.type == StreamEventType.ERROR:
                if self._on_error:
                    self._on_error(normalized)
            
            elif normalized.type == StreamEventType.DONE:
                if self._on_done:
                    self._on_done(accumulated)
        
        return accumulated
    
    def _detect_code_blocks(self, text: str):
        if "```" in text:
            if not self._in_code_block:
                lines = text.split('\n')
                for line in lines:
                    if line.strip().startswith('```'):
                        lang = line.strip()[3:].strip()
                        if lang:
                            self._code_lang = lang
                        break
            
            self._in_code_block = not self._in_code_block
            
            if self._on_code_block:
                self._on_code_block({
                    "entered": self._in_code_block,
                    "language": self._code_lang if self._in_code_block else "",
                    "buffer": self._code_buffer if not self._in_code_block else "",
                    "exited": not self._in_code_block
                })
            
            if not self._in_code_block:
                self._code_buffer = ""
                self._code_lang = ""
        else:
            if self._in_code_block:
                self._code_buffer += text


class ThinkingDisplay:
    """思考内容显示器"""
    
    def __init__(self, output_format: str = "ansi"):
        self.output_format = output_format
        self._thinking_buffer = ""
        self._content_buffer = ""
    
    def create_handler(self) -> StreamHandler:
        handler = StreamHandler()
        handler.on_thinking(self._on_thinking)
        handler.on_content(self._on_content)
        handler.on_code_block(self._on_code_block)
        return handler
    
    def _on_thinking(self, chunk: StreamChunk):
        if self.output_format == "ansi":
            print(f"\033[90m{chunk.delta}\033[0m", end="", flush=True)
        elif self.output_format == "markdown":
            if not self._thinking_buffer:
                print("\n> **思考中:** ", end="", flush=True)
            print(chunk.delta, end="", flush=True)
        else:
            print(f"[思考] {chunk.delta}", end="", flush=True)
        
        self._thinking_buffer += chunk.delta
    
    def _on_content(self, chunk: StreamChunk):
        if self.output_format == "ansi":
            print(chunk.delta, end="", flush=True)
        else:
            print(chunk.delta, end="", flush=True)
        
        self._content_buffer += chunk.delta
    
    def _on_code_block(self, event: Dict):
        if event.get("entered"):
            if self.output_format == "ansi":
                print(f"\n\033[96m{'='*50}\033[0m", flush=True)
                lang = event.get("language", "")
                if lang:
                    print(f"\033[93m代码块 [{lang}]:\033[0m")
                else:
                    print("\033[93m代码块:\033[0m")
                print("\033[92m", end="", flush=True)
            else:
                print("\n```")
        else:
            if self.output_format == "ansi":
                print("\033[0m", end="", flush=True)
                print(f"\n\033[96m{'='*50}\033[0m", flush=True)
            else:
                print("\n```")
    
    def get_result(self) -> tuple:
        return self._thinking_buffer, self._content_buffer


def process_stream(stream_generator: Generator, on_content: Callable = None, on_thinking: Callable = None):
    full_content = ""
    full_thinking = ""
    
    for chunk in stream_generator:
        if isinstance(chunk, StreamChunk):
            if chunk.type == StreamEventType.CONTENT:
                full_content += chunk.delta
                if on_content:
                    on_content(chunk.delta, chunk.accumulated)
            elif chunk.type == StreamEventType.THINKING:
                full_thinking += chunk.delta
                if on_thinking:
                    on_thinking(chunk.delta, chunk.accumulated)
        elif isinstance(chunk, str):
            full_content += chunk
            if on_content:
                on_content(chunk, full_content)
    
    return full_content