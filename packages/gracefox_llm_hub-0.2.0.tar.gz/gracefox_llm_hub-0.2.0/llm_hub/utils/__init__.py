"""工具模块"""

from llm_hub.utils.logger import (
    setup_logger,
    get_logger,
    set_log_level,
    get_log_level,
    LoggerMixin,
    debug,
    info,
    warning,
    error,
    critical,
    DEBUG,
    INFO,
    WARNING,
    ERROR,
    CRITICAL
)
from llm_hub.utils.rate_limiter import RateLimiter, RateLimitedClient
from llm_hub.utils.stream_buffer import BoundedStreamBuffer, StreamingResponseCollector
from llm_hub.utils.stream_handler import StreamHandler, ThinkingDisplay, process_stream
from llm_hub.utils.helpers import (
    format_time,
    safe_json_loads,
    get_file_size,
    ensure_dir,
    truncate_text,
    retry_on_failure,
    merge_dicts
)

# 向后兼容 - 使用providers模块的get_token_counter
from llm_hub.providers import get_token_counter

__all__ = [
    # Logger
    "setup_logger",
    "get_logger",
    "set_log_level",
    "get_log_level",
    "LoggerMixin",
    "debug",
    "info",
    "warning",
    "error",
    "critical",
    "DEBUG",
    "INFO",
    "WARNING",
    "ERROR",
    "CRITICAL",
    # Rate Limiter
    "RateLimiter",
    "RateLimitedClient",
    # Stream Buffer
    "BoundedStreamBuffer",
    "StreamingResponseCollector",
    # Stream Handler
    "StreamHandler",
    "ThinkingDisplay",
    "process_stream",
    # Helpers
    "format_time",
    "safe_json_loads",
    "get_file_size",
    "ensure_dir",
    "truncate_text",
    "retry_on_failure",
    "merge_dicts",
    # Token Counter
    "get_token_counter",
]