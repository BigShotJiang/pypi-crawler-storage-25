"""日志模块 - 不自动创建日志目录，由用户决定"""

import logging
import sys
import os
from datetime import datetime
from typing import Optional
from pathlib import Path


_loggers = {}
_default_level = logging.INFO
_default_log_file = None  # 默认不输出到文件


def setup_logger(
    name: str = "llm_hub",
    level: int = logging.INFO,
    log_file: Optional[str] = None,
    console: bool = True,
    file_size_limit: int = 10 * 1024 * 1024,
    backup_count: int = 5
) -> logging.Logger:
    """
    设置日志器
    
    Args:
        name: 日志器名称
        level: 日志级别
        log_file: 日志文件路径，None则不输出到文件（由用户指定）
        console: 是否输出到控制台
        file_size_limit: 日志文件大小限制（字节）
        backup_count: 备份文件数量
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.handlers.clear()
    
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    if console:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            from logging.handlers import RotatingFileHandler
            file_handler = RotatingFileHandler(
                log_file,
                maxBytes=file_size_limit,
                backupCount=backup_count,
                encoding='utf-8'
            )
        except ImportError:
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
        
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    _loggers[name] = logger
    return logger


def get_logger(name: str = None) -> logging.Logger:
    """获取日志器实例，默认只输出到控制台"""
    if name is None:
        name = "llm_hub"
    
    if name not in _loggers:
        # 创建默认日志器 - 只输出到控制台，不创建文件
        setup_logger(name, _default_level, log_file=_default_log_file, console=True)
    
    return _loggers[name]


def set_log_level(level: int):
    """设置全局日志级别"""
    global _default_level
    _default_level = level
    
    for logger in _loggers.values():
        logger.setLevel(level)
        for handler in logger.handlers:
            handler.setLevel(level)


def get_log_level() -> int:
    """获取当前日志级别"""
    return _default_level


def set_log_file(log_file: str, name: str = "llm_hub"):
    """
    设置日志文件输出（由用户主动调用）
    
    Args:
        log_file: 日志文件路径
        name: 日志器名称
    """
    logger = get_logger(name)
    
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    log_path = Path(log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    
    try:
        from logging.handlers import RotatingFileHandler
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=10 * 1024 * 1024,
            backupCount=5,
            encoding='utf-8'
        )
    except ImportError:
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
    
    file_handler.setLevel(logger.level)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)


def remove_log_file(name: str = "llm_hub"):
    """移除日志文件输出"""
    logger = get_logger(name)
    for handler in logger.handlers[:]:
        if isinstance(handler, (logging.FileHandler, logging.handlers.RotatingFileHandler)):
            handler.close()
            logger.removeHandler(handler)


class LoggerMixin:
    """日志混入类"""
    
    @property
    def logger(self) -> logging.Logger:
        if not hasattr(self, '_logger'):
            self._logger = get_logger(self.__class__.__name__)
        return self._logger


# 便捷函数
def debug(msg: str, *args, **kwargs):
    get_logger().debug(msg, *args, **kwargs)


def info(msg: str, *args, **kwargs):
    get_logger().info(msg, *args, **kwargs)


def warning(msg: str, *args, **kwargs):
    get_logger().warning(msg, *args, **kwargs)


def error(msg: str, *args, **kwargs):
    get_logger().error(msg, *args, **kwargs)


def critical(msg: str, *args, **kwargs):
    get_logger().critical(msg, *args, **kwargs)


# 日志级别常量
DEBUG = logging.DEBUG
INFO = logging.INFO
WARNING = logging.WARNING
ERROR = logging.ERROR
CRITICAL = logging.CRITICAL


# 注意：不再自动初始化日志器
# 用户需要时主动调用 get_logger() 或 setup_logger()