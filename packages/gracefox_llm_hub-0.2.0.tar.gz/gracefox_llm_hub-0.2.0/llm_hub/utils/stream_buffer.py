"""流式缓冲区"""

import threading
from typing import Optional


class BoundedStreamBuffer:
    """有上限的流式缓冲区"""
    
    def __init__(self, max_chars: int = 100000, max_tokens: int = 10000):
        self.max_chars = max_chars
        self.max_tokens = max_tokens
        self._buffer = ""
        self._lock = threading.Lock()
        self._truncation_occurred = False
    
    def append(self, text: str) -> str:
        with self._lock:
            self._buffer += text
            
            estimated_tokens = self._estimate_tokens(self._buffer)
            
            overflow = ""
            if len(self._buffer) > self.max_chars:
                overflow = self._buffer[self.max_chars:]
                self._buffer = self._buffer[:self.max_chars]
                self._truncation_occurred = True
            elif estimated_tokens > self.max_tokens:
                overflow = self._truncate_by_tokens(estimated_tokens)
            
            return overflow
    
    def _estimate_tokens(self, text: str) -> int:
        chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        english_words = len([w for w in text.split() if any(c.isalpha() for c in w)])
        return chinese_chars + int(english_words * 1.3) + 2
    
    def _truncate_by_tokens(self, current_tokens: int) -> str:
        if current_tokens <= self.max_tokens:
            return ""
        
        ratio = self.max_tokens / current_tokens
        new_len = int(len(self._buffer) * ratio)
        overflow = self._buffer[new_len:]
        self._buffer = self._buffer[:new_len]
        self._truncation_occurred = True
        return overflow
    
    def get(self) -> str:
        with self._lock:
            return self._buffer
    
    def clear(self):
        with self._lock:
            self._buffer = ""
            self._truncation_occurred = False
    
    def was_truncated(self) -> bool:
        return self._truncation_occurred
    
    def __len__(self) -> int:
        return len(self._buffer)


class StreamingResponseCollector:
    """流式响应收集器"""
    
    def __init__(self, max_content_chars: int = 100000, max_thinking_chars: int = 50000):
        self.content_buffer = BoundedStreamBuffer(max_content_chars)
        self.thinking_buffer = BoundedStreamBuffer(max_thinking_chars)
        self._is_thinking = False
    
    def add_thinking(self, text: str):
        self._is_thinking = True
        overflow = self.thinking_buffer.append(text)
        if overflow:
            self.thinking_buffer.append("\n[思考内容过长，已截断]")
    
    def add_content(self, text: str):
        self._is_thinking = False
        overflow = self.content_buffer.append(text)
        if overflow:
            self.content_buffer.append("\n[内容过长，已截断]")
    
    def get_content(self) -> str:
        return self.content_buffer.get()
    
    def get_thinking(self) -> str:
        return self.thinking_buffer.get()
    
    def clear(self):
        self.content_buffer.clear()
        self.thinking_buffer.clear()
    
    def get_stats(self) -> dict:
        return {
            "content_chars": len(self.content_buffer),
            "thinking_chars": len(self.thinking_buffer),
            "content_truncated": self.content_buffer.was_truncated(),
            "thinking_truncated": self.thinking_buffer.was_truncated()
        }