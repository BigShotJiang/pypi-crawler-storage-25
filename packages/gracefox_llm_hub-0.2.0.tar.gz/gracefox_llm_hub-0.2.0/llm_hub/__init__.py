"""
LLM Hub - 统一的LLM调用库

一个轻量级的Python库，支持多种LLM提供商：
- OpenAI, DeepSeek, Kimi, Gemini, Claude
- 通义千问, 智谱GLM, 百度文心, MiniCPM
- Ollama, llama.cpp

Usage:
    from llm_hub import LLMClient, LLMConfig, Provider
    
    config = LLMConfig(
        provider=Provider.DEEPSEEK,
        api_key="your-key",
        enable_environment=True
    )
    client = LLMClient(config)
    response = client.chat("Hello")

扩展第三方Provider:
    # 安装第三方包后自动发现
    from llm_hub import list_providers, get_provider_class
    print(list_providers())  # 列出所有可用Provider
"""

from llm_hub.version import __version__, __author__, __license__
from llm_hub.core.client import LLMClient
from llm_hub.core.enums import Provider, ModelType, ResponseFormat
from llm_hub.core.exceptions import (
    LLMHubError, ConfigError, ProviderError, 
    RateLimitError, TokenLimitError
)
from llm_hub.config import LLMConfig, ConfigManager, get_config_manager
from llm_hub.models import Message, Conversation, Role
from llm_hub.models import Response, StreamResponse, StreamChunk, StreamEventType
from llm_hub.providers import get_token_counter, ProviderRegistry, create_provider
from llm_hub.utils import get_logger, setup_logger

# 环境感知模块（可选）
try:
    from llm_hub.environment import EnvironmentManager
    ENVIRONMENT_AVAILABLE = True
except ImportError:
    ENVIRONMENT_AVAILABLE = False
    EnvironmentManager = None


def list_providers() -> list:
    """
    列出所有可用的Provider（包括第三方插件）
    
    Returns:
        可用Provider名称列表
    """
    return ProviderRegistry.list_providers()


def get_provider_class(name: str):
    """
    获取Provider类（支持第三方插件）
    
    Args:
        name: Provider名称（如 'openai', 'deepseek'）
    
    Returns:
        Provider类
    """
    return ProviderRegistry.get_provider_class(name)


def register_provider(name: str, provider_class):
    """
    手动注册Provider（用于动态扩展）
    
    Args:
        name: Provider名称
        provider_class: Provider类
    """
    ProviderRegistry.register(name, provider_class)


__all__ = [
    "__version__", "__author__", "__license__",
    # 核心
    "LLMClient",
    "LLMConfig",
    "Provider",
    "ModelType",
    "ResponseFormat",
    # 配置
    "ConfigManager",
    "get_config_manager",
    # 模型
    "Message",
    "Conversation",
    "Role",
    "Response",
    "StreamResponse",
    "StreamChunk",
    "StreamEventType",
    # Token
    "get_token_counter",
    # 环境
    "EnvironmentManager",
    "ENVIRONMENT_AVAILABLE",
    # 异常
    "LLMHubError",
    "ConfigError",
    "ProviderError",
    "RateLimitError",
    "TokenLimitError",
    # 日志
    "get_logger",
    "setup_logger",
    # 插件系统
    "list_providers",
    "get_provider_class",
    "register_provider",
    "create_provider",
]