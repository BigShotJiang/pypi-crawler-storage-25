"""响应模型"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, Generator, List
from enum import Enum


class StreamEventType(Enum):
    """流式事件类型"""
    THINKING = "thinking"
    CONTENT = "content"
    TOOL_CALL = "tool_call"
    ERROR = "error"
    DONE = "done"


@dataclass
class StreamChunk:
    """流式响应块"""
    type: StreamEventType
    content: str = ""
    delta: str = ""
    accumulated: str = ""
    metadata: Optional[Dict] = None
    
    def __str__(self):
        return self.content


class StreamResponse:
    """流式响应"""
    
    def __init__(self, generator: Generator):
        self.generator = generator
    
    def __iter__(self):
        return self.generator
    
    def __next__(self):
        return next(self.generator)
    
    def collect(self) -> str:
        """收集所有流式响应（仅内容）"""
        result = ""
        for chunk in self.generator:
            if chunk.type == StreamEventType.CONTENT:
                result += chunk.content
        return result
    
    def collect_with_thinking(self) -> tuple:
        """收集所有响应，分离思考和内容"""
        thinking = ""
        content = ""
        tool_calls = []
        
        for chunk in self.generator:
            if chunk.type == StreamEventType.THINKING:
                thinking += chunk.content
            elif chunk.type == StreamEventType.CONTENT:
                content += chunk.content
            elif chunk.type == StreamEventType.TOOL_CALL:
                tool_calls.append(chunk.content)
        
        return thinking, content, tool_calls


@dataclass
class Response:
    """普通响应"""
    content: str = ""
    thinking: str = ""
    model: str = ""
    usage: Optional[Dict[str, int]] = None
    finish_reason: Optional[str] = None
    raw: Optional[Dict] = None
    
    def __str__(self):
        return self.content
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "content": self.content,
            "thinking": self.thinking,
            "model": self.model,
            "usage": self.usage,
            "finish_reason": self.finish_reason
        }