"""版本信息"""
__version__ = "0.2.0"
__author__ = "GraceFox"
__license__ = "GPL-3.0"