# LLM Hub - Unified LLM Calling Library

[![English](https://img.shields.io/badge/Switch_English-README.md-blue.svg)](README.md)
[![中文](https://img.shields.io/badge/Switch_中文-README_zh.md-red.svg)](README_zh.md)
[![PyPI version](https://img.shields.io/pypi/v/gracefox-llm-hub.svg)](https://pypi.org/project/gracefox-llm-hub/)
[![Python versions](https://img.shields.io/pypi/pyversions/gracefox-llm-hub.svg)](https://pypi.org/project/gracefox-llm-hub/)
[![License](https://img.shields.io/github/license/GraceFox/llm-hub.svg)](LICENSE)

A unified calling library supporting multiple LLM providers (International + Chinese AI), providing a consistent API interface.

## ✨ Features

- 🔌 **Unified API** - One interface for all LLM providers
- 🌍 **Multi-Provider Support** - OpenAI, DeepSeek, Kimi, Gemini, Claude, etc.
- 🇨🇳 **Chinese AI Support** - Qwen, GLM, ERNIE, MiniCPM
- 💻 **Local Deployment** - Ollama, llama.cpp
- 🤔 **Reasoning Mode** - Display thinking process (DeepSeek support)
- 📊 **Accurate Token Counting** - Official tokenizers for each provider
- 📡 **Streaming Output** - Real-time response generation
- 💾 **Configuration Management** - JSON/YAML config, profiles, environment variables
- 🔌 **Plugin System** - Support for third-party Provider extensions

## 📋 Supported Providers

| Provider | Type | Token Counting | Reasoning Mode |
|----------|------|----------------|----------------|
| **OpenAI** | Cloud | ✅ tiktoken | ❌ |
| **DeepSeek** | Cloud | ✅ deepseek-tokenizer | ✅ |
| **Kimi** | Cloud | ✅ API | ❌ |
| **Google Gemini** | Cloud | ⚠️ Estimation | ❌ |
| **Anthropic Claude** | Cloud | ⚠️ Estimation | ❌ |
| **Qwen** | Cloud | ✅ qwen-tokenizer | ❌ |
| **GLM** | Cloud | ✅ transformers | ❌ |
| **ERNIE** | Cloud | ✅ transformers | ❌ |
| **MiniCPM** | Cloud/Local | ✅ transformers | ❌ |
| **Ollama** | Local | ✅ API tokenize | ❌ |
| **llama.cpp** | Local | ✅ Subprocess | ❌ |

## 🚀 Quick Start

### Installation

```bash
# Basic installation
pip install gracefox-llm-hub

# Install environment sensing support (system resource monitoring)
pip install gracefox-llm-hub[env]

# Install accurate token counting
pip install gracefox-llm-hub[tokenizers]

# Install secure encryption support
pip install gracefox-llm-hub[secure]

# Install YAML config support
pip install gracefox-llm-hub[yaml]

# Install all features
pip install gracefox-llm-hub[all]
```

### Basic Usage

```python
from llm_hub import LLMClient, LLMConfig, Provider

# Create DeepSeek client
client = LLMClient(LLMConfig(
    provider=Provider.DEEPSEEK,
    model="deepseek-chat",
    api_key="your-api-key"
))

# Single round conversation
response = client.chat("What is artificial intelligence?")
print(response.content)
```

> 📖 **Complete API usage examples can be found in the [docs/](docs/) directory**

## ⚙️ Configuration

### Configuration File Format

```json
{
    "provider": "deepseek",
    "model": "deepseek-chat",
    "api_key": "your-api-key",
    "temperature": 0.7,
    "max_tokens": 2000,
    "reasoning": true,
    "stream": true
}
```

### Environment Variables

```bash
export LLM_PROVIDER=deepseek
export LLM_MODEL=deepseek-chat
export LLM_API_KEY=your-key
export LLM_TEMPERATURE=0.7
```

### Configuration Priority (Low to High)

1. Default configuration
2. Environment variables
3. Configuration profiles
4. Configuration files
5. JSON string
6. Code parameters

## 📦 Project Structure

```
llm-hub/
├── llm_hub/
│   ├── core/           # Core functionality
│   │   ├── client.py   # Main client
│   │   ├── enums.py    # Enum definitions
│   │   └── exceptions.py # Exception definitions
│   ├── config/         # Configuration management
│   │   ├── config.py   # Configuration class
│   │   ├── manager.py  # Configuration manager
│   │   └── security.py # Encryption and security
│   ├── models/         # Data models
│   │   ├── message.py  # Message and Conversation
│   │   └── response.py # Response models
│   ├── providers/      # Provider implementations
│   │   ├── base.py     # Base classes
│   │   ├── factory.py  # Factory and plugin system
│   │   ├── deepseek.py # DeepSeek
│   │   ├── qwen.py     # Qwen
│   │   ├── glm.py      # GLM
│   │   ├── ernie.py    # ERNIE
│   │   ├── minicpm.py  # MiniCPM
│   │   └── ...
│   ├── environment/    # Environment sensing (optional)
│   └── utils/          # Utility functions
│       ├── token_counter.py  # Token counting
│       ├── stream_handler.py # Stream handling
│       ├── rate_limiter.py   # Rate limiting
│       └── logger.py         # Logging system
├── docs/               # API documentation and examples
├── examples/           # Example code
├── pyproject.toml      # Project configuration
└── README.md           # This document
```

## 🔧 Development Guide

```bash
# Clone repository
git clone https://gitee.com/SteHub/llm-hub.git
cd llm-hub

# Development installation
pip install -e .[dev,all]

# Code formatting
black llm_hub/

# Code linting
ruff check llm_hub/

# Type checking
mypy llm_hub/
```

## 🔌 Plugin System

LLM Hub supports third-party Provider extensions through the entry points mechanism.

### Developing Third-party Providers

```python
# setup.py
from setuptools import setup

setup(
    name="my-llm-provider",
    entry_points={
        "llm_hub.providers": [
            "my_provider = my_package:MyProvider",
        ]
    }
)
```

After installation, it will be automatically discovered without modifying llm_hub code.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit Pull Requests.

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing`)
5. Open a Pull Request

## 📄 License

GNU General Public License v3.0 - See [LICENSE](LICENSE) file for details

## 📧 Contact

- Author: GraceFox
- Email: 948743980@qq.com
- Homepage: https://gitee.com/SteHub/llm-hub
- Issues: https://gitee.com/SteHub/llm-hub/issues

---

## Quick Reference

### Installation Options

| Option | Description | Dependencies |
|--------|-------------|--------------|
| `[env]` | Environment sensing | psutil |
| `[tokenizers]` | Accurate token counting | tiktoken, transformers |
| `[secure]` | Secure encryption | cryptography |
| `[yaml]` | YAML configuration | pyyaml |
| `[all]` | All features | All of the above |

### Supported Providers

| Provider | Config Value | Example Model |
|----------|--------------|----------------|
| OpenAI | `openai` | `gpt-3.5-turbo` |
| DeepSeek | `deepseek` | `deepseek-chat` |
| Kimi | `kimi` | `moonshot-v1-8k` |
| Qwen | `qwen` | `qwen-turbo` |
| GLM | `glm` | `glm-4-flash` |
| ERNIE | `ernie` | `ernie-3.5-8k` |
| MiniCPM | `minicpm` | `minicpm` |
| Ollama | `ollama` | `llama2` |
| llama.cpp | `llama_cpp` | `llama-2-7b` |

### API Key Acquisition

| Provider | URL |
|----------|-----|
| OpenAI | https://platform.openai.com/api-keys |
| DeepSeek | https://platform.deepseek.com/api_keys |
| Kimi | https://platform.moonshot.cn/console/apiKey |
| Qwen | https://dashscope.console.aliyun.com/apiKey |
| GLM | https://open.bigmodel.cn/usercenter/apikeys |
| ERNIE | https://console.bce.baidu.com/ai_platform/ |

---

> 📖 **Complete API usage examples, streaming output, reasoning mode, token counting, and more detailed documentation can be found in the [docs/](docs/) directory**

**⭐ If you find this useful, please give it a Star on Gitee!**
