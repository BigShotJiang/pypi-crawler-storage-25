"""
Session runtime (outer engine ≈ QueryEngine + session store).

- **SqliteSessionService**: durable session + events (like transcript persistence).
- **Runner**: wires the root agent to the session, equivalent to “submit query → stream events”.

The inner turn loop (model ↔ tools) is implemented inside ADK (analogous to `query.ts` +
StreamingToolExecutor + runTools orchestration). See `gemcode.query` for transition types,
token budget helpers, and `GemCodeQueryEngine`.
"""

from __future__ import annotations

import os
import warnings
from pathlib import Path

# Suppress ADK's noisy "EXPERIMENTAL feature" UserWarning globally.
# Users get enough context from gemcode's own messages; the warning is redundant.
warnings.filterwarnings("ignore", category=UserWarning, message=".*EXPERIMENTAL.*")

from google.adk.runners import Runner
from google.adk.sessions.sqlite_session_service import SqliteSessionService

from gemcode.agent import build_global_instruction, build_root_agent
from gemcode.config import GemCodeConfig
from gemcode.modality_tools import build_extra_tools as build_modality_extra_tools
from gemcode.memory.embedding_memory_service import EmbeddingFileMemoryService
from gemcode.memory.file_memory_service import FileMemoryService
from gemcode.plugins.terminal_hooks_plugin import GemCodeTerminalHooksPlugin
from gemcode.plugins.tool_recovery_plugin import GemCodeReflectAndRetryToolPlugin


# ---------------------------------------------------------------------------
# ADK: Gemini context cache — quiet "stale delete" failures
# ---------------------------------------------------------------------------


def _gemini_cache_delete_already_gone(exc: BaseException) -> bool:
  """True when delete failed only because the cache entry is already gone.

  The Gemini API often returns ``403 PERMISSION_DENIED`` with a body like
  ``CachedContent not found`` after TTL expiry or server-side eviction. ADK's
  default cleanup logs that as WARNING every time — noisy and usually harmless.
  """
  msg = str(exc).lower()
  if "cachedcontent not found" in msg:
    return True
  if "not found" in msg and "cached" in msg:
    return True
  code = getattr(exc, "code", None)
  if code == 404:
    return True
  status = (getattr(exc, "status", None) or "").upper()
  if code == 403 and status == "PERMISSION_DENIED" and ("cachedcontent" in msg or "cached content" in msg):
    return True
  return False


def _patch_gemini_adk_cache_cleanup() -> None:
  """Downgrade benign cache-delete failures to DEBUG (see ``_gemini_cache_delete_already_gone``)."""
  try:
    from google.adk.models import gemini_context_cache_manager as gccm
  except Exception:
    return
  if getattr(gccm.GeminiContextCacheManager, "_gemcode_cleanup_patch", False):
    return

  async def _cleanup(self, cache_name: str) -> None:
    gccm.logger.debug("Attempting to delete cache: %s", cache_name)
    try:
      await self.genai_client.aio.caches.delete(name=cache_name)
      gccm.logger.info("Cache cleaned up: %s", cache_name)
    except BaseException as e:
      if _gemini_cache_delete_already_gone(e):
        gccm.logger.debug(
            "Cache delete no-op (already expired or gone): %s — %s",
            cache_name,
            e,
        )
        return
      gccm.logger.warning("Failed to cleanup cache %s: %s", cache_name, e)

  gccm.GeminiContextCacheManager.cleanup_cache = _cleanup  # type: ignore[method-assign]
  gccm.GeminiContextCacheManager._gemcode_cleanup_patch = True


_patch_gemini_adk_cache_cleanup()


# ---------------------------------------------------------------------------
# ADK App-level feature helpers
# ---------------------------------------------------------------------------

def _build_context_cache_config():
  """Return ContextCacheConfig if context caching is enabled, else None.

  Context caching lets Gemini reuse the compiled representation of a stable
  prefix (system prompt + tools) across multiple turns, cutting ~75% of input
  token costs on long sessions.

  Opt-out: set ``GEMCODE_CONTEXT_CACHE=0`` in the environment.
  """
  if os.environ.get("GEMCODE_CONTEXT_CACHE", "1").lower() in ("0", "false", "no", "off"):
    return None
  try:
    from google.adk.agents.context_cache_config import ContextCacheConfig
    return ContextCacheConfig(
      cache_intervals=10,   # refresh the cache every 10 invocations
      ttl_seconds=1800,     # cache lives 30 minutes
      min_tokens=1024,      # skip caching tiny sessions (< ~1 K tokens)
    )
  except Exception:
    return None


def _build_app(agent, plugins, cfg: GemCodeConfig):
  """Wrap the root agent in an ADK App for modern plugin + context-cache support.

  Using ``App`` instead of passing ``agent`` + ``plugins`` directly to ``Runner``
  is the recommended ADK pattern as of ADK 1.x (``plugins=`` on ``Runner`` is
  officially deprecated).
  """
  try:
    from google.adk.apps.app import App
    events_compaction_config = None
    if getattr(cfg, "enable_adk_events_compaction", False):
      try:
        from google.adk.apps.app import EventsCompactionConfig
        summarizer = None
        try:
          from google.adk.apps.llm_event_summarizer import LlmEventSummarizer
          from google.adk.models import Gemini
          summarizer_llm = Gemini(model=getattr(cfg, "adk_compaction_summarizer_model", "gemini-2.5-flash"))
          summarizer = LlmEventSummarizer(llm=summarizer_llm)
        except Exception:
          summarizer = None

        kw = dict(
          compaction_interval=max(2, int(getattr(cfg, "adk_compaction_interval", 6) or 6)),
          overlap_size=max(0, int(getattr(cfg, "adk_compaction_overlap", 1) or 1)),
        )
        tt = getattr(cfg, "adk_compaction_token_threshold", None)
        rs = getattr(cfg, "adk_compaction_event_retention_size", None)
        if tt is not None and rs is not None:
          kw["token_threshold"] = int(tt)
          kw["event_retention_size"] = int(rs)
        if summarizer is not None:
          kw["summarizer"] = summarizer
        events_compaction_config = EventsCompactionConfig(**kw)
      except Exception:
        events_compaction_config = None
    return App(
      name="gemcode",
      root_agent=agent,
      plugins=plugins,
      context_cache_config=_build_context_cache_config(),
      events_compaction_config=events_compaction_config,
    )
  except Exception:
    # Fall back silently — Runner still accepts the legacy kwargs.
    return None


def session_db_path(cfg: GemCodeConfig) -> Path:
  return cfg.project_root / ".gemcode" / "sessions.sqlite"


def _wrap_computer_use_tools_with_safety_ack(llm_request) -> None:
  """
  Gemini Computer Use models may include `safety_decision` in tool call args.
  The client must acknowledge it in the corresponding FunctionResponse or the
  API returns HTTP 400.

  ADK's ComputerUseTool returns only image/url by default, so we wrap the tool
  functions to (a) ignore `safety_decision` for execution and (b) include
  `safety_acknowledgement="true"` in the tool result when present.
  """
  try:
    from google.adk.tools.computer_use.computer_use_tool import ComputerUseTool
  except Exception:
    return

  try:
    tools_dict = getattr(llm_request, "tools_dict", None)
    if not isinstance(tools_dict, dict) or not tools_dict:
      return
  except Exception:
    return

  # Wrap each ComputerUseTool's underlying function in-place.
  for tool_name, tool in list(tools_dict.items()):
    try:
      if not isinstance(tool, ComputerUseTool):
        continue
      original_func = getattr(tool, "func", None)
      if original_func is None:
        continue

      async def wrapped(*, _orig=original_func, _tool_name=tool_name, **args):
        sd = None
        if isinstance(args, dict) and "safety_decision" in args:
          sd = args.pop("safety_decision", None)
        result = await _orig(**args)
        if sd is None:
          return result
        # Acknowledge the safety decision as required by Gemini computer-use.
        if isinstance(result, dict):
          out = dict(result)
          out["safety_acknowledgement"] = "true"
          return out
        return {"result": result, "safety_acknowledgement": "true"}

      try:
        wrapped.__name__ = tool_name
      except Exception:
        pass
      tool.func = wrapped
    except Exception:
      continue


def _playwright_available() -> bool:
  """
  Quick synchronous check: does a usable Playwright browser executable exist?

  Runs playwright.sync_api.sync_playwright() briefly to resolve the browser
  path, without actually launching a browser. Falls back to a path probe if
  playwright is not installed.

  Returns True only when Playwright AND at least one browser binary are present.
  This is called before building the runner so we can disable computer-use
  early and prevent model routing from switching to gemini-2.5-computer-use-*.
  """
  # 1) Preferred: ask Playwright for the resolved executable path.
  # This can fail in some environment-mismatch cases (package installed but driver
  # cannot start), so we also do a cache-based probe below.
  try:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
      exe = getattr(p.chromium, "executable_path", None)
      if exe and Path(str(exe)).exists():
        return True
  except Exception:
    pass

  # 2) Fallback: check the default browser cache directly.
  # This avoids false negatives when Playwright import/driver resolution is flaky,
  # but browsers are present (common on macOS with mixed --user/system installs).
  try:
    cache_root = Path.home() / "Library" / "Caches" / "ms-playwright"
    if not cache_root.exists():
      return False
    # macOS paths (Chromium.app or "Google Chrome for Testing.app")
    mac_bins = list(cache_root.glob("chromium-*/*/Chromium.app/Contents/MacOS/Chromium"))
    mac_bins += list(
      cache_root.glob(
        "chromium-*/*/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing"
      )
    )
    if any(p.exists() for p in mac_bins):
      return True
  except Exception:
    pass

  return False


def _make_safe_computer_toolset(computer):
  """
  Build a BaseToolset-compatible wrapper around ComputerUseToolset that catches
  Playwright startup failures gracefully instead of crashing LlmAgent validation.

  Must be a proper BaseToolset subclass (not a plain class) because ADK's Pydantic
  model for LlmAgent validates each entry in `tools` against BaseTool | BaseToolset.
  Returns a real BaseToolset subclass instance, or None if BaseToolset is unavailable.
  """
  try:
    from google.adk.tools.base_toolset import BaseToolset
  except ImportError:
    return None

  class _SafeComputerUseToolset(BaseToolset):
    """Wraps ComputerUseToolset; degrades to a no-op if Playwright is missing."""

    def __init__(self) -> None:
      try:
        from google.adk.tools.computer_use.computer_use_toolset import ComputerUseToolset
        self._inner = ComputerUseToolset(computer=computer)
      except Exception:
        self._inner = None
      self._broken = False
      self._warned = False

    def _warn_once(self, error: Exception) -> None:
      if self._warned:
        return
      self._warned = True
      import sys
      msg = str(error)
      if "playwright install" in msg.lower() or "executable doesn't exist" in msg.lower():
        print(
          "\n[gemcode] Browser (computer-use) is unavailable — Playwright browsers are not installed.\n"
          "  Run:  playwright install chromium\n"
          "  Then restart GemCode with /computer on (or --computer flag).\n"
          "  Continuing without browser tools for this session.\n",
          file=sys.stderr,
        )
      else:
        print(
          f"\n[gemcode] Browser (computer-use) failed to start: {msg!s:.200}\n"
          "  Continuing without browser tools for this session.\n",
          file=sys.stderr,
        )

    # ── BaseToolset required attribute ──────────────────────────────────────
    @property
    def tool_name_prefix(self) -> str:
      if self._inner is not None:
        try:
          return self._inner.tool_name_prefix
        except Exception:
          pass
      return ""

    # ── Core protocol methods ────────────────────────────────────────────────

    async def process_llm_request(self, *, tool_context, llm_request) -> None:
      if self._broken or self._inner is None:
        return
      try:
        await self._inner.process_llm_request(
            tool_context=tool_context, llm_request=llm_request
        )
        _wrap_computer_use_tools_with_safety_ack(llm_request)
      except Exception as exc:
        if not self._broken:
          self._broken = True
          self._warn_once(exc)

    async def get_tools(self, readonly_context=None):
      if self._broken or self._inner is None:
        return []
      try:
        return await self._inner.get_tools(readonly_context)
      except Exception as exc:
        if not self._broken:
          self._broken = True
          self._warn_once(exc)
        return []

    async def close(self) -> None:
      if self._inner is not None:
        try:
          await self._inner.close()
        except Exception:
          pass

    def __getattr__(self, name: str):
      """Proxy any other BaseToolset attributes ADK needs to the inner toolset."""
      # Guard against infinite recursion for our own private attrs.
      if name.startswith("_"):
        raise AttributeError(name)
      inner = object.__getattribute__(self, "_inner")
      if inner is not None:
        try:
          return getattr(inner, name)
        except AttributeError:
          pass
      raise AttributeError(f"'_SafeComputerUseToolset' has no attribute '{name}'")

  return _SafeComputerUseToolset()


def _build_artifact_service(cfg: GemCodeConfig):
  """Return an ADK ArtifactService for this session, or None if disabled.

  Uses ``FileArtifactService`` backed by ``.gemcode/artifacts/`` so that
  artifacts (screenshots, generated reports, diffs, etc.) survive session
  restarts.  Falls back to ``InMemoryArtifactService`` if the file-based
  service is unavailable (older ADK).
  """
  if not getattr(cfg, "enable_artifacts", True):
    return None
  try:
    from google.adk.artifacts import FileArtifactService
    artifacts_dir = cfg.project_root / ".gemcode" / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    return FileArtifactService(root_dir=artifacts_dir)
  except Exception:
    pass
  # Fallback for older ADK versions that don't have FileArtifactService.
  try:
    from google.adk.artifacts import InMemoryArtifactService
    return InMemoryArtifactService()
  except Exception:
    return None


def create_runner(cfg: GemCodeConfig, extra_tools: list | None = None) -> Runner:
  """Construct Runner + SQLite session service + root LlmAgent."""
  # Load per-repo calibration profile (self-tuning dynamic policy).
  try:
    from gemcode.policy_profile import calibrated_baseline_risk, load_profile
    prof = load_profile(cfg.project_root)
    base = calibrated_baseline_risk(prof)
    cur = float(getattr(cfg, "_risk_score", 0.0) or 0.0)
    object.__setattr__(cfg, "_risk_score", max(cur, base))
    object.__setattr__(cfg, "_policy_profile", prof.to_dict())
  except Exception:
    pass
  modality_tools = build_modality_extra_tools(cfg)
  merged_extra_tools: list | None
  if extra_tools:
    merged_extra_tools = [*extra_tools, *modality_tools] if modality_tools else list(extra_tools)
  else:
    merged_extra_tools = modality_tools or None

  # Curated memory snapshot: load once per session and keep stable
  # to avoid cache-breaking prompt drift.
  try:
    from gemcode.curated_memory import load_snapshot
    snap = load_snapshot(cfg.project_root, max_chars=6000)
    object.__setattr__(cfg, "_curated_memory_snapshot", snap if snap.get("exists") else None)
  except Exception:
    pass

  # VeoMem wake-up snapshot (optional): load once per session and keep stable.
  try:
    import os
    if os.environ.get("GEMCODE_VEOMEM", "").strip().lower() in ("1", "true", "yes", "on"):
      from veomem.wakeup import build_wake_up_context  # type: ignore[import-not-found]
      # Ensure store exists; build_wake_up_context can work even if empty.
      from veomem.store import init_store  # type: ignore[import-not-found]

      init_store(cfg.project_root)
      snap2 = build_wake_up_context(cfg.project_root, max_chars=5000, limit=30)
      txt = (snap2.get("text") if isinstance(snap2, dict) else "") or ""
      object.__setattr__(cfg, "_veomem_wakeup_text", txt.strip() if isinstance(txt, str) else "")
  except Exception:
    pass

  # ── MCP toolsets from .gemcode/mcp.json ─────────────────────────────────
  # Supports stdio, http (Streamable HTTP), and sse connection types.
  try:
    from gemcode.mcp_loader import load_mcp_toolsets
    mcp_tools = load_mcp_toolsets(cfg)
    if mcp_tools:
      merged_extra_tools = list(merged_extra_tools or []) + mcp_tools
  except Exception:
    pass  # MCP not installed or mcp.json invalid — continue without

  # ── OpenAPI toolsets from .gemcode/openapi/ ──────────────────────────────
  # Drop any *.yaml / *.json OpenAPI spec in .gemcode/openapi/ to auto-generate
  # REST API tools for that service (GitHub, Sentry, internal APIs, etc.)
  try:
    from gemcode.openapi_loader import load_openapi_toolsets
    oa_tools = load_openapi_toolsets(cfg.project_root)
    if oa_tools:
      merged_extra_tools = list(merged_extra_tools or []) + oa_tools
  except Exception:
    pass  # OpenAPIToolset not in this ADK version — continue without

  # ── AFC compatibility prompt (optional) ───────────────────────────────────
  # Gemini Automatic Function Calling (AFC) only works when the tool list is
  # composed of Python callables. Some ADK toolsets (MCP/OpenAPI/built-in
  # declarations) may be non-callable and cause AFC to be disabled.
  #
  # If we're in an interactive terminal and the user opted into prompting,
  # ask whether to keep "all tools" (AFC disabled) or restrict to callables
  # (AFC enabled).
  try:
    import os
    import sys

    prompt_afc = os.environ.get("GEMCODE_AFC_PROMPT", "1").strip().lower() in ("1", "true", "yes", "on")
    afc_default = (os.environ.get("GEMCODE_AFC_DEFAULT") or "").strip().lower()
    if prompt_afc and hasattr(sys.stdin, "isatty") and sys.stdin.isatty():
      tools_list = list(merged_extra_tools or [])
      noncallable = [t for t in tools_list if not callable(t)]
      if noncallable and getattr(cfg, "_afc_choice", None) not in ("all", "callables") and afc_default in ("all", "callables"):
        object.__setattr__(cfg, "_afc_choice", afc_default)
      if noncallable and getattr(cfg, "_afc_choice", None) not in ("all", "callables"):
        print(
          "\n[gemcode] AFC compatibility\n"
          "Gemini Automatic Function Calling (AFC) works best with Python callables only.\n"
          "Some enabled toolsets appear non-callable, which can disable AFC.\n\n"
          "Choose tool mode for this session:\n"
          "  [Enter] all tools (recommended; AFC may be disabled)\n"
          "  c       callable-only tools (keeps AFC; disables MCP/OpenAPI/toolsets)\n",
          file=sys.stderr,
        )
        try:
          ans = input("afc> ").strip().lower()
        except EOFError:
          ans = ""
        if ans.startswith("c"):
          object.__setattr__(cfg, "_afc_choice", "callables")
        else:
          object.__setattr__(cfg, "_afc_choice", "all")

      if getattr(cfg, "_afc_choice", None) == "callables":
        merged_extra_tools = [t for t in tools_list if callable(t)] or None
  except Exception:
    pass

  # Computer-use: ADK ComputerUseToolset backed by our Playwright BrowserComputer.
  # Probe Playwright BEFORE building the agent so model routing (which runs
  # inside build_root_agent → pick_effective_model) never switches to
  # gemini-2.5-computer-use-* when the browser binary is missing.
  if getattr(cfg, "enable_computer_use", False):
    if not _playwright_available():
      import sys
      print(
        "\n[gemcode] Browser (computer-use) is unavailable — Playwright browsers "
        "are not installed.\n"
        "  Run:  playwright install chromium\n"
        "  Then restart GemCode with /computer on (or --computer flag).\n"
        "  Disabling computer-use for this session.\n",
        file=sys.stderr,
      )
      # Disable so model_routing stays on the normal model (not computer-use preview).
      cfg.enable_computer_use = False
      cfg._computer_use_available = False  # type: ignore[attr-defined]
      # If the TUI already routed the model to the computer-use preview model for
      # this turn, reset back to the normal model so the next agent construction
      # doesn't keep using a model that requires the missing tool.
      try:
        if not getattr(cfg, "model_overridden", False) and cfg.model == cfg.model_computer_use:
          cfg.model = os.environ.get("GEMCODE_MODEL", "gemini-3.1-pro-preview")
      except Exception:
        pass
    else:
      cfg._computer_use_available = True  # type: ignore[attr-defined]
      headless_env = os.environ.get("GEMCODE_COMPUTER_HEADLESS", "1").lower()
      headless = headless_env in ("1", "true", "yes", "on")
      viewport_w = int(os.environ.get("GEMCODE_BROWSER_WIDTH", "1280"))
      viewport_h = int(os.environ.get("GEMCODE_BROWSER_HEIGHT", "720"))
      from gemcode.computer_use.browser_computer import BrowserComputer

      computer = BrowserComputer(
        headless=headless,
        viewport_size=(viewport_w, viewport_h),
      )
      computer_toolset = _make_safe_computer_toolset(computer)
      merged_extra_tools = list(merged_extra_tools or [])
      if computer_toolset is not None:
        merged_extra_tools.append(computer_toolset)

      # Standalone read-only browser tools (browser_screenshot, browser_get_text, etc.)
      from gemcode.tools.browser import build_browser_inspection_tools
      browser_tools = build_browser_inspection_tools(cfg, computer)
      merged_extra_tools.extend(browser_tools)

      # Store reference on cfg so slash commands / TUI can check browser state.
      cfg._browser_computer = computer  # type: ignore[attr-defined]

  agent = build_root_agent(cfg, extra_tools=merged_extra_tools)
  db = session_db_path(cfg)
  db.parent.mkdir(parents=True, exist_ok=True)
  session_service = SqliteSessionService(str(db))

  # ── Plugins ──────────────────────────────────────────────────────────────
  # Recovery plugin first so it can intercept tool errors before terminal hooks.
  plugins = [GemCodeReflectAndRetryToolPlugin(cfg), GemCodeTerminalHooksPlugin(cfg)]

  # Global instruction is now applied via ADK's GlobalInstructionPlugin (the
  # modern replacement for the deprecated LlmAgent.global_instruction field).
  try:
    from google.adk.plugins.global_instruction_plugin import GlobalInstructionPlugin
    plugins.insert(0, GlobalInstructionPlugin(build_global_instruction()))
  except Exception:
    pass

  # Optional: rich YAML debug log (every LLM request/response + tool calls).
  # Enable with: GEMCODE_DEBUG_LOG=1
  if os.environ.get("GEMCODE_DEBUG_LOG", "").lower() in ("1", "true", "yes", "on"):
    try:
      from google.adk.plugins.debug_logging_plugin import DebugLoggingPlugin
      debug_log_path = cfg.project_root / ".gemcode" / "debug.yaml"
      plugins.append(DebugLoggingPlugin(
        output_path=str(debug_log_path),
        include_session_state=True,
      ))
    except Exception:
      pass

  # ── Memory service ────────────────────────────────────────────────────────
  memory_service = None
  if getattr(cfg, "enable_memory", False):
    mem_path = cfg.project_root / ".gemcode" / "memories.jsonl"
    if getattr(cfg, "enable_embeddings", False):
      memory_service = EmbeddingFileMemoryService(
        mem_path, embeddings_model=getattr(cfg, "embeddings_model", None)
      )
    else:
      memory_service = FileMemoryService(mem_path)

  artifact_service = _build_artifact_service(cfg)

  # ── Runner via ADK App (modern pattern) ──────────────────────────────────
  # App is the recommended top-level container as of ADK 1.x.  It owns the
  # plugin list and context-cache config so Runner stays clean.
  # ``plugins=`` on Runner is officially deprecated; using App avoids the
  # DeprecationWarning and enables context caching + future App-level features.
  app = _build_app(agent, plugins, cfg)

  if app is not None:
    runner_kwargs: dict = dict(
        app=app,
        session_service=session_service,
        memory_service=memory_service,
        auto_create_session=True,
    )
  else:
    # Legacy fallback if App is unavailable (very old ADK installs).
    runner_kwargs = dict(
        app_name="gemcode",
        agent=agent,
        session_service=session_service,
        plugins=plugins,
        memory_service=memory_service,
        auto_create_session=True,
    )

  if artifact_service is not None:
    runner_kwargs["artifact_service"] = artifact_service

  return Runner(**runner_kwargs)
