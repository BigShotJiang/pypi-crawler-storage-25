import json
import os
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Union


class TechnicalAnalysis:
    """
    技术分析类 - 适配 Tushare 行情数据

    支持两种初始化方式:
      1. 传入 DataFrame（由 Tushare 直接获取的 df）
      2. 传入 List[Dict]（JSON 序列化后的行情列表）

    数据要求（列名）:
      必须包含: trade_date, open, high, low, close, vol
      可选列:   ts_code, pre_close, change, pct_chg, amount
    """

    def __init__(self, data: Optional[Union[pd.DataFrame, List[Dict]]] = None):
        """
        Args:
            data: Tushare DataFrame 或 List[Dict]，trade_date 为 int 或 str 均可
        """
        self.data = pd.DataFrame()

        if data is None:
            print("警告: 未传入数据")
            return

        if isinstance(data, list):
            self.data = pd.DataFrame(data)
        elif isinstance(data, pd.DataFrame):
            self.data = data.copy()
        else:
            raise TypeError("data 必须是 pd.DataFrame 或 List[Dict]")

        self._process_dataframe()

    # ------------------------------------------------------------------ #
    #  数据预处理                                                           #
    # ------------------------------------------------------------------ #

    def _process_dataframe(self):
        """标准化 DataFrame 格式"""
        if self.data.empty:
            return

        # trade_date: 支持 int(20260303) 或 str("20260303") → datetime
        self.data['trade_date'] = pd.to_datetime(
            self.data['trade_date'].astype(str), format='%Y%m%d'
        )
        self.data = self.data.sort_values('trade_date').reset_index(drop=True)

        # 数值列强制转 float
        num_cols = ['open', 'high', 'low', 'close', 'vol',
                    'pre_close', 'change', 'pct_chg', 'amount']
        for col in num_cols:
            if col in self.data.columns:
                self.data[col] = pd.to_numeric(self.data[col], errors='coerce')

    @classmethod
    def from_json(cls, filepath: str) -> 'TechnicalAnalysis':
        """从 JSON 文件加载"""
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return cls(data)

    # ------------------------------------------------------------------ #
    #  趋势指标                                                             #
    # ------------------------------------------------------------------ #

    def calculate_ma(self, period: int) -> pd.Series:
        """简单移动平均线 SMA"""
        return self.data['close'].rolling(window=period).mean()

    def calculate_ema(self, period: int) -> pd.Series:
        """指数移动平均线 EMA"""
        return self.data['close'].ewm(span=period, adjust=False).mean()

    def calculate_dmi(self, period: int = 14) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """
        DMI 指标，返回 (+DI, -DI, ADX)

        修复:
          - 原版用顺序赋值让 +DM/-DM 互相污染；现改为基于原始值同时判断方向
          - ATR 及 DM 平滑全部使用 Wilder EWM（alpha=1/period）
        """
        high  = self.data['high']
        low   = self.data['low']
        close = self.data['close']

        # 方向动量原始值（未置零）
        up_move   = high.diff()
        down_move = -low.diff()
        raw_plus  = up_move.clip(lower=0)
        raw_minus = down_move.clip(lower=0)

        # 同时判断：哪个方向更大就保留，另一个置零
        condition = raw_plus >= raw_minus
        plus_dm  = raw_plus.where(condition, 0)
        minus_dm = raw_minus.where(~condition, 0)

        # True Range
        tr = pd.concat([
            high - low,
            (high - close.shift()).abs(),
            (low  - close.shift()).abs()
        ], axis=1).max(axis=1)

        # Wilder 平滑
        alpha    = 1.0 / period
        atr      = tr.ewm(alpha=alpha, adjust=False).mean()
        plus_di  = 100 * plus_dm.ewm(alpha=alpha, adjust=False).mean() / atr
        minus_di = 100 * minus_dm.ewm(alpha=alpha, adjust=False).mean() / atr

        dx  = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di)
        adx = dx.ewm(alpha=alpha, adjust=False).mean()

        return plus_di, minus_di, adx

    # ------------------------------------------------------------------ #
    #  动量指标                                                             #
    # ------------------------------------------------------------------ #

    def calculate_rsi(self, period: int = 14) -> pd.Series:
        """
        RSI 相对强弱指数

        修复: 使用 Wilder 平滑（ewm alpha=1/period），与 TradingView 等主流平台一致
        """
        delta = self.data['close'].diff()
        gain  = delta.where(delta > 0, 0.0)
        loss  = (-delta).where(delta < 0, 0.0)

        alpha    = 1.0 / period
        avg_gain = gain.ewm(alpha=alpha, adjust=False).mean()
        avg_loss = loss.ewm(alpha=alpha, adjust=False).mean()

        rs  = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        return rsi

    def calculate_macd(self, fast: int = 12, slow: int = 26,
                       signal: int = 9) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """
        MACD 指标，返回 (DIF, DEA, MACD柱)
        MACD 柱 = (DIF - DEA) × 2（国内主流显示方式）
        """
        ema_fast  = self.data['close'].ewm(span=fast,   adjust=False).mean()
        ema_slow  = self.data['close'].ewm(span=slow,   adjust=False).mean()
        dif       = ema_fast - ema_slow
        dea       = dif.ewm(span=signal, adjust=False).mean()
        histogram = (dif - dea) * 2
        return dif, dea, histogram

    def calculate_kdj(self, n: int = 9,
                      m1: int = 3, m2: int = 3) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """
        KDJ 随机指标，返回 (K, D, J)
        ewm com=m-1 → alpha=1/m，与国内主流平台一致
        """
        low_n  = self.data['low'].rolling(window=n, min_periods=n).min()
        high_n = self.data['high'].rolling(window=n, min_periods=n).max()

        rsv = (self.data['close'] - low_n) / (high_n - low_n) * 100
        k   = rsv.ewm(com=m1 - 1, adjust=False).mean()
        d   = k.ewm(com=m2 - 1,   adjust=False).mean()
        j   = 3 * k - 2 * d
        return k, d, j

    # ------------------------------------------------------------------ #
    #  波动率指标                                                           #
    # ------------------------------------------------------------------ #

    def calculate_bollinger_bands(self, period: int = 20,
                                  std_dev: float = 2.0) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """布林带，返回 (上轨, 中轨, 下轨)"""
        middle = self.data['close'].rolling(window=period).mean()
        std    = self.data['close'].rolling(window=period).std()
        upper  = middle + std * std_dev
        lower  = middle - std * std_dev
        return upper, middle, lower

    def calculate_atr(self, period: int = 14) -> pd.Series:
        """
        ATR 平均真实波幅

        修复: 使用 Wilder 平滑（ewm alpha=1/period），与 TradingView 等主流平台一致
        """
        tr = pd.concat([
            self.data['high'] - self.data['low'],
            (self.data['high'] - self.data['close'].shift()).abs(),
            (self.data['low']  - self.data['close'].shift()).abs()
        ], axis=1).max(axis=1)

        return tr.ewm(alpha=1.0 / period, adjust=False).mean()

    # ------------------------------------------------------------------ #
    #  成交量指标                                                           #
    # ------------------------------------------------------------------ #

    def calculate_obv(self) -> pd.Series:
        """
        OBV 能量潮（向量化实现，避免 for 循环性能问题）
        """
        close     = self.data['close']
        vol       = self.data['vol']
        direction = np.sign(close.diff()).fillna(0)  # type: ignore

        signed_vol      = direction * vol
        signed_vol.iloc[0] = vol.iloc[0]   # 首根 K 线直接取成交量
        return signed_vol.cumsum()

    # ------------------------------------------------------------------ #
    #  价格结构指标                                                         #
    # ------------------------------------------------------------------ #

    def calculate_fibonacci_retracement(self, high: float,
                                        low: float) -> Dict[str, float]:
        """斐波那契回撤位"""
        diff = high - low
        return {
            '0.0':   high,
            '0.236': high - diff * 0.236,
            '0.382': high - diff * 0.382,
            '0.5':   high - diff * 0.5,
            '0.618': high - diff * 0.618,
            '0.786': high - diff * 0.786,
            '1.0':   low
        }

    def find_support_resistance(self, window: int = 5) -> Tuple[List[float], List[float]]:
        """寻找局部支撑/阻力位"""
        highs = self.data['high']
        lows  = self.data['low']

        resistance_levels = []
        for i in range(window, len(highs) - window):
            if all(highs.iloc[i] >= highs.iloc[i - j] for j in range(1, window + 1)) and \
               all(highs.iloc[i] >= highs.iloc[i + j] for j in range(1, window + 1)):
                resistance_levels.append(float(highs.iloc[i]))

        support_levels = []
        for i in range(window, len(lows) - window):
            if all(lows.iloc[i] <= lows.iloc[i - j] for j in range(1, window + 1)) and \
               all(lows.iloc[i] <= lows.iloc[i + j] for j in range(1, window + 1)):
                support_levels.append(float(lows.iloc[i]))

        return support_levels, resistance_levels


    #  一次性计算全部指标                                                   #
    # ------------------------------------------------------------------ #

    def get_all_indicators(self) -> pd.DataFrame:
        """计算所有技术指标，返回完整 DataFrame"""
        if self.data.empty:
            return pd.DataFrame()

        close  = self.data['close']
        volume = self.data['vol']

        df = pd.DataFrame(index=self.data.index)

        # ── 基础价格 ──────────────────────────────────────────────
        df['trade_date'] = self.data['trade_date']
        if 'ts_code' in self.data.columns:
            df['ts_code'] = self.data['ts_code']
        df['open']   = self.data['open']
        df['high']   = self.data['high']
        df['low']    = self.data['low']
        df['close']  = close
        df['volume'] = volume
        if 'amount' in self.data.columns:
            df['amount'] = self.data['amount']

        # ── 趋势 - 移动平均 ───────────────────────────────────────
        for p in [5, 10, 20, 50]:
            df[f'ma{p}'] = self.calculate_ma(p)
        df['ema12'] = self.calculate_ema(12)
        df['ema26'] = self.calculate_ema(26)

        # ── 趋势强度 - DMI ────────────────────────────────────────
        plus_di, minus_di, adx = self.calculate_dmi()
        df['dmi_plus_di']  = plus_di
        df['dmi_minus_di'] = minus_di
        df['dmi_adx']      = adx

        # ── 动量 - RSI ────────────────────────────────────────────
        df['rsi6']  = self.calculate_rsi(6)
        df['rsi14'] = self.calculate_rsi(14)

        # ── 动量 - MACD ───────────────────────────────────────────
        dif, dea, hist = self.calculate_macd()
        df['macd_dif']  = dif
        df['macd_dea']  = dea
        df['macd_hist'] = hist

        # ── 动量 - KDJ ────────────────────────────────────────────
        k, d, j = self.calculate_kdj()
        df['kdj_k'] = k
        df['kdj_d'] = d
        df['kdj_j'] = j

        # ── 波动率 - 布林带 ───────────────────────────────────────
        bb_upper, bb_mid, bb_lower = self.calculate_bollinger_bands()
        df['bb_upper']  = bb_upper
        df['bb_middle'] = bb_mid
        df['bb_lower']  = bb_lower
        df['bb_width']  = (bb_upper - bb_lower) / bb_mid

        # ── 波动率 - ATR ──────────────────────────────────────────
        df['atr14'] = self.calculate_atr(14)

        # ── 成交量 - OBV ──────────────────────────────────────────
        df['obv']          = self.calculate_obv()
        df['volume_ma20']  = volume.rolling(window=20).mean()
        df['volume_chg%']  = volume.pct_change() * 100

        # ── 价格变化 ──────────────────────────────────────────────
        df['price_chg_1%']  = close.pct_change(1)  * 100
        df['price_chg_5%']  = close.pct_change(5)  * 100
        df['price_chg_20%'] = close.pct_change(20) * 100

        return df


def _convert_numpy(obj):
    """递归将所有 numpy 标量转为原生 Python 类型"""
    if isinstance(obj, dict):
        return {k: _convert_numpy(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_convert_numpy(v) for v in obj]
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def get_llm_snapshot(df: pd.DataFrame, recent_n: int = 5) -> dict:
    """接受所有的技术指标, 提取给 LLM 的精简快照，包含信号预处理"""
    latest = df.iloc[-1]
    recent = df.tail(recent_n)

    snapshot = {
        "ts_code": latest.get("ts_code"),
        "date": str(latest["trade_date"])[:10],
        "price": {
            "current":     round(latest["close"], 2),
            "change_1d%":  round(latest["price_chg_1%"], 2),
            "change_5d%":  round(latest["price_chg_5%"], 2),
            "change_20d%": round(latest["price_chg_20%"], 2),
        },
        "trend": {
            "ma5":  round(latest["ma5"],  2),
            "ma20": round(latest["ma20"], 2),
            "ma50": round(latest["ma50"], 2) if pd.notna(latest["ma50"]) else None,
            "ema12_vs_ema26": "golden_cross" if latest["ema12"] > latest["ema26"] else "death_cross",
        },
        "momentum": {
            "rsi14":     round(latest["rsi14"],    1),
            "macd_dif":  round(latest["macd_dif"], 3),
            "macd_dea":  round(latest["macd_dea"], 3),
            "macd_hist": round(latest["macd_hist"],3),
            "kdj_k":     round(latest["kdj_k"],    1),
            "kdj_d":     round(latest["kdj_d"],    1),
            "kdj_j":     round(latest["kdj_j"],    1),
        },
        "volatility": {
            "bb_width": round(latest["bb_width"], 4),
            "atr14":    round(latest["atr14"],    2),
            "price_vs_bb": (
                "above_upper" if latest["close"] > latest["bb_upper"] else
                "below_lower" if latest["close"] < latest["bb_lower"] else
                "inside"
            ),
        },
        "strength": {
            "adx":      round(latest["dmi_adx"],      1),
            "plus_di":  round(latest["dmi_plus_di"],  1),
            "minus_di": round(latest["dmi_minus_di"], 1),
        },
        "volume": {
            "obv_trend":   "up" if recent["obv"].iloc[-1] > recent["obv"].iloc[0] else "down",
            "vol_vs_ma20": round(latest["volume"] / latest["volume_ma20"], 2) if pd.notna(latest["volume_ma20"]) else None,
        },
    }

    # ── 信号预处理：把数字翻译成语义标签 ──────────────────────────
    rsi   = latest["rsi14"]
    kdj_j = latest["kdj_j"]
    adx   = latest["dmi_adx"]
    close = latest["close"]
    ma5   = latest["ma5"]
    ma20  = latest["ma20"]
    ma50  = latest["ma50"] if pd.notna(latest["ma50"]) else None

    snapshot["signals"] = {
        # RSI 超买/超卖
        "rsi_status": (
            "strongly_overbought" if rsi >= 80 else
            "overbought"          if 70 <= rsi < 80 else
            "neutral"             if 30 < rsi < 70 else
            "oversold"            if 20 < rsi <= 30 else
            "strongly_oversold"   if rsi <= 20 else
            "unknown"
        ),

        # MACD 方向与强度
        "macd_status": (
            "bullish_strengthening" if latest["macd_hist"] > 0 and latest["macd_dif"] > latest["macd_dea"] else
            "bullish_weakening"     if latest["macd_hist"] > 0 else
            "bearish_strengthening" if latest["macd_hist"] < 0 and latest["macd_dif"] < latest["macd_dea"] else
            "bearish_weakening"
        ),

        # KDJ 超买/超卖（用 J 值判断，最敏感）
        "kdj_status": (
            "overbought" if kdj_j > 80 else
            "oversold"   if kdj_j < 20 else
            "neutral"
        ),

        # 趋势强度
        "trend_strength": (
            "strong"   if adx > 25 else
            "weak"     if adx < 20 else
            "moderate"
        ),

        # 趋势方向（DMI）
        "trend_direction": (
            "up" if latest["dmi_plus_di"] > latest["dmi_minus_di"] else "down"
        ),

        # 均线多空排列
        "ma_alignment": (
            "bullish" if ma50 and close > ma5 > ma20 > ma50 else  # 空头排列（价格在均线下方）
            "bearish" if ma50 and close < ma5 < ma20 < ma50 else  # 多头排列（价格在均线上方）
            "mixed"                                                 # 均线交织，震荡
        ),

        # 布林带信号
        "bb_signal": (
            "breakout_up"   if latest["close"] > latest["bb_upper"] else
            "breakout_down" if latest["close"] < latest["bb_lower"] else
            "squeeze"       if latest["bb_width"] < 0.1  else      # 带宽极窄，蓄势待发
            "normal"
        ),

        # 成交量信号
        "volume_signal": (
            "heavy_volume" if pd.notna(latest["volume_ma20"]) and latest["volume"] > latest["volume_ma20"] * 1.5 else
            "light_volume" if pd.notna(latest["volume_ma20"]) and latest["volume"] < latest["volume_ma20"] * 0.5 else
            "normal_volume"
        ),

        # OBV 与价格的背离检测（近 recent_n 根）
        "obv_price_divergence": (
            "bullish_divergence" if recent["close"].iloc[-1] < recent["close"].iloc[0]
                                 and recent["obv"].iloc[-1]   > recent["obv"].iloc[0]  else
            "bearish_divergence" if recent["close"].iloc[-1] > recent["close"].iloc[0]
                                 and recent["obv"].iloc[-1]   < recent["obv"].iloc[0]  else
            "no_divergence"
        ),
    }

    return _convert_numpy(snapshot) # pyright: ignore[reportReturnType]