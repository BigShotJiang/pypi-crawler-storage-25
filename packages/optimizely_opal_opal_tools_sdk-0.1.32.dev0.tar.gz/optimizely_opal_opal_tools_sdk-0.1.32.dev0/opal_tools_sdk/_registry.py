"""Internal registry for ToolsService instances."""

from typing import Any

services: list[Any] = []
