from .auth import requires_auth
from .decorators import interaction, resource, tool
from .logging import register_logger_factory
from .models import (
    AuthData,
    AuthRequirement,
    Credentials,
    Environment,
    InteractionContext,
    IslandConfig,
    IslandResponse,
)
from .proteus import UI
from .service import ToolsService

__version__ = "0.1.14-dev"
__all__ = [
    "ToolsService",
    "tool",
    "resource",
    "interaction",
    "requires_auth",
    "register_logger_factory",
    # Models
    "AuthData",
    "AuthRequirement",
    "Credentials",
    "Environment",
    "InteractionContext",
    "IslandConfig",
    "IslandResponse",
    # UI
    "UI",
]
