import inspect
import json
import logging
from collections.abc import Callable
from typing import Any, get_type_hints

from fastapi import APIRouter, FastAPI, HTTPException, Request
from fastapi.routing import APIRoute
from pydantic import BaseModel, ValidationError

from . import _registry
from .models import AuthRequirement, Function, InteractionContext, Parameter
from .proteus import UI, ProteusDocument

logger = logging.getLogger(__name__)


class ToolsService:
    """Main class for managing Opal tools."""

    def __init__(self, app: FastAPI):
        """Initialize the tools service.

        Args:
            app: FastAPI application to attach routes to
        """
        self.app = app
        self.router = APIRouter()
        self.functions: list[Function] = []
        self.interactions: dict[
            str, dict[str, Any]
        ] = {}  # name -> {"handler": fn, "description": str, "parameters": List[Parameter]}
        self.resource_handlers: dict[
            str, tuple[Callable, str | None]
        ] = {}  # URI -> (handler, mime_type)
        self._init_routes()

        # Register in the global registry
        _registry.services.append(self)

        # Debug existing routes
        @app.get("/debug-routes")
        async def debug_routes():
            routes = []
            for route in app.routes:
                if isinstance(route, APIRoute):
                    routes.append(
                        {"path": route.path, "name": route.name, "methods": route.methods}
                    )
            return {"routes": routes}

    def _init_routes(self) -> None:
        """Initialize the discovery and resource endpoints."""

        @self.router.get("/discovery")
        async def discovery() -> dict[str, Any]:
            """Return the discovery information for this tools service."""
            result = {"functions": [f.to_dict() for f in self.functions]}
            return result

        @self.router.post("/resources/read")
        async def read_resource(request: Request) -> dict[str, Any]:
            """Read a resource by URI."""
            try:
                body = await request.json()
                uri = body.get("uri")

                if not uri:
                    raise HTTPException(
                        status_code=400, detail="Missing 'uri' field in request body"
                    )

                resource_tuple = self.resource_handlers.get(uri)
                if not resource_tuple:
                    raise HTTPException(status_code=404, detail=f"Resource not found: {uri}")

                handler, mime_type = resource_tuple

                # Call the handler to get the content
                content = await handler()

                # Check if handler returned a ProteusDocument
                if isinstance(content, ProteusDocument):
                    # Auto-serialize to JSON with proper $type fields
                    text_content = json.dumps(
                        content.model_dump(mode="json", by_alias=True, exclude_none=True)
                    )
                    # Auto-set MIME type if not specified
                    if not mime_type:
                        mime_type = UI.MIME_TYPE
                elif isinstance(content, str):
                    text_content = content
                else:
                    raise HTTPException(
                        status_code=500,
                        detail=(
                            f"Resource handler for '{uri}' must return a str or "
                            f"ProteusDocument, but returned {type(content).__name__}"
                        ),
                    )

                # Return ResourceContent format
                return {"uri": uri, "text": text_content, "mimeType": mime_type or "text/plain"}

            except HTTPException:
                raise
            except Exception as e:
                import traceback

                logger.error(f"Error reading resource: {str(e)}")
                logger.error(traceback.format_exc())
                raise HTTPException(status_code=500, detail=str(e))

        @self.router.post("/interactions/execute")
        async def execute_interaction(request: Request):
            """Execute an interaction by name with parameters."""
            try:
                body = await request.json()
                name = body.get("name")
                parameters = body.get("parameters", {})

                if not name:
                    raise HTTPException(
                        status_code=400, detail="Missing 'name' field in request body"
                    )

                if name not in self.interactions:
                    raise HTTPException(status_code=404, detail=f"Interaction '{name}' not found")

                interaction_info = self.interactions[name]
                handler = interaction_info["handler"]

                # Extract auth data if available
                auth_data = body.get("auth")

                # Build context object
                context = InteractionContext(
                    auth_data=auth_data,
                )

                # Introspect handler signature for Pydantic model (same pattern as tool endpoint)
                sig = inspect.signature(handler)
                type_hints = get_type_hints(handler)

                param_model = None
                for param_name, param in sig.parameters.items():
                    if param_name in type_hints:
                        param_type = type_hints[param_name]
                        if hasattr(param_type, "__fields__") or hasattr(param_type, "model_fields"):
                            param_model = param_type
                            break

                try:
                    if param_model:
                        # Validate and deserialize parameters using the Pydantic model
                        model_instance = param_model(**parameters)
                        result = await handler(model_instance, context)
                    else:
                        # Fall back to raw dict
                        result = await handler(parameters, context)
                    return result
                except ValidationError as e:
                    logger.warning(f"Invalid parameters for interaction '{name}': {str(e)}")
                    raise HTTPException(status_code=400, detail=str(e))
                except Exception as e:
                    logger.error(f"Interaction '{name}' failed: {e}", exc_info=True)
                    raise HTTPException(status_code=500, detail=str(e))

            except HTTPException:
                raise
            except Exception as e:
                import traceback

                logger.error(f"Error executing interaction: {str(e)}")
                logger.error(traceback.format_exc())
                raise HTTPException(status_code=500, detail=str(e))

        # Include router in app
        self.app.include_router(self.router)

    def _extract_auth_requirements(self, handler: Callable) -> list[AuthRequirement]:
        """Extract auth requirements from a handler function decorated with @requires_auth.

        Args:
            handler: The handler function

        Returns:
            List of AuthRequirement objects
        """
        auth_requirements = []

        # Check if the function is wrapped with @requires_auth
        if hasattr(handler, "__auth_requirements__"):
            # Auth requirements should always be a list
            if isinstance(handler.__auth_requirements__, list):
                for req in handler.__auth_requirements__:
                    auth_requirements.append(
                        AuthRequirement(
                            provider=req.get("provider", ""),
                            scope_bundle=req.get("scope_bundle", ""),
                            required=req.get("required", True),
                        )
                    )

        return auth_requirements

    def register_tool(
        self,
        name: str,
        description: str,
        handler: Callable,
        parameters: list[Parameter],
        endpoint: str,
        auth_requirements: list[AuthRequirement] | None = None,
        ui_resource: str | None = None,
    ) -> None:
        """Register a tool function.

        Args:
            name: Name of the tool
            description: Description of the tool
            handler: Function that implements the tool
            parameters: List of parameters for the tool
            endpoint: API endpoint for the tool
            auth_requirements: List of authentication requirements (optional)
            ui_resource: URI of associated UI resource for dynamic rendering (optional)
        """
        logger.info(f"Registering tool: {name} with endpoint: {endpoint}")

        # Validate name uniqueness across tools and interactions
        if name in self.interactions:
            raise ValueError(
                f"Tool name '{name}' conflicts with an existing interaction name. "
                "Tool and interaction names must be unique because both are exported as MCP tools."
            )

        # Extract auth requirements from handler if decorated with @requires_auth
        handler_auth_requirements = self._extract_auth_requirements(handler)

        # If auth_requirements is explicitly provided, it takes precedence
        # Otherwise, use the requirements extracted from the handler
        final_auth_requirements = (
            auth_requirements if auth_requirements else handler_auth_requirements
        )

        function = Function(
            name=name,
            description=description,
            parameters=parameters,
            endpoint=endpoint,
            auth_requirements=final_auth_requirements,
            ui_resource=ui_resource,
        )

        self.functions.append(function)

        # Create a direct route with the app for better control
        @self.app.post(endpoint)
        async def tool_endpoint(request: Request):
            try:
                # Parse JSON body
                body = await request.json()
                logger.info(f"Received request for {endpoint} with body: {body}")

                # Parameters should be in the "parameters" key according to the spec
                # This matches how the tools-mgmt-service calls tools
                if "parameters" in body:
                    params = body["parameters"]
                else:
                    # For backward compatibility with direct test calls
                    logger.warning(
                        "Warning: 'parameters' key not found in request body. Using body directly."
                    )
                    params = body

                # Extract auth data if available
                auth_data = body.get("auth")
                if auth_data:
                    logger.info(
                        f"Auth data provided for provider: {auth_data.get('provider', 'unknown')}"
                    )

                # Extract environment data if available
                environment = body.get("environment", {})
                if environment:
                    logger.info(f"Environment data provided: {environment}")

                logger.info(f"Extracted parameters: {params}")

                # Get the parameter model from handler's signature
                sig = inspect.signature(handler)
                param_name = list(sig.parameters.keys())[0]
                param_type = get_type_hints(handler).get(param_name)

                args = []
                kwargs = {}
                if param_type:
                    # Create instance of param model
                    model_instance = param_type(**params)
                    args.append(model_instance)
                else:
                    # Fall back if type hints not available
                    args.append(BaseModel(**params))

                # Check signature to see if it accepts other values

                # TODO: Change this to "auth"
                if auth_param := sig.parameters.get("auth_data"):
                    kwargs[auth_param.name] = auth_data

                if environment_param := sig.parameters.get("environment"):
                    kwargs[environment_param.name] = environment

                result = await handler(*args, **kwargs)

                logger.info(f"Tool {name} returned: {result}")

                return result
            except ValidationError as e:
                logger.warning(f"Invalid parameters predicted by LLM for tool {name}: {str(e)}")
                raise HTTPException(status_code=400, detail=str(e))
            except HTTPException:
                raise
            except Exception as e:
                import traceback

                logger.error(f"Error in tool {name}: {str(e)}")
                logger.error(traceback.format_exc())
                raise HTTPException(status_code=500, detail=str(e))

        # Update the route function name and docstring
        tool_endpoint.__name__ = f"tool_{name}"
        tool_endpoint.__doc__ = description

    def register_resource(
        self,
        uri: str,
        name: str,
        description: str | None,
        mime_type: str | None,
        title: str | None,
        handler: Callable,
    ) -> None:
        """Register a resource function.

        Args:
            uri: The unique URI for this resource
            name: Name of the resource
            description: Description of the resource (optional)
            mime_type: MIME type of the resource content (optional)
            title: Human-readable title for the resource (optional)
            handler: Function that implements the resource (returns str)
        """
        logger.info(f"Registering resource: {name} with URI: {uri}")

        # Store the handler and mime_type as a tuple
        self.resource_handlers[uri] = (handler, mime_type)

    def register_interaction(
        self,
        name: str,
        description: str,
        handler: Callable,
        parameters: list[Parameter] | None = None,
    ) -> None:
        """Register an interaction handler.

        Args:
            name: Name of the interaction. Must be unique across both tools and interactions.
            description: Description of the interaction
            handler: Async function that handles the interaction.
                     Signature: async def handler(
                     parameters: Model|dict,
                     context: InteractionContext) -> dict
            parameters: Parameter definitions extracted from the handler's Pydantic model

        Raises:
            ValueError: If the name conflicts with an existing tool or interaction name.
        """
        # Validate name uniqueness across tools and interactions
        tool_names = {f.name for f in self.functions}
        if name in tool_names:
            raise ValueError(
                f"Interaction name '{name}' conflicts with an existing tool name. "
                "Tool and interaction names must be unique because both are exported as MCP tools."
            )
        if name in self.interactions:
            raise ValueError(f"Interaction '{name}' is already registered.")

        self.interactions[name] = {
            "handler": handler,
            "description": description,
            "parameters": parameters or [],
        }
        logger.info(f"Registered interaction: {name}")
