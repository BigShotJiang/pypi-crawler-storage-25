from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal, TypedDict

from pydantic import BaseModel, Field


class ParameterType(str, Enum):
    """Types of parameters supported by Opal tools."""

    string = "string"
    integer = "integer"
    number = "number"
    boolean = "boolean"
    list = "array"  # Changed to match main service expectation
    dictionary = "object"  # Standard JSON schema type


@dataclass
class Parameter:
    """Parameter definition for an Opal tool."""

    name: str
    param_type: ParameterType
    description: str
    required: bool
    in_context: bool = False
    schema: dict[str, Any] | None = field(default=None)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for the discovery endpoint."""
        result: dict[str, Any] = {
            "name": self.name,
            "type": self.param_type.value,
            "description": self.description,
            "required": self.required,
            "in_context": self.in_context,
        }
        if self.schema is not None:
            result["schema"] = self.schema
        return result


@dataclass
class AuthRequirement:
    """Authentication requirements for an Opal tool."""

    provider: str  # e.g., "google", "microsoft"
    scope_bundle: str  # e.g., "calendar", "drive"
    required: bool = True

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for the discovery endpoint."""
        return {
            "provider": self.provider,
            "scope_bundle": self.scope_bundle,
            "required": self.required,
        }


class Credentials(TypedDict):
    """AuthData credentials."""

    access_token: str
    org_sso_id: str | None
    customer_id: str
    instance_id: str
    product_sku: str


class AuthData(TypedDict):
    """Authentication data for an Opal tool."""

    provider: str
    credentials: Credentials


@dataclass
class InteractionContext:
    """Context object passed to interaction handlers."""

    auth_data: AuthData | None = None


class Environment(TypedDict):
    """Execution environment for an Opal tool.

    Interactive mode provides interaction islands, while headless does not.
    """

    execution_mode: Literal["headless", "interactive"]


@dataclass
class Function:
    """Function definition for an Opal tool."""

    name: str
    description: str
    parameters: list[Parameter]
    endpoint: str
    auth_requirements: list[AuthRequirement] | None = None
    http_method: str = "POST"
    ui_resource: str | None = None  # UI resource URI for dynamic UI rendering

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for the discovery endpoint."""
        result = {
            "name": self.name,
            "description": self.description,
            "parameters": [p.to_dict() for p in self.parameters],
            "endpoint": self.endpoint,
            "http_method": self.http_method,
        }

        if self.auth_requirements:
            result["auth_requirements"] = [auth.to_dict() for auth in self.auth_requirements]

        if self.ui_resource:
            result["ui_resource"] = self.ui_resource

        return result


# Interaction island related classes
class IslandConfig(BaseModel):
    class Field(BaseModel):
        name: str
        label: str
        type: Literal["string", "boolean", "json"]
        value: str = Field(default="")
        hidden: bool = Field(default=False)
        options: list[str] = Field(default=[])

    class Action(BaseModel):
        name: str
        label: str
        type: str
        endpoint: str
        operation: str = Field(default="create")

    fields: list[Field]
    actions: list[Action]
    type: str | None = None
    icon: str | None = None


class IslandResponse(BaseModel):
    class ResponseConfig(BaseModel):
        islands: list[IslandConfig]

    type: Literal["island"]
    config: ResponseConfig
    message: str | None = None

    @classmethod
    def create(cls, islands: list[IslandConfig], message: str | None = None):
        return cls(type="island", config=cls.ResponseConfig(islands=islands), message=message)
