"""Tests for nested schema extraction from Pydantic models in the @tool decorator."""

from enum import Enum

from pydantic import BaseModel, Field

from opal_tools_sdk.decorators import _resolve_json_schema
from opal_tools_sdk.models import Parameter, ParameterType


class OutputFormat(str, Enum):
    markdown = "markdown"
    raw = "raw"


class BrowseWebUrlItem(BaseModel):
    url: str = Field(description="The webpage URL to browse.")
    information_needed: str | None = Field(default=None, description="What information to extract")
    output_format: OutputFormat | None = Field(default=None, description="Output format")


class SimpleItem(BaseModel):
    name: str = Field(description="Item name")
    count: int = Field(description="Item count")


class TestResolveJsonSchema:
    """Tests for _resolve_json_schema helper."""

    def test_simple_object(self):
        schema = SimpleItem.model_json_schema()
        defs = schema.pop("$defs", {})
        resolved = _resolve_json_schema(schema, defs)
        assert resolved["type"] == "object"
        assert resolved["properties"]["name"] == {
            "type": "string",
            "description": "Item name",
        }
        assert resolved["properties"]["count"] == {
            "type": "integer",
            "description": "Item count",
        }
        assert resolved["required"] == ["name", "count"]

    def test_optional_field_simplified(self):
        schema = BrowseWebUrlItem.model_json_schema()
        defs = schema.pop("$defs", {})
        resolved = _resolve_json_schema(schema, defs)
        info = resolved["properties"]["information_needed"]
        assert info["type"] == "string"
        assert "description" in info

    def test_enum_ref_resolved(self):
        schema = BrowseWebUrlItem.model_json_schema()
        defs = schema.pop("$defs", {})
        resolved = _resolve_json_schema(schema, defs)
        fmt = resolved["properties"]["output_format"]
        assert fmt["type"] == "string"
        assert fmt["enum"] == ["markdown", "raw"]

    def test_required_fields(self):
        schema = BrowseWebUrlItem.model_json_schema()
        defs = schema.pop("$defs", {})
        resolved = _resolve_json_schema(schema, defs)
        assert resolved["required"] == ["url"]

    def test_ref_resolution(self):
        defs = {"MyType": {"type": "string", "enum": ["a", "b"]}}
        schema = {"$ref": "#/$defs/MyType"}
        resolved = _resolve_json_schema(schema, defs)
        assert resolved == {"type": "string", "enum": ["a", "b"]}

    def test_strips_title(self):
        schema = {"type": "object", "title": "SomeModel", "properties": {}}
        resolved = _resolve_json_schema(schema, {})
        assert "title" not in resolved

    def test_ref_preserves_sibling_description(self):
        """$ref with sibling description should preserve the description."""
        defs = {"Inner": {"type": "object", "properties": {"x": {"type": "string"}}}}
        schema = {"$ref": "#/$defs/Inner", "description": "My inner object"}
        resolved = _resolve_json_schema(schema, defs)
        assert resolved["description"] == "My inner object"
        assert resolved["type"] == "object"

    def test_circular_ref_does_not_crash(self):
        """Self-referential $ref should not cause infinite recursion."""
        defs = {
            "TreeNode": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "children": {"type": "array", "items": {"$ref": "#/$defs/TreeNode"}},
                },
            }
        }
        schema = {"$ref": "#/$defs/TreeNode"}
        resolved = _resolve_json_schema(schema, defs)
        assert resolved["type"] == "object"
        # The circular ref should be broken with {type: object}
        assert resolved["properties"]["children"]["items"]["type"] == "object"

    def test_anyof_with_multiple_non_null_types(self):
        """Union[str, int] should fall back to string."""
        schema = {
            "anyOf": [{"type": "string"}, {"type": "integer"}],
            "description": "A union field",
        }
        resolved = _resolve_json_schema(schema, {})
        assert resolved == {"type": "string", "description": "A union field"}


class TestParameterToDict:
    """Tests for Parameter.to_dict with schema field."""

    def test_to_dict_with_array_schema(self):
        param = Parameter(
            name="urls",
            param_type=ParameterType.list,
            description="URLs",
            required=True,
            schema={
                "type": "array",
                "description": "URLs",
                "items": {"type": "object", "properties": {"url": {"type": "string"}}},
            },
        )
        d = param.to_dict()
        assert d["schema"]["type"] == "array"
        assert d["schema"]["items"]["properties"]["url"] == {"type": "string"}

    def test_to_dict_with_object_schema(self):
        param = Parameter(
            name="config",
            param_type=ParameterType.dictionary,
            description="Config",
            required=True,
            schema={
                "type": "object",
                "properties": {"name": {"type": "string"}},
                "required": ["name"],
            },
        )
        d = param.to_dict()
        assert d["schema"]["properties"]["name"] == {"type": "string"}
        assert d["schema"]["required"] == ["name"]

    def test_to_dict_without_schema(self):
        """Backward compat: no schema key when None."""
        param = Parameter(
            name="query",
            param_type=ParameterType.string,
            description="Search",
            required=True,
        )
        d = param.to_dict()
        assert "schema" not in d

    def test_schema_is_complete_json_schema(self):
        """schema field must be a complete, self-contained JSON Schema."""
        param = Parameter(
            name="urls",
            param_type=ParameterType.list,
            description="URLs to browse",
            required=True,
            schema={
                "type": "array",
                "description": "URLs to browse",
                "items": {
                    "type": "object",
                    "properties": {
                        "url": {"type": "string", "description": "The URL"},
                    },
                    "required": ["url"],
                },
            },
        )
        d = param.to_dict()
        schema = d["schema"]
        # Schema is self-contained: includes type and description
        assert schema["type"] == "array"
        assert schema["description"] == "URLs to browse"
        assert schema["items"]["type"] == "object"
        assert schema["items"]["required"] == ["url"]


class TestToolDecoratorNestedExtraction:
    """Tests for the @tool decorator extracting nested schemas from Pydantic models."""

    def test_list_of_pydantic_model(self):
        """Simulates what the decorator does for List[BaseModel] fields."""
        raw = SimpleItem.model_json_schema()
        defs = raw.pop("$defs", {})
        items_schema = _resolve_json_schema(raw, defs)
        assert items_schema["type"] == "object"
        assert "name" in items_schema["properties"]
        assert "count" in items_schema["properties"]

    def test_list_of_str_schema(self):
        """List[str] should produce a complete array schema."""
        param = Parameter(
            name="tags",
            param_type=ParameterType.list,
            description="Tags",
            required=False,
            schema={"type": "array", "description": "Tags", "items": {"type": "string"}},
        )
        d = param.to_dict()
        assert d["schema"]["type"] == "array"
        assert d["schema"]["items"] == {"type": "string"}

    def test_browse_web_url_item_full(self):
        """Full integration test with BrowseWebUrlItem model."""
        raw = BrowseWebUrlItem.model_json_schema()
        defs = raw.pop("$defs", {})
        items_schema = _resolve_json_schema(raw, defs)

        assert items_schema["type"] == "object"
        assert items_schema["properties"]["url"]["type"] == "string"
        assert items_schema["properties"]["information_needed"]["type"] == "string"
        assert items_schema["properties"]["output_format"]["enum"] == ["markdown", "raw"]
        assert items_schema["required"] == ["url"]

        # Build the complete schema as the decorator would
        full_schema = {"type": "array", "description": "URLs to browse", "items": items_schema}
        param = Parameter(
            name="urls",
            param_type=ParameterType.list,
            description="URLs to browse",
            required=True,
            schema=full_schema,
        )
        d = param.to_dict()
        assert d["schema"]["type"] == "array"
        assert d["schema"]["items"]["type"] == "object"
        assert "url" in d["schema"]["items"]["properties"]
        # Uses standard "required" key, not "required_properties"
        assert d["schema"]["items"]["required"] == ["url"]
