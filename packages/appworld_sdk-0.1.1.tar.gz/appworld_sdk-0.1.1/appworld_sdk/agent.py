"""Base agent protocol for client-side eval loops."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

import numpy as np


@runtime_checkable
class BaseAgent(Protocol):
    """Agent that decides actions based on observations.

    Users implement this protocol to plug in custom models.
    The SDK never imports any specific LLM provider — that's the
    user's responsibility.

    Example::

        class MyAgent:
            def predict(self, *, screenshot, goal, **kw) -> dict:
                # call your own model
                return {"action_type": 0, "x": 0.5, "y": 0.5, ...}
    """

    def predict(
        self,
        *,
        screenshot: np.ndarray,
        goal: str,
        task_name: str,
        task_description: str,
        app_names: list[str],
        step_index: int,
        max_steps: int,
        history: list[str],
    ) -> dict[str, Any]:
        """Return an action dict.

        Expected keys: action_type, x, y, text, direction, app_name.
        Optional key: description (used for history logging).
        """
        ...
