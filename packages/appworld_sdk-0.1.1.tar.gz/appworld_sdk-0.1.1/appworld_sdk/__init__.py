"""App World SDK — lightweight client for RL & Eval on the App World platform.

Install: ``pip install appworld-sdk``

Dependencies: requests, numpy, Pillow, gymnasium (no platform internals).
"""

from appworld_sdk.agent import BaseAgent
from appworld_sdk.client import (
    AppWorldClient,
    LocalEvalBatchResult,
    LocalEvalResult,
    RunResult,
)
from appworld_sdk.env import RemoteAppWorldEnv, RemoteAppWorldEvalEnv
from appworld_sdk.errors import (
    AppWorldAPIError,
    AppWorldError,
    EnvironmentNotReady,
    SessionExpired,
)

__all__ = [
    "AppWorldClient",
    "BaseAgent",
    "RemoteAppWorldEnv",
    "RemoteAppWorldEvalEnv",
    "RunResult",
    "LocalEvalResult",
    "LocalEvalBatchResult",
    "AppWorldError",
    "AppWorldAPIError",
    "EnvironmentNotReady",
    "SessionExpired",
]
