"""Remote Gymnasium-compatible environments backed by the App World API.

The env is bound to an *environment* (device/container resources),
NOT to a specific task.  ``task_name`` is passed at ``reset()`` time,
so one env object can run multiple tasks sequentially — the typical
multi-task eval workflow.
"""

from __future__ import annotations

import base64
from io import BytesIO
from typing import Any

import numpy as np
import requests
from PIL import Image
from gymnasium import spaces

from appworld_sdk.errors import AppWorldAPIError, EnvironmentNotReady, SessionExpired


def _decode_data_url_png(data_url: str) -> np.ndarray:
    _, payload = data_url.split(",", 1)
    binary = base64.b64decode(payload)
    return np.array(Image.open(BytesIO(binary)).convert("RGB"))


def _raise_for_status(response: requests.Response) -> None:
    """Convert HTTP errors to SDK exceptions."""
    if response.ok:
        return
    detail = ""
    try:
        body = response.json()
        detail = body.get("detail", "")
    except Exception:
        detail = response.text[:200]
    if response.status_code == 503:
        raise EnvironmentNotReady("unknown", detail=detail)
    if response.status_code == 410:
        raise SessionExpired("unknown", detail=detail)
    raise AppWorldAPIError(
        detail or response.reason or "API error",
        status_code=response.status_code,
        detail=detail,
    )


class _RemoteBaseEnv:
    """Shared HTTP plumbing for remote environments."""

    def __init__(
        self,
        api_key: str,
        base_url: str,
        env_id: str,
        env_type: str,
        timeout: float = 180.0,
        run_id: str | None = None,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.env_id = env_id
        self.env_type = env_type
        self.timeout = timeout
        self.session_id: str | None = None
        self.current_task: str | None = None
        # Consumed on the first reset() and then cleared so subsequent
        # episodes don't try to re-bind to an already-running run.
        self._pending_run_id: str | None = run_id

    @property
    def headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        response = requests.post(
            f"{self.base_url}{path}",
            headers=self.headers,
            json=payload,
            timeout=self.timeout,
        )
        _raise_for_status(response)
        return response.json()

    def close(self) -> None:
        if self.session_id is None:
            return
        try:
            self._post("/api/v1/sdk/env/close", {"session_id": self.session_id})
        except Exception:
            pass
        self.session_id = None
        self.current_task = None


class RemoteAppWorldEnv(_RemoteBaseEnv):
    """RL environment (5 discrete actions, screenshot observation)."""

    def __init__(self, api_key: str, base_url: str, env_id: str, run_id: str | None = None):
        super().__init__(
            api_key=api_key, base_url=base_url, env_id=env_id, env_type="rl", run_id=run_id,
        )
        # Default to native Android portrait resolution (1080x2400). 第一次 reset
        # 如果实际帧形状不同 (web=1280x720 / 自定义 driver), 会自适应改写 space.
        self.observation_space = spaces.Box(low=0, high=255, shape=(2400, 1080, 3), dtype=np.uint8)
        self.action_space = spaces.MultiDiscrete([5, 100, 100, 4])
        self._obs_space_locked = False

    def _maybe_align_observation_space(self, obs: np.ndarray) -> None:
        """First-frame guard: 如果服务端实际返回的 obs shape 跟声明不一致,
        以实际 shape 为准重写 observation_space, 让 sb3/RLlib 等下游框架
        预分配 buffer 时拿到正确维度. 锁一次, 后续不再改."""
        if self._obs_space_locked:
            return
        if obs.shape != self.observation_space.shape:
            self.observation_space = spaces.Box(
                low=0, high=255, shape=obs.shape, dtype=np.uint8,
            )
        self._obs_space_locked = True

    def reset(
        self,
        *,
        task_name: str,
        seed: int | None = None,
        options: dict | None = None,
    ) -> tuple[np.ndarray, dict]:
        # Close previous session if any
        self.close()

        reset_payload: dict[str, Any] = {
            "env_id": self.env_id,
            "task_name": task_name,
            "env_type": "rl",
        }
        if self._pending_run_id is not None:
            reset_payload["run_id"] = self._pending_run_id
            self._pending_run_id = None
        payload = self._post("/api/v1/sdk/env/reset", reset_payload)
        self.session_id = payload["session_id"]
        self.current_task = task_name
        obs = _decode_data_url_png(payload["observation"])
        self._maybe_align_observation_space(obs)
        return obs, payload["info"]

    def step(self, action: np.ndarray) -> tuple[np.ndarray, float, bool, bool, dict]:
        if self.session_id is None:
            raise RuntimeError("reset() must be called before step()")
        payload = self._post("/api/v1/sdk/env/step", {
            "session_id": self.session_id,
            "action": np.asarray(action).tolist(),
        })
        obs = _decode_data_url_png(payload["observation"])
        self._maybe_align_observation_space(obs)
        return (
            obs,
            float(payload["reward"]),
            bool(payload["terminated"]),
            bool(payload["truncated"]),
            payload["info"],
        )


class RemoteAppWorldEvalEnv(_RemoteBaseEnv):
    """Eval environment (7 actions incl. text input, dict observation)."""

    def __init__(self, api_key: str, base_url: str, env_id: str, run_id: str | None = None):
        super().__init__(
            api_key=api_key, base_url=base_url, env_id=env_id, env_type="eval", run_id=run_id,
        )
        # Default to native Android portrait resolution (1080x2400). 第一次 reset
        # 如果实际帧形状不同会自适应改写 screenshot 子 space (见 _maybe_align_observation_space).
        self.observation_space = spaces.Dict({
            "screenshot": spaces.Box(low=0, high=255, shape=(2400, 1080, 3), dtype=np.uint8),
            "goal": spaces.Text(max_length=500),
        })
        self.action_space = spaces.Dict({
            "action_type": spaces.Discrete(7),
            "x": spaces.Box(0.0, 1.0, shape=(), dtype=np.float32),
            "y": spaces.Box(0.0, 1.0, shape=(), dtype=np.float32),
            "text": spaces.Text(max_length=200),
            "direction": spaces.Discrete(4),
        })
        self._obs_space_locked = False

    def _maybe_align_observation_space(self, obs: dict[str, Any]) -> None:
        if self._obs_space_locked:
            return
        screenshot = obs.get("screenshot")
        if screenshot is None:
            return
        actual_shape = screenshot.shape
        screen_space = self.observation_space["screenshot"]
        if actual_shape != screen_space.shape:
            new_screen = spaces.Box(low=0, high=255, shape=actual_shape, dtype=np.uint8)
            self.observation_space = spaces.Dict({
                **{k: v for k, v in self.observation_space.spaces.items() if k != "screenshot"},
                "screenshot": new_screen,
            })
        self._obs_space_locked = True

    def reset(
        self,
        *,
        task_name: str,
        seed: int | None = None,
        options: dict | None = None,
    ) -> tuple[dict[str, Any], dict]:
        # Close previous session if any
        self.close()

        reset_payload: dict[str, Any] = {
            "env_id": self.env_id,
            "task_name": task_name,
            "env_type": "eval",
        }
        if self._pending_run_id is not None:
            reset_payload["run_id"] = self._pending_run_id
            self._pending_run_id = None
        payload = self._post("/api/v1/sdk/env/reset", reset_payload)
        self.session_id = payload["session_id"]
        self.current_task = task_name
        obs = self._unpack_observation(payload["observation"])
        self._maybe_align_observation_space(obs)
        return obs, payload["info"]

    def step(self, action: dict[str, Any]) -> tuple[dict[str, Any], float, bool, bool, dict]:
        if self.session_id is None:
            raise RuntimeError("reset() must be called before step()")
        payload = self._post("/api/v1/sdk/env/step", {
            "session_id": self.session_id,
            "action": action,
        })
        obs = self._unpack_observation(payload["observation"])
        self._maybe_align_observation_space(obs)
        return (
            obs,
            float(payload["reward"]),
            bool(payload["terminated"]),
            bool(payload["truncated"]),
            payload["info"],
        )

    @staticmethod
    def _unpack_observation(observation: dict[str, Any]) -> dict[str, Any]:
        out: dict[str, Any] = {
            "screenshot": _decode_data_url_png(observation["screenshot"]),
            "goal": observation["goal"],
        }
        # Optional fields the server may include for richer agent grounding.
        # `ui_elements` is the UIAutomator dump (Android); when present, callers
        # can drive the SoM/index path of generate_vision_action instead of the
        # pixel-coord fallback. Empty list = server opted out (RL fast path).
        if "ui_elements" in observation:
            out["ui_elements"] = observation["ui_elements"] or []
        if observation.get("focus"):
            out["focus"] = observation["focus"]
        if isinstance(observation.get("structured"), dict):
            out["structured"] = observation["structured"]
        return out
