"""HTTP client for the App World platform.

This is a pure API client — it knows nothing about tasks, adapters,
rewards, or LLM providers.  All heavy lifting happens on the platform
side; the client just sends HTTP requests and returns results.
"""

from __future__ import annotations

import base64
import logging
import time
from dataclasses import dataclass, field
from io import BytesIO
from typing import Any

import numpy as np
import requests
from PIL import Image

from appworld_sdk.agent import BaseAgent
from appworld_sdk.env import RemoteAppWorldEnv, RemoteAppWorldEvalEnv
from appworld_sdk.errors import (
    AppWorldAPIError,
    EnvironmentNotReady,
    SessionExpired,
)

logger = logging.getLogger(__name__)


def _decode_screenshot(data_url: str) -> np.ndarray:
    """Decode a data:image/... URL into an RGB numpy array."""
    _, payload = data_url.split(",", 1)
    binary = base64.b64decode(payload)
    return np.array(Image.open(BytesIO(binary)).convert("RGB"))


# ---------------------------------------------------------------------------
# Result data classes
# ---------------------------------------------------------------------------


@dataclass
class RunResult:
    id: str
    name: str
    status: str
    type: str
    environment_id: str
    success_rate: float | None
    avg_steps: float | None
    results: list[dict[str, Any]]
    raw: dict[str, Any]


@dataclass
class LocalEvalResult:
    """Result of a single-task client-side eval."""

    task_name: str
    status: str
    steps: int
    reward: float
    history: list[str]
    terminated: bool
    truncated: bool


@dataclass
class LocalEvalBatchResult:
    """Aggregated result of a multi-task local eval."""

    task_results: list[LocalEvalResult] = field(default_factory=list)

    @property
    def success_rate(self) -> float:
        if not self.task_results:
            return 0.0
        return sum(1 for r in self.task_results if r.status == "completed") / len(
            self.task_results
        )

    @property
    def avg_steps(self) -> float:
        if not self.task_results:
            return 0.0
        return sum(r.steps for r in self.task_results) / len(self.task_results)


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------


class AppWorldClient:
    """Thin API client for the App World platform.

    Usage::

        client = AppWorldClient(api_key="sk-xxx", base_url="https://api.appworld.dev")

        # Browse catalog
        tasks = client.list_tasks()

        # Create environment (allocates device resources)
        env_info = client.create_environment(
            task_ids=["FennoteCreateNote", "FennoteDeleteNote"],
        )
        env_id = env_info["id"]

        # Get a Gymnasium-compatible env (bound to environment, NOT to a task)
        env = client.make_env(env_id=env_id, env_type="eval")

        # Run multiple tasks on the same environment
        for task in ["FennoteCreateNote", "FennoteDeleteNote"]:
            obs, info = env.reset(task_name=task)
            done = False
            while not done:
                action = my_agent.predict(screenshot=obs["screenshot"], goal=obs["goal"], ...)
                obs, reward, terminated, truncated, info = env.step(action)
                done = terminated or truncated

        env.close()
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "http://127.0.0.1:8000",
        timeout: float = 60.0,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    @property
    def headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    def _raise_for_status(self, response: requests.Response) -> None:
        if response.ok:
            return
        detail = ""
        try:
            body = response.json()
            detail = body.get("detail", "")
        except Exception:
            detail = response.text[:200]
        if response.status_code == 503:
            raise EnvironmentNotReady("unknown", detail=detail)
        if response.status_code == 410:
            raise SessionExpired("unknown", detail=detail)
        raise AppWorldAPIError(
            detail or response.reason or "API error",
            status_code=response.status_code,
            detail=detail,
        )

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        response = requests.get(
            f"{self.base_url}{path}",
            headers=self.headers,
            params=params,
            timeout=self.timeout,
        )
        self._raise_for_status(response)
        return response.json()

    def _post(self, path: str, payload: dict[str, Any]) -> Any:
        response = requests.post(
            f"{self.base_url}{path}",
            headers=self.headers,
            json=payload,
            timeout=self.timeout,
        )
        self._raise_for_status(response)
        return response.json()

    def _delete(self, path: str) -> Any:
        response = requests.delete(
            f"{self.base_url}{path}",
            headers=self.headers,
            timeout=self.timeout,
        )
        self._raise_for_status(response)
        return response.json()

    # ------------------------------------------------------------------
    # Catalog
    # ------------------------------------------------------------------

    def list_apps(self, **filters: Any) -> list[dict[str, Any]]:
        return self._get("/api/v1/apps", params=filters)["items"]

    def list_tasks(self, **filters: Any) -> list[dict[str, Any]]:
        return self._get("/api/v1/tasks", params=filters)["items"]

    def get_task(self, task_id: str) -> dict[str, Any]:
        return self._get(f"/api/v1/tasks/{task_id}")

    def run_quickstart(
        self,
        task_id: str | None = None,
        agent: str = "echo",
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"agent": agent}
        if task_id is not None:
            payload["task_id"] = task_id
        return self._post("/api/v1/quickstart/run", payload)

    # ------------------------------------------------------------------
    # Environments
    # ------------------------------------------------------------------

    def list_environments(self, **filters: Any) -> list[dict[str, Any]]:
        return self._get("/api/v1/environments", params=filters)["items"]

    def create_environment(
        self,
        task_ids: list[str],
        name: str | None = None,
    ) -> dict[str, Any]:
        payload = {"task_ids": task_ids, "name": name or "sdk-environment"}
        return self._post("/api/v1/environments", payload)

    def get_environment(self, env_id: str) -> dict[str, Any]:
        return self._get(f"/api/v1/environments/{env_id}")

    def delete_environment(self, env_id: str) -> dict[str, Any]:
        return self._delete(f"/api/v1/environments/{env_id}")

    def get_environment_status(self, env_id: str) -> dict[str, Any]:
        return self._get(f"/api/v1/environments/{env_id}/status")

    def stop_environment(self, env_id: str) -> dict[str, Any]:
        return self._post(f"/api/v1/environments/{env_id}/stop", {})

    def restart_environment(self, env_id: str) -> dict[str, Any]:
        return self._post(f"/api/v1/environments/{env_id}/restart", {})

    def heartbeat_environment(self, env_id: str) -> dict[str, Any]:
        """Push the v2 lease idle deadline forward.

        Only available for environments provisioned under
        ``APP_WORLD_PERSONAL_ENV_V2_ENABLED`` (provisioning_mode=v2_lease).
        Call periodically (e.g. every ``idle_timeout_s/3``) during long
        training/eval runs that may go quiet between SDK calls — otherwise
        the reconcile worker will reclaim the sandbox after idle_timeout_s.
        """
        return self._post(f"/api/v1/environments/{env_id}/heartbeat", {})

    # ------------------------------------------------------------------
    # Low-level SDK env endpoints (for advanced usage)
    # ------------------------------------------------------------------

    def sdk_reset(
        self,
        *,
        env_id: str,
        task_name: str,
        env_type: str = "eval",
        run_id: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "env_id": env_id,
            "task_name": task_name,
            "env_type": env_type,
        }
        if run_id is not None:
            payload["run_id"] = run_id
        return self._post("/api/v1/sdk/env/reset", payload)

    def sdk_step(self, *, session_id: str, action: Any) -> dict[str, Any]:
        return self._post("/api/v1/sdk/env/step", {
            "session_id": session_id,
            "action": action,
        })

    def sdk_close(self, *, session_id: str) -> dict[str, Any]:
        return self._post("/api/v1/sdk/env/close", {"session_id": session_id})

    # ------------------------------------------------------------------
    # Gymnasium-compatible remote environment
    # ------------------------------------------------------------------

    def make_env(
        self,
        *,
        env_id: str,
        env_type: str = "eval",
        run_id: str | None = None,
    ) -> RemoteAppWorldEnv | RemoteAppWorldEvalEnv:
        """Create a Gymnasium-compatible remote environment.

        The env is bound to an environment (device resources), NOT to a
        specific task.  Pass ``task_name`` to ``env.reset()`` to start
        each task.

        Args:
            env_id: Environment ID from ``create_environment()``.
            env_type: ``"rl"`` or ``"eval"``.
            run_id: Optional run ID returned by the web console's "发布任务"
                flow. When provided, the FIRST ``reset()`` will bind the SDK
                session to that pending run instead of creating a new one,
                so the pending row on the runs page transitions to running.
                Subsequent resets fall back to the new-run path.

        Returns:
            RemoteAppWorldEnv (rl) or RemoteAppWorldEvalEnv (eval).
        """
        if env_type == "rl":
            return RemoteAppWorldEnv(
                api_key=self.api_key,
                base_url=self.base_url,
                env_id=env_id,
                run_id=run_id,
            )
        if env_type == "eval":
            return RemoteAppWorldEvalEnv(
                api_key=self.api_key,
                base_url=self.base_url,
                env_id=env_id,
                run_id=run_id,
            )
        raise ValueError(f"env_type must be 'rl' or 'eval', got '{env_type}'")

    # ------------------------------------------------------------------
    # Runs (server-side eval)
    # ------------------------------------------------------------------

    def list_runs(self, **filters: Any) -> list[dict[str, Any]]:
        return self._get("/api/v1/runs", params=filters)["items"]

    def get_run(self, run_id: str) -> dict[str, Any]:
        return self._get(f"/api/v1/runs/{run_id}")

    def create_run(
        self,
        environment_id: str,
        run_type: str,
        tasks: list[str],
        name: str | None = None,
    ) -> dict[str, Any]:
        return self._post("/api/v1/runs", {
            "environment_id": environment_id,
            "type": run_type,
            "tasks": tasks,
            "name": name,
        })

    def wait_for_run(
        self,
        run_id: str,
        poll_interval: float = 0.2,
        timeout: float = 20.0,
    ) -> dict[str, Any]:
        deadline = time.monotonic() + timeout
        while True:
            run = self.get_run(run_id)
            if run["status"] in {"completed", "failed", "stopped"}:
                return run
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Run '{run_id}' did not finish within {timeout} seconds"
                )
            time.sleep(poll_interval)

    def run_eval(
        self,
        env_id: str,
        tasks: list[str],
        model_provider: str,
        model_api_key: str,
        model_name: str | None = None,
        name: str | None = None,
        wait: bool = True,
        poll_interval: float = 0.2,
        timeout: float = 20.0,
        max_steps: int = 15,
    ) -> RunResult:
        """Submit an eval run to the platform (server-side execution).

        The platform handles LLM calls and environment interactions.
        The model API key is sent to the server for this execution mode.
        """
        payload: dict[str, Any] = {
            "environment_id": env_id,
            "type": "eval",
            "tasks": tasks,
            "name": name,
            "model_provider": model_provider,
            "model_api_key": model_api_key,
            "max_steps": max_steps,
        }
        if model_name:
            payload["model_name"] = model_name
        run = self._post("/api/v1/runs", payload)
        if wait:
            run = self.wait_for_run(
                run["id"], poll_interval=poll_interval, timeout=timeout,
            )
        return self._to_run_result(run)

    # ------------------------------------------------------------------
    # Local eval (LLM runs on user side, env interactions via API)
    # ------------------------------------------------------------------

    def run_local_eval(
        self,
        env_id: str,
        tasks: list[str],
        agent: BaseAgent,
        max_steps: int = 15,
    ) -> LocalEvalBatchResult:
        """Local eval: LLM calls happen on the client side.

        The agent's API key never leaves the local process.  The server
        only handles environment interactions (screenshots, actions, state).

        Args:
            env_id: Environment ID from ``create_environment()``.
            tasks: List of task names to evaluate.
            agent: An object implementing ``BaseAgent.predict()``.
            max_steps: Maximum steps per task.
        """
        if not isinstance(agent, BaseAgent):
            raise TypeError(
                f"agent must implement BaseAgent.predict(), got {type(agent).__name__}"
            )

        batch = LocalEvalBatchResult()
        for task_name in tasks:
            try:
                result = self._run_local_eval_task(
                    env_id=env_id,
                    task_name=task_name,
                    agent=agent,
                    max_steps=max_steps,
                )
            except Exception as exc:
                logger.warning("Task %s failed: %s", task_name, exc)
                result = LocalEvalResult(
                    task_name=task_name,
                    status="failed",
                    steps=0,
                    reward=0.0,
                    history=[],
                    terminated=False,
                    truncated=False,
                )
            batch.task_results.append(result)
        return batch

    def _run_local_eval_task(
        self,
        env_id: str,
        task_name: str,
        agent: BaseAgent,
        max_steps: int,
    ) -> LocalEvalResult:
        """Run a single task with client-side LLM inference."""
        task_info = self.get_task(task_name)
        task_description = task_info.get("description", "")
        app_names = task_info.get("app_names", [])

        reset_payload = self._post("/api/v1/sdk/env/reset", {
            "env_id": env_id,
            "task_name": task_name,
            "env_type": "eval",
        })
        session_id = reset_payload["session_id"]
        observation = reset_payload["observation"]
        goal = observation.get("goal", task_description)

        history: list[str] = []
        total_reward = 0.0
        steps_taken = 0
        terminated = False
        truncated = False

        try:
            for step_index in range(1, max_steps + 1):
                screenshot = _decode_screenshot(observation["screenshot"])

                action = agent.predict(
                    screenshot=screenshot,
                    goal=goal,
                    task_name=task_name,
                    task_description=task_description,
                    app_names=app_names,
                    step_index=step_index,
                    max_steps=max_steps,
                    history=history,
                )

                description = action.get(
                    "description", action.get("action_type", "action"),
                )
                history.append(str(description))

                logger.info(
                    "step %d/%d: %s (%.2f, %.2f) %s",
                    step_index,
                    max_steps,
                    action.get("action_type"),
                    action.get("x", 0),
                    action.get("y", 0),
                    description,
                )

                step_payload = self._post("/api/v1/sdk/env/step", {
                    "session_id": session_id,
                    "action": action,
                })

                total_reward = float(step_payload["reward"])
                terminated = bool(step_payload["terminated"])
                truncated = bool(step_payload["truncated"])
                steps_taken = step_index

                if terminated or truncated:
                    break

                observation = step_payload["observation"]
                goal = observation.get("goal", goal)

        finally:
            try:
                self._post("/api/v1/sdk/env/close", {"session_id": session_id})
            except Exception:
                pass

        status = "completed" if terminated or total_reward >= 1.0 else "failed"
        return LocalEvalResult(
            task_name=task_name,
            status=status,
            steps=steps_taken,
            reward=total_reward,
            history=history,
            terminated=terminated,
            truncated=truncated,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _to_run_result(self, payload: dict[str, Any]) -> RunResult:
        return RunResult(
            id=payload["id"],
            name=payload["name"],
            status=payload["status"],
            type=payload["type"],
            environment_id=payload["environment_id"],
            success_rate=payload.get("success_rate"),
            avg_steps=payload.get("avg_steps"),
            results=payload.get("tasks", []),
            raw=payload,
        )
