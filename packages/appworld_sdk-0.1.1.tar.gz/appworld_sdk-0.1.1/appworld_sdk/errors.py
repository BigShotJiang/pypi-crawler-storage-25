"""App World SDK exception hierarchy."""

from __future__ import annotations


class AppWorldError(Exception):
    """Base exception for all App World SDK errors."""


class AppWorldAPIError(AppWorldError):
    """Error returned by the App World API server."""

    def __init__(self, message: str, *, status_code: int = 0, detail: str = ""):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"[{status_code}] {message}" if status_code else message)


class EnvironmentNotReady(AppWorldAPIError):
    """The requested environment is not available (no live backend)."""

    def __init__(self, env_or_session_id: str, *, detail: str = ""):
        super().__init__(
            f"Environment or session '{env_or_session_id}' is not ready",
            status_code=503,
            detail=detail,
        )


class SessionExpired(AppWorldAPIError):
    """The SDK session has expired or been closed."""

    def __init__(self, session_id: str, *, detail: str = ""):
        super().__init__(
            f"Session '{session_id}' has expired or been closed",
            status_code=410,
            detail=detail,
        )
