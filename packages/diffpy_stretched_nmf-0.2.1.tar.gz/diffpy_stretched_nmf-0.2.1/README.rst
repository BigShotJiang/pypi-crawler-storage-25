|Icon| |title|_
===============

.. |title| replace:: diffpy.stretched-nmf
.. _title: https://diffpy.github.io/diffpy.stretched-nmf

.. |Icon| image:: https://avatars.githubusercontent.com/diffpy
        :target: https://diffpy.github.io/diffpy.stretched-nmf
        :height: 100px

.. _online documentation: https://diffpy.github.io/diffpy.stretched-nmf

|PyPI| |Forge| |PythonVersion| |PR|

|CI| |Codecov| |Black| |Tracking|

.. |Black| image:: https://img.shields.io/badge/code_style-black-black
        :target: https://github.com/psf/black

.. |CI| image:: https://github.com/diffpy/diffpy.stretched-nmf/actions/workflows/matrix-and-codecov-on-merge-to-main.yml/badge.svg
        :target: https://github.com/diffpy/diffpy.stretched-nmf/actions/workflows/matrix-and-codecov-on-merge-to-main.yml

.. |Codecov| image:: https://codecov.io/gh/diffpy/diffpy.stretched-nmf/branch/main/graph/badge.svg
        :target: https://codecov.io/gh/diffpy/diffpy.stretched-nmf

.. |Forge| image:: https://img.shields.io/conda/vn/conda-forge/diffpy.stretched-nmf
        :target: https://anaconda.org/conda-forge/diffpy.stretched-nmf

.. |PR| image:: https://img.shields.io/badge/PR-Welcome-29ab47ff
        :target: https://github.com/diffpy/diffpy.stretched-nmf/pulls

.. |PyPI| image:: https://img.shields.io/pypi/v/diffpy.stretched-nmf
        :target: https://pypi.org/project/diffpy.stretched-nmf/

.. |PythonVersion| image:: https://img.shields.io/pypi/pyversions/diffpy.stretched-nmf
        :target: https://pypi.org/project/diffpy.stretched-nmf/

.. |Tracking| image:: https://img.shields.io/badge/issue_tracking-github-blue
        :target: https://github.com/diffpy/diffpy.stretched-nmf/issues

A python package implementing the stretched NMF algorithm.

This algorithm is designed to do an NMF factorization on a set of signals ignoring any uniform stretching of the signal
on the independent variable axis. For example, for powder diffraction data taken from samples containing multiple
chemical phases where the measurements were done at different temperatures and the materials were undergoing thermal
expansion.

For more information about the diffpy.stretched-nmf library, please consult our
`online documentation`_.

Citation
--------

If you use diffpy.stretched-nmf in a scientific publication, we would like you to cite this package as

    Ran Gu, Yevgeny Rakita, Ling Lan, Zach Thatcher, Gabrielle E. Kamm,
    Daniel O'Nolan, Brennan McBride, Allison Wustrow, James R. Neilson,
    Karena W. Chapman, Qiang Du, and Simon J. L. Billinge,
    `Stretched Non-negative Matrix Factorization
    <https://doi.org/10.1038/s41524-024-01377-5>`__,
    *npj Comput Mater* **10**, 193 (2024).

Installation
------------

The preferred method is conda::

        conda config --add channels conda-forge
        conda create -n diffpy.stretched-nmf_env diffpy.stretched-nmf
        conda activate diffpy.stretched-nmf_env

For interactive plotting with ``show_plots=True``, use a GUI-capable desktop
environment. Conda installs use ``matplotlib-base``, which is sufficient for
plotting but still depends on an available interactive Matplotlib backend.

Alternatively, install from PyPI with pip::

        pip install diffpy.stretched-nmf

For source installs (after cloning the repo)::

        pip install .

Quick check::

        snmf --version
        python -c "import diffpy.stretched_nmf; print(diffpy.stretched_nmf.__version__)"


To view the basic usage and available commands, type ::

        snmf -h

Getting Started
---------------

You may consult our `online documentation`_ for tutorials and API references.

Support and Contribute
----------------------

If you see a bug or want to request a feature, please `report it as an issue <https://github.com/diffpy/diffpy.stretched-nmf/issues>`_ and/or `submit a fix as a PR <https://github.com/diffpy/diffpy.stretched-nmf/pulls>`_.

Feel free to fork the project and contribute. To install diffpy.stretched-nmf
in a development mode, with its sources being directly used by Python
rather than copied to a package directory, use the following in the root
directory ::

        pip install -e .

To ensure code quality and to prevent accidental commits into the default branch, please set up the use of our pre-commit
hooks.

1. Install pre-commit in your working environment by running ``conda install pre-commit``.

2. Initialize pre-commit (one time only) ``pre-commit install``.

Thereafter your code will be linted by black and isort and checked against flake8 before you can commit.
If it fails by black or isort, just rerun and it should pass (black and isort will modify the files so should
pass after they are modified). If the flake8 test fails please see the error messages and fix them manually before
trying to commit again.

Improvements and fixes are always appreciated.

Before contributing, please read our `Code of Conduct <https://github.com/diffpy/diffpy.stretched-nmf/blob/main/CODE-OF-CONDUCT.rst>`_.

Contact
-------

For more information on diffpy.stretched-nmf please visit the project `web-page <https://diffpy.github.io/>`_ or email Simon Billinge at sbillinge@ucsb.edu.

Acknowledgements
----------------

``diffpy.stretched-nmf`` is built and maintained with `scikit-package <https://scikit-package.github.io/scikit-package/>`_.
