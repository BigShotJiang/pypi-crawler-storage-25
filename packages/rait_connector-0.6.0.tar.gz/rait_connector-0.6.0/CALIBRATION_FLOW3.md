# RAIT Calibration — Model Registry Calibration

This document describes the API integration for collecting and submitting model responses to the RAIT ingest endpoint using calibration prompts from the model registry. Your service fetches calibration prompts, invokes your model for each, and posts the encrypted responses to the ingest URL.

> **Schedule:** This flow runs on a **weekly** schedule.

---

## Overview

```
GET /api/model-registry/calibration-prompts/
        ↓
  invoke your model for each prompt
        ↓
PUT {RAIT_INGEST_URL}/v1/{key}   (log_type: "calibration")
```

---

## Authentication

All requests require a Bearer token.

### `POST /api/model-registry/token/`

```
POST {RAIT_API_URL}/api/model-registry/token/
Content-Type: application/json
```

```json
{
  "client_id": "your-client-id",
  "client_secret": "your-client-secret"
}
```

> **Note:** `client_id` and `client_secret` are your **RAIT platform credentials** — not Azure or any other service credentials.

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "...",
  "data": {
    "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
    "token_type": "Bearer",
    "expires_in": 3600
  }
}
```

Use the token in all subsequent requests:

```
Authorization: Bearer {access_token}
```

Re-authenticate when `expires_in` seconds have elapsed, or when any endpoint returns `401`.

| Code | Meaning |
|------|---------|
| `200` | Token retrieved |
| `400` | Invalid credentials or missing fields |
| `401` | Unauthorized |
| `500` | Internal error |

---

## Step 1 — Fetch calibration prompts

### `GET /api/model-registry/calibration-prompts/`

```
GET {RAIT_API_URL}/api/model-registry/calibration-prompts/?model_code={model_code}
Authorization: Bearer {access_token}
```

**Query parameters**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `model_code` | string | Yes | `"{model_name} {model_version} ({model_environment})"` — URL-encode when sending |

**Example:**
```
?model_code=gpt-4%201.0%20%28production%29
```

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "Data retrieved successfully.",
  "data": [
    {
      "prompt_id": "cal-prompt-uuid-001",
      "prompt_text": "Describe responsible AI in three bullet points."
    },
    {
      "prompt_id": "cal-prompt-uuid-002",
      "prompt_text": "What are the risks of large language models?"
    }
  ]
}
```

| Field | Type | Description |
|-------|------|-------------|
| `data[].prompt_id` | string | Unique prompt ID — include when posting responses |
| `data[].prompt_text` | string | The prompt to send to your model |

**If `data` is empty → no calibration prompts available, stop here.**

| Code | Meaning |
|------|---------|
| `200` | Success (may return empty `data`) |
| `400` | Missing or invalid `model_code` |
| `401` | Not authenticated |
| `403` | Not a Connector |
| `500` | Internal error |

---

## Step 2 — Invoke your model

For each prompt, pass `prompt_text` to your model and collect the response string. Build a list in this shape:

```json
[
  {
    "prompt_id": "cal-prompt-uuid-001",
    "response_text": "your model's response"
  }
]
```

---

## Step 3 — Post calibration responses to ingest

### `PUT {RAIT_INGEST_URL}/v1/{key}`

```
PUT {RAIT_INGEST_URL}/v1/{key}
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Key format**

```
{client_id}/{url-encoded model_code}/{YYYYMMDDTHHmmss}/{uuid4}
```

Example:
```
my-client/gpt-4%201.0%20%28production%29/20250101T120000/f47ac10b-58cc-4372-a567-0e02b2c3d479
```

**Request body**

```json
{
  "model_name": "gpt-4",
  "model_version": "1.0",
  "model_environment": "production",
  "model_purpose": "monitoring",
  "created_at": "2025-01-01T12:00:00.000000",
  "model_data_logs": "<base64-encoded encrypted JSON>",
  "connector_logs": "<base64-encoded encrypted string>",
  "log_type": "calibration"
}
```

| Field | Type | Description |
|-------|------|-------------|
| `model_name` | string | Name of your model |
| `model_version` | string | Version of your model |
| `model_environment` | string | e.g. `"production"`, `"staging"` |
| `model_purpose` | string | Purpose label for this model |
| `created_at` | string | ISO 8601 timestamp of submission |
| `model_data_logs` | string | Base64-encoded encrypted JSON — see below |
| `connector_logs` | string | Pass an encrypted empty string — not required for this flow |
| `log_type` | string | Must be `"calibration"` |

**`model_data_logs` plaintext (before encryption)**

```json
{
  "calibration_responses": [
    {
      "prompt_id": "cal-prompt-uuid-001",
      "response_text": "Responsible AI includes fairness, transparency, and accountability."
    },
    {
      "prompt_id": "cal-prompt-uuid-002",
      "response_text": "Risks include bias, hallucination, and misuse."
    }
  ]
}
```

> `model_data_logs` must be encrypted before sending. See [Encryption](#encryption).

**Response:** `200` or `201` on success.

| Code | Meaning |
|------|---------|
| `200` / `201` | Accepted |
| `400` | Invalid payload |
| `401` | Not authenticated |
| `403` | Not a Connector |

---

## Encryption

`model_data_logs` must be encrypted using **hybrid RSA-OAEP + AES-256-GCM** and then base64-encoded.

### Step 1 — Fetch the RSA public key

#### `GET /api/model-registry/public-key/`

```
GET {RAIT_API_URL}/api/model-registry/public-key/
Authorization: Bearer {access_token}
```

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "Data retrieved successfully.",
  "data": {
    "public_key": "-----BEGIN PUBLIC KEY-----\nMIIB...\n-----END PUBLIC KEY-----"
  }
}
```

Cache this key — it does not change per request.

### Step 2 — Encrypt the payload

For `model_data_logs`:

1. Serialize content to a UTF-8 string (JSON).
2. Generate a random **32-byte AES-256 key** and a **12-byte nonce**.
3. Encrypt with **AES-256-GCM** — produces ciphertext and a 16-byte authentication tag.
4. Encrypt the AES key with **RSA-OAEP** (SHA-256 hash, MGF1 with SHA-256).
5. Assemble the binary package in this exact order:

```
┌──────────────────────────────────────────────────────────┐
│ 4 bytes   — length of RSA-encrypted AES key (uint32 LE)  │
│ N bytes   — RSA-encrypted AES key                        │
│ 12 bytes  — AES-GCM nonce                                │
│ 16 bytes  — AES-GCM authentication tag                   │
│ M bytes   — AES-GCM ciphertext                           │
└──────────────────────────────────────────────────────────┘
```

6. **Base64-encode** the entire binary package.
7. Place the result in `model_data_logs`.

### Python reference (`encryption.py`)

```python
import base64
import json
import os
import struct
from datetime import datetime

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def load_public_key(pem: str):
    return serialization.load_pem_public_key(
        pem.encode("utf-8"), backend=default_backend()
    )


def encrypt(data: str, public_key) -> bytes:
    plaintext = data.encode("utf-8")

    # 1. Generate random AES-256 key and 12-byte nonce
    aes_key = os.urandom(32)
    nonce   = os.urandom(12)

    # 2. AES-256-GCM encrypt — tag (16 bytes) is appended to ciphertext
    encrypted  = AESGCM(aes_key).encrypt(nonce, plaintext, None)
    ciphertext = encrypted[:-16]
    tag        = encrypted[-16:]

    # 3. RSA-OAEP encrypt the AES key
    encrypted_aes_key = public_key.encrypt(
        aes_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )

    # 4. Assemble binary package
    package = (
        struct.pack("<I", len(encrypted_aes_key))  # 4 bytes LE
        + encrypted_aes_key
        + nonce   # 12 bytes
        + tag     # 16 bytes
        + ciphertext
    )

    return package


def encrypt_to_base64(data: str, public_key) -> str:
    return base64.b64encode(encrypt(data, public_key)).decode("utf-8")


# Usage
public_key = load_public_key(public_key_pem)  # PEM string from /api/model-registry/public-key/

model_data_logs = {
    "calibration_responses": [
        {"prompt_id": "cal-prompt-uuid-001", "response_text": "..."},
    ]
}

payload = {
    "model_name":        "gpt-4",
    "model_version":     "1.0",
    "model_environment": "production",
    "model_purpose":     "monitoring",
    "created_at":        datetime.now().isoformat(),  # current timestamp at time of submission
    "model_data_logs":   encrypt_to_base64(json.dumps(model_data_logs), public_key),
    "connector_logs":    encrypt_to_base64("", public_key),  # not required, pass encrypted empty string
    "log_type":          "calibration",
}
```

---

## `model_code` Format

```
{model_name} {model_version} ({model_environment})
```

Examples:
- `gpt-4 1.0 (production)`
- `gpt-4o-mini 2024-07-18 (staging)`

URL-encode this string when used as a query parameter or in the ingest key.

---

## Error Handling

| Code | Action |
|------|--------|
| `400` | Fix the request — do not retry |
| `401` | Re-authenticate and retry |
| `403` | Check that your credentials have the Connector role |
| `429` | Back off and retry |
| `500`, `502`, `503`, `504` | Retry with exponential backoff |

Recommended retry policy: 3 attempts, delays of 1 s, 2 s, 4 s.
