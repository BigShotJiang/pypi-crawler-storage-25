"""Tests for rait_connector.constants."""

from rait_connector.constants import Metric


class TestMetric:
    def test_is_str_subclass(self):
        assert isinstance(Metric.COHERENCE_AZURE, str)

    def test_value_matches_human_readable(self):
        assert Metric.COHERENCE_AZURE.value == "Coherence (Azure)"
        assert Metric.F1_SCORE_AZURE.value == "F1 Score (Azure)"
        assert Metric.SELF_HARM_AZURE.value == "Self-Harm (Azure)"
        assert Metric.HATE_AND_UNFAIRNESS_AZURE.value == "Hate and Unfairness (Azure)"
        assert Metric.GROUNDEDNESS_PRO_AZURE.value == "Groundedness Pro (Azure)"

    def test_total_count_is_22(self):
        assert len(Metric) == 22

    def test_string_equality(self):
        assert Metric.FLUENCY_AZURE == "Fluency (Azure)"
        assert Metric.VIOLENCE_AZURE == "Violence (Azure)"

    def test_all_expected_metrics_present(self):
        names = {m.value for m in Metric}
        for expected in (
            "Hate and Unfairness (Azure)",
            "Ungrounded Attributes (Azure)",
            "Content Safety (Azure)",
            "Protected Materials (Azure)",
            "Code Vulnerability (Azure)",
            "Coherence (Azure)",
            "Fluency (Azure)",
            "QA (Azure)",
            "Similarity (Azure)",
            "F1 Score (Azure)",
            "BLEU (Azure)",
            "GLEU (Azure)",
            "ROUGE (Azure)",
            "METEOR (Azure)",
            "Retrieval (Azure)",
            "Groundedness (Azure)",
            "Groundedness Pro (Azure)",
            "Relevance (Azure)",
            "Response Completeness (Azure)",
            "Sexual (Azure)",
            "Violence (Azure)",
            "Self-Harm (Azure)",
        ):
            assert expected in names, f"Missing metric: {expected}"

    def test_can_be_used_as_dict_key(self):
        d = {Metric.COHERENCE_AZURE: 5.0}
        assert d[Metric.COHERENCE_AZURE] == 5.0

    def test_iteration(self):
        metrics = list(Metric)
        assert len(metrics) == 22
