"""Tests for rait_connector.client (RAITClient)."""

import threading
from datetime import timedelta
from unittest.mock import MagicMock, patch

import pytest
import requests

from rait_connector.client import RAITClient
from rait_connector.exceptions import (
    CalibrationError,
    EncryptionError,
    EvaluationError,
    MetricsError,
    TelemetryError,
)


# ── Shared helpers ────────────────────────────────────────────────────────────


def _ok(json_data=None, status=200, text="ok"):
    resp = MagicMock()
    resp.status_code = status
    resp.text = text
    resp.json.return_value = json_data or {}
    resp.raise_for_status.return_value = None
    return resp


def _err(status=500):
    resp = MagicMock()
    resp.status_code = status
    resp.raise_for_status.side_effect = requests.HTTPError(response=resp)
    return resp


def _make_client(**overrides):
    """Return a RAITClient with a mock session and stubbed auth."""
    with patch("rait_connector.client.HttpSessionFactory.get_default_session"):
        client = RAITClient(
            rait_api_url="https://api.example.com",
            rait_client_id="cid",
            rait_client_secret="csec",
            **overrides,
        )
    client._auth_service = MagicMock()
    client._auth_service.client_id = "cid"
    client._auth_service.get_auth_headers.return_value = {"Authorization": "Bearer tok"}
    return client


def _stub_encryptor(client):
    enc = MagicMock()
    enc.encrypt.return_value = b"ENC"
    client._encryptor = enc
    return enc


def _stub_evaluate(client):
    """Stub all collaborators so evaluate() runs without Azure."""
    client.get_calibration_prompts = MagicMock(
        return_value={"calibration_run_id": "", "prompts": []}
    )
    client.get_enabled_metrics = MagicMock(return_value=[])
    client._get_model_config = MagicMock(return_value=MagicMock())
    client._get_azure_ai_project = MagicMock(return_value=MagicMock())
    client._get_credential = MagicMock(return_value=MagicMock())
    client._post_evaluation = MagicMock(
        return_value={"status_code": 200, "response": "ok"}
    )


_EVAL_KWARGS = dict(
    prompt_id="p1",
    prompt_url="https://example.com/p1",
    timestamp="2025-01-01T00:00:00",
    model_name="gpt-4",
    model_version="1.0",
    query="Q",
    response="A",
    environment="prod",
    purpose="monitor",
)


# ── __init__ ──────────────────────────────────────────────────────────────────


class TestInit:
    def test_creates_auth_service(self):
        client = _make_client()
        assert client._auth_service is not None

    def test_lazy_fields_start_none(self):
        client = _make_client()
        assert client._model_config is None
        assert client._encryptor is None
        assert client._enabled_metrics is None
        assert client._telemetry_client is None

    def test_running_calibrations_starts_empty(self):
        client = _make_client()
        assert client._running_calibrations == set()

    def test_settings_override_applied(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        assert client.settings.rait_ingest_url == "https://ingest.example.com"


# ── _get_model_config ─────────────────────────────────────────────────────────


class TestGetModelConfig:
    def test_lazy_create(self):
        client = _make_client()
        with patch("rait_connector.client.AzureOpenAIModelConfiguration") as MockCfg:
            MockCfg.return_value = MagicMock()
            cfg = client._get_model_config()
        assert cfg is MockCfg.return_value

    def test_cached_on_second_call(self):
        client = _make_client()
        with patch("rait_connector.client.AzureOpenAIModelConfiguration") as MockCfg:
            MockCfg.return_value = MagicMock()
            first = client._get_model_config()
            second = client._get_model_config()
        assert first is second
        MockCfg.assert_called_once()


# ── _get_azure_ai_project ─────────────────────────────────────────────────────


class TestGetAzureAiProject:
    def test_returns_url_when_set(self):
        client = _make_client(
            azure_ai_project_url="https://proj.example.com",
            azure_subscription_id="sub",
            azure_resource_group="rg",
            azure_project_name="proj",
        )
        result = client._get_azure_ai_project()
        assert result == "https://proj.example.com"

    def test_returns_dict_when_no_url(self):
        client = _make_client(
            azure_subscription_id="sub",
            azure_resource_group="rg",
            azure_project_name="proj",
        )
        result = client._get_azure_ai_project()
        assert isinstance(result, dict)


# ── _get_credential ───────────────────────────────────────────────────────────


class TestGetCredential:
    def test_lazy_create(self):
        client = _make_client()
        with patch("rait_connector.client.DefaultAzureCredential") as MockCred:
            MockCred.return_value = MagicMock()
            cred = client._get_credential()
        assert cred is MockCred.return_value

    def test_cached_on_second_call(self):
        client = _make_client()
        with patch("rait_connector.client.DefaultAzureCredential") as MockCred:
            MockCred.return_value = MagicMock()
            first = client._get_credential()
            second = client._get_credential()
        assert first is second
        MockCred.assert_called_once()


# ── _get_encryptor ────────────────────────────────────────────────────────────


class TestGetEncryptor:
    def test_success(self):
        client = _make_client()
        client._session.get.return_value = _ok(
            {
                "data": {
                    "public_key": "-----BEGIN PUBLIC KEY-----\nfake\n-----END PUBLIC KEY-----"
                }
            }
        )
        with patch("rait_connector.client.Encryptor") as MockEnc:
            MockEnc.return_value = MagicMock()
            enc = client._get_encryptor()
        assert enc is MockEnc.return_value

    def test_cached_on_second_call(self):
        client = _make_client()
        client._session.get.return_value = _ok({"data": {"public_key": "fake-key"}})
        with patch("rait_connector.client.Encryptor") as MockEnc:
            MockEnc.return_value = MagicMock()
            first = client._get_encryptor()
            second = client._get_encryptor()
        assert first is second
        client._session.get.assert_called_once()

    def test_missing_public_key_raises(self):
        client = _make_client()
        client._session.get.return_value = _ok({"data": {}})
        with pytest.raises(EncryptionError, match="Public key missing"):
            client._get_encryptor()

    def test_http_error_raises(self):
        client = _make_client()
        client._session.get.return_value = _err(401)
        with pytest.raises(EncryptionError, match="Failed to fetch encryption key"):
            client._get_encryptor()

    def test_request_exception_raises(self):
        client = _make_client()
        client._session.get.side_effect = requests.ConnectionError("timeout")
        with pytest.raises(EncryptionError):
            client._get_encryptor()


# ── get_enabled_metrics ───────────────────────────────────────────────────────


class TestGetEnabledMetrics:
    def test_success(self):
        client = _make_client()
        dims = [{"dimension_name": "Bias", "dimension_metrics": []}]
        client._session.get.return_value = _ok({"data": dims})
        result = client.get_enabled_metrics()
        assert result == dims

    def test_cached_on_second_call(self):
        client = _make_client()
        dims = [{"dimension_name": "Bias", "dimension_metrics": []}]
        client._session.get.return_value = _ok({"data": dims})
        client.get_enabled_metrics()
        client.get_enabled_metrics()
        client._session.get.assert_called_once()

    def test_force_refresh_bypasses_cache(self):
        client = _make_client()
        client._session.get.return_value = _ok({"data": []})
        client.get_enabled_metrics()
        client.get_enabled_metrics(force_refresh=True)
        assert client._session.get.call_count == 2

    def test_invalid_format_raises(self):
        client = _make_client()
        client._session.get.return_value = _ok({"data": "not-a-list"})
        with pytest.raises(MetricsError, match="Invalid metrics"):
            client.get_enabled_metrics()

    def test_http_error_raises(self):
        client = _make_client()
        client._session.get.return_value = _err(403)
        with pytest.raises(MetricsError, match="HTTP error"):
            client.get_enabled_metrics()

    def test_network_error_raises(self):
        client = _make_client()
        client._session.get.side_effect = requests.ConnectionError("net")
        with pytest.raises(MetricsError, match="Network error"):
            client.get_enabled_metrics()

    def test_model_code_param_sent(self):
        client = _make_client()
        client._session.get.return_value = _ok({"data": []})
        client.get_enabled_metrics(
            model_name="m", model_version="v", model_environment="e"
        )
        call_kwargs = client._session.get.call_args[1]
        assert call_kwargs["params"]["model_code"] == "m v (e)"


# ── get_calibration_prompts ───────────────────────────────────────────────────


class TestGetCalibrationPrompts:
    def test_success(self):
        client = _make_client()
        prompts = [{"prompt_id": "1", "prompt_text": "hi"}]
        client._session.get.return_value = _ok(
            {"data": {"calibration_run_id": "run-1", "prompts": prompts}}
        )
        result = client.get_calibration_prompts("m", "v", "e")
        assert result["calibration_run_id"] == "run-1"
        assert result["prompts"] == prompts

    def test_invalid_format_raises(self):
        client = _make_client()
        client._session.get.return_value = _ok({"data": {"prompts": "not-a-list"}})
        with pytest.raises(CalibrationError, match="Invalid calibration prompts"):
            client.get_calibration_prompts()

    def test_http_error_raises(self):
        client = _make_client()
        client._session.get.return_value = _err(404)
        with pytest.raises(CalibrationError, match="HTTP error"):
            client.get_calibration_prompts()

    def test_network_error_raises(self):
        client = _make_client()
        client._session.get.side_effect = requests.ConnectionError("net")
        with pytest.raises(CalibrationError, match="Network error"):
            client.get_calibration_prompts()


# ── get_model_calibration_prompts ─────────────────────────────────────────────


class TestGetModelCalibrationPrompts:
    def test_success(self):
        client = _make_client()
        prompts = [{"prompt_id": "1", "prompt_text": "Q"}]
        client._session.get.return_value = _ok({"data": prompts})
        result = client.get_model_calibration_prompts("m", "v", "e")
        assert result == prompts

    def test_invalid_format_raises(self):
        client = _make_client()
        client._session.get.return_value = _ok({"data": "bad"})
        with pytest.raises(CalibrationError, match="Invalid model calibration"):
            client.get_model_calibration_prompts()

    def test_http_error_raises(self):
        client = _make_client()
        client._session.get.return_value = _err(500)
        with pytest.raises(CalibrationError):
            client.get_model_calibration_prompts()


# ── get_prompts_response ──────────────────────────────────────────────────────


class TestGetPromptsResponse:
    def test_flattens_groups(self):
        client = _make_client()
        groups = [
            {"prompts": [{"prompt_response_id": "1", "prompt_text": "A"}]},
            {"prompts": [{"prompt_response_id": "2", "prompt_text": "B"}]},
        ]
        client._session.get.return_value = _ok({"data": groups})
        result = client.get_prompts_response()
        assert len(result) == 2

    def test_empty_groups_returns_empty(self):
        client = _make_client()
        client._session.get.return_value = _ok({"data": []})
        result = client.get_prompts_response()
        assert result == []

    def test_http_error_raises(self):
        client = _make_client()
        client._session.get.return_value = _err(403)
        with pytest.raises(CalibrationError):
            client.get_prompts_response()

    def test_network_error_raises(self):
        client = _make_client()
        client._session.get.side_effect = requests.ConnectionError()
        with pytest.raises(CalibrationError, match="Network error"):
            client.get_prompts_response()


# ── update_prompts_response ───────────────────────────────────────────────────


class TestUpdatePromptsResponse:
    def test_success(self):
        client = _make_client()
        client._session.post.return_value = _ok(status=200)
        result = client.update_prompts_response(
            [{"prompt_response_id": "1"}], "m", "v", "e"
        )
        assert result["status_code"] == 200

    def test_http_error_raises(self):
        client = _make_client()
        client._session.post.return_value = _err(400)
        with pytest.raises(CalibrationError, match="HTTP error"):
            client.update_prompts_response([], "m", "v", "e")

    def test_network_error_raises(self):
        client = _make_client()
        client._session.post.side_effect = requests.ConnectionError()
        with pytest.raises(CalibrationError, match="Network error"):
            client.update_prompts_response([], "m", "v", "e")


# ── _build_key ────────────────────────────────────────────────────────────────


class TestBuildKey:
    def test_format(self):
        client = _make_client()
        key = client._build_key("my-model")
        parts = key.split("/")
        assert parts[0] == "cid"
        assert parts[1] == "my-model"
        assert len(parts) == 4  # cid / model_code / datetime / uuid

    def test_missing_client_id_raises(self):
        client = _make_client()
        client._auth_service.client_id = ""
        with pytest.raises(ValueError, match="client_id"):
            client._build_key("model")

    def test_missing_model_code_raises(self):
        client = _make_client()
        with pytest.raises(ValueError, match="model_code"):
            client._build_key("")


# ── _post_evaluation ──────────────────────────────────────────────────────────


class TestPostEvaluation:
    def _eval_result(self):
        return {
            "prompt_id": "p1",
            "prompt_url": "https://x.com",
            "prompt_response_id": "",
            "calibration_run_id": "",
            "ethical_dimensions": [],
            "model_name": "gpt-4",
            "model_version": "1.0",
            "environment": "prod",
            "purpose": "monitor",
            "timestamp": "2025-01-01T00:00:00",
        }

    def test_success(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        _stub_encryptor(client)
        client._session.put.return_value = _ok(status=201)
        result = client._post_evaluation(self._eval_result())
        assert result["status_code"] == 201

    def test_custom_fields_included(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        enc = _stub_encryptor(client)
        client._session.put.return_value = _ok(status=200)
        client._post_evaluation(self._eval_result(), custom_fields={"extra": "val"})
        # Check that the encrypted payload included custom_fields
        call_args = enc.encrypt.call_args_list[0]
        payload_str = call_args[0][0]
        payload = __import__("json").loads(payload_str)
        assert payload.get("extra") == "val"

    def test_http_error_raises(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        _stub_encryptor(client)
        client._session.put.return_value = _err(500)
        with pytest.raises(MetricsError, match="HTTP error"):
            client._post_evaluation(self._eval_result())

    def test_network_error_raises(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        _stub_encryptor(client)
        client._session.put.side_effect = requests.ConnectionError()
        with pytest.raises(MetricsError, match="Network error"):
            client._post_evaluation(self._eval_result())


# ── evaluate ──────────────────────────────────────────────────────────────────


class TestEvaluate:
    def test_basic_success(self):
        client = _make_client()
        _stub_evaluate(client)
        with patch("rait_connector.client.EvaluatorOrchestrator") as MockOrch:
            MockOrch.return_value.evaluate_metrics.return_value = []
            result = client.evaluate(**_EVAL_KWARGS)
        assert result["prompt_id"] == "p1"
        assert "ethical_dimensions" in result
        client._post_evaluation.assert_called_once()

    def test_for_calibration_skips_calibration_check(self):
        client = _make_client()
        _stub_evaluate(client)
        with patch("rait_connector.client.EvaluatorOrchestrator") as MockOrch:
            MockOrch.return_value.evaluate_metrics.return_value = []
            client.evaluate(**_EVAL_KWARGS, for_calibration=True)
        client.get_calibration_prompts.assert_not_called()

    def test_no_calibration_prompts_no_thread(self):
        client = _make_client()
        _stub_evaluate(client)
        client.get_calibration_prompts.return_value = {
            "calibration_run_id": "",
            "prompts": [],
        }
        with patch("rait_connector.client.EvaluatorOrchestrator") as MockOrch:
            MockOrch.return_value.evaluate_metrics.return_value = []
            with patch("rait_connector.client.threading.Thread") as MockThread:
                client.evaluate(**_EVAL_KWARGS)
        MockThread.assert_not_called()

    def test_calibration_prompts_triggers_background_thread(self):
        client = _make_client()
        _stub_evaluate(client)
        prompts = [{"prompt_id": "c1", "prompt_text": "hi"}]
        client.get_calibration_prompts.return_value = {
            "calibration_run_id": "r1",
            "prompts": prompts,
        }
        done = threading.Event()
        client._run_background_calibration = MagicMock(
            side_effect=lambda *a: done.set()
        )

        with patch("rait_connector.client.EvaluatorOrchestrator") as MockOrch:
            MockOrch.return_value.evaluate_metrics.return_value = []
            client.evaluate(**_EVAL_KWARGS)

        done.wait(timeout=3)
        client._run_background_calibration.assert_called_once()

    def test_already_running_calibration_not_triggered_again(self):
        client = _make_client()
        _stub_evaluate(client)
        model_key = ("gpt-4", "1.0", "prod")
        client._running_calibrations.add(model_key)
        prompts = [{"prompt_id": "c1"}]
        client.get_calibration_prompts.return_value = {
            "calibration_run_id": "r1",
            "prompts": prompts,
        }
        client._run_background_calibration = MagicMock()

        with patch("rait_connector.client.EvaluatorOrchestrator") as MockOrch:
            MockOrch.return_value.evaluate_metrics.return_value = []
            client.evaluate(**_EVAL_KWARGS)

        client._run_background_calibration.assert_not_called()

    def test_calibration_check_failure_is_logged_not_raised(self):
        client = _make_client()
        _stub_evaluate(client)
        client.get_calibration_prompts.side_effect = Exception("api down")
        with patch("rait_connector.client.EvaluatorOrchestrator") as MockOrch:
            MockOrch.return_value.evaluate_metrics.return_value = []
            # Should not raise — calibration check failure is non-blocking
            result = client.evaluate(**_EVAL_KWARGS)
        assert result["prompt_id"] == "p1"

    def test_evaluator_error_raises(self):
        client = _make_client()
        _stub_evaluate(client)
        with patch("rait_connector.client.EvaluatorOrchestrator") as MockOrch:
            MockOrch.return_value.evaluate_metrics.side_effect = RuntimeError(
                "eval broke"
            )
            with pytest.raises(EvaluationError, match="eval broke"):
                client.evaluate(**_EVAL_KWARGS)

    def test_custom_fields_forwarded_to_post(self):
        client = _make_client()
        _stub_evaluate(client)
        with patch("rait_connector.client.EvaluatorOrchestrator") as MockOrch:
            MockOrch.return_value.evaluate_metrics.return_value = []
            client.evaluate(**_EVAL_KWARGS, custom_fields={"key": "val"})
        call_kwargs = client._post_evaluation.call_args[1]
        assert call_kwargs.get("custom_fields") == {"key": "val"}


# ── _run_background_calibration ───────────────────────────────────────────────


class TestRunBackgroundCalibration:
    def test_calls_evaluate_for_each_prompt(self):
        client = _make_client()
        client.evaluate = MagicMock(return_value={})
        model_key = ("m", "v", "e")
        client._running_calibrations.add(model_key)

        calibration_data = {
            "calibration_run_id": "r1",
            "prompts": [
                {
                    "prompt_id": "c1",
                    "prompt_text": "Q1",
                    "prompt_url": "",
                    "response_text": "A1",
                    "timestamp": "2025-01-01T00:00:00",
                },
                {
                    "prompt_id": "c2",
                    "prompt_text": "Q2",
                    "prompt_url": "",
                    "response_text": "A2",
                    "timestamp": "2025-01-01T00:00:00",
                },
            ],
        }
        client._run_background_calibration("m", "v", "e", "p", "", calibration_data)
        assert client.evaluate.call_count == 2

    def test_removes_model_key_from_running_after_completion(self):
        client = _make_client()
        client.evaluate = MagicMock(return_value={})
        model_key = ("m", "v", "e")
        client._running_calibrations.add(model_key)

        client._run_background_calibration(
            "m", "v", "e", "p", "", {"calibration_run_id": "", "prompts": []}
        )
        assert model_key not in client._running_calibrations

    def test_removes_key_even_when_prompt_fails(self):
        client = _make_client()
        client.evaluate = MagicMock(side_effect=Exception("eval failed"))
        model_key = ("m", "v", "e")
        client._running_calibrations.add(model_key)

        client._run_background_calibration(
            "m",
            "v",
            "e",
            "p",
            "",
            {
                "calibration_run_id": "",
                "prompts": [{"prompt_id": "c1", "prompt_text": "Q"}],
            },
        )
        assert model_key not in client._running_calibrations

    def test_uses_for_calibration_true(self):
        client = _make_client()
        client.evaluate = MagicMock(return_value={})
        client._running_calibrations.add(("m", "v", "e"))

        client._run_background_calibration(
            "m",
            "v",
            "e",
            "p",
            "",
            {
                "calibration_run_id": "r1",
                "prompts": [{"prompt_id": "c1", "prompt_text": "Q"}],
            },
        )
        call_kwargs = client.evaluate.call_args[1]
        assert call_kwargs["for_calibration"] is True


# ── evaluate_batch ────────────────────────────────────────────────────────────


class TestEvaluateBatch:
    def _make_prompts(self, n=2):
        return [{**_EVAL_KWARGS, "prompt_id": f"p{i}"} for i in range(n)]

    def test_all_succeed(self):
        client = _make_client()
        client.evaluate = MagicMock(return_value={"prompt_id": "px"})
        result = client.evaluate_batch(self._make_prompts(3))
        assert result["successful"] == 3
        assert result["failed"] == 0
        assert result["total"] == 3

    def test_one_fails_goes_to_errors(self):
        client = _make_client()
        client.evaluate = MagicMock(
            side_effect=[{"prompt_id": "p0"}, Exception("boom"), {"prompt_id": "p2"}]
        )
        result = client.evaluate_batch(self._make_prompts(3))
        assert result["successful"] == 2
        assert result["failed"] == 1
        assert result["errors"][0]["error"] == "boom"

    def test_fail_fast_raises(self):
        client = _make_client()
        client.evaluate = MagicMock(side_effect=Exception("boom"))
        with pytest.raises(EvaluationError, match="Batch evaluation failed"):
            client.evaluate_batch(self._make_prompts(2), fail_fast=True)

    def test_on_complete_called_with_summary(self):
        client = _make_client()
        client.evaluate = MagicMock(return_value={"prompt_id": "p0"})
        callback = MagicMock()
        client.evaluate_batch(self._make_prompts(1), on_complete=callback)
        callback.assert_called_once()
        summary = callback.call_args[0][0]
        assert summary["total"] == 1

    def test_callback_error_does_not_raise(self):
        client = _make_client()
        client.evaluate = MagicMock(return_value={})
        client.evaluate_batch(
            self._make_prompts(1),
            on_complete=MagicMock(side_effect=Exception("cb error")),
        )

    def test_accepts_evaluation_input_objects(self):
        from rait_connector.models import EvaluationInput

        client = _make_client()
        client.evaluate = MagicMock(return_value={})
        inp = EvaluationInput(**{k: v for k, v in _EVAL_KWARGS.items()})
        client.evaluate_batch([inp])
        client.evaluate.assert_called_once()


# ── post_telemetry ────────────────────────────────────────────────────────────


class TestPostTelemetry:
    def test_success(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        _stub_encryptor(client)
        client._session.put.return_value = _ok(status=200)
        result = client.post_telemetry("m", "v", "prod", "monitor", {})
        assert result["status_code"] == 200

    def test_telemetry_tables_included(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        enc = _stub_encryptor(client)
        client._session.put.return_value = _ok(status=200)
        data = {
            "AppDependencies": [{"row": 1}],
            "AppExceptions": [],
            "AppAvailabilityResults": [],
        }
        client.post_telemetry("m", "v", "prod", "monitor", data)
        payload_str = enc.encrypt.call_args_list[0][0][0]
        payload = __import__("json").loads(payload_str)
        assert payload["app_dependencies"] == [{"row": 1}]

    def test_http_error_raises(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        _stub_encryptor(client)
        client._session.put.return_value = _err(500)
        with pytest.raises(MetricsError, match="HTTP error"):
            client.post_telemetry("m", "v", "prod", "monitor", {})

    def test_network_error_raises(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        _stub_encryptor(client)
        client._session.put.side_effect = requests.ConnectionError()
        with pytest.raises(MetricsError, match="Network error"):
            client.post_telemetry("m", "v", "prod", "monitor", {})


# ── post_calibration_responses ────────────────────────────────────────────────


class TestPostCalibrationResponses:
    def test_success(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        _stub_encryptor(client)
        client._session.put.return_value = _ok(status=200)
        result = client.post_calibration_responses("m", "v", "prod", "monitor", [])
        assert result["status_code"] == 200

    def test_responses_in_payload(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        enc = _stub_encryptor(client)
        client._session.put.return_value = _ok(status=200)
        responses = [{"prompt_id": "1", "response_text": "R"}]
        client.post_calibration_responses("m", "v", "prod", "monitor", responses)
        payload_str = enc.encrypt.call_args_list[0][0][0]
        payload = __import__("json").loads(payload_str)
        assert payload["calibration_responses"] == responses

    def test_http_error_raises(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        _stub_encryptor(client)
        client._session.put.return_value = _err(400)
        with pytest.raises(MetricsError, match="HTTP error"):
            client.post_calibration_responses("m", "v", "prod", "monitor", [])

    def test_network_error_raises(self):
        client = _make_client(rait_ingest_url="https://ingest.example.com")
        _stub_encryptor(client)
        client._session.put.side_effect = requests.ConnectionError()
        with pytest.raises(MetricsError, match="Network error"):
            client.post_calibration_responses("m", "v", "prod", "monitor", [])


# ── fetch_telemetry ───────────────────────────────────────────────────────────


class TestFetchTelemetry:
    def test_delegates_to_telemetry_client(self):
        client = _make_client(azure_log_analytics_workspace_id="ws-id")
        mock_tc = MagicMock()
        mock_tc.fetch_all.return_value = {"AppDependencies": []}
        client._telemetry_client = mock_tc
        result = client.fetch_telemetry(timespan=timedelta(hours=6))
        mock_tc.fetch_all.assert_called_once()
        assert "AppDependencies" in result

    def test_no_workspace_id_raises(self):
        client = _make_client()
        with pytest.raises(TelemetryError, match="workspace ID"):
            client.fetch_telemetry()

    def test_telemetry_error_reraises(self):
        client = _make_client(azure_log_analytics_workspace_id="ws-id")
        mock_tc = MagicMock()
        mock_tc.fetch_all.side_effect = TelemetryError("azure down")
        client._telemetry_client = mock_tc
        with pytest.raises(TelemetryError, match="azure down"):
            client.fetch_telemetry()

    def test_unexpected_error_wrapped(self):
        client = _make_client(azure_log_analytics_workspace_id="ws-id")
        mock_tc = MagicMock()
        mock_tc.fetch_all.side_effect = RuntimeError("unexpected")
        client._telemetry_client = mock_tc
        with pytest.raises(TelemetryError, match="Failed to fetch telemetry"):
            client.fetch_telemetry()

    def test_default_tables_used(self):
        client = _make_client(azure_log_analytics_workspace_id="ws-id")
        mock_tc = MagicMock()
        mock_tc.fetch_all.return_value = {}
        client._telemetry_client = mock_tc
        client.fetch_telemetry()
        tables_arg = mock_tc.fetch_all.call_args[1]["tables"]
        assert "AppDependencies" in tables_arg
        assert "AppExceptions" in tables_arg
