# RAIT Calibration — Calibrator Response Collection

This document describes the API integration for collecting and submitting model responses to the RAIT calibrator. Your service fetches prompts that have no model response yet, invokes your model for each, and submits the responses back. No encryption is required.

> **Schedule:** This flow runs on a **daily** schedule.

---

## Overview

```
GET /api/calibrator/get-prompts-response/
        ↓
  invoke your model for each prompt
        ↓
POST /api/calibrator/update-prompts-response/
```

---

## Authentication

All requests require a Bearer token.

### `POST /api/model-registry/token/`

```
POST {RAIT_API_URL}/api/model-registry/token/
Content-Type: application/json
```

```json
{
  "client_id": "your-client-id",
  "client_secret": "your-client-secret"
}
```

> **Note:** `client_id` and `client_secret` are your **RAIT platform credentials** — not Azure or any other service credentials.

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "...",
  "data": {
    "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
    "token_type": "Bearer",
    "expires_in": 3600
  }
}
```

Use the token in all subsequent requests:

```
Authorization: Bearer {access_token}
```

Re-authenticate when `expires_in` seconds have elapsed, or when any endpoint returns `401`.

| Code | Meaning |
|------|---------|
| `200` | Token retrieved |
| `400` | Invalid credentials or missing fields |
| `401` | Unauthorized |
| `500` | Internal error |

---

## Step 1 — Fetch prompts needing responses

### `GET /api/calibrator/get-prompts-response/`

```
GET {RAIT_API_URL}/api/calibrator/get-prompts-response/?model_code={model_code}
Authorization: Bearer {access_token}
```

**Query parameters**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `model_code` | string | Yes | `"{model_name} {model_version} ({model_environment})"` — URL-encode when sending |

**Example:**
```
?model_code=gpt-4%201.0%20%28production%29
```

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "Data retrieved successfully.",
  "data": [
    {
      "prompt_group_id": "group-uuid-001",
      "group_name": "Safety Prompts",
      "prompt_class": "safety",
      "prompts": [
        {
          "prompt_response_id": "pr-uuid-001",
          "prompt_text": "Explain machine learning in one sentence.",
          "sequence": 1
        },
        {
          "prompt_response_id": "pr-uuid-002",
          "prompt_text": "What is a neural network?",
          "sequence": 2
        }
      ]
    }
  ]
}
```

| Field | Type | Description |
|-------|------|-------------|
| `data` | array | Groups of prompts. Empty array means nothing to do. |
| `data[].prompt_group_id` | string | Group identifier |
| `data[].group_name` | string | Human-readable group name |
| `data[].prompt_class` | string | Classification of the prompt group |
| `data[].prompts[].prompt_response_id` | string | Returned by the API — pass it back as-is in Step 3 |
| `data[].prompts[].prompt_text` | string | The prompt to send to your model |
| `data[].prompts[].sequence` | integer\|null | Ordering hint within the group |

> `data` is an array of groups. Flatten all nested `prompts` arrays into a single list before processing.

**If the flattened list is empty → nothing to do, stop here.**

| Code | Meaning |
|------|---------|
| `200` | Success (may return empty `data`) |
| `400` | Missing or invalid `model_code`, or model not found |
| `401` | Not authenticated |
| `403` | Not a Connector |
| `500` | Internal error |

---

## Step 2 — Invoke your model

For each prompt in the flattened list, pass `prompt_text` to your model and collect the response string.

---

## Step 3 — Submit collected responses

### `POST /api/calibrator/update-prompts-response/`

```
POST {RAIT_API_URL}/api/calibrator/update-prompts-response/
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Request body**

```json
{
  "model_code": "gpt-4 1.0 (production)",
  "responses": [
    {
      "prompt_response_id": "pr-uuid-001",
      "prompt_text": "Explain machine learning in one sentence.",
      "model_response": "Machine learning is a subset of AI where models learn patterns from data."
    },
    {
      "prompt_response_id": "pr-uuid-002",
      "prompt_text": "What is a neural network?",
      "model_response": "A neural network is a computational model inspired by the human brain."
    }
  ]
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `model_code` | string | Yes | `"{model_name} {model_version} ({model_environment})"` |
| `responses` | array | Yes | At least one item required |
| `responses[].prompt_response_id` | string | Yes | Returned by the API in Step 1 — do not generate this yourself |
| `responses[].prompt_text` | string | Yes | Echo of the `prompt_text` received in Step 1 |
| `responses[].model_response` | string | Yes | Your model's response to the prompt |

**No encryption required for this endpoint.**

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "Updated successfully"
}
```

| Code | Meaning |
|------|---------|
| `200` | Responses updated successfully |
| `400` | Invalid `model_code`, empty responses list, or unrecognised `prompt_response_id` |
| `403` | Not a Connector |
| `500` | Internal error |

---

## `model_code` Format

```
{model_name} {model_version} ({model_environment})
```

Examples:
- `gpt-4 1.0 (production)`
- `gpt-4o-mini 2024-07-18 (staging)`

URL-encode this string when used as a query parameter.

---

## Error Handling

| Code | Action |
|------|--------|
| `400` | Fix the request — do not retry |
| `401` | Re-authenticate and retry |
| `403` | Check that your credentials have the Connector role |
| `429` | Back off and retry |
| `500`, `502`, `503`, `504` | Retry with exponential backoff |

Recommended retry policy: 3 attempts, delays of 1 s, 2 s, 4 s.
