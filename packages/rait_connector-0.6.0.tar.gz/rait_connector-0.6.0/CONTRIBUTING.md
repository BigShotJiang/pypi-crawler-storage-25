# Contributing to RAIT Connector

## Development Setup

```bash
git clone https://github.com/Responsible-Systems/rait-connector.git
cd rait-connector

uv sync --dev

uv tool install pre-commit
pre-commit install
```

## Running Tests

Always use `uv run pytest`:

```bash
# Full test run with coverage
uv run pytest

# Skip coverage for faster feedback
uv run pytest --no-cov

# Run a specific test file
uv run pytest tests/test_client.py

# Run a specific test
uv run pytest tests/test_client.py::test_evaluate
```

## Environments and Branch Flow

| Branch | Environment |
|---|---|
| `development` | Development |
| `main` | Production |

Changes must be promoted through environments in order:

```mermaid
flowchart LR
    F[feature/fix branch] -->|PR| D[development]
    D -->|PR via release/development-to-main| M[main]
```

Direct PRs to `main` bypass environment testing and must not be used.

## Branch Naming

Follows [Conventional Branch](https://conventional-branch.github.io/): `<type>/<description>`

| Type | Use for |
|------|---------|
| `feature/` or `feat/` | New functionality |
| `bugfix/` or `fix/` | Bug fixes |
| `hotfix/` | Urgent production fixes |
| `release/` | Release preparation |
| `chore/` | Everything else — docs, refactors, tests, CI, tooling |

Rules:

- Lowercase letters, numbers, and hyphens only
- No consecutive or trailing hyphens
- Include ticket numbers when applicable

Examples: `feature/batch-timeout`, `fix/calibration-thread-leak`, `chore/update-dependencies`, `feature/issue-42-scheduler-cron`

The branches `main`, `staging`, and `development` are protected — use a pull request, no direct pushes.

## Commit Messages

This repo uses [Conventional Commits](https://www.conventionalcommits.org/):

```text
<type>(<scope>): <description>
```

Common types: `feat`, `fix`, `docs`, `chore`, `refactor`, `test`, `style`, `ci`

Examples:

```text
feat(scheduler): add cron expression support to add_calibration_job
fix(client): prevent duplicate background calibration threads
docs(readme): add architecture diagram
chore(deps): bump cryptography to 46.0.3
```

## Changelog

All notable changes must be documented in [CHANGELOG.md](CHANGELOG.md), following the [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) format.

- Add an entry to the `[Unreleased]` section as part of the PR that introduces the change — not as a separate commit afterwards.
- Use the appropriate subsection: `Added`, `Changed`, `Fixed`, `Removed`, or `Security`.
- Write from a user's perspective — describe what changed and why it matters, not how it was implemented.

## Pull Requests

- Keep PRs focused — one concern per PR
- Add or update tests for any behaviour change
- Update `CHANGELOG.md` under `[Unreleased]` for any user-facing change
- Ensure `uv run pytest` passes with no failures before opening a PR
- Pre-commit hooks must pass (they run automatically on `git commit`)
- Target `development` for new work; `main` is for releases only

### Merge strategy

| PR type | Strategy | Why |
|---|---|---|
| feature/fix/chore → `development` | **Squash and merge** | Keeps `development` clean — one commit per feature or fix |
| `development` → `main` | **Merge commit** | Preserves full history on `main` and marks exactly when each release landed |

## Releasing a New Version

1. Update `CHANGELOG.md` — rename `[Unreleased]` to the new version with today's date, and add a fresh empty `[Unreleased]` section at the top:

   ```markdown
   ## [Unreleased]

   ## [x.y.z] - YYYY-MM-DD
   ```

2. Bump the version:

   ```bash
   uv version --bump <major|minor|patch>
   ```

3. Commit the version and changelog update:

   ```bash
   git commit -am "chore(release): bump version to <version>"
   ```

4. Tag the release with a `v` prefix:

   ```bash
   git tag -a v<version> <commit-hash> -m "Release version <version>"
   ```

   > Use the commit hash from step 3.

5. Push commit and tag:

   ```bash
   git push && git push --tags
   ```

   > Pushing the `v*` tag triggers the CI release workflow, which runs all checks, builds the package, publishes to PyPI, and creates a GitHub Release with the changelog notes automatically.

> **Prerequisites:** The repository must have a `PYPI_TOKEN` secret configured under `Settings → Secrets and variables → Actions` for the publish step to succeed.

## Docs

```bash
# Serve locally
uv run mkdocs serve

# Build static site
uv run mkdocs build
```

Full docs live in [docs/](docs/) and are built with MkDocs + mkdocstrings.
