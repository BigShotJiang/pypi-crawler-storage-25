# RAIT Connector — Developer Guide

## Table of Contents

1. [Library Overview](#1-library-overview)
2. [Architecture & Data Flow](#2-architecture--data-flow)
3. [Project Structure](#3-project-structure)
4. [Configuration](#4-configuration)
5. [RAITClient](#5-raitclient)
6. [Authentication](#6-authentication)
7. [Encryption](#7-encryption)
8. [Evaluation Pipeline](#8-evaluation-pipeline)
   - [EvaluatorOrchestrator](#81-evaluatororchestrator)
   - [Evaluator Registry](#82-evaluator-registry)
   - [Metric Reference](#83-metric-reference)
9. [Calibration Flows](#9-calibration-flows)
   - [Flow 1 — Triggered by evaluate()](#91-flow-1--triggered-by-evaluate)
   - [Flow 2 — Calibrator Response Collection](#92-flow-2--calibrator-response-collection)
   - [Flow 3 — Model-Registry Calibration](#93-flow-3--model-registry-calibration)
10. [Telemetry](#10-telemetry)
11. [Scheduler](#11-scheduler)
12. [HTTP Layer](#12-http-layer)
13. [RAIT API Alignment](#13-rait-api-alignment)
14. [Environment Variables](#14-environment-variables)
15. [Development Setup](#15-development-setup)

---

## 1. Library Overview

`rait-connector` is a Python library (v0.5.0, Python 3.12+) that integrates an LLM deployment with the RAIT platform. It provides four responsibilities:

1. **Evaluate** — run Azure AI Evaluation metrics against prompt/response pairs and post results to the RAIT API.
2. **Telemetry** — query Azure Monitor Log Analytics and post performance data to the RAIT pipeline.
3. **Calibration** — periodically collect model responses to calibration prompts and submit them to the RAIT backend.
4. **Schedule** — run evaluation, telemetry, and calibration tasks automatically at configurable intervals via an APScheduler-backed `Scheduler`.

The library is consumed by teams that own an LLM deployment. It sits between the LLM and the RAIT platform — it never stores data itself; everything is forwarded to the RAIT API.

---

## 2. Architecture & Data Flow

```mermaid
flowchart TD
    App[Your Application]

    App -->|"client.evaluate(...)"| Connector[RAIT Connector]
    App -->|"scheduler.add_telemetry_job(...)"| Connector
    App -->|"scheduler.add_calibration_job(...)"| Connector

    Connector -->|"PUT {rait_ingest_url}/v1/key\nevaluation, telemetry, calibration log_types"| AGW["API Gateway\n(injects org_id + client_id\nfrom JWT into S3 metadata)"]

    Connector -->|"GET/POST /api/..."| Backend[RAIT Backend]

    Connector -->|"GET /api/model-registry/enabled-metrics/"| Backend
    Connector -->|"GET /api/model-registry/public-key/"| Backend
    Connector -->|"GET /api/model-registry/calibration-prompts/"| Backend
    Connector -->|"GET /api/calibrator/calibration-run-prompts/"| Backend
    Connector -->|"GET /api/calibrator/get-prompts-response/"| Backend
    Connector -->|"POST /api/calibrator/update-prompts-response/"| Backend

    Connector -->|"Azure Log Analytics queries"| AzureMonitor["Azure Monitor\n(Log Analytics)"]

    AGW --> S3[(S3)]
    S3 -->|"S3 event"| SQS[[SQS]]
    SQS --> Engine[RAIT Scoring Engine]
    Engine -->|"POST /api/model-registry/engine-data-logs/"| Backend
    Engine -->|"POST /api/model-registry/scoring-results/"| Backend
```

### Step-by-step for an evaluation call

1. The application calls `client.evaluate(...)`.
2. `RAITClient` fetches enabled metrics from the RAIT API (cached after first call).
3. `EvaluatorOrchestrator` runs all applicable metrics in parallel using Azure AI Evaluation.
4. The result payload is RSA-encrypted using a public key fetched from the RAIT API (cached after first call).
5. The encrypted payload is PUT to the RAIT ingest URL (API Gateway) with the appropriate `log_type`. The API Gateway extracts `org_id` and `client_id` from the Bearer JWT and writes them as S3 object metadata.
6. S3 triggers SQS, and the RAIT Scoring Engine picks it up for scoring.

All log types (`"evaluation"`, `"telemetry"`, `"calibration"`) are routed through the ingest URL.

---

## 3. Project Structure

```text
rait_connector/
├── src/rait_connector/
│   ├── __init__.py          # Public API — all exports listed here
│   ├── client.py            # RAITClient — main entry point
│   ├── config.py            # Settings class (pydantic-settings)
│   ├── scheduler.py         # Scheduler wrapping APScheduler BackgroundScheduler
│   ├── models.py            # EvaluationInput Pydantic model
│   ├── constants.py         # Metric enum (22 Azure metrics)
│   ├── exceptions.py        # Exception hierarchy rooted at RAITConnectorError
│   ├── auth.py              # AuthenticationService (OAuth2 client credentials)
│   ├── encryption.py        # Encryptor (RSA-OAEP + AES-256-GCM)
│   ├── telemetry.py         # TelemetryClient (Azure Monitor Log Analytics)
│   ├── http.py              # HttpSessionFactory with retry adapter
│   └── evaluators/
│       ├── __init__.py
│       ├── orchestrator.py  # EvaluatorOrchestrator — parallel metric runner
│       ├── registry.py      # Metric name → Azure evaluator class mapping
│       └── base.py
├── tests/
│   ├── test_auth.py
│   ├── test_config.py
│   ├── test_constants.py
│   ├── test_encryption.py
│   ├── test_evaluators.py
│   ├── test_http.py
│   ├── test_models.py
│   ├── test_scheduler.py
│   └── test_telemetry.py
├── docs/
├── pyproject.toml
└── mkdocs.yml
```

**Recommended reading order:**

1. `__init__.py` — see what the public surface is
2. `config.py` — understand all settings before anything else
3. `client.py` — the main class; all public operations flow through here
4. `scheduler.py` — how recurring jobs are configured and run
5. `evaluators/registry.py` — which Azure evaluator class maps to which metric

---

## 4. Configuration

**File:** `src/rait_connector/config.py`

Single `Settings` class backed by `pydantic-settings`. Reads from environment variables (case-insensitive). A module-level `settings` singleton is instantiated at import time.

```python
from rait_connector import settings

print(settings.rait_api_url)
```

**Override at runtime** — pass kwargs to `RAITClient(...)`. Internally `Settings.merge_with(**overrides)` creates a shallow copy, filtering out `None` values so partial overrides are safe:

```python
client = RAITClient(rait_api_url="https://staging.api.example.com")
```

**Azure AD side-effect** — when `azure_client_id`, `azure_tenant_id`, or `azure_client_secret` are set (either from env or via override), `Settings` writes them to `os.environ` so that `DefaultAzureCredential` can pick them up automatically.

**URL validation** — `rait_api_url`, `azure_openai_endpoint`, `azure_ai_project_url`, and `rait_ingest_url` are stripped of trailing slashes on load.

---

## 5. RAITClient

**File:** `src/rait_connector/client.py`

The main entry point. All public operations flow through this class. Internally it lazily initialises collaborators on first use:

| Collaborator | Lazy init trigger |
|---|---|
| `AuthenticationService` | Created in `__init__` |
| `Encryptor` | First call that needs to POST encrypted data |
| `AzureOpenAIModelConfiguration` | First `evaluate()` call |
| `DefaultAzureCredential` | First `evaluate()` call |
| `TelemetryClient` | First `fetch_telemetry()` call |

### Public methods

| Method | Description |
|---|---|
| `evaluate(...)` | Run all enabled metrics against a prompt/response pair and PUT to the ingest URL with `log_type="evaluation"`. Also triggers calibration Flow 1 in a background thread if prompts are available. |
| `get_enabled_metrics(model_name, model_version, model_environment)` | GET `/api/model-registry/enabled-metrics/`. Cached in memory; pass `force_refresh=True` to bypass cache. |
| `fetch_telemetry(**kwargs)` | Query Azure Log Analytics. Returns `{table_name: [row_dicts]}`. |
| `post_telemetry(...)` | PUT telemetry result to the ingest URL with `log_type="telemetry"`. |
| `get_calibration_prompts(...)` | GET `/api/calibrator/calibration-run-prompts/`. Returns `{calibration_run_id, prompts}`. Used by Flow 1. |
| `get_model_calibration_prompts(...)` | GET `/api/model-registry/calibration-prompts/`. Returns `[{prompt_id, prompt_text}]`. Used by Flow 3. |
| `get_prompts_response(...)` | GET `/api/calibrator/get-prompts-response/`. Returns flattened list of `{prompt_response_id, prompt_text}`. Used by Flow 2. |
| `update_prompts_response(responses, ...)` | POST to `/api/calibrator/update-prompts-response/`. Used by Flow 2. |
| `post_calibration_responses(...)` | PUT to the ingest URL with `log_type="calibration"`. Used by Flow 3. |

### `evaluate()` parameter reference

```python
client.evaluate(
    prompt_id="abc-123",              # unique ID for this prompt/response pair
    prompt_url="https://…",           # URL reference to the prompt
    timestamp="2025-01-01T00:00:00Z", # ISO 8601
    model_name="gpt-4",
    model_version="1.0",
    query="What is AI?",              # the user's input
    response="AI is…",                # the LLM's output
    environment="production",
    purpose="monitoring",
    ground_truth="",      # optional; enables ground-truth metrics when provided
    context="",           # optional; enables context-aware metrics when provided
    parallel=True,        # run evaluators concurrently (ThreadPoolExecutor)
    max_workers=5,        # thread pool size
    fail_fast=False,      # if True, stop and raise on the first metric failure
    connector_logs="",    # optional logs to attach to the payload
    for_calibration=False,# internal; set True when called from calibration Flow 1
    custom_fields={},     # extra fields passed through to model_data_logs payload
)
```

**Return value:** `dict` containing `prompt_data`, `evaluated_dimensions`, and the raw POST response from the API.

### `model_code` query parameter

Across all calibration and metrics endpoints, the model is identified by a single string: `"{model_name} {model_version} ({environment})"`. This is constructed internally from the three separate arguments.

---

## 6. Authentication

**File:** `src/rait_connector/auth.py`

`AuthenticationService` implements OAuth2 client credentials flow against `POST /api/model-registry/token/`.

- Token is cached in memory until `expires_in - 30 seconds` (30 s clock skew).
- Thread-safe: uses a `threading.Lock` with double-checked locking on refresh.
- Any caller that needs auth headers calls `service.get_auth_headers()`, which returns `{"Authorization": "Bearer <token>"}`.

```python
# Internal usage in client.py
headers = self._auth_service.get_auth_headers()
response = self._session.get(url, headers=headers, timeout=30)
```

Requires: `RAIT_API_URL`, `RAIT_CLIENT_ID`, `RAIT_CLIENT_SECRET`.

---

## 7. Encryption

**File:** `src/rait_connector/encryption.py`

Hybrid encryption: RSA-OAEP wraps an ephemeral AES-256-GCM key. This is the same scheme used by the RAIT Scoring Engine for decryption.

### Scheme

- **Key exchange:** RSA-OAEP with SHA-256
- **Payload encryption:** AES-256-GCM (256-bit key, 96-bit nonce, 128-bit auth tag)

### Binary package format

```text
[4 bytes]    Length of RSA-encrypted AES key (little-endian uint32)
[N bytes]    RSA-encrypted AES-256 key
[12 bytes]   AES-GCM nonce
[16 bytes]   AES-GCM authentication tag
[M bytes]    AES-GCM ciphertext
```

### Usage in the client

`RAITClient._get_encryptor()` fetches the RSA public key from `GET /api/model-registry/public-key/` on first use, constructs an `Encryptor(public_key=pem)`, and caches it. The encrypted bytes are base64-encoded before being embedded in the JSON payload.

```python
encryptor = Encryptor(public_key=pem_bytes)
encrypted_bytes = encryptor.encrypt(json.dumps(payload).encode())
b64_blob = base64.b64encode(encrypted_bytes).decode()
```

The RAIT Scoring Engine holds the corresponding RSA private key and decrypts payloads on receipt.

---

## 8. Evaluation Pipeline

### 8.1 EvaluatorOrchestrator

**File:** `src/rait_connector/evaluators/orchestrator.py`

`EvaluatorOrchestrator.evaluate_metrics()` is called by `RAITClient.evaluate()` with:

- `prompt_data` — dict with `query`, `response`, `context`, `ground_truth`
- `ethical_dimensions` — list of dimension dicts returned by `get_enabled_metrics()`
- `parallel=True`, `max_workers=5`, `fail_fast=False`

#### Execution flow

```text
For each metric in ethical_dimensions[*].dimension_metrics[*]:
  1. can_evaluate_metric(metric_name, has_context, has_ground_truth)
     → skip silently if required fields are absent
  2. create_evaluator(metric_name, model_config, azure_ai_project, credential)
  3. evaluator(query=…, response=…, [context=…], [ground_truth=…])
  4. Write result into metric["metric_metadata"]
```

When `parallel=True` and there is more than one metric, steps 1–4 run concurrently via `ThreadPoolExecutor`. Failures per metric are logged; execution continues for remaining metrics unless `fail_fast=True`.

### 8.2 Evaluator Registry

**File:** `src/rait_connector/evaluators/registry.py`

`EVALUATOR_CONFIG` maps each `Metric` enum value to its Azure evaluator class and requirements:

| Field | Meaning |
|---|---|
| `class` | Azure evaluator class to instantiate |
| `needs_project` | Requires `azure_ai_project` — makes a cloud safety API call |
| `needs_model_config` | Requires `model_config` — calls Azure OpenAI as a judge |
| `requires_context` | Will be skipped if `context` is empty |
| `requires_ground_truth` | Will be skipped if `ground_truth` is empty |

`create_evaluator(metric_name, ...)` looks up the config, constructs kwargs, and returns a ready-to-call evaluator instance. `can_evaluate_metric(metric_name, has_context, has_ground_truth)` is the pre-flight check.

### 8.3 Metric Reference

All 22 metrics are defined in `Metric` enum in `src/rait_connector/constants.py`.

**Safety / Content** — require `azure_ai_project` (cloud safety API call):

| Metric | Notes |
|---|---|
| `HATE_AND_UNFAIRNESS_AZURE` | |
| `CONTENT_SAFETY_AZURE` | |
| `PROTECTED_MATERIALS_AZURE` | |
| `CODE_VULNERABILITY_AZURE` | |
| `SEXUAL_AZURE` | |
| `VIOLENCE_AZURE` | |
| `SELF_HARM_AZURE` | |
| `GROUNDEDNESS_PRO_AZURE` | Also requires `context` |

**Quality / AI-judged** — require `model_config` (Azure OpenAI call):

| Metric | Notes |
|---|---|
| `COHERENCE_AZURE` | |
| `FLUENCY_AZURE` | |
| `RELEVANCE_AZURE` | |
| `RESPONSE_COMPLETENESS_AZURE` | Also requires `ground_truth` |
| `GROUNDEDNESS_AZURE` | Also requires `context` |
| `RETRIEVAL_AZURE` | Also requires `context` |
| `QA_AZURE` | Requires both `context` and `ground_truth` |
| `SIMILARITY_AZURE` | Also requires `ground_truth` |
| `UNGROUNDED_ATTRIBUTES_AZURE` | Also requires `context` |

**Statistical** — no LLM call; only require `ground_truth`:

| Metric | Notes |
|---|---|
| `F1_SCORE_AZURE` | |
| `BLEU_AZURE` | |
| `GLEU_AZURE` | |
| `ROUGE_AZURE` | Uses ROUGE-L variant |
| `METEOR_AZURE` | |

Metrics that cannot run due to missing inputs are silently skipped (logged at `DEBUG` level). They do not raise errors.

---

## 9. Calibration Flows

There are three distinct calibration flows. They are easy to confuse — read this section carefully.

### 9.1 Flow 1 — Triggered by `evaluate()`

**Goal:** Evaluate the model against a calibration run's prompts using the normal evaluators, and report back.

**Trigger:** Every call to `client.evaluate(...)` (unless `for_calibration=True`).

```text
evaluate() called
  → get_calibration_prompts()
    → GET /api/calibrator/calibration-run-prompts/
  → if prompts returned AND model_key not in _running_calibrations:
      add model_key to _running_calibrations
      launch daemon thread: _run_background_calibration()
        → for each prompt:
            evaluate(for_calibration=True)
              → PUT {rait_ingest_url}/v1/{key} (log_type="calibration")
        → remove model_key from _running_calibrations
  → continue with normal evaluation flow
```

Guard: `_running_calibrations` (a `set` on the client) prevents duplicate background threads for the same `(model_name, model_version, environment)` tuple.

### 9.2 Flow 2 — Calibrator Response Collection

**Goal:** Collect raw model responses for prompts the calibrator service needs answered.

**Trigger:** `Scheduler.add_calibration_job(...)` on each interval.

```text
_calibration_task() (inside scheduler)
  → get_prompts_response()
    → GET /api/calibrator/get-prompts-response/
    → flatten grouped response: each group has a "prompts" list
  → for each prompt { prompt_response_id, prompt_text }:
      model_response = invoke_model(prompt_text)
  → update_prompts_response(collected)
    → POST /api/calibrator/update-prompts-response/
```

This flow does **not** run any evaluators and does **not** post to the ingest URL.

### 9.3 Flow 3 — Model-Registry Calibration

**Goal:** Collect model responses for prompts stored in the model registry and post them as calibration logs.

**Trigger:** `Scheduler.add_calibration_job(...)` on each interval (runs in the same task as Flow 2, after it).

```text
_calibration_task() (inside scheduler, continues after Flow 2)
  → get_model_calibration_prompts()
    → GET /api/model-registry/calibration-prompts/
  → for each prompt { prompt_id, prompt_text }:
      response_text = invoke_model(prompt_text)
  → post_calibration_responses(calibration_responses)
    → PUT {rait_ingest_url}/v1/{key} (log_type="calibration")
```

### Summary

| | Flow 1 | Flow 2 | Flow 3 |
|---|---|---|---|
| **Trigger** | Each `evaluate()` | Scheduler `add_calibration_job` | Scheduler `add_calibration_job` |
| **Prompt source** | `/api/calibrator/calibration-run-prompts/` | `/api/calibrator/get-prompts-response/` | `/api/model-registry/calibration-prompts/` |
| **Calls `invoke_model`?** | No | Yes | Yes |
| **Runs evaluators?** | Yes | No | No |
| **Posts to ingest URL?** | Yes (`log_type="calibration"`) | No | Yes (`log_type="calibration"`) |
| **Other endpoint?** | — | `update-prompts-response` | — |

---

## 10. Telemetry

**File:** `src/rait_connector/telemetry.py`

`TelemetryClient` wraps Azure's `LogsQueryClient` to query Log Analytics.

**Supported tables:** `AppDependencies`, `AppExceptions`, `AppAvailabilityResults`

```python
# Standalone
from azure.identity import DefaultAzureCredential
from rait_connector import TelemetryClient
from datetime import timedelta

tc = TelemetryClient(
    credential=DefaultAzureCredential(),
    workspace_id="<log-analytics-workspace-id>",
)

# Fetch one table
rows = tc.fetch("AppDependencies", timespan=timedelta(days=1))

# Fetch all tables
data = tc.fetch_all(
    tables=["AppDependencies", "AppExceptions"],
    timespan=timedelta(days=1),
    limit=500,  # optional row cap per table
)
# data = {"AppDependencies": [{...}, ...], "AppExceptions": [...]}
```

`fetch_all()` is also called internally by `RAITClient.fetch_telemetry()`. Per-table errors are caught, logged, and return an empty list so other tables are not affected.

Row values are serialised to JSON-compatible types (`datetime` → ISO string, unknown → `str`).

---

## 11. Scheduler

**File:** `src/rait_connector/scheduler.py`

`Scheduler` wraps APScheduler 3.x `BackgroundScheduler`. All jobs run in daemon threads. Multiple `Scheduler` instances can coexist.

### Interval formats

| Format | Example |
|---|---|
| Named shorthand | `"hourly"`, `"daily"`, `"weekly"` |
| Cron expression | `"0 9 * * MON-FRI"` |
| `datetime.timedelta` | `timedelta(hours=6)` |
| Seconds (int/float) | `3600` |

### Built-in jobs

```python
scheduler = Scheduler(client)

# Telemetry: fetch + post on schedule
scheduler.add_telemetry_job(
    model_name="gpt-4",
    model_version="1.0",
    model_environment="production",
    model_purpose="monitoring",
    interval="daily",
    on_result=lambda r: print(r),  # optional callback after each run
    timespan=timedelta(days=7),    # forwarded to fetch_telemetry
)

# Calibration: runs Flow 2 + Flow 3 on schedule
scheduler.add_calibration_job(
    model_name="gpt-4",
    model_version="1.0",
    environment="production",
    model_purpose="monitoring",
    invoke_model=lambda prompt: my_llm(prompt),
    interval="weekly",
)
```

### Generic job registration

```python
# Function call style
scheduler.add_job(my_func, interval="daily", name="my_job")

# Decorator style
@scheduler.job(interval="daily")
def my_job():
    ...
```

Job names must be unique per `Scheduler` instance. Re-registering the same name replaces the existing job (`replace_existing=True`).

### Lifecycle

```python
scheduler.start()               # non-blocking — runs in background daemon thread
scheduler.start(blocking=True)  # blocks until Ctrl+C, then calls stop()
scheduler.stop()                # graceful shutdown — waits for running jobs to finish
scheduler.is_running()          # bool
```

### Introspection

```python
scheduler.status()
# [{"id": "rait_telemetry", "trigger": "...", "next_run": "2025-01-02T09:00:00", "is_executing": False}]

scheduler.running_jobs()
# ["rait_telemetry"]   # IDs of jobs currently executing

scheduler.history(job_id="rait_telemetry", limit=10)
# [{"job_id": "…", "started_at": "…", "finished_at": "…", "success": True, "error": None}]
```

History is a ring buffer (default 100 records, configurable via `Scheduler(client, max_history=…)`).

**Job ID naming:**

- Telemetry: always `"rait_telemetry"`
- Calibration: `"rait_calibration_{model_name}_{model_version}_{environment}"`
- Custom: defaults to `func.__name__`; pass `name=` to override

---

## 12. HTTP Layer

**File:** `src/rait_connector/http.py`

`HttpSessionFactory` creates `requests.Session` objects with a retry adapter pre-mounted on both `http://` and `https://`.

Default retry config:

| Setting | Default |
|---|---|
| Total retries | 3 |
| Backoff factor | 0.3 |
| Retry on status | 429, 500, 502, 503, 504 |
| Allowed methods | GET, POST |

`HttpSessionFactory.get_default_session()` returns a cached (singleton) session. `HttpSessionFactory.create_session(retry_config)` creates a fresh session with custom config.

---

## 13. RAIT API Alignment

### Endpoints used

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/model-registry/token/` | Get OAuth2 Bearer token |
| GET | `/api/model-registry/public-key/` | Get RSA public key for encryption |
| GET | `/api/model-registry/enabled-metrics/` | Get active metrics config |
| PUT | `{rait_ingest_url}/v1/{key}` | Post evaluation / telemetry / calibration data |
| GET | `/api/model-registry/calibration-prompts/` | Get calibration prompts (Flow 3) |
| GET | `/api/calibrator/calibration-run-prompts/` | Get calibration run prompts (Flow 1) |
| GET | `/api/calibrator/get-prompts-response/` | Get prompts needing responses (Flow 2) |
| POST | `/api/calibrator/update-prompts-response/` | Submit collected responses (Flow 2) |

### PUT {rait_ingest_url}/v1/{key}

Fields in the request body and where they come from:

| Field | Required | Source |
|---|---|---|
| `model_name` | Yes | `evaluate()` / `post_telemetry()` argument |
| `model_version` | Yes | `evaluate()` / `post_telemetry()` argument |
| `model_environment` | Yes | `evaluate()` / `post_telemetry()` argument |
| `model_purpose` | Yes | `evaluate()` / `post_telemetry()` argument |
| `created_at` | Yes | Caller-supplied `timestamp` argument |
| `model_data_logs` | Yes | RSA-encrypted + base64-encoded payload blob |
| `log_type` | Yes | `"evaluation"`, `"telemetry"`, or `"calibration"` |
| `connector_logs` | No | Optional string passed to `evaluate()` |

### POST /api/calibrator/update-prompts-response/

| Field | Source |
|---|---|
| `model_code` | `"{model_name} {model_version} ({environment})"` |
| `responses` | List of `{prompt_response_id, prompt_text, model_response}` |

---

## 14. Environment Variables

All variables are case-insensitive. Set them in the environment or pass as constructor kwargs to `RAITClient(...)`.

### RAIT API

| Variable | Required | Description |
|---|---|---|
| `RAIT_API_URL` | Yes | RAIT API base URL (no trailing slash) |
| `RAIT_CLIENT_ID` | Yes | OAuth2 client ID |
| `RAIT_CLIENT_SECRET` | Yes | OAuth2 client secret |
| `RAIT_INGEST_URL` | Yes | API Gateway ingest URL (all log types: evaluation, telemetry, calibration) |

### Azure AD

| Variable | Required | Description |
|---|---|---|
| `AZURE_CLIENT_ID` | Yes* | Service principal client ID |
| `AZURE_TENANT_ID` | Yes* | Azure AD tenant ID |
| `AZURE_CLIENT_SECRET` | Yes* | Service principal secret |

*Required for Azure AI Evaluation and Azure Monitor. Automatically forwarded to `os.environ` so `DefaultAzureCredential` picks them up.

### Azure OpenAI

| Variable | Default | Description |
|---|---|---|
| `AZURE_OPENAI_ENDPOINT` | — | Azure OpenAI endpoint URL |
| `AZURE_OPENAI_API_KEY` | — | Azure OpenAI API key |
| `AZURE_OPENAI_DEPLOYMENT` | — | Deployment name for the chat model |
| `AZURE_OPENAI_API_VERSION` | `2024-12-01-preview` | API version |

### Azure AI Project

| Variable | Description |
|---|---|
| `AZURE_SUBSCRIPTION_ID` | Azure subscription ID |
| `AZURE_RESOURCE_GROUP` | Resource group name |
| `AZURE_PROJECT_NAME` | Azure AI project name |
| `AZURE_ACCOUNT_NAME` | Azure account name |
| `AZURE_AI_PROJECT_URL` | Alternative to the sub/rg/project triple; takes precedence when set |

### Azure Monitor

| Variable | Description |
|---|---|
| `AZURE_LOG_ANALYTICS_WORKSPACE_ID` | Log Analytics workspace ID for telemetry queries |

---

## 15. Development Setup

### Prerequisites

- Python 3.12+
- [`uv`](https://github.com/astral-sh/uv) package manager

### Install

```bash
# Install all dependencies including dev group
uv sync --group dev
```

### Run tests

```bash
# Full test suite (coverage enabled by default via pyproject.toml)
uv run pytest

# Single file with verbose output
uv run pytest tests/test_scheduler.py -v

# Disable coverage for a quick run
uv run pytest --no-cov
```

Coverage runs automatically on every `uv run pytest` call. The `[tool.pytest.ini_options]` section in `pyproject.toml` sets `--cov=src --cov-report=term-missing --tb=short` as defaults.

**Always use `uv run pytest`.** Do not use bare `pytest` or `python -m pytest` — the virtual environment may not be on `PATH`.

### Preview docs

```bash
uv run mkdocs serve   # live-reload at http://127.0.0.1:8000
uv run mkdocs build   # build static site to site/
```

### Testing background scheduler jobs

Scheduler jobs run in daemon threads. Use `threading.Event` to synchronise — do not sleep:

```python
import threading
from unittest.mock import MagicMock

def test_calibration_job_fires():
    mock_client = MagicMock()
    done = threading.Event()

    mock_client.get_prompts_response.side_effect = (
        lambda **kw: done.set() or []
    )

    scheduler = Scheduler(mock_client)
    scheduler.add_calibration_job(
        model_name="m", model_version="v", environment="e",
        model_purpose="p", invoke_model=lambda p: "r",
        interval=1,           # 1 second for tests
        run_immediately=True, # fire once immediately on start
    )
    scheduler.start()
    fired = done.wait(timeout=5)  # block up to 5 s
    scheduler.stop()

    assert fired, "calibration job did not fire within 5 seconds"
```

Key points:

- `run_immediately=True` triggers a run as soon as the scheduler starts.
- `done.wait(timeout=5)` returns `True` if the event was set within 5 seconds.
- The `side_effect` lambda returns `[]` (no prompts) so no actual model invocation happens.
- Always call `scheduler.stop()` in teardown to prevent thread leaks between tests.

### Exception hierarchy

```text
RAITConnectorError
├── AuthenticationError   — token fetch failed
├── EncryptionError       — public key fetch or encrypt/decrypt failed
├── MetricsError          — enabled-metrics fetch or evaluation POST failed
├── EvaluationError       — evaluator execution failed
├── TelemetryError        — Azure Monitor query or telemetry POST failed
├── CalibrationError      — any calibration API call failed
└── SchedulerError        — job registration or scheduler start failed
```

All exceptions are importable directly from `rait_connector`:

```python
from rait_connector import RAITConnectorError, EvaluationError
```
