# RAIT Connector

## What this service is

**RAIT Connector** is a Python library (pip package) that client applications install to send AI model evaluation payloads to the RAIT platform. It encrypts payloads with the RAIT Backend's RSA public key, sends them via `PUT {rait_ingest_url}/v1/{key}` to the API Gateway, and the **RAIT Scoring Engine** (`../rait_engine`) picks up the payload and runs scoring.

---

## Architecture

```mermaid
flowchart LR
    A[Client App] -->|evaluate / scheduler| C[RAIT Connector]
    C -->|PUT ingest_url/v1/key RSA-encrypted| AGW[API Gateway]
    AGW -->|S3 write + S3 event| SQS[SQS Queue]
    SQS --> E[RAIT Scoring Engine]
    E -->|write results| B[RAIT Backend API]
    B --> DB[(RAIT Backend DB)]
    DB -->|scoring config read-only| E
```

### Data Flow

1. `client.evaluate()` runs Azure AI evaluators locally and assembles a result payload
2. Payload is RSA-OAEP-encrypted (using the RAIT Backend's public key) and sent via `PUT {rait_ingest_url}/v1/{key}` to the API Gateway
3. API Gateway injects `org_id` and `client_id` from the Bearer JWT and writes the payload to S3
4. S3 triggers SQS, and the RAIT Scoring Engine picks it up and writes scoring results back to RAIT Backend

---

## Key Design Constraints

- **Client-side evaluations** — Azure AI evaluators run in the client process; RAIT Backend only receives encrypted output.
- **Payload encryption** — `model_data_logs` blob is always RSA-OAEP-encrypted before posting. The public key comes from the RAIT Backend at auth time.
- **No direct DB access** — all persistence goes through the RAIT Backend REST API.
- **Background calibration** — triggered automatically by `evaluate()` in a daemon thread; does not block the caller.
- **Scheduler is opt-in** — import `Scheduler` separately; it uses APScheduler `BackgroundScheduler`.

---

## Project Structure

```text
rait_connector/
├── src/rait_connector/
│   ├── __init__.py         # Public API: RAITClient, Scheduler
│   ├── client.py           # RAITClient — evaluate(), evaluate_batch(), calibration
│   ├── scheduler.py        # Scheduler — add_telemetry_job(), add_calibration_job()
│   ├── auth.py             # OAuth2 token management
│   ├── config.py           # Settings (pydantic-settings, reads env vars / .env)
│   ├── constants.py        # Shared constants (log_type values, etc.)
│   ├── encryption.py       # RSA-OAEP + AES-256-GCM hybrid encryption
│   ├── exceptions.py       # Library-specific exceptions
│   ├── http.py             # Thin HTTP wrapper (requests)
│   ├── models.py           # Pydantic models for API payloads
│   ├── telemetry.py        # Telemetry helpers
│   └── evaluators/         # Azure AI evaluator wrappers (one file per metric group)
├── tests/
├── docs/                   # MkDocs + mkdocstrings
├── mkdocs.yml
├── pyproject.toml
├── uv.lock
└── Dockerfile
```

---

## Stack

| Component | Technology |
|-----------|------------|
| Language | Python 3.12+ |
| Package manager | uv |
| Config | pydantic-settings |
| HTTP | requests |
| Evaluators | azure-ai-evaluation |
| Monitoring | azure-monitor-query |
| Scheduler | APScheduler 3.x (BackgroundScheduler) |
| Encryption | cryptography (RSA-OAEP + AES-256-GCM) |
| Auth | OAuth2 client credentials |

---

## API Endpoints Used

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `{rait_ingest_url}/v1/{key}` | PUT | Submit evaluation, telemetry, or calibration logs (all log types) |
| `/api/model-registry/public-key/` | GET | Fetch RSA public key for encryption |
| `/api/model-registry/enabled-metrics/` | GET | Fetch active metrics config |
| `/api/model-registry/calibration-prompts/` | GET | Fetch calibration prompts for a model (Flow 3) |
| `/api/calibrator/calibration-run-prompts/` | GET | Fetch calibration run prompts (Flow 1) |
| `/api/calibrator/get-prompts-response/` | GET | Fetch prompts needing model responses (Flow 2) |
| `/api/calibrator/update-prompts-response/` | POST | Submit collected responses (Flow 2) |

The `log_type` field in the PUT body controls processing in the engine:

- `"telemetry"` — usage/performance stats only
- `"evaluation"` — full scoring pipeline triggered in the engine
- `"calibration"` — calibration scoring pipeline triggered in the engine

---

## Three Calibration Flows

**Flow 1** — triggered automatically inside `evaluate()`:

1. `get_calibration_prompts()` checks if calibration prompts are available
2. Spawns `_run_background_calibration()` in a daemon thread (once per model+version+environment)
3. Calls `evaluate(for_calibration=True)` on those prompts
4. Posts result with `log_type="calibration"`

**Flow 2** — scheduler `add_calibration_job()` using calibrator API:

1. `get_prompts_response()` → `invoke_model()` → `update_prompts_response()`

**Flow 3** — scheduler `add_calibration_job()` using model-data-logs:

1. `get_model_calibration_prompts()` → `invoke_model()` → `post_calibration_responses()` (with `log_type="calibration"`)

---

## Development

```bash
# Install all dependencies (including dev)
uv sync --dev

# Run tests
uv run pytest

# Run tests without coverage (faster)
uv run pytest --no-cov

# Serve docs locally
uv run mkdocs serve

# Build docs
uv run mkdocs build
```

> Always use `uv run pytest`, not bare `pytest` or `python -m pytest`.

---

## Changelog

Maintained in [CHANGELOG.md](CHANGELOG.md) following [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) format and [Semantic Versioning](https://semver.org/spec/v2.0.0.html). Update the `[Unreleased]` section with every notable change; it becomes the release entry when a version is tagged.

---

## Contributing

### Environments and branch flow

| Branch | Environment |
|---|---|
| `development` | Development |
| `main` | Production |

Changes must be promoted through environments in order:

```mermaid
flowchart LR
    F[feature/fix branch] -->|PR| D[development]
    D -->|PR via release/development-to-main| M[main]
```

Direct PRs to `main` bypass environment testing and must not be used.

### Branch naming

Follows [Conventional Branch](https://conventional-branch.github.io/): `<type>/<description>`

| Type | Use for |
|------|---------|
| `feature/` or `feat/` | New functionality |
| `bugfix/` or `fix/` | Bug fixes |
| `hotfix/` | Urgent production fixes |
| `release/` | Release preparation |
| `chore/` | Everything else — docs, refactors, tests, CI, tooling |

Rules: lowercase and hyphens only; no consecutive or trailing hyphens; include ticket numbers when applicable (e.g. `feature/issue-123-add-batch-timeout`).

The protected branches `main`, `staging`, and `development` are exempt.
Direct pushes to these branches are not allowed — use a pull request.

### Commit messages

This repo uses [Conventional Commits](https://www.conventionalcommits.org/): `<type>(<scope>): <description>`

Common types: `feat`, `fix`, `docs`, `chore`, `refactor`, `test`, `style`, `ci`

---

## Related Services

- **RAIT Scoring Engine**: `../rait_engine` — SQS worker that processes evaluation payloads and computes RAI scores
- **RAIT Backend**: `../rait_backend` — owns all DB tables, exposes model-registry API, issues RSA public keys
