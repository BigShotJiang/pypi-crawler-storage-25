# RAIT Connector — Calibration Implementation Reference

This document shows how the Python RAIT Connector implements each calibration flow.
It is intended as a reference for teams building equivalent logic in other languages or frameworks.

For the full API specification see [CALIBRATION_INTEGRATION.md](CALIBRATION_INTEGRATION.md).

---

## Flow 1 — Background Calibration

**Trigger:** Called automatically inside `evaluate()` for every normal (non-calibration) evaluation. Runs once per `(model_name, model_version, environment)` combination — tracked in `_running_calibrations` to avoid duplicate threads.

### Entry point — `RAITClient.evaluate()` (`client.py`)

```python
def evaluate(self, prompt_id, prompt_url, timestamp, model_name, model_version,
             query, response, environment, purpose, ...):

    # Only check for calibration on normal (non-calibration) evaluations
    if not for_calibration:
        model_key = (model_name, model_version, environment)

        if model_key not in self._running_calibrations:
            try:
                calibration_data = self.get_calibration_prompts(
                    model_name=model_name,
                    model_version=model_version,
                    model_environment=environment,
                )
                calibration_prompts = calibration_data.get("prompts", [])

                if calibration_prompts:
                    self._running_calibrations.add(model_key)

                    # Fire-and-forget daemon thread — does not block the caller
                    calibration_thread = threading.Thread(
                        target=self._run_background_calibration,
                        args=(model_name, model_version, environment,
                              purpose, connector_logs, calibration_data),
                        daemon=True,
                    )
                    calibration_thread.start()

            except Exception as e:
                logger.error(f"Failed to check for calibration prompts: {e}")

    # Normal evaluation continues here regardless of calibration ...
```

### Step 1 — `get_calibration_prompts()` (`client.py`)

Calls `GET /api/calibrator/calibration-run-prompts/`.

```python
def get_calibration_prompts(self, model_name="", model_version="", model_environment=""):
    headers = self._auth_service.get_auth_headers()

    params = {}
    if model_name or model_version or model_environment:
        params["model_code"] = f"{model_name} {model_version} ({model_environment})"

    response = self._session.get(
        f"{self.settings.rait_api_url}/api/calibrator/calibration-run-prompts/",
        headers=headers,
        params=params,
        timeout=30,
    )
    response.raise_for_status()

    data = response.json()
    calibration_data = data.get("data", {})
    prompts = calibration_data.get("prompts", [])

    return {
        "calibration_run_id": calibration_data.get("calibration_run_id", ""),
        "prompts": prompts,
    }
```

### Step 2 — `_run_background_calibration()` (`client.py`)

Iterates over each calibration prompt and calls `evaluate()` with `for_calibration=True`.

```python
def _run_background_calibration(self, model_name, model_version, environment,
                                 purpose, connector_logs, calibration_data):
    model_key = (model_name, model_version, environment)
    try:
        calibration_run_id = calibration_data.get("calibration_run_id", "")
        calibration_prompts = calibration_data.get("prompts", [])

        for cp in calibration_prompts:
            try:
                self.evaluate(
                    prompt_id=cp.get("prompt_id", ""),
                    prompt_response_id=cp.get("prompt_response_id", ""),
                    calibration_run_id=calibration_run_id,
                    prompt_url=cp.get("prompt_url", ""),
                    timestamp=cp.get("timestamp", datetime.now().isoformat()),
                    model_name=model_name,
                    model_version=model_version,
                    query=cp.get("prompt_text", ""),
                    response=cp.get("response_text", ""),
                    ground_truth=cp.get("ground_truth", ""),
                    context=cp.get("context", ""),
                    environment=environment,
                    purpose=purpose,
                    connector_logs=connector_logs,
                    for_calibration=True,      # <-- marks this as calibration
                )
            except Exception as e:
                logger.error(f"Background calibration failed for prompt {cp.get('prompt_id')}: {e}")
    finally:
        self._running_calibrations.discard(model_key)
```

### Step 3 — `_post_evaluation()` (`client.py`)

Called by `evaluate()` after running the evaluators. Encrypts the result and PUTs it to the ingest URL.

```python
def _post_evaluation(self, evaluation_result, connector_logs="", for_calibration=False, custom_fields=None):
    encryptor = self._get_encryptor()

    model_data_logs = {
        "prompt_id":           evaluation_result["prompt_id"],
        "prompt_response_id":  evaluation_result.get("prompt_response_id", ""),
        "calibration_run_id":  evaluation_result.get("calibration_run_id", ""),
        "prompt_url":          evaluation_result["prompt_url"],
        "ethical_dimensions":  evaluation_result["ethical_dimensions"],
        "for_calibration":     for_calibration,
    }
    if custom_fields:
        model_data_logs.update(custom_fields)

    encrypted_model_data_b64 = base64.b64encode(
        encryptor.encrypt(json.dumps(model_data_logs, ensure_ascii=False))
    ).decode("utf-8")

    encrypted_logs_b64 = base64.b64encode(
        encryptor.encrypt(connector_logs)
    ).decode("utf-8")

    payload = {
        "model_name":        evaluation_result["model_name"],
        "model_version":     evaluation_result["model_version"],
        "model_environment": evaluation_result["environment"],
        "model_purpose":     evaluation_result["purpose"],
        "created_at":        evaluation_result["timestamp"],
        "model_data_logs":   encrypted_model_data_b64,
        "connector_logs":    encrypted_logs_b64,
        "log_type":          "evaluation",          # always "evaluation" for Flow 1
    }

    headers = self._auth_service.get_auth_headers()
    raw_model_code = (
        f"{evaluation_result['model_name']} "
        f"{evaluation_result['model_version']} "
        f"({evaluation_result['environment']})"
    )
    key = self._build_key(requests.utils.quote(raw_model_code, safe=""))

    response = self._session.put(
        f"{self.settings.rait_ingest_url}/v1/{key}",
        json=payload,
        headers=headers,
        timeout=30,
    )
    response.raise_for_status()
```

### Key format (`_build_key`)

```python
def _build_key(self, model_code: str) -> str:
    # model_code is already URL-encoded by the caller
    client_id    = self._auth_service.client_id
    datetime_str = datetime.now().strftime("%Y%m%dT%H%M%S")
    return f"{client_id}/{model_code}/{datetime_str}/{uuid.uuid4()}"
```

---

## Flow 2 — Calibrator Response Collection

**Trigger:** `Scheduler.add_calibration_job()` — runs on the configured interval (default: weekly).

### Scheduler registration (`scheduler.py`)

```python
scheduler.add_calibration_job(
    model_name="gpt-4",
    model_version="1.0",
    environment="production",
    model_purpose="monitoring",
    invoke_model=lambda prompt: my_llm(prompt),  # your model callable
    interval="weekly",
)
```

### Internal task (`scheduler.py` — `_calibration_task` inside `add_calibration_job`)

```python
# ── Flow 2: calibrator prompt responses ──────────────────────────────────

prompts = self._client.get_prompts_response(
    model_name=model_name,
    model_version=model_version,
    model_environment=environment,
)

if prompts:
    collected = []
    for prompt in prompts:
        prompt_response_id = prompt.get("prompt_response_id", "")
        prompt_text        = prompt.get("prompt_text", "")
        try:
            model_response = invoke_model(prompt_text)
            collected.append({
                "prompt_response_id": prompt_response_id,
                "model_response":     model_response,
            })
        except Exception as exc:
            logger.error("Flow 2: failed to invoke model for %s: %s", prompt_response_id, exc)

    if collected:
        self._client.update_prompts_response(
            responses=collected,
            model_name=model_name,
            model_version=model_version,
            model_environment=environment,
        )
```

### Step 1 — `get_prompts_response()` (`client.py`)

Calls `GET /api/calibrator/get-prompts-response/`. Flattens the grouped response into a flat list.

```python
def get_prompts_response(self, model_name="", model_version="", model_environment=""):
    headers = self._auth_service.get_auth_headers()

    params = {}
    if model_name or model_version or model_environment:
        params["model_code"] = f"{model_name} {model_version} ({model_environment})"

    response = self._session.get(
        f"{self.settings.rait_api_url}/api/calibrator/get-prompts-response/",
        headers=headers,
        params=params,
        timeout=30,
    )
    response.raise_for_status()

    data   = response.json()
    groups = data.get("data", [])

    # API returns grouped prompts — flatten into a single list
    prompts = []
    for group in groups:
        prompts.extend(group.get("prompts", []))

    return prompts
```

### Step 2 — `update_prompts_response()` (`client.py`)

Calls `POST /api/calibrator/update-prompts-response/`. No encryption.

```python
def update_prompts_response(self, responses, model_name="", model_version="", model_environment=""):
    headers = self._auth_service.get_auth_headers()

    model_code = f"{model_name} {model_version} ({model_environment})"
    payload = {
        "model_code": model_code,
        "responses":  responses,   # [{"prompt_response_id": "...", "model_response": "..."}]
    }

    response = self._session.post(
        f"{self.settings.rait_api_url}/api/calibrator/update-prompts-response/",
        json=payload,
        headers=headers,
        timeout=30,
    )
    response.raise_for_status()

    return {"status_code": response.status_code, "response": response.text}
```

---

## Flow 3 — Model-Registry Calibration

**Trigger:** Same `Scheduler.add_calibration_job()` call as Flow 2 — both flows run inside the same scheduled task.

### Internal task (`scheduler.py` — continues from Flow 2)

```python
# ── Flow 3: model-registry calibration prompts ───────────────────────────

cal_prompts = self._client.get_model_calibration_prompts(
    model_name=model_name,
    model_version=model_version,
    model_environment=environment,
)

if cal_prompts:
    calibration_responses = []
    for cp in cal_prompts:
        prompt_id   = cp.get("prompt_id", "")
        prompt_text = cp.get("prompt_text", "")
        try:
            response_text = invoke_model(prompt_text)
            calibration_responses.append({
                "prompt_id":     prompt_id,
                "response_text": response_text,
            })
        except Exception as exc:
            logger.error("Flow 3: failed to invoke model for %s: %s", prompt_id, exc)

    if calibration_responses:
        self._client.post_calibration_responses(
            model_name=model_name,
            model_version=model_version,
            model_environment=environment,
            model_purpose=model_purpose,
            calibration_responses=calibration_responses,
        )
```

### Step 1 — `get_model_calibration_prompts()` (`client.py`)

Calls `GET /api/model-registry/calibration-prompts/`.

```python
def get_model_calibration_prompts(self, model_name="", model_version="", model_environment=""):
    headers = self._auth_service.get_auth_headers()

    params = {}
    if model_name or model_version or model_environment:
        params["model_code"] = f"{model_name} {model_version} ({model_environment})"

    response = self._session.get(
        f"{self.settings.rait_api_url}/api/model-registry/calibration-prompts/",
        headers=headers,
        params=params,
        timeout=30,
    )
    response.raise_for_status()

    data    = response.json()
    prompts = data.get("data", [])

    return prompts   # [{"prompt_id": "...", "prompt_text": "..."}]
```

### Step 2 — `post_calibration_responses()` (`client.py`)

Encrypts the collected responses and PUTs them to the ingest URL with `log_type="calibration"`.

```python
def post_calibration_responses(self, model_name, model_version, model_environment,
                                model_purpose, calibration_responses, connector_logs=""):
    encryptor = self._get_encryptor()

    model_data_logs = {
        "calibration_responses": calibration_responses,
        # [{"prompt_id": "...", "response_text": "..."}]
    }

    encrypted_model_data_b64 = base64.b64encode(
        encryptor.encrypt(json.dumps(model_data_logs, ensure_ascii=False))
    ).decode("utf-8")

    encrypted_logs_b64 = base64.b64encode(
        encryptor.encrypt(connector_logs)
    ).decode("utf-8")

    payload = {
        "model_name":        model_name,
        "model_version":     model_version,
        "model_environment": model_environment,
        "model_purpose":     model_purpose,
        "created_at":        datetime.now().isoformat(),
        "model_data_logs":   encrypted_model_data_b64,
        "connector_logs":    encrypted_logs_b64,
        "log_type":          "calibration",          # <-- key difference from Flow 1
    }

    headers       = self._auth_service.get_auth_headers()
    raw_model_code = f"{model_name} {model_version} ({model_environment})"
    key           = self._build_key(requests.utils.quote(raw_model_code, safe=""))

    response = self._session.put(
        f"{self.settings.rait_ingest_url}/v1/{key}",
        json=payload,
        headers=headers,
        timeout=30,
    )
    response.raise_for_status()
```

---

## Authentication (`auth.py`)

All API calls go through `AuthenticationService`, which caches the token and refreshes it automatically before expiry.

> **Note:** `client_id` and `client_secret` here are the **RAIT platform credentials** — not Azure or any other service credentials.

```python
class AuthenticationService:
    def get_token(self) -> str:
        if not self._needs_refresh():
            return self._token

        response = session.post(
            f"{self.api_url}/api/model-registry/token/",
            json={"client_id": self.client_id, "client_secret": self.client_secret},
            headers={"Content-Type": "application/json"},
            timeout=30,
        )
        response.raise_for_status()
        data = response.json()

        self._token      = data["access_token"]
        self._expires_at = now + float(data.get("expires_in", 300))
        return self._token

    def get_auth_headers(self) -> dict:
        return {"Authorization": f"Bearer {self.get_token()}"}
```

---

## Encryption (`encryption.py`)

`Encryptor.encrypt()` implements the hybrid RSA-OAEP + AES-256-GCM scheme described in the API guide.

```python
def encrypt(self, plaintext: str) -> bytes:
    # 1. Generate random AES-256 key and 12-byte nonce
    aes_key = os.urandom(32)
    nonce   = os.urandom(12)

    # 2. AES-256-GCM encrypt
    aesgcm     = AESGCM(aes_key)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode("utf-8"), None)
    # ciphertext includes the 16-byte tag appended at the end
    tag        = ciphertext[-16:]
    ciphertext = ciphertext[:-16]

    # 3. RSA-OAEP encrypt the AES key
    encrypted_key = self._public_key.encrypt(
        aes_key,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )

    # 4. Assemble binary package
    key_length = len(encrypted_key).to_bytes(4, byteorder="little")
    return key_length + encrypted_key + nonce + tag + ciphertext

# Caller then base64-encodes the result:
# base64.b64encode(encryptor.encrypt(json.dumps(payload))).decode("utf-8")
```

The public key is fetched once from `GET /api/model-registry/public-key/` and cached for the lifetime of the `Encryptor` instance.
