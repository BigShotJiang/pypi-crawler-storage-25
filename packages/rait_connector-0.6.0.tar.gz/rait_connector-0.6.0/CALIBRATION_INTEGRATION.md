# RAIT Calibration — API Integration Guide

This document describes all API calls involved in RAIT calibration. It is intended for any team integrating calibration into their service, regardless of language or framework.

---

## Overview

Calibration is the process of having your model respond to a set of known prompts so RAIT can score those responses and build a performance baseline. There are **three calibration flows**, each serving a different trigger mechanism.

| Flow | Trigger | Description |
|------|---------|-------------|
| [Flow 1](#flow-1--background-calibration) | Automatically inside `evaluate()` | Fetch pre-paired prompts, evaluate them, post results to ingest |
| [Flow 2](#flow-2--calibrator-response-collection) | Scheduled job | Fetch prompts needing responses, collect from your model, submit back |
| [Flow 3](#flow-3--model-registry-calibration) | Scheduled job | Fetch calibration prompts from model registry, collect responses, post to ingest |

All requests require a Bearer token. See [Authentication](#authentication) first.

All API responses follow this standard envelope:

```json
{
  "status_code": 200,
  "message": "Data retrieved successfully.",
  "data": { ... }
}
```

---

## Authentication

### `POST /api/model-registry/token/`

Obtain a Bearer token before making any other call. Cache and reuse the token until near expiry.

**Request**

```
POST {RAIT_API_URL}/api/model-registry/token/
Content-Type: application/json
```

```json
{
  "client_id": "your-client-id",
  "client_secret": "your-client-secret"
}
```

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "...",
  "data": {
    "access_token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9...",
    "token_type": "Bearer",
    "expires_in": 3600
  }
}
```

Use the token in all subsequent requests:

```
Authorization: Bearer {access_token}
```

Re-authenticate when `expires_in` seconds have elapsed, or when any endpoint returns `401`.

**Status codes**

| Code | Meaning |
|------|---------|
| `200` | Token retrieved successfully |
| `400` | Invalid credentials or missing fields |
| `401` | Unauthorized |
| `500` | Internal error |

---

## Flow 1 — Background Calibration

Triggered automatically by `evaluate()`. Prompts from the calibrator API already include both a prompt text and a reference response. Your service evaluates them and posts the results to the ingest endpoint.

### Step 1 — Fetch calibration run prompts

**`GET /api/calibrator/calibration-run-prompts/`**

```
GET {RAIT_API_URL}/api/calibrator/calibration-run-prompts/?model_code={model_code}
Authorization: Bearer {access_token}
```

**Query parameters**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `model_code` | string | Yes | `"{model_name} {model_version} ({model_environment})"` — URL-encode when sending |

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "Data retrieved successfully.",
  "data": {
    "calibration_run_id": "cal-run-uuid-1234",
    "prompts": [
      {
        "prompt_id": "prompt-uuid-abc",
        "prompt_response_id": "pr-uuid-xyz",
        "prompt_text": "What is the capital of France?",
        "response_text": "Paris is the capital of France."
      }
    ]
  }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `calibration_run_id` | string | ID for this calibration run — include in results when posting back |
| `prompts` | array | Prompts to evaluate. Empty array means no calibration needed. |
| `prompts[].prompt_id` | string | Unique prompt ID |
| `prompts[].prompt_response_id` | string | ID linking prompt to a response record |
| `prompts[].prompt_text` | string | The prompt text |
| `prompts[].response_text` | string | Reference response already collected |

**If `prompts` is empty → no calibration needed, skip.**

**Status codes**

| Code | Meaning |
|------|---------|
| `200` | Success |
| `400` | Missing or invalid `model_code`, or model not found |
| `401` | Not authenticated |
| `403` | Not a Connector |
| `500` | Internal error |

---

### Step 2 — Post evaluation results to ingest

After running evaluations on the prompts, post the encrypted result to the ingest endpoint.

**`PUT {RAIT_INGEST_URL}/v1/{key}`**

```
PUT {RAIT_INGEST_URL}/v1/{key}
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Key format**

```
{client_id}/{url-encoded model_code}/{YYYYMMDDTHHmmss}/{uuid4}
```

Example:
```
my-client/gpt-4%201.0%20%28production%29/20250101T120000/f47ac10b-58cc-4372-a567-0e02b2c3d479
```

**Request body**

```json
{
  "model_name": "gpt-4",
  "model_version": "1.0",
  "model_environment": "production",
  "model_purpose": "monitoring",
  "created_at": "2025-01-01T12:00:00.000000",
  "model_data_logs": "<base64-encoded encrypted JSON>",
  "connector_logs": "<base64-encoded encrypted string>",
  "log_type": "evaluation"
}
```

**`model_data_logs` plaintext (before encryption)**

```json
{
  "prompt_id": "prompt-uuid-abc",
  "prompt_response_id": "pr-uuid-xyz",
  "calibration_run_id": "cal-run-uuid-1234",
  "prompt_url": "https://example.com/prompt/prompt-uuid-abc",
  "ethical_dimensions": [ ... ],
  "for_calibration": true
}
```

> `model_data_logs` and `connector_logs` must be encrypted before sending. See [Encryption](#encryption).

**Status codes**

| Code | Meaning |
|------|---------|
| `200` / `201` | Accepted |
| `401` | Not authenticated |
| `403` | Not a Connector |
| `400` | Invalid payload |

---

## Flow 2 — Calibrator Response Collection

Runs on a schedule. The calibrator API provides prompts that have no model response yet. Your service invokes the model and submits the collected responses back. **No encryption required for this flow.**

### Step 1 — Fetch prompts needing responses

**`GET /api/calibrator/get-prompts-response/`**

```
GET {RAIT_API_URL}/api/calibrator/get-prompts-response/?model_code={model_code}
Authorization: Bearer {access_token}
```

**Query parameters**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `model_code` | string | Yes | `"{model_name} {model_version} ({model_environment})"` — URL-encode when sending |

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "Data retrieved successfully.",
  "data": [
    {
      "prompt_group_id": "group-uuid-001",
      "group_name": "Safety Prompts",
      "prompt_class": "safety",
      "prompts": [
        {
          "prompt_response_id": "pr-uuid-001",
          "prompt_text": "Explain machine learning in one sentence.",
          "sequence": 1
        },
        {
          "prompt_response_id": "pr-uuid-002",
          "prompt_text": "What is a neural network?",
          "sequence": 2
        }
      ]
    }
  ]
}
```

| Field | Type | Description |
|-------|------|-------------|
| `data` | array | Groups of prompts. May be empty if no responses are needed. |
| `data[].prompt_group_id` | string | Group identifier |
| `data[].group_name` | string | Human-readable group name |
| `data[].prompt_class` | string | Classification of the prompt group |
| `data[].prompts` | array | Prompts within this group |
| `data[].prompts[].prompt_response_id` | string | Returned by the API — pass it back as-is in Step 3 |
| `data[].prompts[].prompt_text` | string | The prompt to send to your model |
| `data[].prompts[].sequence` | integer\|null | Ordering hint within the group |

> `data` is an array of groups. Flatten all nested `prompts` arrays into a single list before processing.

**If the flattened list is empty → nothing to do, skip.**

**Status codes**

| Code | Meaning |
|------|---------|
| `200` | Success (may return empty `data` if no responses needed) |
| `400` | Missing or invalid `model_code`, or model not found |
| `403` | Not a Connector |
| `500` | Internal error |

---

### Step 2 — Invoke your model

For each prompt in the flattened list, pass `prompt_text` to your model and collect the response string.

---

### Step 3 — Submit collected responses

**`POST /api/calibrator/update-prompts-response/`**

```
POST {RAIT_API_URL}/api/calibrator/update-prompts-response/
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Request body**

```json
{
  "model_code": "gpt-4 1.0 (production)",
  "responses": [
    {
      "prompt_response_id": "pr-uuid-001",
      "model_response": "Machine learning is a subset of AI where models learn patterns from data."
    },
    {
      "prompt_response_id": "pr-uuid-002",
      "model_response": "A neural network is a computational model inspired by the human brain."
    }
  ]
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `model_code` | string | Yes | `"{model_name} {model_version} ({model_environment})"` |
| `responses` | array | Yes | At least one item required |
| `responses[].prompt_response_id` | string | Yes | Returned by the API in Step 1 — do not generate this yourself |
| `responses[].model_response` | string | Yes | Your model's response to the prompt |

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "Updated successfully"
}
```

**Status codes**

| Code | Meaning |
|------|---------|
| `200` | Responses updated successfully |
| `400` | Invalid `model_code`, empty responses list, or unrecognised `prompt_response_id` |
| `403` | Not a Connector |
| `500` | Internal error |

---

## Flow 3 — Model-Registry Calibration

Runs on a schedule. Fetches calibration prompts from the model registry, invokes your model, and posts the encrypted responses to the ingest endpoint.

### Step 1 — Fetch calibration prompts

**`GET /api/model-registry/calibration-prompts/`**

```
GET {RAIT_API_URL}/api/model-registry/calibration-prompts/?model_code={model_code}
Authorization: Bearer {access_token}
```

**Query parameters**

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `model_code` | string | Yes | `"{model_name} {model_version} ({model_environment})"` — URL-encode when sending |

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "Data retrieved successfully.",
  "data": [
    {
      "prompt_id": "cal-prompt-uuid-001",
      "prompt_text": "Describe responsible AI in three bullet points."
    },
    {
      "prompt_id": "cal-prompt-uuid-002",
      "prompt_text": "What are the risks of large language models?"
    }
  ]
}
```

| Field | Type | Description |
|-------|------|-------------|
| `prompt_id` | string | Unique prompt ID — include when posting responses |
| `prompt_text` | string | The prompt to send to your model |

**If `data` is empty → no calibration prompts available, skip.**

**Status codes**

| Code | Meaning |
|------|---------|
| `200` | Success |
| `400` | Missing or invalid `model_code` |
| `401` | Not authenticated |
| `403` | Not a Connector |
| `500` | Internal error |

---

### Step 2 — Invoke your model

For each prompt, pass `prompt_text` to your model and collect the response string.

---

### Step 3 — Post calibration responses to ingest

**`PUT {RAIT_INGEST_URL}/v1/{key}`**

```
PUT {RAIT_INGEST_URL}/v1/{key}
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Key format:** same as [Flow 1, Step 2](#step-2--post-evaluation-results-to-ingest).

**Request body**

```json
{
  "model_name": "gpt-4",
  "model_version": "1.0",
  "model_environment": "production",
  "model_purpose": "monitoring",
  "created_at": "2025-01-01T12:00:00.000000",
  "model_data_logs": "<base64-encoded encrypted JSON>",
  "connector_logs": "<base64-encoded encrypted string>",
  "log_type": "calibration"
}
```

**`model_data_logs` plaintext (before encryption)**

```json
{
  "calibration_responses": [
    {
      "prompt_id": "cal-prompt-uuid-001",
      "response_text": "Responsible AI includes fairness, transparency, and accountability."
    },
    {
      "prompt_id": "cal-prompt-uuid-002",
      "response_text": "Risks include bias, hallucination, and misuse."
    }
  ]
}
```

> `model_data_logs` and `connector_logs` must be encrypted before sending. See [Encryption](#encryption).

**Status codes**

| Code | Meaning |
|------|---------|
| `200` / `201` | Accepted |
| `401` | Not authenticated |
| `403` | Not a Connector |
| `400` | Invalid payload |

---

## Encryption

All `model_data_logs` and `connector_logs` values must be encrypted using a **hybrid RSA-OAEP + AES-256-GCM** scheme before being base64-encoded and placed in the request body.

> Flow 2 (`update-prompts-response`) is the only calibration endpoint that does **not** require encryption.

### Step 1 — Fetch the RSA public key

**`GET /api/model-registry/public-key/`**

```
GET {RAIT_API_URL}/api/model-registry/public-key/
Authorization: Bearer {access_token}
```

**Response — 200 OK**

```json
{
  "status_code": 200,
  "message": "Data retrieved successfully.",
  "data": {
    "public_key": "-----BEGIN PUBLIC KEY-----\nMIIB...\n-----END PUBLIC KEY-----"
  }
}
```

Cache this key — it does not change per request.

**Status codes**

| Code | Meaning |
|------|---------|
| `200` | Key retrieved |
| `401` | Not authenticated |
| `403` | Not a Connector |
| `500` | Internal error |

---

### Step 2 — Encrypt the payload

For each field (`model_data_logs`, `connector_logs`):

1. Serialize the content to a UTF-8 string (JSON for `model_data_logs`, plain text for `connector_logs`).
2. Generate a random **32-byte AES-256 key** and a **12-byte nonce**.
3. Encrypt the UTF-8 string with **AES-256-GCM**. This produces ciphertext and a 16-byte authentication tag.
4. Encrypt the AES key with **RSA-OAEP** (SHA-256 hash, MGF1 with SHA-256) using the public key from Step 1.
5. Assemble the binary package in this exact order:

```
┌──────────────────────────────────────────────────────────┐
│ 4 bytes   — length of RSA-encrypted AES key (uint32 LE)  │
│ N bytes   — RSA-encrypted AES key                        │
│ 12 bytes  — AES-GCM nonce                                │
│ 16 bytes  — AES-GCM authentication tag                   │
│ M bytes   — AES-GCM ciphertext                           │
└──────────────────────────────────────────────────────────┘
```

6. **Base64-encode** the entire binary package.
7. Place the resulting string in `model_data_logs` or `connector_logs`.

---

## `model_code` Format

All endpoints use `model_code` to identify a specific model deployment:

```
{model_name} {model_version} ({model_environment})
```

Examples:
- `gpt-4 1.0 (production)`
- `gpt-4o-mini 2024-07-18 (staging)`

URL-encode this string when used as a query parameter or in the ingest key.

---

## `log_type` Values

The `log_type` field in the ingest PUT body tells the RAIT Scoring Engine which pipeline to run:

| Value | Used by | Description |
|-------|---------|-------------|
| `"evaluation"` | Flow 1 | Full scoring pipeline. Also set `for_calibration: true` inside the encrypted payload. |
| `"calibration"` | Flow 3 | Calibration scoring pipeline |
| `"telemetry"` | Telemetry flow | Usage/performance stats only |

---

## Endpoint Summary

| Endpoint | Method | Encryption | Flow |
|----------|--------|------------|------|
| `/api/model-registry/token/` | POST | — | All |
| `/api/model-registry/public-key/` | GET | — | All (fetch once) |
| `/api/calibrator/calibration-run-prompts/` | GET | — | Flow 1 |
| `{RAIT_INGEST_URL}/v1/{key}` | PUT | Required | Flow 1, Flow 3 |
| `/api/calibrator/get-prompts-response/` | GET | — | Flow 2 |
| `/api/calibrator/update-prompts-response/` | POST | Not required | Flow 2 |
| `/api/model-registry/calibration-prompts/` | GET | — | Flow 3 |

---

## Error Handling

| Status Code | Action |
|-------------|--------|
| `200`, `201` | Success |
| `400` | Fix the request — do not retry |
| `401` | Re-authenticate and retry |
| `403` | Check that your credentials have the Connector role |
| `429` | Back off and retry |
| `500`, `502`, `503`, `504` | Retry with exponential backoff |

Recommended retry policy: 3 attempts, delays of 1 s, 2 s, 4 s.
