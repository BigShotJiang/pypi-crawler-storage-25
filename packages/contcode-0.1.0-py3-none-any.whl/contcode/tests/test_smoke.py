"""Paket smoke testi — kurulumdan sonra çalışır."""
from __future__ import annotations

import json
import unittest

from contcode import _resources, env_flags, lmstudio, pcap, deny_proxy


class SmokeTests(unittest.TestCase):
    def test_whitelist_resource(self):
        wl = _resources.whitelist_default()
        # Default içinde sadece loopback olmalı; kullanıcı kendi IP'sini config ile ekler
        self.assertIn("127.0.0.0/8", wl)

    def test_models_json_resource(self):
        text = _resources.read_data("models.json")
        data = json.loads(text)
        # Jenerik placeholder yapısını doğrula
        self.assertIn("local", data)
        self.assertIn("models", data["local"])

    def test_env_flags_complete(self):
        flags = env_flags.offline_flags()
        for req in env_flags.REQUIRED_FLAGS:
            self.assertIn(req, flags)

    def test_pcap_parse_whitelist(self):
        # Test-only RFC5737 TEST-NET-2 IP
        any_p, spec = pcap.parse_whitelist("127.0.0.0/8,198.51.100.10:1234")
        self.assertTrue(pcap.is_allowed("127.0.0.1", 9, any_p, spec))
        self.assertTrue(pcap.is_allowed("198.51.100.10", 1234, any_p, spec))
        self.assertFalse(pcap.is_allowed("8.8.8.8", 443, any_p, spec))

    def test_deny_proxy_parse_whitelist(self):
        wl = deny_proxy.parse_whitelist("a.com:443,10.0.0.1")
        self.assertIn(("a.com", 443), wl)
        self.assertIn(("10.0.0.1", 0), wl)

    def test_lmstudio_candidates(self):
        cands = lmstudio.candidate_endpoints(windows_host="198.51.100.10")
        self.assertTrue(any("198.51.100.10:1234" in u for u in cands))


if __name__ == "__main__":
    unittest.main(verbosity=2)
