"""Local OpenAI-compatible endpoint liveness + discovery.

Lightweight probe + default-gateway detection for local LLM endpoints.
Stdlib-only (urllib + subprocess).
"""
from __future__ import annotations

import json
import subprocess
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import List, Optional, Tuple


@dataclass
class ProbeResult:
    url: str
    http_code: str = "000"
    alive: bool = False
    model_count: int = 0
    has_model_match: bool = False
    error: str = ""


def detect_windows_host() -> Optional[str]:
    """`ip route show default` gateway IP'si (WSL2'de Windows host)."""
    try:
        out = subprocess.check_output(
            ["ip", "route", "show", "default"], text=True, timeout=3,
            stderr=subprocess.DEVNULL,
        )
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 3 and parts[0] == "default":
                return parts[2]
    except (subprocess.SubprocessError, FileNotFoundError, OSError):
        pass
    return None


def probe_endpoint(
    url: str,
    timeout: float = 3.0,
    model_needle: Tuple[str, ...] = tuple(s.lower() for s in (__import__("os").environ.get("CONTCODE_MODEL_NEEDLE", "").split(",")) if s),
) -> ProbeResult:
    """LM Studio / Ollama OpenAI-compat `/v1/models` endpoint probe.

    DİKKAT: Bu çağrı HTTP_PROXY/HTTPS_PROXY env vars'ı ONURLANDIRIR.
    Çağıran taraf gerekirse çevrili bir Request kullanmalı veya env
    temizlemeli. Burada kasıtlı olarak kullanıcının env'i kullanılır
    (prod'da NO_PROXY varsa LM Studio doğrudan çağrılır).
    """
    result = ProbeResult(url=url)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "contcode/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result.http_code = str(resp.status)
            if resp.status == 200:
                body = resp.read().decode("utf-8", errors="replace")
                try:
                    data = json.loads(body)
                    models = data.get("data", [])
                    result.model_count = len(models)
                    ids = [str(m.get("id", "")).lower() for m in models]
                    for needle in model_needle:
                        if any(needle in mid for mid in ids):
                            result.has_model_match = True
                            break
                    result.alive = True
                except json.JSONDecodeError as e:
                    result.error = f"json decode: {e}"
    except urllib.error.HTTPError as e:
        result.http_code = str(e.code)
        result.error = f"http {e.code}"
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        result.error = str(e)
    return result


def candidate_endpoints(
    windows_host: Optional[str] = None,
    lmstudio_port: int = 1234,
    ollama_port: int = 11434,
) -> List[str]:
    """Denenecek LM Studio / Ollama URL'leri — öncelik sırayla."""
    wh = windows_host or detect_windows_host()
    cands: List[str] = [
        f"http://127.0.0.1:{lmstudio_port}/v1/models",
        f"http://localhost:{lmstudio_port}/v1/models",
    ]
    if wh:
        cands.append(f"http://{wh}:{lmstudio_port}/v1/models")
    cands.append(f"http://127.0.0.1:{ollama_port}/v1/models")
    return cands


def ensure_alive(
    windows_host: Optional[str] = None,
    lmstudio_port: int = 1234,
) -> Tuple[bool, List[ProbeResult]]:
    """En az bir aday LM Studio + qwen30b canlı mı?

    Returns (all_ok, all_results).
    """
    cands = candidate_endpoints(windows_host, lmstudio_port)
    results = [probe_endpoint(url) for url in cands]
    has_lms_with_qwen = any(
        r.alive and r.has_model_match and str(lmstudio_port) in r.url
        for r in results
    )
    return has_lms_with_qwen, results
