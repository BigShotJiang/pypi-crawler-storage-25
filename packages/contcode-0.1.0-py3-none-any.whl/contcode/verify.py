"""verify — in-process test runner (run_all.sh karşılığı).

Kategoriler:
  birim       : deny_proxy + pcap analyze birim testler (stdlib unittest)
  L3 egress   : deny_proxy ayağa kaldır, kötü URL listesini proxy'den geçir,
                hepsi 403/connect-fail bekle
  L4 env      : env_flags.REQUIRED_FLAGS kontrolü
  L1 kernel   : sudo varsa kernel_guard install/uninstall + adversarial
  L2 DNS      : unshare -Urm test (sudo'suz)

Exit kodu:
  0  all pass
  1  soft fail
  2  critical fail (L1 adversarial)
  3  partial (skip var)
"""
from __future__ import annotations

import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from . import deny_proxy as dp
from . import dns_sinkhole
from . import env_flags
from . import kernel_guard
from . import lmstudio
from . import pcap as pcap_mod
from . import reporting


# ===== tests =====

# Known opencode egress list for L3 test
EGRESS_URLS = [
    "https://api.opencode.ai/get_github_app_installation",
    "https://opencode.ai/changelog.json",
    "https://opencode.ai/config.json",
    "https://models.dev/api.json",
    "https://api.github.com/repos/anomalyco/opencode/releases/latest",
    "https://raw.githubusercontent.com/ScoopInstaller/Main/master/bucket/opencode.json",
    "https://registry.npmjs.org/@ai-sdk/openai-compatible",
    "https://bun.report/v1/feedback",
    "https://api.anthropic.com/v1/messages",
    "https://api.openai.com/v1/chat/completions",
]


def _find_free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _proxy_curl_probe(url: str, proxy_host: str, proxy_port: int,
                      timeout: float = 5.0) -> Tuple[int, str]:
    """curl via proxy. Returns (curl_exit, http_code)."""
    if not shutil.which("curl"):
        return 127, "000"
    cmd = [
        "curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
        "--max-time", str(int(timeout)),
        "--proxy", f"http://{proxy_host}:{proxy_port}", url,
    ]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout + 2)
        return p.returncode, (p.stdout.strip() or "000")
    except subprocess.TimeoutExpired:
        return 124, "000"


# ----- Kategori: birim unittest -----
def run_unit_tests() -> Tuple[bool, str]:
    """Minimal stdlib unittests: parse_whitelist + bidirectional flow."""
    import ipaddress

    # whitelist
    any_port, specific = pcap_mod.parse_whitelist("127.0.0.0/8,198.51.100.10:1234")
    assert pcap_mod.is_allowed("127.0.0.1", 9, any_port, specific), "loopback any port"
    assert pcap_mod.is_allowed("198.51.100.10", 1234, any_port, specific), "lms"
    assert not pcap_mod.is_allowed("8.8.8.8", 443, any_port, specific), "deny 8.8.8.8"

    # canonical flow bidirectional
    local = [ipaddress.ip_network("127.0.0.0/8"),
             ipaddress.ip_network("192.168.1.50/32")]
    k1 = pcap_mod.canonical_flow("192.168.1.50", 55555, "198.51.100.10", 1234,
                                 "tcp", local)
    k2 = pcap_mod.canonical_flow("198.51.100.10", 1234, "192.168.1.50", 55555,
                                 "tcp", local)
    assert k1[:3] == k2[:3], f"bidir key eşit olmalı: {k1} vs {k2}"

    # deny_proxy parse_whitelist
    wl = dp.parse_whitelist("example.com:443,10.0.0.1")
    assert ("example.com", 443) in wl, "explicit host:port"
    assert ("10.0.0.1", 0) in wl, "wildcard port"

    return True, "birim: 3 assertion OK"


# ----- Kategori: L4 env flags -----
def run_env_check() -> Tuple[bool, str]:
    flags = env_flags.offline_flags()
    missing = [k for k in env_flags.REQUIRED_FLAGS if not flags.get(k)]
    if missing:
        return False, "eksik: " + ",".join(missing)
    return True, f"{len(env_flags.REQUIRED_FLAGS)}/{len(env_flags.REQUIRED_FLAGS)} OK"


# ----- Kategori: L3 egress (deny_proxy) -----
def run_l3_egress(duration_s: float = 30.0) -> Tuple[bool, str]:
    if not shutil.which("curl"):
        return True, "SKIP: curl yok"

    port = _find_free_port()
    win_host = lmstudio.detect_windows_host()
    wl = f"127.0.0.1:*,{win_host}:1234" if win_host else "127.0.0.1:*"

    deny_log = Path(tempfile.mkstemp(prefix="deny_", suffix=".log")[1])
    server = dp.build_server("127.0.0.1", port, dp.parse_whitelist(wl), deny_log)

    import threading
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    time.sleep(0.3)

    try:
        pass_count = 0
        fail_count = 0
        details: List[str] = []
        for url in EGRESS_URLS:
            rc, code = _proxy_curl_probe(url, "127.0.0.1", port)
            # Blocked: curl tünel kuramaz → rc != 0 VE deny log'da host var
            host = url.split("/")[2]
            denied_in_log = False
            try:
                log_text = deny_log.read_text(errors="replace")
                denied_in_log = host in log_text
            except OSError:
                pass
            if denied_in_log and (rc != 0 or code == "403"):
                pass_count += 1
            else:
                fail_count += 1
                details.append(f"LEAK: {url} rc={rc} code={code} denied_in_log={denied_in_log}")

        # Whitelist local endpoint testi
        if win_host:
            lms_url = f"http://{win_host}:1234/v1/models"
            rc, code = _proxy_curl_probe(lms_url, "127.0.0.1", port)
            if code == "200":
                pass_count += 1
            else:
                fail_count += 1
                details.append(f"local endpoint geçmedi: rc={rc} code={code}")

        total = pass_count + fail_count
        ok = fail_count == 0
        summary = f"L3 egress {pass_count}/{total}"
        if details:
            summary += " | " + "; ".join(details[:3])
        return ok, summary
    finally:
        server.shutdown()
        server.server_close()
        try:
            deny_log.unlink()
        except OSError:
            pass


# ----- Kategori: L2 DNS sinkhole -----
def run_l2_dns() -> Tuple[bool, str]:
    if not dns_sinkhole.usable():
        return True, "SKIP: unshare -Urm kullanılamıyor"
    rc, out = dns_sinkhole.test_run()
    if rc != 0:
        return False, f"dns_sinkhole test rc={rc}"
    # Çıktı: ns içinde lmstudio.local çözülmeli, api.opencode.ai çözülememeli
    if "doğru davranış" in out or "çözülemedi" in out:
        return True, "L2 DNS sinkhole OK"
    return False, "L2 DNS sinkhole beklenen davranışı göstermedi"


# ----- Kategori: L1 kernel_guard (sudo gerekir) -----
def run_l1_kernel_guard_adversarial(duration_s: float = 30.0) -> Tuple[bool, str]:
    """Sudo gerekir. Guard kur → dışarı denenenler fail etmeli → temizle."""
    if not kernel_guard.sudo_nopasswd_available():
        return None, "SKIP: sudo -n yok (kritik test)"  # None = SKIP

    backend = kernel_guard.backend_available()
    if not backend["nft_path"] and not backend["iptables_path"]:
        return False, "ne nft ne iptables var"

    rc, out, err = kernel_guard.install(scope="uid")
    if rc != 0:
        return False, f"install başarısız rc={rc} err={err.strip()[:200]}"

    try:
        win_host = lmstudio.detect_windows_host() or "198.51.100.10"
        results: List[Tuple[str, bool, str]] = []

        # 1) direct IP TCP — fail beklenir
        try:
            with socket.create_connection(("203.0.113.4", 443), timeout=3):
                results.append(("direct_tcp_github_ip", False, "leak"))
        except (OSError, socket.timeout):
            results.append(("direct_tcp_github_ip", True, "blocked"))

        # 2) DNS UDP 8.8.8.8 — fail beklenir
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(2)
            s.sendto(b"\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00"
                     b"\x07example\x03com\x00\x00\x01\x00\x01", ("8.8.8.8", 53))
            try:
                s.recvfrom(512)
                results.append(("dns_udp_8.8.8.8", False, "leak"))
            except (OSError, socket.timeout):
                results.append(("dns_udp_8.8.8.8", True, "blocked"))
            finally:
                s.close()
        except OSError:
            results.append(("dns_udp_8.8.8.8", True, "blocked (sendto fail)"))

        # 3) local endpoint — OK beklenir
        try:
            with socket.create_connection((win_host, 1234), timeout=3):
                results.append(("lmstudio", True, "ok"))
        except (OSError, socket.timeout) as e:
            results.append(("lmstudio", False, f"blocked: {e}"))

        fails = [r for r in results if not r[1]]
        ok = not fails
        desc = f"{len(results) - len(fails)}/{len(results)}"
        if fails:
            desc += " | " + ",".join(f"{n}({d})" for n, _, d in fails)
        return ok, f"L1 adversarial {desc}"
    finally:
        kernel_guard.uninstall()


def run_l1_kernel_guard_status() -> Tuple[bool, str]:
    """Non-destructive: sadece status oku."""
    rc, txt = kernel_guard.status()
    return True, f"kernel_guard status: {txt.strip()[:120]}"


# ----- Kategori: local endpoint canlılık -----
def run_lmstudio_check() -> Tuple[bool, str]:
    _, results = lmstudio.ensure_alive()
    alive = [r for r in results if r.alive]
    if not alive:
        return False, "no local endpoint alive (all candidates dead)"
    needle = os.environ.get("CONTCODE_MODEL_NEEDLE", "").strip()
    if needle:
        match = [r for r in alive if r.has_model_match]
        if not match:
            return False, f"endpoint alive but needle '{needle}' not found"
        return True, f"alive + needle match @ {match[0].url}"
    return True, f"alive @ {alive[0].url} (no model needle set)"


# ===== runner =====

@dataclass
class TestCase:
    name: str
    kind: str  # "normal" | "critical"
    fn: Any
    kwargs: Dict[str, Any] = field(default_factory=dict)


def build_suite(hardened: bool = False, soft_only: bool = False) -> List[TestCase]:
    cases = [
        TestCase("birim", "normal", run_unit_tests),
        TestCase("env_flags (L4)", "normal", run_env_check),
        TestCase("lmstudio canlılık", "normal", run_lmstudio_check),
        TestCase("deny_proxy egress (L3)", "normal", run_l3_egress),
        TestCase("dns_sinkhole (L2)", "normal", run_l2_dns),
    ]
    if not soft_only:
        cases.append(TestCase("kernel_guard adversarial (L1)", "critical",
                              run_l1_kernel_guard_adversarial))
    return cases


def run_suite(hardened: bool = False, soft_only: bool = False) -> Dict[str, Any]:
    suite = build_suite(hardened=hardened, soft_only=soft_only)
    results: List[Dict[str, Any]] = []
    normal_fail = 0
    critical_fail = 0
    skipped = 0

    start = time.time()
    for tc in suite:
        print(f"\n=== {tc.name} ===")
        t0 = time.time()
        try:
            ret = tc.fn(**tc.kwargs)
            # ret: (ok, summary) where ok in {True, False, None}
            ok, summary = ret if isinstance(ret, tuple) else (False, "unknown")
        except Exception as e:
            ok, summary = False, f"exception: {e}"

        elapsed = round(time.time() - t0, 2)
        if ok is None:
            status = "SKIP"
            skipped += 1
        elif ok:
            status = "PASS"
        else:
            status = "FAIL"
            if tc.kind == "critical":
                critical_fail += 1
            else:
                normal_fail += 1
        print(f"  [{status}] {summary}  ({elapsed}s)")
        results.append({
            "name": tc.name, "kind": tc.kind, "status": status,
            "summary": summary, "elapsed_s": elapsed,
        })

    total_elapsed = round(time.time() - start, 2)
    if critical_fail > 0:
        verdict = "bank-grade ready: NO (kritik fail)"
        exit_code = 2
    elif normal_fail > 0:
        verdict = "bank-grade ready: NO (non-kritik fail)"
        exit_code = 1
    elif skipped > 0:
        verdict = "bank-grade ready: PARTIAL (skip var)"
        exit_code = 3
    else:
        verdict = "bank-grade ready: YES"
        exit_code = 0

    summary = {
        "meta": {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "hardened": hardened, "soft_only": soft_only,
            "total_elapsed_s": total_elapsed,
        },
        "results": results,
        "counts": {
            "passed": sum(1 for r in results if r["status"] == "PASS"),
            "failed_normal": normal_fail,
            "failed_critical": critical_fail,
            "skipped": skipped,
        },
        "verdict": verdict,
        "exit_code": exit_code,
    }
    print(f"\n=== SONUÇ ===")
    for r in results:
        print(f"  [{r['status']}] {r['name']}")
    print()
    print(f"counts: {summary['counts']}")
    print(verdict)
    return summary


def main(hardened: bool = False, soft_only: bool = False,
         write_report: bool = True) -> int:
    summary = run_suite(hardened=hardened, soft_only=soft_only)
    if write_report:
        path = reporting.save_json(summary, "verify")
        print(f"JSON: {path}")
    return summary["exit_code"]
