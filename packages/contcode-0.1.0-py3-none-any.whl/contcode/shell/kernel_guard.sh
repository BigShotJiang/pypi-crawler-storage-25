#!/usr/bin/env bash
# v2 | 2026-04-19 | kernel_guard: nftables/iptables fail-closed egress filter
#
# Kural seti "opencode-offline" adıyla yüklenir.
# İki mod:
#   --uid-scope (default):  sadece belirli UID (default: OPENCODE_UID ya da mevcut UID)
#                           dışındaki user'lar etkilenmez
#   --global              : sistem geneli OUTPUT filter — tüm user'ları etkiler
#                           (bank-grade kurulumlarda tercih edilir)
#
# Komutlar:
#   kernel_guard.sh install [--uid-scope UID|--global]
#   kernel_guard.sh uninstall
#   kernel_guard.sh status
#
# SUDO GEREKLİ. İdempotent: install üst üste çağrılabilir, uninstall temiz.
# nftables tercih edilir, yoksa iptables fallback.
set -euo pipefail

GUARD_NAME="opencode-offline"
TABLE_NAME="$GUARD_NAME"
LMSTUDIO_HOST="${LMSTUDIO_HOST:-$(ip route show default 2>/dev/null | awk '{print $3}')}"
LMSTUDIO_PORT="${LMSTUDIO_PORT:-1234}"
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LOG_DIR="${PROJECT_DIR}/offline/logs"
mkdir -p "$LOG_DIR"

need_root() {
  if [ "$(id -u)" != "0" ]; then
    echo "[kernel_guard] bu komut root olarak çalışmalı (sudo ile tekrar deneyin)" >&2
    exit 3
  fi
}

use_nft() {
  command -v nft >/dev/null 2>&1
}

# ----- NFTABLES mode -----
nft_install_uid_scope() {
  local uid="$1"
  nft_uninstall >/dev/null 2>&1 || true
  nft -f - <<EOF
table inet ${TABLE_NAME} {
  chain output {
    type filter hook output priority 0; policy accept;
    # skuid değilsa — başka UID'leri filtreleme
    meta skuid != ${uid} accept
    # loopback serbest
    oif "lo" accept
    ip daddr 127.0.0.0/8 accept
    ip6 daddr ::1 accept
    # local endpoint host (tek IP + tek port)
    ip daddr ${LMSTUDIO_HOST} tcp dport ${LMSTUDIO_PORT} accept
    # DNS sadece 127.0.0.1
    udp dport 53 ip daddr != 127.0.0.1 reject with icmp type admin-prohibited
    tcp dport 53 ip daddr != 127.0.0.1 reject with icmp type admin-prohibited
    # Gerisi: REJECT (ICMP unreachable — hızlı fail için)
    ip protocol tcp reject with tcp reset
    ip protocol udp reject with icmpx type admin-prohibited
    counter log prefix "opencode-block: " drop
  }
}
EOF
}

nft_install_global() {
  nft_uninstall >/dev/null 2>&1 || true
  nft -f - <<EOF
table inet ${TABLE_NAME} {
  chain output {
    type filter hook output priority 0; policy accept;
    oif "lo" accept
    ip daddr 127.0.0.0/8 accept
    ip6 daddr ::1 accept
    ip daddr ${LMSTUDIO_HOST} tcp dport ${LMSTUDIO_PORT} accept
    udp dport 53 ip daddr != 127.0.0.1 reject with icmp type admin-prohibited
    tcp dport 53 ip daddr != 127.0.0.1 reject with icmp type admin-prohibited
    ip protocol tcp reject with tcp reset
    ip protocol udp reject with icmpx type admin-prohibited
    counter log prefix "opencode-block: " drop
  }
}
EOF
}

nft_uninstall() {
  nft list tables 2>/dev/null | grep -qE "inet ${TABLE_NAME}\$" \
    && nft delete table inet "${TABLE_NAME}" 2>/dev/null || true
}

nft_status() {
  if nft list tables 2>/dev/null | grep -qE "inet ${TABLE_NAME}\$"; then
    echo "nft table inet ${TABLE_NAME}: YÜKLÜ"
    return 0
  fi
  echo "nft table inet ${TABLE_NAME}: YOK"
  return 1
}

# ----- IPTABLES fallback -----
IPT_CHAIN="${GUARD_NAME//-/_}"

ipt_install_uid_scope() {
  local uid="$1"
  ipt_uninstall >/dev/null 2>&1 || true
  iptables -N "${IPT_CHAIN}"
  # Bu UID'den geçmeyenleri hemen geçir
  iptables -A "${IPT_CHAIN}" -m owner ! --uid-owner "${uid}" -j RETURN
  iptables -A "${IPT_CHAIN}" -o lo -j ACCEPT
  iptables -A "${IPT_CHAIN}" -d 127.0.0.0/8 -j ACCEPT
  iptables -A "${IPT_CHAIN}" -d "${LMSTUDIO_HOST}" -p tcp --dport "${LMSTUDIO_PORT}" -j ACCEPT
  iptables -A "${IPT_CHAIN}" -p udp --dport 53 -d 127.0.0.1 -j ACCEPT
  iptables -A "${IPT_CHAIN}" -p tcp --dport 53 -d 127.0.0.1 -j ACCEPT
  iptables -A "${IPT_CHAIN}" -p udp --dport 53 -j REJECT --reject-with icmp-admin-prohibited
  iptables -A "${IPT_CHAIN}" -p tcp --dport 53 -j REJECT --reject-with tcp-reset
  iptables -A "${IPT_CHAIN}" -j LOG --log-prefix "opencode-block: " --log-level 4 -m limit --limit 5/min
  iptables -A "${IPT_CHAIN}" -p tcp -j REJECT --reject-with tcp-reset
  iptables -A "${IPT_CHAIN}" -j REJECT --reject-with icmp-admin-prohibited
  iptables -I OUTPUT 1 -j "${IPT_CHAIN}"
}

ipt_install_global() {
  ipt_uninstall >/dev/null 2>&1 || true
  iptables -N "${IPT_CHAIN}"
  iptables -A "${IPT_CHAIN}" -o lo -j ACCEPT
  iptables -A "${IPT_CHAIN}" -d 127.0.0.0/8 -j ACCEPT
  iptables -A "${IPT_CHAIN}" -d "${LMSTUDIO_HOST}" -p tcp --dport "${LMSTUDIO_PORT}" -j ACCEPT
  iptables -A "${IPT_CHAIN}" -p udp --dport 53 -d 127.0.0.1 -j ACCEPT
  iptables -A "${IPT_CHAIN}" -p tcp --dport 53 -d 127.0.0.1 -j ACCEPT
  iptables -A "${IPT_CHAIN}" -p udp --dport 53 -j REJECT --reject-with icmp-admin-prohibited
  iptables -A "${IPT_CHAIN}" -p tcp --dport 53 -j REJECT --reject-with tcp-reset
  iptables -A "${IPT_CHAIN}" -j LOG --log-prefix "opencode-block: " --log-level 4 -m limit --limit 5/min
  iptables -A "${IPT_CHAIN}" -p tcp -j REJECT --reject-with tcp-reset
  iptables -A "${IPT_CHAIN}" -j REJECT --reject-with icmp-admin-prohibited
  iptables -I OUTPUT 1 -j "${IPT_CHAIN}"
}

ipt_uninstall() {
  while iptables -C OUTPUT -j "${IPT_CHAIN}" 2>/dev/null; do
    iptables -D OUTPUT -j "${IPT_CHAIN}"
  done
  iptables -F "${IPT_CHAIN}" 2>/dev/null || true
  iptables -X "${IPT_CHAIN}" 2>/dev/null || true
}

ipt_status() {
  if iptables -L "${IPT_CHAIN}" -n >/dev/null 2>&1; then
    echo "iptables chain ${IPT_CHAIN}: YÜKLÜ"
    return 0
  fi
  echo "iptables chain ${IPT_CHAIN}: YOK"
  return 1
}

# ----- dispatcher -----
cmd="${1:-status}"
shift || true

mode="uid-scope"
uid_arg=""
while [ $# -gt 0 ]; do
  case "$1" in
    --global) mode="global" ;;
    --uid-scope) mode="uid-scope"; uid_arg="${2:-}"; [ -n "$uid_arg" ] && shift ;;
    *) echo "bilinmeyen argüman: $1" >&2; exit 2 ;;
  esac
  shift
done

if [ -z "${LMSTUDIO_HOST:-}" ]; then
  echo "[kernel_guard] LMSTUDIO_HOST tespit edilemedi" >&2
  exit 2
fi

case "$cmd" in
  install)
    need_root
    if [ "$mode" = "uid-scope" ]; then
      uid="${uid_arg:-${OPENCODE_UID:-${SUDO_UID:-1000}}}"
      echo "[kernel_guard] install uid-scope=${uid} lmstudio=${LMSTUDIO_HOST}:${LMSTUDIO_PORT}" | tee -a "${LOG_DIR}/kernel_guard.log"
      if use_nft; then nft_install_uid_scope "$uid"; else ipt_install_uid_scope "$uid"; fi
    else
      echo "[kernel_guard] install global lmstudio=${LMSTUDIO_HOST}:${LMSTUDIO_PORT}" | tee -a "${LOG_DIR}/kernel_guard.log"
      if use_nft; then nft_install_global; else ipt_install_global; fi
    fi
    ;;
  uninstall)
    need_root
    echo "[kernel_guard] uninstall" | tee -a "${LOG_DIR}/kernel_guard.log"
    if use_nft; then nft_uninstall; fi
    ipt_uninstall
    ;;
  status)
    if use_nft; then nft_status; else ipt_status; fi
    ;;
  *)
    echo "kullanım: $0 {install|uninstall|status} [--uid-scope UID|--global]" >&2
    exit 2
    ;;
esac
