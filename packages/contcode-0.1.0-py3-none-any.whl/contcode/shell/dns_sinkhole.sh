#!/usr/bin/env bash
# v2 | 2026-04-19 | dns_sinkhole: opencode process'i için özel resolv.conf + hosts
#
# Yaklaşım: unshare -Urm (user+mount namespace). Sudo gerektirmez — user ns
# içinde fake root olur, bind mount yapabilir.
# Namespace içinde:
#   /etc/resolv.conf  → sadece "nameserver 127.0.0.1" (ulaşılamayan stub)
#   /etc/hosts        → localhost + local endpoint host (WIN_HOST) sabit kayıt
#
# Dış dünyadaki hostname çözümü namespace içinden NXDOMAIN/timeout dönecek,
# local endpoint ve 127.0.0.1 ise hosts üzerinden doğrudan çözülecek.
#
# Fallback (sudo lı): sistem-çapında dnsmasq yükle; bu yol tercih edilmez.
# Detay: offline/OFFLINE_PLAN.md (v2) "Layer 2: DNS" bölümü.
#
# Kullanım:
#   dns_sinkhole.sh wrap -- <komut> [arg...]
#     → komutu ns içinde çalıştırır
#   dns_sinkhole.sh build-files [hedef_dir]
#     → resolv.conf + hosts dosyalarını üretir (debug için)
#   dns_sinkhole.sh test
#     → ns içinden curl / DNS testi yap, raporla
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LOG_DIR="${PROJECT_DIR}/offline/logs"
mkdir -p "$LOG_DIR"

WIN_HOST="${WIN_HOST:-$(ip route show default 2>/dev/null | awk '{print $3}')}"
if [ -z "$WIN_HOST" ]; then
  echo "[dns_sinkhole] WIN_HOST tespit edilemedi" >&2
  exit 2
fi

build_files() {
  local dst="${1:-$(mktemp -d /tmp/opencode_dns.XXXXXX)}"
  cat > "${dst}/resolv.conf" <<EOF
# v2 | opencode offline namespace resolv.conf
# Dış DNS kapalı; sadece 127.0.0.1 (ulaşılamayan stub)
nameserver 127.0.0.1
options timeout:1 attempts:1 ndots:0
EOF
  cat > "${dst}/hosts" <<EOF
# v2 | opencode offline namespace /etc/hosts
127.0.0.1   localhost localhost.localdomain
::1         localhost ip6-localhost
${WIN_HOST}  lmstudio.local lmstudio
EOF
  echo "$dst"
}

wrap() {
  local dst
  dst="$(build_files)"
  # Namespace içinde:
  #   1. kendi hosts/resolv dosyalarımızı /etc altına bind et
  #   2. komutu çalıştır
  #
  # unshare -Urm:
  #   -U  user namespace (fake root, sudo gerektirmez)
  #   -r  map current uid to root inside ns
  #   -m  mount namespace (mount'lar izole)
  exec unshare -Urm bash -c "
    mount --bind '${dst}/resolv.conf' /etc/resolv.conf
    mount --bind '${dst}/hosts' /etc/hosts
    exec \"\$@\"
  " _ "$@"
}

do_test() {
  local dst
  dst="$(build_files)"
  echo "[dns_sinkhole.test] hosts=${dst}/hosts resolv=${dst}/resolv.conf"
  unshare -Urm bash -c "
    mount --bind '${dst}/resolv.conf' /etc/resolv.conf
    mount --bind '${dst}/hosts' /etc/hosts
    echo '--- /etc/resolv.conf (ns içinde) ---'
    cat /etc/resolv.conf
    echo '--- /etc/hosts (ns içinde) ---'
    cat /etc/hosts
    echo '--- lmstudio çözümü ---'
    getent hosts lmstudio.local || echo 'lmstudio.local çözülemedi'
    echo '--- api.opencode.ai çözümü (fail bekleniyor) ---'
    timeout 2 getent hosts api.opencode.ai 2>&1 || echo '(çözülemedi, doğru davranış)'
    echo '--- api.openai.com çözümü (fail bekleniyor) ---'
    timeout 2 getent hosts api.openai.com 2>&1 || echo '(çözülemedi, doğru davranış)'
  "
}

cmd="${1:-}"
shift || true
case "$cmd" in
  wrap)
    [ "${1:-}" = "--" ] && shift
    [ $# -gt 0 ] || { echo "komut gerekli: wrap -- <komut>"; exit 2; }
    wrap "$@"
    ;;
  build-files)
    build_files "${1:-}"
    ;;
  test)
    do_test
    ;;
  *)
    echo "kullanım: $0 {wrap -- <komut>|build-files [dir]|test}" >&2
    exit 2
    ;;
esac
