#!/usr/bin/env bash
# local endpoint daemon'un çalıştığını garantile.
# cont projesinden uyarlandı (cont/ensure_lmstudio.sh, v1).
set -e

PORT="${LMSTUDIO_PORT:-1234}"
WIN_HOST="${WIN_HOST:-$(ip route show default 2>/dev/null | awk '{print $3}')}"
HOST="${LMSTUDIO_HOST:-$WIN_HOST}"
TIMEOUT="${LMSTUDIO_TIMEOUT:-3}"

if [ -z "$HOST" ]; then
  echo "[ensure_lmstudio] HATA: Windows host adresi tespit edilemedi" >&2
  exit 2
fi

if curl -sf --max-time "$TIMEOUT" "http://${HOST}:${PORT}/v1/models" >/dev/null; then
  echo "[ensure_lmstudio] ✅ ${HOST}:${PORT} yanıt veriyor"
  exit 0
fi

# Yerel lms CLI ile bağlamayı dene (sadece WSL içinde, Windows tarafı zaten çalışıyor olmalı)
LMS="${LMS_PATH:-$HOME/.lmstudio/bin/lms}"
if [ -x "$LMS" ]; then
  echo "[ensure_lmstudio] ${HOST}:${PORT} cevapsız — lms ile başlatmayı deniyorum"
  nohup "$LMS" server start --port "$PORT" >/tmp/lmstudio.log 2>&1 &
  sleep 3
  if curl -sf --max-time "$TIMEOUT" "http://${HOST}:${PORT}/v1/models" >/dev/null; then
    echo "[ensure_lmstudio] ✅ başlatıldı"
    exit 0
  fi
fi

echo "[ensure_lmstudio] ❌ ${HOST}:${PORT} erişilemez — Windows tarafında local endpoint açık mı?" >&2
exit 1
