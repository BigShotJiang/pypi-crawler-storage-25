"""prod_recon.sh'in Python portu — read-only prod keşfi.

Hiçbir şey kurmaz, mount etmez, kural eklemez. Sadece gözlem.
stdlib-only, zero dependency. Python 3.8+ uyumlu.
"""
from __future__ import annotations

import datetime
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from . import lmstudio, reporting
from .env_flags import REQUIRED_FLAGS


TOOLS_TO_PROBE = [
    "nft", "iptables", "ip6tables", "tcpdump", "unshare", "dig", "nc", "socat",
    "curl", "wget", "openssl", "python3", "node", "bun", "npm",
    "systemctl", "systemd-run", "firejail", "bwrap",
]


def _run(cmd: List[str], timeout: float = 5.0,
         env: Optional[Dict[str, str]] = None) -> Tuple[int, str, str]:
    try:
        p = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, env=env,
        )
        return p.returncode, p.stdout or "", p.stderr or ""
    except FileNotFoundError:
        return 127, "", "not found"
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"
    except OSError as e:
        return 1, "", str(e)


# ---------- temel ortam ----------
def base_env() -> Dict[str, Any]:
    info: Dict[str, Any] = {}

    _, un, _ = _run(["uname", "-a"])
    info["kernel"] = un.strip()

    info["arch"] = os.uname().machine

    os_pretty = ""
    try:
        for line in Path("/etc/os-release").read_text().splitlines():
            if line.startswith("PRETTY_NAME="):
                os_pretty = line.split("=", 1)[1].strip().strip('"')
                break
    except OSError:
        pass
    info["os_pretty"] = os_pretty

    info["user"] = os.environ.get("USER") or os.getlogin() if hasattr(os, "getlogin") else ""
    info["uid"] = os.getuid()
    info["gid"] = os.getgid()
    rc, groups_out, _ = _run(["groups"])
    info["groups"] = groups_out.strip().split() if rc == 0 else []

    # WSL?
    wsl = False
    try:
        if "microsoft" in Path("/proc/version").read_text().lower():
            wsl = True
    except OSError:
        pass
    info["wsl"] = wsl

    info["hostname"] = socket.gethostname()

    home = Path.home()
    info["home"] = str(home)
    info["home_writable"] = os.access(home, os.W_OK)

    proj = home / "projects"
    info["projects_dir_exists"] = proj.is_dir()
    info["projects_dir_writable"] = proj.is_dir() and os.access(proj, os.W_OK)

    # cpu/mem/disk
    rc, nproc, _ = _run(["nproc"])
    info["cpus"] = int(nproc.strip()) if rc == 0 and nproc.strip().isdigit() else 0
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    info["mem_total_kb"] = int(line.split()[1])
                    break
    except OSError:
        info["mem_total_kb"] = 0
    try:
        stat = shutil.disk_usage(str(home))
        info["home_disk_free_gb"] = stat.free // (1024 ** 3)
    except OSError:
        info["home_disk_free_gb"] = 0

    # paket manager PATH
    info["package_managers"] = {
        name: shutil.which(name) for name in ("apt", "snap", "pip", "flatpak")
    }

    return info


# ---------- ağ ----------
def network_info(wsl: bool) -> Dict[str, Any]:
    info: Dict[str, Any] = {}

    _, ip_out, _ = _run(["ip", "-4", "addr", "show"])
    interfaces: List[Dict[str, str]] = []
    current_iface = None
    for line in ip_out.splitlines():
        m = re.match(r"^\d+:\s+(\S+):\s", line)
        if m:
            current_iface = m.group(1).rstrip(":")
        m2 = re.search(r"inet\s+(\S+)", line)
        if m2 and current_iface:
            interfaces.append({"iface": current_iface, "addr": m2.group(1)})
    info["interfaces"] = interfaces

    _, route_out, _ = _run(["ip", "route", "show", "default"])
    gw = ""
    for line in route_out.splitlines():
        parts = line.split()
        if len(parts) >= 3 and parts[0] == "default":
            gw = parts[2]
            break
    info["default_gw"] = gw
    info["windows_host_ip"] = gw if wsl else None

    try:
        resolv = Path("/etc/resolv.conf").read_text()
    except OSError:
        resolv = ""
    info["resolv_conf_raw"] = resolv[:500]
    info["resolv_nameservers"] = [
        m.group(1) for m in re.finditer(r"(?m)^\s*nameserver\s+(\S+)", resolv)
    ]

    # ss -tuln
    _, ss_out, _ = _run(["ss", "-tuln"])
    info["listening_ports_sample"] = ss_out.splitlines()[:15]

    # firewall readable without sudo?
    rc_n, _, _ = _run(["nft", "list", "ruleset"], timeout=3)
    rc_i, _, _ = _run(["iptables", "-L", "-n"], timeout=3)
    info["firewall_readable_without_sudo"] = (rc_n == 0) or (rc_i == 0)

    # internet probe
    code, _, _ = _curl_code("https://1.1.1.1", timeout=3)
    info["internet_probe_code"] = code
    info["internet_reachable"] = code in ("200", "204", "301", "302", "307", "308")

    # local endpoint adayları
    cands = lmstudio.candidate_endpoints(
        windows_host=info.get("windows_host_ip"),
    )
    info["lmstudio_candidates"] = [
        {
            "url": r.url,
            "http_code": r.http_code,
            "alive": r.alive,
            "model_count": r.model_count,
            "has_model_match": r.has_model_match,
            "error": r.error,
        }
        for r in (lmstudio.probe_endpoint(u) for u in cands)
    ]

    return info


def _curl_code(url: str, timeout: float = 3.0) -> Tuple[str, str, str]:
    """curl -s -o /dev/null -w %{http_code} wrapper; yoksa urllib."""
    if shutil.which("curl"):
        rc, out, err = _run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "--max-time", str(int(timeout)), "-k", url],
            timeout=timeout + 2,
        )
        code = out.strip() or "000"
        return code, out, err
    # urllib fallback
    import urllib.error
    import urllib.request
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return str(resp.status), "", ""
    except urllib.error.HTTPError as e:
        return str(e.code), "", str(e)
    except Exception as e:
        return "000", "", str(e)


# ---------- yetki ----------
def privileges() -> Dict[str, Any]:
    info: Dict[str, Any] = {}
    rc, _, _ = _run(["sudo", "-n", "true"], timeout=3)
    info["sudo_nopasswd"] = rc == 0
    rc2, sudo_l, _ = _run(["sudo", "-ln"], timeout=5)
    info["sudo_l_output"] = sudo_l.strip()[:500]

    info["cap_net_admin"] = False
    info["cap_net_raw"] = False
    if shutil.which("capsh"):
        rc3, caps, _ = _run(["capsh", "--print"], timeout=3)
        if rc3 == 0:
            info["cap_net_admin"] = "cap_net_admin" in caps
            info["cap_net_raw"] = "cap_net_raw" in caps

    info["unprivileged_userns_clone"] = None
    p = Path("/proc/sys/kernel/unprivileged_userns_clone")
    if p.exists():
        try:
            info["unprivileged_userns_clone"] = p.read_text().strip()
        except OSError:
            pass

    rc4, _, _ = _run(["unshare", "-Urm", "true"], timeout=3)
    info["unshare_urm_ok"] = rc4 == 0

    info["sudoers_d_readable"] = os.access("/etc/sudoers.d", os.R_OK)
    return info


# ---------- tooling ----------
def tools() -> Dict[str, Any]:
    result: Dict[str, Any] = {}
    for t in TOOLS_TO_PROBE:
        path = shutil.which(t)
        info = {"present": bool(path), "path": path or "",
                "version": "", "usable_without_sudo": False}
        if path:
            ver_cmd = [path, "--version"]
            rc, out, err = _run(ver_cmd, timeout=2)
            info["version"] = (out or err).splitlines()[0][:120] if (out or err) else ""
            # usability check: --help or --version çalışıyor mu
            rc_h, _, _ = _run([path, "--help"], timeout=2)
            info["usable_without_sudo"] = (rc in (0, 1)) or (rc_h in (0, 1))
        result[t] = info

    # tcpdump -D without sudo
    td_ok = False
    if shutil.which("tcpdump"):
        rc, _, _ = _run(["tcpdump", "-D"], timeout=2)
        td_ok = rc == 0
    result["_tcpdump_D_without_sudo"] = td_ok

    # systemd-run --user --scope
    sr_ok = False
    if shutil.which("systemd-run"):
        rc, _, _ = _run(
            ["systemd-run", "--user", "--quiet", "--scope", "true"], timeout=3,
        )
        sr_ok = rc == 0
    result["_systemd_run_user_scope_ok"] = sr_ok

    return result


# ---------- opencode / cont ----------
def opencode_info() -> Dict[str, Any]:
    info: Dict[str, Any] = {}
    oc = shutil.which("opencode")
    if not oc:
        home_bin = Path.home() / ".opencode" / "bin" / "opencode"
        if home_bin.is_file() and os.access(home_bin, os.X_OK):
            oc = str(home_bin)
    info["binary"] = oc or ""
    info["version"] = ""
    if oc:
        rc, out, _ = _run([oc, "--version"], timeout=3)
        info["version"] = (out.strip().splitlines() or [""])[0]
    info["config_user_dir"] = str(Path.home() / ".config" / "opencode")
    info["config_user_exists"] = Path(info["config_user_dir"]).is_dir()
    info["cont_project_present"] = (Path.home() / "projects" / "cont").is_dir()
    return info


# ---------- risk sinyalleri ----------
def risks() -> Dict[str, Any]:
    info: Dict[str, Any] = {}

    clients: List[Dict[str, Any]] = []
    for name in ("claude", "cursor", "codeium", "copilot"):
        rc, out, _ = _run(["pgrep", "-cf", name], timeout=3)
        if rc == 0:
            try:
                cnt = int(out.strip() or "0")
            except ValueError:
                cnt = 0
            if cnt > 0:
                clients.append({"comm": name, "count": cnt})
    info["ai_clients_running"] = clients

    rc, out, _ = _run(
        ["systemctl", "list-units", "--state=running", "--no-pager", "--no-legend"],
        timeout=5,
    )
    info["running_services_count"] = len([l for l in out.splitlines() if l.strip()])

    try:
        info["etc_hosts_lines"] = sum(1 for _ in open("/etc/hosts"))
    except OSError:
        info["etc_hosts_lines"] = 0

    def _active(svc: str) -> bool:
        rc, out, _ = _run(["systemctl", "is-active", svc], timeout=3)
        return out.strip() == "active"

    info["avahi_active"] = _active("avahi-daemon")
    info["resolved_active"] = _active("systemd-resolved")

    snap_cnt = 0
    if shutil.which("snap"):
        rc, out, _ = _run(["snap", "list"], timeout=5)
        if rc == 0:
            snap_cnt = max(0, len([l for l in out.splitlines() if l.strip()]) - 1)
    info["snap_installed_count"] = snap_cnt

    flatpak_cnt = 0
    if shutil.which("flatpak"):
        rc, out, _ = _run(["flatpak", "list"], timeout=5)
        if rc == 0:
            flatpak_cnt = len([l for l in out.splitlines() if l.strip()])
    info["flatpak_installed_count"] = flatpak_cnt

    return info


# ---------- verdict ----------
def build_verdict(net: Dict[str, Any], priv: Dict[str, Any],
                  tools_info: Dict[str, Any], oc: Dict[str, Any],
                  risks_info: Dict[str, Any]) -> Dict[str, Any]:
    blockers: List[str] = []
    warnings: List[str] = []

    cands = net.get("lmstudio_candidates", [])
    has_alive = any(c.get("alive") for c in cands)
    needle = os.environ.get("CONTCODE_MODEL_NEEDLE", "").strip()
    if not has_alive:
        blockers.append("no local endpoint responded (all candidates dead)")
    elif needle:
        has_match = any(c.get("alive") and c.get("has_model_match") for c in cands)
        if not has_match:
            blockers.append(
                f"endpoint alive but CONTCODE_MODEL_NEEDLE '{needle}' "
                f"not found in any model list"
            )

    if not oc.get("binary"):
        warnings.append("opencode binary not found (optional)")

    nft_p = tools_info.get("nft", {}).get("path")
    ipt_p = tools_info.get("iptables", {}).get("path")
    if not nft_p and not ipt_p:
        blockers.append("ne nft ne iptables var — L1 kernel_guard kurulamaz")

    if not priv.get("unshare_urm_ok"):
        warnings.append("unshare -Urm çalışmıyor; L2 DNS sinkhole düşer")
    if net.get("internet_reachable"):
        warnings.append("internet açık (1.1.1.1 ulaşılabiliyor) — firewall eksik olabilir")
    if not priv.get("sudo_nopasswd"):
        warnings.append("sudo -n yok; operatör interaktif parola girmeli")
    if not tools_info.get("tcpdump", {}).get("path"):
        warnings.append("tcpdump yok; L5 pcap audit devre dışı (L1-L4 yeterli)")
    if risks_info.get("avahi_active"):
        warnings.append("avahi-daemon aktif; prod'da kapatılmalı")
    if risks_info.get("ai_clients_running"):
        warnings.append("AI client process çalışıyor (claude/cursor/codeium/copilot)")

    # resolv.conf 10.x.x.x (WSL DNS bridge)
    nameservers = net.get("resolv_nameservers", [])
    if any(ns.startswith("10.") for ns in nameservers):
        warnings.append("resolv.conf WSL DNS bridge (10.x.x.x) içeriyor; prod'da 127.0.0.1 olmalı")

    return {
        "ready_for_hardened_install": len(blockers) == 0,
        "blockers": blockers,
        "warnings": warnings,
    }


# ---------- orchestrator ----------
def run_recon() -> Dict[str, Any]:
    start = time.time()
    ts = datetime.datetime.now(datetime.timezone.utc).astimezone().isoformat()

    be = base_env()
    net = network_info(wsl=be["wsl"])
    priv = privileges()
    tls = tools()
    oc = opencode_info()
    rsk = risks()
    verdict = build_verdict(net, priv, tls, oc, rsk)

    data = {
        "meta": {
            "timestamp": ts,
            "hostname": be["hostname"],
            "user": be["user"],
            "script_version": "contcode 1.0.0",
            "elapsed_seconds": round(time.time() - start, 2),
        },
        "base_env": be,
        "network": net,
        "privileges": priv,
        "tools": {k: v for k, v in tls.items() if not k.startswith("_")},
        "tcpdump_D_without_sudo": tls.get("_tcpdump_D_without_sudo", False),
        "systemd_run_user_scope_ok": tls.get("_systemd_run_user_scope_ok", False),
        "opencode": oc,
        "risks": rsk,
        "verdict": verdict,
    }
    return data


def format_text(data: Dict[str, Any]) -> str:
    lines: List[str] = []
    b = data["base_env"]
    n = data["network"]
    p = data["privileges"]
    v = data["verdict"]

    lines.append("=== contcode recon ===")
    lines.append(f"host={b['hostname']} user={b['user']} wsl={b['wsl']} os={b['os_pretty']}")
    lines.append(f"kernel={b['kernel']}")
    lines.append(f"cpus={b['cpus']} mem_kb={b.get('mem_total_kb',0)} home_free_gb={b.get('home_disk_free_gb',0)}")
    lines.append("")

    lines.append("--- Ağ ---")
    lines.append(f"default_gw={n.get('default_gw','')} win_host={n.get('windows_host_ip','')}")
    lines.append(f"internet_reachable={n.get('internet_reachable')} code={n.get('internet_probe_code')}")
    lines.append("nameservers: " + ", ".join(n.get("resolv_nameservers", []) or ["(yok)"]))
    lines.append("")

    lines.append("--- local endpoint probe ---")
    for c in n.get("lmstudio_candidates", []):
        lines.append(
            f"  {c['url']:<45} http={c['http_code']:<4} alive={str(c['alive']):<5} "
            f"models={c['model_count']:<3} model={c['has_model_match']}"
        )
    lines.append("")

    lines.append("--- Yetki ---")
    lines.append(f"sudo_nopasswd={p['sudo_nopasswd']} unshare_urm_ok={p['unshare_urm_ok']}")
    lines.append(f"cap_net_admin={p['cap_net_admin']} cap_net_raw={p['cap_net_raw']}")
    lines.append("")

    lines.append("--- Araçlar ---")
    for name, info in data["tools"].items():
        mark = "✅" if info["present"] else "❌"
        lines.append(f"  {mark} {name:<14} {info.get('path','')}")
    lines.append("")

    lines.append("--- Opencode ---")
    oc = data["opencode"]
    lines.append(f"binary={oc['binary']} version={oc['version']}")
    lines.append(f"cont_project_present={oc['cont_project_present']}")
    lines.append("")

    lines.append("=== VERDICT ===")
    lines.append(f"ready_for_hardened_install: {v['ready_for_hardened_install']}")
    lines.append(f"blockers ({len(v['blockers'])}):")
    for b2 in v["blockers"]:
        lines.append(f"  🚨 {b2}")
    lines.append(f"warnings ({len(v['warnings'])}):")
    for w in v["warnings"]:
        lines.append(f"  ⚠  {w}")
    lines.append("")
    lines.append(f"elapsed: {data['meta']['elapsed_seconds']}s")
    return "\n".join(lines)


def main(write_report: bool = True) -> Dict[str, Any]:
    data = run_recon()
    text = format_text(data)
    print(text)
    if write_report:
        json_path = reporting.save_json(data, "recon")
        text_path = reporting.save_text(text, "recon")
        print(f"\nJSON: {json_path}\nTEXT: {text_path}")
    return data
