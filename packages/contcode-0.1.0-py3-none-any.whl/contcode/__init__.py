"""contcode — offline verification suite for local LLM workflows.

Zero runtime dependencies. Python 3.10+. stdlib-only.
"""
__version__ = "0.1.0"
__all__ = ["__version__"]
