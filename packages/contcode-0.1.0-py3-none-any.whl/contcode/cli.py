"""contcode CLI entry point."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import List, Optional

from . import __version__
from . import _resources
from . import kernel_guard
from . import lmstudio
from . import pcap as pcap_mod
from . import recon
from . import reporting
from . import verify


def _cmd_recon(args: argparse.Namespace) -> int:
    recon.main(write_report=True)
    return 0


def _cmd_verify(args: argparse.Namespace) -> int:
    return verify.main(
        hardened=args.hardened,
        soft_only=args.soft_only,
        write_report=True,
    )


def _cmd_pcap(args: argparse.Namespace) -> int:
    tcpdump = shutil.which("tcpdump")
    if not tcpdump:
        print("tcpdump yok. Kurulum: sudo apt install tcpdump", file=sys.stderr)
        return 4

    sudo_ok = kernel_guard.sudo_nopasswd_available()
    guard_installed = False
    try:
        if args.guard and sudo_ok:
            rc, out, err = kernel_guard.install(scope="global")
            if rc == 0:
                guard_installed = True
                print(f"[pcap] kernel_guard --global install ok")
            else:
                print(f"[pcap] kernel_guard install başarısız rc={rc}: {err}",
                      file=sys.stderr)
        elif args.guard:
            print("[pcap] --guard istendi ama sudo -n yok; guard atlanıyor",
                  file=sys.stderr)

        cap_dir = reporting.report_dir() / "captures"
        cap_dir.mkdir(parents=True, exist_ok=True)
        ts = time.strftime("%Y%m%d_%H%M%S")
        pcap_path = cap_dir / f"session_{ts}.pcap"

        td_cmd = (["sudo", "-n"] if sudo_ok else []) + [
            tcpdump, "-i", args.iface, "-U", "-s", "0", "-w", str(pcap_path),
            "tcp or udp",
        ]
        print(f"[pcap] capture {args.duration}s → {pcap_path}")
        td = subprocess.Popen(td_cmd, stdout=subprocess.DEVNULL,
                              stderr=subprocess.DEVNULL)
        try:
            time.sleep(args.duration)
        finally:
            try:
                td.send_signal(2)  # SIGINT
            except Exception:
                pass
            try:
                td.wait(timeout=5)
            except subprocess.TimeoutExpired:
                td.kill()

        if sudo_ok:
            subprocess.run(
                ["sudo", "-n", "chown", f"{os.getuid()}:{os.getgid()}", str(pcap_path)],
                capture_output=True, timeout=5,
            )

        if not pcap_path.exists() or pcap_path.stat().st_size < 24:
            print("[pcap] capture üretilemedi (yetki?)", file=sys.stderr)
            return 4

        wl_spec = _resources.whitelist_default()
        report, violations = pcap_mod.build_report(
            pcap_path, wl_spec, local_nets_spec=None,
        )
        pcap_mod.print_table(report)

        report_dict = pcap_mod.report_to_dict(report)
        report_dict["source_pcap"] = str(pcap_path)
        json_path = reporting.save_json(report_dict, "pcap")
        print(f"JSON: {json_path}")
        return 0 if violations == 0 else 1
    finally:
        if guard_installed:
            kernel_guard.uninstall()
            print("[pcap] kernel_guard uninstall")


def _cmd_report(args: argparse.Namespace) -> int:
    items = reporting.list_recent(limit=20)
    if not items:
        print("(hiç rapor yok)")
        return 0
    print(f"{'file':<60} {'size':>8}  mtime")
    for p in items:
        st = p.stat()
        mt = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(st.st_mtime))
        print(f"{p.name:<60} {st.st_size:>8}  {mt}")
    print()

    # Son verify + recon'u göster
    latest_verify = reporting.latest_report("verify")
    if latest_verify:
        try:
            data = json.loads(latest_verify.read_text())
            print(f"=== son verify ({latest_verify.name}) ===")
            print(data.get("verdict", ""))
            for r in data.get("results", []):
                print(f"  [{r['status']}] {r['name']}: {r['summary']}")
        except Exception as e:
            print(f"latest_verify okunamadı: {e}")

    if args.export:
        target = Path(args.export)
        if latest_verify:
            md = reporting.export_markdown(latest_verify)
            target.write_text(md)
            print(f"\nexported markdown → {target}")
    return 0


def _cmd_selftest(args: argparse.Namespace) -> int:
    """Paket bütünlüğü kontrolü."""
    fails: List[str] = []

    # __version__
    if not isinstance(__version__, str) or not __version__:
        fails.append("__version__ eksik")
    print(f"version: {__version__}")

    # data erişimi
    try:
        wl = _resources.whitelist_default()
        print(f"whitelist default ({len(wl)} chars): {wl[:60]}...")
    except Exception as e:
        fails.append(f"whitelist: {e}")

    try:
        models = _resources.read_data("models.json")
        json.loads(models)
        print(f"models.json OK ({len(models)} chars)")
    except Exception as e:
        fails.append(f"models.json: {e}")

    # shell scripts
    for sh in ("kernel_guard.sh", "dns_sinkhole.sh", "ensure_lmstudio.sh"):
        try:
            p = _resources.shell_path(sh)
            print(f"shell/{sh}: {p}")
        except Exception as e:
            fails.append(f"shell/{sh}: {e}")

    # alt modül importları
    for mod in ("recon", "verify", "pcap", "deny_proxy", "kernel_guard",
                "dns_sinkhole", "lmstudio", "env_flags", "reporting"):
        try:
            __import__(f"contcode.{mod}")
            print(f"import contcode.{mod}: ok")
        except Exception as e:
            fails.append(f"import {mod}: {e}")

    if fails:
        print("\n❌ selftest başarısız:")
        for f in fails:
            print(f"  - {f}")
        return 1
    print("\n✅ selftest OK")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="contcode",
        description="Open Code offline defense + audit suite (bank-grade).",
    )
    p.add_argument("--version", action="version",
                   version=f"contcode {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("recon", help="Prod keşfi (read-only)")
    sp.set_defaults(func=_cmd_recon)

    sp = sub.add_parser("verify", help="Test suite'ini koştur")
    sp.add_argument("--hardened", action="store_true",
                    help="ileride L6 cgroup izolasyonu (şu an dolaylı)")
    sp.add_argument("--soft-only", action="store_true",
                    help="Sadece soft testler, kritik L1'i atla")
    sp.set_defaults(func=_cmd_verify)

    sp = sub.add_parser("pcap", help="tcpdump capture + whitelist analiz")
    sp.add_argument("--duration", type=int, default=15, help="saniye")
    sp.add_argument("--iface", default="any")
    sp.add_argument("--no-guard", dest="guard", action="store_false", default=True,
                    help="kernel_guard --global kurmadan capture yap")
    sp.set_defaults(func=_cmd_pcap)

    sp = sub.add_parser("report", help="Son raporları listele")
    sp.add_argument("--export", help="son verify raporunu markdown olarak yaz")
    sp.set_defaults(func=_cmd_report)

    sp = sub.add_parser("selftest", help="Paket bütünlüğü kontrolü")
    sp.set_defaults(func=_cmd_selftest)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        return 130
    except Exception as e:
        print(f"contcode hata: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
