"""kernel_guard.sh için Python wrapper.

Bash script'i paket içinden çıkartır (contcode/shell/kernel_guard.sh),
`sudo bash <script> install|uninstall|status ...` olarak çağırır.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple

from . import _resources


def script_path() -> Path:
    return _resources.shell_path("kernel_guard.sh")


def _run(argv: List[str], use_sudo: bool, timeout: int = 30) -> Tuple[int, str, str]:
    cmd = (["sudo", "-n"] if use_sudo else []) + argv
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", f"timeout after {timeout}s"
    except FileNotFoundError as e:
        return 127, "", str(e)


def sudo_nopasswd_available() -> bool:
    rc, _, _ = _run(["true"], use_sudo=True, timeout=3)
    return rc == 0


def status() -> Tuple[int, str]:
    rc, out, err = _run(["bash", str(script_path()), "status"], use_sudo=False)
    return rc, (out or "") + (err or "")


def is_loaded() -> bool:
    # nft/iptables query — sudo gerektirebilir ama status subcommand zaten sudo'suz dener
    rc, combined = status()
    return "YÜKLÜ" in combined


def install(scope: str = "uid", uid: Optional[int] = None,
            lmstudio_host: Optional[str] = None,
            lmstudio_port: int = 1234) -> Tuple[int, str, str]:
    """Install kernel_guard. scope: 'uid' | 'global'.

    Returns (rc, stdout, stderr). sudo_nopasswd yoksa rc=126 ve user'a mesaj.
    """
    if not sudo_nopasswd_available():
        return 126, "", (
            "sudo -n başarısız. Elle çalıştırın:\n"
            f"  sudo bash {script_path()} install --{scope}-scope "
            f"{uid if scope=='uid' else ''}\n"
        )

    env = os.environ.copy()
    if lmstudio_host:
        env["LMSTUDIO_HOST"] = lmstudio_host
    env["LMSTUDIO_PORT"] = str(lmstudio_port)

    argv = ["sudo", "-n", "bash", str(script_path()), "install"]
    if scope == "global":
        argv.append("--global")
    else:
        argv.append("--uid-scope")
        argv.append(str(uid if uid is not None else os.getuid()))

    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=30, env=env)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"


def uninstall() -> Tuple[int, str, str]:
    if not sudo_nopasswd_available():
        return 126, "", (
            f"sudo -n başarısız. Elle: sudo bash {script_path()} uninstall\n"
        )
    argv = ["sudo", "-n", "bash", str(script_path()), "uninstall"]
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=15)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"


def backend_available() -> dict:
    """nft veya iptables var mı, sudo ile okunabiliyor mu?"""
    return {
        "nft_path": shutil.which("nft"),
        "iptables_path": shutil.which("iptables"),
        "sudo_nopasswd": sudo_nopasswd_available(),
    }
