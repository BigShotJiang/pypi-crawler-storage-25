"""Rapor üretimi — JSON + markdown + konsol tablosu."""
from __future__ import annotations

import datetime
import json
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


REPORT_ROOT = Path(os.environ.get("OPENCODE_AUDIT_REPORT_DIR", "/tmp/contcode"))


def report_dir() -> Path:
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    return REPORT_ROOT


def save_json(data: Dict[str, Any], prefix: str) -> Path:
    ts = time.strftime("%Y%m%d_%H%M%S")
    out = report_dir() / f"{prefix}_{ts}.json"
    out.write_text(json.dumps(data, indent=2, default=str, ensure_ascii=False))
    return out


def save_text(text: str, prefix: str, ext: str = "txt") -> Path:
    ts = time.strftime("%Y%m%d_%H%M%S")
    out = report_dir() / f"{prefix}_{ts}.{ext}"
    out.write_text(text)
    return out


def list_recent(limit: int = 20) -> List[Path]:
    root = report_dir()
    items = sorted(root.glob("*"), key=lambda p: p.stat().st_mtime, reverse=True)
    return items[:limit]


def latest_report(prefix: str) -> Optional[Path]:
    root = report_dir()
    items = sorted(
        root.glob(f"{prefix}_*.json"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    return items[0] if items else None


def export_markdown(json_path: Path) -> str:
    data = json.loads(json_path.read_text())
    lines: List[str] = [f"# contcode report — {json_path.name}", ""]

    meta = data.get("meta", {})
    if meta:
        lines.append("## Meta")
        for k, v in meta.items():
            lines.append(f"- **{k}**: {v}")
        lines.append("")

    verdict = data.get("verdict")
    if verdict:
        lines.append("## Verdict")
        lines.append(f"- **ready_for_hardened_install**: {verdict.get('ready_for_hardened_install')}")
        blockers = verdict.get("blockers", [])
        warnings = verdict.get("warnings", [])
        lines.append(f"- blockers ({len(blockers)}):")
        for b in blockers:
            lines.append(f"  - 🚨 {b}")
        lines.append(f"- warnings ({len(warnings)}):")
        for w in warnings:
            lines.append(f"  - ⚠  {w}")
        lines.append("")

    if "lmstudio_candidates" in data.get("network", {}):
        lines.append("## local endpoint / Ollama probe")
        lines.append("| URL | HTTP | alive | models | model |")
        lines.append("|-----|------|-------|--------|---------|")
        for c in data["network"]["lmstudio_candidates"]:
            lines.append(
                f"| {c['url']} | {c['http_code']} | {c['alive']} | "
                f"{c['model_count']} | {c['has_model_match']} |"
            )
        lines.append("")

    tools = data.get("tools", {})
    if tools:
        lines.append("## Tools")
        lines.append("| tool | present | path | version |")
        lines.append("|------|---------|------|---------|")
        for name, info in tools.items():
            lines.append(
                f"| {name} | {info.get('present')} | "
                f"{info.get('path','')} | {info.get('version','')[:40]} |"
            )
        lines.append("")

    return "\n".join(lines)
