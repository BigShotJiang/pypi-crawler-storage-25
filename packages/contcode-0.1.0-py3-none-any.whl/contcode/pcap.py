#!/usr/bin/env python3
# v2.2 | 2026-04-19 | pcap audit — bidirectional flow grouping
"""Stdlib-only pcap parser (libpcap classic + LINKTYPE_LINUX_SLL/SLL2).

v2.2 değişiklik:
  Flow'lar yön-bağımsız (bidirectional) gruplanıyor. Client→server ile
  server→client dönüş paketleri aynı flow. Whitelist kontrolü "remote
  endpoint"e (yani lokal olmayan tarafa) uygulanır.
  Lokal IP'ler otomatik tespit edilir: `ip -4 addr show` + 127.0.0.0/8.

Tercih sırası:
  1. tshark varsa → `-T fields` wrap et (hızlı, doğru)
  2. Yoksa → stdlib struct ile libpcap'i parse et

Kullanım:
  analyze_pcap.py <pcap> [--whitelist HOST:PORT,...]
                         [--local-nets HOST/MASK,...]
                         [--json report.json]

Whitelist default:  127.0.0.0/8  (user adds endpoint via config)
Local-nets default: WSL eth0 + docker0 + lo (otomatik tespit)

Exit:
  0 → whitelist dışı remote endpoint yok
  1 → whitelist dışı endpoint tespit edildi
  2 → dosya/format hatası
"""
from __future__ import annotations

import argparse
import ipaddress
import json
import os
import shutil
import struct
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

# libpcap constants
PCAP_MAGIC_LE = 0xA1B2C3D4
PCAP_MAGIC_BE = 0xD4C3B2A1
PCAP_MAGIC_NSEC_LE = 0xA1B23C4D
PCAP_MAGIC_NSEC_BE = 0x4D3CB2A1

LINKTYPE_ETHERNET = 1
LINKTYPE_RAW = 101
LINKTYPE_LINUX_SLL = 113
LINKTYPE_LINUX_SLL2 = 276

DEFAULT_WHITELIST = "127.0.0.0/8"


@dataclass
class Flow:
    # "remote" = local olmayan taraf; whitelist buna uygulanır
    remote_ip: str
    remote_port: int
    proto: str
    packets: int = 0
    bytes: int = 0
    allowed: bool = False
    direction: str = "bidir"  # out|in|bidir|loopback|external


@dataclass
class Report:
    pcap: str
    total_packets: int = 0
    parsed_packets: int = 0
    flows: dict = field(default_factory=dict)  # (remote_ip, remote_port, proto) → Flow
    local_nets: list = field(default_factory=list)
    parser: str = ""
    errors: list = field(default_factory=list)


# ----- local nets autodetect -----
def detect_local_nets() -> list:
    """ip -4 addr show + lo → list[IPv4Network]."""
    nets: list = [ipaddress.ip_network("127.0.0.0/8")]
    try:
        out = subprocess.check_output(
            ["ip", "-o", "-4", "addr", "show"], text=True, stderr=subprocess.DEVNULL
        )
    except (subprocess.SubprocessError, FileNotFoundError):
        return nets
    for line in out.splitlines():
        parts = line.split()
        for i, p in enumerate(parts):
            if p == "inet" and i + 1 < len(parts):
                try:
                    # Her interface IP'sini /32 lokal kabul et (strict=False ağı da kabul etsin)
                    addr = parts[i + 1].split("/")[0]
                    nets.append(ipaddress.ip_network(f"{addr}/32"))
                except ValueError:
                    pass
    # dedup
    seen: set = set()
    out_nets: list = []
    for n in nets:
        if str(n) not in seen:
            seen.add(str(n))
            out_nets.append(n)
    return out_nets


def parse_local_nets(spec: str | None) -> list:
    if not spec:
        return detect_local_nets()
    nets: list = []
    for token in spec.split(","):
        token = token.strip()
        if not token:
            continue
        if "/" not in token:
            token = f"{token}/32" if ":" not in token else f"{token}/128"
        nets.append(ipaddress.ip_network(token, strict=False))
    return nets


def is_local(ip_str: str, local_nets: list) -> bool:
    try:
        addr = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    for n in local_nets:
        if addr.version == n.version and addr in n:
            return True
    return False


# ----- whitelist -----
def parse_whitelist(spec: str):
    """Return (any_port_nets, [(net, port)...])."""
    any_port: list = []
    specific: list = []
    for token in spec.split(","):
        token = token.strip()
        if not token:
            continue
        if ":" in token and "/" not in token.split(":")[0]:
            host_s, port_s = token.rsplit(":", 1)
            try:
                port = int(port_s)
            except ValueError:
                port = 0
        else:
            host_s, port = token, 0
        if "/" not in host_s:
            host_s = f"{host_s}/32" if ":" not in host_s else f"{host_s}/128"
        net = ipaddress.ip_network(host_s, strict=False)
        if port == 0:
            any_port.append(net)
        else:
            specific.append((net, port))
    return any_port, specific


def is_allowed(ip_str: str, port: int, any_port, specific) -> bool:
    try:
        addr = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    for n in any_port:
        if addr.version == n.version and addr in n:
            return True
    for n, p in specific:
        if addr.version == n.version and addr in n and p == port:
            return True
    return False


# ----- canonical (bidirectional) flow key -----
def canonical_flow(src_ip: str, src_port: int,
                   dst_ip: str, dst_port: int,
                   proto: str, local_nets: list):
    """
    Bir paket için yön-bağımsız flow anahtarı üret.
    Döner: (remote_ip, remote_port, proto, direction)
    direction: "out" (local→remote), "in" (remote→local),
               "loopback" (local→local), "external" (uzak↔uzak, olmamalı)
    """
    src_local = is_local(src_ip, local_nets)
    dst_local = is_local(dst_ip, local_nets)
    if src_local and not dst_local:
        return (dst_ip, dst_port, proto, "out")
    if dst_local and not src_local:
        return (src_ip, src_port, proto, "in")
    if src_local and dst_local:
        # Loopback: "remote" = dst (arbitrary ama consistent)
        return (dst_ip, dst_port, proto, "loopback")
    return (dst_ip, dst_port, proto, "external")


# ----- tshark parser -----
def analyze_with_tshark(pcap: Path) -> list:
    """Returns list of (src_ip, src_port, dst_ip, dst_port, proto, frame_len)."""
    cmd = [
        "tshark", "-r", str(pcap), "-n",
        "-T", "fields",
        "-e", "ip.src", "-e", "ipv6.src",
        "-e", "ip.dst", "-e", "ipv6.dst",
        "-e", "tcp.srcport", "-e", "udp.srcport",
        "-e", "tcp.dstport", "-e", "udp.dstport",
        "-e", "frame.len",
    ]
    out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True)
    rows: list = []
    for line in out.splitlines():
        parts = line.split("\t")
        if len(parts) < 9:
            continue
        src_ip = parts[0] or parts[1]
        dst_ip = parts[2] or parts[3]
        if not src_ip or not dst_ip:
            continue
        if parts[4] or parts[6]:
            proto = "tcp"
            src_port = parts[4]
            dst_port = parts[6]
        elif parts[5] or parts[7]:
            proto = "udp"
            src_port = parts[5]
            dst_port = parts[7]
        else:
            continue
        try:
            sp = int(src_port)
            dp = int(dst_port)
            length = int(parts[8])
        except ValueError:
            continue
        rows.append((src_ip, sp, dst_ip, dp, proto, length))
    return rows


# ----- stdlib parser -----
def _read_pcap_header(f):
    hdr = f.read(24)
    if len(hdr) < 24:
        raise ValueError("pcap: header kısa")
    magic = struct.unpack("<I", hdr[:4])[0]
    if magic in (PCAP_MAGIC_LE, PCAP_MAGIC_NSEC_LE):
        big = False
    elif magic in (PCAP_MAGIC_BE, PCAP_MAGIC_NSEC_BE):
        big = True
    else:
        raise ValueError(f"bilinmeyen pcap magic: 0x{magic:08x}")
    fmt = ">I" if big else "<I"
    link_type = struct.unpack(fmt, hdr[20:24])[0]
    return big, link_type


def _iter_packets(f, big: bool):
    fmt = ">IIII" if big else "<IIII"
    while True:
        rec = f.read(16)
        if len(rec) < 16:
            return
        ts_sec, ts_usec, incl_len, orig_len = struct.unpack(fmt, rec)
        data = f.read(incl_len)
        if len(data) < incl_len:
            return
        yield data, orig_len


def _parse_ethernet(data: bytes):
    if len(data) < 14:
        return None
    eth_type = struct.unpack(">H", data[12:14])[0]
    offset = 14
    if eth_type == 0x8100 and len(data) >= 18:
        eth_type = struct.unpack(">H", data[16:18])[0]
        offset = 18
    if eth_type == 0x0800:
        return data[offset:]
    return None


def _parse_sll(data: bytes):
    if len(data) < 16:
        return None
    proto = struct.unpack(">H", data[14:16])[0]
    if proto == 0x0800:
        return data[16:]
    return None


def _parse_sll2(data: bytes):
    if len(data) < 20:
        return None
    proto = struct.unpack(">H", data[0:2])[0]
    if proto == 0x0800:
        return data[20:]
    return None


def _parse_ipv4(data: bytes):
    """Returns (src_ip, src_port, dst_ip, dst_port, proto, total_len) or None."""
    if len(data) < 20:
        return None
    version_ihl = data[0]
    if version_ihl >> 4 != 4:
        return None
    ihl = (version_ihl & 0x0F) * 4
    if ihl < 20 or len(data) < ihl:
        return None
    total_len = struct.unpack(">H", data[2:4])[0]
    proto_num = data[9]
    src_ip = ".".join(str(b) for b in data[12:16])
    dst_ip = ".".join(str(b) for b in data[16:20])
    payload = data[ihl:]
    if proto_num == 6:
        if len(payload) < 20:
            return None
        src_port, dst_port = struct.unpack(">HH", payload[0:4])
        return (src_ip, src_port, dst_ip, dst_port, "tcp", total_len)
    if proto_num == 17:
        if len(payload) < 8:
            return None
        src_port, dst_port = struct.unpack(">HH", payload[0:4])
        return (src_ip, src_port, dst_ip, dst_port, "udp", total_len)
    return None


def analyze_stdlib(pcap: Path) -> list:
    rows: list = []
    with pcap.open("rb") as f:
        big, link_type = _read_pcap_header(f)
        for data, orig_len in _iter_packets(f, big):
            if link_type == LINKTYPE_ETHERNET:
                ip_pkt = _parse_ethernet(data)
            elif link_type == LINKTYPE_LINUX_SLL:
                ip_pkt = _parse_sll(data)
            elif link_type == LINKTYPE_LINUX_SLL2:
                ip_pkt = _parse_sll2(data)
            elif link_type == LINKTYPE_RAW:
                ip_pkt = data
            else:
                continue
            if ip_pkt is None:
                continue
            parsed = _parse_ipv4(ip_pkt)
            if parsed is None:
                continue
            rows.append(parsed)
    return rows


# ----- report -----
def build_report(pcap: Path, whitelist_spec: str,
                 local_nets_spec: str | None = None):
    any_port, specific = parse_whitelist(whitelist_spec)
    local_nets = parse_local_nets(local_nets_spec)

    report = Report(pcap=str(pcap))
    report.local_nets = [str(n) for n in local_nets]

    if shutil.which("tshark"):
        report.parser = "tshark"
        rows = analyze_with_tshark(pcap)
    else:
        report.parser = "stdlib"
        rows = analyze_stdlib(pcap)

    report.total_packets = len(rows)
    report.parsed_packets = len(rows)

    for src_ip, src_port, dst_ip, dst_port, proto, length in rows:
        remote_ip, remote_port, p, direction = canonical_flow(
            src_ip, src_port, dst_ip, dst_port, proto, local_nets
        )
        key = (remote_ip, remote_port, p)
        flow = report.flows.get(key)
        if flow is None:
            flow = Flow(remote_ip=remote_ip, remote_port=remote_port, proto=p,
                        direction=direction)
            flow.allowed = is_allowed(remote_ip, remote_port, any_port, specific)
            report.flows[key] = flow
        else:
            # Eğer iki yön görülürse bidir işaretle
            if flow.direction != direction and direction in ("in", "out"):
                flow.direction = "bidir"
        flow.packets += 1
        flow.bytes += length

    violations = sum(1 for fl in report.flows.values() if not fl.allowed)
    return report, violations


def print_table(report: Report):
    print(f"{'STATUS':<7} {'DIR':<9} {'REMOTE':<39} {'PORT':<6} {'PROTO':<5} {'PKT':>6} {'BYTES':>8}")
    print("-" * 86)
    items = sorted(report.flows.values(), key=lambda f: (f.allowed, -f.packets))
    for f in items:
        status = "ALLOW" if f.allowed else "DENY"
        print(f"{status:<7} {f.direction:<9} {f.remote_ip:<39} {f.remote_port:<6} {f.proto:<5} {f.packets:>6} {f.bytes:>8}")
    print("-" * 86)
    allowed = sum(1 for f in report.flows.values() if f.allowed)
    denied = len(report.flows) - allowed
    print(f"parser={report.parser}  flows={len(report.flows)} allow={allowed} deny={denied} packets={report.total_packets}")
    print(f"local_nets={report.local_nets}")


def report_to_dict(report: Report) -> dict:
    return {
        "pcap": report.pcap,
        "parser": report.parser,
        "total_packets": report.total_packets,
        "parsed_packets": report.parsed_packets,
        "local_nets": report.local_nets,
        "errors": report.errors,
        "flows": [
            {
                "remote_ip": f.remote_ip,
                "remote_port": f.remote_port,
                "proto": f.proto,
                "direction": f.direction,
                "packets": f.packets,
                "bytes": f.bytes,
                "allowed": f.allowed,
            }
            for f in sorted(report.flows.values(), key=lambda f: (f.allowed, -f.packets))
        ],
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("pcap", type=Path)
    ap.add_argument("--whitelist", default=DEFAULT_WHITELIST)
    ap.add_argument("--local-nets", default=None,
                    help="virgülle ayrılmış lokal IP/CIDR; verilmezse ip addr ile tespit")
    ap.add_argument("--json", type=Path)
    args = ap.parse_args()

    if not args.pcap.exists():
        print(f"pcap bulunamadı: {args.pcap}", file=sys.stderr)
        return 2

    try:
        report, violations = build_report(args.pcap, args.whitelist, args.local_nets)
    except ValueError as e:
        print(f"pcap parse hatası: {e}", file=sys.stderr)
        return 2

    print_table(report)

    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(report_to_dict(report), indent=2))
        print(f"json: {args.json}")

    if violations > 0:
        print(f"❌ whitelist dışı {violations} flow", file=sys.stderr)
        return 1
    print("✅ tüm flow'lar whitelist içinde")
    return 0


if __name__ == "__main__":
    sys.exit(main())
