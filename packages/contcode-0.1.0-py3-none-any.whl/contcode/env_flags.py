"""offline_env.sh'in Python karşılığı — opencode env bayrakları."""
from __future__ import annotations

import os
from typing import Dict, Optional


def offline_flags(
    proxy_host: str = "127.0.0.1",
    proxy_port: int = 9876,
    windows_host: Optional[str] = None,
    models_path: Optional[str] = None,
) -> Dict[str, str]:
    """opencode'u offline moda sokacak env bayrakları.

    Kullanıcı bu dict'i mevcut env'e merge edebilir veya subprocess.run
    çağrısına env= parametresi olarak verebilir.
    """
    proxy_url = f"http://{proxy_host}:{proxy_port}"
    no_proxy = "127.0.0.1,localhost,::1"
    if windows_host:
        no_proxy += f",{windows_host}"

    flags: Dict[str, str] = {
        # Katman A: opencode soft flags
        "OPENCODE_DISABLE_AUTOUPDATE": "1",
        "OPENCODE_DISABLE_MODELS_FETCH": "1",
        "OPENCODE_DISABLE_LSP_DOWNLOAD": "1",
        "OPENCODE_DISABLE_SHARE": "1",
        "OPENCODE_DISABLE_DEFAULT_PLUGINS": "1",
        "OPENCODE_DISABLE_EXTERNAL_SKILLS": "1",
        "OPENCODE_DISABLE_EMBEDDED_WEB_UI": "1",
        "OPENCODE_DISABLE_CLAUDE_CODE": "1",
        "OPENCODE_AUTO_SHARE": "0",
        "DO_NOT_TRACK": "1",
        "NO_UPDATE_NOTIFIER": "1",
        "BUN_CRASH_REPORT": "0",
        # Katman D: proxy
        "HTTP_PROXY": proxy_url,
        "HTTPS_PROXY": proxy_url,
        "ALL_PROXY": proxy_url,
        "http_proxy": proxy_url,
        "https_proxy": proxy_url,
        "all_proxy": proxy_url,
        "NO_PROXY": no_proxy,
        "no_proxy": no_proxy,
        "NPM_CONFIG_REGISTRY": proxy_url,
        "BUN_CONFIG_REGISTRY": proxy_url,
    }
    if models_path and os.path.exists(models_path):
        flags["OPENCODE_MODELS_PATH"] = models_path
    return flags


REQUIRED_FLAGS = (
    "OPENCODE_DISABLE_AUTOUPDATE",
    "OPENCODE_DISABLE_MODELS_FETCH",
    "OPENCODE_DISABLE_LSP_DOWNLOAD",
    "OPENCODE_DISABLE_SHARE",
    "OPENCODE_DISABLE_DEFAULT_PLUGINS",
    "OPENCODE_DISABLE_EXTERNAL_SKILLS",
    "OPENCODE_DISABLE_EMBEDDED_WEB_UI",
    "OPENCODE_DISABLE_CLAUDE_CODE",
    "DO_NOT_TRACK",
    "NO_UPDATE_NOTIFIER",
    "HTTP_PROXY",
    "HTTPS_PROXY",
    "ALL_PROXY",
    "NO_PROXY",
    "NPM_CONFIG_REGISTRY",
    "BUN_CONFIG_REGISTRY",
)


def check_env(env: Optional[Dict[str, str]] = None) -> Dict[str, bool]:
    """Mevcut env'de gerekli bayraklar set mi?"""
    src = env if env is not None else os.environ
    return {k: bool(src.get(k)) for k in REQUIRED_FLAGS}
