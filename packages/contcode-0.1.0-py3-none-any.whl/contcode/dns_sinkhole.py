"""dns_sinkhole.sh için Python wrapper.

unshare -Urm ile mount namespace açıp özel resolv.conf/hosts bind eder.
Sudo gerektirmez (modern kernel user ns).
"""
from __future__ import annotations

import subprocess
from pathlib import Path
from typing import List, Tuple

from . import _resources


def script_path() -> Path:
    return _resources.shell_path("dns_sinkhole.sh")


def usable() -> bool:
    """unshare -Urm çalışıyor mu?"""
    try:
        p = subprocess.run(
            ["unshare", "-Urm", "true"],
            capture_output=True, timeout=3,
        )
        return p.returncode == 0
    except (subprocess.SubprocessError, FileNotFoundError):
        return False


def test_run() -> Tuple[int, str]:
    """`dns_sinkhole.sh test` — ns içinde DNS çözümlerini raporlar."""
    try:
        p = subprocess.run(
            ["bash", str(script_path()), "test"],
            capture_output=True, text=True, timeout=15,
        )
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except subprocess.TimeoutExpired:
        return 124, "timeout"


def wrap(cmd: List[str], timeout: int = 0) -> Tuple[int, str, str]:
    """Verilen komutu dns_sinkhole wrap içinde çalıştır."""
    argv = ["bash", str(script_path()), "wrap", "--"] + list(cmd)
    kwargs = {"capture_output": True, "text": True}
    if timeout > 0:
        kwargs["timeout"] = timeout
    p = subprocess.run(argv, **kwargs)
    return p.returncode, p.stdout or "", p.stderr or ""
