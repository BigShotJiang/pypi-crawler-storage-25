# BooleaBayes is now bobaT

This package has been renamed. Use `pip install bobaT` instead.

New package: https://pypi.org/project/bobaT/
