## Review Certificate

**Project:** AntibioSim
**Iterations:** 2
**Final status:** APPROVED FOR PUBLICATION
**Reviewed by:** Academic Reviewer, Engineering Reviewer, Devil's Advocate, Consistency Reviewer
**Date:** 2026-04-07

### Resolved Issues

1. **Paper PK model claim clarified** (Academic): Paper now states current environments use one-compartment models; two-compartment is provided for future extensions. Previously implied all environments used both.
2. **Mutation rate description corrected** (Academic): Paper now documents that the ResistanceControl environment modulates mutation rate by antibiotic spectrum pressure, matching the code implementation. Previously stated a fixed rate.
3. **Resistance factor range clarified** (Academic, Consistency): Paper now notes "depending on environment" for the 0.1-0.15 range, matching fixed values in different environments.
4. **Statistical notes section added** (Devil's Advocate): New subsection explains the 20.5x ratio computation methodology, acknowledges non-significance of small differences in AntibioticSelection/TherapySwitch, and clarifies cross-environment reward scale incomparability.
5. **README badge updated** (Consistency): Test count badge updated from placeholder to actual count of 170.

### Accepted LOW Items

1. EmaxModel and TwoCompartmentPK defined but unused in current environments: Acceptable as library components for user extensibility and future work.
2. No hyperparameter sensitivity analysis: Standard for benchmark papers; hyperparameters are documented for reproducibility.
3. Episode termination semantics (terminated vs truncated): Follows Gymnasium v0.29+ convention; no further documentation needed.
4. Inconsistent capitalization (AntibioSim vs antibiosim): Package name is lowercase per Python convention; display name is title-case. Standard practice.

### False Positives from Initial Review

- Heuristic agent "missing": exists at `src/antibiosim/agents/heuristic_agent.py`
- Figures "missing": exist at `paper/figures/` (training_curves.png, baseline_comparison.png, architecture.png)
- Bibliography "missing": exists at `paper/references.bib` (14 entries)
- Patient generator "missing": exists at `src/antibiosim/models/patient.py`
- Test count "unverified": verified by pytest output (170 passed in 0.36s)
