"""Benchmark runner for AntibioSim environments.

Runs all environments through standardized evaluation and reports metrics.
Usage: antibiosim-benchmark
"""

from __future__ import annotations

import argparse
import json
import time

import gymnasium as gym
import numpy as np

import antibiosim  # noqa: F401 - triggers env registration
from antibiosim.agents.heuristic_agent import HeuristicAgent
from antibiosim.agents.random_agent import RandomAgent
from antibiosim.training.configs import ENV_CONFIGS


def benchmark_env(env_id: str, n_episodes: int = 100) -> dict:
    """Run benchmark for a single environment with random and heuristic agents."""
    env = gym.make(env_id)

    # Random baseline
    random_agent = RandomAgent(env, seed=42)
    random_results = random_agent.evaluate(n_episodes)

    # Heuristic baseline
    heuristic = HeuristicAgent(env_id, seed=42)
    heuristic_rewards = []
    for ep in range(n_episodes):
        obs, _ = env.reset(seed=ep + 2000)
        total_r = 0.0
        done = False
        while not done:
            action = heuristic.act(obs)
            obs, r, term, trunc, _ = env.step(action)
            total_r += float(r)
            done = term or trunc
        heuristic_rewards.append(total_r)

    env.close()

    return {
        "env_id": env_id,
        "random": random_results,
        "heuristic": {
            "mean_reward": float(np.mean(heuristic_rewards)),
            "std_reward": float(np.std(heuristic_rewards)),
            "n_episodes": n_episodes,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Benchmark AntibioSim environments")
    parser.add_argument("--episodes", type=int, default=100)
    parser.add_argument("--output", type=str, default=None)
    args = parser.parse_args()

    results = {}
    for env_id in ENV_CONFIGS:
        print(f"Benchmarking {env_id}...")
        start = time.time()
        result = benchmark_env(env_id, args.episodes)
        elapsed = time.time() - start
        result["wall_time_seconds"] = round(elapsed, 1)
        env_short = env_id.split("/")[-1]
        results[env_short] = result
        print(f"  Random: {result['random']['mean_reward']:.2f}, "
              f"Heuristic: {result['heuristic']['mean_reward']:.2f} "
              f"({elapsed:.1f}s)")

    if args.output:
        with open(args.output, "w") as f:
            json.dump(results, f, indent=2)
        print(f"\nResults saved to {args.output}")

    return


if __name__ == "__main__":
    main()
