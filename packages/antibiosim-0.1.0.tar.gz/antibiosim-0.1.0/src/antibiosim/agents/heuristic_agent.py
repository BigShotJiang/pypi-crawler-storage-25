"""Heuristic baseline agents for AntibioSim environments.

Implements clinical guideline-based heuristics for each environment to serve
as meaningful baselines beyond random action selection.
"""

from __future__ import annotations

import numpy as np


class HeuristicAgent:
    """Guideline-based heuristic agent that implements simple clinical rules.

    Supports all four AntibioSim environments via environment-specific policies.
    """

    def __init__(self, env_id: str, seed: int = 42) -> None:
        self.env_id = env_id
        self.rng = np.random.default_rng(seed)

    def act(self, obs: np.ndarray) -> int | np.ndarray:
        """Select action based on clinical heuristic for the environment."""
        if "AntibioticSelection" in self.env_id:
            return self._selection_heuristic(obs)
        elif "DoseOptimization" in self.env_id:
            return self._dose_heuristic(obs)
        elif "TherapySwitch" in self.env_id:
            return self._switch_heuristic(obs)
        elif "ResistanceControl" in self.env_id:
            return self._resistance_heuristic(obs)
        else:
            raise ValueError(f"Unknown environment: {self.env_id}")

    def _selection_heuristic(self, obs: np.ndarray) -> int:
        """Start narrow, escalate if not improving.

        Clinical rule: Start with amoxicillin (narrow, oral, cheap).
        If bacterial load high and immunocompromised, use meropenem.
        """
        mic = obs[5]
        severity = obs[6]
        immunocompromised = obs[9]
        bacterial_load = obs[11]

        if immunocompromised > 0.5 or severity > 7.0:
            return 3  # meropenem (broad, strong)
        elif bacterial_load > 1e8 and mic > 4.0:
            return 1  # vancomycin (covers resistant gram-positive)
        elif mic > 8.0:
            return 0  # ciprofloxacin (concentration-dependent)
        else:
            return 2  # amoxicillin (narrow, first-line)

    def _dose_heuristic(self, obs: np.ndarray) -> np.ndarray:
        """Standard dosing with renal adjustment.

        Clinical rule: Give 50% of max dose, adjust down for impaired renal function.
        """
        crcl = obs[3]
        trough = obs[6]

        base_fraction = 0.5
        if crcl < 30:
            base_fraction = 0.25
        elif crcl < 60:
            base_fraction = 0.35

        # Reduce if trough is high (accumulation risk)
        if trough > 20.0:
            base_fraction *= 0.7

        return np.array([base_fraction], dtype=np.float32)

    def _switch_heuristic(self, obs: np.ndarray) -> int:
        """IV-to-oral switch when clinically stable.

        Clinical rule (Barlam et al., 2016):
        - Switch to oral when afebrile for 48h and tolerating oral
        - De-escalate when cultures show susceptibility
        - Continue if unstable
        """
        temperature = obs[4]
        oral_tolerance = obs[7]
        days_on_current = obs[2]
        current_therapy = int(obs[3])

        # If temperature normal and oral tolerance good, switch to oral
        if temperature < 38.0 and oral_tolerance > 0.6 and current_therapy % 2 == 0:
            return 1  # Switch to oral

        # If stable for 3+ days on broad, de-escalate
        if temperature < 38.0 and days_on_current >= 3 and current_therapy >= 2:
            return 3  # De-escalate

        return 0  # Continue current

    def _resistance_heuristic(self, obs: np.ndarray) -> np.ndarray:
        """Use narrowest effective spectrum per patient.

        Clinical rule: Narrow spectrum by default, moderate if severity high,
        broad only for resistant infections.
        """
        actions = np.zeros(5, dtype=np.int64)
        for bed in range(5):
            base = bed * 5
            n_resistant = obs[base + 1]
            n_susceptible = obs[base]
            severity = obs[base + 4]

            total = n_susceptible + n_resistant
            if total > 0 and n_resistant / total > 0.3:
                actions[bed] = 2  # Broad for resistant
            elif severity > 6.0:
                actions[bed] = 1  # Moderate for severe
            else:
                actions[bed] = 0  # Narrow default

        return actions
