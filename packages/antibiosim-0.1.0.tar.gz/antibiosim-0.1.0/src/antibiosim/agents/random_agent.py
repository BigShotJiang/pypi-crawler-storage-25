"""Random baseline agent for AntibioSim environments."""

from __future__ import annotations

import gymnasium as gym
import numpy as np


class RandomAgent:
    """Agent that selects actions uniformly at random from the action space."""

    def __init__(self, env: gym.Env, seed: int = 42) -> None:
        self.env = env
        self.rng = np.random.default_rng(seed)

    def act(self, obs: np.ndarray) -> int | np.ndarray:
        """Select a random action."""
        return self.env.action_space.sample()

    def evaluate(self, n_episodes: int = 100) -> dict[str, float]:
        """Evaluate agent over n_episodes, return mean and std reward."""
        rewards = []
        for ep in range(n_episodes):
            obs, _ = self.env.reset(seed=ep)
            total_reward = 0.0
            done = False
            while not done:
                action = self.act(obs)
                obs, reward, terminated, truncated, _ = self.env.step(action)
                total_reward += reward
                done = terminated or truncated
            rewards.append(total_reward)

        return {
            "mean_reward": float(np.mean(rewards)),
            "std_reward": float(np.std(rewards)),
            "min_reward": float(np.min(rewards)),
            "max_reward": float(np.max(rewards)),
            "n_episodes": n_episodes,
        }
