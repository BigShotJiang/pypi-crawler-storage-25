"""PPO training CLI entrypoint for AntibioSim environments.

Shares hyperparameters with train_all.py via training/configs.py.
Usage: antibiosim-train --env antibiosim/DoseOptimization-v0
"""

from __future__ import annotations

import argparse
import json
import os
import sys


def main() -> None:
    parser = argparse.ArgumentParser(description="Train PPO on AntibioSim environments")
    parser.add_argument(
        "--env",
        type=str,
        default="antibiosim/AntibioticSelection-v0",
        help="Environment ID to train on",
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--output-dir", type=str, default="results", help="Output directory")
    args = parser.parse_args()

    try:
        import gymnasium as gym
        import numpy as np
        from stable_baselines3 import PPO
        from stable_baselines3.common.callbacks import EvalCallback
    except ImportError:
        print("Install training dependencies: pip install antibiosim[train]")
        sys.exit(1)

    from antibiosim.training.configs import ENV_CONFIGS

    import random

    config = ENV_CONFIGS.get(args.env, ENV_CONFIGS["antibiosim/AntibioticSelection-v0"])

    # Seed everything
    SEED = args.seed
    random.seed(SEED)
    np.random.seed(SEED)
    print(f"Training with seed={SEED}")

    import antibiosim  # noqa: F401 - triggers env registration

    env = gym.make(args.env)
    eval_env = gym.make(args.env)

    model = PPO(
        "MlpPolicy",
        env,
        learning_rate=config["learning_rate"],
        n_steps=config["n_steps"],
        batch_size=config["batch_size"],
        gamma=config["gamma"],
        seed=SEED,
        verbose=1,
    )

    os.makedirs(args.output_dir, exist_ok=True)
    eval_callback = EvalCallback(
        eval_env,
        best_model_save_path=os.path.join(args.output_dir, "models"),
        eval_freq=5000,
        n_eval_episodes=10,
        deterministic=True,
    )

    model.learn(total_timesteps=config["total_timesteps"], callback=eval_callback)
    model.save(os.path.join(args.output_dir, "models", f"{args.env.split('/')[-1]}_final"))

    # Evaluate and save results
    rewards = []
    for ep in range(50):
        obs, _ = eval_env.reset(seed=ep)
        total_r = 0.0
        done = False
        while not done:
            action, _ = model.predict(obs, deterministic=True)
            obs, r, term, trunc, _ = eval_env.step(action)
            total_r += r
            done = term or trunc
        rewards.append(total_r)

    result = {
        "env": args.env,
        "mean_reward": float(np.mean(rewards)),
        "std_reward": float(np.std(rewards)),
        "seed": SEED,
        "total_timesteps": config["total_timesteps"],
    }

    result_path = os.path.join(args.output_dir, f"{args.env.split('/')[-1]}_result.json")
    with open(result_path, "w") as f:
        json.dump(result, f, indent=2)

    print(f"Results saved to {result_path}")
    print(f"Mean reward: {result['mean_reward']:.2f} +/- {result['std_reward']:.2f}")


if __name__ == "__main__":
    main()
