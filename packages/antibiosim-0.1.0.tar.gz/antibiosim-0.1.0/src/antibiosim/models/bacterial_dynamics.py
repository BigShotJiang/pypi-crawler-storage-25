"""Bacterial population dynamics and antimicrobial resistance models.

Implements logistic growth with antibiotic killing and resistance emergence,
based on Austin et al. (1999) and Levin & Bonten (2004).
"""

from __future__ import annotations

import numpy as np

# Literature-validated parameter ranges
BACTERIAL_PARAMETER_RANGES = {
    "growth_rate": {
        "min": 0.1, "max": 3.0, "unit": "1/h",
        "source": "Austin et al. 1999; typical doubling time 20min-7h",
    },
    "carrying_capacity": {
        "min": 1e6, "max": 1e11, "unit": "CFU",
        "source": "Levin & Bonten 2004",
    },
    "mutation_rate": {
        "min": 1e-10, "max": 1e-6, "unit": "per cell per generation",
        "source": "Martinez & Baquero 2000",
    },
    "fitness_cost": {
        "min": 0.0, "max": 0.5, "unit": "fraction of growth rate",
        "source": "Andersson & Hughes 2010",
    },
}


class BacterialPopulation:
    """Bacterial population with logistic growth and antibiotic kill dynamics.

    dN/dt = r * N * (1 - N/K) - kill_rate * N

    where:
        r: growth rate (1/h)
        K: carrying capacity (CFU)
        N: bacterial count (CFU)
        kill_rate: from PD model (concentration-dependent)

    Based on Austin et al. (1999) population dynamics framework.

    SIMPLIFICATION: Using well-mixed single-compartment bacterial model.
    Clinical infections have spatial heterogeneity (biofilm, tissue penetration).
    Acceptable for benchmark simulation.
    """

    def __init__(
        self,
        growth_rate: float = 0.8,
        carrying_capacity: float = 1e9,
        min_viable: float = 10.0,
    ) -> None:
        if growth_rate <= 0:
            raise ValueError(f"growth_rate must be positive, got {growth_rate}")
        if carrying_capacity <= 0:
            raise ValueError(f"carrying_capacity must be positive, got {carrying_capacity}")

        self.growth_rate = growth_rate
        self.carrying_capacity = carrying_capacity
        self.min_viable = min_viable

    def step(
        self,
        population: float,
        kill_rate: float,
        dt: float,
        n_substeps: int = 10,
    ) -> float:
        """Advance bacterial population by dt hours.

        Args:
            population: Current bacterial count (CFU).
            kill_rate: Drug-induced kill rate from PD model (1/h).
            dt: Time step in hours.
            n_substeps: Euler sub-steps for numerical stability.

        Returns:
            New bacterial population count.
        """
        sub_dt = dt / n_substeps
        n = population

        for _ in range(n_substeps):
            growth = self.growth_rate * n * (1.0 - n / self.carrying_capacity)
            kill = kill_rate * n
            dn = growth - kill
            n = max(n + dn * sub_dt, 0.0)

        if n < self.min_viable:
            return 0.0
        return n

    def doubling_time(self) -> float:
        """Calculate doubling time in hours (at low density, no drug)."""
        return np.log(2) / self.growth_rate

    def net_growth_rate(self, kill_rate: float) -> float:
        """Calculate net growth rate at low density: r - kill_rate."""
        return self.growth_rate - kill_rate


class ResistanceDynamics:
    """Two-population model with susceptible and resistant bacteria.

    dNs/dt = rs * Ns * (1 - (Ns + Nr)/K) - kill_s * Ns - mu * Ns
    dNr/dt = rr * Nr * (1 - (Ns + Nr)/K) - kill_r * Nr + mu * Ns

    where:
        Ns, Nr: susceptible and resistant populations
        rs, rr: growth rates (rr = rs * (1 - fitness_cost))
        kill_s, kill_r: kill rates (kill_r << kill_s for resistant strain)
        mu: mutation rate from susceptible to resistant
        K: shared carrying capacity

    Based on Levin & Bonten (2004) resistance dynamics framework.

    SIMPLIFICATION: Single-step resistance only. Clinical AMR involves
    multi-step resistance acquisition, horizontal gene transfer, and
    heteroresistance. Acceptable for benchmark simulation.
    """

    def __init__(
        self,
        growth_rate_susceptible: float = 0.8,
        carrying_capacity: float = 1e9,
        mutation_rate: float = 1e-8,
        fitness_cost: float = 0.1,
        resistance_factor: float = 0.1,
        min_viable: float = 10.0,
    ) -> None:
        if mutation_rate < 0:
            raise ValueError(f"mutation_rate must be non-negative, got {mutation_rate}")
        if not 0 <= fitness_cost < 1:
            raise ValueError(f"fitness_cost must be in [0, 1), got {fitness_cost}")
        if not 0 <= resistance_factor <= 1:
            raise ValueError(f"resistance_factor must be in [0, 1], got {resistance_factor}")

        self.rs = growth_rate_susceptible
        self.rr = growth_rate_susceptible * (1.0 - fitness_cost)
        self.k = carrying_capacity
        self.mu = mutation_rate
        self.resistance_factor = resistance_factor
        self.min_viable = min_viable

    def step(
        self,
        n_susceptible: float,
        n_resistant: float,
        kill_rate_susceptible: float,
        dt: float,
        n_substeps: int = 10,
    ) -> tuple[float, float]:
        """Advance both populations by dt hours.

        Args:
            n_susceptible: Susceptible population count.
            n_resistant: Resistant population count.
            kill_rate_susceptible: Kill rate for susceptible bacteria from PD model.
            dt: Time step in hours.
            n_substeps: Euler sub-steps for stability.

        Returns:
            (new_n_susceptible, new_n_resistant)
        """
        sub_dt = dt / n_substeps
        ns, nr = n_susceptible, n_resistant
        kill_r = kill_rate_susceptible * self.resistance_factor

        for _ in range(n_substeps):
            total = ns + nr
            growth_s = self.rs * ns * (1.0 - total / self.k)
            growth_r = self.rr * nr * (1.0 - total / self.k)
            mutation = self.mu * ns

            dns = growth_s - kill_rate_susceptible * ns - mutation
            dnr = growth_r - kill_r * nr + mutation

            ns = max(ns + dns * sub_dt, 0.0)
            nr = max(nr + dnr * sub_dt, 0.0)

        if ns < self.min_viable:
            ns = 0.0
        if nr < self.min_viable:
            nr = 0.0

        return ns, nr

    def resistance_fraction(self, n_susceptible: float, n_resistant: float) -> float:
        """Calculate fraction of resistant bacteria in total population."""
        total = n_susceptible + n_resistant
        if total <= 0:
            return 0.0
        return n_resistant / total

    def selection_coefficient(self, kill_rate_susceptible: float) -> float:
        """Calculate selection coefficient for resistant strain under drug pressure.

        Positive values indicate selection favoring resistance.
        """
        kill_r = kill_rate_susceptible * self.resistance_factor
        net_s = self.rs - kill_rate_susceptible
        net_r = self.rr - kill_r
        return net_r - net_s
