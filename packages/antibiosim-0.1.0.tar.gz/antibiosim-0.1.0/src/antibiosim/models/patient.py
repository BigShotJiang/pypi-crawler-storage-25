"""Patient variability generator for antimicrobial stewardship simulation.

Generates physiologically plausible patient profiles with inter-individual
variability in PK parameters, renal function, and infection characteristics.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class PatientProfile:
    """A simulated patient profile for antibiotic dosing scenarios."""

    weight: float  # kg
    creatinine_clearance: float  # mL/min (renal function)
    age: float  # years
    infection_site: str  # e.g., "blood", "lung", "urinary", "skin"
    pathogen_mic: float  # MIC of the infecting pathogen (mg/L)
    is_immunocompromised: bool
    albumin: float  # g/dL (affects protein binding)

    @property
    def renal_category(self) -> str:
        """Categorize renal function per KDIGO guidelines."""
        if self.creatinine_clearance >= 90:
            return "normal"
        elif self.creatinine_clearance >= 60:
            return "mild_impairment"
        elif self.creatinine_clearance >= 30:
            return "moderate_impairment"
        else:
            return "severe_impairment"

    def adjust_clearance(self, base_clearance: float) -> float:
        """Adjust PK clearance based on renal function.

        Uses linear scaling relative to normal CrCl of 120 mL/min,
        following standard dose-adjustment guidelines (Drusano, 2004).
        """
        return base_clearance * (self.creatinine_clearance / 120.0)

    def adjust_volume(self, base_volume: float) -> float:
        """Adjust volume of distribution based on body weight.

        Scales linearly with weight relative to 70 kg reference.
        """
        return base_volume * (self.weight / 70.0)


class PatientGenerator:
    """Generate random patient profiles with clinically plausible variability.

    Uses published population distributions for adult hospitalized patients.
    """

    # Population distribution parameters (mean, std)
    WEIGHT_PARAMS = (75.0, 15.0)  # kg
    AGE_PARAMS = (55.0, 18.0)  # years
    CRCL_PARAMS = (90.0, 30.0)  # mL/min
    ALBUMIN_PARAMS = (3.5, 0.7)  # g/dL

    INFECTION_SITES = ["blood", "lung", "urinary", "skin", "abdominal"]
    INFECTION_SITE_WEIGHTS = [0.20, 0.30, 0.25, 0.15, 0.10]

    # MIC distribution (log-normal, representing typical Enterobacteriaceae)
    MIC_LOG_MEAN = 0.0  # log2(1.0) = 0
    MIC_LOG_STD = 1.5  # covers range ~0.125 to ~8 mg/L

    def __init__(self, rng: np.random.Generator | None = None) -> None:
        self.rng = rng or np.random.default_rng()

    def generate(self) -> PatientProfile:
        """Generate a single random patient profile."""
        weight = float(np.clip(self.rng.normal(*self.WEIGHT_PARAMS), 40.0, 150.0))
        age = float(np.clip(self.rng.normal(*self.AGE_PARAMS), 18.0, 95.0))
        crcl = float(np.clip(self.rng.normal(*self.CRCL_PARAMS), 10.0, 160.0))
        albumin = float(np.clip(self.rng.normal(*self.ALBUMIN_PARAMS), 1.5, 5.0))

        site = self.rng.choice(self.INFECTION_SITES, p=self.INFECTION_SITE_WEIGHTS)

        mic_log2 = self.rng.normal(self.MIC_LOG_MEAN, self.MIC_LOG_STD)
        mic = float(np.clip(2.0 ** mic_log2, 0.03, 256.0))

        immunocompromised = bool(self.rng.random() < 0.15)

        return PatientProfile(
            weight=weight,
            creatinine_clearance=crcl,
            age=age,
            infection_site=str(site),
            pathogen_mic=mic,
            is_immunocompromised=immunocompromised,
            albumin=albumin,
        )

    def generate_batch(self, n: int) -> list[PatientProfile]:
        """Generate a batch of n patient profiles."""
        return [self.generate() for _ in range(n)]
