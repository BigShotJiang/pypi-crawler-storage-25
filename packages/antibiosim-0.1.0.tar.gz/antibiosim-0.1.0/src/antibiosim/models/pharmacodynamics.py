"""Pharmacodynamic models for antibiotic kill-rate relationships.

Implements Emax and sigmoidal Emax models relating drug concentration to
bacterial kill rate (Regoes et al., 2004; Mueller et al., 2004).

PK/PD indices:
- Cmax/MIC: peak concentration relative to minimum inhibitory concentration
- AUC/MIC: 24h area-under-curve relative to MIC
- T>MIC: fraction of dosing interval above MIC
"""

from __future__ import annotations

import numpy as np

# Literature-validated parameter ranges
PD_PARAMETER_RANGES = {
    "emax": {"min": 0.5, "max": 15.0, "unit": "1/h", "source": "Regoes et al. 2004"},
    "ec50": {"min": 0.1, "max": 64.0, "unit": "mg/L", "source": "Mueller et al. 2004"},
    "hill_coefficient": {"min": 0.5, "max": 5.0, "unit": "dimensionless", "source": "Regoes et al. 2004"},
    "mic": {"min": 0.03, "max": 256.0, "unit": "mg/L", "source": "EUCAST breakpoint tables"},
}


class EmaxModel:
    """Standard Emax pharmacodynamic model.

    kill_rate = Emax * C / (EC50 + C)

    where:
        Emax: maximum kill rate (1/h)
        EC50: concentration at half-maximal effect (mg/L)
        C: drug concentration (mg/L)

    Based on the standard PD model from Mueller et al. (2004).
    """

    def __init__(self, emax: float = 3.0, ec50: float = 2.0) -> None:
        if emax <= 0:
            raise ValueError(f"emax must be positive, got {emax}")
        if ec50 <= 0:
            raise ValueError(f"ec50 must be positive, got {ec50}")
        self.emax = emax
        self.ec50 = ec50

    def kill_rate(self, concentration: float) -> float:
        """Calculate bacterial kill rate at given drug concentration.

        Returns kill rate in 1/h (always non-negative).
        """
        if concentration <= 0:
            return 0.0
        return self.emax * concentration / (self.ec50 + concentration)

    def fractional_kill(self, concentration: float) -> float:
        """Calculate fractional effect (0 to 1) at given concentration."""
        if concentration <= 0:
            return 0.0
        return concentration / (self.ec50 + concentration)


class SigmoidalEmaxModel:
    """Sigmoidal Emax (Hill equation) pharmacodynamic model.

    kill_rate = Emax * C^n / (EC50^n + C^n)

    where n is the Hill coefficient controlling the steepness of the
    concentration-response curve. This is the standard model used in
    antimicrobial PK/PD research (Regoes et al., 2004).

    SIMPLIFICATION: Using static EC50 instead of adaptive EC50 that shifts
    with bacterial density. Clinical PD models sometimes account for inoculum
    effect. Acceptable for benchmark simulation.
    """

    def __init__(
        self,
        emax: float = 3.0,
        ec50: float = 2.0,
        hill: float = 1.5,
    ) -> None:
        if emax <= 0:
            raise ValueError(f"emax must be positive, got {emax}")
        if ec50 <= 0:
            raise ValueError(f"ec50 must be positive, got {ec50}")
        if hill <= 0:
            raise ValueError(f"hill coefficient must be positive, got {hill}")
        self.emax = emax
        self.ec50 = ec50
        self.hill = hill

    def kill_rate(self, concentration: float) -> float:
        """Calculate bacterial kill rate using sigmoidal Emax model.

        Returns kill rate in 1/h (always non-negative).
        """
        if concentration <= 0:
            return 0.0
        c_n = concentration ** self.hill
        ec50_n = self.ec50 ** self.hill
        return self.emax * c_n / (ec50_n + c_n)

    def fractional_kill(self, concentration: float) -> float:
        """Calculate fractional effect (0 to 1) at given concentration."""
        if concentration <= 0:
            return 0.0
        c_n = concentration ** self.hill
        ec50_n = self.ec50 ** self.hill
        return c_n / (ec50_n + c_n)

    def mic_from_ec50(self, growth_rate: float) -> float:
        """Estimate MIC from EC50 and natural bacterial growth rate.

        MIC is the concentration where kill rate = growth rate.
        From Regoes et al. (2004): MIC = EC50 * (growth / (Emax - growth))^(1/hill)
        """
        if growth_rate >= self.emax:
            return float("inf")
        ratio = growth_rate / (self.emax - growth_rate)
        return self.ec50 * (ratio ** (1.0 / self.hill))


def compute_time_above_mic(
    concentrations: list[float] | np.ndarray,
    mic: float,
    dt: float,
) -> float:
    """Compute fraction of time that concentration exceeds MIC.

    Args:
        concentrations: Sequence of drug concentrations over time.
        mic: Minimum inhibitory concentration.
        dt: Time step between concentration measurements.

    Returns:
        Fraction of total time that C > MIC (0 to 1).
    """
    conc = np.asarray(concentrations)
    total_time = len(conc) * dt
    if total_time <= 0:
        return 0.0
    time_above = float(np.sum(conc > mic)) * dt
    return time_above / total_time


def compute_auc(concentrations: list[float] | np.ndarray, dt: float) -> float:
    """Compute area under the concentration-time curve using trapezoidal rule."""
    conc = np.asarray(concentrations)
    if len(conc) < 2:
        return 0.0
    _trap = getattr(np, "trapezoid", None) or np.trapz
    return float(_trap(conc, dx=dt))


def compute_pkpd_indices(
    concentrations: list[float] | np.ndarray,
    mic: float,
    dt: float,
    _interval: float = 24.0,
) -> dict[str, float]:
    """Compute the three standard PK/PD indices.

    Args:
        concentrations: Drug concentration time series.
        mic: Minimum inhibitory concentration (mg/L).
        dt: Time between concentration samples (hours).
        _interval: Dosing interval (reserved for future use).

    Returns:
        Dictionary with cmax_mic_ratio, auc24_mic_ratio, time_above_mic.
    """
    conc = np.asarray(concentrations)
    cmax = float(np.max(conc)) if len(conc) > 0 else 0.0
    auc = compute_auc(conc, dt)
    # Scale AUC to 24-hour equivalent
    total_hours = len(conc) * dt
    auc24 = auc * (24.0 / total_hours) if total_hours > 0 else 0.0
    t_above = compute_time_above_mic(conc, mic, dt)

    return {
        "cmax_mic_ratio": cmax / mic if mic > 0 else 0.0,
        "auc24_mic_ratio": auc24 / mic if mic > 0 else 0.0,
        "time_above_mic": t_above,
    }
