"""DoseOptimization-v0: Optimize antibiotic dosing schedule for PK/PD target attainment.

The agent adjusts the dose of a selected antibiotic over a treatment course to
maximize PK/PD target attainment while minimizing toxicity.

Uses one-compartment PK with sigmoidal Emax PD model (Drusano, 2004; Mouton et al., 2005).
"""

from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from antibiosim.models.bacterial_dynamics import BacterialPopulation
from antibiosim.models.patient import PatientGenerator, PatientProfile
from antibiosim.models.pharmacodynamics import SigmoidalEmaxModel, compute_pkpd_indices
from antibiosim.models.pharmacokinetics import OneCompartmentPK


class DoseOptimizationEnv(gym.Env):
    """Gymnasium environment for antibiotic dose optimization.

    Observation Space: Box(8)
        [drug_concentration, bacterial_load, mic, creatinine_clearance,
         time_in_treatment, cumulative_auc, trough_concentration, peak_concentration]

    Action Space: Box(1) in [0, 1]
        Fraction of maximum dose (0 = no dose, 1 = max dose).
        Mapped to [0, max_dose_mg] internally.

    Reward:
        +pkpd_target_attainment - subtherapeutic_penalty - toxicity_penalty
        - resistance_emergence_penalty

    Episode: 10 days (240 hours), with dosing decisions every 8 hours.
        Terminates early on pathogen clearance or severe toxicity.
    """

    metadata = {"render_modes": []}

    MAX_HOURS: float = 240.0
    STEP_HOURS: float = 8.0
    MAX_DOSE: float = 2000.0
    CLEARANCE_THRESHOLD: float = 100.0
    TOXIC_CONCENTRATION: float = 40.0

    # Reward weights
    TARGET_ATTAINMENT_BONUS: float = 5.0
    SUBTHERAPEUTIC_PENALTY: float = 2.0
    TOXICITY_PENALTY: float = 10.0
    CLEARANCE_BONUS: float = 30.0
    RESISTANCE_PENALTY: float = 15.0

    def __init__(self, render_mode: str | None = None) -> None:
        super().__init__()

        self.observation_space = spaces.Box(
            low=np.array([0, 0, 0.03, 10, 0, 0, 0, 0], dtype=np.float32),
            high=np.array([200, 1e10, 256, 160, 240, 1e5, 200, 200], dtype=np.float32),
            dtype=np.float32,
        )

        self.action_space = spaces.Box(
            low=np.array([0.0], dtype=np.float32),
            high=np.array([1.0], dtype=np.float32),
            dtype=np.float32,
        )

        self.patient_gen = PatientGenerator()
        self.patient: PatientProfile | None = None
        self.pk_model: OneCompartmentPK | None = None
        self.pd_model: SigmoidalEmaxModel | None = None
        self.bacteria: BacterialPopulation | None = None

        self.drug_conc: float = 0.0
        self.bacterial_load: float = 0.0
        self.time: float = 0.0
        self.concentration_history: list[float] = []
        self.peak_conc: float = 0.0
        self.trough_conc: float = 0.0

    def reset(
        self, *, seed: int | None = None, options: dict[str, Any] | None = None
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed)

        rng = np.random.default_rng(seed)
        self.patient_gen = PatientGenerator(rng=rng)
        self.patient = self.patient_gen.generate()

        self.pk_model = OneCompartmentPK(
            clearance=self.patient.adjust_clearance(5.0),
            volume=self.patient.adjust_volume(20.0),
        )
        self.pd_model = SigmoidalEmaxModel(
            emax=3.5, ec50=self.patient.pathogen_mic * 1.2, hill=1.5
        )
        self.bacteria = BacterialPopulation(growth_rate=0.8)

        self.drug_conc = 0.0
        self.bacterial_load = float(10 ** rng.uniform(6, 8))
        self.time = 0.0
        self.concentration_history = []
        self.peak_conc = 0.0
        self.trough_conc = 0.0

        return self._get_obs(), self._get_info()

    def step(
        self, action: np.ndarray
    ) -> tuple[np.ndarray, float, bool, bool, dict[str, Any]]:
        assert self.pk_model is not None
        assert self.pd_model is not None
        assert self.bacteria is not None
        assert self.patient is not None

        dose_fraction = float(np.clip(action[0], 0.0, 1.0))
        dose_mg = dose_fraction * self.MAX_DOSE

        # PK: administer dose and simulate over step interval
        # Simulate in 1-hour sub-steps for concentration tracking
        n_substeps = int(self.STEP_HOURS)
        sub_dt = self.STEP_HOURS / n_substeps
        conc = self.drug_conc

        # Administer dose at start of interval (IV bolus)
        conc = self.pk_model.iv_bolus(conc, dose_mg, 0.01)
        self.peak_conc = max(self.peak_conc, conc)

        for _ in range(n_substeps):
            self.concentration_history.append(conc)
            kill_rate = self.pd_model.kill_rate(conc)
            self.bacterial_load = self.bacteria.step(
                self.bacterial_load, kill_rate, sub_dt
            )
            conc = self.pk_model.iv_bolus(conc, 0.0, sub_dt)

        self.drug_conc = conc
        self.trough_conc = conc
        self.time += self.STEP_HOURS

        # Compute PK/PD indices
        pkpd = compute_pkpd_indices(
            self.concentration_history[-n_substeps:],
            self.patient.pathogen_mic,
            dt=sub_dt,
        )

        # Reward computation
        reward = 0.0
        terminated = False
        truncated = False

        # PK/PD target attainment reward
        if pkpd["auc24_mic_ratio"] >= 100:
            reward += self.TARGET_ATTAINMENT_BONUS
        elif pkpd["auc24_mic_ratio"] < 50:
            reward -= self.SUBTHERAPEUTIC_PENALTY

        # Toxicity penalty (concentration too high)
        if self.peak_conc > self.TOXIC_CONCENTRATION:
            excess = (self.peak_conc - self.TOXIC_CONCENTRATION) / self.TOXIC_CONCENTRATION
            reward -= self.TOXICITY_PENALTY * excess

        # Pathogen clearance
        if self.bacterial_load <= self.CLEARANCE_THRESHOLD:
            reward += self.CLEARANCE_BONUS
            terminated = True

        # Bacterial load reduction reward shaping
        if self.bacterial_load > self.CLEARANCE_THRESHOLD:
            log_reduction = np.log10(max(self.bacterial_load, 1.0))
            reward -= log_reduction * 0.5

        # Time limit
        if self.time >= self.MAX_HOURS:
            truncated = True
            if self.bacterial_load > self.CLEARANCE_THRESHOLD:
                reward -= 10.0

        return self._get_obs(), float(reward), terminated, truncated, self._get_info()

    def _get_obs(self) -> np.ndarray:
        assert self.patient is not None
        cumulative_auc = sum(self.concentration_history) * 1.0 if self.concentration_history else 0.0
        return np.array([
            self.drug_conc,
            self.bacterial_load,
            self.patient.pathogen_mic,
            self.patient.creatinine_clearance,
            self.time,
            cumulative_auc,
            self.trough_conc,
            self.peak_conc,
        ], dtype=np.float32)

    def _get_info(self) -> dict[str, Any]:
        return {
            "bacterial_load": self.bacterial_load,
            "drug_concentration": self.drug_conc,
            "time": self.time,
            "peak_concentration": self.peak_conc,
            "trough_concentration": self.trough_conc,
        }
