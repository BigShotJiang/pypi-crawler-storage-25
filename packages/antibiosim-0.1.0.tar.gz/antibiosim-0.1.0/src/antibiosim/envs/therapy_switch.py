"""TherapySwitch-v0: IV-to-oral switch and therapy escalation/de-escalation.

The agent manages antibiotic therapy transitions: deciding when to switch
from IV to oral therapy, when to escalate to broader-spectrum agents, and
when to de-escalate to narrower-spectrum agents.

Based on antimicrobial stewardship transition-of-care guidelines (Barlam et al., 2016).
"""

from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from antibiosim.models.bacterial_dynamics import BacterialPopulation
from antibiosim.models.pharmacodynamics import SigmoidalEmaxModel
from antibiosim.models.pharmacokinetics import OneCompartmentPK


# Therapy levels: narrow IV -> narrow oral -> broad IV -> broad oral
THERAPY_LEVELS = {
    0: {"name": "narrow_iv", "spectrum": 1, "route": "iv",
        "clearance": 8.0, "volume": 18.0, "emax": 3.0, "ec50_factor": 1.0,
        "toxicity": 0.03, "cost": 10.0, "bioavailability": 1.0},
    1: {"name": "narrow_oral", "spectrum": 1, "route": "oral",
        "clearance": 8.0, "volume": 18.0, "emax": 3.0, "ec50_factor": 1.2,
        "toxicity": 0.01, "cost": 3.0, "bioavailability": 0.75},
    2: {"name": "broad_iv", "spectrum": 3, "route": "iv",
        "clearance": 6.0, "volume": 22.0, "emax": 5.0, "ec50_factor": 0.6,
        "toxicity": 0.06, "cost": 25.0, "bioavailability": 1.0},
    3: {"name": "broad_oral", "spectrum": 3, "route": "oral",
        "clearance": 6.0, "volume": 22.0, "emax": 5.0, "ec50_factor": 0.8,
        "toxicity": 0.03, "cost": 8.0, "bioavailability": 0.65},
}


class TherapySwitchEnv(gym.Env):
    """Gymnasium environment for antibiotic therapy switching decisions.

    Observation Space: Box(10)
        [bacterial_load, drug_concentration, days_on_current_therapy,
         current_therapy_level, temperature, wbc_count, crp_level,
         oral_tolerance, creatinine_clearance, resistance_signal]

    Action Space: Discrete(4)
        0: continue current therapy
        1: switch to oral (same spectrum)
        2: escalate (broader spectrum)
        3: de-escalate (narrower spectrum)

    Reward:
        +successful_transition - unnecessary_broad_spectrum - treatment_failure
        - adverse_events - hospital_stay_cost

    Episode: 21 days.
        Terminates early on cure (bacterial clearance + clinical improvement)
        or treatment failure.
    """

    metadata = {"render_modes": []}

    MAX_DAYS: float = 21.0
    STEP_HOURS: float = 24.0
    CLEARANCE_THRESHOLD: float = 100.0
    DETERIORATION_THRESHOLD: float = 5e9

    # Clinical thresholds
    FEVER_THRESHOLD: float = 38.0  # Celsius
    WBC_NORMAL_LOW: float = 4.0
    WBC_NORMAL_HIGH: float = 11.0

    # Reward weights
    CURE_BONUS: float = 40.0
    STEP_DOWN_BONUS: float = 5.0
    BROAD_SPECTRUM_PENALTY: float = 1.5
    IV_PENALTY: float = 0.5
    FAILURE_PENALTY: float = -25.0
    ADVERSE_EVENT_PENALTY: float = 8.0

    def __init__(self, render_mode: str | None = None) -> None:
        super().__init__()

        self.observation_space = spaces.Box(
            low=np.array([0, 0, 0, 0, 35, 0, 0, 0, 10, 0], dtype=np.float32),
            high=np.array([1e10, 200, 21, 3, 42, 30, 500, 1, 160, 1], dtype=np.float32),
            dtype=np.float32,
        )

        self.action_space = spaces.Discrete(4)

        # State variables
        self.bacterial_load: float = 0.0
        self.drug_conc: float = 0.0
        self.day: float = 0.0
        self.days_on_current: float = 0.0
        self.current_therapy: int = 0
        self.temperature: float = 37.0
        self.wbc: float = 8.0
        self.crp: float = 50.0
        self.oral_tolerance: float = 0.0
        self.crcl: float = 90.0
        self.resistance_signal: float = 0.0
        self.mic: float = 1.0

    def reset(
        self, *, seed: int | None = None, options: dict[str, Any] | None = None
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed)

        rng = np.random.default_rng(seed)

        self.bacterial_load = float(10 ** rng.uniform(7, 9))
        self.drug_conc = 0.0
        self.day = 0.0
        self.days_on_current = 0.0
        self.current_therapy = 2  # Start on broad IV (typical empiric therapy)
        self.temperature = float(rng.uniform(38.5, 40.0))  # Febrile on admission
        self.wbc = float(rng.uniform(12.0, 20.0))  # Elevated WBC
        self.crp = float(rng.uniform(100.0, 300.0))  # Elevated CRP
        self.oral_tolerance = float(rng.uniform(0.0, 0.5))  # Initially poor
        self.crcl = float(rng.uniform(50.0, 130.0))
        self.resistance_signal = 0.0
        self.mic = float(2 ** rng.uniform(-1, 3))

        return self._get_obs(), self._get_info()

    def step(self, action: int | np.ndarray) -> tuple[np.ndarray, float, bool, bool, dict[str, Any]]:
        action = int(np.asarray(action).item()) if isinstance(action, np.ndarray) else int(action)
        reward = 0.0

        # Process action
        if action == 0:
            pass  # Continue current
        elif action == 1:  # Switch to oral
            new_therapy = self.current_therapy | 1  # Set oral bit
            if new_therapy != self.current_therapy:
                self.current_therapy = min(new_therapy, 3)
                self.days_on_current = 0.0
                if self.oral_tolerance > 0.5:
                    reward += self.STEP_DOWN_BONUS
        elif action == 2:  # Escalate
            if self.current_therapy < 2:
                self.current_therapy = 2 + (self.current_therapy & 1)
                self.days_on_current = 0.0
        elif action == 3:  # De-escalate
            if self.current_therapy >= 2:
                self.current_therapy = 0 + (self.current_therapy & 1)
                self.days_on_current = 0.0
                reward += self.STEP_DOWN_BONUS

        therapy = THERAPY_LEVELS[self.current_therapy]

        # PK simulation
        dose = 500.0  # Standard dose for all
        adjusted_cl = therapy["clearance"] * (self.crcl / 120.0)
        pk = OneCompartmentPK(clearance=adjusted_cl, volume=therapy["volume"])
        if therapy["route"] == "iv":
            self.drug_conc = pk.iv_bolus(self.drug_conc * 0.3, dose, self.STEP_HOURS)
        else:
            self.drug_conc = pk.iv_bolus(
                self.drug_conc * 0.3,
                dose * therapy["bioavailability"],
                self.STEP_HOURS,
            )

        # PD simulation
        ec50 = therapy["ec50_factor"] * self.mic
        pd = SigmoidalEmaxModel(emax=therapy["emax"], ec50=ec50, hill=1.5)
        kill_rate = pd.kill_rate(self.drug_conc)

        # Bacterial dynamics
        bacteria = BacterialPopulation(growth_rate=0.7)
        self.bacterial_load = bacteria.step(self.bacterial_load, kill_rate, self.STEP_HOURS)

        # Clinical marker evolution (correlated with bacterial load)
        log_load = np.log10(max(self.bacterial_load, 1.0))
        self.temperature += self.np_random.normal(0, 0.3)
        self.temperature = float(np.clip(
            36.5 + (log_load - 2) * 0.3 + self.np_random.normal(0, 0.2),
            35.5, 41.0
        ))
        self.wbc = float(np.clip(
            4.0 + (log_load - 2) * 1.5 + self.np_random.normal(0, 1.0),
            1.0, 30.0
        ))
        self.crp = float(np.clip(
            self.crp * 0.85 + log_load * 5 + self.np_random.normal(0, 10),
            0.5, 500.0
        ))

        # Oral tolerance improves over time if improving
        if self.temperature < self.FEVER_THRESHOLD:
            self.oral_tolerance = min(1.0, self.oral_tolerance + 0.15)

        # Resistance signal
        if therapy["spectrum"] >= 3:
            self.resistance_signal = min(1.0, self.resistance_signal + 0.02)

        self.day += 1.0
        self.days_on_current += 1.0

        # Toxicity
        if self.np_random.random() < therapy["toxicity"]:
            reward -= self.ADVERSE_EVENT_PENALTY

        # Broad spectrum penalty (stewardship)
        if therapy["spectrum"] >= 3:
            reward -= self.BROAD_SPECTRUM_PENALTY
        if therapy["route"] == "iv":
            reward -= self.IV_PENALTY

        # Termination conditions
        terminated = False
        truncated = False

        clinical_improvement = (
            self.temperature < self.FEVER_THRESHOLD
            and self.WBC_NORMAL_LOW <= self.wbc <= self.WBC_NORMAL_HIGH
        )

        if self.bacterial_load <= self.CLEARANCE_THRESHOLD and clinical_improvement:
            reward += self.CURE_BONUS
            terminated = True
        elif self.bacterial_load >= self.DETERIORATION_THRESHOLD:
            reward += self.FAILURE_PENALTY
            terminated = True

        if self.day >= self.MAX_DAYS:
            truncated = True

        return self._get_obs(), float(reward), terminated, truncated, self._get_info()

    def _get_obs(self) -> np.ndarray:
        return np.array([
            self.bacterial_load,
            self.drug_conc,
            self.days_on_current,
            float(self.current_therapy),
            self.temperature,
            self.wbc,
            self.crp,
            self.oral_tolerance,
            self.crcl,
            self.resistance_signal,
        ], dtype=np.float32)

    def _get_info(self) -> dict[str, Any]:
        return {
            "bacterial_load": self.bacterial_load,
            "drug_concentration": self.drug_conc,
            "day": self.day,
            "current_therapy": THERAPY_LEVELS[self.current_therapy]["name"],
            "temperature": self.temperature,
            "clinical_improving": self.temperature < self.FEVER_THRESHOLD,
        }
