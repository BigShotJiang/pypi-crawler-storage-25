"""ResistanceControl-v0: Ward-level antibiotic policy to minimize resistance emergence.

The agent manages antibiotic prescribing for multiple patients simultaneously on a
hospital ward, balancing individual treatment outcomes with population-level
resistance containment.

Based on Austin et al. (1999) and Lipsitch et al. (2000) resistance dynamics models.

SIMPLIFICATION: Using a simplified ward model with 5 beds and independent patients.
Real hospital wards have cross-transmission, patient turnover, and environmental
reservoirs. Acceptable for benchmark simulation.
"""

from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from antibiosim.models.bacterial_dynamics import ResistanceDynamics
from antibiosim.models.pharmacodynamics import SigmoidalEmaxModel
from antibiosim.models.pharmacokinetics import OneCompartmentPK


N_BEDS = 5
N_ANTIBIOTICS = 3  # narrow, moderate, broad spectrum


class ResistanceControlEnv(gym.Env):
    """Gymnasium environment for ward-level antibiotic resistance control.

    Observation Space: Box(N_BEDS * 5 + 1)
        Per patient (x5): [bacterial_load_susceptible, bacterial_load_resistant,
                           drug_concentration, days_in_treatment, severity]
        Ward-level: [mean_resistance_prevalence]

    Action Space: MultiDiscrete([N_ANTIBIOTICS] * N_BEDS)
        For each of 5 beds, choose: 0=narrow, 1=moderate, 2=broad spectrum

    Reward:
        +treatment_success_per_patient - resistance_prevalence_penalty
        - broad_spectrum_usage_penalty - treatment_failure_penalty

    Episode: 90 days (ward-level simulation).
        No early termination. Patients cycle through the ward.
    """

    metadata = {"render_modes": []}

    MAX_DAYS: float = 90.0
    STEP_HOURS: float = 24.0
    CLEARANCE_THRESHOLD: float = 100.0
    DETERIORATION_THRESHOLD: float = 5e9
    PATIENT_TURNOVER_PROB: float = 0.1

    # Antibiotic properties per spectrum level
    ANTIBIOTIC_SPECS = [
        {"name": "narrow", "emax": 2.5, "ec50_factor": 1.5, "hill": 1.2,
         "clearance": 8.0, "volume": 20.0, "resistance_pressure": 0.01, "cost": 3.0},
        {"name": "moderate", "emax": 3.5, "ec50_factor": 1.0, "hill": 1.5,
         "clearance": 6.0, "volume": 22.0, "resistance_pressure": 0.03, "cost": 10.0},
        {"name": "broad", "emax": 5.0, "ec50_factor": 0.5, "hill": 2.0,
         "clearance": 5.0, "volume": 25.0, "resistance_pressure": 0.06, "cost": 25.0},
    ]

    # Reward weights
    CURE_BONUS: float = 10.0
    FAILURE_PENALTY: float = -8.0
    RESISTANCE_SCALE: float = 50.0
    BROAD_PENALTY: float = 1.0

    def __init__(self, render_mode: str | None = None) -> None:
        super().__init__()

        obs_dim = N_BEDS * 5 + 1
        self.observation_space = spaces.Box(
            low=np.zeros(obs_dim, dtype=np.float32),
            high=np.full(obs_dim, 1e10, dtype=np.float32),
            dtype=np.float32,
        )

        self.action_space = spaces.MultiDiscrete([N_ANTIBIOTICS] * N_BEDS)

        # Per-bed state
        self.n_susceptible = np.zeros(N_BEDS)
        self.n_resistant = np.zeros(N_BEDS)
        self.drug_conc = np.zeros(N_BEDS)
        self.days_in_treatment = np.zeros(N_BEDS)
        self.severity = np.zeros(N_BEDS)
        self.mic = np.zeros(N_BEDS)

        self.day: float = 0.0
        self.ward_resistance_history: list[float] = []

    def _init_patient(self, bed: int, rng: np.random.Generator) -> None:
        """Initialize a new patient in a bed."""
        self.n_susceptible[bed] = float(10 ** rng.uniform(6, 8))
        self.n_resistant[bed] = float(10 ** rng.uniform(1, 3))
        self.drug_conc[bed] = 0.0
        self.days_in_treatment[bed] = 0.0
        self.severity[bed] = float(rng.uniform(3.0, 8.0))
        self.mic[bed] = float(2 ** rng.uniform(-1, 3))

    def reset(
        self, *, seed: int | None = None, options: dict[str, Any] | None = None
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed)

        rng = np.random.default_rng(seed)
        for bed in range(N_BEDS):
            self._init_patient(bed, rng)

        self.day = 0.0
        self.ward_resistance_history = []

        return self._get_obs(), self._get_info()

    def step(
        self, action: np.ndarray
    ) -> tuple[np.ndarray, float, bool, bool, dict[str, Any]]:
        reward = 0.0
        rng = self.np_random

        for bed in range(N_BEDS):
            abx_idx = int(action[bed])
            abx = self.ANTIBIOTIC_SPECS[abx_idx]

            # PK
            pk = OneCompartmentPK(clearance=abx["clearance"], volume=abx["volume"])
            self.drug_conc[bed] = pk.iv_bolus(
                self.drug_conc[bed] * 0.3, 500.0, self.STEP_HOURS
            )

            # PD for susceptible strain
            ec50 = abx["ec50_factor"] * self.mic[bed]
            pd = SigmoidalEmaxModel(emax=abx["emax"], ec50=ec50, hill=abx["hill"])
            kill_rate = pd.kill_rate(self.drug_conc[bed])

            # Resistance dynamics
            resistance = ResistanceDynamics(
                growth_rate_susceptible=0.7,
                carrying_capacity=1e9,
                mutation_rate=1e-8 * (1 + abx["resistance_pressure"] * 10),
                fitness_cost=0.1,
                resistance_factor=0.15,
            )

            self.n_susceptible[bed], self.n_resistant[bed] = resistance.step(
                self.n_susceptible[bed],
                self.n_resistant[bed],
                kill_rate,
                self.STEP_HOURS,
            )

            self.days_in_treatment[bed] += 1.0
            total_load = self.n_susceptible[bed] + self.n_resistant[bed]

            # Per-patient outcomes
            if total_load <= self.CLEARANCE_THRESHOLD:
                reward += self.CURE_BONUS
                # Patient discharged, new admission
                self._init_patient(bed, rng)
            elif total_load >= self.DETERIORATION_THRESHOLD:
                reward += self.FAILURE_PENALTY
                self._init_patient(bed, rng)
            elif self.days_in_treatment[bed] >= 14:
                # Long stay without resolution
                reward -= 2.0
                self._init_patient(bed, rng)

            # Broad-spectrum penalty (stewardship)
            if abx_idx == 2:
                reward -= self.BROAD_PENALTY

        # Ward-level resistance prevalence
        total_susceptible = float(np.sum(self.n_susceptible))
        total_resistant = float(np.sum(self.n_resistant))
        total_all = total_susceptible + total_resistant
        resistance_prevalence = total_resistant / total_all if total_all > 0 else 0.0
        self.ward_resistance_history.append(resistance_prevalence)

        # Resistance prevalence penalty (the core stewardship objective)
        reward -= resistance_prevalence * self.RESISTANCE_SCALE

        self.day += 1.0
        terminated = False
        truncated = self.day >= self.MAX_DAYS

        return self._get_obs(), float(reward), terminated, truncated, self._get_info()

    def _get_obs(self) -> np.ndarray:
        obs_parts = []
        for bed in range(N_BEDS):
            obs_parts.extend([
                self.n_susceptible[bed],
                self.n_resistant[bed],
                self.drug_conc[bed],
                self.days_in_treatment[bed],
                self.severity[bed],
            ])

        total_s = float(np.sum(self.n_susceptible))
        total_r = float(np.sum(self.n_resistant))
        total_all = total_s + total_r
        resistance_prev = total_r / total_all if total_all > 0 else 0.0
        obs_parts.append(resistance_prev)

        return np.array(obs_parts, dtype=np.float32)

    def _get_info(self) -> dict[str, Any]:
        total_s = float(np.sum(self.n_susceptible))
        total_r = float(np.sum(self.n_resistant))
        total_all = total_s + total_r
        return {
            "day": self.day,
            "ward_resistance_prevalence": total_r / total_all if total_all > 0 else 0.0,
            "total_susceptible": total_s,
            "total_resistant": total_r,
            "resistance_history": self.ward_resistance_history[-10:],
        }
