"""AntibioticSelection-v0: Choose optimal antibiotic for an infection.

The agent receives patient characteristics, pathogen MIC profile, and infection
severity, then selects from a formulary of 5 antibiotics. Each antibiotic has
different PK/PD properties, spectrum, and toxicity profiles.

Based on clinical antimicrobial stewardship decision-making (Barlam et al., 2016).
"""

from __future__ import annotations

from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from antibiosim.models.bacterial_dynamics import BacterialPopulation
from antibiosim.models.patient import PatientGenerator, PatientProfile
from antibiosim.models.pharmacodynamics import SigmoidalEmaxModel
from antibiosim.models.pharmacokinetics import OneCompartmentPK


# Formulary: 5 antibiotics with distinct PK/PD profiles
# Based on representative clinical parameters (Drusano, 2004)
ANTIBIOTIC_FORMULARY = {
    0: {
        "name": "ciprofloxacin",
        "class": "fluoroquinolone",
        "pk_index": "auc_mic",
        "clearance": 6.0, "volume": 25.0, "ka": 2.0, "bioavailability": 0.7,
        "emax": 4.0, "ec50_factor": 1.0, "hill": 2.0,
        "toxicity_rate": 0.05, "cost_per_dose": 5.0,
        "standard_dose": 400.0,
    },
    1: {
        "name": "vancomycin",
        "class": "glycopeptide",
        "pk_index": "auc_mic",
        "clearance": 4.5, "volume": 30.0, "ka": 0.0, "bioavailability": 0.0,
        "emax": 3.0, "ec50_factor": 1.5, "hill": 1.5,
        "toxicity_rate": 0.10, "cost_per_dose": 15.0,
        "standard_dose": 1000.0,
    },
    2: {
        "name": "amoxicillin",
        "class": "penicillin",
        "pk_index": "time_above_mic",
        "clearance": 10.0, "volume": 20.0, "ka": 2.5, "bioavailability": 0.85,
        "emax": 3.5, "ec50_factor": 0.8, "hill": 1.0,
        "toxicity_rate": 0.02, "cost_per_dose": 2.0,
        "standard_dose": 500.0,
    },
    3: {
        "name": "meropenem",
        "class": "carbapenem",
        "pk_index": "time_above_mic",
        "clearance": 8.0, "volume": 18.0, "ka": 0.0, "bioavailability": 0.0,
        "emax": 5.0, "ec50_factor": 0.5, "hill": 1.2,
        "toxicity_rate": 0.04, "cost_per_dose": 25.0,
        "standard_dose": 1000.0,
    },
    4: {
        "name": "gentamicin",
        "class": "aminoglycoside",
        "pk_index": "cmax_mic",
        "clearance": 5.0, "volume": 15.0, "ka": 0.0, "bioavailability": 0.0,
        "emax": 6.0, "ec50_factor": 2.0, "hill": 2.5,
        "toxicity_rate": 0.12, "cost_per_dose": 8.0,
        "standard_dose": 300.0,
    },
}

# Pathogen susceptibility matrix: probability of susceptibility per antibiotic
# Rows: pathogen_id (0-4), Columns: antibiotic_id (0-4)
# Based on representative resistance rates (EUCAST breakpoint tables)
SUSCEPTIBILITY_MATRIX = np.array([
    [0.85, 0.95, 0.70, 0.99, 0.90],  # E. coli
    [0.75, 0.98, 0.50, 0.95, 0.85],  # Klebsiella
    [0.60, 0.05, 0.80, 0.90, 0.70],  # Pseudomonas (intrinsic vanco-R)
    [0.10, 0.95, 0.90, 0.99, 0.80],  # Staph aureus (low cipro for MRSA)
    [0.70, 0.30, 0.60, 0.85, 0.60],  # Enterococcus
], dtype=np.float32)


class AntibioticSelectionEnv(gym.Env):
    """Gymnasium environment for antibiotic selection in antimicrobial stewardship.

    Observation Space: Box(12)
        [pathogen_id_onehot(5), mic, infection_severity, creatinine_clearance,
         weight, is_immunocompromised, day_in_treatment]

    Action Space: Discrete(5)
        0: ciprofloxacin, 1: vancomycin, 2: amoxicillin, 3: meropenem, 4: gentamicin

    Reward:
        +pathogen_clearance_bonus - treatment_failure_penalty - toxicity_penalty
        - cost_penalty - broad_spectrum_penalty (stewardship)

    Episode: 14 days (standard acute infection treatment course).
        Terminates early on pathogen clearance or patient deterioration.
    """

    metadata = {"render_modes": []}

    MAX_DAYS: float = 14.0
    STEP_HOURS: float = 24.0
    CLEARANCE_THRESHOLD: float = 100.0
    DETERIORATION_THRESHOLD: float = 5e9

    # Reward weights
    CLEARANCE_BONUS: float = 50.0
    FAILURE_PENALTY: float = -30.0
    TOXICITY_SCALE: float = 20.0
    COST_SCALE: float = 0.01
    BROAD_SPECTRUM_PENALTY: float = 2.0

    def __init__(self, render_mode: str | None = None) -> None:
        super().__init__()

        self.observation_space = spaces.Box(
            low=np.zeros(12, dtype=np.float32),
            high=np.array([
                1, 1, 1, 1, 1,         # pathogen one-hot
                256.0,                   # MIC
                10.0,                    # infection severity
                160.0,                   # CrCl
                150.0,                   # weight
                1.0,                     # immunocompromised
                14.0,                    # day
                1e10,                    # bacterial load
            ], dtype=np.float32),
            dtype=np.float32,
        )

        self.action_space = spaces.Discrete(5)

        self.patient_gen = PatientGenerator()
        self.patient: PatientProfile | None = None
        self.pathogen_id: int = 0
        self.bacterial_load: float = 0.0
        self.day: float = 0.0
        self.drug_conc: float = 0.0
        self.severity: float = 0.0
        self.current_antibiotic: int = -1
        self.cumulative_toxicity: float = 0.0

    def reset(
        self, *, seed: int | None = None, options: dict[str, Any] | None = None
    ) -> tuple[np.ndarray, dict[str, Any]]:
        super().reset(seed=seed)

        rng = np.random.default_rng(seed)
        self.patient_gen = PatientGenerator(rng=rng)
        self.patient = self.patient_gen.generate()
        self.pathogen_id = int(rng.integers(0, 5))
        self.bacterial_load = float(10 ** rng.uniform(6, 8))
        self.severity = float(rng.uniform(2.0, 8.0))
        self.day = 0.0
        self.drug_conc = 0.0
        self.current_antibiotic = -1
        self.cumulative_toxicity = 0.0

        return self._get_obs(), self._get_info()

    def step(self, action: int | np.ndarray) -> tuple[np.ndarray, float, bool, bool, dict[str, Any]]:
        assert self.patient is not None
        action = int(np.asarray(action).item()) if isinstance(action, np.ndarray) else int(action)
        abx = ANTIBIOTIC_FORMULARY[action]
        self.current_antibiotic = action

        # Determine susceptibility
        susceptible = SUSCEPTIBILITY_MATRIX[self.pathogen_id, action]
        is_susceptible = self.np_random.random() < susceptible

        # PK simulation
        pk = OneCompartmentPK(
            clearance=self.patient.adjust_clearance(abx["clearance"]),
            volume=self.patient.adjust_volume(abx["volume"]),
        )
        dose = abx["standard_dose"]
        self.drug_conc = pk.iv_bolus(self.drug_conc * 0.3, dose, self.STEP_HOURS)

        # PD simulation
        ec50 = abx["ec50_factor"] * self.patient.pathogen_mic
        pd_model = SigmoidalEmaxModel(emax=abx["emax"], ec50=ec50, hill=abx["hill"])
        kill_rate = pd_model.kill_rate(self.drug_conc) if is_susceptible else 0.0

        # Bacterial dynamics
        bacteria = BacterialPopulation(growth_rate=0.8)
        self.bacterial_load = bacteria.step(self.bacterial_load, kill_rate, self.STEP_HOURS)

        # Toxicity accumulation
        toxicity_event = self.np_random.random() < abx["toxicity_rate"]
        if toxicity_event:
            self.cumulative_toxicity += 1.0

        self.day += 1.0

        # Reward computation
        reward = 0.0
        terminated = False
        truncated = False

        if self.bacterial_load <= self.CLEARANCE_THRESHOLD:
            reward += self.CLEARANCE_BONUS
            terminated = True
        elif self.bacterial_load >= self.DETERIORATION_THRESHOLD:
            reward += self.FAILURE_PENALTY
            terminated = True

        # Continuous reward shaping
        reward -= self.cumulative_toxicity * self.TOXICITY_SCALE / self.MAX_DAYS
        reward -= abx["cost_per_dose"] * self.COST_SCALE
        if abx["class"] in ("carbapenem",):
            reward -= self.BROAD_SPECTRUM_PENALTY

        if self.day >= self.MAX_DAYS:
            truncated = True
            if self.bacterial_load > self.CLEARANCE_THRESHOLD:
                reward += self.FAILURE_PENALTY * 0.5

        return self._get_obs(), float(reward), terminated, truncated, self._get_info()

    def _get_obs(self) -> np.ndarray:
        assert self.patient is not None
        pathogen_onehot = np.zeros(5, dtype=np.float32)
        pathogen_onehot[self.pathogen_id] = 1.0
        return np.concatenate([
            pathogen_onehot,
            np.array([
                self.patient.pathogen_mic,
                self.severity,
                self.patient.creatinine_clearance,
                self.patient.weight,
                float(self.patient.is_immunocompromised),
                self.day,
                self.bacterial_load,
            ], dtype=np.float32),
        ])

    def _get_info(self) -> dict[str, Any]:
        return {
            "bacterial_load": self.bacterial_load,
            "drug_concentration": self.drug_conc,
            "day": self.day,
            "cumulative_toxicity": self.cumulative_toxicity,
            "pathogen_id": self.pathogen_id,
            "current_antibiotic": self.current_antibiotic,
        }
