"""AntibioSim: Gymnasium environments for RL in antimicrobial stewardship."""

__version__ = "0.1.0"

from gymnasium.envs.registration import register

register(
    id="antibiosim/AntibioticSelection-v0",
    entry_point="antibiosim.envs.antibiotic_selection:AntibioticSelectionEnv",
)

register(
    id="antibiosim/DoseOptimization-v0",
    entry_point="antibiosim.envs.dose_optimization:DoseOptimizationEnv",
)

register(
    id="antibiosim/TherapySwitch-v0",
    entry_point="antibiosim.envs.therapy_switch:TherapySwitchEnv",
)

register(
    id="antibiosim/ResistanceControl-v0",
    entry_point="antibiosim.envs.resistance_control:ResistanceControlEnv",
)
