"""Shared training configurations for all AntibioSim environments.

This is the single source of truth for environment-specific hyperparameters.
Both ppo.py CLI and train_all.py import from here.
"""

ENV_CONFIGS: dict[str, dict] = {
    "antibiosim/AntibioticSelection-v0": {
        "total_timesteps": 200_000,
        "learning_rate": 3e-4,
        "n_steps": 2048,
        "batch_size": 64,
        "gamma": 0.99,
        "description": "Antibiotic selection from formulary",
    },
    "antibiosim/DoseOptimization-v0": {
        "total_timesteps": 300_000,
        "learning_rate": 1e-4,
        "n_steps": 2048,
        "batch_size": 128,
        "gamma": 0.995,
        "description": "Antibiotic dose optimization for PK/PD target attainment",
    },
    "antibiosim/TherapySwitch-v0": {
        "total_timesteps": 300_000,
        "learning_rate": 3e-4,
        "n_steps": 2048,
        "batch_size": 64,
        "gamma": 0.99,
        "description": "IV-to-oral switch and therapy escalation/de-escalation",
    },
    "antibiosim/ResistanceControl-v0": {
        "total_timesteps": 500_000,
        "learning_rate": 1e-4,
        "n_steps": 4096,
        "batch_size": 128,
        "gamma": 0.998,
        "description": "Ward-level antibiotic policy for resistance control",
    },
}
