"""Training pipeline for AntibioSim environments."""
