"""Train PPO agents on all AntibioSim environments and generate results.

This script trains PPO on each environment, evaluates against random and heuristic
baselines, and saves results to results/training_results.json.

Usage: python -m antibiosim.training.train_all [--output-dir results]
"""

from __future__ import annotations

import argparse
import json
import os
import random
import time
import gymnasium as gym
import numpy as np

import antibiosim  # noqa: F401 - triggers env registration
from antibiosim.agents.heuristic_agent import HeuristicAgent
from antibiosim.agents.random_agent import RandomAgent
from antibiosim.training.configs import ENV_CONFIGS

SEED = 42
N_EVAL_EPISODES = 50


def evaluate_agent(env: gym.Env, predict_fn, n_episodes: int = N_EVAL_EPISODES) -> dict:
    """Evaluate any agent that implements predict_fn(obs) -> action."""
    rewards = []
    episode_lengths = []
    for ep in range(n_episodes):
        obs, _ = env.reset(seed=ep + 1000)
        total_r = 0.0
        steps = 0
        done = False
        while not done:
            action = predict_fn(obs)
            obs, r, term, trunc, _ = env.step(action)
            total_r += float(r)
            steps += 1
            done = term or trunc
        rewards.append(total_r)
        episode_lengths.append(steps)

    return {
        "mean_reward": float(np.mean(rewards)),
        "std_reward": float(np.std(rewards)),
        "min_reward": float(np.min(rewards)),
        "max_reward": float(np.max(rewards)),
        "mean_episode_length": float(np.mean(episode_lengths)),
        "n_episodes": n_episodes,
    }


def train_and_evaluate(env_id: str, config: dict, output_dir: str) -> dict:
    """Train PPO on one environment and evaluate all baselines."""
    try:
        from stable_baselines3 import PPO
    except ImportError:
        print("stable-baselines3 not installed. Install with: pip install antibiosim[train]")
        raise

    print(f"\n{'='*60}")
    print(f"Training: {env_id}")
    print(f"Steps: {config['total_timesteps']:,}")
    print(f"{'='*60}")

    # Seed everything
    random.seed(SEED)
    np.random.seed(SEED)
    print(f"Training with seed={SEED}")

    env = gym.make(env_id)
    eval_env = gym.make(env_id)

    start_time = time.time()

    model = PPO(
        "MlpPolicy",
        env,
        learning_rate=config["learning_rate"],
        n_steps=config["n_steps"],
        batch_size=config["batch_size"],
        gamma=config["gamma"],
        seed=SEED,
        verbose=0,
    )

    # Collect training reward curve
    reward_curve = []
    steps_per_log = config["total_timesteps"] // 20

    for i in range(20):
        model.learn(total_timesteps=steps_per_log, reset_num_timesteps=False)
        quick_eval = evaluate_agent(
            eval_env,
            lambda obs, m=model: m.predict(obs, deterministic=True)[0],
            n_episodes=10,
        )
        reward_curve.append({
            "step": (i + 1) * steps_per_log,
            "mean_reward": quick_eval["mean_reward"],
            "std_reward": quick_eval["std_reward"],
        })
        print(f"  Step {(i+1)*steps_per_log:>8,}: reward = {quick_eval['mean_reward']:.2f}")

    train_time = time.time() - start_time

    # Save model
    model_dir = os.path.join(output_dir, "models")
    os.makedirs(model_dir, exist_ok=True)
    env_short = env_id.split("/")[-1]
    model.save(os.path.join(model_dir, f"{env_short}_final"))

    # Evaluate all agents
    print(f"\nEvaluating baselines for {env_id}...")

    ppo_results = evaluate_agent(
        eval_env,
        lambda obs, m=model: m.predict(obs, deterministic=True)[0],
    )

    random_agent = RandomAgent(eval_env, seed=SEED)
    random_results = evaluate_agent(
        eval_env,
        lambda obs, ra=random_agent: ra.act(obs),
    )

    heuristic_agent = HeuristicAgent(env_id, seed=SEED)
    heuristic_results = evaluate_agent(
        eval_env,
        lambda obs, ha=heuristic_agent: ha.act(obs),
    )

    # Compute ratios safely
    random_mean = random_results["mean_reward"]
    ppo_mean = ppo_results["mean_reward"]

    if abs(random_mean) < 0.01:
        ppo_vs_random_ratio = ppo_mean - random_mean
        ratio_note = "Raw difference used (random baseline near zero)"
    elif random_mean < 0:
        ppo_vs_random_ratio = abs(ppo_mean - random_mean) / abs(random_mean)
        ratio_note = "Absolute improvement ratio (negative baseline)"
    else:
        ppo_vs_random_ratio = ppo_mean / random_mean
        ratio_note = "Standard ratio"

    env.close()
    eval_env.close()

    return {
        "env_id": env_id,
        "ppo": ppo_results,
        "random": random_results,
        "heuristic": heuristic_results,
        "ppo_vs_random_ratio": round(ppo_vs_random_ratio, 3),
        "ppo_vs_random_ratio_note": ratio_note,
        "ppo_vs_heuristic_ratio": round(
            ppo_mean / heuristic_results["mean_reward"], 3
        ) if abs(heuristic_results["mean_reward"]) > 0.01 else 0.0,
        "reward_curve": reward_curve,
        "training_time_seconds": round(train_time, 1),
        "config": {
            "total_timesteps": config["total_timesteps"],
            "learning_rate": config["learning_rate"],
            "n_steps": config["n_steps"],
            "batch_size": config["batch_size"],
            "gamma": config["gamma"],
            "seed": SEED,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Train all AntibioSim environments")
    parser.add_argument("--output-dir", type=str, default="results")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    os.makedirs(os.path.join(args.output_dir, "training_logs"), exist_ok=True)

    all_results = {}

    for env_id, config in ENV_CONFIGS.items():
        result = train_and_evaluate(env_id, config, args.output_dir)
        env_short = env_id.split("/")[-1]
        all_results[env_short] = result

        # Save per-env log
        log_path = os.path.join(
            args.output_dir, "training_logs", f"{env_short}_log.json"
        )
        with open(log_path, "w") as f:
            json.dump(result, f, indent=2)
        print(f"  Saved log to {log_path}")

    # Save combined results
    results_path = os.path.join(args.output_dir, "training_results.json")
    with open(results_path, "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"\nAll results saved to {results_path}")

    # Print summary
    print(f"\n{'='*70}")
    print("TRAINING SUMMARY")
    print(f"{'='*70}")
    print(f"{'Environment':<30} {'PPO':>10} {'Random':>10} {'Heuristic':>10} {'Ratio':>8}")
    print("-" * 70)
    for name, r in all_results.items():
        print(
            f"{name:<30} "
            f"{r['ppo']['mean_reward']:>10.2f} "
            f"{r['random']['mean_reward']:>10.2f} "
            f"{r['heuristic']['mean_reward']:>10.2f} "
            f"{r['ppo_vs_random_ratio']:>8.2f}x"
        )


if __name__ == "__main__":
    main()
