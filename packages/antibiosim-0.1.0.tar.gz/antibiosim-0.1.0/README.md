# AntibioSim

[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Tests: 170](https://img.shields.io/badge/tests-170-brightgreen.svg)]()
[![PyPI](https://img.shields.io/pypi/v/antibiosim.svg)](https://pypi.org/project/antibiosim/)

**Gymnasium environments for reinforcement learning in antimicrobial stewardship and antibiotic treatment optimization.**

AntibioSim provides four Gymnasium-compatible environments that model key clinical decision points in antibiotic therapy: drug selection, dose optimization, therapy switching, and ward-level resistance control. Each environment is grounded in established pharmacokinetic/pharmacodynamic (PK/PD) models and bacterial dynamics from the antimicrobial stewardship literature.

## Environments

| Environment | Task | Action Space | Difficulty |
|---|---|---|---|
| `AntibioticSelection-v0` | Choose optimal antibiotic from formulary | Discrete(5) | Easy |
| `DoseOptimization-v0` | Optimize dosing for PK/PD target attainment | Box(1) | Medium |
| `TherapySwitch-v0` | IV-to-oral switch and escalation decisions | Discrete(4) | Medium |
| `ResistanceControl-v0` | Ward-level antibiotic policy for resistance control | MultiDiscrete(3^5) | Hard |

## Installation

```bash
pip install antibiosim
```

For training:
```bash
pip install antibiosim[train]
```

## Quick Start

```python
import gymnasium as gym
import antibiosim

env = gym.make("antibiosim/AntibioticSelection-v0")
obs, info = env.reset()

for _ in range(14):
    action = env.action_space.sample()
    obs, reward, terminated, truncated, info = env.step(action)
    if terminated or truncated:
        break
```

## Domain Models

- **Pharmacokinetics:** One-compartment and two-compartment PK models (Drusano, 2004)
- **Pharmacodynamics:** Emax and sigmoidal Emax models (Regoes et al., 2004)
- **Bacterial dynamics:** Logistic growth with antibiotic kill (Austin et al., 1999)
- **Resistance:** Two-population susceptible/resistant dynamics (Levin & Bonten, 2004)

## Baseline Agents

- **Random:** Uniform random action selection
- **Heuristic:** Clinical guideline-based rules (Barlam et al., 2016)
- **PPO:** Proximal Policy Optimization via Stable-Baselines3

## Training

```bash
# Train PPO on all environments
python -m antibiosim.training.train_all

# Train a single environment
antibiosim-train --env antibiosim/DoseOptimization-v0
```

## Citation

```bibtex
@software{dhia2026antibiosim,
  author = {Dhia, Hass},
  title = {AntibioSim: Gymnasium Environments for Reinforcement Learning in Antimicrobial Stewardship},
  year = {2026},
  url = {https://github.com/HassDhia/antibiosim},
  version = {0.1.0}
}
```

## License

MIT License. Copyright (c) 2026 Hass Dhia, Smart Technology Investments Research Institute.
