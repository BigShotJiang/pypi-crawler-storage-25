"""Generate publication-quality figures from training results.

Reads results/training_results.json and produces:
1. Training curves with variance bands
2. Baseline comparison bar chart
3. Architecture diagram

All figures saved to paper/figures/ at 300 DPI with serif fonts.
"""

import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

# Publication-quality style settings
plt.rcParams["font.family"] = "serif"
plt.rcParams["font.size"] = 10
plt.rcParams["axes.linewidth"] = 0.8
plt.rcParams["figure.dpi"] = 300

# Colorblind-safe palette (tab10 subset)
COLORS = {
    "ppo": "#1f77b4",
    "random": "#ff7f0e",
    "heuristic": "#2ca02c",
}

ENV_SHORT_NAMES = {
    "AntibioticSelection-v0": "Selection",
    "DoseOptimization-v0": "Dosing",
    "TherapySwitch-v0": "Switch",
    "ResistanceControl-v0": "Resistance",
}


def load_results(path: str = "results/training_results.json") -> dict:
    with open(path) as f:
        return json.load(f)


def plot_training_curves(results: dict, output_dir: str) -> None:
    """Plot training reward curves with variance bands for each environment."""
    fig, axes = plt.subplots(2, 2, figsize=(8, 6), constrained_layout=True)
    axes_flat = axes.flatten()

    for i, (env_name, data) in enumerate(results.items()):
        ax = axes_flat[i]
        curve = data["reward_curve"]
        steps = [p["step"] for p in curve]
        means = [p["mean_reward"] for p in curve]
        stds = [p["std_reward"] for p in curve]

        means_arr = np.array(means)
        stds_arr = np.array(stds)

        ax.plot(steps, means, color=COLORS["ppo"], linewidth=1.5, label="PPO")
        ax.fill_between(
            steps,
            means_arr - stds_arr,
            means_arr + stds_arr,
            color=COLORS["ppo"],
            alpha=0.2,
        )

        # Random baseline line
        random_mean = data["random"]["mean_reward"]
        ax.axhline(y=random_mean, color=COLORS["random"], linestyle="--",
                    linewidth=1.0, label="Random")

        # Heuristic baseline line
        heuristic_mean = data["heuristic"]["mean_reward"]
        ax.axhline(y=heuristic_mean, color=COLORS["heuristic"], linestyle="-.",
                    linewidth=1.0, label="Heuristic")

        short_name = ENV_SHORT_NAMES.get(env_name, env_name)
        ax.set_title(short_name, fontsize=11)
        ax.set_xlabel("Training Steps")
        ax.set_ylabel("Mean Reward")
        ax.legend(fontsize=7, loc="lower right")
        ax.grid(True, alpha=0.3)

    fig.suptitle("PPO Training Curves with Baseline Comparison", fontsize=12, fontweight="bold")
    path = os.path.join(output_dir, "training_curves.png")
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {path}")


def plot_baseline_comparison(results: dict, output_dir: str) -> None:
    """Bar chart comparing PPO vs random vs heuristic across environments."""
    envs = list(results.keys())
    short_names = [ENV_SHORT_NAMES.get(e, e) for e in envs]

    ppo_means = [results[e]["ppo"]["mean_reward"] for e in envs]
    ppo_stds = [results[e]["ppo"]["std_reward"] for e in envs]
    random_means = [results[e]["random"]["mean_reward"] for e in envs]
    random_stds = [results[e]["random"]["std_reward"] for e in envs]
    heuristic_means = [results[e]["heuristic"]["mean_reward"] for e in envs]
    heuristic_stds = [results[e]["heuristic"]["std_reward"] for e in envs]

    x = np.arange(len(envs))
    width = 0.25

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(x - width, random_means, width, yerr=random_stds,
           label="Random", color=COLORS["random"], alpha=0.85, capsize=3)
    ax.bar(x, heuristic_means, width, yerr=heuristic_stds,
           label="Heuristic", color=COLORS["heuristic"], alpha=0.85, capsize=3)
    ax.bar(x + width, ppo_means, width, yerr=ppo_stds,
           label="PPO", color=COLORS["ppo"], alpha=0.85, capsize=3)

    ax.set_xlabel("Environment")
    ax.set_ylabel("Mean Episode Reward")
    ax.set_title("Baseline Comparison Across AntibioSim Environments", fontweight="bold")
    ax.set_xticks(x)
    ax.set_xticklabels(short_names)
    ax.legend()
    ax.grid(True, axis="y", alpha=0.3)

    path = os.path.join(output_dir, "baseline_comparison.png")
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {path}")


def plot_architecture(output_dir: str) -> None:
    """Generate architecture diagram using matplotlib."""
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 7)
    ax.axis("off")

    # Title
    ax.text(5, 6.5, "AntibioSim Architecture", fontsize=14, fontweight="bold",
            ha="center", va="center")

    # Domain Models box
    rect = plt.Rectangle((0.5, 4.2), 3, 1.5, fill=True, facecolor="#e3f2fd",
                          edgecolor="#1565c0", linewidth=1.5, zorder=2)
    ax.add_patch(rect)
    ax.text(2, 5.2, "Domain Models", fontsize=10, fontweight="bold", ha="center")
    ax.text(2, 4.7, "PK  |  PD  |  Bacteria  |  Patient", fontsize=7, ha="center")

    # Environments box
    rect2 = plt.Rectangle((4, 4.2), 3, 1.5, fill=True, facecolor="#e8f5e9",
                           edgecolor="#2e7d32", linewidth=1.5, zorder=2)
    ax.add_patch(rect2)
    ax.text(5.5, 5.2, "Gymnasium Envs", fontsize=10, fontweight="bold", ha="center")
    ax.text(5.5, 4.7, "Select | Dose | Switch | Resist", fontsize=7, ha="center")

    # Agents box
    rect3 = plt.Rectangle((7.5, 4.2), 2, 1.5, fill=True, facecolor="#fff3e0",
                           edgecolor="#e65100", linewidth=1.5, zorder=2)
    ax.add_patch(rect3)
    ax.text(8.5, 5.2, "Agents", fontsize=10, fontweight="bold", ha="center")
    ax.text(8.5, 4.7, "Random | Heuristic | PPO", fontsize=7, ha="center")

    # Arrows
    ax.annotate("", xy=(4, 4.95), xytext=(3.5, 4.95),
                arrowprops=dict(arrowstyle="->", color="#333", lw=1.5))
    ax.annotate("", xy=(7.5, 4.95), xytext=(7, 4.95),
                arrowprops=dict(arrowstyle="->", color="#333", lw=1.5))

    # Training Pipeline
    rect4 = plt.Rectangle((2, 2), 6, 1.5, fill=True, facecolor="#fce4ec",
                           edgecolor="#c62828", linewidth=1.5, zorder=2)
    ax.add_patch(rect4)
    ax.text(5, 3.0, "Training & Evaluation Pipeline", fontsize=10,
            fontweight="bold", ha="center")
    ax.text(5, 2.5, "train_all.py  |  configs.py  |  benchmarks", fontsize=7, ha="center")

    # Arrow from envs+agents to training
    ax.annotate("", xy=(5, 3.5), xytext=(5, 4.2),
                arrowprops=dict(arrowstyle="->", color="#333", lw=1.5))

    # Results
    rect5 = plt.Rectangle((3, 0.3), 4, 1.2, fill=True, facecolor="#f3e5f5",
                           edgecolor="#6a1b9a", linewidth=1.5, zorder=2)
    ax.add_patch(rect5)
    ax.text(5, 1.1, "Results & Paper", fontsize=10, fontweight="bold", ha="center")
    ax.text(5, 0.7, "training_results.json  |  figures  |  LaTeX", fontsize=7, ha="center")

    ax.annotate("", xy=(5, 1.5), xytext=(5, 2.0),
                arrowprops=dict(arrowstyle="->", color="#333", lw=1.5))

    path = os.path.join(output_dir, "architecture.png")
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {path}")


if __name__ == "__main__":
    output_dir = "paper/figures"
    os.makedirs(output_dir, exist_ok=True)

    results = load_results()
    plot_training_curves(results, output_dir)
    plot_baseline_comparison(results, output_dir)
    plot_architecture(output_dir)
    print("\nAll figures generated successfully.")
