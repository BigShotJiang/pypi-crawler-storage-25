"""Tests for benchmark suite."""

import gymnasium as gym
import numpy as np
import pytest

import antibiosim  # noqa: F401

from antibiosim.training.configs import ENV_CONFIGS


class TestConfigs:
    def test_all_envs_have_configs(self):
        expected = [
            "antibiosim/AntibioticSelection-v0",
            "antibiosim/DoseOptimization-v0",
            "antibiosim/TherapySwitch-v0",
            "antibiosim/ResistanceControl-v0",
        ]
        for env_id in expected:
            assert env_id in ENV_CONFIGS, f"Missing config for {env_id}"

    def test_configs_have_required_keys(self):
        required = ["total_timesteps", "learning_rate", "n_steps", "batch_size", "gamma"]
        for env_id, config in ENV_CONFIGS.items():
            for key in required:
                assert key in config, f"{env_id} missing {key}"

    def test_timesteps_minimum(self):
        for env_id, config in ENV_CONFIGS.items():
            assert config["total_timesteps"] >= 200_000, (
                f"{env_id} has {config['total_timesteps']} < 200K minimum"
            )

    def test_learning_rate_range(self):
        for env_id, config in ENV_CONFIGS.items():
            assert 1e-5 <= config["learning_rate"] <= 1e-2

    def test_gamma_range(self):
        for env_id, config in ENV_CONFIGS.items():
            assert 0.9 <= config["gamma"] <= 1.0

    def test_resistance_control_has_higher_budget(self):
        rc = ENV_CONFIGS["antibiosim/ResistanceControl-v0"]
        sel = ENV_CONFIGS["antibiosim/AntibioticSelection-v0"]
        assert rc["total_timesteps"] > sel["total_timesteps"]


class TestEnvironmentSpecs:
    @pytest.mark.parametrize("env_id", list(ENV_CONFIGS.keys()))
    def test_env_gym_compatible(self, env_id):
        """Verify each env follows the Gymnasium API contract."""
        env = gym.make(env_id)
        assert hasattr(env, "observation_space")
        assert hasattr(env, "action_space")
        assert hasattr(env, "reset")
        assert hasattr(env, "step")
        env.close()

    @pytest.mark.parametrize("env_id", list(ENV_CONFIGS.keys()))
    def test_multiple_resets(self, env_id):
        env = gym.make(env_id)
        for seed in [1, 2, 3]:
            obs, info = env.reset(seed=seed)
            assert obs is not None
        env.close()

    @pytest.mark.parametrize("env_id", list(ENV_CONFIGS.keys()))
    def test_runs_five_steps(self, env_id):
        env = gym.make(env_id)
        obs, _ = env.reset(seed=42)
        for _ in range(5):
            action = env.action_space.sample()
            obs, r, term, trunc, info = env.step(action)
            if term or trunc:
                obs, _ = env.reset(seed=42)
        env.close()
