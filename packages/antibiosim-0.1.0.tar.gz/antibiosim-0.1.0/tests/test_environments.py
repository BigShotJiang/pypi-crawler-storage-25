"""Tests for all AntibioSim Gymnasium environments."""

import gymnasium as gym
import numpy as np
import pytest

import antibiosim  # noqa: F401 - triggers registration


ENV_IDS = [
    "antibiosim/AntibioticSelection-v0",
    "antibiosim/DoseOptimization-v0",
    "antibiosim/TherapySwitch-v0",
    "antibiosim/ResistanceControl-v0",
]


class TestEnvironmentRegistration:
    @pytest.mark.parametrize("env_id", ENV_IDS)
    def test_make(self, env_id):
        env = gym.make(env_id)
        assert env is not None
        env.close()

    @pytest.mark.parametrize("env_id", ENV_IDS)
    def test_reset(self, env_id):
        env = gym.make(env_id)
        obs, info = env.reset(seed=42)
        assert isinstance(obs, np.ndarray)
        assert isinstance(info, dict)
        env.close()

    @pytest.mark.parametrize("env_id", ENV_IDS)
    def test_step(self, env_id):
        env = gym.make(env_id)
        obs, _ = env.reset(seed=42)
        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        assert isinstance(obs, np.ndarray)
        assert isinstance(reward, float)
        assert isinstance(terminated, bool)
        assert isinstance(truncated, bool)
        assert isinstance(info, dict)
        env.close()

    @pytest.mark.parametrize("env_id", ENV_IDS)
    def test_observation_in_space(self, env_id):
        env = gym.make(env_id)
        obs, _ = env.reset(seed=42)
        assert env.observation_space.contains(obs), f"obs not in space: {obs}"
        env.close()

    @pytest.mark.parametrize("env_id", ENV_IDS)
    def test_episode_terminates(self, env_id):
        env = gym.make(env_id)
        obs, _ = env.reset(seed=42)
        done = False
        steps = 0
        max_steps = 1000
        while not done and steps < max_steps:
            action = env.action_space.sample()
            obs, _, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            steps += 1
        assert done, f"Episode did not terminate in {max_steps} steps"
        env.close()

    @pytest.mark.parametrize("env_id", ENV_IDS)
    def test_reproducible_reset(self, env_id):
        env = gym.make(env_id)
        obs1, _ = env.reset(seed=42)
        obs2, _ = env.reset(seed=42)
        np.testing.assert_array_equal(obs1, obs2)
        env.close()


class TestAntibioticSelection:
    def test_observation_shape(self):
        env = gym.make("antibiosim/AntibioticSelection-v0")
        obs, _ = env.reset(seed=42)
        assert obs.shape == (12,)
        env.close()

    def test_action_space(self):
        env = gym.make("antibiosim/AntibioticSelection-v0")
        assert env.action_space.n == 5
        env.close()

    def test_pathogen_onehot(self):
        env = gym.make("antibiosim/AntibioticSelection-v0")
        obs, _ = env.reset(seed=42)
        onehot = obs[:5]
        assert np.sum(onehot) == pytest.approx(1.0)
        env.close()

    def test_info_keys(self):
        env = gym.make("antibiosim/AntibioticSelection-v0")
        obs, info = env.reset(seed=42)
        assert "bacterial_load" in info
        assert "pathogen_id" in info
        env.close()

    def test_different_actions_different_outcomes(self):
        rewards = []
        for action in range(5):
            env = gym.make("antibiosim/AntibioticSelection-v0")
            obs, _ = env.reset(seed=42)
            total_r = 0
            for _ in range(14):
                obs, r, term, trunc, _ = env.step(action)
                total_r += r
                if term or trunc:
                    break
            rewards.append(total_r)
            env.close()
        assert len(set(round(r, 2) for r in rewards)) > 1


class TestDoseOptimization:
    def test_observation_shape(self):
        env = gym.make("antibiosim/DoseOptimization-v0")
        obs, _ = env.reset(seed=42)
        assert obs.shape == (8,)
        env.close()

    def test_action_space(self):
        env = gym.make("antibiosim/DoseOptimization-v0")
        assert env.action_space.shape == (1,)
        assert env.action_space.low[0] == pytest.approx(0.0)
        assert env.action_space.high[0] == pytest.approx(1.0)
        env.close()

    def test_high_dose_reduces_bacteria(self):
        env = gym.make("antibiosim/DoseOptimization-v0")
        obs, _ = env.reset(seed=42)
        initial_load = obs[1]
        action = np.array([0.8], dtype=np.float32)
        obs, _, _, _, _ = env.step(action)
        assert obs[1] <= initial_load
        env.close()

    def test_zero_dose_bacteria_grow(self):
        env = gym.make("antibiosim/DoseOptimization-v0")
        obs, _ = env.reset(seed=42)
        initial_load = obs[1]
        action = np.array([0.0], dtype=np.float32)
        obs, _, _, _, _ = env.step(action)
        assert obs[1] >= initial_load
        env.close()


class TestTherapySwitch:
    def test_observation_shape(self):
        env = gym.make("antibiosim/TherapySwitch-v0")
        obs, _ = env.reset(seed=42)
        assert obs.shape == (10,)
        env.close()

    def test_action_space(self):
        env = gym.make("antibiosim/TherapySwitch-v0")
        assert env.action_space.n == 4
        env.close()

    def test_starts_on_broad_iv(self):
        env = gym.make("antibiosim/TherapySwitch-v0")
        obs, _ = env.reset(seed=42)
        assert obs[3] == pytest.approx(2.0)  # Therapy level 2 = broad_iv
        env.close()

    def test_continue_action(self):
        env = gym.make("antibiosim/TherapySwitch-v0")
        obs, _ = env.reset(seed=42)
        obs, _, _, _, info = env.step(0)
        assert info["current_therapy"] == "broad_iv"
        env.close()

    def test_info_keys(self):
        env = gym.make("antibiosim/TherapySwitch-v0")
        obs, _ = env.reset(seed=42)
        obs, _, _, _, info = env.step(0)
        assert "temperature" in info
        assert "clinical_improving" in info
        env.close()


class TestResistanceControl:
    def test_observation_shape(self):
        env = gym.make("antibiosim/ResistanceControl-v0")
        obs, _ = env.reset(seed=42)
        assert obs.shape == (26,)  # 5 beds * 5 features + 1 ward resistance
        env.close()

    def test_action_space(self):
        env = gym.make("antibiosim/ResistanceControl-v0")
        assert env.action_space.shape == (5,)
        env.close()

    def test_broad_spectrum_increases_resistance(self):
        env = gym.make("antibiosim/ResistanceControl-v0")
        obs, _ = env.reset(seed=42)
        # Run with all broad for 10 steps
        for _ in range(10):
            obs, _, _, _, info = env.step(np.array([2, 2, 2, 2, 2]))
        broad_resistance = info["ward_resistance_prevalence"]

        obs, _ = env.reset(seed=42)
        for _ in range(10):
            obs, _, _, _, info = env.step(np.array([0, 0, 0, 0, 0]))
        narrow_resistance = info["ward_resistance_prevalence"]

        assert broad_resistance > narrow_resistance
        env.close()

    def test_info_keys(self):
        env = gym.make("antibiosim/ResistanceControl-v0")
        obs, _ = env.reset(seed=42)
        obs, _, _, _, info = env.step(np.array([0, 0, 0, 0, 0]))
        assert "ward_resistance_prevalence" in info
        assert "total_susceptible" in info
        assert "total_resistant" in info
        env.close()
