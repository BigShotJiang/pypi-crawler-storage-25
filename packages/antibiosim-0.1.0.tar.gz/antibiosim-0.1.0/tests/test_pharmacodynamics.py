"""Tests for pharmacodynamic models."""

import numpy as np
import pytest

from antibiosim.models.pharmacodynamics import (
    EmaxModel,
    SigmoidalEmaxModel,
    compute_auc,
    compute_pkpd_indices,
    compute_time_above_mic,
)


class TestEmaxModel:
    def test_init_default(self):
        pd = EmaxModel()
        assert pd.emax == 3.0
        assert pd.ec50 == 2.0

    def test_init_invalid_emax(self):
        with pytest.raises(ValueError):
            EmaxModel(emax=-1.0)

    def test_init_invalid_ec50(self):
        with pytest.raises(ValueError):
            EmaxModel(ec50=0.0)

    def test_kill_rate_zero_conc(self):
        pd = EmaxModel()
        assert pd.kill_rate(0.0) == 0.0

    def test_kill_rate_negative_conc(self):
        pd = EmaxModel()
        assert pd.kill_rate(-1.0) == 0.0

    def test_kill_rate_at_ec50(self):
        pd = EmaxModel(emax=4.0, ec50=2.0)
        rate = pd.kill_rate(2.0)
        assert rate == pytest.approx(2.0)  # Emax/2

    def test_kill_rate_increases_with_concentration(self):
        pd = EmaxModel()
        r1 = pd.kill_rate(1.0)
        r2 = pd.kill_rate(10.0)
        assert r2 > r1

    def test_kill_rate_bounded_by_emax(self):
        pd = EmaxModel(emax=5.0)
        rate = pd.kill_rate(1000.0)
        assert rate < 5.0
        assert rate > 4.9

    def test_fractional_kill_range(self):
        pd = EmaxModel()
        assert pd.fractional_kill(0.0) == 0.0
        assert 0.0 < pd.fractional_kill(1.0) < 1.0
        assert pd.fractional_kill(1000.0) > 0.99


class TestSigmoidalEmaxModel:
    def test_init_default(self):
        pd = SigmoidalEmaxModel()
        assert pd.hill == 1.5

    def test_init_invalid_hill(self):
        with pytest.raises(ValueError):
            SigmoidalEmaxModel(hill=-1.0)

    def test_kill_rate_steeper_hill(self):
        pd_low = SigmoidalEmaxModel(hill=1.0)
        pd_high = SigmoidalEmaxModel(hill=3.0)
        # Near EC50, higher hill gives sharper transition
        r_low_below = pd_low.kill_rate(1.0)
        r_high_below = pd_high.kill_rate(1.0)
        # Below EC50, high hill should be lower
        assert r_high_below < r_low_below

    def test_kill_rate_at_ec50(self):
        pd = SigmoidalEmaxModel(emax=4.0, ec50=2.0, hill=2.0)
        rate = pd.kill_rate(2.0)
        assert rate == pytest.approx(2.0)  # Emax/2 at EC50 for any hill

    def test_mic_from_ec50(self):
        pd = SigmoidalEmaxModel(emax=4.0, ec50=2.0, hill=1.5)
        mic = pd.mic_from_ec50(0.5)
        assert mic > 0
        assert mic < pd.ec50

    def test_mic_from_ec50_high_growth(self):
        pd = SigmoidalEmaxModel(emax=4.0)
        mic = pd.mic_from_ec50(3.99)
        assert mic > pd.ec50  # Near Emax, MIC >> EC50

    def test_mic_from_ec50_exceeds_emax(self):
        pd = SigmoidalEmaxModel(emax=4.0)
        assert pd.mic_from_ec50(5.0) == float("inf")


class TestPKPDHelpers:
    def test_time_above_mic_all_above(self):
        conc = [10.0, 10.0, 10.0, 10.0]
        assert compute_time_above_mic(conc, 5.0, 1.0) == pytest.approx(1.0)

    def test_time_above_mic_none_above(self):
        conc = [1.0, 1.0, 1.0]
        assert compute_time_above_mic(conc, 5.0, 1.0) == pytest.approx(0.0)

    def test_time_above_mic_half(self):
        conc = [10.0, 10.0, 1.0, 1.0]
        assert compute_time_above_mic(conc, 5.0, 1.0) == pytest.approx(0.5)

    def test_time_above_mic_empty(self):
        assert compute_time_above_mic([], 5.0, 1.0) == 0.0

    def test_compute_auc_constant(self):
        conc = [10.0] * 24
        auc = compute_auc(conc, dt=1.0)
        assert auc == pytest.approx(230.0)  # Trapezoidal for constant

    def test_compute_auc_single_point(self):
        assert compute_auc([10.0], dt=1.0) == 0.0

    def test_compute_auc_increasing(self):
        conc = list(range(10))
        auc = compute_auc(conc, dt=1.0)
        assert auc > 0

    def test_pkpd_indices_returns_dict(self):
        conc = [20.0, 15.0, 10.0, 8.0, 5.0]
        result = compute_pkpd_indices(conc, mic=2.0, dt=1.0)
        assert "cmax_mic_ratio" in result
        assert "auc24_mic_ratio" in result
        assert "time_above_mic" in result

    def test_pkpd_indices_values(self):
        conc = [20.0, 15.0, 10.0, 8.0, 5.0]
        result = compute_pkpd_indices(conc, mic=2.0, dt=1.0)
        assert result["cmax_mic_ratio"] == pytest.approx(10.0)
        assert result["time_above_mic"] == pytest.approx(1.0)

    def test_pkpd_indices_zero_mic(self):
        conc = [10.0, 5.0]
        result = compute_pkpd_indices(conc, mic=0.0, dt=1.0)
        assert result["cmax_mic_ratio"] == 0.0
