"""Tests for pharmacokinetic models."""

import numpy as np
import pytest

from antibiosim.models.pharmacokinetics import OneCompartmentPK, TwoCompartmentPK


class TestOneCompartmentPK:
    def test_init_default(self):
        pk = OneCompartmentPK()
        assert pk.clearance == 5.0
        assert pk.volume == 20.0

    def test_init_custom(self):
        pk = OneCompartmentPK(clearance=10.0, volume=30.0, absorption_rate=2.0, bioavailability=0.8)
        assert pk.clearance == 10.0
        assert pk.volume == 30.0
        assert pk.ka == 2.0
        assert pk.bioavailability == 0.8

    def test_init_invalid_clearance(self):
        with pytest.raises(ValueError):
            OneCompartmentPK(clearance=-1.0)

    def test_init_invalid_volume(self):
        with pytest.raises(ValueError):
            OneCompartmentPK(volume=0.0)

    def test_init_invalid_bioavailability(self):
        with pytest.raises(ValueError):
            OneCompartmentPK(bioavailability=1.5)

    def test_iv_bolus_concentration_increases(self):
        pk = OneCompartmentPK()
        c_new = pk.iv_bolus(0.0, 1000.0, 0.01)
        assert c_new > 0.0

    def test_iv_bolus_decays_over_time(self):
        pk = OneCompartmentPK()
        c1 = pk.iv_bolus(0.0, 1000.0, 1.0)
        c2 = pk.iv_bolus(0.0, 1000.0, 10.0)
        assert c1 > c2

    def test_iv_bolus_zero_dose(self):
        pk = OneCompartmentPK()
        c_new = pk.iv_bolus(10.0, 0.0, 1.0)
        assert c_new < 10.0
        assert c_new > 0.0

    def test_iv_bolus_non_negative(self):
        pk = OneCompartmentPK()
        c_new = pk.iv_bolus(0.0, 0.0, 100.0)
        assert c_new >= 0.0

    def test_oral_dose_returns_tuple(self):
        pk = OneCompartmentPK()
        result = pk.oral_dose(0.0, 0.0, 500.0, 1.0)
        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_oral_dose_absorption(self):
        pk = OneCompartmentPK()
        c, gut = pk.oral_dose(0.0, 0.0, 500.0, 1.0)
        assert c > 0.0
        assert gut >= 0.0

    def test_oral_gut_decreases(self):
        pk = OneCompartmentPK()
        _, gut1 = pk.oral_dose(0.0, 100.0, 0.0, 1.0)
        assert gut1 < 100.0

    def test_half_life_positive(self):
        pk = OneCompartmentPK()
        assert pk.half_life() > 0.0

    def test_half_life_inversely_proportional(self):
        pk1 = OneCompartmentPK(clearance=5.0, volume=20.0)
        pk2 = OneCompartmentPK(clearance=10.0, volume=20.0)
        assert pk2.half_life() < pk1.half_life()

    def test_auc_single_dose(self):
        pk = OneCompartmentPK(clearance=5.0)
        auc = pk.auc_single_dose(1000.0)
        assert auc == pytest.approx(200.0)

    def test_steady_state_peak(self):
        pk = OneCompartmentPK()
        ss = pk.steady_state_peak(1000.0, 8.0)
        single = 1000.0 / pk.volume
        assert ss > single  # Accumulation

    def test_elimination_rate_constant(self):
        pk = OneCompartmentPK(clearance=5.0, volume=20.0)
        assert pk.ke == pytest.approx(0.25)

    def test_invalid_dt(self):
        pk = OneCompartmentPK()
        with pytest.raises(ValueError):
            pk.iv_bolus(0.0, 100.0, -1.0)


class TestTwoCompartmentPK:
    def test_init_default(self):
        pk = TwoCompartmentPK()
        assert pk.cl == 5.0
        assert pk.v1 == 15.0

    def test_init_invalid(self):
        with pytest.raises(ValueError):
            TwoCompartmentPK(clearance=-1.0)

    def test_step_returns_tuple(self):
        pk = TwoCompartmentPK()
        c1, c2 = pk.step(10.0, 0.0, 0.0, 1.0)
        assert isinstance(c1, float)
        assert isinstance(c2, float)

    def test_step_elimination(self):
        pk = TwoCompartmentPK()
        c1, c2 = pk.step(50.0, 0.0, 0.0, 24.0)
        assert c1 < 50.0

    def test_step_distribution(self):
        pk = TwoCompartmentPK()
        c1, c2 = pk.step(50.0, 0.0, 0.0, 1.0)
        assert c2 > 0.0  # Drug distributed to peripheral

    def test_step_with_infusion(self):
        pk = TwoCompartmentPK()
        c1, c2 = pk.step(0.0, 0.0, 100.0, 1.0)
        assert c1 > 0.0

    def test_non_negative_concentrations(self):
        pk = TwoCompartmentPK()
        c1, c2 = pk.step(0.001, 0.001, 0.0, 100.0)
        assert c1 >= 0.0
        assert c2 >= 0.0

    def test_distribution_half_life(self):
        pk = TwoCompartmentPK()
        t_dist = pk.distribution_half_life()
        t_elim = pk.elimination_half_life()
        assert t_dist < t_elim  # Distribution is faster than elimination
        assert t_dist > 0.0

    def test_elimination_half_life(self):
        pk = TwoCompartmentPK()
        assert pk.elimination_half_life() > 0.0
