"""Tests for baseline agents."""

import gymnasium as gym
import numpy as np
import pytest

import antibiosim  # noqa: F401

from antibiosim.agents.random_agent import RandomAgent
from antibiosim.agents.heuristic_agent import HeuristicAgent


ENV_IDS = [
    "antibiosim/AntibioticSelection-v0",
    "antibiosim/DoseOptimization-v0",
    "antibiosim/TherapySwitch-v0",
    "antibiosim/ResistanceControl-v0",
]


class TestRandomAgent:
    @pytest.mark.parametrize("env_id", ENV_IDS)
    def test_act_returns_valid_action(self, env_id):
        env = gym.make(env_id)
        agent = RandomAgent(env, seed=42)
        obs, _ = env.reset(seed=42)
        action = agent.act(obs)
        assert env.action_space.contains(action)
        env.close()

    def test_evaluate_returns_dict(self):
        env = gym.make("antibiosim/AntibioticSelection-v0")
        agent = RandomAgent(env, seed=42)
        result = agent.evaluate(n_episodes=5)
        assert "mean_reward" in result
        assert "std_reward" in result
        assert result["n_episodes"] == 5
        env.close()


class TestHeuristicAgent:
    @pytest.mark.parametrize("env_id", ENV_IDS)
    def test_act_returns_valid_action(self, env_id):
        env = gym.make(env_id)
        agent = HeuristicAgent(env_id, seed=42)
        obs, _ = env.reset(seed=42)
        action = agent.act(obs)
        assert env.action_space.contains(action)
        env.close()

    def test_selection_heuristic_returns_int(self):
        agent = HeuristicAgent("antibiosim/AntibioticSelection-v0")
        obs = np.zeros(12, dtype=np.float32)
        obs[5] = 1.0  # MIC
        obs[6] = 5.0  # severity
        action = agent.act(obs)
        assert isinstance(action, (int, np.integer))
        assert 0 <= action < 5

    def test_dose_heuristic_returns_array(self):
        agent = HeuristicAgent("antibiosim/DoseOptimization-v0")
        obs = np.array([5.0, 1e6, 1.0, 90.0, 10.0, 100.0, 3.0, 15.0], dtype=np.float32)
        action = agent.act(obs)
        assert isinstance(action, np.ndarray)
        assert 0.0 <= action[0] <= 1.0

    def test_switch_heuristic_returns_int(self):
        agent = HeuristicAgent("antibiosim/TherapySwitch-v0")
        obs = np.array([1e6, 10.0, 3.0, 2.0, 37.5, 8.0, 50.0, 0.8, 90.0, 0.0], dtype=np.float32)
        action = agent.act(obs)
        assert isinstance(action, (int, np.integer))
        assert 0 <= action < 4

    def test_resistance_heuristic_returns_array(self):
        agent = HeuristicAgent("antibiosim/ResistanceControl-v0")
        obs = np.zeros(26, dtype=np.float32)
        obs[0] = 1e6  # First bed susceptible
        obs[4] = 5.0  # First bed severity
        action = agent.act(obs)
        assert len(action) == 5
        assert all(0 <= a < 3 for a in action)

    @pytest.mark.parametrize("env_id", ENV_IDS)
    def test_heuristic_completes_episodes(self, env_id):
        """Verify heuristic agent can complete full episodes without errors."""
        env = gym.make(env_id)
        heuristic = HeuristicAgent(env_id, seed=42)
        for ep in range(5):
            obs, _ = env.reset(seed=ep + 1000)
            done = False
            steps = 0
            while not done and steps < 500:
                action = heuristic.act(obs)
                assert env.action_space.contains(action)
                obs, r, term, trunc, _ = env.step(action)
                done = term or trunc
                steps += 1
            assert done, f"Episode {ep} did not terminate"
        env.close()

    def test_unknown_env_raises(self):
        agent = HeuristicAgent("unknown/Env-v0")
        with pytest.raises(ValueError):
            agent.act(np.zeros(10))
