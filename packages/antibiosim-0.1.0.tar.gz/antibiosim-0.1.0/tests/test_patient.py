"""Tests for patient variability generator."""

import numpy as np
import pytest

from antibiosim.models.patient import PatientGenerator, PatientProfile


class TestPatientProfile:
    def test_renal_category_normal(self):
        p = PatientProfile(
            weight=70, creatinine_clearance=100, age=50,
            infection_site="blood", pathogen_mic=1.0,
            is_immunocompromised=False, albumin=3.5,
        )
        assert p.renal_category == "normal"

    def test_renal_category_mild(self):
        p = PatientProfile(
            weight=70, creatinine_clearance=70, age=50,
            infection_site="blood", pathogen_mic=1.0,
            is_immunocompromised=False, albumin=3.5,
        )
        assert p.renal_category == "mild_impairment"

    def test_renal_category_moderate(self):
        p = PatientProfile(
            weight=70, creatinine_clearance=40, age=50,
            infection_site="blood", pathogen_mic=1.0,
            is_immunocompromised=False, albumin=3.5,
        )
        assert p.renal_category == "moderate_impairment"

    def test_renal_category_severe(self):
        p = PatientProfile(
            weight=70, creatinine_clearance=20, age=50,
            infection_site="blood", pathogen_mic=1.0,
            is_immunocompromised=False, albumin=3.5,
        )
        assert p.renal_category == "severe_impairment"

    def test_adjust_clearance_normal(self):
        p = PatientProfile(
            weight=70, creatinine_clearance=120, age=50,
            infection_site="blood", pathogen_mic=1.0,
            is_immunocompromised=False, albumin=3.5,
        )
        assert p.adjust_clearance(10.0) == pytest.approx(10.0)

    def test_adjust_clearance_impaired(self):
        p = PatientProfile(
            weight=70, creatinine_clearance=60, age=50,
            infection_site="blood", pathogen_mic=1.0,
            is_immunocompromised=False, albumin=3.5,
        )
        assert p.adjust_clearance(10.0) == pytest.approx(5.0)

    def test_adjust_volume_standard(self):
        p = PatientProfile(
            weight=70, creatinine_clearance=90, age=50,
            infection_site="blood", pathogen_mic=1.0,
            is_immunocompromised=False, albumin=3.5,
        )
        assert p.adjust_volume(20.0) == pytest.approx(20.0)

    def test_adjust_volume_heavy(self):
        p = PatientProfile(
            weight=140, creatinine_clearance=90, age=50,
            infection_site="blood", pathogen_mic=1.0,
            is_immunocompromised=False, albumin=3.5,
        )
        assert p.adjust_volume(20.0) == pytest.approx(40.0)


class TestPatientGenerator:
    def test_generate_returns_profile(self):
        gen = PatientGenerator(rng=np.random.default_rng(42))
        p = gen.generate()
        assert isinstance(p, PatientProfile)

    def test_generate_reasonable_values(self):
        gen = PatientGenerator(rng=np.random.default_rng(42))
        p = gen.generate()
        assert 40 <= p.weight <= 150
        assert 18 <= p.age <= 95
        assert 10 <= p.creatinine_clearance <= 160
        assert 1.5 <= p.albumin <= 5.0
        assert p.infection_site in gen.INFECTION_SITES
        assert 0.03 <= p.pathogen_mic <= 256.0

    def test_generate_batch(self):
        gen = PatientGenerator(rng=np.random.default_rng(42))
        batch = gen.generate_batch(10)
        assert len(batch) == 10
        assert all(isinstance(p, PatientProfile) for p in batch)

    def test_generate_variability(self):
        gen = PatientGenerator(rng=np.random.default_rng(42))
        batch = gen.generate_batch(100)
        weights = [p.weight for p in batch]
        assert max(weights) - min(weights) > 20  # Some spread

    def test_reproducible_with_seed(self):
        gen1 = PatientGenerator(rng=np.random.default_rng(42))
        gen2 = PatientGenerator(rng=np.random.default_rng(42))
        p1 = gen1.generate()
        p2 = gen2.generate()
        assert p1.weight == p2.weight
        assert p1.age == p2.age
