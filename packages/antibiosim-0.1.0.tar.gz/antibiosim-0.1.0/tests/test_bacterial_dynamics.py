"""Tests for bacterial population dynamics models."""

import numpy as np
import pytest

from antibiosim.models.bacterial_dynamics import BacterialPopulation, ResistanceDynamics


class TestBacterialPopulation:
    def test_init_default(self):
        bp = BacterialPopulation()
        assert bp.growth_rate == 0.8
        assert bp.carrying_capacity == 1e9

    def test_init_invalid_growth_rate(self):
        with pytest.raises(ValueError):
            BacterialPopulation(growth_rate=-0.1)

    def test_init_invalid_capacity(self):
        with pytest.raises(ValueError):
            BacterialPopulation(carrying_capacity=0)

    def test_growth_no_drug(self):
        bp = BacterialPopulation()
        n0 = 1e5
        n1 = bp.step(n0, kill_rate=0.0, dt=1.0)
        assert n1 > n0

    def test_growth_bounded_by_capacity(self):
        bp = BacterialPopulation(carrying_capacity=1e9)
        n = bp.step(1e9, kill_rate=0.0, dt=1.0)
        assert n <= 1.1e9  # Approximately at capacity

    def test_killing_reduces_population(self):
        bp = BacterialPopulation()
        n0 = 1e6
        n1 = bp.step(n0, kill_rate=2.0, dt=1.0)
        assert n1 < n0

    def test_strong_killing_clears_population(self):
        bp = BacterialPopulation()
        n = bp.step(1e4, kill_rate=10.0, dt=10.0)
        assert n == 0.0  # Below min_viable

    def test_non_negative_population(self):
        bp = BacterialPopulation()
        n = bp.step(100.0, kill_rate=100.0, dt=10.0)
        assert n >= 0.0

    def test_zero_population_stays_zero(self):
        bp = BacterialPopulation()
        n = bp.step(0.0, kill_rate=0.0, dt=1.0)
        assert n == 0.0

    def test_doubling_time(self):
        bp = BacterialPopulation(growth_rate=0.693)
        assert bp.doubling_time() == pytest.approx(1.0, rel=0.01)

    def test_net_growth_rate_positive(self):
        bp = BacterialPopulation(growth_rate=1.0)
        assert bp.net_growth_rate(0.5) == pytest.approx(0.5)

    def test_net_growth_rate_negative(self):
        bp = BacterialPopulation(growth_rate=0.5)
        assert bp.net_growth_rate(1.0) == pytest.approx(-0.5)

    def test_substeps_improve_accuracy(self):
        bp = BacterialPopulation()
        n1 = bp.step(1e6, kill_rate=1.0, dt=10.0, n_substeps=1)
        n10 = bp.step(1e6, kill_rate=1.0, dt=10.0, n_substeps=10)
        n100 = bp.step(1e6, kill_rate=1.0, dt=10.0, n_substeps=100)
        # More substeps should converge
        assert abs(n100 - n10) < abs(n10 - n1)


class TestResistanceDynamics:
    def test_init_default(self):
        rd = ResistanceDynamics()
        assert rd.rs == 0.8

    def test_init_invalid_mutation_rate(self):
        with pytest.raises(ValueError):
            ResistanceDynamics(mutation_rate=-1e-8)

    def test_init_invalid_fitness_cost(self):
        with pytest.raises(ValueError):
            ResistanceDynamics(fitness_cost=1.0)

    def test_step_returns_tuple(self):
        rd = ResistanceDynamics()
        ns, nr = rd.step(1e6, 100.0, kill_rate_susceptible=1.0, dt=1.0)
        assert isinstance(ns, float)
        assert isinstance(nr, float)

    def test_drug_pressure_selects_resistant(self):
        rd = ResistanceDynamics(mutation_rate=1e-6)
        ns0, nr0 = 1e6, 100.0
        ns, nr = rd.step(ns0, nr0, kill_rate_susceptible=3.0, dt=24.0)
        initial_fraction = nr0 / (ns0 + nr0)
        total = ns + nr
        if total > 0:
            final_fraction = nr / total
            assert final_fraction > initial_fraction

    def test_no_drug_susceptible_dominates(self):
        rd = ResistanceDynamics(fitness_cost=0.2)
        ns, nr = rd.step(1e6, 1e6, kill_rate_susceptible=0.0, dt=24.0)
        assert ns > nr  # Susceptible grows faster due to fitness cost

    def test_mutation_creates_resistant(self):
        rd = ResistanceDynamics(mutation_rate=1e-4)
        ns, nr = rd.step(1e8, 0.0, kill_rate_susceptible=0.0, dt=1.0)
        assert nr > 0  # Mutations generate resistant bacteria

    def test_non_negative_populations(self):
        rd = ResistanceDynamics()
        ns, nr = rd.step(100.0, 50.0, kill_rate_susceptible=10.0, dt=100.0)
        assert ns >= 0.0
        assert nr >= 0.0

    def test_resistance_fraction_empty(self):
        rd = ResistanceDynamics()
        assert rd.resistance_fraction(0.0, 0.0) == 0.0

    def test_resistance_fraction_all_resistant(self):
        rd = ResistanceDynamics()
        assert rd.resistance_fraction(0.0, 1000.0) == pytest.approx(1.0)

    def test_resistance_fraction_half(self):
        rd = ResistanceDynamics()
        assert rd.resistance_fraction(500.0, 500.0) == pytest.approx(0.5)

    def test_selection_coefficient_positive_under_drug(self):
        rd = ResistanceDynamics(fitness_cost=0.1, resistance_factor=0.1)
        sc = rd.selection_coefficient(kill_rate_susceptible=3.0)
        assert sc > 0  # Drug selects for resistance

    def test_selection_coefficient_negative_no_drug(self):
        rd = ResistanceDynamics(fitness_cost=0.2, resistance_factor=0.1)
        sc = rd.selection_coefficient(kill_rate_susceptible=0.0)
        assert sc < 0  # Without drug, fitness cost disadvantages resistance
