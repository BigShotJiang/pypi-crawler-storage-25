"""Output-shaping helpers for topic modeling."""

from __future__ import annotations

from typing import Protocol

import numpy as np
import pandas as pd


class TopicModelInfoProvider(Protocol):
    """Minimal topic-model contract required for DataFrame output shaping."""

    def get_topic_info(self) -> pd.DataFrame:
        """Return BERTopic-like topic info containing at least Topic/Name columns."""


def _persist_topic_hierarchy_metadata(df: pd.DataFrame, topic_model: TopicModelInfoProvider) -> None:
    """Persist Toponymy hierarchy metadata and per-layer assignments when available."""
    cluster_layers = getattr(topic_model, "cluster_layers_", None)
    if cluster_layers is None:
        return

    primary_layer_index = getattr(topic_model, "topic_primary_layer_index_", None)
    if primary_layer_index is not None:
        df["topic_primary_layer_index"] = int(primary_layer_index)
        df["topic_layer_count"] = len(cluster_layers)

    for i, layer in enumerate(cluster_layers):
        cluster_labels = getattr(layer, "cluster_labels", None)
        if cluster_labels is not None:
            df[f"topic_layer_{i}_id"] = np.asarray(cluster_labels, dtype=int)

        topic_name_vector = getattr(layer, "topic_name_vector", None)
        if topic_name_vector is not None:
            df[f"topic_layer_{i}_label"] = topic_name_vector
            df[f"Topic_Layer_{i}"] = df[f"topic_layer_{i}_label"]


def build_topic_dataframe(
    df: pd.DataFrame,
    topic_model: TopicModelInfoProvider,
    topics: np.ndarray,
    reduced_2d: np.ndarray,
    embeddings: np.ndarray | None = None,
    topic_info: pd.DataFrame | None = None,
    *,
    reduced_5d: np.ndarray | None = None,
) -> pd.DataFrame:
    """Return a topic-enriched copy of *df*.

    Parameters
    ----------
    df : pd.DataFrame
        Input rows to enrich. Row count must match *topics* and *reduced_2d*.
    topic_model : TopicModelInfoProvider
        Fitted BERTopic/Toponymy-like model implementing ``get_topic_info()``.
        Optional label/layer hooks are used when present.
    topics : np.ndarray
        Topic assignment vector (outliers as ``-1``).
    reduced_2d : np.ndarray
        Two-dimensional projection with shape ``(n_docs, 2)``.
    embeddings : np.ndarray, optional
        Full embedding matrix; when provided, persisted to ``full_embeddings``.
    topic_info : pd.DataFrame, optional
        Optional topic info table with at least ``Topic`` and ``Name``.
        If omitted, ``topic_model.get_topic_info()`` is used.
    reduced_5d : np.ndarray, optional
        Five-dimensional projection used for clustering. When provided,
        persisted as scalar ``embedding_5d_<n>`` columns.

    Returns
    -------
    pd.DataFrame
        Copy of *df* with added columns:
        ``topic_id``, ``embedding_5d_<n>``, ``embedding_2d_x``, ``embedding_2d_y``,
        topic label columns (for example ``Name``/``Main``/``MMR``/``POS``/``KeyBERT``),
        optional ``full_embeddings``, and optional Toponymy hierarchy columns
        such as ``topic_layer_0_id``, ``topic_layer_0_label``,
        ``topic_primary_layer_index``, ``topic_layer_count``, and
        compatibility aliases ``Topic_Layer_X``. For Toponymy backends,
        ``topic_id`` and ``Name`` remain compatibility aliases for the selected
        working layer; the hierarchy columns are the canonical multi-layer output.
    """
    df = df.copy()
    df["topic_id"] = topics

    info = topic_info if topic_info is not None else topic_model.get_topic_info()
    base_cols = ["Name"]
    aspect_cols = [c for c in ("Main", "MMR", "POS", "KeyBERT") if c in info.columns]

    for col in base_cols + aspect_cols:
        if col in info.columns:
            mapping = {
                row["Topic"]: (", ".join(row[col]) if isinstance(row[col], list) else row[col])
                for _, row in info.iterrows()
            }
            df[col] = df["topic_id"].map(mapping)

    if embeddings is not None:
        df["full_embeddings"] = list(embeddings)

    topic_representations = getattr(topic_model, "topic_representations_", None)
    set_topic_labels = getattr(topic_model, "set_topic_labels", None)
    if callable(set_topic_labels) and topic_representations:
        labels = {}
        for tid, rep in topic_representations.items():
            if rep:
                labels[tid] = " | ".join(w for w, _ in rep[:3])
        labels[-1] = "Outlier Topic"
        set_topic_labels(labels)

    _persist_topic_hierarchy_metadata(df, topic_model)

    if reduced_5d is not None:
        for i in range(reduced_5d.shape[1]):
            df[f"embedding_5d_{i}"] = reduced_5d[:, i]
    df["embedding_2d_x"] = reduced_2d[:, 0]
    df["embedding_2d_y"] = reduced_2d[:, 1]

    return df


__all__ = ["build_topic_dataframe"]
