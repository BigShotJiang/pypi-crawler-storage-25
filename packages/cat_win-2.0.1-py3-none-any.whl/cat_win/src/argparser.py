"""
argparser
"""

import glob
import os
from pathlib import Path

from cat_win.src.const.argconstants import (
    ALL_ARGS,
    ARGS_CUT,
    ARGS_ECHO,
    ARGS_REPLACE
)
from cat_win.src.const.regex import (
    RE_CUT,
    RE_ENCODING,
    RE_F_IND,
    RE_M_ATCH,
    RE_Q_FIND,
    RE_Q_MATCH,
    RE_Q_REPLACE,
    RE_Q_TRUNC,
    RE_R_EPLACE,
    RE_REPLACE,
    RE_REPLACE_COMMA,
    RE_T_RUNC,
    compile_re
)
from cat_win.src.service.helper.environment import on_windows_os
from cat_win.src.web.urls import sep_valid_urls

IS_FILE, IS_DIR, IS_PATTERN = range(0, 3)


class ArgParser:
    """
    defines the ArgParser
    """
    def __init__(
            self, default_file_encoding: str = 'utf-8',
            unicode_echo: bool = True,
            unicode_find: bool = True,
            unicode_replace: bool = True,
            custom_commands: dict = None
    ) -> None:
        self.win_prefix_lit = '\\\\?\\' * on_windows_os
        self.default_file_encoding: str = default_file_encoding
        self.unicode_echo: bool = unicode_echo
        self.unicode_find = unicode_find
        self.unicode_replace = unicode_replace
        self.custom_commands = custom_commands or {}
        self._clear_values()
        self.reset_values()

    def _clear_values(self) -> None:
        """
        The here defined variables may NOT be accessed from the outside.
        """
        self._args = []
        self._unknown_args = []
        self._known_files = []
        self._unknown_files = []
        self._echo_args = []

        self._known_file_structures = []
        self._known_directories = []

    def reset_values(self) -> None:
        """
        The here defined variables may be accessed from the outside.
        """
        self.file_encoding = self.default_file_encoding
        self.file_queries = []
        self.file_queries_replacement = []
        self.file_truncate = [None, None, None]

    def get_args(self) -> list:
        """
        getter of self._args

        Returns:
        self._args (list)
            the list of args
        """
        return self._args

    def get_dirs(self) -> list:
        """
        getter of self._known_directories

        Returns:
        self._known_directories (list)
            the list of directories
        """
        return self._known_directories

    def get_arguments(self, argv: list, delete: bool = False) -> tuple:
        """
        Read all args to either a valid parameter, an invalid parameter,
        a known file, an unknown file, or an echo parameter to print out.

        Parameters:
        argv (list):
            the entire sys.argv list
        delete (bool):
            indicates if a parameter should be deleted or added. Needed for
            the repl when changing file_queries

        Returns:
        (args, unknown_args, unknown_files, echo_args) (tuple):
            contains the paramater in a sorted manner
        """
        self.gen_arguments(argv, delete)
        echo_args = ' '.join(self._echo_args)
        if self.unicode_echo:
            try:
                echo_args = echo_args.encode(self.file_encoding).decode('unicode_escape').encode('latin-1').decode(self.file_encoding)
            except UnicodeError:
                pass
        return (self._args, self._unknown_args, echo_args)

    def filter_urls(self, do_filter: bool) -> tuple:
        """
        filter the unknown files for valid urls

        Parameters:
        do_filter (bool):
            indicates if urls should be filtered

        Returns:
        (unknown_files, valid_urls) (tuple):
            contains the unknown files and the valid urls
        """
        if not do_filter:
            unknown_files = [Path(file) for file in self._unknown_files]
            return (unknown_files, [])
        unknown_files, valid_urls = sep_valid_urls(self._unknown_files)
        unknown_files = [Path(file) for file in unknown_files]
        return (unknown_files, valid_urls)

    def get_files(self, dot_files: bool = False) -> list:
        """
        Collect all files from the given patterns or directories
        provided as an argument.

        Parameters:
        dot_files (bool):
            indicates if dotfiles should be included.

        Returns:
        self._known_files (list):
            a list containing all found files
        """
        if dot_files:
            # since py3.11 iglob supports queries for hidden,
            # we want compatibility for more versions ...
            glob._ishidden = lambda _: False
        for struct_type, structure in self._known_file_structures:
            if struct_type == IS_FILE:
                self._known_files.append(structure)
                continue
            if struct_type == IS_DIR:
                self._known_directories.append(structure)
            path_gen = structure.glob(
                '*'
            ) if struct_type == IS_DIR else glob.iglob(
                structure,
                recursive=True
            )
            for _filename in path_gen:
                norm_path = Path(os.path.realpath(_filename))
                p_name = Path(_filename).name
                if not p_name:
                    p_name = norm_path.stem
                lit_path  = Path(f"{self.win_prefix_lit}{norm_path.parent}/{p_name}")
                p_equal = lit_path.stem == norm_path.stem
                norm_exists, lit_exists = False, False
                try:
                    if norm_path.is_file():
                        norm_exists = True
                except OSError:
                    pass
                try:
                    if lit_path.is_file():
                        lit_exists = True
                except OSError:
                    pass
                path_name = norm_path
                if not norm_exists or (lit_exists and not p_equal):
                    path_name = lit_path
                if (norm_exists or lit_exists) and (dot_files or not path_name.name.startswith('.')):
                    self._known_files.append(path_name)
                    continue
                norm_exists, lit_exists = False, False
                try:
                    if norm_path.is_dir():
                        norm_exists = True
                except OSError:
                    pass
                try:
                    if lit_path.is_dir():
                        lit_exists = True
                except OSError:
                    pass
                path_name = norm_path
                if not norm_exists or (lit_exists and not p_equal):
                    path_name = lit_path
                if (norm_exists or lit_exists) and (dot_files or not path_name.name.startswith('.')):
                    self._known_directories.append(path_name)

        return self._known_files

    def _add_path_struct(self, param: str) -> bool:
        norm_path = Path(os.path.realpath(param))
        p_name = Path(param).name
        if not p_name:
            p_name = norm_path.stem
        lit_path  = Path(f"{self.win_prefix_lit}{norm_path.parent}/{p_name}")
        p_equal = lit_path.stem == norm_path.stem
        norm_exists, lit_exists = False, False
        try:
            if norm_path.is_file():
                norm_exists = True
        except OSError:
            pass
        try:
            if lit_path.is_file():
                lit_exists = True
        except OSError:
            pass
        if norm_exists and not (lit_exists and not p_equal):
            self._known_file_structures.append((IS_FILE, norm_path))
        elif lit_exists:
            self._known_file_structures.append((IS_FILE, lit_path))

        is_struct = norm_exists or lit_exists
        norm_exists, lit_exists = False, False
        try:
            if norm_path.is_dir():
                norm_exists = True
        except OSError:
            pass
        try:
            if lit_path.is_dir():
                lit_exists = True
        except OSError:
            pass
        if norm_exists and not (lit_exists and not p_equal):
            self._known_file_structures.append((IS_DIR, norm_path))
        elif lit_exists:
            self._known_file_structures.append((IS_DIR, lit_path))
        is_struct |= norm_exists or lit_exists

        if param[0] != '-' and any(c in param for c in '*?['):
            # matches file-patterns, not directories (e.g. *.txt)
            self._known_file_structures.append((IS_PATTERN, param))
            is_struct = True

        return is_struct

    def _expand_user(self, param: str) -> str:
        provided_path = Path(param)
        if provided_path.parts and provided_path.parts[0] == '~':
            if (
                not os.path.exists('~') or
                os.path.isfile('~') and len(provided_path.parts) > 1
            ):
                param = os.path.expanduser(param)
        return param

    def _add_argument(self, param: str, delete: bool = False) -> bool:
        """
        sorts an argument to either list option, by appending to it.

        Parameters:
        param (str):
            the current parameter
        delete (bool):
            indicates if a parameter should be deleted or added. Needed for
            the repl when changing file_queries

        Returns:
        (bool):
            True if -E has been called, meaning every following parameter
            should simply be printed to stdout.
        """
        # 'enc' + ('=' or ':') + file_encoding
        if RE_ENCODING.match(param):
            self.file_encoding = param[4:]
            return False
        # 'match' + ('=' or ':') + file_queries pattern
        if RE_Q_MATCH.match(param) or RE_M_ATCH.match(param):
            p_length = 6 if RE_Q_MATCH.match(param) else 2
            query_element = (compile_re(param[p_length:], param[:p_length].isupper()),
                             param[:p_length].isupper())
            if delete:
                if query_element in self.file_queries:
                    self.file_queries.reverse()
                    idx = len(self.file_queries) - 1 - self.file_queries.index(query_element)
                    self.file_queries.reverse()
                    self.file_queries.pop(idx)
                    if len(self.file_queries_replacement) > idx:
                        self.file_queries_replacement.pop(idx)
                return False
            self.file_queries.append(query_element)
            return False
        # 'find' + ('=' or ':') + file_queries literal
        if RE_Q_FIND.match(param) or RE_F_IND.match(param):
            p_length = 5 if RE_Q_FIND.match(param) else 2
            query = param[p_length:]
            try:
                if self.unicode_find:
                    query = query.encode().decode('unicode_escape').encode('latin-1').decode()
            except UnicodeError:
                pass
            query_element = (query, param[:p_length].isupper())
            if delete:
                if query_element in self.file_queries:
                    self.file_queries.reverse()
                    idx = len(self.file_queries) - 1 - self.file_queries.index(query_element)
                    self.file_queries.reverse()
                    self.file_queries.pop(idx)
                    if len(self.file_queries_replacement) > idx:
                        self.file_queries_replacement.pop(idx)
                return False
            self.file_queries.append(query_element)
            return False
        # 'replace + ('=' or ':') + file_queries_replacement
        if RE_Q_REPLACE.match(param) or RE_R_EPLACE.match(param):
            p_length = 8 if RE_Q_REPLACE.match(param) else 2
            query = param[p_length:]
            try:
                if self.unicode_replace:
                    query = query.encode().decode('unicode_escape').encode('latin-1').decode()
            except UnicodeError:
                pass
            if delete:
                if query in self.file_queries_replacement:
                    idx_s = self.file_queries_replacement.index(query)
                    self.file_queries_replacement.reverse()
                    idx_e = self.file_queries_replacement.index(query)
                    self.file_queries_replacement.reverse()
                    if idx_e == 0:
                        self.file_queries_replacement = self.file_queries_replacement[:idx_s]
                    else:
                        idx_e = len(self.file_queries_replacement) - idx_e
                        self.file_queries_replacement = self.file_queries_replacement[:idx_s] + [self.file_queries_replacement[idx_e]] * (idx_e - idx_s) + self.file_queries_replacement[idx_e:]
                return False
            self.file_queries_replacement.extend(
                [query] * (len(self.file_queries) - len(self.file_queries_replacement))
            )
            return False
        # 'trunc' + ('='/':') + file_truncate[0] +':'+ file_truncate[1] [+ ':' + file_truncate[2]]
        if RE_Q_TRUNC.match(param) or RE_T_RUNC.match(param):
            p_length = 6 if RE_Q_TRUNC.match(param) else 2
            for i, p_split in enumerate(param[p_length:].split(':')):
                try:
                    self.file_truncate[i] = int(eval(p_split, {"__builtins__": {}}))
                except (SyntaxError, NameError, ValueError, ArithmeticError):
                    self.file_truncate[i] = None
            return False
        # '[' + ARGS_CUT + ']'
        if RE_CUT.match(param):
            slice_evals = [None] * 3
            for i, p_split in enumerate(param[1:-1].split(':')):
                try:
                    slice_evals[i] = int(eval(p_split, {"__builtins__": {}}))
                except (SyntaxError, NameError, ValueError, ArithmeticError):
                    pass
            self._args.append((ARGS_CUT, tuple(slice_evals)))
            return False
        # '[' + ARGS_REPLACE_THIS + ',' + ARGS_REPLACE_WITH + ']' (escape chars with '\')
        if RE_REPLACE.match(param):
            re_match = RE_REPLACE.match(param)
            re_this = RE_REPLACE_COMMA.sub(r"\1,", re_match.group(1))
            re_with = RE_REPLACE_COMMA.sub(r"\1,", re_match.group(2))
            try:
                if self.unicode_replace:
                    re_this = re_this.encode().decode('unicode_escape').encode('latin-1').decode()
                    re_with = re_with.encode().decode('unicode_escape').encode('latin-1').decode()
            except UnicodeError:
                pass
            self._args.append((ARGS_REPLACE, (re_this, re_with)))
            return False

        # custom parameters
        for arg in self.custom_commands.keys():
            if param == arg:
                custom_args = self.custom_commands[arg]
                for i, c_arg in enumerate(custom_args):
                    if self._add_argument(c_arg, delete):
                        if i < len(custom_args) - 1:
                            self._echo_args.extend(custom_args[i+1:])
                        return True
                return False
        # default parameters
        for arg in ALL_ARGS:
            if arg.arg_id < 0:
                continue
            if param in (arg.short_form, arg.long_form):
                self._args.append((arg.arg_id, param))
                return arg.arg_id == ARGS_ECHO

        param = self._expand_user(param)
        if self._add_path_struct(param):
            return False

        if len(param) > 2 and param[0] == '-' != param[1]:
            for i in range(1, len(param)):
                if self._add_argument('-' + param[i], delete):
                    if i < len(param) - 1:
                        self._echo_args.append(param[i+1:])
                    return True
        # out of bound is not possible, in case of length 0 param, possible_path would have
        # become the working-path and therefor handled the param as a directory
        elif param[0] != '-':
            self._unknown_files.append(param)
        else:
            self._unknown_args.append(param)
        return False


    def gen_arguments(self, argv: list, delete: bool = False) -> None:
        """
        Read all args to either a valid parameter, an invalid parameter,
        a known file, an unknown file, or an echo parameter to print out.

        Parameters:
        argv (list):
            the entire sys.argv list
        delete (bool):
            indicates if a parameter should be deleted or added. Needed for
            the repl when changing file_queries
        """
        input_args = argv[1:]
        self._clear_values()

        echo_call = False
        for arg in input_args:
            if echo_call:
                self._echo_args.append(arg)
                continue
            echo_call = self._add_argument(arg, delete)
