from unittest.mock import patch, MagicMock
from unittest import TestCase

from cat_win.src.service.helper.tmpfilehelper import TmpFileHelper
# import sys
# sys.path.append('../cat_win')

mm = MagicMock()
mock_file = MagicMock()
mock_file.name = "magic"
mock_file.__enter__ = MagicMock(return_value=mock_file)
mm.return_value = mock_file

@patch('tempfile.NamedTemporaryFile', mm)
class TestTmpFileHelper(TestCase):
    maxDiff = None

    def test_tmpfilehelper(self):
        tfh = TmpFileHelper()
        self.assertCountEqual(tfh.get_generated_temp_files(), [])
        tfh.generate_temp_file_name()
        tfh.generate_temp_file_name()
        self.assertEqual(len(tfh.tmp_files), 2)
        tfh.generate_temp_file_name()
        self.assertEqual(len(tfh.tmp_files), 3)
        self.assertCountEqual(tfh.get_generated_temp_files(), tfh.tmp_files)
