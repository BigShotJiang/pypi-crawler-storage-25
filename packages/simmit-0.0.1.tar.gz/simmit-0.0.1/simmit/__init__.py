raise NotImplementedError("simmit SDK not implemented — use the HTTP API: https://github.com/void-platforms/simmit")
