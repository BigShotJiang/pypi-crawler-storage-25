# simmit (Python)

WIP — see the [root README](../../README.md).
