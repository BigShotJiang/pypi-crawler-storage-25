"""Entry point for DJ HUD.

Usage:
    djhud              # installed via pip
    python -m djhud    # run as module
"""

import sys


def main():
    """Launch DJ HUD application."""
    from djhud.app import run_app
    run_app()


if __name__ == "__main__":
    main()
