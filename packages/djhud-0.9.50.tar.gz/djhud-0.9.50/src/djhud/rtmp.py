"""RTMP publisher — pipe composited HUD frames to an ffmpeg subprocess → RTMP.

Architecture:

    HUDApp.render_loop()
        │  PIL.Image (BGR/RGB composite)
        ▼
    RtmpPublisher.push_frame(img)
        │  convert to raw BGR bytes
        ▼
    bounded frame queue (max 2 frames deep — drop-on-full)
        ▼
    writer thread
        │  writes raw frames to ffmpeg stdin
        ▼
    ffmpeg subprocess
        │  libx264 zerolatency, CBR, flv wrapper
        ▼
    RTMP push to MediaMTX (e.g. rtmp://10.66.66.1:1935/djhud)

Why a queue + writer thread instead of direct writes in push_frame:

  push_frame() is called from the tkinter render loop. If ffmpeg's stdin
  blocks (e.g. encoder stall, slow network), a direct write blocks the GUI.
  The queue + thread means the main loop can always hand off a frame in
  ~microseconds; overflow drops old frames instead of stalling the UI.

Why auto-respawn ffmpeg:

  VPN hiccups, MediaMTX restart, or transient network issues kill the
  ffmpeg process. Auto-respawn with exponential backoff keeps the stream
  alive without user intervention. User toggle-off forces a clean shutdown.

No PyPI runtime dependency — just uses `ffmpeg` from PATH.
"""

import os
import queue
import shutil
import subprocess
import threading
import time
from typing import Optional

try:
    from PIL import Image
except ImportError:
    Image = None


# ─── Constants ────────────────────────────────────────────────────────────────

# Queue depth. 2 = one in-flight frame + one queued. Anything older is stale
# for low-latency streaming — drop it.
FRAME_QUEUE_DEPTH = 2

# Backoff bounds (seconds) for ffmpeg auto-respawn.
BACKOFF_INITIAL = 1.0
BACKOFF_MAX = 30.0
BACKOFF_RESET_AFTER = 10.0  # if alive this long, reset backoff

# If ffmpeg dies in under this many seconds, count it as a fast failure.
# After FAST_FAIL_LIMIT consecutive fast failures, give up — fundamental
# config problem (encoder rejected params, binary missing, etc.). Looping
# is pointless and hides the real error.
FAST_FAIL_THRESHOLD_SECS = 1.5
FAST_FAIL_LIMIT = 3

# Default encoder params — match the handover doc's validated OBS settings.
DEFAULT_BITRATE_KBPS = 6000
DEFAULT_FPS = 30
DEFAULT_KEYFRAME_SECS = 1


def ffmpeg_available() -> bool:
    """Check if ffmpeg is on PATH."""
    return shutil.which("ffmpeg") is not None


# ═══════════════════════════════════════════════════════════════════════════════
# RtmpPublisher — stdin-piped ffmpeg → RTMP
# ═══════════════════════════════════════════════════════════════════════════════

class RtmpPublisher:
    """Publish DJ HUD composited frames to an RTMP endpoint via ffmpeg.

    Public API mirrors VDONinjaServer for symmetry in the app:
        start()           — spawn ffmpeg and writer thread
        stop()            — shut down cleanly
        push_frame(img)   — hand a PIL Image to the writer (non-blocking)
        is_running        — bool property (user toggle state, not process state)
        is_connected      — bool property (ffmpeg process alive right now)
        dropped_frames    — int property
        sent_frames       — int property
        last_error        — str property (most recent error message, or "")
        status            — str property (human-readable status line)
    """

    def __init__(
        self,
        url: str,
        width: int,
        height: int,
        fps: int = DEFAULT_FPS,
        bitrate_kbps: int = DEFAULT_BITRATE_KBPS,
        keyframe_secs: int = DEFAULT_KEYFRAME_SECS,
        preset: str = "veryfast",
    ):
        if not url:
            raise ValueError("RTMP URL is required")
        self.url = url
        # libx264 with yuv420p requires EVEN dimensions. Odd width or height
        # makes the encoder refuse to open with cryptic "Invalid argument"
        # errors. Force-even via bit clear, with a 16-pixel minimum.
        # The compose loop's resize() handles the small discrepancy
        # transparently when frames don't quite match self.width/self.height.
        self.width = max(16, int(width)) & ~1
        self.height = max(16, int(height)) & ~1
        self.fps = max(1, int(fps))
        self.bitrate_kbps = max(100, int(bitrate_kbps))
        self.keyframe_secs = max(1, int(keyframe_secs))
        self.preset = preset

        self._running = False            # user-toggle state
        self._proc: Optional[subprocess.Popen] = None
        self._proc_started_at: float = 0.0

        self._queue: queue.Queue = queue.Queue(maxsize=FRAME_QUEUE_DEPTH)
        self._writer_thread: Optional[threading.Thread] = None
        self._supervisor_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

        # stats
        self._dropped = 0
        self._sent = 0
        self._last_error = ""
        self._backoff = BACKOFF_INITIAL

        # consecutive fast-failure tracking — if ffmpeg keeps dying in <1s
        # we have a fundamental config problem, not a transient network issue.
        # Stop respawning after FAST_FAIL_LIMIT to surface the error instead
        # of looping silently forever.
        self._consecutive_fast_failures = 0
        self._gave_up = False

        # sentinel used to unblock the writer thread on shutdown
        self._SHUTDOWN = object()

    # ── Lifecycle ────────────────────────────────────────────────────

    def start(self):
        """Start publishing. Idempotent."""
        if self._running:
            return
        if Image is None:
            raise ImportError("Pillow is required for RTMP publishing")
        if not ffmpeg_available():
            raise RuntimeError(
                "ffmpeg not found on PATH. Install from https://ffmpeg.org/ "
                "and ensure it's in your system PATH."
            )

        self._running = True
        self._stop_event.clear()
        self._dropped = 0
        self._sent = 0
        self._last_error = ""
        self._backoff = BACKOFF_INITIAL

        # Writer thread: drains queue → writes to ffmpeg stdin.
        self._writer_thread = threading.Thread(
            target=self._writer_loop, name="rtmp-writer", daemon=True,
        )
        self._writer_thread.start()

        # Supervisor thread: manages ffmpeg lifecycle + respawn.
        self._supervisor_thread = threading.Thread(
            target=self._supervisor_loop, name="rtmp-supervisor", daemon=True,
        )
        self._supervisor_thread.start()

    def stop(self):
        """Shut down cleanly. Idempotent."""
        if not self._running:
            return
        self._running = False
        self._stop_event.set()

        # Wake the writer so it sees the stop event.
        try:
            self._queue.put_nowait(self._SHUTDOWN)
        except queue.Full:
            # If full, drain one and retry.
            try:
                self._queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self._queue.put_nowait(self._SHUTDOWN)
            except queue.Full:
                pass

        # Kill ffmpeg. The writer loop will handle the broken pipe.
        self._terminate_proc()

        if self._writer_thread:
            self._writer_thread.join(timeout=3.0)
            self._writer_thread = None
        if self._supervisor_thread:
            self._supervisor_thread.join(timeout=3.0)
            self._supervisor_thread = None

    # ── Frame push ───────────────────────────────────────────────────

    def push_frame(self, pil_image):
        """Hand a PIL Image to the writer. Non-blocking.

        If the queue is full, the oldest frame is dropped in favor of this
        one — fresh frames matter more than stale ones for low-latency.
        """
        if not self._running:
            return
        if pil_image is None or Image is None:
            return

        # Resize/convert as needed so the raw bytes match ffmpeg's expected
        # -s and -pix_fmt. We feed ffmpeg bgr24, which is Pillow's "BGR".
        # PIL doesn't have a "BGR" mode natively, so we use RGB and let
        # ffmpeg handle it — see _encode_frame below.
        if pil_image.width != self.width or pil_image.height != self.height:
            try:
                pil_image = pil_image.resize(
                    (self.width, self.height), Image.BILINEAR
                )
            except Exception as e:
                self._last_error = f"resize failed: {e}"
                return

        try:
            raw = self._encode_frame(pil_image)
        except Exception as e:
            self._last_error = f"encode failed: {e}"
            return

        # Drop-on-full: try once, if full drop oldest and retry.
        try:
            self._queue.put_nowait(raw)
        except queue.Full:
            try:
                self._queue.get_nowait()
                self._dropped += 1
            except queue.Empty:
                pass
            try:
                self._queue.put_nowait(raw)
            except queue.Full:
                self._dropped += 1

    @staticmethod
    def _encode_frame(pil_image) -> bytes:
        """PIL Image → raw BGR bytes matching ffmpeg's bgr24 input format."""
        if pil_image.mode != "RGB":
            pil_image = pil_image.convert("RGB")
        # RGB → BGR by swapping channels via tobytes reorder.
        # Fastest way: split, merge, tobytes.
        r, g, b = pil_image.split()
        bgr = Image.merge("RGB", (b, g, r))
        return bgr.tobytes()

    # ── ffmpeg subprocess management ─────────────────────────────────

    def _build_ffmpeg_cmd(self) -> list:
        """Build the ffmpeg argv for raw-BGR → x264 → FLV → RTMP."""
        gop = max(1, self.fps * self.keyframe_secs)
        return [
            "ffmpeg",
            "-hide_banner", "-loglevel", "warning",
            "-y",
            # input: raw BGR from stdin
            "-f", "rawvideo",
            "-pix_fmt", "bgr24",
            "-s", f"{self.width}x{self.height}",
            "-r", str(self.fps),
            "-i", "-",
            # video encode
            "-c:v", "libx264",
            "-preset", self.preset,
            "-tune", "zerolatency",
            "-profile:v", "main",
            "-pix_fmt", "yuv420p",
            "-b:v", f"{self.bitrate_kbps}k",
            "-maxrate", f"{self.bitrate_kbps}k",
            "-bufsize", f"{self.bitrate_kbps // 2}k",
            "-g", str(gop),
            "-keyint_min", str(gop),
            "-sc_threshold", "0",
            # no audio
            "-an",
            # output
            "-f", "flv",
            self.url,
        ]

    def _spawn_proc(self) -> bool:
        """Launch ffmpeg. Returns True on success."""
        cmd = self._build_ffmpeg_cmd()
        try:
            # Suppress the console window on Windows when no_window is set;
            # inherit parents' otherwise. stderr goes to a pipe so we can
            # capture errors for display.
            creationflags = 0
            if os.name == "nt":
                # CREATE_NO_WINDOW — hides the console popup for GUI apps.
                creationflags = 0x08000000
            self._proc = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                bufsize=0,
                creationflags=creationflags,
            )
            self._proc_started_at = time.monotonic()
            # Drain stderr in a daemon thread so it doesn't fill the pipe.
            t = threading.Thread(
                target=self._drain_stderr, args=(self._proc,),
                name="rtmp-stderr", daemon=True,
            )
            t.start()
            print(f"[RTMP] ffmpeg started (pid={self._proc.pid}) → {self._sanitize_url()}")
            return True
        except Exception as e:
            self._last_error = f"ffmpeg spawn failed: {e}"
            self._proc = None
            return False

    def _drain_stderr(self, proc):
        """Read ffmpeg stderr so the pipe never fills. Surface last line as error."""
        try:
            for raw_line in iter(proc.stderr.readline, b""):
                line = raw_line.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                # ffmpeg prints a lot — only capture things that look like errors.
                lower = line.lower()
                if any(k in lower for k in ("error", "failed", "unable", "invalid",
                                            "connection", "refused", "timed out")):
                    self._last_error = line[:200]
                    print(f"[RTMP] ffmpeg: {line}")
        except Exception:
            pass

    def _terminate_proc(self):
        """Kill ffmpeg cleanly (SIGTERM-ish, then SIGKILL)."""
        if self._proc is None:
            return
        try:
            if self._proc.stdin and not self._proc.stdin.closed:
                try:
                    self._proc.stdin.close()
                except Exception:
                    pass
            try:
                self._proc.terminate()
                self._proc.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                self._proc.kill()
                self._proc.wait(timeout=1.0)
            except Exception:
                pass
        finally:
            self._proc = None

    def _sanitize_url(self) -> str:
        """Return URL with password stripped for logging."""
        if "pass=" not in self.url:
            return self.url
        pre, _, post = self.url.partition("pass=")
        # Mask everything up to next & or end.
        idx = post.find("&")
        if idx < 0:
            return pre + "pass=***"
        return pre + "pass=***" + post[idx:]

    # ── Supervisor: keeps ffmpeg alive with backoff ──────────────────

    def _supervisor_loop(self):
        """Spawn ffmpeg, watch for exit, respawn with backoff.

        Gives up after FAST_FAIL_LIMIT consecutive fast failures to surface
        config errors (e.g. odd canvas dimensions, missing codec) rather
        than spinning forever.
        """
        while not self._stop_event.is_set():
            if self._gave_up:
                # Fundamental error already detected. Wait quietly for stop().
                self._stop_event.wait(timeout=0.5)
                continue

            if not self._spawn_proc():
                # Spawn failed entirely — back off and retry.
                self._consecutive_fast_failures += 1
                if self._consecutive_fast_failures >= FAST_FAIL_LIMIT:
                    self._mark_gave_up("ffmpeg cannot be started")
                    continue
                self._sleep_backoff()
                continue

            # Wait for proc to exit (or for stop_event).
            while not self._stop_event.is_set():
                proc = self._proc
                if proc is None:
                    break
                rc = proc.poll()
                if rc is not None:
                    alive_for = time.monotonic() - self._proc_started_at
                    print(f"[RTMP] ffmpeg exited rc={rc} after {alive_for:.1f}s")
                    if alive_for >= BACKOFF_RESET_AFTER:
                        # Long-lived — reset backoff and fast-fail counter.
                        self._backoff = BACKOFF_INITIAL
                        self._consecutive_fast_failures = 0
                    elif alive_for < FAST_FAIL_THRESHOLD_SECS:
                        # Died too quickly — likely a config error, not a
                        # transient network issue. Count it.
                        self._consecutive_fast_failures += 1
                    else:
                        # Mid-range exit: probably a network glitch, reset
                        # the fast-fail counter so we don't accidentally
                        # give up on intermittent issues.
                        self._consecutive_fast_failures = 0
                    self._proc = None
                    break
                time.sleep(0.2)

            if self._stop_event.is_set():
                break

            # Check if we've hit the fast-failure limit before respawning.
            if self._consecutive_fast_failures >= FAST_FAIL_LIMIT:
                self._mark_gave_up(
                    "ffmpeg keeps dying immediately — check canvas dimensions "
                    "(must be even and ≥16) and the URL"
                )
                continue

            # Respawn with backoff.
            self._sleep_backoff()
            self._backoff = min(self._backoff * 2, BACKOFF_MAX)

    def _mark_gave_up(self, reason: str):
        """Stop respawning. Surfaces a clear error to the UI status line."""
        self._gave_up = True
        # If ffmpeg already wrote a more specific error to last_error,
        # preserve that and append our higher-level summary.
        if self._last_error:
            self._last_error = f"{reason}. Last ffmpeg error: {self._last_error}"
        else:
            self._last_error = reason
        print(f"[RTMP] giving up — {self._last_error}")

    def _sleep_backoff(self):
        """Wait for self._backoff seconds, abortable by stop_event."""
        end = time.monotonic() + self._backoff
        while not self._stop_event.is_set() and time.monotonic() < end:
            self._stop_event.wait(timeout=0.2)

    # ── Writer: drains queue → ffmpeg stdin ──────────────────────────

    def _writer_loop(self):
        """Pull frames from queue and write them to ffmpeg stdin."""
        while not self._stop_event.is_set():
            try:
                item = self._queue.get(timeout=0.5)
            except queue.Empty:
                continue
            if item is self._SHUTDOWN:
                break

            proc = self._proc
            if proc is None or proc.stdin is None or proc.poll() is not None:
                # ffmpeg not ready — drop this frame, supervisor will respawn.
                self._dropped += 1
                continue

            try:
                proc.stdin.write(item)
                self._sent += 1
            except (BrokenPipeError, OSError, ValueError) as e:
                # ValueError: stdin was closed between the poll() and the
                # write() — typically by stop() racing with this thread.
                # BrokenPipeError/OSError: ffmpeg died mid-write. All three
                # are "pipe gone" cases; supervisor handles respawn.
                self._dropped += 1
                if not self._stop_event.is_set():
                    self._last_error = f"pipe write failed: {e}"

    # ── Properties ───────────────────────────────────────────────────

    @property
    def is_running(self) -> bool:
        """User has toggled this on."""
        return self._running

    @property
    def is_connected(self) -> bool:
        """ffmpeg process is currently alive."""
        p = self._proc
        return p is not None and p.poll() is None

    @property
    def dropped_frames(self) -> int:
        return self._dropped

    @property
    def sent_frames(self) -> int:
        return self._sent

    @property
    def last_error(self) -> str:
        return self._last_error

    @property
    def status(self) -> str:
        """Human-readable status line for UI."""
        if not self._running:
            return "Not running"
        if self._gave_up:
            return f"Stopped — {self._last_error}\nClick Stop, fix the issue, then Start publishing again."
        if self.is_connected:
            base = f"Publishing → {self._strip_query(self.url)}"
            stats = f"{self._sent} sent, {self._dropped} dropped"
            if self._last_error:
                return f"{base}\n{stats} — last error: {self._last_error}"
            return f"{base}\n{stats}"
        else:
            if self._last_error:
                return f"Reconnecting… last error: {self._last_error}"
            return "Reconnecting…"

    @staticmethod
    def _strip_query(url: str) -> str:
        """Return URL without query string (hides credentials for display)."""
        q = url.find("?")
        return url[:q] if q >= 0 else url


# ─── URL builder ──────────────────────────────────────────────────────────────

def build_rtmp_url(base_url: str, user: str = "", password: str = "") -> str:
    """Build an RTMP URL with MediaMTX-style auth query parameters.

    Example:
        build_rtmp_url("rtmp://10.66.66.1:1935/djhud", "djhud", "secret")
        → "rtmp://10.66.66.1:1935/djhud?user=djhud&pass=secret"

    If base_url already has a query string, credentials are appended.
    If user/password are empty, base_url is returned unchanged.
    """
    base_url = base_url.strip()
    if not base_url:
        return base_url
    if not user and not password:
        return base_url

    sep = "&" if "?" in base_url else "?"
    parts = []
    if user:
        parts.append(f"user={user}")
    if password:
        parts.append(f"pass={password}")
    return f"{base_url}{sep}{'&'.join(parts)}"
