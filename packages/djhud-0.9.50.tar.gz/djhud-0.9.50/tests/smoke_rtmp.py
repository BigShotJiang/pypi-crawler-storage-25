"""Smoke test for rtmp.RtmpPublisher.

Can't reach a real RTMP endpoint from the sandbox, so we use a local
MP4 file sink by monkey-patching _build_ffmpeg_cmd to swap the output.
Everything upstream of the output URL is exactly what production uses:
same spawn, same stdin pipe, same writer thread, same queue dynamics.
"""

import os
import sys
import time
import subprocess

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from PIL import Image, ImageDraw
from djhud.rtmp import RtmpPublisher, ffmpeg_available, build_rtmp_url


def make_frame(width, height, frame_num):
    img = Image.new("RGB", (width, height), (frame_num * 4 % 256, 20, 60))
    d = ImageDraw.Draw(img)
    d.rectangle((10, 10, 200, 70), fill=(0, 200, 100))
    d.text((20, 25), f"frame {frame_num}", fill=(255, 255, 255))
    return img


def test_build_rtmp_url():
    # no creds
    assert build_rtmp_url("rtmp://10.66.66.1:1935/djhud") == "rtmp://10.66.66.1:1935/djhud"
    # with creds
    u = build_rtmp_url("rtmp://10.66.66.1:1935/djhud", "djhud", "secret")
    assert u == "rtmp://10.66.66.1:1935/djhud?user=djhud&pass=secret", u
    # with existing query string
    u = build_rtmp_url("rtmp://host/path?foo=bar", "djhud", "x")
    assert u == "rtmp://host/path?foo=bar&user=djhud&pass=x", u
    # empty base
    assert build_rtmp_url("", "u", "p") == ""
    print("  build_rtmp_url: OK")


def test_url_sanitization():
    """Passwords must never appear in logs or the status string."""
    pub = RtmpPublisher(
        url="rtmp://host:1935/path?user=u&pass=SECRET123",
        width=320, height=80, fps=30,
    )
    sanitized = pub._sanitize_url()
    assert "SECRET123" not in sanitized, sanitized
    assert "pass=***" in sanitized, sanitized
    # status property strips the query entirely
    pub._running = True
    pub._proc = None  # force disconnected path
    status = pub.status
    assert "SECRET123" not in status, status
    # pass= mid-string (with trailing &) also redacted
    pub2 = RtmpPublisher(
        url="rtmp://h/p?pass=MYPASS&foo=bar", width=320, height=80, fps=30,
    )
    s2 = pub2._sanitize_url()
    assert "MYPASS" not in s2, s2
    assert "foo=bar" in s2, s2  # preserve other params
    print("  url_sanitization: OK")


def test_ffmpeg_available():
    assert ffmpeg_available(), "ffmpeg must be on PATH for this test"
    print("  ffmpeg_available: OK")


def test_publisher_pipeline(tmp_output="/tmp/djhud_rtmp_smoke.mp4"):
    """Run the full publisher against a local file output.

    We monkey-patch _build_ffmpeg_cmd to produce an MP4 file instead of
    pushing RTMP, so we can verify the pipeline without a real server.
    """
    try:
        os.unlink(tmp_output)
    except FileNotFoundError:
        pass

    W, H, FPS = 640, 80, 30
    pub = RtmpPublisher(
        url="rtmp://127.0.0.1:1935/test",   # sentinel; monkey-patched
        width=W, height=H, fps=FPS,
        bitrate_kbps=2000, keyframe_secs=1,
    )

    # Monkey-patch: produce MP4 instead of FLV+RTMP.
    original_build = pub._build_ffmpeg_cmd
    def patched_cmd():
        cmd = original_build()
        # replace the last two tokens (-f flv URL) with (-f mp4 file)
        assert cmd[-2] == "flv"
        cmd = cmd[:-3] + ["-f", "mp4", tmp_output]
        return cmd
    pub._build_ffmpeg_cmd = patched_cmd

    print("  starting publisher...")
    pub.start()
    time.sleep(0.8)  # let ffmpeg spin up

    assert pub.is_running, "is_running should be True after start()"
    assert pub.is_connected, f"ffmpeg should be alive. Last error: {pub.last_error}"
    print(f"  is_running={pub.is_running} is_connected={pub.is_connected}")

    # Push frames for ~2 seconds at 30fps
    n_target = FPS * 2
    for i in range(n_target):
        img = make_frame(W, H, i)
        pub.push_frame(img)
        time.sleep(1.0 / FPS)

    print(f"  pushed {n_target} frames, queued; waiting for drain...")
    time.sleep(1.0)

    print(f"  sent={pub.sent_frames} dropped={pub.dropped_frames}")
    assert pub.sent_frames > FPS, \
        f"expected >{FPS} frames sent, got {pub.sent_frames}"

    pub.stop()
    assert not pub.is_running, "is_running should be False after stop()"
    assert not pub.is_connected, "ffmpeg should be dead after stop()"

    # Verify file was written and is valid MP4
    assert os.path.exists(tmp_output), f"output file missing: {tmp_output}"
    size = os.path.getsize(tmp_output)
    assert size > 1000, f"output file too small: {size} bytes"
    print(f"  output file: {size} bytes")

    # Use ffprobe to check duration + stream validity
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_streams", "-show_format",
         "-print_format", "default", tmp_output],
        capture_output=True, text=True,
    )
    print(f"  ffprobe rc={probe.returncode}")
    if probe.returncode != 0:
        print(f"  ffprobe stderr: {probe.stderr}")
    assert probe.returncode == 0, "ffprobe says the file is broken"
    # Should contain a video stream
    assert "codec_name=h264" in probe.stdout.lower() or "codec_name=h264" in probe.stdout, \
        f"no h264 stream found. Output:\n{probe.stdout}"

    # Parse duration
    for line in probe.stdout.splitlines():
        if line.startswith("duration="):
            dur = float(line.split("=", 1)[1])
            assert dur > 1.0, f"duration too short: {dur}s"
            print(f"  duration: {dur:.2f}s")
            break

    print("  publisher_pipeline: OK")


def test_stop_during_push():
    """Verify stop() is clean even when frames are actively being pushed."""
    pub = RtmpPublisher(
        url="rtmp://127.0.0.1:1935/test", width=320, height=80, fps=30,
    )
    # Point ffmpeg at /dev/null so it can't actually fail on output
    original_build = pub._build_ffmpeg_cmd
    def patched():
        cmd = original_build()
        assert cmd[-2] == "flv"
        cmd = cmd[:-3] + ["-f", "null", "-"]
        return cmd
    pub._build_ffmpeg_cmd = patched

    pub.start()
    time.sleep(0.5)
    # Push frames fast
    for i in range(10):
        pub.push_frame(make_frame(320, 80, i))
    pub.stop()
    assert not pub.is_running
    assert not pub.is_connected
    print("  stop_during_push: OK")


def test_no_ffmpeg_path_error():
    """Verify a clean error if ffmpeg isn't on PATH (we simulate by bad invocation)."""
    pub = RtmpPublisher(
        url="rtmp://127.0.0.1/test", width=320, height=80, fps=30,
    )
    # Force the command to reference a nonexistent binary
    pub._build_ffmpeg_cmd = lambda: ["nonexistent_ffmpeg_binary_xyz",
                                      "-f", "null", "-"]
    pub.start()
    time.sleep(2.5)  # Let supervisor try + back off
    # Should not be connected. Should have recorded an error.
    assert not pub.is_connected, "shouldn't connect with bogus binary"
    assert pub.last_error, f"expected an error, got: {pub.last_error!r}"
    print(f"  last_error: {pub.last_error}")
    pub.stop()
    print("  no_ffmpeg_path_error: OK")


if __name__ == "__main__":
    print("test_build_rtmp_url")
    test_build_rtmp_url()
    print("test_url_sanitization")
    test_url_sanitization()
    print("test_ffmpeg_available")
    test_ffmpeg_available()
    print("test_publisher_pipeline")
    test_publisher_pipeline()
    print("test_stop_during_push")
    test_stop_during_push()
    print("test_no_ffmpeg_path_error")
    test_no_ffmpeg_path_error()
    print("\nALL TESTS PASSED")
