"""Basic tests for DJ HUD package."""

import sys
import os

# Add src to path for testing without install
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def test_import():
    """Package imports without errors."""
    import djhud
    assert djhud.__version__ == "0.9.50"


def test_models():
    """CaptureRegion and SnapHelper work correctly."""
    from djhud.models import CaptureRegion, SnapHelper

    r = CaptureRegion(name="Test", src_x=0, src_y=0, src_w=200, src_h=100,
                      out_x=10, out_y=10, target_h=50)
    assert r.estimated_width() == 100  # 200 * (50/100)
    assert r.raw_out_x == 10

    snap = SnapHelper(snap_to_grid=True, grid_size=10)
    assert snap.snap_value(13) == 10
    assert snap.snap_value(17) == 20
    assert snap.normalize_rect([100, 100, 50, 50]) == [50, 50, 100, 100]
    assert snap.clamp_rect([-5, -5, 100, 100], 200, 200) == [0, 0, 100, 100]


def test_diagnostics():
    """SystemDiagnostics runs without crashing."""
    from djhud.diagnostics import SystemDiagnostics
    diag = SystemDiagnostics()
    results = diag.run_all()
    assert len(results) > 0
    assert all(r.status in ("ok", "warning", "error") for r in results)

    # JSON export works
    j = diag.to_json()
    import json
    data = json.loads(j)
    assert data["app_version"] == "0.9.50"


def test_platform():
    """Platform detection returns valid values."""
    from djhud.platform import PLATFORM, IS_WINDOWS, IS_MAC, IS_LINUX
    assert PLATFORM in ("Windows", "Darwin", "Linux")
    assert sum([IS_WINDOWS, IS_MAC, IS_LINUX]) == 1


if __name__ == "__main__":
    test_import()
    test_models()
    test_diagnostics()
    test_platform()
    print("All tests passed!")
