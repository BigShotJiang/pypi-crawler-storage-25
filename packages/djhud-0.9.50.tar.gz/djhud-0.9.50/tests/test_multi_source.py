"""Tests for multi-source region capture (v0.9.18)."""

import json
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


def test_capture_region_new_fields():
    """CaptureRegion has source_type and source_id with backward-compatible defaults."""
    from djhud.models import CaptureRegion

    # New region without source fields — defaults to empty (global source)
    r = CaptureRegion(name="Test", src_x=0, src_y=0, src_w=200, src_h=100,
                      out_x=10, out_y=10, target_h=50)
    assert r.source_type == ""
    assert r.source_id == ""
    assert r.estimated_width() == 100

    # Explicit window source
    r2 = CaptureRegion(name="Win", src_x=100, src_y=200, src_w=400, src_h=80,
                       out_x=0, out_y=0, target_h=80,
                       source_type="window", source_id="Traktor Pro")
    assert r2.source_type == "window"
    assert r2.source_id == "Traktor Pro"

    # Explicit screen source
    r3 = CaptureRegion(name="Mon", src_x=0, src_y=0, src_w=1920, src_h=1080,
                       out_x=0, out_y=0, target_h=80,
                       source_type="screen", source_id="0")
    assert r3.source_type == "screen"
    assert r3.source_id == "0"

    # Explicit webcam source
    r4 = CaptureRegion(name="Cam", src_x=0, src_y=0, src_w=640, src_h=480,
                       out_x=0, out_y=0, target_h=80,
                       source_type="webcam", source_id="0")
    assert r4.source_type == "webcam"


def test_capture_region_asdict_roundtrip():
    """CaptureRegion serializes/deserializes with new fields intact."""
    from dataclasses import asdict
    from djhud.models import CaptureRegion

    original = CaptureRegion(
        name="DJ App", src_x=0, src_y=0, src_w=1080, src_h=80,
        out_x=0, out_y=0, target_h=80,
        source_type="window", source_id="djay Pro"
    )
    d = asdict(original)
    assert d["source_type"] == "window"
    assert d["source_id"] == "djay Pro"

    json_str = json.dumps(d)
    loaded = json.loads(json_str)
    restored = CaptureRegion(**loaded)
    assert restored.source_type == "window"
    assert restored.source_id == "djay Pro"
    assert restored.name == "DJ App"


def test_backward_compatible_preset_load():
    """Old presets without source_type/source_id load correctly."""
    from djhud.models import CaptureRegion

    old_region_data = {
        "name": "Waveform",
        "src_x": 100, "src_y": 200, "src_w": 400, "src_h": 80,
        "out_x": 0, "out_y": 0, "target_h": 80,
        "enabled": True, "locked": False, "edit_as_crop": False,
        "raw_out_x": 0, "raw_out_y": 0,
    }
    r = CaptureRegion(**old_region_data)
    assert r.source_type == ""
    assert r.source_id == ""
    assert r.name == "Waveform"


def test_new_preset_format():
    """New preset format with per-region source info round-trips through JSON."""
    from dataclasses import asdict
    from djhud.models import CaptureRegion

    regions = [
        CaptureRegion(name="Waveform", src_x=100, src_y=200, src_w=400, src_h=80,
                      out_x=0, out_y=0, target_h=80,
                      source_type="window", source_id="Traktor Pro"),
        CaptureRegion(name="Webcam", src_x=0, src_y=0, src_w=640, src_h=480,
                      out_x=400, out_y=0, target_h=80,
                      source_type="webcam", source_id="0"),
        CaptureRegion(name="Legacy", src_x=0, src_y=0, src_w=200, src_h=80,
                      out_x=800, out_y=0, target_h=80),
    ]
    preset = {
        "canvas_w": 1080,
        "canvas_h": 80,
        "regions": [asdict(r) for r in regions],
    }
    json_str = json.dumps(preset, indent=2)
    loaded = json.loads(json_str)

    restored = [CaptureRegion(**rd) for rd in loaded["regions"]]
    assert restored[0].source_type == "window"
    assert restored[0].source_id == "Traktor Pro"
    assert restored[1].source_type == "webcam"
    assert restored[1].source_id == "0"
    assert restored[2].source_type == ""
    assert restored[2].source_id == ""


def test_duplicate_preserves_source():
    """Duplicating a region should preserve source_type and source_id."""
    from djhud.models import CaptureRegion

    original = CaptureRegion(name="Deck A", src_x=0, src_y=0, src_w=400, src_h=80,
                             out_x=0, out_y=0, target_h=80,
                             source_type="window", source_id="djay Pro")
    d = CaptureRegion(name=f"{original.name} copy",
                      src_x=original.src_x, src_y=original.src_y,
                      src_w=original.src_w, src_h=original.src_h,
                      out_x=original.out_x + 20, out_y=original.out_y + 20,
                      target_h=original.target_h,
                      source_type=original.source_type,
                      source_id=original.source_id)
    assert d.source_type == "window"
    assert d.source_id == "djay Pro"
    assert d.name == "Deck A copy"


if __name__ == "__main__":
    test_capture_region_new_fields()
    test_capture_region_asdict_roundtrip()
    test_backward_compatible_preset_load()
    test_new_preset_format()
    test_duplicate_preserves_source()
    print("All multi-source tests passed!")
