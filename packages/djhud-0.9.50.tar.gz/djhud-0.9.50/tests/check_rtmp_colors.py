"""Verify BGR byte ordering actually produces correct colors.

We publish a pure-red frame, decode the output with ffmpeg, and sample
the resulting pixel. If the channels are swapped, red would show up as
blue.
"""

import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from PIL import Image
from djhud.rtmp import RtmpPublisher


def main():
    W, H, FPS = 320, 240, 30
    out = "/tmp/djhud_color_check.mp4"
    frame_png = "/tmp/djhud_color_frame.png"
    for f in (out, frame_png):
        try: os.unlink(f)
        except FileNotFoundError: pass

    pub = RtmpPublisher(url="rtmp://x/y", width=W, height=H, fps=FPS,
                        bitrate_kbps=2000, keyframe_secs=1)
    original_build = pub._build_ffmpeg_cmd
    def patched():
        cmd = original_build()
        assert cmd[-2] == "flv"
        return cmd[:-3] + ["-f", "mp4", out]
    pub._build_ffmpeg_cmd = patched

    pub.start()
    time.sleep(0.5)
    assert pub.is_connected

    # Pure red frame
    red = Image.new("RGB", (W, H), (220, 20, 30))
    for _ in range(FPS * 2):
        pub.push_frame(red)
        time.sleep(1.0 / FPS)

    time.sleep(0.5)
    pub.stop()
    assert pub.sent_frames > 10, f"only sent {pub.sent_frames}"

    # Extract middle frame with ffmpeg
    r = subprocess.run(
        ["ffmpeg", "-v", "error", "-y", "-i", out,
         "-vf", "select=eq(n\\,15)", "-vframes", "1", frame_png],
        capture_output=True, text=True,
    )
    assert r.returncode == 0, f"extract failed: {r.stderr}"

    img = Image.open(frame_png).convert("RGB")
    r, g, b = img.getpixel((W // 2, H // 2))
    print(f"  center pixel RGB = ({r}, {g}, {b})")

    # Expected: dominant red. Tolerate yuv420p chroma subsampling distortion.
    assert r > 180, f"red channel too low ({r}) — BGR/RGB swapped?"
    assert r > g + 100, f"red not dominant over green: r={r} g={g}"
    assert r > b + 100, f"red not dominant over blue: r={r} b={b}"
    print("  colors correct — BGR ordering verified")


if __name__ == "__main__":
    main()
    print("\nPASSED")
