"""Tests for the v0.9.50 RTMP fixes:
  1. Odd dimensions get rounded to even instead of crashing libx264
  2. Below-minimum dimensions are rejected
  3. Supervisor gives up after consecutive fast failures instead of looping
"""

import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from djhud.rtmp import RtmpPublisher, FAST_FAIL_LIMIT


def test_odd_dimensions_rounded():
    """220x503 (Rob's actual broken canvas) should round to 220x502."""
    pub = RtmpPublisher(url="rtmp://x/y", width=220, height=503, fps=30)
    assert pub.width == 220, f"width should stay 220, got {pub.width}"
    assert pub.height == 502, f"height should round 503→502, got {pub.height}"

    # Both odd
    pub2 = RtmpPublisher(url="rtmp://x/y", width=1081, height=79, fps=30)
    assert pub2.width == 1080, f"width should round 1081→1080, got {pub2.width}"
    assert pub2.height == 78, f"height should round 79→78, got {pub2.height}"

    # Both already even — unchanged
    pub3 = RtmpPublisher(url="rtmp://x/y", width=1920, height=1080, fps=30)
    assert pub3.width == 1920
    assert pub3.height == 1080
    print("  odd_dimensions_rounded: OK")


def test_tiny_dimensions_bumped_to_minimum():
    """Tiny canvases get bumped up to 16x16 instead of crashing libx264.

    More user-friendly than rejecting: if someone has a tiny test canvas
    they get a working 16x16 stream rather than a confusing exception.
    The image gets resized in push_frame() anyway.
    """
    pub = RtmpPublisher(url="rtmp://x/y", width=8, height=8, fps=30)
    assert pub.width == 16, f"8 should bump to 16, got {pub.width}"
    assert pub.height == 16
    print("  tiny_dimensions_bumped_to_minimum: OK")


def test_fifteen_bumps_to_sixteen():
    """15x15: max() clamps to 16 (already even), so result is 16x16."""
    pub = RtmpPublisher(url="rtmp://x/y", width=15, height=15, fps=30)
    assert pub.width == 16, f"15 should bump to 16 via max(), got {pub.width}"
    assert pub.height == 16
    print("  fifteen_bumps_to_sixteen: OK")


def test_zero_fps_clamped():
    """fps=0 used to make ffmpeg explode. Should clamp to 1."""
    pub = RtmpPublisher(url="rtmp://x/y", width=320, height=240, fps=0)
    assert pub.fps == 1, f"fps=0 should clamp to 1, got {pub.fps}"
    print("  zero_fps_clamped: OK")


def test_supervisor_gives_up_on_consecutive_fast_failures():
    """If ffmpeg dies in <1.5s repeatedly, supervisor stops respawning."""
    pub = RtmpPublisher(
        url="rtmp://x/y", width=320, height=240, fps=30,
    )
    # Force ffmpeg to die immediately by using a bogus binary.
    pub._build_ffmpeg_cmd = lambda: ["nonexistent_ffmpeg_xyz", "-x"]

    pub.start()
    # Wait long enough for FAST_FAIL_LIMIT spawn attempts.
    # Each spawn fails at popen time, no real subprocess to wait for.
    # Should give up after ~3 attempts.
    deadline = time.monotonic() + 8.0
    while time.monotonic() < deadline:
        if pub._gave_up:
            break
        time.sleep(0.2)

    assert pub._gave_up, (
        f"supervisor should have given up by now. "
        f"failures={pub._consecutive_fast_failures}, "
        f"last_error={pub.last_error!r}"
    )
    assert pub._consecutive_fast_failures >= FAST_FAIL_LIMIT
    assert "cannot be started" in pub.last_error.lower() or \
           "ffmpeg" in pub.last_error.lower(), \
           f"error should explain the issue: {pub.last_error!r}"

    # Status string should reflect gave-up state
    status = pub.status
    assert "Stopped" in status, f"status should say Stopped: {status!r}"
    assert "Reconnecting" not in status, \
        f"status shouldn't say Reconnecting after give-up: {status!r}"

    pub.stop()
    print(f"  gives_up_on_fast_failures: OK ({pub._consecutive_fast_failures} attempts before give-up)")


def test_gave_up_recovers_on_restart():
    """Stopping and starting again should reset gave_up state."""
    pub = RtmpPublisher(url="rtmp://x/y", width=320, height=240, fps=30)
    pub._build_ffmpeg_cmd = lambda: ["nonexistent_ffmpeg_xyz", "-x"]
    pub.start()
    deadline = time.monotonic() + 8.0
    while time.monotonic() < deadline and not pub._gave_up:
        time.sleep(0.2)
    assert pub._gave_up
    pub.stop()

    # Now create a fresh publisher (the app does this in start_rtmp).
    # Verify it doesn't carry over state.
    pub2 = RtmpPublisher(url="rtmp://x/y", width=320, height=240, fps=30)
    assert not pub2._gave_up
    assert pub2._consecutive_fast_failures == 0
    print("  gave_up_recovers_on_restart: OK")


if __name__ == "__main__":
    print("test_odd_dimensions_rounded")
    test_odd_dimensions_rounded()
    print("test_tiny_dimensions_bumped_to_minimum")
    test_tiny_dimensions_bumped_to_minimum()
    print("test_fifteen_bumps_to_sixteen")
    test_fifteen_bumps_to_sixteen()
    print("test_zero_fps_clamped")
    test_zero_fps_clamped()
    print("test_supervisor_gives_up_on_consecutive_fast_failures")
    test_supervisor_gives_up_on_consecutive_fast_failures()
    print("test_gave_up_recovers_on_restart")
    test_gave_up_recovers_on_restart()
    print("\nALL TESTS PASSED")
