# ksadk/server/app.py
"""
FastAPI 应用 - 提供 HTTP API 接口 (ADK Web 兼容)
"""

import base64
import io
import json
import logging
import mimetypes
import os
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Request, File, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import ksadk.conversations as conversation
from ksadk.conversations.session_title import (
    HEURISTIC_SESSION_TITLE_SOURCE,
    build_heuristic_title,
)
from ksadk.runners.base_runner import BaseRunner
from ksadk.server.api_models import AgentRunRequest
from ksadk.sessions import Session, SessionEvent, resolve_session_service
from ksadk.sessions.local_service import resolve_local_session_dir
from ksadk.tracing import get_memory_exporter
from ksadk.conversations.model_context import normalize_model_metadata

logger = logging.getLogger(__name__)

# Create and configure the FastAPI application
app = FastAPI(
    title="ADK Core API",
    description="Agent Development Kit HTTP API",
    version="1.0.0",
)

# Middleware for disabling cache on frontend entry points
@app.middleware("http")
async def no_cache_frontend(request: Request, call_next):
    response = await call_next(request)
    path = request.url.path
    if path == "/" or path.endswith(".html"):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response

# Configure CORS (permissive by default for ADK tools)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global Runner instance
runner: BaseRunner = None
_runner_loaded = False

_TEXT_MIME_PREFIXES = ("text/",)
_TEXT_MIME_TYPES = {
    "application/json",
    "application/pdf",
    "application/xml",
    "application/yaml",
    "application/x-yaml",
    "application/x-ndjson",
}
_TEXT_FILE_EXTENSIONS = {
    ".txt",
    ".md",
    ".markdown",
    ".json",
    ".yaml",
    ".yml",
    ".csv",
    ".tsv",
    ".log",
    ".py",
    ".js",
    ".ts",
    ".jsx",
    ".tsx",
    ".html",
    ".css",
    ".sql",
    ".xml",
    ".sh",
}
_MAX_INLINE_BASE64_CHARS = 4_000_000
_MAX_INLINE_TEXT_CHARS = 20_000
_MAX_REFERENCE_TEXT_BYTES = 3_000_000
_UPLOAD_URI_SCHEME = "ksadk-upload://"


def set_runner(r: BaseRunner):
    global runner, _runner_loaded
    runner = r
    _runner_loaded = False


def _ensure_runner_loaded() -> BaseRunner:
    global _runner_loaded
    if not runner:
        raise HTTPException(status_code=500, detail="Runner 未初始化")
    if _runner_loaded:
        return runner

    runner.load_agent()
    _runner_loaded = True
    return runner


def _resolve_active_runner() -> BaseRunner:
    try:
        return _ensure_runner_loaded()
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Runner 加载失败: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc) or "Runner 加载失败") from exc


def _prepare_runner_for_model(active_runner: BaseRunner, model: Optional[str]) -> None:
    try:
        active_runner.prepare_for_request(model)
    except Exception as exc:
        logger.warning("Runner 模型切换失败: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc) or "Runner 模型切换失败") from exc


def _resolve_current_model() -> tuple[Optional[str], Optional[str]]:
    candidates = (
        ("OPENAI_MODEL_NAME", os.getenv("OPENAI_MODEL_NAME")),
        ("MODEL_NAME", os.getenv("MODEL_NAME")),
        ("COZE_MODEL_NAME", os.getenv("COZE_MODEL_NAME")),
    )
    for source, value in candidates:
        model = str(value or "").strip()
        if model:
            return model, source
    return None, None


def _build_bootstrap_model_payload() -> Optional[dict[str, Any]]:
    current_model, source = _resolve_current_model()
    if not current_model:
        return None

    payload = normalize_model_metadata({"id": current_model})
    payload["source"] = source
    return payload


def _is_textual_mime(mime_type: str) -> bool:
    mime = (mime_type or "").lower()
    if not mime:
        return False
    return mime.startswith(_TEXT_MIME_PREFIXES) or mime in _TEXT_MIME_TYPES


def _looks_like_textual_attachment(mime_type: str, display_name: str) -> bool:
    suffix = Path(display_name or "").suffix.lower()
    return _is_textual_mime(mime_type) or suffix in _TEXT_FILE_EXTENSIONS


def _extract_pdf_text(raw: bytes) -> str:
    try:
        from pypdf import PdfReader
    except Exception:
        return ""

    try:
        reader = PdfReader(io.BytesIO(raw))
    except Exception:
        return ""

    segments: List[str] = []
    for page in reader.pages[:10]:
        try:
            page_text = page.extract_text() or ""
        except Exception:
            page_text = ""
        if page_text:
            segments.append(page_text)

    return "\n".join(segments).strip()


def _decode_inline_data(data_b64: str) -> bytes:
    return base64.b64decode((data_b64 or "").strip() + "===")


def _resolve_uploads_dir() -> Path:
    uploads_dir = resolve_local_session_dir() / "files"
    uploads_dir.mkdir(parents=True, exist_ok=True)
    return uploads_dir


def _resolve_attachment_storage_path(file_uri: str) -> Optional[Path]:
    normalized_uri = (file_uri or "").strip()
    if not normalized_uri:
        return None

    if normalized_uri.startswith("local:"):
        path = Path(normalized_uri[6:]).expanduser()
        return path.resolve()

    if normalized_uri.startswith(_UPLOAD_URI_SCHEME):
        file_id = normalized_uri.removeprefix(_UPLOAD_URI_SCHEME).strip("/")
        if not file_id:
            return None

        for candidate in sorted(_resolve_uploads_dir().glob(f"{file_id}*")):
            if candidate.is_file():
                return candidate.resolve()

    return None


def _read_attachment_bytes(storage_path: Optional[Path], *, size_limit: Optional[int] = None) -> Optional[bytes]:
    if storage_path is None or not storage_path.is_file():
        return None

    try:
        if size_limit is not None and storage_path.stat().st_size > size_limit:
            return None
        return storage_path.read_bytes()
    except OSError:
        return None


def _extract_inline_attachment_text(*, display_name: str, mime_type: str, raw: bytes) -> str:
    if mime_type == "application/pdf" or display_name.lower().endswith(".pdf"):
        text = _extract_pdf_text(raw)
        if not text:
            return ""
        if len(text) > _MAX_INLINE_TEXT_CHARS:
            return text[:_MAX_INLINE_TEXT_CHARS] + "\n...[内容已截断]"
        return text

    if _looks_like_textual_attachment(mime_type, display_name):
        text = raw.decode("utf-8", errors="ignore")
        if len(text) > _MAX_INLINE_TEXT_CHARS:
            return text[:_MAX_INLINE_TEXT_CHARS] + "\n...[内容已截断]"
        return text

    return ""


def _attachment_prompt_text(attachment: Dict[str, Any]) -> str:
    display_name = str(attachment.get("display_name") or "uploaded_file")
    mime_type = str(attachment.get("mime_type") or "application/octet-stream")
    transport = str(attachment.get("transport") or "")

    if transport == "inline":
        data_b64 = str(attachment.get("data") or "").strip()
        if len(data_b64) > _MAX_INLINE_BASE64_CHARS:
            return (
                "[上传文件: "
                f"{display_name}, "
                f"mime={mime_type or 'unknown'}, "
                "内容过大，未直接展开]"
            )

        try:
            raw = _decode_inline_data(data_b64)
        except Exception:
            return f"[上传文件: {display_name}, 内容解码失败]"

        text = _extract_inline_attachment_text(
            display_name=display_name,
            mime_type=mime_type,
            raw=raw,
        )
        if text:
            return f"[上传文件: {display_name}]\n{text}"
        return (
            "[上传文件: "
            f"{display_name}, "
            f"mime={mime_type or 'application/octet-stream'}, "
            f"bytes={len(raw)}]"
        )

    storage_path_value = attachment.get("storage_path")
    storage_path = Path(str(storage_path_value)) if storage_path_value else None
    size_bytes = attachment.get("size_bytes")
    if size_bytes is None and storage_path is not None and storage_path.exists():
        try:
            size_bytes = storage_path.stat().st_size
        except OSError:
            size_bytes = None

    raw = _read_attachment_bytes(storage_path, size_limit=_MAX_REFERENCE_TEXT_BYTES)
    if raw is not None:
        text = _extract_inline_attachment_text(
            display_name=display_name,
            mime_type=mime_type,
            raw=raw,
        )
        if text:
            return f"[上传文件: {display_name}]\n{text}"
        return (
            "[上传文件: "
            f"{display_name}, "
            f"mime={mime_type or 'application/octet-stream'}, "
            f"bytes={len(raw)}]"
        )

    if size_bytes and size_bytes > _MAX_REFERENCE_TEXT_BYTES:
        return (
            "[上传文件: "
            f"{display_name}, "
            f"mime={mime_type or 'unknown'}, "
            f"bytes={size_bytes}, "
            "内容过大，未直接展开]"
        )

    file_uri = attachment.get("file_uri") or ""
    return (
        "[上传文件引用: "
        f"{display_name or file_uri}, "
        f"mime={mime_type or 'unknown'}]"
    )


def _extract_user_input_from_parts(parts: List[Any]) -> str:
    """兼容旧测试/旧调用点，统一复用 conversations 层的规范化逻辑。"""

    return conversation.extract_user_input_from_parts(parts)


def _attachment_from_part(part: Any) -> Optional[Dict[str, Any]]:
    """兼容旧入口，真实实现已经收口到 conversations.normalize。"""

    return conversation.attachment_from_part(part)


async def _hydrate_session(session: Optional[Session]) -> Optional[Session]:
    if not session:
        return None
    session.events = await resolve_session_service().get_events(session.id)
    return session


async def _ensure_session(agent_id: str, user_id: str, session_id: Optional[str]) -> Session:
    service = resolve_session_service()
    if session_id:
        existing = await service.get_session(session_id)
        if existing:
            if existing.agent_id != agent_id or existing.user_id != user_id:
                raise HTTPException(
                    status_code=409,
                    detail="Session id belongs to a different agent or user",
                )
            return await _hydrate_session(existing) or existing
        created = await service.create_session(agent_id, user_id, session_id=session_id)
        return await _hydrate_session(created) or created

    created = await service.create_session(agent_id, user_id)
    return await _hydrate_session(created) or created


def _request_id() -> str:
    return f"req-{uuid.uuid4().hex[:12]}"


def _action_response(action: str, data: Any, *, request_id: Optional[str] = None, message: str = "Success") -> dict:
    payload = {
        "Code": 0,
        "Message": message,
        "RequestId": request_id or _request_id(),
        "Data": data,
    }
    if action:
        payload["Action"] = action
    return payload


# ============================================================
# Core ADK API Endpoints
# ============================================================


@app.get("/health")
async def health_check():
    framework = "unknown"
    agent_name = "unknown"
    if runner and hasattr(runner, "detection_result"):
        framework = runner.detection_result.type.value  # langgraph, langchain, adk
        agent_name = runner.detection_result.name
    return {"status": "ok", "framework": framework, "agent": agent_name}


@app.get("/list-apps")
async def list_apps(relative_path: str = "./"):
    """Return available apps. For KsADK single-agent mode, returns the current agent."""
    name = runner.detection_result.name if runner else "default_agent"
    return [name]


class UiBootstrapRequest(BaseModel):
    AgentId: Optional[str] = None
    SessionId: Optional[str] = None


class CreateSessionActionRequest(BaseModel):
    AgentId: str
    UserId: Optional[str] = "user"
    SessionId: Optional[str] = None


class ListSessionsActionRequest(BaseModel):
    AgentId: str
    UserId: Optional[str] = "user"


class SessionIdRequest(BaseModel):
    SessionId: str


class RunAgentActionRequest(BaseModel):
    AgentId: str
    Messages: List[Dict[str, Any]]
    SessionId: Optional[str] = None
    ApiFormat: str = "responses"
    Stream: bool = False
    Model: Optional[str] = None


class ResponsesRequest(BaseModel):
    input: Any
    model: Optional[str] = None
    stream: bool = False
    session_id: Optional[str] = None


def _session_to_action_payload(session: Session) -> dict[str, Any]:
    title = session.title
    title_source = session.title_source
    if title_source == "fallback_first_prompt":
        heuristic = build_heuristic_title(
            first_prompt=session.first_prompt or title,
            assistant_text=session.summary or "",
        )
        if heuristic and heuristic != title:
            title = heuristic
            title_source = HEURISTIC_SESSION_TITLE_SOURCE
    return {
        "SessionId": session.id,
        "AgentId": session.agent_id,
        "UserId": session.user_id,
        "Title": title,
        "TitleSource": title_source,
        "Summary": session.summary,
        "FirstPrompt": session.first_prompt,
        "LastPrompt": session.last_prompt,
        "State": session.state,
        "CreatedAt": session.created_at,
        "UpdatedAt": session.updated_at,
        "Version": session.version,
    }


def _event_to_action_payload(event: SessionEvent) -> dict[str, Any]:
    payload = {
        "EventId": event.id,
        "SessionId": event.session_id,
        "Author": event.author,
        "EventType": event.event_type,
        "Content": event.content,
        "Timestamp": event.timestamp,
        "SeqId": event.seq_id,
        "Metadata": event.metadata,
    }
    if event.invocation_id:
        payload["InvocationId"] = event.invocation_id
    return payload


@app.post("/agentengine/api/v1/GetAgentUiBootstrap")
async def get_agent_ui_bootstrap(request: UiBootstrapRequest):
    agent_id = request.AgentId or (runner.detection_result.name if runner else "default-agent")
    description = getattr(runner.detection_result, "description", "") if runner else ""
    return _action_response(
        "GetAgentUiBootstrap",
        {
            "Agent": {
                "AgentId": agent_id,
                "Name": runner.detection_result.name if runner else agent_id,
                "Description": description or "",
            },
            "Modules": ["Chat", "Build", "Deploy"],
            "Capabilities": {
                "Attachments": True,
                "Approval": True,
                "Thinking": True,
                "StopRun": False,
                "ResumeRun": False,
                "MCP": False,
                "HostedRuntime": False,
            },
            "AccessMode": "Owner",
            "SharePermissions": {
                "Interactive": True,
                "DefaultPath": "/chat",
                "SharePath": "/chat",
            },
            "ApiFormats": ["responses", "chat_completions"],
            "Stream": True,
            "SessionId": request.SessionId,
            "HostedRuntime": None,
            "Model": _build_bootstrap_model_payload(),
        },
    )


@app.post("/agentengine/api/v1/CreateSession")
async def create_session_action(request: CreateSessionActionRequest):
    session = await _ensure_session(request.AgentId, request.UserId or "user", request.SessionId)
    return _action_response("CreateSession", {"Session": _session_to_action_payload(session)})


@app.post("/agentengine/api/v1/ListSessions")
async def list_sessions_action(request: ListSessionsActionRequest):
    service = resolve_session_service()
    sessions = await service.list_sessions(request.AgentId, request.UserId or "user")
    return _action_response(
        "ListSessions",
        {"Sessions": [_session_to_action_payload(session) for session in sessions]},
    )


@app.post("/agentengine/api/v1/GetSession")
async def get_session_action(request: SessionIdRequest):
    service = resolve_session_service()
    session = await _hydrate_session(await service.get_session(request.SessionId))
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return _action_response("GetSession", {"Session": _session_to_action_payload(session)})


@app.post("/agentengine/api/v1/DeleteSession")
async def delete_session_action(request: SessionIdRequest):
    service = resolve_session_service()
    deleted = await service.delete_session(request.SessionId)
    if not deleted:
        raise HTTPException(status_code=404, detail="Session not found")
    return _action_response("DeleteSession", {"Deleted": True})


@app.post("/agentengine/api/v1/ListSessionEvents")
async def list_session_events_action(request: SessionIdRequest):
    service = resolve_session_service()
    events = await service.get_events(request.SessionId)
    return _action_response(
        "ListSessionEvents",
        {"Events": [_event_to_action_payload(event) for event in events]},
    )
@app.post("/agentengine/api/v1/UploadFile")
async def upload_file_action(file: UploadFile = File(...)):
    uploads_dir = _resolve_uploads_dir()
    ext = Path(file.filename or "").suffix
    file_id = uuid.uuid4().hex
    target_path = uploads_dir / f"{file_id}{ext}"
    size_bytes = 0

    with open(target_path, "wb") as f:
        while chunk := await file.read(1024 * 1024):
            size_bytes += len(chunk)
            f.write(chunk)

    return _action_response(
        "UploadFile",
        {
            "FileData": {
                "fileUri": f"{_UPLOAD_URI_SCHEME}{file_id}",
                "displayName": file.filename or "uploaded_file",
                "mimeType": file.content_type or "application/octet-stream",
                "sizeBytes": size_bytes,
            }
        }
    )


@app.get("/agentengine/api/v1/AttachmentContent", include_in_schema=False)
async def attachment_content_action(FileUri: str = Query(...)):
    storage_path = _resolve_attachment_storage_path(FileUri)
    if storage_path is None or not storage_path.is_file():
        raise HTTPException(status_code=404, detail="Attachment not found")

    media_type, _ = mimetypes.guess_type(storage_path.name)
    return FileResponse(
        path=storage_path,
        media_type=media_type or "application/octet-stream",
        filename=storage_path.name,
        content_disposition_type="inline",
    )

def _normalize_model_catalog_items(raw_models: list[Any]) -> list[dict[str, Any]]:
    """统一模型目录 shape，并按 id 去重。

    这里刻意保留上游原始 dict 字段，再补 canonical metadata。
    这样两周后模型服务扩展字段时，这一层不会再次把信息裁掉。
    """

    normalized_by_id: dict[str, dict[str, Any]] = {}
    for raw_model in raw_models:
        item = normalize_model_metadata(raw_model)
        normalized_by_id[item["id"]] = item
    return sorted(normalized_by_id.values(), key=lambda item: item["id"])


async def _build_models_payload() -> dict[str, Any]:
    import os
    import httpx

    api_base = os.getenv("OPENAI_BASE_URL") or os.getenv("OPENAI_API_BASE")
    api_key = os.getenv("OPENAI_API_KEY")
    current_model, source = _resolve_current_model()

    def _fallback_catalog() -> dict[str, Any]:
        models = _normalize_model_catalog_items([current_model]) if current_model else []
        return {
            "data": models,
            "current": current_model,
            "source": source,
        }

    if not api_base:
        return _fallback_catalog()

    try:
        base_url = api_base.rstrip("/")
        if base_url.endswith("/v1"):
            url = f"{base_url}/models"
        else:
            url = f"{base_url}/v1/models"

        headers = {}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        async with httpx.AsyncClient(verify=False, timeout=10) as client:
            resp = await client.get(url, headers=headers)
            resp.raise_for_status()
            data = resp.json()

            if isinstance(data, list):
                models = _normalize_model_catalog_items(list(data))
            else:
                models = _normalize_model_catalog_items(list(data.get("data", [])))
            if current_model and all(str(item.get("id") or "").strip() != current_model for item in models):
                models = _normalize_model_catalog_items([*models, current_model])
            return {"data": models, "current": current_model, "source": source}
    except Exception as e:
        logger.error(f"Failed to fetch models: {e}")
        fallback = _fallback_catalog()
        fallback["error"] = str(e)
        return fallback

class ListAgentModelsRequest(BaseModel):
    AgentId: Optional[str] = None
    Name: Optional[str] = None


@app.post("/agentengine/api/v1/ListAgentModels")
async def list_agent_models_action(_request: ListAgentModelsRequest):
    payload = await _build_models_payload()
    return _action_response(
        "ListAgentModels",
        {
            "Models": payload.get("data", []),
            "Current": payload.get("current"),
            "Source": payload.get("source", ""),
        },
    )

@app.post("/agentengine/api/v1/RunAgent")
async def run_agent_action(request: RunAgentActionRequest):
    messages = conversation.normalize_kop_messages(request.Messages)
    api_format = (request.ApiFormat or "responses").strip().lower()

    if request.Stream:
        if api_format == "chat_completions":
            completion_request = ChatCompletionRequest(
                messages=messages,
                model=request.Model,
                stream=True,
                session_id=request.SessionId,
            )
            return await chat_completions(completion_request)
        return StreamingResponse(
            conversation.stream_conversation_turn(
                runner=_resolve_active_runner(),
                agent_id=request.AgentId,
                user_id="user",
                messages=messages,
                session_id=request.SessionId,
                model=request.Model,
                prepare_runner=_prepare_runner_for_model,
                session_service_provider=resolve_session_service,
            ),
            media_type="text/event-stream",
        )

    resolved_session_id, result = await conversation.invoke_conversation_once(
        runner=_resolve_active_runner(),
        agent_id=request.AgentId,
        user_id="user",
        messages=messages,
        session_id=request.SessionId,
        model=request.Model,
        prepare_runner=_prepare_runner_for_model,
        session_service_provider=resolve_session_service,
    )
    output_text = result["output_text"]
    if api_format == "chat_completions":
        payload = conversation.build_chat_completions_payload(
            output_text=output_text,
            model=request.Model,
            session_id=resolved_session_id,
        )
    else:
        payload = conversation.build_responses_payload(
            output_text=output_text,
            model=request.Model,
            session_id=resolved_session_id,
        )
    return _action_response("RunAgent", payload)


# ============================================================
# Session Management API (ADK Web Compatible)
# ============================================================


@app.post("/apps/{app_name}/users/{user_id}/sessions")
async def create_session(app_name: str, user_id: str, request: Request):
    """Create a new session"""
    # Check if importing existing events
    body = {}
    try:
        body = await request.json()
    except Exception:
        pass

    service = resolve_session_service()
    session = await _ensure_session(app_name, user_id, body.get("sessionId") or body.get("id"))

    for raw_event in body.get("events", []):
        session_event = SessionEvent.from_dict(raw_event, session_id=session.id)
        await service.append_event(session.id, session_event)

    hydrated = await _hydrate_session(await service.get_session(session.id))
    return hydrated.to_legacy_dict() if hydrated else session.to_legacy_dict()


@app.get("/apps/{app_name}/users/{user_id}/sessions")
async def list_sessions(app_name: str, user_id: str):
    """List all sessions for a user"""
    service = resolve_session_service()
    sessions = await service.list_sessions(app_name, user_id)
    hydrated: List[Dict[str, Any]] = []
    for session in sessions:
        session.events = await service.get_events(session.id)
        hydrated.append(session.to_legacy_dict())
    return hydrated


@app.get("/apps/{app_name}/users/{user_id}/sessions/{session_id}")
async def get_session(app_name: str, user_id: str, session_id: str):
    """Get a specific session with its events"""
    service = resolve_session_service()
    session = await _hydrate_session(await service.get_session(session_id))
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    return session.to_legacy_dict()


@app.delete("/apps/{app_name}/users/{user_id}/sessions/{session_id}")
async def delete_session(app_name: str, user_id: str, session_id: str):
    """Delete a session"""
    service = resolve_session_service()
    if await service.delete_session(session_id):
        return {"status": "deleted"}
    raise HTTPException(status_code=404, detail="Session not found")


# ============================================================
# Memory API - Save session to long-term memory
# ============================================================


@app.post("/apps/{app_name}/users/{user_id}/sessions/{session_id}/save_memory")
async def save_session_to_memory(app_name: str, user_id: str, session_id: str):
    """将指定 session 保存到长期记忆

    当配置了 KSADK_LTM_BACKEND 时，将 session 中的用户消息
    持久化到长期记忆后端，供后续 session 通过 load_memory 工具检索。
    """
    active_runner = _ensure_runner_loaded()

    # 检查 runner 是否支持长期记忆
    from ksadk.runners.adk_runner import ADKRunner as _ADKRunner

    if not isinstance(active_runner, _ADKRunner):
        raise HTTPException(
            status_code=400, detail="Long-term memory is only supported with ADK runner"
        )

    if not active_runner._long_term_memory:
        raise HTTPException(
            status_code=400,
            detail="Long-term memory not configured. Set KSADK_LTM_BACKEND environment variable.",
        )

    # 查找 ADK 内部 session ID
    internal_session_id = active_runner._session_map.get(session_id, session_id)

    success = await active_runner.save_session_to_long_term_memory(
        session_id=internal_session_id,
        user_id=user_id,
    )

    if success:
        return {"status": "saved", "session_id": session_id}
    else:
        raise HTTPException(status_code=500, detail="Failed to save session to long-term memory")


# ============================================================
# Run SSE - Core Agent Execution Endpoint
# ============================================================


@app.post("/run_sse")
async def run_sse(request: AgentRunRequest):
    """Unified Streaming Endpoint compatible with ADK Web

    Respects the `streaming` parameter:
    - streaming=False: Accumulate full response, send as single event
    - streaming=True: Stream tokens as they arrive (real-time)
    """
    active_runner = _ensure_runner_loaded()
    _prepare_runner_for_model(active_runner, request.model)
    use_streaming = request.streaming
    normalized_message = conversation.normalize_parts_content(request.newMessage.parts if request.newMessage else [])
    user_message = {
        "role": "user",
        "content": str(normalized_message.get("content") or ""),
        "display_content": str(normalized_message.get("display_content") or ""),
        "parts": list(normalized_message.get("parts") or []),
        "attachments": list(normalized_message.get("attachments") or []),
        "attachment_results": list(normalized_message.get("attachment_results") or []),
    }

    model_version = "models/gemini-pro" if "gemini" in request.appName.lower() else "models/unknown"
    prepared_non_stream: conversation.PreparedConversationTurn | None = None
    if request.sessionId:
        await conversation.ensure_conversation_session(
            agent_id=request.appName,
            user_id=request.userId,
            session_id=request.sessionId,
            session_service_provider=resolve_session_service,
        )
    if not use_streaming:
        prepared_non_stream = await conversation.build_run_input(
            agent_id=request.appName,
            user_id=request.userId,
            session_id=request.sessionId,
            messages=[user_message],
            state_delta=request.stateDelta or {},
            invocation_id=request.invocationId,
            session_service_provider=resolve_session_service,
        )
        await conversation.append_run_status_event(
            session_id=prepared_non_stream.session_id,
            author=active_runner.detection_result.name,
            status="in_progress",
            invocation_id=prepared_non_stream.invocation_id,
            session_service_provider=resolve_session_service,
        )

    async def event_generator():
        if not use_streaming:
            try:
                assert prepared_non_stream is not None
                session_id = prepared_non_stream.session_id
                user_input = prepared_non_stream.user_input
                attachments = prepared_non_stream.attachments
                attachment_results = prepared_non_stream.attachment_results
                user_parts = prepared_non_stream.user_parts
                history = prepared_non_stream.history
                invocation_id = prepared_non_stream.invocation_id
                common_metadata = {
                    "modelVersion": model_version,
                    "usageMetadata": {
                        "promptTokenCount": len(user_input),
                        "candidatesTokenCount": 0,
                        "totalTokenCount": len(user_input),
                    },
                }
                input_data = {
                    "input": user_input,
                    "history": history,
                    "input_parts": list(user_parts),
                    "attachments": attachments,
                    "attachment_results": attachment_results,
                    "model": request.model,
                }
                result = await active_runner.invoke(input_data)
                final_text = result.get("output", "")
                response_event = {
                    "id": str(uuid.uuid4()),
                    "author": active_runner.detection_result.name,
                    "sessionId": session_id,
                    "invocationId": invocation_id,
                    "content": {"role": "model", "parts": [{"text": final_text}]},
                    "actions": {"finishReason": "STOP"},
                    "modelVersion": common_metadata["modelVersion"],
                    "usageMetadata": {
                        "promptTokenCount": len(user_input),
                        "candidatesTokenCount": len(final_text),
                        "totalTokenCount": len(user_input) + len(final_text),
                    },
                    "timestamp": int(time.time() * 1000),
                }
                yield f"data: {json.dumps(response_event, ensure_ascii=False)}\n\n"
                if final_text:
                    await conversation.append_conversation_event(
                        session_id=session_id,
                        author=active_runner.detection_result.name,
                        role="model",
                        text=final_text,
                        invocation_id=invocation_id,
                        event_type="assistant_message",
                        session_service_provider=resolve_session_service,
                    )
                await conversation.append_run_status_event(
                    session_id=session_id,
                    author=active_runner.detection_result.name,
                    status="completed",
                    invocation_id=invocation_id,
                    session_service_provider=resolve_session_service,
                )

            except Exception as e:
                logger.error(f"Error in invoke: {e}")
                await conversation.append_run_status_event(
                    session_id=session_id,
                    author=active_runner.detection_result.name,
                    status="failed",
                    invocation_id=invocation_id,
                    detail=str(e),
                    session_service_provider=resolve_session_service,
                )
                error_event = {
                    "id": str(uuid.uuid4()),
                    "sessionId": session_id,
                    "invocationId": invocation_id,
                    "error": str(e),
                    "errorMessage": str(e),
                    "timestamp": int(time.time() * 1000),
                }
                yield f"data: {json.dumps(error_event, ensure_ascii=False)}\n\n"
        else:
            try:
                compaction_preview = await conversation.preview_auto_compaction(
                    agent_id=request.appName,
                    user_id=request.userId,
                    session_id=request.sessionId,
                    messages=[user_message],
                    session_service_provider=resolve_session_service,
                )
                if compaction_preview.should_compact:
                    yield conversation.build_compaction_sse_event(
                        phase="start",
                        trigger="auto",
                        total_chars=compaction_preview.total_chars,
                        group_count=compaction_preview.group_count,
                    )

                prepared = await conversation.build_run_input(
                    agent_id=request.appName,
                    user_id=request.userId,
                    session_id=request.sessionId,
                    messages=[user_message],
                    state_delta=request.stateDelta or {},
                    invocation_id=request.invocationId,
                    session_service_provider=resolve_session_service,
                )
                if prepared.compaction_triggered:
                    yield conversation.build_compaction_sse_event(
                        phase="done",
                        trigger=str(prepared.compaction_trigger or "auto"),
                        compacted_until_seq_id=prepared.compacted_until_seq_id,
                        total_chars=compaction_preview.total_chars if compaction_preview.should_compact else None,
                        group_count=compaction_preview.group_count if compaction_preview.should_compact else None,
                    )

                session_id = prepared.session_id
                user_input = prepared.user_input
                attachments = prepared.attachments
                attachment_results = prepared.attachment_results
                user_parts = prepared.user_parts
                history = prepared.history
                invocation_id = prepared.invocation_id
                common_metadata = {
                    "modelVersion": model_version,
                    "usageMetadata": {
                        "promptTokenCount": len(user_input),
                        "candidatesTokenCount": 0,
                        "totalTokenCount": len(user_input),
                    },
                }
                await conversation.append_run_status_event(
                    session_id=session_id,
                    author=active_runner.detection_result.name,
                    status="in_progress",
                    invocation_id=invocation_id,
                    session_service_provider=resolve_session_service,
                )

                client_visible_text = ""
                authoritative_text = ""
                async for chunk in active_runner.stream(
                    {
                        "input": user_input,
                        "history": history,
                        "input_parts": list(user_parts),
                        "attachments": attachments,
                        "attachment_results": attachment_results,
                        "model": request.model,
                    }
                ):
                    event_id = str(uuid.uuid4())
                    if chunk.get("type") == "thinking":
                        delta = str(chunk.get("delta", ""))
                        if delta:
                            yield f"event: response.reasoning.delta\ndata: {json.dumps({'delta': delta}, ensure_ascii=False)}\n\n"
                        continue
                    if chunk.get("type") == "text":
                        delta_text = chunk.get("delta", "")
                        client_visible_text += delta_text
                        authoritative_text = client_visible_text
                        response_event = {
                            "id": event_id,
                            "author": chunk.get("node", active_runner.detection_result.name),
                            "sessionId": session_id,
                            "invocationId": invocation_id,
                            "content": {"role": "model", "parts": [{"text": delta_text}]},
                            "partial": True,
                            "timestamp": int(time.time() * 1000),
                        }
                        yield f"data: {json.dumps(response_event, ensure_ascii=False)}\n\n"
                        continue
                    if chunk.get("type") == "tool_call":
                        yield (
                            "event: response.tool_call\n"
                            f"data: {json.dumps({'name': chunk.get('tool_name'), 'args': chunk.get('tool_args', {})}, ensure_ascii=False)}\n\n"
                        )
                        tool_event = {
                            "id": event_id,
                            "author": chunk.get("node", "tool"),
                            "sessionId": session_id,
                            "invocationId": invocation_id,
                            "content": {
                                "role": "model",
                                "parts": [
                                    {
                                        "functionCall": {
                                            "name": chunk.get("tool_name", "unknown"),
                                            "args": chunk.get("tool_args", {}),
                                        }
                                    }
                                ],
                            },
                            "actions": {
                                "finishReason": "STOP",
                                "stateDelta": {},
                            },
                            "modelVersion": common_metadata["modelVersion"],
                            "timestamp": int(time.time() * 1000),
                        }
                        yield f"data: {json.dumps(tool_event, ensure_ascii=False)}\n\n"
                        await conversation.append_conversation_event(
                            session_id=session_id,
                            author=chunk.get("node", "tool"),
                            role="model",
                            text="",
                            invocation_id=invocation_id,
                            event_type="tool_call",
                            session_service_provider=resolve_session_service,
                            metadata={
                                "tool_name": chunk.get("tool_name", "unknown"),
                                "tool_args": chunk.get("tool_args", {}),
                            },
                        )
                        continue
                    if chunk.get("type") == "tool_result":
                        await conversation.append_conversation_event(
                            session_id=session_id,
                            author=active_runner.detection_result.name,
                            role="user",
                            text=str(chunk.get("tool_output", "")),
                            invocation_id=invocation_id,
                            event_type="tool_result",
                            session_service_provider=resolve_session_service,
                            metadata={
                                "tool_name": chunk.get("tool_name"),
                                "tool_output": chunk.get("tool_output", {}),
                            },
                        )
                        yield (
                            "event: response.tool_result\n"
                            f"data: {json.dumps({'name': chunk.get('tool_name'), 'output': chunk.get('tool_output', {})}, ensure_ascii=False)}\n\n"
                        )
                        continue
                    if chunk.get("type") == "interrupt":
                        await conversation.append_conversation_event(
                            session_id=session_id,
                            author=active_runner.detection_result.name,
                            role="model",
                            text="approval requested",
                            invocation_id=invocation_id,
                            event_type="approval_request",
                            session_service_provider=resolve_session_service,
                            metadata={"interrupt_info": chunk.get("interrupt_info")},
                        )
                        yield (
                            "event: response.approval_request\n"
                            f"data: {json.dumps({'interrupt_info': chunk.get('interrupt_info')}, ensure_ascii=False)}\n\n"
                        )
                        continue
                    if chunk.get("type") == "final":
                        final_text = chunk.get("output", "")
                        if not final_text:
                            continue
                        authoritative_text = final_text
                        if final_text != client_visible_text:
                            final_event = {
                                "id": event_id,
                                "author": active_runner.detection_result.name,
                                "sessionId": session_id,
                                "invocationId": invocation_id,
                                "content": {"role": "model", "parts": [{"text": final_text}]},
                                "actions": {"finishReason": "STOP"},
                                "modelVersion": common_metadata["modelVersion"],
                                "usageMetadata": {
                                    "promptTokenCount": len(user_input),
                                    "candidatesTokenCount": len(final_text),
                                    "totalTokenCount": len(user_input) + len(final_text),
                                },
                                "timestamp": int(time.time() * 1000),
                            }
                            yield f"data: {json.dumps(final_event, ensure_ascii=False)}\n\n"
                            client_visible_text = final_text

                if authoritative_text:
                    final_event = {
                        "id": str(uuid.uuid4()),
                        "author": active_runner.detection_result.name,
                        "sessionId": session_id,
                        "invocationId": invocation_id,
                        "content": {"role": "model", "parts": [{"text": authoritative_text}]},
                        "actions": {"finishReason": "STOP"},
                        "modelVersion": common_metadata["modelVersion"],
                        "usageMetadata": {
                            "promptTokenCount": len(user_input),
                            "candidatesTokenCount": len(authoritative_text),
                            "totalTokenCount": len(user_input) + len(authoritative_text),
                        },
                        "timestamp": int(time.time() * 1000),
                    }
                    await conversation.append_conversation_event(
                        session_id=session_id,
                        author=active_runner.detection_result.name,
                        role="model",
                        text=authoritative_text,
                        invocation_id=invocation_id,
                        event_type="assistant_message",
                        session_service_provider=resolve_session_service,
                    )
                    await conversation.append_run_status_event(
                        session_id=session_id,
                        author=active_runner.detection_result.name,
                        status="completed",
                        invocation_id=invocation_id,
                        session_service_provider=resolve_session_service,
                    )

            except Exception as e:
                logger.error(f"Error in stream: {e}")
                await conversation.append_run_status_event(
                    session_id=session_id,
                    author=active_runner.detection_result.name,
                    status="failed",
                    invocation_id=invocation_id,
                    detail=str(e),
                    session_service_provider=resolve_session_service,
                )
                error_event = {
                    "id": str(uuid.uuid4()),
                    "sessionId": session_id,
                    "invocationId": invocation_id,
                    "error": str(e),
                    "errorMessage": str(e),
                    "timestamp": int(time.time() * 1000),
                }
                yield f"data: {json.dumps(error_event, ensure_ascii=False)}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")


# ============================================================
# Trace / Debug API (ADK Web Compatible)
# ============================================================


@app.get("/debug/trace/session/{session_id}")
async def get_session_trace(session_id: str):
    """Get traces for a session - returns array of Span objects"""
    exporter = get_memory_exporter()
    if not exporter:
        return []  # Return empty array, not object

    # Get all spans and transform to ADK-Web expected format
    raw_spans = exporter.get_finished_spans()

    # Get session events for invocation mapping
    service = resolve_session_service()
    events = await service.get_events(session_id)

    # Build invocation ID mapping from session events
    invocation_ids = {}
    for event in events:
        if event.id and event.invocation_id:
            invocation_ids[event.id] = event.invocation_id

    # Transform spans to ADK-Web format
    spans = []
    for span in raw_spans:
        # Use session_id as trace_id for grouping
        trace_id = span.get("trace_id", session_id)

        # Get or create invocation_id
        invocation_id = span.get("attributes", {}).get("gcp.vertex.agent.invocation_id")
        if not invocation_id:
            # Try to derive from event association
            invocation_id = trace_id[:36] if len(trace_id) >= 36 else trace_id

        # Build attributes with required ADK fields
        attrs = span.get("attributes", {}).copy()
        attrs["gcp.vertex.agent.invocation_id"] = invocation_id

        # If this is a LLM span, add request/response
        if "llm" in span.get("name", "").lower() or "invoke" in span.get("name", "").lower():
            if "user.input" in attrs:
                attrs["gcp.vertex.agent.llm_request"] = json.dumps(
                    {
                        "contents": [
                            {"role": "user", "parts": [{"text": attrs.get("user.input", "")}]}
                        ]
                    }
                )
            if "agent.output" in attrs:
                attrs["gcp.vertex.agent.llm_response"] = json.dumps(
                    {
                        "candidates": [
                            {
                                "content": {
                                    "role": "model",
                                    "parts": [{"text": attrs.get("agent.output", "")}],
                                }
                            }
                        ]
                    }
                )

        formatted_span = {
            "trace_id": trace_id,
            "span_id": span.get("span_id", str(uuid.uuid4())[:16]),
            "parent_span_id": span.get("parent_span_id"),
            "name": span.get("name", "unknown"),
            "start_time": span.get("start_time", 0),
            "end_time": span.get("end_time", 0),
            "attributes": attrs,
            "status": span.get("status", {}),
        }
        spans.append(formatted_span)

    return spans  # Return array directly


@app.get("/debug/trace/{event_id}")
async def get_event_trace(event_id: str):
    """Get trace for a specific event - returns array of Span objects"""
    exporter = get_memory_exporter()
    if not exporter:
        return []

    spans = exporter.get_finished_spans()
    # Filter by event_id or return recent spans
    filtered = [s for s in spans if s.get("attributes", {}).get("event_id") == event_id]
    return filtered if filtered else spans[-10:]


@app.get("/apps/{app_name}/users/{user_id}/sessions/{session_id}/events/{event_id}/graph")
async def get_event_graph(app_name: str, user_id: str, session_id: str, event_id: str):
    """Get event graph (DOT format) - placeholder"""
    return {"dotSrc": None}


# ============================================================
# OpenAI Compatible API
# ============================================================


class ChatCompletionRequest(BaseModel):
    messages: List[Dict[str, Any]]
    model: Optional[str] = None
    stream: bool = False
    session_id: Optional[str] = None
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = None


@app.post("/v1/responses")
async def responses(request: ResponsesRequest):
    """OpenAI Responses 兼容接口。"""
    active_runner = _resolve_active_runner()

    messages = conversation.normalize_responses_input(request.input)
    agent_id = active_runner.detection_result.name

    if request.stream:
        return StreamingResponse(
            conversation.stream_conversation_turn(
                runner=active_runner,
                agent_id=agent_id,
                user_id="user",
                messages=messages,
                session_id=request.session_id,
                model=request.model,
                prepare_runner=_prepare_runner_for_model,
                session_service_provider=resolve_session_service,
            ),
            media_type="text/event-stream",
        )

    resolved_session_id, result = await conversation.invoke_conversation_once(
        runner=active_runner,
        agent_id=agent_id,
        user_id="user",
        messages=messages,
        session_id=request.session_id,
        model=request.model,
        prepare_runner=_prepare_runner_for_model,
        session_service_provider=resolve_session_service,
    )
    return conversation.build_responses_payload(
        output_text=result["output_text"],
        model=request.model,
        session_id=resolved_session_id,
    )


@app.post("/v1/chat/completions")
async def chat_completions(request: ChatCompletionRequest):
    """OpenAI 兼容的聊天补全接口 (支持流式和非流式)"""
    active_runner = _resolve_active_runner()
    messages = conversation.normalize_kop_messages(request.messages)
    agent_id = active_runner.detection_result.name

    if request.stream:
        return StreamingResponse(
            conversation.stream_conversation_turn(
                runner=active_runner,
                agent_id=agent_id,
                user_id="user",
                messages=messages,
                session_id=request.session_id,
                model=request.model,
                prepare_runner=_prepare_runner_for_model,
                session_service_provider=resolve_session_service,
            ),
            media_type="text/event-stream",
        )

    resolved_session_id, result = await conversation.invoke_conversation_once(
        runner=active_runner,
        agent_id=agent_id,
        user_id="user",
        messages=messages,
        session_id=request.session_id,
        model=request.model,
        prepare_runner=_prepare_runner_for_model,
        session_service_provider=resolve_session_service,
    )
    return conversation.build_chat_completions_payload(
        output_text=result["output_text"],
        model=request.model,
        session_id=resolved_session_id,
    )


# ============================================================
# Stub Endpoints for ADK-Web Compatibility
# ============================================================


@app.get("/apps/{app_name}/eval_sets")
async def list_eval_sets(app_name: str):
    """List evaluation sets - stub for ADK-Web"""
    return []


@app.get("/apps/{app_name}/eval_results")
async def list_eval_results(app_name: str):
    """List evaluation results - stub for ADK-Web"""
    return []


@app.get("/builder/app/{app_name}")
async def get_agent_builder(app_name: str, ts: int = 0, tmp: bool = False, file_path: str = None):
    """Get agent builder config - stub for ADK-Web"""
    # Return minimal YAML config for non-ADK projects
    return f"""name: {app_name}
model: glm-5
description: {app_name} agent
instruction: You are a helpful assistant.
"""


@app.post("/builder/save")
async def save_agent_builder(request: Request, tmp: bool = False):
    """Save agent builder config - stub for ADK-Web"""
    return True


@app.post("/builder/app/{app_name}/cancel")
async def cancel_agent_changes(app_name: str):
    """Cancel agent builder changes - stub for ADK-Web"""
    return True


# Legacy /traces endpoint
@app.get("/traces")
async def get_traces(limit: int = 50):
    """Get recent traces (OpenTelemetry)"""
    exporter = get_memory_exporter()
    if not exporter:
        return {"traces": []}

    spans = exporter.get_finished_spans()
    traces = []
    for span in spans[-limit:]:
        traces.append(
            {
                "name": span.get("name", "unknown"),
                "status": span.get("status", {}).get("code", "UNSET"),
                "start_time": span.get("start_time"),
                "end_time": span.get("end_time"),
                "attributes": span.get("attributes", {}),
            }
        )
    return {"traces": traces}


# ============================================================
# Static File Hosting
# ============================================================

# 静态文件目录
STATIC_DIR = Path(__file__).parent / "static"

# 使用 StaticFiles 挂载统一 Agent UI 静态文件
if STATIC_DIR.exists() and (STATIC_DIR / "index.html").exists():
    @app.get("/chat", include_in_schema=False)
    @app.get("/build", include_in_schema=False)
    @app.get("/deploy", include_in_schema=False)
    async def serve_agent_workbench_shell():
        return FileResponse(STATIC_DIR / "index.html")

    app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")
    logger.info(f"Unified Agent UI mounted from: {STATIC_DIR}")
else:
    logger.warning(f"Static files not found at: {STATIC_DIR}")
    logger.warning("Build and sync the unified Agent UI static bundle first")
