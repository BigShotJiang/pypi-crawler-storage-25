"""
Retry utilities for HTTP client error handling.

Provides RFC 7231–compliant Retry-After header parsing for 429/503 responses.
"""

import logging
from email.utils import parsedate_to_datetime
from typing import Optional

logger = logging.getLogger(__name__)

# Cap Retry-After to prevent indefinite waits (RFC 7231 best practice)
DEFAULT_RETRY_AFTER_MAX_SECONDS = 300  # 5 minutes


def parse_retry_after(
    header_value: Optional[str],
    default_seconds: int = 5,
    max_seconds: int = DEFAULT_RETRY_AFTER_MAX_SECONDS,
) -> int:
    """
    Parse Retry-After header per RFC 7231.

    Supports both formats:
    - Delay-seconds: integer (e.g. "120")
    - HTTP-date: e.g. "Wed, 21 Oct 2015 07:28:00 GMT"

    Args:
        header_value: Raw Retry-After header value
        default_seconds: Fallback when header is missing or invalid
        max_seconds: Cap to prevent indefinite waits (best practice)

    Returns:
        Seconds to wait before retry (capped at max_seconds)
    """
    if not header_value or not str(header_value).strip():
        return min(default_seconds, max_seconds)

    value = str(header_value).strip()

    # Try delay-seconds (integer)
    try:
        seconds = int(value)
        if seconds >= 0:
            return min(seconds, max_seconds)
    except ValueError:
        pass

    # Try HTTP-date (RFC 7231)
    try:
        dt = parsedate_to_datetime(value)
        from datetime import datetime, timezone

        now = datetime.now(timezone.utc)
        delta = dt - now
        seconds = max(0, int(delta.total_seconds()))
        return min(seconds, max_seconds)
    except (ValueError, TypeError) as e:
        logger.debug("Retry-After HTTP-date parse failed: %s", e)

    return min(default_seconds, max_seconds)
