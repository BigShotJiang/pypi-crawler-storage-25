"""Application DTOs for speech-to-text operations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class TranscribeCommand:
    """Command payload for STT transcription."""

    audio: bytes
    sample_rate: int = 16000
    language: str | None = None
    extract_emotion: bool = True
    use_vad: bool = True
    provider: str | None = None
    user_id: str | None = None
    tenant_id: str | None = None
    user_tier: Any | None = None
    correlation_id: str | None = None


@dataclass(slots=True)
class TranscriptionResultDTO:
    """Serializable transcription result."""

    text: str
    confidence: float
    language: str
    provider: str
    processing_time: float
    emotion: str | None = None
    emotion_confidence: float | None = None
    segments: list[dict[str, Any]] | None = None
    words: list[dict[str, Any]] | None = None
    correlation_id: str | None = None

    @classmethod
    def from_domain(cls, result: Any) -> "TranscriptionResultDTO":
        emotion = result.emotion.value if getattr(result.emotion, "value", None) else None
        metadata = result.metadata or {}
        correlation_id = metadata.get("correlation_id")
        return cls(
            text=result.text,
            confidence=result.confidence,
            language=result.language,
            provider=result.provider,
            processing_time=result.processing_time,
            emotion=emotion,
            emotion_confidence=result.emotion_confidence,
            segments=result.segments,
            words=result.words,
            correlation_id=correlation_id,
        )
