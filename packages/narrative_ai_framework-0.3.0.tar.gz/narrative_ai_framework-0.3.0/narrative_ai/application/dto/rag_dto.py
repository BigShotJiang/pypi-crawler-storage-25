"""Application DTOs for RAG memory operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from narrative_ai.engines.input_processor.types import StructuredDocument
from narrative_ai.engines.rag.types import IndexingResult, RetrievalResult, RichContext


@dataclass(slots=True)
class RememberCommand:
    """Command payload for memory indexing."""

    document: StructuredDocument
    doc_id: str | None = None
    user_id: Any | None = None
    tenant_id: Any | None = None
    correlation_id: str | None = None


@dataclass(slots=True)
class RecallQuery:
    """Query payload for memory retrieval."""

    query: str
    top_k: int = 5
    filters: dict[str, Any] | None = None
    return_context: bool = True
    user_id: Any | None = None
    tenant_id: Any | None = None
    correlation_id: str | None = None


@dataclass(slots=True)
class RecallResultDTO:
    """Serializable retrieval result."""

    text: str
    score: float
    modality: str
    media_ref: str | None
    page: int | None
    doc_id: str
    block_id: str

    @classmethod
    def from_domain(cls, result: RetrievalResult) -> "RecallResultDTO":
        return cls(
            text=result.text,
            score=result.score,
            modality=result.modality,
            media_ref=result.media_ref,
            page=result.page,
            doc_id=result.doc_id,
            block_id=result.block_id,
        )


@dataclass(slots=True)
class IndexingResultDTO:
    """Serializable indexing result."""

    doc_id: str
    chunks_indexed: int
    success: bool
    errors: list[str] = field(default_factory=list)

    @classmethod
    def from_domain(cls, result: IndexingResult) -> "IndexingResultDTO":
        return cls(
            doc_id=result.doc_id,
            chunks_indexed=result.chunks_indexed,
            success=result.success,
            errors=list(result.errors),
        )


@dataclass(slots=True)
class RecallResponseDTO:
    """Aggregated recall response."""

    query: str
    formatted_text: str
    media_references: list[str]
    results: list[RecallResultDTO]
    strategy_used: str
    total_retrieved: int

    @classmethod
    def from_context(cls, context: RichContext) -> "RecallResponseDTO":
        results = [RecallResultDTO.from_domain(item) for item in context.source_chunks]
        return cls(
            query=context.query,
            formatted_text=context.formatted_text,
            media_references=list(context.media_references),
            results=results,
            strategy_used=context.strategy_used,
            total_retrieved=context.total_retrieved,
        )
