"""Application DTOs for LLM operations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from narrative_ai.engines.llm.base_llm import LLMResult


@dataclass(slots=True)
class GenerateCommand:
    """Command payload for one-shot LLM generation."""

    prompt: str | None = None
    system_prompt: str | None = None
    messages: list[dict[str, str]] | None = None
    temperature: float = 0.7
    max_tokens: int | None = None
    provider: str | None = None
    tools: list[dict[str, Any]] | None = None
    tool_choice: str | dict[str, Any] | None = None
    response_format: dict[str, Any] | None = None
    user_id: str | None = None
    tenant_id: str | None = None
    correlation_id: str | None = None


@dataclass(slots=True)
class ChatCommand:
    """Command payload for multi-turn chat."""

    message: str
    session_id: str | None = None
    system_prompt: str | None = None
    temperature: float = 0.7
    max_tokens: int | None = None
    provider: str | None = None
    user_id: str | None = None
    tenant_id: str | None = None
    correlation_id: str | None = None


@dataclass(slots=True)
class GenerateResultDTO:
    """Serializable LLM generation result."""

    text: str
    finish_reason: str
    provider: str
    model: str
    processing_time: float
    input_tokens: int
    output_tokens: int
    total_tokens: int
    emotion: str | None = None
    emotion_confidence: float | None = None
    tool_calls: list[dict[str, Any]] | None = None
    correlation_id: str | None = None
    session_id: str | None = None

    @classmethod
    def from_domain(
        cls,
        result: LLMResult,
        session_id: str | None = None,
    ) -> "GenerateResultDTO":
        emotion = result.emotion.value if getattr(result.emotion, "value", None) else None
        return cls(
            text=result.text,
            finish_reason=result.finish_reason,
            provider=result.provider,
            model=result.model,
            processing_time=result.processing_time,
            input_tokens=result.input_tokens,
            output_tokens=result.output_tokens,
            total_tokens=result.total_tokens,
            emotion=emotion,
            emotion_confidence=result.emotion_confidence,
            tool_calls=result.tool_calls,
            correlation_id=result.correlation_id,
            session_id=session_id,
        )
