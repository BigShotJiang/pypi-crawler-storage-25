"""Application DTOs for ingestion pipeline operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from narrative_ai.engines.input_processor.types import StructuredDocument


@dataclass(slots=True)
class ProcessCommand:
    """Command payload for generic source ingestion."""

    source: str | Path | bytes
    enable_image_processing: bool | None = None
    enable_audio_processing: bool | None = None
    user_id: Any | None = None
    tenant_id: Any | None = None
    correlation_id: str | None = None


@dataclass(slots=True)
class ProcessAudioCommand:
    """Command payload for audio-source ingestion."""

    source: str
    language: str | None = None
    user_id: Any | None = None
    tenant_id: Any | None = None
    correlation_id: str | None = None


@dataclass(slots=True)
class ProcessResultDTO:
    """Serializable ingestion result."""

    document: dict[str, Any]
    doc_id: str
    block_count: int
    errors: list[str] = field(default_factory=list)

    @classmethod
    def from_domain(cls, document: StructuredDocument) -> "ProcessResultDTO":
        meta_errors = [err.message for err in document.metadata.errors]
        return cls(
            document=document.to_dict(),
            doc_id=document.doc_id,
            block_count=len(document.content_blocks),
            errors=meta_errors,
        )
