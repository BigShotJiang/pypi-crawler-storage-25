"""Application DTOs for text-to-speech operations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from narrative_ai.engines.tts.base_tts import TTSResult


@dataclass(slots=True)
class SynthesizeCommand:
    """Command payload for TTS synthesis."""

    text: str
    voice_id: str | None = None
    language: str | None = None
    emotion: Any | None = None
    output_format: str = "mp3_44100_128"
    provider: str | None = None
    user_id: str | None = None
    tenant_id: str | None = None
    correlation_id: str | None = None


@dataclass(slots=True)
class SynthesizeResultDTO:
    """Serializable synthesis result."""

    audio: bytes
    format: str
    sample_rate: int
    duration: float
    provider: str
    processing_time: float
    voice_id: str
    voice_name: str | None
    text_length: int
    language: str | None
    emotion: str | None
    correlation_id: str | None
    metadata: dict[str, Any]

    @classmethod
    def from_domain(cls, result: TTSResult) -> "SynthesizeResultDTO":
        emotion = result.emotion.value if getattr(result.emotion, "value", None) else None
        return cls(
            audio=result.audio,
            format=result.format,
            sample_rate=result.sample_rate,
            duration=result.duration,
            provider=result.provider,
            processing_time=result.processing_time,
            voice_id=result.voice_id,
            voice_name=result.voice_name,
            text_length=result.text_length,
            language=result.language,
            emotion=emotion,
            correlation_id=result.correlation_id,
            metadata=result.metadata or {},
        )
