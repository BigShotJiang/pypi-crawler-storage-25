"""Application DTOs for vision-language processing."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from narrative_ai.engines.vlm.types import CaptionResult, ProcessingError


@dataclass(slots=True)
class CaptionCommand:
    """Command payload for image captioning."""

    image: str | Path | bytes | Any
    prompt: str | None = None
    user_id: Any | None = None
    tenant_id: Any | None = None
    correlation_id: str | None = None


@dataclass(slots=True)
class CaptionResultDTO:
    """Serializable captioning result."""

    caption: str
    confidence: float | None
    model: str
    model_version: str | None
    correlation_id: str | None = None

    @classmethod
    def from_domain(
        cls,
        result: CaptionResult,
        correlation_id: str | None = None,
    ) -> "CaptionResultDTO":
        return cls(
            caption=result.caption,
            confidence=result.caption_confidence,
            model=result.caption_model,
            model_version=result.caption_model_version,
            correlation_id=correlation_id,
        )


@dataclass(slots=True)
class CaptionErrorDTO:
    """Serializable captioning failure details."""

    component: str
    error_type: str
    message: str
    recoverable: bool = True

    @classmethod
    def from_domain(cls, error: ProcessingError) -> "CaptionErrorDTO":
        return cls(
            component=error.component,
            error_type=error.error_type,
            message=error.message,
            recoverable=error.recoverable,
        )
