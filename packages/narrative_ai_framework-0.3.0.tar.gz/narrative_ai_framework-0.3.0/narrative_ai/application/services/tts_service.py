"""Application service wrapper for the TTS engine."""

from __future__ import annotations

from typing import Any

from narrative_ai.application.dto.tts_dto import SynthesizeCommand, SynthesizeResultDTO
from narrative_ai.domain.domain_services.tts_engine import TTSServiceInterface


class TTSAppService:
    """Coordinates TTS requests and response mapping."""

    def __init__(self, tts_engine: TTSServiceInterface):
        self._tts_engine = tts_engine

    async def synthesize(self, command: SynthesizeCommand) -> SynthesizeResultDTO:
        """Synthesize speech from text."""
        text = command.text.strip()
        if not text:
            raise ValueError("text must not be empty")
        result = await self._tts_engine.synthesize(
            text=text,
            voice_id=command.voice_id,
            language=command.language,
            emotion=command.emotion,
            output_format=command.output_format,
            provider=command.provider,
            user_id=command.user_id,
            tenant_id=command.tenant_id,
            correlation_id=command.correlation_id,
        )
        return SynthesizeResultDTO.from_domain(result)

    async def list_voices(self, provider: str | None = None) -> list[dict[str, Any]]:
        """List available voices in a flattened response."""
        providers_map = await self._tts_engine.get_voices(provider=provider)
        rows: list[dict[str, Any]] = []
        for provider_name, voices in providers_map.items():
            for voice in voices:
                rows.append(
                    {
                        "voice_id": getattr(voice, "voice_id", "") or getattr(voice, "id", ""),
                        "name": getattr(voice, "name", "unknown"),
                        "provider": provider_name,
                        "language": getattr(voice, "language", None),
                        "gender": getattr(voice, "gender", None),
                        "description": getattr(voice, "description", None),
                    }
                )
        return rows

    async def status(self) -> dict:
        """Return TTS health payload."""
        return await self._tts_engine.health_check()

    async def shutdown(self) -> None:
        """Shutdown wrapped engine."""
        await self._tts_engine.shutdown()
