"""Application service wrapper for the STT engine."""

from __future__ import annotations

from narrative_ai.application.dto.stt_dto import TranscribeCommand, TranscriptionResultDTO
from narrative_ai.domain.domain_services.stt_engine import STTServiceInterface


class STTAppService:
    """Coordinates STT requests and validation."""

    def __init__(self, stt_engine: STTServiceInterface):
        self._stt_engine = stt_engine

    async def transcribe(self, command: TranscribeCommand) -> TranscriptionResultDTO:
        """Transcribe a full audio payload."""
        if not command.audio:
            raise ValueError("audio must not be empty")

        result = await self._stt_engine.transcribe(
            audio=command.audio,
            sample_rate=command.sample_rate,
            language=command.language,
            extract_emotion=command.extract_emotion,
            use_vad=command.use_vad,
            provider=command.provider,
            user_id=command.user_id,
            tenant_id=command.tenant_id,
            user_tier=command.user_tier,
            correlation_id=command.correlation_id,
        )
        return TranscriptionResultDTO.from_domain(result)

    async def status(self) -> dict:
        """Return STT health payload."""
        return await self._stt_engine.health_check()

    async def shutdown(self) -> None:
        """Shutdown wrapped engine."""
        await self._stt_engine.shutdown()
