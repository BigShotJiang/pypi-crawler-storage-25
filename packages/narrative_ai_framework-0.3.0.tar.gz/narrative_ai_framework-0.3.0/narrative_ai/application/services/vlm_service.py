"""Application service wrapper for the VLM engine."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from narrative_ai.application.dto.vlm_dto import CaptionCommand, CaptionErrorDTO, CaptionResultDTO
from narrative_ai.domain.domain_services.vlm_engine import VLMServiceInterface

logger = logging.getLogger(__name__)


class VLMAppService:
    """Coordinates VLM requests with bounded concurrency."""

    def __init__(self, vlm_engine: VLMServiceInterface, max_concurrency: int = 2):
        self._vlm_engine = vlm_engine
        self._semaphore = asyncio.Semaphore(max(1, max_concurrency))

    async def caption(self, command: CaptionCommand) -> CaptionResultDTO:
        """Generate a caption for an image input."""
        self._validate_image(command.image)
        async with self._semaphore:
            result, error = await self._vlm_engine.process(
                image=command.image,
                prompt=command.prompt,
                user_id=command.user_id,
                tenant_id=command.tenant_id,
                correlation_id=command.correlation_id,
            )

        if error is not None:
            err = CaptionErrorDTO.from_domain(error)
            raise RuntimeError(f"VLM captioning failed ({err.error_type}): {err.message}")
        if result is None:
            raise RuntimeError("VLM captioning returned no result")
        return CaptionResultDTO.from_domain(result, correlation_id=command.correlation_id)

    async def status(self) -> dict[str, Any]:
        """Return lightweight VLM status metadata."""
        config = getattr(self._vlm_engine, "config", None)
        provider = getattr(config, "provider", "unknown")
        return {
            "status": "healthy",
            "provider": provider,
        }

    def _validate_image(self, image: object) -> None:
        if image is None:
            raise ValueError("image is required")
        if isinstance(image, (bytes, bytearray)) and not image:
            raise ValueError("image must not be empty")
