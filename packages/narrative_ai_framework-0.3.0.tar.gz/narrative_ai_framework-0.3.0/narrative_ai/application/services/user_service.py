"""User application service -- register, authenticate, get profile.

Encapsulates user/auth use cases. Uses domain repository and injected
password hashing so the application layer stays free of infrastructure.
All methods are designed for security: timing-safe authentication,
normalized inputs, and no sensitive data in logs.
"""

from __future__ import annotations

import logging
import uuid
from typing import Callable

from narrative_ai.domain.entities.user import User
from narrative_ai.domain.exceptions import (
    AccountDeactivatedError,
    InvalidCredentialsError,
    UserAlreadyExistsError,
    UserNotFoundError,
)
from narrative_ai.domain.repositories.user_repository import UserRepository

logger = logging.getLogger(__name__)

# Dummy bcrypt hash for timing-safe comparison when user does not exist
_DUMMY_HASH = "$2b$12$dummy.hash.to.prevent.timing.attack.leakage"

# Max display name length (aligned with API schema)
DISPLAY_NAME_MAX_LENGTH = 128


def _normalize_email(email: str) -> str:
    """Return email stripped and lowercased for consistent lookups."""
    return email.strip().lower()


def _normalize_display_name(raw: str, email: str) -> str:
    """Return display name: trimmed, capped, or email local part if empty."""
    value = (raw or "").strip()[:DISPLAY_NAME_MAX_LENGTH]
    return value or email.split("@")[0] if "@" in email else value or "user"


class UserService:
    """Application service for user and auth use cases.

    Dependencies:
    - user_repo: Port for persisting and loading users.
    - hash_password: Callable that hashes a plain password (injected from infra).
    - verify_password: Callable(plain, hashed) -> bool (injected from infra).

    Security:
    - authenticate() is timing-safe: always runs verify_password so response
      time does not leak whether the email exists.
    - No passwords or tokens are ever logged.
    """

    def __init__(
        self,
        user_repo: UserRepository,
        *,
        hash_password: Callable[[str], str],
        verify_password: Callable[[str, str], bool],
    ) -> None:
        self._repo = user_repo
        self._hash_password = hash_password
        self._verify_password = verify_password

    async def register(
        self,
        email: str,
        password: str,
        display_name: str = "",
    ) -> User:
        """Register a new user.

        Email is normalized (strip, lower). Display name is trimmed and
        capped; if empty, the email local part is used.

        Returns:
            The created user with server-set fields populated.

        Raises:
            UserAlreadyExistsError: If a user with this email already exists.
        """
        normalized_email = _normalize_email(email)
        existing = await self._repo.get_by_email(normalized_email)
        if existing is not None:
            logger.info("Registration rejected: email already exists (email=%s)", normalized_email)
            raise UserAlreadyExistsError()

        name = _normalize_display_name(display_name, normalized_email)
        user = User(
            id=uuid.uuid4(),
            email=normalized_email,
            password_hash=self._hash_password(password),
            display_name=name,
        )
        created = await self._repo.create(user)
        logger.info("User registered successfully (email=%s)", normalized_email)
        return created

    async def authenticate(self, email: str, password: str) -> User:
        """Validate credentials and return the user.

        Timing-safe: always runs verify_password so response time does not
        leak whether the email exists.

        Returns:
            The authenticated user if credentials are valid and account is active.

        Raises:
            InvalidCredentialsError: Wrong password or unknown email.
            AccountDeactivatedError: User exists but account is deactivated.
        """
        normalized_email = _normalize_email(email)
        user = await self._repo.get_by_email(normalized_email)
        password_hash = user.password_hash if user else _DUMMY_HASH

        if not self._verify_password(password, password_hash):
            logger.debug("Authentication failed: invalid credentials (email=%s)", normalized_email)
            raise InvalidCredentialsError()

        if user is None:
            raise InvalidCredentialsError()

        if not user.is_active:
            logger.info("Authentication rejected: account deactivated (email=%s)", normalized_email)
            raise AccountDeactivatedError()

        logger.debug("Authentication succeeded (email=%s)", normalized_email)
        return user

    async def get_by_id(self, user_id: uuid.UUID) -> User:
        """Return user by id.

        Returns:
            The user if found.

        Raises:
            UserNotFoundError: No user with this id exists.
        """
        user = await self._repo.get_by_id(user_id)
        if user is None:
            raise UserNotFoundError()
        return user
