"""Application service wrapper for the RAG engine."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from narrative_ai.application.dto.rag_dto import (
    IndexingResultDTO,
    RecallQuery,
    RecallResponseDTO,
    RecallResultDTO,
    RememberCommand,
)
from narrative_ai.domain.domain_services.rag_service import RAGServiceInterface
from narrative_ai.engines.rag.types import RetrievalResult, RichContext

logger = logging.getLogger(__name__)


class RAGAppService:
    """Coordinates RAG operations and enforces safe write concurrency."""

    def __init__(self, rag_engine: RAGServiceInterface, write_lock: asyncio.Lock | None = None):
        self._rag_engine = rag_engine
        self._write_lock = write_lock or asyncio.Lock()

    async def remember(self, command: RememberCommand) -> IndexingResultDTO:
        """Index a document into memory with a write lock."""
        async with self._write_lock:
            result = await self._rag_engine.remember(
                document=command.document,
                doc_id=command.doc_id,
                user_id=command.user_id,
                tenant_id=command.tenant_id,
                correlation_id=command.correlation_id,
            )
        return IndexingResultDTO.from_domain(result)

    async def recall(self, query: RecallQuery) -> RecallResponseDTO:
        """Retrieve ranked context for a query."""
        normalized_query = query.query.strip()
        if not normalized_query:
            raise ValueError("query must not be empty")
        top_k = max(1, min(query.top_k, 100))

        result = await self._rag_engine.recall(
            query=normalized_query,
            top_k=top_k,
            filters=query.filters,
            return_context=query.return_context,
            user_id=query.user_id,
            tenant_id=query.tenant_id,
            correlation_id=query.correlation_id,
        )

        if isinstance(result, RichContext):
            return RecallResponseDTO.from_context(result)
        if isinstance(result, list):
            return self._from_results(normalized_query, result)

        raise TypeError(f"Unsupported RAG recall result type: {type(result)!r}")

    async def forget(self, doc_id: str, user_id: str | None = None) -> bool:
        """Delete indexed chunks for a document with a write lock."""
        if not doc_id.strip():
            raise ValueError("doc_id must not be empty")
        async with self._write_lock:
            return await self._rag_engine.forget(doc_id.strip(), user_id=user_id)

    async def status(self) -> dict[str, Any]:
        """Return lightweight health/status metadata."""
        strategy = getattr(getattr(self._rag_engine, "strategy", None), "name", "unknown")
        provider = type(getattr(self._rag_engine, "embedding_provider", None)).__name__
        store = type(getattr(self._rag_engine, "vector_store", None)).__name__
        return {
            "status": "healthy",
            "strategy": strategy,
            "embedding_provider": provider,
            "vector_store": store,
        }

    def _from_results(self, query: str, results: list[RetrievalResult]) -> RecallResponseDTO:
        """Normalize plain retrieval results into the response DTO."""
        mapped = [RecallResultDTO.from_domain(item) for item in results]
        return RecallResponseDTO(
            query=query,
            formatted_text="\n\n".join(item.text for item in mapped),
            media_references=[item.media_ref for item in mapped if item.media_ref],
            results=mapped,
            strategy_used="default",
            total_retrieved=len(mapped),
        )
