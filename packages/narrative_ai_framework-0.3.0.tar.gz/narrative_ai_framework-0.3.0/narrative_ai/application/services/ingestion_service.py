"""Application service wrapper for the ingestion pipeline."""

from __future__ import annotations

import asyncio
from typing import Any

from narrative_ai.application.dto.ingestion_dto import ProcessAudioCommand, ProcessCommand, ProcessResultDTO
from narrative_ai.domain.domain_services.ingestion_engine import IngestionServiceInterface


class IngestionAppService:
    """Coordinates ingestion requests with bounded concurrency."""

    def __init__(self, ingestion_engine: IngestionServiceInterface, max_concurrency: int = 3):
        self._ingestion_engine = ingestion_engine
        self._semaphore = asyncio.Semaphore(max(1, max_concurrency))

    async def process(self, command: ProcessCommand) -> ProcessResultDTO:
        """Process any supported source into a structured document."""
        async with self._semaphore:
            document = await self._ingestion_engine.process(
                source=command.source,
                enable_image_processing=command.enable_image_processing,
                enable_audio_processing=command.enable_audio_processing,
                user_id=command.user_id,
                tenant_id=command.tenant_id,
                correlation_id=command.correlation_id,
            )
        return ProcessResultDTO.from_domain(document)

    async def process_audio(self, command: ProcessAudioCommand) -> ProcessResultDTO:
        """Process an audio source into a structured document."""
        async with self._semaphore:
            document = await self._ingestion_engine.process_audio(
                source=command.source,
                language=command.language,
                user_id=command.user_id,
                tenant_id=command.tenant_id,
                correlation_id=command.correlation_id,
            )
        return ProcessResultDTO.from_domain(document)

    async def status(self) -> dict[str, Any]:
        """Return lightweight ingestion status metadata."""
        version = getattr(self._ingestion_engine, "version", "unknown")
        return {
            "status": "healthy",
            "version": version,
        }
