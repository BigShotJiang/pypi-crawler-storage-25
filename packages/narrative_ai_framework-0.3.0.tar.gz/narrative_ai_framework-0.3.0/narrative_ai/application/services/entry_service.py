"""Entry application service -- orchestrates entry use cases.

Encapsulates all entry-related business flows: create, list, get,
update, delete, voice pipeline, text pipeline, and enhancement.
Uses domain events for side-effect decoupling.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Any, List, Optional

from narrative_ai.domain.entities.diary_entry import DiaryEntry, SourceType
from narrative_ai.domain.events import EntryCreated, EntryDeleted, EntryUpdated, get_event_bus
from narrative_ai.domain.exceptions import (
    EntryNotFoundError,
    NoSpeechDetectedError,
    ServiceUnavailableError,
)
from narrative_ai.domain.repositories.entry_repository import EntryRepository
from narrative_ai.engines.input_processor.types import (
    BlockMetadata,
    ContentBlock,
    ContentBlockType,
    DocumentMetadata,
    SourceMetadata,
    StructuredDocument,
)
from narrative_ai.engines.rag.cache import get_rag_context_cache, get_rag_response_cache

logger = logging.getLogger(__name__)


class EntryService:
    """Application service for diary entry use cases.

    Dependencies:
    - entry_repo: Required. Persists and retrieves entries.
    - entry_processor: Optional. LLM-based enrichment (enhance, emotion, tags).
    - stt_engine: Optional. Speech-to-text for voice pipelines.
    """

    def __init__(
        self,
        entry_repo: EntryRepository,
        *,
        entry_processor: Any = None,
        stt_engine: Any = None,
        profile_service: Any = None,
        rag_engine: Any = None,
    ) -> None:
        self._repo = entry_repo
        self._processor = entry_processor
        self._stt = stt_engine
        self._profile_service = profile_service  # Optional UserProfileService
        self._rag = rag_engine  # Optional RAG engine for entry indexing

    @staticmethod
    def _entry_doc_id(entry_id: uuid.UUID) -> str:
        return f"entry_{entry_id}"

    def _build_rag_document(self, entry: DiaryEntry) -> Optional[StructuredDocument]:
        text = (entry.enhanced_text or entry.raw_text or "").strip()
        if not text:
            return None

        source = SourceMetadata(
            source_type="raw_text",
            file_name=f"entry-{entry.id}.txt",
        )
        metadata = DocumentMetadata(
            source=source,
            total_blocks=1,
            title=f"Diary Entry {entry.id}",
        )
        block = ContentBlock(
            block_id=f"{entry.id}-b0",
            type=ContentBlockType.TEXT.value,
            content=text,
            metadata=BlockMetadata(
                extra={
                    "entry_id": str(entry.id),
                    "created_at": entry.created_at.isoformat() if entry.created_at else None,
                    "emotion": entry.emotion,
                    "tags": entry.tags or [],
                    "source_type": entry.source_type.value
                    if isinstance(entry.source_type, SourceType)
                    else str(entry.source_type),
                }
            ),
        )
        return StructuredDocument(
            doc_id=self._entry_doc_id(entry.id),
            metadata=metadata,
            content_blocks=[block],
        )

    async def _index_entry_in_rag(self, entry: DiaryEntry, *, replace_existing: bool = False) -> bool:
        if self._rag is None:
            return False

        document = self._build_rag_document(entry)
        if document is None:
            return False

        doc_id = self._entry_doc_id(entry.id)
        try:
            if replace_existing:
                await self._rag.forget(doc_id)
            await self._rag.remember(
                document=document,
                doc_id=doc_id,
                user_id=entry.user_id,
            )
            return True
        except Exception as exc:
            logger.warning("RAG indexing failed for entry %s: %s", entry.id, exc)
            return False

    @staticmethod
    def _invalidate_rag_caches_for_user(user_id: uuid.UUID) -> None:
        """Clear user-scoped RAG caches after diary mutations."""
        uid = str(user_id)
        context_deleted = get_rag_context_cache().invalidate_user(uid)
        response_deleted = get_rag_response_cache().invalidate_user(uid)
        if context_deleted or response_deleted:
            logger.debug(
                "Invalidated RAG caches for user %s (context=%d, response=%d)",
                uid,
                context_deleted,
                response_deleted,
            )

    async def backfill_user_entries_to_rag(
        self,
        user_id: uuid.UUID,
        *,
        batch_size: int = 100,
        max_entries: int = 1000,
    ) -> int:
        """Index existing user entries into RAG (used for one-time bootstrap/migrations)."""
        if self._rag is None:
            return 0

        batch_size = max(1, batch_size)
        max_entries = max(1, max_entries)

        indexed = 0
        offset = 0

        while indexed < max_entries:
            take = min(batch_size, max_entries - indexed)
            entries = await self._repo.list_entries(
                user_id=user_id,
                offset=offset,
                limit=take,
            )
            if not entries:
                break

            for entry in entries:
                ok = await self._index_entry_in_rag(entry, replace_existing=False)
                if ok:
                    indexed += 1
                if indexed >= max_entries:
                    break

            offset += len(entries)
            if len(entries) < take:
                break

        logger.info("RAG backfill completed for user %s: indexed_entries=%d", user_id, indexed)
        return indexed

    # ------------------------------------------------------------------
    # CRUD
    # ------------------------------------------------------------------

    async def create(
        self,
        user_id: uuid.UUID,
        raw_text: str,
        *,
        enhanced_text: str = "",
        emotion: str = "neutral",
        source_type: SourceType = SourceType.TEXT,
        tags: Optional[List[str]] = None,
        audio_storage_path: Optional[str] = None,
    ) -> DiaryEntry:
        """Create a new diary entry."""
        entry = DiaryEntry(
            id=uuid.uuid4(),
            user_id=user_id,
            raw_text=raw_text,
            enhanced_text=enhanced_text or raw_text,
            emotion=emotion,
            source_type=source_type,
            tags=tags or [],
            audio_storage_path=audio_storage_path,
        )
        created = await self._repo.create(entry)
        await get_event_bus().publish(
            EntryCreated(
                entry_id=created.id,
                user_id=created.user_id,
                source_type=source_type.value,
            )
        )
        # Invalidate profile cache so next chat reflects new entry
        if self._profile_service is not None:
            await self._profile_service.invalidate_profile(user_id)
        await self._index_entry_in_rag(created, replace_existing=False)
        self._invalidate_rag_caches_for_user(user_id)
        return created

    async def list_entries(
        self,
        user_id: uuid.UUID,
        *,
        offset: int = 0,
        limit: int = 20,
        emotion: Optional[str] = None,
        tag: Optional[str] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
    ) -> tuple[List[DiaryEntry], int]:
        """List entries with optional filters. Returns (entries, total_count)."""
        entries = await self._repo.list_entries(
            user_id=user_id,
            offset=offset,
            limit=limit,
            emotion=emotion,
            tag=tag,
            date_from=date_from,
            date_to=date_to,
        )
        total = await self._repo.count(
            user_id=user_id,
            emotion=emotion,
            tag=tag,
            date_from=date_from,
            date_to=date_to,
        )
        return entries, total

    async def get_by_id(self, entry_id: uuid.UUID, user_id: uuid.UUID) -> DiaryEntry:
        """Get an entry by ID. Raises EntryNotFoundError if not found."""
        entry = await self._repo.get_by_id(entry_id, user_id=user_id)
        if entry is None:
            raise EntryNotFoundError(entry_id=entry_id, user_id=user_id)
        return entry

    async def update(
        self,
        entry_id: uuid.UUID,
        user_id: uuid.UUID,
        *,
        enhanced_text: Optional[str] = None,
        tags: Optional[List[str]] = None,
        emotion: Optional[str] = None,
    ) -> DiaryEntry:
        """Update an entry. Raises EntryNotFoundError if not found."""
        existing = await self._repo.get_by_id(entry_id, user_id=user_id)
        if existing is None:
            raise EntryNotFoundError(entry_id=entry_id, user_id=user_id)

        if enhanced_text is not None:
            existing.enhanced_text = enhanced_text
        if tags is not None:
            existing.tags = [t.strip().lower() for t in tags if t.strip()]
        if emotion is not None:
            existing.emotion = emotion

        updated = await self._repo.update(existing)
        await get_event_bus().publish(EntryUpdated(entry_id=updated.id, user_id=updated.user_id))
        if self._profile_service is not None:
            await self._profile_service.invalidate_profile(user_id)
        await self._index_entry_in_rag(updated, replace_existing=True)
        self._invalidate_rag_caches_for_user(user_id)
        return updated

    async def delete(self, entry_id: uuid.UUID, user_id: uuid.UUID) -> None:
        """Soft-delete an entry. Raises EntryNotFoundError if not found."""
        existing = await self._repo.get_by_id(entry_id, user_id=user_id)
        if existing is None:
            raise EntryNotFoundError(entry_id=entry_id, user_id=user_id)

        await self._repo.soft_delete(entry_id, user_id=user_id)
        await get_event_bus().publish(EntryDeleted(entry_id=entry_id, user_id=user_id))
        if self._profile_service is not None:
            await self._profile_service.invalidate_profile(user_id)
        if self._rag is not None:
            doc_id = self._entry_doc_id(entry_id)
            try:
                await self._rag.forget(doc_id)
            except Exception as exc:
                logger.warning("RAG delete sync failed for entry %s: %s", entry_id, exc)
        self._invalidate_rag_caches_for_user(user_id)

    # ------------------------------------------------------------------
    # Pipeline: voice
    # ------------------------------------------------------------------

    async def create_from_voice(
        self,
        user_id: uuid.UUID,
        pcm_bytes: bytes,
        sample_rate: int,
        *,
        language: Optional[str] = None,
        extract_emotion: bool = True,
        correlation_id: Optional[str] = None,
    ) -> DiaryEntry:
        """Create entry from voice (STT). Requires STT engine."""
        if self._stt is None:
            raise ServiceUnavailableError("STT engine is not available")

        result = await self._stt.transcribe(
            audio=pcm_bytes,
            sample_rate=sample_rate,
            language=language,
            extract_emotion=extract_emotion,
            use_vad=True,
            user_id=str(user_id),
            correlation_id=correlation_id,
        )

        if not result.text.strip():
            raise NoSpeechDetectedError()

        emotion = "neutral"
        if result.emotion:
            emotion = result.emotion.value if hasattr(result.emotion, "value") else str(result.emotion)

        return await self.create(
            user_id=user_id,
            raw_text=result.text,
            emotion=emotion,
            source_type=SourceType.VOICE,
        )

    async def create_from_voice_enhanced(
        self,
        user_id: uuid.UUID,
        pcm_bytes: bytes,
        sample_rate: int,
        *,
        language: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> DiaryEntry:
        """Create entry from voice with LLM enhancement."""
        created = await self.create_from_voice(
            user_id=user_id,
            pcm_bytes=pcm_bytes,
            sample_rate=sample_rate,
            language=language,
            extract_emotion=True,
            correlation_id=correlation_id,
        )

        if self._processor is not None:
            try:
                enrichment = await self._processor.process_entry(
                    raw_text=created.raw_text,
                    detect_emotion=False,
                    enhance=True,
                    generate_tags=True,
                    existing_emotion=created.emotion,
                    user_id=str(user_id),
                    correlation_id=correlation_id,
                )
                created.enhanced_text = enrichment["enhanced_text"]
                if enrichment.get("tags"):
                    created.tags = enrichment["tags"]
                created = await self._repo.update(created)
                await get_event_bus().publish(EntryUpdated(entry_id=created.id, user_id=created.user_id))
            except Exception as exc:
                logger.warning(
                    "LLM enhancement failed (entry saved without enhancement): %s",
                    exc,
                )

        return created

    # ------------------------------------------------------------------
    # Pipeline: text
    # ------------------------------------------------------------------

    async def create_from_text(
        self,
        user_id: uuid.UUID,
        raw_text: str,
        *,
        enhance: bool = False,
        detect_emotion: bool = False,
        generate_tags: bool = False,
        correlation_id: Optional[str] = None,
    ) -> DiaryEntry:
        """Create entry from text with optional LLM processing."""
        emotion = "neutral"
        enhanced_text = ""
        tags: List[str] = []

        if self._processor is not None and (detect_emotion or enhance or generate_tags):
            try:
                enrichment = await self._processor.process_entry(
                    raw_text=raw_text,
                    detect_emotion=detect_emotion,
                    enhance=enhance,
                    generate_tags=generate_tags,
                    user_id=str(user_id),
                    correlation_id=correlation_id,
                )
                emotion = enrichment["emotion"]
                enhanced_text = enrichment.get("enhanced_text", "")
                tags = enrichment.get("tags", [])
            except Exception as exc:
                logger.warning(
                    "LLM processing failed (saving entry without enrichment): %s",
                    exc,
                )

        return await self.create(
            user_id=user_id,
            raw_text=raw_text,
            enhanced_text=enhanced_text or raw_text,
            emotion=emotion,
            source_type=SourceType.TEXT,
            tags=tags if tags else None,
        )

    # ------------------------------------------------------------------
    # Pipeline: enhance existing
    # ------------------------------------------------------------------

    async def enhance_entry(
        self,
        entry_id: uuid.UUID,
        user_id: uuid.UUID,
        *,
        correlation_id: Optional[str] = None,
    ) -> DiaryEntry:
        """Enhance an existing entry with LLM.

        Raises EntryNotFoundError if not found, ServiceUnavailableError if LLM
        engine is unavailable.
        """
        existing = await self.get_by_id(entry_id, user_id)

        if self._processor is None:
            raise ServiceUnavailableError("LLM engine is not available. Cannot enhance entry.")

        enrichment = await self._processor.process_entry(
            raw_text=existing.raw_text,
            detect_emotion=(existing.emotion == "neutral"),
            enhance=True,
            generate_tags=True,
            existing_emotion=existing.emotion,
            user_id=str(user_id),
            correlation_id=correlation_id,
        )

        existing.enhanced_text = enrichment.get("enhanced_text", existing.enhanced_text)
        if enrichment.get("emotion") != "neutral" or existing.emotion == "neutral":
            existing.emotion = enrichment.get("emotion", existing.emotion)
        if enrichment.get("tags"):
            existing.tags = enrichment["tags"]

        updated = await self._repo.update(existing)
        await get_event_bus().publish(EntryUpdated(entry_id=updated.id, user_id=updated.user_id))
        await self._index_entry_in_rag(updated, replace_existing=True)
        self._invalidate_rag_caches_for_user(user_id)
        return updated
