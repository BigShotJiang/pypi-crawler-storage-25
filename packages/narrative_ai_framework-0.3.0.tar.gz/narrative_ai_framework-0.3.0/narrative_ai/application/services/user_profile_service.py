"""User Profile Service.

Builds and manages the per-user profile snapshot that is injected into
every LLM system prompt.

Flow:
  1. get_profile(user_id) → check UserProfileCache
  2. Cache HIT  → return snapshot immediately
  3. Cache MISS → call entry_repo.get_user_stats(user_id)
               → build UserProfileSnapshot
               → store in cache
               → return snapshot

Invalidation:
  Call invalidate_profile(user_id) from EntryService whenever the user
  creates, updates, or deletes a diary entry.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Dict

from narrative_ai.infrastructure.cache.user_profile_cache import (
    UserProfileCache,
    UserProfileSnapshot,
)

logger = logging.getLogger(__name__)


class UserProfileService:
    """Application service for building and caching user profile snapshots."""

    def __init__(
        self,
        entry_repo,  # PostgresEntryRepository — typed loosely to avoid circular imports
        profile_cache: UserProfileCache,
        user_repo=None,  # Optional: for display_name lookup
    ) -> None:
        self._entry_repo = entry_repo
        self._cache = profile_cache
        self._user_repo = user_repo

    async def get_profile(self, user_id: uuid.UUID) -> UserProfileSnapshot:
        """Return the user profile snapshot, building it from DB on cache miss."""
        # 1. Try cache first
        cached = await self._cache.get(user_id)
        if cached is not None:
            return cached

        # 2. Build from DB
        profile = await self._build_profile(user_id)

        # 3. Store in cache
        await self._cache.set(profile)

        return profile

    async def invalidate_profile(self, user_id: uuid.UUID) -> None:
        """Invalidate the cached profile (call after any diary entry mutation)."""
        await self._cache.invalidate(user_id)
        logger.debug("Profile invalidated for user %s", user_id)

    async def get_user_stats(self, user_id: uuid.UUID) -> Dict[str, Any]:
        """
        Return structured stats for DB-only meta responses.

        Uses the same aggregate source as profile building to avoid duplicate
        query logic in API routes.
        """
        return await self._entry_repo.get_user_stats(user_id)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _build_profile(self, user_id: uuid.UUID) -> UserProfileSnapshot:
        """Query the DB and assemble a UserProfileSnapshot."""
        logger.debug("Building profile from DB for user %s", user_id)

        # Fetch aggregated stats from entry repository
        stats = await self._entry_repo.get_user_stats(user_id)

        # Optionally fetch display name
        display_name = str(user_id)[:8]  # fallback
        if self._user_repo is not None:
            try:
                user = await self._user_repo.get_by_id(user_id)
                if user is not None:
                    display_name = user.display_name or display_name
            except Exception as exc:
                logger.warning("Could not fetch display name for user %s: %s", user_id, exc)

        # Detect preferred language from recent entries (simple heuristic)
        preferred_language = stats.get("preferred_language", "en")

        return UserProfileSnapshot(
            user_id=str(user_id),
            display_name=display_name,
            entry_count=stats.get("entry_count", 0),
            top_emotions=stats.get("top_emotions", []),
            top_tags=stats.get("top_tags", []),
            recent_topics=stats.get("recent_topics", []),
            first_entry_date=stats.get("first_entry_date"),
            last_entry_date=stats.get("last_entry_date"),
            preferred_language=preferred_language,
        )
