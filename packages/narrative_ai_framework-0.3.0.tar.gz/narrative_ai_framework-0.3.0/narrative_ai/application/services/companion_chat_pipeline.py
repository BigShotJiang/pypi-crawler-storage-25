"""Shared chat pipeline used by text and voice companion flows.

This keeps one source of truth for:
- intent routing
- user profile injection
- selective RAG augmentation
- DB-only meta responses
- token budgeting
- RAG response caching
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import uuid
from dataclasses import dataclass
from typing import Any, AsyncIterator, Awaitable, Callable, Optional

try:
    from sqlalchemy.exc import SQLAlchemyError
except Exception:  # pragma: no cover - sqlalchemy is optional in some environments
    SQLAlchemyError = None  # type: ignore[assignment]

from narrative_ai.api.dependencies import get_rag_engine, get_web_engine
from narrative_ai.application.services.user_profile_service import UserProfileService
from narrative_ai.engines.companion.intent_classifier import get_intent_classifier
from narrative_ai.engines.llm.base_llm import LLMError
from narrative_ai.engines.llm import ConversationManager, LLMEngine, TokenBudgetManager
from narrative_ai.engines.rag.augmentation import RAGAugmentor
from narrative_ai.infrastructure.cache.user_profile_cache import get_user_profile_cache, UserProfileSnapshot
from narrative_ai.infrastructure.database.repositories.entry_repository_impl import PostgresEntryRepository
from narrative_ai.infrastructure.database.repositories.user_repository_impl import PostgresUserRepository
from narrative_ai.infrastructure.database.session import async_session_scope

logger = logging.getLogger(__name__)

_RAG_BACKFILLED_USERS: set[str] = set()
_PERSONAL_FACT_GUARDRAIL = (
    "When answering questions about the user's personal history, use only the provided user profile "
    "and retrieved diary context. If specific facts are missing, say you do not know yet and ask the "
    "user to save or clarify the information. Do not invent personal facts."
)
_WEB_UNAVAILABLE_GUARDRAIL = (
    "If the user asks for an internet/web lookup and no Web Sources are provided in this turn, "
    "explicitly state that live web search is currently unavailable and ask the user to retry. "
    "Do not reuse or invent URLs from old messages, diary context, or memory."
)
_FORCE_MEMORY_RAG_PATTERNS = re.compile(
    r"""
    # English memory/diary recall signals
    \b(
        diary|journal|entries|entry|notes|memory|memories|
        my\s+(diary|journal|entries|entry|past)|
        what\s+did\s+i\s+(write|say|record|mention|note)|
        from\s+my\s+(diary|journal|entries)|
        based\s+on\s+my\s+(diary|journal|entries)|
        remind\s+me\s+about\s+my\s+(diary|entries|journal)
    )\b
    |
    # Arabic memory/diary recall signals
    \b(
        يومياتي|مذكراتي|مذكرتي|مدخلاتي|سجلاتي|
        ماذا\s+كتبت|وش\s+كتبت|متى\s+كتبت|
        تذكر|تذكّر|ذكرت|سجلت|سجّلت
    )\b
    """,
    re.IGNORECASE | re.VERBOSE,
)


@dataclass
class CompanionChatRequest:
    message: str
    session_id: Optional[str] = None
    system_prompt: Optional[str] = None
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    provider: Optional[str] = None
    user_id: Optional[str] = None
    tenant_id: Optional[str] = None
    correlation_id: Optional[str] = None


@dataclass
class CompanionChatResult:
    session_id: str
    text: str
    finish_reason: str
    provider: str
    model: str
    processing_time: float
    input_tokens: int
    output_tokens: int
    emotion: Optional[str]
    correlation_id: str
    sources: Optional[list[dict[str, Any]]] = None


class CompanionChatPipeline:
    """Reusable orchestration for companion chat."""

    def __init__(
        self,
        engine: LLMEngine,
        conv_manager: ConversationManager,
        rag_engine_getter: Optional[Callable[[], Awaitable[Any]]] = None,
        web_engine_getter: Optional[Callable[[], Awaitable[Any]]] = None,
    ) -> None:
        self._engine = engine
        self._conv_manager = conv_manager
        self._token_budget = TokenBudgetManager(token_estimator=conv_manager.estimate_tokens)
        self._classifier = get_intent_classifier()
        self._rag_engine_getter = rag_engine_getter or get_rag_engine
        self._web_engine_getter = web_engine_getter or get_web_engine
        self._web_enabled = self._env_bool("WEB_INTEL_ENABLED", True)
        self._web_mode = (os.getenv("WEB_INTEL_MODE", "auto") or "auto").strip().lower()
        self._web_timeout_ms = self._env_int("WEB_INTEL_TIMEOUT_MS", 3000)
        self._web_max_results = self._env_int("WEB_INTEL_MAX_RESULTS", 5)
        self._web_context_tokens = self._env_int("WEB_CONTEXT_TOKENS", 1000)
        # Voice sessions need a tighter prompt budget to keep latency predictable.
        self._voice_history_tokens = self._env_int("VOICE_HISTORY_TOKENS", 1800)
        self._voice_history_max_messages = self._env_int("VOICE_HISTORY_MAX_MESSAGES", 16)
        self._voice_summary_trigger_messages = self._env_int("VOICE_SUMMARY_TRIGGER_MESSAGES", 16)
        self._voice_summary_keep_recent = self._env_int("VOICE_SUMMARY_KEEP_RECENT_MESSAGES", 8)
        self._voice_summary_max_tokens = self._env_int("VOICE_SUMMARY_MAX_TOKENS", 260)
        self._voice_system_prompt_tokens = self._env_int("VOICE_SYSTEM_PROMPT_TOKENS", 260)
        self._voice_rag_context_tokens = self._env_int("VOICE_RAG_CONTEXT_TOKENS", 1200)
        self._voice_web_timeout_ms = self._env_int("VOICE_WEB_TIMEOUT_MS", 1500)
        self._voice_web_max_results = self._env_int("VOICE_WEB_MAX_RESULTS", 3)
        self._voice_web_context_tokens = self._env_int("VOICE_WEB_CONTEXT_TOKENS", 700)

    @staticmethod
    def _env_int(name: str, default: int) -> int:
        try:
            return max(1, int(os.getenv(name, str(default))))
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _env_bool(name: str, default: bool) -> bool:
        raw = os.getenv(name)
        if raw is None:
            return default
        return str(raw).strip().lower() in {"1", "true", "yes", "on"}

    @staticmethod
    def _is_voice_session(session_id: Optional[str]) -> bool:
        return bool(session_id and session_id.startswith("voice-"))

    def _needs_profile_for_intent(self, intent: Any) -> bool:
        # Keep profile available for all authenticated turns so identity/context
        # queries ("what is my name?") don't fail when intent falls back to GENERAL.
        _ = intent
        return True

    def _is_web_lookup_enabled(self, intent: Any) -> bool:
        if not self._web_enabled:
            return False
        if self._web_mode == "off":
            return False
        if self._web_mode == "force":
            return True
        needs_web_fn = getattr(self._classifier, "needs_web", None)
        if callable(needs_web_fn):
            try:
                return bool(needs_web_fn(intent))
            except Exception:
                return False
        return False

    @staticmethod
    def _should_force_memory_rag(message: str) -> bool:
        text = (message or "").strip()
        if not text:
            return False
        return bool(_FORCE_MEMORY_RAG_PATTERNS.search(text))

    @staticmethod
    def _build_user_profile_service(db_session: Any) -> UserProfileService:
        entry_repo = PostgresEntryRepository(db_session)
        user_repo = PostgresUserRepository(db_session)
        return UserProfileService(entry_repo, get_user_profile_cache(), user_repo=user_repo)

    async def run(
        self,
        request: CompanionChatRequest,
        *,
        db_session: Any | None = None,
    ) -> CompanionChatResult:
        if not request.message or not request.message.strip():
            raise ValueError("message must not be empty")

        if db_session is not None:
            return await self._run_with_db(request, db_session)

        # No authenticated user context: skip DB session setup for lower latency.
        if not request.user_id:
            return await self._run_with_db(request, None)

        # Voice worker calls this path (outside FastAPI dependency injection).
        try:
            async with async_session_scope() as managed_db:
                return await self._run_with_db(request, managed_db)
        except Exception as exc:
            # Do NOT retry on LLM/provider failures; that causes duplicate calls
            # and doubles quota burn/latency for the same turn.
            if isinstance(exc, LLMError):
                raise

            module_name = getattr(type(exc), "__module__", "") or ""
            is_db_error = bool(SQLAlchemyError and isinstance(exc, SQLAlchemyError)) or module_name.startswith(
                ("sqlalchemy", "psycopg2", "asyncpg")
            )
            if not is_db_error:
                raise

            logger.warning("Could not open DB session for chat pipeline; continuing without DB context: %s", exc)
            return await self._run_with_db(request, None)

    # ------------------------------------------------------------------
    # Helpers: parallel profile + RAG loading
    # ------------------------------------------------------------------

    async def _load_profile(self, db_session: Any, user_uuid: uuid.UUID) -> Optional[UserProfileSnapshot]:
        """Fetch user profile (returns None on failure)."""
        try:
            service = self._build_user_profile_service(db_session)
            return await service.get_profile(user_uuid)
        except Exception as exc:
            logger.warning("Profile load failed (will continue without): %s", exc)
            return None

    async def _load_rag_context(
        self,
        request: CompanionChatRequest,
        user_uuid: uuid.UUID,
        db_session: Any | None,
    ) -> tuple[str, str, Optional[RAGAugmentor]]:
        """Fetch RAG context (returns empty on failure)."""
        try:
            rag_engine = await self._rag_engine_getter()
            if rag_engine is None:
                return "", "", None

            rag_augmentor = RAGAugmentor(rag_engine)
            rag_context_package = await rag_augmentor.get_context(
                query=request.message,
                user_id=str(user_uuid),
                top_k=5,
                max_tokens=self._token_budget.config.rag_context_tokens,
            )
            rag_context = rag_context_package.formatted_text
            rag_context_fingerprint = rag_context_package.context_fingerprint

            # One-time lazy bootstrap for historical users not yet indexed in RAG.
            if not rag_context and db_session is not None and str(user_uuid) not in _RAG_BACKFILLED_USERS:
                try:
                    from narrative_ai.application.services.entry_service import EntryService

                    bootstrap_entry_service = EntryService(
                        PostgresEntryRepository(db_session),
                        rag_engine=rag_engine,
                    )
                    indexed = await bootstrap_entry_service.backfill_user_entries_to_rag(
                        user_uuid,
                        batch_size=100,
                        max_entries=1000,
                    )

                    if indexed > 0:
                        _RAG_BACKFILLED_USERS.add(str(user_uuid))
                        rag_context_package = await rag_augmentor.get_context(
                            query=request.message,
                            user_id=str(user_uuid),
                            top_k=5,
                            max_tokens=self._token_budget.config.rag_context_tokens,
                        )
                        rag_context = rag_context_package.formatted_text
                        rag_context_fingerprint = rag_context_package.context_fingerprint
                except Exception as bootstrap_exc:
                    logger.warning("RAG lazy backfill failed for user %s: %s", user_uuid, bootstrap_exc)

            return rag_context, rag_context_fingerprint, rag_augmentor
        except Exception as exc:
            logger.warning("RAG recall failed, continuing without context: %s", exc)
            return "", "", None

    async def _load_web_context(
        self,
        request: CompanionChatRequest,
        *,
        is_voice_session: bool,
    ) -> tuple[str, list[dict[str, Any]], dict[str, Any]]:
        """Fetch internet search context (returns empty on failure)."""
        try:
            web_engine = await self._web_engine_getter()
            if web_engine is None or not getattr(web_engine, "enabled", True):
                return "", [], {}

            timeout_ms = self._voice_web_timeout_ms if is_voice_session else self._web_timeout_ms
            max_results = self._voice_web_max_results if is_voice_session else self._web_max_results
            result = await web_engine.search(
                request.message,
                max_results=max_results,
                timeout_ms=timeout_ms,
            )
            if not result.sources:
                logger.warning(
                    "Web lookup returned no sources (provider=%s, latency_ms=%.2f, query=%r)",
                    result.provider or "unknown",
                    float(result.latency_ms or 0.0),
                    request.message,
                )
                return (
                    "",
                    [],
                    {
                        "used_web": False,
                        "provider": result.provider,
                        "latency_ms": result.latency_ms,
                        "cache_hit": result.cache_hit,
                    },
                )

            context_tokens = self._voice_web_context_tokens if is_voice_session else self._web_context_tokens
            context_text = self._token_budget.truncate_text(result.formatted_context, context_tokens)
            sources = [
                {
                    "title": src.title,
                    "url": src.url,
                    "domain": src.domain,
                    "snippet": src.snippet,
                    "published_at": src.published_at,
                    "retrieved_at": src.retrieved_at,
                    "score": src.score,
                    "query": src.query,
                }
                for src in result.sources
            ]
            meta = {
                "used_web": True,
                "provider": result.provider,
                "latency_ms": result.latency_ms,
                "cache_hit": result.cache_hit,
            }
            return context_text, sources, meta
        except Exception as exc:
            logger.warning("Web lookup failed, continuing without web context: %s", exc)
            return "", [], {}

    async def _run_with_db(
        self,
        request: CompanionChatRequest,
        db_session: Any | None,
    ) -> CompanionChatResult:
        # Intent classifier is sync; run in thread to avoid blocking the event loop
        intent = await asyncio.to_thread(self._classifier.classify, request.message)

        # Get or create session
        if not request.session_id:
            session_id = await self._conv_manager.create_session_async(
                user_id=request.user_id,
                tenant_id=request.tenant_id,
            )
        else:
            session_id = request.session_id
            if not await self._conv_manager.get_session_async(session_id):
                session_id = await self._conv_manager.create_session_async(
                    user_id=request.user_id,
                    tenant_id=request.tenant_id,
                    session_id=session_id,
                )

        user_uuid: Optional[uuid.UUID] = None
        system_prompt = request.system_prompt or ""

        if request.user_id:
            try:
                user_uuid = uuid.UUID(request.user_id)
            except Exception:
                user_uuid = None

        # ── Parallel profile + RAG + web loading ────────────────────────
        profile: Optional[UserProfileSnapshot] = None
        rag_context = ""
        rag_context_fingerprint = ""
        rag_augmentor: Optional[RAGAugmentor] = None
        profile_service: Optional[UserProfileService] = None
        web_context = ""
        web_sources: list[dict[str, Any]] = []

        needs_profile = user_uuid is not None and db_session is not None and self._needs_profile_for_intent(intent)
        force_memory_rag = self._should_force_memory_rag(request.message)
        needs_rag = user_uuid is not None and (self._classifier.needs_rag(intent) or force_memory_rag)
        is_voice_session = self._is_voice_session(session_id)
        needs_web = self._is_web_lookup_enabled(intent)

        task_keys: list[str] = []
        pending_tasks: list[asyncio.Task[Any]] = []

        if needs_profile:
            task_keys.append("profile")
            pending_tasks.append(asyncio.create_task(self._load_profile(db_session, user_uuid)))
        if needs_rag:
            task_keys.append("rag")
            pending_tasks.append(asyncio.create_task(self._load_rag_context(request, user_uuid, db_session)))
        if needs_web:
            task_keys.append("web")
            pending_tasks.append(
                asyncio.create_task(
                    self._load_web_context(
                        request,
                        is_voice_session=is_voice_session,
                    )
                )
            )

        if pending_tasks:
            results = await asyncio.gather(*pending_tasks)
            resolved = dict(zip(task_keys, results))

            if "profile" in resolved:
                profile = resolved["profile"]
                if profile is not None:
                    profile_service = self._build_user_profile_service(db_session)

            if "rag" in resolved:
                rag_context, rag_context_fingerprint, rag_augmentor = resolved["rag"]
                if not rag_context and force_memory_rag and db_session is not None:
                    rag_context = await self._build_recent_entry_fallback_context(db_session, user_uuid)
                    if rag_context:
                        rag_context_fingerprint = hashlib.sha256(rag_context.encode("utf-8")).hexdigest()

            if "web" in resolved:
                web_context, web_sources, _web_meta = resolved["web"]

        # Inject profile into system prompt
        if profile is not None:
            profile_budget = (
                self._voice_system_prompt_tokens
                if self._is_voice_session(session_id)
                else self._token_budget.config.system_prompt_tokens
            )
            profile_text = self._token_budget.truncate_text(profile.to_system_prompt_text(), profile_budget)
            if system_prompt:
                system_prompt = f"{profile_text}\n\n{system_prompt}"
            else:
                system_prompt = profile_text

        # DB-only meta questions
        if self._classifier.needs_db_only(intent) and profile_service and user_uuid:
            try:
                stats = await profile_service.get_user_stats(user_uuid)
                answer = (
                    f"You have {stats['entry_count']} diary entries in total.\n"
                    f"First entry: {stats['first_entry_date'] or 'N/A'}\n"
                    f"Last entry: {stats['last_entry_date'] or 'N/A'}\n"
                    f"Top emotions: {', '.join(stats['top_emotions']) or 'N/A'}\n"
                    f"Top tags: {', '.join(stats['top_tags']) or 'N/A'}"
                )
                await self._conv_manager.add_message_async(session_id, "user", request.message)
                await self._conv_manager.add_message_async(
                    session_id,
                    "assistant",
                    answer,
                    sources_json=json.dumps(web_sources, ensure_ascii=False) if web_sources else None,
                )
                return CompanionChatResult(
                    session_id=session_id,
                    text=answer,
                    finish_reason="stop",
                    provider="db_direct",
                    model="db_direct",
                    processing_time=0.0,
                    input_tokens=0,
                    output_tokens=0,
                    emotion=None,
                    correlation_id=request.correlation_id or "",
                    sources=web_sources or None,
                )
            except Exception as exc:
                logger.warning("META_QUESTION DB path failed, falling back to LLM: %s", exc)

        final_system_prompt = system_prompt
        if rag_context:
            final_system_prompt = (
                f"{system_prompt}\n\n## Relevant diary entries:\n{rag_context}"
                if system_prompt
                else f"## Relevant diary entries:\n{rag_context}"
            )
        if web_context:
            final_system_prompt = (
                f"{final_system_prompt}\n\n## Web Sources:\n{web_context}"
                if final_system_prompt
                else f"## Web Sources:\n{web_context}"
            )
        elif needs_web:
            final_system_prompt = (
                f"{final_system_prompt}\n\n{_WEB_UNAVAILABLE_GUARDRAIL}"
                if final_system_prompt
                else _WEB_UNAVAILABLE_GUARDRAIL
            )
        if final_system_prompt:
            final_system_prompt = f"{final_system_prompt}\n\n{_PERSONAL_FACT_GUARDRAIL}"
        else:
            final_system_prompt = _PERSONAL_FACT_GUARDRAIL

        if is_voice_session:
            final_system_budget = (
                self._voice_system_prompt_tokens + self._voice_rag_context_tokens + self._voice_web_context_tokens
            )
        else:
            final_system_budget = (
                self._token_budget.config.system_prompt_tokens
                + self._token_budget.config.rag_context_tokens
                + self._web_context_tokens
            )
        final_system_prompt = self._token_budget.truncate_text(final_system_prompt, final_system_budget)

        await self._conv_manager.add_message_async(session_id, "user", request.message)
        if is_voice_session:
            await self._conv_manager.summarize_if_needed_async(
                session_id,
                trigger_message_count=self._voice_summary_trigger_messages,
                keep_recent_messages=self._voice_summary_keep_recent,
                max_summary_tokens=self._voice_summary_max_tokens,
            )
            history_tokens = self._voice_history_tokens
            messages = await self._conv_manager.get_messages_async(
                session_id,
                max_tokens=history_tokens,
            )
            messages = self._token_budget.cap_messages(
                messages,
                max_tokens=history_tokens,
                max_messages=self._voice_history_max_messages,
            )
        else:
            await self._conv_manager.summarize_if_needed_async(session_id)
            messages = await self._conv_manager.get_messages_async(
                session_id,
                max_tokens=self._token_budget.config.history_tokens,
            )
            messages = self._token_budget.cap_messages(messages)

        # Skip LLM if same user question + same retrieved context was already answered.
        if rag_augmentor and rag_context_fingerprint and user_uuid:
            cached_answer = rag_augmentor.get_cached_response(
                query=request.message,
                user_id=str(user_uuid),
                intent=intent.value,
                context_fingerprint=rag_context_fingerprint,
            )
            if cached_answer:
                await self._conv_manager.add_message_async(
                    session_id,
                    "assistant",
                    cached_answer,
                    sources_json=json.dumps(web_sources, ensure_ascii=False) if web_sources else None,
                )
                return CompanionChatResult(
                    session_id=session_id,
                    text=cached_answer,
                    finish_reason="stop",
                    provider="rag_answer_cache",
                    model="rag_answer_cache",
                    processing_time=0.0,
                    input_tokens=0,
                    output_tokens=0,
                    emotion=None,
                    correlation_id=request.correlation_id or "",
                    sources=web_sources or None,
                )

        result = await self._engine.generate(
            messages=messages,
            system_prompt=final_system_prompt or None,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            provider=request.provider,
            user_id=request.user_id,
            tenant_id=request.tenant_id,
            correlation_id=request.correlation_id,
        )

        await self._conv_manager.add_message_async(
            session_id,
            "assistant",
            result.text,
            sources_json=json.dumps(web_sources, ensure_ascii=False) if web_sources else None,
        )

        if rag_augmentor and rag_context_fingerprint and user_uuid:
            rag_augmentor.set_cached_response(
                query=request.message,
                user_id=str(user_uuid),
                intent=intent.value,
                context_fingerprint=rag_context_fingerprint,
                response_text=result.text,
            )

        return CompanionChatResult(
            session_id=session_id,
            text=result.text,
            finish_reason=result.finish_reason,
            provider=result.provider,
            model=result.model,
            processing_time=result.processing_time,
            input_tokens=result.input_tokens,
            output_tokens=result.output_tokens,
            emotion=result.emotion.value if result.emotion else None,
            correlation_id=result.correlation_id or request.correlation_id or "",
            sources=web_sources or None,
        )

    # ------------------------------------------------------------------
    # Streaming variant: yields partial text chunks for progressive TTS
    # ------------------------------------------------------------------

    async def run_streaming(
        self,
        request: CompanionChatRequest,
        *,
        db_session: Any | None = None,
    ) -> AsyncIterator[CompanionChatResult]:
        """Yield partial CompanionChatResult chunks for progressive TTS.

        Performs the same setup as ``run()`` (intent classification, parallel
        profile + RAG loading, session management, cached-answer shortcut)
        but streams LLM output chunk-by-chunk instead of waiting for the
        full generation.
        """
        if not request.message or not request.message.strip():
            raise ValueError("message must not be empty")

        # ── resolve DB session (same logic as run()) ──
        if db_session is None and request.user_id:
            try:
                async with async_session_scope() as managed_db:
                    async for chunk in self._stream_with_db(request, managed_db):
                        yield chunk
                    return
            except Exception as exc:
                if isinstance(exc, LLMError):
                    raise
                module_name = getattr(type(exc), "__module__", "") or ""
                is_db_error = bool(SQLAlchemyError and isinstance(exc, SQLAlchemyError)) or module_name.startswith(
                    ("sqlalchemy", "psycopg2", "asyncpg")
                )
                if not is_db_error:
                    raise
                logger.warning("Could not open DB session for streaming pipeline; continuing without: %s", exc)
                db_session = None

        async for chunk in self._stream_with_db(request, db_session):
            yield chunk

    async def _stream_with_db(
        self,
        request: CompanionChatRequest,
        db_session: Any | None,
    ) -> AsyncIterator[CompanionChatResult]:
        """Core streaming implementation; mirrors ``_run_with_db`` but yields chunks."""
        # Intent classifier is sync; run in thread to avoid blocking the event loop
        intent = await asyncio.to_thread(self._classifier.classify, request.message)

        # Get or create session
        if not request.session_id:
            session_id = await self._conv_manager.create_session_async(
                user_id=request.user_id,
                tenant_id=request.tenant_id,
            )
        else:
            session_id = request.session_id
            if not await self._conv_manager.get_session_async(session_id):
                session_id = await self._conv_manager.create_session_async(
                    user_id=request.user_id,
                    tenant_id=request.tenant_id,
                    session_id=session_id,
                )

        user_uuid: Optional[uuid.UUID] = None
        system_prompt = request.system_prompt or ""
        if request.user_id:
            try:
                user_uuid = uuid.UUID(request.user_id)
            except Exception:
                user_uuid = None

        # ── Parallel profile + RAG + web loading (same as _run_with_db) ──
        profile: Optional[UserProfileSnapshot] = None
        rag_context = ""
        rag_context_fingerprint = ""
        rag_augmentor: Optional[RAGAugmentor] = None
        profile_service: Optional[UserProfileService] = None
        web_context = ""
        web_sources: list[dict[str, Any]] = []

        needs_profile = user_uuid is not None and db_session is not None and self._needs_profile_for_intent(intent)
        force_memory_rag = self._should_force_memory_rag(request.message)
        needs_rag = user_uuid is not None and (self._classifier.needs_rag(intent) or force_memory_rag)
        is_voice_session = self._is_voice_session(session_id)
        needs_web = self._is_web_lookup_enabled(intent)

        task_keys: list[str] = []
        pending_tasks: list[asyncio.Task[Any]] = []

        if needs_profile:
            task_keys.append("profile")
            pending_tasks.append(asyncio.create_task(self._load_profile(db_session, user_uuid)))
        if needs_rag:
            task_keys.append("rag")
            pending_tasks.append(asyncio.create_task(self._load_rag_context(request, user_uuid, db_session)))
        if needs_web:
            task_keys.append("web")
            pending_tasks.append(
                asyncio.create_task(
                    self._load_web_context(
                        request,
                        is_voice_session=is_voice_session,
                    )
                )
            )

        if pending_tasks:
            results = await asyncio.gather(*pending_tasks)
            resolved = dict(zip(task_keys, results))

            if "profile" in resolved:
                profile = resolved["profile"]
                if profile is not None:
                    profile_service = self._build_user_profile_service(db_session)

            if "rag" in resolved:
                rag_context, rag_context_fingerprint, rag_augmentor = resolved["rag"]
                if not rag_context and force_memory_rag and db_session is not None:
                    rag_context = await self._build_recent_entry_fallback_context(db_session, user_uuid)
                    if rag_context:
                        rag_context_fingerprint = hashlib.sha256(rag_context.encode("utf-8")).hexdigest()

            if "web" in resolved:
                web_context, web_sources, _web_meta = resolved["web"]

        # Profile → system prompt
        if profile is not None:
            profile_budget = (
                self._voice_system_prompt_tokens
                if self._is_voice_session(session_id)
                else self._token_budget.config.system_prompt_tokens
            )
            profile_text = self._token_budget.truncate_text(profile.to_system_prompt_text(), profile_budget)
            system_prompt = f"{profile_text}\n\n{system_prompt}" if system_prompt else profile_text

        # DB-only meta answers (yield as single chunk and return)
        if self._classifier.needs_db_only(intent) and profile_service and user_uuid:
            try:
                stats = await profile_service.get_user_stats(user_uuid)
                answer = (
                    f"You have {stats['entry_count']} diary entries in total.\n"
                    f"First entry: {stats['first_entry_date'] or 'N/A'}\n"
                    f"Last entry: {stats['last_entry_date'] or 'N/A'}\n"
                    f"Top emotions: {', '.join(stats['top_emotions']) or 'N/A'}\n"
                    f"Top tags: {', '.join(stats['top_tags']) or 'N/A'}"
                )
                await self._conv_manager.add_message_async(session_id, "user", request.message)
                await self._conv_manager.add_message_async(
                    session_id,
                    "assistant",
                    answer,
                    sources_json=json.dumps(web_sources, ensure_ascii=False) if web_sources else None,
                )
                yield CompanionChatResult(
                    session_id=session_id,
                    text=answer,
                    finish_reason="stop",
                    provider="db_direct",
                    model="db_direct",
                    processing_time=0.0,
                    input_tokens=0,
                    output_tokens=0,
                    emotion=None,
                    correlation_id=request.correlation_id or "",
                    sources=web_sources or None,
                )
                return
            except Exception as exc:
                logger.warning("META_QUESTION DB path failed, falling back to LLM: %s", exc)

        # Build final system prompt
        final_system_prompt = system_prompt
        if rag_context:
            final_system_prompt = (
                f"{system_prompt}\n\n## Relevant diary entries:\n{rag_context}"
                if system_prompt
                else f"## Relevant diary entries:\n{rag_context}"
            )
        if web_context:
            final_system_prompt = (
                f"{final_system_prompt}\n\n## Web Sources:\n{web_context}"
                if final_system_prompt
                else f"## Web Sources:\n{web_context}"
            )
        elif needs_web:
            final_system_prompt = (
                f"{final_system_prompt}\n\n{_WEB_UNAVAILABLE_GUARDRAIL}"
                if final_system_prompt
                else _WEB_UNAVAILABLE_GUARDRAIL
            )
        if final_system_prompt:
            final_system_prompt = f"{final_system_prompt}\n\n{_PERSONAL_FACT_GUARDRAIL}"
        else:
            final_system_prompt = _PERSONAL_FACT_GUARDRAIL

        if is_voice_session:
            final_system_budget = (
                self._voice_system_prompt_tokens + self._voice_rag_context_tokens + self._voice_web_context_tokens
            )
        else:
            final_system_budget = (
                self._token_budget.config.system_prompt_tokens
                + self._token_budget.config.rag_context_tokens
                + self._web_context_tokens
            )
        final_system_prompt = self._token_budget.truncate_text(final_system_prompt, final_system_budget)

        await self._conv_manager.add_message_async(session_id, "user", request.message)
        if is_voice_session:
            await self._conv_manager.summarize_if_needed_async(
                session_id,
                trigger_message_count=self._voice_summary_trigger_messages,
                keep_recent_messages=self._voice_summary_keep_recent,
                max_summary_tokens=self._voice_summary_max_tokens,
            )
            history_tokens = self._voice_history_tokens
            messages = await self._conv_manager.get_messages_async(
                session_id,
                max_tokens=history_tokens,
            )
            messages = self._token_budget.cap_messages(
                messages,
                max_tokens=history_tokens,
                max_messages=self._voice_history_max_messages,
            )
        else:
            await self._conv_manager.summarize_if_needed_async(session_id)
            messages = await self._conv_manager.get_messages_async(
                session_id,
                max_tokens=self._token_budget.config.history_tokens,
            )
            messages = self._token_budget.cap_messages(messages)

        # Cached answer shortcut (yield as single chunk)
        if rag_augmentor and rag_context_fingerprint and user_uuid:
            cached_answer = rag_augmentor.get_cached_response(
                query=request.message,
                user_id=str(user_uuid),
                intent=intent.value,
                context_fingerprint=rag_context_fingerprint,
            )
            if cached_answer:
                await self._conv_manager.add_message_async(
                    session_id,
                    "assistant",
                    cached_answer,
                    sources_json=json.dumps(web_sources, ensure_ascii=False) if web_sources else None,
                )
                yield CompanionChatResult(
                    session_id=session_id,
                    text=cached_answer,
                    finish_reason="stop",
                    provider="rag_answer_cache",
                    model="rag_answer_cache",
                    processing_time=0.0,
                    input_tokens=0,
                    output_tokens=0,
                    emotion=None,
                    correlation_id=request.correlation_id or "",
                    sources=web_sources or None,
                )
                return

        # ── Stream LLM chunks ──
        full_text = ""
        sent_text = ""

        async for partial in self._engine.generate_streaming(
            messages=messages,
            system_prompt=final_system_prompt or None,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            provider=request.provider,
            user_id=request.user_id,
            tenant_id=request.tenant_id,
            correlation_id=request.correlation_id,
        ):
            chunk_text = partial.text or ""
            is_final = bool(getattr(partial, "is_final", False))

            # Only normalize on final chunks. Partial chunks from providers are expected
            # to be deltas; normalizing all chunks can incorrectly strip valid text.
            if is_final and chunk_text and sent_text and chunk_text.startswith(sent_text):
                delta_text = chunk_text[len(sent_text) :]
            else:
                delta_text = chunk_text

            if delta_text:
                sent_text += delta_text
                full_text = sent_text
            elif is_final and chunk_text and not full_text:
                # Defensive: if provider emitted a single final chunk only.
                full_text = chunk_text

            # Preserve final metadata/emotion even when final chunk carries no new delta.
            if delta_text or partial.emotion:
                yield CompanionChatResult(
                    session_id=session_id,
                    text=delta_text,
                    finish_reason=partial.finish_reason or "",
                    provider=partial.provider or "",
                    model=partial.model or "",
                    processing_time=partial.processing_time or 0.0,
                    input_tokens=partial.input_tokens or 0,
                    output_tokens=partial.output_tokens or 0,
                    emotion=partial.emotion.value if partial.emotion else None,
                    correlation_id=partial.correlation_id or request.correlation_id or "",
                    sources=web_sources if is_final else None,
                )

        # ── Post-generation: persist conversation + cache ──
        if full_text:
            await self._conv_manager.add_message_async(
                session_id,
                "assistant",
                full_text,
                sources_json=json.dumps(web_sources, ensure_ascii=False) if web_sources else None,
            )

        if rag_augmentor and rag_context_fingerprint and user_uuid and full_text:
            rag_augmentor.set_cached_response(
                query=request.message,
                user_id=str(user_uuid),
                intent=intent.value,
                context_fingerprint=rag_context_fingerprint,
                response_text=full_text,
            )

    async def _build_recent_entry_fallback_context(
        self,
        db_session: Any,
        user_uuid: uuid.UUID,
        *,
        max_entries: int = 4,
        max_chars: int = 2200,
    ) -> str:
        """Best-effort fallback when RAG recall is empty for diary memory queries.

        Uses recent entries from the primary DB so memory questions still get
        grounded context even if the vector index is cold/unavailable.
        """
        try:
            repo = PostgresEntryRepository(db_session)
            entries = await repo.list_entries(user_id=user_uuid, limit=max_entries)
            if not entries:
                return ""

            lines: list[str] = []
            for idx, entry in enumerate(entries, start=1):
                text = (entry.enhanced_text or entry.raw_text or "").strip()
                if not text:
                    continue
                text = text.replace("\n", " ").strip()
                if len(text) > 380:
                    text = text[:377] + "..."
                created = entry.created_at.isoformat() if entry.created_at else "unknown"
                mood = f" | emotion={entry.emotion}" if entry.emotion else ""
                lines.append(f"[Entry {idx} | {created}{mood}] {text}")

            if not lines:
                return ""
            return self._token_budget.truncate_text("\n".join(lines), max_chars)
        except Exception as exc:
            logger.warning("Recent-entry fallback context failed, continuing without it: %s", exc)
            return ""
