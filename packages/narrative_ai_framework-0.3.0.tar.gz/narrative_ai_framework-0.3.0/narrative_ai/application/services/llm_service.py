"""Application service wrapper for the LLM engine."""

from __future__ import annotations

from narrative_ai.application.dto.llm_dto import ChatCommand, GenerateCommand, GenerateResultDTO
from narrative_ai.domain.domain_services.llm_engine import LLMServiceInterface
from narrative_ai.engines.llm import ConversationManager


class LLMAppService:
    """Coordinates LLM generation and chat workflows."""

    def __init__(
        self,
        llm_engine: LLMServiceInterface,
        conversation_manager: ConversationManager | None = None,
    ):
        self._llm_engine = llm_engine
        self._conversation_manager = conversation_manager or ConversationManager()

    async def generate(self, command: GenerateCommand) -> GenerateResultDTO:
        """Generate a single completion."""
        if not command.prompt and not command.messages:
            raise ValueError("Either prompt or messages must be provided")
        result = await self._llm_engine.generate(
            prompt=command.prompt,
            system_prompt=command.system_prompt,
            messages=command.messages,
            temperature=command.temperature,
            max_tokens=command.max_tokens,
            tools=command.tools,
            tool_choice=command.tool_choice,
            response_format=command.response_format,
            provider=command.provider,
            user_id=command.user_id,
            tenant_id=command.tenant_id,
            correlation_id=command.correlation_id,
        )
        return GenerateResultDTO.from_domain(result)

    async def chat(self, command: ChatCommand) -> GenerateResultDTO:
        """Generate a chat response while managing conversation state."""
        if not command.message.strip():
            raise ValueError("message must not be empty")

        if command.session_id:
            session_id = command.session_id
            if not await self._conversation_manager.get_session_async(session_id):
                session_id = await self._conversation_manager.create_session_async(
                    user_id=command.user_id,
                    tenant_id=command.tenant_id,
                    session_id=session_id,
                )
        else:
            session_id = await self._conversation_manager.create_session_async(
                user_id=command.user_id,
                tenant_id=command.tenant_id,
            )

        await self._conversation_manager.add_message_async(session_id, "user", command.message)
        messages = await self._conversation_manager.get_messages_async(session_id)

        result = await self._llm_engine.generate(
            messages=messages,
            system_prompt=command.system_prompt,
            temperature=command.temperature,
            max_tokens=command.max_tokens,
            provider=command.provider,
            user_id=command.user_id,
            tenant_id=command.tenant_id,
            correlation_id=command.correlation_id,
        )

        await self._conversation_manager.add_message_async(session_id, "assistant", result.text)
        return GenerateResultDTO.from_domain(result, session_id=session_id)

    async def status(self) -> dict:
        """Return LLM health payload."""
        return await self._llm_engine.health_check()
