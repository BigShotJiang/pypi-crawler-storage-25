"""Application layer -- use cases and orchestration.

This layer coordinates domain entities, repositories, and engines
to fulfill use cases. It does not contain business rules (those live
in the domain) or infrastructure details.
"""
