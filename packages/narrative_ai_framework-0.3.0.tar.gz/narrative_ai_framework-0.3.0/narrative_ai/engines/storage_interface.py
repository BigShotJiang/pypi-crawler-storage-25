"""Optional storage interfaces for framework engines.

When the framework is used as a standalone SDK (pip install narrative-ai-framework),
engines operate statelessly by default -- audio in / text out, text in / audio out.

If the consuming application (e.g. the diary app backend) wants the engines to
persist results, it can inject concrete implementations of these interfaces via
dependency injection.  The engines never import SQLAlchemy, Redis, or any
infrastructure code directly.

Example usage from the app backend::

    from narrative_ai.engines.stt import create_stt_engine_from_providers
    from narrative_ai.engines.storage_interface import EntryPersistence

    class MyEntryPersistence(EntryPersistence):
        async def save_entry(self, user_id, raw_text, enhanced_text, emotion, source_type, audio_path):
            # Use your app's repository to persist
            entry = DiaryEntry(...)
            await entry_repo.create(entry)
            return str(entry.id)

    stt_engine = await create_stt_engine_from_providers()
    stt_engine.set_persistence(MyEntryPersistence())

This keeps the engine packages zero-dependency on databases while allowing
the app to plug in persistence where needed.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class EntryPersistence(ABC):
    """Callback interface for persisting diary entries after STT / enhancement."""

    @abstractmethod
    async def save_entry(
        self,
        user_id: str,
        raw_text: str,
        enhanced_text: str,
        emotion: str,
        source_type: str,
        audio_path: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> str:
        """Persist a diary entry and return its ID."""
        ...


class EmbeddingPersistence(ABC):
    """Callback interface for storing embeddings after generation."""

    @abstractmethod
    async def store_embedding(
        self,
        entry_id: str,
        user_id: str,
        embedding: List[float],
    ) -> None: ...

    @abstractmethod
    async def search_similar(
        self,
        query_embedding: List[float],
        user_id: str,
        top_k: int = 5,
    ) -> List[Dict[str, Any]]:
        """Return list of dicts with at least ``entry_id`` and ``similarity``."""
        ...


class ConversationPersistence(ABC):
    """Callback interface for persisting companion chat history."""

    @abstractmethod
    async def save_message(
        self,
        conversation_id: str,
        user_id: str,
        role: str,
        content: str,
        audio_url: Optional[str] = None,
        emotion: Optional[str] = None,
        sources: Optional[str] = None,
    ) -> str:
        """Persist a message and return its ID."""
        ...

    @abstractmethod
    async def get_history(
        self,
        conversation_id: str,
        user_id: str,
        limit: int = 20,
    ) -> List[Dict[str, Any]]:
        """Return recent messages for context."""
        ...


class AudioPersistence(ABC):
    """Callback interface for persisting TTS audio metadata."""

    @abstractmethod
    async def save_audio_metadata(
        self,
        user_id: str,
        file_type: str,
        storage_path: str,
        duration_seconds: float,
        voice_used: Optional[str] = None,
        conversation_id: Optional[str] = None,
    ) -> str:
        """Persist audio metadata and return its ID."""
        ...


class UserPreferenceLookup(ABC):
    """Callback interface for looking up user preferences (voice, language)."""

    @abstractmethod
    async def get_preferences(self, user_id: str) -> Dict[str, Any]:
        """Return user preferences as a dict.

        Expected keys: preferred_voice, speaking_rate, audio_quality, language.
        """
        ...
