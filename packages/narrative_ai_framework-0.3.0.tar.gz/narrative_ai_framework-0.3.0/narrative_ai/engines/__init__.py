"""
Narrative AI Engines Module.

This module provides access to all AI processing engines:
- Input Processing (input_processor)
- Speech-to-Text (stt)
- OCR (ocr)
- Text Enhancement (text_enhancement)
- Embeddings (embeddings)
- RAG Retrieval (rag)
- AI Companion (companion)
- Text-to-Speech (tts)
- Export (export)
- Analytics (analytics)

Note: Use the aliases below for imports.
"""

import importlib
import importlib.util
import sys
from pathlib import Path

# Add engine paths to allow importing numbered modules
_engines_path = Path(__file__).parent

# Create aliases for numbered engine modules
# This allows: from narrative_ai.engines.stt import STTEngine
# Use: from narrative_ai.engines.stt import STTEngine


def _load_engine_module(folder_name: str, alias: str, debug: bool = False):
    """Dynamically load a numbered engine module and create an alias."""
    try:
        init_path = _engines_path / folder_name / "__init__.py"
        if not init_path.exists():
            if debug:
                print(f"[DEBUG] {alias}: __init__.py not found at {init_path}")
            return None

        spec = importlib.util.spec_from_file_location(
            f"narrative_ai.engines.{alias}", init_path, submodule_search_locations=[str(_engines_path / folder_name)]
        )
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            module.__path__ = [str(_engines_path / folder_name)]
            module.__package__ = f"narrative_ai.engines.{alias}"
            sys.modules[f"narrative_ai.engines.{alias}"] = module
            spec.loader.exec_module(module)
            return module
        else:
            if debug:
                print(f"[DEBUG] {alias}: spec or loader is None")
    except Exception as e:
        # Print error for debugging
        if debug:
            print(f"[DEBUG] {alias}: Error loading module: {e}")
            import traceback

            traceback.print_exc()
    return None


# Load engine modules with aliases
stt = _load_engine_module("stt", "stt")
ocr = _load_engine_module("ocr", "ocr")
text_enhancement = _load_engine_module("text_enhancement", "text_enhancement")
embeddings = _load_engine_module("embeddings", "embeddings")
rag = _load_engine_module("rag", "rag")
companion = _load_engine_module("companion", "companion")
tts = _load_engine_module("tts", "tts")
export = _load_engine_module("export", "export")
analytics = _load_engine_module("analytics", "analytics")
llm = _load_engine_module("llm", "llm")
web_intel = _load_engine_module("web_intel", "web_intel")
vlm = _load_engine_module("vlm", "vlm")
voice_mode = _load_engine_module("voice_mode", "voice_mode")
input_processor = _load_engine_module("input_processor", "input_processor")

__all__ = [
    "stt",
    "ocr",
    "text_enhancement",
    "embeddings",
    "rag",
    "companion",
    "tts",
    "export",
    "analytics",
    "llm",
    "web_intel",
    "vlm",
    "voice_mode",
    "input_processor",
]
