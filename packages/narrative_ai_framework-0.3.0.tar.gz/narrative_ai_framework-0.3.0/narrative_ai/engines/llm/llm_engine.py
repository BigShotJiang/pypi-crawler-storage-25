"""
LLM Engine - Main Orchestrator.

Production-ready implementation with:
- Thread-safe metrics using asyncio.Lock
- Correlation ID propagation for distributed tracing
- Async context manager support
- Proper exception chaining
- Structured logging
- Security layer integration
"""

import asyncio
import time
import uuid
import logging
from typing import Optional, Dict, Any, AsyncIterator, List, Union
from collections import deque

from .base_llm import (
    LLMResult,
    LLMError,
    GenerationError,
    RateLimitError,
    get_metrics_exporter,
    FinishReason,
)
from .config import LLMConfig
from .input_processor import InputProcessor
from .llm_strategy import LLMStrategy, CircuitBreakerConfig

logger = logging.getLogger(__name__)


# Security layer imports - optional to allow standalone usage
_SECURITY_AVAILABLE = False
_RATE_LIMITER_AVAILABLE = False
_AUDIT_LOGGER_AVAILABLE = False
_INPUT_VALIDATOR_AVAILABLE = False
_ERROR_HANDLER_AVAILABLE = False

try:
    from narrative_ai.security.rate_limiting import (
        RateLimiter,
        EndpointCosts,
        RateLimitExceeded,
        UserTier,
    )

    _RATE_LIMITER_AVAILABLE = True
except ImportError:
    RateLimiter = None
    EndpointCosts = None
    RateLimitExceeded = None
    UserTier = None

try:
    from narrative_ai.security.audit_trail import AuditLogger, ActionType, ActionStatus

    _AUDIT_LOGGER_AVAILABLE = True
except ImportError:
    AuditLogger = None
    ActionType = None
    ActionStatus = None

try:
    from narrative_ai.security.input_validation import validate_text, ValidationError as InputValidationError

    _INPUT_VALIDATOR_AVAILABLE = True
except ImportError:
    validate_text = None
    InputValidationError = None

try:
    from narrative_ai.security.error_handling import SecureErrorHandler

    _ERROR_HANDLER_AVAILABLE = True
except ImportError:
    SecureErrorHandler = None

_SECURITY_AVAILABLE = any(
    [
        _RATE_LIMITER_AVAILABLE,
        _AUDIT_LOGGER_AVAILABLE,
        _INPUT_VALIDATOR_AVAILABLE,
        _ERROR_HANDLER_AVAILABLE,
    ]
)

if not _SECURITY_AVAILABLE:
    logger.warning("Security layer not available - running without security integration")


class LLMEngine:
    """
    Main LLM Engine - Central orchestrator for Large Language Models.

    Production Features:
    - Thread-safe metrics with asyncio.Lock
    - Correlation ID propagation for tracing
    - Async context manager support (async with)
    - Proper exception chaining
    - Structured logging
    - Security layer integration

    Example:
        # Using context manager (recommended)
        async with LLMEngine() as engine:
            result = await engine.generate(
                prompt="Hello, how are you?",
                correlation_id="req-123",
            )

        # Manual lifecycle management
        engine = LLMEngine()
        await engine.initialize()
        try:
            result = await engine.generate(...)
        finally:
            await engine.shutdown()
    """

    def __init__(
        self,
        config: Optional[LLMConfig] = None,
        circuit_breaker_config: Optional[CircuitBreakerConfig] = None,
    ):
        """
        Initialize LLM Engine.

        Args:
            config: Engine configuration (uses defaults/env if not provided)
            circuit_breaker_config: Circuit breaker configuration
        """
        self.config = config or LLMConfig.from_providers_config()
        self._circuit_breaker_config = circuit_breaker_config

        # Components (lazy initialized)
        self._strategy: Optional[LLMStrategy] = None
        self._input_processor: Optional[InputProcessor] = None

        # Security components (optional)
        self._rate_limiter: Optional[Any] = None
        self._audit_logger: Optional[Any] = None
        self._error_handler: Optional[Any] = None

        # State
        self._initialized = False

        # Thread-safe metrics with lock
        self._metrics_lock = asyncio.Lock()
        self._metrics: Dict[str, Any] = {
            "generations": 0,
            "streaming_sessions": 0,
            "total_processing_time": 0.0,
            "total_input_tokens": 0,
            "total_output_tokens": 0,
            "total_cost": 0.0,  # Total cost in USD
            "cost_by_provider": {},  # Cost per provider
            "errors": 0,
            "errors_by_type": {},  # Error type -> count
            "errors_by_provider": {},  # Provider -> error count
            "errors_by_provider_and_type": {},  # Provider -> error_type -> count
            "latencies": deque(maxlen=10000),  # Bounded deque for percentile calculation (keeps last 10k)
            "latencies_by_provider": {},  # Provider -> deque of latencies
            "ttft_by_provider": {},  # Provider -> deque of time-to-first-token
            "token_usage_by_provider": {},  # Provider -> {"input": total, "output": total}
        }

        # External metrics exporter
        self._external_metrics = get_metrics_exporter()

    async def __aenter__(self) -> "LLMEngine":
        """Async context manager entry."""
        await self.initialize()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.shutdown()

    def _generate_correlation_id(self) -> str:
        """Generate a unique correlation ID for request tracing."""
        return f"llm-{uuid.uuid4().hex[:12]}"

    def _to_uuid(self, val: Any, name: str) -> Optional[uuid.UUID]:
        """
        Convert string/int to UUID for rate limiting and audit.
        Handles non-UUID strings (e.g. session IDs) via uuid5 fallback to prevent crash.
        """
        if val is None:
            return None
        if isinstance(val, uuid.UUID):
            return val
        try:
            return uuid.UUID(str(val))
        except (ValueError, TypeError):
            logger.debug(
                "Converting non-UUID %s to uuid5",
                name,
                extra={"input_preview": str(val)[:50], "name": name},
            )
            return uuid.uuid5(uuid.NAMESPACE_DNS, f"llm.{name}.{val}")

    async def initialize(self) -> None:
        """
        Initialize the engine and all components.

        Call this before using the engine. Safe to call multiple times.
        Implements rollback on partial failure to prevent resource leaks.
        """
        if self._initialized:
            return

        logger.info("Initializing LLM Engine...")
        start_time = time.time()

        # Track initialized components for rollback on failure
        initialized_components = []

        try:
            # Initialize input processor
            self._input_processor = InputProcessor()
            initialized_components.append(("input_processor", self._input_processor))
            logger.info("Input processor initialized")

            # Initialize provider strategy
            self._strategy = LLMStrategy.from_config(self.config)
            if self._circuit_breaker_config:
                self._strategy.set_circuit_breaker_config(self._circuit_breaker_config)
            initialized_components.append(("strategy", self._strategy))
            await self._strategy.initialize()

            # Initialize security components if available and enabled
            if _SECURITY_AVAILABLE:
                import os

                is_production = os.getenv("ENV", "").lower() == "production"
                skip_rate_limit = not is_production and os.getenv("VOICE_DEV_SKIP_RATE_LIMIT", "").strip() == "1"
                if self.config.integration.enable_rate_limiting and RateLimiter and not skip_rate_limit:
                    try:
                        self._rate_limiter = RateLimiter()
                        initialized_components.append(("rate_limiter", self._rate_limiter))
                        logger.info("Rate limiter initialized")
                    except Exception as e:
                        logger.warning(f"Failed to initialize rate limiter: {e}")

                if self.config.integration.enable_audit_logging and AuditLogger:
                    try:
                        import os

                        audit_db_url = os.getenv("AUDIT_DATABASE_URL") or os.getenv("DATABASE_URL")
                        if audit_db_url:
                            self._audit_logger = AuditLogger(database_url=audit_db_url)
                            initialized_components.append(("audit_logger", self._audit_logger))
                            logger.info("Audit logger initialized")
                        else:
                            logger.warning("Audit logging enabled but DATABASE_URL not set")
                    except Exception as e:
                        logger.warning(f"Failed to initialize audit logger: {e}")

                if SecureErrorHandler:
                    try:
                        self._error_handler = SecureErrorHandler()
                        initialized_components.append(("error_handler", self._error_handler))
                        logger.info("Secure error handler initialized")
                    except Exception as e:
                        logger.warning(f"Failed to initialize error handler: {e}")

            self._initialized = True
            init_time = time.time() - start_time
            logger.info(f"LLM Engine initialized in {init_time:.2f}s")

        except Exception as e:
            # Rollback: cleanup what was initialized
            logger.error(
                "LLM Engine initialization failed, cleaning up resources",
                extra={"error": str(e), "error_type": type(e).__name__},
                exc_info=True,
            )

            for name, component in reversed(initialized_components):
                try:
                    if hasattr(component, "shutdown"):
                        await component.shutdown()
                    elif hasattr(component, "close"):
                        if asyncio.iscoroutinefunction(component.close):
                            await component.close()
                        else:
                            component.close()
                    logger.debug(f"Cleaned up {name} during rollback")
                except Exception as cleanup_error:
                    logger.error(
                        f"Failed to cleanup {name} during rollback", extra={"error": str(cleanup_error)}, exc_info=True
                    )

            # Reset state
            self._input_processor = None
            self._strategy = None
            self._rate_limiter = None
            self._audit_logger = None
            self._error_handler = None
            self._initialized = False

            raise

    async def shutdown(self) -> None:
        """
        Shutdown the engine and cleanup resources.

        Shuts down all components in reverse order of initialization
        to ensure proper cleanup and prevent resource leaks.
        """
        if not self._initialized:
            return

        logger.info("Shutting down LLM Engine...")

        shutdown_errors = []

        if self._strategy:
            try:
                await self._strategy.shutdown()
            except Exception as e:
                shutdown_errors.append(("strategy", str(e)))
                logger.error(f"Error shutting down strategy: {e}", exc_info=True)

        # Cleanup security components
        if self._rate_limiter:
            try:
                if hasattr(self._rate_limiter, "shutdown"):
                    await self._rate_limiter.shutdown()
            except Exception as e:
                shutdown_errors.append(("rate_limiter", str(e)))
                logger.error(f"Error shutting down rate limiter: {e}", exc_info=True)

        if self._audit_logger:
            try:
                if hasattr(self._audit_logger, "shutdown"):
                    await self._audit_logger.shutdown()
            except Exception as e:
                shutdown_errors.append(("audit_logger", str(e)))
                logger.error(f"Error shutting down audit logger: {e}", exc_info=True)

        if self._error_handler:
            try:
                if hasattr(self._error_handler, "shutdown"):
                    await self._error_handler.shutdown()
            except Exception as e:
                shutdown_errors.append(("error_handler", str(e)))
                logger.error(f"Error shutting down error handler: {e}", exc_info=True)

        # Reset all references
        self._strategy = None
        self._input_processor = None
        self._rate_limiter = None
        self._audit_logger = None
        self._error_handler = None
        self._initialized = False

        if shutdown_errors:
            logger.warning("Some components failed to shutdown cleanly", extra={"errors": shutdown_errors})
        else:
            logger.info("LLM Engine shutdown complete")

    def _check_rate_limit(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        user_tier: Optional["UserTier"] = None,
    ) -> None:
        """
        Check rate limit if enabled.

        When user_id or tenant_id is None, uses shared anonymous bucket (OWASP API4)
        - all unauthenticated requests share FREE tier limits.

        Raises:
            RateLimitExceeded: If rate limit exceeded
        """
        if not self._rate_limiter:
            return

        try:
            from narrative_ai.security.rate_limiting import UserTier

            def _resolve_uuid(val: Any, name: str, anon_namespace: str) -> uuid.UUID:
                if val is None:
                    return uuid.uuid5(uuid.NAMESPACE_DNS, anon_namespace)
                u = self._to_uuid(val, name)
                return u if u is not None else uuid.uuid5(uuid.NAMESPACE_DNS, anon_namespace)

            anon_ns = "anon.engine.llm"
            user_uuid = _resolve_uuid(user_id, "user", anon_ns)
            tenant_uuid = _resolve_uuid(tenant_id, "tenant", anon_ns)

            # Tier lookup: explicit param > callback (DB/cache) > FREE (secure default)
            if user_tier is not None:
                tier = user_tier
            else:
                cb = getattr(self.config.integration, "user_tier_callback", None)
                if cb and (user_id or tenant_id):
                    try:
                        looked_up = cb(user_id, tenant_id)
                        tier = looked_up if looked_up is not None else UserTier.FREE
                    except Exception as e:
                        logger.debug("User tier lookup failed, using FREE: %s", e)
                        tier = UserTier.FREE
                else:
                    tier = UserTier.FREE

            self._rate_limiter.check_rate_limit(
                tenant_id=tenant_uuid,
                user_id=user_uuid,
                tier=tier,
                endpoint_cost=EndpointCosts.LLM_GENERATE.value,
            )
        except Exception as e:
            # Use isinstance when RateLimitExceeded is available (avoids TypeError when
            # security layer import failed and RateLimitExceeded is None)
            if RateLimitExceeded is not None and isinstance(e, RateLimitExceeded):
                self._external_metrics.increment("llm.rate_limited")
                raise RateLimitError(
                    f"Rate limit exceeded: {getattr(e, 'message', str(e))}",
                    provider="engine",
                    retry_after=getattr(e, "retry_after", None),
                ) from e
            # Fail closed: re-raise on unexpected errors (Redis down, bug, etc.)
            logger.warning(f"Rate limit check failed: {e}")
            raise

    def _track_error(
        self,
        error: Exception,
        provider: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> None:
        """
        Track error with provider-specific details for observability.

        Args:
            error: Exception that occurred
            provider: Provider name (if known)
            correlation_id: Request correlation ID
        """

        async def _track():
            async with self._metrics_lock:
                self._metrics["errors"] += 1

                error_type = type(error).__name__
                self._metrics["errors_by_type"][error_type] = self._metrics["errors_by_type"].get(error_type, 0) + 1

                if provider:
                    # Track errors by provider
                    self._metrics["errors_by_provider"][provider] = (
                        self._metrics["errors_by_provider"].get(provider, 0) + 1
                    )

                    # Track errors by provider and type
                    if provider not in self._metrics["errors_by_provider_and_type"]:
                        self._metrics["errors_by_provider_and_type"][provider] = {}
                    self._metrics["errors_by_provider_and_type"][provider][error_type] = (
                        self._metrics["errors_by_provider_and_type"][provider].get(error_type, 0) + 1
                    )

                # Export to external metrics
                self._external_metrics.increment(
                    "llm.errors.total", tags={"error_type": error_type, "provider": provider or "unknown"}
                )

        # Schedule async tracking (fire and forget)
        try:
            import asyncio

            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(_track())
            else:
                asyncio.run(_track())
        except Exception:
            # Fallback: try sync tracking if async fails
            pass

    def _track_latency(
        self,
        latency: float,
        provider: Optional[str] = None,
    ) -> None:
        """
        Track latency with provider-specific details.

        Args:
            latency: Processing latency in seconds
            provider: Provider name
        """

        async def _track():
            async with self._metrics_lock:
                self._metrics["latencies"].append(latency)

                if provider:
                    if provider not in self._metrics["latencies_by_provider"]:
                        self._metrics["latencies_by_provider"][provider] = deque(maxlen=10000)
                    self._metrics["latencies_by_provider"][provider].append(latency)

                # Export to external metrics
                self._external_metrics.histogram("llm.latency", latency, tags={"provider": provider or "unknown"})

        try:
            import asyncio

            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(_track())
            else:
                asyncio.run(_track())
        except Exception:
            pass

    def _track_token_usage(
        self,
        input_tokens: int,
        output_tokens: int,
        provider: Optional[str] = None,
    ) -> None:
        """
        Track token usage by provider.

        Args:
            input_tokens: Input token count
            output_tokens: Output token count
            provider: Provider name
        """

        async def _track():
            async with self._metrics_lock:
                if provider:
                    if provider not in self._metrics["token_usage_by_provider"]:
                        self._metrics["token_usage_by_provider"][provider] = {
                            "input": 0,
                            "output": 0,
                        }
                    self._metrics["token_usage_by_provider"][provider]["input"] += input_tokens
                    self._metrics["token_usage_by_provider"][provider]["output"] += output_tokens

                # Export to external metrics
                self._external_metrics.increment(
                    "llm.tokens.input", input_tokens, tags={"provider": provider or "unknown"}
                )
                self._external_metrics.increment(
                    "llm.tokens.output", output_tokens, tags={"provider": provider or "unknown"}
                )

        try:
            import asyncio

            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(_track())
            else:
                asyncio.run(_track())
        except Exception:
            pass

    def _log_audit(
        self,
        action_type: str,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        status: str = "success",
        correlation_id: Optional[str] = None,
    ) -> None:
        """
        Log audit trail if enabled.

        When user/tenant is None (anonymous), uses bucket UUIDs for traceability.
        Uses sync log_action (per audit_trail API). Run in executor if non-blocking needed.

        Args:
            action_type: Type of action (e.g. "llm_generate")
            user_id: User ID
            tenant_id: Tenant ID
            details: Additional details
            status: Action status ("success" or "failure")
            correlation_id: Request correlation ID (for anonymous traceability)
        """
        if not self._audit_logger:
            return

        details = dict(details or {})
        if correlation_id:
            details["correlation_id"] = correlation_id

        try:
            if user_id and tenant_id:
                user_uuid = self._to_uuid(user_id, "user")
                tenant_uuid = self._to_uuid(tenant_id, "tenant")
                if user_uuid is None or tenant_uuid is None:
                    return
            else:
                # Anonymous: use bucket UUIDs for traceability (correlation_id in details)
                tenant_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, "anon.engine.llm")
                user_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, f"anon.engine.llm.{correlation_id or uuid.uuid4()}")

            # Map to ActionType (audit_trail expects action, resource_type, resource_id)
            action = ActionType.CHAT if action_type == "llm_generate" else ActionType.CHAT
            resource_type = "llm_generation"

            self._audit_logger.log_action(
                tenant_id=tenant_uuid,
                user_id=user_uuid,
                action=action,
                resource_type=resource_type,
                resource_id=uuid.uuid4(),
                status=ActionStatus.SUCCESS if status == "success" else ActionStatus.FAILURE,
                details=details or {},
            )
        except Exception as e:
            logger.warning(f"Audit logging failed: {e}")
            # Don't block on audit logging errors

    async def generate(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        provider: Optional[str] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        user_tier: Optional["UserTier"] = None,
        correlation_id: Optional[str] = None,
    ) -> LLMResult:
        """
        Generate text completion.

        Args:
            prompt: User prompt (if messages not provided)
            system_prompt: System instruction
            messages: Conversation history
            temperature: Sampling temperature (0-2)
            max_tokens: Maximum tokens to generate
            tools: Function calling tools
            tool_choice: Tool choice strategy
            response_format: Structured output format
            provider: Force specific provider (skip fallback)
            user_id: User ID for rate limiting/audit
            tenant_id: Tenant ID for rate limiting/audit
            user_tier: User subscription tier (defaults to FREE for security)
            correlation_id: Request correlation ID (auto-generated if not provided)

        Returns:
            LLMResult with generated text and metadata

        Raises:
            GenerationError: If generation fails
            RateLimitError: If rate limit exceeded
            InvalidInputError: If input validation fails
        """
        if not self._initialized:
            await self.initialize()

        # Generate correlation ID if not provided
        if not correlation_id:
            correlation_id = self._generate_correlation_id()

        start_time = time.time()

        try:
            # Rate limiting (always check; uses anonymous bucket when user_id/tenant_id is None)
            self._check_rate_limit(user_id, tenant_id, user_tier=user_tier)

            # Input validation and processing
            processed_inputs = self._input_processor.process_inputs(
                prompt=prompt,
                system_prompt=system_prompt,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                correlation_id=correlation_id,
            )

            # Generate with strategy
            result = await self._strategy.generate(
                prompt=processed_inputs["prompt"],
                system_prompt=processed_inputs["system_prompt"],
                messages=processed_inputs["messages"],
                temperature=processed_inputs["temperature"],
                max_tokens=processed_inputs["max_tokens"],
                tools=tools,
                tool_choice=tool_choice,
                response_format=response_format,
                provider=provider,
                correlation_id=correlation_id,
            )

            # Update metrics with enhanced tracking
            async with self._metrics_lock:
                self._metrics["generations"] += 1
                self._metrics["total_processing_time"] += result.processing_time
                self._metrics["total_input_tokens"] += result.input_tokens
                self._metrics["total_output_tokens"] += result.output_tokens

                # Track cost (if available in metadata)
                if "cost" in result.metadata:
                    cost = result.metadata["cost"]
                    self._metrics["total_cost"] += cost
                    provider_name = result.provider
                    if provider_name not in self._metrics["cost_by_provider"]:
                        self._metrics["cost_by_provider"][provider_name] = 0.0
                    self._metrics["cost_by_provider"][provider_name] += cost

            # Use enhanced tracking methods
            self._track_latency(result.processing_time, provider=result.provider)
            self._track_token_usage(result.input_tokens, result.output_tokens, provider=result.provider)

            # Export metrics
            self._external_metrics.increment(
                "llm.generations.total", tags={"provider": result.provider, "model": result.model}
            )

            # Audit logging (includes anonymous for traceability)
            self._log_audit(
                action_type="llm_generate",
                user_id=user_id,
                tenant_id=tenant_id,
                details={
                    "provider": result.provider,
                    "model": result.model,
                    "input_tokens": result.input_tokens,
                    "output_tokens": result.output_tokens,
                    "total_tokens": result.total_tokens,
                    "processing_time": result.processing_time,
                    "finish_reason": result.finish_reason,
                },
                status="success",
                correlation_id=correlation_id,
            )

            logger.info(
                "LLM generation completed",
                extra={
                    "correlation_id": correlation_id,
                    "provider": result.provider,
                    "model": result.model,
                    "input_tokens": result.input_tokens,
                    "output_tokens": result.output_tokens,
                    "processing_time": result.processing_time,
                },
            )

            return result

        except LLMError:
            # Re-raise LLM errors as-is
            raise
        except Exception as e:
            # Wrap unexpected errors
            total_time = time.time() - start_time

            async with self._metrics_lock:
                self._metrics["errors"] += 1
                error_type = type(e).__name__
                self._metrics["errors_by_type"][error_type] = self._metrics["errors_by_type"].get(error_type, 0) + 1

            # Audit logging for errors (includes anonymous for traceability)
            self._log_audit(
                action_type="llm_generate",
                user_id=user_id,
                tenant_id=tenant_id,
                details={
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "processing_time": total_time,
                },
                status="failure",
                correlation_id=correlation_id,
            )

            logger.error(
                "LLM generation failed",
                extra={
                    "correlation_id": correlation_id,
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "processing_time": total_time,
                },
                exc_info=True,
            )

            raise GenerationError(
                f"Generation failed: {str(e)}",
                provider="engine",
                correlation_id=correlation_id,
            ) from e

    async def generate_streaming(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        provider: Optional[str] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        user_tier: Optional["UserTier"] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[LLMResult]:
        """
        Stream text completion with incremental results.

        Args:
            prompt: User prompt (if messages not provided)
            system_prompt: System instruction
            messages: Conversation history
            temperature: Sampling temperature (0-2)
            max_tokens: Maximum tokens to generate
            tools: Function calling tools
            tool_choice: Tool choice strategy
            response_format: Structured output format
            provider: Force specific provider (skip fallback)
            user_id: User ID for rate limiting/audit
            tenant_id: Tenant ID for rate limiting/audit
            correlation_id: Request correlation ID (auto-generated if not provided)

        Yields:
            LLMResult objects with is_partial=True for interim results

        Raises:
            GenerationError: If generation fails
            RateLimitError: If rate limit exceeded
            InvalidInputError: If input validation fails
        """
        if not self._initialized:
            await self.initialize()

        # Generate correlation ID if not provided
        if not correlation_id:
            correlation_id = self._generate_correlation_id()

        start_time = time.time()

        try:
            # Rate limiting (always check; uses anonymous bucket when user_id/tenant_id is None)
            self._check_rate_limit(user_id, tenant_id, user_tier=user_tier)

            # Input validation and processing
            processed_inputs = self._input_processor.process_inputs(
                prompt=prompt,
                system_prompt=system_prompt,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                correlation_id=correlation_id,
            )

            # Track streaming session
            async with self._metrics_lock:
                self._metrics["streaming_sessions"] += 1

            try:
                # Stream with strategy (with timeout to prevent indefinite hang)
                total_input_tokens = 0
                total_output_tokens = 0
                final_result: Optional[LLMResult] = None
                stream_timeout = (
                    getattr(
                        self.config.integration,
                        "streaming_timeout",
                        90.0,
                    )
                    or 90.0
                )

                stream = self._strategy.generate_streaming(
                    prompt=processed_inputs["prompt"],
                    system_prompt=processed_inputs["system_prompt"],
                    messages=processed_inputs["messages"],
                    temperature=processed_inputs["temperature"],
                    max_tokens=processed_inputs["max_tokens"],
                    tools=tools,
                    tool_choice=tool_choice,
                    response_format=response_format,
                    provider=provider,
                    correlation_id=correlation_id,
                )
                stream_iter = stream.__aiter__()
                first_result = True

                while True:
                    try:
                        result = await asyncio.wait_for(
                            stream_iter.__anext__(),
                            timeout=stream_timeout,
                        )
                    except StopAsyncIteration:
                        break
                    except asyncio.TimeoutError:
                        logger.warning(
                            "LLM streaming timed out after %.0f seconds",
                            stream_timeout,
                            extra={"correlation_id": correlation_id},
                        )
                        yield LLMResult(
                            text="I'm still thinking. Please try again in a moment.",
                            finish_reason=FinishReason.ERROR.value,
                            provider="engine",
                            model="timeout",
                            processing_time=time.time() - start_time,
                            input_tokens=0,
                            output_tokens=0,
                            total_tokens=0,
                            is_partial=False,
                            is_final=True,
                            metadata={"timeout": True, "streaming_timeout_s": stream_timeout},
                            correlation_id=correlation_id,
                        )
                        break

                    if first_result:
                        time_to_first_token = time.time() - start_time
                        first_result = False

                        # Track TTFT by provider
                        provider_name = getattr(result, "provider", "unknown")
                        async with self._metrics_lock:
                            if provider_name not in self._metrics["ttft_by_provider"]:
                                self._metrics["ttft_by_provider"][provider_name] = deque(maxlen=10000)
                            self._metrics["ttft_by_provider"][provider_name].append(time_to_first_token)

                        self._external_metrics.histogram(
                            "llm.streaming.time_to_first_token",
                            time_to_first_token,
                            tags={"provider": provider_name},
                        )
                    yield result

                    # Track final result
                    if result.is_final:
                        final_result = result
                        total_input_tokens = result.input_tokens
                        total_output_tokens = result.output_tokens

                # Update metrics with final result
                if final_result:
                    async with self._metrics_lock:
                        self._metrics["total_processing_time"] += final_result.processing_time
                        self._metrics["total_input_tokens"] += total_input_tokens
                        self._metrics["total_output_tokens"] += total_output_tokens

                        # Track cost
                        if "cost" in final_result.metadata:
                            cost = final_result.metadata["cost"]
                            self._metrics["total_cost"] += cost
                            provider_name = final_result.provider
                            if provider_name not in self._metrics["cost_by_provider"]:
                                self._metrics["cost_by_provider"][provider_name] = 0.0
                            self._metrics["cost_by_provider"][provider_name] += cost

                    # Use enhanced tracking methods
                    self._track_latency(final_result.processing_time, provider=final_result.provider)
                    self._track_token_usage(total_input_tokens, total_output_tokens, provider=final_result.provider)

                    # Export metrics
                    self._external_metrics.increment(
                        "llm.streaming_sessions.total", tags={"provider": final_result.provider}
                    )

                    # Audit logging (includes anonymous for traceability)
                    self._log_audit(
                        action_type="llm_generate",
                        user_id=user_id,
                        tenant_id=tenant_id,
                        details={
                            "provider": final_result.provider,
                            "model": final_result.model,
                            "input_tokens": total_input_tokens,
                            "output_tokens": total_output_tokens,
                            "total_tokens": total_input_tokens + total_output_tokens,
                            "processing_time": final_result.processing_time,
                            "finish_reason": final_result.finish_reason,
                            "streaming": True,
                        },
                        status="success",
                        correlation_id=correlation_id,
                    )

                    logger.info(
                        "LLM streaming completed",
                        extra={
                            "correlation_id": correlation_id,
                            "provider": final_result.provider,
                            "model": final_result.model,
                            "input_tokens": total_input_tokens,
                            "output_tokens": total_output_tokens,
                            "processing_time": final_result.processing_time,
                        },
                    )
            finally:
                # Always decrement streaming session counter, even on error
                async with self._metrics_lock:
                    self._metrics["streaming_sessions"] = max(0, self._metrics["streaming_sessions"] - 1)

        except LLMError:
            # Re-raise LLM errors as-is
            raise
        except Exception as e:
            # Wrap unexpected errors
            total_time = time.time() - start_time

            # Track error with provider details (if available from exception)
            provider = getattr(e, "provider", None) if isinstance(e, LLMError) else None
            self._track_error(e, provider=provider, correlation_id=correlation_id)

            # Audit logging for errors (includes anonymous for traceability)
            self._log_audit(
                action_type="llm_generate",
                user_id=user_id,
                tenant_id=tenant_id,
                details={
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "processing_time": total_time,
                    "streaming": True,
                },
                status="failure",
                correlation_id=correlation_id,
            )

            logger.error(
                "LLM streaming failed",
                extra={
                    "correlation_id": correlation_id,
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "processing_time": total_time,
                },
                exc_info=True,
            )

            raise GenerationError(
                f"Streaming failed: {str(e)}",
                provider="engine",
                correlation_id=correlation_id,
            ) from e

    async def get_metrics(self) -> Dict[str, Any]:
        """
        Get engine metrics.

        Returns:
            Dict with metrics
        """
        async with self._metrics_lock:
            # Calculate percentiles (fix edge case for empty latencies)
            latencies = list(self._metrics["latencies"])
            if len(latencies) > 0:
                sorted_latencies = sorted(latencies)
                p50 = sorted_latencies[len(sorted_latencies) // 2]
                if len(sorted_latencies) > 1:
                    p95 = sorted_latencies[int(len(sorted_latencies) * 0.95)]
                    p99 = sorted_latencies[int(len(sorted_latencies) * 0.99)]
                else:
                    p95 = p99 = sorted_latencies[-1]
            else:
                p50 = p95 = p99 = 0.0

            # Calculate provider-specific latency percentiles
            latency_by_provider = {}
            for provider, provider_latencies in self._metrics["latencies_by_provider"].items():
                if len(provider_latencies) > 0:
                    sorted_lats = sorted(provider_latencies)
                    latency_by_provider[provider] = {
                        "p50": sorted_lats[len(sorted_lats) // 2],
                        "p95": sorted_lats[int(len(sorted_lats) * 0.95)] if len(sorted_lats) > 1 else sorted_lats[-1],
                        "p99": sorted_lats[int(len(sorted_lats) * 0.99)] if len(sorted_lats) > 1 else sorted_lats[-1],
                        "count": len(provider_latencies),
                    }

            # Calculate TTFT percentiles by provider
            ttft_by_provider = {}
            for provider, ttft_values in self._metrics["ttft_by_provider"].items():
                if len(ttft_values) > 0:
                    sorted_ttft = sorted(ttft_values)
                    ttft_by_provider[provider] = {
                        "p50": sorted_ttft[len(sorted_ttft) // 2],
                        "p95": sorted_ttft[int(len(sorted_ttft) * 0.95)] if len(sorted_ttft) > 1 else sorted_ttft[-1],
                        "p99": sorted_ttft[int(len(sorted_ttft) * 0.99)] if len(sorted_ttft) > 1 else sorted_ttft[-1],
                        "count": len(ttft_values),
                    }

            metrics_dict = {
                "generations": self._metrics["generations"],
                "streaming_sessions": self._metrics["streaming_sessions"],
                "total_processing_time": self._metrics["total_processing_time"],
                "average_processing_time": (
                    self._metrics["total_processing_time"] / self._metrics["generations"]
                    if self._metrics["generations"] > 0
                    else 0.0
                ),
                "total_input_tokens": self._metrics["total_input_tokens"],
                "total_output_tokens": self._metrics["total_output_tokens"],
                "total_tokens": self._metrics["total_input_tokens"] + self._metrics["total_output_tokens"],
                "total_cost": self._metrics["total_cost"],
                "cost_by_provider": self._metrics["cost_by_provider"].copy(),
                "token_usage_by_provider": self._metrics["token_usage_by_provider"].copy(),
                "errors": self._metrics["errors"],
                "errors_by_type": self._metrics["errors_by_type"].copy(),
                "errors_by_provider": self._metrics["errors_by_provider"].copy(),
                "errors_by_provider_and_type": {
                    p: t.copy() for p, t in self._metrics["errors_by_provider_and_type"].items()
                },
                "latency_p50": p50,
                "latency_p95": p95,
                "latency_p99": p99,
                "latency_by_provider": latency_by_provider,
                "ttft_by_provider": ttft_by_provider,
            }

            # Export metrics to external monitoring systems
            self._export_metrics(metrics_dict)

            return metrics_dict

    def _export_metrics(self, metrics: Dict[str, Any]) -> None:
        """
        Export metrics to external monitoring systems (Prometheus, StatsD, etc.).

        Args:
            metrics: Metrics dictionary from get_metrics()
        """
        if not self._external_metrics:
            return

        try:
            # Export counters
            self._external_metrics.gauge("llm.generations.total", metrics["generations"])
            self._external_metrics.gauge("llm.streaming_sessions.total", metrics["streaming_sessions"])
            self._external_metrics.gauge("llm.tokens.input.total", metrics["total_input_tokens"])
            self._external_metrics.gauge("llm.tokens.output.total", metrics["total_output_tokens"])
            self._external_metrics.gauge("llm.tokens.total", metrics["total_tokens"])
            self._external_metrics.gauge("llm.cost.total", metrics["total_cost"])
            self._external_metrics.gauge("llm.errors.total", metrics["errors"])

            # Export latency percentiles
            self._external_metrics.gauge("llm.latency.p50", metrics["latency_p50"])
            self._external_metrics.gauge("llm.latency.p95", metrics["latency_p95"])
            self._external_metrics.gauge("llm.latency.p99", metrics["latency_p99"])

            # Export cost by provider
            for provider, cost in metrics["cost_by_provider"].items():
                self._external_metrics.gauge("llm.cost.by_provider", cost, tags={"provider": provider})

            # Export errors by type
            for error_type, count in metrics["errors_by_type"].items():
                self._external_metrics.gauge("llm.errors.by_type", count, tags={"error_type": error_type})
        except Exception as e:
            logger.warning(f"Failed to export metrics: {e}", exc_info=False)

    async def health_check(self) -> Dict[str, Any]:
        """
        Perform health check on engine and providers.

        Returns:
            Health status dict
        """
        timeout = getattr(
            self.config.integration,
            "health_check_timeout",
            5.0,
        )
        try:
            return await asyncio.wait_for(
                self._do_health_check(),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning(f"Health check timed out after {timeout} seconds")
            return {
                "engine": {
                    "initialized": self._initialized,
                    "status": "timeout",
                    "error": f"Health check timed out after {timeout}s",
                },
            }

    async def _do_health_check(self) -> Dict[str, Any]:
        """Internal health check implementation."""
        health = {
            "engine": {
                "initialized": self._initialized,
                "config": {
                    "primary_provider": self.config.primary_provider,
                    "fallback_providers": self.config.fallback_providers,
                },
            },
        }

        if self._strategy:
            health["strategy"] = await self._strategy.health_check()

        return health
