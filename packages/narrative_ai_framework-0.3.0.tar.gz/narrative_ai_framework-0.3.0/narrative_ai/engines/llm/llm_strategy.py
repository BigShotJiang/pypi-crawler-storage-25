"""
LLM Strategy - Provider Selection and Fallback Logic.

Production-ready implementation with:
- Configurable circuit breaker
- Correlation ID propagation
- Structured logging
- Better error classification
"""

import time
import logging
import threading
from dataclasses import dataclass
from typing import Optional, Dict, List, Any, AsyncIterator

from .base_llm import (
    BaseLLMProvider,
    LLMResult,
    LLMError,
    GenerationError,
    ProviderUnavailableError,
    is_retriable_error,
    get_metrics_exporter,
)
from .config import LLMConfig

logger = logging.getLogger(__name__)


@dataclass
class CircuitBreakerConfig:
    """
    Configuration for circuit breaker pattern.

    Attributes:
        failure_threshold: Number of failures before opening circuit
        recovery_timeout: Seconds to wait before attempting recovery
        half_open_max_calls: Max calls in half-open state
    """

    failure_threshold: int = 5
    recovery_timeout: float = 60.0
    half_open_max_calls: int = 1


class LLMStrategy:
    """
    Strategy manager for LLM providers with fallback support.

    Production Features:
    - Configurable circuit breaker
    - Correlation ID propagation for tracing
    - Structured logging
    - Metrics export
    - Better error classification for retry decisions

    Example:
        strategy = LLMStrategy(
            providers={"gemini": gemini_provider, "openai": openai_provider},
            primary="gemini",
            fallback_order=["openai"],
            circuit_breaker_config=CircuitBreakerConfig(
                failure_threshold=5,
                recovery_timeout=120.0,
            ),
        )

        result = await strategy.generate(prompt="Hello", correlation_id="req-123")
    """

    def __init__(
        self,
        providers: Dict[str, BaseLLMProvider],
        primary: str = "gemini",
        fallback_order: Optional[List[str]] = None,
        enable_fallback: bool = True,
        circuit_breaker_config: Optional[CircuitBreakerConfig] = None,
        allow_degraded_mode: bool = False,
    ):
        """
        Initialize LLM strategy.

        Args:
            providers: Dict of provider name -> provider instance
            primary: Name of primary provider
            fallback_order: Order of fallback providers (after primary)
            enable_fallback: Whether to enable automatic fallback
            circuit_breaker_config: Circuit breaker configuration
            allow_degraded_mode: Return degraded result instead of raising when all providers fail
        """
        self.providers = providers
        self.primary = primary
        self.fallback_order = fallback_order or list(p for p in providers.keys() if p != primary)
        self.enable_fallback = enable_fallback
        self.allow_degraded_mode = allow_degraded_mode

        # Circuit breaker config
        self._cb_config = circuit_breaker_config or CircuitBreakerConfig()

        # Provider health tracking
        self._provider_failures: Dict[str, int] = {name: 0 for name in providers}
        self._provider_last_failure: Dict[str, float] = {}
        self._provider_last_success: Dict[str, float] = {}
        self._half_open_requests: Dict[str, int] = {name: 0 for name in providers}  # Track requests in half-open state
        self._half_open_lock = threading.Lock()  # Protect half-open state transitions

        # Metrics
        self._metrics = get_metrics_exporter()

    @classmethod
    def from_config(cls, config: LLMConfig) -> "LLMStrategy":
        """
        Create strategy from configuration.

        Args:
            config: LLM configuration

        Returns:
            Configured LLMStrategy instance
        """
        from .gemini_llm import GeminiLLMProvider
        from .openai_llm import OpenAILLMProvider
        from .claude_llm import ClaudeLLMProvider
        from .xai_llm import XAILLMProvider
        from .deepseek_llm import DeepSeekLLMProvider
        from .ollama_llm import OllamaLLMProvider

        providers: Dict[str, BaseLLMProvider] = {}

        # Gemini
        if config.gemini.enabled and config.gemini.api_key:
            providers["gemini"] = GeminiLLMProvider(config.gemini)

        # OpenAI
        if config.openai.enabled and config.openai.api_key:
            providers["openai"] = OpenAILLMProvider(config.openai)

        # Anthropic
        if config.anthropic.enabled and config.anthropic.api_key:
            providers["anthropic"] = ClaudeLLMProvider(config.anthropic)

        # xAI
        if config.xai.enabled and config.xai.api_key:
            providers["xai"] = XAILLMProvider(config.xai)

        # DeepSeek
        if config.deepseek.enabled and config.deepseek.api_key:
            providers["deepseek"] = DeepSeekLLMProvider(config.deepseek)

        # Ollama Cloud/Local
        if config.ollama.enabled and (config.ollama.api_key or config.ollama.base_url):
            providers["ollama"] = OllamaLLMProvider(config.ollama)

        return cls(
            providers=providers,
            primary=config.primary_provider,
            fallback_order=config.fallback_providers,
            enable_fallback=config.enable_fallback,
            allow_degraded_mode=config.allow_degraded_mode,
            circuit_breaker_config=CircuitBreakerConfig(
                failure_threshold=config.circuit_breaker_failure_threshold,
                recovery_timeout=config.circuit_breaker_timeout,
            ),
        )

    async def initialize(self) -> None:
        """Initialize all providers."""
        for name, provider in self.providers.items():
            try:
                if provider.is_available():
                    await provider.load_model()
                    logger.info("Initialized LLM provider", extra={"provider": name})
            except Exception as e:
                logger.warning("Failed to initialize LLM provider", extra={"provider": name, "error": str(e)})

    async def shutdown(self) -> None:
        """Shutdown all providers."""
        for name, provider in self.providers.items():
            try:
                await provider.shutdown()
                logger.info("Shutdown LLM provider", extra={"provider": name})
            except Exception as e:
                logger.warning("Failed to shutdown LLM provider", extra={"provider": name, "error": str(e)})

    def _get_provider_order(self) -> List[str]:
        """Get ordered list of providers to try."""
        order = []

        if self.primary and self._is_provider_healthy(self.primary):
            order.append(self.primary)

        for provider_name in self.fallback_order:
            if provider_name not in order and self._is_provider_healthy(provider_name):
                order.append(provider_name)

        if not order:
            order = [
                name
                for name in [self.primary] + self.fallback_order
                if name in self.providers and self.providers[name].is_available()
            ]

        return order

    def _is_provider_healthy(self, provider_name: str) -> bool:
        """
        Check if provider is healthy using circuit breaker pattern.

        States:
        - Closed: Normal operation, failures < threshold
        - Open: Circuit tripped, rejecting requests
        - Half-Open: Allowing limited requests to test recovery
        """
        if provider_name not in self.providers:
            return False

        if not self.providers[provider_name].is_available():
            return False

        failures = self._provider_failures.get(provider_name, 0)

        if failures >= self._cb_config.failure_threshold:
            last_failure = self._provider_last_failure.get(provider_name, 0)
            time_since_failure = time.time() - last_failure

            if time_since_failure < self._cb_config.recovery_timeout:
                # Circuit is open
                self._metrics.increment("llm.circuit_breaker.rejected", tags={"provider": provider_name})
                logger.debug(
                    "Circuit breaker open",
                    extra={
                        "provider": provider_name,
                        "failures": failures,
                        "time_until_retry": self._cb_config.recovery_timeout - time_since_failure,
                    },
                )
                return False
            else:
                # Half-open: check if we can allow retry (limit concurrent test requests)
                with self._half_open_lock:
                    half_open_requests = self._half_open_requests.get(provider_name, 0)
                    if half_open_requests >= self._cb_config.half_open_max_calls:
                        logger.debug(
                            "Circuit breaker half-open limit reached",
                            extra={
                                "provider": provider_name,
                                "requests": half_open_requests,
                                "max_calls": self._cb_config.half_open_max_calls,
                            },
                        )
                        return False

                    # Increment half-open request count
                    self._half_open_requests[provider_name] = half_open_requests + 1
                    logger.info(
                        "Circuit breaker half-open, allowing test request",
                        extra={
                            "provider": provider_name,
                            "request_count": half_open_requests + 1,
                            "max_calls": self._cb_config.half_open_max_calls,
                        },
                    )
                    # Don't reset failures here - wait for success/failure result

        return True

    def _record_success(self, provider_name: str) -> None:
        """Record successful provider usage."""
        with self._half_open_lock:
            failures = self._provider_failures.get(provider_name, 0)

            # If in half-open state, reset failures and close circuit
            if failures >= self._cb_config.failure_threshold:
                self._provider_failures[provider_name] = 0
                self._half_open_requests[provider_name] = 0
                logger.info("Circuit breaker closed after successful request", extra={"provider": provider_name})
            else:
                self._provider_failures[provider_name] = 0

            self._provider_last_success[provider_name] = time.time()
            self._metrics.increment("llm.provider.success", tags={"provider": provider_name})

    def _record_failure(self, provider_name: str, error: Exception) -> None:
        """Record provider failure with error classification."""
        with self._half_open_lock:
            # Increment half-open request count if in half-open state
            failures = self._provider_failures.get(provider_name, 0)
            if failures >= self._cb_config.failure_threshold:
                # Decrement half-open counter on failure (may reopen circuit)
                if provider_name in self._half_open_requests:
                    self._half_open_requests[provider_name] = max(0, self._half_open_requests[provider_name] - 1)

            self._provider_failures[provider_name] = self._provider_failures.get(provider_name, 0) + 1
            self._provider_last_failure[provider_name] = time.time()

            failures = self._provider_failures[provider_name]
            retriable = is_retriable_error(error)

            self._metrics.increment(
                "llm.provider.failure",
                tags={
                    "provider": provider_name,
                    "retriable": str(retriable).lower(),
                },
            )

            if failures >= self._cb_config.failure_threshold:
                self._metrics.increment("llm.circuit_breaker.opened", tags={"provider": provider_name})
                logger.warning(
                    "Circuit breaker opened",
                    extra={
                        "provider": provider_name,
                        "failures": failures,
                        "recovery_timeout": self._cb_config.recovery_timeout,
                    },
                )

    async def generate(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        provider: Optional[str] = None,
        correlation_id: Optional[str] = None,
        **kwargs,
    ) -> LLMResult:
        """
        Generate text with strategy and fallback.

        Args:
            prompt: User prompt (if messages not provided)
            system_prompt: System instruction
            messages: Conversation history
            provider: Force specific provider (skip routing/fallback)
            correlation_id: Request correlation ID for tracing
            **kwargs: Additional generation parameters

        Returns:
            LLMResult from successful provider

        Raises:
            GenerationError: If all providers fail
        """
        start_time = time.time()

        if provider:
            return await self._generate_with_provider(
                provider, prompt, system_prompt, messages, correlation_id, **kwargs
            )

        provider_order = self._get_provider_order()

        if not provider_order:
            # Graceful degradation: return degraded result if enabled
            if self.allow_degraded_mode:
                logger.warning(
                    "All providers unavailable, returning degraded result", extra={"correlation_id": correlation_id}
                )
                return LLMResult(
                    text="",
                    finish_reason="error",
                    provider="degraded",
                    model="none",
                    processing_time=0.0,
                    input_tokens=0,
                    output_tokens=0,
                    total_tokens=0,
                    is_partial=False,
                    is_final=True,
                    metadata={"degraded": True, "reason": "All providers unavailable"},
                    correlation_id=correlation_id,
                )
            raise ProviderUnavailableError(
                "No available LLM providers",
                provider="strategy",
                correlation_id=correlation_id,
            )

        last_error: Optional[Exception] = None
        tried_providers: List[str] = []

        for provider_name in provider_order:
            tried_providers.append(provider_name)

            try:
                result = await self._generate_with_provider(
                    provider_name, prompt, system_prompt, messages, correlation_id, **kwargs
                )

                self._record_success(provider_name)

                # Log if we had to fallback
                if len(tried_providers) > 1:
                    logger.info(
                        "LLM succeeded after fallback",
                        extra={
                            "correlation_id": correlation_id,
                            "successful_provider": provider_name,
                            "tried_providers": tried_providers,
                        },
                    )

                return result

            except LLMError as e:
                logger.warning(
                    f"LLM provider '{provider_name}' failed: {str(e)}",
                    extra={
                        "correlation_id": correlation_id,
                        "provider": provider_name,
                        "error": str(e),
                        "retriable": e.retriable,
                    },
                )
                self._record_failure(provider_name, e)
                last_error = e

                if not self.enable_fallback:
                    raise

                # For non-retriable errors: allow fallback if explicitly enabled
                # This gives users control over fallback behavior
                # Document: Non-retriable errors (like invalid input) can still trigger
                # fallback if enable_fallback=True, allowing users to try alternative providers
                if not e.retriable:
                    # Log that we're attempting fallback for non-retriable error
                    logger.info(
                        "Non-retriable error encountered, attempting fallback",
                        extra={
                            "correlation_id": correlation_id,
                            "provider": provider_name,
                            "error": str(e),
                        },
                    )
                    # Continue to next provider in fallback order

        total_time = time.time() - start_time

        # Graceful degradation: return degraded result if enabled
        if self.allow_degraded_mode:
            logger.warning(
                "All providers failed, returning degraded result",
                extra={
                    "correlation_id": correlation_id,
                    "tried_providers": tried_providers,
                    "last_error": str(last_error),
                },
            )
            return LLMResult(
                text="",
                finish_reason="error",
                provider="degraded",
                model="none",
                processing_time=total_time,
                input_tokens=0,
                output_tokens=0,
                total_tokens=0,
                is_partial=False,
                is_final=True,
                metadata={
                    "degraded": True,
                    "reason": "All providers failed",
                    "tried_providers": tried_providers,
                    "last_error": str(last_error),
                },
                correlation_id=correlation_id,
            )

        error = GenerationError(
            f"All LLM providers failed after {total_time:.2f}s",
            provider="strategy",
            details={
                "tried_providers": tried_providers,
                "last_error": str(last_error),
            },
            correlation_id=correlation_id,
        )

        if last_error:
            error.__cause__ = last_error

        raise error

    async def generate_streaming(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        provider: Optional[str] = None,
        correlation_id: Optional[str] = None,
        **kwargs,
    ) -> AsyncIterator[LLMResult]:
        """
        Stream text generation with fallback.

        Note: Fallback is limited for streaming since we can't replay
        the stream. We only fallback before streaming starts.
        """
        provider_name = provider or self._get_best_available_provider()

        if not provider_name:
            raise ProviderUnavailableError(
                "No available LLM providers for streaming",
                provider="strategy",
                correlation_id=correlation_id,
            )

        llm_provider = self.providers.get(provider_name)

        if not llm_provider:
            raise ProviderUnavailableError(
                f"LLM provider {provider_name} not found",
                provider="strategy",
                correlation_id=correlation_id,
            )

        logger.info(
            "LLM streaming started",
            extra={
                "correlation_id": correlation_id,
                "provider": provider_name,
            },
        )

        try:
            async for result in llm_provider.generate_streaming(
                prompt, system_prompt, messages, correlation_id=correlation_id, **kwargs
            ):
                yield result

            self._record_success(provider_name)

        except LLMError as e:
            logger.warning(
                "LLM streaming failed",
                extra={
                    "correlation_id": correlation_id,
                    "provider": provider_name,
                    "error": str(e),
                },
            )
            self._record_failure(provider_name, e)
            raise

    async def _generate_with_provider(
        self,
        provider_name: str,
        prompt: Optional[str],
        system_prompt: Optional[str],
        messages: Optional[List[Dict[str, str]]],
        correlation_id: Optional[str],
        **kwargs,
    ) -> LLMResult:
        """Generate with specific provider."""
        provider = self.providers.get(provider_name)

        if not provider:
            raise ProviderUnavailableError(
                f"LLM provider {provider_name} not found",
                provider=provider_name,
                correlation_id=correlation_id,
            )

        if not provider.is_available():
            raise ProviderUnavailableError(
                f"LLM provider {provider_name} is not available",
                provider=provider_name,
                correlation_id=correlation_id,
            )

        logger.debug(
            "Generating with provider",
            extra={
                "correlation_id": correlation_id,
                "provider": provider_name,
            },
        )

        return await provider.generate(
            prompt=prompt,
            system_prompt=system_prompt,
            messages=messages,
            correlation_id=correlation_id,
            **kwargs,
        )

    def _get_best_available_provider(self) -> Optional[str]:
        """Get the best available provider."""
        order = self._get_provider_order()
        return order[0] if order else None

    def get_provider(self, name: str) -> Optional[BaseLLMProvider]:
        """Get a specific provider."""
        return self.providers.get(name)

    def set_primary(self, provider_name: str) -> None:
        """Change primary provider."""
        if provider_name not in self.providers:
            raise ValueError(f"LLM provider {provider_name} not found")

        self.primary = provider_name
        logger.info("Changed primary LLM provider", extra={"provider": provider_name})

    def set_circuit_breaker_config(self, config: CircuitBreakerConfig) -> None:
        """
        Update circuit breaker configuration at runtime.

        Args:
            config: New circuit breaker configuration
        """
        self._cb_config = config
        logger.info(
            "Updated circuit breaker config",
            extra={
                "failure_threshold": config.failure_threshold,
                "recovery_timeout": config.recovery_timeout,
            },
        )

    def reset_circuit_breaker(self, provider_name: Optional[str] = None) -> None:
        """
        Reset circuit breaker for one or all providers.

        Args:
            provider_name: Specific provider to reset, or None for all
        """
        if provider_name:
            self._provider_failures[provider_name] = 0
            logger.info("Reset circuit breaker", extra={"provider": provider_name})
        else:
            for name in self._provider_failures:
                self._provider_failures[name] = 0
            logger.info("Reset all circuit breakers")

    def add_provider(
        self,
        name: str,
        provider: BaseLLMProvider,
        add_to_fallback: bool = True,
    ) -> None:
        """Add a new provider."""
        self.providers[name] = provider
        self._provider_failures[name] = 0

        if add_to_fallback and name not in self.fallback_order:
            self.fallback_order.append(name)

        logger.info("Added LLM provider", extra={"provider": name})

    def remove_provider(self, name: str) -> None:
        """Remove a provider."""
        if name in self.providers:
            del self.providers[name]

        if name in self._provider_failures:
            del self._provider_failures[name]

        if name in self.fallback_order:
            self.fallback_order.remove(name)

        if name == self.primary and self.fallback_order:
            self.primary = self.fallback_order[0]

        logger.info("Removed LLM provider", extra={"provider": name})

    async def health_check(self) -> Dict[str, Any]:
        """Check health of all providers."""
        health = {
            "primary": self.primary,
            "fallback_order": self.fallback_order,
            "circuit_breaker": {
                "failure_threshold": self._cb_config.failure_threshold,
                "recovery_timeout": self._cb_config.recovery_timeout,
            },
            "providers": {},
        }

        for name, provider in self.providers.items():
            try:
                provider_health = await provider.health_check()
                provider_health["circuit_open"] = not self._is_provider_healthy(name)
                provider_health["failure_count"] = self._provider_failures.get(name, 0)
                health["providers"][name] = provider_health
            except Exception as e:
                health["providers"][name] = {
                    "available": False,
                    "error": str(e),
                }

        return health

    def get_status(self) -> Dict[str, Any]:
        """Get current strategy status."""
        return {
            "primary": self.primary,
            "fallback_order": self.fallback_order,
            "enable_fallback": self.enable_fallback,
            "circuit_breaker": {
                "failure_threshold": self._cb_config.failure_threshold,
                "recovery_timeout": self._cb_config.recovery_timeout,
            },
            "provider_order": self._get_provider_order(),
            "provider_failures": self._provider_failures.copy(),
        }
