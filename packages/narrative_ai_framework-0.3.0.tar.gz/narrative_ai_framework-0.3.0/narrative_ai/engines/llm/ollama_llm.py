"""
Ollama LLM Provider.

Implements Ollama Chat API integration (cloud/local) via /api/chat.
Supports standard generation and line-delimited streaming responses.
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
import time
from typing import Any, AsyncIterator, Dict, List, Optional, Union
from urllib.parse import urlparse

import httpx

from .base_llm import (
    BaseLLMProvider,
    FinishReason,
    GenerationError,
    LLMError,
    LLMNetworkError,
    LLMResult,
    LLMTimeoutError,
    ProviderUnavailableError,
    RateLimitError,
    AuthenticationError,
    InvalidInputError,
    is_retriable_error,
    estimate_input_tokens,
)
from .config import OllamaConfig

logger = logging.getLogger(__name__)


class OllamaLLMProvider(BaseLLMProvider):
    """
    Ollama provider using the native /api/chat endpoint.

    Works with:
    - Ollama Cloud (api key + cloud model tag, e.g. "...:cloud")
    - Local Ollama (no key, localhost base URL)
    """

    MAX_INPUT_TOKENS = 128000
    MAX_OUTPUT_TOKENS = 8192
    SUPPORTED_FEATURES = ["streaming"]

    def __init__(self, config: OllamaConfig):
        super().__init__()
        self.config = config
        self._async_client: Optional[httpx.AsyncClient] = None

    def get_provider_name(self) -> str:
        return "ollama"

    def _requires_api_key(self) -> bool:
        """Require API key for non-local endpoints (cloud)."""
        parsed = urlparse((self.config.base_url or "").strip())
        host = (parsed.hostname or "").lower()
        return host not in {"localhost", "127.0.0.1"}

    def is_available(self) -> bool:
        if not self.config.enabled:
            return False
        if self._requires_api_key():
            return bool(self.config.api_key)
        return True

    async def _load_model_impl(self) -> None:
        if not self.is_available():
            reason = (
                f"missing {self.config.api_key_env}"
                if self._requires_api_key() and not self.config.api_key
                else "provider disabled"
            )
            raise ProviderUnavailableError(
                f"Ollama provider not available ({reason})",
                provider="ollama",
            )

        self._async_client = httpx.AsyncClient(timeout=self.config.timeout)
        logger.info("Ollama client initialized")

    async def _shutdown_impl(self) -> None:
        if self._async_client is not None:
            try:
                await self._async_client.aclose()
            except Exception as e:
                logger.warning("Error closing Ollama async client: %s", e)
        self._async_client = None

    def _build_messages(
        self,
        prompt: Optional[str],
        system_prompt: Optional[str],
        messages: Optional[List[Dict[str, str]]],
    ) -> List[Dict[str, str]]:
        ollama_messages: List[Dict[str, str]] = []

        if system_prompt:
            ollama_messages.append({"role": "system", "content": system_prompt})

        if messages:
            for msg in messages:
                role = msg.get("role", "user")
                if role not in {"user", "assistant", "system"}:
                    continue
                ollama_messages.append(
                    {
                        "role": role,
                        "content": msg.get("content", ""),
                    }
                )
        elif prompt:
            ollama_messages.append({"role": "user", "content": prompt})

        return ollama_messages

    def _build_headers(self) -> Dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        return headers

    def _build_payload(
        self,
        messages: List[Dict[str, str]],
        *,
        temperature: float,
        max_tokens: Optional[int],
        stream: bool,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "model": self.config.default_model,
            "messages": messages,
            "stream": stream,
            "options": {
                "temperature": temperature,
            },
        }

        cap = max_tokens or self.config.max_tokens
        if cap:
            payload["options"]["num_predict"] = cap

        return payload

    async def generate(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        stream: bool = False,
        correlation_id: Optional[str] = None,
    ) -> Union[LLMResult, AsyncIterator[LLMResult]]:
        if not self._is_loaded:
            await self.load_model()

        if stream:
            return self.generate_streaming(
                prompt=prompt,
                system_prompt=system_prompt,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                tools=tools,
                tool_choice=tool_choice,
                response_format=response_format,
                correlation_id=correlation_id,
            )

        # Native /api/chat path does not support OpenAI tools/response_format schema.
        if tools or tool_choice or response_format:
            logger.debug("Ollama provider ignoring unsupported tools/response_format options")

        start_time = time.time()
        ollama_messages = self._build_messages(prompt, system_prompt, messages)
        payload = self._build_payload(
            ollama_messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=False,
        )
        url = f"{self.config.base_url.rstrip('/')}/api/chat"
        headers = self._build_headers()

        last_error: Optional[LLMError] = None
        for attempt in range(self.config.retry_attempts):
            try:
                response = await self._async_client.post(url, json=payload, headers=headers)
                if response.status_code >= 400:
                    raise self._status_error(response)

                data = response.json()
                text = (data.get("message", {}) or {}).get("content", "") or ""
                finish_reason = self._map_finish_reason(data.get("done_reason"))

                input_tokens = int(data.get("prompt_eval_count") or estimate_input_tokens(messages=ollama_messages))
                output_tokens = int(data.get("eval_count") or int(len(text.split()) * 1.3))
                processing_time = time.time() - start_time

                return LLMResult(
                    text=text,
                    finish_reason=finish_reason,
                    provider="ollama",
                    model=self.config.default_model,
                    processing_time=processing_time,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=input_tokens + output_tokens,
                    is_partial=False,
                    is_final=True,
                    metadata={"correlation_id": correlation_id, "cost": 0.0},
                    correlation_id=correlation_id,
                )
            except Exception as e:
                last_error = self._handle_error(e, correlation_id)
                if attempt < self.config.retry_attempts - 1 and is_retriable_error(last_error):
                    wait_time = self._calculate_backoff_with_jitter(attempt, self.config.retry_backoff)
                    logger.warning(
                        "Retrying Ollama LLM request",
                        extra={
                            "correlation_id": correlation_id,
                            "attempt": attempt + 1,
                            "wait_time": wait_time,
                            "error": str(last_error),
                        },
                    )
                    await asyncio.sleep(wait_time)
                    continue
                raise last_error

        raise last_error or GenerationError(
            "Ollama generation failed after all retries",
            provider="ollama",
            correlation_id=correlation_id,
        )

    async def generate_streaming(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[LLMResult]:
        if not self._is_loaded:
            await self.load_model()

        start_time = time.time()
        accumulated_text = ""
        input_tokens = estimate_input_tokens(prompt=prompt, system_prompt=system_prompt, messages=messages)

        ollama_messages = self._build_messages(prompt, system_prompt, messages)
        payload = self._build_payload(
            ollama_messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stream=True,
        )
        url = f"{self.config.base_url.rstrip('/')}/api/chat"
        headers = self._build_headers()

        try:
            async with self._async_client.stream("POST", url, json=payload, headers=headers) as response:
                if response.status_code >= 400:
                    raise self._status_error(response)

                async for line in response.aiter_lines():
                    if not line:
                        continue
                    data = json.loads(line)
                    chunk_text = (data.get("message", {}) or {}).get("content", "") or ""

                    if chunk_text:
                        accumulated_text += chunk_text
                        yield LLMResult(
                            text=chunk_text,
                            finish_reason=FinishReason.STOP.value,
                            provider="ollama",
                            model=self.config.default_model,
                            processing_time=time.time() - start_time,
                            input_tokens=input_tokens,
                            output_tokens=int(len(accumulated_text.split()) * 1.3),
                            total_tokens=input_tokens + int(len(accumulated_text.split()) * 1.3),
                            is_partial=True,
                            is_final=False,
                            metadata={"correlation_id": correlation_id},
                            correlation_id=correlation_id,
                        )

                    if data.get("done"):
                        break

            output_tokens = int(len(accumulated_text.split()) * 1.3)
            yield LLMResult(
                text=accumulated_text,
                finish_reason=FinishReason.STOP.value,
                provider="ollama",
                model=self.config.default_model,
                processing_time=time.time() - start_time,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                total_tokens=input_tokens + output_tokens,
                is_partial=False,
                is_final=True,
                metadata={"correlation_id": correlation_id, "cost": 0.0},
                correlation_id=correlation_id,
            )
        except Exception as e:
            raise self._handle_error(e, correlation_id)

    def _status_error(self, response: httpx.Response) -> Exception:
        status = response.status_code
        message = response.text
        if status == 429:
            return RateLimitError(f"Ollama rate limit exceeded: {message}", provider="ollama")
        if status in (401, 403):
            return AuthenticationError(f"Ollama authentication failed: {message}", provider="ollama")
        if status == 400:
            return InvalidInputError(f"Ollama invalid input: {message}", provider="ollama")
        if status in (502, 503, 504):
            return ProviderUnavailableError(f"Ollama service unavailable: {message}", provider="ollama")
        return GenerationError(f"Ollama API error {status}: {message}", provider="ollama", retriable=status >= 500)

    def _map_finish_reason(self, reason: Optional[str]) -> str:
        mapping = {
            None: FinishReason.STOP.value,
            "stop": FinishReason.STOP.value,
            "length": FinishReason.LENGTH.value,
            "max_tokens": FinishReason.LENGTH.value,
            "tool_calls": FinishReason.TOOL_CALLS.value,
            "content_filter": FinishReason.CONTENT_FILTER.value,
        }
        return mapping.get(reason, FinishReason.STOP.value)

    def _handle_error(self, error: Exception, correlation_id: Optional[str]) -> LLMError:
        if isinstance(error, LLMError):
            return error

        if isinstance(error, (ConnectionError, OSError, httpx.NetworkError)):
            return LLMNetworkError(
                f"Ollama network error: {error}",
                provider="ollama",
                correlation_id=correlation_id,
            )
        if isinstance(error, (asyncio.TimeoutError, httpx.TimeoutException)):
            return LLMTimeoutError(
                f"Ollama request timed out: {error}",
                provider="ollama",
                correlation_id=correlation_id,
            )

        err = str(error).lower()
        if "429" in err or "rate limit" in err:
            return RateLimitError(
                f"Ollama rate limit exceeded: {error}", provider="ollama", correlation_id=correlation_id
            )
        if "401" in err or "403" in err or "unauthorized" in err or "authentication" in err:
            return AuthenticationError(
                f"Ollama authentication failed: {error}",
                provider="ollama",
                correlation_id=correlation_id,
            )
        return GenerationError(
            f"Ollama generation failed: {error}",
            provider="ollama",
            correlation_id=correlation_id,
        )

    def _calculate_backoff_with_jitter(self, attempt: int, base_delay: float = 1.0) -> float:
        return random.uniform(0, min(60, base_delay * (2**attempt)))
