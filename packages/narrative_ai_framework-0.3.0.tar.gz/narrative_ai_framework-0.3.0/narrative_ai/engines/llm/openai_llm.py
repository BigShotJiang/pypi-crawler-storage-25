"""
OpenAI LLM Provider.

Implements OpenAI API integration (GPT models).
Supports streaming, function calling, structured outputs, and multi-modal inputs.

Documentation: https://platform.openai.com/docs/api-reference/chat
"""

import asyncio
import time
import logging
from typing import Optional, Dict, Any, List, AsyncIterator, Union

try:
    from openai import OpenAI, AsyncOpenAI
except ImportError:
    OpenAI = None
    AsyncOpenAI = None
    logging.warning("openai not installed. OpenAI provider will not be available.")

from .base_llm import (
    BaseLLMProvider,
    LLMResult,
    LLMError,
    GenerationError,
    ProviderUnavailableError,
    RateLimitError,
    AuthenticationError,
    InvalidInputError,
    ContentFilterError,
    LLMTimeoutError,
    LLMNetworkError,
    FinishReason,
    is_retriable_error,
    estimate_input_tokens,
)
from .config import OpenAIConfig
from .error_mapper import parse_provider_error

logger = logging.getLogger(__name__)


class OpenAILLMProvider(BaseLLMProvider):
    """
    OpenAI LLM provider.

    Supports GPT-4o, GPT-4o-mini, o3-mini, and other OpenAI models.
    """

    MAX_INPUT_TOKENS = 128000  # GPT-4o context window
    MAX_OUTPUT_TOKENS = 16384
    SUPPORTED_FEATURES = ["streaming", "function_calling", "structured_outputs", "multimodal"]

    def __init__(self, config: OpenAIConfig):
        """
        Initialize OpenAI provider.

        Args:
            config: OpenAI configuration
        """
        super().__init__()
        self.config = config
        self._client: Optional[Any] = None
        self._async_client: Optional[Any] = None

    def is_available(self) -> bool:
        """Check if provider is available and configured."""
        if OpenAI is None or AsyncOpenAI is None:
            return False

        if not self.config.api_key:
            return False

        return True

    def get_provider_name(self) -> str:
        """Get provider name."""
        return "openai"

    def _estimate_output_tokens(self, text: str) -> int:
        """
        Estimate output tokens using tiktoken for accurate counting.

        Falls back to word count estimation if tiktoken is not available.

        Args:
            text: Text to estimate tokens for

        Returns:
            Estimated token count
        """
        try:
            import tiktoken

            # Use cl100k_base encoding (used by GPT-4o, GPT-4o-mini, o3-mini)
            encoding = tiktoken.get_encoding("cl100k_base")
            return len(encoding.encode(text))
        except ImportError:
            # Fallback to word count estimation
            return int(len(text.split()) * 1.3)
        except Exception as e:
            logger.warning(f"Token estimation failed, using fallback: {e}")
            return int(len(text.split()) * 1.3)

    async def _load_model_impl(self) -> None:
        """Initialize OpenAI clients."""
        if not self.is_available():
            raise ProviderUnavailableError(
                "OpenAI provider not available (missing API key or SDK)",
                provider="openai",
            )

        try:
            client_kwargs = {
                "api_key": self.config.api_key,
            }

            if self.config.organization_id:
                client_kwargs["organization"] = self.config.organization_id

            self._client = OpenAI(**client_kwargs)
            self._async_client = AsyncOpenAI(**client_kwargs)
            logger.info("OpenAI client initialized")
        except Exception as e:
            raise ProviderUnavailableError(
                f"Failed to initialize OpenAI client: {str(e)}",
                provider="openai",
            ) from e

    async def _shutdown_impl(self) -> None:
        """Cleanup OpenAI clients."""
        try:
            # Close async client's HTTP session if it exists
            if hasattr(self, "_async_client") and self._async_client is not None:
                if hasattr(self._async_client, "_client") and hasattr(self._async_client._client, "close"):
                    await self._async_client._client.close()
                elif hasattr(self._async_client, "close"):
                    await self._async_client.close()
        except Exception as e:
            logger.warning(f"Error closing OpenAI async client: {e}")

        try:
            # Close sync client's HTTP session if it exists
            if hasattr(self, "_client") and self._client is not None:
                if hasattr(self._client, "_client") and hasattr(self._client._client, "close"):
                    self._client._client.close()
                elif hasattr(self._client, "close"):
                    self._client.close()
        except Exception as e:
            logger.warning(f"Error closing OpenAI sync client: {e}")

        self._client = None
        self._async_client = None

    async def generate(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        stream: bool = False,
        correlation_id: Optional[str] = None,
    ) -> Union[LLMResult, AsyncIterator[LLMResult]]:
        """
        Generate text completion using OpenAI.

        Args:
            prompt: User prompt (if messages not provided)
            system_prompt: System instruction
            messages: Conversation history
            temperature: Sampling temperature (0-2)
            max_tokens: Maximum tokens to generate
            tools: Function calling tools
            tool_choice: Tool choice strategy
            response_format: Structured output format (JSON schema)
            stream: Whether to stream response
            correlation_id: Request correlation ID

        Returns:
            LLMResult or AsyncIterator[LLMResult] if streaming
        """
        if not self._is_loaded:
            await self.load_model()

        if stream:
            return self.generate_streaming(
                prompt=prompt,
                system_prompt=system_prompt,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                tools=tools,
                tool_choice=tool_choice,
                response_format=response_format,
                correlation_id=correlation_id,
            )

        start_time = time.time()

        # Build messages
        openai_messages = self._build_messages(prompt, system_prompt, messages)

        # Build request parameters
        request_params = {
            "model": self.config.default_model,
            "messages": openai_messages,
            "temperature": temperature,
        }

        if max_tokens:
            request_params["max_tokens"] = max_tokens
        elif self.config.max_tokens:
            request_params["max_tokens"] = self.config.max_tokens

        # Add tools if function calling requested
        if tools:
            request_params["tools"] = tools
            if tool_choice:
                request_params["tool_choice"] = tool_choice

        # Add structured output if requested. OpenAI expects:
        # - {"type": "json_object"} or {"type": "text"} for simple modes
        # - {"type": "json_schema", "json_schema": {"strict": bool, "name": str, "schema": dict}} for strict
        if response_format:
            self._validate_response_format(response_format, correlation_id)
            request_params["response_format"] = response_format

        # Retry logic with exponential backoff
        last_error = None
        for attempt in range(self.config.retry_attempts):
            try:
                # Generate with timeout
                completion = await asyncio.wait_for(
                    self._async_client.chat.completions.create(**request_params),
                    timeout=self.config.timeout,
                )

                processing_time = time.time() - start_time

                # Extract response
                choice = completion.choices[0]
                text = choice.message.content or ""

                # Extract finish reason
                finish_reason = self._map_finish_reason(choice.finish_reason)

                # Extract token usage
                usage = completion.usage
                input_tokens = usage.prompt_tokens if usage else 0
                output_tokens = usage.completion_tokens if usage else 0

                # Extract tool calls
                tool_calls = None
                if choice.message.tool_calls:
                    tool_calls = [
                        {
                            "id": tc.id,
                            "type": tc.type,
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments,
                            },
                        }
                        for tc in choice.message.tool_calls
                    ]

                # Calculate cost (OpenAI pricing varies by model, using gpt-4o-mini as default: $0.15/$0.60 per 1M tokens)
                # For gpt-4o: $2.50/$10.00 per 1M tokens
                model_name = self.config.default_model
                if "gpt-4o" in model_name and "mini" not in model_name:
                    cost_per_input = 2.50 / 1_000_000
                    cost_per_output = 10.00 / 1_000_000
                else:
                    cost_per_input = 0.15 / 1_000_000
                    cost_per_output = 0.60 / 1_000_000
                cost = (input_tokens * cost_per_input) + (output_tokens * cost_per_output)

                return LLMResult(
                    text=text,
                    finish_reason=finish_reason,
                    provider="openai",
                    model=self.config.default_model,
                    processing_time=processing_time,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=input_tokens + output_tokens,
                    tool_calls=tool_calls,
                    is_partial=False,
                    is_final=True,
                    metadata={
                        "correlation_id": correlation_id,
                        "cost": cost,
                    },
                    correlation_id=correlation_id,
                )

            except asyncio.TimeoutError as e:
                processing_time = time.time() - start_time
                last_error = LLMTimeoutError(
                    f"Request timed out after {self.config.timeout}s",
                    provider="openai",
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e
            except (AuthenticationError, InvalidInputError, ContentFilterError):
                raise
            except RateLimitError as e:
                last_error = e
            except Exception as e:
                processing_time = time.time() - start_time
                last_error = self._handle_error(e, correlation_id)

                if not is_retriable_error(last_error):
                    raise last_error

            if attempt < self.config.retry_attempts - 1 and last_error and is_retriable_error(last_error):
                wait_time = self._get_retry_wait_time(last_error, attempt, self.config.retry_backoff)
                logger.warning(
                    "Retrying OpenAI LLM request",
                    extra={
                        "correlation_id": correlation_id,
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                        "error": str(last_error),
                    },
                )
                await asyncio.sleep(wait_time)

        # All retries exhausted
        if last_error:
            raise last_error

        raise GenerationError(
            "Generation failed after all retries",
            provider="openai",
            correlation_id=correlation_id,
        )

    async def generate_streaming(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[LLMResult]:
        """
        Stream text completion with incremental results.

        Yields:
            LLMResult objects with is_partial=True for interim results
        """
        if not self._is_loaded:
            await self.load_model()

        start_time = time.time()
        accumulated_text = ""

        # Calculate input tokens before streaming
        input_tokens = estimate_input_tokens(
            prompt=prompt,
            system_prompt=system_prompt,
            messages=messages,
        )

        # Build messages
        openai_messages = self._build_messages(prompt, system_prompt, messages)

        # Build request parameters
        request_params = {
            "model": self.config.default_model,
            "messages": openai_messages,
            "temperature": temperature,
            "stream": True,
        }

        if max_tokens:
            request_params["max_tokens"] = max_tokens
        elif self.config.max_tokens:
            request_params["max_tokens"] = self.config.max_tokens

        # Add tools
        if tools:
            request_params["tools"] = tools
            if tool_choice:
                request_params["tool_choice"] = tool_choice

        # Add structured output
        if response_format:
            self._validate_response_format(response_format, correlation_id)
            request_params["response_format"] = response_format

        # Retry logic with exponential backoff
        last_error = None

        for attempt in range(self.config.retry_attempts):
            try:
                # Wrap stream creation with timeout
                stream = await asyncio.wait_for(
                    self._async_client.chat.completions.create(**request_params),
                    timeout=self.config.timeout,
                )

                # Stream chunks with timeout monitoring
                chunk_timeout = self.config.timeout

                try:
                    async for chunk in stream:
                        # Check if we've exceeded overall timeout
                        elapsed = time.time() - start_time
                        if elapsed > chunk_timeout:
                            logger.warning(
                                "Streaming timeout exceeded",
                                extra={"correlation_id": correlation_id, "elapsed": elapsed},
                            )
                            break

                        if chunk.choices and chunk.choices[0].delta.content:
                            chunk_text = chunk.choices[0].delta.content
                            accumulated_text += chunk_text

                            processing_time = time.time() - start_time

                            # Estimate output tokens using tiktoken for accuracy
                            output_tokens_est = self._estimate_output_tokens(accumulated_text)

                            yield LLMResult(
                                # IMPORTANT: emit delta text for streaming consumers (e.g., LiveKit)
                                text=chunk_text,
                                finish_reason=FinishReason.STOP.value,
                                provider="openai",
                                model=self.config.default_model,
                                processing_time=processing_time,
                                input_tokens=input_tokens,
                                output_tokens=int(output_tokens_est),
                                total_tokens=input_tokens + int(output_tokens_est),
                                is_partial=True,
                                is_final=False,
                                metadata={"correlation_id": correlation_id},
                                correlation_id=correlation_id,
                            )
                except Exception as stream_error:
                    # Handle mid-stream errors
                    logger.error(
                        "Error during streaming",
                        extra={"correlation_id": correlation_id, "error": str(stream_error)},
                        exc_info=True,
                    )
                    # Yield a final error result and stop (don't pretend we finished cleanly)
                    processing_time = time.time() - start_time
                    output_tokens = self._estimate_output_tokens(accumulated_text)

                    model_name = self.config.default_model
                    if "gpt-4o" in model_name and "mini" not in model_name:
                        cost_per_input = 2.50 / 1_000_000
                        cost_per_output = 10.00 / 1_000_000
                    elif "o3" in model_name.lower():
                        cost_per_input = 0.15 / 1_000_000
                        cost_per_output = 0.60 / 1_000_000
                    else:
                        cost_per_input = 0.15 / 1_000_000
                        cost_per_output = 0.60 / 1_000_000

                    cost = (input_tokens * cost_per_input) + (int(output_tokens) * cost_per_output)

                    yield LLMResult(
                        text=accumulated_text,
                        finish_reason=FinishReason.ERROR.value,
                        provider="openai",
                        model=self.config.default_model,
                        processing_time=processing_time,
                        input_tokens=input_tokens,
                        output_tokens=int(output_tokens),
                        total_tokens=input_tokens + int(output_tokens),
                        is_partial=False,
                        is_final=True,
                        metadata={
                            "correlation_id": correlation_id,
                            "cost": cost,
                            "error": str(stream_error),
                        },
                        correlation_id=correlation_id,
                    )
                    return

                # Final result
                processing_time = time.time() - start_time

                # Estimate final output tokens using tiktoken
                output_tokens = self._estimate_output_tokens(accumulated_text)

                # Calculate cost (OpenAI pricing varies by model)
                model_name = self.config.default_model
                if "gpt-4o" in model_name and "mini" not in model_name:
                    cost_per_input = 2.50 / 1_000_000
                    cost_per_output = 10.00 / 1_000_000
                elif "o3" in model_name.lower():
                    # o3-mini pricing (approximate)
                    cost_per_input = 0.15 / 1_000_000
                    cost_per_output = 0.60 / 1_000_000
                else:
                    # Default to gpt-4o-mini pricing
                    cost_per_input = 0.15 / 1_000_000
                    cost_per_output = 0.60 / 1_000_000

                cost = (input_tokens * cost_per_input) + (int(output_tokens) * cost_per_output)

                yield LLMResult(
                    text=accumulated_text,
                    finish_reason=FinishReason.STOP.value,
                    provider="openai",
                    model=self.config.default_model,
                    processing_time=processing_time,
                    input_tokens=input_tokens,
                    output_tokens=int(output_tokens),
                    total_tokens=input_tokens + int(output_tokens),
                    is_partial=False,
                    is_final=True,
                    metadata={
                        "correlation_id": correlation_id,
                        "cost": cost,
                    },
                    correlation_id=correlation_id,
                )

                # Success - break retry loop
                return

            except asyncio.TimeoutError as e:
                processing_time = time.time() - start_time
                last_error = LLMTimeoutError(
                    f"Request timed out after {self.config.timeout}s",
                    provider="openai",
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e
            except (AuthenticationError, InvalidInputError, ContentFilterError):
                raise
            except RateLimitError as e:
                last_error = e
            except Exception as e:
                processing_time = time.time() - start_time
                last_error = self._handle_error(e, correlation_id)

                if not is_retriable_error(last_error):
                    raise last_error

            if attempt < self.config.retry_attempts - 1 and last_error and is_retriable_error(last_error):
                wait_time = self._get_retry_wait_time(last_error, attempt, self.config.retry_backoff)
                logger.warning(
                    "Retrying OpenAI streaming request",
                    extra={
                        "correlation_id": correlation_id,
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                        "error": str(last_error),
                    },
                )
                await asyncio.sleep(wait_time)

        # All retries exhausted
        if last_error:
            raise last_error

        raise GenerationError(
            "Streaming failed after all retries",
            provider="openai",
            correlation_id=correlation_id,
        )

    def _build_messages(
        self,
        prompt: Optional[str],
        system_prompt: Optional[str],
        messages: Optional[List[Dict[str, str]]],
    ) -> List[Dict[str, str]]:
        """
        Build messages for OpenAI API.

        Args:
            prompt: User prompt
            system_prompt: System instruction
            messages: Conversation messages

        Returns:
            List of message dicts
        """
        openai_messages = []

        # Add system message if provided
        if system_prompt:
            openai_messages.append(
                {
                    "role": "system",
                    "content": system_prompt,
                }
            )

        # Use messages if provided, otherwise use prompt
        if messages:
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")

                # Map roles
                if role == "assistant":
                    openai_messages.append({"role": "assistant", "content": content})
                elif role == "user":
                    openai_messages.append({"role": "user", "content": content})
                # System messages already added above
        elif prompt:
            openai_messages.append(
                {
                    "role": "user",
                    "content": prompt,
                }
            )

        return openai_messages

    def _map_finish_reason(self, openai_reason: Optional[str]) -> str:
        """Map OpenAI finish reason to standard format."""
        if not openai_reason:
            return FinishReason.STOP.value

        mapping = {
            "stop": FinishReason.STOP.value,
            "length": FinishReason.LENGTH.value,
            "tool_calls": FinishReason.TOOL_CALLS.value,
            "content_filter": FinishReason.CONTENT_FILTER.value,
        }
        return mapping.get(openai_reason, FinishReason.STOP.value)

    def _handle_error(self, error: Exception, correlation_id: Optional[str]) -> LLMError:
        """
        Handle and classify errors from OpenAI API using provider-specific error mapper.

        Args:
            error: Exception from API
            correlation_id: Request correlation ID

        Returns:
            Appropriate LLMError subclass with rich error details
        """
        # Network/connection errors (check before provider-specific parsing)
        if isinstance(error, (ConnectionError, OSError)):
            return LLMNetworkError(
                f"OpenAI network error: {error}",
                provider="openai",
                correlation_id=correlation_id,
            )
        try:
            import httpx

            if isinstance(error, httpx.TimeoutException):
                return LLMTimeoutError(
                    f"OpenAI request timed out: {error}",
                    provider="openai",
                    correlation_id=correlation_id,
                )
            if isinstance(error, httpx.NetworkError):
                return LLMNetworkError(
                    f"OpenAI network error: {error}",
                    provider="openai",
                    correlation_id=correlation_id,
                )
        except ImportError:
            pass
        try:
            from openai import APITimeoutError, APIConnectionError

            # APITimeoutError extends APIConnectionError - check timeout first
            if isinstance(error, APITimeoutError):
                return LLMTimeoutError(
                    f"OpenAI request timed out: {error}",
                    provider="openai",
                    correlation_id=correlation_id,
                )
            if isinstance(error, APIConnectionError):
                return LLMNetworkError(
                    f"OpenAI connection error: {error}",
                    provider="openai",
                    correlation_id=correlation_id,
                )
        except ImportError:
            pass

        # Use provider-specific error mapper for rich error details
        mapped_error, error_details = parse_provider_error(error, "openai", correlation_id)

        # Log error details for observability
        logger.debug(
            "OpenAI error mapped",
            extra={
                "correlation_id": correlation_id,
                "error_type": type(error).__name__,
                "mapped_type": type(mapped_error).__name__,
                "error_details": error_details,
            },
        )

        return mapped_error

    def _validate_response_format(
        self,
        response_format: Dict,
        correlation_id: Optional[str] = None,
    ) -> None:
        """
        Validate response_format structure for OpenAI API.
        Logs a warning if format appears malformed.
        Expected: {"type": "json_object"|"text"|"json_schema", "json_schema": {...}?}
        """
        if not isinstance(response_format, dict):
            logger.warning(
                "response_format should be a dict; got %s",
                type(response_format).__name__,
                extra={"correlation_id": correlation_id},
            )
            return
        rtype = response_format.get("type")
        if rtype not in ("json_object", "text", "json_schema"):
            logger.warning(
                "response_format.type should be 'json_object', 'text', or 'json_schema'; got %r. "
                "See https://platform.openai.com/docs/guides/structured-outputs",
                rtype,
                extra={"correlation_id": correlation_id},
            )
        elif rtype == "json_schema" and "json_schema" not in response_format:
            logger.warning(
                "response_format with type='json_schema' should include 'json_schema' key with "
                "strict, name, and schema. See OpenAI structured outputs docs.",
                extra={"correlation_id": correlation_id},
            )

    def _calculate_backoff_with_jitter(self, attempt: int, base_delay: float = 1.0) -> float:
        """
        Calculate exponential backoff with jitter.

        Uses "full jitter" strategy to prevent thundering herd.

        Args:
            attempt: Current attempt number (0-indexed)
            base_delay: Base delay in seconds

        Returns:
            Delay in seconds with jitter applied
        """
        import random

        cap = 30.0  # Maximum delay cap
        exponential_delay = min(cap, base_delay * (2**attempt))
        return random.uniform(0, exponential_delay)

    def _get_retry_wait_time(self, error: Optional[Exception], attempt: int, base_delay: float = 1.0) -> float:
        """Get wait time for retry; respect Retry-After for RateLimitError, else backoff with jitter."""
        import random

        if error is not None and isinstance(error, RateLimitError) and getattr(error, "retry_after", None) is not None:
            delay = float(error.retry_after)
            # Add ±25% jitter to avoid thundering herd
            jitter = delay * 0.25 * (2 * random.random() - 1)
            return max(0.5, min(300.0, delay + jitter))
        return self._calculate_backoff_with_jitter(attempt, base_delay)
