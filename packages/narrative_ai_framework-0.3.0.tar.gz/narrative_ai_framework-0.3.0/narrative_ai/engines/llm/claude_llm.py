"""
Anthropic Claude LLM Provider.

Implements Anthropic Claude API integration using the official Python SDK.
Supports streaming and non-streaming text generation in a way that matches
the existing provider interfaces (OpenAI, Gemini, xAI, DeepSeek).

Docs: https://platform.claude.com/docs/en/api/overview
"""

import asyncio
import time
import logging
from typing import Optional, Dict, Any, List, Tuple, AsyncIterator, Union

try:
    from anthropic import Anthropic, AsyncAnthropic  # type: ignore
except ImportError:  # pragma: no cover - handled by is_available()
    Anthropic = None
    AsyncAnthropic = None
    logging.warning("anthropic SDK not installed. Anthropic/Claude provider will not be available.")

from .base_llm import (
    BaseLLMProvider,
    LLMResult,
    LLMError,
    GenerationError,
    ProviderUnavailableError,
    RateLimitError,
    AuthenticationError,
    InvalidInputError,
    ContentFilterError,
    LLMTimeoutError,
    LLMNetworkError,
    FinishReason,
    is_retriable_error,
    estimate_input_tokens,
)
from .config import AnthropicConfig

logger = logging.getLogger(__name__)


class ClaudeLLMProvider(BaseLLMProvider):
    """
    Anthropic Claude LLM provider.

    Uses the official Anthropic Python SDK (Anthropic / AsyncAnthropic).
    Supports Claude 3 models such as claude-3-5-sonnet, claude-3-opus, etc.
    """

    # Anthropic supports very large context windows on Claude 3.5 models.
    MAX_INPUT_TOKENS = 200_000
    MAX_OUTPUT_TOKENS = 8_192
    SUPPORTED_FEATURES = ["streaming", "structured_outputs"]

    def __init__(self, config: AnthropicConfig):
        """
        Initialize Anthropic provider.

        Args:
            config: Anthropic configuration
        """
        super().__init__()
        self.config = config
        self._client: Optional[Any] = None
        self._async_client: Optional[Any] = None

    def is_available(self) -> bool:
        """Check if provider is available and configured."""
        if Anthropic is None or AsyncAnthropic is None:
            return False

        if not self.config.api_key:
            return False

        return True

    def get_provider_name(self) -> str:
        """Get provider name."""
        return "anthropic"

    def _estimate_output_tokens(self, text: str) -> int:
        """
        Estimate output tokens for Claude.

        Anthropic provides a separate token counting API, but to keep parity
        with other providers we approximate using character length.

        Args:
            text: Text to estimate tokens for

        Returns:
            Estimated token count
        """
        # Rough heuristic: ~4 characters per token for multilingual text/code
        char_count = len(text)
        return max(1, char_count // 4) if char_count else 0

    async def _load_model_impl(self) -> None:
        """Initialize Anthropic clients."""
        if not self.is_available():
            raise ProviderUnavailableError(
                "Anthropic/Claude provider not available (missing API key or SDK)",
                provider="anthropic",
            )

        try:
            client_kwargs: Dict[str, Any] = {
                "api_key": self.config.api_key,
            }
            if self.config.base_url:
                # Optional custom endpoint (e.g., via proxy)
                client_kwargs["base_url"] = self.config.base_url

            self._client = Anthropic(**client_kwargs)
            self._async_client = AsyncAnthropic(**client_kwargs)
            logger.info("Anthropic/Claude client initialized")
        except Exception as e:  # pragma: no cover - network / SDK errors
            raise ProviderUnavailableError(
                f"Failed to initialize Anthropic client: {str(e)}",
                provider="anthropic",
            ) from e

    async def _shutdown_impl(self) -> None:
        """Cleanup Anthropic clients."""
        try:
            # Close async client's HTTP session if it exists
            if hasattr(self, "_async_client") and self._async_client is not None:
                if hasattr(self._async_client, "_client") and hasattr(self._async_client._client, "close"):
                    await self._async_client._client.close()
                elif hasattr(self._async_client, "close"):
                    await self._async_client.close()
        except Exception as e:
            logger.warning(f"Error closing Anthropic async client: {e}")

        try:
            # Close sync client's HTTP session if it exists
            if hasattr(self, "_client") and self._client is not None:
                if hasattr(self._client, "_client") and hasattr(self._client._client, "close"):
                    self._client._client.close()
                elif hasattr(self._client, "close"):
                    self._client.close()
        except Exception as e:
            logger.warning(f"Error closing Anthropic sync client: {e}")

        self._client = None
        self._async_client = None

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    async def generate(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        stream: bool = False,
        correlation_id: Optional[str] = None,
    ) -> Union[LLMResult, AsyncIterator[LLMResult]]:
        """
        Generate text completion using Anthropic Claude Messages API.

        Args:
            prompt: User prompt (if messages not provided)
            system_prompt: System instruction
            messages: Conversation history in OpenAI-like format
            temperature: Sampling temperature (0-2)
            max_tokens: Maximum tokens to generate
            tools: (Not yet mapped; placeholder for future function calling)
            tool_choice: Placeholder for future use
            response_format: Optional JSON schema / structured output config
            stream: Whether to stream response
            correlation_id: Request correlation ID
        """
        if not self._is_loaded:
            await self.load_model()

        if stream:
            return self.generate_streaming(
                prompt=prompt,
                system_prompt=system_prompt,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                tools=tools,
                tool_choice=tool_choice,
                response_format=response_format,
                correlation_id=correlation_id,
            )

        start_time = time.time()

        # Build messages in Anthropic format (system messages filtered out, merged into top-level system)
        anth_messages, merged_system = self._build_messages(prompt, system_prompt, messages)

        # Build request parameters
        request_params: Dict[str, Any] = {
            "model": self.config.default_model,
            "messages": anth_messages,
            "temperature": temperature,
            "max_tokens": max_tokens or self.config.max_tokens,
        }

        # Anthropic uses 'system' as top-level param, NOT in messages array
        if merged_system:
            request_params["system"] = merged_system

        # Retry logic with exponential backoff
        last_error: Optional[Exception] = None
        for attempt in range(self.config.retry_attempts):
            try:
                # Wrap API call with timeout
                response = await asyncio.wait_for(
                    self._async_client.messages.create(**request_params),  # type: ignore[attr-defined]
                    timeout=self.config.timeout,
                )

                processing_time = time.time() - start_time

                # Extract text
                text = self._extract_text_from_response(response)

                # Extract finish reason
                finish_reason = self._map_finish_reason(getattr(response, "stop_reason", None))

                # Extract token usage
                input_tokens = getattr(getattr(response, "usage", None), "input_tokens", 0)
                output_tokens = getattr(getattr(response, "usage", None), "output_tokens", 0)

                # Tool calls / structured outputs not yet wired; placeholder
                tool_calls = None

                # Very rough cost estimate (example numbers; adjust via config if needed)
                # e.g., $3 per 1M input tokens, $15 per 1M output tokens for Claude Sonnet
                cost_per_input = 3.0 / 1_000_000
                cost_per_output = 15.0 / 1_000_000
                cost = (input_tokens * cost_per_input) + (output_tokens * cost_per_output)

                return LLMResult(
                    text=text,
                    finish_reason=finish_reason,
                    provider="anthropic",
                    model=self.config.default_model,
                    processing_time=processing_time,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=input_tokens + output_tokens,
                    tool_calls=tool_calls,
                    is_partial=False,
                    is_final=True,
                    metadata={
                        "correlation_id": correlation_id,
                        "cost": cost,
                    },
                    correlation_id=correlation_id,
                )

            except asyncio.TimeoutError as e:
                processing_time = time.time() - start_time
                last_error = LLMTimeoutError(
                    f"Request timed out after {self.config.timeout}s",
                    provider="anthropic",
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e
                logger.warning(
                    "Anthropic request timeout",
                    extra={
                        "provider": "anthropic",
                        "model": self.config.default_model,
                        "timeout": self.config.timeout,
                        "correlation_id": correlation_id,
                    },
                )

            except LLMError as e:
                # Already classified error (RateLimitError, AuthenticationError, etc.)
                last_error = e

            except Exception as e:
                # Generic error -> classify
                last_error = self._classify_and_wrap_error(e, correlation_id)

            # Exponential backoff with jitter; respect Retry-After for rate limits
            if attempt < self.config.retry_attempts - 1 and last_error and is_retriable_error(last_error):
                wait_time = self._get_retry_wait_time(last_error, attempt, self.config.retry_backoff)
                logger.warning(
                    "Retrying Anthropic request",
                    extra={
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                        "provider": "anthropic",
                        "correlation_id": correlation_id,
                        "error": str(last_error),
                    },
                )
                await asyncio.sleep(wait_time)
            else:
                break

        if last_error:
            raise last_error

        raise GenerationError(
            "Anthropic generation failed for unknown reasons",
            provider="anthropic",
            correlation_id=correlation_id,
        )

    async def generate_streaming(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[LLMResult]:
        """
        Stream text completion using Anthropic Claude.

        Yields incremental `LLMResult` objects with `is_partial=True` for
        streaming chunks, and a final one with `is_final=True`.
        """
        if not self._is_loaded:
            await self.load_model()

        # Build messages in Anthropic format (system messages filtered out, merged into top-level system)
        anth_messages, merged_system = self._build_messages(prompt, system_prompt, messages)

        request_params: Dict[str, Any] = {
            "model": self.config.default_model,
            "messages": anth_messages,
            "temperature": temperature,
            "max_tokens": max_tokens or self.config.max_tokens,
            "stream": True,
        }
        if merged_system:
            request_params["system"] = merged_system

        start_time = time.time()
        accumulated_text = ""
        input_tokens_est = estimate_input_tokens(prompt=prompt, system_prompt=system_prompt, messages=messages)

        last_error: Optional[Exception] = None
        for attempt in range(self.config.retry_attempts):
            try:
                # The SDK returns an async iterator of events
                stream = await asyncio.wait_for(
                    self._async_client.messages.create(**request_params),  # type: ignore[attr-defined]
                    timeout=self.config.timeout,
                )

                async for event in stream:
                    chunk_text = self._extract_text_from_stream_event(event)
                    if not chunk_text:
                        continue

                    accumulated_text += chunk_text
                    output_tokens_est = self._estimate_output_tokens(accumulated_text)
                    processing_time = time.time() - start_time

                    yield LLMResult(
                        text=chunk_text,
                        finish_reason=FinishReason.STOP.value,
                        provider="anthropic",
                        model=self.config.default_model,
                        processing_time=processing_time,
                        input_tokens=input_tokens_est,
                        output_tokens=output_tokens_est,
                        total_tokens=input_tokens_est + output_tokens_est,
                        is_partial=True,
                        is_final=False,
                        metadata={
                            "correlation_id": correlation_id,
                        },
                        correlation_id=correlation_id,
                    )

                # Final aggregated result
                processing_time = time.time() - start_time
                output_tokens_est = self._estimate_output_tokens(accumulated_text)

                yield LLMResult(
                    text=accumulated_text,
                    finish_reason=FinishReason.STOP.value,
                    provider="anthropic",
                    model=self.config.default_model,
                    processing_time=processing_time,
                    input_tokens=input_tokens_est,
                    output_tokens=output_tokens_est,
                    total_tokens=input_tokens_est + output_tokens_est,
                    is_partial=False,
                    is_final=True,
                    metadata={
                        "correlation_id": correlation_id,
                    },
                    correlation_id=correlation_id,
                )
                return  # Success - exit retry loop

            except asyncio.TimeoutError as e:
                last_error = LLMTimeoutError(
                    f"Streaming request timed out after {self.config.timeout}s",
                    provider="anthropic",
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e
            except (RateLimitError, AuthenticationError, InvalidInputError, ContentFilterError):
                raise
            except Exception as e:
                last_error = self._classify_and_wrap_error(e, correlation_id)
                if not is_retriable_error(last_error):
                    raise last_error

            if attempt < self.config.retry_attempts - 1 and last_error:
                wait_time = self._get_retry_wait_time(last_error, attempt, self.config.retry_backoff)
                logger.warning(
                    "Retrying Anthropic streaming request",
                    extra={
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                        "provider": "anthropic",
                        "correlation_id": correlation_id,
                        "error": str(last_error),
                    },
                )
                await asyncio.sleep(wait_time)

        if last_error:
            raise last_error
        raise GenerationError(
            "Anthropic streaming failed after all retries",
            provider="anthropic",
            correlation_id=correlation_id,
        )

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    def _calculate_backoff_with_jitter(self, attempt: int, base_delay: float = 1.0) -> float:
        """Calculate exponential backoff with jitter (full jitter strategy)."""
        import random

        cap = 30.0
        exponential_delay = min(cap, base_delay * (2**attempt))
        return random.uniform(0, exponential_delay)

    def _get_retry_wait_time(self, error: Exception, attempt: int, base_delay: float = 1.0) -> float:
        """Get wait time for retry; respect Retry-After for RateLimitError, else backoff with jitter."""
        import random

        if isinstance(error, RateLimitError) and getattr(error, "retry_after", None) is not None:
            delay = float(error.retry_after)
            # Add ±25% jitter to avoid thundering herd
            jitter = delay * 0.25 * (2 * random.random() - 1)
            return max(0.5, min(300.0, delay + jitter))
        return self._calculate_backoff_with_jitter(attempt, base_delay)

    def _build_messages(
        self,
        prompt: Optional[str],
        system_prompt: Optional[str],
        messages: Optional[List[Dict[str, str]]],
    ) -> Tuple[List[Dict[str, Any]], str]:
        """
        Convert OpenAI-style messages into Anthropic Messages API format.

        Anthropic expects: [{"role": "user"|"assistant", "content": "text"}]
        with system as a top-level param, NOT in the messages array.

        Returns:
            Tuple of (messages_list, merged_system_content)
        """
        if messages:
            filtered: List[Dict[str, Any]] = []
            system_parts: List[str] = []
            if system_prompt and system_prompt.strip():
                system_parts.append(system_prompt.strip())
            for m in messages:
                role = m.get("role", "user")
                content = (m.get("content") or "").strip()
                if not content:
                    continue
                if role == "system":
                    system_parts.append(content)
                elif role in ("user", "assistant"):
                    filtered.append({"role": role, "content": content})
            merged_system = "\n\n".join(system_parts) if system_parts else ""
            return (filtered, merged_system)

        # Fallback: single user message with optional system prompt handled separately
        user_content = prompt or ""
        if not user_content:
            raise InvalidInputError(
                "Either 'prompt' or 'messages' must be provided",
                provider="anthropic",
            )

        return ([{"role": "user", "content": user_content}], system_prompt or "")

    def _extract_text_from_response(self, response: Any) -> str:
        """
        Extract text content from a non-streaming Anthropic response.

        Response format (simplified):
            {
              "content": [
                {"type": "text", "text": "..."},
                {"type": "tool_use", ...}
              ],
              "stop_reason": "end_turn",
              "usage": {"input_tokens": ..., "output_tokens": ...}
            }
        """
        try:
            parts = getattr(response, "content", None) or []
            texts: List[str] = []
            for part in parts:
                # New SDK uses dict-like attributes or objects; handle both
                p_type = getattr(part, "type", None) or getattr(part, "role", None)
                if p_type == "text":
                    text_val = getattr(part, "text", None) or getattr(part, "content", None)
                    if text_val:
                        texts.append(str(text_val))
            return "".join(texts)
        except Exception as e:  # pragma: no cover - defensive
            logger.warning(f"Failed to extract text from Anthropic response: {e}")
            return ""

    def _extract_text_from_stream_event(self, event: Any) -> str:
        """
        Extract incremental text from a streaming event.

        Per Anthropic API docs (https://docs.anthropic.com/en/api/messages-streaming):
        - content_block_delta with delta.type="text_delta" contains delta.text
        - input_json_delta, thinking_delta, signature_delta are not text; skip them
        - Handle unknown event types gracefully per Anthropic versioning policy
        """
        try:
            # Support both object and dict-like events (SDK may vary)
            ev_type = getattr(event, "type", None) or (event.get("type") if isinstance(event, dict) else None)
            if ev_type != "content_block_delta":
                return ""

            delta = getattr(event, "delta", None) or (event.get("delta") if isinstance(event, dict) else None)
            if delta is None:
                return ""

            # Only extract from text_delta; skip input_json_delta, thinking_delta, signature_delta
            delta_type = getattr(delta, "type", None) or (delta.get("type") if isinstance(delta, dict) else None)
            if delta_type != "text_delta":
                return ""

            text = getattr(delta, "text", None) or (delta.get("text") if isinstance(delta, dict) else None)
            return str(text) if text else ""
        except Exception as e:  # pragma: no cover - defensive
            logger.debug(f"Ignoring malformed Anthropic stream event: {e}")
        return ""

    def _map_finish_reason(self, reason: Optional[str]) -> str:
        """
        Map Anthropic stop_reason to internal FinishReason.
        """
        if not reason:
            return FinishReason.STOP.value

        reason = str(reason)
        mapping = {
            "end_turn": FinishReason.STOP.value,
            "max_tokens": FinishReason.LENGTH.value,
            "stop_sequence": FinishReason.STOP.value,
            "tool_use": FinishReason.TOOL_CALLS.value,
            "content_filter": FinishReason.CONTENT_FILTER.value,
        }
        return mapping.get(reason, FinishReason.STOP.value)

    def _classify_and_wrap_error(self, error: Exception, correlation_id: Optional[str]) -> LLMError:
        """
        Classify generic exceptions into specific LLMError subclasses.
        """
        # Network/connection errors (check before string-based classification)
        if isinstance(error, (ConnectionError, OSError)):
            return LLMNetworkError(
                f"Anthropic network error: {error}",
                provider="anthropic",
                correlation_id=correlation_id,
            )
        try:
            import httpx

            if isinstance(error, httpx.TimeoutException):
                return LLMTimeoutError(
                    f"Anthropic request timed out: {error}",
                    provider="anthropic",
                    correlation_id=correlation_id,
                )
            if isinstance(error, httpx.NetworkError):
                return LLMNetworkError(
                    f"Anthropic network error: {error}",
                    provider="anthropic",
                    correlation_id=correlation_id,
                )
        except ImportError:
            pass
        try:
            from anthropic import APITimeoutError, APIConnectionError

            # APITimeoutError extends APIConnectionError - check timeout first
            if isinstance(error, APITimeoutError):
                return LLMTimeoutError(
                    f"Anthropic request timed out: {error}",
                    provider="anthropic",
                    correlation_id=correlation_id,
                )
            if isinstance(error, APIConnectionError):
                return LLMNetworkError(
                    f"Anthropic connection error: {error}",
                    provider="anthropic",
                    correlation_id=correlation_id,
                )
        except ImportError:
            pass
        try:
            import aiohttp

            if aiohttp is not None and isinstance(error, aiohttp.ClientError):
                return LLMNetworkError(
                    f"Anthropic connection error: {error}",
                    provider="anthropic",
                    correlation_id=correlation_id,
                )
        except ImportError:
            pass

        msg = str(error).lower()

        # Very rough pattern-based classification
        if "rate limit" in msg or "too many requests" in msg or "429" in msg:
            return RateLimitError(
                f"Anthropic rate limit exceeded: {error}",
                provider="anthropic",
                correlation_id=correlation_id,
            )
        if "unauthorized" in msg or "invalid api key" in msg or "401" in msg:
            return AuthenticationError(
                f"Anthropic authentication failed: {error}",
                provider="anthropic",
                correlation_id=correlation_id,
            )
        if "safety" in msg or "blocked" in msg or "content" in msg:
            return ContentFilterError(
                f"Anthropic content filtered: {error}",
                provider="anthropic",
                correlation_id=correlation_id,
            )

        # Default: generic generation error
        return GenerationError(
            f"Anthropic generation error: {error}",
            provider="anthropic",
            correlation_id=correlation_id,
        )
