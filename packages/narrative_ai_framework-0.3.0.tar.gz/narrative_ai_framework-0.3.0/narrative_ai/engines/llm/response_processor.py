"""
LLM Response Processor - Post-processing and Emotion Extraction.

Processes LLM responses to:
- Extract emotion from text
- Validate response format
- Normalize response across providers
- Extract metadata (tool calls, finish reasons, etc.)

Production-Ready Features:
- Keyword-based emotion detection
- Sentiment analysis support
- Arabic and English support
- Confidence scoring
"""

import re
import logging
from typing import Optional, Dict, Any, Tuple, List

from .base_llm import (
    LLMResult,
    Emotion,
    FinishReason,
)

logger = logging.getLogger(__name__)


# =============================================================================
# Emotion Keywords (Arabic and English)
# =============================================================================

EMOTION_KEYWORDS = {
    Emotion.HAPPY: {
        "en": [
            "happy",
            "joy",
            "glad",
            "excited",
            "cheerful",
            "delighted",
            "wonderful",
            "great",
            "amazing",
            "fantastic",
            "excellent",
            "smile",
            "laugh",
            "celebrate",
            "thrilled",
            "pleased",
        ],
        "ar": [
            "سعيد",
            "فرح",
            "مبسوط",
            "مسرور",
            "مبسوط",
            "فرحان",
            "رائع",
            "عظيم",
            "ممتاز",
            "جميل",
            "حلو",
        ],
    },
    Emotion.SAD: {
        "en": [
            "sad",
            "sorrow",
            "unhappy",
            "depressed",
            "melancholy",
            "disappointed",
            "upset",
            "hurt",
            "grief",
            "mournful",
            "tears",
            "crying",
            "lonely",
            "miserable",
            "down",
        ],
        "ar": [
            "حزين",
            "زعلان",
            "مكتئب",
            "محبط",
            "حزين",
            "مهموم",
            "كئيب",
            "بائس",
            "مأساوي",
        ],
    },
    Emotion.CALM: {
        "en": [
            "calm",
            "peaceful",
            "relaxed",
            "serene",
            "tranquil",
            "quiet",
            "gentle",
            "soothing",
            "comfortable",
            "at ease",
            "zen",
            "meditation",
            "mindful",
            "balanced",
        ],
        "ar": [
            "هادئ",
            "مطمئن",
            "مرتاح",
            "ساكن",
            "مستريح",
            "راحة",
            "طمأنينة",
            "سلام",
        ],
    },
    Emotion.ANXIOUS: {
        "en": [
            "anxious",
            "worried",
            "nervous",
            "stressed",
            "tense",
            "fearful",
            "afraid",
            "concerned",
            "uneasy",
            "restless",
            "panic",
            "frightened",
            "apprehensive",
            "jittery",
        ],
        "ar": [
            "قلق",
            "مضطرب",
            "خائف",
            "متوتر",
            "مذعور",
            "مشغول",
            "مهموم",
            "خوف",
            "توتر",
        ],
    },
    Emotion.ANGRY: {
        "en": [
            "angry",
            "mad",
            "furious",
            "irritated",
            "annoyed",
            "frustrated",
            "rage",
            "outraged",
            "livid",
            "enraged",
            "upset",
            "disgusted",
            "hostile",
            "aggressive",
        ],
        "ar": [
            "غاضب",
            "زعلان",
            "ناقم",
            "مستاء",
            "مغتاظ",
            "غضب",
            "سخط",
            "استياء",
        ],
    },
    Emotion.EMPATHETIC: {
        "en": [
            "understand",
            "feel",
            "empathy",
            "compassion",
            "sympathy",
            "support",
            "care",
            "concern",
            "comfort",
            "reassure",
            "acknowledge",
            "validate",
            "listen",
        ],
        "ar": [
            "أفهم",
            "أشعر",
            "تعاطف",
            "دعم",
            "رعاية",
            "مواساة",
            "طمأنة",
            "تفهم",
        ],
    },
    Emotion.EXCITED: {
        "en": [
            "excited",
            "thrilled",
            "pumped",
            "enthusiastic",
            "eager",
            "energetic",
            "vibrant",
            "lively",
            "animated",
        ],
        "ar": [
            "متحمس",
            "متحفز",
            "نشيط",
            "حيوي",
        ],
    },
    Emotion.SURPRISED: {
        "en": [
            "surprised",
            "shocked",
            "amazed",
            "astonished",
            "stunned",
            "wow",
            "incredible",
            "unbelievable",
            "unexpected",
        ],
        "ar": [
            "مندهش",
            "مصدوم",
            "مذهول",
            "مفاجئ",
        ],
    },
    Emotion.THOUGHTFUL: {
        "en": [
            "think",
            "consider",
            "reflect",
            "contemplate",
            "ponder",
            "thoughtful",
            "meditative",
            "introspective",
            "deliberate",
        ],
        "ar": [
            "يفكر",
            "يتأمل",
            "يتدبر",
            "يتفكر",
            "تأمل",
        ],
    },
}


# =============================================================================
# Response Processor
# =============================================================================


class ResponseProcessor:
    """
    Processes LLM responses for post-processing and emotion extraction.

    Features:
    - Emotion extraction from text (keyword-based + sentiment)
    - Response validation
    - Format normalization
    - Metadata extraction
    """

    def __init__(self, enable_emotion_extraction: bool = True):
        """
        Initialize response processor.

        Args:
            enable_emotion_extraction: Whether to extract emotion from responses
        """
        self.enable_emotion_extraction = enable_emotion_extraction

    def process(
        self,
        raw_response: LLMResult,
        language: str = "en",
    ) -> LLMResult:
        """
        Process raw provider response into standardized LLMResult.

        Args:
            raw_response: Raw LLMResult from provider
            language: Language code ("en", "ar", "mixed")

        Returns:
            Processed LLMResult with emotion extracted
        """
        # Extract emotion if enabled
        if self.enable_emotion_extraction and raw_response.text:
            emotion, confidence = self.extract_emotion(raw_response.text, language)
            raw_response.emotion = emotion
            raw_response.emotion_confidence = confidence

        # Validate response
        self.validate_response(raw_response)

        return raw_response

    def extract_emotion(
        self,
        text: str,
        language: str = "en",
    ) -> Tuple[Optional[Emotion], float]:
        """
        Extract emotion from response text.

        Uses keyword matching and simple sentiment analysis.
        Supports Arabic and English.

        Args:
            text: Response text
            language: Language code ("en", "ar", "mixed")

        Returns:
            Tuple of (emotion, confidence) where confidence is 0.0-1.0
        """
        if not text:
            return None, 0.0

        text_lower = text.lower()

        # Score each emotion based on keyword matches
        emotion_scores: Dict[Emotion, float] = {}

        # Determine languages to check
        languages_to_check = []
        if language == "mixed" or language == "auto":
            languages_to_check = ["en", "ar"]
        else:
            languages_to_check = [language]

        # Negation patterns to detect negative contexts (e.g., "not happy", "I'm not sad")
        negation_patterns = [
            r"\b(?:not|no|never|n't|isn't|aren't|wasn't|weren't|don't|doesn't|didn't|can't|couldn't|won't|wouldn't|shouldn't|mustn't)\s+",
            r"\b(?:without|lack|missing|absence)\s+",
        ]
        negation_regex = re.compile("|".join(negation_patterns), re.IGNORECASE)

        # Count keyword matches for each emotion
        for emotion, keywords_dict in EMOTION_KEYWORDS.items():
            score = 0.0
            total_matches = 0

            for lang in languages_to_check:
                if lang in keywords_dict:
                    for keyword in keywords_dict[lang]:
                        # Count occurrences (case-insensitive)
                        pattern = re.compile(rf"\b{re.escape(keyword)}\b", re.IGNORECASE)
                        matches = pattern.findall(text_lower)

                        # Check for negation before each match
                        for match in matches:
                            match_pos = text_lower.find(match)
                            if match_pos > 0:
                                # Check 5 words before the match for negation
                                context_start = max(0, match_pos - 50)  # ~5 words before
                                context = text_lower[context_start:match_pos]
                                if negation_regex.search(context):
                                    # Negated emotion - reduce score or skip
                                    continue

                            total_matches += 1
                            # Weight by keyword length (longer keywords = more specific)
                            score += 1.0 * (1.0 + len(keyword) * 0.1)

            if total_matches > 0:
                # Normalize score
                emotion_scores[emotion] = min(1.0, score / (total_matches * 2.0))

        # Find emotion with highest score
        if emotion_scores:
            best_emotion = max(emotion_scores.items(), key=lambda x: x[1])
            emotion, confidence = best_emotion

            # Apply confidence threshold
            if confidence >= 0.3:  # Minimum threshold
                return emotion, min(1.0, confidence)

        # Fallback: check for neutral indicators or default to neutral
        neutral_indicators = ["okay", "fine", "alright", "حسنا", "تمام"]
        if any(indicator in text_lower for indicator in neutral_indicators):
            return Emotion.NEUTRAL, 0.5

        # Default to neutral if no strong emotion detected
        return Emotion.NEUTRAL, 0.3

    def validate_response(self, result: LLMResult) -> bool:
        """
        Validate response meets quality criteria.

        Args:
            result: LLMResult to validate

        Returns:
            True if valid

        Raises:
            ValueError: If response is invalid
        """
        # Check required fields
        if not isinstance(result.text, str):
            raise ValueError("Response text must be a string")

        if not isinstance(result.provider, str):
            raise ValueError("Response provider must be a string")

        if not isinstance(result.model, str):
            raise ValueError("Response model must be a string")

        # Check token counts are non-negative
        if result.input_tokens < 0 or result.output_tokens < 0:
            logger.warning(
                f"Negative token counts: input={result.input_tokens}, output={result.output_tokens}",
                extra={"correlation_id": result.correlation_id},
            )

        # Check processing time is reasonable
        if result.processing_time < 0:
            logger.warning(
                f"Negative processing time: {result.processing_time}", extra={"correlation_id": result.correlation_id}
            )

        # Check finish reason is valid
        valid_finish_reasons = [fr.value for fr in FinishReason]
        if result.finish_reason not in valid_finish_reasons:
            logger.warning(
                f"Unknown finish reason: {result.finish_reason}", extra={"correlation_id": result.correlation_id}
            )

        return True

    def normalize_response(self, result: LLMResult) -> LLMResult:
        """
        Normalize response format across providers.

        Ensures consistent format regardless of provider.

        Args:
            result: LLMResult to normalize

        Returns:
            Normalized LLMResult
        """
        # Ensure text is not None
        if result.text is None:
            result.text = ""

        # Ensure metadata is a dict
        if result.metadata is None:
            result.metadata = {}

        # Normalize finish reason
        if result.finish_reason not in [fr.value for fr in FinishReason]:
            result.finish_reason = FinishReason.STOP.value

        # Ensure correlation_id is set (but don't overwrite existing one to preserve tracing)
        # Only generate if truly missing (None or empty string)
        if not result.correlation_id:
            import uuid

            logger.warning(
                "Missing correlation_id in LLMResult, generating new one (may break tracing)",
                extra={"provider": result.provider},
            )
            result.correlation_id = f"llm-{uuid.uuid4().hex[:12]}"

        return result

    def extract_tool_calls(self, result: LLMResult) -> Optional[List[Dict[str, Any]]]:
        """
        Extract tool calls from response.

        Args:
            result: LLMResult

        Returns:
            List of tool calls or None
        """
        return result.tool_calls

    def calculate_cost(
        self,
        result: LLMResult,
        cost_per_input_token: float = 0.0,
        cost_per_output_token: float = 0.0,
    ) -> float:
        """
        Calculate cost for the response.

        Args:
            result: LLMResult
            cost_per_input_token: Cost per input token (provider-specific)
            cost_per_output_token: Cost per output token (provider-specific)

        Returns:
            Total cost in USD
        """
        if cost_per_input_token == 0.0 and cost_per_output_token == 0.0:
            # Try to get cost from metadata
            if result.metadata and "cost" in result.metadata:
                return float(result.metadata["cost"])
            return 0.0

        total_cost = result.input_tokens * cost_per_input_token + result.output_tokens * cost_per_output_token

        # Store in metadata
        if result.metadata:
            result.metadata["cost"] = total_cost
        else:
            result.metadata = {"cost": total_cost}

        return total_cost
