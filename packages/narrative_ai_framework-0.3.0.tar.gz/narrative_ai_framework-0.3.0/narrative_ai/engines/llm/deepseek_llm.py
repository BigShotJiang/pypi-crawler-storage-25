"""
DeepSeek LLM Provider.

Implements DeepSeek API integration using OpenAI-compatible SDK.
Supports streaming, function calling, structured outputs, and reasoning mode.

Documentation: https://api-docs.deepseek.com/
"""

import asyncio
import time
import logging
from typing import Optional, Dict, Any, List, AsyncIterator, Union

try:
    from openai import OpenAI, AsyncOpenAI
except ImportError:
    OpenAI = None
    AsyncOpenAI = None
    logging.warning("openai not installed. DeepSeek provider will not be available.")

from .base_llm import (
    BaseLLMProvider,
    LLMResult,
    LLMError,
    GenerationError,
    ProviderUnavailableError,
    RateLimitError,
    AuthenticationError,
    InvalidInputError,
    ContentFilterError,
    LLMTimeoutError,
    LLMNetworkError,
    FinishReason,
    is_retriable_error,
    estimate_input_tokens,
)
from .config import DeepSeekConfig

logger = logging.getLogger(__name__)


class DeepSeekLLMProvider(BaseLLMProvider):
    """
    DeepSeek LLM provider.

    Uses OpenAI SDK with DeepSeek base URL (OpenAI-compatible API).
    Supports deepseek-chat (non-thinking) and deepseek-reasoner (thinking) models.
    """

    MAX_INPUT_TOKENS = 64000  # DeepSeek context window
    MAX_OUTPUT_TOKENS = 8192
    SUPPORTED_FEATURES = ["streaming", "function_calling", "structured_outputs", "reasoning"]

    def __init__(self, config: DeepSeekConfig):
        """
        Initialize DeepSeek provider.

        Args:
            config: DeepSeek configuration
        """
        super().__init__()
        self.config = config
        self._client: Optional[Any] = None
        self._async_client: Optional[Any] = None

    def is_available(self) -> bool:
        """Check if provider is available and configured."""
        if OpenAI is None or AsyncOpenAI is None:
            return False

        if not self.config.api_key:
            return False

        return True

    def get_provider_name(self) -> str:
        """Get provider name."""
        return "deepseek"

    def _estimate_output_tokens(self, text: str) -> int:
        """
        Estimate output tokens using tiktoken (DeepSeek uses OpenAI-compatible API).

        Falls back to word count estimation if tiktoken is not available.

        Args:
            text: Text to estimate tokens for

        Returns:
            Estimated token count
        """
        try:
            import tiktoken

            # DeepSeek uses cl100k_base encoding (same as GPT-4)
            encoding = tiktoken.get_encoding("cl100k_base")
            return len(encoding.encode(text))
        except ImportError:
            # Fallback to word count estimation
            return int(len(text.split()) * 1.3)
        except Exception as e:
            logger.warning(f"Token estimation failed, using fallback: {e}")
            return int(len(text.split()) * 1.3)

    async def _load_model_impl(self) -> None:
        """Initialize DeepSeek clients."""
        if not self.is_available():
            raise ProviderUnavailableError(
                "DeepSeek provider not available (missing API key or SDK)",
                provider="deepseek",
            )

        try:
            self._client = OpenAI(
                api_key=self.config.api_key,
                base_url=self.config.base_url,
            )
            self._async_client = AsyncOpenAI(
                api_key=self.config.api_key,
                base_url=self.config.base_url,
            )
            logger.info("DeepSeek client initialized")
        except Exception as e:
            raise ProviderUnavailableError(
                f"Failed to initialize DeepSeek client: {str(e)}",
                provider="deepseek",
            ) from e

    async def _shutdown_impl(self) -> None:
        """Cleanup DeepSeek clients."""
        try:
            # Close async client's HTTP session if it exists
            if hasattr(self, "_async_client") and self._async_client is not None:
                if hasattr(self._async_client, "_client") and hasattr(self._async_client._client, "close"):
                    await self._async_client._client.close()
                elif hasattr(self._async_client, "close"):
                    await self._async_client.close()
        except Exception as e:
            logger.warning(f"Error closing DeepSeek async client: {e}")

        try:
            # Close sync client's HTTP session if it exists
            if hasattr(self, "_client") and self._client is not None:
                if hasattr(self._client, "_client") and hasattr(self._client._client, "close"):
                    self._client._client.close()
                elif hasattr(self._client, "close"):
                    self._client.close()
        except Exception as e:
            logger.warning(f"Error closing DeepSeek sync client: {e}")

        self._client = None
        self._async_client = None

    async def generate(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        stream: bool = False,
        correlation_id: Optional[str] = None,
    ) -> Union[LLMResult, AsyncIterator[LLMResult]]:
        """
        Generate text completion using DeepSeek.

        Uses OpenAI-compatible API, so implementation is similar to OpenAI.
        """
        if not self._is_loaded:
            await self.load_model()

        if stream:
            return self.generate_streaming(
                prompt=prompt,
                system_prompt=system_prompt,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                tools=tools,
                tool_choice=tool_choice,
                response_format=response_format,
                correlation_id=correlation_id,
            )

        start_time = time.time()

        # Build messages (same as OpenAI)
        openai_messages = self._build_messages(prompt, system_prompt, messages)

        # Build request parameters
        request_params = {
            "model": self.config.default_model,
            "messages": openai_messages,
            "temperature": temperature,
        }

        if max_tokens:
            request_params["max_tokens"] = max_tokens
        elif self.config.max_tokens:
            request_params["max_tokens"] = self.config.max_tokens

        # Add tools
        if tools:
            request_params["tools"] = tools
            if tool_choice:
                request_params["tool_choice"] = tool_choice

        # Add structured output
        if response_format:
            request_params["response_format"] = response_format

        # Retry logic with exponential backoff
        last_error = None
        for attempt in range(self.config.retry_attempts):
            try:
                # Wrap API call with timeout
                completion = await asyncio.wait_for(
                    self._async_client.chat.completions.create(**request_params),
                    timeout=self.config.timeout,
                )

                processing_time = time.time() - start_time

                # Extract response (same as OpenAI)
                choice = completion.choices[0]
                text = choice.message.content or ""
                finish_reason = self._map_finish_reason(choice.finish_reason)

                usage = completion.usage
                input_tokens = usage.prompt_tokens if usage else 0
                output_tokens = usage.completion_tokens if usage else 0

                # Extract tool calls
                tool_calls = None
                if choice.message.tool_calls:
                    tool_calls = [
                        {
                            "id": tc.id,
                            "type": tc.type,
                            "function": {
                                "name": tc.function.name,
                                "arguments": tc.function.arguments,
                            },
                        }
                        for tc in choice.message.tool_calls
                    ]

                # Calculate cost (DeepSeek pricing varies by model)
                # DeepSeek V3.2 (deepseek-chat): $0.28/$0.42 per 1M tokens (cache miss)
                # DeepSeek V3.2 Reasoner: $0.55/$2.19 per 1M tokens (cache miss)
                model_name = self.config.default_model.lower()
                if "reasoner" in model_name or "r1" in model_name:
                    # DeepSeek-Reasoner / R1 pricing
                    cost_per_input = 0.55 / 1_000_000
                    cost_per_output = 2.19 / 1_000_000
                elif "v3" in model_name or "chat" in model_name:
                    # DeepSeek-V3 / Chat pricing (corrected from $0.14/$0.28)
                    cost_per_input = 0.28 / 1_000_000
                    cost_per_output = 0.42 / 1_000_000
                else:
                    # Conservative default (use highest pricing)
                    cost_per_input = 0.55 / 1_000_000
                    cost_per_output = 2.19 / 1_000_000

                cost = (input_tokens * cost_per_input) + (output_tokens * cost_per_output)

                return LLMResult(
                    text=text,
                    finish_reason=finish_reason,
                    provider="deepseek",
                    model=self.config.default_model,
                    processing_time=processing_time,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=input_tokens + output_tokens,
                    tool_calls=tool_calls,
                    is_partial=False,
                    is_final=True,
                    metadata={
                        "correlation_id": correlation_id,
                        "cost": cost,
                    },
                    correlation_id=correlation_id,
                )

            except asyncio.TimeoutError as e:
                processing_time = time.time() - start_time
                last_error = LLMTimeoutError(
                    f"Request timed out after {self.config.timeout}s",
                    provider="deepseek",
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e
            except (RateLimitError, AuthenticationError, InvalidInputError, ContentFilterError):
                # Don't retry non-retriable errors
                raise
            except Exception as e:
                processing_time = time.time() - start_time
                last_error = self._handle_error(e, correlation_id)

                # Check if error is retriable
                if not is_retriable_error(last_error):
                    raise last_error

            # Exponential backoff with jitter
            if attempt < self.config.retry_attempts - 1:
                wait_time = self._calculate_backoff_with_jitter(attempt, self.config.retry_backoff)
                logger.warning(
                    "Retrying DeepSeek LLM request",
                    extra={
                        "correlation_id": correlation_id,
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                        "error": str(last_error),
                    },
                )
                await asyncio.sleep(wait_time)

        # All retries exhausted
        if last_error:
            raise last_error

        raise GenerationError(
            "Generation failed after all retries",
            provider="deepseek",
            correlation_id=correlation_id,
        )

    async def generate_streaming(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[LLMResult]:
        """Stream text completion (same as OpenAI)."""
        if not self._is_loaded:
            await self.load_model()

        start_time = time.time()
        accumulated_text = ""

        # Calculate input tokens before streaming
        input_tokens = estimate_input_tokens(
            prompt=prompt,
            system_prompt=system_prompt,
            messages=messages,
        )

        openai_messages = self._build_messages(prompt, system_prompt, messages)

        request_params = {
            "model": self.config.default_model,
            "messages": openai_messages,
            "temperature": temperature,
            "stream": True,
        }

        if max_tokens:
            request_params["max_tokens"] = max_tokens
        elif self.config.max_tokens:
            request_params["max_tokens"] = self.config.max_tokens

        if tools:
            request_params["tools"] = tools
            if tool_choice:
                request_params["tool_choice"] = tool_choice

        if response_format:
            request_params["response_format"] = response_format

        # Retry logic with exponential backoff
        last_error = None

        for attempt in range(self.config.retry_attempts):
            try:
                # Wrap stream creation with timeout
                stream = await asyncio.wait_for(
                    self._async_client.chat.completions.create(**request_params),
                    timeout=self.config.timeout,
                )

                # Stream chunks with timeout monitoring
                chunk_timeout = self.config.timeout

                try:
                    async for chunk in stream:
                        # Check if we've exceeded overall timeout
                        elapsed = time.time() - start_time
                        if elapsed > chunk_timeout:
                            logger.warning(
                                "Streaming timeout exceeded",
                                extra={"correlation_id": correlation_id, "elapsed": elapsed},
                            )
                            break

                        if chunk.choices and chunk.choices[0].delta.content:
                            chunk_text = chunk.choices[0].delta.content
                            accumulated_text += chunk_text

                            processing_time = time.time() - start_time

                            # Estimate output tokens incrementally
                            output_tokens_est = len(accumulated_text.split()) * 1.3

                            yield LLMResult(
                                # IMPORTANT: emit delta text for streaming consumers (e.g., LiveKit)
                                text=chunk_text,
                                finish_reason=FinishReason.STOP.value,
                                provider="deepseek",
                                model=self.config.default_model,
                                processing_time=processing_time,
                                input_tokens=input_tokens,
                                output_tokens=int(output_tokens_est),
                                total_tokens=input_tokens + int(output_tokens_est),
                                is_partial=True,
                                is_final=False,
                                metadata={"correlation_id": correlation_id},
                                correlation_id=correlation_id,
                            )
                except Exception as stream_error:
                    # Handle mid-stream errors
                    logger.error(
                        "Error during streaming",
                        extra={"correlation_id": correlation_id, "error": str(stream_error)},
                        exc_info=True,
                    )
                    # Yield partial result with error flag and return (don't continue with corrupted data)
                    processing_time = time.time() - start_time
                    output_tokens = self._estimate_output_tokens(accumulated_text)

                    # Calculate cost for partial result
                    model_name = self.config.default_model.lower()
                    if "reasoner" in model_name or "r1" in model_name:
                        cost_per_input = 0.55 / 1_000_000
                        cost_per_output = 2.19 / 1_000_000
                    elif "v3" in model_name or "chat" in model_name:
                        cost_per_input = 0.28 / 1_000_000
                        cost_per_output = 0.42 / 1_000_000
                    else:
                        cost_per_input = 0.55 / 1_000_000
                        cost_per_output = 2.19 / 1_000_000
                    cost = (input_tokens * cost_per_input) + (int(output_tokens) * cost_per_output)

                    yield LLMResult(
                        text=accumulated_text,
                        finish_reason=FinishReason.ERROR.value,
                        provider="deepseek",
                        model=self.config.default_model,
                        processing_time=processing_time,
                        input_tokens=input_tokens,
                        output_tokens=int(output_tokens),
                        total_tokens=input_tokens + int(output_tokens),
                        is_partial=False,
                        is_final=True,
                        metadata={
                            "correlation_id": correlation_id,
                            "cost": cost,
                            "error": str(stream_error),
                        },
                        correlation_id=correlation_id,
                    )
                    return  # Don't continue with corrupted data

                processing_time = time.time() - start_time
                output_tokens = self._estimate_output_tokens(accumulated_text)

                # Calculate cost (DeepSeek pricing varies by model)
                # DeepSeek V3.2 (deepseek-chat): $0.28/$0.42 per 1M tokens (cache miss)
                # DeepSeek V3.2 Reasoner: $0.55/$2.19 per 1M tokens (cache miss)
                model_name = self.config.default_model.lower()
                if "reasoner" in model_name or "r1" in model_name:
                    # DeepSeek-Reasoner / R1 pricing
                    cost_per_input = 0.55 / 1_000_000
                    cost_per_output = 2.19 / 1_000_000
                elif "v3" in model_name or "chat" in model_name:
                    # DeepSeek-V3 / Chat pricing (corrected from $0.14/$0.28)
                    cost_per_input = 0.28 / 1_000_000
                    cost_per_output = 0.42 / 1_000_000
                else:
                    # Conservative default (use highest pricing)
                    cost_per_input = 0.55 / 1_000_000
                    cost_per_output = 2.19 / 1_000_000

                cost = (input_tokens * cost_per_input) + (int(output_tokens) * cost_per_output)

                yield LLMResult(
                    text=accumulated_text,
                    finish_reason=FinishReason.STOP.value,
                    provider="deepseek",
                    model=self.config.default_model,
                    processing_time=processing_time,
                    input_tokens=input_tokens,
                    output_tokens=int(output_tokens),
                    total_tokens=input_tokens + int(output_tokens),
                    is_partial=False,
                    is_final=True,
                    metadata={
                        "correlation_id": correlation_id,
                        "cost": cost,
                    },
                    correlation_id=correlation_id,
                )

                # Success - break retry loop
                return

            except asyncio.TimeoutError as e:
                processing_time = time.time() - start_time
                last_error = LLMTimeoutError(
                    f"Request timed out after {self.config.timeout}s",
                    provider="deepseek",
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e
            except (RateLimitError, AuthenticationError, InvalidInputError, ContentFilterError):
                # Don't retry non-retriable errors
                raise
            except Exception as e:
                processing_time = time.time() - start_time
                last_error = self._handle_error(e, correlation_id)

                # Check if error is retriable
                if not is_retriable_error(last_error):
                    raise last_error

            # Exponential backoff with jitter
            if attempt < self.config.retry_attempts - 1:
                wait_time = self._calculate_backoff_with_jitter(attempt, self.config.retry_backoff)
                logger.warning(
                    "Retrying DeepSeek streaming request",
                    extra={
                        "correlation_id": correlation_id,
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                        "error": str(last_error),
                    },
                )
                await asyncio.sleep(wait_time)

        # All retries exhausted
        if last_error:
            raise last_error

        raise GenerationError(
            "Streaming failed after all retries",
            provider="deepseek",
            correlation_id=correlation_id,
        )

    def _build_messages(
        self,
        prompt: Optional[str],
        system_prompt: Optional[str],
        messages: Optional[List[Dict[str, str]]],
    ) -> List[Dict[str, str]]:
        """Build messages (same as OpenAI)."""
        openai_messages = []

        if system_prompt:
            openai_messages.append({"role": "system", "content": system_prompt})

        if messages:
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                if role in ["assistant", "user"]:
                    openai_messages.append({"role": role, "content": content})
        elif prompt:
            openai_messages.append({"role": "user", "content": prompt})

        return openai_messages

    def _map_finish_reason(self, reason: Optional[str]) -> str:
        """Map finish reason (same as OpenAI)."""
        if not reason:
            return FinishReason.STOP.value

        mapping = {
            "stop": FinishReason.STOP.value,
            "length": FinishReason.LENGTH.value,
            "tool_calls": FinishReason.TOOL_CALLS.value,
            "content_filter": FinishReason.CONTENT_FILTER.value,
        }
        return mapping.get(reason, FinishReason.STOP.value)

    def _handle_error(self, error: Exception, correlation_id: Optional[str]) -> LLMError:
        """Handle and classify errors."""
        # Network/connection errors (check before string-based classification)
        if isinstance(error, (ConnectionError, OSError)):
            return LLMNetworkError(
                f"DeepSeek network error: {error}",
                provider="deepseek",
                correlation_id=correlation_id,
            )
        try:
            import httpx

            if isinstance(error, httpx.TimeoutException):
                return LLMTimeoutError(
                    f"DeepSeek request timed out: {error}",
                    provider="deepseek",
                    correlation_id=correlation_id,
                )
            if isinstance(error, httpx.NetworkError):
                return LLMNetworkError(
                    f"DeepSeek network error: {error}",
                    provider="deepseek",
                    correlation_id=correlation_id,
                )
        except ImportError:
            pass
        try:
            from openai import APITimeoutError, APIConnectionError

            # APITimeoutError extends APIConnectionError - check timeout first
            if isinstance(error, APITimeoutError):
                return LLMTimeoutError(
                    f"DeepSeek request timed out: {error}",
                    provider="deepseek",
                    correlation_id=correlation_id,
                )
            if isinstance(error, APIConnectionError):
                return LLMNetworkError(
                    f"DeepSeek connection error: {error}",
                    provider="deepseek",
                    correlation_id=correlation_id,
                )
        except ImportError:
            pass

        error_str = str(error).lower()

        if "rate limit" in error_str or "429" in error_str:
            return RateLimitError(
                f"DeepSeek rate limit exceeded: {str(error)}",
                provider="deepseek",
                correlation_id=correlation_id,
            )

        if "api key" in error_str or "authentication" in error_str or "401" in error_str or "403" in error_str:
            return AuthenticationError(
                f"DeepSeek authentication failed: {str(error)}",
                provider="deepseek",
                correlation_id=correlation_id,
            )

        if "not available" in error_str or "503" in error_str:
            return ProviderUnavailableError(
                f"DeepSeek provider unavailable: {str(error)}",
                provider="deepseek",
                correlation_id=correlation_id,
            )

        return GenerationError(
            f"DeepSeek generation failed: {str(error)}",
            provider="deepseek",
            correlation_id=correlation_id,
        )

    def _calculate_backoff_with_jitter(self, attempt: int, base_delay: float = 1.0) -> float:
        """
        Calculate exponential backoff with jitter.

        Uses "full jitter" strategy to prevent thundering herd.

        Args:
            attempt: Current attempt number (0-indexed)
            base_delay: Base delay in seconds

        Returns:
            Delay in seconds with jitter applied
        """
        import random

        cap = 30.0  # Maximum delay cap
        exponential_delay = min(cap, base_delay * (2**attempt))
        return random.uniform(0, exponential_delay)
