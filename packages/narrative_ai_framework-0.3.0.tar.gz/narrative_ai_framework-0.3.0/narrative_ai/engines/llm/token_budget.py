"""Token budget management utilities for chat orchestration.

Provides hard caps for prompt components so context does not explode as
conversation and diary data grow.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List


@dataclass
class TokenBudgetConfig:
    """Hard token caps for each prompt component."""

    total_budget_tokens: int = 32000
    system_prompt_tokens: int = 500
    rag_context_tokens: int = 4000
    history_tokens: int = 6000
    history_max_messages: int = 40
    response_reserved_tokens: int = 2000
    safety_margin_tokens: int = 500

    def validate(self) -> None:
        allocated = (
            self.system_prompt_tokens
            + self.rag_context_tokens
            + self.history_tokens
            + self.response_reserved_tokens
            + self.safety_margin_tokens
        )
        if allocated > self.total_budget_tokens:
            raise ValueError(f"Invalid token budget: allocated={allocated} exceeds total={self.total_budget_tokens}")


class TokenBudgetManager:
    """Applies token caps to system prompt blocks and message history."""

    def __init__(
        self,
        config: TokenBudgetConfig | None = None,
        token_estimator: Callable[[str], int] | None = None,
    ) -> None:
        self.config = config or TokenBudgetConfig()
        self.config.validate()
        self._estimate_tokens = token_estimator or self._default_estimator

    @staticmethod
    def _default_estimator(text: str) -> int:
        if not text:
            return 0
        return max(1, int(len(text) / 4))

    def truncate_text(self, text: str, max_tokens: int) -> str:
        """Trim text to token budget using a conservative char-based estimate."""
        if not text:
            return ""
        if max_tokens <= 0:
            return ""
        if self._estimate_tokens(text) <= max_tokens:
            return text

        max_chars = max_tokens * 4
        if max_chars < 8:
            return text[:max_chars]

        truncated = text[: max_chars - 3].rstrip()
        return truncated + "..."

    def cap_messages(
        self,
        messages: List[Dict[str, str]],
        max_tokens: int | None = None,
        max_messages: int | None = None,
    ) -> List[Dict[str, str]]:
        """
        Keep all system messages and as many recent user/assistant messages as
        fit in the history budget, with an additional hard cap on message count.
        """
        if not messages:
            return []

        budget = max_tokens or self.config.history_tokens
        if budget <= 0:
            return []
        message_cap = self.config.history_max_messages if max_messages is None else max_messages

        system_messages = [msg for msg in messages if msg.get("role") == "system"]
        user_assistant_messages = [msg for msg in messages if msg.get("role") != "system"]
        if message_cap is not None:
            if message_cap <= 0:
                user_assistant_messages = []
            elif len(user_assistant_messages) > message_cap:
                user_assistant_messages = user_assistant_messages[-message_cap:]

        result: List[Dict[str, str]] = []
        used = 0

        for msg in system_messages:
            msg_tokens = self._estimate_tokens(msg.get("content", ""))
            if used + msg_tokens > budget:
                break
            result.append(msg)
            used += msg_tokens

        kept_user_assistant: List[Dict[str, str]] = []
        for msg in reversed(user_assistant_messages):
            msg_tokens = self._estimate_tokens(msg.get("content", ""))
            if used + msg_tokens > budget:
                break
            kept_user_assistant.insert(0, msg)
            used += msg_tokens

        result.extend(kept_user_assistant)
        return result
