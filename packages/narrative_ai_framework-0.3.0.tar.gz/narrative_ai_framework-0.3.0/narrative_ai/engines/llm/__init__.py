"""
LLM Engine - Large Language Model Module.

This module provides comprehensive LLM functionality with:
- Multiple provider support (Gemini, Ollama, OpenAI, Claude, xAI, DeepSeek)
- Automatic provider fallback on failure
- Dedicated timeout/network error types: LLMTimeoutError, LLMNetworkError (retriable)
- Emotion extraction from responses
- Streaming support for real-time applications
- Function calling and structured outputs
- Full integration with the framework's security layer
- Centralized configuration via providers.yml

Quick Start (Recommended - Using providers.yml):
    ```python
    from narrative_ai.engines.llm import LLMEngine

    # Create engine (loads from config/providers.yml)
    async with LLMEngine() as engine:
        result = await engine.generate(
            prompt="Hello, how are you?",
            correlation_id="req-123",
        )
        print(f"Response: {result.text}")
        print(f"Emotion: {result.emotion}")
    ```

Streaming Example:
    ```python
    async with LLMEngine() as engine:
        async for chunk in engine.generate_streaming(
            prompt="Tell me a story",
            correlation_id="req-123",
        ):
            if chunk.is_partial:
                print(f"Partial: {chunk.text}")
            else:
                print(f"Final: {chunk.text}")
    ```

Multi-turn Conversation:
    ```python
    from narrative_ai.engines.llm import LLMEngine, ConversationManager

    async with LLMEngine() as engine:
        conv_manager = ConversationManager()

        # Create session
        session_id = conv_manager.create_session(user_id="user-123")

        # Add user message
        conv_manager.add_message(session_id, "user", "Hello!")

        # Get conversation history
        messages = conv_manager.get_messages(session_id)

        # Generate response
        result = await engine.generate(messages=messages)

        # Add assistant response
        conv_manager.add_message(session_id, "assistant", result.text)
    ```

Direct Provider Usage:
    ```python
    from narrative_ai.engines.llm import GeminiLLMProvider, GeminiConfig

    provider = GeminiLLMProvider(GeminiConfig(api_key="..."))
    result = await provider.generate(prompt="Hello")
    ```
"""

# Base components
from .base_llm import (
    BaseLLMProvider,
    LLMResult,
    Emotion,
    FinishReason,
    ErrorSeverity,
    LLMError,
    GenerationError,
    ProviderUnavailableError,
    RateLimitError,
    AuthenticationError,
    InvalidInputError,
    ContentFilterError,
    LLMTimeoutError,
    LLMNetworkError,
    MetricsExporter,
    NoOpMetricsExporter,
    set_metrics_exporter,
    get_metrics_exporter,
    is_retriable_error,
)

# Configuration
from .config import (
    LLMConfig,
    GeminiConfig,
    OllamaConfig,
    OpenAIConfig,
    AnthropicConfig,
    XAIConfig,
    DeepSeekConfig,
    IntegrationConfig,
)

# Input processing
from .input_processor import (
    InputProcessor,
    InputProcessorConfig,
)

# Strategy
from .llm_strategy import (
    LLMStrategy,
    CircuitBreakerConfig,
)

# Response processing
from .response_processor import (
    ResponseProcessor,
)

# Conversation management
from .conversation_manager import (
    ConversationManager,
    ConversationSession,
)

# Token budgeting
from .token_budget import (
    TokenBudgetConfig,
    TokenBudgetManager,
)

# Conversation storage
from .conversation_storage import (
    ConversationStorageInterface,
    InMemoryConversationStorage,
    RedisConversationStorage,
    PostgresConversationStorage,
    get_conversation_storage,
)

# Error mapping
from .error_mapper import (
    parse_provider_error,
    parse_gemini_error,
    parse_openai_error,
    parse_claude_error,
    ProviderErrorCode,
)

# Providers
from .gemini_llm import GeminiLLMProvider
from .openai_llm import OpenAILLMProvider
from .claude_llm import ClaudeLLMProvider
from .xai_llm import XAILLMProvider
from .deepseek_llm import DeepSeekLLMProvider
from .ollama_llm import OllamaLLMProvider

# Main engine
from .llm_engine import (
    LLMEngine,
)

# High-level Client API
from .api import (
    LLMClient,
    generate,
    generate_stream,
    chat,
)


__all__ = [
    # Main entry points
    "LLMEngine",
    # Base components
    "BaseLLMProvider",
    "LLMResult",
    "Emotion",
    "FinishReason",
    "ErrorSeverity",
    # Errors
    "LLMError",
    "GenerationError",
    "ProviderUnavailableError",
    "RateLimitError",
    "AuthenticationError",
    "InvalidInputError",
    "ContentFilterError",
    "LLMTimeoutError",
    "LLMNetworkError",
    # Error utilities
    "is_retriable_error",
    # Metrics
    "MetricsExporter",
    "NoOpMetricsExporter",
    "set_metrics_exporter",
    "get_metrics_exporter",
    # Configuration
    "LLMConfig",
    "GeminiConfig",
    "OllamaConfig",
    "OpenAIConfig",
    "AnthropicConfig",
    "XAIConfig",
    "DeepSeekConfig",
    "IntegrationConfig",
    # Input processing
    "InputProcessor",
    "InputProcessorConfig",
    # Strategy
    "LLMStrategy",
    "CircuitBreakerConfig",
    # Response processing
    "ResponseProcessor",
    # Conversation management
    "ConversationManager",
    "ConversationSession",
    # Token budgeting
    "TokenBudgetConfig",
    "TokenBudgetManager",
    # Conversation storage
    "ConversationStorageInterface",
    "InMemoryConversationStorage",
    "RedisConversationStorage",
    "PostgresConversationStorage",
    "get_conversation_storage",
    # Error mapping
    "parse_provider_error",
    "parse_gemini_error",
    "parse_openai_error",
    "parse_claude_error",
    "ProviderErrorCode",
    # Providers
    "GeminiLLMProvider",
    "OpenAILLMProvider",
    "ClaudeLLMProvider",
    "XAILLMProvider",
    "DeepSeekLLMProvider",
    "OllamaLLMProvider",
    # High-level API
    "LLMClient",
    "generate",
    "generate_stream",
    "chat",
]

# Module version
__version__ = "0.1.0"
