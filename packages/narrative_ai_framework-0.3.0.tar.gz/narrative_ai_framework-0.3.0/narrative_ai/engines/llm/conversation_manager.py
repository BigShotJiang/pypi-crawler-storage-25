"""
Conversation Manager - Multi-turn Conversation Management.

Manages conversation context and history for multi-turn interactions.
Handles context window management, message formatting, and session tracking.

Production-Ready Features:
- Context window management (truncation)
- Session management per user/tenant
- Message format conversion
- Token counting and budgeting
- Redis/PostgreSQL persistence (auto-detected from env vars)
"""

import asyncio
import logging
from typing import Optional, Dict, Any, List, TYPE_CHECKING
from dataclasses import dataclass, field
import time
import uuid

if TYPE_CHECKING:
    # Imported only for type checking to avoid circular import at runtime.
    from .conversation_storage import ConversationStorageInterface

logger = logging.getLogger(__name__)


@dataclass
class ConversationSession:
    """
    A conversation session with message history.

    Attributes:
        session_id: Unique session identifier
        user_id: User ID
        tenant_id: Tenant ID
        messages: List of conversation messages
        created_at: Session creation timestamp
        updated_at: Last update timestamp
        metadata: Additional session metadata
    """

    session_id: str
    user_id: Optional[str] = None
    tenant_id: Optional[str] = None
    messages: List[Dict[str, Any]] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def add_message(
        self,
        role: str,
        content: str,
        *,
        emotion: Optional[str] = None,
        audio_url: Optional[str] = None,
        sources_json: Optional[str] = None,
    ) -> None:
        """Add a message to the conversation."""
        row: Dict[str, Any] = {
            "role": role,
            "content": content,
        }
        if emotion is not None:
            row["emotion"] = emotion
        if audio_url is not None:
            row["audio_url"] = audio_url
        if sources_json is not None:
            row["sources_json"] = sources_json
        self.messages.append(row)
        self.updated_at = time.time()

    def get_message_count(self) -> int:
        """Get number of messages in conversation."""
        return len(self.messages)

    def clear(self) -> None:
        """Clear all messages."""
        self.messages = []
        self.updated_at = time.time()


class ConversationManager:
    """
    Manages multi-turn conversations with context window management.

    Features:
    - Session management per user/tenant
    - Context window truncation (FIFO)
    - Message format conversion
    - Token counting and budgeting

    Example:
        manager = ConversationManager(max_context_tokens=32000)

        # Start conversation
        session_id = manager.create_session(user_id="user-123", tenant_id="tenant-456")

        # Add messages
        manager.add_message(session_id, "user", "Hello!")
        manager.add_message(session_id, "assistant", "Hi there!")

        # Get messages for LLM
        messages = manager.get_messages(session_id, max_tokens=4000)
    """

    def __init__(
        self,
        max_context_tokens: int = 32000,
        max_sessions: int = 10000,
        session_ttl_seconds: int = 3600,  # 1 hour
        provider_hint: str = "openai",
        storage: Optional["ConversationStorageInterface"] = None,
    ):
        """
        Initialize conversation manager.

        Storage backend is auto-detected from environment variables if not provided:
        - REDIS_URL: Use Redis backend
        - LLM_CONVERSATION_DATABASE_URL or DATABASE_URL (postgresql://): Use PostgreSQL backend
        - Otherwise: Use in-memory backend (sessions lost on restart)

        Args:
            max_context_tokens: Maximum tokens per conversation context
            max_sessions: Maximum number of concurrent sessions (in-memory only)
            session_ttl_seconds: Session time-to-live in seconds (for cleanup)
            provider_hint: Provider hint for token estimation ("openai", "gemini", "claude", etc.)
            storage: Optional storage backend (auto-detected if None)
        """
        self.max_context_tokens = max_context_tokens
        self.max_sessions = max_sessions
        self.session_ttl_seconds = session_ttl_seconds
        # Hint to choose better token estimation heuristics per provider family
        # ("openai", "gemini", "claude", etc.). Does not affect behavior if a
        # tokenizer is not available.
        self.provider_hint = provider_hint

        # Storage backend (Redis/PostgreSQL/in-memory). Import factory lazily to
        # avoid circular import during module loading.
        if storage is not None:
            self._storage = storage
        else:
            from .conversation_storage import get_conversation_storage

            self._storage = get_conversation_storage()

        # Optional tokenizer (e.g., tiktoken) for more accurate token counts.
        self._tokenizer = self._load_tokenizer(provider_hint)
        self._summary_marker = "[CONVERSATION_SUMMARY]"

    def _load_tokenizer(self, provider: str):
        """
        Load provider-specific tokenizer when available.

        Currently supports OpenAI via tiktoken. For other providers we rely on
        heuristic estimation. This is a best-effort optimization only; lack of
        tokenizer never breaks functionality.
        """
        try:
            if provider.lower() == "openai":
                import tiktoken  # type: ignore[import]

                # Use a generic GPT-4 encoding; good approximation for GPT‑4o/mini.
                return tiktoken.encoding_for_model("gpt-4")
        except ImportError:
            logger.debug("tiktoken not installed; using character-based token estimation")
        except Exception as e:
            logger.debug("Tokenizer load failed (%s); falling back to character-based estimation", e)
        return None

    def estimate_tokens(self, text: str) -> int:
        """
        Estimate token count for text using tokenizer when available, otherwise
        provider-specific character-based heuristics.
        """
        if not text:
            return 0

        if self._tokenizer is not None:
            try:
                return len(self._tokenizer.encode(text))
            except Exception as e:
                logger.debug("Tokenizer encode failed (%s); falling back to character-based estimation", e)

        # Fallback: character-based estimate tuned per provider family.
        hint = (self.provider_hint or "default").lower()
        # These divisors are approximate and intentionally conservative.
        if hint == "openai":
            divisor = 4.5
        elif hint == "gemini":
            divisor = 3.5
        elif hint == "claude":
            divisor = 4.5
        else:
            divisor = 4.0

        # Ensure at least 1 token for any non-empty text.
        return max(1, int(len(text) / divisor))

    def create_session(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> str:
        """
        Create a new conversation session.

        Args:
            user_id: User ID
            tenant_id: Tenant ID
            session_id: Optional custom session ID (auto-generated if not provided)

        Returns:
            Session ID
        """
        # Generate session ID if not provided
        if not session_id:
            session_id = f"conv-{uuid.uuid4().hex[:12]}"

        # Check if session already exists
        existing = self._storage.get(session_id)
        if existing:
            logger.debug("Session already exists, returning existing", extra={"session_id": session_id})
            return session_id

        # For in-memory storage, check session limit
        if hasattr(self._storage, "_sessions"):
            sessions_dict = getattr(self._storage, "_sessions", {})
            if len(sessions_dict) >= self.max_sessions:
                # Remove oldest session (in-memory only)
                oldest_session_id = min(sessions_dict.keys(), key=lambda sid: sessions_dict[sid].created_at)
                self._storage.delete(oldest_session_id)
                logger.warning(f"Removed oldest session {oldest_session_id} due to limit")

        # Create session
        session = ConversationSession(
            session_id=session_id,
            user_id=user_id,
            tenant_id=tenant_id,
        )

        # Save to storage
        self._storage.save(session)

        logger.debug(
            "Created conversation session", extra={"session_id": session_id, "user_id": user_id, "tenant_id": tenant_id}
        )

        return session_id

    def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        *,
        emotion: Optional[str] = None,
        audio_url: Optional[str] = None,
        sources_json: Optional[str] = None,
    ) -> None:
        """
        Add a message to conversation.

        Args:
            session_id: Session ID
            role: Message role ("user", "assistant", "system")
            content: Message content

        Raises:
            ValueError: If session not found
        """
        session = self._storage.get(session_id)
        if not session:
            raise ValueError(f"Session {session_id} not found")

        session.add_message(
            role,
            content,
            emotion=emotion,
            audio_url=audio_url,
            sources_json=sources_json,
        )

        # Persist updated session
        self._storage.save(session)

        logger.debug("Added message to conversation", extra={"session_id": session_id, "role": role})

    def get_messages(
        self,
        session_id: str,
        max_tokens: Optional[int] = None,
        include_system: bool = True,
    ) -> List[Dict[str, str]]:
        """
        Get conversation messages, truncating if needed.

        Uses FIFO truncation: keeps most recent messages that fit in token budget.

        Args:
            session_id: Session ID
            max_tokens: Maximum tokens (uses max_context_tokens if not provided)
            include_system: Whether to include system messages

        Returns:
            List of message dicts

        Raises:
            ValueError: If session not found
        """
        session = self._storage.get(session_id)
        if not session:
            raise ValueError(f"Session {session_id} not found")

        max_tokens = max_tokens or self.max_context_tokens

        messages = session.messages.copy()

        # Filter system messages if needed
        if not include_system:
            messages = [msg for msg in messages if msg.get("role") != "system"]

        # Truncate if needed (FIFO: keep most recent) using token estimation
        total_tokens = sum(self.estimate_tokens(msg.get("content", "")) for msg in messages)

        if total_tokens > max_tokens:
            # Remove oldest messages until we fit
            truncated = []
            current_tokens = 0

            # Keep system messages if present
            system_messages = [msg for msg in messages if msg.get("role") == "system"]
            system_tokens = sum(self.estimate_tokens(msg.get("content", "")) for msg in system_messages)

            # Add system messages first
            truncated.extend(system_messages)
            current_tokens = system_tokens

            # Add user/assistant messages from end (most recent)
            user_assistant_messages = [msg for msg in messages if msg.get("role") != "system"]
            for msg in reversed(user_assistant_messages):
                msg_tokens = self.estimate_tokens(msg.get("content", ""))
                if current_tokens + msg_tokens <= max_tokens:
                    truncated.insert(len(system_messages), msg)
                    current_tokens += msg_tokens
                else:
                    break

            messages = truncated

            logger.debug(
                "Truncated conversation messages",
                extra={
                    "session_id": session_id,
                    "original_count": len(session.messages),
                    "truncated_count": len(messages),
                    "max_tokens": max_tokens,
                },
            )

        return messages

    def summarize_if_needed(
        self,
        session_id: str,
        *,
        trigger_message_count: int = 24,
        keep_recent_messages: int = 12,
        max_summary_tokens: int = 400,
    ) -> bool:
        """
        Summarize older conversation turns when message count grows too large.

        Keeps recent turns verbatim and replaces older user/assistant turns
        with a compact system summary message.

        Returns:
            True when a summary was written, otherwise False.
        """
        session = self._storage.get(session_id)
        if not session:
            raise ValueError(f"Session {session_id} not found")

        messages = session.messages
        non_system = [m for m in messages if m.get("role") != "system"]
        if len(non_system) <= trigger_message_count:
            return False

        keep_recent_messages = max(1, keep_recent_messages)
        recent_messages = non_system[-keep_recent_messages:]
        older_messages = non_system[:-keep_recent_messages]
        if not older_messages:
            return False

        summary_text = self._build_summary_text(older_messages, max_summary_tokens=max_summary_tokens)
        if not summary_text.strip():
            return False

        system_messages = [
            m
            for m in messages
            if m.get("role") == "system" and not str(m.get("content", "")).startswith(self._summary_marker)
        ]

        summary_message = {
            "role": "system",
            "content": f"{self._summary_marker}\n{summary_text}",
        }
        session.messages = [*system_messages, summary_message, *recent_messages]
        session.updated_at = time.time()
        self._storage.save(session)

        logger.debug(
            "Conversation summarized",
            extra={
                "session_id": session_id,
                "original_count": len(messages),
                "new_count": len(session.messages),
            },
        )
        return True

    def _build_summary_text(self, messages: List[Dict[str, str]], max_summary_tokens: int = 400) -> str:
        """
        Build a deterministic summary from old conversation turns.

        This avoids extra LLM calls while still preserving key context.
        """
        if not messages:
            return ""

        lines: List[str] = []
        for msg in messages:
            role = (msg.get("role") or "user").strip().lower()
            role_label = "User" if role == "user" else "Assistant"
            content = (msg.get("content") or "").strip().replace("\n", " ")
            if not content:
                continue
            if len(content) > 200:
                content = content[:197] + "..."
            lines.append(f"{role_label}: {content}")

        if not lines:
            return ""

        summary = "Earlier conversation highlights:\n" + "\n".join(lines)
        max_chars = max(200, max_summary_tokens * 4)
        if len(summary) > max_chars:
            summary = summary[: max_chars - 3] + "..."
        return summary

    def clear_session(self, session_id: str) -> None:
        """
        Clear conversation session.

        Args:
            session_id: Session ID
        """
        session = self._storage.get(session_id)
        if session:
            session.clear()
            self._storage.save(session)
            logger.debug("Cleared conversation session", extra={"session_id": session_id})

    def delete_session(self, session_id: str) -> None:
        """
        Delete conversation session.

        Args:
            session_id: Session ID
        """
        self._storage.delete(session_id)
        logger.debug("Deleted conversation session", extra={"session_id": session_id})

    def get_session(self, session_id: str) -> Optional[ConversationSession]:
        """
        Get conversation session.

        Args:
            session_id: Session ID

        Returns:
            ConversationSession or None
        """
        return self._storage.get(session_id)

    # ------------------------------------------------------------------
    # Async-safe wrappers
    # ------------------------------------------------------------------

    async def create_session_async(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ) -> str:
        """Async wrapper for :meth:`create_session` (offloads sync storage I/O)."""
        return await asyncio.to_thread(
            self.create_session,
            user_id,
            tenant_id,
            session_id,
        )

    async def add_message_async(
        self,
        session_id: str,
        role: str,
        content: str,
        *,
        emotion: Optional[str] = None,
        audio_url: Optional[str] = None,
        sources_json: Optional[str] = None,
    ) -> None:
        """Async wrapper for :meth:`add_message` (offloads sync storage I/O)."""
        await asyncio.to_thread(
            self.add_message,
            session_id,
            role,
            content,
            emotion=emotion,
            audio_url=audio_url,
            sources_json=sources_json,
        )

    async def get_messages_async(
        self,
        session_id: str,
        max_tokens: Optional[int] = None,
        include_system: bool = True,
    ) -> List[Dict[str, str]]:
        """Async wrapper for :meth:`get_messages` (offloads sync storage I/O)."""
        return await asyncio.to_thread(
            self.get_messages,
            session_id,
            max_tokens,
            include_system,
        )

    async def summarize_if_needed_async(
        self,
        session_id: str,
        *,
        trigger_message_count: int = 24,
        keep_recent_messages: int = 12,
        max_summary_tokens: int = 400,
    ) -> bool:
        """Async wrapper for :meth:`summarize_if_needed` (offloads sync storage I/O)."""
        return await asyncio.to_thread(
            self.summarize_if_needed,
            session_id,
            trigger_message_count=trigger_message_count,
            keep_recent_messages=keep_recent_messages,
            max_summary_tokens=max_summary_tokens,
        )

    async def get_session_async(self, session_id: str) -> Optional[ConversationSession]:
        """Async wrapper for :meth:`get_session` (offloads sync storage I/O)."""
        return await asyncio.to_thread(self.get_session, session_id)

    def cleanup_expired_sessions(self) -> int:
        """
        Clean up expired sessions (older than TTL).

        Note: Only works for in-memory storage. Redis/PostgreSQL backends
        handle TTL automatically.

        Returns:
            Number of sessions cleaned up
        """
        # Only cleanup for in-memory storage
        if not hasattr(self._storage, "_sessions"):
            logger.debug("Cleanup skipped (not using in-memory storage)")
            return 0

        current_time = time.time()
        sessions_dict = getattr(self._storage, "_sessions", {})
        expired_sessions = [
            sid
            for sid, session in sessions_dict.items()
            if current_time - session.updated_at > self.session_ttl_seconds
        ]

        for sid in expired_sessions:
            self._storage.delete(sid)

        if expired_sessions:
            logger.info(
                f"Cleaned up {len(expired_sessions)} expired sessions", extra={"expired_count": len(expired_sessions)}
            )

        return len(expired_sessions)

    def get_session_count(self) -> int:
        """
        Get number of active sessions.

        Note: Only accurate for in-memory storage. Redis/PostgreSQL backends
        don't provide efficient count operations.
        """
        if hasattr(self._storage, "_sessions"):
            return len(getattr(self._storage, "_sessions", {}))
        # For Redis/PostgreSQL, we can't efficiently count without scanning
        return -1

    def get_all_sessions(self) -> Dict[str, ConversationSession]:
        """
        Get all sessions (for debugging/monitoring).

        Note: Only works for in-memory storage. Redis/PostgreSQL backends
        don't support efficient full scans.
        """
        if hasattr(self._storage, "_sessions"):
            return getattr(self._storage, "_sessions", {}).copy()
        # For Redis/PostgreSQL, return empty dict (can't efficiently scan)
        logger.warning("get_all_sessions() only works with in-memory storage")
        return {}
