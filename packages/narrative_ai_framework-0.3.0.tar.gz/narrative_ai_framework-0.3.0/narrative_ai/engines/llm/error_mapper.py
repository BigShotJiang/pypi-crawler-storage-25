"""
Provider-Specific Error Mapping.

Maps provider-specific error codes and messages to framework error types
with rich context for better debugging and retry decisions.
"""

import logging
from typing import Optional, Dict, Any, Tuple
from enum import Enum

try:
    from narrative_ai.shared.retry_utils import parse_retry_after
except ImportError:

    def parse_retry_after(header_value: Optional[str], default_seconds: int = 5, max_seconds: int = 300) -> int:
        return default_seconds


from .base_llm import (
    LLMError,
    RateLimitError,
    AuthenticationError,
    InvalidInputError,
    ContentFilterError,
    LLMTimeoutError,
    GenerationError,
)

logger = logging.getLogger(__name__)


def _extract_retry_after(error: Exception, default_seconds: int = 5) -> Optional[int]:
    """
    Extract Retry-After from error (RFC 7231).
    Checks: error.retry_after, error.response.headers["Retry-After"],
    error.response.headers["retry-after-ms"] (Azure).
    """
    if hasattr(error, "retry_after") and error.retry_after is not None:
        try:
            return int(error.retry_after)
        except (TypeError, ValueError):
            pass
    if hasattr(error, "response") and error.response is not None:
        resp = error.response
        if hasattr(resp, "headers"):
            headers = resp.headers
            # Standard Retry-After (delay-seconds or HTTP-date)
            retry_after = headers.get("Retry-After") or headers.get("retry-after")
            if retry_after is not None:
                return parse_retry_after(
                    str(retry_after) if not isinstance(retry_after, (int, float)) else str(int(retry_after)),
                    default_seconds=default_seconds,
                )
            # Azure: retry-after-ms
            retry_ms = headers.get("retry-after-ms") or headers.get("Retry-After-Ms")
            if retry_ms is not None:
                try:
                    ms = int(retry_ms)
                    return min(300, max(0, ms // 1000))  # cap at 5 min
                except (TypeError, ValueError):
                    pass
    return None


class ProviderErrorCode(str, Enum):
    """Provider-specific error codes."""

    # Gemini error codes (from Google API)
    GEMINI_RESOURCE_EXHAUSTED = "RESOURCE_EXHAUSTED"  # 429 - Rate limit/quota
    GEMINI_INVALID_ARGUMENT = "INVALID_ARGUMENT"  # 400 - Bad request
    GEMINI_UNAUTHENTICATED = "UNAUTHENTICATED"  # 401 - Invalid API key
    GEMINI_PERMISSION_DENIED = "PERMISSION_DENIED"  # 403 - Quota exceeded/permission
    GEMINI_NOT_FOUND = "NOT_FOUND"  # 404 - Model not found
    GEMINI_DEADLINE_EXCEEDED = "DEADLINE_EXCEEDED"  # 504 - Timeout
    GEMINI_INTERNAL = "INTERNAL"  # 500 - Server error
    GEMINI_UNAVAILABLE = "UNAVAILABLE"  # 503 - Service unavailable

    # OpenAI error codes
    OPENAI_RATE_LIMIT_ERROR = "rate_limit_error"
    OPENAI_INVALID_API_KEY = "invalid_api_key"
    OPENAI_INVALID_REQUEST_ERROR = "invalid_request_error"
    OPENAI_CONTENT_FILTER = "content_filter"
    OPENAI_SERVER_ERROR = "server_error"
    OPENAI_TIMEOUT = "timeout"

    # Claude error codes
    CLAUDE_RATE_LIMIT = "rate_limit_error"
    CLAUDE_AUTHENTICATION_ERROR = "authentication_error"
    CLAUDE_INVALID_REQUEST = "invalid_request_error"
    CLAUDE_OVERLOADED = "overloaded_error"
    CLAUDE_API_ERROR = "api_error"


def parse_gemini_error(error: Exception, correlation_id: Optional[str] = None) -> Tuple[LLMError, Dict[str, Any]]:
    """
    Parse Gemini API error and map to framework error type.

    Args:
        error: Exception from Gemini API
        correlation_id: Request correlation ID

    Returns:
        Tuple of (LLMError, error_details_dict)
    """
    error_str = str(error).lower()
    error_details: Dict[str, Any] = {
        "provider": "gemini",
        "original_error": str(error),
        "error_type": type(error).__name__,
        "correlation_id": correlation_id,
    }

    # Check for Gemini API error attributes
    error_code = None
    status_code = None

    if hasattr(error, "status_code"):
        status_code = error.status_code
        error_details["status_code"] = status_code

    if hasattr(error, "code"):
        error_code = str(error.code)
        error_details["error_code"] = error_code
    elif hasattr(error, "error_code"):
        error_code = str(error.error_code)
        error_details["error_code"] = error_code

    # Parse error message for Gemini-specific patterns
    if hasattr(error, "message"):
        error_details["error_message"] = str(error.message)

    # Map status codes and error codes
    if status_code == 429 or error_code == ProviderErrorCode.GEMINI_RESOURCE_EXHAUSTED:
        retry_after = _extract_retry_after(error, default_seconds=5)
        if retry_after is None and hasattr(error, "retry_after_seconds"):
            retry_after = error.retry_after_seconds

        return (
            RateLimitError(
                f"Gemini rate limit exceeded: {error_details.get('error_message', str(error))}",
                provider="gemini",
                retry_after=retry_after,
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 401 or error_code == ProviderErrorCode.GEMINI_UNAUTHENTICATED:
        return (
            AuthenticationError(
                f"Gemini authentication failed: {error_details.get('error_message', str(error))}",
                provider="gemini",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 403 or error_code == ProviderErrorCode.GEMINI_PERMISSION_DENIED:
        # Could be quota exceeded or permission denied
        if "quota" in error_str or "quota_exceeded" in error_str:
            return (
                RateLimitError(
                    f"Gemini quota exceeded: {error_details.get('error_message', str(error))}",
                    provider="gemini",
                    details=error_details,
                    correlation_id=correlation_id,
                ),
                error_details,
            )
        return (
            AuthenticationError(
                f"Gemini permission denied: {error_details.get('error_message', str(error))}",
                provider="gemini",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 400 or error_code == ProviderErrorCode.GEMINI_INVALID_ARGUMENT:
        return (
            InvalidInputError(
                f"Gemini invalid input: {error_details.get('error_message', str(error))}",
                provider="gemini",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 404 or error_code == ProviderErrorCode.GEMINI_NOT_FOUND:
        return (
            InvalidInputError(
                f"Gemini model not found: {error_details.get('error_message', str(error))}",
                provider="gemini",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 504 or error_code == ProviderErrorCode.GEMINI_DEADLINE_EXCEEDED:
        return (
            LLMTimeoutError(
                f"Gemini request timed out: {error_details.get('error_message', str(error))}",
                provider="gemini",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 503 or error_code == ProviderErrorCode.GEMINI_UNAVAILABLE:
        return (
            GenerationError(
                f"Gemini service unavailable: {error_details.get('error_message', str(error))}",
                provider="gemini",
                retriable=True,
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 500 or error_code == ProviderErrorCode.GEMINI_INTERNAL:
        return (
            GenerationError(
                f"Gemini internal server error: {error_details.get('error_message', str(error))}",
                provider="gemini",
                retriable=True,
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    # Fallback: check error string for common patterns
    if "429" in error_str or "rate_limit" in error_str or "resource_exhausted" in error_str:
        return (
            RateLimitError(
                f"Gemini rate limit: {str(error)}",
                provider="gemini",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if "401" in error_str or "unauthorized" in error_str or "authentication" in error_str:
        return (
            AuthenticationError(
                f"Gemini authentication error: {str(error)}",
                provider="gemini",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if "timeout" in error_str or "deadline" in error_str:
        return (
            LLMTimeoutError(
                f"Gemini timeout: {str(error)}",
                provider="gemini",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    # Default: generic generation error
    return (
        GenerationError(
            f"Gemini error: {str(error)}",
            provider="gemini",
            retriable=True,
            details=error_details,
            correlation_id=correlation_id,
        ),
        error_details,
    )


def parse_openai_error(error: Exception, correlation_id: Optional[str] = None) -> Tuple[LLMError, Dict[str, Any]]:
    """
    Parse OpenAI API error and map to framework error type.

    Args:
        error: Exception from OpenAI API
        correlation_id: Request correlation ID

    Returns:
        Tuple of (LLMError, error_details_dict)
    """
    error_str = str(error).lower()
    error_details: Dict[str, Any] = {
        "provider": "openai",
        "original_error": str(error),
        "error_type": type(error).__name__,
        "correlation_id": correlation_id,
    }

    # Check for OpenAI API error attributes
    error_code = None
    status_code = None

    if hasattr(error, "status_code"):
        status_code = error.status_code
        error_details["status_code"] = status_code

    if hasattr(error, "code"):
        error_code = str(error.code)
        error_details["error_code"] = error_code
    elif hasattr(error, "type"):
        error_code = str(error.type)
        error_details["error_code"] = error_code

    if hasattr(error, "message"):
        error_details["error_message"] = str(error.message)

    # Map OpenAI error codes
    if status_code == 429 or error_code == ProviderErrorCode.OPENAI_RATE_LIMIT_ERROR:
        retry_after = _extract_retry_after(error, default_seconds=5)

        return (
            RateLimitError(
                f"OpenAI rate limit exceeded: {error_details.get('error_message', str(error))}",
                provider="openai",
                retry_after=retry_after,
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 401 or error_code == ProviderErrorCode.OPENAI_INVALID_API_KEY:
        return (
            AuthenticationError(
                f"OpenAI authentication failed: {error_details.get('error_message', str(error))}",
                provider="openai",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 400 or error_code == ProviderErrorCode.OPENAI_INVALID_REQUEST_ERROR:
        # Check for content filter
        if "content_filter" in error_str or error_code == ProviderErrorCode.OPENAI_CONTENT_FILTER:
            return (
                ContentFilterError(
                    f"OpenAI content filter: {error_details.get('error_message', str(error))}",
                    provider="openai",
                    details=error_details,
                    correlation_id=correlation_id,
                ),
                error_details,
            )
        return (
            InvalidInputError(
                f"OpenAI invalid request: {error_details.get('error_message', str(error))}",
                provider="openai",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 500 or error_code == ProviderErrorCode.OPENAI_SERVER_ERROR:
        return (
            GenerationError(
                f"OpenAI server error: {error_details.get('error_message', str(error))}",
                provider="openai",
                retriable=True,
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if "timeout" in error_str or error_code == ProviderErrorCode.OPENAI_TIMEOUT:
        return (
            LLMTimeoutError(
                f"OpenAI timeout: {error_details.get('error_message', str(error))}",
                provider="openai",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    # Fallback: check error string
    if "429" in error_str or "rate_limit" in error_str:
        return (
            RateLimitError(
                f"OpenAI rate limit: {str(error)}",
                provider="openai",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if "401" in error_str or "unauthorized" in error_str or "api_key" in error_str:
        return (
            AuthenticationError(
                f"OpenAI authentication error: {str(error)}",
                provider="openai",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    # Default: generic generation error
    return (
        GenerationError(
            f"OpenAI error: {str(error)}",
            provider="openai",
            retriable=True,
            details=error_details,
            correlation_id=correlation_id,
        ),
        error_details,
    )


def parse_claude_error(error: Exception, correlation_id: Optional[str] = None) -> Tuple[LLMError, Dict[str, Any]]:
    """
    Parse Claude API error and map to framework error type.

    Args:
        error: Exception from Claude API
        correlation_id: Request correlation ID

    Returns:
        Tuple of (LLMError, error_details_dict)
    """
    error_str = str(error).lower()
    error_details: Dict[str, Any] = {
        "provider": "claude",
        "original_error": str(error),
        "error_type": type(error).__name__,
        "correlation_id": correlation_id,
    }

    # Check for Claude API error attributes
    error_code = None
    status_code = None

    if hasattr(error, "status_code"):
        status_code = error.status_code
        error_details["status_code"] = status_code

    if hasattr(error, "type"):
        error_code = str(error.type)
        error_details["error_code"] = error_code

    if hasattr(error, "message"):
        error_details["error_message"] = str(error.message)

    # Map Claude error codes
    if status_code == 429 or error_code == ProviderErrorCode.CLAUDE_RATE_LIMIT:
        retry_after = _extract_retry_after(error, default_seconds=5)

        return (
            RateLimitError(
                f"Claude rate limit exceeded: {error_details.get('error_message', str(error))}",
                provider="claude",
                retry_after=retry_after,
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 401 or error_code == ProviderErrorCode.CLAUDE_AUTHENTICATION_ERROR:
        return (
            AuthenticationError(
                f"Claude authentication failed: {error_details.get('error_message', str(error))}",
                provider="claude",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 400 or error_code == ProviderErrorCode.CLAUDE_INVALID_REQUEST:
        return (
            InvalidInputError(
                f"Claude invalid request: {error_details.get('error_message', str(error))}",
                provider="claude",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 529 or error_code == ProviderErrorCode.CLAUDE_OVERLOADED:
        return (
            GenerationError(
                f"Claude service overloaded: {error_details.get('error_message', str(error))}",
                provider="claude",
                retriable=True,
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if status_code == 500 or error_code == ProviderErrorCode.CLAUDE_API_ERROR:
        return (
            GenerationError(
                f"Claude API error: {error_details.get('error_message', str(error))}",
                provider="claude",
                retriable=True,
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    # Fallback: check error string
    if "429" in error_str or "rate_limit" in error_str:
        return (
            RateLimitError(
                f"Claude rate limit: {str(error)}",
                provider="claude",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    if "401" in error_str or "unauthorized" in error_str or "authentication" in error_str:
        return (
            AuthenticationError(
                f"Claude authentication error: {str(error)}",
                provider="claude",
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )

    # Default: generic generation error
    return (
        GenerationError(
            f"Claude error: {str(error)}",
            provider="claude",
            retriable=True,
            details=error_details,
            correlation_id=correlation_id,
        ),
        error_details,
    )


def parse_provider_error(
    error: Exception,
    provider: str,
    correlation_id: Optional[str] = None,
) -> Tuple[LLMError, Dict[str, Any]]:
    """
    Parse provider-specific error and map to framework error type.

    Args:
        error: Exception from provider API
        provider: Provider name ("gemini", "openai", "claude", etc.)
        correlation_id: Request correlation ID

    Returns:
        Tuple of (LLMError, error_details_dict)
    """
    provider_lower = provider.lower()

    if provider_lower == "gemini":
        return parse_gemini_error(error, correlation_id)
    elif provider_lower == "openai":
        return parse_openai_error(error, correlation_id)
    elif provider_lower == "claude":
        return parse_claude_error(error, correlation_id)
    else:
        # Generic fallback for unknown providers
        error_details: Dict[str, Any] = {
            "provider": provider,
            "original_error": str(error),
            "error_type": type(error).__name__,
            "correlation_id": correlation_id,
        }

        error_str = str(error).lower()
        if "429" in error_str or "rate_limit" in error_str:
            return (
                RateLimitError(
                    f"{provider} rate limit: {str(error)}",
                    provider=provider,
                    details=error_details,
                    correlation_id=correlation_id,
                ),
                error_details,
            )

        if "401" in error_str or "unauthorized" in error_str or "authentication" in error_str:
            return (
                AuthenticationError(
                    f"{provider} authentication error: {str(error)}",
                    provider=provider,
                    details=error_details,
                    correlation_id=correlation_id,
                ),
                error_details,
            )

        return (
            GenerationError(
                f"{provider} error: {str(error)}",
                provider=provider,
                retriable=True,
                details=error_details,
                correlation_id=correlation_id,
            ),
            error_details,
        )
