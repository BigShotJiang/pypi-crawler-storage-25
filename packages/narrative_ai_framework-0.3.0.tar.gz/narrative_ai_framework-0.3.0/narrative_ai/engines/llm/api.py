import asyncio
from typing import Optional, List, Dict, Any, Union, AsyncIterator
from narrative_ai.engines.llm.llm_engine import LLMEngine
from narrative_ai.engines.llm.base_llm import LLMResult, Emotion
from narrative_ai.engines.llm.conversation_manager import ConversationManager
from narrative_ai.engines.llm.input_processor import InputProcessor
from narrative_ai.engines.llm.response_processor import ResponseProcessor

_default_engine: Optional[LLMEngine] = None

def set_api_key(api_key: str, provider: str = "openai"):
    """
    Dynamically set the API key for a specific provider.
    
    Args:
        api_key: The secret API key string.
        provider: Provider name (e.g., 'openai', 'gemini', 'anthropic').
    """
    # We can't use _ensure_engine here because it's async, 
    # but we can modify the config on the singleton if it exists.
    global _default_engine
    if _default_engine:
        config = _default_engine.config.get_provider_config(provider)
        if config:
            config.api_key = api_key
    
    # Also set as environment variable for lazy-loaded engines
    import os
    env_map = {
        "openai": "OPENAI_API_KEY",
        "gemini": "GEMINI_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY",
        "deepseek": "DEEPSEEK_API_KEY",
        "xai": "XAI_API_KEY"
    }
    env_var = env_map.get(provider.lower())
    if env_var:
        os.environ[env_var] = api_key

def set_llm_provider(provider_name: str):
    """Set the primary provider for LLM generation."""
    global _default_engine
    if _default_engine:
        _default_engine.config.primary_provider = provider_name
    
    import os
    os.environ["LLM_PRIMARY_PROVIDER"] = provider_name

async def _ensure_engine() -> LLMEngine:
    """Get or create the default global LLMEngine instance."""
    global _default_engine
    if _default_engine is None:
        _default_engine = LLMEngine()
        await _default_engine.initialize()
    return _default_engine

async def generate(
    prompt: Optional[str] = None,
    system_prompt: Optional[str] = None,
    messages: Optional[List[Dict[str, str]]] = None,
    temperature: float = 0.7,
    max_tokens: Optional[int] = None,
    tools: Optional[List[Dict]] = None,
    tool_choice: Optional[Union[str, Dict]] = None,
    response_format: Optional[Dict] = None,
    provider: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_tier: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> LLMResult:
    """Generate text completion from prompt or messages."""
    engine = await _ensure_engine()
    return await engine.generate(
        prompt=prompt,
        system_prompt=system_prompt,
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
        tools=tools,
        tool_choice=tool_choice,
        response_format=response_format,
        provider=provider,
        user_id=user_id,
        tenant_id=tenant_id,
        user_tier=user_tier,
        correlation_id=correlation_id,
        **kwargs
    )

async def generate_stream(
    prompt: Optional[str] = None,
    system_prompt: Optional[str] = None,
    messages: Optional[List[Dict[str, str]]] = None,
    temperature: float = 0.7,
    max_tokens: Optional[int] = None,
    tools: Optional[List[Dict]] = None,
    tool_choice: Optional[Union[str, Dict]] = None,
    response_format: Optional[Dict] = None,
    provider: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_tier: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> AsyncIterator[str]:
    """Stream generated text tokens (simplified text-only stream)."""
    engine = await _ensure_engine()
    async for result in engine.generate_streaming(
        prompt=prompt,
        system_prompt=system_prompt,
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
        tools=tools,
        tool_choice=tool_choice,
        response_format=response_format,
        provider=provider,
        user_id=user_id,
        tenant_id=tenant_id,
        user_tier=user_tier,
        correlation_id=correlation_id,
        **kwargs
    ):
        if result.text:
            yield result.text

def chat(session_id: Optional[str] = None) -> ConversationManager:
    """Get a conversation manager for stateful chat."""
    return ConversationManager(session_id=session_id)

def check_security(text: str) -> str:
    """
    Check for prompt injection and validate input.
    Returns sanitized text or raises InvalidInputError.
    """
    processor = InputProcessor()
    return processor.validate_prompt(text)

def estimate_tokens(text: str, provider_hint: str = "openai") -> int:
    """Estimate token count for a piece of text."""
    manager = ConversationManager(provider_hint=provider_hint)
    return manager.estimate_tokens(text)

async def summarize_session(
    session_id: str,
    trigger_count: int = 24,
    keep_recent: int = 12
) -> bool:
    """
    Manually trigger conversation summarization if message count exceeds trigger.
    Returns True if summarized, False otherwise.
    """
    manager = ConversationManager()
    return await manager.summarize_if_needed_async(
        session_id,
        trigger_message_count=trigger_count,
        keep_recent_messages=keep_recent
    )

def calculate_cost(result: LLMResult) -> float:
    """Calculate the cost of an LLM generation in USD."""
    processor = ResponseProcessor()
    return processor.calculate_cost(result)

class LLMClient:
    """
    A session-based client for the LLM engine.
    Stores common parameters like user_id, tenant_id, and provider to avoid repetition.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        provider: Optional[str] = None,
        api_key: Optional[str] = None,
        user_tier: Optional[Any] = None,
        correlation_id: Optional[str] = None,
    ):
        """
        Initialize the LLM client with default context.
        
        Args:
            user_id: Default user ID for all requests
            tenant_id: Default tenant ID for all requests
            provider: Default provider to use
            api_key: Optional API key for the session (sets provider key if provided)
            user_tier: Default user tier
            correlation_id: Default correlation ID prefix or value
        """
        if api_key and provider:
            set_api_key(api_key, provider)

        self.defaults = {
            "user_id": user_id,
            "tenant_id": tenant_id,
            "provider": provider,
            "user_tier": user_tier,
            "correlation_id": correlation_id,
        }

    async def generate(self, **kwargs) -> LLMResult:
        """
        Generate text completion using client defaults.
        Specific arguments passed here will override client defaults.
        """
        # Merge defaults with provided kwargs (kwargs takes precedence)
        final_args = {**self.defaults, **kwargs}
        return await generate(**final_args)

    async def generate_stream(self, **kwargs) -> AsyncIterator[str]:
        """
        Stream generated text using client defaults.
        Specific arguments passed here will override client defaults.
        """
        final_args = {**self.defaults, **kwargs}
        async for text in generate_stream(**final_args):
            yield text

    def chat(self, session_id: Optional[str] = None) -> ConversationManager:
        """
        Open a managed conversation session.
        Uses any relevant client defaults (user_id/tenant_id) if not explicitly set.
        """
        manager = chat(session_id=session_id)
        # Note: ConversationManager handles its own persistence based on session_id,
        # but the client-level user_id can be useful for session creation if needed.
        return manager
