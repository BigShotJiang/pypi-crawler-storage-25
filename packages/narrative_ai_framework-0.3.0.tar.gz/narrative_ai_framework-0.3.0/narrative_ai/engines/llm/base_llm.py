"""
Base LLM Provider - Abstract Interface.

Defines the interface that all LLM providers must implement.
This follows the Strategy pattern for interchangeable providers.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, AsyncIterator, Union, Protocol
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class Emotion(str, Enum):
    """Detected emotion categories from LLM responses."""

    HAPPY = "happy"
    SAD = "sad"
    CALM = "calm"
    ANXIOUS = "anxious"
    ANGRY = "angry"
    NEUTRAL = "neutral"
    EMPATHETIC = "empathetic"
    EXCITED = "excited"
    SURPRISED = "surprised"
    THOUGHTFUL = "thoughtful"


class FinishReason(str, Enum):
    """Reason why generation finished."""

    STOP = "stop"  # Natural stop
    LENGTH = "length"  # Max tokens reached
    TOOL_CALLS = "tool_calls"  # Function calling
    CONTENT_FILTER = "content_filter"  # Safety filter
    ERROR = "error"  # Error occurred


class ErrorSeverity(str, Enum):
    """Error severity levels."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class LLMResult:
    """
    Result from LLM generation.

    Contains generated text, token usage, emotion (if extracted),
    and metadata from the provider.
    """

    # Core response
    text: str
    finish_reason: str  # "stop", "length", "tool_calls", "error", "content_filter"

    # Provider info
    provider: str
    model: str
    processing_time: float

    # Token usage
    input_tokens: int
    output_tokens: int
    total_tokens: int

    # Emotion (extracted from response)
    emotion: Optional[Emotion] = None
    emotion_confidence: Optional[float] = None

    # Tool calls (if function calling used)
    tool_calls: Optional[List[Dict[str, Any]]] = None

    # Streaming
    is_partial: bool = False
    is_final: bool = True

    # Metadata
    metadata: Optional[Dict[str, Any]] = field(default_factory=dict)
    correlation_id: Optional[str] = None

    def __post_init__(self) -> None:
        """Validate and auto-correct token counts for consistency."""
        # Ensure non-negative
        if self.input_tokens < 0:
            logger.warning(
                f"LLMResult input_tokens {self.input_tokens} < 0, clamping to 0",
                extra={"provider": self.provider, "correlation_id": self.correlation_id},
            )
            object.__setattr__(self, "input_tokens", 0)
        if self.output_tokens < 0:
            logger.warning(
                f"LLMResult output_tokens {self.output_tokens} < 0, clamping to 0",
                extra={"provider": self.provider, "correlation_id": self.correlation_id},
            )
            object.__setattr__(self, "output_tokens", 0)
        # Enforce total_tokens == input_tokens + output_tokens
        expected_total = self.input_tokens + self.output_tokens
        if self.total_tokens != expected_total:
            logger.warning(
                f"LLMResult total_tokens mismatch: {self.total_tokens} != {self.input_tokens} + {self.output_tokens}, auto-correcting to {expected_total}",
                extra={"provider": self.provider, "correlation_id": self.correlation_id},
            )
            object.__setattr__(self, "total_tokens", expected_total)


class LLMError(Exception):
    """Base exception for LLM errors."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        details: Optional[Dict] = None,
        retriable: bool = False,
        severity: ErrorSeverity = ErrorSeverity.MEDIUM,
        correlation_id: Optional[str] = None,
    ):
        super().__init__(message)
        self.provider = provider
        self.details = details or {}
        self.retriable = retriable
        self.severity = severity
        self.correlation_id = correlation_id


class ProviderUnavailableError(LLMError):
    """Raised when a provider is not available."""

    def __init__(self, message: str, provider: Optional[str] = None, **kwargs):
        super().__init__(message, provider=provider, retriable=False, **kwargs)


class GenerationError(LLMError):
    """Raised when generation fails."""

    def __init__(self, message: str, provider: Optional[str] = None, **kwargs):
        super().__init__(message, provider=provider, retriable=True, **kwargs)


class RateLimitError(LLMError):
    """Raised when rate limit is exceeded."""

    def __init__(self, message: str, provider: Optional[str] = None, retry_after: Optional[int] = None, **kwargs):
        super().__init__(message, provider=provider, retriable=True, **kwargs)
        self.retry_after = retry_after


class AuthenticationError(LLMError):
    """Raised when authentication fails."""

    def __init__(self, message: str, provider: Optional[str] = None, **kwargs):
        super().__init__(message, provider=provider, retriable=False, **kwargs)


class InvalidInputError(LLMError):
    """Raised when input is invalid."""

    def __init__(self, message: str, provider: Optional[str] = None, **kwargs):
        super().__init__(message, provider=provider, retriable=False, **kwargs)


class ContentFilterError(LLMError):
    """Raised when content is filtered by safety filters."""

    def __init__(self, message: str, provider: Optional[str] = None, **kwargs):
        super().__init__(message, provider=provider, retriable=False, **kwargs)


class LLMTimeoutError(LLMError):
    """Raised when an LLM request times out."""

    def __init__(self, message: str, provider: Optional[str] = None, **kwargs):
        super().__init__(message, provider=provider, retriable=True, **kwargs)


class LLMNetworkError(LLMError):
    """Raised when a network/connection error occurs during an LLM request."""

    def __init__(self, message: str, provider: Optional[str] = None, **kwargs):
        super().__init__(message, provider=provider, retriable=True, **kwargs)


def is_retriable_error(error: Exception) -> bool:
    """
    Check if an error is retriable.

    Args:
        error: Exception to check

    Returns:
        True if error is retriable
    """
    if isinstance(error, LLMError):
        return error.retriable

    # Network errors are generally retriable
    error_str = str(error).lower()
    retriable_patterns = [
        "timeout",
        "connection",
        "network",
        "temporary",
        "503",
        "502",
        "504",
    ]

    return any(pattern in error_str for pattern in retriable_patterns)


def estimate_input_tokens(
    prompt: Optional[str] = None,
    system_prompt: Optional[str] = None,
    messages: Optional[List[Dict[str, str]]] = None,
) -> int:
    """
    Estimate input tokens (rough approximation).

    Uses word count * 1.3 as approximation (average tokens per word).

    Args:
        prompt: User prompt
        system_prompt: System instruction
        messages: Conversation messages

    Returns:
        Estimated token count
    """
    total_text = ""

    if prompt:
        total_text += prompt + " "
    if system_prompt:
        total_text += system_prompt + " "
    if messages:
        for msg in messages:
            content = msg.get("content", "")
            if content:
                total_text += content + " "

    # Rough estimate: ~1.3 tokens per word
    word_count = len(total_text.split())
    return int(word_count * 1.3)


class MetricsExporter(Protocol):
    """Protocol for external metrics exporters (Prometheus, StatsD, DataDog)."""

    def increment(self, name: str, value: float = 1.0, tags: Optional[Dict[str, str]] = None) -> None:
        """Increment a counter metric."""
        ...

    def gauge(self, name: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        """Set a gauge metric."""
        ...

    def histogram(self, name: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        """Record a histogram value."""
        ...


class NoOpMetricsExporter:
    """No-op metrics exporter (default)."""

    def increment(self, name: str, value: float = 1.0, tags: Optional[Dict[str, str]] = None) -> None:
        pass

    def gauge(self, name: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        pass

    def histogram(self, name: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        pass


# Global metrics exporter
_metrics_exporter: Optional[MetricsExporter] = None


def set_metrics_exporter(exporter: MetricsExporter) -> None:
    """Set the global metrics exporter."""
    global _metrics_exporter
    _metrics_exporter = exporter


def get_metrics_exporter() -> MetricsExporter:
    """Get the global metrics exporter (returns NoOp if not set)."""
    global _metrics_exporter
    if _metrics_exporter is None:
        return NoOpMetricsExporter()
    return _metrics_exporter


class BaseLLMProvider(ABC):
    """
    Abstract base class for LLM providers.

    All LLM providers (Gemini, OpenAI, Claude, xAI, DeepSeek) must implement this interface.
    This enables the Strategy pattern for interchangeable providers with fallback support.
    """

    def __init__(self):
        """Initialize base provider."""
        self._is_loaded = False
        self._load_time: Optional[float] = None

    @abstractmethod
    async def generate(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        stream: bool = False,
        correlation_id: Optional[str] = None,
    ) -> Union[LLMResult, AsyncIterator[LLMResult]]:
        """
        Generate text completion.

        Args:
            prompt: User prompt (if messages not provided)
            system_prompt: System instruction
            messages: Conversation history (list of {"role": "user/assistant/system", "content": "..."})
            temperature: Sampling temperature (0-2)
            max_tokens: Maximum tokens to generate
            tools: Function calling tools (JSON schema)
            tool_choice: Tool choice strategy ("auto", "required", "none", or tool name)
            response_format: Structured output format (JSON schema)
            stream: Whether to stream response
            correlation_id: Request correlation ID

        Returns:
            LLMResult (non-streaming) or AsyncIterator[LLMResult] (streaming)

        Raises:
            LLMError: Base error
            LLMTimeoutError: Request timed out (retriable)
            LLMNetworkError: Network/connection error (retriable)
            RateLimitError: Rate limit exceeded
            AuthenticationError: Invalid API key
            ProviderUnavailableError: Provider not available
        """
        pass

    @abstractmethod
    async def generate_streaming(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[LLMResult]:
        """
        Stream text completion with incremental results.

        Yields:
            LLMResult objects with:
            - is_partial=True for interim results
            - is_final=True for the final result
        """
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """Check if provider is available and ready."""
        pass

    @abstractmethod
    def get_provider_name(self) -> str:
        """Get provider name."""
        pass

    async def load_model(self) -> None:
        """
        Lazy load model/resources if needed.

        This is called automatically before generate() if not already loaded.
        """
        if self._is_loaded:
            return

        import time

        start_time = time.time()
        await self._load_model_impl()
        self._load_time = time.time() - start_time
        self._is_loaded = True
        logger.debug(f"{self.get_provider_name()} provider loaded in {self._load_time:.2f}s")

    @abstractmethod
    async def _load_model_impl(self) -> None:
        """Internal implementation of model loading."""
        pass

    async def shutdown(self) -> None:
        """Cleanup resources."""
        if not self._is_loaded:
            return

        await self._shutdown_impl()
        self._is_loaded = False
        logger.debug(f"{self.get_provider_name()} provider shut down")

    @abstractmethod
    async def _shutdown_impl(self) -> None:
        """Internal implementation of shutdown."""
        pass
