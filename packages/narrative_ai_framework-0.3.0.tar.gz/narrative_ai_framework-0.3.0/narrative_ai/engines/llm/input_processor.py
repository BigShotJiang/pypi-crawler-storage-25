"""
LLM Input Processor - Validation & Sanitization.

Validates and sanitizes LLM inputs (prompts, messages, parameters)
to prevent injection attacks and ensure data integrity.

Production-Ready Features:
- Prompt injection detection
- Input length validation
- Message format validation
- Parameter validation
- Integration with security layer
"""

import re
import logging
from typing import Optional, List, Dict, Any, Tuple
from dataclasses import dataclass

from .base_llm import InvalidInputError

logger = logging.getLogger(__name__)


# Security layer imports - optional to allow standalone usage
_INPUT_VALIDATOR_AVAILABLE = False

try:
    from narrative_ai.security.input_validation import (
        validate_text,
        ValidationError as InputValidationError,
    )

    _INPUT_VALIDATOR_AVAILABLE = True
except ImportError:
    validate_text = None
    InputValidationError = None

if not _INPUT_VALIDATOR_AVAILABLE:
    logger.warning("Security input validation not available - using basic validation")


# =============================================================================
# Configuration
# =============================================================================


@dataclass
class InputProcessorConfig:
    """Configuration for input processor."""

    # Length limits
    max_prompt_length: int = 1000000  # ~1M tokens (conservative estimate: 1 char ≈ 0.25 tokens)
    max_message_length: int = 1000000
    max_system_prompt_length: int = 10000
    max_messages_count: int = 100

    # Validation
    enable_prompt_injection_detection: bool = True
    enable_length_validation: bool = True
    enable_format_validation: bool = True

    # Sanitization
    strip_whitespace: bool = True
    normalize_unicode: bool = True


# =============================================================================
# Prompt Injection Patterns
# =============================================================================

# Pre-compiled prompt injection patterns with atomic groups
# These patterns are designed to catch OBVIOUS prompt injection attacks
# while avoiding false positives on legitimate content.

# Whitelist patterns that should NOT trigger injection detection
# (e.g., "ignore previous mistakes" in learning context)
INJECTION_WHITELIST_PATTERNS = [
    re.compile(r"ignore\s+previous\s+mistakes?", re.IGNORECASE),  # Learning context
    re.compile(r"forget\s+what\s+I\s+said\s+before", re.IGNORECASE),  # Conversation reset
    re.compile(r"disregard\s+the\s+above\s+if\s+it\s+was\s+wrong", re.IGNORECASE),  # Error correction
]

PROMPT_INJECTION_PATTERNS = [
    # Multi-word attack phrases (very specific to avoid false positives)
    # Only match when NOT in whitelist context
    re.compile(
        r"(?:ignore|disregard|forget)\s+(?:all\s+)?(?:previous|above|prior)\s+(?:instructions?|prompts?|commands?|rules?)(?!\s+(?:mistakes?|errors?|if\s+wrong))",
        re.IGNORECASE,
    ),
    re.compile(r"(?:you\s+are\s+now|from\s+now\s+on\s+you\s+are)\s+(?:a|an|my)", re.IGNORECASE),  # Role reassignment
    re.compile(r"(?:override|bypass)\s+(?:your|all|system)\s+(?:instructions?|rules?|settings?)", re.IGNORECASE),
    re.compile(r"(?:pretend|act\s+as\s+if)\s+(?:you\s+are|there\s+are\s+no)\s+", re.IGNORECASE),
    # LLM token injection (exact format only)
    re.compile(r"<\|(?:im_start|im_end|system|user|assistant|endoftext)\|>", re.IGNORECASE),
    re.compile(r"\[(?:INST|/INST|SYS|/SYS)\]", re.IGNORECASE),  # Llama-style tokens
    # Jailbreak markers
    re.compile(r"(?:DAN|STAN|DUDE)\s*(?:mode|prompt|jailbreak)", re.IGNORECASE),
]


# =============================================================================
# Input Processor
# =============================================================================


class InputProcessor:
    """
    Processes and validates LLM inputs.

    Features:
    - Prompt injection detection
    - Length validation
    - Message format validation
    - Parameter validation
    - Sanitization
    """

    def __init__(self, config: Optional[InputProcessorConfig] = None):
        """
        Initialize input processor.

        Args:
            config: Processor configuration (uses defaults if not provided)
        """
        self.config = config or InputProcessorConfig()

    def validate_prompt(
        self,
        prompt: Optional[str],
        correlation_id: Optional[str] = None,
    ) -> str:
        """
        Validate and sanitize a prompt string.

        Args:
            prompt: Prompt text to validate
            correlation_id: Request correlation ID

        Returns:
            Sanitized prompt

        Raises:
            InvalidInputError: If validation fails
        """
        if prompt is None:
            return ""

        # Basic type check
        if not isinstance(prompt, str):
            raise InvalidInputError(
                "Prompt must be a string",
                provider="input_processor",
                correlation_id=correlation_id,
            )

        # Sanitize
        prompt = self._sanitize_text(prompt)

        # Length validation
        if self.config.enable_length_validation:
            if len(prompt) > self.config.max_prompt_length:
                raise InvalidInputError(
                    f"Prompt too long: {len(prompt)} characters (max: {self.config.max_prompt_length})",
                    provider="input_processor",
                    details={"length": len(prompt), "max_length": self.config.max_prompt_length},
                    correlation_id=correlation_id,
                )

        # Prompt injection detection
        if self.config.enable_prompt_injection_detection:
            self._check_prompt_injection(prompt, correlation_id)

        # Use security layer validation if available
        if _INPUT_VALIDATOR_AVAILABLE and validate_text:
            try:
                validate_text(
                    prompt,
                    min_length=0,
                    max_length=self.config.max_prompt_length,
                )
            except InputValidationError as e:
                raise InvalidInputError(
                    f"Input validation failed: {e.message}",
                    provider="input_processor",
                    correlation_id=correlation_id,
                ) from e

        return prompt

    def validate_system_prompt(
        self,
        system_prompt: Optional[str],
        correlation_id: Optional[str] = None,
    ) -> Optional[str]:
        """
        Validate and sanitize a system prompt.

        Args:
            system_prompt: System prompt text
            correlation_id: Request correlation ID

        Returns:
            Sanitized system prompt or None

        Raises:
            InvalidInputError: If validation fails
        """
        if system_prompt is None:
            return None

        # Basic type check
        if not isinstance(system_prompt, str):
            raise InvalidInputError(
                "System prompt must be a string",
                provider="input_processor",
                correlation_id=correlation_id,
            )

        # Sanitize
        system_prompt = self._sanitize_text(system_prompt)

        # Length validation
        if self.config.enable_length_validation:
            if len(system_prompt) > self.config.max_system_prompt_length:
                raise InvalidInputError(
                    f"System prompt too long: {len(system_prompt)} characters (max: {self.config.max_system_prompt_length})",
                    provider="input_processor",
                    details={"length": len(system_prompt), "max_length": self.config.max_system_prompt_length},
                    correlation_id=correlation_id,
                )

        return system_prompt

    def validate_messages(
        self,
        messages: Optional[List[Dict[str, str]]],
        correlation_id: Optional[str] = None,
    ) -> List[Dict[str, str]]:
        """
        Validate and sanitize message list.

        Args:
            messages: List of message dicts with "role" and "content"
            correlation_id: Request correlation ID

        Returns:
            Validated and sanitized messages

        Raises:
            InvalidInputError: If validation fails
        """
        if messages is None:
            return []

        # Type check
        if not isinstance(messages, list):
            raise InvalidInputError(
                "Messages must be a list",
                provider="input_processor",
                correlation_id=correlation_id,
            )

        # Validate empty messages list
        if len(messages) == 0:
            raise InvalidInputError(
                "Messages list cannot be empty. Provide at least one message or use 'prompt' parameter.",
                provider="input_processor",
                correlation_id=correlation_id,
            )

        # Count validation
        if len(messages) > self.config.max_messages_count:
            raise InvalidInputError(
                f"Too many messages: {len(messages)} (max: {self.config.max_messages_count})",
                provider="input_processor",
                details={"count": len(messages), "max_count": self.config.max_messages_count},
                correlation_id=correlation_id,
            )

        # Validate each message
        validated_messages = []
        for i, message in enumerate(messages):
            validated_message = self._validate_single_message(
                message,
                index=i,
                correlation_id=correlation_id,
            )
            validated_messages.append(validated_message)

        return validated_messages

    def _validate_single_message(
        self,
        message: Dict[str, Any],
        index: int,
        correlation_id: Optional[str] = None,
    ) -> Dict[str, str]:
        """
        Validate a single message dict.

        Args:
            message: Message dict
            index: Message index (for error reporting)
            correlation_id: Request correlation ID

        Returns:
            Validated message dict

        Raises:
            InvalidInputError: If validation fails
        """
        if not isinstance(message, dict):
            raise InvalidInputError(
                f"Message {index} must be a dict",
                provider="input_processor",
                correlation_id=correlation_id,
            )

        # Check required fields
        if "role" not in message:
            raise InvalidInputError(
                f"Message {index} missing 'role' field",
                provider="input_processor",
                correlation_id=correlation_id,
            )

        if "content" not in message:
            raise InvalidInputError(
                f"Message {index} missing 'content' field",
                provider="input_processor",
                correlation_id=correlation_id,
            )

        # Validate role
        role = message["role"]
        if not isinstance(role, str):
            raise InvalidInputError(
                f"Message {index} 'role' must be a string",
                provider="input_processor",
                correlation_id=correlation_id,
            )

        valid_roles = ["system", "user", "assistant"]
        if role.lower() not in valid_roles:
            logger.warning(
                f"Message {index} has unusual role: {role}", extra={"correlation_id": correlation_id, "role": role}
            )
            # Normalize role
            role = role.lower()
            if role not in valid_roles:
                role = "user"  # Default to user

        # Validate and sanitize content
        content = message["content"]
        if not isinstance(content, str):
            raise InvalidInputError(
                f"Message {index} 'content' must be a string",
                provider="input_processor",
                correlation_id=correlation_id,
            )

        content = self._sanitize_text(content)

        # Length validation
        if self.config.enable_length_validation:
            if len(content) > self.config.max_message_length:
                raise InvalidInputError(
                    f"Message {index} content too long: {len(content)} characters (max: {self.config.max_message_length})",
                    provider="input_processor",
                    details={"index": index, "length": len(content), "max_length": self.config.max_message_length},
                    correlation_id=correlation_id,
                )

        # Prompt injection detection (only for user messages)
        if self.config.enable_prompt_injection_detection and role == "user":
            self._check_prompt_injection(content, correlation_id)

        return {
            "role": role.lower(),
            "content": content,
        }

    def validate_parameters(
        self,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        correlation_id: Optional[str] = None,
    ) -> Tuple[float, Optional[int]]:
        """
        Validate generation parameters.

        Args:
            temperature: Sampling temperature (0-2)
            max_tokens: Maximum tokens to generate
            correlation_id: Request correlation ID

        Returns:
            Validated (temperature, max_tokens)

        Raises:
            InvalidInputError: If validation fails
        """
        # Validate temperature
        if not isinstance(temperature, (int, float)):
            raise InvalidInputError(
                f"Temperature must be a number, got {type(temperature)}",
                provider="input_processor",
                correlation_id=correlation_id,
            )

        if temperature < 0 or temperature > 2:
            logger.warning(
                f"Temperature {temperature} out of recommended range [0, 2]",
                extra={"correlation_id": correlation_id, "temperature": temperature},
            )
            # Clamp to valid range
            temperature = max(0.0, min(2.0, float(temperature)))

        # Validate max_tokens
        if max_tokens is not None:
            if not isinstance(max_tokens, int):
                raise InvalidInputError(
                    f"max_tokens must be an integer, got {type(max_tokens)}",
                    provider="input_processor",
                    correlation_id=correlation_id,
                )

            if max_tokens < 1:
                raise InvalidInputError(
                    f"max_tokens must be >= 1, got {max_tokens}",
                    provider="input_processor",
                    correlation_id=correlation_id,
                )

        return float(temperature), max_tokens

    def _sanitize_text(self, text: str) -> str:
        """
        Sanitize text input.

        Args:
            text: Input text

        Returns:
            Sanitized text
        """
        # Strip whitespace
        if self.config.strip_whitespace:
            text = text.strip()

        # Normalize unicode (NFKC normalization)
        if self.config.normalize_unicode:
            import unicodedata

            text = unicodedata.normalize("NFKC", text)

        return text

    def _check_prompt_injection(
        self,
        text: str,
        correlation_id: Optional[str] = None,
    ) -> None:
        """
        Check for prompt injection patterns with context-aware detection.

        Uses whitelist patterns to avoid false positives on legitimate content
        (e.g., "ignore previous mistakes" in learning contexts).

        Args:
            text: Text to check
            correlation_id: Request correlation ID

        Raises:
            InvalidInputError: If prompt injection detected
        """
        # Check whitelist first - if text matches whitelist, skip injection check
        for whitelist_pattern in INJECTION_WHITELIST_PATTERNS:
            if whitelist_pattern.search(text):
                logger.debug(
                    "Text matches injection whitelist, skipping injection check",
                    extra={"correlation_id": correlation_id, "pattern": whitelist_pattern.pattern},
                )
                return  # Whitelisted, allow through

        # Check for injection patterns
        for pattern in PROMPT_INJECTION_PATTERNS:
            if pattern.search(text):
                logger.warning(
                    "Potential prompt injection detected",
                    extra={
                        "correlation_id": correlation_id,
                        "pattern": pattern.pattern,
                    },
                )
                # Block by default in production
                if self.config.enable_prompt_injection_detection:
                    raise InvalidInputError(
                        "Potential prompt injection detected. Request blocked for security.",
                        provider="input_processor",
                        correlation_id=correlation_id,
                    )

    def process_inputs(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        correlation_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Process and validate all inputs at once.

        Args:
            prompt: User prompt
            system_prompt: System prompt
            messages: Conversation messages
            temperature: Sampling temperature
            max_tokens: Maximum tokens
            correlation_id: Request correlation ID

        Returns:
            Dict with validated inputs

        Raises:
            InvalidInputError: If validation fails
        """
        # Validate that either prompt or messages is provided
        if not prompt and not messages:
            raise InvalidInputError(
                "Either 'prompt' or 'messages' must be provided",
                provider="input_processor",
                correlation_id=correlation_id,
            )

        # Process inputs
        validated_prompt = self.validate_prompt(prompt, correlation_id) if prompt else None
        validated_system_prompt = self.validate_system_prompt(system_prompt, correlation_id)
        validated_messages = self.validate_messages(messages, correlation_id) if messages else None
        validated_temperature, validated_max_tokens = self.validate_parameters(
            temperature,
            max_tokens,
            correlation_id,
        )

        return {
            "prompt": validated_prompt,
            "system_prompt": validated_system_prompt,
            "messages": validated_messages,
            "temperature": validated_temperature,
            "max_tokens": validated_max_tokens,
        }
