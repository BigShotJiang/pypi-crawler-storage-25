"""
Gemini LLM Provider.

Implements Google Gemini API integration using the new SDK.
Supports streaming, function calling, structured outputs, and multi-modal inputs.

Documentation: https://ai.google.dev/gemini-api/docs
"""

import asyncio
import time
import logging
from typing import Optional, Dict, Any, List, AsyncIterator, Union

try:
    from google import genai
except ImportError:
    genai = None
    logging.warning("google-generativeai not installed. Gemini provider will not be available.")

from .base_llm import (
    BaseLLMProvider,
    LLMResult,
    LLMError,
    GenerationError,
    ProviderUnavailableError,
    RateLimitError,
    AuthenticationError,
    InvalidInputError,
    ContentFilterError,
    LLMTimeoutError,
    LLMNetworkError,
    FinishReason,
    is_retriable_error,
    estimate_input_tokens,
)
from .config import GeminiConfig
from .error_mapper import parse_provider_error

logger = logging.getLogger(__name__)


def _format_request_for_gemini(
    prompt: Optional[str],
    messages: Optional[List[Dict[str, str]]],
    system_prompt: Optional[str],
    model_name: str,
    temperature: float = 0.7,
    max_tokens: Optional[int] = None,
    tools: Optional[List[Dict]] = None,
    tool_choice: Optional[Any] = None,
    response_format: Optional[Dict] = None,
) -> Dict[str, Any]:
    """
    Build request dict for Gemini API with contents and optional config.
    Ensures contents is never empty (Gemini requires "contents are required").
    Config: system_instruction, temperature, max_output_tokens, tools, response_mime_type.
    See: https://googleapis.github.io/python-genai/
    """
    contents = []
    system_instruction: Optional[str] = None

    if messages:
        for msg in messages:
            role = msg.get("role", "user")
            content = (msg.get("content") or "").strip()
            if not content:
                continue
            if role == "system":
                system_instruction = content
                continue
            if role == "assistant":
                role = "model"
            contents.append({"role": role, "parts": [{"text": content}]})
    if prompt and (prompt := (prompt or "").strip()):
        if not contents:
            contents.append({"role": "user", "parts": [{"text": prompt}]})
        elif contents[-1].get("role") == "user":
            # Append to last user message
            last = contents[-1]
            last["parts"] = [{"text": (last["parts"][0].get("text") or "") + "\n" + prompt}]
        else:
            contents.append({"role": "user", "parts": [{"text": prompt}]})
    if system_prompt and (system_prompt := (system_prompt or "").strip()):
        system_instruction = system_prompt

    if not contents:
        contents = [{"role": "user", "parts": [{"text": "Hello"}]}]

    request: Dict[str, Any] = {
        "model": f"models/{model_name}" if not model_name.startswith("models/") else model_name,
        "contents": contents,
    }
    config: Dict[str, Any] = {}
    if system_instruction:
        config["system_instruction"] = system_instruction
    config["temperature"] = max(0.0, min(2.0, temperature))  # Gemini allows 0-2
    if max_tokens is not None and max_tokens > 0:
        config["max_output_tokens"] = max_tokens
    if tools:
        config["tools"] = tools
        # Wire tool_choice to Gemini function_calling_config (AUTO/ANY/NONE)
        # Per https://ai.google.dev/gemini-api/docs/function-calling#function_calling_modes
        if tool_choice is not None:
            fc_config: Dict[str, Any] = {}
            if tool_choice == "none" or (isinstance(tool_choice, str) and tool_choice.lower() == "none"):
                fc_config["mode"] = "NONE"
            elif (
                tool_choice == "required"
                or tool_choice == "any"
                or (isinstance(tool_choice, str) and tool_choice.lower() in ("required", "any"))
            ):
                fc_config["mode"] = "ANY"
            elif isinstance(tool_choice, dict):
                if tool_choice.get("type") == "function":
                    fn = tool_choice.get("function", {})
                    fn_name = fn.get("name") if isinstance(fn, dict) else None
                    if fn_name:
                        fc_config["mode"] = "ANY"
                        fc_config["allowed_function_names"] = [fn_name]
            # "auto" or None: Gemini default AUTO, no config needed
            if fc_config:
                config["tool_config"] = {"function_calling_config": fc_config}
    if response_format:
        # Map OpenAI-style response_format to Gemini config
        fmt_type = response_format.get("type") if isinstance(response_format, dict) else None
        if fmt_type == "json_object":
            config["response_mime_type"] = "application/json"
        elif fmt_type == "json_schema" and "json_schema" in response_format:
            config["response_mime_type"] = "application/json"
            config["response_schema"] = response_format["json_schema"]
    if config:
        request["config"] = config
    return request


class GeminiLLMProvider(BaseLLMProvider):
    """
    Google Gemini LLM provider.

    Uses the new Google Generative AI SDK (from google import genai).
    Supports streaming, function calling, structured outputs, and multi-modal inputs.
    """

    MAX_INPUT_TOKENS = 1000000  # 1M token context
    MAX_OUTPUT_TOKENS = 8192
    SUPPORTED_FEATURES = ["streaming", "function_calling", "structured_outputs", "multimodal"]

    def __init__(self, config: GeminiConfig):
        """
        Initialize Gemini provider.

        Args:
            config: Gemini configuration
        """
        super().__init__()
        self.config = config
        self._client: Optional[Any] = None

    def is_available(self) -> bool:
        """Check if provider is available and configured."""
        if genai is None:
            return False

        if not self.config.api_key:
            return False

        return True

    def get_provider_name(self) -> str:
        """Get provider name."""
        return "gemini"

    def _estimate_output_tokens(self, text: str) -> int:
        """
        Estimate output tokens for Gemini.

        Gemini API doesn't provide token counts in streaming responses.
        Uses character-based estimation (more accurate than word count for code/multilingual).

        Args:
            text: Text to estimate tokens for

        Returns:
            Estimated token count

        Note:
            Gemini uses SentencePiece tokenization. This is an approximation.
            For exact counts, use non-streaming API which returns usage stats.
        """
        # Character-based estimation: ~4 characters per token (more accurate for code/multilingual)
        # This is better than word count for non-English and code
        char_count = len(text)
        return int(char_count / 4.0)

    async def _load_model_impl(self) -> None:
        """Initialize Gemini client."""
        if not self.is_available():
            raise ProviderUnavailableError(
                "Gemini provider not available (missing API key or SDK)",
                provider="gemini",
            )

        try:
            # Initialize Gemini client (SDK controls API version).
            api_key = self.config.api_key
            if api_key:
                masked_key = f"{api_key[:10]}...{api_key[-10:]}" if len(api_key) > 20 else "***"
                logger.info(f"Gemini client initialized with API key: {masked_key}")
            self._client = genai.Client(api_key=api_key)
            logger.info("Gemini client initialized")
        except Exception as e:
            raise ProviderUnavailableError(
                f"Failed to initialize Gemini client: {str(e)}",
                provider="gemini",
            ) from e

    async def _shutdown_impl(self) -> None:
        """Cleanup Gemini client."""
        try:
            # Close Gemini client's HTTP session if it exists
            if hasattr(self, "_client") and self._client is not None:
                # google-genai Client may have an underlying HTTP client
                if hasattr(self._client, "_client") and hasattr(self._client._client, "close"):
                    await self._client._client.close()
                elif hasattr(self._client, "close"):
                    await self._client.close()
        except Exception as e:
            logger.warning(f"Error closing Gemini client: {e}")

        self._client = None

    async def generate(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        stream: bool = False,
        correlation_id: Optional[str] = None,
    ) -> Union[LLMResult, AsyncIterator[LLMResult]]:
        """
        Generate text completion using Gemini.

        Args:
            prompt: User prompt (if messages not provided)
            system_prompt: System instruction
            messages: Conversation history
            temperature: Sampling temperature (0-2)
            max_tokens: Maximum tokens to generate
            tools: Function calling tools
            tool_choice: Tool choice strategy
            response_format: Structured output format (JSON schema)
            stream: Whether to stream response
            correlation_id: Request correlation ID

        Returns:
            LLMResult or AsyncIterator[LLMResult] if streaming

        Raises:
            GenerationError: If generation fails
            RateLimitError: If rate limit exceeded
            AuthenticationError: If API key invalid
        """
        if not self._is_loaded:
            await self.load_model()

        if stream:
            return self.generate_streaming(
                prompt=prompt,
                system_prompt=system_prompt,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                tools=tools,
                tool_choice=tool_choice,
                response_format=response_format,
                correlation_id=correlation_id,
            )

        start_time = time.time()

        # Convert tools to Gemini format if provided
        gemini_tools = self._convert_tools_to_gemini_format(tools) if tools else None

        # Build request with contents (never empty) and optional config
        request = _format_request_for_gemini(
            prompt,
            messages,
            system_prompt,
            self.config.default_model,
            temperature=temperature,
            max_tokens=max_tokens or self.config.max_tokens,
            tools=gemini_tools,
            tool_choice=tool_choice,
            response_format=response_format,
        )

        # Retry logic with exponential backoff
        last_error = None
        for attempt in range(self.config.retry_attempts):
            try:
                # Wrap API call with timeout
                response = await asyncio.wait_for(
                    asyncio.to_thread(
                        self._client.models.generate_content,
                        **request,
                    ),
                    timeout=self.config.timeout,
                )

                processing_time = time.time() - start_time

                # Extract text
                text = ""
                if hasattr(response, "text") and response.text:
                    text = response.text
                elif hasattr(response, "candidates") and response.candidates:
                    candidate = response.candidates[0]
                    if hasattr(candidate, "content") and hasattr(candidate.content, "parts"):
                        text_parts = [
                            part.text for part in candidate.content.parts if hasattr(part, "text") and part.text
                        ]
                        text = "".join(text_parts)

                # Extract finish reason
                finish_reason = FinishReason.STOP.value
                raw_finish_reason = None
                if hasattr(response, "candidates") and response.candidates:
                    candidate = response.candidates[0]
                    if hasattr(candidate, "finish_reason"):
                        raw_finish_reason = getattr(candidate, "finish_reason", None)
                        finish_reason = self._map_finish_reason(raw_finish_reason)

                # Explicit safety block handling (per Gemini API docs: finish_reason=SAFETY/RECITATION)
                if raw_finish_reason in ("SAFETY", "RECITATION", "BLOCKED") and not (text or "").strip():
                    raise ContentFilterError(
                        f"Gemini blocked response (finish_reason={raw_finish_reason})",
                        provider="gemini",
                        correlation_id=correlation_id,
                    )

                # Extract token usage
                input_tokens = 0
                output_tokens = 0
                if hasattr(response, "usage_metadata"):
                    input_tokens = getattr(response.usage_metadata, "prompt_token_count", 0)
                    output_tokens = getattr(response.usage_metadata, "candidates_token_count", 0)

                # Extract tool calls
                tool_calls = None
                if hasattr(response, "candidates") and response.candidates:
                    candidate = response.candidates[0]
                    if hasattr(candidate, "content") and hasattr(candidate.content, "parts"):
                        function_calls = []
                        for part in candidate.content.parts:
                            if hasattr(part, "function_call"):
                                function_calls.append(
                                    {
                                        "name": getattr(part.function_call, "name", ""),
                                        "arguments": getattr(part.function_call, "args", {}),
                                    }
                                )
                        if function_calls:
                            tool_calls = function_calls

                # Calculate cost (Gemini pricing: $0.075 per 1M input tokens, $0.30 per 1M output tokens)
                cost = (input_tokens / 1_000_000 * 0.075) + (output_tokens / 1_000_000 * 0.30)

                return LLMResult(
                    text=text,
                    finish_reason=finish_reason,
                    provider="gemini",
                    model=self.config.default_model,
                    processing_time=processing_time,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=input_tokens + output_tokens,
                    tool_calls=tool_calls,
                    is_partial=False,
                    is_final=True,
                    metadata={
                        "correlation_id": correlation_id,
                        "cost": cost,
                    },
                    correlation_id=correlation_id,
                )

            except asyncio.TimeoutError as e:
                processing_time = time.time() - start_time
                last_error = LLMTimeoutError(
                    f"Request timed out after {self.config.timeout}s",
                    provider="gemini",
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e
            except (AuthenticationError, InvalidInputError, ContentFilterError):
                raise
            except RateLimitError as e:
                last_error = e
            except Exception as e:
                processing_time = time.time() - start_time
                last_error = self._handle_error(e, correlation_id)

                if not is_retriable_error(last_error):
                    raise last_error

            if attempt < self.config.retry_attempts - 1 and last_error and is_retriable_error(last_error):
                wait_time = self._get_retry_wait_time(last_error, attempt, self.config.retry_backoff)
                logger.warning(
                    f"Retrying Gemini LLM request (attempt {attempt + 1}/{self.config.retry_attempts}): {str(last_error)}",
                    extra={
                        "correlation_id": correlation_id,
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                        "error": str(last_error),
                    },
                )
                await asyncio.sleep(wait_time)

        # All retries exhausted
        if last_error:
            raise last_error

        raise GenerationError(
            "Generation failed after all retries",
            provider="gemini",
            correlation_id=correlation_id,
        )

    async def generate_streaming(
        self,
        prompt: Optional[str] = None,
        system_prompt: Optional[str] = None,
        messages: Optional[List[Dict[str, str]]] = None,
        temperature: float = 0.7,
        max_tokens: Optional[int] = None,
        tools: Optional[List[Dict]] = None,
        tool_choice: Optional[Union[str, Dict]] = None,
        response_format: Optional[Dict] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[LLMResult]:
        """
        Stream text completion with incremental results.

        Yields:
            LLMResult objects with is_partial=True for interim results
        """
        if not self._is_loaded:
            await self.load_model()

        start_time = time.time()
        accumulated_text = ""

        # Convert tools to Gemini format if provided
        gemini_tools = self._convert_tools_to_gemini_format(tools) if tools else None

        # Build request with contents (never empty) and optional config
        request = _format_request_for_gemini(
            prompt,
            messages,
            system_prompt,
            self.config.default_model,
            temperature=temperature,
            max_tokens=max_tokens or self.config.max_tokens,
            tools=gemini_tools,
            tool_choice=tool_choice,
            response_format=response_format,
        )

        # Use Gemini count_tokens API for accurate input token count (per ai.google.dev/api/tokens)
        # Note: config (system_instruction, tools) excluded due to known SDK/API issues (400 on config)
        # Falls back to estimate_input_tokens if count_tokens fails or is unavailable
        try:
            count_resp = await asyncio.wait_for(
                asyncio.to_thread(
                    self._client.models.count_tokens,
                    model=request["model"],
                    contents=request["contents"],
                ),
                timeout=10.0,
            )
            input_tokens = getattr(count_resp, "total_tokens", None) or getattr(count_resp, "totalTokens", 0)
            if input_tokens is None or (isinstance(input_tokens, (int, float)) and input_tokens < 0):
                input_tokens = estimate_input_tokens(prompt=prompt, system_prompt=system_prompt, messages=messages)
        except Exception as count_err:
            logger.debug(
                "Gemini count_tokens failed, using estimate: %s",
                count_err,
                extra={"correlation_id": correlation_id},
            )
            input_tokens = estimate_input_tokens(prompt=prompt, system_prompt=system_prompt, messages=messages)

        # Retry logic with exponential backoff
        last_error = None

        for attempt in range(self.config.retry_attempts):
            try:
                # Wrap synchronous stream creation with timeout
                def create_stream():
                    return self._client.models.generate_content_stream(**request)

                # Create stream with timeout
                stream = await asyncio.wait_for(
                    asyncio.to_thread(create_stream),
                    timeout=self.config.timeout,
                )

                # Stream chunks with timeout monitoring
                chunk_timeout = self.config.timeout
                last_chunk_time = start_time

                try:
                    # Convert synchronous iterator to async with timeout protection
                    # Add per-chunk timeout to prevent hanging
                    chunk_read_timeout = 30.0  # Max 30 seconds between chunks
                    last_chunk_time = start_time
                    last_chunk = None  # Track for safety block check

                    async def iterate_stream():
                        nonlocal last_chunk_time
                        for chunk in stream:
                            # Check per-chunk timeout
                            now = time.time()
                            if now - last_chunk_time > chunk_read_timeout:
                                logger.warning(
                                    "Chunk read timeout exceeded",
                                    extra={
                                        "correlation_id": correlation_id,
                                        "time_since_last_chunk": now - last_chunk_time,
                                    },
                                )
                                break
                            last_chunk_time = now
                            yield chunk

                    async for chunk in iterate_stream():
                        last_chunk = chunk
                        # Check if we've exceeded overall timeout
                        elapsed = time.time() - start_time
                        if elapsed > chunk_timeout:
                            logger.warning(
                                "Streaming timeout exceeded",
                                extra={"correlation_id": correlation_id, "elapsed": elapsed},
                            )
                            break

                        chunk_text = ""

                        if hasattr(chunk, "text") and chunk.text:
                            chunk_text = chunk.text
                        elif hasattr(chunk, "candidates") and chunk.candidates:
                            candidate = chunk.candidates[0]
                            if hasattr(candidate, "content") and hasattr(candidate.content, "parts"):
                                text_parts = [
                                    part.text for part in candidate.content.parts if hasattr(part, "text") and part.text
                                ]
                                chunk_text = "".join(text_parts)

                        if chunk_text:
                            accumulated_text += chunk_text
                            last_chunk_time = time.time()

                            processing_time = time.time() - start_time

                            # Estimate output tokens incrementally using character-based method
                            output_tokens_est = self._estimate_output_tokens(accumulated_text)

                            yield LLMResult(
                                # IMPORTANT: emit delta text for streaming consumers (e.g., LiveKit)
                                text=chunk_text,
                                finish_reason=FinishReason.STOP.value,
                                provider="gemini",
                                model=self.config.default_model,
                                processing_time=processing_time,
                                input_tokens=input_tokens,
                                output_tokens=int(output_tokens_est),
                                total_tokens=input_tokens + int(output_tokens_est),
                                is_partial=True,
                                is_final=False,
                                metadata={"correlation_id": correlation_id},
                                correlation_id=correlation_id,
                            )
                except Exception as stream_error:
                    # Handle mid-stream errors
                    err_str = str(stream_error).lower()
                    is_quota = "429" in err_str or "quota" in err_str or "resource_exhausted" in err_str
                    if is_quota:
                        logger.warning(
                            "Gemini quota exceeded during streaming (user gets fallback message)",
                            extra={"correlation_id": correlation_id, "error": str(stream_error)[:200]},
                        )
                    else:
                        logger.error(
                            "Error during streaming",
                            extra={"correlation_id": correlation_id, "error": str(stream_error)},
                            exc_info=True,
                        )
                    # Yield a final error result and stop (don't pretend we finished cleanly)
                    processing_time = time.time() - start_time
                    output_tokens = self._estimate_output_tokens(accumulated_text)
                    cost = (input_tokens / 1_000_000 * 0.075) + (int(output_tokens) / 1_000_000 * 0.30)

                    yield LLMResult(
                        text=accumulated_text,
                        finish_reason=FinishReason.ERROR.value,
                        provider="gemini",
                        model=self.config.default_model,
                        processing_time=processing_time,
                        input_tokens=input_tokens,
                        output_tokens=int(output_tokens),
                        total_tokens=input_tokens + int(output_tokens),
                        is_partial=False,
                        is_final=True,
                        metadata={
                            "correlation_id": correlation_id,
                            "cost": cost,
                            "error": str(stream_error),
                        },
                        correlation_id=correlation_id,
                    )
                    return

                # Safety block check: if last chunk had SAFETY/RECITATION and no text, raise
                if last_chunk and not (accumulated_text or "").strip():
                    raw_reason = None
                    if hasattr(last_chunk, "candidates") and last_chunk.candidates:
                        c = last_chunk.candidates[0]
                        raw_reason = getattr(c, "finish_reason", None)
                    if raw_reason in ("SAFETY", "RECITATION", "BLOCKED"):
                        raise ContentFilterError(
                            f"Gemini blocked response during streaming (finish_reason={raw_reason})",
                            provider="gemini",
                            correlation_id=correlation_id,
                        )

                # Final result: use usage_metadata from final chunk when available (per Gemini streaming API)
                # Most chunks have empty usage_metadata; only the final chunk has full token stats
                processing_time = time.time() - start_time
                final_input_tokens = input_tokens
                final_output_tokens = self._estimate_output_tokens(accumulated_text)
                if last_chunk and hasattr(last_chunk, "usage_metadata") and last_chunk.usage_metadata:
                    um = last_chunk.usage_metadata
                    pt = getattr(um, "prompt_token_count", None) or getattr(um, "promptTokenCount", 0)
                    ct = getattr(um, "candidates_token_count", None) or getattr(um, "candidatesTokenCount", 0)
                    if pt is not None and ct is not None and (pt > 0 or ct > 0):
                        final_input_tokens = int(pt)
                        final_output_tokens = int(ct)

                # Calculate cost (Gemini pricing: $0.075 per 1M input tokens, $0.30 per 1M output tokens)
                cost = (final_input_tokens / 1_000_000 * 0.075) + (final_output_tokens / 1_000_000 * 0.30)

                yield LLMResult(
                    text=accumulated_text,
                    finish_reason=FinishReason.STOP.value,
                    provider="gemini",
                    model=self.config.default_model,
                    processing_time=processing_time,
                    input_tokens=final_input_tokens,
                    output_tokens=final_output_tokens,
                    total_tokens=final_input_tokens + final_output_tokens,
                    is_partial=False,
                    is_final=True,
                    metadata={
                        "correlation_id": correlation_id,
                        "cost": cost,
                    },
                    correlation_id=correlation_id,
                )

                # Success - break retry loop
                return

            except asyncio.TimeoutError as e:
                processing_time = time.time() - start_time
                last_error = LLMTimeoutError(
                    f"Request timed out after {self.config.timeout}s",
                    provider="gemini",
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e
            except (AuthenticationError, InvalidInputError, ContentFilterError):
                raise
            except RateLimitError as e:
                last_error = e
            except Exception as e:
                processing_time = time.time() - start_time
                last_error = self._handle_error(e, correlation_id)

                if not is_retriable_error(last_error):
                    raise last_error

            if attempt < self.config.retry_attempts - 1 and last_error and is_retriable_error(last_error):
                wait_time = self._get_retry_wait_time(last_error, attempt, self.config.retry_backoff)
                logger.warning(
                    "Retrying Gemini streaming request",
                    extra={
                        "correlation_id": correlation_id,
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                        "error": str(last_error),
                    },
                )
                await asyncio.sleep(wait_time)

        # All retries exhausted
        if last_error:
            raise last_error

        raise GenerationError(
            "Streaming failed after all retries",
            provider="gemini",
            correlation_id=correlation_id,
        )

    def _build_contents(self, prompt: Optional[str], messages: Optional[List[Dict[str, str]]]) -> Union[str, List]:
        """
        Build contents for Gemini API.

        Args:
            prompt: User prompt
            messages: Conversation messages

        Returns:
            Contents as string or list of parts
        """
        if messages:
            # Convert messages to Gemini format
            parts = []
            for msg in messages:
                role = msg.get("role", "user")
                content = msg.get("content", "")

                if role == "system":
                    # System messages are handled separately
                    continue
                elif role == "user":
                    parts.append({"role": "user", "parts": [{"text": content}]})
                elif role == "assistant":
                    parts.append({"role": "model", "parts": [{"text": content}]})

            return parts
        elif prompt:
            return prompt
        else:
            return ""

    def _convert_tools_to_gemini_format(self, tools: List[Dict]) -> Optional[List[Dict]]:
        """
        Convert OpenAI-style tools to Gemini format.

        Args:
            tools: Tools in standard format (type: function, function: {name, description, parameters})

        Returns:
            List of Gemini Tool dicts, or None if empty
        """
        declarations = []
        for tool in tools:
            if tool.get("type") == "function":
                func = tool.get("function", {})
                declarations.append(
                    {
                        "name": func.get("name", ""),
                        "description": func.get("description", ""),
                        "parameters": func.get("parameters", {}),
                    }
                )
        if not declarations:
            return None
        return [{"function_declarations": declarations}]

    def _map_finish_reason(self, gemini_reason: str) -> str:
        """Map Gemini finish reason to standard format."""
        mapping = {
            "STOP": FinishReason.STOP.value,
            "MAX_TOKENS": FinishReason.LENGTH.value,
            "SAFETY": FinishReason.CONTENT_FILTER.value,
            "RECITATION": FinishReason.CONTENT_FILTER.value,
            "OTHER": FinishReason.ERROR.value,
        }
        return mapping.get(gemini_reason, FinishReason.STOP.value)

    def _handle_error(self, error: Exception, correlation_id: Optional[str]) -> LLMError:
        """
        Handle and classify errors from Gemini API using provider-specific error mapper.

        Args:
            error: Exception from API
            correlation_id: Request correlation ID

        Returns:
            Appropriate LLMError subclass with rich error details
        """
        # Network/connection errors (check before provider-specific parsing)
        if isinstance(error, (ConnectionError, OSError)):
            return LLMNetworkError(
                f"Gemini network error: {error}",
                provider="gemini",
                correlation_id=correlation_id,
            )
        try:
            import httpx

            if isinstance(error, httpx.TimeoutException):
                return LLMTimeoutError(
                    f"Gemini request timed out: {error}",
                    provider="gemini",
                    correlation_id=correlation_id,
                )
            if isinstance(error, httpx.NetworkError):
                return LLMNetworkError(
                    f"Gemini network error: {error}",
                    provider="gemini",
                    correlation_id=correlation_id,
                )
        except ImportError:
            pass

        # Use provider-specific error mapper for rich error details
        mapped_error, error_details = parse_provider_error(error, "gemini", correlation_id)

        # Log error details for observability
        logger.debug(
            "Gemini error mapped",
            extra={
                "correlation_id": correlation_id,
                "error_type": type(error).__name__,
                "mapped_type": type(mapped_error).__name__,
                "error_details": error_details,
            },
        )

        return mapped_error

    def _calculate_backoff_with_jitter(self, attempt: int, base_delay: float = 1.0) -> float:
        """
        Calculate exponential backoff with jitter.

        Uses "full jitter" strategy to prevent thundering herd.

        Args:
            attempt: Current attempt number (0-indexed)
            base_delay: Base delay in seconds

        Returns:
            Delay in seconds with jitter applied
        """
        import random

        cap = 30.0  # Maximum delay cap
        exponential_delay = min(cap, base_delay * (2**attempt))
        return random.uniform(0, exponential_delay)

    def _get_retry_wait_time(self, error: Optional[Exception], attempt: int, base_delay: float = 1.0) -> float:
        """Get wait time for retry; respect Retry-After for RateLimitError, else backoff with jitter."""
        import random

        if error is not None and isinstance(error, RateLimitError) and getattr(error, "retry_after", None) is not None:
            delay = float(error.retry_after)
            jitter = delay * 0.25 * (2 * random.random() - 1)
            return max(0.5, min(300.0, delay + jitter))
        return self._calculate_backoff_with_jitter(attempt, base_delay)
