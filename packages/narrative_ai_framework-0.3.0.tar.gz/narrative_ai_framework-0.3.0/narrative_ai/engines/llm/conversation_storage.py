"""
LLM Conversation Storage Backends.

Provides Redis and PostgreSQL backends for conversation persistence.
Follows the same pattern as voice_mode/conversation.py for consistency.

Storage: In-memory by default. For production:
- Set REDIS_URL for Redis (requires redis package)
- Set LLM_CONVERSATION_DATABASE_URL or DATABASE_URL (postgresql://) for PostgreSQL
  (requires psycopg2 or asyncpg; uses SQLAlchemy)
"""

from __future__ import annotations

import json
import logging
import os
import time
import uuid
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, List

from .conversation_manager import ConversationSession

logger = logging.getLogger(__name__)


class ConversationStorageInterface(ABC):
    """Abstract interface for conversation storage. Implement for Redis/DB in production."""

    @abstractmethod
    def get(self, session_id: str) -> Optional[ConversationSession]:
        """Get session by session_id, or None if not found."""
        ...

    @abstractmethod
    def save(self, session: ConversationSession) -> None:
        """Save or update session."""
        ...

    @abstractmethod
    def delete(self, session_id: str) -> None:
        """Delete session."""
        ...

    @abstractmethod
    def exists(self, session_id: str) -> bool:
        """Check if session exists."""
        ...

    def search(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        min_messages: Optional[int] = None,
        max_messages: Optional[int] = None,
        created_after: Optional[float] = None,
        created_before: Optional[float] = None,
        limit: int = 100,
    ) -> List[ConversationSession]:
        """
        Search sessions by criteria.

        Args:
            user_id: Filter by user ID
            tenant_id: Filter by tenant ID
            min_messages: Minimum message count
            max_messages: Maximum message count
            created_after: Filter sessions created after timestamp
            created_before: Filter sessions created before timestamp
            limit: Maximum number of results

        Returns:
            List of matching sessions
        """
        # Default implementation: scan all sessions (inefficient for large datasets)
        # Subclasses should override for efficient implementation
        return []

    def bulk_delete(self, session_ids: List[str]) -> int:
        """
        Delete multiple sessions.

        Args:
            session_ids: List of session IDs to delete

        Returns:
            Number of sessions deleted
        """
        count = 0
        for session_id in session_ids:
            try:
                self.delete(session_id)
                count += 1
            except Exception as e:
                logger.warning(f"Failed to delete session {session_id}: {e}")
        return count

    def get_statistics(self) -> Dict[str, Any]:
        """
        Get storage statistics.

        Returns:
            Dictionary with statistics (session_count, total_messages, etc.)
        """
        return {
            "session_count": 0,
            "total_messages": 0,
            "storage_type": type(self).__name__,
        }


class InMemoryConversationStorage(ConversationStorageInterface):
    """In-memory storage (default). Sessions lost on restart."""

    def __init__(self) -> None:
        self._sessions: Dict[str, ConversationSession] = {}

    def get(self, session_id: str) -> Optional[ConversationSession]:
        return self._sessions.get(session_id)

    def save(self, session: ConversationSession) -> None:
        self._sessions[session.session_id] = session

    def delete(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)

    def exists(self, session_id: str) -> bool:
        return session_id in self._sessions

    def search(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        min_messages: Optional[int] = None,
        max_messages: Optional[int] = None,
        created_after: Optional[float] = None,
        created_before: Optional[float] = None,
        limit: int = 100,
    ) -> List[ConversationSession]:
        """Search sessions in memory."""
        results = []
        for session in self._sessions.values():
            # Apply filters
            if user_id and session.user_id != user_id:
                continue
            if tenant_id and session.tenant_id != tenant_id:
                continue
            if min_messages is not None and len(session.messages) < min_messages:
                continue
            if max_messages is not None and len(session.messages) > max_messages:
                continue
            if created_after is not None and session.created_at < created_after:
                continue
            if created_before is not None and session.created_at > created_before:
                continue

            results.append(session)
            if len(results) >= limit:
                break

        return results

    def get_statistics(self) -> Dict[str, Any]:
        """Get statistics for in-memory storage."""
        total_messages = sum(len(s.messages) for s in self._sessions.values())
        return {
            "session_count": len(self._sessions),
            "total_messages": total_messages,
            "storage_type": "InMemoryConversationStorage",
        }


def _session_to_dict(session: ConversationSession) -> dict:
    """Serialize session for Redis/PostgreSQL."""
    return {
        "session_id": session.session_id,
        "user_id": session.user_id,
        "tenant_id": session.tenant_id,
        "messages": session.messages,
        "created_at": session.created_at,
        "updated_at": session.updated_at,
        "metadata": session.metadata,
    }


def _dict_to_session(data: dict) -> ConversationSession:
    """Deserialize session from Redis/PostgreSQL."""
    return ConversationSession(
        session_id=data["session_id"],
        user_id=data.get("user_id"),
        tenant_id=data.get("tenant_id"),
        messages=data.get("messages", []),
        created_at=data.get("created_at", time.time()),
        updated_at=data.get("updated_at", time.time()),
        metadata=data.get("metadata", {}),
    )


class RedisConversationStorage(ConversationStorageInterface):
    """Redis-backed storage for production multi-worker deployments. Requires redis package."""

    _PREFIX = "llm:conv:"
    _TTL_SECONDS = 86400  # 24 hours

    def __init__(self, redis_url: str) -> None:
        try:
            import redis
        except ImportError:
            raise ImportError("Redis storage requires 'redis' package. Install with: pip install redis")
        self._client = redis.from_url(redis_url, decode_responses=True)
        # Verify connection immediately
        self._client.ping()

    def _key(self, session_id: str) -> str:
        return f"{self._PREFIX}{session_id}"

    def get(self, session_id: str) -> Optional[ConversationSession]:
        data = self._client.get(self._key(session_id))
        if not data:
            return None
        try:
            return _dict_to_session(json.loads(data))
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning("Redis conversation session corrupt for %s: %s", session_id, e)
            return None

    def save(self, session: ConversationSession) -> None:
        """Save session to Redis with TTL."""
        self._client.setex(
            self._key(session.session_id),
            self._TTL_SECONDS,
            json.dumps(_session_to_dict(session)),
        )

    def delete(self, session_id: str) -> None:
        self._client.delete(self._key(session_id))

    def exists(self, session_id: str) -> bool:
        return self._client.exists(self._key(session_id)) > 0

    def search(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        min_messages: Optional[int] = None,
        max_messages: Optional[int] = None,
        created_after: Optional[float] = None,
        created_before: Optional[float] = None,
        limit: int = 100,
    ) -> List[ConversationSession]:
        """Search sessions in Redis (scans all keys - use with caution)."""
        results = []
        pattern = f"{self._PREFIX}*"

        # Scan keys (efficient for large datasets)
        cursor = 0
        scanned = 0
        while scanned < limit * 10:  # Scan up to 10x limit to find matches
            cursor, keys = self._client.scan(cursor, match=pattern, count=100)
            for key in keys:
                session = self.get(key.replace(self._PREFIX, ""))
                if not session:
                    continue

                # Apply filters
                if user_id and session.user_id != user_id:
                    continue
                if tenant_id and session.tenant_id != tenant_id:
                    continue
                if min_messages is not None and len(session.messages) < min_messages:
                    continue
                if max_messages is not None and len(session.messages) > max_messages:
                    continue
                if created_after is not None and session.created_at < created_after:
                    continue
                if created_before is not None and session.created_at > created_before:
                    continue

                results.append(session)
                if len(results) >= limit:
                    return results

            scanned += len(keys)
            if cursor == 0:
                break

        return results

    def get_statistics(self) -> Dict[str, Any]:
        """Get statistics for Redis storage."""
        pattern = f"{self._PREFIX}*"
        count = 0
        total_messages = 0

        cursor = 0
        while True:
            cursor, keys = self._client.scan(cursor, match=pattern, count=100)
            for key in keys:
                session = self.get(key.replace(self._PREFIX, ""))
                if session:
                    count += 1
                    total_messages += len(session.messages)
            if cursor == 0:
                break

        return {
            "session_count": count,
            "total_messages": total_messages,
            "storage_type": "RedisConversationStorage",
        }


class PostgresConversationStorage(ConversationStorageInterface):
    """PostgreSQL-backed storage. Uses SQLAlchemy + psycopg2. Requires table llm_conversation_session."""

    _TTL_SECONDS = 86400

    def __init__(self, database_url: str) -> None:
        try:
            from sqlalchemy import create_engine
        except ImportError:
            raise ImportError("PostgreSQL storage requires 'sqlalchemy' package. Install with: pip install sqlalchemy")
        self._engine = create_engine(database_url, pool_pre_ping=True)
        self._ensure_table()

    def _ensure_table(self) -> None:
        """Create table if it doesn't exist."""
        from sqlalchemy import text

        with self._engine.connect() as conn:
            conn.execute(
                text("""
                    CREATE TABLE IF NOT EXISTS llm_conversation_session (
                        session_id VARCHAR(512) PRIMARY KEY,
                        data JSONB NOT NULL,
                        expires_at TIMESTAMP WITH TIME ZONE
                    )
                """)
            )
            conn.commit()

    def get(self, session_id: str) -> Optional[ConversationSession]:
        from sqlalchemy import text

        with self._engine.connect() as conn:
            row = conn.execute(
                text(
                    "SELECT data FROM llm_conversation_session WHERE session_id = :sid AND (expires_at IS NULL OR expires_at > NOW())"
                ),
                {"sid": session_id},
            ).fetchone()
        if not row:
            return None
        try:
            return _dict_to_session(json.loads(row[0]))
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning("Postgres conversation session corrupt for %s: %s", session_id, e)
            return None

    def save(self, session: ConversationSession) -> None:
        """Save session to PostgreSQL with TTL."""
        from datetime import datetime, timezone, timedelta
        from sqlalchemy import text

        data = json.dumps(_session_to_dict(session))
        expires = datetime.now(timezone.utc) + timedelta(seconds=self._TTL_SECONDS)
        with self._engine.connect() as conn:
            conn.execute(
                text("""
                    INSERT INTO llm_conversation_session (session_id, data, expires_at)
                    VALUES (:sid, CAST(:data AS jsonb), :exp)
                    ON CONFLICT (session_id) DO UPDATE SET data = CAST(:data AS jsonb), expires_at = :exp
                """),
                {"sid": session.session_id, "data": data, "exp": expires},
            )
            conn.commit()

    def delete(self, session_id: str) -> None:
        from sqlalchemy import text

        with self._engine.connect() as conn:
            conn.execute(
                text("DELETE FROM llm_conversation_session WHERE session_id = :sid"),
                {"sid": session_id},
            )
            conn.commit()

    def exists(self, session_id: str) -> bool:
        from sqlalchemy import text

        with self._engine.connect() as conn:
            row = conn.execute(
                text(
                    "SELECT 1 FROM llm_conversation_session WHERE session_id = :sid AND (expires_at IS NULL OR expires_at > NOW())"
                ),
                {"sid": session_id},
            ).fetchone()
            return row is not None

    def search(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        min_messages: Optional[int] = None,
        max_messages: Optional[int] = None,
        created_after: Optional[float] = None,
        created_before: Optional[float] = None,
        limit: int = 100,
    ) -> List[ConversationSession]:
        """Search sessions in PostgreSQL."""
        from sqlalchemy import text

        query = "SELECT data FROM llm_conversation_session WHERE (expires_at IS NULL OR expires_at > NOW())"
        params = {}

        if user_id:
            query += " AND CAST(data->>'user_id' AS TEXT) = :user_id"
            params["user_id"] = user_id
        if tenant_id:
            query += " AND CAST(data->>'tenant_id' AS TEXT) = :tenant_id"
            params["tenant_id"] = tenant_id
        if created_after:
            query += " AND CAST(data->>'created_at' AS FLOAT) >= :created_after"
            params["created_after"] = created_after
        if created_before:
            query += " AND CAST(data->>'created_at' AS FLOAT) <= :created_before"
            params["created_before"] = created_before

        query += " LIMIT :limit"
        params["limit"] = limit

        results = []
        with self._engine.connect() as conn:
            rows = conn.execute(text(query), params).fetchall()
            for row in rows:
                try:
                    session = _dict_to_session(json.loads(row[0]))
                    # Apply message count filters (can't do in SQL easily)
                    if min_messages is not None and len(session.messages) < min_messages:
                        continue
                    if max_messages is not None and len(session.messages) > max_messages:
                        continue
                    results.append(session)
                except (json.JSONDecodeError, KeyError):
                    continue

        return results

    def get_statistics(self) -> Dict[str, Any]:
        """Get statistics for PostgreSQL storage."""
        from sqlalchemy import text

        with self._engine.connect() as conn:
            row = conn.execute(
                text(
                    """
                    SELECT 
                        COUNT(*) as session_count,
                        SUM(jsonb_array_length(data->'messages')) as total_messages
                    FROM llm_conversation_session
                    WHERE expires_at IS NULL OR expires_at > NOW()
                    """
                )
            ).fetchone()

            return {
                "session_count": row[0] or 0,
                "total_messages": row[1] or 0,
                "storage_type": "PostgresConversationStorage",
            }


class AppDatabaseConversationStorage(ConversationStorageInterface):
    """Stores LLM conversation sessions in the shared app database using the
    normalised ``conversations`` / ``conversation_messages`` tables instead of
    the legacy ``llm_conversation_session`` table.

    This backend maps the flat :class:`ConversationSession` dataclass to the
    relational schema created by the Alembic migrations.  It uses synchronous
    SQLAlchemy (matching the existing ``PostgresConversationStorage`` pattern)
    so that it can be used without an ``asyncio`` event loop.
    """

    def __init__(self, database_url: str) -> None:
        from sqlalchemy import create_engine

        # Ensure we use the sync driver
        url = database_url.replace("postgresql+asyncpg://", "postgresql://")
        self._engine = create_engine(url, pool_pre_ping=True)

    @staticmethod
    def _normalize_conversation_uuid(session_id: str) -> str:
        """Map arbitrary session IDs (e.g. conv-abc) to a valid UUID string."""
        try:
            return str(uuid.UUID(str(session_id)))
        except (ValueError, TypeError, AttributeError):
            # Stable mapping so the same session_id always maps to the same DB UUID.
            return str(uuid.uuid5(uuid.NAMESPACE_URL, f"llm-session:{session_id}"))

    # ---- helpers ---------------------------------------------------------

    def _session_to_rows(self, session: ConversationSession) -> tuple:
        """Return (conv_dict, list_of_msg_dicts)."""
        conv_id = session.metadata.get("conversation_uuid")
        if not conv_id:
            conv_id = self._normalize_conversation_uuid(session.session_id)
        # Safely convert user_id to UUID, falling back to zero UUID
        _zero_uid = str(uuid.UUID(int=0))
        if session.user_id:
            try:
                user_id_str = str(uuid.UUID(session.user_id))
            except (ValueError, TypeError, AttributeError):
                user_id_str = _zero_uid
        else:
            user_id_str = _zero_uid
        conv = {
            "id": conv_id,
            "user_id": user_id_str,
            "title": session.metadata.get("title", ""),
            "created_at": session.created_at,
            "updated_at": session.updated_at,
        }
        msgs = []
        for idx, m in enumerate(session.messages):
            msgs.append(
                {
                    "id": str(uuid.uuid4()),
                    "conversation_id": conv_id,
                    "role": m.get("role", "user"),
                    "content": m.get("content", ""),
                    "emotion": m.get("emotion"),
                    "audio_url": m.get("audio_url"),
                    "sources_json": m.get("sources_json"),
                }
            )
        return conv, msgs

    def _rows_to_session(self, conv_row: Any, msg_rows: list) -> ConversationSession:
        msgs = [
            {
                "role": r[1],
                "content": r[2],
                "emotion": r[3],
                "audio_url": r[4],
                "sources_json": r[5],
            }
            for r in msg_rows
        ]
        return ConversationSession(
            session_id=str(conv_row[0]),  # conversation uuid
            user_id=str(conv_row[1]) if conv_row[1] else None,
            messages=msgs,
            created_at=conv_row[3].timestamp() if conv_row[3] else time.time(),
            updated_at=conv_row[4].timestamp() if conv_row[4] else time.time(),
            metadata={"conversation_uuid": str(conv_row[0]), "title": conv_row[2] or ""},
        )

    # ---- interface -------------------------------------------------------

    def get(self, session_id: str) -> Optional[ConversationSession]:
        from sqlalchemy import text

        conv_uuid = self._normalize_conversation_uuid(session_id)
        with self._engine.connect() as conn:
            conv = conn.execute(
                text(
                    "SELECT id, user_id, title, created_at, updated_at FROM conversations WHERE id = CAST(:sid AS uuid)"
                ),
                {"sid": conv_uuid},
            ).fetchone()
            if not conv:
                return None
            msgs = conn.execute(
                text(
                    """
                    SELECT id, role, content, emotion, audio_url, sources_json
                    FROM conversation_messages
                    WHERE conversation_id = CAST(:cid AS uuid)
                    ORDER BY created_at
                    """
                ),
                {"cid": conv_uuid},
            ).fetchall()
        session = self._rows_to_session(conv, msgs)
        # Preserve the external session_id expected by ConversationManager/API.
        session.session_id = session_id
        session.metadata["conversation_uuid"] = conv_uuid
        return session

    def save(self, session: ConversationSession) -> None:
        from sqlalchemy import text

        conv, _ = self._session_to_rows(session)
        # Store the conversation_uuid so subsequent saves update the same row.
        session.metadata["conversation_uuid"] = conv["id"]

        # Normalize session messages once.
        normalized_session_messages = [
            {
                "role": m.get("role", "user"),
                "content": m.get("content", ""),
                "emotion": m.get("emotion"),
                "audio_url": m.get("audio_url"),
                "sources_json": m.get("sources_json"),
            }
            for m in (session.messages or [])
        ]

        with self._engine.connect() as conn:
            # Upsert conversation row first.
            conn.execute(
                text(
                    """
                    INSERT INTO conversations (id, user_id, title, created_at, updated_at)
                    VALUES (CAST(:id AS uuid), CAST(:uid AS uuid), :title, to_timestamp(:cat), to_timestamp(:uat))
                    ON CONFLICT (id) DO UPDATE SET title = :title, updated_at = to_timestamp(:uat)
                    """
                ),
                {
                    "id": conv["id"],
                    "uid": conv["user_id"],
                    "title": conv["title"],
                    "cat": conv["created_at"],
                    "uat": conv["updated_at"],
                },
            )

            # Row-level lock serializes concurrent writers for this conversation.
            conn.execute(
                text("SELECT id FROM conversations WHERE id = CAST(:cid AS uuid) FOR UPDATE"),
                {"cid": conv["id"]},
            )

            # Load persisted messages in order.
            existing_rows = conn.execute(
                text(
                    """
                    SELECT role, content
                    FROM conversation_messages
                    WHERE conversation_id = CAST(:cid AS uuid)
                    ORDER BY created_at, id
                    """
                ),
                {"cid": conv["id"]},
            ).fetchall()
            existing_messages = [
                {
                    "role": row[0] or "user",
                    "content": row[1] or "",
                }
                for row in existing_rows
            ]

            # When ConversationManager writes a summary snapshot, we need to
            # compact persisted rows (replace old turns) instead of append-only.
            has_summary_snapshot = any(
                msg.get("role") == "system" and str(msg.get("content", "")).startswith("[CONVERSATION_SUMMARY]")
                for msg in normalized_session_messages
            )
            should_compact = has_summary_snapshot and len(normalized_session_messages) < len(existing_messages)
            if should_compact:
                conn.execute(
                    text(
                        """
                        DELETE FROM conversation_messages
                        WHERE conversation_id = CAST(:cid AS uuid)
                        """
                    ),
                    {"cid": conv["id"]},
                )
                for msg in normalized_session_messages:
                    conn.execute(
                        text(
                            """
                            INSERT INTO conversation_messages (id, conversation_id, role, content, emotion, audio_url, sources_json)
                            VALUES (
                                CAST(:id AS uuid),
                                CAST(:conversation_id AS uuid),
                                :role,
                                :content,
                                :emotion,
                                :audio_url,
                                :sources_json
                            )
                            """
                        ),
                        {
                            "id": str(uuid.uuid4()),
                            "conversation_id": conv["id"],
                            "role": msg["role"],
                            "content": msg["content"],
                            "emotion": msg.get("emotion"),
                            "audio_url": msg.get("audio_url"),
                            "sources_json": msg.get("sources_json"),
                        },
                    )
                conn.commit()
                logger.info(
                    "Conversation compacted for %s (existing=%d, compacted=%d)",
                    session.session_id,
                    len(existing_messages),
                    len(normalized_session_messages),
                )
                return

            # Compute common prefix between persisted and in-memory state.
            prefix_len = 0
            max_prefix = min(len(existing_messages), len(normalized_session_messages))
            while prefix_len < max_prefix:
                if existing_messages[prefix_len]["role"] != normalized_session_messages[prefix_len]["role"]:
                    break
                if existing_messages[prefix_len]["content"] != normalized_session_messages[prefix_len]["content"]:
                    break
                prefix_len += 1

            new_messages = normalized_session_messages[prefix_len:]
            if prefix_len < len(existing_messages):
                logger.warning(
                    "Conversation divergence detected for %s (prefix=%d, existing=%d, incoming=%d); applying guarded append",
                    session.session_id,
                    prefix_len,
                    len(existing_messages),
                    len(normalized_session_messages),
                )

                # Guard against runaway duplication when incoming snapshots diverge
                # from persisted history (e.g., summarization/compaction or races).
                # Prefer a minimal append strategy instead of re-appending the full
                # in-memory history.
                if normalized_session_messages:
                    latest_incoming = normalized_session_messages[-1]
                    already_present = any(
                        msg["role"] == latest_incoming["role"] and msg["content"] == latest_incoming["content"]
                        for msg in reversed(existing_messages)
                    )
                    if already_present:
                        # Latest turn already persisted; nothing new to append.
                        new_messages = []
                    else:
                        # Append only the newest message to keep append-only safety
                        # without duplicating thousands of historical messages.
                        new_messages = [latest_incoming]
                else:
                    new_messages = []

            # Non-destructive persistence:
            # append only messages not already represented by the common prefix.
            for msg in new_messages:
                conn.execute(
                    text(
                        """
                        INSERT INTO conversation_messages (id, conversation_id, role, content, emotion, audio_url, sources_json)
                        VALUES (
                            CAST(:id AS uuid),
                            CAST(:conversation_id AS uuid),
                            :role,
                            :content,
                            :emotion,
                            :audio_url,
                            :sources_json
                        )
                        """
                    ),
                    {
                        "id": str(uuid.uuid4()),
                        "conversation_id": conv["id"],
                        "role": msg["role"],
                        "content": msg["content"],
                        "emotion": msg.get("emotion"),
                        "audio_url": msg.get("audio_url"),
                        "sources_json": msg.get("sources_json"),
                    },
                )

            conn.commit()

    def delete(self, session_id: str) -> None:
        from sqlalchemy import text

        conv_uuid = self._normalize_conversation_uuid(session_id)
        with self._engine.connect() as conn:
            conn.execute(
                text("DELETE FROM conversations WHERE id = CAST(:sid AS uuid)"),
                {"sid": conv_uuid},
            )
            conn.commit()

    def exists(self, session_id: str) -> bool:
        from sqlalchemy import text

        conv_uuid = self._normalize_conversation_uuid(session_id)
        with self._engine.connect() as conn:
            row = conn.execute(
                text("SELECT 1 FROM conversations WHERE id = CAST(:sid AS uuid)"),
                {"sid": conv_uuid},
            ).fetchone()
        return row is not None


def get_conversation_storage() -> ConversationStorageInterface:
    """
    Return the appropriate storage backend: Redis, PostgreSQL, or in-memory.

    Auto-detects backend based on environment variables:
    - REDIS_URL: Use Redis backend (ephemeral, 24-hour TTL)
    - DATABASE_URL (postgresql://): Use the shared app database
      (normalised ``conversations`` + ``conversation_messages`` tables)
    - LLM_CONVERSATION_DATABASE_URL: Legacy -- uses the old
      ``llm_conversation_session`` table (deprecated)
    - Otherwise: Use in-memory backend

    Returns:
        ConversationStorageInterface implementation
    """
    # Try Redis first (best for ephemeral session state)
    redis_url = os.getenv("REDIS_URL", "").strip()
    if redis_url:
        try:
            return RedisConversationStorage(redis_url)
        except ImportError as e:
            logger.warning("REDIS_URL set but redis not installed (%s); trying next backend", e)
        except Exception as e:
            logger.warning("Redis connection failed (%s); trying next backend. Set REDIS_URL='' to suppress this.", e)

    # Prefer the new normalised tables via the shared DATABASE_URL
    db_url = os.getenv("DATABASE_URL", "").strip()
    if db_url and db_url.split(":")[0] in ("postgresql", "postgres", "postgresql+asyncpg"):
        try:
            return AppDatabaseConversationStorage(db_url)
        except Exception as e:
            logger.warning("App-database conversation storage failed (%s); trying legacy", e)

    # Legacy: separate LLM_CONVERSATION_DATABASE_URL with flat JSONB table
    legacy_url = os.getenv("LLM_CONVERSATION_DATABASE_URL", "").strip()
    if legacy_url and legacy_url.split(":")[0] in ("postgresql", "postgres"):
        try:
            logger.warning(
                "Using legacy llm_conversation_session table. "
                "Set DATABASE_URL to use the normalised conversations schema."
            )
            return PostgresConversationStorage(legacy_url)
        except ImportError as e:
            logger.warning(
                "PostgreSQL URL set but sqlalchemy not installed (%s); using in-memory",
                e,
            )
        except Exception as e:
            logger.warning("PostgreSQL conversation storage failed (%s); using in-memory", e)

    # Fallback to in-memory
    logger.info("Using in-memory conversation storage (sessions lost on restart)")
    return InMemoryConversationStorage()
