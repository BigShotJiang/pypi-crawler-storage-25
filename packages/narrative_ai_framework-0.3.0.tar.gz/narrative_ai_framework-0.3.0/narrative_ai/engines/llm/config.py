"""
LLM Engine Configuration.

Centralized configuration for all LLM providers, features,
and integration options.

Supports loading from:
- Environment variables (from_env)
- Dictionary (from_dict)
- providers.yml (from_providers_config)
"""

import os
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, TYPE_CHECKING, Callable
import logging

if TYPE_CHECKING:
    from config import ProvidersConfig

logger = logging.getLogger(__name__)


# =============================================================================
# Provider Configurations
# =============================================================================


@dataclass
class GeminiConfig:
    """
    Configuration for Google Gemini provider.

    Gemini offers multiple models:
    - gemini-2.5-flash: Best price-performance (1M token context)
    - gemini-2.5-pro: Advanced reasoning model
    - gemini-3-flash-preview: Fast, balanced model
    - gemini-3-pro-preview: Most intelligent model
    """

    # API settings
    api_key: Optional[str] = None
    api_key_env: str = "GEMINI_API_KEY"
    base_url: str = "https://generativelanguage.googleapis.com/v1beta"

    # Model selection
    default_model: str = "gemini-2.5-flash"
    advanced_model: str = "gemini-2.5-pro"

    # Request settings
    timeout: int = 30
    max_tokens: int = 8192
    temperature: float = 0.7

    # Retry settings
    retry_attempts: int = 3
    retry_backoff: float = 1.0  # Base delay in seconds

    # Features
    enabled: bool = True

    def __post_init__(self):
        """Load API key from environment if not provided."""
        if self.api_key is None:
            self.api_key = os.getenv(self.api_key_env)
            is_production = os.getenv("ENV", "").lower() == "production"
            if self.api_key and not is_production:
                logger.info("Loaded Gemini API key from environment")
            elif not self.api_key:
                logger.warning("Gemini API key not found")


@dataclass
class OpenAIConfig:
    """
    Configuration for OpenAI provider.

    OpenAI offers multiple models:
    - gpt-4o-mini: Fast, cost-effective
    - gpt-4o: Advanced multimodal
    - o3-mini: Reasoning model
    """

    # API settings
    api_key: Optional[str] = None
    api_key_env: str = "OPENAI_API_KEY"
    organization_id: Optional[str] = None
    organization_id_env: str = "OPENAI_ORG_ID"
    base_url: str = "https://api.openai.com/v1"

    # Model selection
    default_model: str = "gpt-4o-mini"
    advanced_model: str = "gpt-4o"
    reasoning_model: str = "o3-mini"

    # Request settings
    timeout: int = 30
    max_tokens: int = 4096
    temperature: float = 0.7

    # Retry settings
    retry_attempts: int = 3
    retry_backoff: float = 1.0  # Base delay in seconds

    # Features
    enabled: bool = True

    def __post_init__(self):
        """Load API key from environment if not provided."""
        if self.api_key is None:
            self.api_key = os.getenv(self.api_key_env)
            is_production = os.getenv("ENV", "").lower() == "production"
            if self.api_key and not is_production:
                logger.info("Loaded OpenAI API key from environment")

        if self.organization_id is None:
            self.organization_id = os.getenv(self.organization_id_env)


@dataclass
class AnthropicConfig:
    """
    Configuration for Anthropic Claude provider.

    Claude offers multiple models:
    - claude-sonnet-4-5: Best for real-world agents and coding
    - claude-opus-4-5: Most capable model
    - claude-haiku-4-5: Fastest, hybrid model
    """

    # API settings
    api_key: Optional[str] = None
    api_key_env: str = "ANTHROPIC_API_KEY"
    base_url: str = "https://api.anthropic.com/v1"
    api_version: str = "2023-06-01"  # Required header

    # Model selection
    default_model: str = "claude-sonnet-4-5"
    advanced_model: str = "claude-opus-4-5"
    fast_model: str = "claude-haiku-4-5"

    # Request settings
    timeout: int = 60
    max_tokens: int = 4096
    temperature: float = 0.7

    # Retry settings
    retry_attempts: int = 3
    retry_backoff: float = 1.0  # Base delay in seconds

    # Features
    enabled: bool = False

    def __post_init__(self):
        """Load API key from environment if not provided."""
        if self.api_key is None:
            self.api_key = os.getenv(self.api_key_env)
            is_production = os.getenv("ENV", "").lower() == "production"
            if self.api_key and not is_production:
                logger.info("Loaded Anthropic API key from environment")


@dataclass
class XAIConfig:
    """
    Configuration for xAI/Grok provider.

    xAI offers OpenAI-compatible API:
    - grok-beta: Default model
    - grok-2: Advanced model
    - grok-4: Latest model (from Responses API)
    """

    # API settings
    api_key: Optional[str] = None
    api_key_env: str = "XAI_API_KEY"
    base_url: str = "https://api.x.ai/v1"

    # Model selection
    default_model: str = "grok-beta"
    advanced_model: str = "grok-2"

    # Request settings
    timeout: int = 30
    max_tokens: int = 4096
    temperature: float = 0.7

    # Retry settings
    retry_attempts: int = 3
    retry_backoff: float = 1.0  # Base delay in seconds

    # Features
    enabled: bool = False

    def __post_init__(self):
        """Load API key from environment if not provided."""
        if self.api_key is None:
            self.api_key = os.getenv(self.api_key_env)
            is_production = os.getenv("ENV", "").lower() == "production"
            if self.api_key and not is_production:
                logger.info("Loaded xAI API key from environment")


@dataclass
class DeepSeekConfig:
    """
    Configuration for DeepSeek provider.

    DeepSeek offers OpenAI-compatible API:
    - deepseek-chat: Non-thinking mode (DeepSeek-V3.2)
    - deepseek-reasoner: Thinking mode (DeepSeek-V3.2)
    """

    # API settings
    api_key: Optional[str] = None
    api_key_env: str = "DEEPSEEK_API_KEY"
    base_url: str = "https://api.deepseek.com"

    # Model selection
    default_model: str = "deepseek-chat"
    reasoning_model: str = "deepseek-reasoner"

    # Request settings
    timeout: int = 30
    max_tokens: int = 4096
    temperature: float = 0.7

    # Retry settings
    retry_attempts: int = 3
    retry_backoff: float = 1.0  # Base delay in seconds

    # Features
    enabled: bool = False

    def __post_init__(self):
        """Load API key from environment if not provided."""
        if self.api_key is None:
            self.api_key = os.getenv(self.api_key_env)
            is_production = os.getenv("ENV", "").lower() == "production"
            if self.api_key and not is_production:
                logger.info("Loaded DeepSeek API key from environment")


@dataclass
class OllamaConfig:
    """
    Configuration for Ollama provider (cloud/local).

    - Cloud: base_url=https://ollama.com, requires OLLAMA_CLOUD_API_KEY
    - Local: base_url=http://localhost:11434, API key optional
    """

    # API settings
    api_key: Optional[str] = None
    api_key_env: str = "OLLAMA_CLOUD_API_KEY"
    base_url: str = "https://ollama.com"

    # Model selection
    default_model: str = "nemotron-3-nano:30b-cloud"
    advanced_model: str = "nemotron-3-nano:30b-cloud"

    # Request settings
    timeout: int = 60
    max_tokens: int = 4096
    temperature: float = 0.7

    # Retry settings
    retry_attempts: int = 3
    retry_backoff: float = 1.0  # Base delay in seconds

    # Features
    enabled: bool = False

    def __post_init__(self):
        """Load API key from environment if not provided."""
        if self.api_key is None:
            self.api_key = os.getenv(self.api_key_env)
            is_production = os.getenv("ENV", "").lower() == "production"
            if self.api_key and not is_production:
                logger.info("Loaded Ollama API key from environment")


# =============================================================================
# Integration Configuration
# =============================================================================


@dataclass
class IntegrationConfig:
    """Configuration for framework integration."""

    # Security layer integration
    enable_rate_limiting: bool = True
    enable_audit_logging: bool = True
    enable_input_validation: bool = True
    enable_error_handling: bool = True

    # User tier lookup: when user_tier is None, call (user_id, tenant_id) -> UserTier from DB/cache
    user_tier_callback: Optional[Callable[[Optional[str], Optional[str]], Any]] = None

    # Health check (prevents unbounded hangs when providers are slow/stuck)
    health_check_timeout: float = 5.0  # Timeout in seconds

    # Streaming timeout (prevents indefinite hang if provider stops sending chunks)
    streaming_timeout: float = 90.0  # Seconds to wait for next chunk before aborting


# =============================================================================
# Main Configuration
# =============================================================================


@dataclass
class LLMConfig:
    """
    Main LLM Engine configuration.

    Combines all configuration sections into a single config object.

    Example:
        config = LLMConfig(
            primary_provider="gemini",
            fallback_providers=["openai", "anthropic"],
        )

        # Or load from environment
        config = LLMConfig.from_env()

        # Or load from providers.yml
        config = LLMConfig.from_providers_config()
    """

    # Provider selection
    primary_provider: str = "gemini"
    fallback_providers: List[str] = field(default_factory=lambda: ["ollama", "openai", "anthropic", "xai", "deepseek"])

    # Default settings
    default_temperature: float = 0.7
    default_max_tokens: int = 4096
    min_confidence: float = 0.7

    # Provider configs
    gemini: GeminiConfig = field(default_factory=GeminiConfig)
    openai: OpenAIConfig = field(default_factory=OpenAIConfig)
    anthropic: AnthropicConfig = field(default_factory=AnthropicConfig)
    xai: XAIConfig = field(default_factory=XAIConfig)
    deepseek: DeepSeekConfig = field(default_factory=DeepSeekConfig)
    ollama: OllamaConfig = field(default_factory=OllamaConfig)

    # Features
    enable_streaming: bool = True
    enable_function_calling: bool = True
    enable_structured_outputs: bool = True
    enable_emotion_extraction: bool = True

    # Fallback
    enable_fallback: bool = True
    allow_degraded_mode: bool = False

    # Circuit breaker
    circuit_breaker_failure_threshold: int = 5
    circuit_breaker_success_threshold: int = 2
    circuit_breaker_timeout: int = 60

    # Integration
    integration: IntegrationConfig = field(default_factory=IntegrationConfig)

    def __post_init__(self):
        """Validate configuration."""
        valid_providers = ["gemini", "openai", "anthropic", "xai", "deepseek", "ollama"]

        if self.primary_provider not in valid_providers:
            raise ValueError(f"Invalid primary provider: {self.primary_provider}")

        for provider in self.fallback_providers:
            if provider not in valid_providers:
                raise ValueError(f"Invalid fallback provider: {provider}")

    @classmethod
    def from_env(cls) -> "LLMConfig":
        """
        Create configuration from environment variables.

        Environment variables:
            LLM_PRIMARY_PROVIDER: Primary provider name
            LLM_FALLBACK_PROVIDERS: Comma-separated fallback providers
            GEMINI_API_KEY: Gemini API key
            OPENAI_API_KEY: OpenAI API key
            ANTHROPIC_API_KEY: Anthropic API key
            XAI_API_KEY: xAI API key
            DEEPSEEK_API_KEY: DeepSeek API key
            OLLAMA_CLOUD_API_KEY: Ollama Cloud API key

        Returns:
            LLMConfig instance
        """
        config = cls()

        # Provider selection
        if primary := os.getenv("LLM_PRIMARY_PROVIDER"):
            config.primary_provider = primary

        if fallbacks := os.getenv("LLM_FALLBACK_PROVIDERS"):
            config.fallback_providers = [p.strip() for p in fallbacks.split(",")]

        logger.info(f"Loaded LLM config from environment: primary={config.primary_provider}")

        return config

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LLMConfig":
        """
        Create configuration from dictionary.

        Args:
            data: Configuration dictionary

        Returns:
            LLMConfig instance
        """
        # Create copy to avoid mutation
        data = data.copy()

        # Extract nested configs
        gemini_data = data.pop("gemini", {})
        openai_data = data.pop("openai", {})
        anthropic_data = data.pop("anthropic", {})
        xai_data = data.pop("xai", {})
        deepseek_data = data.pop("deepseek", {})
        ollama_data = data.pop("ollama", {})
        integration_data = data.pop("integration", {})

        return cls(
            **data,
            gemini=GeminiConfig(**gemini_data),
            openai=OpenAIConfig(**openai_data),
            anthropic=AnthropicConfig(**anthropic_data),
            xai=XAIConfig(**xai_data),
            deepseek=DeepSeekConfig(**deepseek_data),
            ollama=OllamaConfig(**ollama_data),
            integration=IntegrationConfig(**integration_data),
        )

    @classmethod
    def from_providers_config(
        cls,
        providers_config: Optional["ProvidersConfig"] = None,
    ) -> "LLMConfig":
        """
        Create configuration from providers.yml.

        This is the recommended way to configure LLM when using
        the centralized providers.yml configuration file.

        Args:
            providers_config: ProvidersConfig instance (loads default if None)

        Returns:
            LLMConfig instance configured from providers.yml
        """
        try:
            from config import ProvidersConfig, ProviderType
        except ImportError:
            logger.warning("ProvidersConfig not available, falling back to env")
            return cls.from_env()

        # Load providers config if not provided
        if providers_config is None:
            try:
                providers_config = ProvidersConfig()
            except FileNotFoundError:
                logger.warning("providers.yml not found, falling back to env")
                return cls.from_env()

        # Get LLM config section
        llm_section = providers_config._config.get("llm", {})

        # Determine primary and fallback providers
        fallback_order = llm_section.get(
            "fallback_order",
            ["gemini", "ollama", "openai", "anthropic", "xai", "deepseek"],
        )

        # Get primary provider (the one marked as primary: true)
        primary_provider = "gemini"  # Default
        for provider_info in providers_config.get_all_providers(ProviderType.LLM):
            if provider_info.primary:
                primary_provider = provider_info.name
                break

        # Extract enabled fallbacks
        enabled_fallbacks = [
            p.name
            for p in providers_config.get_enabled_providers(ProviderType.LLM)
            if p.name != primary_provider and p.name in fallback_order
        ]

        # Build Gemini config
        gemini_info = providers_config.get_provider("gemini", ProviderType.LLM)
        gemini_config = GeminiConfig()
        if gemini_info and gemini_info.enabled:
            g_cfg = gemini_info.config
            models = g_cfg.get("models", {})

            gemini_config = GeminiConfig(
                api_key=gemini_info.api_key,
                base_url=g_cfg.get("base_url", "https://generativelanguage.googleapis.com/v1beta"),
                default_model=models.get("default", "gemini-2.5-flash"),
                advanced_model=models.get("advanced", "gemini-2.5-pro"),
                timeout=g_cfg.get("timeout", 30),
                max_tokens=g_cfg.get("max_tokens", 8192),
                temperature=g_cfg.get("temperature", 0.7),
                retry_attempts=g_cfg.get("retry_attempts", 3),
                retry_backoff=g_cfg.get("retry_backoff", 1.0),
                enabled=gemini_info.enabled,
            )

        # Build OpenAI config
        openai_info = providers_config.get_provider("openai", ProviderType.LLM)
        openai_config = OpenAIConfig()
        if openai_info and openai_info.enabled:
            oa_cfg = openai_info.config
            models = oa_cfg.get("models", {})

            openai_config = OpenAIConfig(
                api_key=openai_info.api_key,
                base_url=oa_cfg.get("base_url", "https://api.openai.com/v1"),
                default_model=models.get("default", "gpt-4o-mini"),
                advanced_model=models.get("advanced", "gpt-4o"),
                timeout=oa_cfg.get("timeout", 30),
                max_tokens=oa_cfg.get("max_tokens", 4096),
                temperature=oa_cfg.get("temperature", 0.7),
                retry_attempts=oa_cfg.get("retry_attempts", 3),
                retry_backoff=oa_cfg.get("retry_backoff", 1.0),
                enabled=openai_info.enabled,
            )

        # Build Anthropic config
        anthropic_info = providers_config.get_provider("anthropic", ProviderType.LLM)
        anthropic_config = AnthropicConfig()
        if anthropic_info and anthropic_info.enabled:
            an_cfg = anthropic_info.config
            models = an_cfg.get("models", {})

            anthropic_config = AnthropicConfig(
                api_key=anthropic_info.api_key,
                default_model=models.get("default", "claude-sonnet-4-5"),
                advanced_model=models.get("advanced", "claude-opus-4-5"),
                timeout=an_cfg.get("timeout", 60),
                max_tokens=an_cfg.get("max_tokens", 4096),
                temperature=an_cfg.get("temperature", 0.7),
                retry_attempts=an_cfg.get("retry_attempts", 3),
                retry_backoff=an_cfg.get("retry_backoff", 1.0),
                enabled=anthropic_info.enabled,
            )

        # Build xAI config
        xai_info = providers_config.get_provider("xai", ProviderType.LLM)
        xai_config = XAIConfig()
        if xai_info and xai_info.enabled:
            x_cfg = xai_info.config
            models = x_cfg.get("models", {})

            xai_config = XAIConfig(
                api_key=xai_info.api_key,
                base_url=x_cfg.get("base_url", "https://api.x.ai/v1"),
                default_model=models.get("default", "grok-beta"),
                advanced_model=models.get("advanced", "grok-2"),
                timeout=x_cfg.get("timeout", 30),
                max_tokens=x_cfg.get("max_tokens", 4096),
                temperature=x_cfg.get("temperature", 0.7),
                retry_attempts=x_cfg.get("retry_attempts", 3),
                retry_backoff=x_cfg.get("retry_backoff", 1.0),
                enabled=xai_info.enabled,
            )

        # Build DeepSeek config
        deepseek_info = providers_config.get_provider("deepseek", ProviderType.LLM)
        deepseek_config = DeepSeekConfig()
        if deepseek_info and deepseek_info.enabled:
            ds_cfg = deepseek_info.config
            models = ds_cfg.get("models", {})

            deepseek_config = DeepSeekConfig(
                api_key=deepseek_info.api_key,
                base_url=ds_cfg.get("base_url", "https://api.deepseek.com"),
                default_model=models.get("default", "deepseek-chat"),
                reasoning_model=models.get("reasoning", "deepseek-reasoner"),
                timeout=ds_cfg.get("timeout", 30),
                max_tokens=ds_cfg.get("max_tokens", 4096),
                temperature=ds_cfg.get("temperature", 0.7),
                retry_attempts=ds_cfg.get("retry_attempts", 3),
                retry_backoff=ds_cfg.get("retry_backoff", 1.0),
                enabled=deepseek_info.enabled,
            )

        # Build Ollama config
        ollama_info = providers_config.get_provider("ollama", ProviderType.LLM)
        ollama_config = OllamaConfig()
        if ollama_info and ollama_info.enabled:
            ol_cfg = ollama_info.config
            models = ol_cfg.get("models", {})

            ollama_config = OllamaConfig(
                api_key=ollama_info.api_key,
                api_key_env=ol_cfg.get("api_key_env", "OLLAMA_CLOUD_API_KEY"),
                base_url=ol_cfg.get("base_url", "https://ollama.com"),
                default_model=models.get("default", "nemotron-3-nano:30b-cloud"),
                advanced_model=models.get("advanced", models.get("default", "nemotron-3-nano:30b-cloud")),
                timeout=ol_cfg.get("timeout", 60),
                max_tokens=ol_cfg.get("max_tokens", 4096),
                temperature=ol_cfg.get("temperature", 0.7),
                retry_attempts=ol_cfg.get("retry_attempts", 3),
                retry_backoff=ol_cfg.get("retry_backoff", 1.0),
                enabled=ollama_info.enabled,
            )

        # Build integration config from global settings
        global_cfg = providers_config.global_config
        integration_config = IntegrationConfig(
            enable_rate_limiting=global_cfg.get("enable_rate_limiting", True),
            enable_audit_logging=global_cfg.get("enable_audit_logging", True),
            enable_input_validation=global_cfg.get("enable_input_validation", True),
            enable_error_handling=global_cfg.get("enable_error_handling", True),
        )

        logger.info(f"Loaded LLM config from providers.yml: primary={primary_provider}")

        return cls(
            primary_provider=primary_provider,
            fallback_providers=enabled_fallbacks,
            min_confidence=llm_section.get("min_confidence", 0.7),
            gemini=gemini_config,
            openai=openai_config,
            anthropic=anthropic_config,
            xai=xai_config,
            deepseek=deepseek_config,
            ollama=ollama_config,
            integration=integration_config,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        from dataclasses import asdict

        return asdict(self)

    def get_provider_config(self, provider: str) -> Any:
        """
        Get configuration for a specific provider.

        Args:
            provider: Provider name

        Returns:
            Provider configuration object
        """
        configs = {
            "gemini": self.gemini,
            "openai": self.openai,
            "anthropic": self.anthropic,
            "xai": self.xai,
            "deepseek": self.deepseek,
            "ollama": self.ollama,
        }
        return configs.get(provider)
