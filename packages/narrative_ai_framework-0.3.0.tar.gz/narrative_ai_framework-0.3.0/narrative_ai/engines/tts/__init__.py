"""
TTS Engine - Text-to-Speech Module.

This module provides comprehensive Text-to-Speech functionality with:
- Multiple provider support (ElevenLabs, OpenAI, EGTTS)
- Automatic provider fallback on failure
- Emotion-aware speech synthesis
- Language-based provider routing (e.g., Arabic → EGTTS)
- Streaming support for real-time applications
- Full integration with the framework's security layer
- Centralized configuration via providers.yml

Quick Start (Recommended - Using providers.yml):
    ```python
    from narrative_ai.engines.tts import create_tts_engine_from_providers

    # Create engine from config/providers.yml
    engine = await create_tts_engine_from_providers()

    # Simple synthesis
    result = await engine.synthesize(
        text="Hello, how are you?",
        voice_id="21m00Tcm4TlvDq8ikWAM",
    )

    # Save to file
    result.save_to_file("output.mp3")

    # With emotion
    result = await engine.synthesize(
        text="I understand how you feel",
        emotion="empathetic",
    )
    ```

    To change providers, edit config/providers.yml:
    ```yaml
    tts:
      elevenlabs:
        enabled: true
        primary: true    # <- Default provider
      openai:
        enabled: true
        primary: false   # <- Fallback
    ```

Alternative Quick Start (Environment Variables):
    ```python
    from narrative_ai.engines.tts import create_tts_engine

    # Create engine from environment variables
    engine = await create_tts_engine()
    result = await engine.synthesize("Hello world")
    ```

Streaming Example (for LiveKit):
    ```python
    async for chunk in engine.synthesize_streaming(
        text="Hello, this is streaming audio",
        output_format="pcm_24000",
    ):
        await livekit_audio_track.write_frame(chunk)
    ```

Emotion-Aware Synthesis:
    ```python
    from narrative_ai.engines.tts import Emotion

    # Using enum
    result = await engine.synthesize(
        text="That's wonderful news!",
        emotion=Emotion.HAPPY,
    )

    # Using string
    result = await engine.synthesize(
        text="I'm sorry to hear that",
        emotion="empathetic",
    )
    ```

Direct Provider Usage:
    ```python
    from narrative_ai.engines.tts import ElevenLabsTTSProvider, ElevenLabsConfig

    provider = ElevenLabsTTSProvider(ElevenLabsConfig(api_key="..."))
    result = await provider.synthesize("Hello", voice_id="...")
    ```
"""

# Base components
from .base_tts import (
    BaseTTSProvider,
    TTSResult,
    VoiceSettings,
    VoiceInfo,
    Emotion,
    AudioFormat,
    Language,
    StreamingChunk,
    ErrorSeverity,
    TTSError,
    SynthesisError,
    ProviderUnavailableError,
    RateLimitError,
    VoiceNotFoundError,
    TextTooLongError,
    AudioFormatError,
    AuthenticationError,
    TTSTimeoutError,
    TTSNetworkError,
    estimate_duration,
    get_default_voice_settings,
    normalize_language_code,
    is_retriable_error,
    MetricsExporter,
    NoOpMetricsExporter,
    set_metrics_exporter,
    get_metrics_exporter,
)

# Configuration
from .config import (
    TTSConfig,
    ElevenLabsConfig,
    OpenAIConfig,
    EGTTSConfig,
    GoogleConfig,
    EmotionConfig,
    AudioConfig,
    IntegrationConfig,
    TTSProvider,
    OutputFormat,
)

# Audio processing
from .audio_processor import (
    TTSAudioProcessor,
    AudioMetadata,
    detect_format,
    calculate_duration_estimate,
    format_duration,
    get_elevenlabs_format_code,
    parse_elevenlabs_format_code,
)

# Emotion processing
from .emotion_applicator import (
    EmotionApplicator,
    EmotionProfile,
    get_default_applicator,
    apply_emotion_to_text,
)

# Providers
from .elevenlabs_tts import ElevenLabsTTSProvider
from .openai_tts import OpenAITTSProvider

# Strategy
from .tts_strategy import TTSStrategy, CircuitBreakerConfig

# Main engine
from .tts_engine import (
    TTSEngine,
    create_tts_engine,
    create_tts_engine_from_providers,
    tts_engine_context,
)

# API
from .api import (
    text_to_speech,
    tts_streaming,
    get_voices,
    TTSClient,
)


__all__ = [
    # Main entry points
    "TTSEngine",
    "create_tts_engine",
    "create_tts_engine_from_providers",
    "tts_engine_context",
    "text_to_speech",
    "tts_streaming",
    "get_voices",
    "TTSClient",
    # Base components
    "BaseTTSProvider",
    "TTSResult",
    "VoiceSettings",
    "VoiceInfo",
    "Emotion",
    "AudioFormat",
    "Language",
    "StreamingChunk",
    "ErrorSeverity",
    # Errors
    "TTSError",
    "SynthesisError",
    "ProviderUnavailableError",
    "RateLimitError",
    "VoiceNotFoundError",
    "TextTooLongError",
    "AudioFormatError",
    "AuthenticationError",
    "TTSTimeoutError",
    "TTSNetworkError",
    # Error utilities
    "is_retriable_error",
    # Metrics
    "MetricsExporter",
    "NoOpMetricsExporter",
    "set_metrics_exporter",
    "get_metrics_exporter",
    # Configuration
    "TTSConfig",
    "ElevenLabsConfig",
    "OpenAIConfig",
    "EGTTSConfig",
    "GoogleConfig",
    "EmotionConfig",
    "AudioConfig",
    "IntegrationConfig",
    "TTSProvider",
    "OutputFormat",
    # Audio processing
    "TTSAudioProcessor",
    "AudioMetadata",
    "detect_format",
    "calculate_duration_estimate",
    "format_duration",
    "get_elevenlabs_format_code",
    "parse_elevenlabs_format_code",
    # Emotion processing
    "EmotionApplicator",
    "EmotionProfile",
    "get_default_applicator",
    "apply_emotion_to_text",
    # Providers
    "ElevenLabsTTSProvider",
    "OpenAITTSProvider",
    # Strategy
    "TTSStrategy",
    "CircuitBreakerConfig",
    # Utility functions
    "estimate_duration",
    "get_default_voice_settings",
    "normalize_language_code",
]

# Module version
__version__ = "0.1.0"
