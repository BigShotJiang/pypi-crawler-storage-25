"""Entry point for running the TTS engine via ``python -m narrative_ai.engines.tts``."""

from .main import main

if __name__ == "__main__":
    main()
