"""
ElevenLabs TTS Provider.

Production-ready implementation with:
- Connection pool limits to prevent socket exhaustion
- Exponential backoff with jitter to prevent thundering herd
- Retry logic for streaming endpoints
- Bounded voice cache
- Structured logging with correlation IDs
- Proper exception chaining
"""

import asyncio
import random
import time
import logging
from typing import Optional, List, Dict, Any, AsyncIterator
from urllib.parse import urlencode

from .base_tts import (
    BaseTTSProvider,
    TTSResult,
    VoiceSettings,
    VoiceInfo,
    SynthesisError,
    ProviderUnavailableError,
    RateLimitError,
    VoiceNotFoundError,
    TextTooLongError,
    AuthenticationError,
    TTSTimeoutError,
    TTSNetworkError,
    get_metrics_exporter,
)
from .config import ElevenLabsConfig
from .audio_processor import get_elevenlabs_format_code, parse_elevenlabs_format_code

try:
    import aiohttp
except ImportError:
    aiohttp = None  # type: ignore[assignment]

try:
    from narrative_ai.shared.retry_utils import parse_retry_after
except ImportError:

    def parse_retry_after(header_value: Optional[str], default_seconds: int = 5, max_seconds: int = 300) -> int:
        return default_seconds


logger = logging.getLogger(__name__)


# =============================================================================
# Connection Pool Configuration
# =============================================================================

# Default connection pool limits
DEFAULT_POOL_LIMIT = 100  # Total connections across all hosts
DEFAULT_POOL_LIMIT_PER_HOST = 30  # Connections per host
MAX_VOICE_CACHE_SIZE = 1000  # Maximum voices to cache


class ElevenLabsTTSProvider(BaseTTSProvider):
    """
    ElevenLabs TTS provider - Production Ready.

    Features:
    - High-quality voice synthesis
    - Ultra-low latency streaming (~75ms with Flash model)
    - 32 languages including Arabic
    - Voice settings control (stability, similarity, style)
    - Multiple output formats

    Production Features:
    - Connection pooling with configurable limits
    - Exponential backoff with jitter
    - Retry logic for both batch and streaming
    - Bounded LRU cache for voices
    - Structured logging
    - Metrics export

    Models:
    - eleven_flash_v2_5: Ultra-low latency (~75ms)
    - eleven_multilingual_v2: Highest quality, 29 languages
    - eleven_turbo_v2_5: Balance of quality and speed
    """

    BASE_URL = "https://api.elevenlabs.io"
    TTS_ENDPOINT = "/v1/text-to-speech"
    VOICES_ENDPOINT = "/v2/voices"  # v2: pagination, v1 deprecated

    # Provider constants
    MAX_TEXT_LENGTH = 5000  # Characters
    SUPPORTED_FORMATS = [
        "mp3_44100_128",
        "mp3_44100_64",
        "mp3_22050_32",
        "pcm_16000",
        "pcm_22050",
        "pcm_24000",
        "pcm_44100",
        "ulaw_8000",
        "alaw_8000",
    ]
    SUPPORTED_LANGUAGES = [
        "en",
        "ar",
        "zh",
        "de",
        "es",
        "fr",
        "hi",
        "it",
        "ja",
        "ko",
        "nl",
        "pl",
        "pt",
        "ru",
        "tr",
        "vi",
    ]

    def __init__(
        self,
        config: ElevenLabsConfig,
        pool_limit: int = DEFAULT_POOL_LIMIT,
        pool_limit_per_host: int = DEFAULT_POOL_LIMIT_PER_HOST,
    ):
        """
        Initialize ElevenLabs provider.

        Args:
            config: ElevenLabs configuration
            pool_limit: Total connection pool limit
            pool_limit_per_host: Connection limit per host
        """
        self.config = config
        self._pool_limit = pool_limit
        self._pool_limit_per_host = pool_limit_per_host
        self._http_session = None
        self._connector = None
        self._is_loaded = False

        # Bounded voice cache
        self._voices_cache: Optional[List[VoiceInfo]] = None
        self._cache_timestamp: float = 0
        self._cache_ttl: int = 300  # 5 minutes

        # Metrics
        self._metrics = get_metrics_exporter()

    async def load_model(self) -> None:
        """Initialize HTTP session with connection pooling."""
        if self._http_session is not None:
            return

        try:
            import aiohttp

            # Create connector with pool limits
            self._connector = aiohttp.TCPConnector(
                limit=self._pool_limit,
                limit_per_host=self._pool_limit_per_host,
                ttl_dns_cache=300,  # Cache DNS for 5 minutes
                enable_cleanup_closed=True,
            )

            # Session has no default timeout so streaming works when not run inside an
            # asyncio task (e.g. LiveKit pipeline). Timeout is passed per-request for
            # batch and get_voices to avoid "Timeout context manager should be used
            # inside a task" in aiohttp.
            self._http_session = aiohttp.ClientSession(
                connector=self._connector,
                timeout=None,
            )
            self._is_loaded = True

            logger.info(
                "ElevenLabs TTS provider initialized",
                extra={
                    "pool_limit": self._pool_limit,
                    "pool_limit_per_host": self._pool_limit_per_host,
                },
            )

        except ImportError as e:
            raise ProviderUnavailableError(
                "aiohttp required for ElevenLabs TTS",
                provider=self.get_provider_name(),
            ) from e

    async def shutdown(self) -> None:
        """Close HTTP session and connector."""
        if self._http_session:
            await self._http_session.close()
            self._http_session = None

        if self._connector:
            await self._connector.close()
            self._connector = None

        self._is_loaded = False
        logger.info("ElevenLabs TTS provider shutdown")

    def is_available(self) -> bool:
        """Check if provider is available."""
        return self.config.api_key is not None and len(self.config.api_key) > 0

    def get_provider_name(self) -> str:
        """Get provider name."""
        return "elevenlabs"

    def get_supported_languages(self) -> List[str]:
        """Get supported languages."""
        return self.SUPPORTED_LANGUAGES.copy()

    def _get_headers(self, output_format: Optional[str] = None) -> Dict[str, str]:
        """
        Get API request headers.

        Args:
            output_format: Output format code (e.g. mp3_44100_128, pcm_24000).
                Accept header is set based on format for correct content-type handling.
        """
        fmt = (output_format or "mp3_44100_128").lower().split("_")[0]
        if fmt in ("pcm", "wav"):
            accept = "application/octet-stream"
        elif fmt in ("ulaw", "alaw"):
            accept = "audio/basic"
        else:
            accept = "audio/mpeg"
        return {
            "xi-api-key": self.config.api_key,
            "Content-Type": "application/json",
            "Accept": accept,
        }

    def _build_request_body(
        self,
        text: str,
        voice_settings: Optional[VoiceSettings] = None,
        model_id: Optional[str] = None,
        language: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build API request body."""
        body = {
            "text": text,
            "model_id": model_id or self.config.model_id,
        }

        if voice_settings:
            body["voice_settings"] = voice_settings.to_elevenlabs_dict()

        if language:
            body["language_code"] = language

        # Latency optimization flag is deprecated by ElevenLabs. If users set a
        # non-zero value in config we log a warning (once per process) but do
        # not send the parameter to the API. Flash + streaming are the
        # recommended approach instead.
        if getattr(self.config, "optimize_streaming_latency", 0) > 0:
            flag = getattr(self, "_warned_optimize_latency", False)
            if not flag:
                logger.warning(
                    "ElevenLabs optimize_streaming_latency is deprecated and will be ignored. "
                    "Use eleven_flash_v2_5 with streaming instead for best latency.",
                    extra={
                        "correlation_id": correlation_id,
                        "value": self.config.optimize_streaming_latency,
                    },
                )
                self._warned_optimize_latency = True

        return body

    def _calculate_backoff_with_jitter(self, attempt: int, base_delay: float = 1.0) -> float:
        """
        Calculate exponential backoff with jitter.

        Uses "full jitter" strategy to prevent thundering herd:
        delay = random(0, min(cap, base * 2^attempt))

        Args:
            attempt: Current attempt number (0-indexed)
            base_delay: Base delay in seconds

        Returns:
            Delay in seconds with jitter applied
        """
        cap = 30.0  # Maximum delay cap
        exponential_delay = min(cap, base_delay * (2**attempt))
        # Full jitter: random between 0 and exponential delay
        return random.uniform(0, exponential_delay)

    async def synthesize(
        self,
        text: str,
        voice_id: str,
        language: Optional[str] = None,
        voice_settings: Optional[VoiceSettings] = None,
        output_format: str = "mp3_44100_128",
        sample_rate: Optional[int] = None,
        correlation_id: Optional[str] = None,
    ) -> TTSResult:
        """
        Synthesize speech using ElevenLabs API.

        Args:
            text: Text to convert to speech
            voice_id: Voice ID to use
            language: Language code
            voice_settings: Voice settings
            output_format: Output format code
            sample_rate: Desired sample rate (determines format if set)
            correlation_id: Request correlation ID for tracing

        Returns:
            TTSResult with audio and metadata
        """
        if not self.is_available():
            raise ProviderUnavailableError(
                "ElevenLabs API key not configured",
                provider=self.get_provider_name(),
                correlation_id=correlation_id,
            )

        # Validate input
        self.validate_text(text, correlation_id)
        self.validate_format(output_format, correlation_id)

        # Ensure session is ready
        if not self._http_session:
            await self.load_model()

        # Determine output format
        if sample_rate:
            output_format = get_elevenlabs_format_code("mp3", sample_rate)

        start_time = time.time()

        # Build request
        url = f"{self.BASE_URL}{self.TTS_ENDPOINT}/{voice_id}?output_format={output_format}"
        headers = self._get_headers(output_format)
        body = self._build_request_body(text, voice_settings, language=language, correlation_id=correlation_id)

        # Track metrics
        self._metrics.increment("tts.elevenlabs.requests", tags={"type": "batch"})

        # Make request with retry and jitter
        last_error: Optional[Exception] = None
        _timeout = aiohttp.ClientTimeout(
            total=self.config.timeout,
            connect=10,
            sock_read=30,
        )
        for attempt in range(self.config.retry_attempts):
            try:
                async with self._http_session.post(
                    url,
                    headers=headers,
                    json=body,
                    timeout=_timeout,
                ) as response:
                    if response.status == 200:
                        audio_data = await response.read()
                        processing_time = time.time() - start_time

                        # Parse format info
                        fmt, sr, bitrate = parse_elevenlabs_format_code(output_format)

                        # Calculate duration estimate
                        if fmt == "mp3" and bitrate:
                            duration = (len(audio_data) * 8) / (bitrate * 1000)
                        else:
                            duration = len(audio_data) / (sr * 2)

                        # Record metrics
                        self._metrics.increment("tts.elevenlabs.success")
                        self._metrics.histogram("tts.elevenlabs.latency", processing_time)
                        self._metrics.histogram("tts.elevenlabs.audio_duration", duration)

                        logger.info(
                            "TTS synthesis completed",
                            extra={
                                "correlation_id": correlation_id,
                                "provider": "elevenlabs",
                                "voice_id": voice_id,
                                "text_length": len(text),
                                "duration": duration,
                                "processing_time": processing_time,
                            },
                        )

                        return TTSResult(
                            audio=audio_data,
                            format=fmt,
                            sample_rate=sr,
                            duration=duration,
                            provider=self.get_provider_name(),
                            processing_time=processing_time,
                            voice_id=voice_id,
                            text_length=len(text),
                            language=language,
                            correlation_id=correlation_id,
                            metadata={
                                "model_id": body.get("model_id"),
                                "output_format": output_format,
                            },
                        )

                    elif response.status == 429:
                        retry_after = parse_retry_after(
                            response.headers.get("Retry-After"),
                            default_seconds=5,
                        )
                        self._metrics.increment("tts.elevenlabs.rate_limited")

                        logger.warning(
                            "Rate limited by ElevenLabs",
                            extra={
                                "correlation_id": correlation_id,
                                "retry_after": retry_after,
                                "attempt": attempt + 1,
                            },
                        )

                        if attempt < self.config.retry_attempts - 1:
                            await asyncio.sleep(retry_after)
                            continue
                        else:
                            raise RateLimitError(
                                f"Rate limited after {self.config.retry_attempts} attempts",
                                provider=self.get_provider_name(),
                                retry_after=retry_after,
                                correlation_id=correlation_id,
                            )

                    elif response.status == 401:
                        self._metrics.increment("tts.elevenlabs.auth_error")
                        raise AuthenticationError(
                            "Invalid API key",
                            provider=self.get_provider_name(),
                            correlation_id=correlation_id,
                        )

                    elif response.status == 404:
                        raise VoiceNotFoundError(
                            f"Voice not found: {voice_id}",
                            provider=self.get_provider_name(),
                            correlation_id=correlation_id,
                        )

                    elif response.status == 422:
                        error_text = await response.text()
                        if "text" in error_text.lower() and "long" in error_text.lower():
                            raise TextTooLongError(
                                f"Text too long: {len(text)} characters",
                                provider=self.get_provider_name(),
                                max_length=self.MAX_TEXT_LENGTH,
                                actual_length=len(text),
                                correlation_id=correlation_id,
                            )
                        raise SynthesisError(
                            f"Validation error: {error_text}",
                            provider=self.get_provider_name(),
                            correlation_id=correlation_id,
                        )

                    else:
                        error_text = await response.text()
                        last_error = SynthesisError(
                            f"API error {response.status}: {error_text}",
                            provider=self.get_provider_name(),
                            correlation_id=correlation_id,
                        )

            except asyncio.TimeoutError as e:
                self._metrics.increment("tts.elevenlabs.timeout")
                last_error = TTSTimeoutError(
                    "Request timed out",
                    provider=self.get_provider_name(),
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e

            except (
                ProviderUnavailableError,
                RateLimitError,
                VoiceNotFoundError,
                TextTooLongError,
                AuthenticationError,
            ):
                raise

            except (ConnectionError, OSError) as e:
                self._metrics.increment("tts.elevenlabs.network_error")
                last_error = TTSNetworkError(
                    f"Network error: {e}",
                    provider=self.get_provider_name(),
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e

            except Exception as e:
                if aiohttp is not None and isinstance(e, aiohttp.ClientError):
                    self._metrics.increment("tts.elevenlabs.network_error")
                    last_error = TTSNetworkError(
                        f"Connection error: {e}",
                        provider=self.get_provider_name(),
                        correlation_id=correlation_id,
                    )
                    last_error.__cause__ = e
                else:
                    self._metrics.increment("tts.elevenlabs.error")
                    last_error = SynthesisError(
                        f"Request failed: {e}",
                        provider=self.get_provider_name(),
                        correlation_id=correlation_id,
                    )
                    last_error.__cause__ = e

            # Exponential backoff with jitter
            if attempt < self.config.retry_attempts - 1:
                wait_time = self._calculate_backoff_with_jitter(attempt, self.config.retry_backoff)
                logger.warning(
                    "Retrying TTS request",
                    extra={
                        "correlation_id": correlation_id,
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                        "error": str(last_error),
                    },
                )
                await asyncio.sleep(wait_time)

        self._metrics.increment("tts.elevenlabs.exhausted_retries")

        if last_error:
            raise last_error

        raise SynthesisError(
            "Synthesis failed after all retries",
            provider=self.get_provider_name(),
            correlation_id=correlation_id,
        )

    async def synthesize_streaming(
        self,
        text: str,
        voice_id: str,
        language: Optional[str] = None,
        voice_settings: Optional[VoiceSettings] = None,
        output_format: str = "pcm_24000",
        sample_rate: Optional[int] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[bytes]:
        """
        Stream synthesized audio chunks with retry support.

        Uses ElevenLabs streaming endpoint with retry before streaming starts.
        Once streaming begins, errors are propagated (can't replay).

        Args:
            text: Text to convert
            voice_id: Voice ID
            language: Language code
            voice_settings: Voice settings
            output_format: Output format (pcm recommended for streaming)
            sample_rate: Sample rate
            correlation_id: Request correlation ID

        Yields:
            Audio data chunks as bytes
        """
        if not self.is_available():
            raise ProviderUnavailableError(
                "ElevenLabs API key not configured",
                provider=self.get_provider_name(),
                correlation_id=correlation_id,
            )

        self.validate_text(text, correlation_id)
        self.validate_format(output_format, correlation_id)

        if not self._http_session:
            await self.load_model()

        if sample_rate:
            output_format = get_elevenlabs_format_code("pcm", sample_rate)

        # Build streaming URL (omit deprecated optimize_streaming_latency; prefer Flash model)
        url = f"{self.BASE_URL}{self.TTS_ENDPOINT}/{voice_id}/stream?output_format={output_format}"

        headers = self._get_headers(output_format)
        body = self._build_request_body(text, voice_settings, language=language)

        self._metrics.increment("tts.elevenlabs.requests", tags={"type": "streaming"})

        # Retry logic for connection establishment. No timeout on request so aiohttp
        # does not use its timer (avoids "Timeout context manager should be used
        # inside a task" when run from LiveKit or other non-task context).
        last_error: Optional[Exception] = None
        for attempt in range(self.config.retry_attempts):
            try:
                async with self._http_session.post(
                    url,
                    headers=headers,
                    json=body,
                ) as response:
                    if response.status == 200:
                        self._metrics.increment("tts.elevenlabs.streaming_started")

                        logger.info(
                            "TTS streaming started",
                            extra={
                                "correlation_id": correlation_id,
                                "voice_id": voice_id,
                                "text_length": len(text),
                            },
                        )

                        # Once streaming starts, yield chunks without retry
                        chunk_count = 0
                        total_bytes = 0
                        async for chunk in response.content.iter_chunked(4096):
                            if chunk:
                                chunk_count += 1
                                total_bytes += len(chunk)
                                yield chunk

                        self._metrics.increment("tts.elevenlabs.streaming_success")
                        self._metrics.histogram("tts.elevenlabs.streaming_chunks", chunk_count)

                        logger.info(
                            "TTS streaming completed",
                            extra={
                                "correlation_id": correlation_id,
                                "chunks": chunk_count,
                                "total_bytes": total_bytes,
                            },
                        )
                        return

                    elif response.status == 429:
                        retry_after = parse_retry_after(
                            response.headers.get("Retry-After"),
                            default_seconds=5,
                        )
                        self._metrics.increment("tts.elevenlabs.rate_limited")
                        if attempt < self.config.retry_attempts - 1:
                            await asyncio.sleep(retry_after)
                            continue
                        raise RateLimitError(
                            "Rate limited during streaming setup",
                            provider=self.get_provider_name(),
                            retry_after=retry_after,
                            correlation_id=correlation_id,
                        )

                    elif response.status == 401:
                        raise AuthenticationError(
                            "Invalid API key",
                            provider=self.get_provider_name(),
                            correlation_id=correlation_id,
                        )

                    elif response.status == 404:
                        raise VoiceNotFoundError(
                            f"Voice not found: {voice_id}",
                            provider=self.get_provider_name(),
                            correlation_id=correlation_id,
                        )

                    else:
                        error_text = await response.text()
                        last_error = SynthesisError(
                            f"Streaming error {response.status}: {error_text}",
                            provider=self.get_provider_name(),
                            correlation_id=correlation_id,
                        )

            except asyncio.TimeoutError as e:
                last_error = TTSTimeoutError(
                    "Streaming request timed out",
                    provider=self.get_provider_name(),
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e

            except (ProviderUnavailableError, RateLimitError, VoiceNotFoundError, AuthenticationError):
                raise

            except (ConnectionError, OSError) as e:
                last_error = TTSNetworkError(
                    f"Streaming network error: {e}",
                    provider=self.get_provider_name(),
                    correlation_id=correlation_id,
                )
                last_error.__cause__ = e

            except Exception as e:
                if aiohttp is not None and isinstance(e, aiohttp.ClientError):
                    last_error = TTSNetworkError(
                        f"Streaming connection error: {e}",
                        provider=self.get_provider_name(),
                        correlation_id=correlation_id,
                    )
                    last_error.__cause__ = e
                else:
                    last_error = SynthesisError(
                        f"Streaming failed: {e}",
                        provider=self.get_provider_name(),
                        correlation_id=correlation_id,
                    )
                    last_error.__cause__ = e

            # Retry with jitter before streaming starts
            if attempt < self.config.retry_attempts - 1:
                wait_time = self._calculate_backoff_with_jitter(attempt, self.config.retry_backoff)
                logger.warning(
                    "Retrying TTS streaming request",
                    extra={
                        "correlation_id": correlation_id,
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                    },
                )
                await asyncio.sleep(wait_time)

        self._metrics.increment("tts.elevenlabs.streaming_failed")

        if last_error:
            raise last_error

        raise SynthesisError(
            "Streaming failed after all retries",
            provider=self.get_provider_name(),
            correlation_id=correlation_id,
        )

    async def get_voices(self, force_refresh: bool = False) -> List[VoiceInfo]:
        """
        Get available voices from ElevenLabs (v2 API with pagination).

        Uses GET /v2/voices with pagination to fetch all voices. Results are
        cached with TTL and size limit.

        Args:
            force_refresh: Force cache refresh

        Returns:
            List of VoiceInfo objects
        """
        now = time.time()
        if not force_refresh and self._voices_cache and (now - self._cache_timestamp) < self._cache_ttl:
            return self._voices_cache

        if not self._http_session:
            await self.load_model()

        headers = {"xi-api-key": self.config.api_key}
        all_voices: List[VoiceInfo] = []
        next_page_token: Optional[str] = None
        page_size = 100  # Max per ElevenLabs v2 API

        _timeout = aiohttp.ClientTimeout(
            total=self.config.timeout,
            connect=10,
            sock_read=30,
        )
        try:
            while True:
                params: Dict[str, Any] = {
                    "page_size": page_size,
                    "include_total_count": "false",  # Avoid perf cost per docs
                }
                if next_page_token:
                    params["next_page_token"] = next_page_token
                query = urlencode(params)
                url = f"{self.BASE_URL}{self.VOICES_ENDPOINT}?{query}"

                async with self._http_session.get(url, headers=headers, timeout=_timeout) as response:
                    if response.status != 200:
                        logger.warning(
                            "Failed to get voices from API, returning cached voices if available",
                            extra={"status": response.status, "api_error": True},
                        )
                        # Return cache on error; don't overwrite with partial data
                        if all_voices:
                            self._voices_cache = all_voices[:MAX_VOICE_CACHE_SIZE]
                            self._cache_timestamp = now
                        return self._voices_cache or []

                    data = await response.json()
                    voices_data = data.get("voices", [])

                    for v in voices_data:
                        voice_id = v.get("voice_id")
                        name = v.get("name")
                        if not voice_id or not name:
                            logger.debug("Skipping voice with missing voice_id or name", extra={"voice": v})
                            continue
                        voice = VoiceInfo(
                            voice_id=voice_id,
                            name=name,
                            description=v.get("description"),
                            provider=self.get_provider_name(),
                            preview_url=v.get("preview_url"),
                            is_cloned=v.get("category") == "cloned",
                            labels=v.get("labels") if isinstance(v.get("labels"), dict) else {},
                        )
                        all_voices.append(voice)

                    has_more = data.get("has_more", False)
                    if not has_more:
                        break

                    next_page_token = data.get("next_page_token")
                    if not next_page_token:
                        break

                    # Brief pause between pages to avoid rate limits
                    await asyncio.sleep(0.1)

            # Limit cache size
            if len(all_voices) > MAX_VOICE_CACHE_SIZE:
                all_voices = all_voices[:MAX_VOICE_CACHE_SIZE]

            self._voices_cache = all_voices
            self._cache_timestamp = now

            logger.debug("Voice cache updated (v2 API with pagination)", extra={"voice_count": len(all_voices)})

            return all_voices

        except Exception as e:
            logger.warning(
                "Error fetching voices from API, returning cached voices if available",
                extra={"error": str(e), "api_error": True},
            )
            return self._voices_cache or []

    def get_available_voices(self) -> List[VoiceInfo]:
        """Get available voices (sync wrapper)."""
        return self._voices_cache or []

    async def health_check(self) -> Dict[str, Any]:
        """Perform health check."""
        health = {
            "provider": self.get_provider_name(),
            "available": self.is_available(),
            "session_active": self._http_session is not None,
            "model_id": self.config.model_id,
            "max_text_length": self.MAX_TEXT_LENGTH,
            "pool_limit": self._pool_limit,
            "pool_limit_per_host": self._pool_limit_per_host,
        }

        if self.is_available():
            try:
                voices = await self.get_voices()
                health["voice_count"] = len(voices)
                health["api_connected"] = True
            except Exception as e:
                health["api_connected"] = False
                health["error"] = str(e)

        return health
