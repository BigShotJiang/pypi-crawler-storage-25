from typing import Optional, Union, AsyncIterator, List, Any, Dict
from narrative_ai.engines.tts.tts_engine import TTSEngine
from narrative_ai.engines.tts.base_tts import TTSResult, VoiceSettings, Emotion, VoiceInfo, StreamingChunk

_default_engine: Optional[TTSEngine] = None

async def _ensure_engine() -> TTSEngine:
    """Get or create the default global TTSEngine instance."""
    global _default_engine
    if _default_engine is None:
        from narrative_ai.engines.tts.tts_engine import create_tts_engine_from_providers
        _default_engine = await create_tts_engine_from_providers()
        await _default_engine.initialize()
    return _default_engine

def set_api_key(api_key: str, provider: str = "elevenlabs"):
    """
    Dynamically set the API key for a TTS provider.
    
    Args:
        api_key: The secret API key string.
        provider: Provider name (e.g., 'elevenlabs', 'openai', 'google').
    """
    import os
    env_map = {
        "elevenlabs": "ELEVENLABS_API_KEY",
        "openai": "OPENAI_API_KEY",
        "google": "GOOGLE_APPLICATION_CREDENTIALS"
    }
    env_var = env_map.get(provider.lower())
    if env_var:
        os.environ[env_var] = api_key

def set_tts_provider(provider_name: str) -> None:
    """Dynamically switch the primary TTS provider."""
    global _default_engine
    if _default_engine:
        _default_engine.set_primary_provider(provider_name)
    
    import os
    os.environ["TTS_PRIMARY_PROVIDER"] = provider_name

async def text_to_speech(
    text: str,
    voice_id: Optional[str] = None,
    emotion: Optional[Union[Emotion, str]] = None,
    language: Optional[str] = None,
    voice_settings: Optional[VoiceSettings] = None,
    output_format: str = "mp3_44100_128",
    provider: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> TTSResult:
    """Synthesize text to speech."""
    engine = await _ensure_engine()
    return await engine.synthesize(
        text=text,
        voice_id=voice_id,
        emotion=emotion,
        language=language,
        voice_settings=voice_settings,
        output_format=output_format,
        provider=provider,
        user_id=user_id,
        tenant_id=tenant_id,
        correlation_id=correlation_id,
        **kwargs
    )

async def tts_streaming(
    text: str,
    voice_id: Optional[str] = None,
    emotion: Optional[Union[Emotion, str]] = None,
    language: Optional[str] = None,
    voice_settings: Optional[VoiceSettings] = None,
    output_format: str = "mp3_44100_128",
    provider: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> AsyncIterator[StreamingChunk]:
    """Synthesize text to speech stream."""
    engine = await _ensure_engine()
    async for chunk in engine.synthesize_streaming(
        text=text,
        voice_id=voice_id,
        emotion=emotion,
        language=language,
        voice_settings=voice_settings,
        output_format=output_format,
        provider=provider,
        user_id=user_id,
        tenant_id=tenant_id,
        correlation_id=correlation_id,
        **kwargs
    ):
        yield chunk

async def get_voices() -> List[VoiceInfo]:
    """Get list of available voices from current strategy."""
    engine = await _ensure_engine()
    return await engine.get_voices()

async def get_tts_metrics() -> Dict[str, Any]:
    """Get performance metrics for the TTS engine."""
    engine = await _ensure_engine()
    return await engine.get_metrics()

async def tts_health_check() -> Dict[str, Any]:
    """Check the health status of the TTS engine and its providers."""
    engine = await _ensure_engine()
    return await engine.health_check()

def set_tts_provider(provider_name: str) -> None:
    """Dynamically switch the primary TTS provider."""
    global _default_engine
    if _default_engine:
        _default_engine.set_primary_provider(provider_name)

class TTSClient:
    """
    A session-based client for the Text-to-Speech engine.
    Stores common parameters like user_id, voice_id, and language.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        voice_id: Optional[str] = None,
        language: Optional[str] = None,
        provider: Optional[str] = None,
        api_key: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ):
        """
        Initialize the TTS client with default context.
        
        Args:
            user_id: Default user ID for all requests
            tenant_id: Default tenant ID for all requests
            voice_id: Default voice ID to use
            language: Default language for synthesis
            provider: Default TTS provider to use
            api_key: Optional API key for the session
            correlation_id: Default correlation ID prefix or value
        """
        if api_key and provider:
            set_api_key(api_key, provider)

        self.defaults = {
            "user_id": user_id,
            "tenant_id": tenant_id,
            "voice_id": voice_id,
            "language": language,
            "provider": provider,
            "correlation_id": correlation_id,
        }

    async def synthesize(self, text: str, **kwargs) -> TTSResult:
        """
        Synthesize text to speech using client defaults.
        Specific arguments passed here will override client defaults.
        """
        final_args = {**self.defaults, "text": text, **kwargs}
        return await text_to_speech(**final_args)

    async def synthesize_stream(self, text: str, **kwargs) -> AsyncIterator[StreamingChunk]:
        """
        Synthesize text to speech stream using client defaults.
        Specific arguments passed here will override client defaults.
        """
        final_args = {**self.defaults, "text": text, **kwargs}
        async for chunk in tts_streaming(**final_args):
            yield chunk

    async def get_voices(self) -> List[VoiceInfo]:
        """Get list of available voices."""
        return await get_voices()

    async def get_metrics(self) -> Dict[str, Any]:
        """Get performance metrics for the current session."""
        return await get_tts_metrics()

    async def health_check(self) -> Dict[str, Any]:
        """Check the status of TTS providers."""
        return await tts_health_check()

    def set_provider(self, provider_name: str) -> None:
        """Switch the provider for this session."""
        set_tts_provider(provider_name)
