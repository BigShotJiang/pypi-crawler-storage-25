"""
TTS Emotion Applicator.

Converts emotion labels from the LLM response to voice settings adjustments.
The LLM provides emotion alongside the response text, and this module
maps those emotions to appropriate TTS voice parameters.

Example flow:
    LLM Response: {"text": "I understand how you feel", "emotion": "empathetic"}
    → EmotionApplicator maps "empathetic" to voice settings
    → TTS synthesizes with adjusted stability, speed, style
"""

import logging
from typing import Optional, Dict
from dataclasses import dataclass

from .base_tts import Emotion, VoiceSettings
from .config import EmotionConfig

logger = logging.getLogger(__name__)


# =============================================================================
# Emotion Profiles
# =============================================================================


@dataclass
class EmotionProfile:
    """
    Voice settings profile for an emotion.

    Defines how an emotion affects voice parameters.

    Attributes:
        stability: Voice stability adjustment
        similarity_boost: Voice similarity adjustment
        style: Style exaggeration
        speed: Speech speed multiplier
        description: Human-readable description
    """

    stability: float
    similarity_boost: float
    style: float
    speed: float
    description: str = ""

    def to_voice_settings(self) -> VoiceSettings:
        """Convert to VoiceSettings object."""
        return VoiceSettings(
            stability=self.stability,
            similarity_boost=self.similarity_boost,
            style=self.style,
            speed=self.speed,
        )


# =============================================================================
# Default Emotion Profiles
# =============================================================================

# These profiles are tuned for natural-sounding emotional speech.
# Lower stability = more variation/expressiveness
# Higher style = more dramatic delivery
# Speed affects perceived energy

DEFAULT_EMOTION_PROFILES: Dict[Emotion, EmotionProfile] = {
    Emotion.HAPPY: EmotionProfile(
        stability=0.4,  # More variation for expressiveness
        similarity_boost=0.8,
        style=0.35,  # Noticeable style for cheerfulness
        speed=1.1,  # Slightly faster, more energetic
        description="Cheerful, upbeat delivery with good energy",
    ),
    Emotion.SAD: EmotionProfile(
        stability=0.65,  # More stable, measured delivery
        similarity_boost=0.75,
        style=0.2,  # Subtle style
        speed=0.88,  # Slower, more deliberate
        description="Subdued, gentle delivery with slower pace",
    ),
    Emotion.CALM: EmotionProfile(
        stability=0.7,  # Very stable, consistent
        similarity_boost=0.75,
        style=0.1,  # Minimal style variation
        speed=0.95,  # Slightly slower, relaxed
        description="Soothing, steady delivery for relaxation",
    ),
    Emotion.ANXIOUS: EmotionProfile(
        stability=0.35,  # More variation shows nervousness
        similarity_boost=0.7,
        style=0.4,  # Higher style for tension
        speed=1.12,  # Faster, more urgent
        description="Tense, slightly rushed delivery",
    ),
    Emotion.ANGRY: EmotionProfile(
        stability=0.45,  # Some variation for intensity
        similarity_boost=0.85,
        style=0.5,  # Strong style for emphasis
        speed=1.08,  # Slightly faster
        description="Forceful, emphatic delivery with intensity",
    ),
    Emotion.NEUTRAL: EmotionProfile(
        stability=0.5,  # Balanced
        similarity_boost=0.75,
        style=0.0,  # No style exaggeration
        speed=1.0,  # Normal speed
        description="Natural, balanced delivery",
    ),
    Emotion.EXCITED: EmotionProfile(
        stability=0.3,  # High variation for enthusiasm
        similarity_boost=0.8,
        style=0.45,  # Strong style
        speed=1.18,  # Noticeably faster
        description="Enthusiastic, energetic delivery with high variation",
    ),
    Emotion.EMPATHETIC: EmotionProfile(
        stability=0.55,  # Moderate stability for warmth
        similarity_boost=0.8,
        style=0.25,  # Some style for expressiveness
        speed=0.95,  # Slightly slower, more thoughtful
        description="Warm, understanding delivery with gentle pace",
    ),
    Emotion.SURPRISED: EmotionProfile(
        stability=0.4,  # Variation for expressiveness
        similarity_boost=0.75,
        style=0.4,  # Noticeable style
        speed=1.05,  # Slightly faster
        description="Expressive delivery with surprise inflection",
    ),
    Emotion.THOUGHTFUL: EmotionProfile(
        stability=0.6,  # Measured, considered
        similarity_boost=0.75,
        style=0.15,  # Subtle style
        speed=0.92,  # Slower, more deliberate
        description="Contemplative, measured delivery",
    ),
}


# =============================================================================
# Emotion Applicator
# =============================================================================


class EmotionApplicator:
    """
    Applies emotion-based adjustments to TTS voice settings.

    Maps emotions from LLM responses to voice parameter adjustments.
    Supports intensity control and custom emotion profiles.

    Example:
        applicator = EmotionApplicator()

        # Get voice settings for an emotion
        settings = applicator.get_settings_for_emotion(Emotion.EMPATHETIC)

        # Apply emotion to existing settings
        adjusted = applicator.apply_emotion(
            base_settings=VoiceSettings(),
            emotion=Emotion.HAPPY,
            intensity=0.8,
        )
    """

    def __init__(
        self,
        config: Optional[EmotionConfig] = None,
        custom_profiles: Optional[Dict[Emotion, EmotionProfile]] = None,
    ):
        """
        Initialize emotion applicator.

        Args:
            config: Emotion configuration
            custom_profiles: Custom emotion profiles (override defaults)
        """
        self.config = config or EmotionConfig()

        # Build profiles: start with defaults, override with custom
        self.profiles = DEFAULT_EMOTION_PROFILES.copy()
        if custom_profiles:
            self.profiles.update(custom_profiles)

        # Load custom mappings from config
        if self.config.custom_mappings:
            for emotion_name, settings in self.config.custom_mappings.items():
                try:
                    emotion = Emotion(emotion_name)
                    self.profiles[emotion] = EmotionProfile(
                        stability=settings.get("stability", 0.5),
                        similarity_boost=settings.get("similarity_boost", 0.75),
                        style=settings.get("style", 0.0),
                        speed=settings.get("speed", 1.0),
                    )
                except ValueError:
                    logger.warning(f"Unknown emotion in custom mappings: {emotion_name}")

    def get_profile(self, emotion: Emotion) -> EmotionProfile:
        """
        Get emotion profile.

        Args:
            emotion: Emotion enum value

        Returns:
            EmotionProfile for the emotion
        """
        return self.profiles.get(emotion, self.profiles[Emotion.NEUTRAL])

    def get_settings_for_emotion(
        self,
        emotion: Emotion,
        intensity: Optional[float] = None,
    ) -> VoiceSettings:
        """
        Get voice settings for an emotion.

        Args:
            emotion: Emotion to get settings for
            intensity: Emotion intensity (0-1), uses config default if None

        Returns:
            VoiceSettings adjusted for the emotion
        """
        profile = self.get_profile(emotion)
        base_profile = self.get_profile(Emotion.NEUTRAL)

        # Use config intensity if not specified
        if intensity is None:
            intensity = self.config.intensity

        intensity = max(0.0, min(1.0, intensity))

        # Interpolate between neutral and emotion profile based on intensity
        if intensity < 1.0:
            settings = VoiceSettings(
                stability=self._lerp(base_profile.stability, profile.stability, intensity),
                similarity_boost=self._lerp(base_profile.similarity_boost, profile.similarity_boost, intensity),
                style=self._lerp(base_profile.style, profile.style, intensity),
                speed=self._lerp(base_profile.speed, profile.speed, intensity),
            )
        else:
            settings = profile.to_voice_settings()

        # Validate voice settings are within valid ranges
        settings = self._validate_voice_settings(settings)

        return settings

    def apply_emotion(
        self,
        base_settings: VoiceSettings,
        emotion: Emotion,
        intensity: Optional[float] = None,
    ) -> VoiceSettings:
        """
        Apply emotion adjustments to existing voice settings.

        Merges base settings with emotion-based adjustments.

        Args:
            base_settings: Base voice settings to adjust
            emotion: Emotion to apply
            intensity: How strongly to apply (0-1)

        Returns:
            VoiceSettings with emotion applied
        """
        if not self.config.enabled:
            return base_settings

        emotion_settings = self.get_settings_for_emotion(emotion, intensity)

        # Use config intensity for merge weight
        if intensity is None:
            intensity = self.config.intensity

        return base_settings.merge_with(emotion_settings, weight=intensity)

    def _validate_voice_settings(self, settings: VoiceSettings) -> VoiceSettings:
        """
        Validate voice settings are within valid ranges.

        Args:
            settings: VoiceSettings to validate

        Returns:
            Validated VoiceSettings with clamped values
        """
        # ElevenLabs valid ranges:
        # stability: 0.0-1.0
        # similarity_boost: 0.0-1.0
        # style: 0.0-1.0
        # speed: 0.25-4.0

        return VoiceSettings(
            stability=max(0.0, min(1.0, settings.stability)),
            similarity_boost=max(0.0, min(1.0, settings.similarity_boost)),
            style=max(0.0, min(1.0, settings.style)),
            speed=max(0.25, min(4.0, settings.speed)),
            use_speaker_boost=settings.use_speaker_boost,
        )

    def parse_emotion(self, emotion_str: str) -> Emotion:
        """
        Parse emotion string to Emotion enum.

        Handles various formats and aliases.

        Args:
            emotion_str: Emotion string

        Returns:
            Emotion enum value (NEUTRAL if not recognized)
        """
        if not emotion_str:
            return Emotion(self.config.default_emotion)

        # Normalize string
        normalized = emotion_str.lower().strip()

        # Direct match
        try:
            return Emotion(normalized)
        except ValueError:
            pass

        # Aliases and mappings
        aliases = {
            "cheerful": Emotion.HAPPY,
            "joyful": Emotion.HAPPY,
            "content": Emotion.HAPPY,
            "pleased": Emotion.HAPPY,
            "melancholy": Emotion.SAD,
            "sorrowful": Emotion.SAD,
            "depressed": Emotion.SAD,
            "down": Emotion.SAD,
            "peaceful": Emotion.CALM,
            "relaxed": Emotion.CALM,
            "serene": Emotion.CALM,
            "tranquil": Emotion.CALM,
            "nervous": Emotion.ANXIOUS,
            "worried": Emotion.ANXIOUS,
            "stressed": Emotion.ANXIOUS,
            "tense": Emotion.ANXIOUS,
            "mad": Emotion.ANGRY,
            "furious": Emotion.ANGRY,
            "frustrated": Emotion.ANGRY,
            "irritated": Emotion.ANGRY,
            "enthusiastic": Emotion.EXCITED,
            "thrilled": Emotion.EXCITED,
            "eager": Emotion.EXCITED,
            "animated": Emotion.EXCITED,
            "understanding": Emotion.EMPATHETIC,
            "compassionate": Emotion.EMPATHETIC,
            "caring": Emotion.EMPATHETIC,
            "supportive": Emotion.EMPATHETIC,
            "sympathetic": Emotion.EMPATHETIC,
            "shocked": Emotion.SURPRISED,
            "amazed": Emotion.SURPRISED,
            "astonished": Emotion.SURPRISED,
            "contemplative": Emotion.THOUGHTFUL,
            "reflective": Emotion.THOUGHTFUL,
            "pensive": Emotion.THOUGHTFUL,
            "normal": Emotion.NEUTRAL,
            "default": Emotion.NEUTRAL,
            "none": Emotion.NEUTRAL,
        }

        if normalized in aliases:
            return aliases[normalized]

        # Log warning for unknown emotions (not just debug)
        logger.warning(
            f"Unknown emotion '{emotion_str}', defaulting to {self.config.default_emotion}",
            extra={"emotion_str": emotion_str, "normalized": normalized},
        )
        return Emotion(self.config.default_emotion)

    def _lerp(self, a: float, b: float, t: float) -> float:
        """Linear interpolation between a and b by t."""
        return a + (b - a) * t

    def get_emotion_description(self, emotion: Emotion) -> str:
        """
        Get human-readable description of emotion settings.

        Args:
            emotion: Emotion to describe

        Returns:
            Description string
        """
        profile = self.get_profile(emotion)
        return profile.description or f"{emotion.value} emotion"

    def list_supported_emotions(self) -> Dict[str, str]:
        """
        List all supported emotions with descriptions.

        Returns:
            Dict mapping emotion names to descriptions
        """
        return {emotion.value: self.get_emotion_description(emotion) for emotion in Emotion}


# =============================================================================
# Utility Functions
# =============================================================================


def get_default_applicator() -> EmotionApplicator:
    """
    Get default emotion applicator instance.

    Returns:
        EmotionApplicator with default settings
    """
    return EmotionApplicator()


def apply_emotion_to_text(
    text: str,
    emotion: Emotion,
    add_markers: bool = True,
) -> str:
    """
    Optionally add emotion markers to text.

    Some TTS models interpret text cues for emotion.
    This adds subtle markers that may influence synthesis.

    Args:
        text: Original text
        emotion: Emotion to apply
        add_markers: Whether to add markers

    Returns:
        Text with optional emotion markers

    Note:
        This is primarily for models that interpret text cues.
        ElevenLabs interprets punctuation and context.
    """
    if not add_markers:
        return text

    # Add subtle markers based on emotion (reserved for future use)
    # These influence models that interpret text cues
    _markers = {
        Emotion.HAPPY: "",  # Exclamation marks in text already help
        Emotion.SAD: "",  # Period-heavy text already helps
        Emotion.EXCITED: "",  # Exclamation marks help
        Emotion.CALM: "",  # Commas and periods help
        Emotion.EMPATHETIC: "",  # Natural phrasing is usually best
    }

    # For most emotions, the text itself should convey the emotion
    # Adding artificial markers often sounds unnatural
    return text
