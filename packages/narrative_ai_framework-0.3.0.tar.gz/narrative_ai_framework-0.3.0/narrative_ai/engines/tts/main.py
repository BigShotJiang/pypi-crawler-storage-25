"""
TTS Engine CLI - Synthesize speech directly.

Usage:
    python -m narrative_ai.engines.tts "Hello, world"
    python -m narrative_ai.engines.tts "مرحبا" --output greeting.mp3
    python -m narrative_ai.engines.tts "Hello" --voice 21m00Tcm4TlvDq8ikWAM
    python -m narrative_ai.engines.tts "Hello" --provider openai --voice nova
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys

# Ensure project root is on path and load .env
if "__file__" in dir():
    _root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    if _root not in sys.path:
        sys.path.insert(0, _root)
    _env_path = os.path.join(_root, ".env")
    if os.path.isfile(_env_path):
        try:
            from dotenv import load_dotenv

            load_dotenv(_env_path, override=False)
        except ImportError:
            pass


async def _run(
    text: str,
    output: str = "tts_output.mp3",
    provider: str | None = None,
    voice: str | None = None,
    emotion: str | None = None,
) -> int:
    """Run TTS on text and save to file."""
    from narrative_ai.engines.tts import create_tts_engine_from_providers

    if not text.strip():
        print("Error: Text is empty", file=sys.stderr)
        return 1

    engine = await create_tts_engine_from_providers(auto_initialize=True)

    try:
        result = await engine.synthesize(
            text=text.strip(),
            provider=provider,
            voice_id=voice,
            emotion=emotion,
        )

        with open(output, "wb") as f:
            f.write(result.audio)

        print(f"Saved to {os.path.abspath(output)}")
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    finally:
        await engine.shutdown()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Synthesize speech with TTS engine (uses config/providers.yml)",
    )
    parser.add_argument("text", help="Text to synthesize")
    parser.add_argument(
        "-o",
        "--output",
        default="tts_output.mp3",
        help="Output file path (default: tts_output.mp3)",
    )
    parser.add_argument(
        "--provider",
        choices=["elevenlabs", "openai", "google"],
        default=None,
        help="Force TTS provider (default: from config)",
    )
    parser.add_argument(
        "-v",
        "--voice",
        default=None,
        help="Voice ID (ElevenLabs: e.g. 21m00Tcm4TlvDq8ikWAM (Rachel); OpenAI: alloy, echo, nova, shimmer, etc.)",
    )
    parser.add_argument(
        "-e",
        "--emotion",
        default=None,
        help="Emotion: angry, happy, sad, calm, excited, neutral, etc.",
    )
    args = parser.parse_args()

    exit_code = asyncio.run(
        _run(
            args.text,
            output=args.output,
            provider=args.provider,
            voice=args.voice,
            emotion=args.emotion,
        )
    )
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
