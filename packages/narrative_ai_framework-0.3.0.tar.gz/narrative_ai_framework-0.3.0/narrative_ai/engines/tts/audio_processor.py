"""
TTS Audio Processor.

Handles audio format conversion, normalization, and processing
for TTS output.
"""

import io
import wave
import logging
from typing import Optional, Tuple
from dataclasses import dataclass
from enum import Enum

import numpy as np

logger = logging.getLogger(__name__)


# =============================================================================
# Constants
# =============================================================================


class AudioFormat(str, Enum):
    """Audio formats."""

    MP3 = "mp3"
    WAV = "wav"
    PCM = "pcm"
    OGG = "ogg"
    FLAC = "flac"
    OPUS = "opus"
    AAC = "aac"


@dataclass
class AudioMetadata:
    """Metadata about audio data."""

    format: str
    sample_rate: int
    channels: int
    bit_depth: int
    duration: float
    size_bytes: int

    @property
    def bitrate(self) -> int:
        """Calculate bitrate in bits per second."""
        if self.duration > 0:
            return int((self.size_bytes * 8) / self.duration)
        return 0


# =============================================================================
# Audio Processor
# =============================================================================


class TTSAudioProcessor:
    """
    Audio processor for TTS output.

    Handles:
    - Format conversion (PCM to WAV, etc.)
    - Sample rate conversion
    - Audio normalization
    - Duration calculation
    """

    def __init__(
        self,
        target_sample_rate: int = 24000,
        target_channels: int = 1,
        normalize: bool = True,
        target_loudness_db: float = -16.0,
    ):
        """
        Initialize audio processor.

        Args:
            target_sample_rate: Target sample rate in Hz
            target_channels: Target number of channels (1=mono, 2=stereo)
            normalize: Whether to normalize audio levels
            target_loudness_db: Target loudness in dB (LUFS approximation)
        """
        self.target_sample_rate = target_sample_rate
        self.target_channels = target_channels
        self.normalize = normalize
        self.target_loudness_db = target_loudness_db

    def pcm_to_wav(
        self,
        pcm_data: bytes,
        sample_rate: int,
        channels: int = 1,
        bit_depth: int = 16,
    ) -> bytes:
        """
        Convert raw PCM data to WAV format.

        Args:
            pcm_data: Raw PCM audio bytes
            sample_rate: Sample rate in Hz
            channels: Number of audio channels
            bit_depth: Bits per sample (usually 16)

        Returns:
            WAV file as bytes
        """
        wav_buffer = io.BytesIO()

        with wave.open(wav_buffer, "wb") as wav_file:
            wav_file.setnchannels(channels)
            wav_file.setsampwidth(bit_depth // 8)
            wav_file.setframerate(sample_rate)
            wav_file.writeframes(pcm_data)

        return wav_buffer.getvalue()

    def wav_to_pcm(self, wav_data: bytes) -> Tuple[bytes, int, int]:
        """
        Extract raw PCM from WAV file.

        Args:
            wav_data: WAV file bytes

        Returns:
            Tuple of (pcm_data, sample_rate, channels)
        """
        wav_buffer = io.BytesIO(wav_data)

        with wave.open(wav_buffer, "rb") as wav_file:
            sample_rate = wav_file.getframerate()
            channels = wav_file.getnchannels()
            pcm_data = wav_file.readframes(wav_file.getnframes())

        return pcm_data, sample_rate, channels

    def get_audio_duration(
        self,
        audio_data: bytes,
        sample_rate: int,
        format: str = "pcm",
        bit_depth: int = 16,
        channels: int = 1,
    ) -> float:
        """
        Calculate audio duration in seconds.

        Args:
            audio_data: Audio bytes
            sample_rate: Sample rate in Hz
            format: Audio format
            bit_depth: Bits per sample
            channels: Number of channels

        Returns:
            Duration in seconds
        """
        if format.lower() == "wav":
            try:
                wav_buffer = io.BytesIO(audio_data)
                with wave.open(wav_buffer, "rb") as wav:
                    frames = wav.getnframes()
                    rate = wav.getframerate()
                    return frames / rate if rate > 0 else 0.0
            except Exception:
                pass

        # For PCM, calculate from bytes
        bytes_per_sample = bit_depth // 8
        samples = len(audio_data) // (bytes_per_sample * channels)
        return samples / sample_rate if sample_rate > 0 else 0.0

    def get_metadata(
        self,
        audio_data: bytes,
        format: str = "pcm",
        sample_rate: int = 24000,
        channels: int = 1,
        bit_depth: int = 16,
    ) -> AudioMetadata:
        """
        Get metadata for audio data.

        Args:
            audio_data: Audio bytes
            format: Audio format
            sample_rate: Sample rate (for PCM)
            channels: Channels (for PCM)
            bit_depth: Bit depth (for PCM)

        Returns:
            AudioMetadata object
        """
        # Try to extract from WAV header
        if format.lower() == "wav" or audio_data[:4] == b"RIFF":
            try:
                wav_buffer = io.BytesIO(audio_data)
                with wave.open(wav_buffer, "rb") as wav:
                    sample_rate = wav.getframerate()
                    channels = wav.getnchannels()
                    bit_depth = wav.getsampwidth() * 8
                    frames = wav.getnframes()
                    duration = frames / sample_rate if sample_rate > 0 else 0.0

                    return AudioMetadata(
                        format="wav",
                        sample_rate=sample_rate,
                        channels=channels,
                        bit_depth=bit_depth,
                        duration=duration,
                        size_bytes=len(audio_data),
                    )
            except Exception:
                pass

        # Calculate for PCM or other formats
        duration = self.get_audio_duration(audio_data, sample_rate, format, bit_depth, channels)

        return AudioMetadata(
            format=format,
            sample_rate=sample_rate,
            channels=channels,
            bit_depth=bit_depth,
            duration=duration,
            size_bytes=len(audio_data),
        )

    def bytes_to_array(
        self,
        audio_bytes: bytes,
        bit_depth: int = 16,
    ) -> np.ndarray:
        """
        Convert audio bytes to numpy array.

        Args:
            audio_bytes: Raw audio bytes
            bit_depth: Bits per sample

        Returns:
            Numpy array of audio samples (float32, -1 to 1)
        """
        if bit_depth == 16:
            dtype = np.int16
            max_val = 32768.0
        elif bit_depth == 32:
            dtype = np.int32
            max_val = 2147483648.0
        elif bit_depth == 8:
            dtype = np.uint8
            max_val = 128.0
        else:
            raise ValueError(f"Unsupported bit depth: {bit_depth}")

        audio_array = np.frombuffer(audio_bytes, dtype=dtype)

        if bit_depth == 8:
            audio_array = audio_array.astype(np.float32) - 128.0
            audio_array = audio_array / max_val
        else:
            audio_array = audio_array.astype(np.float32) / max_val

        return audio_array

    def array_to_bytes(
        self,
        audio_array: np.ndarray,
        bit_depth: int = 16,
    ) -> bytes:
        """
        Convert numpy array to audio bytes.

        Args:
            audio_array: Numpy array (float32, -1 to 1)
            bit_depth: Target bits per sample

        Returns:
            Audio bytes
        """
        # Clip to valid range
        audio_array = np.clip(audio_array, -1.0, 1.0)

        if bit_depth == 16:
            dtype = np.int16
            max_val = 32767
        elif bit_depth == 32:
            dtype = np.int32
            max_val = 2147483647
        else:
            raise ValueError(f"Unsupported bit depth: {bit_depth}")

        audio_int = (audio_array * max_val).astype(dtype)
        return audio_int.tobytes()

    def normalize_audio(
        self,
        audio_array: np.ndarray,
        target_db: Optional[float] = None,
    ) -> np.ndarray:
        """
        Normalize audio levels using RMS-based normalization.

        **Note**: This uses RMS (Root Mean Square) normalization, not LUFS
        (Loudness Units relative to Full Scale). For broadcast-standard LUFS
        normalization, use `normalize_audio_lufs()` method (requires pyloudnorm).

        Args:
            audio_array: Input audio array
            target_db: Target loudness in dB (uses instance default if None)

        Returns:
            Normalized audio array

        See Also:
            normalize_audio_lufs() for LUFS-based normalization
        """
        if target_db is None:
            target_db = self.target_loudness_db

        # Calculate current RMS
        rms = np.sqrt(np.mean(audio_array**2))

        if rms < 1e-10:
            return audio_array

        # Calculate current dB
        current_db = 20 * np.log10(rms)

        # Calculate gain
        gain_db = target_db - current_db
        gain = 10 ** (gain_db / 20)

        # Apply gain with clipping protection
        normalized = audio_array * gain
        normalized = np.clip(normalized, -1.0, 1.0)

        return normalized

    def normalize_audio_lufs(
        self,
        audio_array: np.ndarray,
        target_lufs: float = -16.0,
        sample_rate: int = 24000,
    ) -> np.ndarray:
        """
        Normalize audio using LUFS (Loudness Units relative to Full Scale).

        LUFS is the industry standard for audio loudness normalization.
        Requires the loudness package: pip install loudness

        Args:
            audio_array: Input audio array (float32, -1 to 1)
            target_lufs: Target loudness in LUFS (default: -16.0, broadcast standard)
            sample_rate: Sample rate in Hz

        Returns:
            Normalized audio array

        Raises:
            ImportError: If loudness package is not installed
        """
        try:
            import loudness

            meter = loudness.Meter(sample_rate)
            loudness_lufs = meter.integrated_loudness(audio_array)

            if loudness_lufs == float("-inf"):
                # Silent audio, return as-is
                return audio_array

            # Calculate gain
            gain_db = target_lufs - loudness_lufs
            gain = 10 ** (gain_db / 20)

            # Apply gain with clipping protection
            normalized = audio_array * gain
            normalized = np.clip(normalized, -1.0, 1.0)

            return normalized
        except ImportError:
            raise ImportError("loudness package required for LUFS normalization. Install with: pip install loudness")

    def resample(
        self,
        audio_array: np.ndarray,
        original_sr: int,
        target_sr: int,
    ) -> np.ndarray:
        """
        Resample audio to different sample rate.

        Args:
            audio_array: Input audio
            original_sr: Original sample rate
            target_sr: Target sample rate

        Returns:
            Resampled audio
        """
        if original_sr == target_sr:
            return audio_array

        # Try librosa first
        try:
            import librosa

            return librosa.resample(
                audio_array,
                orig_sr=original_sr,
                target_sr=target_sr,
            )
        except ImportError:
            pass

        # Fallback to scipy
        try:
            from scipy import signal

            num_samples = int(len(audio_array) * target_sr / original_sr)
            return signal.resample(audio_array, num_samples)
        except ImportError:
            pass

        # Simple linear interpolation fallback
        ratio = target_sr / original_sr
        new_length = int(len(audio_array) * ratio)
        indices = np.linspace(0, len(audio_array) - 1, new_length)
        return np.interp(indices, np.arange(len(audio_array)), audio_array)

    def to_mono(self, audio_array: np.ndarray) -> np.ndarray:
        """
        Convert stereo audio to mono.

        Args:
            audio_array: Input audio (may be 1D or 2D)

        Returns:
            Mono audio array
        """
        if audio_array.ndim == 1:
            return audio_array

        if audio_array.ndim == 2:
            if audio_array.shape[0] == 2:
                # Shape is (channels, samples)
                return np.mean(audio_array, axis=0)
            elif audio_array.shape[1] == 2:
                # Shape is (samples, channels)
                return np.mean(audio_array, axis=1)

        return audio_array

    def process(
        self,
        audio_bytes: bytes,
        input_sample_rate: int,
        input_format: str = "pcm",
        output_format: str = "pcm",
    ) -> Tuple[bytes, int]:
        """
        Process audio with resampling and normalization.

        Args:
            audio_bytes: Input audio bytes
            input_sample_rate: Input sample rate
            input_format: Input format
            output_format: Output format

        Returns:
            Tuple of (processed_audio_bytes, output_sample_rate)
        """
        # Extract PCM if WAV
        if input_format.lower() == "wav":
            pcm_data, input_sample_rate, channels = self.wav_to_pcm(audio_bytes)
        else:
            pcm_data = audio_bytes

        # Convert to array
        audio_array = self.bytes_to_array(pcm_data)

        # Convert to mono if needed
        audio_array = self.to_mono(audio_array)

        # Resample if needed
        if input_sample_rate != self.target_sample_rate:
            audio_array = self.resample(
                audio_array,
                input_sample_rate,
                self.target_sample_rate,
            )

        # Normalize if enabled
        if self.normalize:
            audio_array = self.normalize_audio(audio_array)

        # Convert back to bytes
        output_bytes = self.array_to_bytes(audio_array)

        # Convert to WAV if requested
        if output_format.lower() == "wav":
            output_bytes = self.pcm_to_wav(
                output_bytes,
                self.target_sample_rate,
                self.target_channels,
            )

        return output_bytes, self.target_sample_rate


# =============================================================================
# Utility Functions
# =============================================================================


def detect_format(audio_data: bytes) -> str:
    """
    Detect audio format from magic bytes.

    Args:
        audio_data: Audio file bytes

    Returns:
        Format string or 'unknown'
    """
    if len(audio_data) < 12:
        return "unknown"

    # Check magic bytes
    if audio_data[:4] == b"RIFF" and audio_data[8:12] == b"WAVE":
        return "wav"
    # MP3: ID3 header or frame sync (\xff\xfb, \xff\xfa, \xff\xf3, \xff\xf2)
    if audio_data[:3] == b"ID3":
        return "mp3"
    if len(audio_data) >= 2 and audio_data[:2] in (b"\xff\xfb", b"\xff\xfa", b"\xff\xf3", b"\xff\xf2"):
        return "mp3"
    if audio_data[:4] == b"OggS":
        return "ogg"
    if audio_data[:4] == b"fLaC":
        return "flac"
    if audio_data[:4] == b"OpuS":
        return "opus"
    # M4A/MP4: ftyp at offset 4
    if len(audio_data) >= 12 and audio_data[4:8] == b"ftyp":
        return "m4a"
    # WebM: EBML header
    if audio_data[:4] == bytes([0x1A, 0x45, 0xDF, 0xA3]):
        return "webm"

    return "unknown"


def calculate_duration_estimate(
    text: str,
    words_per_minute: int = 150,
) -> float:
    """
    Estimate audio duration from text.

    Args:
        text: Input text
        words_per_minute: Average speech rate

    Returns:
        Estimated duration in seconds
    """
    word_count = len(text.split())
    return (word_count / words_per_minute) * 60


def format_duration(seconds: float) -> str:
    """
    Format duration as human-readable string.

    Args:
        seconds: Duration in seconds

    Returns:
        Formatted string like "1:23" or "0:05"
    """
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    return f"{minutes}:{secs:02d}"


def get_elevenlabs_format_code(
    format: str,
    sample_rate: int,
    bitrate: int = 128,
) -> str:
    """
    Get ElevenLabs format code.

    ElevenLabs uses format codes like "mp3_44100_128" or "pcm_24000".

    Args:
        format: Audio format (mp3, pcm, etc.)
        sample_rate: Sample rate in Hz
        bitrate: Bitrate in kbps (for mp3)

    Returns:
        ElevenLabs format code string
    """
    format = format.lower()

    if format == "mp3":
        return f"mp3_{sample_rate}_{bitrate}"
    elif format in ("pcm", "wav"):
        return f"pcm_{sample_rate}"
    elif format == "ulaw":
        return "ulaw_8000"
    elif format == "alaw":
        return "alaw_8000"
    else:
        return f"{format}_{sample_rate}"


def parse_elevenlabs_format_code(format_code: str) -> Tuple[str, int, Optional[int]]:
    """
    Parse ElevenLabs format code.

    Args:
        format_code: Format code like "mp3_44100_128"

    Returns:
        Tuple of (format, sample_rate, bitrate or None)
    """
    parts = format_code.split("_")

    if len(parts) >= 2:
        format = parts[0]
        sample_rate = int(parts[1])
        bitrate = int(parts[2]) if len(parts) >= 3 else None
        return format, sample_rate, bitrate

    return format_code, 44100, None
