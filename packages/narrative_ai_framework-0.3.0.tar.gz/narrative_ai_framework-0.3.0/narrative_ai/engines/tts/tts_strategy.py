"""
TTS Strategy - Provider Selection and Fallback Logic.

Production-ready implementation with:
- Configurable circuit breaker settings
- Correlation ID propagation
- Structured logging
- Better error classification
"""

import asyncio
import time
import logging
import threading
from dataclasses import dataclass
from typing import Optional, Dict, List, Any, AsyncIterator

from .base_tts import (
    BaseTTSProvider,
    TTSResult,
    VoiceSettings,
    VoiceInfo,
    TTSError,
    TTSTimeoutError,
    SynthesisError,
    ProviderUnavailableError,
    is_retriable_error,
    get_metrics_exporter,
)
from .config import TTSConfig

logger = logging.getLogger(__name__)


@dataclass
class CircuitBreakerConfig:
    """
    Configuration for circuit breaker pattern.

    Attributes:
        failure_threshold: Number of failures before opening circuit
        recovery_timeout: Seconds to wait before attempting recovery
        half_open_max_calls: Max calls in half-open state
    """

    failure_threshold: int = 3
    recovery_timeout: float = 60.0
    half_open_max_calls: int = 1


class TTSStrategy:
    """
    Strategy manager for TTS providers with fallback support.

    Production Features:
    - Configurable circuit breaker
    - Correlation ID propagation for tracing
    - Structured logging
    - Metrics export
    - Better error classification for retry decisions

    Example:
        strategy = TTSStrategy(
            providers={"elevenlabs": elevenlabs_provider, "openai": openai_provider},
            primary="elevenlabs",
            fallback_order=["openai"],
            language_routing={"ar": "egtts"},
            circuit_breaker_config=CircuitBreakerConfig(
                failure_threshold=5,
                recovery_timeout=120.0,
            ),
        )

        result = await strategy.synthesize(text, voice_id, correlation_id="req-123")
    """

    def __init__(
        self,
        providers: Dict[str, BaseTTSProvider],
        primary: str = "elevenlabs",
        fallback_order: Optional[List[str]] = None,
        language_routing: Optional[Dict[str, str]] = None,
        enable_fallback: bool = True,
        circuit_breaker_config: Optional[CircuitBreakerConfig] = None,
        allow_degraded_mode: bool = False,
    ):
        """
        Initialize TTS strategy.

        Args:
            providers: Dict of provider name -> provider instance
            primary: Name of primary provider
            fallback_order: Order of fallback providers (after primary)
            language_routing: Language code -> provider name routing
            enable_fallback: Whether to enable automatic fallback
            circuit_breaker_config: Circuit breaker configuration
            allow_degraded_mode: Return degraded result instead of raising when all providers fail
        """
        self.providers = providers
        self.primary = primary
        self.fallback_order = fallback_order or list(p for p in providers.keys() if p != primary)
        self.language_routing = language_routing or {}
        self.enable_fallback = enable_fallback
        self.allow_degraded_mode = allow_degraded_mode

        # Circuit breaker config
        self._cb_config = circuit_breaker_config or CircuitBreakerConfig()

        # Provider health tracking
        self._provider_failures: Dict[str, int] = {name: 0 for name in providers}
        self._provider_last_failure: Dict[str, float] = {}
        self._provider_last_success: Dict[str, float] = {}
        self._half_open_requests: Dict[str, int] = {}  # Track concurrent requests in half-open state
        self._half_open_lock = threading.Lock()  # Protect half-open state transitions

        # Metrics
        self._metrics = get_metrics_exporter()

    @classmethod
    def from_config(cls, config: TTSConfig) -> "TTSStrategy":
        """
        Create strategy from configuration.

        Args:
            config: TTS configuration

        Returns:
            Configured TTSStrategy instance
        """
        from .elevenlabs_tts import ElevenLabsTTSProvider

        providers: Dict[str, BaseTTSProvider] = {}

        # ElevenLabs
        if config.elevenlabs.api_key:
            providers["elevenlabs"] = ElevenLabsTTSProvider(config.elevenlabs)

        # OpenAI
        try:
            from .openai_tts import OpenAITTSProvider

            if config.openai.api_key:
                providers["openai"] = OpenAITTSProvider(config.openai)
        except ImportError:
            logger.debug("OpenAI TTS provider not available")

        # EGTTS
        try:
            from .egtts import EGTTSProvider

            if config.egtts.model_path:
                providers["egtts"] = EGTTSProvider(config.egtts)
        except ImportError:
            logger.debug("EGTTS provider not available")

        return cls(
            providers=providers,
            primary=config.primary_provider,
            fallback_order=config.fallback_providers,
            language_routing=config.language_routing,
            allow_degraded_mode=config.allow_degraded_mode,
        )

    async def initialize(self) -> None:
        """Initialize all providers."""
        for name, provider in self.providers.items():
            try:
                if provider.is_available():
                    await provider.load_model()
                    logger.info("Initialized TTS provider", extra={"provider": name})
            except Exception as e:
                logger.warning("Failed to initialize TTS provider", extra={"provider": name, "error": str(e)})

    async def shutdown(self) -> None:
        """Shutdown all providers."""
        for name, provider in self.providers.items():
            try:
                await provider.shutdown()
                logger.info("Shutdown TTS provider", extra={"provider": name})
            except Exception as e:
                logger.warning("Failed to shutdown TTS provider", extra={"provider": name, "error": str(e)})

    def _get_provider_for_language(self, language: Optional[str]) -> Optional[str]:
        """Get preferred provider for a language."""
        if not language:
            return None

        lang = language.lower()

        if lang in self.language_routing:
            return self.language_routing[lang]

        if "-" in lang:
            base_lang = lang.split("-")[0]
            if base_lang in self.language_routing:
                return self.language_routing[base_lang]

        return None

    def _get_provider_order(self, language: Optional[str] = None) -> List[str]:
        """Get ordered list of providers to try."""
        order = []

        routed_provider = self._get_provider_for_language(language)
        if routed_provider and self._is_provider_healthy(routed_provider):
            order.append(routed_provider)

        if self.primary not in order and self._is_provider_healthy(self.primary):
            order.append(self.primary)

        for provider_name in self.fallback_order:
            if provider_name not in order and self._is_provider_healthy(provider_name):
                order.append(provider_name)

        if not order:
            order = [
                name
                for name in [self.primary] + self.fallback_order
                if name in self.providers and self.providers[name].is_available()
            ]

        return order

    def _is_provider_healthy(self, provider_name: str) -> bool:
        """
        Check if provider is healthy using circuit breaker pattern.

        States:
        - Closed: Normal operation, failures < threshold
        - Open: Circuit tripped, rejecting requests
        - Half-Open: Allowing limited requests to test recovery
        """
        if provider_name not in self.providers:
            return False

        if not self.providers[provider_name].is_available():
            return False

        failures = self._provider_failures.get(provider_name, 0)

        if failures >= self._cb_config.failure_threshold:
            last_failure = self._provider_last_failure.get(provider_name, 0)
            time_since_failure = time.time() - last_failure

            if time_since_failure < self._cb_config.recovery_timeout:
                # Circuit is open
                self._metrics.increment("tts.circuit_breaker.rejected", tags={"provider": provider_name})
                logger.debug(
                    "Circuit breaker open",
                    extra={
                        "provider": provider_name,
                        "failures": failures,
                        "time_until_retry": self._cb_config.recovery_timeout - time_since_failure,
                    },
                )
                return False
            else:
                # Half-open: check if we can allow retry (limit concurrent test requests)
                with self._half_open_lock:
                    half_open_count = self._half_open_requests.get(provider_name, 0)
                    if half_open_count >= self._cb_config.half_open_max_calls:
                        logger.debug(
                            "Circuit breaker half-open: max concurrent requests reached",
                            extra={
                                "provider": provider_name,
                                "current": half_open_count,
                                "max": self._cb_config.half_open_max_calls,
                            },
                        )
                        return False

                    # Increment half-open request count
                    self._half_open_requests[provider_name] = half_open_count + 1
                    logger.info(
                        "Circuit breaker half-open, allowing retry",
                        extra={
                            "provider": provider_name,
                            "concurrent_requests": half_open_count + 1,
                        },
                    )

        return True

    def _record_success(self, provider_name: str) -> None:
        """Record successful provider usage."""
        self._provider_failures[provider_name] = 0
        self._provider_last_success[provider_name] = time.time()
        # Reset half-open request counter on success so that the next half-open
        # cycle starts from a clean slate. This prevents leaking previous
        # half-open counts across recovery cycles.
        if provider_name in self._half_open_requests:
            self._half_open_requests[provider_name] = 0
        self._metrics.increment("tts.provider.success", tags={"provider": provider_name})

    def _record_failure(self, provider_name: str, error: Exception) -> None:
        """Record provider failure with error classification."""
        with self._half_open_lock:
            self._provider_failures[provider_name] = self._provider_failures.get(provider_name, 0) + 1
            self._provider_last_failure[provider_name] = time.time()
            # Decrement half-open counter on failure (may reopen circuit)
            if provider_name in self._half_open_requests:
                self._half_open_requests[provider_name] = max(0, self._half_open_requests[provider_name] - 1)

        failures = self._provider_failures[provider_name]
        retriable = is_retriable_error(error)

        self._metrics.increment(
            "tts.provider.failure",
            tags={
                "provider": provider_name,
                "retriable": str(retriable).lower(),
            },
        )

        if failures >= self._cb_config.failure_threshold:
            self._metrics.increment("tts.circuit_breaker.opened", tags={"provider": provider_name})
            logger.warning(
                "Circuit breaker opened",
                extra={
                    "provider": provider_name,
                    "failures": failures,
                    "recovery_timeout": self._cb_config.recovery_timeout,
                },
            )

    async def synthesize(
        self,
        text: str,
        voice_id: str,
        language: Optional[str] = None,
        voice_settings: Optional[VoiceSettings] = None,
        output_format: str = "mp3_44100_128",
        provider: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> TTSResult:
        """
        Synthesize speech with strategy and fallback.

        Args:
            text: Text to synthesize
            voice_id: Voice ID to use
            language: Language code (for routing)
            voice_settings: Voice settings
            output_format: Output format
            provider: Force specific provider (skip routing/fallback)
            correlation_id: Request correlation ID for tracing

        Returns:
            TTSResult from successful provider

        Raises:
            SynthesisError: If all providers fail
        """
        start_time = time.time()

        if provider:
            return await self._synthesize_with_provider(
                provider, text, voice_id, language, voice_settings, output_format, correlation_id
            )

        provider_order = self._get_provider_order(language)

        if not provider_order:
            # Graceful degradation: return degraded result if enabled
            if self.allow_degraded_mode:
                logger.warning(
                    "All providers unavailable, returning degraded result", extra={"correlation_id": correlation_id}
                )
                return TTSResult(
                    audio=b"",
                    format=output_format.split("_")[0] if "_" in output_format else output_format,
                    sample_rate=24000,
                    duration=0.0,
                    provider="degraded",
                    processing_time=0.0,
                    voice_id=voice_id,
                    voice_name="degraded",
                    text_length=len(text),
                    language=language,
                    metadata={"degraded": True, "reason": "All providers unavailable"},
                )
            raise ProviderUnavailableError(
                "No available TTS providers",
                provider="strategy",
                correlation_id=correlation_id,
            )

        last_error: Optional[Exception] = None
        tried_providers: List[str] = []
        total_timeout = 30.0

        for provider_name in provider_order:
            tried_providers.append(provider_name)
            remaining = total_timeout - (time.time() - start_time)
            if remaining <= 0:
                raise SynthesisError(
                    "Exceeded total timeout across providers",
                    provider=provider_name,
                    correlation_id=correlation_id,
                )

            try:
                result = await asyncio.wait_for(
                    self._synthesize_with_provider(
                        provider_name, text, voice_id, language, voice_settings, output_format, correlation_id
                    ),
                    timeout=remaining,
                )

                self._record_success(provider_name)

                # Log if we had to fallback
                if len(tried_providers) > 1:
                    logger.info(
                        "TTS succeeded after fallback",
                        extra={
                            "correlation_id": correlation_id,
                            "successful_provider": provider_name,
                            "tried_providers": tried_providers,
                        },
                    )

                return result

            except asyncio.TimeoutError:
                err = TTSTimeoutError(
                    "Provider timed out",
                    provider=provider_name,
                    correlation_id=correlation_id,
                )
                logger.warning(
                    "TTS provider timed out",
                    extra={
                        "correlation_id": correlation_id,
                        "provider": provider_name,
                    },
                )
                self._record_failure(provider_name, err)
                last_error = err
                if not self.enable_fallback:
                    raise err
            except TTSError as e:
                logger.warning(
                    "TTS provider failed",
                    extra={
                        "correlation_id": correlation_id,
                        "provider": provider_name,
                        "error": str(e),
                        "retriable": e.retriable,
                    },
                )
                self._record_failure(provider_name, e)
                last_error = e

                if not self.enable_fallback:
                    raise

                # Don't retry non-retriable errors through fallback
                if not e.retriable:
                    raise

        total_time = time.time() - start_time

        # Graceful degradation: return degraded result if enabled
        if self.allow_degraded_mode:
            logger.warning(
                "All providers failed, returning degraded result",
                extra={
                    "correlation_id": correlation_id,
                    "tried_providers": tried_providers,
                    "last_error": str(last_error),
                },
            )
            return TTSResult(
                audio=b"",
                format=output_format.split("_")[0] if "_" in output_format else output_format,
                sample_rate=24000,
                duration=0.0,
                provider="degraded",
                processing_time=total_time,
                voice_id=voice_id,
                voice_name="degraded",
                text_length=len(text),
                language=language,
                metadata={
                    "degraded": True,
                    "reason": "All providers failed",
                    "tried_providers": tried_providers,
                    "last_error": str(last_error),
                },
            )

        error = SynthesisError(
            f"All TTS providers failed after {total_time:.2f}s",
            provider="strategy",
            details={
                "tried_providers": tried_providers,
                "last_error": str(last_error),
            },
            correlation_id=correlation_id,
        )

        if last_error:
            error.__cause__ = last_error

        raise error

    async def synthesize_streaming(
        self,
        text: str,
        voice_id: str,
        language: Optional[str] = None,
        voice_settings: Optional[VoiceSettings] = None,
        output_format: str = "pcm_24000",
        provider: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[bytes]:
        """
        Stream synthesized audio with fallback.

        Note: Fallback is limited for streaming since we can't replay
        the stream. We only fallback before streaming starts.
        """
        provider_name = provider or self._get_best_available_provider(language)

        if not provider_name:
            raise ProviderUnavailableError(
                "No available TTS providers for streaming",
                provider="strategy",
                correlation_id=correlation_id,
            )

        tts_provider = self.providers.get(provider_name)

        if not tts_provider:
            raise ProviderUnavailableError(
                f"TTS provider {provider_name} not found",
                provider="strategy",
                correlation_id=correlation_id,
            )

        logger.info(
            "TTS streaming started",
            extra={
                "correlation_id": correlation_id,
                "provider": provider_name,
            },
        )

        try:
            async for chunk in tts_provider.synthesize_streaming(
                text,
                voice_id,
                language,
                voice_settings,
                output_format,
                correlation_id=correlation_id,
            ):
                yield chunk

            self._record_success(provider_name)

        except TTSError as e:
            logger.warning(
                "TTS streaming failed",
                extra={
                    "correlation_id": correlation_id,
                    "provider": provider_name,
                    "error": str(e),
                },
            )
            self._record_failure(provider_name, e)
            raise

    async def _synthesize_with_provider(
        self,
        provider_name: str,
        text: str,
        voice_id: str,
        language: Optional[str],
        voice_settings: Optional[VoiceSettings],
        output_format: str,
        correlation_id: Optional[str] = None,
    ) -> TTSResult:
        """Synthesize with specific provider."""
        provider = self.providers.get(provider_name)

        if not provider:
            raise ProviderUnavailableError(
                f"TTS provider {provider_name} not found",
                provider=provider_name,
                correlation_id=correlation_id,
            )

        if not provider.is_available():
            raise ProviderUnavailableError(
                f"TTS provider {provider_name} is not available",
                provider=provider_name,
                correlation_id=correlation_id,
            )

        logger.debug(
            "Synthesizing with provider",
            extra={
                "correlation_id": correlation_id,
                "provider": provider_name,
            },
        )

        return await provider.synthesize(
            text,
            voice_id,
            language,
            voice_settings,
            output_format,
            correlation_id=correlation_id,
        )

    def _get_best_available_provider(self, language: Optional[str] = None) -> Optional[str]:
        """Get the best available provider."""
        order = self._get_provider_order(language)
        return order[0] if order else None

    def get_provider(self, name: str) -> Optional[BaseTTSProvider]:
        """Get a specific provider."""
        return self.providers.get(name)

    def set_primary(self, provider_name: str) -> None:
        """Change primary provider."""
        if provider_name not in self.providers:
            raise ValueError(f"TTS provider {provider_name} not found")

        self.primary = provider_name
        logger.info("Changed primary TTS provider", extra={"provider": provider_name})

    def set_circuit_breaker_config(self, config: CircuitBreakerConfig) -> None:
        """
        Update circuit breaker configuration at runtime.

        Args:
            config: New circuit breaker configuration
        """
        self._cb_config = config
        logger.info(
            "Updated circuit breaker config",
            extra={
                "failure_threshold": config.failure_threshold,
                "recovery_timeout": config.recovery_timeout,
            },
        )

    def reset_circuit_breaker(self, provider_name: Optional[str] = None) -> None:
        """
        Reset circuit breaker for one or all providers.

        Args:
            provider_name: Specific provider to reset, or None for all
        """
        if provider_name:
            self._provider_failures[provider_name] = 0
            logger.info("Reset circuit breaker", extra={"provider": provider_name})
        else:
            for name in self._provider_failures:
                self._provider_failures[name] = 0
            logger.info("Reset all circuit breakers")

    def add_provider(
        self,
        name: str,
        provider: BaseTTSProvider,
        add_to_fallback: bool = True,
    ) -> None:
        """Add a new provider."""
        self.providers[name] = provider
        self._provider_failures[name] = 0

        if add_to_fallback and name not in self.fallback_order:
            self.fallback_order.append(name)

        logger.info("Added TTS provider", extra={"provider": name})

    def remove_provider(self, name: str) -> None:
        """Remove a provider."""
        if name in self.providers:
            del self.providers[name]

        if name in self._provider_failures:
            del self._provider_failures[name]

        if name in self.fallback_order:
            self.fallback_order.remove(name)

        if name == self.primary and self.fallback_order:
            self.primary = self.fallback_order[0]

        logger.info("Removed TTS provider", extra={"provider": name})

    async def get_all_voices(self) -> Dict[str, List[VoiceInfo]]:
        """Get voices from all providers."""
        all_voices = {}

        for name, provider in self.providers.items():
            try:
                if hasattr(provider, "get_voices"):
                    voices = await provider.get_voices()
                else:
                    voices = provider.get_available_voices()
                all_voices[name] = voices
            except Exception as e:
                logger.warning("Failed to get voices", extra={"provider": name, "error": str(e)})
                all_voices[name] = []

        return all_voices

    async def health_check(self) -> Dict[str, Any]:
        """Check health of all providers."""
        health = {
            "primary": self.primary,
            "fallback_order": self.fallback_order,
            "language_routing": self.language_routing,
            "circuit_breaker": {
                "failure_threshold": self._cb_config.failure_threshold,
                "recovery_timeout": self._cb_config.recovery_timeout,
            },
            "providers": {},
        }

        for name, provider in self.providers.items():
            try:
                provider_health = await provider.health_check()
                provider_health["circuit_open"] = not self._is_provider_healthy(name)
                provider_health["failure_count"] = self._provider_failures.get(name, 0)
                health["providers"][name] = provider_health
            except Exception as e:
                health["providers"][name] = {
                    "available": False,
                    "error": str(e),
                }

        return health

    def get_status(self) -> Dict[str, Any]:
        """Get current strategy status."""
        return {
            "primary": self.primary,
            "fallback_order": self.fallback_order,
            "language_routing": self.language_routing,
            "enable_fallback": self.enable_fallback,
            "circuit_breaker": {
                "failure_threshold": self._cb_config.failure_threshold,
                "recovery_timeout": self._cb_config.recovery_timeout,
            },
            "provider_order": self._get_provider_order(),
            "provider_failures": self._provider_failures.copy(),
        }
