"""
TTS Engine Configuration.

Centralized configuration for all TTS providers, emotion settings,
and integration options.

Supports loading from:
- Environment variables (from_env)
- Dictionary (from_dict)
- providers.yml (from_providers_config)
"""

import os
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, TYPE_CHECKING, Callable
from enum import Enum
import logging

if TYPE_CHECKING:
    from config import ProvidersConfig

logger = logging.getLogger(__name__)


# =============================================================================
# Enums
# =============================================================================


class TTSProvider(str, Enum):
    """Available TTS providers."""

    ELEVENLABS = "elevenlabs"
    OPENAI = "openai"
    EGTTS = "egtts"
    GOOGLE = "google"
    LOCAL = "local"


class OutputFormat(str, Enum):
    """Audio output formats."""

    MP3_44100_128 = "mp3_44100_128"
    MP3_44100_64 = "mp3_44100_64"
    MP3_22050_32 = "mp3_22050_32"
    PCM_16000 = "pcm_16000"
    PCM_22050 = "pcm_22050"
    PCM_24000 = "pcm_24000"
    PCM_44100 = "pcm_44100"
    ULAW_8000 = "ulaw_8000"
    WAV_44100 = "wav_44100"


# =============================================================================
# Provider Configurations
# =============================================================================


@dataclass
class ElevenLabsConfig:
    """
    Configuration for ElevenLabs TTS provider.

    ElevenLabs offers high-quality TTS with multiple models:
    - eleven_flash_v2_5: Ultra-low latency (~75ms)
    - eleven_multilingual_v2: Highest quality, 29 languages
    - eleven_turbo_v2_5: Balance of quality and speed
    """

    # API settings
    api_key: Optional[str] = None

    # Model selection
    model_id: str = "eleven_flash_v2_5"  # Fast model for real-time
    model_id_quality: str = "eleven_multilingual_v2"  # High quality
    model_id_turbo: str = "eleven_turbo_v2_5"  # Balanced

    # Default voice
    default_voice_id: str = "21m00Tcm4TlvDq8ikWAM"  # Rachel
    arabic_voice_id: Optional[str] = None  # Arabic voice if set

    # Output settings
    output_format: str = "mp3_44100_128"
    streaming_format: str = "pcm_24000"  # PCM for LiveKit

    # Request settings
    timeout: int = 30
    retry_attempts: int = 3
    retry_backoff: float = 1.0

    # Latency optimization: 0 = off (recommended; param deprecated by ElevenLabs).
    # ElevenLabs recommends Flash model + streaming instead. If set 1-4, param is
    # still sent but a deprecation warning is logged.
    optimize_streaming_latency: int = 0

    # API base URL (for custom deployments)
    api_base_url: Optional[str] = None

    def __post_init__(self):
        """Load API key from environment if not provided."""
        if self.api_key is None:
            self.api_key = os.getenv("ELEVENLABS_API_KEY")
            is_production = os.getenv("ENV", "").lower() == "production"
            if self.api_key and not is_production:
                logger.info("Loaded ElevenLabs API key from environment")
            elif not self.api_key:
                logger.warning("ElevenLabs API key not found")


# OpenAI TTS models that support true server-side streaming (stream_format sse/audio).
# Per https://platform.openai.com/docs/api-reference/audio/createSpeech
OPENAI_TTS_STREAMING_MODELS = frozenset(
    {
        "gpt-4o-mini-tts",
        "gpt-4o-mini-tts-2025-12-15",
    }
)


@dataclass
class OpenAIConfig:
    """
    Configuration for OpenAI TTS provider.

    OpenAI TTS models (per https://platform.openai.com/docs/api-reference/audio/createSpeech):
    - tts-1: Standard quality, lower latency (no streaming)
    - tts-1-hd: High definition quality (no streaming)
    - gpt-4o-mini-tts: Supports true streaming via stream_format
    - gpt-4o-mini-tts-2025-12-15: Latest variant with streaming
    """

    # API settings
    api_key: Optional[str] = None

    # Model selection
    model: str = "tts-1"
    model_hd: str = "tts-1-hd"
    model_streaming: str = "gpt-4o-mini-tts"  # Use for streaming; supports stream_format

    # Voice selection
    # Available: alloy, echo, fable, onyx, nova, shimmer
    default_voice: str = "alloy"

    # Output settings
    response_format: str = "mp3"  # mp3, opus, aac, flac, wav, pcm
    speed: float = 1.0  # 0.25 to 4.0

    # Request settings
    timeout: int = 30
    retry_attempts: int = 3

    def __post_init__(self):
        """Load API key from environment if not provided."""
        if self.api_key is None:
            self.api_key = os.getenv("OPENAI_API_KEY")
            is_production = os.getenv("ENV", "").lower() == "production"
            if self.api_key and self.api_key != "your_openai_api_key_here" and not is_production:
                logger.info("Loaded OpenAI API key from environment")


@dataclass
class EGTTSConfig:
    """
    Configuration for EGTTS V0.1 provider.

    EGTTS is a local model specialized for Egyptian Arabic,
    built on the XTTS v2 architecture from Coqui TTS.
    """

    # Model paths
    model_path: Optional[str] = None
    config_path: Optional[str] = None
    vocab_path: Optional[str] = None

    # Environment variable overrides
    model_path_env: str = "EGTTS_MODEL_PATH"

    # Reference audio for voice cloning
    speaker_audio_path: Optional[str] = None

    # Device settings
    device: str = "auto"  # auto, cuda, cpu
    use_deepspeed: bool = True

    # Inference settings
    temperature: float = 0.75
    length_penalty: float = 1.0
    repetition_penalty: float = 2.0
    top_k: int = 50
    top_p: float = 0.85

    # Output settings
    sample_rate: int = 24000  # EGTTS native sample rate

    def __post_init__(self):
        """Load model path from environment if not provided."""
        if self.model_path is None:
            self.model_path = os.getenv(self.model_path_env)
            if self.model_path:
                logger.info(f"Loaded EGTTS model path from {self.model_path_env}")


@dataclass
class GoogleConfig:
    """Configuration for Google Cloud TTS provider."""

    # Credentials
    credentials_path: Optional[str] = None
    credentials_env: str = "GOOGLE_APPLICATION_CREDENTIALS"

    # Voice settings
    language_code: str = "en-US"
    voice_name: str = "en-US-Neural2-J"
    arabic_voice_name: str = "ar-XA-Wavenet-B"

    # Audio settings
    audio_encoding: str = "MP3"  # LINEAR16, MP3, OGG_OPUS
    sample_rate: int = 24000
    speaking_rate: float = 1.0  # 0.25 to 4.0
    pitch: float = 0.0  # -20.0 to 20.0

    def __post_init__(self):
        """Load credentials from environment."""
        if self.credentials_path is None:
            self.credentials_path = os.getenv(self.credentials_env)


# =============================================================================
# Emotion Configuration
# =============================================================================


@dataclass
class EmotionConfig:
    """
    Configuration for emotion-aware TTS.

    Controls how emotions from the LLM are mapped to voice settings.
    """

    # Enable/disable emotion processing
    enabled: bool = True

    # Emotion intensity (0-1, how much to apply emotion adjustments)
    intensity: float = 0.7

    # Default emotion when none specified
    default_emotion: str = "neutral"

    # Custom emotion mappings (optional override of defaults)
    custom_mappings: Optional[Dict[str, Dict[str, float]]] = None

    def __post_init__(self):
        """Validate custom_mappings: values must be numeric and in [-1, 1]."""
        if not self.custom_mappings:
            return
        for emotion_name, settings in self.custom_mappings.items():
            if not isinstance(settings, dict):
                raise ValueError(f"custom_mappings[{emotion_name!r}] must be a dict, got {type(settings).__name__}")
            for key, val in settings.items():
                if not isinstance(val, (int, float)):
                    raise ValueError(
                        f"custom_mappings[{emotion_name!r}][{key!r}] must be numeric, got {type(val).__name__}"
                    )
                if val < -1.0 or val > 1.0:
                    raise ValueError(f"custom_mappings[{emotion_name!r}][{key!r}]={val} must be in [-1, 1]")


# =============================================================================
# Audio Configuration
# =============================================================================


@dataclass
class AudioConfig:
    """Configuration for audio processing and output."""

    # Default output settings
    default_format: str = "mp3"
    default_sample_rate: int = 24000
    default_bitrate: int = 128  # kbps

    # Streaming settings
    streaming_chunk_size: int = 4096  # bytes
    streaming_format: str = "pcm"
    streaming_sample_rate: int = 24000

    # Normalization
    normalize_audio: bool = True
    target_loudness_db: float = -16.0  # LUFS

    # Silence trimming
    trim_silence: bool = False
    silence_threshold_db: float = -40.0


# =============================================================================
# Integration Configuration
# =============================================================================


@dataclass
class IntegrationConfig:
    """Configuration for framework integration."""

    # Security layer integration
    enable_rate_limiting: bool = True
    enable_audit_logging: bool = True
    enable_input_validation: bool = True

    # User tier lookup: when user_tier is None, call (user_id, tenant_id) -> UserTier from DB/cache
    user_tier_callback: Optional[Callable[[Optional[str], Optional[str]], Any]] = None

    # Performance settings
    timeout: int = 30
    retry_attempts: int = 3
    health_check_timeout: float = 5.0  # Timeout in seconds (prevents unbounded hangs)

    # Logging
    log_synthesis_text: bool = False  # Privacy concern - don't log text
    log_performance_metrics: bool = True

    # Caching (future feature)
    enable_caching: bool = False
    cache_ttl_seconds: int = 3600


# =============================================================================
# Main Configuration
# =============================================================================


@dataclass
class TTSConfig:
    """
    Main TTS Engine configuration.

    Combines all configuration sections into a single config object.

    Example:
        config = TTSConfig(
            primary_provider="elevenlabs",
            fallback_providers=["openai"],
        )

        # Or load from environment
        config = TTSConfig.from_env()

        # Or load from providers.yml
        config = TTSConfig.from_providers_config()
    """

    # Provider selection
    primary_provider: str = "elevenlabs"
    fallback_providers: List[str] = field(default_factory=lambda: ["openai"])
    allow_degraded_mode: bool = False  # Return degraded result instead of raising when all providers fail

    # Language-based routing
    # Maps language codes to preferred providers
    language_routing: Dict[str, str] = field(
        default_factory=lambda: {
            "ar": "egtts",  # Arabic -> EGTTS
            "ar-EG": "egtts",  # Egyptian Arabic -> EGTTS
        }
    )

    # Provider-specific configs
    elevenlabs: ElevenLabsConfig = field(default_factory=ElevenLabsConfig)
    openai: OpenAIConfig = field(default_factory=OpenAIConfig)
    egtts: EGTTSConfig = field(default_factory=EGTTSConfig)
    google: GoogleConfig = field(default_factory=GoogleConfig)

    # Feature configs
    emotion: EmotionConfig = field(default_factory=EmotionConfig)
    audio: AudioConfig = field(default_factory=AudioConfig)
    integration: IntegrationConfig = field(default_factory=IntegrationConfig)

    def __post_init__(self):
        """Validate configuration."""
        valid_providers = ["elevenlabs", "openai", "egtts", "google", "local"]

        if self.primary_provider not in valid_providers:
            raise ValueError(f"Invalid primary provider: {self.primary_provider}")

        for provider in self.fallback_providers:
            if provider not in valid_providers:
                raise ValueError(f"Invalid fallback provider: {provider}")

    @classmethod
    def from_env(cls) -> "TTSConfig":
        """
        Create configuration from environment variables.

        Environment variables:
            TTS_PRIMARY_PROVIDER: Primary provider name
            TTS_FALLBACK_PROVIDERS: Comma-separated fallback providers
            ELEVENLABS_API_KEY: ElevenLabs API key
            OPENAI_API_KEY: OpenAI API key
            EGTTS_MODEL_PATH: Path to EGTTS model

        Returns:
            TTSConfig instance
        """
        config = cls()

        # Provider selection
        if primary := os.getenv("TTS_PRIMARY_PROVIDER"):
            config.primary_provider = primary

        if fallbacks := os.getenv("TTS_FALLBACK_PROVIDERS"):
            config.fallback_providers = [p.strip() for p in fallbacks.split(",")]

        # ElevenLabs settings
        if voice_id := os.getenv("ELEVENLABS_VOICE_ID"):
            config.elevenlabs.default_voice_id = voice_id

        if model_id := os.getenv("ELEVENLABS_MODEL_ID"):
            config.elevenlabs.model_id = model_id

        # Emotion settings
        if emotion_enabled := os.getenv("TTS_EMOTION_ENABLED"):
            config.emotion.enabled = emotion_enabled.lower() in ("true", "1", "yes")

        logger.info(f"Loaded TTS config from environment: primary={config.primary_provider}")

        return config

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TTSConfig":
        """
        Create configuration from dictionary.

        Args:
            data: Configuration dictionary

        Returns:
            TTSConfig instance
        """
        # Create copy to avoid mutation
        data = data.copy()

        # Extract nested configs
        elevenlabs_data = data.pop("elevenlabs", {})
        openai_data = data.pop("openai", {})
        egtts_data = data.pop("egtts", {})
        google_data = data.pop("google", {})
        emotion_data = data.pop("emotion", {})
        audio_data = data.pop("audio", {})
        integration_data = data.pop("integration", {})

        return cls(
            **data,
            elevenlabs=ElevenLabsConfig(**elevenlabs_data),
            openai=OpenAIConfig(**openai_data),
            egtts=EGTTSConfig(**egtts_data),
            google=GoogleConfig(**google_data),
            emotion=EmotionConfig(**emotion_data),
            audio=AudioConfig(**audio_data),
            integration=IntegrationConfig(**integration_data),
        )

    @classmethod
    def from_providers_config(
        cls,
        providers_config: Optional["ProvidersConfig"] = None,
    ) -> "TTSConfig":
        """
        Create configuration from providers.yml.

        This is the recommended way to configure TTS when using
        the centralized providers.yml configuration file.

        Args:
            providers_config: ProvidersConfig instance (loads default if None)

        Returns:
            TTSConfig instance configured from providers.yml
        """
        try:
            from config import ProvidersConfig, ProviderType
        except ImportError:
            logger.warning("ProvidersConfig not available, falling back to env")
            return cls.from_env()

        # Load providers config if not provided
        if providers_config is None:
            try:
                providers_config = ProvidersConfig()
            except FileNotFoundError:
                logger.warning("providers.yml not found, falling back to env")
                return cls.from_env()

        # Get TTS config section
        tts_section = providers_config._config.get("tts", {})

        # Determine primary provider (the one marked as primary: true)
        primary_provider = "elevenlabs"  # Default
        for provider_info in providers_config.get_all_providers(ProviderType.TTS):
            if provider_info.primary:
                primary_provider = provider_info.name
                break

        # Determine fallback order. When not explicitly set in providers.yml,
        # derive from enabled providers (excluding the primary) so config stays
        # in sync when new providers are added.
        explicit_fallback_order = tts_section.get("fallback_order")
        if explicit_fallback_order is not None:
            fallback_order = list(explicit_fallback_order)
        else:
            enabled_names = [
                p.name for p in providers_config.get_enabled_providers(ProviderType.TTS) if p.name != primary_provider
            ]
            fallback_order = enabled_names

        # Extract enabled fallbacks in the configured order
        enabled_fallbacks = [
            p.name
            for p in providers_config.get_enabled_providers(ProviderType.TTS)
            if p.name != primary_provider and p.name in fallback_order
        ]

        # Build ElevenLabs config
        elevenlabs_info = providers_config.get_provider("elevenlabs", ProviderType.TTS)
        elevenlabs_config = ElevenLabsConfig()
        if elevenlabs_info and elevenlabs_info.enabled:
            el_cfg = elevenlabs_info.config
            models = el_cfg.get("models", {})
            voices = el_cfg.get("voices", {})
            output = el_cfg.get("output", {})

            elevenlabs_config = ElevenLabsConfig(
                api_key=elevenlabs_info.api_key,
                model_id=models.get("default", "eleven_flash_v2_5"),
                model_id_quality=models.get("quality", "eleven_turbo_v2_5"),
                default_voice_id=voices.get("default", "21m00Tcm4TlvDq8ikWAM"),
                arabic_voice_id=voices.get("arabic"),
                output_format=output.get("format", "mp3_44100_128"),
                timeout=el_cfg.get("timeout", 30),
            )

        # Build OpenAI config
        openai_info = providers_config.get_provider("openai", ProviderType.TTS)
        openai_config = OpenAIConfig()
        if openai_info and openai_info.enabled:
            oa_cfg = openai_info.config
            models = oa_cfg.get("models", {})
            voices = oa_cfg.get("voices", {})
            output = oa_cfg.get("output", {})

            openai_config = OpenAIConfig(
                api_key=openai_info.api_key,
                model=models.get("default", "tts-1"),
                model_hd=models.get("hd", "tts-1-hd"),
                model_streaming=models.get("streaming", "gpt-4o-mini-tts"),
                default_voice=voices.get("default", "alloy"),
                speed=output.get("speed", 1.0),
            )

        # Build integration config from global settings
        global_cfg = providers_config.global_config
        integration_config = IntegrationConfig(
            timeout=global_cfg.get("default_timeout", 30),
            retry_attempts=global_cfg.get("retry", {}).get("max_attempts", 3),
            log_performance_metrics=global_cfg.get("log_performance_metrics", True),
        )

        logger.info(f"Loaded TTS config from providers.yml: primary={primary_provider}")

        return cls(
            primary_provider=primary_provider,
            fallback_providers=enabled_fallbacks,
            elevenlabs=elevenlabs_config,
            openai=openai_config,
            integration=integration_config,
        )

    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        from dataclasses import asdict

        return asdict(self)

    def get_provider_config(self, provider: str) -> Any:
        """
        Get configuration for a specific provider.

        Args:
            provider: Provider name

        Returns:
            Provider configuration object
        """
        configs = {
            "elevenlabs": self.elevenlabs,
            "openai": self.openai,
            "egtts": self.egtts,
            "google": self.google,
        }
        return configs.get(provider)
