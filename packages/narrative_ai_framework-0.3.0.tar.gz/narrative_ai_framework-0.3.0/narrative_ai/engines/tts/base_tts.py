"""
TTS Base Module - Abstract Interface and Data Classes.

Defines the core interfaces and data structures used by all TTS providers.
Following the same patterns as the STT engine for consistency.

Production-Ready Features:
- Error classification for retriability
- Structured logging support
- Correlation ID propagation
- Metrics export interface
"""

import asyncio
import time
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import (
    Optional,
    Dict,
    Any,
    List,
    AsyncIterator,
    Protocol,
)

logger = logging.getLogger(__name__)


# =============================================================================
# Enums
# =============================================================================


class Emotion(str, Enum):
    """
    Emotion types for controlling TTS voice expression.

    The LLM provides emotion alongside the response text.
    This enum maps to voice settings adjustments.
    """

    HAPPY = "happy"
    SAD = "sad"
    CALM = "calm"
    ANXIOUS = "anxious"
    ANGRY = "angry"
    NEUTRAL = "neutral"
    EXCITED = "excited"
    EMPATHETIC = "empathetic"
    SURPRISED = "surprised"
    THOUGHTFUL = "thoughtful"


class AudioFormat(str, Enum):
    """Supported audio output formats."""

    MP3 = "mp3"
    WAV = "wav"
    PCM = "pcm"
    OGG = "ogg"
    OPUS = "opus"
    ULAW = "ulaw"  # μ-law for telephony
    ALAW = "alaw"  # A-law for telephony
    FLAC = "flac"


class Language(str, Enum):
    """Supported languages for TTS."""

    ARABIC = "ar"
    ARABIC_EGYPTIAN = "ar-EG"
    ENGLISH = "en"
    ENGLISH_US = "en-US"
    ENGLISH_UK = "en-GB"
    FRENCH = "fr"
    GERMAN = "de"
    SPANISH = "es"
    ITALIAN = "it"
    PORTUGUESE = "pt"
    CHINESE = "zh"
    JAPANESE = "ja"
    KOREAN = "ko"
    HINDI = "hi"
    TURKISH = "tr"
    DUTCH = "nl"
    POLISH = "pl"
    RUSSIAN = "ru"
    MIXED = "mixed"  # Mixed language content


class ErrorSeverity(str, Enum):
    """Error severity levels for monitoring."""

    TRANSIENT = "transient"  # Temporary, retry will likely succeed
    PERMANENT = "permanent"  # Won't succeed without intervention
    DEGRADED = "degraded"  # Partial failure, fallback available


# =============================================================================
# Metrics Protocol
# =============================================================================


class MetricsExporter(Protocol):
    """Protocol for metrics export - implement for Prometheus/StatsD/DataDog."""

    def increment(self, metric: str, value: int = 1, tags: Optional[Dict[str, str]] = None) -> None:
        """Increment a counter metric."""
        ...

    def gauge(self, metric: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        """Set a gauge metric."""
        ...

    def histogram(self, metric: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        """Record a histogram value (for latencies)."""
        ...


class NoOpMetricsExporter:
    """Default no-op metrics exporter."""

    def increment(self, metric: str, value: int = 1, tags: Optional[Dict[str, str]] = None) -> None:
        pass

    def gauge(self, metric: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        pass

    def histogram(self, metric: str, value: float, tags: Optional[Dict[str, str]] = None) -> None:
        pass


# Global metrics exporter - can be replaced with real implementation
_metrics_exporter: MetricsExporter = NoOpMetricsExporter()


def set_metrics_exporter(exporter: MetricsExporter) -> None:
    """Set the global metrics exporter."""
    global _metrics_exporter
    _metrics_exporter = exporter


def get_metrics_exporter() -> MetricsExporter:
    """Get the global metrics exporter."""
    return _metrics_exporter


# =============================================================================
# Data Classes
# =============================================================================


@dataclass
class VoiceSettings:
    """
    Voice settings for controlling TTS output characteristics.

    These map to ElevenLabs voice_settings and similar provider settings.

    Attributes:
        stability: Voice stability (0-1). Higher = more consistent, lower = more expressive
        similarity_boost: How closely to match the original voice (0-1)
        style: Style exaggeration (0-1). Higher = more dramatic delivery
        use_speaker_boost: Enhance speaker clarity
        speed: Speech speed multiplier (0.5-2.0, 1.0 = normal)
    """

    stability: float = 0.5
    similarity_boost: float = 0.75
    style: float = 0.0
    use_speaker_boost: bool = True
    speed: float = 1.0

    def __post_init__(self):
        """Validate settings."""
        self.stability = max(0.0, min(1.0, self.stability))
        self.similarity_boost = max(0.0, min(1.0, self.similarity_boost))
        self.style = max(0.0, min(1.0, self.style))
        self.speed = max(0.25, min(4.0, self.speed))

    def to_elevenlabs_dict(self) -> Dict[str, Any]:
        """Convert to ElevenLabs API format (per voice_settings schema)."""
        return {
            "stability": self.stability,
            "similarity_boost": self.similarity_boost,
            "style": self.style,
            "use_speaker_boost": self.use_speaker_boost,
            "speed": self.speed,  # ElevenLabs voice_settings; default 1.0
        }

    def merge_with(self, other: "VoiceSettings", weight: float = 0.5) -> "VoiceSettings":
        """
        Merge with another VoiceSettings using weighted average.

        Args:
            other: Other VoiceSettings to merge with
            weight: Weight for the other settings (0-1)

        Returns:
            New VoiceSettings with merged values
        """
        w = max(0.0, min(1.0, weight))
        w_self = 1.0 - w

        return VoiceSettings(
            stability=self.stability * w_self + other.stability * w,
            similarity_boost=self.similarity_boost * w_self + other.similarity_boost * w,
            style=self.style * w_self + other.style * w,
            use_speaker_boost=other.use_speaker_boost if w > 0.5 else self.use_speaker_boost,
            speed=self.speed * w_self + other.speed * w,
        )


@dataclass
class VoiceInfo:
    """
    Information about an available voice.

    Attributes:
        voice_id: Unique identifier for the voice
        name: Human-readable voice name
        description: Voice description
        language: Primary language
        gender: Voice gender
        age: Voice age category
        accent: Voice accent
        provider: Provider name
        preview_url: URL to voice preview audio
        is_cloned: Whether this is a cloned voice
        labels: Additional labels/tags
    """

    voice_id: str
    name: str
    description: Optional[str] = None
    language: Optional[str] = None
    gender: Optional[str] = None
    age: Optional[str] = None
    accent: Optional[str] = None
    provider: str = "unknown"
    preview_url: Optional[str] = None
    is_cloned: bool = False
    labels: Dict[str, str] = field(default_factory=dict)


@dataclass
class TTSResult:
    """
    Result from TTS synthesis.

    Contains the generated audio and metadata.

    Attributes:
        audio: Generated audio data as bytes
        format: Audio format (mp3, wav, pcm, etc.)
        sample_rate: Sample rate in Hz
        duration: Audio duration in seconds
        provider: Provider that generated the audio
        processing_time: Time taken to generate (seconds)
        voice_id: Voice ID used
        voice_name: Voice name used
        text_length: Length of input text
        language: Language used
        emotion: Emotion applied (if any)
        correlation_id: Request correlation ID for tracing
        metadata: Additional metadata
    """

    audio: bytes
    format: str
    sample_rate: int
    duration: float
    provider: str
    processing_time: float
    voice_id: str
    voice_name: Optional[str] = None
    text_length: int = 0
    language: Optional[str] = None
    emotion: Optional[Emotion] = None
    correlation_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = field(default_factory=dict)

    @property
    def size_bytes(self) -> int:
        """Get audio size in bytes."""
        return len(self.audio) if self.audio else 0

    @property
    def size_kb(self) -> float:
        """Get audio size in kilobytes."""
        return self.size_bytes / 1024

    def save_to_file(self, path: str) -> None:
        """
        Save audio to file.

        Args:
            path: File path to save to
        """
        with open(path, "wb") as f:
            f.write(self.audio)
        logger.debug(
            "Saved audio to file",
            extra={
                "path": path,
                "size_kb": self.size_kb,
                "correlation_id": self.correlation_id,
            },
        )


@dataclass
class StreamingChunk:
    """
    A chunk of streaming audio data.

    Attributes:
        audio: Audio chunk bytes
        chunk_index: Index of this chunk
        is_final: Whether this is the final chunk
        timestamp: Timestamp when chunk was received
    """

    audio: bytes
    chunk_index: int = 0
    is_final: bool = False
    timestamp: float = field(default_factory=time.time)


# =============================================================================
# Exceptions with Retriability Classification
# =============================================================================


class TTSError(Exception):
    """
    Base exception for TTS errors.

    Includes retriability classification for production systems.
    """

    # Default: assume errors are transient unless specified
    severity: ErrorSeverity = ErrorSeverity.TRANSIENT
    retriable: bool = True

    def __init__(
        self,
        message: str,
        provider: str = "unknown",
        details: Optional[Dict[str, Any]] = None,
        correlation_id: Optional[str] = None,
    ):
        super().__init__(message)
        self.message = message
        self.provider = provider
        self.details = details or {}
        self.correlation_id = correlation_id

    def __str__(self) -> str:
        base = f"[{self.provider}] {self.message}"
        if self.correlation_id:
            base = f"[{self.correlation_id}] {base}"
        return base

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging."""
        return {
            "error_type": self.__class__.__name__,
            "message": self.message,
            "provider": self.provider,
            "severity": self.severity.value,
            "retriable": self.retriable,
            "correlation_id": self.correlation_id,
            "details": self.details,
        }


class SynthesisError(TTSError):
    """Raised when speech synthesis fails."""

    severity = ErrorSeverity.TRANSIENT
    retriable = True


class ProviderUnavailableError(TTSError):
    """Raised when a provider is not available."""

    severity = ErrorSeverity.DEGRADED
    retriable = True  # Other providers may be available


class RateLimitError(TTSError):
    """Raised when rate limit is exceeded."""

    severity = ErrorSeverity.TRANSIENT
    retriable = True  # Will succeed after waiting

    def __init__(
        self,
        message: str,
        provider: str = "unknown",
        retry_after: Optional[int] = None,
        correlation_id: Optional[str] = None,
    ):
        super().__init__(message, provider, correlation_id=correlation_id)
        self.retry_after = retry_after


class VoiceNotFoundError(TTSError):
    """Raised when requested voice is not found."""

    severity = ErrorSeverity.PERMANENT
    retriable = False  # Voice won't magically appear


class TextTooLongError(TTSError):
    """Raised when input text exceeds maximum length."""

    severity = ErrorSeverity.PERMANENT
    retriable = False  # Text won't get shorter

    def __init__(
        self,
        message: str,
        provider: str = "unknown",
        max_length: int = 0,
        actual_length: int = 0,
        correlation_id: Optional[str] = None,
    ):
        super().__init__(message, provider, correlation_id=correlation_id)
        self.max_length = max_length
        self.actual_length = actual_length


class AudioFormatError(TTSError):
    """Raised when audio format conversion fails."""

    severity = ErrorSeverity.PERMANENT
    retriable = False


class AuthenticationError(TTSError):
    """Raised when API authentication fails."""

    severity = ErrorSeverity.PERMANENT
    retriable = False  # Need new credentials


class TTSTimeoutError(TTSError):
    """Raised when a TTS request times out."""

    severity = ErrorSeverity.TRANSIENT
    retriable = True


class TTSNetworkError(TTSError):
    """Raised when a network/connection error occurs."""

    severity = ErrorSeverity.TRANSIENT
    retriable = True


# =============================================================================
# Abstract Base Class
# =============================================================================


class BaseTTSProvider(ABC):
    """
    Abstract base class for TTS providers.

    All TTS providers must implement this interface.
    Provides consistent API across ElevenLabs, EGTTS, OpenAI, etc.
    """

    # Provider constants - override in subclasses
    MAX_TEXT_LENGTH: int = 5000
    SUPPORTED_FORMATS: List[str] = ["mp3", "wav", "pcm"]
    SUPPORTED_LANGUAGES: List[str] = ["en"]

    @abstractmethod
    async def synthesize(
        self,
        text: str,
        voice_id: str,
        language: Optional[str] = None,
        voice_settings: Optional[VoiceSettings] = None,
        output_format: str = "mp3",
        sample_rate: Optional[int] = None,
        correlation_id: Optional[str] = None,
    ) -> TTSResult:
        """
        Synthesize speech from text.

        Args:
            text: Text to convert to speech
            voice_id: ID of the voice to use
            language: Language code (auto-detect if None)
            voice_settings: Voice settings for controlling output
            output_format: Audio output format
            sample_rate: Desired sample rate (provider default if None)
            correlation_id: Request correlation ID for tracing

        Returns:
            TTSResult with generated audio and metadata

        Raises:
            SynthesisError: If synthesis fails
            VoiceNotFoundError: If voice_id is invalid
            TextTooLongError: If text exceeds limit
            RateLimitError: If rate limited
        """
        pass

    @abstractmethod
    async def synthesize_streaming(
        self,
        text: str,
        voice_id: str,
        language: Optional[str] = None,
        voice_settings: Optional[VoiceSettings] = None,
        output_format: str = "mp3",
        sample_rate: Optional[int] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[bytes]:
        """
        Stream synthesized audio chunks.

        For real-time applications like LiveKit integration.

        Args:
            text: Text to convert to speech
            voice_id: ID of the voice to use
            language: Language code
            voice_settings: Voice settings
            output_format: Audio format
            sample_rate: Sample rate
            correlation_id: Request correlation ID

        Yields:
            Audio data chunks as bytes
        """
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """
        Check if provider is available and configured.

        Returns:
            True if provider can be used
        """
        pass

    @abstractmethod
    def get_provider_name(self) -> str:
        """
        Get provider name.

        Returns:
            Provider identifier string
        """
        pass

    @abstractmethod
    def get_available_voices(self) -> List[VoiceInfo]:
        """
        Get list of available voices.

        Returns:
            List of VoiceInfo objects
        """
        pass

    @abstractmethod
    def get_supported_languages(self) -> List[str]:
        """
        Get list of supported languages.

        Returns:
            List of language codes
        """
        pass

    async def load_model(self) -> None:
        """
        Load model/initialize provider.

        Override in subclasses that need initialization.
        """
        pass

    async def shutdown(self) -> None:
        """
        Cleanup provider resources.

        Override in subclasses that need cleanup.
        """
        pass

    async def health_check(self) -> Dict[str, Any]:
        """
        Perform health check on provider.

        Returns:
            Health status dict with at least 'available' key
        """
        return {
            "provider": self.get_provider_name(),
            "available": self.is_available(),
            "supported_languages": self.get_supported_languages(),
            "max_text_length": self.MAX_TEXT_LENGTH,
        }

    def validate_text(self, text: str, correlation_id: Optional[str] = None) -> None:
        """
        Validate input text.

        Args:
            text: Text to validate
            correlation_id: Request correlation ID

        Raises:
            TextTooLongError: If text exceeds maximum length
            ValueError: If text is empty or invalid
        """
        if not text:
            raise ValueError("Text cannot be empty")

        if not isinstance(text, str):
            raise ValueError("Text must be a string")

        if len(text) > self.MAX_TEXT_LENGTH:
            raise TextTooLongError(
                f"Text too long: {len(text)} > {self.MAX_TEXT_LENGTH} characters",
                provider=self.get_provider_name(),
                max_length=self.MAX_TEXT_LENGTH,
                actual_length=len(text),
                correlation_id=correlation_id,
            )

    def validate_format(self, output_format: str, correlation_id: Optional[str] = None) -> None:
        """
        Validate output format.

        Args:
            output_format: Format to validate
            correlation_id: Request correlation ID

        Raises:
            AudioFormatError: If format not supported
        """
        if output_format.lower() not in self.SUPPORTED_FORMATS:
            raise AudioFormatError(
                f"Format '{output_format}' not supported. Supported formats: {self.SUPPORTED_FORMATS}",
                provider=self.get_provider_name(),
                correlation_id=correlation_id,
            )


# =============================================================================
# Utility Functions
# =============================================================================


def estimate_duration(text: str, words_per_minute: int = 150) -> float:
    """
    Estimate audio duration from text length.

    Args:
        text: Input text
        words_per_minute: Average speech rate

    Returns:
        Estimated duration in seconds
    """
    word_count = len(text.split())
    return (word_count / words_per_minute) * 60


def get_default_voice_settings() -> VoiceSettings:
    """
    Get default voice settings.

    Returns:
        Default VoiceSettings instance
    """
    return VoiceSettings()


def normalize_language_code(language: str) -> str:
    """
    Normalize language code to standard format.

    Args:
        language: Input language code

    Returns:
        Normalized language code
    """
    if not language:
        return "en"

    # Map common variations
    mappings = {
        "arabic": "ar",
        "english": "en",
        "french": "fr",
        "german": "de",
        "spanish": "es",
        "ar-eg": "ar-EG",
        "en-us": "en-US",
        "en-gb": "en-GB",
    }

    normalized = language.lower().strip()
    return mappings.get(normalized, language)


def is_retriable_error(error: Exception) -> bool:
    """
    Check if an error is retriable.

    Args:
        error: Exception to check

    Returns:
        True if error is retriable
    """
    if isinstance(error, TTSError):
        return error.retriable

    # Network errors are generally retriable
    if isinstance(error, (asyncio.TimeoutError, ConnectionError, OSError)):
        return True

    return False
