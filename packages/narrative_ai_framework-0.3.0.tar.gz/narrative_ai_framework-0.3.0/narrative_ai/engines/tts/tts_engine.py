"""
TTS Engine - Main Orchestrator.

Production-ready implementation with:
- Thread-safe metrics using asyncio.Lock
- Correlation ID propagation for distributed tracing
- Async context manager support
- Proper exception chaining
- Structured logging
- Metrics export interface
"""

import asyncio
import time
import uuid
import logging
from collections import deque
from typing import Optional, Dict, Any, AsyncIterator, List, Union
from contextlib import asynccontextmanager

from .base_tts import (
    BaseTTSProvider,
    TTSResult,
    VoiceSettings,
    VoiceInfo,
    Emotion,
    TTSError,
    SynthesisError,
    get_metrics_exporter,
)
from .config import TTSConfig
from .emotion_applicator import EmotionApplicator
from .tts_strategy import TTSStrategy, CircuitBreakerConfig
from .audio_processor import TTSAudioProcessor

logger = logging.getLogger(__name__)


# Security layer imports - optional to allow standalone usage
_SECURITY_AVAILABLE = False
_RATE_LIMITER_AVAILABLE = False
_AUDIT_LOGGER_AVAILABLE = False
_INPUT_VALIDATOR_AVAILABLE = False
_ERROR_HANDLER_AVAILABLE = False

try:
    from narrative_ai.security.rate_limiting import (
        RateLimiter,
        EndpointCosts,
        RateLimitExceeded,
        UserTier,
    )

    _RATE_LIMITER_AVAILABLE = True
except ImportError:
    RateLimiter = None
    EndpointCosts = None
    RateLimitExceeded = None
    UserTier = None

try:
    from narrative_ai.security.audit_trail import AuditLogger, ActionType, ActionStatus

    _AUDIT_LOGGER_AVAILABLE = True
except ImportError:
    AuditLogger = None
    ActionType = None
    ActionStatus = None

try:
    from narrative_ai.security.input_validation import validate_text, ValidationError as InputValidationError

    _INPUT_VALIDATOR_AVAILABLE = True
except ImportError:
    validate_text = None
    InputValidationError = None

try:
    from narrative_ai.security.error_handling import SecureErrorHandler

    _ERROR_HANDLER_AVAILABLE = True
except ImportError:
    SecureErrorHandler = None

_SECURITY_AVAILABLE = any(
    [
        _RATE_LIMITER_AVAILABLE,
        _AUDIT_LOGGER_AVAILABLE,
        _INPUT_VALIDATOR_AVAILABLE,
        _ERROR_HANDLER_AVAILABLE,
    ]
)

if not _SECURITY_AVAILABLE:
    logger.warning("Security layer not available - running without security integration")


class TTSEngine:
    """
    Main TTS Engine - Central orchestrator for Text-to-Speech.

    Production Features:
    - Thread-safe metrics with asyncio.Lock
    - Correlation ID propagation for tracing
    - Async context manager support (async with)
    - Proper exception chaining
    - Structured logging
    - Metrics export to Prometheus/StatsD/DataDog

    Example:
        # Using context manager (recommended)
        async with TTSEngine() as engine:
            result = await engine.synthesize(
                text="Hello, how are you?",
                voice_id="21m00Tcm4TlvDq8ikWAM",
            )

        # Manual lifecycle management
        engine = TTSEngine()
        await engine.initialize()
        try:
            result = await engine.synthesize(...)
        finally:
            await engine.shutdown()
    """

    def __init__(
        self,
        config: Optional[TTSConfig] = None,
        circuit_breaker_config: Optional[CircuitBreakerConfig] = None,
    ):
        """
        Initialize TTS Engine.

        Args:
            config: Engine configuration (uses defaults/env if not provided)
            circuit_breaker_config: Circuit breaker configuration
        """
        self.config = config or TTSConfig.from_env()
        self._circuit_breaker_config = circuit_breaker_config

        # Components (lazy initialized)
        self._strategy: Optional[TTSStrategy] = None
        self._emotion_applicator: Optional[EmotionApplicator] = None
        self._audio_processor: Optional[TTSAudioProcessor] = None

        # Security components (optional)
        self._rate_limiter: Optional[Any] = None
        self._audit_logger: Optional[Any] = None
        self._error_handler: Optional[Any] = None

        # State
        self._initialized = False

        # Thread-safe metrics with lock
        self._metrics_lock = asyncio.Lock()
        self._metrics: Dict[str, Any] = {
            "syntheses": 0,
            "total_audio_duration": 0.0,
            "total_processing_time": 0.0,
            "total_characters": 0,
            "errors": 0,
            "errors_by_type": {},
            "streaming_sessions": 0,
            "latencies": deque(maxlen=1000),  # Bounded deque for percentile calculation (O(1) append)
            "total_cost": 0,  # Total cost units consumed
            "cost_by_provider": {},  # Cost per provider
        }

        # External metrics exporter
        self._external_metrics = get_metrics_exporter()

    async def __aenter__(self) -> "TTSEngine":
        """Async context manager entry."""
        await self.initialize()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.shutdown()

    async def initialize(self) -> None:
        """
        Initialize the engine and all components.

        Call this before using the engine. Safe to call multiple times.
        Implements rollback on partial failure to prevent resource leaks.
        """
        if self._initialized:
            return

        logger.info("Initializing TTS Engine...")
        start_time = time.time()

        # Track initialized components for rollback on failure
        initialized_components = []

        try:
            # Initialize emotion applicator
            if self.config.emotion.enabled:
                self._emotion_applicator = EmotionApplicator(self.config.emotion)
                initialized_components.append(("emotion_applicator", self._emotion_applicator))
                logger.info("Emotion applicator initialized")

            # Initialize audio processor
            self._audio_processor = TTSAudioProcessor(
                target_sample_rate=self.config.audio.default_sample_rate,
                normalize=self.config.audio.normalize_audio,
                target_loudness_db=self.config.audio.target_loudness_db,
            )
            initialized_components.append(("audio_processor", self._audio_processor))

            # Initialize provider strategy
            self._strategy = TTSStrategy.from_config(self.config)
            initialized_components.append(("strategy", self._strategy))

            if self._circuit_breaker_config:
                self._strategy.set_circuit_breaker_config(self._circuit_breaker_config)

            await self._strategy.initialize()

            # Initialize security components if available and enabled
            if _SECURITY_AVAILABLE:
                import os

                is_production = os.getenv("ENV", "").lower() == "production"
                skip_rate_limit = not is_production and os.getenv("VOICE_DEV_SKIP_RATE_LIMIT", "").strip() == "1"
                if self.config.integration.enable_rate_limiting and RateLimiter and not skip_rate_limit:
                    try:
                        self._rate_limiter = RateLimiter()
                        initialized_components.append(("rate_limiter", self._rate_limiter))
                        logger.info("Rate limiter initialized")
                    except Exception as e:
                        logger.warning("Failed to initialize rate limiter", extra={"error": str(e)})

                if self.config.integration.enable_audit_logging and AuditLogger:
                    try:
                        import os

                        audit_db_url = os.getenv("AUDIT_DATABASE_URL") or os.getenv("DATABASE_URL")
                        if audit_db_url:
                            self._audit_logger = AuditLogger(database_url=audit_db_url)
                            initialized_components.append(("audit_logger", self._audit_logger))
                            logger.info("Audit logger initialized")
                        else:
                            logger.warning("Audit logging enabled but DATABASE_URL not set")
                    except Exception as e:
                        logger.warning("Failed to initialize audit logger", extra={"error": str(e)})

                if SecureErrorHandler:
                    try:
                        self._error_handler = SecureErrorHandler()
                        initialized_components.append(("error_handler", self._error_handler))
                        logger.info("Secure error handler initialized")
                    except Exception as e:
                        logger.warning("Failed to initialize error handler", extra={"error": str(e)})

            self._initialized = True
            init_time = time.time() - start_time

            logger.info("TTS Engine initialized", extra={"init_time": init_time})

            self._external_metrics.gauge("tts.engine.initialized", 1)

        except Exception as e:
            # Rollback: cleanup what was initialized
            logger.error(
                "TTS Engine initialization failed, cleaning up resources",
                extra={"error": str(e), "error_type": type(e).__name__},
                exc_info=True,
            )

            for name, component in reversed(initialized_components):
                try:
                    if hasattr(component, "shutdown"):
                        await component.shutdown()
                    elif hasattr(component, "close"):
                        if asyncio.iscoroutinefunction(component.close):
                            await component.close()
                        else:
                            component.close()
                    logger.debug(f"Cleaned up {name} during rollback")
                except Exception as cleanup_error:
                    logger.error(
                        f"Failed to cleanup {name} during rollback", extra={"error": str(cleanup_error)}, exc_info=True
                    )

            # Reset state
            self._emotion_applicator = None
            self._audio_processor = None
            self._strategy = None
            self._rate_limiter = None
            self._audit_logger = None
            self._error_handler = None
            self._initialized = False

            raise

    async def shutdown(self) -> None:
        """
        Shutdown the engine and cleanup resources.

        Shuts down all components in reverse order of initialization
        to ensure proper cleanup and prevent resource leaks.
        """
        if not self._initialized:
            return

        logger.info("Shutting down TTS Engine...")

        shutdown_errors = []

        if self._strategy:
            try:
                await self._strategy.shutdown()
            except Exception as e:
                shutdown_errors.append(("strategy", str(e)))
                logger.error(f"Error shutting down strategy: {e}", exc_info=True)

        # Cleanup security components
        if self._rate_limiter:
            try:
                if hasattr(self._rate_limiter, "shutdown"):
                    await self._rate_limiter.shutdown()
            except Exception as e:
                shutdown_errors.append(("rate_limiter", str(e)))
                logger.error(f"Error shutting down rate limiter: {e}", exc_info=True)

        if self._audit_logger:
            try:
                if hasattr(self._audit_logger, "shutdown"):
                    await self._audit_logger.shutdown()
            except Exception as e:
                shutdown_errors.append(("audit_logger", str(e)))
                logger.error(f"Error shutting down audit logger: {e}", exc_info=True)

        if self._error_handler:
            try:
                if hasattr(self._error_handler, "shutdown"):
                    await self._error_handler.shutdown()
            except Exception as e:
                shutdown_errors.append(("error_handler", str(e)))
                logger.error(f"Error shutting down error handler: {e}", exc_info=True)

        # Reset all references
        self._strategy = None
        self._emotion_applicator = None
        self._audio_processor = None
        self._rate_limiter = None
        self._audit_logger = None
        self._error_handler = None
        self._initialized = False

        self._external_metrics.gauge("tts.engine.initialized", 0)

        if shutdown_errors:
            logger.warning("Some components failed to shutdown cleanly", extra={"errors": shutdown_errors})
        else:
            logger.info("TTS Engine shutdown complete")

    def _generate_correlation_id(self) -> str:
        """Generate a unique correlation ID for request tracing."""
        return f"tts-{uuid.uuid4().hex[:12]}"

    def _to_uuid(self, val: Any, name: str) -> Optional[uuid.UUID]:
        """
        Convert string/int to UUID for rate limiting and audit.
        Handles non-UUID strings (e.g. session IDs) via uuid5 fallback to prevent crash.
        """
        if val is None:
            return None
        if isinstance(val, uuid.UUID):
            return val
        try:
            return uuid.UUID(str(val))
        except (ValueError, TypeError):
            logger.debug(
                "Converting non-UUID %s to uuid5",
                name,
                extra={"input_preview": str(val)[:50], "name": name},
            )
            return uuid.uuid5(uuid.NAMESPACE_DNS, f"tts.{name}.{val}")

    def _check_rate_limit(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        user_tier: Optional["UserTier"] = None,
        correlation_id: Optional[str] = None,
    ) -> None:
        """
        Check rate limit if enabled.

        When user_id or tenant_id is None, uses shared anonymous bucket (OWASP API4)
        - all unauthenticated requests share FREE tier limits.
        """
        if not self._rate_limiter:
            return

        try:
            from narrative_ai.security.rate_limiting import UserTier

            def _resolve_uuid(val: Any, name: str, anon_namespace: str) -> uuid.UUID:
                if val is None:
                    return uuid.uuid5(uuid.NAMESPACE_DNS, anon_namespace)
                u = self._to_uuid(val, name)
                return u if u is not None else uuid.uuid5(uuid.NAMESPACE_DNS, anon_namespace)

            anon_ns = "anon.engine.tts"
            user_uuid = _resolve_uuid(user_id, "user", anon_ns)
            tenant_uuid = _resolve_uuid(tenant_id, "tenant", anon_ns)

            # Tier lookup: explicit param > callback (DB/cache) > FREE (secure default)
            if user_tier is not None:
                tier = user_tier
            else:
                cb = getattr(self.config.integration, "user_tier_callback", None)
                if cb and (user_id or tenant_id):
                    try:
                        looked_up = cb(user_id, tenant_id)
                        tier = looked_up if looked_up is not None else UserTier.FREE
                    except Exception as e:
                        logger.debug("User tier lookup failed, using FREE: %s", e)
                        tier = UserTier.FREE
                else:
                    tier = UserTier.FREE

            self._rate_limiter.check_rate_limit(
                tenant_id=tenant_uuid,
                user_id=user_uuid,
                tier=tier,
                endpoint_cost=EndpointCosts.TTS.value,
            )
        except Exception as e:
            if RateLimitExceeded and isinstance(e, RateLimitExceeded):
                self._external_metrics.increment("tts.rate_limited")
                raise
            # Fail closed: re-raise on unexpected errors (Redis down, bug, etc.)
            logger.warning(
                "Rate limit check failed",
                extra={
                    "correlation_id": correlation_id,
                    "error": str(e),
                },
            )
            raise

    def _log_audit(
        self,
        user_id: Optional[str],
        tenant_id: Optional[str],
        status: str,
        details: Dict[str, Any],
        correlation_id: Optional[str] = None,
    ) -> None:
        """Log audit event if enabled. When user/tenant is None (anonymous), uses bucket UUIDs for traceability."""
        if not self._audit_logger:
            return

        # Include correlation ID in audit
        details["correlation_id"] = correlation_id

        try:
            if user_id and tenant_id:
                uid = self._to_uuid(user_id, "user")
                tid = self._to_uuid(tenant_id, "tenant")
                if uid is None or tid is None:
                    return
            else:
                # Anonymous: use bucket UUIDs for traceability (correlation_id in details)
                tid = uuid.uuid5(uuid.NAMESPACE_DNS, "anon.engine.tts")
                uid = uuid.uuid5(uuid.NAMESPACE_DNS, f"anon.engine.tts.{correlation_id or uuid.uuid4()}")
            self._audit_logger.log_action(
                user_id=uid,
                tenant_id=tid,
                action=ActionType.CREATE,
                resource_type="tts_synthesis",
                resource_id=uuid.uuid4(),
                status=ActionStatus.SUCCESS if status == "success" else ActionStatus.FAILURE,
                details=details,
            )
        except Exception as e:
            logger.warning(
                "Audit logging failed",
                extra={
                    "correlation_id": correlation_id,
                    "error": str(e),
                },
            )

    def _validate_text_security(
        self,
        text: str,
        correlation_id: Optional[str] = None,
    ) -> str:
        """
        Validate text using security layer if available.

        Returns:
            Sanitized text (trimmed, null bytes removed) or original if validation disabled.
        """
        if not _INPUT_VALIDATOR_AVAILABLE or not validate_text:
            return text

        if not self.config.integration.enable_input_validation:
            return text

        try:
            return validate_text(
                text,
                min_length=1,
                max_length=5000,
                check_sql_injection=False,
                check_prompt_injection=False,
            )
        except Exception as e:
            logger.warning(
                "Security validation failed",
                extra={
                    "correlation_id": correlation_id,
                    "error": str(e),
                },
            )
            # Re-raise ValidationError as-is for proper exception type (API consistency)
            if InputValidationError and isinstance(e, InputValidationError):
                raise
            raise ValueError(f"Text validation failed: {e}") from e

    async def synthesize(
        self,
        text: str,
        voice_id: Optional[str] = None,
        language: Optional[str] = None,
        emotion: Optional[Union[Emotion, str]] = None,
        voice_settings: Optional[VoiceSettings] = None,
        output_format: str = "mp3_44100_128",
        provider: Optional[str] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> TTSResult:
        """
        Synthesize speech from text.

        Args:
            text: Text to convert to speech
            voice_id: Voice ID to use (uses default if not specified)
            language: Language code (for provider routing)
            emotion: Emotion to apply (Emotion enum or string)
            voice_settings: Voice settings (overrides emotion settings)
            output_format: Output format (e.g., "mp3_44100_128", "pcm_24000")
            provider: Force specific provider
            user_id: User ID for rate limiting and audit logging
            tenant_id: Tenant ID for rate limiting and audit logging
            correlation_id: Request correlation ID (auto-generated if not provided)

        Returns:
            TTSResult with generated audio and metadata
        """
        if not self._initialized:
            await self.initialize()

        # Generate correlation ID if not provided
        if not correlation_id:
            correlation_id = self._generate_correlation_id()

        start_time = time.time()

        try:
            # Check rate limit
            self._check_rate_limit(user_id, tenant_id, None, correlation_id)

            # Validate text and use sanitized result (removes null bytes, trims)
            text = self._validate_text_security(text, correlation_id)

            # Get default voice ID if not specified
            if not voice_id:
                voice_id = self.config.elevenlabs.default_voice_id or "21m00Tcm4TlvDq8ikWAM"  # Fallback to Rachel
                if not voice_id:
                    raise ValueError("No voice_id provided and default_voice_id not configured")

            # Parse emotion if string. When emotion is requested but emotion applicator is
            # disabled (config.emotion.enabled=False), we fall back to NEUTRAL so synthesis
            # proceeds without emotion-based voice adjustments.
            emotion_enum: Optional[Emotion] = None
            if emotion:
                if isinstance(emotion, str):
                    emotion_enum = (
                        self._emotion_applicator.parse_emotion(emotion) if self._emotion_applicator else Emotion.NEUTRAL
                    )
                else:
                    emotion_enum = emotion

            # Apply emotion to voice settings
            if emotion_enum and self._emotion_applicator and not voice_settings:
                voice_settings = self._emotion_applicator.get_settings_for_emotion(emotion_enum)
            elif emotion_enum and self._emotion_applicator and voice_settings:
                voice_settings = self._emotion_applicator.apply_emotion(voice_settings, emotion_enum)

            # Synthesize with strategy
            result = await self._strategy.synthesize(
                text=text,
                voice_id=voice_id,
                language=language,
                voice_settings=voice_settings,
                output_format=output_format,
                provider=provider,
                correlation_id=correlation_id,
            )

            # Add correlation ID and emotion to result
            result.correlation_id = correlation_id
            result.emotion = emotion_enum

            # Update metrics (thread-safe)
            processing_time = time.time() - start_time
            result.processing_time = processing_time

            # Track cost (TTS endpoint cost)
            endpoint_cost = EndpointCosts.TTS.value if EndpointCosts else 10
            await self._update_metrics(
                audio_duration=result.duration,
                processing_time=processing_time,
                text_length=len(text),
                success=True,
                provider=result.provider,
                cost=endpoint_cost,
            )

            # Export to external metrics
            self._external_metrics.increment("tts.synthesis.success")
            self._external_metrics.histogram("tts.synthesis.latency", processing_time)
            self._external_metrics.histogram("tts.synthesis.duration", result.duration)

            # Export cost metrics
            if _SECURITY_AVAILABLE and EndpointCosts:
                self._external_metrics.increment(
                    "tts.cost.total", value=endpoint_cost, tags={"provider": result.provider}
                )
                # Thread-safe read of accumulated cost
                async with self._metrics_lock:
                    accumulated_cost = self._metrics.get("total_cost", 0)
                self._external_metrics.gauge("tts.cost.accumulated", accumulated_cost)

            # Log audit
            self._log_audit(
                user_id,
                tenant_id,
                "success",
                {
                    "provider": result.provider,
                    "voice_id": result.voice_id,
                    "language": language,
                    "emotion": emotion_enum.value if emotion_enum else None,
                    "text_length": len(text),
                    "audio_duration": result.duration,
                    "processing_time": processing_time,
                },
                correlation_id,
            )

            if self.config.integration.log_performance_metrics:
                logger.info(
                    "TTS synthesis completed",
                    extra={
                        "correlation_id": correlation_id,
                        "provider": result.provider,
                        "text_length": len(text),
                        "duration": result.duration,
                        "processing_time": processing_time,
                    },
                )

            return result

        except TTSError as e:
            endpoint_cost = EndpointCosts.TTS.value if (EndpointCosts and _SECURITY_AVAILABLE) else 10
            await self._update_metrics(
                0, time.time() - start_time, len(text), success=False, error_type=type(e).__name__, cost=endpoint_cost
            )
            self._external_metrics.increment("tts.synthesis.error", tags={"error_type": type(e).__name__})
            self._log_audit(
                user_id, tenant_id, "failure", {"error": e.message, "error_type": type(e).__name__}, correlation_id
            )
            raise

        except Exception as e:
            endpoint_cost = EndpointCosts.TTS.value if (EndpointCosts and _SECURITY_AVAILABLE) else 10
            await self._update_metrics(
                0, time.time() - start_time, len(text), success=False, error_type=type(e).__name__, cost=endpoint_cost
            )
            self._external_metrics.increment("tts.synthesis.error", tags={"error_type": type(e).__name__})
            self._log_audit(
                user_id, tenant_id, "failure", {"error": str(e), "error_type": type(e).__name__}, correlation_id
            )

            if self._error_handler:
                try:
                    self._error_handler.handle_error(e, user_id, tenant_id)
                except Exception as handler_error:
                    logger.warning(
                        "Error handler failed",
                        extra={
                            "correlation_id": correlation_id,
                            "error": str(handler_error),
                        },
                    )

            raise SynthesisError(
                f"Synthesis failed: {e}",
                provider="engine",
                correlation_id=correlation_id,
            ) from e

    async def synthesize_streaming(
        self,
        text: str,
        voice_id: Optional[str] = None,
        language: Optional[str] = None,
        emotion: Optional[Union[Emotion, str]] = None,
        voice_settings: Optional[VoiceSettings] = None,
        output_format: str = "pcm_24000",
        provider: Optional[str] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[bytes]:
        """
        Stream synthesized audio chunks.

        Designed for real-time applications like LiveKit integration.
        """
        if not self._initialized:
            await self.initialize()

        if not correlation_id:
            correlation_id = self._generate_correlation_id()

        # Check rate limit at start
        self._check_rate_limit(user_id, tenant_id, None, correlation_id)

        # Validate text and use sanitized result
        text = self._validate_text_security(text, correlation_id)

        start_time = time.time()

        # Thread-safe increment
        async with self._metrics_lock:
            self._metrics["streaming_sessions"] += 1

        self._external_metrics.increment("tts.streaming.started")

        try:
            # Get default voice ID
            if not voice_id:
                voice_id = self.config.elevenlabs.default_voice_id or "21m00Tcm4TlvDq8ikWAM"  # Fallback to Rachel
                if not voice_id:
                    raise ValueError("No voice_id provided and default_voice_id not configured")

            # Parse emotion. When emotion applicator is disabled, falls back to NEUTRAL. See synthesize().
            emotion_enum: Optional[Emotion] = None
            if emotion:
                if isinstance(emotion, str):
                    emotion_enum = (
                        self._emotion_applicator.parse_emotion(emotion) if self._emotion_applicator else Emotion.NEUTRAL
                    )
                else:
                    emotion_enum = emotion

            # Apply emotion to voice settings (must match batch synthesize behavior)
            if emotion_enum and self._emotion_applicator and not voice_settings:
                voice_settings = self._emotion_applicator.get_settings_for_emotion(emotion_enum)
            elif emotion_enum and self._emotion_applicator and voice_settings:
                voice_settings = self._emotion_applicator.apply_emotion(voice_settings, emotion_enum)

            logger.info(
                "TTS streaming started",
                extra={
                    "correlation_id": correlation_id,
                    "text_length": len(text),
                },
            )

            first_chunk = True
            async for chunk in self._strategy.synthesize_streaming(
                text=text,
                voice_id=voice_id,
                language=language,
                voice_settings=voice_settings,
                output_format=output_format,
                provider=provider,
                correlation_id=correlation_id,
            ):
                if first_chunk:
                    time_to_first_byte = time.time() - start_time
                    first_chunk = False
                    self._external_metrics.histogram(
                        "tts.streaming.time_to_first_byte",
                        time_to_first_byte,
                        tags={"correlation_id": correlation_id} if correlation_id else None,
                    )
                yield chunk

            # Log audit on completion
            processing_time = time.time() - start_time

            # Track cost for streaming (per synthesis cost)
            endpoint_cost = EndpointCosts.VOICE_TTS_STREAM.value if (EndpointCosts and _SECURITY_AVAILABLE) else 5
            async with self._metrics_lock:
                self._metrics["total_cost"] = self._metrics.get("total_cost", 0) + endpoint_cost

            self._external_metrics.increment("tts.streaming.success")
            self._external_metrics.histogram("tts.streaming.duration", processing_time)

            # Export cost metrics
            if _SECURITY_AVAILABLE and EndpointCosts:
                self._external_metrics.increment(
                    "tts.streaming.cost.total",
                    value=endpoint_cost,
                )
                # Thread-safe read of accumulated cost
                async with self._metrics_lock:
                    accumulated_cost = self._metrics.get("total_cost", 0)
                self._external_metrics.gauge("tts.cost.accumulated", accumulated_cost)

            self._log_audit(
                user_id,
                tenant_id,
                "success",
                {
                    "type": "streaming",
                    "text_length": len(text),
                    "processing_time": processing_time,
                    "cost": endpoint_cost,
                },
                correlation_id,
            )

            logger.info(
                "TTS streaming completed",
                extra={
                    "correlation_id": correlation_id,
                    "processing_time": processing_time,
                },
            )

        except Exception as e:
            endpoint_cost = EndpointCosts.VOICE_TTS_STREAM.value if (EndpointCosts and _SECURITY_AVAILABLE) else 5
            async with self._metrics_lock:
                self._metrics["total_cost"] = self._metrics.get("total_cost", 0) + endpoint_cost

            self._external_metrics.increment("tts.streaming.error", tags={"error_type": type(e).__name__})

            # Export cost even on error (resource was consumed)
            if _SECURITY_AVAILABLE and EndpointCosts:
                self._external_metrics.increment(
                    "tts.streaming.cost.total",
                    value=endpoint_cost,
                )

            self._log_audit(
                user_id,
                tenant_id,
                "failure",
                {
                    "type": "streaming",
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "cost": endpoint_cost,
                },
                correlation_id,
            )

            logger.warning(
                "TTS streaming failed",
                extra={
                    "correlation_id": correlation_id,
                    "error": str(e),
                },
            )
            raise
        finally:
            # Always decrement streaming session counter, even on error
            async with self._metrics_lock:
                self._metrics["streaming_sessions"] = max(0, self._metrics["streaming_sessions"] - 1)

    async def get_voices(
        self,
        provider: Optional[str] = None,
    ) -> Dict[str, List[VoiceInfo]]:
        """Get available voices."""
        if not self._initialized:
            await self.initialize()

        if provider:
            prov = self._strategy.get_provider(provider)
            if prov and hasattr(prov, "get_voices"):
                voices = await prov.get_voices()
                return {provider: voices}
            return {provider: []}

        return await self._strategy.get_all_voices()

    def get_provider(self, name: str) -> Optional[BaseTTSProvider]:
        """Get specific provider instance."""
        if self._strategy:
            return self._strategy.get_provider(name)
        return None

    def set_primary_provider(self, name: str) -> None:
        """Change primary provider."""
        if self._strategy:
            self._strategy.set_primary(name)

    async def health_check(self) -> Dict[str, Any]:
        """Perform health check on engine and all providers."""
        timeout = getattr(
            self.config.integration,
            "health_check_timeout",
            5.0,
        )
        try:
            return await asyncio.wait_for(
                self._do_health_check(),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            logger.warning(f"Health check timed out after {timeout} seconds")
            return {
                "initialized": self._initialized,
                "status": "timeout",
                "error": f"Health check timed out after {timeout}s",
                "security_available": _SECURITY_AVAILABLE,
            }

    async def _do_health_check(self) -> Dict[str, Any]:
        """Internal health check implementation."""
        async with self._metrics_lock:
            metrics_copy = self._metrics.copy()
            # Don't include raw latencies in health (deque, verbose); expose count only
            latencies_deque = metrics_copy.pop("latencies", deque())
            metrics_copy["latency_sample_count"] = len(latencies_deque)

        health: Dict[str, Any] = {
            "initialized": self._initialized,
            "status": "healthy",
            "security_available": _SECURITY_AVAILABLE,
            "config": {
                "primary_provider": self.config.primary_provider,
                "emotion_enabled": self.config.emotion.enabled,
                "rate_limiting_enabled": self.config.integration.enable_rate_limiting,
                "audit_logging_enabled": self.config.integration.enable_audit_logging,
            },
            "metrics": metrics_copy,
        }

        if self._strategy:
            provider_health = await self._strategy.health_check()
            health["providers"] = provider_health
            # Degrade status if providers report issues
            if isinstance(provider_health, dict):
                for key, val in provider_health.items():
                    if isinstance(val, dict) and val.get("status") == "unhealthy":
                        health["status"] = "degraded"
                        break
        else:
            health["providers"] = {}

        return health

    async def get_metrics(self) -> Dict[str, Any]:
        """
        Get engine metrics (thread-safe).

        Returns:
            Metrics dict with averages and percentiles
        """
        async with self._metrics_lock:
            metrics = self._metrics.copy()
            latencies = metrics.pop("latencies", [])

        # Calculate averages
        if metrics["syntheses"] > 0:
            metrics["avg_processing_time"] = metrics["total_processing_time"] / metrics["syntheses"]
            metrics["avg_audio_duration"] = metrics["total_audio_duration"] / metrics["syntheses"]
            metrics["avg_characters"] = metrics["total_characters"] / metrics["syntheses"]
            metrics["realtime_factor"] = (
                metrics["total_audio_duration"] / metrics["total_processing_time"]
                if metrics["total_processing_time"] > 0
                else 0
            )

        # Calculate percentiles if we have latency data
        if latencies:
            sorted_latencies = sorted(latencies)
            n = len(sorted_latencies)
            metrics["latency_p50"] = sorted_latencies[int(n * 0.5)]
            metrics["latency_p95"] = sorted_latencies[int(n * 0.95)]
            metrics["latency_p99"] = sorted_latencies[int(n * 0.99)] if n >= 100 else sorted_latencies[-1]

        return metrics

    async def _update_metrics(
        self,
        audio_duration: float,
        processing_time: float,
        text_length: int,
        success: bool,
        error_type: Optional[str] = None,
        provider: Optional[str] = None,
        cost: int = 0,
    ) -> None:
        """Update engine metrics (thread-safe)."""
        async with self._metrics_lock:
            self._metrics["syntheses"] += 1
            self._metrics["total_audio_duration"] += audio_duration
            self._metrics["total_processing_time"] += processing_time
            self._metrics["total_characters"] += text_length

            # Track cost
            if cost > 0:
                self._metrics["total_cost"] = self._metrics.get("total_cost", 0) + cost
                if provider:
                    self._metrics["cost_by_provider"][provider] = (
                        self._metrics["cost_by_provider"].get(provider, 0) + cost
                    )

            # Append to bounded deque (auto-bounded to last 1000; no manual trim)
            self._metrics["latencies"].append(processing_time)

            if not success:
                self._metrics["errors"] += 1
                if error_type:
                    self._metrics["errors_by_type"][error_type] = self._metrics["errors_by_type"].get(error_type, 0) + 1

    async def reset_metrics(self) -> None:
        """Reset all metrics (thread-safe)."""
        async with self._metrics_lock:
            self._metrics = {
                "syntheses": 0,
                "total_audio_duration": 0.0,
                "total_processing_time": 0.0,
                "total_characters": 0,
                "errors": 0,
                "errors_by_type": {},
                "streaming_sessions": 0,
                "latencies": deque(maxlen=1000),
                "total_cost": 0,
                "cost_by_provider": {},
            }
        logger.info("TTS engine metrics reset")

    @property
    def is_initialized(self) -> bool:
        """Check if engine is initialized."""
        return self._initialized

    @property
    def security_enabled(self) -> bool:
        """Check if security layer is enabled."""
        return _SECURITY_AVAILABLE and (self._rate_limiter is not None or self._audit_logger is not None)

    def __repr__(self) -> str:
        return (
            f"TTSEngine(initialized={self._initialized}, "
            f"primary={self.config.primary_provider}, "
            f"security={self.security_enabled})"
        )


# =============================================================================
# Factory Functions
# =============================================================================


async def create_tts_engine(
    config: Optional[TTSConfig] = None,
    auto_initialize: bool = True,
    circuit_breaker_config: Optional[CircuitBreakerConfig] = None,
) -> TTSEngine:
    """
    Create and optionally initialize TTS engine.

    Args:
        config: Engine configuration
        auto_initialize: Initialize immediately
        circuit_breaker_config: Circuit breaker configuration

    Returns:
        Configured TTSEngine instance
    """
    engine = TTSEngine(config, circuit_breaker_config)

    if auto_initialize:
        await engine.initialize()

    return engine


async def create_tts_engine_from_providers(
    auto_initialize: bool = True,
    circuit_breaker_config: Optional[CircuitBreakerConfig] = None,
) -> TTSEngine:
    """
    Create TTS engine from providers.yml configuration.

    Args:
        auto_initialize: Initialize immediately (default: True)
        circuit_breaker_config: Circuit breaker configuration

    Returns:
        Configured TTSEngine instance
    """
    config = TTSConfig.from_providers_config()
    engine = TTSEngine(config, circuit_breaker_config)

    if auto_initialize:
        await engine.initialize()

    return engine


@asynccontextmanager
async def tts_engine_context(
    config: Optional[TTSConfig] = None,
    circuit_breaker_config: Optional[CircuitBreakerConfig] = None,
):
    """
    Context manager for TTS engine lifecycle.

    Example:
        async with tts_engine_context() as engine:
            result = await engine.synthesize("Hello")
    """
    engine = TTSEngine(config, circuit_breaker_config)
    await engine.initialize()
    try:
        yield engine
    finally:
        await engine.shutdown()
