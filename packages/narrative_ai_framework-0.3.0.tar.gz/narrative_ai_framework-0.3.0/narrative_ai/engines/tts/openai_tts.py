"""
OpenAI TTS Provider.

Production-ready implementation with:
- Connection pooling to prevent socket exhaustion
- Exponential backoff with jitter
- Correlation ID propagation
- Proper exception chaining
"""

import asyncio
import base64
import json
import random
import time
import logging
from typing import Optional, List, Dict, Any, AsyncIterator

from .base_tts import (
    BaseTTSProvider,
    TTSResult,
    VoiceSettings,
    VoiceInfo,
    SynthesisError,
    ProviderUnavailableError,
    RateLimitError,
    VoiceNotFoundError,
    TTSTimeoutError,
    TTSNetworkError,
)
from .config import OpenAIConfig, OPENAI_TTS_STREAMING_MODELS

logger = logging.getLogger(__name__)

# Connection pool configuration
DEFAULT_POOL_LIMIT = 100
DEFAULT_POOL_LIMIT_PER_HOST = 30


class OpenAITTSProvider(BaseTTSProvider):
    """
    OpenAI TTS provider.

    A simple, reliable TTS provider as fallback.

    Models:
    - tts-1: Standard quality, lower latency
    - tts-1-hd: High definition quality

    Voices:
    - alloy: Neutral, balanced
    - echo: Warm, conversational
    - fable: Expressive, dramatic
    - onyx: Deep, authoritative
    - nova: Friendly, upbeat
    - shimmer: Clear, professional

    Note:
    - No Arabic support
    - No streaming support (full audio returned)
    - Limited voice control

    Example:
        provider = OpenAITTSProvider(config)
        result = await provider.synthesize(
            text="Hello world",
            voice_id="alloy",
        )
    """

    BASE_URL = "https://api.openai.com/v1"
    TTS_ENDPOINT = "/audio/speech"

    # Provider constants
    MAX_TEXT_LENGTH = 4096
    SUPPORTED_FORMATS = ["mp3", "opus", "aac", "flac", "wav", "pcm"]
    SUPPORTED_LANGUAGES = ["en"]  # Primarily English

    # Available voices (per OpenAI Create Speech API: alloy, ash, ballad, coral, echo, fable, onyx, nova, sage, shimmer, verse, marin, cedar)
    VOICES = {
        "alloy": VoiceInfo(
            voice_id="alloy",
            name="Alloy",
            description="Neutral, balanced voice",
            provider="openai",
            gender="neutral",
        ),
        "ash": VoiceInfo(
            voice_id="ash",
            name="Ash",
            description="Calm, composed voice",
            provider="openai",
            gender="neutral",
        ),
        "ballad": VoiceInfo(
            voice_id="ballad",
            name="Ballad",
            description="Narrative, storytelling voice",
            provider="openai",
            gender="neutral",
        ),
        "coral": VoiceInfo(
            voice_id="coral",
            name="Coral",
            description="Warm, expressive voice",
            provider="openai",
            gender="female",
        ),
        "echo": VoiceInfo(
            voice_id="echo",
            name="Echo",
            description="Warm, conversational voice",
            provider="openai",
            gender="male",
        ),
        "fable": VoiceInfo(
            voice_id="fable",
            name="Fable",
            description="Expressive, dramatic voice",
            provider="openai",
            gender="neutral",
        ),
        "onyx": VoiceInfo(
            voice_id="onyx",
            name="Onyx",
            description="Deep, authoritative voice",
            provider="openai",
            gender="male",
        ),
        "nova": VoiceInfo(
            voice_id="nova",
            name="Nova",
            description="Friendly, upbeat voice",
            provider="openai",
            gender="female",
        ),
        "sage": VoiceInfo(
            voice_id="sage",
            name="Sage",
            description="Wise, thoughtful voice",
            provider="openai",
            gender="neutral",
        ),
        "shimmer": VoiceInfo(
            voice_id="shimmer",
            name="Shimmer",
            description="Clear, professional voice",
            provider="openai",
            gender="female",
        ),
        "verse": VoiceInfo(
            voice_id="verse",
            name="Verse",
            description="Poetic, rhythmic voice",
            provider="openai",
            gender="neutral",
        ),
        "marin": VoiceInfo(
            voice_id="marin",
            name="Marin",
            description="Smooth, articulate voice",
            provider="openai",
            gender="neutral",
        ),
        "cedar": VoiceInfo(
            voice_id="cedar",
            name="Cedar",
            description="Rich, grounded voice",
            provider="openai",
            gender="male",
        ),
    }

    def __init__(
        self,
        config: OpenAIConfig,
        pool_limit: int = DEFAULT_POOL_LIMIT,
        pool_limit_per_host: int = DEFAULT_POOL_LIMIT_PER_HOST,
    ):
        """
        Initialize OpenAI TTS provider.

        Args:
            config: OpenAI configuration
            pool_limit: Total connection pool limit
            pool_limit_per_host: Connection limit per host
        """
        self.config = config
        self._pool_limit = pool_limit
        self._pool_limit_per_host = pool_limit_per_host
        self._http_session = None
        self._connector = None
        self._is_loaded = False

    async def load_model(self) -> None:
        """Initialize HTTP session with connection pooling."""
        if self._http_session is not None:
            return

        try:
            import aiohttp

            # Create connector with pool limits
            self._connector = aiohttp.TCPConnector(
                limit=self._pool_limit,
                limit_per_host=self._pool_limit_per_host,
                ttl_dns_cache=300,
                enable_cleanup_closed=True,
            )

            timeout = aiohttp.ClientTimeout(
                total=self.config.timeout,
                connect=10,
                sock_read=30,
            )
            self._http_session = aiohttp.ClientSession(connector=self._connector, timeout=timeout)
            self._is_loaded = True
            logger.info("OpenAI TTS provider initialized")

        except ImportError:
            raise ProviderUnavailableError(
                "aiohttp required for OpenAI TTS",
                provider=self.get_provider_name(),
            )

    async def shutdown(self) -> None:
        """Close HTTP session and connector."""
        if self._http_session:
            await self._http_session.close()
            self._http_session = None

        if self._connector:
            await self._connector.close()
            self._connector = None

        self._is_loaded = False
        logger.info("OpenAI TTS provider shutdown")

    def _calculate_backoff_with_jitter(self, attempt: int, base_delay: float = 1.0) -> float:
        """
        Calculate exponential backoff with jitter.

        Uses "full jitter" strategy to prevent thundering herd.

        Args:
            attempt: Current attempt number (0-indexed)
            base_delay: Base delay in seconds

        Returns:
            Delay in seconds with jitter applied
        """
        cap = 30.0  # Maximum delay cap
        exponential_delay = min(cap, base_delay * (2**attempt))
        return random.uniform(0, exponential_delay)

    def is_available(self) -> bool:
        """Check if provider is available."""
        return (
            self.config.api_key is not None
            and len(self.config.api_key) > 0
            and self.config.api_key != "your_openai_api_key_here"
        )

    def get_provider_name(self) -> str:
        """Get provider name."""
        return "openai"

    def get_supported_languages(self) -> List[str]:
        """Get supported languages."""
        return self.SUPPORTED_LANGUAGES.copy()

    def get_available_voices(self) -> List[VoiceInfo]:
        """Get available voices."""
        return list(self.VOICES.values())

    def _get_headers(self) -> Dict[str, str]:
        """Get API request headers."""
        return {
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json",
        }

    def _validate_voice(self, voice_id: str, correlation_id: Optional[str] = None) -> str:
        """
        Validate and normalize voice ID.

        Per OpenAI Create Speech API: alloy, ash, ballad, coral, echo, fable,
        onyx, nova, sage, shimmer, verse, marin, cedar.

        Args:
            voice_id: Voice ID to validate
            correlation_id: Request correlation ID for error context

        Returns:
            Validated voice ID

        Raises:
            VoiceNotFoundError: If voice not found
        """
        voice_id = voice_id.lower()

        if voice_id in self.VOICES:
            return voice_id

        raise VoiceNotFoundError(
            f"Voice not found: '{voice_id}'. Supported voices: {', '.join(sorted(self.VOICES.keys()))}",
            provider=self.get_provider_name(),
            correlation_id=correlation_id,
        )

    def _get_response_format(self, output_format: str) -> str:
        """
        Convert output format to OpenAI format.

        Args:
            output_format: Requested format

        Returns:
            OpenAI response_format string
        """
        # Strip sample rate info if present (e.g., "mp3_44100_128" -> "mp3")
        fmt = output_format.split("_")[0].lower()

        if fmt in self.SUPPORTED_FORMATS:
            return fmt

        return "mp3"

    async def synthesize(
        self,
        text: str,
        voice_id: str,
        language: Optional[str] = None,
        voice_settings: Optional[VoiceSettings] = None,
        output_format: str = "mp3",
        sample_rate: Optional[int] = None,
        correlation_id: Optional[str] = None,
    ) -> TTSResult:
        """
        Synthesize speech using OpenAI TTS API.

        Args:
            text: Text to convert to speech
            voice_id: Voice ID (alloy, echo, fable, onyx, nova, shimmer)
            language: Language code (ignored, primarily English)
            voice_settings: Voice settings (speed only supported)
            output_format: Output format
            sample_rate: Sample rate (ignored, determined by format)

        Returns:
            TTSResult with audio and metadata
        """
        if not self.is_available():
            raise ProviderUnavailableError(
                "OpenAI API key not configured",
                provider=self.get_provider_name(),
            )

        # Validate input
        self.validate_text(text)
        self.validate_format(self._get_response_format(output_format), correlation_id)
        voice_id = self._validate_voice(voice_id, correlation_id)

        # Ensure session is ready
        if not self._http_session:
            await self.load_model()

        start_time = time.time()

        # Build request
        url = f"{self.BASE_URL}{self.TTS_ENDPOINT}"
        headers = self._get_headers()

        body = {
            "model": self.config.model,
            "input": text,
            "voice": voice_id,
            "response_format": self._get_response_format(output_format),
        }

        # Apply speed from voice settings if provided
        speed = self.config.speed
        if voice_settings and voice_settings.speed != 1.0:
            speed = voice_settings.speed
        body["speed"] = max(0.25, min(4.0, speed))

        # Make request with retry
        last_error = None
        for attempt in range(self.config.retry_attempts):
            try:
                async with self._http_session.post(
                    url,
                    headers=headers,
                    json=body,
                ) as response:
                    if response.status == 200:
                        audio_data = await response.read()
                        processing_time = time.time() - start_time

                        # Estimate duration (OpenAI doesn't return duration)
                        # Try to parse actual duration from audio, fallback to text-based estimate
                        estimated_duration = self._estimate_audio_duration(audio_data, body["response_format"])
                        if estimated_duration <= 0:
                            # Fallback: approximate from text length
                            words = len(text.split())
                            estimated_duration = (words / 150) * 60 / speed

                        # Determine sample rate from format
                        fmt = body["response_format"]
                        if fmt == "pcm":
                            sr = 24000
                        elif fmt == "opus":
                            sr = 48000
                        else:
                            sr = 24000  # OpenAI default

                        return TTSResult(
                            audio=audio_data,
                            format=fmt,
                            sample_rate=sr,
                            duration=estimated_duration,
                            provider=self.get_provider_name(),
                            processing_time=processing_time,
                            voice_id=voice_id,
                            voice_name=self.VOICES.get(voice_id, VoiceInfo(voice_id, voice_id)).name,
                            text_length=len(text),
                            language=language,
                            metadata={
                                "model": self.config.model,
                                "speed": body["speed"],
                            },
                        )

                    elif response.status == 429:
                        retry_after = int(response.headers.get("Retry-After", 5))
                        logger.warning(f"Rate limited, waiting {retry_after}s")

                        if attempt < self.config.retry_attempts - 1:
                            await asyncio.sleep(retry_after)
                            continue
                        else:
                            raise RateLimitError(
                                f"Rate limited after {self.config.retry_attempts} attempts",
                                provider=self.get_provider_name(),
                                retry_after=retry_after,
                            )

                    elif response.status == 401:
                        raise ProviderUnavailableError(
                            "Invalid API key",
                            provider=self.get_provider_name(),
                        )

                    else:
                        error_text = await response.text()
                        last_error = SynthesisError(
                            f"API error {response.status}: {error_text}",
                            provider=self.get_provider_name(),
                        )

            except asyncio.TimeoutError as e:
                last_error = TTSTimeoutError(
                    "Request timed out",
                    provider=self.get_provider_name(),
                )
                last_error.__cause__ = e
            except (ProviderUnavailableError, RateLimitError):
                raise
            except (ConnectionError, OSError) as e:
                last_error = TTSNetworkError(
                    f"Network error: {e}",
                    provider=self.get_provider_name(),
                )
                last_error.__cause__ = e
            except Exception as e:
                try:
                    import aiohttp

                    if aiohttp is not None and isinstance(e, aiohttp.ClientError):
                        last_error = TTSNetworkError(
                            f"Connection error: {e}",
                            provider=self.get_provider_name(),
                        )
                    else:
                        last_error = SynthesisError(
                            f"Request failed: {e}",
                            provider=self.get_provider_name(),
                        )
                except ImportError:
                    last_error = SynthesisError(
                        f"Request failed: {e}",
                        provider=self.get_provider_name(),
                    )
                last_error.__cause__ = e

            # Exponential backoff with jitter
            if attempt < self.config.retry_attempts - 1:
                wait_time = self._calculate_backoff_with_jitter(attempt, 1.0)
                logger.warning(
                    "Retrying OpenAI TTS request",
                    extra={
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                        "correlation_id": correlation_id,
                        "error": str(last_error),
                    },
                )
                await asyncio.sleep(wait_time)

        if last_error:
            raise last_error

        raise SynthesisError(
            "Synthesis failed after all retries",
            provider=self.get_provider_name(),
        )

    def _supports_streaming(self) -> bool:
        """Check if configured model supports true streaming (gpt-4o-mini-tts*)."""
        model = getattr(self.config, "model_streaming", None) or self.config.model
        return model in OPENAI_TTS_STREAMING_MODELS

    async def synthesize_streaming(
        self,
        text: str,
        voice_id: str,
        language: Optional[str] = None,
        voice_settings: Optional[VoiceSettings] = None,
        output_format: str = "mp3",
        sample_rate: Optional[int] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[bytes]:
        """
        Stream synthesized audio.

        For gpt-4o-mini-tts: uses true server-side streaming (stream_format=sse).
        For tts-1/tts-1-hd: synthesizes fully then yields in chunks (no streaming support).

        Per https://platform.openai.com/docs/api-reference/audio/createSpeech
        stream_format sse is not supported for tts-1 or tts-1-hd.
        """
        if self._supports_streaming():
            async for chunk in self._synthesize_streaming_native(
                text, voice_id, voice_settings, output_format, correlation_id
            ):
                yield chunk
        else:
            # tts-1/tts-1-hd: synthesize then chunk
            result = await self.synthesize(
                text, voice_id, language, voice_settings, output_format, sample_rate, correlation_id
            )
            chunk_size = 4096
            for i in range(0, len(result.audio), chunk_size):
                yield result.audio[i : i + chunk_size]

    async def _synthesize_streaming_native(
        self,
        text: str,
        voice_id: str,
        voice_settings: Optional[VoiceSettings],
        output_format: str,
        correlation_id: Optional[str],
    ) -> AsyncIterator[bytes]:
        """
        True streaming for gpt-4o-mini-tts via stream_format=sse.
        Parses speech.audio.delta events per OpenAI API docs.
        """
        if not self._http_session:
            await self.load_model()

        voice_id = self._validate_voice(voice_id, correlation_id)
        fmt = self._get_response_format(output_format)
        self.validate_text(text)
        self.validate_format(fmt, correlation_id)

        url = f"{self.BASE_URL}{self.TTS_ENDPOINT}"
        headers = self._get_headers()
        speed = self.config.speed
        if voice_settings and voice_settings.speed != 1.0:
            speed = voice_settings.speed
        model = getattr(self.config, "model_streaming", "gpt-4o-mini-tts")

        body = {
            "model": model,
            "input": text,
            "voice": voice_id,
            "response_format": fmt,
            "speed": max(0.25, min(4.0, speed)),
            "stream_format": "sse",  # Triggers streaming; sse not supported for tts-1/tts-1-hd
        }

        async with self._http_session.post(url, headers=headers, json=body) as response:
            if response.status != 200:
                error_text = await response.text()
                raise SynthesisError(
                    f"OpenAI TTS streaming error {response.status}: {error_text}",
                    provider=self.get_provider_name(),
                    correlation_id=correlation_id,
                )

            buffer = ""
            # Per-chunk timeout to avoid hanging indefinitely if the server stalls.
            # We rely on aiohttp's overall socket timeout as a backstop, but this
            # gives us a clearer failure mode for streaming.
            stream_timeout = getattr(self.config, "timeout", 30)
            try:
                async for chunk in response.content.iter_any():
                    try:
                        # Guard each chunk read with a timeout; if the server
                        # stops sending data, we surface a TTSTimeoutError.
                        chunk = await asyncio.wait_for(
                            asyncio.shield(asyncio.sleep(0, result=chunk)),
                            timeout=stream_timeout,
                        )
                    except asyncio.TimeoutError as e:
                        raise TTSTimeoutError(
                            f"OpenAI TTS streaming chunk timed out after {stream_timeout}s",
                            provider=self.get_provider_name(),
                            correlation_id=correlation_id,
                        ) from e

                    if not chunk:
                        continue
                    buffer += chunk.decode("utf-8", errors="replace")
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        line = line.strip()
                        if line.startswith("data: "):
                            data_str = line[6:].strip()
                            if data_str == "[DONE]":
                                return
                            try:
                                event = json.loads(data_str)
                                if event.get("type") == "speech.audio.delta" and event.get("audio"):
                                    decoded = base64.b64decode(event["audio"])
                                    if decoded:
                                        yield decoded
                            except json.JSONDecodeError:
                                continue
            except TTSTimeoutError:
                # Propagate timeout errors directly so callers can handle them.
                raise

    def _estimate_audio_duration(
        self,
        audio_data: bytes,
        format: str,
    ) -> float:
        """
        Estimate audio duration by parsing the audio file.

        Args:
            audio_data: Audio file bytes
            format: Audio format (mp3, opus, pcm, etc.)

        Returns:
            Duration in seconds, or 0.0 if estimation fails
        """
        try:
            # Try to parse MP3/Opus/WAV to get actual duration
            if format in ("mp3", "opus", "wav", "flac"):
                try:
                    import mutagen  # noqa: F401
                    from mutagen.mp3 import MP3
                    from mutagen.oggopus import OggOpus
                    from mutagen.flac import FLAC

                    # Create temporary file-like object
                    import io

                    audio_file = io.BytesIO(audio_data)

                    if format == "mp3":
                        audio = MP3(audio_file)
                    elif format == "opus":
                        audio = OggOpus(audio_file)
                    elif format == "flac":
                        audio = FLAC(audio_file)
                    else:
                        return 0.0

                    if audio.info and hasattr(audio.info, "length"):
                        return float(audio.info.length)
                except (ImportError, Exception):
                    # mutagen not available or parsing failed, fallback to estimate
                    pass

            # For PCM, estimate from size
            if format == "pcm":
                # Assume 16-bit mono PCM at 24kHz (OpenAI default)
                bytes_per_sample = 2
                samples = len(audio_data) // bytes_per_sample
                return samples / 24000.0

        except Exception:
            pass

        return 0.0  # Indicates estimation failed, use text-based fallback

    async def health_check(self) -> Dict[str, Any]:
        """Perform health check."""
        return {
            "provider": self.get_provider_name(),
            "available": self.is_available(),
            "session_active": self._http_session is not None,
            "model": self.config.model,
            "model_streaming": getattr(self.config, "model_streaming", None),
            "voices": list(self.VOICES.keys()),
            "max_text_length": self.MAX_TEXT_LENGTH,
            "supports_streaming": self._supports_streaming(),
            "streaming_note": "True streaming for gpt-4o-mini-tts; chunked for tts-1/tts-1-hd",
        }
