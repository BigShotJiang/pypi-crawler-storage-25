"""
Voice agent — canonical path using NarrativeAgent + worker engines.

This module provides create_voice_session/create_voice_agent that delegate to
the same NarrativeAgent and engine prewarming used by the main worker.
Single code path for consistency and maintainability.
"""

from __future__ import annotations

import logging
from typing import Optional, Tuple, Any

from .config import VoiceConfig, load_voice_config_from_providers, VoiceAgentConfig
from .worker import prewarm_engines, get_prewarmed_engines
from .agent import NarrativeAgent

logger = logging.getLogger(__name__)

try:
    from livekit.agents.voice import AgentSession

    _VOICE_AVAILABLE = True
except ImportError:
    AgentSession = None  # type: ignore
    _VOICE_AVAILABLE = False


def _config_to_agent_config(cfg: Any) -> VoiceAgentConfig:
    """Convert VoiceConfig/VoiceAgentConfig to VoiceAgentConfig."""
    if isinstance(cfg, VoiceAgentConfig):
        return cfg
    # Override load_config defaults with cfg attributes
    base = load_voice_config_from_providers()
    for attr in (
        "allow_interruptions",
        "min_endpointing_delay",
        "max_endpointing_delay",
        "preemptive_generation",
        "resume_false_interruption",
        "false_interruption_timeout",
        "stt_provider",
        "stt_sample_rate",
        "stt_language",
        "vad_aggressiveness",
        "instructions",
        "initial_greeting",
    ):
        if hasattr(cfg, attr):
            setattr(base, attr, getattr(cfg, attr))
    return base


async def create_voice_session_async(config: Optional[VoiceConfig] = None) -> Any:
    """
    Build a LiveKit AgentSession with NarrativeAgent (canonical path).

    Uses the same engines and NarrativeAgent as the main worker. Prewarms
    engines so the first user turn avoids cold-start latency.

    Returns:
        AgentSession instance. Call await session.start(agent=agent, room=room).
    """
    if not _VOICE_AVAILABLE or AgentSession is None:
        raise RuntimeError("livekit-agents is required for voice mode. Install with: pip install livekit-agents")

    cfg = config or load_voice_config_from_providers()
    agent_config = _config_to_agent_config(cfg)

    await prewarm_engines()
    stt_engine, llm_engine, tts_engine = get_prewarmed_engines()

    agent = NarrativeAgent(
        stt_engine=stt_engine,
        llm_engine=llm_engine,
        tts_engine=tts_engine,
        config=agent_config,
    )

    session = AgentSession(
        allow_interruptions=agent_config.allow_interruptions,
        min_endpointing_delay=agent_config.min_endpointing_delay,
        max_endpointing_delay=agent_config.max_endpointing_delay,
        preemptive_generation=agent_config.preemptive_generation,
        resume_false_interruption=agent_config.resume_false_interruption,
        false_interruption_timeout=agent_config.false_interruption_timeout,
    )

    return session, agent


def create_voice_session(config: Optional[VoiceConfig] = None) -> Tuple[Any, Any]:
    """
    Build (AgentSession, NarrativeAgent) synchronously.

    Engines must already be prewarmed (e.g. by create_voice_agent_async or worker).
    For first-time use, prefer create_voice_agent_async.
    Returns (session, agent); call await session.start(agent=agent, room=room).
    """
    if not _VOICE_AVAILABLE or AgentSession is None:
        raise RuntimeError("livekit-agents is required for voice mode. Install with: pip install livekit-agents")

    try:
        stt_engine, llm_engine, tts_engine = get_prewarmed_engines()
    except RuntimeError:
        raise RuntimeError("Engines not prewarmed. Call create_voice_agent_async() first or use run_voice_agent().")

    cfg = config or load_voice_config_from_providers()
    agent_config = _config_to_agent_config(cfg)

    agent = NarrativeAgent(
        stt_engine=stt_engine,
        llm_engine=llm_engine,
        tts_engine=tts_engine,
        config=agent_config,
    )

    session = AgentSession(
        allow_interruptions=agent_config.allow_interruptions,
        min_endpointing_delay=agent_config.min_endpointing_delay,
        max_endpointing_delay=agent_config.max_endpointing_delay,
        preemptive_generation=agent_config.preemptive_generation,
        resume_false_interruption=agent_config.resume_false_interruption,
        false_interruption_timeout=agent_config.false_interruption_timeout,
    )

    return session, agent


def create_agent(
    config: Optional[VoiceConfig] = None,
    *,
    instructions: Optional[str] = None,
) -> Any:
    """
    Build a bare LiveKit Agent with instructions only.

    For the canonical path, use create_voice_session/create_voice_agent_async
    which return NarrativeAgent with full STT/LLM/TTS.
    """
    if not _VOICE_AVAILABLE:
        raise RuntimeError("livekit-agents is required. pip install livekit-agents")

    from livekit.agents.voice import Agent

    default_instructions = (
        "You are a helpful narrative AI assistant. Keep replies concise and natural for voice. "
        "Respond in the same language the user uses."
    )
    prompt = instructions or default_instructions
    return Agent(instructions=prompt)


def create_voice_agent(config: Optional[VoiceConfig] = None) -> Tuple[Any, Any]:
    """
    Build (AgentSession, Agent) synchronously.

    Engines must be prewarmed. Prefer create_voice_agent_async for first use.
    """
    return create_voice_session(config)


async def create_voice_agent_async(config: Optional[VoiceConfig] = None) -> Tuple[Any, Any]:
    """
    Build (AgentSession, Agent) with engines prewarmed (canonical path).

    Usage:
        session, agent = await create_voice_agent_async(config)
        await session.start(agent=agent, room=ctx.room)
    """
    return await create_voice_session_async(config)
