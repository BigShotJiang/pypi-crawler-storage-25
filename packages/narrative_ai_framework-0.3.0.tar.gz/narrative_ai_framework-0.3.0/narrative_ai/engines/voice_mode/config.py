"""
Voice Agent Configuration

Load configuration from providers.yml and environment variables.
"""

import os
import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class VoiceAgentConfig:
    """Configuration for the voice agent."""

    # LiveKit Connection
    livekit_url: str = field(default_factory=lambda: os.getenv("LIVEKIT_URL", "ws://localhost:7880"))
    livekit_api_key: str = field(default_factory=lambda: os.getenv("LIVEKIT_API_KEY", ""))
    livekit_api_secret: str = field(default_factory=lambda: os.getenv("LIVEKIT_API_SECRET", ""))

    # Agent Instructions (System Prompt)
    instructions: str = (
        "You are a helpful voice assistant. "
        "Keep your responses concise and natural for voice conversation. "
        "Respond in 1-3 sentences unless more detail is specifically requested."
    )

    # Turn Detection & Interruptions
    allow_interruptions: bool = True
    min_endpointing_delay: float = 0.5  # seconds
    max_endpointing_delay: float = 3.0  # seconds
    # False = one reply per turn, avoids same text spoken twice (preemptive + final). True = lower latency.
    preemptive_generation: bool = True
    resume_false_interruption: bool = (
        False  # avoid resume-after-pause which can cause duplicate or "resume after close"
    )
    false_interruption_timeout: Optional[float] = 2.0  # seconds; used only if resume_false_interruption is True

    # Conversation limits
    # When set, the agent will automatically disconnect after this many turns.
    max_turns: Optional[int] = None

    # STT Provider Configuration
    stt_provider: Optional[str] = None  # e.g., "elevenlabs"
    stt_sample_rate: int = 16000
    stt_language: str = "en"

    # LLM Provider Configuration
    llm_provider: Optional[str] = None  # e.g., "gemini"
    llm_temperature: float = 0.7
    llm_max_tokens: int = 1024

    # TTS Provider Configuration
    tts_provider: Optional[str] = None  # e.g., "elevenlabs"
    tts_sample_rate: int = 24000
    tts_voice_id: Optional[str] = None  # ElevenLabs voice ID

    # VAD Configuration (WebRTC mode 0–3; 2 recommended)
    vad_aggressiveness: int = 2

    # Initial Greeting
    initial_greeting: str = "Hello! How can I help you today?"

    def __post_init__(self):
        """Validate configuration. Skip in dev when keys may be placeholders."""
        skip = os.getenv("VOICE_SKIP_CONFIG_VALIDATION", "").strip().lower() in ("1", "true", "yes")
        if skip:
            return
        if not self.livekit_url:
            raise ValueError("LIVEKIT_URL environment variable is required")
        if not self.livekit_api_key:
            raise ValueError("LIVEKIT_API_KEY environment variable is required")
        if not self.livekit_api_secret:
            raise ValueError("LIVEKIT_API_SECRET environment variable is required")


def load_config_from_providers() -> VoiceAgentConfig:
    """
    Load configuration from providers.yml.

    This reads the realtime.livekit.agent.pipeline section from providers.yml
    and merges it with environment variables.

    Returns:
        VoiceAgentConfig instance
    """
    config = VoiceAgentConfig()

    try:
        from pathlib import Path
        import yaml

        # Resolve providers.yml relative to project root (robust to CWD).
        # voice_mode -> engines -> framework -> project root
        _config_dir = Path(__file__).resolve().parent
        _project_root = _config_dir.parent.parent.parent
        providers_paths = [
            _project_root / "config" / "providers.yml",
            Path("config/providers.yml"),
            Path("../config/providers.yml"),
            Path("../../config/providers.yml"),
        ]

        providers_file = None
        for path in providers_paths:
            if path.exists():
                providers_file = path
                break

        if providers_file:
            with open(providers_file, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}

            # Extract realtime configuration
            realtime = data.get("realtime", {})
            livekit = realtime.get("livekit", {})
            agent = livekit.get("agent", {})
            pipeline = agent.get("pipeline", {})

            # Update config from providers.yml
            if "stt_provider" in pipeline:
                config.stt_provider = pipeline["stt_provider"]
            if "llm_provider" in pipeline:
                config.llm_provider = pipeline["llm_provider"]
            if "tts_provider" in pipeline:
                config.tts_provider = pipeline["tts_provider"]

            if "vad_aggressiveness" in pipeline:
                config.vad_aggressiveness = pipeline["vad_aggressiveness"]

            # allow_interruptions: prefer explicit key; interrupt_enabled is alias (providers.yml)
            if "allow_interruptions" in pipeline:
                config.allow_interruptions = bool(pipeline["allow_interruptions"])
            elif "interrupt_enabled" in pipeline:
                config.allow_interruptions = bool(pipeline["interrupt_enabled"])
            if "min_endpointing_delay" in pipeline:
                config.min_endpointing_delay = pipeline["min_endpointing_delay"]
            if "max_endpointing_delay" in pipeline:
                config.max_endpointing_delay = pipeline["max_endpointing_delay"]
            if "preemptive_generation" in pipeline:
                config.preemptive_generation = pipeline["preemptive_generation"]
            if "resume_false_interruption" in pipeline:
                config.resume_false_interruption = pipeline["resume_false_interruption"]
            if "false_interruption_timeout" in pipeline:
                config.false_interruption_timeout = pipeline["false_interruption_timeout"]
            if "max_turns" in pipeline:
                config.max_turns = pipeline["max_turns"]
            if "instructions" in pipeline and pipeline["instructions"]:
                config.instructions = pipeline["instructions"]
            if "initial_greeting" in pipeline and pipeline["initial_greeting"]:
                config.initial_greeting = pipeline["initial_greeting"]

            # Validate endpointing delays
            if config.min_endpointing_delay >= config.max_endpointing_delay:
                logger.warning(
                    "min_endpointing_delay (%.1f) >= max_endpointing_delay (%.1f); clamping min to max-0.1",
                    config.min_endpointing_delay,
                    config.max_endpointing_delay,
                )
                config.min_endpointing_delay = max(0.1, config.max_endpointing_delay - 0.1)

            logger.info(f"Loaded configuration from {providers_file}")
        else:
            logger.warning("providers.yml not found, using defaults")

    except Exception as e:
        logger.warning(f"Could not load providers.yml: {e}")

    return config


# Backward compatibility: voice_agent and docs use these names
VoiceConfig = VoiceAgentConfig
load_voice_config_from_providers = load_config_from_providers
