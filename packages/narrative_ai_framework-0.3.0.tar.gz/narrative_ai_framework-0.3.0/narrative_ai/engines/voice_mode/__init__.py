"""
Voice Mode Engine - LiveKit Agent Integration
"""

import sys
import importlib
from typing import Any
from .api import start_agent, VoiceClient

def __getattr__(name: str) -> Any:
    """Implement stable lazy loading for heavy modules."""
    if name in ("run_voice_agent", "worker", "NarrativeAgent", "prewarm_engines"):
        # Import worker or agent lazily
        if name == "run_voice_agent":
            mod = importlib.import_module(".worker", __package__)
            return mod.run_voice_agent
        if name == "worker":
            return importlib.import_module(".worker", __package__)
        if name == "NarrativeAgent":
            mod = importlib.import_module(".agent", __package__)
            return mod.NarrativeAgent
        if name == "prewarm_engines":
            mod = importlib.import_module(".worker", __package__)
            return mod.prewarm_engines
    
    raise AttributeError(f"module {__name__} has no attribute {name}")

__all__ = [
    "start_agent",
    "VoiceClient",
    "run_voice_agent",
    "NarrativeAgent",
    "prewarm_engines",
]

__version__ = "0.1.0"
