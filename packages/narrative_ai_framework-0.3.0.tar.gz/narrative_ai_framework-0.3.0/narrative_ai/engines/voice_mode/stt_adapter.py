"""
STT Adapter - Wraps your custom STT engine for LiveKit

This adapter implements LiveKit's STT interface while using your custom
STT engine under the hood. Your engine stays independent and can be
swapped for fine-tuned models without changing this adapter.

For lowest latency and partials: set use_streaming_for_segment=True so
each segment is fed to engine.transcribe_streaming(); prefer ElevenLabs
as primary provider for sub-300 ms first-token when possible.
"""

import logging
from typing import Optional

import numpy as np
from livekit import rtc
from livekit.agents import stt as lk_stt
from livekit.agents.types import (
    DEFAULT_API_CONNECT_OPTIONS,
    NOT_GIVEN,
    APIConnectOptions,
    NotGivenOr,
)
from livekit.agents.utils import AudioBuffer, is_given

logger = logging.getLogger(__name__)

# STT sometimes returns noise/sound-effect labels; don't treat as user speech
_NOISE_LABELS = frozenset(
    {
        "[background noise]",
        "[static]",
        "[radio static]",
        "[gunshot]",
        "[music]",
        "[applause]",
        "[laughter]",
        "[cough]",
        "[sigh]",
        "[breath]",
        "[noise]",
        "[silence]",
        "[inaudible]",
        "[unintelligible]",
        "[audio]",
        "[sound]",
        "[mechanical sound]",
        "[mechanical]",
    }
)


def _is_noise_or_sound_label(text: str) -> bool:
    """True if text is only a noise/sound-effect label (e.g. [background noise])."""
    if not text or len(text) > 80:
        return False
    t = text.strip().lower()
    if t in _NOISE_LABELS:
        return True
    # Single bracketed token, e.g. [something]
    if t.startswith("[") and t.endswith("]") and " " not in t[1:-1]:
        return True
    return False


class CustomSTT(lk_stt.STT):
    """
    LiveKit STT adapter for your custom STT engine.

    Wraps your framework's STT engine to work with LiveKit's AgentSession.
    """

    def __init__(
        self,
        stt_engine,
        *,
        sample_rate: int = 16000,
        language: str = "en",
        use_streaming_for_segment: bool = False,
        # Default ~1.0s of silence at 20 ms/frame for faster commit (was 75 ≈ 1.5s).
        silence_frames_to_flush: int = 50,
        # Default ~0.2s of speech at 16 kHz 16‑bit mono for earlier segmenting (was ~0.3s).
        min_speech_bytes: int = 6400,
    ):
        """
        Initialize STT adapter.

        Args:
            stt_engine: Your framework's STT engine instance
            sample_rate: Audio sample rate in Hz
            language: Language code (e.g., "en", "ar")
            use_streaming_for_segment: If True, feed each segment to
                engine.transcribe_streaming() for partials and lower first-token
                (recommended when primary is ElevenLabs).
            silence_frames_to_flush: Frames of silence after speech to trigger
                segment end (~1.5 s at 20 ms/frame if 75).
            min_speech_bytes: Min bytes of speech before flushing on silence
                (~0.3 s at 16 kHz 16-bit if 9600).
        """
        super().__init__(
            capabilities=lk_stt.STTCapabilities(
                streaming=True,
                interim_results=True,
            )
        )
        self._engine = stt_engine
        self._sample_rate = sample_rate
        self._language = language
        self._use_streaming_for_segment = use_streaming_for_segment
        self._silence_frames_to_flush = silence_frames_to_flush
        self._min_speech_bytes = min_speech_bytes

        logger.info(
            f"Custom STT adapter initialized: "
            f"sample_rate={sample_rate}, language={language}, "
            f"use_streaming_for_segment={use_streaming_for_segment}"
        )

    async def _recognize_impl(
        self,
        buffer: AudioBuffer,
        *,
        language: NotGivenOr[str] = NOT_GIVEN,
        conn_options: APIConnectOptions,
    ) -> lk_stt.SpeechEvent:
        """Non-streaming recognition: convert buffer to bytes and call framework STT."""
        if isinstance(buffer, list):
            if not buffer:
                return lk_stt.SpeechEvent(
                    type=lk_stt.SpeechEventType.FINAL_TRANSCRIPT,
                    alternatives=[
                        lk_stt.SpeechData(
                            language=self._language,
                            text="",
                            confidence=0.0,
                        )
                    ],
                )
            audio_data = b"".join(bytes(frame.data) for frame in buffer)
            sample_rate = int(buffer[0].sample_rate)
        else:
            audio_data = bytes(buffer.data)
            sample_rate = int(buffer.sample_rate)

        lang = language if is_given(language) else self._language

        if not audio_data:
            return lk_stt.SpeechEvent(
                type=lk_stt.SpeechEventType.FINAL_TRANSCRIPT,
                alternatives=[
                    lk_stt.SpeechData(
                        language=lang,
                        text="",
                        confidence=0.0,
                    )
                ],
            )

        result = await self._engine.transcribe(
            audio=audio_data,
            sample_rate=sample_rate,
            language=lang or None,
        )
        text = getattr(result, "text", "") or ""
        if _is_noise_or_sound_label(text.strip()):
            text = ""
        out_lang = getattr(result, "language", None) or lang
        conf = getattr(result, "confidence", 0.0) or 0.0

        return lk_stt.SpeechEvent(
            type=lk_stt.SpeechEventType.FINAL_TRANSCRIPT,
            alternatives=[
                lk_stt.SpeechData(
                    language=out_lang,
                    text=text,
                    confidence=float(conf),
                )
            ],
        )

    def stream(
        self,
        *,
        language: Optional[str] = None,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
    ) -> "CustomSTTStream":
        """
        Create a new STT stream.

        Args:
            language: Override language for this stream
            conn_options: Connection options

        Returns:
            CustomSTTStream instance
        """
        lang = language or self._language
        return CustomSTTStream(
            stt=self,
            conn_options=conn_options,
            sample_rate=self._sample_rate,
            language=lang,
            use_streaming_for_segment=self._use_streaming_for_segment,
            silence_frames_to_flush=self._silence_frames_to_flush,  # Pass through; stream uses parent values
            min_speech_bytes=self._min_speech_bytes,
        )


def _is_silence_frame(frame: rtc.AudioFrame, threshold: int = 512) -> bool:
    """
    True if frame looks like silence (max 16-bit sample amplitude below threshold).

    Uses a vectorized NumPy implementation for performance instead of a Python
    per-sample loop, which can become a bottleneck under high throughput.
    """
    data = bytes(frame.data)
    if not data:
        return True
    try:
        samples = np.frombuffer(data, dtype=np.int16)
        if samples.size == 0:
            return True
        max_abs = int(np.max(np.abs(samples)))
        return max_abs < threshold
    except Exception as e:
        # On any unexpected error, fall back to treating the frame as non-silence
        # so we don't accidentally drop user speech.
        logger.debug("Silence detection error, treating frame as speech: %s", e)
        return False


class CustomSTTStream(lk_stt.RecognizeStream):
    """
    STT stream implementation that feeds audio to your custom engine.

    The LiveKit pipeline never sends FlushSentinel; it only pushes frames (including
    silence when commit_user_turn runs). We treat a run of silence after speech as
    end-of-segment and trigger transcription so user speech is actually processed.
    """

    def __init__(
        self,
        stt: CustomSTT,
        conn_options: APIConnectOptions,
        sample_rate: int,
        language: str,
        use_streaming_for_segment: bool = False,
        silence_frames_to_flush: Optional[int] = None,
        min_speech_bytes: Optional[int] = None,
    ):
        super().__init__(stt=stt, conn_options=conn_options, sample_rate=sample_rate)
        self._engine = stt._engine
        self._language = language
        self._sample_rate = sample_rate
        self._use_streaming_for_segment = use_streaming_for_segment
        # Use CustomSTT's optimized defaults (50 ~1s silence, 6400 ~0.2s speech) when not passed
        self.SILENCE_FRAMES_TO_FLUSH = (
            silence_frames_to_flush if silence_frames_to_flush is not None else stt._silence_frames_to_flush
        )
        self.MIN_SPEECH_BYTES = min_speech_bytes if min_speech_bytes is not None else stt._min_speech_bytes

        logger.debug(f"STT stream created: language={language}, use_streaming_for_segment={use_streaming_for_segment}")

    async def _metrics_monitor_task(self, event_aiter) -> None:
        """Consume events for metrics (no-op for custom adapter)."""
        async for _ in event_aiter:
            pass

    async def _transcribe_segment(self, chunk: bytes) -> None:
        """
        Transcribe a full segment (silence-triggered or flush).
        When use_streaming_for_segment is True, feeds chunk to
        engine.transcribe_streaming() for partials and lower first-token;
        otherwise uses one-shot transcribe(). Skips empty transcripts.
        """
        if self._use_streaming_for_segment:
            await self._transcribe_segment_streaming(chunk)
        else:
            await self._transcribe_segment_oneshot(chunk)

    async def _transcribe_segment_oneshot(self, chunk: bytes) -> None:
        """One-shot transcribe(segment)."""
        try:
            result = await self._engine.transcribe(
                audio=chunk,
                sample_rate=self._sample_rate,
                language=self._language or None,
                use_vad=False,  # chunk is already a segment
            )
        except Exception as e:
            logger.warning("STT segment transcribe failed: %s", e, exc_info=True)
            return
        text = (getattr(result, "text", None) or "").strip()
        if not text:
            logger.debug("STT stream: skipping empty transcript")
            return
        if _is_noise_or_sound_label(text):
            logger.debug("STT stream: skipping noise/sound label %r", text[:60])
            return
        lang = getattr(result, "language", None) or self._language
        conf = getattr(result, "confidence", 0.0) or 0.0
        event = lk_stt.SpeechEvent(
            type=lk_stt.SpeechEventType.FINAL_TRANSCRIPT,
            alternatives=[lk_stt.SpeechData(language=lang, text=text, confidence=float(conf))],
        )
        self._event_ch.send_nowait(event)
        logger.info("STT stream: FINAL_TRANSCRIPT text=%r", text[:80])

    async def _transcribe_segment_streaming(self, chunk: bytes) -> None:
        """Feed segment to engine.transcribe_streaming() for partials and lower first-token."""
        # Yield chunk in small pieces (e.g. 20 ms) so engine can return partials
        frame_size = 640  # 20 ms at 16 kHz 16-bit mono

        async def _segment_stream():
            for i in range(0, len(chunk), frame_size):
                yield chunk[i : i + frame_size]

        try:
            async for result in self._engine.transcribe_streaming(
                _segment_stream(),
                sample_rate=self._sample_rate,
                language=self._language or None,
                extract_emotion=False,
            ):
                text = (getattr(result, "text", None) or "").strip()
                if not text:
                    continue
                if _is_noise_or_sound_label(text):
                    continue
                lang = getattr(result, "language", None) or self._language
                conf = getattr(result, "confidence", 0.0) or 0.0
                is_final = getattr(result, "is_final", True)
                event_type = (
                    lk_stt.SpeechEventType.FINAL_TRANSCRIPT if is_final else lk_stt.SpeechEventType.INTERIM_TRANSCRIPT
                )
                event = lk_stt.SpeechEvent(
                    type=event_type,
                    alternatives=[lk_stt.SpeechData(language=lang, text=text, confidence=float(conf))],
                )
                self._event_ch.send_nowait(event)
                if is_final:
                    logger.info("STT stream: FINAL_TRANSCRIPT (streaming) text=%r", text[:80])
                    break
        except Exception as e:
            logger.warning("STT segment streaming failed: %s", e, exc_info=True)

    async def _run(self) -> None:
        """Run transcription loop: read frames from _input_ch, feed to engine, send events to _event_ch."""
        import time as _time

        frame_count = 0
        silence_run = 0
        try:
            logger.info("STT stream: transcription loop started (waiting for user audio)")
            segment_bytes = bytearray()

            async for item in self._input_ch:
                if isinstance(item, self._FlushSentinel):
                    if not segment_bytes:
                        logger.debug("STT stream: flush with empty segment, skipping")
                        continue
                    chunk = bytes(segment_bytes)
                    segment_bytes.clear()
                    logger.info(
                        "STT stream: flush segment received, total %d bytes (%d frames), calling transcribe_streaming",
                        len(chunk),
                        frame_count,
                    )
                    frame_count = 0
                    silence_run = 0
                    try:
                        await self._transcribe_segment(chunk)
                    except Exception as stream_err:
                        logger.error(
                            "STT stream: transcribe_streaming error: %s",
                            stream_err,
                            exc_info=True,
                        )
                        raise
                    continue

                if isinstance(item, rtc.AudioFrame):
                    segment_bytes.extend(bytes(item.data))
                    frame_count += 1
                    if frame_count == 1:
                        logger.info("STT stream: first user audio frame received")

                    # Pipeline never sends FlushSentinel; it pushes silence frames.
                    # Treat long run of silence after speech as end-of-segment.
                    if _is_silence_frame(item):
                        silence_run += 1
                        if len(segment_bytes) >= self.MIN_SPEECH_BYTES and silence_run >= self.SILENCE_FRAMES_TO_FLUSH:
                            chunk = bytes(segment_bytes)
                            segment_bytes.clear()
                            logger.info(
                                "STT stream: silence run (%d frames), transcribing %d bytes",
                                silence_run,
                                len(chunk),
                            )
                            frame_count = 0
                            silence_run = 0
                            try:
                                await self._transcribe_segment(chunk)
                            except Exception as stream_err:
                                logger.error(
                                    "STT stream: transcribe_streaming error: %s",
                                    stream_err,
                                    exc_info=True,
                                )
                                raise
                    else:
                        silence_run = 0

        except Exception as e:
            logger.error(f"STT transcription error: {e}", exc_info=True)
            self._stt.emit(
                "error",
                lk_stt.STTError(
                    timestamp=_time.time(),
                    label=self._stt._label,
                    error=e,
                    recoverable=False,
                ),
            )
            raise

        finally:
            logger.debug("STT transcription ended")
