"""
Narrative AI Agent

The main agent class that defines the voice assistant's behavior.
Uses LiveKit's Agent class (latest API) with custom engine adapters.

STT:
- Default is framework STT (CustomSTT) so the session does not die on ElevenLabs
  quota_exceeded. Set VOICE_USE_LIVEKIT_STT=1 to use the LiveKit ElevenLabs plugin
  for real-time streaming when you have quota.
- Framework STT supports ElevenLabs, Whisper, Conformer; you can use your own model
  (e.g. Whisper finetuned on a GPU) via config/providers.yml.
"""

import logging
import os
import sys
from typing import Optional

from livekit.agents.voice import Agent
from livekit.plugins import silero

from .config import VoiceAgentConfig
from .stt_adapter import CustomSTT
from .llm_adapter import CustomLLM
from .tts_adapter import CustomTTS

logger = logging.getLogger(__name__)


def _get_elevenlabs_stt_plugin(config: VoiceAgentConfig):
    """
    Prefer LiveKit's ElevenLabs STT plugin for true realtime streaming when available.

    Behaviour:
    - Uses livekit.plugins.elevenlabs.STT with the realtime model.
    - Enabled by default when the plugin is importable and an API key is set.
    - Can be forced off by setting VOICE_USE_FRAMEWORK_STT=1 (or true/yes).
    - Falls back to framework STT (CustomSTT) on any error.
    """
    # Allow opting out of the plugin entirely (e.g. for testing or quota concerns)
    if os.getenv("VOICE_USE_FRAMEWORK_STT", "").strip().lower() in ("1", "true", "yes"):
        logger.info("VOICE_USE_FRAMEWORK_STT enabled - skipping LiveKit ElevenLabs STT plugin")
        return None

    # Backwards compatibility: VOICE_USE_LIVEKIT_STT still respected when explicitly false
    if os.getenv("VOICE_USE_LIVEKIT_STT", "").strip().lower() in ("0", "false", "no"):
        logger.info("VOICE_USE_LIVEKIT_STT explicitly disabled - using framework STT")
        return None

    api_key = os.getenv("ELEVEN_API_KEY") or os.getenv("ELEVENLABS_API_KEY") or ""
    if not (api_key and api_key.strip() and api_key != "your_elevenlabs_api_key_here"):
        logger.debug("ElevenLabs STT plugin not used: ELEVEN_API_KEY/ELEVENLABS_API_KEY not set")
        return None

    lk_elevenlabs = sys.modules.get("livekit.plugins.elevenlabs")
    if lk_elevenlabs is None:
        logger.debug("livekit.plugins.elevenlabs not imported on main thread; using framework STT")
        return None

    try:
        # Pass api_key directly to avoid mutating os.environ (plugin supports api_key parameter).
        # Newer livekit-plugins-elevenlabs uses 'model', older versions accept 'model_id'.
        base_kwargs = {
            "language_code": config.stt_language or "en",
            "sample_rate": config.stt_sample_rate,
        }
        try:
            stt = lk_elevenlabs.STT(api_key=api_key, model="scribe_v2_realtime", **base_kwargs)
        except TypeError:
            # Older plugin: may not accept api_key or uses model_id; set env as fallback
            if not os.getenv("ELEVEN_API_KEY"):
                os.environ["ELEVEN_API_KEY"] = api_key
            try:
                stt = lk_elevenlabs.STT(model="scribe_v2_realtime", **base_kwargs)
            except TypeError:
                stt = lk_elevenlabs.STT(model_id="scribe_v2_realtime", **base_kwargs)

        logger.info(
            "Using LiveKit ElevenLabs STT plugin for real-time streaming "
            "(model=scribe_v2_realtime, language=%s, sample_rate=%s)",
            config.stt_language or "en",
            config.stt_sample_rate,
        )
        return stt
    except Exception as e:
        logger.debug("ElevenLabs plugin STT creation failed: %s, using framework STT", e, exc_info=True)
        return None


class NarrativeAgent(Agent):
    """
    Narrative AI voice agent.

    This agent uses your custom STT, LLM, and TTS engines wrapped in
    LiveKit-compatible adapters.
    """

    def __init__(
        self,
        stt_engine,
        llm_engine,
        tts_engine,
        config: Optional[VoiceAgentConfig] = None,
        *,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ):
        """
        Initialize Narrative AI agent.

        Args:
            stt_engine: Your custom STT engine instance
            llm_engine: Your custom LLM engine instance
            tts_engine: Your custom TTS engine instance
            config: Optional configuration (uses defaults if not provided)
            user_id: Authenticated user UUID (if available)
            tenant_id: Optional tenant UUID
            session_id: Stable conversation id for persistent memory
        """
        self._config = config or VoiceAgentConfig()

        # Prefer LiveKit ElevenLabs STT plugin for real-time streaming when available.
        # Fall back to framework STT (CustomSTT) with streaming enabled for supported providers.
        stt_adapter = _get_elevenlabs_stt_plugin(self._config)
        if stt_adapter is None:
            provider = (self._config.stt_provider or "").strip().lower()
            # Engines backed by ElevenLabs or Whisper support low-latency streaming.
            use_streaming_for_segment = provider in ("elevenlabs", "whisper")
            if provider and provider not in ("elevenlabs", "whisper"):
                logger.debug(
                    "VoiceAgentConfig.stt_provider=%r is not a recognised low-latency "
                    "streaming provider (elevenlabs/whisper). Using conservative "
                    "segment-based STT; update providers.yml if this is unexpected.",
                    provider,
                )

            stt_adapter = CustomSTT(
                stt_engine,
                sample_rate=self._config.stt_sample_rate,
                language=self._config.stt_language,
                use_streaming_for_segment=use_streaming_for_segment,
            )

        # Shared turn metadata: LLM writes emotion/language on final chunk; TTS reads before synth.
        _turn_metadata: dict = {}

        llm_adapter = CustomLLM(
            llm_engine,
            temperature=self._config.llm_temperature,
            max_tokens=self._config.llm_max_tokens,
            turn_metadata=_turn_metadata,
            user_id=user_id,
            tenant_id=tenant_id,
            session_id=session_id,
        )

        tts_adapter = CustomTTS(
            tts_engine,
            sample_rate=self._config.tts_sample_rate,
            voice_id=self._config.tts_voice_id,
            turn_metadata=_turn_metadata,
            default_language=self._config.stt_language or "en",
        )

        # VAD: WebRTC is faster (avoids "inference slower than realtime"); Silero is more accurate.
        # Set VOICE_USE_WEBRTC_VAD=1 to reduce reply delay when Silero is slow on your machine.
        use_webrtc_vad = os.getenv("VOICE_USE_WEBRTC_VAD", "").strip().lower() in ("1", "true", "yes")
        vad = None
        if use_webrtc_vad:
            try:
                from .webrtc_vad import WebRTCVAD

                vad = WebRTCVAD(
                    sample_rate=16000,
                    aggressiveness=getattr(self._config, "vad_aggressiveness", 2),
                    update_interval=0.02,
                )
                logger.info("Using WebRTC VAD (VOICE_USE_WEBRTC_VAD=1, lower latency)")
            except Exception as e:
                logger.warning("WebRTC VAD not available: %s", e)
        if vad is None:
            try:
                vad = silero.VAD.load()
                logger.info("Using Silero VAD (recommended)")
            except Exception as e:
                logger.warning("Silero VAD not available: %s", e)
                logger.info("VAD will be provided by STT")
                vad = None

        # Initialize parent Agent class with our adapters
        super().__init__(
            instructions=self._config.instructions,
            stt=stt_adapter,
            llm=llm_adapter,
            tts=tts_adapter,
            vad=vad,
            allow_interruptions=self._config.allow_interruptions,
            min_endpointing_delay=self._config.min_endpointing_delay,
            max_endpointing_delay=self._config.max_endpointing_delay,
        )

        logger.info("Narrative AI agent initialized successfully")

    async def on_enter(self):
        """
        Called when agent becomes active in a session.

        Send the initial greeting using say() so it is spoken once via TTS
        without an LLM call (avoids duplicate or similar greetings).
        """
        logger.info("Agent entered session")

        # Speak greeting directly (no LLM) so it plays exactly once
        self.session.say(
            self._config.initial_greeting,
            add_to_chat_ctx=True,
        )
        logger.info(f"Sent greeting: {self._config.initial_greeting}")

    async def on_exit(self):
        """
        Called before agent gives control to another agent.

        Only used in multi-agent workflows.
        """
        logger.info("Agent exiting session")

    async def on_user_turn_completed(self, turn_ctx, new_message):
        """
        Called when user finishes speaking (signature matches LiveKit Agent base class).

        Args:
            turn_ctx: Mutable chat context for this turn
            new_message: ChatMessage with the user's transcribed text
        """
        text = (new_message.text_content or "").strip()
        logger.info(f"User said: {text}")

        # You can add custom logic here, e.g.:
        # - Analytics
        # - Sentiment analysis
        # - Context updates (edit turn_ctx)
