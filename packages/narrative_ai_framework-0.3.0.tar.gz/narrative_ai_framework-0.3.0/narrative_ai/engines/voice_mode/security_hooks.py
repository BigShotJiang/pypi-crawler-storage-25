"""
Security hooks for voice mode: rate limit and audit per session/turn.

Hook into plugins (e.g. before STT/LLM calls) using EndpointCosts.VOICE_TURN_COMPLETE
and ActionType.VOICE_INTERACTION.

When VOICE_DEV_SKIP_RATE_LIMIT=1, check_rate_limit returns True without calling Redis
so session start is not blocked by Redis timeout in development.

Anonymous sessions: When tenant_id is None, each session gets a per-session anonymous
tenant UUID (derived from session_id) for rate limit isolation - prevents all anonymous
sessions from sharing the same rate limit bucket.

SECURITY: Uses shared RateLimiter and AuditLogger instances (lazy-initialized) to
avoid connection exhaustion - creating new Redis/DB connections per call can exhaust
resources under load (OWASP API4).
"""

from __future__ import annotations

import logging
import os
import threading
import uuid as _uuid_module
from typing import Any, Optional

logger = logging.getLogger(__name__)

_SECURITY_AVAILABLE = False
RateLimiter = None
EndpointCosts = None
RateLimitExceeded = None
AuditLogger = None
ActionType = None
ActionStatus = None

try:
    from narrative_ai.security.rate_limiting import RateLimiter, EndpointCosts, RateLimitExceeded

    _SECURITY_AVAILABLE = True
except ImportError:
    pass

try:
    from narrative_ai.security.audit_trail import AuditLogger, ActionType, ActionStatus
except ImportError:
    pass

# Shared instances (lazy-initialized) to avoid connection exhaustion
_rate_limiter_instance: Optional[Any] = None
_rate_limiter_lock = threading.Lock()
_audit_logger_instances: dict = {}  # database_url -> AuditLogger
_audit_logger_lock = threading.Lock()


def _anonymous_tenant_uuid(session_id: str) -> _uuid_module.UUID:
    """
    Generate a per-session anonymous tenant UUID for isolation.

    When tenant_id is None, using a shared nil UUID would put all anonymous
    sessions in the same rate limit bucket. This gives each session its own
    tenant space for better isolation (OWASP API1/API4).
    """
    return _uuid_module.uuid5(_uuid_module.NAMESPACE_DNS, f"anon_tenant:{session_id}")


def _anonymous_user_uuid(session_id: str) -> _uuid_module.UUID:
    """Generate a per-session user UUID when user_id is not provided."""
    return _uuid_module.uuid5(_uuid_module.NAMESPACE_DNS, f"voice:{session_id}")


def _get_rate_limiter():
    """Get shared RateLimiter instance (lazy-init, thread-safe). Avoids connection exhaustion."""
    global _rate_limiter_instance
    if RateLimiter is None:
        return None
    with _rate_limiter_lock:
        if _rate_limiter_instance is None:
            _rate_limiter_instance = RateLimiter()
            logger.debug("Initialized shared RateLimiter for security hooks")
        return _rate_limiter_instance


def _get_audit_logger(database_url: str):
    """Get shared AuditLogger for database_url (lazy-init, thread-safe). Avoids connection exhaustion."""
    if AuditLogger is None or not database_url:
        return None
    with _audit_logger_lock:
        if database_url not in _audit_logger_instances:
            _audit_logger_instances[database_url] = AuditLogger(database_url=database_url)
            logger.debug("Initialized shared AuditLogger for security hooks")
        return _audit_logger_instances[database_url]


def check_rate_limit(
    session_id: str,
    user_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    *,
    cost: Optional[int] = None,
) -> bool:
    """
    Check rate limit. Returns True when allowed.

    Behavior:
    - Raises RateLimitExceeded when over limit (hard user-facing limit).
    - On infrastructure errors (Redis/security module unavailable), logs and
      **fails open** for voice sessions to preserve availability, especially
      during brief outages. Engine-level rate limiting remains in place.
    """
    # Never skip rate limiting in production (OWASP API8 - security misconfiguration)
    is_production = os.getenv("ENV", "").lower() == "production"
    if not is_production and os.getenv("VOICE_DEV_SKIP_RATE_LIMIT", "").strip() == "1":
        return True
    # In production, when the security module is unavailable we prefer to
    # fail open for *voice sessions* (real-time UX) while emitting loud logs.
    # Engine-level rate limiting still enforces hard limits per request.
    if not _SECURITY_AVAILABLE or RateLimiter is None or EndpointCosts is None:
        if is_production:
            logger.critical(
                "Security module unavailable in production - rate limiting cannot be enforced "
                "for voice session. ALLOWING request (fail open for availability)."
            )
            # Optionally emit a metric if monitoring is available (best-effort).
            try:
                from narrative_ai import monitoring  # type: ignore[attr-defined]

                if hasattr(monitoring, "emit_metric"):
                    monitoring.emit_metric(
                        "voice.rate_limit.unavailable",
                        1,
                        tags=["severity:critical"],
                    )
            except Exception:
                # Monitoring is optional; never block voice on it.
                pass
            return True
        logger.warning("Security module unavailable (dev) - allowing request without rate limit check")
        return True
    c = cost
    if c is None:
        try:
            co = getattr(EndpointCosts, "VOICE_TURN_COMPLETE", None)
            if co is not None and hasattr(co, "value"):
                c = co.value
        except AttributeError:
            c = None
    if c is None:
        try:
            s = getattr(EndpointCosts, "VOICE_STT_STREAM", None)
            l_ = getattr(EndpointCosts, "VOICE_LLM_STREAM", None) or getattr(EndpointCosts, "VOICE_LLM_GENERATE", None)
            t = getattr(EndpointCosts, "VOICE_TTS_STREAM", None)
            c = (
                (getattr(s, "value", 5) if s else 5)
                + (getattr(l_, "value", 10) if l_ else 10)
                + (getattr(t, "value", 5) if t else 5)
            )
        except (AttributeError, TypeError):
            c = 20
    try:
        from narrative_ai.security.rate_limiting import UserTier

        limiter = _get_rate_limiter()
        if limiter is None:
            raise RuntimeError("RateLimiter not available")
        # Per-session anonymous tenant when tenant_id is None (better isolation)
        if tenant_id:
            try:
                tenant_uuid = _uuid_module.UUID(tenant_id)
            except (ValueError, TypeError):
                tenant_uuid = _anonymous_tenant_uuid(session_id)
        else:
            tenant_uuid = _anonymous_tenant_uuid(session_id)
        # Per-session user UUID
        if user_id and len(user_id) == 36:
            try:
                user_uuid = _uuid_module.UUID(user_id)
            except (ValueError, TypeError):
                user_uuid = _anonymous_user_uuid(session_id)
        else:
            user_uuid = _anonymous_user_uuid(session_id)
        limiter.check_rate_limit(
            tenant_id=tenant_uuid,
            user_id=user_uuid,
            tier=UserTier.FREE,
            endpoint_cost=c,
        )
        return True
    except Exception as e:
        if RateLimitExceeded and isinstance(e, RateLimitExceeded):
            logger.warning("Voice rate limit exceeded: session=%s", session_id)
            raise
        # Infrastructure / unexpected error (Redis down, bug, etc.). For real-time voice
        # we ALLOW the session to proceed but log loudly so SREs can investigate.
        logger.error(
            "Rate limit check failed for voice session %s, ALLOWING request for availability: %s",
            session_id,
            e,
            exc_info=True,
        )
        try:
            from narrative_ai import monitoring  # type: ignore[attr-defined]

            if hasattr(monitoring, "emit_metric"):
                monitoring.emit_metric(
                    "voice.rate_limit.error",
                    1,
                    tags=["error:infrastructure"],
                )
        except Exception:
            pass
        return True


async def audit_turn(
    session_id: str,
    input_text: str,
    output_text: str,
    emotion: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    metadata: Optional[dict] = None,
) -> None:
    """
    Audit a voice turn (user said X, agent said Y).
    Uses ActionType.VOICE_INTERACTION and AuditLogger.log_action_async.
    """
    if AuditLogger is None or ActionType is None or ActionStatus is None:
        return
    try:
        import uuid

        details = {
            "input": input_text[:500],
            "output": output_text[:500],
            **(metadata or {}),
        }
        if emotion is not None:
            details["emotion"] = emotion
        # Per-session anonymous tenant when tenant_id is None (matches check_rate_limit)
        try:
            if tenant_id:
                tid = uuid.UUID(tenant_id)
            else:
                tid = uuid.uuid5(uuid.NAMESPACE_DNS, f"anon_tenant:{session_id}")
        except (ValueError, TypeError):
            tid = uuid.uuid5(uuid.NAMESPACE_DNS, f"anon_tenant:{session_id}")
        try:
            uid = (
                uuid.UUID(user_id)
                if (user_id and len(user_id) == 36)
                else uuid.uuid5(uuid.NAMESPACE_DNS, f"voice:{session_id}")
            )
        except (ValueError, TypeError):
            uid = uuid.uuid5(uuid.NAMESPACE_DNS, f"voice:{session_id}")
        try:
            rid = uuid.UUID(session_id) if session_id else None
        except (ValueError, TypeError):
            rid = None
        audit_db_url = os.getenv("AUDIT_DATABASE_URL") or os.getenv("DATABASE_URL")
        if not audit_db_url:
            logger.debug("Audit logging skipped: AUDIT_DATABASE_URL/DATABASE_URL not set")
            return
        audit = _get_audit_logger(audit_db_url)
        if audit is None:
            return
        audit.log_action_async(
            tenant_id=tid,
            user_id=uid,
            action=ActionType.VOICE_INTERACTION,
            resource_type="voice_turn",
            resource_id=rid,
            status=ActionStatus.SUCCESS,
            details=details,
        )
    except Exception as e:
        logger.warning("Audit turn failed: %s", e)
