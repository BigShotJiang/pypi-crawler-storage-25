"""
Voice-specific conversation state: last_emotion, turn_count, etc.

Extends the LLM ConversationManager notion for voice sessions.

Storage: In-memory by default. For production:
- Set REDIS_URL for Redis (requires redis package)
- Set VOICE_CONVERSATION_DATABASE_URL or DATABASE_URL (postgresql://) for PostgreSQL
  (requires psycopg2 or asyncpg; uses SQLAlchemy)
"""

from __future__ import annotations

import json
import logging
import os
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from threading import Lock

logger = logging.getLogger(__name__)


class VoiceConversationStoreInterface(ABC):
    """Abstract interface for voice conversation storage. Implement for Redis/DB in production."""

    @abstractmethod
    def get_or_create(self, session_id: str) -> "VoiceConversationState":
        """Get existing state or create new one."""
        ...

    @abstractmethod
    def get(self, session_id: str) -> Optional["VoiceConversationState"]:
        """Get state by session_id, or None."""
        ...

    @abstractmethod
    def drop(self, session_id: str) -> None:
        """Remove session state."""
        ...


@dataclass
class VoiceConversationState:
    """Per-session voice state for the pipeline."""

    session_id: str
    turn_count: int = 0
    last_emotion: Optional[str] = None
    last_user_text: Optional[str] = None
    last_agent_text: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def on_turn(self, user_text: str, agent_text: str, emotion: Optional[str] = None) -> None:
        self.turn_count += 1
        self.last_user_text = user_text
        self.last_agent_text = agent_text
        if emotion is not None:
            self.last_emotion = emotion
        self.updated_at = time.time()


class VoiceConversationStore(VoiceConversationStoreInterface):
    """In-memory store for voice session state. Use Redis/Postgres store for production.

    This implementation includes a simple TTL-based cleanup to prevent unbounded
    memory growth in long-running workers when Redis/Postgres are not configured.
    """

    # Match Redis/Postgres TTL (24 hours) for consistency.
    _TTL_SECONDS = 86400
    # Run lightweight cleanup at most once per hour.
    _CLEANUP_INTERVAL_SECONDS = 3600

    def __init__(self) -> None:
        self._sessions: Dict[str, VoiceConversationState] = {}
        self._lock: Lock = Lock()
        self._last_cleanup: float = time.time()

    def _cleanup_expired(self) -> None:
        """Remove expired sessions periodically to bound memory usage."""
        now = time.time()
        if (now - self._last_cleanup) < self._CLEANUP_INTERVAL_SECONDS:
            return

        with self._lock:
            expired: List[str] = []
            for sid, state in self._sessions.items():
                age = now - state.updated_at
                if age > self._TTL_SECONDS:
                    expired.append(sid)

            for sid in expired:
                self._sessions.pop(sid, None)

            if expired:
                logger.info(
                    "Cleaned up %d expired in-memory voice conversation states",
                    len(expired),
                )

            self._last_cleanup = now

    def get_or_create(self, session_id: str) -> VoiceConversationState:
        # Periodic cleanup on hot path (cheap and bounded by _CLEANUP_INTERVAL_SECONDS).
        self._cleanup_expired()

        with self._lock:
            state = self._sessions.get(session_id)
            if state is None:
                state = VoiceConversationState(session_id=session_id)
                self._sessions[session_id] = state
            return state

    def get(self, session_id: str) -> Optional[VoiceConversationState]:
        self._cleanup_expired()

        with self._lock:
            state = self._sessions.get(session_id)
            if state is None:
                return None

            age = time.time() - state.updated_at
            if age > self._TTL_SECONDS:
                # Expired state is removed and treated as missing.
                self._sessions.pop(session_id, None)
                return None
            return state

    def drop(self, session_id: str) -> None:
        with self._lock:
            self._sessions.pop(session_id, None)


def _state_to_dict(state: VoiceConversationState) -> dict:
    """Serialize state for Redis."""
    return {
        "session_id": state.session_id,
        "turn_count": state.turn_count,
        "last_emotion": state.last_emotion,
        "last_user_text": state.last_user_text,
        "last_agent_text": state.last_agent_text,
        "created_at": state.created_at,
        "updated_at": state.updated_at,
        "metadata": state.metadata,
    }


def _dict_to_state(data: dict) -> VoiceConversationState:
    """Deserialize state from Redis."""
    return VoiceConversationState(
        session_id=data["session_id"],
        turn_count=data.get("turn_count", 0),
        last_emotion=data.get("last_emotion"),
        last_user_text=data.get("last_user_text"),
        last_agent_text=data.get("last_agent_text"),
        created_at=data.get("created_at", time.time()),
        updated_at=data.get("updated_at", time.time()),
        metadata=data.get("metadata", {}),
    )


class RedisVoiceConversationStore(VoiceConversationStoreInterface):
    """Redis-backed store for production multi-worker deployments. Requires redis package."""

    _PREFIX = "voice:conv:"
    _TTL_SECONDS = 86400  # 24 hours

    def __init__(self, redis_url: str) -> None:
        import redis

        self._client = redis.from_url(redis_url, decode_responses=True)
        # In-memory fallback used when Redis is unavailable so voice sessions
        # continue instead of crashing.
        self._fallback = VoiceConversationStore()
        self._redis_disabled_until = 0.0
        self._redis_disable_seconds = int(os.getenv("VOICE_REDIS_DISABLE_SECONDS", "300") or "300")

        # Validate connectivity once at startup.
        try:
            self._client.ping()
        except Exception as e:
            self._disable_redis("PING", None, e)

    def _key(self, session_id: str) -> str:
        return f"{self._PREFIX}{session_id}"

    def _redis_enabled(self) -> bool:
        return time.time() >= self._redis_disabled_until

    def _disable_redis(self, op: str, session_id: Optional[str], exc: Exception) -> None:
        self._redis_disabled_until = time.time() + self._redis_disable_seconds
        sid = f" for session={session_id}" if session_id else ""
        logger.warning(
            "Voice Redis %s failed%s: %s. Disabling Redis for %ss and using in-memory fallback.",
            op,
            sid,
            exc,
            self._redis_disable_seconds,
        )

    def _write_fallback_state(self, state: VoiceConversationState) -> None:
        fb = self._fallback.get_or_create(state.session_id)
        fb.turn_count = state.turn_count
        fb.last_emotion = state.last_emotion
        fb.last_user_text = state.last_user_text
        fb.last_agent_text = state.last_agent_text
        fb.created_at = state.created_at
        fb.updated_at = state.updated_at
        fb.metadata = dict(state.metadata or {})

    def _save(self, state: VoiceConversationState) -> None:
        """Persist state to Redis."""
        # Always mirror to in-memory so we can continue immediately if Redis drops.
        self._write_fallback_state(state)

        if not self._redis_enabled():
            return

        try:
            self._client.setex(
                self._key(state.session_id),
                self._TTL_SECONDS,
                json.dumps(_state_to_dict(state)),
            )
        except Exception as e:
            self._disable_redis("SET", state.session_id, e)

    def get_or_create(self, session_id: str) -> VoiceConversationState:
        if not self._redis_enabled():
            return self._fallback.get_or_create(session_id)

        key = self._key(session_id)
        try:
            data = self._client.get(key)
        except Exception as e:
            self._disable_redis("GET", session_id, e)
            return self._fallback.get_or_create(session_id)

        if data:
            try:
                state = _dict_to_state(json.loads(data))
                self._write_fallback_state(state)
                return _PersistedState(state, self._save)
            except (json.JSONDecodeError, KeyError) as e:
                logger.warning("Redis conversation state corrupt for %s: %s", session_id, e)

        state = VoiceConversationState(session_id=session_id)
        self._save(state)
        return _PersistedState(state, self._save)

    def get(self, session_id: str) -> Optional[VoiceConversationState]:
        if not self._redis_enabled():
            return self._fallback.get(session_id)

        try:
            data = self._client.get(self._key(session_id))
        except Exception as e:
            self._disable_redis("GET", session_id, e)
            return self._fallback.get(session_id)

        if not data:
            return self._fallback.get(session_id)
        try:
            state = _dict_to_state(json.loads(data))
            self._write_fallback_state(state)
            return state
        except (json.JSONDecodeError, KeyError):
            return self._fallback.get(session_id)

    def drop(self, session_id: str) -> None:
        self._fallback.drop(session_id)
        if not self._redis_enabled():
            return
        try:
            self._client.delete(self._key(session_id))
        except Exception as e:
            self._disable_redis("DELETE", session_id, e)


class _PersistedState:
    """State wrapper that persists to Redis on on_turn. Delegates attributes to inner state."""

    def __init__(self, inner: VoiceConversationState, save_fn: Any) -> None:
        self._inner = inner
        self._save_fn = save_fn

    def __getattr__(self, name: str) -> Any:
        return getattr(self._inner, name)

    def on_turn(self, user_text: str, agent_text: str, emotion: Optional[str] = None) -> None:
        self._inner.on_turn(user_text, agent_text, emotion)
        self._save_fn(self._inner)


class PostgresVoiceConversationStore(VoiceConversationStoreInterface):
    """PostgreSQL-backed store. Uses SQLAlchemy + psycopg2. Requires table voice_conversation_state."""

    _TTL_SECONDS = 86400

    def __init__(self, database_url: str) -> None:
        from sqlalchemy import create_engine

        self._engine = create_engine(database_url, pool_pre_ping=True)
        self._ensure_table()

    def _ensure_table(self) -> None:
        from sqlalchemy import text

        with self._engine.connect() as conn:
            conn.execute(
                text("""
                CREATE TABLE IF NOT EXISTS voice_conversation_state (
                    session_id VARCHAR(512) PRIMARY KEY,
                    data JSONB NOT NULL,
                    expires_at TIMESTAMP WITH TIME ZONE
                )
            """)
            )
            conn.commit()

    def _key(self, session_id: str) -> str:
        return f"voice:conv:{session_id}"

    def _save(self, state: VoiceConversationState) -> None:
        from datetime import datetime, timezone, timedelta
        from sqlalchemy import text

        data = json.dumps(_state_to_dict(state))
        expires = datetime.now(timezone.utc) + timedelta(seconds=self._TTL_SECONDS)
        with self._engine.connect() as conn:
            conn.execute(
                text("""
                    INSERT INTO voice_conversation_state (session_id, data, expires_at)
                    VALUES (:sid, CAST(:data AS jsonb), :exp)
                    ON CONFLICT (session_id) DO UPDATE SET data = CAST(:data AS jsonb), expires_at = :exp
                """),
                {"sid": state.session_id, "data": data, "exp": expires},
            )
            conn.commit()

    def get_or_create(self, session_id: str) -> VoiceConversationState:
        from sqlalchemy import text

        with self._engine.connect() as conn:
            row = conn.execute(
                text("SELECT data FROM voice_conversation_state WHERE session_id = :sid"),
                {"sid": session_id},
            ).fetchone()
        if row:
            try:
                state = _dict_to_state(json.loads(row[0]))
                return _PersistedState(state, self._save)
            except (json.JSONDecodeError, KeyError) as e:
                logger.warning("Postgres conversation state corrupt for %s: %s", session_id, e)
        state = VoiceConversationState(session_id=session_id)
        self._save(state)
        return _PersistedState(state, self._save)

    def get(self, session_id: str) -> Optional[VoiceConversationState]:
        from sqlalchemy import text

        with self._engine.connect() as conn:
            row = conn.execute(
                text("SELECT data FROM voice_conversation_state WHERE session_id = :sid"),
                {"sid": session_id},
            ).fetchone()
        if not row:
            return None
        try:
            return _dict_to_state(json.loads(row[0]))
        except (json.JSONDecodeError, KeyError):
            return None

    def drop(self, session_id: str) -> None:
        from sqlalchemy import text

        with self._engine.connect() as conn:
            conn.execute(text("DELETE FROM voice_conversation_state WHERE session_id = :sid"), {"sid": session_id})
            conn.commit()


def get_conversation_store() -> VoiceConversationStoreInterface:
    """Return the appropriate store: Redis, PostgreSQL, or in-memory.

    Voice session state is *ephemeral* (turn counter, last emotion, etc.)
    and is best stored in Redis or in-memory.  The PostgreSQL backend
    (``voice_conversation_state`` table) is available for workers that
    need to survive restarts, but it is separate from the normalised
    ``conversations`` tables used for permanent chat history.

    Priority:
    1. Redis (REDIS_URL) -- recommended for multi-worker voice agents.
    2. PostgreSQL (VOICE_CONVERSATION_DATABASE_URL | DATABASE_URL) -- legacy.
    3. In-memory -- default for development / single-worker.
    """
    redis_url = os.getenv("REDIS_URL", "").strip()
    if redis_url:
        try:
            return RedisVoiceConversationStore(redis_url)
        except ImportError as e:
            logger.warning("REDIS_URL set but redis not installed (%s); trying next backend", e)

    db_url = (os.getenv("VOICE_CONVERSATION_DATABASE_URL") or "").strip()
    if db_url and db_url.split(":")[0] in ("postgresql", "postgres"):
        try:
            logger.info("Using PostgreSQL for voice conversation state (ephemeral data -- consider REDIS_URL instead)")
            return PostgresVoiceConversationStore(db_url)
        except ImportError as e:
            logger.warning("PostgreSQL URL set but psycopg2 not installed (%s); using in-memory", e)
        except Exception as e:
            logger.warning("PostgreSQL conversation store failed (%s); using in-memory", e)

    logger.info("Using in-memory voice conversation store (state lost on restart)")
    return VoiceConversationStore()
