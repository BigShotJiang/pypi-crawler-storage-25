"""
TTS Adapter - Wraps your custom TTS engine for LiveKit

This adapter implements LiveKit's TTS interface while using your custom
TTS engine under the hood.
"""

import logging
import os
from typing import Optional

import time

from livekit.agents import tts as lk_tts
from livekit.agents.types import DEFAULT_API_CONNECT_OPTIONS, APIConnectOptions
from livekit.agents.utils import shortuuid

from .constants import VOICE_FALLBACK_PHRASES


def _dedupe_repeated_content(text: str, min_len: int = 24) -> str:
    """
    Remove exact duplicate content (e.g. Gemini streaming bug repeats the full response).
    If text is the same substring repeated twice exactly, return the first occurrence.
    Only applies when len(text) >= min_len to avoid false positives on short phrases
    (e.g. "no no", "go go").
    """
    if not text or len(text) < min_len:
        return text
    half = len(text) // 2
    if text[:half] == text[half:]:
        return text[:half]
    return text


try:
    # Prefer specific TTS error types when the full framework is available.
    from narrative_ai.engines.tts.base_tts import AuthenticationError, TTSError
except Exception:  # pragma: no cover - defensive fallback when engines package not present
    AuthenticationError = TTSError = Exception

logger = logging.getLogger(__name__)


class CustomTTS(lk_tts.TTS):
    """
    LiveKit TTS adapter for your custom TTS engine.

    Wraps your framework's TTS engine to work with LiveKit's AgentSession.
    """

    def __init__(
        self,
        tts_engine,
        *,
        sample_rate: int = 24000,
        voice_id: Optional[str] = None,
        turn_metadata: Optional[dict] = None,
        default_language: Optional[str] = None,
    ):
        """
        Initialize TTS adapter.

        Args:
            tts_engine: Your framework's TTS engine instance
            sample_rate: Output audio sample rate in Hz
            voice_id: Voice ID (e.g., ElevenLabs voice ID)
            turn_metadata: Shared dict with emotion/language from LLM (read before synth)
            default_language: Fallback language when turn_metadata has none
        """
        super().__init__(
            capabilities=lk_tts.TTSCapabilities(streaming=True),
            sample_rate=sample_rate,
            num_channels=1,
        )
        self._engine = tts_engine
        self._sample_rate = sample_rate
        self._voice_id = voice_id
        self._turn_metadata = turn_metadata if turn_metadata is not None else {}
        self._default_language = default_language or "en"
        # Deduplicate identical assistant utterances within a short window to avoid
        # speaking the exact same reply twice (e.g. duplicate assistant messages).
        self._last_text: Optional[str] = None
        self._last_text_time: float = 0.0
        try:
            self._dedupe_window_seconds = max(0.0, float(os.getenv("VOICE_TTS_DEDUPE_WINDOW_SECONDS", "10")))
        except (ValueError, TypeError):
            self._dedupe_window_seconds = 10.0

        logger.info(f"Custom TTS adapter initialized: sample_rate={sample_rate}, voice={voice_id}")

    def stream(
        self,
        *,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
    ) -> "CustomTTSStream":
        """
        Create a new TTS stream.

        Returns:
            CustomTTSStream instance
        """
        return CustomTTSStream(
            tts=self,
            conn_options=conn_options,
        )

    def synthesize(
        self,
        text: str,
        *,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
    ) -> lk_tts.ChunkedStream:
        """
        Synthesize speech from text (non-streaming fallback).

        This creates a stream under the hood.

        Args:
            text: Text to synthesize
            conn_options: Connection options

        Returns:
            ChunkedStream
        """
        return lk_tts.TTS._synthesize_with_stream(self, text=text, conn_options=conn_options)


class CustomTTSStream(lk_tts.SynthesizeStream):
    """
    TTS stream implementation that synthesizes speech via your custom engine.
    """

    def __init__(
        self,
        tts: CustomTTS,
        conn_options: APIConnectOptions,
    ):
        super().__init__(tts=tts, conn_options=conn_options)

    async def _metrics_monitor_task(self, event_aiter) -> None:
        """Consume events for metrics (no-op for custom adapter)."""
        async for _ in event_aiter:
            pass

    async def _run(self, output_emitter: lk_tts.AudioEmitter) -> None:
        """Run synthesis loop: read text from _input_ch, synthesize via engine, push to output_emitter."""
        tts = self._tts  # CustomTTS
        engine = tts._engine
        sample_rate = tts._sample_rate
        voice_id = tts._voice_id

        request_id = shortuuid()
        output_emitter.initialize(
            request_id=request_id,
            sample_rate=sample_rate,
            num_channels=1,
            mime_type="audio/pcm",
            stream=True,
        )

        segment_id = shortuuid()
        output_emitter.start_segment(segment_id=segment_id)

        try:
            pushed_any_audio = False
            min_chunk_chars = max(20, int(os.getenv("VOICE_TTS_MIN_CHUNK_CHARS", "48")))
            max_buffer_chars = max(min_chunk_chars + 16, int(os.getenv("VOICE_TTS_MAX_BUFFER_CHARS", "220")))
            sentence_boundaries = (".", "!", "?", "\n", ";", ":", "،", "؟", "؛")
            text_buffer = ""

            def _extract_speakable(buffer: str, *, force: bool = False) -> tuple[str, str]:
                if not buffer:
                    return "", ""
                if force:
                    return buffer.strip(), ""

                split_at = -1
                for mark in sentence_boundaries:
                    split_at = max(split_at, buffer.rfind(mark))

                if split_at >= 0 and (split_at + 1) >= min_chunk_chars:
                    return buffer[: split_at + 1].strip(), buffer[split_at + 1 :]

                if len(buffer) >= max_buffer_chars:
                    cut = buffer.rfind(" ", 0, max_buffer_chars)
                    if cut <= 0:
                        cut = max_buffer_chars
                    return buffer[:cut].strip(), buffer[cut:]

                return "", buffer

            async def _speak_chunk(text_chunk: str) -> None:
                chunk = text_chunk.strip()
                if not chunk:
                    return

                # Defensive dedupe: if a provider emits exact duplicated halves, collapse it.
                orig_len = len(chunk)
                chunk = _dedupe_repeated_content(chunk)
                if len(chunk) < orig_len:
                    logger.info(
                        "TTS: Trimmed duplicated content (chars %d -> %d)",
                        orig_len,
                        len(chunk),
                    )
                if not chunk:
                    return

                # Short-window dedupe to suppress accidental repeated segment playback.
                is_fallback = chunk.lower() in VOICE_FALLBACK_PHRASES
                dedupe_window = getattr(tts, "_dedupe_window_seconds", 0.0)
                if dedupe_window and not is_fallback:
                    now = time.monotonic()
                    last_text = (getattr(tts, "_last_text", None) or "").strip().lower()
                    last_time = float(getattr(tts, "_last_text_time", 0.0) or 0.0)
                    if last_text and chunk.lower() == last_text and (now - last_time) <= dedupe_window:
                        logger.info(
                            "TTS: Skipping duplicate synthesis within %.1fs window (request_id=%s, chars=%d)",
                            dedupe_window,
                            request_id,
                            len(chunk),
                        )
                        return
                    tts._last_text = chunk
                    tts._last_text_time = now

                logger.info(
                    "TTS: Synthesizing %d chars (request_id=%s, preview=%r)",
                    len(chunk),
                    request_id,
                    chunk[:120],
                )

                # Emotion/language from LLM turn_metadata (written on final chunk)
                meta = getattr(tts, "_turn_metadata", None) or {}
                emotion = meta.get("emotion") if isinstance(meta, dict) else None
                language = (meta.get("language") if isinstance(meta, dict) else None) or getattr(
                    tts, "_default_language", "en"
                )

                synth_kwargs = {
                    "text": chunk,
                    "voice_id": voice_id,
                    "output_format": "pcm_24000",  # Explicit for LiveKit compatibility; engine default may change
                }
                if emotion is not None:
                    synth_kwargs["emotion"] = emotion
                if language is not None:
                    synth_kwargs["language"] = language

                start_time = time.perf_counter()
                first_chunk_time: Optional[float] = None
                audio_stream = engine.synthesize_streaming(**synth_kwargs)
                try:
                    async for audio_chunk in audio_stream:
                        if not audio_chunk:
                            continue
                        if first_chunk_time is None:
                            first_chunk_time = time.perf_counter()
                            logger.info(
                                "TTS: First audio chunk ready (request_id=%s, first_chunk_latency_ms=%.1f)",
                                request_id,
                                (first_chunk_time - start_time) * 1000.0,
                            )
                        output_emitter.push(audio_chunk)
                finally:
                    try:
                        if hasattr(audio_stream, "aclose"):
                            await audio_stream.aclose()  # type: ignore[func-returns-value]
                    except Exception as close_err:
                        logger.debug("Error while closing TTS audio_stream: %s", close_err)

                output_emitter.flush()
                total_ms = (time.perf_counter() - start_time) * 1000.0
                logger.debug(
                    "TTS: Synthesis complete (request_id=%s, total_latency_ms=%.1f)",
                    request_id,
                    total_ms,
                )

            async for item in self._input_ch:
                if isinstance(item, self._FlushSentinel):
                    break
                if not isinstance(item, str) or not item:
                    continue

                text_buffer += item
                while True:
                    speak_now, text_buffer = _extract_speakable(text_buffer, force=False)
                    if not speak_now:
                        break
                    await _speak_chunk(speak_now)

            # Flush any tail text when generation ends.
            tail_text, text_buffer = _extract_speakable(text_buffer, force=True)
            if tail_text:
                await _speak_chunk(tail_text)
        except AuthenticationError as e:
            # Authentication failures (e.g. invalid API key) are user/config issues.
            # Log clearly but don't crash the whole voice session; LiveKit will simply
            # not receive audio for this turn.
            if not locals().get("pushed_any_audio", False):
                # Prevent LiveKit "no audio frames were pushed" hard failure for this turn.
                silence_samples = int(sample_rate * 0.02)  # 20ms
                output_emitter.push(b"\x00" * (silence_samples * 2))
            logger.error(
                "TTS authentication failed for provider (likely invalid API key): %s",
                e,
                exc_info=True,
            )
        except TTSError as e:
            # Known TTS provider errors (rate limit, voice not found, etc.).
            # We log and gracefully end the segment so the agent can continue.
            if not locals().get("pushed_any_audio", False):
                silence_samples = int(sample_rate * 0.02)  # 20ms
                output_emitter.push(b"\x00" * (silence_samples * 2))
            logger.error("TTS provider error during synthesis: %s", e, exc_info=True)
        except Exception as e:
            # Unexpected errors should still surface so they can be fixed.
            logger.error(f"TTS synthesis unexpected error: {e}", exc_info=True)
            raise
        finally:
            output_emitter.flush()
            output_emitter.end_segment()
