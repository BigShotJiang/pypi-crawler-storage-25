"""
Voice Agent Worker

This is the main entry point for the LiveKit voice agent.
It handles engine prewarming and session management.
"""
# ruff: noqa: E402  # Imports must follow DEFAULT_AGENT_NAME and plugin registration order

import asyncio
import json
import logging
import os
import re
import sys
import time
import signal
import uuid
from typing import Optional

# Agent name must match what the client dispatches (e.g. scripts/join_voice_room.py uses "narrative-voice").
# Set LIVEKIT_AGENT_NAME in .env to override.
DEFAULT_AGENT_NAME = "narrative-voice"

from livekit.agents import AgentSession, AutoSubscribe, JobContext, JobProcess, WorkerOptions, cli
from livekit.agents.utils import shortuuid
from livekit.agents.voice import room_io

# Register LiveKit ElevenLabs plugin on the main thread (required by livekit.agents).
# Must be imported here when the worker process loads; if we import it only inside the
# entrypoint (job runner thread), we get "Plugins must be registered on the main thread".
# If this runs in a non-main thread (e.g. some process layouts), we catch and skip;
# the agent will then use the framework STT (CustomSTT) via VOICE_USE_FRAMEWORK_STT or no plugin.
try:
    import livekit.plugins.elevenlabs  # noqa: F401
except (ImportError, RuntimeError):
    pass

# Optional: turn detection (MultilingualModel). Install: livekit-plugins-turn-detector, run download-files.
# When available, used by default for ~39% reduction in early interruptions (LiveKit blog).
# Set VOICE_USE_TURN_DETECTOR=0 to disable (e.g. resource constraints).
_turn_detector_model = None
_turn_detector_disabled_by_env = os.getenv("VOICE_USE_TURN_DETECTOR", "").strip().lower() in ("0", "false", "no")
if not _turn_detector_disabled_by_env:
    try:
        from livekit.plugins.turn_detector.multilingual import MultilingualModel

        _turn_detector_model = MultilingualModel
    except ImportError:
        try:
            from livekit.plugins.turn_detector import MultilingualModel

            _turn_detector_model = MultilingualModel
        except ImportError:
            pass

# Optional: noise cancellation (BVC). Install: livekit-plugins-noise-cancellation, then download-files.
_noise_cancellation_plugin = None
try:
    from livekit.plugins import noise_cancellation

    _noise_cancellation_plugin = noise_cancellation
except ImportError:
    pass

from .agent import NarrativeAgent
from .config import load_config_from_providers
from .conversation import get_conversation_store
from .security_hooks import check_rate_limit, audit_turn, RateLimitExceeded

logger = logging.getLogger(__name__)

# Unique identifier per worker process (helps correlate logs when multiple workers are running).
_WORKER_ID = shortuuid()

# Conversation state store (in-memory or Redis when REDIS_URL is set)
_conversation_store = get_conversation_store()

# Global shutdown event used to coordinate graceful shutdown across sessions.
_shutdown_event: Optional[asyncio.Event] = None
_shutdown_event_loop: Optional[asyncio.AbstractEventLoop] = None
_shutdown_requested: bool = False


def _get_shutdown_event(loop: asyncio.AbstractEventLoop) -> asyncio.Event:
    """Return a shutdown event bound to the given loop."""
    global _shutdown_event, _shutdown_event_loop
    if _shutdown_event is None or _shutdown_event_loop is not loop:
        _shutdown_event = asyncio.Event()
        _shutdown_event_loop = loop
    return _shutdown_event


def _extract_session_id_from_room(room_name: str, participant_identity: Optional[str]) -> Optional[str]:
    """Extract canonical conversation session id from room name when available.

    Expected format from token route:
      voice-<user_uuid>-<session_id>
    """
    if not room_name or not room_name.startswith("voice-"):
        return None

    if participant_identity:
        prefix = f"voice-{participant_identity}-"
        if room_name.startswith(prefix):
            candidate = room_name[len(prefix) :].strip("-_")
            if candidate:
                return candidate

    match = re.match(r"^voice-[0-9a-fA-F-]{36}-(?P<session>[A-Za-z0-9_-]+)$", room_name)
    if match:
        return match.group("session")

    return None


# =============================================================================
# ENGINE PREWARMING (Module-level - runs ONCE per job process)
# =============================================================================

# Global engine instances (shared across sessions in the same process)
_stt_engine = None
_llm_engine = None
_tts_engine = None
_engines_loop: Optional[asyncio.AbstractEventLoop] = None
# Lock is created lazily in prewarm_engines() so it's bound to the current
# event loop (entrypoint's loop). Creating it at import time would bind it
# to a different loop and cause "bound to a different event loop" errors.
_engines_lock: Optional[asyncio.Lock] = None


def _get_engines_lock() -> asyncio.Lock:
    """Return a lock bound to the current running event loop."""
    global _engines_lock
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    if _engines_lock is None or getattr(_engines_lock, "_loop", object()) is not loop:
        _engines_lock = asyncio.Lock()
        _engines_lock._loop = loop  # type: ignore[attr-defined]
    return _engines_lock


async def prewarm_engines():
    """
    Prewarm all engines ONCE per job process. Called from entrypoint on first
    session so the lock is always used in the same event loop as the job.
    """
    global _stt_engine, _llm_engine, _tts_engine, _engines_loop

    async def _safe_shutdown_engine(name: str, engine_obj) -> None:
        if engine_obj is None:
            return
        shutdown_fn = getattr(engine_obj, "shutdown", None)
        if shutdown_fn is None:
            return
        try:
            maybe_coro = shutdown_fn()
            if asyncio.iscoroutine(maybe_coro):
                await maybe_coro
        except Exception as e:
            logger.debug("Failed to shutdown old %s engine during loop rebinding: %s", name, e)

    current_loop = asyncio.get_running_loop()

    async with _get_engines_lock():
        # Only prewarm if already initialized on the same event loop.
        if _stt_engine is not None and _engines_loop is current_loop:
            logger.info("Engines already prewarmed")
            return

        # Engines created on another event loop (previous job runner) may hold
        # loop-bound resources (aiohttp sessions, tasks). Reinitialize for the
        # current loop to avoid cross-loop runtime errors.
        if _stt_engine is not None and _engines_loop is not current_loop:
            logger.info("Detected event loop change for prewarmed engines; reinitializing for current loop")
            await _safe_shutdown_engine("tts", _tts_engine)
            await _safe_shutdown_engine("llm", _llm_engine)
            await _safe_shutdown_engine("stt", _stt_engine)
            _stt_engine = None
            _llm_engine = None
            _tts_engine = None

        logger.info("🔥 Prewarming engines...")
        start_time = time.monotonic()

        # Prewarm STT engine
        logger.info("Prewarming STT engine...")
        stt_start = time.monotonic()
        try:
            from narrative_ai.engines.stt import create_stt_engine_from_providers

            _stt_engine = await create_stt_engine_from_providers()
            stt_elapsed = time.monotonic() - stt_start
            logger.info(f"✅ STT engine prewarmed in {stt_elapsed:.2f}s")
        except Exception as e:
            logger.error(f"❌ Failed to prewarm STT engine: {e}")
            raise

        # Prewarm LLM engine (framework uses LLMEngine() + initialize())
        logger.info("Prewarming LLM engine...")
        llm_start = time.monotonic()
        try:
            from narrative_ai.engines.llm import LLMEngine

            _llm_engine = LLMEngine()
            await _llm_engine.initialize()
            llm_elapsed = time.monotonic() - llm_start
            logger.info(f"✅ LLM engine prewarmed in {llm_elapsed:.2f}s")
        except Exception as e:
            logger.error(f"❌ Failed to prewarm LLM engine: {e}")
            raise

        # Prewarm TTS engine
        logger.info("Prewarming TTS engine...")
        tts_start = time.monotonic()
        try:
            from narrative_ai.engines.tts import create_tts_engine_from_providers

            _tts_engine = await create_tts_engine_from_providers()
            tts_elapsed = time.monotonic() - tts_start
            logger.info(f"✅ TTS engine prewarmed in {tts_elapsed:.2f}s")
        except Exception as e:
            logger.error(f"❌ Failed to prewarm TTS engine: {e}")
            raise

        total_elapsed = time.monotonic() - start_time
        _engines_loop = current_loop
        logger.info(f"🚀 All engines prewarmed in {total_elapsed:.2f}s")


def get_prewarmed_engines():
    """
    Get prewarmed engines.

    Returns:
        Tuple of (stt_engine, llm_engine, tts_engine)

    Raises:
        RuntimeError: If engines haven't been prewarmed
    """
    if _stt_engine is None or _llm_engine is None or _tts_engine is None:
        raise RuntimeError("Engines not prewarmed! Make sure prewarm_engines() is called in prewarm_fnc.")

    return _stt_engine, _llm_engine, _tts_engine


# =============================================================================
# LIVEKIT WORKER FUNCTIONS
# =============================================================================


def prewarm(proc: JobProcess) -> None:
    """
    Prewarm function - called synchronously by LiveKit when each job process
    is initialized. We do NOT run engine prewarm here because:
    - asyncio.run() would create a different event loop, so our Lock would
      be "bound to a different event loop" when entrypoint runs.
    - Engine init takes ~15s but LiveKit's initialize_process_timeout is 10s,
      so process init would time out.
    Engines are prewarmed on first connection in entrypoint (await prewarm_engines()).
    """
    logger.info("Worker process ready (engines will prewarm on first connection).")


async def entrypoint(ctx: JobContext):
    """
    Entrypoint - called for EACH new session.

    Connect to the room first (within 10s) to satisfy LiveKit, then prewarm
    engines and start the agent. Subsequent sessions in the same process
    start quickly thanks to prewarming.

    Args:
        ctx: Job context with room and participant info
    """
    room_name = getattr(ctx.room, "name", "unknown")
    participant_identity = getattr(getattr(ctx, "participant", None), "identity", None)
    logger.info(
        "📞 New session request for room: %s, participant: %s",
        room_name,
        participant_identity or "unknown",
    )

    session = None
    try:
        # Connect to room FIRST so LiveKit sees connection within 10s (avoids timeout warning).
        # Then we prewarm and start the session; the client will see the agent join after prewarm.
        await ctx.connect(auto_subscribe=AutoSubscribe.AUDIO_ONLY)

        # Prefer canonical cross-modality session IDs from room naming:
        #   voice-<user_uuid>-<session_id>
        # and fall back to legacy room/participant derived IDs.
        session_id = _extract_session_id_from_room(room_name, participant_identity)
        if not session_id:
            if participant_identity:
                session_id = f"{room_name}:{participant_identity}"
            else:
                session_id = room_name or "unknown"

        # Resolve authenticated user/tenant context for shared chat pipeline (profile + RAG).
        # Prefer UUID participant identity; otherwise allow metadata JSON:
        # {"user_id":"<uuid>","tenant_id":"<uuid>"}.
        voice_user_id: Optional[str] = None
        voice_tenant_id: Optional[str] = None
        if participant_identity:
            try:
                voice_user_id = str(uuid.UUID(str(participant_identity)))
            except (ValueError, TypeError, AttributeError):
                voice_user_id = None

        # Fallback for deployments where participant identity is unavailable in
        # the initial JobContext: infer user UUID from canonical room naming.
        # Expected format from token route: "voice-<user_uuid>-<session_id>".
        if not voice_user_id and isinstance(room_name, str) and room_name.startswith("voice-"):
            match = re.match(r"^voice-(?P<user>[0-9a-fA-F-]{36})(?:-[A-Za-z0-9_-]+)?$", room_name)
            candidate = match.group("user") if match else room_name[len("voice-") :].strip()
            try:
                voice_user_id = str(uuid.UUID(candidate))
            except (ValueError, TypeError, AttributeError):
                voice_user_id = None

        participant_metadata = getattr(getattr(ctx, "participant", None), "metadata", None)
        if participant_metadata:
            try:
                metadata_obj = (
                    json.loads(participant_metadata)
                    if isinstance(participant_metadata, str)
                    else dict(participant_metadata)
                )
            except Exception:
                metadata_obj = {}
            if not voice_user_id:
                raw_uid = metadata_obj.get("user_id")
                if raw_uid:
                    try:
                        voice_user_id = str(uuid.UUID(str(raw_uid)))
                    except (ValueError, TypeError, AttributeError):
                        voice_user_id = None
            raw_tid = metadata_obj.get("tenant_id")
            if raw_tid:
                try:
                    voice_tenant_id = str(uuid.UUID(str(raw_tid)))
                except (ValueError, TypeError, AttributeError):
                    voice_tenant_id = None
            raw_sid = metadata_obj.get("session_id")
            if raw_sid:
                normalized_sid = str(raw_sid).strip()
                if normalized_sid:
                    session_id = normalized_sid

        # Voice-session rate limiting: apply a lightweight check before heavy engine init.
        try:
            check_rate_limit(
                session_id=session_id,
                user_id=voice_user_id,
                tenant_id=voice_tenant_id,
            )
        except Exception as e:
            # Distinguish between hard rate limits and unexpected failures.
            if RateLimitExceeded is not None and isinstance(e, RateLimitExceeded):
                logger.warning("Voice session rate limit exceeded for %s; disconnecting", session_id)
                try:
                    await ctx.room.disconnect()
                except Exception as disc_err:
                    logger.debug("Error while disconnecting rate-limited room %s: %s", session_id, disc_err)
                return
            logger.error("Voice session rate limit check failed for %s: %s", session_id, e, exc_info=True)
            raise

        # Ensure engines are prewarmed in this process (idempotent; no-op if already done)
        await prewarm_engines()

        # Get prewarmed engines (instant if prewarm ran in process init)
        stt_engine, llm_engine, tts_engine = get_prewarmed_engines()

        # Load configuration
        config = load_config_from_providers()

        # Create agent with prewarmed engines
        agent = NarrativeAgent(
            stt_engine=stt_engine,
            llm_engine=llm_engine,
            tts_engine=tts_engine,
            config=config,
            user_id=voice_user_id,
            tenant_id=voice_tenant_id,
            session_id=session_id,
        )

        # Turn detection: MultilingualModel when available. Reduces early interruptions (~39% per LiveKit).
        # Enabled by default when plugin installed; set VOICE_USE_TURN_DETECTOR=0 to disable.
        turn_detection = None
        use_turn_detector_env = os.getenv("VOICE_USE_TURN_DETECTOR", "").strip().lower()
        turn_detector_disabled = use_turn_detector_env in ("0", "false", "no")
        if not turn_detector_disabled and _turn_detector_model is not None:
            try:
                turn_detection = _turn_detector_model()
                logger.info("Using turn_detection=MultilingualModel() (reduces early interruptions)")
            except Exception as e:
                logger.warning("Turn detector init failed (%s), continuing without: %s", type(e).__name__, e)

        # Room options: noise_cancellation=BVC() when VOICE_USE_NOISE_CANCELLATION=1 (run download-files after installing).
        room_options = None
        if (
            os.getenv("VOICE_USE_NOISE_CANCELLATION", "").strip().lower() in ("1", "true", "yes")
            and _noise_cancellation_plugin is not None
        ):
            room_options = room_io.RoomOptions(
                audio_input=room_io.AudioInputOptions(
                    noise_cancellation=_noise_cancellation_plugin.BVC(),
                ),
            )
            logger.info("Using noise_cancellation=BVC() in RoomOptions")

        # Create session. preemptive_generation comes from config (default True for low latency).
        # resume_false_interruption=False avoids "_SegmentSynchronizerImpl.resume called after close".
        session_kw: dict = {
            "allow_interruptions": config.allow_interruptions,
            "min_endpointing_delay": config.min_endpointing_delay,
            "max_endpointing_delay": config.max_endpointing_delay,
            "preemptive_generation": config.preemptive_generation,
            "resume_false_interruption": config.resume_false_interruption,
            "false_interruption_timeout": config.false_interruption_timeout,
        }
        if turn_detection is not None:
            session_kw["turn_detection"] = turn_detection
        session = AgentSession(**session_kw)

        # Basic observability hooks for AgentSession events. Use a local dict
        # (session.userdata may not be set until after session.start() in some SDK versions).
        metrics_slot: dict = {}

        try:

            @session.on("agent_state_changed")
            def _on_agent_state_changed(*args, **kwargs):
                logger.info("Agent state changed: args=%s kwargs_keys=%s", args, list(kwargs.keys()))
        except Exception:
            logger.debug("agent_state_changed event not available on AgentSession")

        try:

            @session.on("user_input_transcribed")
            def _on_user_input_transcribed(ev):
                # Track when user input was transcribed for simple latency measurements.
                # Event uses .transcript (not .text) per LiveKit API
                text = getattr(ev, "transcript", None) or getattr(ev, "text", None) or getattr(ev, "value", None) or ""
                metrics_slot["last_user_input_ts"] = time.time()
                logger.info("User input transcribed: %r", str(text)[:200])
        except Exception:
            logger.debug("user_input_transcribed event not available on AgentSession")

        try:

            @session.on("speech_created")
            def _on_speech_created(ev):
                # Rough LLM→TTS latency: from last_user_input_ts to first speech_created.
                now_ts = time.time()
                start_ts = metrics_slot.get("last_user_input_ts")
                if start_ts is not None and "tts_first_chunk_ts" not in metrics_slot:
                    metrics_slot["tts_first_chunk_ts"] = now_ts
                    latency = now_ts - start_ts
                    logger.info("TTS first chunk latency (approx): %.3fs", latency)
        except Exception:
            logger.debug("speech_created event not available on AgentSession")

        # Start session (optionally with room_options for noise cancellation).
        logger.info("Starting agent session...")
        if room_options is not None:
            await session.start(agent=agent, room=ctx.room, room_options=room_options)
        else:
            await session.start(agent=agent, room=ctx.room)

        logger.info("✅ Agent session started successfully")

        # Conversation state and auditing for each completed user→assistant turn.
        store = _conversation_store
        state = store.get_or_create(session_id)
        _last_user: list[str] = [""]

        async def _on_conversation_item_added_async(ev):
            try:
                item = getattr(ev, "item", None)
                if item is None:
                    return
                role = getattr(item, "role", None)
                if hasattr(role, "value"):
                    role = role.value
                content = getattr(item, "content", "")
                if isinstance(content, list):
                    content = (
                        " ".join(
                            (getattr(c, "text", None) or str(c))
                            for c in content
                            if hasattr(c, "text") or isinstance(c, str)
                        )
                        if content
                        else ""
                    )
                else:
                    content = str(content) if content else ""
                emotion = None
                if hasattr(item, "metadata") and isinstance(getattr(item, "metadata", None), dict):
                    emotion = (item.metadata or {}).get("emotion")

                if role == "user":
                    _last_user[0] = content
                elif role == "assistant" and _last_user[0]:
                    try:
                        await audit_turn(session_id, _last_user[0], content, emotion=emotion)
                    except Exception as audit_err:
                        logger.debug("audit_turn failed for session %s: %s", session_id, audit_err)
                    state.on_turn(_last_user[0], content, emotion)
                    _last_user[0] = ""
                    if config.max_turns is not None and state.turn_count >= config.max_turns:
                        logger.info(
                            "Max turns (%s) reached for session %s; disconnecting room", config.max_turns, session_id
                        )
                        try:
                            await ctx.room.disconnect()
                        except Exception as disc_err:
                            logger.debug(
                                "Error while disconnecting room after max_turns for %s: %s", session_id, disc_err
                            )
            except Exception as e:
                logger.debug("conversation_item_added handler error for session %s: %s", session_id, e)

        def _on_conversation_item_added(ev):
            loop = getattr(session, "_loop", None) or asyncio.get_running_loop()
            loop.create_task(_on_conversation_item_added_async(ev))

        try:
            session.on("conversation_item_added", _on_conversation_item_added)
        except Exception:
            # Older or different LiveKit versions may not emit this event; continue without voice-specific audit.
            logger.debug("conversation_item_added event not available on AgentSession")

        # Keep job alive until room disconnects or a global shutdown is requested.
        loop = asyncio.get_running_loop()
        fut = loop.create_future()

        def _on_disconnected(*_args):
            if not fut.done():
                fut.set_result(None)

        try:
            ctx.room.on("disconnected", _on_disconnected)
        except Exception:
            pass

        # Prepare shutdown wait task if a global shutdown has been configured.
        shutdown_event = _get_shutdown_event(loop)
        if _shutdown_requested:
            shutdown_event.set()
        shutdown_task = loop.create_task(shutdown_event.wait())

        try:
            done, pending = await asyncio.wait(
                [fut, shutdown_task],
                return_when=asyncio.FIRST_COMPLETED,
            )

            shutdown_requested = False
            if shutdown_task in done:
                if shutdown_task.cancelled():
                    shutdown_requested = False
                elif shutdown_task.exception() is not None:
                    logger.warning(
                        "Shutdown wait task failed for session %s: %s",
                        session_id,
                        shutdown_task.exception(),
                    )
                else:
                    shutdown_requested = bool(shutdown_task.result())

            # If shutdown was requested, try to say a short goodbye before closing.
            if shutdown_requested and not fut.done():
                logger.info("Global shutdown detected, attempting graceful voice disconnect for session %s", session_id)
                try:
                    # Best-effort polite goodbye; ignore errors if session is already closing.
                    if getattr(agent, "session", None) is not None:
                        agent.session.say(
                            "I need to disconnect now. Thank you for talking with me!",
                            add_to_chat_ctx=False,
                        )
                        await asyncio.sleep(2.0)
                except Exception as goodbye_err:
                    logger.debug("Goodbye message failed for %s: %s", session_id, goodbye_err)
                try:
                    await ctx.room.disconnect()
                except Exception as disc_err:
                    logger.debug("Error while disconnecting room on shutdown for %s: %s", session_id, disc_err)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.debug("entrypoint wait ended: %s", e)
        finally:
            # Cancel any remaining waiters.
            for t in [fut, shutdown_task]:
                if not t.done():
                    t.cancel()
                    try:
                        await t
                    except Exception:
                        pass
            # Drop in-memory conversation state and close the session.
            try:
                _conversation_store.drop(session_id)
            except Exception as drop_err:
                logger.debug("Error dropping conversation state for %s: %s", session_id, drop_err)
            if hasattr(session, "aclose"):
                try:
                    await session.aclose()
                except Exception as e:
                    logger.debug("session.aclose() error: %s", e)

    except Exception as e:
        logger.error(f"❌ Error in entrypoint: {e}", exc_info=True)
        raise


# =============================================================================
# MAIN ENTRY POINT
# =============================================================================


def run_voice_agent():
    """
    Run the voice agent worker.

    This is the main entry point. Call this from your worker script:

        from narrative_ai.engines.voice_mode import run_voice_agent
        run_voice_agent()
    """
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # Reduce noise from libraries
    logging.getLogger("livekit").setLevel(logging.WARNING)
    logging.getLogger("google").setLevel(logging.WARNING)

    logger.info("=" * 60)
    logger.info("Narrative AI Voice Agent Worker")
    logger.info("=" * 60)
    logger.info(
        "Worker starting (pid=%s, worker_id=%s, python=%s)",
        os.getpid(),
        _WORKER_ID,
        sys.version.split()[0],
    )

    # Agent name must match the name used when dispatching (e.g. CreateAgentDispatchRequest(agent_name=...)).
    # Otherwise the worker registers but never receives the job.
    agent_name = os.getenv("LIVEKIT_AGENT_NAME", "").strip() or DEFAULT_AGENT_NAME
    logger.info(
        "Registering worker with agent_name=%r (set LIVEKIT_AGENT_NAME to override, worker_id=%s)",
        agent_name,
        _WORKER_ID,
    )

    # Install signal handlers for graceful shutdown (SIGTERM/SIGINT).
    def _handle_shutdown(signum, _frame):
        logger.info("Received signal %s, initiating graceful shutdown", signum)
        global _shutdown_requested
        _shutdown_requested = True
        loop = _shutdown_event_loop
        event = _shutdown_event
        if loop is None or event is None:
            return
        if loop.is_closed():
            return
        loop.call_soon_threadsafe(event.set)

    try:
        signal.signal(signal.SIGTERM, _handle_shutdown)
        signal.signal(signal.SIGINT, _handle_shutdown)
    except Exception:
        # Some environments (e.g. Windows) may restrict signal usage; ignore.
        logger.debug("Signal handlers could not be registered; continuing without explicit shutdown hooks")

    # Run worker with LiveKit CLI
    # In production: try to enable health check port for liveness/readiness probes.
    # In development: skip (avoids unsupported-param errors on older livekit-agents).
    is_production = os.getenv("ENV", "").lower() == "production"
    worker_kwargs = {
        "entrypoint_fnc": entrypoint,
        "prewarm_fnc": prewarm,
        "agent_name": agent_name,
    }
    if is_production:
        port = int(os.getenv("LIVEKIT_HEALTH_PORT", "8081") or "8081")
        if port > 0:
            worker_kwargs["health_check_port"] = port

    try:
        cli.run_app(WorkerOptions(**worker_kwargs))
    except TypeError as e:
        if "health_check_port" in str(e):
            logger.warning(
                "health_check_port not supported by this livekit-agents version, starting without; "
                "upgrade livekit-agents for health check support"
            )
            worker_kwargs.pop("health_check_port", None)
            cli.run_app(WorkerOptions(**worker_kwargs))
        else:
            raise


if __name__ == "__main__":
    run_voice_agent()
