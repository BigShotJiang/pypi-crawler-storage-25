"""
LiveKit STT plugin that wraps the framework STTEngine.

Maps LiveKit RecognizeStream (push_frame → SpeechEvent) to
STTEngine.transcribe_streaming(audio_stream, sample_rate).
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
import uuid
from typing import AsyncIterator

logger = logging.getLogger(__name__)
_DEBUG = os.getenv("VOICE_MODE_DEBUG", "").strip() == "1"

try:
    from livekit import rtc
    from livekit.agents import stt as lk_stt

    _LIVEKIT_AVAILABLE = True
except ImportError:
    _LIVEKIT_AVAILABLE = False
    lk_stt = None
    rtc = None


def _engine_from_framework():
    """Get STTEngine from narrative_ai. Prefer narrative_ai.engines.stt when available."""
    try:
        from narrative_ai.engines import stt as stt_mod

        if stt_mod is not None and hasattr(stt_mod, "STTEngine"):
            return stt_mod.STTEngine()
    except (ImportError, AttributeError):
        pass
    # Fallback: direct import from stt (works when narrative_ai.engines.stt is not wired)
    import importlib.util
    from pathlib import Path

    # Get the framework/engines directory
    current_file = Path(__file__)
    engines_dir = current_file.parent.parent.parent
    stt_engine_path = engines_dir / "stt" / "stt_engine.py"

    if not stt_engine_path.exists():
        raise RuntimeError(f"STT engine file not found at {stt_engine_path}")

    # Load the module directly from file
    spec = importlib.util.spec_from_file_location(
        "narrative_ai.engines.stt.stt_engine", stt_engine_path, submodule_search_locations=[str(engines_dir / "stt")]
    )
    if spec and spec.loader:
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if hasattr(module, "STTEngine"):
            return module.STTEngine()

    raise RuntimeError(f"Failed to load STTEngine from {stt_engine_path}")


class _NarrativeRecognizeStream(lk_stt.RecognizeStream if _LIVEKIT_AVAILABLE else object):
    """
    Feeds framework STTEngine.transcribe_streaming from _input_ch; emits SpeechEvents to _event_ch.

    Events sent to self._event_ch (FINAL_TRANSCRIPT / INTERIM_TRANSCRIPT) are consumed by LiveKit
    AgentSession to update ChatContext and drive the LLM. If "I didn't catch that" appears, the
    cause is likely in AgentSession consumption or the base RecognizeStream contract, not in
    this plugin's event emission.
    """

    def __init__(self, *, stt, conn_options, sample_rate, language=None, **kwargs):
        super().__init__(stt=stt, conn_options=conn_options, sample_rate=sample_rate)
        self._language = language

    async def _run(self) -> None:
        if not _LIVEKIT_AVAILABLE:
            raise RuntimeError("livekit-agents is not installed")
        engine = self._stt._engine
        needed_sr = self._needed_sr or 16000
        Flush = getattr(lk_stt.RecognizeStream, "_FlushSentinel", type("_Flush", (), {}))

        logger.info("STT stream started, waiting for audio frames from VAD...")
        _frame_count = 0  # Only log first frame and Flush to avoid flooding logs / blocking event loop

        async for item in self._input_ch:
            if _DEBUG:
                logger.debug("STT received item from input channel: type=%s", type(item).__name__)
            if isinstance(item, Flush):
                _frame_count = 0  # Next AudioFrame will be first of new utterance
                if _DEBUG:
                    logger.debug("STT received Flush sentinel")
                continue
            _frame_count += 1
            if _frame_count == 1:
                logger.info("STT received first audio frame, starting transcription")
            sr = 16000
            if hasattr(item, "data"):
                sr = getattr(item, "sample_rate", None) or 16000
            elif isinstance(item, rtc.AudioFrame):
                sr = item.sample_rate
            else:
                if _DEBUG:
                    logger.debug("STT skipping item (not AudioFrame or data): %s", type(item))
                continue

            # Stable request_id per utterance/segment
            request_id = f"stt-{uuid.uuid4().hex[:12]}"
            logger.info("STT starting new transcription stream: request_id=%s, sample_rate=%s", request_id, sr)

            # Determine preferred provider (from NarrativeSTT) and fallbacks.
            preferred_provider = getattr(self._stt, "_provider", None)
            fallback_providers = list(getattr(self._stt, "_fallback_providers", []) or [])
            if not fallback_providers:
                # Safe default fallback for voice mode: whisper (local, reliable)
                fallback_providers = ["whisper"]

            # Convert first frame to bytes (and keep a replay buffer so we can fallback).
            # Support both generic .data attribute and livekit rtc.AudioFrame explicitly.
            if hasattr(item, "data") and item.data is not None:
                first_bytes = bytes(item.data)
            elif isinstance(item, rtc.AudioFrame):
                first_bytes = bytes(item.data)
            else:
                if _DEBUG:
                    logger.debug("STT skipping item (no audio data): %s", type(item))
                continue

            buffer = bytearray()
            buffer.extend(first_bytes)
            ended = False

            async def _consume_until_flush_and_yield() -> AsyncIterator[bytes]:
                """Consume frames until Flush; yield raw bytes and fill buffer."""
                nonlocal ended
                # Yield the first frame (already buffered)
                yield first_bytes
                async for rest in self._input_ch:
                    if isinstance(rest, Flush):
                        ended = True
                        break
                    if hasattr(rest, "data"):
                        b = bytes(rest.data)
                        buffer.extend(b)
                        yield b
                    elif isinstance(rest, rtc.AudioFrame):
                        b = bytes(rest.data)
                        buffer.extend(b)
                        yield b

            async def _replay_then_consume_and_yield() -> AsyncIterator[bytes]:
                """Replay buffered audio first, then keep consuming until Flush (if not already ended)."""
                nonlocal ended
                # Replay what we captured so far (in manageable chunks)
                if buffer:
                    chunk_size = 8192
                    for i in range(0, len(buffer), chunk_size):
                        yield bytes(buffer[i : i + chunk_size])
                if ended:
                    return
                # Continue consuming new frames until Flush
                async for rest in self._input_ch:
                    if isinstance(rest, Flush):
                        ended = True
                        break
                    if hasattr(rest, "data"):
                        b = bytes(rest.data)
                        buffer.extend(b)
                        yield b
                    elif isinstance(rest, rtc.AudioFrame):
                        b = bytes(rest.data)
                        buffer.extend(b)
                        yield b

            # Initialize engine if needed
            try:
                if not getattr(engine, "_initialized", False):
                    await engine.initialize()
            except Exception as init_err:
                logger.warning(
                    "STT engine initialization failed (may already be initialized): %s",
                    init_err,
                    extra={"request_id": request_id},
                )

            # Finalize buffered partial after this many seconds of no new partial/final (e.g. ElevenLabs closes early)
            _finalize_delay_sec = getattr(self._stt, "_stt_finalize_delay_sec", 0.5)

            async def _emit_results(res_iter):
                last_partial = None  # (text, lang, conf) – emit as final when stream ends if no final received
                transcript_buffer = None  # same; used by timer to finalize after silence
                last_partial_time = None
                timer_cancelled = False

                async def _finalization_timer():
                    nonlocal transcript_buffer, last_partial_time, last_partial, timer_cancelled
                    while not timer_cancelled:
                        await asyncio.sleep(0.1)
                        if timer_cancelled:
                            break
                        if transcript_buffer is not None and last_partial_time is not None:
                            if time.monotonic() - last_partial_time >= _finalize_delay_sec:
                                p_text, p_lang, p_conf = transcript_buffer
                                transcript_buffer = None
                                last_partial_time = None
                                last_partial = None  # avoid double-emit at end of stream
                                logger.info(
                                    "STT finalizing buffered partial after %.1fs silence (%s): %s",
                                    _finalize_delay_sec,
                                    p_lang,
                                    (p_text or "")[:80],
                                )
                                alt = lk_stt.SpeechData(language=p_lang, text=p_text, confidence=p_conf)
                                ev = lk_stt.SpeechEvent(
                                    type=lk_stt.SpeechEventType.FINAL_TRANSCRIPT,
                                    request_id=request_id,
                                    alternatives=[alt],
                                )
                                try:
                                    self._event_ch.send_nowait(ev)
                                except Exception:
                                    await self._event_ch.send(ev)

                timer_task = asyncio.create_task(_finalization_timer())
                try:
                    async for res in res_iter:
                        is_final = getattr(res, "is_final", True)
                        text = getattr(res, "text", "") or ""
                        text_stripped = text.strip()
                        lang = getattr(res, "language", "en") or "en"
                        conf = getattr(res, "confidence", 0.0)
                        # Skip emitting empty final transcripts so we don't trigger LLM with no input
                        if is_final and not text_stripped:
                            logger.debug("STT skipping empty final transcript (request_id: %s)", request_id)
                            continue
                        if is_final:
                            last_partial = None
                            transcript_buffer = None
                            last_partial_time = None
                        elif text_stripped:
                            last_partial = (text_stripped, lang, conf)
                            transcript_buffer = (text_stripped, lang, conf)
                            last_partial_time = time.monotonic()
                        ev_type = (
                            lk_stt.SpeechEventType.FINAL_TRANSCRIPT
                            if is_final
                            else lk_stt.SpeechEventType.INTERIM_TRANSCRIPT
                        )
                        # Log final transcripts, and interim if debug enabled
                        if is_final:
                            logger.info(
                                "STT final transcript (%s): %s (confidence: %.2f)", lang, text_stripped or text, conf
                            )
                        elif _DEBUG and text_stripped:
                            logger.debug("STT interim (%s): %s", lang, text_stripped)
                        alt = lk_stt.SpeechData(language=lang, text=text_stripped or text, confidence=conf)
                        ev = lk_stt.SpeechEvent(type=ev_type, request_id=request_id, alternatives=[alt])
                        try:
                            self._event_ch.send_nowait(ev)
                        except Exception:
                            await self._event_ch.send(ev)
                finally:
                    timer_cancelled = True
                    timer_task.cancel()
                    try:
                        await timer_task
                    except asyncio.CancelledError:
                        pass
                # Stream ended without a final for the last utterance – emit last partial as final so LLM responds
                if last_partial:
                    p_text, p_lang, p_conf = last_partial
                    logger.info(
                        "STT stream ended with pending partial; emitting as final (%s): %s", p_lang, (p_text or "")[:80]
                    )
                    alt = lk_stt.SpeechData(language=p_lang, text=p_text, confidence=p_conf)
                    ev = lk_stt.SpeechEvent(
                        type=lk_stt.SpeechEventType.FINAL_TRANSCRIPT, request_id=request_id, alternatives=[alt]
                    )
                    try:
                        self._event_ch.send_nowait(ev)
                    except Exception:
                        await self._event_ch.send(ev)

            # Attempt preferred provider first, then fall back to whisper (or configured fallbacks).
            try:
                primary_iter = engine.transcribe_streaming(
                    _consume_until_flush_and_yield(),
                    sample_rate=sr or needed_sr,
                    extract_emotion=True,
                    language=getattr(self, "_language", None),
                    provider=preferred_provider,
                )
                await _emit_results(primary_iter)
            except Exception as e:
                logger.warning(
                    "Primary STT streaming failed, attempting fallback",
                    extra={
                        "error": str(e),
                        "provider": preferred_provider or "primary",
                        "request_id": request_id,
                    },
                )
                last_error = e
                # Try each fallback provider by replaying buffered audio and continuing to consume
                for fb in fallback_providers:
                    if fb and fb == preferred_provider:
                        continue
                    try:
                        fb_iter = engine.transcribe_streaming(
                            _replay_then_consume_and_yield(),
                            sample_rate=sr or needed_sr,
                            extract_emotion=True,
                            language=getattr(self, "_language", None),
                            provider=fb,
                        )
                        await _emit_results(fb_iter)
                        last_error = None
                        break
                    except Exception as fb_err:
                        last_error = fb_err
                        logger.warning(
                            "Fallback STT provider failed",
                            extra={
                                "provider": fb,
                                "error": str(fb_err),
                                "request_id": request_id,
                            },
                        )

                # If everything failed, emit user-friendly error message as transcript
                if last_error is not None:
                    logger.error(
                        "STT streaming error (all providers failed): %s",
                        last_error,
                        extra={
                            "request_id": request_id,
                            "preferred_provider": preferred_provider,
                            "fallback_providers": fallback_providers,
                        },
                        exc_info=True,
                    )

                    # Emit a user-friendly error message as transcript
                    # This way the LLM can respond with an apology
                    error_text = "I'm sorry, I couldn't hear you clearly. Could you please repeat that?"

                    alt = lk_stt.SpeechData(
                        language=getattr(self, "_language", None) or "en",
                        text=error_text,
                        confidence=0.1,  # Low confidence signals issue
                    )
                    ev = lk_stt.SpeechEvent(
                        type=lk_stt.SpeechEventType.FINAL_TRANSCRIPT,
                        request_id=request_id,
                        alternatives=[alt],
                    )
                    try:
                        self._event_ch.send_nowait(ev)
                    except Exception:
                        await self._event_ch.send(ev)
                    # Continue to next utterance without raising - don't crash the session


if _LIVEKIT_AVAILABLE:

    class NarrativeSTT(lk_stt.STT):
        """LiveKit STT delegating to framework STTEngine."""

        def __init__(
            self,
            engine=None,
            *,
            sample_rate: int = 16000,
            provider: str | None = None,
            fallback_providers: list[str] | None = None,
            finalize_delay_sec: float = 0.5,
        ):
            super().__init__(capabilities=lk_stt.STTCapabilities(streaming=True, interim_results=True))
            self._engine = engine if engine is not None else _engine_from_framework()
            self._sample_rate = sample_rate
            self._provider = provider
            self._fallback_providers = fallback_providers or []
            self._stt_finalize_delay_sec = finalize_delay_sec

        def prewarm(self) -> None:
            """Initialize the STT engine so first utterance avoids cold-start. LiveKit calls this synchronously."""

            async def _do_prewarm() -> None:
                try:
                    if not getattr(self._engine, "_initialized", False):
                        await self._engine.initialize()
                    logger.info("STT prewarm completed")
                except Exception as e:
                    logger.warning("STT prewarm failed (will init on first use): %s", e)

            try:
                loop = asyncio.get_running_loop()
                loop.create_task(_do_prewarm())
            except RuntimeError:
                import threading

                def _run() -> None:
                    asyncio.run(_do_prewarm())

                threading.Thread(target=_run, daemon=True).start()

        async def _recognize_impl(
            self,
            buffer,
            *,
            language=None,
            conn_options=None,
        ):
            """Implement non-streaming recognition (for compatibility with LiveKit STT base class)."""

            # Convert AudioBuffer (list of AudioFrame or single AudioFrame) to bytes
            if isinstance(buffer, list):
                audio_data = b"".join(bytes(frame.data) for frame in buffer)
                sample_rate = buffer[0].sample_rate if buffer else self._sample_rate
            elif isinstance(buffer, rtc.AudioFrame):
                audio_data = bytes(buffer.data)
                sample_rate = buffer.sample_rate
            else:
                # Fallback: try to get data attribute
                audio_data = bytes(buffer.data) if hasattr(buffer, "data") else b""
                sample_rate = getattr(buffer, "sample_rate", self._sample_rate)

            if not audio_data:
                # Return empty result
                return lk_stt.SpeechEvent(
                    type=lk_stt.SpeechEventType.FINAL_TRANSCRIPT,
                    request_id="",
                    alternatives=[lk_stt.SpeechData(language=language or "en", text="", confidence=0.0)],
                )

            # Initialize engine if needed
            try:
                if not getattr(self._engine, "_initialized", False):
                    await self._engine.initialize()
            except Exception:
                pass

            # Use framework's transcribe method (non-streaming)
            try:
                result = await self._engine.transcribe(
                    audio=audio_data,
                    sample_rate=sample_rate,
                    language=language,
                )
                text = getattr(result, "text", "") or ""
                lang = getattr(result, "language", language) or "en"
                conf = getattr(result, "confidence", 0.0)

                return lk_stt.SpeechEvent(
                    type=lk_stt.SpeechEventType.FINAL_TRANSCRIPT,
                    request_id="",
                    alternatives=[lk_stt.SpeechData(language=lang, text=text, confidence=conf)],
                )
            except Exception as e:
                logger.exception("STT recognition error: %s", e)
                # Return error result
                return lk_stt.SpeechEvent(
                    type=lk_stt.SpeechEventType.FINAL_TRANSCRIPT,
                    request_id="",
                    alternatives=[lk_stt.SpeechData(language=language or "en", text="", confidence=0.0)],
                )

        def stream(self, *, language=None, conn_options=None):
            # livekit.agents exposes APIConnectOptions/DEFAULT_API_CONNECT_OPTIONS (no "api" module)
            from livekit.agents import DEFAULT_API_CONNECT_OPTIONS, APIConnectOptions

            opts = conn_options or DEFAULT_API_CONNECT_OPTIONS
            if not isinstance(opts, APIConnectOptions):
                opts = DEFAULT_API_CONNECT_OPTIONS
            return _NarrativeRecognizeStream(
                stt=self,
                conn_options=opts,
                sample_rate=self._sample_rate,
                language=language,
            )
else:
    NarrativeSTT = None  # type: ignore
