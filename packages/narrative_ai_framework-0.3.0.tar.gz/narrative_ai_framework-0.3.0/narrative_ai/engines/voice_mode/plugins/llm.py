"""
LiveKit LLM plugin that wraps the framework LLMEngine.

Maps LiveKit LLMStream (chat_ctx → ChatChunk stream) to
LLMEngine.generate_streaming(messages=..., prompt=...).
"""

from __future__ import annotations

import asyncio
import logging
import os
import uuid

logger = logging.getLogger(__name__)
_DEBUG = os.getenv("VOICE_MODE_DEBUG", "").strip() == "1"

try:
    from livekit.agents import llm as lk_llm

    _LIVEKIT_AVAILABLE = True
except ImportError:
    _LIVEKIT_AVAILABLE = False
    lk_llm = None


def _engine_from_framework():
    """Get LLMEngine from narrative_ai. Prefer narrative_ai.engines.llm when available."""
    try:
        from narrative_ai.engines import llm as llm_mod

        if llm_mod is not None and hasattr(llm_mod, "LLMEngine"):
            return llm_mod.LLMEngine()
    except (ImportError, AttributeError):
        pass
    # Fallback: direct import from llm (works when narrative_ai.engines.llm is not wired)
    import importlib.util
    from pathlib import Path

    # Get the framework/engines directory
    current_file = Path(__file__)
    engines_dir = current_file.parent.parent.parent
    llm_engine_path = engines_dir / "llm" / "llm_engine.py"

    if not llm_engine_path.exists():
        raise RuntimeError(f"LLM engine file not found at {llm_engine_path}")

    # Load the module directly from file
    spec = importlib.util.spec_from_file_location(
        "narrative_ai.engines.llm.llm_engine", llm_engine_path, submodule_search_locations=[str(engines_dir / "llm")]
    )
    if spec and spec.loader:
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if hasattr(module, "LLMEngine"):
            return module.LLMEngine()

    raise RuntimeError(f"Failed to load LLMEngine from {llm_engine_path}")


def _chat_ctx_to_messages(chat_ctx) -> list[dict]:
    """Convert LiveKit ChatContext to list of {role, content} for framework LLM.
    LiveKit uses chat_ctx.items (list of ChatMessage/FunctionCall/etc.), not .messages."""
    out = []
    items = getattr(chat_ctx, "items", []) or []
    for item in items:
        kind = getattr(item, "type", "message")
        if kind != "message":
            continue
        role = getattr(item, "role", "user")
        if hasattr(role, "value"):
            role = role.value
        # Prefer text_content (LiveKit ChatMessage property); fallback to content
        content = getattr(item, "text_content", None) if hasattr(item, "text_content") else None
        if content is None:
            content = getattr(item, "content", "")
        if isinstance(content, list):
            content = " ".join((getattr(c, "text", None) or str(c) for c in content if hasattr(c, "text") or True))
        out.append({"role": role, "content": (content or "").strip()})
    return out


class _NarrativeLLMStream(lk_llm.LLMStream if _LIVEKIT_AVAILABLE else object):
    """Feeds framework LLMEngine.generate_streaming from chat_ctx, emits ChatChunks to _event_ch."""

    async def _run(self) -> None:
        if not _LIVEKIT_AVAILABLE:
            raise RuntimeError("livekit-agents is not installed")
        engine = self._llm._engine
        chat_ctx = self._chat_ctx
        messages = _chat_ctx_to_messages(chat_ctx)

        # Log when LLM stream starts
        logger.info(
            "LLM stream started: request_id=%s, messages_count=%d",
            getattr(chat_ctx, "id", "unknown"),
            len(messages) if messages else 0,
            extra={"last_message": messages[-1].get("content", "")[:100] if messages else None},
        )
        # LiveKit expects request_id to be stable within this stream
        request_id = (
            getattr(self, "request_id", None)
            or getattr(self, "_request_id", None)
            or getattr(chat_ctx, "id", None)
            or f"llm-{uuid.uuid4().hex[:12]}"
        )
        # Append detected emotion to last user message when available (for better responses)
        emotion = None
        if hasattr(chat_ctx, "metadata") and isinstance(getattr(chat_ctx, "metadata", None), dict):
            emotion = (chat_ctx.metadata or {}).get("emotion")
        if emotion and messages:
            messages = list(messages)
            messages[-1] = dict(messages[-1])
            messages[-1]["content"] = (messages[-1].get("content") or "") + f" [emotion: {emotion}]"

        # Initialize engine if needed
        try:
            await engine.initialize()
        except Exception as init_err:
            logger.warning(
                "LLM engine initialization failed (may already be initialized): %s",
                init_err,
                extra={"request_id": request_id},
            )

        # Validate inputs: ensure either messages or prompt is provided
        # If messages is empty or whitespace-only, emit error message instead of generic greeting
        if not messages or (len(messages) == 1 and not messages[0].get("content", "").strip()):
            # Truly empty or whitespace-only input - this indicates STT failure
            logger.warning(
                "Empty or whitespace-only chat context received in LLM stream",
                extra={
                    "request_id": request_id,
                    "chat_ctx_id": getattr(chat_ctx, "id", None),
                    "messages_count": len(messages) if messages else 0,
                },
            )

            # Emit a polite "didn't catch that" response instead of generic greeting
            error_chunk = lk_llm.ChatChunk(
                id=request_id,
                delta=lk_llm.ChoiceDelta(
                    role="assistant", content="I'm sorry, I didn't catch that. Could you please speak again?"
                ),
            )
            try:
                self._event_ch.send_nowait(error_chunk)
            except Exception:
                await self._event_ch.send(error_chunk)
            return

        # Continue with normal processing for valid messages
        # Extract prompt from last user message for providers that prefer prompt format
        last_message = messages[-1] if messages else None
        prompt = last_message.get("content", "") if last_message else ""
        # If last message is empty, use messages without separate prompt
        if not prompt.strip():
            prompt = None

        # Final validation: ensure we have at least one valid input
        if not messages and not prompt:
            logger.error("LLM stream has no valid input (messages or prompt)", extra={"request_id": request_id})
            # Emit an error chunk to LiveKit instead of crashing
            error_chunk = lk_llm.ChatChunk(
                id=request_id,
                delta=lk_llm.ChoiceDelta(
                    role="assistant", content="I apologize, but I didn't receive any input. Please try again."
                ),
            )
            try:
                self._event_ch.send_nowait(error_chunk)
            except Exception:
                await self._event_ch.send(error_chunk)
            return

        logger.info(
            "LLM generating response: messages=%d, prompt_length=%d",
            len(messages) if messages else 0,
            len(prompt) if prompt else 0,
            extra={
                "request_id": request_id,
                "last_message": messages[-1].get("content", "")[:100] if messages else None,
            },
        )
        try:
            async for res in engine.generate_streaming(
                messages=messages,
                prompt=prompt,
                correlation_id=request_id,
            ):
                # Convert engine/provider output to proper delta chunks.
                # Providers should ideally emit delta text for partial chunks, but we handle
                # both delta and accumulated-text styles defensively.
                if not hasattr(self, "_sent_text"):
                    self._sent_text = ""  # type: ignore[attr-defined]
                sent_text = getattr(self, "_sent_text", "")  # type: ignore[attr-defined]

                text = getattr(res, "text", "") or ""
                is_final = bool(getattr(res, "is_final", True))

                if text and isinstance(text, str) and sent_text and text.startswith(sent_text):
                    delta_text = text[len(sent_text) :]
                else:
                    delta_text = text

                if delta_text:
                    setattr(self, "_sent_text", sent_text + delta_text)  # type: ignore[attr-defined]

                if _DEBUG and is_final and text:
                    logger.info("LLM final: %s", text)
                delta = lk_llm.ChoiceDelta(role="assistant", content=delta_text if delta_text else None)
                # LiveKit ChatChunk uses 'id' not 'request_id', and 'delta' not 'choices'
                chunk = lk_llm.ChatChunk(id=request_id, delta=delta)
                if is_final and hasattr(res, "input_tokens") and hasattr(res, "output_tokens"):
                    chunk = lk_llm.ChatChunk(
                        id=request_id,
                        delta=delta,
                        usage=lk_llm.CompletionUsage(
                            prompt_tokens=getattr(res, "input_tokens", 0),
                            completion_tokens=getattr(res, "output_tokens", 0),
                            total_tokens=getattr(res, "input_tokens", 0) + getattr(res, "output_tokens", 0),
                        ),
                    )
                try:
                    self._event_ch.send_nowait(chunk)
                except Exception:
                    await self._event_ch.send(chunk)
        except Exception as e:
            logger.exception("LLM streaming error: %s", e)
            raise


if _LIVEKIT_AVAILABLE:

    class NarrativeLLM(lk_llm.LLM):
        """LiveKit LLM delegating to framework LLMEngine."""

        def __init__(self, engine=None):
            super().__init__()
            self._engine = engine if engine is not None else _engine_from_framework()

        def prewarm(self) -> None:
            """Initialize the LLM engine so first user turn avoids cold-start latency.
            LiveKit calls this synchronously (no await), so we schedule async init and return."""

            async def _do_prewarm() -> None:
                try:
                    await self._engine.initialize()
                    logger.info("LLM prewarm completed")
                except Exception as e:
                    logger.warning("LLM prewarm failed (will init on first use): %s", e)

            try:
                loop = asyncio.get_running_loop()
                loop.create_task(_do_prewarm())
            except RuntimeError:
                import threading

                def _run() -> None:
                    asyncio.run(_do_prewarm())

                threading.Thread(target=_run, daemon=True).start()

        def chat(
            self,
            *,
            chat_ctx,
            tools=None,
            conn_options=None,
            parallel_tool_calls=None,
            tool_choice=None,
            extra_kwargs=None,
            **kwargs,
        ):
            """Match LiveKit LLM.chat(chat_ctx, tools, conn_options, ...)."""
            from livekit.agents import DEFAULT_API_CONNECT_OPTIONS, APIConnectOptions

            opts = conn_options or DEFAULT_API_CONNECT_OPTIONS
            if not isinstance(opts, APIConnectOptions):
                opts = DEFAULT_API_CONNECT_OPTIONS
            return _NarrativeLLMStream(
                llm=self,
                chat_ctx=chat_ctx,
                tools=tools if tools is not None else [],
                conn_options=opts,
            )
else:
    NarrativeLLM = None  # type: ignore
