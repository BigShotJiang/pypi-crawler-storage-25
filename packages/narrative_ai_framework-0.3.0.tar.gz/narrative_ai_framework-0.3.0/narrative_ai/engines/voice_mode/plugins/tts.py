"""
LiveKit TTS plugin that wraps the framework TTSEngine.

Maps LiveKit SynthesizeStream (push_text → SynthesizedAudio) to
TTSEngine.synthesize_streaming(text, output_format="pcm_24000").
"""

from __future__ import annotations

import asyncio
import logging
import uuid

try:
    import livekit.agents.utils as utils
except ImportError:
    utils = None

logger = logging.getLogger(__name__)

try:
    from livekit import rtc
    from livekit.agents import tts as lk_tts

    _LIVEKIT_AVAILABLE = True
except ImportError:
    _LIVEKIT_AVAILABLE = False
    lk_tts = None
    rtc = None

# Match LiveKit pipeline default
SAMPLE_RATE = 24000
NUM_CHANNELS = 1


def _engine_from_framework():
    """Get TTSEngine from narrative_ai. Prefer narrative_ai.engines.tts when available."""
    try:
        from narrative_ai.engines import tts as tts_mod

        if tts_mod is not None and hasattr(tts_mod, "TTSEngine"):
            return tts_mod.TTSEngine()
    except (ImportError, AttributeError):
        pass
    # Fallback: direct import from tts (works when narrative_ai.engines.tts is not wired)
    import importlib.util
    from pathlib import Path

    # Get the framework/engines directory
    current_file = Path(__file__)
    engines_dir = current_file.parent.parent.parent
    tts_engine_path = engines_dir / "tts" / "tts_engine.py"

    if not tts_engine_path.exists():
        raise RuntimeError(f"TTS engine file not found at {tts_engine_path}")

    # Load the module directly from file
    spec = importlib.util.spec_from_file_location(
        "narrative_ai.engines.tts.tts_engine", tts_engine_path, submodule_search_locations=[str(engines_dir / "tts")]
    )
    if spec and spec.loader:
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if hasattr(module, "TTSEngine"):
            return module.TTSEngine()

    raise RuntimeError(f"Failed to load TTSEngine from {tts_engine_path}")


class _NarrativeSynthesizeStream(lk_tts.SynthesizeStream if _LIVEKIT_AVAILABLE else object):
    """Feeds framework TTSEngine.synthesize_streaming from _input_ch, emits SynthesizedAudio to _event_ch."""

    async def _run(self, output_emitter) -> None:
        """
        Run TTS synthesis stream.

        Args:
            output_emitter: LiveKit AudioEmitter for outputting synthesized audio frames
        """
        if not _LIVEKIT_AVAILABLE:
            raise RuntimeError("livekit-agents is not installed")
        engine = self._tts._engine
        # Generate request_id if not provided
        if utils and hasattr(utils, "shortuuid"):
            request_id = utils.shortuuid()
        else:
            request_id = f"tts-{uuid.uuid4().hex[:12]}"
        Flush = getattr(lk_tts.SynthesizeStream, "_FlushSentinel", type("_Flush", (), {}))

        # Initialize output_emitter (required by LiveKit)
        try:
            init_result = output_emitter.initialize(
                request_id=request_id,
                sample_rate=SAMPLE_RATE,
                num_channels=NUM_CHANNELS,
                mime_type="audio/pcm",
                stream=True,  # Streaming mode
            )

            # Await if it's a coroutine
            import asyncio

            if asyncio.iscoroutine(init_result):
                await init_result

            # Verify initialization succeeded
            if not getattr(output_emitter, "_initialized", True):
                raise RuntimeError("AudioEmitter initialization failed")

            logger.info(
                "TTS output emitter initialized: sample_rate=%d, channels=%d",
                SAMPLE_RATE,
                NUM_CHANNELS,
                extra={"request_id": request_id},
            )
        except Exception as init_error:
            logger.error(
                "Failed to initialize TTS output emitter: %s",
                init_error,
                extra={"request_id": request_id},
                exc_info=True,
            )
            raise

        # Initialize engine if needed
        try:
            await engine.initialize()
        except Exception as init_err:
            logger.warning("TTS engine initialization failed (may already be initialized): %s", init_err)

        text_buf = []
        segment_index = 0
        try:
            async for item in self._input_ch:
                if isinstance(item, Flush):
                    if not text_buf:
                        continue
                    text = "".join(text_buf)
                    text_buf = []
                    if not text.strip():
                        continue
                    # Start a new segment per utterance so LiveKit pipeline can play out correctly
                    segment_id = f"{request_id}-{segment_index}"
                    segment_index += 1
                    try:
                        output_emitter.start_segment(segment_id=segment_id)
                        logger.debug("TTS segment started: %s", segment_id)
                    except Exception as segment_error:
                        logger.error("Failed to start TTS segment: %s", segment_error, exc_info=True)
                        raise
                    meta = getattr(self._tts, "metadata", None) or {}
                    emotion = meta.get("emotion") if isinstance(meta, dict) else None
                    language = meta.get("language", "en") if isinstance(meta, dict) else "en"
                    logger.info(
                        "TTS synthesizing: text_length=%d, emotion=%s, language=%s",
                        len(text),
                        emotion,
                        language,
                        extra={"request_id": request_id, "text_preview": text[:100]},
                    )
                    try:
                        async for chunk in engine.synthesize_streaming(
                            text=text,
                            output_format="pcm_24000",
                            correlation_id=request_id,
                            emotion=emotion,
                            language=language,
                        ):
                            # Validate chunk before pushing
                            if not chunk or len(chunk) == 0:
                                logger.warning("TTS engine returned empty chunk, skipping")
                                continue

                            # Validate chunk size (should be multiple of 2 for 16-bit PCM)
                            if len(chunk) % 2 != 0:
                                logger.debug(
                                    "TTS chunk size not multiple of 2 (got %d bytes), padding",
                                    len(chunk),
                                    extra={"request_id": request_id},
                                )
                                chunk = chunk + b"\x00"  # Pad with zero byte

                            # Validate reasonable chunk size (not too large)
                            max_chunk_size = SAMPLE_RATE * NUM_CHANNELS * 2 * 5  # 5 seconds max
                            if len(chunk) > max_chunk_size:
                                logger.error(
                                    "TTS chunk size excessive (%d bytes), truncating",
                                    len(chunk),
                                    extra={"request_id": request_id},
                                )
                                chunk = chunk[:max_chunk_size]

                            # Push audio data to output_emitter (16-bit PCM bytes)
                            try:
                                output_emitter.push(chunk)
                            except Exception as push_error:
                                logger.error(
                                    "Failed to push audio chunk: %s",
                                    push_error,
                                    extra={"request_id": request_id, "chunk_size": len(chunk)},
                                    exc_info=True,
                                )
                                # Continue with next chunk instead of crashing
                                continue
                        # Flush and end segment so pipeline can play out and accept next segment
                        output_emitter.flush()
                        try:
                            output_emitter.end_segment()
                            logger.debug("TTS segment ended: %s", segment_id)
                        except Exception as end_err:
                            logger.warning("TTS end_segment: %s", end_err)
                    except Exception as e:
                        logger.exception("TTS streaming error: %s", e)
                        raise
                    continue
                if isinstance(item, str):
                    text_buf.append(item)
                # else skip
        except Exception as e:
            logger.exception("TTS stream error in input channel: %s", e)
            # Emit error audio frame to signal failure
            error_frame = rtc.AudioFrame(
                data=b"", sample_rate=SAMPLE_RATE, num_channels=NUM_CHANNELS, samples_per_channel=0
            )
            error_ev = lk_tts.SynthesizedAudio(
                frame=error_frame,
                request_id=request_id,
                is_final=True,
                segment_id="",
                delta_text="",
            )
            try:
                self._event_ch.send_nowait(error_ev)
            except Exception:
                await self._event_ch.send(error_ev)
            raise


if _LIVEKIT_AVAILABLE:

    class NarrativeTTS(lk_tts.TTS):
        """LiveKit TTS delegating to framework TTSEngine."""

        def __init__(self, engine=None, *, sample_rate: int = SAMPLE_RATE, num_channels: int = NUM_CHANNELS):
            super().__init__(
                capabilities=lk_tts.TTSCapabilities(streaming=True),
                sample_rate=sample_rate,
                num_channels=num_channels,
            )
            self._engine = engine if engine is not None else _engine_from_framework()

        def prewarm(self) -> None:
            """Initialize the TTS engine so first agent reply avoids cold-start latency.
            LiveKit calls this synchronously (no await), so we schedule async init and return."""

            async def _do_prewarm() -> None:
                try:
                    await self._engine.initialize()
                    logger.info("TTS prewarm completed")
                except Exception as e:
                    logger.warning("TTS prewarm failed (will init on first use): %s", e)

            try:
                loop = asyncio.get_running_loop()
                loop.create_task(_do_prewarm())
            except RuntimeError:
                import threading

                def _run() -> None:
                    asyncio.run(_do_prewarm())

                threading.Thread(target=_run, daemon=True).start()

        def synthesize(self, text: str, *, conn_options=None):
            """Implement synthesize() using stream() helper."""
            return self._synthesize_with_stream(text, conn_options=conn_options)

        def stream(self, *, conn_options=None):
            from livekit.agents import DEFAULT_API_CONNECT_OPTIONS, APIConnectOptions

            opts = conn_options or DEFAULT_API_CONNECT_OPTIONS
            if not isinstance(opts, APIConnectOptions):
                opts = DEFAULT_API_CONNECT_OPTIONS
            return _NarrativeSynthesizeStream(tts=self, conn_options=opts)
else:
    NarrativeTTS = None  # type: ignore
