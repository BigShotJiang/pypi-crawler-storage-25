"""LiveKit plugins wrapping framework STT/LLM/TTS engines.

.. deprecated::
    DEPRECATED: Use agent.NarrativeAgent with stt_adapter, llm_adapter, tts_adapter instead.
    The main worker (worker.run_voice_agent) uses adapters, not these plugins.
    These plugins remain for backward compatibility and documentation only.
    Canonical path: NarrativeAgent + CustomSTT/CustomLLM/CustomTTS from agent.py.
"""

try:
    from .stt import NarrativeSTT
except (ImportError, TypeError):
    NarrativeSTT = None
try:
    from .llm import NarrativeLLM
except (ImportError, TypeError):
    NarrativeLLM = None
try:
    from .tts import NarrativeTTS
except (ImportError, TypeError):
    NarrativeTTS = None

__all__ = ["NarrativeSTT", "NarrativeLLM", "NarrativeTTS"]
