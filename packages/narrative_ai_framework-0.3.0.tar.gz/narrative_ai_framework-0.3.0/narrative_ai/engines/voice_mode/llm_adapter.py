"""
LLM Adapter - Wraps your custom LLM engine for LiveKit

This adapter implements LiveKit's LLM interface while using your custom
LLM engine (with fixed Gemini support) under the hood.
"""

import logging
import os
import time
from typing import Any, Dict, List, Optional

from narrative_ai.application.services.companion_chat_pipeline import CompanionChatPipeline, CompanionChatRequest
from narrative_ai.engines.llm import ConversationManager
from narrative_ai.engines.llm.conversation_storage import InMemoryConversationStorage
from livekit.agents import llm as lk_llm
from livekit.agents.types import (
    DEFAULT_API_CONNECT_OPTIONS,
    NOT_GIVEN,
    APIConnectOptions,
    NotGivenOr,
)
from livekit.agents.utils import shortuuid

from .constants import FALLBACK_404, FALLBACK_DUPLICATE, FALLBACK_GENERIC, FALLBACK_QUOTA

logger = logging.getLogger(__name__)


class CustomLLM(lk_llm.LLM):
    """
    LiveKit LLM adapter for your custom LLM engine.

    Wraps your framework's LLM engine (Gemini/OpenAI/etc.) to work with
    LiveKit's AgentSession.
    """

    def __init__(
        self,
        llm_engine,
        *,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        turn_metadata: Optional[dict] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        session_id: Optional[str] = None,
    ):
        """
        Initialize LLM adapter.

        Args:
            llm_engine: Your framework's LLM engine instance
            temperature: Generation temperature
            max_tokens: Maximum tokens per response
            turn_metadata: Shared dict to write emotion/language for TTS (mutated on final chunk)
            user_id: Authenticated user UUID (if available) for profile/RAG context
            tenant_id: Optional tenant UUID
            session_id: Stable session id for conversation persistence
        """
        super().__init__()
        self._engine = llm_engine
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._turn_metadata = turn_metadata if turn_metadata is not None else {}
        self._user_id = user_id
        self._tenant_id = tenant_id
        self._session_id = session_id
        # If we don't have an authenticated user id, avoid app-database
        # persistence (conversations.user_id is NOT NULL + FK to users.id).
        # Use in-memory conversation state for this anonymous/unknown session.
        if self._user_id:
            self._conv_manager = ConversationManager()
        else:
            self._conv_manager = ConversationManager(storage=InMemoryConversationStorage())
            logger.warning("Voice LLM started without user_id; using in-memory conversation storage for this session.")
        self._chat_pipeline = CompanionChatPipeline(llm_engine, self._conv_manager)
        # Deduplicate overlapping real-time STT segments (same utterance committed multiple times).
        self._last_user_content: str = ""
        self._last_user_content_time: float = 0.0
        try:
            self._duplicate_window_seconds = max(0.0, float(os.getenv("VOICE_LLM_DUPLICATE_WINDOW_SECONDS", "20")))
        except (ValueError, TypeError):
            self._duplicate_window_seconds = 20.0

        # Configurable thresholds for duplicate detection
        def _int_env(name: str, default: int) -> int:
            try:
                return max(0, int(os.getenv(name, str(default))))
            except (ValueError, TypeError):
                return default

        def _float_env(name: str, default: float) -> float:
            try:
                return max(0.0, min(1.0, float(os.getenv(name, str(default)))))
            except (ValueError, TypeError):
                return default

        self._dup_min_chars = _int_env("VOICE_LLM_DUP_MIN_CHARS", 5)
        self._dup_min_new_words = _int_env("VOICE_LLM_DUP_MIN_NEW_WORDS", 2)
        self._dup_min_new_chars = _int_env("VOICE_LLM_DUP_MIN_NEW_CHARS", 8)
        self._dup_overlap_ratio = _float_env("VOICE_LLM_DUP_OVERLAP_RATIO", 0.65)

        logger.info(f"Custom LLM adapter initialized: temperature={temperature}, max_tokens={max_tokens}")

    def chat(
        self,
        *,
        chat_ctx: lk_llm.ChatContext,
        tools: Optional[List[lk_llm.Tool]] = None,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
        parallel_tool_calls: NotGivenOr[bool] = NOT_GIVEN,
        tool_choice: NotGivenOr[lk_llm.ToolChoice] = NOT_GIVEN,
        extra_kwargs: NotGivenOr[Dict[str, Any]] = NOT_GIVEN,
    ) -> "CustomLLMStream":
        """
        Create a new LLM chat stream.

        Args:
            chat_ctx: Chat context with conversation history
            tools: Optional tools for function calling
            conn_options: Connection options
            parallel_tool_calls: Unused (no tool calling in custom engine)
            tool_choice: Unused (no tool calling in custom engine)
            extra_kwargs: Unused

        Returns:
            CustomLLMStream instance
        """
        return CustomLLMStream(
            llm=self,
            chat_ctx=chat_ctx,
            tools=tools or [],
            conn_options=conn_options,
        )


class CustomLLMStream(lk_llm.LLMStream):
    """
    LLM stream implementation that generates responses via your custom engine.
    """

    def __init__(
        self,
        llm: CustomLLM,
        chat_ctx: lk_llm.ChatContext,
        tools: List[lk_llm.Tool],
        conn_options: APIConnectOptions,
    ):
        super().__init__(
            llm=llm,
            chat_ctx=chat_ctx,
            tools=tools,
            conn_options=conn_options,
        )

    def _convert_messages(self) -> tuple[List[Dict[str, str]], Optional[str]]:
        """
        Convert LiveKit ChatContext to your engine's message format.

        ChatContext uses .items (list of ChatItem), not .messages.
        Only message-type items are included; text is taken from .text_content.
        Returns (messages, system_prompt) — system_prompt from first system message if present.
        """
        messages = []
        system_prompt = None
        for item in self._chat_ctx.items:
            if getattr(item, "type", None) != "message":
                continue
            role = getattr(item, "role", "user")
            if hasattr(role, "value"):
                role = role.value
            role = str(role)
            text = getattr(item, "text_content", None)
            if text is None and hasattr(item, "content"):
                parts = item.content or []
                text = " ".join(c if isinstance(c, str) else getattr(c, "text", str(c)) for c in parts)
            text = (text or "").strip() or ""
            if role == "system" and text:
                system_prompt = text
                continue
            messages.append({"role": role, "content": text})
        logger.debug(f"Converted {len(messages)} messages for LLM")
        return messages, system_prompt

    def _is_duplicate_user_turn(self, new_content: str) -> bool:
        """True if new_content is effectively the same as the last user turn we responded to (overlapping STT segments)."""
        last = (self._llm._last_user_content or "").strip()
        new = (new_content or "").strip()
        min_chars = self._llm._dup_min_chars
        if not last or not new or len(new) < min_chars:
            return False
        last_n = last.lower()
        new_n = new.lower()
        overlap_ratio = self._llm._dup_overlap_ratio

        # Case 1: new contains last (cumulative STT). Only treat as duplicate if no substantial new content.
        if last_n in new_n:
            pos = new_n.find(last_n) + len(last_n)
            added = new_n[pos:].strip()
            added_words = len(added.split()) if added else 0
            # Be more lenient for cumulative STT: a small amount of new content
            # (1+ words or a few characters) should be treated as a NEW turn,
            # so the agent can react to refinements like "in Cairo".
            base_min_new_words = self._llm._dup_min_new_words
            base_min_new_chars = self._llm._dup_min_new_chars
            min_new_words = max(1, base_min_new_words // 3 or 1)
            min_new_chars = max(5, base_min_new_chars // 4 or 5)
            if added_words >= min_new_words or len(added) >= min_new_chars:
                return False
            return True

        # Case 2: last contains new (STT refinement/shortening) - treat as duplicate
        if new_n in last_n:
            return True

        # Case 3: Word overlap - same phrase with small variations
        last_words = set(last_n.split())
        new_words = set(new_n.split())
        if len(last_words) >= 5:
            overlap = len(last_words & new_words) / len(last_words)
            if overlap >= overlap_ratio and len(new_words) <= len(last_words) * 2:
                return True
        return False

    def _send_fallback(self, request_id: str, fallback: str) -> None:
        lk_chunk = lk_llm.ChatChunk(
            id=request_id,
            delta=lk_llm.ChoiceDelta(content=fallback, role="assistant"),
            usage=None,
        )
        self._event_ch.send_nowait(lk_chunk)

    async def _run(self) -> None:
        """Run LLM generation and send chunks to _event_ch."""
        temperature = self._llm._temperature
        max_tokens = self._llm._max_tokens
        request_id = shortuuid()
        full_text = ""

        messages, system_prompt = self._convert_messages()
        last_user_content = (messages[-1]["content"] if messages and messages[-1]["role"] == "user" else "").strip()

        # Deduplicate: real-time STT often commits overlapping segments; skip if same as last turn we answered.
        if self._is_duplicate_user_turn(last_user_content):
            if (time.monotonic() - self._llm._last_user_content_time) <= self._llm._duplicate_window_seconds:
                logger.info(
                    "Skipping duplicate user turn (overlapping STT segment), saying short reply "
                    "(request_id=%s, last_user=%r)",
                    request_id,
                    last_user_content[:120],
                )
                self._send_fallback(request_id, FALLBACK_DUPLICATE)
                return

        self._llm._last_user_content = last_user_content
        self._llm._last_user_content_time = time.monotonic()

        # Clear turn metadata for this turn; LLM will populate emotion on final chunk
        meta = self._llm._turn_metadata
        meta.clear()

        try:
            logger.info(
                "LLM generating response (request_id=%s, messages=%d, last_msg=%r)",
                request_id,
                len(messages),
                (messages[-1]["content"][:100] if messages else "none"),
            )
            if not last_user_content:
                logger.warning("Voice LLM received empty user turn (request_id=%s)", request_id)
                self._send_fallback(request_id, FALLBACK_GENERIC)
                return

            chat_request = CompanionChatRequest(
                message=last_user_content,
                session_id=self._llm._session_id,
                system_prompt=system_prompt,
                temperature=temperature,
                max_tokens=max_tokens,
                user_id=self._llm._user_id,
                tenant_id=self._llm._tenant_id,
                correlation_id=request_id,
            )

            # ── Stream chunks progressively for faster TTS ──
            chunk_count = 0
            async for chat_chunk in self._llm._chat_pipeline.run_streaming(chat_request):
                # Update session ID from the first chunk
                if chunk_count == 0:
                    self._llm._session_id = chat_chunk.session_id
                chunk_count += 1

                chunk_text = chat_chunk.text or ""
                if chunk_text:
                    full_text += chunk_text
                    lk_chunk = lk_llm.ChatChunk(
                        id=request_id,
                        delta=lk_llm.ChoiceDelta(
                            content=chunk_text,
                            role="assistant",
                        ),
                        usage=None,
                    )
                    self._event_ch.send_nowait(lk_chunk)

                # Capture emotion from the final chunk
                if chat_chunk.emotion:
                    meta["emotion"] = chat_chunk.emotion

            logger.info(
                "LLM streaming complete (request_id=%s, chars=%d, chunks=%d)",
                request_id,
                len(full_text),
                chunk_count,
            )

            # Gemini 429 (and similar) yield an error result instead of raising; we get 0 chars. Speak a fallback.
            if not full_text.strip():
                fallback = FALLBACK_QUOTA
                logger.warning("LLM returned no text (e.g. 429 quota); speaking fallback: %s", fallback)
                self._send_fallback(request_id, fallback)
        except Exception as e:
            err_msg = str(e).lower()
            is_quota = (
                "429" in err_msg or "quota" in err_msg or "resource_exhausted" in err_msg or "rate limit" in err_msg
            )
            is_not_found = "404" in err_msg or "not_found" in err_msg or "not found" in err_msg
            if not full_text:
                if is_quota:
                    fallback = FALLBACK_QUOTA
                    logger.warning("LLM quota/429: returning fallback phrase to user: %s", fallback)
                elif is_not_found:
                    fallback = FALLBACK_404
                    logger.warning("LLM 404/model not found: returning fallback phrase to user: %s", fallback)
                else:
                    fallback = FALLBACK_GENERIC
                    logger.warning(
                        "LLM error (no content yet): %s (%s). returning fallback phrase: %s",
                        e,
                        type(e).__name__,
                        fallback,
                        exc_info=True,
                    )
                self._send_fallback(request_id, fallback)
                return
            logger.error(f"LLM generation error: {e}", exc_info=True)
            raise
