"""
Voice Agent Main Entry Point

Run this file to start the voice agent worker:
    python -m narrative_ai.engines.voice_mode.main dev

Or from project root:
    python framework/engines/voice_mode/main.py dev
"""

from __future__ import annotations

import os
import sys

# Ensure project root is on path and load .env (LiveKit CLI does not load it)
if "__file__" in dir():
    _root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    if _root not in sys.path:
        sys.path.insert(0, _root)
    _env_path = os.path.join(_root, ".env")
    if os.path.isfile(_env_path):
        try:
            from dotenv import load_dotenv

            load_dotenv(_env_path, override=False)
        except ImportError:
            pass

from .worker import run_voice_agent

if __name__ == "__main__":
    # LiveKit CLI requires a subcommand (start, dev, console, download-files). Default to "start" when none given.
    _subcommands = ("start", "dev", "console", "download-files", "download_files", "--help", "-h")
    if len(sys.argv) == 1 or sys.argv[1] not in _subcommands:
        sys.argv.insert(1, "start")
    run_voice_agent()
