"""
Voice Mode API - SDK entry point for the Narrative AI Voice Agent.
"""

from typing import Optional

def set_livekit_config(url: str, api_key: str, api_secret: str):
    """
    Dynamically set LiveKit connection parameters.
    
    Args:
        url: LiveKit server URL (e.g., 'wss://your-project.livekit.cloud')
        api_key: LiveKit API Key
        api_secret: LiveKit API Secret
    """
    import os
    os.environ["LIVEKIT_URL"] = url
    os.environ["LIVEKIT_API_KEY"] = api_key
    os.environ["LIVEKIT_API_SECRET"] = api_secret

def set_agent_name(name: str):
    """Set the name this agent registers with in LiveKit."""
    import os
    os.environ["LIVEKIT_AGENT_NAME"] = name

def start_agent():
    """
    Start the voice agent worker.
    This registers the agent with LiveKit and waits for incoming jobs.
    """
    from .worker import run_voice_agent
    run_voice_agent()

class VoiceClient:
    """
    A client for interacting with or managing the Voice Mode engine.
    For now, primarily focused on starting the agent worker.
    """
    
    def start(self):
        """Start the voice agent worker."""
        start_agent()
