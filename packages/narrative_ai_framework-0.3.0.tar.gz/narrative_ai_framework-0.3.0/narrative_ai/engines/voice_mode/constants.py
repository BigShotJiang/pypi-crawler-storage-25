"""
Voice mode constants — shared across adapters to avoid drift.

Fallback phrases spoken when LLM/TTS encounter errors. These must never be
deduplicated by TTS (user should always hear them when intended).
"""

# Individual fallback messages (used by LLM adapter)
FALLBACK_QUOTA = "I've hit my request limit for now. Please try again in a moment."
FALLBACK_404 = "The language model isn't available. Check that config uses gemini-2.5-flash in config/providers.yml."
FALLBACK_GENERIC = "Something went wrong with the assistant. Please try again."
FALLBACK_DUPLICATE = "I already answered that."

# Set of all fallback phrases (used by TTS adapter for dedupe exclusion)
VOICE_FALLBACK_PHRASES = frozenset(
    {
        FALLBACK_DUPLICATE.lower(),
        FALLBACK_QUOTA.lower(),
        FALLBACK_404.lower(),
        FALLBACK_GENERIC.lower(),
    }
)
