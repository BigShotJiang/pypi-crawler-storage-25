"""
LiveKit VAD adapter wrapping the framework WebRTC VAD (narrative_ai.engines.stt.vad_processor).

Use this instead of Silero so voice_mode uses your WebRTC VAD as in the plan
("LiveKit's WebRTC + Semantic" → WebRTC VAD from this repo).

For semantic VAD (e.g. pyannote), use LiveKit's SemanticVAD as a wrapper in session
init: SemanticVAD(base_vad=WebRTCVAD(...)) when config.semantic_vad is True.
"""

from __future__ import annotations

import logging
import os
import sys
import time
import numpy as np
from livekit import rtc
from livekit.agents import vad as lk_vad

logger = logging.getLogger(__name__)
_DEBUG = os.getenv("VOICE_MODE_DEBUG", "").strip() == "1"
# WebRTC VAD supports 8k/16k/32k/48k only. We always resample other rates (e.g. 24kHz from TTS/room).

# Helps verify which file the worker is executing (useful when job processes
# are spawned and old bytecode is suspected).
logger.info("Loaded voice_mode.webrtc_vad from %s", __file__)

# Ensure project root on path so "narrative_ai.engines.stt" resolves (voice_mode -> engines -> framework -> project root)
_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
if _root not in sys.path:
    sys.path.insert(0, _root)

# Import framework WebRTC VAD (narrative_ai.engines.stt re-exports VADProcessor, SpeechState)
try:
    from narrative_ai.engines.stt import VADProcessor, SpeechState
except ImportError:
    from narrative_ai.engines.stt.vad_processor import VADProcessor, SpeechState  # type: ignore

TARGET_SR = 16000


def _is_low_energy(frame_bytes: bytes, threshold: float = 0.015) -> bool:
    """
    Check if audio frame has low energy (likely silence/noise).
    Uses NumPy for consistency with stt_adapter and better performance.

    Args:
        frame_bytes: 16-bit PCM audio frame
        threshold: RMS threshold (0.0-1.0, normalized)

    Returns:
        True if energy below threshold
    """
    try:
        if len(frame_bytes) < 2:
            return True
        samples = np.frombuffer(frame_bytes, dtype=np.int16)
        if samples.size == 0:
            return True
        rms = np.sqrt(np.mean(samples.astype(np.float64) ** 2)) / 32768.0
        return rms < threshold
    except Exception as e:
        logger.debug("Energy calculation error: %s", e)
        return False


def _frame_bytes(frame: rtc.AudioFrame) -> bytes:
    """Extract 16-bit PCM bytes from a LiveKit AudioFrame (mono or first channel)."""
    d = frame.data
    if hasattr(d, "tobytes"):
        return d.tobytes()
    return bytes(d)


def _resample_numpy(arr: np.ndarray, n_in: int, n_out: int) -> np.ndarray:
    """
    Pure-numpy linear interpolation resampler. Used when scipy/librosa unavailable.
    WebRTC VAD only accepts 8k/16k/32k/48k - we must resample 24kHz etc. correctly.
    """
    if n_out < 1:
        return np.array([], dtype=np.int16)
    x_old = np.linspace(0, n_in - 1, n_in, dtype=np.float64)
    x_new = np.linspace(0, n_in - 1, n_out, dtype=np.float64, endpoint=False)
    interp = np.interp(x_new, x_old, arr.astype(np.float64))
    return np.clip(interp, -32768, 32767).astype(np.int16)


def _resample_to_16k_mono(raw: bytes, sample_rate: int, num_channels: int, target_sr: int = TARGET_SR) -> bytes:
    """
    Resample PCM int16 audio to target_sr Hz mono.
    WebRTC VAD requires 8k/16k/32k/48k only - 24kHz etc. must be resampled.
    Uses scipy (best) -> numpy (fallback). Never passes unsupported sample rates.
    """
    if sample_rate == target_sr and num_channels == 1:
        return raw
    arr = np.frombuffer(raw, dtype=np.int16)
    if num_channels > 1:
        arr = arr.reshape(-1, num_channels)[:, 0]
    if sample_rate == target_sr:
        return arr.tobytes()

    n_in = arr.size
    n_out = int(round(n_in * target_sr / sample_rate))
    if n_out < 1:
        return b""

    # 1. Prefer scipy (high quality, in requirements.txt)
    try:
        from scipy.signal import resample

        float_in = arr.astype(np.float64) / 32768.0
        float_out = resample(float_in, n_out)
        out = np.clip(float_out * 32768.0, -32768, 32767).astype(np.int16)
        return out.tobytes()
    except ImportError:
        pass

    # 2. Fast path: integer-ratio decimation (e.g. 48k->16k, 32k->16k) - no scipy needed
    ratio = sample_rate / target_sr
    if ratio >= 1 and abs(ratio - round(ratio)) < 0.01:
        step = int(round(ratio))
        out = arr[::step]
        return out.tobytes()

    # 3. Fallback: numpy linear interpolation (handles 24k->16k, 22050, etc.)
    out = _resample_numpy(arr, n_in, n_out)
    return out.tobytes()


class WebRTCVAD(lk_vad.VAD):
    """LiveKit VAD implementation using the framework WebRTC VAD (webrtcvad)."""

    def __init__(
        self,
        *,
        sample_rate: int = 16000,
        aggressiveness: int = 2,
        update_interval: float = 0.02,
    ) -> None:
        super().__init__(capabilities=lk_vad.VADCapabilities(update_interval=update_interval))
        self._processor = VADProcessor(
            sample_rate=sample_rate,
            frame_duration_ms=20,
            mode=aggressiveness,
        )
        self._sample_rate = sample_rate

    @property
    def model(self) -> str:
        return "webrtc-vad"

    @property
    def provider(self) -> str:
        return "framework"

    def stream(self) -> "WebRTCVADStream":
        return WebRTCVADStream(self)


class WebRTCVADStream(lk_vad.VADStream):
    """LiveKit VADStream that feeds AudioFrames into the framework WebRTC VAD."""

    def __init__(self, vad: WebRTCVAD) -> None:
        super().__init__(vad)
        self._webrtc_vad = vad
        self._processor = vad._processor
        self._frame_bytes = vad._processor.frame_bytes
        self._buffer = bytearray()
        # Frames belonging to the current speech segment only. We intentionally
        # avoid accumulating *all* frames (including long silence) to prevent
        # unbounded memory growth during long calls with no speech.
        self._segment_frames: list[rtc.AudioFrame] = []
        self._samples_index = 0
        self._speech_duration = 0.0
        self._silence_duration = 0.0
        self._rate_warned = False  # log sample-rate mismatch only once per stream

    def _emit_end_of_speech(self) -> None:
        """Emit END_OF_SPEECH with current segment frames and clear state."""
        if self._segment_frames:
            self._event_ch.send_nowait(
                lk_vad.VADEvent(
                    type=lk_vad.VADEventType.END_OF_SPEECH,
                    samples_index=self._samples_index,
                    timestamp=time.time(),
                    speech_duration=self._speech_duration,
                    silence_duration=self._silence_duration,
                    frames=list(self._segment_frames),
                    speaking=False,
                )
            )
        self._segment_frames.clear()

    async def _main_task(self) -> None:
        frame_duration_s = self._processor.frame_duration_ms / 1000.0
        frames_received = 0
        try:
            async for item in self._input_ch:
                if item is self._FlushSentinel:
                    # Flush: end current segment if in speech
                    if _DEBUG:
                        logger.debug("VAD received Flush sentinel")
                    self._emit_end_of_speech()
                    self._processor.reset()
                    self._buffer.clear()
                    continue
                frame = item
                frames_received += 1
                if frames_received == 1:
                    logger.info(
                        "VAD received first audio frame: sample_rate=%s, channels=%s, samples=%s",
                        frame.sample_rate,
                        frame.num_channels,
                        len(frame.data),
                    )
                raw = _frame_bytes(frame)
                if frame.sample_rate != self._processor.sample_rate or frame.num_channels != 1:
                    if not self._rate_warned:
                        logger.info(
                            "WebRTC VAD: resampling %s Hz, %s ch -> %s Hz mono (supported: 8k/16k/32k/48k)",
                            frame.sample_rate,
                            frame.num_channels,
                            self._processor.sample_rate,
                        )
                        self._rate_warned = True
                    raw = _resample_to_16k_mono(raw, frame.sample_rate, frame.num_channels, self._processor.sample_rate)
                self._buffer.extend(raw)
                while len(self._buffer) >= self._frame_bytes:
                    chunk = bytes(self._buffer[: self._frame_bytes])
                    del self._buffer[: self._frame_bytes]

                    # Pre-filter low energy frames to reduce false positives
                    if _is_low_energy(chunk, threshold=0.015):
                        # Skip VAD processing for very quiet frames
                        self._samples_index += self._processor.frame_samples
                        self._silence_duration += frame_duration_s
                        # Still emit INFERENCE_DONE with speaking=False
                        self._event_ch.send_nowait(
                            lk_vad.VADEvent(
                                type=lk_vad.VADEventType.INFERENCE_DONE,
                                samples_index=self._samples_index,
                                timestamp=time.time(),
                                speech_duration=self._speech_duration,
                                silence_duration=self._silence_duration,
                                frames=[],
                                probability=0.0,
                                inference_duration=0.0,
                                speaking=False,
                            )
                        )
                        continue

                    t0 = time.perf_counter()
                    state, segment = self._processor.process_frame(chunk)
                    inference_duration = time.perf_counter() - t0
                    self._samples_index += self._processor.frame_samples
                    is_speech = state in (
                        SpeechState.IN_SPEECH,
                        SpeechState.SPEECH_START,
                        SpeechState.SPEECH_END,
                    )
                    self._event_ch.send_nowait(
                        lk_vad.VADEvent(
                            type=lk_vad.VADEventType.INFERENCE_DONE,
                            samples_index=self._samples_index,
                            timestamp=time.time(),
                            speech_duration=self._speech_duration,
                            silence_duration=self._silence_duration,
                            frames=[],
                            probability=1.0 if is_speech else 0.0,
                            inference_duration=inference_duration,
                            speaking=is_speech,
                        )
                    )
                    if state == SpeechState.SPEECH_START:
                        # New speech segment: start tracking frames for this segment only.
                        self._segment_frames.clear()
                        self._segment_frames.append(frame)
                        self._speech_duration = 0.0
                        self._silence_duration = 0.0
                        logger.info(
                            "VAD START_OF_SPEECH detected (idx=%s)",
                            self._samples_index,
                        )
                        self._event_ch.send_nowait(
                            lk_vad.VADEvent(
                                type=lk_vad.VADEventType.START_OF_SPEECH,
                                samples_index=self._samples_index,
                                timestamp=time.time(),
                                speech_duration=0.0,
                                silence_duration=self._silence_duration,
                                frames=list(self._segment_frames),
                                speaking=True,
                            )
                        )
                    elif state == SpeechState.SPEECH_END and segment is not None:
                        # End of current speech segment: include the latest frame, then emit and clear.
                        if self._segment_frames and self._segment_frames[-1] is not frame:
                            self._segment_frames.append(frame)
                        self._speech_duration += segment.duration_ms / 1000.0
                        logger.info(
                            "VAD END_OF_SPEECH detected (idx=%s, speech_s=%.2f)",
                            self._samples_index,
                            self._speech_duration,
                        )
                        self._event_ch.send_nowait(
                            lk_vad.VADEvent(
                                type=lk_vad.VADEventType.END_OF_SPEECH,
                                samples_index=self._samples_index,
                                timestamp=time.time(),
                                speech_duration=self._speech_duration,
                                silence_duration=self._silence_duration,
                                frames=list(self._segment_frames),
                                speaking=False,
                            )
                        )
                        self._segment_frames.clear()
                    elif state == SpeechState.IN_SPEECH:
                        # Ongoing speech: accumulate frames for this segment only.
                        self._segment_frames.append(frame)
                        self._speech_duration += frame_duration_s
                        if _DEBUG:
                            logger.debug(
                                "VAD IN_SPEECH (idx=%s, duration=%.2f)", self._samples_index, self._speech_duration
                            )
                    else:
                        self._silence_duration += frame_duration_s
                        if _DEBUG and self._samples_index % 10000 == 0:
                            logger.debug(
                                "VAD silence (idx=%s, duration=%.2fs)", self._samples_index, self._silence_duration
                            )
        except Exception as e:
            logger.exception("WebRTC VAD stream error: %s", e)
            raise
        finally:
            self._event_ch.close()
