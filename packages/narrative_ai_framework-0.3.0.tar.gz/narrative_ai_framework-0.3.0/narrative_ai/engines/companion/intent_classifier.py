"""Intent Classifier for smart RAG routing.

Classifies user messages into one of four intents to determine whether
a full RAG recall is needed, saving cost and latency on ~60% of messages.

Strategy: Heuristic-First with Dynamic Fallback
  1. Fast regex/keyword rules (0 ms) — handles most cases
  2. TF-IDF cosine similarity fallback — for ambiguous personal messages
     (uses exemplar phrases from intent_exemplars.yaml, 0ms, no API calls)

Intent categories:
  GENERAL          → Direct LLM response, no RAG needed
  PERSONAL_RECALL  → Full RAG recall required
  EMOTIONAL_SUPPORT → LLM + user profile context only, no RAG
  WEB_LOOKUP       → Internet search + citation-grounded response
  META_QUESTION    → Direct DB query, no LLM/RAG needed
"""

from __future__ import annotations

import logging
import math
import os
import re
from collections import Counter
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import yaml

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Intent enum
# ---------------------------------------------------------------------------


class Intent(str, Enum):
    GENERAL = "GENERAL"
    PERSONAL_RECALL = "PERSONAL_RECALL"
    EMOTIONAL_SUPPORT = "EMOTIONAL_SUPPORT"
    WEB_LOOKUP = "WEB_LOOKUP"
    META_QUESTION = "META_QUESTION"


# ---------------------------------------------------------------------------
# Keyword / regex rule sets  (Arabic + English)
# ---------------------------------------------------------------------------

# META_QUESTION: questions about diary statistics / counts / dates
_META_PATTERNS = re.compile(
    r"""
    # English
    \b(how\s+many|count\s+of|number\s+of|total\s+(entries|diary)|
       when\s+(did\s+i\s+start|was\s+my\s+first)|
       what\s+(are\s+my\s+tags|emotions?\s+do\s+i|is\s+my\s+(streak|total)))\b
    |
    # Arabic
    \b(كم\s+(مرة|تسجيل|يومية|إدخال)|عدد\s+(المدخلات|التسجيلات)|
       متى\s+بدأت|أول\s+تسجيل)\b
    """,
    re.IGNORECASE | re.VERBOSE,
)

# PERSONAL_RECALL: asking about specific past diary content
_RECALL_PATTERNS = re.compile(
    r"""
    # English
    \b(remember|recall|wrote|mentioned|said|noted|recorded|
       what\s+did\s+i\s+(write|say|feel|think|do)|
       when\s+did\s+i|last\s+time\s+i|
       what\s+was\s+my\s+problem|
       remind\s+me(\s+of|\s+about\s+my|\s+what\s+was\s+my)?|
       my\s+(diary|entry|entries|journal)|
       what\s+do\s+you\s+know\s+about\s+me|
       tell\s+me\s+about\s+(me|myself|my\s+past)|
       based\s+on\s+my\s+(entries|diary|journal)|
       summarize\s+my\s+(entries|diary|journal)|
       from\s+my\s+(entries|diary|journal)|
       tell\s+me\s+about\s+my|
       find\s+(in\s+my|my)|search\s+my)\b
    |
    # Arabic
    \b(تذكر|تذكّر|كتبت|ذكرت|سجّلت|قلت|
       ماذا\s+كتبت|متى\s+كتبت|آخر\s+مرة|
       يومياتي|مذكراتي|في\s+يومياتي|
       ماذا\s+تعرف\s+عني|احكي\s+لي\s+عن\s+يومياتي|
       لخص\s+يومياتي|لخّص\s+يومياتي)\b
    """,
    re.IGNORECASE | re.VERBOSE,
)

# EMOTIONAL_SUPPORT: emotional expressions / seeking comfort
_EMOTIONAL_PATTERNS = re.compile(
    r"""
    # English
    \b(i\s+(feel|am\s+feeling|felt|am)\s+(sad|down|anxious|stressed|
       depressed|lonely|overwhelmed|happy|excited|angry|frustrated|lost|
       scared|hopeless|tired|exhausted)|
       i\s+(need|want)\s+(support|comfort|help|to\s+talk)|
       i\s+don'?t\s+know\s+what\s+to\s+do|
       i\s+'?m\s+(struggling|having\s+a\s+hard\s+time|not\s+okay|not\s+ok))
    |
    # Arabic
    \b(أشعر\s+ب(الحزن|القلق|الوحدة|الإرهاق|الخوف|الفرح|السعادة)|
       أنا\s+(حزين|قلق|وحيد|متعب|خائف|سعيد)|
       لا\s+أعرف\s+ماذا\s+أفعل|أحتاج\s+(مساعدة|دعم))\b
    """,
    re.IGNORECASE | re.VERBOSE,
)

# WEB_LOOKUP: current events / internet lookup requests
_WEB_PATTERNS = re.compile(
    r"""
    # English
    \b(latest|current|today'?s|breaking\s+news|news\s+about|
       last\s+updates?|latest\s+updates?|recent\s+updates?|what'?s\s+new|
       search\s+the\s+web|search\s+online|search\s+for|search\s+me\s+for|
       look\s+up|find\s+online|find\s+me|
       on\s+the\s+internet|web\s+search)\b
    |
    # Arabic
    \b(أحدث|آخر\s+الأخبار|اخبار\s+اليوم|الأخبار\s+اليوم|آخر\s+التحديثات|آخر\s+المستجدات|
       ابحث|ابحثلي|ابحث\s+عن|دور\s+على|على\s+الانترنت|في\s+الإنترنت)\b
    """,
    re.IGNORECASE | re.VERBOSE,
)

_QUESTION_PREFIX_PATTERNS = re.compile(
    r"^\s*(what|when|where|who|how|why|which|did|do|does|can|could|is|are|was|were|"
    r"هل|متى|ماذا|من|مين|كيف|لماذا|وين)\b",
    re.IGNORECASE,
)

_PERSONAL_REFERENCE_PATTERNS = re.compile(
    r"\b(i|me|my|mine|myself)\b|"
    r"\b(أنا|عندي|لي|يومي|يومياتي|حياتي|مذكراتي)\b",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Lightweight TF-IDF similarity (0 ms, no external dependencies)
# ---------------------------------------------------------------------------

_TOKENIZER = re.compile(r"[a-zA-Z\u0600-\u06FF']+", re.UNICODE)


def _tokenize(text: str) -> List[str]:
    """Tokenize text into lowercase word tokens (Latin + Arabic)."""
    return [m.group().lower() for m in _TOKENIZER.finditer(text)]


def _cosine_similarity(vec_a: Dict[str, float], vec_b: Dict[str, float]) -> float:
    """Compute cosine similarity between two sparse tf-idf vectors."""
    keys = set(vec_a) & set(vec_b)
    if not keys:
        return 0.0
    dot = sum(vec_a[k] * vec_b[k] for k in keys)
    norm_a = math.sqrt(sum(v * v for v in vec_a.values()))
    norm_b = math.sqrt(sum(v * v for v in vec_b.values()))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


class _ExemplarIndex:
    """Pre-computed TF-IDF index for exemplar phrases."""

    def __init__(self, exemplars: Dict[Intent, List[str]], threshold: float = 0.58):
        self.threshold = threshold
        self._exemplar_tokens: List[Tuple[Intent, List[str]]] = []
        self._df: Counter = Counter()
        self._n_docs = 0

        # Build document frequency from all exemplars
        all_docs: List[Tuple[Intent, List[str]]] = []
        for intent, phrases in exemplars.items():
            for phrase in phrases:
                tokens = _tokenize(phrase)
                if tokens:
                    all_docs.append((intent, tokens))
                    self._df.update(set(tokens))

        self._exemplar_tokens = all_docs
        self._n_docs = len(all_docs) or 1  # avoid div/0

    def _tfidf_vector(self, tokens: List[str]) -> Dict[str, float]:
        """Compute TF-IDF vector for a list of tokens."""
        tf = Counter(tokens)
        vec: Dict[str, float] = {}
        for token, count in tf.items():
            df = self._df.get(token, 0)
            if df == 0:
                continue
            idf = math.log(self._n_docs / df) + 1.0
            vec[token] = (count / len(tokens)) * idf
        return vec

    def classify(self, text: str) -> Tuple[Intent, float]:
        """Classify text by similarity to exemplar phrases.

        Returns (best_intent, best_score). If best_score < threshold,
        the caller should fall through to GENERAL.
        """
        query_tokens = _tokenize(text)
        if not query_tokens:
            return Intent.GENERAL, 0.0

        query_vec = self._tfidf_vector(query_tokens)
        best_intent = Intent.GENERAL
        best_score = 0.0

        for intent, ex_tokens in self._exemplar_tokens:
            ex_vec = self._tfidf_vector(ex_tokens)
            score = _cosine_similarity(query_vec, ex_vec)
            if score > best_score:
                best_intent = intent
                best_score = score

        return best_intent, best_score


def _load_exemplars(yaml_path: Optional[str] = None) -> Tuple[Dict[Intent, List[str]], float]:
    """Load exemplar phrases from YAML config file."""
    if yaml_path is None:
        yaml_path = str(Path(__file__).parent / "intent_exemplars.yaml")

    exemplars: Dict[Intent, List[str]] = {
        Intent.EMOTIONAL_SUPPORT: [],
        Intent.PERSONAL_RECALL: [],
    }
    threshold = 0.58

    if not os.path.exists(yaml_path):
        logger.warning("Exemplars file not found at %s; dynamic classification disabled", yaml_path)
        return exemplars, threshold

    try:
        with open(yaml_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        for lang_phrases in (data.get("emotional_support", {}) or {}).values():
            if isinstance(lang_phrases, list):
                exemplars[Intent.EMOTIONAL_SUPPORT].extend(lang_phrases)

        for lang_phrases in (data.get("personal_recall", {}) or {}).values():
            if isinstance(lang_phrases, list):
                exemplars[Intent.PERSONAL_RECALL].extend(lang_phrases)

        threshold = float(data.get("similarity_threshold", 0.58))
        total = sum(len(v) for v in exemplars.values())
        logger.info("Loaded %d intent exemplars from %s (threshold=%.2f)", total, yaml_path, threshold)
    except Exception as exc:
        logger.warning("Failed to load intent exemplars: %s", exc)

    return exemplars, threshold


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------


class IntentClassifier:
    """Heuristic-first intent classifier with dynamic exemplar fallback.

    Checks rules in priority order:
      1. META_QUESTION  (most specific — DB only)
      2. PERSONAL_RECALL (needs RAG)
      3. EMOTIONAL_SUPPORT (needs profile, no RAG)
      4. WEB_LOOKUP (needs web search + citations)
      5. Dynamic exemplar fallback (TF-IDF similarity)
      6. GENERAL (default — direct LLM)
    """

    def __init__(self, exemplar_yaml_path: Optional[str] = None) -> None:
        exemplars, threshold = _load_exemplars(exemplar_yaml_path)
        self._exemplar_index = _ExemplarIndex(exemplars, threshold=threshold)

    def classify(self, message: str) -> Intent:
        """Classify a user message. Returns an Intent enum value.

        Args:
            message: The raw user message text.

        Returns:
            Intent enum value.
        """
        text = message.strip()
        if not text:
            return Intent.GENERAL

        # Priority 1: META_QUESTION (most specific)
        if _META_PATTERNS.search(text):
            logger.debug("Intent: META_QUESTION (heuristic match)")
            return Intent.META_QUESTION

        # Priority 2: PERSONAL_RECALL
        if _RECALL_PATTERNS.search(text):
            logger.debug("Intent: PERSONAL_RECALL (heuristic match)")
            return Intent.PERSONAL_RECALL

        # Priority 3: EMOTIONAL_SUPPORT
        if _EMOTIONAL_PATTERNS.search(text):
            logger.debug("Intent: EMOTIONAL_SUPPORT (heuristic match)")
            return Intent.EMOTIONAL_SUPPORT

        # Priority 4: WEB_LOOKUP
        if _WEB_PATTERNS.search(text):
            logger.debug("Intent: WEB_LOOKUP (heuristic match)")
            return Intent.WEB_LOOKUP

        # Priority 5: Dynamic exemplar fallback — for any message with
        # personal references.  Uses TF-IDF cosine similarity (0 ms).
        if self._looks_like_personal_message(text):
            intent, score = self._exemplar_index.classify(text)
            if score >= self._exemplar_index.threshold:
                logger.debug(
                    "Intent: %s (dynamic exemplar, score=%.3f)",
                    intent.value,
                    score,
                )
                return intent
            # Below threshold but still personal — default to GENERAL
            # (not PERSONAL_RECALL) to avoid unnecessary RAG triggers
            logger.debug(
                "Intent: GENERAL (personal message, but dynamic score=%.3f < threshold=%.2f)",
                score,
                self._exemplar_index.threshold,
            )
            return Intent.GENERAL

        # Priority 6 / Default: GENERAL
        logger.debug("Intent: GENERAL (default)")
        return Intent.GENERAL

    @staticmethod
    def _looks_like_personal_message(text: str) -> bool:
        """Check if message is personal AND question-like before dynamic fallback."""
        has_personal_ref = bool(_PERSONAL_REFERENCE_PATTERNS.search(text))
        if not has_personal_ref:
            return False

        # Keep dynamic fallback narrow to avoid false positives on plain statements.
        if "?" in text or "؟" in text:
            return True
        return bool(_QUESTION_PREFIX_PATTERNS.search(text))

    def needs_rag(self, intent: Intent) -> bool:
        """Return True if this intent requires a RAG recall."""
        return intent == Intent.PERSONAL_RECALL

    def needs_db_only(self, intent: Intent) -> bool:
        """Return True if this intent should be answered from DB directly."""
        return intent == Intent.META_QUESTION

    def needs_profile_only(self, intent: Intent) -> bool:
        """Return True if this intent needs profile context but not RAG."""
        return intent == Intent.EMOTIONAL_SUPPORT

    def needs_web(self, intent: Intent) -> bool:
        """Return True if this intent requires internet lookup."""
        return intent == Intent.WEB_LOOKUP


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_classifier_instance: Optional[IntentClassifier] = None


def get_intent_classifier() -> IntentClassifier:
    """Return the global IntentClassifier singleton."""
    global _classifier_instance
    if _classifier_instance is None:
        _classifier_instance = IntentClassifier()
    return _classifier_instance
