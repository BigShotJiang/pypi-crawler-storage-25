"""Companion audio response building (placeholder).

This module is reserved for future voice-companion features that build
audio responses (e.g. TTS from companion reply text). Not yet implemented.
Do not rely on this module for production behavior.
"""

from __future__ import annotations

# Placeholder: no public API until voice companion audio is implemented.
__all__: list[str] = []
