"""
Document Extractor for the Enhanced Ingestion Pipeline.

Integrates with Unstructured.io to extract content from various document formats.
Preserves original content, layout, tables, and images without modification.
"""

import logging
import asyncio
import uuid
from pathlib import Path
from typing import List, Optional, Dict, Any, Union

from .config import get_config, IngestionConfig
from .types import (
    ContentBlock,
    ContentBlockType,
    BlockMetadata,
    PositionInfo,
    ProvenanceInfo,
    ProcessingError,
)

logger = logging.getLogger(__name__)

# Try to import unstructured
try:
    from unstructured.partition.auto import partition

    UNSTRUCTURED_AVAILABLE = True
except ImportError:
    UNSTRUCTURED_AVAILABLE = False
    logger.warning("Unstructured library not available. Document extraction will be limited.")


class DocumentExtractor:
    """
    Extracts content from documents using Unstructured.io.

    Responsibilities:
    - Extract text blocks, tables, images, and layout information
    - Preserve original content without modification
    - Handle extraction failures gracefully
    - Return structured content blocks
    """

    # Mapping from Unstructured element types to ContentBlockType
    ELEMENT_TYPE_MAP = {
        "Title": ContentBlockType.HEADING,
        "Header": ContentBlockType.HEADING,
        "NarrativeText": ContentBlockType.TEXT,
        "Text": ContentBlockType.TEXT,
        "ListItem": ContentBlockType.LIST,
        "Table": ContentBlockType.TABLE,
        "Image": ContentBlockType.IMAGE,
        "FigureCaption": ContentBlockType.TEXT,
        "PageBreak": ContentBlockType.PAGE_BREAK,
        "Footer": ContentBlockType.TEXT,
    }

    def __init__(self, config: Optional[IngestionConfig] = None):
        """
        Initialize the document extractor.

        Args:
            config: Optional configuration. Uses global config if not provided.
        """
        self.config = config or get_config()
        self._unstructured_config = self.config.unstructured
        self._errors: List[ProcessingError] = []

    async def extract(
        self,
        file_path: Union[str, Path],
        extract_images: Optional[bool] = None,
    ) -> tuple[List[ContentBlock], List[ProcessingError], Dict[str, Any]]:
        """
        Extract content from a document file.

        Args:
            file_path: Path to the document file.
            extract_images: Override config for image extraction.

        Returns:
            Tuple of (content_blocks, errors, document_metadata)
        """
        self._errors = []
        file_path = Path(file_path)

        if not UNSTRUCTURED_AVAILABLE:
            error = ProcessingError(
                component="document_extractor",
                error_type="ImportError",
                message="Unstructured library not available",
                recoverable=False,
            )
            return [], [error], {}

        if not file_path.exists():
            error = ProcessingError(
                component="document_extractor",
                error_type="FileNotFoundError",
                message=f"File not found: {file_path}",
                recoverable=False,
            )
            return [], [error], {}

        logger.info(f"Extracting content from: {file_path}")

        # Determine extraction settings
        should_extract_images = (
            extract_images if extract_images is not None else self._unstructured_config.extract_images
        )

        try:
            # Call Unstructured partition
            elements = await asyncio.to_thread(
                self._partition_document,
                file_path,
                should_extract_images,
            )

            # Convert elements to content blocks
            content_blocks = self._elements_to_blocks(elements, str(file_path))

            # Extract document-level metadata
            doc_metadata = self._extract_document_metadata(elements, file_path)

            logger.info(f"Extracted {len(content_blocks)} content blocks")

            return content_blocks, self._errors, doc_metadata

        except Exception as e:
            logger.error(f"Extraction failed: {e}")
            error = ProcessingError(
                component="document_extractor",
                error_type=type(e).__name__,
                message=str(e),
                recoverable=True,
                details={"file": str(file_path)},
            )
            self._errors.append(error)

            # Fallback: return raw content if possible
            fallback_blocks = await self._create_fallback_block(file_path)
            return fallback_blocks, self._errors, {}

    def _partition_document(
        self,
        file_path: Path,
        extract_images: bool,
    ) -> List[Any]:
        """Call Unstructured partition with configuration."""
        strategy = self._unstructured_config.strategy
        languages = self._unstructured_config.languages

        # Build partition kwargs
        kwargs = {
            "filename": str(file_path),
            "strategy": strategy,
            "languages": languages,
            "include_page_breaks": self._unstructured_config.include_page_breaks,
        }

        # Add PDF-specific options
        suffix = file_path.suffix.lower()
        if suffix == ".pdf":
            kwargs["infer_table_structure"] = self._unstructured_config.pdf_infer_table_structure
            if extract_images:
                kwargs["extract_image_block_types"] = self._unstructured_config.pdf_extract_image_block_types

        # Handle image extraction
        if extract_images:
            # Create temp directory for extracted images
            import tempfile

            kwargs["extract_images_in_pdf"] = True
            kwargs["image_output_dir_path"] = tempfile.mkdtemp(prefix="unstructured_images_")

        return partition(**kwargs)

    def _elements_to_blocks(
        self,
        elements: List[Any],
        source_file: str,
    ) -> List[ContentBlock]:
        """Convert Unstructured elements to ContentBlocks."""
        blocks = []

        for idx, element in enumerate(elements):
            try:
                block = self._element_to_block(element, idx, source_file)
                if block:
                    blocks.append(block)
            except Exception as e:
                logger.warning(f"Failed to convert element {idx}: {e}")
                error = ProcessingError(
                    component="document_extractor",
                    error_type="ConversionError",
                    message=f"Failed to convert element {idx}: {e}",
                    recoverable=True,
                    details={"element_index": idx},
                )
                self._errors.append(error)

        return blocks

    def _element_to_block(
        self,
        element: Any,
        sequence_index: int,
        source_file: str,
    ) -> Optional[ContentBlock]:
        """Convert a single Unstructured element to a ContentBlock."""
        # Get element type
        element_type = type(element).__name__
        block_type = self.ELEMENT_TYPE_MAP.get(element_type, ContentBlockType.TEXT)

        # Generate block ID
        block_id = f"block_{sequence_index}_{uuid.uuid4().hex[:8]}"

        # Extract content based on type
        if element_type == "Table":
            content = self._extract_table_content(element)
        elif element_type == "Image":
            content = self._extract_image_content(element)
        else:
            content = str(element)

        # Skip empty content
        if not content:
            return None

        # Build position info
        position = self._extract_position(element, sequence_index)

        # Build provenance info
        provenance = ProvenanceInfo(
            extraction_method="unstructured",
            model_used="unstructured.partition.auto",
            source_element_id=getattr(element, "id", None),
        )

        # Build metadata
        metadata = BlockMetadata(
            position=position,
            provenance=provenance,
            element_type=element_type,
        )

        return ContentBlock(
            block_id=block_id,
            type=block_type.value,
            content=content,
            metadata=metadata,
        )

    def _extract_table_content(self, element: Any) -> Dict[str, Any]:
        """Extract table content as structured data."""
        result = {
            "text": str(element),
            "html": None,
        }

        # Try to get HTML representation
        if hasattr(element, "metadata") and hasattr(element.metadata, "text_as_html"):
            result["html"] = element.metadata.text_as_html

        return result

    def _extract_image_content(self, element: Any) -> Dict[str, Any]:
        """Extract image content with metadata."""
        result = {
            "image_path": None,
            "alt_text": str(element) if str(element) else None,
        }

        # Try to get image path
        if hasattr(element, "metadata"):
            if hasattr(element.metadata, "image_path"):
                result["image_path"] = element.metadata.image_path

        return result

    def _extract_position(
        self,
        element: Any,
        sequence_index: int,
    ) -> PositionInfo:
        """Extract position/layout information from element."""
        position = PositionInfo(sequence_index=sequence_index)

        if hasattr(element, "metadata"):
            meta = element.metadata

            # Page number
            if hasattr(meta, "page_number"):
                position.page = meta.page_number

            # Bounding box coordinates
            if hasattr(meta, "coordinates") and meta.coordinates:
                coords = meta.coordinates
                if hasattr(coords, "points") and coords.points:
                    # Convert points to bbox format
                    points = coords.points
                    if len(points) >= 4:
                        x_coords = [p[0] for p in points]
                        y_coords = [p[1] for p in points]
                        position.bbox = [
                            min(x_coords),
                            min(y_coords),
                            max(x_coords),
                            max(y_coords),
                        ]

                # Layout dimensions
                if hasattr(coords, "layout_width"):
                    position.page_width = coords.layout_width
                if hasattr(coords, "layout_height"):
                    position.page_height = coords.layout_height

        return position

    def _extract_document_metadata(
        self,
        elements: List[Any],
        file_path: Path,
    ) -> Dict[str, Any]:
        """Extract document-level metadata."""
        doc_meta = {}

        # Count pages
        pages = set()
        for element in elements:
            if hasattr(element, "metadata") and hasattr(element.metadata, "page_number"):
                pages.add(element.metadata.page_number)

        # Filter out None values before calculating max
        valid_pages = {p for p in pages if p is not None}
        if valid_pages:
            doc_meta["total_pages"] = max(valid_pages)

        # Try to get document properties
        if elements:
            first_element = elements[0]
            if hasattr(first_element, "metadata"):
                meta = first_element.metadata
                if hasattr(meta, "filename"):
                    doc_meta["filename"] = meta.filename
                if hasattr(meta, "filetype"):
                    doc_meta["filetype"] = meta.filetype

        return doc_meta

    async def _create_fallback_block(self, file_path: Path) -> List[ContentBlock]:
        """Create a fallback block when extraction fails."""
        try:
            content = await asyncio.to_thread(self._read_text_fallback_chunks, file_path)

            block = ContentBlock(
                block_id=f"fallback_{uuid.uuid4().hex[:8]}",
                type=ContentBlockType.TEXT.value,
                content=content,
                metadata=BlockMetadata(
                    provenance=ProvenanceInfo(
                        extraction_method="fallback_text_read",
                    ),
                    extra={"warning": "Extraction failed, raw text fallback used"},
                ),
            )
            return [block]
        except Exception:
            return []

    def _read_text_fallback_chunks(self, file_path: Path) -> str:
        """
        Read fallback text using chunked streaming.
        Caps at 10MB to avoid memory blowups on malformed large files.
        """
        chunk_size = 64 * 1024
        max_bytes = 10 * 1024 * 1024
        total = 0
        chunks: List[str] = []
        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            while total < max_bytes:
                chunk = f.read(chunk_size)
                if not chunk:
                    break
                chunks.append(chunk)
                total += len(chunk.encode("utf-8", errors="ignore"))
        return "".join(chunks)

    async def extract_text_only(self, file_path: Union[str, Path]) -> str:
        """
        Extract only text content from a document.

        Convenience method that returns plain text without structure.
        """
        blocks, _, _ = await self.extract(file_path, extract_images=False)

        texts = []
        for block in blocks:
            if block.type in (ContentBlockType.TEXT.value, ContentBlockType.HEADING.value):
                texts.append(str(block.content))

        return "\n\n".join(texts)


async def extract_document(
    file_path: Union[str, Path],
    config: Optional[IngestionConfig] = None,
) -> tuple[List[ContentBlock], List[ProcessingError], Dict[str, Any]]:
    """
    Convenience function to extract a document.

    Args:
        file_path: Path to the document.
        config: Optional configuration.

    Returns:
        Tuple of (content_blocks, errors, document_metadata)
    """
    extractor = DocumentExtractor(config)
    return await extractor.extract(file_path)
