"""
Document Assembler for the Enhanced Ingestion Pipeline.

Merges all extracted and enriched content into a single, ordered
structured document ready for RAG processing.
"""

import logging
import uuid
import unicodedata
from datetime import datetime, timezone
from typing import Dict, Any, List, Optional
from .config import get_config, IngestionConfig
from .types import (
    StructuredDocument,
    DocumentMetadata,
    ContentBlock,
    ContentBlockType,
    SourceMetadata,
    ProcessingError,
)

logger = logging.getLogger(__name__)


class DocumentAssembler:
    """
    Assembles extracted content into a structured document.

    Responsibilities:
    - Merge content blocks from various sources
    - Preserve original ordering
    - Attach global metadata
    - Validate and deduplicate content
    """

    def __init__(self, config: Optional[IngestionConfig] = None):
        """
        Initialize the document assembler.

        Args:
            config: Optional configuration. Uses global config if not provided.
        """
        self.config = config or get_config()
        self._pipeline_version = self.config.pipeline.version

    def assemble(
        self,
        doc_id: str,
        source_metadata: SourceMetadata,
        content_blocks: List[ContentBlock],
        document_metadata: Optional[Dict[str, Any]] = None,
        errors: Optional[List[ProcessingError]] = None,
        processing_start_time: Optional[datetime] = None,
    ) -> StructuredDocument:
        """
        Assemble a structured document from components.

        Args:
            doc_id: Unique document identifier.
            source_metadata: Metadata about the input source.
            content_blocks: List of extracted content blocks.
            document_metadata: Optional document-level metadata.
            errors: Optional list of processing errors.
            processing_start_time: Optional start time for duration calculation.

        Returns:
            Assembled StructuredDocument.
        """
        logger.info(f"Assembling document: {doc_id}")

        # Sort blocks by sequence index
        sorted_blocks = self._sort_blocks(content_blocks)

        # Deduplicate blocks
        unique_blocks = self._deduplicate_blocks(sorted_blocks)

        # Validate blocks
        validated_blocks = self._validate_blocks(unique_blocks)

        # Calculate processing duration
        processing_duration_ms = None
        if processing_start_time:
            # Use timezone-aware comparison to avoid TypeError
            now = datetime.now(timezone.utc)
            duration = now - processing_start_time
            processing_duration_ms = int(duration.total_seconds() * 1000)

        # Build document metadata
        doc_meta = DocumentMetadata(
            source=source_metadata,
            pipeline_version=self._pipeline_version,
            processing_timestamp=datetime.now(timezone.utc).isoformat() + "Z",
            processing_duration_ms=processing_duration_ms,
            total_blocks=len(validated_blocks),
            errors=errors or [],
        )

        # Add document-level properties from extraction
        if document_metadata:
            doc_meta.total_pages = document_metadata.get("total_pages")
            doc_meta.title = document_metadata.get("title")
            doc_meta.author = document_metadata.get("author")
            doc_meta.creation_date = document_metadata.get("creation_date")
            doc_meta.language = document_metadata.get("language")

        # Normalize content (fix Arabic formatting and presentation forms)
        normalized_blocks = self._normalize_content(validated_blocks)

        # Create structured document
        document = StructuredDocument(
            doc_id=doc_id,
            metadata=doc_meta,
            content_blocks=normalized_blocks,
        )

        logger.info(f"Assembled document with {len(normalized_blocks)} blocks")

        return document

    def _normalize_content(self, blocks: List[ContentBlock]) -> List[ContentBlock]:
        """Normalize and fix formatting in all content blocks."""
        for block in blocks:
            if isinstance(block.content, str):
                block.content = self._fix_arabic_text(block.content)
            elif hasattr(block.content, "to_dict"):
                # Handle complex types like ImageData (OCR and Caption)
                if block.type == "image":
                    try:
                        if hasattr(block.content, "ocr") and block.content.ocr:
                            block.content.ocr.ocr_text = self._fix_arabic_text(block.content.ocr.ocr_text)
                        if hasattr(block.content, "caption") and block.content.caption:
                            block.content.caption.caption = self._fix_arabic_text(block.content.caption.caption)
                    except Exception as e:
                        logger.warning(f"Failed to normalize image content: {e}")
                elif block.type == "audio_transcript":
                    try:
                        if hasattr(block.content, "full_text"):
                            block.content.full_text = self._fix_arabic_text(block.content.full_text)
                        if hasattr(block.content, "segments"):
                            for segment in block.content.segments:
                                segment.text = self._fix_arabic_text(segment.text)
                    except Exception as e:
                        logger.warning(f"Failed to normalize transcript: {e}")
        return blocks

    def _fix_arabic_text(self, text: str) -> str:
        """
        Normalize Arabic presentation forms and fix visual-to-logical order.
        """
        if not text:
            return text

        # 1. Normalize to NFKC - this converts presentation forms to standard characters
        # Many disconnected characters (ﺔﯾّﺳﺣ) are presentation forms.
        # However, NFKC doesn't fix the order if it was extracted in visual order.

        # Detect if it's likely visual order (Arabic Presentation Forms range)
        has_presentation_forms = any("\ufb50" <= c <= "\ufdff" or "\ufe70" <= c <= "\ufeff" for c in text)

        # Normalize
        normalized = unicodedata.normalize("NFKC", text)

        # 2. If it was presentation forms, it's very likely in visual order (reverted)
        # We need to reverse it to get logical order for models.
        if has_presentation_forms:
            # We must reverse line-by-line, not the whole string.
            # Reversing the whole string flips the paragraph order (last becomes first).
            lines = normalized.split("\n")
            reversed_lines = [line[::-1] for line in lines]
            return "\n".join(reversed_lines)

        return normalized

    def _sort_blocks(
        self,
        blocks: List[ContentBlock],
    ) -> List[ContentBlock]:
        """Sort blocks by sequence index, then by page."""

        def sort_key(block: ContentBlock) -> tuple:
            position = block.metadata.position
            if position:
                page = position.page or 0
                seq = position.sequence_index or 0
                return (page, seq)
            return (0, 0)

        return sorted(blocks, key=sort_key)

    def _deduplicate_blocks(
        self,
        blocks: List[ContentBlock],
    ) -> List[ContentBlock]:
        """Remove duplicate blocks based on content hash."""
        seen_content: Dict[str, bool] = {}
        unique_blocks: List[ContentBlock] = []

        for block in blocks:
            # Create content hash
            content_str = str(block.content)
            content_hash = hash(content_str)

            if content_hash not in seen_content:
                seen_content[content_hash] = True
                unique_blocks.append(block)
            else:
                logger.debug(f"Removed duplicate block: {block.block_id}")

        if len(unique_blocks) < len(blocks):
            logger.info(f"Removed {len(blocks) - len(unique_blocks)} duplicate blocks")

        return unique_blocks

    def _validate_blocks(
        self,
        blocks: List[ContentBlock],
    ) -> List[ContentBlock]:
        """Validate blocks and filter out invalid ones."""
        valid_blocks: List[ContentBlock] = []

        for block in blocks:
            # Skip empty text blocks
            if block.type == ContentBlockType.TEXT.value:
                content = str(block.content).strip()
                if not content:
                    continue

            # Skip page breaks if configured
            if block.type == ContentBlockType.PAGE_BREAK.value:
                if not self.config.unstructured.include_page_breaks:
                    continue

            # Ensure block has valid ID
            if not block.block_id:
                block.block_id = f"block_{uuid.uuid4().hex[:12]}"

            valid_blocks.append(block)

        return valid_blocks

    def merge_documents(
        self,
        documents: List[StructuredDocument],
        new_doc_id: Optional[str] = None,
    ) -> StructuredDocument:
        """
        Merge multiple structured documents into one.

        Args:
            documents: List of documents to merge.
            new_doc_id: Optional new document ID.

        Returns:
            Merged StructuredDocument.
        """
        if not documents:
            raise ValueError("No documents to merge")

        if len(documents) == 1:
            return documents[0]

        # Use first document as base
        base = documents[0]
        new_id = new_doc_id or f"merged_{uuid.uuid4().hex[:8]}"

        # Collect all blocks
        all_blocks: List[ContentBlock] = []
        all_errors: List[ProcessingError] = []

        for doc in documents:
            all_blocks.extend(doc.content_blocks)
            all_errors.extend(doc.metadata.errors)

        # Re-index blocks
        for i, block in enumerate(all_blocks):
            if block.metadata.position:
                block.metadata.position.sequence_index = i

        # Create merged document
        return self.assemble(
            doc_id=new_id,
            source_metadata=base.metadata.source,
            content_blocks=all_blocks,
            errors=all_errors,
        )

    def add_blocks(
        self,
        document: StructuredDocument,
        new_blocks: List[ContentBlock],
    ) -> StructuredDocument:
        """
        Add new blocks to an existing document.

        Args:
            document: Existing document.
            new_blocks: Blocks to add.

        Returns:
            Updated StructuredDocument.
        """
        # Update sequence indices
        start_index = len(document.content_blocks)
        for i, block in enumerate(new_blocks):
            if block.metadata.position:
                block.metadata.position.sequence_index = start_index + i

        document.content_blocks.extend(new_blocks)
        document.metadata.total_blocks = len(document.content_blocks)

        return document


def assemble_document(
    doc_id: str,
    source_metadata: SourceMetadata,
    content_blocks: List[ContentBlock],
    config: Optional[IngestionConfig] = None,
) -> StructuredDocument:
    """
    Convenience function to assemble a document.

    Args:
        doc_id: Document ID.
        source_metadata: Source metadata.
        content_blocks: Content blocks.
        config: Optional configuration.

    Returns:
        Assembled StructuredDocument.
    """
    assembler = DocumentAssembler(config)
    return assembler.assemble(doc_id, source_metadata, content_blocks)
