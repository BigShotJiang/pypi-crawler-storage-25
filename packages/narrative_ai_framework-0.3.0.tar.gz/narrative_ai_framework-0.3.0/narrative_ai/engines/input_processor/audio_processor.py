"""
Audio Processor for the Enhanced Ingestion Pipeline.

Handles audio and video ingestion including YouTube URL downloads,
audio extraction, and speech-to-text transcription.
"""

import asyncio
import logging
import tempfile
import uuid
from pathlib import Path
from typing import List, Optional, Tuple, Union

from .config import get_config, IngestionConfig
from .types import (
    ContentBlock,
    ContentBlockType,
    BlockMetadata,
    PositionInfo,
    ProvenanceInfo,
    ProcessingError,
    AudioTranscript,
)
from .stt_processor import STTProcessor

logger = logging.getLogger(__name__)

try:
    import yt_dlp

    YTDLP_AVAILABLE = True
except ImportError:
    YTDLP_AVAILABLE = False
    logger.warning("yt-dlp not available. YouTube downloads will be disabled.")

try:
    from pydub import AudioSegment

    PYDUB_AVAILABLE = True
except ImportError:
    PYDUB_AVAILABLE = False
    logger.warning("pydub not available. Audio conversion will be limited.")


class AudioProcessor:
    """
    Async audio and video ingestion processor.
    """

    def __init__(self, config: Optional[IngestionConfig] = None):
        self.config = config or get_config()
        self._audio_config = self.config.audio_processing
        self._stt = STTProcessor(config)
        self._temp_dir = self._audio_config.youtube.temp_dir

    @property
    def is_enabled(self) -> bool:
        """Check if audio processing is enabled."""
        return self._audio_config.enabled

    async def process_audio(
        self,
        source: Union[str, Path],
        language: Optional[str] = None,
    ) -> Tuple[AudioTranscript, List[ProcessingError]]:
        """
        Process an audio source (file or YouTube URL).
        """
        errors: List[ProcessingError] = []
        source_str = str(source)

        if self._is_youtube_url(source_str):
            audio_path, download_errors = await self._download_youtube_audio(source_str)
            errors.extend(download_errors)
            if audio_path is None:
                return self._create_error_transcript(source_str), errors + [
                    ProcessingError(
                        component="audio_processor",
                        error_type="DownloadError",
                        message="Failed to download YouTube audio",
                        recoverable=False,
                    )
                ]
        else:
            audio_path = Path(source)
            if not audio_path.exists():
                return self._create_error_transcript(source_str), [
                    ProcessingError(
                        component="audio_processor",
                        error_type="FileNotFoundError",
                        message=f"Audio file not found: {audio_path}",
                        recoverable=False,
                    )
                ]

        transcript, stt_error = await self._stt.process(audio_path, language)
        if stt_error:
            errors.append(stt_error)
        if transcript is None:
            transcript = self._create_error_transcript(source_str)
            transcript.errors = errors
        return transcript, errors

    async def process_video(
        self,
        source: Union[str, Path],
        language: Optional[str] = None,
    ) -> Tuple[AudioTranscript, List[ProcessingError]]:
        """
        Process a video source by extracting and transcribing audio.
        """
        errors: List[ProcessingError] = []
        source_str = str(source)

        if self._is_youtube_url(source_str):
            return await self.process_audio(source, language)

        audio_path, extract_error = await self._extract_audio_from_video(Path(source))
        if extract_error:
            errors.append(extract_error)
        if audio_path is None:
            return self._create_error_transcript(source_str), errors

        transcript, stt_errors = await self.process_audio(audio_path, language)
        return transcript, errors + stt_errors

    def _is_youtube_url(self, url: str) -> bool:
        youtube_patterns = [
            "youtube.com/watch",
            "youtu.be/",
            "youtube.com/embed",
            "youtube.com/v/",
        ]
        return any(pattern in url for pattern in youtube_patterns)

    async def _download_youtube_audio(
        self,
        url: str,
    ) -> Tuple[Optional[Path], List[ProcessingError]]:
        """
        Download audio from a YouTube video asynchronously.
        """
        if not YTDLP_AVAILABLE:
            return None, [
                ProcessingError(
                    component="audio_processor",
                    error_type="ImportError",
                    message="yt-dlp not installed",
                    recoverable=False,
                )
            ]

        temp_dir = self._temp_dir or tempfile.mkdtemp(prefix="youtube_audio_")
        output_path = Path(temp_dir) / f"youtube_{uuid.uuid4().hex[:8]}"
        ydl_opts = {
            "format": self._audio_config.youtube.format,
            "outtmpl": str(output_path) + ".%(ext)s",
            "postprocessors": [
                {
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": self._audio_config.youtube.output_format,
                }
            ],
            "quiet": True,
            "no_warnings": True,
        }

        def _download() -> Tuple[Optional[Path], List[ProcessingError]]:
            try:
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    ydl.extract_info(url, download=True)
                output_format = self._audio_config.youtube.output_format
                audio_file = output_path.with_suffix(f".{output_format}")
                if audio_file.exists():
                    return audio_file, []
                for ext in ["wav", "mp3", "m4a", "opus", "webm"]:
                    alt_file = output_path.with_suffix(f".{ext}")
                    if alt_file.exists():
                        return alt_file, []
                return None, [
                    ProcessingError(
                        component="audio_processor",
                        error_type="DownloadError",
                        message="Downloaded file not found",
                        recoverable=True,
                    )
                ]
            except Exception as e:
                logger.error("YouTube download failed: %s", e)
                return None, [
                    ProcessingError(
                        component="audio_processor",
                        error_type=type(e).__name__,
                        message=str(e),
                        recoverable=True,
                    )
                ]

        return await asyncio.to_thread(_download)

    async def _extract_audio_from_video(
        self,
        video_path: Path,
    ) -> Tuple[Optional[Path], Optional[ProcessingError]]:
        """
        Extract audio track from a video file asynchronously.
        """
        if not PYDUB_AVAILABLE:
            return None, ProcessingError(
                component="audio_processor",
                error_type="ImportError",
                message="pydub not installed",
                recoverable=False,
            )
        if not video_path.exists():
            return None, ProcessingError(
                component="audio_processor",
                error_type="FileNotFoundError",
                message=f"Video file not found: {video_path}",
                recoverable=False,
            )

        def _extract() -> Tuple[Optional[Path], Optional[ProcessingError]]:
            try:
                audio = AudioSegment.from_file(str(video_path))
                temp_dir = self._temp_dir or tempfile.mkdtemp(prefix="video_audio_")
                audio_path = Path(temp_dir) / f"{video_path.stem}_audio.wav"
                audio.export(str(audio_path), format="wav")
                logger.info("Extracted audio from video: %s", audio_path)
                return audio_path, None
            except Exception as e:
                logger.error("Audio extraction failed: %s", e)
                return None, ProcessingError(
                    component="audio_processor",
                    error_type=type(e).__name__,
                    message=str(e),
                    recoverable=True,
                )

        return await asyncio.to_thread(_extract)

    def _create_error_transcript(self, source: str) -> AudioTranscript:
        return AudioTranscript(
            transcript_id=f"error_{uuid.uuid4().hex[:8]}",
            full_text="",
            status="failed",
        )

    def create_transcript_blocks(
        self,
        transcript: AudioTranscript,
        source_info: Optional[str] = None,
    ) -> List[ContentBlock]:
        """
        Convert an audio transcript to content blocks.
        """
        blocks: List[ContentBlock] = []

        if transcript.segments:
            for i, segment in enumerate(transcript.segments):
                block_id = f"audio_{transcript.transcript_id}_{i}"
                content = {
                    "text": segment.text,
                    "start_time": segment.start_time,
                    "end_time": segment.end_time,
                    "speaker": segment.speaker,
                }
                position = PositionInfo(sequence_index=i)
                provenance = ProvenanceInfo(
                    extraction_method="audio_transcription",
                    model_used=transcript.stt_model,
                )
                blocks.append(
                    ContentBlock(
                        block_id=block_id,
                        type=ContentBlockType.AUDIO_TRANSCRIPT.value,
                        content=content,
                        metadata=BlockMetadata(position=position, provenance=provenance),
                    )
                )
        else:
            blocks.append(
                ContentBlock(
                    block_id=f"audio_{transcript.transcript_id}_full",
                    type=ContentBlockType.AUDIO_TRANSCRIPT.value,
                    content={"text": transcript.full_text, "duration": transcript.duration},
                    metadata=BlockMetadata(
                        provenance=ProvenanceInfo(
                            extraction_method="audio_transcription",
                            model_used=transcript.stt_model,
                        )
                    ),
                )
            )

        return blocks

    async def get_youtube_video_info(self, url: str) -> Optional[dict]:
        """
        Get metadata about a YouTube video without downloading.
        """
        if not YTDLP_AVAILABLE:
            return None

        def _fetch() -> Optional[dict]:
            try:
                ydl_opts = {
                    "quiet": True,
                    "no_warnings": True,
                    "extract_flat": True,
                }
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(url, download=False)
                    return {
                        "title": info.get("title"),
                        "duration": info.get("duration"),
                        "uploader": info.get("uploader"),
                        "description": info.get("description"),
                        "view_count": info.get("view_count"),
                    }
            except Exception as e:
                logger.warning("Could not get YouTube info: %s", e)
                return None

        return await asyncio.to_thread(_fetch)


async def process_audio(
    source: str,
    config: Optional[IngestionConfig] = None,
    language: Optional[str] = None,
) -> AudioTranscript:
    """
    Simple async API entrypoint for audio processing.
    """
    processor = AudioProcessor(config)
    transcript, _ = await processor.process_audio(source, language)
    return transcript
