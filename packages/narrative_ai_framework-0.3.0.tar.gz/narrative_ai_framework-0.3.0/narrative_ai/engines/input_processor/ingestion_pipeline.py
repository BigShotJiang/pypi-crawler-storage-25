"""
Ingestion Pipeline Orchestrator for the Enhanced Ingestion Pipeline.

Main async entry point that transforms input sources into RAG-ready
structured documents.
"""

import asyncio
import logging
import os
import random
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Union, List, Iterable, Tuple, Any

from .config import get_config, IngestionConfig, load_config

# Optional security integration - engines run exactly as today when unavailable
try:
    from narrative_ai.security.engine_integration import (
        check_rate_limit_for_engine,
        log_audit_for_engine,
    )
    from narrative_ai.security.rate_limiting import EndpointCosts, RateLimiter
    from narrative_ai.security.audit_trail import AuditLogger, ActionType
    from narrative_ai.security.error_handling import SecureErrorHandler

    _SECURITY_AVAILABLE = True
except ImportError:
    RateLimiter = None
    AuditLogger = None
    ActionType = None
    SecureErrorHandler = None
    _SECURITY_AVAILABLE = False

if not _SECURITY_AVAILABLE:
    logging.getLogger(__name__).warning(
        "Security layer not available - input_processor running without security integration"
    )
from .types import (
    StructuredDocument,
    ContentBlock,
    ProcessingError,
)
from .input_handler import InputHandler, InputValidationError
from .document_extractor import DocumentExtractor
from .image_processor import ImageProcessor
from .audio_processor import AudioProcessor
from .assembler import DocumentAssembler

logger = logging.getLogger(__name__)


class IngestionPipeline:
    """
    Main async ingestion pipeline orchestrator.
    """

    def __init__(
        self,
        config: Optional[IngestionConfig] = None,
        config_path: Optional[Union[str, Path]] = None,
    ):
        if config:
            self.config = config
        elif config_path:
            self.config = load_config(config_path)
        else:
            self.config = get_config()

        random.seed(self.config.pipeline.random_seed)
        self._setup_logging()

        self._rate_limiter = None
        self._audit_logger = None
        self._error_handler = None
        self._security_initialized = False

        self._input_handler = InputHandler(self.config)
        self._document_extractor = DocumentExtractor(self.config)
        self._image_processor = ImageProcessor(self.config)
        self._audio_processor = AudioProcessor(self.config)
        self._assembler = DocumentAssembler(self.config)

    def _setup_logging(self) -> None:
        log_level = getattr(logging, self.config.logging.level.upper(), logging.INFO)
        logging.basicConfig(
            level=log_level,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        )
        if self.config.logging.file:
            handler = logging.FileHandler(self.config.logging.file)
            handler.setLevel(log_level)
            logging.getLogger().addHandler(handler)

    @property
    def version(self) -> str:
        """Get pipeline version."""
        return self.config.pipeline.version

    def _ensure_security_initialized(self) -> None:
        """Lazy-init rate limiter and audit logger when security is enabled."""
        if not _SECURITY_AVAILABLE or self._security_initialized:
            return
        if not (
            getattr(self.config.integration, "enable_rate_limiting", False)
            or getattr(self.config.integration, "enable_audit_logging", False)
            or getattr(self.config.integration, "enable_error_handling", False)
        ):
            self._security_initialized = True
            return
        try:
            is_production = os.getenv("ENV", "").lower() == "production"
            skip_rate_limit = not is_production and os.getenv("VOICE_DEV_SKIP_RATE_LIMIT", "").strip() == "1"
            if getattr(self.config.integration, "enable_rate_limiting", False) and RateLimiter and not skip_rate_limit:
                self._rate_limiter = RateLimiter()
            if getattr(self.config.integration, "enable_audit_logging", False) and AuditLogger:
                audit_db_url = os.getenv("AUDIT_DATABASE_URL") or os.getenv("DATABASE_URL")
                if audit_db_url:
                    self._audit_logger = AuditLogger(database_url=audit_db_url)
                else:
                    logger.warning("Audit logging enabled but AUDIT_DATABASE_URL/DATABASE_URL not set")
            if getattr(self.config.integration, "enable_error_handling", False) and SecureErrorHandler:
                try:
                    self._error_handler = SecureErrorHandler()
                except Exception as e:
                    logger.warning("Secure error handler initialization failed: %s", e)
        except Exception as e:
            logger.warning("Security initialization failed: %s", e)
        self._security_initialized = True

    async def process(
        self,
        source: Union[str, Path, bytes],
        enable_image_processing: Optional[bool] = None,
        enable_audio_processing: Optional[bool] = None,
        user_id: Optional[Any] = None,
        tenant_id: Optional[Any] = None,
        correlation_id: Optional[str] = None,
    ) -> StructuredDocument:
        """
        Process any input source into a structured document asynchronously.
        """
        # Security: rate limit (when enabled)
        if _SECURITY_AVAILABLE:
            self._ensure_security_initialized()
            if getattr(self.config.integration, "enable_rate_limiting", False) and self._rate_limiter:
                check_rate_limit_for_engine(
                    self._rate_limiter,
                    user_id,
                    tenant_id,
                    EndpointCosts.DOCUMENT_INGEST,
                    "anon.engine.input_processor",
                    user_tier_callback=getattr(self.config.integration, "user_tier_callback", None),
                )

        start_time = datetime.now(timezone.utc)
        errors: List[ProcessingError] = []
        source_type = "unknown"

        logger.info("Starting ingestion pipeline v%s", self.version)
        try:
            doc_id, source_metadata, source_type = await self._input_handler.process_input(source)
            logger.info("Processing %s: doc_id=%s", source_type, doc_id)

            document: StructuredDocument
            if source_type in ("audio", "youtube"):
                document = await self._process_audio_source(
                    source=source,
                    doc_id=doc_id,
                    source_metadata=source_metadata,
                    start_time=start_time,
                    errors=errors,
                )
            elif source_type == "video":
                document = await self._process_video_source(
                    source=source,
                    doc_id=doc_id,
                    source_metadata=source_metadata,
                    start_time=start_time,
                    errors=errors,
                )
            else:
                document = await self._process_document_source(
                    source=source,
                    doc_id=doc_id,
                    source_metadata=source_metadata,
                    source_type=source_type,
                    start_time=start_time,
                    errors=errors,
                    enable_image_processing=enable_image_processing,
                )

            # Security: audit success (when enabled)
            if (
                _SECURITY_AVAILABLE
                and getattr(self.config.integration, "enable_audit_logging", False)
                and self._audit_logger
            ):
                log_audit_for_engine(
                    self._audit_logger,
                    user_id,
                    tenant_id,
                    ActionType.DOCUMENT_INGEST,
                    "document",
                    "success",
                    {
                        "doc_id": document.doc_id,
                        "block_count": len(document.content_blocks),
                        "source_type": source_type,
                    },
                    resource_id=None,
                    engine_namespace="anon.engine.input_processor",
                    correlation_id=correlation_id,
                )

            return document
        except Exception as e:
            # Security: audit failure (when enabled) - matches STT/TTS/LLM pattern
            if (
                _SECURITY_AVAILABLE
                and getattr(self.config.integration, "enable_audit_logging", False)
                and self._audit_logger
            ):
                log_audit_for_engine(
                    self._audit_logger,
                    user_id,
                    tenant_id,
                    ActionType.DOCUMENT_INGEST,
                    "document",
                    "failure",
                    {
                        "source_preview": str(source)[:100],
                        "source_type": source_type,
                        "error": str(e),
                        "type": type(e).__name__,
                    },
                    resource_id=None,
                    engine_namespace="anon.engine.input_processor",
                    correlation_id=correlation_id,
                )
            if self._error_handler:
                try:
                    self._error_handler.handle_error(e, user_id, tenant_id, {"source_preview": str(source)[:50]})
                except Exception as handler_error:
                    logger.warning("Error handler failed: %s", handler_error)
            if isinstance(e, InputValidationError):
                logger.error("Input validation failed: %s", e)
            raise

    async def process_batch(
        self,
        sources: Iterable[Union[str, Path, bytes]],
        enable_image_processing: Optional[bool] = None,
        enable_audio_processing: Optional[bool] = None,
        batch_concurrency: Optional[int] = None,
        user_id: Optional[Any] = None,
        tenant_id: Optional[Any] = None,
        correlation_id: Optional[str] = None,
    ) -> List[StructuredDocument]:
        """
        Process multiple sources concurrently using an async worker queue.
        """
        source_list = list(sources)
        if not source_list:
            return []

        concurrency = batch_concurrency or self.config.pipeline.batch_concurrency
        concurrency = max(1, concurrency)

        queue: asyncio.Queue[Optional[Tuple[int, Union[str, Path, bytes]]]] = asyncio.Queue()
        for idx, src in enumerate(source_list):
            queue.put_nowait((idx, src))
        for _ in range(concurrency):
            queue.put_nowait(None)

        results: List[Optional[StructuredDocument]] = [None] * len(source_list)
        failures: List[Tuple[int, Exception]] = []

        async def _worker() -> None:
            while True:
                item = await queue.get()
                if item is None:
                    queue.task_done()
                    return
                idx, src = item
                try:
                    results[idx] = await self.process(
                        src,
                        enable_image_processing=enable_image_processing,
                        enable_audio_processing=enable_audio_processing,
                        user_id=user_id,
                        tenant_id=tenant_id,
                        correlation_id=correlation_id,
                    )
                except Exception as e:
                    failures.append((idx, e))
                finally:
                    queue.task_done()

        workers = [asyncio.create_task(_worker()) for _ in range(concurrency)]
        await queue.join()
        await asyncio.gather(*workers)

        if failures:
            first_idx, first_err = failures[0]
            raise RuntimeError(
                f"Batch processing failed for {len(failures)} source(s); first failure at index {first_idx}: {first_err}"
            ) from first_err

        return [doc for doc in results if doc is not None]

    async def _process_document_source(
        self,
        source: Union[str, Path, bytes],
        doc_id: str,
        source_metadata,
        source_type: str,
        start_time: datetime,
        errors: List[ProcessingError],
        enable_image_processing: Optional[bool] = None,
    ) -> StructuredDocument:
        """Process a document file (PDF, DOCX, etc.)."""
        content_blocks: List[ContentBlock] = []
        doc_metadata = {}

        if source_type == "file":
            blocks, extraction_errors, doc_metadata = await self._document_extractor.extract(str(source))
            content_blocks.extend(blocks)
            errors.extend(extraction_errors)
        elif source_type == "raw":
            from .types import BlockMetadata, ProvenanceInfo
            import uuid

            content_blocks.append(
                ContentBlock(
                    block_id=f"raw_{uuid.uuid4().hex[:8]}",
                    type="text",
                    content=str(source) if isinstance(source, str) else source.decode("utf-8", errors="replace"),
                    metadata=BlockMetadata(
                        provenance=ProvenanceInfo(extraction_method="raw_input"),
                    ),
                )
            )

        should_process_images = (
            enable_image_processing if enable_image_processing is not None else self.config.image_processing.enabled
        )
        if should_process_images and self._image_processor.is_enabled:
            content_blocks, image_errors = await self._enrich_images(
                content_blocks,
                max_workers=self.config.image_processing.max_image_workers,
            )
            errors.extend(image_errors)

        document = self._assembler.assemble(
            doc_id=doc_id,
            source_metadata=source_metadata,
            content_blocks=content_blocks,
            document_metadata=doc_metadata,
            errors=errors,
            processing_start_time=start_time,
        )
        logger.info("Pipeline complete: %d blocks", len(document.content_blocks))
        return document

    async def _process_audio_source(
        self,
        source: Union[str, Path],
        doc_id: str,
        source_metadata,
        start_time: datetime,
        errors: List[ProcessingError],
    ) -> StructuredDocument:
        """Process an audio file or YouTube URL."""
        transcript, audio_errors = await self._audio_processor.process_audio(str(source))
        errors.extend(audio_errors)
        content_blocks = self._audio_processor.create_transcript_blocks(
            transcript,
            source_info=str(source),
        )
        return self._assembler.assemble(
            doc_id=doc_id,
            source_metadata=source_metadata,
            content_blocks=content_blocks,
            errors=errors,
            processing_start_time=start_time,
        )

    async def _process_video_source(
        self,
        source: Union[str, Path],
        doc_id: str,
        source_metadata,
        start_time: datetime,
        errors: List[ProcessingError],
    ) -> StructuredDocument:
        """Process a video file."""
        transcript, video_errors = await self._audio_processor.process_video(str(source))
        errors.extend(video_errors)
        content_blocks = self._audio_processor.create_transcript_blocks(
            transcript,
            source_info=str(source),
        )
        return self._assembler.assemble(
            doc_id=doc_id,
            source_metadata=source_metadata,
            content_blocks=content_blocks,
            errors=errors,
            processing_start_time=start_time,
        )

    async def _enrich_images(
        self,
        blocks: List[ContentBlock],
        max_workers: int = 5,
    ) -> tuple[List[ContentBlock], List[ProcessingError]]:
        """
        Enrich image blocks with OCR and captioning concurrently.
        """
        enriched_blocks: List[ContentBlock] = list(blocks)
        all_errors: List[ProcessingError] = []
        image_indices = [i for i, block in enumerate(blocks) if block.type == "image"]
        if not image_indices:
            return enriched_blocks, all_errors

        logger.info(
            "Async enrichment starting for %d images with %d workers",
            len(image_indices),
            max_workers,
        )
        start_ts = time.time()
        semaphore = asyncio.Semaphore(max(1, max_workers))

        async def _enrich_single(index: int) -> None:
            async with semaphore:
                enriched_block, errs = await self._image_processor.enrich_content_block(blocks[index])
            enriched_blocks[index] = enriched_block
            all_errors.extend(errs)

        done = await asyncio.gather(
            *[asyncio.create_task(_enrich_single(idx)) for idx in image_indices],
            return_exceptions=True,
        )
        for item in done:
            if isinstance(item, Exception):
                all_errors.append(
                    ProcessingError(
                        component="ingestion_pipeline",
                        error_type=type(item).__name__,
                        message=f"Async image enrichment failed: {item}",
                    )
                )

        logger.info("Async enrichment completed in %.2fs", time.time() - start_ts)
        return enriched_blocks, all_errors

    async def process_audio(
        self,
        source: str,
        language: Optional[str] = None,
        user_id: Optional[Any] = None,
        tenant_id: Optional[Any] = None,
        correlation_id: Optional[str] = None,
    ) -> StructuredDocument:
        """
        Async API entrypoint for audio/video processing.
        """
        return await self.process(
            source, enable_audio_processing=True, user_id=user_id, tenant_id=tenant_id, correlation_id=correlation_id
        )

    async def process_document(
        self,
        file_path: Union[str, Path],
        enable_image_processing: bool = False,
    ) -> StructuredDocument:
        """
        Async API entrypoint for document processing.
        """
        return await self.process(file_path, enable_image_processing=enable_image_processing)


async def process(
    source: Union[str, Path, bytes],
    config: Optional[IngestionConfig] = None,
) -> StructuredDocument:
    """
    Async convenience function to process any source into a structured document.
    """
    pipeline = IngestionPipeline(config=config)
    return await pipeline.process(source)


async def process_audio(
    source: str,
    config: Optional[IngestionConfig] = None,
) -> StructuredDocument:
    """
    Async convenience function to process audio/video source.
    """
    pipeline = IngestionPipeline(config=config)
    return await pipeline.process_audio(source)


async def process_batch(
    sources: Iterable[Union[str, Path, bytes]],
    config: Optional[IngestionConfig] = None,
    batch_concurrency: Optional[int] = None,
) -> List[StructuredDocument]:
    """
    Async convenience function for concurrent batch ingestion.
    """
    pipeline = IngestionPipeline(config=config)
    return await pipeline.process_batch(sources, batch_concurrency=batch_concurrency)
