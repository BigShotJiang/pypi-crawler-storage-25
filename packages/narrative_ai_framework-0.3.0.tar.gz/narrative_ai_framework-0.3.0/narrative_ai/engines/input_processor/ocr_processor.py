"""
OCR adapter for the Enhanced Ingestion Pipeline.

Bridges input_processor with the shared OCR engine.
"""

import asyncio
import logging
from io import BytesIO
from pathlib import Path
from typing import Optional, Tuple, Union

from PIL import Image

from .config import IngestionConfig, get_config
from .types import OCRResult, ProcessingError
from ..ocr.core.api import ocr_async

logger = logging.getLogger(__name__)


def run_ocr(image: Union[str, Path, bytes, Image.Image]) -> str:
    """
    Synchronous wrapper around the core OCR API.

    Kept for backwards compatibility with existing tests that patch
    narrative_ai.engines.input_processor.ocr_processor.run_ocr.
    """
    # Normalize/convert is handled by OCRProcessor._normalize_image_input before calling this.
    return asyncio.run(ocr_async(image))


class OCRProcessor:
    """
    OCR adapter built on top of narrative_ai.engines.ocr core API.
    """

    def __init__(self, config: Optional[IngestionConfig] = None):
        self.config = config or get_config()
        self._ocr_config = self.config.image_processing.ocr
        self._provider_name = "ocr_pipeline"

    async def process(
        self,
        image: Union[str, Path, bytes, Image.Image],
    ) -> Tuple[Optional[OCRResult], Optional[ProcessingError]]:
        """
        Perform OCR on an image asynchronously.
        """
        if not self._ocr_config.enabled:
            return None, None

        try:
            normalized_input = await asyncio.to_thread(self._normalize_image_input, image)
            # Delegate to synchronous wrapper in a background thread to keep API compatible with tests.
            text = await asyncio.to_thread(run_ocr, normalized_input)
            text = text.strip()

            if text.startswith("Error:"):
                return None, ProcessingError(
                    component="ocr_processor",
                    error_type="OCRPipelineError",
                    message=text,
                    recoverable=True,
                    details={"provider": self._provider_name},
                )

            return OCRResult(
                ocr_text=text,
                ocr_model=self._provider_name,
                word_count=len(text.split()) if text else 0,
            ), None
        except Exception as e:
            logger.error("OCR processing failed: %s", e)
            return None, ProcessingError(
                component="ocr_processor",
                error_type=type(e).__name__,
                message=str(e),
                recoverable=True,
            )

    @staticmethod
    def _normalize_image_input(image: Union[str, Path, bytes, Image.Image]) -> Union[str, Path, bytes]:
        """
        Convert unsupported input types to formats accepted by OCRPipeline.
        """
        if isinstance(image, Image.Image):
            buffer = BytesIO()
            image.save(buffer, format="PNG")
            return buffer.getvalue()
        return image
