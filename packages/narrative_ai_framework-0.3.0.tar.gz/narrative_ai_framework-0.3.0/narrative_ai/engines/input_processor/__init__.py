"""
Enhanced Ingestion Pipeline for RAG Systems.
"""

from typing import Any
from .config import (
    IngestionConfig,
    get_config,
    load_config,
    reset_config,
)
from .types import (
    StructuredDocument,
    ContentBlock,
    ContentBlockType,
    SourceMetadata,
    SourceType,
    DocumentMetadata,
    BlockMetadata,
    PositionInfo,
    ProvenanceInfo,
    ProcessingError,
    ProcessingStatus,
    ImageData,
    OCRResult,
    CaptionResult,
    AudioTranscript,
    TranscriptSegment,
)
from .api import (
    process,
    process_batch,
    process_audio,
    process_document,
    InputClient,
)

def __getattr__(name: str) -> Any:
    """Implement lazy loading for heavy ingestion components."""
    if name == "IngestionPipeline":
        from .ingestion_pipeline import IngestionPipeline
        return IngestionPipeline
    if name == "OCRProcessor":
        from .ocr_processor import OCRProcessor
        return OCRProcessor
    if name == "STTProcessor":
        from .stt_processor import STTProcessor
        return STTProcessor
    if name == "VLMProcessor":
        from ..vlm import VLMProcessor
        return VLMProcessor
    if name == "ImageProcessor":
        from .image_processor import ImageProcessor
        return ImageProcessor
    if name == "AudioProcessor":
        from .audio_processor import AudioProcessor
        return AudioProcessor
    if name == "DocumentAssembler":
        from .assembler import DocumentAssembler
        return DocumentAssembler
    
    # Factory methods
    if name.startswith("create_"):
        from .factory import (
            create_pipeline,
            create_pipeline_from_config,
            create_pipeline_with_options,
            create_input_handler,
            create_document_extractor,
            create_image_processor,
            create_audio_processor,
            create_assembler,
        )
        factory_items = {
            "create_pipeline": create_pipeline,
            "create_pipeline_from_config": create_pipeline_from_config,
            "create_pipeline_with_options": create_pipeline_with_options,
            "create_input_handler": create_input_handler,
            "create_document_extractor": create_document_extractor,
            "create_image_processor": create_image_processor,
            "create_audio_processor": create_audio_processor,
            "create_assembler": create_assembler,
        }
        if name in factory_items:
            return factory_items[name]

    raise AttributeError(f"module {__name__} has no attribute {name}")

__version__ = "0.1.0"

__all__ = [
    "__version__",
    "IngestionPipeline",
    "process",
    "process_audio",
    "process_batch",
    "process_document",
    "InputClient",
    "IngestionConfig",
    "get_config",
    "load_config",
    "reset_config",
    "StructuredDocument",
    "ContentBlock",
    "ContentBlockType",
    "SourceMetadata",
    "SourceType",
    "DocumentMetadata",
    "BlockMetadata",
    "PositionInfo",
    "ProvenanceInfo",
    "ProcessingError",
    "ProcessingStatus",
    "ImageData",
    "OCRResult",
    "CaptionResult",
    "AudioTranscript",
    "TranscriptSegment",
    "OCRProcessor",
    "VLMProcessor",
    "STTProcessor",
    "create_pipeline",
    "create_pipeline_from_config",
    "create_pipeline_with_options",
    "create_input_handler",
    "create_document_extractor",
    "create_image_processor",
    "create_audio_processor",
    "create_assembler",
]
