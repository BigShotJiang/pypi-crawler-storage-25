"""
STT adapter for the Enhanced Ingestion Pipeline.

Bridges input_processor with the shared STT engine.
"""

import asyncio
import logging
from pathlib import Path
from typing import Optional, Tuple, Union, List

from .config import IngestionConfig, get_config
from .types import AudioTranscript, ProcessingError, TranscriptSegment
from ..stt import STTEngine, create_stt_engine_from_providers

logger = logging.getLogger(__name__)


class STTProcessor:
    """
    STT adapter built on top of narrative_ai.engines.stt.STTEngine.
    """

    def __init__(self, config: Optional[IngestionConfig] = None):
        self.config = config or get_config()
        self._stt_config = self.config.audio_processing.stt
        self._engine: Optional[STTEngine] = None
        self._engine_lock = asyncio.Lock()

    async def process(
        self,
        audio_path: Union[str, Path],
        language: Optional[str] = None,
    ) -> Tuple[Optional[AudioTranscript], Optional[ProcessingError]]:
        """
        Transcribe an audio file asynchronously.
        """
        audio_path = Path(audio_path)
        if not audio_path.exists():
            return None, ProcessingError(
                component="stt_processor",
                error_type="FileNotFoundError",
                message=f"Audio file not found: {audio_path}",
                recoverable=False,
            )

        try:
            engine = await self._get_engine()
        except Exception as e:
            logger.error("Failed to initialize STT engine: %s", e)
            return None, ProcessingError(
                component="stt_processor",
                error_type=type(e).__name__,
                message=str(e),
                recoverable=True,
            )

        try:
            audio_bytes = await asyncio.to_thread(audio_path.read_bytes)
            result = await engine.transcribe_file(
                audio_bytes,
                extract_emotion=False,
                language=language,
            )
            segments = self._map_segments(result.segments)
            transcript = AudioTranscript(
                transcript_id=f"{result.provider}_{audio_path.stem}",
                full_text=(result.text or "").strip(),
                segments=segments,
                language=result.language,
                stt_model=result.provider or self._stt_config.provider,
                has_diarization=False,
            )
            return transcript, None
        except Exception as e:
            logger.error("STT processing failed: %s", e)
            return None, ProcessingError(
                component="stt_processor",
                error_type=type(e).__name__,
                message=str(e),
                recoverable=True,
            )

    async def _get_engine(self) -> STTEngine:
        if self._engine is not None:
            return self._engine

        async with self._engine_lock:
            if self._engine is None:
                self._engine = await create_stt_engine_from_providers(auto_initialize=True)
                preferred_provider = (self._stt_config.provider or "").strip()
                if preferred_provider:
                    try:
                        self._engine.set_primary_provider(preferred_provider)
                    except Exception as e:
                        logger.warning(
                            "Could not set preferred STT provider '%s': %s",
                            preferred_provider,
                            e,
                        )
        return self._engine

    @staticmethod
    def _map_segments(raw_segments: Optional[List[dict]]) -> List[TranscriptSegment]:
        if not raw_segments:
            return []

        mapped: List[TranscriptSegment] = []
        for segment in raw_segments:
            mapped.append(
                TranscriptSegment(
                    text=(segment.get("text") or "").strip(),
                    start_time=segment.get("start_time", segment.get("start")),
                    end_time=segment.get("end_time", segment.get("end")),
                    confidence=segment.get("confidence"),
                    speaker=segment.get("speaker"),
                )
            )
        return mapped
