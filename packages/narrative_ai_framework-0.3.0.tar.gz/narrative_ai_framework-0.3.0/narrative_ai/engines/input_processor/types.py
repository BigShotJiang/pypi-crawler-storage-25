"""
Data models for the Enhanced Ingestion Pipeline.

Defines Pydantic models for structured documents, content blocks,
and all related metadata types. These models ensure type safety
and JSON serialization for RAG pipeline integration.
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Optional, List, Dict, Any, Union
from dataclasses import dataclass, field, asdict
import json


class ContentBlockType(str, Enum):
    """Types of content blocks in a structured document."""

    TEXT = "text"
    TABLE = "table"
    IMAGE = "image"
    AUDIO_TRANSCRIPT = "audio_transcript"
    HEADING = "heading"
    LIST = "list"
    CODE = "code"
    PAGE_BREAK = "page_break"
    UNKNOWN = "unknown"


class SourceType(str, Enum):
    """Types of input sources."""

    FILE = "file"
    URL = "url"
    YOUTUBE = "youtube"
    RAW_TEXT = "raw_text"
    STREAM = "stream"


class ProcessingStatus(str, Enum):
    """Processing status for blocks or documents."""

    SUCCESS = "success"
    PARTIAL = "partial"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class ProcessingError:
    """Represents an error that occurred during processing."""

    component: str
    error_type: str
    message: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat() + "Z")
    recoverable: bool = True
    details: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class SourceMetadata:
    """Metadata about the input source."""

    source_type: str
    source_path: Optional[str] = None
    source_url: Optional[str] = None
    file_name: Optional[str] = None
    file_size: Optional[int] = None
    mime_type: Optional[str] = None
    input_timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat() + "Z")
    encoding: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class PositionInfo:
    """Position/layout information for a content block."""

    page: Optional[int] = None
    page_width: Optional[float] = None
    page_height: Optional[float] = None
    # Bounding box coordinates (x1, y1, x2, y2)
    bbox: Optional[List[float]] = None
    # Sequential index in document
    sequence_index: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class ProvenanceInfo:
    """Provenance/origin information for a content block."""

    extraction_method: str = "unstructured"
    model_used: Optional[str] = None
    model_version: Optional[str] = None
    confidence: Optional[float] = None
    source_element_id: Optional[str] = None
    parent_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class OCRResult:
    """OCR extraction results for an image."""

    ocr_text: str
    ocr_confidence: Optional[float] = None
    ocr_model: str = "tesseract"
    ocr_model_version: Optional[str] = None
    language_detected: Optional[str] = None
    word_count: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class CaptionResult:
    """Image captioning results."""

    caption: str
    caption_confidence: Optional[float] = None
    caption_model: str = "qwen2-vl:2b"
    caption_model_version: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class ImageData:
    """Complete image data including OCR and captioning results."""

    image_id: str
    # Image binary data (base64 encoded) or path
    image_data: Optional[str] = None
    image_path: Optional[str] = None
    image_format: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None
    # OCR results
    ocr: Optional[OCRResult] = None
    # Captioning results
    caption: Optional[CaptionResult] = None
    # Processing status
    status: str = "success"
    errors: List[ProcessingError] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "image_id": self.image_id,
            "status": self.status,
        }
        if self.image_data:
            result["image_data"] = self.image_data
        if self.image_path:
            result["image_path"] = self.image_path
        if self.image_format:
            result["image_format"] = self.image_format
        if self.width:
            result["width"] = self.width
        if self.height:
            result["height"] = self.height
        if self.ocr:
            result["ocr"] = self.ocr.to_dict()
        if self.caption:
            result["caption"] = self.caption.to_dict()
        if self.errors:
            result["errors"] = [e.to_dict() for e in self.errors]
        return result


@dataclass
class TranscriptSegment:
    """A segment of an audio transcript."""

    text: str
    start_time: Optional[float] = None  # seconds
    end_time: Optional[float] = None  # seconds
    speaker: Optional[str] = None
    confidence: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class AudioTranscript:
    """Complete audio transcript with segments."""

    transcript_id: str
    full_text: str
    segments: List[TranscriptSegment] = field(default_factory=list)
    duration: Optional[float] = None  # total duration in seconds
    language: Optional[str] = None
    stt_model: str = "elevenlabs"
    stt_model_version: Optional[str] = None
    has_diarization: bool = False
    status: str = "success"
    errors: List[ProcessingError] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "transcript_id": self.transcript_id,
            "full_text": self.full_text,
            "stt_model": self.stt_model,
            "has_diarization": self.has_diarization,
            "status": self.status,
        }
        if self.segments:
            result["segments"] = [s.to_dict() for s in self.segments]
        if self.duration is not None:
            result["duration"] = self.duration
        if self.language:
            result["language"] = self.language
        if self.stt_model_version:
            result["stt_model_version"] = self.stt_model_version
        if self.errors:
            result["errors"] = [e.to_dict() for e in self.errors]
        return result


@dataclass
class BlockMetadata:
    """Metadata for a content block."""

    position: Optional[PositionInfo] = None
    provenance: Optional[ProvenanceInfo] = None
    # Original element type from Unstructured
    element_type: Optional[str] = None
    # Additional custom metadata
    extra: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {}
        if self.position:
            result["position"] = self.position.to_dict()
        if self.provenance:
            result["provenance"] = self.provenance.to_dict()
        if self.element_type:
            result["element_type"] = self.element_type
        if self.extra:
            result["extra"] = self.extra
        return result


@dataclass
class ContentBlock:
    """
    A single content block in a structured document.

    Content blocks are the atomic units of extracted content,
    each with a type, content, and associated metadata.
    """

    block_id: str
    type: str  # ContentBlockType value
    content: Union[str, Dict[str, Any], List[Any], ImageData, AudioTranscript]
    metadata: BlockMetadata = field(default_factory=BlockMetadata)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        result = {
            "block_id": self.block_id,
            "type": self.type,
        }

        # Handle different content types
        if isinstance(self.content, (ImageData, AudioTranscript)):
            result["content"] = self.content.to_dict()
        elif isinstance(self.content, dict):
            result["content"] = self.content
        elif isinstance(self.content, list):
            result["content"] = self.content
        else:
            result["content"] = str(self.content)

        result["metadata"] = self.metadata.to_dict()
        return result


@dataclass
class DocumentMetadata:
    """Top-level metadata for a structured document."""

    source: SourceMetadata
    pipeline_version: str = "1.0.0"
    processing_timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat() + "Z")
    processing_duration_ms: Optional[int] = None
    total_blocks: int = 0
    total_pages: Optional[int] = None
    # Document-level properties (from source document)
    title: Optional[str] = None
    author: Optional[str] = None
    creation_date: Optional[str] = None
    language: Optional[str] = None
    # Processing info
    errors: List[ProcessingError] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = {
            "source": self.source.to_dict(),
            "pipeline_version": self.pipeline_version,
            "processing_timestamp": self.processing_timestamp,
            "total_blocks": self.total_blocks,
        }
        if self.processing_duration_ms is not None:
            result["processing_duration_ms"] = self.processing_duration_ms
        if self.total_pages is not None:
            result["total_pages"] = self.total_pages
        if self.title:
            result["title"] = self.title
        if self.author:
            result["author"] = self.author
        if self.creation_date:
            result["creation_date"] = self.creation_date
        if self.language:
            result["language"] = self.language
        if self.errors:
            result["errors"] = [e.to_dict() for e in self.errors]
        if self.warnings:
            result["warnings"] = self.warnings
        return result


@dataclass
class StructuredDocument:
    """
    The main output of the ingestion pipeline.

    A structured document contains all extracted content organized
    into blocks, with comprehensive metadata for RAG processing.
    """

    doc_id: str
    metadata: DocumentMetadata
    content_blocks: List[ContentBlock] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "doc_id": self.doc_id,
            "metadata": self.metadata.to_dict(),
            "content_blocks": [block.to_dict() for block in self.content_blocks],
        }

    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StructuredDocument":
        """Create a StructuredDocument from a dictionary."""
        # This is a simplified loader - expand as needed
        doc_id = data["doc_id"]

        # Parse source metadata
        source_data = data["metadata"]["source"]
        source = SourceMetadata(**source_data)

        # Parse document metadata
        meta_data = data["metadata"]
        errors = [ProcessingError(**e) for e in meta_data.get("errors", [])]

        metadata = DocumentMetadata(
            source=source,
            pipeline_version=meta_data.get("pipeline_version", "1.0.0"),
            processing_timestamp=meta_data.get("processing_timestamp", ""),
            processing_duration_ms=meta_data.get("processing_duration_ms"),
            total_blocks=meta_data.get("total_blocks", 0),
            total_pages=meta_data.get("total_pages"),
            title=meta_data.get("title"),
            author=meta_data.get("author"),
            creation_date=meta_data.get("creation_date"),
            language=meta_data.get("language"),
            errors=errors,
            warnings=meta_data.get("warnings", []),
        )

        # Parse content blocks (simplified)
        content_blocks = []
        for block_data in data.get("content_blocks", []):
            block = ContentBlock(
                block_id=block_data["block_id"],
                type=block_data["type"],
                content=block_data["content"],
                metadata=BlockMetadata(),  # Simplified
            )
            content_blocks.append(block)

        return cls(doc_id=doc_id, metadata=metadata, content_blocks=content_blocks)

    def add_block(self, block: ContentBlock) -> None:
        """Add a content block to the document."""
        self.content_blocks.append(block)
        self.metadata.total_blocks = len(self.content_blocks)

    def add_error(self, error: ProcessingError) -> None:
        """Add a processing error to the document metadata."""
        self.metadata.errors.append(error)

    def get_text_content(self) -> str:
        """Get all text content concatenated."""
        texts = []
        for block in self.content_blocks:
            if block.type == ContentBlockType.TEXT.value:
                texts.append(str(block.content))
            elif block.type == ContentBlockType.HEADING.value:
                texts.append(str(block.content))
        return "\n\n".join(texts)

    def get_blocks_by_type(self, block_type: str) -> List[ContentBlock]:
        """Get all blocks of a specific type."""
        return [b for b in self.content_blocks if b.type == block_type]
