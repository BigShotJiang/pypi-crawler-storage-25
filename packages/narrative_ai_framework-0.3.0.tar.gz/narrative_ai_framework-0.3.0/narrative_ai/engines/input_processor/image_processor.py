"""
Image Processor for the Enhanced Ingestion Pipeline.

Orchestrates image enrichment including OCR and captioning.
Handles failure cascading and partial result preservation.
"""

import asyncio
import logging
import uuid
from pathlib import Path
from typing import List, Optional, Tuple, Union

from PIL import Image

from .config import get_config, IngestionConfig
from .types import (
    ContentBlock,
    ContentBlockType,
    BlockMetadata,
    PositionInfo,
    ProvenanceInfo,
    ProcessingError,
    ImageData,
)
from .ocr_processor import OCRProcessor
from ..vlm import VLMProcessor

logger = logging.getLogger(__name__)


class ImageProcessor:
    """
    Async image enrichment processor.

    Orchestrates OCR and VLM captioning for images extracted from documents.
    Handles partial failures gracefully, preserving whatever data is available.
    """

    def __init__(self, config: Optional[IngestionConfig] = None):
        self.config = config or get_config()
        self._image_config = self.config.image_processing

        self._ocr = OCRProcessor(config)
        self._vlm = VLMProcessor(config)

    @property
    def is_enabled(self) -> bool:
        """Check if image processing is enabled."""
        return self._image_config.enabled

    async def process_image(
        self,
        image: Union[str, Path, bytes, Image.Image],
        image_id: Optional[str] = None,
        position: Optional[PositionInfo] = None,
        run_ocr: Optional[bool] = None,
        run_captioning: Optional[bool] = None,
    ) -> Tuple[ImageData, List[ProcessingError]]:
        """
        Process a single image with OCR and captioning concurrently.
        """
        errors: List[ProcessingError] = []

        if image_id is None:
            image_id = f"img_{uuid.uuid4().hex[:12]}"

        result = ImageData(
            image_id=image_id,
            status="success",
        )

        try:
            pil_image = await asyncio.to_thread(self._load_image, image)
            result.width = pil_image.width
            result.height = pil_image.height
            result.image_format = pil_image.format
        except Exception as e:
            logger.warning("Could not load image metadata: %s", e)

        if isinstance(image, (str, Path)):
            result.image_path = str(image)

        should_ocr = run_ocr if run_ocr is not None else self._image_config.ocr.enabled
        should_caption = run_captioning if run_captioning is not None else self._image_config.captioning.enabled

        async def _run_ocr():
            if not should_ocr:
                return None, None
            return await self._ocr.process(image)

        async def _run_caption():
            if not should_caption:
                return None, None
            return await self._vlm.process(image)

        ocr_task, cap_task = await asyncio.gather(
            _run_ocr(),
            _run_caption(),
            return_exceptions=True,
        )

        if isinstance(ocr_task, Exception):
            errors.append(
                ProcessingError(
                    component="image_processor",
                    error_type=type(ocr_task).__name__,
                    message=str(ocr_task),
                    recoverable=True,
                )
            )
        else:
            ocr_result, ocr_error = ocr_task
            if ocr_result:
                result.ocr = ocr_result
            if ocr_error:
                errors.append(ocr_error)

        if isinstance(cap_task, Exception):
            errors.append(
                ProcessingError(
                    component="image_processor",
                    error_type=type(cap_task).__name__,
                    message=str(cap_task),
                    recoverable=True,
                )
            )
        else:
            caption_result, caption_error = cap_task
            if caption_result:
                result.caption = caption_result
            if caption_error:
                errors.append(caption_error)

        if errors:
            result.status = "partial" if (result.ocr or result.caption) else "failed"
            result.errors = errors

        return result, errors

    async def process_images(
        self,
        images: List[Union[str, Path, bytes, Image.Image]],
        position_infos: Optional[List[PositionInfo]] = None,
        max_workers: Optional[int] = None,
    ) -> Tuple[List[ImageData], List[ProcessingError]]:
        """
        Process multiple images concurrently with bounded worker count.
        """
        worker_count = max_workers or self._image_config.max_image_workers
        worker_count = max(1, worker_count)

        all_results: List[Optional[ImageData]] = [None] * len(images)
        all_errors: List[ProcessingError] = []
        semaphore = asyncio.Semaphore(worker_count)

        async def _process_single(index: int) -> None:
            image = images[index]
            position = position_infos[index] if position_infos and index < len(position_infos) else None
            image_id = f"img_{index}_{uuid.uuid4().hex[:8]}"

            async with semaphore:
                result, errors = await self.process_image(
                    image=image,
                    image_id=image_id,
                    position=position,
                )
            all_results[index] = result
            all_errors.extend(errors)

        tasks = [asyncio.create_task(_process_single(i)) for i in range(len(images))]
        done = await asyncio.gather(*tasks, return_exceptions=True)
        for item in done:
            if isinstance(item, Exception):
                all_errors.append(
                    ProcessingError(
                        component="image_processor",
                        error_type=type(item).__name__,
                        message=f"Parallel processing failed: {item}",
                    )
                )

        valid_results = [r for r in all_results if r is not None]
        return valid_results, all_errors

    async def enrich_content_block(
        self,
        block: ContentBlock,
    ) -> Tuple[ContentBlock, List[ProcessingError]]:
        """
        Enrich an image content block with OCR and captioning.
        """
        if block.type != ContentBlockType.IMAGE.value:
            return block, []

        image_path = None
        if isinstance(block.content, dict):
            image_path = block.content.get("image_path")
        elif isinstance(block.content, ImageData):
            image_path = block.content.image_path

        if not image_path or not Path(image_path).exists():
            return block, [
                ProcessingError(
                    component="image_processor",
                    error_type="ImageNotFound",
                    message=f"Image path not found or invalid: {image_path}",
                    recoverable=True,
                )
            ]

        result, process_errors = await self.process_image(
            image=image_path,
            image_id=block.block_id,
            position=block.metadata.position,
        )

        block.content = result
        if block.metadata.provenance is None:
            block.metadata.provenance = ProvenanceInfo()
        block.metadata.provenance.model_used = "image_processor"

        return block, process_errors

    async def create_image_block(
        self,
        image: Union[str, Path, bytes, Image.Image],
        sequence_index: int,
        source_page: Optional[int] = None,
    ) -> Tuple[ContentBlock, List[ProcessingError]]:
        """
        Create a complete image content block with enrichment.
        """
        block_id = f"img_block_{sequence_index}_{uuid.uuid4().hex[:8]}"
        position = PositionInfo(
            sequence_index=sequence_index,
            page=source_page,
        )

        image_data, errors = await self.process_image(
            image=image,
            image_id=block_id,
            position=position,
        )

        metadata = BlockMetadata(
            position=position,
            provenance=ProvenanceInfo(extraction_method="image_processor"),
            element_type="Image",
        )

        block = ContentBlock(
            block_id=block_id,
            type=ContentBlockType.IMAGE.value,
            content=image_data,
            metadata=metadata,
        )
        return block, errors

    def _load_image(self, image: Union[str, Path, bytes, Image.Image]) -> Image.Image:
        """Load image from various sources."""
        if isinstance(image, Image.Image):
            return image
        if isinstance(image, bytes):
            from io import BytesIO

            return Image.open(BytesIO(image))
        return Image.open(str(image))


async def process_image(
    image: Union[str, Path, bytes],
    config: Optional[IngestionConfig] = None,
) -> ImageData:
    """
    Convenience function to process a single image.
    """
    processor = ImageProcessor(config)
    result, _ = await processor.process_image(image)
    return result
