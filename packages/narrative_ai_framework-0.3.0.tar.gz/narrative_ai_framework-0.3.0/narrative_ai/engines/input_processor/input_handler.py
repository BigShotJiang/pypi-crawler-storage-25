"""
Input Handler for the Enhanced Ingestion Pipeline.

Handles input validation, doc_id generation, and source metadata extraction.
Supports files, URLs, YouTube links, and raw content.
"""

import asyncio
import hashlib
import logging
import mimetypes
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple, Union
from urllib.parse import urlparse

from .config import get_config, IngestionConfig
from .types import (
    SourceMetadata,
)

# Optional security input validation (Layer 4)
try:
    from narrative_ai.security.input_validation import (
        validate_text as _security_validate_text,
        validate_audio as _security_validate_audio,
        ValidationError as SecurityValidationError,
    )

    _SECURITY_VALIDATION_AVAILABLE = True
except ImportError:
    _security_validate_text = None
    _security_validate_audio = None
    SecurityValidationError = Exception
    _SECURITY_VALIDATION_AVAILABLE = False

logger = logging.getLogger(__name__)

# YouTube URL patterns
YOUTUBE_PATTERNS = [
    r"(?:https?://)?(?:www\.)?youtube\.com/watch\?v=([a-zA-Z0-9_-]{11})",
    r"(?:https?://)?(?:www\.)?youtu\.be/([a-zA-Z0-9_-]{11})",
    r"(?:https?://)?(?:www\.)?youtube\.com/embed/([a-zA-Z0-9_-]{11})",
    r"(?:https?://)?(?:www\.)?youtube\.com/v/([a-zA-Z0-9_-]{11})",
]

# Audio file extensions
AUDIO_EXTENSIONS = {".mp3", ".wav", ".m4a", ".flac", ".ogg", ".aac", ".wma", ".opus"}

# Video file extensions
VIDEO_EXTENSIONS = {".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm"}


class InputValidationError(Exception):
    """Raised when input validation fails."""

    pass


class InputHandler:
    """
    Handles input processing for the ingestion pipeline.

    Responsibilities:
    - Validate input sources (files, URLs, raw content)
    - Generate stable, unique document IDs
    - Extract source metadata
    - Detect input type and route appropriately
    """

    def __init__(self, config: Optional[IngestionConfig] = None):
        """
        Initialize the input handler.

        Args:
            config: Optional configuration. Uses global config if not provided.
        """
        self.config = config or get_config()
        self._input_config = self.config.input

    async def process_input(
        self,
        source: Union[str, Path, bytes],
        source_hint: Optional[str] = None,
    ) -> Tuple[str, SourceMetadata, str]:
        """
        Process and validate an input source.

        Args:
            source: The input source - can be a file path, URL, or raw bytes.
            source_hint: Optional hint about the source type.

        Returns:
            Tuple of (doc_id, source_metadata, detected_type)
            detected_type is one of: "file", "url", "youtube", "audio", "video", "raw"

        Raises:
            InputValidationError: If the input is invalid.
        """
        logger.info(f"Processing input: {type(source).__name__}")

        # Detect source type
        source_type, resolved_source = self._detect_source_type(source, source_hint)

        # Validate the input
        self._validate_input(resolved_source, source_type)

        # Generate doc_id
        doc_id = await self._generate_doc_id(resolved_source, source_type)

        # Extract metadata
        metadata = await self._extract_metadata(resolved_source, source_type)

        logger.info(f"Input processed: doc_id={doc_id}, type={source_type}")

        return doc_id, metadata, source_type

    def _detect_source_type(
        self,
        source: Union[str, Path, bytes],
        hint: Optional[str] = None,
    ) -> Tuple[str, Union[str, Path, bytes]]:
        """
        Detect the type of input source.

        Returns:
            Tuple of (source_type, resolved_source)
        """
        # If hint is provided, trust it
        if hint:
            return hint, source

        # Handle bytes
        if isinstance(source, bytes):
            return "raw", source

        # Convert Path to string
        if isinstance(source, Path):
            source = str(source)

        # Check for YouTube URL
        if self._is_youtube_url(source):
            return "youtube", source

        # Check for general URL
        if self._is_url(source):
            return "url", source

        # Check for file path
        if os.path.exists(source):
            path = Path(source)
            ext = path.suffix.lower()

            if ext in AUDIO_EXTENSIONS:
                return "audio", source
            elif ext in VIDEO_EXTENSIONS:
                return "video", source
            else:
                return "file", source

        # If it looks like a path but doesn't exist
        if "/" in source or "\\" in source or source.endswith(tuple([".pdf", ".docx", ".txt"])):
            raise InputValidationError(f"File not found: {source}")

        # Treat as raw text
        return "raw", source

    def _is_youtube_url(self, source: str) -> bool:
        """Check if the source is a YouTube URL."""
        for pattern in YOUTUBE_PATTERNS:
            if re.match(pattern, source):
                return True
        return False

    def _is_url(self, source: str) -> bool:
        """Check if the source is a URL."""
        try:
            result = urlparse(source)
            return all([result.scheme in ("http", "https"), result.netloc])
        except Exception:
            return False

    def _validate_input(
        self,
        source: Union[str, Path, bytes],
        source_type: str,
    ) -> None:
        """
        Validate the input source.

        Raises:
            InputValidationError: If validation fails.
        """
        if source_type == "file":
            self._validate_file(source)
        elif source_type in ("audio", "video"):
            self._validate_file(source)
            # Optional: security layer audio validation (audio sources only; video formats differ)
            if (
                source_type == "audio"
                and _SECURITY_VALIDATION_AVAILABLE
                and getattr(self.config.integration, "enable_input_validation", False)
            ):
                path = Path(source)
                with open(path, "rb") as f:
                    audio_bytes = f.read()
                try:
                    _security_validate_audio(
                        audio_bytes,
                        min_size=1,
                        max_size=self._input_config.max_file_size,
                    )
                except Exception as e:
                    raise InputValidationError(str(e)) from e
        elif source_type == "url":
            self._validate_url(source)
        elif source_type == "youtube":
            self._validate_youtube_url(source)
        elif source_type == "raw":
            self._validate_raw(source)

    def _validate_file(self, file_path: Union[str, Path]) -> None:
        """Validate a file input."""
        path = Path(file_path)

        if not path.exists():
            raise InputValidationError(f"File not found: {file_path}")

        if not path.is_file():
            raise InputValidationError(f"Path is not a file: {file_path}")

        # Check file size
        file_size = path.stat().st_size
        if file_size > self._input_config.max_file_size:
            raise InputValidationError(
                f"File too large: {file_size} bytes (max: {self._input_config.max_file_size} bytes)"
            )

        if file_size == 0:
            raise InputValidationError(f"File is empty: {file_path}")

        # Check extension if restrictions are configured
        if self._input_config.allowed_extensions:
            ext = path.suffix.lower().lstrip(".")
            if ext not in self._input_config.allowed_extensions:
                raise InputValidationError(
                    f"File extension not allowed: {ext}. Allowed: {self._input_config.allowed_extensions}"
                )

    def _validate_url(self, url: str) -> None:
        """Validate a URL input."""
        try:
            result = urlparse(url)
            if not all([result.scheme, result.netloc]):
                raise InputValidationError(f"Invalid URL: {url}")
        except Exception as e:
            raise InputValidationError(f"Failed to parse URL: {url} - {e}")

    def _validate_youtube_url(self, url: str) -> None:
        """Validate a YouTube URL."""
        video_id = self._extract_youtube_id(url)
        if not video_id:
            raise InputValidationError(f"Invalid YouTube URL: {url}")

    def _validate_raw(self, content: Union[str, bytes]) -> None:
        """Validate raw content input."""
        if isinstance(content, str) and len(content.strip()) == 0:
            raise InputValidationError("Raw content is empty")
        if isinstance(content, bytes) and len(content) == 0:
            raise InputValidationError("Raw bytes content is empty")
        # Optional: security layer text validation (when enabled)
        if (
            isinstance(content, str)
            and _SECURITY_VALIDATION_AVAILABLE
            and getattr(self.config.integration, "enable_input_validation", False)
        ):
            try:
                _security_validate_text(content)
            except Exception as e:
                raise InputValidationError(str(e)) from e

    def _extract_youtube_id(self, url: str) -> Optional[str]:
        """Extract video ID from a YouTube URL."""
        for pattern in YOUTUBE_PATTERNS:
            match = re.match(pattern, url)
            if match:
                return match.group(1)
        return None

    async def _generate_doc_id(
        self,
        source: Union[str, Path, bytes],
        source_type: str,
    ) -> str:
        """
        Generate a stable, unique document ID.

        Uses SHA-256 hash of the content or source identifier.
        """
        hash_algo = self._input_config.hash_algorithm

        if hash_algo == "sha256":
            hasher = hashlib.sha256()
        else:
            # For compatibility, allow config values like "sha1"/"md5" but normalize
            # them to SHA-256 so we avoid insecure hashes.
            if hash_algo in {"sha1", "md5"}:
                logger.warning("Deprecated hash_algorithm '%s'; using sha256 instead", hash_algo)
            hasher = hashlib.sha256()

        if source_type in ("file", "audio", "video"):
            path = Path(source)
            await asyncio.to_thread(self._hash_file_chunks, path, hasher)
        elif source_type == "youtube":
            # Use video ID for YouTube
            video_id = self._extract_youtube_id(str(source))
            hasher.update(f"youtube:{video_id}".encode("utf-8"))
        elif source_type == "url":
            # Hash the URL itself
            hasher.update(str(source).encode("utf-8"))
        elif source_type == "raw":
            # Hash the content
            if isinstance(source, bytes):
                hasher.update(source)
            else:
                hasher.update(str(source).encode("utf-8"))

        return hasher.hexdigest()

    def _hash_file_chunks(self, path: Path, hasher) -> None:
        """Hash file content in fixed-size chunks."""
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hasher.update(chunk)

    async def _extract_metadata(
        self,
        source: Union[str, Path, bytes],
        source_type: str,
    ) -> SourceMetadata:
        """Extract metadata from the input source."""
        timestamp = datetime.utcnow().isoformat() + "Z"

        if source_type in ("file", "audio", "video"):
            path = Path(source)
            file_stat = await asyncio.to_thread(path.stat)
            mime_type, _ = mimetypes.guess_type(str(path))

            return SourceMetadata(
                source_type=source_type,
                source_path=str(path.absolute()),
                file_name=path.name,
                file_size=file_stat.st_size,
                mime_type=mime_type,
                input_timestamp=timestamp,
            )

        elif source_type == "youtube":
            video_id = self._extract_youtube_id(str(source))
            return SourceMetadata(
                source_type="youtube",
                source_url=str(source),
                file_name=f"youtube_{video_id}",
                input_timestamp=timestamp,
            )

        elif source_type == "url":
            parsed = urlparse(str(source))
            file_name = os.path.basename(parsed.path) or "webpage"

            return SourceMetadata(
                source_type="url",
                source_url=str(source),
                file_name=file_name,
                input_timestamp=timestamp,
            )

        else:  # raw
            content_size = len(source) if isinstance(source, bytes) else len(str(source).encode("utf-8"))
            return SourceMetadata(
                source_type="raw_text",
                file_size=content_size,
                input_timestamp=timestamp,
            )

    def get_youtube_video_id(self, url: str) -> Optional[str]:
        """
        Public method to extract YouTube video ID.

        Args:
            url: The YouTube URL.

        Returns:
            Video ID or None if not a valid YouTube URL.
        """
        return self._extract_youtube_id(url)

    def is_audio_source(self, source: str) -> bool:
        """Check if the source is an audio file or YouTube URL."""
        if self._is_youtube_url(source):
            return True
        if os.path.exists(source):
            return Path(source).suffix.lower() in AUDIO_EXTENSIONS
        return False

    def is_video_source(self, source: str) -> bool:
        """Check if the source is a video file or YouTube URL."""
        if self._is_youtube_url(source):
            return True
        if os.path.exists(source):
            return Path(source).suffix.lower() in VIDEO_EXTENSIONS
        return False
