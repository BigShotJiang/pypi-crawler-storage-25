import asyncio
from typing import Union, Optional, List, Any
from pathlib import Path
# Lazy loading to avoid heavy imports
# from narrative_ai.engines.input_processor.ingestion_pipeline import IngestionPipeline
from narrative_ai.engines.input_processor.types import StructuredDocument

_default_pipeline: Optional["IngestionPipeline"] = None

def _get_pipeline() -> "IngestionPipeline":
    global _default_pipeline
    if _default_pipeline is None:
        from narrative_ai.engines.input_processor.ingestion_pipeline import IngestionPipeline
        _default_pipeline = IngestionPipeline()
    return _default_pipeline

async def process(
    source: Union[str, Path, bytes],
    enable_image_processing: Optional[bool] = None,
    enable_audio_processing: Optional[bool] = None,
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> StructuredDocument:
    """
    Process any input source (file path, URL, or bytes) into a StructuredDocument.
    Automatically handles PDF, Images, Audio, and Web Links.
    """
    pipeline = _get_pipeline()
    return await pipeline.process(
        source, 
        enable_image_processing=enable_image_processing,
        enable_audio_processing=enable_audio_processing,
        user_id=user_id,
        tenant_id=tenant_id,
        correlation_id=correlation_id,
        **kwargs
    )

async def process_batch(
    sources: List[Union[str, Path, bytes]],
    enable_image_processing: Optional[bool] = None,
    enable_audio_processing: Optional[bool] = None,
    batch_concurrency: Optional[int] = None,
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> List[StructuredDocument]:
    """Process multiple sources in parallel."""
    pipeline = _get_pipeline()
    return await pipeline.process_batch(
        sources,
        enable_image_processing=enable_image_processing,
        enable_audio_processing=enable_audio_processing,
        batch_concurrency=batch_concurrency,
        user_id=user_id,
        tenant_id=tenant_id,
        correlation_id=correlation_id,
        **kwargs
    )

async def process_audio(
    source: str,
    language: Optional[str] = None,
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> StructuredDocument:
    """Specialized function for audio/video source processing."""
    pipeline = _get_pipeline()
    return await pipeline.process_audio(
        source,
        language=language,
        user_id=user_id,
        tenant_id=tenant_id,
        correlation_id=correlation_id,
        **kwargs
    )

async def process_document(
    file_path: Union[str, Path],
    enable_image_processing: bool = False,
    **kwargs
) -> StructuredDocument:
    """Specialized function for document (PDF/Docx) processing."""
    pipeline = _get_pipeline()
    # Note: engine's process_document uses file_path/enable_image_processing
    # We pass through user_id/tenant_id via kwargs if the engine process supports it
    return await pipeline.process_document(
        file_path, 
        enable_image_processing=enable_image_processing,
        **kwargs
    )

class InputClient:
    """
    A session-based client for the InputProcessor engine.
    Stores common parameters like user_id, tenant_id, and processing preferences
    to simplify repetitive ingestion tasks.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        enable_image_processing: Optional[bool] = None,
        enable_audio_processing: Optional[bool] = None,
        correlation_id: Optional[str] = None,
    ):
        """
        Initialize the Input client with default context.
        
        Args:
            user_id: Default user ID for all requests
            tenant_id: Default tenant ID for all requests
            enable_image_processing: Default preference for image OCR
            enable_audio_processing: Default preference for audio transcription
            correlation_id: Default correlation ID prefix or value
        """
        self.defaults = {
            "user_id": user_id,
            "tenant_id": tenant_id,
            "enable_image_processing": enable_image_processing,
            "enable_audio_processing": enable_audio_processing,
            "correlation_id": correlation_id,
        }

    async def process(self, source: Union[str, Path, bytes], **kwargs) -> StructuredDocument:
        """
        Process an input source using client defaults.
        Specific arguments passed here will override client defaults.
        """
        final_args = {**self.defaults, "source": source, **kwargs}
        return await process(**final_args)

    async def process_batch(
        self, 
        sources: List[Union[str, Path, bytes]], 
        **kwargs
    ) -> List[StructuredDocument]:
        """
        Process multiple sources using client defaults.
        Specific arguments passed here will override client defaults.
        """
        final_args = {**self.defaults, "sources": sources, **kwargs}
        return await process_batch(**final_args)

    async def process_audio(self, source: str, **kwargs) -> StructuredDocument:
        """Specialized audio processing using client defaults."""
        final_args = {**self.defaults, "source": source, **kwargs}
        # Filter out enable_image_processing as it's not applicable to process_audio signature
        final_args.pop("enable_image_processing", None)
        final_args.pop("enable_audio_processing", None)
        return await process_audio(**final_args)

    async def process_document(self, file_path: Union[str, Path], **kwargs) -> StructuredDocument:
        """Specialized document processing using client defaults."""
        final_args = {**self.defaults, "file_path": file_path, **kwargs}
        # Filter toggle as it is a positional/named arg in engine
        enable_img = final_args.pop("enable_image_processing", False)
        # Remove security context as process_document doesn't support them
        final_args.pop("user_id", None)
        final_args.pop("tenant_id", None)
        final_args.pop("correlation_id", None)
        final_args.pop("enable_audio_processing", None)
        return await process_document(file_path=file_path, enable_image_processing=enable_img, **final_args)
