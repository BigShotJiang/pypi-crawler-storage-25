"""
Configuration loader for the Enhanced Ingestion Pipeline.

Loads configuration from YAML file with environment variable interpolation
and validation. Provides a singleton-pattern access to pipeline configuration.
"""

import os
import re
import logging
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, Union, Callable

import yaml

logger = logging.getLogger(__name__)

# Load .env file automatically if it exists
try:
    from dotenv import load_dotenv

    # Look for .env in current and parent directories (up to 4 levels)
    # The config file is usually in framework/engines/input_processor/
    # Project root is likely framework/ or the parent of framework/
    found_env = False
    current_dir = Path(__file__).resolve().parent
    for _ in range(5):
        _env_path = current_dir / ".env"
        if _env_path.exists():
            load_dotenv(_env_path)
            # Use a print as loggers might not be fully configured yet
            print(f"DEBUG: Loaded environment variables from {_env_path}")
            found_env = True
            break
        if current_dir.parent == current_dir:
            break
        current_dir = current_dir.parent

    if not found_env:
        print("DEBUG: No .env file found in search path.")
except ImportError:
    pass

# Path to default config file
DEFAULT_CONFIG_PATH = Path(__file__).parent / "ingestion_config.yaml"


@dataclass
class OCRConfig:
    """OCR processing configuration."""

    enabled: bool = True
    provider: str = "tesseract"
    tesseract_lang: str = "eng"
    tesseract_config: str = "--psm 3"
    api_key_env: str = "GOOGLE_VISION_API_KEY"
    api_endpoint: str = ""


@dataclass
class CaptioningConfig:
    """Image captioning configuration."""

    enabled: bool = True
    provider: str = "ollama"
    ollama_model: str = "qwen2-vl:2b"
    ollama_host: str = "http://localhost:11434"
    ollama_timeout: int = 30
    ollama_cloud_model: str = "qwen-3vl"
    ollama_cloud_base_url: str = "https://ollama.com"
    ollama_cloud_api_key_env: str = "OLLAMA_CLOUD_API_KEY"
    ollama_cloud_timeout: int = 300
    api_key_env: str = "OPENAI_API_KEY"
    api_model: str = "gpt-4-vision-preview"
    api_max_tokens: int = 300
    google_model: str = "gemini-2.5-flash"


@dataclass
class ImageProcessingConfig:
    """Image processing configuration."""

    enabled: bool = False
    mode: str = "local"  # "api" or "local"
    max_image_workers: int = 5
    ocr: OCRConfig = field(default_factory=OCRConfig)
    captioning: CaptioningConfig = field(default_factory=CaptioningConfig)


@dataclass
class YouTubeConfig:
    """YouTube download configuration."""

    format: str = "bestaudio/best"
    output_format: str = "wav"
    temp_dir: Optional[str] = None


@dataclass
class ElevenLabsConfig:
    """ElevenLabs STT configuration."""

    api_key_env: str = "ELEVENLABS_API_KEY"
    model: str = "scribe_v1"


@dataclass
class WhisperConfig:
    """Whisper STT configuration."""

    model_size: str = "base"
    device: str = "auto"
    compute_type: str = "auto"


@dataclass
class DiarizationConfig:
    """Speaker diarization configuration."""

    enabled: bool = False
    segment_interval: int = 10


@dataclass
class STTConfig:
    """Speech-to-text configuration."""

    provider: str = "elevenlabs"
    fallback_provider: str = "whisper"
    elevenlabs: ElevenLabsConfig = field(default_factory=ElevenLabsConfig)
    whisper: WhisperConfig = field(default_factory=WhisperConfig)
    diarization: DiarizationConfig = field(default_factory=DiarizationConfig)


@dataclass
class AudioProcessingConfig:
    """Audio processing configuration."""

    enabled: bool = True
    youtube: YouTubeConfig = field(default_factory=YouTubeConfig)
    stt: STTConfig = field(default_factory=STTConfig)


@dataclass
class UnstructuredConfig:
    """Unstructured.io configuration."""

    strategy: str = "auto"
    extract_images: bool = True
    include_page_breaks: bool = True
    languages: List[str] = field(default_factory=lambda: ["en"])
    pdf_infer_table_structure: bool = True
    pdf_extract_image_block_types: List[str] = field(default_factory=lambda: ["Image", "Table"])


@dataclass
class InputConfig:
    """Input handling configuration."""

    max_file_size: int = 104857600  # 100MB
    allowed_extensions: List[str] = field(default_factory=list)
    hash_algorithm: str = "sha256"


@dataclass
class ErrorHandlingConfig:
    """Error handling configuration."""

    continue_on_error: bool = True
    max_retries: int = 3
    retry_delay: float = 1.0


@dataclass
class LoggingConfig:
    """Logging configuration."""

    level: str = "INFO"
    include_metrics: bool = True
    file: Optional[str] = None


@dataclass
class IntegrationConfig:
    """Security integration settings. Defaults OFF for zero functional impact."""

    enable_rate_limiting: bool = False
    enable_audit_logging: bool = False
    enable_input_validation: bool = False
    enable_error_handling: bool = False
    user_tier_callback: Optional[Callable] = field(default=None, repr=False)


@dataclass
class PipelineConfig:
    """Top-level pipeline configuration."""

    version: str = "1.0.0"
    name: str = "narrative-ai-ingestion"
    random_seed: int = 42
    batch_concurrency: int = 3


@dataclass
class IngestionConfig:
    """
    Main configuration class for the ingestion pipeline.

    Aggregates all sub-configurations and provides methods for
    loading from YAML files with environment variable interpolation.
    """

    pipeline: PipelineConfig = field(default_factory=PipelineConfig)
    integration: IntegrationConfig = field(default_factory=IntegrationConfig)
    input: InputConfig = field(default_factory=InputConfig)
    unstructured: UnstructuredConfig = field(default_factory=UnstructuredConfig)
    image_processing: ImageProcessingConfig = field(default_factory=ImageProcessingConfig)
    audio_processing: AudioProcessingConfig = field(default_factory=AudioProcessingConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    error_handling: ErrorHandlingConfig = field(default_factory=ErrorHandlingConfig)

    @classmethod
    def from_yaml(cls, config_path: Union[str, Path]) -> "IngestionConfig":
        """
        Load configuration from a YAML file.

        Args:
            config_path: Path to the YAML configuration file.

        Returns:
            IngestionConfig instance with loaded values.
        """
        config_path = Path(config_path)
        if not config_path.exists():
            logger.warning(f"Config file not found: {config_path}, using defaults")
            return cls()

        with open(config_path, "r", encoding="utf-8") as f:
            raw_config = yaml.safe_load(f) or {}

        # Interpolate environment variables
        config = cls._interpolate_env_vars(raw_config)

        return cls._from_dict(config)

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "IngestionConfig":
        """Create configuration from a dictionary."""
        return cls._from_dict(config_dict)

    @classmethod
    def _from_dict(cls, config: Dict[str, Any]) -> "IngestionConfig":
        """Internal method to create config from dictionary."""
        # Pipeline config
        pipeline_cfg = config.get("pipeline", {})
        integration_cfg = {
            k: v
            for k, v in config.get("integration", {}).items()
            if k in ("enable_rate_limiting", "enable_audit_logging", "enable_input_validation", "enable_error_handling")
        }
        integration = IntegrationConfig(**integration_cfg)
        pipeline = PipelineConfig(
            version=pipeline_cfg.get("version", "1.0.0"),
            name=pipeline_cfg.get("name", "narrative-ai-ingestion"),
            random_seed=pipeline_cfg.get("random_seed", 42),
            batch_concurrency=max(1, int(pipeline_cfg.get("batch_concurrency", 3))),
        )

        # Input config
        input_cfg = config.get("input", {})
        input_config = InputConfig(
            max_file_size=input_cfg.get("max_file_size", 104857600),
            allowed_extensions=input_cfg.get("allowed_extensions", []),
            hash_algorithm=input_cfg.get("hash_algorithm", "sha256"),
        )

        # Unstructured config
        unstr_cfg = config.get("unstructured", {})
        pdf_cfg = unstr_cfg.get("pdf", {})
        unstructured = UnstructuredConfig(
            strategy=unstr_cfg.get("strategy", "auto"),
            extract_images=unstr_cfg.get("extract_images", True),
            include_page_breaks=unstr_cfg.get("include_page_breaks", True),
            languages=unstr_cfg.get("languages", ["en"]),
            pdf_infer_table_structure=pdf_cfg.get("infer_table_structure", True),
            pdf_extract_image_block_types=pdf_cfg.get("extract_image_block_types", ["Image", "Table"]),
        )

        # Image processing config
        img_cfg = config.get("image_processing", {})
        ocr_cfg = img_cfg.get("ocr", {})
        tesseract_cfg = ocr_cfg.get("tesseract", {})
        ocr_api_cfg = ocr_cfg.get("api", {})

        ocr = OCRConfig(
            enabled=ocr_cfg.get("enabled", True),
            provider=ocr_cfg.get("provider", "tesseract"),
            tesseract_lang=tesseract_cfg.get("lang", "eng"),
            tesseract_config=tesseract_cfg.get("config", "--psm 3"),
            api_key_env=ocr_api_cfg.get("api_key_env", "GOOGLE_VISION_API_KEY"),
            api_endpoint=ocr_api_cfg.get("endpoint", ""),
        )

        cap_cfg = img_cfg.get("captioning", {})
        ollama_cfg = cap_cfg.get("ollama", {})
        ollama_cloud_cfg = cap_cfg.get("ollama_cloud", {})
        google_cfg = cap_cfg.get("google", {})
        cap_api_cfg = cap_cfg.get("api", {})

        captioning = CaptioningConfig(
            enabled=cap_cfg.get("enabled", True),
            provider=cap_cfg.get("provider", "ollama"),
            ollama_model=ollama_cfg.get("model", "qwen2-vl:2b"),
            ollama_host=ollama_cfg.get("host", "http://localhost:11434"),
            ollama_timeout=ollama_cfg.get("timeout", 30),
            ollama_cloud_model=ollama_cloud_cfg.get("model", "qwen-3vl"),
            ollama_cloud_base_url=ollama_cloud_cfg.get("base_url", "https://ollama.com"),
            ollama_cloud_api_key_env=ollama_cloud_cfg.get("api_key_env", "OLLAMA_CLOUD_API_KEY"),
            ollama_cloud_timeout=ollama_cloud_cfg.get("timeout", 300),
            api_key_env=cap_api_cfg.get("api_key_env", "OPENAI_API_KEY"),
            api_model=cap_api_cfg.get("model", "gpt-4-vision-preview"),
            api_max_tokens=cap_api_cfg.get("max_tokens", 300),
            google_model=google_cfg.get("model", "gemini-1.5-flash"),
        )

        image_processing = ImageProcessingConfig(
            enabled=img_cfg.get("enabled", False),
            mode=img_cfg.get("mode", "local"),
            max_image_workers=max(1, int(img_cfg.get("max_image_workers", 5))),
            ocr=ocr,
            captioning=captioning,
        )

        # Audio processing config
        audio_cfg = config.get("audio_processing", {})
        yt_cfg = audio_cfg.get("youtube", {})
        youtube = YouTubeConfig(
            format=yt_cfg.get("format", "bestaudio/best"),
            output_format=yt_cfg.get("output_format", "wav"),
            temp_dir=yt_cfg.get("temp_dir"),
        )

        stt_cfg = audio_cfg.get("stt", {})
        el_cfg = stt_cfg.get("elevenlabs", {})
        elevenlabs = ElevenLabsConfig(
            api_key_env=el_cfg.get("api_key_env", "ELEVENLABS_API_KEY"),
            model=el_cfg.get("model", "scribe_v1"),
        )

        whisper_cfg = stt_cfg.get("whisper", {})
        whisper = WhisperConfig(
            model_size=whisper_cfg.get("model_size", "base"),
            device=whisper_cfg.get("device", "auto"),
            compute_type=whisper_cfg.get("compute_type", "auto"),
        )

        diar_cfg = stt_cfg.get("diarization", {})
        diarization = DiarizationConfig(
            enabled=diar_cfg.get("enabled", False),
            segment_interval=diar_cfg.get("segment_interval", 10),
        )

        stt = STTConfig(
            provider=stt_cfg.get("provider", "elevenlabs"),
            fallback_provider=stt_cfg.get("fallback_provider", "whisper"),
            elevenlabs=elevenlabs,
            whisper=whisper,
            diarization=diarization,
        )

        audio_processing = AudioProcessingConfig(
            enabled=audio_cfg.get("enabled", True),
            youtube=youtube,
            stt=stt,
        )

        # Logging config
        log_cfg = config.get("logging", {})
        logging_config = LoggingConfig(
            level=log_cfg.get("level", "INFO"),
            include_metrics=log_cfg.get("include_metrics", True),
            file=log_cfg.get("file"),
        )

        # Error handling config
        err_cfg = config.get("error_handling", {})
        error_handling = ErrorHandlingConfig(
            continue_on_error=err_cfg.get("continue_on_error", True),
            max_retries=err_cfg.get("max_retries", 3),
            retry_delay=err_cfg.get("retry_delay", 1.0),
        )

        return cls(
            pipeline=pipeline,
            integration=integration,
            input=input_config,
            unstructured=unstructured,
            image_processing=image_processing,
            audio_processing=audio_processing,
            logging=logging_config,
            error_handling=error_handling,
        )

    @staticmethod
    def _interpolate_env_vars(obj: Any) -> Any:
        """
        Recursively interpolate environment variables in config values.

        Supports ${VAR_NAME} and ${VAR_NAME:-default} syntax.
        """
        if isinstance(obj, dict):
            return {k: IngestionConfig._interpolate_env_vars(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [IngestionConfig._interpolate_env_vars(item) for item in obj]
        elif isinstance(obj, str):
            # Pattern: ${VAR_NAME} or ${VAR_NAME:-default}
            pattern = r"\$\{([^}:]+)(?::-([^}]*))?\}"

            def replace_var(match):
                var_name = match.group(1)
                default = match.group(2) if match.group(2) is not None else ""
                return os.environ.get(var_name, default)

            return re.sub(pattern, replace_var, obj)
        return obj

    def get_api_key(self, env_var_name: str) -> Optional[str]:
        """Get an API key from environment variables."""
        return os.environ.get(env_var_name)


# Global config instance (singleton pattern)
_global_config: Optional[IngestionConfig] = None


def get_config(config_path: Optional[Union[str, Path]] = None) -> IngestionConfig:
    """
    Get the global configuration instance.

    Args:
        config_path: Path to config file. If None, uses default config.
                     Only used on first call to initialize the config.

    Returns:
        The global IngestionConfig instance.
    """
    global _global_config

    if _global_config is None:
        path = config_path or DEFAULT_CONFIG_PATH
        _global_config = IngestionConfig.from_yaml(path)
        logger.info(f"Loaded ingestion config from {path}")

    return _global_config


def reset_config() -> None:
    """Reset the global configuration (mainly for testing)."""
    global _global_config
    _global_config = None


def load_config(config_path: Union[str, Path]) -> IngestionConfig:
    """
    Load a new configuration from file, replacing the global instance.

    Args:
        config_path: Path to the configuration file.

    Returns:
        The newly loaded IngestionConfig.
    """
    global _global_config
    _global_config = IngestionConfig.from_yaml(config_path)
    return _global_config
