"""
Factory methods for the Enhanced Ingestion Pipeline.

Provides convenient factory functions to create pipeline instances
with various configurations.
"""

from pathlib import Path
from typing import Optional, Union

from .config import IngestionConfig, get_config
from .ingestion_pipeline import IngestionPipeline
from .input_handler import InputHandler
from .document_extractor import DocumentExtractor
from .image_processor import ImageProcessor
from .audio_processor import AudioProcessor
from .assembler import DocumentAssembler


def create_pipeline(
    config: Optional[IngestionConfig] = None,
) -> IngestionPipeline:
    """
    Create an ingestion pipeline with default or provided configuration.

    Args:
        config: Optional configuration. Uses default config if not provided.

    Returns:
        Configured IngestionPipeline instance.
    """
    return IngestionPipeline(config=config)


def create_pipeline_from_config(
    config_path: Union[str, Path],
) -> IngestionPipeline:
    """
    Create an ingestion pipeline from a configuration file.

    Args:
        config_path: Path to the YAML configuration file.

    Returns:
        Configured IngestionPipeline instance.
    """
    return IngestionPipeline(config_path=config_path)


def create_pipeline_with_options(
    enable_image_processing: bool = False,
    enable_audio_processing: bool = True,
    ocr_provider: str = "tesseract",
    stt_provider: str = "elevenlabs",
    unstructured_strategy: str = "auto",
) -> IngestionPipeline:
    """
    Create a pipeline with specific options.

    This is a convenience method for quick configuration without YAML.

    Args:
        enable_image_processing: Enable OCR and captioning for images.
        enable_audio_processing: Enable audio/video transcription.
        ocr_provider: OCR backend ("tesseract", "google_vision", "azure").
        stt_provider: STT backend ("elevenlabs", "whisper").
        unstructured_strategy: Extraction strategy ("auto", "fast", "hi_res").

    Returns:
        Configured IngestionPipeline instance.
    """
    # Load default config and modify
    config = get_config()

    config.image_processing.enabled = enable_image_processing
    config.image_processing.ocr.provider = ocr_provider
    config.audio_processing.enabled = enable_audio_processing
    config.audio_processing.stt.provider = stt_provider
    config.unstructured.strategy = unstructured_strategy

    return IngestionPipeline(config=config)


def create_input_handler(
    config: Optional[IngestionConfig] = None,
) -> InputHandler:
    """
    Create an input handler instance.

    Args:
        config: Optional configuration.

    Returns:
        InputHandler instance.
    """
    return InputHandler(config=config)


def create_document_extractor(
    config: Optional[IngestionConfig] = None,
) -> DocumentExtractor:
    """
    Create a document extractor instance.

    Args:
        config: Optional configuration.

    Returns:
        DocumentExtractor instance.
    """
    return DocumentExtractor(config=config)


def create_image_processor(
    config: Optional[IngestionConfig] = None,
) -> ImageProcessor:
    """
    Create an image processor instance.

    Args:
        config: Optional configuration.

    Returns:
        ImageProcessor instance.
    """
    return ImageProcessor(config=config)


def create_audio_processor(
    config: Optional[IngestionConfig] = None,
) -> AudioProcessor:
    """
    Create an audio processor instance.

    Args:
        config: Optional configuration.

    Returns:
        AudioProcessor instance.
    """
    return AudioProcessor(config=config)


def create_assembler(
    config: Optional[IngestionConfig] = None,
) -> DocumentAssembler:
    """
    Create a document assembler instance.

    Args:
        config: Optional configuration.

    Returns:
        DocumentAssembler instance.
    """
    return DocumentAssembler(config=config)
