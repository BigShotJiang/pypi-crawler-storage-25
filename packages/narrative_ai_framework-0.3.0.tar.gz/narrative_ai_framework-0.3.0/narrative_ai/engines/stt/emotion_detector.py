"""
Emotion Detector - Prosody-based Voice Emotion Detection.

Detects emotion from voice prosody features (pitch, speed, energy)
to enhance STT results with emotional context.
"""

import logging
from typing import Optional, Dict, Tuple, List
from dataclasses import dataclass

import numpy as np

from .base_stt import Emotion
from .config import EmotionConfig

logger = logging.getLogger(__name__)


@dataclass
class ProsodyFeatures:
    """Extracted prosody features from audio."""

    # Pitch (fundamental frequency)
    pitch_mean: float  # Hz
    pitch_std: float  # Standard deviation
    pitch_range: float  # Max - Min
    pitch_slope: float  # Trend direction

    # Speed/Rate
    speech_rate: float  # Syllables per second (estimated)
    pause_ratio: float  # Ratio of pauses to speech

    # Energy/Intensity
    energy_mean: float  # RMS energy
    energy_std: float  # Energy variation
    energy_range: float  # Dynamic range

    # Duration
    duration_s: float  # Total duration in seconds


@dataclass
class EmotionResult:
    """Result of emotion detection."""

    emotion: Emotion
    confidence: float
    prosody: ProsodyFeatures

    # Individual emotion scores
    scores: Dict[str, float]

    # Raw feature values (for debugging)
    raw_features: Optional[Dict[str, float]] = None


class EmotionDetector:
    """
    Prosody-based emotion detector.

    Analyzes audio prosody features (pitch, speed, energy) to detect
    emotional state. Uses a rule-based approach with optional ML enhancement.

    Emotion Categories:
    - HAPPY: Higher pitch, faster speech, more energy variation
    - SAD: Lower pitch, slower speech, less energy
    - CALM: Normal pitch, steady pace, consistent energy
    - ANXIOUS: Higher pitch, faster speech, irregular patterns
    - ANGRY: Higher pitch, faster speech, higher energy
    - NEUTRAL: Default/fallback when no strong emotion detected

    Example:
        detector = EmotionDetector()
        result = await detector.detect_emotion(audio_array, sample_rate=16000)
        print(f"Detected: {result.emotion} ({result.confidence:.1%})")
    """

    # Baseline prosody values (can be calibrated per speaker)
    DEFAULT_BASELINES = {
        "pitch_mean": 150.0,  # Hz (average for male/female)
        "pitch_std": 30.0,
        "speech_rate": 4.0,  # syllables/sec
        "energy_mean": 0.1,
    }

    # Emotion detection thresholds
    EMOTION_PATTERNS = {
        Emotion.HAPPY: {
            "pitch_deviation": (0.1, 0.5),  # Higher pitch
            "speed_deviation": (0.1, 0.5),  # Faster
            "energy_deviation": (0.0, 0.5),  # More energy
            "pitch_variation": (1.2, 2.0),  # More variation
        },
        Emotion.SAD: {
            "pitch_deviation": (-0.4, -0.1),  # Lower pitch
            "speed_deviation": (-0.4, -0.1),  # Slower
            "energy_deviation": (-0.4, 0.0),  # Less energy
            "pitch_variation": (0.5, 1.0),  # Less variation
        },
        Emotion.CALM: {
            "pitch_deviation": (-0.1, 0.1),  # Normal pitch
            "speed_deviation": (-0.1, 0.1),  # Normal speed
            "energy_deviation": (-0.1, 0.1),  # Normal energy
            "pitch_variation": (0.8, 1.2),  # Steady variation
        },
        Emotion.ANXIOUS: {
            "pitch_deviation": (0.2, 0.6),  # Higher pitch
            "speed_deviation": (0.2, 0.6),  # Faster
            "energy_deviation": (-0.2, 0.3),  # Variable energy
            "pitch_variation": (1.5, 2.5),  # High variation
        },
        Emotion.ANGRY: {
            "pitch_deviation": (0.1, 0.4),  # Higher pitch
            "speed_deviation": (0.1, 0.4),  # Faster
            "energy_deviation": (0.2, 0.6),  # Higher energy
            "pitch_variation": (1.3, 2.0),  # More variation
        },
    }

    def __init__(
        self,
        config: Optional[EmotionConfig] = None,
        baselines: Optional[Dict[str, float]] = None,
    ):
        """
        Initialize emotion detector.

        Args:
            config: Emotion detection configuration
            baselines: Custom baseline prosody values
        """
        self.config = config or EmotionConfig()
        self.baselines = baselines or self.DEFAULT_BASELINES.copy()

        # Feature weights from config
        self.pitch_weight = self.config.pitch_weight
        self.speed_weight = self.config.speed_weight
        self.energy_weight = self.config.energy_weight

        # Normalize weights
        total_weight = self.pitch_weight + self.speed_weight + self.energy_weight
        self.pitch_weight /= total_weight
        self.speed_weight /= total_weight
        self.energy_weight /= total_weight

        # Thread pool executor for CPU-intensive pitch extraction (librosa.pyin is blocking)
        # Use default executor to avoid creating new threads unnecessarily
        self._use_thread_pool = True  # Can be disabled for testing

    async def detect_emotion(
        self,
        audio: np.ndarray,
        sample_rate: int = 16000,
    ) -> EmotionResult:
        """
        Detect emotion from audio.

        Args:
            audio: Audio data as numpy array (float32, normalized)
            sample_rate: Audio sample rate

        Returns:
            EmotionResult with detected emotion and confidence
        """
        if not self.config.enabled:
            return self._neutral_result()

        try:
            # Extract prosody features (pitch extraction runs in thread pool to avoid blocking)
            prosody = await self._extract_prosody_async(audio, sample_rate)

            # Classify emotion (lightweight, can run in event loop)
            emotion, confidence, scores = self._classify_emotion(prosody)

            # Apply confidence threshold
            if confidence < self.config.confidence_threshold:
                emotion = Emotion.NEUTRAL

            return EmotionResult(
                emotion=emotion,
                confidence=confidence,
                prosody=prosody,
                scores=scores,
                raw_features=self._prosody_to_dict(prosody),
            )

        except Exception as e:
            logger.warning(f"Emotion detection failed: {e}")
            return self._neutral_result()

    async def _extract_prosody_async(
        self,
        audio: np.ndarray,
        sample_rate: int,
    ) -> ProsodyFeatures:
        """
        Extract prosody features asynchronously (pitch extraction in thread pool).

        Args:
            audio: Audio data
            sample_rate: Sample rate

        Returns:
            ProsodyFeatures
        """
        duration_s = len(audio) / sample_rate

        # Extract pitch using thread pool (librosa.pyin is CPU-intensive and blocking)
        if self._use_thread_pool:
            import asyncio

            loop = asyncio.get_running_loop()
            pitch_values = await loop.run_in_executor(
                None,  # Use default executor
                self._extract_pitch,
                audio,
                sample_rate,
            )
        else:
            pitch_values = self._extract_pitch(audio, sample_rate)

        # Pitch statistics
        if len(pitch_values) > 0:
            pitch_mean = float(np.mean(pitch_values))
            pitch_std = float(np.std(pitch_values))
            pitch_range = float(np.max(pitch_values) - np.min(pitch_values))

            # Pitch slope (trend)
            if len(pitch_values) > 1:
                x = np.arange(len(pitch_values))
                slope, _ = np.polyfit(x, pitch_values, 1)
                pitch_slope = float(slope)
            else:
                pitch_slope = 0.0
        else:
            pitch_mean = self.baselines["pitch_mean"]
            pitch_std = self.baselines["pitch_std"]
            pitch_range = 0.0
            pitch_slope = 0.0

        # Extract energy (lightweight, can run in event loop)
        energy = self._extract_energy(audio)
        energy_mean = float(np.mean(energy))
        energy_std = float(np.std(energy))
        energy_range = float(np.max(energy) - np.min(energy)) if len(energy) > 0 else 0.0

        # Estimate speech rate (lightweight)
        speech_rate = self._estimate_speech_rate(audio, sample_rate)

        # Estimate pause ratio (lightweight)
        pause_ratio = self._estimate_pause_ratio(audio)

        return ProsodyFeatures(
            pitch_mean=pitch_mean,
            pitch_std=pitch_std,
            pitch_range=pitch_range,
            pitch_slope=pitch_slope,
            speech_rate=speech_rate,
            pause_ratio=pause_ratio,
            energy_mean=energy_mean,
            energy_std=energy_std,
            energy_range=energy_range,
            duration_s=duration_s,
        )

    def _extract_prosody(
        self,
        audio: np.ndarray,
        sample_rate: int,
    ) -> ProsodyFeatures:
        """
        Extract prosody features from audio (synchronous version).

        This method is kept for backward compatibility and internal use.
        For async contexts, use _extract_prosody_async() instead.

        Args:
            audio: Audio data
            sample_rate: Sample rate

        Returns:
            ProsodyFeatures
        """
        duration_s = len(audio) / sample_rate

        # Extract pitch using autocorrelation
        pitch_values = self._extract_pitch(audio, sample_rate)

        # Pitch statistics
        if len(pitch_values) > 0:
            pitch_mean = float(np.mean(pitch_values))
            pitch_std = float(np.std(pitch_values))
            pitch_range = float(np.max(pitch_values) - np.min(pitch_values))

            # Pitch slope (trend)
            if len(pitch_values) > 1:
                x = np.arange(len(pitch_values))
                slope, _ = np.polyfit(x, pitch_values, 1)
                pitch_slope = float(slope)
            else:
                pitch_slope = 0.0
        else:
            pitch_mean = self.baselines["pitch_mean"]
            pitch_std = self.baselines["pitch_std"]
            pitch_range = 0.0
            pitch_slope = 0.0

        # Extract energy
        energy = self._extract_energy(audio)
        energy_mean = float(np.mean(energy))
        energy_std = float(np.std(energy))
        energy_range = float(np.max(energy) - np.min(energy)) if len(energy) > 0 else 0.0

        # Estimate speech rate (simplified)
        speech_rate = self._estimate_speech_rate(audio, sample_rate)

        # Estimate pause ratio
        pause_ratio = self._estimate_pause_ratio(audio)

        return ProsodyFeatures(
            pitch_mean=pitch_mean,
            pitch_std=pitch_std,
            pitch_range=pitch_range,
            pitch_slope=pitch_slope,
            speech_rate=speech_rate,
            pause_ratio=pause_ratio,
            energy_mean=energy_mean,
            energy_std=energy_std,
            energy_range=energy_range,
            duration_s=duration_s,
        )

    def _extract_pitch(
        self,
        audio: np.ndarray,
        sample_rate: int,
    ) -> np.ndarray:
        """
        Extract pitch (F0) using autocorrelation.

        Args:
            audio: Audio data
            sample_rate: Sample rate

        Returns:
            Array of pitch values (Hz)
        """
        # Try to use librosa for better pitch extraction
        try:
            import librosa

            # Use librosa's pyin for better pitch tracking
            f0, voiced_flag, voiced_probs = librosa.pyin(
                audio,
                fmin=librosa.note_to_hz("C2"),
                fmax=librosa.note_to_hz("C7"),
                sr=sample_rate,
            )

            # Filter to voiced frames only
            pitch_values = f0[voiced_flag]
            pitch_values = pitch_values[~np.isnan(pitch_values)]

            return pitch_values

        except ImportError:
            pass

        # Fallback: Simple autocorrelation-based pitch detection
        return self._simple_pitch_extraction(audio, sample_rate)

    def _simple_pitch_extraction(
        self,
        audio: np.ndarray,
        sample_rate: int,
    ) -> np.ndarray:
        """
        Simple pitch extraction using autocorrelation.

        Args:
            audio: Audio data
            sample_rate: Sample rate

        Returns:
            Array of pitch values
        """
        # Parameters
        frame_length = int(0.025 * sample_rate)  # 25ms frames
        hop_length = int(0.010 * sample_rate)  # 10ms hop

        # Pitch range (50-500 Hz)
        min_period = int(sample_rate / 500)
        max_period = int(sample_rate / 50)

        pitch_values = []

        # Process frames
        for i in range(0, len(audio) - frame_length, hop_length):
            frame = audio[i : i + frame_length]

            # Skip low energy frames
            if np.mean(np.abs(frame)) < 0.01:
                continue

            # Autocorrelation
            corr = np.correlate(frame, frame, mode="full")
            corr = corr[len(corr) // 2 :]

            # Find peak in pitch range
            search_region = corr[min_period:max_period]

            if len(search_region) > 0:
                peak_idx = np.argmax(search_region) + min_period

                if corr[peak_idx] > 0.3 * corr[0]:  # Threshold
                    pitch = sample_rate / peak_idx
                    pitch_values.append(pitch)

        return np.array(pitch_values)

    def _extract_energy(self, audio: np.ndarray) -> np.ndarray:
        """
        Extract frame-level energy (RMS).

        Args:
            audio: Audio data

        Returns:
            Array of energy values
        """
        frame_length = 512
        hop_length = 256

        energy = []

        for i in range(0, len(audio) - frame_length, hop_length):
            frame = audio[i : i + frame_length]
            rms = np.sqrt(np.mean(frame**2))
            energy.append(rms)

        return np.array(energy)

    def _estimate_speech_rate(
        self,
        audio: np.ndarray,
        sample_rate: int,
    ) -> float:
        """
        Estimate speech rate (syllables per second).

        Uses energy envelope peaks as syllable estimate.

        Args:
            audio: Audio data
            sample_rate: Sample rate

        Returns:
            Estimated syllables per second
        """
        duration_s = len(audio) / sample_rate

        if duration_s < 0.5:
            return self.baselines["speech_rate"]

        # Get energy envelope
        energy = self._extract_energy(audio)

        if len(energy) < 10:
            return self.baselines["speech_rate"]

        # Smooth energy - try scipy, fallback to numpy
        smoothed = self._smooth_signal(energy, window_size=5)

        # Find peaks (syllables)
        peaks = self._find_peaks(smoothed)

        if len(peaks) == 0:
            return self.baselines["speech_rate"]

        syllables_per_sec = len(peaks) / duration_s

        return syllables_per_sec

    def _smooth_signal(self, signal: np.ndarray, window_size: int = 5) -> np.ndarray:
        """
        Smooth signal using a moving average.

        Tries scipy first, falls back to numpy.

        Args:
            signal: Input signal
            window_size: Size of smoothing window

        Returns:
            Smoothed signal
        """
        # Try scipy first
        try:
            from scipy.ndimage import uniform_filter1d

            return uniform_filter1d(signal, size=window_size)
        except ImportError:
            pass

        # Fallback to numpy convolution
        try:
            kernel = np.ones(window_size) / window_size
            return np.convolve(signal, kernel, mode="same")
        except Exception:
            return signal

    def _find_peaks(self, signal: np.ndarray) -> np.ndarray:
        """Find peaks in signal."""
        # Try scipy first
        try:
            from scipy.signal import find_peaks as scipy_peaks

            peaks, _ = scipy_peaks(signal, distance=10, prominence=0.01)
            return peaks
        except ImportError:
            pass

        # Simple peak finding
        peaks = []
        for i in range(1, len(signal) - 1):
            if signal[i] > signal[i - 1] and signal[i] > signal[i + 1]:
                if signal[i] > np.mean(signal) * 0.5:
                    peaks.append(i)
        return np.array(peaks)

    def _estimate_pause_ratio(self, audio: np.ndarray) -> float:
        """
        Estimate ratio of pauses to speech.

        Args:
            audio: Audio data

        Returns:
            Pause ratio (0-1)
        """
        energy = self._extract_energy(audio)

        if len(energy) == 0:
            return 0.0

        # Threshold for silence
        threshold = np.median(energy) * 0.3

        silent_frames = np.sum(energy < threshold)
        pause_ratio = silent_frames / len(energy)

        return float(pause_ratio)

    def _classify_emotion(
        self,
        prosody: ProsodyFeatures,
    ) -> Tuple[Emotion, float, Dict[str, float]]:
        """
        Classify emotion based on prosody features.

        Args:
            prosody: Extracted prosody features

        Returns:
            Tuple of (emotion, confidence, scores)
        """
        # Calculate deviations from baseline
        pitch_dev = (prosody.pitch_mean - self.baselines["pitch_mean"]) / self.baselines["pitch_mean"]
        speed_dev = (prosody.speech_rate - self.baselines["speech_rate"]) / self.baselines["speech_rate"]
        energy_dev = (prosody.energy_mean - self.baselines["energy_mean"]) / self.baselines["energy_mean"]
        pitch_var = prosody.pitch_std / self.baselines["pitch_std"] if self.baselines["pitch_std"] > 0 else 1.0

        scores: Dict[str, float] = {}

        # Score each emotion
        for emotion, patterns in self.EMOTION_PATTERNS.items():
            score = 0.0

            # Pitch score
            p_min, p_max = patterns["pitch_deviation"]
            if p_min <= pitch_dev <= p_max:
                pitch_score = 1.0 - abs(pitch_dev - (p_min + p_max) / 2) / ((p_max - p_min) / 2)
                score += pitch_score * self.pitch_weight

            # Speed score
            s_min, s_max = patterns["speed_deviation"]
            if s_min <= speed_dev <= s_max:
                speed_score = 1.0 - abs(speed_dev - (s_min + s_max) / 2) / ((s_max - s_min) / 2)
                score += speed_score * self.speed_weight

            # Energy score
            e_min, e_max = patterns["energy_deviation"]
            if e_min <= energy_dev <= e_max:
                energy_score = 1.0 - abs(energy_dev - (e_min + e_max) / 2) / ((e_max - e_min) / 2)
                score += energy_score * self.energy_weight

            # Pitch variation bonus
            v_min, v_max = patterns["pitch_variation"]
            if v_min <= pitch_var <= v_max:
                score *= 1.2

            scores[emotion.value] = max(0.0, min(1.0, score))

        # Add neutral as fallback
        scores[Emotion.NEUTRAL.value] = 0.3  # Base score for neutral

        # Select highest scoring emotion
        best_emotion = Emotion.NEUTRAL
        best_score = 0.0

        for emotion_str, score in scores.items():
            if score > best_score:
                best_score = score
                best_emotion = Emotion(emotion_str)

        # Calculate confidence
        confidence = best_score

        return best_emotion, confidence, scores

    def _prosody_to_dict(self, prosody: ProsodyFeatures) -> Dict[str, float]:
        """Convert prosody features to dict."""
        return {
            "pitch_mean": prosody.pitch_mean,
            "pitch_std": prosody.pitch_std,
            "pitch_range": prosody.pitch_range,
            "pitch_slope": prosody.pitch_slope,
            "speech_rate": prosody.speech_rate,
            "pause_ratio": prosody.pause_ratio,
            "energy_mean": prosody.energy_mean,
            "energy_std": prosody.energy_std,
            "energy_range": prosody.energy_range,
            "duration_s": prosody.duration_s,
        }

    def _neutral_result(self) -> EmotionResult:
        """Create neutral emotion result."""
        return EmotionResult(
            emotion=Emotion.NEUTRAL,
            confidence=1.0,
            prosody=ProsodyFeatures(
                pitch_mean=0,
                pitch_std=0,
                pitch_range=0,
                pitch_slope=0,
                speech_rate=0,
                pause_ratio=0,
                energy_mean=0,
                energy_std=0,
                energy_range=0,
                duration_s=0,
            ),
            scores={e.value: 0.0 for e in Emotion},
        )

    def calibrate_baselines(
        self,
        audio_samples: List[np.ndarray],
        sample_rate: int = 16000,
    ) -> None:
        """
        Calibrate baselines from neutral speech samples.

        Use this to personalize emotion detection per speaker.

        Args:
            audio_samples: List of neutral speech audio arrays
            sample_rate: Sample rate
        """
        if not audio_samples:
            return

        pitch_means = []
        pitch_stds = []
        speech_rates = []
        energy_means = []

        for audio in audio_samples:
            prosody = self._extract_prosody(audio, sample_rate)
            pitch_means.append(prosody.pitch_mean)
            pitch_stds.append(prosody.pitch_std)
            speech_rates.append(prosody.speech_rate)
            energy_means.append(prosody.energy_mean)

        self.baselines = {
            "pitch_mean": float(np.mean(pitch_means)),
            "pitch_std": float(np.mean(pitch_stds)),
            "speech_rate": float(np.mean(speech_rates)),
            "energy_mean": float(np.mean(energy_means)),
        }

        logger.info(f"Calibrated baselines: {self.baselines}")


# Convenience function


async def detect_emotion_from_audio(
    audio: np.ndarray,
    sample_rate: int = 16000,
) -> Tuple[Emotion, float]:
    """
    Detect emotion from audio.

    Convenience function for quick emotion detection.

    Args:
        audio: Audio data as numpy array
        sample_rate: Sample rate

    Returns:
        Tuple of (emotion, confidence)
    """
    detector = EmotionDetector()
    result = await detector.detect_emotion(audio, sample_rate)
    return result.emotion, result.confidence
