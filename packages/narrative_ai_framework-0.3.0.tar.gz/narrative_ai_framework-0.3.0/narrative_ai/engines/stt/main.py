"""
STT Engine CLI - Transcribe audio files directly.

Usage:
    python -m narrative_ai.engines.stt test.wav
    python -m narrative_ai.engines.stt test.wav --provider whisper   # faster-whisper (CT2)
    python -m narrative_ai.engines.stt test.wav --provider elevenlabs
    python -m narrative_ai.engines.stt test.wav --use-vad
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys

# Ensure project root is on path and load .env
if "__file__" in dir():
    _root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    if _root not in sys.path:
        sys.path.insert(0, _root)
    _env_path = os.path.join(_root, ".env")
    if os.path.isfile(_env_path):
        try:
            from dotenv import load_dotenv

            load_dotenv(_env_path, override=False)
        except ImportError:
            pass


async def _run(
    audio_file: str,
    use_vad: bool = False,
    provider: str | None = None,
) -> int:
    """Run STT on an audio file."""
    import numpy as np
    from narrative_ai.engines.stt import create_stt_engine_from_providers
    from narrative_ai.engines.stt.audio_processor import AudioProcessor

    if not os.path.exists(audio_file):
        print(f"Error: File not found: {audio_file}", file=sys.stderr)
        return 1

    engine = await create_stt_engine_from_providers(auto_initialize=True)
    processor = AudioProcessor()

    try:
        with open(audio_file, "rb") as f:
            audio_bytes = f.read()

        audio_array, original_sr = processor.load_audio_file(audio_bytes)
        processed, target_sr = processor.preprocess(audio_array, input_sample_rate=original_sr)

        if processed.dtype != np.float32:
            processed = processed.astype(np.float32)
        max_val = np.max(np.abs(processed))
        if max_val > 1.0:
            processed = processed / max_val

        pcm_bytes = (processed * 32767).astype(np.int16).tobytes()

        result = await engine.transcribe(
            pcm_bytes,
            sample_rate=target_sr,
            extract_emotion=False,
            use_vad=use_vad,
            provider=provider,
        )

        print(result.text)
        return 0
    finally:
        await engine.shutdown()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Transcribe audio file with STT engine (uses config/providers.yml)",
    )
    parser.add_argument("audio_file", help="Path to audio file (WAV, MP3, FLAC, etc.)")
    parser.add_argument("--use-vad", action="store_true", help="Use Voice Activity Detection")
    parser.add_argument(
        "--provider",
        choices=["whisper", "elevenlabs"],
        default=None,
        help="Force STT provider (whisper=faster-whisper when model is CT2; default=from config)",
    )
    args = parser.parse_args()

    exit_code = asyncio.run(_run(args.audio_file, use_vad=args.use_vad, provider=args.provider))
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
