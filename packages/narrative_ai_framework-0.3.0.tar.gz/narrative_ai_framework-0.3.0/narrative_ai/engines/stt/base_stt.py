"""
Base STT Provider - Abstract Interface.

Defines the interface that all STT providers must implement.
This follows the Strategy pattern for interchangeable providers.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, AsyncIterator
from enum import Enum
import time
import logging

logger = logging.getLogger(__name__)


class Emotion(str, Enum):
    """Detected emotion categories from voice prosody."""

    HAPPY = "happy"
    SAD = "sad"
    CALM = "calm"
    ANXIOUS = "anxious"
    ANGRY = "angry"
    NEUTRAL = "neutral"


class Language(str, Enum):
    """Supported languages for transcription."""

    ARABIC = "ar"
    ENGLISH = "en"
    MIXED = "mixed"  # Code-switching (Arabic/English)
    AUTO = "auto"  # Auto-detect


@dataclass
class STTResult:
    """
    Result from STT transcription.

    Contains transcribed text, confidence score, detected language,
    optional emotion, and metadata from the provider.
    """

    # Core transcription result
    text: str
    confidence: float  # 0.0 - 1.0
    language: str  # "ar", "en", "mixed"

    # Performance metrics
    processing_time: float  # Time taken in seconds
    provider: str  # Which provider was used

    # Optional emotion detection
    emotion: Optional[Emotion] = None
    emotion_confidence: Optional[float] = None

    # Streaming support
    is_partial: bool = False  # True for interim results during streaming
    is_final: bool = True  # True when this is the final result

    # Timestamped segments (if available)
    segments: Optional[List[Dict[str, Any]]] = None

    # Word-level timestamps (if available)
    words: Optional[List[Dict[str, Any]]] = None

    # Provider-specific metadata
    metadata: Optional[Dict[str, Any]] = field(default_factory=dict)

    def __post_init__(self):
        """Validate result after initialization."""
        if not 0.0 <= self.confidence <= 1.0:
            logger.warning(f"Confidence {self.confidence} out of range, clamping to [0, 1]")
            self.confidence = max(0.0, min(1.0, self.confidence))

        if self.emotion_confidence is not None and not 0.0 <= self.emotion_confidence <= 1.0:
            logger.warning(f"Emotion confidence {self.emotion_confidence} out of range, clamping to [0, 1]")
            self.emotion_confidence = max(0.0, min(1.0, self.emotion_confidence))


class STTError(Exception):
    """Base exception for STT errors."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        details: Optional[Dict] = None,
        retriable: bool = False,
        **kwargs,
    ):
        super().__init__(message)
        self.provider = provider
        self.details = details or {}
        self.retriable = retriable


class ProviderUnavailableError(STTError):
    """Raised when a provider is not available (model not loaded, API key missing, etc.)."""

    pass


class TranscriptionError(STTError):
    """Raised when transcription fails."""

    def __init__(
        self,
        message: str,
        provider: Optional[str] = None,
        details: Optional[Dict] = None,
        correlation_id: Optional[str] = None,
        audio_duration: Optional[float] = None,
    ):
        super().__init__(message, provider, details)
        self.correlation_id = correlation_id
        self.audio_duration = audio_duration


class AudioFormatError(STTError):
    """Raised when audio format is invalid or unsupported."""

    pass


class RateLimitError(STTError):
    """Raised when API rate limit is exceeded."""

    pass


class AudioTooShortError(AudioFormatError):
    """Raised when audio is too short to process."""

    pass


class AudioTooLongError(AudioFormatError):
    """Raised when audio exceeds maximum duration."""

    pass


class InvalidSampleRateError(AudioFormatError):
    """Raised when sample rate is invalid."""

    pass


class VADProcessingError(STTError):
    """Raised when VAD processing fails."""

    pass


class EmotionDetectionError(STTError):
    """Raised when emotion detection fails."""

    pass


class STTTimeoutError(STTError):
    """Raised when an STT request times out."""

    def __init__(self, message: str, provider: Optional[str] = None, **kwargs):
        super().__init__(message, provider=provider, retriable=True, **kwargs)


class STTNetworkError(STTError):
    """Raised when a network/connection error occurs during STT."""

    def __init__(self, message: str, provider: Optional[str] = None, **kwargs):
        super().__init__(message, provider=provider, retriable=True, **kwargs)


def is_retriable_error(error: Exception) -> bool:
    """
    Check if an error is retriable.

    Uses type-based checks first (robust), then string matching as fallback.

    Args:
        error: Exception to check

    Returns:
        True if error is retriable
    """
    if isinstance(error, STTError):
        return error.retriable

    # Type-based checks (robust - not fragile to error message changes)
    try:
        import asyncio

        if isinstance(error, asyncio.TimeoutError):
            return True
    except ImportError:
        pass

    retriable_types = ()
    try:
        import httpx

        retriable_types = (
            httpx.TimeoutException,
            httpx.ConnectError,
        )
    except ImportError:
        pass
    try:
        from requests.exceptions import Timeout, ConnectionError as ReqConnectionError

        retriable_types = retriable_types + (Timeout, ReqConnectionError)
    except ImportError:
        pass

    if isinstance(error, retriable_types):
        return True

    # Fallback: string matching (last resort)
    error_str = str(error).lower()
    retriable_patterns = [
        "timeout",
        "connection",
        "network",
        "temporary",
        "503",
        "502",
        "504",
    ]
    return any(pattern in error_str for pattern in retriable_patterns)


class BaseSTTProvider(ABC):
    """
    Abstract base class for STT providers.

    All STT providers (Whisper, ElevenLabs) must implement this interface.
    This enables the Strategy pattern for interchangeable providers with fallback support.

    Example:
        class WhisperSTTProvider(BaseSTTProvider):
            async def transcribe(self, audio, sample_rate):
                # Implementation
                pass
    """

    def __init__(self):
        """Initialize base provider."""
        self._is_loaded = False
        self._load_time: Optional[float] = None

    @abstractmethod
    async def transcribe(
        self,
        audio: bytes,
        sample_rate: int = 16000,
        language: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> STTResult:
        """
        Transcribe audio to text.

        Args:
            audio: Audio data as bytes (16-bit PCM expected)
            sample_rate: Audio sample rate in Hz (default: 16000)
            language: Optional language code ("ar", "en", or None for auto-detect)

        Returns:
            STTResult with transcribed text and metadata

        Raises:
            TranscriptionError: If transcription fails
            AudioFormatError: If audio format is invalid
            ProviderUnavailableError: If provider is not available
        """
        pass

    @abstractmethod
    async def transcribe_streaming(
        self,
        audio_stream: AsyncIterator[bytes],
        sample_rate: int = 16000,
        language: Optional[str] = None,
    ) -> AsyncIterator[STTResult]:
        """
        Stream transcription with interim results.

        This method is designed for real-time transcription with LiveKit integration.
        It yields partial results as audio is processed, allowing for low-latency
        feedback to users.

        Args:
            audio_stream: Async iterator of audio chunks (from LiveKit AudioFrame)
            sample_rate: Audio sample rate in Hz (default: 16000)
            language: Optional language code ("ar", "en", or None for auto-detect)

        Yields:
            STTResult objects with:
            - is_partial=True for interim results
            - is_final=True for the final result after speech ends

        Raises:
            TranscriptionError: If transcription fails
            AudioFormatError: If audio format is invalid
            ProviderUnavailableError: If provider is not available

        Example:
            async for result in provider.transcribe_streaming(audio_stream):
                if result.is_partial:
                    # Update UI with partial text
                    print(f"Partial: {result.text}")
                else:
                    # Final result
                    print(f"Final: {result.text}")
        """
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """
        Check if provider is available and ready to use.

        Returns:
            True if provider is loaded and ready, False otherwise

        Example:
            if provider.is_available():
                result = await provider.transcribe(audio)
        """
        pass

    @abstractmethod
    def get_provider_name(self) -> str:
        """
        Get the name of this provider.

        Returns:
            Provider name (e.g., "whisper", "elevenlabs")
        """
        pass

    def get_supported_languages(self) -> List[str]:
        """
        Get list of supported languages.

        Returns:
            List of language codes (e.g., ["ar", "en"])

        Override in subclass if provider has specific language support.
        """
        return ["ar", "en", "mixed"]

    def get_supported_sample_rates(self) -> List[int]:
        """
        Get list of supported sample rates.

        Returns:
            List of sample rates in Hz (e.g., [16000, 48000])

        Override in subclass if provider has specific sample rate requirements.
        """
        return [16000]  # Most models require 16kHz

    async def load_model(self) -> None:
        """
        Load the model into memory.

        This is called lazily when first transcription is requested,
        or can be called explicitly to pre-load the model.

        Override in subclass to implement model loading.
        """
        start_time = time.time()
        await self._load_model_impl()
        self._load_time = time.time() - start_time
        self._is_loaded = True
        logger.info(f"Provider {self.get_provider_name()} loaded in {self._load_time:.2f}s")

    async def _load_model_impl(self) -> None:
        """
        Implementation of model loading.

        Override in subclass to implement actual model loading.
        """
        pass

    async def shutdown(self) -> None:
        """
        Cleanup resources and unload model.

        Called when provider is no longer needed.
        Override in subclass to implement cleanup.
        """
        await self._shutdown_impl()
        self._is_loaded = False
        logger.info(f"Provider {self.get_provider_name()} shut down")

    async def _shutdown_impl(self) -> None:
        """
        Implementation of shutdown.

        Override in subclass to implement actual cleanup.
        """
        pass

    def get_model_info(self) -> Dict[str, Any]:
        """
        Get information about the loaded model.

        Returns:
            Dict with model information (name, size, device, etc.)

        Override in subclass to provide model-specific information.
        """
        return {
            "provider": self.get_provider_name(),
            "is_loaded": self._is_loaded,
            "load_time": self._load_time,
            "supported_languages": self.get_supported_languages(),
            "supported_sample_rates": self.get_supported_sample_rates(),
        }

    async def health_check(self) -> Dict[str, Any]:
        """
        Perform health check on the provider.

        Returns:
            Dict with health status and details
        """
        return {
            "provider": self.get_provider_name(),
            "available": self.is_available(),
            "loaded": self._is_loaded,
        }

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(provider={self.get_provider_name()}, available={self.is_available()})"
