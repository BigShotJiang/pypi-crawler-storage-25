"""
STT Engine Configuration.

Centralized configuration for all STT providers, VAD, emotion detection,
and integration settings.

Supports loading from:
- Environment variables (from_env)
- Dictionary (from_dict)
- providers.yml (from_providers_config)

Real-time targets (industry): first-token < 200 ms for streaming,
batch < 2× realtime. Use metrics.slo_first_result_latency_ms and
alert_first_result_p95_ms for dashboards and alerting.
"""

import os
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any, TYPE_CHECKING, Callable
from enum import Enum
import logging

if TYPE_CHECKING:
    from config import ProvidersConfig

logger = logging.getLogger(__name__)

# Supported STT provider names (used for validation and filtering)
VALID_STT_PROVIDERS = frozenset({"whisper", "elevenlabs"})


def _validate_provider_names(primary: str, fallbacks: List[str]) -> None:
    """Validate primary and fallback provider names. Raises ValueError if invalid."""
    valid = list(VALID_STT_PROVIDERS)
    if primary not in VALID_STT_PROVIDERS:
        raise ValueError(f"Primary provider must be one of {valid}, got {primary!r}")
    for p in fallbacks:
        if p not in VALID_STT_PROVIDERS:
            raise ValueError(f"Fallback provider must be one of {valid}, got {p!r}")


class STTProvider(str, Enum):
    """Available STT providers."""

    ELEVENLABS = "elevenlabs"
    WHISPER = "whisper"


class EmotionProvider(str, Enum):
    """Emotion detection provider types."""

    PROSODY = "prosody"  # Rule-based prosody analysis
    ML_MODEL = "ml_model"  # ML model-based
    HYBRID = "hybrid"  # Combination of both


class VADMode(int, Enum):
    """WebRTC VAD aggressiveness modes."""

    QUALITY = 0  # Least aggressive - most sensitive
    LOW_BITRATE = 1  # Moderately sensitive
    AGGRESSIVE = 2  # Balanced (recommended)
    VERY_AGGRESSIVE = 3  # Least sensitive - filters more


@dataclass
class WhisperConfig:
    """Configuration for Whisper 3 Turbo provider."""

    # Model settings
    model_path: Optional[str] = None  # Path to fine-tuned checkpoint, HF Hub ID, or CTranslate2 dir
    device: str = "auto"  # "auto", "cuda", "cpu"
    precision: str = "float16"  # "float16", "float32" (HuggingFace path)
    compute_type: str = "int8_float16"  # CTranslate2/faster-whisper: int8, int8_float16, float16

    # Inference settings
    chunk_length_s: float = 30.0  # Max chunk length in seconds (batch / long audio)
    overlap_s: float = 0.5  # Overlap between chunks in seconds
    # For streaming: use smaller chunks to reduce time-to-first-result.
    # When None, streaming uses chunk_length_s. Low-latency: set streaming_chunk_length_s=5.0
    # (and optionally chunk_length_s=10.0, overlap_s=1.0) in providers.yml for real-time feel.
    streaming_chunk_length_s: Optional[float] = None
    # Min duration (seconds) of remaining buffer to send for transcription; skip tiny tail to avoid fragile calls.
    min_tail_duration_s: float = 0.1
    beam_size: int = 5  # Beam search size (use 1 for lowest latency; 5 for best quality)

    # Low-latency (faster-whisper): fewer retries and smaller beam
    low_latency: bool = False  # True → beam_size=1, temperature=0.0 only (no fallback)
    disable_temperature_fallback: bool = False  # True → use temperature=0.0 only (faster, no retries)
    patience: float = 1.0  # Beam search patience (lower = faster; 0.0 = greedy-like)

    # VAD integration
    use_vad: bool = True  # Enable VAD for better chunking
    # faster-whisper Silero VAD tuning (e.g. min_silence_duration_ms, speech_pad_ms, threshold)
    vad_parameters: Optional[Dict[str, Any]] = None

    # faster-whisper–specific
    word_timestamps: bool = False  # Enable word-level timestamps (adds cost)
    condition_on_previous_text: bool = True  # Context across chunks; disable to avoid repetition loops
    # Anti-hallucination: only passed when set (otherwise library defaults; no extra cost)
    no_speech_threshold: Optional[float] = None  # e.g. 0.7 = skip more as "no speech"
    log_prob_threshold: Optional[float] = None  # e.g. -1.2 = skip low-confidence segments
    initial_prompt: Optional[str] = None  # optional hint phrase to reduce hallucination
    cpu_threads: int = 0  # CPU threads when device=cpu (0 = CTranslate2 default)
    max_concurrent_transcriptions: int = 4  # Semaphore limit for concurrent transcribe() calls
    faster_whisper_max_workers: int = 2  # ThreadPoolExecutor workers for run_in_executor

    # Language settings
    default_language: Optional[str] = None  # None = auto-detect

    def __post_init__(self):
        """Validate configuration."""
        if self.model_path is None:
            # Use default model from HuggingFace
            self.model_path = "openai/whisper-large-v3-turbo"
            logger.info(f"Using default Whisper model: {self.model_path}")
        if not 1 <= self.beam_size <= 10:
            raise ValueError(f"beam_size must be 1-10, got {self.beam_size}")
        if self.overlap_s >= self.chunk_length_s:
            raise ValueError(f"overlap_s ({self.overlap_s}) must be less than chunk_length_s ({self.chunk_length_s})")


@dataclass
class ElevenLabsConfig:
    """Configuration for ElevenLabs API provider."""

    # API settings
    api_key: Optional[str] = None  # From env: ELEVENLABS_API_KEY

    # Model settings
    model_id: str = "scribe_v2"  # "scribe_v2" for batch
    # Realtime STT uses a dedicated model id (see ElevenLabs "Realtime" STT API).
    streaming_model_id: str = "scribe_v2_realtime"  # For real-time streaming

    # Request settings
    timeout: int = 30  # Timeout in seconds
    retry_attempts: int = 3  # Number of retry attempts
    retry_backoff: float = 1.0  # Initial backoff in seconds

    # Streaming / real-time tuning (ElevenLabs Realtime STT)
    vad_silence_threshold_secs: float = 0.8  # Silence before commit (lower = faster commit, default ~1.5s on API)
    final_commit_grace_sec: float = 0.12  # Wait after audio end for committed_transcript before forcing final
    include_timestamps: bool = (
        False  # Enable word-level timestamps in committed_transcript_with_timestamps (adds payload)
    )

    # API endpoint (optional override)
    api_base_url: Optional[str] = None

    def __post_init__(self):
        """Load config from environment if not provided."""
        if self.api_key is None:
            raw = os.getenv("ELEVENLABS_API_KEY") or ""
            self.api_key = raw.strip().strip("\ufeff") or None
            if self.api_key:
                logger.info("Loaded ElevenLabs API key from environment")
            else:
                logger.warning("ElevenLabs API key not found in environment")
        else:
            # Normalize key from providers/caller: strip whitespace and BOM
            self.api_key = (self.api_key or "").strip().strip("\ufeff") or None
        if self.api_key:
            logger.info("ElevenLabs API key loaded successfully")
        else:
            logger.warning("ElevenLabs API key not configured")

        # Optional model overrides (kept flexible for quick experimentation)
        if model_id := os.getenv("ELEVENLABS_STT_MODEL_ID"):
            self.model_id = model_id.strip()

        streaming_override = os.getenv("ELEVENLABS_STT_STREAMING_MODEL_ID") or os.getenv(
            "ELEVENLABS_STT_REALTIME_MODEL_ID"
        )
        if streaming_override:
            self.streaming_model_id = streaming_override.strip()


@dataclass
class VADConfig:
    """Configuration for WebRTC VAD."""

    # VAD settings
    enabled: bool = True
    mode: int = 2  # 0-3, 2 = aggressive (recommended)

    # Audio format
    sample_rate: int = 16000  # Must be 8000, 16000, 32000, or 48000
    frame_duration_ms: int = 20  # 10, 20, or 30 ms

    # Speech detection thresholds
    speech_start_frames: int = 3  # Frames to confirm speech start
    speech_end_frames: int = 5  # Frames to confirm speech end

    # Duration limits
    min_speech_duration_ms: int = 250  # Minimum speech duration to output
    max_speech_duration_ms: int = 30000  # Maximum speech duration (30s)

    # When VAD finds no segments (e.g. TTS/synthetic speech), transcribe full audio once instead of returning empty
    retry_with_full_audio_on_no_speech: bool = True

    def __post_init__(self):
        """Validate configuration."""
        if self.sample_rate not in [8000, 16000, 32000, 48000]:
            raise ValueError(f"Sample rate must be 8000, 16000, 32000, or 48000, got {self.sample_rate}")

        if self.frame_duration_ms not in [10, 20, 30]:
            raise ValueError(f"Frame duration must be 10, 20, or 30 ms, got {self.frame_duration_ms}")

        if self.mode not in range(4):
            raise ValueError(f"VAD mode must be 0-3, got {self.mode}")

    @property
    def frame_size_samples(self) -> int:
        """Calculate frame size in samples."""
        return int(self.sample_rate * self.frame_duration_ms / 1000)

    @property
    def frame_size_bytes(self) -> int:
        """Calculate frame size in bytes (16-bit PCM)."""
        return self.frame_size_samples * 2


@dataclass
class EmotionConfig:
    """Configuration for emotion detection."""

    # Enable/disable
    enabled: bool = True

    # Provider type
    provider: str = "prosody"  # "prosody", "ml_model", "hybrid"

    # Language settings
    language: str = "auto"  # "ar", "en", "auto"

    # Confidence threshold
    confidence_threshold: float = 0.6  # Minimum confidence to return emotion

    # Prosody feature settings
    pitch_weight: float = 0.4  # Weight for pitch in classification
    speed_weight: float = 0.3  # Weight for speech speed
    energy_weight: float = 0.3  # Weight for energy/volume

    # ML model settings (for future use)
    ml_model_path: Optional[str] = None


@dataclass
class AudioConfig:
    """Configuration for audio processing."""

    # Target format
    target_sample_rate: int = 16000  # Standard for most STT models
    target_channels: int = 1  # Mono
    target_bit_depth: int = 16  # 16-bit PCM

    # Validation limits
    max_duration_s: int = 600  # 10 minutes max
    max_size_bytes: int = 50 * 1024 * 1024  # 50 MB max

    # Streaming buffer limits (prevents memory leaks in long sessions)
    max_streaming_buffer_size_bytes: int = 10 * 1024 * 1024  # 10 MB max for accumulated audio

    # Processing options
    normalize_audio: bool = True  # Normalize audio levels
    remove_silence: bool = False  # Remove leading/trailing silence

    # Supported input formats
    supported_formats: List[str] = field(default_factory=lambda: ["wav", "mp3", "flac", "m4a", "ogg", "webm"])


@dataclass
class MetricsConfig:
    """Configuration for metrics collection and latency SLOs."""

    # Latency tracking
    max_latency_samples: int = 1000  # Max samples for percentile calculation

    # SLO targets (for dashboards and alerting; industry: first-token < 200 ms for streaming)
    slo_first_result_latency_ms: Optional[float] = 200.0  # Target: time to first transcription (ms)
    slo_batch_realtime_factor: Optional[float] = 2.0  # Target: processing_time <= audio_duration * factor
    alert_first_result_p95_ms: Optional[float] = 500.0  # Alert when first-result p95 exceeds this (ms)

    # Health check
    health_check_timeout: float = 5.0  # Timeout in seconds

    # Export settings
    export_histograms: bool = True  # Export histogram metrics
    export_vad_metrics: bool = True  # Export VAD performance metrics


@dataclass
class IntegrationConfig:
    """Configuration for framework integration."""

    # Security layer integration
    enable_rate_limiting: bool = True
    enable_audit_logging: bool = True
    enable_input_validation: bool = True

    # User tier lookup: when user_tier is None, call (user_id, tenant_id) -> UserTier
    # from DB/cache. Use FREE when callback returns None or is not set.
    user_tier_callback: Optional[Callable[[Optional[str], Optional[str]], Any]] = None

    # Performance settings
    timeout: int = 30  # Overall timeout in seconds
    retry_attempts: int = 3  # Retry attempts on failure
    health_check_timeout: float = 5.0  # Timeout for health checks (aligns with TTS/LLM)

    # Logging
    log_transcriptions: bool = False  # Log transcription text (privacy concern)
    log_performance_metrics: bool = True  # Log latency, confidence, etc.


@dataclass
class STTConfig:
    """
    Main STT Engine configuration.

    Combines all configuration sections into a single config object.

    Example:
        config = STTConfig(
            primary_provider="elevenlabs",
            fallback_providers=["whisper"],
        )

        # Or load from environment
        config = STTConfig.from_env()
    """

    # Provider selection
    primary_provider: str = "elevenlabs"  # "whisper", "elevenlabs"
    fallback_providers: List[str] = field(default_factory=lambda: ["whisper"])
    min_confidence: float = 0.6  # Minimum confidence to accept result
    allow_degraded_mode: bool = False  # Return degraded result instead of raising when all providers fail

    # Provider-specific configs
    whisper: WhisperConfig = field(default_factory=WhisperConfig)
    elevenlabs: ElevenLabsConfig = field(default_factory=ElevenLabsConfig)

    # VAD config
    vad: VADConfig = field(default_factory=VADConfig)

    # Emotion detection config
    emotion: EmotionConfig = field(default_factory=EmotionConfig)

    # Audio processing config
    audio: AudioConfig = field(default_factory=AudioConfig)

    # Integration config
    integration: IntegrationConfig = field(default_factory=IntegrationConfig)

    # Metrics config
    metrics: MetricsConfig = field(default_factory=MetricsConfig)

    def __post_init__(self):
        """Validate configuration after initialization."""
        _validate_provider_names(self.primary_provider, self.fallback_providers)
        # Validate min confidence
        if not 0.0 <= self.min_confidence <= 1.0:
            raise ValueError(f"min_confidence must be between 0 and 1, got {self.min_confidence}")

    @classmethod
    def from_env(cls) -> "STTConfig":
        """
        Create configuration from environment variables.

        Environment variables:
            STT_PRIMARY_PROVIDER: Primary provider name
            STT_FALLBACK_PROVIDERS: Comma-separated fallback providers
            STT_MIN_CONFIDENCE: Minimum confidence threshold
            ELEVENLABS_API_KEY: ElevenLabs API key
            WHISPER_MODEL_PATH: Path to Whisper model

        Returns:
            STTConfig instance
        """
        config = cls()

        # Provider selection
        if primary := os.getenv("STT_PRIMARY_PROVIDER"):
            config.primary_provider = primary

        if fallbacks := os.getenv("STT_FALLBACK_PROVIDERS"):
            config.fallback_providers = [p.strip() for p in fallbacks.split(",")]

        if min_conf := os.getenv("STT_MIN_CONFIDENCE"):
            config.min_confidence = float(min_conf)

        # Model paths
        if whisper_path := os.getenv("WHISPER_MODEL_PATH"):
            config.whisper.model_path = whisper_path

        # VAD settings
        if vad_mode := os.getenv("VAD_MODE"):
            config.vad.mode = int(vad_mode)

        if vad_enabled := os.getenv("VAD_ENABLED"):
            config.vad.enabled = vad_enabled.lower() in ("true", "1", "yes")

        # Emotion settings
        if emotion_enabled := os.getenv("EMOTION_DETECTION_ENABLED"):
            config.emotion.enabled = emotion_enabled.lower() in ("true", "1", "yes")

        # Validate provider names from env (may override defaults with invalid values)
        _validate_provider_names(config.primary_provider, config.fallback_providers)
        logger.info(f"Loaded STT config from environment: primary={config.primary_provider}")

        return config

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "STTConfig":
        """
        Create configuration from dictionary.

        Note: This method creates a copy of the input to avoid mutating it.

        Args:
            data: Configuration dictionary

        Returns:
            STTConfig instance
        """
        # Create a copy to avoid mutating the input dictionary
        data = data.copy()

        # Extract nested configs
        whisper_data = data.pop("whisper", {})
        elevenlabs_data = data.pop("elevenlabs", {})
        vad_data = data.pop("vad", {})
        emotion_data = data.pop("emotion", {})
        audio_data = data.pop("audio", {})
        integration_data = data.pop("integration", {})
        metrics_data = data.pop("metrics", {})

        return cls(
            **data,
            whisper=WhisperConfig(**whisper_data),
            elevenlabs=ElevenLabsConfig(**elevenlabs_data),
            vad=VADConfig(**vad_data),
            emotion=EmotionConfig(**emotion_data),
            audio=AudioConfig(**audio_data),
            integration=IntegrationConfig(**integration_data),
            metrics=MetricsConfig(**metrics_data),
        )

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert configuration to dictionary.

        Returns:
            Configuration as dictionary
        """
        from dataclasses import asdict

        return asdict(self)

    def get_provider_config(self, provider: str) -> Any:
        """
        Get configuration for a specific provider.

        Args:
            provider: Provider name ("whisper", "elevenlabs")

        Returns:
            Provider configuration object
        """
        configs = {
            "whisper": self.whisper,
            "elevenlabs": self.elevenlabs,
        }
        return configs.get(provider)

    @classmethod
    def from_providers_config(
        cls,
        providers_config: Optional["ProvidersConfig"] = None,
    ) -> "STTConfig":
        """
        Create configuration from providers.yml.

        This is the recommended way to configure STT when using the
        centralized providers.yml configuration file.

        Args:
            providers_config: ProvidersConfig instance (loads default if None)

        Returns:
            STTConfig instance configured from providers.yml

        Example:
            # Using default providers.yml
            config = STTConfig.from_providers_config()

            # Or with custom ProvidersConfig
            from config import ProvidersConfig
            providers = ProvidersConfig("/path/to/providers.yml")
            config = STTConfig.from_providers_config(providers)
        """
        # Import here to avoid circular dependency
        try:
            from config import ProvidersConfig, ProviderType
        except ImportError:
            logger.warning("ProvidersConfig not available, falling back to env")
            return cls.from_env()

        # Load providers config if not provided
        if providers_config is None:
            try:
                providers_config = ProvidersConfig()
            except FileNotFoundError:
                logger.warning("providers.yml not found, falling back to env")
                return cls.from_env()

        # Get STT config section
        stt_section = providers_config._config.get("stt", {})

        # Determine primary and fallback from providers.yml
        raw_fallback_order = stt_section.get("fallback_order", ["elevenlabs", "whisper"])
        # Filter to only supported providers (ignore unimplemented e.g. google, conformer)
        fallback_order = [p for p in raw_fallback_order if p in VALID_STT_PROVIDERS]
        if len(fallback_order) < len(raw_fallback_order):
            skipped = set(raw_fallback_order) - VALID_STT_PROVIDERS
            logger.debug("STT fallback_order: skipped unsupported providers: %s", skipped)
        min_confidence = stt_section.get("min_confidence", 0.6)

        # Get primary provider (the one marked as primary: true)
        primary_provider = "elevenlabs"  # Default
        for provider_info in providers_config.get_all_providers(ProviderType.STT):
            if provider_info.primary and provider_info.name in VALID_STT_PROVIDERS:
                primary_provider = provider_info.name
                break
            elif provider_info.primary and provider_info.name not in VALID_STT_PROVIDERS:
                logger.warning(
                    "STT primary %r not implemented, using elevenlabs",
                    provider_info.name,
                )
                break

        # Extract enabled fallbacks (only supported providers)
        enabled_fallbacks = [
            p.name
            for p in providers_config.get_enabled_providers(ProviderType.STT)
            if p.name in VALID_STT_PROVIDERS and p.name != primary_provider and p.name in fallback_order
        ]

        # Build ElevenLabs config
        elevenlabs_info = providers_config.get_provider("elevenlabs", ProviderType.STT)
        elevenlabs_config = ElevenLabsConfig()
        if elevenlabs_info and elevenlabs_info.enabled:
            el_cfg = elevenlabs_info.config
            elevenlabs_config = ElevenLabsConfig(
                api_key=elevenlabs_info.api_key,  # Reads from env via ProviderInfo
                model_id=el_cfg.get("models", {}).get("batch", "scribe_v2"),
                streaming_model_id=el_cfg.get("models", {}).get("streaming", "scribe_v2_realtime"),
                timeout=el_cfg.get("timeout", 30),
                retry_attempts=el_cfg.get("retry_attempts", 3),
                vad_silence_threshold_secs=float(el_cfg.get("vad_silence_threshold_secs", 0.8)),
                final_commit_grace_sec=float(el_cfg.get("final_commit_grace_sec", 0.12)),
            )

        # Build Whisper config
        whisper_info = providers_config.get_provider("whisper", ProviderType.STT)
        whisper_config = WhisperConfig()
        if whisper_info and whisper_info.enabled:
            w_cfg = whisper_info.config
            # Check for env variable override first
            model_path = os.getenv(w_cfg.get("model_path_env", "WHISPER_MODEL_PATH"))
            if not model_path:
                model_path = w_cfg.get("model_path", "openai/whisper-large-v3-turbo")

            local_cfg = w_cfg.get("local", {})
            sc = local_cfg.get("streaming_chunk_length_s")
            streaming_chunk = float(sc) if sc is not None else None
            min_tail = local_cfg.get("min_tail_duration_s")
            min_tail_s = float(min_tail) if min_tail is not None else 0.1
            vad_params = local_cfg.get("vad_parameters")
            vad_params = vad_params if isinstance(vad_params, dict) else None
            no_speech = local_cfg.get("no_speech_threshold")
            no_speech_f = float(no_speech) if no_speech is not None else None
            log_prob = local_cfg.get("log_prob_threshold")
            log_prob_f = float(log_prob) if log_prob is not None else None
            initial_prompt_val = local_cfg.get("initial_prompt")
            if initial_prompt_val is not None and not str(initial_prompt_val).strip():
                initial_prompt_val = None
            # One switch for much lower latency (beam=1, temp=0 only, patience 0.5); trade-off: quality
            use_low_latency_preset = local_cfg.get("use_low_latency_preset", False)
            if use_low_latency_preset:
                beam_size = 1
                low_latency = True
                disable_temperature_fallback = True
                patience = 0.5
            else:
                beam_size = local_cfg.get("beam_size", 5)
                low_latency = local_cfg.get("low_latency", False)
                disable_temperature_fallback = local_cfg.get("disable_temperature_fallback", False)
                patience = float(local_cfg.get("patience", 1.0))
            whisper_config = WhisperConfig(
                model_path=model_path,
                device=local_cfg.get("device", "auto"),
                precision=local_cfg.get("precision", "float16"),
                compute_type=local_cfg.get("compute_type", "int8_float16"),
                chunk_length_s=float(local_cfg.get("chunk_length_s", 30)),
                overlap_s=float(local_cfg.get("overlap_s", 0.5)),
                streaming_chunk_length_s=streaming_chunk,
                min_tail_duration_s=min_tail_s,
                beam_size=beam_size,
                low_latency=low_latency,
                disable_temperature_fallback=disable_temperature_fallback,
                patience=patience,
                use_vad=local_cfg.get("use_vad", True),
                vad_parameters=vad_params,
                word_timestamps=local_cfg.get("word_timestamps", False),
                condition_on_previous_text=local_cfg.get("condition_on_previous_text", True),
                no_speech_threshold=no_speech_f,
                log_prob_threshold=log_prob_f,
                initial_prompt=initial_prompt_val,
                cpu_threads=int(local_cfg.get("cpu_threads", 0)),
                max_concurrent_transcriptions=int(local_cfg.get("max_concurrent_transcriptions", 4)),
                faster_whisper_max_workers=int(local_cfg.get("faster_whisper_max_workers", 2)),
            )

        # Build VAD config
        vad_section = stt_section.get("vad", {})
        vad_config = VADConfig(
            enabled=vad_section.get("enabled", True),
            mode=vad_section.get("mode", 2),
            sample_rate=vad_section.get("sample_rate", 16000),
            retry_with_full_audio_on_no_speech=vad_section.get("retry_with_full_audio_on_no_speech", True),
        )

        # Build Emotion config
        emotion_section = stt_section.get("emotion_detection", {})
        emotion_config = EmotionConfig(
            enabled=emotion_section.get("enabled", True),
            provider=emotion_section.get("provider", "prosody"),
        )

        # Build Integration config from global settings
        global_cfg = providers_config.global_config
        integration_config = IntegrationConfig(
            timeout=global_cfg.get("default_timeout", 30),
            retry_attempts=global_cfg.get("retry", {}).get("max_attempts", 3),
            log_performance_metrics=global_cfg.get("log_performance_metrics", True),
        )

        # Build Metrics config (use defaults, can be overridden via env if needed)
        metrics_config = MetricsConfig()

        logger.info(f"Loaded STT config from providers.yml: primary={primary_provider}")

        return cls(
            primary_provider=primary_provider,
            fallback_providers=enabled_fallbacks,
            min_confidence=min_confidence,
            whisper=whisper_config,
            elevenlabs=elevenlabs_config,
            vad=vad_config,
            emotion=emotion_config,
            integration=integration_config,
            metrics=metrics_config,
        )
