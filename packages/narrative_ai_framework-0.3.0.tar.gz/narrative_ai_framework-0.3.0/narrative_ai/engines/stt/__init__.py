"""
STT Engine - Speech-to-Text Module.

This module provides comprehensive Speech-to-Text functionality with:
- Multiple provider support (ElevenLabs, Whisper 3 Turbo)
- Automatic provider fallback on failure
- Voice Activity Detection (VAD) preprocessing
- Emotion detection from voice prosody
- Streaming transcription for real-time applications
- Full integration with the framework's security layer
- Centralized configuration via providers.yml

Quick Start (Recommended - Using providers.yml):
    ```python
    from narrative_ai.engines.stt import create_stt_engine_from_providers

    # Create engine from config/providers.yml
    engine = await create_stt_engine_from_providers()

    # Transcribe audio with emotion detection
    result = await engine.transcribe(
        audio_bytes,
        sample_rate=16000,
        extract_emotion=True,
    )

    print(f"Text: {result.text}")
    print(f"Emotion: {result.emotion}")
    print(f"Confidence: {result.confidence}")
    ```

    To change providers, just edit config/providers.yml:
    ```yaml
    stt:
      elevenlabs:
        enabled: true
        primary: true    # <- Default provider
      whisper:
        enabled: true
        primary: false   # <- Fallback
    ```

Alternative Quick Start (Environment Variables):
    ```python
    from narrative_ai.engines.stt import create_stt_engine

    # Create engine from environment variables
    engine = await create_stt_engine()
    result = await engine.transcribe(audio_bytes)
    ```

Streaming Example:
    ```python
    async for partial in engine.transcribe_streaming(audio_stream):
        if partial.is_partial:
            print(f"Interim: {partial.text}")
        else:
            print(f"Final: {partial.text} (emotion: {partial.emotion})")
    ```

Provider Configuration (Manual):
    ```python
    from narrative_ai.engines.stt import STTConfig, STTEngine

    config = STTConfig(
        primary_provider="elevenlabs",
        fallback_providers=["whisper"],
        min_confidence=0.6,
    )

    engine = STTEngine(config)
    ```

Direct Provider Usage:
    ```python
    from narrative_ai.engines.stt import ElevenLabsSTTProvider, ElevenLabsConfig

    provider = ElevenLabsSTTProvider(ElevenLabsConfig(api_key="..."))
    result = await provider.transcribe(audio_bytes)
    ```

VAD Processing:
    ```python
    from narrative_ai.engines.stt import VADProcessor

    vad = VADProcessor(sample_rate=16000, mode=2)
    segments = vad.process_audio(audio_bytes)

    for segment in segments:
        print(f"Speech: {segment.start_time_s:.2f}s - {segment.end_time_s:.2f}s")
    ```

Emotion Detection:
    ```python
    from narrative_ai.engines.stt import EmotionDetector

    detector = EmotionDetector()
    result = await detector.detect_emotion(audio_array, sample_rate=16000)

    print(f"Emotion: {result.emotion} ({result.confidence:.0%})")
    ```
"""

# Base components
from .base_stt import (
    BaseSTTProvider,
    STTResult,
    Emotion,
    Language,
    STTError,
    TranscriptionError,
    ProviderUnavailableError,
    RateLimitError,
    AudioFormatError,
    STTTimeoutError,
    STTNetworkError,
)

# Configuration
from .config import (
    STTConfig,
    WhisperConfig,
    ElevenLabsConfig,
    VADConfig,
    EmotionConfig,
    AudioConfig,
    IntegrationConfig,
    STTProvider,
    EmotionProvider,
    VADMode,
)

# Audio processing
from .audio_processor import (
    AudioProcessor,
    AudioMetadata,
    AudioFormat,
    AudioProcessingError,
    AudioValidationError,
    preprocess_audio,
    validate_audio,
)

# VAD
from .vad_processor import (
    VADProcessor,
    SpeechSegment,
    SpeechState,
    SpeechChunker,
    detect_speech_segments,
)

# Providers
from .elevenlabs_stt import ElevenLabsSTTProvider
from .whisper_stt import WhisperSTTProvider
from .faster_whisper_stt import FasterWhisperSTTProvider

# Strategy
from .stt_strategy import STTStrategy

# Emotion detection
from .emotion_detector import (
    EmotionDetector,
    EmotionResult,
    ProsodyFeatures,
    detect_emotion_from_audio,
)

# Main engine
from .stt_engine import (
    STTEngine,
    TranscriptionResult,
    create_stt_engine,
    create_stt_engine_from_providers,
)

# API
from .api import (
    speech_to_text,
    stt_streaming,
    detect_emotion,
    detect_speech,
    STTClient,
)


__all__ = [
    # Main entry points
    "STTEngine",
    "create_stt_engine",
    "create_stt_engine_from_providers",
    "TranscriptionResult",
    "speech_to_text",
    "stt_streaming",
    "detect_emotion",
    "detect_speech",
    "STTClient",
    # Base components
    "BaseSTTProvider",
    "STTResult",
    "Emotion",
    "Language",
    # Errors
    "STTError",
    "TranscriptionError",
    "ProviderUnavailableError",
    "RateLimitError",
    "AudioFormatError",
    "STTTimeoutError",
    "STTNetworkError",
    "is_retriable_error",
    # Configuration
    "STTConfig",
    "WhisperConfig",
    "ElevenLabsConfig",
    "VADConfig",
    "EmotionConfig",
    "AudioConfig",
    "IntegrationConfig",
    "STTProvider",
    "EmotionProvider",
    "VADMode",
    # Audio processing
    "AudioProcessor",
    "AudioMetadata",
    "AudioFormat",
    "AudioProcessingError",
    "AudioValidationError",
    "preprocess_audio",
    "validate_audio",
    # VAD
    "VADProcessor",
    "SpeechSegment",
    "SpeechState",
    "SpeechChunker",
    "detect_speech_segments",
    # Providers
    "ElevenLabsSTTProvider",
    "WhisperSTTProvider",
    "FasterWhisperSTTProvider",
    # Strategy
    "STTStrategy",
    # Emotion detection
    "EmotionDetector",
    "EmotionResult",
    "ProsodyFeatures",
    "detect_emotion_from_audio",
]

# Module version
__version__ = "0.1.0"
