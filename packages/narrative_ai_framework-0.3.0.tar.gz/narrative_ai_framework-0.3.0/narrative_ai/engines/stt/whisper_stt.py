"""
Whisper STT Provider - Fine-tuned Whisper 3 Turbo.

Implements STT using a fine-tuned Whisper Large-v3 Turbo model
for high-quality transcription with Arabic and English support.

Model: openai/whisper-large-v3-turbo (or fine-tuned checkpoint)
Framework: HuggingFace Transformers
"""

import asyncio
import time
import logging
import warnings
from typing import Optional, Dict, Any, AsyncIterator, List, Union
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from .base_stt import (
    BaseSTTProvider,
    STTResult,
    TranscriptionError,
    ProviderUnavailableError,
)
from .config import WhisperConfig
from .audio_processor import AudioProcessor

logger = logging.getLogger(__name__)


class WhisperSTTProvider(BaseSTTProvider):
    """
    Whisper STT Provider using fine-tuned Whisper 3 Turbo.

    Features:
    - Fine-tuned model support for Arabic/English
    - Long-form audio transcription with chunking
    - Word-level timestamps
    - GPU acceleration (CUDA)
    - Streaming support with overlapping windows

    Example:
        config = WhisperConfig(model_path="path/to/finetuned-whisper")
        provider = WhisperSTTProvider(config)

        result = await provider.transcribe(audio_bytes)
        logger.info("Transcription: %s", result.text)
    """

    def __init__(self, config: Optional[WhisperConfig] = None):
        """
        Initialize Whisper STT provider.

        Args:
            config: Whisper configuration
        """
        super().__init__()
        self.config = config or WhisperConfig()

        # Model components (lazy loaded)
        self._model = None
        self._processor = None
        self._device = None
        self._torch_dtype = None

        # Thread pool for blocking inference
        # Use explicit lifecycle management to prevent resource leaks
        self._executor = ThreadPoolExecutor(max_workers=2)
        self._executor_shutdown = False  # Track shutdown state to prevent double-shutdown

        # Concurrency limit to prevent resource exhaustion
        # Default: 4 concurrent transcriptions (adjust based on GPU memory)
        # Lazy init: created on first use to avoid "no event loop" when provider is
        # instantiated before asyncio.run() (e.g. in sync tests or config loading)
        # Python 3.9 and earlier: Semaphore captures event loop at init, causing RuntimeError
        max_concurrent = getattr(self.config, "max_concurrent_transcriptions", 4)
        self._max_concurrent = max_concurrent
        self._concurrency_limit: Optional[asyncio.Semaphore] = None

        # Thread safety lock for model access (PyTorch models are not thread-safe)
        # Lazy init: created on first use to avoid "no event loop" when provider is
        # instantiated before asyncio.run() (e.g. in sync tests or config loading)
        self._model_lock: Optional[asyncio.Lock] = None

        # Shutdown lock for atomic executor shutdown (lazy init for same reason)
        self._shutdown_lock: Optional[asyncio.Lock] = None

        # Audio processor
        self._audio_processor = AudioProcessor(
            target_sample_rate=16000,  # Whisper requires 16kHz
            normalize=True,
        )

    def _get_model_lock(self) -> asyncio.Lock:
        """Get model lock, creating it lazily when event loop is running."""
        if self._model_lock is None:
            self._model_lock = asyncio.Lock()
        return self._model_lock

    def _get_shutdown_lock(self) -> asyncio.Lock:
        """Get shutdown lock, creating it lazily when event loop is running."""
        if self._shutdown_lock is None:
            self._shutdown_lock = asyncio.Lock()
        return self._shutdown_lock

    def _get_concurrency_limit(self) -> asyncio.Semaphore:
        """Get concurrency semaphore, creating it lazily when event loop is running."""
        if self._concurrency_limit is None:
            self._concurrency_limit = asyncio.Semaphore(self._max_concurrent)
        return self._concurrency_limit

    async def _load_model_impl(self) -> None:
        """Load Whisper model."""
        logger.info(f"Loading Whisper model: {self.config.model_path}")

        try:
            import torch
            from transformers import WhisperForConditionalGeneration, WhisperProcessor
        except ImportError:
            raise ProviderUnavailableError(
                "transformers and torch required. Run: pip install transformers torch",
                provider=self.get_provider_name(),
            )

        if self.config.device == "auto":
            self._device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self._device = str(self.config.device)

        if self.config.precision == "float16":
            self._torch_dtype = torch.float16
        else:
            self._torch_dtype = torch.float32

        # CPU does not benefit from float16 and can be slower/less stable.
        # Force float32 on CPU even if config requests float16.
        if self._device == "cpu" and self._torch_dtype == torch.float16:
            logger.info("CPU detected; forcing Whisper dtype to float32")
            self._torch_dtype = torch.float32

        logger.info(f"Using device: {self._device}, dtype: {self._torch_dtype}")

        try:
            self._processor = WhisperProcessor.from_pretrained(self.config.model_path)  # nosec: B615

            # Prefer dtype= (newer transformers); fallback to torch_dtype= to avoid deprecation warning
            def _load_model(**kwargs):
                return WhisperForConditionalGeneration.from_pretrained(
                    self.config.model_path,
                    low_cpu_mem_usage=True,
                    **kwargs,
                )  # nosec: B615

            try:
                self._model = _load_model(dtype=self._torch_dtype, use_safetensors=True)
                logger.debug("Loaded model with safetensors")
            except TypeError:
                try:
                    self._model = _load_model(torch_dtype=self._torch_dtype, use_safetensors=True)  # nosec: B615
                    logger.debug("Loaded model with safetensors")
                except Exception as safetensor_error:
                    logger.debug(f"safetensors not available: {safetensor_error}, loading without")
                    self._model = _load_model(torch_dtype=self._torch_dtype)  # nosec: B615
            except Exception as safetensor_error:
                logger.debug(f"safetensors not available: {safetensor_error}, loading without")
                self._model = _load_model(dtype=self._torch_dtype)  # nosec: B615
            self._model.to(self._device)
            self._model.eval()
            # Kaggle fix: prevents forced_decoder_ids error
            if hasattr(self._model, "generation_config") and self._model.generation_config is not None:
                self._model.generation_config.forced_decoder_ids = None
            self._is_loaded = True
            logger.info("Whisper model loaded (Kaggle-style: eval, forced_decoder_ids=None)")

        except Exception as e:
            raise ProviderUnavailableError(f"Failed to load Whisper model: {e}", provider=self.get_provider_name())

    async def _shutdown_impl(self) -> None:
        """Unload model and cleanup."""
        if self._model is not None:
            del self._model
            self._model = None
        if self._processor is not None:
            del self._processor
            self._processor = None

        # Clear CUDA cache
        try:
            import torch

            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except ImportError:
            pass

        # Properly shutdown executor with non-blocking approach
        # Use wait=False to avoid blocking async event loop
        # Python guarantees threads will finish naturally - no need to check private APIs
        # Use lock to prevent race condition if shutdown is called concurrently
        async with self._get_shutdown_lock():
            if self._executor and not self._executor_shutdown:
                self._executor_shutdown = True
                # Signal shutdown (prevents new tasks) without blocking
                # cancel_futures=True cancels pending tasks (Python 3.9+); fallback for 3.8
                try:
                    self._executor.shutdown(wait=False, cancel_futures=True)
                except TypeError:
                    self._executor.shutdown(wait=False)

                # Log shutdown initiation
                # According to Python documentation: "Regardless of the value of wait,
                # the entire Python program will not exit until all pending futures
                # are done executing" - so threads will finish naturally
                logger.debug(
                    "Executor shutdown initiated (wait=False) - threads will finish naturally. "
                    "Python runtime guarantees cleanup on program exit."
                )

                # Release reference - Python runtime will handle thread cleanup
                # No need to check private _threads attribute (not part of public API)
                self._executor = None

        self._is_loaded = False

    def is_available(self) -> bool:
        """Check if provider is available."""
        try:
            import torch  # noqa: F401
            from transformers import AutoModelForSpeechSeq2Seq  # noqa: F401

            return True
        except ImportError:
            return False

    def get_provider_name(self) -> str:
        """Get provider name."""
        return "whisper"

    def get_supported_languages(self) -> List[str]:
        """Get supported languages."""
        return ["ar", "en", "mixed"]  # Focus on Arabic/English

    async def transcribe(
        self,
        audio: Union[bytes, np.ndarray],
        sample_rate: int = 16000,
        language: Optional[str] = None,
        correlation_id: Optional[str] = None,
        **kwargs: Any,
    ) -> STTResult:
        """
        Transcribe audio using Whisper model.

        Args:
            audio: Audio as bytes (16-bit PCM) or float32 numpy array (Kaggle/librosa-style, -1..1)
            sample_rate: Audio sample rate
            language: Language code (None for auto-detect)

        Returns:
            STTResult with transcription
        """
        if not self._is_loaded:
            await self.load_model()

        start_time = time.time()

        if isinstance(audio, np.ndarray):
            # Kaggle-style path: float32 array from librosa.load(path, sr=16000), no peak-normalize
            audio_array = np.asarray(audio, dtype=np.float32)
            if audio_array.ndim > 1:
                audio_array = np.mean(audio_array, axis=1)
            sr = int(sample_rate) if sample_rate else 16000
            if sr != 16000:
                try:
                    import librosa

                    audio_array = librosa.resample(audio_array, orig_sr=sr, target_sr=16000)
                except Exception:
                    audio_array, _ = self._audio_processor.preprocess(
                        self._audio_processor.array_to_bytes(audio_array), input_sample_rate=sr
                    )
                sr = 16000
            audio_array = np.clip(audio_array, -1.0, 1.0)
            duration_s = len(audio_array) / 16000
            logger.debug("Whisper transcription started (array, ~%.1fs)", duration_s)
            if duration_s > self.config.chunk_length_s:
                # Chunk in memory and transcribe per chunk
                # Acquire model lock to ensure thread safety (PyTorch models are not thread-safe)
                async with self._get_model_lock():
                    async with self._get_concurrency_limit():
                        chunk_samp = int(self.config.chunk_length_s * 16000)
                        step = chunk_samp - int(self.config.overlap_s * 16000)
                        parts = []
                        offset = 0
                        loop = asyncio.get_running_loop()
                        while offset < len(audio_array):
                            chunk = audio_array[offset : offset + chunk_samp]
                            r = await loop.run_in_executor(self._executor, self._transcribe_sync, chunk, language)
                            if r.text:
                                parts.append(r.text)
                            offset += step
                        combined = " ".join(parts)
                        if parts:
                            # dedupe overlap words
                            words = combined.split()
                            out = [words[0]] if words else []
                            for w in words[1:]:
                                if w != out[-1]:
                                    out.append(w)
                            combined = " ".join(out)
                        res = STTResult(
                            text=combined,
                            confidence=0.85,
                            language=language or "ar",
                            processing_time=time.time() - start_time,
                            provider=self.get_provider_name(),
                            is_partial=False,
                            is_final=True,
                            segments=None,
                            words=None,
                            metadata={"chunks": len(parts)},
                        )
                        return res
        else:
            logger.debug("Whisper transcription started (audio=%d bytes, sample_rate=%s Hz)", len(audio), sample_rate)

        # Acquire model lock first to ensure thread safety (PyTorch models are not thread-safe)
        async with self._get_model_lock():
            async with self._get_concurrency_limit():
                try:
                    if not isinstance(audio, np.ndarray):
                        logger.debug("Whisper preprocessing audio...")
                        audio_array, sr = self._audio_processor.preprocess(
                            audio,
                            input_sample_rate=sample_rate,
                        )
                        duration_s = len(audio_array) / sr
                        logger.debug(
                            "Whisper audio preprocessed: %d samples at %s Hz (~%.1fs)", len(audio_array), sr, duration_s
                        )
                        if duration_s > self.config.chunk_length_s:
                            logger.debug("Long audio (>%ss), using chunking", self.config.chunk_length_s)
                            return await self.transcribe_long_audio(audio, sample_rate, language)

                    logger.debug("Whisper starting model inference")
                    loop = asyncio.get_running_loop()
                    result = await loop.run_in_executor(
                        self._executor,
                        self._transcribe_sync,
                        audio_array,
                        language,
                    )
                    logger.debug("Whisper model inference complete")

                    result.processing_time = time.time() - start_time
                    return result

                except Exception as e:
                    raise TranscriptionError(f"Whisper transcription failed: {e}", provider=self.get_provider_name())

    def _transcribe_sync(
        self,
        audio_array: np.ndarray,
        language: Optional[str],
    ) -> STTResult:
        """
        Synchronous transcription matching your Kaggle inference exactly:
        - processor.feature_extractor (not full processor())
        - max_new_tokens=225
        - language="arabic" / task="transcribe"
        """
        import torch

        start_time = time.time()
        duration_s = len(audio_array) / 16000
        num_beams = 1 if self._device == "cpu" else getattr(self.config, "beam_size", 5)
        logger.debug("Whisper transcribing ~%.1fs (device=%s, beams=%s)", duration_s, self._device, num_beams)
        # Match Kaggle: use feature_extractor directly (same as your processor.feature_extractor(...))
        input_features = self._processor.feature_extractor(
            audio_array,
            sampling_rate=16000,
            return_tensors="pt",
        ).input_features.to(self._device, dtype=self._torch_dtype)
        # Attention mask: (batch, encoder_time_steps) so "pad token same as eos" warning is avoided
        # input_features shape is (batch, n_mels, time) -> encoder time = shape[2]
        seq_len = input_features.shape[2] if input_features.dim() >= 3 else input_features.shape[1]
        attention_mask = torch.ones(
            (input_features.shape[0], seq_len),
            device=input_features.device,
            dtype=torch.long,
        )
        # Match Kaggle: max_new_tokens=225, language + task
        generate_kwargs: Dict[str, Any] = {
            "task": "transcribe",
            "max_new_tokens": 225,
            "attention_mask": attention_mask,
        }
        if language == "ar":
            generate_kwargs["language"] = "arabic"
        elif language == "en":
            generate_kwargs["language"] = "english"
        if num_beams > 1:
            generate_kwargs["num_beams"] = num_beams
        # Suppress transformers warnings (generation_config defaults, logits processor, attention_mask)
        _prev_verbosity = None
        try:
            import transformers.logging as tf_logging

            _prev_verbosity = tf_logging.get_verbosity()
            tf_logging.set_verbosity_error()
        except Exception:
            pass
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            try:
                with torch.no_grad():
                    outputs = self._model.generate(input_features, **generate_kwargs)
            finally:
                if _prev_verbosity is not None:
                    try:
                        import transformers.logging as _tf_logging

                        _tf_logging.set_verbosity(_prev_verbosity)
                    except Exception:
                        pass
        transcription = self._processor.batch_decode(outputs, skip_special_tokens=True)[0].strip()
        segments = None
        try:
            ts = self._processor.batch_decode(outputs, skip_special_tokens=False, decode_with_timestamps=True)[0]
            segments = self._parse_timestamps(ts)
        except Exception:
            pass
        detected = language or (
            "ar" if transcription and any("\u0600" <= c <= "\u06ff" for c in transcription) else "en"
        )
        logger.debug("Whisper done (%.1fs)", time.time() - start_time)
        return STTResult(
            text=transcription,
            confidence=0.9,
            language=detected,
            processing_time=0.0,
            provider=self.get_provider_name(),
            is_partial=False,
            is_final=True,
            segments=segments,
            words=None,
            metadata={"model": self.config.model_path, "device": self._device},
        )

    async def transcribe_streaming(
        self,
        audio_stream: AsyncIterator[bytes],
        sample_rate: int = 16000,
        language: Optional[str] = None,
    ) -> AsyncIterator[STTResult]:
        """
        Stream transcription with overlapping chunks.

        Whisper doesn't support true streaming, so we implement pseudo-streaming
        by transcribing overlapping chunks and yielding interim results.

        Args:
            audio_stream: Async iterator of audio chunks
            sample_rate: Audio sample rate
            language: Language code

        Yields:
            STTResult objects
        """
        if not self._is_loaded:
            await self.load_model()

        # Buffer for accumulating audio (bytes)
        buffer = bytearray()
        # Use smaller chunks for streaming when set (lower time-to-first-result latency)
        chunk_s = (
            self.config.streaming_chunk_length_s
            if self.config.streaming_chunk_length_s is not None
            else self.config.chunk_length_s
        )
        chunk_bytes = int(chunk_s * sample_rate * 2)  # 16-bit PCM = 2 bytes per sample
        overlap_bytes = int(self.config.overlap_s * sample_rate * 2)

        start_time = time.time()
        last_text = ""

        async for chunk in audio_stream:
            buffer.extend(chunk)

            # Process when we have enough audio
            while len(buffer) >= chunk_bytes:
                # Get chunk to process
                chunk_audio = bytes(buffer[:chunk_bytes])

                # Keep overlap for next chunk
                buffer = buffer[chunk_bytes - overlap_bytes :]

                # Transcribe chunk
                try:
                    result = await self.transcribe(chunk_audio, sample_rate, language)

                    # Check if text changed
                    if result.text and result.text != last_text:
                        # Yield partial result
                        yield STTResult(
                            text=result.text,
                            confidence=result.confidence * 0.8,  # Lower confidence for partial
                            language=result.language,
                            processing_time=time.time() - start_time,
                            provider=self.get_provider_name(),
                            is_partial=True,
                            is_final=False,
                        )
                        last_text = result.text

                except Exception as e:
                    logger.warning(f"Chunk transcription failed: {e}")

        # Process remaining buffer (skip tiny tail to avoid slow/fragile Whisper call on very short audio)
        min_tail_s = getattr(self.config, "min_tail_duration_s", 0.1)
        min_tail_bytes = int(min_tail_s * sample_rate * 2)  # 16-bit mono
        if len(buffer) >= min_tail_bytes:
            try:
                result = await self.transcribe(bytes(buffer), sample_rate, language)

                # Yield final result
                yield STTResult(
                    text=result.text,
                    confidence=result.confidence,
                    language=result.language,
                    processing_time=time.time() - start_time,
                    provider=self.get_provider_name(),
                    is_partial=False,
                    is_final=True,
                    segments=result.segments,
                )
            except Exception as e:
                logger.warning(f"Final chunk transcription failed: {e}")

    def _parse_timestamps(self, decoded_output: str) -> Optional[List[Dict[str, Any]]]:
        """
        Parse timestamps from Whisper output.

        Args:
            decoded_output: Raw decoded output with timestamps

        Returns:
            List of segment dicts with start, end, text
        """
        import re

        # Pattern for Whisper timestamps: <|0.00|>text<|2.50|>
        pattern = r"<\|(\d+\.\d+)\|>([^<]*)"
        matches = re.findall(pattern, decoded_output)

        if not matches:
            return None

        segments = []
        for i, (timestamp, text) in enumerate(matches):
            if text.strip():
                start_time = float(timestamp)

                # Get end time from next segment or estimate
                if i + 1 < len(matches):
                    end_time = float(matches[i + 1][0])
                else:
                    # Estimate based on text length
                    end_time = start_time + len(text) * 0.05

                segments.append(
                    {
                        "start": start_time,
                        "end": end_time,
                        "text": text.strip(),
                    }
                )

        return segments if segments else None

    async def transcribe_long_audio(
        self,
        audio: bytes,
        sample_rate: int = 16000,
        language: Optional[str] = None,
    ) -> STTResult:
        """
        Transcribe long audio with proper chunking.

        Handles audio longer than 30 seconds by chunking with overlap.

        Args:
            audio: Audio data
            sample_rate: Sample rate
            language: Language code

        Returns:
            Combined STTResult
        """
        # Preprocess audio
        audio_array, sr = self._audio_processor.preprocess(
            audio,
            input_sample_rate=sample_rate,
        )

        duration_s = len(audio_array) / sr

        # If short enough, transcribe directly
        if duration_s <= self.config.chunk_length_s:
            return await self.transcribe(audio, sample_rate, language)

        chunk_samples = int(self.config.chunk_length_s * sr)
        overlap_samples = int(self.config.overlap_s * sr)
        step = chunk_samples - overlap_samples
        n_chunks = max(1, (len(audio_array) - overlap_samples + step - 1) // step)

        logger.debug(
            "Long audio (%.1fs), transcribing in %d chunks of ~%ss", duration_s, n_chunks, self.config.chunk_length_s
        )
        logger.info("Long audio (%.1fs), chunking...", duration_s)

        start_time = time.time()

        all_segments = []
        full_text_parts = []
        chunk_index = 0

        # Process chunks
        offset = 0
        while offset < len(audio_array):
            chunk_index += 1
            chunk_end = min(offset + chunk_samples, len(audio_array))
            chunk = audio_array[offset:chunk_end]

            # Convert back to bytes for transcribe
            chunk_bytes = self._audio_processor.array_to_bytes(chunk)

            logger.debug("Whisper chunk %d/%d (%.1fs - %.1fs)", chunk_index, n_chunks, offset / sr, chunk_end / sr)
            # Transcribe chunk
            result = await self.transcribe(chunk_bytes, sr, language)

            if result.text:
                full_text_parts.append(result.text)

                # Adjust segment timestamps
                if result.segments:
                    time_offset = offset / sr
                    for seg in result.segments:
                        seg["start"] += time_offset
                        seg["end"] += time_offset
                    all_segments.extend(result.segments)

            # Move to next chunk with overlap
            offset += chunk_samples - overlap_samples

        # Combine results
        combined_text = " ".join(full_text_parts)

        # Remove duplicate words at chunk boundaries
        combined_text = self._remove_overlap_duplicates(combined_text)

        processing_time = time.time() - start_time

        return STTResult(
            text=combined_text,
            confidence=0.85,  # Slightly lower for long audio
            language=language or "en",
            processing_time=processing_time,
            provider=self.get_provider_name(),
            is_partial=False,
            is_final=True,
            segments=all_segments if all_segments else None,
            metadata={
                "chunks_processed": len(full_text_parts),
                "total_duration_s": duration_s,
            },
        )

    def _remove_overlap_duplicates(self, text: str) -> str:
        """Remove duplicate words at chunk boundaries."""
        words = text.split()
        if len(words) < 2:
            return text

        # Simple deduplication: remove consecutive duplicate words
        result = [words[0]]
        for word in words[1:]:
            if word.lower() != result[-1].lower():
                result.append(word)

        return " ".join(result)

    def get_model_info(self) -> Dict[str, Any]:
        """Get model information."""
        info = super().get_model_info()
        info.update(
            {
                "model_path": self.config.model_path,
                "device": self._device,
                "dtype": str(self._torch_dtype) if self._torch_dtype else None,
                "chunk_length_s": self.config.chunk_length_s,
                "beam_size": self.config.beam_size,
            }
        )
        return info
