"""
STT Engine - Main Orchestrator.

Production-ready implementation with:
- Thread-safe metrics using asyncio.Lock
- Correlation ID propagation for distributed tracing
- Async context manager support
- Proper exception chaining
- Structured logging

Real-time voice (path to <300 ms E2E):
- Prefer ElevenLabs as primary_provider and use transcribe_streaming() for
  partials and lower first-token latency (e.g. stt.first_result.latency).
- In voice-mode CustomSTT, set use_streaming_for_segment=True to feed segments
  to transcribe_streaming() for interim results.
- For Whisper fallback: set streaming_chunk_length_s=5.0 (and optionally
  chunk_length_s=10.0, overlap_s=1.0) in providers.yml for lower latency.
- SLO targets: config.metrics.slo_first_result_latency_ms (e.g. 200 ms),
  alert_first_result_p95_ms (e.g. 500 ms) for dashboards/alerting.
"""

import asyncio
import logging
import os
import time
import uuid
from typing import Optional, Dict, Any, AsyncIterator, List, Union, Tuple, TYPE_CHECKING
from dataclasses import dataclass
from collections import deque
from weakref import WeakSet

import numpy as np

if TYPE_CHECKING:
    from typing_extensions import TypedDict

    class MetricsDict(TypedDict, total=False):
        """Type definition for metrics dictionary."""

        transcriptions: int
        total_audio_duration: float
        total_processing_time: float
        errors: int
        errors_by_type: Dict[str, int]
        no_speech_detected: int
        streaming_sessions: int
        latencies: deque
        first_result_latencies: deque
        total_cost: int
        cost_by_provider: Dict[str, int]
else:
    # Runtime: use Dict[str, Any] for compatibility
    MetricsDict = Dict[str, Any]

from .base_stt import (
    BaseSTTProvider,
    STTResult,
    Emotion,
    STTError,
    TranscriptionError,
    AudioFormatError,
)
from .config import STTConfig
from .audio_processor import AudioProcessor, AudioProcessingError, AudioValidationError, AudioFormatDetector
from .vad_processor import VADProcessor
from .emotion_detector import EmotionDetector, EmotionResult
from .stt_strategy import STTStrategy

logger = logging.getLogger(__name__)

# External metrics exporter (optional)
try:
    from .base_stt import get_metrics_exporter

    _METRICS_EXPORTER_AVAILABLE = True
except ImportError:

    def get_metrics_exporter():
        class NoOpMetrics:
            def increment(self, *args, **kwargs):
                pass

            def gauge(self, *args, **kwargs):
                pass

            def histogram(self, *args, **kwargs):
                pass

        return NoOpMetrics()

    _METRICS_EXPORTER_AVAILABLE = False


# Security layer imports - optional to allow standalone usage
_SECURITY_AVAILABLE = False
_RATE_LIMITER_AVAILABLE = False
_AUDIT_LOGGER_AVAILABLE = False
_INPUT_VALIDATOR_AVAILABLE = False
_ERROR_HANDLER_AVAILABLE = False

try:
    from narrative_ai.security.rate_limiting import (
        RateLimiter,
        EndpointCosts,
        RateLimitExceeded,
        UserTier,
    )

    _RATE_LIMITER_AVAILABLE = True
except ImportError:
    RateLimiter = None
    EndpointCosts = None
    RateLimitExceeded = None
    UserTier = None

try:
    from narrative_ai.security.audit_trail import AuditLogger, ActionType, ActionStatus

    _AUDIT_LOGGER_AVAILABLE = True
except ImportError:
    AuditLogger = None
    ActionType = None
    ActionStatus = None

try:
    from narrative_ai.security.input_validation import validate_audio, ValidationError as InputValidationError

    _INPUT_VALIDATOR_AVAILABLE = True
except ImportError:
    validate_audio = None
    InputValidationError = None

try:
    from narrative_ai.security.error_handling import SecureErrorHandler

    _ERROR_HANDLER_AVAILABLE = True
except ImportError:
    SecureErrorHandler = None

_SECURITY_AVAILABLE = any(
    [
        _RATE_LIMITER_AVAILABLE,
        _AUDIT_LOGGER_AVAILABLE,
        _INPUT_VALIDATOR_AVAILABLE,
        _ERROR_HANDLER_AVAILABLE,
    ]
)

if not _SECURITY_AVAILABLE:
    logger.warning("Security layer not available - running without security integration")


@dataclass
class TranscriptionResult:
    """
    Complete transcription result with all metadata.

    Combines STT result with emotion detection and processing metrics.
    """

    # Core transcription
    text: str
    confidence: float
    language: str

    # Provider info
    provider: str
    processing_time: float

    # Emotion (optional)
    emotion: Optional[Emotion] = None
    emotion_confidence: Optional[float] = None

    # Timestamps
    segments: Optional[List[Dict[str, Any]]] = None
    words: Optional[List[Dict[str, Any]]] = None

    # Streaming
    is_partial: bool = False
    is_final: bool = True

    # Additional metadata
    metadata: Optional[Dict[str, Any]] = None

    @classmethod
    def from_stt_result(
        cls,
        stt_result: STTResult,
        emotion_result: Optional[EmotionResult] = None,
    ) -> "TranscriptionResult":
        """Create from STTResult with optional emotion."""
        emotion = None
        emotion_confidence = None

        if emotion_result:
            emotion = emotion_result.emotion
            emotion_confidence = emotion_result.confidence
        elif stt_result.emotion:
            emotion = stt_result.emotion
            emotion_confidence = stt_result.emotion_confidence

        return cls(
            text=stt_result.text,
            confidence=stt_result.confidence,
            language=stt_result.language,
            provider=stt_result.provider,
            processing_time=stt_result.processing_time,
            emotion=emotion,
            emotion_confidence=emotion_confidence,
            segments=stt_result.segments,
            words=stt_result.words,
            is_partial=stt_result.is_partial,
            is_final=stt_result.is_final,
            metadata=stt_result.metadata,
        )

    @classmethod
    def empty_result(cls, reason: str = "No speech detected") -> "TranscriptionResult":
        """Create an empty result for no-speech scenarios."""
        return cls(
            text="",
            confidence=0.0,
            language="unknown",
            provider="none",
            processing_time=0.0,
            metadata={"reason": reason},
        )


class STTEngine:
    """
    Main STT Engine - Central orchestrator for Speech-to-Text.

    Production Features:
    - Thread-safe metrics with asyncio.Lock
    - Correlation ID propagation for tracing
    - Async context manager support (async with)
    - Proper exception chaining
    - Structured logging

    Example:
        # Using context manager (recommended)
        async with STTEngine() as engine:
            result = await engine.transcribe(audio_bytes, extract_emotion=True)
            print(f"Text: {result.text}")

        # Manual lifecycle management
        engine = STTEngine()
        await engine.initialize()
        try:
            result = await engine.transcribe(...)
        finally:
            await engine.shutdown()
    """

    def __init__(
        self,
        config: Optional[STTConfig] = None,
    ):
        """
        Initialize STT Engine.

        Args:
            config: Engine configuration (uses defaults/env if not provided)
        """
        self.config = config or STTConfig.from_env()

        # Components (lazy initialized)
        self._strategy: Optional[STTStrategy] = None
        self._audio_processor: Optional[AudioProcessor] = None
        self._vad: Optional[VADProcessor] = None
        self._emotion_detector: Optional[EmotionDetector] = None

        # Security components (optional)
        self._rate_limiter: Optional[Any] = None
        self._audit_logger: Optional[Any] = None
        self._error_handler: Optional[Any] = None

        # State
        self._initialized = False

        # Track active streams for cleanup (weak references)
        self._active_streams: WeakSet = WeakSet()

        # Thread-safe metrics with lock
        self._metrics_lock = asyncio.Lock()
        # Use bounded deque for latencies - O(1) append, automatic memory management
        max_latency_samples = self.config.metrics.max_latency_samples
        self._metrics: MetricsDict = {
            "transcriptions": 0,
            "total_audio_duration": 0.0,
            "total_processing_time": 0.0,
            "errors": 0,
            "errors_by_type": {},
            "no_speech_detected": 0,
            "streaming_sessions": 0,
            "latencies": deque(maxlen=max_latency_samples),  # Bounded deque for percentile calculation
            "first_result_latencies": deque(
                maxlen=max_latency_samples
            ),  # Time to first transcription (streaming/batch)
            "total_cost": 0,  # Total cost units consumed
            "cost_by_provider": {},  # Cost per provider
        }

        # External metrics exporter
        self._external_metrics = get_metrics_exporter()

        # Cache for frequently accessed config values (performance optimization)
        self._cached_vad_enabled: Optional[bool] = None

    async def __aenter__(self) -> "STTEngine":
        """Async context manager entry."""
        await self.initialize()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.shutdown()

    def _generate_correlation_id(self) -> str:
        """Generate a unique correlation ID for request tracing."""
        return f"stt-{uuid.uuid4().hex[:12]}"

    def _calculate_audio_duration(
        self,
        audio_data: Union[np.ndarray, bytes],
        sample_rate: int,
        is_array: bool = True,
        channels: int = 1,
        bit_depth: int = 16,
    ) -> float:
        """
        Calculate audio duration accounting for format differences.

        Args:
            audio_data: Audio as numpy array or bytes
            sample_rate: Sample rate in Hz
            is_array: True if audio_data is numpy array, False if bytes
            channels: Number of audio channels (1=mono, 2=stereo)
            bit_depth: Bits per sample (16, 24, 32)

        Returns:
            Duration in seconds
        """
        if sample_rate <= 0:
            return 0.0

        if is_array:
            # For numpy arrays: shape determines samples
            if isinstance(audio_data, np.ndarray):
                if audio_data.ndim == 1:
                    # Mono: shape is (samples,)
                    num_samples = len(audio_data)
                elif audio_data.ndim == 2:
                    # Multi-channel: shape is (channels, samples) or (samples, channels)
                    # Assume (samples, channels) format
                    num_samples = audio_data.shape[0]
                else:
                    # Unknown format, fallback
                    num_samples = len(audio_data)
            else:
                num_samples = len(audio_data)

            # Duration = samples / sample_rate
            return num_samples / sample_rate
        else:
            # For bytes: calculate from byte length
            if not isinstance(audio_data, bytes):
                audio_data = bytes(audio_data)

            bytes_per_sample = (bit_depth // 8) * channels
            num_samples = len(audio_data) / bytes_per_sample

            return num_samples / sample_rate

    async def _retry_empty_transcription(
        self,
        result: "TranscriptionResult",
        audio_array: np.ndarray,
        full_audio_for_retry: Optional[np.ndarray],
        first_language: Optional[str],
        sample_rate: int,
        provider: Optional[str],
        correlation_id: str,
        emotion_result: Optional[Any],
    ) -> Tuple["TranscriptionResult", np.ndarray]:
        """Retry with opposite language when first pass is empty. ar→en first; en→ar; auto→en then ar."""
        retry_audio = (
            self._audio_processor.array_to_bytes(full_audio_for_retry)
            if full_audio_for_retry is not None
            else self._audio_processor.array_to_bytes(audio_array)
        )
        # Retry order: ar→(en,ar); en→(ar,); auto/None→(en,ar)
        if first_language == "ar":
            retry_langs = ("en", "ar")
        elif first_language == "en":
            retry_langs = ("ar",)
        else:
            retry_langs = ("en", "ar")
        for lang in retry_langs:
            logger.info(
                "STT empty; retrying with language=%s (TTS/synthetic or --no-vad)",
                lang,
                extra={"correlation_id": correlation_id},
            )
            stt_retry = await self._strategy.transcribe(
                retry_audio,
                sample_rate=sample_rate,
                language=lang,
                provider=provider,
                correlation_id=correlation_id,
                use_provider_vad=False,
            )
            res = TranscriptionResult.from_stt_result(stt_retry, emotion_result)
            if (res.text or "").strip():
                arr = full_audio_for_retry if full_audio_for_retry is not None else audio_array
                return res, arr
        return result, audio_array

    async def initialize(self) -> None:
        """
        Initialize the engine and all components.

        Call this before using the engine. Safe to call multiple times.
        Implements rollback on partial failure to prevent resource leaks.
        """
        if self._initialized:
            return

        logger.info("Initializing STT Engine...")
        start_time = time.time()

        # Track initialized components for rollback on failure
        initialized_components = []

        try:
            # Initialize audio processor
            self._audio_processor = AudioProcessor(
                target_sample_rate=self.config.audio.target_sample_rate,
                target_channels=self.config.audio.target_channels,
                normalize=self.config.audio.normalize_audio,
                max_duration_s=self.config.audio.max_duration_s,
                max_size_bytes=self.config.audio.max_size_bytes,
            )
            initialized_components.append(("audio_processor", self._audio_processor))

            # Initialize VAD (optional: if webrtcvad not installed, disable VAD and continue)
            if self.config.vad.enabled:
                try:
                    self._vad = VADProcessor(
                        sample_rate=self.config.vad.sample_rate,
                        frame_duration_ms=self.config.vad.frame_duration_ms,
                        mode=self.config.vad.mode,
                        speech_start_frames=self.config.vad.speech_start_frames,
                        speech_end_frames=self.config.vad.speech_end_frames,
                        min_speech_duration_ms=self.config.vad.min_speech_duration_ms,
                        max_speech_duration_ms=self.config.vad.max_speech_duration_ms,
                    )
                    initialized_components.append(("vad", self._vad))
                    logger.info("VAD initialized")
                except ImportError:
                    logger.warning(
                        "VAD enabled but webrtcvad not installed. Disabling VAD. "
                        "Run: pip install webrtcvad for speech segment filtering."
                    )
                    self._vad = None
                # Reset cache when VAD is initialized (or disabled)
                self._cached_vad_enabled = None

            # Initialize emotion detector
            if self.config.emotion.enabled:
                self._emotion_detector = EmotionDetector(self.config.emotion)
                initialized_components.append(("emotion_detector", self._emotion_detector))
                logger.info("Emotion detector initialized")

            # Initialize provider strategy
            self._strategy = STTStrategy.from_config(self.config)
            initialized_components.append(("strategy", self._strategy))
            await self._strategy.initialize()

            # Initialize security components if available and enabled
            if _SECURITY_AVAILABLE:
                # Skip rate limiter when VOICE_DEV_SKIP_RATE_LIMIT=1 (dev only; never in production)
                is_production = os.getenv("ENV", "").lower() == "production"
                skip_rate_limit = not is_production and os.getenv("VOICE_DEV_SKIP_RATE_LIMIT", "").strip() == "1"
                if self.config.integration.enable_rate_limiting and not skip_rate_limit and RateLimiter:
                    try:
                        self._rate_limiter = RateLimiter()
                        initialized_components.append(("rate_limiter", self._rate_limiter))
                        logger.info("Rate limiter initialized")
                    except Exception as e:
                        logger.warning(f"Failed to initialize rate limiter: {e}")

                if self.config.integration.enable_audit_logging and AuditLogger:
                    try:
                        audit_db_url = os.getenv("AUDIT_DATABASE_URL") or os.getenv("DATABASE_URL")
                        if audit_db_url:
                            self._audit_logger = AuditLogger(database_url=audit_db_url)
                            initialized_components.append(("audit_logger", self._audit_logger))
                            logger.info("Audit logger initialized")
                        else:
                            logger.warning("Audit logging enabled but DATABASE_URL not set")
                    except Exception as e:
                        logger.warning(f"Failed to initialize audit logger: {e}")

                if SecureErrorHandler:
                    try:
                        self._error_handler = SecureErrorHandler()
                        initialized_components.append(("error_handler", self._error_handler))
                        logger.info("Secure error handler initialized")
                    except Exception as e:
                        logger.warning(f"Failed to initialize error handler: {e}")

            self._initialized = True
            init_time = time.time() - start_time
            logger.info(f"STT Engine initialized in {init_time:.2f}s")

        except Exception as e:
            # Rollback: cleanup what was initialized
            logger.error(
                "STT Engine initialization failed, cleaning up resources",
                extra={"error": str(e), "error_type": type(e).__name__},
                exc_info=True,
            )

            for name, component in reversed(initialized_components):
                try:
                    if hasattr(component, "shutdown"):
                        await component.shutdown()
                    elif hasattr(component, "close"):
                        if asyncio.iscoroutinefunction(component.close):
                            await component.close()
                        else:
                            component.close()
                    logger.debug(f"Cleaned up {name} during rollback")
                except Exception as cleanup_error:
                    logger.error(
                        f"Failed to cleanup {name} during rollback", extra={"error": str(cleanup_error)}, exc_info=True
                    )

            # Reset state
            self._audio_processor = None
            self._vad = None
            self._emotion_detector = None
            self._strategy = None
            self._rate_limiter = None
            self._audit_logger = None
            self._error_handler = None
            self._initialized = False

            raise

    async def shutdown(self) -> None:
        """
        Shutdown the engine and cleanup resources.

        Shuts down all components in reverse order of initialization
        to ensure proper cleanup and prevent resource leaks.
        """
        if not self._initialized:
            return

        logger.info("Shutting down STT Engine...")

        shutdown_errors = []

        # Shutdown in reverse order of initialization
        if self._strategy:
            try:
                await self._strategy.shutdown()
            except Exception as e:
                shutdown_errors.append(("strategy", str(e)))
                logger.error(f"Error shutting down strategy: {e}", exc_info=True)

        if self._emotion_detector:
            try:
                if hasattr(self._emotion_detector, "shutdown"):
                    await self._emotion_detector.shutdown()
            except Exception as e:
                shutdown_errors.append(("emotion_detector", str(e)))
                logger.error(f"Error shutting down emotion detector: {e}", exc_info=True)

        if self._vad:
            try:
                if hasattr(self._vad, "shutdown"):
                    await self._vad.shutdown()
            except Exception as e:
                shutdown_errors.append(("vad", str(e)))
                logger.error(f"Error shutting down VAD: {e}", exc_info=True)

        # Cleanup security components
        if self._rate_limiter:
            try:
                if hasattr(self._rate_limiter, "shutdown"):
                    await self._rate_limiter.shutdown()
            except Exception as e:
                shutdown_errors.append(("rate_limiter", str(e)))
                logger.error(f"Error shutting down rate limiter: {e}", exc_info=True)

        if self._audit_logger:
            try:
                if hasattr(self._audit_logger, "shutdown"):
                    await self._audit_logger.shutdown()
            except Exception as e:
                shutdown_errors.append(("audit_logger", str(e)))
                logger.error(f"Error shutting down audit logger: {e}", exc_info=True)

        if self._error_handler:
            try:
                if hasattr(self._error_handler, "shutdown"):
                    await self._error_handler.shutdown()
            except Exception as e:
                shutdown_errors.append(("error_handler", str(e)))
                logger.error(f"Error shutting down error handler: {e}", exc_info=True)

        # Reset all references
        self._strategy = None
        self._emotion_detector = None
        self._vad = None
        self._audio_processor = None
        self._rate_limiter = None
        self._audit_logger = None
        self._error_handler = None
        self._initialized = False
        self._cached_vad_enabled = None

        # Export shutdown metric
        self._external_metrics.gauge("stt.engine.initialized", 0)

        if shutdown_errors:
            logger.warning("Some components failed to shutdown cleanly", extra={"errors": shutdown_errors})
        else:
            logger.info("STT Engine shutdown complete")

    def _check_rate_limit(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        user_tier: Optional["UserTier"] = None,
    ) -> None:
        """
        Check rate limit if enabled.

        When user_id or tenant_id is None, uses shared anonymous bucket (OWASP API4:
        unrestricted resource consumption) - all unauthenticated requests share FREE tier limits.

        Args:
            user_id: User ID for rate limiting
            tenant_id: Tenant ID for rate limiting
            user_tier: User subscription tier (defaults to FREE for security)

        Raises:
            RateLimitExceeded: If rate limit exceeded
        """
        if not self._rate_limiter:
            return

        try:
            from narrative_ai.security.rate_limiting import UserTier

            def _to_uuid(val: Any, name: str, anon_namespace: str):
                if val is None:
                    return uuid.uuid5(uuid.NAMESPACE_DNS, anon_namespace)
                if isinstance(val, uuid.UUID):
                    return val
                try:
                    return uuid.UUID(str(val))
                except (ValueError, TypeError):
                    return uuid.uuid5(uuid.NAMESPACE_DNS, f"stt.{name}.{val}")

            # Anonymous bucket: all unauthenticated requests share FREE tier limits
            anon_ns = "anon.engine.stt"
            user_uuid = _to_uuid(user_id, "user", anon_ns)
            tenant_uuid = _to_uuid(tenant_id, "tenant", anon_ns)

            # Tier lookup: explicit param > callback (DB/cache) > FREE (secure default)
            if user_tier is not None:
                tier = user_tier
            else:
                cb = getattr(self.config.integration, "user_tier_callback", None)
                if cb and (user_id or tenant_id):
                    try:
                        looked_up = cb(user_id, tenant_id)
                        tier = looked_up if looked_up is not None else UserTier.FREE
                    except Exception as e:
                        logger.debug("User tier lookup failed, using FREE: %s", e)
                        tier = UserTier.FREE
                else:
                    tier = UserTier.FREE

            self._rate_limiter.check_rate_limit(
                tenant_id=tenant_uuid,
                user_id=user_uuid,
                tier=tier,
                endpoint_cost=EndpointCosts.STT.value,
            )
        except Exception as e:
            # Use isinstance when RateLimitExceeded is available (robust against
            # class renames; matches TTS/LLM pattern)
            if RateLimitExceeded is not None and isinstance(e, RateLimitExceeded):
                self._external_metrics.increment("stt.rate_limited")
                raise
            # Fail closed: re-raise on unexpected errors (Redis down, bug, etc.)
            logger.warning(f"Rate limit check failed: {e}")
            raise

    def _log_audit(
        self,
        user_id: Optional[str],
        tenant_id: Optional[str],
        status: str,
        details: Dict[str, Any],
        correlation_id: Optional[str] = None,
    ) -> None:
        """
        Log audit event if enabled.

        When user_id/tenant_id is None (anonymous), uses anonymous bucket UUIDs so
        we still get audit trail with correlation_id for traceability.

        Args:
            user_id: User ID
            tenant_id: Tenant ID
            status: Action status
            details: Additional details
            correlation_id: Request correlation ID
        """
        if not self._audit_logger:
            return

        # Include correlation ID in audit
        details["correlation_id"] = correlation_id

        def _audit_uuid(val):
            if val is None:
                return None
            if isinstance(val, uuid.UUID):
                return val
            try:
                return uuid.UUID(str(val))
            except (ValueError, TypeError):
                return uuid.uuid5(uuid.NAMESPACE_DNS, f"stt.audit.{val}")

        try:
            if user_id and tenant_id:
                uid = _audit_uuid(user_id)
                tid = _audit_uuid(tenant_id)
                if uid is None or tid is None:
                    return
            else:
                # Anonymous: use bucket UUIDs for traceability (correlation_id in details)
                tid = uuid.uuid5(uuid.NAMESPACE_DNS, "anon.engine.stt")
                uid = uuid.uuid5(uuid.NAMESPACE_DNS, f"anon.engine.stt.{correlation_id or uuid.uuid4()}")
            self._audit_logger.log_action(
                user_id=uid,
                tenant_id=tid,
                action=ActionType.TRANSCRIBE,
                resource_type="stt_transcription",
                resource_id=uuid.uuid4(),
                status=ActionStatus.SUCCESS if status == "success" else ActionStatus.FAILURE,
                details=details,
            )
        except Exception as e:
            logger.warning("Audit logging failed", extra={"correlation_id": correlation_id, "error": str(e)})

    def _validate_audio_security(
        self,
        audio: bytes,
        sample_rate: int,
    ) -> None:
        """
        Validate audio using security layer if available.

        Note: Security layer's validate_audio expects audio FILE bytes (WAV, MP3, etc.),
        not raw PCM bytes. For raw PCM, we skip security validation and rely on
        internal AudioProcessor validation.

        Args:
            audio: Audio bytes
            sample_rate: Sample rate

        Raises:
            AudioFormatError: If validation fails
        """
        if not _INPUT_VALIDATOR_AVAILABLE or not validate_audio:
            return

        if not self.config.integration.enable_input_validation:
            return

        # Pre-decoded float32 array (e.g. from librosa) — skip file-magic check
        if isinstance(audio, np.ndarray):
            duration = len(audio) / sample_rate if sample_rate and sample_rate > 0 else 0
            if duration > self.config.audio.max_duration_s:
                raise AudioFormatError(
                    f"Audio duration {duration:.1f}s exceeds maximum {self.config.audio.max_duration_s}s"
                )
            return

        # Use AudioFormatDetector utility to check if this is an audio file
        # Raw PCM bytes will skip file validation and use AudioProcessor validation instead
        if not AudioFormatDetector.is_audio_file(audio):
            # This is raw PCM bytes - perform PCM-specific validation (no security bypass)
            # Min size: 320 bytes = 10ms at 16kHz 16-bit mono (reject empty/tiny bypass attempts)
            bytes_per_sample = 2  # 16-bit = 2 bytes
            min_pcm_bytes = 320
            if len(audio) < min_pcm_bytes:
                raise AudioFormatError(f"PCM audio too small: {len(audio)} bytes (minimum: {min_pcm_bytes} bytes)")
            samples = len(audio) // bytes_per_sample
            duration = samples / sample_rate if sample_rate > 0 else 0
            if duration > self.config.audio.max_duration_s:
                raise AudioFormatError(
                    f"PCM audio duration {duration:.1f}s exceeds maximum {self.config.audio.max_duration_s}s"
                )

            if len(audio) > self.config.audio.max_size_bytes:
                raise AudioFormatError(
                    f"PCM audio size {len(audio)} bytes exceeds maximum {self.config.audio.max_size_bytes} bytes"
                )

            # PCM validation passed, return early
            return

        try:
            validate_audio(
                audio,
                min_size=100,  # 100 bytes minimum for files
                max_size=self.config.audio.max_size_bytes,
                max_duration=self.config.audio.max_duration_s,
            )
        except Exception as e:
            logger.warning(f"Security validation failed: {e}")
            raise AudioFormatError(f"Audio validation failed: {e}")

    async def transcribe(
        self,
        audio: bytes,
        sample_rate: int = 16000,
        language: Optional[str] = None,
        extract_emotion: bool = True,
        use_vad: bool = True,
        provider: Optional[str] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        user_tier: Optional["UserTier"] = None,
        correlation_id: Optional[str] = None,
    ) -> TranscriptionResult:
        """
        Transcribe audio to text.

        Args:
            audio: Audio data as bytes (16-bit PCM)
            sample_rate: Audio sample rate in Hz
            language: Language code ("ar", "en", or None for auto-detect)
            extract_emotion: Whether to detect emotion from voice
            use_vad: Whether to use VAD preprocessing
            provider: Force specific provider (skip fallback)
            user_id: User ID for rate limiting and audit logging
            tenant_id: Tenant ID for rate limiting and audit logging
            user_tier: User subscription tier (defaults to FREE for security)
            correlation_id: Request correlation ID (auto-generated if not provided)

        Returns:
            TranscriptionResult with text, emotion, and metadata

        Raises:
            TranscriptionError: If transcription fails
            AudioValidationError: If audio is invalid
            RateLimitExceeded: If rate limit exceeded
        """
        if not self._initialized:
            await self.initialize()

        # Generate correlation ID if not provided
        if not correlation_id:
            correlation_id = self._generate_correlation_id()

        start_time = time.time()
        audio_duration = 0.0  # Initialize for error handling

        # Early return for empty audio (avoids validation error and gives predictable result)
        if audio is None:
            await self._update_metrics(0, 0.0, success=True, no_speech=True)
            return TranscriptionResult.empty_result("No audio provided")
        if isinstance(audio, bytes) and len(audio) == 0:
            await self._update_metrics(0, 0.0, success=True, no_speech=True)
            return TranscriptionResult.empty_result("Empty audio")
        if isinstance(audio, np.ndarray) and (audio.size == 0 or len(audio) == 0):
            await self._update_metrics(0, 0.0, success=True, no_speech=True)
            return TranscriptionResult.empty_result("Empty audio")

        try:
            # Check rate limit
            self._check_rate_limit(user_id, tenant_id, user_tier)

            # Security validation
            self._validate_audio_security(audio, sample_rate)

            # Size check for bytes (avoid converting twice: preprocess does bytes→array once)
            if isinstance(audio, bytes) and len(audio) > self.config.audio.max_size_bytes:
                raise AudioValidationError(
                    f"Audio size {len(audio)} exceeds maximum {self.config.audio.max_size_bytes} bytes"
                )

            # Preprocess audio (single bytes→array conversion)
            audio_array, sr = self._audio_processor.preprocess(
                audio,
                input_sample_rate=sample_rate,
            )

            # Validate preprocessed audio (duration, empty, silence)
            self._audio_processor.validate(audio_array, sr)

            # When VAD finds no segments we may still transcribe full audio (TTS/synthetic); then disable provider internal VAD
            used_vad_fallback = False
            full_audio_for_retry = None  # keep full audio when VAD had segments, for empty-result retry
            speech_audio_bytes = None  # Keep VAD output as bytes to avoid unnecessary conversion

            # Apply VAD if enabled (using cached check for performance)
            if use_vad and self._vad_enabled:
                # Convert to bytes once for VAD (VAD requires 16-bit PCM bytes)
                audio_bytes = self._audio_processor.array_to_bytes(audio_array)
                original_size = len(audio_bytes)

                try:
                    segments = self._vad.process_audio(audio_bytes)
                except Exception as e:
                    # Fallback to non-VAD: use full audio to prevent pipeline failure (OWASP resilience)
                    logger.warning(
                        f"VAD processing failed, using full audio: {e}",
                        extra={"correlation_id": correlation_id},
                        exc_info=False,
                    )
                    segments = None  # Will trigger full-audio fallback below

                if segments:
                    # Keep full audio in case first pass returns empty (e.g. TTS with wrong language)
                    full_audio_for_retry = np.array(audio_array, copy=True)
                    # Concatenate speech segments (keep as bytes - no conversion needed yet)
                    speech_audio_bytes = b"".join(seg.audio for seg in segments)
                    filtered_size = len(speech_audio_bytes)

                    # Calculate VAD reduction ratio for metrics
                    reduction_ratio = 1.0 - (filtered_size / original_size) if original_size > 0 else 0.0

                    logger.debug(
                        "VAD processed",
                        extra={
                            "correlation_id": correlation_id,
                            "segments": len(segments),
                            "bytes": len(speech_audio_bytes),
                            "reduction_ratio": reduction_ratio,
                        },
                    )

                    # Export VAD metrics if enabled
                    if self.config.metrics.export_vad_metrics and _SECURITY_AVAILABLE:
                        self._external_metrics.histogram(
                            "stt.vad.reduction_ratio", reduction_ratio, tags={"correlation_id": correlation_id}
                        )
                        self._external_metrics.increment(
                            "stt.vad.segments_detected", value=len(segments), tags={"correlation_id": correlation_id}
                        )
                else:
                    # No speech detected by VAD (e.g. TTS/synthetic or unusual profile)
                    if getattr(self.config.vad, "retry_with_full_audio_on_no_speech", True):
                        used_vad_fallback = True
                        logger.info(
                            "VAD: No segments; using full audio (TTS/synthetic-friendly fallback)",
                            extra={"correlation_id": correlation_id},
                        )
                        # Keep audio_array as-is (full audio) and fall through to transcription
                    else:
                        logger.info("VAD: No speech detected", extra={"correlation_id": correlation_id})
                        await self._update_metrics(0, time.time() - start_time, success=True, no_speech=True)
                        result = TranscriptionResult.empty_result("No speech detected by VAD")
                        result.processing_time = time.time() - start_time
                        self._log_audit(
                            user_id,
                            tenant_id,
                            "success",
                            {
                                "provider": "vad",
                                "result": "no_speech",
                                "processing_time": result.processing_time,
                            },
                            correlation_id,
                        )
                        return result

            # Detect emotion before transcription (optional)
            # Only convert to array if emotion detection is needed
            emotion_result = None
            if extract_emotion and self._emotion_detector:
                try:
                    # Use speech_audio_bytes if available (VAD filtered), otherwise use full audio_array
                    if speech_audio_bytes is not None:
                        # Convert VAD output to array for emotion detection
                        emotion_audio_array = self._audio_processor._bytes_to_array(speech_audio_bytes)
                    else:
                        # Use existing array (no VAD or VAD fallback)
                        emotion_audio_array = audio_array

                    emotion_result = await self._emotion_detector.detect_emotion(emotion_audio_array, sr)
                    logger.debug(
                        "Emotion detected",
                        extra={
                            "correlation_id": correlation_id,
                            "emotion": emotion_result.emotion.value,
                            "confidence": emotion_result.confidence,
                        },
                    )
                except Exception as e:
                    logger.warning(
                        f"Emotion detection failed: {e}", extra={"correlation_id": correlation_id}, exc_info=True
                    )
                    # Never fail transcription on emotion failure; emotion is optional
                    emotion_result = None

            # When VAD had segments we send full audio (not segments). Use caller language for first pass
            # (fast). When VAD fallback (no segments, e.g. TTS/synthetic), use auto-detect for best results.
            # When user disabled VAD (--no-vad), also disable provider internal VAD so TTS isn't filtered.
            use_auto_detect = used_vad_fallback or (full_audio_for_retry is not None)
            transcribe_language = None if used_vad_fallback else language  # auto on TTS fallback; caller lang otherwise
            use_provider_vad_flag = False if (use_auto_detect or not use_vad) else None

            # Optimize: Use bytes directly when available (from VAD), avoid unnecessary conversion
            if use_auto_detect and full_audio_for_retry is not None:
                # Need to convert full audio for retry
                processed_audio = self._audio_processor.array_to_bytes(full_audio_for_retry)
            elif speech_audio_bytes is not None:
                # Use VAD output directly (already bytes) - avoid array→bytes conversion
                processed_audio = speech_audio_bytes
            else:
                # No VAD or VAD fallback - convert array to bytes
                processed_audio = self._audio_processor.array_to_bytes(audio_array)

            stt_result = await self._strategy.transcribe(
                processed_audio,
                sample_rate=sr,
                language=transcribe_language,
                provider=provider,
                correlation_id=correlation_id,
                use_provider_vad=use_provider_vad_flag,
            )

            # Combine results
            result = TranscriptionResult.from_stt_result(stt_result, emotion_result)

            # First pass used full audio when use_auto_detect and full_audio_for_retry; keep for duration/metrics
            if use_auto_detect and full_audio_for_retry is not None:
                audio_array = full_audio_for_retry

            # Retry on empty: try opposite language first (ar→en, en→ar) to avoid second pass when possible
            if (not (result.text or "").strip()) and getattr(
                self.config.vad, "retry_with_full_audio_on_no_speech", True
            ):
                result, audio_array = await self._retry_empty_transcription(
                    result=result,
                    audio_array=audio_array,
                    full_audio_for_retry=full_audio_for_retry,
                    first_language=language,
                    sample_rate=sr,
                    provider=provider,
                    correlation_id=correlation_id,
                    emotion_result=emotion_result,
                )

            # Update metrics (thread-safe)
            processing_time = time.time() - start_time
            result.processing_time = processing_time
            # Calculate duration accounting for format (numpy array, mono/stereo)
            audio_duration = self._calculate_audio_duration(audio_array, sr, is_array=True, channels=1)

            # Track cost (STT endpoint cost)
            endpoint_cost = EndpointCosts.STT.value if EndpointCosts else 5
            await self._update_metrics(
                audio_duration, processing_time, success=True, provider=result.provider, cost=endpoint_cost
            )
            # Batch: first result latency equals full processing time
            await self._record_first_result_latency(processing_time)

            # Export metrics to external systems (batch export for performance)
            if _SECURITY_AVAILABLE and EndpointCosts:
                tags = {
                    "provider": result.provider,
                    "success": "true",
                    "correlation_id": correlation_id,
                }

                # Export histogram metrics for latency and duration
                if self.config.metrics.export_histograms:
                    self._external_metrics.histogram("stt.transcription.latency", processing_time, tags=tags)
                    self._external_metrics.histogram("stt.first_result.latency", processing_time, tags=tags)
                    self._external_metrics.histogram("stt.audio.duration", audio_duration, tags=tags)

                # Export cost metrics
                self._external_metrics.increment(
                    "stt.cost.total", value=endpoint_cost, tags={"provider": result.provider}
                )
                # Thread-safe read and export of accumulated cost (atomic operation)
                async with self._metrics_lock:
                    accumulated_cost = self._metrics.get("total_cost", 0)
                    self._external_metrics.gauge("stt.cost.accumulated", accumulated_cost)

            # Log audit
            self._log_audit(
                user_id,
                tenant_id,
                "success",
                {
                    "provider": result.provider,
                    "language": result.language,
                    "confidence": result.confidence,
                    "emotion": result.emotion.value if result.emotion else None,
                    "processing_time": processing_time,
                    "audio_duration": audio_duration,
                },
                correlation_id,
            )

            if self.config.integration.log_performance_metrics:
                logger.info(
                    "Transcription completed",
                    extra={
                        "correlation_id": correlation_id,
                        "provider": result.provider,
                        "audio_duration": audio_duration,
                        "processing_time": processing_time,
                        "confidence": result.confidence,
                    },
                )

            return result

        except (AudioValidationError, AudioProcessingError) as e:
            await self._update_metrics(0, time.time() - start_time, success=False, error_type="validation")
            self._log_audit(user_id, tenant_id, "failure", {"error": str(e), "type": "validation"}, correlation_id)
            raise AudioFormatError(str(e)) from e

        except STTError:
            await self._update_metrics(0, time.time() - start_time, success=False, error_type="provider")
            self._log_audit(user_id, tenant_id, "failure", {"error": "STT error", "type": "provider"}, correlation_id)
            raise

        except Exception as e:
            await self._update_metrics(0, time.time() - start_time, success=False, error_type=type(e).__name__)
            self._log_audit(user_id, tenant_id, "failure", {"error": str(e), "type": "unknown"}, correlation_id)

            # Use secure error handler if available
            if self._error_handler:
                try:
                    self._error_handler.handle_error(e, user_id, tenant_id)
                except Exception as handler_error:
                    logger.warning(
                        "Error handler failed", extra={"correlation_id": correlation_id, "error": str(handler_error)}
                    )

            raise TranscriptionError(
                f"Transcription failed [{type(e).__name__}]: {e}",
                provider="engine",
                correlation_id=correlation_id,
                audio_duration=audio_duration if audio_duration > 0 else None,
                details={"original_error": str(e), "error_type": type(e).__name__},
            ) from e

    async def transcribe_streaming(
        self,
        audio_stream: AsyncIterator[bytes],
        sample_rate: int = 16000,
        language: Optional[str] = None,
        extract_emotion: bool = False,
        provider: Optional[str] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[TranscriptionResult]:
        """
        Stream transcription with interim results.

        Designed for real-time transcription with LiveKit integration.

        Args:
            audio_stream: Async iterator of audio chunks
            sample_rate: Audio sample rate
            language: Language code
            extract_emotion: Extract emotion (only on final result for streaming)
            provider: Force specific provider
            user_id: User ID for rate limiting
            tenant_id: Tenant ID for rate limiting
            correlation_id: Request correlation ID

        Yields:
            TranscriptionResult objects (partial and final)
        """
        if not self._initialized:
            await self.initialize()

        if not correlation_id:
            correlation_id = self._generate_correlation_id()

        # Check rate limit at start
        self._check_rate_limit(user_id, tenant_id, None)  # user_tier not available in this context

        start_time = time.time()
        accumulated_audio = bytearray()

        # Bounded buffer to prevent memory leaks in long streaming sessions
        # Always enforce a maximum buffer size to prevent unbounded growth
        # Config applies regardless of extract_emotion (fixes config being ignored when emotion off)
        default_buffer_size = 10 * 1024 * 1024  # 10MB default limit
        max_buffer_size = (
            self.config.audio.max_streaming_buffer_size_bytes
            if self.config.audio.max_streaming_buffer_size_bytes > 0
            else default_buffer_size
        )

        # Track streaming session
        async with self._metrics_lock:
            self._metrics["streaming_sessions"] += 1

        logger.info("STT streaming started", extra={"correlation_id": correlation_id})

        # Optional: process through VAD first
        if self._vad_enabled:
            # Use VAD's filter_speech_stream which processes frame-by-frame
            # while maintaining proper state across chunks
            async def vad_filtered_stream():
                nonlocal accumulated_audio
                # Reset VAD state for new stream (prefer public reset() from VADProcessor)
                if hasattr(self._vad, "reset"):
                    self._vad.reset()
                elif hasattr(self._vad, "reset_state"):
                    self._vad.reset_state()
                elif hasattr(self._vad, "_reset_state"):
                    self._vad._reset_state()  # Fallback to private method

                async for chunk in audio_stream:
                    # Accumulate for emotion detection later (with bounded buffer)
                    # Always enforce buffer limit to prevent memory leaks
                    # Implement sliding window: keep only recent audio
                    # Optimized approach: delete from front (O(n) but bounded by max_buffer_size)
                    # This is more efficient than creating new bytearray since we modify in-place
                    if len(accumulated_audio) + len(chunk) > max_buffer_size:
                        keep_bytes = max(0, max_buffer_size - len(chunk))
                        if keep_bytes > 0:
                            # Keep last keep_bytes; del [:-keep_bytes] removes older data from front
                            del accumulated_audio[:-keep_bytes]
                        else:
                            # Edge case: chunk >= max_buffer; clear buffer, chunk will be used alone
                            accumulated_audio.clear()
                        logger.debug(
                            "Streaming buffer limit reached, applying sliding window",
                            extra={
                                "correlation_id": correlation_id,
                                "buffer_size": len(accumulated_audio),
                                "chunk_size": len(chunk),
                                "max_size": max_buffer_size,
                            },
                        )
                    accumulated_audio.extend(chunk)

                    # Process each frame through VAD and yield if speech
                    async for frame in self._vad.filter_speech_stream(self._async_iter_single(chunk)):
                        yield frame

            processed_stream = vad_filtered_stream()
            # Track stream for cleanup
            self._active_streams.add(processed_stream)
        else:

            async def accumulating_stream():
                nonlocal accumulated_audio
                async for chunk in audio_stream:
                    # Accumulate for emotion detection later (with bounded buffer)
                    # Always enforce buffer limit to prevent memory leaks
                    # Implement sliding window: keep only recent audio
                    # Optimized approach: delete from front (O(n) but bounded by max_buffer_size)
                    # This is more efficient than creating new bytearray since we modify in-place
                    if len(accumulated_audio) + len(chunk) > max_buffer_size:
                        keep_bytes = max(0, max_buffer_size - len(chunk))
                        if keep_bytes > 0:
                            # Keep last keep_bytes; del [:-keep_bytes] removes older data from front
                            del accumulated_audio[:-keep_bytes]
                        else:
                            # Edge case: chunk >= max_buffer; clear buffer, chunk will be used alone
                            accumulated_audio.clear()
                        logger.debug(
                            "Streaming buffer limit reached, applying sliding window",
                            extra={
                                "correlation_id": correlation_id,
                                "buffer_size": len(accumulated_audio),
                                "chunk_size": len(chunk),
                                "max_size": max_buffer_size,
                            },
                        )
                    accumulated_audio.extend(chunk)
                    yield chunk

            processed_stream = accumulating_stream()
            # Track stream for cleanup
            self._active_streams.add(processed_stream)

        # Stream transcription
        first_yield = True
        try:
            async for stt_result in self._strategy.transcribe_streaming(
                processed_stream,
                sample_rate=sample_rate,
                language=language,
                provider=provider,
                correlation_id=correlation_id,
            ):
                # Record time-to-first-result (streaming) once
                if first_yield:
                    time_to_first = time.time() - start_time
                    await self._record_first_result_latency(time_to_first)
                    if self.config.metrics.export_histograms and _SECURITY_AVAILABLE:
                        self._external_metrics.histogram(
                            "stt.first_result.latency",
                            time_to_first,
                            tags={"provider": provider or "unknown", "correlation_id": correlation_id},
                        )
                    first_yield = False
                # For final result, optionally detect emotion
                emotion_result = None
                if stt_result.is_final and extract_emotion and self._emotion_detector and self._audio_processor:
                    if accumulated_audio:
                        try:
                            audio_array = self._audio_processor._bytes_to_array(bytes(accumulated_audio))
                            emotion_result = await self._emotion_detector.detect_emotion(audio_array, sample_rate)
                            # Clear buffer after emotion detection to free memory
                            accumulated_audio.clear()
                        except Exception as e:
                            logger.warning(
                                "Failed to detect emotion in streaming",
                                extra={"correlation_id": correlation_id, "error": str(e)},
                            )
                            # Never fail streaming on emotion failure; emotion is optional
                            emotion_result = None
                            # Clear buffer even on error to prevent memory leak
                            accumulated_audio.clear()

                yield TranscriptionResult.from_stt_result(stt_result, emotion_result)

            # Update metrics for final (successful completion)
            processing_time = time.time() - start_time
            # Calculate duration: bytes / (sample_rate * bytes_per_sample)
            # Assumes 16-bit PCM (2 bytes per sample), mono (1 channel)
            if accumulated_audio and sample_rate > 0:
                audio_duration = self._calculate_audio_duration(
                    bytes(accumulated_audio),
                    sample_rate,
                    is_array=False,
                    channels=1,
                    bit_depth=16,  # 16-bit PCM assumed for streaming
                )
            else:
                audio_duration = 0.0

            # Track cost for streaming (per chunk cost is lower)
            endpoint_cost = EndpointCosts.VOICE_STT_STREAM.value if (EndpointCosts and _SECURITY_AVAILABLE) else 3
            await self._update_metrics(audio_duration, processing_time, success=True, cost=endpoint_cost)

            # Export cost to external metrics
            if _SECURITY_AVAILABLE and EndpointCosts:
                tags = {
                    "provider": provider or "unknown",
                    "correlation_id": correlation_id,
                }

                # Export histogram metrics for streaming
                if self.config.metrics.export_histograms:
                    self._external_metrics.histogram("stt.streaming.latency", processing_time, tags=tags)
                    self._external_metrics.histogram("stt.streaming.audio.duration", audio_duration, tags=tags)

                self._external_metrics.increment("stt.streaming.cost.total", value=endpoint_cost, tags=tags)

            # Log audit
            self._log_audit(
                user_id,
                tenant_id,
                "success",
                {
                    "type": "streaming",
                    "processing_time": processing_time,
                    "audio_duration": audio_duration,
                },
                correlation_id,
            )

        except Exception as e:
            endpoint_cost = EndpointCosts.STT.value if (EndpointCosts and _SECURITY_AVAILABLE) else 5
            await self._update_metrics(0, time.time() - start_time, success=False, cost=endpoint_cost)
            self._log_audit(user_id, tenant_id, "failure", {"error": str(e), "type": "streaming"}, correlation_id)
            raise
        finally:
            # Cleanup stream tracking and accumulated audio (always execute)
            self._active_streams.discard(processed_stream)
            # Clear accumulated audio buffer to free memory
            # Use try/except instead of locals() check for reliability
            try:
                if accumulated_audio:
                    accumulated_audio.clear()
            except NameError:
                pass  # Variable doesn't exist (shouldn't happen, but be safe)

    async def _async_iter_single(self, data: bytes) -> AsyncIterator[bytes]:
        """Create async iterator from single bytes object."""
        yield data

    async def transcribe_file(
        self,
        file_bytes: bytes,
        extract_emotion: bool = True,
        language: Optional[str] = None,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
    ) -> TranscriptionResult:
        """
        Transcribe audio file (any format).

        Args:
            file_bytes: Audio file bytes (WAV, MP3, FLAC, etc.)
            extract_emotion: Detect emotion
            language: Language code
            user_id: User ID for security
            tenant_id: Tenant ID for security

        Returns:
            TranscriptionResult

        Raises:
            AudioFormatError: If file format is invalid or cannot be loaded
            TranscriptionError: If transcription fails
        """
        if not self._initialized:
            await self.initialize()

        correlation_id = self._generate_correlation_id()

        try:
            # Load and detect format
            audio_array, sample_rate = self._audio_processor.load_audio_file(file_bytes)

            # Convert to bytes for transcription
            audio_bytes = self._audio_processor.array_to_bytes(audio_array)

            return await self.transcribe(
                audio_bytes,
                sample_rate=sample_rate,
                language=language,
                extract_emotion=extract_emotion,
                user_id=user_id,
                tenant_id=tenant_id,
                correlation_id=correlation_id,
            )
        except (AudioValidationError, AudioProcessingError) as e:
            logger.warning("Failed to load audio file", extra={"correlation_id": correlation_id, "error": str(e)})
            raise AudioFormatError(f"Failed to load audio file: {e}") from e

    def get_provider(self, name: str) -> Optional[BaseSTTProvider]:
        """
        Get specific provider instance.

        Args:
            name: Provider name

        Returns:
            Provider instance or None
        """
        if self._strategy:
            return self._strategy.get_provider(name)
        return None

    def set_primary_provider(self, name: str) -> None:
        """
        Change primary provider.

        Args:
            name: Provider name
        """
        if self._strategy:
            # Strategy.set_primary is synchronous, but some tests may mock it as async.
            # Avoid "coroutine was never awaited" warnings by scheduling if needed.
            res = self._strategy.set_primary(name)
            try:
                if asyncio.iscoroutine(res):
                    asyncio.create_task(res)
            except Exception:
                pass

    async def health_check(self) -> Dict[str, Any]:
        """
        Perform health check on engine and all providers.

        Returns:
            Health status dict
        """
        # Add timeout to prevent hanging health checks
        # Prefer integration.health_check_timeout (aligns with TTS/LLM), fallback to metrics
        health_check_timeout = getattr(
            self.config.integration,
            "health_check_timeout",
            getattr(self.config.metrics, "health_check_timeout", 5.0),
        )
        try:
            return await asyncio.wait_for(self._do_health_check(), timeout=health_check_timeout)
        except asyncio.TimeoutError:
            logger.warning(f"Health check timed out after {health_check_timeout} seconds")
            return {
                "initialized": self._initialized,
                "status": "timeout",
                "error": f"Health check timed out after {health_check_timeout}s",
                "security_available": _SECURITY_AVAILABLE,
            }

    async def _do_health_check(self) -> Dict[str, Any]:
        """Internal health check implementation."""
        # Thread-safe metrics access
        async with self._metrics_lock:
            metrics_copy = self._metrics.copy()
            # Don't include raw latencies in health check (too verbose)
            # Convert deque to list length for health check
            latencies_deque = metrics_copy.pop("latencies", deque())
            metrics_copy["latency_sample_count"] = len(latencies_deque)
            first_result_deque = metrics_copy.pop("first_result_latencies", deque())
            metrics_copy["first_result_latency_sample_count"] = len(first_result_deque)

        health = {
            "initialized": self._initialized,
            "security_available": _SECURITY_AVAILABLE,
            "config": {
                "primary_provider": self.config.primary_provider,
                "vad_enabled": self.config.vad.enabled,
                "emotion_enabled": self.config.emotion.enabled,
                "rate_limiting_enabled": self.config.integration.enable_rate_limiting,
                "audit_logging_enabled": self.config.integration.enable_audit_logging,
            },
            "metrics": metrics_copy,
        }

        if self._strategy:
            health["providers"] = await self._strategy.health_check()

        return health

    async def get_metrics(self) -> Dict[str, Any]:
        """
        Get engine metrics (thread-safe).

        Returns:
            Metrics dict with averages and percentiles
        """
        async with self._metrics_lock:
            metrics = self._metrics.copy()
            latencies = metrics.pop("latencies", [])
            first_result_latencies = metrics.pop("first_result_latencies", [])

        # Calculate averages
        if metrics["transcriptions"] > 0:
            metrics["avg_processing_time"] = metrics["total_processing_time"] / metrics["transcriptions"]
            metrics["avg_audio_duration"] = metrics["total_audio_duration"] / metrics["transcriptions"]
            metrics["realtime_factor"] = (
                metrics["total_audio_duration"] / metrics["total_processing_time"]
                if metrics["total_processing_time"] > 0
                else 0
            )

        # Calculate percentiles if we have latency data
        # P50 = median, P95 = 95th percentile, P99 = 99th percentile
        if latencies:
            # Convert deque to list for sorting (deque is iterable)
            sorted_latencies = sorted(latencies)
            n = len(sorted_latencies)

            # P50: median value (50% of requests faster)
            metrics["latency_p50"] = sorted_latencies[int(n * 0.5)]

            # P95: 95% of requests are faster than this
            metrics["latency_p95"] = sorted_latencies[int(n * 0.95)]

            # P99: 99% of requests are faster (only 1% slower)
            # Use last element if less than 100 samples (conservative estimate)
            metrics["latency_p99"] = sorted_latencies[int(n * 0.99)] if n >= 100 else sorted_latencies[-1]

        # First-result latency percentiles (time to first transcription, esp. for streaming)
        if first_result_latencies:
            sorted_first = sorted(first_result_latencies)
            n_first = len(sorted_first)
            metrics["latency_first_result_p50"] = sorted_first[int(n_first * 0.5)]
            metrics["latency_first_result_p95"] = sorted_first[int(n_first * 0.95)]
            metrics["latency_first_result_p99"] = (
                sorted_first[int(n_first * 0.99)] if n_first >= 100 else sorted_first[-1]
            )

        # SLO/alert targets for dashboards (industry: first-token < 200 ms, alert when p95 > 500 ms)
        mc = self.config.metrics
        if getattr(mc, "slo_first_result_latency_ms", None) is not None:
            metrics["slo_first_result_latency_ms"] = mc.slo_first_result_latency_ms
        if getattr(mc, "slo_batch_realtime_factor", None) is not None:
            metrics["slo_batch_realtime_factor"] = mc.slo_batch_realtime_factor
        if getattr(mc, "alert_first_result_p95_ms", None) is not None:
            metrics["alert_first_result_p95_ms"] = mc.alert_first_result_p95_ms

        return metrics

    async def reset_metrics(self) -> None:
        """Reset all metrics (thread-safe)."""
        async with self._metrics_lock:
            max_latency_samples = self.config.metrics.max_latency_samples
            self._metrics = {
                "transcriptions": 0,
                "total_audio_duration": 0.0,
                "total_processing_time": 0.0,
                "errors": 0,
                "errors_by_type": {},
                "no_speech_detected": 0,
                "streaming_sessions": 0,
                "latencies": deque(maxlen=max_latency_samples),  # Bounded deque
                "first_result_latencies": deque(maxlen=max_latency_samples),
                "total_cost": 0,
                "cost_by_provider": {},
            }
        logger.info("STT engine metrics reset")

    async def _record_first_result_latency(self, latency: float) -> None:
        """Record time-to-first-transcription (streaming or batch). Thread-safe."""
        async with self._metrics_lock:
            self._metrics["first_result_latencies"].append(latency)

    async def _update_metrics(
        self,
        audio_duration: float,
        processing_time: float,
        success: bool,
        error_type: Optional[str] = None,
        no_speech: bool = False,
        provider: Optional[str] = None,
        cost: int = 0,
    ) -> None:
        """Update engine metrics (thread-safe)."""
        async with self._metrics_lock:
            self._metrics["transcriptions"] += 1
            self._metrics["total_audio_duration"] += audio_duration
            self._metrics["total_processing_time"] += processing_time

            # Track cost
            if cost > 0:
                self._metrics["total_cost"] = self._metrics.get("total_cost", 0) + cost
                if provider:
                    self._metrics["cost_by_provider"][provider] = (
                        self._metrics["cost_by_provider"].get(provider, 0) + cost
                    )

            # Append latency to bounded deque (automatic memory management)
            # No manual trimming needed - deque handles it automatically
            self._metrics["latencies"].append(processing_time)

            if no_speech:
                self._metrics["no_speech_detected"] += 1

            if not success:
                self._metrics["errors"] += 1
                if error_type:
                    self._metrics["errors_by_type"][error_type] = self._metrics["errors_by_type"].get(error_type, 0) + 1

    @property
    def is_initialized(self) -> bool:
        """Check if engine is initialized."""
        return self._initialized

    @property
    def security_enabled(self) -> bool:
        """Check if security layer is enabled."""
        return _SECURITY_AVAILABLE and (self._rate_limiter is not None or self._audit_logger is not None)

    @property
    def _vad_enabled(self) -> bool:
        """
        Cached VAD enabled check for performance optimization.

        Returns:
            True if VAD is enabled and initialized
        """
        if self._cached_vad_enabled is None:
            self._cached_vad_enabled = self.config.vad.enabled and self._vad is not None
        return self._cached_vad_enabled

    def __repr__(self) -> str:
        return (
            f"STTEngine(initialized={self._initialized}, "
            f"primary={self.config.primary_provider}, "
            f"security={self.security_enabled})"
        )


# Factory functions for convenience


async def create_stt_engine(
    config: Optional[STTConfig] = None,
    auto_initialize: bool = True,
) -> STTEngine:
    """
    Create and optionally initialize STT engine.

    Args:
        config: Engine configuration
        auto_initialize: Initialize immediately

    Returns:
        Configured STTEngine instance

    Example:
        engine = await create_stt_engine()
        result = await engine.transcribe(audio)
    """
    engine = STTEngine(config)

    if auto_initialize:
        await engine.initialize()

    return engine


async def create_stt_engine_from_providers(
    auto_initialize: bool = True,
) -> STTEngine:
    """
    Create STT engine from providers.yml configuration.

    This is the recommended way to create the engine when using
    the centralized providers.yml configuration file.

    Args:
        auto_initialize: Initialize immediately (default: True)

    Returns:
        Configured STTEngine instance

    Example:
        # Simple usage - loads from config/providers.yml
        engine = await create_stt_engine_from_providers()
        result = await engine.transcribe(audio)

        # The providers.yml controls which providers are enabled
        # and their priority. Just edit the YAML to change behavior:
        #
        # In providers.yml:
        # stt:
        #   elevenlabs:
        #     enabled: true
        #     primary: true   # <- This is the default
        #   whisper:
        #     enabled: true
        #     primary: false  # <- Fallback
    """
    config = STTConfig.from_providers_config()
    engine = STTEngine(config)

    if auto_initialize:
        await engine.initialize()

    return engine
