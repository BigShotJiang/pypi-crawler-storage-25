"""
Faster-Whisper STT Provider - CTranslate2 backend.

Uses faster-whisper (CTranslate2) for ~4x faster inference with the same
fine-tuned model. Use when model_path points to a CTranslate2-converted
directory (e.g. models/whisper-3-turbo-finetuned-ct2).

Optimized per faster-whisper docs: local_files_only for local CT2 paths,
VAD tuning (vad_parameters), optional word_timestamps, cpu_threads on CPU,
and asyncio.get_running_loop() for async safety.
"""

import asyncio
import os
import time
import logging
from typing import Optional, Dict, Any, AsyncIterator, List, Union
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from .base_stt import (
    BaseSTTProvider,
    STTResult,
    ProviderUnavailableError,
)
from .config import WhisperConfig
from .audio_processor import AudioProcessor

logger = logging.getLogger(__name__)


def _is_ct2_model_path(model_path: Optional[str]) -> bool:
    """True if model_path is a directory containing CTranslate2 model.bin."""
    if not model_path:
        return False
    path = _resolve_model_path(model_path)
    return path is not None and os.path.isdir(path) and os.path.isfile(os.path.join(path, "model.bin"))


def _resolve_model_path(model_path: str) -> Optional[str]:
    """
    Resolve model path for loading. If the path is a local directory (relative
    or absolute), return its absolute path so loading works from any cwd.
    Otherwise return the original string (e.g. HuggingFace Hub ID).
    Note: Relative paths are resolved from the current working directory;
    run from project root or set WHISPER_MODEL_PATH to an absolute path.
    """
    if not model_path or not model_path.strip():
        return None
    s = model_path.strip()
    abs_path = os.path.abspath(s)
    return abs_path if os.path.isdir(abs_path) else s


class FasterWhisperSTTProvider(BaseSTTProvider):
    """
    Whisper STT Provider using faster-whisper (CTranslate2).

    Use when model_path points to a CTranslate2-converted model directory.
    Same API as WhisperSTTProvider; ~4x faster inference.
    """

    def __init__(self, config: Optional[WhisperConfig] = None):
        super().__init__()
        self.config = config or WhisperConfig()
        self._model = None
        self._device = None
        self._compute_type = getattr(self.config, "compute_type", "int8_float16")
        max_workers = getattr(self.config, "faster_whisper_max_workers", 2)
        self._executor = ThreadPoolExecutor(max_workers=max_workers)
        # Concurrency limit - lazy init to avoid "no event loop" when provider is
        # instantiated before asyncio.run() (e.g. in sync tests or config loading)
        # Python 3.9 and earlier: Semaphore captures event loop at init, causing RuntimeError
        max_concurrent = getattr(self.config, "max_concurrent_transcriptions", 4)
        self._max_concurrent = max_concurrent
        self._concurrency_limit: Optional[asyncio.Semaphore] = None
        self._audio_processor = AudioProcessor(
            target_sample_rate=16000,
            normalize=True,
        )

    def _get_concurrency_limit(self) -> asyncio.Semaphore:
        """Get concurrency semaphore, creating it lazily when event loop is running."""
        if self._concurrency_limit is None:
            self._concurrency_limit = asyncio.Semaphore(self._max_concurrent)
        return self._concurrency_limit

    async def _load_model_impl(self) -> None:
        try:
            from faster_whisper import WhisperModel
        except ImportError:
            raise ProviderUnavailableError(
                "faster-whisper required. Run: pip install faster-whisper",
                provider=self.get_provider_name(),
            )

        model_path = self.config.model_path
        if not model_path:
            raise ProviderUnavailableError(
                "Whisper model_path not set",
                provider=self.get_provider_name(),
            )

        # Resolve relative paths so loading works from any cwd
        load_path = _resolve_model_path(model_path) or model_path
        local_only = os.path.isdir(load_path)

        device = self.config.device
        if device == "auto":
            try:
                import torch

                device = "cuda" if torch.cuda.is_available() else "cpu"
            except ImportError:
                device = "cpu"
        self._device = device

        # On CPU, prefer float16 or int8; avoid int8_float16 if it causes issues
        compute_type = self._compute_type
        if device == "cpu" and compute_type == "int8_float16":
            compute_type = "int8"
        cpu_threads = getattr(self.config, "cpu_threads", 0)
        logger.info(
            "Loading faster-whisper model: %s (device=%s, compute_type=%s, local_files_only=%s)",
            load_path,
            self._device,
            compute_type,
            local_only,
        )

        self._model = WhisperModel(
            load_path,
            device=self._device,
            compute_type=compute_type,
            cpu_threads=cpu_threads if device == "cpu" else 0,
            local_files_only=local_only,
        )
        self._is_loaded = True
        logger.info("Faster-whisper model loaded")

    async def _shutdown_impl(self) -> None:
        self._model = None
        try:
            self._executor.shutdown(wait=True, cancel_futures=True)
        except TypeError:
            self._executor.shutdown(wait=True)
        self._is_loaded = False

    def is_available(self) -> bool:
        try:
            from faster_whisper import WhisperModel  # noqa: F401

            return True
        except ImportError:
            return False

    def get_provider_name(self) -> str:
        return "whisper"

    def get_supported_languages(self) -> List[str]:
        return ["ar", "en", "mixed"]

    def _bytes_to_float32(self, audio: bytes) -> np.ndarray:
        """Convert 16-bit PCM bytes to float32 mono for faster-whisper."""
        arr = np.frombuffer(audio, dtype=np.int16)
        return arr.astype(np.float32) / 32768.0

    async def transcribe(
        self,
        audio: Union[bytes, np.ndarray],
        sample_rate: int = 16000,
        language: Optional[str] = None,
        correlation_id: Optional[str] = None,
        **kwargs: Any,
    ) -> STTResult:
        use_provider_vad = kwargs.pop("use_provider_vad", None)
        if not self._is_loaded:
            await self.load_model()

        start_time = time.time()

        # Short-audio guard: avoid model call for empty or near-empty input
        if isinstance(audio, np.ndarray):
            n_samples = int(audio.shape[0]) if audio.ndim >= 1 else 0
        else:
            n_samples = len(audio) // 2  # 16-bit = 2 bytes per sample
        min_samples = int(0.05 * sample_rate)  # 50 ms minimum
        if n_samples < min_samples:
            return STTResult(
                text="",
                confidence=0.0,
                language=language or "en",
                processing_time=time.time() - start_time,
                provider=self.get_provider_name(),
                is_partial=False,
                is_final=True,
                segments=None,
                words=None,
                metadata={"model": self.config.model_path, "backend": "faster_whisper", "skipped": "audio_too_short"},
            )

        if isinstance(audio, np.ndarray):
            audio_f32 = np.asarray(audio, dtype=np.float32)
            if audio_f32.ndim > 1:
                audio_f32 = np.mean(audio_f32, axis=1)
            if sample_rate != 16000:
                try:
                    import librosa

                    audio_f32 = librosa.resample(audio_f32, orig_sr=sample_rate, target_sr=16000)
                except Exception:
                    audio_bytes = self._audio_processor.array_to_bytes(audio_f32)
                    audio_f32, _ = self._audio_processor.preprocess(audio_bytes, input_sample_rate=sample_rate)
        else:
            audio_f32 = self._bytes_to_float32(audio)
            if sample_rate != 16000:
                try:
                    import librosa

                    audio_f32 = librosa.resample(audio_f32, orig_sr=sample_rate, target_sr=16000)
                except Exception:
                    audio_f32, _ = self._audio_processor.preprocess(audio, input_sample_rate=sample_rate)

        # Ensure float32 contiguous for faster-whisper (avoids copy inside library)
        audio_f32 = np.ascontiguousarray(np.asarray(audio_f32, dtype=np.float32))

        async with self._get_concurrency_limit():
            loop = asyncio.get_running_loop()
            segments_list, info = await loop.run_in_executor(
                self._executor,
                self._transcribe_sync,
                audio_f32,
                language,
                use_provider_vad,
            )
            text = " ".join(s.text for s in segments_list).strip() if segments_list else ""
            lang = (info.language or "en") if info else (language or "en")
            if language == "ar" or (text and any("\u0600" <= c <= "\u06ff" for c in text)):
                lang = "ar"

        processing_time = time.time() - start_time
        segs = [{"start": s.start, "end": s.end, "text": s.text} for s in segments_list] if segments_list else None
        words_list = None
        if segments_list and getattr(self.config, "word_timestamps", False):
            words_list = []
            for s in segments_list:
                if s.words:
                    for w in s.words:
                        words_list.append(
                            {
                                "start": getattr(w, "start", 0.0),
                                "end": getattr(w, "end", 0.0),
                                "word": getattr(w, "word", ""),
                                "probability": getattr(w, "probability", 0.0),
                            }
                        )
        # Derive confidence from avg_logprob when available (logprob is negative)
        confidence = 0.9
        if segments_list:
            avg_logprob = sum(getattr(s, "avg_logprob", 0.0) for s in segments_list) / len(segments_list)
            try:
                conf = np.exp(avg_logprob)
                confidence = min(0.99, max(0.01, float(conf)))
            except (OverflowError, ValueError):
                pass
        return STTResult(
            text=text,
            confidence=confidence,
            language=lang,
            processing_time=processing_time,
            provider=self.get_provider_name(),
            is_partial=False,
            is_final=True,
            segments=segs,
            words=words_list,
            metadata={"model": self.config.model_path, "device": self._device, "backend": "faster_whisper"},
        )

    def _transcribe_sync(
        self,
        audio_f32: np.ndarray,
        language: Optional[str],
        vad_filter_override: Optional[bool] = None,
    ):
        """Run faster_whisper transcribe in executor; return (list of segments, info)."""
        # ar / en / mixed (None = auto-detect, best for Arabic–English code-switching)
        lang = None
        if language == "ar":
            lang = "ar"
        elif language == "en":
            lang = "en"
        # "mixed" or None → lang=None (auto-detect)
        vad_params = getattr(self.config, "vad_parameters", None)
        if isinstance(vad_params, dict) and not vad_params:
            vad_params = None
        beam_size = getattr(self.config, "beam_size", 5)
        if getattr(self.config, "low_latency", False):
            beam_size = 1
        temperature = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0]  # default fallback sequence
        if getattr(self.config, "low_latency", False) or getattr(self.config, "disable_temperature_fallback", False):
            temperature = 0.0  # no fallback → faster
        vad_filter = vad_filter_override if vad_filter_override is not None else getattr(self.config, "use_vad", True)
        kwargs = {
            "language": lang,
            "task": "transcribe",
            "beam_size": beam_size,
            "patience": max(0.1, getattr(self.config, "patience", 1.0)),  # library requires > 0
            "temperature": temperature,
            "vad_filter": vad_filter,
            "condition_on_previous_text": getattr(self.config, "condition_on_previous_text", True),
            "word_timestamps": getattr(self.config, "word_timestamps", False),
        }
        no_speech = getattr(self.config, "no_speech_threshold", None)
        if no_speech is not None:
            kwargs["no_speech_threshold"] = float(no_speech)
        log_prob = getattr(self.config, "log_prob_threshold", None)
        if log_prob is not None:
            kwargs["log_prob_threshold"] = float(log_prob)
        initial_prompt = getattr(self.config, "initial_prompt", None)
        if initial_prompt is not None and str(initial_prompt).strip():
            kwargs["initial_prompt"] = str(initial_prompt).strip()
        if vad_params:
            try:
                from faster_whisper.vad import VadOptions

                kwargs["vad_parameters"] = VadOptions(**vad_params) if isinstance(vad_params, dict) else vad_params
            except (ImportError, TypeError):
                kwargs["vad_parameters"] = vad_params
        segments_gen, info = self._model.transcribe(audio_f32, **kwargs)
        return (list(segments_gen), info)

    async def transcribe_streaming(
        self,
        audio_stream: AsyncIterator[bytes],
        sample_rate: int = 16000,
        language: Optional[str] = None,
    ) -> AsyncIterator[STTResult]:
        if not self._is_loaded:
            await self.load_model()

        buffer = bytearray()
        chunk_s = (
            self.config.streaming_chunk_length_s
            if self.config.streaming_chunk_length_s is not None
            else self.config.chunk_length_s
        )
        chunk_bytes = int(chunk_s * sample_rate * 2)  # 16-bit PCM = 2 bytes per sample
        overlap_bytes = int(self.config.overlap_s * sample_rate * 2)
        max_buffer_size = chunk_bytes * 10  # Cap buffer to prevent unbounded growth
        start_time = time.time()
        last_text = ""

        async for chunk in audio_stream:
            if len(buffer) + len(chunk) > max_buffer_size:
                logger.warning("Streaming buffer full, dropping oldest chunk to prevent memory growth")
                buffer = buffer[chunk_bytes - overlap_bytes :]
            buffer.extend(chunk)
            while len(buffer) >= chunk_bytes:
                chunk_audio = bytes(buffer[:chunk_bytes])
                buffer = buffer[chunk_bytes - overlap_bytes :]
                try:
                    result = await self.transcribe(chunk_audio, sample_rate=sample_rate, language=language)
                    if result.text and result.text != last_text:
                        yield STTResult(
                            text=result.text,
                            confidence=result.confidence * 0.8,
                            language=result.language,
                            processing_time=time.time() - start_time,
                            provider=self.get_provider_name(),
                            is_partial=True,
                            is_final=False,
                        )
                        last_text = result.text
                except Exception as e:
                    logger.warning("Chunk transcription failed: %s", e)

        min_tail_s = getattr(self.config, "min_tail_duration_s", 0.1)
        min_tail_bytes = int(min_tail_s * sample_rate * 2)
        if len(buffer) >= min_tail_bytes:
            try:
                result = await self.transcribe(bytes(buffer), sample_rate=sample_rate, language=language)
                yield STTResult(
                    text=result.text,
                    confidence=result.confidence,
                    language=result.language,
                    processing_time=time.time() - start_time,
                    provider=self.get_provider_name(),
                    is_partial=False,
                    is_final=True,
                    segments=result.segments,
                    words=result.words,
                    metadata=result.metadata,
                )
            except Exception as e:
                logger.warning("Final chunk transcription failed: %s", e)

    def get_model_info(self) -> Dict[str, Any]:
        info = super().get_model_info()
        info.update(
            {
                "model_path": self.config.model_path,
                "device": self._device,
                "compute_type": self._compute_type,
                "backend": "faster_whisper",
            }
        )
        return info
