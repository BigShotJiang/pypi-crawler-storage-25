"""Allow running: python -m narrative_ai.engines.stt test.wav"""

from .main import main

if __name__ == "__main__":
    main()
