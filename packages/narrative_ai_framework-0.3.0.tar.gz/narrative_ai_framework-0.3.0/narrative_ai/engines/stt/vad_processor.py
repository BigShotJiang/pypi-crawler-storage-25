"""
VAD Processor - Voice Activity Detection using WebRTC VAD.

Provides speech segment detection for filtering silence and optimizing
STT engine processing.
"""

import logging
from typing import List, Tuple, Optional, Iterator, AsyncIterator
from dataclasses import dataclass
from enum import Enum
import threading


logger = logging.getLogger(__name__)


class SpeechState(str, Enum):
    """Current state of speech detection."""

    WAITING = "waiting"  # Waiting for speech to start
    IN_SPEECH = "in_speech"  # Currently in speech segment
    SPEECH_START = "speech_start"  # Just started speech
    SPEECH_END = "speech_end"  # Just ended speech


@dataclass
class SpeechSegment:
    """A detected speech segment."""

    start_sample: int  # Start sample index
    end_sample: int  # End sample index
    audio: bytes  # Audio data for this segment
    duration_ms: float  # Duration in milliseconds
    sample_rate: int  # Sample rate

    @property
    def start_time_s(self) -> float:
        """Start time in seconds."""
        return self.start_sample / self.sample_rate

    @property
    def end_time_s(self) -> float:
        """End time in seconds."""
        return self.end_sample / self.sample_rate


class VADProcessor:
    """
    Voice Activity Detection processor using WebRTC VAD.

    Processes audio frames to detect speech segments, filtering out
    silence for more efficient STT processing.

    Specifications (from WebRTC VAD):
    - Sample rates: 8000, 16000, 32000, 48000 Hz
    - Frame sizes: 10, 20, 30 ms
    - Audio format: 16-bit mono PCM
    - Aggressiveness modes: 0-3 (0=quality, 3=most aggressive)

    Example:
        # Initialize VAD
        vad = VADProcessor(sample_rate=16000, frame_duration_ms=20, mode=2)

        # Process audio stream
        async for segment in vad.process_stream(audio_stream):
            result = await stt_engine.transcribe(segment.audio)
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        frame_duration_ms: int = 20,
        mode: int = 2,
        speech_start_frames: int = 3,
        speech_end_frames: int = 5,
        min_speech_duration_ms: int = 250,
        max_speech_duration_ms: int = 30000,
    ):
        """
        Initialize VAD processor.

        Args:
            sample_rate: Audio sample rate (8000, 16000, 32000, 48000)
            frame_duration_ms: Frame duration in ms (10, 20, 30)
            mode: VAD aggressiveness (0-3, 2=recommended)
            speech_start_frames: Consecutive speech frames to start segment
            speech_end_frames: Consecutive silence frames to end segment
            min_speech_duration_ms: Minimum speech duration to output
            max_speech_duration_ms: Maximum speech duration (30s default)

        Raises:
            ValueError: If parameters are invalid
        """
        # Validate parameters
        if sample_rate not in [8000, 16000, 32000, 48000]:
            raise ValueError(f"Sample rate must be 8000, 16000, 32000, or 48000, got {sample_rate}")

        if frame_duration_ms not in [10, 20, 30]:
            raise ValueError(f"Frame duration must be 10, 20, or 30 ms, got {frame_duration_ms}")

        if mode not in range(4):
            raise ValueError(f"VAD mode must be 0-3, got {mode}")

        self.sample_rate = sample_rate
        self.frame_duration_ms = frame_duration_ms
        self.mode = mode
        self.speech_start_frames = speech_start_frames
        self.speech_end_frames = speech_end_frames
        self.min_speech_duration_ms = min_speech_duration_ms
        self.max_speech_duration_ms = max_speech_duration_ms
        # Protect underlying WebRTC VAD C extension when used from multiple threads.
        # Asyncio runs in a single thread by default, but adding a lock is a cheap
        # safeguard for environments that might share VAD instances across threads.
        self._lock = threading.Lock()

        # Calculate frame sizes
        self.frame_samples = int(sample_rate * frame_duration_ms / 1000)
        self.frame_bytes = self.frame_samples * 2  # 16-bit = 2 bytes per sample

        # Initialize WebRTC VAD
        self._vad = None
        self._init_vad()

        # Verify initialization succeeded (defensive check)
        if self._vad is None:
            raise RuntimeError(
                "VAD initialization failed: _vad is None after _init_vad(). This should not happen if webrtcvad is installed."
            )

        # State tracking
        self._reset_state()

    def _init_vad(self):
        """Initialize WebRTC VAD."""
        try:
            import warnings

            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", message=".*pkg_resources.*", category=UserWarning)
                import webrtcvad
            vad_instance = webrtcvad.Vad(self.mode)
            # Defensive check: ensure Vad() didn't return None
            if vad_instance is None:
                raise RuntimeError(
                    "webrtcvad.Vad() returned None. This indicates a problem with webrtcvad installation."
                )
            self._vad = vad_instance
            logger.info(f"WebRTC VAD initialized: mode={self.mode}, sample_rate={self.sample_rate}")
        except ImportError as e:
            logger.error("webrtcvad not installed. Run: pip install webrtcvad")
            self._vad = None  # Explicitly set to None
            raise ImportError("webrtcvad is required for VAD. Run: pip install webrtcvad") from e
        except Exception as e:
            logger.error(f"Failed to initialize WebRTC VAD: {e}")
            self._vad = None  # Explicitly set to None
            raise RuntimeError(f"Failed to initialize WebRTC VAD: {e}") from e

    def _reset_state(self):
        """Reset internal state."""
        self._speech_frame_count = 0
        self._silence_frame_count = 0
        self._in_speech = False
        self._current_segment_start = 0
        self._current_segment_audio = bytearray()
        self._total_samples_processed = 0

    def reset(self) -> None:
        """Reset VAD state (e.g. on flush). Public API for external callers."""
        self._reset_state()

    def is_speech(self, frame: bytes) -> bool:
        """
        Check if audio frame contains speech.

        Args:
            frame: Audio frame (must be frame_bytes length)

        Returns:
            True if frame contains speech

        Raises:
            ValueError: If frame size is incorrect
            RuntimeError: If VAD is not initialized
        """
        if self._vad is None:
            raise RuntimeError("VAD not initialized. WebRTC VAD failed to initialize.")

        if len(frame) != self.frame_bytes:
            raise ValueError(
                f"Frame must be exactly {self.frame_bytes} bytes for {self.sample_rate}Hz "
                f"at {self.frame_duration_ms}ms, got {len(frame)} bytes. "
                f"WebRTC VAD requires exact frame sizes (no tolerance). "
                f"Expected: {self.frame_bytes} bytes ({self.frame_samples} samples)."
            )

        try:
            # Thread-safe guard around C extension call. This prevents concurrent
            # access to the same Vad instance from multiple threads, which is not
            # guaranteed to be safe by the underlying library.
            with self._lock:
                return self._vad.is_speech(frame, self.sample_rate)
        except AttributeError as e:
            # Catch AttributeError from webrtcvad and provide better diagnostics
            error_msg = (
                f"AttributeError in webrtcvad.is_speech(): {e}. "
                f"This may indicate that webrtcvad.Vad object is in an invalid state. "
                f"_vad type: {type(self._vad)}, _vad value: {self._vad}, "
                f"sample_rate: {self.sample_rate}, frame_length: {len(frame)}"
            )
            logger.error(error_msg)
            raise RuntimeError(error_msg) from e

    def process_frame(self, frame: bytes) -> Tuple[SpeechState, Optional[SpeechSegment]]:
        """
        Process a single audio frame.

        Args:
            frame: Audio frame (frame_bytes length, 16-bit PCM)

        Returns:
            Tuple of (state, segment)
            - state: Current speech state
            - segment: SpeechSegment if speech ended, None otherwise
        """
        # Wrap VAD call in try-except to prevent crashes on corrupted frames
        try:
            is_speech = self.is_speech(frame)
        except Exception as e:
            logger.warning(f"VAD processing failed for frame, treating as silence: {e}", exc_info=False)
            # Treat error as silence to prevent pipeline failure
            is_speech = False

        segment = None
        state = SpeechState.WAITING

        if is_speech:
            self._speech_frame_count += 1
            self._silence_frame_count = 0
        else:
            self._silence_frame_count += 1
            self._speech_frame_count = 0

        if not self._in_speech:
            # Looking for speech start
            if self._speech_frame_count >= self.speech_start_frames:
                # Speech started
                self._in_speech = True
                self._current_segment_start = max(
                    0, self._total_samples_processed - (self.speech_start_frames * self.frame_samples)
                )
                self._current_segment_audio = bytearray()
                state = SpeechState.SPEECH_START
                logger.debug(f"Speech started at sample {self._current_segment_start}")
        else:
            # Currently in speech
            state = SpeechState.IN_SPEECH

            # Check for speech end
            if self._silence_frame_count >= self.speech_end_frames:
                # Speech ended
                segment = self._finalize_segment()
                self._in_speech = False
                state = SpeechState.SPEECH_END
                if segment is not None:
                    logger.debug(f"Speech ended, duration: {segment.duration_ms:.0f}ms")
                else:
                    logger.debug("Speech ended, but segment was too short and filtered out")

            # Check for max duration
            current_duration_ms = len(self._current_segment_audio) * 1000 / (self.sample_rate * 2)
            if current_duration_ms >= self.max_speech_duration_ms:
                # Force end due to max duration
                segment = self._finalize_segment()
                # Don't reset _in_speech - continue capturing
                self._current_segment_audio = bytearray()
                state = SpeechState.SPEECH_END
                logger.debug(f"Speech segment max duration reached: {current_duration_ms:.0f}ms")

        # Accumulate audio if in speech
        if self._in_speech:
            self._current_segment_audio.extend(frame)

        self._total_samples_processed += self.frame_samples

        return state, segment

    def _finalize_segment(self) -> Optional[SpeechSegment]:
        """Finalize and return current speech segment."""
        if not self._current_segment_audio:
            return None

        audio_bytes = bytes(self._current_segment_audio)
        duration_ms = len(audio_bytes) * 1000 / (self.sample_rate * 2)

        # Check minimum duration
        if duration_ms < self.min_speech_duration_ms:
            logger.debug(f"Discarding short segment: {duration_ms:.0f}ms")
            return None

        end_sample = self._total_samples_processed

        return SpeechSegment(
            start_sample=self._current_segment_start,
            end_sample=end_sample,
            audio=audio_bytes,
            duration_ms=duration_ms,
            sample_rate=self.sample_rate,
        )

    def process_audio(self, audio: bytes) -> List[SpeechSegment]:
        """
        Process complete audio and return speech segments.

        Args:
            audio: Complete audio data (16-bit PCM)

        Returns:
            List of SpeechSegment objects
        """
        self._reset_state()
        segments = []

        # Process frame by frame
        for i in range(0, len(audio), self.frame_bytes):
            frame = audio[i : i + self.frame_bytes]

            # Pad last frame if needed (only for incomplete last frame)
            # Note: WebRTC VAD prefers exact frame sizes, but padding is acceptable for the final frame
            if len(frame) < self.frame_bytes:
                if i + self.frame_bytes > len(audio):
                    # This is the last frame and it's incomplete - pad it
                    original_len = len(frame)
                    frame = frame + b"\x00" * (self.frame_bytes - len(frame))
                    logger.debug(f"Padded incomplete last frame: {original_len} -> {self.frame_bytes} bytes")
                else:
                    # Frame is incomplete but not the last - this shouldn't happen
                    raise ValueError(
                        f"Incomplete frame at offset {i}: expected {self.frame_bytes} bytes, "
                        f"got {len(frame)} bytes. Audio may be corrupted."
                    )

            state, segment = self.process_frame(frame)

            if segment is not None:
                segments.append(segment)

        # Handle any remaining speech
        if self._in_speech and self._current_segment_audio:
            segment = self._finalize_segment()
            if segment is not None:
                segments.append(segment)

        logger.info(f"Processed audio: {len(segments)} speech segments found")

        return segments

    def process_audio_with_timing(
        self,
        audio: bytes,
    ) -> List[Tuple[float, float, bytes]]:
        """
        Process audio and return segments with timestamps.

        Args:
            audio: Complete audio data (16-bit PCM)

        Returns:
            List of (start_time_s, end_time_s, audio_bytes) tuples
        """
        segments = self.process_audio(audio)

        return [(seg.start_time_s, seg.end_time_s, seg.audio) for seg in segments]

    def iter_frames(self, audio: bytes) -> Iterator[bytes]:
        """
        Iterate over audio frames.

        Args:
            audio: Audio data (16-bit PCM)

        Yields:
            Audio frames of frame_bytes size
        """
        for i in range(0, len(audio), self.frame_bytes):
            frame = audio[i : i + self.frame_bytes]

            # Pad last frame if needed
            if len(frame) < self.frame_bytes:
                frame = frame + b"\x00" * (self.frame_bytes - len(frame))

            yield frame

    async def process_stream(
        self,
        audio_stream: AsyncIterator[bytes],
    ) -> AsyncIterator[SpeechSegment]:
        """
        Process streaming audio and yield speech segments.

        This method is designed for real-time processing with LiveKit.
        Audio chunks from the stream are buffered into frames and processed.

        Args:
            audio_stream: Async iterator of audio chunks

        Yields:
            SpeechSegment objects when speech ends

        Example:
            async for segment in vad.process_stream(audio_stream):
                result = await stt_engine.transcribe(segment.audio)
        """
        self._reset_state()
        buffer = bytearray()

        async for chunk in audio_stream:
            buffer.extend(chunk)

            # Process complete frames
            while len(buffer) >= self.frame_bytes:
                frame = bytes(buffer[: self.frame_bytes])
                buffer = buffer[self.frame_bytes :]

                state, segment = self.process_frame(frame)

                if segment is not None:
                    yield segment

        # Process remaining buffer
        if len(buffer) > 0:
            # Pad to frame size
            frame = bytes(buffer) + b"\x00" * (self.frame_bytes - len(buffer))
            state, segment = self.process_frame(frame)

            if segment is not None:
                yield segment

        # Handle any remaining speech
        if self._in_speech and self._current_segment_audio:
            segment = self._finalize_segment()
            if segment is not None:
                yield segment

    async def filter_speech_stream(
        self,
        audio_stream: AsyncIterator[bytes],
    ) -> AsyncIterator[bytes]:
        """
        Filter audio stream to only yield speech frames.

        Unlike process_stream which yields complete segments, this yields
        individual frames that contain speech, useful for streaming STT.

        Args:
            audio_stream: Async iterator of audio chunks

        Yields:
            Audio frames that contain speech
        """
        buffer = bytearray()

        async for chunk in audio_stream:
            buffer.extend(chunk)

            # Process complete frames
            while len(buffer) >= self.frame_bytes:
                frame = bytes(buffer[: self.frame_bytes])
                buffer = buffer[self.frame_bytes :]

                if self.is_speech(frame):
                    yield frame

    def get_stats(self) -> dict:
        """
        Get VAD processing statistics.

        Returns:
            Dict with processing stats
        """
        return {
            "sample_rate": self.sample_rate,
            "frame_duration_ms": self.frame_duration_ms,
            "mode": self.mode,
            "total_samples_processed": self._total_samples_processed,
            "total_duration_s": self._total_samples_processed / self.sample_rate,
            "in_speech": self._in_speech,
        }


class SpeechChunker:
    """
    High-level speech chunker that combines VAD with buffering.

    Designed for streaming scenarios where you want to accumulate
    speech into chunks suitable for STT processing.

    Example:
        chunker = SpeechChunker(sample_rate=16000, min_chunk_ms=500)

        async for chunk in chunker.chunk_stream(audio_stream):
            # chunk is suitable for STT processing
            result = await stt_provider.transcribe(chunk)
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        frame_duration_ms: int = 20,
        vad_mode: int = 2,
        min_chunk_ms: int = 500,
        max_chunk_ms: int = 5000,
        silence_threshold_ms: int = 300,
    ):
        """
        Initialize speech chunker.

        Args:
            sample_rate: Audio sample rate
            frame_duration_ms: VAD frame duration
            vad_mode: VAD aggressiveness (0-3)
            min_chunk_ms: Minimum chunk duration to yield
            max_chunk_ms: Maximum chunk duration before forcing yield
            silence_threshold_ms: Silence duration to trigger chunk yield
        """
        self.vad = VADProcessor(
            sample_rate=sample_rate,
            frame_duration_ms=frame_duration_ms,
            mode=vad_mode,
            speech_start_frames=3,
            speech_end_frames=int(silence_threshold_ms / frame_duration_ms),
            min_speech_duration_ms=min_chunk_ms,
            max_speech_duration_ms=max_chunk_ms,
        )

        self.sample_rate = sample_rate
        self.min_chunk_ms = min_chunk_ms
        self.max_chunk_ms = max_chunk_ms

    async def chunk_stream(
        self,
        audio_stream: AsyncIterator[bytes],
    ) -> AsyncIterator[bytes]:
        """
        Chunk audio stream based on speech activity.

        Args:
            audio_stream: Async iterator of audio chunks

        Yields:
            Audio chunks suitable for STT processing
        """
        async for segment in self.vad.process_stream(audio_stream):
            yield segment.audio


# Convenience function for one-shot VAD processing


def detect_speech_segments(
    audio: bytes,
    sample_rate: int = 16000,
    mode: int = 2,
) -> List[SpeechSegment]:
    """
    Detect speech segments in audio.

    Convenience function that creates a VAD processor and processes audio.

    Args:
        audio: Audio data (16-bit PCM)
        sample_rate: Audio sample rate
        mode: VAD aggressiveness (0-3)

    Returns:
        List of SpeechSegment objects
    """
    vad = VADProcessor(sample_rate=sample_rate, mode=mode)
    return vad.process_audio(audio)
