import asyncio
import numpy as np
from typing import Optional, Union, AsyncIterator, Any, List, Dict
from narrative_ai.engines.stt.stt_engine import STTEngine, TranscriptionResult
from narrative_ai.engines.stt.emotion_detector import EmotionResult, ProsodyFeatures
from narrative_ai.engines.stt.vad_processor import VADProcessor, SpeechSegment

_default_engine: Optional[STTEngine] = None

def get_engine() -> STTEngine:
    """Get or create the default global STTEngine instance."""
    global _default_engine
    if _default_engine is None:
        # Note: In a production SDK, we might want to allow 
        # passing config or initializing from env here.
        from .stt_engine import create_stt_engine
        # create_stt_engine is async, so we might have a bootstrap issue
        # for a truly sync-looking API. We'll use a lock or initialize on first async call.
        pass
    return _default_engine

async def _ensure_engine():
    global _default_engine
    if _default_engine is None:
        from narrative_ai.engines.stt.stt_engine import create_stt_engine_from_providers
        _default_engine = await create_stt_engine_from_providers()
    return _default_engine

def set_api_key(api_key: str, provider: str = "openai"):
    """
    Dynamically set the API key for an STT provider.
    
    Args:
        api_key: The secret API key string.
        provider: Provider name (e.g., 'openai', 'elevenlabs', 'google').
    """
    global _default_engine
    if _default_engine:
        # Note: STTEngine might not have a public set_api_key, so we use env var fallback
        pass
    
    import os
    env_map = {
        "openai": "OPENAI_API_KEY",
        "elevenlabs": "ELEVENLABS_API_KEY",
        "google": "GOOGLE_APPLICATION_CREDENTIALS"
    }
    env_var = env_map.get(provider.lower())
    if env_var:
        os.environ[env_var] = api_key

def set_stt_provider(provider_name: str) -> None:
    """Dynamically switch the primary STT provider."""
    global _default_engine
    if _default_engine:
        _default_engine.set_primary_provider(provider_name)
    
    import os
    os.environ["STT_PRIMARY_PROVIDER"] = provider_name

async def speech_to_text(
    audio: Union[bytes, np.ndarray],
    sample_rate: int = 16000,
    language: Optional[str] = None,
    extract_emotion: bool = True,
    use_vad: bool = True,
    provider: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_tier: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> TranscriptionResult:
    """Transcribe audio to text."""
    engine = await _ensure_engine()
    return await engine.transcribe(
        audio, 
        sample_rate=sample_rate, 
        language=language, 
        extract_emotion=extract_emotion,
        use_vad=use_vad,
        provider=provider,
        user_id=user_id,
        tenant_id=tenant_id,
        user_tier=user_tier,
        correlation_id=correlation_id,
        **kwargs
    )

async def stt_streaming(
    audio_stream: AsyncIterator[bytes],
    sample_rate: int = 16000,
    language: Optional[str] = None,
    extract_emotion: bool = True,
    provider: Optional[str] = None,
    user_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    user_tier: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> AsyncIterator[TranscriptionResult]:
    """Stream audio chunks and yield transcriptions."""
    engine = await _ensure_engine()
    async for result in engine.transcribe_streaming(
        audio_stream,
        sample_rate=sample_rate,
        language=language,
        extract_emotion=extract_emotion,
        provider=provider,
        user_id=user_id,
        tenant_id=tenant_id,
        user_tier=user_tier,
        correlation_id=correlation_id,
        **kwargs
    ):
        yield result

async def detect_emotion(
    audio: Union[bytes, np.ndarray],
    sample_rate: int = 16000
) -> EmotionResult:
    """Detect emotion from audio prosody."""
    engine = await _ensure_engine()
    if engine._emotion_detector:
        # Pre-process audio to numpy array if it's bytes
        if isinstance(audio, bytes):
            audio_array = engine._audio_processor.bytes_to_array(audio, sample_rate)
        else:
            audio_array = audio
        return await engine._emotion_detector.detect_emotion(audio_array, sample_rate)
    
    # Fallback to a neutral result if detector not initialized
    from .emotion_detector import EmotionDetector
    detector = EmotionDetector()
    if isinstance(audio, bytes):
        from .audio_processor import AudioProcessor
        ap = AudioProcessor()
        audio_array = ap.bytes_to_array(audio, sample_rate)
    else:
        audio_array = audio
    return await detector.detect_emotion(audio_array, sample_rate)

async def get_stt_metrics() -> Dict[str, Any]:
    """Get performance metrics for the STT engine."""
    engine = await _ensure_engine()
    return await engine.get_metrics()

async def stt_health_check() -> Dict[str, Any]:
    """Check the health status of the STT engine and its providers."""
    engine = await _ensure_engine()
    return await engine.health_check()

async def calibrate_emotion(
    audio_samples: List[Union[bytes, np.ndarray]], 
    sample_rate: int = 16000
) -> None:
    """
    Calibrate emotion detection baselines using neutral speech samples.
    
    This improves accuracy for a specific speaker's voice.
    """
    engine = await _ensure_engine()
    if not engine._emotion_detector:
        return
        
    processed_samples = []
    for sample in audio_samples:
        if isinstance(sample, bytes):
            arr = engine._audio_processor.bytes_to_array(sample, sample_rate)
            processed_samples.append(arr)
        else:
            processed_samples.append(sample)
            
    engine._emotion_detector.calibrate_baselines(processed_samples, sample_rate)

def set_stt_provider(provider_name: str) -> None:
    """Dynamically switch the primary STT provider."""
    global _default_engine
    if _default_engine:
        _default_engine.set_primary_provider(provider_name)

class STTClient:
    """
    A session-based client for the Speech-to-Text engine.
    Stores common parameters like user_id, tenant_id, and language to avoid repetition.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        language: Optional[str] = None,
        extract_emotion: bool = True,
        use_vad: bool = True,
        provider: Optional[str] = None,
        api_key: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ):
        """
        Initialize the STT client with default context.
        
        Args:
            user_id: Default user ID for all requests
            tenant_id: Default tenant ID for all requests
            language: Default language hint (e.g., 'ar', 'en')
            extract_emotion: Whether to detect emotion by default
            use_vad: Whether to use voice activity detection by default
            provider: Default STT provider to use
            api_key: Optional API key for the session
            correlation_id: Default correlation ID prefix or value
        """
        if api_key and provider:
            set_api_key(api_key, provider)

        self.defaults = {
            "user_id": user_id,
            "tenant_id": tenant_id,
            "language": language,
            "extract_emotion": extract_emotion,
            "use_vad": use_vad,
            "provider": provider,
            "correlation_id": correlation_id,
        }

    async def transcribe(self, audio: Union[bytes, np.ndarray], **kwargs) -> TranscriptionResult:
        """
        Transcribe audio using client defaults.
        Specific arguments passed here will override client defaults.
        """
        final_args = {**self.defaults, "audio": audio, **kwargs}
        return await speech_to_text(**final_args)

    async def transcribe_stream(self, audio_stream: AsyncIterator[bytes], **kwargs) -> AsyncIterator[TranscriptionResult]:
        """
        Stream audio and yield transcriptions using client defaults.
        Specific arguments passed here will override client defaults.
        """
        final_args = {**self.defaults, "audio_stream": audio_stream, **kwargs}
        async for result in stt_streaming(**final_args):
            yield result

    def detect_speech(self, audio: bytes, **kwargs) -> List[SpeechSegment]:
        """Detect speech segments using client defaults."""
        from .vad_processor import VADProcessor
        vad = VADProcessor()
        return vad.process(audio, **kwargs)

    async def detect_emotion(self, audio: Union[bytes, np.ndarray], sample_rate: int = 16000) -> EmotionResult:
        """Helper to detect emotion from audio."""
        return await detect_emotion(audio, sample_rate=sample_rate)

    async def get_metrics(self) -> Dict[str, Any]:
        """Get performance metrics for the current session."""
        return await get_stt_metrics()

    async def health_check(self) -> Dict[str, Any]:
        """Check the status of STT providers."""
        return await stt_health_check()

    async def calibrate_emotion(self, audio_samples: List[Union[bytes, np.ndarray]], sample_rate: int = 16000) -> None:
        """Personalize emotion detection for this speaker."""
        await calibrate_emotion(audio_samples, sample_rate)

    def set_provider(self, provider_name: str) -> None:
        """Switch the provider for this session."""
        set_stt_provider(provider_name)
