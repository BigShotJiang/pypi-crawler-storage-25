"""
Audio Processor - Common Audio Preprocessing Utilities.

Provides audio format conversion, resampling, normalization, and validation
for all STT providers.
"""

import io
import logging
from typing import Optional, Tuple, Union
from dataclasses import dataclass
from enum import Enum

import numpy as np

logger = logging.getLogger(__name__)


class AudioFormat(str, Enum):
    """Supported audio formats."""

    WAV = "wav"
    MP3 = "mp3"
    FLAC = "flac"
    M4A = "m4a"
    OGG = "ogg"
    WEBM = "webm"
    PCM = "pcm"  # Raw PCM
    UNKNOWN = "unknown"


@dataclass
class AudioMetadata:
    """Metadata about audio data."""

    sample_rate: int
    channels: int
    duration_s: float
    num_samples: int
    format: AudioFormat
    bit_depth: int = 16


class AudioProcessingError(Exception):
    """Raised when audio processing fails."""

    pass


class AudioValidationError(Exception):
    """Raised when audio validation fails."""

    pass


class AudioFormatDetector:
    """
    Detect audio file formats from magic bytes.

    Utility class for identifying audio file formats vs raw PCM data.
    This is used by security validation to determine if audio bytes
    represent a file format (WAV, MP3, etc.) or raw PCM data.
    """

    # Audio file magic bytes (first few bytes)
    MAGIC_BYTES = {
        b"RIFF": "wav",  # WAV files start with RIFF
        b"ID3": "mp3",  # MP3 with ID3 tag
        b"\xff\xfb": "mp3",  # MP3 frame sync
        b"\xff\xf3": "mp3",  # MP3 frame sync variant
        b"fLaC": "flac",  # FLAC
        b"OggS": "ogg",  # OGG
    }

    @staticmethod
    def is_audio_file(audio_bytes: bytes) -> bool:
        """
        Check if bytes represent an audio file (not raw PCM).

        Args:
            audio_bytes: Audio data bytes

        Returns:
            True if appears to be an audio file format
        """
        if len(audio_bytes) < 12:
            return False

        # Check common magic bytes
        for magic, _ in AudioFormatDetector.MAGIC_BYTES.items():
            if audio_bytes.startswith(magic):
                return True

        # Check M4A/MP4 (magic at offset 4)
        if len(audio_bytes) >= 8 and audio_bytes[4:8] == b"ftyp":
            return True

        return False

    @staticmethod
    def detect_format(audio_bytes: bytes) -> Optional[str]:
        """
        Detect audio format from magic bytes.

        Args:
            audio_bytes: Audio data bytes

        Returns:
            Format name (e.g., "wav", "mp3") or None if unknown
        """
        if len(audio_bytes) < 12:
            return None

        for magic, format_name in AudioFormatDetector.MAGIC_BYTES.items():
            if audio_bytes.startswith(magic):
                return format_name

        # Check M4A/MP4 (magic at offset 4)
        if len(audio_bytes) >= 8 and audio_bytes[4:8] == b"ftyp":
            return "m4a"

        return None


class AudioProcessor:
    """
    Audio preprocessing utility for STT engines.

    Handles:
    - Format detection and conversion
    - Sample rate conversion (resampling)
    - Channel conversion (stereo to mono)
    - Audio normalization
    - Validation (duration, size)

    Example:
        processor = AudioProcessor(target_sample_rate=16000)

        # Preprocess audio
        audio_array, sample_rate = processor.preprocess(audio_bytes, input_sr=44100)

        # Validate audio
        processor.validate(audio_array, sample_rate)
    """

    def __init__(
        self,
        target_sample_rate: int = 16000,
        target_channels: int = 1,
        normalize: bool = True,
        max_duration_s: int = 600,
        max_size_bytes: int = 50 * 1024 * 1024,
    ):
        """
        Initialize audio processor.

        Args:
            target_sample_rate: Target sample rate in Hz (default: 16000)
            target_channels: Target number of channels (default: 1 = mono)
            normalize: Whether to normalize audio levels (default: True)
            max_duration_s: Maximum audio duration in seconds (default: 600)
            max_size_bytes: Maximum file size in bytes (default: 50MB)
        """
        self.target_sample_rate = target_sample_rate
        self.target_channels = target_channels
        self.normalize = normalize
        self.max_duration_s = max_duration_s
        self.max_size_bytes = max_size_bytes

    def preprocess(
        self,
        audio: Union[bytes, np.ndarray],
        input_sample_rate: Optional[int] = None,
        input_channels: Optional[int] = None,
    ) -> Tuple[np.ndarray, int]:
        """
        Preprocess audio to target format.

        Args:
            audio: Audio data (bytes or numpy array)
            input_sample_rate: Input sample rate (required if audio is bytes)
            input_channels: Input channels (optional, will detect if not provided)

        Returns:
            Tuple of (preprocessed audio array, sample rate)

        Raises:
            AudioProcessingError: If preprocessing fails
        """
        try:
            # Convert bytes to numpy array if needed
            if isinstance(audio, bytes):
                audio_array = self._bytes_to_array(audio)
            else:
                audio_array = audio.copy()

            # Get input sample rate
            sr = input_sample_rate or self.target_sample_rate

            # Convert to mono if needed
            if len(audio_array.shape) > 1:
                audio_array = self._to_mono(audio_array)

            # Resample if needed
            if sr != self.target_sample_rate:
                audio_array = self._resample(audio_array, sr, self.target_sample_rate)
                sr = self.target_sample_rate

            # Normalize if enabled
            if self.normalize:
                audio_array = self._normalize(audio_array)

            logger.debug(f"Preprocessed audio: {len(audio_array)} samples at {sr}Hz")

            return audio_array, sr

        except Exception as e:
            raise AudioProcessingError(f"Failed to preprocess audio: {e}") from e

    def validate(
        self,
        audio: Union[bytes, np.ndarray],
        sample_rate: int,
    ) -> bool:
        """
        Validate audio data.

        Args:
            audio: Audio data (bytes or numpy array)
            sample_rate: Audio sample rate

        Returns:
            True if valid

        Raises:
            AudioValidationError: If validation fails
        """
        # Check size (for bytes)
        if isinstance(audio, bytes):
            if len(audio) > self.max_size_bytes:
                raise AudioValidationError(f"Audio size {len(audio)} exceeds maximum {self.max_size_bytes} bytes")
            audio_array = self._bytes_to_array(audio)
        else:
            audio_array = audio

        # Check duration
        duration_s = len(audio_array) / sample_rate
        if duration_s > self.max_duration_s:
            raise AudioValidationError(f"Audio duration {duration_s:.1f}s exceeds maximum {self.max_duration_s}s")

        # Check for empty audio
        if len(audio_array) == 0:
            raise AudioValidationError("Audio is empty")

        # Check for silence (very low energy)
        energy = np.sqrt(np.mean(audio_array**2))
        if energy < 1e-10:
            raise AudioValidationError("Audio appears to be silent")

        logger.debug(f"Audio validated: {duration_s:.1f}s, energy={energy:.4f}")

        return True

    def get_metadata(
        self,
        audio: Union[bytes, np.ndarray],
        sample_rate: int,
        audio_format: AudioFormat = AudioFormat.PCM,
    ) -> AudioMetadata:
        """
        Get metadata about audio data.

        Args:
            audio: Audio data
            sample_rate: Sample rate
            audio_format: Audio format

        Returns:
            AudioMetadata object
        """
        if isinstance(audio, bytes):
            audio_array = self._bytes_to_array(audio)
        else:
            audio_array = audio

        # Determine channels
        if len(audio_array.shape) > 1:
            channels = audio_array.shape[1]
            num_samples = audio_array.shape[0]
        else:
            channels = 1
            num_samples = len(audio_array)

        duration_s = num_samples / sample_rate

        return AudioMetadata(
            sample_rate=sample_rate,
            channels=channels,
            duration_s=duration_s,
            num_samples=num_samples,
            format=audio_format,
        )

    def _bytes_to_array(self, audio_bytes: bytes) -> np.ndarray:
        """
        Convert bytes to numpy array.

        Assumes 16-bit PCM format.

        Args:
            audio_bytes: Audio as bytes

        Returns:
            Audio as float32 numpy array (normalized to -1.0 to 1.0)
        """
        # Convert from 16-bit PCM to float32
        audio_array = np.frombuffer(audio_bytes, dtype=np.int16).astype(np.float32)

        # Normalize to -1.0 to 1.0
        audio_array = audio_array / 32768.0

        return audio_array

    def array_to_bytes(self, audio_array: np.ndarray) -> bytes:
        """
        Convert numpy array to bytes.

        Args:
            audio_array: Audio as float32 numpy array (normalized -1.0 to 1.0)

        Returns:
            Audio as 16-bit PCM bytes
        """
        # Clip to valid range
        audio_array = np.clip(audio_array, -1.0, 1.0)

        # Convert to 16-bit PCM
        audio_int16 = (audio_array * 32768.0).astype(np.int16)

        return audio_int16.tobytes()

    def _to_mono(self, audio: np.ndarray) -> np.ndarray:
        """
        Convert stereo audio to mono.

        Args:
            audio: Audio array (samples x channels)

        Returns:
            Mono audio array
        """
        if len(audio.shape) == 1:
            return audio

        # Average channels
        return np.mean(audio, axis=1)

    def _resample(
        self,
        audio: np.ndarray,
        orig_sr: int,
        target_sr: int,
    ) -> np.ndarray:
        """
        Resample audio to target sample rate.

        Uses linear interpolation for simple resampling.
        For higher quality, librosa.resample is recommended.

        Args:
            audio: Input audio array
            orig_sr: Original sample rate
            target_sr: Target sample rate

        Returns:
            Resampled audio array
        """
        if orig_sr == target_sr:
            return audio

        # Try to use librosa for high-quality resampling
        try:
            import librosa

            return librosa.resample(audio, orig_sr=orig_sr, target_sr=target_sr)
        except ImportError:
            pass

        # Fallback to scipy
        try:
            from scipy import signal

            # Calculate resampling ratio
            ratio = target_sr / orig_sr
            new_length = int(len(audio) * ratio)

            # Use scipy resample
            return signal.resample(audio, new_length)
        except ImportError:
            pass

        # Last resort: simple linear interpolation
        logger.warning("Using simple interpolation for resampling. Install librosa for better quality.")

        ratio = target_sr / orig_sr
        new_length = int(len(audio) * ratio)

        # Linear interpolation
        indices = np.linspace(0, len(audio) - 1, new_length)
        return np.interp(indices, np.arange(len(audio)), audio)

    def _normalize(self, audio: np.ndarray) -> np.ndarray:
        """
        Normalize audio to target peak level.

        Args:
            audio: Input audio array

        Returns:
            Normalized audio array
        """
        # Find peak amplitude
        peak = np.max(np.abs(audio))

        if peak < 1e-10:
            # Audio is silence, don't normalize
            return audio

        # Normalize to 0.95 peak (leaving some headroom)
        target_peak = 0.95
        return audio * (target_peak / peak)

    def detect_format(self, audio_bytes: bytes) -> AudioFormat:
        """
        Detect audio format from magic bytes.

        Args:
            audio_bytes: Audio file bytes

        Returns:
            Detected AudioFormat
        """
        if len(audio_bytes) < 12:
            return AudioFormat.UNKNOWN

        # WAV: starts with "RIFF"
        if audio_bytes[:4] == b"RIFF" and audio_bytes[8:12] == b"WAVE":
            return AudioFormat.WAV

        # MP3: starts with ID3 or 0xFF 0xFB
        if audio_bytes[:3] == b"ID3" or audio_bytes[:2] == b"\xff\xfb":
            return AudioFormat.MP3

        # FLAC: starts with "fLaC"
        if audio_bytes[:4] == b"fLaC":
            return AudioFormat.FLAC

        # OGG: starts with "OggS"
        if audio_bytes[:4] == b"OggS":
            return AudioFormat.OGG

        # M4A/MP4: ftyp box starts at offset 4 (per MP4/M4A file format spec)
        if len(audio_bytes) >= 8 and audio_bytes[4:8] == b"ftyp":
            return AudioFormat.M4A

        # WebM: starts with EBML header
        if audio_bytes[:4] == b"\x1a\x45\xdf\xa3":
            return AudioFormat.WEBM

        return AudioFormat.UNKNOWN

    def load_audio_file(self, audio_bytes: bytes) -> Tuple[np.ndarray, int]:
        """
        Load audio from file bytes (any supported format).

        Args:
            audio_bytes: Audio file bytes

        Returns:
            Tuple of (audio array, sample rate)

        Raises:
            AudioProcessingError: If loading fails
        """
        audio_format = self.detect_format(audio_bytes)

        # Try soundfile first (supports WAV, FLAC, OGG)
        try:
            import soundfile as sf

            audio_file = io.BytesIO(audio_bytes)
            audio_array, sample_rate = sf.read(audio_file)

            # Convert to float32 if needed
            if audio_array.dtype != np.float32:
                audio_array = audio_array.astype(np.float32)

            return audio_array, sample_rate
        except Exception as sf_error:
            logger.debug(f"soundfile failed: {sf_error}")

        # Try librosa (supports more formats)
        try:
            import librosa

            audio_file = io.BytesIO(audio_bytes)
            audio_array, sample_rate = librosa.load(audio_file, sr=None, mono=False)

            # librosa returns (channels, samples) for stereo, transpose if needed
            if len(audio_array.shape) > 1:
                audio_array = audio_array.T

            return audio_array, sample_rate
        except Exception as librosa_error:
            logger.debug(f"librosa failed: {librosa_error}")

        # Try pydub as last resort
        try:
            from pydub import AudioSegment

            audio_file = io.BytesIO(audio_bytes)

            # Detect format for pydub
            format_map = {
                AudioFormat.WAV: "wav",
                AudioFormat.MP3: "mp3",
                AudioFormat.FLAC: "flac",
                AudioFormat.M4A: "m4a",
                AudioFormat.OGG: "ogg",
            }

            fmt = format_map.get(audio_format, "wav")
            segment = AudioSegment.from_file(audio_file, format=fmt)

            # Convert to numpy array
            samples = np.array(segment.get_array_of_samples())

            # Handle stereo
            if segment.channels == 2:
                samples = samples.reshape((-1, 2))

            # Normalize to float32
            audio_array = samples.astype(np.float32) / (2 ** (segment.sample_width * 8 - 1))

            return audio_array, segment.frame_rate
        except Exception as pydub_error:
            logger.debug(f"pydub failed: {pydub_error}")

        raise AudioProcessingError(
            f"Failed to load audio file. Format: {audio_format}. "
            "Install soundfile, librosa, or pydub for better format support."
        )


# Convenience functions for common operations


def preprocess_audio(
    audio: Union[bytes, np.ndarray],
    input_sample_rate: int,
    target_sample_rate: int = 16000,
    normalize: bool = True,
) -> Tuple[np.ndarray, int]:
    """
    Preprocess audio to target format.

    Convenience function that creates a processor and preprocesses audio.

    Args:
        audio: Audio data (bytes or numpy array)
        input_sample_rate: Input sample rate
        target_sample_rate: Target sample rate (default: 16000)
        normalize: Whether to normalize audio (default: True)

    Returns:
        Tuple of (preprocessed audio array, sample rate)
    """
    processor = AudioProcessor(
        target_sample_rate=target_sample_rate,
        normalize=normalize,
    )
    return processor.preprocess(audio, input_sample_rate=input_sample_rate)


def validate_audio(
    audio: Union[bytes, np.ndarray],
    sample_rate: int,
    max_duration_s: int = 600,
    max_size_bytes: int = 50 * 1024 * 1024,
) -> bool:
    """
    Validate audio data.

    Convenience function that creates a processor and validates audio.

    Args:
        audio: Audio data (bytes or numpy array)
        sample_rate: Audio sample rate
        max_duration_s: Maximum duration in seconds
        max_size_bytes: Maximum size in bytes

    Returns:
        True if valid

    Raises:
        AudioValidationError: If validation fails
    """
    processor = AudioProcessor(
        max_duration_s=max_duration_s,
        max_size_bytes=max_size_bytes,
    )
    return processor.validate(audio, sample_rate)
