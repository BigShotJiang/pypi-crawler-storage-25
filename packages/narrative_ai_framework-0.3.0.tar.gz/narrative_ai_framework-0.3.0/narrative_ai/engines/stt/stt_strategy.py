"""
STT Strategy - Provider Selection and Fallback Logic.

Production-ready implementation with:
- Configurable circuit breaker
- Correlation ID propagation
- Structured logging
"""

import asyncio
import time
import logging
from dataclasses import dataclass
from typing import Optional, Dict, List, Any, AsyncIterator

from .base_stt import (
    BaseSTTProvider,
    STTResult,
    STTError,
    TranscriptionError,
    ProviderUnavailableError,
)
from .config import STTConfig

logger = logging.getLogger(__name__)


@dataclass
class CircuitBreakerConfig:
    """
    Configuration for circuit breaker pattern.

    Attributes:
        failure_threshold: Number of failures before opening circuit
        recovery_timeout: Seconds to wait before attempting recovery
    """

    failure_threshold: int = 3
    recovery_timeout: float = 60.0


class STTStrategy:
    """
    Strategy manager for STT providers with fallback support.

    Manages multiple STT providers and implements:
    - Primary provider selection
    - Automatic fallback on failure
    - Provider health monitoring
    - Result confidence filtering

    Example:
        strategy = STTStrategy(
            providers={"elevenlabs": elevenlabs_provider, "whisper": whisper_provider},
            primary="elevenlabs",
            fallback_order=["whisper"],
            min_confidence=0.6,
        )

        result = await strategy.transcribe(audio)
        # Uses elevenlabs, falls back to whisper if it fails
    """

    def __init__(
        self,
        providers: Dict[str, BaseSTTProvider],
        primary: str = "elevenlabs",
        fallback_order: Optional[List[str]] = None,
        min_confidence: float = 0.6,
        enable_fallback: bool = True,
        circuit_breaker_config: Optional[CircuitBreakerConfig] = None,
        allow_degraded_mode: bool = False,
    ):
        """
        Initialize STT strategy.

        Args:
            providers: Dict of provider name -> provider instance
            primary: Name of primary provider
            fallback_order: Order of fallback providers (after primary)
            min_confidence: Minimum confidence to accept result
            enable_fallback: Whether to enable automatic fallback
            circuit_breaker_config: Circuit breaker configuration
            allow_degraded_mode: Return degraded result instead of raising when all providers fail
        """
        self.providers = providers
        self.primary = primary
        self.fallback_order = fallback_order or list(p for p in providers.keys() if p != primary)
        self.min_confidence = min_confidence
        self.enable_fallback = enable_fallback
        self.allow_degraded_mode = allow_degraded_mode

        # Circuit breaker config
        self._cb_config = circuit_breaker_config or CircuitBreakerConfig()

        # Provider health tracking
        self._provider_failures: Dict[str, int] = {name: 0 for name in providers}
        self._provider_last_failure: Dict[str, float] = {}
        self._provider_last_success: Dict[str, float] = {}

    @classmethod
    def from_config(cls, config: STTConfig) -> "STTStrategy":
        """
        Create strategy from configuration.

        Args:
            config: STT configuration

        Returns:
            Configured STTStrategy instance
        """
        from .elevenlabs_stt import ElevenLabsSTTProvider
        from .whisper_stt import WhisperSTTProvider
        from .faster_whisper_stt import FasterWhisperSTTProvider, _is_ct2_model_path

        # Only create providers that are in use (primary or fallback) to save memory and avoid loading unused backends
        needed = {config.primary_provider} | set(config.fallback_providers)
        providers: Dict[str, BaseSTTProvider] = {}

        if "elevenlabs" in needed and config.elevenlabs.api_key:
            providers["elevenlabs"] = ElevenLabsSTTProvider(config.elevenlabs)

        if "whisper" in needed:
            if _is_ct2_model_path(config.whisper.model_path):
                providers["whisper"] = FasterWhisperSTTProvider(config.whisper)
            else:
                providers["whisper"] = WhisperSTTProvider(config.whisper)

        if not providers:
            raise ValueError(
                "No STT providers could be created. "
                "Ensure ELEVENLABS_API_KEY is set for elevenlabs, or whisper/faster-whisper dependencies are installed. "
                f"Requested: primary={config.primary_provider}, fallbacks={config.fallback_providers}"
            )
        if config.primary_provider not in providers:
            logger.warning(
                "Primary provider %r not available (e.g. missing API key), using first fallback",
                config.primary_provider,
            )
            # Use first available as primary
            first_available = next(iter(providers))
            primary = first_available
            fallback_order = [p for p in config.fallback_providers if p in providers and p != primary]
        else:
            primary = config.primary_provider
            fallback_order = [p for p in config.fallback_providers if p in providers and p != primary]

        return cls(
            providers=providers,
            primary=primary,
            fallback_order=fallback_order,
            min_confidence=config.min_confidence,
            allow_degraded_mode=config.allow_degraded_mode,
        )

    async def transcribe(
        self,
        audio: bytes,
        sample_rate: int = 16000,
        language: Optional[str] = None,
        provider: Optional[str] = None,
        correlation_id: Optional[str] = None,
        use_provider_vad: Optional[bool] = None,
    ) -> STTResult:
        """
        Transcribe audio using strategy with fallback.

        Args:
            audio: Audio data as bytes
            sample_rate: Audio sample rate
            language: Optional language code
            provider: Force specific provider (skip fallback)
            correlation_id: Request correlation ID for tracing
            use_provider_vad: If False, disable provider internal VAD (e.g. for TTS/synthetic fallback)

        Returns:
            STTResult from successful provider

        Raises:
            TranscriptionError: If all providers fail
        """
        start_time = time.time()

        # If specific provider requested and it exists, use it directly.
        # Otherwise fall back to default order (handles Swagger "string" placeholder, typos, etc.)
        if provider and provider in self.providers:
            return await self._transcribe_with_provider(
                provider, audio, sample_rate, language, correlation_id, use_provider_vad
            )
        elif provider and provider not in self.providers:
            logger.warning(
                "Requested provider %r not found, falling back to default order",
                provider,
                extra={"correlation_id": correlation_id},
            )

        # Build provider order
        provider_order = self._get_provider_order()

        if not provider_order:
            # Graceful degradation: return degraded result if enabled
            if self.allow_degraded_mode:
                logger.warning(
                    "All providers unavailable, returning degraded result", extra={"correlation_id": correlation_id}
                )
                return STTResult(
                    text="",
                    confidence=0.0,
                    language="unknown",
                    provider="degraded",
                    processing_time=0.0,
                    is_partial=False,
                    is_final=True,
                    metadata={"degraded": True, "reason": "All providers unavailable"},
                )
            raise TranscriptionError(
                "No available providers",
                provider="strategy",
            )

        # Try providers in order with total timeout across all fallbacks
        total_timeout = 30.0
        last_error: Optional[Exception] = None
        tried_providers: List[str] = []

        for provider_name in provider_order:
            tried_providers.append(provider_name)
            remaining = total_timeout - (time.time() - start_time)
            if remaining <= 0:
                raise TranscriptionError(
                    "Exceeded total timeout across providers",
                    provider=provider_name,
                )

            try:
                result = await asyncio.wait_for(
                    self._transcribe_with_provider(
                        provider_name, audio, sample_rate, language, correlation_id, use_provider_vad
                    ),
                    timeout=remaining,
                )

                # Check confidence threshold
                if result.confidence >= self.min_confidence:
                    self._record_success(provider_name)

                    # Log if we had to fallback
                    if len(tried_providers) > 1:
                        logger.info(
                            "STT succeeded after fallback",
                            extra={
                                "correlation_id": correlation_id,
                                "successful_provider": provider_name,
                                "tried_providers": tried_providers,
                            },
                        )

                    return result

                # Low confidence - try next provider if available
                logger.warning(
                    "Provider returned low confidence",
                    extra={
                        "correlation_id": correlation_id,
                        "provider": provider_name,
                        "confidence": result.confidence,
                        "threshold": self.min_confidence,
                    },
                )

                if not self.enable_fallback:
                    return result

                last_error = TranscriptionError(
                    f"Low confidence: {result.confidence:.2f}",
                    provider=provider_name,
                )

            except asyncio.TimeoutError:
                logger.warning(
                    "Provider timed out",
                    extra={
                        "correlation_id": correlation_id,
                        "provider": provider_name,
                        "remaining_seconds": remaining,
                    },
                )
                self._record_failure(provider_name)
                last_error = TranscriptionError(
                    f"Provider timed out after {remaining:.1f}s",
                    provider=provider_name,
                )
            except STTError as e:
                logger.warning(
                    "Provider failed",
                    extra={
                        "correlation_id": correlation_id,
                        "provider": provider_name,
                        "error": str(e),
                        "retriable": e.retriable,
                    },
                )
                self._record_failure(provider_name)
                last_error = e

                if not self.enable_fallback:
                    raise

                # Log when attempting fallback for non-retriable error (parity with LLM strategy)
                if not e.retriable:
                    logger.info(
                        "Non-retriable error encountered, attempting fallback",
                        extra={
                            "correlation_id": correlation_id,
                            "provider": provider_name,
                            "error": str(e),
                        },
                    )

        # All providers failed
        total_time = time.time() - start_time

        # Graceful degradation: return degraded result if enabled
        if self.allow_degraded_mode:
            logger.warning(
                "All providers failed, returning degraded result",
                extra={
                    "correlation_id": correlation_id,
                    "tried_providers": tried_providers,
                    "last_error": str(last_error),
                },
            )
            return STTResult(
                text="",
                confidence=0.0,
                language="unknown",
                provider="degraded",
                processing_time=total_time,
                is_partial=False,
                is_final=True,
                metadata={
                    "degraded": True,
                    "reason": "All providers failed",
                    "tried_providers": tried_providers,
                    "last_error": str(last_error),
                },
            )

        error = TranscriptionError(
            f"All providers failed after {total_time:.2f}s",
            provider="strategy",
            details={
                "tried_providers": tried_providers,
                "last_error": str(last_error),
            },
        )

        if last_error:
            error.__cause__ = last_error

        raise error

    async def transcribe_streaming(
        self,
        audio_stream: AsyncIterator[bytes],
        sample_rate: int = 16000,
        language: Optional[str] = None,
        provider: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> AsyncIterator[STTResult]:
        """
        Stream transcription with fallback.

        Note: Fallback is limited for streaming since we can't replay
        the stream. We only fallback before streaming starts.

        Args:
            audio_stream: Async iterator of audio chunks
            sample_rate: Audio sample rate
            language: Language code
            provider: Force specific provider

        Yields:
            STTResult objects
        """
        # Select provider
        provider_name = provider or self._get_best_available_provider()

        if not provider_name:
            raise TranscriptionError(
                "No available providers for streaming",
                provider="strategy",
            )

        stt_provider = self.providers.get(provider_name)

        if not stt_provider:
            raise ProviderUnavailableError(
                f"Provider {provider_name} not found",
                provider="strategy",
            )

        logger.info(
            f"Streaming with provider: {provider_name}",
            extra={"correlation_id": correlation_id} if correlation_id else {},
        )

        try:
            # Lazy-load provider if not yet loaded (allows fast startup)
            if not getattr(stt_provider, "_is_loaded", False):
                await stt_provider.load_model()
            async for result in stt_provider.transcribe_streaming(audio_stream, sample_rate, language):
                # Add correlation ID to result if not present
                if correlation_id and not result.metadata.get("correlation_id"):
                    result.metadata = result.metadata or {}
                    result.metadata["correlation_id"] = correlation_id
                yield result

            self._record_success(provider_name)

        except STTError as e:
            logger.error(f"Streaming failed with {provider_name}: {e}")
            self._record_failure(provider_name)
            raise

    async def _transcribe_with_provider(
        self,
        provider_name: str,
        audio: bytes,
        sample_rate: int,
        language: Optional[str],
        correlation_id: Optional[str] = None,
        use_provider_vad: Optional[bool] = None,
    ) -> STTResult:
        """
        Transcribe with specific provider.

        Args:
            provider_name: Provider name
            audio: Audio data
            sample_rate: Sample rate
            language: Language code
            correlation_id: Request correlation ID
            use_provider_vad: If set, override provider internal VAD for this call (e.g. False for TTS fallback)

        Returns:
            STTResult
        """
        provider = self.providers.get(provider_name)

        if not provider:
            raise ProviderUnavailableError(
                f"Provider {provider_name} not found",
                provider=provider_name,
            )

        if not provider.is_available():
            raise ProviderUnavailableError(
                f"Provider {provider_name} is not available",
                provider=provider_name,
            )

        # Lazy-load provider if not yet loaded (allows fast startup)
        if not getattr(provider, "_is_loaded", False):
            await provider.load_model()

        logger.debug(
            "Transcribing with provider",
            extra={
                "correlation_id": correlation_id,
                "provider": provider_name,
            },
        )
        kwargs = {}
        if use_provider_vad is not None:
            kwargs["use_provider_vad"] = use_provider_vad
        return await provider.transcribe(audio, sample_rate, language, correlation_id, **kwargs)

    def _get_provider_order(self) -> List[str]:
        """
        Get ordered list of providers to try.

        Filters out unhealthy providers (circuit breaker).

        Returns:
            List of provider names in order
        """
        order = []

        # Add primary if healthy
        if self._is_provider_healthy(self.primary):
            order.append(self.primary)

        # Add fallbacks if healthy
        for provider_name in self.fallback_order:
            if provider_name not in order and self._is_provider_healthy(provider_name):
                order.append(provider_name)

        # If no healthy providers, include all available as fallback
        if not order:
            order = [
                name
                for name in [self.primary] + self.fallback_order
                if name in self.providers and self.providers[name].is_available()
            ]

        return order

    def _get_best_available_provider(self) -> Optional[str]:
        """
        Get the best available provider.

        Returns:
            Provider name or None
        """
        order = self._get_provider_order()
        return order[0] if order else None

    def _is_provider_healthy(self, provider_name: str) -> bool:
        """
        Check if provider is healthy using circuit breaker pattern.

        Args:
            provider_name: Provider name

        Returns:
            True if healthy
        """
        if provider_name not in self.providers:
            return False

        if not self.providers[provider_name].is_available():
            return False

        # Check circuit breaker
        failures = self._provider_failures.get(provider_name, 0)

        if failures >= self._cb_config.failure_threshold:
            # Check if recovery timeout passed
            last_failure = self._provider_last_failure.get(provider_name, 0)
            time_since_failure = time.time() - last_failure

            if time_since_failure < self._cb_config.recovery_timeout:
                logger.debug(
                    "Circuit breaker open",
                    extra={
                        "provider": provider_name,
                        "failures": failures,
                        "time_until_retry": self._cb_config.recovery_timeout - time_since_failure,
                    },
                )
                return False
            else:
                # Half-open: allow retry
                logger.info("Circuit breaker half-open, allowing retry", extra={"provider": provider_name})
                self._provider_failures[provider_name] = 0

        return True

    def _record_success(self, provider_name: str) -> None:
        """Record successful provider usage."""
        self._provider_failures[provider_name] = 0
        self._provider_last_success[provider_name] = time.time()

    def _record_failure(self, provider_name: str) -> None:
        """Record provider failure."""
        self._provider_failures[provider_name] = self._provider_failures.get(provider_name, 0) + 1
        self._provider_last_failure[provider_name] = time.time()

        failures = self._provider_failures[provider_name]
        if failures >= self._cb_config.failure_threshold:
            logger.warning(
                "Circuit breaker opened",
                extra={
                    "provider": provider_name,
                    "failures": failures,
                    "recovery_timeout": self._cb_config.recovery_timeout,
                },
            )

    def set_circuit_breaker_config(self, config: CircuitBreakerConfig) -> None:
        """Update circuit breaker configuration at runtime."""
        self._cb_config = config
        logger.info(
            "Updated circuit breaker config",
            extra={
                "failure_threshold": config.failure_threshold,
                "recovery_timeout": config.recovery_timeout,
            },
        )

    def reset_circuit_breaker(self, provider_name: Optional[str] = None) -> None:
        """
        Reset circuit breaker for one or all providers.

        Args:
            provider_name: Specific provider to reset, or None for all
        """
        if provider_name:
            self._provider_failures[provider_name] = 0
            logger.info("Reset circuit breaker", extra={"provider": provider_name})
        else:
            for name in self._provider_failures:
                self._provider_failures[name] = 0
            logger.info("Reset all circuit breakers")

    async def initialize(self) -> None:
        """
        Initialize all providers.

        Call this to pre-load models before first transcription.
        """
        # Optimization: by default, only preload the primary provider.
        # Loading Whisper can be expensive and isn't needed unless fallback occurs.
        import os

        preload_all = os.getenv("STT_PRELOAD_ALL", "").strip() == "1"

        to_init = list(self.providers.keys()) if preload_all else [self.primary]
        for name in to_init:
            provider = self.providers.get(name)
            if provider is None:
                continue
            try:
                if provider.is_available():
                    await provider.load_model()
                    logger.info(f"Initialized provider: {name}")
            except Exception as e:
                logger.warning(f"Failed to initialize {name}: {e}")

    async def shutdown(self) -> None:
        """Shutdown all providers."""
        for name, provider in self.providers.items():
            try:
                await provider.shutdown()
                logger.info(f"Shutdown provider: {name}")
            except Exception as e:
                logger.warning(f"Failed to shutdown {name}: {e}")

    def get_provider(self, name: str) -> Optional[BaseSTTProvider]:
        """
        Get a specific provider.

        Args:
            name: Provider name

        Returns:
            Provider instance or None
        """
        return self.providers.get(name)

    def set_primary(self, provider_name: str) -> None:
        """
        Change primary provider.

        Args:
            provider_name: New primary provider name

        Raises:
            ValueError: If provider not found
        """
        if provider_name not in self.providers:
            raise ValueError(f"Provider {provider_name} not found")

        self.primary = provider_name
        logger.info(f"Changed primary provider to: {provider_name}")

    def add_provider(
        self,
        name: str,
        provider: BaseSTTProvider,
        add_to_fallback: bool = True,
    ) -> None:
        """
        Add a new provider.

        Args:
            name: Provider name
            provider: Provider instance
            add_to_fallback: Add to fallback order
        """
        self.providers[name] = provider
        self._provider_failures[name] = 0

        if add_to_fallback and name not in self.fallback_order:
            self.fallback_order.append(name)

        logger.info(f"Added provider: {name}")

    def remove_provider(self, name: str) -> None:
        """
        Remove a provider.

        Args:
            name: Provider name
        """
        if name in self.providers:
            del self.providers[name]

        if name in self._provider_failures:
            del self._provider_failures[name]

        if name in self.fallback_order:
            self.fallback_order.remove(name)

        if name == self.primary and self.fallback_order:
            self.primary = self.fallback_order[0]

        logger.info(f"Removed provider: {name}")

    async def health_check(self) -> Dict[str, Any]:
        """
        Check health of all providers.

        Returns:
            Health status for each provider
        """
        health = {
            "primary": self.primary,
            "fallback_order": self.fallback_order,
            "providers": {},
        }

        for name, provider in self.providers.items():
            try:
                # Apply timeout to health check to prevent hanging
                import asyncio

                timeout = 5.0  # 5 second timeout for health checks
                provider_health = await asyncio.wait_for(provider.health_check(), timeout=timeout)
                provider_health["circuit_open"] = not self._is_provider_healthy(name)
                provider_health["failure_count"] = self._provider_failures.get(name, 0)
                health["providers"][name] = provider_health
            except asyncio.TimeoutError:
                health["providers"][name] = {
                    "available": False,
                    "error": f"Health check timed out after {timeout}s",
                    "circuit_open": True,
                }
                # Record failure for timeout
                self._record_failure(name)
            except Exception as e:
                health["providers"][name] = {
                    "available": False,
                    "error": str(e),
                    "circuit_open": True,
                }
                self._record_failure(name)

        return health

    def get_status(self) -> Dict[str, Any]:
        """
        Get current strategy status.

        Returns:
            Status dict
        """
        return {
            "primary": self.primary,
            "fallback_order": self.fallback_order,
            "min_confidence": self.min_confidence,
            "enable_fallback": self.enable_fallback,
            "provider_order": self._get_provider_order(),
            "provider_failures": self._provider_failures.copy(),
        }
