"""
ElevenLabs STT Provider - Priority API-based Provider.

Production-ready implementation with:
- Connection pool limits to prevent socket exhaustion
- Exponential backoff with jitter to prevent thundering herd
- Correlation ID propagation for tracing
- Structured logging

API Reference:
- Batch: POST /v1/speech-to-text (Scribe v2)
- Streaming: WebSocket for real-time transcription
"""

import asyncio
import os
import random
import time
import logging
from typing import Optional, Dict, Any, AsyncIterator, List
import json
import struct
import io
import base64
from urllib.parse import urlencode

from .base_stt import (
    BaseSTTProvider,
    STTResult,
    TranscriptionError,
    ProviderUnavailableError,
    RateLimitError,
    STTTimeoutError,
    STTNetworkError,
    AudioFormatError,
)
from .config import ElevenLabsConfig

logger = logging.getLogger(__name__)

# Retry-After parsing (RFC 7231) - at module level to avoid import inside retry loop
try:
    from narrative_ai.shared.retry_utils import parse_retry_after
except ImportError:

    def parse_retry_after(header: Optional[str], default_seconds: int) -> int:
        """Fallback if retry_utils not available."""
        if not header:
            return default_seconds
        try:
            return int(header)
        except (ValueError, TypeError):
            return default_seconds


# Connection pool configuration
DEFAULT_POOL_LIMIT = 100
DEFAULT_POOL_LIMIT_PER_HOST = 30


class ElevenLabsSTTProvider(BaseSTTProvider):
    """
    ElevenLabs STT Provider using Scribe API.

    Features:
    - Batch transcription via REST API
    - Streaming transcription via WebSocket
    - Multi-language support (Arabic, English, etc.)
    - Word-level timestamps
    - Automatic retry with exponential backoff

    Example:
        config = ElevenLabsConfig(api_key="your_api_key")
        provider = ElevenLabsSTTProvider(config)

        result = await provider.transcribe(audio_bytes)
        print(result.text)
    """

    # API endpoints
    BASE_URL = "https://api.elevenlabs.io/v1"
    STT_ENDPOINT = "/speech-to-text"
    # Realtime STT WebSocket endpoint (ElevenLabs API reference: /v1/speech-to-text/realtime)
    STREAMING_ENDPOINT = "wss://api.elevenlabs.io/v1/speech-to-text/realtime"

    def __init__(
        self,
        config: Optional[ElevenLabsConfig] = None,
        pool_limit: int = DEFAULT_POOL_LIMIT,
        pool_limit_per_host: int = DEFAULT_POOL_LIMIT_PER_HOST,
    ):
        """
        Initialize ElevenLabs STT provider.

        Args:
            config: ElevenLabs configuration (uses env vars if not provided)
            pool_limit: Total connection pool limit
            pool_limit_per_host: Connection limit per host
        """
        super().__init__()
        self.config = config or ElevenLabsConfig()
        self._pool_limit = pool_limit
        self._pool_limit_per_host = pool_limit_per_host
        self._client = None
        self._http_session = None
        self._connector = None
        self._ws_session = None  # Shared session for WebSocket connections (reused across streaming calls)
        # Initialize lock immediately to avoid race conditions during lazy initialization
        # The lock will be bound to the event loop when first used
        self._ws_session_lock: Optional[asyncio.Lock] = None
        # Track active streaming sessions for graceful shutdown
        self._active_streaming_count = 0
        self._active_streaming_lock: Optional[asyncio.Lock] = None

    async def _ensure_ws_session(self) -> None:
        """
        Ensure WebSocket session is available and properly initialized.

        This method handles session creation, recreation, and cleanup atomically
        to prevent race conditions and connection leaks.
        """
        # Initialize locks if needed (bound to current event loop)
        if self._ws_session_lock is None:
            self._ws_session_lock = asyncio.Lock()
        if self._active_streaming_lock is None:
            self._active_streaming_lock = asyncio.Lock()

        async with self._ws_session_lock:
            # Check if session exists and is still open
            if self._ws_session and not self._ws_session.closed:
                return

            # Properly close old session before creating new one
            if self._ws_session:
                try:
                    await self._ws_session.close()
                except Exception as e:
                    logger.warning(f"Error closing old WebSocket session: {e}")
                self._ws_session = None

            # Create new session
            import aiohttp

            self._ws_session = aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(
                    limit=10,
                    limit_per_host=5,
                    ttl_dns_cache=300,
                    enable_cleanup_closed=True,
                ),
                timeout=aiohttp.ClientTimeout(total=300, connect=10),
            )
            logger.debug("ElevenLabs STT: Created new WebSocket session")

    async def _load_model_impl(self) -> None:
        """Initialize HTTP client with connection pooling."""
        try:
            import aiohttp

            # Create connector with pool limits
            self._connector = aiohttp.TCPConnector(
                limit=self._pool_limit,
                limit_per_host=self._pool_limit_per_host,
                ttl_dns_cache=300,
                enable_cleanup_closed=True,
            )

            self._http_session = aiohttp.ClientSession(
                connector=self._connector,
                timeout=aiohttp.ClientTimeout(
                    total=self.config.timeout,
                    connect=10,
                    sock_read=30,
                ),
            )

            # Create shared WebSocket session for connection reuse
            # Reusing the same session improves performance and prevents socket exhaustion
            self._ws_session = aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(
                    limit=10,
                    limit_per_host=5,
                    ttl_dns_cache=300,
                    enable_cleanup_closed=True,
                ),
                timeout=aiohttp.ClientTimeout(total=300, connect=10),  # 5min total, 10s connect
            )

            # Optional: verify API key via GET /user. Skip if ELEVENLABS_SKIP_KEY_VERIFY=1.
            # Some valid keys get 401 on /user (e.g. free tier, scoped keys, or IP restrictions)
            # but still work for STT; we treat 401 as warning and continue so actual STT can be tried.
            api_key = (self.config.api_key or "").strip()
            skip_verify = (os.environ.get("ELEVENLABS_SKIP_KEY_VERIFY") or "").strip().lower() in ("1", "true", "yes")
            if api_key and not skip_verify:
                async with self._http_session.get(f"{self.BASE_URL}/user", headers={"xi-api-key": api_key}) as response:
                    if response.status == 401:
                        logger.warning(
                            "ElevenLabs GET /user returned 401 (key not accepted for user endpoint). "
                            "Continuing anyway; STT may still work (some keys/scenarios get 401 here but work for STT). "
                            "Set ELEVENLABS_SKIP_KEY_VERIFY=1 to skip this check. "
                            "See elevenlabs.io/app/settings/api-keys and consider upgrading if on free tier."
                        )
                    elif response.status == 200:
                        logger.info("ElevenLabs API key verified")

            self._is_loaded = True

        except ImportError:
            raise ProviderUnavailableError(
                "aiohttp required. Run: pip install aiohttp", provider=self.get_provider_name()
            )

    async def _shutdown_impl(self) -> None:
        """Cleanup HTTP session, WebSocket session, connector, and lock."""
        # Wait for active streaming sessions to finish (max 30s) before closing WebSocket
        shutdown_wait_timeout = 30.0
        poll_interval = 0.5
        waited = 0.0
        if self._active_streaming_lock is not None:
            while waited < shutdown_wait_timeout:
                async with self._active_streaming_lock:
                    count = self._active_streaming_count
                if count <= 0:
                    break
                logger.debug(
                    "ElevenLabs STT: Waiting for %d active streaming session(s) to finish (%.1fs remaining)",
                    count,
                    shutdown_wait_timeout - waited,
                )
                await asyncio.sleep(poll_interval)
                waited += poll_interval

        if self._ws_session:
            try:
                await self._ws_session.close()
            except Exception as e:
                logger.warning(f"Error closing WebSocket session during shutdown: {e}")
            self._ws_session = None

        self._ws_session_lock = None
        self._active_streaming_lock = None

        if self._http_session:
            await self._http_session.close()
            self._http_session = None

        if self._connector:
            await self._connector.close()
            self._connector = None

        self._is_loaded = False

    def _calculate_backoff_with_jitter(self, attempt: int, base_delay: float = 1.0) -> float:
        """
        Calculate exponential backoff with jitter.

        Uses "full jitter" strategy to prevent thundering herd.

        Args:
            attempt: Current attempt number (0-indexed)
            base_delay: Base delay in seconds

        Returns:
            Delay in seconds with jitter applied
        """
        cap = 30.0  # Maximum delay cap
        exponential_delay = min(cap, base_delay * (2**attempt))
        return random.uniform(0, exponential_delay)

    def is_available(self) -> bool:
        """Check if provider is available."""
        return self.config.api_key is not None and len(self.config.api_key) > 0

    def get_provider_name(self) -> str:
        """Get provider name."""
        return "elevenlabs"

    def get_supported_languages(self) -> List[str]:
        """Get supported languages."""
        # ElevenLabs Scribe supports many languages
        return ["ar", "en", "es", "fr", "de", "it", "pt", "zh", "ja", "ko", "mixed"]

    def _create_form_data(
        self,
        wav_audio: bytes,
        language: Optional[str],
    ):
        """
        Create a new FormData for each request.

        FormData objects are not reusable after being sent.

        Args:
            wav_audio: WAV formatted audio bytes
            language: Optional language code

        Returns:
            New aiohttp.FormData instance
        """
        import aiohttp

        form = aiohttp.FormData()
        # ElevenLabs expects field name "file" (not "audio")
        form.add_field("file", wav_audio, filename="audio.wav", content_type="audio/wav")
        form.add_field("model_id", self.config.model_id)

        if language:
            form.add_field("language_code", language)

        return form

    async def transcribe(
        self,
        audio: bytes,
        sample_rate: int = 16000,
        language: Optional[str] = None,
        correlation_id: Optional[str] = None,
        **kwargs: Any,
    ) -> STTResult:
        """
        Transcribe audio using ElevenLabs Scribe API.

        Args:
            audio: Audio data as bytes (16-bit PCM)
            sample_rate: Audio sample rate (default: 16000)
            language: Language code (None for auto-detect)

        Returns:
            STTResult with transcription

        Raises:
            TranscriptionError: If transcription fails
            RateLimitError: If rate limited
            ProviderUnavailableError: If provider not available
        """
        if not self.is_available():
            raise ProviderUnavailableError("ElevenLabs API key not configured", provider=self.get_provider_name())

        # Ensure session is ready
        if not self._http_session:
            await self.load_model()

        start_time = time.time()

        # Prepare audio file - convert PCM to WAV
        wav_audio = self._pcm_to_wav(audio, sample_rate)

        # Prepare request headers (use stripped key)
        headers = {
            "xi-api-key": (self.config.api_key or "").strip(),
        }

        # Make request with retry
        last_error = None
        for attempt in range(self.config.retry_attempts):
            try:
                # Create fresh FormData for each attempt (FormData is not reusable)
                form = self._create_form_data(wav_audio, language)

                async with self._http_session.post(
                    f"{self.BASE_URL}{self.STT_ENDPOINT}",
                    headers=headers,
                    data=form,
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        processing_time = time.time() - start_time

                        return self._parse_response(data, processing_time)

                    elif response.status == 429:
                        # Rate limited - respect Retry-After per RFC 7231 (delay-seconds or HTTP-date)
                        retry_after = parse_retry_after(
                            response.headers.get("Retry-After"),
                            default_seconds=5,
                        )
                        logger.warning(f"Rate limited, waiting {retry_after}s (Retry-After respected)")

                        if attempt < self.config.retry_attempts - 1:
                            await asyncio.sleep(retry_after)
                            continue
                        else:
                            raise RateLimitError(
                                f"Rate limited after {self.config.retry_attempts} attempts",
                                provider=self.get_provider_name(),
                            )

                    elif response.status == 401:
                        raise ProviderUnavailableError("Invalid API key", provider=self.get_provider_name())

                    else:
                        error_text = await response.text()
                        last_error = TranscriptionError(
                            f"API error {response.status}: {error_text}", provider=self.get_provider_name()
                        )

            except asyncio.TimeoutError as e:
                last_error = STTTimeoutError("Request timed out", provider=self.get_provider_name())
                last_error.__cause__ = e
            except (ProviderUnavailableError, RateLimitError):
                raise
            except (ConnectionError, OSError) as e:
                last_error = STTNetworkError(f"Network error: {e}", provider=self.get_provider_name())
                last_error.__cause__ = e
            except Exception as e:
                try:
                    import aiohttp

                    if aiohttp is not None and isinstance(e, aiohttp.ClientError):
                        last_error = STTNetworkError(
                            f"Connection error: {e}",
                            provider=self.get_provider_name(),
                        )
                    else:
                        last_error = TranscriptionError(
                            f"Request failed: {e}",
                            provider=self.get_provider_name(),
                        )
                except ImportError:
                    last_error = TranscriptionError(
                        f"Request failed: {e}",
                        provider=self.get_provider_name(),
                    )
                last_error.__cause__ = e

            # Exponential backoff with jitter
            if attempt < self.config.retry_attempts - 1:
                wait_time = self._calculate_backoff_with_jitter(attempt, self.config.retry_backoff)
                logger.warning(
                    "Retrying STT request",
                    extra={
                        "attempt": attempt + 1,
                        "wait_time": wait_time,
                        "error": str(last_error),
                    },
                )
                await asyncio.sleep(wait_time)

        if last_error:
            raise last_error

        raise TranscriptionError("Transcription failed after all retries", provider=self.get_provider_name())

    async def transcribe_streaming(
        self,
        audio_stream: AsyncIterator[bytes],
        sample_rate: int = 16000,
        language: Optional[str] = None,
    ) -> AsyncIterator[STTResult]:
        """
        Stream transcription with interim results.

        Uses WebSocket connection for real-time transcription.

        Args:
            audio_stream: Async iterator of audio chunks
            sample_rate: Audio sample rate
            language: Language code

        Yields:
            STTResult objects (partial and final)
        """
        if not self.is_available():
            raise ProviderUnavailableError("ElevenLabs API key not configured", provider=self.get_provider_name())

        try:
            import aiohttp
        except ImportError:
            raise ProviderUnavailableError("aiohttp required for streaming", provider=self.get_provider_name())

        start_time = time.time()

        # Build WebSocket URL with query params (ElevenLabs Realtime STT API)
        # NOTE: The realtime endpoint requires JSON messages with base64 audio and a "message_type".
        # Sending raw bytes (ws.send_bytes) is not supported.
        # Realtime API only supports scribe_v2_realtime; if config has scribe_v2, use realtime model.
        streaming_model = self.config.streaming_model_id
        if streaming_model == "scribe_v2":
            streaming_model = "scribe_v2_realtime"
        query: Dict[str, Any] = {
            "model_id": streaming_model,
            # We send 16-bit PCM chunks; declare the audio format for the session.
            "audio_format": self._to_elevenlabs_audio_format(sample_rate),
            # We rely on server-side VAD to commit segments (since we don't send explicit commit events).
            "commit_strategy": "vad",
            # Force commit faster for real-time (default ~1.5s); configurable via config.
            "vad_silence_threshold_secs": getattr(self.config, "vad_silence_threshold_secs", 0.8),
            "include_timestamps": getattr(self.config, "include_timestamps", False),
        }
        if language:
            query["language_code"] = language

        # Preprocess booleans: urlencode converts False to "False" (capital F); APIs expect "false"
        query_for_encode = {k: str(v).lower() if isinstance(v, bool) else v for k, v in query.items()}
        ws_url = f"{self.STREAMING_ENDPOINT}?{urlencode(query_for_encode)}"

        headers = {
            "xi-api-key": (self.config.api_key or "").strip(),
        }

        # Ensure WebSocket session is available and properly initialized
        # This handles session creation, recreation, and cleanup atomically
        await self._ensure_ws_session()

        async with self._active_streaming_lock:
            self._active_streaming_count += 1

        try:
            logger.info(
                "ElevenLabs STT: Connecting to WebSocket (reusing session)",
                extra={"url": ws_url, "provider": self.get_provider_name()},
            )
            async with self._ws_session.ws_connect(ws_url, headers=headers) as ws:
                logger.info(
                    "ElevenLabs STT: WebSocket connected successfully", extra={"provider": self.get_provider_name()}
                )
                # Create tasks for sending and receiving
                send_task = asyncio.create_task(self._send_audio(ws, audio_stream, sample_rate))

                last_partial_text = ""
                received_final_transcript = False
                message_count = 0
                send_task_completed = False
                send_task_done_at = (
                    None  # When we first saw send_task.done() with partial; wait 0.3s before forcing final
                )

                # Receive transcriptions with timeout
                receive_timeout = 30.0  # 30 second timeout for stalled connection
                poll_interval = 0.25  # Wake often to check send_task.done() so we emit final within LiveKit's 2s
                grace_sec = getattr(
                    self.config, "final_commit_grace_sec", 0.12
                )  # After audio ends, wait for committed_transcript before forcing final
                last_message_time = time.time()

                try:
                    logger.debug("ElevenLabs STT: Starting to receive WebSocket messages")

                    while True:
                        try:
                            # Short wait so we wake and can react when send_task completes (user stopped speaking)
                            msg = await asyncio.wait_for(ws.receive(), timeout=poll_interval)
                            last_message_time = time.time()

                            # Break on close/error
                            if msg.type in (aiohttp.WSMsgType.CLOSE, aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                                logger.info("ElevenLabs STT: WebSocket closed")
                                break

                            # Process message
                            message_count += 1
                            if message_count == 1:
                                logger.info(
                                    "ElevenLabs STT: Received first WebSocket message",
                                    extra={"msg_type": str(msg.type), "provider": self.get_provider_name()},
                                )

                            if msg.type == aiohttp.WSMsgType.TEXT:
                                try:
                                    data = json.loads(msg.data)
                                except json.JSONDecodeError as e:
                                    logger.error(
                                        "ElevenLabs STT: Failed to parse JSON message",
                                        extra={
                                            "error": str(e),
                                            "raw_data": str(msg.data)[:200],
                                            "provider": self.get_provider_name(),
                                        },
                                    )
                                    continue
                                message_type = data.get("message_type") or data.get("type")
                                # ALWAYS log first few messages with full content for debugging
                                if message_count <= 5:
                                    logger.info(
                                        "ElevenLabs STT: Received WebSocket message #%d: type=%s, keys=%s, data=%s",
                                        message_count,
                                        message_type,
                                        list(data.keys()),
                                        str(data)[:500],  # First 500 chars of data
                                        extra={"provider": self.get_provider_name()},
                                    )

                                # Successful transcript events
                                if message_type in (
                                    "partial_transcript",
                                    "committed_transcript",
                                    "committed_transcript_with_timestamps",
                                ):
                                    result = self._parse_streaming_response(data, time.time() - start_time)
                                    # Track last partial text for final emission if needed
                                    if not result.is_final and result.text:
                                        last_partial_text = result.text
                                    elif result.is_final:
                                        received_final_transcript = True
                                        # If server sent empty committed_transcript, emit final from last partial so LiveKit gets input
                                        if not (result.text or "").strip() and last_partial_text:
                                            logger.info(
                                                "ElevenLabs STT committed (empty), using last partial as final: %s",
                                                last_partial_text[:80],
                                                extra={"provider": self.get_provider_name()},
                                            )
                                            result = STTResult(
                                                text=last_partial_text,
                                                confidence=0.85,
                                                language=getattr(result, "language", "en") or "en",
                                                processing_time=result.processing_time,
                                                provider=self.get_provider_name(),
                                                is_partial=False,
                                                is_final=True,
                                            )
                                        last_partial_text = ""
                                        logger.info(
                                            "ElevenLabs STT committed transcript: %s",
                                            result.text[:100] if result.text else "(empty)",
                                            extra={
                                                "provider": self.get_provider_name(),
                                                "confidence": result.confidence,
                                                "language": result.language,
                                            },
                                        )
                                    else:
                                        logger.debug(
                                            "ElevenLabs STT partial transcript: %s",
                                            result.text[:50] if result.text else "(empty)",
                                            extra={"provider": self.get_provider_name()},
                                        )
                                    yield result
                                    # In VAD mode the server will emit committed transcripts continuously;
                                    # we keep listening until the client stops sending audio and closes.

                                    # If send task completed and we got a final transcript, we can close
                                    if send_task.done() and result.is_final:
                                        logger.debug(
                                            "ElevenLabs STT: Received final transcript after audio stream ended",
                                            extra={"provider": self.get_provider_name()},
                                        )
                                        # Close WebSocket to exit loop cleanly
                                        await ws.close()
                                        break
                                    continue

                                # Session started / informational events
                                if message_type == "session_started":
                                    logger.debug(
                                        "ElevenLabs realtime STT session started",
                                        extra={"provider": self.get_provider_name(), "config": data.get("config")},
                                    )
                                    continue

                                # Error events (per ElevenLabs Realtime API: scribeError, scribeAuthError,
                                # scribeQuotaExceededError, scribeThrottledError, scribeRateLimitedError, etc.)
                                if message_type and "error" in message_type.lower():
                                    error_msg = data.get("message", str(data))
                                    logger.error(
                                        "ElevenLabs realtime STT error",
                                        extra={
                                            "message_type": message_type,
                                            "error": error_msg,
                                            "provider": self.get_provider_name(),
                                        },
                                    )
                                    # Map specific error types to appropriate exceptions (retriable vs not)
                                    if message_type in (
                                        "scribeAuthError",
                                        "scribeUnacceptedTermsError",
                                    ):
                                        raise ProviderUnavailableError(
                                            f"ElevenLabs STT auth/terms: {error_msg}",
                                            provider=self.get_provider_name(),
                                            details={"event": data},
                                        )
                                    if message_type in (
                                        "scribeQuotaExceededError",
                                        "scribeThrottledError",
                                        "scribeRateLimitedError",
                                        "scribeQueueOverflowError",
                                        "scribeResourceExhaustedError",
                                    ):
                                        raise RateLimitError(
                                            f"ElevenLabs STT rate/quota: {error_msg}",
                                            provider=self.get_provider_name(),
                                            details={"event": data},
                                        )
                                    if message_type == "scribeSessionTimeLimitExceededError":
                                        raise STTTimeoutError(
                                            f"ElevenLabs STT session timeout: {error_msg}",
                                            provider=self.get_provider_name(),
                                            details={"event": data},
                                        )
                                    if message_type in (
                                        "scribeInputError",
                                        "scribeChunkSizeExceededError",
                                    ):
                                        raise AudioFormatError(
                                            f"ElevenLabs STT input/chunk: {error_msg}",
                                            provider=self.get_provider_name(),
                                            details={"event": data},
                                        )
                                    if message_type == "scribeInsufficientAudioActivityError":
                                        raise STTTimeoutError(
                                            f"ElevenLabs STT: insufficient audio (no speech detected): {error_msg}",
                                            provider=self.get_provider_name(),
                                            details={"event": data},
                                        )
                                    # scribeError, scribeTranscriberError
                                    raise TranscriptionError(
                                        f"ElevenLabs realtime STT error: {message_type}: {error_msg}",
                                        provider=self.get_provider_name(),
                                        details={"event": data},
                                    )

                                # Unknown message types - ignore, but keep connection alive
                                logger.debug(
                                    "ElevenLabs realtime STT unknown message",
                                    extra={"message_type": message_type, "event": data},
                                )

                            elif msg.type == aiohttp.WSMsgType.ERROR:
                                error = ws.exception()
                                logger.error(
                                    "ElevenLabs WebSocket error",
                                    extra={"error": str(error), "provider": self.get_provider_name()},
                                    exc_info=error,
                                )
                                raise TranscriptionError(f"WebSocket error: {error}", provider=self.get_provider_name())
                            elif msg.type == aiohttp.WSMsgType.CLOSE:
                                # WebSocket closed - if we have pending partial text and no final transcript, emit it as final
                                if last_partial_text and not received_final_transcript:
                                    logger.info(
                                        "ElevenLabs WebSocket closed with pending partial transcript, emitting as final: %s",
                                        last_partial_text[:100],
                                        extra={"provider": self.get_provider_name()},
                                    )
                                    yield STTResult(
                                        text=last_partial_text,
                                        confidence=0.8,
                                        language="en",
                                        processing_time=time.time() - start_time,
                                        provider=self.get_provider_name(),
                                        is_partial=False,
                                        is_final=True,
                                    )
                                elif received_final_transcript:
                                    logger.debug(
                                        "ElevenLabs WebSocket closed after receiving final transcript",
                                        extra={"provider": self.get_provider_name()},
                                    )
                                break

                            # Check if send task completed - if so, wait inline then emit partial as final if needed
                            if send_task.done() and not send_task_completed:
                                send_task_completed = True
                                # Wait inline (not background task) with timeout so we can yield
                                logger.debug(
                                    "ElevenLabs STT: Audio stream ended, waiting for final transcript (%.2fs)",
                                    grace_sec,
                                    extra={"provider": self.get_provider_name()},
                                )
                                wait_start = time.time()
                                final_transcript_received = False

                                while (time.time() - wait_start) < grace_sec and not received_final_transcript:
                                    try:
                                        msg = await asyncio.wait_for(ws.receive(), timeout=0.1)
                                        message_count += 1

                                        if msg.type == aiohttp.WSMsgType.TEXT:
                                            try:
                                                data = json.loads(msg.data)
                                            except json.JSONDecodeError:
                                                continue

                                            message_type = data.get("message_type") or data.get("type")

                                            if message_type in (
                                                "committed_transcript",
                                                "committed_transcript_with_timestamps",
                                            ):
                                                received_final_transcript = True
                                                final_transcript_received = True
                                                result = self._parse_streaming_response(data, time.time() - start_time)
                                                last_partial_text = ""
                                                logger.info(
                                                    "ElevenLabs STT final: %s",
                                                    result.text[:100] if result.text else "(empty)",
                                                    extra={"provider": self.get_provider_name()},
                                                )
                                                yield result
                                                break

                                            elif message_type == "partial_transcript":
                                                result = self._parse_streaming_response(data, time.time() - start_time)
                                                if result.text:
                                                    last_partial_text = result.text
                                                yield result

                                        elif msg.type in (
                                            aiohttp.WSMsgType.CLOSE,
                                            aiohttp.WSMsgType.CLOSED,
                                            aiohttp.WSMsgType.ERROR,
                                        ):
                                            logger.debug("WebSocket closed during wait")
                                            break

                                    except asyncio.TimeoutError:
                                        continue  # Keep waiting

                                # If timeout expired and we still have partial text, emit it as final
                                if (
                                    last_partial_text
                                    and not final_transcript_received
                                    and not received_final_transcript
                                ):
                                    logger.info(
                                        "ElevenLabs STT: Forcing final transcript from partial: %s",
                                        last_partial_text[:100],
                                        extra={"provider": self.get_provider_name()},
                                    )
                                    yield STTResult(
                                        text=last_partial_text,
                                        confidence=0.8,
                                        language="en",
                                        processing_time=time.time() - start_time,
                                        provider=self.get_provider_name(),
                                        is_partial=False,
                                        is_final=True,
                                    )
                                    received_final_transcript = True
                                    last_partial_text = ""

                                # Now close the WebSocket
                                if not ws.closed:
                                    await ws.close()
                                break  # Exit main receive loop

                        except asyncio.TimeoutError:
                            elapsed = time.time() - last_message_time

                            # If send task is done (user stopped speaking), give ElevenLabs grace_sec then emit final
                            if send_task.done() and last_partial_text and not received_final_transcript:
                                if send_task_done_at is None:
                                    send_task_done_at = time.time()
                                if (time.time() - send_task_done_at) >= grace_sec:
                                    logger.info(
                                        "ElevenLabs STT: Audio ended, forcing final from partial (after %.1fs grace)",
                                        grace_sec,
                                        extra={"provider": self.get_provider_name()},
                                    )
                                    yield STTResult(
                                        text=last_partial_text,
                                        confidence=0.75,
                                        language="en",
                                        processing_time=time.time() - start_time,
                                        provider=self.get_provider_name(),
                                        is_partial=False,
                                        is_final=True,
                                    )
                                    received_final_transcript = True
                                    if not ws.closed:
                                        await ws.close()
                                    break
                                # else: keep polling until grace_sec has passed

                            # Log only occasionally to avoid spam (every 30s, not every 10s)
                            if elapsed > 15.0 and int(elapsed) % 30 < 1:
                                logger.warning(
                                    "ElevenLabs STT: No message for %.1fs (no transcript from server yet)",
                                    elapsed,
                                    extra={"provider": self.get_provider_name()},
                                )

                            # Close if totally stalled (no message for 60s)
                            if elapsed > receive_timeout * 2:
                                logger.error("ElevenLabs STT: Connection stalled, closing")
                                if not ws.closed:
                                    await ws.close()
                                break
                finally:
                    # Cleanup send task
                    if not send_task.done():
                        send_task.cancel()
                        try:
                            await send_task
                        except asyncio.CancelledError:
                            pass

        except aiohttp.ClientError as e:
            raise TranscriptionError(f"Streaming connection failed: {e}", provider=self.get_provider_name())
        finally:
            if self._active_streaming_lock is not None:
                async with self._active_streaming_lock:
                    self._active_streaming_count = max(0, self._active_streaming_count - 1)

    async def _send_audio(
        self,
        ws,
        audio_stream: AsyncIterator[bytes],
        sample_rate: int,
    ) -> None:
        """
        Send audio chunks over WebSocket.

        ElevenLabs Realtime STT expects JSON messages with:
        - message_type: "input_audio_chunk"
        - audio_base_64: base64-encoded audio bytes
        - sample_rate: provided for clarity / troubleshooting

        We rely on server-side VAD (`commit_strategy=vad`) for committing transcripts.
        """
        try:
            # To ensure the last segment is flushed, we mark the last chunk as commit=True.
            # We do this with a 1-chunk lookahead so we don't need to buffer the full stream.
            buffered: Optional[bytes] = None
            chunks_sent = 0
            chunks_received = 0

            logger.info(
                "ElevenLabs STT: Starting to consume audio stream", extra={"provider": self.get_provider_name()}
            )

            async for chunk in audio_stream:
                chunks_received += 1
                if chunks_received <= 3:
                    logger.debug(
                        "ElevenLabs STT: Received audio chunk #%d from stream (size=%d bytes)",
                        chunks_received,
                        len(chunk) if chunk else 0,
                        extra={"provider": self.get_provider_name()},
                    )
                if ws.closed:
                    logger.debug("WebSocket closed, stopping audio send")
                    return

                # Validate chunk
                if not chunk or len(chunk) == 0:
                    logger.debug("Skipping empty audio chunk")
                    continue

                # Send previous buffered chunk (first chunk is sent when second arrives, or at flush)
                if buffered is not None:
                    await self._send_input_audio_chunk(
                        ws=ws,
                        audio_bytes=buffered,
                        sample_rate=sample_rate,
                        commit=False,
                    )
                    chunks_sent += 1
                    if chunks_sent <= 3 or chunks_sent % 50 == 0:
                        logger.debug(
                            "ElevenLabs STT: Sent audio chunk #%d (size=%d bytes)",
                            chunks_sent,
                            len(buffered),
                            extra={"provider": self.get_provider_name()},
                        )

                buffered = chunk
                # Small delay to prevent overwhelming the server
                await asyncio.sleep(0.01)

            # Flush last buffered chunk, if any
            if buffered is not None and not ws.closed:
                await self._send_input_audio_chunk(
                    ws=ws,
                    audio_bytes=buffered,
                    sample_rate=sample_rate,
                    commit=True,
                )
                chunks_sent += 1
                logger.info(
                    "ElevenLabs STT: Sent final audio chunk with commit=True (total_chunks=%d, chunks_received=%d)",
                    chunks_sent,
                    chunks_received,
                    extra={"provider": self.get_provider_name()},
                )
                # Give ElevenLabs time to process and send committed transcript
                await asyncio.sleep(0.5)
            elif chunks_received > 0:
                logger.info(
                    "ElevenLabs STT: Stream ended with no flush (chunks_received=%d, chunks_sent=%d)",
                    chunks_received,
                    chunks_sent,
                    extra={"provider": self.get_provider_name()},
                )
        except asyncio.CancelledError:
            # Task was cancelled, this is expected
            logger.debug("Audio send task cancelled")
        except Exception as e:
            logger.error(
                "Error sending audio chunks to ElevenLabs",
                extra={"error": str(e), "chunks_sent": chunks_sent},
                exc_info=True,
            )
            raise

    async def _send_input_audio_chunk(
        self,
        ws,
        audio_bytes: bytes,
        sample_rate: int,
        commit: bool,
        previous_text: Optional[str] = None,
    ) -> None:
        """Send a single ElevenLabs `input_audio_chunk` message."""
        payload: Dict[str, Any] = {
            "message_type": "input_audio_chunk",
            "audio_base_64": base64.b64encode(audio_bytes).decode("ascii"),
            "sample_rate": sample_rate,
            "commit": commit,
        }
        if previous_text:
            payload["previous_text"] = previous_text

        await ws.send_json(payload)

    def _parse_response(self, data: Dict[str, Any], processing_time: float) -> STTResult:
        """Parse batch API response. Defensive against missing or unexpected fields."""
        if not isinstance(data, dict):
            data = {}
        text = data.get("text") or ""
        if not isinstance(text, str):
            text = str(text) if text is not None else ""
        # ElevenLabs batch API returns language_probability (0-1), not confidence.
        # Per docs: https://elevenlabs.io/docs/api-reference/speech-to-text/convert
        confidence = data.get("confidence") or data.get("language_probability", 0.9)
        try:
            confidence = max(0.0, min(1.0, float(confidence)))
        except (TypeError, ValueError):
            confidence = 0.9
        language = data.get("language_code") or "en"
        if not isinstance(language, str):
            language = "en"
        words = data.get("words")
        segments = data.get("segments")

        return STTResult(
            text=text,
            confidence=confidence,
            language=language,
            processing_time=processing_time,
            provider=self.get_provider_name(),
            is_partial=False,
            is_final=True,
            words=words,
            segments=segments,
            metadata={
                "model_id": self.config.model_id,
                "raw_response": data,
            },
        )

    def _parse_streaming_response(
        self,
        data: Dict[str, Any],
        processing_time: float,
    ) -> STTResult:
        """Parse streaming response. Defensive against missing or unexpected fields."""
        if not isinstance(data, dict):
            data = {}
        text = data.get("text") or ""
        if not isinstance(text, str):
            text = str(text) if text is not None else ""
        message_type = data.get("message_type") or data.get("type")
        is_final = message_type in ("committed_transcript", "committed_transcript_with_timestamps")
        confidence = data.get("confidence", 0.8 if not is_final else 0.9)
        try:
            confidence = max(0.0, min(1.0, float(confidence)))
        except (TypeError, ValueError):
            confidence = 0.9 if is_final else 0.8
        language = data.get("language_code") or "en"
        if not isinstance(language, str):
            language = "en"

        return STTResult(
            text=text,
            confidence=confidence,
            language=language,
            processing_time=processing_time,
            provider=self.get_provider_name(),
            is_partial=not is_final,
            is_final=is_final,
            words=data.get("words"),
            metadata={
                "streaming": True,
                "message_type": message_type,
                "raw_response": data,
            },
        )

    @staticmethod
    def _to_elevenlabs_audio_format(sample_rate: int) -> str:
        """
        Map sample rate to ElevenLabs `audio_format` query parameter.

        Supported formats per ElevenLabs docs: pcm_8000, pcm_16000, pcm_22050, pcm_24000, pcm_44100, pcm_48000.
        """
        mapping = {
            8000: "pcm_8000",
            16000: "pcm_16000",
            22050: "pcm_22050",
            24000: "pcm_24000",
            44100: "pcm_44100",
            48000: "pcm_48000",
        }
        return mapping.get(sample_rate, "pcm_16000")

    def _pcm_to_wav(self, pcm_data: bytes, sample_rate: int) -> bytes:
        """
        Convert raw PCM to WAV format.

        Args:
            pcm_data: Raw 16-bit PCM audio
            sample_rate: Sample rate in Hz

        Returns:
            WAV file bytes
        """
        # WAV header parameters
        num_channels = 1
        bits_per_sample = 16
        byte_rate = sample_rate * num_channels * bits_per_sample // 8
        block_align = num_channels * bits_per_sample // 8
        data_size = len(pcm_data)

        # Create WAV header
        wav_buffer = io.BytesIO()

        # RIFF header
        wav_buffer.write(b"RIFF")
        wav_buffer.write(struct.pack("<I", 36 + data_size))  # File size - 8
        wav_buffer.write(b"WAVE")

        # fmt chunk
        wav_buffer.write(b"fmt ")
        wav_buffer.write(struct.pack("<I", 16))  # Chunk size
        wav_buffer.write(struct.pack("<H", 1))  # Audio format (PCM)
        wav_buffer.write(struct.pack("<H", num_channels))
        wav_buffer.write(struct.pack("<I", sample_rate))
        wav_buffer.write(struct.pack("<I", byte_rate))
        wav_buffer.write(struct.pack("<H", block_align))
        wav_buffer.write(struct.pack("<H", bits_per_sample))

        # data chunk
        wav_buffer.write(b"data")
        wav_buffer.write(struct.pack("<I", data_size))
        wav_buffer.write(pcm_data)

        return wav_buffer.getvalue()

    async def health_check(self) -> Dict[str, Any]:
        """Perform health check."""
        base_health = await super().health_check()

        if self.is_available() and self._http_session:
            try:
                async with self._http_session.get(
                    f"{self.BASE_URL}/user", headers={"xi-api-key": (self.config.api_key or "").strip()}
                ) as response:
                    base_health["api_reachable"] = response.status == 200
                    if response.status == 200:
                        data = await response.json()
                        base_health["subscription"] = data.get("subscription", {})
            except Exception as e:
                base_health["api_reachable"] = False
                base_health["error"] = str(e)

        return base_health

    def get_model_info(self) -> Dict[str, Any]:
        """Get model information."""
        info = super().get_model_info()
        info.update(
            {
                "model_id": self.config.model_id,
                "streaming_model_id": self.config.streaming_model_id,
                "api_base_url": self.BASE_URL,
                "has_api_key": bool(self.config.api_key),
            }
        )
        return info
