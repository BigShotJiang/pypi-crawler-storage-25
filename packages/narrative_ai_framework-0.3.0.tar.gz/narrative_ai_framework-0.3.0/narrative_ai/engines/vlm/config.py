import os
from dataclasses import dataclass, field
from typing import Optional, Callable
from pathlib import Path

# Robust .env loading
try:
    from dotenv import load_dotenv

    found_env = False
    # Check project root relative to this file
    _current = Path(__file__).resolve().parent
    for _ in range(5):
        _env = _current / ".env"
        if _env.exists():
            load_dotenv(_env)
            found_env = True
            break
        _current = _current.parent
except ImportError:
    pass


@dataclass
class IntegrationConfig:
    """Security integration settings. Defaults OFF for zero functional impact."""

    enable_rate_limiting: bool = False
    enable_audit_logging: bool = False
    enable_input_validation: bool = False
    enable_error_handling: bool = False
    user_tier_callback: Optional[Callable] = field(default=None, repr=False)


@dataclass
class VLMConfig:
    """Configuration for the VLM Engine."""

    # Security integration
    integration: IntegrationConfig = field(default_factory=IntegrationConfig)

    # General
    enabled: bool = True
    provider: str = "ollama"  # ollama, ollama_cloud, openai, google

    # Local Ollama
    ollama_host: str = field(default_factory=lambda: os.getenv("OLLAMA_HOST", "http://localhost:11434"))
    ollama_model: str = field(default_factory=lambda: os.getenv("OLLAMA_MODEL", "qwen2-vl:2b"))
    ollama_timeout: int = 30

    # Ollama Cloud (supporting Qwen-3VL via OpenAI-compatible endpoints)
    ollama_cloud_base_url: str = "https://ollama.com"
    ollama_cloud_api_key_env: str = "OLLAMA_CLOUD_API_KEY"
    ollama_cloud_model: str = "qwen3-vl:235b-cloud"
    ollama_cloud_max_tokens: int = 300
    ollama_cloud_timeout: int = 300  # Default 5 minutes for large cloud models

    # OpenAI
    openai_api_key_env: str = "OPENAI_API_KEY"
    openai_model: str = "gpt-4-vision-preview"
    openai_max_tokens: int = 300

    # Google
    google_api_key_env: str = "GOOGLE_API_KEY"
    google_model: str = "gemini-2.0-flash"

    def __post_init__(self):
        # Ensure provider is lowercase
        if self.provider:
            self.provider = self.provider.lower()
