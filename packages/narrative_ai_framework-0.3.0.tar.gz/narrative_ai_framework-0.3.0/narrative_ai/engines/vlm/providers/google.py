"""
Google Gemini VLM Provider.
"""

import os
import asyncio
import logging
import requests
from typing import Optional, Tuple, Union
from pathlib import Path
from PIL import Image

from ..types import CaptionResult, ProcessingError
from ..base import VLMProvider
from ..utils import image_to_base64

logger = logging.getLogger(__name__)


class GoogleProvider(VLMProvider):
    """
    Provider for Google Gemini Vision API.
    """

    @property
    def name(self) -> str:
        return "google"

    async def generate_caption(
        self,
        image: Union[str, Path, bytes, Image.Image],
        prompt: str,
    ) -> Tuple[Optional[CaptionResult], Optional[ProcessingError]]:
        api_key = os.environ.get(self.config.google_api_key_env)
        if not api_key:
            return None, ProcessingError(
                component="vlm_engine",
                error_type="ConfigError",
                message=f"API key not found in env var: {self.config.google_api_key_env}",
                recoverable=True,
            )

        model = self.config.google_model
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"

        try:
            image_b64 = image_to_base64(image)

            payload = {
                "contents": [
                    {
                        "parts": [
                            {"text": prompt},
                            {
                                "inline_data": {
                                    "mime_type": "image/png",
                                    "data": image_b64,
                                },
                            },
                        ],
                    }
                ],
            }

            # Retry logic for 429 errors
            max_retries = 3
            base_delay = 5

            for attempt in range(max_retries):
                try:
                    response = await asyncio.to_thread(
                        requests.post,
                        url,
                        json=payload,
                        timeout=60,
                    )

                    if response.status_code == 429:
                        if attempt < max_retries - 1:
                            delay = base_delay * (2**attempt)
                            logger.warning(f"Gemini API rate limit hit. Retrying in {delay}s...")
                            await asyncio.sleep(delay)
                            continue

                    if response.status_code != 200:
                        return None, ProcessingError(
                            component="vlm_engine",
                            error_type="APIError",
                            message=f"Google API error {response.status_code}: {response.text}",
                            recoverable=True,
                        )

                    data = response.json()
                    caption = data["candidates"][0]["content"]["parts"][0]["text"]

                    result = CaptionResult(
                        caption=caption.strip(),
                        caption_model=model,
                    )
                    return result, None

                except requests.exceptions.RequestException as e:
                    if attempt < max_retries - 1:
                        delay = base_delay * (2**attempt)
                        logger.warning(f"Gemini connection error: {e}. Retrying in {delay}s...")
                        await asyncio.sleep(delay)
                        continue
                    raise

            return None, ProcessingError(
                component="vlm_engine",
                error_type="MaxRetriesExceeded",
                message="Max retries exceeded for Google API",
                recoverable=True,
            )

        except Exception as e:
            logger.error(f"Google processing failed: {e}")
            return None, ProcessingError(
                component="vlm_engine", error_type=type(e).__name__, message=str(e), recoverable=True
            )
