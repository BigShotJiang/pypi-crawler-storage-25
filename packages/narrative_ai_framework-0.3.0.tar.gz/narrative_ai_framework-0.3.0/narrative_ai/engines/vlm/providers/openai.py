"""
OpenAI VLM Provider.
"""

import asyncio
import os
import logging
import requests
from typing import Optional, Tuple, Union
from pathlib import Path
from PIL import Image

from ..types import CaptionResult, ProcessingError
from ..base import VLMProvider
from ..utils import image_to_base64

logger = logging.getLogger(__name__)


class OpenAIProvider(VLMProvider):
    """
    Provider for OpenAI Vision API (GPT-4 Vision).
    """

    @property
    def name(self) -> str:
        return "openai"

    async def generate_caption(
        self,
        image: Union[str, Path, bytes, Image.Image],
        prompt: str,
    ) -> Tuple[Optional[CaptionResult], Optional[ProcessingError]]:
        api_key = os.environ.get(self.config.openai_api_key_env)
        if not api_key:
            return None, ProcessingError(
                component="vlm_engine",
                error_type="ConfigError",
                message=f"API key not found in env var: {self.config.openai_api_key_env}",
                recoverable=True,
            )

        model = self.config.openai_model

        try:
            image_b64 = image_to_base64(image)

            url = "https://api.openai.com/v1/chat/completions"
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }

            payload = {
                "model": model,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_b64}"}},
                        ],
                    }
                ],
                "max_tokens": self.config.openai_max_tokens,
            }

            response = await asyncio.to_thread(
                requests.post,
                url,
                headers=headers,
                json=payload,
                timeout=60,
            )

            if response.status_code != 200:
                return None, ProcessingError(
                    component="vlm_engine",
                    error_type="APIError",
                    message=f"OpenAI API error {response.status_code}: {response.text}",
                    recoverable=True,
                )

            data = response.json()
            caption = data["choices"][0]["message"]["content"]

            result = CaptionResult(
                caption=caption.strip(),
                caption_model=model,
            )
            return result, None

        except Exception as e:
            logger.error(f"OpenAI processing failed: {e}")
            return None, ProcessingError(
                component="vlm_engine", error_type=type(e).__name__, message=str(e), recoverable=True
            )
