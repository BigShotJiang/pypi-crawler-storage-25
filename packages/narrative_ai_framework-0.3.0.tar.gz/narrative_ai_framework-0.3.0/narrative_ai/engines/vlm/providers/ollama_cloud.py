"""
Ollama Cloud VLM Provider (Qwen-3VL).
"""

import asyncio
import os
import logging
from threading import Lock
import requests
from typing import Optional, Tuple, Union
from pathlib import Path
from PIL import Image

from ..types import CaptionResult, ProcessingError
from ..base import VLMProvider
from ..utils import image_to_base64

logger = logging.getLogger(__name__)


class OllamaCloudProvider(VLMProvider):
    """
    Provider for Ollama Cloud services (e.g. Qwen-3VL).
    Uses standard requests with session reuse for better performance.
    """

    # Shared session for connection reuse
    _session: Optional[requests.Session] = None
    _session_lock: Lock = Lock()

    @classmethod
    def _get_session(cls) -> requests.Session:
        """Get or create a shared HTTP session."""
        with cls._session_lock:
            if cls._session is None:
                cls._session = requests.Session()
            return cls._session

    @property
    def name(self) -> str:
        return "ollama_cloud"

    async def generate_caption(
        self,
        image: Union[str, Path, bytes, Image.Image],
        prompt: str,
    ) -> Tuple[Optional[CaptionResult], Optional[ProcessingError]]:
        api_key = os.environ.get(self.config.ollama_cloud_api_key_env)
        if not api_key:
            return None, ProcessingError(
                component="vlm_engine",
                error_type="ConfigError",
                message=f"API key not found in env var: {self.config.ollama_cloud_api_key_env}",
                recoverable=True,
            )

        host = self.config.ollama_cloud_base_url.rstrip("/")
        url = f"{host}/api/chat"
        model = self.config.ollama_cloud_model

        try:
            image_b64 = image_to_base64(image)

            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            }

            payload = {
                "model": model,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt,
                        "images": [image_b64],
                    }
                ],
                "stream": False,
            }

            # Use shared session for connection reuse
            session = self._get_session()
            timeout = getattr(self.config, "ollama_cloud_timeout", 300)

            def _post():
                with self._session_lock:
                    return session.post(url, headers=headers, json=payload, timeout=timeout)

            response = await asyncio.to_thread(_post)

            if response.status_code != 200:
                return None, ProcessingError(
                    component="vlm_engine",
                    error_type="APIError",
                    message=f"Ollama Cloud API error {response.status_code}: {response.text}",
                    recoverable=True,
                )

            data = response.json()
            caption = data.get("message", {}).get("content", "")

            result = CaptionResult(
                caption=caption.strip(),
                caption_model=model,
            )
            return result, None

        except Exception as e:
            logger.error(f"Ollama Cloud processing failed: {e}")
            return None, ProcessingError(
                component="vlm_engine", error_type=type(e).__name__, message=str(e), recoverable=True
            )
