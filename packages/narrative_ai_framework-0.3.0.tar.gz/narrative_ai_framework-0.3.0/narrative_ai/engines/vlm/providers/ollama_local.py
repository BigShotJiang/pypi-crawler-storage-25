"""
Ollama Local VLM Provider.
"""

import asyncio
import logging
from typing import Optional, Tuple, Union
from pathlib import Path
from PIL import Image

try:
    import ollama

    OLLAMA_AVAILABLE = True
except ImportError:
    OLLAMA_AVAILABLE = False

from ..types import CaptionResult, ProcessingError
from ..base import VLMProvider
from ..utils import image_to_base64

logger = logging.getLogger(__name__)


class OllamaLocalProvider(VLMProvider):
    """
    Provider for local Ollama instance.
    Uses the official ollama python library.
    """

    @property
    def name(self) -> str:
        return "ollama_local"

    async def generate_caption(
        self,
        image: Union[str, Path, bytes, Image.Image],
        prompt: str,
    ) -> Tuple[Optional[CaptionResult], Optional[ProcessingError]]:
        if not OLLAMA_AVAILABLE:
            error = ProcessingError(
                component="vlm_engine",
                error_type="ImportError",
                message="ollama library not installed",
                recoverable=True,
            )
            return None, error

        model = self.config.ollama_model
        host = self.config.ollama_host

        # Configure client
        client = ollama.Client(host=host)

        try:
            image_b64 = image_to_base64(image)

            response = await asyncio.to_thread(
                client.chat,
                model=model,
                messages=[
                    {
                        "role": "user",
                        "content": prompt,
                        "images": [image_b64],
                    }
                ],
            )

            caption = response.get("message", {}).get("content", "")

            result = CaptionResult(
                caption=caption.strip(),
                caption_model=model,
            )
            return result, None

        except Exception as e:
            if "not found" in str(e).lower():
                return None, ProcessingError(
                    component="vlm_engine",
                    error_type="ModelNotFound",
                    message=f"Ollama model '{model}' not found. Run: ollama pull {model}",
                    recoverable=True,
                )

            logger.error(f"Ollama local processing failed: {e}")
            return None, ProcessingError(
                component="vlm_engine", error_type=type(e).__name__, message=str(e), recoverable=True
            )
