import asyncio
from typing import Union, Optional, List, Any
from pathlib import Path
from narrative_ai.engines.vlm.processor import VLMProcessor
from narrative_ai.engines.vlm.types import CaptionResult

_default_processor: Optional[VLMProcessor] = None

def _get_processor() -> VLMProcessor:
    global _default_processor
    if _default_processor is None:
        _default_processor = VLMProcessor()
    return _default_processor

def set_api_key(api_key: str, provider: str = "openai"):
    """
    Dynamically set the API key for a VLM provider.
    
    Args:
        api_key: The secret API key string.
        provider: Provider name (e.g., 'openai', 'gemini', 'anthropic').
    """
    import os
    env_map = {
        "openai": "OPENAI_API_KEY",
        "gemini": "GEMINI_API_KEY",
        "anthropic": "ANTHROPIC_API_KEY"
    }
    env_var = env_map.get(provider.lower())
    if env_var:
        os.environ[env_var] = api_key

async def caption(
    image: Union[str, Path, bytes],
    prompt: str = "Describe this image in detail.",
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> CaptionResult:
    """Generate a caption/description for an image."""
    processor = _get_processor()
    result, error = await processor.process(
        image, 
        prompt=prompt,
        user_id=user_id,
        tenant_id=tenant_id,
        correlation_id=correlation_id,
        **kwargs
    )
    if error:
        raise error
    return result

async def ask(
    image: Union[str, Path, bytes],
    question: str,
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> str:
    """Ask a specific question about an image."""
    result = await caption(
        image, 
        prompt=question,
        user_id=user_id,
        tenant_id=tenant_id,
        correlation_id=correlation_id,
        **kwargs
    )
    return result.caption if hasattr(result, "caption") else str(result)

class VLMClient:
    """
    A session-based client for the Vision-Language Model (VLM) engine.
    Stores common parameters like user_id and tenant_id.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        api_key: Optional[str] = None,
        provider: str = "openai",
        correlation_id: Optional[str] = None,
    ):
        """Initialize the VLM client with default context."""
        if api_key:
            set_api_key(api_key, provider)

        self.defaults = {
            "user_id": user_id,
            "tenant_id": tenant_id,
            "correlation_id": correlation_id,
        }

    async def caption(self, image: Union[str, Path, bytes], **kwargs) -> CaptionResult:
        """Generate caption using client defaults."""
        final_args = {**self.defaults, "image": image, **kwargs}
        return await caption(**final_args)

    async def ask(self, image: Union[str, Path, bytes], question: str, **kwargs) -> str:
        """Ask question using client defaults."""
        final_args = {**self.defaults, "image": image, "question": question, **kwargs}
        return await ask(**final_args)
