"""
VLM Engine Types.
Shared data models for the VLM engine.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional, Dict, Any


@dataclass
class ProcessingError:
    """Represents an error that occurred during processing."""

    component: str
    error_type: str
    message: str
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat() + "Z")
    recoverable: bool = True
    details: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class CaptionResult:
    """Image captioning results."""

    caption: str
    caption_confidence: Optional[float] = None
    caption_model: str = "qwen2-vl:2b"
    caption_model_version: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary, excluding None values."""
        return {k: v for k, v in asdict(self).items() if v is not None}
