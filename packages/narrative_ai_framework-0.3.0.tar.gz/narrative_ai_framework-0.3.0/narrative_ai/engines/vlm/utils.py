"""
VLM Engine Utilities.
"""

import base64
from io import BytesIO
from pathlib import Path
from typing import Union
from PIL import Image


def image_to_base64(image: Union[str, Path, bytes, Image.Image], max_size: int = 1024) -> str:
    """
    Convert an image to a base64 encoded string with optimization.

    Args:
        image: Image input (path, bytes, or PIL Image)
        max_size: Maximum dimension (width or height) to resize to.

    Returns:
        Base64 string of the image (without data URI prefix)
    """
    if isinstance(image, (str, Path)):
        img = Image.open(str(image))
    elif isinstance(image, bytes):
        img = Image.open(BytesIO(image))
    else:
        # Use a copy to avoid side-effects on the original image
        img = image.copy() if hasattr(image, "copy") else image

    # Ensure RGB for JPEG
    if img.mode != "RGB":
        img = img.convert("RGB")

    # Resize if too large
    w, h = img.size
    if max(w, h) > max_size:
        scale = max_size / max(w, h)
        img = img.resize((int(w * scale), int(h * scale)), Image.Resampling.LANCZOS)

    buffer = BytesIO()
    # Save as JPEG with 85% quality to balance speed and quality
    img.save(buffer, format="JPEG", quality=85, optimize=True)
    return base64.b64encode(buffer.getvalue()).decode("utf-8")
