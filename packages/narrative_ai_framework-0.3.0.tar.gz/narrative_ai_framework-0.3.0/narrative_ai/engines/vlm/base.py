"""
Abstract Base Class for VLM Providers.
"""

from abc import ABC, abstractmethod
from typing import Optional, Tuple, Union
from pathlib import Path
from PIL import Image

# Import types from the input processor for compatibility
# We might want to move these shared types to a common shared/ location later
from .types import CaptionResult, ProcessingError
from .config import VLMConfig


class VLMProvider(ABC):
    """
    Abstract base class for Vision Language Model providers.
    All providers must implement this interface.
    """

    def __init__(self, config: VLMConfig):
        self.config = config

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the unique name of this provider."""
        pass

    @abstractmethod
    async def generate_caption(
        self,
        image: Union[str, Path, bytes, Image.Image],
        prompt: str,
    ) -> Tuple[Optional[CaptionResult], Optional[ProcessingError]]:
        """
        Generate a caption for the provided image.

        Args:
            image: The image input (path, bytes, or PIL Image)
            prompt: The text prompt to guide generation

        Returns:
            Tuple of (CaptionResult, ProcessingError).
            If successful, ProcessingError is None.
            If failed, CaptionResult is None.
        """
        pass
