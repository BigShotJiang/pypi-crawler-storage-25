"""
VLM Provider Factory.
"""

from typing import Dict, Type
from .config import VLMConfig
from .base import VLMProvider
from .providers.ollama_local import OllamaLocalProvider
from .providers.ollama_cloud import OllamaCloudProvider
from .providers.openai import OpenAIProvider
from .providers.google import GoogleProvider


class VLMProviderFactory:
    """
    Factory for creating VLM providers based on configuration.
    """

    _providers: Dict[str, Type[VLMProvider]] = {
        "ollama": OllamaLocalProvider,
        "ollama_local": OllamaLocalProvider,
        "ollama_cloud": OllamaCloudProvider,
        "openai": OpenAIProvider,
        "google": GoogleProvider,
    }

    @classmethod
    def create(cls, config: VLMConfig) -> VLMProvider:
        """
        Create a VLM provider instance based on the configuration.

        Args:
            config: VLM configuration object

        Returns:
            An instance of a VLMProvider subclass

        Raises:
            ValueError: If the provider in config is unknown
        """
        provider_name = config.provider.lower()
        provider_cls = cls._providers.get(provider_name)

        if not provider_cls:
            # Fallback to ollama local if not found is usually safe,
            # or raise specific error. Here we raise error for clarity.
            raise ValueError(f"Unknown VLM provider: {provider_name}. Available: {list(cls._providers.keys())}")

        return provider_cls(config)
