"""
VLM Processor.
Main entry point for VLM operations.
"""

import asyncio
import logging
from typing import Optional, Tuple, Union, Any
from pathlib import Path
from PIL import Image

# Import types for compatibility with existing code
from .types import CaptionResult, ProcessingError

from .config import VLMConfig
from .factory import VLMProviderFactory

logger = logging.getLogger(__name__)

# Optional security integration - engines run exactly as today when unavailable
try:
    from narrative_ai.security.engine_integration import (
        check_rate_limit_for_engine,
        log_audit_for_engine,
    )
    from narrative_ai.security.rate_limiting import EndpointCosts, RateLimiter
    from narrative_ai.security.audit_trail import AuditLogger, ActionType
    from narrative_ai.security.input_validation import validate_text
    from narrative_ai.security.error_handling import SecureErrorHandler

    _SECURITY_AVAILABLE = True
except ImportError:
    RateLimiter = None
    AuditLogger = None
    ActionType = None
    validate_text = None
    SecureErrorHandler = None
    _SECURITY_AVAILABLE = False

if not _SECURITY_AVAILABLE:
    logging.getLogger(__name__).warning("Security layer not available - VLM running without security integration")


class VLMProcessor:
    """
    Vision Language Model processor for image captioning.
    Delegates to specific providers based on configuration.
    """

    # Default prompt for image captioning
    DEFAULT_CAPTION_PROMPT = (
        "Describe this image in detail. Focus on the main subjects, "
        "any text visible, colors, composition, and context. "
        "Be factual and precise."
    )

    def __init__(self, config=None):
        """
        Initialize the VLM processor.

        Args:
            config: Optional configuration. Can be:
                   - VLMConfig instance
                   - IngestionConfig instance (from input_processor)
                   - Dict
                   - None (defaults will be used)
        """
        self.config = self._adapt_config(config)
        self._provider = VLMProviderFactory.create(self.config)
        self._rate_limiter = None
        self._audit_logger = None
        self._error_handler = None
        self._security_initialized = False

    def _adapt_config(self, config) -> VLMConfig:
        """
        Adapt various config inputs to VLMConfig.
        """
        if isinstance(config, VLMConfig):
            return config

        # If it's the main IngestionConfig or CaptioningConfig
        # We need to extract values. This is a bit of glue code
        # to ensure backward compatibility with input_processor config

        vlm_config = VLMConfig()

        if config is None:
            return vlm_config

        # Check if it looks like IngestionConfig
        if hasattr(config, "image_processing") and hasattr(config.image_processing, "captioning"):
            cap_config = config.image_processing.captioning
        elif hasattr(config, "captioning"):  # Maybe ImageProcessingConfig
            cap_config = config.captioning
        else:
            cap_config = config  # Assume it's CaptioningConfig or dict

        # Extract values
        if isinstance(cap_config, dict):
            # Handle dict configuration
            vlm_config.enabled = cap_config.get("enabled", True)
            vlm_config.provider = cap_config.get("provider", "ollama")

            # Ollama
            ollama = cap_config.get("ollama", {})
            vlm_config.ollama_model = ollama.get("model", vlm_config.ollama_model)
            vlm_config.ollama_host = ollama.get("host", vlm_config.ollama_host)

            ollama_cloud = cap_config.get("ollama_cloud", {})
            vlm_config.ollama_cloud_model = ollama_cloud.get("model", vlm_config.ollama_cloud_model)
            vlm_config.ollama_cloud_base_url = ollama_cloud.get("base_url", vlm_config.ollama_cloud_base_url)
            vlm_config.ollama_cloud_timeout = ollama_cloud.get("timeout", vlm_config.ollama_cloud_timeout)

            # API (OpenAI)
            api = cap_config.get("api", {})
            vlm_config.openai_model = api.get("model", vlm_config.openai_model)
            vlm_config.openai_max_tokens = api.get("max_tokens", vlm_config.openai_max_tokens)

            # Google
            google = cap_config.get("google", {})
            vlm_config.google_model = google.get("model", vlm_config.google_model)

        else:
            # Handle object configuration (dataclass)
            if hasattr(cap_config, "enabled"):
                vlm_config.enabled = cap_config.enabled
            if hasattr(cap_config, "provider"):
                vlm_config.provider = cap_config.provider

            # Copy attributes if they exist
            # Ollama
            if hasattr(cap_config, "ollama_model"):
                vlm_config.ollama_model = cap_config.ollama_model
            if hasattr(cap_config, "ollama_host"):
                vlm_config.ollama_host = cap_config.ollama_host

            # Ollama Cloud (New attributes might not stand on old config object,
            # so we check safely. The dataclass in config.py wasn't updated yet!
            # But the user asked for config driven. We'll rely on it being there
            # or defaults here.)
            if hasattr(cap_config, "ollama_cloud_model"):
                vlm_config.ollama_cloud_model = cap_config.ollama_cloud_model
            if hasattr(cap_config, "ollama_cloud_base_url"):
                vlm_config.ollama_cloud_base_url = cap_config.ollama_cloud_base_url
            if hasattr(cap_config, "ollama_cloud_timeout"):
                vlm_config.ollama_cloud_timeout = cap_config.ollama_cloud_timeout

            # OpenAI
            if hasattr(cap_config, "api_model"):
                vlm_config.openai_model = cap_config.api_model
            if hasattr(cap_config, "api_max_tokens"):
                vlm_config.openai_max_tokens = cap_config.api_max_tokens

            # Google
            if hasattr(cap_config, "google_model"):
                vlm_config.google_model = cap_config.google_model

        return vlm_config

    def _ensure_security_initialized(self) -> None:
        """Lazy-init rate limiter and audit logger when security is enabled."""
        if not _SECURITY_AVAILABLE or self._security_initialized:
            return
        int_cfg = getattr(self.config, "integration", None)
        if int_cfg is None or not (
            getattr(int_cfg, "enable_rate_limiting", False)
            or getattr(int_cfg, "enable_audit_logging", False)
            or getattr(int_cfg, "enable_error_handling", False)
        ):
            self._security_initialized = True
            return
        try:
            import os

            is_production = os.getenv("ENV", "").lower() == "production"
            skip_rate_limit = not is_production and os.getenv("VOICE_DEV_SKIP_RATE_LIMIT", "").strip() == "1"
            if getattr(int_cfg, "enable_rate_limiting", False) and RateLimiter and not skip_rate_limit:
                self._rate_limiter = RateLimiter()
            if getattr(int_cfg, "enable_audit_logging", False) and AuditLogger:
                audit_db_url = os.getenv("AUDIT_DATABASE_URL") or os.getenv("DATABASE_URL")
                if audit_db_url:
                    self._audit_logger = AuditLogger(database_url=audit_db_url)
                else:
                    logger.warning("Audit logging enabled but AUDIT_DATABASE_URL/DATABASE_URL not set")
            if getattr(int_cfg, "enable_error_handling", False) and SecureErrorHandler:
                try:
                    self._error_handler = SecureErrorHandler()
                except Exception as e:
                    logger.warning("Secure error handler initialization failed: %s", e)
        except Exception as e:
            logger.warning("Security initialization failed: %s", e)
        self._security_initialized = True

    async def process(
        self,
        image: Union[str, Path, bytes, Image.Image],
        prompt: Optional[str] = None,
        user_id: Optional[Any] = None,
        tenant_id: Optional[Any] = None,
        correlation_id: Optional[str] = None,
    ) -> Tuple[Optional[CaptionResult], Optional[ProcessingError]]:
        """
        Generate a caption for an image.

        Args:
            image: Image to process - can be path, bytes, or PIL Image.
            prompt: Optional custom prompt. Uses default if not provided.
            user_id: Optional user ID for rate limiting and audit.
            tenant_id: Optional tenant ID for rate limiting and audit.
            correlation_id: Optional correlation ID for audit traceability.

        Returns:
            Tuple of (CaptionResult, error). One will be None.
        """
        if not self.config.enabled:
            return None, None

        caption_prompt = prompt or self.DEFAULT_CAPTION_PROMPT

        # Security: validate prompt, rate limit (when enabled)
        if _SECURITY_AVAILABLE:
            self._ensure_security_initialized()
            int_cfg = getattr(self.config, "integration", None)
            if int_cfg and getattr(int_cfg, "enable_input_validation", False) and validate_text:
                validate_text(caption_prompt, max_length=10000)
            if int_cfg and getattr(int_cfg, "enable_rate_limiting", False) and self._rate_limiter:
                check_rate_limit_for_engine(
                    self._rate_limiter,
                    user_id,
                    tenant_id,
                    EndpointCosts.VLM_INFERENCE,
                    "anon.engine.vlm",
                    user_tier_callback=getattr(int_cfg, "user_tier_callback", None),
                )

        try:
            result, error = await self._provider.generate_caption(image, caption_prompt)
        except Exception as e:
            int_cfg = getattr(self.config, "integration", None)
            if int_cfg and getattr(int_cfg, "enable_audit_logging", False) and self._audit_logger:
                log_audit_for_engine(
                    self._audit_logger,
                    user_id,
                    tenant_id,
                    ActionType.VLM_INFERENCE,
                    "vlm_caption",
                    "failure",
                    {"prompt_preview": caption_prompt[:100], "error": str(e), "type": type(e).__name__},
                    resource_id=None,
                    engine_namespace="anon.engine.vlm",
                    correlation_id=correlation_id,
                )
            if self._error_handler:
                try:
                    self._error_handler.handle_error(e, user_id, tenant_id, {"correlation_id": correlation_id})
                except Exception as handler_error:
                    logger.warning("Error handler failed: %s", handler_error)
            raise

        # Security: audit (when enabled)
        if _SECURITY_AVAILABLE:
            int_cfg = getattr(self.config, "integration", None)
            if int_cfg and getattr(int_cfg, "enable_audit_logging", False) and self._audit_logger:
                log_audit_for_engine(
                    self._audit_logger,
                    user_id,
                    tenant_id,
                    ActionType.VLM_INFERENCE,
                    "vlm_caption",
                    "success" if result is not None and error is None else "failure",
                    {"has_result": result is not None, "prompt_preview": caption_prompt[:100]},
                    resource_id=None,
                    engine_namespace="anon.engine.vlm",
                    correlation_id=correlation_id,
                )

        return result, error

    def process_sync(
        self,
        image: Union[str, Path, bytes, Image.Image],
        prompt: Optional[str] = None,
        user_id: Optional[Any] = None,
        tenant_id: Optional[Any] = None,
        correlation_id: Optional[str] = None,
    ) -> Tuple[Optional[CaptionResult], Optional[ProcessingError]]:
        """
        Synchronous compatibility wrapper around async process().
        """
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(
                self.process(
                    image=image,
                    prompt=prompt,
                    user_id=user_id,
                    tenant_id=tenant_id,
                    correlation_id=correlation_id,
                )
            )

        raise RuntimeError(
            "process_sync() cannot be called from an active event loop. Use `await process(...)` instead."
        )
