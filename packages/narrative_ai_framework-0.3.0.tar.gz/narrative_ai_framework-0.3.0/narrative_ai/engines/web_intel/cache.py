"""Caching helpers for web intelligence retrieval."""

from __future__ import annotations

import asyncio
import json
import os
import re
import threading
import time
from typing import Any, Optional


class WebIntelCache:
    """Two-level cache: in-process TTL (L1) + optional Redis (L2)."""

    _REDIS_PREFIX = "web_intel:search:"

    def __init__(self, ttl_seconds: int = 300) -> None:
        self.ttl_seconds = max(1, int(ttl_seconds))
        self._memory: dict[str, tuple[float, dict[str, Any]]] = {}
        self._memory_lock = threading.Lock()
        self._redis_client: Any | None = None
        self._redis_init_attempted = False
        self._redis_lock: asyncio.Lock | None = None

    @staticmethod
    def normalize_query(query: str) -> str:
        text = (query or "").strip().lower()
        text = re.sub(r"\s+", " ", text)
        return text

    def build_key(
        self,
        query: str,
        *,
        max_results: int,
        freshness: str | None,
    ) -> str:
        normalized = self.normalize_query(query)
        freshness_token = (freshness or "").strip().lower()
        return f"q={normalized}|k={int(max_results)}|f={freshness_token}"

    async def _ensure_redis(self) -> Any | None:
        if self._redis_init_attempted:
            return self._redis_client

        if self._redis_lock is None:
            self._redis_lock = asyncio.Lock()
        async with self._redis_lock:
            if self._redis_init_attempted:
                return self._redis_client
            self._redis_init_attempted = True

            redis_url = (os.getenv("REDIS_URL") or "").strip()
            if not redis_url:
                return None

            try:
                import redis.asyncio as redis_async

                client = redis_async.from_url(
                    redis_url,
                    decode_responses=True,
                    socket_connect_timeout=1,
                    socket_timeout=1,
                )
                await client.ping()
                self._redis_client = client
            except Exception:
                self._redis_client = None
        return self._redis_client

    def _l1_get(self, key: str) -> Optional[dict[str, Any]]:
        now = time.time()
        with self._memory_lock:
            row = self._memory.get(key)
            if row is None:
                return None
            expires_at, payload = row
            if expires_at <= now:
                self._memory.pop(key, None)
                return None
            return dict(payload)

    def _l1_set(self, key: str, payload: dict[str, Any], ttl_seconds: int) -> None:
        expires_at = time.time() + max(1, int(ttl_seconds))
        with self._memory_lock:
            self._memory[key] = (expires_at, dict(payload))

    async def get(self, key: str) -> Optional[dict[str, Any]]:
        payload = self._l1_get(key)
        if payload is not None:
            return payload

        redis_client = await self._ensure_redis()
        if redis_client is None:
            return None

        redis_key = f"{self._REDIS_PREFIX}{key}"
        try:
            raw = await redis_client.get(redis_key)
            if not raw:
                return None
            payload = json.loads(raw)
            if isinstance(payload, dict):
                self._l1_set(key, payload, self.ttl_seconds)
                return payload
            return None
        except Exception:
            return None

    async def set(
        self,
        key: str,
        payload: dict[str, Any],
        *,
        ttl_seconds: int | None = None,
    ) -> None:
        ttl = max(1, int(ttl_seconds or self.ttl_seconds))
        self._l1_set(key, payload, ttl)

        redis_client = await self._ensure_redis()
        if redis_client is None:
            return

        redis_key = f"{self._REDIS_PREFIX}{key}"
        try:
            await redis_client.setex(redis_key, ttl, json.dumps(payload))
        except Exception:
            return
