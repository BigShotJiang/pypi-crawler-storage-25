"""Data models for web intelligence search."""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Optional
from urllib.parse import urlparse


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def extract_domain(url: str) -> str:
    parsed = urlparse((url or "").strip())
    return (parsed.netloc or "").lower()


@dataclass(slots=True)
class WebSource:
    title: str
    url: str
    domain: str
    snippet: str
    published_at: Optional[str]
    retrieved_at: str
    score: float
    query: str

    @classmethod
    def create(
        cls,
        *,
        title: str,
        url: str,
        snippet: str,
        query: str,
        published_at: Optional[str] = None,
        score: float = 0.0,
    ) -> "WebSource":
        return cls(
            title=(title or "").strip(),
            url=(url or "").strip(),
            domain=extract_domain(url),
            snippet=(snippet or "").strip(),
            published_at=(published_at or None),
            retrieved_at=_utc_now_iso(),
            score=max(0.0, min(1.0, float(score or 0.0))),
            query=(query or "").strip(),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class WebSearchResponse:
    query: str
    sources: list[WebSource] = field(default_factory=list)
    formatted_context: str = ""
    provider: str = ""
    latency_ms: float = 0.0
    cache_hit: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "query": self.query,
            "sources": [source.to_dict() for source in self.sources],
            "formatted_context": self.formatted_context,
            "provider": self.provider,
            "latency_ms": self.latency_ms,
            "cache_hit": self.cache_hit,
        }
