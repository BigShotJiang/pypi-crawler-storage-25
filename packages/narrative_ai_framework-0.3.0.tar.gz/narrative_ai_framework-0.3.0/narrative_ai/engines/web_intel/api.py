"""
Web Intelligence API - SDK entry point for the Web Intelligence engine.
"""

from typing import Optional, Any
from .engine import WebIntelEngine
from .models import WebSearchResponse

_default_engine: Optional[WebIntelEngine] = None

def _get_engine() -> WebIntelEngine:
    global _default_engine
    if _default_engine is None:
        _default_engine = WebIntelEngine.from_providers_config()
    return _default_engine

def set_api_key(api_key: str, provider: str = "tavily"):
    """
    Dynamically set the API key for a Web Search provider.
    
    Args:
        api_key: The secret API key string.
        provider: Provider name (e.g., 'tavily', 'bing', 'google').
    """
    import os
    env_map = {
        "tavily": "TAVILY_API_KEY",
        "bing": "BING_SEARCH_API_KEY",
        "google": "GOOGLE_SEARCH_API_KEY"
    }
    env_var = env_map.get(provider.lower())
    if env_var:
        os.environ[env_var] = api_key

async def search(
    query: str,
    max_results: Optional[int] = None,
    freshness: Optional[str] = None,
    timeout_ms: Optional[int] = None,
    **kwargs
) -> WebSearchResponse:
    """Search the public web for recent information."""
    engine = _get_engine()
    return await engine.search(
        query=query,
        max_results=max_results,
        freshness=freshness,
        timeout_ms=timeout_ms,
        **kwargs
    )

class WebIntelClient:
    """
    A session-based client for the Web Intelligence engine.
    Stores common parameters like max_results and timeout.
    """

    def __init__(
        self,
        max_results: Optional[int] = None,
        timeout_ms: Optional[int] = None,
        freshness: Optional[str] = None,
        api_key: Optional[str] = None,
        provider: str = "tavily",
    ):
        """Initialize the Web Intel client with default context."""
        if api_key:
            set_api_key(api_key, provider)

        self.defaults = {
            "max_results": max_results,
            "timeout_ms": timeout_ms,
            "freshness": freshness,
        }

    async def search(self, query: str, **kwargs) -> WebSearchResponse:
        """Search the web using client defaults."""
        final_args = {**self.defaults, "query": query, **kwargs}
        return await search(**final_args)
