"""Web search provider implementations."""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Any, Optional

import httpx

from .models import WebSource

logger = logging.getLogger(__name__)


class WebSearchProvider(ABC):
    """Abstract provider contract for internet search."""

    name: str = "unknown"

    @abstractmethod
    async def search(
        self,
        query: str,
        *,
        max_results: int = 5,
        freshness: Optional[str] = None,
        timeout_ms: int = 3000,
    ) -> list[WebSource]:
        """Return normalized web sources for the query."""


class DuckDuckGoProvider(WebSearchProvider):
    """DuckDuckGo-based provider via duckduckgo-search package."""

    name = "duckduckgo"

    def __init__(self, *, region: str = "wt-wt") -> None:
        self._region = (region or "wt-wt").strip()

    def _search_sync(
        self,
        query: str,
        *,
        max_results: int,
        freshness: Optional[str],
        timeout_ms: int,
    ) -> list[dict[str, Any]]:
        try:
            from ddgs import DDGS  # type: ignore[import-not-found]
        except Exception:
            try:
                from duckduckgo_search import DDGS  # type: ignore[import-not-found]
            except Exception as exc:  # pragma: no cover - optional dependency
                raise RuntimeError("DuckDuckGo provider requires 'ddgs' (recommended) or 'duckduckgo-search'.") from exc

        timeout_sec = max(1.0, timeout_ms / 1000.0)
        with DDGS(timeout=timeout_sec) as ddgs:
            # Accept provider-specific freshness hints when available.
            kwargs: dict[str, Any] = {
                "region": self._region,
                "max_results": max(1, int(max_results)),
            }
            if freshness:
                kwargs["timelimit"] = freshness
            rows = list(ddgs.text(query, **kwargs))
        return rows

    async def search(
        self,
        query: str,
        *,
        max_results: int = 5,
        freshness: Optional[str] = None,
        timeout_ms: int = 3000,
    ) -> list[WebSource]:
        rows = await asyncio.to_thread(
            self._search_sync,
            query,
            max_results=max_results,
            freshness=freshness,
            timeout_ms=timeout_ms,
        )

        out: list[WebSource] = []
        for idx, row in enumerate(rows[: max(1, int(max_results))], start=1):
            title = str(row.get("title") or row.get("heading") or "").strip()
            url = str(row.get("href") or row.get("url") or "").strip()
            snippet = str(row.get("body") or row.get("snippet") or "").strip()
            published_at = str(row.get("date") or row.get("published_at") or "").strip() or None
            if not url or not title:
                continue
            score = max(0.0, 1.0 - ((idx - 1) * 0.08))
            out.append(
                WebSource.create(
                    title=title,
                    url=url,
                    snippet=snippet,
                    query=query,
                    published_at=published_at,
                    score=score,
                )
            )
        return out


class GoogleSearchProvider(WebSearchProvider):
    """Google Custom Search JSON API provider."""

    name = "google"
    _ENDPOINT = "https://www.googleapis.com/customsearch/v1"

    def __init__(self, *, api_key: str, cx: str) -> None:
        self._api_key = (api_key or "").strip()
        self._cx = (cx or "").strip()
        if not self._api_key or not self._cx:
            raise ValueError("Google search provider requires both api_key and cx")

    @staticmethod
    def _extract_published_at(item: dict[str, Any]) -> Optional[str]:
        pagemap = item.get("pagemap") or {}
        meta_tags = pagemap.get("metatags") or []
        if isinstance(meta_tags, list):
            for meta in meta_tags:
                if not isinstance(meta, dict):
                    continue
                for key in ("article:published_time", "og:updated_time", "date", "dc.date"):
                    value = meta.get(key)
                    if value:
                        return str(value)
        return None

    async def search(
        self,
        query: str,
        *,
        max_results: int = 5,
        freshness: Optional[str] = None,
        timeout_ms: int = 3000,
    ) -> list[WebSource]:
        del freshness  # Google CSE freshness requires paid filters; keep interface parity.

        params = {
            "key": self._api_key,
            "cx": self._cx,
            "q": query,
            "num": max(1, min(10, int(max_results))),
        }
        timeout = httpx.Timeout(timeout_ms / 1000.0)
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.get(self._ENDPOINT, params=params)
            response.raise_for_status()
            payload = response.json()

        items = payload.get("items") or []
        out: list[WebSource] = []
        for idx, item in enumerate(items[: max(1, int(max_results))], start=1):
            if not isinstance(item, dict):
                continue
            title = str(item.get("title") or "").strip()
            url = str(item.get("link") or "").strip()
            snippet = str(item.get("snippet") or "").strip()
            published_at = self._extract_published_at(item)
            if not title or not url:
                continue
            score = max(0.0, 1.0 - ((idx - 1) * 0.08))
            out.append(
                WebSource.create(
                    title=title,
                    url=url,
                    snippet=snippet,
                    query=query,
                    published_at=published_at,
                    score=score,
                )
            )
        return out
