"""Web Intelligence engine orchestrator."""

from __future__ import annotations

import asyncio
import ipaddress
import logging
import os
import re
import time
from dataclasses import asdict
from typing import Any, Optional
from urllib.parse import urlparse, urlunparse

from config import ProvidersConfig

from .cache import WebIntelCache
from .models import WebSearchResponse, WebSource
from .providers import DuckDuckGoProvider, GoogleSearchProvider, WebSearchProvider

logger = logging.getLogger(__name__)

_TAG_RE = re.compile(r"<[^>]+>")
_SPACE_RE = re.compile(r"\s+")
_SNIPPET_MAX_CHARS = 360


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return str(raw).strip().lower() in {"1", "true", "yes", "on"}


def _sanitize_snippet(text: str) -> str:
    cleaned = _TAG_RE.sub(" ", text or "")
    cleaned = _SPACE_RE.sub(" ", cleaned).strip()
    if len(cleaned) > _SNIPPET_MAX_CHARS:
        cleaned = cleaned[: _SNIPPET_MAX_CHARS - 3].rstrip() + "..."
    return cleaned


def _normalize_url(url: str) -> str:
    try:
        parsed = urlparse((url or "").strip())
    except Exception:
        return ""

    scheme = (parsed.scheme or "").lower()
    if scheme not in {"http", "https"}:
        return ""
    hostname = (parsed.hostname or "").lower()
    netloc = hostname
    if parsed.port:
        netloc = f"{hostname}:{parsed.port}"
    path = parsed.path or "/"
    normalized = parsed._replace(scheme=scheme, netloc=netloc, path=path, params="", query=parsed.query, fragment="")
    return urlunparse(normalized)


def _is_private_or_local_host(hostname: str) -> bool:
    host = (hostname or "").strip().lower()
    if not host:
        return True
    if host in {"localhost", "127.0.0.1", "::1"}:
        return True
    if host.endswith(".local") or host.endswith(".internal"):
        return True
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    return bool(ip.is_private or ip.is_loopback or ip.is_link_local)


class WebIntelEngine:
    """Search engine with provider fallback, safety filtering, and caching."""

    def __init__(
        self,
        *,
        providers: dict[str, WebSearchProvider],
        primary_provider: str,
        fallback_order: list[str],
        enabled: bool = True,
        mode: str = "auto",
        timeout_ms: int = 3000,
        max_results: int = 5,
        cache_ttl_seconds: int = 300,
        deny_domains: Optional[list[str]] = None,
    ) -> None:
        self._providers = providers
        self._primary_provider = primary_provider
        self._fallback_order = list(fallback_order)
        self._enabled = bool(enabled)
        self._mode = (mode or "auto").strip().lower()
        self._timeout_ms = max(200, int(timeout_ms))
        self._max_results = max(1, int(max_results))
        self._cache = WebIntelCache(ttl_seconds=cache_ttl_seconds)
        self._deny_domains = {d.strip().lower() for d in (deny_domains or []) if d.strip()}

    @classmethod
    def from_providers_config(cls, providers_config: ProvidersConfig | None = None) -> "WebIntelEngine":
        providers_config = providers_config or ProvidersConfig()
        raw = providers_config.to_dict().get("web", {}) or {}

        enabled = _env_bool("WEB_INTEL_ENABLED", bool(raw.get("enabled", True)))
        mode = (os.getenv("WEB_INTEL_MODE") or raw.get("mode") or "auto").strip().lower()
        timeout_ms = int(raw.get("timeout_ms", 3000))
        max_results = int(raw.get("max_results", 5))
        ttl_seconds = int(raw.get("freshness_ttl", 300))

        primary_provider = str(raw.get("primary_provider") or "duckduckgo").strip().lower()
        fallback_order = [
            str(p).strip().lower() for p in (raw.get("fallback_order") or [primary_provider]) if str(p).strip()
        ]

        providers: dict[str, WebSearchProvider] = {}

        ddg_cfg = raw.get("duckduckgo") or {}
        if ddg_cfg.get("enabled", True):
            providers["duckduckgo"] = DuckDuckGoProvider(region=str(ddg_cfg.get("region") or "wt-wt"))

        google_cfg = raw.get("google") or {}
        if google_cfg.get("enabled", False):
            key_env = str(google_cfg.get("api_key_env") or "GOOGLE_SEARCH_API_KEY")
            cx_env = str(google_cfg.get("cx_env") or "GOOGLE_SEARCH_CX")
            api_key = (os.getenv(key_env) or "").strip()
            cx = (os.getenv(cx_env) or "").strip()
            if api_key and cx:
                try:
                    providers["google"] = GoogleSearchProvider(api_key=api_key, cx=cx)
                except Exception as exc:
                    logger.warning("Google web provider disabled due to invalid configuration: %s", exc)

        if not providers:
            # Keep a default provider entry so runtime errors are explicit.
            providers["duckduckgo"] = DuckDuckGoProvider(region="wt-wt")

        deny_domains = list(raw.get("deny_domains") or []) + [
            "localhost",
        ]

        return cls(
            providers=providers,
            primary_provider=primary_provider if primary_provider in providers else next(iter(providers.keys())),
            fallback_order=[p for p in fallback_order if p in providers] or [next(iter(providers.keys()))],
            enabled=enabled,
            mode=mode,
            timeout_ms=timeout_ms,
            max_results=max_results,
            cache_ttl_seconds=ttl_seconds,
            deny_domains=deny_domains,
        )

    @property
    def enabled(self) -> bool:
        return self._enabled and self._mode != "off"

    @property
    def mode(self) -> str:
        return self._mode

    @property
    def timeout_ms(self) -> int:
        return self._timeout_ms

    @property
    def max_results(self) -> int:
        return self._max_results

    def _provider_order(self) -> list[str]:
        order: list[str] = []
        for name in [self._primary_provider, *self._fallback_order]:
            if name in self._providers and name not in order:
                order.append(name)
        for name in self._providers:
            if name not in order:
                order.append(name)
        return order

    def _is_allowed_url(self, url: str) -> bool:
        parsed = urlparse(url)
        host = (parsed.hostname or "").lower()
        if _is_private_or_local_host(host):
            return False
        if host in self._deny_domains:
            return False
        return True

    def _postprocess_sources(self, sources: list[WebSource], *, max_results: int) -> list[WebSource]:
        deduped: list[WebSource] = []
        seen_urls: set[str] = set()
        for src in sources:
            normalized_url = _normalize_url(src.url)
            if not normalized_url:
                continue
            if not self._is_allowed_url(normalized_url):
                continue
            if normalized_url in seen_urls:
                continue
            seen_urls.add(normalized_url)
            src.url = normalized_url
            src.snippet = _sanitize_snippet(src.snippet)
            if not src.snippet:
                src.snippet = src.title
            deduped.append(src)
            if len(deduped) >= max(1, int(max_results)):
                break
        return deduped

    @staticmethod
    def _format_context(sources: list[WebSource]) -> str:
        if not sources:
            return ""
        lines: list[str] = []
        for idx, source in enumerate(sources, start=1):
            date_part = f" | published={source.published_at}" if source.published_at else ""
            lines.append(f"[Web {idx}] {source.title} ({source.url}){date_part}\nSnippet: {source.snippet}")
        return "\n".join(lines)

    async def search(
        self,
        query: str,
        *,
        max_results: Optional[int] = None,
        freshness: Optional[str] = None,
        timeout_ms: Optional[int] = None,
    ) -> WebSearchResponse:
        clean_query = (query or "").strip()
        if not clean_query:
            return WebSearchResponse(query=clean_query)
        if not self.enabled:
            return WebSearchResponse(query=clean_query)

        resolved_max_results = max(1, int(max_results or self._max_results))
        resolved_timeout_ms = max(200, int(timeout_ms or self._timeout_ms))
        cache_key = self._cache.build_key(clean_query, max_results=resolved_max_results, freshness=freshness)
        cached = await self._cache.get(cache_key)
        if cached:
            sources_data = cached.get("sources") or []
            sources = []
            for row in sources_data:
                if isinstance(row, dict):
                    try:
                        sources.append(WebSource(**row))
                    except Exception:
                        continue
            return WebSearchResponse(
                query=clean_query,
                sources=sources,
                formatted_context=str(cached.get("formatted_context") or self._format_context(sources)),
                provider=str(cached.get("provider") or ""),
                latency_ms=float(cached.get("latency_ms") or 0.0),
                cache_hit=True,
            )

        start = time.perf_counter()
        for provider_name in self._provider_order():
            provider = self._providers.get(provider_name)
            if provider is None:
                continue

            try:
                timeout_sec = resolved_timeout_ms / 1000.0
                provider_sources = await asyncio.wait_for(
                    provider.search(
                        clean_query,
                        max_results=resolved_max_results,
                        freshness=freshness,
                        timeout_ms=resolved_timeout_ms,
                    ),
                    timeout=timeout_sec,
                )
                sources = self._postprocess_sources(provider_sources, max_results=resolved_max_results)
                if not sources:
                    continue
                context = self._format_context(sources)
                latency_ms = (time.perf_counter() - start) * 1000.0
                response = WebSearchResponse(
                    query=clean_query,
                    sources=sources,
                    formatted_context=context,
                    provider=provider_name,
                    latency_ms=latency_ms,
                    cache_hit=False,
                )
                await self._cache.set(
                    cache_key,
                    {
                        "sources": [asdict(s) for s in sources],
                        "formatted_context": context,
                        "provider": provider_name,
                        "latency_ms": latency_ms,
                    },
                )
                return response
            except Exception as exc:
                logger.warning("Web provider %s failed: %s", provider_name, exc)
                continue

        return WebSearchResponse(query=clean_query, latency_ms=(time.perf_counter() - start) * 1000.0)

    def get_tool_descriptor(self) -> dict[str, Any]:
        """Return MCP-ready tool metadata for external agent discovery."""
        return {
            "name": "web_search",
            "description": "Search the public web for recent information and return ranked citations.",
            "input_schema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Natural language search query."},
                    "max_results": {"type": "integer", "minimum": 1, "maximum": 10, "default": self._max_results},
                    "freshness": {
                        "type": "string",
                        "description": "Optional time filter hint (e.g. day/week/month).",
                    },
                },
                "required": ["query"],
            },
            "transport": {
                "type": "rest",
                "endpoint": "/api/web-intel/search",
                "method": "POST",
            },
        }
