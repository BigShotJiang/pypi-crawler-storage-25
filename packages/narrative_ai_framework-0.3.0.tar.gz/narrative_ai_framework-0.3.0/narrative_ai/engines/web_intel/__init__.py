from .engine import WebIntelEngine
from .models import WebSearchResponse, WebSource
from .providers import DuckDuckGoProvider, GoogleSearchProvider, WebSearchProvider
from .api import search, WebIntelClient

__all__ = [
    "WebIntelEngine",
    "WebSearchResponse",
    "WebSource",
    "WebSearchProvider",
    "DuckDuckGoProvider",
    "GoogleSearchProvider",
    "search",
    "WebIntelClient",
]

__version__ = "0.1.0"
