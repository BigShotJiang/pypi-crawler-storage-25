"""
Hybrid Search Module for the Memory Framework.

Combines dense (semantic) and sparse (keyword) search
for optimal Arabic/English retrieval.

NOTE: This module is Pure Async for production performance.
"""

import logging
import time
from typing import List, Optional, Dict, Any

from .config import get_config
from .types import RetrievalResult
from .cache import get_query_cache
from .providers.base import EmbeddingProvider
from .strategies import DomainStrategy, get_strategy
from ...infrastructure.vector.base_vector_store import RagVectorStore

logger = logging.getLogger(__name__)


class HybridSearch:
    """
    Hybrid search engine combining dense and sparse retrieval.

    Uses a single embedding call (BGE-M3) to generate both vector types,
    then performs a fused search via the vector store.

    All methods are async for production performance.
    """

    def __init__(
        self,
        vector_store: RagVectorStore,
        embedding_provider: EmbeddingProvider,
        reranker_provider: Optional[Any] = None,
        strategy: Optional[DomainStrategy] = None,
    ):
        """
        Initialize hybrid search.

        Args:
            vector_store: Vector store implementation.
            embedding_provider: Embedding model provider.
            reranker_provider: Optional reranker for secondary scoring.
            strategy: Domain strategy for scoring and formatting.
        """
        self.vector_store = vector_store
        self.embedding_provider = embedding_provider
        self.reranker_provider = reranker_provider
        self.config = get_config()

        # Load strategy
        self.strategy = strategy or get_strategy(self.config.strategy)
        self.query_cache = get_query_cache()

        logger.info(f"HybridSearch initialized with strategy: {self.strategy.name}")

    async def search(
        self,
        query: str,
        top_k: Optional[int] = None,
        filters: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None,
    ) -> List[RetrievalResult]:
        """
        Perform hybrid search (async).

        Args:
            query: Natural language query.
            top_k: Number of results to retrieve.
            filters: Optional metadata filters.
            user_id: User identifier for per-user embedding cache isolation.

        Returns:
            List of RetrievalResult objects, ranked by relevance.
        """
        start_time = time.time()

        top_k = top_k or self.config.retrieval.top_k

        # 1. Embed the query (with user-scoped caching)
        embedding_start = time.time()

        # Check cache first (scoped by user_id to prevent cross-user hits)
        embedding = self.query_cache.get(query, user_id=user_id)
        if embedding is None:
            # Cache miss - generate embedding asynchronously
            embedding = await self.embedding_provider.embed_query(query)
            self.query_cache.set(query, embedding, user_id=user_id)
            logger.debug(f"Query embedding generated (cache MISS) in {(time.time() - embedding_start) * 1000:.1f}ms")
        else:
            logger.debug(
                f"Query embedding retrieved from cache (HIT) in {(time.time() - embedding_start) * 1000:.1f}ms"
            )

        # 2. Perform hybrid search (vector store is still sync - Qdrant is fast enough)
        search_start = time.time()
        vector_results = await self.vector_store.search(
            dense_vector=embedding.dense_vector,
            sparse_vector=embedding.sparse_vector,
            top_k=top_k,
            filters=filters,
            hybrid_alpha=self.config.retrieval.hybrid_alpha,
        )
        search_time = time.time() - search_start
        logger.debug(f"Vector search completed in {search_time * 1000:.1f}ms, found {len(vector_results)} results")

        # 3. Convert to RetrievalResult and apply strategy scoring
        current_time = time.time()
        results = []

        for vr in vector_results:
            # Extract parent context from extra payload (Small-to-Big)
            extra = vr.payload.extra or {}
            parent_text = extra.get("parent_text")
            parent_window_id = extra.get("parent_window_id")

            result = RetrievalResult(
                chunk_id=vr.payload.chunk_id,
                text=vr.payload.text,
                score=vr.score,
                doc_id=vr.payload.doc_id,
                block_id=vr.payload.block_id,
                modality=vr.payload.modality,
                timestamp=vr.payload.timestamp,
                page=vr.payload.page,
                media_ref=vr.payload.media_ref,
                parent_text=parent_text,
                parent_window_id=parent_window_id,
                extra=extra,
            )

            # Apply strategy-based scoring
            result.score = self.strategy.calculate_final_score(result, current_time)
            results.append(result)

        # 4. Filter by threshold
        threshold = self.config.retrieval.similarity_threshold
        pre_threshold_results = list(results)
        results = [r for r in pre_threshold_results if r.score >= threshold]
        if not results and pre_threshold_results:
            # Fallback: keep top raw matches when threshold is too strict for short/specific queries.
            # This avoids empty recalls for questions like "what was my breakfast today?"
            max_score = max(r.score for r in pre_threshold_results)
            logger.info(
                "Hybrid search threshold fallback activated (threshold=%.3f, max_score=%.3f, candidates=%d)",
                threshold,
                max_score,
                len(pre_threshold_results),
            )
            results = pre_threshold_results

        # 5. Reranking (optional)
        if self.reranker_provider and results:
            rerank_start = time.time()
            texts = [r.text for r in results]

            # Async rerank
            scores = await self.reranker_provider.rerank(query, texts)
            rerank_time = time.time() - rerank_start

            # Update scores with rerank scores
            for i, score in enumerate(scores):
                results[i].score = score

            # Re-sort after reranking
            results.sort(key=lambda r: r.score, reverse=True)
            logger.debug(f"Reranking completed in {rerank_time * 1000:.1f}ms")
        else:
            # Sort by strategy score if no reranker
            results.sort(key=lambda r: r.score, reverse=True)

        # 6. Limit to final_k
        final_k = self.config.retrieval.final_k
        results = results[:final_k]

        total_time = time.time() - start_time
        logger.info(f"Hybrid search completed in {total_time * 1000:.1f}ms, returning {len(results)} results")

        return results

    async def search_with_context(
        self,
        query: str,
        top_k: Optional[int] = None,
        filters: Optional[Dict[str, Any]] = None,
    ):
        """
        Search and format results into rich context (async).

        Args:
            query: Search query string.
            top_k: Number of results.
            filters: Optional metadata filters.

        Returns:
            RichContext object ready for LLM consumption.
        """
        results = await self.search(query, top_k, filters)
        return self.strategy.format_context(results, query)
