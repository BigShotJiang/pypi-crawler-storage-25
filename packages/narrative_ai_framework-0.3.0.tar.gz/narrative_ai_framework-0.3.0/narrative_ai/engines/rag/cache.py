"""
Query Cache Module for the Memory Framework.

Provides LRU caching for embeddings to avoid redundant API calls.
RAG context cache TTL is driven by CACHE_TTL_SEARCH (default 3600s) when set.
"""

import logging
import os
import json
import re
import unicodedata
from typing import Optional, Dict, Any, List
from hashlib import sha256
from datetime import datetime, timedelta
from dataclasses import dataclass
from .providers.base import EmbeddingOutput

logger = logging.getLogger(__name__)


def normalize_query(query: str) -> str:
    """Normalize a query string for consistent cache key generation.

    Applies:
    1. Unicode NFKC normalization (handles Arabic variants, fullwidth chars)
    2. Lowercasing
    3. Whitespace collapse (multiple spaces/tabs → single space)
    4. Trailing punctuation stripping (Latin and Arabic)
    """
    if not query:
        return ""
    # 1. Unicode normalize
    text = unicodedata.normalize("NFKC", query)
    # 2. Lowercase and strip
    text = text.lower().strip()
    # 3. Collapse whitespace
    text = re.sub(r"\s+", " ", text)
    # 4. Strip trailing punctuation (Latin + Arabic)
    text = text.rstrip("?!.،؟؛")
    return text


@dataclass
class CacheEntry:
    """Cache entry with TTL support."""

    embedding: EmbeddingOutput
    timestamp: datetime
    hit_count: int = 0


class QueryCache:
    """
    LRU cache for query embeddings.

    Features:
    - SHA-256 based key generation
    - TTL support (default 1 hour)
    - Hit/miss statistics
    """

    def __init__(self, max_size: int = 1000, ttl_seconds: int = 3600):
        """
        Initialize the cache.

        Args:
            max_size: Maximum number of cached embeddings.
            ttl_seconds: Time-to-live for cache entries in seconds.
        """
        self.max_size = max_size
        self.ttl = timedelta(seconds=ttl_seconds)
        self._cache: Dict[str, CacheEntry] = {}
        self._hits = 0
        self._misses = 0

    def _get_key(self, query: str, user_id: Optional[str] = None) -> str:
        """Generate cache key from query text, scoped by user_id if provided.

        Key strategy:
          - With user_id:    hash(user_id + ":" + normalized_query)  → per-user isolation
          - Without user_id: hash(normalized_query)                  → shared (backward compat)
        """
        norm = normalize_query(query)
        raw = f"{user_id}:{norm}" if user_id else norm
        return sha256(raw.encode("utf-8")).hexdigest()

    def get(self, query: str, user_id: Optional[str] = None) -> Optional[EmbeddingOutput]:
        """
        Retrieve cached embedding for a query.

        Args:
            query: Query text.
            user_id: Optional user identifier for per-user cache isolation.

        Returns:
            EmbeddingOutput if cached and not expired, None otherwise.
        """
        key = self._get_key(query, user_id)
        entry = self._cache.get(key)

        if entry is None:
            self._misses += 1
            return None

        # Check TTL
        if datetime.now() - entry.timestamp > self.ttl:
            del self._cache[key]
            self._misses += 1
            logger.debug(f"Cache entry expired for query: {query[:50]}...")
            return None

        # Cache hit
        entry.hit_count += 1
        self._hits += 1
        logger.debug(f"Cache HIT for query: {query[:50]}... (hits: {entry.hit_count})")
        return entry.embedding

    def set(self, query: str, embedding: EmbeddingOutput, user_id: Optional[str] = None) -> None:
        """
        Store embedding in cache.

        Args:
            query: Query text.
            embedding: Embedding to cache.
            user_id: Optional user identifier for per-user cache isolation.
        """
        key = self._get_key(query, user_id)

        # LRU eviction if cache is full
        if len(self._cache) >= self.max_size and key not in self._cache:
            # Remove oldest entry
            oldest_key = min(self._cache.keys(), key=lambda k: self._cache[k].timestamp)
            del self._cache[oldest_key]
            logger.debug("Cache full, evicted oldest entry")

        self._cache[key] = CacheEntry(embedding=embedding, timestamp=datetime.now(), hit_count=0)
        logger.debug(f"Cached embedding for query: {query[:50]}...")

    def clear(self) -> None:
        """Clear all cache entries."""
        self._cache.clear()
        self._hits = 0
        self._misses = 0
        logger.info("Cache cleared")

    def get_stats(self) -> Dict[str, any]:
        """Get cache statistics."""
        total_requests = self._hits + self._misses
        hit_rate = self._hits / total_requests if total_requests > 0 else 0

        return {
            "size": len(self._cache),
            "max_size": self.max_size,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": hit_rate,
            "total_requests": total_requests,
        }

    def warmup(self, queries: list[str], embed_func) -> None:
        """
        Pre-populate cache with common queries.

        Args:
            queries: List of common queries to pre-embed.
            embed_func: Function to generate embeddings (should accept str, return EmbeddingOutput).
        """
        logger.info(f"Warming up cache with {len(queries)} queries...")
        for query in queries:
            if self.get(query) is None:
                embedding = embed_func(query)
                self.set(query, embedding)
        logger.info(f"Cache warmup complete. Size: {len(self._cache)}")


@dataclass
class RagContextCacheEntry:
    """Cached RAG context payload.

    Optional results (list of serialized RetrievalResult dicts) and strategy_used
    allow the recall API path to return full RichContext on cache hit.
    """

    formatted_text: str
    source_chunk_ids: List[str]
    context_fingerprint: str
    user_id: Optional[str]
    timestamp: datetime
    hit_count: int = 0
    # Full recall path: for /api/rag/recall to return RichContext with source_chunks
    results: Optional[List[Dict[str, Any]]] = None
    strategy_used: str = "cached"


class RagContextCache:
    """LRU+TTL cache for query -> RAG context, scoped by user."""

    def __init__(self, max_size: int = 500, ttl_seconds: int = 3600):
        self.max_size = max_size
        self.ttl = timedelta(seconds=ttl_seconds)
        self._cache: Dict[str, RagContextCacheEntry] = {}
        self._hits = 0
        self._misses = 0

    @staticmethod
    def _normalize_filters(filters: Optional[Dict[str, Any]]) -> str:
        if not filters:
            return ""
        return json.dumps(filters, sort_keys=True, default=str)

    def _get_key(
        self,
        query: str,
        user_id: Optional[str],
        *,
        top_k: int = 5,
        filters: Optional[Dict[str, Any]] = None,
    ) -> str:
        normalized_query = normalize_query(query)
        user_scope = user_id or "anonymous"
        normalized_filters = self._normalize_filters(filters)
        raw = f"{user_scope}:{top_k}:{normalized_filters}:{normalized_query}"
        return sha256(raw.encode("utf-8")).hexdigest()

    def get(
        self,
        query: str,
        user_id: Optional[str],
        *,
        top_k: int = 5,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Optional[RagContextCacheEntry]:
        key = self._get_key(query, user_id, top_k=top_k, filters=filters)
        entry = self._cache.get(key)
        if entry is None:
            self._misses += 1
            return None
        if not (entry.formatted_text or "").strip():
            # Never keep/return empty contexts; they go stale after new diary writes.
            del self._cache[key]
            self._misses += 1
            return None
        if datetime.now() - entry.timestamp > self.ttl:
            del self._cache[key]
            self._misses += 1
            return None
        entry.hit_count += 1
        self._hits += 1
        return entry

    def set(
        self,
        query: str,
        user_id: Optional[str],
        *,
        top_k: int = 5,
        filters: Optional[Dict[str, Any]] = None,
        formatted_text: str,
        source_chunk_ids: List[str],
        context_fingerprint: str,
        results: Optional[List[Dict[str, Any]]] = None,
        strategy_used: str = "cached",
    ) -> None:
        key = self._get_key(query, user_id, top_k=top_k, filters=filters)
        if len(self._cache) >= self.max_size and key not in self._cache:
            oldest_key = min(self._cache.keys(), key=lambda k: self._cache[k].timestamp)
            del self._cache[oldest_key]
        self._cache[key] = RagContextCacheEntry(
            formatted_text=formatted_text,
            source_chunk_ids=source_chunk_ids,
            context_fingerprint=context_fingerprint,
            user_id=user_id,
            timestamp=datetime.now(),
            hit_count=0,
            results=results,
            strategy_used=strategy_used,
        )

    def invalidate_user(self, user_id: str) -> int:
        """Remove all cached RAG contexts for a user."""
        if not user_id:
            return 0
        keys_to_delete = [k for k, v in self._cache.items() if v.user_id == user_id]
        for key in keys_to_delete:
            del self._cache[key]
        return len(keys_to_delete)

    def clear(self) -> None:
        self._cache.clear()
        self._hits = 0
        self._misses = 0

    def get_stats(self) -> Dict[str, Any]:
        total_requests = self._hits + self._misses
        hit_rate = self._hits / total_requests if total_requests > 0 else 0
        return {
            "size": len(self._cache),
            "max_size": self.max_size,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": hit_rate,
            "total_requests": total_requests,
        }


@dataclass
class RagResponseCacheEntry:
    """Cached final assistant answer for a RAG-backed query."""

    text: str
    user_id: str
    timestamp: datetime
    hit_count: int = 0


class RagResponseCache:
    """LRU+TTL cache for user-scoped RAG answers."""

    def __init__(self, max_size: int = 1000, ttl_seconds: int = 86400):
        self.max_size = max_size
        self.ttl = timedelta(seconds=ttl_seconds)
        self._cache: Dict[str, RagResponseCacheEntry] = {}
        self._hits = 0
        self._misses = 0

    def _get_key(
        self,
        query: str,
        user_id: str,
        *,
        intent: str,
        context_fingerprint: str,
    ) -> str:
        normalized_query = normalize_query(query)
        raw = f"{user_id}:{intent}:{context_fingerprint}:{normalized_query}"
        return sha256(raw.encode("utf-8")).hexdigest()

    def get(
        self,
        query: str,
        user_id: str,
        *,
        intent: str,
        context_fingerprint: str,
    ) -> Optional[RagResponseCacheEntry]:
        key = self._get_key(query, user_id, intent=intent, context_fingerprint=context_fingerprint)
        entry = self._cache.get(key)
        if entry is None:
            self._misses += 1
            return None
        if datetime.now() - entry.timestamp > self.ttl:
            del self._cache[key]
            self._misses += 1
            return None
        entry.hit_count += 1
        self._hits += 1
        return entry

    def set(
        self,
        query: str,
        user_id: str,
        *,
        intent: str,
        context_fingerprint: str,
        text: str,
    ) -> None:
        key = self._get_key(query, user_id, intent=intent, context_fingerprint=context_fingerprint)
        if len(self._cache) >= self.max_size and key not in self._cache:
            oldest_key = min(self._cache.keys(), key=lambda k: self._cache[k].timestamp)
            del self._cache[oldest_key]
        self._cache[key] = RagResponseCacheEntry(
            text=text,
            user_id=user_id,
            timestamp=datetime.now(),
            hit_count=0,
        )

    def invalidate_user(self, user_id: str) -> int:
        """Remove all cached RAG answers for a user."""
        if not user_id:
            return 0
        keys_to_delete = [k for k, v in self._cache.items() if v.user_id == user_id]
        for key in keys_to_delete:
            del self._cache[key]
        return len(keys_to_delete)

    def clear(self) -> None:
        self._cache.clear()
        self._hits = 0
        self._misses = 0

    def get_stats(self) -> Dict[str, Any]:
        total_requests = self._hits + self._misses
        hit_rate = self._hits / total_requests if total_requests > 0 else 0
        return {
            "size": len(self._cache),
            "max_size": self.max_size,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": hit_rate,
            "total_requests": total_requests,
        }


# Global cache instance (singleton pattern)
_query_cache: Optional[QueryCache] = None
_rag_context_cache: Optional[RagContextCache] = None
_rag_response_cache: Optional[RagResponseCache] = None


def get_query_cache(max_size: int = 1000, ttl_seconds: int = 3600) -> QueryCache:
    """Get or create the global query cache instance."""
    global _query_cache
    if _query_cache is None:
        _query_cache = QueryCache(max_size=max_size, ttl_seconds=ttl_seconds)
    return _query_cache


def get_rag_context_cache(max_size: int = 500, ttl_seconds: Optional[int] = None) -> RagContextCache:
    """Get or create the shared RAG context cache instance.

    TTL is read from CACHE_TTL_SEARCH (seconds) when set in the environment,
    otherwise defaults to 3600. This aligns recall/context cache with infrastructure
    cache config (ttl_search).
    """
    global _rag_context_cache
    if _rag_context_cache is None:
        if ttl_seconds is None:
            ttl_seconds = int(os.getenv("CACHE_TTL_SEARCH", "3600"))
        _rag_context_cache = RagContextCache(max_size=max_size, ttl_seconds=ttl_seconds)
    return _rag_context_cache


def get_rag_response_cache(max_size: int = 1000, ttl_seconds: int = 86400) -> RagResponseCache:
    """Get or create the shared RAG final-answer cache instance."""
    global _rag_response_cache
    if _rag_response_cache is None:
        _rag_response_cache = RagResponseCache(max_size=max_size, ttl_seconds=ttl_seconds)
    return _rag_response_cache
