"""
RAG / Memory Framework Engine

Provides multimodal, multilingual (Arabic/English) memory capabilities
for fast retrieval and narrative context synthesis.
"""

from .memory_manager import MemoryManager
from .augmentation import RAGAugmentor, AugmentedRAGContext
from .types import RetrievalResult, MemoryChunk
from .config import get_config
from .api import (
    remember,
    recall,
    search,
    forget,
    chunk,
    chunk_stream,
    RAGClient,
    get_stats,
    detect_lang,
    normalize,
    clear_cache,
    get_cache_stats,
    invalidate_user_cache
)

__all__ = [
    "MemoryManager",
    "RAGAugmentor",
    "AugmentedRAGContext",
    "RetrievalResult",
    "MemoryChunk",
    "get_config",
    "remember",
    "recall",
    "search",
    "forget",
    "chunk",
    "chunk_stream",
    "RAGClient",
    "get_stats",
    "detect_lang",
    "normalize",
    "clear_cache",
    "get_cache_stats",
    "invalidate_user_cache"
]
__version__ = "0.1.0"
