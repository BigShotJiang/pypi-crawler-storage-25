"""
Query Processor Module for the Memory Framework.

Provides query understanding and enhancement for improved retrieval:
- Language detection
- Keyword extraction
- Query expansion
"""

import re
import logging
from typing import List, Dict, Any, Set
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# Arabic character ranges
ARABIC_PATTERN = re.compile(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]+")


@dataclass
class ProcessedQuery:
    """Result of query processing."""

    original: str
    language: str  # 'ar' or 'en'
    keywords: List[str]
    expansions: List[str] = field(default_factory=list)
    filters: Dict[str, Any] = field(default_factory=dict)


class QueryProcessor:
    """
    Processes and enhances queries for optimal retrieval.

    Features:
    - Language detection (Arabic/English)
    - Keyword extraction for hybrid search boost
    - Query expansion (optional, LLM-based)
    - Filter extraction from natural language
    """

    # Arabic stopwords (common words to exclude from keywords)
    ARABIC_STOPWORDS: Set[str] = {
        "في",
        "من",
        "إلى",
        "على",
        "عن",
        "مع",
        "هذا",
        "هذه",
        "ذلك",
        "تلك",
        "التي",
        "الذي",
        "الذين",
        "اللاتي",
        "كان",
        "كانت",
        "يكون",
        "هو",
        "هي",
        "هم",
        "هن",
        "أنا",
        "نحن",
        "أنت",
        "أنتم",
        "ما",
        "ماذا",
        "لماذا",
        "كيف",
        "متى",
        "أين",
        "هل",
        "لا",
        "نعم",
        "كل",
        "بعض",
        "أي",
        "قد",
        "لقد",
        "و",
        "أو",
        "ثم",
        "لكن",
        "إن",
        "أن",
        "لأن",
        "حتى",
        "إذا",
        "عند",
    }

    # English stopwords
    ENGLISH_STOPWORDS: Set[str] = {
        "the",
        "a",
        "an",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "have",
        "has",
        "had",
        "do",
        "does",
        "did",
        "will",
        "would",
        "could",
        "should",
        "may",
        "might",
        "must",
        "shall",
        "can",
        "need",
        "dare",
        "ought",
        "used",
        "to",
        "of",
        "in",
        "for",
        "on",
        "with",
        "at",
        "by",
        "from",
        "up",
        "about",
        "into",
        "over",
        "after",
        "beneath",
        "under",
        "above",
        "it",
        "its",
        "this",
        "that",
        "these",
        "those",
        "i",
        "me",
        "my",
        "we",
        "our",
        "you",
        "your",
        "he",
        "him",
        "his",
        "she",
        "her",
        "they",
        "them",
        "their",
        "what",
        "which",
        "who",
        "when",
        "where",
        "why",
        "how",
        "all",
        "each",
        "every",
        "both",
        "few",
        "more",
        "most",
        "other",
        "some",
        "such",
        "no",
        "nor",
        "not",
        "only",
        "own",
        "same",
        "so",
        "than",
        "too",
        "very",
        "just",
        "and",
        "but",
        "if",
        "or",
        "because",
        "as",
        "until",
        "while",
        "although",
        "though",
        "once",
    }

    # Filter keywords to detect modality requests
    MODALITY_KEYWORDS = {
        "image": ["image", "picture", "photo", "صورة", "صور"],
        "audio": ["audio", "sound", "voice", "صوت", "تسجيل"],
        "video": ["video", "مقطع", "فيديو"],
    }

    def __init__(self, enable_expansion: bool = False):
        """
        Initialize the query processor.

        Args:
            enable_expansion: Whether to enable LLM-based query expansion.
        """
        self.enable_expansion = enable_expansion

    def process(self, query: str) -> ProcessedQuery:
        """
        Process a query and extract structured information.

        Args:
            query: The raw query string.

        Returns:
            ProcessedQuery with language, keywords, and optional expansions.
        """
        query = query.strip()

        # Detect language
        language = self._detect_language(query)

        # Extract keywords
        keywords = self._extract_keywords(query, language)

        # Extract filters from query
        filters = self._extract_filters(query)

        # Optional: Generate expansions
        expansions = []
        if self.enable_expansion:
            expansions = self._expand_query(query, language)

        logger.debug(f"Processed query: lang={language}, keywords={keywords[:5]}, filters={filters}")

        return ProcessedQuery(
            original=query,
            language=language,
            keywords=keywords,
            expansions=expansions,
            filters=filters,
        )

    def _detect_language(self, text: str) -> str:
        """
        Detect if text is primarily Arabic or English.

        Returns 'ar' for Arabic, 'en' for English/other.
        """
        arabic_matches = ARABIC_PATTERN.findall(text)
        arabic_chars = sum(len(m) for m in arabic_matches)
        total_alpha = len(re.findall(r"\w", text))

        if total_alpha == 0:
            return "en"

        arabic_ratio = arabic_chars / total_alpha
        return "ar" if arabic_ratio > 0.3 else "en"

    def _extract_keywords(self, query: str, language: str) -> List[str]:
        """
        Extract significant keywords from the query.

        Removes stopwords and returns meaningful terms for hybrid search.
        """
        # Tokenize (simple word split, works for both Arabic and English)
        words = re.findall(r"\w+", query.lower())

        # Select appropriate stopwords
        stopwords = self.ARABIC_STOPWORDS if language == "ar" else self.ENGLISH_STOPWORDS

        # Filter stopwords and short words
        keywords = [w for w in words if w not in stopwords and len(w) > 2]

        return keywords

    def _extract_filters(self, query: str) -> Dict[str, Any]:
        """
        Extract metadata filters from natural language query.

        E.g., "show me images from page 5" -> {"modality": "image", "page": 5}
        """
        filters = {}
        query_lower = query.lower()

        # Detect modality filter
        for modality, keywords in self.MODALITY_KEYWORDS.items():
            if any(kw in query_lower for kw in keywords):
                filters["modality"] = modality
                break

        # Detect page filter (e.g., "page 5", "صفحة 5")
        page_match = re.search(r"(?:page|صفحة)\s*(\d+)", query_lower)
        if page_match:
            filters["page"] = int(page_match.group(1))

        return filters

    def _expand_query(self, query: str, language: str) -> List[str]:
        """
        Generate query expansions (paraphrases).

        This is a placeholder for LLM-based expansion.
        In production, call an LLM to generate 2-3 paraphrases.
        """
        # Placeholder: return empty list
        # In production, integrate with LLM provider
        logger.debug("Query expansion is enabled but no LLM configured")
        return []


def get_query_processor(enable_expansion: bool = False) -> QueryProcessor:
    """Factory function to create a QueryProcessor."""
    return QueryProcessor(enable_expansion=enable_expansion)
