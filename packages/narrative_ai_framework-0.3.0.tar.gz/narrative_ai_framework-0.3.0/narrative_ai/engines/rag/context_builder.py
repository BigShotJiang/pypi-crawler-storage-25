"""
Context Builder for the Memory Framework.

Synthesizes retrieved chunks into a coherent context
for LLM consumption, with modality markers and source attribution.
"""

import logging
from typing import List, Optional

from .types import RetrievalResult, RichContext
from .strategies import DomainStrategy, get_strategy
from .config import get_config

logger = logging.getLogger(__name__)


class ContextBuilder:
    """
    Builds formatted context from retrieval results.

    Handles:
    - Modality-specific formatting
    - Chronological ordering (if strategy requires)
    - Media reference extraction
    - Source attribution
    """

    def __init__(self, strategy: Optional[DomainStrategy] = None):
        """
        Initialize context builder.

        Args:
            strategy: Domain strategy for formatting. Uses config default if not provided.
        """
        config = get_config()
        self.strategy = strategy or get_strategy(config.strategy)

    def build(
        self,
        results: List[RetrievalResult],
        query: str,
        max_tokens: Optional[int] = None,
        use_parent_text: bool = True,
    ) -> RichContext:
        """
        Build rich context from retrieval results.

        Args:
            results: List of retrieval results.
            query: Original query string.
            max_tokens: Optional token limit for context.
            use_parent_text: If True, use parent_text for richer context (Small-to-Big).

        Returns:
            RichContext with formatted text and media references.
        """
        if not results:
            return RichContext(
                formatted_text="No relevant information found.",
                media_references=[],
                source_chunks=[],
                query=query,
                strategy_used=self.strategy.name,
                total_retrieved=0,
            )

        # Build context with citations
        lines = []
        media_refs = []
        included_results = []
        seen_parents = set()  # Deduplicate parent windows
        token_budget = max_tokens if max_tokens is not None and max_tokens > 0 else None
        used_tokens = 0

        for result in results:
            # Use parent_text if available (Small-to-Big strategy)
            if use_parent_text and result.parent_text and result.parent_window_id:
                # Deduplicate: only include each parent window once
                if result.parent_window_id in seen_parents:
                    continue
                seen_parents.add(result.parent_window_id)
                text_to_use = result.parent_text
            else:
                text_to_use = result.text

            # Build citation header
            citation_parts = [f"[{result.modality.upper()}]"]
            if result.page:
                citation_parts.append(f"Page {result.page}")
            if result.media_ref:
                citation_parts.append(f"Media: {result.media_ref}")

            citation = " | ".join(citation_parts)
            source_number = len(lines) + 1
            section = f"### Source {source_number} ({citation})\n{text_to_use}"

            if token_budget is not None:
                separator_tokens = self._estimate_tokens("\n\n---\n\n") if lines else 0
                section_tokens = self._estimate_tokens(section)
                projected = used_tokens + separator_tokens + section_tokens
                if projected > token_budget:
                    remaining_tokens = token_budget - used_tokens - separator_tokens
                    if remaining_tokens > 40:
                        truncated_section = self._truncate_to_tokens(section, remaining_tokens)
                        if truncated_section:
                            lines.append(truncated_section)
                            included_results.append(result)
                            if result.media_ref:
                                media_refs.append(result.media_ref)
                    break

                used_tokens = projected

            lines.append(section)
            included_results.append(result)
            if result.media_ref:
                media_refs.append(result.media_ref)

        if not lines:
            fallback = "No relevant information found."
            if token_budget is not None:
                fallback = self._truncate_to_tokens(fallback, token_budget)
            return RichContext(
                formatted_text=fallback,
                media_references=[],
                source_chunks=[],
                query=query,
                strategy_used=self.strategy.name,
                total_retrieved=0,
            )

        formatted_text = "\n\n---\n\n".join(lines)

        logger.debug(f"Built context with {len(results)} chunks, {len(media_refs)} media refs")

        return RichContext(
            formatted_text=formatted_text,
            media_references=media_refs,
            source_chunks=included_results,
            query=query,
            strategy_used=self.strategy.name,
            total_retrieved=len(included_results),
        )

    @staticmethod
    def _estimate_tokens(text: str) -> int:
        if not text:
            return 0
        return max(1, int(len(text) / 4))

    def _truncate_to_tokens(self, text: str, max_tokens: int) -> str:
        if max_tokens <= 0:
            return ""
        if self._estimate_tokens(text) <= max_tokens:
            return text
        max_chars = max_tokens * 4
        if max_chars < 8:
            return text[:max_chars]
        return text[: max_chars - 3].rstrip() + "..."

    def build_for_llm(
        self,
        results: List[RetrievalResult],
        query: str,
        system_template: Optional[str] = None,
    ) -> str:
        """
        Build a complete prompt context string for an LLM.

        Args:
            results: List of retrieval results.
            query: Original query string.
            system_template: Optional system prompt template.

        Returns:
            Formatted string ready for LLM input.
        """
        context = self.build(results, query)

        # Default template
        if not system_template:
            system_template = """Based on the following context from the user's memories, answer their question.

CONTEXT:
{context}

USER QUESTION: {query}

Provide a helpful, accurate response based on the context above. If the context doesn't contain relevant information, say so."""

        return system_template.format(
            context=context.formatted_text,
            query=query,
        )
