"""
Type definitions for the Memory Framework.

Defines the data structures used throughout the RAG engine,
including chunks, retrieval results, and memory entries.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from datetime import datetime


@dataclass
class MemoryChunk:
    """
    A single chunk of content ready for embedding and storage.

    Represents the atomic unit of retrieval - a piece of text
    with all necessary metadata to trace it back to its source.
    """

    chunk_id: str
    text: str

    # Source tracking
    doc_id: str
    block_id: str

    # Metadata for retrieval strategies
    timestamp: Optional[datetime] = None
    modality: str = "text"  # text | image | audio | table
    page: Optional[int] = None

    # Rich media reference (path to original image/audio)
    media_ref: Optional[str] = None

    # Additional metadata
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RetrievalResult:
    """
    A single result from the retrieval pipeline.

    Contains both the text content and all metadata needed
    for context building and rich media display.
    """

    chunk_id: str
    text: str
    score: float

    # Source tracking
    doc_id: str
    block_id: str

    # Metadata
    modality: str = "text"
    timestamp: Optional[datetime] = None
    page: Optional[int] = None

    # Rich media reference
    media_ref: Optional[str] = None

    # Parent window text for Small-to-Big retrieval
    parent_text: Optional[str] = None
    parent_window_id: Optional[str] = None

    # Additional metadata from block (provenance, extraction_method, etc.)
    extra: Dict[str, Any] = field(default_factory=dict)

    # Original embedding vectors (optional, for debugging)
    dense_vector: Optional[List[float]] = None
    sparse_vector: Optional[Dict[str, float]] = None


@dataclass
class RichContext:
    """
    The final synthesized context for LLM consumption.

    Contains formatted text with modality markers and
    a list of media references for the UI to display.
    """

    formatted_text: str
    media_references: List[str] = field(default_factory=list)
    source_chunks: List[RetrievalResult] = field(default_factory=list)

    # Metadata
    query: str = ""
    strategy_used: str = "default"
    total_retrieved: int = 0


@dataclass
class IndexingResult:
    """Result of indexing a document into memory."""

    doc_id: str
    chunks_indexed: int
    success: bool
    errors: List[str] = field(default_factory=list)
