"""
Configuration module for the Memory Framework.

Loads settings from memory_config.yaml and provides Pydantic models
for type-safe access throughout the engine.
"""

import logging
import os
import re
from pathlib import Path
from typing import Optional, Callable, Any
from dataclasses import dataclass, field
import yaml

logger = logging.getLogger(__name__)

# Path to the default config file
DEFAULT_CONFIG_PATH = Path(__file__).parent / "memory_config.yaml"


@dataclass
class QdrantConfig:
    """Qdrant vector store configuration."""

    host: str = "localhost"
    port: int = 6333
    collection: str = "narrative_memory"
    use_sparse: bool = True
    prefer_grpc: bool = False


@dataclass
class EmbeddingConfig:
    """Embedding model configuration."""

    model: str = "BAAI/bge-m3"
    batch_size: int = 32
    max_length: int = 8192
    device: str = "cpu"


@dataclass
class RetrievalConfig:
    """Retrieval settings."""

    top_k: int = 20
    final_k: int = 5
    hybrid_alpha: float = 0.7
    similarity_threshold: float = 0.5
    context_max_tokens: Optional[int] = None


@dataclass
class ChunkingConfig:
    """Chunking settings."""

    chunk_size: int = 512
    chunk_overlap: int = 50
    preserve_blocks: bool = True


@dataclass
class ProvidersConfig:
    """Provider selection."""

    vector_store: str = "qdrant"
    embedding: str = "bge-m3"
    reranker: str = "none"


@dataclass
class IntegrationConfig:
    """Security integration settings. Defaults OFF for zero functional impact."""

    enable_rate_limiting: bool = False
    enable_audit_logging: bool = False
    enable_input_validation: bool = False
    enable_error_handling: bool = False
    user_tier_callback: Optional[Callable] = field(default=None, repr=False)


@dataclass
class MemoryConfig:
    """Root configuration for the Memory Framework."""

    version: str = "1.0"
    providers: ProvidersConfig = field(default_factory=ProvidersConfig)
    integration: IntegrationConfig = field(default_factory=IntegrationConfig)
    qdrant: QdrantConfig = field(default_factory=QdrantConfig)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)
    chunking: ChunkingConfig = field(default_factory=ChunkingConfig)
    strategy: str = "default"


def _interpolate_env_vars(data: Any) -> Any:
    """
    Recursively interpolate environment variables in the configuration.
    Supports ${VAR_NAME} and ${VAR_NAME:-default_value} syntax.
    """
    if isinstance(data, dict):
        return {k: _interpolate_env_vars(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [_interpolate_env_vars(i) for i in data]
    elif isinstance(data, str):
        # Match ${VAR_NAME} or ${VAR_NAME:-default}
        pattern = r"\$\{([^}:]+)(?::-([^}]*))?\}"

        def replace(match):
            var_name = match.group(1)
            default_value = match.group(2)
            return os.environ.get(var_name, default_value if default_value is not None else match.group(0))

        return re.sub(pattern, replace, data)
    return data


def load_config(config_path: Optional[Path] = None) -> MemoryConfig:
    """
    Load configuration from YAML file and interpolate environment variables.

    Args:
        config_path: Path to config file. Uses default if not provided.

    Returns:
        MemoryConfig instance with loaded settings.
    """
    path = config_path or DEFAULT_CONFIG_PATH

    if not path.exists():
        logger.warning(f"Config file not found at {path}, using defaults")
        return MemoryConfig()

    try:
        with open(path, "r", encoding="utf-8") as f:
            raw_data = yaml.safe_load(f)

        # Interpolate environment variables
        data = _interpolate_env_vars(raw_data) or {}

        # Parse nested configs
        providers = ProvidersConfig(**data.get("providers", {}))
        qdrant = QdrantConfig(**data.get("qdrant", {}))
        embedding = EmbeddingConfig(**data.get("embedding", {}))
        retrieval = RetrievalConfig(**data.get("retrieval", {}))
        chunking = ChunkingConfig(**data.get("chunking", {}))
        integration_data = {
            k: v
            for k, v in data.get("integration", {}).items()
            if k in ("enable_rate_limiting", "enable_audit_logging", "enable_input_validation", "enable_error_handling")
        }
        integration = IntegrationConfig(**integration_data)

        return MemoryConfig(
            version=data.get("version", "1.0"),
            providers=providers,
            qdrant=qdrant,
            embedding=embedding,
            retrieval=retrieval,
            chunking=chunking,
            integration=integration,
            strategy=data.get("strategy", "default"),
        )
    except Exception as e:
        logger.error(f"Failed to load config from {path}: {e}")
        raise


# Singleton config instance
_config: Optional[MemoryConfig] = None


def get_config() -> MemoryConfig:
    """Get the singleton config instance."""
    global _config
    if _config is None:
        _config = load_config()
    return _config


def reset_config() -> None:
    """Reset the singleton config (useful for testing)."""
    global _config
    _config = None
