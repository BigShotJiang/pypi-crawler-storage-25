"""
Strategy module for the Memory Framework.
"""

from .base import DomainStrategy, StrategyConfig
from .default import DefaultStrategy
from .diary import DiaryStrategy

__all__ = [
    "DomainStrategy",
    "StrategyConfig",
    "DefaultStrategy",
    "DiaryStrategy",
]


def get_strategy(name: str) -> DomainStrategy:
    """
    Get a strategy instance by name.

    Args:
        name: Strategy name (default, diary, medical, etc.)

    Returns:
        DomainStrategy instance.
    """
    strategies = {
        "default": DefaultStrategy,
        "diary": DiaryStrategy,
    }

    strategy_class = strategies.get(name.lower(), DefaultStrategy)
    return strategy_class()
