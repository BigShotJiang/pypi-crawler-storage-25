"""
Diary domain strategy.

Optimized for personal logs and journals where recency
and narrative flow are important.
"""

from typing import List
from datetime import datetime

from .base import DomainStrategy, StrategyConfig
from ..types import RetrievalResult, RichContext


class DiaryStrategy(DomainStrategy):
    """
    Strategy optimized for personal diaries and journals.

    Key features:
    - Weights recent entries higher than older ones
    - Sorts results chronologically for narrative flow
    - Formats as first-person narrative
    """

    # Decay factor for recency (entries lose 50% relevance per week)
    DECAY_HALF_LIFE_SECONDS = 7 * 24 * 60 * 60  # 1 week

    def __init__(self):
        super().__init__(
            StrategyConfig(
                recency_weight=0.3,
                relevance_weight=0.7,
                context_window=1,  # Include neighboring blocks
                sort_by_time=True,  # Narrative ordering
            )
        )

    @property
    def name(self) -> str:
        return "diary"

    def calculate_final_score(
        self,
        result: RetrievalResult,
        current_time: float,
    ) -> float:
        """
        Score with recency bonus.

        Recent entries get a boost, older entries are still relevant
        but with diminishing weight.
        """
        base_score = result.score * self.config.relevance_weight
        if isinstance(current_time, datetime):
            current_time = current_time.timestamp()

        if result.timestamp:
            # Calculate time decay
            result_time = result.timestamp.timestamp() if isinstance(result.timestamp, datetime) else result.timestamp
            age_seconds = max(0.0, float(current_time) - float(result_time))

            # Exponential decay
            recency_factor = 0.5 ** (age_seconds / self.DECAY_HALF_LIFE_SECONDS)
            recency_bonus = recency_factor * self.config.recency_weight
        else:
            recency_bonus = 0.0

        return base_score + recency_bonus

    def format_context(
        self,
        results: List[RetrievalResult],
        query: str,
    ) -> RichContext:
        """Format as a first-person narrative."""
        # Reorder chronologically
        ordered = self.reorder_results(results)

        lines = []
        media_refs = []

        for result in ordered:
            # Add timestamp if available
            time_str = ""
            if result.timestamp:
                if isinstance(result.timestamp, datetime):
                    time_str = result.timestamp.strftime("%B %d, %Y")
                else:
                    time_str = datetime.fromtimestamp(result.timestamp).strftime("%B %d, %Y")

            # Add modality marker with narrative style
            if result.modality == "audio":
                prefix = f"[Voice memo from {time_str}]:" if time_str else "[Voice memo]:"
            elif result.modality == "image":
                prefix = f"[Photo from {time_str}]:" if time_str else "[Photo]:"
            else:
                prefix = f"[Entry from {time_str}]:" if time_str else "[Entry]:"

            lines.append(f"{prefix}\n{result.text}")

            if result.media_ref:
                media_refs.append(result.media_ref)

        return RichContext(
            formatted_text="\n\n".join(lines),
            media_references=media_refs,
            source_chunks=ordered,
            query=query,
            strategy_used=self.name,
            total_retrieved=len(ordered),
        )
