"""
Default domain strategy.

A balanced strategy that focuses purely on relevance score
without any domain-specific adjustments.
"""

from typing import List

from .base import DomainStrategy, StrategyConfig
from ..types import RetrievalResult, RichContext


class DefaultStrategy(DomainStrategy):
    """
    Default balanced retrieval strategy.

    Uses pure relevance scoring with no temporal weighting.
    Formats context as simple citations.
    """

    def __init__(self):
        super().__init__(
            StrategyConfig(
                recency_weight=0.0,
                relevance_weight=1.0,
                context_window=0,
                sort_by_time=False,
            )
        )

    @property
    def name(self) -> str:
        return "default"

    def calculate_final_score(
        self,
        result: RetrievalResult,
        current_time: float,
    ) -> float:
        """Pure relevance-based scoring."""
        return result.score * self.config.relevance_weight

    def format_context(
        self,
        results: List[RetrievalResult],
        query: str,
    ) -> RichContext:
        """Format as simple citations with modality markers."""
        lines = []
        media_refs = []

        for i, result in enumerate(results, 1):
            # Add modality marker
            modality_tag = f"[{result.modality.upper()}]"

            # Add source info if available
            source_info = ""
            if result.page:
                source_info = f" (Page {result.page})"

            lines.append(f"{modality_tag}{source_info}:\n{result.text}\n")

            # Collect media references
            if result.media_ref:
                media_refs.append(result.media_ref)

        return RichContext(
            formatted_text="\n---\n".join(lines),
            media_references=media_refs,
            source_chunks=results,
            query=query,
            strategy_used=self.name,
            total_retrieved=len(results),
        )
