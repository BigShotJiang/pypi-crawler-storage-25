"""
Domain Strategy base class and interface.

Strategies define how the Memory Framework adapts to different use cases
(e.g., personal diaries vs. medical records).
"""

from abc import ABC, abstractmethod
from typing import List
from dataclasses import dataclass

from ..types import RetrievalResult, RichContext


@dataclass
class StrategyConfig:
    """Configuration for a domain strategy."""

    recency_weight: float = 0.0  # How much to weight recent entries (0-1)
    relevance_weight: float = 1.0  # How much to weight similarity score (0-1)
    context_window: int = 0  # Number of neighboring blocks to include
    sort_by_time: bool = False  # Sort final results chronologically


class DomainStrategy(ABC):
    """
    Abstract base class for domain strategies.

    A strategy defines:
    1. How to score and rank retrieval results (recency vs. relevance)
    2. How to format the context for the LLM (narrative vs. citation)
    3. How much surrounding context to include
    """

    def __init__(self, config: StrategyConfig = None):
        self.config = config or StrategyConfig()

    @abstractmethod
    def calculate_final_score(
        self,
        result: RetrievalResult,
        current_time: float,
    ) -> float:
        """
        Calculate the final score for a retrieval result.

        This allows strategies to weight recency vs. relevance differently.

        Args:
            result: The retrieval result to score.
            current_time: Current timestamp for recency calculation.

        Returns:
            Final score for ranking.
        """
        pass

    @abstractmethod
    def format_context(
        self,
        results: List[RetrievalResult],
        query: str,
    ) -> RichContext:
        """
        Format the retrieved results into a context string for the LLM.

        Args:
            results: List of retrieval results.
            query: Original query string.

        Returns:
            RichContext with formatted text and media references.
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the strategy name."""
        pass

    def reorder_results(
        self,
        results: List[RetrievalResult],
    ) -> List[RetrievalResult]:
        """
        Optionally reorder results (e.g., by timestamp for narrative flow).

        Default implementation returns results as-is.
        """
        if self.config.sort_by_time and results:
            return sorted(
                results,
                key=lambda r: r.timestamp or 0,
                reverse=False,  # Oldest first for narrative
            )
        return results
