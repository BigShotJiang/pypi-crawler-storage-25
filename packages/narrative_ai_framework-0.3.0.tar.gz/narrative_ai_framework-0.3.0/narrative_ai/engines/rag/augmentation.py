"""RAG augmentation helpers for chat orchestration.

Centralizes user-scoped recall context retrieval and caching so chat routes
can keep orchestration logic small and deterministic.
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .cache import (
    RagContextCache,
    RagResponseCache,
    get_rag_context_cache,
    get_rag_response_cache,
)

logger = logging.getLogger(__name__)


@dataclass
class AugmentedRAGContext:
    """RAG context package returned to chat orchestrators."""

    formatted_text: str = ""
    source_chunk_ids: List[str] = field(default_factory=list)
    context_fingerprint: str = ""
    cache_hit: bool = False


class RAGAugmentor:
    """Builds and caches user-scoped RAG context and final answers."""

    def __init__(
        self,
        rag_engine: Any,
        *,
        context_cache: Optional[RagContextCache] = None,
        response_cache: Optional[RagResponseCache] = None,
    ) -> None:
        self.rag_engine = rag_engine
        self.context_cache = context_cache or get_rag_context_cache()
        self.response_cache = response_cache or get_rag_response_cache()

    async def get_context(
        self,
        *,
        query: str,
        user_id: str,
        top_k: int = 5,
        filters: Optional[Dict[str, Any]] = None,
        max_tokens: Optional[int] = None,
    ) -> AugmentedRAGContext:
        """Return context for a query, using user-scoped cache when possible."""
        if not query.strip():
            return AugmentedRAGContext()
        if not user_id:
            raise ValueError("user_id is required for user-scoped RAG augmentation")

        cached = self.context_cache.get(query, user_id, top_k=top_k, filters=filters)
        if cached is not None:
            return AugmentedRAGContext(
                formatted_text=cached.formatted_text,
                source_chunk_ids=cached.source_chunk_ids,
                context_fingerprint=cached.context_fingerprint,
                cache_hit=True,
            )

        rich_context = await self.rag_engine.recall(
            query=query,
            user_id=user_id,
            top_k=top_k,
            filters=filters,
            return_context=True,
            require_user_scope=True,
        )
        if rich_context is None:
            return AugmentedRAGContext()

        formatted_text = getattr(rich_context, "formatted_text", "") or str(rich_context)
        if max_tokens is not None:
            formatted_text = self._truncate_to_tokens(formatted_text, max_tokens)

        source_chunk_ids = self._extract_source_chunk_ids(rich_context)
        has_context = bool(formatted_text.strip()) and bool(source_chunk_ids)
        context_fingerprint = self._build_context_fingerprint(source_chunk_ids, formatted_text) if has_context else ""

        if has_context:
            self.context_cache.set(
                query,
                user_id,
                top_k=top_k,
                filters=filters,
                formatted_text=formatted_text,
                source_chunk_ids=source_chunk_ids,
                context_fingerprint=context_fingerprint,
            )
        return AugmentedRAGContext(
            formatted_text=formatted_text,
            source_chunk_ids=source_chunk_ids,
            context_fingerprint=context_fingerprint,
            cache_hit=False,
        )

    def get_cached_response(
        self,
        *,
        query: str,
        user_id: str,
        intent: str,
        context_fingerprint: str,
    ) -> Optional[str]:
        """Return cached final answer text for an identical RAG context."""
        if not context_fingerprint:
            return None
        cached = self.response_cache.get(
            query=query,
            user_id=user_id,
            intent=intent,
            context_fingerprint=context_fingerprint,
        )
        return cached.text if cached is not None else None

    def set_cached_response(
        self,
        *,
        query: str,
        user_id: str,
        intent: str,
        context_fingerprint: str,
        response_text: str,
    ) -> None:
        """Store final answer text keyed by user, query, intent, and context."""
        if not response_text.strip() or not context_fingerprint:
            return
        self.response_cache.set(
            query=query,
            user_id=user_id,
            intent=intent,
            context_fingerprint=context_fingerprint,
            text=response_text,
        )

    def _extract_source_chunk_ids(self, rich_context: Any) -> List[str]:
        source_chunks = getattr(rich_context, "source_chunks", None) or []
        chunk_ids: List[str] = []
        for chunk in source_chunks:
            chunk_id = getattr(chunk, "chunk_id", None)
            if chunk_id:
                chunk_ids.append(str(chunk_id))
        return chunk_ids

    @staticmethod
    def _build_context_fingerprint(source_chunk_ids: List[str], formatted_text: str) -> str:
        raw = f"{'|'.join(source_chunk_ids)}::{formatted_text}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    @staticmethod
    def _estimate_tokens(text: str) -> int:
        if not text:
            return 0
        return max(1, int(len(text) / 4))

    def _truncate_to_tokens(self, text: str, max_tokens: int) -> str:
        if max_tokens <= 0:
            return ""
        if self._estimate_tokens(text) <= max_tokens:
            return text
        max_chars = max_tokens * 4
        if max_chars < 8:
            return text[:max_chars]
        return text[: max_chars - 3].rstrip() + "..."
