from typing import Optional

from .base import (
    EmbeddingProvider,
    VectorStoreProvider,
    RerankerProvider,
    EmbeddingOutput,
)
from .embeddings import BGEM3EmbeddingProvider, BGEM3LiteProvider, CohereEmbeddingProvider, OpenAIEmbeddingProvider
from .rerankers import BGERerankerProvider, CohereRerankerProvider


def get_embedding_provider(name: str, **kwargs) -> EmbeddingProvider:
    """Factory to get embedding provider by name."""
    name = name.lower()

    # Extract model if present to handle naming differences
    model = kwargs.pop("model", None)

    if name == "bge-m3":
        return BGEM3EmbeddingProvider(model_name=model, **kwargs) if model else BGEM3EmbeddingProvider(**kwargs)
    elif name == "bge-m3-lite":
        return BGEM3LiteProvider(model_name=model, **kwargs) if model else BGEM3LiteProvider(**kwargs)
    elif name == "cohere":
        # Cloud providers don't need 'device'
        kwargs.pop("device", None)
        # If model is just 'cohere', use the default instead of overriding
        if model == "cohere":
            model = None
        return CohereEmbeddingProvider(model=model, **kwargs) if model else CohereEmbeddingProvider(**kwargs)
    elif name == "openai":
        # Cloud providers don't need 'device'
        kwargs.pop("device", None)
        return OpenAIEmbeddingProvider(model=model, **kwargs) if model else OpenAIEmbeddingProvider(**kwargs)
    else:
        raise ValueError(f"Unknown embedding provider: {name}")


def get_reranker_provider(name: str, **kwargs) -> Optional[RerankerProvider]:
    """Factory to get reranker provider by name."""
    if not name or name.lower() == "none":
        return None

    name = name.lower()
    if name == "bge-reranker":
        return BGERerankerProvider(**kwargs)
    elif name == "cohere":
        # Check if cohere is available before creating the provider
        try:
            import cohere  # noqa: F401
        except ImportError:
            # Cohere not installed - return None to allow graceful degradation
            import logging

            logging.getLogger(__name__).warning(
                "Cohere reranker requested but 'cohere' package not installed. "
                "Continuing without reranker. Install with: pip install cohere"
            )
            return None
        return CohereRerankerProvider(**kwargs)
    else:
        raise ValueError(f"Unknown reranker provider: {name}")


__all__ = [
    "EmbeddingProvider",
    "VectorStoreProvider",
    "RerankerProvider",
    "EmbeddingOutput",
    "BGEM3EmbeddingProvider",
    "BGEM3LiteProvider",
    "CohereEmbeddingProvider",
    "OpenAIEmbeddingProvider",
    "BGERerankerProvider",
    "CohereRerankerProvider",
    "get_embedding_provider",
    "get_reranker_provider",
]
