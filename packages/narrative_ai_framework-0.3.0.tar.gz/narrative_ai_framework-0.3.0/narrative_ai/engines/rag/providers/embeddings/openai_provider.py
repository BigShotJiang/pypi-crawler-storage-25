"""
OpenAI Embedding Provider.

Provides embeddings using OpenAI's 'text-embedding-3-small/large' models.
"""

import logging
import os
from typing import List, Optional

from ..base import EmbeddingProvider, EmbeddingOutput

logger = logging.getLogger(__name__)


class OpenAIEmbeddingProvider(EmbeddingProvider):
    """
    OpenAI implementation of the embedding provider.

    Supports 'text-embedding-3-small' and 'text-embedding-3-large'.
    Note: Standard OpenAI embeddings do not provide sparse vectors.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "text-embedding-3-small",
        dimensions: int = 1536,
    ):
        """
        Initialize OpenAI provider.

        Args:
            api_key: OpenAI API Key. Loads from OPENAI_API_KEY if not provided.
            model: Model name.
            dimensions: Output dimensions (only for V3 models).
        """
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self.model_name = model
        self.dimensions_param = dimensions

        self._client = None

    @property
    def client(self):
        """Lazy-load async OpenAI client."""
        if self._client is None:
            try:
                from openai import AsyncOpenAI

                self._client = AsyncOpenAI(api_key=self.api_key)
            except ImportError:
                raise ImportError("openai is required. Install with: pip install openai")
        return self._client

    @property
    def dimension(self) -> int:
        return self.dimensions_param

    @property
    def supports_sparse(self) -> bool:
        return False

    async def embed_query(self, text: str) -> EmbeddingOutput:
        """Embed single query (async)."""
        request_params = {
            "input": text,
            "model": self.model_name,
        }
        if "text-embedding-3" in self.model_name:
            request_params["dimensions"] = self.dimensions_param

        response = await self.client.embeddings.create(**request_params)
        return EmbeddingOutput(dense_vector=response.data[0].embedding)

    async def embed_texts(self, texts: List[str]) -> List[EmbeddingOutput]:
        """Embed multiple texts (async)."""
        if not texts:
            return []

        request_params = {
            "input": texts,
            "model": self.model_name,
        }
        if "text-embedding-3" in self.model_name:
            request_params["dimensions"] = self.dimensions_param

        response = await self.client.embeddings.create(**request_params)

        return [EmbeddingOutput(dense_vector=item.embedding) for item in response.data]
