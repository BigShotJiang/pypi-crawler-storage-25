"""
Cohere Embedding Provider.

Provides high-performance multilingual embeddings using Cohere's API.
Excellent for Arabic/English hybrid search.

NOTE: This provider is Pure Async for production performance.
"""

import logging
from typing import List, Optional

from ..base import EmbeddingProvider, EmbeddingOutput

logger = logging.getLogger(__name__)


class CohereEmbeddingProvider(EmbeddingProvider):
    """
    Cohere implementation of the embedding provider.

    Uses 'embed-multilingual-v3.0' which is state-of-the-art
    for multilingual RAG, including Arabic.

    All methods are async for production performance.
    """

    MODEL_NAME = "embed-multilingual-v3.0"
    DENSE_DIM = 1024

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = MODEL_NAME,
        input_type_search: str = "search_query",
        input_type_index: str = "search_document",
    ):
        """
        Initialize Cohere provider.

        Args:
            api_key: Cohere API Key. Loads from COHERE_API_KEY if not provided.
            model: Model name to use.
            input_type_search: Input type for queries.
            input_type_index: Input type for indexing.
        """
        import os

        self.api_key = api_key or os.environ.get("COHERE_API_KEY")
        if not self.api_key:
            logger.warning(
                "No API key provided for CohereEmbeddingProvider. Ensure COHERE_API_KEY is set in environment."
            )

        self.model_name = model
        self.input_type_search = input_type_search
        self.input_type_index = input_type_index

        self._client = None

    @property
    def client(self):
        """Lazy-load Cohere async client."""
        if self._client is None:
            try:
                import cohere

                self._client = cohere.AsyncClient(self.api_key)
            except ImportError:
                raise ImportError("cohere is required. Install with: pip install cohere")
        return self._client

    @property
    def dimension(self) -> int:
        return self.DENSE_DIM

    @property
    def supports_sparse(self) -> bool:
        return False

    async def embed_query(self, text: str) -> EmbeddingOutput:
        """Embed search query (async)."""
        response = await self.client.embed(
            texts=[text],
            model=self.model_name,
            input_type=self.input_type_search,
            embedding_types=["float"],
        )
        return EmbeddingOutput(dense_vector=response.embeddings.float[0])

    async def embed_texts(self, texts: List[str]) -> List[EmbeddingOutput]:
        """Embed multiple documents (async)."""
        if not texts:
            return []

        response = await self.client.embed(
            texts=texts,
            model=self.model_name,
            input_type=self.input_type_index,
            embedding_types=["float"],
        )

        return [EmbeddingOutput(dense_vector=emb) for emb in response.embeddings.float]
