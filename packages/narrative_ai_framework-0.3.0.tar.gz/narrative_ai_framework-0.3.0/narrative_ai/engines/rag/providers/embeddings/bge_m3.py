"""
BGE-M3 Embedding Provider.

Provides state-of-the-art multilingual (Arabic/English) embeddings
with native dense + sparse output for hybrid search.
"""

import asyncio
import logging
from typing import List

from ..base import EmbeddingProvider, EmbeddingOutput

logger = logging.getLogger(__name__)


class BGEM3EmbeddingProvider(EmbeddingProvider):
    """
    BGE-M3 embedding provider for multilingual hybrid search.

    Features:
    - Dense embeddings (1024 dimensions)
    - Sparse embeddings (for BM25-like keyword matching)
    - Optimized for Arabic and English
    - Local execution via FlagEmbedding

    Example:
        provider = BGEM3EmbeddingProvider()
        output = provider.embed_query("What is the weather today?")
        print(output.dense_vector)  # 1024-dim dense
        print(output.sparse_vector)  # {token_id: weight}
    """

    # Model constants
    MODEL_NAME = "BAAI/bge-m3"
    DENSE_DIM = 1024

    def __init__(
        self,
        model_name: str = MODEL_NAME,
        device: str = "cpu",
        max_length: int = 8192,
        batch_size: int = 32,
        use_fp16: bool = False,
    ):
        """
        Initialize the BGE-M3 provider.

        Args:
            model_name: HuggingFace model name.
            device: Device to run on (cpu, cuda, mps).
            max_length: Maximum token length.
            batch_size: Batch size for embedding.
            use_fp16: Use half precision (faster on GPU).
        """
        self.model_name = model_name
        self.device = device
        self.max_length = max_length
        self.batch_size = batch_size
        self.use_fp16 = use_fp16

        self._model = None
        logger.info("BGEM3Provider initialized (lazy loading on first use)")

    @property
    def model(self):
        """Lazy-load the model."""
        if self._model is None:
            self._load_model()
        return self._model

    def _load_model(self):
        """Load the BGE-M3 model."""
        try:
            from FlagEmbedding import BGEM3FlagModel

            logger.info(f"Loading BGE-M3 model: {self.model_name}")
            self._model = BGEM3FlagModel(
                self.model_name,
                use_fp16=self.use_fp16,
                device=self.device,
            )
            logger.info(f"BGE-M3 model loaded successfully on {self.device}")

        except ImportError:
            raise ImportError("FlagEmbedding is required for BGE-M3. Install with: pip install FlagEmbedding")

    @property
    def dimension(self) -> int:
        """Return embedding dimension (forces model load)."""
        # Ensure model is loaded to detect correct dimension
        loaded_model = self.model

        if hasattr(loaded_model, "model"):
            return loaded_model.model.config.hidden_size

        return self.DENSE_DIM

    @property
    def supports_sparse(self) -> bool:
        """BGE-M3 supports sparse vectors."""
        return True

    async def embed_query(self, text: str) -> EmbeddingOutput:
        """
        Embed a single query.

        Args:
            text: Query text.

        Returns:
            EmbeddingOutput with dense and sparse vectors.
        """
        results = await asyncio.to_thread(self._embed_batch, [text])
        return results[0]

    async def embed_texts(self, texts: List[str]) -> List[EmbeddingOutput]:
        """
        Embed multiple texts in batch.

        Args:
            texts: List of texts.

        Returns:
            List of EmbeddingOutput objects.
        """
        if not texts:
            return []

        # Process in batches
        all_outputs = []
        for i in range(0, len(texts), self.batch_size):
            batch = texts[i : i + self.batch_size]
            outputs = await asyncio.to_thread(self._embed_batch, batch)
            all_outputs.extend(outputs)

        return all_outputs

    def _embed_batch(self, texts: List[str]) -> List[EmbeddingOutput]:
        """
        Internal batch embedding.

        Uses BGE-M3's encode method which returns both dense and sparse.
        """
        # Encode with both dense and sparse outputs
        embeddings = self.model.encode(
            texts,
            return_dense=True,
            return_sparse=True,
            return_colbert_vecs=False,  # ColBERT not needed for our use case
            max_length=self.max_length,
        )

        outputs = []
        for i in range(len(texts)):
            # Dense vector
            dense = embeddings["dense_vecs"][i].tolist()

            # Sparse vector (convert to dict format)
            sparse_dict = None
            if "lexical_weights" in embeddings:
                sparse_weights = embeddings["lexical_weights"][i]
                # Convert sparse representation to dict
                if isinstance(sparse_weights, dict):
                    sparse_dict = {int(k): float(v) for k, v in sparse_weights.items()}
                elif hasattr(sparse_weights, "items"):
                    sparse_dict = {int(k): float(v) for k, v in sparse_weights.items()}

            outputs.append(
                EmbeddingOutput(
                    dense_vector=dense,
                    sparse_vector=sparse_dict,
                )
            )

        return outputs


class BGEM3LiteProvider(EmbeddingProvider):
    """
    Lightweight BGE-M3 provider using sentence-transformers.

    This is a fallback if FlagEmbedding is not available.
    Note: This only provides dense embeddings, not sparse.
    """

    MODEL_NAME = "BAAI/bge-m3"
    DENSE_DIM = 1024

    def __init__(
        self,
        model_name: str = MODEL_NAME,
        device: str = "cpu",
    ):
        self.model_name = model_name
        self.device = device
        self._model = None

    @property
    def model(self):
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer

                self._model = SentenceTransformer(self.model_name, device=self.device)
                logger.info(f"SentenceTransformer BGE-M3 loaded on {self.device}")
            except ImportError:
                raise ImportError("sentence-transformers is required. Install with: pip install sentence-transformers")
        return self._model

    @property
    def dimension(self) -> int:
        """Return embedding dimension (forces model load)."""
        return self.model.get_sentence_embedding_dimension()

    @property
    def supports_sparse(self) -> bool:
        return False  # sentence-transformers doesn't output sparse

    async def embed_query(self, text: str) -> EmbeddingOutput:
        embedding = await asyncio.to_thread(self.model.encode, text, convert_to_numpy=True)
        return EmbeddingOutput(dense_vector=embedding.tolist())

    async def embed_texts(self, texts: List[str]) -> List[EmbeddingOutput]:
        embeddings = await asyncio.to_thread(self.model.encode, texts, convert_to_numpy=True)
        return [EmbeddingOutput(dense_vector=emb.tolist()) for emb in embeddings]
