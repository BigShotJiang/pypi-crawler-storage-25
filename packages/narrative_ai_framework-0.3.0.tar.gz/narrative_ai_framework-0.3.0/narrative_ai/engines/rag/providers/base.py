"""
Provider base classes for the Memory Framework.

Defines abstract interfaces for vector stores and embedding models,
enabling easy swapping of implementations via configuration.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from dataclasses import dataclass

from ..types import MemoryChunk, RetrievalResult


@dataclass
class EmbeddingOutput:
    """Output from an embedding model."""

    dense_vector: List[float]
    sparse_vector: Optional[Dict[str, float]] = None  # For hybrid models like BGE-M3


class EmbeddingProvider(ABC):
    """
    Abstract base class for embedding providers.

    Implementations should handle both single queries and batch operations
    for efficient indexing.
    """

    @abstractmethod
    async def embed_query(self, text: str) -> EmbeddingOutput:
        """
        Embed a single query string (async).

        Args:
            text: The query text to embed.

        Returns:
            EmbeddingOutput with dense (and optionally sparse) vectors.
        """
        pass

    @abstractmethod
    async def embed_texts(self, texts: List[str]) -> List[EmbeddingOutput]:
        """
        Embed multiple texts in batch (async).

        Args:
            texts: List of texts to embed.

        Returns:
            List of EmbeddingOutput objects.
        """
        pass

    @property
    @abstractmethod
    def dimension(self) -> int:
        """Return the embedding dimension."""
        pass

    @property
    def supports_sparse(self) -> bool:
        """Whether this provider supports sparse vectors (hybrid search)."""
        return False


class VectorStoreProvider(ABC):
    """
    Abstract base class for vector store providers.

    Implementations connect to the centralized infrastructure layer
    (e.g., framework/infrastructure/vector/qdrant_store.py).
    """

    @abstractmethod
    def upsert(
        self,
        chunks: List[MemoryChunk],
        embeddings: List[EmbeddingOutput],
    ) -> bool:
        """
        Insert or update chunks with their embeddings.

        Args:
            chunks: List of memory chunks to store.
            embeddings: Corresponding embeddings for each chunk.

        Returns:
            True if successful.
        """
        pass

    @abstractmethod
    def search(
        self,
        query_embedding: EmbeddingOutput,
        top_k: int = 10,
        filters: Optional[Dict[str, Any]] = None,
    ) -> List[RetrievalResult]:
        """
        Search for similar chunks.

        Args:
            query_embedding: The query vector(s).
            top_k: Number of results to return.
            filters: Optional metadata filters.

        Returns:
            List of RetrievalResult objects sorted by score.
        """
        pass

    @abstractmethod
    def delete(self, doc_id: str) -> bool:
        """
        Delete all chunks belonging to a document.

        Args:
            doc_id: The document ID to delete.

        Returns:
            True if successful.
        """
        pass

    @abstractmethod
    def collection_exists(self) -> bool:
        """Check if the collection exists."""
        pass

    @abstractmethod
    def create_collection(self, dimension: int) -> bool:
        """Create the collection if it doesn't exist."""
        pass


class RerankerProvider(ABC):
    """
    Abstract base class for reranker providers.

    Rerankers provide a second-stage ranking using cross-encoders
    for higher accuracy.
    """

    @abstractmethod
    async def rerank(
        self,
        query: str,
        texts: List[str],
    ) -> List[float]:
        """
        Rerank the results based on query-document relevance (async).

        Args:
            query: The original query string.
            texts: List of strings to rerank.

        Returns:
            List of relevance scores.
        """
        pass
