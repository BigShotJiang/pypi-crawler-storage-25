"""
Cohere Reranker Provider.

Uses Cohere's Rerank API to provide high-precision ranking for retrieval results.

NOTE: This provider is Pure Async for production performance.
"""

import logging
from typing import List, Optional

from ..base import RerankerProvider

logger = logging.getLogger(__name__)


class CohereRerankerProvider(RerankerProvider):
    """
    Cohere implementation of the reranker provider.

    Uses 'rerank-multilingual-v3.0' for state-of-the-art results.

    All methods are async for production performance.
    """

    MODEL_NAME = "rerank-multilingual-v3.0"

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = MODEL_NAME,
    ):
        """
        Initialize Cohere reranker.

        Args:
            api_key: Cohere API Key. Loads from COHERE_API_KEY if not provided.
            model: Model name to use.
        """
        import os

        self.api_key = api_key or os.environ.get("COHERE_API_KEY")
        self.model_name = model

        self._client = None

    @property
    def client(self):
        """Lazy-load Cohere async client."""
        if self._client is None:
            try:
                import cohere

                self._client = cohere.AsyncClient(self.api_key)
            except ImportError:
                raise ImportError("cohere is required. Install with: pip install cohere")
        return self._client

    async def rerank(self, query: str, texts: List[str]) -> List[float]:
        """
        Rerank texts using Cohere API (async).

        Returns:
            List of relevance scores.
        """
        if not texts:
            return []

        response = await self.client.rerank(
            query=query,
            documents=texts,
            top_n=len(texts),
            model=self.model_name,
        )

        # Cohere returns results in order, we need to map them back to original indices
        scores = [0.0] * len(texts)
        for result in response.results:
            scores[result.index] = result.relevance_score

        return scores
