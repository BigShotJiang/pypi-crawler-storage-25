"""
BGE Reranker Provider.

Uses the BGE-Reranker model to improve retrieval precision.
"""

import asyncio
import logging
from typing import List

from ..base import RerankerProvider

logger = logging.getLogger(__name__)


class BGERerankerProvider(RerankerProvider):
    """
    BGE-Reranker implementation.

    Scores (query, passage) pairs to re-order retrieval results.
    """

    def __init__(
        self,
        model_name: str = "BAAI/bge-reranker-base",
        device: str = "cpu",
    ):
        """
        Initialize BGE Reranker.

        Args:
            model_name: Model name on Hugging Face.
            device: Device to run on (cpu, cuda, mps).
        """
        self.model_name = model_name
        self.device = device
        self._model = None
        self._tokenizer = None

    @property
    def model(self):
        """Lazy-load model."""
        if self._model is None:
            try:
                from sentence_transformers import CrossEncoder

                self._model = CrossEncoder(self.model_name, device=self.device)
            except ImportError:
                raise ImportError("sentence-transformers is required. Install with: pip install sentence-transformers")
        return self._model

    async def rerank(self, query: str, texts: List[str]) -> List[float]:
        """
        Rerank a list of texts against a query.

        Returns:
            List of relevance scores.
        """
        if not texts:
            return []

        # CrossEncoder expects pairs of (query, text)
        pairs = [(query, text) for text in texts]
        scores = await asyncio.to_thread(self.model.predict, pairs)

        return scores.tolist()
