import asyncio
from typing import List, Optional, Dict, Any, Union, AsyncGenerator
from narrative_ai.engines.rag.memory_manager import MemoryManager
from narrative_ai.engines.rag.text_splitter import ArabicAwareTextSplitter, TextChunk, detect_language
from narrative_ai.engines.rag.types import IndexingResult, RetrievalResult, RichContext
from narrative_ai.engines.rag.cache import (
    normalize_query,
    get_query_cache,
    get_rag_context_cache,
    get_rag_response_cache,
)
from narrative_ai.engines.input_processor.types import StructuredDocument

_default_manager: Optional[MemoryManager] = None

def get_manager() -> MemoryManager:
    """Get or create the default global MemoryManager instance."""
    global _default_manager
    if _default_manager is None:
        _default_manager = MemoryManager()
    return _default_manager

def set_api_key(api_key: str, provider: str = "openai"):
    """
    Dynamically set the API key for a RAG provider (Embedding/Reranker).
    
    Args:
        api_key: The secret API key string.
        provider: Provider name (e.g., 'openai', 'cohere').
    """
    import os
    env_map = {
        "openai": "OPENAI_API_KEY",
        "cohere": "COHERE_API_KEY"
    }
    env_var = env_map.get(provider.lower())
    if env_var:
        os.environ[env_var] = api_key

async def remember(
    document: StructuredDocument,
    doc_id: Optional[str] = None,
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
) -> IndexingResult:
    """Index a document into memory."""
    return await get_manager().remember(
        document=document,
        doc_id=doc_id,
        user_id=user_id,
        tenant_id=tenant_id,
        correlation_id=correlation_id
    )

async def recall(
    query: str,
    top_k: Optional[int] = None,
    filters: Optional[Dict[str, Any]] = None,
    return_context: bool = True,
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    require_user_scope: bool = False,
) -> Union[RichContext, List[RetrievalResult]]:
    """Retrieve relevant context for a query."""
    return await get_manager().recall(
        query=query,
        top_k=top_k,
        filters=filters,
        return_context=return_context,
        user_id=user_id,
        tenant_id=tenant_id,
        correlation_id=correlation_id,
        require_user_scope=require_user_scope
    )

async def search(
    query: str,
    **kwargs
) -> List[RetrievalResult]:
    """Perform raw search and return ranked results with metadata."""
    kwargs["return_context"] = False
    results = await recall(
        query=query,
        **kwargs
    )
    return results

async def forget(doc_id: str, user_id: Optional[str] = None) -> bool:
    """Remove a document from memory."""
    return await get_manager().forget(doc_id, user_id=user_id)

async def get_stats() -> Dict[str, Any]:
    """Get indexing statistics from the vector store."""
    manager = get_manager()
    count = await manager.vector_store.count()
    return {
        "total_chunks": count,
        "is_healthy": manager.vector_store is not None and manager.embedding_provider is not None,
        "collection": manager.config.qdrant.collection
    }

def detect_lang(text: str) -> str:
    """Detect if text is primarily Arabic ('ar') or English ('en')."""
    return detect_language(text)

def normalize(text: str) -> str:
    """Normalize text for consistent cache keys and search."""
    return normalize_query(text)

def clear_cache():
    """Clear all RAG-related caches (query, context, and responses)."""
    get_query_cache().clear()
    get_rag_context_cache().clear()
    get_rag_response_cache().clear()

def get_cache_stats() -> Dict[str, Any]:
    """Get aggregated statistics from all RAG caches."""
    return {
        "query_cache": get_query_cache().get_stats(),
        "context_cache": get_rag_context_cache().get_stats(),
        "response_cache": get_rag_response_cache().get_stats(),
    }

def invalidate_user_cache(user_id: str):
    """Remove all cached RAG contents for a specific user."""
    get_rag_context_cache().invalidate_user(user_id)
    get_rag_response_cache().invalidate_user(user_id)

def extract_keywords(text: str, lang: Optional[str] = None) -> List[str]:
    """Extract significant keywords from text (useful for building custom search)."""
    from narrative_ai.engines.rag.query_processor import get_query_processor
    qp = get_query_processor()
    target_lang = lang or detect_language(text)
    return qp._extract_keywords(text, target_lang)

def parse_filters(query: str) -> Dict[str, Any]:
    """Parse natural language to extract metadata filters (e.g., 'page 5')."""
    from narrative_ai.engines.rag.query_processor import get_query_processor
    return get_query_processor()._extract_filters(query)

class RAGClient:
    """
    A session-based client for the RAG engine.
    Stores common parameters like user_id, tenant_id, and search preferences.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        top_k: int = 5,
        api_key: Optional[str] = None,
        provider: str = "openai",
        require_user_scope: bool = False,
        correlation_id: Optional[str] = None,
    ):
        """
        Initialize the RAG client with default context.

        Args:
            user_id: Default user ID for isolation and audit.
            tenant_id: Default tenant ID for multi-tenancy.
            top_k: Default number of results to retrieve.
            api_key: Optional API key for the session.
            provider: Provider for the API key (e.g., 'openai').
            require_user_scope: Whether to enforce user_id presence.
            correlation_id: Default tracking ID for audit trails.
        """
        if api_key:
            set_api_key(api_key, provider)

        self.defaults = {
            "user_id": user_id,
            "tenant_id": tenant_id,
            "top_k": top_k,
            "require_user_scope": require_user_scope,
            "correlation_id": correlation_id,
        }

    async def remember(self, document: StructuredDocument, **kwargs) -> IndexingResult:
        """Index a document using client defaults."""
        final_args = {**self.defaults, **kwargs, "document": document}
        # Filter out recall-specific args if they leaked in
        final_args.pop("top_k", None)
        final_args.pop("require_user_scope", None)
        return await remember(**final_args)

    async def recall(self, query: str, **kwargs) -> Union[RichContext, List[RetrievalResult]]:
        """Retrieve context using client defaults."""
        final_args = {**self.defaults, **kwargs, "query": query}
        return await recall(**final_args)

    async def search(self, query: str, **kwargs) -> List[RetrievalResult]:
        """Perform raw search using client defaults."""
        final_args = {**self.defaults, **kwargs, "query": query}
        return await search(**final_args)

    async def forget(self, doc_id: str, **kwargs) -> bool:
        """Remove a document using client defaults."""
        user_id = kwargs.get("user_id") or self.defaults.get("user_id")
        return await forget(doc_id=doc_id, user_id=user_id)

    async def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics."""
        return await get_stats()

    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return get_cache_stats()

    def invalidate_cache(self):
        """Invalidate cache for the current user."""
        if self.defaults.get("user_id"):
            invalidate_user_cache(self.defaults["user_id"])
        else:
            clear_cache()

    def extract_keywords(self, text: str, lang: Optional[str] = None) -> List[str]:
        """Extract keywords using client-provided logic."""
        return extract_keywords(text, lang=lang)

    def parse_filters(self, query: str) -> Dict[str, Any]:
        """Parse filters from query."""
        return parse_filters(query)

    def detect_lang(self, text: str) -> str:
        """Helper to detect language."""
        return detect_lang(text)

    def normalize(self, text: str) -> str:
        """Helper to normalize text."""
        return normalize(text)

    def clear_cache(self):
        """Clear all RAG caches."""
        clear_cache()

def chunk(
    text: str,
    doc_id: str = "temp",
    block_id: str = "temp",
    chunk_size: int = 200,
    overlap: int = 30,
    modality: str = "text",
    page: Optional[int] = None,
    media_ref: Optional[str] = None,
    timestamp: Optional[float] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> List[TextChunk]:
    """Split text into hierarchical chunks using Arabic-aware logic."""
    splitter = ArabicAwareTextSplitter(
        child_chunk_size=chunk_size,
        child_overlap=overlap
    )
    return splitter.split_with_hierarchy(
        text=text,
        doc_id=doc_id,
        block_id=block_id,
        modality=modality,
        page=page,
        media_ref=media_ref,
        timestamp=timestamp,
        extra=extra
    )

async def chunk_stream(
    text: str,
    doc_id: str = "temp",
    block_id: str = "temp",
    chunk_size: int = 200,
    overlap: int = 30,
    modality: str = "text",
    page: Optional[int] = None,
    media_ref: Optional[str] = None,
    timestamp: Optional[float] = None,
    extra: Optional[Dict[str, Any]] = None,
) -> AsyncGenerator[TextChunk, None]:
    """Split text into hierarchical chunks using streaming (memory-efficient)."""
    splitter = ArabicAwareTextSplitter(
        child_chunk_size=chunk_size,
        child_overlap=overlap
    )
    async for c in splitter.split_with_hierarchy_streaming(
        text=text,
        doc_id=doc_id,
        block_id=block_id,
        modality=modality,
        page=page,
        media_ref=media_ref,
        timestamp=timestamp,
        extra=extra
    ):
        yield c
