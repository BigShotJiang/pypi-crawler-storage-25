"""
Memory Manager - Main Entry Point for the Memory Framework.

Orchestrates the entire memory pipeline:
- remember(): Ingest documents into memory
- recall(): Retrieve relevant context
"""

import logging
import uuid
from dataclasses import asdict
from datetime import datetime
from typing import List, Optional, Dict, Any, Union

from .config import get_config, MemoryConfig

# Optional security integration - engines run exactly as today when unavailable
try:
    from narrative_ai.security.engine_integration import (
        check_rate_limit_for_engine,
        log_audit_for_engine,
    )
    from narrative_ai.security.rate_limiting import EndpointCosts, RateLimiter
    from narrative_ai.security.audit_trail import AuditLogger, ActionType
    from narrative_ai.security.input_validation import validate_text
    from narrative_ai.security.error_handling import SecureErrorHandler

    _SECURITY_AVAILABLE = True
except ImportError:
    validate_text = None
    SecureErrorHandler = None
    _SECURITY_AVAILABLE = False

if not _SECURITY_AVAILABLE:
    logging.getLogger(__name__).warning("Security layer not available - RAG running without security integration")
from .types import (
    MemoryChunk,
    RetrievalResult,
    RichContext,
    IndexingResult,
)
from .hybrid_search import HybridSearch
from .context_builder import ContextBuilder
from .query_processor import get_query_processor
from .cache import get_query_cache, get_rag_context_cache
from .providers.base import EmbeddingProvider
from .strategies import DomainStrategy, get_strategy

# Import infrastructure
from ...infrastructure.vector.base_vector_store import RagVectorStore, VectorPayload
from ...infrastructure.vector.qdrant_store import QdrantStore

# Import StructuredDocument from input processor
from ..input_processor.types import StructuredDocument, ContentBlock
from .text_splitter import ArabicAwareTextSplitter

logger = logging.getLogger(__name__)


def _serialize_results_for_cache(results: List[RetrievalResult]) -> List[Dict[str, Any]]:
    """Serialize RetrievalResult list to cache-safe dicts (timestamp -> isoformat)."""
    out: List[Dict[str, Any]] = []
    for r in results:
        d = asdict(r)
        if d.get("timestamp") is not None:
            d["timestamp"] = d["timestamp"].isoformat()
        out.append(d)
    return out


def _deserialize_results_from_cache(data: List[Dict[str, Any]]) -> List[RetrievalResult]:
    """Deserialize cache dicts back to RetrievalResult list."""
    out: List[RetrievalResult] = []
    for d in data:
        d = dict(d)
        if d.get("timestamp") is not None:
            if isinstance(d["timestamp"], str):
                d["timestamp"] = datetime.fromisoformat(d["timestamp"])
        out.append(RetrievalResult(**d))
    return out


class MemoryManager:
    """
    Main entry point for the Multimodal Memory Framework.

    Provides two core operations:
    - remember(): Index a StructuredDocument into memory (async)
    - recall(): Retrieve relevant context for a query (async)

    NOTE: All methods are async for production performance.

    Example:
        manager = MemoryManager()

        # Index a document
        doc = await input_processor.process("path/to/file.pdf")
        await manager.remember(doc)

        # Retrieve context
        context = await manager.recall("What did the doctor say?")
    """

    def __init__(
        self,
        config: Optional[MemoryConfig] = None,
        vector_store: Optional[RagVectorStore] = None,
        embedding_provider: Optional[EmbeddingProvider] = None,
        reranker_provider: Optional[Any] = None,
        strategy: Optional[DomainStrategy] = None,
    ):
        """
        Initialize the Memory Manager.

        Args:
            config: Configuration object. Uses default if not provided.
            vector_store: Vector store implementation. Uses Qdrant if not provided.
            embedding_provider: Embedding provider. Must be provided or set later.
            reranker_provider: Optional reranker provider.
            strategy: Domain strategy. Uses config default if not provided.
        """
        self.config = config or get_config()

        # Initialize strategy first as it might be needed by providers
        self.strategy = strategy or get_strategy(self.config.strategy)

        # Initialize vector store
        if vector_store:
            self.vector_store = vector_store
        else:
            self.vector_store = QdrantStore(
                host=self.config.qdrant.host,
                port=self.config.qdrant.port,
                collection_name=self.config.qdrant.collection,
                prefer_grpc=self.config.qdrant.prefer_grpc,
            )

        # Dynamically load embedding provider if not passed
        from .providers import get_embedding_provider, get_reranker_provider

        if embedding_provider:
            self.embedding_provider = embedding_provider
        else:
            logger.info(f"Loading embedding provider: {self.config.providers.embedding}")
            self.embedding_provider = get_embedding_provider(
                self.config.providers.embedding,
                # Pass extra settings from config
                model=self.config.embedding.model,
                device=self.config.embedding.device,
            )

        # Dynamically load reranker provider if not passed
        if reranker_provider is not None:
            self.reranker_provider = reranker_provider
        else:
            logger.info(f"Loading reranker provider: {self.config.providers.reranker}")
            try:
                self.reranker_provider = get_reranker_provider(self.config.providers.reranker)
            except (ImportError, ValueError) as e:
                logger.warning(
                    f"Could not load reranker provider '{self.config.providers.reranker}': {e}. Continuing without reranker."
                )
                self.reranker_provider = None

        # Initialize components (lazy)
        self._search_engine = None
        self._context_builder = None

        logger.info(f"MemoryManager initialized with strategy: {self.strategy.name}")

        # Initialize text splitter
        self.text_splitter = ArabicAwareTextSplitter(
            child_chunk_size=self.config.chunking.chunk_size,
            parent_window_size=self.config.chunking.chunk_size * 4,
            child_overlap=self.config.chunking.chunk_overlap,
        )

        # Initialize query cache and query processor
        self.query_cache = get_query_cache(max_size=1000, ttl_seconds=3600)
        self.query_processor = get_query_processor()

        # Security components (lazy-init on first use)
        self._rate_limiter = None
        self._audit_logger = None
        self._error_handler = None
        self._security_initialized = False

    def set_embedding_provider(self, provider: EmbeddingProvider) -> None:
        """Set the embedding provider."""
        self.embedding_provider = provider
        self._search_engine = None  # Reset search engine

    def _ensure_security_initialized(self) -> None:
        """Lazy-init rate limiter and audit logger when security is enabled."""
        if not _SECURITY_AVAILABLE or self._security_initialized:
            return
        if not (
            getattr(self.config.integration, "enable_rate_limiting", False)
            or getattr(self.config.integration, "enable_audit_logging", False)
            or getattr(self.config.integration, "enable_error_handling", False)
        ):
            self._security_initialized = True
            return
        try:
            import os

            is_production = os.getenv("ENV", "").lower() == "production"
            skip_rate_limit = not is_production and os.getenv("VOICE_DEV_SKIP_RATE_LIMIT", "").strip() == "1"
            if getattr(self.config.integration, "enable_rate_limiting", False) and RateLimiter and not skip_rate_limit:
                self._rate_limiter = RateLimiter()
            if getattr(self.config.integration, "enable_audit_logging", False) and AuditLogger:
                audit_db_url = os.getenv("AUDIT_DATABASE_URL") or os.getenv("DATABASE_URL")
                if audit_db_url:
                    self._audit_logger = AuditLogger(database_url=audit_db_url)
                else:
                    logger.warning("Audit logging enabled but AUDIT_DATABASE_URL/DATABASE_URL not set")
            if getattr(self.config.integration, "enable_error_handling", False) and SecureErrorHandler:
                try:
                    self._error_handler = SecureErrorHandler()
                except Exception as e:
                    logger.warning("Secure error handler initialization failed: %s", e)
        except Exception as e:
            logger.warning("Security initialization failed: %s", e)
        self._security_initialized = True

    @property
    def search_engine(self) -> HybridSearch:
        """Lazy-load search engine."""
        if self._search_engine is None:
            if not self.embedding_provider:
                raise ValueError("Embedding provider must be set before searching")
            self._search_engine = HybridSearch(
                vector_store=self.vector_store,
                embedding_provider=self.embedding_provider,
                reranker_provider=self.reranker_provider,
                strategy=self.strategy,
            )
        return self._search_engine

    @property
    def context_builder(self) -> ContextBuilder:
        """Lazy-load context builder."""
        if self._context_builder is None:
            self._context_builder = ContextBuilder(strategy=self.strategy)
        return self._context_builder

    async def remember(
        self,
        document: StructuredDocument,
        doc_id: Optional[str] = None,
        user_id: Optional[Any] = None,
        tenant_id: Optional[Any] = None,
        correlation_id: Optional[str] = None,
    ) -> IndexingResult:
        """
        Index a StructuredDocument into memory (async).

        This is the ingestion entry point. It:
        1. Extracts content blocks from the document
        2. Chunks text content while preserving metadata
        3. Generates embeddings (dense + sparse)
        4. Stores in the vector database

        Args:
            document: StructuredDocument from the InputProcessor.
            doc_id: Optional document ID. Generated if not provided.
            user_id: Optional user ID for rate limiting and audit.
            tenant_id: Optional tenant ID for rate limiting and audit.
            correlation_id: Optional correlation ID for audit traceability.

        Returns:
            IndexingResult with status and chunk count.
        """
        if not self.embedding_provider:
            raise ValueError("Embedding provider must be set before indexing")

        # Security: rate limit and audit (when enabled)
        if _SECURITY_AVAILABLE:
            self._ensure_security_initialized()
            if getattr(self.config.integration, "enable_rate_limiting", False) and self._rate_limiter:
                check_rate_limit_for_engine(
                    self._rate_limiter,
                    user_id,
                    tenant_id,
                    EndpointCosts.RAG_INGEST,
                    "anon.engine.rag",
                    user_tier_callback=getattr(self.config.integration, "user_tier_callback", None),
                )

        doc_id = doc_id or document.doc_id or str(uuid.uuid4())
        errors = []

        try:
            # 1. Ensure collection exists
            if not await self.vector_store.collection_exists():
                dimension = self.embedding_provider.dimension
                await self.vector_store.create_collection(
                    dense_dimension=dimension,
                    sparse_enabled=self.embedding_provider.supports_sparse,
                )

            # 2. Stream blocks and index in embedding batches to reduce peak memory usage.
            batch_size = self.config.embedding.batch_size
            chunk_config = self.config.chunking
            chunks_indexed = 0
            extracted_any = False

            for block in document.content_blocks:
                block_chunks = await self._chunk_content_block(
                    block=block,
                    doc_id=doc_id,
                    chunk_size=chunk_config.chunk_size,
                    chunk_overlap=chunk_config.chunk_overlap,
                )
                if not block_chunks:
                    continue

                extracted_any = True
                logger.debug(f"Extracted {len(block_chunks)} chunks from block {block.block_id}")

                for i in range(0, len(block_chunks), batch_size):
                    batch_chunks = block_chunks[i : i + batch_size]
                    texts = [chunk.text for chunk in batch_chunks]
                    embeddings = await self.embedding_provider.embed_texts(texts)

                    ids = [chunk.chunk_id for chunk in batch_chunks]
                    dense_vectors = [embedding.dense_vector for embedding in embeddings]
                    sparse_vectors = [embedding.sparse_vector for embedding in embeddings]
                    payloads = [
                        VectorPayload(
                            chunk_id=chunk.chunk_id,
                            doc_id=chunk.doc_id,
                            block_id=chunk.block_id,
                            text=chunk.text,
                            modality=chunk.modality,
                            timestamp=chunk.timestamp.timestamp() if chunk.timestamp else None,
                            page=chunk.page,
                            media_ref=chunk.media_ref,
                            extra=chunk.extra,
                            user_id=str(user_id) if user_id is not None else None,
                        )
                        for chunk in batch_chunks
                    ]

                    success = await self.vector_store.upsert(
                        ids=ids,
                        dense_vectors=dense_vectors,
                        payloads=payloads,
                        sparse_vectors=sparse_vectors if self.embedding_provider.supports_sparse else None,
                    )
                    if success:
                        chunks_indexed += len(batch_chunks)
                    else:
                        errors.append(f"Vector store upsert failed for block {block.block_id} batch {i // batch_size}")

            if not extracted_any:
                logger.warning(f"No chunks extracted from document: {doc_id}")
                if (
                    _SECURITY_AVAILABLE
                    and getattr(self.config.integration, "enable_audit_logging", False)
                    and self._audit_logger
                ):
                    log_audit_for_engine(
                        self._audit_logger,
                        user_id,
                        tenant_id,
                        ActionType.RAG_REMEMBER,
                        "rag_document",
                        "success",
                        {"doc_id": doc_id, "chunks_indexed": 0, "note": "no content"},
                        resource_id=None,
                        engine_namespace="anon.engine.rag",
                        correlation_id=correlation_id,
                    )
                return IndexingResult(
                    doc_id=doc_id,
                    chunks_indexed=0,
                    success=True,
                    errors=["No content to index"],
                )

            overall_success = len(errors) == 0
            if chunks_indexed > 0:
                logger.info(f"Indexed {chunks_indexed} chunks for document: {doc_id}")
            if errors:
                logger.warning(f"Indexing completed with {len(errors)} errors for document: {doc_id}")

            if (
                _SECURITY_AVAILABLE
                and getattr(self.config.integration, "enable_audit_logging", False)
                and self._audit_logger
            ):
                log_audit_for_engine(
                    self._audit_logger,
                    user_id,
                    tenant_id,
                    ActionType.RAG_REMEMBER,
                    "rag_document",
                    "success" if overall_success else "failure",
                    {"doc_id": doc_id, "chunks_indexed": chunks_indexed, "errors": errors[:5]},
                    resource_id=None,
                    engine_namespace="anon.engine.rag",
                    correlation_id=correlation_id,
                )

            return IndexingResult(
                doc_id=doc_id,
                chunks_indexed=chunks_indexed,
                success=overall_success,
                errors=errors,
            )

        except Exception as e:
            logger.error(f"Failed to index document: {e}")
            if (
                _SECURITY_AVAILABLE
                and getattr(self.config.integration, "enable_audit_logging", False)
                and self._audit_logger
            ):
                log_audit_for_engine(
                    self._audit_logger,
                    user_id,
                    tenant_id,
                    ActionType.RAG_REMEMBER,
                    "rag_document",
                    "failure",
                    {"doc_id": doc_id or "unknown", "error": str(e), "type": type(e).__name__},
                    resource_id=None,
                    engine_namespace="anon.engine.rag",
                    correlation_id=correlation_id,
                )
            if self._error_handler:
                try:
                    self._error_handler.handle_error(
                        e, user_id, tenant_id, {"doc_id": doc_id, "correlation_id": correlation_id}
                    )
                except Exception as handler_error:
                    logger.warning("Error handler failed: %s", handler_error)
            return IndexingResult(
                doc_id=doc_id,
                chunks_indexed=0,
                success=False,
                errors=[str(e)],
            )

    async def recall(
        self,
        query: str,
        top_k: Optional[int] = None,
        filters: Optional[Dict[str, Any]] = None,
        return_context: bool = True,
        user_id: Optional[Any] = None,
        tenant_id: Optional[Any] = None,
        correlation_id: Optional[str] = None,
        require_user_scope: bool = False,
    ) -> Union[RichContext, List[RetrievalResult]]:
        """
        Retrieve relevant context for a query (async).

        Args:
            query: Natural language query.
            top_k: Number of results to retrieve.
            filters: Optional metadata filters (e.g., {"modality": "image"}).
            return_context: If True, returns formatted RichContext. Otherwise, raw results.
            user_id: Optional user ID for rate limiting and audit.
            tenant_id: Optional tenant ID for rate limiting and audit.
            correlation_id: Optional correlation ID for audit traceability.
            require_user_scope: When True, user_id must be provided to enforce strict user isolation.

        Returns:
            RichContext or List[RetrievalResult] depending on return_context.
        """
        if _SECURITY_AVAILABLE:
            self._ensure_security_initialized()

        try:
            # Security: validate, rate limit (when enabled) - inside try so validation/rate-limit failures are audited
            if _SECURITY_AVAILABLE:
                if getattr(self.config.integration, "enable_input_validation", False) and validate_text:
                    validate_text(query, max_length=10000)
                if getattr(self.config.integration, "enable_rate_limiting", False) and self._rate_limiter:
                    check_rate_limit_for_engine(
                        self._rate_limiter,
                        user_id,
                        tenant_id,
                        EndpointCosts.RAG_SEARCH,
                        "anon.engine.rag",
                        user_tier_callback=getattr(self.config.integration, "user_tier_callback", None),
                    )

            # Process query to extract filters and detect language
            processed_query = self.query_processor.process(query)

            # Merge extracted filters with provided filters
            active_filters = dict(filters or {})
            if processed_query.filters:
                active_filters.update(processed_query.filters)

            # SECURITY: Enforce mandatory user_id filter to prevent cross-user leakage
            if user_id is not None:
                active_filters["user_id"] = str(user_id)
            elif require_user_scope:
                raise ValueError("user_id is required for this recall request")
            else:
                logger.warning(
                    "recall() called without user_id — results may include data from all users. "
                    "Pass user_id for strict isolation."
                )

            logger.debug(
                f"Recalling with query: '{query}' | Language: {processed_query.language} | Filters: {active_filters}"
            )

            # Context cache for recall API path: avoid repeated vector search + context build for same query
            top_k_resolved = top_k or getattr(self.config.retrieval, "top_k", 5)
            if return_context:
                context_cache = get_rag_context_cache()
                cached = context_cache.get(
                    query,
                    str(user_id) if user_id else None,
                    top_k=top_k_resolved,
                    filters=active_filters if active_filters else None,
                )
                if cached is not None and getattr(cached, "results", None):
                    source_chunks = _deserialize_results_from_cache(cached.results)
                    media_refs = [r.media_ref for r in source_chunks if r.media_ref]
                    logger.debug("RAG recall cache HIT for query (returning cached context)")
                    if (
                        _SECURITY_AVAILABLE
                        and getattr(self.config.integration, "enable_audit_logging", False)
                        and self._audit_logger
                    ):
                        log_audit_for_engine(
                            self._audit_logger,
                            user_id,
                            tenant_id,
                            ActionType.RAG_RECALL,
                            "rag_recall",
                            "success",
                            {"query_preview": query[:200], "result_count": len(source_chunks), "cache_hit": True},
                            resource_id=None,
                            engine_namespace="anon.engine.rag",
                            correlation_id=correlation_id,
                        )
                    return RichContext(
                        formatted_text=cached.formatted_text,
                        media_references=media_refs,
                        source_chunks=source_chunks,
                        query=query,
                        strategy_used=getattr(cached, "strategy_used", "cached"),
                        total_retrieved=len(source_chunks),
                    )

            # Async search (user_id scopes the embedding cache for isolation)
            results = await self.search_engine.search(
                query, top_k, active_filters, user_id=str(user_id) if user_id else None
            )

            # Security: audit success (when enabled)
            if (
                _SECURITY_AVAILABLE
                and getattr(self.config.integration, "enable_audit_logging", False)
                and self._audit_logger
            ):
                result_count = len(results) if hasattr(results, "__len__") else 0
                log_audit_for_engine(
                    self._audit_logger,
                    user_id,
                    tenant_id,
                    ActionType.RAG_RECALL,
                    "rag_recall",
                    "success",
                    {"query_preview": query[:200], "result_count": result_count},
                    resource_id=None,
                    engine_namespace="anon.engine.rag",
                    correlation_id=correlation_id,
                )

            if return_context:
                context_max_tokens = getattr(self.config.retrieval, "context_max_tokens", None)
                rich = self.context_builder.build(results, query, max_tokens=context_max_tokens)
                # Store in context cache for future identical recall requests (same user, query, top_k, filters)
                try:
                    context_cache = get_rag_context_cache()
                    context_cache.set(
                        query,
                        str(user_id) if user_id else None,
                        top_k=top_k_resolved,
                        filters=active_filters if active_filters else None,
                        formatted_text=rich.formatted_text,
                        source_chunk_ids=[r.chunk_id for r in rich.source_chunks],
                        context_fingerprint="",  # not needed for recall API path
                        results=_serialize_results_for_cache(rich.source_chunks),
                        strategy_used=rich.strategy_used,
                    )
                except Exception as cache_err:
                    logger.debug("Failed to set RAG context cache: %s", cache_err)
                return rich
            return results
        except Exception as e:
            # Security: audit failure and error handler (when enabled) - matches STT/TTS/LLM pattern
            if (
                _SECURITY_AVAILABLE
                and getattr(self.config.integration, "enable_audit_logging", False)
                and self._audit_logger
            ):
                log_audit_for_engine(
                    self._audit_logger,
                    user_id,
                    tenant_id,
                    ActionType.RAG_RECALL,
                    "rag_recall",
                    "failure",
                    {"query_preview": query[:200], "error": str(e), "type": type(e).__name__},
                    resource_id=None,
                    engine_namespace="anon.engine.rag",
                    correlation_id=correlation_id,
                )
            if self._error_handler:
                try:
                    self._error_handler.handle_error(e, user_id, tenant_id, {"correlation_id": correlation_id})
                except Exception as handler_error:
                    logger.warning("Error handler failed: %s", handler_error)
            raise

    async def forget(self, doc_id: str, user_id: Optional[str] = None) -> bool:
        """
        Remove a document from memory.

        Args:
            doc_id: Document ID to remove.
            user_id: Optional owner user ID to scope deletion.

        Returns:
            True if at least one chunk was removed, False if document was not found.
        """
        try:
            # Backward compatibility: custom stores may still expose the old
            # delete_by_doc_id(doc_id) signature.
            try:
                count = await self.vector_store.delete_by_doc_id(doc_id, user_id=user_id)
            except TypeError:
                count = await self.vector_store.delete_by_doc_id(doc_id)
            if count > 0:
                logger.info("Removed document from memory: %s (%d chunks)", doc_id, count)
            return count > 0
        except Exception as e:
            logger.error("Failed to forget document: %s", e)
            return False

    async def _extract_chunks(
        self,
        document: StructuredDocument,
        doc_id: str,
    ) -> List[MemoryChunk]:
        """
        Extract memory chunks from a StructuredDocument.

        Preserves metadata and handles multimodal content.
        """
        chunks = []
        chunk_config = self.config.chunking

        for block in document.content_blocks:
            block_chunks = await self._chunk_content_block(
                block=block,
                doc_id=doc_id,
                chunk_size=chunk_config.chunk_size,
                chunk_overlap=chunk_config.chunk_overlap,
            )
            chunks.extend(block_chunks)

        return chunks

    async def _chunk_content_block(
        self,
        block: ContentBlock,
        doc_id: str,
        chunk_size: int,
        chunk_overlap: int,
    ) -> List[MemoryChunk]:
        """
        Chunk a single content block using Arabic-aware hierarchical splitting.

        Handles different modalities and preserves full metadata.
        """
        chunks = []

        # Get text content based on block type
        text_content = self._get_block_text(block)

        if not text_content or not text_content.strip():
            return chunks

        # Determine modality
        modality = block.type if hasattr(block, "type") else "text"

        # Get media reference if applicable
        media_ref = None
        if hasattr(block, "content"):
            content = block.content
            if hasattr(content, "image_path"):
                media_ref = content.image_path
            elif hasattr(content, "image_data") and content.image_data:
                media_ref = f"embedded:{block.block_id}"
            elif hasattr(content, "audio_path"):
                media_ref = content.audio_path

        # Extract full metadata from block
        timestamp = None
        page = None
        extra_meta = {}

        if hasattr(block, "metadata") and block.metadata:
            meta = block.metadata

            # Position info
            if hasattr(meta, "position") and meta.position:
                pos = meta.position
                if hasattr(pos, "page"):
                    page = pos.page
                if hasattr(pos, "sequence_index"):
                    extra_meta["sequence_index"] = pos.sequence_index

            # Provenance info
            if hasattr(meta, "provenance") and meta.provenance:
                prov = meta.provenance
                if hasattr(prov, "extraction_method"):
                    extra_meta["extraction_method"] = prov.extraction_method
                if hasattr(prov, "confidence"):
                    extra_meta["confidence"] = prov.confidence

            # Element type
            if hasattr(meta, "element_type") and meta.element_type:
                extra_meta["element_type"] = meta.element_type

            # Extra dict
            if hasattr(meta, "extra") and meta.extra:
                extra_meta.update(meta.extra)
                if "timestamp" in meta.extra:
                    timestamp = meta.extra["timestamp"]
                if "page_number" in meta.extra:
                    page = meta.extra["page_number"]

        # Use the Arabic-aware hierarchical splitter with streaming
        async for tc in self.text_splitter.split_with_hierarchy_streaming(
            text=text_content,
            doc_id=doc_id,
            block_id=block.block_id,
            modality=modality,
            page=page,
            media_ref=media_ref,
            timestamp=timestamp.timestamp() if timestamp else None,
            extra=extra_meta,
        ):
            # Store parent_text in extra for retrieval expansion
            chunk_extra = tc.metadata.extra.copy() if tc.metadata.extra else {}
            if tc.parent_text:
                chunk_extra["parent_text"] = tc.parent_text
                chunk_extra["parent_window_id"] = tc.metadata.parent_window_id

            chunks.append(
                MemoryChunk(
                    chunk_id=tc.chunk_id,
                    text=tc.text,
                    doc_id=tc.metadata.doc_id,
                    block_id=tc.metadata.block_id,
                    timestamp=datetime.fromtimestamp(tc.metadata.timestamp) if tc.metadata.timestamp else None,
                    modality=tc.metadata.modality,
                    page=tc.metadata.page,
                    media_ref=tc.metadata.media_ref,
                    extra=chunk_extra,
                )
            )

        return chunks

    def _get_block_text(self, block: ContentBlock) -> str:
        """Extract text from a content block based on its type."""
        if isinstance(block.content, str):
            return block.content

        # Handle ImageData
        if hasattr(block.content, "caption"):
            caption = block.content.caption
            if caption and hasattr(caption, "caption"):
                return caption.caption

        # Handle OCR (OCRResult uses ocr_text, not text)
        if hasattr(block.content, "ocr"):
            ocr = block.content.ocr
            if ocr:
                text = getattr(ocr, "ocr_text", None) or getattr(ocr, "text", None)
                if text:
                    return text

        # Handle AudioTranscript
        if hasattr(block.content, "full_text"):
            return block.content.full_text

        # Fallback for dict content
        if isinstance(block.content, dict):
            return block.content.get("text", str(block.content))

        return str(block.content)
