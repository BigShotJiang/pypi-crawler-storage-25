"""
Text Splitter Module for the Memory Framework.

Provides intelligent, Arabic-aware text splitting for optimal RAG performance.
Implements the "Small-to-Big" hierarchical chunking strategy.
"""

import asyncio
import gc
import re
import logging
import psutil
import os
from typing import List, Optional, Dict, Any, AsyncGenerator
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)

# Arabic and English sentence terminators
SENTENCE_TERMINATORS = re.compile(r"(?<=[.!?؟])\s+")
ARABIC_COMMA = "،"
PARAGRAPH_BREAK = re.compile(r"\n\n+")


@dataclass
class ChunkMetadata:
    """Metadata preserved from the original content block."""

    doc_id: str
    block_id: str
    modality: str = "text"
    page: Optional[int] = None
    media_ref: Optional[str] = None
    timestamp: Optional[float] = None
    parent_window_id: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)


@dataclass
class TextChunk:
    """A single chunk of text with full metadata."""

    chunk_id: str
    text: str
    metadata: ChunkMetadata
    # For Small-to-Big: the parent window text
    parent_text: Optional[str] = None


class ArabicAwareTextSplitter:
    """
    Intelligent text splitter with Arabic language support.

    Implements hierarchical chunking:
    - Child Chunks: Small, precise units for vector search
    - Parent Windows: Larger context returned to LLM
    """

    def __init__(
        self,
        child_chunk_size: int = 200,
        parent_window_size: int = 800,
        child_overlap: int = 30,
        separators: Optional[List[str]] = None,
        max_memory_percent: float = 80.0,  # Maximum memory usage percentage
    ):
        """
        Initialize the splitter.

        Args:
            child_chunk_size: Target size for child chunks (in characters).
            parent_window_size: Size of parent context window.
            child_overlap: Overlap between consecutive child chunks.
            separators: Custom separators for splitting (order matters).
            max_memory_percent: Maximum memory usage percentage before triggering GC.
        """
        self.child_chunk_size = child_chunk_size
        self.parent_window_size = parent_window_size
        self.child_overlap = child_overlap
        self.max_memory_percent = max_memory_percent

        # Default separators: paragraph -> sentence -> clause -> word
        self.separators = separators or [
            "\n\n",  # Paragraph
            "\n",  # Line break
            ".",  # English sentence end
            "؟",  # Arabic question mark
            "!",  # Exclamation
            "،",  # Arabic comma (clause)
            ",",  # English comma
            " ",  # Word
            "",  # Character fallback
        ]

    def _check_memory_usage(self) -> bool:
        """
        Check current memory usage and trigger garbage collection if needed.

        Returns:
            True if memory usage is acceptable, False if resources are constrained.
        """
        memory_percent = psutil.Process(os.getpid()).memory_percent()
        if memory_percent > self.max_memory_percent:
            logger.warning(f"High memory usage detected: {memory_percent:.1f}% - performing garbage collection")
            gc.collect()
            # Double-check after GC
            memory_percent = psutil.Process(os.getpid()).memory_percent()
            if memory_percent > self.max_memory_percent:
                logger.warning(f"Memory usage still high after GC: {memory_percent:.1f}%")
                return False
        return True

    async def split_with_hierarchy_streaming(
        self,
        text: str,
        doc_id: str,
        block_id: str,
        modality: str = "text",
        page: Optional[int] = None,
        media_ref: Optional[str] = None,
        timestamp: Optional[float] = None,
        extra: Optional[Dict[str, Any]] = None,
    ) -> AsyncGenerator[TextChunk, None]:
        """
        Split text into hierarchical chunks (child + parent) using streaming approach.

        Yields TextChunks where each has:
        - text: The small child chunk (for embedding)
        - parent_text: The larger context window (for LLM)

        This method is memory-efficient for large documents.
        """
        if not text or not text.strip():
            return

        text = text.strip()
        extra = extra or {}

        # Step 1: Create parent windows
        parent_windows = self._create_parent_windows(text)

        # Process parent windows one by one to manage memory
        for parent_idx, parent_text in enumerate(parent_windows):
            # Check memory usage periodically
            if not self._check_memory_usage():
                logger.warning("Memory constraints detected, pausing briefly")
                await asyncio.sleep(0.01)  # Brief pause to allow other tasks

            parent_window_id = f"{doc_id}_{block_id}_pw_{parent_idx}"

            # Split parent into children
            child_texts = self._recursive_split(parent_text, self.child_chunk_size)

            for child_idx, child_text in enumerate(child_texts):
                chunk_id = f"{doc_id}_{block_id}_{parent_idx}_{child_idx}"

                metadata = ChunkMetadata(
                    doc_id=doc_id,
                    block_id=block_id,
                    modality=modality,
                    page=page,
                    media_ref=media_ref,
                    timestamp=timestamp,
                    parent_window_id=parent_window_id,
                    extra=extra,
                )

                yield TextChunk(
                    chunk_id=chunk_id,
                    text=child_text.strip(),
                    metadata=metadata,
                    parent_text=parent_text,
                )

                # Yield control to event loop periodically
                if child_idx % 10 == 0:  # Every 10 chunks
                    await asyncio.sleep(0)

        logger.debug(f"Streamed processing of {len(parent_windows)} parent windows")

    def split_with_hierarchy(
        self,
        text: str,
        doc_id: str,
        block_id: str,
        modality: str = "text",
        page: Optional[int] = None,
        media_ref: Optional[str] = None,
        timestamp: Optional[float] = None,
        extra: Optional[Dict[str, Any]] = None,
    ) -> List[TextChunk]:
        """
        Split text into hierarchical chunks (child + parent).

        Returns a list of TextChunks where each has:
        - text: The small child chunk (for embedding)
        - parent_text: The larger context window (for LLM)
        """
        if not text or not text.strip():
            return []

        text = text.strip()
        extra = extra or {}

        # Step 1: Create parent windows
        parent_windows = self._create_parent_windows(text)

        # Step 2: For each parent, create child chunks
        chunks: List[TextChunk] = []

        for parent_idx, parent_text in enumerate(parent_windows):
            parent_window_id = f"{doc_id}_{block_id}_pw_{parent_idx}"

            # Split parent into children
            child_texts = self._recursive_split(parent_text, self.child_chunk_size)

            for child_idx, child_text in enumerate(child_texts):
                chunk_id = f"{doc_id}_{block_id}_{parent_idx}_{child_idx}"

                metadata = ChunkMetadata(
                    doc_id=doc_id,
                    block_id=block_id,
                    modality=modality,
                    page=page,
                    media_ref=media_ref,
                    timestamp=timestamp,
                    parent_window_id=parent_window_id,
                    extra=extra,
                )

                chunks.append(
                    TextChunk(
                        chunk_id=chunk_id,
                        text=child_text.strip(),
                        metadata=metadata,
                        parent_text=parent_text,
                    )
                )

        logger.debug(f"Split into {len(chunks)} child chunks from {len(parent_windows)} parent windows")
        return chunks

    def _create_parent_windows(self, text: str) -> List[str]:
        """Create overlapping parent windows from text."""
        windows = []

        # First try splitting by paragraphs
        paragraphs = PARAGRAPH_BREAK.split(text)

        current_window = ""
        for para in paragraphs:
            if not para.strip():
                continue

            if len(current_window) + len(para) <= self.parent_window_size:
                current_window += ("\n\n" if current_window else "") + para
            else:
                if current_window:
                    windows.append(current_window)

                if len(para) > self.parent_window_size:
                    # Paragraph itself is too large, split it
                    para_chunks = self._recursive_split(para, self.parent_window_size)
                    windows.extend(para_chunks[:-1])
                    current_window = para_chunks[-1]
                else:
                    current_window = para

        if current_window:
            windows.append(current_window)

        # If text is smaller than one window, just return it
        if not windows:
            windows = [text]

        return windows

    def _recursive_split(self, text: str, max_size: int, separators: Optional[List[str]] = None) -> List[str]:
        """
        Recursively split text using the separator hierarchy.

        Tries each separator in order until chunks are small enough.
        """
        if len(text) <= max_size:
            return [text]

        seps = separators if separators is not None else self.separators

        for i, separator in enumerate(seps):
            if separator == "":
                # Character-level split (last resort)
                return self._split_by_size(text, max_size)

            if separator in text:
                parts = text.split(separator)

                # Reconstruct with separator (except for whitespace seps)
                if separator.strip():
                    parts = [p + separator for p in parts[:-1]] + [parts[-1]]

                # Merge small parts and split large ones
                result = []
                current = ""

                # The next separators to try for sub-parts
                next_separators = seps[i + 1 :]

                for part in parts:
                    if not part.strip():
                        continue

                    if len(current) + len(part) <= max_size:
                        current += (separator if not separator.strip() and current else "") + part
                    else:
                        if current.strip():
                            result.append(current.strip())

                        if len(part) > max_size:
                            # Recursively split this large part using REMAINING separators
                            result.extend(self._recursive_split(part, max_size, next_separators))
                            current = ""
                        else:
                            current = part

                if current.strip():
                    result.append(current.strip())

                if result:
                    return result

        # Fallback to character split if no separators found and still too large
        return self._split_by_size(text, max_size)

    def _split_by_size(self, text: str, max_size: int) -> List[str]:
        """Last-resort character-based splitting with overlap."""
        chunks = []
        start = 0
        overlap = min(self.child_overlap, max_size - 1) if max_size > 1 else 0

        while start < len(text):
            end = min(start + max_size, len(text))
            chunks.append(text[start:end])
            if end >= len(text):
                break
            start = end - overlap
            # Ensure we always advance
            if start <= chunks[-1].find(text[start:end]):  # This is a bit complex, let's just use a simpler advance
                pass

            # Simple fallback: if start didn't move forward enough, force it
            if start <= (end - max_size):  # Should typically be 'start'
                start = end  # No overlap if it's stuck

        # Cleaner implementation:
        chunks = []
        start = 0
        while start < len(text):
            end = min(start + max_size, len(text))
            chunks.append(text[start:end])
            if end >= len(text):
                break
            start = end - overlap
        return chunks


def split_sentences_arabic(text: str) -> List[str]:
    """
    Split text into sentences with Arabic support.

    Handles: . ! ? ؟
    """
    sentences = SENTENCE_TERMINATORS.split(text)
    return [s.strip() for s in sentences if s.strip()]


def detect_language(text: str) -> str:
    """
    Simple language detection based on character ranges.

    Returns 'ar' for Arabic, 'en' for English/other.
    """
    arabic_chars = len(re.findall(r"[\u0600-\u06FF]", text))
    total_alpha = len(re.findall(r"\w", text))

    if total_alpha == 0:
        return "en"

    arabic_ratio = arabic_chars / total_alpha
    return "ar" if arabic_ratio > 0.3 else "en"
