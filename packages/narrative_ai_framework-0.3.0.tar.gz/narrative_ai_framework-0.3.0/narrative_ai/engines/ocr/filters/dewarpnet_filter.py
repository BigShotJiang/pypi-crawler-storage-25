"""
DewarpNet filter: dewarping-only filter using DewarpNet (ICCV 2019).
Vendored inference logic; requires pretrained .pkl models (unetnc_doc3d_final.pkl, dnetccnl_doc3d_final.pkl).
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict, Union

from .base import AbstractFilter

logger = logging.getLogger(__name__)

try:
    import cv2
    import numpy as np
    import torch
    import torch.nn as nn
    import torch.nn.functional as F

    _DEWARPNET_DEPS = True
except ImportError:
    _DEWARPNET_DEPS = False

from ..core import registry  # noqa: E402

# Max side length for inference; larger images are downscaled to avoid OOM (output at same size).
MAX_INFER_SIDE = 4096


def _unwarp(img_rgb: np.ndarray, bm: torch.Tensor, device: torch.device) -> np.ndarray:
    """
    Apply backward map to image. Matches official DewarpNet infer.py semantics.
    img_rgb: (H, W, 3) RGB, any dtype (normalized to float [0,1]).
    bm: (1, 2, 128, 128) backward map from dnetccnl; Hardtanh(0,1) so values in [0,1].
    PyTorch grid_sample expects grid in [-1, 1], so we use 2*bm - 1.
    Returns (H, W, 3) RGB float in [0, 1].
    """
    h, w = img_rgb.shape[0], img_rgb.shape[1]
    # bm from model: (1, 2, 128, 128) -> (128, 128, 2)
    bm_np = bm[0].detach().cpu().numpy().transpose(1, 2, 0)
    bm0 = cv2.blur(bm_np[:, :, 0], (3, 3))
    bm1 = cv2.blur(bm_np[:, :, 1], (3, 3))
    # OpenCV resize dsize is (width, height); we want spatial (h, w) so pass (w, h)
    bm0 = cv2.resize(bm0, (w, h))
    bm1 = cv2.resize(bm1, (w, h))
    # Model outputs [0,1] (Hardtanh); grid_sample expects [-1, 1]
    bm0_f = bm0.astype(np.float32)
    bm1_f = bm1.astype(np.float32)
    grid_x = np.clip(2.0 * bm0_f - 1.0, -1.0, 1.0)
    grid_y = np.clip(2.0 * bm1_f - 1.0, -1.0, 1.0)
    grid = np.stack([grid_x, grid_y], axis=-1).astype(np.float32)
    grid = np.expand_dims(grid, 0)
    grid_t = torch.from_numpy(grid).to(device)

    img = np.asarray(img_rgb, dtype=np.float32)
    if img.max() > 1.0:
        img = img / 255.0
    img = img.transpose((2, 0, 1))
    img = np.expand_dims(img, 0)
    img_t = torch.from_numpy(img).float().to(device)

    res = F.grid_sample(img_t, grid_t, mode="bilinear", padding_mode="zeros", align_corners=False)
    res = res[0].cpu().numpy().transpose((1, 2, 0))
    return np.clip(res, 0.0, 1.0)


@registry.register_filter("dewarpnet")
class DewarpNetFilter(AbstractFilter):
    """
    Dewarping-only filter using DewarpNet (ICCV 2019).
    Loads shape net (unetnc) and texture net (dnetccnl); applies unwarp at original resolution.
    """

    WC_SIZE = (256, 256)
    BM_SIZE = (128, 128)

    def __init__(self, config: Dict[str, Any]):
        super().__init__("dewarpnet", config)
        self._wc_model = None
        self._bm_model = None
        self._device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        wc_path = config.get("wc_model_path") or config.get("wc_model_path_env")
        if isinstance(wc_path, str) and wc_path.startswith("env:"):
            wc_path = os.getenv(wc_path[4:].strip()) or ""
        bm_path = config.get("bm_model_path") or config.get("bm_model_path_env")
        if isinstance(bm_path, str) and bm_path.startswith("env:"):
            bm_path = os.getenv(bm_path[4:].strip()) or ""
        self._wc_path = wc_path or ""
        self._bm_path = bm_path or ""

    def _resolve_path(self, p: str) -> Path:
        """Resolve path: if relative, relative to this filter's directory (so CWD-independent)."""
        path = Path(p)
        if not path.is_absolute():
            path = (Path(__file__).resolve().parent / path).resolve()
        return path

    def _load(self) -> None:
        if not _DEWARPNET_DEPS:
            logger.warning("DewarpNet filter: torch/cv2/numpy not available")
            self.model = None
            return
        if not self._wc_path or not self._bm_path:
            logger.warning("DewarpNet filter: wc_model_path and bm_model_path required in config")
            self.model = None
            return
        wc_path = self._resolve_path(self._wc_path)
        bm_path = self._resolve_path(self._bm_path)
        if not wc_path.exists() or not bm_path.exists():
            logger.warning("DewarpNet filter: model files not found at %s, %s", wc_path, bm_path)
            self.model = None
            return

        try:
            from .dewarpnet_models import convert_state_dict, get_model

            def _load_state(path: Path, device: torch.device):
                ckpt = torch.load(str(path), map_location=device, weights_only=False)  # nosec B614 - trusted model weights
                if not isinstance(ckpt, dict):
                    return convert_state_dict(ckpt)
                state = ckpt.get("model_state") or ckpt.get("state_dict")
                if state is None:
                    state = ckpt
                return convert_state_dict(state)

            wc_model = get_model("unetnc", n_classes=3, in_channels=3)
            wc_state = _load_state(wc_path, self._device)
            try:
                wc_model.load_state_dict(wc_state, strict=True)
            except Exception:
                wc_result = wc_model.load_state_dict(wc_state, strict=False)
                logger.warning(
                    "DewarpNet wc: loaded with strict=False; missing=%s unexpected=%s",
                    wc_result.missing_keys[:8],
                    wc_result.unexpected_keys[:8],
                )
            wc_model.eval().to(self._device)

            bm_model = get_model("dnetccnl", n_classes=2, in_channels=3)
            bm_state = _load_state(bm_path, self._device)
            try:
                bm_model.load_state_dict(bm_state, strict=True)
            except Exception:
                bm_result = bm_model.load_state_dict(bm_state, strict=False)
                logger.warning(
                    "DewarpNet bm: loaded with strict=False; missing=%s unexpected=%s",
                    bm_result.missing_keys[:8],
                    bm_result.unexpected_keys[:8],
                )
            bm_model.eval().to(self._device)

            self._wc_model = wc_model
            self._bm_model = bm_model
            self.model = True
            logger.info("DewarpNet filter loaded (device=%s)", self._device)
        except Exception as e:
            logger.exception("DewarpNet filter load failed: %s", e)
            self.model = None

    def apply(self, image: Union[str, Path, bytes], task: str = "dewarp", **kwargs: Any) -> bytes:
        """Apply dewarping. Only task='dewarp' is supported; other tasks return image unchanged."""
        if task != "dewarp":
            if isinstance(image, bytes):
                return image
            with open(image, "rb") as f:
                return f.read()
        return self.process(image, task=task, **kwargs)

    def _apply(self, image: Union[str, Path, bytes], **kwargs: Any) -> bytes:
        if self._wc_model is None or self._bm_model is None:
            if isinstance(image, bytes):
                return image
            with open(image, "rb") as f:
                return f.read()

        if isinstance(image, (str, Path)):
            with open(image, "rb") as f:
                raw = f.read()
        else:
            raw = image
        nparr = np.frombuffer(raw, np.uint8)
        img_bgr = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if img_bgr is None:
            return raw

        h_in, w_in = img_bgr.shape[0], img_bgr.shape[1]
        max_side = max(h_in, w_in)
        if max_side > MAX_INFER_SIDE:
            scale = MAX_INFER_SIDE / max_side
            new_w, new_h = int(w_in * scale), int(h_in * scale)
            img_bgr = cv2.resize(img_bgr, (new_w, new_h), interpolation=cv2.INTER_AREA)
            logger.debug("DewarpNet: downscaled large image to %dx%d", new_h, new_w)

        # Official infer.py: network is fed BGR (they do img[:,:,::-1] after RGB resize).
        img_wc = cv2.resize(img_bgr, self.WC_SIZE, interpolation=cv2.INTER_LINEAR)
        img_wc = img_wc.astype(np.float32) / 255.0
        img_wc = np.expand_dims(img_wc.transpose(2, 0, 1), axis=0)
        img_t = torch.from_numpy(img_wc).float().to(self._device, non_blocking=True)

        htan = nn.Hardtanh(0, 1.0)
        infer_ctx = torch.inference_mode() if hasattr(torch, "inference_mode") else torch.no_grad()
        with infer_ctx():
            wc_out = self._wc_model(img_t)
            pred_wc = htan(wc_out)
            bm_input = F.interpolate(pred_wc, size=self.BM_SIZE, mode="bilinear", align_corners=False)
            bm_out = self._bm_model(bm_input)

        # Unwarp in RGB space (official uses RGB for unwarp and writes with [:,:,::-1]).
        img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        uwpred_rgb = _unwarp(img_rgb, bm_out.float(), self._device)
        uwpred_uint8 = (uwpred_rgb * 255.0).clip(0, 255).astype(np.uint8)
        uwpred_bgr = cv2.cvtColor(uwpred_uint8, cv2.COLOR_RGB2BGR)
        _, buf = cv2.imencode(".png", uwpred_bgr)
        return buf.tobytes()
