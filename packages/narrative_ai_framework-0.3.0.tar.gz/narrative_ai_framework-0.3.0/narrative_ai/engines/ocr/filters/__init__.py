from .base import AbstractFilter
from .docres_filter import DocResFilter
from .remote_docres import RemoteDocResFilter

try:
    from .dewarpnet_filter import DewarpNetFilter

    _DEWARPNET_EXPORT = ("DewarpNetFilter",)
except ImportError:
    DewarpNetFilter = None  # type: ignore[misc, assignment]
    _DEWARPNET_EXPORT = ()

__all__ = [
    "AbstractFilter",
    "DocResFilter",
    "RemoteDocResFilter",
    *_DEWARPNET_EXPORT,
]
