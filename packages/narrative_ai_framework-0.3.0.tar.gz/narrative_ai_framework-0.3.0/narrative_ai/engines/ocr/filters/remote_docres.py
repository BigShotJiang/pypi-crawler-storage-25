import requests
import logging
import cv2
import numpy as np
from pathlib import Path
from typing import Union, Dict, Any
from .base import AbstractFilter
from ..utils import docres_utils
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

from ..core import registry  # noqa: E402


@registry.register_filter("remote_docres")
class RemoteDocResFilter(AbstractFilter):
    """
    Remote DocRes Filter Engine with Local Pre/Post-processing.

    This component offloads ONLY the model inference to a remote server.
    The "intelligence" of preparing prompts and reconstructing detail stay local.
    """

    def __init__(self, config: Dict[str, Any]):
        super().__init__("remote_docres", config)
        raw_url = config.get("url", "")
        self.url = raw_url.strip().rstrip("/") if raw_url else ""
        self.timeout = config.get("timeout", 60)
        self.headers = config.get("headers", {})
        self.verify_ssl = config.get("verify_ssl", True)

    def _load(self) -> None:
        if not self.url:
            self.model = None
            return
        try:
            response = requests.get(f"{self.url}/health", headers=self.headers, timeout=5, verify=self.verify_ssl)
            self.model = True if response.status_code == 200 else None
        except Exception:
            self.model = None

    def apply(self, image: Union[str, Path, bytes], task: str = "end2end", **kwargs) -> bytes:
        return self._apply(image, task=task, **kwargs)

    def apply_combined(self, image: Union[str, Path, bytes], task: str = "end2end", **kwargs) -> Dict[str, Any]:
        """
        Execute both Restoration and OCR in a single server request.
        """
        # 1. Prepare image bytes
        if isinstance(image, bytes):
            raw_bytes = image
        else:
            with open(image, "rb") as f:
                raw_bytes = f.read()

        # 2. Determine MIME type and filename
        import mimetypes

        ext = ".png"
        hint = kwargs.get("filename")
        if isinstance(image, (str, Path)):
            ext = Path(image).suffix.lower()
        elif hint:
            ext = Path(hint).suffix.lower()

        mime_type, _ = mimetypes.guess_type(f"temp{ext}")
        if not mime_type:
            mime_map = {
                ".webp": "image/webp",
                ".tiff": "image/tiff",
                ".tif": "image/tiff",
                ".bmp": "image/bmp",
                ".heic": "image/heic",
                ".heif": "image/heif",
            }
            mime_type = mime_map.get(ext, "image/png")

        filename = f"image{ext}"

        # 3. Call Combined Endpoint
        try:
            print(f"📡 SDK -> Server: Requesting Combined Pipeline ({task}) [MIME: {mime_type}]...")
            files = {"file": (filename, raw_bytes, mime_type)}
            response = requests.post(
                f"{self.url}/docres_and_ocr",
                files=files,
                data={"task": task},
                headers=self.headers,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )

            if response.status_code == 200:
                print("✅ SDK: Combined Pipeline Successful")
                data = response.json()

                # Handle Base64 image
                import base64

                img_b64 = data.get("processed_image", "")
                img_bytes = base64.b64decode(img_b64) if img_b64 else None

                return {"text": data.get("text", ""), "processed_image": img_bytes}
            else:
                print(f"❌ SDK: Combined Server error {response.status_code}")
        except Exception as e:
            print(f"❌ SDK: Combined Connection error: {e}")

        return {"text": "", "processed_image": None}

    @staticmethod
    def _normalize_single_task(t: str) -> str:
        """Normalize a single task keyword to the canonical server task name."""
        t = t.strip().lower()
        if "dewarp" in t:
            return "dewarp"
        if "restor" in t:
            return "restoration"
        if "shadow" in t:
            return "deshadow"
        if "appear" in t or "enhance" in t:
            return "appearance"
        if "binarize" in t:
            return "binarize"
        if "deblur" in t or "blur" in t:
            return "deblur"
        return t

    def _apply_single(self, image: bytes, t: str, **kwargs) -> bytes:
        """
        Apply ONE normalized task to raw image bytes.
        Tries the standard server pipeline first, then falls back to atomic inference.
        """
        import mimetypes

        ext = ".png"
        hint = kwargs.get("filename")
        if hint:
            ext = Path(hint).suffix.lower()

        mime_type, _ = mimetypes.guess_type(f"temp{ext}")
        if not mime_type:
            mime_map = {
                ".webp": "image/webp",
                ".tiff": "image/tiff",
                ".tif": "image/tiff",
                ".bmp": "image/bmp",
                ".heic": "image/heic",
                ".heif": "image/heif",
            }
            mime_type = mime_map.get(ext, "image/png")
        filename = f"image{ext}"
        raw_bytes = image

        # Case A: Standard server-side pipeline
        try:
            print(f"📡 SDK -> Server: Requesting Standard Pipeline ({t}) [MIME: {mime_type}]...")
            files = {"file": (filename, raw_bytes, mime_type)}
            response = requests.post(
                f"{self.url}/docres",
                files=files,
                data={"task": t},
                headers=self.headers,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )
            if response.status_code == 200:
                print(f"✅ SDK: Standard Pipeline Successful ({t})")
                return response.content
            else:
                print(f"⚠️ SDK: Standard Pipeline failed ({response.status_code}) for '{t}'. Trying Atomic...")
        except Exception as e:
            print(f"⚠️ SDK: Standard Pipeline connection error for '{t}': {e}. Trying Atomic...")

        # Case B: Fallback atomic inference
        try:
            img_bgr = cv2.imdecode(np.frombuffer(raw_bytes, np.uint8), cv2.IMREAD_COLOR)
            if img_bgr is None:
                print(f"❌ SDK: Atomic Inference failed for '{t}' - local decoding not supported.")
                return raw_bytes

            h, w = img_bgr.shape[:2]
            prompt_img = None
            if t == "deshadow":
                prompt_img = docres_utils.generate_deshadow_prompt(img_bgr)
            elif t == "appearance":
                prompt_img = docres_utils.generate_appearance_prompt(img_bgr)
            elif t == "binarize":
                prompt_img = docres_utils.generate_binarization_prompt(img_bgr)
            elif t == "deblur":
                # Sobel high-frequency prompt — matches Kaggle server deblur_prompt()
                x = cv2.Sobel(img_bgr, cv2.CV_16S, 1, 0)
                y = cv2.Sobel(img_bgr, cv2.CV_16S, 0, 1)
                edge = cv2.addWeighted(cv2.convertScaleAbs(x), 0.5, cv2.convertScaleAbs(y), 0.5, 0)
                if len(edge.shape) == 2:
                    edge = cv2.cvtColor(edge, cv2.COLOR_GRAY2BGR)
                prompt_img = edge

            if prompt_img is not None:
                print(f"📡 SDK -> Server: Trying Atomic Inference for '{t}'...")
                _, img_encoded = cv2.imencode(".png", img_bgr)
                _, prompt_encoded = cv2.imencode(".png", prompt_img)
                response = requests.post(
                    f"{self.url}/docres/inference",
                    files={
                        "file": ("image.png", img_encoded.tobytes(), "image/png"),
                        "prompt": ("prompt.png", prompt_encoded.tobytes(), "image/png"),
                    },
                    data={"task": t},
                    headers=self.headers,
                    timeout=self.timeout,
                    verify=self.verify_ssl,
                )
                if response.status_code == 200:
                    print(f"✅ SDK: Atomic Inference Successful for '{t}'. Reconstructing...")
                    pred_img = cv2.imdecode(np.frombuffer(response.content, np.uint8), cv2.IMREAD_COLOR)
                    if t == "binarize":
                        res_img = cv2.resize(pred_img, (w, h))
                    else:
                        res_img = docres_utils.reconstruct_from_ratio(img_bgr, pred_img)
                    _, final_buffer = cv2.imencode(".png", res_img)
                    return final_buffer.tobytes()
        except Exception as e:
            print(f"❌ SDK: Atomic Inference error for '{t}': {e}")

        print(f"⚠️ SDK: Returning image unchanged because all processing failed for '{t}'")
        return raw_bytes

    def _apply(self, image: Union[str, Path, bytes], task: str = "end2end", **kwargs) -> bytes:
        """
        Execute model calls with local pre/post-processing and automatic fallback.
        Supports composite tasks like 'dewarp+deshadow' — each sub-task is applied
        sequentially in the order provided.
        """
        # Ensure we have raw bytes
        if isinstance(image, bytes):
            raw_bytes = image
        else:
            with open(image, "rb") as f:
                raw_bytes = f.read()

        # Split composite task string into individual steps
        parts = [p.strip() for p in task.lower().split("+") if p.strip()]
        if not parts:
            parts = ["restoration"]

        # Normalize each part to its canonical name
        steps = [self._normalize_single_task(p) for p in parts]
        print(f"🔄 SDK: RemoteDocRes pipeline — steps: {steps} (from task='{task}')")

        current = raw_bytes
        for step in steps:
            print(f"  ▶ Applying step: '{step}'")
            current = self._apply_single(current, step, **kwargs)

        return current
