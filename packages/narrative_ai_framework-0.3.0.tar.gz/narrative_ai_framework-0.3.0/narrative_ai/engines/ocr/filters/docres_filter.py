import os
import sys
import subprocess
import torch
import cv2
import numpy as np
import urllib.request
import logging
from collections import OrderedDict
from pathlib import Path
from typing import Union, Dict, Any
from skimage.filters import threshold_sauvola
from .base import AbstractFilter
from ..utils import docres_utils

logger = logging.getLogger(__name__)

from ..core import registry  # noqa: E402


@registry.register_filter("local_docres")
class DocResFilter(AbstractFilter):
    """
    Local Engine for Document Restoration (DocRes).

    This filter performs:
    1. Geometric Dewarping (Restoring flat document structure)
    2. Deshadowing (Removing shadows and lighting artifacts)
    3. Appearance Enhancement (Improving contrast and clarity)

    Uses the Restormer architecture and MBD (Mask-based Dewarping).
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the DocRes Filter.

        Args:
            config: Configuration dictionary for models and paths.
        """
        super().__init__("docres", config)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Define paths
        weights_root = Path(__file__).parent / "weights"
        self.repo_path = weights_root / "DocRes"
        self.docres_weights = weights_root / "docres.pkl"
        self.mbd_weights = weights_root / "mbd.pkl"

    def _load(self) -> None:
        """
        Set up the environment, download weights, and load the Restormer model.
        """
        # 1. Initialize DocRes Repository
        if not (self.repo_path / "models").exists():
            self._setup_repository()

        # 2. Ensure weights are present
        self._ensure_weights_exist()

        # 3. Add repo to python path for internal imports
        self._inject_paths()

        # 4. Initialize and load model
        try:
            from models import restormer_arch

            self.model = restormer_arch.Restormer(
                inp_channels=6,
                out_channels=3,
                dim=48,
                num_blocks=[2, 3, 3, 4],
                num_refinement_blocks=4,
                heads=[1, 2, 4, 8],
                ffn_expansion_factor=2.66,
                bias=False,
                LayerNorm_type="WithBias",
                dual_pixel_task=True,
            )

            logger.info(f"Loading DocRes weights onto {self.device}...")
            state = self._convert_state_dict(
                torch.load(str(self.docres_weights), map_location=self.device, weights_only=True)["model_state"]
            )
            self.model.load_state_dict(state)
            self.model.eval().to(self.device)
            logger.info("DocRes Engine: Successfully loaded and ready.")

        except Exception as e:
            logger.error(f"Failed to initialize DocRes Engine: {e}")
            self.model = None

    def _setup_repository(self) -> None:
        """Clone the DocRes git repository for internal model definitions."""
        logger.info(f"Cloning DocRes repository to {self.repo_path}...")
        if self.repo_path.exists():
            import shutil

            shutil.rmtree(self.repo_path)

        os.makedirs(self.repo_path.parent, exist_ok=True)
        subprocess.run(["git", "clone", "https://github.com/ZZZHANG-jx/DocRes.git", str(self.repo_path)], check=True)

        # Create necessary internal directories
        (self.repo_path / "checkpoints").mkdir(exist_ok=True)
        (self.repo_path / "data" / "MBD" / "checkpoint").mkdir(parents=True, exist_ok=True)

    def _ensure_weights_exist(self) -> None:
        """Download weight files if missing from local storage."""
        weight_map = {
            self.docres_weights: "https://huggingface.co/DaVinciCode/doctra-docres-main/resolve/main/docres.pkl",
            self.mbd_weights: "https://huggingface.co/DaVinciCode/doctra-docres-mbd/resolve/main/mbd.pkl",
        }

        for path, url in weight_map.items():
            if not path.exists():
                if not str(url).startswith("https://huggingface.co/DaVinciCode/"):
                    logger.error("Unexpected DocRes weights URL %s; refusing to download.", url)
                    continue
                logger.info("Downloading required DocRes weights: %s...", path.name)
                urllib.request.urlretrieve(url, str(path))  # nosec: B310

    def _inject_paths(self) -> None:
        """Inject required repository paths into sys.path."""
        paths = [str(self.repo_path), str(self.repo_path / "data" / "MBD")]
        for p in paths:
            if p not in sys.path:
                sys.path.insert(0, p)

    def _convert_state_dict(self, state_dict: Dict[str, Any]) -> OrderedDict:
        """Convert state dict to remove 'module.' prefix if present."""
        new_state_dict = OrderedDict()
        for k, v in state_dict.items():
            name = k[7:] if k.startswith("module.") else k
            new_state_dict[name] = v
        return new_state_dict

    def _dewarping(self, img: np.ndarray) -> np.ndarray:
        """Perform Geometric dewarping on the input BGR image."""
        from infer import net1_net2_infer_single_im

        # 1. Generate segmentation mask (MBD)
        mask = net1_net2_infer_single_im(img, str(self.mbd_weights))

        # 2. Prepare inputs for Restormer
        im_masked = img.copy()
        im_masked[mask == 0] = 0

        base_grid = docres_utils.get_base_coord(256, 256) / 256
        prompt = np.concatenate((base_grid, np.expand_dims(cv2.resize(mask, (256, 256)) / 255, -1)), -1)

        im_t = (
            torch.from_numpy(cv2.resize(im_masked, (256, 256)).transpose(2, 0, 1) / 255)
            .unsqueeze(0)
            .float()
            .to(self.device)
        )
        pr_t = torch.from_numpy(prompt.transpose(2, 0, 1)).unsqueeze(0).float().to(self.device)

        # 3. Model Inference (Atomic)
        with torch.no_grad():
            pred = self.model.float()(torch.cat((im_t, pr_t), 1))

        # 4. Post-processing (Flow locally)
        pred_np = pred[0][:2].permute(1, 2, 0).cpu().numpy()
        flow = docres_utils.get_dewarp_flow(img, pred_np)

        return cv2.remap(img, flow[:, :, 0].astype(np.float32), flow[:, :, 1].astype(np.float32), cv2.INTER_LINEAR)

    def _process_prompt_task(self, img: np.ndarray, task_type: str) -> np.ndarray:
        """Unified processing for Deshadowing and Enhancement."""
        # 1. Generate task-specific prompt (Local CV2)
        if task_type == "deshadow":
            prompt_img = docres_utils.generate_deshadow_prompt(img, 1024)
        else:  # Appearance
            prompt_img = docres_utils.generate_appearance_prompt(img, 1024)

        # 2. Prep tensor
        in_im = np.concatenate((img, prompt_img), -1)
        in_im_t = torch.from_numpy(cv2.resize(in_im, (1600, 1600)).transpose(2, 0, 1) / 255).unsqueeze(0)

        # 3. Inference
        is_cuda = self.device.type == "cuda"
        in_im_t = in_im_t.half().to(self.device) if is_cuda else in_im_t.float().to(self.device)
        model = self.model.half() if is_cuda else self.model.float()

        with torch.no_grad():
            pred = model(in_im_t)

        # 4. Reconstruction (Local CV2)
        pred_np = (torch.clamp(pred[0].permute(1, 2, 0), 0, 1).cpu().numpy() * 255).astype(np.uint8)
        return docres_utils.reconstruct_from_ratio(img, pred_np)

    def _deblurring(self, img: np.ndarray) -> np.ndarray:
        """Apply deblurring via DocRes model using Sobel high-frequency prompt."""
        h, w = img.shape[:2]

        # Pad to multiple of 8 (Restormer requirement)
        ph, pw = (8 - h % 8) % 8, (8 - w % 8) % 8
        img_padded = np.pad(img, ((ph, 0), (pw, 0), (0, 0)), "reflect")

        # Generate Sobel high-frequency prompt (same as Kaggle server)
        x = cv2.Sobel(img_padded, cv2.CV_16S, 1, 0)
        y = cv2.Sobel(img_padded, cv2.CV_16S, 0, 1)
        edge = cv2.addWeighted(cv2.convertScaleAbs(x), 0.5, cv2.convertScaleAbs(y), 0.5, 0)
        if len(edge.shape) == 2:
            edge = cv2.cvtColor(edge, cv2.COLOR_GRAY2BGR)

        # Concatenate image + prompt and run through DocRes model
        in_im = np.concatenate((img_padded, edge), -1)
        is_cuda = self.device.type == "cuda"
        in_t = torch.from_numpy(in_im.transpose(2, 0, 1) / 255).unsqueeze(0)
        in_t = in_t.half().to(self.device) if is_cuda else in_t.float().to(self.device)
        model = self.model.half() if is_cuda else self.model.float()

        with torch.no_grad():
            pred = model(in_t)
            pred = torch.clamp(pred, 0, 1)
            result = (pred[0].permute(1, 2, 0).cpu().float().numpy() * 255).astype(np.uint8)

        # Crop padding and return
        return result[ph:, pw:]

    def _binarization(self, img: np.ndarray) -> np.ndarray:
        """Apply Sauvola Binarization with edge enhancement prompt."""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        n1 = int(0.05 * min(img.shape[:2])) | 1
        T1 = threshold_sauvola(gray, window_size=n1, k=0.5)
        C = np.zeros_like(gray, dtype=np.float32)
        m = gray > T1
        C[m] = (gray[m] - T1[m]) / (np.amax(gray) - T1[m] + 1e-6)
        T2 = threshold_sauvola((C * 255).astype(np.uint8), window_size=n1 * 2 | 1, k=0.5)
        binary = np.where((C * 255) > T2, 255, 0).astype(np.uint8)

        # Create prompt with binary map + edges
        x = cv2.Sobel(img, cv2.CV_16S, 1, 0)
        y = cv2.Sobel(img, cv2.CV_16S, 0, 1)
        edge = cv2.addWeighted(cv2.convertScaleAbs(x), 0.5, cv2.convertScaleAbs(y), 0.5, 0)
        if len(edge.shape) == 3:
            edge = cv2.cvtColor(edge, cv2.COLOR_BGR2GRAY)

        prompt = np.zeros_like(img)
        prompt[:, :, 0] = binary
        prompt[:, :, 1] = edge

        h, w = img.shape[:2]
        in_im = np.concatenate((img, prompt), -1)
        in_im_t = (
            torch.from_numpy(cv2.resize(in_im, (1024, 1024)).transpose(2, 0, 1) / 255)
            .unsqueeze(0)
            .float()
            .to(self.device)
        )

        with torch.no_grad():
            pred = self.model(in_im_t)

        pred = torch.max(torch.softmax(pred[:, :2, :, :], 1), 1)[1]
        res = (pred[0].cpu().numpy() * 255).astype(np.uint8)
        return cv2.resize(res, (w, h))

    def _apply(self, image: Union[bytes, np.ndarray], task: str = "end2end", **kwargs) -> bytes:
        """Apply requested DocRes processing pipeline."""
        if self.model is None:
            return image

        # Convert to BGR Numpy array for processing
        if isinstance(image, bytes):
            img = cv2.imdecode(np.frombuffer(image, np.uint8), cv2.IMREAD_COLOR)
        else:
            img = image
            if img.shape[2] == 4:  # RGBA -> BGR
                img = cv2.cvtColor(img, cv2.COLOR_RGBA2BGR)
            else:  # RGB -> BGR
                img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)

        # Pipeline execution
        if task == "dewarping":
            img = self._dewarping(img)
        elif task == "deshadowing":
            img = self._process_prompt_task(img, "deshadow")
        elif task == "appearance":
            img = self._process_prompt_task(img, "appearance")
        elif task == "deblur":
            img = self._deblurring(img)
        elif task == "binarize":
            img = self._binarization(img)
        else:  # end2end
            img = self._dewarping(img)
            img = self._process_prompt_task(img, "deshadow")
            img = self._process_prompt_task(img, "appearance")

        # Convert back to PNG bytes
        _, buffer = cv2.imencode(".png", img)
        return buffer.tobytes()
