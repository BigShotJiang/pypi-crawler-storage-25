from abc import ABC, abstractmethod
import logging
from pathlib import Path
from typing import Any, Dict, Optional, Union
from urllib.parse import urlparse
import urllib.request

logger = logging.getLogger(__name__)


class AbstractFilter(ABC):
    """
    Base class for all image processing filters in the OCR engine.

    This class defines the interface for loading models and applying
    filters to images, providing common utilities like model downloading.
    """

    def __init__(self, name: str, config: Dict[str, Any]):
        """
        Initialize the filter.

        Args:
            name: Human-readable name of the filter.
            config: Configuration dictionary for the filter.
        """
        self.name = name
        self.config = config
        self.model = None

    def get_model_path(self) -> Optional[str]:
        """
        Retrieve the path to the model weight file, downloading it if necessary.

        Returns:
            Optional[str]: Absolute path to the model file, or None if not found/downloadable.
        """
        model_config = self.config.get("model", {})
        filename = model_config.get("filename", f"{self.name}.pth")
        url = model_config.get("url")

        # Ensure weights directory exists
        weight_dir = Path(__file__).parent / "weights"
        weight_dir.mkdir(exist_ok=True)

        file_path = weight_dir / filename

        if not file_path.exists():
            if url:
                parsed = urlparse(str(url))
                if parsed.scheme not in {"http", "https"}:
                    logger.error("Refusing to download weights for %s from non-HTTP(S) URL: %s", self.name, url)
                    return None
                logger.info("Downloading weights for %s from %s...", self.name, url)
                try:
                    urllib.request.urlretrieve(url, file_path)  # nosec: B310
                except Exception as e:
                    logger.error("Failed to download weights for %s: %s", self.name, e)
                    return None
            else:
                logger.warning("Weights for %s are missing and no download URL is provided.", self.name)
                return None

        return str(file_path.absolute())

    @abstractmethod
    def _load(self) -> None:
        """
        Load the model into memory/GPU. Must be implemented by subclasses.
        This method should handle model loading, potentially using a function like
        `from_pretrained` which might require a `nosec: B615` tag if `allow_pickle=True`
        or similar unsafe deserialization is used.
        """
        pass

    @abstractmethod
    def _apply(self, image: Union[str, Path, bytes], **kwargs) -> Union[bytes, Any]:
        """
        Internal implementation of the filter logic.

        Args:
            image: Input image (path or raw bytes).
            **kwargs: Additional parameters for the filter.

        Returns:
            The processed image data.
        """
        pass

    def process(self, image_input: Union[str, Path, bytes], **kwargs: Any) -> Union[bytes, Any]:
        """
        The main entrance for applying the filter. Handles lazy loading of the model.

        Args:
            image_input: The image to be processed.
            **kwargs: Parameters passed to the underlying filter implementation.

        Returns:
            The processed image.
        """
        if self.model is None:
            self._load()

        if self.model is None:
            logger.warning(f"Filter {self.name} failed to load model. Skipping filter.")
            return image_input

        return self._apply(image_input, **kwargs)
