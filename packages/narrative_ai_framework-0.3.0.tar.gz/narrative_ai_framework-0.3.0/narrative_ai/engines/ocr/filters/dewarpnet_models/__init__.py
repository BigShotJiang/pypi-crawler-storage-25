# Vendored from DewarpNet (https://github.com/cvlab-stonybrook/DewarpNet) for inference only.
# Models: unetnc (shape), dnetccnl (backward map). See docs/DEWARPNET_INTEGRATION.md.

from collections import OrderedDict
from typing import Any, Dict

import torch


def convert_state_dict(state_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Convert state dict from DataParallel module to normal module (remove 'module.' prefix)."""
    new_state_dict = OrderedDict()
    for k, v in state_dict.items():
        name = k[7:] if k.startswith("module.") else k
        new_state_dict[name] = v
    return new_state_dict


def get_model(name: str, n_classes: int, in_channels: int = 3, **kwargs) -> torch.nn.Module:
    """Get DewarpNet model by name. name in ('unetnc', 'dnetccnl')."""
    if name == "dnetccnl":
        from .densenetccnl import dnetccnl

        return dnetccnl(img_size=128, in_channels=in_channels, out_channels=n_classes, filters=32)
    if name == "unetnc":
        from .unetnc import UnetGenerator

        return UnetGenerator(input_nc=in_channels, output_nc=n_classes, num_downs=7)
    raise ValueError(f"Unknown model: {name}")
