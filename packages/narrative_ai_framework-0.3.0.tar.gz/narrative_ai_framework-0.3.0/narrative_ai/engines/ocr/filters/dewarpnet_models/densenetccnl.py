# Vendored from DewarpNet models/densenetccnl.py (ICCV 2019). dnetccnl for backward map prediction.

import numpy as np
import torch
import torch.nn as nn


def add_coordConv_channels(t):
    n, c, h, w = t.size()
    xx_channel = np.ones((h, w))
    xx_range = np.array(range(h), dtype=np.float32)
    xx_range = np.expand_dims(xx_range, -1)
    xx_coord = xx_channel * xx_range
    yy_coord = xx_coord.transpose()
    # Safe for h==1 or w==1 (single row/column)
    xx_coord = xx_coord / max(h - 1, 1)
    yy_coord = yy_coord / max(w - 1, 1)
    xx_coord = xx_coord * 2 - 1
    yy_coord = yy_coord * 2 - 1
    xx_coord = torch.from_numpy(xx_coord.astype(np.float32)).to(t.device)
    yy_coord = torch.from_numpy(yy_coord.astype(np.float32)).to(t.device)
    xx_coord = xx_coord.unsqueeze(0).unsqueeze(0).repeat(n, 1, 1, 1)
    yy_coord = yy_coord.unsqueeze(0).unsqueeze(0).repeat(n, 1, 1, 1)
    t_cc = torch.cat((t, xx_coord, yy_coord), dim=1)
    return t_cc


class DenseBlockEncoder(nn.Module):
    def __init__(self, n_channels, n_convs, activation=nn.ReLU, args=(False,)):
        super().__init__()
        assert n_convs > 0
        self.layers = nn.ModuleList()
        for _ in range(n_convs):
            self.layers.append(
                nn.Sequential(
                    nn.BatchNorm2d(n_channels),
                    activation(*args),
                    nn.Conv2d(n_channels, n_channels, 3, stride=1, padding=1, bias=False),
                )
            )

    def forward(self, inputs):
        outputs = []
        for i, layer in enumerate(self.layers):
            if i > 0:
                next_output = sum(outputs)
                outputs.append(layer(next_output))
            else:
                outputs.append(layer(inputs))
        return outputs[-1]


class DenseBlockDecoder(nn.Module):
    def __init__(self, n_channels, n_convs, activation=nn.ReLU, args=(False,)):
        super().__init__()
        assert n_convs > 0
        self.layers = nn.ModuleList()
        for _ in range(n_convs):
            self.layers.append(
                nn.Sequential(
                    nn.BatchNorm2d(n_channels),
                    activation(*args),
                    nn.ConvTranspose2d(n_channels, n_channels, 3, stride=1, padding=1, bias=False),
                )
            )

    def forward(self, inputs):
        outputs = []
        for i, layer in enumerate(self.layers):
            if i > 0:
                next_output = sum(outputs)
                outputs.append(layer(next_output))
            else:
                outputs.append(layer(inputs))
        return outputs[-1]


class DenseTransitionBlockEncoder(nn.Module):
    def __init__(self, n_channels_in, n_channels_out, mp, activation=nn.ReLU, args=(False,)):
        super().__init__()
        self.main = nn.Sequential(
            nn.BatchNorm2d(n_channels_in),
            activation(*args),
            nn.Conv2d(n_channels_in, n_channels_out, 1, stride=1, padding=0, bias=False),
            nn.MaxPool2d(mp),
        )

    def forward(self, x):
        return self.main(x)


class DenseTransitionBlockDecoder(nn.Module):
    def __init__(self, n_channels_in, n_channels_out, activation=nn.ReLU, args=(False,)):
        super().__init__()
        self.main = nn.Sequential(
            nn.BatchNorm2d(n_channels_in),
            activation(*args),
            nn.ConvTranspose2d(n_channels_in, n_channels_out, 4, stride=2, padding=1, bias=False),
        )

    def forward(self, x):
        return self.main(x)


class waspDenseEncoder128(nn.Module):
    def __init__(
        self, nc=1, ndf=32, ndim=128, activation=nn.LeakyReLU, args=(0.2, False), f_activation=nn.Tanh, f_args=()
    ):
        super().__init__()
        self.ndim = ndim
        self.main = nn.Sequential(
            nn.BatchNorm2d(nc),
            nn.ReLU(True),
            nn.Conv2d(nc, ndf, 4, stride=2, padding=1),
            DenseBlockEncoder(ndf, 6),
            DenseTransitionBlockEncoder(ndf, ndf * 2, 2, activation=activation, args=args),
            DenseBlockEncoder(ndf * 2, 12),
            DenseTransitionBlockEncoder(ndf * 2, ndf * 4, 2, activation=activation, args=args),
            DenseBlockEncoder(ndf * 4, 16),
            DenseTransitionBlockEncoder(ndf * 4, ndf * 8, 2, activation=activation, args=args),
            DenseBlockEncoder(ndf * 8, 16),
            DenseTransitionBlockEncoder(ndf * 8, ndf * 8, 2, activation=activation, args=args),
            DenseBlockEncoder(ndf * 8, 16),
            DenseTransitionBlockEncoder(ndf * 8, ndim, 4, activation=activation, args=args),
            f_activation(*f_args),
        )

    def forward(self, x):
        x = add_coordConv_channels(x)
        return self.main(x).view(-1, self.ndim)


class waspDenseDecoder128(nn.Module):
    def __init__(self, nz=128, nc=1, ngf=32, activation=nn.ReLU, args=(False,), f_activation=nn.Hardtanh, f_args=()):
        super().__init__()
        self.main = nn.Sequential(
            nn.BatchNorm2d(nz),
            activation(*args),
            nn.ConvTranspose2d(nz, ngf * 8, 4, 1, 0, bias=False),
            DenseBlockDecoder(ngf * 8, 16),
            DenseTransitionBlockDecoder(ngf * 8, ngf * 8),
            DenseBlockDecoder(ngf * 8, 16),
            DenseTransitionBlockDecoder(ngf * 8, ngf * 4),
            DenseBlockDecoder(ngf * 4, 12),
            DenseTransitionBlockDecoder(ngf * 4, ngf * 2),
            DenseBlockDecoder(ngf * 2, 6),
            DenseTransitionBlockDecoder(ngf * 2, ngf),
            DenseBlockDecoder(ngf, 6),
            DenseTransitionBlockDecoder(ngf, ngf),
            nn.BatchNorm2d(ngf),
            activation(*args),
            nn.ConvTranspose2d(ngf, nc, 3, stride=1, padding=1, bias=False),
            f_activation(*f_args),
        )

    def forward(self, x):
        return self.main(x)


class dnetccnl(nn.Module):
    def __init__(self, img_size=128, in_channels=1, out_channels=2, filters=32, fc_units=100):
        super().__init__()
        self.encoder = waspDenseEncoder128(nc=in_channels + 2, ndf=filters, ndim=img_size)
        self.decoder = waspDenseDecoder128(nz=img_size, nc=out_channels, ngf=filters)

    def forward(self, x):
        encoded = self.encoder(x)
        encoded = encoded.unsqueeze(-1).unsqueeze(-1)
        return self.decoder(encoded)
