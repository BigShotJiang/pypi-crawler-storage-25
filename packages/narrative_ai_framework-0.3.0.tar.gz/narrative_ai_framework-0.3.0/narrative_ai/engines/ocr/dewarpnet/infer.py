"""DewarpNet inference: image bytes in -> dewarped image bytes out."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional, Union

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .models import get_model
from .utils import convert_state_dict

logger = logging.getLogger(__name__)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
WC_IMG_SIZE = (256, 256)
BM_IMG_SIZE = (128, 128)
WC_N_CLASSES = 3
BM_N_CLASSES = 2


def _unwarp(img: np.ndarray, bm: torch.Tensor) -> np.ndarray:
    """Apply backward mapping to image. img: H,W,3 float 0-1 RGB; bm: model output."""
    h, w = img.shape[0], img.shape[1]
    bm = bm.transpose(1, 2).transpose(2, 3).detach().cpu().numpy()[0, :, :, :]
    bm0 = cv2.blur(bm[:, :, 0], (3, 3))
    bm1 = cv2.blur(bm[:, :, 1], (3, 3))
    bm0 = cv2.resize(bm0, (w, h))
    bm1 = cv2.resize(bm1, (w, h))
    bm_np = np.stack([bm0, bm1], axis=-1)
    bm_np = np.expand_dims(bm_np, 0)
    bm_t = torch.from_numpy(bm_np).double()

    img_f = img.astype(np.float64) / 255.0
    img_f = img_f.transpose((2, 0, 1))
    img_f = np.expand_dims(img_f, 0)
    img_t = torch.from_numpy(img_f).double()

    grid = bm_t.permute(0, 3, 1, 2)
    grid = grid * 2 - 1
    grid = grid.permute(0, 2, 3, 1)
    res = F.grid_sample(input=img_t, grid=grid, mode="bilinear", padding_mode="zeros", align_corners=False)
    res = res[0].numpy().transpose((1, 2, 0))
    return res


def _load_models(
    wc_model_path: str,
    bm_model_path: str,
    device: torch.device,
):
    """Load and return (wc_model, bm_model) for reuse."""
    wc_model = get_model("unetnc", n_classes=WC_N_CLASSES, in_channels=3)
    wc_state = torch.load(wc_model_path, map_location=device)  # nosec B614 - trusted model weights
    wc_state = convert_state_dict(wc_state.get("model_state", wc_state))
    wc_model.load_state_dict(wc_state, strict=True)
    wc_model.to(device).eval()

    bm_model = get_model("dnetccnl", n_classes=BM_N_CLASSES, in_channels=3)
    bm_state = torch.load(bm_model_path, map_location=device)  # nosec B614 - trusted model weights
    bm_state = convert_state_dict(bm_state.get("model_state", bm_state))
    bm_model.load_state_dict(bm_state, strict=True)
    bm_model.to(device).eval()
    return wc_model, bm_model


def run_dewarp_with_models(
    image_input: Union[bytes, str, Path],
    wc_model: nn.Module,
    bm_model: nn.Module,
    device: torch.device,
) -> bytes:
    """Run dewarp using pre-loaded models. Use this when calling repeatedly (e.g. from a filter)."""
    if isinstance(image_input, (str, Path)):
        with open(image_input, "rb") as f:
            raw = f.read()
    else:
        raw = image_input

    arr = np.frombuffer(raw, dtype=np.uint8)
    img_bgr = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img_bgr is None:
        raise ValueError("Failed to decode image")
    imgorg = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
    img = cv2.resize(imgorg, WC_IMG_SIZE)
    img = img[:, :, ::-1]
    img = img.astype(np.float32) / 255.0
    img = img.transpose(2, 0, 1)
    img = np.expand_dims(img, 0)
    img_t = torch.from_numpy(img).float().to(device)

    htan = nn.Hardtanh(0, 1.0)
    with torch.no_grad():
        wc_outputs = wc_model(img_t)
        pred_wc = htan(wc_outputs)
        bm_input = F.interpolate(pred_wc, size=BM_IMG_SIZE, mode="bilinear", align_corners=False)
        outputs_bm = bm_model(bm_input)

    uwpred = _unwarp(imgorg, outputs_bm)
    out_uint8 = (np.clip(uwpred, 0, 1) * 255).astype(np.uint8)
    out_bgr = cv2.cvtColor(out_uint8, cv2.COLOR_RGB2BGR)
    _, buf = cv2.imencode(".png", out_bgr)
    return buf.tobytes()


def run_dewarp(
    image_input: Union[bytes, str, Path],
    wc_model_path: str,
    bm_model_path: str,
    device: Optional[torch.device] = None,
) -> bytes:
    """
    Run DewarpNet on an image and return dewarped image as PNG bytes.
    Loads models from disk each time; for repeated use prefer loading once and using run_dewarp_with_models.

    Args:
        image_input: Image as bytes, or path to image file.
        wc_model_path: Path to unetnc_doc3d.pkl (shape network).
        bm_model_path: Path to dnetccnl_doc3d.pkl (texture mapping network).
        device: Torch device (default: cuda if available else cpu).

    Returns:
        PNG-encoded dewarped image bytes.
    """
    if device is None:
        device = DEVICE
    wc_model, bm_model = _load_models(wc_model_path, bm_model_path, device)
    return run_dewarp_with_models(image_input, wc_model, bm_model, device)
