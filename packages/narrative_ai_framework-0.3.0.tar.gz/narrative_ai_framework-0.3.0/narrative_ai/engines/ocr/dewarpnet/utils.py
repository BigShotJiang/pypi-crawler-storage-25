"""Minimal utils from DewarpNet (convert_state_dict only)."""

from collections import OrderedDict


def convert_state_dict(state_dict):
    """Convert state dict from DataParallel to normal module (remove 'module.' prefix)."""
    new_state_dict = OrderedDict()
    for k, v in state_dict.items():
        name = k[7:] if k.startswith("module.") else k
        new_state_dict[name] = v
    return new_state_dict
