import logging
import os
import yaml
import time
import io
import re
import numpy as np
from pathlib import Path
from typing import Union, Dict, Any, Optional, List

# Optional OpenCV import (required for OCR image processing)
try:
    import cv2

    _CV2_AVAILABLE = True
except ImportError:
    cv2 = None  # type: ignore[assignment]
    _CV2_AVAILABLE = False

# Internal imports
from .core import OCRFactory
from .filters import AbstractFilter  # noqa: F401 - load filters so registry has dewarpnet etc.

logger = logging.getLogger(__name__)

# Optional security integration - engines run exactly as today when unavailable
try:
    from narrative_ai.security.engine_integration import (
        check_rate_limit_for_engine,
        log_audit_for_engine_async,
    )
    from narrative_ai.security.rate_limiting import EndpointCosts, RateLimiter
    from narrative_ai.security.audit_trail import AuditLogger, ActionType
    from narrative_ai.security.error_handling import SecureErrorHandler

    _SECURITY_AVAILABLE = True
except ImportError:
    RateLimiter = None
    AuditLogger = None
    ActionType = None
    SecureErrorHandler = None
    _SECURITY_AVAILABLE = False

if not _SECURITY_AVAILABLE:
    logging.getLogger(__name__).warning("Security layer not available - OCR running without security integration")

if not _CV2_AVAILABLE:
    logging.getLogger(__name__).warning(
        "OpenCV (cv2) not available - OCR pipeline will fail on numpy array inputs. "
        "Install with: pip install opencv-python"
    )


class OCRPipeline:
    """
    Main controller for the OCR processing pipeline.

    This class orchestrates image preprocessing (dewarping, deshadowing, enhancement)
    and text extraction via internal or remote OCR engines.
    """

    def __init__(self, config_path: Optional[Union[str, Path]] = None):
        """
        Initialize the OCR Pipeline.
        """
        if config_path is None:
            config_path = Path(__file__).parent / "config" / "config.yaml"
        else:
            config_path = Path(config_path)

        with open(config_path, "r", encoding="utf-8") as f:
            raw_config = yaml.safe_load(f) or {}

        # Interpolate environment variables (e.g., ${KAGGLE_OCR_URL})
        self.config = self._interpolate_env_vars(raw_config)

        # 1. Initialize core OCR provider via Factory
        ocr_type = self.config.get("vlm_provider", {}).get("type", "remote_ocr")
        ocr_config = self.config.get("vlm_provider", {}).get("remote", {})
        self.ocr_tool = OCRFactory.create_provider(ocr_type, ocr_config)

        # 2. Initialize DocRes filter via Factory
        d_cfg = self.config.get("filters", {}).get("docres", {})
        filter_type = "remote_docres" if d_cfg.get("type") == "remote" else "local_docres"

        # Ensure remote filter gets the same base URL if not specified
        if filter_type == "remote_docres":
            remote_config = d_cfg.get("remote", {}).copy()
            if not remote_config.get("url"):
                remote_config["url"] = self.ocr_tool.url
            self.docres_filter = OCRFactory.create_filter(filter_type, remote_config)
        else:
            self.docres_filter = OCRFactory.create_filter(filter_type, d_cfg) if d_cfg.get("enabled") else None

        # 3. Optional DewarpNet filter for local dewarping (runs before DocRes for remaining tasks)
        dw_cfg = self.config.get("filters", {}).get("dewarp", {})
        if dw_cfg.get("enabled") and dw_cfg.get("type") == "dewarpnet":
            try:
                self.dewarp_filter = OCRFactory.create_filter("dewarpnet", dw_cfg)
            except Exception as e:
                logger.warning("DewarpNet filter not available: %s", e)
                self.dewarp_filter = None
        else:
            self.dewarp_filter = None

        self._rate_limiter = None
        self._audit_logger = None
        self._error_handler = None
        self._security_initialized = False

        logger.info("OCR Pipeline Initialized [SDK: ocr] [Provider: %s]", ocr_type)

    def _ensure_security_initialized(self) -> None:
        """Lazy-init rate limiter and audit logger when security is enabled."""
        if not _SECURITY_AVAILABLE or self._security_initialized:
            return
        int_cfg = self.config.get("integration", {}) or {}
        if not (
            int_cfg.get("enable_rate_limiting", False)
            or int_cfg.get("enable_audit_logging", False)
            or int_cfg.get("enable_error_handling", False)
        ):
            self._security_initialized = True
            return
        try:
            is_production = os.getenv("ENV", "").lower() == "production"
            skip_rate_limit = not is_production and os.getenv("VOICE_DEV_SKIP_RATE_LIMIT", "").strip() == "1"
            if int_cfg.get("enable_rate_limiting", False) and RateLimiter and not skip_rate_limit:
                self._rate_limiter = RateLimiter()
            if int_cfg.get("enable_audit_logging", False) and AuditLogger:
                audit_db_url = os.getenv("AUDIT_DATABASE_URL") or os.getenv("DATABASE_URL")
                if audit_db_url:
                    self._audit_logger = AuditLogger(database_url=audit_db_url)
                else:
                    logger.warning("Audit logging enabled but AUDIT_DATABASE_URL/DATABASE_URL not set")
            if int_cfg.get("enable_error_handling", False) and SecureErrorHandler:
                try:
                    self._error_handler = SecureErrorHandler()
                except Exception as e:
                    logger.warning("Secure error handler initialization failed: %s", e)
        except Exception as e:
            logger.warning("Security initialization failed: %s", e)
        self._security_initialized = True

    def _convert_document_to_images(self, file_content: bytes, extension: str) -> List[bytes]:
        images = []
        try:
            if extension.lower() == ".pdf":
                from pdf2image import convert_from_bytes

                pil_images = convert_from_bytes(file_content)
                for pil_img in pil_images:
                    buf = io.BytesIO()
                    pil_img.save(buf, format="PNG")
                    images.append(buf.getvalue())
        except Exception as e:
            logger.error("Error converting document: %s", e)
        return images

    def process(
        self,
        image_input: Union[str, Path, bytes],
        shadow_removal: bool = False,
        dewarping: bool = False,
        appearance: bool = False,
        enhancement: bool = False,
        deblurring: bool = False,
        binarization: bool = False,
        ocr: bool = True,
        filename: Optional[str] = None,
        user_id: Optional[Any] = None,
        tenant_id: Optional[Any] = None,
        _ordered_task: Optional[str] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Execute the full processing pipeline on an input image or document.
        """
        # Security: rate limit (when enabled)
        if _SECURITY_AVAILABLE:
            self._ensure_security_initialized()
            int_cfg = self.config.get("integration", {}) or {}
            if int_cfg.get("enable_rate_limiting", False) and self._rate_limiter:
                check_rate_limit_for_engine(
                    self._rate_limiter,
                    user_id,
                    tenant_id,
                    EndpointCosts.OCR_PROCESS,
                    "anon.engine.ocr",
                    user_tier_callback=int_cfg.get("user_tier_callback"),
                )

        try:
            start_time = time.time()
            timings = {}
            processed_image = image_input
            # 0. Extension Normalization
            if isinstance(image_input, (str, Path)):
                with open(image_input, "rb") as f:
                    processed_image = f.read()
                ext = Path(image_input).suffix.lower()
            elif isinstance(image_input, np.ndarray):
                if not _CV2_AVAILABLE:
                    raise ImportError(
                        "OpenCV (cv2) is required for numpy array image input. Install with: pip install opencv-python"
                    )
                success, encoded_img = cv2.imencode(".png", image_input)
                if success:
                    processed_image = encoded_img.tobytes()
                ext = ".png"
            elif filename:
                ext = Path(filename).suffix.lower()
            else:
                ext = ".png"

            # 1. Document Handling: Convert PDF to images if needed
            if ext == ".pdf":
                pages = self._convert_document_to_images(processed_image, ext)
                if pages:
                    processed_image = pages[0]

            # 2. Restoration & OCR Optimization (SMART COMBINED)
            # Processed_image is now raw bytes (could be PNG, JPG, WEBP, etc.)
            needs_processing = dewarping or shadow_removal or appearance or enhancement or deblurring or binarization

            # Optimization: Use combined endpoint if both processing and OCR are requested
            # AND we are using a remote filter that supports it. Skip combined when using
            # local DewarpNet for dewarp (we do sequential: DewarpNet then docres then OCR).
            # Note: Combined logic on server usually does end2end (restoration + dewarp),
            # but doesn't handle binarization in the same pass.
            use_combined = (
                ocr
                and needs_processing
                and not binarization
                and self.docres_filter is not None
                and hasattr(self.docres_filter, "apply_combined")
                and not (dewarping and self.dewarp_filter)
            )
            if use_combined:
                p_start = time.time()
                # Use user-ordered task if provided, otherwise auto-determine
                task = (
                    _ordered_task
                    if _ordered_task
                    else self._determine_task(dewarping, shadow_removal, appearance, binarization, deblurring)
                )

                logger.info("SDK: Using Smart Combined Endpoint (Task: %s)", task)
                result = self.docres_filter.apply_combined(processed_image, task=task, filename=filename)

                p_end = time.time()
                timings["Restoration + OCR"] = p_end - p_start
                timings["Total"] = p_end - start_time
                success = bool(result.get("text"))

                # Security: audit (when enabled)
                if _SECURITY_AVAILABLE:
                    int_cfg = self.config.get("integration", {}) or {}
                    if int_cfg.get("enable_audit_logging", False) and self._audit_logger:
                        log_audit_for_engine_async(
                            self._audit_logger,
                            user_id,
                            tenant_id,
                            ActionType.OCR_PROCESS,
                            "ocr",
                            "success" if success else "failure",
                            {"task": task, "has_text": success},
                            resource_id=None,
                            engine_namespace="anon.engine.ocr",
                        )

                return {
                    "text": result.get("text", ""),
                    "processed_image": result.get("processed_image"),
                    "timings": timings,
                    "success": success,
                }

            # 3. Sequential Processing (Fallback or Complex Combo)
            if needs_processing:
                p_start = time.time()

                # Use user-defined ordered task string if provided (from Streamlit UI)
                if _ordered_task:
                    logger.info("SDK: Using user-ordered pipeline: %s", _ordered_task)
                    processed_image = self.docres_filter.apply(processed_image, task=_ordered_task, filename=filename)
                else:
                    # Phase 1a: Local DewarpNet for dewarp when configured
                    if dewarping and self.dewarp_filter:
                        logger.info("SDK: Phase 1a - Applying DewarpNet (dewarp)")
                        processed_image = self.dewarp_filter.apply(processed_image, task="dewarp", filename=filename)

                    # Phase 1b: DocRes for dewarp (if not done by DewarpNet), deshadow, appearance, deblur
                    needs_docres = (
                        (dewarping and not self.dewarp_filter)
                        or shadow_removal
                        or appearance
                        or enhancement
                        or deblurring
                    )
                    if needs_docres and self.docres_filter:
                        task = self._determine_task(
                            dewarping and not self.dewarp_filter,
                            shadow_removal,
                            appearance,
                            False,
                            deblurring,
                        )
                        logger.info("SDK: Phase 1b - Applying %s", task)
                        processed_image = self.docres_filter.apply(processed_image, task=task, filename=filename)

                    # Phase 2: Binarization (applied to result of Phase 1 or initial image)
                    if binarization and self.docres_filter:
                        logger.info("SDK: Phase 2 - Applying Binarization")
                        processed_image = self.docres_filter.apply(processed_image, task="binarize", filename=filename)

                timings["Restoration"] = time.time() - p_start

            text = ""
            if ocr:
                ocr_start = time.time()
                text = self.ocr_tool.extract_text(processed_image, filename=filename)
                timings["OCR"] = time.time() - ocr_start

            timings["Total"] = time.time() - start_time
            success = not text.startswith("Error:")

            # Security: audit (when enabled)
            if _SECURITY_AVAILABLE:
                int_cfg = self.config.get("integration", {}) or {}
                if int_cfg.get("enable_audit_logging", False) and self._audit_logger:
                    log_audit_for_engine_async(
                        self._audit_logger,
                        user_id,
                        tenant_id,
                        ActionType.OCR_PROCESS,
                        "ocr",
                        "success" if success else "failure",
                        {"has_text": success, "needs_processing": needs_processing},
                        resource_id=None,
                        engine_namespace="anon.engine.ocr",
                    )

            return {
                "text": text,
                "processed_image": processed_image if needs_processing else None,
                "timings": timings,
                "success": success,
            }
        except Exception as e:
            if _SECURITY_AVAILABLE:
                int_cfg = self.config.get("integration", {}) or {}
                if int_cfg.get("enable_audit_logging", False) and self._audit_logger:
                    log_audit_for_engine_async(
                        self._audit_logger,
                        user_id,
                        tenant_id,
                        ActionType.OCR_PROCESS,
                        "ocr",
                        "failure",
                        {"error": str(e), "type": type(e).__name__},
                        resource_id=None,
                        engine_namespace="anon.engine.ocr",
                    )
                if self._error_handler:
                    try:
                        self._error_handler.handle_error(e, user_id, tenant_id)
                    except Exception as handler_error:
                        logger.warning("Error handler failed: %s", handler_error)
            raise

    def _determine_task(
        self, dewarping: bool, shadow_removal: bool, appearance: bool, binarization: bool, deblurring: bool = False
    ) -> str:
        """Helper to map boolean flags to backend task names. Supporting composite tasks."""
        tasks = []
        if dewarping:
            tasks.append("dewarp")
        if shadow_removal:
            tasks.append("deshadow")
        if appearance:
            tasks.append("appearance")
        if deblurring:
            tasks.append("deblur")
        if binarization:
            tasks.append("binarize")

        # If no specific flags but restoration mentioned, use restoration
        if not tasks:
            return "restoration"

        # Special case for 'restoration' backward compatibility
        if shadow_removal and appearance and not dewarping and not binarization and not deblurring:
            return "restoration"

        return "+".join(tasks)

    def update_service_url(self, new_url: str) -> None:
        clean_url = new_url.rstrip("/")
        if hasattr(self.ocr_tool, "url"):
            self.ocr_tool.url = clean_url
        if hasattr(self.docres_filter, "url"):
            self.docres_filter.url = clean_url
        logger.info("SDK: Service URL updated to: %s", clean_url)

    @staticmethod
    def _interpolate_env_vars(obj: Any) -> Any:
        """
        Recursively interpolate environment variables in config values.
        Supports ${VAR_NAME} and ${VAR_NAME:-default} syntax.
        """
        if isinstance(obj, dict):
            return {k: OCRPipeline._interpolate_env_vars(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [OCRPipeline._interpolate_env_vars(item) for item in obj]
        elif isinstance(obj, str):
            # Pattern: ${VAR_NAME} or ${VAR_NAME:-default}
            pattern = r"\$\{([^}:]+)(?::-([^}]*))?\}"

            def replace_var(match):
                var_name = match.group(1)
                default = match.group(2) if match.group(2) is not None else ""
                val = os.environ.get(var_name, default)
                # print(f"DEBUG: Interpolating {var_name}, result: {val}")
                return val

            return re.sub(pattern, replace_var, obj)
        return obj
