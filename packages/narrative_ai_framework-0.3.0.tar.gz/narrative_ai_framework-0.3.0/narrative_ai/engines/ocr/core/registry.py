from typing import Dict, Type


class OCRRegistry:
    """
    Centralized registry for OCR components (Providers, Filters, etc.).
    Enables dynamic registration and retrieval without circular imports.
    """

    def __init__(self):
        self._providers: Dict[str, Type] = {}
        self._filters: Dict[str, Type] = {}

    def register_provider(self, name: str):
        """Decorator to register an OCR Provider class."""

        def wrapper(cls: Type):
            self._providers[name] = cls
            return cls

        return wrapper

    def register_filter(self, name: str):
        """Decorator to register an Image Filter class."""

        def wrapper(cls: Type):
            self._filters[name] = cls
            return cls

        return wrapper

    def get_provider(self, name: str):
        """Retrieve a provider class by name."""
        if name not in self._providers:
            raise ValueError(f"Provider '{name}' not found in registry. Available: {list(self._providers.keys())}")
        return self._providers[name]

    def get_filter(self, name: str):
        """Retrieve a filter class by name."""
        if name not in self._filters:
            raise ValueError(f"Filter '{name}' not found in registry. Available: {list(self._filters.keys())}")
        return self._filters[name]


# Global registry instance
registry = OCRRegistry()
