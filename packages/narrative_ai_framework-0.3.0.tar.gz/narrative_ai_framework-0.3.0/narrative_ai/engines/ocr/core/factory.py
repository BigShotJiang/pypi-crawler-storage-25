from typing import Dict, Any
from .registry import registry


class OCRFactory:
    """
    Factory class to create OCR components using the dynamic registry.
    """

    @staticmethod
    def create_filter(filter_type: str, config: Dict[str, Any]):
        """Creates a filter based on registered types."""
        filter_cls = registry.get_filter(filter_type)
        return filter_cls(config)

    @staticmethod
    def create_provider(provider_type: str, config: Dict[str, Any]):
        """Creates an OCR provider based on registered types."""
        provider_cls = registry.get_provider(provider_type)
        return provider_cls(config)
