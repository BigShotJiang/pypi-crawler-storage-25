from typing import Union
from pathlib import Path
import asyncio
import numpy as np
# Removed top-level import to break circular dependency
# from ..pipeline import OCRPipeline

# --- Functional API (Standalone Helpers) ---

_default_pipeline = None


def _get_pipeline():
    global _default_pipeline
    if _default_pipeline is None:
        from ..pipeline import OCRPipeline
        _default_pipeline = OCRPipeline()
    return _default_pipeline


def ocr(image: Union[str, Path, bytes, np.ndarray], **kwargs) -> str:
    """Extract text from an image (sync). Use ocr_async from async code to avoid blocking the event loop."""
    result = _get_pipeline().process(image, ocr=True, **kwargs)
    return result.get("text", "")


async def ocr_async(image: Union[str, Path, bytes, np.ndarray], **kwargs) -> str:
    """Async wrapper for OCR. Runs sync pipeline in a thread so the event loop is not blocked."""
    return await asyncio.to_thread(ocr, image, **kwargs)


def restoration(image: Union[str, Path, bytes, np.ndarray], **kwargs) -> bytes:
    """Apply full restoration (deshadow + appearance) to an image."""
    result = _get_pipeline().process(image, ocr=False, shadow_removal=True, appearance=True, **kwargs)
    return result.get("processed_image")


def dewarp(image: Union[str, Path, bytes, np.ndarray], **kwargs) -> bytes:
    """Apply dewarping to an image."""
    result = _get_pipeline().process(image, ocr=False, dewarping=True, **kwargs)
    return result.get("processed_image")


def deshadow(image: Union[str, Path, bytes, np.ndarray], **kwargs) -> bytes:
    """Apply deshadowing to an image."""
    result = _get_pipeline().process(image, ocr=False, shadow_removal=True, **kwargs)
    return result.get("processed_image")


def enhance(image: Union[str, Path, bytes, np.ndarray], **kwargs) -> bytes:
    """Apply appearance enhancement to an image."""
    result = _get_pipeline().process(image, ocr=False, appearance=True, **kwargs)
    return result.get("processed_image")


def binarize(image: Union[str, Path, bytes, np.ndarray], **kwargs) -> bytes:
    """Apply binarization to an image."""
    result = _get_pipeline().process(image, ocr=False, binarization=True, **kwargs)
    return result.get("processed_image")
