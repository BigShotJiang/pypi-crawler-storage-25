import cv2
import numpy as np
from skimage.filters import threshold_sauvola


def get_base_coord(h: int, w: int) -> np.ndarray:
    """Generate base coordinate grid for dewarping."""
    c0 = np.tile(np.arange(h).reshape(h, 1), (1, w)).astype(np.float32)
    c1 = np.tile(np.arange(w).reshape(1, w), (h, 1)).astype(np.float32)
    return np.concatenate((np.expand_dims(c1, -1), np.expand_dims(c0, -1)), -1)


def generate_deshadow_prompt(img: np.ndarray, target_size: int = 1024) -> np.ndarray:
    """Generate the background estimation prompt for deshadowing."""
    h, w = img.shape[:2]
    prompt_res = cv2.resize(img, (target_size, target_size))
    # Median blur on dilated channels estimates the background lighting
    bg = cv2.merge([cv2.medianBlur(cv2.dilate(p, np.ones((7, 7), np.uint8)), 21) for p in cv2.split(prompt_res)])
    return cv2.resize(bg, (w, h))


def generate_appearance_prompt(img: np.ndarray, target_size: int = 1024) -> np.ndarray:
    """Generate the background normalization prompt for appearance enhancement."""
    h, w = img.shape[:2]
    prompt_res = cv2.resize(img, (target_size, target_size))
    # Normalize difference between image and background (dilated/blurred)
    res = [
        cv2.normalize(
            255 - cv2.absdiff(p, cv2.medianBlur(cv2.dilate(p, np.ones((7, 7), np.uint8)), 21)),
            None,
            0,
            255,
            cv2.NORM_MINMAX,
            cv2.CV_8UC1,
        )
        for p in cv2.split(prompt_res)
    ]
    return cv2.resize(cv2.merge(res), (w, h))


def reconstruct_from_ratio(original_img: np.ndarray, pred_img: np.ndarray) -> np.ndarray:
    """
    Reconstruct the high-res image using the ratio between original and prediction.
    This preserves local texture while applying the model's global corrections.
    """
    h, w = original_img.shape[:2]
    ph, pw = pred_img.shape[:2]

    # Ensure prediction is same size as what was processed (e.g. 1600x1600 if that was used)
    # The ratio math is: Result = Original / (ResizedOriginal / Prediction)
    # This effectively scales the illumination change back up to original resolution.

    pred_np = pred_img.copy()
    pred_np[pred_np == 0] = 1  # Avoid division by zero

    # Calculate ratio at prediction resolution
    resized_orig = cv2.resize(original_img, (pw, ph)).astype(float)
    ratio_at_pred = resized_orig / pred_np.astype(float)

    # Scale ratio up to original resolution
    ratio_highres = cv2.resize(ratio_at_pred, (w, h))

    return np.clip(original_img.astype(float) / (ratio_highres + 1e-5), 0, 255).astype(np.uint8)


def generate_binarization_prompt(img: np.ndarray) -> np.ndarray:
    """Generate binarization guidance prompt (Sauvola + Sobel edges)."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    n1 = int(0.05 * min(img.shape[:2])) | 1
    T1 = threshold_sauvola(gray, window_size=n1, k=0.5)

    # Contrast map
    C = np.zeros_like(gray, dtype=np.float32)
    m = gray > T1
    C[m] = (gray[m] - T1[m]) / (np.amax(gray) - T1[m] + 1e-6)

    # Global binary map from Sauvola
    T2 = threshold_sauvola((C * 255).astype(np.uint8), window_size=n1 * 2 | 1, k=0.5)
    binary = np.where((C * 255) > T2, 255, 0).astype(np.uint8)

    # Sobel edges
    x = cv2.Sobel(img, cv2.CV_16S, 1, 0)
    y = cv2.Sobel(img, cv2.CV_16S, 0, 1)
    edge = cv2.addWeighted(cv2.convertScaleAbs(x), 0.5, cv2.convertScaleAbs(y), 0.5, 0)
    if len(edge.shape) == 3:
        edge = cv2.cvtColor(edge, cv2.COLOR_BGR2GRAY)

    # Prompt is 3-channel: [Binary, Edge, 0]
    prompt = np.zeros_like(img)
    prompt[:, :, 0] = binary
    prompt[:, :, 1] = edge
    return prompt


def get_dewarp_flow(img: np.ndarray, pred: np.ndarray) -> np.ndarray:
    """Convert model prediction into a geometric remap flow."""
    h, w = img.shape[:2]
    # pred usually comes back as normalized coords [0,1]
    # We add base grid and scale to pixel indices
    base_grid = get_base_coord(256, 256) / 256

    flow_coords = pred[..., :2] + base_grid
    flow_px = cv2.resize(flow_coords, (w, h)) * (w, h)

    # Smooth the flow to avoid artifacts
    for _ in range(15):
        flow_px = cv2.blur(flow_px, (3, 3), borderType=cv2.BORDER_REPLICATE)

    return flow_px
