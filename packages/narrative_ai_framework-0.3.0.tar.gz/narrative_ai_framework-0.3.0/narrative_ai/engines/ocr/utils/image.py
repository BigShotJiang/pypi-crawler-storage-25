import numpy as np
import io
from pathlib import Path
from typing import Union
from PIL import Image


def read_image_as_numpy(image_input: Union[str, Path, bytes, np.ndarray]) -> np.ndarray:
    """Convert input to NumPy array (RGB)."""
    if isinstance(image_input, np.ndarray):
        return image_input

    img = None
    if isinstance(image_input, (str, Path)):
        img = Image.open(str(image_input))
    elif isinstance(image_input, bytes):
        img = Image.open(io.BytesIO(image_input))

    if img:
        return np.array(img.convert("RGB"))
    raise ValueError("Unsupported format")


def convert_numpy_to_bytes(image_np: np.ndarray, format="PNG") -> bytes:
    """Convert NumPy array to bytes."""
    img = Image.fromarray(image_np)
    buf = io.BytesIO()
    img.save(buf, format=format)
    return buf.getvalue()
