import cv2
import numpy as np


def whiten_background(image: np.ndarray) -> np.ndarray:
    """
    Advanced background whitening and contrast enhancement for documents.

    Args:
        image: Input image as NumPy array (BGR).

    Returns:
        np.ndarray: Whitened and enhanced image.
    """
    if image is None:
        return None

    # 1. Convert to YUV to separate luminance
    yuv = cv2.cvtColor(image, cv2.COLOR_BGR2YUV)
    y, u, v = cv2.split(yuv)

    # 2. Adaptive Background Leveling
    # This helps remove uneven lighting and makes the background more uniform
    kernel_size = 31
    blurred = cv2.GaussianBlur(y, (kernel_size, kernel_size), 0)

    # Normalized luminance: y = (y / blurred) * 255
    normalized = cv2.divide(y, blurred, scale=255)

    # 3. Pull high values to pure white
    # We use a threshold to identify what's likely background
    _, mask = cv2.threshold(normalized, 220, 255, cv2.THRESH_BINARY)

    # 4. Final normalization tweak: Stretch range to [0, 255]
    final_y = cv2.normalize(normalized, None, 0, 255, cv2.NORM_MINMAX)

    # Reconstruct BGR
    yuv_final = cv2.merge([final_y, u, v])
    res = cv2.cvtColor(yuv_final, cv2.COLOR_YUV2BGR)

    # 5. Global Brightness/Contrast Boost
    # alpha (contrast) and beta (brightness)
    alpha = 1.1
    beta = 10
    res = cv2.convertScaleAbs(res, alpha=alpha, beta=beta)

    return res


def prepare_docres_input(image: np.ndarray, target_size: int = 1024) -> np.ndarray:
    """
    Prepares the background prompt for DocRes deshadowing.
    """
    img_r = cv2.resize(image, (target_size, target_size))
    # Create the background/shadow estimation
    bg = cv2.merge([cv2.medianBlur(cv2.dilate(p, np.ones((7, 7), np.uint8)), 21) for p in cv2.split(img_r)])
    return bg


def adjust_color_balance(image: np.ndarray) -> np.ndarray:
    """
    Simple color balance adjustment to remove tints.
    """
    result = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
    avg_a = np.average(result[:, :, 1])
    avg_b = np.average(result[:, :, 2])
    result[:, :, 1] = result[:, :, 1] - ((avg_a - 128) * (result[:, :, 0] / 255.0) * 1.1)
    result[:, :, 2] = result[:, :, 2] - ((avg_b - 128) * (result[:, :, 0] / 255.0) * 1.1)
    return cv2.cvtColor(result, cv2.COLOR_LAB2BGR)
