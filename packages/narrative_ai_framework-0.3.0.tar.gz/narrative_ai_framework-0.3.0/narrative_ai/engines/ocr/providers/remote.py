import requests
import io
from pathlib import Path
from typing import Union, Dict, Any, Optional
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from ..core import registry  # noqa: E402


@registry.register_provider("remote_ocr")
class RemoteOCR:
    """
    Client for interacting with a remote OCR service.

    This class handles communication with the remote Qwen2.5-VL server,
    including health checks and text extraction.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the Remote OCR client.

        Args:
            config: Configuration dictionary containing service 'url',
                   'timeout', 'headers', and 'verify_ssl'.
        """
        raw_url = config.get("url", "")
        self.url = raw_url.strip().rstrip("/") if raw_url else ""
        self.timeout = config.get("timeout", 60)
        self.headers = config.get("headers", {})
        self.verify_ssl = config.get("verify_ssl", True)

        # Use session to maintain cookies (for ngrok)
        self.session = requests.Session()
        self.session.headers.update(self.headers)

        if not self.url:
            print("Warning: No OCR URL provided in configuration.")

    def is_available(self) -> bool:
        """
        Check if the remote OCR server is reachable and healthy.

        Returns:
            bool: True if the server returns a 200 status code, False otherwise.
        """
        if not self.url:
            return False
        try:
            response = self.session.get(f"{self.url}/health", timeout=5, verify=self.verify_ssl)
            return response.status_code == 200
        except Exception:
            return False

    def extract_text(self, image_input: Union[str, Path, bytes, io.BytesIO], filename: Optional[str] = None) -> str:
        """
        Send an image to the remote server and extract its text content.

        Args:
            image_input: The image to process. Can be a file path (str/Path),
                         raw image bytes, or a BytesIO object.

        Returns:
            str: The extracted text or an error message starting with "Error:".
        """
        if not self.url:
            return "Error: Remote OCR URL not configured."

        files = {}
        file_to_close: Optional[io.IOBase] = None

        try:
            import mimetypes

            mime_type = "image/png"
            ext = ".png"

            if isinstance(image_input, (str, Path)):
                file_path = Path(image_input)
                if not file_path.exists():
                    return f"Error: File not found at {file_path}"
                ext = file_path.suffix.lower()
                mime_type, _ = mimetypes.guess_type(f"temp{ext}")
                if not mime_type:
                    mime_map = {
                        ".webp": "image/webp",
                        ".tiff": "image/tiff",
                        ".tif": "image/tiff",
                        ".bmp": "image/bmp",
                        ".heic": "image/heic",
                        ".heif": "image/heif",
                    }
                    mime_type = mime_map.get(ext, "image/png")
                file_to_close = open(file_path, "rb")
                file_to_close.seek(0)
                files = {"file": (f"image{ext}", file_to_close, mime_type)}
            elif isinstance(image_input, io.BytesIO):
                image_input.seek(0)
                if filename:
                    ext = Path(filename).suffix.lower()
                    mime_type, _ = mimetypes.guess_type(f"temp{ext}")
                    if not mime_type:
                        mime_map = {
                            ".webp": "image/webp",
                            ".tiff": "image/tiff",
                            ".tif": "image/tiff",
                            ".bmp": "image/bmp",
                            ".heic": "image/heic",
                            ".heif": "image/heif",
                        }
                        mime_type = mime_map.get(ext, "image/png")
                else:
                    mime_type = "image/png"
                    ext = ".png"
                files = {"file": (f"image{ext}", image_input, mime_type)}
            else:
                # Numpy array (e.g. from pipeline after docres/dewarp): encode to PNG bytes
                try:
                    import numpy as np

                    if isinstance(image_input, np.ndarray):
                        import cv2

                        success, buf = cv2.imencode(".png", image_input)
                        if not success:
                            return "Error: Failed to encode image for OCR"
                        image_input = buf.tobytes()
                        ext = ".png"
                        mime_type = "image/png"
                        files = {"file": (f"image{ext}", image_input, mime_type)}
                    else:
                        raise TypeError("not ndarray")
                except (TypeError, ImportError):
                    # Assume raw bytes
                    if filename:
                        ext = Path(filename).suffix.lower()
                        mime_type, _ = mimetypes.guess_type(f"temp{ext}")
                        if not mime_type:
                            mime_map = {
                                ".webp": "image/webp",
                                ".tiff": "image/tiff",
                                ".tif": "image/tiff",
                                ".bmp": "image/bmp",
                                ".heic": "image/heic",
                                ".heif": "image/heif",
                            }
                            mime_type = mime_map.get(ext, "image/png")
                    else:
                        mime_type = "image/png"
                        ext = ".png"
                    files = {"file": (f"image{ext}", image_input, mime_type)}

            ocr_url = f"{self.url}/ocr"
            print(f"🔍 Calling OCR URL: {ocr_url}")
            print(f"🔍 Headers: {self.headers}")
            print(f"🔍 Verify SSL: {self.verify_ssl}")

            # Debug input size
            if "file" in files:
                f_val = files["file"]
                if isinstance(f_val, tuple):
                    # (filename, content, type)
                    content = f_val[1]
                    if isinstance(content, (bytes, bytearray)):
                        print(f"🔍 OCR Input: {type(content)} of size {len(content)}")
                        print(f"🔍 OCR Input Preview: {content[:20]}")
                    elif hasattr(content, "getvalue"):  # BytesIO
                        content.seek(0, 2)
                        size = content.tell()
                        content.seek(0)
                        print(f"🔍 OCR Input: BytesIO of size {size}")
                    else:
                        print(f"🔍 OCR Input: Unknown content type {type(content)}")
                else:
                    # File object
                    print(f"🔍 OCR Input: File object {type(f_val)}")

            # CRITICAL FIX: Server requires 'prompt' parameter (not optional)
            # This was causing the 422 "Field required" error
            data = {"prompt": "اقرأ النص الموجود في الصورة بدقة"}

            response = self.session.post(
                ocr_url,
                files=files,
                data=data,  # Add the required prompt
                timeout=self.timeout,
                verify=self.verify_ssl,
            )

            print(f"🔍 OCR Response Status: {response.status_code}")
            print(f"🔍 OCR Response Headers: {dict(response.headers)}")

            if response.status_code == 200:
                result = response.json()
                print(f"✅ OCR Success: {result}")
                return result.get("text", "").strip()

            print(f"❌ OCR Error Response: {response.text[:500]}")
            try:
                err_body = response.json()
                msg = err_body.get("error") or err_body.get("message") or err_body.get("detail") or response.text[:200]
                if isinstance(msg, dict):
                    msg = msg.get("message", str(msg))
                return f"Error: OCR server returned {response.status_code} - {msg}"
            except Exception:
                return f"Error: Server returned status code {response.status_code}"

        except requests.exceptions.RequestException as e:
            print(f"❌ OCR Connection Error: {str(e)}")
            return f"Error: Connection to remote OCR failed - {str(e)}"
        except Exception as e:
            print(f"❌ OCR Unexpected Error: {str(e)}")
            return f"Error: An unexpected error occurred during OCR - {str(e)}"
        finally:
            if file_to_close:
                file_to_close.close()
