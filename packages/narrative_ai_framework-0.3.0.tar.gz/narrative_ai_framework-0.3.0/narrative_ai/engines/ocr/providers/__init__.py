from .remote import RemoteOCR

__all__ = ["RemoteOCR"]
