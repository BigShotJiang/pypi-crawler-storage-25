import sys
from pathlib import Path

# Add engines to path
sys.path.append(str(Path(__file__).resolve().parent.parent.parent))

try:
    from narrative_ai.engines.ocr.pipeline import OCRPipeline  # noqa: E402

    # Initialize pipeline
    pipeline = OCRPipeline()

    # Simulate a WebP file (even if it's just bytes of a PNG for testing the protocol)
    test_bytes = b"fake_image_data_simulating_webp"
    test_filename = "test_document.webp"

    print(f"🚀 Testing SDK with universal format: {test_filename}")

    # Since we are in a headless environment and don't have a real WebP,
    # we just want to verify that the SDK doesn't crash and sends the right metadata.
    # We will mock the requests.post to see what's being sent.

    from unittest.mock import patch, MagicMock

    with patch("requests.post") as mock_post:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"text": "Success", "processed_image": ""}
        mock_response.content = b"processed_image_bytes"
        mock_post.return_value = mock_response

        # Test Process
        result = pipeline.process(test_bytes, dewarping=True, ocr=True, filename=test_filename)

        # Verify the calls
        for call in mock_post.call_args_list:
            args, kwargs = call
            files = kwargs.get("files", {})
            if "file" in files:
                fname, fcontent, ftype = files["file"]
                print(f"✅ SDK sent file: {fname} with MIME: {ftype}")
                if ".webp" in fname and "image/webp" in ftype:
                    print("🏆 SUCCESS: SDK correctly identified and sent the WebP format!")
                else:
                    print(f"⚠️ SDK sent {fname} as {ftype} (Expected .webp / image/webp)")

except Exception as e:
    print(f"❌ Test Failed: {e}")
    import traceback

    traceback.print_exc()
