import requests
import cv2
import numpy as np

# Config
URL = "https://db97-35-226-203-135.ngrok-free.app"
HEADERS = {"ngrok-skip-browser-warning": "1"}


def test_endpoint(name, endpoint, payload=None, files=None):
    print(f"\nTesting {name} ({endpoint})...")
    try:
        response = requests.post(
            f"{URL}/{endpoint}",
            headers=HEADERS,
            data=payload,
            files=files,
            timeout=120,
        )
        print(f"Status Code: {response.status_code}")
        if response.status_code == 200:
            print("SUCCESS! Response received.")
            if endpoint == "ocr":
                print(f"OCR Result: {response.json()}")
            else:
                print(f"DocRes Response Size: {len(response.content)} bytes")
        else:
            print(f"FAILURE. Error: {response.text}")
    except Exception as e:
        print(f"EXCEPTION: {e}")


# Create dummy image
img = np.zeros((100, 100, 3), dtype=np.uint8)
cv2.putText(img, "Test", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
_, img_encoded = cv2.imencode(".png", img)
img_bytes = img_encoded.tobytes()

# Test 1: Health
print(f"Checking Health at {URL}/health...")
try:
    resp = requests.get(f"{URL}/health", headers=HEADERS, timeout=10)
    print(f"Health: {resp.status_code} - {resp.text}")
except Exception as e:
    print(f"Health Check Failed: {e}")

# Test 2: DocRes (Appearance)
test_endpoint(
    "DocRes Appearance", "docres", payload={"task": "appearance"}, files={"file": ("test.png", img_bytes, "image/png")}
)

# Test 3: OCR
test_endpoint("OCR", "ocr", files={"file": ("test.png", img_bytes, "image/png")})
