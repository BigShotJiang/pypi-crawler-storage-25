import unittest
from unittest.mock import patch, MagicMock
from narrative_ai.engines.ocr.pipeline import OCRPipeline


class TestOCRPipeline(unittest.TestCase):
    @patch("builtins.open", new_callable=MagicMock)
    @patch("yaml.safe_load")
    @patch("narrative_ai.engines.ocr.providers.remote.RemoteOCR")
    def test_pipeline_init(self, mock_remote, mock_yaml, mock_open):
        mock_yaml.return_value = {
            "vlm_provider": {"remote": {"url": "http://test.com"}},
            "filters": {"docres": {"enabled": False}},
        }

        pipeline = OCRPipeline(config_path="/fake/config.yaml")
        self.assertIsNotNone(pipeline.ocr_tool)

    @patch("narrative_ai.engines.ocr.pipeline.OCRPipeline.__init__", return_value=None)
    def test_process_flow(self, mock_init):
        pipeline = OCRPipeline()
        pipeline.ocr_tool = MagicMock()
        pipeline.ocr_tool.extract_text.return_value = "extracted text"
        pipeline.docres_filter = None
        pipeline._security_initialized = False
        pipeline._security_available = False
        pipeline.config = {"vlm_provider": {"remote": {"url": "http://test.com"}}}

        result = pipeline.process(b"image", ocr=True)

        self.assertEqual(result["text"], "extracted text")
        self.assertTrue(pipeline.ocr_tool.extract_text.called)

    @patch("narrative_ai.engines.ocr.pipeline.OCRPipeline.__init__", return_value=None)
    def test_update_url(self, mock_init):
        pipeline = OCRPipeline()
        pipeline.ocr_tool = MagicMock()
        pipeline.docres_filter = MagicMock()
        pipeline._security_initialized = False

        pipeline.update_service_url("http://new-url.com")
        self.assertEqual(pipeline.ocr_tool.url, "http://new-url.com")
        self.assertEqual(pipeline.docres_filter.url, "http://new-url.com")
