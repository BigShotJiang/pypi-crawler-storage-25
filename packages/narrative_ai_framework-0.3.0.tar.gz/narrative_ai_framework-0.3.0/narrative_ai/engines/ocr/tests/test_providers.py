import unittest
from unittest.mock import patch
from narrative_ai.engines.ocr.providers.remote import RemoteOCR


class TestRemoteOCR(unittest.TestCase):
    def setUp(self):
        self.config = {"url": "http://fake-ocr.com", "timeout": 10}
        self.ocr = RemoteOCR(self.config)

    def test_is_available_success(self):
        with patch.object(self.ocr.session, "get") as mock_get:
            mock_get.return_value.status_code = 200
            self.assertTrue(self.ocr.is_available())

    def test_is_available_fail(self):
        with patch.object(self.ocr.session, "get") as mock_get:
            mock_get.side_effect = Exception("Connection Error")
            self.assertFalse(self.ocr.is_available())

    def test_extract_text_success(self):
        with patch.object(self.ocr.session, "post") as mock_post:
            mock_post.return_value.status_code = 200
            mock_post.return_value.json.return_value = {"text": "Hello World"}

            result = self.ocr.extract_text(b"some-image-bytes")
            self.assertEqual(result, "Hello World")
            self.assertTrue(mock_post.called)

    def test_extract_text_server_error(self):
        with patch.object(self.ocr.session, "post") as mock_post:
            mock_post.return_value.status_code = 500
            result = self.ocr.extract_text(b"bytes")
            self.assertIn("Error: OCR server returned 500", result)
