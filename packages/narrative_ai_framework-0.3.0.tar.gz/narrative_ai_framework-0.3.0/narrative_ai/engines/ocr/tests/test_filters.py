import unittest
from unittest.mock import patch
from narrative_ai.engines.ocr.filters.docres_filter import DocResFilter


class TestDocResFilter(unittest.TestCase):
    def setUp(self):
        self.config = {"enabled": True, "type": "local"}
        # Mock paths to avoid huge downloads during test
        with patch("narrative_ai.engines.ocr.filters.docres_filter.Path"):
            self.filter = DocResFilter(self.config)

    def test_init(self):
        """Test initialization sets up paths correctly."""
        self.assertEqual(self.filter.name, "docres")
        self.assertTrue(self.filter.config["enabled"])

    @patch("narrative_ai.engines.ocr.filters.docres_filter.DocResFilter._load")
    def test_load_trigger(self, mock_load):
        """Test that _load is called."""
        self.filter._load()
        mock_load.assert_called_once()
