import unittest
import numpy as np
import io
from PIL import Image
from narrative_ai.engines.ocr.utils.image import read_image_as_numpy, convert_numpy_to_bytes


class TestImageUtils(unittest.TestCase):
    def setUp(self):
        # Create a dummy image for testing
        self.test_img = Image.new("RGB", (100, 100), color="red")
        self.test_np = np.array(self.test_img)

        # Save to buffer
        buf = io.BytesIO()
        self.test_img.save(buf, format="PNG")
        self.test_bytes = buf.getvalue()

    def test_read_image_as_numpy_from_bytes(self):
        result = read_image_as_numpy(self.test_bytes)
        self.assertIsInstance(result, np.ndarray)
        self.assertEqual(result.shape, (100, 100, 3))
        np.testing.assert_array_equal(result, self.test_np)

    def test_read_image_as_numpy_from_numpy(self):
        result = read_image_as_numpy(self.test_np)
        self.assertIsInstance(result, np.ndarray)
        np.testing.assert_array_equal(result, self.test_np)

    def test_convert_numpy_to_bytes(self):
        result = convert_numpy_to_bytes(self.test_np)
        self.assertIsInstance(result, bytes)
        # Verify it can be read back
        img_back = Image.open(io.BytesIO(result))
        self.assertEqual(img_back.size, (100, 100))

    def test_invalid_input(self):
        with self.assertRaises(ValueError):
            read_image_as_numpy(12345)
