import sys
import numpy as np
import cv2
from pathlib import Path

# Add the project root to the path so we can import 'framework'
sys.path.append(str(Path(__file__).resolve().parents[4]))

try:
    from narrative_ai.engines import ocr

    print("✅ Successfully imported ocr module")
except ImportError as e:
    print(f"❌ Failed to import ocr module: {e}")
    sys.exit(1)


def test_api():
    print("\n--- Testing Functional API ---")

    # Create a dummy image
    dummy_img = np.zeros((100, 100, 3), dtype=np.uint8)
    cv2.putText(dummy_img, "Test", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    # Test 1: ocr.ocr
    print("Testing ocr.ocr(numpy_array)...")
    try:
        # We don't expect it to actually run without a server, but it should reach the point of trying
        # or it might return an error string if configured for remote
        text = ocr.ocr(dummy_img)
        print(f"Result: {text}")
    except Exception as e:
        print(f"Expected failure or error: {e}")

    # Test 2: ocr.restoration
    print("\nTesting ocr.restoration(numpy_array)...")
    try:
        res = ocr.restoration(dummy_img)
        if res:
            print(f"Result: Got {len(res)} bytes")
        else:
            print("Result: No image returned (expected if filtering skipped)")
    except Exception as e:
        print(f"Expected failure or error: {e}")

    # Test 3: ocr.binarize
    print("\nTesting ocr.binarize(numpy_array)...")
    try:
        res = ocr.binarize(dummy_img)
        if res:
            print(f"Result: Got {len(res)} bytes")
    except Exception as e:
        print(f"Expected failure or error: {e}")

    print("\n--- Functional API Test Complete ---")


if __name__ == "__main__":
    test_api()
