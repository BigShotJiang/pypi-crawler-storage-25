import sys
from pathlib import Path

# Add the engines directory to path so ocr is a package
ENGINES_DIR = Path(__file__).resolve().parent.parent
sys.path.append(str(ENGINES_DIR))

from narrative_ai.engines.ocr.pipeline import OCRPipeline  # noqa: E402
from narrative_ai.engines.ocr.filters.docres_filter import DocResFilter  # noqa: E402
import numpy as np  # noqa: E402


def verify_integration():
    print("Testing OCR Pipeline Integration...")

    # Initialize pipeline
    # We use a custom config dict to enable filters for testing
    pipeline = OCRPipeline()

    print("\n1. Testing Filter classes...")
    assert issubclass(DocResFilter, object)
    print("Filter classes verified.")

    print("\n2. Testing Pipeline with DocRes options...")
    # Check if process accepts the new arguments
    dummy_img = np.zeros((100, 100, 3), dtype=np.uint8)

    # We mock the internal extract_text to avoid network calls
    pipeline.ocr_tool.extract_text = lambda x: "Extracted Text"

    # We mock the filter process completely to avoid heavy loading
    def mock_process(self, img, **kwargs):
        print(f"Mocked {self.__class__.__name__} Process Called")
        return img

    original_docres_process = DocResFilter.apply

    DocResFilter.apply = mock_process

    print("Executing pipeline.process(dewarping=True, shadow_removal=True)...")
    result = pipeline.process(dummy_img, dewarping=True, shadow_removal=True)

    # Restore originals
    if hasattr(DocResFilter, "apply"):
        DocResFilter.apply = original_docres_process

    print(f"Result timings: {list(result['timings'].keys())}")
    assert result["text"] == "Extracted Text"
    print("Pipeline integration verified.")


if __name__ == "__main__":
    import traceback

    try:
        verify_integration()
    except Exception:
        print("Verification Failed:")
        traceback.print_exc()
        sys.exit(1)
