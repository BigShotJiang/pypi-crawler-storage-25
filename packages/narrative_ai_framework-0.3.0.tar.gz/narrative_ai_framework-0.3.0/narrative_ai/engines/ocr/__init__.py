"""Standalone OCR pipeline: filters, providers, and core image operations."""

from typing import Any
from .api import (
    ocr,
    restoration,
    dewarp,
    deshadow,
    enhance,
    binarize,
    extract_text,
    ocr_async,
    OCRClient
)

def __getattr__(name: str) -> Any:
    """Implement lazy loading for heavy OCR components."""
    if name == "OCRPipeline":
        from .pipeline import OCRPipeline
        return OCRPipeline
    if name == "DocResFilter":
        from .filters import DocResFilter
        return DocResFilter
    if name == "AbstractFilter":
        from .filters import AbstractFilter
        return AbstractFilter
    if name == "RemoteDocResFilter":
        from .filters import RemoteDocResFilter
        return RemoteDocResFilter
    if name == "RemoteOCR":
        from .providers.remote import RemoteOCR
        return RemoteOCR
    
    raise AttributeError(f"module {__name__} has no attribute {name}")

__all__ = [
    "AbstractFilter",
    "DocResFilter",
    "RemoteDocResFilter",
    "RemoteOCR",
    "OCRPipeline",
    "ocr",
    "restoration",
    "dewarp",
    "deshadow",
    "enhance",
    "binarize",
    "extract_text",
    "ocr_async",
    "OCRClient",
]
__version__ = "0.1.0"
