import asyncio
from typing import Union, Optional, Dict, Any, List
from pathlib import Path
import numpy as np
# Lazy loading to avoid heavy imports at the root level
# from narrative_ai.engines.ocr.pipeline import OCRPipeline

_default_pipeline: Optional["OCRPipeline"] = None

async def _ensure_pipeline() -> "OCRPipeline":
    """Get or create the default global OCRPipeline instance."""
    global _default_pipeline
    if _default_pipeline is None:
        from narrative_ai.engines.ocr.pipeline import OCRPipeline
        _default_pipeline = await asyncio.to_thread(OCRPipeline)
    return _default_pipeline

def set_service_url(url: str):
    """
    Update the remote service URL for OCR and Restoration.
    Useful for updating ngrok endpoints.
    """
    global _default_pipeline
    if _default_pipeline:
        _default_pipeline.update_service_url(url)
    
    import os
    os.environ["NARRATIVE_OCR_URL"] = url

def set_ocr_provider(provider_type: str):
    """
    Switch the OCR provider type (e.g., 'remote_ocr', 'local_paddle').
    """
    # This requires re-initializing the factory which is complex in api.py
    # For now, we set the env var so the next _ensure_pipeline picks it up
    import os
    os.environ["OCR_VLM_PROVIDER_TYPE"] = provider_type

async def dewarp(
    image: Union[str, Path, bytes, np.ndarray],
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> bytes:
    """Apply dewarping to an image."""
    pipeline = await _ensure_pipeline()
    result = await asyncio.to_thread(
        pipeline.process, 
        image_input=image, 
        dewarping=True, 
        ocr=False,
        user_id=user_id,
        tenant_id=tenant_id,
        **kwargs
    )
    return result.get("processed_image") or (image if isinstance(image, bytes) else b"")

async def deshadow(
    image: Union[str, Path, bytes, np.ndarray],
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> bytes:
    """Remove shadows from an image."""
    pipeline = await _ensure_pipeline()
    result = await asyncio.to_thread(
        pipeline.process, 
        image_input=image, 
        shadow_removal=True, 
        ocr=False,
        user_id=user_id,
        tenant_id=tenant_id,
        **kwargs
    )
    return result.get("processed_image") or (image if isinstance(image, bytes) else b"")

async def enhance(
    image: Union[str, Path, bytes, np.ndarray],
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> bytes:
    """Enhance document appearance and legibility."""
    pipeline = await _ensure_pipeline()
    result = await asyncio.to_thread(
        pipeline.process, 
        image_input=image, 
        appearance=True, 
        enhancement=True, 
        ocr=False,
        user_id=user_id,
        tenant_id=tenant_id,
        **kwargs
    )
    return result.get("processed_image") or (image if isinstance(image, bytes) else b"")

async def binarize(
    image: Union[str, Path, bytes, np.ndarray],
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> bytes:
    """Convert an image to black and white (binarization)."""
    pipeline = await _ensure_pipeline()
    result = await asyncio.to_thread(
        pipeline.process, 
        image_input=image, 
        binarization=True, 
        ocr=False,
        user_id=user_id,
        tenant_id=tenant_id,
        **kwargs
    )
    return result.get("processed_image") or (image if isinstance(image, bytes) else b"")

async def restoration(
    image: Union[str, Path, bytes, np.ndarray],
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    correlation_id: Optional[str] = None,
    **kwargs
) -> bytes:
    """Apply full restoration (deshadow + appearance) to an image."""
    pipeline = await _ensure_pipeline()
    result = await asyncio.to_thread(
        pipeline.process, 
        image_input=image, 
        ocr=False, 
        shadow_removal=True, 
        appearance=True,
        user_id=user_id,
        tenant_id=tenant_id,
        **kwargs
    )
    return result.get("processed_image") or (image if isinstance(image, bytes) else b"")

async def extract_text(
    image: Union[str, Path, bytes, np.ndarray],
    shadow_removal: bool = False,
    dewarping: bool = False,
    appearance: bool = False,
    enhancement: bool = False,
    deblurring: bool = False,
    binarization: bool = False,
    filename: Optional[str] = None,
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    _ordered_task: Optional[str] = None,
    **kwargs
) -> str:
    """Extract text from an image using OCR."""
    pipeline = await _ensure_pipeline()
    result = await asyncio.to_thread(
        pipeline.process, 
        image_input=image, 
        ocr=True,
        shadow_removal=shadow_removal,
        dewarping=dewarping,
        appearance=appearance,
        enhancement=enhancement,
        deblurring=deblurring,
        binarization=binarization,
        filename=filename,
        user_id=user_id,
        tenant_id=tenant_id,
        _ordered_task=_ordered_task,
        **kwargs
    )
    return result.get("text", "")

async def ocr(
    image: Union[str, Path, bytes, np.ndarray],
    ocr: bool = True,
    shadow_removal: bool = False,
    dewarping: bool = False,
    appearance: bool = False,
    enhancement: bool = False,
    deblurring: bool = False,
    binarization: bool = False,
    filename: Optional[str] = None,
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    _ordered_task: Optional[str] = None,
    **kwargs
) -> Dict[str, Any]:
    """
    Perform a combined OCR operation with custom preprocessing steps.
    Returns the full result dictionary including 'text', 'processed_image', and 'timings'.
    """
    pipeline = await _ensure_pipeline()
    return await asyncio.to_thread(
        pipeline.process, 
        image_input=image,
        ocr=ocr,
        shadow_removal=shadow_removal,
        dewarping=dewarping,
        appearance=appearance,
        enhancement=enhancement,
        deblurring=deblurring,
        binarization=binarization,
        filename=filename,
        user_id=user_id,
        tenant_id=tenant_id,
        _ordered_task=_ordered_task,
        **kwargs
    )

async def ocr_async(
    image: Union[str, Path, bytes, np.ndarray],
    shadow_removal: bool = False,
    dewarping: bool = False,
    appearance: bool = False,
    enhancement: bool = False,
    deblurring: bool = False,
    binarization: bool = False,
    filename: Optional[str] = None,
    user_id: Optional[Any] = None,
    tenant_id: Optional[Any] = None,
    _ordered_task: Optional[str] = None,
    **kwargs
) -> str:
    """Async alias for extract_text for backward compatibility."""
    return await extract_text(
        image=image,
        shadow_removal=shadow_removal,
        dewarping=dewarping,
        appearance=appearance,
        enhancement=enhancement,
        deblurring=deblurring,
        binarization=binarization,
        filename=filename,
        user_id=user_id,
        tenant_id=tenant_id,
        _ordered_task=_ordered_task,
        **kwargs
    )

class OCRClient:
    """
    A session-based client for the OCR engine.
    Stores common parameters like user_id, tenant_id, and processing preferences.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        tenant_id: Optional[str] = None,
        shadow_removal: bool = False,
        dewarping: bool = False,
        appearance: bool = False,
        enhancement: bool = False,
        service_url: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ):
        """
        Initialize the OCR client with default context.
        
        Args:
            user_id: Default user ID for audit logging
            tenant_id: Default tenant ID for multi-tenancy
            shadow_removal: Default shadow removal preference
            dewarping: Default dewarping preference
            appearance: Default document appearance enhancement preference
            enhancement: Default resolution/quality enhancement preference
            service_url: Optional URL for remote OCR service
            correlation_id: Default request tracking ID
        """
        if service_url:
            set_service_url(service_url)

        self.defaults = {
            "user_id": user_id,
            "tenant_id": tenant_id,
            "shadow_removal": shadow_removal,
            "dewarping": dewarping,
            "appearance": appearance,
            "enhancement": enhancement,
            "correlation_id": correlation_id,
        }

    async def extract_text(self, image: Union[str, Path, bytes, np.ndarray], **kwargs) -> str:
        """Extract text using client defaults."""
        final_args = {**self.defaults, "image": image, **kwargs}
        return await extract_text(**final_args)

    async def ocr(self, image: Union[str, Path, bytes, np.ndarray], **kwargs) -> Dict[str, Any]:
        """Perform full OCR operation using client defaults."""
        final_args = {**self.defaults, "image": image, **kwargs}
        return await ocr(**final_args)

    async def dewarp(self, image: Union[str, Path, bytes, np.ndarray], **kwargs) -> bytes:
        """Apply dewarping using client defaults."""
        final_args = {**self.defaults, "image": image, **kwargs}
        return await dewarp(**final_args)

    async def deshadow(self, image: Union[str, Path, bytes, np.ndarray], **kwargs) -> bytes:
        """Remove shadows using client defaults."""
        final_args = {**self.defaults, "image": image, **kwargs}
        return await deshadow(**final_args)

    async def enhance(self, image: Union[str, Path, bytes, np.ndarray], **kwargs) -> bytes:
        """Enhance image using client defaults."""
        final_args = {**self.defaults, "image": image, **kwargs}
        return await enhance(**final_args)

    async def binarize(self, image: Union[str, Path, bytes, np.ndarray], **kwargs) -> bytes:
        """Binarize image using client defaults."""
        final_args = {**self.defaults, "image": image, **kwargs}
        return await binarize(**final_args)

    async def restoration(self, image: Union[str, Path, bytes, np.ndarray], **kwargs) -> bytes:
        """Apply full restoration using client defaults."""
        final_args = {**self.defaults, "image": image, **kwargs}
        return await restoration(**final_args)
