"""
Streamlit Demo - Arabic OCR + Document Restoration
Simple 3-option UI: Magic Filter | Dewarping | OCR
"""

import streamlit as st
import sys
from pathlib import Path

# Setup paths
OCR_ENGINE_DIR = Path(__file__).resolve().parent.parent
ENGINES_DIR = OCR_ENGINE_DIR.parent
sys.path.append(str(ENGINES_DIR))

try:
    from ocr.pipeline import OCRPipeline

    print("✅ SDK Successfully Imported")
except ImportError:
    sys.path.append("framework/engines")
    from ocr.pipeline import OCRPipeline

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(page_title="Arabic OCR", layout="wide", page_icon="🔤")

st.markdown(
    """
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

/* Toggle card style */
div[data-testid="stCheckbox"] label {
    font-size: 15px !important;
    font-weight: 500 !important;
}

/* Primary button */
[data-testid="stButton"] button[kind="primary"] {
    background: linear-gradient(135deg, #7c3aed, #4f46e5);
    border: none;
    font-weight: 700;
    font-size: 16px;
    border-radius: 12px;
    padding: 0.7rem 1.5rem;
    transition: all 0.2s;
    color: white;
}
[data-testid="stButton"] button[kind="primary"]:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 24px rgba(124,58,237,0.45);
}

/* Pipeline badge */
.pipeline-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: linear-gradient(135deg, #7c3aed22, #4f46e522);
    border: 1px solid #7c3aed55;
    border-radius: 20px;
    padding: 6px 16px;
    font-size: 13px;
    font-weight: 600;
    color: #a78bfa;
    margin: 4px 4px 4px 0;
}
.pipeline-row { margin: 10px 0 16px; }
</style>
""",
    unsafe_allow_html=True,
)

# ── Session state ─────────────────────────────────────────────────────────────
if "pipeline" not in st.session_state:
    try:
        st.session_state.pipeline = OCRPipeline()
    except Exception as e:
        st.error(f"Init failed: {e}")
        st.stop()

pipeline = st.session_state.pipeline

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("⚙️ Settings")
    current_url = getattr(pipeline.ocr_tool, "url", "")
    api_url = st.text_input("API URL", value=current_url)
    if st.button("Update URL"):
        pipeline.update_service_url(api_url)
        if pipeline.ocr_tool.is_available():
            st.success("✅ Connected!")
        else:
            st.error("❌ Connection Failed")

    st.markdown("---")
    st.markdown("""
    ### الفلاتر المتاحة:
    - **✨ Magic Filter** — Deblurring + Deshadowing + Appearance Enhancement
    - **📐 Dewarping** — تصحيح انحناء الصفحات
    *(كلها داخل نموذج DocRes)*
    """)

# ── Main ──────────────────────────────────────────────────────────────────────
st.title("🔤 Arabic OCR + Document Restoration")
st.caption("Powered by Qwen2.5-VL + DocRes")

col1, col2 = st.columns([1, 1])

# ── LEFT: Input + Options ─────────────────────────────────────────────────────
with col1:
    st.subheader("📁 Input")
    input_mode = st.radio("Source", ["Upload Image", "Take Photo"], horizontal=True)

    uploaded_file = None
    if input_mode == "Upload Image":
        uploaded_file = st.file_uploader("Choose an image...")
    else:
        uploaded_file = st.camera_input("Take a photo")

    if uploaded_file and input_mode != "Take Photo":
        try:
            st.image(uploaded_file, caption="Preview", use_container_width=True)
        except Exception:
            st.warning("⚠️ Can't preview this format, but processing will still work.")

    st.markdown("---")
    st.subheader("🎛️ Processing Options")

    use_magic = st.checkbox(
        "✨ Magic Filter", value=True, help="يطبّق Deblurring + Deshadowing + Appearance Enhancement بالـ DocRes model"
    )
    use_dewarp = st.checkbox("📐 Dewarping", value=False, help="يصحّح تعرّج وانحناء الصفحات")
    run_ocr = st.checkbox("🔍 Run OCR (Extract Text)", value=True, help="يستخرج النص من الصورة بعد المعالجة")

    # Live pipeline preview
    if use_magic or use_dewarp or run_ocr:
        badges = []
        if use_dewarp:
            badges.append("📐 Dewarping")
        if use_magic:
            badges.append("🔧 Deblurring")
            badges.append("🌤️ Deshadowing")
            badges.append("✨ Appearance")
        if run_ocr:
            badges.append("🔍 OCR")

        arrow_sep = '<span style="color:#7c3aed;font-size:16px;margin:0 2px;">→</span>'
        pipeline_html = arrow_sep.join(f'<span class="pipeline-badge">{b}</span>' for b in badges)
        st.markdown(f'<div class="pipeline-row">{pipeline_html}</div>', unsafe_allow_html=True)

    run_btn = st.button("🚀 Process Document", type="primary", use_container_width=True)

# ── RIGHT: Results ────────────────────────────────────────────────────────────
with col2:
    st.subheader("📊 Results")

    if run_btn:
        if not uploaded_file:
            st.warning("⚠️ من فضلك ارفع صورة أو التقط صورة أولاً.")
        elif not use_magic and not use_dewarp and not run_ocr:
            st.warning("⚠️ اختر خياراً واحداً على الأقل.")
        else:
            with st.spinner("⏳ Processing..."):
                try:
                    # Build ordered task string based on user choices
                    # Order: dewarp → magic (deblur+deshadow+appearance)
                    task_parts = []
                    if use_dewarp:
                        task_parts.append("dewarp")
                    if use_magic:
                        task_parts.append("deblur")
                        task_parts.append("deshadow")
                        task_parts.append("appearance")

                    ordered_task = "+".join(task_parts) if task_parts else ""

                    result = pipeline.process(
                        uploaded_file.getvalue(),
                        dewarping=use_dewarp,
                        shadow_removal=use_magic,
                        appearance=use_magic,
                        deblurring=use_magic,
                        binarization=False,
                        ocr=run_ocr,
                        filename=(uploaded_file.name if hasattr(uploaded_file, "name") else "camera.png"),
                        _ordered_task=ordered_task if ordered_task else None,
                    )

                    if "error" in result:
                        st.error(result["error"])
                    else:
                        # Processed image
                        img_bytes = result.get("processed_image")
                        if img_bytes:
                            try:
                                st.image(img_bytes, caption="✅ Processed Image", use_container_width=True)
                            except Exception:
                                st.warning("⚠️ Processed result can't be previewed, but text extraction is complete.")

                        # Timings
                        timings = result.get("timings", {})
                        if timings:
                            st.markdown("#### ⏱️ Performance")
                            cols = st.columns(len(timings))
                            for i, (stage, dur) in enumerate(timings.items()):
                                with cols[i]:
                                    st.metric(stage, f"{dur:.2f}s")

                        # Extracted text
                        text = result.get("text", "")
                        if run_ocr:
                            st.text_area("📝 Extracted Text", value=text, height=280)

                except Exception as e:
                    st.error(f"Error: {e}")
                    import traceback

                    st.code(traceback.format_exc())

st.markdown("---")
st.caption("✨ Magic Filter = Deblurring + Deshadowing + Appearance Enhancement (DocRes)  |  📐 Dewarping يُطبَّق أولاً")
