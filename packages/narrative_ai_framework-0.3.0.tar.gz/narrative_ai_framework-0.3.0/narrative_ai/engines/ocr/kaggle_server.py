# ============================================================================
# 🚀 FINAL MERGED SERVER (V3) - TURBO EDITION (GOOGLE COLAB)
# ============================================================================
# 1. ATOMIC ENV FIX: Solves broken Sympy attribute errors in Colab.
# 2. PERSISTENT VRAM: Models stay in GPU for 10x faster inference.
# 3. BLOCKING LAUNCH: Cell stays running indefinitely while server is live.
# 4. DIRECTORY FIX: Auto-creates folders for weights before download.
# ============================================================================
# ============================================
# Cell 1: Install All Dependencies
# ============================================

#!pip install -q git+https://github.com/huggingface/transformers.git
#!pip install -q accelerate bitsandbytes
# !pip install -q qwen-vl-utils pillow
# !pip install -q fastapi uvicorn python-multipart pyngrok nest-asyncio
# !pip install -q torch numpy

import os
import sys
import subprocess
import time
import threading

# --- 0. COLAB NUCLEAR ENV FIX (Must be FIRST) ---
try:
    import sympy

    if not hasattr(sympy, "printing"):
        raise ImportError("Sympy is broken")
except (ImportError, AttributeError):
    print("🩹 Fixing environment (Sympy issue detected)...")
    subprocess.run([sys.executable, "-m", "pip", "uninstall", "-y", "sympy"], check=True)
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "sympy==1.12"], check=True)
    try:
        from google.colab import runtime

        print("🔁 RESTARTING COLAB RUNTIME TO APPLY FIX. PLEASE RUN THIS CELL AGAIN.")
        runtime.unassign()
    except Exception:
        # Not Colab (e.g. Kaggle): cannot restart runtime; exit so user re-runs
        print("🔁 Re-run this notebook cell to pick up the sympy fix.")
    sys.exit()

# --- 1. ENVIRONMENT SETUP ---
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["PYTHONWARNINGS"] = "ignore"
import warnings

warnings.filterwarnings("ignore")

PORT = 8890
# Kaggle: writable dir is /kaggle/working. Colab: /content.
WORKING_DIR = "/kaggle/working" if os.path.isdir("/kaggle/working") else "/content"
os.makedirs(WORKING_DIR, exist_ok=True)
os.chdir(WORKING_DIR)
print(f"📁 Working directory: {WORKING_DIR}")

# --- 2. DEPENDENCY INSTALLATION ---
print("📦 Checking dependencies...")
try:
    import uvicorn
    import nest_asyncio
except ImportError:
    subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "-q",
            "einops",
            "scikit-image",
            "timm",
            "pyngrok",
            "fastapi",
            "uvicorn",
            "python-multipart",
            "pillow",
            "opencv-python",
            "huggingface_hub",
            "torch",
            "transformers",
            "accelerate",
            "sentencepiece",
            "qwen_vl_utils",
            "nest_asyncio",
        ],
        check=True,
    )
    print("✅ Dependencies installed. Please RUN AGAIN.")

# --- 3. IMPORTS ---
import torch  # noqa: E402
import numpy as np  # noqa: E402
import cv2  # noqa: E402
import urllib.request  # noqa: E402
from collections import OrderedDict  # noqa: E402
from fastapi import FastAPI, UploadFile, File, Form, Response  # noqa: E402
from fastapi.responses import JSONResponse  # noqa: E402
from pyngrok import ngrok  # noqa: E402
from einops import rearrange  # noqa: E402
import torch.nn as nn  # noqa: E402
import torch.nn.functional as F  # noqa: E402
import numbers  # noqa: E402
from skimage.filters import threshold_sauvola  # noqa: E402
import nest_asyncio  # noqa: E402
from PIL import Image  # noqa: E402
import io  # noqa: E402
import traceback  # noqa: E402
import base64  # noqa: E402
from transformers import Qwen2_5_VLForConditionalGeneration, AutoProcessor  # noqa: E402

# --- 4. DEVICE & ASYNC CONFIG ---
nest_asyncio.apply()
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"🖥️ Using device: {DEVICE}")

# Clean up previous server instances
try:
    ngrok.kill()
    subprocess.run(["fuser", "-k", f"{PORT}/tcp"], check=False, capture_output=True)
    time.sleep(1)
except Exception:
    pass


# --- 5. DOCRES ARCHITECTURE ---
def to_3d(x):
    return rearrange(x, "b c h w -> b (h w) c")


def to_4d(x, h, w):
    return rearrange(x, "b (h w) c -> b c h w", h=h, w=w)


class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim):
        super(LayerNorm, self).__init__()
        self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)


class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()
        hidden_features = int(dim * ffn_expansion_factor)
        self.project_in = nn.Conv2d(dim, hidden_features * 2, kernel_size=1, bias=bias)
        self.dwconv = nn.Conv2d(
            hidden_features * 2,
            hidden_features * 2,
            kernel_size=3,
            stride=1,
            padding=1,
            groups=hidden_features * 2,
            bias=bias,
        )
        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x1, x2 = self.dwconv(self.project_in(x)).chunk(2, dim=1)
        return self.project_out(F.gelu(x1) * x2)


class Attention(nn.Module):
    def __init__(self, dim, num_heads, bias):
        super(Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))
        self.qkv = nn.Conv2d(dim, dim * 3, kernel_size=1, bias=bias)
        self.qkv_dwconv = nn.Conv2d(dim * 3, dim * 3, kernel_size=3, stride=1, padding=1, groups=dim * 3, bias=bias)
        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        b, c, h, w = x.shape
        q, k, v = self.qkv_dwconv(self.qkv(x)).chunk(3, dim=1)
        q = rearrange(q, "b (head c) h w -> b head c (h w)", head=self.num_heads)
        k = rearrange(k, "b (head c) h w -> b head c (h w)", head=self.num_heads)
        v = rearrange(v, "b (head c) h w -> b head c (h w)", head=self.num_heads)
        q, k = F.normalize(q, dim=-1), F.normalize(k, dim=-1)
        attn = (q @ k.transpose(-2, -1)) * self.temperature
        out = attn.softmax(dim=-1) @ v
        return self.project_out(rearrange(out, "b head c (h w) -> b (head c) h w", head=self.num_heads, h=h, w=w))


class TransformerBlock(nn.Module):
    def __init__(self, dim, num_heads, ffn_expansion_factor, bias):
        super(TransformerBlock, self).__init__()
        self.norm1, self.attn = LayerNorm(dim), Attention(dim, num_heads, bias)
        self.norm2, self.ffn = LayerNorm(dim), FeedForward(dim, ffn_expansion_factor, bias)

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        return x + self.ffn(self.norm2(x))


class OverlapPatchEmbed(nn.Module):
    def __init__(self, in_c=3, embed_dim=48, bias=False):
        super(OverlapPatchEmbed, self).__init__()
        self.proj = nn.Conv2d(in_c, embed_dim, kernel_size=3, stride=1, padding=1, bias=bias)

    def forward(self, x):
        return self.proj(x)


class Downsample(nn.Module):
    def __init__(self, n_feat):
        super(Downsample, self).__init__()
        self.body = nn.Sequential(
            nn.Conv2d(n_feat, n_feat // 2, kernel_size=3, stride=1, padding=1, bias=False), nn.PixelUnshuffle(2)
        )

    def forward(self, x):
        return self.body(x)


class Upsample(nn.Module):
    def __init__(self, n_feat):
        super(Upsample, self).__init__()
        self.body = nn.Sequential(
            nn.Conv2d(n_feat, n_feat * 2, kernel_size=3, stride=1, padding=1, bias=False), nn.PixelShuffle(2)
        )

    def forward(self, x):
        return self.body(x)


class Restormer(nn.Module):
    def __init__(
        self,
        inp_channels=6,
        out_channels=3,
        dim=48,
        num_blocks=[2, 3, 3, 4],
        num_refinement_blocks=4,
        heads=[1, 2, 4, 8],
        ffn_expansion_factor=2.66,
        bias=False,
    ):
        super(Restormer, self).__init__()
        self.patch_embed = OverlapPatchEmbed(inp_channels, dim)
        self.encoder_level1 = nn.Sequential(
            *[TransformerBlock(dim, heads[0], ffn_expansion_factor, bias) for _ in range(num_blocks[0])]
        )
        self.down1_2 = Downsample(dim)
        self.encoder_level2 = nn.Sequential(
            *[TransformerBlock(dim * 2, heads[1], ffn_expansion_factor, bias) for _ in range(num_blocks[1])]
        )
        self.down2_3 = Downsample(dim * 2)
        self.encoder_level3 = nn.Sequential(
            *[TransformerBlock(dim * 4, heads[2], ffn_expansion_factor, bias) for _ in range(num_blocks[2])]
        )
        self.down3_4 = Downsample(dim * 4)
        self.latent = nn.Sequential(
            *[TransformerBlock(dim * 8, heads[3], ffn_expansion_factor, bias) for _ in range(num_blocks[3])]
        )
        self.up4_3 = Upsample(dim * 8)
        self.reduce_chan_level3 = nn.Conv2d(dim * 8, dim * 4, kernel_size=1, bias=bias)
        self.decoder_level3 = nn.Sequential(
            *[TransformerBlock(dim * 4, heads[2], ffn_expansion_factor, bias) for _ in range(num_blocks[2])]
        )
        self.up3_2 = Upsample(dim * 4)
        self.reduce_chan_level2 = nn.Conv2d(dim * 4, dim * 2, kernel_size=1, bias=bias)
        self.decoder_level2 = nn.Sequential(
            *[TransformerBlock(dim * 2, heads[1], ffn_expansion_factor, bias) for _ in range(num_blocks[1])]
        )
        self.up2_1 = Upsample(dim * 2)
        self.decoder_level1 = nn.Sequential(
            *[TransformerBlock(dim * 2, heads[0], ffn_expansion_factor, bias) for _ in range(num_blocks[0])]
        )
        self.refinement = nn.Sequential(
            *[TransformerBlock(dim * 2, heads[0], ffn_expansion_factor, bias) for _ in range(num_refinement_blocks)]
        )
        self.skip_conv = nn.Conv2d(dim, dim * 2, kernel_size=1, bias=bias)
        self.output = nn.Conv2d(dim * 2, out_channels, kernel_size=3, stride=1, padding=1, bias=bias)

    def forward(self, inp_img):
        inp_enc_level1 = self.patch_embed(inp_img)
        out_enc_level1 = self.encoder_level1(inp_enc_level1)
        out_enc_level2 = self.encoder_level2(self.down1_2(out_enc_level1))
        out_enc_level3 = self.encoder_level3(self.down2_3(out_enc_level2))
        latent = self.latent(self.down3_4(out_enc_level3))
        dec3 = self.decoder_level3(self.reduce_chan_level3(torch.cat([self.up4_3(latent), out_enc_level3], 1)))
        dec2 = self.decoder_level2(self.reduce_chan_level2(torch.cat([self.up3_2(dec3), out_enc_level2], 1)))
        dec1 = self.refinement(self.decoder_level1(torch.cat([self.up2_1(dec2), out_enc_level1], 1)))
        return self.output(dec1 + self.skip_conv(inp_enc_level1))


# --- 6. INITIALIZING MODELS (PERSISTENT VRAM) ---
print("\n🚀 Initializing Models (Turbo Mode - Static precision)...")
if not os.path.exists("DocRes"):
    subprocess.run(["git", "clone", "-q", "https://github.com/ZZZHANG-jx/DocRes.git"], check=True)
sys.path.insert(0, f"{WORKING_DIR}/DocRes")
sys.path.insert(0, f"{WORKING_DIR}/DocRes/data/MBD")
from infer import net1_net2_infer_single_im  # noqa: E402

# 6.1 DocRes Loading
DR_MODEL = Restormer().to(DEVICE).eval()
if torch.cuda.is_available():
    DR_MODEL = DR_MODEL.half()

# Directory Creation for Weights (STRICT FIX)
DR_W = f"{WORKING_DIR}/DocRes/checkpoints/docres.pkl"
MBD_W = f"{WORKING_DIR}/DocRes/data/MBD/checkpoint/mbd.pkl"
os.makedirs(os.path.dirname(DR_W), exist_ok=True)
os.makedirs(os.path.dirname(MBD_W), exist_ok=True)

if not os.path.exists(DR_W):
    print("📥 Downloading DocRes weights...")
    urllib.request.urlretrieve(
        "https://huggingface.co/DaVinciCode/doctra-docres-main/resolve/main/docres.pkl",
        DR_W,
    )  # nosec: B310
if not os.path.exists(MBD_W):
    print("📥 Downloading MBD weights...")
    urllib.request.urlretrieve(
        "https://huggingface.co/DaVinciCode/doctra-docres-mbd/resolve/main/mbd.pkl",
        MBD_W,
    )  # nosec: B310

sd = torch.load(DR_W, map_location=DEVICE, weights_only=True)["model_state"]
new_sd = OrderedDict([(k[7:] if k.startswith("module.") else k, v) for k, v in sd.items()])
DR_MODEL.load_state_dict(new_sd)

# 6.2 OCR Loading
OCR_NAME = "sherif1313/Arabic-handwritten-OCR-4bit-Qwen2.5-VL-3B-v3"
OCR_PROCESSOR = AutoProcessor.from_pretrained(OCR_NAME, trust_remote_code=True)  # nosec: B615
OCR_MODEL = Qwen2_5_VLForConditionalGeneration.from_pretrained(
    OCR_NAME,
    trust_remote_code=True,
    torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
    device_map="auto",
)  # nosec: B615
OCR_MODEL.lm_head.weight = OCR_MODEL.get_input_embeddings().weight
print("✅ Models ready and locked in VRAM.")


# --- 7. UTILS ---
def getBasecoord(h, w):
    b0 = np.tile(np.arange(h).reshape(h, 1), (1, w)).astype(np.float32)
    b1 = np.tile(np.arange(w).reshape(1, w), (h, 1)).astype(np.float32)
    return np.concatenate((np.expand_dims(b1, -1), np.expand_dims(b0, -1)), -1)


def run_dewarp(img):
    mask = net1_net2_infer_single_im(img, MBD_W)
    h, w = img.shape[:2]
    im_m = img.copy()
    im_m[mask == 0] = 0
    im_t = torch.from_numpy(cv2.resize(im_m, (256, 256)).transpose(2, 0, 1) / 255).unsqueeze(0).float().to(DEVICE)
    if torch.cuda.is_available():
        im_t = im_t.half()
    pr_t = (
        torch.from_numpy(
            np.concatenate(
                (getBasecoord(256, 256) / 256, np.expand_dims(cv2.resize(mask, (256, 256)) / 255, -1)), -1
            ).transpose(2, 0, 1)
        )
        .unsqueeze(0)
        .float()
        .to(DEVICE)
    )
    if torch.cuda.is_available():
        pr_t = pr_t.half()
    with torch.no_grad():
        pred = (
            DR_MODEL(torch.cat((im_t, pr_t), 1))[0][:2].permute(1, 2, 0).cpu().float().numpy()
            + getBasecoord(256, 256) / 256
        )
    fl = cv2.resize(pred, (w, h)) * (w, h)
    fl = cv2.blur(fl, (3, 3))
    return cv2.remap(img, fl[:, :, 0].astype(np.float32), fl[:, :, 1].astype(np.float32), cv2.INTER_LINEAR)


def run_res(img, mode="deshadow"):
    h, w = img.shape[:2]
    pr_r = cv2.resize(img, (1024, 1024))
    if mode == "deshadow":
        pr_i = cv2.merge([cv2.medianBlur(cv2.dilate(p, np.ones((7, 7))), 21) for p in cv2.split(pr_r)])
    else:
        pr_i = cv2.merge(
            [
                cv2.normalize(
                    255 - cv2.absdiff(p, cv2.medianBlur(cv2.dilate(p, np.ones((7, 7))), 21)),
                    None,
                    0,
                    255,
                    cv2.NORM_MINMAX,
                    cv2.CV_8UC1,
                )
                for p in cv2.split(pr_r)
            ]
        )
    pr_i = cv2.resize(pr_i, (w, h))
    in_im = np.concatenate((img, pr_i), -1)
    ph, pw = (8 - h % 8) % 8, (8 - w % 8) % 8
    in_im = np.pad(in_im, ((ph, 0), (pw, 0), (0, 0)), "reflect")
    in_t = torch.from_numpy(in_im.transpose(2, 0, 1) / 255).unsqueeze(0).float().to(DEVICE)
    if torch.cuda.is_available():
        in_t = in_t.half()
    with torch.no_grad():
        p = DR_MODEL(in_t)
        rn = (torch.clamp(p[0].permute(1, 2, 0), 0, 1).cpu().float().numpy() * 255).astype(np.uint8)[ph:, pw:]
    rn[rn == 0] = 1
    sm = cv2.resize(cv2.resize(img, (rn.shape[1], rn.shape[0])).astype(float) / rn.astype(float), (w, h))
    return np.clip(img.astype(float) / (sm + 1e-5), 0, 255).astype(np.uint8)


def run_binarize(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    thresh = threshold_sauvola(gray, window_size=25)
    binary = (gray > thresh).astype(np.uint8) * 255
    return cv2.cvtColor(binary, cv2.COLOR_GRAY2BGR)


def deblur_prompt(img):
    """Generate Sobel high-frequency prompt for deblurring (from official DocRes repo)."""
    x = cv2.Sobel(img, cv2.CV_16S, 1, 0)
    y = cv2.Sobel(img, cv2.CV_16S, 0, 1)
    absX = cv2.convertScaleAbs(x)
    absY = cv2.convertScaleAbs(y)
    high_frequency = cv2.addWeighted(absX, 0.5, absY, 0.5, 0)
    high_frequency = cv2.cvtColor(high_frequency, cv2.COLOR_BGR2GRAY)
    high_frequency = cv2.cvtColor(high_frequency, cv2.COLOR_GRAY2BGR)
    return high_frequency


def run_deblur(img):
    """Run DocRes deblurring using the Sobel-based high-frequency prompt."""
    # Pad to multiple of 8 (Restormer requirement)
    h, w = img.shape[:2]
    ph, pw = (8 - h % 8) % 8, (8 - w % 8) % 8
    img_padded = np.pad(img, ((ph, 0), (pw, 0), (0, 0)), "reflect")
    prompt = deblur_prompt(img_padded)
    in_im = np.concatenate((img_padded, prompt), -1)
    in_t = torch.from_numpy(in_im.transpose(2, 0, 1) / 255).unsqueeze(0).float().to(DEVICE)
    if torch.cuda.is_available():
        in_t = in_t.half()
    with torch.no_grad():
        pred = DR_MODEL(in_t)
        pred = torch.clamp(pred, 0, 1)
        pred = (pred[0].permute(1, 2, 0).cpu().float().numpy() * 255).astype(np.uint8)
    # Crop padding and return
    return pred[ph:, pw:]


# --- 8. FASTAPI ---
app = FastAPI()


@app.get("/health")
def health():
    return {"status": "ok", "device": str(DEVICE)}


@app.post("/docres")
async def docres(file: UploadFile = File(...), task: str = Form("restoration")):
    try:
        img_data = await file.read()
        img = cv2.imdecode(np.frombuffer(img_data, np.uint8), 1)
        if img is None:
            return JSONResponse({"error": "Invalid image format"}, status_code=400)

        t = task.lower()
        res = img

        # Cumulative processing order: Dewarp -> Deblur -> Deshadow -> Appearance -> Binarize
        if "dewarp" in t or "end2end" in t:
            res = run_dewarp(res)

        if "deblur" in t:
            res = run_deblur(res)

        if "deshadow" in t or "restor" in t or "end2end" in t:
            res = run_res(res, "deshadow")

        if "appear" in t or "restor" in t or "end2end" in t:
            res = run_res(res, "appearance")

        if "binarize" in t:
            res = run_binarize(res)

        return Response(content=cv2.imencode(".png", res)[1].tobytes(), media_type="image/png")
    except Exception as e:
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/docres/inference")
async def docres_inference(file: UploadFile = File(...), prompt: UploadFile = File(...), task: str = Form("deshadow")):
    """
    Atomic model inference endpoint.
    Expects preprocessed image and prompt from the client.
    Returns raw model output.
    """
    try:
        img_data = await file.read()
        prompt_data = await prompt.read()

        img = cv2.imdecode(np.frombuffer(img_data, np.uint8), 1)
        pr_i = cv2.imdecode(np.frombuffer(prompt_data, np.uint8), 1)

        if img is None or pr_i is None:
            return JSONResponse({"error": "Invalid image or prompt format"}, status_code=400)

        h, w = img.shape[:2]
        in_im = np.concatenate((img, pr_i), -1)

        # Padding to multiple of 8 (Restormer requirement)
        ph, pw = (8 - h % 8) % 8, (8 - w % 8) % 8
        in_im = np.pad(in_im, ((ph, 0), (pw, 0), (0, 0)), "reflect")

        in_t = torch.from_numpy(in_im.transpose(2, 0, 1) / 255).unsqueeze(0).float().to(DEVICE)
        if torch.cuda.is_available():
            in_t = in_t.half()

        with torch.no_grad():
            p = DR_MODEL(in_t)
            # Raw model prediction (RGB/BGR depends on training, usually BGR in this setup)
            res = (torch.clamp(p[0].permute(1, 2, 0), 0, 1).cpu().float().numpy() * 255).astype(np.uint8)

        # Crop back padding
        res = res[ph:, pw:]

        return Response(content=cv2.imencode(".png", res)[1].tobytes(), media_type="image/png")
    except Exception as e:
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/ocr")
async def ocr(file: UploadFile = File(...)):
    try:
        raw = await file.read()
        if not raw:
            return JSONResponse({"error": "Empty image file"}, status_code=400)
        try:
            image = Image.open(io.BytesIO(raw)).convert("RGB")
        except OSError as e:
            return JSONResponse(
                {"error": f"Invalid or corrupted image: {e}"},
                status_code=400,
            )
        msg = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": "اقرأ النص الموجود في الصورة بدقة"},
                ],
            }
        ]
        prompt = OCR_PROCESSOR.apply_chat_template(msg, tokenize=False, add_generation_prompt=True)
        inputs = OCR_PROCESSOR(text=[prompt], images=[image], return_tensors="pt").to(DEVICE)
        with torch.no_grad():
            out = OCR_MODEL.generate(**inputs, max_new_tokens=512)
        res = OCR_PROCESSOR.batch_decode(out, skip_special_tokens=True)[0]
        return {"text": res.split("assistant")[-1].strip() if "assistant" in res else res}
    except Exception as e:
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/docres_and_ocr")
async def docres_and_ocr(file: UploadFile = File(...), task: str = Form("restoration")):
    try:
        img_data = await file.read()
        img = cv2.imdecode(np.frombuffer(img_data, np.uint8), 1)
        if img is None:
            return JSONResponse({"error": "Invalid image format"}, status_code=400)

        t = task.lower()
        res_img = img

        # Cumulative processing order: Dewarp -> Deblur -> Deshadow -> Appearance -> Binarize
        if "dewarp" in t or "end2end" in t:
            res_img = run_dewarp(res_img)

        if "deblur" in t:
            res_img = run_deblur(res_img)

        if "deshadow" in t or "restor" in t or "end2end" in t:
            res_img = run_res(res_img, "deshadow")

        if "appear" in t or "restor" in t or "end2end" in t:
            res_img = run_res(res_img, "appearance")

        if "binarize" in t:
            res_img = run_binarize(res_img)
        pil_img = Image.fromarray(cv2.cvtColor(res_img, cv2.COLOR_BGR2RGB))
        msg = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": pil_img},
                    {"type": "text", "text": "اقرأ النص الموجود في الصورة بدقة"},
                ],
            }
        ]
        prompt = OCR_PROCESSOR.apply_chat_template(msg, tokenize=False, add_generation_prompt=True)
        inputs = OCR_PROCESSOR(text=[prompt], images=[pil_img], return_tensors="pt").to(DEVICE)
        with torch.no_grad():
            out = OCR_MODEL.generate(**inputs, max_new_tokens=512)
        text = OCR_PROCESSOR.batch_decode(out, skip_special_tokens=True)[0]
        _, buffer = cv2.imencode(".jpg", res_img, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
        img_b64 = base64.b64encode(buffer).decode("utf-8")
        return {
            "text": text.split("assistant")[-1].strip() if "assistant" in text else text,
            "processed_image": img_b64,
        }
    except Exception as e:
        traceback.print_exc()
        return JSONResponse({"error": str(e)}, status_code=500)


# --- 9. START SERVER ---
# Static domain: set NGROK_AUTH_TOKEN and optionally NGROK_DOMAIN via env (e.g. Kaggle Secrets).
# If NGROK_DOMAIN is set, uses that; otherwise ngrok.connect(PORT) for a dynamic URL.
print("\n🔗 STARTING SERVER WITH NGROK...")
try:
    token = os.environ.get("NGROK_AUTH_TOKEN") or os.getenv("NGROK_AUTHTOKEN")
    if token:
        ngrok.set_auth_token(token)
    domain = os.environ.get("NGROK_DOMAIN", "").strip()
    if domain:
        public_url = ngrok.connect(addr=PORT, domain=domain)
        print(f"🚀 API is live at: https://{domain}")
    else:
        public_url = ngrok.connect(PORT)
        print(f"🚀 API is live at: {public_url.public_url}")

    def run_server():
        uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="warning")  # nosec: B104

    thread = threading.Thread(target=run_server, daemon=True)
    thread.start()
    print("✅ Server started. Ready for requests.")

    # Keep main thread alive to allow stopping with Ctrl+C
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("\n🛑 Shutting down server...")
    ngrok.kill()
    print("Server has been stopped.")
except Exception as e:
    print(f"❌ An error occurred during server startup: {e}")
    ngrok.kill()
