"""
Rate Limiting Security Layer.

Implements per-user, per-tier rate limiting using Redis to prevent
abuse and ensure fair resource usage. This is Layer 3 of the
6-layer security architecture.
"""

import os
import re
import uuid
import time
import threading
import json
from typing import Optional, Dict, Any
from enum import Enum
import redis  # type: ignore
from redis.exceptions import RedisError  # type: ignore
import logging

from narrative_ai.security.circuit_breaker import CircuitBreaker

logger = logging.getLogger(__name__)


class UserTier(str, Enum):
    """User subscription tiers with different rate limits."""

    FREE = "free"  # 5 requests/minute
    PRO = "pro"  # 50 requests/minute
    ENTERPRISE = "enterprise"  # Unlimited


class EndpointCosts(int, Enum):
    """Resource cost per endpoint for cost-based rate limiting."""

    VALIDATE_AUDIO = 1  # Cheap
    VALIDATE_TEXT = 1
    STT = 5  # Medium
    RAG_SEARCH = 3
    WEB_SEARCH = 8
    RAG_INGEST = 5
    DOCUMENT_INGEST = 5
    OCR_PROCESS = 3
    VLM_INFERENCE = 15
    LLM_GENERATE = 20  # Expensive
    TTS = 10

    # Voice Stream endpoints (Engine 11)
    VOICE_SESSION_START = 2  # Starting a voice session
    VOICE_STT_STREAM = 3  # Per STT chunk in streaming mode
    VOICE_LLM_STREAM = 10  # Per LLM turn in conversation
    VOICE_TTS_STREAM = 5  # Per TTS synthesis in streaming mode
    VOICE_TURN_COMPLETE = 15  # Full voice turn (STT + LLM + TTS)


class RateLimitExceeded(Exception):
    """Raised when rate limit is exceeded."""

    def __init__(self, message: str, retry_after: int):
        """
        Initialize rate limit exception.

        Args:
            message: Human-readable error message
            retry_after: Seconds until rate limit resets
        """
        super().__init__(message)
        self.message = message
        self.retry_after = retry_after


class RateLimiter:
    """
    Rate limiter using Redis for distributed rate limiting.

    Implements sliding window rate limiting per user per tier.
    """

    # Rate limits per tier (requests per minute)
    RATE_LIMITS = {
        UserTier.FREE: 5,
        UserTier.PRO: 50,
        UserTier.ENTERPRISE: float("inf"),  # Unlimited
    }

    # Time window in seconds (1 minute)
    TIME_WINDOW = 60

    # Redis Lua script for atomic rate limiting (fixes TOCTOU race condition)
    # Returns: [status, retry_after, limit_type]
    # status: 0 = allowed, 1 = count exceeded, 2 = cost exceeded
    # retry_after: seconds until retry
    # limit_type: "count" or "cost" (if exceeded)
    # Uses KEYS[3] as atomic counter to avoid math.random collision under load
    LUA_RATE_LIMIT_SCRIPT = """
    local count_key = KEYS[1]
    local cost_key = KEYS[2]
    local counter_key = KEYS[3]
    local window_start = tonumber(ARGV[1])
    local now = tonumber(ARGV[2])
    local rate_limit = tonumber(ARGV[3])
    local budget = tonumber(ARGV[4])
    local endpoint_cost = tonumber(ARGV[5])
    local time_window = tonumber(ARGV[6])
    local cost_window = 60  -- Cost tracking window (60 seconds)
    local cost_window_start = now - cost_window
    
    -- Remove old entries from count key (sliding window)
    redis.call('ZREMRANGEBYSCORE', count_key, 0, window_start)
    
    -- Remove old entries from cost key (sliding window)
    redis.call('ZREMRANGEBYSCORE', cost_key, 0, cost_window_start)
    
    -- Count current requests in window
    local current_count = redis.call('ZCARD', count_key)
    
    -- Calculate current cost from sorted set (sliding window)
    -- ZRANGEBYSCORE with WITHSCORES returns: [member1, score1, member2, score2, ...]
    -- Members are in format "timestamp:cost:random" (e.g., "1234567890.123456:5:654321")
    local cost_entries = redis.call('ZRANGEBYSCORE', cost_key, cost_window_start, now, 'WITHSCORES')
    local current_cost = 0
    for i = 1, #cost_entries, 2 do
        -- cost_entries[i] is the member (format: "timestamp:cost:random"), cost_entries[i+1] is the score (timestamp)
        if cost_entries[i] then
            -- Extract cost from member string (format: "timestamp:cost:random")
            -- Need to find SECOND colon to extract just the cost value
            local member = tostring(cost_entries[i])
            local first_colon = string.find(member, ":")
            if first_colon then
                local second_colon = string.find(member, ":", first_colon + 1)
                if second_colon then
                    -- Extract cost between first and second colon
                    local cost_str = string.sub(member, first_colon + 1, second_colon - 1)
                    local cost_val = tonumber(cost_str)
                    if cost_val then
                        current_cost = current_cost + cost_val
                    end
                end
            end
        end
    end
    
    -- Check count limit
    if current_count >= rate_limit then
        -- Get oldest request timestamp to calculate retry_after
        local oldest = redis.call('ZRANGE', count_key, 0, 0, 'WITHSCORES')
        local retry_after = time_window
        if #oldest > 0 then
            local oldest_time = tonumber(oldest[2])
            retry_after = math.floor(time_window - (now - oldest_time)) + 1
        end
        return {1, retry_after, 'count'}
    end
    
    -- Check cost budget
    if current_cost + endpoint_cost > budget then
        return {2, 60, 'cost'}
    end
    
    -- All checks passed - add request atomically
    redis.call('ZADD', count_key, now, now)
    redis.call('EXPIRE', count_key, time_window + 1)
    
    -- Add cost entry to sorted set (use timestamp as score, unique member)
    -- FIX: Use Redis INCR for atomic counter instead of math.random to avoid collision
    -- under extreme load when same-millisecond requests could get identical random suffix
    local counter = redis.call('INCR', counter_key)
    redis.call('EXPIRE', counter_key, 60)  -- Counter key expires in 60 seconds
    local cost_member = string.format("%.6f:%d:%d", now, endpoint_cost, counter)
    redis.call('ZADD', cost_key, now, cost_member)
    redis.call('EXPIRE', cost_key, cost_window + 1)
    
    return {0, 0, ''}
    """

    def __init__(
        self,
        redis_client: Optional[redis.Redis] = None,
        redis_url: Optional[str] = None,
    ):
        """
        Initialize rate limiter.

        Args:
            redis_client: Optional Redis client instance
            redis_url: Optional Redis URL (used if redis_client not provided)
        """
        # Fast-fail timeouts so we don't block the event loop when Redis is down (critical for real-time voice)
        _socket_connect_timeout = 1  # Connection attempt fails in 1s
        _socket_timeout = 2  # Read/write (ping, eval) fail in 2s so voice pipeline stays responsive
        if redis_client is not None:
            self.redis = redis_client
        elif redis_url is not None:
            self.redis = redis.Redis.from_url(
                redis_url,
                decode_responses=False,
                socket_connect_timeout=_socket_connect_timeout,
                socket_timeout=_socket_timeout,
            )
        else:
            # Check if we're in production - REQUIRE explicit Redis URL in production
            is_production = os.getenv("ENV", "").lower() == "production"
            if is_production:
                raise ValueError(
                    "SECURITY: Redis URL must be explicitly configured in production. "
                    "Set REDIS_URL environment variable or pass redis_url parameter. "
                    "Using localhost Redis in production is a security risk."
                )

            # DEVELOPMENT ONLY: Default to localhost Redis (fail fast if unreachable)
            logger.warning(
                "Using localhost Redis (development mode). Set ENV=production and REDIS_URL for production deployments."
            )
            self.redis = redis.Redis(
                host="localhost",
                port=6379,
                db=0,
                decode_responses=False,
                socket_connect_timeout=_socket_connect_timeout,
                socket_timeout=_socket_timeout,
            )

        # Initialize circuit breaker for Redis failure detection
        self.redis_circuit_breaker = CircuitBreaker(
            failure_threshold=5,
            success_threshold=2,
            timeout_seconds=60,
        )

        # Local in-memory fallback (stricter limits) with bounded size
        # Maximum entries to prevent memory exhaustion under attack
        self._MAX_LOCAL_ENTRIES = 10000  # Max unique user keys to track
        self._MAX_AUTH_ENTRIES = 5000  # Max auth attempt entries

        # Option to fail closed when Redis is unavailable (more secure)
        # If True, raises RateLimitExceeded instead of using local fallback
        self._fail_closed_on_redis_down = os.getenv("RATE_LIMIT_FAIL_CLOSED", "false").lower() == "true"

        # Optional persistent storage for local fallback (file-based)
        # If set, local limits persist across restarts (prevents abuse)
        self._persistent_storage_path = os.getenv("RATE_LIMIT_PERSISTENT_STORAGE", None)
        self._persistent_storage_lock = threading.Lock()

        self._local_limits: Dict[str, list] = {}  # key -> list of timestamps
        self._local_costs: Dict[str, list] = {}  # key -> list of (timestamp, cost) tuples for sliding window
        self._local_auth_attempts: Dict[str, Dict[str, float]] = {}  # key -> {count: int, first_attempt: float}
        self._local_lock = threading.Lock()  # Thread-safety for local fallback
        self._cleanup_thread_running = False  # Flag to prevent duplicate cleanup threads
        self._cleanup_thread_lock = threading.Lock()  # Lock for thread restart logic

        # Load persistent storage if available
        if self._persistent_storage_path:
            self._load_persistent_storage()

        # Start periodic cleanup thread for local limits
        # Note: Thread restarts automatically on failure (see _cleanup_local_limits)
        with self._cleanup_thread_lock:
            if not self._cleanup_thread_running:
                self._cleanup_thread = threading.Thread(
                    target=self._cleanup_local_limits, daemon=True, name="RateLimiterCleanup"
                )
                self._cleanup_thread_running = True
                self._cleanup_thread.start()
                logger.debug("Started cleanup thread for local rate limits")

        # SECURITY NOTE: Redis isolation
        # For multi-tenant deployments, ensure Redis ACLs or namespaces are configured:
        # - Use Redis ACLs: redis-cli ACL SETUSER app_user on >password ~tenant:* +@all
        # - Or use separate Redis databases: db=tenant_id % 16
        # - Or use Redis Cluster with tenant-based sharding
        # Current implementation relies on key naming (tenant_id in key) but ACLs provide defense-in-depth

        # Test connection first
        redis_available = False
        try:
            self.redis.ping()
            self.redis_circuit_breaker.record_success()
            redis_available = True
            logger.debug("Redis connection successful")
        except RedisError as e:
            logger.warning(f"Initial Redis connection failed: {e}. Will use local fallback.")
            self.redis_circuit_breaker.record_failure()

        # Load Lua script for atomic rate limiting (only if Redis is available)
        # If Redis is not available, we'll use eval() directly when needed (no warning needed)
        if redis_available:
            try:
                sha = self.redis.script_load(self.LUA_RATE_LIMIT_SCRIPT)
                sha_str = sha.decode("utf-8") if isinstance(sha, bytes) else (sha or "")
                # Validate SHA format (40 hex chars) to avoid silent failures from invalid SHA
                if sha_str and re.match(r"^[a-f0-9]{40}$", sha_str):
                    self._lua_script_sha = sha  # Keep original (bytes or str) for evalsha
                else:
                    logger.error(f"Invalid Lua script SHA from Redis: {sha!r}")
                    self._lua_script_sha = None
            except RedisError as e:
                logger.warning(f"Failed to load Lua script: {e}. Will use eval() directly.")
                self._lua_script_sha = None
        else:
            # Redis not available - skip script loading, will use eval() when needed
            self._lua_script_sha = None

        # Start periodic health check thread
        self._health_check_thread = threading.Thread(
            target=self._periodic_health_check, daemon=True, name="RateLimiterHealthCheck"
        )
        self._health_check_thread.start()
        logger.debug("Started Redis health check thread")

    def _periodic_health_check(self) -> None:
        """
        Periodically check Redis connection health and attempt reconnection.

        Runs every 30 seconds to detect when Redis recovers.
        """
        while True:
            try:
                time.sleep(30)  # Check every 30 seconds

                # Only check if circuit breaker is open (Redis was down)
                if self.redis_circuit_breaker.is_open():
                    try:
                        # Attempt to ping Redis
                        self.redis.ping()
                        # Success - record success to potentially close circuit breaker
                        self.redis_circuit_breaker.record_success()
                        logger.info("Redis connection recovered - circuit breaker may close")
                        # Reload Lua script so evalsha can be used (more efficient than eval)
                        if self._lua_script_sha is None:
                            try:
                                self._lua_script_sha = self.redis.script_load(self.LUA_RATE_LIMIT_SCRIPT)
                                logger.info("Lua rate limit script loaded after Redis recovery")
                            except RedisError:
                                logger.debug("Lua script load failed after recovery, will continue using eval()")
                    except RedisError:
                        # Still down, record failure
                        self.redis_circuit_breaker.record_failure()
                        logger.debug("Redis still unavailable, continuing with local fallback")
            except Exception as e:
                logger.error(f"Error in Redis health check: {e}", exc_info=True)
                # Continue health checking even if there's an error

    def _get_rate_limit_key(self, tenant_id: uuid.UUID, user_id: uuid.UUID) -> bytes:
        """
        Generate Redis key for rate limiting.

        Args:
            tenant_id: Tenant UUID
            user_id: User UUID

        Returns:
            Redis key as bytes
        """
        return f"rate_limit:{tenant_id}:{user_id}".encode("utf-8")

    def _cleanup_local_limits(self) -> None:
        """
        Periodically clean up old entries from local limits to prevent memory bloat.

        Restarts automatically on failure to prevent silent thread death.
        """
        while True:
            try:
                time.sleep(300)  # Run every 5 minutes
                with self._local_lock:
                    now = time.time()
                    keys_to_remove = []

                    for key, timestamps in self._local_limits.items():
                        # Remove old entries
                        self._local_limits[key] = [ts for ts in timestamps if now - ts < self.TIME_WINDOW]

                        # Remove empty entries
                        if not self._local_limits[key]:
                            keys_to_remove.append(key)

                    for key in keys_to_remove:
                        del self._local_limits[key]

                    # Clean up old cost entries (60 second window for cost tracking)
                    cost_keys_to_remove = []
                    for key, cost_entries in self._local_costs.items():
                        # Remove old entries (60 second window)
                        self._local_costs[key] = [(ts, cost) for ts, cost in cost_entries if now - ts < 60]

                        # Remove empty entries
                        if not self._local_costs[key]:
                            cost_keys_to_remove.append(key)

                    for key in cost_keys_to_remove:
                        del self._local_costs[key]

                    # Clean up old auth attempts (5 minute window)
                    auth_keys_to_remove = []
                    for key, data in self._local_auth_attempts.items():
                        if now - data.get("first_attempt", now) >= 300:  # 5 minutes
                            auth_keys_to_remove.append(key)

                    for key in auth_keys_to_remove:
                        del self._local_auth_attempts[key]

                    if keys_to_remove or auth_keys_to_remove or cost_keys_to_remove:
                        logger.debug(
                            f"Cleaned up {len(keys_to_remove)} rate limit entries, "
                            f"{len(cost_keys_to_remove)} cost entries, "
                            f"and {len(auth_keys_to_remove)} auth attempt entries"
                        )

                    # Save to persistent storage if configured
                    if self._persistent_storage_path:
                        self._save_persistent_storage()
            except Exception as e:
                # Log error and restart thread to prevent silent failure
                logger.error(f"Error in local limits cleanup: {e}. Restarting cleanup thread.", exc_info=True)
                # Restart cleanup thread (with lock to prevent duplicates)
                with self._cleanup_thread_lock:
                    # Check if thread is still marked as running (may have been restarted by another thread)
                    if not self._cleanup_thread_running:
                        # Another thread already restarted it, just exit
                        break

                    # Mark current thread as no longer running
                    self._cleanup_thread_running = False

                    # Verify thread is actually dead before restarting
                    if hasattr(self, "_cleanup_thread") and self._cleanup_thread.is_alive():
                        # Thread is still alive, don't restart
                        logger.warning("Cleanup thread is still alive, not restarting")
                        break

                    # Restart cleanup thread
                    try:
                        self._cleanup_thread = threading.Thread(
                            target=self._cleanup_local_limits, daemon=True, name="RateLimiterCleanup"
                        )
                        self._cleanup_thread_running = True
                        self._cleanup_thread.start()
                        logger.info("Cleanup thread restarted successfully")
                    except Exception as restart_error:
                        logger.critical(f"Failed to restart cleanup thread: {restart_error}", exc_info=True)
                        self._cleanup_thread_running = False
                break  # Exit current thread (new one started if successful)

    def _check_local_rate_limit(
        self,
        tenant_id: uuid.UUID,
        user_id: uuid.UUID,
        tier: UserTier,
        endpoint_cost: int = 1,
    ) -> bool:
        """
        Local in-memory rate limiter (stricter than Redis).

        Used as fallback when Redis is unavailable.
        Uses 50% of normal limit for safety.
        Implements both count and cost-based limiting.
        Thread-safe with lock protection.

        Args:
            tenant_id: Tenant UUID
            user_id: User UUID
            tier: User subscription tier
            endpoint_cost: Cost of this operation (default: 1)

        Returns:
            True if request is allowed

        Raises:
            RateLimitExceeded: If rate limit or cost limit is exceeded
        """
        if tier == UserTier.ENTERPRISE:
            return True

        key = f"{tenant_id}:{user_id}"
        now = time.time()

        # Use 50% of normal limit during Redis failure (conservative)
        rate_limit = int(self.RATE_LIMITS.get(tier, self.RATE_LIMITS[UserTier.FREE]) * 0.5)

        # Cost budgets (50% of normal for safety)
        cost_budget = {
            UserTier.FREE: 5,  # 50% of 10
            UserTier.PRO: 100,  # 50% of 200
        }
        budget = cost_budget.get(tier, cost_budget[UserTier.FREE])

        # CRITICAL: All operations on _local_limits and _local_costs must be thread-safe
        with self._local_lock:
            # Enforce bounded cache size to prevent memory exhaustion
            if key not in self._local_limits:
                if len(self._local_limits) >= self._MAX_LOCAL_ENTRIES:
                    # Evict oldest entries (LRU approximation)
                    # Remove 10% of entries to avoid frequent evictions
                    entries_to_remove = max(1, self._MAX_LOCAL_ENTRIES // 10)
                    keys_to_evict = list(self._local_limits.keys())[:entries_to_remove]
                    for k in keys_to_evict:
                        del self._local_limits[k]
                        if k in self._local_costs:
                            del self._local_costs[k]
                    logger.warning(f"Local rate limit cache full, evicted {entries_to_remove} entries")
                self._local_limits[key] = []

            if key not in self._local_costs:
                self._local_costs[key] = []

            # Remove old entries from count tracking
            self._local_limits[key] = [ts for ts in self._local_limits[key] if now - ts < self.TIME_WINDOW]

            # Remove old entries from cost tracking (60 second window)
            self._local_costs[key] = [(ts, cost) for ts, cost in self._local_costs[key] if now - ts < 60]

            # Check count limit
            if len(self._local_limits[key]) >= rate_limit:
                retry_after = (
                    int(self.TIME_WINDOW - (now - self._local_limits[key][0])) + 1
                    if self._local_limits[key]
                    else self.TIME_WINDOW
                )
                raise RateLimitExceeded(
                    f"Rate limit exceeded (local fallback): {rate_limit} requests per {self.TIME_WINDOW} seconds",
                    retry_after=retry_after,
                )

            # Check cost budget
            current_cost = sum(cost for _, cost in self._local_costs[key])
            if current_cost + endpoint_cost > budget:
                raise RateLimitExceeded(
                    f"Cost limit exceeded (local fallback): {current_cost + endpoint_cost} > {budget}", retry_after=60
                )

            # All checks passed - add entries
            self._local_limits[key].append(now)
            self._local_costs[key].append((now, endpoint_cost))

            # Save to persistent storage if configured
            if self._persistent_storage_path:
                self._save_persistent_storage()

        return True

    def _save_persistent_storage(self) -> None:
        """
        Save local rate limit state to persistent storage (file-based).

        Uses JSON instead of pickle to avoid CWE-502 (arbitrary code execution
        during deserialization). This prevents rate limits from resetting on
        server restart when Redis is down.
        """
        if not self._persistent_storage_path:
            return

        try:
            with self._persistent_storage_lock:
                # Only save essential data (keys, timestamps, costs)
                # Don't save auth attempts (security-sensitive, should reset)
                # Convert costs from [(ts, cost), ...] to [[ts, cost], ...] for JSON
                data: Dict[str, Any] = {
                    "limits": {
                        k: v
                        for k, v in self._local_limits.items()
                        if len(v) > 0  # Only save non-empty entries
                    },
                    "costs": {
                        k: [[ts, cost] for ts, cost in v]
                        for k, v in self._local_costs.items()
                        if len(v) > 0  # Only save non-empty entries
                    },
                    "timestamp": time.time(),
                }

                # Use atomic write (write to temp, then rename)
                temp_path = f"{self._persistent_storage_path}.tmp"
                with open(temp_path, "w", encoding="utf-8") as f:
                    json.dump(data, f)

                # Atomic rename (works on both Unix and Windows)
                if os.path.exists(self._persistent_storage_path):
                    os.replace(temp_path, self._persistent_storage_path)
                else:
                    os.rename(temp_path, self._persistent_storage_path)
        except Exception as e:
            logger.warning(f"Failed to save persistent rate limit storage: {e}", exc_info=False)

    def _load_persistent_storage(self) -> None:
        """
        Load local rate limit state from persistent storage.

        Uses JSON (not pickle) to avoid CWE-502 deserialization attacks.
        Restores rate limits after server restart when Redis is down.
        """
        if not self._persistent_storage_path or not os.path.exists(self._persistent_storage_path):
            return

        try:
            with self._persistent_storage_lock:
                with open(self._persistent_storage_path, "r", encoding="utf-8") as f:
                    data = json.load(f)

                # Check if data is stale (older than 1 hour)
                saved_timestamp = data.get("timestamp", 0)
                if time.time() - saved_timestamp > 3600:  # 1 hour
                    logger.debug("Persistent rate limit storage is stale, ignoring")
                    return

                # Restore limits
                self._local_limits.update(data.get("limits", {}))

                # Restore costs: convert [[ts, cost], ...] back to [(ts, cost), ...]
                raw_costs = data.get("costs", {})
                for k, v in raw_costs.items():
                    self._local_costs[k] = [(item[0], item[1]) for item in v]

                logger.info(
                    f"Loaded persistent rate limit storage: "
                    f"{len(self._local_limits)} limit entries, "
                    f"{len(self._local_costs)} cost entries"
                )
        except json.JSONDecodeError as e:
            # Old pickle format or corrupted - skip (do not use pickle for security)
            logger.warning(f"Persistent rate limit storage is not valid JSON (possibly old format), skipping: {e}")
        except Exception as e:
            logger.warning(f"Failed to load persistent rate limit storage: {e}", exc_info=False)

    def _check_local_auth_limit(
        self,
        tenant_id: uuid.UUID,
        username: str,
    ) -> bool:
        """
        Local in-memory auth attempt limiter (stricter than Redis).

        Used as fallback when Redis is unavailable.
        Uses same limits as Redis (5 attempts per 5 minutes).
        Thread-safe with lock protection.

        Args:
            tenant_id: Tenant UUID
            username: Username attempting authentication

        Returns:
            True if auth attempt is allowed

        Raises:
            RateLimitExceeded: If too many failed attempts
        """
        # MUST use sanitized username to match Redis path and reset_auth_attempts
        safe_username = self._sanitize_username_for_key(username)
        key = f"auth_attempts:{tenant_id}:{safe_username}"
        now = time.time()
        max_attempts = 5
        window_seconds = 300  # 5 minutes

        with self._local_lock:
            if key not in self._local_auth_attempts:
                # Enforce bounded cache size to prevent memory exhaustion
                if len(self._local_auth_attempts) >= self._MAX_AUTH_ENTRIES:
                    # Evict oldest entries based on first_attempt timestamp
                    entries_to_remove = max(1, self._MAX_AUTH_ENTRIES // 10)
                    # Sort by first_attempt and remove oldest
                    sorted_keys = sorted(
                        self._local_auth_attempts.keys(),
                        key=lambda k: self._local_auth_attempts[k].get("first_attempt", 0),
                    )
                    for k in sorted_keys[:entries_to_remove]:
                        del self._local_auth_attempts[k]
                    logger.warning(f"Local auth attempts cache full, evicted {entries_to_remove} entries")
                self._local_auth_attempts[key] = {"count": 0, "first_attempt": now}

            data = self._local_auth_attempts[key]

            # Reset if window expired
            if now - data["first_attempt"] >= window_seconds:
                data["count"] = 0
                data["first_attempt"] = now

            # Check limit BEFORE incrementing (matches Redis behavior)
            # This allows exactly max_attempts attempts (0 to max_attempts-1)
            if data["count"] >= max_attempts:
                retry_after = int(window_seconds - (now - data["first_attempt"])) + 1
                raise RateLimitExceeded(
                    "Too many authentication attempts. Please try again later.", retry_after=retry_after
                )

            # Increment attempt count
            data["count"] += 1

        return True

    def check_rate_limit(
        self,
        tenant_id: uuid.UUID,
        user_id: uuid.UUID,
        tier: UserTier,
        endpoint_cost: int = 1,
    ) -> bool:
        """
        Check if user has exceeded rate limit with cost-based limiting.

        Args:
            tenant_id: Tenant UUID
            user_id: User UUID
            tier: User subscription tier
            endpoint_cost: Cost of this operation (default: 1, max: 100)

        Returns:
            True if request is allowed

        Raises:
            RateLimitExceeded: If rate limit is exceeded (with retry_after)
            ValueError: If endpoint_cost is invalid
        """
        # Validate endpoint_cost to prevent bypass attempts
        if not isinstance(endpoint_cost, int) or endpoint_cost < 1 or endpoint_cost > 100:
            raise ValueError(f"Invalid endpoint_cost: {endpoint_cost}. Must be integer between 1 and 100.")

        # Enterprise tier has unlimited requests
        if tier == UserTier.ENTERPRISE:
            return True

        # Check circuit breaker - use local fallback if Redis is down
        if self.redis_circuit_breaker.is_open():
            logger.warning("Redis circuit breaker is OPEN - using local fallback")
            # Fail closed if configured
            if self._fail_closed_on_redis_down:
                logger.critical("Redis unavailable and RATE_LIMIT_FAIL_CLOSED=true. Rejecting request for security.")
                raise RateLimitExceeded("Rate limiting service unavailable. Please try again later.", retry_after=60)
            return self._check_local_rate_limit(tenant_id, user_id, tier, endpoint_cost)

        # Cost-based rate limiting
        cost_budget = {
            UserTier.FREE: 10,  # Can do: 2x LLM OR 10x validation
            UserTier.PRO: 200,  # Much higher
        }

        rate_limit = self.RATE_LIMITS.get(tier, self.RATE_LIMITS[UserTier.FREE])
        budget = cost_budget.get(tier, cost_budget[UserTier.FREE])

        key = self._get_rate_limit_key(tenant_id, user_id)
        cost_key = f"rate_limit_cost:{tenant_id}:{user_id}".encode("utf-8")
        counter_key = f"rate_limit:counter:{tenant_id}:{user_id}".encode("utf-8")

        try:
            # Use atomic Lua script to prevent race conditions (TOCTOU vulnerability fix)
            now = time.time()
            window_start = now - self.TIME_WINDOW

            # Execute Lua script atomically
            # Returns: [status, retry_after, limit_type]
            # status: 0 = allowed, 1 = count exceeded, 2 = cost exceeded
            if self._lua_script_sha:
                # Use cached script SHA for better performance
                result = self.redis.evalsha(
                    self._lua_script_sha,
                    3,  # Number of keys (count, cost, counter)
                    key,
                    cost_key,
                    counter_key,
                    window_start,
                    now,
                    rate_limit,
                    budget,
                    endpoint_cost,
                    self.TIME_WINDOW,
                )
            else:
                # Fallback to eval() if script not loaded
                result = self.redis.eval(
                    self.LUA_RATE_LIMIT_SCRIPT,
                    3,  # Number of keys (count, cost, counter)
                    key,
                    cost_key,
                    counter_key,
                    window_start,
                    now,
                    rate_limit,
                    budget,
                    endpoint_cost,
                    self.TIME_WINDOW,
                )

            status = int(result[0])
            retry_after = int(result[1])

            if status == 1:  # Count limit exceeded
                raise RateLimitExceeded(
                    f"Rate limit exceeded: {rate_limit} requests per {self.TIME_WINDOW} seconds",
                    retry_after=retry_after,
                )
            elif status == 2:  # Cost limit exceeded
                raise RateLimitExceeded(f"Cost limit exceeded: budget {budget} exceeded", retry_after=retry_after)

            # Request allowed (status == 0)
            # Record success for circuit breaker
            self.redis_circuit_breaker.record_success()

            return True

        except RedisError as e:
            # Record failure for circuit breaker
            self.redis_circuit_breaker.record_failure()

            # Fail closed if configured (more secure)
            if self._fail_closed_on_redis_down:
                logger.critical("Redis unavailable and RATE_LIMIT_FAIL_CLOSED=true. Rejecting request for security.")
                raise RateLimitExceeded("Rate limiting service unavailable. Please try again later.", retry_after=60)

            # Use local fallback with stricter limits
            logger.warning(f"Redis failure in rate limiting: {e}. Using local fallback.")
            return self._check_local_rate_limit(tenant_id, user_id, tier, endpoint_cost)

    def get_remaining_quota(
        self,
        tenant_id: uuid.UUID,
        user_id: uuid.UUID,
        tier: UserTier,
    ) -> int:
        """
        Get remaining quota for user.

        Args:
            tenant_id: Tenant UUID
            user_id: User UUID
            tier: User subscription tier

        Returns:
            Number of remaining requests in current window
            Returns -1 for enterprise tier (unlimited)
        """
        if tier == UserTier.ENTERPRISE:
            return -1  # Unlimited

        rate_limit = self.RATE_LIMITS.get(tier, self.RATE_LIMITS[UserTier.FREE])
        key = self._get_rate_limit_key(tenant_id, user_id)

        try:
            now = time.time()
            window_start = now - self.TIME_WINDOW

            # Remove old entries
            self.redis.zremrangebyscore(key, 0, window_start)

            # Count current requests
            current_count = self.redis.zcard(key)

            remaining = max(0, rate_limit - current_count)
            return remaining

        except RedisError:
            # On Redis failure, return rate limit (assume no usage)
            return rate_limit

    # Lua script for atomic auth attempt checking (fixes race condition)
    LUA_AUTH_LIMIT_SCRIPT = """
    local key = KEYS[1]
    local max_attempts = tonumber(ARGV[1])
    local window_seconds = tonumber(ARGV[2])
    
    -- Get current attempts
    local attempts = tonumber(redis.call('GET', key) or 0)
    
    -- Check if already at limit BEFORE incrementing
    if attempts >= max_attempts then
        local ttl = redis.call('TTL', key)
        if ttl < 0 then ttl = window_seconds end
        return {1, ttl}  -- 1 = blocked, ttl = retry after
    end
    
    -- Atomically increment and set expiry
    local new_count = redis.call('INCR', key)
    if new_count == 1 then
        -- First attempt, set expiry
        redis.call('EXPIRE', key, window_seconds)
    end
    
    return {0, 0}  -- 0 = allowed
    """

    def _sanitize_username_for_key(self, username: str) -> str:
        """
        Sanitize username for use in Redis keys to prevent injection and collisions.

        Uses hash-based key generation to prevent collisions from sanitization
        (e.g., "user@domain" and "user#domain" would collide with simple sanitization).

        Args:
            username: Raw username string

        Returns:
            Hash-based key safe for Redis (prevents collisions)
        """
        import hashlib

        # Always use hash-based keys to prevent collisions
        # This ensures "user@domain" and "user#domain" get different keys
        hash_value = hashlib.sha256(username.encode("utf-8")).hexdigest()[:32]
        return f"u_{hash_value}"

    def check_auth_attempt_limit(
        self,
        tenant_id: uuid.UUID,
        username: str,
    ) -> bool:
        """
        Prevent brute force attacks on authentication.

        Uses atomic Lua script to prevent race conditions where
        concurrent requests could exceed the limit.

        Args:
            tenant_id: Tenant UUID
            username: Username attempting authentication

        Returns:
            True if auth attempt is allowed

        Raises:
            RateLimitExceeded: If too many failed attempts
        """
        # Sanitize username to prevent Redis key injection
        safe_username = self._sanitize_username_for_key(username)
        key = f"auth_attempts:{tenant_id}:{safe_username}".encode("utf-8")

        max_attempts = 5
        window_seconds = 300  # 5 minutes

        try:
            # Use atomic Lua script to prevent race condition
            result = self.redis.eval(
                self.LUA_AUTH_LIMIT_SCRIPT,
                1,  # Number of keys
                key,
                max_attempts,
                window_seconds,
            )

            status = int(result[0])
            retry_after = int(result[1])

            if status == 1:  # Blocked
                raise RateLimitExceeded(
                    "Too many authentication attempts. Please try again later.", retry_after=retry_after
                )

            return True

        except RedisError as e:
            # On Redis failure, use local fallback (fail closed for security)
            # Auth attempts are critical - always use local fallback (don't fail closed)
            # to prevent lockout during Redis outages
            logger.warning(f"Redis error in auth rate limiting: {e}. Using local fallback.")
            return self._check_local_auth_limit(tenant_id, username)

    def reset_auth_attempts(
        self,
        tenant_id: uuid.UUID,
        username: str,
        requesting_user_id: Optional[uuid.UUID] = None,
        is_self_reset: bool = False,
    ) -> None:
        """
        Reset auth attempt counter.

        SECURITY: This function should only be called:
        1. On successful login (is_self_reset=True, system call)
        2. By admin users with proper authorization (requesting_user_id required)

        Args:
            tenant_id: Tenant UUID
            username: Username to reset
            requesting_user_id: User ID making the request (for audit)
            is_self_reset: True if this is called after successful login

        Raises:
            ValueError: If neither is_self_reset nor requesting_user_id provided
        """
        # Security check: require either self-reset flag or requesting user
        if not is_self_reset and requesting_user_id is None:
            raise ValueError(
                "reset_auth_attempts requires either is_self_reset=True "
                "(for post-login reset) or requesting_user_id (for admin reset)"
            )

        # Log admin resets for audit trail
        if not is_self_reset and requesting_user_id:
            logger.info(
                "Admin reset of auth attempts",
                extra={
                    "tenant_id": str(tenant_id),
                    "target_username": username[:3] + "***",  # Partial for privacy
                    "requesting_user_id": str(requesting_user_id),
                },
            )

        # Sanitize username for key
        safe_username = self._sanitize_username_for_key(username)
        key = f"auth_attempts:{tenant_id}:{safe_username}".encode("utf-8")
        local_key = f"auth_attempts:{tenant_id}:{safe_username}"

        # Reset in Redis
        try:
            self.redis.delete(key)
        except RedisError as e:
            logger.error(f"Failed to reset auth attempts in Redis: {e}")

        # Reset in local fallback
        with self._local_lock:
            if local_key in self._local_auth_attempts:
                del self._local_auth_attempts[local_key]

    def reset_rate_limit(
        self,
        tenant_id: uuid.UUID,
        user_id: uuid.UUID,
        requesting_user_id: uuid.UUID,
        is_admin: bool = False,
    ) -> None:
        """
        Reset rate limit for a user (admin function).

        SECURITY: Requires admin privileges and logs the action.

        Args:
            tenant_id: Tenant UUID
            user_id: Target user UUID to reset
            requesting_user_id: User ID making the request
            is_admin: Whether the requesting user has admin privileges

        Raises:
            PermissionError: If requesting user is not admin
        """
        # Security check: require admin privileges
        if not is_admin:
            logger.warning(
                "Unauthorized rate limit reset attempt",
                extra={
                    "tenant_id": str(tenant_id),
                    "target_user_id": str(user_id),
                    "requesting_user_id": str(requesting_user_id),
                },
            )
            raise PermissionError("Admin privileges required to reset rate limits")

        # Log admin action for audit trail
        logger.info(
            "Admin reset of rate limit",
            extra={
                "tenant_id": str(tenant_id),
                "target_user_id": str(user_id),
                "requesting_user_id": str(requesting_user_id),
            },
        )

        key = self._get_rate_limit_key(tenant_id, user_id)
        cost_key = f"rate_limit_cost:{tenant_id}:{user_id}".encode("utf-8")
        local_key = f"{tenant_id}:{user_id}"

        try:
            self.redis.delete(key)
            self.redis.delete(cost_key)
        except RedisError as e:
            logger.error(f"Failed to reset rate limit in Redis: {e}")

        # Also reset local fallback
        with self._local_lock:
            if local_key in self._local_limits:
                del self._local_limits[local_key]
            if local_key in self._local_costs:
                del self._local_costs[local_key]
