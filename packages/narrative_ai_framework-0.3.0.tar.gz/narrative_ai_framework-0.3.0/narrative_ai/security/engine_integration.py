"""
Shared security integration helpers for engines.

Provides a single source of truth for rate limiting, audit logging, and
user/tenant UUID resolution. All engines (STT, TTS, LLM, RAG, etc.) can
use these helpers to ensure identical behavior and avoid drift.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Callable, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

# Optional imports - functions no-op when security unavailable
RateLimiter = None
RateLimitExceeded = None
EndpointCosts = None
UserTier = None
AuditLogger = None
ActionType = None
ActionStatus = None

try:
    from narrative_ai.security.rate_limiting import (
        RateLimiter as _RateLimiter,
        RateLimitExceeded as _RateLimitExceeded,
        EndpointCosts as _EndpointCosts,
        UserTier as _UserTier,
    )

    RateLimiter = _RateLimiter
    RateLimitExceeded = _RateLimitExceeded
    EndpointCosts = _EndpointCosts
    UserTier = _UserTier
except ImportError:
    pass

try:
    from narrative_ai.security.audit_trail import (
        AuditLogger as _AuditLogger,
        ActionType as _ActionType,
        ActionStatus as _ActionStatus,
    )

    AuditLogger = _AuditLogger
    ActionType = _ActionType
    ActionStatus = _ActionStatus
except ImportError:
    pass


def resolve_user_tenant_uuids(
    user_id: Optional[Any],
    tenant_id: Optional[Any],
    engine_namespace: str,
) -> Tuple[uuid.UUID, uuid.UUID]:
    """
    Resolve user_id and tenant_id to UUIDs for rate limiting and audit.

    When user_id or tenant_id is None, uses anonymous bucket UUIDs derived
    from engine_namespace so unauthenticated requests share FREE tier limits.

    Args:
        user_id: User ID (str, UUID, or None)
        tenant_id: Tenant ID (str, UUID, or None)
        engine_namespace: Namespace for anonymous UUIDs (e.g. "anon.engine.rag")

    Returns:
        Tuple of (user_uuid, tenant_uuid)
    """

    def _to_uuid(val: Any, name: str, anon_ns: str) -> uuid.UUID:
        if val is None:
            return uuid.uuid5(uuid.NAMESPACE_DNS, anon_ns)
        if isinstance(val, uuid.UUID):
            return val
        try:
            return uuid.UUID(str(val))
        except (ValueError, TypeError):
            return uuid.uuid5(uuid.NAMESPACE_DNS, f"{engine_namespace}.{name}.{val}")

    user_uuid = _to_uuid(user_id, "user", engine_namespace)
    tenant_uuid = _to_uuid(tenant_id, "tenant", engine_namespace)
    return user_uuid, tenant_uuid


def check_rate_limit_for_engine(
    rate_limiter: Any,
    user_id: Optional[Any],
    tenant_id: Optional[Any],
    endpoint_cost: int,
    engine_namespace: str,
    user_tier: Optional[Any] = None,
    user_tier_callback: Optional[Callable[[Optional[str], Optional[str]], Any]] = None,
) -> None:
    """
    Check rate limit for an engine. No-op if rate_limiter is None or security unavailable.

    Args:
        rate_limiter: RateLimiter instance or None
        user_id: User ID for rate limiting
        tenant_id: Tenant ID for rate limiting
        endpoint_cost: Cost for this operation (from EndpointCosts)
        engine_namespace: Namespace for anonymous UUIDs
        user_tier: Explicit tier (UserTier) or None
        user_tier_callback: Optional callback (user_id, tenant_id) -> UserTier

    Raises:
        RateLimitExceeded: If rate limit exceeded (when security available)
    """
    if rate_limiter is None or UserTier is None or RateLimitExceeded is None:
        return

    user_uuid, tenant_uuid = resolve_user_tenant_uuids(user_id, tenant_id, engine_namespace)

    # Tier lookup: explicit param > callback > FREE (secure default)
    if user_tier is not None:
        tier = user_tier
    elif user_tier_callback and (user_id or tenant_id):
        try:
            looked_up = user_tier_callback(user_id, tenant_id)
            tier = looked_up if looked_up is not None else UserTier.FREE
        except Exception as e:
            logger.debug("User tier lookup failed, using FREE: %s", e)
            tier = UserTier.FREE
    else:
        tier = UserTier.FREE

    rate_limiter.check_rate_limit(
        tenant_id=tenant_uuid,
        user_id=user_uuid,
        tier=tier,
        endpoint_cost=endpoint_cost,
    )


def _audit_uuid(val: Any, engine_namespace: str, fallback_suffix: str) -> uuid.UUID:
    """Resolve value to UUID for audit logging."""
    if val is None:
        return uuid.uuid5(uuid.NAMESPACE_DNS, f"{engine_namespace}.{fallback_suffix}")
    if isinstance(val, uuid.UUID):
        return val
    try:
        return uuid.UUID(str(val))
    except (ValueError, TypeError):
        return uuid.uuid5(uuid.NAMESPACE_DNS, f"{engine_namespace}.audit.{val}")


def log_audit_for_engine(
    audit_logger: Any,
    user_id: Optional[Any],
    tenant_id: Optional[Any],
    action: Any,
    resource_type: str,
    status: str,
    details: Dict[str, Any],
    resource_id: Optional[uuid.UUID] = None,
    engine_namespace: str = "anon.engine",
    correlation_id: Optional[str] = None,
) -> None:
    """
    Log audit event synchronously. No-op if audit_logger is None or security unavailable.

    Args:
        audit_logger: AuditLogger instance or None
        user_id: User ID
        tenant_id: Tenant ID
        action: ActionType value
        resource_type: Type of resource (e.g. "rag_recall")
        status: "success" or "failure"
        details: Additional details dict
        resource_id: Optional resource UUID
        engine_namespace: Namespace for anonymous UUIDs
        correlation_id: Optional correlation ID (added to details)
    """
    if audit_logger is None or ActionType is None or ActionStatus is None:
        return

    if correlation_id is not None:
        details = {**details, "correlation_id": correlation_id}

    try:
        if user_id and tenant_id:
            uid = _audit_uuid(user_id, engine_namespace, "user")
            tid = _audit_uuid(tenant_id, engine_namespace, "tenant")
        else:
            tid = uuid.uuid5(uuid.NAMESPACE_DNS, engine_namespace)
            uid = uuid.uuid5(
                uuid.NAMESPACE_DNS,
                f"{engine_namespace}.{correlation_id or uuid.uuid4()}",
            )

        audit_logger.log_action(
            user_id=uid,
            tenant_id=tid,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id or uuid.uuid4(),
            status=ActionStatus.SUCCESS if status == "success" else ActionStatus.FAILURE,
            details=details,
        )
    except Exception as e:
        logger.warning("Audit logging failed: %s", e, extra={"correlation_id": correlation_id})


def log_audit_for_engine_async(
    audit_logger: Any,
    user_id: Optional[Any],
    tenant_id: Optional[Any],
    action: Any,
    resource_type: str,
    status: str,
    details: Dict[str, Any],
    resource_id: Optional[uuid.UUID] = None,
    engine_namespace: str = "anon.engine",
    correlation_id: Optional[str] = None,
) -> None:
    """
    Log audit event asynchronously (fire-and-forget). No-op if audit_logger is None.
    """
    if audit_logger is None or ActionType is None or ActionStatus is None:
        return

    if correlation_id is not None:
        details = {**details, "correlation_id": correlation_id}

    try:
        if user_id and tenant_id:
            uid = _audit_uuid(user_id, engine_namespace, "user")
            tid = _audit_uuid(tenant_id, engine_namespace, "tenant")
        else:
            tid = uuid.uuid5(uuid.NAMESPACE_DNS, engine_namespace)
            uid = uuid.uuid5(
                uuid.NAMESPACE_DNS,
                f"{engine_namespace}.{correlation_id or uuid.uuid4()}",
            )

        audit_logger.log_action_async(
            user_id=uid,
            tenant_id=tid,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            status=ActionStatus.SUCCESS if status == "success" else ActionStatus.FAILURE,
            details=details,
        )
    except Exception as e:
        logger.warning("Async audit logging failed: %s", e, extra={"correlation_id": correlation_id})
