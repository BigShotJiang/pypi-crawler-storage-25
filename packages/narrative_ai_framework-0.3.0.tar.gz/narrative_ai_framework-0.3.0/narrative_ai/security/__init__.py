"""
Security Foundation Module for Narrative AI Voice Mode.

This module provides a 5-layer security architecture:

1. Stream Isolation (stream_isolation.py)
   - Tenant/user isolation for voice streams
   - Session management with TTL validation
   - Cross-tenant access prevention

2. Input Validation (input_validation.py)
   - Audio file validation (format, size, duration)
   - Text validation with injection protection
   - Parameter validation for API calls
   - Null byte and control character sanitization

3. Rate Limiting (rate_limiting.py)
   - Per-user, per-tier request limits
   - Cost-based rate limiting for expensive operations
   - Redis-based distributed rate limiting
   - Local fallback with circuit breaker pattern
   - Brute-force attack prevention for auth

4. Error Handling (error_handling.py)
   - Sanitized error messages (no internal leaks)
   - Structured internal logging
   - Log injection prevention
   - Exception sanitization

5. Audit Trail (audit_trail.py)
   - Immutable action logging (SOC2 compliant)
   - Tenant-isolated log retrieval
   - Optional encryption for sensitive details
   - Production enforcement of immutability triggers
"""

from narrative_ai.security.stream_isolation import StreamSecurityContext, StreamIsolationManager
from narrative_ai.security.input_validation import (
    validate_audio,
    validate_text,
    validate_parameters,
    ValidationError,
)
from narrative_ai.security.rate_limiting import RateLimiter, RateLimitExceeded
from narrative_ai.security.error_handling import (
    AuthenticationError,
    TenantIsolationError,
    SecurityError,
    SecureErrorHandler,
)
from narrative_ai.security.audit_trail import AuditLogger

__all__ = [
    "StreamSecurityContext",
    "StreamIsolationManager",
    "validate_audio",
    "validate_text",
    "validate_parameters",
    "ValidationError",
    "RateLimiter",
    "RateLimitExceeded",
    "AuthenticationError",
    "TenantIsolationError",
    "SecurityError",
    "SecureErrorHandler",
    "AuditLogger",
]
