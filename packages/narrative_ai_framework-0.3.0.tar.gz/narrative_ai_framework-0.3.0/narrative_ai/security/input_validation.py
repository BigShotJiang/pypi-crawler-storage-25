"""
Input Validation Security Layer.

Validates all user inputs (audio, text, parameters) to prevent
injection attacks and ensure data integrity. This is Layer 4 of the
6-layer security architecture.
"""

import re
import struct
import signal
import threading
import multiprocessing
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeoutError
from typing import Optional, Dict, Any, List
from io import BytesIO
import wave
from functools import wraps
import logging

logger = logging.getLogger(__name__)


class ValidationError(Exception):
    """Raised when input validation fails."""

    def __init__(self, message: str, field: Optional[str] = None):
        """
        Initialize validation error.

        Args:
            message: Human-readable error message (will be sanitized)
            field: Optional field name that failed validation
        """
        super().__init__(message)
        self.message = message
        self.field = field


# Pre-compiled SQL injection patterns with atomic groups to prevent ReDoS
# Using atomic groups (?:...) to prevent catastrophic backtracking
#
# IMPORTANT: We use SQLAlchemy ORM with parameterized queries throughout.
# Parameterized queries prevent SQL injection at the database level.
# These patterns catch OBVIOUS attack attempts for logging/alerting purposes,
# but we DO NOT block common characters like quotes, semicolons, or pipes
# because they appear in legitimate diary entries (e.g., "It's a beautiful day").
#
# PHILOSOPHY: Defense in depth - parameterized queries are the primary defense,
# these patterns are secondary alerting/logging for suspicious payloads.
# SQL injection patterns - improved to reduce false positives
# These patterns catch OBVIOUS SQL injection attempts while allowing legitimate text
SQL_INJECTION_PATTERNS = [
    # SELECT * or SELECT ... FROM (catches "SELECT * FROM users")
    re.compile(r"\bSELECT\s+\*", re.IGNORECASE),
    re.compile(
        r"\b(?:SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE)\s+(?:\*|FROM|INTO|TABLE|DATABASE|SCHEMA|INDEX)\b",
        re.IGNORECASE,
    ),
    # SQL comments (only at end of line or block comments, not in middle of words)
    re.compile(r"(?:--\s*$|/\*[^*]*\*/)", re.IGNORECASE | re.MULTILINE),
    # UNION SELECT attacks (with or without FROM)
    re.compile(r"\bUNION\s+(?:ALL\s+)?SELECT\s+", re.IGNORECASE),
    re.compile(r"\bUNION\s+(?:ALL\s+)?SELECT\s+.*\bFROM\b", re.IGNORECASE),
    # SQL tautology attacks (OR/AND 1=1)
    re.compile(r"\b(?:OR|AND)\s+['\"]?\d+['\"]?\s*=\s*['\"]?\d+\s*(?:--|;|$)?", re.IGNORECASE),
    # Chained destructive commands (semicolon followed by dangerous SQL)
    re.compile(r";\s*(?:DROP|DELETE|TRUNCATE|ALTER|EXEC|EXECUTE)\s+", re.IGNORECASE),
    # XSS patterns (separate from SQL but still security-relevant)
    re.compile(r"\b(?:script|javascript|vbscript|data):", re.IGNORECASE),  # Protocol handlers
    re.compile(r"\bon(?:load|error|click|mouse|focus|blur)\s*=", re.IGNORECASE),  # Event handlers
]

# Pre-compiled prompt injection patterns with atomic groups
#
# IMPORTANT: These patterns are designed to catch OBVIOUS prompt injection attacks
# while avoiding false positives on legitimate diary content.
# Patterns are intentionally specific to avoid blocking normal text.
#
# Examples that SHOULD be allowed:
# - "I'm going to ignore my previous worries" (diary reflection)
# - "The system was down today" (normal text)
# - "I need new instructions for the recipe" (normal text)
PROMPT_INJECTION_PATTERNS = [
    # Multi-word attack phrases (very specific to avoid false positives)
    re.compile(
        r"(?:ignore|disregard|forget)\s+(?:all\s+)?(?:previous|above|prior)\s+(?:instructions?|prompts?|commands?|rules?)",
        re.IGNORECASE,
    ),
    re.compile(r"(?:you\s+are\s+now|from\s+now\s+on\s+you\s+are)\s+(?:a|an|my)", re.IGNORECASE),  # Role reassignment
    re.compile(r"(?:override|bypass)\s+(?:your|all|system)\s+(?:instructions?|rules?|settings?)", re.IGNORECASE),
    re.compile(r"(?:pretend|act\s+as\s+if)\s+(?:you\s+are|there\s+are\s+no)\s+", re.IGNORECASE),
    # LLM token injection (exact format only - won't match "the system is")
    re.compile(r"<\|(?:im_start|im_end|system|user|assistant|endoftext)\|>", re.IGNORECASE),
    re.compile(r"\[(?:INST|/INST|SYS|/SYS)\]", re.IGNORECASE),  # Llama-style tokens
    # Jailbreak markers
    re.compile(r"(?:DAN|STAN|DUDE)\s*(?:mode|prompt|jailbreak)", re.IGNORECASE),
]


class RegexTimeoutError(Exception):
    """Raised when regex pattern matching times out."""

    pass


def _timeout_handler(signum, frame):
    """Signal handler for regex timeout."""
    raise RegexTimeoutError("Regex pattern matching exceeded timeout")


def _regex_worker(func, args, kwargs, result_queue, error_queue):
    """
    Worker function for multiprocessing-based regex timeout.

    SECURITY NOTE: Only primitive types (str, int, etc.) should be passed in args/kwargs.
    Custom objects are pickled and could be exploited if untrusted.
    """
    try:
        # Validate args are safe types (primitives only)
        for arg in args:
            if not isinstance(arg, (str, int, float, bool, type(None))):
                raise ValueError(f"Unsafe type in args: {type(arg)}. Only primitives allowed.")

        for key, value in kwargs.items():
            if not isinstance(value, (str, int, float, bool, type(None))):
                raise ValueError(f"Unsafe type in kwargs[{key}]: {type(value)}. Only primitives allowed.")

        result = func(*args, **kwargs)
        result_queue.put(result)
    except Exception as e:
        error_queue.put(e)


def regex_timeout(seconds: int = 1):
    """
    Decorator to timeout regex operations (works on both Unix and Windows).

    Uses signal-based timeout on Unix (efficient).
    Uses multiprocessing-based timeout on Windows (truly interruptible).

    Note: On Windows, multiprocessing adds overhead but ensures true timeout
    (threading won't interrupt stuck regex due to GIL).
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Unix: use signal-based timeout (efficient)
            if hasattr(signal, "SIGALRM"):
                old_handler = signal.signal(signal.SIGALRM, _timeout_handler)
                signal.alarm(seconds)
                try:
                    result = func(*args, **kwargs)
                finally:
                    signal.alarm(0)
                    signal.signal(signal.SIGALRM, old_handler)
                return result
            else:
                # Windows: use multiprocessing for true timeout (GIL-safe)
                # Also add threading.Timer as additional safety layer
                # This is slower but ensures regex can be interrupted
                # Note: For production, consider Unix deployment (Kubernetes)
                # where signal-based timeout is more efficient
                try:
                    import threading

                    # Use context manager for proper cleanup
                    ctx = multiprocessing.get_context("spawn")  # Windows-compatible
                    result_queue = ctx.Queue()
                    error_queue = ctx.Queue()

                    process = ctx.Process(
                        target=_regex_worker, args=(func, args, kwargs, result_queue, error_queue), daemon=True
                    )

                    # Additional safety: threading.Timer to force kill if process hangs
                    kill_timer = threading.Timer(
                        seconds + 0.5,  # Slightly longer than process timeout
                        lambda: (process.kill() if process.is_alive() else None),
                    )
                    kill_timer.start()

                    try:
                        process.start()
                        process.join(timeout=seconds)

                        if process.is_alive():
                            # Process still running - timeout occurred
                            process.terminate()
                            process.join(timeout=0.5)  # Shorter timeout for Windows
                            if process.is_alive():
                                process.kill()  # Force kill if still alive
                            raise RegexTimeoutError(f"Regex pattern matching exceeded timeout ({seconds}s)")

                        # Check for errors
                        if not error_queue.empty():
                            raise error_queue.get()

                        # Get result
                        if result_queue.empty():
                            raise RuntimeError("Regex worker completed but returned no result")

                        return result_queue.get()
                    finally:
                        kill_timer.cancel()  # Cancel timer if process completed
                except Exception as e:
                    # If multiprocessing fails, reject input (fail secure)
                    # This prevents ReDoS attacks when timeout mechanism fails
                    logger.error(
                        f"Multiprocessing timeout mechanism failed: {e}. Rejecting input for security.", exc_info=True
                    )
                    # Re-raise as RegexTimeoutError to trigger validation failure
                    raise RegexTimeoutError(
                        "Input validation timeout mechanism failed. Input rejected for security."
                    ) from e

        return wrapper

    return decorator


def _run_injection_pattern_checks_impl(text: str, pattern_set: str) -> bool:
    """
    Core implementation of injection pattern checks.
    pattern_set: 'sql' or 'prompt'.
    """
    patterns = SQL_INJECTION_PATTERNS if pattern_set == "sql" else PROMPT_INJECTION_PATTERNS
    for pattern in patterns:
        if pattern.search(text):
            return True
    return False


# Shared executor for regex timeout (avoids SIGALRM/signal.alarm limitations:
# - SIGALRM does not interrupt C-level regex; signal.alarm is single-alarm-per-process)
_regex_executor: Optional[ThreadPoolExecutor] = None
_regex_executor_lock = threading.Lock()


def _get_regex_executor() -> ThreadPoolExecutor:
    """Lazy-init shared executor for injection pattern checks (max 1 worker to serialize)."""
    global _regex_executor
    with _regex_executor_lock:
        if _regex_executor is None:
            _regex_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="RegexTimeout")
        return _regex_executor


def _run_injection_pattern_checks(text: str, pattern_set: str) -> bool:
    """
    Run SQL or prompt injection pattern checks against text with ReDoS timeout.

    Uses ThreadPoolExecutor on all platforms. Avoids signal.alarm (single-alarm-per-process
    race) and SIGALRM (does not interrupt C-level regex per Python docs). Rejects input
    after 1s timeout (fail secure).
    """
    try:
        executor = _get_regex_executor()
        future = executor.submit(_run_injection_pattern_checks_impl, text, pattern_set)
        try:
            return future.result(timeout=1)
        except FuturesTimeoutError:
            raise RegexTimeoutError("Regex pattern matching exceeded timeout (1s)")
    except RegexTimeoutError:
        raise
    except Exception as e:
        logger.error(
            "Input validation timeout mechanism failed: %s. Rejecting input for security.",
            e,
            exc_info=True,
        )
        raise RegexTimeoutError("Input validation timeout mechanism failed. Input rejected for security.") from e


# Audio file signatures (magic numbers)
AUDIO_SIGNATURES = {
    b"RIFF": "WAV",  # WAV files start with RIFF
    b"\xff\xfb": "MP3",  # MP3 files
    b"\xff\xf3": "MP3",
    b"\xff\xf2": "MP3",
    b"OggS": "OGG",  # OGG files
}


def validate_audio(
    audio_bytes: bytes,
    min_size: int = 100 * 1024,  # 100KB
    max_size: int = 10 * 1024 * 1024,  # 10MB
    max_duration: int = 600,  # 600 seconds (10 minutes)
    allowed_formats: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Validate audio file input.

    Args:
        audio_bytes: Raw audio file bytes
        min_size: Minimum file size in bytes (default: 100KB)
        max_size: Maximum file size in bytes (default: 10MB)
        max_duration: Maximum audio duration in seconds (default: 600s)
        allowed_formats: List of allowed formats (default: ["WAV", "MP3", "OGG"])

    Returns:
        Dictionary with validation results:
        - format: Detected audio format
        - size: File size in bytes
        - duration: Estimated duration in seconds (if detectable)
        - sample_rate: Sample rate in Hz (if detectable)

    Raises:
        ValidationError: If audio validation fails.
    """
    if allowed_formats is None:
        allowed_formats = ["WAV", "MP3", "OGG"]

    # Check size
    size = len(audio_bytes)
    if size < min_size:
        raise ValidationError(f"Audio file too small: {size} bytes (minimum: {min_size} bytes)", field="audio_size")

    if size > max_size:
        raise ValidationError(f"Audio file too large: {size} bytes (maximum: {max_size} bytes)", field="audio_size")

    # Detect format
    detected_format = None
    for signature, fmt in AUDIO_SIGNATURES.items():
        if audio_bytes.startswith(signature):
            detected_format = fmt
            break

    if detected_format is None:
        raise ValidationError("Unknown audio format. Supported formats: WAV, MP3, OGG", field="audio_format")

    if detected_format not in allowed_formats:
        raise ValidationError(
            f"Audio format '{detected_format}' not allowed. Allowed: {', '.join(allowed_formats)}", field="audio_format"
        )

    # Try to extract metadata (for WAV files)
    duration = None
    sample_rate = None

    if detected_format == "WAV":
        try:
            with BytesIO(audio_bytes) as wav_file:
                with wave.open(wav_file, "rb") as wav:
                    frames = wav.getnframes()
                    sample_rate = wav.getframerate()
                    duration = frames / float(sample_rate) if sample_rate > 0 else None
        except (wave.Error, struct.error, EOFError):
            # If we can't parse WAV, that's okay - we'll validate duration later
            pass

    # Validate duration if we could detect it
    if duration is not None and duration > max_duration:
        raise ValidationError(
            f"Audio duration too long: {duration:.2f}s (maximum: {max_duration}s)", field="audio_duration"
        )

    return {
        "format": detected_format,
        "size": size,
        "duration": duration,
        "sample_rate": sample_rate,
    }


def validate_text(
    text: str,
    min_length: int = 1,
    max_length: int = 5000,
    check_sql_injection: bool = True,
    check_prompt_injection: bool = True,
) -> str:
    """Validate text input with length limits to prevent ReDoS attacks.

    CRITICAL: Length limit is enforced BEFORE regex patterns to prevent
    ReDoS attacks on extremely long inputs.

    Args:
        text: Text string to validate.
        min_length: Minimum text length (default: 1).
        max_length: Maximum text length (default: 5000).
        check_sql_injection: Whether to check for SQL injection (default: True).
        check_prompt_injection: Whether to check for prompt injection (default: True).

    Returns:
        Sanitized text (trimmed).

    Raises:
        ValidationError: If text validation fails.
    """
    if not isinstance(text, str):
        raise ValidationError("Text must be a string", field="text")

    # Remove null bytes and other dangerous control characters FIRST
    # Null bytes can cause issues with C-based libraries and databases
    text = text.replace("\x00", "")  # Null bytes
    text = "".join(char for char in text if ord(char) >= 32 or char in "\n\r\t")

    # Trim whitespace
    text = text.strip()

    # CRITICAL: Check length FIRST (before regex) to prevent ReDoS
    # Extremely long inputs can cause regex to hang even with timeout
    if len(text) > max_length:
        raise ValidationError(f"Text too long: {len(text)} characters (maximum: {max_length})", field="text_length")

    if len(text) < min_length:
        raise ValidationError(f"Text too short: {len(text)} characters (minimum: {min_length})", field="text_length")

    # Check for SQL injection (length already validated above)
    # _run_injection_pattern_checks is wrapped with regex_timeout to prevent ReDoS
    if check_sql_injection:
        try:
            if _run_injection_pattern_checks(text, "sql"):
                raise ValidationError("Text contains potentially malicious SQL patterns", field="text_content")
        except RegexTimeoutError:
            # If regex times out, reject the input (fail secure)
            raise ValidationError("Input validation timeout - input may be malicious", field="text_content")

    # Check for prompt injection (regex_timeout prevents ReDoS)
    if check_prompt_injection:
        try:
            if _run_injection_pattern_checks(text, "prompt"):
                raise ValidationError(
                    "Text contains potentially malicious prompt injection patterns", field="text_content"
                )
        except RegexTimeoutError:
            # If regex times out, reject the input (fail secure)
            raise ValidationError("Input validation timeout - input may be malicious", field="text_content")

    return text


def validate_parameters(
    params: Dict[str, Any],
    expected_params: Dict[str, Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Validate function parameters.

    Args:
        params: Dictionary of parameters to validate
        expected_params: Dictionary mapping parameter names to validation rules:
            {
                "param_name": {
                    "type": type or tuple of types,
                    "required": bool,
                    "min": optional minimum value,
                    "max": optional maximum value,
                    "choices": optional list of allowed values,
                }
            }

    Returns:
        Validated and sanitized parameters dictionary

    Raises:
        ValidationError: If parameter validation fails.
    """
    if not isinstance(params, dict):
        raise ValidationError("Parameters must be a dictionary", field="params")

    validated = {}

    # Check required parameters
    for param_name, rules in expected_params.items():
        if rules.get("required", False) and param_name not in params:
            raise ValidationError(f"Required parameter missing: {param_name}", field=param_name)

    # Validate each provided parameter
    for param_name, value in params.items():
        if param_name not in expected_params:
            # Unknown parameter - skip or raise error based on strictness
            continue

        rules = expected_params[param_name]
        expected_type = rules.get("type")

        # Type check
        if expected_type and not isinstance(value, expected_type):
            type_str = (
                " or ".join(t.__name__ for t in expected_type)
                if isinstance(expected_type, tuple)
                else expected_type.__name__
            )
            raise ValidationError(
                f"Parameter '{param_name}' has wrong type: expected {type_str}, got {type(value).__name__}",
                field=param_name,
            )

        # Range check (for numeric types)
        if isinstance(value, (int, float)):
            if "min" in rules and value < rules["min"]:
                raise ValidationError(
                    f"Parameter '{param_name}' below minimum: {value} < {rules['min']}", field=param_name
                )

            if "max" in rules and value > rules["max"]:
                raise ValidationError(
                    f"Parameter '{param_name}' above maximum: {value} > {rules['max']}", field=param_name
                )

        # Choices check
        if "choices" in rules and value not in rules["choices"]:
            raise ValidationError(
                f"Parameter '{param_name}' has invalid value: {value}. Allowed: {rules['choices']}", field=param_name
            )

        validated[param_name] = value

    return validated
