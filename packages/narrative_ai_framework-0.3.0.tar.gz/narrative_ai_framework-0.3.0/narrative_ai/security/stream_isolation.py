"""
Stream Isolation Security Layer.

Provides tenant and user isolation for voice streams to prevent
cross-tenant data access. This is Layer 5 of the 6-layer security architecture.
"""

import uuid
import logging
import threading
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class StreamSecurityContext:
    """
    Security context for voice streams.

    Ensures that every stream is associated with a specific tenant and user,
    preventing cross-tenant data access.

    This class is immutable (frozen) to ensure hash stability when used in sets/dicts.

    Attributes:
        tenant_id: UUID of the tenant (organization)
        user_id: UUID of the user within the tenant
        session_id: UUID of the current session
        timestamp: When the context was created
        session_ttl_seconds: Session time-to-live in seconds (default: 3600)
    """

    tenant_id: uuid.UUID
    user_id: uuid.UUID
    session_id: uuid.UUID
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    session_ttl_seconds: int = 3600  # 1 hour default TTL

    @property
    def room_name(self) -> str:
        """
        Generate room name from tenant_id and session_id.

        Returns:
            LiveKit room name derived from tenant and session IDs
        """
        return f"{self.tenant_id.hex[:8]}-{self.session_id.hex[:8]}"

    def _ensure_timezone_aware(self, dt: datetime) -> datetime:
        """
        Ensure datetime is timezone-aware (assumes UTC if naive).

        Helper method to avoid code duplication.

        Args:
            dt: Datetime object (may be naive or aware)

        Returns:
            Timezone-aware datetime (UTC)
        """
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt

    def is_expired(self) -> bool:
        """
        Check if session has expired based on TTL.

        Returns:
            True if session has expired, False otherwise
        """
        now = datetime.now(timezone.utc)
        timestamp_aware = self._ensure_timezone_aware(self.timestamp)
        age = (now - timestamp_aware).total_seconds()
        return age > self.session_ttl_seconds

    def validate(self) -> None:
        """
        Verify all required fields are present and valid.

        Raises:
            ValueError: If any required field is missing or invalid, or if session is expired.
        """
        if not isinstance(self.tenant_id, uuid.UUID):
            raise ValueError("tenant_id must be a valid UUID")

        if not isinstance(self.user_id, uuid.UUID):
            raise ValueError("user_id must be a valid UUID")

        if not isinstance(self.session_id, uuid.UUID):
            raise ValueError("session_id must be a valid UUID")

        if not isinstance(self.timestamp, datetime):
            raise ValueError("timestamp must be a datetime object")

        # Validate session_ttl_seconds is positive and reasonable
        # Max 24 hours (86400 seconds) to prevent sessions that never expire
        if not isinstance(self.session_ttl_seconds, int) or self.session_ttl_seconds <= 0:
            raise ValueError("session_ttl_seconds must be a positive integer")

        if self.session_ttl_seconds > 86400:  # 24 hours max
            raise ValueError("session_ttl_seconds cannot exceed 86400 (24 hours)")

        # Check session expiration
        if self.is_expired():
            now = datetime.now(timezone.utc)
            timestamp_aware = self._ensure_timezone_aware(self.timestamp)
            age = (now - timestamp_aware).total_seconds()
            logger.warning(
                "session_expired",
                extra={
                    "tenant_id": str(self.tenant_id),
                    "user_id": str(self.user_id),
                    "session_id": str(self.session_id),
                    "age_seconds": age,
                    "ttl_seconds": self.session_ttl_seconds,
                },
            )
            raise ValueError(
                f"Session expired (age: {age:.0f}s, TTL: {self.session_ttl_seconds}s). Please create a new session."
            )

        # Log successful validation (for audit trail)
        logger.debug(
            "session_validated",
            extra={
                "tenant_id": str(self.tenant_id),
                "user_id": str(self.user_id),
                "session_id": str(self.session_id),
            },
        )

    def check_tenant_access(self, resource_tenant_id: uuid.UUID) -> bool:
        """
        Check if this context has access to a resource from a specific tenant.

        Args:
            resource_tenant_id: The tenant ID of the resource being accessed.

        Returns:
            True if access is allowed (tenant_id matches), False otherwise.

        Raises:
            ValueError: If resource_tenant_id is not a valid UUID.
        """
        if not isinstance(resource_tenant_id, uuid.UUID):
            raise ValueError("resource_tenant_id must be a valid UUID")

        return self.tenant_id == resource_tenant_id

    def to_dict(self) -> Dict[str, Any]:
        """
        Serialize the security context to a dictionary for logging.

        Returns:
            Dictionary representation of the security context.
        """
        return {
            "tenant_id": str(self.tenant_id),
            "user_id": str(self.user_id),
            "session_id": str(self.session_id),
            "timestamp": self.timestamp.isoformat(),
            "room_name": self.room_name,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StreamSecurityContext":
        """
        Create a StreamSecurityContext from a dictionary.

        Args:
            data: Dictionary containing security context data.

        Returns:
            StreamSecurityContext instance.

        Raises:
            ValueError: If required fields are missing or invalid.
        """
        try:
            # Validate all required fields exist
            tenant_id = uuid.UUID(data["tenant_id"])
            user_id = uuid.UUID(data["user_id"])
            session_id = uuid.UUID(data["session_id"])

            # Verify format, not just parsing
            if not all([tenant_id, user_id, session_id]):
                raise ValueError("All UUIDs required")

            # Require timestamp (no default to now - prevents rewriting history)
            if "timestamp" not in data:
                raise ValueError("timestamp is required and cannot be defaulted")

            # Parse timestamp (handle both timezone-aware and naive formats)
            timestamp_str = data["timestamp"]
            try:
                timestamp = datetime.fromisoformat(timestamp_str)
                # If naive, assume UTC
                if timestamp.tzinfo is None:
                    timestamp = timestamp.replace(tzinfo=timezone.utc)
            except (ValueError, TypeError) as e:
                raise ValueError(f"Invalid timestamp format: {timestamp_str}") from e

            # room_name is now a property (computed from tenant_id/session_id)
            # Ignore room_name in data if present (it will be computed automatically)
            context = cls(
                tenant_id=tenant_id,
                user_id=user_id,
                session_id=session_id,
                timestamp=timestamp,
                session_ttl_seconds=data.get("session_ttl_seconds", 3600),
            )

            # Validate the created context
            context.validate()

            return context
        except (KeyError, ValueError, TypeError) as e:
            raise ValueError(f"Invalid security context data: {e}") from e

    def __eq__(self, other: object) -> bool:
        """Check if two security contexts are equal."""
        if not isinstance(other, StreamSecurityContext):
            return False

        return (
            self.tenant_id == other.tenant_id and self.user_id == other.user_id and self.session_id == other.session_id
        )

    def __hash__(self) -> int:
        """Make StreamSecurityContext hashable for use in sets/dicts."""
        return hash((self.tenant_id, self.user_id, self.session_id))


class StreamIsolationManager:
    """
    Manages stream isolation sessions with proactive cleanup.

    Provides session tracking and automatic cleanup of expired sessions
    to prevent memory leaks in long-running applications.
    """

    # Maximum sessions to prevent memory exhaustion under attack
    DEFAULT_MAX_SESSIONS = 100000

    def __init__(self, cleanup_interval_seconds: int = 300, max_sessions: int = 100000):
        """
        Initialize stream isolation manager.

        Args:
            cleanup_interval_seconds: How often to run cleanup (default: 5 minutes)
            max_sessions: Maximum concurrent sessions (default: 100000). Prevents memory exhaustion if orphaned sessions accumulate.
        """
        self._sessions: Dict[str, StreamSecurityContext] = {}
        self._sessions_lock = threading.Lock()
        self._cleanup_interval = cleanup_interval_seconds
        self._cleanup_thread: Optional[threading.Thread] = None
        self._cleanup_running = False
        self._cleanup_event = threading.Event()
        self._max_sessions = max_sessions

        # Start cleanup thread
        self._start_cleanup_thread()

    def _start_cleanup_thread(self) -> None:
        """Start background thread for proactive session cleanup."""
        if self._cleanup_thread is not None and self._cleanup_thread.is_alive():
            return

        self._cleanup_running = True
        self._cleanup_thread = threading.Thread(
            target=self._cleanup_expired_sessions, daemon=True, name="StreamIsolationCleanup"
        )
        self._cleanup_thread.start()
        logger.debug("Started stream isolation cleanup thread")

    def _cleanup_expired_sessions(self) -> None:
        """Background thread to proactively clean up expired sessions.

        Uses Event.wait() instead of time.sleep() so shutdown() can wake the thread
        immediately instead of waiting up to cleanup_interval_seconds.
        """
        while self._cleanup_running:
            try:
                # Wait for interval or until shutdown (Event.set wakes immediately)
                if not self._cleanup_event.wait(timeout=self._cleanup_interval):
                    # Timeout occurred (normal case) - proceed with cleanup
                    with self._sessions_lock:
                        expired_keys = []

                        for key, context in self._sessions.items():
                            if context.is_expired():
                                expired_keys.append(key)

                        for key in expired_keys:
                            del self._sessions[key]

                        if expired_keys:
                            logger.debug(f"Cleaned up {len(expired_keys)} expired stream isolation sessions")
            except Exception as e:
                logger.error(f"Error in stream isolation cleanup: {e}", exc_info=True)

    def register_session(self, context: StreamSecurityContext) -> None:
        """
        Register a new session context.

        Args:
            context: StreamSecurityContext to register

        Raises:
            ValueError: If session limit reached after cleanup attempt
        """
        context.validate()  # Ensure context is valid and not expired
        key = f"{context.tenant_id}:{context.session_id}"

        with self._sessions_lock:
            # Enforce maximum sessions to prevent memory exhaustion
            if len(self._sessions) >= self._max_sessions:
                expired_keys = [k for k, ctx in self._sessions.items() if ctx.is_expired()]
                expired_count = len(expired_keys)
                for k in expired_keys:
                    del self._sessions[k]

                if len(self._sessions) >= self._max_sessions:
                    raise ValueError(
                        f"Session limit reached ({len(self._sessions)}). "
                        f"Cleaned {expired_count} expired. Increase limit or reduce TTL."
                    )

            self._sessions[key] = context

    def get_session(self, tenant_id: uuid.UUID, session_id: uuid.UUID) -> Optional[StreamSecurityContext]:
        """
        Get a session context if it exists and is not expired.

        Args:
            tenant_id: Tenant UUID
            session_id: Session UUID

        Returns:
            StreamSecurityContext if found and valid, None otherwise
        """
        key = f"{tenant_id}:{session_id}"

        with self._sessions_lock:
            context = self._sessions.get(key)
            if context is None:
                return None

            # Check expiration on access
            if context.is_expired():
                del self._sessions[key]
                return None

            return context

    def cleanup_expired_sessions(self) -> int:
        """
        Manually trigger cleanup of expired sessions.

        Returns:
            Number of sessions cleaned up
        """
        with self._sessions_lock:
            expired_keys = [key for key, context in self._sessions.items() if context.is_expired()]

            for key in expired_keys:
                del self._sessions[key]

            return len(expired_keys)

    def get_active_sessions_count(self) -> int:
        """Get count of active (non-expired) sessions."""
        with self._sessions_lock:
            return sum(1 for context in self._sessions.values() if not context.is_expired())

    def shutdown(self) -> None:
        """Stop cleanup thread (for graceful shutdown).

        Sets _cleanup_event to wake the cleanup thread immediately,
        avoiding delay of up to cleanup_interval_seconds.
        """
        self._cleanup_running = False
        self._cleanup_event.set()  # Wake up thread immediately
        if self._cleanup_thread is not None:
            self._cleanup_thread.join(timeout=5.0)
