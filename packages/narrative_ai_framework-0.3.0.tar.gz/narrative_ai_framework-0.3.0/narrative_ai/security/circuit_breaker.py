"""
Circuit Breaker for Rate Limiting Fallback.

Implements circuit breaker pattern to detect Redis failures and
automatically switch to local fallback rate limiting.
"""

import time
import logging
from enum import Enum
from typing import Optional, Dict, Any
from dataclasses import dataclass, field
from threading import Lock

logger = logging.getLogger(__name__)


class CircuitState(str, Enum):
    """Circuit breaker states."""

    CLOSED = "closed"  # Normal operation
    OPEN = "open"  # Failing, use fallback
    HALF_OPEN = "half_open"  # Testing if service recovered


@dataclass
class CircuitBreaker:
    """
    Circuit breaker for detecting service failures.

    Switches to fallback mode when failures exceed threshold.
    """

    failure_threshold: int = 5  # Open circuit after 5 failures
    success_threshold: int = 2  # Close circuit after 2 successes
    timeout_seconds: int = 60  # Timeout before trying again
    initial_timeout: int = 60  # Store original timeout for reset
    state: CircuitState = field(default=CircuitState.CLOSED)
    failure_count: int = field(default=0)
    success_count: int = field(default=0)
    last_failure_time: Optional[float] = field(default=None)
    _test_request_in_progress: bool = field(default=False, init=False)  # Track test request in HALF_OPEN
    _lock: Lock = field(default_factory=Lock, init=False)  # Thread-safety lock

    def __post_init__(self):
        """Store initial timeout for exponential backoff reset."""
        self.initial_timeout = self.timeout_seconds

    def record_success(self) -> None:
        """Record a successful operation (thread-safe)."""
        with self._lock:
            old_state = self.state
            if self.state == CircuitState.HALF_OPEN:
                # Clear test request flag (test completed)
                self._test_request_in_progress = False
                self.success_count += 1
                if self.success_count >= self.success_threshold:
                    self.state = CircuitState.CLOSED
                    self.failure_count = 0
                    self.success_count = 0
                    # Reset timeout to initial value on successful recovery
                    self.timeout_seconds = self.initial_timeout
                    logger.info(
                        "circuit_breaker_closed",
                        extra={
                            "old_state": old_state.value,
                            "new_state": self.state.value,
                            "failure_count": self.failure_count,
                            "timeout_seconds": self.timeout_seconds,
                        },
                    )
            elif self.state == CircuitState.CLOSED:
                # Reset failure count on success
                self.failure_count = 0

    def record_failure(self) -> None:
        """Record a failed operation (thread-safe) with exponential backoff."""
        with self._lock:
            old_state = self.state
            self.last_failure_time = time.time()

            if self.state == CircuitState.CLOSED:
                self.failure_count += 1
                if self.failure_count >= self.failure_threshold:
                    self.state = CircuitState.OPEN
                    # Exponential backoff: double timeout on each failure (cap at 300s)
                    self.timeout_seconds = min(self.timeout_seconds * 2, 300)
                    logger.warning(
                        "circuit_breaker_opened",
                        extra={
                            "old_state": old_state.value,
                            "new_state": self.state.value,
                            "failure_count": self.failure_count,
                            "failure_threshold": self.failure_threshold,
                            "timeout_seconds": self.timeout_seconds,
                        },
                    )
            elif self.state == CircuitState.HALF_OPEN:
                # Failed during test, go back to open
                # Clear test request flag (test completed)
                self._test_request_in_progress = False
                self.state = CircuitState.OPEN
                self.success_count = 0
                # Exponential backoff on half-open failure
                self.timeout_seconds = min(self.timeout_seconds * 2, 300)
                logger.warning(
                    "circuit_breaker_reopened",
                    extra={
                        "old_state": old_state.value,
                        "new_state": self.state.value,
                        "timeout_seconds": self.timeout_seconds,
                    },
                )

    def is_open(self) -> bool:
        """
        Check if circuit is open (should use fallback) - thread-safe.

        Returns:
            True if circuit is open (use fallback), False otherwise (allow request)
        """
        with self._lock:
            if self.state == CircuitState.OPEN:
                # Check if timeout has passed
                if self.last_failure_time is not None:
                    elapsed = time.time() - self.last_failure_time
                    if elapsed >= self.timeout_seconds:
                        # Try half-open state (allow one test request)
                        old_state = self.state
                        self.state = CircuitState.HALF_OPEN
                        self.success_count = 0
                        self._test_request_in_progress = True  # Mark test request as in progress
                        logger.info(
                            "circuit_breaker_half_open",
                            extra={
                                "old_state": old_state.value,
                                "new_state": self.state.value,
                                "elapsed_seconds": elapsed,
                                "timeout_seconds": self.timeout_seconds,
                            },
                        )
                        return False  # Allow this one test request
                return True  # Still in OPEN state, use fallback

            elif self.state == CircuitState.HALF_OPEN:
                # HALF_OPEN state: only allow one test request at a time
                if self._test_request_in_progress:
                    # Test request already in progress, reject others
                    return True  # Use fallback
                else:
                    # No test request in progress, allow this one
                    self._test_request_in_progress = True
                    return False  # Allow this test request

            # CLOSED state: normal operation
            return False

    def get_status(self) -> Dict[str, Any]:
        """
        Get current circuit breaker status for monitoring/metrics.

        Returns:
            Dictionary with current state, failure count, and timing info
        """
        with self._lock:
            elapsed = None
            if self.last_failure_time is not None:
                elapsed = time.time() - self.last_failure_time

            return {
                "state": self.state.value,
                "failure_count": self.failure_count,
                "success_count": self.success_count,
                "failure_threshold": self.failure_threshold,
                "success_threshold": self.success_threshold,
                "timeout_seconds": self.timeout_seconds,
                "last_failure_time": self.last_failure_time,
                "seconds_since_last_failure": elapsed,
            }
