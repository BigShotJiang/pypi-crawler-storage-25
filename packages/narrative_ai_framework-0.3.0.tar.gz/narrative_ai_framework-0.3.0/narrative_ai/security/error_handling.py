"""
Error Handling Security Layer.

Provides secure error handling with sanitized error messages and
comprehensive internal logging. This is Layer 2 of the 6-layer
security architecture.
"""

import logging
import traceback
import uuid
from typing import Optional, Dict, Any, Union
from datetime import datetime, timezone


logger = logging.getLogger(__name__)


def _remove_ansi_codes(text: str) -> str:
    """
    Remove ANSI escape codes without regex (avoids ReDoS).

    Pattern \\x1b\\[[0-9;]*m can cause catastrophic backtracking with
    malicious input (e.g. many semicolons). Manual parsing is O(n) and safe.
    """
    result = []
    i = 0
    while i < len(text):
        if i + 2 <= len(text) and text[i : i + 2] == "\x1b[":
            j = i + 2
            while j < len(text) and text[j] != "m":
                j += 1
            i = j + 1 if j < len(text) else len(text)
        else:
            result.append(text[i])
            i += 1
    return "".join(result)


# Sanitization levels for different contexts
class SanitizationLevel:
    """Sanitization levels for different logging contexts."""

    STRICT = "strict"  # User-facing logs - maximum sanitization
    MODERATE = "moderate"  # Internal logs - balanced sanitization
    LENIENT = "lenient"  # Debug logs - minimal sanitization (preserve context)


def _sanitize_for_logging(
    data: Union[str, Dict, list, Any],
    seen_ids: Optional[set] = None,
    max_depth: int = 50,
    current_depth: int = 0,
    max_string_length: int = 10000,
    sanitization_level: str = SanitizationLevel.STRICT,
) -> Union[str, Dict, list, Any]:
    """
    Sanitize data for safe logging to prevent log injection.

    Removes:
    - ANSI escape codes
    - Newlines and carriage returns
    - Null bytes
    - Control characters

    Also:
    - Truncates long strings to prevent log bloat and memory issues
    - Handles custom objects by sanitizing their attributes recursively
    - Prevents infinite loops on circular references with seen_ids tracking

    Args:
        data: Data to sanitize (string, dict, list, custom object, or other)
        seen_ids: Set of object IDs already seen (prevents circular references)
        max_depth: Maximum recursion depth (default: 50)
        current_depth: Current recursion depth (internal use)
        max_string_length: Maximum string length before truncation (default: 10000)
        sanitization_level: Sanitization level (strict/moderate/lenient)
            - strict: Maximum sanitization for user-facing logs
            - moderate: Balanced sanitization for internal logs
            - lenient: Minimal sanitization for debug logs (preserves context)

    Returns:
        Sanitized data safe for logging
    """
    # Initialize seen_ids on first call
    if seen_ids is None:
        seen_ids = set()

    # Check recursion depth limit
    if current_depth >= max_depth:
        logger.warning(f"Sanitization depth limit reached ({max_depth}). Truncating recursion.", exc_info=False)
        return f"[Sanitization Depth Limit Reached - Type: {type(data).__name__}]"

    # Handle strings (immutable, no circular reference risk)
    if isinstance(data, str):
        # CRITICAL: Truncate long strings FIRST to prevent regex from processing huge inputs
        # This prevents ReDoS and memory issues in the error handler
        # Adjust truncation based on sanitization level
        effective_max_length = max_string_length
        if sanitization_level == SanitizationLevel.LENIENT:
            effective_max_length = max_string_length * 5  # Allow longer strings in debug mode

        if len(data) > effective_max_length:
            truncation_msg = f" ... [TRUNCATED - original length: {len(data)}]"
            if sanitization_level == SanitizationLevel.LENIENT:
                # In lenient mode, preserve more context
                data = data[: effective_max_length - len(truncation_msg)] + truncation_msg
            else:
                data = data[: effective_max_length - len(truncation_msg)] + truncation_msg

        # Remove ANSI escape codes (e.g., \x1b[31m)
        # Use manual parsing instead of regex to avoid ReDoS - pattern [0-9;]* can cause
        # catastrophic backtracking with input like \x1b[0;0;0;...;0m (1000+ semicolons)
        data = _remove_ansi_codes(data)

        # Remove control characters and normalize whitespace
        # In lenient mode, preserve newlines/tabs for better debugging
        if sanitization_level == SanitizationLevel.LENIENT:
            # Only remove null bytes and dangerous control chars
            data = data.replace("\x00", "")  # Null bytes
            # Preserve \n, \r, \t for readability
            data = "".join(char for char in data if ord(char) >= 32 or char in "\t\n\r")
        else:
            # Strict/moderate: full sanitization
            data = (
                data.replace("\x00", "")  # Null bytes
                .replace("\n", "\\n")  # Newlines
                .replace("\r", "\\r")  # Carriage returns
                .replace("\t", "\\t")  # Tabs
                .replace("\x1b", "")  # Escape characters
            )
            # Remove any remaining control characters (0x00-0x1F except \t, \n, \r)
            data = "".join(char for char in data if ord(char) >= 32 or char in "\t\n\r")

        return data

    # Handle mutable types (dict, list, custom objects) - check for circular references
    data_id = id(data)
    if data_id in seen_ids:
        # Circular reference detected
        return f"[Circular Reference - Type: {type(data).__name__}]"

    # Add to seen set
    seen_ids.add(data_id)

    try:
        if isinstance(data, dict):
            result = {}
            for k, v in data.items():
                safe_key = _sanitize_for_logging(
                    str(k),
                    seen_ids,
                    max_depth,
                    current_depth + 1,
                    max_string_length=200,  # Keys should be short; prevent key bloat
                    sanitization_level=sanitization_level,
                )
                safe_value = _sanitize_for_logging(
                    v,
                    seen_ids,
                    max_depth,
                    current_depth + 1,
                    max_string_length=max_string_length,
                    sanitization_level=sanitization_level,
                )
                result[safe_key] = safe_value
        elif isinstance(data, list):
            result = [
                _sanitize_for_logging(
                    v,
                    seen_ids,
                    max_depth,
                    current_depth + 1,
                    max_string_length=max_string_length,
                    sanitization_level=sanitization_level,
                )
                for v in data
            ]
        elif hasattr(data, "__dict__"):
            # Custom objects: sanitize their attributes recursively
            # This prevents PII leaks from __str__ methods
            try:
                result = _sanitize_for_logging(
                    data.__dict__,
                    seen_ids,
                    max_depth,
                    current_depth + 1,
                    max_string_length=max_string_length,
                    sanitization_level=sanitization_level,
                )
            except (AttributeError, TypeError, RecursionError) as e:
                # If __dict__ access fails, log warning and return safe placeholder
                logger.warning(
                    f"Sanitization failed for object type {type(data).__name__}: {e}",
                    exc_info=False,  # Don't log full traceback to avoid recursion
                )
                result = f"[Sanitization Failed - Object Type: {type(data).__name__}]"
        else:
            # For other types (int, float, bool, None, etc.), convert to string and sanitize
            # This handles cases where str(data) might contain sensitive info
            result = _sanitize_for_logging(
                str(data),
                seen_ids,
                max_depth,
                current_depth + 1,
                max_string_length=max_string_length,
                sanitization_level=sanitization_level,
            )

        return result
    finally:
        # Remove from seen set when done (allows same object to appear in different branches)
        seen_ids.discard(data_id)


class SecurityError(Exception):
    """Base exception for all security-related errors."""

    def __init__(self, message: str, internal_details: Optional[Dict[str, Any]] = None):
        """
        Initialize security error.

        Args:
            message: User-facing error message (sanitized)
            internal_details: Internal error details (for logging only)
        """
        super().__init__(message)
        self.message = message
        self.internal_details = internal_details or {}
        self.timestamp = datetime.now(timezone.utc)

        # Log internally with full details
        self._log_internal_error()

    def _log_internal_error(self) -> None:
        """Log full error details internally with sanitization (never exposed to user)."""
        # Generate error ID for tracking
        error_id = str(uuid.uuid4())

        # Sanitize all user input to prevent log injection
        sanitized_message = _sanitize_for_logging(self.message)
        sanitized_details = _sanitize_for_logging(self.internal_details)

        # Use structured logging with fixed message (not user input)
        logger.error(
            "security_error",  # Fixed message, not user input
            extra={
                "error_id": error_id,  # For tracking
                "error_type": self.__class__.__name__,
                "error_message": sanitized_message,
                "internal_details": sanitized_details,
                "timestamp": self.timestamp.isoformat(),
            },
            exc_info=True,
        )


class AuthenticationError(SecurityError):
    """Raised when authentication fails."""

    def __init__(
        self,
        message: str = "Authentication failed",
        internal_details: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize authentication error.

        Args:
            message: User-facing error message
            internal_details: Internal error details
        """
        super().__init__(message, internal_details)


class TenantIsolationError(SecurityError):
    """Raised when tenant isolation is violated."""

    def __init__(
        self,
        message: str = "Access denied",
        internal_details: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize tenant isolation error.

        Args:
            message: User-facing error message
            internal_details: Internal error details (includes tenant_id, user_id)
        """
        super().__init__(message, internal_details)


class AuditLogError(SecurityError):
    """
    Raised when audit logging fails.

    CRITICAL: According to SOC2 "fail closed" principle, operations that trigger
    audit logs should fail if audit logging fails. This ensures complete audit trail.
    """

    def __init__(
        self,
        message: str = "Failed to record audit log",
        internal_details: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize audit log error.

        Args:
            message: User-facing error message
            internal_details: Internal error details (includes original exception)
        """
        super().__init__(message, internal_details)


def sanitize_error_message(error: Exception) -> str:
    """
    Sanitize error message for user consumption.

    Returns generic messages with error ID for tracking.
    Never leaks error type or internal details.

    Args:
        error: Exception to sanitize

    Returns:
        Generic error message safe for user display with error ID
    """
    # Generate error ID for tracking
    error_id = str(uuid.uuid4())

    # Always return generic message - never leak error type
    # Include error ID for support tracking
    return f"An error occurred. Please contact support with error ID: {error_id}"


def log_error_internally(
    error: Exception,
    context: Optional[Dict[str, Any]] = None,
    sanitization_level: str = SanitizationLevel.MODERATE,
) -> None:
    """
    Log full error details internally with configurable sanitization (never exposed to user).

    Args:
        error: Exception to log
        context: Additional context (tenant_id, user_id, etc.)
        sanitization_level: Sanitization level (strict/moderate/lenient)
            - strict: Maximum sanitization (for user-facing logs)
            - moderate: Balanced sanitization (default for internal logs)
            - lenient: Minimal sanitization (for debug logs, preserves context)
    """
    context = context or {}
    error_id = str(uuid.uuid4())

    # Get full traceback
    tb_str = traceback.format_exc()

    # Sanitize all user input with specified level
    sanitized_context = _sanitize_for_logging(context, sanitization_level=sanitization_level)
    sanitized_message = _sanitize_for_logging(str(error), sanitization_level=sanitization_level)
    sanitized_traceback = _sanitize_for_logging(tb_str, sanitization_level=sanitization_level)

    # Log with full details (sanitized)
    logger.error(
        "internal_error",  # Fixed message
        extra={
            "error_id": error_id,
            "error_type": type(error).__name__,
            "error_message": sanitized_message,
            "traceback": sanitized_traceback,
            "context": sanitized_context,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
        exc_info=True,
    )


class SecureErrorHandler:
    """
    Handler for secure error logging in engines.
    Logs errors internally with sanitization; never exposes internal details to callers.
    """

    def handle_error(
        self,
        error: Exception,
        user_id: Optional[Any] = None,
        tenant_id: Optional[Any] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Log error internally with sanitization. Safe to call from exception handlers.
        Does not re-raise; callers should raise/suppress as appropriate.
        """
        ctx = dict(context or {})
        if user_id is not None:
            ctx["user_id"] = str(user_id)[:100]
        if tenant_id is not None:
            ctx["tenant_id"] = str(tenant_id)[:100]
        log_error_internally(error, context=ctx, sanitization_level=SanitizationLevel.MODERATE)


def handle_security_error(
    error: Exception,
    context: Optional[Dict[str, Any]] = None,
) -> SecurityError:
    """
    Handle and sanitize security-related errors.

    Args:
        error: Exception to handle
        context: Additional context

    Returns:
        Sanitized SecurityError instance
    """
    # Log internally first
    log_error_internally(error, context)

    # Convert to appropriate SecurityError
    if isinstance(error, SecurityError):
        return error

    if isinstance(error, (ValueError, TypeError)):
        return SecurityError(
            "Invalid request parameters", internal_details={"original_error": str(error), "context": context}
        )

    if isinstance(error, KeyError):
        return SecurityError(
            "Required parameter missing", internal_details={"original_error": str(error), "context": context}
        )

    # Generic security error
    return SecurityError(
        sanitize_error_message(error), internal_details={"original_error": str(error), "context": context}
    )
