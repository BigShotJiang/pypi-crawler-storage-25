"""
Audit Trail Security Layer.

Provides immutable logging of all user actions for compliance and
security monitoring. This is Layer 6 of the 6-layer security architecture.
"""

import uuid
import os
import re
import logging
import ipaddress
import queue
import threading
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List, Callable
from enum import Enum
from dataclasses import dataclass
import json

from sqlalchemy import create_engine, Column, String, DateTime, JSON, Text, UUID, text  # type: ignore
from sqlalchemy.orm import sessionmaker, Session, declarative_base  # type: ignore
from sqlalchemy.pool import QueuePool  # type: ignore
from cryptography.fernet import Fernet  # type: ignore

from narrative_ai.security.error_handling import TenantIsolationError, AuditLogError

logger = logging.getLogger(__name__)

Base = declarative_base()


class ActionType(str, Enum):
    """Types of actions that can be logged."""

    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    SEARCH = "search"
    TRANSCRIBE = "transcribe"  # Speech-to-text transcription (STT)
    CHAT = "chat"
    EXPORT = "export"
    LOGIN = "login"
    LOGOUT = "logout"
    AUTH_FAILED = "auth_failed"
    RATE_LIMIT_EXCEEDED = "rate_limit_exceeded"
    SECURITY_VIOLATION = "security_violation"
    VOICE_INTERACTION = "voice_interaction"  # Real-time voice turn (user said X, agent said Y)
    RAG_RECALL = "rag_recall"
    RAG_REMEMBER = "rag_remember"
    DOCUMENT_INGEST = "document_ingest"
    OCR_PROCESS = "ocr_process"
    VLM_INFERENCE = "vlm_inference"


class ActionStatus(str, Enum):
    """Status of the action."""

    SUCCESS = "success"
    FAILURE = "failure"
    BLOCKED = "blocked"


@dataclass
class AuditLogEntry:
    """
    Immutable audit log entry.

    Attributes:
        tenant_id: UUID of the tenant
        user_id: UUID of the user
        action: Type of action performed
        resource_type: Type of resource (e.g., "entry", "conversation")
        resource_id: UUID of the resource (if applicable)
        timestamp: When the action occurred
        status: Success, failure, or blocked
        details: Additional details as JSON
        ip_address: IP address of the request (optional)
        user_agent: User agent string (optional)
    """

    tenant_id: uuid.UUID
    user_id: uuid.UUID
    action: ActionType
    resource_type: str
    resource_id: Optional[uuid.UUID] = None
    timestamp: datetime = None
    status: ActionStatus = ActionStatus.SUCCESS
    details: Dict[str, Any] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None

    def __post_init__(self):
        """Set default timestamp if not provided."""
        if self.timestamp is None:
            self.timestamp = datetime.now(timezone.utc)
        if self.details is None:
            self.details = {}


class AuditLog(Base):
    """SQLAlchemy model for audit logs table."""

    __tablename__ = "audit_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    user_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    action = Column(String(50), nullable=False, index=True)
    resource_type = Column(String(100), nullable=False)
    resource_id = Column(UUID(as_uuid=True), nullable=True, index=True)
    timestamp = Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc), index=True)
    status = Column(String(20), nullable=False, index=True)
    details = Column(JSON, nullable=False, default=dict)  # May contain encrypted JSON string if encryption enabled
    ip_address = Column(String(45), nullable=True)  # IPv6 max length
    user_agent = Column(Text, nullable=True)

    # Prevent updates and deletes (immutable)
    __table_args__ = (
        # Add constraint to prevent updates (application-level enforcement)
        # PostgreSQL doesn't support preventing updates at DB level easily
    )


class AuditLogger:
    """
    Immutable audit logger for tracking all user actions.

    All logs are append-only and cannot be modified or deleted.

    CRITICAL SECURITY NOTES:
    1. Database triggers MUST be applied (see database_migrations/audit_immutability.sql)
    2. Audit logging is SYNCHRONOUS by design (SOC2 "fail closed" principle)
    3. Operations that trigger audit logs should fail if audit logging fails
    4. Encryption is optional - use for sensitive details if needed
    """

    # Maximum lengths for sanitized fields
    MAX_USER_AGENT_LENGTH = 500
    MAX_IP_ADDRESS_LENGTH = 45  # IPv6 max

    @staticmethod
    def _validate_ip_address(ip: Optional[str]) -> Optional[str]:
        """
        Validate and normalize IP address.

        Args:
            ip: IP address string to validate

        Returns:
            Validated IP address or None if invalid
        """
        if not ip:
            return None

        try:
            # Try to parse as IPv4 or IPv6
            ip_obj = ipaddress.ip_address(ip.strip())
            return str(ip_obj)
        except ValueError:
            # Check for IPv4 with port (e.g., "192.168.1.1:8080")
            if ":" in ip and not ip.startswith("["):
                ip_part = ip.rsplit(":", 1)[0]
                try:
                    ip_obj = ipaddress.ip_address(ip_part.strip())
                    return str(ip_obj)
                except ValueError:
                    pass

            # Invalid IP address
            logger.warning(
                "Invalid IP address in audit log",
                extra={"ip_value": ip[:20] if ip else None},  # Truncate for safety
            )
            return None

    @staticmethod
    def _sanitize_user_agent(user_agent: Optional[str]) -> Optional[str]:
        """
        Sanitize user agent string to prevent log injection.

        Args:
            user_agent: Raw user agent string

        Returns:
            Sanitized user agent string
        """
        if not user_agent:
            return None

        # Remove control characters (potential log injection)
        sanitized = re.sub(r"[\x00-\x1f\x7f-\x9f]", "", user_agent)

        # Remove any HTML/script tags
        sanitized = re.sub(r"<[^>]*>", "", sanitized)

        # Truncate to maximum length
        if len(sanitized) > AuditLogger.MAX_USER_AGENT_LENGTH:
            sanitized = sanitized[: AuditLogger.MAX_USER_AGENT_LENGTH] + "..."

        return sanitized if sanitized else None

    def __init__(
        self,
        database_url: str,
        create_tables: bool = False,
        encrypt_details: bool = False,
        encryption_key: Optional[str] = None,
    ):
        """
        Initialize audit logger with connection pooling.

        Args:
            database_url: PostgreSQL database URL
            create_tables: Whether to create tables if they don't exist
            encrypt_details: Whether to encrypt the 'details' JSON field (default: False)
            encryption_key: Fernet encryption key (if None, reads from AUDIT_ENCRYPTION_KEY env var)

        Raises:
            ValueError: If encrypt_details=True but no encryption key provided

        Note:
            **Encryption Key Rotation**: To rotate encryption keys:
            1. Generate new key: python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
            2. Set AUDIT_ENCRYPTION_KEY_NEW env var with new key
            3. Re-encrypt existing records (use migration script)
            4. Update AUDIT_ENCRYPTION_KEY to new key
            5. Remove AUDIT_ENCRYPTION_KEY_NEW

            For production, use a key management service (AWS KMS, HashiCorp Vault)
            that supports automatic key rotation.
        """
        # Configure connection pool for production
        self.engine = create_engine(
            database_url,
            poolclass=QueuePool,
            pool_size=20,  # Minimum connections
            max_overflow=40,  # Additional connections under load
            pool_pre_ping=True,  # Verify connections before use
            pool_recycle=3600,  # Recycle connections after 1 hour
            echo=False,  # Don't echo SQL queries
        )
        self.SessionLocal = sessionmaker(bind=self.engine)

        # Encryption setup (optional)
        self.encrypt_details = encrypt_details
        if encrypt_details:
            key = encryption_key or os.getenv("AUDIT_ENCRYPTION_KEY")
            if not key:
                raise ValueError(
                    "encrypt_details=True requires encryption_key parameter or AUDIT_ENCRYPTION_KEY env var"
                )
            try:
                self.cipher = Fernet(key.encode() if isinstance(key, str) else key)
            except Exception as e:
                raise ValueError(f"Invalid encryption key: {e}") from e
        else:
            self.cipher = None

        if create_tables:
            Base.metadata.create_all(self.engine)

        # Lock for thread-safe async queue initialization (prevents race in log_action_async)
        self._async_init_lock = threading.Lock()

        # Warn if immutability triggers might not be applied
        self._warn_if_triggers_missing()

    def _warn_if_triggers_missing(self) -> None:
        """
        Check if immutability triggers are applied.

        PRODUCTION BEHAVIOR (SOC2 COMPLIANT):
        - In production (ENV=production or AUDIT_REQUIRE_TRIGGERS=true), FAILS HARD if triggers missing
        - In development, logs warning but allows initialization

        This ensures SOC2 compliance: audit logs MUST be immutable in production.
        """
        # Check environment - production requires triggers
        is_production = os.getenv("ENV", "").lower() == "production"
        require_triggers = os.getenv("AUDIT_REQUIRE_TRIGGERS", "").lower() == "true"
        enforce_immutability = is_production or require_triggers

        try:
            session: Session = self.SessionLocal()
            try:
                # Check if trigger exists
                result = session.execute(
                    text("""
                    SELECT COUNT(*) FROM pg_trigger 
                    WHERE tgname = 'audit_immutability_trigger'
                """)
                )
                count = result.scalar()

                if count == 0:
                    error_msg = (
                        "CRITICAL: Audit immutability triggers not found. "
                        "Run database_migrations/audit_immutability.sql before production. "
                        "Set AUDIT_REQUIRE_TRIGGERS=false to disable this check in development."
                    )

                    if enforce_immutability:
                        # PRODUCTION: Fail hard - SOC2 requires immutable audit logs
                        logger.critical(
                            "audit_immutability_enforcement_failed",
                            extra={
                                "message": error_msg,
                                "env": os.getenv("ENV", "unset"),
                                "enforce_immutability": enforce_immutability,
                            },
                        )
                        raise RuntimeError(f"SOC2 COMPLIANCE FAILURE: {error_msg}")
                    else:
                        # DEVELOPMENT: Warn but allow
                        logger.warning(
                            "audit_immutability_triggers_missing",
                            extra={
                                "message": error_msg,
                                "migration_file": "database_migrations/audit_immutability.sql",
                            },
                        )
                else:
                    logger.info("Audit immutability triggers verified")
            finally:
                session.close()
        except RuntimeError:
            # Re-raise our own RuntimeError
            raise
        except Exception as e:
            # Don't fail initialization if check fails (e.g., table doesn't exist yet)
            # But DO warn in production
            if enforce_immutability:
                logger.warning(f"Could not verify audit triggers (this may be OK during initial setup): {e}")
            else:
                logger.debug(f"Could not verify triggers (this is OK if tables don't exist yet): {e}")

    def _encrypt_details(self, details: Dict[str, Any]) -> Dict[str, Any]:
        """
        Encrypt details JSON if encryption is enabled.

        Returns:
            If encryption enabled: {"is_encrypted": True, "data": "<encrypted_string>"}
            If encryption disabled: details dict as-is
        """
        if not self.encrypt_details or not self.cipher:
            return details

        json_str = json.dumps(details)
        encrypted = self.cipher.encrypt(json_str.encode())
        encrypted_str = encrypted.decode("utf-8")

        # Store encrypted data with version flag for consistency
        return {"is_encrypted": True, "data": encrypted_str}

    def _decrypt_details(self, details: Any) -> Dict[str, Any]:
        """
        Decrypt details JSON if encryption is enabled.

        Handles multiple formats for backward compatibility:
        - New format: {"is_encrypted": True, "data": "<encrypted_string>"}
        - Old format: {"encrypted": "<encrypted_string>"}
        - Old format: string (encrypted)
        - Plain dict: unencrypted

        Args:
            details: Either a dict (possibly with encryption flags) or a string

        Returns:
            Decrypted details dict
        """
        # If details is a string (old format)
        if isinstance(details, str):
            if not self.encrypt_details or not self.cipher:
                # Not encrypted, try to parse as JSON
                try:
                    return json.loads(details)
                except (json.JSONDecodeError, TypeError):
                    return {"raw": details}

            # String might be encrypted (old format)
            try:
                decrypted = self.cipher.decrypt(details.encode())
                return json.loads(decrypted.decode("utf-8"))
            except Exception:
                # Not encrypted, try parsing as JSON
                try:
                    return json.loads(details)
                except (json.JSONDecodeError, TypeError):
                    return {"raw": details}

        # If details is a dict
        if isinstance(details, dict):
            # Check new format first: {"is_encrypted": True, "data": "..."}
            if details.get("is_encrypted") is True and self.encrypt_details and self.cipher:
                try:
                    encrypted_str = details.get("data", "")
                    decrypted = self.cipher.decrypt(encrypted_str.encode())
                    return json.loads(decrypted.decode("utf-8"))
                except Exception as e:
                    # Don't log full exception to avoid leaking key-related info
                    logger.warning(
                        "Failed to decrypt audit details (new format)", extra={"error_type": type(e).__name__}
                    )
                    return {"decryption_error": "Decryption failed"}

            # Check old format: {"encrypted": "..."} (backward compatibility)
            if "encrypted" in details and self.encrypt_details and self.cipher:
                try:
                    encrypted_str = details["encrypted"]
                    decrypted = self.cipher.decrypt(encrypted_str.encode())
                    return json.loads(decrypted.decode("utf-8"))
                except Exception as e:
                    # Don't log full exception to avoid leaking key-related info
                    logger.warning(
                        "Failed to decrypt audit details (old format)", extra={"error_type": type(e).__name__}
                    )
                    return {"decryption_error": "Decryption failed"}

            # Not encrypted, return as-is
            return details

        # Fallback: return as dict
        return {"raw": str(details)}

    def log_action(
        self,
        tenant_id: uuid.UUID,
        user_id: uuid.UUID,
        action: ActionType,
        resource_type: str,
        resource_id: Optional[uuid.UUID] = None,
        status: ActionStatus = ActionStatus.SUCCESS,
        details: Optional[Dict[str, Any]] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> uuid.UUID:
        """
        Log an action to the audit trail.

        CRITICAL: This is SYNCHRONOUS by design (SOC2 "fail closed" principle).
        If audit logging fails, the operation that triggered it should also fail.
        This ensures complete audit trail - "if it's not logged, it didn't happen."

        For high-performance scenarios where audit logging latency is acceptable,
        use log_action_async() which uses a background queue.

        Args:
            tenant_id: Tenant UUID
            user_id: User UUID
            action: Type of action
            resource_type: Type of resource
            resource_id: Resource UUID (if applicable)
            status: Action status
            details: Additional details (will be encrypted if encrypt_details=True)
            ip_address: IP address (optional)
            user_agent: User agent (optional)

        Returns:
            UUID of the created audit log entry

        Raises:
            AuditLogError: If audit logging fails (caller should fail the operation)
        """
        session: Session = self.SessionLocal()

        try:
            # Encrypt details if encryption is enabled
            details_json = details or {}
            details_storage = self._encrypt_details(details_json)  # Returns dict (encrypted or plain)

            # Validate and sanitize inputs
            validated_ip = self._validate_ip_address(ip_address)
            sanitized_user_agent = self._sanitize_user_agent(user_agent)

            log_entry = AuditLog(
                tenant_id=tenant_id,
                user_id=user_id,
                action=action.value,
                resource_type=resource_type,
                resource_id=resource_id,
                timestamp=datetime.now(timezone.utc),
                status=status.value,
                details=details_storage,  # Always a dict (may contain "encrypted" key)
                ip_address=validated_ip,
                user_agent=sanitized_user_agent,
            )

            session.add(log_entry)
            session.commit()

            return log_entry.id

        except Exception as e:
            session.rollback()
            # CRITICAL: Raise AuditLogError - caller should fail the operation
            # This enforces "fail closed" principle for audit logs
            raise AuditLogError(
                "Failed to record audit log. Operation cannot proceed without audit trail.",
                internal_details={
                    "tenant_id": str(tenant_id),
                    "user_id": str(user_id),
                    "action": action.value,
                    "resource_type": resource_type,
                    "original_error": str(e),
                    "error_type": type(e).__name__,
                },
            ) from e
        finally:
            session.close()

    def log_action_async(
        self,
        tenant_id: uuid.UUID,
        user_id: uuid.UUID,
        action: ActionType,
        resource_type: str,
        resource_id: Optional[uuid.UUID] = None,
        status: ActionStatus = ActionStatus.SUCCESS,
        details: Optional[Dict[str, Any]] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        """
        Log an action asynchronously using background queue (non-blocking).

        **WARNING**: This method does NOT enforce "fail closed" principle.
        If audit logging fails, the operation continues. Use only for non-critical
        audit logs where performance is more important than guaranteed logging.

        For SOC2 compliance, use synchronous log_action() instead.

        Args:
            tenant_id: Tenant UUID
            user_id: User UUID
            action: Type of action
            resource_type: Type of resource
            resource_id: Resource UUID (if applicable)
            status: Action status
            details: Additional details (will be encrypted if encrypt_details=True)
            ip_address: IP address (optional)
            user_agent: User agent (optional)

        Note:
            This method queues the log entry for background processing.
            Actual logging happens asynchronously and failures are logged but don't
            affect the calling operation.
        """
        # Initialize background queue if not exists (thread-safe, prevents duplicate threads)
        with self._async_init_lock:
            if not hasattr(self, "_async_log_queue"):
                self._async_log_queue: queue.Queue = queue.Queue(maxsize=1000)
                self._async_log_thread = threading.Thread(
                    target=self._process_async_logs, daemon=True, name="AuditLogAsyncProcessor"
                )
                self._async_log_thread.start()
                logger.info("Started async audit log processor thread")

        # Queue the log entry
        try:
            log_data = {
                "tenant_id": tenant_id,
                "user_id": user_id,
                "action": action,
                "resource_type": resource_type,
                "resource_id": resource_id,
                "status": status,
                "details": details,
                "ip_address": ip_address,
                "user_agent": user_agent,
            }
            self._async_log_queue.put(log_data, timeout=5.0)
        except queue.Full:
            # Queue full (immediate or after 5s timeout) - fall back to synchronous logging
            logger.warning("Async audit log queue full, falling back to synchronous logging")
            try:
                self.log_action(
                    tenant_id, user_id, action, resource_type, resource_id, status, details, ip_address, user_agent
                )
            except Exception as e:
                logger.error(f"Failed to log audit entry (sync fallback): {e}", exc_info=True)

    def _process_async_logs(self) -> None:
        """Background thread to process async audit logs."""
        while True:
            try:
                log_data = self._async_log_queue.get(timeout=1.0)
                try:
                    self.log_action(
                        log_data["tenant_id"],
                        log_data["user_id"],
                        log_data["action"],
                        log_data["resource_type"],
                        log_data.get("resource_id"),
                        log_data.get("status", ActionStatus.SUCCESS),
                        log_data.get("details"),
                        log_data.get("ip_address"),
                        log_data.get("user_agent"),
                    )
                except Exception as e:
                    logger.error(f"Failed to process async audit log: {e}", exc_info=True)
                finally:
                    self._async_log_queue.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Error in async audit log processor: {e}", exc_info=True)

    def get_user_actions(
        self,
        requesting_tenant_id: uuid.UUID,
        requesting_user_id: uuid.UUID,
        target_tenant_id: uuid.UUID,
        target_user_id: uuid.UUID,
        limit: int = 100,
        offset: int = 0,
        action_type: Optional[ActionType] = None,
        is_admin: bool = False,
    ) -> List[Dict[str, Any]]:
        """
        Get audit logs for a specific user with tenant verification.

        CRITICAL SECURITY:
        1. Verifies that requesting tenant matches target tenant
        2. Users can only view their OWN logs unless they are admin

        Args:
            requesting_tenant_id: Tenant ID of the user making the request
            requesting_user_id: User ID making the request
            target_tenant_id: Tenant ID of the user whose logs to retrieve
            target_user_id: User ID whose logs to retrieve
            limit: Maximum number of logs to return (max 1000, default: 100)
            offset: Number of logs to skip for pagination (default: 0)
            action_type: Optional filter by action type
            is_admin: Whether requesting user has admin privileges

        Returns:
            List of audit log entries as dictionaries

        Raises:
            TenantIsolationError: If requesting tenant != target tenant
            PermissionError: If user tries to access another user's logs without admin
        """
        # CRITICAL: Verify requesting tenant == target tenant
        if requesting_tenant_id != target_tenant_id:
            raise TenantIsolationError(
                "Cannot access audit logs from different tenant",
                internal_details={
                    "requesting_tenant_id": str(requesting_tenant_id),
                    "target_tenant_id": str(target_tenant_id),
                    "requesting_user_id": str(requesting_user_id),
                },
            )

        # CRITICAL: Users can only view their own logs unless admin
        if requesting_user_id != target_user_id and not is_admin:
            logger.warning(
                "Unauthorized attempt to access other user's audit logs",
                extra={
                    "requesting_user_id": str(requesting_user_id),
                    "target_user_id": str(target_user_id),
                    "tenant_id": str(requesting_tenant_id),
                },
            )
            raise PermissionError("Cannot access another user's audit logs without admin privileges")

        # Enforce maximum limit and validate offset
        limit = min(limit, 1000)
        offset = max(0, offset)  # Prevent negative offset

        session: Session = self.SessionLocal()

        try:
            # Use verified tenant_id (requesting_tenant_id == target_tenant_id)
            query = session.query(AuditLog).filter(
                AuditLog.tenant_id == requesting_tenant_id,  # Verified
                AuditLog.user_id == target_user_id,
            )

            if action_type:
                query = query.filter(AuditLog.action == action_type.value)

            logs = query.order_by(AuditLog.timestamp.desc()).offset(offset).limit(limit).all()

            result = []
            for log in logs:
                # Decrypt details if encryption is enabled (handles both dict and string)
                details = self._decrypt_details(log.details)

                result.append(
                    {
                        "id": str(log.id),
                        "tenant_id": str(log.tenant_id),
                        "user_id": str(log.user_id),
                        "action": log.action,
                        "resource_type": log.resource_type,
                        "resource_id": str(log.resource_id) if log.resource_id else None,
                        "timestamp": log.timestamp.isoformat(),
                        "status": log.status,
                        "details": details,
                        "ip_address": log.ip_address,
                        "user_agent": log.user_agent,
                    }
                )

            return result
        finally:
            session.close()

    def get_tenant_actions(
        self,
        requesting_tenant_id: uuid.UUID,
        requesting_user_id: uuid.UUID,
        target_tenant_id: uuid.UUID,
        limit: int = 1000,
        offset: int = 0,
        action_type: Optional[ActionType] = None,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        is_admin: bool = False,
        admin_check_callback: Optional[Callable[[uuid.UUID, uuid.UUID], bool]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get audit logs for a tenant (admin function) with tenant and role verification.

        CRITICAL SECURITY:
        1. Verifies that requesting tenant matches target tenant
        2. Requires admin privileges (is_admin=True or admin_check_callback)

        Args:
            requesting_tenant_id: Tenant ID of the admin making the request
            requesting_user_id: User ID of the admin making the request
            target_tenant_id: Tenant ID whose logs to retrieve
            limit: Maximum number of logs to return (max 1000, default: 1000)
            offset: Number of logs to skip for pagination (default: 0)
            action_type: Optional filter by action type
            start_time: Optional start time filter
            end_time: Optional end time filter
            is_admin: Whether the requesting user has admin privileges
            admin_check_callback: Optional callback to verify admin status
                                  (signature: callback(tenant_id, user_id) -> bool)

        Returns:
            List of audit log entries as dictionaries

        Raises:
            TenantIsolationError: If requesting tenant != target tenant
            PermissionError: If user is not an admin
        """
        # CRITICAL: Verify requesting tenant == target tenant
        if requesting_tenant_id != target_tenant_id:
            raise TenantIsolationError(
                "Cannot access audit logs from different tenant",
                internal_details={
                    "requesting_tenant_id": str(requesting_tenant_id),
                    "target_tenant_id": str(target_tenant_id),
                    "requesting_user_id": str(requesting_user_id),
                },
            )

        # CRITICAL: Verify admin privileges
        user_is_admin = is_admin
        if admin_check_callback and not user_is_admin:
            try:
                user_is_admin = admin_check_callback(requesting_tenant_id, requesting_user_id)
            except Exception as e:
                logger.warning(
                    "Admin check callback failed",
                    extra={
                        "tenant_id": str(requesting_tenant_id),
                        "user_id": str(requesting_user_id),
                        "error": str(e),
                    },
                )
                user_is_admin = False

        if not user_is_admin:
            logger.warning(
                "Unauthorized attempt to access tenant audit logs",
                extra={
                    "tenant_id": str(requesting_tenant_id),
                    "user_id": str(requesting_user_id),
                },
            )
            raise PermissionError("Admin privileges required to access tenant-wide audit logs")

        # Enforce maximum limit and validate offset
        limit = min(limit, 1000)
        offset = max(0, offset)  # Prevent negative offset

        session: Session = self.SessionLocal()

        try:
            # Use verified tenant_id (requesting_tenant_id == target_tenant_id)
            query = session.query(AuditLog).filter(
                AuditLog.tenant_id == requesting_tenant_id,  # Verified
            )

            if action_type:
                query = query.filter(AuditLog.action == action_type.value)

            if start_time:
                query = query.filter(AuditLog.timestamp >= start_time)

            if end_time:
                query = query.filter(AuditLog.timestamp <= end_time)

            logs = query.order_by(AuditLog.timestamp.desc()).offset(offset).limit(limit).all()

            result = []
            for log in logs:
                # Decrypt details if encryption is enabled (handles both dict and string)
                details = self._decrypt_details(log.details)

                result.append(
                    {
                        "id": str(log.id),
                        "tenant_id": str(log.tenant_id),
                        "user_id": str(log.user_id),
                        "action": log.action,
                        "resource_type": log.resource_type,
                        "resource_id": str(log.resource_id) if log.resource_id else None,
                        "timestamp": log.timestamp.isoformat(),
                        "status": log.status,
                        "details": details,
                        "ip_address": log.ip_address,
                        "user_agent": log.user_agent,
                    }
                )

            return result
        finally:
            session.close()
