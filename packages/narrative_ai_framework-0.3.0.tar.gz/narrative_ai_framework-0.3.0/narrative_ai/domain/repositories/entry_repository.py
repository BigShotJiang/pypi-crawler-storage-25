"""Abstract diary-entry repository interface."""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Optional

from narrative_ai.domain.entities.diary_entry import DiaryEntry


class EntryRepository(ABC):
    """Port for persisting and retrieving diary entries."""

    @abstractmethod
    async def create(self, entry: DiaryEntry) -> DiaryEntry: ...

    @abstractmethod
    async def get_by_id(
        self,
        entry_id: uuid.UUID,
        *,
        user_id: uuid.UUID,
        include_deleted: bool = False,
    ) -> Optional[DiaryEntry]: ...

    @abstractmethod
    async def update(self, entry: DiaryEntry) -> DiaryEntry: ...

    @abstractmethod
    async def soft_delete(self, entry_id: uuid.UUID, *, user_id: uuid.UUID) -> None: ...

    @abstractmethod
    async def list_entries(
        self,
        *,
        user_id: uuid.UUID,
        offset: int = 0,
        limit: int = 20,
        emotion: Optional[str] = None,
        tag: Optional[str] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        include_deleted: bool = False,
    ) -> List[DiaryEntry]: ...

    @abstractmethod
    async def count(
        self,
        *,
        user_id: uuid.UUID,
        emotion: Optional[str] = None,
        tag: Optional[str] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        include_deleted: bool = False,
    ) -> int: ...
