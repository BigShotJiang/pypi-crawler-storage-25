"""Domain repository interfaces (ports).

These are abstract contracts; concrete implementations live in
``framework.infrastructure.database.repositories``.
"""

from .user_repository import UserRepository
from .entry_repository import EntryRepository
from .conversation_repository import ConversationRepository
from .audio_repository import AudioRepository
from .search_repository import SearchRepository, SearchResult

__all__ = [
    "UserRepository",
    "EntryRepository",
    "ConversationRepository",
    "AudioRepository",
    "SearchRepository",
    "SearchResult",
]
