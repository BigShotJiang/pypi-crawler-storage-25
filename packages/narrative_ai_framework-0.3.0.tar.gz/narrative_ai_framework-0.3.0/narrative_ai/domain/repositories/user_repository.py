"""Abstract user repository interface."""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from typing import List, Optional

from narrative_ai.domain.entities.user import User


class UserRepository(ABC):
    """Port for persisting and retrieving users.

    Concrete implementations live in the infrastructure layer
    (e.g. ``infrastructure.database.repositories.user_repository_impl``).
    """

    @abstractmethod
    async def create(self, user: User) -> User:
        """Insert a new user.  Returns the user with server-set fields populated."""
        ...

    @abstractmethod
    async def get_by_id(self, user_id: uuid.UUID) -> Optional[User]: ...

    @abstractmethod
    async def get_by_email(self, email: str) -> Optional[User]: ...

    @abstractmethod
    async def update(self, user: User) -> User: ...

    @abstractmethod
    async def delete(self, user_id: uuid.UUID) -> None:
        """Hard delete -- use with caution."""
        ...

    @abstractmethod
    async def list_users(
        self,
        *,
        offset: int = 0,
        limit: int = 50,
        active_only: bool = True,
    ) -> List[User]: ...
