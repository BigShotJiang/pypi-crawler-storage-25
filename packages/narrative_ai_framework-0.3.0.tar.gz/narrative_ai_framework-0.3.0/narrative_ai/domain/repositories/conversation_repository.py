"""Abstract conversation repository interface."""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from typing import List, Optional

from narrative_ai.domain.entities.conversation import Conversation, ConversationMessage


class ConversationRepository(ABC):
    """Port for persisting and retrieving conversations."""

    @abstractmethod
    async def create(self, conversation: Conversation) -> Conversation: ...

    @abstractmethod
    async def get_by_id(
        self,
        conversation_id: uuid.UUID,
        *,
        user_id: uuid.UUID,
    ) -> Optional[Conversation]: ...

    @abstractmethod
    async def add_message(self, message: ConversationMessage) -> ConversationMessage: ...

    @abstractmethod
    async def list_conversations(
        self,
        *,
        user_id: uuid.UUID,
        offset: int = 0,
        limit: int = 20,
    ) -> List[Conversation]:
        """Return conversations (without full message lists for performance)."""
        ...

    @abstractmethod
    async def delete(
        self,
        conversation_id: uuid.UUID,
        *,
        user_id: uuid.UUID,
    ) -> None: ...
