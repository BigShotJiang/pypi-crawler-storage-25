"""Abstract audio-file metadata repository interface."""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from typing import List, Optional

from narrative_ai.domain.entities.audio_file import AudioFile


class AudioRepository(ABC):
    """Port for persisting and retrieving audio file metadata."""

    @abstractmethod
    async def create(self, audio: AudioFile) -> AudioFile: ...

    @abstractmethod
    async def get_by_id(
        self,
        audio_id: uuid.UUID,
        *,
        user_id: uuid.UUID,
    ) -> Optional[AudioFile]: ...

    @abstractmethod
    async def list_by_user(
        self,
        *,
        user_id: uuid.UUID,
        file_type: Optional[str] = None,
        offset: int = 0,
        limit: int = 50,
    ) -> List[AudioFile]: ...

    @abstractmethod
    async def delete_expired(self) -> int:
        """Remove metadata rows whose ``expires_at`` has passed.  Returns count."""
        ...
