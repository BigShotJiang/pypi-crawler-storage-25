"""Abstract search / embedding repository interface."""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class SearchResult:
    """A single search hit with similarity score."""

    entry_id: uuid.UUID = field(default_factory=uuid.uuid4)
    similarity_score: float = 0.0
    enhanced_text: str = ""
    emotion: str = "neutral"
    created_at: Optional[str] = None


class SearchRepository(ABC):
    """Port for storing embeddings and running semantic search.

    Backed by pgvector (HNSW) in the production implementation.
    """

    @abstractmethod
    async def store_embedding(
        self,
        entry_id: uuid.UUID,
        user_id: uuid.UUID,
        embedding: List[float],
    ) -> None: ...

    @abstractmethod
    async def search(
        self,
        query_embedding: List[float],
        *,
        user_id: uuid.UUID,
        top_k: int = 5,
        min_similarity: float = 0.0,
    ) -> List[SearchResult]: ...

    @abstractmethod
    async def delete_embedding(self, entry_id: uuid.UUID) -> None: ...
