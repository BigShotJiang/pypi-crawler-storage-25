"""Entry-related domain events."""

from __future__ import annotations

import uuid

from .domain_event import DomainEvent


class EntryCreated(DomainEvent):
    """Emitted when a diary entry is created."""

    def __init__(
        self,
        entry_id: uuid.UUID,
        user_id: uuid.UUID,
        source_type: str = "text",
        *,
        correlation_id: str | None = None,
        metadata: dict | None = None,
    ) -> None:
        super().__init__(correlation_id=correlation_id, metadata=metadata or {})
        self.entry_id = entry_id
        self.user_id = user_id
        self.source_type = source_type


class EntryUpdated(DomainEvent):
    """Emitted when a diary entry is updated."""

    def __init__(
        self,
        entry_id: uuid.UUID,
        user_id: uuid.UUID,
        *,
        correlation_id: str | None = None,
        metadata: dict | None = None,
    ) -> None:
        super().__init__(correlation_id=correlation_id, metadata=metadata or {})
        self.entry_id = entry_id
        self.user_id = user_id


class EntryDeleted(DomainEvent):
    """Emitted when a diary entry is soft-deleted."""

    def __init__(
        self,
        entry_id: uuid.UUID,
        user_id: uuid.UUID,
        *,
        correlation_id: str | None = None,
        metadata: dict | None = None,
    ) -> None:
        super().__init__(correlation_id=correlation_id, metadata=metadata or {})
        self.entry_id = entry_id
        self.user_id = user_id
