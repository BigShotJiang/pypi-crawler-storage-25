"""In-process domain event bus.

Publishes domain events to registered handlers.
Handlers can be sync or async; async handlers are awaited.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import Any, Callable, Coroutine

from .domain_event import DomainEvent

logger = logging.getLogger(__name__)

Handler = Callable[[DomainEvent], Any | Coroutine[Any, Any, Any]]


class EventBus:
    """Simple in-process event bus for domain events."""

    def __init__(self) -> None:
        self._handlers: dict[type[DomainEvent], list[Handler]] = defaultdict(list)

    def subscribe(self, event_type: type[DomainEvent], handler: Handler) -> None:
        """Register a handler for the given event type."""
        self._handlers[event_type].append(handler)

    async def publish(self, event: DomainEvent) -> None:
        """Publish an event to all subscribed handlers.

        Handlers are called in registration order.
        Exceptions in handlers are logged but do not stop other handlers.
        """
        handlers = self._handlers.get(type(event), [])
        for h in handlers:
            try:
                result = h(event)
                if hasattr(result, "__await__"):
                    await result
            except Exception as exc:
                logger.warning(
                    "Event handler %s failed for %s: %s",
                    h.__qualname__ if hasattr(h, "__qualname__") else h,
                    type(event).__name__,
                    exc,
                    exc_info=True,
                )


# Global singleton; can be overridden for tests
_default_bus: EventBus | None = None


def get_event_bus() -> EventBus:
    """Return the default event bus instance."""
    global _default_bus
    if _default_bus is None:
        _default_bus = EventBus()
    return _default_bus


def set_event_bus(bus: EventBus | None) -> None:
    """Override the default event bus (e.g. for testing)."""
    global _default_bus
    _default_bus = bus
