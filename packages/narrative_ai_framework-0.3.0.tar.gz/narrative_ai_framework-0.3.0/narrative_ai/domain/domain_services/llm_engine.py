"""Domain contract for large-language-model services."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from narrative_ai.engines.llm.base_llm import LLMResult


class LLMServiceInterface(ABC):
    """Abstract LLM contract implemented by LLM engines."""

    @abstractmethod
    async def generate(
        self,
        prompt: str | None = None,
        system_prompt: str | None = None,
        messages: list[dict[str, str]] | None = None,
        temperature: float = 0.7,
        max_tokens: int | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        response_format: dict[str, Any] | None = None,
        provider: str | None = None,
        user_id: str | None = None,
        tenant_id: str | None = None,
        user_tier: Any | None = None,
        correlation_id: str | None = None,
    ) -> LLMResult:
        """Generate a completion from prompt/messages."""

    @abstractmethod
    async def health_check(self) -> dict[str, Any]:
        """Return LLM health information."""

    @abstractmethod
    async def shutdown(self) -> None:
        """Release LLM resources."""
