"""Domain contract for ingestion-pipeline services."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from narrative_ai.engines.input_processor.types import StructuredDocument


class IngestionServiceInterface(ABC):
    """Abstract ingestion contract implemented by ingestion engines."""

    @abstractmethod
    async def process(
        self,
        source: str | Path | bytes,
        enable_image_processing: bool | None = None,
        enable_audio_processing: bool | None = None,
        user_id: Any | None = None,
        tenant_id: Any | None = None,
        correlation_id: str | None = None,
    ) -> StructuredDocument:
        """Process an arbitrary input source into a structured document."""

    @abstractmethod
    async def process_audio(
        self,
        source: str,
        language: str | None = None,
        user_id: Any | None = None,
        tenant_id: Any | None = None,
        correlation_id: str | None = None,
    ) -> StructuredDocument:
        """Process an audio-capable source into a structured document."""
