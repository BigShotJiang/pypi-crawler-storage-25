"""Domain contract for speech-to-text services."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class STTServiceInterface(ABC):
    """Abstract STT contract implemented by STT engines."""

    @abstractmethod
    async def transcribe(
        self,
        audio: bytes,
        sample_rate: int = 16000,
        language: str | None = None,
        extract_emotion: bool = True,
        use_vad: bool = True,
        provider: str | None = None,
        user_id: str | None = None,
        tenant_id: str | None = None,
        user_tier: Any | None = None,
        correlation_id: str | None = None,
    ) -> Any:
        """Transcribe audio bytes into text and metadata."""

    @abstractmethod
    async def health_check(self) -> dict[str, Any]:
        """Return STT health information."""

    @abstractmethod
    async def shutdown(self) -> None:
        """Release STT resources."""
