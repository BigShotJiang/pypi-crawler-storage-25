"""Domain contract for RAG memory operations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from narrative_ai.engines.input_processor.types import StructuredDocument
from narrative_ai.engines.rag.types import IndexingResult, RetrievalResult, RichContext


class RAGServiceInterface(ABC):
    """Abstract contract implemented by RAG-capable engines."""

    @abstractmethod
    async def remember(
        self,
        document: StructuredDocument,
        doc_id: str | None = None,
        user_id: Any | None = None,
        tenant_id: Any | None = None,
        correlation_id: str | None = None,
    ) -> IndexingResult:
        """Index a structured document into memory."""

    @abstractmethod
    async def recall(
        self,
        query: str,
        top_k: int | None = None,
        filters: dict[str, Any] | None = None,
        return_context: bool = True,
        user_id: Any | None = None,
        tenant_id: Any | None = None,
        correlation_id: str | None = None,
    ) -> RichContext | list[RetrievalResult]:
        """Retrieve memory context/results for a query."""

    @abstractmethod
    async def forget(self, doc_id: str, user_id: Any | None = None) -> bool:
        """Delete memory chunks for a document, optionally scoped by user."""
