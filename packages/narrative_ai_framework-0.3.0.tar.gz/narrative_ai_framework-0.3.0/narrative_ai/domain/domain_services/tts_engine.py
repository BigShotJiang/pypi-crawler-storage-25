"""Domain contract for text-to-speech services."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from narrative_ai.engines.tts.base_tts import TTSResult


class TTSServiceInterface(ABC):
    """Abstract TTS contract implemented by TTS engines."""

    @abstractmethod
    async def synthesize(
        self,
        text: str,
        voice_id: str | None = None,
        language: str | None = None,
        emotion: Any | None = None,
        output_format: str = "mp3_44100_128",
        provider: str | None = None,
        user_id: str | None = None,
        tenant_id: str | None = None,
        correlation_id: str | None = None,
    ) -> TTSResult:
        """Synthesize speech from text."""

    @abstractmethod
    async def get_voices(self, provider: str | None = None) -> dict[str, list[Any]]:
        """List available voices."""

    @abstractmethod
    async def health_check(self) -> dict[str, Any]:
        """Return TTS health information."""

    @abstractmethod
    async def shutdown(self) -> None:
        """Release TTS resources."""
