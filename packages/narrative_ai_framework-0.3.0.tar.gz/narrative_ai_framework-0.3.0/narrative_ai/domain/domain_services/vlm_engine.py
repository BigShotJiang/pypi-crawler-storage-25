"""Domain contract for vision-language-model services."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from narrative_ai.engines.vlm.types import CaptionResult, ProcessingError


class VLMServiceInterface(ABC):
    """Abstract VLM contract implemented by VLM engines."""

    @abstractmethod
    async def process(
        self,
        image: str | Path | bytes | Any,
        prompt: str | None = None,
        user_id: Any | None = None,
        tenant_id: Any | None = None,
        correlation_id: str | None = None,
    ) -> tuple[CaptionResult | None, ProcessingError | None]:
        """Generate captioning metadata for an image input."""
