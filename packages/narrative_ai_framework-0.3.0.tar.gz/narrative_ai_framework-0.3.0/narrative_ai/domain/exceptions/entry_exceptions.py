"""Entry-related domain exceptions."""

from __future__ import annotations

import uuid

from .domain_exception import DomainException


class EntryNotFoundError(DomainException):
    """Raised when a diary entry is not found for the given id and user."""

    message = "Entry not found"
    http_status = 404
    code = "ENTRY_NOT_FOUND"

    def __init__(
        self,
        entry_id: uuid.UUID | None = None,
        user_id: uuid.UUID | None = None,
        message: str | None = None,
    ) -> None:
        msg = message or self.message
        if entry_id is not None:
            msg = f"Entry {entry_id} not found"
        if user_id is not None and entry_id is not None:
            msg = f"Entry {entry_id} not found for user {user_id}"
        super().__init__(message=msg, entry_id=entry_id, user_id=user_id)


class EntryValidationError(DomainException):
    """Raised when entry data fails validation."""

    message = "Invalid entry data"
    http_status = 400
    code = "ENTRY_VALIDATION_ERROR"


class NoSpeechDetectedError(DomainException):
    """Raised when STT returns no speech in the audio."""

    message = "No speech detected in audio"
    http_status = 422
    code = "NO_SPEECH_DETECTED"
