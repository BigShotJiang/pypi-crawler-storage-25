"""User-related domain exceptions."""

from __future__ import annotations

from .domain_exception import DomainException


class UserNotFoundError(DomainException):
    """Raised when a user is not found by id or email."""

    message = "User not found"
    http_status = 404
    code = "USER_NOT_FOUND"


class UserAlreadyExistsError(DomainException):
    """Raised when attempting to register with an email that already exists."""

    message = "A user with this email already exists"
    http_status = 409
    code = "USER_ALREADY_EXISTS"


class InvalidCredentialsError(DomainException):
    """Raised when email/password do not match (timing-safe; does not leak existence)."""

    message = "Invalid email or password"
    http_status = 401
    code = "INVALID_CREDENTIALS"


class AccountDeactivatedError(DomainException):
    """Raised when the user account is deactivated."""

    message = "Account is deactivated"
    http_status = 403
    code = "ACCOUNT_DEACTIVATED"
