"""Domain exceptions -- explicit error types for domain layer."""

from .domain_exception import DomainException
from .entry_exceptions import EntryNotFoundError, EntryValidationError, NoSpeechDetectedError
from .user_exceptions import (
    UserNotFoundError,
    UserAlreadyExistsError,
    InvalidCredentialsError,
    AccountDeactivatedError,
)


class ServiceUnavailableError(DomainException):
    """Raised when a required external service (STT, LLM) is unavailable."""

    message = "Service temporarily unavailable"
    http_status = 503
    code = "SERVICE_UNAVAILABLE"


__all__ = [
    "DomainException",
    "EntryNotFoundError",
    "EntryValidationError",
    "NoSpeechDetectedError",
    "UserNotFoundError",
    "UserAlreadyExistsError",
    "InvalidCredentialsError",
    "AccountDeactivatedError",
    "ServiceUnavailableError",
]
