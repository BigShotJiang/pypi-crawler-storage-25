"""Base domain exception.

All domain-specific exceptions inherit from DomainException.
They can be mapped to HTTP status codes at the API layer.
"""

from __future__ import annotations


class DomainException(Exception):
    """Base exception for domain-layer errors.

    Subclasses should override:
    - message: Human-readable description
    - http_status: Suggested HTTP status code (404, 409, etc.)
    - code: Machine-readable error code (e.g. ENTRY_NOT_FOUND)
    """

    message: str = "A domain error occurred"
    http_status: int = 500
    code: str = "DOMAIN_ERROR"

    def __init__(self, message: str | None = None, **kwargs: object) -> None:
        super().__init__(message or self.message)
        self._message = message or self.message
        self._details = kwargs

    @property
    def detail_message(self) -> str:
        return self._message

    def __str__(self) -> str:
        return self._message
