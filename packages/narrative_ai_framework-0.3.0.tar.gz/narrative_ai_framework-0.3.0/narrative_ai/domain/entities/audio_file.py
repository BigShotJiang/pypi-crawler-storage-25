"""Audio file metadata domain entity."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class AudioFileType(str, Enum):
    """Purpose of the stored audio."""

    INPUT = "input"  # Original voice recording from user
    TTS_RESPONSE = "tts_response"  # AI companion audio reply
    AUDIOBOOK = "audiobook"  # Exported audiobook chapter / full


@dataclass
class AudioFile:
    """Metadata for an audio artefact stored in object storage (S3 / local).

    The actual binary lives in S3 or the local filesystem; this entity
    tracks the reference path, duration, voice used, and expiry.
    """

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    user_id: uuid.UUID = field(default_factory=uuid.uuid4)

    file_type: AudioFileType = AudioFileType.INPUT
    storage_path: str = ""
    duration_seconds: float = 0.0
    voice_used: Optional[str] = None
    quality: str = "high"
    format: str = "mp3"

    # Link to conversation (for TTS responses)
    conversation_id: Optional[uuid.UUID] = None

    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    expires_at: Optional[datetime] = None

    @property
    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return datetime.now(timezone.utc) > self.expires_at
