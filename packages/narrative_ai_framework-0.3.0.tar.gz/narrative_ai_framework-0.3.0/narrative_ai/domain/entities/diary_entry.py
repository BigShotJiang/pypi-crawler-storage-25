"""Diary entry domain entity."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional


class SourceType(str, Enum):
    """How the entry was originally captured."""

    VOICE = "voice"
    TEXT = "text"
    IMAGE = "image"  # OCR / handwriting
    FILE = "file"


@dataclass
class DiaryEntry:
    """A single diary entry created by a user.

    Core table of the entire application.  Each entry may have been
    created from voice (STT), typed text, or scanned handwriting (OCR).
    The ``raw_text`` preserves the original transcription / input while
    ``enhanced_text`` holds the LLM-beautified version.
    """

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    user_id: uuid.UUID = field(default_factory=uuid.uuid4)

    # Content
    raw_text: str = ""
    enhanced_text: str = ""
    emotion: str = "neutral"
    source_type: SourceType = SourceType.TEXT
    tags: List[str] = field(default_factory=list)

    # Optional reference to the original audio recording
    audio_storage_path: Optional[str] = None

    # Timestamps
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: Optional[datetime] = None
    deleted_at: Optional[datetime] = None  # soft delete

    # ------------------------------------------------------------------
    # Domain behaviour
    # ------------------------------------------------------------------

    @property
    def is_deleted(self) -> bool:
        return self.deleted_at is not None

    def soft_delete(self) -> None:
        self.deleted_at = datetime.now(timezone.utc)

    def restore(self) -> None:
        self.deleted_at = None

    def update_text(self, enhanced: str) -> None:
        self.enhanced_text = enhanced
        self.updated_at = datetime.now(timezone.utc)

    def add_tag(self, tag: str) -> None:
        tag = tag.strip().lower()
        if tag and tag not in self.tags:
            self.tags.append(tag)
            self.updated_at = datetime.now(timezone.utc)

    def remove_tag(self, tag: str) -> None:
        tag = tag.strip().lower()
        if tag in self.tags:
            self.tags.remove(tag)
            self.updated_at = datetime.now(timezone.utc)
