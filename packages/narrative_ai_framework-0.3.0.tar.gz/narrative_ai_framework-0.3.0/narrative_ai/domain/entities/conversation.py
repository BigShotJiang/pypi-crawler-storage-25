"""Conversation domain entity."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional


class MessageRole(str, Enum):
    """Who sent the message."""

    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


@dataclass
class ConversationMessage:
    """A single message within a conversation turn."""

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    conversation_id: uuid.UUID = field(default_factory=uuid.uuid4)
    role: MessageRole = MessageRole.USER
    content: str = ""

    # Optional audio response URL (when TTS was used)
    audio_url: Optional[str] = None

    # Which diary entries were used as RAG context
    sources_json: Optional[str] = None

    # Detected emotion of the message / response
    emotion: Optional[str] = None

    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class Conversation:
    """Multi-turn conversation between a user and the AI companion.

    Stores the full message history so the user can revisit past chats.
    """

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    user_id: uuid.UUID = field(default_factory=uuid.uuid4)
    title: str = ""
    messages: List[ConversationMessage] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Domain behaviour
    # ------------------------------------------------------------------

    def add_message(
        self,
        role: MessageRole,
        content: str,
        *,
        audio_url: Optional[str] = None,
        sources_json: Optional[str] = None,
        emotion: Optional[str] = None,
    ) -> ConversationMessage:
        msg = ConversationMessage(
            conversation_id=self.id,
            role=role,
            content=content,
            audio_url=audio_url,
            sources_json=sources_json,
            emotion=emotion,
        )
        self.messages.append(msg)
        self.updated_at = datetime.now(timezone.utc)
        return msg

    @property
    def message_count(self) -> int:
        return len(self.messages)

    @property
    def last_message(self) -> Optional[ConversationMessage]:
        return self.messages[-1] if self.messages else None

    def auto_title(self) -> None:
        """Generate a title from the first user message if not set."""
        if self.title:
            return
        for msg in self.messages:
            if msg.role == MessageRole.USER and msg.content:
                self.title = msg.content[:80]
                return
