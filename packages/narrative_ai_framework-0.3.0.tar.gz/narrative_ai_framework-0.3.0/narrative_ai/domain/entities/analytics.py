"""Analytics event domain entity."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict


@dataclass
class AnalyticsEvent:
    """A single analytics event (emotion tracking, feature usage, etc.).

    Events are append-only and use a flexible ``metadata`` JSONB column
    for extensibility so we don't have to migrate the schema every time
    a new event type is added.
    """

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    user_id: uuid.UUID = field(default_factory=uuid.uuid4)
    event_type: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
