"""User domain entity."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


class UserRole(str, Enum):
    """User roles within a tenant."""

    USER = "user"
    ADMIN = "admin"


class SubscriptionTier(str, Enum):
    """Subscription plans."""

    FREE = "free"
    PREMIUM = "premium"


@dataclass
class User:
    """Represents a registered user of the diary application.

    Every user belongs to exactly one tenant (even in single-tenant
    mode, where the default tenant is used).  The ``password_hash``
    is stored -- never the plain-text password.
    """

    id: uuid.UUID = field(default_factory=uuid.uuid4)
    email: str = ""
    password_hash: str = ""
    display_name: str = ""
    role: UserRole = UserRole.USER
    subscription_tier: SubscriptionTier = SubscriptionTier.FREE
    is_active: bool = True
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    @property
    def is_premium(self) -> bool:
        return self.subscription_tier == SubscriptionTier.PREMIUM

    @property
    def is_admin(self) -> bool:
        return self.role == UserRole.ADMIN

    def upgrade_to_premium(self) -> None:
        self.subscription_tier = SubscriptionTier.PREMIUM
        self.updated_at = datetime.now(timezone.utc)

    def deactivate(self) -> None:
        self.is_active = False
        self.updated_at = datetime.now(timezone.utc)
