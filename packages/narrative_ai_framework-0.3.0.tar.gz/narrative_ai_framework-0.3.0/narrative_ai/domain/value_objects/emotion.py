"""Emotion value object shared across all engines."""

from __future__ import annotations

from enum import Enum


class Emotion(str, Enum):
    """Canonical emotion labels used across STT, TTS, LLM, and analytics."""

    HAPPY = "happy"
    SAD = "sad"
    ANGRY = "angry"
    CALM = "calm"
    ANXIOUS = "anxious"
    NEUTRAL = "neutral"
    EXCITED = "excited"
    EMPATHETIC = "empathetic"
    SURPRISED = "surprised"
    THOUGHTFUL = "thoughtful"

    @classmethod
    def from_string(cls, raw: str) -> "Emotion":
        """Parse a string to an Emotion, defaulting to NEUTRAL."""
        try:
            return cls(raw.lower().strip())
        except (ValueError, AttributeError):
            return cls.NEUTRAL
