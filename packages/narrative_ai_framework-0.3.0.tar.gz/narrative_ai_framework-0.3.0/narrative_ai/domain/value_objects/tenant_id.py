"""Tenant ID value object."""

from __future__ import annotations

import uuid
from dataclasses import dataclass


@dataclass(frozen=True)
class TenantId:
    """Immutable tenant identifier.

    In the single-database design the tenant_id column isolates data
    belonging to different organisations / deployments.  When the
    framework is used as a standalone SDK (no multi-tenancy) a default
    tenant UUID is used so that the schema stays consistent.
    """

    value: uuid.UUID

    # ------------------------------------------------------------------
    # Factory helpers
    # ------------------------------------------------------------------

    @classmethod
    def generate(cls) -> "TenantId":
        return cls(value=uuid.uuid4())

    @classmethod
    def from_string(cls, raw: str) -> "TenantId":
        return cls(value=uuid.UUID(raw))

    @classmethod
    def default(cls) -> "TenantId":
        """Default tenant for single-tenant / SDK usage."""
        return cls(value=uuid.UUID("00000000-0000-0000-0000-000000000000"))

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def __str__(self) -> str:
        return str(self.value)

    def __hash__(self) -> int:
        return hash(self.value)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, TenantId):
            return self.value == other.value
        return NotImplemented
