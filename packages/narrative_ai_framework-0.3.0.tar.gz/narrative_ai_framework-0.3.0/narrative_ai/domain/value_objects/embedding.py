"""Embedding value object."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class Embedding:
    """Immutable dense-vector embedding (e.g. 768-D from sentence-transformers).

    Stored in PostgreSQL via pgvector as ``vector(768)`` and indexed with
    HNSW for fast approximate-nearest-neighbour search.
    """

    vector: List[float]

    @property
    def dimension(self) -> int:
        return len(self.vector)

    def to_list(self) -> List[float]:
        return list(self.vector)

    def __len__(self) -> int:
        return len(self.vector)
