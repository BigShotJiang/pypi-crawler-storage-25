"""Audio metadata value object."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class AudioMetadata:
    """Describes an audio artefact (input recording or TTS output)."""

    storage_path: str
    duration_seconds: float
    format: str = "mp3"
    sample_rate: int = 16_000
    voice_used: Optional[str] = None
    quality: str = "high"
    file_size_bytes: Optional[int] = None
