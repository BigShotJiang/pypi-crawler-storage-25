"""User ID value object."""

from __future__ import annotations

import uuid
from dataclasses import dataclass


@dataclass(frozen=True)
class UserId:
    """Immutable user identifier."""

    value: uuid.UUID

    @classmethod
    def generate(cls) -> "UserId":
        return cls(value=uuid.uuid4())

    @classmethod
    def from_string(cls, raw: str) -> "UserId":
        return cls(value=uuid.UUID(raw))

    def __str__(self) -> str:
        return str(self.value)

    def __hash__(self) -> int:
        return hash(self.value)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, UserId):
            return self.value == other.value
        return NotImplemented
