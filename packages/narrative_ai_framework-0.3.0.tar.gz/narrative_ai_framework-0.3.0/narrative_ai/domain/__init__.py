"""Narrative AI domain layer.

Contains entities, value objects, repository interfaces, domain events,
and exceptions -- all framework-agnostic (no SQLAlchemy, no FastAPI).
Business logic engines live in narrative_ai.engines.
"""
