"""
Narrative AI - FastAPI Application Entry Point.

Creates a FastAPI server exposing STT, TTS, LLM, RAG, VLM, and Ingestion engines as REST APIs.
Each engine can be loaded selectively via the --engines CLI flag.

Usage:
    # All engines
    python -m framework.api.app --engines stt,tts,llm,rag,vlm,ingestion

    # Single engine
    python -m framework.api.app --engines stt
    python -m framework.api.app --engines tts
    python -m framework.api.app --engines llm
    python -m framework.api.app --engines rag
    python -m framework.api.app --engines vlm
    python -m framework.api.app --engines ingestion

    # Custom host/port
    python -m framework.api.app --engines stt --host 0.0.0.0 --port 8001
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

# Ensure project root is on path and load .env
_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
if _root not in sys.path:
    sys.path.insert(0, _root)
_env_path = os.path.join(_root, ".env")
if os.path.isfile(_env_path):
    try:
        from dotenv import load_dotenv

        load_dotenv(_env_path, override=False)
    except ImportError:
        pass

from contextlib import asynccontextmanager  # noqa: E402

from fastapi import FastAPI  # noqa: E402
from fastapi.middleware.cors import CORSMiddleware  # noqa: E402

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lifespan: startup / shutdown hooks
# ---------------------------------------------------------------------------


@asynccontextmanager
async def _lifespan(app: FastAPI):
    """Manage async resources across the application lifetime."""
    # --- startup ---
    db_url = os.getenv("DATABASE_URL", "")
    if db_url:
        try:
            from narrative_ai.infrastructure.database.connection import get_engine

            get_engine()  # creates the singleton engine
            logger.info("Database engine initialised.")
        except Exception as e:
            logger.warning("Could not initialise database engine: %s", e)
    else:
        logger.info("DATABASE_URL not set -- database features disabled.")

    yield  # application is running

    # --- shutdown ---
    # All STT/TTS/LLM engines are now created via dependencies; single shutdown path
    # Shutdown dependency-managed engine singletons
    try:
        from narrative_ai.api.dependencies import shutdown_engine_singletons

        await shutdown_engine_singletons()
    except Exception as e:
        logger.warning("Error shutting down dependency-managed engines: %s", e)

    # Dispose database engine
    try:
        from narrative_ai.infrastructure.database.connection import dispose_engine

        await dispose_engine()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Application factory
# ---------------------------------------------------------------------------


def create_app(engines: list[str] | None = None) -> FastAPI:
    """
    Create FastAPI application with selected engine routers.

    Args:
        engines: List of engines to load
                 ("stt", "tts", "llm", "rag", "vlm", "ingestion").
                 If None or empty, loads all engines.

    Returns:
        Configured FastAPI application.
    """
    if not engines:
        engines = ["stt", "tts", "llm", "rag", "vlm", "ingestion"]

    # Normalize
    engines = [e.strip().lower() for e in engines]

    app = FastAPI(
        title="Narrative AI API",
        description="REST API for Narrative AI engines (STT, TTS, LLM, RAG, VLM, Ingestion)",
        version="1.0.0",
        lifespan=_lifespan,
    )

    # CORS -- allow all origins in development, REQUIRE whitelist in production
    allow_origins = ["*"]
    if os.getenv("ENV", "development") == "production":
        allowed = os.getenv("CORS_ALLOWED_ORIGINS", "")
        if not allowed:
            raise RuntimeError(
                "CORS_ALLOWED_ORIGINS must be set in production.  "
                "Example: CORS_ALLOWED_ORIGINS=https://app.narrative-ai.com"
            )
        allow_origins = [o.strip() for o in allowed.split(",") if o.strip()]

    app.add_middleware(
        CORSMiddleware,
        allow_origins=allow_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # -------------------------------------------------------------------------
    # Custom middleware (order matters: last added = outermost = runs first)
    # Execution order (outermost -> innermost):
    #   JwtUserId -> CorrelationId -> Logging -> RateLimit -> SecurityHeaders -> route handler
    # JwtUserId sets request.state.user_id from Bearer token so rate limiter can use per-user keys.
    # -------------------------------------------------------------------------
    try:
        from narrative_ai.api.middleware.security_headers import SecurityHeadersMiddleware

        app.add_middleware(SecurityHeadersMiddleware)
        logger.info("Security headers middleware registered.")
    except Exception as e:
        logger.warning("Could not register security headers middleware: %s", e)
    try:
        from narrative_ai.api.middleware.rate_limit import RateLimitMiddleware

        app.add_middleware(RateLimitMiddleware)
        logger.info("Rate limiting middleware registered.")
    except Exception as e:
        logger.warning("Could not register rate limiting middleware: %s", e)
    try:
        from narrative_ai.api.middleware.logging import RequestLoggingMiddleware

        app.add_middleware(RequestLoggingMiddleware)
        logger.info("Request logging middleware registered.")
    except Exception as e:
        logger.warning("Could not register request logging middleware: %s", e)
    try:
        from narrative_ai.api.middleware.correlation_id import CorrelationIdMiddleware

        app.add_middleware(CorrelationIdMiddleware)
        logger.info("Correlation ID middleware registered.")
    except Exception as e:
        logger.warning("Could not register correlation ID middleware: %s", e)
    try:
        from narrative_ai.api.middleware.jwt_user_id import JwtUserIdMiddleware

        app.add_middleware(JwtUserIdMiddleware)
        logger.info("JWT user-id middleware registered (for per-user rate limiting).")
    except Exception as e:
        logger.warning("Could not register JWT user-id middleware: %s", e)

    # -------------------------------------------------------------------------
    # Global error handler
    # -------------------------------------------------------------------------
    try:
        from narrative_ai.api.middleware.error_handler import register_error_handlers

        register_error_handlers(app)
        logger.info("Global error handlers registered.")
    except Exception as e:
        logger.warning("Could not register error handlers: %s", e)

    # -------------------------------------------------------------------------
    # Auth & Entries routers (always loaded -- not engine-gated)
    # -------------------------------------------------------------------------
    try:
        from narrative_ai.api.routes.auth import router as auth_router

        app.include_router(auth_router)
        logger.info("Auth routes loaded at /api/auth")
    except Exception as e:
        logger.warning("Could not load auth routes: %s", e)

    try:
        from narrative_ai.api.routes.entries import router as entries_router

        app.include_router(entries_router)
        logger.info("Entries routes loaded at /api/entries")
    except Exception as e:
        logger.warning("Could not load entries routes: %s", e)

    # -------------------------------------------------------------------------
    # Optional routers (return 501 until services are implemented)
    # -------------------------------------------------------------------------
    try:
        from narrative_ai.api.routes.search import router as search_router

        app.include_router(search_router)
        logger.info("Search routes loaded at /api/search (404 until implemented)")
    except Exception as e:
        logger.warning("Could not load search routes: %s", e)
    try:
        from narrative_ai.api.routes.export import router as export_router

        app.include_router(export_router)
        logger.info("Export routes loaded at /api/export (404 until implemented)")
    except Exception as e:
        logger.warning("Could not load export routes: %s", e)
    try:
        from narrative_ai.api.routes.analytics import router as analytics_router

        app.include_router(analytics_router)
        logger.info("Analytics routes loaded at /api/analytics")
    except Exception as e:
        logger.warning("Could not load analytics routes: %s", e)
    try:
        from narrative_ai.api.routes.companion import router as companion_router

        app.include_router(companion_router)
        logger.info("Companion routes loaded at /api/companion (404 until implemented)")
    except Exception as e:
        logger.warning("Could not load companion routes: %s", e)
    try:
        from narrative_ai.api.routes.web_intel import router as web_intel_router

        app.include_router(web_intel_router)
        logger.info("Web intelligence routes loaded at /api/web-intel")
    except Exception as e:
        logger.warning("Could not load web intelligence routes: %s", e)

    # -------------------------------------------------------------------------
    # Register engine routers
    # -------------------------------------------------------------------------
    loaded = []

    if "stt" in engines:
        try:
            from narrative_ai.api.routes.stt import router as stt_router

            app.include_router(stt_router)
            loaded.append("stt")
            logger.info("STT engine routes loaded at /api/stt")
        except Exception as e:
            logger.error(f"Failed to load STT routes: {e}", exc_info=True)

    if "tts" in engines:
        try:
            from narrative_ai.api.routes.tts import router as tts_router

            app.include_router(tts_router)
            loaded.append("tts")
            logger.info("TTS engine routes loaded at /api/tts")
        except Exception as e:
            logger.error(f"Failed to load TTS routes: {e}", exc_info=True)

    if "llm" in engines:
        try:
            from narrative_ai.api.routes.llm import router as llm_router

            app.include_router(llm_router)
            loaded.append("llm")
            logger.info("LLM engine routes loaded at /api/llm")
        except Exception as e:
            logger.error(f"Failed to load LLM routes: {e}", exc_info=True)

    if "rag" in engines:
        try:
            from narrative_ai.api.routes.rag import router as rag_router

            app.include_router(rag_router)
            loaded.append("rag")
            logger.info("RAG engine routes loaded at /api/rag")
        except Exception as e:
            logger.error(f"Failed to load RAG routes: {e}", exc_info=True)

    if "vlm" in engines:
        try:
            from narrative_ai.api.routes.vlm import router as vlm_router

            app.include_router(vlm_router)
            loaded.append("vlm")
            logger.info("VLM engine routes loaded at /api/vlm")
        except Exception as e:
            logger.error(f"Failed to load VLM routes: {e}", exc_info=True)

    if "ingestion" in engines:
        try:
            from narrative_ai.api.routes.ingestion import router as ingestion_router
            from narrative_ai.api.routes.ocr import router as ocr_router

            app.include_router(ingestion_router)
            app.include_router(ocr_router)
            loaded.append("ingestion")
            logger.info("Ingestion engine routes loaded at /api/ingestion")
            logger.info("OCR routes loaded at /api/ocr")
        except Exception as e:
            logger.error(f"Failed to load Ingestion routes: {e}", exc_info=True)

    # -------------------------------------------------------------------------
    # Health endpoint (always available)
    # -------------------------------------------------------------------------
    @app.get("/health")
    async def health():
        return {
            "status": "ok",
            "engines": loaded,
            "env": os.getenv("ENV", "development"),
        }

    @app.get("/")
    async def root():
        return {
            "service": "Narrative AI API",
            "version": "1.0.0",
            "engines": loaded,
            "docs": "/docs",
        }

    return app


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Narrative AI API Server",
    )
    parser.add_argument(
        "--engines",
        default="stt,tts,llm,rag,vlm,ingestion",
        help="Comma-separated list of engines to load (stt,tts,llm,rag,vlm,ingestion). Default: all.",
    )
    parser.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")  # nosec: B104
    parser.add_argument("--port", type=int, default=8000, help="Bind port (default: 8000)")
    parser.add_argument("--workers", type=int, default=1, help="Number of workers (default: 1)")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload (development)")
    args = parser.parse_args()

    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    engines = [e.strip() for e in args.engines.split(",") if e.strip()]
    logger.info(f"Starting Narrative AI API with engines: {engines}")

    # Warn when multi-worker may exhaust Postgres connections (pool_size + max_overflow per process)
    if args.workers > 1 and os.getenv("DATABASE_URL"):
        pool_size = int(os.getenv("DATABASE_POOL_SIZE", "20"))
        max_overflow = int(os.getenv("DATABASE_MAX_OVERFLOW", "40"))
        total_connections = args.workers * (pool_size + max_overflow)
        if total_connections >= 200:
            logger.warning(
                "Multi-worker DB pool: workers=%d * (pool_size=%d + max_overflow=%d) = %d connections. "
                "Ensure PostgreSQL max_connections is greater than this (e.g. 250). "
                "Consider lowering DATABASE_POOL_SIZE when using many workers.",
                args.workers,
                pool_size,
                max_overflow,
                total_connections,
            )

    import uvicorn

    # Reload/workers require an import string so uvicorn can re-import the app
    if args.reload or args.workers > 1:
        os.environ["_NARRATIVE_ENGINES"] = args.engines
        uvicorn.run(
            "narrative_ai.api.app:_app_factory",
            factory=True,
            host=args.host,
            port=args.port,
            workers=args.workers,
            reload=args.reload,
        )
    else:
        app = create_app(engines)
        uvicorn.run(
            app,
            host=args.host,
            port=args.port,
        )


def _app_factory() -> FastAPI:
    """Factory for uvicorn multi-worker mode."""
    engines_str = os.getenv("_NARRATIVE_ENGINES", "stt,tts,llm,rag,vlm,ingestion")
    engines = [e.strip() for e in engines_str.split(",") if e.strip()]
    return create_app(engines)


if __name__ == "__main__":
    main()
