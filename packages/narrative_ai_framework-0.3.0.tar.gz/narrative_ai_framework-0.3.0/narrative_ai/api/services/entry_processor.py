"""Entry processing service -- LLM-powered enhancement, emotion detection, tagging.

This thin service encapsulates the LLM prompting logic that turns raw diary
text into enriched entries.  It is used by the pipeline endpoints in
``framework.api.routes.entries`` and is injected via FastAPI dependencies.
"""

from __future__ import annotations

import json
import logging
from typing import List, Optional

from narrative_ai.engines.llm import LLMEngine

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System prompts
# ---------------------------------------------------------------------------

_ENHANCE_SYSTEM_PROMPT = """\
You are a diary-enhancement assistant. The user gives you a raw diary entry
(possibly a rough voice transcription). Your job:

1. Fix grammar, spelling, and punctuation.
2. Improve clarity and flow while keeping the original meaning and voice.
3. Keep the same language -- if the entry is in Arabic, reply in Arabic.
4. Do NOT add information the user did not mention.
5. Return ONLY the enhanced text, nothing else.
"""

_EMOTION_SYSTEM_PROMPT = """\
You are an emotion classifier. Given a diary entry, return EXACTLY one word
from this list: happy, sad, angry, anxious, calm, excited, grateful,
lonely, hopeful, nostalgic, neutral.

Return ONLY the single emotion word, nothing else.
"""

_TAGS_SYSTEM_PROMPT = """\
You are a tag extractor. Given a diary entry and its detected emotion,
return a JSON array of 1-5 short lowercase tags that summarise the key
topics (e.g. ["work", "family", "health"]).

Rules:
- Include the emotion as a tag.
- Only include tags directly mentioned or clearly implied.
- Return ONLY the JSON array, nothing else.
"""


class EntryProcessor:
    """Orchestrates LLM calls for diary entry enrichment."""

    def __init__(self, llm_engine: LLMEngine) -> None:
        self._llm = llm_engine

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def enhance_text(
        self,
        raw_text: str,
        emotion: str = "neutral",
        *,
        user_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> str:
        """Return an LLM-enhanced version of *raw_text*.

        On failure the original *raw_text* is returned unchanged.
        """
        try:
            result = await self._llm.generate(
                prompt=raw_text,
                system_prompt=_ENHANCE_SYSTEM_PROMPT,
                temperature=0.4,
                max_tokens=2000,
                user_id=user_id,
                correlation_id=correlation_id,
            )
            enhanced = result.text.strip()
            return enhanced if enhanced else raw_text
        except Exception as exc:
            logger.warning("LLM enhancement failed (returning raw text): %s", exc)
            return raw_text

    async def detect_emotion(
        self,
        text: str,
        *,
        user_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> str:
        """Use the LLM to classify the dominant emotion of *text*.

        Returns one of the predefined emotion labels, or ``"neutral"``
        on failure.
        """
        valid_emotions = {
            "happy",
            "sad",
            "angry",
            "anxious",
            "calm",
            "excited",
            "grateful",
            "lonely",
            "hopeful",
            "nostalgic",
            "neutral",
        }
        try:
            result = await self._llm.generate(
                prompt=text,
                system_prompt=_EMOTION_SYSTEM_PROMPT,
                temperature=0.0,
                max_tokens=10,
                user_id=user_id,
                correlation_id=correlation_id,
            )
            emotion = result.text.strip().lower().rstrip(".")
            return emotion if emotion in valid_emotions else "neutral"
        except Exception as exc:
            logger.warning("LLM emotion detection failed: %s", exc)
            return "neutral"

    async def generate_tags(
        self,
        text: str,
        emotion: str = "neutral",
        *,
        user_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> List[str]:
        """Use the LLM to extract 1-5 topic tags from *text*.

        Returns an empty list on failure.
        """
        prompt = f"Emotion: {emotion}\n\nDiary entry:\n{text}"
        try:
            result = await self._llm.generate(
                prompt=prompt,
                system_prompt=_TAGS_SYSTEM_PROMPT,
                temperature=0.0,
                max_tokens=100,
                user_id=user_id,
                correlation_id=correlation_id,
            )
            raw = result.text.strip()
            # Parse JSON array
            tags = json.loads(raw)
            if isinstance(tags, list):
                return [t.strip().lower() for t in tags if isinstance(t, str) and t.strip()][:5]
        except (json.JSONDecodeError, TypeError, ValueError):
            logger.warning("Could not parse tags JSON from LLM output: %s", result.text if "result" in dir() else "N/A")
        except Exception as exc:
            logger.warning("LLM tag generation failed: %s", exc)
        return []

    async def process_entry(
        self,
        raw_text: str,
        *,
        detect_emotion: bool = True,
        enhance: bool = True,
        generate_tags: bool = True,
        existing_emotion: str = "neutral",
        user_id: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> dict:
        """Run the full enrichment pipeline on *raw_text*.

        Returns a dict with keys ``enhanced_text``, ``emotion``, ``tags``
        that can be applied directly to a diary entry.
        """
        emotion = existing_emotion

        # Emotion detection first (tags depend on it)
        if detect_emotion:
            emotion = await self.detect_emotion(
                raw_text,
                user_id=user_id,
                correlation_id=correlation_id,
            )

        enhanced_text = ""
        if enhance:
            enhanced_text = await self.enhance_text(
                raw_text,
                emotion=emotion,
                user_id=user_id,
                correlation_id=correlation_id,
            )

        tags: List[str] = []
        if generate_tags:
            tags = await self.generate_tags(
                enhanced_text or raw_text,
                emotion=emotion,
                user_id=user_id,
                correlation_id=correlation_id,
            )

        return {
            "enhanced_text": enhanced_text,
            "emotion": emotion,
            "tags": tags,
        }
