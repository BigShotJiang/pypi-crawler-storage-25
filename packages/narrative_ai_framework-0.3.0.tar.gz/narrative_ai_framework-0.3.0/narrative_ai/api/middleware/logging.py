"""Structured request/response logging middleware.

Logs every HTTP request with method, path, status code, duration, and the
correlation ID (if available from :mod:`correlation_id` middleware).

Attach this middleware **after** :class:`CorrelationIdMiddleware` so the
correlation ID is already set on ``request.state`` when logging fires.
"""

from __future__ import annotations

import logging
import time

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger("narrative_ai.access")


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Log every request with timing and correlation info."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        start = time.perf_counter()

        # Collect request metadata
        method = request.method
        path = request.url.path
        client_ip = request.client.host if request.client else "unknown"
        correlation_id = getattr(request.state, "correlation_id", "-")

        # Process the request
        response: Response | None = None
        try:
            response = await call_next(request)
            return response
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            status_code = response.status_code if response else 500

            logger.info(
                "%s %s %d %.1fms cid=%s ip=%s",
                method,
                path,
                status_code,
                duration_ms,
                correlation_id,
                client_ip,
            )
