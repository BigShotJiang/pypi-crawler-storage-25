"""Global error handler middleware for consistent JSON error responses.

Installs exception handlers on the FastAPI app to return errors in
the format::

    {
        "errors": [{"code": "...", "message": "..."}],
        "meta": {"timestamp": "...", "correlation_id": "..."}
    }

In production (``ENV=production``) internal exception details are
suppressed and only generic messages are returned to prevent
information disclosure. DomainException handlers use the instance
message (e.g. detail_message or str(exc)) so API responses show
specific messages like "Entry x not found for user y".
"""

from __future__ import annotations

import logging
import os
import uuid
from datetime import datetime, timezone

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

logger = logging.getLogger(__name__)


def _is_production() -> bool:
    """Check ENV at request time so tests can override via os.environ."""
    return os.getenv("ENV", "development") == "production"


def _error_body(code: str, message: str, status_code: int, *, retry_after: int | None = None) -> dict:
    """Build a consistent error response body.

    Includes both structured format (errors array) and backward-compatible
    'detail' field for mobile app compatibility.
    """
    body = {
        "errors": [{"code": code, "message": message}],
        "detail": message,  # Backward compatibility: mobile app expects 'detail'
        "meta": {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "correlation_id": str(uuid.uuid4()),
        },
    }
    # For 429 rate limit errors, include retry_after_seconds in body
    if status_code == 429 and retry_after is not None:
        body["retry_after_seconds"] = retry_after
    return body


def _safe_detail(exc: Exception, *, generic: str) -> str:
    """Return *generic* in production, ``str(exc)`` otherwise."""
    if _is_production():
        logger.warning("Suppressed error detail in production: %s", exc)
        return generic
    return str(exc)


def register_error_handlers(app: FastAPI) -> None:
    """Attach global exception handlers to *app*."""

    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(request: Request, exc: StarletteHTTPException):
        """Handle all HTTP exceptions (401, 403, 404, 409, 413, 415, 503, etc.).

        Preserves custom headers (e.g., Retry-After for 429) and includes
        both structured errors array and backward-compatible 'detail' field.
        If exc.detail is a dict with 'code' and 'message', those are used
        so routes (ingestion, RAG, VLM) can return consistent structured errors.
        """
        code_map = {
            400: "BAD_REQUEST",
            401: "UNAUTHORIZED",
            403: "FORBIDDEN",
            404: "NOT_FOUND",
            405: "METHOD_NOT_ALLOWED",
            409: "CONFLICT",
            413: "PAYLOAD_TOO_LARGE",
            415: "UNSUPPORTED_MEDIA_TYPE",
            422: "VALIDATION_ERROR",
            429: "RATE_LIMIT_EXCEEDED",
            503: "SERVICE_UNAVAILABLE",
        }
        if isinstance(exc.detail, dict) and "code" in exc.detail and "message" in exc.detail:
            code = str(exc.detail["code"])
            detail = str(exc.detail["message"])
        else:
            code = code_map.get(exc.status_code, "HTTP_ERROR")
            detail = exc.detail if isinstance(exc.detail, str) else str(exc.detail)

        # Extract Retry-After header for 429 errors
        retry_after = None
        if exc.status_code == 429 and exc.headers:
            retry_after_str = exc.headers.get("Retry-After")
            if retry_after_str:
                try:
                    retry_after = int(retry_after_str)
                except (ValueError, TypeError):
                    pass

        # Preserve all custom headers (especially Retry-After for 429)
        headers = dict(exc.headers) if exc.headers else {}

        return JSONResponse(
            status_code=exc.status_code,
            content=_error_body(code, detail, exc.status_code, retry_after=retry_after),
            headers=headers,  # Preserve Retry-After and other custom headers
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        """Handle Pydantic / request validation errors."""
        messages = []
        for err in exc.errors():
            loc = " -> ".join(str(part) for part in err.get("loc", []))
            msg = err.get("msg", "")
            messages.append(f"{loc}: {msg}" if loc else msg)
        detail = "; ".join(messages) if messages else "Validation error"
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content=_error_body("VALIDATION_ERROR", detail, 422, retry_after=None),
        )

    @app.exception_handler(ValueError)
    async def value_error_handler(request: Request, exc: ValueError):
        """Map ValueError to 400 Bad Request."""
        detail = _safe_detail(exc, generic="Invalid request")
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content=_error_body("BAD_REQUEST", detail, 400, retry_after=None),
        )

    # Security layer input validation (SQL/prompt injection, etc.)
    from narrative_ai.security.input_validation import ValidationError as SecurityValidationError

    @app.exception_handler(SecurityValidationError)
    async def security_validation_handler(request: Request, exc: SecurityValidationError):
        """Map security ValidationError to 400 Bad Request."""
        detail = getattr(exc, "message", str(exc)) or "Invalid input"
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content=_error_body("BAD_REQUEST", detail, 400, retry_after=None),
        )

    # Domain exceptions - map to HTTP status codes
    from narrative_ai.domain.exceptions import DomainException

    @app.exception_handler(DomainException)
    async def domain_exception_handler(request: Request, exc: DomainException):
        """Map domain exceptions to HTTP responses."""
        # Use instance message (e.g. EntryNotFoundError "Entry x not found") when available
        generic = getattr(exc, "detail_message", None) or getattr(exc, "message", str(exc))
        detail = _safe_detail(exc, generic=generic)
        return JSONResponse(
            status_code=exc.http_status,
            content=_error_body(exc.code, detail, exc.http_status, retry_after=None),
        )

    @app.exception_handler(PermissionError)
    async def permission_error_handler(request: Request, exc: PermissionError):
        """Map PermissionError to 403 Forbidden."""
        detail = _safe_detail(exc, generic="Permission denied")
        return JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content=_error_body("FORBIDDEN", detail, 403, retry_after=None),
        )

    @app.exception_handler(LookupError)
    async def lookup_error_handler(request: Request, exc: LookupError):
        """Map LookupError / KeyError to 404 Not Found."""
        detail = _safe_detail(exc, generic="Resource not found")
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content=_error_body("NOT_FOUND", detail, 404, retry_after=None),
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception):
        """Catch-all: log the error, return generic 500."""
        logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=_error_body(
                "INTERNAL_SERVER_ERROR",
                "An unexpected error occurred",
                500,
                retry_after=None,
            ),
        )
