"""Rate limiting middleware using Redis sliding-window counters.

Applies per-IP rate limiting by default.  Authenticated requests are limited
per user ID instead (set by JwtUserIdMiddleware from the Bearer token).

Environment variables
---------------------
RATE_LIMIT_REQUESTS : int
    Maximum requests per window (default 100).
RATE_LIMIT_WINDOW_SECONDS : int
    Window duration in seconds (default 60).
REDIS_URL : str
    Redis connection URL. When unset, rate limiting is disabled in development;
    in production, if Redis is unavailable this middleware returns 503 (fail closed).

Operational note: Rate limiting is *strict* (fail closed in production when
Redis is down). The application cache (infrastructure.cache) is best-effort
(fail open with in-memory fallback). Keep Redis healthy for rate limiting.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import Optional

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

logger = logging.getLogger(__name__)

# Defaults (overridable via env)
_DEFAULT_MAX_REQUESTS = 100
_DEFAULT_WINDOW_SECONDS = 60

# Lazy-initialised Redis connection
_redis_client: Optional[object] = None
_redis_init_attempted: bool = False
_redis_init_lock: asyncio.Lock | None = None


async def _get_redis():
    """Return an async Redis client or *None* if Redis is unavailable."""
    global _redis_client, _redis_init_attempted, _redis_init_lock
    if _redis_init_attempted:
        return _redis_client

    if _redis_init_lock is None:
        _redis_init_lock = asyncio.Lock()
    async with _redis_init_lock:
        if _redis_init_attempted:
            return _redis_client
        _redis_init_attempted = True

        redis_url = os.getenv("REDIS_URL", "")
        if not redis_url:
            logger.info("REDIS_URL not set -- rate limiting disabled.")
            return None

        try:
            import redis.asyncio as redis_lib

            _redis_client = redis_lib.from_url(
                redis_url,
                decode_responses=True,
                socket_connect_timeout=2,
                socket_timeout=2,
            )
            # Quick connectivity check
            await _redis_client.ping()
            logger.info("Rate limiter connected to Redis.")
        except Exception as exc:
            logger.warning("Could not connect to Redis for rate limiting: %s", exc)
            _redis_client = None

    return _redis_client


def _rate_limit_key(request: Request) -> str:
    """Build a rate-limit key from user ID or client IP."""
    # Prefer user ID if the request has been authenticated
    user_id = None
    if hasattr(request.state, "user_id"):
        user_id = request.state.user_id
    if user_id:
        return f"rl:user:{user_id}"
    # Fallback to client IP
    client_ip = request.client.host if request.client else "unknown"
    return f"rl:ip:{client_ip}"


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Sliding-window rate limiter backed by Redis."""

    def __init__(self, app, max_requests: int = 0, window_seconds: int = 0):
        super().__init__(app)
        self.max_requests = max_requests or int(os.getenv("RATE_LIMIT_REQUESTS", str(_DEFAULT_MAX_REQUESTS)))
        self.window_seconds = window_seconds or int(
            os.getenv("RATE_LIMIT_WINDOW_SECONDS", str(_DEFAULT_WINDOW_SECONDS))
        )

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        r = await _get_redis()
        if r is None:
            # Redis unavailable -- fail closed in production, warn in dev
            if os.getenv("ENV", "development") == "production":
                return JSONResponse(
                    status_code=503,
                    content={"detail": "Rate limiting service unavailable. Try again later."},
                )
            return await call_next(request)

        key = _rate_limit_key(request)
        now = time.time()
        window_start = now - self.window_seconds

        try:
            pipe = r.pipeline(transaction=True)
            # Remove expired entries from the sorted set
            pipe.zremrangebyscore(key, 0, window_start)
            # Count remaining entries (requests in window)
            pipe.zcard(key)
            # Add the current request timestamp
            pipe.zadd(key, {str(now): now})
            # Set TTL so the key self-cleans
            pipe.expire(key, self.window_seconds + 1)
            results = await pipe.execute()

            request_count = results[1]  # zcard result
        except Exception as exc:
            logger.warning("Rate limiter Redis error (allowing request): %s", exc)
            return await call_next(request)

        # Attach rate limit headers
        remaining = max(0, self.max_requests - request_count - 1)

        if request_count >= self.max_requests:
            retry_after = int(self.window_seconds - (now - window_start))
            return JSONResponse(
                status_code=429,
                content={
                    "detail": "Too many requests. Please try again later.",
                    "retry_after_seconds": max(1, retry_after),
                },
                headers={
                    "Retry-After": str(max(1, retry_after)),
                    "X-RateLimit-Limit": str(self.max_requests),
                    "X-RateLimit-Remaining": "0",
                    "X-RateLimit-Reset": str(int(now + max(1, retry_after))),
                },
            )

        response = await call_next(request)

        # Inform client of their rate limit status
        response.headers["X-RateLimit-Limit"] = str(self.max_requests)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Reset"] = str(int(now + self.window_seconds))

        return response
