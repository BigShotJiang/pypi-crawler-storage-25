"""Authentication middleware -- FastAPI dependency for JWT-based auth.

Usage in a route::

    from narrative_ai.api.middleware.auth import get_current_user

    @router.get("/protected")
    async def protected(current_user: dict = Depends(get_current_user)):
        user_id = current_user["user_id"]
        ...
"""

from __future__ import annotations

from fastapi import Depends, Query, Request, status
from fastapi.security import OAuth2PasswordBearer

import jwt as pyjwt

from narrative_ai.api.http_helpers import http_error
from narrative_ai.infrastructure.security.jwt_service import decode_token

# The tokenUrl is used by Swagger UI "Authorize" - it POSTs form data (username, password).
# We use /api/auth/token for OAuth2 compatibility; /api/auth/login accepts JSON.
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/token")


_AUTH_HEADERS = {"WWW-Authenticate": "Bearer"}


def _decode_and_validate_token(token: str) -> dict:
    """Validate JWT and return user claims. Raises HTTPException on failure."""
    payload = decode_token(token)
    if payload.get("type") != "access":
        raise http_error(
            status.HTTP_401_UNAUTHORIZED,
            "INVALID_CREDENTIALS",
            "Could not validate credentials",
            headers=_AUTH_HEADERS,
        )
    user_id = payload.get("sub")
    if user_id is None:
        raise http_error(
            status.HTTP_401_UNAUTHORIZED,
            "INVALID_CREDENTIALS",
            "Could not validate credentials",
            headers=_AUTH_HEADERS,
        )
    return {
        "user_id": user_id,
        "email": payload.get("email", ""),
        "role": payload.get("role", "user"),
    }


async def get_current_user_or_token_query(
    request: Request,
    token_query: str | None = Query(None, alias="token"),
) -> dict:
    """Authenticate via Bearer header or optional 'token' query param (e.g. for Image src in mobile)."""
    auth_header = request.headers.get("Authorization")
    token = None
    if auth_header and auth_header.startswith("Bearer "):
        token = auth_header[7:].strip()
    if not token and token_query:
        token = token_query
    if not token:
        raise http_error(
            status.HTTP_401_UNAUTHORIZED,
            "INVALID_CREDENTIALS",
            "Could not validate credentials",
            headers=_AUTH_HEADERS,
        )
    try:
        return _decode_and_validate_token(token)
    except pyjwt.ExpiredSignatureError:
        raise http_error(
            status.HTTP_401_UNAUTHORIZED,
            "TOKEN_EXPIRED",
            "Token has expired",
            headers=_AUTH_HEADERS,
        )
    except pyjwt.InvalidTokenError:
        raise http_error(
            status.HTTP_401_UNAUTHORIZED,
            "INVALID_CREDENTIALS",
            "Could not validate credentials",
            headers=_AUTH_HEADERS,
        )


async def get_current_user(token: str = Depends(oauth2_scheme)) -> dict:
    """Decode a Bearer token and return the user claims.

    Returns a dict with keys: ``user_id``, ``email``, ``role``.

    Raises :class:`HTTPException` (401) on invalid / expired / missing token.
    """
    creds_exc = http_error(
        status.HTTP_401_UNAUTHORIZED,
        "INVALID_CREDENTIALS",
        "Could not validate credentials",
        headers=_AUTH_HEADERS,
    )
    try:
        payload = decode_token(token)
    except pyjwt.ExpiredSignatureError:
        raise http_error(
            status.HTTP_401_UNAUTHORIZED,
            "TOKEN_EXPIRED",
            "Token has expired",
            headers=_AUTH_HEADERS,
        )
    except pyjwt.InvalidTokenError:
        raise creds_exc

    # Ensure this is an access token, not a refresh token
    if payload.get("type") != "access":
        raise creds_exc

    user_id: str | None = payload.get("sub")
    if user_id is None:
        raise creds_exc

    return {
        "user_id": user_id,
        "email": payload.get("email", ""),
        "role": payload.get("role", "user"),
    }
