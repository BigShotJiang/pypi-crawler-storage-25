from __future__ import annotations

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Add common security headers to all responses.

    These are safe defaults for APIs and SPAs when served over HTTPS.
    CSP is intentionally omitted here because it is highly app-specific;
    you can add it at the ingress/proxy layer if needed.
    """

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        response = await call_next(request)

        # Enforce HTTPS (only meaningful when deployed behind HTTPS)
        response.headers.setdefault("Strict-Transport-Security", "max-age=63072000; includeSubDomains; preload")
        # Mitigate MIME-type sniffing
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        # Prevent clickjacking by disallowing framing
        response.headers.setdefault("X-Frame-Options", "DENY")
        # Basic XSS protection hint (still useful for older UAs)
        response.headers.setdefault("X-XSS-Protection", "1; mode=block")
        # Limit referrer information
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")

        return response
