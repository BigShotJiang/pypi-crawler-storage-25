"""Correlation ID middleware for distributed tracing.

Attaches a unique ``X-Correlation-ID`` header to every request and response.
If the client already provides one, it is reused; otherwise a new UUID is
generated.  The ID is stored in the request state so that downstream handlers,
loggers, and error handlers can include it.

Usage::

    from narrative_ai.api.middleware.correlation_id import get_correlation_id

    @router.get("/example")
    async def example(request: Request):
        cid = get_correlation_id(request)
        ...
"""

from __future__ import annotations

import re
import uuid
import logging

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger(__name__)

HEADER_NAME = "X-Correlation-ID"

# Only allow safe characters (alphanumeric, hyphens, underscores), max 64 chars
_SAFE_CID_PATTERN = re.compile(r"^[a-zA-Z0-9\-_]{1,64}$")


def get_correlation_id(request: Request) -> str:
    """Return the correlation ID attached to *request* (or empty string)."""
    return getattr(request.state, "correlation_id", "")


class CorrelationIdMiddleware(BaseHTTPMiddleware):
    """Inject a correlation ID into every request/response cycle."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # Reuse client-supplied ID only if it matches the safe pattern
        raw = request.headers.get(HEADER_NAME, "")
        if raw and _SAFE_CID_PATTERN.match(raw):
            correlation_id = raw
        else:
            correlation_id = str(uuid.uuid4())

        # Attach to request.state for downstream access
        request.state.correlation_id = correlation_id

        response = await call_next(request)

        # Echo back to the client
        response.headers[HEADER_NAME] = correlation_id

        return response
