"""Optional JWT parsing middleware to set request.state.user_id for rate limiting.

Runs before the rate limit middleware. If the request has a valid Bearer access token,
decodes it (without raising 401) and sets request.state.user_id so the rate limiter
can apply per-user limits instead of per-IP. Unauthenticated or invalid tokens leave
user_id unset; the rate limiter then uses client IP.
"""

from __future__ import annotations

import logging
from typing import Callable

import jwt as pyjwt
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger(__name__)


async def _optional_user_id_from_request(request: Request) -> str | None:
    """Extract user_id from Bearer JWT if present and valid. No 401 on failure."""
    auth = request.headers.get("Authorization")
    if not auth or not auth.startswith("Bearer "):
        return None
    token = auth[7:].strip()
    if not token:
        return None
    try:
        from narrative_ai.infrastructure.security.jwt_service import decode_token

        payload = decode_token(token)
        if payload.get("type") != "access":
            return None
        user_id = payload.get("sub")
        return str(user_id) if user_id is not None else None
    except (pyjwt.ExpiredSignatureError, pyjwt.InvalidTokenError, Exception):
        return None


class JwtUserIdMiddleware(BaseHTTPMiddleware):
    """Set request.state.user_id from valid Bearer access token for rate limiting."""

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        user_id = await _optional_user_id_from_request(request)
        if user_id is not None:
            request.state.user_id = user_id
        return await call_next(request)
