"""OCR extract API routes.

Dedicated endpoint for single-image text extraction (Scan flow).
Uses narrative_ai.engines.ocr ocr_async so sync OCR never blocks the event loop.
Registered when ingestion engine is loaded.
"""

from __future__ import annotations

import logging
import os
from typing import Literal

from fastapi import APIRouter, File, Form, UploadFile

from narrative_ai.api.http_helpers import http_error

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/ocr", tags=["ocr"])

MAX_FILE_SIZE_BYTES = 20 * 1024 * 1024  # 20MB
ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/png", "image/webp", "image/jpg"}
# Fallback when client does not send Content-Type (e.g. some React Native FormData)
EXT_TO_CONTENT_TYPE = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
}


def _mode_to_kwargs(mode: str) -> dict:
    """Map mode to OCRPipeline.process kwargs."""
    if mode == "handwritten":
        return {"dewarping": True, "shadow_removal": True}
    if mode == "document":
        return {"binarization": True}
    return {}


@router.post("/extract")
async def extract_text(
    file: UploadFile = File(..., description="Image file to extract text from"),
    mode: Literal["default", "handwritten", "document"] = Form("default"),
):
    """
    Extract text from a single image (OCR). For Scan flow: camera or gallery image.

    - **file**: Image (JPEG, PNG, WebP). Max 20MB.
    - **mode**: `default` (fast, no preprocessing), `handwritten` (dewarp + deshadow),
      `document` (binarize). Default: `default`.

    Returns `{ "text": "..." }`. Empty string if no text extracted.
    """
    content_type = (file.content_type or "").lower().strip()
    if content_type not in ALLOWED_CONTENT_TYPES:
        # Infer from filename for clients that do not set Content-Type (e.g. React Native FormData)
        ext = os.path.splitext(file.filename or "")[1].lower()
        content_type = EXT_TO_CONTENT_TYPE.get(ext, "")
    if content_type not in ALLOWED_CONTENT_TYPES:
        raise http_error(400, "INVALID_FILE_TYPE", "File must be image/jpeg, image/png, or image/webp")

    payload = await file.read()
    if not payload:
        raise http_error(400, "EMPTY_FILE", "Image file is empty")
    if len(payload) > MAX_FILE_SIZE_BYTES:
        raise http_error(413, "FILE_TOO_LARGE", "Image must be at most 20MB")

    kwargs = _mode_to_kwargs(mode)
    filename = file.filename or "image.jpg"
    if not any(filename.lower().endswith(e) for e in (".jpg", ".jpeg", ".png", ".webp")):
        filename = filename.rsplit(".", 1)[0] + (".png" if content_type == "image/png" else ".jpg")

    try:
        from narrative_ai.engines.ocr.core.api import ocr_async

        text = await ocr_async(payload, filename=filename, **kwargs)
        # Remote provider can return "Error: ..." as text; surface it to the client
        if text and text.strip().startswith("Error:"):
            msg = text.strip()
            logger.warning("OCR returned error: %s", msg)
            raise http_error(503, "OCR_FAILED", msg) from None
        return {"text": text or ""}
    except Exception as e:
        logger.exception("OCR extract failed: %s", e)
        msg = str(e).strip() or "Text extraction failed"
        logger.error("OCR returning 503 to client: %s", msg)
        raise http_error(503, "OCR_FAILED", msg) from e
