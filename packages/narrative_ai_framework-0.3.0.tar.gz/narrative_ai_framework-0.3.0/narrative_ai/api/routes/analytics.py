"""Analytics API routes.

- GET  /api/analytics       -- returns 404 until dashboard is ready (coming soon).
- POST /api/analytics/events -- accept client analytics events (e.g. notification reminder_shown, reminder_tapped).
"""

from __future__ import annotations

import logging
import uuid
from typing import Any, Optional

from fastapi import APIRouter, Depends, status
from pydantic import BaseModel, Field

from narrative_ai.api.dependencies import get_analytics_event_repo, get_current_user
from narrative_ai.api.http_helpers import http_error
from narrative_ai.infrastructure.database.repositories.analytics_event_repository_impl import (
    PostgresAnalyticsEventRepository,
)

logger = logging.getLogger(__name__)

# Allowed event types from the mobile app (notification analytics).
ALLOWED_EVENT_TYPES = frozenset(
    {
        "reminder_scheduled",
        "reminder_cancelled",
        "reminder_shown",
        "reminder_tapped",
    }
)

MAX_EVENTS_PER_REQUEST = 500

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


class EventItem(BaseModel):
    """Single event from the client (mobile app)."""

    id: str = Field(..., min_length=1, max_length=128, description="Client-generated event id")
    type: str = Field(..., min_length=1, max_length=64, description="Event type")
    timestamp: str = Field(..., max_length=64, description="ISO timestamp from client")
    payload: Optional[dict[str, Any]] = None


class EventsRequest(BaseModel):
    """Body for POST /api/analytics/events."""

    events: list[EventItem] = Field(..., min_length=0, max_length=MAX_EVENTS_PER_REQUEST)


class EventsResponse(BaseModel):
    """Response after accepting events."""

    accepted: int


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("", status_code=501)
async def analytics_not_implemented():
    """
    Analytics dashboard is not implemented yet (coming soon).

    For now this is a stub endpoint that returns 501 NOT_IMPLEMENTED so clients
    and tests can detect that analytics dashboard is not yet wired. Event ingestion
    is available via POST /api/analytics/events.
    """
    return {
        "code": "NOT_IMPLEMENTED",
        "message": "Analytics dashboard is not implemented yet. Use POST /api/analytics/events to send events.",
    }


@router.post(
    "/events",
    response_model=EventsResponse,
    status_code=status.HTTP_200_OK,
    summary="Send analytics events",
    description="Accepts a batch of client analytics events (e.g. notification reminder shown/tapped). Requires auth.",
)
async def post_events(
    body: EventsRequest,
    current_user: dict = Depends(get_current_user),
    repo: PostgresAnalyticsEventRepository = Depends(get_analytics_event_repo),
) -> EventsResponse:
    """Ingest analytics events from the mobile app. Invalid or disallowed event types are skipped."""
    user_id_str = current_user.get("user_id")
    if not user_id_str:
        raise http_error(status.HTTP_401_UNAUTHORIZED, "UNAUTHORIZED", "Could not validate credentials")
    try:
        user_id = uuid.UUID(str(user_id_str))
    except (ValueError, TypeError):
        raise http_error(status.HTTP_401_UNAUTHORIZED, "INVALID_TOKEN", "Invalid token")

    # Normalize and filter: only allowed types, build metadata from client fields
    to_insert: list[dict[str, Any]] = []
    for ev in body.events:
        if ev.type not in ALLOWED_EVENT_TYPES:
            logger.debug("Skipping disallowed analytics event type: %s", ev.type)
            continue
        metadata: dict[str, Any] = {
            "client_id": ev.id,
            "client_timestamp": ev.timestamp,
        }
        if ev.payload:
            # Limit payload keys to avoid huge JSONB; keep it small
            for k, v in list(ev.payload.items())[:20]:
                if isinstance(k, str) and len(k) <= 64:
                    metadata[k] = v
        to_insert.append({"event_type": ev.type, "metadata": metadata})

    if not to_insert:
        return EventsResponse(accepted=0)

    try:
        count = await repo.add_events(user_id, to_insert)
        # Session is committed by get_db when the request completes successfully
    except Exception as e:
        logger.exception("Failed to persist analytics events: %s", e)
        raise http_error(
            status.HTTP_503_SERVICE_UNAVAILABLE,
            "ANALYTICS_SAVE_FAILED",
            "Failed to save analytics events. Please try again.",
        ) from e

    return EventsResponse(accepted=count)
