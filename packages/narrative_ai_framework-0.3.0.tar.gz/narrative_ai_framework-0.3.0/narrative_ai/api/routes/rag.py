"""RAG memory API routes."""

from __future__ import annotations

import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, Header, Path
from pydantic import BaseModel, Field

from narrative_ai.api.dependencies import get_rag_service, get_user_tenant
from narrative_ai.api.http_helpers import http_error
from narrative_ai.application.dto.rag_dto import RecallQuery, RememberCommand
from narrative_ai.application.services.rag_service import RAGAppService
from narrative_ai.engines.input_processor.types import StructuredDocument

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/rag", tags=["rag"])


class RememberRequest(BaseModel):
    """Request body for indexing a structured document."""

    document: dict[str, Any]
    doc_id: Optional[str] = None
    # Deprecated on public API: user/tenant are derived from JWT.
    user_id: Optional[str] = None
    tenant_id: Optional[str] = None


class RememberResponse(BaseModel):
    """Response body for remember endpoint."""

    doc_id: str
    chunks_indexed: int
    success: bool
    errors: list[str] = Field(default_factory=list)
    correlation_id: str = ""


class RecallRequest(BaseModel):
    """Request body for recall endpoint."""

    query: str = Field(..., min_length=1, max_length=5000)
    top_k: int = Field(default=5, ge=1, le=100)
    filters: Optional[dict[str, Any]] = None
    return_context: bool = True
    # Deprecated on public API: user/tenant are derived from JWT.
    user_id: Optional[str] = None
    tenant_id: Optional[str] = None


class RecallResult(BaseModel):
    """Single recall result."""

    text: str
    score: float
    modality: str
    media_ref: Optional[str] = None
    page: Optional[int] = None
    doc_id: str
    block_id: str


class RecallResponse(BaseModel):
    """Response body for recall endpoint."""

    query: str
    formatted_text: str
    media_references: list[str]
    results: list[RecallResult]
    strategy_used: str
    total_retrieved: int
    correlation_id: str = ""


class ForgetResponse(BaseModel):
    """Response body for forget endpoint."""

    doc_id: str
    success: bool
    correlation_id: str = ""


@router.post("/remember", response_model=RememberResponse)
async def remember(
    request: RememberRequest,
    service: RAGAppService = Depends(get_rag_service),
    user_tenant: tuple[str, Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """Index a structured document into vector memory."""
    user_id, tenant_id = user_tenant
    try:
        document = StructuredDocument.from_dict(request.document)
    except Exception as exc:
        raise http_error(422, "INVALID_DOCUMENT", f"Invalid structured document payload: {exc}") from exc

    try:
        result = await service.remember(
            RememberCommand(
                document=document,
                doc_id=request.doc_id,
                user_id=user_id,
                tenant_id=tenant_id,
                correlation_id=correlation_id,
            )
        )
        return RememberResponse(
            doc_id=result.doc_id,
            chunks_indexed=result.chunks_indexed,
            success=result.success,
            errors=result.errors,
            correlation_id=correlation_id or "",
        )
    except ValueError as exc:
        raise http_error(400, "BAD_REQUEST", str(exc)) from exc
    except RuntimeError as exc:
        raise http_error(503, "RAG_UNAVAILABLE", str(exc)) from exc
    except Exception as exc:
        logger.error("RAG remember failed: %s", exc, exc_info=True)
        raise http_error(500, "RAG_REMEMBER_FAILED", "Failed to index document") from exc


@router.post("/recall", response_model=RecallResponse)
async def recall(
    request: RecallRequest,
    service: RAGAppService = Depends(get_rag_service),
    user_tenant: tuple[str, Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """Query memory and return ranked contextual results."""
    user_id, tenant_id = user_tenant
    try:
        result = await service.recall(
            RecallQuery(
                query=request.query,
                top_k=request.top_k,
                filters=request.filters,
                return_context=request.return_context,
                user_id=user_id,
                tenant_id=tenant_id,
                correlation_id=correlation_id,
            )
        )
        return RecallResponse(
            query=result.query,
            formatted_text=result.formatted_text,
            media_references=result.media_references,
            results=[
                RecallResult(
                    text=item.text,
                    score=item.score,
                    modality=item.modality,
                    media_ref=item.media_ref,
                    page=item.page,
                    doc_id=item.doc_id,
                    block_id=item.block_id,
                )
                for item in result.results
            ],
            strategy_used=result.strategy_used,
            total_retrieved=result.total_retrieved,
            correlation_id=correlation_id or "",
        )
    except ValueError as exc:
        raise http_error(400, "BAD_REQUEST", str(exc)) from exc
    except RuntimeError as exc:
        raise http_error(503, "RAG_UNAVAILABLE", str(exc)) from exc
    except Exception as exc:
        logger.error("RAG recall failed: %s", exc, exc_info=True)
        raise http_error(500, "RAG_RECALL_FAILED", "Failed to retrieve context") from exc


@router.delete("/forget/{doc_id}", response_model=ForgetResponse)
async def forget(
    doc_id: str = Path(..., min_length=1),
    service: RAGAppService = Depends(get_rag_service),
    user_tenant: tuple[str, Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """Delete all vector-memory chunks for a document."""
    user_id, _ = user_tenant
    try:
        removed = await service.forget(doc_id, user_id=user_id)
    except ValueError as exc:
        raise http_error(400, "BAD_REQUEST", str(exc)) from exc
    except RuntimeError as exc:
        raise http_error(503, "RAG_UNAVAILABLE", str(exc)) from exc
    except Exception as exc:
        logger.error("RAG forget failed: %s", exc, exc_info=True)
        raise http_error(500, "RAG_FORGET_FAILED", "Failed to remove document from memory") from exc

    if not removed:
        raise http_error(404, "DOCUMENT_NOT_FOUND", "Document was not found in memory")
    return ForgetResponse(doc_id=doc_id, success=True, correlation_id=correlation_id or "")


@router.get("/status")
async def status(service: RAGAppService = Depends(get_rag_service)):
    """RAG service status endpoint."""
    try:
        return await service.status()
    except Exception as exc:
        logger.error("RAG status failed: %s", exc, exc_info=True)
        return {"status": "unhealthy", "error": str(exc)}
