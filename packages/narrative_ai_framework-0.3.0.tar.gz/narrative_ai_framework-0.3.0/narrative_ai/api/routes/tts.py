"""
TTS API Routes.

FastAPI routes for Text-to-Speech endpoints.
Supports batch synthesis, streaming, voice listing, and provider management.

Endpoints:
- POST /api/tts/synthesize - Synthesize speech from text
- POST /api/tts/synthesize/stream - Streaming audio synthesis
- GET /api/tts/voices - List available voices
- GET /api/tts/providers - List available TTS providers
- GET /api/tts/status - Health check endpoint
"""

import logging
from typing import List, Optional

from fastapi import APIRouter, Depends, Header, HTTPException

from narrative_ai.api.http_helpers import http_error
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel, Field

from narrative_ai.api.dependencies import get_tts_engine, get_user_tenant
from narrative_ai.engines.tts import Emotion, TTSEngine, TTSResult

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/tts", tags=["tts"])


# =============================================================================
# Request/Response Models
# =============================================================================


class SynthesizeRequest(BaseModel):
    """Request model for TTS synthesis."""

    text: str = Field(..., min_length=1, max_length=10000, description="Text to synthesize")
    voice_id: Optional[str] = Field(None, description="Voice ID (provider-specific)")
    language: Optional[str] = Field(None, description="Language code (en, ar, etc.)")
    emotion: Optional[str] = Field(None, description="Emotion: happy, sad, calm, angry, excited, neutral, empathetic")
    output_format: str = Field("mp3_44100_128", description="Audio output format")
    provider: Optional[str] = Field(None, description="Force specific provider (elevenlabs, openai)")


class SynthesizeMetadata(BaseModel):
    """Metadata returned alongside audio (in headers or JSON mode)."""

    provider: str
    voice_id: str = ""
    processing_time: float
    duration: Optional[float] = None
    format: str
    sample_rate: int
    text_length: int
    emotion: Optional[str] = None
    correlation_id: str = ""


class VoiceInfoResponse(BaseModel):
    """Voice information response."""

    voice_id: str
    name: str
    provider: str
    language: Optional[str] = None
    gender: Optional[str] = None
    description: Optional[str] = None


class ProviderInfo(BaseModel):
    """TTS provider information."""

    name: str
    available: bool
    models: List[str] = []
    features: List[str] = []


# =============================================================================
# Routes (engine and user_tenant from narrative_ai.api.dependencies)
# =============================================================================


@router.post("/synthesize")
async def synthesize(
    request: SynthesizeRequest,
    engine: Optional[TTSEngine] = Depends(get_tts_engine),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
    accept: Optional[str] = Header("audio/mpeg", alias="Accept"),
):
    """
    Synthesize speech from text.

    Returns the audio file directly with metadata in response headers.
    Set Accept header to 'application/json' to get metadata only (no audio).
    """
    if engine is None:
        raise http_error(503, "TTS_UNAVAILABLE", "TTS service temporarily unavailable")
    user_id, tenant_id = user_tenant

    try:
        # Parse emotion
        emotion = None
        if request.emotion:
            try:
                emotion = Emotion(request.emotion)
            except ValueError:
                emotion = request.emotion  # Pass as string, engine handles it

        result: TTSResult = await engine.synthesize(
            text=request.text,
            voice_id=request.voice_id,
            language=request.language,
            emotion=emotion,
            output_format=request.output_format,
            provider=request.provider,
            user_id=user_id,
            tenant_id=tenant_id,
            correlation_id=correlation_id,
        )

        # Determine content type from format
        format_str = getattr(result, "format", "mp3") or "mp3"
        content_type_map = {
            "mp3": "audio/mpeg",
            "wav": "audio/wav",
            "pcm": "audio/pcm",
            "ogg": "audio/ogg",
            "flac": "audio/flac",
            "opus": "audio/opus",
        }
        # Handle compound format strings like "mp3_44100_128"
        base_format = format_str.split("_")[0] if "_" in format_str else format_str
        content_type = content_type_map.get(base_format, "application/octet-stream")

        # If client wants JSON metadata instead of audio
        if accept and "application/json" in accept:
            return SynthesizeMetadata(
                provider=result.provider or "",
                voice_id=result.voice_id or "",
                processing_time=result.processing_time,
                duration=result.duration,
                format=format_str,
                sample_rate=result.sample_rate or 44100,
                text_length=result.text_length or len(request.text),
                emotion=result.emotion.value
                if hasattr(result.emotion, "value")
                else str(result.emotion)
                if result.emotion
                else None,
                correlation_id=correlation_id or "",
            )

        # Return audio with metadata in headers
        headers = {
            "X-Provider": result.provider or "",
            "X-Voice-ID": result.voice_id or "",
            "X-Processing-Time": str(result.processing_time),
            "X-Audio-Duration": str(result.duration or ""),
            "X-Audio-Format": format_str,
            "Content-Disposition": f'attachment; filename="speech.{base_format}"',
        }

        return Response(
            content=result.audio,
            media_type=content_type,
            headers=headers,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Synthesis failed: {e}", exc_info=True)
        raise http_error(500, "TTS_ERROR", str(e))


@router.post("/synthesize/stream")
async def synthesize_stream(
    request: SynthesizeRequest,
    engine: Optional[TTSEngine] = Depends(get_tts_engine),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """
    Stream synthesized audio in chunks.

    Returns audio data as a chunked response for real-time playback.
    """
    if engine is None:
        raise http_error(503, "TTS_UNAVAILABLE", "TTS service temporarily unavailable")
    user_id, tenant_id = user_tenant

    # Parse emotion
    emotion = None
    if request.emotion:
        try:
            emotion = Emotion(request.emotion)
        except ValueError:
            emotion = request.emotion

    # Prefer PCM for streaming
    output_format = request.output_format
    if output_format.startswith("mp3"):
        output_format = "pcm_24000"

    async def audio_stream():
        try:
            async for chunk in engine.synthesize_streaming(
                text=request.text,
                voice_id=request.voice_id,
                language=request.language,
                emotion=emotion,
                output_format=output_format,
                provider=request.provider,
                user_id=user_id,
                tenant_id=tenant_id,
            ):
                # chunk may be a StreamingChunk with .audio or raw bytes
                audio_data = getattr(chunk, "audio", chunk)
                if isinstance(audio_data, (bytes, bytearray)):
                    yield audio_data

        except Exception as e:
            logger.error(f"Streaming synthesis failed: {e}", exc_info=True)

    return StreamingResponse(
        audio_stream(),
        media_type="audio/pcm",
        headers={
            "X-Audio-Format": output_format,
            "Transfer-Encoding": "chunked",
        },
    )


@router.get("/voices", response_model=List[VoiceInfoResponse])
async def list_voices(
    provider: Optional[str] = None,
    engine: Optional[TTSEngine] = Depends(get_tts_engine),
):
    """List available voices, optionally filtered by provider."""
    if engine is None:
        raise http_error(503, "TTS_UNAVAILABLE", "TTS service temporarily unavailable")
    try:
        voices_dict = await engine.get_voices(provider=provider)

        result = []
        for prov_name, voices in voices_dict.items():
            for voice in voices:
                result.append(
                    VoiceInfoResponse(
                        voice_id=getattr(voice, "voice_id", "") or getattr(voice, "id", ""),
                        name=getattr(voice, "name", "unknown"),
                        provider=prov_name,
                        language=getattr(voice, "language", None),
                        gender=getattr(voice, "gender", None),
                        description=getattr(voice, "description", None),
                    )
                )

        return result

    except Exception as e:
        logger.error(f"Failed to list voices: {e}", exc_info=True)
        raise http_error(500, "TTS_ERROR", str(e))


@router.get("/providers", response_model=List[ProviderInfo])
async def list_providers(
    engine: Optional[TTSEngine] = Depends(get_tts_engine),
):
    """List all available TTS providers."""
    if engine is None:
        raise http_error(503, "TTS_UNAVAILABLE", "TTS service temporarily unavailable")
    try:
        health = await engine.health_check()
        strategy_health = health.get("strategy", {})
        providers_health = strategy_health.get("providers", {})

        providers = []
        for name, provider_info in providers_health.items():
            providers.append(
                ProviderInfo(
                    name=name,
                    available=provider_info.get("available", False),
                    models=[provider_info.get("model", "unknown")] if provider_info.get("model") else [],
                    features=provider_info.get("supported_features", []),
                )
            )

        return providers

    except Exception as e:
        logger.error(f"Failed to list providers: {e}", exc_info=True)
        raise http_error(500, "TTS_ERROR", str(e))


@router.get("/status")
async def status(
    engine: Optional[TTSEngine] = Depends(get_tts_engine),
):
    """Health check endpoint."""
    if engine is None:
        raise http_error(503, "TTS_UNAVAILABLE", "TTS service temporarily unavailable")
    try:
        health = await engine.health_check()
        metrics = await engine.get_metrics()

        return {
            "status": "healthy" if health.get("engine", {}).get("initialized") else "unhealthy",
            "health": health,
            "metrics": metrics,
        }

    except Exception as e:
        logger.error(f"Health check failed: {e}", exc_info=True)
        return {
            "status": "unhealthy",
            "error": str(e),
        }
