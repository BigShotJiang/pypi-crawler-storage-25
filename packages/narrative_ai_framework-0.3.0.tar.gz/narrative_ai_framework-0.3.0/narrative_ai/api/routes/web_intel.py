"""Web Intelligence API routes."""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from narrative_ai.api.dependencies import get_user_tenant, get_web_engine
from narrative_ai.api.http_helpers import http_error

router = APIRouter(prefix="/api/web-intel", tags=["web-intel"])


class WebSearchRequest(BaseModel):
    query: str = Field(..., min_length=1, description="Natural language web query")
    max_results: int = Field(5, ge=1, le=10)
    freshness: Optional[str] = Field(
        default=None,
        description="Optional freshness hint (e.g. day/week/month)",
    )


class WebSourceResponse(BaseModel):
    title: str
    url: str
    domain: str
    snippet: str
    published_at: Optional[str] = None
    retrieved_at: str
    score: float
    query: str


class WebSearchResponse(BaseModel):
    query: str
    sources: list[WebSourceResponse]
    latency_ms: float
    cache_hit: bool
    provider: str


@router.post("/search", response_model=WebSearchResponse)
async def web_search(
    request: WebSearchRequest,
    web_engine=Depends(get_web_engine),
    user_tenant: tuple[str, Optional[str]] = Depends(get_user_tenant),
):
    """Search the web and return normalized citations."""
    del user_tenant  # Reserved for audit/rate-limit enrichment.
    if web_engine is None:
        raise http_error(503, "WEB_INTEL_UNAVAILABLE", "Web intelligence service temporarily unavailable")
    result = await web_engine.search(
        request.query,
        max_results=request.max_results,
        freshness=request.freshness,
    )
    return WebSearchResponse(
        query=result.query,
        sources=[WebSourceResponse(**src.to_dict()) for src in result.sources],
        latency_ms=result.latency_ms,
        cache_hit=result.cache_hit,
        provider=result.provider,
    )


@router.get("/tools")
async def web_tools_descriptor(web_engine=Depends(get_web_engine)):
    """Return MCP-ready tool descriptor for external agent integration."""
    if web_engine is None:
        raise http_error(503, "WEB_INTEL_UNAVAILABLE", "Web intelligence service temporarily unavailable")
    return {
        "tools": [web_engine.get_tool_descriptor()],
        "notes": {
            "mode": web_engine.mode,
            "enabled": web_engine.enabled,
        },
    }
