"""Ingestion pipeline API routes."""

from __future__ import annotations

import asyncio
import logging
import os
import tempfile
import time
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, Depends, File, Form, Header, UploadFile
from pydantic import BaseModel, Field

from narrative_ai.api.dependencies import get_ingestion_service, get_user_tenant
from narrative_ai.api.http_helpers import http_error
from narrative_ai.application.dto.ingestion_dto import ProcessAudioCommand, ProcessCommand
from narrative_ai.application.services.ingestion_service import IngestionAppService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/ingestion", tags=["ingestion"])

MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024


class ProcessResponse(BaseModel):
    """Ingestion process response model."""

    document: dict[str, Any]
    processing_time_ms: int
    block_count: int
    errors: list[str] = Field(default_factory=list)
    correlation_id: str = ""


async def _write_temp_file(data: bytes, suffix: str) -> str:
    def _write() -> str:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp.write(data)
            return tmp.name

    return await asyncio.to_thread(_write)


@router.post("/process", response_model=ProcessResponse)
async def process_document(
    file: UploadFile = File(..., description="Document to process"),
    enable_image_processing: bool = Form(True),
    enable_audio_processing: bool = Form(True),
    service: IngestionAppService = Depends(get_ingestion_service),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """Upload and process a document source."""
    user_id, tenant_id = user_tenant
    payload = await file.read()
    if not payload:
        raise http_error(400, "EMPTY_FILE", "Uploaded file is empty")
    if len(payload) > MAX_FILE_SIZE_BYTES:
        raise http_error(413, "FILE_TOO_LARGE", "Uploaded file exceeds 100MB limit")

    suffix = Path(file.filename or "upload.bin").suffix or ".bin"
    temp_path = await _write_temp_file(payload, suffix=suffix)

    start = time.perf_counter()
    try:
        result = await service.process(
            ProcessCommand(
                source=temp_path,
                enable_image_processing=enable_image_processing,
                enable_audio_processing=enable_audio_processing,
                user_id=user_id,
                tenant_id=tenant_id,
                correlation_id=correlation_id,
            )
        )
        return ProcessResponse(
            document=result.document,
            processing_time_ms=int((time.perf_counter() - start) * 1000),
            block_count=result.block_count,
            errors=result.errors,
            correlation_id=correlation_id or "",
        )
    except ValueError as exc:
        raise http_error(400, "BAD_REQUEST", str(exc)) from exc
    except RuntimeError as exc:
        raise http_error(503, "INGESTION_FAILED", str(exc)) from exc
    except Exception as exc:
        logger.error("Ingestion document processing failed: %s", exc, exc_info=True)
        raise http_error(500, "INGESTION_PROCESS_FAILED", "Failed to process document") from exc
    finally:
        try:
            os.unlink(temp_path)
        except OSError:
            pass


@router.post("/process/audio", response_model=ProcessResponse)
async def process_audio(
    file: UploadFile | None = File(default=None, description="Audio/video file"),
    youtube_url: str | None = Form(default=None),
    language: str | None = Form(default=None),
    service: IngestionAppService = Depends(get_ingestion_service),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """Process audio/video upload or a YouTube URL."""
    user_id, tenant_id = user_tenant
    if file is None and not youtube_url:
        raise http_error(400, "MISSING_INPUT", "Provide either an uploaded file or youtube_url")
    if file is not None and youtube_url:
        raise http_error(400, "AMBIGUOUS_INPUT", "Provide only one of file or youtube_url")

    temp_path: str | None = None
    source: str
    if file is not None:
        payload = await file.read()
        if not payload:
            raise http_error(400, "EMPTY_FILE", "Uploaded file is empty")
        if len(payload) > MAX_FILE_SIZE_BYTES:
            raise http_error(413, "FILE_TOO_LARGE", "Uploaded file exceeds 100MB limit")
        suffix = Path(file.filename or "upload.bin").suffix or ".bin"
        temp_path = await _write_temp_file(payload, suffix=suffix)
        source = temp_path
    else:
        source = youtube_url or ""

    start = time.perf_counter()
    try:
        result = await service.process_audio(
            ProcessAudioCommand(
                source=source,
                language=language,
                user_id=user_id,
                tenant_id=tenant_id,
                correlation_id=correlation_id,
            )
        )
        return ProcessResponse(
            document=result.document,
            processing_time_ms=int((time.perf_counter() - start) * 1000),
            block_count=result.block_count,
            errors=result.errors,
            correlation_id=correlation_id or "",
        )
    except ValueError as exc:
        raise http_error(400, "BAD_REQUEST", str(exc)) from exc
    except RuntimeError as exc:
        raise http_error(503, "INGESTION_FAILED", str(exc)) from exc
    except Exception as exc:
        logger.error("Ingestion audio processing failed: %s", exc, exc_info=True)
        raise http_error(500, "INGESTION_AUDIO_FAILED", "Failed to process audio source") from exc
    finally:
        if temp_path:
            try:
                os.unlink(temp_path)
            except OSError:
                pass


@router.get("/status")
async def status(service: IngestionAppService = Depends(get_ingestion_service)):
    """Ingestion service status endpoint."""
    try:
        return await service.status()
    except Exception as exc:
        logger.error("Ingestion status failed: %s", exc, exc_info=True)
        return {"status": "unhealthy", "error": str(exc)}
