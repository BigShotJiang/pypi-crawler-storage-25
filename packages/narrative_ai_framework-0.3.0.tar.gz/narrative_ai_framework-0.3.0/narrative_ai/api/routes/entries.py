"""Diary entries CRUD routes and pipeline endpoints.

All endpoints are prefixed with ``/api/entries`` and require authentication.

Pipeline endpoints
------------------
- ``POST /from-voice``           -- audio -> STT -> entry
- ``POST /from-voice/enhanced``  -- audio -> STT -> entry -> LLM enhance + tags
- ``POST /from-text``            -- text  -> optional LLM emotion + enhance + tags
- ``PATCH /{id}/enhance``        -- run LLM enhancement on an existing entry
"""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from fastapi import (
    APIRouter,
    Depends,
    File,
    Form,
    Header,
    Query,
    UploadFile,
    status,
)

from narrative_ai.api.http_helpers import http_error
from narrative_ai.api.idempotency import get_idempotent_response, set_idempotent_response
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from narrative_ai.api.dependencies import (
    get_current_user,
    get_entry_media_repo,
    get_entry_repo,
    get_entry_service,
)
from narrative_ai.api.middleware.auth import get_current_user_or_token_query
from narrative_ai.application.services.entry_service import EntryService
from narrative_ai.domain.entities.diary_entry import DiaryEntry, SourceType
from narrative_ai.domain.exceptions import EntryNotFoundError
from narrative_ai.infrastructure.database.repositories.entry_media_repository_impl import (
    PostgresEntryMediaRepository,
)
from narrative_ai.infrastructure.database.repositories.entry_repository_impl import (
    PostgresEntryRepository,
)
from narrative_ai.security.input_validation import ValidationError as SecurityValidationError
from narrative_ai.security.input_validation import validate_text as security_validate_text

logger = logging.getLogger(__name__)

# Max length for security validation (must match Pydantic max_length for entries)
_ENTRY_TEXT_MAX_LENGTH = 50000

MEDIA_UPLOAD_DIR = os.getenv("MEDIA_UPLOAD_DIR", os.path.join(os.getcwd(), "uploads", "entry_media"))
ALLOWED_IMAGE_CONTENT_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif"}
MAX_MEDIA_FILE_BYTES = 10 * 1024 * 1024  # 10MB

router = APIRouter(prefix="/api/entries", tags=["entries"])


# ---------------------------------------------------------------------------
# Request / Response schemas
# ---------------------------------------------------------------------------


class CreateEntryRequest(BaseModel):
    raw_text: str = Field(..., min_length=1, max_length=50000)
    enhanced_text: str = Field(default="", max_length=50000)
    emotion: str = Field(default="neutral", max_length=32)
    source_type: str = Field(default="text", pattern=r"^(voice|text|image|file)$")
    tags: List[str] = Field(default_factory=list, max_length=20)


class UpdateEntryRequest(BaseModel):
    enhanced_text: Optional[str] = Field(default=None, max_length=50000)
    tags: Optional[List[str]] = Field(default=None, max_length=20)
    emotion: Optional[str] = Field(default=None, max_length=32)


class EntryMediaItem(BaseModel):
    id: str
    url: str
    caption: Optional[str] = None
    media_type: str


class EntryResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    user_id: str
    raw_text: str
    enhanced_text: str
    emotion: str
    source_type: str
    tags: List[str]
    audio_storage_path: Optional[str] = None
    created_at: str
    updated_at: Optional[str] = None
    media: Optional[List[EntryMediaItem]] = None


class EntryListResponse(BaseModel):
    entries: List[EntryResponse]
    total: int
    offset: int
    limit: int


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _preprocess_audio(audio_bytes: bytes) -> tuple[bytes, int]:
    """Convert audio bytes to PCM and sample rate for STT."""
    try:
        from narrative_ai.engines.stt.audio_processor import AudioProcessor
        import numpy as np

        processor = AudioProcessor()
        audio_array, original_sr = processor.load_audio_file(audio_bytes)
        processed, target_sr = processor.preprocess(audio_array, input_sample_rate=original_sr)
        if processed.dtype != np.float32:
            processed = processed.astype(np.float32)
        max_val = np.max(np.abs(processed))
        if max_val > 1.0:
            processed = processed / max_val
        pcm_bytes = (processed * 32767).astype(np.int16).tobytes()
        return pcm_bytes, target_sr
    except Exception as exc:
        logger.debug("Audio preprocessing failed, passing through raw bytes: %s", exc)
        return audio_bytes, 16000


async def _preprocess_audio_async(audio_bytes: bytes) -> tuple[bytes, int]:
    """Run CPU-heavy audio preprocessing off the event loop."""
    return await asyncio.to_thread(_preprocess_audio, audio_bytes)


def _validate_entry_text(text: str, field_name: str = "text") -> str:
    """Run security validation (injection checks, length) on entry text. Raises HTTP 400 on failure."""
    try:
        return security_validate_text(
            text,
            min_length=0,
            max_length=_ENTRY_TEXT_MAX_LENGTH,
            check_sql_injection=True,
            check_prompt_injection=True,
        )
    except SecurityValidationError as e:
        raise http_error(
            status.HTTP_400_BAD_REQUEST,
            "VALIDATION_ERROR",
            e.message or f"Invalid {field_name}",
        ) from e


def _get_user_id(current_user: dict) -> uuid.UUID:
    """Parse user_id from JWT claims. Raises HTTP 401 if invalid (consistent with auth /me)."""
    try:
        return uuid.UUID(current_user["user_id"])
    except (ValueError, TypeError, KeyError):
        raise http_error(status.HTTP_401_UNAUTHORIZED, "INVALID_TOKEN", "Invalid token")


def _media_to_response_items(media_rows: list) -> List[EntryMediaItem]:
    return [
        EntryMediaItem(
            id=str(m.id),
            url=f"/api/entries/media/{m.id}",
            caption=getattr(m, "caption", None),
            media_type=getattr(m, "media_type", "image"),
        )
        for m in media_rows
    ]


def _entry_to_response(
    entry: DiaryEntry,
    media_items: Optional[List[EntryMediaItem]] = None,
) -> EntryResponse:
    return EntryResponse(
        id=str(entry.id),
        user_id=str(entry.user_id),
        raw_text=entry.raw_text,
        enhanced_text=entry.enhanced_text,
        emotion=entry.emotion,
        source_type=entry.source_type.value if isinstance(entry.source_type, SourceType) else entry.source_type,
        tags=entry.tags or [],
        audio_storage_path=entry.audio_storage_path,
        created_at=entry.created_at.isoformat() if entry.created_at else "",
        updated_at=entry.updated_at.isoformat() if entry.updated_at else None,
        media=media_items,
    )


def _entry_to_response_with_media_rows(entry: DiaryEntry, media_rows: list) -> EntryResponse:
    """Build EntryResponse from domain entry and pre-fetched media rows (single place for entry + media -> response)."""
    return _entry_to_response(entry, media_items=_media_to_response_items(media_rows))


async def _entry_to_response_with_media(
    entry: DiaryEntry,
    media_repo: PostgresEntryMediaRepository,
) -> EntryResponse:
    """Load media for entry and return EntryResponse. Use for single-entry endpoints."""
    media_rows = await media_repo.list_by_entry_id(entry.id)
    return _entry_to_response_with_media_rows(entry, media_rows)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "",
    response_model=EntryResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new diary entry",
)
async def create_entry(
    body: CreateEntryRequest,
    current_user: dict = Depends(get_current_user),
    entry_service: EntryService = Depends(get_entry_service),
    idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key"),
):
    """Create a diary entry for the authenticated user. Send Idempotency-Key to avoid duplicates on retry."""
    user_id = _get_user_id(current_user)
    if idempotency_key:
        cached = await get_idempotent_response(str(user_id), idempotency_key)
        if cached:
            return JSONResponse(content=cached[1], status_code=cached[0])
    _validate_entry_text(body.raw_text, "raw_text")
    if body.enhanced_text:
        _validate_entry_text(body.enhanced_text, "enhanced_text")
    created = await entry_service.create(
        user_id=user_id,
        raw_text=body.raw_text,
        enhanced_text=body.enhanced_text,
        emotion=body.emotion,
        source_type=SourceType(body.source_type),
        tags=[t.strip().lower() for t in body.tags if t.strip()],
    )
    response = _entry_to_response(created)
    if idempotency_key:
        await set_idempotent_response(str(user_id), idempotency_key, 201, response.model_dump())
    return response


@router.get(
    "",
    response_model=EntryListResponse,
    summary="List diary entries",
)
async def list_entries(
    current_user: dict = Depends(get_current_user),
    entry_service: EntryService = Depends(get_entry_service),
    media_repo: PostgresEntryMediaRepository = Depends(get_entry_media_repo),
    offset: int = Query(default=0, ge=0),
    limit: int = Query(default=20, ge=1, le=100),
    emotion: Optional[str] = Query(default=None),
    tag: Optional[str] = Query(default=None),
    date_from: Optional[datetime] = Query(default=None),
    date_to: Optional[datetime] = Query(default=None),
):
    """List the authenticated user's diary entries with optional filters."""
    user_id = _get_user_id(current_user)
    entries, total = await entry_service.list_entries(
        user_id=user_id,
        offset=offset,
        limit=limit,
        emotion=emotion,
        tag=tag,
        date_from=date_from,
        date_to=date_to,
    )
    entry_ids = [e.id for e in entries]
    all_media = await media_repo.list_by_entry_ids(entry_ids)
    by_entry: dict = {}
    for m in all_media:
        by_entry.setdefault(m.entry_id, []).append(m)
    response_entries = [_entry_to_response_with_media_rows(e, by_entry.get(e.id, [])) for e in entries]
    return EntryListResponse(
        entries=response_entries,
        total=total,
        offset=offset,
        limit=limit,
    )


# Serve media must be declared before /{entry_id} so that /media/{id} is matched
@router.get(
    "/media/{media_id}",
    response_class=FileResponse,
    summary="Serve entry media file",
)
async def serve_entry_media(
    media_id: uuid.UUID,
    current_user: dict = Depends(get_current_user_or_token_query),
    entry_repo: PostgresEntryRepository = Depends(get_entry_repo),
    media_repo: PostgresEntryMediaRepository = Depends(get_entry_media_repo),
):
    """Return the media file if it belongs to an entry owned by the current user."""
    user_id = _get_user_id(current_user)
    media_row = await media_repo.get_by_id(media_id)
    if media_row is None:
        raise http_error(status.HTTP_404_NOT_FOUND, "MEDIA_NOT_FOUND", "Media not found")
    entry = await entry_repo.get_by_id(media_row.entry_id, user_id=user_id, include_deleted=False)
    if entry is None:
        raise http_error(status.HTTP_404_NOT_FOUND, "MEDIA_NOT_FOUND", "Media not found")
    full_path = Path(MEDIA_UPLOAD_DIR) / media_row.storage_path
    if not full_path.is_file():
        raise http_error(status.HTTP_404_NOT_FOUND, "MEDIA_FILE_NOT_FOUND", "Media file not found")
    suffix = full_path.suffix.lower()
    media_type = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".webp": "image/webp",
        ".gif": "image/gif",
    }.get(suffix, "image/jpeg")
    return FileResponse(full_path, media_type=media_type)


@router.get(
    "/{entry_id}",
    response_model=EntryResponse,
    summary="Get a single diary entry",
)
async def get_entry(
    entry_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),
    entry_service: EntryService = Depends(get_entry_service),
    media_repo: PostgresEntryMediaRepository = Depends(get_entry_media_repo),
):
    """Retrieve a single diary entry by ID (scoped to the authenticated user)."""
    user_id = _get_user_id(current_user)
    entry = await entry_service.get_by_id(entry_id, user_id)
    return await _entry_to_response_with_media(entry, media_repo)


@router.patch(
    "/{entry_id}",
    response_model=EntryResponse,
    summary="Update a diary entry",
)
async def update_entry(
    entry_id: uuid.UUID,
    body: UpdateEntryRequest,
    current_user: dict = Depends(get_current_user),
    entry_service: EntryService = Depends(get_entry_service),
    media_repo: PostgresEntryMediaRepository = Depends(get_entry_media_repo),
):
    """Update selected fields on an existing diary entry."""
    if body.enhanced_text is not None:
        _validate_entry_text(body.enhanced_text, "enhanced_text")
    user_id = _get_user_id(current_user)
    updated = await entry_service.update(
        entry_id,
        user_id,
        enhanced_text=body.enhanced_text,
        tags=body.tags,
        emotion=body.emotion,
    )
    return await _entry_to_response_with_media(updated, media_repo)


@router.delete(
    "/{entry_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Soft-delete a diary entry",
)
async def delete_entry(
    entry_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),
    entry_service: EntryService = Depends(get_entry_service),
):
    """Soft-delete a diary entry (sets ``deleted_at``, recoverable)."""
    user_id = _get_user_id(current_user)
    await entry_service.delete(entry_id, user_id)


# ---------------------------------------------------------------------------
# Entry media (images) – upload, delete
# ---------------------------------------------------------------------------


@router.post(
    "/{entry_id}/media",
    response_model=EntryMediaItem,
    status_code=status.HTTP_201_CREATED,
    summary="Upload media for an entry",
)
async def upload_entry_media(
    entry_id: uuid.UUID,
    file: UploadFile = File(..., description="Image file (JPEG, PNG, WebP, GIF)"),
    caption: Optional[str] = Form(None),
    current_user: dict = Depends(get_current_user),
    entry_service: EntryService = Depends(get_entry_service),
    media_repo: PostgresEntryMediaRepository = Depends(get_entry_media_repo),
):
    """Upload an image (or other media) for a diary entry. Entry must belong to the current user."""
    user_id = _get_user_id(current_user)
    try:
        await entry_service.get_by_id(entry_id, user_id)
    except EntryNotFoundError:
        raise http_error(status.HTTP_404_NOT_FOUND, "ENTRY_NOT_FOUND", "Entry not found")
    content_type = (file.content_type or "").lower().split(";")[0].strip()
    if content_type not in ALLOWED_IMAGE_CONTENT_TYPES:
        raise http_error(
            status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            "UNSUPPORTED_MEDIA_TYPE",
            f"Allowed types: {', '.join(ALLOWED_IMAGE_CONTENT_TYPES)}",
        )
    data = await file.read()
    if not data:
        raise http_error(status.HTTP_400_BAD_REQUEST, "EMPTY_FILE", "Empty file")
    if len(data) > MAX_MEDIA_FILE_BYTES:
        raise http_error(
            status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            "FILE_TOO_LARGE",
            f"File too large. Maximum size is {MAX_MEDIA_FILE_BYTES // (1024 * 1024)}MB.",
        )
    ext = (
        "jpg"
        if "jpeg" in content_type
        else "png"
        if content_type == "image/png"
        else "webp"
        if content_type == "image/webp"
        else "gif"
    )
    media_id = uuid.uuid4()
    rel_path = f"{entry_id}/{media_id}.{ext}"
    upload_dir = Path(MEDIA_UPLOAD_DIR) / str(entry_id)
    upload_dir.mkdir(parents=True, exist_ok=True)
    full_path = upload_dir / f"{media_id}.{ext}"
    await asyncio.to_thread(full_path.write_bytes, data)
    await media_repo.add(
        entry_id=entry_id,
        user_id=user_id,
        storage_path=rel_path,
        media_type="image",
        caption=caption,
        media_id=media_id,
    )
    return EntryMediaItem(
        id=str(media_id),
        url=f"/api/entries/media/{media_id}",
        caption=caption,
        media_type="image",
    )


@router.delete(
    "/{entry_id}/media/{media_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete entry media",
)
async def delete_entry_media(
    entry_id: uuid.UUID,
    media_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),
    entry_repo: PostgresEntryRepository = Depends(get_entry_repo),
    media_repo: PostgresEntryMediaRepository = Depends(get_entry_media_repo),
):
    """Remove a media attachment from an entry. Entry must belong to the current user."""
    user_id = _get_user_id(current_user)
    entry = await entry_repo.get_by_id(entry_id, user_id=user_id, include_deleted=False)
    if entry is None:
        raise http_error(status.HTTP_404_NOT_FOUND, "ENTRY_NOT_FOUND", "Entry not found")
    media_row = await media_repo.get_by_id(media_id)
    if media_row is None or media_row.entry_id != entry_id:
        raise http_error(status.HTTP_404_NOT_FOUND, "MEDIA_NOT_FOUND", "Media not found")
    full_path = Path(MEDIA_UPLOAD_DIR) / media_row.storage_path
    if full_path.is_file():
        try:
            full_path.unlink()
        except OSError as e:
            logger.warning("Could not delete media file %s: %s", full_path, e)
    await media_repo.delete(media_id)


# ---------------------------------------------------------------------------
# Pipeline request schemas
# ---------------------------------------------------------------------------


class FromTextRequest(BaseModel):
    """Request for the ``/from-text`` pipeline endpoint."""

    raw_text: str = Field(..., min_length=1, max_length=50000)
    enhance: bool = Field(default=False, description="Run LLM text enhancement")
    detect_emotion: bool = Field(default=False, description="Run LLM emotion detection")
    generate_tags: bool = Field(default=False, description="Run LLM tag generation")


# ---------------------------------------------------------------------------
# Pipeline endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/from-voice",
    response_model=EntryResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create entry from voice (audio -> STT -> entry)",
    tags=["entries", "pipeline"],
)
async def create_entry_from_voice(
    audio: UploadFile = File(..., description="Audio file (WAV, MP3, FLAC, OGG, WebM)"),
    language: Optional[str] = Form(None, description="Language code (ar, en, or auto-detect)"),
    extract_emotion: bool = Form(True, description="Detect emotion from voice"),
    current_user: dict = Depends(get_current_user),
    entry_service: EntryService = Depends(get_entry_service),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
    idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key"),
):
    """Upload audio, transcribe via STT with emotion detection, save as diary entry. Use Idempotency-Key to avoid duplicates on retry."""
    user_id = _get_user_id(current_user)
    if idempotency_key:
        cached = await get_idempotent_response(str(user_id), idempotency_key)
        if cached:
            return JSONResponse(content=cached[1], status_code=cached[0])
    audio_bytes = await audio.read()
    if not audio_bytes:
        raise http_error(status.HTTP_400_BAD_REQUEST, "EMPTY_AUDIO", "Empty audio file")

    pcm_bytes, target_sr = await _preprocess_audio_async(audio_bytes)

    created = await entry_service.create_from_voice(
        user_id=user_id,
        pcm_bytes=pcm_bytes,
        sample_rate=target_sr,
        language=language,
        extract_emotion=extract_emotion,
        correlation_id=correlation_id,
    )
    response = _entry_to_response(created)
    if idempotency_key:
        await set_idempotent_response(str(user_id), idempotency_key, 201, response.model_dump())
    return response


@router.post(
    "/from-voice/enhanced",
    response_model=EntryResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create entry from voice with LLM enhancement",
    tags=["entries", "pipeline"],
)
async def create_entry_from_voice_enhanced(
    audio: UploadFile = File(..., description="Audio file (WAV, MP3, FLAC, OGG, WebM)"),
    language: Optional[str] = Form(None, description="Language code (ar, en, or auto-detect)"),
    current_user: dict = Depends(get_current_user),
    entry_service: EntryService = Depends(get_entry_service),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
    idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key"),
):
    """Full pipeline: audio -> STT -> emotion -> entry -> LLM enhance + tags.

    If LLM enhancement fails the unenhanced entry is still returned.
    Use Idempotency-Key to avoid duplicates on retry.
    """
    user_id = _get_user_id(current_user)
    if idempotency_key:
        cached = await get_idempotent_response(str(user_id), idempotency_key)
        if cached:
            return JSONResponse(content=cached[1], status_code=cached[0])
    audio_bytes = await audio.read()
    if not audio_bytes:
        raise http_error(status.HTTP_400_BAD_REQUEST, "EMPTY_AUDIO", "Empty audio file")

    pcm_bytes, target_sr = await _preprocess_audio_async(audio_bytes)

    created = await entry_service.create_from_voice_enhanced(
        user_id=user_id,
        pcm_bytes=pcm_bytes,
        sample_rate=target_sr,
        language=language,
        correlation_id=correlation_id,
    )
    response = _entry_to_response(created)
    if idempotency_key:
        await set_idempotent_response(str(user_id), idempotency_key, 201, response.model_dump())
    return response


@router.post(
    "/from-text",
    response_model=EntryResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create entry from text with optional LLM processing",
    tags=["entries", "pipeline"],
)
async def create_entry_from_text(
    body: FromTextRequest,
    current_user: dict = Depends(get_current_user),
    entry_service: EntryService = Depends(get_entry_service),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
    idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key"),
):
    """Create a text entry with optional LLM emotion detection, enhancement, and tagging. Use Idempotency-Key to avoid duplicates on retry."""
    user_id = _get_user_id(current_user)
    if idempotency_key:
        cached = await get_idempotent_response(str(user_id), idempotency_key)
        if cached:
            return JSONResponse(content=cached[1], status_code=cached[0])
    _validate_entry_text(body.raw_text, "raw_text")
    created = await entry_service.create_from_text(
        user_id=user_id,
        raw_text=body.raw_text,
        enhance=body.enhance,
        detect_emotion=body.detect_emotion,
        generate_tags=body.generate_tags,
        correlation_id=correlation_id,
    )
    response = _entry_to_response(created)
    if idempotency_key:
        await set_idempotent_response(str(user_id), idempotency_key, 201, response.model_dump())
    return response


@router.patch(
    "/{entry_id}/enhance",
    response_model=EntryResponse,
    summary="Enhance an existing entry with LLM",
    tags=["entries", "pipeline"],
)
async def enhance_entry(
    entry_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),
    entry_service: EntryService = Depends(get_entry_service),
    media_repo: PostgresEntryMediaRepository = Depends(get_entry_media_repo),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """Run LLM enhancement on an existing diary entry.

    Generates ``enhanced_text`` and auto-tags from the ``raw_text``.
    """
    user_id = _get_user_id(current_user)
    updated = await entry_service.enhance_entry(
        entry_id=entry_id,
        user_id=user_id,
        correlation_id=correlation_id,
    )
    return await _entry_to_response_with_media(updated, media_repo)
