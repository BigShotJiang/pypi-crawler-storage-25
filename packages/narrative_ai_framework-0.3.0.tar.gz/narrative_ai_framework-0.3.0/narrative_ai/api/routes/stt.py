"""
STT API Routes.

FastAPI routes for Speech-to-Text endpoints.
Supports batch transcription, streaming, and provider management.

Endpoints:
- POST /api/stt/transcribe - Transcribe uploaded audio file
- POST /api/stt/transcribe/stream - Streaming transcription (SSE)
- GET /api/stt/providers - List available STT providers
- GET /api/stt/status - Health check endpoint
"""

import asyncio
import json
import logging
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, Header, HTTPException, UploadFile

from narrative_ai.api.http_helpers import http_error
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from narrative_ai.api.dependencies import get_stt_engine, get_user_tenant
from narrative_ai.engines.stt import STTEngine, TranscriptionResult

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/stt", tags=["stt"])


# =============================================================================
# Request/Response Models
# =============================================================================


class TranscribeResponse(BaseModel):
    """Response model for transcription."""

    text: str
    confidence: float
    language: str
    provider: str
    processing_time: float
    emotion: Optional[str] = None
    emotion_confidence: Optional[float] = None
    correlation_id: str = ""


class ProviderInfo(BaseModel):
    """STT provider information."""

    name: str
    available: bool
    models: List[str] = []
    features: List[str] = []


# =============================================================================
# Routes (engine and user_tenant from narrative_ai.api.dependencies)
# =============================================================================

VALID_STT_PROVIDERS = frozenset({"whisper", "elevenlabs"})


def _preprocess_audio_to_pcm(audio_bytes: bytes) -> tuple[bytes, int]:
    """Decode and convert to 16-bit PCM at 16 kHz (best effort)."""
    from narrative_ai.engines.stt.audio_processor import AudioProcessor
    import numpy as np

    processor = AudioProcessor()
    try:
        audio_array, original_sr = processor.load_audio_file(audio_bytes)
        processed, target_sr = processor.preprocess(audio_array, input_sample_rate=original_sr)

        if processed.dtype != np.float32:
            processed = processed.astype(np.float32)
        max_val = np.max(np.abs(processed))
        if max_val > 1.0:
            processed = processed / max_val

        pcm_bytes = (processed * 32767).astype(np.int16).tobytes()
        return pcm_bytes, target_sr
    except Exception:
        # If preprocessing fails, pass raw bytes and let the engine handle it
        return audio_bytes, 16000


@router.post("/transcribe", response_model=TranscribeResponse)
async def transcribe(
    audio: UploadFile = File(..., description="Audio file (WAV, MP3, FLAC, OGG, WebM, etc.)"),
    language: Optional[str] = Form(None, description="Language code (ar, en, or None for auto-detect)"),
    provider: Optional[str] = Form(None, description="Force specific provider (whisper, elevenlabs)"),
    extract_emotion: bool = Form(True, description="Whether to detect emotion from voice"),
    use_vad: bool = Form(True, description="Whether to use Voice Activity Detection"),
    engine: Optional[STTEngine] = Depends(get_stt_engine),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """
    Transcribe an uploaded audio file.

    Accepts common audio formats: WAV, MP3, FLAC, OGG, WebM, etc.
    Returns the transcribed text with confidence, language, and optional emotion.
    """
    if engine is None:
        raise http_error(503, "STT_UNAVAILABLE", "STT service temporarily unavailable")
    user_id, tenant_id = user_tenant

    # Normalize provider: reject invalid values (e.g. Swagger "string" placeholder)
    if provider and provider.strip().lower() not in VALID_STT_PROVIDERS:
        provider = None

    try:
        audio_bytes = await audio.read()

        if not audio_bytes:
            raise http_error(400, "EMPTY_AUDIO", "Empty audio file")

        # Preprocess off event loop (CPU-heavy).
        pcm_bytes, target_sr = await asyncio.to_thread(_preprocess_audio_to_pcm, audio_bytes)

        result: TranscriptionResult = await engine.transcribe(
            audio=pcm_bytes,
            sample_rate=target_sr,
            language=language,
            extract_emotion=extract_emotion,
            use_vad=use_vad,
            provider=provider,
            user_id=user_id,
            tenant_id=tenant_id,
            correlation_id=correlation_id,
        )

        return TranscribeResponse(
            text=result.text,
            confidence=result.confidence,
            language=result.language or "",
            provider=result.provider or "",
            processing_time=result.processing_time,
            emotion=result.emotion.value if result.emotion else None,
            emotion_confidence=result.emotion_confidence,
            correlation_id=correlation_id or "",
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Transcription failed: {e}", exc_info=True)
        raise http_error(500, "STT_ERROR", str(e))


@router.post("/transcribe/stream")
async def transcribe_stream(
    audio: UploadFile = File(..., description="Audio file to stream-transcribe"),
    language: Optional[str] = Form(None),
    provider: Optional[str] = Form(None),
    engine: Optional[STTEngine] = Depends(get_stt_engine),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """
    Stream transcription results as Server-Sent Events (SSE).

    Reads the uploaded audio and yields partial/final transcription results.
    """
    if engine is None:
        raise http_error(503, "STT_UNAVAILABLE", "STT service temporarily unavailable")
    user_id, tenant_id = user_tenant

    audio_bytes = await audio.read()
    if not audio_bytes:
        raise http_error(400, "EMPTY_AUDIO", "Empty audio file")

    async def stream_generator():
        try:
            # Create a simple async iterator that yields the audio in chunks
            chunk_size = 16000 * 2  # 1 second of 16-bit 16 kHz audio
            offset = 0

            async def audio_chunks():
                nonlocal offset
                while offset < len(audio_bytes):
                    chunk = audio_bytes[offset : offset + chunk_size]
                    offset += chunk_size
                    yield chunk

            async for partial_result in engine.transcribe_streaming(
                audio_stream=audio_chunks(),
                sample_rate=16000,
                language=language,
                provider=provider,
                user_id=user_id,
                tenant_id=tenant_id,
                correlation_id=correlation_id,
            ):
                data = {
                    "text": partial_result.text,
                    "confidence": partial_result.confidence,
                    "language": partial_result.language or "",
                    "is_partial": getattr(partial_result, "is_partial", False),
                    "emotion": partial_result.emotion.value if partial_result.emotion else None,
                }
                yield f"data: {json.dumps(data)}\n\n"

        except Exception as e:
            logger.error(f"Streaming transcription failed: {e}", exc_info=True)
            error_data = {"error": str(e), "is_final": True}
            yield f"data: {json.dumps(error_data)}\n\n"

    return StreamingResponse(
        stream_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )


@router.get("/providers", response_model=List[ProviderInfo])
async def list_providers(
    engine: Optional[STTEngine] = Depends(get_stt_engine),
):
    """List all available STT providers."""
    if engine is None:
        raise http_error(503, "STT_UNAVAILABLE", "STT service temporarily unavailable")
    try:
        health = await engine.health_check()
        strategy_health = health.get("strategy", {})
        providers_health = strategy_health.get("providers", {})

        providers = []
        for name, provider_info in providers_health.items():
            providers.append(
                ProviderInfo(
                    name=name,
                    available=provider_info.get("available", False),
                    models=[provider_info.get("model", "unknown")] if provider_info.get("model") else [],
                    features=provider_info.get("supported_features", []),
                )
            )

        return providers

    except Exception as e:
        logger.error(f"Failed to list providers: {e}", exc_info=True)
        raise http_error(500, "STT_ERROR", str(e))


@router.get("/status")
async def status(
    engine: Optional[STTEngine] = Depends(get_stt_engine),
):
    """Health check endpoint."""
    if engine is None:
        raise http_error(503, "STT_UNAVAILABLE", "STT service temporarily unavailable")
    try:
        health = await engine.health_check()
        metrics = await engine.get_metrics()

        return {
            "status": "healthy" if health.get("engine", {}).get("initialized") else "unhealthy",
            "health": health,
            "metrics": metrics,
        }

    except Exception as e:
        logger.error(f"Health check failed: {e}", exc_info=True)
        return {
            "status": "unhealthy",
            "error": str(e),
        }
