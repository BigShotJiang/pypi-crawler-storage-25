"""Search API routes.

Planned: RAG/embedding-based search over diary entries.

For now this is a stub endpoint that returns 501 NOT_IMPLEMENTED so clients
and tests can detect that search is not yet wired.
"""

from fastapi import APIRouter

router = APIRouter(prefix="/api/search", tags=["search"])


@router.get("", status_code=501)
async def search_not_implemented():
    """Search is not implemented yet (RAG/embedding search coming soon)."""
    return {
        "code": "NOT_IMPLEMENTED",
        "message": "Search is not implemented yet. RAG/embedding search coming soon.",
    }
