"""
LLM API Routes.

FastAPI routes for LLM generation endpoints.
Supports both streaming and non-streaming generation.

Endpoints:
- POST /api/llm/generate - Main generation endpoint
- POST /api/llm/generate/stream - Streaming generation endpoint
- POST /api/llm/chat - Multi-turn conversation endpoint
- GET /api/llm/providers - List available providers
- GET /api/llm/models - List available models
- GET /api/llm/status - Health check endpoint
"""

import logging
from typing import Optional, List, Dict, Any, Union
from fastapi import APIRouter, Depends, Header

from narrative_ai.api.http_helpers import http_error
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
import json

from narrative_ai.api.dependencies import get_conversation_manager, get_llm_engine, get_user_tenant, get_db
from narrative_ai.application.services.companion_chat_pipeline import CompanionChatPipeline, CompanionChatRequest
from narrative_ai.engines.llm import LLMEngine, ConversationManager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/llm", tags=["llm"])
_chat_pipeline_instance: Optional[CompanionChatPipeline] = None


def _get_chat_pipeline(engine: LLMEngine, conv_manager: ConversationManager) -> CompanionChatPipeline:
    global _chat_pipeline_instance
    if _chat_pipeline_instance is None:
        _chat_pipeline_instance = CompanionChatPipeline(engine=engine, conv_manager=conv_manager)
    return _chat_pipeline_instance


# =============================================================================
# Request/Response Models
# =============================================================================


class GenerateRequest(BaseModel):
    """Request model for LLM generation."""

    prompt: Optional[str] = Field(None, description="User prompt (if messages not provided)")
    system_prompt: Optional[str] = Field(None, description="System instruction")
    messages: Optional[List[Dict[str, str]]] = Field(None, description="Conversation history")
    temperature: float = Field(0.7, ge=0.0, le=2.0, description="Sampling temperature")
    max_tokens: Optional[int] = Field(None, gt=0, description="Maximum tokens to generate")
    provider: Optional[str] = Field(None, description="Force specific provider")
    tools: Optional[List[Dict]] = Field(None, description="Function calling tools")
    tool_choice: Optional[Union[str, Dict]] = Field(None, description="Tool choice strategy")
    response_format: Optional[Dict] = Field(None, description="Structured output format")
    stream: bool = Field(False, description="Whether to stream response")


class GenerateResponse(BaseModel):
    """Response model for LLM generation."""

    text: str
    finish_reason: str
    provider: str
    model: str
    processing_time: float
    input_tokens: int
    output_tokens: int
    total_tokens: int
    emotion: Optional[str] = None
    emotion_confidence: Optional[float] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    correlation_id: str


class ChatRequest(BaseModel):
    """Request model for multi-turn chat."""

    session_id: Optional[str] = Field(None, description="Conversation session ID (auto-created if not provided)")
    message: str = Field(..., description="User message")
    system_prompt: Optional[str] = Field(None, description="System instruction")
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    max_tokens: Optional[int] = Field(None, gt=0)
    provider: Optional[str] = None


class ChatResponse(BaseModel):
    """Response model for multi-turn chat."""

    session_id: str
    text: str
    finish_reason: str
    provider: str
    model: str
    processing_time: float
    input_tokens: int
    output_tokens: int
    emotion: Optional[str] = None
    correlation_id: str
    sources: Optional[List[Dict[str, Any]]] = None


class ChatHistoryMessage(BaseModel):
    """Normalized chat history message."""

    role: str
    content: str


class ChatHistoryResponse(BaseModel):
    """Chat history payload for a single session."""

    session_id: str
    messages: List[ChatHistoryMessage]


class ProviderInfo(BaseModel):
    """Provider information."""

    name: str
    available: bool
    models: List[str]
    features: List[str]


# =============================================================================
# Routes (engine, conversation_manager, user_tenant from narrative_ai.api.dependencies)
# =============================================================================


@router.post("/generate", response_model=GenerateResponse)
async def generate(
    request: GenerateRequest,
    engine: Optional[LLMEngine] = Depends(get_llm_engine),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """
    Generate text completion.

    Supports both prompt-based and message-based generation.
    """
    if engine is None:
        raise http_error(503, "LLM_UNAVAILABLE", "LLM service temporarily unavailable")
    user_id, tenant_id = user_tenant

    try:
        result = await engine.generate(
            prompt=request.prompt,
            system_prompt=request.system_prompt,
            messages=request.messages,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            tools=request.tools,
            tool_choice=request.tool_choice,
            response_format=request.response_format,
            provider=request.provider,
            user_id=user_id,
            tenant_id=tenant_id,
            correlation_id=correlation_id,
        )

        return GenerateResponse(
            text=result.text,
            finish_reason=result.finish_reason,
            provider=result.provider,
            model=result.model,
            processing_time=result.processing_time,
            input_tokens=result.input_tokens,
            output_tokens=result.output_tokens,
            total_tokens=result.total_tokens,
            emotion=result.emotion.value if result.emotion else None,
            emotion_confidence=result.emotion_confidence,
            tool_calls=result.tool_calls,
            correlation_id=result.correlation_id or correlation_id or "",
        )

    except Exception as e:
        logger.error(f"Generation failed: {e}", exc_info=True)
        raise http_error(500, "LLM_ERROR", str(e))


@router.post("/generate/stream")
async def generate_stream(
    request: GenerateRequest,
    engine: Optional[LLMEngine] = Depends(get_llm_engine),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """
    Stream text completion with Server-Sent Events (SSE).

    Returns incremental results as they are generated.
    """
    if engine is None:
        raise http_error(503, "LLM_UNAVAILABLE", "LLM service temporarily unavailable")
    user_id, tenant_id = user_tenant

    async def generate():
        try:
            async for result in engine.generate_streaming(
                prompt=request.prompt,
                system_prompt=request.system_prompt,
                messages=request.messages,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
                tools=request.tools,
                tool_choice=request.tool_choice,
                response_format=request.response_format,
                provider=request.provider,
                user_id=user_id,
                tenant_id=tenant_id,
                correlation_id=correlation_id,
            ):
                # Format as SSE
                data = {
                    "text": result.text,
                    "is_partial": result.is_partial,
                    "is_final": result.is_final,
                    "emotion": result.emotion.value if result.emotion else None,
                    "emotion_confidence": result.emotion_confidence,
                }

                yield f"data: {json.dumps(data)}\n\n"

        except Exception as e:
            logger.error(f"Streaming failed: {e}", exc_info=True)
            error_data = {"error": str(e), "is_final": True}
            yield f"data: {json.dumps(error_data)}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )


@router.post("/chat", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    engine: Optional[LLMEngine] = Depends(get_llm_engine),
    conv_manager: ConversationManager = Depends(get_conversation_manager),
    db: Any = Depends(get_db),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """
    Multi-turn conversation endpoint.

    Manages conversation context automatically.
    Injects a user profile snapshot into the system prompt on every request.
    """
    if engine is None:
        raise http_error(503, "LLM_UNAVAILABLE", "LLM service temporarily unavailable")
    user_id, tenant_id = user_tenant

    try:
        chat_pipeline = _get_chat_pipeline(engine, conv_manager)
        result = await chat_pipeline.run(
            CompanionChatRequest(
                session_id=request.session_id,
                message=request.message,
                system_prompt=request.system_prompt,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
                provider=request.provider,
                user_id=user_id,
                tenant_id=tenant_id,
                correlation_id=correlation_id,
            ),
            db_session=db,
        )
        return ChatResponse(
            session_id=result.session_id,
            text=result.text,
            finish_reason=result.finish_reason,
            provider=result.provider,
            model=result.model,
            processing_time=result.processing_time,
            input_tokens=result.input_tokens,
            output_tokens=result.output_tokens,
            emotion=result.emotion,
            correlation_id=result.correlation_id,
            sources=result.sources,
        )

    except Exception as e:
        logger.error(f"Chat failed: {e}", exc_info=True)
        raise http_error(500, "LLM_ERROR", str(e))


@router.get("/chat/{session_id}/messages", response_model=ChatHistoryResponse)
async def get_chat_messages(
    session_id: str,
    conv_manager: ConversationManager = Depends(get_conversation_manager),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
):
    """Return persisted user/assistant turns for a chat session."""
    user_id, _tenant_id = user_tenant

    session = await conv_manager.get_session_async(session_id)
    if session is None:
        raise http_error(404, "SESSION_NOT_FOUND", "Session not found")

    # Enforce per-user isolation even when clients guess session IDs.
    if session.user_id and user_id and str(session.user_id) != str(user_id):
        raise http_error(403, "SESSION_FORBIDDEN", "Session does not belong to the current user")

    messages = await conv_manager.get_messages_async(session_id, include_system=False)
    normalized = [
        ChatHistoryMessage(role=role, content=content)
        for msg in messages
        if (role := str(msg.get("role", "")).strip()) in {"user", "assistant"}
        if (content := str(msg.get("content", "")).strip())
    ]

    return ChatHistoryResponse(session_id=session_id, messages=normalized)


@router.get("/providers", response_model=List[ProviderInfo])
async def list_providers(
    engine: Optional[LLMEngine] = Depends(get_llm_engine),
):
    """List all available LLM providers."""
    if engine is None:
        raise http_error(503, "LLM_UNAVAILABLE", "LLM service temporarily unavailable")
    try:
        health = await engine.health_check()
        strategy_health = health.get("strategy", {})
        providers_health = strategy_health.get("providers", {})

        providers = []
        for name, provider_info in providers_health.items():
            providers.append(
                ProviderInfo(
                    name=name,
                    available=provider_info.get("available", False),
                    models=[provider_info.get("model", "unknown")],
                    features=provider_info.get("supported_features", []),
                )
            )

        return providers

    except Exception as e:
        logger.error(f"Failed to list providers: {e}", exc_info=True)
        raise http_error(500, "LLM_ERROR", str(e))


@router.get("/models")
async def list_models(
    provider: Optional[str] = None,
    engine: Optional[LLMEngine] = Depends(get_llm_engine),
):
    """List available models for a provider (or all providers)."""
    if engine is None:
        raise http_error(503, "LLM_UNAVAILABLE", "LLM service temporarily unavailable")
    try:
        health = await engine.health_check()
        strategy_health = health.get("strategy", {})
        providers_health = strategy_health.get("providers", {})

        models = {}

        if provider:
            if provider in providers_health:
                provider_info = providers_health[provider]
                models[provider] = [provider_info.get("model", "unknown")]
        else:
            for name, provider_info in providers_health.items():
                models[name] = [provider_info.get("model", "unknown")]

        return {"models": models}

    except Exception as e:
        logger.error(f"Failed to list models: {e}", exc_info=True)
        raise http_error(500, "LLM_ERROR", str(e))


@router.get("/status")
async def status(
    engine: Optional[LLMEngine] = Depends(get_llm_engine),
):
    """Health check endpoint."""
    if engine is None:
        raise http_error(503, "LLM_UNAVAILABLE", "LLM service temporarily unavailable")
    try:
        health = await engine.health_check()
        metrics = await engine.get_metrics()

        return {
            "status": "healthy" if health.get("engine", {}).get("initialized") else "unhealthy",
            "health": health,
            "metrics": metrics,
        }

    except Exception as e:
        logger.error(f"Health check failed: {e}", exc_info=True)
        return {
            "status": "unhealthy",
            "error": str(e),
        }
