"""Authentication routes -- register, login, refresh, me.

All endpoints are prefixed with ``/api/auth`` (set via the router prefix).
"""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from typing import Optional

import jwt as pyjwt
from fastapi import APIRouter, Depends, status
from fastapi.security import OAuth2PasswordRequestForm

from narrative_ai.api.http_helpers import http_error
from pydantic import BaseModel, ConfigDict, EmailStr, Field

from narrative_ai.api.dependencies import get_current_user, get_user_service
from narrative_ai.application.services.user_service import UserService
from narrative_ai.domain.entities.user import User
from narrative_ai.domain.exceptions import AccountDeactivatedError, UserNotFoundError
from narrative_ai.domain.value_objects.tenant_id import TenantId
from narrative_ai.infrastructure.security.jwt_service import (
    create_access_token,
    create_refresh_token,
    decode_token,
    refresh_token_ttl_seconds,
)
from narrative_ai.security.audit_trail import ActionStatus, ActionType, AuditLogger
from narrative_ai.security.rate_limiting import RateLimitExceeded, RateLimiter

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Brute force protection: per-email rate limiter
# ---------------------------------------------------------------------------

# Lazy-initialized rate limiter instance
_rate_limiter: Optional[RateLimiter] = None
# Lazy-initialized audit logger for auth-related security events
_audit_logger: Optional[AuditLogger] = None


def _get_rate_limiter() -> Optional[RateLimiter]:
    """Return a RateLimiter instance for brute force protection, or None if unavailable."""
    global _rate_limiter
    if _rate_limiter is not None:
        return _rate_limiter

    try:
        _rate_limiter = RateLimiter()
        return _rate_limiter
    except Exception as exc:
        logger.warning("Could not initialize rate limiter for brute force protection: %s", exc)
        return None


def _get_audit_logger() -> Optional[AuditLogger]:
    """Return a shared AuditLogger instance for auth events, or None if unavailable.

    Uses AUDIT_DATABASE_URL if set, otherwise falls back to DATABASE_URL.
    Fails open (returns None) if initialization fails so that auth is not blocked
    by audit misconfiguration.
    """
    global _audit_logger
    if _audit_logger is not None:
        return _audit_logger

    try:
        audit_db_url = os.getenv("AUDIT_DATABASE_URL") or os.getenv("DATABASE_URL")
        if not audit_db_url:
            logger.debug("Audit logging skipped for auth: AUDIT_DATABASE_URL/DATABASE_URL not set")
            return None
        _audit_logger = AuditLogger(database_url=audit_db_url)
        logger.info("Audit logger initialized for auth routes")
        return _audit_logger
    except Exception as exc:  # pragma: no cover - best-effort
        logger.warning("Could not initialize audit logger for auth routes: %s", exc)
        return None


def _check_auth_rate_limit(email: str, resource_type: str) -> uuid.UUID:
    """Enforce per-email auth rate limit; audit and raise 429 if exceeded.

    Returns:
        tenant_id (for use when resetting after success).

    Raises:
        HTTPException: 429 with Retry-After when limit exceeded.
    """
    limiter = _get_rate_limiter()
    tenant_id = TenantId.default().value
    if limiter is None:
        return tenant_id

    try:
        limiter.check_auth_attempt_limit(tenant_id, email)
        return tenant_id
    except RateLimitExceeded as exc:
        audit = _get_audit_logger()
        if audit is not None and ActionType is not None and ActionStatus is not None:
            try:
                pseudo_user_id = uuid.uuid5(uuid.NAMESPACE_DNS, f"auth.email:{email}")
                audit.log_action_async(
                    tenant_id=TenantId.default().value,
                    user_id=pseudo_user_id,
                    action=ActionType.RATE_LIMIT_EXCEEDED,
                    resource_type=resource_type,
                    resource_id=None,
                    status=ActionStatus.BLOCKED,
                    details={
                        "email": email,
                        "reason": "too_many_auth_attempts",
                        "window_seconds": 300,
                    },
                )
            except Exception:  # pragma: no cover
                logger.warning("Failed to write auth rate-limit audit log for %s", resource_type, exc_info=True)
        raise http_error(
            status.HTTP_429_TOO_MANY_REQUESTS,
            "RATE_LIMIT_EXCEEDED",
            exc.message,
            headers={"Retry-After": str(exc.retry_after)},
        ) from exc


def _reset_auth_rate_limit(tenant_id: uuid.UUID, email: str, endpoint: str = "login") -> None:
    """Reset per-email auth attempt counter after successful login (best-effort)."""
    limiter = _get_rate_limiter()
    if limiter is None:
        return
    try:
        limiter.reset_auth_attempts(tenant_id, email, is_self_reset=True)
    except Exception:  # pragma: no cover
        logger.warning("Failed to reset auth attempts after successful %s", endpoint, exc_info=True)


# ---------------------------------------------------------------------------
# Refresh-token rotation: used-JTI tracking via Redis
# ---------------------------------------------------------------------------

_redis_client = None
_redis_init_attempted = False
_redis_init_lock: asyncio.Lock | None = None


async def _get_redis():
    """Return a Redis client for JTI tracking, or *None* if unavailable."""
    global _redis_client, _redis_init_attempted, _redis_init_lock
    if _redis_init_attempted:
        return _redis_client

    if _redis_init_lock is None:
        _redis_init_lock = asyncio.Lock()
    async with _redis_init_lock:
        if _redis_init_attempted:
            return _redis_client
        _redis_init_attempted = True

        redis_url = os.getenv("REDIS_URL", "")
        if not redis_url:
            return None
        try:
            import redis.asyncio as redis_lib

            _redis_client = redis_lib.from_url(
                redis_url,
                decode_responses=True,
                socket_connect_timeout=2,
                socket_timeout=2,
            )
            await _redis_client.ping()
        except Exception:
            _redis_client = None
    return _redis_client


async def _is_jti_used(jti: str) -> bool:
    """Check whether a refresh token JTI has already been consumed.

    Uses atomic SETNX check to prevent race conditions.
    Returns True if JTI exists (already used), False otherwise.
    """
    r = await _get_redis()
    if r is None:
        # Fail closed: if Redis unavailable, reject refresh tokens for security
        # This prevents token reuse when Redis is down
        logger.warning("Redis unavailable for JTI tracking - rejecting refresh token for security")
        return True  # Treat as used to fail closed
    try:
        key = f"used_jti:{jti}"
        # Check if key exists (already used)
        return await r.exists(key) == 1
    except Exception as exc:
        logger.warning("Error checking JTI in Redis: %s - rejecting for security", exc)
        return True  # Fail closed on error


async def _mark_jti_used(jti: str) -> bool:
    """Atomically mark a refresh token JTI as consumed.

    Uses SETNX (SET if Not eXists) to prevent race conditions where
    concurrent refresh requests could both pass the check.

    Returns True if JTI was successfully marked (first time), False if already used.
    """
    r = await _get_redis()
    if r is None:
        logger.warning("Redis unavailable - cannot mark JTI as used")
        return False
    try:
        key = f"used_jti:{jti}"
        # SETNX returns 1 if key was set (first time), 0 if already exists
        # Set expiration to match refresh token TTL
        was_set = await r.set(key, "1", nx=True, ex=refresh_token_ttl_seconds())
        return bool(was_set)
    except Exception as exc:
        logger.error("Could not mark JTI as used in Redis: %s", exc)
        return False


router = APIRouter(prefix="/api/auth", tags=["auth"])


# ---------------------------------------------------------------------------
# Request / Response schemas
# ---------------------------------------------------------------------------


class RegisterRequest(BaseModel):
    """Request body for user registration."""

    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {"email": "user@example.com", "password": "securePassword123", "display_name": "Jane"},
            ]
        }
    )

    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)  # NIST 2024: length over complexity
    display_name: str = Field(default="", max_length=128)


class LoginRequest(BaseModel):
    """Request body for email/password login."""

    model_config = ConfigDict(
        json_schema_extra={"examples": [{"email": "user@example.com", "password": "your_password"}]}
    )

    email: EmailStr
    password: str = Field(..., min_length=1)


class RefreshRequest(BaseModel):
    refresh_token: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    email: str
    display_name: str
    role: str
    subscription_tier: str
    is_active: bool
    created_at: str


def _user_to_response(user: User) -> UserResponse:
    """Build UserResponse from domain User (single place for /me and future use)."""
    return UserResponse(
        id=str(user.id),
        email=user.email,
        display_name=user.display_name,
        role=user.role.value,
        subscription_tier=user.subscription_tier.value,
        is_active=user.is_active,
        created_at=user.created_at.isoformat() if user.created_at else "",
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/register",
    response_model=TokenResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new user",
)
async def register(
    body: RegisterRequest,
    user_service: UserService = Depends(get_user_service),
):
    """Create a new user account and return JWT tokens."""
    created_user = await user_service.register(
        body.email,
        body.password,
        body.display_name or "",
    )

    access = create_access_token(created_user.id, created_user.email, created_user.role.value)
    refresh = create_refresh_token(created_user.id)

    return TokenResponse(access_token=access, refresh_token=refresh)


@router.post(
    "/token",
    response_model=TokenResponse,
    summary="OAuth2 token (form: username=email, password) - for Swagger Authorize",
)
async def token(
    form: OAuth2PasswordRequestForm = Depends(),
    user_service: UserService = Depends(get_user_service),
):
    """OAuth2-compatible token endpoint. Use username=email, password as form fields.

    Security:
    - Per-email brute-force protection (5 attempts / 5 minutes).
    - UserService.authenticate is timing-safe.
    - Email is normalized (strip, lower) for rate-limit and lookup.
    """
    email = (form.username or "").strip().lower()
    tenant_id = _check_auth_rate_limit(email, "auth_token")

    user = await user_service.authenticate(email, form.password)
    _reset_auth_rate_limit(tenant_id, email, "token")

    access = create_access_token(user.id, user.email, user.role.value)
    refresh = create_refresh_token(user.id)
    return TokenResponse(access_token=access, refresh_token=refresh)


@router.post(
    "/login",
    response_model=TokenResponse,
    summary="Login with email and password (JSON)",
)
async def login(
    body: LoginRequest,
    user_service: UserService = Depends(get_user_service),
):
    """Authenticate with JSON body and return JWT tokens.

    Security:
    - Per-email brute-force protection (5 attempts / 5 minutes).
    - UserService.authenticate is timing-safe.
    - Email is normalized (strip, lower) for rate-limit and lookup.
    """
    email = (body.email or "").strip().lower()
    tenant_id = _check_auth_rate_limit(email, "auth_login")

    user = await user_service.authenticate(email, body.password)
    _reset_auth_rate_limit(tenant_id, email, "login")

    access = create_access_token(user.id, user.email, user.role.value)
    refresh = create_refresh_token(user.id)
    return TokenResponse(access_token=access, refresh_token=refresh)


@router.post(
    "/refresh",
    response_model=TokenResponse,
    summary="Refresh access token",
)
async def refresh(
    body: RefreshRequest,
    user_service: UserService = Depends(get_user_service),
):
    """Exchange a refresh token for a new access + refresh token pair."""
    try:
        payload = decode_token(body.refresh_token)
    except pyjwt.ExpiredSignatureError:
        raise http_error(status.HTTP_401_UNAUTHORIZED, "REFRESH_TOKEN_EXPIRED", "Refresh token has expired")
    except pyjwt.InvalidTokenError:
        raise http_error(status.HTTP_401_UNAUTHORIZED, "INVALID_REFRESH_TOKEN", "Invalid refresh token")

    if payload.get("type") != "refresh":
        raise http_error(status.HTTP_401_UNAUTHORIZED, "NOT_REFRESH_TOKEN", "Token is not a refresh token")

    user_id_str: Optional[str] = payload.get("sub")
    if not user_id_str:
        raise http_error(status.HTTP_401_UNAUTHORIZED, "INVALID_REFRESH_PAYLOAD", "Invalid refresh token payload")
    try:
        user_id = uuid.UUID(user_id_str)
    except (ValueError, TypeError):
        raise http_error(status.HTTP_401_UNAUTHORIZED, "INVALID_REFRESH_PAYLOAD", "Invalid refresh token payload")

    jti: Optional[str] = payload.get("jti")
    if jti:
        if not await _mark_jti_used(jti):
            raise http_error(
                status.HTTP_401_UNAUTHORIZED,
                "REFRESH_TOKEN_REUSED",
                "Refresh token has already been used",
            )

    try:
        user = await user_service.get_by_id(user_id)
    except UserNotFoundError:
        raise http_error(status.HTTP_401_UNAUTHORIZED, "USER_NOT_FOUND", "User not found or deactivated")
    if not user.is_active:
        raise AccountDeactivatedError()

    # JTI already marked as used above (atomic operation)

    access = create_access_token(user.id, user.email, user.role.value)
    new_refresh = create_refresh_token(user.id)

    return TokenResponse(access_token=access, refresh_token=new_refresh)


@router.get(
    "/me",
    response_model=UserResponse,
    summary="Get current user profile",
)
async def me(
    current_user: dict = Depends(get_current_user),
    user_service: UserService = Depends(get_user_service),
):
    """Return the authenticated user's profile. Raises UserNotFoundError (404) if user no longer exists."""
    try:
        user_id = uuid.UUID(current_user["user_id"])
    except (ValueError, TypeError):
        raise http_error(status.HTTP_401_UNAUTHORIZED, "INVALID_TOKEN", "Invalid token")
    user = await user_service.get_by_id(user_id)
    return _user_to_response(user)
