"""Companion / chat API routes.

Includes utility endpoints used by the mobile companion experience, such as
issuing authenticated LiveKit room tokens for voice mode.
"""

from __future__ import annotations

import logging
import os
import re
import uuid
from typing import Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from narrative_ai.api.dependencies import get_current_user
from narrative_ai.api.http_helpers import http_error

router = APIRouter(prefix="/api/companion", tags=["companion"])
logger = logging.getLogger(__name__)


def _env_truthy(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


class VoiceTokenRequest(BaseModel):
    room_name: Optional[str] = Field(
        default=None,
        description="Deprecated. Room names are server-generated per user for isolation.",
    )
    session_id: Optional[str] = Field(
        default=None,
        description="Conversation session ID shared with text chat. Auto-generated if not provided.",
    )
    agent_name: Optional[str] = Field(
        default=None,
        description="Voice agent name. Defaults to LIVEKIT_AGENT_NAME or 'narrative-voice'.",
    )


class VoiceTokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    livekit_url: str
    session_id: str
    room_name: str
    participant_identity: str
    agent_name: str


def _sanitize_room_name(room_name: str) -> str:
    """Keep room names predictable and LiveKit-safe."""
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "-", (room_name or "").strip())
    cleaned = re.sub(r"-{2,}", "-", cleaned).strip("-_")
    return cleaned[:120] if cleaned else "voice-room"


def _normalize_session_id(raw_session_id: Optional[str]) -> str:
    """Return a safe, stable session id for cross-modality conversation state."""
    if raw_session_id and raw_session_id.strip():
        cleaned = _sanitize_room_name(raw_session_id)
        if cleaned:
            return cleaned
    return f"conv-{uuid.uuid4().hex[:12]}"


@router.get("", status_code=501)
@router.post("", status_code=501)
async def companion_not_implemented():
    """
    Companion/chat is not implemented yet (coming soon).

    For now this is a stub endpoint that returns 501 NOT_IMPLEMENTED so clients
    and tests can detect that the companion chat API is not yet wired.
    """
    return {
        "code": "NOT_IMPLEMENTED",
        "message": "Companion/chat API is not implemented yet. Coming soon.",
    }


@router.post("/voice/token", response_model=VoiceTokenResponse, summary="Create authenticated LiveKit voice token")
async def create_voice_token(
    body: VoiceTokenRequest,
    current_user: dict = Depends(get_current_user),
):
    """Issue a LiveKit participant token using the authenticated app user as identity.

    Identity is always `user_id` (UUID) so voice pipeline can resolve profile/RAG
    context for the same user as text chat.
    """
    raw_user_id = current_user.get("user_id")
    try:
        user_id = str(uuid.UUID(str(raw_user_id)))
    except (ValueError, TypeError):
        raise http_error(401, "INVALID_TOKEN", "Invalid token")

    livekit_url = os.getenv("LIVEKIT_URL", "").strip()
    livekit_api_key = os.getenv("LIVEKIT_API_KEY", "").strip()
    livekit_api_secret = os.getenv("LIVEKIT_API_SECRET", "").strip()
    if not livekit_url or not livekit_api_key or not livekit_api_secret:
        raise http_error(
            503,
            "VOICE_NOT_CONFIGURED",
            "Voice service is not configured. Set LIVEKIT_URL, LIVEKIT_API_KEY, and LIVEKIT_API_SECRET.",
        )

    session_id = _normalize_session_id(body.session_id)

    # Enforce server-generated room names to prevent room hopping / impersonation.
    canonical_room_name = _sanitize_room_name(f"voice-{user_id}-{session_id}")
    if body.room_name and _sanitize_room_name(body.room_name) != canonical_room_name:
        raise http_error(400, "CUSTOM_ROOM_NOT_ALLOWED", "Custom room_name is not allowed.")
    room_name = canonical_room_name
    agent_name = (body.agent_name or os.getenv("LIVEKIT_AGENT_NAME", "narrative-voice")).strip() or "narrative-voice"

    try:
        from livekit import api as livekit_api
    except Exception as exc:
        logger.warning("livekit-api package unavailable: %s", exc)
        raise http_error(503, "LIVEKIT_UNAVAILABLE", "LiveKit SDK is not available on the server.")

    try:
        access_token = (
            livekit_api.AccessToken(livekit_api_key, livekit_api_secret)
            .with_identity(user_id)
            .with_grants(
                livekit_api.VideoGrants(
                    room_join=True,
                    room=room_name,
                    can_publish=True,
                    can_subscribe=True,
                )
            )
            .to_jwt()
        )
    except Exception as exc:
        logger.error("Failed to create LiveKit token: %s", exc, exc_info=True)
        raise http_error(500, "VOICE_TOKEN_FAILED", "Could not create voice token.")

    # Ensure agent is dispatched for self-hosted/local setups.
    # This is idempotent (list first, create only if missing).
    # Disable with LIVEKIT_EXPLICIT_DISPATCH=0 when using LiveKit Cloud auto-dispatch.
    explicit_dispatch_enabled = _env_truthy("LIVEKIT_EXPLICIT_DISPATCH", default=True)
    require_dispatch = _env_truthy("LIVEKIT_REQUIRE_EXPLICIT_DISPATCH", default=False)
    if explicit_dispatch_enabled:
        dispatch_error: Optional[str] = None
        lkapi = None
        try:
            lkapi = livekit_api.LiveKitAPI(livekit_url, livekit_api_key, livekit_api_secret)
            try:
                existing_dispatches = await lkapi.agent_dispatch.list_dispatch(room_name)
            except livekit_api.TwirpError as twerr:
                # Some LiveKit deployments return not_found when the room does not
                # exist yet. Create it once, then continue dispatch flow.
                if twerr.code != "not_found":
                    raise
                try:
                    await lkapi.room.create_room(
                        livekit_api.CreateRoomRequest(
                            name=room_name,
                            # Keep short-lived pre-created rooms from lingering.
                            empty_timeout=60,
                        )
                    )
                except livekit_api.TwirpError as create_err:
                    if create_err.code != "already_exists":
                        raise
                existing_dispatches = []
            already_dispatched = any(getattr(d, "agent_name", "") == agent_name for d in (existing_dispatches or []))

            if not already_dispatched:
                await lkapi.agent_dispatch.create_dispatch(
                    livekit_api.CreateAgentDispatchRequest(
                        agent_name=agent_name,
                        room=room_name,
                        metadata=f'{{"user_id":"{user_id}","session_id":"{session_id}"}}',
                    )
                )
                logger.info("Dispatched agent '%s' to room '%s' for user '%s'", agent_name, room_name, user_id)
            else:
                logger.debug("Agent '%s' already dispatched to room '%s'", agent_name, room_name)
        except Exception as exc:
            dispatch_error = f"Could not dispatch voice agent '{agent_name}' to room '{room_name}': {exc}"
            logger.warning(dispatch_error, exc_info=True)
        finally:
            if lkapi is not None:
                try:
                    await lkapi.aclose()
                except Exception:
                    pass

        if dispatch_error and require_dispatch:
            raise http_error(503, "VOICE_DISPATCH_FAILED", dispatch_error)

    return VoiceTokenResponse(
        access_token=access_token,
        livekit_url=livekit_url,
        session_id=session_id,
        room_name=room_name,
        participant_identity=user_id,
        agent_name=agent_name,
    )
