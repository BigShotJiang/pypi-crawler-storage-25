"""VLM captioning API routes."""

from __future__ import annotations

import base64
import binascii
import logging
import time
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, Header, UploadFile
from pydantic import BaseModel, Field

from narrative_ai.api.dependencies import get_user_tenant, get_vlm_service
from narrative_ai.api.http_helpers import http_error
from narrative_ai.application.dto.vlm_dto import CaptionCommand
from narrative_ai.application.services.vlm_service import VLMAppService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/vlm", tags=["vlm"])

MAX_FILE_SIZE_BYTES = 20 * 1024 * 1024
ALLOWED_CONTENT_TYPES = {
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/bmp",
    "image/tiff",
}


class CaptionBase64Request(BaseModel):
    """Base64 image caption request."""

    image_base64: str = Field(..., min_length=1)
    prompt: Optional[str] = None


class CaptionResponse(BaseModel):
    """Caption response model."""

    caption: str
    confidence: float | None
    model: str
    processing_time_ms: int
    correlation_id: str = ""


@router.post("/caption", response_model=CaptionResponse)
async def caption_upload(
    image: UploadFile = File(..., description="Image file"),
    prompt: Optional[str] = Form(None),
    service: VLMAppService = Depends(get_vlm_service),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """Caption an uploaded image file."""
    user_id, tenant_id = user_tenant
    if image.content_type and image.content_type.lower() not in ALLOWED_CONTENT_TYPES:
        raise http_error(415, "UNSUPPORTED_MEDIA_TYPE", f"Unsupported image type: {image.content_type}")

    image_bytes = await image.read()
    if not image_bytes:
        raise http_error(400, "EMPTY_IMAGE", "Uploaded image is empty")
    if len(image_bytes) > MAX_FILE_SIZE_BYTES:
        raise http_error(413, "IMAGE_TOO_LARGE", "Image exceeds 20MB upload limit")

    start = time.perf_counter()
    try:
        result = await service.caption(
            CaptionCommand(
                image=image_bytes,
                prompt=prompt,
                user_id=user_id,
                tenant_id=tenant_id,
                correlation_id=correlation_id,
            )
        )
        processing_ms = int((time.perf_counter() - start) * 1000)
        return CaptionResponse(
            caption=result.caption,
            confidence=result.confidence,
            model=result.model,
            processing_time_ms=processing_ms,
            correlation_id=result.correlation_id or correlation_id or "",
        )
    except ValueError as exc:
        raise http_error(400, "BAD_REQUEST", str(exc)) from exc
    except RuntimeError as exc:
        raise http_error(503, "VLM_FAILED", str(exc)) from exc
    except Exception as exc:
        logger.error("VLM caption upload failed: %s", exc, exc_info=True)
        raise http_error(500, "VLM_CAPTION_FAILED", "Failed to caption image") from exc


@router.post("/caption/base64", response_model=CaptionResponse)
async def caption_base64(
    request: CaptionBase64Request,
    service: VLMAppService = Depends(get_vlm_service),
    user_tenant: tuple[Optional[str], Optional[str]] = Depends(get_user_tenant),
    correlation_id: Optional[str] = Header(None, alias="X-Correlation-ID"),
):
    """Caption an image provided as base64 data."""
    user_id, tenant_id = user_tenant
    payload = request.image_base64
    if "," in payload and payload.strip().startswith("data:"):
        payload = payload.split(",", 1)[1]

    try:
        image_bytes = base64.b64decode(payload, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise http_error(400, "INVALID_BASE64", "Invalid base64 image payload") from exc

    if not image_bytes:
        raise http_error(400, "EMPTY_IMAGE", "Decoded image is empty")
    if len(image_bytes) > MAX_FILE_SIZE_BYTES:
        raise http_error(413, "IMAGE_TOO_LARGE", "Image exceeds 20MB upload limit")

    start = time.perf_counter()
    try:
        result = await service.caption(
            CaptionCommand(
                image=image_bytes,
                prompt=request.prompt,
                user_id=user_id,
                tenant_id=tenant_id,
                correlation_id=correlation_id,
            )
        )
        processing_ms = int((time.perf_counter() - start) * 1000)
        return CaptionResponse(
            caption=result.caption,
            confidence=result.confidence,
            model=result.model,
            processing_time_ms=processing_ms,
            correlation_id=result.correlation_id or correlation_id or "",
        )
    except ValueError as exc:
        raise http_error(400, "BAD_REQUEST", str(exc)) from exc
    except RuntimeError as exc:
        raise http_error(503, "VLM_FAILED", str(exc)) from exc
    except Exception as exc:
        logger.error("VLM caption base64 failed: %s", exc, exc_info=True)
        raise http_error(500, "VLM_CAPTION_FAILED", "Failed to caption image") from exc


@router.get("/status")
async def status(service: VLMAppService = Depends(get_vlm_service)):
    """VLM service status endpoint."""
    try:
        return await service.status()
    except Exception as exc:
        logger.error("VLM status failed: %s", exc, exc_info=True)
        return {"status": "unhealthy", "error": str(exc)}
