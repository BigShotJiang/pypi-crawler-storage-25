"""Export API routes.

Planned: export diary entries (e.g. PDF, JSON) via export domain service.

For now this is a stub endpoint that returns 501 NOT_IMPLEMENTED so clients
and tests can detect that export is not yet wired.
"""

from fastapi import APIRouter

router = APIRouter(prefix="/api/export", tags=["export"])


@router.get("", status_code=501)
@router.post("", status_code=501)
async def export_not_implemented():
    """Export is not implemented yet (export service coming soon)."""
    return {
        "code": "NOT_IMPLEMENTED",
        "message": "Export is not implemented yet. Export service coming soon.",
    }
