"""
Narrative AI SDK - Central entry point for all AI engines.
Modular structure: narrative_ai.engines.<engine>.api
"""

from .engines.llm import api as llm
from .engines.ocr import api as ocr
from .engines.stt import api as stt
from .engines.tts import api as tts
from .engines.rag import api as rag
from .engines.vlm import api as vlm
from .engines.input_processor import api as input_processor
from .engines.web_intel import api as web_intel
from .engines.voice_mode import api as voice_mode

__all__ = [
    "llm",
    "ocr",
    "stt",
    "tts",
    "rag",
    "vlm",
    "input_processor",
    "web_intel",
    "voice_mode",
]

__version__ = "0.1.0"
