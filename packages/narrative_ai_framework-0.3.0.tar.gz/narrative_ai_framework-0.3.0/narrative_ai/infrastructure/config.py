"""Aggregate infrastructure configuration.

Provides a single entry-point for loading database, cache, and vector
configs from environment variables.
"""

from __future__ import annotations

from dataclasses import dataclass

from .database.config import DatabaseConfig
from .cache.config import CacheConfig
from .vector.config import VectorConfig


@dataclass
class InfrastructureConfig:
    """Combined configuration for all infrastructure services."""

    database: DatabaseConfig
    cache: CacheConfig
    vector: VectorConfig

    @classmethod
    def from_env(cls) -> "InfrastructureConfig":
        return cls(
            database=DatabaseConfig.from_env(),
            cache=CacheConfig.from_env(),
            vector=VectorConfig.from_env(),
        )
