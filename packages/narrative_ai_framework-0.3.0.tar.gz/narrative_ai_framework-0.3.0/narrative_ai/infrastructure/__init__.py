"""Infrastructure layer -- adapters for databases, caches, and external services.

This layer contains concrete implementations of the domain repository
interfaces, plus cache, vector store, and file storage adapters.
"""
