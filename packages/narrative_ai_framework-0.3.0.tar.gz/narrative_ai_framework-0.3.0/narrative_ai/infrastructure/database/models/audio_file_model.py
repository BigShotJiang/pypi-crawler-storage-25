"""Audio file ORM model."""

from __future__ import annotations

from sqlalchemy import Column, DateTime, Float, ForeignKey, Index, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import Base, utcnow, uuid_default


class AudioFileModel(Base):
    __tablename__ = "audio_files"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid_default)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    file_type = Column(String(32), nullable=False, default="input")
    storage_path = Column(String(1024), nullable=False, default="")
    duration_seconds = Column(Float, nullable=False, default=0.0)
    voice_used = Column(String(64), nullable=True)
    quality = Column(String(16), nullable=False, default="high")
    format = Column(String(16), nullable=False, default="mp3")
    conversation_id = Column(UUID(as_uuid=True), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    expires_at = Column(DateTime(timezone=True), nullable=True)

    user = relationship("UserModel", back_populates="audio_files")

    __table_args__ = (
        Index("ix_audio_files_user", "user_id"),
        Index("ix_audio_files_expires", "expires_at"),
    )
