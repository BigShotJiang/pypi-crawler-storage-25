"""Diary embedding ORM model (pgvector)."""

from __future__ import annotations

from sqlalchemy import Column, DateTime, ForeignKey, Index, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import Base, utcnow, uuid_default


class DiaryEmbeddingModel(Base):
    """Stores 768-D dense vectors for semantic search.

    Requires the pgvector extension. At runtime the pgvector_store
    module handles read/write through raw SQL.
    """

    __tablename__ = "diary_embeddings"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid_default)
    entry_id = Column(
        UUID(as_uuid=True),
        ForeignKey("diary_entries.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
    )
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    embedding = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)

    entry = relationship("DiaryEntryModel", back_populates="embedding")

    __table_args__ = (Index("ix_diary_embeddings_user", "user_id"),)
