"""Diary entry ORM model."""

from __future__ import annotations

from sqlalchemy import Column, DateTime, ForeignKey, Index, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import relationship

from .base import Base, utcnow, uuid_default


class DiaryEntryModel(Base):
    __tablename__ = "diary_entries"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid_default)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    raw_text = Column(Text, nullable=False, default="")
    enhanced_text = Column(Text, nullable=False, default="")
    emotion = Column(String(32), nullable=False, default="neutral")
    source_type = Column(String(16), nullable=False, default="text")  # voice|text|image|file
    tags = Column(ARRAY(String), nullable=False, server_default="{}")
    audio_storage_path = Column(String(512), nullable=True)

    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = Column(DateTime(timezone=True), nullable=True, onupdate=utcnow)
    deleted_at = Column(DateTime(timezone=True), nullable=True)  # soft delete

    # Relationships
    user = relationship("UserModel", back_populates="entries")
    embedding = relationship("DiaryEmbeddingModel", back_populates="entry", uselist=False, lazy="selectin")
    media = relationship("EntryMediaModel", back_populates="entry", lazy="selectin", cascade="all, delete-orphan")

    __table_args__ = (
        Index("ix_diary_entries_user_created", "user_id", "created_at"),
        Index("ix_diary_entries_user_emotion", "user_id", "emotion"),
    )
