"""User preference ORM model."""

from __future__ import annotations

from sqlalchemy import Column, DateTime, Float, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import Base, utcnow, uuid_default


class UserPreferenceModel(Base):
    __tablename__ = "user_preferences"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid_default)
    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
    )
    preferred_voice = Column(String(64), nullable=False, default="fatima")
    speaking_rate = Column(Float, nullable=False, default=1.0)
    audio_quality = Column(String(16), nullable=False, default="high")
    language = Column(String(16), nullable=False, default="ar-EG")
    theme = Column(String(16), nullable=False, default="system")
    updated_at = Column(DateTime(timezone=True), nullable=True, onupdate=utcnow)

    user = relationship("UserModel", back_populates="preferences")
