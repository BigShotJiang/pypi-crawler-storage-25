"""Conversation message ORM model."""

from __future__ import annotations

from sqlalchemy import Column, DateTime, ForeignKey, Index, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import Base, utcnow, uuid_default


class ConversationMessageModel(Base):
    __tablename__ = "conversation_messages"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid_default)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey("conversations.id", ondelete="CASCADE"), nullable=False)
    role = Column(String(16), nullable=False)
    content = Column(Text, nullable=False, default="")
    audio_url = Column(String(1024), nullable=True)
    sources_json = Column(Text, nullable=True)
    emotion = Column(String(32), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)

    conversation = relationship("ConversationModel", back_populates="messages")

    __table_args__ = (Index("ix_conv_messages_conv_id", "conversation_id"),)
