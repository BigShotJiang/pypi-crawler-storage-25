"""User ORM model."""

from __future__ import annotations

from sqlalchemy import Boolean, Column, DateTime, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import Base, utcnow, uuid_default


class UserModel(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid_default)
    email = Column(String(320), unique=True, nullable=False, index=True)
    password_hash = Column(String(256), nullable=False)
    display_name = Column(String(128), nullable=False, default="")
    role = Column(String(16), nullable=False, default="user")
    subscription_tier = Column(String(16), nullable=False, default="free")
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = Column(DateTime(timezone=True), nullable=True, onupdate=utcnow)

    entries = relationship("DiaryEntryModel", back_populates="user", lazy="selectin")
    conversations = relationship("ConversationModel", back_populates="user", lazy="selectin")
    audio_files = relationship("AudioFileModel", back_populates="user", lazy="selectin")
    preferences = relationship("UserPreferenceModel", back_populates="user", uselist=False, lazy="selectin")
