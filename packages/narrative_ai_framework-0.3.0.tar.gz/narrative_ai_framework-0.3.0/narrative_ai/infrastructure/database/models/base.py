"""Shared declarative base and helpers for ORM models."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Shared declarative base for all ORM models."""

    pass


def utcnow() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(timezone.utc)


def uuid_default() -> uuid.UUID:
    """Return a new UUID for column defaults."""
    return uuid.uuid4()
