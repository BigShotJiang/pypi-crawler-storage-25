"""Export job ORM model."""

from __future__ import annotations

from sqlalchemy import Column, DateTime, ForeignKey, Index, String
from sqlalchemy.dialects.postgresql import UUID

from .base import Base, utcnow, uuid_default


class ExportJobModel(Base):
    __tablename__ = "export_jobs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid_default)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    format = Column(String(16), nullable=False, default="pdf")
    status = Column(String(16), nullable=False, default="pending")
    storage_path = Column(String(1024), nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    completed_at = Column(DateTime(timezone=True), nullable=True)

    __table_args__ = (Index("ix_export_jobs_user", "user_id"),)
