"""Conversation ORM model."""

from __future__ import annotations

from sqlalchemy import Column, DateTime, ForeignKey, Index, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import Base, utcnow, uuid_default


class ConversationModel(Base):
    __tablename__ = "conversations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid_default)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    title = Column(String(256), nullable=False, default="")
    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)
    updated_at = Column(DateTime(timezone=True), nullable=True, onupdate=utcnow)

    user = relationship("UserModel", back_populates="conversations")
    messages = relationship(
        "ConversationMessageModel",
        back_populates="conversation",
        order_by="ConversationMessageModel.created_at",
        lazy="selectin",
    )

    __table_args__ = (Index("ix_conversations_user_updated", "user_id", "updated_at"),)
