"""Entry media (images, etc.) ORM model."""

from __future__ import annotations

from sqlalchemy import Column, DateTime, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import Base, utcnow, uuid_default


class EntryMediaModel(Base):
    __tablename__ = "entry_media"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid_default)
    entry_id = Column(UUID(as_uuid=True), ForeignKey("diary_entries.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)

    storage_path = Column(String(1024), nullable=False)
    media_type = Column(String(32), nullable=False, default="image")  # image | video
    caption = Column(Text, nullable=True)

    created_at = Column(DateTime(timezone=True), nullable=False, default=utcnow)

    entry = relationship("DiaryEntryModel", back_populates="media")
