"""ORM models package -- one model per file.

All model definitions live in this package. Each module defines a single
ORM model class. Import from this package for use in repositories, services, etc.

Models such as AnalyticsEventModel, ExportJobModel, SubscriptionModel support
future features (analytics, export, subscriptions) and are part of the schema
and migrations; routes will be wired when those features are implemented.
"""

from .analytics_event_model import AnalyticsEventModel
from .audit_log_model import AuditLogModel
from .audio_file_model import AudioFileModel
from .base import Base, utcnow, uuid_default
from .conversation_message_model import ConversationMessageModel
from .conversation_model import ConversationModel
from .diary_embedding_model import DiaryEmbeddingModel
from .diary_entry_model import DiaryEntryModel
from .entry_media_model import EntryMediaModel
from .export_job_model import ExportJobModel
from .subscription_model import SubscriptionModel
from .user_model import UserModel
from .user_preference_model import UserPreferenceModel

__all__ = [
    "Base",
    "utcnow",
    "uuid_default",
    "UserModel",
    "DiaryEntryModel",
    "DiaryEmbeddingModel",
    "EntryMediaModel",
    "ConversationModel",
    "ConversationMessageModel",
    "AudioFileModel",
    "UserPreferenceModel",
    "SubscriptionModel",
    "ExportJobModel",
    "AnalyticsEventModel",
    "AuditLogModel",
]
