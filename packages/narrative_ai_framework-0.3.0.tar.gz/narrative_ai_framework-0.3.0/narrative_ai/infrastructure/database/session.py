"""Convenience helpers for obtaining an async database session.

In FastAPI these are used as dependencies::

    from narrative_ai.infrastructure.database.session import get_db

    @router.get("/entries")
    async def list_entries(db: AsyncSession = Depends(get_db)):
        ...

Outside FastAPI (scripts, tests, CLI) use the context-manager form::

    async with async_session_scope() as session:
        ...
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator, Optional

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from .connection import get_engine, get_session_factory

logger = logging.getLogger(__name__)

_factory: Optional[async_sessionmaker[AsyncSession]] = None


def _get_factory() -> async_sessionmaker[AsyncSession]:
    global _factory
    if _factory is None:
        _factory = get_session_factory(get_engine())
    return _factory


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency that yields an ``AsyncSession``.

    The session is committed on success and rolled back on exception.
    """
    factory = _get_factory()
    async with factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


@asynccontextmanager
async def async_session_scope() -> AsyncGenerator[AsyncSession, None]:
    """Context-manager wrapper around :func:`get_db` for non-FastAPI code."""
    factory = _get_factory()
    async with factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
