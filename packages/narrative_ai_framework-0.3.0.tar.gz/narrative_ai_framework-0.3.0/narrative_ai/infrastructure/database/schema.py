"""SQLAlchemy ORM schema -- re-exports from models for backward compatibility.

The canonical model definitions live in ``framework.infrastructure.database.models``.
This module re-exports them so that:
- Alembic's ``env.py`` can continue importing ``Base`` from here
- Existing code importing from ``schema`` continues to work

All tables live in **one** PostgreSQL database. The pgvector extension is
required for the ``diary_embeddings`` table.
"""

from __future__ import annotations

from narrative_ai.infrastructure.database.models import (
    AnalyticsEventModel,
    AuditLogModel,
    AudioFileModel,
    Base,
    ConversationModel,
    ConversationMessageModel,
    DiaryEmbeddingModel,
    DiaryEntryModel,
    ExportJobModel,
    SubscriptionModel,
    UserModel,
    UserPreferenceModel,
)

__all__ = [
    "Base",
    "UserModel",
    "DiaryEntryModel",
    "DiaryEmbeddingModel",
    "ConversationModel",
    "ConversationMessageModel",
    "AudioFileModel",
    "UserPreferenceModel",
    "SubscriptionModel",
    "ExportJobModel",
    "AnalyticsEventModel",
    "AuditLogModel",
]
