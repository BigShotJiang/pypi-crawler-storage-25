"""Concrete async diary-entry repository backed by PostgreSQL."""

from __future__ import annotations

import uuid
from collections import Counter
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy import and_, func, select

from narrative_ai.domain.entities.diary_entry import DiaryEntry, SourceType
from narrative_ai.domain.exceptions import EntryNotFoundError
from narrative_ai.domain.repositories.entry_repository import EntryRepository
from narrative_ai.infrastructure.database.models import DiaryEntryModel
from .base_repository import BaseRepository


class PostgresEntryRepository(BaseRepository[DiaryEntryModel], EntryRepository):
    """PostgreSQL implementation of :class:`EntryRepository`."""

    model_class = DiaryEntryModel

    # ------------------------------------------------------------------
    # Mapping helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _to_domain(row: DiaryEntryModel) -> DiaryEntry:
        return DiaryEntry(
            id=row.id,
            user_id=row.user_id,
            raw_text=row.raw_text,
            enhanced_text=row.enhanced_text,
            emotion=row.emotion,
            source_type=SourceType(row.source_type),
            tags=list(row.tags) if row.tags else [],
            audio_storage_path=row.audio_storage_path,
            created_at=row.created_at,
            updated_at=row.updated_at,
            deleted_at=row.deleted_at,
        )

    @staticmethod
    def _to_model(entry: DiaryEntry) -> DiaryEntryModel:
        return DiaryEntryModel(
            id=entry.id,
            user_id=entry.user_id,
            raw_text=entry.raw_text,
            enhanced_text=entry.enhanced_text,
            emotion=entry.emotion,
            source_type=entry.source_type.value if isinstance(entry.source_type, SourceType) else entry.source_type,
            tags=entry.tags,
            audio_storage_path=entry.audio_storage_path,
            created_at=entry.created_at,
            updated_at=entry.updated_at,
            deleted_at=entry.deleted_at,
        )

    # ------------------------------------------------------------------
    # Interface implementation
    # ------------------------------------------------------------------

    async def create(self, entry: DiaryEntry) -> DiaryEntry:
        model = self._to_model(entry)
        model = await self._add(model)
        return self._to_domain(model)

    async def get_by_id(
        self,
        entry_id: uuid.UUID,
        *,
        user_id: uuid.UUID,
        include_deleted: bool = False,
    ) -> Optional[DiaryEntry]:
        filters = [
            DiaryEntryModel.id == entry_id,
            DiaryEntryModel.user_id == user_id,
        ]
        if not include_deleted:
            filters.append(DiaryEntryModel.deleted_at == None)  # noqa: E711
        stmt = select(DiaryEntryModel).where(and_(*filters))
        result = await self._session.execute(stmt)
        row = result.scalar_one_or_none()
        return self._to_domain(row) if row else None

    async def update(self, entry: DiaryEntry) -> DiaryEntry:
        row = await self._get_by_id(entry.id)
        if row is None:
            raise EntryNotFoundError(entry_id=entry.id, user_id=entry.user_id)
        row.raw_text = entry.raw_text
        row.enhanced_text = entry.enhanced_text
        row.emotion = entry.emotion
        row.tags = entry.tags
        row.audio_storage_path = entry.audio_storage_path
        row.updated_at = datetime.now(timezone.utc)
        row.deleted_at = entry.deleted_at
        await self._session.flush()
        await self._session.refresh(row)
        return self._to_domain(row)

    async def soft_delete(self, entry_id: uuid.UUID, *, user_id: uuid.UUID) -> None:
        row = await self._get_by_id(entry_id)
        if row is None or row.user_id != user_id:
            raise EntryNotFoundError(entry_id=entry_id, user_id=user_id)
        row.deleted_at = datetime.now(timezone.utc)
        await self._session.flush()

    async def list_entries(
        self,
        *,
        user_id: uuid.UUID,
        offset: int = 0,
        limit: int = 20,
        emotion: Optional[str] = None,
        tag: Optional[str] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        include_deleted: bool = False,
    ) -> List[DiaryEntry]:
        filters = [DiaryEntryModel.user_id == user_id]
        if not include_deleted:
            filters.append(DiaryEntryModel.deleted_at == None)  # noqa: E711
        if emotion:
            filters.append(DiaryEntryModel.emotion == emotion)
        if tag:
            filters.append(DiaryEntryModel.tags.any(tag))
        if date_from:
            filters.append(DiaryEntryModel.created_at >= date_from)
        if date_to:
            filters.append(DiaryEntryModel.created_at <= date_to)

        rows = await self._list(
            *filters,
            offset=offset,
            limit=limit,
            order_by=DiaryEntryModel.created_at.desc(),
        )
        return [self._to_domain(r) for r in rows]

    async def count(
        self,
        *,
        user_id: uuid.UUID,
        emotion: Optional[str] = None,
        tag: Optional[str] = None,
        date_from: Optional[datetime] = None,
        date_to: Optional[datetime] = None,
        include_deleted: bool = False,
    ) -> int:
        filters = [DiaryEntryModel.user_id == user_id]
        if not include_deleted:
            filters.append(DiaryEntryModel.deleted_at == None)  # noqa: E711
        if emotion:
            filters.append(DiaryEntryModel.emotion == emotion)
        if tag:
            filters.append(DiaryEntryModel.tags.any(tag))
        if date_from:
            filters.append(DiaryEntryModel.created_at >= date_from)
        if date_to:
            filters.append(DiaryEntryModel.created_at <= date_to)
        return await self._count(*filters)

    async def get_user_stats(self, user_id: uuid.UUID) -> Dict[str, Any]:
        """Aggregate diary stats for the user profile cache.

        Returns a dict with:
          - entry_count (int)
          - top_emotions (List[str], up to 3)
          - top_tags (List[str], up to 5)
          - recent_topics (List[str], up to 5 — derived from tags of last 10 entries)
          - first_entry_date (str ISO date or None)
          - last_entry_date (str ISO date or None)
          - preferred_language (str, always "en" for now — extend later)
        """
        base_filter = and_(
            DiaryEntryModel.user_id == user_id,
            DiaryEntryModel.deleted_at == None,  # noqa: E711
        )

        # --- entry count ---
        count_stmt = select(func.count()).select_from(DiaryEntryModel).where(base_filter)
        count_result = await self._session.execute(count_stmt)
        entry_count: int = count_result.scalar_one() or 0

        if entry_count == 0:
            return {
                "entry_count": 0,
                "top_emotions": [],
                "top_tags": [],
                "recent_topics": [],
                "first_entry_date": None,
                "last_entry_date": None,
                "preferred_language": "en",
            }

        # --- date range ---
        date_stmt = select(
            func.min(DiaryEntryModel.created_at),
            func.max(DiaryEntryModel.created_at),
        ).where(base_filter)
        date_result = await self._session.execute(date_stmt)
        first_dt, last_dt = date_result.one()
        first_entry_date = first_dt.date().isoformat() if first_dt else None
        last_entry_date = last_dt.date().isoformat() if last_dt else None

        # --- top emotions (fetch all, count in Python) ---
        emotion_stmt = (
            select(DiaryEntryModel.emotion).where(base_filter).where(DiaryEntryModel.emotion != None)  # noqa: E711
        )
        emotion_rows = (await self._session.execute(emotion_stmt)).scalars().all()
        top_emotions = [e for e, _ in Counter(emotion_rows).most_common(3) if e]

        # --- top tags (fetch all, flatten, count in Python) ---
        tag_stmt = select(DiaryEntryModel.tags).where(base_filter).where(DiaryEntryModel.tags != None)  # noqa: E711
        tag_rows = (await self._session.execute(tag_stmt)).scalars().all()
        all_tags: List[str] = [t for row in tag_rows if row for t in row]
        top_tags = [t for t, _ in Counter(all_tags).most_common(5)]

        # --- recent topics: tags from the last 10 entries ---
        recent_stmt = (
            select(DiaryEntryModel.tags).where(base_filter).order_by(DiaryEntryModel.created_at.desc()).limit(10)
        )
        recent_rows = (await self._session.execute(recent_stmt)).scalars().all()
        recent_tags: List[str] = [t for row in recent_rows if row for t in row]
        # Deduplicate while preserving order
        seen: set = set()
        recent_topics: List[str] = []
        for t in recent_tags:
            if t not in seen:
                seen.add(t)
                recent_topics.append(t)
            if len(recent_topics) >= 5:
                break

        return {
            "entry_count": entry_count,
            "top_emotions": top_emotions,
            "top_tags": top_tags,
            "recent_topics": recent_topics,
            "first_entry_date": first_entry_date,
            "last_entry_date": last_entry_date,
            "preferred_language": "en",  # TODO: detect from text content
        }
