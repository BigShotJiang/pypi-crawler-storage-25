"""Concrete async conversation repository backed by PostgreSQL."""

from __future__ import annotations

import uuid
from typing import List, Optional

from sqlalchemy import select, delete as sa_delete, and_

from narrative_ai.domain.entities.conversation import (
    Conversation,
    ConversationMessage,
    MessageRole,
)
from narrative_ai.domain.repositories.conversation_repository import ConversationRepository
from narrative_ai.infrastructure.database.models import (
    ConversationModel,
    ConversationMessageModel,
)
from .base_repository import BaseRepository


class PostgresConversationRepository(BaseRepository[ConversationModel], ConversationRepository):
    """PostgreSQL implementation of :class:`ConversationRepository`."""

    model_class = ConversationModel

    # ------------------------------------------------------------------
    # Mapping helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _msg_to_domain(row: ConversationMessageModel) -> ConversationMessage:
        return ConversationMessage(
            id=row.id,
            conversation_id=row.conversation_id,
            role=MessageRole(row.role),
            content=row.content,
            audio_url=row.audio_url,
            sources_json=row.sources_json,
            emotion=row.emotion,
            created_at=row.created_at,
        )

    @classmethod
    def _to_domain(cls, row: ConversationModel) -> Conversation:
        msgs = [cls._msg_to_domain(m) for m in (row.messages or [])]
        return Conversation(
            id=row.id,
            user_id=row.user_id,
            title=row.title,
            messages=msgs,
            created_at=row.created_at,
            updated_at=row.updated_at,
        )

    @classmethod
    def _to_domain_light(cls, row: ConversationModel) -> Conversation:
        """Map without loading messages (for listing)."""
        return Conversation(
            id=row.id,
            user_id=row.user_id,
            title=row.title,
            messages=[],
            created_at=row.created_at,
            updated_at=row.updated_at,
        )

    # ------------------------------------------------------------------
    # Interface implementation
    # ------------------------------------------------------------------

    async def create(self, conversation: Conversation) -> Conversation:
        model = ConversationModel(
            id=conversation.id,
            user_id=conversation.user_id,
            title=conversation.title,
            created_at=conversation.created_at,
            updated_at=conversation.updated_at,
        )
        model = await self._add(model)
        return self._to_domain(model)

    async def get_by_id(
        self,
        conversation_id: uuid.UUID,
        *,
        user_id: uuid.UUID,
    ) -> Optional[Conversation]:
        stmt = select(ConversationModel).where(
            and_(
                ConversationModel.id == conversation_id,
                ConversationModel.user_id == user_id,
            )
        )
        result = await self._session.execute(stmt)
        row = result.scalar_one_or_none()
        return self._to_domain(row) if row else None

    async def add_message(self, message: ConversationMessage) -> ConversationMessage:
        model = ConversationMessageModel(
            id=message.id,
            conversation_id=message.conversation_id,
            role=message.role.value if isinstance(message.role, MessageRole) else message.role,
            content=message.content,
            audio_url=message.audio_url,
            sources_json=message.sources_json,
            emotion=message.emotion,
            created_at=message.created_at,
        )
        self._session.add(model)
        await self._session.flush()
        await self._session.refresh(model)
        return self._msg_to_domain(model)

    async def list_conversations(
        self,
        *,
        user_id: uuid.UUID,
        offset: int = 0,
        limit: int = 20,
    ) -> List[Conversation]:
        stmt = (
            select(ConversationModel)
            .where(ConversationModel.user_id == user_id)
            .order_by(ConversationModel.updated_at.desc().nullslast())
            .offset(offset)
            .limit(limit)
        )
        result = await self._session.execute(stmt)
        rows = result.scalars().all()
        return [self._to_domain_light(r) for r in rows]

    async def delete(
        self,
        conversation_id: uuid.UUID,
        *,
        user_id: uuid.UUID,
    ) -> None:
        # CASCADE deletes messages automatically
        stmt = sa_delete(ConversationModel).where(
            and_(
                ConversationModel.id == conversation_id,
                ConversationModel.user_id == user_id,
            )
        )
        await self._session.execute(stmt)
        await self._session.flush()
