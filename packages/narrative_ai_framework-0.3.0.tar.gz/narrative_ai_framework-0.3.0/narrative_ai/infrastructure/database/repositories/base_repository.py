"""Base repository with common CRUD helpers for async SQLAlchemy."""

from __future__ import annotations

import logging
import uuid
from typing import Any, Generic, List, Optional, Type, TypeVar

from sqlalchemy import select, func, delete as sa_delete
from sqlalchemy.ext.asyncio import AsyncSession

from narrative_ai.infrastructure.database.models import Base

T = TypeVar("T", bound=Base)
logger = logging.getLogger(__name__)


class BaseRepository(Generic[T]):
    """Thin async wrapper around common SQLAlchemy operations.

    Subclasses set ``model_class`` and add domain-specific queries.
    """

    model_class: Type[T]

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    # ------------------------------------------------------------------
    # CRUD primitives
    # ------------------------------------------------------------------

    async def _add(self, instance: T) -> T:
        self._session.add(instance)
        await self._session.flush()
        await self._session.refresh(instance)
        return instance

    async def _get_by_id(self, row_id: uuid.UUID) -> Optional[T]:
        return await self._session.get(self.model_class, row_id)

    async def _list(
        self,
        *filters: Any,
        offset: int = 0,
        limit: int = 50,
        order_by: Any = None,
    ) -> List[T]:
        stmt = select(self.model_class).where(*filters)
        if order_by is not None:
            stmt = stmt.order_by(order_by)
        stmt = stmt.offset(offset).limit(limit)
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def _count(self, *filters: Any) -> int:
        stmt = select(func.count()).select_from(self.model_class).where(*filters)
        result = await self._session.execute(stmt)
        return result.scalar_one()

    async def _delete(self, row_id: uuid.UUID) -> None:
        stmt = sa_delete(self.model_class).where(self.model_class.id == row_id)
        await self._session.execute(stmt)
        await self._session.flush()
