"""PostgreSQL implementation for persisting analytics events (e.g. notification analytics)."""

from __future__ import annotations

import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from narrative_ai.infrastructure.database.models import AnalyticsEventModel
from narrative_ai.infrastructure.database.models.base import utcnow, uuid_default


class PostgresAnalyticsEventRepository:
    """Bulk-insert analytics events for a user. No domain interface; used only by API layer."""

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def add_events(self, user_id: uuid.UUID, events: list[dict[str, Any]]) -> int:
        """Insert multiple events for the given user. Returns the number inserted."""
        if not events:
            return 0
        user_uuid = user_id if isinstance(user_id, uuid.UUID) else uuid.UUID(str(user_id))
        rows = []
        for ev in events:
            event_type = ev.get("event_type") or ""
            metadata = ev.get("metadata") or {}
            rows.append(
                AnalyticsEventModel(
                    id=uuid_default(),
                    user_id=user_uuid,
                    event_type=event_type[:64],  # column is String(64)
                    event_metadata=metadata,
                    created_at=utcnow(),
                )
            )
        self._session.add_all(rows)
        await self._session.flush()
        return len(rows)
