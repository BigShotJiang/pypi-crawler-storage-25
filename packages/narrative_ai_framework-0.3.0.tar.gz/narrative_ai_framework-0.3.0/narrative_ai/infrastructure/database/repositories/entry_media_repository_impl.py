"""Entry media repository: list/add/delete media for diary entries."""

from __future__ import annotations

import uuid
from typing import List

from sqlalchemy import select

from narrative_ai.infrastructure.database.models import EntryMediaModel
from .base_repository import BaseRepository


class PostgresEntryMediaRepository(BaseRepository[EntryMediaModel]):
    model_class = EntryMediaModel

    async def add(
        self,
        entry_id: uuid.UUID,
        user_id: uuid.UUID,
        storage_path: str,
        media_type: str = "image",
        caption: str | None = None,
        media_id: uuid.UUID | None = None,
    ) -> EntryMediaModel:
        kwargs = dict(
            entry_id=entry_id,
            user_id=user_id,
            storage_path=storage_path,
            media_type=media_type,
            caption=caption,
        )
        if media_id is not None:
            kwargs["id"] = media_id
        row = EntryMediaModel(**kwargs)
        return await self._add(row)

    async def list_by_entry_id(self, entry_id: uuid.UUID) -> List[EntryMediaModel]:
        stmt = select(EntryMediaModel).where(EntryMediaModel.entry_id == entry_id).order_by(EntryMediaModel.created_at)
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def list_by_entry_ids(self, entry_ids: List[uuid.UUID]) -> List[EntryMediaModel]:
        if not entry_ids:
            return []
        stmt = (
            select(EntryMediaModel)
            .where(EntryMediaModel.entry_id.in_(entry_ids))
            .order_by(EntryMediaModel.entry_id, EntryMediaModel.created_at)
        )
        result = await self._session.execute(stmt)
        return list(result.scalars().all())

    async def get_by_id(self, media_id: uuid.UUID) -> EntryMediaModel | None:
        return await self._session.get(EntryMediaModel, media_id)

    async def delete(self, media_id: uuid.UUID) -> None:
        await self._delete(media_id)
