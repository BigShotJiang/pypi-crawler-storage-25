"""Concrete async user repository backed by PostgreSQL."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import List, Optional

from sqlalchemy import select

from narrative_ai.domain.entities.user import User, UserRole, SubscriptionTier
from narrative_ai.domain.repositories.user_repository import UserRepository
from narrative_ai.infrastructure.database.models import UserModel
from .base_repository import BaseRepository


class PostgresUserRepository(BaseRepository[UserModel], UserRepository):
    """PostgreSQL implementation of :class:`UserRepository`."""

    model_class = UserModel

    # ------------------------------------------------------------------
    # Mapping helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _to_domain(row: UserModel) -> User:
        return User(
            id=row.id,
            email=row.email,
            password_hash=row.password_hash,
            display_name=row.display_name,
            role=UserRole(row.role),
            subscription_tier=SubscriptionTier(row.subscription_tier),
            is_active=row.is_active,
            created_at=row.created_at,
            updated_at=row.updated_at,
        )

    @staticmethod
    def _to_model(user: User) -> UserModel:
        return UserModel(
            id=user.id,
            email=user.email,
            password_hash=user.password_hash,
            display_name=user.display_name,
            role=user.role.value,
            subscription_tier=user.subscription_tier.value,
            is_active=user.is_active,
            created_at=user.created_at,
            updated_at=user.updated_at,
        )

    # ------------------------------------------------------------------
    # Interface implementation
    # ------------------------------------------------------------------

    async def create(self, user: User) -> User:
        model = self._to_model(user)
        model = await self._add(model)
        return self._to_domain(model)

    async def get_by_id(self, user_id: uuid.UUID) -> Optional[User]:
        row = await self._get_by_id(user_id)
        return self._to_domain(row) if row else None

    async def get_by_email(self, email: str) -> Optional[User]:
        stmt = select(UserModel).where(UserModel.email == email)
        result = await self._session.execute(stmt)
        row = result.scalar_one_or_none()
        return self._to_domain(row) if row else None

    async def update(self, user: User) -> User:
        row = await self._get_by_id(user.id)
        if row is None:
            raise ValueError(f"User {user.id} not found")
        row.email = user.email
        row.display_name = user.display_name
        row.role = user.role.value
        row.subscription_tier = user.subscription_tier.value
        row.is_active = user.is_active
        row.updated_at = datetime.now(timezone.utc)
        await self._session.flush()
        await self._session.refresh(row)
        return self._to_domain(row)

    async def delete(self, user_id: uuid.UUID) -> None:
        await self._delete(user_id)

    async def list_users(
        self,
        *,
        offset: int = 0,
        limit: int = 50,
        active_only: bool = True,
    ) -> List[User]:
        filters = []
        if active_only:
            filters.append(UserModel.is_active == True)  # noqa: E712
        rows = await self._list(
            *filters,
            offset=offset,
            limit=limit,
            order_by=UserModel.created_at.desc(),
        )
        return [self._to_domain(r) for r in rows]
