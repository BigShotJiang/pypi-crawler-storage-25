"""Concrete async search / embedding repository using pgvector."""

from __future__ import annotations

import logging
import uuid
from typing import List

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from narrative_ai.domain.repositories.search_repository import (
    SearchRepository,
    SearchResult,
)

logger = logging.getLogger(__name__)


class PgvectorSearchRepository(SearchRepository):
    """pgvector-backed semantic search using HNSW indexes.

    Uses raw SQL because SQLAlchemy's ORM does not natively support
    the ``vector`` type.  The HNSW index is created by migration 003.
    """

    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def store_embedding(
        self,
        entry_id: uuid.UUID,
        user_id: uuid.UUID,
        embedding: List[float],
    ) -> None:
        vector_str = "[" + ",".join(str(f) for f in embedding) + "]"
        stmt = text(
            """
            INSERT INTO diary_embeddings (id, entry_id, user_id, embedding)
            VALUES (:id, :entry_id, :user_id, :embedding::vector)
            ON CONFLICT (entry_id)
            DO UPDATE SET embedding = EXCLUDED.embedding
            """
        )
        await self._session.execute(
            stmt,
            {
                "id": uuid.uuid4(),
                "entry_id": entry_id,
                "user_id": user_id,
                "embedding": vector_str,
            },
        )
        await self._session.flush()

    async def search(
        self,
        query_embedding: List[float],
        *,
        user_id: uuid.UUID,
        top_k: int = 5,
        min_similarity: float = 0.0,
    ) -> List[SearchResult]:
        """Find the *top_k* most similar entries using cosine distance.

        pgvector's ``<=>`` operator computes cosine distance (0 = identical,
        2 = opposite).  We convert to a similarity score in [0, 1] via
        ``1 - distance``.

        The HNSW index makes this O(log N) even with millions of vectors.
        Set ``ef_search`` for the session to tune accuracy vs. speed.
        """
        vector_str = "[" + ",".join(str(f) for f in query_embedding) + "]"

        # Optionally tune ef_search for this session (trade recall for speed)
        await self._session.execute(text("SET LOCAL hnsw.ef_search = 40"))

        stmt = text(
            """
            SELECT
                de.entry_id,
                1 - (de.embedding <=> :query::vector) AS similarity,
                e.enhanced_text,
                e.emotion,
                e.created_at::text
            FROM diary_embeddings de
            JOIN diary_entries e ON e.id = de.entry_id
            WHERE de.user_id = :user_id
              AND e.deleted_at IS NULL
            ORDER BY de.embedding <=> :query::vector
            LIMIT :top_k
            """
        )
        result = await self._session.execute(
            stmt,
            {
                "query": vector_str,
                "user_id": user_id,
                "top_k": top_k,
            },
        )
        hits: List[SearchResult] = []
        for row in result.fetchall():
            sim = float(row[1])
            if sim < min_similarity:
                continue
            hits.append(
                SearchResult(
                    entry_id=row[0],
                    similarity_score=sim,
                    enhanced_text=row[2],
                    emotion=row[3],
                    created_at=row[4],
                )
            )
        return hits

    async def delete_embedding(self, entry_id: uuid.UUID) -> None:
        stmt = text("DELETE FROM diary_embeddings WHERE entry_id = :entry_id")
        await self._session.execute(stmt, {"entry_id": entry_id})
        await self._session.flush()
