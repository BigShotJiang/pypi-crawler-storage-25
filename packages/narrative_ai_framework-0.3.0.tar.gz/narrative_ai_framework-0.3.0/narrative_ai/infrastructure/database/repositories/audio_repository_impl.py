"""Concrete async audio-file metadata repository backed by PostgreSQL."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import List, Optional

from sqlalchemy import select, delete as sa_delete, and_

from narrative_ai.domain.entities.audio_file import AudioFile, AudioFileType
from narrative_ai.domain.repositories.audio_repository import AudioRepository
from narrative_ai.infrastructure.database.models import AudioFileModel
from .base_repository import BaseRepository


class PostgresAudioRepository(BaseRepository[AudioFileModel], AudioRepository):
    """PostgreSQL implementation of :class:`AudioRepository`."""

    model_class = AudioFileModel

    @staticmethod
    def _to_domain(row: AudioFileModel) -> AudioFile:
        return AudioFile(
            id=row.id,
            user_id=row.user_id,
            file_type=AudioFileType(row.file_type),
            storage_path=row.storage_path,
            duration_seconds=row.duration_seconds,
            voice_used=row.voice_used,
            quality=row.quality,
            format=row.format,
            conversation_id=row.conversation_id,
            created_at=row.created_at,
            expires_at=row.expires_at,
        )

    @staticmethod
    def _to_model(audio: AudioFile) -> AudioFileModel:
        return AudioFileModel(
            id=audio.id,
            user_id=audio.user_id,
            file_type=audio.file_type.value if isinstance(audio.file_type, AudioFileType) else audio.file_type,
            storage_path=audio.storage_path,
            duration_seconds=audio.duration_seconds,
            voice_used=audio.voice_used,
            quality=audio.quality,
            format=audio.format,
            conversation_id=audio.conversation_id,
            created_at=audio.created_at,
            expires_at=audio.expires_at,
        )

    async def create(self, audio: AudioFile) -> AudioFile:
        model = self._to_model(audio)
        model = await self._add(model)
        return self._to_domain(model)

    async def get_by_id(self, audio_id: uuid.UUID, *, user_id: uuid.UUID) -> Optional[AudioFile]:
        stmt = select(AudioFileModel).where(and_(AudioFileModel.id == audio_id, AudioFileModel.user_id == user_id))
        result = await self._session.execute(stmt)
        row = result.scalar_one_or_none()
        return self._to_domain(row) if row else None

    async def list_by_user(
        self,
        *,
        user_id: uuid.UUID,
        file_type: Optional[str] = None,
        offset: int = 0,
        limit: int = 50,
    ) -> List[AudioFile]:
        filters = [AudioFileModel.user_id == user_id]
        if file_type:
            filters.append(AudioFileModel.file_type == file_type)
        rows = await self._list(
            *filters,
            offset=offset,
            limit=limit,
            order_by=AudioFileModel.created_at.desc(),
        )
        return [self._to_domain(r) for r in rows]

    async def delete_expired(self) -> int:
        now = datetime.now(timezone.utc)
        stmt = (
            sa_delete(AudioFileModel)
            .where(
                and_(
                    AudioFileModel.expires_at != None,  # noqa: E711
                    AudioFileModel.expires_at < now,
                )
            )
            .returning(AudioFileModel.id)
        )
        result = await self._session.execute(stmt)
        await self._session.flush()
        return len(result.fetchall())
