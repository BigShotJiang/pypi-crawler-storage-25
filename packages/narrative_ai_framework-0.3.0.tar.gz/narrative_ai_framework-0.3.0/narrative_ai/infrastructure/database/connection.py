"""Async SQLAlchemy engine and session factory.

Usage
-----
::

    from narrative_ai.infrastructure.database.connection import get_engine, get_session_factory

    engine = get_engine()          # singleton per process
    SessionLocal = get_session_factory(engine)

    async with SessionLocal() as session:
        ...
"""

from __future__ import annotations

import logging
from typing import Optional

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from .config import DatabaseConfig

logger = logging.getLogger(__name__)

_engine: Optional[AsyncEngine] = None


def get_engine(config: Optional[DatabaseConfig] = None) -> AsyncEngine:
    """Return a process-wide async engine (created once, reused)."""
    global _engine
    if _engine is not None:
        return _engine

    if config is None:
        config = DatabaseConfig.from_env()

    if not config.url:
        raise RuntimeError(
            "DATABASE_URL is not set.  "
            "Export it before starting the application, e.g. "
            "DATABASE_URL=postgresql+asyncpg://user:pass@localhost:5432/narrative_ai"
        )

    _engine = create_async_engine(
        config.url,
        pool_size=config.pool_size,
        max_overflow=config.max_overflow,
        pool_pre_ping=config.pool_pre_ping,
        pool_recycle=config.pool_recycle,
        echo=config.echo_sql,
    )
    logger.info(
        "Async database engine created (pool_size=%d, pool_recycle=%d)",
        config.pool_size,
        config.pool_recycle,
    )
    return _engine


def get_session_factory(
    engine: Optional[AsyncEngine] = None,
) -> async_sessionmaker[AsyncSession]:
    """Return an async session factory bound to *engine*."""
    if engine is None:
        engine = get_engine()
    return async_sessionmaker(
        bind=engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )


async def dispose_engine() -> None:
    """Gracefully close the engine pool (call on shutdown)."""
    global _engine
    if _engine is not None:
        await _engine.dispose()
        _engine = None
        logger.info("Database engine disposed.")
