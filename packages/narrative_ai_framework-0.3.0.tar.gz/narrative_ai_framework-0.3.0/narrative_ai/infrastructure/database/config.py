"""Database configuration loaded from environment variables."""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class DatabaseConfig:
    """Connection and pool settings for the single PostgreSQL database.

    Environment variables
    ---------------------
    DATABASE_URL : str
        Full connection string, e.g.
        ``postgresql+asyncpg://user:pass@localhost:5432/narrative_ai``
    DATABASE_POOL_SIZE : int  (default 20)
    DATABASE_MAX_OVERFLOW : int  (default 40)
    DATABASE_POOL_PRE_PING : bool  (default True)
    DATABASE_POOL_RECYCLE : int  (seconds, default 3600)
    DATABASE_ECHO_SQL : bool  (default False)

    Pool sizing with multiple workers
    ---------------------------------
    Each process has its own engine; total connections = workers * (pool_size + max_overflow).
    Ensure this is below PostgreSQL max_connections (leave headroom for migrations, admin).
    Example: 4 workers with defaults = 4 * 60 = 240 connections; set postgres max_connections
    accordingly or lower DATABASE_POOL_SIZE / DATABASE_MAX_OVERFLOW when increasing workers.
    """

    url: str = ""
    pool_size: int = 20
    max_overflow: int = 40
    pool_pre_ping: bool = True
    pool_recycle: int = 3600
    echo_sql: bool = False

    @classmethod
    def from_env(cls) -> "DatabaseConfig":
        raw_url = os.getenv("DATABASE_URL", "")
        # Ensure we use the asyncpg driver for async sessions.
        if raw_url.startswith("postgresql://"):
            raw_url = raw_url.replace("postgresql://", "postgresql+asyncpg://", 1)
        return cls(
            url=raw_url,
            pool_size=int(os.getenv("DATABASE_POOL_SIZE", "20")),
            max_overflow=int(os.getenv("DATABASE_MAX_OVERFLOW", "40")),
            pool_pre_ping=os.getenv("DATABASE_POOL_PRE_PING", "true").lower() in ("true", "1", "yes"),
            pool_recycle=int(os.getenv("DATABASE_POOL_RECYCLE", "3600")),
            echo_sql=os.getenv("DATABASE_ECHO_SQL", "false").lower() in ("true", "1", "yes"),
        )

    @property
    def sync_url(self) -> str:
        """Return the URL with the synchronous ``psycopg2`` driver."""
        return self.url.replace("postgresql+asyncpg://", "postgresql://")
