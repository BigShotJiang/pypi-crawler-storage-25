"""Enable pgvector extension and create diary_embeddings table.

Revision ID: 002
Revises: 001
Create Date: 2026-02-08

If pgvector is not installed, creates the table with a BYTEA column instead.
Semantic search will not work until pgvector is installed; auth and entries still work.
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID

revision = "002"
down_revision = "001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Try to enable pgvector (fails if extension not installed on PostgreSQL).
    # Use SAVEPOINT so a failed CREATE EXTENSION doesn't abort the whole transaction.
    conn = op.get_bind()
    has_pgvector = False
    try:
        conn.execute(sa.text("SAVEPOINT before_vector"))
        conn.execute(sa.text("CREATE EXTENSION IF NOT EXISTS vector"))
        conn.execute(sa.text("RELEASE SAVEPOINT before_vector"))
        has_pgvector = True
    except Exception:
        try:
            conn.execute(sa.text("ROLLBACK TO SAVEPOINT before_vector"))
            conn.execute(sa.text("RELEASE SAVEPOINT before_vector"))
        except Exception:
            pass
        # pgvector not available; use BYTEA fallback (semantic search disabled)

    # Create the diary_embeddings table
    op.create_table(
        "diary_embeddings",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "entry_id",
            UUID(as_uuid=True),
            sa.ForeignKey("diary_entries.id", ondelete="CASCADE"),
            nullable=False,
            unique=True,
        ),
        sa.Column(
            "user_id",
            UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )

    if has_pgvector:
        op.execute("ALTER TABLE diary_embeddings ADD COLUMN embedding vector(768) NOT NULL")
    else:
        # Fallback: BYTEA stores raw bytes; semantic search disabled until pgvector installed
        op.add_column(
            "diary_embeddings",
            sa.Column("embedding", sa.LargeBinary(), nullable=False, server_default=sa.text("'\\x'::bytea")),
        )

    op.create_index("ix_diary_embeddings_user", "diary_embeddings", ["user_id"])


def downgrade() -> None:
    op.drop_table("diary_embeddings")
    try:
        op.execute("DROP EXTENSION IF EXISTS vector")
    except Exception:
        pass  # Extension may not exist if pgvector was never installed
