"""Add composite index on audit_logs (tenant_id, timestamp) for tenant-scoped audit queries.

Revision ID: 007
Revises: 006
Create Date: 2026-03-01

Supports get_user_actions and get_tenant_actions in AuditLogger which filter by
tenant_id and order by timestamp DESC (optionally with time range).
"""

from alembic import op

revision = "007"
down_revision = "006"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_index(
        "ix_audit_logs_tenant_timestamp",
        "audit_logs",
        ["tenant_id", "timestamp"],
        postgresql_ops={"timestamp": "DESC"},
    )


def downgrade() -> None:
    op.drop_index("ix_audit_logs_tenant_timestamp", table_name="audit_logs")
