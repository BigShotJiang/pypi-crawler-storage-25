"""Add HNSW index on diary_embeddings and additional performance indexes.

Revision ID: 003
Revises: 002
Create Date: 2026-02-08

HNSW index is skipped if pgvector was not available (embedding column is BYTEA).
Uses SAVEPOINT so a failed HNSW creation doesn't abort the whole transaction.
"""

from alembic import op
import sqlalchemy as sa

revision = "003"
down_revision = "002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # HNSW index for fast approximate nearest-neighbour search (requires pgvector).
    # Use SAVEPOINT so a failed CREATE INDEX doesn't abort the transaction.
    conn = op.get_bind()
    try:
        conn.execute(sa.text("SAVEPOINT before_hnsw"))
        conn.execute(
            sa.text(
                """
                CREATE INDEX ix_diary_embeddings_hnsw
                ON diary_embeddings
                USING hnsw (embedding vector_cosine_ops)
                WITH (m = 16, ef_construction = 200)
                """
            )
        )
        conn.execute(sa.text("RELEASE SAVEPOINT before_hnsw"))
    except Exception:
        try:
            conn.execute(sa.text("ROLLBACK TO SAVEPOINT before_hnsw"))
            conn.execute(sa.text("RELEASE SAVEPOINT before_hnsw"))
        except Exception:
            pass
        # pgvector not available; semantic search disabled

    # GIN index on diary_entries.tags for fast tag-based filtering
    op.execute(
        """
        CREATE INDEX ix_diary_entries_tags
        ON diary_entries
        USING gin (tags)
        """
    )

    # Partial index for non-deleted entries (most common query pattern)
    op.execute(
        """
        CREATE INDEX ix_diary_entries_active
        ON diary_entries (user_id, created_at DESC)
        WHERE deleted_at IS NULL
        """
    )


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ix_diary_entries_active")
    op.execute("DROP INDEX IF EXISTS ix_diary_entries_tags")
    op.execute("DROP INDEX IF EXISTS ix_diary_embeddings_hnsw")
