"""Add entry_media table for per-entry images/attachments.

Revision ID: 006
Revises: 005
Create Date: 2026-02-16

"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID

revision = "006"
down_revision = "005"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "entry_media",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "entry_id", UUID(as_uuid=True), sa.ForeignKey("diary_entries.id", ondelete="CASCADE"), nullable=False
        ),
        sa.Column("user_id", UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("storage_path", sa.String(1024), nullable=False),
        sa.Column("media_type", sa.String(32), nullable=False, server_default="image"),
        sa.Column("caption", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=sa.text("now()")),
    )
    op.create_index("ix_entry_media_entry_id", "entry_media", ["entry_id"])
    op.create_index("ix_entry_media_user_id", "entry_media", ["user_id"])


def downgrade() -> None:
    op.drop_index("ix_entry_media_user_id", table_name="entry_media")
    op.drop_index("ix_entry_media_entry_id", table_name="entry_media")
    op.drop_table("entry_media")
