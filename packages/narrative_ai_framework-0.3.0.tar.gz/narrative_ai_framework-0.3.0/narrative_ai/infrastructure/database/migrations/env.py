"""Alembic environment configuration.

Supports both *online* (connected to a live database) and *offline*
(SQL script generation) migration modes.

Set ``DATABASE_URL`` in the environment or in a ``.env`` file before running::

    alembic upgrade head
"""

from __future__ import annotations

import os
import sys
from logging.config import fileConfig

# Add project root to path so "framework" is importable
_env_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(_env_dir))))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

# Load .env from project root (parent of framework/)
try:
    from dotenv import load_dotenv

    _env_path = os.path.join(_project_root, ".env")
    if os.path.isfile(_env_path):
        load_dotenv(_env_path, override=False)
except ImportError:
    pass

from alembic import context  # noqa: E402
from sqlalchemy import engine_from_config, pool  # noqa: E402

# Import the declarative base so Alembic can diff models vs. schema.
from narrative_ai.infrastructure.database.schema import Base  # noqa: E402

# Alembic Config object
config = context.config

# Logging
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Metadata for autogenerate
target_metadata = Base.metadata

# Get DATABASE_URL from env (loaded from .env above if dotenv available)
_url = os.getenv("DATABASE_URL", "")
if _url:
    # Alembic migrations use the synchronous psycopg2 driver.
    _url = _url.replace("postgresql+asyncpg://", "postgresql://")
    config.set_main_option("sqlalchemy.url", _url)


def run_migrations_offline() -> None:
    """Generate SQL scripts without a live connection."""
    url = config.get_main_option("sqlalchemy.url")
    if not url:
        raise RuntimeError("DATABASE_URL is not set. Set it in your environment or in a .env file in the project root.")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations against a live database."""
    # Build config dict: engine_from_config expects sqlalchemy.url
    configuration = config.get_section(config.config_ini_section, {})
    url = config.get_main_option("sqlalchemy.url")
    if not url:
        raise RuntimeError("DATABASE_URL is not set. Set it in your environment or in a .env file in the project root.")
    configuration["sqlalchemy.url"] = url

    connectable = engine_from_config(
        configuration,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
