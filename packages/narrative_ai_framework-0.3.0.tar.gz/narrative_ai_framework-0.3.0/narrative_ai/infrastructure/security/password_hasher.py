"""Password hashing utilities using bcrypt.

Usage::

    from narrative_ai.infrastructure.security.password_hasher import hash_password, verify_password

    hashed = hash_password("my_plain_password")
    assert verify_password("my_plain_password", hashed)
"""

from __future__ import annotations

import bcrypt


def hash_password(plain_password: str) -> str:
    """Hash a plain-text password and return the bcrypt hash string."""
    password_bytes = plain_password.encode("utf-8")
    salt = bcrypt.gensalt(rounds=12)
    hashed = bcrypt.hashpw(password_bytes, salt)
    return hashed.decode("utf-8")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plain-text password against a bcrypt hash.

    Returns ``True`` if the password matches, ``False`` otherwise.
    Never raises on mismatch.
    """
    try:
        return bcrypt.checkpw(
            plain_password.encode("utf-8"),
            hashed_password.encode("utf-8"),
        )
    except (ValueError, TypeError):
        # Malformed hash or encoding error -- treat as mismatch
        return False
