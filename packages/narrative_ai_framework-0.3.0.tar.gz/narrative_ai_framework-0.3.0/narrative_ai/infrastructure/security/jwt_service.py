"""JWT token creation and validation using PyJWT.

Environment variables
---------------------
- ``JWT_SECRET_KEY``  -- signing key (required, change in production)
- ``JWT_ALGORITHM``   -- algorithm (default ``HS256``)
- ``JWT_ACCESS_TOKEN_EXPIRE_MINUTES``  -- access token TTL (default 60)
- ``JWT_REFRESH_TOKEN_EXPIRE_DAYS``    -- refresh token TTL (default 7)
"""

from __future__ import annotations

import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict

import jwt

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_SECRET_KEY: str | None = None
_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

# Validate algorithm early so misconfiguration fails fast.
_ALLOWED_ALGORITHMS = {"HS256", "HS384", "HS512", "RS256"}
if _ALGORITHM not in _ALLOWED_ALGORITHMS:
    raise ValueError(f"Unsupported JWT algorithm: {_ALGORITHM!r}. Allowed: {_ALLOWED_ALGORITHMS}")


def _get_secret() -> str:
    global _SECRET_KEY
    if _SECRET_KEY is None:
        _SECRET_KEY = os.getenv("JWT_SECRET_KEY", "")
    if not _SECRET_KEY:
        raise RuntimeError("JWT_SECRET_KEY is not set.  Export it before starting the application.")
    return _SECRET_KEY


def _access_expire_minutes() -> int:
    return int(os.getenv("JWT_ACCESS_TOKEN_EXPIRE_MINUTES", "60"))


def _refresh_expire_days() -> int:
    return int(os.getenv("JWT_REFRESH_TOKEN_EXPIRE_DAYS", "7"))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def create_access_token(
    user_id: str | uuid.UUID,
    email: str,
    role: str,
    *,
    extra_claims: Dict[str, Any] | None = None,
) -> str:
    """Create a short-lived access JWT.

    The payload contains ``sub`` (user id), ``email``, ``role``, ``type``
    (``access``), ``iat``, and ``exp``.
    """
    now = datetime.now(timezone.utc)
    payload: Dict[str, Any] = {
        "sub": str(user_id),
        "email": email,
        "role": role,
        "type": "access",
        "iat": now,
        "exp": now + timedelta(minutes=_access_expire_minutes()),
    }
    if extra_claims:
        payload.update(extra_claims)
    return jwt.encode(payload, _get_secret(), algorithm=_ALGORITHM)


def create_refresh_token(user_id: str | uuid.UUID) -> str:
    """Create a long-lived refresh JWT.

    Contains ``sub``, ``type`` (``refresh``), ``jti`` (unique ID for
    rotation/invalidation), ``iat``, and ``exp``.
    """
    now = datetime.now(timezone.utc)
    payload: Dict[str, Any] = {
        "sub": str(user_id),
        "type": "refresh",
        "jti": str(uuid.uuid4()),
        "iat": now,
        "exp": now + timedelta(days=_refresh_expire_days()),
    }
    return jwt.encode(payload, _get_secret(), algorithm=_ALGORITHM)


def refresh_token_ttl_seconds() -> int:
    """Return the refresh token TTL in seconds (for Redis key expiry)."""
    return _refresh_expire_days() * 86400


def decode_token(token: str) -> Dict[str, Any]:
    """Decode and validate a JWT.

    Raises
    ------
    jwt.ExpiredSignatureError
        If the token has expired.
    jwt.InvalidTokenError
        If the token is malformed or the signature is invalid.
    """
    return jwt.decode(token, _get_secret(), algorithms=[_ALGORITHM])
