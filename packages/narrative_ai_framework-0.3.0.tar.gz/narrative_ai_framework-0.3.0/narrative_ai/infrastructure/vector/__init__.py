"""Vector store infrastructure -- pgvector (diary), Qdrant (RAG)."""

from .config import VectorConfig
from .base_vector_store import (
    BaseVectorStore,
    VectorSearchHit,
    RagVectorStore,
    VectorPayload,
    VectorSearchResult,
)

try:
    from .pgvector_store import PgvectorStore
except Exception:  # pragma: no cover - optional dependency in lightweight test envs
    PgvectorStore = None  # type: ignore[assignment]

try:
    from .qdrant_store import QdrantStore
except Exception:  # pragma: no cover - optional dependency in lightweight test envs
    QdrantStore = None  # type: ignore[assignment]

__all__ = [
    "VectorConfig",
    "BaseVectorStore",
    "VectorSearchHit",
    "PgvectorStore",
    "RagVectorStore",
    "VectorPayload",
    "VectorSearchResult",
    "QdrantStore",
]
