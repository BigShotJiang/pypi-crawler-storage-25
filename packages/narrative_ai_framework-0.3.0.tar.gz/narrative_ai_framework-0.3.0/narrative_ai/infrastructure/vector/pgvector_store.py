"""pgvector-backed vector store using HNSW indexes.

This is a thin wrapper around :class:`PgvectorSearchRepository` that
also implements the :class:`BaseVectorStore` interface so it can be
swapped for Pinecone / Milvus if needed.
"""

from __future__ import annotations

import logging
import uuid
from typing import List, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from .base_vector_store import BaseVectorStore, VectorSearchHit
from .config import VectorConfig

logger = logging.getLogger(__name__)


class PgvectorStore(BaseVectorStore):
    """PostgreSQL + pgvector vector store.

    Requires:
    - ``CREATE EXTENSION IF NOT EXISTS vector;``
    - The ``diary_embeddings`` table (migration 002)
    - The HNSW index (migration 003)

    The ``<=>`` operator computes *cosine distance* (0 = identical,
    2 = opposite).  We convert to a similarity in [0, 1] via ``1 - d``.
    """

    def __init__(
        self,
        session: AsyncSession,
        config: Optional[VectorConfig] = None,
    ) -> None:
        self._session = session
        self._config = config or VectorConfig.from_env()

    # ------------------------------------------------------------------
    # BaseVectorStore implementation
    # ------------------------------------------------------------------

    async def upsert(
        self,
        entry_id: uuid.UUID,
        user_id: uuid.UUID,
        embedding: List[float],
    ) -> None:
        vec = self._to_pg_literal(embedding)
        stmt = text(
            """
            INSERT INTO diary_embeddings (id, entry_id, user_id, embedding)
            VALUES (:id, :entry_id, :user_id, :embedding::vector)
            ON CONFLICT (entry_id)
            DO UPDATE SET embedding = EXCLUDED.embedding
            """
        )
        await self._session.execute(
            stmt,
            {
                "id": uuid.uuid4(),
                "entry_id": entry_id,
                "user_id": user_id,
                "embedding": vec,
            },
        )
        await self._session.flush()

    async def search(
        self,
        query: List[float],
        *,
        user_id: uuid.UUID,
        top_k: int = 5,
        min_similarity: float = 0.0,
    ) -> List[VectorSearchHit]:
        vec = self._to_pg_literal(query)

        # Tune HNSW recall for this transaction
        await self._session.execute(text(f"SET LOCAL hnsw.ef_search = {self._config.hnsw_ef_search}"))

        stmt = text(
            """
            SELECT
                de.entry_id,
                1 - (de.embedding <=> :q::vector) AS similarity
            FROM diary_embeddings de
            JOIN diary_entries e ON e.id = de.entry_id
            WHERE de.user_id = :uid
              AND e.deleted_at IS NULL
            ORDER BY de.embedding <=> :q::vector
            LIMIT :k
            """
        )
        result = await self._session.execute(stmt, {"q": vec, "uid": user_id, "k": top_k})
        hits: List[VectorSearchHit] = []
        for row in result.fetchall():
            sim = float(row[1])
            if sim < min_similarity:
                continue
            hits.append(VectorSearchHit(entry_id=row[0], similarity=sim))
        return hits

    async def delete(self, entry_id: uuid.UUID) -> None:
        stmt = text("DELETE FROM diary_embeddings WHERE entry_id = :eid")
        await self._session.execute(stmt, {"eid": entry_id})
        await self._session.flush()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _to_pg_literal(embedding: List[float]) -> str:
        """Serialise a float list to pgvector's text representation."""
        return "[" + ",".join(str(f) for f in embedding) + "]"
