"""
Qdrant Vector Store Implementation.

Provides high-speed hybrid (dense + sparse) vector search
using Qdrant as the backend.
"""

import asyncio
import inspect
import logging
from typing import List, Dict, Any, Optional

from .base_vector_store import RagVectorStore, VectorPayload, VectorSearchResult

logger = logging.getLogger(__name__)


class QdrantStore(RagVectorStore):
    """
    Qdrant implementation of the vector store interface.

    Features:
    - Dense + Sparse hybrid search
    - HNSW indexing for fast retrieval
    - Rich payload support for metadata
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6333,
        collection_name: str = "narrative_memory",
        prefer_grpc: bool = False,
        api_key: Optional[str] = None,
    ):
        """
        Initialize Qdrant client.

        Args:
            host: Qdrant server host.
            port: Qdrant server port.
            collection_name: Name of the collection.
            prefer_grpc: Use gRPC instead of HTTP.
            api_key: Optional API key for Qdrant Cloud.
        """
        self.host = host
        self.port = port
        self.collection_name = collection_name
        self.prefer_grpc = prefer_grpc
        self.api_key = api_key

        self._client = None
        self._async_client = None
        self._models = None

    @property
    def client(self):
        """Lazy-load Qdrant client."""
        if self._client is None:
            try:
                from qdrant_client import QdrantClient

                if self.host == ":memory:":
                    self._client = QdrantClient(":memory:")
                    logger.info("Initialized In-Memory Qdrant Client")
                else:
                    self._client = QdrantClient(
                        host=self.host,
                        port=self.port,
                        prefer_grpc=self.prefer_grpc,
                        api_key=self.api_key,
                    )
                    logger.info(f"Connected to Qdrant at {self.host}:{self.port}")
            except ImportError:
                raise ImportError("qdrant-client is required. Install with: pip install qdrant-client")
        return self._client

    @property
    def async_client(self):
        """Lazy-load async Qdrant client."""
        if self._async_client is None:
            try:
                from qdrant_client import AsyncQdrantClient

                if self.host == ":memory:":
                    # For in-memory, we'll use the sync client for now
                    from qdrant_client import QdrantClient

                    self._async_client = QdrantClient(":memory:")
                    logger.info("Initialized In-Memory Qdrant Client for async")
                else:
                    self._async_client = AsyncQdrantClient(
                        host=self.host,
                        port=self.port,
                        prefer_grpc=self.prefer_grpc,
                        api_key=self.api_key,
                    )
                    logger.info(f"Connected to Async Qdrant at {self.host}:{self.port}")
            except ImportError:
                raise ImportError("qdrant-client is required. Install with: pip install qdrant-client>=1.7.0")
        return self._async_client

    @property
    def models(self):
        """Lazy-load Qdrant models."""
        if self._models is None:
            from qdrant_client import models

            self._models = models
        return self._models

    async def _call_async_client(self, method_name: str, *args, **kwargs):
        """
        Call client method safely across async and sync clients.

        For in-memory mode, async_client can be a sync QdrantClient.
        We offload sync operations to a worker thread.
        """
        method = getattr(self.async_client, method_name)
        if inspect.iscoroutinefunction(method):
            return await method(*args, **kwargs)
        return await asyncio.to_thread(method, *args, **kwargs)

    def _build_doc_id_filter(self, doc_id: str, user_id: Optional[str] = None):
        must_conditions = [
            self.models.FieldCondition(
                key="doc_id",
                match=self.models.MatchValue(value=doc_id),
            )
        ]
        if user_id:
            must_conditions.append(
                self.models.FieldCondition(
                    key="user_id",
                    match=self.models.MatchValue(value=user_id),
                )
            )
        return self.models.Filter(must=must_conditions)

    @staticmethod
    def _extract_count(count_response: Any) -> int:
        if count_response is None:
            return 0
        if isinstance(count_response, int):
            return count_response
        if isinstance(count_response, dict):
            return int(count_response.get("count", 0))
        return int(getattr(count_response, "count", 0))

    async def _count_with_filter(self, qdrant_filter) -> int:
        """
        Count points with version-compatible parameter names.
        """
        try:
            response = await self._call_async_client(
                "count",
                collection_name=self.collection_name,
                count_filter=qdrant_filter,
                exact=True,
            )
        except TypeError:
            response = await self._call_async_client(
                "count",
                collection_name=self.collection_name,
                query_filter=qdrant_filter,
                exact=True,
            )
        return self._extract_count(response)

    async def collection_exists(self) -> bool:
        """Check if collection exists."""
        try:
            collections = (await self._call_async_client("get_collections")).collections
            return any(c.name == self.collection_name for c in collections)
        except Exception as e:
            logger.error(f"Error checking collection: {e}")
            return False

    async def create_collection(
        self,
        dense_dimension: int,
        sparse_enabled: bool = True,
    ) -> bool:
        """Create collection with HNSW indexing."""
        try:
            vectors_config = {
                "dense": self.models.VectorParams(
                    size=dense_dimension,
                    distance=self.models.Distance.COSINE,
                )
            }

            sparse_vectors_config = None
            if sparse_enabled:
                sparse_vectors_config = {
                    "sparse": self.models.SparseVectorParams(index=self.models.SparseIndexParams(on_disk=False))
                }

            await self._call_async_client(
                "create_collection",
                collection_name=self.collection_name,
                vectors_config=vectors_config,
                sparse_vectors_config=sparse_vectors_config,
            )

            logger.info(f"Created collection: {self.collection_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to create collection: {e}")
            return False

    async def delete_collection(self) -> bool:
        """Delete the collection."""
        try:
            await self._call_async_client("delete_collection", self.collection_name)
            logger.info(f"Deleted collection: {self.collection_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete collection: {e}")
            return False

    def _ensure_uuid(self, id_val: str) -> str:
        """Ensure the ID is a valid UUID string (required by Qdrant)."""
        import uuid
        import hashlib

        try:
            # Check if it's already a valid UUID
            uuid.UUID(str(id_val))
            return str(id_val)
        except (ValueError, TypeError):
            # If not, hash the string into a deterministic UUID
            hash_m = hashlib.md5(str(id_val).encode()).hexdigest()  # nosec: B324
            return str(uuid.UUID(hash_m))

    async def upsert(
        self,
        ids: List[str],
        dense_vectors: List[List[float]],
        payloads: List[VectorPayload],
        sparse_vectors: Optional[List[Dict[str, float]]] = None,
    ) -> bool:
        """Insert or update vectors."""
        try:
            points = []
            for i, (id_, dense, payload) in enumerate(zip(ids, dense_vectors, payloads)):
                # Ensure ID is a UUID
                point_id = self._ensure_uuid(id_)

                vectors = {"dense": dense}

                if sparse_vectors and sparse_vectors[i]:
                    # Convert sparse dict to Qdrant format
                    sparse = sparse_vectors[i]
                    vectors["sparse"] = self.models.SparseVector(
                        indices=list(sparse.keys())
                        if isinstance(list(sparse.keys())[0], int)
                        else list(range(len(sparse))),
                        values=list(sparse.values()),
                    )

                # Convert payload to dict
                payload_dict = {
                    "chunk_id": payload.chunk_id,
                    "doc_id": payload.doc_id,
                    "block_id": payload.block_id,
                    "text": payload.text,
                    "modality": payload.modality,
                    "timestamp": payload.timestamp,
                    "page": payload.page,
                    "media_ref": payload.media_ref,
                    "user_id": payload.user_id,  # Stored for mandatory retrieval filtering
                }
                if payload.extra:
                    payload_dict["extra"] = payload.extra

                points.append(
                    self.models.PointStruct(
                        id=point_id,
                        vector=vectors,
                        payload=payload_dict,
                    )
                )

            await self._call_async_client(
                "upsert",
                collection_name=self.collection_name,
                points=points,
            )

            logger.debug(f"Upserted {len(points)} vectors")
            return True
        except Exception as e:
            logger.error(f"Failed to upsert: {e}")
            return False

    async def search(
        self,
        dense_vector: List[float],
        sparse_vector: Optional[Dict[str, float]] = None,
        top_k: int = 10,
        filters: Optional[Dict[str, Any]] = None,
        hybrid_alpha: float = 0.7,
    ) -> List[VectorSearchResult]:
        """
        Perform hybrid search.

        Uses Qdrant's native hybrid search combining dense and sparse.
        """
        try:
            # Build filter if provided
            qdrant_filter = None
            if filters:
                conditions = []
                for key, value in filters.items():
                    conditions.append(
                        self.models.FieldCondition(
                            key=key,
                            match=self.models.MatchValue(value=value),
                        )
                    )
                qdrant_filter = self.models.Filter(must=conditions)

            # Perform hybrid search if sparse vector available
            if sparse_vector:
                # Use query_batch for hybrid
                logger.debug("Executing hybrid search with RRF fusion")
                results_bundle = await self._call_async_client(
                    "query_points",
                    collection_name=self.collection_name,
                    prefetch=[
                        self.models.Prefetch(
                            query=dense_vector,
                            using="dense",
                            limit=top_k * 2,
                        ),
                        self.models.Prefetch(
                            query=self.models.SparseVector(
                                indices=list(range(len(sparse_vector)))
                                if not isinstance(list(sparse_vector.keys())[0], int)
                                else list(sparse_vector.keys()),
                                values=list(sparse_vector.values()),
                            ),
                            using="sparse",
                            limit=top_k * 2,
                        ),
                    ],
                    query=self.models.FusionQuery(fusion=self.models.Fusion.RRF),
                    limit=top_k,
                    query_filter=qdrant_filter,
                    with_payload=True,
                )
                results = results_bundle.points
                logger.debug(f"Hybrid search returned {len(results)} points")
            else:
                # Dense-only search
                logger.debug("Executing dense-only search")
                results_bundle = await self._call_async_client(
                    "query_points",
                    collection_name=self.collection_name,
                    query=dense_vector,
                    using="dense",
                    limit=top_k,
                    query_filter=qdrant_filter,
                    with_payload=True,
                )
                results = results_bundle.points
                logger.debug(f"Dense search returned {len(results)} points")

            # Convert to VectorSearchResult
            search_results = []
            for point in results:
                payload = point.payload
                search_results.append(
                    VectorSearchResult(
                        chunk_id=payload.get("chunk_id", str(point.id)),
                        score=point.score,
                        payload=VectorPayload(
                            chunk_id=payload.get("chunk_id", ""),
                            doc_id=payload.get("doc_id", ""),
                            block_id=payload.get("block_id", ""),
                            text=payload.get("text", ""),
                            modality=payload.get("modality", "text"),
                            timestamp=payload.get("timestamp"),
                            page=payload.get("page"),
                            media_ref=payload.get("media_ref"),
                            extra=payload.get("extra"),
                            user_id=payload.get("user_id"),
                        ),
                    )
                )

            return search_results
        except Exception as e:
            logger.error(f"Search failed: {e}")
            return []

    async def delete_by_doc_id(self, doc_id: str, user_id: Optional[str] = None) -> int:
        """Delete vectors for a document, optionally scoped by owner user_id."""
        try:
            doc_filter = self._build_doc_id_filter(doc_id, user_id=user_id)
            deleted_count = await self._count_with_filter(doc_filter)
            if deleted_count == 0:
                return 0

            await self._call_async_client(
                "delete",
                collection_name=self.collection_name,
                points_selector=self.models.FilterSelector(filter=doc_filter),
            )
            logger.info(f"Deleted vectors for doc_id: {doc_id}")
            return deleted_count
        except Exception as e:
            logger.error(f"Delete failed: {e}")
            return 0

    async def count(self) -> int:
        """Return total vector count."""
        try:
            info = await self._call_async_client("get_collection", self.collection_name)
            return int(getattr(info, "points_count", 0) or 0)
        except Exception as e:
            logger.error(f"Count failed: {e}")
            return 0
