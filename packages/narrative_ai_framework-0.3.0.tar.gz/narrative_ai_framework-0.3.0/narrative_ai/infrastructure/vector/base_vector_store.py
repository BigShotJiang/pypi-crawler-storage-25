"""
Vector store interfaces: diary/entry (voice) and RAG (chunk/payload).

- BaseVectorStore + VectorSearchHit: used by pgvector for diary embeddings.
- RagVectorStore + VectorPayload + VectorSearchResult: used by Qdrant for RAG.
"""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


# -----------------------------------------------------------------------------
# Voice / Diary interface (pgvector)
# -----------------------------------------------------------------------------


@dataclass
class VectorSearchHit:
    """A single hit returned by vector similarity search (diary/entry)."""

    entry_id: uuid.UUID
    similarity: float
    metadata: Optional[dict] = None


class BaseVectorStore(ABC):
    """Port for storing and searching dense-vector embeddings (diary entries).

    The primary implementation uses pgvector (see ``pgvector_store.py``).
    Alternative backends (Pinecone, Milvus) can implement this interface.
    """

    @abstractmethod
    async def upsert(
        self,
        entry_id: uuid.UUID,
        user_id: uuid.UUID,
        embedding: List[float],
    ) -> None:
        """Insert or update an embedding for *entry_id*."""
        ...

    @abstractmethod
    async def search(
        self,
        query: List[float],
        *,
        user_id: uuid.UUID,
        top_k: int = 5,
        min_similarity: float = 0.0,
    ) -> List[VectorSearchHit]:
        """Return the *top_k* nearest entries by similarity."""
        ...

    @abstractmethod
    async def delete(self, entry_id: uuid.UUID) -> None:
        """Remove the embedding for *entry_id*."""
        ...


# -----------------------------------------------------------------------------
# RAG interface (Qdrant, chunk/payload)
# -----------------------------------------------------------------------------


@dataclass
class VectorPayload:
    """Metadata payload stored alongside vectors (RAG)."""

    chunk_id: str
    doc_id: str
    block_id: str
    text: str
    modality: str = "text"
    timestamp: Optional[float] = None
    page: Optional[int] = None
    media_ref: Optional[str] = None
    extra: Optional[Dict[str, Any]] = None
    user_id: Optional[str] = None  # Owner — used for mandatory retrieval filtering


@dataclass
class VectorSearchResult:
    """Result from a vector search operation (RAG)."""

    chunk_id: str
    score: float
    payload: VectorPayload
    dense_vector: Optional[List[float]] = None
    sparse_vector: Optional[Dict[str, float]] = None


class RagVectorStore(ABC):
    """
    Abstract base for RAG vector stores (chunk/payload, hybrid search).
    Qdrant and similar backends implement this interface.
    """

    @abstractmethod
    async def upsert(
        self,
        ids: List[str],
        dense_vectors: List[List[float]],
        payloads: List[VectorPayload],
        sparse_vectors: Optional[List[Dict[str, float]]] = None,
    ) -> bool:
        """Insert or update vectors with their payloads."""
        ...

    @abstractmethod
    async def search(
        self,
        dense_vector: List[float],
        sparse_vector: Optional[Dict[str, float]] = None,
        top_k: int = 10,
        filters: Optional[Dict[str, Any]] = None,
        hybrid_alpha: float = 0.7,
    ) -> List[VectorSearchResult]:
        """Search for similar vectors."""
        ...

    @abstractmethod
    async def delete_by_doc_id(self, doc_id: str, user_id: Optional[str] = None) -> int:
        """Delete vectors for a document, optionally scoped by owner user_id."""
        ...

    @abstractmethod
    async def collection_exists(self) -> bool:
        """Check if the collection/index exists."""
        ...

    @abstractmethod
    async def create_collection(
        self,
        dense_dimension: int,
        sparse_enabled: bool = True,
    ) -> bool:
        """Create the collection/index."""
        ...

    @abstractmethod
    async def delete_collection(self) -> bool:
        """Delete the entire collection/index."""
        ...

    @abstractmethod
    async def count(self) -> int:
        """Return the total number of vectors in the collection."""
        ...
