"""Vector store configuration."""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class VectorConfig:
    """Settings for the pgvector-backed vector store.

    These are also used by the HNSW index tuning and the search
    repository.
    """

    # Embedding dimensionality (must match the model output)
    dimension: int = 768

    # HNSW build-time parameter
    hnsw_m: int = 16
    hnsw_ef_construction: int = 200

    # HNSW search-time parameter (higher = better recall, slower)
    hnsw_ef_search: int = 40

    # Distance metric used for the HNSW index
    # "cosine" | "l2" | "inner_product"
    distance_metric: str = "cosine"

    @classmethod
    def from_env(cls) -> "VectorConfig":
        return cls(
            dimension=int(os.getenv("VECTOR_DIMENSION", "768")),
            hnsw_m=int(os.getenv("VECTOR_HNSW_M", "16")),
            hnsw_ef_construction=int(os.getenv("VECTOR_HNSW_EF_CONSTRUCTION", "200")),
            hnsw_ef_search=int(os.getenv("VECTOR_HNSW_EF_SEARCH", "40")),
            distance_metric=os.getenv("VECTOR_DISTANCE_METRIC", "cosine"),
        )
