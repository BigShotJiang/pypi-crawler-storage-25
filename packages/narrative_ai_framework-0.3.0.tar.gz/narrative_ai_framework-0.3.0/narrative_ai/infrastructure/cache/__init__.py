"""Cache infrastructure -- Redis (production) and in-memory (dev/test).

Quick-start::

    from narrative_ai.infrastructure.cache import get_cache

    cache = get_cache()           # auto-detects Redis from REDIS_URL
    await cache.set("key", "val", ttl=300)
    val = await cache.get("key")
"""

from .config import CacheConfig
from .base_cache import BaseCache
from .memory_cache import MemoryCache


def get_cache(config: CacheConfig | None = None) -> BaseCache:
    """Factory that returns a Redis cache if ``REDIS_URL`` is set,
    otherwise an in-memory fallback."""
    if config is None:
        config = CacheConfig.from_env()
    if config.is_configured:
        try:
            from .redis_cache import RedisCache

            return RedisCache(config)
        except ImportError:
            return MemoryCache(config)
    return MemoryCache(config)


__all__ = [
    "CacheConfig",
    "BaseCache",
    "MemoryCache",
    "get_cache",
]
