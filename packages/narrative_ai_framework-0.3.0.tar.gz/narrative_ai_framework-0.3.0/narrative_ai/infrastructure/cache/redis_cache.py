"""Redis-backed async cache.

Uses the ``redis`` package's async API.  Falls back gracefully if Redis
is unavailable (log warning, return ``None`` on reads, silently skip
writes). After a connection failure, Redis is disabled for 300s and an
in-memory fallback is used (per-process; not shared across workers).

Operational note: This cache is *best-effort*. When Redis is down,
requests continue with degraded caching. The rate limiter (see
api.middleware.rate_limit) is *strict*: in production it returns 503
when Redis is unavailable. Align runbooks accordingly.
"""

from __future__ import annotations

import json
import logging
import time
from fnmatch import fnmatch
from typing import Any, Optional

import redis.asyncio as aioredis  # type: ignore

from .base_cache import BaseCache
from .config import CacheConfig

logger = logging.getLogger(__name__)


class RedisCache(BaseCache):
    """Production cache backed by Redis.

    Typical key patterns::

        user:{user_id}:preferences
        search:{user_id}:{query_hash}
        session:{session_id}
    """

    def __init__(self, config: Optional[CacheConfig] = None) -> None:
        self._config = config or CacheConfig.from_env()
        self._client: Optional[aioredis.Redis] = None
        self._disabled_until = 0.0
        self._cooldown_seconds = 300
        # Local fallback cache used while Redis is unavailable.
        self._fallback_store: dict[str, tuple[str, Optional[float]]] = {}

    def _is_temporarily_disabled(self) -> bool:
        return time.monotonic() < self._disabled_until

    def _mark_unavailable(self, operation: str, key_or_pattern: str, exc: Exception) -> None:
        """Disable Redis briefly after connection failures to avoid repeated stalls."""
        self._disabled_until = time.monotonic() + self._cooldown_seconds
        self._client = None
        logger.warning(
            "Redis %s failed for key=%s: %s. Disabling Redis cache for %ss and using in-memory fallback.",
            operation,
            key_or_pattern,
            exc,
            self._cooldown_seconds,
        )

    def _fallback_get(self, key: str) -> Optional[str]:
        item = self._fallback_store.get(key)
        if item is None:
            return None
        value, expires_at = item
        if expires_at is not None and expires_at <= time.time():
            self._fallback_store.pop(key, None)
            return None
        return value

    def _fallback_set(self, key: str, value: str, ttl: Optional[int] = None) -> None:
        ttl_value = ttl if ttl is not None else self._config.ttl_default
        expires_at = time.time() + ttl_value if ttl_value and ttl_value > 0 else None
        self._fallback_store[key] = (value, expires_at)

    def _fallback_delete(self, key: str) -> None:
        self._fallback_store.pop(key, None)

    def _fallback_exists(self, key: str) -> bool:
        return self._fallback_get(key) is not None

    def _fallback_flush_pattern(self, pattern: str) -> int:
        keys = list(self._fallback_store.keys())
        deleted = 0
        for key in keys:
            if fnmatch(key, pattern):
                self._fallback_store.pop(key, None)
                deleted += 1
        return deleted

    async def _get_client(self) -> aioredis.Redis:
        if self._client is None:
            self._client = aioredis.from_url(
                self._config.redis_url,
                decode_responses=True,
                socket_connect_timeout=5,
                retry_on_timeout=True,
            )
        return self._client

    # ------------------------------------------------------------------
    # BaseCache implementation
    # ------------------------------------------------------------------

    async def get(self, key: str) -> Optional[str]:
        if self._is_temporarily_disabled():
            return self._fallback_get(key)
        try:
            client = await self._get_client()
            return await client.get(key)
        except Exception as exc:
            self._mark_unavailable("GET", key, exc)
            return self._fallback_get(key)

    async def set(self, key: str, value: str, ttl: Optional[int] = None) -> None:
        if self._is_temporarily_disabled():
            self._fallback_set(key, value, ttl)
            return
        try:
            client = await self._get_client()
            await client.set(key, value, ex=ttl or self._config.ttl_default)
        except Exception as exc:
            self._mark_unavailable("SET", key, exc)
            self._fallback_set(key, value, ttl)

    async def delete(self, key: str) -> None:
        if self._is_temporarily_disabled():
            self._fallback_delete(key)
            return
        try:
            client = await self._get_client()
            await client.delete(key)
        except Exception as exc:
            self._mark_unavailable("DELETE", key, exc)
            self._fallback_delete(key)

    async def exists(self, key: str) -> bool:
        if self._is_temporarily_disabled():
            return self._fallback_exists(key)
        try:
            client = await self._get_client()
            return bool(await client.exists(key))
        except Exception as exc:
            self._mark_unavailable("EXISTS", key, exc)
            return self._fallback_exists(key)

    async def flush_pattern(self, pattern: str) -> int:
        """Delete keys matching a glob *pattern* using SCAN (safe for prod)."""
        if self._is_temporarily_disabled():
            return self._fallback_flush_pattern(pattern)
        try:
            client = await self._get_client()
            deleted = 0
            async for key in client.scan_iter(match=pattern, count=200):
                await client.delete(key)
                deleted += 1
            return deleted
        except Exception as exc:
            self._mark_unavailable("FLUSH", pattern, exc)
            return self._fallback_flush_pattern(pattern)

    # ------------------------------------------------------------------
    # Convenience typed helpers
    # ------------------------------------------------------------------

    async def get_json(self, key: str) -> Optional[Any]:
        raw = await self.get(key)
        if raw is None:
            return None
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return None

    async def set_json(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        await self.set(key, json.dumps(value, default=str), ttl=ttl)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None
