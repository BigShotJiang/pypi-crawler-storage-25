"""Cache configuration loaded from environment variables."""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class CacheConfig:
    """Redis connection and TTL settings.

    Environment variables
    ---------------------
    REDIS_URL : str
        e.g. ``redis://localhost:6379/0``
    CACHE_TTL_SEARCH : int  (seconds, default 1800 = 30 min)
    CACHE_TTL_PREFERENCES : int  (seconds, default 86400 = 1 day)
    CACHE_TTL_SESSION : int  (seconds, default 86400 = 1 day)
    CACHE_TTL_DEFAULT : int  (seconds, default 3600 = 1 hour)
    """

    redis_url: str = ""
    ttl_search: int = 1800
    ttl_preferences: int = 86400
    ttl_session: int = 86400
    ttl_default: int = 3600

    @classmethod
    def from_env(cls) -> "CacheConfig":
        return cls(
            redis_url=os.getenv("REDIS_URL", ""),
            ttl_search=int(os.getenv("CACHE_TTL_SEARCH", "1800")),
            ttl_preferences=int(os.getenv("CACHE_TTL_PREFERENCES", "86400")),
            ttl_session=int(os.getenv("CACHE_TTL_SESSION", "86400")),
            ttl_default=int(os.getenv("CACHE_TTL_DEFAULT", "3600")),
        )

    @property
    def is_configured(self) -> bool:
        return bool(self.redis_url)
