"""Abstract cache interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional


class BaseCache(ABC):
    """Port for a key-value cache (Redis, Memcached, in-memory)."""

    @abstractmethod
    async def get(self, key: str) -> Optional[str]: ...

    @abstractmethod
    async def set(self, key: str, value: str, ttl: Optional[int] = None) -> None: ...

    @abstractmethod
    async def delete(self, key: str) -> None: ...

    @abstractmethod
    async def exists(self, key: str) -> bool: ...

    @abstractmethod
    async def flush_pattern(self, pattern: str) -> int:
        """Delete all keys matching *pattern* (e.g. ``user:123:*``).

        Returns the number of keys deleted.
        """
        ...
