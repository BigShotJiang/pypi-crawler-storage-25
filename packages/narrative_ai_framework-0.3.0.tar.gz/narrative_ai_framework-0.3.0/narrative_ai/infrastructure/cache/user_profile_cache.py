"""User Profile Cache.

Stores a compact per-user profile snapshot (entry count, top emotions,
recent tags, date range, preferred language) in the existing cache
infrastructure (Redis in production, MemoryCache in dev/test).

Key pattern:  user_profile:{user_id}
TTL:          15 minutes (configurable via USER_PROFILE_CACHE_TTL env var)

Invalidation: call invalidate(user_id) whenever the user creates, updates,
or deletes a diary entry.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from dataclasses import asdict, dataclass, field
from typing import List, Optional

from .base_cache import BaseCache
from . import get_cache

logger = logging.getLogger(__name__)

# Default TTL: 15 minutes
_DEFAULT_TTL = int(os.getenv("USER_PROFILE_CACHE_TTL", "900"))

_KEY_PREFIX = "user_profile"


def _cache_key(user_id: uuid.UUID) -> str:
    return f"{_KEY_PREFIX}:{user_id}"


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class UserProfileSnapshot:
    """Compact user profile injected into every LLM system prompt."""

    user_id: str
    display_name: str
    entry_count: int
    top_emotions: List[str] = field(default_factory=list)
    top_tags: List[str] = field(default_factory=list)
    recent_topics: List[str] = field(default_factory=list)
    first_entry_date: Optional[str] = None
    last_entry_date: Optional[str] = None
    preferred_language: str = "en"

    def to_system_prompt_text(self) -> str:
        """Return a concise natural-language description for LLM injection."""
        lines = [
            f"User: {self.display_name}",
            f"Total diary entries: {self.entry_count}",
        ]
        if self.top_emotions:
            lines.append(f"Common emotions: {', '.join(self.top_emotions)}")
        if self.top_tags:
            lines.append(f"Frequent topics/tags: {', '.join(self.top_tags)}")
        if self.recent_topics:
            lines.append(f"Recent topics: {', '.join(self.recent_topics)}")
        if self.first_entry_date and self.last_entry_date:
            lines.append(f"Writing since {self.first_entry_date} (last entry: {self.last_entry_date})")
        lines.append(f"Preferred language: {self.preferred_language}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Cache service
# ---------------------------------------------------------------------------


class UserProfileCache:
    """Thin wrapper around BaseCache for user profile snapshots.

    Uses JSON serialisation so it works with both RedisCache and MemoryCache.
    """

    def __init__(self, cache: BaseCache, ttl: int = _DEFAULT_TTL) -> None:
        self._cache = cache
        self._ttl = ttl

    async def get(self, user_id: uuid.UUID) -> Optional[UserProfileSnapshot]:
        """Return cached profile or None if missing/expired."""
        key = _cache_key(user_id)
        raw = await self._cache.get(key)
        if raw is None:
            logger.debug("Profile cache MISS for user %s", user_id)
            return None
        try:
            data = json.loads(raw)
            logger.debug("Profile cache HIT for user %s", user_id)
            return UserProfileSnapshot(**data)
        except Exception as exc:
            logger.warning("Failed to deserialise profile cache for user %s: %s", user_id, exc)
            return None

    async def set(self, profile: UserProfileSnapshot) -> None:
        """Store a profile snapshot in the cache."""
        key = _cache_key(uuid.UUID(profile.user_id))
        try:
            await self._cache.set(key, json.dumps(asdict(profile)), ttl=self._ttl)
            logger.debug("Profile cached for user %s (TTL=%ds)", profile.user_id, self._ttl)
        except Exception as exc:
            logger.warning("Failed to cache profile for user %s: %s", profile.user_id, exc)

    async def invalidate(self, user_id: uuid.UUID) -> None:
        """Remove the cached profile so the next request rebuilds it."""
        key = _cache_key(user_id)
        await self._cache.delete(key)
        logger.debug("Profile cache invalidated for user %s", user_id)


_profile_cache_instance: Optional[UserProfileCache] = None


def get_user_profile_cache() -> UserProfileCache:
    """Return a shared UserProfileCache backed by the configured cache provider."""
    global _profile_cache_instance
    if _profile_cache_instance is None:
        _profile_cache_instance = UserProfileCache(get_cache())
    return _profile_cache_instance
