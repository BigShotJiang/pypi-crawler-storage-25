"""In-memory cache for development and testing.

Entries are stored in a plain dict and automatically evicted after
their TTL expires (checked lazily on access).  No inter-process
sharing -- suitable only for single-process / test scenarios.
"""

from __future__ import annotations

import fnmatch
import time
from typing import Dict, Optional, Tuple

from .base_cache import BaseCache
from .config import CacheConfig


class MemoryCache(BaseCache):
    """Process-local fallback cache (no Redis required)."""

    def __init__(self, config: Optional[CacheConfig] = None) -> None:
        self._config = config or CacheConfig()
        # value, expiry_ts
        self._store: Dict[str, Tuple[str, float]] = {}

    def _is_expired(self, key: str) -> bool:
        if key not in self._store:
            return True
        _, expiry = self._store[key]
        if time.time() > expiry:
            del self._store[key]
            return True
        return False

    async def get(self, key: str) -> Optional[str]:
        if self._is_expired(key):
            return None
        return self._store[key][0]

    async def set(self, key: str, value: str, ttl: Optional[int] = None) -> None:
        t = ttl or self._config.ttl_default
        self._store[key] = (value, time.time() + t)

    async def delete(self, key: str) -> None:
        self._store.pop(key, None)

    async def exists(self, key: str) -> bool:
        return not self._is_expired(key)

    async def flush_pattern(self, pattern: str) -> int:
        keys_to_delete = [k for k in list(self._store.keys()) if fnmatch.fnmatch(k, pattern)]
        for k in keys_to_delete:
            del self._store[k]
        return len(keys_to_delete)
