import sys

def args() -> tuple[bool,str|None,str|None,dict]:
    argv = sys.argv[1:]
    acts = [a for a in argv if not a.startswith('-')]
    flgs = [a for a in argv if a.startswith('-')]
    
    # True because by defaul we need to show help
    valid = True

    command = None
    if len(acts) != 0:
        command = argv[0]
        valid = argv[0] == acts[0]

    action = None
    if len(acts) >= 2 and valid:
        action = argv[1]
        valid = argv[1] == acts[1]

    flags = {}
    for a in flgs:
        k = a.split('=')[0]
        v = a.replace(k + "=", "")
        if len(v) > 2 and v[0] == v[-1] and v[0] in ["'",'"']:
            v = v.strip(v[0])
        
        v = True if v == a else v
        flags[k.lstrip("-")] = v

    return valid,command, action, flags


