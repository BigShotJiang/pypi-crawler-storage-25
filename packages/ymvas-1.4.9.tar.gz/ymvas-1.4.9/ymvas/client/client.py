from functools import lru_cache

import os, json, yaml
from os.path import join, relpath, exists, dirname
from typing import Any

from ymvas.gitsrv import YmvasBackupService, GitServer,Compiler
from ymvas.maincf.config import YGlobalConfig
from ymvas.creator.creator import GitCreator

from ymvas.settings import Settings
from ymvas.utils    import find_root
from ymvas.errors   import YException, YWorkspaceException

from .utils import args

class Operator( Settings ):

    def __init__( self, src:str = "" ):
        self.gconf = YGlobalConfig()
        self.info  = yaml.safe_load(open(
            join(dirname(__file__) , 'arguments.yaml' )
        ).read())

        valid, command , action , flags = args()
        self._valid   = valid
        self._command = command
        self._action  = action
        self._flags   = flags
        self._src     = src

        # setup the settings
        Settings.__init__( self , self.src )

        if not self.gconf.is_setup:
            if self.is_main:
                self.gconf.set('workspace.src',self.root)
            self.gconf.setup()

    @property
    def version(self) -> bool:
        return "version" in self._flags or "v" in self._flags

    @property
    def help(self) -> bool:
        return "help" in self._flags or "h" in self._flags

    @property
    @lru_cache
    def src(self) -> str:
        if self.version or self._command == 'init':
            return self._src
        
        root = self.gconf.workspace.source_path
        def _in(s,sb):
            return s in self._flags or sb in self._flags
        
        if _in('workspace','w') and root is not None:
            return root

        src = self._src
        if _in('src','s'):
            src = self._flags.get('s',self._flags.get('src'))
        
        # final check
        src = src if src is not None else self._src
        src, is_repo = find_root( src )
        if is_repo:
            return src

        # if not in a directory
        if root is None:
            return self._src

        return root

    def parse(self) -> tuple[Any, tuple|list, dict]:
        is_valid = self._valid
        command  = self._command
        action   = self._action
        
        if not is_valid:
            return None , (), {}
        
        command_data = self.info['commands'].get(self._command)
        
        # self repository scripts
        if command_data is None:
            for c in self.commands:
                if c['cmd'] != command:
                    continue
                cmd = c['run'] + " " + c['path']
                return self.exec, [cmd], {}

        if command_data is None:
            return None, (), {}
        
        def help():
            print(command_data['help'])
            return 0
        
        def _err():
            print(command_data['error'])
            return 0

        # expected actions
        actions = command_data.get('actions')
           
  
        _def = command_data.get( 'def' )
        _use = getattr( self , _def )
        
        # flags
        _flags = command_data.get('flags',{})
        if action is not None:
            x_flags = {}
            for k,v in _flags.items():
                _for = v.get("for")
                if isinstance(_for,list):
                    if action in _for:
                        x_flags[k] = v
                elif isinstance(_for,dict):
                    x_for = list(_for.keys())
                    if action in x_for:
                        x_flags[k] = {
                           **v, **_for[action]
                        }
                else:
                    continue
            _flags = x_flags

        _flagk = list(_flags.keys())

          
        # conditions
        if actions is None:                 # does not expect actions
            if self._action != None:        # but action given
                return help,(),{}
        else:                               # expects actions 
            if self._action is None:        # no action writen in the terminal
                return help,(),{}
            if self._action not in actions: # action not defined in arguments.yaml
                return help,(),{}
        
        if len(_flagk) == 0:                # if expects no flags
            if len(self._flags.keys())!= 0: # but given flgas from terminal
                return _err, (), {}


        parsed_flags = {}
        # check if NOT requires flags and if given throw error
        for f,v in _flags.items():
            s = v.get('short'         , f     )
            r = v.get('required'      , False )
            t = v.get('type'          , "str" )
            d = v.get('default'       , None  )
            e = v.get('exclude-flags' , {}    )
            q = v.get('requires'      , {}    )
            

            # if flag detectet
            _in = s in self._flags or f in self._flags

            # flag value 
            flag_val = self._flags.get(s, self._flags.get(f,d))
            
            # return error if requires a flag 
            if r and flag_val is None:
                return _err, (), {}

            if not r and ( flag_val is None or (t == 'bool' and flag_val is False )):
                continue
            
            # fix exclusion
            for ef,ev in e.items():
                es = _flags[ef].get('short',ef)
                ed = _flags[ef].get('default',None)
                
                if es in self._flags or ef in self._flags:
                    eev = self._flags.get(
                        es,self._flags.get(ef,ed)
                    )

                    if ev == None or ev == eev:
                        return _err, (), {}

            # fix requires
            for qf,qv in q.items():
                qs = _flags[qf].get('short'   , qf   )
                qd = _flags[qf].get('default' , None )
                
                if qs in self._flags or qf in self._flags:
                    continue

                qev = self._flags.get(
                  qs,self._flags.get(qf,qd)
                )

                if qv == None or qv == qev:
                    return _err, (), {}
            
            if not _in:
                continue    

            if t == 'bool' and not isinstance(flag_val,bool):
                return _err, (), {}

            parsed_flags[f] = flag_val


        args = []
        if self._action != None:
            args.append( self._action )

        return _use, (a for a in args), parsed_flags
    

    def exec( self, cmd:str ,**kwargs) -> int:
        os.system( cmd )
        return 1
    
    def create(
            self ,
            template:str      = 'main' ,
            access:str | None = None   ,
            bare:bool         = False
        ):
        
        creator = GitCreator(
            self._src,
            mode = template,
            is_bare = bare == True
        )

        if access is not None:
            try:
                access = json.loads(access)
                for u,v in access.items():
                    creator.set_permisions(
                        u,
                        v.get('read', False),
                        v.get('write', False)
                    )
            except Exception as e:
                return 0

        creator.create()
        return 1


    def task(self, action:str, **kwargs):
        conf = self.get_repo_tasks_config()


        if action == 'get':
            tasks = conf.list()

            if len(tasks) == 0:
                print('no tasks here')
                return

            for i, task in enumerate(tasks):
                rl = relpath(task.src, self.d_tasks)
                print( f" {i} " + rl )

            selected = None
            while selected is None:
                task = input(" - select a task from this list or type `q` to exit:")

                if task == 'q':
                    exit()

                if not task.isnumeric() or len(tasks) <= int(task):
                    print(f'\033[31m - invalid selection [{task}] \033[0m')
                    continue

                selected = int(task)

            t = tasks[selected]

            print("")
            for s in t.bs_udfs():
                print((" " * s.level) + s.display())

            return

        elif action == 'list':
            tasks = conf.list()

            for task in tasks:
                rl = relpath(task.src, self.d_tasks)
                print( "   " + rl )

            return

    def config(self, action:str , **kwargs):
        if action == 'designate':
            if not self.is_repo:
               print("can't designate this directory as it's not a repositoy!")
               return
            
            self.gconf.set('workspace.src'      , self.root       )
            self.gconf.set('workspace.commands' , self.d_commands )

        elif action == "show":
            print(json.dumps(self.gconf._conf,indent=2))
            return
        elif action == 'set':
            for k,v in kwargs.items():
                self.gconf.set(k,v)
        elif action == 'del':
            for k in kwargs.keys():
                self.gconf.drop(k)
        elif action == "get":
            am = len(kwargs.keys())
            for k in kwargs.keys():
                sg = self.gconf.get(k)
                if am == 1:
                    print(sg)
                else:
                    print(f"{k} -> {sg}")
            return

        self.gconf.save()


    def server(self, action, **kwargs):
        gbsrv  = YmvasBackupService()
        gsrv   = GitServer()
        
        target = kwargs.get('target')
        if action == 'setup':
            user,skey = kwargs['user'], kwargs['skey']
            gsrv.setup(user,skey)
        elif cmd == 'backup':
            if target is None:
                target = self._src
            src = gbsrv.create(target)
            print(f"backup created: {src}")
        elif cmd == 'restore':
            gbsrv.restore(target)
        elif cmd == 'compile':
            data = Compiler( self , self.compile ).run()
            print(json.dumps( data , indent = 2 ))
            print('src ->', self.compile )
        elif cmd == 'ping':
            domain  = self.gconf.origin.domain
            command = f'ssh git@{domain} git-ping'
            os.system(command)

 

    # extras
    @property
    @lru_cache
    def commands(self) -> list:
        if not self.is_repo:
            return []
        
        is_global = 'w' in self._flags or 'workspace' in self._flags

        if is_global and self.gconf.workspace.commands_path is not None:
            self.d_commands = self.gconf.workspace.commands_path

        if not exists(self.d_commands):
            return []

        return self.get_repo_comands_config().list()
    

    def __repr__(self) -> str:
        max_key = 21

        def justify(key:str, desc:str="",minus=0):
            nonlocal max_key
            desc = desc.replace('\n', (" " * (max_key-minus)) + "\n" )
            return f"{key.ljust(max_key-minus)} {desc}"

        data = self.info['help']
        rcli = ""

        if self.is_repo:
            cmds = [(
                c['cmd'],
                (
                    "-> " + relpath(c['path'],self.d_commands)
                    if c['desc'] is None else c['desc']
                )
            ) for c in self.commands ]

            max_cmd = max(len(x[0]) for x in cmds) if len(cmds) > 0 else 0
            max_key = max_key if max_cmd < max_key else max_cmd + 2

            meta = "" if not self.is_ymvas and not self.is_main else (
                f"{'Y' if self.is_ymvas else ''}"
                f"{'M' if self.is_main else ''}"
            )

            rcli = self.info['repocli'].format(
                alias = f"\033[1;32m{self.alias}\033[0m",
                main  = meta,
                extra = "    " + ("\n    ".join(justify(x,d,2) for x,d in cmds ))
            )

        data = data.format(
            repocli = rcli,
            conf = self.gconf.src
        )
        return data

    def print_help(self) -> None:
        print(self)



