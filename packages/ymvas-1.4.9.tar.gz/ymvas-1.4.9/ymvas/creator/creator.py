import yaml,shutil
from os.path import dirname, join, exists, basename
from ymvas import YWorkspaceException
from ymvas.utils import walker
from .gitutils import commit, build_tree, read_object, parse_tree, blob, tree
from os import makedirs
import configparser
from io import StringIO

from ymvas.maincf.config import YGlobalConfig

_dir = dirname(__file__)

class GitCreator:

    VALID_TYPES = {
        "account" : {
            "path"     : join(_dir,'templates','account'),
            "requires" : ['.ymvas'],
            "barereqs" : ['ymconf.yaml'],
            "bare"     : True
        },
        "main" : {
            "path"     : join(_dir,'templates','main'),
            "requires" : ['.ymvas'],
            "barereqs" : ['ymconf.yaml'],
            "bare"     : True,
        },
        "local"   : {
            "path"     : join(_dir,'templates','local'),
            "requires" : ['.ymvas'],
            "barereqs" : ['ymconf.yaml'],
            "bare"     : False,
            "ignored"  : True
        },
    }

    def __init__(
            self            ,
            target     : str ,
            mode       : str  = "default",
            is_bare    : bool = False,
            exists_ok  : bool = False,
            main_branch : str  = 'master'
        ) -> None:

        if mode not in self.VALID_TYPES:
            raise YWorkspaceException(
                'invalid-init-mode' ,
                mode  = mode        ,
                usage = "<" + "|".join( self.VALID_TYPES.keys() ) + ">"
            )

        self.gconf = YGlobalConfig()
        
        self.commit_author    = self.gconf.origin.author_email
        self.main_branch      = main_branch
        self.exists_ok        = exists_ok
        self.target           = target
        self.is_bare          = is_bare
        self.mode             = mode
        self._bare_permisions = {}

    
    @property
    def name(self) -> str:
        name = basename(self.target)
        name = name.split('.')
        name = name if len(name) == 1 else name[:-1]
        return '.'.join(name)


    def set_permisions(self, user:str, r:bool, w:bool) -> None:
        self._bare_permisions[user] = {
            "access" : f"{'r' if r else ''}{'w' if w else ''}"
        }

    def _get_bare_folders(self, folder:str ) -> dict[str,str]:
        return {
            "branches"     : join(folder, "branches"          ),
            "hooks"        : join(folder, "hooks"             ),
            "info"         : join(folder, "info"              ),
            "objects"      : join(folder, "objects"           ),
            "objects/info" : join(folder, "objects" , "info"  ),
            "objects/pack" : join(folder, "objects" , "pack"  ),
            "refs"         : join(folder, "refs"              ),
            "refs/heads"   : join(folder, "refs"    , "heads" ),
            "refs/tags"    : join(folder, "refs"    , "tags"  ),
        }

    def _add_local_exclusion(self):
        _git = join(self.target, '.git')
        if not exists(_git):
            return

        ignore = join(_git, 'info', 'exclude')
        entry  = ".ymvas/"

        # file doesn't exist → create with entry
        if not exists( ignore ):
            with open( ignore , "w" ) as f:
                f.write(entry + "\n")
            return

        # file exists → append only if entry missing
        with open(ignore, "r+") as f:
            content = f.read().splitlines()
            if entry not in content:
                f.write(entry + "\n")


    def _create_bare(self) -> bool:
        data = self.VALID_TYPES[self.mode]
        requires = data['barereqs']

        if exists(self.target) and self.exists_ok:
            return True

        if not self.exists_ok:
            # for non bare creation check if it was already inited
            for r in requires:
                if exists(join( self.target, r )):
                    raise YWorkspaceException(
                        'invalid-init-already-exists',
                        src = self.target
                    )
        
        src = self.target
        for p in self._get_bare_folders(src).values():
            makedirs(p, exist_ok=True)

        files = {
            "HEAD": "ref: refs/heads/master\n",
            "description": "Unnamed repository; edit this file 'description' to name the repository.\n",
            "config": (
                "[core]\n"
                "    repositoryformatversion = 0\n"
                "    filemode = true\n"
                "    bare = true\n"
            ),
            "ymconf.yaml": yaml.dump({
                "users": self._bare_permisions
            }),
            "info/exclude": (
                "# git ls-files --others --exclude-from=.git/info/exclude\n"
                "# Lines that start with '#' are comments.\n"
                "# *.[oa]\n"
                "# *~\n"
            ),
        }

        for k, v in files.items():
            path = join(src, k)
            makedirs(dirname(path), exist_ok=True)
            with open(path, "w") as f:
                f.write(v)


        root_tree  = build_tree( data['path'] , src )
        commit_sha = commit(
            src, 
            root_tree,
            author_name = self.gconf.origin.author_name,
            author_mail = self.gconf.origin.author_email, 
            message     = 'init'
        )

        ref = join(src, "refs", "heads", self.main_branch)
        makedirs(dirname(ref), exist_ok=True)

        with open(ref, "w") as f:
            f.write(commit_sha + "\n")
        
        self._bare_permisions = {}
        return True

    def _create_local(self) -> bool:
        data     = self.VALID_TYPES[self.mode]
        requires = data['requires']

        if not self.exists_ok and not self.is_bare:
            # for non bare creation check if it was already inited
            for r in requires:
                if exists(join( self.target, r )):
                    raise YWorkspaceException(
                        'invalid-init-already-exists',
                        src = self.target
                    )
        
        if data.get('ignored',False):
            self._add_local_exclusion()
        
        for f in walker(data['path']):
            dest = f.replace(data['path'],self.target)

            if exists(dest):
                continue

            dic = dirname(dest)
            makedirs(dic,exist_ok=True)
            shutil.copyfile(f, dest)

        self._bare_permisions = {}
        return True

    def create(self) -> bool:
        data = self.VALID_TYPES[self.mode]
        if self.is_bare:
            if data.get("bare",False) == False:
                raise YWorkspaceException(
                    "invalid-init-not-bare",
                    mode = self.mode
                )

            return self._create_bare()
        return self._create_local()


    def add_space(self,url:str):
        name = basename(url)
        name = name.split('.')
        name = name if len(name) == 1 else name[:-1]
        name = '.'.join(name)

        rmaster = join(
            self.target,
            'refs',
            'heads',
            self.main_branch
        )

        with open(rmaster) as f:
            commit_sha = f.read().strip()

        _, commit_data = read_object(self.target, commit_sha)
        tree_sha = None
        for line in commit_data.decode().splitlines():
            if line.startswith("tree "):
                tree_sha = line.split()[1]
                break
            pass
        
        # current root tree
        _, tree_data = read_object(self.target, tree_sha)
        entries = parse_tree(tree_data)

        # create .gitmodules blob
        content = (
            f'[submodule "{name}"]\n'
            f'\tpath = spaces/{name}\n'
            f'\turl = {url}\n'
        ).encode()



        # add to tree
        updated = False
        for i, (mode, xname, sha) in enumerate(entries):
            if xname != ".gitmodules":
                continue

            _, old = read_object(self.target, sha)

            cfg = configparser.ConfigParser()
            cfg.read_string(old.decode())

            cfg[f'submodule "{name}"'] = {
                "path" : f"spaces/{name}",
                "url"  : url
            }

            buf = StringIO()
            cfg.write(buf)
            content = buf.getvalue().encode()

            gm_blob = blob(self.target, content)

            entries[i] = ("100644", ".gitmodules", gm_blob)
            updated = True
            break

        if not updated:
            gm_blob = blob(self.target, content)
            entries.append(("100644", ".gitmodules", gm_blob))

        # create new root tree
        new_tree = tree(self.target, entries)

        # create commit
        new_commit = commit(
            self.target, 
            new_tree ,
            author_name = self.gconf.origin.author_name,
            author_mail = self.gconf.origin.author_email , 
            message     = f'space added in [spaces/{name}]'
        )

        # move branch
        with open(rmaster, "w") as f:
            f.write(new_commit + "\n")



