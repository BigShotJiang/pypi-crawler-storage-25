import hashlib, zlib, time, yaml

from os.path import join, dirname, isfile, isdir, basename
from os import makedirs, listdir
from ymvas.maincf.config import YGlobalConfig



def write_object(
        repository_path: str,
        data: bytes
    ) -> str:

    sha = hashlib.sha1(data).hexdigest()
    path = join(repository_path, "objects", sha[:2], sha[2:])

    makedirs(dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(zlib.compress(data))

    return sha

def read_object(repo, sha):
    path = join(repo, "objects", sha[:2], sha[2:])
    with open(path, "rb") as f:
        data = zlib.decompress(f.read())

    nul = data.index(b"\0")
    header = data[:nul]
    body = data[nul+1:]

    typ = header.split()[0].decode()
    return typ, body

def blob(
        repository_path: str,
        content: bytes
    ) -> str:

    header = f"blob {len(content)}\0".encode()
    return write_object(repository_path, header + content)

def tree(repo:str, entries: list) -> str:
    body = b""

    for mode, name, sha in entries:
        body += f"{mode} {name}\0".encode()
        body += bytes.fromhex(sha)

    header = f"tree {len(body)}\0".encode()
    return write_object(repo, header + body)

def commit(
        repo,
        tree_sha    : str,
        author_name : str = 'ymvas',
        author_mail : str = 'root@local',
        timestamp   : int | None = None ,
        message     : str = 'init'
    ) -> str:

    if timestamp is None:
        timestamp = int(time.time())

    content = (
        f"tree {tree_sha}\n"
        f"author {author_name} <{author_mail}> {timestamp} +0000\n"
        f"committer {author_name} <{author_mail}> {timestamp} +0000\n\n"
        f"{message}"
    ).encode()

    header = f"commit {len(content)}\0".encode()
    return write_object(repo, header + content)


def build_tree(path:str, repository_path:str) -> str:
    entries = []

    for name in sorted(listdir(path)):
        full = join(path, name)

        if isfile(full):
            with open(full, "rb") as f:
                sha = blob(repository_path, f.read())
            entries.append(("100644", name, sha))

        elif isdir(full):
            sha = build_tree(full, repository_path)
            entries.append(("040000", name, sha))

    return tree(repository_path, entries)

def parse_tree(data):
    i = 0
    out = []

    while i < len(data):
        j = data.index(b" ", i)
        mode = data[i:j].decode()

        i = j + 1
        j = data.index(b"\0", i)

        name = data[i:j].decode()
        sha = data[j+1:j+21].hex()

        out.append((mode, name, sha))
        i = j + 21

    return out

def git_url_parse( url:str ) -> tuple[str|None,bool]:
    cnf = YGlobalConfig()
    is_ymvas = f"@{cnf.origin.domain}" in url

    # get repo user 
    user1 = url.split('@')[-1]
    user  = user1.replace(basename(url),'')
    user  = basename(user.strip('/'))
    user  = user.split(':')[-1]
    user  = user.strip('/')
    user  = user if '/' not in user else None

    if user is not None:
        user = None if user1.startswith( user ) else user

    return user, is_ymvas


