import yaml, json, os, pathlib
from os.path import exists, join, basename
from pathlib import Path

def _loader(path:str, default = {}, _def=json.loads):
    _type = type(default)

    if not os.path.exists(path):
        return default

    try:
        with open(path,'r') as f:
            data = _def(f.read())
            if not isinstance(data,_type):
                return default
            return data
    except Exception:
        return default


def get_yaml(path:str, default = {}):
    return _loader(
        path,
        default = default, 
        _def = yaml.safe_load
    )
    
def get_json(path:str, default = {}):
    return _loader(
        path,
        default = default, 
        _def = json.loads
    )


def walker(_dir:str):
    for r,_,files in os.walk(_dir):
        for f in files:
            yield os.path.join(r,f)


def climber(_dir:str):
    _base = pathlib.Path(_dir)
    yield _dir
    for p in _base.parents:
        yield str(p)



def find_root(src:str) -> tuple[str,bool]:
    def _git_bash_fix(p:str) -> str:
        dr = Path(p)
        if str(dr).startswith("/c/") or str(dr).startswith("\\c\\"):
            dr = Path("C:" + str(dr)[2:])
        return str(dr)

    for c in climber(src):
        ymf = join(c,".ymvas")
        git = join(c,".git")

        if not exists(ymf) and exists(git):
            return _git_bash_fix(c), False
        
        if exists(ymf):
            return _git_bash_fix(c), True

    return _git_bash_fix(src), False


