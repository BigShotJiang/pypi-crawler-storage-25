#!/usr/bin/env python3

import os, sys
from ymvas.gitsrv.gitsrv import GitServer

def die(msg:str, ex = 1):
    sys.stderr.write(msg + "\n")
    sys.exit(ex)

if __name__ == '__main__':
    gsrv = GitServer(exceptions = False)

    cmd = os.environ.get("SSH_ORIGINAL_COMMAND")
    if not cmd:
        die("No SSH command")

    cmd = str(cmd) # stringify for typesafe

    parts = cmd.split()
    if len(parts) != 2:
        die("Invalid git command")

    git_cmd, repo = parts
    repo = repo.strip("'").removesuffix(".git").lstrip('/')

    repo_path = f"{gsrv.REPOSITORIES}/{repo}.git"
    user = sys.argv[-1].split("=")[-1]
    
    if git_cmd == "git-upload-pack":
        access = gsrv.has_read_privileges(repo,user)
        if access:
            os.execvp(
                git_cmd,
                [ git_cmd, repo_path ]
            )
    
    elif git_cmd == 'git-receive-pack':
        access = gsrv.has_write_privileges(repo,user)
        if access:
            os.execvp(
                git_cmd,
                [git_cmd, repo_path]
            )

    elif git_cmd == 'git-ping':
        sys.stdout.write("server is ready")
        sys.exit(0)

