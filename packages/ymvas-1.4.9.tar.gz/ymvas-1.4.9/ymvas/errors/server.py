from .exceptions import YException

class YServerException(YException):
    SERVER_ERROR_MESSAGES = {
        "backup-not-found" : {
            "msg" : "The file you provided for backup does not exists! [{src}]",
            "color" : "red"
        },
        "invalid-backup-restore" : {
            "msg" : "The backup you privided has files without destination: {src}",
            "color" : "red"
        },
        "invalid-backup-file" : {
            "msg"   : "The backup file you privided failed: [{reason}]",
            "color" : "red"
        },
        "missing-ssh-key" : {
            "msg" : "The ssh-key path you provided is invalid! [{src}]",
            "color" : "red"
        },

   
        'reference-not-compiled' : {
            'msg'   : "[{src}] was not complied correctly, please use Referer properly!",
            "color" : "yellow"
        },



    }


    @property
    def errors(self) -> dict:
        return {
            **self.SERVER_ERROR_MESSAGES,
            **YException.GLOBAL_ERROR_MESSAGES
        }
