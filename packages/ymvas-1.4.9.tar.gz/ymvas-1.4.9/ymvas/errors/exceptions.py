from __future__ import annotations

from functools import lru_cache
import sys

from ymvas.maincf.system import config_src, config_directory
class YException(Exception):

    GLOBAL_ERROR_MESSAGES = {
        "unexpected" : {
            "msg"   : "This error has not been documented!",
            "color" : "red"
        },
        "global-config-misconfigured": {
            "msg"   : "Unable to parse config file [{config_src()}], please remove it or fix the contents",
            "color" : "red"
        },
        "global-config-not-created" : {
            "msg"   : "Unable to create global config file please check permisions! : [{config_src()}]",
            "color" : "red"
        },
        "global-dir-not-created" : {
            "msg"  : "Unable to create global directory, please check permisions for this directory [{config_directory()}]!",
            "color" : "red"
        },
    }

    def __init__(self, key:str ,**kwargs):
        if key not in self.errors:
            key = "unexpected"

        data = self.errors[key]
        mess = data['msg'].format(**kwargs)

        # add extra info for cli
        if self.is_cli and 'cli' in data:
            mess += "\n" + data['cli']

        # add color if cli command
        if self.is_cli and 'color' in data:
            mess = self.color(data['color'], mess)

        super().__init__(mess)
        self._msg = mess

    @property
    @lru_cache
    def is_cli(self) -> bool:
        valid = ['ym']
        for a in sys.argv:
            if a in valid:
                return True
        return False

    def color(self, color:str, msg:str) -> str:
        cls = {
            "red"    : lambda x: f"\033[31m{x}\033[0m",
            "green"  : lambda x: f"\033[32m{x}\033[0m",
            "yellow" : lambda x: f"\033[33m{x}\033[0m",
            "blue"   : lambda x: f"\033[34m{x}\033[0m",
        }

        return cls.get(
            color,
            lambda x:x
        )(msg)

    @property
    def message(self) -> str:
        return self._msg

    @property
    def errors(self) -> dict:
        return self.GLOBAL_ERROR_MESSAGES
