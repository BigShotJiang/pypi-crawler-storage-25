from __future__ import annotations

from .exceptions import YException

class YWorkspaceException( YException ):

    WORKSPACE_ERROR_MESSAGES = {
        # init
        "invalid-init-mode" : {
            "msg"   : "invalid init mode [{mode}]",
            "color" : "yellow"
        },
        "invalid-init-already-exists" : {
            "msg"   : "this path is already setup [{src}]" ,
            "color" : "yellow"
        },
        "invalid-init-not-bare" : {
            "msg"   : "can't create a bare repository with mode [{mode}]",
            "color" : "yellow"
        },

        
        'complex-secret' : {
            'msg'   : "[{src}] contains references and can't be updated!",
            "color" : "yellow"
        },
    }


    @property
    def errors(self) -> dict:
        return {
            **self.WORKSPACE_ERROR_MESSAGES,
            **YException.GLOBAL_ERROR_MESSAGES
        }
