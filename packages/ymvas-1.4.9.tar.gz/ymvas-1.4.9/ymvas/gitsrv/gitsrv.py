from __future__ import annotations


from functools import lru_cache
from os.path import exists, expanduser, join
from ymvas.maincf.config import YGlobalConfig
from ymvas.maincf.system import get_pkg_localtion
from ymvas.errors import YException, YServerException
from ymvas.utils.files import get_yaml


class GitServer:
    # BASE CONFIG
    CONFIG:YGlobalConfig = YGlobalConfig()

    HOME            : str = CONFIG.server.home_path
    AUTHORIZED_KEYS : str = CONFIG.server.authorized_keys_path
    REPOSITORIES    : str = CONFIG.server.repository_path

    def __init__(self, exceptions = True) -> None:
        pass


    def exists(self,user:str,name:str) -> bool:
        return exists(
            join( self.REPOSITORIES , user, f"{name}.git" )
        )

    def setup(self, user:str, sshkey:str ):
        # this will create ssh record in the authorized_keys
        auth_keys = expanduser(self.AUTHORIZED_KEYS)
        sshkey    = expanduser(sshkey)

        if not exists(sshkey):
            raise YServerException('missing-ssh-key', src = sshkey )

        content = None
        with open(sshkey) as f:
            content = f.read().strip()

        # in case of some strange file
        if content is None or content == '':
            raise YServerException('missing-ssh-key', src = sshkey )

        src = get_pkg_localtion()
        srv = join(src,'server.py')

        srv_exec = f"{srv} user='{user}'"

        full_command = (
            f"command=\"{srv_exec}\","
            f"no-port-forwarding,"
            f"no-X11-forwarding,"
            "no-agent-forwarding,"
            f"no-pty {content}"
        )

        if exists(auth_keys):
            with open(auth_keys) as f:
                for l in f:
                    if l.strip() == full_command:
                        print('access was already added!')
                        return

            with open(auth_keys,"a") as f:
                f.write(full_command + "\n")
        else:
            with open(auth_keys,"w") as f:
                f.write(full_command + "\n")

        print('succefully added access!')

    @lru_cache(maxsize=2)
    def _get_rep_access(self,repo:str) -> dict:
        fpath = join( self.REPOSITORIES , repo + '.git' )
        yconf = join( fpath , 'ymconf.yaml' )

        if not exists(yconf):
            return {}

        data = get_yaml(yconf)

        if not isinstance(data,dict):
            return {}

        return data

    def __has_access(self,repo:str,user:str,priv:str) -> bool:
        access = self._get_rep_access(repo)

        if 'users' not in access:
            return False

        users = access['users']
        if user not in users:
            return False

        privleg = users[user]
        if 'access' not in privleg:
            return False

        uacces = privleg['access']
        if not isinstance(uacces,str):
            return False

        return priv.lower() in uacces.lower()

    def has_read_privileges(self,repo:str, user:str) -> bool:
        return self.__has_access(repo,user,'r')

    def has_write_privileges(self,repo:str, user:str) -> bool:
        return self.__has_access(repo,user,'w')
