import io, json, tarfile

from os import makedirs
from os.path import dirname, exists, join
from datetime import datetime as dt

from ymvas.maincf.config import YGlobalConfig
from ymvas.errors import YServerException, YException

class YmvasBackupService:

    def __init__(self) -> None:
        pass

    @property
    def artifacts(self) -> list[dict]:
        conf   = YGlobalConfig()

        repo   = conf.server.repository_path
        cmpd   = conf.server.compile_directory_path
        auth   = conf.server.authorized_keys_path
        extras = conf.server.backup_extras

        data = [
            { "src" : repo , "arcname" : "repositories"    },
            { "src" : auth , "arcname" : "authorized_keys" },
        ]

        # compile dir is not required to backup
        if cmpd is not None:
            data.append({
                'src'     : cmpd,
                'arcname' : 'docs'
            })

        artifs = []
        for m in data:
            src = m["src"]

            for e in extras:
                # if in extras some path has been modified we just update the arcname
                if src == e['src']:
                    m['arcname'] = e['arcname']
                    break

            artifs.append(m)

        arcnames = [a['arcname'] for a in artifs]
        for e in extras:
            if e['arcname'] in arcnames:
                continue
            artifs.append(e)

        return data


    def create(self, target:str ) -> str:
        src = join(
            target,
            dt.now().strftime("%Y%m%d%H%M%S") + ".tar.gz"
        )

        makedirs(target,exist_ok=True)

        with tarfile.open(src,'w:gz') as tar:
            data = [a for a in self.artifacts if exists(a['src'])]

            if len(data) == 0:
                raise YException('global-config-misconfigured')

            for a in data:
                tar.add(a['src'],arcname=a['arcname'])

            from ymvas import __version__
            data = json.dumps(
                {
                    "info"    : self.artifacts,
                    "version" : __version__
                }
            ).encode('utf-8')

            info = tarfile.TarInfo(name='meta.json')
            info.size = len(data)

            tar.addfile(info, io.BytesIO(data))

        return src

    def restore(self, archive:str) -> bool:
        if not exists(archive):
            raise YServerException("backup-not-found", src = archive)

        try:
            tar  = tarfile.open(archive,'r:gz')
            meta = tar.extractfile('meta.json')

            data = json.load(meta)

            # old artifacts info
            restore = {}

            olda = data.get("info",[])
            for o in olda:
                found = False
                arcname = o['arcname']

                for a in self.artifacts:
                    if a['arcname'] == arcname:
                        # in case directory location has changed update it
                        o['src'] = a['src']
                        found = True
                        break

                if found:
                    restore[arcname] = o['src']
                else:
                    raise YServerException('invalid-backup-restore', src = arcname )

            for member in tar.getmembers():
                if member.name == 'meta.json':
                    continue

                start = member.name.split('/')[0]
                dest  = dirname(restore[start])

                makedirs(dest,exist_ok=True)

                if member.isfile():
                    fpath = join(dest,member.name)
                    with tar.extractfile(member) as src, open(fpath, "wb") as dst:
                        dst.write(src.read())
                else:
                    tar.extract(member, path=dest)

        except YException as e:
            raise e
        except Exception as e:
            raise YException("invalid-backup",amsg={
                "reason" : str(e)
            })

        return True
