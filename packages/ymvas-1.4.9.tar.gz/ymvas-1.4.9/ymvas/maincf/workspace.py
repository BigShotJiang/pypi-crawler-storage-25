
from functools import lru_cache
from ymvas.errors import YException

class WorkspaceConfig:

    def __init__(self,conf:dict) -> None:
        self._conf = conf
    
    @property
    @lru_cache
    def workspace(self) -> dict:
        return self._conf.get('workspace',{})

    @property
    @lru_cache
    def source_path(self) -> str | None:
        wk = self.workspace.get('src')

        if wk is None:
            return None

        if not isinstance(wk,str):
            raise YException('global-config-misconfigured')

        return wk

    @property
    @lru_cache
    def commands_path(self) -> str | None:
        wk = self.workspace.get('commands')

        if wk is None:
            return None

        if not isinstance(wk,str):
            raise YException('global-config-misconfigured')

        return wk
