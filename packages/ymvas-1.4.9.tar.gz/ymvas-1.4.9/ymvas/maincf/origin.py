from __future__ import annotations

from functools import lru_cache

from ymvas.errors import YException

class OriginConfig:

    def __init__(self,conf:dict) -> None:
        self._conf = conf

    @property
    @lru_cache
    def origin(self) -> dict :
        return self._conf.get('origin',{})
    

    # parts
    @property
    @lru_cache
    def ssh(self) -> dict :
        return self.origin.get('ssh',{})
    @property
    @lru_cache
    def author(self) -> dict:
        return self.origin.get('author',{})
    @property
    @lru_cache
    def init(self) -> dict:
        return self.origin.get('init',{})

    
    

    ## properties
    @property
    @lru_cache
    def domain(self) -> str:
        data = self.origin.get('domain',"ymvas.com")

        if not isinstance(data,str):
            raise YException('global-config-misconfigured')

        return data

    @property
    @lru_cache
    def ssh_address(self) -> str:
        return str(self.ssh.get( "url","ssh://git@" + self.domain + "/{repo}.git" ))

    @property
    @lru_cache
    def author_name(self) -> str:
        return str(self.author.get("name", "ymvas" ))

    @property
    @lru_cache
    def author_email(self) -> str:
        return str(self.author.get("email", f"git@{self.domain}" ))

    @property
    @lru_cache
    def init_ssh_address(self) -> str:
        return str(self.init.get("ssh-address","ssh://git@"+self.domain+"/{repo}.git" ))


