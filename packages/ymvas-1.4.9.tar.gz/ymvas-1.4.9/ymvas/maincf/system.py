from __future__ import annotations

import os, platform
from functools import lru_cache
from os.path import expanduser, join


@lru_cache(maxsize=None)
def sys_platform() -> str:
    system  = platform.system()
    shell   = os.environ.get("SHELL", "")
    msystem = os.environ.get("MSYSTEM", "")
    
    # Detect Git Bash on Windows
    is_windows_git_bash = (system == "Windows") and (
        "bash" in shell or msystem.startswith("MINGW")
    )

    if is_windows_git_bash:
        return "git-bash"
    elif system == "Windows":
        return "widnows"
    elif system == "Darwin":
        return "mac"
    return 'unix'


def get_pkg_localtion() -> str:
    dn = os.path.dirname
    return dn(dn(__file__))


def config_directory() -> str:
    return join({
        "git-bash" : expanduser("~/.config"),
        "widnows"  : os.environ.get("APPDATA", expanduser(
            "~\\AppData\\Roaming"
        )),
        "mac"      : expanduser("~/Library/Application Support"),
        'unix'     : os.environ.get("XDG_CONFIG_HOME", expanduser(
            "~/.config"
        ))
    }.get(sys_platform(), '~/.config'), 'ymvas')


def config_src() -> str:
    return join(config_directory(),'config.json')
