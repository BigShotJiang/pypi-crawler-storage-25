from __future__ import annotations

import json
from functools import lru_cache
from os.path import expanduser, join, exists
from os import environ, makedirs

from ymvas.errors import YException

from .system import sys_platform, config_src, config_directory
from .origin import OriginConfig
from .workspace import WorkspaceConfig
from .server import ServerConfig




class YGlobalConfig:
    server    : ServerConfig
    workspace : WorkspaceConfig
    origin    : OriginConfig

    # SINGLETON
    _instance    = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return

        self._conf = {}
        if exists(self.src):
            try:
                with open(self.src) as fs:
                    x = json.loads(fs.read())
                    if not isinstance(x,dict):
                        raise YException('global-config-misconfigured')
                    self._conf = x
            except FileNotFoundError:
                self._conf = {}
            except json.JSONDecodeError:
                raise YException("global-config-misconfigured")

        self.server = ServerConfig(self._conf)
        self.workspace = WorkspaceConfig(self._conf)
        self.origin = OriginConfig(self._conf)

        self.__class__._initialized = True


    @property
    @lru_cache
    def directory(self) -> str:
        return config_directory()

    @property
    @lru_cache
    def src(self) -> str:
        return join(self.directory,'config.json')
    
    def save(self):
        from ymvas import __version__
        self._conf['version'] = __version__

        try:
            with open(self.src,'w') as f:
                f.write(json.dumps(self._conf, indent=2))
        except PermissionError:
            raise YException('global-config-not-created')

        # restore services
        self.server = ServerConfig(self._conf)
        self.workspace = WorkspaceConfig(self._conf)
        self.origin = OriginConfig(self._conf)

    def get(self,key:str) -> None | str | bool | int:
        obj = self._conf
        for k in key.split('.'):
            if k not in obj:
                return None
            obj = obj[k]
        return obj

    def set(self,key:str,val:str):
        obj = self._conf
        pth = key.split('.')
        leg = len(pth)

        for i, k in enumerate(pth):
            if k not in obj:
                obj[k] = {}
            if (leg - 1) == i:
                obj[k] = val
                break
            obj = obj[k]

    def drop(self,key:str) -> None:
        obj = self._conf
        pth = key.split('.')
        leg = len(pth)

        for i,k in enumerate(pth):
            if k not in obj:
                return
            if (leg - 1) == i:
                del obj[k]
                break
            obj = obj[k]

    @property
    def is_setup(self) -> bool:
        return 'version' in self._conf

    def setup(self):
        try:
            makedirs( self.directory , exist_ok = True )
        except PermissionError:
            raise YException('global-dir-not-created')
        if not exists( self.directory ):
            raise YException('global-dir-not-created')
        
        self.save()
