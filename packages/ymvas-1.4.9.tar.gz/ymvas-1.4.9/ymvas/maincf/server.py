from __future__ import annotations

from functools import lru_cache
from os.path import expanduser, join
from ymvas.errors import YException



class ServerConfig:

    def __init__(self,conf:dict) -> None:
        self._conf = conf
    
    @property
    def server(self) -> dict:
        return self._conf.get('server',{})

    # server props
    @property
    def repos(self) -> dict:
        return self.server.get('repos',{})
    @property
    def compile(self) -> dict:
        return self.server.get('compile',{})
    @property
    def backup(self) -> dict:
        return self.server.get('backup',{})


    # vars
    @property
    @lru_cache
    def home_path(self) -> str:
        hom = self.server.get('home')

        if hom is None:
            return expanduser("~/")

        if not isinstance(hom,str):
            raise YException('global-config-misconfigured')

        return hom

    @property
    @lru_cache
    def repository_path(self) -> str:
        data = self.repos.get('base')

        if data is None:
            return join(self.home_path,"repositories")

        if not isinstance(data,str):
            raise YException('global-config-misconfigured')

        return data

    @property
    @lru_cache
    def compile_directory_path(self) -> str | None:
        data = self.compile.get('dir')

        if data is None:
            return None

        if not isinstance(data,str):
            raise YException('global-config-misconfigured')

        return data

    @property
    @lru_cache
    def authorized_keys_path(self) -> str:
        return join(self.home_path,'.ssh','authorized_keys')

    @property
    @lru_cache
    def backup_extras(self) -> list[dict]:
        data = self.backup.get('extras')

        if data is None:
            return []

        if not isinstance(data,list):
            raise YException('global-config-misconfigured')

        # verify
        for m in data:
            if not isinstance(m,dict):
                raise YException('global-config-misconfigured')

            if 'src' not in m or \
                'arcname' not in m :
                raise YException('global-config-misconfigured')

        return data
