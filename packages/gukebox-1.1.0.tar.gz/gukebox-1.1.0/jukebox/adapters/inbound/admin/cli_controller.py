import logging

from jukebox.adapters.inbound.admin.cli_display import display_library_line, display_library_table
from jukebox.admin.library_commands import (
    CliAddCommand,
    CliEditCommand,
    CliGetCommand,
    CliListCommand,
    CliRemoveCommand,
    CliSearchCommand,
)
from jukebox.domain.entities import Disc, DiscMetadata, DiscOption
from jukebox.domain.use_cases.library.add_disc import AddDisc
from jukebox.domain.use_cases.library.edit_disc import EditDisc
from jukebox.domain.use_cases.library.get_disc import GetDisc
from jukebox.domain.use_cases.library.list_discs import ListDiscs
from jukebox.domain.use_cases.library.remove_disc import RemoveDisc
from jukebox.domain.use_cases.library.resolve_tag_id import ResolveTagId
from jukebox.domain.use_cases.library.search_discs import SearchDiscs

LOGGER = logging.getLogger("discstore")


class CLIController:
    def __init__(
        self,
        add_disc: AddDisc,
        list_discs: ListDiscs,
        remove_disc: RemoveDisc,
        edit_disc: EditDisc,
        get_disc: GetDisc,
        search_discs: SearchDiscs,
        resolve_tag_id: ResolveTagId,
    ):
        self.add_disc = add_disc
        self.list_discs = list_discs
        self.remove_disc = remove_disc
        self.edit_disc = edit_disc
        self.get_disc = get_disc
        self.search_discs = search_discs
        self.resolve_tag_id = resolve_tag_id

    def run(
        self,
        command: CliAddCommand | CliListCommand | CliRemoveCommand | CliEditCommand | CliGetCommand | CliSearchCommand,
    ) -> None:
        match command:
            case CliAddCommand():
                self.add_disc_flow(command)
            case CliListCommand():
                self.list_discs_flow(command)
            case CliRemoveCommand():
                self.remove_disc_flow(command)
            case CliEditCommand():
                self.edit_disc_flow(command)
            case CliGetCommand():
                self.get_disc_flow(command)
            case CliSearchCommand():
                self.search_discs_flow(command)
            case _:
                LOGGER.error("Command not implemented yet: command='%s'", command)

    def add_disc_flow(self, command: CliAddCommand) -> None:
        tag = self.resolve_tag_id.execute(command.tag, command.use_current_tag)
        option = DiscOption()
        metadata = DiscMetadata(track=command.track, artist=command.artist, album=command.album)

        disc = Disc(uri=command.uri, metadata=metadata, option=option)
        self.add_disc.execute(tag, disc)
        LOGGER.info("✅ Disc successfully added")

    def list_discs_flow(self, command: CliListCommand) -> None:
        discs = self.list_discs.execute()
        if command.mode == "table":
            display_library_table(discs)
            return
        if command.mode == "line":
            display_library_line(discs)
            return
        LOGGER.error("Displaying mode not implemented yet: mode='%s'", command.mode)

    def remove_disc_flow(self, command: CliRemoveCommand) -> None:
        tag = self.resolve_tag_id.execute(command.tag, command.use_current_tag)
        self.remove_disc.execute(tag)
        LOGGER.info("🗑️ Disc successfully removed")

    def edit_disc_flow(self, command: CliEditCommand) -> None:
        metadata_fields = {}
        if command.track is not None:
            metadata_fields["track"] = command.track
        if command.artist is not None:
            metadata_fields["artist"] = command.artist
        if command.album is not None:
            metadata_fields["album"] = command.album

        metadata = DiscMetadata(**metadata_fields) if metadata_fields else None

        self.edit_disc.execute(
            tag_id=self.resolve_tag_id.execute(command.tag, command.use_current_tag),
            uri=command.uri,
            metadata=metadata,
            option=None,
        )
        LOGGER.info("✅ Disc successfully edited")

    def get_disc_flow(self, command: CliGetCommand) -> None:
        try:
            tag = self.resolve_tag_id.execute(command.tag, command.use_current_tag)
            disc = self.get_disc.execute(tag)
            print(f"\n📀 Disc: {tag}")
            print(f"  URI      : {disc.uri}")
            print(f"  Artist   : {disc.metadata.artist or '/'}")
            print(f"  Album    : {disc.metadata.album or '/'}")
            print(f"  Track    : {disc.metadata.track or '/'}")
            print(f"  Playlist : {disc.metadata.playlist or '/'}")
            print(f"  Shuffle  : {disc.option.shuffle}")
        except ValueError as e:
            LOGGER.error(str(e))

    def search_discs_flow(self, command: CliSearchCommand) -> None:
        results = self.search_discs.execute(command.query)
        if not results:
            LOGGER.info("No discs found matching '%s'", command.query)
            return
        LOGGER.info("Found %d disc(s) matching '%s':", len(results), command.query)
        display_library_table(results)
