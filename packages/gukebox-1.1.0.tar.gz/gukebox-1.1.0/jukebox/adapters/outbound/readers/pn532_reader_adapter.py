import logging
import os

from jukebox.shared.errors import MissingOptionalDependencyError

try:
    from pn532 import PN532_SPI
except ModuleNotFoundError as err:
    raise MissingOptionalDependencyError("The `pn532` reader", "pn532", "jukebox ...") from err

from jukebox.domain.ports import ReaderPort
from jukebox.shared.timing import DEFAULT_NFC_READ_TIMEOUT_SECONDS

LOGGER = logging.getLogger("jukebox")


def parse_raw_uid(raw: bytearray):
    return ":".join([hex(i)[2:].lower().rjust(2, "0") for i in raw])


def spi_active():
    return any(dev.startswith("spidev") for dev in os.listdir("/dev"))


class Pn532ReaderAdapter(ReaderPort):
    """Adapter for Pn532 NFC reader implementing ReaderPort."""

    def __init__(
        self,
        read_timeout_seconds: float = DEFAULT_NFC_READ_TIMEOUT_SECONDS,
        spi_reset: int | None = None,
        spi_cs: int | None = None,
        spi_irq: int | None = None,
    ):
        if not spi_active():
            error_message = (
                "The SPI interface is not enabled. Please enable it to use the PN532 NFC reader."
                "You can enable SPI using `sudo raspi-config` then navigate to: Interface Options > SPI > Enable > Yes."
            )
            LOGGER.error(error_message)
            raise RuntimeError("SPI interface not enabled. Use raspi-config to enable it.")

        self.pn532 = PN532_SPI(debug=False, reset=spi_reset, cs=spi_cs, irq=spi_irq)
        self.read_timeout_seconds = read_timeout_seconds
        ic, ver, rev, support = self.pn532.get_firmware_version()
        LOGGER.info("Found PN532 with firmware version: %s.%s", ver, rev)
        self._firmware_version: tuple[int, int] = (ver, rev)
        self.pn532.SAM_configuration()

    @property
    def firmware_version(self) -> tuple[int, int]:
        return self._firmware_version

    def read(self) -> str | None:
        rawuid = self.pn532.read_passive_target(timeout=self.read_timeout_seconds)
        if rawuid is None:
            return None
        return parse_raw_uid(rawuid)
