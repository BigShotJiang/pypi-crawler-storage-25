import logging
import os
import tempfile

from jukebox.domain.repositories import CurrentTagRepository

LOGGER = logging.getLogger("jukebox")


class TextCurrentTagAdapter(CurrentTagRepository):
    """Plain-text sidecar implementation of CurrentTagRepository.

    Writes are atomic via temp-file replace; the current-tag state has a
    single expected writer, so no cross-process lock file is maintained.
    """

    def __init__(self, filepath: str):
        self.filepath = filepath

    def get(self) -> str | None:
        return self._read_current_tag()

    def set(self, tag_id: str) -> None:
        directory = os.path.dirname(self.filepath)
        os.makedirs(directory, exist_ok=True)

        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                dir=directory,
                delete=False,
                prefix="current-tag-",
                suffix=".tmp",
            ) as temp_file:
                temp_path = temp_file.name
                self._write_text(temp_file, tag_id)
                temp_file.flush()
                os.fsync(temp_file.fileno())

            os.replace(temp_path, self.filepath)
            self._fsync_directory()
        finally:
            if temp_path is not None and os.path.exists(temp_path):
                os.unlink(temp_path)

    def clear(self) -> None:
        self._clear_unlocked()

    def _read_current_tag(self) -> str | None:
        try:
            with open(self.filepath, encoding="utf-8") as current_tag_file:
                tag_id = current_tag_file.read().strip()
        except FileNotFoundError:
            return None
        except OSError as err:
            LOGGER.warning("Error reading current tag state: filepath: %s, error: %s", self.filepath, err)
            return None

        if not tag_id:
            return None

        return tag_id

    def _clear_unlocked(self) -> None:
        try:
            os.unlink(self.filepath)
            self._fsync_directory()
        except FileNotFoundError:
            return

    def _write_text(self, temp_file, tag_id: str) -> None:
        temp_file.write(f"{tag_id}\n")

    def _fsync_directory(self) -> None:
        directory_fd = os.open(os.path.dirname(self.filepath), os.O_RDONLY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
