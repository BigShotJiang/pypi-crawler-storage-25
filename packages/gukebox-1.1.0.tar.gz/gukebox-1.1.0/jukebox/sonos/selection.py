from typing import Literal, Protocol

from pydantic import BaseModel, ConfigDict

from jukebox.settings.entities import (
    SelectedSonosGroupSettings,
    SelectedSonosSpeakerSettings,
)

from .discovery import DiscoveredSonosSpeaker
from .service import SonosService


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SonosSelectionMemberAvailability(StrictModel):
    uid: str
    status: Literal["available", "unavailable"]
    speaker: DiscoveredSonosSpeaker | None = None


class SonosSelectionAvailability(StrictModel):
    status: Literal["not_selected", "available", "partial", "unavailable"]
    members: list[SonosSelectionMemberAvailability] = []


class SonosSelectionStatus(StrictModel):
    selected_group: SelectedSonosGroupSettings | None = None
    availability: SonosSelectionAvailability


class SonosSelectionResult(StrictModel):
    coordinator: DiscoveredSonosSpeaker
    members: list[DiscoveredSonosSpeaker]
    selected_group: SelectedSonosGroupSettings
    settings_message: str
    restart_required: bool = False


class SaveSelectedSonosGroupResult(StrictModel):
    message: str = "Settings saved."
    restart_required: bool = False


class SelectedSonosGroupRepository(Protocol):
    def get_selected_group(self) -> SelectedSonosGroupSettings | None: ...

    def save_selected_group(self, selected_group: SelectedSonosGroupSettings) -> SaveSelectedSonosGroupResult: ...


class SaveSonosSelection:
    def __init__(self, selected_group_repository: SelectedSonosGroupRepository, sonos_service: SonosService):
        self.selected_group_repository = selected_group_repository
        self.sonos_service = sonos_service

    def execute(
        self,
        uids: list[str],
        coordinator_uid: str | None = None,
        requested_household_id: str | None = None,
    ) -> SonosSelectionResult:
        available_speakers = self.sonos_service.list_network_speakers()
        validated_group = _validate_selection_request(
            available_speakers=available_speakers,
            requested_uids=uids,
            coordinator_uid=coordinator_uid,
            requested_household_id=requested_household_id,
        )
        speakers_by_uid = {speaker.uid: speaker for speaker in available_speakers}
        selected_group = SelectedSonosGroupSettings(
            household_id=validated_group.household_id,
            coordinator_uid=validated_group.coordinator_uid,
            members=[SelectedSonosSpeakerSettings(uid=uid) for uid in validated_group.selected_uids],
        )
        members = [speakers_by_uid[uid] for uid in validated_group.selected_uids]
        coordinator = speakers_by_uid[validated_group.coordinator_uid]
        settings_result = self.selected_group_repository.save_selected_group(selected_group)
        return SonosSelectionResult(
            coordinator=coordinator,
            members=members,
            selected_group=selected_group,
            settings_message=settings_result.message,
            restart_required=settings_result.restart_required,
        )


class GetSonosSelectionStatus:
    def __init__(self, selected_group_repository: SelectedSonosGroupRepository, sonos_service: SonosService):
        self.selected_group_repository = selected_group_repository
        self.sonos_service = sonos_service

    def execute(self) -> SonosSelectionStatus:
        selected_group = self.selected_group_repository.get_selected_group()
        if selected_group is None:
            return SonosSelectionStatus(
                selected_group=None,
                availability=SonosSelectionAvailability(status="not_selected"),
            )

        inspection = self.sonos_service.inspect_selected_group(selected_group)
        available_speakers = {speaker.uid: speaker for speaker in inspection.resolved_members}
        members = []

        for saved_member in selected_group.members:
            speaker = available_speakers.get(saved_member.uid)
            if speaker is None:
                members.append(
                    SonosSelectionMemberAvailability(
                        uid=saved_member.uid,
                        status="unavailable",
                    )
                )
                continue

            members.append(
                SonosSelectionMemberAvailability(
                    uid=saved_member.uid,
                    status="available",
                    speaker=speaker,
                )
            )

        if inspection.error_message is not None:
            availability = SonosSelectionAvailability(status="unavailable", members=members)
        elif inspection.missing_member_uids:
            availability = SonosSelectionAvailability(status="partial", members=members)
        else:
            availability = SonosSelectionAvailability(status="available", members=members)

        return SonosSelectionStatus(
            selected_group=selected_group,
            availability=availability,
        )


class _ValidatedSonosSelectionRequest(StrictModel):
    selected_uids: list[str]
    coordinator_uid: str
    household_id: str


def _validate_selection_request(
    available_speakers: list[DiscoveredSonosSpeaker],
    requested_uids: list[str],
    coordinator_uid: str | None = None,
    requested_household_id: str | None = None,
) -> _ValidatedSonosSelectionRequest:
    if not requested_uids:
        raise ValueError("`uids` must include at least one UID.")

    if len(set(requested_uids)) != len(requested_uids):
        raise ValueError("`uids` must not contain duplicate UIDs.")

    speakers_by_uid = {speaker.uid: speaker for speaker in available_speakers}
    unknown_uids = [uid for uid in requested_uids if uid not in speakers_by_uid]
    if unknown_uids:
        raise ValueError("Selected Sonos speakers are not currently discoverable: {}".format(", ".join(unknown_uids)))

    resolved_coordinator_uid = requested_uids[0] if coordinator_uid is None else coordinator_uid
    if resolved_coordinator_uid not in requested_uids:
        raise ValueError(f"Selected Sonos coordinator must be one of the selected speakers: {resolved_coordinator_uid}")

    if requested_household_id is not None:
        available_household_ids = {speaker.household_id for speaker in available_speakers}
        if requested_household_id not in available_household_ids:
            raise ValueError(f"No visible Sonos speakers found for household `{requested_household_id}`.")
        if any(speakers_by_uid[uid].household_id != requested_household_id for uid in requested_uids):
            raise ValueError(f"Selected Sonos speakers must belong to household `{requested_household_id}`.")

    household_ids = {speakers_by_uid[uid].household_id for uid in requested_uids}
    if len(household_ids) != 1:
        raise ValueError("Selected Sonos speakers must belong to the same household.")
    resolved_household_id = next(iter(household_ids))

    return _ValidatedSonosSelectionRequest(
        selected_uids=list(requested_uids),
        coordinator_uid=resolved_coordinator_uid,
        household_id=resolved_household_id,
    )
