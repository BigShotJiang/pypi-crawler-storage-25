import sys
import traceback
from typing import Annotated, Never

import typer
from pydantic import ValidationError

from jukebox.admin.library_command_handlers import execute_library_command
from jukebox.admin.library_commands import (
    CliAddCommand,
    CliEditCommand,
    CliGetCommand,
    CliListCommand,
    CliListCommandModes,
    CliRemoveCommand,
    CliSearchCommand,
    InteractiveCliCommand,
)
from jukebox.settings.errors import SettingsError
from jukebox.shared.config_utils import get_package_version
from jukebox.shared.errors import MissingOptionalDependencyError
from jukebox.shared.logger import set_logger
from jukebox.sonos.discovery import DiscoveredSonosSpeaker

from .cli_presentation import (
    build_sonos_household_choice_label,
    build_sonos_speaker_choice_label,
    render_cli_error,
    render_sonos_speakers_output,
)
from .command_handlers import execute_server_command, execute_settings_command, execute_sonos_command
from .commands import (
    ApiCommand,
    SettingsResetCommand,
    SettingsSetCommand,
    SettingsShowCommand,
    SonosListCommand,
    SonosSelectCommand,
    SonosShowCommand,
    UiCommand,
    is_sonos_command,
)
from .di_container import (
    build_admin_api_app,
    build_admin_services,
    build_admin_ui_app,
    build_cli_controller,
    build_interactive_cli_controller,
    build_settings_service,
)
from .pn532_command_handlers import execute_pn532_command
from .pn532_commands import Pn532ProbeCommand, Pn532ProfilesCommand, Pn532SelectCommand, is_pn532_command
from .sonos_households import GroupedSonosHousehold


class AdminCliState:
    def __init__(self, library: str | None, verbose: bool):
        self.library = library
        self.verbose = verbose


def _version_callback(value: bool) -> None:
    if value:
        _exit_success(f"jukebox-admin {get_package_version()}")


def _get_state(ctx: typer.Context) -> AdminCliState:
    state = ctx.obj
    if not isinstance(state, AdminCliState):
        raise RuntimeError("Admin CLI state was not initialized")
    return state


def _run_settings_command(ctx: typer.Context, command: object) -> None:
    state = _get_state(ctx)

    try:
        settings_service = build_settings_service(
            library=state.library,
            command=command,
        )
        execute_settings_command(
            command=command,
            settings_service=settings_service,
        )
    except typer.Exit:
        raise
    except SettingsError as err:
        typer.echo(render_cli_error(err, verbose=state.verbose), err=True)
        raise typer.Exit(code=1)
    except OSError as err:
        typer.echo(str(err), err=True)
        raise typer.Exit(code=1)
    except Exception as err:
        typer.echo(render_cli_error(err, verbose=state.verbose), err=True)
        if state.verbose:
            traceback.print_exception(type(err), err, err.__traceback__)
        raise typer.Exit(code=1)


def _run_command(ctx: typer.Context, command: object) -> None:
    state = _get_state(ctx)

    try:
        services = build_admin_services(
            library=state.library,
            command=command,
        )
        try:
            if is_sonos_command(command):
                execute_sonos_command(
                    command=command,
                    sonos_service=services.sonos,
                    settings_service=services.settings,
                    household_prompt_fn=_prompt_for_sonos_household_selection,
                    speaker_prompt_fn=_prompt_for_sonos_speaker_selection,
                    coordinator_prompt_fn=_prompt_for_sonos_group_coordinator,
                    status_fn=_emit_cli_status,
                )
            elif is_pn532_command(command):
                execute_pn532_command(
                    command=command,
                    settings_service=services.settings,
                    profile_prompt_fn=_prompt_for_pn532_profile,
                    protocol_prompt_fn=_prompt_for_pn532_protocol,
                    pin_prompt_fn=_prompt_for_pn532_pin,
                    stdout_fn=typer.echo,
                )
            else:
                execute_server_command(
                    verbose=state.verbose,
                    command=command,
                    services=services,
                    build_api_app=build_admin_api_app,
                    build_ui_app=build_admin_ui_app,
                    source_command="jukebox-admin",
                )
        except RuntimeError as err:
            if state.verbose:
                raise
            _exit_error(str(err))
    except MissingOptionalDependencyError as err:
        _exit_error(render_cli_error(err, verbose=state.verbose))
    except typer.Exit:
        raise
    except SettingsError as err:
        _exit_error(render_cli_error(err, verbose=state.verbose))
    except ModuleNotFoundError as err:
        _exit_error(str(err))
    except OSError as err:
        _exit_error(str(err))
    except Exception as err:
        typer.echo(render_cli_error(err, verbose=state.verbose), err=True)
        if state.verbose:
            traceback.print_exception(type(err), err, err.__traceback__)
        raise typer.Exit(code=1)


def _run_library_command(ctx: typer.Context, command: object) -> None:
    state = _get_state(ctx)

    try:
        settings_service = build_settings_service(
            library=state.library,
            command=command,
        )
        try:
            execute_library_command(
                verbose=state.verbose,
                command=command,
                settings_service=settings_service,
                build_cli_controller=build_cli_controller,
                build_interactive_cli_controller=build_interactive_cli_controller,
            )
        except (ValueError, RuntimeError) as err:
            _exit_error(str(err))
    except typer.Exit:
        raise
    except SettingsError as err:
        _exit_error(render_cli_error(err, verbose=state.verbose))
    except OSError as err:
        _exit_error(str(err))
    except Exception as err:
        typer.echo(render_cli_error(err, verbose=state.verbose), err=True)
        if state.verbose:
            traceback.print_exception(type(err), err, err.__traceback__)
        raise typer.Exit(code=1)


def _exit_error(message: str) -> Never:
    typer.echo(message, err=True)
    raise typer.Exit(code=1)


def _exit_success(message: str) -> Never:
    typer.echo(message)
    raise typer.Exit()


def _prompt_for_sonos_speaker_selection(speakers: list[DiscoveredSonosSpeaker]) -> list[str] | None:
    import questionary

    try:
        return questionary.checkbox(
            "Select one or more Sonos speakers",
            choices=[
                questionary.Choice(
                    title=build_sonos_speaker_choice_label(speaker),
                    value=speaker.uid,
                )
                for speaker in speakers
            ],
        ).ask()
    except KeyboardInterrupt:
        return None


def _prompt_for_sonos_household_selection(households: list[GroupedSonosHousehold]) -> str | None:
    import questionary

    try:
        typer.echo(render_sonos_speakers_output(households))
        return questionary.select(
            "Select the Sonos household",
            choices=[
                questionary.Choice(
                    title=build_sonos_household_choice_label(household),
                    value=household.household_id,
                )
                for household in households
            ],
        ).ask()
    except KeyboardInterrupt:
        return None


def _prompt_for_pn532_profile(profiles: list[str]) -> str | None:
    import questionary

    try:
        return questionary.select("Select a PN532 board profile", choices=profiles).ask()
    except KeyboardInterrupt:
        return None


def _prompt_for_pn532_protocol(protocols: list[str], default: str) -> str | None:
    import questionary

    try:
        return questionary.select("Select a PN532 protocol", choices=protocols, default=default).ask()

    except KeyboardInterrupt:
        return None


def _prompt_for_pn532_pin(pin_name: str, default: int | None) -> str | None:
    import questionary

    default_str = str(default) if default is not None else ""
    try:
        return questionary.text(
            f"SPI {pin_name} pin (GPIO number, leave blank to clear):",
            default=default_str,
        ).ask()
    except KeyboardInterrupt:
        return None


def _prompt_for_sonos_group_coordinator(speakers: list[DiscoveredSonosSpeaker]) -> str | None:
    import questionary

    try:
        return questionary.select(
            "Select the Sonos coordinator",
            choices=[
                questionary.Choice(
                    title=build_sonos_speaker_choice_label(speaker),
                    value=speaker.uid,
                )
                for speaker in speakers
            ],
        ).ask()
    except KeyboardInterrupt:
        return None


def _emit_cli_status(message: str) -> None:
    if not sys.stderr.isatty():
        return
    typer.echo(message, err=True)


app = typer.Typer(help="Admin CLI for jukebox")
settings_app = typer.Typer(help="Inspect and manage application settings")
library_app = typer.Typer(help="Manage the library")
sonos_app = typer.Typer(help="Inspect Sonos speakers and manage the saved Sonos selection")
pn532_app = typer.Typer(help="Inspect and debug the PN532 NFC reader")
app.add_typer(settings_app, name="settings")
app.add_typer(library_app, name="library")
app.add_typer(sonos_app, name="sonos")
app.add_typer(pn532_app, name="pn532")


@app.callback()
def main_callback(
    ctx: typer.Context,
    library: Annotated[
        str | None,
        typer.Option("--library", "-l", help="override the library JSON path for this process"),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="enable verbose logging"),
    ] = False,
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            callback=_version_callback,
            is_eager=True,
            help="show current installed version",
        ),
    ] = False,
) -> None:
    del version
    set_logger("jukebox-admin", verbose)
    ctx.obj = AdminCliState(library=library, verbose=verbose)


@settings_app.command("show")
def settings_show(
    ctx: typer.Context,
    effective: Annotated[
        bool,
        typer.Option("--effective", help="show merged effective settings with provenance"),
    ] = False,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="print the raw machine-readable payload"),
    ] = False,
) -> None:
    _run_settings_command(ctx, SettingsShowCommand(type="settings_show", effective=effective, json_output=json_output))


@settings_app.command("set")
def settings_set(
    ctx: typer.Context,
    dotted_path: Annotated[str, typer.Argument(help="canonical dotted path to update")],
    value: Annotated[str, typer.Argument(help="value to persist for the given path")],
    json_output: Annotated[
        bool,
        typer.Option("--json", help="print the raw machine-readable payload"),
    ] = False,
) -> None:
    _run_settings_command(
        ctx,
        SettingsSetCommand(
            type="settings_set",
            dotted_path=dotted_path,
            value=value,
            json_output=json_output,
        ),
    )


@settings_app.command("reset")
def settings_reset(
    ctx: typer.Context,
    dotted_path: Annotated[str, typer.Argument(help="canonical dotted path to reset")],
    json_output: Annotated[
        bool,
        typer.Option("--json", help="print the raw machine-readable payload"),
    ] = False,
) -> None:
    _run_settings_command(
        ctx,
        SettingsResetCommand(
            type="settings_reset",
            dotted_path=dotted_path,
            json_output=json_output,
        ),
    )


@app.command("api")
def api(
    ctx: typer.Context,
    port: Annotated[
        int | None,
        typer.Option("--port", help="override the configured API port"),
    ] = None,
) -> None:
    _run_command(ctx, ApiCommand(type="api", port=port))


@app.command("ui")
def ui(
    ctx: typer.Context,
    port: Annotated[
        int | None,
        typer.Option("--port", help="override the configured UI port"),
    ] = None,
) -> None:
    _run_command(ctx, UiCommand(type="ui", port=port))


@sonos_app.command("list")
def sonos_list(ctx: typer.Context) -> None:
    _run_command(ctx, SonosListCommand(type="sonos_list"))


@sonos_app.command("select")
def sonos_select(
    ctx: typer.Context,
    uids: Annotated[
        list[str] | None,
        typer.Option(
            "--uids",
            help=(
                "comma-separated Sonos speaker UIDs to persist as the selected group; may be repeated; "
                "first UID is used as coordinator if --coordinator is omitted"
            ),
        ),
    ] = None,
    coordinator: Annotated[
        str | None,
        typer.Option("--coordinator", help="coordinator UID for the selected Sonos group"),
    ] = None,
    household: Annotated[
        str | None,
        typer.Option("--household", help="household ID to use for interactive Sonos speaker selection"),
    ] = None,
) -> None:
    parsed_uids = (
        None if uids is None else [uid.strip() for raw_uids in uids for uid in raw_uids.split(",") if uid.strip()]
    )
    try:
        command = SonosSelectCommand(
            type="sonos_select",
            uids=parsed_uids,
            coordinator=coordinator,
            household=household,
        )
    except ValidationError as err:
        _exit_error(str(err))

    _run_command(ctx, command)


@sonos_app.command("show")
def sonos_show(ctx: typer.Context) -> None:
    _run_command(ctx, SonosShowCommand(type="sonos_show"))


@pn532_app.command("profiles")
def pn532_profiles(ctx: typer.Context) -> None:
    """List available board profiles and their default GPIO pins."""
    _run_command(ctx, Pn532ProfilesCommand(type="pn532_profiles"))


@pn532_app.command("select")
def pn532_select(
    ctx: typer.Context,
    profile: Annotated[
        str | None,
        typer.Option(
            "--profile",
            help="board profile to persist (waveshare_hat, hiletgo_v3, custom)",
        ),
    ] = None,
) -> None:
    """Select a board profile and persist it to settings."""
    _run_command(ctx, Pn532SelectCommand(type="pn532_select", profile=profile))


@pn532_app.command("probe")
def pn532_probe(ctx: typer.Context) -> None:
    """Verify the PN532 is connected, show firmware version and attempt one tag read."""
    _run_command(ctx, Pn532ProbeCommand(type="pn532_probe"))


@library_app.command("add")
def library_add(
    ctx: typer.Context,
    uri: Annotated[str, typer.Option("--uri", help="Path or URI of the media file")],
    tag: Annotated[str | None, typer.Argument(help="Tag to be associated with the disc")] = None,
    track: Annotated[str | None, typer.Option("--track", help="Name of the track")] = None,
    artist: Annotated[str | None, typer.Option("--artist", help="Name of the artist or band")] = None,
    album: Annotated[str | None, typer.Option("--album", help="Name of the album")] = None,
    use_current_tag: Annotated[
        bool,
        typer.Option("--from-current", help="Resolve the tag ID from shared current-tag.txt state"),
    ] = False,
) -> None:
    try:
        command = CliAddCommand(
            type="add",
            tag=tag,
            use_current_tag=use_current_tag,
            uri=uri,
            track=track,
            artist=artist,
            album=album,
        )
    except ValidationError as err:
        _exit_error(str(err))

    _run_library_command(ctx, command)


@library_app.command("list")
def library_list(
    ctx: typer.Context,
    mode: Annotated[CliListCommandModes, typer.Option("--mode", help="Displaying mode")] = CliListCommandModes.table,
) -> None:
    _run_library_command(ctx, CliListCommand(type="list", mode=mode))


@library_app.command("remove")
def library_remove(
    ctx: typer.Context,
    tag: Annotated[str | None, typer.Argument(help="Tag to remove")] = None,
    use_current_tag: Annotated[
        bool,
        typer.Option("--from-current", help="Resolve the tag ID from shared current-tag.txt state"),
    ] = False,
) -> None:
    try:
        command = CliRemoveCommand(type="remove", tag=tag, use_current_tag=use_current_tag)
    except ValidationError as err:
        _exit_error(str(err))

    _run_library_command(ctx, command)


@library_app.command("edit")
def library_edit(
    ctx: typer.Context,
    tag: Annotated[str | None, typer.Argument(help="Tag to be edited")] = None,
    uri: Annotated[str | None, typer.Option("--uri", help="Path or URI of the media file")] = None,
    track: Annotated[str | None, typer.Option("--track", help="Name of the track")] = None,
    artist: Annotated[str | None, typer.Option("--artist", help="Name of the artist or band")] = None,
    album: Annotated[str | None, typer.Option("--album", help="Name of the album")] = None,
    use_current_tag: Annotated[
        bool,
        typer.Option("--from-current", help="Resolve the tag ID from shared current-tag.txt state"),
    ] = False,
) -> None:
    try:
        command = CliEditCommand(
            type="edit",
            tag=tag,
            use_current_tag=use_current_tag,
            uri=uri,
            track=track,
            artist=artist,
            album=album,
        )
    except ValidationError as err:
        _exit_error(str(err))

    _run_library_command(ctx, command)


@library_app.command("get")
def library_get(
    ctx: typer.Context,
    tag: Annotated[str | None, typer.Argument(help="Tag to retrieve")] = None,
    use_current_tag: Annotated[
        bool,
        typer.Option("--from-current", help="Resolve the tag ID from shared current-tag.txt state"),
    ] = False,
) -> None:
    try:
        command = CliGetCommand(type="get", tag=tag, use_current_tag=use_current_tag)
    except ValidationError as err:
        _exit_error(str(err))

    _run_library_command(ctx, command)


@library_app.command("search")
def library_search(
    ctx: typer.Context,
    query: Annotated[str, typer.Argument(help="Search query (matches artist, album, track, playlist, or tag)")],
) -> None:
    _run_library_command(ctx, CliSearchCommand(type="search", query=query))


@library_app.command("interactive")
def library_interactive(ctx: typer.Context) -> None:
    _run_library_command(ctx, InteractiveCliCommand(type="interactive"))


def main(args: list[str] | None = None) -> None:
    app(args=args, prog_name="jukebox-admin")
