import logging
from base64 import b64decode, b64encode
from dataclasses import dataclass, field
from enum import StrEnum
from types import TracebackType
from typing import Self, cast
from uuid import UUID
from xml.etree.ElementTree import Element, SubElement

from ..wsman import NAMESPACES, OptionSet, SelectorSet, WSMan
from .encoding import Encoding

log = logging.getLogger('wsmanio')


class CommandState(StrEnum):
    DONE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/CommandState/Done'
    PENDING = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/CommandState/Pending'
    RUNNING = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/CommandState/Running'


class Stream(StrEnum):
    STDIN = 'stdin'
    STDOUT = 'stdout'
    STDERR = 'stderr'
    PR = 'pr'


@dataclass(slots=True)
class WinRS:
    wsman: WSMan
    encoding: Encoding | None = None
    shell_id: UUID | None = None
    resource_uri: str = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'
    opened: bool = field(init=False, default=False)
    environment: dict[str, str] | None = None
    idle_time_out: int | None = None
    lifetime: int | None = None
    name: str | None = None
    no_profile: bool = True
    resourse_uri: str = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/cmd'
    input_streams: list[Stream] = field(default_factory=lambda: [Stream.STDIN])
    output_streams: list[Stream] = field(default_factory=lambda: [Stream.STDOUT, Stream.STDERR])
    working_directory: str | None = None
    selector_set: SelectorSet | None = None

    id: str | None = None
    owner: str | None = None
    client_ip: str | None = None
    idle_time_out: str | None = None
    shell_run_time: str | None = None
    shell_inactivity: str | None = None

    def __post_init__(self) -> None: ...

    def _parse_shell_create(
        self,
        response: Element,
    ) -> None:
        fields = {
            'rsp:ShellId': 'id',
            'rsp:ResourceUri': 'resource_uri',
            'rsp:Owner': 'owner',
            'rsp:ClientIP': 'client_ip',
            'rsp:IdleTimeOut': 'idle_time_out',
            'rsp:OutputStreams': 'output_streams',
            'rsp:ShellRunTime': 'shell_run_time',
            'rsp:ShellInactivity': 'shell_inactivity',
        }

        for xml_element, shell_attr in fields.items():
            element = response.find(f'rsp:Shell/{xml_element}', namespaces=NAMESPACES)
            if element is not None:
                setattr(self, shell_attr, element.text)

        selector_set = response.find(
            'wst:ResourceCreated/wsa:ReferenceParameters/wsman:SelectorSet',
            namespaces=NAMESPACES,
        )
        if selector_set is not None:
            self.selector_set = SelectorSet()
            for selector in selector_set:
                self.selector_set.add_option(selector.attrib['Name'], selector.text or '')

    async def __aenter__(self) -> Self:
        await self.open()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        await self.close()

    async def open(self, base_options: OptionSet | None = None, open_content: Element | None = None) -> Element | None:
        if self.opened:
            return None

        rsp = NAMESPACES['rsp']

        shell = Element(f'{{{rsp}}}Shell')
        if self.shell_id is not None:
            shell.set('ShellId', str(self.shell_id).upper())

        SubElement(shell, f'{{{rsp}}}InputStreams').text = ' '.join(self.input_streams)
        SubElement(shell, f'{{{rsp}}}OutputStreams').text = ' '.join(self.output_streams)
        if self.environment is not None:
            env = SubElement(shell, f'{{{rsp}}}Environment')
            for key, value in self.environment.items():
                SubElement(env, f'{{{rsp}}}Variable', Name=str(key)).text = str(value)

        if self.idle_time_out is not None:
            SubElement(shell, f'{{{rsp}}}IdleTimeOut').text = f'PT{self.idle_time_out}S'

        if self.lifetime is not None:
            SubElement(shell, f'{{{rsp}}}Lifetime').text = f'PT{self.lifetime}S'

        if self.name is not None:
            SubElement(shell, f'{{{rsp}}}Name').text = self.name

        if self.working_directory is not None:
            SubElement(shell, f'{{{rsp}}}WorkingDirectory').text = self.working_directory

        if open_content is not None:
            shell.append(open_content)

        # Inherit the base options if it was passed in, otherwise use an empty option set.
        options = OptionSet() if base_options is None else base_options
        if self.no_profile is not None:
            options.add_option('WINRS_NOPROFILE', str(self.no_profile))
        if self.encoding is not None:
            options.add_option('WINRS_CODEPAGE', str(self.encoding.codepage))

        response = await self.wsman.create(
            self.resource_uri,
            shell,
            option_set=options if len(options.values) else None,
        )
        self._parse_shell_create(response)
        self.opened = True
        return response

    async def close(self) -> None:
        if not self.opened:
            return
        await self.wsman.delete(self.resource_uri, selector_set=self.selector_set)
        self.id = None
        self.opened = False

    async def command(
        self,
        executable: str,
        arguments: list[str] | None = None,
        no_shell: bool = False,
        command_id: str | None = None,
    ) -> Element:
        rsp = NAMESPACES['rsp']

        options = OptionSet()
        options.add_option('WINRS_SKIP_CMD_SHELL', str(no_shell))

        arguments = arguments if arguments is not None else []

        cmd = Element(f'{{{rsp}}}CommandLine')
        if command_id is not None:
            cmd.set('CommandId', command_id)

        SubElement(cmd, f'{{{rsp}}}Command').text = executable
        for argument in arguments:
            SubElement(cmd, f'{{{rsp}}}Arguments').text = argument

        return await self.wsman.command(self.resource_uri, cmd, option_set=options, selector_set=self.selector_set)

    async def signal(self, code: str, command_id: str) -> Element:
        rsp = NAMESPACES['rsp']

        signal = Element(f'{{{rsp}}}Signal', attrib={'CommandId': command_id})
        SubElement(signal, f'{{{rsp}}}Code').text = code
        return await self.wsman.signal(self.resource_uri, signal, selector_set=self.selector_set)

    async def receive(
        self,
        stream: str = 'stdout stderr',
        command_id: str | None = None,
        timeout: int | None = None,
    ) -> tuple[CommandState, int, bytes, bytes]:
        rsp = NAMESPACES['rsp']

        receive = Element(f'{{{rsp}}}Receive')
        stream_xml = SubElement(receive, f'{{{rsp}}}DesiredStream')
        stream_xml.text = stream
        if command_id is not None:
            stream_xml.set('CommandId', command_id)

        options = OptionSet()
        options.add_option('WSMAN_CMDSHELL_OPTION_KEEPALIVE', str(True))

        response = await self.wsman.receive(
            self.resource_uri,
            receive,
            option_set=options,
            selector_set=self.selector_set,
            timeout=timeout,
        )

        command_state_et = response.find('rsp:ReceiveResponse/rsp:CommandState', namespaces=NAMESPACES)
        command_state = CommandState.PENDING
        if command_state_et is not None:
            command_state = command_state_et.attrib['State']

        return_code = -1
        if command_state == CommandState.DONE:
            return_code_et = response.find('rsp:ReceiveResponse/rsp:CommandState/rsp:ExitCode', namespaces=NAMESPACES)
            if return_code_et is None:
                log.exception('Unable to find exit code')
                raise
            return_code = int(return_code_et.text or -1)

        stdout, stderr = [], []
        streams = response.findall('rsp:ReceiveResponse/rsp:Stream', namespaces=NAMESPACES)
        for s in streams:
            if s.text is None:
                continue

            if s.attrib['Name'] == 'stdout':
                stdout.append(b64decode(s.text.encode('utf-8')))
            elif s.attrib['Name'] == 'stderr':
                stderr.append(b64decode(s.text.encode('utf-8')))

        return cast('CommandState', command_state), return_code, b''.join(stdout), b''.join(stderr)

    async def send(
        self,
        stream: str,
        data: bytes,
        command_id: str | None = None,
        end: bool | None = None,
    ) -> Element:
        rsp = NAMESPACES['rsp']

        send = Element(f'{{{rsp}}}Send')
        resp = SubElement(send, f'{{{rsp}}}Stream', Name=stream)
        if end is not None:
            resp.attrib['End'] = str(end)
        if command_id is not None:
            resp.attrib['CommandId'] = command_id

        resp.text = b64encode(data).decode('utf-8')
        return await self.wsman.send(self.resource_uri, send, selector_set=self.selector_set)
