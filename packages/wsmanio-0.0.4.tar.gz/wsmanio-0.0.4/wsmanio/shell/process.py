from dataclasses import dataclass, field
from enum import StrEnum

from ..exceptions import WSManFaultError
from ..wsman import NAMESPACES
from .winrs import CommandState, WinRS


class SignalCode(StrEnum):
    CTRL_C = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/ctrl_c'
    CTRL_BREAK = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/ctrl_break'
    TERMINATE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/signal/Terminate'
    PS_CTRL_C = 'powershell/signal/ctrl_c'


@dataclass(slots=True)
class Process:
    shell: WinRS
    executable: str
    arguments: list[str] = field(default_factory=list)
    id: str | None = None
    no_shell: bool = False
    state: CommandState = CommandState.PENDING
    rc: int | None = None
    stdout: bytes = b''
    stderr: bytes = b''

    async def begin_invoke(self) -> None:
        response = await self.shell.command(self.executable, self.arguments, no_shell=self.no_shell)
        command_id = response.find('rsp:CommandResponse/rsp:CommandId', namespaces=NAMESPACES)
        self.id = command_id.text if command_id is not None else None

    async def end_invoke(self) -> None:
        while not self.state == CommandState.DONE:
            await self.poll_invoke()

    async def invoke(self) -> None:
        await self.begin_invoke()
        await self.end_invoke()

    async def poll_invoke(self, timeout: int | None = None) -> None:
        try:
            self.state, self.rc, stdout, stderr = await self.shell.receive(
                stream='stdout stderr',
                command_id=self.id,
                timeout=timeout,
            )
        except WSManFaultError as exc:
            if exc.code != 2150858793:
                raise

        self.stdout += stdout
        self.stderr += stderr

    async def send(self, data: bytes, end: bool = True) -> None:
        await self.shell.send(stream='stdin', data=data, end=end)

    async def signal(self, code: SignalCode) -> None:
        await self.shell.signal(code=code, command_id=self.id or '')
