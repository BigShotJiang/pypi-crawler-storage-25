import logging
from dataclasses import dataclass, field

from pyreqwest.client import Client, ClientBuilder
from pyreqwest.exceptions import StatusError

from ..exceptions import AuthenticationError, WinRMTransportError

logger = logging.getLogger('wsmanio')


@dataclass(slots=True, frozen=True)
class HTTPTransport:
    server_url: str
    username: str
    password: str
    client: Client = field(init=False)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            'client',
            ClientBuilder()
            .base_url(self.server_url + '/' if not self.server_url.endswith('/') else self.server_url)
            .default_cookie_store(enable=True)
            .default_headers(
                {
                    'Content-Type': 'application/soap+xml;charset=UTF-8',
                },
            )
            .danger_accept_invalid_certs(enable=True)
            .build(),
        )

    async def send(self, body: bytes) -> str:
        logger.debug("Sending request to '%s' with body '%s'", self.server_url, body)
        request = self.client.post(self.server_url).basic_auth(self.username, self.password).body_bytes(body).build()
        response = await request.send()
        result = await response.text()
        logger.debug("Received response from '%s': status=%s, body=%s", self.server_url, response.status, result)
        try:
            response.error_for_status()
        except StatusError as err:
            if response.status == 401:
                logger.exception('Authentication failed for user %s (status=%s)', self.username, response.status)
                raise AuthenticationError from err
            raise WinRMTransportError(protocol='http', code=response.status, response_text=result) from err
        return result

    async def close(self) -> None:
        await self.client.close()
