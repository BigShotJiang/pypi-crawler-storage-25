from enum import StrEnum, unique


@unique
class WSManAction(StrEnum):
    # WS-Management URIs
    GET = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Get'
    GET_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/GetResponse'
    PUT = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Put'
    PUT_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/PutResponse'
    CREATE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Create'
    CREATE_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/CreateResponse'
    DELETE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/Delete'
    DELETE_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/transfer/DeleteResponse'
    ENUMERATE = 'http://schemas.xmlsoap.org/ws/2004/09/enumeration/Enumerate'
    ENUMERATE_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/enumeration/EnumerateResponse'
    PULL = 'http://schemas.xmlsoap.org/ws/2004/09/enumeration/Pull'
    PULL_RESPONSE = 'http://schemas.xmlsoap.org/ws/2004/09/enumeration/PullResponse'

    # MS-WSMV URIs
    COMMAND = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Command'
    COMMAND_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/CommandResponse'
    CONNECT = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Connect'
    CONNECT_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/ConnectResponse'
    DISCONNECT = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Disconnect'
    DISCONNECT_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/DisconnectResponse'
    RECEIVE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Receive'
    RECEIVE_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/ReceiveResponse'
    RECONNECT = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Reconnect'
    RECONNECT_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/ReconnectResponse'
    SEND = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Send'
    SEND_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/SendResponse'
    SIGNAL = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/Signal'
    SIGNAL_RESPONSE = 'http://schemas.microsoft.com/wbem/wsman/1/windows/shell/SignalResponse'
