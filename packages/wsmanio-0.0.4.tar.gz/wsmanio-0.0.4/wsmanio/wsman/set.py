from dataclasses import dataclass, field
from xml.etree.ElementTree import Element, SubElement

from .ns import NAMESPACES


@dataclass(slots=True, frozen=True)
class WSManSet:
    element_name: str
    child_element_name: str
    must_understand: bool
    values: list = field(default_factory=list)

    def add_option(self, name: str, value: str, attributes: dict | None = None) -> None:
        attributes = attributes if attributes is not None else {}
        self.values.append((name, value, attributes))

    def pack(self) -> Element:
        s = NAMESPACES['s']
        wsman = NAMESPACES['wsman']
        element = Element(f'{{{wsman}}}{self.element_name}')
        if self.must_understand:
            element.set(f'{{{s}}}mustUnderstand', 'true')

        for key, value, attributes in self.values:
            SubElement(element, f'{{{wsman}}}{self.child_element_name}', Name=key, attrib=attributes).text = str(value)

        return element


class OptionSet(WSManSet):
    def __init__(self) -> None:
        super().__init__('OptionSet', 'Option', must_understand=True)


class SelectorSet(WSManSet):
    def __init__(self) -> None:
        super().__init__('SelectorSet', 'Selector', must_understand=False)
