from dataclasses import dataclass


class WinRMError(Exception):
    pass


class AuthenticationError(WinRMError):
    pass


@dataclass(slots=True, frozen=True)
class WinRMTransportError(WinRMError):
    protocol: str
    code: int
    response_text: str

    @property
    def message(self) -> str:
        return (
            f'Bad {self.protocol.upper()} response returned from the server. '
            f"Code: {self.code}, Content: '{self.response_text}'"
        )

    def __str__(self):
        return self.message


@dataclass(slots=True, frozen=True)
class WSManFaultError(WinRMError):
    code: int | str
    machine: str | None
    reason: str | None
    provider: str | None
    provider_path: str | None
    provider_fault: str | None

    @property
    def message(self):
        errors = []
        if self.code:
            errors.append(f'Code: {self.code}')

        if self.machine:
            errors.append(f'Machine: {self.machine}')

        if self.reason:
            errors.append(f'Reason: {self.reason}')

        if self.provider:
            errors.append(f'Provider: {self.provider}')

        if self.provider_path:
            errors.append(f'Provider Path: {self.provider_path}')

        if self.provider_fault:
            errors.append(f'Provider Fault: {self.provider_fault}')

        if not errors:
            errors.append('No details returned by the server')

        return f'Received a WSManFault message. ({", ".join(errors)})'

    def __str__(self) -> str:
        return self.message
