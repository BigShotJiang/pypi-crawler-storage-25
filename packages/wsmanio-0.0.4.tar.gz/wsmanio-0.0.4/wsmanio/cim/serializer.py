from abc import ABC, abstractmethod
from typing import Any
from xml.etree.ElementTree import Element, SubElement, tostring


class XmlSerializer(ABC):
    @abstractmethod
    def serialize(self, value: Any, parent: Element, tag: str, namespace: str) -> None:
        pass


class EprSerializer(XmlSerializer):
    def serialize(self, value: Any, parent: Element, tag: str, namespace: str) -> None:
        for child in value.to_epr():
            parent.append(child)


class PrimitiveSerializer(XmlSerializer):
    """Сериализация примитивных типов"""

    def serialize(self, value: Any, parent: Element, tag: str, namespace: str) -> None:
        field = SubElement(parent, f'{{{namespace}}}{tag}')

        if value is None:
            field.set('{http://www.w3.org/2001/XMLSchema-instance}nil', 'true')
        else:
            field.text = str(value)


class InstanceDataSerializer(XmlSerializer):
    """Сериализация CimInstanceData"""

    def serialize(self, value: Any, parent: Element, tag: str, namespace: str) -> None:
        field = SubElement(parent, f'{{{namespace}}}{tag}')
        field.text = tostring(value.to_xml(), encoding='unicode', method='xml')
