import asyncio
import logging
from dataclasses import dataclass
from enum import IntEnum
from typing import Any, TYPE_CHECKING
from xml.etree.ElementTree import Element

from .exceptions import CimJobError
from .objects import CimReference

if TYPE_CHECKING:
    from .resolver import CimReader

logger = logging.getLogger('wsmanio')


class JobStatuses(IntEnum):
    NEW = 2
    STARTING = 3
    RUNNING = 4
    SUSPENDED = 5
    SHUTTING_DOWN = 6
    COMPLETED = 7
    TERMINATED = 8
    KILLED = 9
    EXCEPTION = 10
    SERVICE = 11


@dataclass(slots=True)
class CimMethodResult:
    return_value: int
    output: dict[str, Any]
    raw_xml: Element
    job: 'CimReference | None' = None
    job_instance: Any = None

    @property
    def success(self) -> bool:
        return self.return_value == 0

    @property
    def is_async(self) -> bool:
        return self.job is not None and self.return_value == 4096

    @property
    def job_state(self) -> int | None:
        if self.job_instance:
            state = self.job_instance.properties.get('JobState')
            return int(state) if state is not None else None
        return None

    @property
    def job_error_description(self) -> str | None:
        """Описание ошибки Job (если есть)"""
        if self.job_instance:
            return self.job_instance.properties.get('ErrorDescription')
        return None


class CimJobManager:
    __slots__ = ('resolver',)

    def __init__(self, resolver: 'CimReader'):
        self.resolver = resolver

    async def poll(self, job: CimReference, interval: float, timeout: float) -> Any:
        start = asyncio.get_event_loop().time()
        while True:
            if asyncio.get_event_loop().time() - start > timeout:
                raise TimeoutError()

            instance = await self.resolver.get(job)

            state, error_code, error_description = (
                int(instance.JobState),
                int(instance.ErrorCode),
                instance.ErrorDescription,
            )
            logger.info('Job %s: state=%s percent=%s', instance.Name, state, instance.PercentComplete)

            if state == JobStatuses.COMPLETED:
                return instance

            if state in (JobStatuses.TERMINATED, JobStatuses.KILLED, JobStatuses.EXCEPTION):
                logger.exception(
                    'Job failed: State=%s, ErrorCode=%s, ErrorDescription=%s',
                    state,
                    error_code,
                    error_description,
                )
                raise CimJobError(state=state, code=error_code, description=error_description)

            await asyncio.sleep(interval)
