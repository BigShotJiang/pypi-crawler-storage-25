# from abc import ABC, abstractmethod
# from typing import Any, ClassVar

# from .types import CimType


# class CimValueConverter(ABC):
#     @abstractmethod
#     def can_handle(self, cim_type) -> bool: ...

#     @abstractmethod
#     def convert(self, value: str) -> Any: ...


# class BooleanConverter(CimValueConverter):
#     def can_handle(self, cim_type: CimType) -> bool:
#         return cim_type == CimType.BOOLEAN

#     def convert(self, value: str) -> bool:
#         return value.lower() == 'true'


# class IntegerConverter(CimValueConverter):
#     def can_handle(self, cim_type) -> bool:
#         return cim_type in {
#             CimType.UINT8,
#             CimType.UINT16,
#             CimType.UINT32,
#             CimType.UINT64,
#             CimType.SINT8,
#             CimType.SINT16,
#             CimType.SINT32,
#             CimType.SINT64,
#         }

#     def convert(self, value: str) -> int:
#         return int(value)


# class FloatConverter(CimValueConverter):
#     def can_handle(self, cim_type: CimType) -> bool:
#         return cim_type in {CimType.REAL32, CimType.REAL64}

#     def convert(self, value: str) -> float:
#         return float(value)


# class TypeMapper:
#     converters: ClassVar[tuple[CimValueConverter, ...]] = (BooleanConverter(), IntegerConverter(), FloatConverter())

#     def convert(self, value: str, cim_type: CimType) -> Any:
#         for converter in self.converters:
#             if converter.can_handle(cim_type):
#                 return converter.convert(value)
#         return value
