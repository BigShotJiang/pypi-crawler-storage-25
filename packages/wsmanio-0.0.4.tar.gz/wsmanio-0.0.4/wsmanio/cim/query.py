from typing import Any
from xml.etree.ElementTree import Element, SubElement

from ..wsman import NAMESPACES, WSMan
from .parser import CimParser


class CimQueryResult:
    def __init__(self, client: WSMan, resource_uri: str, context: str, parser: CimParser) -> None:
        self.client = client
        self.resource_uri = resource_uri
        self.context = context
        self.parser = parser

    async def __aiter__(self):
        wsen = NAMESPACES['wsen']
        context = self.context

        while True:
            resource = Element(f'{{{wsen}}}Pull')
            SubElement(resource, f'{{{wsen}}}EnumerationContext').text = context
            SubElement(resource, f'{{{wsen}}}MaxElements').text = '10'
            body = await self.client.pull(
                resource_uri=self.resource_uri,
                resource=resource,
            )

            for item in body.findall('wsen:PullResponse/wsen:Items/*', namespaces=NAMESPACES):
                yield self.parser.parse_instance(item)

            end_of_sequence = body.find('wsen:PullResponse/wsen:EndOfSequence', namespaces=NAMESPACES)
            if end_of_sequence is not None:
                break

            context = body.find('wsen:PullResponse/wsen:EnumerationContext', namespaces=NAMESPACES)
            if context is None:
                raise RuntimeError
            context = context.text

    async def all(self) -> list[Any]:
        return [obj async for obj in self]
