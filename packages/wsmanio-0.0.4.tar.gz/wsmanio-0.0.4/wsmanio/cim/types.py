import logging
from enum import StrEnum

logger = logging.getLogger('wsmanio')


class CimType(StrEnum):
    STRING = 'string'
    BOOLEAN = 'boolean'
    UINT8 = 'uint8'
    UINT16 = 'uint16'
    UINT32 = 'uint32'
    UINT64 = 'uint64'
    SINT8 = 'sint8'
    SINT16 = 'sint16'
    SINT32 = 'sint32'
    SINT64 = 'sint64'
    REAL32 = 'real32'
    REAL64 = 'real64'
    DATETIME = 'datetime'
    REFERENCE = 'reference'
    INTERVAL = 'interval'
