from typing import Self

from ..wsman import HTTPTransport, WSMan
from .dsl import CimNamespace
from .resolver import CimResolver


class CimClient:
    def __init__(self, endpoint: str, username: str, password: str):
        self.endpoint = endpoint
        self.username = username
        self.password = password
        self.resolver = CimResolver(
            client=WSMan(
                transport=HTTPTransport(server_url=self.endpoint, username=self.username, password=self.password)
            )
        )

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.resolver.__aexit__(exc_type, exc_val, exc_tb)

    @property
    def cimv2(self) -> CimNamespace:
        return CimNamespace(resolver=self.resolver, namespace='root/cimv2')

    @property
    def virtualization(self) -> CimNamespace:
        return CimNamespace(resolver=self.resolver, namespace='root/virtualization/v2')

    def namespace(self, namespace: str) -> CimNamespace:
        return CimNamespace(resolver=self.resolver, namespace=namespace)
