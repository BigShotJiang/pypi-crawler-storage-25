from typing import Any
from xml.etree.ElementTree import Element, SubElement, tostring

from .objects import CimReference
from .query import CimQueryResult
from .resolver import CimResolver


class CimNamespace:
    def __init__(self, resolver: CimResolver, namespace: str) -> None:
        self.resolver = resolver
        self.namespace = namespace

    async def query(self, query: str) -> CimQueryResult:
        resource_uri = f'http://schemas.microsoft.com/wbem/wsman/1/wmi/{self.namespace}/*'
        return await self.resolver.query(query, resource_uri=resource_uri)

    def __getattr__(self, class_name: str) -> 'CimClass':
        return CimClass(resolver=self.resolver, namespace=self.namespace, class_name=class_name)


class CimClass:
    def __init__(self, resolver: CimResolver, namespace: str, class_name: str) -> None:
        self.resolver = resolver
        self.namespace = namespace
        self.class_name = class_name

    def __call__(self, **selectors) -> 'CimInstanceBuilder':
        return CimInstanceBuilder(
            resolver=self.resolver, namespace=self.namespace, class_name=self.class_name, selectors=selectors
        )

    def __getattr__(self, method_name: str) -> 'CimMethod':
        return CimMethod(
            resolver=self.resolver,
            namespace=self.namespace,
            class_name=self.class_name,
            method_name=method_name,
            selectors={},
        )

    @property
    def resource_uri(self) -> str:
        return f'http://schemas.microsoft.com/wbem/wsman/1/wmi/{self.namespace}/{self.class_name}'


class CimInstanceBuilder:
    def __init__(self, resolver: CimResolver, namespace: str, class_name: str, selectors: dict[str, str]) -> None:
        self.resolver = resolver
        self.namespace = namespace
        self.class_name = class_name
        self.selectors = selectors

    def __getattr__(self, method_name) -> 'CimMethod':
        return CimMethod(
            resolver=self.resolver,
            namespace=self.namespace,
            class_name=self.class_name,
            method_name=method_name,
            selectors=self.selectors,
        )

    async def get(self) -> Any:
        return await self.resolver.get(CimReference(resource_uri=self.resource_uri, selectors=self.selectors))

    def ref(self) -> CimReference:
        return CimReference(
            resource_uri=self.resource_uri,
            selectors=self.selectors,
        )

    @property
    def resource_uri(self) -> str:
        return f'http://schemas.microsoft.com/wbem/wsman/1/wmi/{self.namespace}/{self.class_name}'


class CimMethod:
    def __init__(
        self, resolver: CimResolver, namespace: str, class_name: str, method_name: str, selectors: dict[str, str]
    ) -> None:
        self.resolver = resolver
        self.namespace = namespace
        self.class_name = class_name
        self.method_name = method_name
        self.selectors = selectors
        self._arguments: dict[str, Any] = {}

    def __call__(self, **arguments) -> 'CimMethod':
        self._arguments = arguments
        return self

    async def invoke(self, poll_interval: float = 0.5, poll_timeout: int = 300) -> Any:
        resource_uri = f'http://schemas.microsoft.com/wbem/wsman/1/wmi/{self.namespace}/{self.class_name}'

        for key, value in self._arguments.items():
            if isinstance(value, CimInstanceBuilder):
                self._arguments[key] = value.ref().to_xml()
            elif isinstance(value, CimReference):
                self._arguments[key] = value.to_xml()
            elif isinstance(value, CimInstanceXmlGenerator):
                self._arguments[key] = value.to_xml()
            else:
                continue

        return await self.resolver.invoke(
            resource_uri=resource_uri,
            method=self.method_name,
            arguments=self._arguments,
            selectors=self.selectors,
            poll_interval=poll_interval,
            poll_timeout=poll_timeout,
        )

    def __await__(self):
        return self.invoke().__await__()


class CimInstanceXmlGenerator:
    __slots__ = ('class_name', 'root')

    def __init__(self, class_name: str) -> None:
        self.class_name = class_name
        self.root = Element('INSTANCE')
        self.root.set('CLASSNAME', self.class_name)

    def add_property(self, name: str, value: Any, prop_type: str, modified: bool = False) -> None:
        is_array = isinstance(value, (list, tuple))
        if is_array:
            prop = SubElement(self.root, 'PROPERTY.ARRAY', attrib={'NAME': name, 'TYPE': prop_type})
            if modified:
                prop.set('MODIFIED', 'TRUE')
            if value:
                array_elem = SubElement(prop, 'VALUE.ARRAY')
                for item in value:
                    SubElement(array_elem, 'VALUE').text = str(item)
        else:
            prop = SubElement(self.root, 'PROPERTY', attrib={'NAME': name, 'TYPE': prop_type})
            if modified:
                prop.set('MODIFIED', 'TRUE')

            if value is not None and value != '':
                SubElement(prop, 'VALUE').text = str(value)

    def to_xml(self) -> str:
        return tostring(self.root, encoding='unicode', method='xml')
