import logging
from datetime import datetime
from typing import TYPE_CHECKING, Any
from xml.etree.ElementTree import Element
from dataclasses import make_dataclass
from .method import CimMethodResult
from .objects import CimReference
from .types import CimType

if TYPE_CHECKING:
    from .resolver import CimResolver

logger = logging.getLogger('wsmanio')


class CimTypeMapper:
    def get_cim_type(self, value: str) -> CimType:
        if value.casefold() in ('true', 'false'):
            return CimType.BOOLEAN
        try:
            int(value)
            return CimType.SINT64
        except ValueError:
            try:
                float(value)
                return CimType.REAL64
            except ValueError:
                return CimType.STRING


class CimValueParser:
    __slots__ = ('type_mapper',)

    def __init__(self, type_mapper: CimTypeMapper) -> None:
        self.type_mapper = type_mapper

    # def parse(self, node: Element) -> 'CimValue':
    #     if node.attrib.get('{http://www.w3.org/2001/XMLSchema-instance}nil') == 'true':
    #         return CimValue(value=None, cim_type=CimType.STRING)

    #     cim_type = self.type_mapper.get_cim_type(node.text or '')
    #     value = self.cast_primitive(node.text, cim_type)
    #     return CimValue(value=value, cim_type=cim_type)

    def parse(self, node: Element) -> Any:
        if node.attrib.get('{http://www.w3.org/2001/XMLSchema-instance}nil') == 'true':
            return None

        return node.text or ''

    @staticmethod
    def cast_primitive(value: str | None, cim_type: CimType) -> Any:
        if value is None:
            return None

        value = value.strip()

        if cim_type == CimType.BOOLEAN:
            return value.lower() == 'true'

        if cim_type in (
            CimType.UINT8,
            CimType.UINT16,
            CimType.UINT32,
            CimType.UINT64,
            CimType.SINT8,
            CimType.SINT16,
            CimType.SINT32,
            CimType.SINT64,
        ):
            try:
                return int(value)
            except ValueError:
                return value

        if cim_type in (CimType.REAL32, CimType.REAL64):
            try:
                return float(value)
            except ValueError:
                return value

        if cim_type == CimType.DATETIME:
            return datetime.fromisoformat(value)

        return value


class CimReferenceParser:
    def parse(self, node: Element) -> 'CimReference | None':
        address = node.find('.//{*}Address')
        ref_params = node.find('.//{*}ReferenceParameters')
        if address is None or ref_params is None:
            return None

        resource_uri = ref_params.find('.//{*}ResourceURI')
        selector_set = ref_params.find('.//{*}SelectorSet')
        if resource_uri is None or selector_set is None:
            return None

        selectors = {}
        for selector in selector_set.findall('.//{*}Selector'):
            name = selector.attrib.get('Name')
            selectors[name] = selector.text

        return CimReference(
            resource_uri=str(resource_uri.text),
            selectors=selectors,
        )


class CimInstanceParser:
    __slots__ = ('value_parser', 'ref_parser')

    def __init__(self, value_parser: CimValueParser, ref_parser: CimReferenceParser) -> None:
        self.value_parser = value_parser
        self.ref_parser = ref_parser

    @staticmethod
    def strip(tag: str) -> str:
        return tag.split('}')[-1]

    def parse(self, xml: Element) -> Any:
        class_name = self.strip(xml.tag)

        props: dict[str, Any] = {}
        if len(xml) < 1:
            self._add_to_props(props, self.strip(xml.tag), xml.text)
        for child in xml:
            key = self.strip(child.tag)

            ref = self.ref_parser.parse(child)
            if ref is not None:
                self._add_to_props(props, key, ref)
                continue

            if len(child) > 0:
                nested_instance = self.parse(child)
                self._add_to_props(props, key, nested_instance)
                continue

            value = self.value_parser.parse(child)
            self._add_to_props(props, key, value)

        cls = make_dataclass(
            cls_name=class_name,
            fields=[(key, type(value)) for key, value in props.items()],
            slots=True,
        )
        return cls(**props)

    def _add_to_props(self, props: dict[str, Any], key: str, value: Any) -> None:
        if (prop := props.get(key)) is not None:
            if isinstance(prop, list):
                prop.append(value)
            else:
                props[key] = [prop, value]
        else:
            props[key] = value


class CimParser:
    def __init__(self, resolver: 'CimResolver'):
        self.resolver = resolver
        self.type_mapper = CimTypeMapper()
        self.value_parser = CimValueParser(self.type_mapper)
        self.ref_parser = CimReferenceParser()
        self.instance_parser = CimInstanceParser(self.value_parser, self.ref_parser)

    def parse_instance(self, xml: Element) -> Any:
        return self.instance_parser.parse(xml)

    def parse_reference(self, node: Element) -> CimReference | None:
        return self.ref_parser.parse(node)

    def parse_value(self, node: Element) -> Any:
        return self.value_parser.parse(node)

    def parse_method_result(self, xml: Element) -> CimMethodResult:
        """Парсинг результата метода CIM"""
        return_value = 0
        job = None
        output = {}

        for child in xml:
            tag = CimInstanceParser.strip(child.tag)

            if tag == 'ReturnValue':
                val = self.value_parser.parse(child)
                return_value = val if val is not None else 0

            elif tag == 'Job':
                job = self.ref_parser.parse(child)

            else:
                ref = self.ref_parser.parse(child)
                if ref is not None:
                    output[tag] = ref
                    continue
                output[tag] = child.text

        return CimMethodResult(
            return_value=int(return_value),
            job=job,
            output=output,
            raw_xml=xml,
        )
