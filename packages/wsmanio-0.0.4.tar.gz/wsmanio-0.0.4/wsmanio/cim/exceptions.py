class CimError(Exception): ...


class CimJobError(CimError):
    def __init__(self, state: int, code: int, description: str | None = None) -> None:
        self.state = state
        self.code = code
        self.description = description

        message = f'WMI job failed: state={self.state}, code={self.code}'
        if self.description:
            message += f', description={self.description}'

        super().__init__(message)
