from abc import ABC
from dataclasses import dataclass
from xml.etree.ElementTree import Element, SubElement

from ..wsman import NAMESPACES


class ICimNode(ABC): ...


@dataclass(slots=True)
class CimReference(ICimNode):
    resource_uri: str
    selectors: dict[str, str]

    def to_xml(self) -> list[Element]:
        epr = Element('temp')
        wsa = NAMESPACES['wsa']
        SubElement(epr, f'{{{wsa}}}Address').text = 'http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous'

        wsman = NAMESPACES['wsman']
        ref_params = SubElement(epr, f'{{{wsa}}}ReferenceParameters')
        SubElement(ref_params, f'{{{wsman}}}ResourceURI').text = self.resource_uri

        selector_set = SubElement(ref_params, f'{{{wsman}}}SelectorSet')
        for key, value in self.selectors.items():
            SubElement(selector_set, f'{{{wsman}}}Selector', Name=key).text = value

        return list(epr)


# @dataclass(slots=True)
# class CimInstanceData(ICimNode):
#     class_name: str
#     properties: dict[str, Any]

#     def __getattr__(self, name: str) -> Any:
#         if (value := self.properties.get(name)) is not None:
#             return value.value if isinstance(value, CimValue) else value
#         raise AttributeError(name)
