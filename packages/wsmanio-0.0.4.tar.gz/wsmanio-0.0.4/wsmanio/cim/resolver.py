from typing import Any
import logging
from xml.etree.ElementTree import Element, SubElement, tostring

from ..wsman import NAMESPACES, SelectorSet, WSMan
from .method import CimJobManager, CimMethodResult
from .objects import CimReference
from .parser import CimParser
from .query import CimQueryResult

logger = logging.getLogger('wsmanio')


class CimReader:
    __slots__ = ('client', 'parser')

    def __init__(self, client: WSMan, parser: CimParser) -> None:
        self.client = client
        self.parser = parser

    async def get(self, ref: CimReference) -> Any:
        selector_set = SelectorSet()
        for key, value in ref.selectors.items():
            selector_set.add_option(name=key, value=value)

        body = await self.client.get(
            resource_uri=ref.resource_uri,
            selector_set=selector_set,
        )
        xml = body.find('./*')
        if xml is None:
            raise RuntimeError
        return self.parser.parse_instance(xml)

    async def query(self, query: str, resource_uri: str) -> CimQueryResult:
        wsen = NAMESPACES['wsen']
        resource = Element(f'{{{wsen}}}Enumerate')
        wsman = NAMESPACES['wsman']
        SubElement(
            resource,
            f'{{{wsman}}}Filter',
            attrib={'Dialect': 'http://schemas.microsoft.com/wbem/wsman/1/WQL'},
        ).text = query

        body = await self.client.enumerate(resource_uri=resource_uri, resource=resource)
        context = body.find('wsen:EnumerateResponse/wsen:EnumerationContext', namespaces=NAMESPACES)
        if context is None:
            raise RuntimeError
        if context.text is None:
            raise RuntimeError
        return CimQueryResult(client=self.client, resource_uri=resource_uri, context=context.text, parser=self.parser)


class CimWriter:
    __slots__ = ('client', 'parser')

    def __init__(self, client: WSMan, parser: CimParser) -> None:
        self.client = client
        self.parser = parser

    async def invoke(
        self,
        resource_uri: str,
        method: str,
        arguments: dict[str, str | Element | list[Element]],
        selectors: dict[str, str] | None = None,
    ) -> CimMethodResult:
        resource = Element(f'{{{resource_uri}}}{method}_INPUT')

        for key, value in arguments.items():
            field = SubElement(resource, f'{{{resource_uri}}}{key}')
            if isinstance(value, list):
                for subval in value:
                    if isinstance(subval, Element):
                        field.append(subval)
                    else:
                        raise ValueError(f'Unsupported value, {subval=}, {type(subval)}')
            elif isinstance(value, Element):
                field.text = tostring(value, encoding='unicode', method='xml')
            else:
                field.text = value

        selector_set = None
        if selectors:
            selector_set = SelectorSet()
            for key, value in selectors.items():
                selector_set.add_option(name=key, value=value)

        body = await self.client.custom(
            action=f'{resource_uri}/{method}',
            resource_uri=resource_uri,
            resource=resource,
            selector_set=selector_set,
        )
        output = body.find(f'.//{{*}}{method}_OUTPUT')
        if output is None:
            logger.exception('Unable to find output')
            raise RuntimeError(f'Missing {method}_OUTPUT in response')

        return self.parser.parse_method_result(output)


class CimResolver:
    __slots__ = ('client', 'parser', 'reader', 'writer', 'job_manager')

    def __init__(self, client: WSMan):
        self.client = client
        self.parser = CimParser(self)
        self.reader = CimReader(client=client, parser=self.parser)
        self.writer = CimWriter(client=client, parser=self.parser)
        self.job_manager = CimJobManager(self.reader)

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.client.close()

    async def get(self, ref: CimReference) -> Any:
        return await self.reader.get(ref)

    async def query(self, query: str, resource_uri: str) -> CimQueryResult:
        return await self.reader.query(query=query, resource_uri=resource_uri)

    async def invoke(
        self,
        resource_uri: str,
        method: str,
        arguments: dict[str, str | Element | list[Element]],
        selectors: dict[str, str] | None = None,
        poll_interval: float = 0.5,
        poll_timeout: int = 300,
    ) -> Any:
        result_method = await self.writer.invoke(
            resource_uri=resource_uri,
            method=method,
            arguments=arguments,
            selectors=selectors,
        )
        if result_method.job is not None and result_method.return_value == 4096:
            return await self.poll_job(job=result_method.job, interval=poll_interval, timeout=poll_timeout)
        return result_method

    async def poll_job(self, job: CimReference, interval: float, timeout: float) -> Any:
        return await self.job_manager.poll(job, interval, timeout)
