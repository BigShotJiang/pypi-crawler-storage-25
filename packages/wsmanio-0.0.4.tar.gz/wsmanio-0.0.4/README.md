# WSMANIO

## Examples

### Shell

```python
import asyncio

from wsmanio.shell import Encoding, Process, WinRS
from wsmanio.wsman import HTTPTransport, WSMan

async def main():
    async with (
        WSMan(
            transport=HTTPTransport(
                server_url='https://windows-server.lan:5986/wsman',
                username='username',
                password='password',
            )
        ) as wsman,
        WinRS(
            wsman=wsman,
            encoding=Encoding.UTF8,
        ) as shell,
    ):
        process = Process(shell=shell, executable='powershell', arguments=['-command', '"Get-Process | Select Name"'])
        await process.invoke()
        print(process.rc)
        print(process.stdout.decode(errors='replace'))
        print(process.stderr.decode(errors='replace'))


if __name__ == '__main__':
    asyncio.run(main())
```

### WMI

```python
import asyncio

from wsmanio.wmi import WMIClient
from wsmanio.wsman import HTTPTransport, WSMan

async def main():
    async with WSMan(
        transport=HTTPTransport(
            server_url='https://windows-server.lan:5986/wsman',
            username='username',
            password='password',
        )
    ) as wsman:
        wmi = WMIClient(wsman=wsman)
        result = await (
            wmi.virtualization
            .Msvm_ComputerSystem(Name='9E41B16C-E617-4B54-9515-1905CDA18C3F', CreationClassName='Msvm_ComputerSystem')
            .get()
        )
        print(result)

        result = await (
            wmi.cimv2
            .Win32_Process()
            .Create(CommandLine='notepad.exe', CurrentDirectory='C:\\')
        )
        print(result)

        result = await (
            wmi.virtualization
            .Msvm_ComputerSystem(Name='9E41B16C-E617-4B54-9515-1905CDA18C3F')
            .RequestStateChange(RequestedState='3')
        )
        print(result)


if __name__ == '__main__':
    asyncio.run(main())
```
