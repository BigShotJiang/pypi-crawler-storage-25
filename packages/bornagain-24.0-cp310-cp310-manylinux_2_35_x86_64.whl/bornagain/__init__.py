#  **************************************************************************  #
#   BornAgain: simulate and fit reflection and scattering
#
#   @file      source:     Wrap/Python/src/bornagain/__init__.py.in
#              configured: build/py/src/bornagain/__init__.py
#   @brief     Top-level __init__.py of Python module BornAgain.
#
#   @homepage  http://apps.jcns.fz-juelich.de/BornAgain
#   @license   GNU General Public License v3 or higher (see COPYING)
#   @copyright Forschungszentrum Juelich GmbH 2016
#   @authors   Scientific Computing Group at MLZ (see CITATION, AUTHORS)
#  **************************************************************************  #

version = (24, 0)
version_str = "24.0"

# import all available BornAgain functionality
# add the package directory to sys.path so that
# the absolute imports in Python wrappers can find the shared libraries
# NOTE: Adding the path to Python path is required for the automatically-built SWIG wrappers

import os, sys

BA_LIBPATH = os.path.dirname(__file__)
sys.path.append(BA_LIBPATH)

if sys.platform == 'win32':
    os.add_dll_directory(BA_LIBPATH)

from .libBornAgainBase import *
from .libBornAgainSample import *
from .libBornAgainResample import *
from .libBornAgainDevice import *
from .libBornAgainSim import *

from .ba_fit import FitObjective, IterationInfo


def showSample3D(sample, sample_size, seed=0, **kwargs):
    """Shows an interactive 3D visualization of a BornAgain Sample.

    Requires vtk: pip install vtk

    Args:
        sample:      a bornagain.Sample instance.
        sample_size: side length of the visible square sample patch, in nm.
        seed:        base seed for particle positions and Mixture realization.
        **kwargs:    window_size, background, roughness, roughness_resolution, blocking —
                     forwarded to ba_view3d.plot_sample.
    """
    from .ba_view3d import plot_sample
    return plot_sample(sample, sample_size=sample_size, seed=seed, **kwargs)
