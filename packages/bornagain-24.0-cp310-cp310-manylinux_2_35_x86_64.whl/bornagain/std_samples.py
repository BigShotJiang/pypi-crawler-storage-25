"""
BornAgain collection of standard sample.
"""
import bornagain as ba
from bornagain import deg, nm


def alternating_layers():
    """
    Returns sample sample consisting of 20 alternating Ti and Ni layers.
    """

    # Define materials
    ambient_mat = ba.Vacuum()
    ti_color = (0.05, 0.62, 0.55)
    ti_mat = ba.SLDMaterial("Ti", ti_color, -1.9493e-06, 0)
    ni_color = (0.93, 0.48, 0.14)
    ni_mat = ba.SLDMaterial("Ni", ni_color, 9.4245e-06, 0)
    substrate_color = (0.28, 0.57, 0.82)
    substrate_mat = ba.SLDMaterial("SiSubstrate", substrate_color, 2.0704e-06, 0)

    # Define layers
    ambient_layer = ba.Layer(ambient_mat)
    ti_layer = ba.Layer(ti_mat, 3*nm)
    ni_layer = ba.Layer(ni_mat, 7*nm)
    substrate_layer = ba.Layer(substrate_mat)

    # Define stack
    n_repetitions = 10
    stack = ba.LayerStack(n_repetitions)
    stack.addLayer(ti_layer)
    stack.addLayer(ni_layer)

    # Define sample
    sample = ba.Sample()
    sample.addLayer(ambient_layer)
    sample.addStack(stack)
    sample.addLayer(substrate_layer)

    return sample


def substrate_plus_particle(particle):
    """
    Returns sample consisting of a substrate, and uncorrelated particles on top.
    """

    # Define material
    substrate_color = (0.28, 0.57, 0.82)
    substrate_mat = ba.RefractiveMaterial("Substrate", substrate_color, 6e-6, 2e-08)

    # Define layers
    layer_1 = ba.Layer(ba.Vacuum())
    layer_1.deposit2D(ba.Dilute2D(0.001, particle))
    layer_2 = ba.Layer(substrate_mat)

    # Define sample
    sample = ba.Sample()
    sample.addLayer(layer_1)
    sample.addLayer(layer_2)

    return sample


def cylinders():
    """
    Returns sample consisting of dilute cylinders on substrate.
    """
    particle_color = (0.86, 0.24, 0.18)
    mat = ba.RefractiveMaterial("Particle", particle_color, 6e-4, 2e-08)
    ff = ba.Cylinder(5*nm, 5*nm)
    particle = ba.Particle(mat, ff)

    return substrate_plus_particle(particle)
