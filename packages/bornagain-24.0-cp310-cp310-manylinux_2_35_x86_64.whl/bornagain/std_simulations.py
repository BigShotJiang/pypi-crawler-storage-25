"""
BornAgain collection of standard simulation setups.
"""
import bornagain as ba
from bornagain import deg, angstrom


def particle(particle, n):
    """
    Returns a ParticleSimulation for computing pure form factor scattering.
    """
    beam = ba.Beam(1, 1*angstrom, 0)
    det = ba.SphericalDetector(n, -4.5*deg, 4.5*deg, n, -4.5*deg, 4.5*deg)
    return ba.ParticleSimulation(beam, particle, det)
