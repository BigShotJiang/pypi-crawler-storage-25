"""MCP Resource tools — list and read MCP server resources.

MCP servers can expose resources (files, data) in addition to tools.
These tools let the agent discover and read them.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from typing import ClassVar, final

from pydantic import BaseModel, Field

from drydock.core.tools.base import (
    BaseTool, BaseToolConfig, BaseToolState, InvokeContext, ToolError, ToolPermission,
)
from drydock.core.tools.ui import ToolCallDisplay, ToolResultDisplay, ToolUIData
from drydock.core.types import ToolStreamEvent, ToolResultEvent


class ListMcpResourcesArgs(BaseModel):
    server_name: str = Field(default="", description="MCP server name (empty = all servers)")


class McpResource(BaseModel):
    uri: str
    name: str
    description: str = ""
    mime_type: str = ""
    server: str = ""


class ListMcpResourcesResult(BaseModel):
    resources: list[McpResource]
    count: int


class ListMcpResources(
    BaseTool[ListMcpResourcesArgs, ListMcpResourcesResult, BaseToolConfig, BaseToolState],
    ToolUIData[ListMcpResourcesArgs, ListMcpResourcesResult],
):
    description: ClassVar[str] = "List resources available from MCP servers."

    @classmethod
    def format_call_display(cls, args: ListMcpResourcesArgs) -> ToolCallDisplay:
        return ToolCallDisplay(summary=f"list_mcp_resources: {args.server_name or 'all'}")

    @classmethod
    def get_result_display(cls, event: ToolResultEvent) -> ToolResultDisplay:
        if isinstance(event.result, ListMcpResourcesResult):
            return ToolResultDisplay(success=True, message=f"{event.result.count} resources")
        return ToolResultDisplay(success=True, message="Resources listed")

    @classmethod
    def get_status_text(cls) -> str:
        return "Listing MCP resources"

    def resolve_permission(self, args: ListMcpResourcesArgs) -> ToolPermission | None:
        return ToolPermission.ALWAYS

    @final
    async def run(
        self, args: ListMcpResourcesArgs, ctx: InvokeContext | None = None
    ) -> AsyncGenerator[ToolStreamEvent | ListMcpResourcesResult, None]:
        resources: list[McpResource] = []

        try:
            if ctx and hasattr(ctx, 'agent_manager') and ctx.agent_manager:
                config = ctx.agent_manager.config
                servers = [s for s in (config.mcp_servers or [])
                           if getattr(s, "enabled", True)]

                from drydock.core.tools.mcp.tools import (
                    list_resources_http, list_resources_stdio,
                )
                from drydock.core.config import MCPStdio, MCPHttp

                tasks = []
                for srv in servers:
                    if args.server_name and getattr(srv, 'alias', '') != args.server_name:
                        continue
                    if isinstance(srv, MCPHttp):
                        tasks.append(list_resources_http(
                            srv.url,
                            headers=srv.headers,
                            startup_timeout_sec=srv.startup_timeout_sec,
                        ))
                    elif isinstance(srv, MCPStdio):
                        tasks.append(list_resources_stdio(
                            srv.argv(),
                            env=srv.env,
                            startup_timeout_sec=srv.startup_timeout_sec,
                        ))

                if tasks:
                    results = await asyncio.gather(*tasks, return_exceptions=True)
                    for result in results:
                        if isinstance(result, list):
                            for r in result:
                                resources.append(McpResource(
                                    uri=r.uri, name=r.name,
                                    description=r.description,
                                    mime_type=r.mime_type,
                                    server=r.server,
                                ))
        except Exception as e:
            raise ToolError(f"Failed to list MCP resources: {e}") from e

        yield ListMcpResourcesResult(resources=resources, count=len(resources))


class ReadMcpResourceArgs(BaseModel):
    uri: str = Field(description="Resource URI to read")
    server_name: str = Field(default="", description="MCP server name (required if multiple servers)")


class ReadMcpResourceResult(BaseModel):
    uri: str
    content: str
    mime_type: str = ""


class ReadMcpResource(
    BaseTool[ReadMcpResourceArgs, ReadMcpResourceResult, BaseToolConfig, BaseToolState],
    ToolUIData[ReadMcpResourceArgs, ReadMcpResourceResult],
):
    description: ClassVar[str] = "Read a resource from an MCP server by URI."

    @classmethod
    def format_call_display(cls, args: ReadMcpResourceArgs) -> ToolCallDisplay:
        return ToolCallDisplay(summary=f"read_mcp_resource: {args.uri[:50]}")

    @classmethod
    def get_result_display(cls, event: ToolResultEvent) -> ToolResultDisplay:
        return ToolResultDisplay(success=True, message="Resource read")

    @classmethod
    def get_status_text(cls) -> str:
        return "Reading MCP resource"

    def resolve_permission(self, args: ReadMcpResourceArgs) -> ToolPermission | None:
        return ToolPermission.ALWAYS

    @final
    async def run(
        self, args: ReadMcpResourceArgs, ctx: InvokeContext | None = None
    ) -> AsyncGenerator[ToolStreamEvent | ReadMcpResourceResult, None]:
        # Fast path: file:// URIs that resolve to an existing local file
        # should be read directly, not routed through MCP. Observed
        # 2026-05-20 in /data3/slides: model called
        # read_mcp_resource('file:///data3/slides/slides/extractor/md_extractor.py')
        # → MCP filesystem server returned a StdioServerParameters
        # validation error → model retried 3+ times. The right tool
        # for a local file is read_file, but the model picked
        # read_mcp_resource; intercepting it here makes the call work
        # anyway instead of error-looping.
        uri = (args.uri or "").strip()
        if uri.startswith("file://"):
            from pathlib import Path as _Path
            from urllib.parse import unquote, urlparse
            _parsed = urlparse(uri)
            _local = _Path(unquote(_parsed.path))
            if _local.is_file():
                try:
                    _content = _local.read_text(
                        encoding="utf-8", errors="replace",
                    )
                except OSError as e:
                    raise ToolError(
                        f"read_mcp_resource: file:// URI {uri} could not "
                        f"be read locally: {e}. Tip: use read_file for "
                        f"local files instead of read_mcp_resource."
                    ) from e
                yield ReadMcpResourceResult(
                    uri=uri, content=_content, mime_type="text/plain",
                )
                return

        if not ctx or not hasattr(ctx, 'agent_manager') or not ctx.agent_manager:
            raise ToolError("No agent manager available for MCP resource reading")

        config = ctx.agent_manager.config
        servers = [s for s in (config.mcp_servers or [])
                   if getattr(s, "enabled", True)]

        if not servers:
            raise ToolError(
                "No MCP servers configured (or all are disabled). "
                "For local files use read_file; for shell commands use bash."
            )

        from drydock.core.tools.mcp.tools import read_resource_http, read_resource_stdio
        from drydock.core.config import MCPStdio, MCPHttp

        # Try each server until we find the resource
        last_error = None
        for srv in servers:
            if args.server_name and getattr(srv, 'alias', '') != args.server_name:
                continue
            try:
                if isinstance(srv, MCPHttp):
                    content = await read_resource_http(
                        srv.url, args.uri,
                        headers=srv.headers,
                        startup_timeout_sec=srv.startup_timeout_sec,
                    )
                elif isinstance(srv, MCPStdio):
                    content = await read_resource_stdio(
                        srv.argv(), args.uri,
                        env=srv.env,
                        startup_timeout_sec=srv.startup_timeout_sec,
                    )
                else:
                    continue

                yield ReadMcpResourceResult(
                    uri=args.uri,
                    content=content,
                    mime_type="",
                )
                return
            except Exception as e:
                last_error = e
                continue

        hint = " Use read_file for local paths instead." if args.uri.startswith("file://") else ""
        raise ToolError(
            f"Could not read resource '{args.uri}' from any configured MCP server. "
            f"Last error: {last_error}.{hint}"
        )
