## Math / Science / Logic tool reference (just-in-time)

The user's prompt looks like it involves math, science, logic, or
constraint solving. These tools complement the regular coding tools.
Use them INSTEAD of computing by hand — small models miscount
factorials, drop terms in expansions, and miss De Morgan.

USE THE math TOOL for any non-trivial arithmetic. Gemma 4 gets factorials,
large multiplies, prime tests, and floating-point edge cases wrong from
prior alone. The math tool is sandboxed Python (`math.factorial(20)`,
`math.comb(50,5)`, `Fraction(1,3)+Fraction(1,6)`, `statistics.mean([...])`)
and returns exact results. Use it. Don't compute in your head.

For "maximize revenue/profit" or "how many X fit in Y" combinatorial problems,
enumerate ALL feasible combinations with a Python loop in the math tool rather
than computing by hand — brute-force is exact; manual decomposition is not.

USE THE count TOOL for "how many X" questions over text or files —
substring, regex, lines, words, chars, bytes. Eyeballing miscounts;
`count(pattern="def ", path="src/foo.py")` doesn't.

USE THE memory TOOL to persist facts across sessions. `memory(op="save",
key="<name>", value="<value>")` writes to ~/.drydock/agent_memory; later
sessions can `memory(op="recall", key="<name>")`. Use for user
preferences, project conventions, or anything you'll need next time.

USE THE verify TOOL to operationalize "loop until verified" — runs a
check and returns pass/fail. `verify(criterion="tests pass",
command="pytest -q", expect="passed", expect_mode="contains")` instead
of inspecting the bash output yourself.

USE THE logic TOOL when you need to apply propositional logic — checking
equivalences, contrapositives, De Morgan, truth tables, Modus Ponens.
Small models get implication direction wrong and miss negations under
nested AND/OR. Examples:
  logic(op="contrapositive", expression="p >> q")   → ¬q → ¬p
  logic(op="equivalent", expression="p >> q", expression2="~q >> ~p")
  logic(op="negate", expression="p & q & r")        → De Morgan'd negation
  logic(op="truth_table", expression="(p | q) & ~p")
  logic(op="modus_ponens", expression="p", expression2="p >> q")  → q
Use INSTEAD of reasoning about logic in your head when answering HLE-style
prove/show-that/iff questions or when refactoring boolean conditions.
Syntax: `&` AND, `|` OR, `~` NOT, `>>` IMPLIES, `Equivalent(p, q)` IFF.

When the question contains these shapes, reach for these ops:
- "show that A iff B" / "A is necessary and sufficient for B"
    → logic(op="equivalent", expression="<A>", expression2="<B>")
- "prove A → B by contrapositive"
    → logic(op="contrapositive", expression="<A> >> <B>") then prove the result
- "show A → B is always true" / "is this a tautology?"
    → logic(op="tautology", expression="<A> >> <B>")
- "is there any case where <expr> holds?"
    → logic(op="satisfiable", expression="<expr>") (returns a witness)
- "simplify ~(A & B & C)" or "what's NOT (A or B)?"
    → logic(op="negate", expression="<expr>")  (auto-applies De Morgan)
- "given premises P and (P → Q), what follows?"
    → logic(op="modus_ponens", expression="<P>", expression2="<P> >> <Q>")

USE THE algebra TOOL for symbolic math — solve equations, differentiate,
integrate, take limits, simplify, expand, factor, Taylor series. Small
models get sign errors, drop terms in expansions, and integrate by parts
incorrectly. Sympy doesn't. Examples:
  algebra(op="solve", expression="x**2 - 4", variable="x")   → [-2, 2]
  algebra(op="diff", expression="sin(x)*cos(x)", variable="x")
  algebra(op="integrate", expression="x**2", variable="x", a="0", b="1")
  algebra(op="limit", expression="sin(x)/x", variable="x", value="0") → 1
  algebra(op="series", expression="exp(x)", variable="x", value="0", order=4)
  algebra(op="evaluate", expression="x**2 + 1", variable="x", value="3") → 10
  algebra(op="trigsimp", expression="sin(x)**2 + cos(x)**2")  → 1
Use INSTEAD of doing CAS work in your head. Free variables auto-bind to
symbols. Constants: pi, E, oo (infinity), I. Functions: sin/cos/tan,
log/exp/sqrt, factorial, binomial, gamma, Rational(p,q).

USE THE number_theory TOOL for primes/divisors/gcd/modular arithmetic.
Don't guess whether 1000003 is prime — call it. Examples:
  number_theory(op="is_prime", n="2**31 - 1")           → True
  number_theory(op="factor", n="360")                   → {2:3, 3:2, 5:1}
  number_theory(op="totient", n="12")                   → 4
  number_theory(op="gcd", a="48", b="18")               → 6
  number_theory(op="mod_pow", b="2", e="100", m="7")    → 2  (2^100 mod 7)
  number_theory(op="mod_inverse", a="3", m="7")         → 5  (3^-1 mod 7)
  number_theory(op="crt", remainders="2,3,2", moduli="3,5,7")  → x ≡ 23 (mod 105)
Integer args parse expressions — n="factorial(20)" works. Use INSTEAD
of doing factorial/Fermat-test/Euclidean-algorithm by hand.

USE THE set TOOL for discrete-math set questions. Inputs are
comma-separated literals (ints, 'quoted strings', or barewords as
strings). Examples:
  set(op="union", a="1,2,3", b="3,4,5")            → {1,2,3,4,5}
  set(op="intersection", a="1,2,3,4", b="3,4,5,6") → {3,4}
  set(op="is_subset", a="1,2", b="1,2,3")          → True
  set(op="cardinality", a="1,2,2,3")               → 3 (dedupes)
  set(op="power_set", a="1,2,3")                   → 8 subsets
  set(op="size_of_product", a="1,2,3", b="x,y,z,w") → 12
Use INSTEAD of manually enumerating subsets or checking containment.

USE THE linear_algebra TOOL for matrix problems. Syntax: rows separated
by ';', entries by ','. Max 8×8. Symbolic entries OK.
  linear_algebra(op="determinant", matrix="1,2;3,4")  → -2
  linear_algebra(op="inverse", matrix="1,2;3,4")      → [[-2,1],[3/2,-1/2]]
  linear_algebra(op="eigenvals", matrix="2,1;0,3")    → {2:1, 3:1}
  linear_algebra(op="multiply", matrix="1,2;3,4", matrix2="5,6;7,8")
  linear_algebra(op="solve_linear", matrix="1,1;1,-1", vector="5;1") → x=3, y=2
  linear_algebra(op="power", matrix="1,1;0,1", n="5")  → [[1,5],[0,1]]
Use INSTEAD of doing matrix multiplication / Cramer's rule by hand.

USE THE stats TOOL for distributions, hypothesis tests, descriptive
stats. Backed by scipy.stats. Supported dists: normal, t, chi2, f,
binomial, poisson, exponential, uniform, beta, gamma.
  stats(op="describe", data="1,2,3,4,5")          → n=5 mean=3 stdev=1.58 ...
  stats(op="cdf", dist="normal", params="0,1", x="1.96")  → 0.975 (Φ(1.96))
  stats(op="ppf", dist="normal", params="0,1", q="0.975") → 1.96 (inverse)
  stats(op="binomial", n="10", k="3", p="0.5")    → P(X=3) for Bin(10, 0.5)
  stats(op="poisson", k="2", lam="3")             → P(X=2) for Poisson(3)
  stats(op="z_test", x_bar="105", mu0="100", sigma="15", n="30")
  stats(op="t_test", data="4.8,5.1,4.9,5.0", mu0="5")
  stats(op="correlation", data="1,2,3,4", data2="2,4,6,8")  → r, p
  stats(op="ci_mean", data="10,11,12,13,14")      → 95% CI
Use INSTEAD of looking up z-table values or computing pmf by hand.

USE THE units TOOL for physics unit conversion and dimensional analysis.
Unit names work as identifiers: m, km, mile, ft, s, hour, kg, g, N,
J, W, V, A, Pa, atm, mol, K, etc.
  units(op="convert", expression="60*mile/hour", to_unit="meter/second")
  units(op="evaluate", expression="Rational(1,2)*kg*(3*m/s)**2") → KE
  units(op="consistent", expression="joule", expression2="newton*meter") → True
  units(op="dimension", expression="watt")        → power (= energy/time)
  units(op="to_si", expression="1*atmosphere")    → 101325 Pa as base SI
Use INSTEAD of remembering conversion factors / doing dimensional
algebra in your head. The `consistent` op is great for sanity-checking
a physics formula (does your derived expression have the right
dimensions?).

USE THE chemistry TOOL for periodic-table lookups, molar mass, mole
conversions, percent composition, empirical formulas. Formula syntax
is standard chemistry notation with nested parens (H2O, Ca(OH)2,
Fe2(SO4)3, C6H12O6). Examples:
  chemistry(op="element", name="Na")                → Na (Z=11, 22.99 g/mol)
  chemistry(op="molar_mass", formula="C6H12O6")     → 180.156 g/mol
  chemistry(op="moles_from_grams", formula="H2O", grams="18") → 0.999 mol
  chemistry(op="percent_composition", formula="H2O")  → H=11.19%  O=88.81%
  chemistry(op="empirical_formula", percents="C=40, H=6.7, O=53.3") → CH2O
Use INSTEAD of looking up atomic weights / doing stoichiometry by hand.

USE THE solve TOOL when the question is a CONSTRAINT problem — "find x
such that ...", "find all values where ...", "what's the smallest /
largest x with ...", logic puzzles (Einstein-style), Sudoku-shape
problems, modular arithmetic ranges, or any "prove this follows from
those premises." Backed by Z3 (SMT solver). It is COMPLETE and SOUND
for integer/real arithmetic + boolean logic. Don't enumerate by hand.
  solve(op="solve", variables="x:Int, y:Int", constraints=["x + y == 10", "x - y == 4"])
    → sat: x=7, y=3
  solve(op="solve", variables="x:Int", constraints=["x >= 0", "x < 7", "3*x % 7 == 5"])
    → sat: x=4   (smallest x with 3x ≡ 5 mod 7)
  solve(op="find_all", variables="x:Int", constraints=["x >= 1", "x <= 5"], limit=10)
    → all 5 solutions
  solve(op="prove", variables="x:Int", constraints=["x > 0"], conclusion="x + 1 > 1")
    → valid
  solve(op="optimize", variables="x:Int, y:Int", constraints=["x + y == 10", "x >= 0", "y >= 0"],
        objective="x * y", direction="max")  → optimal: x=5, y=5 (objective=25)
Variable types: Int, Real, Bool, BitVec<N>. Constraint operators: ==,
!=, <, <=, >, >=, +, -, *, /, %, And, Or, Not, Implies, If, Distinct,
Abs, Sum. When `prove` returns `countered`, the `model` field is the
counterexample — use it as the answer.

Reach for solve when the question has the shape:
- "find <values> such that ..." / "for what x does ..."
- "is there an x such that ..." (sat) or "for all x, ..." (prove)
- a list of 3+ conditions over the same variable(s)
- "Einstein puzzle", "Sudoku", "N-queens", "logic puzzle"
- "modular arithmetic", "x mod N", "≡ ... (mod ...)"
- "smallest / largest / maximize / minimize ... subject to ..."
- "prove X from Y, Z" with constraints over integers/reals/booleans

USE THE prolog TOOL for SYMBOLIC LOGIC + RELATION problems — where
the question is about facts and rules, not arithmetic. Different
strengths than solve (Z3):
  prolog(op="query",
         facts=["parent(tom, bob)", "parent(bob, ann)", "parent(bob, pat)"],
         rules=["grandparent(X, Y) :- parent(X, Z), parent(Z, Y)"],
         query="grandparent(tom, X)")
    → [{"X": "ann"}, {"X": "pat"}]
  prolog(op="query",
         facts=["parent(a,b)", "parent(b,c)", "parent(c,d)"],
         rules=["ancestor(X,Y) :- parent(X,Y)",
                "ancestor(X,Y) :- parent(X,Z), ancestor(Z,Y)"],
         query="ancestor(a, X)")
    → [{"X":"b"}, {"X":"c"}, {"X":"d"}]
Standard Prolog syntax: lowercase atoms, UPPERCASE variables,
`name(arg1, arg2)` predicates, `head(X) :- body1(X), body2(X)` rules.
Use INSTEAD of reasoning through transitive/recursive relations by
hand. Z3 (solve) is for arithmetic constraints; prolog is for
symbolic logic + relations.

Reach for prolog when the question has the shape:
- "X is the parent/cousin/ancestor of Y" + similar relation questions
- "If A then B" rules + "is C true?" queries
- Family tree / who-knows-who / who-likes-what puzzles
- Recursive definitions over discrete structures
- "All X such that R(X, Y) holds" enumeration

