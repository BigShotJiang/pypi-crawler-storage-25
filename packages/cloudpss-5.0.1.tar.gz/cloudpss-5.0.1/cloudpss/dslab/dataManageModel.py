from ..utils import request, fileLoad, graphql_request
import json
import time, datetime
import urllib.parse
import copy
import os 
from cloudpss.dslab.files import getCurveData

class DataManageModel(object):
    _weatherUrl = ''
    _baseUri = ''
    _kindUrlMap = {}
    _itemDataMap={}
    _kindItemDataMap={}
    _kindIdMap={}

    def __init__(self, resourceId):
        self.resourceId = resourceId
        self._fetchTypes()
    def _status(self):
        '''
            获取运行状态

            :return: boolean 类型
        '''
        pass
    def _fetchTypes(self):
        '''
            获取所有数据项的类型

            :return: list 类型，返回所有数据项的类型
        '''
        url = f"{self._baseUri}rest/types"
        r = request('GET',url)
        types = json.loads(r.text)
        self._kindUrlMap = {kind['name']: f"api/dslab/rest/{kind['name']}" for kind in types}
    def _fetchItemData(self, url):
        '''
            私有方法，获取simu对应所有数据项的列表
            :params: url string类型，request请求对应的url链接
            
            :return: list类型，返回该种类下所有数据项的的列表
        '''
        r = request('GET',
                    url,
                    params={
                        "simu": self.resourceId,
                    })
        return json.loads(r.text)
    
    def _saveItemData(self, url, data):
        '''
            私有方法，保存url链接对应的data数据
            :params: url string类型，request请求对应的url链接
            :params: data dict类型，表示添加的数据内容，其数据结构应满足对应数据项的结构要求
            
            :return: 无
        '''
        r = request('POST', url, data=json.dumps(data))
        

    def _updateItemData(self, url, data):
        '''
            私有方法，更新url链接对应的data数据
            :params: url string类型，request请求对应的url链接
            :params: data dict类型，表示添加的数据内容，其数据结构应满足对应数据项的结构要求
            
            :return: 无
        '''
        r = request('PUT', url, data=json.dumps(data))
    
    def _deleteItemData(self, url):
        '''
            私有方法，删除url链接对应的数据
            :params: url string类型，request请求对应的url链接
            
            :return: 无
        '''
        r = request('DELETE',url)

    def LocationGet(self):
        '''
            获取气象定位点数据

            :return: list<dict>类型，为源数据的引用，包含id，经度坐标，纬度坐标，定位点名称
        '''
        url = f"{self._baseUri}rest/location"
        r = request('GET',
            url,
            params={"simu": self.resourceId})
        return json.loads(r.text)

    def LocationCreate(self, name=None, longitude=None, latitude=None):
        '''
            创建气象定位点
            :param: name 定位点名称，可选
            :params: longitude float类型，可选，表示经度，范围为气象数据源的经度范围
            :params: latitude float类型，可选，表示纬度，范围为气象数据源的纬度范围
    
            :return: 无
        '''
        url = f"{self._baseUri}rest/location"
        r = request('POST',
            url,
            data=json.dumps({
                "lat": latitude  if latitude is not None else '34.734492',
                "lng": longitude if longitude is not None else '113.648906',
                "simu": self.resourceId,
                "name": name if name is not None else '定位点'
            }))
        d = json.loads(r.text)
        
    def LocationUpdate(self, id, name, longitude, latitude):
        '''
            修改气象定位点
            :param id: 定位点id
            :param: name 定位点名称，可选
            :params: longitude float类型，可选，表示经度，范围为气象数据源的经度范围
            :params: latitude float类型，可选，表示纬度，范围为气象数据源的纬度范围
    
            :return: 无
        '''
        if (float(longitude) > 180 or float(longitude) < -180
            or float(latitude) > 90 or float(latitude) < -90):
            raise Exception('经纬度坐标不存在')
        else:
            url = f"{self._baseUri}rest/location"
            r = request('PUT',
                url,
                data=json.dumps({
                    "lat": latitude,
                    "lng": longitude,
                    "simu": self.resourceId,
                    "name": name,
                    "id": id
                }))
            
    def LocationDelete(self, id):
        '''
            删除气象定位点
            :param id: 定位点id

            :return: 无
        '''
        url = f"{self._baseUri}rest/location/{str(id)}"
        r = request('DELETE',
                url)

    def LoadWeather(self):
        '''
            加载气象数据

            :return: 无
        '''
        url = f"{self._baseUri}rest/load_weather"
        r = request('GET',
            url,
            params = {
                "simu": self.resourceId,
            })
        
    def GetAtmosData(self, locationId, date):
        '''
            获取日期在date的气象数据
            :params: locationId str类型，表示定位点id
            :params: date dateTime类型，表示时间
            
            :return: list<dict>类型，为源数据的引用，返回当前项目位置对应时间范围内的气象数据序列，每个元素用字典进行表示，字典的key即区分不同的气象数据项（如风速、太阳辐照等）以及标识当前时间点
        '''
        rDate = datetime.date(*map(int, date.split('-')))
        r = request('GET',
                    self._weatherUrl, 
                    params={
                        "locationId": str(locationId),
                        "date": rDate,
                    })
        return json.loads(r.text)
    
    def AddDataItem(self, kind, data, extra=None):
        '''
            向kind类型的数据库中添加内容为data的数据项
            :params: kind str类型，数据的种类标识，包含：光伏、光伏曲线、风机、风机曲线、燃气、燃气曲线、水电、水电曲线、火电、火电曲线、生物质发电、生物质发电曲线、垃圾电厂、垃圾电厂曲线、传输线、变压器、开关、负荷分类、负荷用户、储能设备、储能运行策略、上网电价、输配电价、常数电价、阶梯电价、分时电价、分时阶梯电价
            :params: data dict类型，表示添加的数据内容，其数据结构应满足对应数据项的结构要求
            :params extra list类型，表示添加的基准出力曲线、负荷曲线、策略曲线数据
    
            :return: list<dict>类型，返回该种类下所有数据项的列表
        '''
        if extra is None or not extra:
            curveData = getCurveData(kind)
            if len(curveData) > 0:
                r = {
                    'simu': self.resourceId,
                    'name': data.get('name', ''),
                    'extra': curveData,
                    'data': data.get('data', {}),
                }
                url = f"{self._baseUri}rest/{kind}"
                self._saveItemData(url, r)
                return self._fetchItemData(url)
            else:
                r = {
                    'simu': self.resourceId,
                    'name': data.get('name', ''),
                    'data': data.get('data', {}),
                }
                url = f"{self._baseUri}rest/{kind}"
                self._saveItemData(url, r)
                return self._fetchItemData(url)
        else:
            r = {
                'simu': self.resourceId,
                'name': data.get('name', ''),
                'extra': extra,
                'data': data.get('data', {}),
            }
            url = f"{self._baseUri}rest/{kind}"
            self._saveItemData(url, r)
            return self._fetchItemData(url)

    def DeleteDataItem(self, id, kind):
        '''
            获取kind类型对应所有数据项的列表
            :params: id int类型，数据的id
            :params: kind str类型，数据的种类标识，包含：光伏、光伏曲线、风机、风机曲线、燃气、燃气曲线、水电、水电曲线、火电、火电曲线、生物质发电、生物质发电曲线、垃圾电厂、垃圾电厂曲线、传输线、变压器、开关、负荷分类、负荷用户、储能设备、储能运行策略、上网电价、输配电价、常数电价、阶梯电价、分时电价、分时阶梯电价
    
            :return: list<dict>类型，返回该种类下所有数据项的列表
        '''
        url = f"{self._baseUri}rest/id/{str(id)}"
        self._deleteItemData(url)
        return self._fetchItemData(f"{self._baseUri}rest/{kind}")


    def UpdateDataItem(self, kind, data):
        '''
            更新kind类型对应数据项
            :params: kind str类型，数据的种类标识，包含：光伏、光伏曲线、风机、风机曲线、燃气、燃气曲线、水电、水电曲线、火电、火电曲线、生物质发电、生物质发电曲线、垃圾电厂、垃圾电厂曲线、传输线、变压器、开关、负荷分类、负荷用户、储能设备、储能运行策略、上网电价、输配电价、常数电价、阶梯电价、分时电价、分时阶梯电价
            :params: data dict类型，表示添加的数据内容，其数据结构应满足对应数据项的结构要求
    
            :return: list<dict>类型，返回该种类下所有数据项的列表
        '''
        d = {
            'id': data.get('id', ''),
            'name': data.get('name', ''),
            'data': data.get('data', {}),
        }
        # 调用融合版
        return self.UpdateItem(kind, d)

        
    def GetItemList(self, kind):
        '''
            获取kind类型对应所有数据项的列表
            :params: kind str类型，数据的种类标识，包含：光伏、光伏曲线、风机、风机曲线、燃气、燃气曲线、水电、水电曲线、火电、火电曲线、生物质发电、生物质发电曲线、垃圾电厂、垃圾电厂曲线、传输线、变压器、开关、负荷分类、负荷用户、储能设备、储能运行策略、上网电价、输配电价、常数电价、阶梯电价、分时电价、分时阶梯电价
    
            :return: list<dict>类型，返回该种类下所有数据项的列表
        '''
        url = f"{self._baseUri}rest/{kind}"
        return self._fetchItemData(url)
    
    def GetItemExtra(self, kind, uuid):
        '''
            获取kind类型对应数据项的基准出力曲线、负荷曲线、策略曲线数据
            :params: kind str类型，数据的类型
            :params: uuid str类型，数据的unique id
        '''
        url = f"{self._baseUri}rest/id/{uuid}"
        data = self._fetchItemData(url)
        if data.get('extra', None) is None:
            return None
        return data.get('extra', None).get('data', None)
    
    def UpdateItemExtra(self, kind, data):
        '''
            更新kind类型对应数据项的基准出力曲线、负荷曲线、策略曲线数据
            :params: kind str类型，数据的种类标识，包含：光伏、光伏曲线、风机、风机曲线、燃气、燃气曲线、水电、水电曲线、火电、火电曲线、生物质发电、生物质发电曲线、垃圾电厂、垃圾电厂曲线、传输线、变压器、开关、负荷分类、负荷用户、储能设备、储能运行策略、上网电价、输配电价、常数电价、阶梯电价、分时电价、分时阶梯电价
            :params: data dict类型，表示添加的数据内容，其数据结构应满足对应数据项的结构要求，形如：{'data': {}, 'extra': [], 'id': ""}
    
            :return: list<dict>类型，返回该种类下所有数据项的列表
        '''
        if not data.get('extra'):
            raise ValueError("extra 不能为空，必须包含有效的数据")
        return self.UpdateItem(kind, data, allow_empty_extra=False)

    def UpdateItem(self, kind, data, allow_empty_extra: bool = False):
        '''
            统一处理基础信息(data/name)与曲线(extra)的更新
            :params: kind str 类型，数据种类（如：光伏、风机、负荷用户、...）
            :params: data dict 类型，包含如下字段的任意子集：
                     {
                        'id': str|int,           # 必填
                        'name': str,             # 可选
                        'data': dict,            # 可选
                        'extra': list|dict       # 可选（基准出力/负荷/策略曲线）
                     }
            :params: allow_empty_extra bool，是否允许提交空的 extra（默认 False，即 extra 存在则必须非空）
            :return: list<dict> 当前 kind 下所有数据项
        '''
        if not data or 'id' not in data or not data.get('id'):
            raise ValueError("UpdateItem: 'id' 为必填字段")

        payload = {
            'id': data.get('id')
        }

        if 'name' in data:
            payload['name'] = data.get('name', '')

        if 'data' in data:
            payload['data'] = data.get('data', {})

        if 'extra' in data:
            extra_val = data.get('extra')
            if (extra_val is None or (isinstance(extra_val, (list, dict)) and len(extra_val) == 0)) and not allow_empty_extra:
                raise ValueError("UpdateItem: extra 存在但为空，如需清空请设置 allow_empty_extra=True")
            payload['extra'] = extra_val

        url = f"{self._baseUri}rest/{kind}"
        self._updateItemData(url, payload)
        return self._fetchItemData(url)

    def UpdateAtmosData(self,data):
        '''
            编辑气象数据记录

            :params: record_id int | str 类型，对应气象表的主键 ID
            :params: data dict 类型，表示该条记录完整的数据内容，结构示例：
                    "id": int类型 气象数据记录主键ID
                    "lat": float类型 坐标纬度
                    "lng": float类型 坐标经度
                    "t10m": string类型 表示环境温度（℃）
                    "lwgab_swgdn": string类型 表示太阳辐射强度（W/m²）
                    "tsoil3": string类型 表示土壤温度（℃）
                    "u10m": string类型 距地面10m处东向风速（m/s）
                    "u50m": string类型 距地面50m处东向风速（m/s）
                    "v10m": string类型 距地面10m处北向风速（m/s）
                    "v50m": string类型 距地面50m处北向风速（m/s）
            :return: bool 类型，True 表示更新成功，False 表示后端返回非 2xx
        '''
        record_id = data.get("id")
        if record_id is None or record_id == "":
            raise ValueError("UpdateAtmosData: data 中必须包含非空的 'id' 字段")
        payload = copy.deepcopy(data)
        r = request('PUT',
                    self._weatherUrl,
                    data=json.dumps(payload))
        return r.ok
    
    def UpLoadAtmosData(self, data, locationId=None):
        '''
            上传气象数据

            :param data: list 类型，气象数据列表，每个元素应满足：
                    "lat": string/float 坐标纬度
                    "lng": string/float 坐标经度
                    "date": string类型 表示日期，格式YYYY-MM-DD
                    "time": string类型 表示时间，格式 0 - 60 * 23 的分钟数
                    "t10m": string 类型，环境温度（℃）
                    "lwgab_swgdn": string 类型，太阳辐照（W/m²）
                    "tsoil3": string 类型，土壤温度（℃）
                    "u10m": string 类型，距地面10m处东向风速（m/s）
                    "u50m": string 类型，距地面50m处东向风速（m/s）
                    "v10m": string 类型，距地面10m处北向风速（m/s）
                    "v50m": string 类型，距地面50m处北向风速（m/s）

            :param locationId: int | None，定位点 id；
                    - 若不为 None：直接使用该 id；
                    - 若为 None：根据当前算例是否已有定位点决定后续行为。

            :return: bool，True 表示上传成功
        '''
        if not isinstance(data, list) or not data:
            raise ValueError("UpLoadAtmosData: data 必须是非空 list")

        payload = copy.deepcopy(data)

        if locationId is not None:
            real_location_id = locationId
        else:
            locations = self.LocationGet()

            if not locations:
                first = payload[0]
                lat = first.get('lat')
                lng = first.get('lng')

                self.LocationCreate(
                    name="定位点1",
                    longitude=lng if lng is not None else '113.648906',
                    latitude=lat if lat is not None else '34.734492'
                )

                locations_after = self.LocationGet()
                if not locations_after:
                    raise Exception("UpLoadAtmosData: 自动创建定位点失败，未获取到任何 location")

                real_location_id = locations_after[-1]["id"]
            else:
                ids = [loc.get("id") for loc in locations]
                raise Exception(
                    f"UpLoadAtmosData: 当前算例已存在 {len(locations)} 个定位点，请显式指定 locationId 进行上传，"
                    f"可选 id 列表为: {ids}"
                )

        body = {
            "locationId": real_location_id,
            "data": payload,
        }

        r = request(
            'POST',
            self._weatherUrl,
            data=json.dumps(body)
        )

        return r.ok

        
class DSLabDataManageModel(DataManageModel):
    _baseUri = 'api/dslab/'
    _weatherUrl = 'api/dslab/rest/weather'

