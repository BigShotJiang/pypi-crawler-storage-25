
import logging
logger = logging.getLogger(__name__)

from cloudpss.model.check.environments import getModel
from cloudpss.model.check.evaluator import isExpression
from cloudpss.model.check.scope import Scope
from .utils import evaluateCondition, validateArg, validateExp, validateKey
from mirascript.vm.types.context import create_vm_context,Uninitialized

        
        
        

class DiagramExpressionChecker:
    def __init__(self, document,checker,config=None):
        self.document = document
        self.globalArgs={}
        self.checker=checker
        if config is None:
            currentConfig = document.context["currentConfig"]
            config = document.configs[currentConfig]
        
        parameters = document.revision.parameters
        for group in parameters:
            for param in group['items']:
                key =param['key']
                value = param['value']
                
                self.globalArgs[f'${key}'] = config['args'].get(key, value)
        

    def diagramArgs(self,globalArgs,component=None):
       
        def scopeArgs(key):
            if key == '$$':
                return  self.document
            if key =='$':
                return component
            if component is not None and key in component.args:
                return component.args[key]
            if key in globalArgs:
                return globalArgs[key]
            
            return Uninitialized
        
        return Scope(scopeArgs)
    
    def check(self):
        return self.checkDiagram(self.document.revision.implements.diagram)
    def checkComponentEnabled(self,component,diagramArgs):
        if hasattr(component,'props') is False or component['props'] is None:
            component['props'] = {'enabled':True}
        
        enabledCheck = validateExp(component['props'].get('enabled',True),diagramArgs)
        
        if 'error' in enabledCheck:
            self.checker.addProblem(f"组件'{component}'的enabled表达式错误: {enabledCheck['error']}",'error')
           
        
        component['props']['enabled'] = enabledCheck['value']  if 'error' not in enabledCheck else True
        
        return component['props']['enabled']
        
        
        
    def checkComponent(self, component,key,globalArgs):
        # Placeholder for actual component checking logic
        # For now, we assume all components are valid
        diagramArgs = self.diagramArgs(self.globalArgs,component)
        
        compDef =getModel(component.definition)
        
        
        if compDef is None:
            self.checker.addProblem(f"组件'{key}'引用的模型'{component.definition}'不存在",'error')
            return False
        
        enabled = self.checkComponentEnabled(component, diagramArgs)
        
        
        parameters = compDef['revision']['parameters']
        for ig in parameters:
            for definition in ig['items']:
                akey = definition['key']
                
                arg = component.args.get(akey,None)
                if(arg is None):
                    component.args[akey] = definition.get('value',None)
                    continue
                
                ret = validateArg(arg,diagramArgs,definition)
                logger.info(f"组件'{key}'参数'{akey}' 值 {arg} 验证结果: {ret}")
                if 'error' in ret:
                    self.checker.addProblem(f"组件'{key}'参数'{akey}' 的表达式' {  arg['source'] if isinstance(arg, dict) and 'source' in arg else arg}' 错误: {ret['error']}",'error')
                else:
                    component.args[akey] = ret['value']
        
        
        pins = compDef['revision']['pins']
        
        pinsDef ={}
        for pin in pins:
            pinsDef[pin['key']] = pin
            if pin['key'] not in component.pins:
                component.pins[pin['key']] =''
            
        for key,pin in  component.pins.items():
            if key not in pinsDef:
                self.checker.addProblem(f"组件'{key}'的引脚'{key}'在模型'{component.definition}'中未定义",'error')
                del component.pins[key]
                continue
            valid = evaluateCondition(pinsDef[key]['condition'],diagramArgs)
            value = component.pins[key]
            result = validateExp(value,diagramArgs)
            if 'error' in result:
                self.checker.addProblem(f"组件'{key}'引脚'{key}'表达式错误: {result['error']}",'error' )
            elif valid is False:
                component.pins[key] = ''
            else:
                component.pins[key] = result['value']
                
                

        return True
    
    def checkDiagram(self, diagram):
        # Placeholder for actual diagram checking logic
        # For now, we assume all diagrams are valid
        variables = diagram.variables
        vKeys = []
        args = self.globalArgs 
        for var in variables:
            k = validateKey(var['key'],True,f"全局变量的变量名'{var}'",self.document)
            if not k[0]:
                self.checker.addProblem(k[1],'error')
            
            vK =f"${k[1]}"
            
            if vK in args:
                if vK in self.globalArgs:
                    self.checker.addProblem(f"全局变量的变量名'{var}'与参数名冲突",'error')
                else:
                    self.checker.addProblem(f"全局变量的变量名'{var}'重复定义",'error')
            args[vK] = var['value']
            vKeys.append(vK)
            
        diagramArgs = self.diagramArgs(args)
        variables=[]
        for key in vKeys:
            val = args[key]
            ret = validateExp(val,diagramArgs)
            logger.info(f"全局变量'{key}' 值 {val} 验证结果: {ret}")
            if 'error' in ret:
                self.checker.addProblem(f"全局变量'{key}'表达式错误: {ret['error']}",'error')
            else:
                args[key] = ret['value']
                variables.append({'key':key,'value':ret['value']})
            
            
        for cellKey,cell in diagram.cells.items():
            
            if cell is None:
                continue
            shape = cell.shape
            if shape =='diagram-component' or shape =='diagram-component-edge':
            
                self.checkComponent(cell,cellKey,diagramArgs)
        return True