


from .evaluator import Evaluator,isExpression
import logging
logger = logging.getLogger(__name__)

import traceback
evaluator = Evaluator()
ExpressionTag = 'ɵexp'

def Expression(value,returnType=''):
    if value is None:
        raise Exception("Expression value cannot be None")

    s =value['source'] if isExpression(value) else str(value)
    
    return {ExpressionTag: returnType,
            'source': s }
    

def validateKey(key,unicode,messageKey,data):
    """

    """
    
    k = key.strip()
    if k =='':
        return False,f"{messageKey} 不能为空"
    
    regex = r'^[^\W\d]\w*$' if unicode else r'^[_a-z]\w*$'
    import re   
    if not re.match(regex, k):
        return False,f"{messageKey} 只能包含字母、数字和下划线，且不能以数字开头"
    
    
    return True,k


def validateExp(exp,scope):
    try:
        v= evaluator.evaluate(exp,scope)
        return {'value':v}
    except Exception as e:
        return {'error':str(e)}
    
def validateArg(expression,scope,definition):
  
    if expression is None:
        return {'value':definition.value}
    
    try:
        v = evaluator.evaluateArg(expression,scope,definition)
        return {'value':v}
    except Exception as e:
        logger.debug(f"Error validating argument: {traceback.format_exc()}")
        return {'error':str(e)}
    
    
def evaluateCondition(expression,scope,default=True):
    try:
        
        v= evaluator.evaluateCondition(expression,scope,default)
        return v
    except Exception as e:
        logger.debug(f"Error evaluating condition: {traceback.format_exc()}")
        return default