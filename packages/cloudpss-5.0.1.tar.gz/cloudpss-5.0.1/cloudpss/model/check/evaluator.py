from mirascript import compile
ExpressionTag = 'ɵexp'
def isExpression(value):
    if value is None or( not isinstance(value,dict) and not callable(value)  ):
        return False
    return ExpressionTag in value and isinstance(value[ExpressionTag], str)


def parse(expression):
    complied= compile(expression)
    
    return complied[0]

class Evaluator:
    
    
    def evaluate(self,expression,scope,defaults=None):
        
        if expression is None or expression =='':
            return defaults

        if callable(expression):
            return expression(scope)
        if not isExpression(expression):
            return expression
        
        ret = self.evaluateSource(expression['source'],scope,defaults)
        
        if ret is None:
            return defaults
        
        
        return ret
    
    def evaluateSource(self,expression,scope,defaults):
       if expression is None or expression =='':
           return defaults
       if not isinstance(expression,str):
           return expression
       value = parse(expression)
       return value(scope)
    
    def evaluateCondition(self,condition,scope,default=True):
        if condition is None or condition =='':
            return default
        if isinstance(condition,bool):
            return condition
        if condition=='true':
            return True
        if condition=='false':
            return False
        
        try:
            result = self.evaluateSource(condition,scope,default)
            if isinstance(result,bool):
                return result
            raise Exception("Condition did not evaluate to a boolean")
        except Exception as e:
            print(f"Error evaluating condition: {e}")
            return default
        
    def evaluateArg(self,arg,scope,definition):
        if arg is None:
            arg= definition.get('value',None)
        
        ret =self.evaluate(arg,scope,definition.get('value',None))
        
        return ret