"""
并查集（Disjoint Set Union）及从边映射计算连通分量的实现（由 TypeScript 翻译）

原文件: src/topology/gen/union-find.ts
"""
from typing import Dict, Iterable, List, Mapping, Set


class DSU:
    def __init__(self) -> None:
        self.parent: Dict[str, str] = {}
        self.rank: Dict[str, int] = {}

    def make_set(self, x: str) -> None:
        if x not in self.parent:
            self.parent[x] = x
            self.rank[x] = 0

    def find(self, x: str) -> str:
        self.make_set(x)
        p = self.parent[x]
        if p != x:
            self.parent[x] = self.find(p)
        return self.parent[x]

    def union(self, a: str, b: str) -> None:
        ra = self.find(a)
        rb = self.find(b)
        if ra == rb:
            return

        rka = self.rank.get(ra, 0)
        rkb = self.rank.get(rb, 0)

        if rka < rkb:
            self.parent[ra] = rb
        elif rka > rkb:
            self.parent[rb] = ra
        else:
            self.parent[rb] = ra
            self.rank[ra] = rka + 1

    def groups(self) -> Dict[str, Set[str]]:
        g: Dict[str, Set[str]] = {}
        for node in list(self.parent.keys()):
            root = self.find(node)
            if root not in g:
                g[root] = set()
            g[root].add(node)
        return g


def connected_components_from_edge_map(adj) -> Dict[str, Set[str]]:
    """
    根据 edgeId -> [u, v, ...] 的映射计算连通分量。

    参数:
        adj: 映射，键为 edgeId，值为端点的可迭代对象

    返回:
        root -> set(nodes) 的字典
    """
    dsu = DSU()

    for edge_id, endpoints in adj.items():
        dsu.make_set(edge_id)
        if not isinstance(endpoints, (list, tuple)) or len(endpoints) == 0:
            continue
        # 保持与原 TS 实现一致的合并顺序
        dsu.union(edge_id, list(endpoints)[0])
        for node in endpoints:
            dsu.union(edge_id, node)

    return dsu.groups()


__all__ = ["DSU", "connected_components_from_edge_map"]
