

from .scope import Scope
from .union_find import connected_components_from_edge_map
from .utils import evaluateCondition, validateExp,Expression
from .environments import getModel
from mirascript.vm.types.context import Uninitialized

def isTerminalCellData(data):
    if data is None:
        return False
    if 'cell' not in data:
        return False
    return isinstance(data['cell'], str) 

class DiagramChecker:
    """
    A class to check the validity of diagram objects in CloudPSS.

    Methods
    -------
    diagramChecker(diagram)
        Check the validity of a diagram object.
    """
    
    components= {}  # Placeholder for component mapping if needed in future.
    edges= {}       # Placeholder for edge mapping if needed in future.
    lineGroup={}
    def __init__(self,model,diagram,checker,config=None):
        self.model = model
        self.diagram = diagram
        cells = diagram.cells
        self.checker=checker
        if config is None:
            currentConfig = model.context["currentConfig"]
            config = model.configs[currentConfig]
        self.globalArgs=config
        self.portGroup=set()
        self.pinDefinitions={}
        
        variables = diagram.variables
        for var in variables:
            self.globalArgs[var['key']] = var['value']
        
        
        for key,cell in cells.items():
            if cell is None:
                continue
            shape = cell.shape
            if shape is None:
                continue
            if shape.startswith('diagram-component'):
                compDef = getModel(cell['definition'])
                compEnabled=  cell.props.get('enabled',True) if hasattr(cell,'props') and cell['props'] is not None else True
                self.components[key] = [cell, compDef,compEnabled]
            if shape.endswith('-edge'):
                self.edges[key] = cell

    def addTerminalNode(self,key,terminalEnd,terminal):
        
        self.lineGroup[key] =[] if self.lineGroup.get(key,None) is None else self.lineGroup[key]
        
        
        if terminal['cell'] in self.edges:
            self.lineGroup[key].append(terminal['cell'])
            return True
        
        c = self.components.get(terminal['cell'],None)
        if c is  None:
            if terminal['cell'] not in self.diagram.cells:
                self.checker.addProblem(f"边'{key}'的 '{terminalEnd}' 端点连接到不存在的组件'{terminal['cell']}'",'error')
            
            return False
        
        [comp, compDef, compEnabled] = c
        if compDef is None:
            return False
        for pinDef in compDef['revision']['pins']:
            if pinDef['key'] == terminal['port']:
                break
       
       
        if pinDef is None:
            self.checker.addProblem(f"边'{ key }'的 '{terminalEnd}' 端点连接到组件'{terminal['cell']}'不存在的端口'{terminal['port']}'",'error')
            return False
        self.lineGroup[key].append(f'{terminal["cell"]}.pins.{terminal["port"]}')
        
        
        
            
    def checkEdge(self):
        for edgeId,edge in self.edges.items():
            
            if isTerminalCellData(edge['source']) is False:
                self.checker.addProblem(f"边'{edgeId}'的 source 悬空") 
            else:
                self.addTerminalNode(edgeId, 'source', edge['source'])
            if isTerminalCellData(edge['target']) is False:
                self.checker.addProblem(f"边'{edgeId}'的 target 悬空")
            else:
                self.addTerminalNode(edgeId, 'target', edge['target'])
                
    
    
    def scope(self,comp,component=None):
       
        def scopeArgs(key):
            if key == '$$':
                return  self.document
            if key =='$':
                return comp
            if component is not None and key in component.args:
                return component.args[key]
            
            if key.startswith('$'):
                gKey = key[1:]
                if gKey in self.globalArgs:
                    return self.globalArgs[gKey]
            
            
            
            return comp.args.get(key,Uninitialized)
        
        return Scope(scopeArgs)
    def checkerConnection(self):
        c = connected_components_from_edge_map(self.lineGroup)
        connectionInfo=[]
        connectionTypeMap={}
        
        for root,nodes in c.items():
            connectionInfo.append([])
            connectionTypeMap[len(connectionInfo)-1]={
                "output":0,
                "input":0,
                "electrical":0,            
                '':0                      
            }
            dim=None
            dimError={'x':[],'y':[]}
            hasZeroDimX=False
            hasZeroDimY=False
            for node in nodes:
                pinDef = self.pinDefinitions.get(node,None)
                if pinDef is  None:
                    continue
                if dim is None:
                    dim = pinDef.get('dim',None)
                else:
                    nextDim = pinDef.get('dim',None)
                    if dim[0] ==0 or nextDim[0] ==0:
                        hasZeroDimX =True
                    if dim[1] ==0 or nextDim[1] ==0:
                        hasZeroDimY =True
                    if dim[0] != nextDim[0]:
                        dimError['x'].append(f"引脚节点 '{node}' X 维度 {nextDim[0]} 与其他引脚维度不相等 {dim[0]}")
                    if dim[1] != nextDim[1]:
                        dimError['y'].append(f"引脚节点 '{node}' Y 维度 {nextDim[1]} 与其他引脚维度不相等 {dim[1]}")
                        
                
                connectionInfo[-1].append(node)
                connectionTypeMap[len(connectionInfo)-1][pinDef.get('connection','')] +=1
                self.portGroup.remove(node)
                
            if hasZeroDimX is False:
                for err in dimError['x']:
                    self.checker.addProblem(err,'error')
            if hasZeroDimY is False:
                for err in dimError['y']:
                    self.checker.addProblem(err,'error')
                
                
        for idx,nodes in enumerate(connectionInfo):
            if len(nodes) <=1:
                self.checker.addProblem(f"当前引脚节点 {', '.join(nodes)} 只连接到单个端点，未形成有效连接",'error')
            
            if connectionTypeMap[idx]['output'] >1:
                self.checker.addProblem(f"当前引脚节点 {', '.join(nodes)} 存在多个输出端口，连接冲突",'error')
                continue
            if connectionTypeMap[idx]['output'] >0 and connectionTypeMap[idx]['electrical'] >0:
                self.checker.addProblem(f"当前引脚节点 {', '.join(nodes)} 同时存在输出端口和电气端口，连接冲突",'error')
                continue
            if connectionTypeMap[idx]['input'] >0 and connectionTypeMap[idx]['electrical'] ==0 and connectionTypeMap[idx]['output'] ==0:
                self.checker.addProblem(f"当前引脚节点 {', '.join(nodes)} 悬空，无信号输入",'error')
                continue
            if connectionTypeMap[idx]['electrical'] >0 and connectionTypeMap[idx]['input'] >0:
                self.checker.addProblem(f"当前引脚节点 {', '.join(nodes)} 同时存在输入端口和电气端口，此时输入信号为当前节点电压（单位：V）")
                continue
            
        
        
        for port in self.portGroup:
            componentPath = port.split('.')[0]
            component = self.components.get(componentPath,None)
            if component is None:
                continue
            if component[0].definition == 'model/CloudPSS/GND':
                continue
            pinDef = self.pinDefinitions.get(port,None)
            if pinDef is None:
                continue
            if pinDef.get('connection','electrical') =='output':
                continue
            self.checker.addProblem(f"端口 '{port}' 悬空",'error')
    
    def evalPinDim(self,dim,scope):
        if dim is None:
            return [0,0]
        dimX =dim[0]
        dimY =dim[1]
        rX = validateExp(Expression(dimX),scope)
        rY = validateExp(Expression(dimY),scope)
        
        
        if 'error' in rX:
            self.checker.addProblem(f"引脚X维度表达式错误: {rX['error']}",'error')
            dimX =0
        else:
            dimX = rX['value']
            
        if 'error' in rY:
            self.checker.addProblem(f"引脚Y维度表达式错误: {rY['error']}",'error')
            dimY =0
        else:
            dimY = rY['value']
        if int(dimX) <0:
            self.checker.addProblem(f"引脚X维度不能为负值: {dimX}",'error')
        
        if int(dimY) <0:
            self.checker.addProblem(f"引脚Y维度不能为负值: {dimY}",'error')
            
        if dimX != int(dimX):
            self.checker.addProblem(f"引脚X维度必须为整数: {dimX}",'error')
            dimX = int(dimX)
        if dimY != int(dimY):
            self.checker.addProblem(f"引脚Y维度必须为整数: {dimY}",'error')
            dimY = int(dimY)
            
        return [int(dimX),int(dimY)]
    
    def check(self):
        self.checkEdge()
        
        for compId,[comp, compDef,compEnabled] in self.components.items():
            
            if compDef is None:
                self.checker.addProblem(f"组件'{compId}'引用的模型'{comp['definition']}'不存在",'error')
                continue
            scope = self.scope(comp)
            for pg in compDef['revision']['parameters']:
                validGroup=None
                for pp in pg['items']:
                    pinKey = pp['key']
                    if pp['type'] != 'pinLike':
                        continue
                    pinName = comp.args.get(pp['key'],None)
                    pinPath = f'{compId}.args.{pinKey}'
                    self.portGroup.add(pinPath)
                    pp['dim'] = self.evalPinDim(pp.get('dim',None),scope)
                    self.pinDefinitions[pinPath]=pp
                    if not pinName:
                        continue
                    
                    if validGroup is None:
                        validGroup = evaluateCondition(pg.get('condition',True), scope)
                        
                    if compEnabled is False:
                        continue
                    
                    
                    self.lineGroup[pinName] =[] if self.lineGroup.get(pinName,None) is None else self.lineGroup[pinName]
                    self.lineGroup[pinName].append(pinPath)    
                    
            pinsDef = compDef['revision']['pins']
            for pinDef in pinsDef:
                pinKey = pinDef['key']
                pinName = comp.pins.get(pinKey,None)
                pinPath = f'{compId}.pins.{pinKey}'
                pinCond = evaluateCondition(pinDef.get('condition',True), scope)
                if pinCond is False:
                    continue
                
                self.portGroup.add(pinPath)
                pinDef['dim'] = self.evalPinDim(pinDef.get('dim',None),scope)   
                self.pinDefinitions[pinPath]=pinDef
                if not pinName:
                    continue
                
                if compEnabled is False:
                    continue
                
                
                self.lineGroup[pinName] =[] if self.lineGroup.get(pinName,None) is None else self.lineGroup[pinName]
                self.lineGroup[pinName].append(pinPath) 
                    
                    
                    
        self.checkerConnection()
        
        
    
def diagramChecker(model,config,checker):
    
    checker = DiagramChecker(model, model.revision.implements.diagram,checker,config) 
    return checker