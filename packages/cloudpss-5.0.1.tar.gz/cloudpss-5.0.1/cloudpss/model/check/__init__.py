



from cloudpss.model.check.diagram import diagramChecker
from cloudpss.model.check.diagramExpressionChecker import DiagramExpressionChecker
from cloudpss.model.check.environments import loadModels
from cloudpss.model.model import Model
import copy 
import os

class Checker:
    _COLOR_RED = "\033[31m"
    _COLOR_YELLOW = "\033[33m"
    _COLOR_RESET = "\033[0m"

    def __init__(self,model,job=None,config=None):
        self.model = Model(copy.deepcopy(model.toJSON()))
        self.job = job
        self.config = config
        self.problems = []

    def _use_color(self):
        if os.environ.get("NO_COLOR"):
            return False
        return True
        
    def addProblem(self,problem,level='warning'):
        self.problems.append({
                              "problem": problem,
                              "level": level
                              })
    
    def updateEnvironment(self):
        
        cells = self.model.getAllComponents()
        rids = set()
        for key,cell in cells.items():
            rid = getattr(cell,'definition',None)
            if rid is None:
                continue
            
            rids.add(rid)
        loadModels(rids)
        
    def diagramExpressionChecker(self):
        """
        检查拓扑表达式是否合法
        """
        checker = DiagramExpressionChecker(self.model,self,self.config)
        checker.check()
           
        
        return True

    def diagramChecker(self):
        """
        检查拓扑结构是否合法
        """
        checker =diagramChecker(self.model,self.config,self)
        checker.check()
        return True
    
    def check(self):
        if self.model.revision.getImplements().getDiagram() is None:
            return True
        
        self.updateEnvironment()
        
        self.diagramExpressionChecker()
        self.diagramChecker()
        
        if len(self.problems) ==0:
            return True
        
        for p in self.problems:
            if p['level'] == 'error':
                if self._use_color():
                    print(f"{self._COLOR_RED}[错误] {p['problem']}{self._COLOR_RESET}")
                else:
                    print(f"[错误] {p['problem']}")
            else:
                if self._use_color():
                    print(f"{self._COLOR_YELLOW}[警告] {p['problem']}{self._COLOR_RESET}")
                else:
                    print(f"[警告] {p['problem']}")
        return False