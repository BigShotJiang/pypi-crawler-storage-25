
from cloudpss.utils import graphql_request 
env ={
    "models":{},
    "policies":[],
    "functions":{},
}


def loadModels(rids):    
    """
    Load all models into the global environment.
    """
    m =""
    i =0
    for rid in rids:
        i +=1
        m += f'node{i}:model(input:{{ rid:"{rid}" }} ){{...model}}'
    
    query = f"fragment model on Model {{ rid  name tags description  revision{{ implements pins parameters }}}} query {{ {m} }}"
    models = graphql_request(query,{})['data']
    

    for _,modelData in models.items():
        model = modelData
        env["models"][model['rid']] = model
    

def getModel(rid):
    """
    Retrieve the environment for a specific model.

    Parameters
    ----------
    rid : str
        The name of the model.

    Returns
    -------
    dict
        The environment dictionary for the specified model.
    """
    return env["models"].get(rid, None)
