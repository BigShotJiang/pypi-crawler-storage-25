from mirascript.vm.types.context import create_vm_context
from cloudpss.model.check.evaluator import isExpression, parse
class Scope:
    
    def __init__(self,scope):
        self.scope = create_vm_context(scope)
    
    def reset(self,evaluator):
        self.evaluator = evaluator
    
    def get(self,key,default=None):
        
        scope =self.scope
        
        if callable(scope):
            v= scope(key)
        else:
            v= scope.get(key)
        if not isExpression(v):
            return v
        
        return self.eval(v,[key])
   
    
    def eval(self,expression,path):
        
        try:
            if(callable(expression)):
                result = expression(self)
            else:
                exp = parse(expression['source'])
                result = exp(self)
            return result
        except Exception as e:
            raise Exception(f"Error evaluating expression at {'.'.join(path)}: {e}")