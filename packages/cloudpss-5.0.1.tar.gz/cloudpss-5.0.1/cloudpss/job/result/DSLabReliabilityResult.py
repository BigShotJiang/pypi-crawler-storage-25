import pandas as pd
from .result import Result

class DSLabReliabilityResult(Result):
    
    def __init__(self, receiver, sender = None):
        super().__init__(receiver, sender)
        self.table_msg = None
    
    def _process_id(self, ids):        
        return [id.split(' ')[2].split('\"')[1].split('/')[1] for id in ids]
    
    def getIndexTableByName(self, name):
        """
            获取指定 type 的消息数据

            :params type: 表名称

            :returns: 对应 type 的数据字典

            >>> message= db.getIndexTableByName('系统可靠性指标')
        """
          
        result = {}
        if self.table_msg is None:
            self.table_msg = self.getMessagesByType('table')
        for val in self.table_msg:
            if val.get('key', None) == name:
                for col_dict in val['data']['columns']:
                    if col_dict.get('name', None) in ['系统可靠性指标（英文名）', '值', '故障率(次/年)','平均故障持续时间(小时/次）','故障持续时间(小时/年)']:
                        result[col_dict['name']] = col_dict['data'] # [0]
                    elif col_dict['name'] ==  '负荷':
                        result[col_dict['name']] = self._process_id(col_dict['data'])   # [0]
        return result
    
    def getLoadIndicesByID(self, id):
        """
            获取指定 负荷 的消息数据

            :params id: 负荷id

            :returns: 对应 id 的数据字典
            
            >>> message= db.getLoadIndexByID('component_load_1')
        """
        
        # b = self.getIndexTableByName('负荷可靠性指标')
        # a = pd.DataFrame(self.getIndexTableByName('负荷可靠性指标'))
        df = pd.DataFrame(data=self.getIndexTableByName('负荷可靠性指标')).set_index('负荷')
        
        return df.loc[id].to_dict()

