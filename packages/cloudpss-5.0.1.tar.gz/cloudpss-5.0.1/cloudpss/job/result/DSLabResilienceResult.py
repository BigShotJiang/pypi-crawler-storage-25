# from cloudpss.job.result.result import Result
from .result import Result

class DSLabResilienceResult(Result):
    
    def __init__(self, receiver, sender = None):
        super().__init__(receiver, sender)
        self.table_msg = None
    
    def _process_id(self, ids):        
        return [id.split(' ')[2].split('\"')[1].split('/')[1] for id in ids]
    
    def getTableByName(self, name):
        """
            获取指定 type 的消息数据

            :params type: 表名称

            :returns: 对应 type 的数据字典
            
            >>> message= r.getTableByName('系统时序故障概率')
        """
          
        result = {}
        if self.table_msg is None:
            self.table_msg = self.getMessagesByType('table')
        for val in self.table_msg:
            if val.get('key', None) == name:
                for col_dict in val['data']['columns']:
                    if 'name' not in col_dict:
                        continue
                    elif col_dict['name'] in ['分配设备','故障设备','设备ID']:
                        result[col_dict['name']] = self._process_id(col_dict['data'])   # [0]
                    else:
                        result[col_dict['name']] = col_dict['data']
        return result

