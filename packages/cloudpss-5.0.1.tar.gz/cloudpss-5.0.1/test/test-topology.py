import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
import cloudpss
import time
import numpy as np
import json

if __name__ == '__main__':
    os.environ['CLOUDPSS_API_URL'] = 'http://10.101.10.42/'
    print('CLOUDPSS connected')
    cloudpss.setToken(
        'eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidXNlcm5hbWUiOiJhZG1pbiIsInNjb3BlcyI6WyJicm93c2VyIl0sInR5cGUiOiJicm93c2VyIiwiZXhwIjoxNzc2NDIzODExLCJpYXQiOjE3NzM3NDU0MTF9.U7rBhaNes1JF6CvyaE4eMDs6dwTxTYqa_kZAaTW70gikWUal7pQBpwx7S53y7nhmjxM8ISxwMsc-QWW_wJId_g')
    print('Token done')
    project = cloudpss.Model.fetch('model/admin/adfw123')
    
    topology = project.fetchTopology(config={'args':{}},maximumDepth=10)




    topology.dump(topology,'test.json')
    
    
    