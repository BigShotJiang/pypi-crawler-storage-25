from ast import mod
import sys,os

sys.path.append(os.path.join(os.path.dirname(__file__), '../'))
import cloudpss # 引入 cloudpss 依赖
import json
import time
__models_query="""query($input:ModelsInput!){models(input:$input){cursor total count items{rid name description owner tags updatedAt revision{ parameters pins documentation}}}}"""
def fetchMany(name=None, cursor=[], pageSize=10,owner=None,tags=None,**kwargs):
    if owner is None:
        owner = cloudpss.verify.userName()
    elif owner == "*":
        owner = None
    variables = {
        "cursor": cursor,
        "limit": pageSize,
        "orderBy": [
            "updatedAt<",
            "type",
            "owner",
            "key"
        ],
        "owner":owner,
        "tags": tags
    }
    if name is not None:
        variables["_search"] = name

    data = cloudpss.utils.graphql_request(__models_query, {"input": variables},**kwargs)
    if "errors" in data:
        raise Exception(data["errors"][0]["message"])
    return data["data"]["models"]['items']

if __name__ == '__main__':
    
    # 申请 token 
    cloudpss.setToken('eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidXNlcm5hbWUiOiJhZG1pbiIsInNjb3BlcyI6WyJtb2RlbDo5ODM2NyIsImZ1bmN0aW9uOjk4MzY3IiwiYXBwbGljYXRpb246MzI4MzEiXSwicm9sZXMiOlsiYWRtaW4iXSwidHlwZSI6ImFwcGx5IiwiZXhwIjoxNzk0MzE5MDUwLCJub3RlIjoidGVzdC1ydCIsImlhdCI6MTc2MzIxNTA1MH0.BgWaHXf1Zoy6THILV44RYY21xKjhFh-O5MyYSK6nOpqvEVRus8kpfL4sow26yrM4UAAe-boZ_J7zOqiygYYxqg')

    # 设置目标 API 地址（可选，默认地址为 https://cloudpss.net/ ）
    os.environ['CLOUDPSS_API_URL'] = 'http://10.109.10.31/'
    
    
    
    models = fetchMany(pageSize=999999,owner='*',tags='project-category:component')
    print(f'获取算例项目列表成功，项目总数：{models}')
    # x=[]
    
    
    
    filter_component=  [ {'name': m['name'], 'rid': m['rid'],"documentation": m['revision']['documentation']}  for m in models ] # 根据组件标签过滤出包含虚拟输入单元组件的算例项目
    
    print(f'包含虚拟输入单元组件的算例项目列表：{filter_component}')