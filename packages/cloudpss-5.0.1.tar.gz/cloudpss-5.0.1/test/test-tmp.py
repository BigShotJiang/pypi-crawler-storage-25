temps=[
    "model/open-cloudpss/Zero_Current_Protection-v1b1",
    "model/open-cloudpss/Distance_Protection-v1b1",
    "model/open-cloudpss/Pilot_Protection-v1b1",
    "model/open-cloudpss/Current_Protection-v1b1",
    "model/open-cloudpss/Zero_Voltage_Protection-v1b1",
    "model/open-cloudpss/Compound_Voltage_Over_Current_Protection-v1b1",
    "model/open-cloudpss/Reclose-v1b1",
    "model/open-cloudpss/HVDC_Hybrid_HI-fdm-std-v1b3",
    "model/open-cloudpss/HVDC_Hybrid_MT-fdm-std-v1b3",
    "model/open-cloudpss/HVDC_MMC_WF-fdm-std-v1b2",
    "model/open-cloudpss/HVDC_MMC_MT-fdm-std-v1b2",
    "model/open-cloudpss/HVDC_LCC_MT-fdm-std-v1b2",
    "model/open-cloudpss/HVDC_LCC_HI-fdm-std-v1b2",
    "model/open-cloudpss/HVDC_MMC_HI-fdm-std-v1b2",
    "model/open-cloudpss/HVDC_LCC_BP-fdm-std-v1b2",
    "model/open-cloudpss/HVDC_MMC_BP-fdm-std-v1b2",
    "model/open-cloudpss/HVDC_LCC_SP-fdm-std-v1b2",
    "model/open-cloudpss/HVDC_MMC_SP-fdm-std-v1b2",
    "model/open-cloudpss/PVS_01-avm-std-v1b2",
    "model/open-cloudpss/PVS_01-fdm-std-v1b2",
    "model/open-cloudpss/PVS_01-avm-stdm-v1b5",
    "model/open-cloudpss/WTG_DFIG_01-avm-stdm-v1b5",
    "model/open-cloudpss/WTG_DFIG_01-fdm-std-v1b3",
    "model/open-cloudpss/WTG_DFIG_01-avm-std-v1b3",
    "model/open-cloudpss/WTG_PMSG_01-avm-stdm-v2b5",
    "model/open-cloudpss/WTG_PMSG_01-avm-std-v2b2",
    "model/open-cloudpss/WTG_PMSG_01-fdm-std-v2b2",
    "model/open-cloudpss/WTG_PMSG_01-avm-std-v1b2",
    "model/open-cloudpss/WTG_PMSG_01-fdm-std-v1b2",
    "model/open-cloudpss/CSEE_PFO_Continuous-v1b1",
    "model/open-cloudpss/CSEE_PFO_Temporary-v1b1",
    "model/open-cloudpss/CSEE_VS_CLV-v1b1",
    "model/open-cloudpss/CSEE_VS_VC-v1b1",
    "model/open-cloudpss/CSEE_FS-v1b1",
    "model/open-cloudpss/CSEE_RAS_Periodic-v1b1",
    "model/open-cloudpss/CSEE_RAS_Aperiodic-v1b1",
    "model/open-cloudpss/IEEE_118_BUS-v1b1",
    "model/open-cloudpss/IEEE_39_BUS-v1b1",
    "model/open-cloudpss/IEEE_30_BUS-v1b1",
    "model/open-cloudpss/IEEE_14_BUS-v1b1",
    "model/open-cloudpss/WSCC_9_BUS-v1b1",
    "model/open-cloudpss/KUNDUR_TWO_AREA-v1b1",
    "model/CloudPSS/ieee39-ssc-demo",
    "model/CloudPSS/SubstationCase",
    "model/CloudPSS/HVDC800",
    "model/CloudPSS/HVDC_PN_12",
    "model/CloudPSS/HVDC_PN_D12",
    "model/CloudPSS/HVDC_P_D12",
    "model/CloudPSS/HVDC_P_12",
    "model/CloudPSS/HLM",
    "model/CloudPSS/HTModule",
    "model/CloudPSS/HBridgeModule",
    "model/CloudPSS/HalfBridgeModule",
    "model/CloudPSS/3HM",
    "model/CloudPSS/IEEE39",
    "model/CloudPSS/IEEE3",
    "model/CloudPSS/DFIG_AVM",
    "model/CloudPSS/Blank_Octave_Components",
    "model/CloudPSS/MMC_Benchmark",
    "model/CloudPSS/PV_Averaged_Detailed",
    "model/CloudPSS/PV_Averaged",
    "model/CloudPSS/PV_Detailed",
    "model/CloudPSS/Bat_Averaged_Detailed",
    "model/CloudPSS/Bat_Averaged",
    "model/CloudPSS/Bat_Detailed",
    "model/CloudPSS/ACDCHybridCase",
    "model/CloudPSS/DemoCase",
    "model/CloudPSS/CHPCase",
    "model/CloudPSS/DC_MICROGRID",
    "model/CloudPSS/NPCmodule",
    "model/CloudPSS/NSSTs",
    "model/CloudPSS/B2BModule",
    "model/CloudPSS/DC_Motor",
    "model/CloudPSS/Asyn_Motor",
    "model/CloudPSS/FESS",
    "model/CloudPSS/Blank_Component",
    "model/CloudPSS/Blank_IESModel",
    "model/CloudPSS/Blank_Common",
    "model/CloudPSS/Blank_Simple"
]

import logging
import sys, os
import time


sys.path.append(os.path.join(os.path.dirname(__file__), "..\\"))

import cloudpss
import time
if __name__ == "__main__":
    cloudpss.setToken(
        'eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidXNlcm5hbWUiOiJhZG1pbiIsInNjb3BlcyI6WyJtb2RlbDo5ODM2NyIsImZ1bmN0aW9uOjk4MzY3IiwiYXBwbGljYXRpb246MzI4MzEiXSwicm9sZXMiOlsiYWRtaW4iXSwidHlwZSI6ImFwcGx5IiwiZXhwIjoxODA5NDUwNTMzLCJub3RlIjoiYSIsImlhdCI6MTc3ODM0NjUzM30.mJ-rF4Kc1ZwoXJHrC3QuwXS3KBBJ3_Z2xZCLtmTwdKlnf8eaasaRIakrzgppISEwjRqwxi0OCqpnA1og_kKPzA'
    )
    os.environ["CLOUDPSS_API_URL"] = "http://10.101.10.46/"
    for temp in temps:
        print(temp)
        model = cloudpss.Model.fetch(temp)
        
        runner = model.run()
        while not runner.status():
            time.sleep(1)

        logs= runner.result.getLogs()
        for log in logs:
            print(log)
        print("end")