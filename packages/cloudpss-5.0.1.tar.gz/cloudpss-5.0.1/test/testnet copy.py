import networkx as nx
G = nx.Graph()

edges =[
  {
    "source": "2800000000337977285",
    "target": "2800000000337977285_pole",
  },
  {
    "source": "2800000000337958142",
    "target": "2800000000337958142_pole",
  },
  {
    "source": "2800000000337963079",
    "target": "2800000002008028653",
  },
  {
    "source": "2800000000337977420",
    "target": "2800000000337951028",
  },
  {
    "source": "2800000002008028661",
    "target": "2800000000337898342",
  },
  {
    "source": "2800000000337898342",
    "target": "2800000000337970280",
  },
  {
    "source": "2800000000337940029",
    "target": "2800000000337940029_pole",
  },
  {
    "source": "2800000000337976126",
    "target": "2800000000337976126_pole",
  },
  {
    "source": "2800000000337936280",
    "target": "2800000000337901702",
  },
  {
    "source": "2800000000130449370",
    "target": "2800000000129704341",
  },
  {
    "source": "2800000002002393089",
    "target": "2800000002002393093",
  },
  {
    "source": "2800000000047690404",
    "target": "2800000000047690404_pole",
  },
  {
    "source": "2800000000129689347",
    "target": "2800000000129689347_pole",
  },
  {
    "source": "2800000000130566962",
    "target": "2800000000129704341",
  },
  {
    "source": "2800000000047688892",
    "target": "2800000000047688892_pole",
  },
  {
    "source": "2800000000337977607",
    "target": "2800000000337977607_pole",
  },
  {
    "source": "2800000000337977521",
    "target": "2800000000337977521_pole",
  },
  {
    "source": "2800000000337977475",
    "target": "2800000000337977475_pole",
  },
  {
    "source": "2800000000337965065",
    "target": "2800000000337965065_pole",
  },
  {
    "source": "2800000002008028653",
    "target": "2800000000337963075",
  },
  {
    "source": "2800000000337951028",
    "target": "2800000000047690402",
  },
  {
    "source": "2800000000337951028",
    "target": "2800000000337977326",
  },
  {
    "source": "2800000000337951028",
    "target": "2800000000337977285",
  },
  {
    "source": "2800000000337977241",
    "target": "2800000000337951028",
  },
  {
    "source": "2800000002002393099",
    "target": "2800000002002393099_pole",
  },
  {
    "source": "2800000002002393096",
    "target": "2800000002002393096_pole",
  },
  {
    "source": "2800000002002393118",
    "target": "2800000002002393118_pole",
  },
  {
    "source": "2800000002002393094",
    "target": "2800000002002393096",
  },
  {
    "source": "2800000002002393099",
    "target": "2800000002002393082",
  },
  {
    "source": "2800000000129915578",
    "target": "2800000000129915578_pole",
  },
  {
    "source": "2800000000129935134",
    "target": "2800000000129935134_pole",
  },
  {
    "source": "2800000000130585577",
    "target": "2800000000130585577_pole",
  },
  {
    "source": "2800000000130583451",
    "target": "2800000000130583451_pole",
  },
  {
    "source": "2800000000130583451",
    "target": "2800000000130581791",
  },
  {
    "source": "2800000000160398456",
    "target": "2800000000160398456_pole",
  },
  {
    "source": "2800000000047688892",
    "target": "2800000002002393082",
  },
  {
    "source": "2800000000337905189",
    "target": "2800000000337905189_pole",
  },
  {
    "source": "2800000000337970005",
    "target": "2800000000337970005_pole",
  },
  {
    "source": "2800000000337970280",
    "target": "2800000000337970280_pole",
  },
  {
    "source": "2800000000337970324",
    "target": "2800000000337970324_pole",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000129704341_pole",
  },
  {
    "source": "2800000002002393093",
    "target": "2800000002002393118",
  },
  {
    "source": "2800000002002393082",
    "target": "2800000002002393091",
  },
  {
    "source": "2800000000337940028",
    "target": "2800000000337901702",
  },
  {
    "source": "2800000000375934275",
    "target": "2800000000337901702",
  },
  {
    "source": "2800000000337901702",
    "target": "2800000000337937496",
  },
  {
    "source": "2800000000337901702",
    "target": "2800000000337976218",
  },
  {
    "source": "2800000000337976126",
    "target": "2800000000337901702",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000129915578",
  },
  {
    "source": "2800000000130362522",
    "target": "2800000000129704341",
  },
  {
    "source": "2800000000130386321",
    "target": "2800000000129704341",
  },
  {
    "source": "2800000000337906136",
    "target": "2800000002008028655",
  },
  {
    "source": "2800000000337940028",
    "target": "2800000000337940028_pole",
  },
  {
    "source": "2800000000129684551",
    "target": "2800000000129684551_pole",
  },
  {
    "source": "2800000000130583451",
    "target": "2800000002008028641",
  },
  {
    "source": "2800000002002393087",
    "target": "2800000002002393089",
  },
  {
    "source": "2800000000129686282",
    "target": "2800000000129686282_pole",
  },
  {
    "source": "2800000000130380286",
    "target": "2800000000130380286_pole",
  },
  {
    "source": "2800000000337977365",
    "target": "2800000000337977365_pole",
  },
  {
    "source": "2800000000337977241",
    "target": "2800000000337977241_pole",
  },
  {
    "source": "2800000000337953026",
    "target": "2800000000337953026_pole",
  },
  {
    "source": "2800000000337952963",
    "target": "2800000000337952963_pole",
  },
  {
    "source": "2800000000337965064",
    "target": "2800000000337965064_pole",
  },
  {
    "source": "2800000000337977365",
    "target": "2800000000337951028",
  },
  {
    "source": "2800000000337898342",
    "target": "2800000000337898342_pole",
  },
  {
    "source": "2800000000337970125",
    "target": "2800000000337970125_pole",
  },
  {
    "source": "2800000000047690404",
    "target": "2800000000337898342",
  },
  {
    "source": "2800000000337970681",
    "target": "2800000000337898342",
  },
  {
    "source": "2800000002002393082",
    "target": "2800000002002393082_pole",
  },
  {
    "source": "2800000000160400117",
    "target": "2800000000160400117_pole",
  },
  {
    "source": "2800000000337901702",
    "target": "2800000000337976171",
  },
  {
    "source": "2800000000337976265",
    "target": "2800000000337901702",
  },
  {
    "source": "2800000000337901702",
    "target": "2800000000337910229",
  },
  {
    "source": "2800000000375932952",
    "target": "2800000000357867476",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000130377025",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000130383782",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000130417562",
  },
  {
    "source": "2800000000337951315",
    "target": "2800000000337901702",
  },
  {
    "source": "2800000000337906131",
    "target": "2800000000337906132",
  },
  {
    "source": "2800000002008028655",
    "target": "2800000000337906132",
  },
  {
    "source": "2800000000129686714",
    "target": "2800000000129684552",
  },
  {
    "source": "2800000000130586344",
    "target": "2800000002008028643",
  },
  {
    "source": "2800000000047690402",
    "target": "2800000000047690402_pole",
  },
  {
    "source": "2800000000337977646",
    "target": "2800000000337977646_pole",
  },
  {
    "source": "2800000000337977420",
    "target": "2800000000337977420_pole",
  },
  {
    "source": "2800000002008028647",
    "target": "2800000000344560160",
  },
  {
    "source": "2800000000337963075",
    "target": "2800000000337963075_pole",
  },
  {
    "source": "2800000000130367903",
    "target": "2800000000130367903_pole",
  },
  {
    "source": "2800000000337951028",
    "target": "2800000000337952963",
  },
  {
    "source": "2800000002002393093",
    "target": "2800000002002393093_pole",
  },
  {
    "source": "2800000000130446730",
    "target": "2800000000130446730_pole",
  },
  {
    "source": "2800000000337940028",
    "target": "2800000000337940029",
  },
  {
    "source": "2800000002008028667",
    "target": "2800000000337940033",
  },
  {
    "source": "2800000000337901702",
    "target": "2800000000337901702_pole",
  },
  {
    "source": "2800000002008028669",
    "target": "2800000000337901702",
  },
  {
    "source": "2800000000375934275",
    "target": "2800000000375934275_pole",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000130367903",
  },
  {
    "source": "2800000000337906131",
    "target": "2800000000337906131_pole",
  },
  {
    "source": "2800000000129684552",
    "target": "2800000000129684552_pole",
  },
  {
    "source": "2800000000337977560",
    "target": "2800000000337977560_pole",
  },
  {
    "source": "2800000000337965145",
    "target": "2800000000337965145_pole",
  },
  {
    "source": "2800000000337977646",
    "target": "2800000000337951028",
  },
  {
    "source": "2800000000337965064",
    "target": "2800000000337951028",
  },
  {
    "source": "2800000000337951028",
    "target": "2800000000337977521",
  },
  {
    "source": "2800000000337951028",
    "target": "2800000000337977475",
  },
  {
    "source": "2800000000047688890",
    "target": "2800000000047688890_pole",
  },
  {
    "source": "2800000002002393093",
    "target": "2800000000047688890",
  },
  {
    "source": "2800000000337965064",
    "target": "2800000000337965065",
  },
  {
    "source": "2800000002002393094",
    "target": "2800000002002393094_pole",
  },
  {
    "source": "2800000000130362522",
    "target": "2800000000130362522_pole",
  },
  {
    "source": "2800000000130377025",
    "target": "2800000000130377025_pole",
  },
  {
    "source": "2800000000130585315",
    "target": "2800000000130585577",
  },
  {
    "source": "2800000000130578771",
    "target": "2800000000130566732",
  },
  {
    "source": "2800000000375934275",
    "target": "2800000000337938873",
  },
  {
    "source": "2800000002002393089",
    "target": "2800000002002393089_pole",
  },
  {
    "source": "2800000002008028647",
    "target": "2800000000337965065",
  },
  {
    "source": "2800000000047688890",
    "target": "2800000000047688890_pole",
  },
  {
    "source": "2800000000130386321",
    "target": "2800000000130386321_pole",
  },
  {
    "source": "2800000002008028657",
    "target": "2800000002008028661",
  },
  {
    "source": "2800000000337970681",
    "target": "2800000000337970681_pole",
  },
  {
    "source": "2800000000337898342",
    "target": "2800000000337970324",
  },
  {
    "source": "2800000000337970005",
    "target": "2800000000337898342",
  },
  {
    "source": "2800000000337905189",
    "target": "2800000000337898342",
  },
  {
    "source": "2800000000130449370",
    "target": "2800000000130449370_pole",
  },
  {
    "source": "2800000002002393082",
    "target": "2800000002002393094",
  },
  {
    "source": "2800000002008028667",
    "target": "2800000000337940029",
  },
  {
    "source": "2800000000337901702",
    "target": "2800000000375942239",
  },
  {
    "source": "2800000000337981483",
    "target": "2800000000375942239",
  },
  {
    "source": "2800000000337937496",
    "target": "2800000000337937496_pole",
  },
  {
    "source": "2800000000337936280",
    "target": "2800000000337936280_pole",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000129935134",
  },
  {
    "source": "2800000000337901702",
    "target": "2800000000047690404",
  },
  {
    "source": "2800000000129688164",
    "target": "2800000000129684551",
  },
  {
    "source": "2800000000129684551",
    "target": "2800000000129689347",
  },
  {
    "source": "2800000000129686714",
    "target": "2800000000129686714_pole",
  },
  {
    "source": "2800000000130585315",
    "target": "2800000000129704341",
  },
  {
    "source": "2800000002002393093",
    "target": "2800000002002393096",
  },
  {
    "source": "2800000000337963074",
    "target": "2800000000337963074_pole",
  },
  {
    "source": "2800000000337963074",
    "target": "2800000000337951028",
  },
  {
    "source": "2800000000337951028",
    "target": "2800000000337965145",
  },
  {
    "source": "2800000000337956986",
    "target": "2800000000337951028",
  },
  {
    "source": "2800000002008028659",
    "target": "2800000000337898342",
  },
  {
    "source": "2800000000337898342",
    "target": "2800000000337970125",
  },
  {
    "source": "2800000000337910229",
    "target": "2800000000337910229_pole",
  },
  {
    "source": "2800000000129936776",
    "target": "2800000000129704341",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000130365212",
  },
  {
    "source": "2800000000130446730",
    "target": "2800000000129704341",
  },
  {
    "source": "2800000000129688164",
    "target": "2800000000129688164_pole",
  },
  {
    "source": "2800000002008028643",
    "target": "2800000000130585577",
  },
  {
    "source": "2800000000130584297",
    "target": "2800000002008028641",
  },
  {
    "source": "2800000000130581791",
    "target": "2800000000129704341",
  },
  {
    "source": "2800000000129688164",
    "target": "2800000000129686714",
  },
  {
    "source": "2800000002002393085",
    "target": "2800000002002393085_pole",
  },
  {
    "source": "2800000000337951315",
    "target": "2800000000337951028",
  },
  {
    "source": "2800000000337977326",
    "target": "2800000000337977326_pole",
  },
  {
    "source": "2800000000337956986",
    "target": "2800000000337956986_pole",
  },
  {
    "source": "2800000000337963075",
    "target": "2800000000337963074",
  },
  {
    "source": "2800000000337977560",
    "target": "2800000000337951028",
  },
  {
    "source": "2800000000337953026",
    "target": "2800000000337951028",
  },
  {
    "source": "2800000000337951028",
    "target": "2800000000337977607",
  },
  {
    "source": "2800000000337958142",
    "target": "2800000000337951028",
  },
  {
    "source": "2800000002002393091",
    "target": "2800000002002393091_pole",
  },
  {
    "source": "2800000000130566962",
    "target": "2800000000130566962_pole",
  },
  {
    "source": "2800000000047688892",
    "target": "2800000000047688892_pole",
  },
  {
    "source": "2800000002002393087",
    "target": "2800000000160398456",
  },
  {
    "source": "2800000000129936776",
    "target": "2800000000129936776_pole",
  },
  {
    "source": "2800000000130383782",
    "target": "2800000000130383782_pole",
  },
  {
    "source": "2800000002008028649",
    "target": "2800000000129704341",
  },
  {
    "source": "2800000000337898342",
    "target": "2800000000130745194",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000130745194",
  },
  {
    "source": "2800000000130390322",
    "target": "2800000000130390322_pole",
  },
  {
    "source": "2800000002002393087",
    "target": "2800000002002393087_pole",
  },
  {
    "source": "2800000000129684552",
    "target": "2800000000129686282",
  },
  {
    "source": "2800000002002393085",
    "target": "2800000000160400117",
  },
  {
    "source": "2800000000337965145",
    "target": "2800000000337965145_pole",
  },
  {
    "source": "2800000000130365212",
    "target": "2800000000130365212_pole",
  },
  {
    "source": "2800000000375932952",
    "target": "2800000000129704341",
  },
  {
    "source": "2800000000130417562",
    "target": "2800000000130417562_pole",
  },
  {
    "source": "2800000002002393099",
    "target": "2800000002002393085",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000129704341_pole",
  },
  {
    "source": "2800000000337970213",
    "target": "2800000000337970213_pole",
  },
  {
    "source": "2800000000337970213",
    "target": "2800000000337898342",
  },
  {
    "source": "2800000000047688890",
    "target": "2800000000047690402",
  },
  {
    "source": "2800000000047688892",
    "target": "2800000000047690404",
  },
  {
    "source": "2800000000337976171",
    "target": "2800000000337976171_pole",
  },
  {
    "source": "2800000000337976265",
    "target": "2800000000337976265_pole",
  },
  {
    "source": "2800000000337976218",
    "target": "2800000000337976218_pole",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000130380286",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000130390322",
  },
  {
    "source": "2800000000129684552",
    "target": "2800000000129684552_pole",
  },
  {
    "source": "2800000000047690404",
    "target": "2800000000047690404_pole",
  },
  {
    "source": "2800000000337906132",
    "target": "2800000000337906132_pole",
  },
  {
    "source": "2800000000337898342",
    "target": "2800000000337906131",
  },
  {
    "source": "2800000000129704341",
    "target": "2800000000129686282",
  },
  {
    "source": "2800000000130566732",
    "target": "2800000000130566962",
  },
]

val = [(edge["source"], edge["target"]) for edge in edges]
G.add_edges_from(val)


def _ccw(a, b, c):
  return (c[1] - a[1]) * (b[0] - a[0]) > (b[1] - a[1]) * (c[0] - a[0])


def _segments_intersect(p1, p2, p3, p4):
  return _ccw(p1, p3, p4) != _ccw(p2, p3, p4) and _ccw(p1, p2, p3) != _ccw(p1, p2, p4)


def count_edge_crossings(graph, pos):
  edge_list = list(graph.edges())
  cross = 0
  for i, (u1, v1) in enumerate(edge_list):
    p1, p2 = pos[u1], pos[v1]
    for u2, v2 in edge_list[i + 1:]:
      if len({u1, v1, u2, v2}) < 4:
        continue
      if _segments_intersect(p1, p2, pos[u2], pos[v2]):
        cross += 1
  return cross


def total_edge_length(graph, pos):
  total = 0.0
  for u, v in graph.edges():
    x1, y1 = pos[u]
    x2, y2 = pos[v]
    dx = x1 - x2
    dy = y1 - y2
    total += (dx * dx + dy * dy) ** 0.5
  return total


def build_community_layout(graph):
  communities = list(nx.community.greedy_modularity_communities(graph))
  if not communities:
    return None, {}

  cluster_id = {n: i for i, c in enumerate(communities) for n in c}
  cluster_graph = nx.Graph()
  cluster_graph.add_nodes_from(range(len(communities)))

  for u, v in graph.edges():
    cu = cluster_id[u]
    cv = cluster_id[v]
    if cu == cv:
      continue
    if cluster_graph.has_edge(cu, cv):
      cluster_graph[cu][cv]["weight"] += 1
    else:
      cluster_graph.add_edge(cu, cv, weight=1)

  center_pos = nx.spring_layout(cluster_graph, seed=42, weight="weight", k=2.8)

  # 强制簇中心保持最小间距，避免两个簇贴得太近
  min_dist = 2.4
  for _ in range(60):
    moved = False
    ids = list(center_pos.keys())
    for i in range(len(ids)):
      for j in range(i + 1, len(ids)):
        a = ids[i]
        b = ids[j]
        ax, ay = center_pos[a]
        bx, by = center_pos[b]
        dx = bx - ax
        dy = by - ay
        dist = (dx * dx + dy * dy) ** 0.5
        if dist == 0:
          dx, dy, dist = 1e-6, 0.0, 1e-6
        if dist < min_dist:
          moved = True
          push = (min_dist - dist) / 2
          ux = dx / dist
          uy = dy / dist
          center_pos[a] = (ax - ux * push, ay - uy * push)
          center_pos[b] = (bx + ux * push, by + uy * push)
    if not moved:
      break

  pos = {}
  for i, comm in enumerate(communities):
    subg = graph.subgraph(comm)
    sub_pos = nx.spring_layout(subg, seed=7, k=0.8 / (len(comm) ** 0.5))
    cx, cy = center_pos[i]
    # 簇规模越大，内部铺开越大，防止视觉挤压
    scale = max(1.6, (len(comm) ** 0.5) * 0.65)
    spread = 11.0
    for n, (x, y) in sub_pos.items():
      pos[n] = (cx * spread + x * scale, cy * spread + y * scale)

  return pos, cluster_id


candidate_layouts = []
for seed in (7, 17, 42, 77):
  candidate_layouts.append(
    (
      f"spring_seed_{seed}",
      nx.spring_layout(G, seed=seed, k=1.3 / (len(G.nodes()) ** 0.5), iterations=300),
      None,
    )
  )

if G.number_of_nodes() > 1:
  candidate_layouts.append(("kamada_kawai", nx.kamada_kawai_layout(G), None))

community_pos, community_cluster_id = build_community_layout(G)
if community_pos:
  candidate_layouts.append(("community_hybrid", community_pos, community_cluster_id))

best_name = None
best_pos = None
best_cluster = None
best_score = None

for name, layout_pos, cluster in candidate_layouts:
  score = (count_edge_crossings(G, layout_pos), total_edge_length(G, layout_pos))
  if best_score is None or score < best_score:
    best_name = name
    best_pos = layout_pos
    best_cluster = cluster
    best_score = score

if best_cluster is None:
  components = list(nx.connected_components(G))
  best_cluster = {n: i for i, c in enumerate(components) for n in c}

import matplotlib.pyplot as plt

print(f"selected_layout={best_name}, crossings={best_score[0]}, total_edge_len={best_score[1]:.2f}")

colors = [best_cluster[n] for n in G.nodes()]
nx.draw_networkx_nodes(G, best_pos, node_color=colors, cmap=plt.cm.Set3, node_size=220)
nx.draw_networkx_edges(G, best_pos, alpha=0.75, width=1.2, edge_color="#666666")
nx.draw_networkx_labels(G, best_pos, font_size=6)
plt.axis("off")
plt.tight_layout()
plt.show()