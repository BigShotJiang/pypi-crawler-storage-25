from ast import mod
import sys,os

sys.path.append(os.path.join(os.path.dirname(__file__), '../'))
import cloudpss # 引入 cloudpss 依赖
import json
import time


if __name__ == '__main__':
    
    # 申请 token 
    cloudpss.setToken('eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwidXNlcm5hbWUiOiJhZG1pbiIsInNjb3BlcyI6WyJtb2RlbDo5ODM2NyIsImZ1bmN0aW9uOjk4MzY3IiwiYXBwbGljYXRpb246MzI4MzEiXSwicm9sZXMiOlsiYWRtaW4iXSwidHlwZSI6ImFwcGx5IiwiZXhwIjoxODA2MDU0Njk2LCJub3RlIjoiYXMiLCJpYXQiOjE3NzQ5NTA2OTZ9.viWd2waydVwkYmZckLVvFvMwzgZk0dXv0hOgiPoSsNWxtD-AW3CicjD7rDyvrf81vSsOUB-QimwyPAkS4Ud7RA')

    # 设置目标 API 地址（可选，默认地址为 https://cloudpss.net/ ）
    os.environ['CLOUDPSS_API_URL'] = 'http://10.101.10.170/'
    
    job =cloudpss.currentJob() # 获取当前计算任务对象
    print('当前计算任务状态:',job.args,flush=True) # 输出当前计算任务状态
    runJobid = job.args['runJobid'] # 获取当前计算任务的 runJobid 参数

    runner = cloudpss.Job.fetch(runJobid)

    while not runner.status(): 
        mLen = runner.result.getMessageLength()
        if mLen > 0:
            for _ in range(mLen):
                log = runner.result.pop() # 实时的日志两比较大，需要将日志及时从缓存中弹出，否则会占用大量内存
                # job.print(log) # 输出日志到计算任务的日志中，可以在云平台的计算任务日志界面查看输出结果
                # print(log,flush=True) # 输出日志到控制台，可以查看日志内容
                if log.get('key','')=='table-1':
                    # print(log,flush=True) #输出日志
                    job.print(log) # 输出日志到计算任务的日志中，可以在云平台的计算任务日志界面查看输出结果
        time.sleep(0.01) # 本测试例为快速循环等待，实际应用
        
