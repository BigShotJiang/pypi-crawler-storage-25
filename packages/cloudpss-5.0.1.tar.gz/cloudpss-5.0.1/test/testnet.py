import networkx as nx
from edges import edges
G = nx.Graph()


val = [(edge["source"], edge["target"]) for edge in edges]
G.add_edges_from(val)


def _ccw(a, b, c):
  return (c[1] - a[1]) * (b[0] - a[0]) > (b[1] - a[1]) * (c[0] - a[0])


def _segments_intersect(p1, p2, p3, p4):
  return _ccw(p1, p3, p4) != _ccw(p2, p3, p4) and _ccw(p1, p2, p3) != _ccw(p1, p2, p4)


def count_edge_crossings(graph, pos):
  edge_list = list(graph.edges())
  cross = 0
  for i, (u1, v1) in enumerate(edge_list):
    p1, p2 = pos[u1], pos[v1]
    for u2, v2 in edge_list[i + 1:]:
      if len({u1, v1, u2, v2}) < 4:
        continue
      if _segments_intersect(p1, p2, pos[u2], pos[v2]):
        cross += 1
  return cross


def total_edge_length(graph, pos):
  total = 0.0
  for u, v in graph.edges():
    x1, y1 = pos[u]
    x2, y2 = pos[v]
    dx = x1 - x2
    dy = y1 - y2
    total += (dx * dx + dy * dy) ** 0.5
  return total


def small_cluster_hierarchical_layout(subg):
  if subg.number_of_nodes() == 0:
    return {}
  if subg.number_of_nodes() == 1:
    n = next(iter(subg.nodes()))
    return {n: (0.0, 0.0)}

  final_pos = {}
  y_offset = 0.0

  for comp_nodes in nx.connected_components(subg):
    comp = subg.subgraph(comp_nodes).copy()
    if comp.number_of_nodes() == 1:
      n = next(iter(comp.nodes()))
      final_pos[n] = (0.0, y_offset)
      y_offset += 1.5
      continue

    root = max(comp.degree, key=lambda item: item[1])[0]
    levels = dict(nx.single_source_shortest_path_length(comp, root))
    nx.set_node_attributes(comp, levels, "subset")
    comp_pos = nx.multipartite_layout(comp, subset_key="subset", align="vertical", scale=1.0)

    ys = [float(v[1]) for v in comp_pos.values()]
    min_y = min(ys)
    max_y = max(ys)
    comp_height = (max_y - min_y) + 1.0

    for n, (x, y) in comp_pos.items():
      final_pos[n] = (float(x), float(y) + y_offset)

    y_offset += comp_height + 1.2

  return final_pos


def build_community_layout(graph):
  communities = list(nx.community.greedy_modularity_communities(graph))
  if not communities:
    return None, {}

  cluster_id = {n: i for i, c in enumerate(communities) for n in c}
  cluster_graph = nx.Graph()
  cluster_graph.add_nodes_from(range(len(communities)))

  for u, v in graph.edges():
    cu = cluster_id[u]
    cv = cluster_id[v]
    if cu == cv:
      continue
    if cluster_graph.has_edge(cu, cv):
      cluster_graph[cu][cv]["weight"] += 1
    else:
      cluster_graph.add_edge(cu, cv, weight=1)

  center_pos = nx.spring_layout(cluster_graph, seed=42, weight="weight", k=2.8)

  # 强制簇中心保持最小间距，避免两个簇贴得太近
  min_dist = 2.4
  for _ in range(60):
    moved = False
    ids = list(center_pos.keys())
    for i in range(len(ids)):
      for j in range(i + 1, len(ids)):
        a = ids[i]
        b = ids[j]
        ax, ay = center_pos[a]
        bx, by = center_pos[b]
        dx = bx - ax
        dy = by - ay
        dist = (dx * dx + dy * dy) ** 0.5
        if dist == 0:
          dx, dy, dist = 1e-6, 0.0, 1e-6
        if dist < min_dist:
          moved = True
          push = (min_dist - dist) / 2
          ux = dx / dist
          uy = dy / dist
          center_pos[a] = (ax - ux * push, ay - uy * push)
          center_pos[b] = (bx + ux * push, by + uy * push)
    if not moved:
      break

  pos = {}
  for i, comm in enumerate(communities):
    subg = graph.subgraph(comm)
    if len(comm) <= 12:
      sub_pos = small_cluster_hierarchical_layout(subg)
    else:
      sub_pos = nx.spring_layout(subg, seed=7, k=0.8 / (len(comm) ** 0.5))
    cx, cy = center_pos[i]
    # 簇规模越大，内部铺开越大，防止视觉挤压
    scale = max(1.6, (len(comm) ** 0.5) * 0.65)
    spread = 11.0
    for n, (x, y) in sub_pos.items():
      pos[n] = (cx * spread + x * scale, cy * spread + y * scale)

  return pos, cluster_id


candidate_layouts = []
for seed in (7, 17, 42, 77):
  candidate_layouts.append(
    (
      f"spring_seed_{seed}",
      nx.spring_layout(G, seed=seed, k=1.3 / (len(G.nodes()) ** 0.5), iterations=300),
      None,
    )
  )

if G.number_of_nodes() > 1:
  candidate_layouts.append(("kamada_kawai", nx.kamada_kawai_layout(G), None))

community_pos, community_cluster_id = build_community_layout(G)
if community_pos:
  candidate_layouts.append(("community_hybrid", community_pos, community_cluster_id))

best_name = None
best_pos = None
best_cluster = None
best_score = None

for name, layout_pos, cluster in candidate_layouts:
  score = (count_edge_crossings(G, layout_pos), total_edge_length(G, layout_pos))
  if best_score is None or score < best_score:
    best_name = name
    best_pos = layout_pos
    best_cluster = cluster
    best_score = score

if best_cluster is None:
  components = list(nx.connected_components(G))
  best_cluster = {n: i for i, c in enumerate(components) for n in c}

import matplotlib.pyplot as plt

print(f"selected_layout={best_name}, crossings={best_score[0]}, total_edge_len={best_score[1]:.2f}")

colors = [best_cluster[n] for n in G.nodes()]
nx.draw_networkx_nodes(G, best_pos, node_color=colors, cmap=plt.cm.Set3, node_size=220)
nx.draw_networkx_edges(G, best_pos, alpha=0.75, width=1.2, edge_color="#666666")
nx.draw_networkx_labels(G, best_pos, font_size=6)
plt.axis("off")
plt.tight_layout()
plt.show()