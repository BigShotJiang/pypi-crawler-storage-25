"""
Rotunda version constants.
"""


class CONSTRAINTS:
    """
    The minimum and maximum supported versions of the Rotunda browser.
    """

    MIN_VERSION = 'alpha.1'
    MAX_VERSION = '1'

    @staticmethod
    def as_range() -> str:
        """
        Returns the version range as a string.
        """
        return f">={CONSTRAINTS.MIN_VERSION}, <{CONSTRAINTS.MAX_VERSION}"
