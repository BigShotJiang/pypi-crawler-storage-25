# rmsafe

A modern `rm` replacement that moves files to trash instead of deleting them.

[English](README.md) | [中文](README_CN.md)

## Install

```bash
# Homebrew
brew tap leftrk/rmsafe
brew install rmsafe

# pip / uv
pip install git+https://github.com/leftrk/rmsafe.git
uv tool install git+https://github.com/leftrk/rmsafe.git
```

## Usage

Replace `rm` in your shell:

```bash
alias rm='rmsafe trash'
```

### Commands

| Command | Description |
|---------|-------------|
| `rmsafe trash <files>` | Move files to trash |
| `rmsafe restore <pattern>` | Restore trashed files |
| `rmsafe list [pattern]` | List trashed files |
| `rmsafe undo [n]` | Undo recent deletions |
| `rmsafe undo --list` | Show undo history |
| `rmsafe empty [days]` | Empty trash |
| `rmsafe status` | Trash statistics |

### Examples

```bash
rmsafe trash file.txt              # Move to trash
rmsafe trash *.log --dry-run       # Preview
rmsafe restore file.txt            # Restore
rmsafe undo                        # Undo last deletion
rmsafe undo --list                 # Show history table
rmsafe empty 7                     # Delete files older than 7 days
rmsafe status                      # Panel with stats
```

## Features

- **Rich output**: Tables, panels, icons, progress bars
- **Undo history**: Track and undo recent deletions
- **Smart UX**: Progress bar for batch operations, transient cleanup
- **Cross-platform**: macOS (`~/.Trash`), Linux (FreeDesktop Trash spec)
- **Btrfs optimized**: Zero-copy reflink clone on Linux
- **JSONC config**: Comments and trailing commas supported

## Config

`~/.config/rmsafe/config.jsonc`:

```jsonc
{
  "trash": { "location": null, "auto_clean_days": 30 },
  "behavior": { "confirm_large_files": "10MB", "undo_history_limit": 100 },
  "output": { "color": "auto", "icons": true }
}
```

## vs trash-cli

| Feature | rmsafe | trash-cli |
|---------|--------|-----------|
| Output | Rich tables/icons | Plain text |
| Undo history | Built-in | Limited |
| Progress bar | Yes (≥4 files) | No |
| Config format | JSONC | INI |
| Btrfs clone | Yes | No |

## Development

```bash
git clone https://github.com/leftrk/rmsafe.git
cd rmsafe
uv sync --dev
uv run pytest  # 1030 tests
```

See [CONTRIBUTING.md](CONTRIBUTING.md) for details.

## License

MIT