"""Typer-based CLI for rmsafe."""

# pyright: reportMissingImports=false

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from . import __version__
from .commands import empty, list_command, restore, status, trash, undo
from .config.loader import load_config
from .output.colors import ColorManager


app = typer.Typer(add_completion=False, help="Safe trash management for files.")


def _build_context(
    dry_run: bool,
    verbose: bool,
    color: str,
    config: Optional[Path],
    confirm_large: Optional[str],
) -> dict[str, object]:
    overrides: dict[str, object] = {"output": {"color": color, "verbose": verbose}}
    if confirm_large is not None:
        overrides["behavior"] = {"confirm_large_files": confirm_large}
    loaded = load_config(overrides, config_file=config)
    manager = ColorManager(color_setting=loaded.output.color)
    return {
        "config": loaded,
        "colors": manager,
        "dry_run": dry_run,
        "verbose": verbose,
        "color": color,
    }


@app.callback(invoke_without_command=True, context_settings={"allow_extra_args": True, "ignore_unknown_options": False})
def root(
    ctx: typer.Context,
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing."),
    verbose: bool = typer.Option(False, "--verbose", help="Show detailed output."),
    color: str = typer.Option("auto", "--color", help="Color mode: always, never, auto."),
    config: Optional[Path] = typer.Option(None, "--config", help="Path to config file."),
    confirm_large: Optional[str] = typer.Option(None, "--confirm-large", help="Large file confirmation threshold."),
    no_confirm: bool = typer.Option(False, "--no-confirm", help="Skip confirmation prompts."),
    version: bool = typer.Option(False, "--version", help="Show version and exit."),
) -> None:
    """Root command. Defaults to trash when files are provided."""

    if version:
        typer.echo(f"rmsafe {__version__}")
        raise typer.Exit()

    ctx.obj = _build_context(dry_run=dry_run, verbose=verbose, color=color, config=config, confirm_large=confirm_large)
    ctx.obj["no_confirm"] = no_confirm

    if ctx.invoked_subcommand is None and ctx.args:
        trash.run([Path(arg) for arg in ctx.args], ctx.obj)
    elif ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())


@app.command("trash")
def trash_command(
    files: Annotated[list[Path], typer.Argument(help="Files to trash.")],
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing."),
    verbose: bool = typer.Option(False, "--verbose", help="Show detailed output."),
    color: str = typer.Option("auto", "--color", help="Color mode: always, never, auto."),
    config: Optional[Path] = typer.Option(None, "--config", help="Path to config file."),
    confirm_large: Optional[str] = typer.Option(None, "--confirm-large", help="Large file confirmation threshold."),
    no_confirm: bool = typer.Option(False, "--no-confirm", help="Skip confirmation prompts."),
) -> None:
    """Trash files."""

    ctx = _build_context(dry_run=dry_run, verbose=verbose, color=color, config=config, confirm_large=confirm_large)
    ctx["no_confirm"] = no_confirm
    trash.run(files, ctx)


trash_command.__name__ = "trash"


@app.command("restore")
def restore_command(
    pattern: Annotated[Optional[str], typer.Argument(help="Pattern to restore.")] = None,
    to: Optional[Path] = typer.Option(None, "--to", help="Restore to a specific destination."),
) -> None:
    restore.run(pattern, to=to)


@app.command("list")
def list_command_cmd(
    pattern: Annotated[Optional[str], typer.Argument(help="Pattern to filter trash.")] = None,
    sort: str = typer.Option("time", "--sort", help="Sort by size or time."),
) -> None:
    list_command.run(pattern, sort=sort)


list_command_cmd.__name__ = "list"


@app.command("undo")
def undo_command(
    n: Annotated[Optional[int], typer.Argument(help="Number of deletions to undo.")] = None,
    list_only: bool = typer.Option(False, "--list", help="Show recent undo history."),
) -> None:
    undo.run(n, list_only=list_only)


@app.command("empty")
def empty_command(
    days: Annotated[Optional[int], typer.Argument(help="Days before emptying trash.")] = None,
    force: bool = typer.Option(False, "--force", help="Skip confirmation prompt."),
) -> None:
    empty.run(days, force=force)


@app.command("status")
def status_command() -> None:
    status.run()


def main_entry() -> None:
    """Console script entry point."""

    app()


def main() -> None:
    """Compatibility entry point for project scripts."""

    app()
