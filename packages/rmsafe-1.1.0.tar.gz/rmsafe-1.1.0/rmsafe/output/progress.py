"""Progress bar helpers for rmsafe - transient progress with completion summary."""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn

from .colors import ColorManager
from .icons import IconManager


# Threshold: show progress bar only for 4+ files
PROGRESS_THRESHOLD = 4


def should_show_progress(files: Sequence[Path]) -> bool:
    """Return True if progress bar should be shown (>=4 files)."""
    return len(files) >= PROGRESS_THRESHOLD


def create_progress_bar(colors: ColorManager, icons: IconManager) -> Progress:
    """Create a transient progress bar for trash operations.

    Uses transient=True so progress bar disappears after completion,
    leaving only the final summary.
    """
    return Progress(
        SpinnerColumn(style="cyan"),
        TextColumn("[cyan]{task.fields[filename]:<30}"),
        BarColumn(complete_style="green", finished_style="green"),
        TextColumn("[dim]{task.completed}/{task.total}[/]"),
        transient=True,
        console=colors.console,
    )


def format_summary(count: int, total_bytes: int, colors: ColorManager, icons: IconManager) -> str:
    """Format completion summary shown after progress bar finishes."""
    from ..utils.size import format_size

    size_text = format_size(total_bytes)
    files_text = f"{count} file{'s' if count != 1 else ''}"

    # Build summary with icon
    icon = icons.success()
    return f"{icon}Trashed {files_text}, freed {size_text}"


__all__ = ["should_show_progress", "create_progress_bar", "format_summary", "PROGRESS_THRESHOLD"]