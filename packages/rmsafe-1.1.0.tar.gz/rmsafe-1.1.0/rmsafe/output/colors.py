"""Color output management for rmsafe."""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING

from ..utils.tty import should_use_color

if TYPE_CHECKING:
    from rich.console import Console


class Color(str, Enum):
    """Standard colors used by rmsafe output."""

    INFO = "cyan"
    SUCCESS = "green"
    WARNING = "yellow"
    ERROR = "red"
    HIGHLIGHT = "magenta"


def get_console(color_setting: str = "auto") -> Console:
    """Return a Rich console configured for the requested color mode."""

    from rich.console import Console

    use_color = should_use_color(color_setting)
    return Console(force_terminal=use_color, no_color=not use_color)


class ColorManager:
    """Wrapper around :class:`rich.console.Console` with color control."""

    def __init__(self, color_setting: str = "auto") -> None:
        self.color_setting = color_setting
        self.console = get_console(color_setting)

    def print(self, *args: object, **kwargs: object) -> None:
        """Proxy to :meth:`rich.console.Console.print`."""

        self.console.print(*args, **kwargs)

    def style(self, text: str, color: Color) -> str:
        """Return *text* wrapped in a Rich style when color is enabled."""

        if should_use_color(self.color_setting):
            return f"[{color.value}]{text}[/{color.value}]"
        return text


__all__ = ["Color", "ColorManager", "get_console"]
