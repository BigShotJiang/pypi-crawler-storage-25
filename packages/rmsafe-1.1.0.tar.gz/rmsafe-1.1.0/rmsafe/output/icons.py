"""Icon management for rmsafe terminal output."""

from __future__ import annotations

from enum import Enum


class Icon(Enum):
    """Standard icons used by rmsafe output."""

    # Status icons
    SUCCESS = "✓"
    ERROR = "✗"
    WARNING = "⚠"
    INFO = "ℹ"

    # File operation icons (emoji)
    TRASH = "🗑️"
    FILE = "📄"
    FOLDER = "📁"
    RESTORE = "↩️"

    # Alternative unicode icons (for terminals without emoji support)
    TRASH_ALT = "🗑"
    FILE_ALT = "☐"
    FOLDER_ALT = "☐"
    RESTORE_ALT = "←"


class IconManager:
    """Manage icon rendering based on configuration and terminal support."""

    def __init__(self, use_icons: bool = True, use_emoji: bool = True) -> None:
        self.use_icons = use_icons
        self.use_emoji = use_emoji

    def icon(self, icon: Icon) -> str:
        """Return the appropriate icon string based on settings.

        Args:
            icon: The Icon enum value to render.

        Returns:
            The icon string (emoji, unicode, or empty if icons disabled).
        """
        if not self.use_icons:
            return ""

        # Status icons always use unicode (work everywhere)
        if icon in (Icon.SUCCESS, Icon.ERROR, Icon.WARNING, Icon.INFO):
            return icon.value

        # File icons: use emoji if enabled, otherwise unicode alternative
        if self.use_emoji:
            return icon.value
        else:
            return self._get_alt_icon(icon)

    def _get_alt_icon(self, icon: Icon) -> str:
        """Get unicode alternative for emoji icons."""
        alt_map = {
            Icon.TRASH: Icon.TRASH_ALT.value,
            Icon.FILE: Icon.FILE_ALT.value,
            Icon.FOLDER: Icon.FOLDER_ALT.value,
            Icon.RESTORE: Icon.RESTORE_ALT.value,
        }
        return alt_map.get(icon, icon.value)

    def success(self) -> str:
        """Return success icon with space."""
        icon = self.icon(Icon.SUCCESS)
        return f"{icon} " if icon else ""

    def error(self) -> str:
        """Return error icon with space."""
        icon = self.icon(Icon.ERROR)
        return f"{icon} " if icon else ""

    def warning(self) -> str:
        """Return warning icon with space."""
        icon = self.icon(Icon.WARNING)
        return f"{icon} " if icon else ""

    def info(self) -> str:
        """Return info icon with space."""
        icon = self.icon(Icon.INFO)
        return f"{icon} " if icon else ""

    def trash(self) -> str:
        """Return trash icon with space."""
        icon = self.icon(Icon.TRASH)
        return f"{icon} " if icon else ""

    def file(self) -> str:
        """Return file icon with space."""
        icon = self.icon(Icon.FILE)
        return f"{icon} " if icon else ""

    def folder(self) -> str:
        """Return folder icon with space."""
        icon = self.icon(Icon.FOLDER)
        return f"{icon} " if icon else ""

    def restore(self) -> str:
        """Return restore icon with space."""
        icon = self.icon(Icon.RESTORE)
        return f"{icon} " if icon else ""


__all__ = ["Icon", "IconManager"]