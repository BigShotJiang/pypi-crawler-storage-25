"""rmsafe package metadata and public exports."""

__version__ = "1.0.0"

__all__ = ["__version__"]
