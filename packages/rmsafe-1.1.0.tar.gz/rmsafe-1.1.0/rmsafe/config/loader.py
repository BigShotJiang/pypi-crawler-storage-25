# pyright: reportMissingImports=false
"""Configuration loading with priority handling and JSONC support."""

from __future__ import annotations

import json
import os
import platform
from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping

from rmsafe.config.schema import Config
from rmsafe.platform.macos import get_default_trash_path as get_macos_default_trash_path


CONFIG_FILE = Path.home() / ".config" / "rmsafe" / "config.jsonc"


def get_default_trash_path() -> Path:
    """Return the platform-specific default trash location."""

    home = Path.home()
    if platform.system().lower() == "darwin":
        return get_macos_default_trash_path()
    return home / ".local" / "share" / "Trash"


def load_config(cli_overrides: dict | None = None, *, config_file: Path | None = None) -> Config:
    """Load configuration with CLI > env > config file > defaults priority."""

    data: dict[str, Any] = _default_config_data()
    active_config_file = config_file or CONFIG_FILE
    _deep_merge(data, _load_config_file(active_config_file))
    _deep_merge(data, _load_env_overrides())
    _deep_merge(data, _normalize_cli_overrides(cli_overrides or {}))
    return Config.from_mapping(data, default_trash_location=get_default_trash_path())


def _default_config_data() -> dict[str, Any]:
    return {
        "trash": {
            "max_size": "500MB",
            "location": None,
            "auto_clean_days": 30,
        },
        "behavior": {
            "confirm_large_files": "10MB",
            "confirm_directories": True,
            "undo_history_limit": 100,
        },
        "output": {
            "color": "auto",
            "verbose": True,
            "icons": True,
            "table_format": "rounded",
        },
        "btrfs": {
            "enable_clone": True,
            "fallback_on_error": True,
        },
    }


def _strip_jsonc_comments(content: str) -> str:
    """Strip // line comments and /* block comments */ from JSONC content.

    Preserves comments inside strings. Handles nested block comments by
    matching the first /* to the first */.
    """
    result = []
    i = 0
    in_string = False
    while i < len(content):
        char = content[i]
        # Track string state to avoid stripping comments inside strings
        if char == '"' and (i == 0 or content[i - 1] != "\\"):
            in_string = not in_string
            result.append(char)
            i += 1
        elif in_string:
            # Inside string, append everything
            result.append(char)
            i += 1
        elif char == "/" and i + 1 < len(content):
            next_char = content[i + 1]
            if next_char == "/":
                # Line comment: skip until newline or end
                i += 2
                while i < len(content) and content[i] != "\n":
                    i += 1
                # Keep the newline for proper line tracking
                if i < len(content):
                    result.append("\n")
                    i += 1
            elif next_char == "*":
                # Block comment: skip until */
                i += 2
                while i < len(content) - 1:
                    if content[i] == "*" and content[i + 1] == "/":
                        i += 2
                        break
                    i += 1
            else:
                result.append(char)
                i += 1
        else:
            result.append(char)
            i += 1
    return "".join(result)


def _strip_trailing_commas(content: str) -> str:
    """Strip trailing commas before ] or } in JSONC content.

    Preserves commas inside strings.
    """
    result = []
    i = 0
    in_string = False
    while i < len(content):
        char = content[i]
        # Track string state
        if char == '"' and (i == 0 or content[i - 1] != "\\"):
            in_string = not in_string
            result.append(char)
            i += 1
        elif in_string:
            result.append(char)
            i += 1
        elif char == "," and i + 1 < len(content):
            # Look ahead to see if next non-whitespace is ] or }
            j = i + 1
            while j < len(content) and content[j] in " \t\n\r":
                j += 1
            if j < len(content) and content[j] in "]}":
                # Trailing comma: skip it
                i += 1
            else:
                result.append(char)
                i += 1
        else:
            result.append(char)
            i += 1
    return "".join(result)


def _load_config_file(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        with path.open("r", encoding="utf-8") as fp:
            content = fp.read()
        # Handle empty files gracefully
        if not content.strip():
            return {}
        # Strip JSONC comments and trailing commas, then parse with standard json
        stripped = _strip_jsonc_comments(content)
        stripped = _strip_trailing_commas(stripped)
        loaded = json.loads(stripped)
    except OSError:
        return {}
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid config file {path}: {exc}") from exc
    except Exception as exc:
        raise ValueError(f"Invalid config file {path}: {exc}") from exc
    # Non-dict values (null, string, array) return empty dict
    return loaded if isinstance(loaded, dict) else {}


def _load_env_overrides() -> dict[str, Any]:
    trash_dir = os.getenv("RMSAFE_TRASH_DIR")
    if not trash_dir:
        return {}
    return {"trash": {"location": trash_dir}}


def _normalize_cli_overrides(cli_overrides: Mapping[str, Any]) -> dict[str, Any]:
    if not cli_overrides:
        return {}

    normalized: dict[str, Any] = {}
    if "trash_dir" in cli_overrides:
        normalized.setdefault("trash", {})["location"] = cli_overrides["trash_dir"]
    if "trash_location" in cli_overrides:
        normalized.setdefault("trash", {})["location"] = cli_overrides["trash_location"]

    for key in ("trash", "behavior", "output", "btrfs"):
        if key in cli_overrides and isinstance(cli_overrides[key], Mapping):
            normalized.setdefault(key, {})
            _deep_merge(normalized[key], dict(cli_overrides[key]))

    for key in ("trash_dir", "trash_location"):
        if key in cli_overrides:
            normalized.setdefault("trash", {})["location"] = cli_overrides[key]

    return normalized


def _deep_merge(base: dict[str, Any], override: Mapping[str, Any]) -> None:
    for key, value in override.items():
        if isinstance(value, Mapping) and isinstance(base.get(key), dict):
            _deep_merge(base[key], value)
        elif isinstance(value, Mapping):
            base[key] = deepcopy(dict(value))
        else:
            base[key] = value
