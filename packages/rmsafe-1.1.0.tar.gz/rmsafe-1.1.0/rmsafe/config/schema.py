"""Typed configuration schema and validation for rmsafe."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Optional
import re


_SIZE_RE = re.compile(r"^\d+(?:\.\d+)?\s*(B|KB|MB|GB|TB)$", re.IGNORECASE)
_COLOR_VALUES = {"always", "never", "auto"}


def _normalize_size(value: str, field_name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a string like '10MB'")
    normalized = value.strip().upper().replace(" ", "")
    if not _SIZE_RE.match(normalized):
        raise ValueError(f"{field_name} must look like '10MB', '500KB', or '1.5GB'")
    return normalized


def _normalize_color(value: str) -> str:
    if not isinstance(value, str):
        raise ValueError("output.color must be a string")
    normalized = value.strip().lower()
    if normalized not in _COLOR_VALUES:
        raise ValueError("output.color must be one of: always, never, auto")
    return normalized


def _as_path(value: Any, field_name: str) -> Optional[Path]:
    if value is None or value == "":
        return None
    if isinstance(value, Path):
        return value.expanduser()
    if isinstance(value, str):
        return Path(value).expanduser()
    raise ValueError(f"{field_name} must be a string path or null")


def _require_mapping(value: Any, field_name: str) -> Mapping[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValueError(f"{field_name} must be a mapping")
    return value


@dataclass(slots=True)
class TrashConfig:
    max_size: str = "500MB"
    location: Optional[Path] = None
    auto_clean_days: int = 30


@dataclass(slots=True)
class BehaviorConfig:
    confirm_large_files: str = "10MB"
    confirm_directories: bool = True
    undo_history_limit: int = 100


@dataclass(slots=True)
class OutputConfig:
    color: str = "auto"
    verbose: bool = True
    icons: bool = True
    table_format: str = "rounded"


@dataclass(slots=True)
class BtrfsConfig:
    enable_clone: bool = True
    fallback_on_error: bool = True


@dataclass(slots=True)
class Config:
    trash: TrashConfig = field(default_factory=TrashConfig)
    behavior: BehaviorConfig = field(default_factory=BehaviorConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    btrfs: BtrfsConfig = field(default_factory=BtrfsConfig)

    @classmethod
    def from_mapping(cls, data: Mapping[str, Any], *, default_trash_location: Optional[Path] = None) -> "Config":
        trash = _require_mapping(data.get("trash"), "trash")
        behavior = _require_mapping(data.get("behavior"), "behavior")
        output = _require_mapping(data.get("output"), "output")
        btrfs = _require_mapping(data.get("btrfs"), "btrfs")

        trash_location = _as_path(trash.get("location"), "trash.location")
        if trash_location is None and default_trash_location is not None:
            trash_location = default_trash_location

        trash_config = TrashConfig(
            max_size=_normalize_size(trash.get("max_size", "500MB"), "trash.max_size"),
            location=trash_location,
            auto_clean_days=cls._validate_positive_int(
                trash.get("auto_clean_days", 30), "trash.auto_clean_days"
            ),
        )

        behavior_config = BehaviorConfig(
            confirm_large_files=_normalize_size(
                behavior.get("confirm_large_files", "10MB"),
                "behavior.confirm_large_files",
            ),
            confirm_directories=cls._validate_bool(
                behavior.get("confirm_directories", True),
                "behavior.confirm_directories",
            ),
            undo_history_limit=cls._validate_positive_int(
                behavior.get("undo_history_limit", 100),
                "behavior.undo_history_limit",
            ),
        )

        output_config = OutputConfig(
            color=_normalize_color(output.get("color", "auto")),
            verbose=cls._validate_bool(output.get("verbose", True), "output.verbose"),
            icons=cls._validate_bool(output.get("icons", True), "output.icons"),
            table_format=cls._validate_nonempty_string(
                output.get("table_format", "rounded"), "output.table_format"
            ),
        )

        btrfs_config = BtrfsConfig(
            enable_clone=cls._validate_bool(
                btrfs.get("enable_clone", True), "btrfs.enable_clone"
            ),
            fallback_on_error=cls._validate_bool(
                btrfs.get("fallback_on_error", True), "btrfs.fallback_on_error"
            ),
        )

        return cls(trash=trash_config, behavior=behavior_config, output=output_config, btrfs=btrfs_config)

    @staticmethod
    def _validate_bool(value: Any, field_name: str) -> bool:
        if isinstance(value, bool):
            return value
        raise ValueError(f"{field_name} must be true or false")

    @staticmethod
    def _validate_positive_int(value: Any, field_name: str) -> int:
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError(f"{field_name} must be an integer")
        if value < 0:
            raise ValueError(f"{field_name} must be >= 0")
        return value

    @staticmethod
    def _validate_nonempty_string(value: Any, field_name: str) -> str:
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{field_name} must be a non-empty string")
        return value.strip()
