# pyright: reportMissingImports=false
"""Configuration helpers for rmsafe."""

from .loader import get_default_trash_path, load_config  # type: ignore[import-not-found]
from .schema import (  # type: ignore[import-not-found]
    BehaviorConfig,
    BtrfsConfig,
    Config,
    OutputConfig,
    TrashConfig,
)

__all__ = [
    "BehaviorConfig",
    "BtrfsConfig",
    "Config",
    "OutputConfig",
    "TrashConfig",
    "get_default_trash_path",
    "load_config",
]
