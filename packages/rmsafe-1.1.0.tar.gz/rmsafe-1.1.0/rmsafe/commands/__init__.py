"""Command modules for rmsafe."""

from importlib import import_module

empty = import_module(".empty", __name__)
list_command = import_module(".list", __name__)
restore = import_module(".restore", __name__)
status = import_module(".status", __name__)
trash = import_module(".trash", __name__)
undo = import_module(".undo", __name__)

__all__ = ["empty", "list_command", "restore", "status", "trash", "undo"]
