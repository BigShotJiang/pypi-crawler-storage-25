"""Status command implementation - trash status with visual feedback."""

from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path

from rich.panel import Panel

from ..config.loader import get_default_trash_path, load_config
from ..core.trash_manager import TrashManager
from ..core.trashinfo import parse_trashinfo
from ..output.colors import ColorManager
from ..output.icons import IconManager
from ..utils.size import format_size, path_size


def run() -> None:
    """Display trash directory status in a styled panel."""

    config = load_config()
    manager = TrashManager(config.trash.location or get_default_trash_path())
    colors = ColorManager(config.output.color)
    icons = IconManager(use_icons=config.output.icons)

    file_count, total_size, oldest, newest = _collect_stats(manager)

    # Build panel content
    content = _build_status_content(
        file_count=file_count,
        total_size=total_size,
        oldest=oldest,
        newest=newest,
        trash_path=manager.trash_dir,
        icons=icons,
        use_icons=config.output.icons,
    )

    # Create panel with trash icon title
    title = f"{icons.trash()}Trash" if config.output.icons else "Trash"
    panel = Panel(
        content,
        title=title,
        title_align="left",
        border_style="cyan",
        expand=False,
    )

    colors.print(panel)


def _collect_stats(manager: TrashManager) -> tuple[int, int, datetime | None, datetime | None]:
    if not manager.files_dir.exists():
        return 0, 0, None, None

    total_size = 0
    timestamps: list[datetime] = []
    count = 0

    for file_path in sorted(manager.files_dir.iterdir(), key=lambda path: path.name.lower()):
        count += 1
        total_size += path_size(file_path)
        if manager.info_dir is None:
            continue
        info_path = manager.info_dir / f"{file_path.name}.trashinfo"
        try:
            timestamps.append(parse_trashinfo(info_path).deletion_date)
        except (OSError, ValueError):
            continue

    return count, total_size, (min(timestamps) if timestamps else None), (max(timestamps) if timestamps else None)


def _build_status_content(
    file_count: int,
    total_size: int,
    oldest: datetime | None,
    newest: datetime | None,
    trash_path: Path,
    icons: IconManager,
    use_icons: bool,
) -> str:
    """Build status display content with icons and formatting.

    Returns Rich markup string for Panel content.
    """

    lines: list[str] = []

    # File count and size summary
    if file_count == 0:
        lines.append("[dim]Empty trash[/]")
    else:
        size_text = format_size(total_size)
        files_text = f"{file_count} file{'s' if file_count != 1 else ''}"
        lines.append(f"[bold]{files_text}[/] · [cyan]{size_text}[/]")

    # Time information
    if oldest is not None and newest is not None:
        oldest_age = _format_age(oldest)
        newest_age = _format_age(newest)
        if oldest_age != newest_age:
            lines.append(f"[dim]oldest: {oldest_age}[/] · newest: {newest_age}")
        else:
            lines.append(f"[dim]all deleted {oldest_age}[/]")
    elif oldest is not None:
        lines.append(f"[dim]oldest: {_format_age(oldest)}[/]")

    # Undo availability hint
    restore_icon = icons.restore() if use_icons else ""
    if file_count > 0:
        lines.append(f"{restore_icon}undo available: [cyan]rmsafe undo[/]")
    else:
        lines.append(f"[dim]{restore_icon}undo: nothing to restore[/]")

    # Trash location (verbose info)
    lines.append(f"[dim]path: {trash_path}[/]")

    return "\n".join(lines)


def _format_age(dt: datetime) -> str:
    """Format datetime as human-readable age string."""

    now = datetime.now()
    delta = now - dt

    if delta < timedelta(minutes=1):
        return "just now"
    elif delta < timedelta(hours=1):
        minutes = int(delta.total_seconds() / 60)
        return f"{minutes} min ago"
    elif delta < timedelta(days=1):
        hours = int(delta.total_seconds() / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif delta < timedelta(days=7):
        days = int(delta.total_seconds() / 86400)
        return f"{days} day{'s' if days != 1 else ''} ago"
    elif delta < timedelta(days=30):
        weeks = int(delta.total_seconds() / (7 * 86400))
        return f"{weeks} week{'s' if weeks != 1 else ''} ago"
    else:
        return dt.strftime("%Y-%m-%d")


def _format_time(value: datetime | None) -> str:
    """Format datetime for display (backwards compatible).

    Returns "-" for None, or formatted datetime string.
    """
    if value is None:
        return "-"
    return value.replace(microsecond=0).strftime("%Y-%m-%d %H:%M:%S")


__all__ = ["run"]