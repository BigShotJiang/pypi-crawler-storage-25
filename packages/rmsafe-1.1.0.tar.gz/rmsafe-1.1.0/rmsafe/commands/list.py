"""List command implementation."""

# pyright: reportMissingImports=false

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from fnmatch import fnmatchcase
from pathlib import Path

from rich.table import Table

from ..config.loader import get_default_trash_path, load_config
from ..core.trash_manager import TrashManager
from ..core.trashinfo import parse_trashinfo
from ..output.colors import ColorManager
from ..utils.size import format_size, path_size


@dataclass(slots=True)
class TrashEntry:
    path: Path
    name: str
    size_bytes: int
    time_value: datetime | None
    time_text: str
    origin_text: str


def run(pattern: str | None, sort: str = "time") -> None:
    """List trashed files in a table."""

    config = load_config()
    manager = TrashManager(config.trash.location or get_default_trash_path())
    colors = ColorManager(config.output.color)

    entries = _collect_entries(manager, pattern)
    if not entries:
        colors.print("No trashed files found.")
        return

    sorted_entries = sorted(entries, key=_sort_key(sort), reverse=True)
    table = Table(title="Trash", header_style="bold", show_lines=False)
    table.add_column("Time", style="cyan", no_wrap=True)
    table.add_column("File", style="green")
    table.add_column("Size", justify="right", style="magenta")
    table.add_column("Origin", style="blue")

    total_size = 0
    for entry in sorted_entries:
        total_size += entry.size_bytes
        table.add_row(entry.time_text, entry.name, format_size(entry.size_bytes), entry.origin_text)

    colors.print(table)
    colors.print(f"{len(sorted_entries)} file(s), {format_size(total_size)} total")


def _collect_entries(manager: TrashManager, pattern: str | None) -> list[TrashEntry]:
    if not manager.files_dir.exists():
        return []

    entries: list[TrashEntry] = []
    for file_path in sorted(manager.files_dir.iterdir(), key=lambda path: path.name.lower()):
        if pattern and not _matches_pattern(file_path, pattern, manager):
            continue
        entries.append(_build_entry(file_path, manager))
    return entries


def _build_entry(file_path: Path, manager: TrashManager) -> TrashEntry:
    size_bytes = path_size(file_path)
    if manager.info_dir is None:
        return TrashEntry(file_path, file_path.name, size_bytes, None, "-", "-")

    info_path = manager.info_dir / f"{file_path.name}.trashinfo"
    try:
        trashinfo = parse_trashinfo(info_path)
    except (OSError, ValueError):
        return TrashEntry(file_path, file_path.name, size_bytes, None, "-", "-")

    time_text = trashinfo.deletion_date.replace(microsecond=0).strftime("%Y-%m-%d %H:%M:%S")
    return TrashEntry(file_path, file_path.name, size_bytes, trashinfo.deletion_date, time_text, str(trashinfo.original_path))


def _matches_pattern(file_path: Path, pattern: str, manager: TrashManager) -> bool:
    values = [file_path.name]
    if manager.info_dir is not None:
        info_path = manager.info_dir / f"{file_path.name}.trashinfo"
        try:
            values.append(str(parse_trashinfo(info_path).original_path))
        except (OSError, ValueError):
            pass
    return any(fnmatchcase(value, pattern) for value in values)


def _sort_key(sort: str):
    sort_value = sort.strip().lower()
    if sort_value == "size":
        return lambda entry: (entry.size_bytes, entry.name.lower())
    return lambda entry: (
        entry.time_value or datetime.min,
        entry.name.lower(),
    )
