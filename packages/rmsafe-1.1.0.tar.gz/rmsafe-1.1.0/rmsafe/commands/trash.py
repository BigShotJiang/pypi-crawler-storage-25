"""Trash command implementation."""

# pyright: reportMissingImports=false

from __future__ import annotations

import sys
import signal
from pathlib import Path
from typing import Any, Sequence

from rich import print as rprint
from rich.prompt import Confirm

from ..core.history_tracker import HistoryTracker
from ..core.trash_manager import TrashManager
from ..output.colors import Color, ColorManager
from ..output.icons import IconManager
from ..output.progress import should_show_progress, create_progress_bar, format_summary
from ..utils.size import parse_size, path_size
from ..utils.tty import is_tty


def run(files: Sequence[Path], context: dict[str, Any]) -> None:
    """Trash files using the configured trash manager."""

    config = context["config"]
    colors = context.get("colors")
    if not isinstance(colors, ColorManager):
        colors = ColorManager()

    icons = IconManager(use_icons=config.output.icons)
    manager = TrashManager(config.trash.location)
    history = HistoryTracker(max_entries=config.behavior.undo_history_limit)
    dry_run = bool(context.get("dry_run"))
    no_confirm = bool(context.get("no_confirm"))
    confirm_large_bytes = parse_size(config.behavior.confirm_large_files)

    # >=4 files: use progress bar with transient behavior
    if should_show_progress(files) and not dry_run:
        total_bytes = 0
        success_count = 0

        with create_progress_bar(colors, icons) as progress:
            task = progress.add_task("Trashing", total=len(files), filename="")

            for path in files:
                if _needs_large_file_confirm(path, confirm_large_bytes, dry_run=dry_run, no_confirm=no_confirm):
                    if not _confirm_large_file(path, colors):
                        progress.update(task, filename=f"Skipped: {path.name}")
                        progress.advance(task)
                        continue

                result = manager.trash_directory(path, dry_run=dry_run) if path.is_dir() else manager.trash_file(path, dry_run=dry_run)
                progress.update(task, filename=path.name)
                progress.advance(task)

                if result.success:
                    total_bytes += result.size_bytes or 0
                    success_count += 1
                    history.record_deletion([result.source.absolute()], [result.info_path.absolute() if result.info_path else None])
                else:
                    rprint(colors.style(result.message, Color.ERROR))

        # Summary after progress bar completes
        if success_count > 0:
            colors.print(format_summary(success_count, total_bytes, colors, icons))

        return

    # <=3 files or dry_run: direct output (original behavior)
    for path in files:
        if _needs_large_file_confirm(path, confirm_large_bytes, dry_run=dry_run, no_confirm=no_confirm):
            if not _confirm_large_file(path, colors):
                rprint(colors.style(f"Skipped {path}", Color.WARNING))
                continue

        result = manager.trash_directory(path, dry_run=dry_run) if path.is_dir() else manager.trash_file(path, dry_run=dry_run)
        if result.success:
            rprint(_format_success(result, colors, icons))
            if not dry_run:
                history.record_deletion([
                    result.source.absolute(),
                ], [
                    result.info_path.absolute() if result.info_path is not None else None,
                ])
        else:
            rprint(colors.style(result.message, Color.ERROR))
            if result.error:
                rprint(colors.style(result.error, Color.WARNING))


def _format_success(result, colors: ColorManager, icons: IconManager | None = None) -> str:
    size_part = f" ({result.size_text})" if result.size_text else ""
    prefix = "Dry run: " if result.dry_run else ""
    trash_root = result.destination.parent if result.info_path is None else result.destination.parent.parent

    # Add icon if available
    icon_part = ""
    if icons and not result.dry_run:
        icon_part = icons.trash()

    return (
        f"{icon_part}{colors.style(prefix + result.source.name, Color.SUCCESS)}"
        f"{size_part} → {colors.style(str(trash_root) + '/', Color.INFO)}"
    )


def _needs_large_file_confirm(path: Path, threshold_bytes: int, *, dry_run: bool, no_confirm: bool) -> bool:
    if dry_run or no_confirm or not path.is_file():
        return False
    try:
        return path.stat().st_size > threshold_bytes
    except OSError:
        return False


def _confirm_large_file(path: Path, colors: ColorManager) -> bool:
    if not is_tty(sys.stdin) or not is_tty(sys.stdout):
        return True
    prompt = colors.style(f"Trash large file {path}?", Color.WARNING)

    if not hasattr(signal, "SIGALRM"):
        return Confirm.ask(prompt, default=False)

    def _timeout_handler(_signum: int, _frame: object) -> None:
        raise TimeoutError

    previous_handler = signal.signal(signal.SIGALRM, _timeout_handler)
    signal.alarm(30)
    try:
        return Confirm.ask(prompt, default=False)
    except TimeoutError:
        return False
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, previous_handler)
