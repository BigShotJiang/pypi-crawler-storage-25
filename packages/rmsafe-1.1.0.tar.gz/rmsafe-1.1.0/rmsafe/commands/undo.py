"""Undo command implementation - visual history with Rich Table."""

from __future__ import annotations

from pathlib import Path

from rich.table import Table

from ..config.loader import get_default_trash_path, load_config
from ..core.history_tracker import HistoryTracker
from ..core.trash_manager import TrashManager
from ..output.colors import ColorManager
from ..output.icons import IconManager
from ..utils.size import format_size, path_size


def run(n: int | None, list_only: bool = False) -> None:
    """Undo recent trash operations from history."""

    config = load_config()
    colors = ColorManager(config.output.color)
    icons = IconManager(use_icons=config.output.icons)
    tracker = HistoryTracker(max_entries=config.behavior.undo_history_limit)

    if list_only:
        _print_history_table(tracker, colors, icons, config.output.icons)
        return

    count = n or 1
    manager = TrashManager(config.trash.location or get_default_trash_path())

    try:
        restored = tracker.undo_last(count, trash_manager=manager)
    except (FileExistsError, FileNotFoundError, OSError, ValueError) as exc:
        colors.print(f"{icons.error()}Undo failed: {exc}")
        return

    if not restored:
        colors.print(f"{icons.info()}No undo history found.")
        return

    # Print restored files with icons
    colors.print(f"{icons.success()}Restored {len(restored)} deletion(s)")
    for entry in restored:
        for file_path in entry.files:
            colors.print(f"  {icons.restore()}{file_path}")


def _print_history_table(
    tracker: HistoryTracker,
    colors: ColorManager,
    icons: IconManager,
    use_icons: bool,
) -> None:
    """Print undo history as a Rich table with icons."""

    entries = tracker.list_recent()
    if not entries:
        colors.print(f"{icons.info()}No undo history found.")
        return

    # Build table
    restore_icon = icons.restore() if use_icons else ""
    table = Table(
        title=f"{restore_icon}Recently Trashed",
        title_style="bold cyan",
        header_style="bold",
        show_lines=False,
        expand=False,
    )

    table.add_column("#", style="cyan", no_wrap=True, width=4)
    table.add_column("Time", style="dim", width=12)
    table.add_column("Files", style="green")
    table.add_column("Size", justify="right", style="magenta", width=8)
    table.add_column("Undo", style="cyan dim", width=15)

    for index, entry in enumerate(entries, start=1):
        # Format time
        time_text = _format_time_ago(entry.timestamp)

        # Format files (show up to 3, then count remaining)
        file_names = _format_file_names(entry.files)

        # Calculate size
        total_size = _calculate_entry_size(entry.files)
        size_text = format_size(total_size)

        # Undo hint
        undo_cmd = f"rmsafe undo {index}"

        table.add_row(
            str(index),
            time_text,
            file_names,
            size_text,
            undo_cmd,
        )

    colors.print(table)

    # Summary hint
    colors.print(f"\n[dim]Use [cyan]rmsafe undo N[/] to restore items[/]")


def _format_time_ago(dt: Path | object) -> str:
    """Format datetime as short age string for table."""
    from datetime import datetime, timedelta

    # Handle if dt is a Path (shouldn't happen but be safe)
    if isinstance(dt, Path):
        return "-"

    now = datetime.now()
    delta = now - dt

    if delta < timedelta(minutes=1):
        return "just now"
    elif delta < timedelta(hours=1):
        minutes = int(delta.total_seconds() / 60)
        return f"{minutes}m"
    elif delta < timedelta(days=1):
        hours = int(delta.total_seconds() / 3600)
        return f"{hours}h"
    elif delta < timedelta(days=7):
        days = int(delta.total_seconds() / 86400)
        return f"{days}d"
    else:
        return dt.strftime("%m/%d")


def _format_file_names(files: list[Path]) -> str:
    """Format file names for display in table.

    Shows up to 2 files, then count of remaining.
    """
    if not files:
        return "-"

    names = [f.name for f in files[:2]]
    if len(files) > 2:
        names.append(f"... ({len(files) - 2} more)")

    return ", ".join(names)


def _calculate_entry_size(files: list[Path]) -> int:
    """Calculate total size of files in history entry."""
    total = 0
    for f in files:
        try:
            if f.exists():
                total += path_size(f)
        except OSError:
            pass
    return total


__all__ = ["run"]