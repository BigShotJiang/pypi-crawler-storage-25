"""Restore command implementation."""
# pyright: reportMissingImports=false

from __future__ import annotations

import re
import os
import shutil
from dataclasses import dataclass
from pathlib import Path

import typer
from rich.table import Table

from ..config.loader import get_default_trash_path, load_config
from ..core.trash_manager import TrashManager
from ..core.trashinfo import parse_trashinfo
from ..output.colors import Color, ColorManager


@dataclass(slots=True)
class RestoreEntry:
    index: int
    trash_path: Path
    origin_path: Path | None
    deletion_text: str

    @property
    def name(self) -> str:
        return self.trash_path.name


class RestoreSkipped(Exception):
    """Raised when the user declines to overwrite an existing destination."""


class RestoreFailed(Exception):
    """Raised when restore cannot complete safely."""


def run(pattern: str | None, to: Path | None = None) -> None:
    """Restore trashed files or directories."""

    config = load_config()
    manager = TrashManager(config.trash.location or get_default_trash_path())
    colors = ColorManager(config.output.color)

    entries = _collect_entries(manager)
    if not entries:
        colors.print("No trashed files found.")
        return

    _print_entries(entries, colors)
    selection = pattern or typer.prompt("Restore which item(s)?", default="all")
    chosen = _resolve_selection(selection, entries, manager)
    if not chosen:
        colors.print(colors.style("No matching trashed files found.", Color.WARNING))
        return

    for entry in chosen:
        _restore_entry(entry, colors, to, len(chosen) > 1)


def _collect_entries(manager: TrashManager) -> list[RestoreEntry]:
    if not manager.files_dir.exists():
        return []

    entries: list[RestoreEntry] = []
    for index, trash_path in enumerate(sorted(manager.files_dir.iterdir(), key=lambda path: path.name.lower()), start=1):
        origin_path = None
        deletion_text = "-"
        if manager.info_dir is not None:
            info_path = manager.info_dir / f"{trash_path.name}.trashinfo"
            try:
                trashinfo = parse_trashinfo(info_path)
            except (OSError, ValueError):
                pass
            else:
                origin_path = trashinfo.original_path
                deletion_text = trashinfo.deletion_date.replace(microsecond=0).strftime("%Y-%m-%d %H:%M:%S")
        entries.append(RestoreEntry(index=index, trash_path=trash_path, origin_path=origin_path, deletion_text=deletion_text))
    return entries


def _print_entries(entries: list[RestoreEntry], colors: ColorManager) -> None:
    table = Table(title="Trash", header_style="bold", show_lines=False)
    table.add_column("#", style="cyan", no_wrap=True)
    table.add_column("File", style="green")
    table.add_column("Deleted", style="magenta")
    table.add_column("Origin", style="blue")
    for entry in entries:
        table.add_row(str(entry.index), entry.name, entry.deletion_text, str(entry.origin_path or "-"))
    colors.print(table)


def _resolve_selection(selection: str, entries: list[RestoreEntry], manager: TrashManager) -> list[RestoreEntry]:
    normalized = selection.strip()
    if not normalized:
        return []

    exact_matches = [entry for entry in entries if manager.names_match(normalized, entry.name)]
    if exact_matches:
        return exact_matches

    if normalized.lower() == "all":
        return entries

    if re.fullmatch(r"\d+(?:\s*,\s*\d+)*", normalized):
        indexes = {int(part) for part in normalized.split(",")}
        return [entry for entry in entries if entry.index in indexes]

    return []


def _restore_entry(entry: RestoreEntry, colors: ColorManager, to: Path | None, batch: bool) -> None:
    destination = _destination_for(entry, to)
    if destination is None:
        colors.print(colors.style(f"Unable to restore {entry.name}", Color.ERROR))
        return

    try:
        _restore_path(entry.trash_path, destination)
    except RestoreSkipped:
        colors.print(colors.style(f"Skipped existing destination: {destination}", Color.WARNING))
    except PermissionError as exc:
        colors.print(colors.style(f"Permission denied: {entry.name}", Color.ERROR))
        colors.print(colors.style(str(exc), Color.WARNING))
    except OSError as exc:
        colors.print(colors.style(f"Failed to restore {entry.name}", Color.ERROR))
        colors.print(colors.style(str(exc), Color.WARNING))
    else:
        prefix = "Restored" if not batch else "Restored"
        colors.print(colors.style(f"{prefix} {entry.name} → {destination}", Color.SUCCESS))


def _destination_for(entry: RestoreEntry, to: Path | None) -> Path | None:
    if to is not None:
        target = to.expanduser()
        if target.exists() and target.is_dir():
            return target / entry.name
        return target

    if entry.origin_path is not None:
        return entry.origin_path.expanduser()

    return Path.cwd() / entry.name


def _restore_path(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)

    backup: Path | None = None
    temp: Path | None = None
    if destination.exists():
        if not typer.confirm(f"Overwrite existing {destination}?", default=False):
            raise RestoreSkipped(destination)
        backup = destination.parent / f".restore-backup-{os.getpid()}-{destination.name}"
        shutil.move(str(destination), str(backup))

    temp = destination.parent / f".restore-temp-{os.getpid()}-{destination.name}"

    try:
        shutil.move(str(source), str(temp))
        if destination.exists():
            raise RestoreFailed(f"Destination unexpectedly exists: {destination}")
        os.replace(temp, destination)
    except Exception:
        if temp is not None and temp.exists():
            try:
                shutil.move(str(temp), str(source))
            except Exception:
                pass
        if backup is not None:
            try:
                shutil.move(str(backup), str(destination))
            except Exception:
                pass
        raise
    finally:
        if backup is not None and backup.exists():
            if backup.is_dir():
                shutil.rmtree(backup)
            else:
                backup.unlink(missing_ok=True)
        if temp is not None and temp.exists():
            if temp.is_dir():
                shutil.rmtree(temp)
            else:
                temp.unlink(missing_ok=True)
