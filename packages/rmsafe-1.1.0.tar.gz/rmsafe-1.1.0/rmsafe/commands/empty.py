"""Empty command implementation."""

# pyright: reportMissingImports=false

from __future__ import annotations

import os
import shutil
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

import typer
from rich.prompt import Confirm

from ..config.loader import get_default_trash_path, load_config
from ..core.trash_manager import TrashManager
from ..core.trashinfo import parse_trashinfo
from ..output.colors import Color, ColorManager
from ..utils.size import format_size, path_size
from ..utils.tty import is_tty


@dataclass(slots=True)
class TrashCandidate:
    path: Path
    info_path: Path | None
    deletion_date: datetime | None
    size_bytes: int


def run(days: int | None, force: bool = False) -> None:
    """Empty trash items, optionally limited to items older than *days*."""

    config = load_config()
    manager = TrashManager(config.trash.location or get_default_trash_path())
    colors = ColorManager(config.output.color)

    candidates = _collect_candidates(manager)
    if not candidates:
        colors.print("No trashed files found.")
        return

    to_delete = candidates
    if days is not None:
        now = _current_time()
        if now is None:
            return
        if manager.info_dir is None:
            colors.print(colors.style("Trash metadata is unavailable; cannot age-filter items.", Color.WARNING))
            return
        cutoff = now - timedelta(days=days)
        to_delete = [candidate for candidate in candidates if candidate.deletion_date is not None and candidate.deletion_date < cutoff]

    if not to_delete:
        colors.print("Nothing to empty.")
        return

    if days is None and not force:
        if not is_tty(sys.stdin) or not is_tty(sys.stdout):
            colors.print(colors.style("Refusing to prompt in a non-interactive terminal. Use --force.", Color.WARNING))
            raise typer.Exit(code=1)
        message = f"Empty {len(to_delete)} trashed item(s)?"
        if not Confirm.ask(colors.style(message, Color.WARNING), default=False):
            colors.print(colors.style("Aborted.", Color.WARNING))
            raise typer.Exit(code=1)

    removed = 0
    removed_size = 0
    for candidate in to_delete:
        _remove_candidate(candidate)
        removed += 1
        removed_size += candidate.size_bytes

    colors.print(colors.style(f"Emptied {removed} item(s), freed {format_size(removed_size)}.", Color.SUCCESS))


def _collect_candidates(manager: TrashManager) -> list[TrashCandidate]:
    if not manager.files_dir.exists():
        return []

    candidates: list[TrashCandidate] = []
    for path in sorted(manager.files_dir.iterdir(), key=lambda item: item.name.lower()):
        info_path = None if manager.info_dir is None else manager.info_dir / f"{path.name}.trashinfo"
        deletion_date = None
        if info_path is not None:
            try:
                deletion_date = parse_trashinfo(info_path).deletion_date
            except (OSError, ValueError):
                deletion_date = None
        candidates.append(TrashCandidate(path=path, info_path=info_path, deletion_date=deletion_date, size_bytes=path_size(path)))
    return candidates


def _remove_candidate(candidate: TrashCandidate) -> None:
    if candidate.path.is_dir() and not candidate.path.is_symlink():
        shutil.rmtree(candidate.path)
    else:
        candidate.path.unlink(missing_ok=True)

    if candidate.info_path is not None and candidate.info_path.exists():
        candidate.info_path.unlink(missing_ok=True)


def _current_time() -> datetime | None:
    raw = os.environ.get("TRASH_DATE")
    if not raw:
        return datetime.now()

    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        typer.echo(f"empty: invalid TRASH_DATE: {raw}", err=True)
        raise typer.Exit(code=1)
