"""Module entry point for ``python -m rmsafe``."""

from __future__ import annotations

from .cli import main_entry


def main() -> None:
    main_entry()


if __name__ == "__main__":
    main()
