"""Platform-specific integrations for rmsafe."""

from . import btrfs
from . import macos

__all__ = ["btrfs", "macos"]
