"""BTRFS helpers for rmsafe.

Linux-only support for filesystem detection and file cloning.
"""

from __future__ import annotations

import contextlib
import os
import shutil
import sys
from pathlib import Path
from typing import Optional

BTRFS_SUPER_MAGIC = 0x9123683E
BTRFS_IOC_CLONE = 0x40049409

_IS_LINUX = sys.platform.startswith("linux")


def _is_linux() -> bool:
    return _IS_LINUX


def _Statfs():  # type: ignore[no-untyped-def]
    if not _IS_LINUX:
        return None

    import ctypes

    class _Statfs(ctypes.Structure):
        _fields_ = [
            ("f_type", ctypes.c_long),
            ("f_bsize", ctypes.c_long),
            ("f_blocks", ctypes.c_ulonglong),
            ("f_bfree", ctypes.c_ulonglong),
            ("f_bavail", ctypes.c_ulonglong),
            ("f_files", ctypes.c_ulonglong),
            ("f_ffree", ctypes.c_ulonglong),
            ("f_fsid", ctypes.c_long * 2),
            ("f_namelen", ctypes.c_long),
            ("f_frsize", ctypes.c_long),
            ("f_flags", ctypes.c_long),
            ("f_spare", ctypes.c_long * 4),
        ]

    return _Statfs


def get_fs_type(path: Path | str) -> Optional[int]:
    """Return the filesystem magic number for ``path``.

    Uses ``statfs(2)`` via ``ctypes``; returns ``None`` on failure or on
    non-Linux platforms.
    """

    if not _IS_LINUX:
        return None

    import ctypes
    import ctypes.util

    target = Path(path)
    if not target.exists():
        target = target.parent

    libc_name = ctypes.util.find_library("c")
    if libc_name is None:
        return None
    libc = ctypes.CDLL(libc_name, use_errno=True)
    Statfs = _Statfs()
    statfs = libc.statfs
    statfs.argtypes = [ctypes.c_char_p, ctypes.POINTER(Statfs)]
    statfs.restype = ctypes.c_int

    buf = Statfs()
    result = statfs(os.fsencode(str(target)), ctypes.byref(buf))
    if result != 0:
        return None
    return int(buf.f_type)


def is_btrfs(path: Path | str) -> bool:
    """Return whether ``path`` is on BTRFS."""

    return get_fs_type(path) == BTRFS_SUPER_MAGIC


def are_same_subvolume(src: Path | str, dest: Path | str) -> bool:
    """Best-effort same-subvolume check for BTRFS paths."""

    if not (_is_linux() and is_btrfs(src) and is_btrfs(dest)):
        return False

    try:
        return os.stat(src).st_dev == os.stat(Path(dest).parent).st_dev
    except OSError:
        return False


def btrfs_clone_file(src: Path | str, dest: Path | str) -> bool:
    """Try to clone ``src`` to ``dest`` using the BTRFS clone ioctl.

    Returns ``True`` on success; ``False`` means callers should fallback to a
    normal copy.
    """

    if not (_IS_LINUX and is_btrfs(src) and is_btrfs(Path(dest).parent)):
        return False

    import fcntl

    source = Path(src)
    target = Path(dest)
    src_fd: int | None = None
    dest_fd: int | None = None
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        src_fd = os.open(source, os.O_RDONLY)
        dest_fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        fcntl.ioctl(dest_fd, BTRFS_IOC_CLONE, src_fd)
        os.close(src_fd)
        os.close(dest_fd)
        src_fd = None
        dest_fd = None
        source.unlink()
        return True
    except OSError:
        if dest_fd is not None:
            with contextlib.suppress(OSError):
                os.close(dest_fd)
            with contextlib.suppress(OSError):
                target.unlink()
        if src_fd is not None:
            with contextlib.suppress(OSError):
                os.close(src_fd)
        return False


def trash_file_with_btrfs_support(src: Path | str, dest: Path | str) -> bool:
    """Move a file into trash with BTRFS-aware fallback.

    Flow: rename -> BTRFS clone -> copy + unlink.
    """

    source = Path(src)
    target = Path(dest)
    target.parent.mkdir(parents=True, exist_ok=True)

    try:
        os.rename(source, target)
        return True
    except OSError:
        pass

    if btrfs_clone_file(source, target):
        return True

    try:
        shutil.copy2(source, target)
        source.unlink()
        return True
    except OSError:
        with contextlib.suppress(OSError):
            target.unlink()
        raise
