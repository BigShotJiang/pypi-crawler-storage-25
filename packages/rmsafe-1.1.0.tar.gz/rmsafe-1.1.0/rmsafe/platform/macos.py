"""macOS-specific helpers for rmsafe."""

from __future__ import annotations

import sys
from pathlib import Path


def get_default_trash_path() -> Path:
    """Return Finder's standard trash location."""

    return Path.home() / ".Trash"


def is_mac_trash(trash_dir: Path) -> bool:
    """Return whether ``trash_dir`` is the macOS Finder trash."""

    return sys.platform == "darwin" and trash_dir.name == ".Trash"


def names_match(expected: str, actual: str) -> bool:
    """Return whether two names match on macOS case-insensitively."""

    return expected == actual or (sys.platform == "darwin" and expected.casefold() == actual.casefold())
