"""Deletion history tracking for undo support.

Uses SQLite backend for atomic writes and transaction protection.
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Sequence

from .history_db import HistoryDB
from .trash_manager import TrashManager


@dataclass(slots=True)
class HistoryEntry:
    """A deletion event stored in history."""

    timestamp: datetime
    files: list[Path]
    trashinfo_paths: list[Path | None]


class HistoryTracker:
    """Persist deletion history for undo operations using SQLite backend."""

    def __init__(self, history_path: Path | None = None, max_entries: int = 100):
        """Initialize history tracker.

        Args:
            history_path: Path to database file (SQLite .db or legacy .json).
                          Uses default ~/.local/share/rmsafe/history.db if None.
            max_entries: Maximum number of entries to keep.
        """
        # Determine database path - convert legacy .json path to .db
        if history_path is not None:
            path = history_path.expanduser()
            # If user specified .json path, use .db instead
            if path.suffix == ".json":
                path = path.with_suffix(".db")
            self._db_path = path
        else:
            self._db_path = HistoryDB.DEFAULT_DB_PATH

        self.max_entries = max_entries
        self._db = HistoryDB(db_path=self._db_path, max_entries=max_entries)

    @property
    def history_path(self) -> Path:
        """Return the database path for backward compatibility."""
        return self._db_path

    def record_deletion(
        self,
        files: Sequence[Path],
        trashinfo_paths: Sequence[Path | None],
        timestamp: datetime | None = None,
    ) -> None:
        """Append a deletion record, keeping only the newest entries."""

        if not files:
            return

        if len(files) != len(trashinfo_paths):
            raise ValueError("files and trashinfo_paths must have the same length")

        # Convert paths to strings for storage
        files_str = [str(path) for path in files]
        trashinfo_str = [str(path) if path is not None else None for path in trashinfo_paths]

        self._db.record(files_str, trashinfo_str, timestamp)

    def list_recent(self, limit: int | None = None) -> list[HistoryEntry]:
        """Return recent deletion entries, newest first."""

        raw_entries = self._db.list_recent(limit)
        return [self._decode_entry(item) for item in raw_entries]

    def undo_last(self, count: int = 1, trash_manager: TrashManager | None = None) -> list[HistoryEntry]:
        """Restore the most recent deletion records."""

        if count < 1:
            return []

        manager = trash_manager or TrashManager(Path.home() / ".local/share/Trash")

        # Pop entries from database
        raw_entries = self._db.pop_last(count)
        if not raw_entries:
            return []

        pending: list[HistoryEntry] = [self._decode_entry(item) for item in raw_entries]
        restored: list[HistoryEntry] = []

        try:
            for entry in pending:
                self._restore_entry(entry, manager)
        except Exception:
            # On failure, we need to restore the entries back to database
            # They were popped but restoration failed
            for entry in pending:
                files_str = [str(path) for path in entry.files]
                trashinfo_str = [str(path) if path is not None else None for path in entry.trashinfo_paths]
                self._db.record(files_str, trashinfo_str, entry.timestamp)
            raise
        else:
            restored.extend(pending)

        return restored

    def _restore_entry(self, entry: HistoryEntry, manager: TrashManager) -> None:
        for original_path, trashinfo_path in zip(entry.files, entry.trashinfo_paths, strict=True):
            trash_path = self._resolve_trash_path(original_path, trashinfo_path, manager)
            destination = original_path.expanduser()
            destination.parent.mkdir(parents=True, exist_ok=True)

            if destination.exists():
                raise FileExistsError(f"Destination already exists: {destination}")
            if not trash_path.exists():
                raise FileNotFoundError(f"Missing trashed file: {trash_path}")

            shutil.move(str(trash_path), str(destination))

            if trashinfo_path is not None and trashinfo_path.exists():
                trashinfo_path.unlink()

    def _resolve_trash_path(
        self,
        original_path: Path,
        trashinfo_path: Path | None,
        manager: TrashManager,
    ) -> Path:
        if trashinfo_path is not None:
            candidate = manager.files_dir / trashinfo_path.stem
            if candidate.exists():
                return candidate

        candidate = manager.files_dir / original_path.name
        if candidate.exists():
            return candidate

        matches = [path for path in manager.files_dir.glob(f"{original_path.stem}*{''.join(original_path.suffixes)}") if path.is_file()]
        if len(matches) == 1:
            return matches[0]

        return candidate

    def _decode_entry(self, item: dict[str, object]) -> HistoryEntry:
        timestamp_text = item.get("timestamp")
        files_text = item.get("files", [])
        trashinfo_text = item.get("trashinfo_paths", [])

        if not isinstance(timestamp_text, str):
            raise ValueError("Invalid history entry timestamp")
        if not isinstance(files_text, list) or not isinstance(trashinfo_text, list):
            raise ValueError("Invalid history entry paths")
        if len(files_text) != len(trashinfo_text):
            raise ValueError("History entry path lengths do not match")

        # Filter files and trashinfo together, keeping only entries where file is a string
        paired = [
            (Path(f), Path(t) if isinstance(t, str) else None)
            for f, t in zip(files_text, trashinfo_text, strict=True)
            if isinstance(f, str)
        ]
        files = [f for f, _ in paired]
        trashinfo_paths = [t for _, t in paired]

        return HistoryEntry(timestamp=datetime.fromisoformat(timestamp_text), files=files, trashinfo_paths=trashinfo_paths)

    # Legacy methods for backward compatibility with tests
    def _load_raw(self) -> list[dict[str, object]]:
        """Legacy method for backward compatibility - returns raw entries."""
        return self._db.list_recent()

    def _save_raw(self, entries: list[dict[str, object]]) -> None:
        """Legacy method - clears database and inserts provided entries."""
        self._db.clear()
        for item in entries:
            timestamp = item.get("timestamp")
            files = item.get("files", [])
            trashinfo = item.get("trashinfo_paths", [])

            if isinstance(timestamp, str) and isinstance(files, list) and isinstance(trashinfo, list):
                files_str = [str(f) if isinstance(f, (str, Path)) else f for f in files]
                # Convert Path objects in trashinfo to strings
                trashinfo_str = []
                for t in trashinfo:
                    if t is None:
                        trashinfo_str.append(None)
                    elif isinstance(t, (str, Path)):
                        trashinfo_str.append(str(t))
                    else:
                        trashinfo_str.append(t)

                self._db.record(files_str, trashinfo_str, datetime.fromisoformat(timestamp) if isinstance(timestamp, str) else None)