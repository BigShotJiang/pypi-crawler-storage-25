"""SQLite backend for deletion history tracking with atomic writes."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any


class HistoryDB:
    """SQLite storage for deletion history with transaction protection."""

    # Default database path
    DEFAULT_DB_PATH = Path.home() / ".local/share/rmsafe/history.db"

    # Old JSON path for migration
    OLD_JSON_PATH = Path.home() / ".local/share/rmsafe/history.json"

    def __init__(self, db_path: Path | None = None, max_entries: int = 100):
        """Initialize the SQLite history database.

        Args:
            db_path: Path to SQLite database file. Uses default if None.
            max_entries: Maximum number of entries to keep.
        """
        self.db_path = (db_path or self.DEFAULT_DB_PATH).expanduser()
        self.max_entries = max_entries
        self._init_db()
        self._migrate_from_json()

    def _init_db(self) -> None:
        """Create database and table if they don't exist."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    files_json TEXT NOT NULL,
                    trashinfo_json TEXT NOT NULL
                )
                """
            )
            # Create index for efficient ordering by timestamp
            conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_history_timestamp
                ON history(timestamp)
                """
            )
            conn.commit()

    def _migrate_from_json(self) -> None:
        """Migrate old JSON history file to SQLite if it exists."""
        old_json_path = self.OLD_JSON_PATH.expanduser()

        if not old_json_path.exists():
            return

        try:
            content = old_json_path.read_text(encoding="utf-8")
            data = json.loads(content)

            if not isinstance(data, list):
                return

            # Check if we already have entries (migration already done)
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.execute("SELECT COUNT(*) FROM history")
                count = cursor.fetchone()[0]
                if count > 0:
                    # Already migrated, delete old JSON
                    old_json_path.unlink()
                    return

            # Insert all entries from JSON
            entries_to_insert = []
            for item in data:
                if not isinstance(item, dict):
                    continue

                timestamp = item.get("timestamp")
                files = item.get("files", [])
                trashinfo = item.get("trashinfo_paths", [])

                if not isinstance(timestamp, str):
                    continue
                if not isinstance(files, list) or not isinstance(trashinfo, list):
                    continue

                entries_to_insert.append(
                    (timestamp, json.dumps(files), json.dumps(trashinfo))
                )

            if entries_to_insert:
                with sqlite3.connect(self.db_path) as conn:
                    conn.executemany(
                        """
                        INSERT INTO history (timestamp, files_json, trashinfo_json)
                        VALUES (?, ?, ?)
                        """,
                        entries_to_insert,
                    )
                    conn.commit()

            # Delete old JSON after successful migration
            old_json_path.unlink()

        except (OSError, json.JSONDecodeError, sqlite3.Error):
            # Migration failed - keep JSON file for manual recovery
            pass

    def record(
        self,
        files: list[str],
        trashinfo_paths: list[str | None],
        timestamp: datetime | None = None,
    ) -> None:
        """Record a deletion event with atomic transaction.

        Args:
            files: List of file paths as strings.
            trashinfo_paths: List of trashinfo paths (or None).
            timestamp: Timestamp of deletion, uses now if None.
        """
        if not files:
            return

        ts = (timestamp or datetime.now()).replace(microsecond=0).isoformat()
        files_json = json.dumps(files, ensure_ascii=False)
        trashinfo_json = json.dumps(trashinfo_paths, ensure_ascii=False)

        with sqlite3.connect(self.db_path) as conn:
            # Insert new entry
            conn.execute(
                """
                INSERT INTO history (timestamp, files_json, trashinfo_json)
                VALUES (?, ?, ?)
                """,
                (ts, files_json, trashinfo_json),
            )

            # Enforce max_entries limit if set
            if self.max_entries > 0:
                conn.execute(
                    """
                    DELETE FROM history
                    WHERE id NOT IN (
                        SELECT id FROM history
                        ORDER BY timestamp DESC, id DESC
                        LIMIT ?
                    )
                    """,
                    (self.max_entries,),
                )

            conn.commit()

    def list_recent(self, limit: int | None = None) -> list[dict[str, Any]]:
        """Return recent deletion entries, newest first.

        Args:
            limit: Maximum entries to return, None for all.

        Returns:
            List of entry dicts with timestamp, files, trashinfo_paths.
        """
        with sqlite3.connect(self.db_path) as conn:
            if limit is None:
                cursor = conn.execute(
                    """
                    SELECT timestamp, files_json, trashinfo_json
                    FROM history
                    ORDER BY timestamp DESC, id DESC
                    """
                )
            else:
                cursor = conn.execute(
                    """
                    SELECT timestamp, files_json, trashinfo_json
                    FROM history
                    ORDER BY timestamp DESC, id DESC
                    LIMIT ?
                    """,
                    (limit,),
                )

            results = []
            for row in cursor.fetchall():
                timestamp, files_json, trashinfo_json = row
                results.append({
                    "timestamp": timestamp,
                    "files": json.loads(files_json),
                    "trashinfo_paths": json.loads(trashinfo_json),
                })

            return results

    def pop_last(self, count: int = 1) -> list[dict[str, Any]]:
        """Remove and return the most recent entries.

        Args:
            count: Number of entries to pop.

        Returns:
            List of popped entry dicts, newest first.
        """
        if count < 1:
            return []

        with sqlite3.connect(self.db_path) as conn:
            # Get entries to pop (newest first)
            cursor = conn.execute(
                """
                SELECT id, timestamp, files_json, trashinfo_json
                FROM history
                ORDER BY timestamp DESC, id DESC
                LIMIT ?
                """,
                (count,),
            )

            rows = cursor.fetchall()
            if not rows:
                return []

            ids_to_delete = [row[0] for row in rows]

            # Delete the entries
            conn.execute(
                """
                DELETE FROM history
                WHERE id IN ({})
                """.format(",".join("?" * len(ids_to_delete))),
                ids_to_delete,
            )
            conn.commit()

            # Return popped entries as dicts
            results = []
            for row in rows:
                _, timestamp, files_json, trashinfo_json = row
                results.append({
                    "timestamp": timestamp,
                    "files": json.loads(files_json),
                    "trashinfo_paths": json.loads(trashinfo_json),
                })

            return results

    def count(self) -> int:
        """Return total number of entries."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT COUNT(*) FROM history")
            return cursor.fetchone()[0]

    def clear(self) -> None:
        """Remove all entries."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("DELETE FROM history")
            conn.commit()

    def prune(self) -> None:
        """Enforce max_entries limit on existing data."""
        if self.max_entries <= 0:
            return

        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                """
                DELETE FROM history
                WHERE id NOT IN (
                    SELECT id FROM history
                    ORDER BY timestamp DESC, id DESC
                    LIMIT ?
                )
                """,
                (self.max_entries,),
            )
            conn.commit()