"""FreeDesktop.org trash info file handling."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


@dataclass(slots=True)
class TrashInfo:
    """Metadata stored alongside a trashed file."""

    original_path: Path
    deletion_date: datetime

    def render(self) -> str:
        """Render the trash info file contents."""

        return (
            "[Trash Info]\n"
            f"Path={self.original_path}\n"
            f"DeletionDate={self.deletion_date.replace(microsecond=0).isoformat(timespec='seconds')}\n"
        )


def write_trashinfo(info_path: Path, original_path: Path, deletion_date: datetime | None = None) -> None:
    """Write a ``.trashinfo`` file."""

    info_path.parent.mkdir(parents=True, exist_ok=True)
    info = TrashInfo(original_path=original_path.absolute(), deletion_date=deletion_date or datetime.now())
    info_path.write_text(info.render(), encoding="utf-8")


def parse_trashinfo(info_path: Path) -> TrashInfo:
    """Parse a FreeDesktop.org ``.trashinfo`` file."""

    path_text: str | None = None
    deletion_text: str | None = None

    for raw_line in info_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if line.startswith("Path="):
            path_text = line.removeprefix("Path=")
        elif line.startswith("DeletionDate="):
            deletion_text = line.removeprefix("DeletionDate=")

    if not path_text or not deletion_text:
        raise ValueError(f"Invalid trashinfo file: {info_path}")

    parsed_date = datetime.fromisoformat(deletion_text.replace("Z", "+00:00"))
    return TrashInfo(original_path=Path(path_text), deletion_date=parsed_date)
