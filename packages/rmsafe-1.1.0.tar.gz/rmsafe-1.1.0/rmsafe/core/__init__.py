"""Core domain logic for rmsafe."""

from .trash_manager import TrashManager, TrashResult
from .history_tracker import HistoryEntry, HistoryTracker
from .trashinfo import TrashInfo, write_trashinfo

__all__ = ["HistoryEntry", "HistoryTracker", "TrashInfo", "TrashManager", "TrashResult", "write_trashinfo"]
