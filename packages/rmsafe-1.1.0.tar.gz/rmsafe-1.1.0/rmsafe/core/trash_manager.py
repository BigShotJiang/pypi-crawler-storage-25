"""Core trash operations for rmsafe."""

from __future__ import annotations

import contextlib
import os
import sys
import shutil
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterator

from ..platform.btrfs import trash_file_with_btrfs_support
from .trashinfo import write_trashinfo, parse_trashinfo
from ..utils.size import format_size
from ..utils.filelock import FileLock, LockTimeout


@dataclass(slots=True)
class TrashResult:
    """Result for a trash operation."""

    source: Path
    destination: Path | None
    info_path: Path | None
    size_bytes: int | None
    size_text: str | None
    dry_run: bool
    success: bool
    message: str
    error: str | None = None


@dataclass(slots=True)
class OrphanEntry:
    """Represents an orphaned entry in trash."""

    path: Path
    orphan_type: str  # "file" or "info"
    message: str


@dataclass(slots=True)
class ConsistencyReport:
    """Result of trash consistency verification."""

    consistent: bool
    orphan_files: list[Path]  # files without .trashinfo
    orphan_infos: list[Path]  # .trashinfo files without corresponding files
    missing_infos: list[Path]  # files that should have .trashinfo but don't
    errors: list[str]


class TrashManager:
    """Move files and directories into a trash location.

    Uses advisory file locking to prevent race conditions when multiple
    processes operate on the same trash directory simultaneously.

    Lock file is stored at ``trash_dir/.lock``. The lock is acquired
    before any operation that modifies the trash directory state.
    """

    def __init__(self, trash_dir: Path, lock_timeout: float | None = None):
        """Initialize the trash manager.

        Args:
            trash_dir: Path to the trash directory.
            lock_timeout: Maximum seconds to wait for lock acquisition.
                         None = block indefinitely (default).
                         0 = non-blocking, raise LockTimeout if locked.
                         >0 = wait up to this many seconds.
        """
        self.trash_dir = trash_dir.expanduser()
        self._mac_style = self._is_mac_trash(self.trash_dir)
        self.files_dir = self.trash_dir if self._mac_style else self.trash_dir / "files"
        self.info_dir = None if self._mac_style else self.trash_dir / "info"
        self._lock_timeout = lock_timeout
        self._lock: FileLock | None = None

    def _get_lock(self) -> FileLock:
        """Get or create the file lock for this trash directory."""
        if self._lock is None:
            lock_path = self.trash_dir / ".lock"
            self._lock = FileLock(lock_path, timeout=self._lock_timeout)
        return self._lock

    def acquire_lock(self, timeout: float | None = None) -> None:
        """Acquire the trash directory lock.

        Args:
            timeout: Override the instance timeout. Uses instance timeout if None.

        Raises:
            LockTimeout: If lock cannot be acquired within timeout.
        """
        # Ensure trash directory exists before creating lock file
        self.trash_dir.mkdir(parents=True, exist_ok=True)
        self._get_lock().acquire(timeout)

    def release_lock(self) -> None:
        """Release the trash directory lock."""
        if self._lock is not None and self._lock.is_locked:
            self._lock.release()

    @contextlib.contextmanager
    def _with_lock(self) -> Iterator[None]:
        """Context manager that acquires and releases the lock.

        Ensures the trash directory exists before acquiring the lock,
        since the lock file is stored inside it.
        """
        # Ensure trash directory exists before creating lock file inside it
        self.trash_dir.mkdir(parents=True, exist_ok=True)
        lock = self._get_lock()
        lock.acquire()
        try:
            yield
        finally:
            lock.release()

    def trash_file(self, src: Path, dry_run: bool = False) -> TrashResult:
        """Trash a file."""

        return self._trash_path(src, dry_run=dry_run)

    def trash_directory(self, src: Path, dry_run: bool = False) -> TrashResult:
        """Trash a directory."""

        return self._trash_path(src, dry_run=dry_run)

    def _trash_path(self, src: Path, dry_run: bool = False) -> TrashResult:
        source = src.expanduser()
        # Check if path exists OR is a symlink (symlinks can be "broken" - target doesn't exist)
        if not source.exists() and not source.is_symlink():
            return TrashResult(source, None, None, None, None, dry_run, False, f"{source} does not exist")

        size_bytes = self._get_size(source)
        size_text = None if size_bytes is None else format_size(size_bytes)

        if dry_run:
            # For dry run, compute destination name without lock (doesn't modify state)
            dest_name = self._get_unique_name(source.name)
            destination = self.files_dir / dest_name
            info_path = None if self.info_dir is None else self.info_dir / f"{dest_name}.trashinfo"
            return TrashResult(source, destination, info_path, size_bytes, size_text, True, True, self._message(source, destination, size_text))

        # Acquire lock for actual operation
        try:
            with self._with_lock():
                # Ensure directories exist (must be within lock)
                self._ensure_directories()

                # Re-compute unique name within lock to prevent race conditions
                dest_name = self._get_unique_name(source.name)
                destination = self.files_dir / dest_name
                info_path = None if self.info_dir is None else self.info_dir / f"{dest_name}.trashinfo"

                # ERROR RECOVERY: Write trashinfo BEFORE moving the file
                # If trashinfo write fails, we don't attempt the move
                if info_path is not None:
                    try:
                        self._create_trashinfo(source, dest_name)
                    except (OSError, PermissionError) as exc:
                        return TrashResult(
                            source, destination, info_path, size_bytes, size_text,
                            False, False, f"Failed to write trashinfo for {source}", str(exc)
                        )

                # Now attempt to move the file
                try:
                    # Handle symlinks, files, and directories appropriately
                    # - Symlinks (including broken ones) and regular files use shutil.move
                    # - Directories use shutil.move
                    # Note: is_file() follows symlinks, so check is_symlink() first
                    if source.is_symlink() or source.is_file():
                        if sys.platform.startswith("linux"):
                            trash_file_with_btrfs_support(source, destination)
                        else:
                            shutil.move(str(source), str(destination))
                    else:
                        shutil.move(str(source), str(destination))
                except (OSError, PermissionError) as exc:
                    # ERROR RECOVERY: Move failed - clean up orphaned trashinfo
                    if info_path is not None and info_path.exists():
                        try:
                            info_path.unlink()
                        except OSError:
                            # Best effort cleanup - don't mask the original error
                            pass
                    return TrashResult(
                        source, destination, info_path, size_bytes, size_text,
                        False, False, f"Failed to trash {source}", str(exc)
                    )

        except LockTimeout as exc:
            return TrashResult(
                source, None, None, size_bytes, size_text,
                False, False, f"Could not acquire lock on trash directory", str(exc)
            )
        except PermissionError as exc:
            return TrashResult(source, None, None, size_bytes, size_text, False, False, f"Permission denied: {source}", str(exc))
        except OSError as exc:
            return TrashResult(source, None, None, size_bytes, size_text, False, False, f"Failed to trash {source}", str(exc))

        return TrashResult(source, destination, info_path, size_bytes, size_text, False, True, self._message(source, destination, size_text))

    def _get_unique_name(self, name: str) -> str:
        """Return a non-conflicting destination name."""

        candidate = name
        counter = 1
        while (self.files_dir / candidate).exists():
            candidate = self._append_suffix(name, counter)
            counter += 1
        return candidate

    def _create_trashinfo(self, src: Path, dest_name: str) -> None:
        """Create the matching ``.trashinfo`` file."""

        if self.info_dir is None:
            return
        write_trashinfo(self.info_dir / f"{dest_name}.trashinfo", src, deletion_date=datetime.now())

    def _ensure_directories(self) -> None:
        self.files_dir.mkdir(parents=True, exist_ok=True)
        if self.info_dir is not None:
            self.info_dir.mkdir(parents=True, exist_ok=True)

    def _get_size(self, src: Path) -> int | None:
        try:
            # Symlinks don't have meaningful file size
            if src.is_symlink():
                return None
            return src.stat().st_size if src.is_file() else None
        except OSError:
            return None

    def _message(self, source: Path, destination: Path, size_text: str | None) -> str:
        size_part = f" ({size_text})" if size_text else ""
        return f"{source.name}{size_part} → {self._trash_root_for(destination)}"

    def _trash_root_for(self, destination: Path) -> Path:
        if self.info_dir is None:
            return destination.parent
        return destination.parent.parent

    @staticmethod
    def _append_suffix(name: str, index: int) -> str:
        path = Path(name)
        suffixes = "".join(path.suffixes)
        stem = name[: -len(suffixes)] if suffixes else name
        return f"{stem}_{index}{suffixes}"

    def names_match(self, expected: str, actual: str) -> bool:
        """Return whether two trash entry names should be treated as equal."""

        if expected == actual:
            return True
        return self._mac_style and expected.casefold() == actual.casefold()

    @staticmethod
    def _is_mac_trash(trash_dir: Path) -> bool:
        return sys.platform == "darwin" and trash_dir.name == ".Trash"

    # ========================================================================
    # Error Recovery and Consistency Methods
    # ========================================================================

    def verify_trash_consistency(self) -> ConsistencyReport:
        """
        Verify consistency between trash files and .trashinfo files.

        Returns a ConsistencyReport with:
        - orphan_files: Files in files/ without corresponding .trashinfo
        - orphan_infos: .trashinfo files without corresponding files
        - missing_infos: Files that should have .trashinfo (mac-style never has info)
        """
        orphan_files: list[Path] = []
        orphan_infos: list[Path] = []
        missing_infos: list[Path] = []
        errors: list[str] = []

        # macOS .Trash style doesn't use .trashinfo files
        if self._mac_style:
            return ConsistencyReport(
                consistent=True,
                orphan_files=[],
                orphan_infos=[],
                missing_infos=[],
                errors=[]
            )

        # Ensure directories exist
        if not self.files_dir.exists() or not self.info_dir.exists():
            return ConsistencyReport(
                consistent=True,  # Empty trash is consistent
                orphan_files=[],
                orphan_infos=[],
                missing_infos=[],
                errors=[]
            )

        # Build sets of file names (without extensions for info files)
        try:
            file_entries = set()
            for entry in self.files_dir.iterdir():
                if entry.name not in (".", ".."):
                    file_entries.add(entry.name)

            info_entries = set()
            for entry in self.info_dir.iterdir():
                if entry.name.endswith(".trashinfo"):
                    # Strip .trashinfo extension
                    info_entries.add(entry.name[:-10])
                elif entry.name not in (".", ".."):
                    # Non-trashinfo file in info dir
                    orphan_infos.append(entry)

            # Find orphan files (no corresponding .trashinfo)
            for name in file_entries:
                if name not in info_entries:
                    orphan_files.append(self.files_dir / name)

            # Find orphan info files (no corresponding file)
            for name in info_entries:
                if name not in file_entries:
                    orphan_infos.append(self.info_dir / f"{name}.trashinfo")

            # All files should have info files in standard layout
            for name in file_entries:
                if name not in info_entries:
                    missing_infos.append(self.files_dir / name)

        except OSError as e:
            errors.append(f"Error scanning trash directories: {e}")

        return ConsistencyReport(
            consistent=len(orphan_files) == 0 and len(orphan_infos) == 0,
            orphan_files=orphan_files,
            orphan_infos=orphan_infos,
            missing_infos=missing_infos,
            errors=errors
        )

    def cleanup_orphans(self, *, delete_orphan_files: bool = False, delete_orphan_infos: bool = False) -> list[OrphanEntry]:
        """
        Find and optionally clean up orphaned entries in trash.

        Orphan files: Files in files/ without corresponding .trashinfo
        Orphan infos: .trashinfo files without corresponding files

        Args:
            delete_orphan_files: If True, delete orphan files in files/
            delete_orphan_infos: If True, delete orphan .trashinfo files

        Returns:
            List of OrphanEntry describing what was found/deleted
        """
        results: list[OrphanEntry] = []

        # macOS .Trash style doesn't use .trashinfo files
        if self._mac_style:
            return results

        # Ensure directories exist
        if not self.files_dir.exists() or not self.info_dir.exists():
            return results

        # Build sets of names
        try:
            file_entries = set()
            for entry in self.files_dir.iterdir():
                if entry.name not in (".", ".."):
                    file_entries.add(entry.name)

            info_entries = set()
            for entry in self.info_dir.iterdir():
                if entry.name.endswith(".trashinfo"):
                    info_entries.add(entry.name[:-10])
                elif entry.name not in (".", ".."):
                    # Non-trashinfo file in info directory
                    orphan_path = self.info_dir / entry.name
                    results.append(OrphanEntry(
                        path=orphan_path,
                        orphan_type="info",
                        message=f"Non-trashinfo file in info directory: {entry.name}"
                    ))
                    if delete_orphan_infos:
                        try:
                            orphan_path.unlink()
                        except OSError:
                            pass

            # Find and handle orphan files
            for name in file_entries:
                if name not in info_entries:
                    orphan_path = self.files_dir / name
                    results.append(OrphanEntry(
                        path=orphan_path,
                        orphan_type="file",
                        message=f"Orphan file without .trashinfo: {name}"
                    ))
                    if delete_orphan_files:
                        try:
                            if orphan_path.is_dir():
                                shutil.rmtree(orphan_path)
                            else:
                                orphan_path.unlink()
                        except OSError:
                            pass

            # Find and handle orphan info files
            for name in info_entries:
                if name not in file_entries:
                    orphan_path = self.info_dir / f"{name}.trashinfo"
                    results.append(OrphanEntry(
                        path=orphan_path,
                        orphan_type="info",
                        message=f"Orphan .trashinfo without file: {name}"
                    ))
                    if delete_orphan_infos:
                        try:
                            orphan_path.unlink()
                        except OSError:
                            pass

        except OSError as e:
            results.append(OrphanEntry(
                path=self.trash_dir,
                orphan_type="error",
                message=f"Error scanning trash: {e}"
            ))

        return results

    def iter_trash_entries(self) -> Iterator[tuple[Path, Path | None]]:
        """
        Iterate over trash entries, yielding (file_path, info_path) tuples.

        For macOS .Trash style, info_path is always None.
        Only yields entries that have both file and info (if applicable).
        """
        if not self.files_dir.exists():
            return

        if self._mac_style:
            # macOS style: no info files
            for entry in self.files_dir.iterdir():
                if entry.name not in (".", ".."):
                    yield (entry, None)
            return

        # Standard style: require both file and info
        if not self.info_dir.exists():
            return

        for entry in self.files_dir.iterdir():
            if entry.name in (".", ".."):
                continue
            info_path = self.info_dir / f"{entry.name}.trashinfo"
            if info_path.exists():
                yield (entry, info_path)
