"""TTY detection utilities for rmsafe."""

from __future__ import annotations

import sys
from typing import IO


def is_tty(stream: IO[str] = sys.stdout) -> bool:
    """Return ``True`` when *stream* is attached to a terminal."""

    isatty = getattr(stream, "isatty", None)
    return bool(isatty()) if callable(isatty) else False


def should_use_color(color_setting: str = "auto") -> bool:
    """Decide whether colored output should be enabled.

    ``NO_COLOR`` always disables color. ``always`` forces color, ``never``
    disables it, and ``auto`` enables color only when stdout is a TTY.
    """

    import os

    if "NO_COLOR" in os.environ:
        return False

    setting = color_setting.strip().lower()
    if setting == "always":
        return True
    if setting == "never":
        return False
    if setting == "auto":
        return is_tty(sys.stdout)

    raise ValueError(f"Unsupported color setting: {color_setting!r}")
