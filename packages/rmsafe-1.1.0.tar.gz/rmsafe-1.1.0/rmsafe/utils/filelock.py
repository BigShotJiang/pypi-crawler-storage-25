"""Cross-platform file locking for rmsafe.

Provides advisory file locks using:
- fcntl.flock on Unix (including macOS)
- msvcrt.locking on Windows

Supports both blocking (with optional timeout) and non-blocking modes.
"""

from __future__ import annotations

import contextlib
import os
import sys
import time
from pathlib import Path
from typing import Generator

if sys.platform == "win32":
    import msvcrt
else:
    import fcntl


class FileLockError(Exception):
    """Base exception for file lock errors."""

    pass


class LockTimeout(FileLockError):
    """Raised when a lock cannot be acquired within the specified timeout."""

    pass


class FileLock:
    """Cross-platform advisory file lock.

    Usage with context manager (recommended)::

        lock = FileLock("/path/to/.lock")
        with lock:
            # Critical section - lock is held
            pass
        # Lock is released automatically

    Usage with explicit acquire/release::

        lock = FileLock("/path/to/.lock", timeout=5.0)
        lock.acquire()
        try:
            # Critical section
            pass
        finally:
            lock.release()

    Args:
        path: Path to the lock file. Parent directories must exist.
        timeout: Maximum seconds to wait for the lock.
                 None = block indefinitely (default).
                 0 = non-blocking, raise LockTimeout immediately if locked.
                 >0 = wait up to this many seconds.
    """

    def __init__(self, path: Path | str, timeout: float | None = None):
        self._path = Path(path)
        self._timeout = timeout
        self._fd: int | None = None
        self._locked = False

    @property
    def path(self) -> Path:
        """The lock file path."""
        return self._path

    @property
    def is_locked(self) -> bool:
        """Whether this instance currently holds the lock."""
        return self._locked

    def acquire(self, timeout: float | None = None) -> bool:
        """Acquire the lock.

        Args:
            timeout: Override the instance timeout. Uses instance timeout if None.

        Returns:
            True if lock was acquired.

        Raises:
            LockTimeout: If lock cannot be acquired within timeout.
            FileLockError: If lock acquisition fails for other reasons.
        """
        if self._locked:
            return True

        effective_timeout = timeout if timeout is not None else self._timeout

        # Open/create the lock file
        try:
            # O_RDWR for read/write, O_CREAT to create if not exists
            # On Windows, we need O_BINARY for binary mode
            if sys.platform == "win32":
                self._fd = os.open(self._path, os.O_RDWR | os.O_CREAT | os.O_BINARY, 0o644)  # type: ignore[attr-defined]
            else:
                self._fd = os.open(self._path, os.O_RDWR | os.O_CREAT, 0o644)
        except OSError as exc:
            raise FileLockError(f"Cannot create lock file {self._path}: {exc}") from exc

        if effective_timeout is None:
            # Block indefinitely
            self._do_lock(blocking=True)
            self._locked = True
            return True

        if effective_timeout == 0:
            # Non-blocking
            try:
                self._do_lock(blocking=False)
                self._locked = True
                return True
            except (IOError, OSError):
                self._close_fd()
                raise LockTimeout(f"Lock {self._path} is held by another process")

        # Wait with timeout
        deadline = time.monotonic() + effective_timeout
        while True:
            try:
                self._do_lock(blocking=False)
                self._locked = True
                return True
            except (IOError, OSError):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    self._close_fd()
                    raise LockTimeout(
                        f"Could not acquire lock {self._path} within {effective_timeout}s"
                    )
                time.sleep(min(0.05, remaining))  # Poll every 50ms max

    def release(self) -> None:
        """Release the lock.

        Raises:
            FileLockError: If lock is not held or release fails.
        """
        if not self._locked:
            raise FileLockError(f"Lock {self._path} is not held by this instance")

        if self._fd is None:
            raise FileLockError(f"Lock {self._path} has no open file descriptor")

        try:
            self._do_unlock()
        finally:
            self._close_fd()
            self._locked = False

    def _do_lock(self, blocking: bool) -> None:
        """Platform-specific lock acquisition."""
        if self._fd is None:
            raise FileLockError("No file descriptor available")

        if sys.platform == "win32":
            # Windows: msvcrt.locking
            # LK_NBLCK = non-blocking lock
            # LK_LOCK = blocking lock (but has 10s default timeout, so we poll)
            mode = msvcrt.LK_NBLCK
            try:
                msvcrt.locking(self._fd, mode, 1)  # type: ignore[arg-type]
            except OSError:
                if blocking:
                    raise
                raise LockTimeout("Lock is held by another process")
        else:
            # Unix: fcntl.flock
            # LOCK_SH = shared lock
            # LOCK_EX = exclusive lock
            # LOCK_NB = non-blocking
            operation = fcntl.LOCK_EX
            if not blocking:
                operation |= fcntl.LOCK_NB
            fcntl.flock(self._fd, operation)

    def _do_unlock(self) -> None:
        """Platform-specific lock release."""
        if self._fd is None:
            return

        if sys.platform == "win32":
            msvcrt.locking(self._fd, msvcrt.LK_UNLCK, 1)  # type: ignore[arg-type]
        else:
            fcntl.flock(self._fd, fcntl.LOCK_UN)

    def _close_fd(self) -> None:
        """Close the file descriptor if open."""
        if self._fd is not None:
            with contextlib.suppress(OSError):
                os.close(self._fd)
            self._fd = None

    def __enter__(self) -> "FileLock":
        """Context manager entry."""
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # type: ignore[no-untyped-def]
        """Context manager exit."""
        if self._locked:
            self.release()

    def __del__(self) -> None:
        """Cleanup on garbage collection."""
        if self._locked:
            self._close_fd()
            self._locked = False


class AtomicRename:
    """Atomic file operations using rename.

    Provides a simple way to atomically write files:
    - Write to a temporary file
    - Atomically rename to final destination

    This is useful for ensuring that concurrent processes don't see
    partially written files.
    """

    @staticmethod
    def write_file(path: Path | str, content: str | bytes, *, encoding: str = "utf-8") -> None:
        """Write content to path atomically.

        Args:
            path: Destination file path.
            content: String or bytes to write.
            encoding: Encoding for string content (default utf-8).
        """
        dest = Path(path)
        temp_path = dest.with_suffix(dest.suffix + ".tmp")

        try:
            if isinstance(content, bytes):
                temp_path.write_bytes(content)
            else:
                temp_path.write_text(content, encoding=encoding)

            # Atomic rename (POSIX guarantees atomicity)
            temp_path.replace(dest)
        finally:
            # Cleanup temp file if it still exists
            with contextlib.suppress(OSError):
                temp_path.unlink()


@contextlib.contextmanager
def atomic_file(path: Path | str, *, encoding: str = "utf-8") -> Generator[Path, None, None]:
    """Context manager for atomic file writes.

    Yields a temporary path for writing, then atomically renames to
    the final destination on successful exit.

    Usage::

        with atomic_file("/path/to/file.txt") as temp_path:
            temp_path.write_text("content")
        # File is now atomically written to /path/to/file.txt
    """
    dest = Path(path)
    temp_path = dest.with_suffix(dest.suffix + ".tmp")

    try:
        yield temp_path
        # Atomic rename on success
        temp_path.replace(dest)
    finally:
        # Cleanup temp file on failure
        with contextlib.suppress(OSError):
            temp_path.unlink()