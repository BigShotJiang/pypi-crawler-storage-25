"""File size formatting helpers for rmsafe."""

from __future__ import annotations

import os
import re
from pathlib import Path


_UNITS = ("bytes", "KB", "MB", "GB", "TB")
_SIZE_RE = re.compile(r"^(\d+(?:\.\d+)?)(B|KB|MB|GB|TB)$", re.IGNORECASE)


def format_size(num_bytes: int) -> str:
    """Format *num_bytes* using human-readable binary units."""

    if num_bytes < 0:
        raise ValueError("num_bytes must be >= 0")
    if num_bytes == 1:
        return "1 byte"
    if num_bytes < 1024:
        return f"{num_bytes} bytes"

    value = float(num_bytes)
    unit_index = 0
    while value >= 1024 and unit_index < len(_UNITS) - 1:
        value /= 1024
        unit_index += 1

    if value.is_integer():
        text = str(int(value))
    else:
        text = f"{value:.1f}".rstrip("0").rstrip(".")
    return f"{text} {_UNITS[unit_index]}"


def parse_size(size: str) -> int:
    """Parse a binary size string like ``10MB`` into bytes."""

    if not isinstance(size, str):
        raise ValueError("size must be a string like '10MB'")

    normalized = size.strip().upper().replace(" ", "")
    match = _SIZE_RE.match(normalized)
    if not match:
        raise ValueError("size must look like '10MB', '500KB', or '1.5GB'")

    value = float(match.group(1))
    unit = match.group(2).upper()
    multiplier = {
        "B": 1,
        "KB": 1024,
        "MB": 1024**2,
        "GB": 1024**3,
        "TB": 1024**4,
    }[unit]
    return int(value * multiplier)


def path_size(path: Path) -> int:
    """Return total size in bytes for a file, symlink, or directory tree."""

    if path.is_symlink():
        try:
            return path.lstat().st_size
        except OSError:
            return 0
    if path.is_file():
        try:
            return path.stat().st_size
        except OSError:
            return 0
    if not path.is_dir():
        return 0

    total = 0
    for dirpath, _dirnames, filenames in os.walk(path, followlinks=False):
        for name in filenames:
            try:
                total += os.lstat(os.path.join(dirpath, name)).st_size
            except OSError:
                continue
    return total
