"""Comprehensive tests for commands/trash.py following SQLite test philosophy."""
from __future__ import annotations

import signal
import sys
from io import StringIO
from pathlib import Path

import pytest

from rmsafe.commands.trash import (
    run,
    _format_success,
    _needs_large_file_confirm,
    _confirm_large_file,
)
from rmsafe.output.colors import Color, ColorManager
from rmsafe.output.icons import Icon, IconManager


class TestNeedsLargeFileConfirm:
    """_needs_large_file_confirm() - every threshold, every file type."""

    def test_below_threshold(self, tmp_path: Path) -> None:
        src = tmp_path / "small.txt"
        src.write_text("x" * 100, encoding="utf-8")
        result = _needs_large_file_confirm(src, 1000, dry_run=False, no_confirm=False)
        assert result is False

    def test_above_threshold(self, tmp_path: Path) -> None:
        src = tmp_path / "large.txt"
        src.write_text("x" * 2000, encoding="utf-8")
        result = _needs_large_file_confirm(src, 1000, dry_run=False, no_confirm=False)
        assert result is True

    def test_exactly_at_threshold(self, tmp_path: Path) -> None:
        src = tmp_path / "exact.txt"
        src.write_text("x" * 1000, encoding="utf-8")
        result = _needs_large_file_confirm(src, 1000, dry_run=False, no_confirm=False)
        assert result is False  # > threshold, not >=

    def test_dry_run_skips_confirm(self, tmp_path: Path) -> None:
        src = tmp_path / "large.txt"
        src.write_text("x" * 2000, encoding="utf-8")
        result = _needs_large_file_confirm(src, 1000, dry_run=True, no_confirm=False)
        assert result is False

    def test_no_confirm_skips_check(self, tmp_path: Path) -> None:
        src = tmp_path / "large.txt"
        src.write_text("x" * 2000, encoding="utf-8")
        result = _needs_large_file_confirm(src, 1000, dry_run=False, no_confirm=True)
        assert result is False

    def test_directory_never_confirms(self, tmp_path: Path) -> None:
        dir_path = tmp_path / "large_dir"
        dir_path.mkdir()
        (dir_path / "file.txt").write_text("x" * 2000, encoding="utf-8")
        result = _needs_large_file_confirm(dir_path, 100, dry_run=False, no_confirm=False)
        assert result is False  # Only files trigger confirm

    def test_nonexistent_file_returns_false(self, tmp_path: Path) -> None:
        src = tmp_path / "nonexistent.txt"
        result = _needs_large_file_confirm(src, 100, dry_run=False, no_confirm=False)
        assert result is False

    @pytest.mark.skip(reason="Linux and macOS both allow owner to stat files regardless of permission bits")
    def test_permission_denied_returns_false(self, tmp_path: Path) -> None:
        import os
        src = tmp_path / "secret.txt"
        src.write_text("x" * 2000, encoding="utf-8")
        os.chmod(src, 0o000)
        try:
            result = _needs_large_file_confirm(src, 100, dry_run=False, no_confirm=False)
            assert result is False
        finally:
            os.chmod(src, 0o644)

    def test_zero_threshold(self, tmp_path: Path) -> None:
        src = tmp_path / "any.txt"
        src.write_text("x", encoding="utf-8")
        result = _needs_large_file_confirm(src, 0, dry_run=False, no_confirm=False)
        assert result is True  # Any size > 0

    def test_empty_file_zero_threshold(self, tmp_path: Path) -> None:
        src = tmp_path / "empty.txt"
        src.write_text("", encoding="utf-8")
        result = _needs_large_file_confirm(src, 0, dry_run=False, no_confirm=False)
        assert result is False  # Size is 0, not > 0

    def test_symlink_returns_false(self, tmp_path: Path) -> None:
        target = tmp_path / "target.txt"
        target.write_text("x" * 2000, encoding="utf-8")
        link = tmp_path / "link.txt"
        link.symlink_to(target)
        # Symlink size is size of link itself, not target
        result = _needs_large_file_confirm(link, 100, dry_run=False, no_confirm=False)
        # Symlink stat gives link size (small), not target
        assert isinstance(result, bool)


class TestFormatSuccess:
    """_format_success() - every result type."""

    def test_basic_success(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashResult
        from rmsafe.output.colors import ColorManager

        result = TrashResult(
            source=tmp_path / "file.txt",
            destination=tmp_path / "Trash" / "files" / "file.txt",
            info_path=tmp_path / "Trash" / "info" / "file.txt.trashinfo",
            size_bytes=100,
            size_text="100 bytes",
            dry_run=False,
            success=True,
            message="trashed",
        )
        colors = ColorManager("never")
        output = _format_success(result, colors)
        assert "file.txt" in output
        assert "100 bytes" in output

    def test_dry_run_prefix(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashResult
        from rmsafe.output.colors import ColorManager

        result = TrashResult(
            source=tmp_path / "file.txt",
            destination=tmp_path / "Trash" / "files" / "file.txt",
            info_path=tmp_path / "Trash" / "info" / "file.txt.trashinfo",
            size_bytes=100,
            size_text="100 bytes",
            dry_run=True,
            success=True,
            message="dry run",
        )
        colors = ColorManager("never")
        output = _format_success(result, colors)
        assert "Dry run" in output

    def test_without_size(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashResult
        from rmsafe.output.colors import ColorManager

        result = TrashResult(
            source=tmp_path / "file.txt",
            destination=tmp_path / "Trash" / "files" / "file.txt",
            info_path=tmp_path / "Trash" / "info" / "file.txt.trashinfo",
            size_bytes=None,
            size_text=None,
            dry_run=False,
            success=True,
            message="trashed",
        )
        colors = ColorManager("never")
        output = _format_success(result, colors)
        assert "(" not in output  # No size part

    def test_macos_layout_no_info(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashResult
        from rmsafe.output.colors import ColorManager

        # macOS layout: info_path is None
        result = TrashResult(
            source=tmp_path / "file.txt",
            destination=tmp_path / ".Trash" / "file.txt",
            info_path=None,
            size_bytes=100,
            size_text="100 bytes",
            dry_run=False,
            success=True,
            message="trashed",
        )
        colors = ColorManager("never")
        output = _format_success(result, colors)
        # Trash root is destination.parent when no info
        assert ".Trash" in output

    def test_with_colors(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashResult
        from rmsafe.output.colors import ColorManager, Color

        result = TrashResult(
            source=tmp_path / "file.txt",
            destination=tmp_path / "Trash" / "files" / "file.txt",
            info_path=tmp_path / "Trash" / "info" / "file.txt.trashinfo",
            size_bytes=100,
            size_text="100 bytes",
            dry_run=False,
            success=True,
            message="trashed",
        )
        colors = ColorManager("always")
        output = _format_success(result, colors)
        # Contains color markup
        assert "[green]" in output or "[cyan]" in output


class TestConfirmLargeFile:
    """_confirm_large_file() - every terminal state."""

    def test_non_tty_returns_true(self, tmp_path: Path, monkeypatch) -> None:
        from rmsafe.output.colors import ColorManager

        # Mock is_tty to return False (non-TTY auto-confirms)
        monkeypatch.setattr("rmsafe.commands.trash.is_tty", lambda stream: False)

        colors = ColorManager("never")
        result = _confirm_large_file(tmp_path / "file.txt", colors)
        assert result is True  # Non-TTY auto-confirms

    def test_no_sigalrm_platform(self, tmp_path: Path, monkeypatch) -> None:
        from rmsafe.output.colors import ColorManager

        # Remove SIGALRM attribute (Windows behavior)
        monkeypatch.delattr(signal, "SIGALRM", raising=False)

        colors = ColorManager("never")
        # Would prompt, but we can't test interactive prompt
        # This test verifies the code path exists
        # In real test, would mock Confirm.ask

    def test_sigalrm_timeout_path_exists(self, tmp_path: Path) -> None:
        # Verify SIGALRM exists on Unix
        if hasattr(signal, "SIGALRM"):
            assert signal.SIGALRM is not None


class TestRun:
    """run() - every file type, every context."""

    def test_trash_single_file(self, tmp_path: Path, monkeypatch) -> None:
        from rmsafe.config.schema import Config, TrashConfig

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src], context)

        assert not src.exists()
        assert (trash_dir / "files" / "file.txt").exists()

    def test_trash_directory(self, tmp_path: Path, monkeypatch) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src_dir = tmp_path / "mydir"
        src_dir.mkdir()
        (src_dir / "file.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src_dir], context)

        assert not src_dir.exists()
        assert (trash_dir / "files" / "mydir").is_dir()

    def test_dry_run_preserves_source(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": True,
            "no_confirm": True,
        }

        run([src], context)

        assert src.exists()
        assert not (trash_dir / "files").exists()

    def test_nonexistent_file_shows_error(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "nonexistent.txt"

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        # Should print error, not raise
        run([src], context)

    def test_multiple_files(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(3):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}", encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        for f in files:
            assert not f.exists()
        assert len(list((trash_dir / "files").iterdir())) == 3

    def test_creates_color_manager_if_missing(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
            # No "colors" key
        }

        run([src], context)  # Should create ColorManager internally

    def test_empty_files_list(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([], context)  # Should do nothing

    def test_large_file_with_confirm_disabled(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "large.txt"
        src.write_text("x" * 20000, encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir
        config.behavior.confirm_large_files = "10MB"  # Large threshold

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,  # Confirm disabled
        }

        run([src], context)

        assert not src.exists()

    @pytest.mark.skip(reason="Linux and macOS both allow owner to delete files regardless of permission bits")
    def test_permission_denied_shows_error(self, tmp_path: Path) -> None:
        import os
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "secret.txt"
        src.write_text("secret", encoding="utf-8")
        os.chmod(src, 0o000)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        try:
            run([src], context)  # Should print error, not crash
        finally:
            if src.exists():
                os.chmod(src, 0o644)


class TestRunWithHistory:
    """run() with history tracking."""

    def test_records_history_on_success(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir
        config.behavior.undo_history_limit = 100

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src], context)

        # History should be recorded (would need to check history file)
        # For now, verify operation succeeded
        assert not src.exists()

    def test_dry_run_does_not_record_history(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": True,
            "no_confirm": True,
        }

        run([src], context)

        # Dry run should not record history
        assert src.exists()


class TestEdgeCases:
    """Edge cases and unusual scenarios."""

    def test_file_with_unicode_name(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "你好世界.txt"
        src.write_text("unicode content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src], context)

        assert not src.exists()
        assert (trash_dir / "files" / "你好世界.txt").exists()

    def test_file_with_spaces_in_name(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file with spaces.txt"
        src.write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src], context)

        assert not src.exists()
        assert (trash_dir / "files" / "file with spaces.txt").exists()

    def test_file_with_special_chars(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file-test_#$.txt"
        src.write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src], context)

        assert not src.exists()

    def test_nested_directory(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src_dir = tmp_path / "nested"
        inner = src_dir / "inner" / "deep"
        inner.mkdir(parents=True)
        (inner / "file.txt").write_text("nested", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src_dir], context)

        assert not src_dir.exists()
        trashed = trash_dir / "files" / "nested"
        assert (trashed / "inner" / "deep" / "file.txt").exists()

    def test_symlink_to_file(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        target = tmp_path / "target.txt"
        target.write_text("target content", encoding="utf-8")
        link = tmp_path / "link.txt"
        link.symlink_to(target)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([link], context)

        # Symlink is trashed, target remains
        assert not link.exists()
        assert target.exists()
        assert (trash_dir / "files" / "link.txt").is_symlink()

    def test_empty_directory(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src_dir = tmp_path / "empty_dir"
        src_dir.mkdir()

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src_dir], context)

        assert not src_dir.exists()
        assert (trash_dir / "files" / "empty_dir").is_dir()

    def test_conflict_naming(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        (trash_dir / "files").mkdir(parents=True)
        (trash_dir / "files" / "file.txt").write_text("existing", encoding="utf-8")

        src = tmp_path / "file.txt"
        src.write_text("new", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src], context)

        # Should create file_1.txt
        assert (trash_dir / "files" / "file_1.txt").exists()

    def test_relative_path_input(self, tmp_path: Path, monkeypatch) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        monkeypatch.chdir(tmp_path)

        run([Path("file.txt")], context)  # Relative path

        assert not src.exists()


class TestTrashWithIcons:
    """Icon integration in trash command output."""

    def test_icon_manager_icons_disabled(self) -> None:
        """When icons disabled, all icon methods return empty string."""
        manager = IconManager(use_icons=False, use_emoji=True)
        assert manager.icon(Icon.SUCCESS) == ""
        assert manager.icon(Icon.ERROR) == ""
        assert manager.icon(Icon.TRASH) == ""
        assert manager.icon(Icon.FILE) == ""
        assert manager.icon(Icon.FOLDER) == ""
        assert manager.icon(Icon.RESTORE) == ""

    def test_icon_manager_status_icons_enabled(self) -> None:
        """Status icons (SUCCESS, ERROR, WARNING, INFO) use unicode."""
        manager = IconManager(use_icons=True, use_emoji=False)
        # Status icons always use unicode regardless of emoji setting
        assert manager.icon(Icon.SUCCESS) == "✓"
        assert manager.icon(Icon.ERROR) == "✗"
        assert manager.icon(Icon.WARNING) == "⚠"
        assert manager.icon(Icon.INFO) == "ℹ"

    def test_icon_manager_emoji_enabled(self) -> None:
        """When emoji enabled, file operation icons use emoji."""
        manager = IconManager(use_icons=True, use_emoji=True)
        assert manager.icon(Icon.TRASH) == "🗑️"
        assert manager.icon(Icon.FILE) == "📄"
        assert manager.icon(Icon.FOLDER) == "📁"
        assert manager.icon(Icon.RESTORE) == "↩️"

    def test_icon_manager_emoji_disabled(self) -> None:
        """When emoji disabled, file operation icons use unicode alternatives."""
        manager = IconManager(use_icons=True, use_emoji=False)
        assert manager.icon(Icon.TRASH) == "🗑"
        assert manager.icon(Icon.FILE) == "☐"
        assert manager.icon(Icon.FOLDER) == "☐"
        assert manager.icon(Icon.RESTORE) == "←"

    def test_icon_manager_helper_methods_with_space(self) -> None:
        """Helper methods return icon followed by space when enabled."""
        manager = IconManager(use_icons=True, use_emoji=True)
        assert manager.success() == "✓ "
        assert manager.error() == "✗ "
        assert manager.warning() == "⚠ "
        assert manager.info() == "ℹ "
        assert manager.trash() == "🗑️ "
        assert manager.file() == "📄 "
        assert manager.folder() == "📁 "
        assert manager.restore() == "↩️ "

    def test_icon_manager_helper_methods_without_space(self) -> None:
        """Helper methods return empty string when icons disabled."""
        manager = IconManager(use_icons=False, use_emoji=True)
        assert manager.success() == ""
        assert manager.error() == ""
        assert manager.warning() == ""
        assert manager.info() == ""
        assert manager.trash() == ""
        assert manager.file() == ""
        assert manager.folder() == ""
        assert manager.restore() == ""

    def test_format_success_with_icon_prefix(self, tmp_path: Path) -> None:
        """_format_success can include icon prefix in output."""
        from rmsafe.core.trash_manager import TrashResult

        result = TrashResult(
            source=tmp_path / "file.txt",
            destination=tmp_path / "Trash" / "files" / "file.txt",
            info_path=tmp_path / "Trash" / "info" / "file.txt.trashinfo",
            size_bytes=100,
            size_text="100 bytes",
            dry_run=False,
            success=True,
            message="trashed",
        )
        colors = ColorManager("never")
        output = _format_success(result, colors)
        # Verify the output contains the filename
        assert "file.txt" in output

    def test_format_success_could_include_icon(self, tmp_path: Path) -> None:
        """Test that format_success output could be combined with icons."""
        from rmsafe.core.trash_manager import TrashResult

        result = TrashResult(
            source=tmp_path / "file.txt",
            destination=tmp_path / "Trash" / "files" / "file.txt",
            info_path=tmp_path / "Trash" / "info" / "file.txt.trashinfo",
            size_bytes=100,
            size_text="100 bytes",
            dry_run=False,
            success=True,
            message="trashed",
        )
        colors = ColorManager("never")
        icons = IconManager(use_icons=True, use_emoji=True)

        output = _format_success(result, colors)
        # Icons can be prepended to the output
        full_output = f"{icons.success()}{output}"
        assert full_output.startswith("✓ ")
        assert "file.txt" in full_output


class TestTrashColorOutput:
    """Color output with different settings (always/never/auto)."""

    def test_color_manager_always_setting(self) -> None:
        """ColorManager with 'always' includes color markup."""
        colors = ColorManager("always")
        styled = colors.style("test message", Color.SUCCESS)
        assert "[green]test message[/green]" == styled

    def test_color_manager_never_setting(self) -> None:
        """ColorManager with 'never' returns unstyled text."""
        colors = ColorManager("never")
        styled = colors.style("test message", Color.SUCCESS)
        assert styled == "test message"

    def test_color_manager_auto_non_tty(self, monkeypatch) -> None:
        """ColorManager with 'auto' on non-TTY returns unstyled text."""
        # is_tty is imported from rmsafe.utils.tty in colors.py
        monkeypatch.setattr("rmsafe.utils.tty.is_tty", lambda stream: False)
        colors = ColorManager("auto")
        styled = colors.style("test message", Color.SUCCESS)
        assert styled == "test message"

    def test_color_manager_auto_tty(self, monkeypatch) -> None:
        """ColorManager with 'auto' on TTY includes color markup."""
        # is_tty is imported from rmsafe.utils.tty in colors.py
        monkeypatch.setattr("rmsafe.utils.tty.is_tty", lambda stream: True)
        colors = ColorManager("auto")
        styled = colors.style("test message", Color.SUCCESS)
        assert "[green]test message[/green]" == styled

    def test_no_color_env_var_disables_color(self, monkeypatch) -> None:
        """NO_COLOR environment variable disables color even with 'always'."""
        monkeypatch.setenv("NO_COLOR", "1")
        colors = ColorManager("always")
        styled = colors.style("test message", Color.SUCCESS)
        assert styled == "test message"

    def test_all_color_types(self) -> None:
        """All Color enum values work with ColorManager."""
        colors = ColorManager("always")

        assert colors.style("info", Color.INFO) == "[cyan]info[/cyan]"
        assert colors.style("success", Color.SUCCESS) == "[green]success[/green]"
        assert colors.style("warning", Color.WARNING) == "[yellow]warning[/yellow]"
        assert colors.style("error", Color.ERROR) == "[red]error[/red]"
        assert colors.style("highlight", Color.HIGHLIGHT) == "[magenta]highlight[/magenta]"

    def test_format_success_with_colors_always(self, tmp_path: Path) -> None:
        """_format_success with colors='always' includes markup."""
        from rmsafe.core.trash_manager import TrashResult

        result = TrashResult(
            source=tmp_path / "file.txt",
            destination=tmp_path / "Trash" / "files" / "file.txt",
            info_path=tmp_path / "Trash" / "info" / "file.txt.trashinfo",
            size_bytes=100,
            size_text="100 bytes",
            dry_run=False,
            success=True,
            message="trashed",
        )
        colors = ColorManager("always")
        output = _format_success(result, colors)
        assert "[green]file.txt[/green]" in output
        assert "[cyan]" in output  # trash root path

    def test_format_success_with_colors_never(self, tmp_path: Path) -> None:
        """_format_success with colors='never' has no markup."""
        from rmsafe.core.trash_manager import TrashResult

        result = TrashResult(
            source=tmp_path / "file.txt",
            destination=tmp_path / "Trash" / "files" / "file.txt",
            info_path=tmp_path / "Trash" / "info" / "file.txt.trashinfo",
            size_bytes=100,
            size_text="100 bytes",
            dry_run=False,
            success=True,
            message="trashed",
        )
        colors = ColorManager("never")
        output = _format_success(result, colors)
        assert "[" not in output  # No Rich markup
        assert "file.txt" in output

    def test_format_success_dry_run_with_colors(self, tmp_path: Path) -> None:
        """_format_success with dry_run includes Dry run prefix with color."""
        from rmsafe.core.trash_manager import TrashResult

        result = TrashResult(
            source=tmp_path / "file.txt",
            destination=tmp_path / "Trash" / "files" / "file.txt",
            info_path=tmp_path / "Trash" / "info" / "file.txt.trashinfo",
            size_bytes=100,
            size_text="100 bytes",
            dry_run=True,
            success=True,
            message="dry run",
        )
        colors = ColorManager("always")
        output = _format_success(result, colors)
        assert "[green]Dry run: file.txt[/green]" in output

    def test_run_with_color_context(self, tmp_path: Path) -> None:
        """run() uses ColorManager from context when provided."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        colors = ColorManager("always")
        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
            "colors": colors,
        }

        run([src], context)
        # Operation should succeed
        assert not src.exists()


class TestTrashProgressFeedback:
    """Progress/visual feedback during multi-file operations."""

    def test_multi_file_outputs_each_file(self, tmp_path: Path, capsys) -> None:
        """Multi-file trash operation outputs each file name."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(3):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}", encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        captured = capsys.readouterr()
        # Each file should appear in output
        for i in range(3):
            assert f"file{i}.txt" in captured.out

    def test_multi_file_dry_run_outputs_each(self, tmp_path: Path, capsys) -> None:
        """Multi-file dry run outputs each file with Dry run prefix."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(3):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}", encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": True,
            "no_confirm": True,
        }

        run(files, context)

        captured = capsys.readouterr()
        # Each file should appear with Dry run prefix
        for i in range(3):
            assert f"file{i}.txt" in captured.out
        # Files should not be moved
        for f in files:
            assert f.exists()

    def test_multi_file_with_sizes(self, tmp_path: Path, capsys) -> None:
        """Multi-file output includes size information."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(3):
            f = tmp_path / f"file{i}.txt"
            f.write_text("x" * (100 * (i + 1)), encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        captured = capsys.readouterr()
        # Size should appear in output
        assert "(" in captured.out
        assert "bytes" in captured.out

    def test_mixed_success_and_failure_output(self, tmp_path: Path, capsys) -> None:
        """Mixed success/failure outputs both types appropriately."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        existing = tmp_path / "existing.txt"
        existing.write_text("content", encoding="utf-8")
        nonexistent = tmp_path / "nonexistent.txt"

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([existing, nonexistent], context)

        captured = capsys.readouterr()
        # Successful file appears
        assert "existing.txt" in captured.out
        # Existing file is trashed
        assert not existing.exists()

    def test_output_format_contains_arrow(self, tmp_path: Path, capsys) -> None:
        """Success output format contains arrow pointing to trash location."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src], context)

        captured = capsys.readouterr()
        # Arrow should point to trash location
        assert "→" in captured.out
        assert str(trash_dir) in captured.out or "Trash" in captured.out

    def test_visual_feedback_order_preserved(self, tmp_path: Path, capsys) -> None:
        """Multi-file output preserves input order."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        names = ["alpha.txt", "beta.txt", "gamma.txt"]
        for name in names:
            f = tmp_path / name
            f.write_text("content", encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        captured = capsys.readouterr()
        # Find positions of each file name
        positions = [captured.out.find(name) for name in names]
        # Order should be preserved
        assert positions == sorted(positions)

    def test_empty_file_shows_zero_size(self, tmp_path: Path, capsys) -> None:
        """Empty file shows 0 bytes in output."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src = tmp_path / "empty.txt"
        src.write_text("", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src], context)

        captured = capsys.readouterr()
        assert "empty.txt" in captured.out
        # Empty files should show 0 bytes
        assert "0 bytes" in captured.out or "(0" in captured.out

    def test_directory_output_format(self, tmp_path: Path, capsys) -> None:
        """Directory trashing outputs directory name and trash location."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        src_dir = tmp_path / "mydir"
        src_dir.mkdir()
        (src_dir / "file1.txt").write_text("x" * 100, encoding="utf-8")
        (src_dir / "file2.txt").write_text("y" * 200, encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run([src_dir], context)

        captured = capsys.readouterr()
        assert "mydir" in captured.out
        # Arrow should point to trash location
        assert "→" in captured.out
        assert "Trash" in captured.out


class TestProgressBarPath:
    """Progress bar code path (>=4 files, not dry_run) - lines 40-69."""

    def test_progress_bar_with_4_files(self, tmp_path: Path) -> None:
        """>=4 files triggers progress bar path (lines 40-69)."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(4):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}", encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        # All files should be trashed
        for f in files:
            assert not f.exists()
        assert len(list((trash_dir / "files").iterdir())) == 4

    def test_progress_bar_with_5_files(self, tmp_path: Path) -> None:
        """5+ files triggers progress bar path."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(5):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}", encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        for f in files:
            assert not f.exists()

    def test_progress_bar_with_10_files(self, tmp_path: Path) -> None:
        """10 files triggers progress bar path."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(10):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}", encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        for f in files:
            assert not f.exists()

    def test_progress_bar_with_sizes(self, tmp_path: Path) -> None:
        """Progress bar path with size tracking (lines 59-60)."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(4):
            f = tmp_path / f"file{i}.txt"
            f.write_text("x" * (100 * (i + 1)), encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        # Check sizes were tracked
        for f in files:
            assert not f.exists()

    def test_progress_bar_with_mixed_success_failure(self, tmp_path: Path) -> None:
        """Progress bar handles mixed success/failure (lines 62-63)."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(4):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}", encoding="utf-8")
            files.append(f)

        # Add a nonexistent file (will fail)
        nonexistent = tmp_path / "nonexistent.txt"
        all_files = files + [nonexistent]

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(all_files, context)

        # Existing files trashed
        for f in files:
            assert not f.exists()

    def test_progress_bar_summary_output(self, tmp_path: Path, capsys) -> None:
        """Progress bar shows summary after completion (lines 66-67)."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(4):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}", encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        captured = capsys.readouterr()
        # Summary should contain file count
        assert "4" in captured.out or "Trashed" in captured.out

    def test_progress_bar_with_directory(self, tmp_path: Path) -> None:
        """Progress bar handles directory (line 54)."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []

        # Create 3 files and 1 directory
        for i in range(3):
            f = tmp_path / f"file{i}.txt"
            f.write_text("content", encoding="utf-8")
            files.append(f)

        dir_path = tmp_path / "mydir"
        dir_path.mkdir()
        (dir_path / "inner.txt").write_text("inner", encoding="utf-8")
        files.append(dir_path)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        for f in files:
            assert not f.exists()

    def test_progress_bar_records_history(self, tmp_path: Path) -> None:
        """Progress bar records history on success (line 61)."""
        from rmsafe.config.schema import Config
        from rmsafe.core.history_tracker import HistoryTracker

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(4):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}", encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        # History should be recorded
        tracker = HistoryTracker()
        # History recorded in default path, we can't easily verify it
        # Just ensure operation succeeded
        for f in files:
            assert not f.exists()

    def test_progress_bar_with_3_files_no_bar(self, tmp_path: Path) -> None:
        """3 files does NOT trigger progress bar (line 39 condition)."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(3):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}", encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        run(files, context)

        # Files should be trashed (uses non-progress path)
        for f in files:
            assert not f.exists()

    def test_progress_bar_dry_run_uses_normal_path(self, tmp_path: Path) -> None:
        """Dry run with 4+ files uses normal path (line 40 condition)."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []
        for i in range(4):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}", encoding="utf-8")
            files.append(f)

        config = Config()
        config.trash.location = trash_dir

        context = {
            "config": config,
            "dry_run": True,  # Dry run skips progress bar
            "no_confirm": True,
        }

        run(files, context)

        # Files should NOT be trashed
        for f in files:
            assert f.exists()


class TestSkippedFileHandling:
    """Skipped file handling when user declines large file confirmation."""

    def test_skipped_in_progress_bar_mode(self, tmp_path: Path, monkeypatch) -> None:
        """Skipped file in progress bar mode (lines 49-52)."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files = []

        # Create 3 small files
        for i in range(3):
            f = tmp_path / f"small{i}.txt"
            f.write_text("small", encoding="utf-8")
            files.append(f)

        # Create 1 large file that triggers confirmation
        large = tmp_path / "large.txt"
        large.write_text("x" * 20000, encoding="utf-8")
        all_files = files + [large]

        config = Config()
        config.trash.location = trash_dir
        config.behavior.confirm_large_files = "1KB"  # Small threshold

        # Mock Confirm.ask to return False (decline) - must mock at module level
        monkeypatch.setattr("rmsafe.commands.trash.Confirm.ask", lambda *args, **kwargs: False)
        # Mock is_tty to return True so confirmation is attempted
        monkeypatch.setattr("rmsafe.commands.trash.is_tty", lambda stream: True)

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": False,  # Allow confirmation
        }

        run(all_files, context)

        # Small files trashed, large file skipped
        for f in files:
            assert not f.exists()
        assert large.exists()  # Not trashed (skipped)

    def test_skipped_in_normal_mode(self, tmp_path: Path, monkeypatch) -> None:
        """Skipped file in normal mode (lines 74-76)."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"

        # Create 2 small files (uses normal mode, not progress bar)
        files = []
        for i in range(2):
            f = tmp_path / f"small{i}.txt"
            f.write_text("small", encoding="utf-8")
            files.append(f)

        # Create 1 large file
        large = tmp_path / "large.txt"
        large.write_text("x" * 20000, encoding="utf-8")
        all_files = files + [large]

        config = Config()
        config.trash.location = trash_dir
        config.behavior.confirm_large_files = "1KB"

        # Mock at module level
        monkeypatch.setattr("rmsafe.commands.trash.Confirm.ask", lambda *args, **kwargs: False)
        monkeypatch.setattr("rmsafe.commands.trash.is_tty", lambda stream: True)

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": False,
        }

        run(all_files, context)

        for f in files:
            assert not f.exists()
        assert large.exists()


class TestNeedsLargeFileConfirmOSError:
    """OSError handling in _needs_large_file_confirm (lines 114-115)."""

    def test_oserror_returns_false(self, tmp_path: Path) -> None:
        """OSError during stat returns False."""
        # Create a file
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        # Remove the file after creation to trigger OSError on stat
        src.unlink()

        result = _needs_large_file_confirm(src, 100, dry_run=False, no_confirm=False)
        assert result is False  # File doesn't exist, OSError caught


class TestConfirmLargeFileSIGALRM:
    """SIGALRM timeout handling in _confirm_large_file (lines 121-137)."""

    def test_non_tty_auto_confirms(self, tmp_path: Path, monkeypatch) -> None:
        """Non-TTY auto-confirms (line 119-120)."""
        from rmsafe.output.colors import ColorManager

        # Mock is_tty to return False
        monkeypatch.setattr("rmsafe.commands.trash.is_tty", lambda stream: False)

        colors = ColorManager("never")
        result = _confirm_large_file(tmp_path / "large.txt", colors)
        assert result is True  # Auto-confirm on non-TTY

    def test_tty_with_confirmation(self, tmp_path: Path, monkeypatch) -> None:
        """TTY with confirmation prompt."""
        from rmsafe.output.colors import ColorManager

        # Mock at module level
        monkeypatch.setattr("rmsafe.commands.trash.is_tty", lambda stream: True)
        monkeypatch.setattr("rmsafe.commands.trash.Confirm.ask", lambda *args, **kwargs: True)

        colors = ColorManager("never")
        result = _confirm_large_file(tmp_path / "large.txt", colors)
        assert result is True

    def test_no_sigalrm_platform(self, tmp_path: Path, monkeypatch) -> None:
        """Platform without SIGALRM uses normal confirmation (line 123-124)."""
        from rmsafe.output.colors import ColorManager

        # Ensure SIGALRM doesn't exist
        if hasattr(signal, "SIGALRM"):
            monkeypatch.delattr(signal, "SIGALRM")

        monkeypatch.setattr("rmsafe.commands.trash.is_tty", lambda stream: True)
        monkeypatch.setattr("rmsafe.commands.trash.Confirm.ask", lambda *args, **kwargs: False)

        colors = ColorManager("never")
        result = _confirm_large_file(tmp_path / "large.txt", colors)
        assert result is False

    def test_sigalrm_timeout_returns_false(self, tmp_path: Path, monkeypatch) -> None:
        """SIGALRM timeout returns False (lines 133-134)."""
        from rmsafe.output.colors import ColorManager

        # Ensure SIGALRM exists
        if not hasattr(signal, "SIGALRM"):
            pytest.skip("SIGALRM not available on this platform")

        # Mock to simulate timeout
        monkeypatch.setattr("rmsafe.commands.trash.is_tty", lambda stream: True)

        def raise_timeout(*args, **kwargs):
            raise TimeoutError("Simulated timeout")

        monkeypatch.setattr("rmsafe.commands.trash.Confirm.ask", raise_timeout)

        colors = ColorManager("never")
        result = _confirm_large_file(tmp_path / "large.txt", colors)
        assert result is False  # Timeout returns False


class TestErrorDetailOutput:
    """Error detail output (line 90)."""

    def test_error_with_detail_message(self, tmp_path: Path, monkeypatch) -> None:
        """Error with detail message shows warning (line 90)."""
        from rmsafe.config.schema import Config
        from rmsafe.core.trash_manager import TrashResult

        trash_dir = tmp_path / "Trash"

        config = Config()
        config.trash.location = trash_dir

        # Create a mock TrashManager that returns error with detail
        from rmsafe.core.trash_manager import TrashManager
        original_trash_file = TrashManager.trash_file

        def mock_trash_file(self, path, dry_run=False):
            if not path.exists():
                return TrashResult(
                    source=path,
                    destination=path,
                    info_path=None,
                    size_bytes=None,
                    size_text=None,
                    dry_run=dry_run,
                    success=False,
                    message=f"File not found: {path}",
                    error="Permission denied or file moved",
                )
            return original_trash_file(self, path, dry_run)

        monkeypatch.setattr(TrashManager, "trash_file", mock_trash_file)

        nonexistent = tmp_path / "nonexistent.txt"

        context = {
            "config": config,
            "dry_run": False,
            "no_confirm": True,
        }

        # Should print error and warning message
        run([nonexistent], context)