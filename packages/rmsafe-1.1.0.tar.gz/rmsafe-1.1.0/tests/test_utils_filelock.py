"""Comprehensive tests for utils/filelock.py following SQLite test philosophy."""
from __future__ import annotations

import sys
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

import pytest

from rmsafe.utils.filelock import FileLock, FileLockError, LockTimeout


class TestFileLockInit:
    """FileLock.__init__() - every configuration."""

    def test_basic_init(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock")
        assert lock.path == tmp_path / ".lock"
        assert lock.is_locked is False

    def test_with_timeout(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock", timeout=5.0)
        assert lock._timeout == 5.0

    def test_zero_timeout(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock", timeout=0)
        assert lock._timeout == 0

    def test_none_timeout(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock", timeout=None)
        assert lock._timeout is None

    def test_path_string(self, tmp_path: Path) -> None:
        lock = FileLock(str(tmp_path / ".lock"))
        assert lock.path == tmp_path / ".lock"


class TestFileLockAcquire:
    """FileLock.acquire() - every mode, every outcome."""

    def test_acquire_blocking(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock")
        lock.acquire()
        assert lock.is_locked is True
        lock.release()
        assert lock.is_locked is False

    def test_acquire_non_blocking_success(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock", timeout=0)
        lock.acquire()
        assert lock.is_locked is True
        lock.release()

    def test_acquire_non_blocking_conflict(self, tmp_path: Path) -> None:
        lock1 = FileLock(tmp_path / ".lock", timeout=0)
        lock1.acquire()

        lock2 = FileLock(tmp_path / ".lock", timeout=0)
        with pytest.raises(LockTimeout):
            lock2.acquire()

        lock1.release()

    def test_acquire_twice_same_instance(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock")
        lock.acquire()
        assert lock.acquire() is True  # Should succeed, already held
        lock.release()

    def test_acquire_creates_lock_file(self, tmp_path: Path) -> None:
        lock_path = tmp_path / ".lock"
        assert not lock_path.exists()

        lock = FileLock(lock_path)
        lock.acquire()

        # Lock file should be created
        assert lock_path.exists()

        lock.release()

    def test_acquire_timeout_override(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock", timeout=None)
        # Override with specific timeout
        lock.acquire(timeout=0.5)
        assert lock.is_locked is True
        lock.release()


class TestFileLockRelease:
    """FileLock.release() - every state."""

    def test_release_after_acquire(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock")
        lock.acquire()
        lock.release()
        assert lock.is_locked is False

    def test_release_without_acquire(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock")
        with pytest.raises(FileLockError, match="not held"):
            lock.release()

    def test_release_twice(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock")
        lock.acquire()
        lock.release()
        with pytest.raises(FileLockError, match="not held"):
            lock.release()

    def test_release_allows_reacquire(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock")
        lock.acquire()
        lock.release()
        lock.acquire()
        assert lock.is_locked is True
        lock.release()


class TestFileLockContextManager:
    """FileLock as context manager - every scenario."""

    def test_context_manager_acquires(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock")
        with lock:
            assert lock.is_locked is True
        assert lock.is_locked is False

    def test_context_manager_releases_on_exception(self, tmp_path: Path) -> None:
        lock = FileLock(tmp_path / ".lock")
        try:
            with lock:
                assert lock.is_locked is True
                raise ValueError("test error")
        except ValueError:
            pass
        assert lock.is_locked is False

    def test_nested_context_different_locks(self, tmp_path: Path) -> None:
        lock1 = FileLock(tmp_path / "lock1")
        lock2 = FileLock(tmp_path / "lock2")

        with lock1:
            assert lock1.is_locked is True
            with lock2:
                assert lock2.is_locked is True
                assert lock1.is_locked is True
            assert lock2.is_locked is False
            assert lock1.is_locked is True
        assert lock1.is_locked is False


class TestFileLockTimeout:
    """FileLock timeout behavior."""

    def test_timeout_zero_immediate_fail(self, tmp_path: Path) -> None:
        lock1 = FileLock(tmp_path / ".lock")
        lock1.acquire()

        lock2 = FileLock(tmp_path / ".lock", timeout=0)
        with pytest.raises(LockTimeout):
            lock2.acquire()

        lock1.release()

    def test_timeout_expires(self, tmp_path: Path) -> None:
        lock1 = FileLock(tmp_path / ".lock")
        lock1.acquire()

        lock2 = FileLock(tmp_path / ".lock", timeout=0.5)
        start = time.monotonic()
        with pytest.raises(LockTimeout):
            lock2.acquire()
        elapsed = time.monotonic() - start

        # Should have waited at least 0.5 seconds (allowing some tolerance)
        assert elapsed >= 0.4  # Some tolerance for timing
        assert elapsed < 1.0  # Should not wait much longer than timeout

        lock1.release()

    def test_timeout_succeeds_before_expire(self, tmp_path: Path) -> None:
        lock1 = FileLock(tmp_path / ".lock")

        def hold_and_release() -> None:
            time.sleep(0.3)
            lock1.release()

        lock2 = FileLock(tmp_path / ".lock", timeout=1.0)

        with ThreadPoolExecutor(max_workers=2) as executor:
            executor.submit(hold_and_release)
            time.sleep(0.1)  # Let lock1 get acquired
            lock1.acquire()  # Ensure lock1 is held
            # lock2 should succeed within timeout since lock1 releases after 0.3s
            lock2.acquire()  # This may block until lock1 releases

        # If test gets here, lock2 succeeded


class TestFileLockConcurrency:
    """FileLock with multiple processes/threads."""

    def test_two_threads_same_lock(self, tmp_path: Path) -> None:
        """Two threads trying to acquire same lock."""
        lock_path = tmp_path / ".lock"
        results = []

        def thread_work(thread_id: int) -> int:
            lock = FileLock(lock_path, timeout=5.0)
            with lock:
                time.sleep(0.1)  # Hold lock briefly
                results.append(thread_id)
            return thread_id

        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(thread_work, i) for i in range(2)]
            for f in as_completed(futures):
                f.result()  # Ensure no exceptions

        # Both threads should have completed
        assert len(results) == 2
        assert set(results) == {0, 1}

    def test_serialized_operations(self, tmp_path: Path) -> None:
        """Lock serializes concurrent operations."""
        lock_path = tmp_path / ".lock"
        operations = []

        def thread_work(thread_id: int) -> None:
            lock = FileLock(lock_path, timeout=10.0)
            with lock:
                start = time.monotonic()
                operations.append(("start", thread_id, start))
                time.sleep(0.2)
                end = time.monotonic()
                operations.append(("end", thread_id, end))

        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = [executor.submit(thread_work, i) for i in range(3)]
            for f in as_completed(futures):
                f.result()

        # Verify operations were serialized (no overlap)
        starts = [(op[1], op[2]) for op in operations if op[0] == "start"]
        ends = [(op[1], op[2]) for op in operations if op[0] == "end"]

        # Sort by time
        starts.sort(key=lambda x: x[1])
        ends.sort(key=lambda x: x[1])

        # Each end should come before the next start (no overlap)
        for i in range(len(ends) - 1):
            assert ends[i][1] <= starts[i + 1][1] + 0.05  # Small tolerance for timing

    def test_multiple_lock_files(self, tmp_path: Path) -> None:
        """Different lock files don't interfere."""
        results = []

        def thread_work(lock_name: str) -> str:
            lock = FileLock(tmp_path / lock_name, timeout=1.0)
            with lock:
                time.sleep(0.1)
                results.append(lock_name)
            return lock_name

        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = [executor.submit(thread_work, f"lock{i}") for i in range(3)]
            for f in as_completed(futures):
                f.result()

        assert len(results) == 3


class TestFileLockErrorHandling:
    """FileLock error scenarios."""

    def test_acquire_invalid_directory(self) -> None:
        """Acquiring lock in non-existent directory."""
        lock = FileLock(Path("/nonexistent/directory/.lock"))
        with pytest.raises(FileLockError):
            lock.acquire()

    @pytest.mark.skipif(sys.platform == "win32", reason="Permission tests unreliable on Windows")
    def test_acquire_permission_denied(self, tmp_path: Path) -> None:
        """Acquiring lock in read-only directory."""
        import os

        readonly_dir = tmp_path / "readonly"
        readonly_dir.mkdir()
        os.chmod(readonly_dir, 0o444)

        try:
            lock = FileLock(readonly_dir / ".lock")
            with pytest.raises(FileLockError):
                lock.acquire()
        finally:
            os.chmod(readonly_dir, 0o755)


class TestFileLockCleanup:
    """FileLock cleanup behavior."""

    def test_lock_file_persists_after_release(self, tmp_path: Path) -> None:
        """Lock file is not deleted on release (standard advisory lock behavior)."""
        lock_path = tmp_path / ".lock"
        lock = FileLock(lock_path)
        lock.acquire()
        lock.release()

        # Lock file persists (standard flock behavior)
        assert lock_path.exists()

    def test_garbage_collection_releases(self, tmp_path: Path) -> None:
        """Lock should be released when object is garbage collected."""
        lock_path = tmp_path / ".lock"

        lock = FileLock(lock_path)
        lock.acquire()
        assert lock.is_locked is True

        # Delete reference, triggering __del__
        del lock

        # Allow a new lock to be acquired
        new_lock = FileLock(lock_path, timeout=1.0)
        new_lock.acquire()
        assert new_lock.is_locked is True
        new_lock.release()


class TestLockTimeoutException:
    """LockTimeout exception behavior."""

    def test_exception_message(self, tmp_path: Path) -> None:
        lock1 = FileLock(tmp_path / ".lock")
        lock1.acquire()

        lock2 = FileLock(tmp_path / ".lock", timeout=0)
        try:
            lock2.acquire()
        except LockTimeout as exc:
            assert "held by another process" in str(exc) or "could not acquire" in str(exc).lower()

        lock1.release()

    def test_exception_is_filelock_error(self, tmp_path: Path) -> None:
        lock1 = FileLock(tmp_path / ".lock")
        lock1.acquire()

        lock2 = FileLock(tmp_path / ".lock", timeout=0)
        try:
            lock2.acquire()
        except LockTimeout as exc:
            assert isinstance(exc, FileLockError)

        lock1.release()