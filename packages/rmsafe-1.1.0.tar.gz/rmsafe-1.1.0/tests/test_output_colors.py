"""Comprehensive tests for output/colors.py following SQLite test philosophy."""
from __future__ import annotations

import io
import sys

import pytest

from rmsafe.output.colors import Color, ColorManager, get_console


class TestColorEnum:
    """Color enum - every value, every property."""

    def test_info_value(self) -> None:
        assert Color.INFO.value == "cyan"

    def test_success_value(self) -> None:
        assert Color.SUCCESS.value == "green"

    def test_warning_value(self) -> None:
        assert Color.WARNING.value == "yellow"

    def test_error_value(self) -> None:
        assert Color.ERROR.value == "red"

    def test_highlight_value(self) -> None:
        assert Color.HIGHLIGHT.value == "magenta"

    def test_all_colors_exist(self) -> None:
        values = [c.value for c in Color]
        assert "cyan" in values
        assert "green" in values
        assert "yellow" in values
        assert "red" in values
        assert "magenta" in values

    def test_color_is_string_enum(self) -> None:
        assert isinstance(Color.INFO, str)
        assert Color.INFO == "cyan"

    def test_color_members_count(self) -> None:
        assert len(list(Color)) == 5


class TestGetConsole:
    """get_console() - every color setting, every environment."""

    def test_always_returns_console_with_color(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        console = get_console("always")
        assert console._force_terminal is True
        assert console.no_color is False

    def test_always_respects_no_color(self, monkeypatch) -> None:
        # NO_COLOR always disables color in this implementation
        monkeypatch.setenv("NO_COLOR", "1")
        console = get_console("always")
        assert console.no_color is True

    def test_never_returns_console_without_color(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        console = get_console("never")
        assert console.no_color is True

    def test_never_with_no_color(self, monkeypatch) -> None:
        monkeypatch.setenv("NO_COLOR", "1")
        console = get_console("never")
        assert console.no_color is True

    def test_auto_no_color_env(self, monkeypatch) -> None:
        monkeypatch.setenv("NO_COLOR", "1")
        console = get_console("auto")
        assert console.no_color is True

    def test_auto_without_no_color(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        console = get_console("auto")
        # Result depends on TTY state
        assert isinstance(console.no_color, bool)

    def test_uppercase_setting_normalized(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        console = get_console("ALWAYS")
        assert console._force_terminal is True

    def test_mixed_case_setting_normalized(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        console = get_console("NeVeR")
        assert console.no_color is True

    def test_whitespace_setting_normalized(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        console = get_console("  always  ")
        assert console._force_terminal is True

    def test_default_is_auto(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        console = get_console()
        assert isinstance(console.no_color, bool)

    def test_invalid_setting_raises(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        with pytest.raises(ValueError, match="Unsupported"):
            get_console("invalid")

    def test_empty_setting_raises(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        with pytest.raises(ValueError, match="Unsupported"):
            get_console("")

    def test_returns_rich_console(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        from rich.console import Console
        console = get_console("always")
        assert isinstance(console, Console)


class TestColorManagerInit:
    """ColorManager.__init__() - every setting, every environment."""

    def test_default_color_setting(self) -> None:
        manager = ColorManager()
        assert manager.color_setting == "auto"

    def test_explicit_always(self) -> None:
        manager = ColorManager("always")
        assert manager.color_setting == "always"

    def test_explicit_never(self) -> None:
        manager = ColorManager("never")
        assert manager.color_setting == "never"

    def test_explicit_auto(self) -> None:
        manager = ColorManager("auto")
        assert manager.color_setting == "auto"

    def test_uppercase_normalized(self) -> None:
        manager = ColorManager("ALWAYS")
        assert manager.color_setting == "ALWAYS"

    def test_console_attribute_exists(self) -> None:
        manager = ColorManager("always")
        assert hasattr(manager, "console")

    def test_console_is_rich_console(self) -> None:
        from rich.console import Console
        manager = ColorManager("always")
        assert isinstance(manager.console, Console)


class TestColorManagerPrint:
    """ColorManager.print() - every argument, every output."""

    def test_print_string(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        output = io.StringIO()
        manager.console.file = output
        manager.print("test message")
        assert "test message" in output.getvalue()

    def test_print_multiple_args(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        output = io.StringIO()
        manager.console.file = output
        manager.print("part1", "part2", "part3")
        result = output.getvalue()
        assert "part1" in result
        assert "part2" in result
        assert "part3" in result

    def test_print_with_kwargs(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        output = io.StringIO()
        manager.console.file = output
        manager.print("styled", style="bold")
        assert "styled" in output.getvalue()

    def test_print_empty(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        output = io.StringIO()
        manager.console.file = output
        manager.print()
        # Empty print outputs newline
        assert output.getvalue() == "\n"

    def test_print_none(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        output = io.StringIO()
        manager.console.file = output
        manager.print(None)
        assert "None" in output.getvalue()

    def test_print_rich_table(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        from rich.table import Table
        manager = ColorManager("always")
        output = io.StringIO()
        manager.console.file = output
        table = Table()
        table.add_column("Test")
        table.add_row("value")
        manager.print(table)
        assert "value" in output.getvalue()


class TestColorManagerStyle:
    """ColorManager.style() - every color, every text, every environment."""

    def test_style_info_with_color(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("test", Color.INFO)
        assert "[cyan]test[/cyan]" == result

    def test_style_success_with_color(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("test", Color.SUCCESS)
        assert "[green]test[/green]" == result

    def test_style_warning_with_color(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("test", Color.WARNING)
        assert "[yellow]test[/yellow]" == result

    def test_style_error_with_color(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("test", Color.ERROR)
        assert "[red]test[/red]" == result

    def test_style_highlight_with_color(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("test", Color.HIGHLIGHT)
        assert "[magenta]test[/magenta]" == result

    def test_style_never_returns_plain(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("never")
        result = manager.style("test", Color.INFO)
        assert result == "test"

    def test_style_never_with_no_color(self, monkeypatch) -> None:
        monkeypatch.setenv("NO_COLOR", "1")
        manager = ColorManager("never")
        result = manager.style("test", Color.SUCCESS)
        assert result == "test"

    def test_style_always_respects_no_color(self, monkeypatch) -> None:
        # NO_COLOR always disables in this implementation
        monkeypatch.setenv("NO_COLOR", "1")
        manager = ColorManager("always")
        result = manager.style("test", Color.WARNING)
        assert result == "test"

    def test_style_no_color_env_auto(self, monkeypatch) -> None:
        monkeypatch.setenv("NO_COLOR", "1")
        manager = ColorManager("auto")
        result = manager.style("test", Color.ERROR)
        assert result == "test"

    def test_style_empty_text(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("", Color.INFO)
        assert result == "[cyan][/cyan]"

    def test_style_text_with_spaces(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("  spaces  ", Color.INFO)
        assert "[cyan]  spaces  [/cyan]" == result

    def test_style_text_with_special_chars(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("special-[chars]-{test}", Color.INFO)
        assert "special-[chars]-{test}" in result

    def test_style_text_with_newlines(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("line1\nline2", Color.INFO)
        assert "[cyan]line1\nline2[/cyan]" == result

    def test_style_multiline_text(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("a\nb\nc", Color.SUCCESS)
        assert "[green]a\nb\nc[/green]" == result

    def test_style_unicode_text(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("你好世界", Color.INFO)
        assert "[cyan]你好世界[/cyan]" == result

    def test_style_emoji_text(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        result = manager.style("✅ success", Color.SUCCESS)
        assert "[green]✅ success[/green]" == result


class TestColorIntegration:
    """Integration tests combining ColorManager with various outputs."""

    def test_print_styled_message(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        output = io.StringIO()
        manager.console.file = output
        styled = manager.style("error occurred", Color.ERROR)
        manager.print(styled)
        assert "error occurred" in output.getvalue()

    def test_multiple_styles_in_sequence(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("always")
        output = io.StringIO()
        manager.console.file = output
        manager.print(manager.style("success: ", Color.SUCCESS) + manager.style("file.txt", Color.INFO))
        assert "success" in output.getvalue()
        assert "file.txt" in output.getvalue()

    def test_style_preserves_text_content(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        manager = ColorManager("never")
        for color in Color:
            result = manager.style("important", color)
            assert result == "important"