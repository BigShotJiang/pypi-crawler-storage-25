from __future__ import annotations

import sys

import pytest
from pathlib import Path

from rmsafe.commands import restore
from rmsafe.config.schema import BtrfsConfig, BehaviorConfig, Config, OutputConfig, TrashConfig


def test_restore_command_restores_named_file_to_origin(tmp_path: Path, monkeypatch, capsys) -> None:
    trash_dir = tmp_path / "Trash"
    files_dir = trash_dir / "files"
    info_dir = trash_dir / "info"
    files_dir.mkdir(parents=True)
    info_dir.mkdir(parents=True)

    trashed = files_dir / "report.txt"
    trashed.write_text("hello", encoding="utf-8")
    (info_dir / "report.txt.trashinfo").write_text(
        f"[Trash Info]\nPath={tmp_path / 'report.txt'}\nDeletionDate=2026-04-26T10:00:00\n",
        encoding="utf-8",
    )

    config = Config(
        trash=TrashConfig(location=trash_dir),
        behavior=BehaviorConfig(),
        output=OutputConfig(color="never", verbose=True, icons=True, table_format="rounded"),
        btrfs=BtrfsConfig(),
    )

    monkeypatch.setattr(restore, "load_config", lambda: config)
    monkeypatch.setattr(restore.typer, "confirm", lambda *args, **kwargs: True)

    restore.run("report.txt")

    out = capsys.readouterr().out
    assert "report.txt" in out
    assert "Restored" in out
    assert not trashed.exists()
    assert (tmp_path / "report.txt").read_text(encoding="utf-8") == "hello"


def test_restore_command_uses_to_directory_and_overwrites_existing_file(tmp_path: Path, monkeypatch) -> None:
    trash_dir = tmp_path / "Trash"
    files_dir = trash_dir / "files"
    files_dir.mkdir(parents=True)

    trashed = files_dir / "archive.txt"
    trashed.write_text("new", encoding="utf-8")

    destination_dir = tmp_path / "dest"
    destination_dir.mkdir()
    (destination_dir / "archive.txt").write_text("old", encoding="utf-8")

    config = Config(
        trash=TrashConfig(location=trash_dir),
        behavior=BehaviorConfig(),
        output=OutputConfig(color="never", verbose=True, icons=True, table_format="rounded"),
        btrfs=BtrfsConfig(),
    )

    monkeypatch.setattr(restore, "load_config", lambda: config)
    monkeypatch.setattr(restore.typer, "confirm", lambda *args, **kwargs: True)

    restore.run("archive.txt", to=destination_dir)

    assert not trashed.exists()
    assert (destination_dir / "archive.txt").read_text(encoding="utf-8") == "new"


def test_restore_command_falls_back_to_cwd_when_trashinfo_missing(tmp_path: Path, monkeypatch) -> None:
    trash_dir = tmp_path / "Trash"
    files_dir = trash_dir / "files"
    files_dir.mkdir(parents=True)

    trashed = files_dir / "note.txt"
    trashed.write_text("fallback", encoding="utf-8")

    config = Config(
        trash=TrashConfig(location=trash_dir),
        behavior=BehaviorConfig(),
        output=OutputConfig(color="never", verbose=True, icons=True, table_format="rounded"),
        btrfs=BtrfsConfig(),
    )

    monkeypatch.setattr(restore, "load_config", lambda: config)
    monkeypatch.setattr(restore.typer, "confirm", lambda *args, **kwargs: True)
    monkeypatch.chdir(tmp_path)

    restore.run("note.txt")

    assert not trashed.exists()
    assert (tmp_path / "note.txt").read_text(encoding="utf-8") == "fallback"


@pytest.mark.skipif(sys.platform != "darwin", reason="macOS case-insensitive matching only works on Darwin")
def test_restore_command_matches_case_insensitively_on_macos_layout(tmp_path: Path, monkeypatch, capsys) -> None:
    trash_dir = tmp_path / ".Trash"
    trash_dir.mkdir()

    trashed = trash_dir / "Report.TXT"
    trashed.write_text("mac", encoding="utf-8")

    config = Config(
        trash=TrashConfig(location=trash_dir),
        behavior=BehaviorConfig(),
        output=OutputConfig(color="never", verbose=True, icons=True, table_format="rounded"),
        btrfs=BtrfsConfig(),
    )

    monkeypatch.setattr(restore, "load_config", lambda: config)
    monkeypatch.setattr(restore.typer, "confirm", lambda *args, **kwargs: True)
    monkeypatch.chdir(tmp_path)

    restore.run("report.txt")

    out = capsys.readouterr().out
    assert "Report.TXT" in out
    assert not trashed.exists()
    assert (tmp_path / "Report.TXT").read_text(encoding="utf-8") == "mac"


def test_undo_list_is_exposed_via_cli_option(tmp_path: Path, monkeypatch, capsys) -> None:
    from rmsafe.commands import undo

    monkeypatch.setenv("HOME", str(tmp_path))
    tracker = undo.HistoryTracker(history_path=tmp_path / ".local/share/rmsafe/history.json")
    tracker.record_deletion([tmp_path / "x.txt"], [None])

    undo.run(None, list_only=True)

    out = capsys.readouterr().out
    assert "Recently Trashed" in out
