"""Tests for list command - Rich Table output for trashed files."""

from __future__ import annotations

import pytest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

from rmsafe.commands import list as list_cmd
from rmsafe.core.trash_manager import TrashManager
from rmsafe.core.trashinfo import write_trashinfo, TrashInfo


class TestTrashEntry:
    """Test TrashEntry dataclass."""

    def test_basic_entry(self, tmp_path: Path) -> None:
        """Basic entry with all fields."""
        entry = list_cmd.TrashEntry(
            path=tmp_path / "file.txt",
            name="file.txt",
            size_bytes=1024,
            time_value=datetime.now(),
            time_text="2024-01-15 10:30:00",
            origin_text="/home/user/file.txt",
        )

        assert entry.name == "file.txt"
        assert entry.size_bytes == 1024
        assert entry.time_text == "2024-01-15 10:30:00"
        assert entry.origin_text == "/home/user/file.txt"

    def test_entry_with_none_time(self, tmp_path: Path) -> None:
        """Entry with missing time (no trashinfo)."""
        entry = list_cmd.TrashEntry(
            path=tmp_path / "file.txt",
            name="file.txt",
            size_bytes=512,
            time_value=None,
            time_text="-",
            origin_text="-",
        )

        assert entry.time_value is None
        assert entry.time_text == "-"
        assert entry.origin_text == "-"

    def test_slots_dataclass(self, tmp_path: Path) -> None:
        """TrashEntry uses slots for efficiency."""
        entry = list_cmd.TrashEntry(
            path=tmp_path / "file.txt",
            name="file.txt",
            size_bytes=100,
            time_value=None,
            time_text="-",
            origin_text="-",
        )

        # Verify slots is in use - no __dict__ attribute
        assert not hasattr(entry, "__dict__")


class TestCollectEntries:
    """Test _collect_entries function."""

    def test_empty_trash_dir(self, tmp_path: Path) -> None:
        """Empty trash directory returns empty list."""
        trash_dir = tmp_path / "Trash"
        trash_dir.mkdir()
        manager = TrashManager(trash_dir)

        entries = list_cmd._collect_entries(manager, None)
        assert entries == []

    def test_missing_files_dir(self, tmp_path: Path) -> None:
        """Missing files directory returns empty list."""
        trash_dir = tmp_path / "Trash"
        # Don't create files_dir
        manager = TrashManager(trash_dir)

        entries = list_cmd._collect_entries(manager, None)
        assert entries == []

    def test_single_file(self, tmp_path: Path) -> None:
        """Single file in trash is collected."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create a file in trash
        file_path = files_dir / "test.txt"
        file_path.write_text("hello world")

        # Create trashinfo
        write_trashinfo(
            info_dir / "test.txt.trashinfo",
            Path("/home/user/test.txt"),
            datetime.now() - timedelta(hours=1),
        )

        manager = TrashManager(trash_dir)
        entries = list_cmd._collect_entries(manager, None)

        assert len(entries) == 1
        assert entries[0].name == "test.txt"
        assert entries[0].size_bytes == 11  # "hello world"
        assert entries[0].time_value is not None
        assert entries[0].origin_text == "/home/user/test.txt"

    def test_multiple_files_sorted(self, tmp_path: Path) -> None:
        """Multiple files are sorted alphabetically by name."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create multiple files
        for name in ["zebra.txt", "apple.txt", "banana.txt"]:
            file_path = files_dir / name
            file_path.write_text("content")
            write_trashinfo(
                info_dir / f"{name}.trashinfo",
                Path(f"/home/user/{name}"),
                datetime.now(),
            )

        manager = TrashManager(trash_dir)
        entries = list_cmd._collect_entries(manager, None)

        # Files should be sorted alphabetically (case-insensitive)
        names = [e.name for e in entries]
        assert names == ["apple.txt", "banana.txt", "zebra.txt"]

    def test_pattern_filter_matches_filename(self, tmp_path: Path) -> None:
        """Pattern filter matches against filename."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create files
        for name in ["test.py", "test.txt", "other.py"]:
            (files_dir / name).write_text("content")
            write_trashinfo(
                info_dir / f"{name}.trashinfo",
                Path(f"/home/user/{name}"),
                datetime.now(),
            )

        manager = TrashManager(trash_dir)
        entries = list_cmd._collect_entries(manager, "*.py")

        names = [e.name for e in entries]
        assert names == ["other.py", "test.py"]

    def test_pattern_filter_matches_origin(self, tmp_path: Path) -> None:
        """Pattern filter matches against original path."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create files with different origins
        (files_dir / "file1.txt").write_text("a")
        write_trashinfo(
            info_dir / "file1.txt.trashinfo",
            Path("/home/user/documents/file1.txt"),
            datetime.now(),
        )

        (files_dir / "file2.txt").write_text("b")
        write_trashinfo(
            info_dir / "file2.txt.trashinfo",
            Path("/home/user/downloads/file2.txt"),
            datetime.now(),
        )

        manager = TrashManager(trash_dir)
        entries = list_cmd._collect_entries(manager, "*documents*")

        assert len(entries) == 1
        assert entries[0].name == "file1.txt"

    def test_file_without_trashinfo(self, tmp_path: Path) -> None:
        """File without trashinfo still collected with defaults."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        # Create file without trashinfo
        file_path = files_dir / "orphan.txt"
        file_path.write_text("orphan content")

        manager = TrashManager(trash_dir)
        entries = list_cmd._collect_entries(manager, None)

        assert len(entries) == 1
        assert entries[0].name == "orphan.txt"
        assert entries[0].time_value is None
        assert entries[0].time_text == "-"
        assert entries[0].origin_text == "-"

    def test_directory_in_trash(self, tmp_path: Path) -> None:
        """Directory in trash is collected."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create directory with files
        dir_path = files_dir / "mydir"
        dir_path.mkdir()
        (dir_path / "file1.txt").write_text("content1")
        (dir_path / "file2.txt").write_text("content2")

        write_trashinfo(
            info_dir / "mydir.trashinfo",
            Path("/home/user/mydir"),
            datetime.now(),
        )

        manager = TrashManager(trash_dir)
        entries = list_cmd._collect_entries(manager, None)

        assert len(entries) == 1
        assert entries[0].name == "mydir"
        # Size should be sum of files in directory
        assert entries[0].size_bytes >= 16  # "content1" + "content2"

    def test_symlink_in_trash(self, tmp_path: Path) -> None:
        """Symlink in trash is collected."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create a symlink
        target = tmp_path / "target.txt"
        target.write_text("target content")
        link_path = files_dir / "mylink"
        link_path.symlink_to(target)

        write_trashinfo(
            info_dir / "mylink.trashinfo",
            Path("/home/user/mylink"),
            datetime.now(),
        )

        manager = TrashManager(trash_dir)
        entries = list_cmd._collect_entries(manager, None)

        assert len(entries) == 1
        assert entries[0].name == "mylink"


class TestBuildEntry:
    """Test _build_entry function."""

    def test_file_with_trashinfo(self, tmp_path: Path) -> None:
        """File with valid trashinfo has full metadata."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        file_path = files_dir / "document.pdf"
        file_path.write_text("PDF content here")

        deletion_time = datetime.now() - timedelta(hours=2)
        write_trashinfo(
            info_dir / "document.pdf.trashinfo",
            Path("/home/user/documents/report.pdf"),
            deletion_time,
        )

        manager = TrashManager(trash_dir)
        entry = list_cmd._build_entry(file_path, manager)

        assert entry.name == "document.pdf"
        assert entry.size_bytes == len("PDF content here")
        assert entry.time_value is not None
        # Time should match (without microseconds)
        assert entry.time_value.replace(microsecond=0) == deletion_time.replace(microsecond=0)
        assert entry.origin_text == "/home/user/documents/report.pdf"

    def test_file_without_trashinfo(self, tmp_path: Path) -> None:
        """File without trashinfo returns defaults."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        file_path = files_dir / "orphan.dat"
        file_path.write_text("data")

        manager = TrashManager(trash_dir)
        entry = list_cmd._build_entry(file_path, manager)

        assert entry.name == "orphan.dat"
        assert entry.time_value is None
        assert entry.time_text == "-"
        assert entry.origin_text == "-"

    def test_mac_style_trash_no_info_dir(self, tmp_path: Path) -> None:
        """macOS-style trash has no info directory."""
        # macOS style: trash_dir name is .Trash
        trash_dir = tmp_path / ".Trash"
        trash_dir.mkdir()
        files_dir = trash_dir
        # No info subdirectory

        file_path = files_dir / "macfile.txt"
        file_path.write_text("mac content")

        manager = TrashManager(trash_dir)
        assert manager.info_dir is None  # macOS style

        entry = list_cmd._build_entry(file_path, manager)

        assert entry.name == "macfile.txt"
        assert entry.time_value is None
        assert entry.time_text == "-"
        assert entry.origin_text == "-"

    def test_corrupt_trashinfo_file(self, tmp_path: Path) -> None:
        """Corrupt trashinfo file returns defaults."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        file_path = files_dir / "corrupt.txt"
        file_path.write_text("content")

        # Write invalid trashinfo
        (info_dir / "corrupt.txt.trashinfo").write_text("This is not valid trashinfo")

        manager = TrashManager(trash_dir)
        entry = list_cmd._build_entry(file_path, manager)

        assert entry.name == "corrupt.txt"
        assert entry.time_value is None
        assert entry.time_text == "-"
        assert entry.origin_text == "-"

    def test_unicode_filename(self, tmp_path: Path) -> None:
        """Unicode filenames are handled correctly."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Unicode filename
        file_path = files_dir / "emoji_🎉_test.txt"
        file_path.write_text("unicode content")

        write_trashinfo(
            info_dir / "emoji_🎉_test.txt.trashinfo",
            Path("/home/user/emoji_🎉_test.txt"),
            datetime.now(),
        )

        manager = TrashManager(trash_dir)
        entry = list_cmd._build_entry(file_path, manager)

        assert entry.name == "emoji_🎉_test.txt"
        assert entry.origin_text == "/home/user/emoji_🎉_test.txt"

    def test_special_characters_in_filename(self, tmp_path: Path) -> None:
        """Special characters in filenames are handled."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Filename with spaces and special characters
        file_path = files_dir / "file with spaces & symbols!.txt"
        file_path.write_text("special")

        write_trashinfo(
            info_dir / "file with spaces & symbols!.txt.trashinfo",
            Path("/home/user/file with spaces & symbols!.txt"),
            datetime.now(),
        )

        manager = TrashManager(trash_dir)
        entry = list_cmd._build_entry(file_path, manager)

        assert "spaces" in entry.name
        assert entry.origin_text == "/home/user/file with spaces & symbols!.txt"


class TestMatchesPattern:
    """Test _matches_pattern function."""

    @pytest.fixture
    def manager(self, tmp_path: Path) -> TrashManager:
        """Create a TrashManager with info directory."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)
        return TrashManager(trash_dir)

    def test_exact_match_filename(self, manager: TrashManager, tmp_path: Path) -> None:
        """Exact match on filename."""
        file_path = tmp_path / "test.txt"
        file_path.write_text("x")

        assert list_cmd._matches_pattern(file_path, "test.txt", manager)

    def test_glob_wildcard(self, manager: TrashManager, tmp_path: Path) -> None:
        """Glob wildcard patterns work."""
        file_path = tmp_path / "test.py"
        file_path.write_text("x")

        assert list_cmd._matches_pattern(file_path, "*.py", manager)
        assert not list_cmd._matches_pattern(file_path, "*.txt", manager)

    def test_question_mark_wildcard(self, manager: TrashManager, tmp_path: Path) -> None:
        """Question mark single character wildcard."""
        file_path = tmp_path / "file1.txt"
        file_path.write_text("x")

        assert list_cmd._matches_pattern(file_path, "file?.txt", manager)
        assert not list_cmd._matches_pattern(file_path, "file??.txt", manager)

    def test_character_class(self, manager: TrashManager, tmp_path: Path) -> None:
        """Character class patterns work."""
        file_path = tmp_path / "fileA.txt"
        file_path.write_text("x")

        assert list_cmd._matches_pattern(file_path, "file[ABC].txt", manager)
        assert not list_cmd._matches_pattern(file_path, "file[XYZ].txt", manager)

    def test_match_against_origin_path(self, manager: TrashManager, tmp_path: Path) -> None:
        """Pattern matches against origin path."""
        file_path = manager.files_dir / "renamed.txt"
        file_path.write_text("x")

        write_trashinfo(
            manager.info_dir / "renamed.txt.trashinfo",
            Path("/home/user/documents/original.txt"),
            datetime.now(),
        )

        # Match against origin path
        assert list_cmd._matches_pattern(file_path, "*documents*", manager)
        assert list_cmd._matches_pattern(file_path, "*original*", manager)

    def test_case_sensitive_match(self, manager: TrashManager, tmp_path: Path) -> None:
        """Pattern matching is case-sensitive (fnmatchcase)."""
        file_path = tmp_path / "Test.PY"
        file_path.write_text("x")

        assert list_cmd._matches_pattern(file_path, "Test.PY", manager)
        assert not list_cmd._matches_pattern(file_path, "test.py", manager)

    def test_missing_trashinfo_falls_back_to_filename(self, manager: TrashManager) -> None:
        """Missing trashinfo only matches against filename."""
        file_path = manager.files_dir / "orphan.txt"
        file_path.write_text("x")

        # No trashinfo exists, so only filename matching works
        assert list_cmd._matches_pattern(file_path, "orphan.txt", manager)
        assert list_cmd._matches_pattern(file_path, "*.txt", manager)
        assert not list_cmd._matches_pattern(file_path, "*nonexistent*", manager)

    def test_mac_style_no_info_dir(self, tmp_path: Path) -> None:
        """macOS style trash (no info dir) only matches filename."""
        trash_dir = tmp_path / ".Trash"
        trash_dir.mkdir()
        files_dir = trash_dir

        file_path = files_dir / "file.txt"
        file_path.write_text("x")

        manager = TrashManager(trash_dir)
        assert manager.info_dir is None

        assert list_cmd._matches_pattern(file_path, "*.txt", manager)
        assert not list_cmd._matches_pattern(file_path, "*.py", manager)


class TestSortKey:
    """Test _sort_key function."""

    def test_sort_by_time_default(self, tmp_path: Path) -> None:
        """Default sort is by time (newest first when reversed)."""
        now = datetime.now()

        entry1 = list_cmd.TrashEntry(
            path=tmp_path / "a.txt",
            name="a.txt",
            size_bytes=100,
            time_value=now - timedelta(hours=2),
            time_text="time1",
            origin_text="-",
        )
        entry2 = list_cmd.TrashEntry(
            path=tmp_path / "b.txt",
            name="b.txt",
            size_bytes=100,
            time_value=now - timedelta(hours=1),
            time_text="time2",
            origin_text="-",
        )

        key_func = list_cmd._sort_key("time")
        assert key_func(entry1) < key_func(entry2)

    def test_sort_by_time_none_last(self, tmp_path: Path) -> None:
        """Entries with no time sort last (datetime.min)."""
        now = datetime.now()

        entry_with_time = list_cmd.TrashEntry(
            path=tmp_path / "a.txt",
            name="a.txt",
            size_bytes=100,
            time_value=now,
            time_text="time",
            origin_text="-",
        )
        entry_no_time = list_cmd.TrashEntry(
            path=tmp_path / "b.txt",
            name="b.txt",
            size_bytes=100,
            time_value=None,
            time_text="-",
            origin_text="-",
        )

        key_func = list_cmd._sort_key("time")
        assert key_func(entry_no_time) < key_func(entry_with_time)

    def test_sort_by_size(self, tmp_path: Path) -> None:
        """Sort by size orders by bytes."""
        entry1 = list_cmd.TrashEntry(
            path=tmp_path / "small.txt",
            name="small.txt",
            size_bytes=100,
            time_value=datetime.now(),
            time_text="time",
            origin_text="-",
        )
        entry2 = list_cmd.TrashEntry(
            path=tmp_path / "large.txt",
            name="large.txt",
            size_bytes=1000,
            time_value=datetime.now(),
            time_text="time",
            origin_text="-",
        )

        key_func = list_cmd._sort_key("size")
        assert key_func(entry1) < key_func(entry2)

    def test_sort_by_size_with_tiebreaker(self, tmp_path: Path) -> None:
        """Size sort uses filename as tiebreaker."""
        entry_a = list_cmd.TrashEntry(
            path=tmp_path / "a.txt",
            name="a.txt",
            size_bytes=100,
            time_value=datetime.now(),
            time_text="time",
            origin_text="-",
        )
        entry_b = list_cmd.TrashEntry(
            path=tmp_path / "b.txt",
            name="b.txt",
            size_bytes=100,  # Same size
            time_value=datetime.now(),
            time_text="time",
            origin_text="-",
        )

        key_func = list_cmd._sort_key("size")
        # a < b alphabetically
        assert key_func(entry_a) < key_func(entry_b)

    def test_sort_by_time_with_tiebreaker(self, tmp_path: Path) -> None:
        """Time sort uses filename as tiebreaker."""
        same_time = datetime.now()

        entry_a = list_cmd.TrashEntry(
            path=tmp_path / "a.txt",
            name="a.txt",
            size_bytes=100,
            time_value=same_time,
            time_text="time",
            origin_text="-",
        )
        entry_b = list_cmd.TrashEntry(
            path=tmp_path / "b.txt",
            name="b.txt",
            size_bytes=100,
            time_value=same_time,  # Same time
            time_text="time",
            origin_text="-",
        )

        key_func = list_cmd._sort_key("time")
        assert key_func(entry_a) < key_func(entry_b)

    def test_sort_string_variants(self, tmp_path: Path) -> None:
        """Sort string handles variations (whitespace, case)."""
        entry = list_cmd.TrashEntry(
            path=tmp_path / "test.txt",
            name="test.txt",
            size_bytes=100,
            time_value=datetime.now(),
            time_text="time",
            origin_text="-",
        )

        # All these should return time sort (default)
        key_time = list_cmd._sort_key("time")(entry)
        assert list_cmd._sort_key("  time  ")(entry) == key_time
        assert list_cmd._sort_key("TIME")(entry) == key_time
        assert list_cmd._sort_key("Time")(entry) == key_time

    def test_case_insensitive_filename_sort(self, tmp_path: Path) -> None:
        """Filename tiebreaker is case-insensitive."""
        same_time = datetime.now()

        entry_a = list_cmd.TrashEntry(
            path=tmp_path / "Apple.txt",
            name="Apple.txt",
            size_bytes=100,
            time_value=same_time,
            time_text="time",
            origin_text="-",
        )
        entry_b = list_cmd.TrashEntry(
            path=tmp_path / "banana.txt",
            name="banana.txt",
            size_bytes=100,
            time_value=same_time,
            time_text="time",
            origin_text="-",
        )

        key_func = list_cmd._sort_key("time")
        # "apple" < "banana" alphabetically (case-insensitive)
        assert key_func(entry_a) < key_func(entry_b)


class TestRunIntegration:
    """Integration tests for list.run() function."""

    @patch("rmsafe.commands.list.load_config")
    @patch("rmsafe.commands.list.get_default_trash_path")
    def test_run_empty_trash(self, mock_get_default, mock_load_config, tmp_path: Path) -> None:
        """Running list on empty trash shows appropriate message."""
        from rmsafe.config.schema import Config

        mock_config = Config()
        mock_load_config.return_value = mock_config
        mock_get_default.return_value = tmp_path / "Trash"

        trash_dir = tmp_path / "Trash"
        trash_dir.mkdir()
        files_dir = trash_dir / "files"
        files_dir.mkdir()

        list_cmd.run(None)
        # Should not raise

    @patch("rmsafe.commands.list.load_config")
    @patch("rmsafe.commands.list.get_default_trash_path")
    def test_run_with_files(self, mock_get_default, mock_load_config, tmp_path: Path) -> None:
        """Running list with files displays table."""
        from rmsafe.config.schema import Config

        mock_config = Config()
        mock_load_config.return_value = mock_config
        mock_get_default.return_value = tmp_path / "Trash"

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create files
        for name in ["file1.txt", "file2.txt"]:
            (files_dir / name).write_text("content")
            write_trashinfo(
                info_dir / f"{name}.trashinfo",
                Path(f"/home/user/{name}"),
                datetime.now() - timedelta(hours=1),
            )

        list_cmd.run(None)
        # Should not raise

    @patch("rmsafe.commands.list.load_config")
    @patch("rmsafe.commands.list.get_default_trash_path")
    def test_run_with_pattern(self, mock_get_default, mock_load_config, tmp_path: Path) -> None:
        """Running list with pattern filters results."""
        from rmsafe.config.schema import Config

        mock_config = Config()
        mock_load_config.return_value = mock_config
        mock_get_default.return_value = tmp_path / "Trash"

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create files
        (files_dir / "test.py").write_text("python code")
        (files_dir / "test.txt").write_text("text content")

        write_trashinfo(info_dir / "test.py.trashinfo", Path("/home/user/test.py"), datetime.now())
        write_trashinfo(info_dir / "test.txt.trashinfo", Path("/home/user/test.txt"), datetime.now())

        list_cmd.run("*.py")
        # Should not raise

    @patch("rmsafe.commands.list.load_config")
    @patch("rmsafe.commands.list.get_default_trash_path")
    def test_run_with_sort_by_size(self, mock_get_default, mock_load_config, tmp_path: Path) -> None:
        """Running list with --sort size orders by size."""
        from rmsafe.config.schema import Config

        mock_config = Config()
        mock_load_config.return_value = mock_config
        mock_get_default.return_value = tmp_path / "Trash"

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create files with different sizes
        (files_dir / "small.txt").write_text("x" * 10)
        (files_dir / "large.txt").write_text("x" * 1000)

        write_trashinfo(info_dir / "small.txt.trashinfo", Path("/home/user/small.txt"), datetime.now())
        write_trashinfo(info_dir / "large.txt.trashinfo", Path("/home/user/large.txt"), datetime.now())

        list_cmd.run(None, sort="size")
        # Should not raise

    @patch("rmsafe.commands.list.load_config")
    @patch("rmsafe.commands.list.get_default_trash_path")
    def test_run_with_no_matching_files(self, mock_get_default, mock_load_config, tmp_path: Path) -> None:
        """Running list with pattern that matches nothing shows empty message."""
        from rmsafe.config.schema import Config

        mock_config = Config()
        mock_load_config.return_value = mock_config
        mock_get_default.return_value = tmp_path / "Trash"

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content")

        list_cmd.run("*.nonexistent")
        # Should not raise


class TestListTableStructure:
    """Test Rich Table structure for list output."""

    def test_table_has_correct_columns(self) -> None:
        """Table includes all required columns."""
        from rich.table import Table

        table = Table(title="Trash", header_style="bold", show_lines=False)
        table.add_column("Time", style="cyan", no_wrap=True)
        table.add_column("File", style="green")
        table.add_column("Size", justify="right", style="magenta")
        table.add_column("Origin", style="blue")

        assert len(table.columns) == 4
        column_names = [col.header for col in table.columns]
        assert "Time" in column_names
        assert "File" in column_names
        assert "Size" in column_names
        assert "Origin" in column_names

    def test_table_row_format(self, tmp_path: Path) -> None:
        """Table rows have correct data format."""
        from rich.table import Table

        table = Table(title="Trash", header_style="bold")

        entry = list_cmd.TrashEntry(
            path=tmp_path / "test.txt",
            name="test.txt",
            size_bytes=1024,
            time_value=datetime.now(),
            time_text="2024-01-15 10:30:00",
            origin_text="/home/user/test.txt",
        )

        from rmsafe.utils.size import format_size

        table.add_column("Time")
        table.add_column("File")
        table.add_column("Size")
        table.add_column("Origin")
        table.add_row(entry.time_text, entry.name, format_size(entry.size_bytes), entry.origin_text)

        # Verify row was added
        assert table.row_count == 1


class TestEdgeCases:
    """Test edge cases for list command."""

    def test_very_large_size_formatting(self) -> None:
        """Large sizes are formatted correctly."""
        from rmsafe.utils.size import format_size

        # GB
        assert format_size(1024**3) == "1 GB"
        # TB
        assert format_size(1024**4) == "1 TB"
        # Fractional GB
        result = format_size(int(1.5 * 1024**3))
        assert "1.5 GB" == result

    def test_zero_byte_file(self, tmp_path: Path) -> None:
        """Zero byte file is handled."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        file_path = files_dir / "empty.txt"
        file_path.write_text("")

        manager = TrashManager(trash_dir)
        entry = list_cmd._build_entry(file_path, manager)

        assert entry.size_bytes == 0

    def test_path_size_directory(self, tmp_path: Path) -> None:
        """Directory size is calculated recursively."""
        from rmsafe.utils.size import path_size

        dir_path = tmp_path / "testdir"
        dir_path.mkdir()
        (dir_path / "file1.txt").write_text("a" * 100)
        (dir_path / "subdir").mkdir()
        (dir_path / "subdir" / "file2.txt").write_text("b" * 200)

        size = path_size(dir_path)
        assert size == 300  # 100 + 200

    def test_multiple_files_total_size(self, tmp_path: Path) -> None:
        """Total size is calculated correctly for multiple files."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        sizes = [100, 200, 300]
        for i, size in enumerate(sizes):
            (files_dir / f"file{i}.txt").write_text("x" * size)

        manager = TrashManager(trash_dir)
        entries = list_cmd._collect_entries(manager, None)

        total = sum(e.size_bytes for e in entries)
        assert total == sum(sizes)

    def test_hidden_files_in_trash(self, tmp_path: Path) -> None:
        """Hidden files (dotfiles) are included in listing."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create hidden file
        (files_dir / ".hidden").write_text("hidden content")
        write_trashinfo(
            info_dir / ".hidden.trashinfo",
            Path("/home/user/.hidden"),
            datetime.now(),
        )

        manager = TrashManager(trash_dir)
        entries = list_cmd._collect_entries(manager, None)

        # Hidden files should be included
        names = [e.name for e in entries]
        assert ".hidden" in names

    def test_time_text_format(self, tmp_path: Path) -> None:
        """Time text is formatted correctly."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        file_path = files_dir / "timed.txt"
        file_path.write_text("content")

        # Specific deletion time
        deletion_time = datetime(2024, 3, 15, 14, 30, 45)
        write_trashinfo(
            info_dir / "timed.txt.trashinfo",
            Path("/home/user/timed.txt"),
            deletion_time,
        )

        manager = TrashManager(trash_dir)
        entry = list_cmd._build_entry(file_path, manager)

        # Time text should be formatted as "YYYY-MM-DD HH:MM:SS"
        assert entry.time_text == "2024-03-15 14:30:45"

    def test_broken_symlink_size(self, tmp_path: Path) -> None:
        """Broken symlink returns link size, not target size."""
        from rmsafe.utils.size import path_size

        # Create broken symlink
        link_path = tmp_path / "broken_link"
        link_path.symlink_to("/nonexistent/target")

        # Should return size of symlink itself, not error
        size = path_size(link_path)
        assert size >= 0  # Symlink has some size

    def test_relative_time_in_past(self, tmp_path: Path) -> None:
        """Entries from long ago are sorted correctly."""
        now = datetime.now()

        entry_recent = list_cmd.TrashEntry(
            path=tmp_path / "recent.txt",
            name="recent.txt",
            size_bytes=100,
            time_value=now - timedelta(hours=1),
            time_text="recent",
            origin_text="-",
        )
        entry_old = list_cmd.TrashEntry(
            path=tmp_path / "old.txt",
            name="old.txt",
            size_bytes=100,
            time_value=now - timedelta(days=365),
            time_text="old",
            origin_text="-",
        )

        key_func = list_cmd._sort_key("time")
        # Old should come before recent (for reverse sort to show newest first)
        assert key_func(entry_old) < key_func(entry_recent)


class TestPatternMatchingEdgeCases:
    """Edge cases for pattern matching."""

    def test_pattern_with_brackets(self, tmp_path: Path) -> None:
        """fnmatch treats brackets as character class, not literal."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        # File with brackets in name - fnmatch treats [1] as character class
        file_with_brackets = files_dir / "file[1].txt"
        file_with_brackets.write_text("x")

        # File matching the character class interpretation
        # Pattern "file[1].txt" means: "file" + one char from set {1} + ".txt"
        file_matching_class = files_dir / "file1.txt"
        file_matching_class.write_text("x")

        manager = TrashManager(trash_dir)

        # fnmatch treats [1] as character class, so pattern matches file1.txt
        assert list_cmd._matches_pattern(file_matching_class, "file[1].txt", manager)
        # But does NOT match literal "file[1].txt" because brackets have special meaning
        assert not list_cmd._matches_pattern(file_with_brackets, "file[1].txt", manager)

    def test_pattern_matches_multiple_positions(self, tmp_path: Path) -> None:
        """Star pattern matches at any position."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        file_path = files_dir / "middle_test_file.txt"
        file_path.write_text("x")

        manager = TrashManager(trash_dir)

        assert list_cmd._matches_pattern(file_path, "*test*", manager)
        assert list_cmd._matches_pattern(file_path, "middle*", manager)
        assert list_cmd._matches_pattern(file_path, "*file.txt", manager)

    def test_empty_pattern_matches_all(self, tmp_path: Path) -> None:
        """Empty string pattern behavior (treated as no filter)."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        file_path = files_dir / "any.txt"
        file_path.write_text("x")

        manager = TrashManager(trash_dir)

        # Empty string pattern matches nothing (fnmatch behavior)
        # But this is handled by _collect_entries which treats None/empty differently
        assert not list_cmd._matches_pattern(file_path, "", manager)