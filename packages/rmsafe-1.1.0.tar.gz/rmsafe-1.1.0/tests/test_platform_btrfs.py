"""Comprehensive tests for platform/btrfs.py following SQLite test philosophy."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

from rmsafe.platform.btrfs import (
    BTRFS_SUPER_MAGIC,
    BTRFS_IOC_CLONE,
    _is_linux,
    get_fs_type,
    is_btrfs,
    are_same_subvolume,
    btrfs_clone_file,
    trash_file_with_btrfs_support,
)

# Skip ctypes tests on non-Linux to avoid segfault
IS_LINUX = sys.platform.startswith("linux")


class TestConstants:
    """Btrfs constants - verify values."""

    def test_btrfs_magic_value(self) -> None:
        assert BTRFS_SUPER_MAGIC == 0x9123683E

    def test_ioctl_clone_value(self) -> None:
        assert BTRFS_IOC_CLONE == 0x40049409


class TestIsLinux:
    """_is_linux() - every platform."""

    def test_linux_returns_true(self, monkeypatch) -> None:
        # Patch the module-level variable, not sys.platform
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        assert _is_linux() is True

    def test_linux2_returns_true(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        assert _is_linux() is True

    def test_darwin_returns_false(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", False)
        assert _is_linux() is False

    def test_windows_returns_false(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", False)
        assert _is_linux() is False


class TestGetFsType:
    """get_fs_type() - every platform, every path state."""

    def test_non_linux_returns_none(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", False)
        result = get_fs_type("/tmp")
        assert result is None

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_nonexistent_path_on_linux(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        # Falls back to parent directory
        result = get_fs_type("/nonexistent/path/file.txt")
        # Result depends on actual filesystem
        assert result is None or isinstance(result, int)

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_existing_path_on_linux(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        # Uses actual path, result depends on environment
        result = get_fs_type("/tmp")
        assert result is None or isinstance(result, int)

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_string_path(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        result = get_fs_type("/tmp")
        assert result is None or isinstance(result, int)

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_path_object(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        result = get_fs_type(Path("/tmp"))
        assert result is None or isinstance(result, int)

    @pytest.mark.skip(reason="Linux allows owner to statfs chmod 000 directories")
    def test_permission_denied(self, monkeypatch, tmp_path: Path) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        restricted = tmp_path / "restricted"
        restricted.mkdir()
        os.chmod(restricted, 0o000)
        try:
            result = get_fs_type(restricted)
            # statfs fails, returns None
            assert result is None
        finally:
            os.chmod(restricted, 0o755)


class TestIsBtrfs:
    """is_btrfs() - every platform, every filesystem."""

    def test_non_linux_returns_false(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", False)
        assert is_btrfs("/tmp") is False

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_linux_non_btrfs_returns_false(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        # Most systems won't have btrfs at /tmp
        # We can't guarantee the result, but it should return bool
        result = is_btrfs("/tmp")
        assert isinstance(result, bool)


class TestAreSameSubvolume:
    """are_same_subvolume() - every scenario, every platform."""

    def test_non_linux_returns_false(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", False)
        assert are_same_subvolume("/tmp/a", "/tmp/b") is False

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_linux_different_fs_returns_false(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        # Different filesystems
        result = are_same_subvolume("/tmp/a", "/home/b")
        assert isinstance(result, bool)

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_one_path_nonexistent(self, monkeypatch, tmp_path: Path) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        existing = tmp_path / "exists"
        existing.mkdir()
        result = are_same_subvolume(existing, "/nonexistent/path")
        # OSError caught, returns False
        assert result is False

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_both_paths_nonexistent(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        result = are_same_subvolume("/nonexistent/a", "/nonexistent/b")
        assert result is False


class TestBtrfsCloneFile:
    """btrfs_clone_file() - every scenario, every error."""

    def test_non_linux_returns_false(self, monkeypatch) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", False)
        result = btrfs_clone_file("/tmp/src", "/tmp/dest")
        assert result is False

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_nonexistent_source(self, monkeypatch, tmp_path: Path) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        src = tmp_path / "nonexistent.txt"
        dest = tmp_path / "dest.txt"
        result = btrfs_clone_file(src, dest)
        # Fails, returns False
        assert result is False

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_nonexistent_dest_parent(self, monkeypatch, tmp_path: Path) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        src = tmp_path / "src.txt"
        src.write_text("content", encoding="utf-8")
        dest = tmp_path / "nonexistent" / "nested" / "dest.txt"
        result = btrfs_clone_file(src, dest)
        # Will attempt to create parent dirs
        assert isinstance(result, bool)

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_dest_already_exists(self, monkeypatch, tmp_path: Path) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        src = tmp_path / "src.txt"
        src.write_text("source", encoding="utf-8")
        dest = tmp_path / "dest.txt"
        dest.write_text("existing", encoding="utf-8")
        # Uses O_EXCL, so fails if file exists
        result = btrfs_clone_file(src, dest)
        assert result is False

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_permission_denied_source(self, monkeypatch, tmp_path: Path) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        src = tmp_path / "secret.txt"
        src.write_text("secret", encoding="utf-8")
        os.chmod(src, 0o000)
        dest = tmp_path / "dest.txt"
        try:
            result = btrfs_clone_file(src, dest)
            assert result is False
        finally:
            os.chmod(src, 0o644)

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_permission_denied_dest_parent(self, monkeypatch, tmp_path: Path) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        restricted = tmp_path / "restricted"
        restricted.mkdir()
        os.chmod(restricted, 0o000)
        src = tmp_path / "src.txt"
        src.write_text("content", encoding="utf-8")
        dest = restricted / "dest.txt"
        try:
            result = btrfs_clone_file(src, dest)
            assert result is False
        finally:
            os.chmod(restricted, 0o755)

    @pytest.mark.skipif(not IS_LINUX, reason="ctypes statfs only works on Linux")
    def test_creates_destination_parent(self, monkeypatch, tmp_path: Path) -> None:
        import rmsafe.platform.btrfs as btrfs_module
        monkeypatch.setattr(btrfs_module, "_IS_LINUX", True)
        src = tmp_path / "src.txt"
        src.write_text("content", encoding="utf-8")
        dest_dir = tmp_path / "newdir"
        dest = dest_dir / "dest.txt"
        # This will attempt to create dest_dir
        result = btrfs_clone_file(src, dest)
        # Result depends on filesystem
        assert isinstance(result, bool)


class TestTrashFileWithBtrfsSupport:
    """trash_file_with_btrfs_support() - every fallback scenario."""

    def test_rename_success(self, tmp_path: Path) -> None:
        src = tmp_path / "src.txt"
        src.write_text("content", encoding="utf-8")
        dest_dir = tmp_path / "dest"
        dest_dir.mkdir()
        dest = dest_dir / "src.txt"

        result = trash_file_with_btrfs_support(src, dest)
        assert result is True
        assert not src.exists()
        assert dest.read_text() == "content"

    def test_rename_cross_device_falls_back(self, tmp_path: Path) -> None:
        src = tmp_path / "src.txt"
        src.write_text("content", encoding="utf-8")
        dest_dir = tmp_path / "dest"
        dest_dir.mkdir()
        dest = dest_dir / "src.txt"

        # Normal rename should work within same filesystem
        result = trash_file_with_btrfs_support(src, dest)
        assert result is True

    def test_creates_destination_parent(self, tmp_path: Path) -> None:
        src = tmp_path / "src.txt"
        src.write_text("content", encoding="utf-8")
        dest_dir = tmp_path / "nested" / "deep"
        dest = dest_dir / "src.txt"

        result = trash_file_with_btrfs_support(src, dest)
        assert result is True
        assert dest_dir.exists()

    def test_source_nonexistent_raises(self, tmp_path: Path) -> None:
        src = tmp_path / "nonexistent.txt"
        dest = tmp_path / "dest.txt"

        with pytest.raises(OSError):
            trash_file_with_btrfs_support(src, dest)

    @pytest.mark.skip(reason="Linux and macOS both allow owner to access chmod 000 files")
    def test_permission_denied_source(self, tmp_path: Path) -> None:
        src = tmp_path / "secret.txt"
        src.write_text("secret", encoding="utf-8")
        os.chmod(src, 0o000)
        dest = tmp_path / "dest.txt"

        try:
            with pytest.raises(OSError):
                trash_file_with_btrfs_support(src, dest)
        finally:
            os.chmod(src, 0o644)

    def test_permission_denied_dest_parent(self, tmp_path: Path) -> None:
        restricted = tmp_path / "restricted"
        restricted.mkdir()
        os.chmod(restricted, 0o000)
        src = tmp_path / "src.txt"
        src.write_text("content", encoding="utf-8")
        dest = restricted / "dest.txt"

        try:
            with pytest.raises(OSError):
                trash_file_with_btrfs_support(src, dest)
        finally:
            os.chmod(restricted, 0o755)

    def test_copy_preserves_content(self, tmp_path: Path) -> None:
        src = tmp_path / "src.txt"
        src.write_text("test content\nmultiple lines", encoding="utf-8")
        dest = tmp_path / "dest.txt"

        result = trash_file_with_btrfs_support(src, dest)
        assert result is True
        assert dest.read_text() == "test content\nmultiple lines"

    def test_empty_file(self, tmp_path: Path) -> None:
        src = tmp_path / "empty.txt"
        src.write_text("", encoding="utf-8")
        dest = tmp_path / "dest.txt"

        result = trash_file_with_btrfs_support(src, dest)
        assert result is True
        assert dest.exists()
        assert dest.read_text() == ""

    def test_large_file(self, tmp_path: Path) -> None:
        src = tmp_path / "large.txt"
        src.write_text("x" * 10000, encoding="utf-8")
        dest = tmp_path / "dest.txt"

        result = trash_file_with_btrfs_support(src, dest)
        assert result is True
        assert len(dest.read_text()) == 10000

    def test_binary_file(self, tmp_path: Path) -> None:
        src = tmp_path / "binary.bin"
        src.write_bytes(b"\x00\x01\x02\xff\xfe\xfd")
        dest = tmp_path / "dest.bin"

        result = trash_file_with_btrfs_support(src, dest)
        assert result is True
        assert dest.read_bytes() == b"\x00\x01\x02\xff\xfe\xfd"

    def test_symlink_moves_as_symlink(self, tmp_path: Path) -> None:
        """os.rename moves symlinks as-is (not the target)."""
        target = tmp_path / "target.txt"
        target.write_text("content", encoding="utf-8")
        src = tmp_path / "link.txt"
        src.symlink_to(target)
        dest = tmp_path / "dest.txt"

        # os.rename succeeds first, moving the symlink itself
        result = trash_file_with_btrfs_support(src, dest)
        assert result is True
        # dest is still a symlink pointing to the same target
        assert dest.is_symlink()
        assert dest.resolve() == target
        assert not src.exists()  # symlink was moved

    def test_cleanup_on_partial_failure(self, tmp_path: Path) -> None:
        src = tmp_path / "src.txt"
        src.write_text("content", encoding="utf-8")
        dest_dir = tmp_path / "dest"
        dest_dir.mkdir()
        dest = dest_dir / "src.txt"
        dest.write_text("existing", encoding="utf-8")

        # If rename fails and copy fails, cleanup attempted
        # In this case on same filesystem rename might succeed
        result = trash_file_with_btrfs_support(src, dest)
        # Behavior depends on whether rename overwrites
        assert isinstance(result, bool)


class TestIntegration:
    """Integration tests for btrfs module."""

    def test_full_trash_flow_non_btrfs(self, tmp_path: Path) -> None:
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")
        trash_files = tmp_path / "Trash" / "files"
        trash_files.mkdir(parents=True)
        dest = trash_files / "file.txt"

        result = trash_file_with_btrfs_support(src, dest)
        assert result is True
        assert not src.exists()
        assert dest.exists()

    def test_path_vs_string_input(self, tmp_path: Path) -> None:
        src = tmp_path / "src.txt"
        src.write_text("content", encoding="utf-8")
        dest = tmp_path / "dest.txt"

        # Both work with Path and string
        result = trash_file_with_btrfs_support(str(src), str(dest))
        assert result is True

        # Cleanup
        dest.unlink()
        src.write_text("content", encoding="utf-8")
        result = trash_file_with_btrfs_support(Path(src), Path(dest))
        assert result is True