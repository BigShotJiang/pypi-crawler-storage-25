from __future__ import annotations

from pathlib import Path

import rmsafe.commands.trash as trash_command
from rmsafe.commands.trash import run
from rmsafe.config.schema import Config, TrashConfig, OutputConfig, BehaviorConfig, BtrfsConfig


def test_trash_command_reports_success_and_moves_file(tmp_path: Path, capsys) -> None:
    trash_dir = tmp_path / "Trash"
    src = tmp_path / "report.txt"
    src.write_text("hello", encoding="utf-8")

    config = Config(
        trash=TrashConfig(location=trash_dir),
        behavior=BehaviorConfig(),
        output=OutputConfig(color="never", verbose=True, icons=True, table_format="rounded"),
        btrfs=BtrfsConfig(),
    )

    run([src], {"config": config, "dry_run": False, "colors": None})

    out = capsys.readouterr().out
    assert "report.txt" in out
    assert "5 bytes" in out
    assert "Trash/" in out
    assert not src.exists()
    assert (trash_dir / "files" / "report.txt").exists()


def test_trash_command_prompts_for_large_files(tmp_path: Path, monkeypatch, capsys) -> None:
    trash_dir = tmp_path / "Trash"
    src = tmp_path / "video.bin"
    src.write_bytes(b"x" * (10 * 1024 * 1024 + 1))

    config = Config(
        trash=TrashConfig(location=trash_dir),
        behavior=BehaviorConfig(confirm_large_files="10MB"),
        output=OutputConfig(color="never", verbose=True, icons=True, table_format="rounded"),
        btrfs=BtrfsConfig(),
    )

    called = {}

    monkeypatch.setattr(trash_command, "is_tty", lambda stream=None: True)
    monkeypatch.setattr(trash_command.Confirm, "ask", staticmethod(lambda prompt, default=False: called.setdefault("prompt", prompt) or True))

    run([src], {"config": config, "dry_run": False, "colors": None})

    out = capsys.readouterr().out
    assert "video.bin" in out
    assert "prompt" in called
    assert not src.exists()
    assert (trash_dir / "files" / "video.bin").exists()
