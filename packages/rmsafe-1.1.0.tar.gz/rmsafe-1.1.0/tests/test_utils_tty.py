"""Comprehensive tests for utils/tty.py following SQLite test philosophy."""
from __future__ import annotations

import io
import os
import sys
from pathlib import Path

import pytest

from rmsafe.utils.tty import is_tty, should_use_color


class TestIsTty:
    """is_tty() - every stream type, every error path."""

    def test_stdout_is_tty_when_terminal(self) -> None:
        # This test's result depends on environment
        # We can only verify the function doesn't crash
        result = is_tty(sys.stdout)
        assert isinstance(result, bool)

    def test_stdin_is_tty(self) -> None:
        result = is_tty(sys.stdin)
        assert isinstance(result, bool)

    def test_stderr_is_tty(self) -> None:
        result = is_tty(sys.stderr)
        assert isinstance(result, bool)

    def test_file_object_not_tty(self, tmp_path: Path) -> None:
        file = tmp_path / "test.txt"
        file.write_text("test", encoding="utf-8")
        with file.open("r") as fp:
            assert is_tty(fp) is False

    def test_stringio_not_tty(self) -> None:
        stream = io.StringIO()
        assert is_tty(stream) is False

    def test_bytesio_not_tty(self) -> None:
        stream = io.BytesIO()
        assert is_tty(stream) is False

    def test_object_without_isatty(self) -> None:
        class NoIsatty:
            pass
        obj = NoIsatty()
        # getattr returns None, callable check fails
        assert is_tty(obj) is False

    def test_object_with_isatty_method(self) -> None:
        class WithIsatty:
            def isatty(self) -> bool:
                return True
        obj = WithIsatty()
        assert is_tty(obj) is True

    def test_object_with_isatty_false(self) -> None:
        class WithIsattyFalse:
            def isatty(self) -> bool:
                return False
        obj = WithIsattyFalse()
        assert is_tty(obj) is False

    def test_object_with_isatty_non_callable(self) -> None:
        class NonCallableIsatty:
            isatty = "not a method"
        obj = NonCallableIsatty()
        # callable check fails
        assert is_tty(obj) is False

    def test_default_parameter(self) -> None:
        # Default is sys.stdout
        result = is_tty()
        assert isinstance(result, bool)


class TestShouldUseColor:
    """should_use_color() - every setting, every environment, every error."""

    def test_always_true(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        assert should_use_color("always") is True

    def test_always_respects_no_color(self, monkeypatch) -> None:
        # NO_COLOR always disables in this implementation
        monkeypatch.setenv("NO_COLOR", "1")
        assert should_use_color("always") is False

    def test_never_false(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        assert should_use_color("never") is False

    def test_never_with_no_color(self, monkeypatch) -> None:
        monkeypatch.setenv("NO_COLOR", "1")
        assert should_use_color("never") is False

    def test_auto_with_tty(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        # Result depends on actual TTY state
        result = should_use_color("auto")
        assert isinstance(result, bool)

    def test_auto_no_color_override(self, monkeypatch) -> None:
        monkeypatch.setenv("NO_COLOR", "1")
        assert should_use_color("auto") is False

    def test_no_color_empty_string(self, monkeypatch) -> None:
        # NO_COLOR presence alone disables, value doesn't matter
        monkeypatch.setenv("NO_COLOR", "")
        assert should_use_color("auto") is False

    def test_no_color_any_value(self, monkeypatch) -> None:
        monkeypatch.setenv("NO_COLOR", "anything")
        assert should_use_color("auto") is False

    def test_uppercase_setting(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        assert should_use_color("ALWAYS") is True
        assert should_use_color("NEVER") is False

    def test_mixed_case_setting(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        assert should_use_color("Always") is True
        assert should_use_color("NeVeR") is False

    def test_setting_with_whitespace(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        assert should_use_color("  always  ") is True
        assert should_use_color(" never ") is False

    def test_invalid_setting_raises(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        with pytest.raises(ValueError, match="Unsupported"):
            should_use_color("invalid")

    def test_invalid_setting_uppercase_raises(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        with pytest.raises(ValueError, match="Unsupported"):
            should_use_color("INVALID")

    def test_empty_setting_raises(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        with pytest.raises(ValueError, match="Unsupported"):
            should_use_color("")

    def test_whitespace_only_raises(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        with pytest.raises(ValueError, match="Unsupported"):
            should_use_color("   ")

    def test_default_parameter(self, monkeypatch) -> None:
        monkeypatch.delenv("NO_COLOR", raising=False)
        # Default is "auto"
        result = should_use_color()
        assert isinstance(result, bool)