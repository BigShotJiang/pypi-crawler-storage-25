"""Comprehensive tests for core/trash_manager.py following SQLite test philosophy."""
from __future__ import annotations

import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import pytest

from rmsafe.core.trash_manager import TrashManager, TrashResult, OrphanEntry, ConsistencyReport
from rmsafe.utils.filelock import FileLock, LockTimeout


class TestTrashResult:
    """TrashResult - all fields, all states."""

    def test_success_result(self, tmp_path: Path) -> None:
        result = TrashResult(
            source=tmp_path / "src.txt",
            destination=tmp_path / "dest.txt",
            info_path=tmp_path / "info.trashinfo",
            size_bytes=100,
            size_text="100 bytes",
            dry_run=False,
            success=True,
            message="trashed",
            error=None,
        )
        assert result.success is True
        assert result.error is None

    def test_failure_result(self, tmp_path: Path) -> None:
        result = TrashResult(
            source=tmp_path / "src.txt",
            destination=None,
            info_path=None,
            size_bytes=None,
            size_text=None,
            dry_run=False,
            success=False,
            message="failed",
            error="Permission denied",
        )
        assert result.success is False
        assert result.error == "Permission denied"

    def test_dry_run_result(self, tmp_path: Path) -> None:
        result = TrashResult(
            source=tmp_path / "src.txt",
            destination=tmp_path / "dest.txt",
            info_path=tmp_path / "info.trashinfo",
            size_bytes=100,
            size_text="100 bytes",
            dry_run=True,
            success=True,
            message="dry run",
        )
        assert result.dry_run is True


class TestOrphanEntry:
    """OrphanEntry - all fields."""

    def test_orphan_file_entry(self, tmp_path: Path) -> None:
        orphan_path = tmp_path / "orphan.txt"
        entry = OrphanEntry(
            path=orphan_path,
            orphan_type="file",
            message="Orphan file without .trashinfo"
        )
        assert entry.path == orphan_path
        assert entry.orphan_type == "file"

    def test_orphan_info_entry(self, tmp_path: Path) -> None:
        info_path = tmp_path / "info" / "missing.trashinfo"
        entry = OrphanEntry(
            path=info_path,
            orphan_type="info",
            message="Orphan .trashinfo without file"
        )
        assert entry.orphan_type == "info"


class TestConsistencyReport:
    """ConsistencyReport - all fields."""

    def test_consistent_report(self) -> None:
        report = ConsistencyReport(
            consistent=True,
            orphan_files=[],
            orphan_infos=[],
            missing_infos=[],
            errors=[]
        )
        assert report.consistent is True
        assert len(report.orphan_files) == 0

    def test_inconsistent_report(self, tmp_path: Path) -> None:
        report = ConsistencyReport(
            consistent=False,
            orphan_files=[tmp_path / "orphan.txt"],
            orphan_infos=[tmp_path / "missing.trashinfo"],
            missing_infos=[tmp_path / "orphan.txt"],
            errors=[]
        )
        assert report.consistent is False
        assert len(report.orphan_files) == 1


class TestTrashManagerInit:
    """TrashManager.__init__() - every path type, every platform."""

    def test_linux_trash_layout(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "linux")
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)
        assert manager.files_dir == trash_dir / "files"
        assert manager.info_dir == trash_dir / "info"
        assert manager._mac_style is False

    def test_macos_trash_layout(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        trash_dir = tmp_path / ".Trash"
        manager = TrashManager(trash_dir)
        assert manager.files_dir == trash_dir
        assert manager.info_dir is None
        assert manager._mac_style is True

    def test_non_dot_trash_on_macos(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        trash_dir = tmp_path / "custom_trash"
        manager = TrashManager(trash_dir)
        # Not .Trash name, so uses Linux-style layout
        assert manager.files_dir == trash_dir / "files"
        assert manager.info_dir == trash_dir / "info"
        assert manager._mac_style is False

    def test_dot_trash_on_linux(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "linux")
        trash_dir = tmp_path / ".Trash"
        manager = TrashManager(trash_dir)
        # .Trash name on Linux doesn't trigger mac-style
        assert manager.files_dir == trash_dir / "files"
        assert manager.info_dir == trash_dir / "info"

    def test_home_expansion(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setenv("HOME", str(tmp_path))
        manager = TrashManager(Path("~/trash"))
        assert manager.trash_dir == tmp_path / "trash"

    def test_absolute_path(self) -> None:
        manager = TrashManager(Path("/tmp/trash"))
        assert manager.trash_dir == Path("/tmp/trash")


class TestTrashFile:
    """TrashManager.trash_file() - every scenario, every error."""

    def test_basic_file(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.success is True
        assert result.destination == trash_dir / "files" / "file.txt"
        assert result.info_path == trash_dir / "info" / "file.txt.trashinfo"
        assert not src.exists()
        assert (trash_dir / "files" / "file.txt").read_text() == "content"

    def test_nonexistent_file(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src = tmp_path / "nonexistent.txt"

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.success is False
        assert "does not exist" in result.message
        assert result.destination is None

    def test_dry_run_preserves_source(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src, dry_run=True)

        assert result.success is True
        assert result.dry_run is True
        assert src.exists()
        assert not (trash_dir / "files").exists()

    def test_conflict_naming_single(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        (trash_dir / "files").mkdir(parents=True)
        (trash_dir / "files" / "file.txt").write_text("existing", encoding="utf-8")

        src = tmp_path / "file.txt"
        src.write_text("new", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.success is True
        assert result.destination == trash_dir / "files" / "file_1.txt"
        assert (trash_dir / "files" / "file_1.txt").read_text() == "new"

    def test_conflict_naming_multiple(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "file.txt").write_text("first", encoding="utf-8")
        (files_dir / "file_1.txt").write_text("second", encoding="utf-8")
        (files_dir / "file_2.txt").write_text("third", encoding="utf-8")

        src = tmp_path / "file.txt"
        src.write_text("fourth", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.success is True
        assert result.destination == trash_dir / "files" / "file_3.txt"

    def test_conflict_with_suffixes(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "file.tar.gz").write_text("existing", encoding="utf-8")

        src = tmp_path / "file.tar.gz"
        src.write_text("new", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.success is True
        assert result.destination == trash_dir / "files" / "file_1.tar.gz"
        assert result.destination.name.endswith(".tar.gz")

    def test_multiple_suffixes(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "archive.tar.bz2.xz").write_text("existing", encoding="utf-8")

        src = tmp_path / "archive.tar.bz2.xz"
        src.write_text("new", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.success is True
        # All suffixes preserved: .tar.bz2.xz
        assert result.destination.name.endswith(".tar.bz2.xz")

    def test_file_without_suffix(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "README").write_text("existing", encoding="utf-8")

        src = tmp_path / "README"
        src.write_text("new", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.success is True
        assert result.destination == trash_dir / "files" / "README_1"

    @pytest.mark.skip(reason="Linux and macOS both allow owner to access chmod 000 files")
    def test_permission_denied_source(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src = tmp_path / "secret.txt"
        src.write_text("secret", encoding="utf-8")
        os.chmod(src, 0o000)

        try:
            manager = TrashManager(trash_dir)
            result = manager.trash_file(src)
            assert result.success is False
            assert "Permission denied" in result.message
        finally:
            os.chmod(src, 0o644)

    @pytest.mark.skip(reason="Linux and macOS both allow owner to access chmod 000 directories")
    def test_permission_denied_trash_dir(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        trash_dir.mkdir()
        os.chmod(trash_dir, 0o000)

        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        try:
            manager = TrashManager(trash_dir)
            result = manager.trash_file(src)
            assert result.success is False
        finally:
            os.chmod(trash_dir, 0o755)

    def test_size_reporting(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src = tmp_path / "large.txt"
        src.write_text("x" * 2048, encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.size_bytes == 2048
        assert "KB" in result.size_text

    def test_empty_file_size(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src = tmp_path / "empty.txt"
        src.write_text("", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.size_bytes == 0
        assert result.size_text == "0 bytes"

    def test_macos_layout_no_info_file(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        trash_dir = tmp_path / ".Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.success is True
        assert result.destination == trash_dir / "file.txt"
        assert result.info_path is None
        assert not (trash_dir / "info").exists()

    def test_trashinfo_content_matches_source(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src = tmp_path / "original.txt"
        src.write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.info_path is not None
        info_content = result.info_path.read_text(encoding="utf-8")
        assert str(src.absolute()) in info_content


class TestTrashDirectory:
    """TrashManager.trash_directory() - every scenario."""

    def test_empty_directory(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src_dir = tmp_path / "empty_dir"
        src_dir.mkdir()

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(src_dir)

        assert result.success is True
        assert not src_dir.exists()
        assert (trash_dir / "files" / "empty_dir").is_dir()

    def test_directory_with_files(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src_dir = tmp_path / "dir"
        src_dir.mkdir()
        (src_dir / "a.txt").write_text("a", encoding="utf-8")
        (src_dir / "b.txt").write_text("b", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(src_dir)

        assert result.success is True
        trashed_dir = trash_dir / "files" / "dir"
        assert (trashed_dir / "a.txt").read_text() == "a"
        assert (trashed_dir / "b.txt").read_text() == "b"

    def test_nested_directory(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src_dir = tmp_path / "nested"
        inner = src_dir / "inner"
        inner.mkdir(parents=True)
        (src_dir / "top.txt").write_text("top", encoding="utf-8")
        (inner / "bottom.txt").write_text("bottom", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(src_dir)

        assert result.success is True
        trashed = trash_dir / "files" / "nested"
        assert (trashed / "top.txt").read_text() == "top"
        assert (trashed / "inner" / "bottom.txt").read_text() == "bottom"

    def test_directory_dry_run(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src_dir = tmp_path / "dir"
        src_dir.mkdir()
        (src_dir / "file.txt").write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(src_dir, dry_run=True)

        assert result.success is True
        assert result.dry_run is True
        assert src_dir.exists()
        assert not (trash_dir / "files").exists()

    def test_directory_conflict(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "dir").mkdir()

        src_dir = tmp_path / "dir"
        src_dir.mkdir()
        (src_dir / "file.txt").write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(src_dir)

        assert result.success is True
        assert result.destination == trash_dir / "files" / "dir_1"

    def test_nonexistent_directory(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        src_dir = tmp_path / "nonexistent"

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(src_dir)

        assert result.success is False
        assert "does not exist" in result.message


class TestNamesMatch:
    """TrashManager.names_match() - every platform behavior."""

    def test_exact_match(self, tmp_path: Path) -> None:
        manager = TrashManager(tmp_path / "Trash")
        assert manager.names_match("file.txt", "file.txt") is True

    def test_different_names(self, tmp_path: Path) -> None:
        manager = TrashManager(tmp_path / "Trash")
        assert manager.names_match("file.txt", "other.txt") is False

    def test_case_sensitive_linux(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "linux")
        manager = TrashManager(tmp_path / "Trash")
        assert manager.names_match("File.txt", "file.txt") is False

    def test_case_insensitive_macos(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        trash_dir = tmp_path / ".Trash"
        manager = TrashManager(trash_dir)
        assert manager.names_match("File.txt", "file.txt") is True

    def test_case_insensitive_macos_not_dot_trash(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        manager = TrashManager(tmp_path / "custom")
        # Only .Trash triggers case-insensitive matching
        assert manager.names_match("File.txt", "file.txt") is False


class TestAppendSuffix:
    """_append_suffix() - every filename pattern."""

    def test_single_suffix(self) -> None:
        result = TrashManager._append_suffix("file.txt", 1)
        assert result == "file_1.txt"

    def test_multiple_suffixes(self) -> None:
        result = TrashManager._append_suffix("archive.tar.gz", 2)
        assert result == "archive_2.tar.gz"

    def test_no_suffix(self) -> None:
        result = TrashManager._append_suffix("README", 3)
        assert result == "README_3"

    def test_dotfile(self) -> None:
        result = TrashManager._append_suffix(".hidden", 1)
        assert result == ".hidden_1"

    def test_complex_suffixes(self) -> None:
        result = TrashManager._append_suffix("file.a.b.c.d", 1)
        assert result == "file_1.a.b.c.d"


class TestSymlinkToFile:
    """Symlink to file - link moved, target unchanged."""

    def test_symlink_to_file_moves_link_only(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        target = tmp_path / "target.txt"
        target.write_text("target content", encoding="utf-8")
        link = tmp_path / "link_to_file"
        link.symlink_to(target)

        manager = TrashManager(trash_dir)
        result = manager.trash_file(link)

        assert result.success is True
        assert not link.exists()  # link removed
        assert not link.is_symlink()  # link itself gone
        assert target.exists()  # target still there
        assert target.read_text() == "target content"
        # Trashed item is still a symlink pointing to same target
        trashed = trash_dir / "files" / "link_to_file"
        assert trashed.is_symlink()
        assert trashed.resolve() == target.resolve()

    def test_symlink_to_file_preserves_target_content(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        target = tmp_path / "original.txt"
        target.write_text("unchanged", encoding="utf-8")
        link = tmp_path / "shortcut"
        link.symlink_to(target)

        manager = TrashManager(trash_dir)
        manager.trash_file(link)

        # Target content should be untouched
        assert target.read_text() == "unchanged"
        # Verify the moved symlink still works
        trashed_link = trash_dir / "files" / "shortcut"
        assert trashed_link.read_text() == "unchanged"


class TestSymlinkToDirectory:
    """Symlink to directory - link moved, directory unchanged."""

    def test_symlink_to_directory_moves_link_only(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        target_dir = tmp_path / "actual_dir"
        target_dir.mkdir()
        (target_dir / "file.txt").write_text("inside dir", encoding="utf-8")
        link = tmp_path / "dir_link"
        link.symlink_to(target_dir)

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(link)

        assert result.success is True
        assert not link.exists()
        assert not link.is_symlink()
        assert target_dir.is_dir()
        assert (target_dir / "file.txt").read_text() == "inside dir"

    def test_symlink_to_directory_preserves_directory_contents(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        target_dir = tmp_path / "real_directory"
        target_dir.mkdir()
        (target_dir / "a.txt").write_text("a", encoding="utf-8")
        (target_dir / "subdir").mkdir()
        (target_dir / "subdir" / "b.txt").write_text("b", encoding="utf-8")
        link = tmp_path / "mylink"
        link.symlink_to(target_dir)

        manager = TrashManager(trash_dir)
        manager.trash_directory(link)

        # Original directory untouched
        assert (target_dir / "a.txt").read_text() == "a"
        assert (target_dir / "subdir" / "b.txt").read_text() == "b"
        # Trashed symlink still points to it
        trashed_link = trash_dir / "files" / "mylink"
        assert trashed_link.is_symlink()
        assert (trashed_link / "a.txt").read_text() == "a"


class TestBrokenSymlink:
    """Broken symlink (target does not exist)."""

    def test_broken_symlink_to_file(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        missing_target = tmp_path / "nonexistent.txt"
        link = tmp_path / "broken_link"
        link.symlink_to(missing_target)
        # Don't create the target - it's a broken link

        manager = TrashManager(trash_dir)
        result = manager.trash_file(link)

        # Broken symlinks should still be trashable
        assert result.success is True
        assert not link.exists()
        assert not link.is_symlink()
        trashed = trash_dir / "files" / "broken_link"
        assert trashed.is_symlink()
        # Still points to the nonexistent target
        assert trashed.resolve() == missing_target.resolve()

    def test_broken_symlink_to_directory(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        missing_dir = tmp_path / "nonexistent_dir"
        link = tmp_path / "broken_dir_link"
        link.symlink_to(missing_dir)

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(link)

        assert result.success is True
        assert not link.is_symlink()
        trashed = trash_dir / "files" / "broken_dir_link"
        assert trashed.is_symlink()

    def test_chain_of_broken_symlinks(self, tmp_path: Path) -> None:
        """Multiple broken symlinks in sequence."""
        trash_dir = tmp_path / "Trash"
        link1 = tmp_path / "link1"
        link2 = tmp_path / "link2"
        link3 = tmp_path / "link3"

        # link3 -> link2 -> link1 -> nonexistent (all broken)
        link1.symlink_to(tmp_path / "nowhere1")
        link2.symlink_to(link1)
        link3.symlink_to(link2)

        manager = TrashManager(trash_dir)
        result = manager.trash_file(link3)

        assert result.success is True
        trashed = trash_dir / "files" / "link3"
        assert trashed.is_symlink()
        # The trashed link should still point to link2
        assert os.readlink(trashed) == str(link2)


class TestSymlinkCycle:
    """Symlink cycle - directory containing symlink pointing to ancestor."""

    def test_symlink_cycle_in_directory(self, tmp_path: Path) -> None:
        """Directory with symlink pointing to ancestor creates cycle."""
        trash_dir = tmp_path / "Trash"
        src_dir = tmp_path / "cyclic_dir"
        src_dir.mkdir()
        (src_dir / "file.txt").write_text("content", encoding="utf-8")
        # Create symlink pointing to ancestor (cycle)
        cycle_link = src_dir / "parent_link"
        cycle_link.symlink_to(tmp_path)

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(src_dir)

        assert result.success is True
        assert not src_dir.exists()
        trashed_dir = trash_dir / "files" / "cyclic_dir"
        assert trashed_dir.is_dir()
        assert (trashed_dir / "file.txt").read_text() == "content"
        # The cycle symlink should also be moved
        trashed_link = trashed_dir / "parent_link"
        assert trashed_link.is_symlink()

    def test_self_referencing_symlink(self, tmp_path: Path) -> None:
        """Symlink pointing to itself."""
        trash_dir = tmp_path / "Trash"
        src_dir = tmp_path / "self_ref_dir"
        src_dir.mkdir()
        self_link = src_dir / "myself"
        self_link.symlink_to(self_link)

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(src_dir)

        assert result.success is True
        trashed_dir = trash_dir / "files" / "self_ref_dir"
        trashed_link = trashed_dir / "myself"
        assert trashed_link.is_symlink()


class TestAbsolutePathSymlink:
    """Absolute path symlinks."""

    def test_absolute_symlink_to_file(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        target = tmp_path / "target.txt"
        target.write_text("abs target", encoding="utf-8")
        link = tmp_path / "abs_link"
        link.symlink_to(target.resolve())  # absolute path

        manager = TrashManager(trash_dir)
        result = manager.trash_file(link)

        assert result.success is True
        trashed = trash_dir / "files" / "abs_link"
        assert trashed.is_symlink()
        # Verify it's still an absolute path
        link_target = os.readlink(trashed)
        assert os.path.isabs(link_target)
        assert Path(link_target) == target.resolve()

    def test_absolute_symlink_to_directory(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        target_dir = tmp_path / "abs_target_dir"
        target_dir.mkdir()
        (target_dir / "inside.txt").write_text("inside", encoding="utf-8")
        link = tmp_path / "abs_dir_link"
        link.symlink_to(target_dir.resolve())

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(link)

        assert result.success is True
        trashed = trash_dir / "files" / "abs_dir_link"
        link_target = os.readlink(trashed)
        assert os.path.isabs(link_target)


class TestRelativePathSymlink:
    """Relative path symlinks."""

    def test_relative_symlink_to_file(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        subdir = tmp_path / "subdir"
        subdir.mkdir()
        target = subdir / "target.txt"
        target.write_text("relative target", encoding="utf-8")
        link = tmp_path / "rel_link"
        link.symlink_to(Path("subdir") / "target.txt")  # relative path

        manager = TrashManager(trash_dir)
        result = manager.trash_file(link)

        assert result.success is True
        trashed = trash_dir / "files" / "rel_link"
        assert trashed.is_symlink()
        # The relative path should be preserved as-is
        link_target = os.readlink(trashed)
        assert not os.path.isabs(link_target)
        assert link_target == str(Path("subdir") / "target.txt")

    def test_relative_symlink_to_directory(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        target_dir = tmp_path / "rel_target"
        target_dir.mkdir()
        (target_dir / "file.txt").write_text("rel dir content", encoding="utf-8")
        link = tmp_path / "rel_dir_link"
        link.symlink_to(Path("rel_target"))  # relative path

        manager = TrashManager(trash_dir)
        result = manager.trash_directory(link)

        assert result.success is True
        trashed = trash_dir / "files" / "rel_dir_link"
        link_target = os.readlink(trashed)
        assert link_target == "rel_target"

    def test_relative_symlink_with_parent_reference(self, tmp_path: Path) -> None:
        """Symlink using ../ to reference parent directory."""
        trash_dir = tmp_path / "Trash"
        inner = tmp_path / "inner"
        inner.mkdir()
        target = tmp_path / "outer.txt"
        target.write_text("outer content", encoding="utf-8")
        link = inner / "parent_link"
        link.symlink_to(Path("..") / "outer.txt")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(link)

        assert result.success is True
        trashed = trash_dir / "files" / "parent_link"
        link_target = os.readlink(trashed)
        assert link_target == str(Path("..") / "outer.txt")


class TestSymlinkTargetPathUnchanged:
    """Verify symlink target path unchanged after move."""

    def test_target_path_preserved_after_move(self, tmp_path: Path) -> None:
        """The symlink target string should be exactly the same after trashing."""
        import os

        trash_dir = tmp_path / "Trash"
        target = tmp_path / "preserve_target.txt"
        target.write_text("content", encoding="utf-8")
        link = tmp_path / "preserve_link"
        link.symlink_to(target)
        original_target = os.readlink(link)

        manager = TrashManager(trash_dir)
        manager.trash_file(link)

        trashed = trash_dir / "files" / "preserve_link"
        moved_target = os.readlink(trashed)
        assert moved_target == original_target

    def test_complex_relative_path_preserved(self, tmp_path: Path) -> None:
        """Complex relative path like ../../other/file.txt preserved exactly."""
        import os

        trash_dir = tmp_path / "Trash"
        deep = tmp_path / "a" / "b" / "c"
        deep.mkdir(parents=True)
        link = deep / "complex_link"
        link.symlink_to(Path("..") / ".." / ".." / "other" / "file.txt")
        original_target = os.readlink(link)

        manager = TrashManager(trash_dir)
        manager.trash_file(link)

        trashed = trash_dir / "files" / "complex_link"
        moved_target = os.readlink(trashed)
        assert moved_target == original_target
        assert "../../../../other/file.txt" in moved_target or "../../../other/file.txt" in moved_target

    def test_symlink_target_unmodified_by_trash_operation(self, tmp_path: Path) -> None:
        """Moving symlink does not modify the target file in any way."""
        trash_dir = tmp_path / "Trash"
        target = tmp_path / "immutable.txt"
        target.write_text("original data", encoding="utf-8")
        original_mtime = target.stat().st_mtime
        link = tmp_path / "link_to_immutable"
        link.symlink_to(target)

        manager = TrashManager(trash_dir)
        manager.trash_file(link)

        # Target should be completely unchanged
        assert target.read_text() == "original data"
        assert target.stat().st_mtime == original_mtime


class TestTrashManagerLock:
    """TrashManager locking behavior."""

    def test_lock_file_path(self, tmp_path: Path) -> None:
        """Lock file should be at trash_dir/.lock."""
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)
        lock = manager._get_lock()
        assert lock.path == trash_dir / ".lock"

    def test_lock_timeout_initialization(self, tmp_path: Path) -> None:
        """TrashManager accepts lock_timeout parameter."""
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir, lock_timeout=5.0)
        assert manager._lock_timeout == 5.0

    def test_lock_timeout_none_default(self, tmp_path: Path) -> None:
        """Default lock_timeout is None (block indefinitely)."""
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)
        assert manager._lock_timeout is None

    def test_acquire_release_lock(self, tmp_path: Path) -> None:
        """Manual lock acquire and release."""
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)
        manager.acquire_lock()
        assert manager._lock is not None
        assert manager._lock.is_locked is True
        manager.release_lock()
        assert manager._lock.is_locked is False

    def test_with_lock_context_manager(self, tmp_path: Path) -> None:
        """_with_lock context manager acquires and releases."""
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)
        with manager._with_lock():
            assert manager._lock is not None
            assert manager._lock.is_locked is True
        assert manager._lock.is_locked is False

    def test_lock_prevents_concurrent_access(self, tmp_path: Path) -> None:
        """Lock prevents two managers from accessing same trash."""
        trash_dir = tmp_path / "Trash"

        manager1 = TrashManager(trash_dir, lock_timeout=0)
        manager1.acquire_lock()

        manager2 = TrashManager(trash_dir, lock_timeout=0)
        with pytest.raises(LockTimeout):
            manager2.acquire_lock()

        manager1.release_lock()

    def test_trash_operation_acquires_lock(self, tmp_path: Path) -> None:
        """Trash operations acquire and release the lock."""
        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src)

        assert result.success is True
        # After operation, lock should be released
        assert manager._lock is not None
        assert not manager._lock.is_locked

    def test_dry_run_does_not_acquire_lock(self, tmp_path: Path) -> None:
        """Dry run operations don't acquire the lock."""
        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        result = manager.trash_file(src, dry_run=True)

        assert result.success is True
        # Lock may not even be created for dry run
        # Note: current implementation doesn't use lock for dry run


class TestTrashManagerConcurrency:
    """Concurrency scenarios with TrashManager."""

    def test_concurrent_trash_same_name(self, tmp_path: Path) -> None:
        """Two threads trashing files with same name should get unique names."""
        trash_dir = tmp_path / "Trash"

        # Create two files with same name in different locations
        dir1 = tmp_path / "dir1"
        dir2 = tmp_path / "dir2"
        dir1.mkdir()
        dir2.mkdir()
        (dir1 / "file.txt").write_text("content1", encoding="utf-8")
        (dir2 / "file.txt").write_text("content2", encoding="utf-8")

        results = []

        def trash_file(work_dir: Path) -> TrashResult:
            manager = TrashManager(trash_dir, lock_timeout=10.0)
            src = work_dir / "file.txt"
            result = manager.trash_file(src)
            results.append(result)
            return result

        with ThreadPoolExecutor(max_workers=2) as executor:
            futures = [
                executor.submit(trash_file, dir1),
                executor.submit(trash_file, dir2),
            ]
            for f in as_completed(futures):
                assert f.result().success is True

        # Both should succeed with different destination names
        assert len(results) == 2
        destinations = [r.destination for r in results if r.destination]
        assert len(destinations) == 2
        # Names should be unique (either file.txt and file_1.txt)
        names = [d.name for d in destinations]
        assert len(set(names)) == 2  # Two unique names

    def test_concurrent_trash_operations_serialized(self, tmp_path: Path) -> None:
        """Lock ensures operations are serialized."""
        trash_dir = tmp_path / "Trash"

        operations = []

        def trash_with_timing(thread_id: int) -> int:
            src = tmp_path / f"file{thread_id}.txt"
            src.write_text(f"content{thread_id}", encoding="utf-8")
            manager = TrashManager(trash_dir, lock_timeout=10.0)

            # Use _with_lock which ensures directory exists
            with manager._with_lock():
                start = time.monotonic()
                operations.append(("start", thread_id, start))
                time.sleep(0.1)  # Simulate work

            manager.trash_file(src)
            end = time.monotonic()
            operations.append(("end", thread_id, end))
            return thread_id

        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = [executor.submit(trash_with_timing, i) for i in range(3)]
            for f in as_completed(futures):
                f.result()

        # Operations should be serialized
        starts = [(op[1], op[2]) for op in operations if op[0] == "start"]
        ends = [(op[1], op[2]) for op in operations if op[0] == "end"]
        starts.sort(key=lambda x: x[1])
        ends.sort(key=lambda x: x[1])

        # Each end should come before next start (serialized) - allow larger tolerance for CI
        for i in range(min(len(ends) - 1, len(starts) - 1)):
            assert ends[i][1] <= starts[i + 1][1] + 0.5  # Increased tolerance for CI variability

    def test_concurrent_trash_different_files(self, tmp_path: Path) -> None:
        """Multiple files trashed concurrently should all succeed."""
        trash_dir = tmp_path / "Trash"

        # Create multiple source files
        for i in range(10):
            (tmp_path / f"file{i}.txt").write_text(f"content{i}", encoding="utf-8")

        def trash_file(index: int) -> bool:
            manager = TrashManager(trash_dir, lock_timeout=30.0)
            src = tmp_path / f"file{index}.txt"
            result = manager.trash_file(src)
            return result.success

        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(trash_file, i) for i in range(10)]
            successes = [f.result() for f in as_completed(futures)]

        assert all(successes)

        # All 10 files should be in trash
        files_dir = trash_dir / "files"
        trashed_files = list(files_dir.glob("file*.txt"))
        assert len(trashed_files) == 10

    def test_concurrent_directory_trash(self, tmp_path: Path) -> None:
        """Concurrent directory trash operations."""
        trash_dir = tmp_path / "Trash"

        for i in range(5):
            dir_path = tmp_path / f"dir{i}"
            dir_path.mkdir()
            (dir_path / "file.txt").write_text(f"content{i}", encoding="utf-8")

        def trash_directory(index: int) -> bool:
            manager = TrashManager(trash_dir, lock_timeout=30.0)
            src = tmp_path / f"dir{index}"
            result = manager.trash_directory(src)
            return result.success

        with ThreadPoolExecutor(max_workers=3) as executor:
            futures = [executor.submit(trash_directory, i) for i in range(5)]
            successes = [f.result() for f in as_completed(futures)]

        assert all(successes)

        # All 5 directories should be in trash
        files_dir = trash_dir / "files"
        trashed_dirs = [p for p in files_dir.iterdir() if p.is_dir()]
        assert len(trashed_dirs) == 5

    def test_lock_timeout_on_busy_trash(self, tmp_path: Path) -> None:
        """LockTimeout when trash dir is busy and timeout is short."""
        trash_dir = tmp_path / "Trash"

        manager1 = TrashManager(trash_dir, lock_timeout=None)
        manager1.acquire_lock()  # Hold lock indefinitely

        # Create file to trash
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        manager2 = TrashManager(trash_dir, lock_timeout=0.5)
        result = manager2.trash_file(src)

        # Should fail due to lock timeout
        assert result.success is False
        assert "Could not acquire lock" in result.message

        manager1.release_lock()


class TestTrashManagerLockRecovery:
    """Lock recovery and cleanup scenarios."""

    def test_lock_released_on_success(self, tmp_path: Path) -> None:
        """Lock is always released after successful operation."""
        trash_dir = tmp_path / "Trash"
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        manager.trash_file(src)

        # Lock should be released
        lock = manager._get_lock()
        assert not lock.is_locked

        # Another manager should be able to acquire
        manager2 = TrashManager(trash_dir, lock_timeout=1.0)
        manager2.acquire_lock()
        manager2.release_lock()

    def test_lock_released_on_failure(self, tmp_path: Path) -> None:
        """Lock is released even when operation fails."""
        trash_dir = tmp_path / "Trash"

        # Try to trash non-existent file
        manager = TrashManager(trash_dir)
        result = manager.trash_file(tmp_path / "nonexistent.txt")

        assert result.success is False
        # Lock should still be released (or never acquired for non-existent check)
        # Note: current implementation checks existence before acquiring lock

    def test_lock_file_created_on_first_use(self, tmp_path: Path) -> None:
        """Lock file is created when first operation needs it."""
        trash_dir = tmp_path / "Trash"
        lock_path = trash_dir / ".lock"

        assert not lock_path.exists()

        manager = TrashManager(trash_dir)
        manager.acquire_lock()

        assert lock_path.exists()

        manager.release_lock()
        # Lock file persists (standard flock behavior)


class TestErrorRecoveryTrashinfoWriteFailure:
    """When trashinfo write fails, the file should NOT be moved."""

    @pytest.mark.skip(reason="Linux and macOS both allow owner to access chmod 000 directories")
    def test_trashinfo_write_failure_no_move(self, tmp_path: Path) -> None:
        """If trashinfo cannot be written, the source file should remain untouched."""
        trash_dir = tmp_path / "Trash"
        # Make info directory unwritable BEFORE trashing
        (trash_dir / "info").mkdir(parents=True)
        os.chmod(trash_dir / "info", 0o000)

        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        try:
            manager = TrashManager(trash_dir)
            result = manager.trash_file(src)

            # Operation should fail
            assert result.success is False
            assert "Failed to write trashinfo" in result.message
            # Source file should still exist
            assert src.exists()
            assert src.read_text() == "content"
            # No file should be in trash
            assert not (trash_dir / "files" / "file.txt").exists()
        finally:
            os.chmod(trash_dir / "info", 0o755)

    @pytest.mark.skip(reason="Linux and macOS both allow owner to access chmod 000 directories")
    def test_trashinfo_write_failure_preserves_directory(self, tmp_path: Path) -> None:
        """If trashinfo cannot be written, the source directory should remain untouched."""
        trash_dir = tmp_path / "Trash"
        (trash_dir / "info").mkdir(parents=True)
        os.chmod(trash_dir / "info", 0o000)

        src_dir = tmp_path / "mydir"
        src_dir.mkdir()
        (src_dir / "file.txt").write_text("inside", encoding="utf-8")

        try:
            manager = TrashManager(trash_dir)
            result = manager.trash_directory(src_dir)

            assert result.success is False
            assert "Failed to write trashinfo" in result.message
            assert src_dir.exists()
            assert (src_dir / "file.txt").read_text() == "inside"
        finally:
            os.chmod(trash_dir / "info", 0o755)


class TestErrorRecoveryMoveFailureCleanup:
    """When move fails after trashinfo was written, orphaned trashinfo should be cleaned."""

    @pytest.mark.skip(reason="Linux and macOS both allow owner to access chmod 000 directories")
    def test_move_failure_cleans_orphan_trashinfo(self, tmp_path: Path) -> None:
        """If move fails, the already-written trashinfo should be deleted."""
        trash_dir = tmp_path / "Trash"
        # Make files directory unwritable so move fails
        (trash_dir / "files").mkdir(parents=True)
        os.chmod(trash_dir / "files", 0o000)

        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        try:
            manager = TrashManager(trash_dir)
            result = manager.trash_file(src)

            # Operation should fail
            assert result.success is False
            # The orphan trashinfo should have been cleaned up
            # (info dir was created and writable, so trashinfo was written before move attempt)
            assert not (trash_dir / "info" / "file.txt.trashinfo").exists()
        finally:
            os.chmod(trash_dir / "files", 0o755)

    @pytest.mark.skip(reason="Linux and macOS both allow owner to access chmod 000 directories")
    def test_move_failure_partial_cleanup(self, tmp_path: Path) -> None:
        """Cleanup of orphan trashinfo is best-effort; failure shouldn't mask original error."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")

        # Make files unwritable so move fails
        os.chmod(files_dir, 0o000)

        try:
            manager = TrashManager(trash_dir)
            result = manager.trash_file(src)

            assert result.success is False
            assert "Failed to trash" in result.message
        finally:
            os.chmod(files_dir, 0o755)


class TestVerifyTrashConsistency:
    """verify_trash_consistency() - detect orphaned files and info files."""

    def test_empty_trash_is_consistent(self, tmp_path: Path) -> None:
        """Empty trash directory is considered consistent."""
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)
        report = manager.verify_trash_consistency()

        assert report.consistent is True
        assert report.orphan_files == []
        assert report.orphan_infos == []
        assert report.errors == []

    def test_consistent_trash(self, tmp_path: Path) -> None:
        """Trash with matching files and trashinfo is consistent."""
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)

        # Trash a file properly
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")
        result = manager.trash_file(src)
        assert result.success is True

        report = manager.verify_trash_consistency()
        assert report.consistent is True
        assert report.orphan_files == []
        assert report.orphan_infos == []

    def test_orphan_file_without_trashinfo(self, tmp_path: Path) -> None:
        """File in files/ without corresponding .trashinfo is detected."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create orphan file (no corresponding trashinfo)
        orphan = files_dir / "orphan.txt"
        orphan.write_text("orphan content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        report = manager.verify_trash_consistency()

        assert report.consistent is False
        assert len(report.orphan_files) == 1
        assert report.orphan_files[0] == orphan
        assert len(report.missing_infos) == 1

    def test_orphan_trashinfo_without_file(self, tmp_path: Path) -> None:
        """Trashinfo file without corresponding file is detected."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create orphan trashinfo (no corresponding file)
        orphan_info = info_dir / "missing.trashinfo"
        orphan_info.write_text(
            "[Trash Info]\nPath=/tmp/missing.txt\nDeletionDate=2024-01-01T00:00:00\n",
            encoding="utf-8"
        )

        manager = TrashManager(trash_dir)
        report = manager.verify_trash_consistency()

        assert report.consistent is False
        assert len(report.orphan_infos) == 1
        assert report.orphan_infos[0] == orphan_info

    def test_multiple_orphans(self, tmp_path: Path) -> None:
        """Multiple orphan files and info files are all detected."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create multiple orphan files
        (files_dir / "orphan1.txt").write_text("1", encoding="utf-8")
        (files_dir / "orphan2.txt").write_text("2", encoding="utf-8")

        # Create multiple orphan trashinfo
        (info_dir / "missing1.trashinfo").write_text("[Trash Info]\n", encoding="utf-8")
        (info_dir / "missing2.trashinfo").write_text("[Trash Info]\n", encoding="utf-8")

        manager = TrashManager(trash_dir)
        report = manager.verify_trash_consistency()

        assert report.consistent is False
        assert len(report.orphan_files) == 2
        assert len(report.orphan_infos) == 2

    def test_macos_style_always_consistent(self, tmp_path: Path, monkeypatch) -> None:
        """macOS .Trash style (no info files) is always considered consistent."""
        monkeypatch.setattr(sys, "platform", "darwin")
        trash_dir = tmp_path / ".Trash"
        files_dir = trash_dir
        files_dir.mkdir(parents=True)

        # Create some files
        (files_dir / "file1.txt").write_text("1", encoding="utf-8")
        (files_dir / "file2.txt").write_text("2", encoding="utf-8")

        manager = TrashManager(trash_dir)
        report = manager.verify_trash_consistency()

        assert report.consistent is True
        assert report.orphan_files == []


class TestCleanupOrphans:
    """cleanup_orphans() - find and optionally delete orphaned entries."""

    def test_find_orphan_file(self, tmp_path: Path) -> None:
        """cleanup_orphans finds orphan files without deleting by default."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        orphan = files_dir / "orphan.txt"
        orphan.write_text("orphan", encoding="utf-8")

        manager = TrashManager(trash_dir)
        results = manager.cleanup_orphans()

        assert len(results) == 1
        assert results[0].path == orphan
        assert results[0].orphan_type == "file"
        # File should still exist (not deleted by default)
        assert orphan.exists()

    def test_delete_orphan_files(self, tmp_path: Path) -> None:
        """cleanup_orphans with delete_orphan_files=True removes orphan files."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        orphan = files_dir / "orphan.txt"
        orphan.write_text("orphan", encoding="utf-8")

        manager = TrashManager(trash_dir)
        results = manager.cleanup_orphans(delete_orphan_files=True)

        assert len(results) == 1
        assert results[0].orphan_type == "file"
        # File should be deleted
        assert not orphan.exists()

    def test_delete_orphan_directory(self, tmp_path: Path) -> None:
        """cleanup_orphans can delete orphan directories."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        orphan_dir = files_dir / "orphan_dir"
        orphan_dir.mkdir()
        (orphan_dir / "file.txt").write_text("inside", encoding="utf-8")

        manager = TrashManager(trash_dir)
        results = manager.cleanup_orphans(delete_orphan_files=True)

        assert len(results) == 1
        assert results[0].orphan_type == "file"
        assert not orphan_dir.exists()

    def test_find_orphan_trashinfo(self, tmp_path: Path) -> None:
        """cleanup_orphans finds orphan .trashinfo files."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        orphan_info = info_dir / "missing.trashinfo"
        orphan_info.write_text("[Trash Info]\n", encoding="utf-8")

        manager = TrashManager(trash_dir)
        results = manager.cleanup_orphans()

        assert len(results) == 1
        assert results[0].path == orphan_info
        assert results[0].orphan_type == "info"
        assert orphan_info.exists()

    def test_delete_orphan_infos(self, tmp_path: Path) -> None:
        """cleanup_orphans with delete_orphan_infos=True removes orphan trashinfo."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        orphan_info = info_dir / "missing.trashinfo"
        orphan_info.write_text("[Trash Info]\n", encoding="utf-8")

        manager = TrashManager(trash_dir)
        results = manager.cleanup_orphans(delete_orphan_infos=True)

        assert len(results) == 1
        assert results[0].orphan_type == "info"
        assert not orphan_info.exists()

    def test_delete_both_types(self, tmp_path: Path) -> None:
        """cleanup_orphans can delete both orphan files and infos."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        orphan_file = files_dir / "orphan.txt"
        orphan_file.write_text("orphan", encoding="utf-8")
        orphan_info = info_dir / "missing.trashinfo"
        orphan_info.write_text("[Trash Info]\n", encoding="utf-8")

        manager = TrashManager(trash_dir)
        results = manager.cleanup_orphans(delete_orphan_files=True, delete_orphan_infos=True)

        assert len(results) == 2
        assert not orphan_file.exists()
        assert not orphan_info.exists()

    def test_non_trashinfo_file_in_info_dir(self, tmp_path: Path) -> None:
        """Non-trashinfo files in info directory are detected as orphans."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Random file in info dir (not .trashinfo extension)
        random_file = info_dir / "random.txt"
        random_file.write_text("random", encoding="utf-8")

        manager = TrashManager(trash_dir)
        results = manager.cleanup_orphans()

        # Should find the non-trashinfo file
        found = [r for r in results if r.path == random_file]
        assert len(found) == 1
        assert found[0].orphan_type == "info"

    def test_macos_style_no_orphans(self, tmp_path: Path, monkeypatch) -> None:
        """macOS .Trash style doesn't have orphan detection (no info files)."""
        monkeypatch.setattr(sys, "platform", "darwin")
        trash_dir = tmp_path / ".Trash"
        trash_dir.mkdir()

        (trash_dir / "file.txt").write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        results = manager.cleanup_orphans()

        assert results == []

    def test_empty_trash_no_orphans(self, tmp_path: Path) -> None:
        """Empty trash directory has no orphans."""
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)
        results = manager.cleanup_orphans()

        assert results == []


class TestIterTrashEntries:
    """iter_trash_entries() - iterate over valid trash entries."""

    def test_iterate_consistent_entries(self, tmp_path: Path) -> None:
        """Iterate over entries that have both file and trashinfo."""
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)

        # Trash a file
        src = tmp_path / "file.txt"
        src.write_text("content", encoding="utf-8")
        manager.trash_file(src)

        entries = list(manager.iter_trash_entries())
        assert len(entries) == 1
        file_path, info_path = entries[0]
        assert file_path.name == "file.txt"
        assert info_path is not None
        assert info_path.name == "file.txt.trashinfo"

    def test_iterate_skips_orphans(self, tmp_path: Path) -> None:
        """iter_trash_entries only returns entries with both file and info."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create a proper entry
        proper_file = files_dir / "proper.txt"
        proper_file.write_text("proper", encoding="utf-8")
        proper_info = info_dir / "proper.txt.trashinfo"
        proper_info.write_text("[Trash Info]\n", encoding="utf-8")

        # Create an orphan file (no info)
        (files_dir / "orphan.txt").write_text("orphan", encoding="utf-8")

        manager = TrashManager(trash_dir)
        entries = list(manager.iter_trash_entries())

        assert len(entries) == 1
        assert entries[0][0].name == "proper.txt"

    def test_iterate_empty_trash(self, tmp_path: Path) -> None:
        """Empty trash returns no entries."""
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)
        entries = list(manager.iter_trash_entries())
        assert entries == []

    def test_iterate_macos_style(self, tmp_path: Path, monkeypatch) -> None:
        """macOS .Trash style returns all files with None info_path."""
        monkeypatch.setattr(sys, "platform", "darwin")
        trash_dir = tmp_path / ".Trash"
        trash_dir.mkdir()

        (trash_dir / "file1.txt").write_text("1", encoding="utf-8")
        (trash_dir / "file2.txt").write_text("2", encoding="utf-8")

        manager = TrashManager(trash_dir)
        entries = list(manager.iter_trash_entries())

        assert len(entries) == 2
        for file_path, info_path in entries:
            assert info_path is None
            assert file_path.parent == trash_dir