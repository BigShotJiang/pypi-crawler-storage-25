"""Tests for IconManager - comprehensive icon rendering tests."""

from __future__ import annotations

import pytest

from rmsafe.output.icons import Icon, IconManager


class TestIconEnum:
    """Test Icon enum values."""

    def test_status_icons_are_unicode(self) -> None:
        """Status icons should be unicode characters that work everywhere."""
        assert Icon.SUCCESS.value == "✓"
        assert Icon.ERROR.value == "✗"
        assert Icon.WARNING.value == "⚠"
        assert Icon.INFO.value == "ℹ"

    def test_file_icons_are_emoji(self) -> None:
        """File operation icons should be emoji by default."""
        assert Icon.TRASH.value == "🗑️"
        assert Icon.FILE.value == "📄"
        assert Icon.FOLDER.value == "📁"
        assert Icon.RESTORE.value == "↩️"

    def test_alt_icons_exist(self) -> None:
        """Alternative unicode icons should exist for terminals without emoji."""
        assert Icon.TRASH_ALT.value == "🗑"
        assert Icon.FILE_ALT.value == "☐"
        assert Icon.FOLDER_ALT.value == "☐"
        assert Icon.RESTORE_ALT.value == "←"


class TestIconManagerBasic:
    """Test IconManager basic functionality."""

    def test_default_settings(self) -> None:
        """Default settings: icons enabled, emoji enabled."""
        manager = IconManager()
        assert manager.use_icons is True
        assert manager.use_emoji is True

    def test_icons_disabled(self) -> None:
        """When icons disabled, all icon() calls return empty string."""
        manager = IconManager(use_icons=False)
        assert manager.icon(Icon.SUCCESS) == ""
        assert manager.icon(Icon.TRASH) == ""
        assert manager.icon(Icon.FILE) == ""

    def test_emoji_disabled_uses_alt(self) -> None:
        """When emoji disabled, file icons use unicode alternatives."""
        manager = IconManager(use_icons=True, use_emoji=False)
        # Status icons still use unicode (they're not emoji)
        assert manager.icon(Icon.SUCCESS) == "✓"
        assert manager.icon(Icon.ERROR) == "✗"
        # File icons use alternatives
        assert manager.icon(Icon.TRASH) == Icon.TRASH_ALT.value
        assert manager.icon(Icon.FILE) == Icon.FILE_ALT.value

    def test_icons_disabled_overrides_emoji(self) -> None:
        """Even with emoji enabled, icons disabled returns empty."""
        manager = IconManager(use_icons=False, use_emoji=True)
        assert manager.icon(Icon.TRASH) == ""
        assert manager.icon(Icon.SUCCESS) == ""


class TestIconManagerMethods:
    """Test IconManager convenience methods."""

    def test_success_method(self) -> None:
        """success() returns icon with trailing space."""
        manager = IconManager()
        assert manager.success() == "✓ "

    def test_success_method_disabled(self) -> None:
        """success() returns empty when icons disabled."""
        manager = IconManager(use_icons=False)
        assert manager.success() == ""

    def test_error_method(self) -> None:
        """error() returns icon with trailing space."""
        manager = IconManager()
        assert manager.error() == "✗ "

    def test_warning_method(self) -> None:
        """warning() returns icon with trailing space."""
        manager = IconManager()
        assert manager.warning() == "⚠ "

    def test_info_method(self) -> None:
        """info() returns icon with trailing space."""
        manager = IconManager()
        assert manager.info() == "ℹ "

    def test_trash_method(self) -> None:
        """trash() returns emoji icon with trailing space."""
        manager = IconManager(use_emoji=True)
        assert manager.trash() == "🗑️ "

    def test_trash_method_no_emoji(self) -> None:
        """trash() returns unicode alt when emoji disabled."""
        manager = IconManager(use_emoji=False)
        assert manager.trash() == "🗑 "

    def test_file_method(self) -> None:
        """file() returns emoji icon with trailing space."""
        manager = IconManager(use_emoji=True)
        assert manager.file() == "📄 "

    def test_folder_method(self) -> None:
        """folder() returns emoji icon with trailing space."""
        manager = IconManager(use_emoji=True)
        assert manager.folder() == "📁 "

    def test_restore_method(self) -> None:
        """restore() returns emoji icon with trailing space."""
        manager = IconManager(use_emoji=True)
        assert manager.restore() == "↩️ "


class TestIconManagerIntegration:
    """Test IconManager integration with output scenarios."""

    def test_success_message_format(self) -> None:
        """Success message format with icon."""
        manager = IconManager()
        message = f"{manager.success()}File trashed"
        assert message == "✓ File trashed"

    def test_success_message_no_icons(self) -> None:
        """Success message without icons."""
        manager = IconManager(use_icons=False)
        message = f"{manager.success()}File trashed"
        assert message == "File trashed"

    def test_error_message_format(self) -> None:
        """Error message format with icon."""
        manager = IconManager()
        message = f"{manager.error()}Permission denied"
        assert message == "✗ Permission denied"

    def test_file_list_format(self) -> None:
        """File list format with icons."""
        manager = IconManager()
        line = f"{manager.file()}report.pdf  2.3 MB"
        assert line == "📄 report.pdf  2.3 MB"

    def test_folder_list_format(self) -> None:
        """Folder list format with icons."""
        manager = IconManager()
        line = f"{manager.folder()}project/  500 MB"
        assert line == "📁 project/  500 MB"

    def test_mixed_icon_format(self) -> None:
        """Mixed icon usage in single output."""
        manager = IconManager()
        output = f"{manager.trash()}Trash Contents\n{manager.file()}file.txt"
        assert output == "🗑️ Trash Contents\n📄 file.txt"


class TestIconManagerEdgeCases:
    """Test edge cases and boundary conditions."""

    def test_empty_string_handling(self) -> None:
        """Empty icon should not break formatting."""
        manager = IconManager(use_icons=False)
        result = manager.icon(Icon.SUCCESS)
        assert result == ""
        assert len(result) == 0

    def test_multiple_icons_in_sequence(self) -> None:
        """Multiple icons in sequence should work correctly."""
        manager = IconManager()
        icons = [manager.success(), manager.file(), manager.trash()]
        assert all(len(i) > 0 for i in icons)

    def test_icon_enum_all_members(self) -> None:
        """All Icon enum members should be renderable."""
        manager = IconManager()
        for icon in Icon:
            result = manager.icon(icon)
            # Should always return a string (empty or icon)
            assert isinstance(result, str)

    def test_icon_spacing_consistency(self) -> None:
        """All convenience methods should have consistent trailing space."""
        manager = IconManager()
        methods = [
            manager.success,
            manager.error,
            manager.warning,
            manager.info,
            manager.trash,
            manager.file,
            manager.folder,
            manager.restore,
        ]
        for method in methods:
            result = method()
            if manager.use_icons:
                # All should end with space when icons enabled
                assert result.endswith(" ") or result == ""
            else:
                # All should be empty when icons disabled
                assert result == ""

    def test_unicode_vs_emoji_width(self) -> None:
        """Unicode alternatives should be single-width characters."""
        manager = IconManager(use_emoji=False)
        # Unicode alternatives should work in narrow terminals
        trash = manager.icon(Icon.TRASH)
        assert trash == Icon.TRASH_ALT.value


class TestIconManagerConfigurationIntegration:
    """Test IconManager integration with config settings."""

    def test_from_config_icons_true(self) -> None:
        """Create manager from config with icons=True."""
        from rmsafe.config.schema import OutputConfig

        config = OutputConfig(icons=True)
        manager = IconManager(use_icons=config.icons)
        assert manager.use_icons is True
        assert manager.success() == "✓ "

    def test_from_config_icons_false(self) -> None:
        """Create manager from config with icons=False."""
        from rmsafe.config.schema import OutputConfig

        config = OutputConfig(icons=False)
        manager = IconManager(use_icons=config.icons)
        assert manager.use_icons is False
        assert manager.success() == ""

    def test_manager_respects_config_object(self) -> None:
        """Manager should respect config object values."""
        from rmsafe.config.schema import OutputConfig

        for icons_value in [True, False]:
            config = OutputConfig(icons=icons_value)
            manager = IconManager(use_icons=config.icons)
            result = manager.icon(Icon.SUCCESS)
            if icons_value:
                assert result == "✓"
            else:
                assert result == ""