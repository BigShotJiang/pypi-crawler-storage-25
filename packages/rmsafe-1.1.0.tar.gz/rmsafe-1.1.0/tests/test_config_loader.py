"""Comprehensive tests for config/loader.py following SQLite test philosophy."""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from rmsafe.config.loader import (
    get_default_trash_path,
    load_config,
    _default_config_data,
    _load_config_file,
    _load_env_overrides,
    _normalize_cli_overrides,
    _deep_merge,
)


class TestGetDefaultTrashPath:
    """get_default_trash_path() - every platform."""

    def test_macos(self, monkeypatch) -> None:
        import platform
        monkeypatch.setattr(platform, "system", lambda: "Darwin")
        result = get_default_trash_path()
        assert result.name == ".Trash"

    def test_linux(self, monkeypatch) -> None:
        import platform
        monkeypatch.setattr(platform, "system", lambda: "Linux")
        result = get_default_trash_path()
        assert result.name == "Trash"
        assert "share" in str(result)

    def test_other_platform(self, monkeypatch) -> None:
        import platform
        monkeypatch.setattr(platform, "system", lambda: "Windows")
        result = get_default_trash_path()
        # Falls back to Linux-style path
        assert result.name == "Trash"

    def test_case_insensitive_darwin(self, monkeypatch) -> None:
        import platform
        monkeypatch.setattr(platform, "system", lambda: "darwin")
        result = get_default_trash_path()
        assert result.name == ".Trash"


class TestDefaultConfigData:
    """_default_config_data() - structure verification."""

    def test_returns_dict(self) -> None:
        result = _default_config_data()
        assert isinstance(result, dict)

    def test_has_all_sections(self) -> None:
        result = _default_config_data()
        assert "trash" in result
        assert "behavior" in result
        assert "output" in result
        assert "btrfs" in result

    def test_trash_defaults(self) -> None:
        result = _default_config_data()
        assert result["trash"]["max_size"] == "500MB"
        assert result["trash"]["location"] is None
        assert result["trash"]["auto_clean_days"] == 30

    def test_behavior_defaults(self) -> None:
        result = _default_config_data()
        assert result["behavior"]["confirm_large_files"] == "10MB"
        assert result["behavior"]["confirm_directories"] is True
        assert result["behavior"]["undo_history_limit"] == 100

    def test_output_defaults(self) -> None:
        result = _default_config_data()
        assert result["output"]["color"] == "auto"
        assert result["output"]["verbose"] is True
        assert result["output"]["icons"] is True
        assert result["output"]["table_format"] == "rounded"

    def test_btrfs_defaults(self) -> None:
        result = _default_config_data()
        assert result["btrfs"]["enable_clone"] is True
        assert result["btrfs"]["fallback_on_error"] is True


class TestLoadConfigFile:
    """_load_config_file() - every file state, every error."""

    def test_missing_file_returns_empty(self, tmp_path: Path) -> None:
        result = _load_config_file(tmp_path / "nonexistent.jsonc")
        assert result == {}

    def test_valid_json(self, tmp_path: Path) -> None:
        file = tmp_path / "config.json"
        file.write_text('{"trash": {"max_size": "1GB"}}', encoding="utf-8")
        result = _load_config_file(file)
        assert result == {"trash": {"max_size": "1GB"}}

    def test_valid_jsonc_with_comments(self, tmp_path: Path) -> None:
        file = tmp_path / "config.jsonc"
        file.write_text('{"trash": {"max_size": "1GB"} /* comment */}', encoding="utf-8")
        result = _load_config_file(file)
        assert result == {"trash": {"max_size": "1GB"}}

    def test_jsonc_trailing_comma(self, tmp_path: Path) -> None:
        file = tmp_path / "config.jsonc"
        file.write_text('{"trash": {"max_size": "1GB",}}', encoding="utf-8")
        result = _load_config_file(file)
        assert result == {"trash": {"max_size": "1GB"}}

    def test_empty_file(self, tmp_path: Path) -> None:
        file = tmp_path / "empty.jsonc"
        file.write_text("", encoding="utf-8")
        # Empty JSON is invalid, but returns {}
        result = _load_config_file(file)
        assert result == {}

    def test_invalid_json(self, tmp_path: Path) -> None:
        file = tmp_path / "invalid.json"
        file.write_text("not valid json", encoding="utf-8")
        with pytest.raises(ValueError, match="Invalid config file"):
            _load_config_file(file)

    def test_json_array(self, tmp_path: Path) -> None:
        file = tmp_path / "array.json"
        file.write_text("[1, 2, 3]", encoding="utf-8")
        result = _load_config_file(file)
        assert result == {}  # Non-dict returns empty

    def test_json_string(self, tmp_path: Path) -> None:
        file = tmp_path / "string.json"
        file.write_text('"hello"', encoding="utf-8")
        result = _load_config_file(file)
        assert result == {}  # Non-dict returns empty

    def test_json_null(self, tmp_path: Path) -> None:
        file = tmp_path / "null.json"
        file.write_text("null", encoding="utf-8")
        result = _load_config_file(file)
        assert result == {}

    def test_permission_denied(self, tmp_path: Path) -> None:
        file = tmp_path / "secret.jsonc"
        file.write_text('{"trash": {"max_size": "1GB"}}', encoding="utf-8")
        os.chmod(file, 0o000)
        try:
            result = _load_config_file(file)
            assert result == {}  # OSError returns empty
        finally:
            os.chmod(file, 0o644)


class TestLoadEnvOverrides:
    """_load_env_overrides() - every env state."""

    def test_unset_returns_empty(self, monkeypatch) -> None:
        monkeypatch.delenv("RMSAFE_TRASH_DIR", raising=False)
        result = _load_env_overrides()
        assert result == {}

    def test_set_returns_location(self, monkeypatch) -> None:
        monkeypatch.setenv("RMSAFE_TRASH_DIR", "/custom/trash")
        result = _load_env_overrides()
        assert result == {"trash": {"location": "/custom/trash"}}

    def test_empty_string_returns_empty(self, monkeypatch) -> None:
        monkeypatch.setenv("RMSAFE_TRASH_DIR", "")
        result = _load_env_overrides()
        assert result == {}

    def test_path_with_spaces(self, monkeypatch) -> None:
        monkeypatch.setenv("RMSAFE_TRASH_DIR", "/path/with spaces/trash")
        result = _load_env_overrides()
        assert result == {"trash": {"location": "/path/with spaces/trash"}}


class TestNormalizeCliOverrides:
    """_normalize_cli_overrides() - every override type."""

    def test_empty_returns_empty(self) -> None:
        result = _normalize_cli_overrides({})
        assert result == {}

    def test_none_returns_empty(self) -> None:
        result = _normalize_cli_overrides(None)
        assert result == {}

    def test_trash_dir(self) -> None:
        result = _normalize_cli_overrides({"trash_dir": "/custom/trash"})
        assert result == {"trash": {"location": "/custom/trash"}}

    def test_trash_location(self) -> None:
        result = _normalize_cli_overrides({"trash_location": "/custom/trash"})
        assert result == {"trash": {"location": "/custom/trash"}}

    def test_both_trash_keys(self) -> None:
        result = _normalize_cli_overrides({"trash_dir": "/a", "trash_location": "/b"})
        # Last one wins based on order in function
        assert result["trash"]["location"] == "/b"

    def test_output_override(self) -> None:
        result = _normalize_cli_overrides({"output": {"color": "never"}})
        assert result == {"output": {"color": "never"}}

    def test_behavior_override(self) -> None:
        result = _normalize_cli_overrides({"behavior": {"confirm_large_files": "5MB"}})
        assert result == {"behavior": {"confirm_large_files": "5MB"}}

    def test_nested_with_trash_dir(self) -> None:
        result = _normalize_cli_overrides({
            "trash_dir": "/custom",
            "output": {"color": "never"}
        })
        assert result["trash"]["location"] == "/custom"
        assert result["output"]["color"] == "never"

    def test_nested_trash_section(self) -> None:
        result = _normalize_cli_overrides({
            "trash": {"max_size": "1GB"}
        })
        assert result == {"trash": {"max_size": "1GB"}}


class TestDeepMerge:
    """_deep_merge() - every merge scenario."""

    def test_flat_override(self) -> None:
        base = {"a": 1, "b": 2}
        _deep_merge(base, {"c": 3})
        assert base == {"a": 1, "b": 2, "c": 3}

    def test_flat_overwrite(self) -> None:
        base = {"a": 1}
        _deep_merge(base, {"a": 2})
        assert base == {"a": 2}

    def test_nested_merge(self) -> None:
        base = {"trash": {"max_size": "500MB"}}
        _deep_merge(base, {"trash": {"auto_clean_days": 7}})
        assert base["trash"]["max_size"] == "500MB"
        assert base["trash"]["auto_clean_days"] == 7

    def test_nested_overwrite(self) -> None:
        base = {"trash": {"max_size": "500MB"}}
        _deep_merge(base, {"trash": {"max_size": "1GB"}})
        assert base["trash"]["max_size"] == "1GB"

    def test_nested_to_flat(self) -> None:
        base = {"trash": "flat"}
        _deep_merge(base, {"trash": {"nested": True}})
        assert base["trash"] == {"nested": True}

    def test_flat_to_nested_preserves_nested(self) -> None:
        base = {"trash": {"nested": True}}
        _deep_merge(base, {"trash": "flat"})
        assert base["trash"] == "flat"

    def test_empty_override(self) -> None:
        base = {"a": 1}
        _deep_merge(base, {})
        assert base == {"a": 1}

    def test_empty_base(self) -> None:
        base = {}
        _deep_merge(base, {"a": 1})
        assert base == {"a": 1}

    def test_deep_nested(self) -> None:
        base = {"a": {"b": {"c": 1}}}
        _deep_merge(base, {"a": {"b": {"d": 2}}})
        assert base["a"]["b"]["c"] == 1
        assert base["a"]["b"]["d"] == 2

    def test_none_value(self) -> None:
        base = {"a": 1}
        _deep_merge(base, {"a": None})
        assert base["a"] is None


class TestLoadConfigIntegration:
    """load_config() - priority chain: CLI > env > file > defaults."""

    def test_defaults_only(self, monkeypatch) -> None:
        monkeypatch.delenv("RMSAFE_TRASH_DIR", raising=False)
        # Use a nonexistent config file
        config = load_config(config_file=Path("/nonexistent/config.jsonc"))
        assert config.trash.max_size == "500MB"
        assert config.trash.location is not None  # Default platform location

    def test_file_override(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.delenv("RMSAFE_TRASH_DIR", raising=False)
        config_file = tmp_path / "config.jsonc"
        config_file.write_text('{"trash": {"max_size": "1GB"}}', encoding="utf-8")
        config = load_config(config_file=config_file)
        assert config.trash.max_size == "1GB"

    def test_env_override_file(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setenv("RMSAFE_TRASH_DIR", "/env/trash")
        config_file = tmp_path / "config.jsonc"
        config_file.write_text('{"trash": {"location": "/file/trash"}}', encoding="utf-8")
        config = load_config(config_file=config_file)
        assert str(config.trash.location) == "/env/trash"

    def test_cli_override_env(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setenv("RMSAFE_TRASH_DIR", "/env/trash")
        config_file = tmp_path / "config.jsonc"
        config_file.write_text("", encoding="utf-8")
        config = load_config(
            cli_overrides={"trash_dir": "/cli/trash"},
            config_file=config_file
        )
        assert str(config.trash.location) == "/cli/trash"

    def test_cli_output_override(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.delenv("RMSAFE_TRASH_DIR", raising=False)
        config_file = tmp_path / "config.jsonc"
        config_file.write_text('{"output": {"color": "always"}}', encoding="utf-8")
        config = load_config(
            cli_overrides={"output": {"color": "never"}},
            config_file=config_file
        )
        assert config.output.color == "never"

    def test_full_priority_chain(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.setenv("RMSAFE_TRASH_DIR", "/env/trash")
        config_file = tmp_path / "config.jsonc"
        config_file.write_text('''
            {
                "trash": {"max_size": "1GB", "location": "/file/trash"},
                "output": {"color": "always"}
            }
        ''', encoding="utf-8")
        config = load_config(
            cli_overrides={"trash_dir": "/cli/trash", "output": {"color": "never"}},
            config_file=config_file
        )
        # CLI wins for both
        assert str(config.trash.location) == "/cli/trash"
        assert config.output.color == "never"
        # File setting still applies where CLI didn't override
        assert config.trash.max_size == "1GB"


class TestRecoveryPartialWrite:
    """Recovery from partially written/incomplete config files."""

    def test_truncated_json_raises_error(self, tmp_path: Path) -> None:
        """Config file truncated mid-write raises clear ValueError."""
        file = tmp_path / "partial.jsonc"
        # Simulate truncation: opening brace and partial content
        file.write_text('{"trash": {"max_size": "1G', encoding="utf-8")
        with pytest.raises(ValueError, match="Invalid config file"):
            _load_config_file(file)

    def test_incomplete_json_structure_raises_error(self, tmp_path: Path) -> None:
        """Incomplete JSON object raises clear ValueError."""
        file = tmp_path / "incomplete.jsonc"
        file.write_text('{"trash":', encoding="utf-8")
        with pytest.raises(ValueError, match="Invalid config file"):
            _load_config_file(file)

    def test_json_with_null_byte(self, tmp_path: Path) -> None:
        """File with embedded null byte raises clear ValueError."""
        file = tmp_path / "null_byte.jsonc"
        file.write_bytes(b'{"trash":\x00{"max_size": "1GB"}}')
        with pytest.raises(ValueError, match="Invalid config file"):
            _load_config_file(file)


class TestRecoveryEncoding:
    """Recovery from encoding issues."""

    def test_latin1_encoding_raises_error(self, tmp_path: Path) -> None:
        """Non-UTF-8 file raises clear ValueError."""
        file = tmp_path / "latin1.jsonc"
        # Latin-1 encoded content with character that's invalid in UTF-8
        content = b'{"comment": "R\xe9glage", "trash": {"max_size": "1GB"}}'
        file.write_bytes(content)
        # UTF-8 decode will fail; should raise ValueError
        with pytest.raises(ValueError, match="Invalid config file"):
            _load_config_file(file)

    def test_utf8_bom_raises_error(self, tmp_path: Path) -> None:
        """UTF-8 with BOM raises error (requires utf-8-sig encoding)."""
        file = tmp_path / "bom.jsonc"
        # UTF-8 BOM followed by valid JSON - but read with plain utf-8
        file.write_bytes(b'\xef\xbb\xbf{"trash": {"max_size": "1GB"}}')
        # Current loader uses utf-8, not utf-8-sig, so BOM causes error
        with pytest.raises(ValueError, match="Invalid config file"):
            _load_config_file(file)

    def test_mixed_encoding_file_raises_error(self, tmp_path: Path) -> None:
        """File with mixed/invalid encoding raises clear ValueError."""
        file = tmp_path / "mixed.jsonc"
        # Invalid UTF-8 sequence
        file.write_bytes(b'{"trash": "\xff\xfe"}')
        with pytest.raises(ValueError, match="Invalid config file"):
            _load_config_file(file)


class TestRecoveryBrokenJsonc:
    """Recovery from broken JSONC syntax."""

    def test_unclosed_block_comment(self, tmp_path: Path) -> None:
        """Unclosed /* comment causes parse error."""
        file = tmp_path / "unclosed_comment.jsonc"
        file.write_text('{"trash": /* unclosed comment', encoding="utf-8")
        with pytest.raises(ValueError, match="Invalid config file"):
            _load_config_file(file)

    def test_unclosed_string(self, tmp_path: Path) -> None:
        """Unclosed string causes parse error."""
        file = tmp_path / "unclosed_string.jsonc"
        file.write_text('{"trash": {"max_size": "1GB', encoding="utf-8")
        with pytest.raises(ValueError, match="Invalid config file"):
            _load_config_file(file)

    def test_malformed_comment_in_middle(self, tmp_path: Path) -> None:
        """Broken comment syntax mid-file causes parse error."""
        file = tmp_path / "broken_comment.jsonc"
        file.write_text('{"trash": { /* ok */ "max_size": "1GB" }, / * bad * /}', encoding="utf-8")
        with pytest.raises(ValueError, match="Invalid config file"):
            _load_config_file(file)

    def test_line_comment_at_end_works(self, tmp_path: Path) -> None:
        """Line comment at end without newline is now handled correctly."""
        file = tmp_path / "line_comment.jsonc"
        file.write_text('{"trash": {"max_size": "1GB"}} // trailing comment', encoding="utf-8")
        # Our implementation properly strips trailing line comments
        result = _load_config_file(file)
        assert result == {"trash": {"max_size": "1GB"}}

    def test_line_comment_with_newline_works(self, tmp_path: Path) -> None:
        """Line comment at end with newline is parsed correctly."""
        file = tmp_path / "line_comment_nl.jsonc"
        file.write_text('{"trash": {"max_size": "1GB"}}\n// trailing comment\n', encoding="utf-8")
        result = _load_config_file(file)
        assert result == {"trash": {"max_size": "1GB"}}


class TestRecoveryAutoCreate:
    """Recovery by auto-creating missing config files/directories."""

    def test_missing_config_file_uses_defaults(self, tmp_path: Path, monkeypatch) -> None:
        """Missing config file returns default config without error."""
        monkeypatch.delenv("RMSAFE_TRASH_DIR", raising=False)
        nonexistent = tmp_path / "nonexistent" / "config.jsonc"
        config = load_config(config_file=nonexistent)
        # Should get defaults, not error
        assert config.trash.max_size == "500MB"
        assert config.behavior.confirm_directories is True

    def test_missing_directory_uses_defaults(self, tmp_path: Path, monkeypatch) -> None:
        """Missing parent directory returns default config without error."""
        monkeypatch.delenv("RMSAFE_TRASH_DIR", raising=False)
        nonexistent = tmp_path / "deeply" / "nested" / "missing" / "config.jsonc"
        config = load_config(config_file=nonexistent)
        assert config.trash.max_size == "500MB"

    def test_file_created_after_load_check(self, tmp_path: Path, monkeypatch) -> None:
        """Race condition: file deleted between check and read is handled."""
        monkeypatch.delenv("RMSAFE_TRASH_DIR", raising=False)
        file = tmp_path / "race.jsonc"
        file.write_text('{"trash": {"max_size": "1GB"}}', encoding="utf-8")
        # Delete after existence confirmed
        file.unlink()
        result = _load_config_file(file)
        assert result == {}


class TestRecoveryCliOverrides:
    """Deterministic CLI override behavior and partial nested overrides."""

    def test_trash_dir_and_location_both_passed_deterministic(self) -> None:
        """Both trash_dir and trash_location: deterministic resolution."""
        # Based on implementation, trash_location wins (processed last in normalize)
        result = _normalize_cli_overrides({"trash_dir": "/dir_a", "trash_location": "/dir_b"})
        assert result["trash"]["location"] == "/dir_b"

    def test_trash_location_and_trash_dir_order(self) -> None:
        """Order of keys in dict shouldn't matter, trash_location wins."""
        # trash_location is processed last in implementation, wins
        result = _normalize_cli_overrides({"trash_location": "/first", "trash_dir": "/second"})
        assert result["trash"]["location"] == "/first"

    def test_cli_partial_nested_override(self, tmp_path: Path, monkeypatch) -> None:
        """CLI can override single nested field without affecting siblings."""
        monkeypatch.delenv("RMSAFE_TRASH_DIR", raising=False)
        config_file = tmp_path / "config.jsonc"
        config_file.write_text(
            '{"output": {"color": "always", "verbose": false, "icons": false}}',
            encoding="utf-8"
        )
        # Override only color, leave verbose and icons from file
        config = load_config(
            cli_overrides={"output": {"color": "never"}},
            config_file=config_file
        )
        assert config.output.color == "never"
        assert config.output.verbose is False  # From file
        assert config.output.icons is False    # From file

    def test_cli_partial_nested_trash(self, tmp_path: Path, monkeypatch) -> None:
        """CLI can override one trash field without losing others from file."""
        monkeypatch.delenv("RMSAFE_TRASH_DIR", raising=False)
        config_file = tmp_path / "config.jsonc"
        config_file.write_text(
            '{"trash": {"max_size": "2GB", "auto_clean_days": 7}}',
            encoding="utf-8"
        )
        # Override only max_size
        config = load_config(
            cli_overrides={"trash": {"max_size": "100MB"}},
            config_file=config_file
        )
        assert config.trash.max_size == "100MB"  # From CLI
        assert config.trash.auto_clean_days == 7  # From file

    def test_cli_nested_deep_merge(self, tmp_path: Path, monkeypatch) -> None:
        """Deep merge preserves unmodified nested values."""
        monkeypatch.delenv("RMSAFE_TRASH_DIR", raising=False)
        config_file = tmp_path / "config.jsonc"
        config_file.write_text(
            '''{
                "trash": {"max_size": "1GB", "auto_clean_days": 14},
                "behavior": {"confirm_large_files": "5MB", "confirm_directories": false},
                "output": {"color": "always", "verbose": false, "table_format": "simple"}
            }''',
            encoding="utf-8"
        )
        # Override multiple partial sections
        config = load_config(
            cli_overrides={
                "trash": {"auto_clean_days": 30},
                "output": {"color": "never"},
            },
            config_file=config_file
        )
        # Trash: CLI override + file default
        assert config.trash.auto_clean_days == 30
        assert config.trash.max_size == "1GB"  # From file
        # Behavior: all from file
        assert config.behavior.confirm_large_files == "5MB"
        assert config.behavior.confirm_directories is False
        # Output: CLI override + file defaults
        assert config.output.color == "never"
        assert config.output.verbose is False
        assert config.output.table_format == "simple"

    def test_cli_override_null_preserves_file(self, tmp_path: Path, monkeypatch) -> None:
        """CLI can set value to null/None (location allows None)."""
        monkeypatch.delenv("RMSAFE_TRASH_DIR", raising=False)
        config_file = tmp_path / "config.jsonc"
        config_file.write_text('{"trash": {"location": "/file/trash"}}', encoding="utf-8")
        # Set location to None via CLI (this should use default instead)
        config = load_config(
            cli_overrides={"trash": {"location": None}},
            config_file=config_file
        )
        # None from CLI means use default
        assert config.trash.location is not None  # Gets default platform location