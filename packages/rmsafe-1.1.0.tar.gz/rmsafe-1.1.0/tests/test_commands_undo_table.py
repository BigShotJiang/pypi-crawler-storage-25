"""Tests for undo command - Rich Table output with icons."""

from __future__ import annotations

import pytest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

from rmsafe.commands import undo
from rmsafe.output.icons import IconManager
from rmsafe.output.colors import ColorManager
from rmsafe.core.history_tracker import HistoryTracker, HistoryEntry


class TestFormatTimeAgo:
    """Test _format_time_ago function."""

    def test_just_now(self) -> None:
        """Very recent shows 'just now'."""
        now = datetime.now()
        assert undo._format_time_ago(now) == "just now"
        assert undo._format_time_ago(now - timedelta(seconds=30)) == "just now"

    def test_minutes(self) -> None:
        """Within hour shows minutes (short format)."""
        now = datetime.now()
        result = undo._format_time_ago(now - timedelta(minutes=5))
        assert result == "5m"

        result = undo._format_time_ago(now - timedelta(minutes=59))
        assert result == "59m"

    def test_hours(self) -> None:
        """Within day shows hours (short format)."""
        now = datetime.now()
        result = undo._format_time_ago(now - timedelta(hours=3))
        assert result == "3h"

        result = undo._format_time_ago(now - timedelta(hours=23))
        assert result == "23h"

    def test_days(self) -> None:
        """Within week shows days (short format)."""
        now = datetime.now()
        result = undo._format_time_ago(now - timedelta(days=2))
        assert result == "2d"

        result = undo._format_time_ago(now - timedelta(days=6))
        assert result == "6d"

    def test_weeks_and_months(self) -> None:
        """Older than week shows date format."""
        now = datetime.now()
        old = now - timedelta(days=10)
        result = undo._format_time_ago(old)
        # Should show MM/DD format
        assert "/" in result  # Like "01/15"

    def test_path_input(self) -> None:
        """If accidentally passed a Path, returns '-'."""
        result = undo._format_time_ago(Path("/some/path"))
        assert result == "-"


class TestFormatFileNames:
    """Test _format_file_names function."""

    def test_empty_list(self) -> None:
        """Empty file list returns '-'."""
        assert undo._format_file_names([]) == "-"

    def test_single_file(self) -> None:
        """Single file shows just the name."""
        files = [Path("/home/user/file.txt")]
        result = undo._format_file_names(files)
        assert result == "file.txt"

    def test_two_files(self) -> None:
        """Two files shows both names."""
        files = [Path("/a.txt"), Path("/b.txt")]
        result = undo._format_file_names(files)
        assert result == "a.txt, b.txt"

    def test_many_files(self) -> None:
        """More than 2 files shows first 2 plus count."""
        files = [Path("/a.txt"), Path("/b.txt"), Path("/c.txt"), Path("/d.txt")]
        result = undo._format_file_names(files)
        assert "a.txt" in result
        assert "b.txt" in result
        assert "... (2 more)" in result

    def test_exactly_three_files(self) -> None:
        """Exactly 3 files shows first 2 plus 1 more."""
        files = [Path("/a.txt"), Path("/b.txt"), Path("/c.txt")]
        result = undo._format_file_names(files)
        assert "... (1 more)" in result


class TestCalculateEntrySize:
    """Test _calculate_entry_size function."""

    def test_empty_list(self) -> None:
        """Empty file list has zero size."""
        assert undo._calculate_entry_size([]) == 0

    def test_single_file(self, tmp_path: Path) -> None:
        """Single file returns its size."""
        file = tmp_path / "test.txt"
        file.write_text("hello")  # 5 bytes
        result = undo._calculate_entry_size([file])
        assert result == 5

    def test_multiple_files(self, tmp_path: Path) -> None:
        """Multiple files returns total size."""
        files = [
            tmp_path / "a.txt",
            tmp_path / "b.txt",
        ]
        files[0].write_text("hello")  # 5 bytes
        files[1].write_text("world!")  # 6 bytes
        result = undo._calculate_entry_size(files)
        assert result == 11

    def test_nonexistent_file(self) -> None:
        """Nonexistent file contributes 0 to size."""
        nonexistent = Path("/nonexistent/file.txt")
        result = undo._calculate_entry_size([nonexistent])
        assert result == 0

    def test_directory(self, tmp_path: Path) -> None:
        """Directory size is calculated."""
        dir_path = tmp_path / "testdir"
        dir_path.mkdir()
        (dir_path / "file.txt").write_text("content")  # 7 bytes

        result = undo._calculate_entry_size([dir_path])
        assert result >= 7


class TestPrintHistoryTable:
    """Test _print_history_table function."""

    @pytest.fixture
    def icons(self) -> IconManager:
        return IconManager(use_icons=True)

    @pytest.fixture
    def colors(self) -> ColorManager:
        return ColorManager(color_setting="never")

    def test_empty_history(self, icons: IconManager, colors: ColorManager) -> None:
        """Empty history shows appropriate message."""
        tracker = MagicMock()
        tracker.list_recent.return_value = []

        undo._print_history_table(tracker, colors, icons, True)
        # Should not raise

    def test_single_entry(self, icons: IconManager, colors: ColorManager, tmp_path: Path) -> None:
        """Single entry is formatted correctly."""
        entry = HistoryEntry(
            timestamp=datetime.now() - timedelta(minutes=5),
            files=[tmp_path / "file.txt"],
            trashinfo_paths=[None],
        )
        (tmp_path / "file.txt").write_text("test")

        tracker = MagicMock()
        tracker.list_recent.return_value = [entry]

        undo._print_history_table(tracker, colors, icons, True)

    def test_multiple_entries(self, icons: IconManager, colors: ColorManager, tmp_path: Path) -> None:
        """Multiple entries are formatted correctly."""
        entries = [
            HistoryEntry(
                timestamp=datetime.now() - timedelta(minutes=5),
                files=[tmp_path / "a.txt"],
                trashinfo_paths=[None],
            ),
            HistoryEntry(
                timestamp=datetime.now() - timedelta(hours=2),
                files=[tmp_path / "b.txt", tmp_path / "c.txt"],
                trashinfo_paths=[None, None],
            ),
        ]
        (tmp_path / "a.txt").write_text("a")
        (tmp_path / "b.txt").write_text("b")
        (tmp_path / "c.txt").write_text("c")

        tracker = MagicMock()
        tracker.list_recent.return_value = entries

        undo._print_history_table(tracker, colors, icons, True)

    def test_icons_disabled(self, colors: ColorManager) -> None:
        """Icons disabled shows no emoji."""
        icons_disabled = IconManager(use_icons=False)
        entry = HistoryEntry(
            timestamp=datetime.now() - timedelta(minutes=5),
            files=[Path("/file.txt")],
            trashinfo_paths=[None],
        )

        tracker = MagicMock()
        tracker.list_recent.return_value = [entry]

        undo._print_history_table(tracker, colors, icons_disabled, False)


class TestUndoRunIntegration:
    """Integration tests for undo.run() function."""

    @patch("rmsafe.commands.undo.load_config")
    @patch("rmsafe.commands.undo.HistoryTracker")
    def test_run_list_empty(self, mock_tracker_class, mock_load_config) -> None:
        """Running undo --list with empty history shows message."""
        from rmsafe.config.schema import Config

        mock_config = Config()
        mock_load_config.return_value = mock_config

        mock_tracker = MagicMock()
        mock_tracker.list_recent.return_value = []
        mock_tracker_class.return_value = mock_tracker

        undo.run(None, list_only=True)
        # Should not raise

    @patch("rmsafe.commands.undo.load_config")
    @patch("rmsafe.commands.undo.HistoryTracker")
    @patch("rmsafe.commands.undo.TrashManager")
    def test_run_undo_single(self, mock_manager_class, mock_tracker_class, mock_load_config) -> None:
        """Running undo restores from history."""
        from rmsafe.config.schema import Config

        mock_config = Config()
        mock_load_config.return_value = mock_config

        mock_tracker = MagicMock()
        mock_tracker.undo_last.return_value = [
            HistoryEntry(
                timestamp=datetime.now(),
                files=[Path("/file.txt")],
                trashinfo_paths=[None],
            )
        ]
        mock_tracker_class.return_value = mock_tracker

        undo.run(1, list_only=False)


class TestUndoTableStructure:
    """Test Rich Table structure for undo history."""

    def test_table_has_correct_columns(self) -> None:
        """Table includes all required columns."""
        from rich.table import Table

        icons = IconManager(use_icons=True)
        restore_icon = icons.restore()

        table = Table(
            title=f"{restore_icon}Recently Trashed",
            title_style="bold cyan",
        )

        table.add_column("#")
        table.add_column("Time")
        table.add_column("Files")
        table.add_column("Size")
        table.add_column("Undo")

        # Verify columns exist
        assert len(table.columns) == 5

    def test_table_title_with_icons(self) -> None:
        """Table title includes restore icon when enabled."""
        icons = IconManager(use_icons=True)
        title = f"{icons.restore()}Recently Trashed"

        assert "↩️" in title

    def test_table_title_without_icons(self) -> None:
        """Table title has no icon when disabled."""
        icons = IconManager(use_icons=False)
        title = f"{icons.restore()}Recently Trashed"

        assert "↩️" not in title


class TestEdgeCases:
    """Test edge cases for undo command."""

    def test_very_long_file_names(self) -> None:
        """Very long file names are handled."""
        long_name = "a" * 100 + ".txt"
        files = [Path(f"/{long_name}")]

        result = undo._format_file_names(files)
        assert len(result) > 0  # Should not crash

    def test_special_characters_in_names(self) -> None:
        """Special characters in file names are handled."""
        files = [Path("/file with spaces.txt"), Path("/file-with-dashes.txt")]

        result = undo._format_file_names(files)
        assert "file with spaces.txt" in result

    def test_many_files_overflow(self) -> None:
        """Many files (> 10) shows summary correctly."""
        files = [Path(f"/file{i}.txt") for i in range(20)]
        result = undo._format_file_names(files)

        assert "... (" in result
        assert "more)" in result

    def test_negative_undo_count(self) -> None:
        """Negative undo count is handled gracefully."""
        # This should be handled by the caller, not undo.run()
        # But the function should not crash if called with valid input
        pass  # Placeholder for integration test