"""Tests for status command - Panel output with icons."""

from __future__ import annotations

import pytest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

from rmsafe.commands import status
from rmsafe.output.icons import IconManager


class TestFormatAge:
    """Test _format_age function for human-readable time formatting."""

    def test_just_now(self) -> None:
        """Very recent deletion shows 'just now'."""
        now = datetime.now()
        assert status._format_age(now) == "just now"
        assert status._format_age(now - timedelta(seconds=30)) == "just now"

    def test_minutes_ago(self) -> None:
        """Deletion within last hour shows minutes."""
        now = datetime.now()
        age = now - timedelta(minutes=5)
        assert status._format_age(age) == "5 min ago"

        age = now - timedelta(minutes=1)
        assert status._format_age(age) == "1 min ago"

    def test_hours_ago(self) -> None:
        """Deletion within last day shows hours."""
        now = datetime.now()
        age = now - timedelta(hours=3)
        assert status._format_age(age) == "3 hours ago"

        age = now - timedelta(hours=1)
        assert status._format_age(age) == "1 hour ago"

    def test_days_ago(self) -> None:
        """Deletion within last week shows days."""
        now = datetime.now()
        age = now - timedelta(days=2)
        assert status._format_age(age) == "2 days ago"

        age = now - timedelta(days=1)
        assert status._format_age(age) == "1 day ago"

    def test_weeks_ago(self) -> None:
        """Deletion within last month shows weeks."""
        now = datetime.now()
        age = now - timedelta(days=14)
        assert status._format_age(age) == "2 weeks ago"

        age = now - timedelta(days=7)
        assert status._format_age(age) == "1 week ago"

    def test_old_date_shows_actual_date(self) -> None:
        """Very old deletion shows actual date."""
        now = datetime.now()
        age = now - timedelta(days=60)
        result = status._format_age(age)
        # Should show date format like "2024-01-15"
        assert result == age.strftime("%Y-%m-%d")


class TestBuildStatusContent:
    """Test _build_status_content function."""

    @pytest.fixture
    def icons_enabled(self) -> IconManager:
        return IconManager(use_icons=True)

    @pytest.fixture
    def icons_disabled(self) -> IconManager:
        return IconManager(use_icons=False)

    def test_empty_trash(self, icons_enabled: IconManager) -> None:
        """Empty trash shows appropriate message."""
        content = status._build_status_content(
            file_count=0,
            total_size=0,
            oldest=None,
            newest=None,
            trash_path=Path("/tmp/Trash"),
            icons=icons_enabled,
            use_icons=True,
        )

        assert "Empty trash" in content
        assert "undo: nothing to restore" in content

    def test_single_file(self, icons_enabled: IconManager) -> None:
        """Single file shows correct count."""
        content = status._build_status_content(
            file_count=1,
            total_size=1024,
            oldest=datetime.now() - timedelta(minutes=5),
            newest=datetime.now() - timedelta(minutes=5),
            trash_path=Path("/tmp/Trash"),
            icons=icons_enabled,
            use_icons=True,
        )

        # Should show "1 file" (singular)
        assert "1 file" in content
        assert "1 KB" in content or "1024 bytes" in content

    def test_multiple_files(self, icons_enabled: IconManager) -> None:
        """Multiple files shows plural."""
        content = status._build_status_content(
            file_count=42,
            total_size=1024 * 1024 * 100,  # 100 MB
            oldest=datetime.now() - timedelta(days=30),
            newest=datetime.now() - timedelta(hours=1),
            trash_path=Path("/tmp/Trash"),
            icons=icons_enabled,
            use_icons=True,
        )

        assert "42 files" in content
        assert "100.0 MB" in content or "100 MB" in content

    def test_same_age_files(self, icons_enabled: IconManager) -> None:
        """Files with same age show single timestamp."""
        same_time = datetime.now() - timedelta(hours=2)
        content = status._build_status_content(
            file_count=5,
            total_size=1024,
            oldest=same_time,
            newest=same_time,
            trash_path=Path("/tmp/Trash"),
            icons=icons_enabled,
            use_icons=True,
        )

        assert "all deleted" in content

    def test_different_age_files(self, icons_enabled: IconManager) -> None:
        """Files with different ages show range."""
        content = status._build_status_content(
            file_count=10,
            total_size=1024,
            oldest=datetime.now() - timedelta(days=5),
            newest=datetime.now() - timedelta(hours=1),
            trash_path=Path("/tmp/Trash"),
            icons=icons_enabled,
            use_icons=True,
        )

        assert "oldest:" in content and "newest:" in content

    def test_undo_hint_with_files(self, icons_enabled: IconManager) -> None:
        """Files available shows undo hint."""
        content = status._build_status_content(
            file_count=3,
            total_size=1024,
            oldest=datetime.now() - timedelta(minutes=5),
            newest=None,
            trash_path=Path("/tmp/Trash"),
            icons=icons_enabled,
            use_icons=True,
        )

        assert "undo available" in content or "rmsafe undo" in content

    def test_icons_disabled(self, icons_disabled: IconManager) -> None:
        """Icons disabled changes output."""
        content = status._build_status_content(
            file_count=1,
            total_size=1024,
            oldest=None,
            newest=None,
            trash_path=Path("/tmp/Trash"),
            icons=icons_disabled,
            use_icons=False,
        )

        # No emoji icons in output when disabled
        assert "🗑️" not in content
        assert "↩️" not in content

    def test_trash_path_shown(self, icons_enabled: IconManager) -> None:
        """Trash path is always shown."""
        content = status._build_status_content(
            file_count=0,
            total_size=0,
            oldest=None,
            newest=None,
            trash_path=Path("/home/user/.Trash"),
            icons=icons_enabled,
            use_icons=True,
        )

        assert "/home/user/.Trash" in content

    def test_content_is_rich_markup(self, icons_enabled: IconManager) -> None:
        """Content contains Rich markup tags."""
        content = status._build_status_content(
            file_count=5,
            total_size=1024,
            oldest=datetime.now() - timedelta(minutes=5),
            newest=None,
            trash_path=Path("/tmp/Trash"),
            icons=icons_enabled,
            use_icons=True,
        )

        # Should have Rich markup like [bold], [dim], [cyan]
        assert "[bold]" in content or "[cyan]" in content or "[dim]" in content


class TestCollectStats:
    """Test _collect_stats function."""

    def test_empty_trash_dir(self, tmp_path: Path) -> None:
        """Empty trash directory returns zeros."""
        from rmsafe.core.trash_manager import TrashManager

        trash_dir = tmp_path / "Trash"
        trash_dir.mkdir()
        manager = TrashManager(trash_dir)

        count, size, oldest, newest = status._collect_stats(manager)
        assert count == 0
        assert size == 0
        assert oldest is None
        assert newest is None

    def test_files_without_trashinfo(self, tmp_path: Path) -> None:
        """Files without trashinfo still counted."""
        from rmsafe.core.trash_manager import TrashManager

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        # Create files without trashinfo
        (files_dir / "file1.txt").write_text("content")
        (files_dir / "file2.txt").write_text("content2")

        manager = TrashManager(trash_dir)
        count, size, oldest, newest = status._collect_stats(manager)

        assert count == 2
        assert size > 0
        assert oldest is None  # No timestamps available
        assert newest is None


class TestStatusRunIntegration:
    """Integration tests for status.run() function."""

    @patch("rmsafe.commands.status.load_config")
    @patch("rmsafe.commands.status.get_default_trash_path")
    def test_run_empty_trash(self, mock_get_default, mock_load_config, tmp_path: Path) -> None:
        """Running status on empty trash displays empty message."""
        from rmsafe.config.schema import Config

        # Setup mocks
        mock_config = Config()
        mock_load_config.return_value = mock_config
        mock_get_default.return_value = tmp_path / "Trash"

        trash_dir = tmp_path / "Trash"
        trash_dir.mkdir()
        files_dir = trash_dir / "files"
        files_dir.mkdir()

        # Run should not raise
        status.run()

    @patch("rmsafe.commands.status.load_config")
    @patch("rmsafe.commands.status.get_default_trash_path")
    def test_run_with_files(self, mock_get_default, mock_load_config, tmp_path: Path) -> None:
        """Running status with files displays file count."""
        from rmsafe.config.schema import Config

        mock_config = Config()
        mock_load_config.return_value = mock_config
        mock_get_default.return_value = tmp_path / "Trash"

        trash_dir = tmp_path / "Trash"
        trash_dir.mkdir()
        files_dir = trash_dir / "files"
        files_dir.mkdir()

        # Create some files
        (files_dir / "file1.txt").write_text("test")
        (files_dir / "file2.txt").write_text("test")

        status.run()


class TestStatusPanelOutput:
    """Test Panel output format."""

    def test_panel_has_trash_title(self) -> None:
        """Panel title includes trash icon when enabled."""
        icons = IconManager(use_icons=True)
        title = f"{icons.trash()}Trash"

        assert "🗑️" in title or "Trash" in title

    def test_panel_title_without_icons(self) -> None:
        """Panel title is just 'Trash' when icons disabled."""
        icons = IconManager(use_icons=False)
        title = f"{icons.trash()}Trash"

        # No emoji when icons disabled
        assert "🗑️" not in title


class TestEdgeCases:
    """Test edge cases for status command."""

    def test_very_large_size(self) -> None:
        """Large sizes are formatted correctly."""
        from rmsafe.utils.size import format_size

        large_size = 1024 * 1024 * 1024 * 5  # 5 GB
        formatted = format_size(large_size)

        assert "5" in formatted
        assert "GB" in formatted

    def test_single_byte_size(self) -> None:
        """Tiny sizes are formatted correctly."""
        from rmsafe.utils.size import format_size

        # format_size returns "1 byte" for single byte
        assert format_size(1) == "1 byte"

    def test_age_at_boundary(self) -> None:
        """Age at exact boundary is correct."""
        now = datetime.now()

        # Exactly 1 minute
        age = now - timedelta(minutes=1)
        result = status._format_age(age)
        assert "1 min ago" in result or "just now" in result

        # Exactly 1 hour
        age = now - timedelta(hours=1)
        result = status._format_age(age)
        assert "1 hour ago" in result or "60 min ago" in result

    def test_future_timestamp(self) -> None:
        """Future timestamp (edge case) handled gracefully."""
        # This shouldn't happen in practice, but should not crash
        now = datetime.now()
        future = now + timedelta(hours=1)

        # Should not crash
        result = status._format_age(future)
        assert isinstance(result, str)