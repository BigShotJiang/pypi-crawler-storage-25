from __future__ import annotations

from pathlib import Path

from rmsafe.core.history_tracker import HistoryTracker
from rmsafe.core.trash_manager import TrashManager


def test_history_tracker_records_and_lists_recent(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    tracker = HistoryTracker(max_entries=2)

    tracker.record_deletion([Path("/tmp/a.txt")], [Path("/tmp/a.txt.trashinfo")])
    tracker.record_deletion([Path("/tmp/b.txt")], [Path("/tmp/b.txt.trashinfo")])
    tracker.record_deletion([Path("/tmp/c.txt")], [Path("/tmp/c.txt.trashinfo")])

    recent = tracker.list_recent()
    assert [entry.files[0] for entry in recent] == [Path("/tmp/c.txt"), Path("/tmp/b.txt")]


def test_history_tracker_undo_restores_last_deletion(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    trash_dir = tmp_path / ".local/share/Trash"
    files_dir = trash_dir / "files"
    info_dir = trash_dir / "info"
    files_dir.mkdir(parents=True)
    info_dir.mkdir(parents=True)

    trashed = files_dir / "note.txt"
    trashed.write_text("hello", encoding="utf-8")
    info_path = info_dir / "note.txt.trashinfo"
    info_path.write_text(
        f"[Trash Info]\nPath={tmp_path / 'note.txt'}\nDeletionDate=2026-04-26T10:00:00\n",
        encoding="utf-8",
    )

    tracker = HistoryTracker(history_path=tmp_path / ".local/share/rmsafe/history.json")
    tracker.record_deletion([tmp_path / "note.txt"], [info_path])

    restored = tracker.undo_last(1, trash_manager=TrashManager(trash_dir))

    assert restored[0].files[0] == tmp_path / "note.txt"
    assert (tmp_path / "note.txt").read_text(encoding="utf-8") == "hello"
    assert not trashed.exists()


def test_history_tracker_undo_keeps_history_when_restore_fails(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    trash_dir = tmp_path / ".local/share/Trash"
    files_dir = trash_dir / "files"
    files_dir.mkdir(parents=True)

    tracker = HistoryTracker(history_path=tmp_path / ".local/share/rmsafe/history.json")
    tracker.record_deletion([tmp_path / "missing.txt"], [None])

    try:
        tracker.undo_last(1, trash_manager=TrashManager(trash_dir))
    except FileNotFoundError:
        pass

    assert tracker.list_recent()[0].files[0] == tmp_path / "missing.txt"


def test_history_tracker_list_recent_respects_limit(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    tracker = HistoryTracker(max_entries=5)
    tracker.record_deletion([tmp_path / "a.txt"], [None])
    tracker.record_deletion([tmp_path / "b.txt"], [None])

    recent = tracker.list_recent(limit=1)
    assert len(recent) == 1
    assert recent[0].files[0] == tmp_path / "b.txt"
