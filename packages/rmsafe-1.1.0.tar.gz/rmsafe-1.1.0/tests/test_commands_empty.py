"""Comprehensive tests for commands/empty.py following SQLite test philosophy."""
from __future__ import annotations

import os
import sys
from datetime import datetime, timedelta
from io import StringIO
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import typer

from rmsafe.commands.empty import (
    run,
    _collect_candidates,
    _remove_candidate,
    _current_time,
    TrashCandidate,
)
from rmsafe.output.colors import Color, ColorManager
from rmsafe.output.icons import Icon, IconManager
from rmsafe.utils.size import format_size


class TestTrashCandidate:
    """TrashCandidate - every field, every state."""

    def test_basic_candidate(self, tmp_path: Path) -> None:
        candidate = TrashCandidate(
            path=tmp_path / "file.txt",
            info_path=tmp_path / "file.txt.trashinfo",
            deletion_date=datetime(2026, 4, 26, 10, 0, 0),
            size_bytes=100,
        )
        assert candidate.path == tmp_path / "file.txt"
        assert candidate.info_path == tmp_path / "file.txt.trashinfo"
        assert candidate.deletion_date == datetime(2026, 4, 26, 10, 0, 0)
        assert candidate.size_bytes == 100

    def test_candidate_with_none_info_path(self, tmp_path: Path) -> None:
        candidate = TrashCandidate(
            path=tmp_path / "file.txt",
            info_path=None,
            deletion_date=None,
            size_bytes=100,
        )
        assert candidate.info_path is None
        assert candidate.deletion_date is None

    def test_candidate_slots(self, tmp_path: Path) -> None:
        candidate = TrashCandidate(
            path=tmp_path / "file.txt",
            info_path=None,
            deletion_date=None,
            size_bytes=0,
        )
        # slots=True prevents adding new attributes
        with pytest.raises(AttributeError):
            candidate.extra_field = "test"

    def test_zero_size(self, tmp_path: Path) -> None:
        candidate = TrashCandidate(
            path=tmp_path / "empty.txt",
            info_path=None,
            deletion_date=None,
            size_bytes=0,
        )
        assert candidate.size_bytes == 0

    def test_large_size(self, tmp_path: Path) -> None:
        candidate = TrashCandidate(
            path=tmp_path / "large.txt",
            info_path=None,
            deletion_date=None,
            size_bytes=10_000_000,
        )
        assert candidate.size_bytes == 10_000_000


class TestCurrentTime:
    """_current_time() - every environment state."""

    def test_without_trash_date_env(self, monkeypatch) -> None:
        monkeypatch.delenv("TRASH_DATE", raising=False)
        result = _current_time()
        assert isinstance(result, datetime)
        # Should be close to now
        now = datetime.now()
        diff = abs((result - now).total_seconds())
        assert diff < 1  # Within 1 second

    def test_with_trash_date_iso_format(self, monkeypatch) -> None:
        monkeypatch.setenv("TRASH_DATE", "2026-04-26T10:00:00")
        result = _current_time()
        assert result == datetime(2026, 4, 26, 10, 0, 0)

    def test_with_trash_date_with_z(self, monkeypatch) -> None:
        monkeypatch.setenv("TRASH_DATE", "2026-04-26T10:00:00Z")
        result = _current_time()
        assert result.tzinfo is not None

    def test_with_trash_date_with_offset(self, monkeypatch) -> None:
        monkeypatch.setenv("TRASH_DATE", "2026-04-26T10:00:00+05:00")
        result = _current_time()
        assert result.tzinfo is not None

    def test_invalid_trash_date_raises(self, monkeypatch) -> None:
        monkeypatch.setenv("TRASH_DATE", "invalid-date")
        with pytest.raises(typer.Exit):
            _current_time()

    def test_empty_trash_date_uses_now(self, monkeypatch) -> None:
        monkeypatch.setenv("TRASH_DATE", "")
        result = _current_time()
        assert isinstance(result, datetime)


class TestCollectCandidates:
    """_collect_candidates() - every trash state."""

    def test_empty_files_dir(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashManager

        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)

        candidates = _collect_candidates(manager)
        assert candidates == []

    def test_nonexistent_files_dir(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashManager

        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)

        candidates = _collect_candidates(manager)
        assert candidates == []

    def test_single_file(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashManager
        from rmsafe.core.trashinfo import write_trashinfo

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content", encoding="utf-8")
        write_trashinfo(info_dir / "file.txt.trashinfo", Path("/original/file.txt"), datetime(2026, 4, 26))

        manager = TrashManager(trash_dir)
        candidates = _collect_candidates(manager)

        assert len(candidates) == 1
        assert candidates[0].path == files_dir / "file.txt"
        assert candidates[0].deletion_date is not None

    def test_multiple_files_sorted(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashManager

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "z.txt").write_text("z", encoding="utf-8")
        (files_dir / "a.txt").write_text("a", encoding="utf-8")
        (files_dir / "m.txt").write_text("m", encoding="utf-8")

        manager = TrashManager(trash_dir)
        candidates = _collect_candidates(manager)

        assert len(candidates) == 3
        # Sorted by name.lower()
        names = [c.path.name for c in candidates]
        assert names == ["a.txt", "m.txt", "z.txt"]

    def test_file_without_info(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashManager

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        candidates = _collect_candidates(manager)

        assert len(candidates) == 1
        assert candidates[0].deletion_date is None

    def test_directory_candidate(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashManager

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        trashed_dir = files_dir / "mydir"
        trashed_dir.mkdir()
        (trashed_dir / "file.txt").write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        candidates = _collect_candidates(manager)

        assert len(candidates) == 1
        assert candidates[0].path.is_dir()
        assert candidates[0].size_bytes > 0

    def test_macos_layout_no_info_dir(self, tmp_path: Path, monkeypatch) -> None:
        from rmsafe.core.trash_manager import TrashManager

        monkeypatch.setattr("sys.platform", "darwin")
        trash_dir = tmp_path / ".Trash"
        trash_dir.mkdir()

        (trash_dir / "file.txt").write_text("content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        candidates = _collect_candidates(manager)

        assert len(candidates) == 1
        assert candidates[0].info_path is None
        assert candidates[0].deletion_date is None

    def test_invalid_trashinfo_ignored(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashManager

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content", encoding="utf-8")
        (info_dir / "file.txt.trashinfo").write_text("invalid content", encoding="utf-8")

        manager = TrashManager(trash_dir)
        candidates = _collect_candidates(manager)

        assert len(candidates) == 1
        assert candidates[0].deletion_date is None  # Invalid info ignored

    def test_symlink_in_trash(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashManager

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        target = tmp_path / "target.txt"
        target.write_text("target", encoding="utf-8")
        link = files_dir / "link.txt"
        link.symlink_to(target)

        manager = TrashManager(trash_dir)
        candidates = _collect_candidates(manager)

        assert len(candidates) == 1
        assert candidates[0].path.is_symlink()

    def test_empty_file_size(self, tmp_path: Path) -> None:
        from rmsafe.core.trash_manager import TrashManager

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "empty.txt").write_text("", encoding="utf-8")

        manager = TrashManager(trash_dir)
        candidates = _collect_candidates(manager)

        assert candidates[0].size_bytes == 0


class TestRemoveCandidate:
    """_remove_candidate() - every file type."""

    def test_remove_file(self, tmp_path: Path) -> None:
        file = tmp_path / "file.txt"
        file.write_text("content", encoding="utf-8")
        info = tmp_path / "file.txt.trashinfo"
        info.write_text("[Trash Info]", encoding="utf-8")

        candidate = TrashCandidate(
            path=file,
            info_path=info,
            deletion_date=datetime.now(),
            size_bytes=100,
        )

        _remove_candidate(candidate)

        assert not file.exists()
        assert not info.exists()

    def test_remove_directory(self, tmp_path: Path) -> None:
        dir_path = tmp_path / "mydir"
        dir_path.mkdir()
        (dir_path / "file.txt").write_text("content", encoding="utf-8")

        candidate = TrashCandidate(
            path=dir_path,
            info_path=None,
            deletion_date=None,
            size_bytes=100,
        )

        _remove_candidate(candidate)

        assert not dir_path.exists()

    def test_remove_without_info(self, tmp_path: Path) -> None:
        file = tmp_path / "file.txt"
        file.write_text("content", encoding="utf-8")

        candidate = TrashCandidate(
            path=file,
            info_path=None,
            deletion_date=None,
            size_bytes=100,
        )

        _remove_candidate(candidate)

        assert not file.exists()

    def test_remove_info_missing_ok(self, tmp_path: Path) -> None:
        file = tmp_path / "file.txt"
        file.write_text("content", encoding="utf-8")
        info = tmp_path / "nonexistent.trashinfo"  # Doesn't exist

        candidate = TrashCandidate(
            path=file,
            info_path=info,
            deletion_date=None,
            size_bytes=100,
        )

        _remove_candidate(candidate)

        assert not file.exists()

    def test_remove_symlink(self, tmp_path: Path) -> None:
        target = tmp_path / "target.txt"
        target.write_text("target", encoding="utf-8")
        link = tmp_path / "link.txt"
        link.symlink_to(target)

        candidate = TrashCandidate(
            path=link,
            info_path=None,
            deletion_date=None,
            size_bytes=0,
        )

        _remove_candidate(candidate)

        assert not link.exists()
        assert target.exists()  # Target not removed

    def test_remove_nested_directory(self, tmp_path: Path) -> None:
        dir_path = tmp_path / "nested"
        inner = dir_path / "inner" / "deep"
        inner.mkdir(parents=True)
        (inner / "file.txt").write_text("nested", encoding="utf-8")

        candidate = TrashCandidate(
            path=dir_path,
            info_path=None,
            deletion_date=None,
            size_bytes=100,
        )

        _remove_candidate(candidate)

        assert not dir_path.exists()

    def test_remove_file_already_deleted(self, tmp_path: Path) -> None:
        file = tmp_path / "nonexistent.txt"  # Doesn't exist

        candidate = TrashCandidate(
            path=file,
            info_path=None,
            deletion_date=None,
            size_bytes=0,
        )

        _remove_candidate(candidate)  # missing_ok=True


class TestRun:
    """run() - every scenario, every flag."""

    def test_empty_all_files(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "a.txt").write_text("a", encoding="utf-8")
        (files_dir / "b.txt").write_text("b", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        # Monkeypatch load_config to return our config
        def mock_load_config():
            return config

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = mock_load_config

        run(days=None, force=True)

        assert not (files_dir / "a.txt").exists()
        assert not (files_dir / "b.txt").exists()

    def test_empty_with_age_filter(self, tmp_path: Path, monkeypatch) -> None:
        from rmsafe.config.schema import Config
        from rmsafe.core.trashinfo import write_trashinfo

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Old file
        (files_dir / "old.txt").write_text("old", encoding="utf-8")
        write_trashinfo(info_dir / "old.txt.trashinfo", Path("/old.txt"), datetime(2025, 1, 1))

        # New file
        (files_dir / "new.txt").write_text("new", encoding="utf-8")
        write_trashinfo(info_dir / "new.txt.trashinfo", Path("/new.txt"), datetime(2026, 4, 26))

        # Set current time
        monkeypatch.setenv("TRASH_DATE", "2026-04-26T10:00:00")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        # Empty files older than 30 days
        run(days=30, force=True)

        # Old file deleted
        assert not (files_dir / "old.txt").exists()
        # New file kept
        assert (files_dir / "new.txt").exists()

    def test_empty_empty_trash(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)  # Nothing to empty

    def test_empty_no_matching_age(self, tmp_path: Path, monkeypatch) -> None:
        from rmsafe.config.schema import Config
        from rmsafe.core.trashinfo import write_trashinfo

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Recent file
        (files_dir / "recent.txt").write_text("recent", encoding="utf-8")
        write_trashinfo(info_dir / "recent.txt.trashinfo", Path("/recent.txt"), datetime(2026, 4, 26))

        monkeypatch.setenv("TRASH_DATE", "2026-04-26T10:00:00")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        # Empty files older than 100 days - none match
        run(days=100, force=True)

        assert (files_dir / "recent.txt").exists()

    def test_force_skips_confirmation(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        # force=True skips confirmation
        run(days=None, force=True)

        assert not (files_dir / "file.txt").exists()

    def test_age_filter_macos_layout_no_info(self, tmp_path: Path, monkeypatch) -> None:
        from rmsafe.config.schema import Config

        monkeypatch.setattr("sys.platform", "darwin")
        trash_dir = tmp_path / ".Trash"
        trash_dir.mkdir()
        (trash_dir / "file.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        # macOS layout has no info dir, cannot age-filter
        # run(days=30, force=True) would print warning and return
        # This test verifies the warning path
        run(days=30, force=True)


class TestEdgeCases:
    """Edge cases and unusual scenarios."""

    def test_unicode_filenames(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "你好.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        assert not (files_dir / "你好.txt").exists()

    def test_special_chars_filenames(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file-test_$.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        assert not (files_dir / "file-test_$.txt").exists()

    def test_dotfiles_in_trash(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / ".hidden").write_text("hidden", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        assert not (files_dir / ".hidden").exists()

    @pytest.mark.skip(reason="Linux and macOS both allow owner to delete chmod 000 files")
    def test_permission_denied_file(self, tmp_path: Path) -> None:
        import os
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        secret = files_dir / "secret.txt"
        secret.write_text("secret", encoding="utf-8")
        os.chmod(secret, 0o000)

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        try:
            run(days=None, force=True)  # Should handle error gracefully
        finally:
            os.chmod(secret, 0o644)

    @pytest.mark.skip(reason="Linux and macOS both allow owner to delete chmod 000 directories")
    def test_permission_denied_directory(self, tmp_path: Path) -> None:
        import os
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        locked_dir = files_dir / "locked"
        locked_dir.mkdir()
        (locked_dir / "file.txt").write_text("content", encoding="utf-8")
        os.chmod(locked_dir, 0o000)

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        try:
            run(days=None, force=True)  # Should handle error
        finally:
            os.chmod(locked_dir, 0o755)

    def test_large_directory_tree(self, tmp_path: Path) -> None:
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        # Create nested structure
        deep = files_dir / "deep" / "nested" / "dirs"
        deep.mkdir(parents=True)
        for i in range(10):
            (deep / f"file{i}.txt").write_text(f"content{i}", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        assert not (files_dir / "deep").exists()

    def test_zero_days_filters_all(self, tmp_path: Path, monkeypatch) -> None:
        from rmsafe.config.schema import Config
        from rmsafe.core.trashinfo import write_trashinfo

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content", encoding="utf-8")
        write_trashinfo(info_dir / "file.txt.trashinfo", Path("/file.txt"), datetime(2026, 4, 26, 10, 0, 0))

        monkeypatch.setenv("TRASH_DATE", "2026-04-26T10:00:01")  # 1 second later

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=0, force=True)  # Files from 0+ days ago

        assert not (files_dir / "file.txt").exists()


class TestEmptyWithIcons:
    """Icon integration tests - verify icons can be used with empty command output."""

    def test_icon_manager_success_icon(self) -> None:
        """Success icon renders correctly."""
        manager = IconManager(use_icons=True, use_emoji=True)
        assert manager.success() == "✓ "
        assert manager.icon(Icon.SUCCESS) == "✓"

    def test_icon_manager_success_icon_disabled(self) -> None:
        """Success icon is empty when icons disabled."""
        manager = IconManager(use_icons=False, use_emoji=True)
        assert manager.success() == ""
        assert manager.icon(Icon.SUCCESS) == ""

    def test_icon_manager_trash_icon_emoji(self) -> None:
        """Trash icon uses emoji when enabled."""
        manager = IconManager(use_icons=True, use_emoji=True)
        assert manager.trash() == "🗑️ "
        assert manager.icon(Icon.TRASH) == "🗑️"

    def test_icon_manager_trash_icon_unicode_fallback(self) -> None:
        """Trash icon uses unicode fallback when emoji disabled."""
        manager = IconManager(use_icons=True, use_emoji=False)
        assert manager.trash() == "🗑 "
        assert manager.icon(Icon.TRASH) == "🗑"

    def test_icon_manager_all_status_icons(self) -> None:
        """All status icons render correctly."""
        manager = IconManager(use_icons=True, use_emoji=True)
        assert manager.icon(Icon.SUCCESS) == "✓"
        assert manager.icon(Icon.ERROR) == "✗"
        assert manager.icon(Icon.WARNING) == "⚠"
        assert manager.icon(Icon.INFO) == "ℹ"

    def test_icon_manager_file_folder_icons(self) -> None:
        """File and folder icons render correctly."""
        manager = IconManager(use_icons=True, use_emoji=True)
        assert manager.file() == "📄 "
        assert manager.folder() == "📁 "

    def test_icon_manager_file_folder_unicode_fallback(self) -> None:
        """File and folder icons use unicode fallback."""
        manager = IconManager(use_icons=True, use_emoji=False)
        assert manager.file() == "☐ "
        assert manager.folder() == "☐ "

    def test_icon_prefixed_empty_summary(self) -> None:
        """Empty summary message can be prefixed with icon."""
        manager = IconManager(use_icons=True, use_emoji=True)
        count = 5
        size_freed = format_size(10240)
        message = f"{manager.success()}Emptied {count} item(s), freed {size_freed}."
        assert message == "✓ Emptied 5 item(s), freed 10 KB."

    def test_icon_prefixed_empty_summary_no_icons(self) -> None:
        """Empty summary message without icons."""
        manager = IconManager(use_icons=False, use_emoji=True)
        count = 5
        size_freed = format_size(10240)
        message = f"{manager.success()}Emptied {count} item(s), freed {size_freed}."
        assert message == "Emptied 5 item(s), freed 10 KB."


class TestEmptyColorOutput:
    """Color output tests - verify color settings affect output."""

    def test_color_manager_auto_mode(self, monkeypatch) -> None:
        """ColorManager in auto mode respects TTY detection."""
        monkeypatch.setattr("rmsafe.output.colors.should_use_color", lambda _: True)
        manager = ColorManager("auto")
        styled = manager.style("test", Color.SUCCESS)
        assert "[green]test[/green]" == styled

    def test_color_manager_never_mode(self) -> None:
        """ColorManager in never mode outputs plain text."""
        manager = ColorManager("never")
        styled = manager.style("test", Color.SUCCESS)
        assert styled == "test"

    def test_color_manager_always_mode(self) -> None:
        """ColorManager in always mode outputs styled text."""
        manager = ColorManager("always")
        styled = manager.style("test", Color.SUCCESS)
        assert "[green]test[/green]" == styled

    def test_all_color_types(self) -> None:
        """All Color enum values produce correct styles."""
        manager = ColorManager("always")
        assert manager.style("info", Color.INFO) == "[cyan]info[/cyan]"
        assert manager.style("success", Color.SUCCESS) == "[green]success[/green]"
        assert manager.style("warning", Color.WARNING) == "[yellow]warning[/yellow]"
        assert manager.style("error", Color.ERROR) == "[red]error[/red]"
        assert manager.style("highlight", Color.HIGHLIGHT) == "[magenta]highlight[/magenta]"

    def test_empty_command_with_color_always(self, tmp_path: Path, capsys) -> None:
        """Empty command outputs colored messages with color=always."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir
        config.output.color = "always"

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        # Rich outputs ANSI codes - strip them for assertion
        import re
        stripped = re.sub(r"\x1b\[[0-9;]*m", "", captured.out)
        assert "Emptied 1 item(s)" in stripped
        assert "freed" in stripped
        # Verify ANSI codes are present (color is enabled)
        assert "\x1b[32m" in captured.out  # green

    def test_empty_command_with_color_never(self, tmp_path: Path, capsys) -> None:
        """Empty command outputs plain messages with color=never."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir
        config.output.color = "never"

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "Emptied 1 item(s)" in captured.out
        # Should not contain color markup
        assert "[green]" not in captured.out
        assert "[/green]" not in captured.out

    def test_empty_command_no_files_message_color(self, tmp_path: Path, capsys) -> None:
        """Empty command 'No trashed files' message with color."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"

        config = Config()
        config.trash.location = trash_dir
        config.output.color = "always"

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "No trashed files found" in captured.out

    def test_empty_command_nothing_to_empty_message_color(self, tmp_path: Path, monkeypatch, capsys) -> None:
        """Empty command 'Nothing to empty' message with color."""
        from rmsafe.config.schema import Config
        from rmsafe.core.trashinfo import write_trashinfo

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create a file with recent deletion date
        (files_dir / "recent.txt").write_text("recent", encoding="utf-8")
        write_trashinfo(info_dir / "recent.txt.trashinfo", Path("/recent.txt"), datetime(2026, 4, 26, 10, 0, 0))

        monkeypatch.setenv("TRASH_DATE", "2026-04-26T10:00:00")

        config = Config()
        config.trash.location = trash_dir
        config.output.color = "always"

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        # Request files older than 100 days - none match
        run(days=100, force=True)

        captured = capsys.readouterr()
        assert "Nothing to empty" in captured.out


class TestEmptySummary:
    """Summary output formatting tests - verify 'Emptied N item(s), freed X' format."""

    def test_summary_single_item(self, tmp_path: Path, capsys) -> None:
        """Summary shows 'Emptied 1 item(s), freed X' for single file."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("hello world", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "Emptied 1 item(s)" in captured.out
        assert "freed" in captured.out

    def test_summary_multiple_items(self, tmp_path: Path, capsys) -> None:
        """Summary shows correct count for multiple files."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        for i in range(5):
            (files_dir / f"file{i}.txt").write_text(f"content {i}", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "Emptied 5 item(s)" in captured.out

    def test_summary_size_zero_bytes(self, tmp_path: Path, capsys) -> None:
        """Summary shows '0 bytes' for empty files."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "empty.txt").write_text("", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "freed 0 bytes" in captured.out

    def test_summary_size_single_byte(self, tmp_path: Path, capsys) -> None:
        """Summary shows '1 byte' (singular) for single byte."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "single.txt").write_bytes(b"x")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "freed 1 byte" in captured.out

    def test_summary_size_small_bytes(self, tmp_path: Path, capsys) -> None:
        """Summary shows bytes for small sizes."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "small.txt").write_bytes(b"hello")  # 5 bytes

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "freed 5 bytes" in captured.out

    def test_summary_size_kilobytes(self, tmp_path: Path, capsys) -> None:
        """Summary shows KB for kilobyte sizes."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        # 2048 bytes = 2 KB
        (files_dir / "file.txt").write_bytes(b"x" * 2048)

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "freed 2 KB" in captured.out

    def test_summary_size_megabytes(self, tmp_path: Path, capsys) -> None:
        """Summary shows MB for megabyte sizes."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        # 1.5 MB
        (files_dir / "file.txt").write_bytes(b"x" * (1024 * 1024 + 512 * 1024))

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "freed 1.5 MB" in captured.out

    def test_summary_size_gigabytes(self, tmp_path: Path, capsys) -> None:
        """Summary shows GB for gigabyte sizes."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        # 2 GB
        (files_dir / "large.txt").write_bytes(b"x" * (2 * 1024 * 1024 * 1024))

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "freed 2 GB" in captured.out

    def test_summary_includes_directory_size(self, tmp_path: Path, capsys) -> None:
        """Summary includes size of directories."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        trashed_dir = files_dir / "mydir"
        trashed_dir.mkdir()
        (trashed_dir / "file1.txt").write_bytes(b"x" * 100)
        (trashed_dir / "file2.txt").write_bytes(b"x" * 100)

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "Emptied 1 item(s)" in captured.out
        assert "freed" in captured.out


class TestEmptyUXFeedback:
    """User feedback message tests - verify all user-facing messages."""

    def test_no_trashed_files_message(self, tmp_path: Path, capsys) -> None:
        """Shows 'No trashed files found.' when trash is empty."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "No trashed files found" in captured.out

    def test_nothing_to_empty_message(self, tmp_path: Path, monkeypatch, capsys) -> None:
        """Shows 'Nothing to empty.' when no files match age filter."""
        from rmsafe.config.schema import Config
        from rmsafe.core.trashinfo import write_trashinfo

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create file with today's deletion date
        (files_dir / "recent.txt").write_text("recent", encoding="utf-8")
        write_trashinfo(info_dir / "recent.txt.trashinfo", Path("/recent.txt"), datetime(2026, 4, 26, 10, 0, 0))

        monkeypatch.setenv("TRASH_DATE", "2026-04-26T10:00:00")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        # Request files older than 1 day - none match
        run(days=1, force=True)

        captured = capsys.readouterr()
        assert "Nothing to empty" in captured.out

    def test_non_interactive_warning_message(self, tmp_path: Path, monkeypatch, capsys) -> None:
        """Shows warning when prompting in non-interactive terminal without force."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        # Simulate non-TTY stdin
        monkeypatch.setattr("rmsafe.commands.empty.is_tty", lambda fd: False)

        with pytest.raises(typer.Exit) as exc_info:
            run(days=None, force=False)

        assert exc_info.value.exit_code == 1
        captured = capsys.readouterr()
        assert "non-interactive terminal" in captured.out
        assert "--force" in captured.out

    def test_confirmation_prompt_message(self, tmp_path: Path, monkeypatch) -> None:
        """Shows confirmation prompt with count."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "a.txt").write_text("a", encoding="utf-8")
        (files_dir / "b.txt").write_text("b", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        # Mock TTY check to return True
        monkeypatch.setattr("rmsafe.commands.empty.is_tty", lambda fd: True)

        # Mock Confirm.ask to return False (abort)
        with patch("rmsafe.commands.empty.Confirm.ask", return_value=False):
            with pytest.raises(typer.Exit) as exc_info:
                run(days=None, force=False)

        assert exc_info.value.exit_code == 1

    def test_abort_message_on_confirmation_declined(self, tmp_path: Path, monkeypatch, capsys) -> None:
        """Shows 'Aborted.' when user declines confirmation."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        # Mock TTY check to return True
        monkeypatch.setattr("rmsafe.commands.empty.is_tty", lambda fd: True)

        # Mock Confirm.ask to return False (decline)
        with patch("rmsafe.commands.empty.Confirm.ask", return_value=False):
            with pytest.raises(typer.Exit):
                run(days=None, force=False)

        captured = capsys.readouterr()
        assert "Aborted" in captured.out

    def test_confirmation_shows_correct_count(self, tmp_path: Path, monkeypatch) -> None:
        """Confirmation prompt shows correct file count."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        # Create 7 files
        for i in range(7):
            (files_dir / f"file{i}.txt").write_text(f"content{i}", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        monkeypatch.setattr("rmsafe.commands.empty.is_tty", lambda fd: True)

        # Capture the message passed to Confirm.ask
        captured_message = None

        def mock_confirm(message, default=False):
            nonlocal captured_message
            captured_message = message
            return False

        with patch("rmsafe.commands.empty.Confirm.ask", side_effect=mock_confirm):
            with pytest.raises(typer.Exit):
                run(days=None, force=False)

        assert captured_message is not None
        assert "7" in captured_message
        assert "item(s)" in captured_message

    def test_force_skips_confirmation_no_prompt(self, tmp_path: Path, monkeypatch, capsys) -> None:
        """force=True skips confirmation prompt entirely."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        # Should not prompt even in TTY mode
        monkeypatch.setattr("rmsafe.commands.empty.is_tty", lambda fd: True)

        # Should succeed without calling Confirm.ask
        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "Emptied 1 item(s)" in captured.out

    def test_age_filter_unavailable_warning(self, tmp_path: Path, monkeypatch, capsys) -> None:
        """Shows warning when age filter requested but metadata unavailable (macOS layout)."""
        from rmsafe.config.schema import Config

        # Simulate macOS layout (no info dir)
        monkeypatch.setattr("sys.platform", "darwin")
        trash_dir = tmp_path / ".Trash"
        trash_dir.mkdir()
        (trash_dir / "file.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=30, force=True)

        captured = capsys.readouterr()
        assert "metadata" in captured.out.lower() or "cannot age-filter" in captured.out.lower()

    def test_success_message_format(self, tmp_path: Path, capsys) -> None:
        """Success message follows expected format."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("test content here", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        output = captured.out

        # Check message structure: "Emptied N item(s), freed X."
        assert "Emptied" in output
        assert "item(s)" in output
        assert "freed" in output
        # Should end with period
        assert output.strip().endswith(".")

    def test_multiple_files_progress(self, tmp_path: Path, capsys) -> None:
        """Verify all files are processed and reported correctly."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        # Create 10 files with different sizes
        total_size = 0
        for i in range(10):
            content = f"x" * (i * 100)
            total_size += len(content)
            (files_dir / f"file{i}.txt").write_text(content, encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        assert "Emptied 10 item(s)" in captured.out
        # Size should be reported
        assert "freed" in captured.out

    def test_message_order_empty_trash(self, tmp_path: Path, capsys) -> None:
        """Verify message order: no prompt, then success summary."""
        from rmsafe.config.schema import Config

        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        (files_dir / "file.txt").write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        import rmsafe.commands.empty as empty_module
        empty_module.load_config = lambda: config

        run(days=None, force=True)

        captured = capsys.readouterr()
        output = captured.out.strip()

        # Should have exactly one output line with the summary
        assert output.startswith("Emptied")
        assert "freed" in output