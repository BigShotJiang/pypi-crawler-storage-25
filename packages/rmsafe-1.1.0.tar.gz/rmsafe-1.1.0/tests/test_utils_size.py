"""Comprehensive tests for utils/size.py following SQLite test philosophy.

SQLite tests: 100% branch coverage, edge cases, boundary conditions, failure paths.
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from rmsafe.utils.size import format_size, parse_size, path_size


class TestFormatSize:
    """format_size() - every branch, every boundary."""

    def test_zero_bytes(self) -> None:
        assert format_size(0) == "0 bytes"

    def test_one_byte(self) -> None:
        assert format_size(1) == "1 byte"

    def test_two_bytes(self) -> None:
        assert format_size(2) == "2 bytes"

    def test_1023_bytes(self) -> None:
        assert format_size(1023) == "1023 bytes"

    def test_exactly_1_kb(self) -> None:
        assert format_size(1024) == "1 KB"

    def test_1_kb_plus_1(self) -> None:
        assert format_size(1025) == "1 KB"

    def test_1_5_kb(self) -> None:
        assert format_size(1536) == "1.5 KB"

    def test_exactly_1_mb(self) -> None:
        assert format_size(1024 * 1024) == "1 MB"

    def test_5_mb(self) -> None:
        assert format_size(5 * 1024 * 1024) == "5 MB"

    def test_1_5_mb(self) -> None:
        assert format_size(int(1.5 * 1024 * 1024)) == "1.5 MB"

    def test_1_2_mb_rounding(self) -> None:
        # 1.2 MB = 1258291.2 bytes, rounds to 1.2 MB
        result = format_size(int(1.2 * 1024 * 1024))
        assert "MB" in result

    def test_exactly_1_gb(self) -> None:
        assert format_size(1024**3) == "1 GB"

    def test_2_5_gb(self) -> None:
        assert format_size(int(2.5 * 1024**3)) == "2.5 GB"

    def test_exactly_1_tb(self) -> None:
        assert format_size(1024**4) == "1 TB"

    def test_1_5_tb(self) -> None:
        assert format_size(int(1.5 * 1024**4)) == "1.5 TB"

    def test_large_value_stays_tb(self) -> None:
        # 100 TB should stay as TB, not overflow
        assert format_size(100 * 1024**4) == "100 TB"

    def test_negative_raises(self) -> None:
        with pytest.raises(ValueError, match="must be >= 0"):
            format_size(-1)

    def test_negative_large_raises(self) -> None:
        with pytest.raises(ValueError, match="must be >= 0"):
            format_size(-1024**4)


class TestParseSize:
    """parse_size() - every unit, every format, every error path."""

    def test_bytes_lower(self) -> None:
        assert parse_size("1b") == 1
        assert parse_size("1B") == 1

    def test_bytes_upper(self) -> None:
        assert parse_size("10B") == 10

    def test_kb_lower(self) -> None:
        assert parse_size("1kb") == 1024

    def test_kb_upper(self) -> None:
        assert parse_size("1KB") == 1024

    def test_kb_with_space(self) -> None:
        assert parse_size("1 KB") == 1024

    def test_kb_decimal(self) -> None:
        assert parse_size("1.5KB") == int(1.5 * 1024)

    def test_mb_lower(self) -> None:
        assert parse_size("1mb") == 1024**2

    def test_mb_upper(self) -> None:
        assert parse_size("10MB") == 10 * 1024**2

    def test_mb_decimal(self) -> None:
        assert parse_size("1.5MB") == int(1.5 * 1024**2)

    def test_gb_lower(self) -> None:
        assert parse_size("1gb") == 1024**3

    def test_gb_upper(self) -> None:
        assert parse_size("2GB") == 2 * 1024**3

    def test_gb_decimal(self) -> None:
        assert parse_size("1.5GB") == int(1.5 * 1024**3)

    def test_tb_lower(self) -> None:
        assert parse_size("1tb") == 1024**4

    def test_tb_upper(self) -> None:
        assert parse_size("2TB") == 2 * 1024**4

    def test_tb_decimal(self) -> None:
        assert parse_size("1.5TB") == int(1.5 * 1024**4)

    def test_leading_whitespace(self) -> None:
        assert parse_size("  10MB") == 10 * 1024**2

    def test_trailing_whitespace(self) -> None:
        assert parse_size("10MB  ") == 10 * 1024**2

    def test_both_whitespace(self) -> None:
        assert parse_size("  10MB  ") == 10 * 1024**2

    def test_internal_space(self) -> None:
        assert parse_size("10 MB") == 10 * 1024**2

    def test_invalid_unit(self) -> None:
        with pytest.raises(ValueError, match="look like"):
            parse_size("10PB")

    def test_invalid_format_no_unit(self) -> None:
        with pytest.raises(ValueError, match="look like"):
            parse_size("10")

    def test_invalid_format_letters(self) -> None:
        with pytest.raises(ValueError, match="look like"):
            parse_size("abc")

    def test_invalid_format_empty(self) -> None:
        with pytest.raises(ValueError, match="look like"):
            parse_size("")

    def test_invalid_format_whitespace_only(self) -> None:
        with pytest.raises(ValueError, match="look like"):
            parse_size("   ")

    def test_invalid_type_int(self) -> None:
        with pytest.raises(ValueError, match="must be a string"):
            parse_size(10)

    def test_invalid_type_float(self) -> None:
        with pytest.raises(ValueError, match="must be a string"):
            parse_size(10.0)

    def test_invalid_type_none(self) -> None:
        with pytest.raises(ValueError, match="must be a string"):
            parse_size(None)


class TestPathSize:
    """path_size() - file, symlink, directory, error paths."""

    def test_small_file(self, tmp_path: Path) -> None:
        file = tmp_path / "small.txt"
        file.write_text("hello", encoding="utf-8")
        assert path_size(file) == 5

    def test_empty_file(self, tmp_path: Path) -> None:
        file = tmp_path / "empty.txt"
        file.write_text("", encoding="utf-8")
        assert path_size(file) == 0

    def test_large_file(self, tmp_path: Path) -> None:
        file = tmp_path / "large.bin"
        data = b"x" * 10000
        file.write_bytes(data)
        assert path_size(file) == 10000

    def test_symlink_to_file(self, tmp_path: Path) -> None:
        target = tmp_path / "target.txt"
        target.write_text("content", encoding="utf-8")
        link = tmp_path / "link.txt"
        link.symlink_to(target)
        # symlink size is the length of target path string, not target content
        # for absolute paths this can be 50+ bytes depending on tmp_path length
        assert path_size(link) > 0
        assert path_size(link) == len(str(target))  # symlink stores target path

    def test_symlink_broken(self, tmp_path: Path) -> None:
        link = tmp_path / "broken_link"
        link.symlink_to(tmp_path / "nonexistent")
        assert path_size(link) > 0  # still returns symlink metadata size

    def test_empty_directory(self, tmp_path: Path) -> None:
        dir_path = tmp_path / "empty_dir"
        dir_path.mkdir()
        assert path_size(dir_path) == 0

    def test_directory_with_files(self, tmp_path: Path) -> None:
        dir_path = tmp_path / "dir"
        dir_path.mkdir()
        (dir_path / "a.txt").write_text("aaa", encoding="utf-8")
        (dir_path / "b.txt").write_text("bbb", encoding="utf-8")
        assert path_size(dir_path) == 6

    def test_nested_directory(self, tmp_path: Path) -> None:
        dir_path = tmp_path / "outer"
        inner = dir_path / "inner"
        inner.mkdir(parents=True)
        (dir_path / "top.txt").write_text("top", encoding="utf-8")
        (inner / "bottom.txt").write_text("bottom", encoding="utf-8")
        assert path_size(dir_path) == 9  # "top" (3) + "bottom" (6)

    def test_deep_nested_directory(self, tmp_path: Path) -> None:
        dir_path = tmp_path / "deep"
        current = dir_path
        for i in range(10):
            current.mkdir(exist_ok=True)
            (current / f"file{i}.txt").write_text(f"content{i}", encoding="utf-8")
            current = current / f"level{i}"
        current.mkdir()
        (current / "final.txt").write_text("final", encoding="utf-8")
        assert path_size(dir_path) > 0

    def test_directory_with_symlinks(self, tmp_path: Path) -> None:
        dir_path = tmp_path / "dir"
        dir_path.mkdir()
        (dir_path / "real.txt").write_text("real", encoding="utf-8")
        link = dir_path / "link.txt"
        link.symlink_to(dir_path / "real.txt")
        # counts symlinks but not their targets
        total = path_size(dir_path)
        assert total > 0

    def test_nonexistent_file(self, tmp_path: Path) -> None:
        file = tmp_path / "nonexistent.txt"
        # path_size handles OSError gracefully, returns 0 for missing
        # But we need to test what happens when file doesn't exist
        # Since it checks is_file() first, it should return 0
        assert path_size(file) == 0

    def test_special_file_type_returns_zero(self, tmp_path: Path) -> None:
        # Path that exists but is neither file, symlink, nor dir
        # This is hard to create on most systems, but the code handles it
        # by returning 0 for unknown types
        pass  # Can't easily test this without special filesystem objects

    def test_permission_denied_file(self, tmp_path: Path) -> None:
        file = tmp_path / "secret.txt"
        file.write_text("secret", encoding="utf-8")
        os.chmod(file, 0o000)
        try:
            # path_size catches OSError and returns 0
            # Note: on macOS, root may still read files with 0o000 permissions
            # so the result could be either 0 (OSError caught) or 6 (success)
            result = path_size(file)
            assert result in (0, 6)  # either graceful failure or actual size
        finally:
            os.chmod(file, 0o644)

    def test_permission_denied_directory(self, tmp_path: Path) -> None:
        dir_path = tmp_path / "secret_dir"
        dir_path.mkdir()
        (dir_path / "file.txt").write_text("content", encoding="utf-8")
        os.chmod(dir_path, 0o000)
        try:
            # os.walk will fail, but path_size catches and continues
            result = path_size(dir_path)
            # May return 0 or partial count depending on timing
            assert result >= 0
        finally:
            os.chmod(dir_path, 0o755)

    def test_circular_symlink_in_directory(self, tmp_path: Path) -> None:
        dir_path = tmp_path / "dir"
        dir_path.mkdir()
        link = dir_path / "circular"
        link.symlink_to(dir_path)
        # os.walk with followlinks=False handles this safely
        result = path_size(dir_path)
        assert result >= 0  # Should not hang or crash

    def test_file_in_current_directory(self, tmp_path: Path, monkeypatch) -> None:
        file = tmp_path / "local.txt"
        file.write_text("local", encoding="utf-8")
        monkeypatch.chdir(tmp_path)
        assert path_size(Path("local.txt")) == 5

    def test_absolute_path(self, tmp_path: Path) -> None:
        file = tmp_path / "abs.txt"
        file.write_text("abs", encoding="utf-8")
        assert path_size(file.absolute()) == 3