"""Comprehensive tests for core/trashinfo.py following SQLite test philosophy."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import pytest

from rmsafe.core.trashinfo import TrashInfo, write_trashinfo, parse_trashinfo


class TestTrashInfo:
    """TrashInfo - every field, every render scenario."""

    def test_basic_render(self) -> None:
        info = TrashInfo(original_path=Path("/tmp/file.txt"), deletion_date=datetime(2026, 4, 26, 10, 30, 0))
        result = info.render()
        assert "[Trash Info]" in result
        assert "Path=/tmp/file.txt" in result
        assert "DeletionDate=2026-04-26T10:30:00" in result

    def test_path_with_spaces(self) -> None:
        info = TrashInfo(original_path=Path("/tmp/file with spaces.txt"), deletion_date=datetime.now())
        result = info.render()
        assert "Path=/tmp/file with spaces.txt" in result

    def test_path_with_special_chars(self) -> None:
        info = TrashInfo(original_path=Path("/tmp/file-_test.txt"), deletion_date=datetime.now())
        result = info.render()
        assert "Path=/tmp/file-_test.txt" in result

    def test_relative_path(self) -> None:
        info = TrashInfo(original_path=Path("relative.txt"), deletion_date=datetime.now())
        result = info.render()
        assert "Path=relative.txt" in result

    def test_absolute_path(self) -> None:
        info = TrashInfo(original_path=Path("/absolute/path.txt"), deletion_date=datetime.now())
        result = info.render()
        assert "Path=/absolute/path.txt" in result

    def test_microseconds_removed(self) -> None:
        info = TrashInfo(
            original_path=Path("/tmp/file.txt"),
            deletion_date=datetime(2026, 4, 26, 10, 30, 45, 123456)
        )
        result = info.render()
        assert "DeletionDate=2026-04-26T10:30:45" in result
        assert "123456" not in result

    def test_trailing_newline(self) -> None:
        info = TrashInfo(original_path=Path("/tmp/file.txt"), deletion_date=datetime.now())
        result = info.render()
        assert result.endswith("\n")


class TestWriteTrashinfo:
    """write_trashinfo() - every scenario."""

    def test_basic_write(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        write_trashinfo(info_path, Path("/original/file.txt"), datetime(2026, 4, 26, 0, 0, 0))
        assert info_path.exists()
        content = info_path.read_text(encoding="utf-8")
        assert "[Trash Info]" in content
        assert "Path=/original/file.txt" in content

    def test_creates_parent_directory(self, tmp_path: Path) -> None:
        info_path = tmp_path / "subdir" / "nested" / "file.txt.trashinfo"
        write_trashinfo(info_path, Path("/file.txt"), datetime.now())
        assert info_path.exists()
        assert info_path.parent.is_dir()

    def test_default_datetime_is_now(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        before = datetime.now().replace(microsecond=0)
        write_trashinfo(info_path, Path("/file.txt"))
        after = datetime.now().replace(microsecond=0)
        content = info_path.read_text(encoding="utf-8")
        # Extract date from content
        for line in content.splitlines():
            if line.startswith("DeletionDate="):
                date_str = line.removeprefix("DeletionDate=")
                parsed = datetime.fromisoformat(date_str)
                assert before <= parsed <= after

    def test_overwrites_existing(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        write_trashinfo(info_path, Path("/first.txt"), datetime(2025, 1, 1))
        write_trashinfo(info_path, Path("/second.txt"), datetime(2026, 1, 1))
        content = info_path.read_text(encoding="utf-8")
        assert "Path=/second.txt" in content

    def test_absolute_path_used(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        write_trashinfo(info_path, Path("relative.txt"), datetime.now())
        content = info_path.read_text(encoding="utf-8")
        # Path should be absolute
        assert content.startswith("[Trash Info]")


class TestParseTrashinfo:
    """parse_trashinfo() - every format, every error."""

    def test_basic_parse(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        assert info.original_path == Path("/tmp/file.txt")
        assert info.deletion_date == datetime(2026, 4, 26, 10, 0, 0)

    def test_with_whitespace(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\n  Path=/tmp/file.txt  \n  DeletionDate=2026-04-26T10:00:00  \n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        assert info.original_path == Path("/tmp/file.txt")

    def test_with_extra_lines(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\nExtraField=value\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        assert info.original_path == Path("/tmp/file.txt")

    def test_with_z_timezone(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\nDeletionDate=2026-04-26T10:00:00Z\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        # Z gets converted to +00:00
        assert info.deletion_date.tzinfo is not None

    def test_with_timezone_offset(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\nDeletionDate=2026-04-26T10:00:00+05:00\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        assert info.deletion_date.tzinfo is not None

    def test_missing_path_raises(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )
        with pytest.raises(ValueError, match="Invalid trashinfo"):
            parse_trashinfo(info_path)

    def test_missing_deletion_date_raises(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\n",
            encoding="utf-8"
        )
        with pytest.raises(ValueError, match="Invalid trashinfo"):
            parse_trashinfo(info_path)

    def test_empty_file_raises(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text("", encoding="utf-8")
        with pytest.raises(ValueError, match="Invalid trashinfo"):
            parse_trashinfo(info_path)

    def test_only_header_raises(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text("[Trash Info]\n", encoding="utf-8")
        with pytest.raises(ValueError, match="Invalid trashinfo"):
            parse_trashinfo(info_path)

    def test_invalid_date_format_raises(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\nDeletionDate=invalid-date\n",
            encoding="utf-8"
        )
        with pytest.raises(ValueError):
            parse_trashinfo(info_path)

    def test_nonexistent_file_raises(self, tmp_path: Path) -> None:
        info_path = tmp_path / "nonexistent.trashinfo"
        with pytest.raises(OSError):
            parse_trashinfo(info_path)

    def test_permission_denied(self, tmp_path: Path) -> None:
        import os
        info_path = tmp_path / "secret.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )
        os.chmod(info_path, 0o000)
        try:
            with pytest.raises(OSError):
                parse_trashinfo(info_path)
        finally:
            os.chmod(info_path, 0o644)

    def test_path_with_spaces(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file with spaces.txt\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        assert info.original_path == Path("/tmp/file with spaces.txt")

    def test_multiple_path_lines_last_wins(self, tmp_path: Path) -> None:
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/first.txt\nPath=/second.txt\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        # Last Path= line wins
        assert info.original_path == Path("/second.txt")

    def test_lines_without_header(self, tmp_path: Path) -> None:
        # Header is not required, lines are parsed regardless
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "Path=/tmp/file.txt\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        assert info.original_path == Path("/tmp/file.txt")


class TestUnicodePaths:
    """Unicode path handling - Chinese, emoji, combining characters."""

    def test_chinese_path(self, tmp_path: Path) -> None:
        """Chinese characters in path should round-trip correctly."""
        info_path = tmp_path / "file.txt.trashinfo"
        chinese_path = Path("/用户/文档/测试文件.txt")
        write_trashinfo(info_path, chinese_path, datetime(2026, 4, 26, 10, 0, 0))
        info = parse_trashinfo(info_path)
        assert info.original_path == chinese_path

    def test_emoji_path(self, tmp_path: Path) -> None:
        """Emoji in path should round-trip correctly."""
        info_path = tmp_path / "file.txt.trashinfo"
        emoji_path = Path("/home/user/📁📁/file🎉.txt")
        write_trashinfo(info_path, emoji_path, datetime(2026, 4, 26, 10, 0, 0))
        info = parse_trashinfo(info_path)
        assert info.original_path == emoji_path

    def test_combining_characters_path(self, tmp_path: Path) -> None:
        """Combining characters (e.g., accents) should be preserved."""
        info_path = tmp_path / "file.txt.trashinfo"
        # e + combining acute accent = e
        combining_path = Path("/tmp/cafe/file.txt")  # "cafe" with combining accent
        write_trashinfo(info_path, combining_path, datetime(2026, 4, 26, 10, 0, 0))
        info = parse_trashinfo(info_path)
        assert info.original_path == combining_path

    def test_mixed_unicode_path(self, tmp_path: Path) -> None:
        """Mixed unicode (Chinese + emoji + ASCII) should work."""
        info_path = tmp_path / "file.txt.trashinfo"
        mixed_path = Path("/用户/Documents/📁/混合-mixed.txt")
        write_trashinfo(info_path, mixed_path, datetime(2026, 4, 26, 10, 0, 0))
        info = parse_trashinfo(info_path)
        assert info.original_path == mixed_path


class TestPathsWithNewlines:
    """Paths containing newline characters - should break format or be rejected."""

    def test_path_with_embedded_newline_breaks_format(self, tmp_path: Path) -> None:
        """Embedded newline in path breaks the .trashinfo format."""
        info_path = tmp_path / "file.txt.trashinfo"
        # Path with embedded newline - this will corrupt the format
        newline_path = Path("/tmp/file\nwith\nnewlines.txt")

        # Write the file directly (write_trashinfo would also write it)
        info_path.write_text(
            f"[Trash Info]\nPath={newline_path}\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )

        # Parsing will see the newline as line break, corrupting the path
        info = parse_trashinfo(info_path)
        # The path gets truncated at first newline
        assert info.original_path == Path("/tmp/file")

    def test_path_with_carriage_return_breaks_format(self, tmp_path: Path) -> None:
        """Carriage return in path also breaks format."""
        info_path = tmp_path / "file.txt.trashinfo"
        cr_path = "/tmp/file\rwith\rcr.txt"

        info_path.write_text(
            f"[Trash Info]\nPath={cr_path}\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )

        # The \r gets stripped by splitlines() but corrupts path
        info = parse_trashinfo(info_path)
        assert "\r" not in str(info.original_path)


class TestCRLFLineEndings:
    """CRLF line endings in .trashinfo files."""

    def test_crlf_line_endings_parse_correctly(self, tmp_path: Path) -> None:
        """Windows-style CRLF line endings should parse correctly."""
        info_path = tmp_path / "file.txt.trashinfo"
        # Write with CRLF line endings
        info_path.write_text(
            "[Trash Info]\r\nPath=/tmp/file.txt\r\nDeletionDate=2026-04-26T10:00:00\r\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        assert info.original_path == Path("/tmp/file.txt")
        assert info.deletion_date == datetime(2026, 4, 26, 10, 0, 0)

    def test_mixed_line_endings(self, tmp_path: Path) -> None:
        """Mixed LF and CRLF should still parse."""
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\r\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        assert info.original_path == Path("/tmp/file.txt")


class TestUTF8BOM:
    """UTF-8 BOM handling at file start."""

    def test_bom_at_file_start(self, tmp_path: Path) -> None:
        """UTF-8 BOM at file start should be handled gracefully."""
        info_path = tmp_path / "file.txt.trashinfo"
        # Write file with UTF-8 BOM
        bom_content = "﻿[Trash Info]\nPath=/tmp/file.txt\nDeletionDate=2026-04-26T10:00:00\n"
        info_path.write_text(bom_content, encoding="utf-8")

        # BOM becomes part of first line, so [Trash Info] becomes [Trash Info]
        # But key-value lines should still work
        info = parse_trashinfo(info_path)
        assert info.original_path == Path("/tmp/file.txt")
        assert info.deletion_date == datetime(2026, 4, 26, 10, 0, 0)

    def test_bom_path_value(self, tmp_path: Path) -> None:
        """BOM in Path value should be preserved."""
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=﻿/tmp/file.txt\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        # BOM is preserved in the path
        assert str(info.original_path).startswith("﻿")


class TestEmptyValueFields:
    """Empty value fields in .trashinfo files."""

    def test_empty_path_value_raises(self, tmp_path: Path) -> None:
        """Empty Path= value should raise ValueError."""
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=\nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )
        with pytest.raises(ValueError, match="Invalid trashinfo"):
            parse_trashinfo(info_path)

    def test_empty_deletion_date_value_raises(self, tmp_path: Path) -> None:
        """Empty DeletionDate= value should raise ValueError."""
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\nDeletionDate=\n",
            encoding="utf-8"
        )
        with pytest.raises(ValueError):
            parse_trashinfo(info_path)

    def test_whitespace_only_path_value_raises(self, tmp_path: Path) -> None:
        """Whitespace-only Path= should raise after strip."""
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=   \nDeletionDate=2026-04-26T10:00:00\n",
            encoding="utf-8"
        )
        # After strip, path becomes empty string, which is falsy
        with pytest.raises(ValueError, match="Invalid trashinfo"):
            parse_trashinfo(info_path)


class TestRoundTrip:
    """Round-trip tests: write -> parse -> data consistency."""

    def test_roundtrip_basic(self, tmp_path: Path) -> None:
        """Basic round-trip should preserve all data."""
        info_path = tmp_path / "file.txt.trashinfo"
        original_path = Path("/tmp/original/location/file.txt")
        original_date = datetime(2026, 4, 26, 14, 30, 45)

        write_trashinfo(info_path, original_path, original_date)
        parsed = parse_trashinfo(info_path)

        assert parsed.original_path == original_path
        assert parsed.deletion_date == original_date

    def test_roundtrip_unicode(self, tmp_path: Path) -> None:
        """Unicode path round-trip should preserve all characters."""
        info_path = tmp_path / "file.txt.trashinfo"
        unicode_path = Path("/用户/📁/测试🎉file.txt")
        original_date = datetime(2026, 4, 26, 10, 0, 0)

        write_trashinfo(info_path, unicode_path, original_date)
        parsed = parse_trashinfo(info_path)

        assert parsed.original_path == unicode_path
        assert parsed.deletion_date == original_date

    def test_roundtrip_spaces(self, tmp_path: Path) -> None:
        """Paths with spaces should round-trip correctly."""
        info_path = tmp_path / "file.txt.trashinfo"
        space_path = Path("/tmp/path with  multiple   spaces/file name.txt")
        original_date = datetime(2026, 4, 26, 10, 0, 0)

        write_trashinfo(info_path, space_path, original_date)
        parsed = parse_trashinfo(info_path)

        assert parsed.original_path == space_path

    def test_roundtrip_timezone_preserved(self, tmp_path: Path) -> None:
        """Timezone info should be preserved in round-trip."""
        info_path = tmp_path / "file.txt.trashinfo"
        original_path = Path("/tmp/file.txt")
        # Write a file with timezone info
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\nDeletionDate=2026-04-26T10:00:00+08:00\n",
            encoding="utf-8"
        )
        parsed = parse_trashinfo(info_path)
        assert parsed.deletion_date.tzinfo is not None

        # Now write it back
        write_trashinfo(info_path, parsed.original_path, parsed.deletion_date)
        parsed2 = parse_trashinfo(info_path)
        # Timezone should still be present (though rendered without tz by render())
        # Actually render() doesn't include timezone, so let's just verify it parsed
        assert parsed2.deletion_date.hour == 10


class TestTimestampParsing:
    """Timestamp parsing edge cases."""

    def test_timestamp_with_microseconds(self, tmp_path: Path) -> None:
        """Timestamps with microseconds should parse correctly."""
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\nDeletionDate=2026-04-26T10:30:45.123456\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        assert info.deletion_date == datetime(2026, 4, 26, 10, 30, 45, 123456)

    def test_timestamp_with_nanoseconds(self, tmp_path: Path) -> None:
        """Python's fromisoformat handles nanoseconds (truncates to microseconds)."""
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\nDeletionDate=2026-04-26T10:30:45.123456789\n",
            encoding="utf-8"
        )
        info = parse_trashinfo(info_path)
        # Python's fromisoformat truncates nanoseconds
        assert info.deletion_date.second == 45

    def test_date_only_no_time(self, tmp_path: Path) -> None:
        """Date-only format without time behavior depends on Python version."""
        info_path = tmp_path / "file.txt.trashinfo"
        info_path.write_text(
            "[Trash Info]\nPath=/tmp/file.txt\nDeletionDate=2026-04-26\n",
            encoding="utf-8"
        )
        # Python 3.11+ allows date-only in fromisoformat
        # datetime.fromisoformat("2026-04-26") returns datetime at midnight
        try:
            info = parse_trashinfo(info_path)
            assert info.deletion_date.year == 2026
            assert info.deletion_date.month == 4
            assert info.deletion_date.day == 26
        except (ValueError, TypeError):
            # Either format error or type error are acceptable on older Python
            pass