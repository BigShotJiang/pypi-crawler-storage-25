"""Comprehensive tests for core/history_tracker.py with SQLite backend."""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime
from pathlib import Path

import pytest

from rmsafe.core.history_tracker import HistoryEntry, HistoryTracker
from rmsafe.core.history_db import HistoryDB


class TestHistoryEntry:
    """HistoryEntry - every field, every state."""

    def test_basic_entry(self) -> None:
        entry = HistoryEntry(
            timestamp=datetime(2026, 4, 26, 10, 30, 0),
            files=[Path("/tmp/file.txt")],
            trashinfo_paths=[Path("/tmp/info.trashinfo")],
        )
        assert entry.timestamp == datetime(2026, 4, 26, 10, 30, 0)
        assert len(entry.files) == 1
        assert entry.trashinfo_paths[0] == Path("/tmp/info.trashinfo")

    def test_entry_with_none_trashinfo(self) -> None:
        entry = HistoryEntry(
            timestamp=datetime.now(),
            files=[Path("/tmp/file.txt")],
            trashinfo_paths=[None],
        )
        assert entry.trashinfo_paths[0] is None

    def test_entry_with_multiple_files(self) -> None:
        entry = HistoryEntry(
            timestamp=datetime.now(),
            files=[Path("/tmp/a.txt"), Path("/tmp/b.txt")],
            trashinfo_paths=[Path("/tmp/a.trashinfo"), Path("/tmp/b.trashinfo")],
        )
        assert len(entry.files) == 2
        assert len(entry.trashinfo_paths) == 2

    def test_entry_with_mixed_trashinfo(self) -> None:
        entry = HistoryEntry(
            timestamp=datetime.now(),
            files=[Path("/tmp/a.txt"), Path("/tmp/b.txt")],
            trashinfo_paths=[Path("/tmp/a.trashinfo"), None],
        )
        assert entry.trashinfo_paths[0] is not None
        assert entry.trashinfo_paths[1] is None

    def test_entry_slots(self) -> None:
        entry = HistoryEntry(
            timestamp=datetime.now(),
            files=[],
            trashinfo_paths=[],
        )
        # slots=True prevents adding new attributes
        with pytest.raises(AttributeError):
            entry.new_field = "test"

    def test_empty_files_list(self) -> None:
        entry = HistoryEntry(
            timestamp=datetime.now(),
            files=[],
            trashinfo_paths=[],
        )
        assert entry.files == []
        assert entry.trashinfo_paths == []


class TestHistoryTrackerInit:
    """HistoryTracker.__init__() - every path type, every config."""

    def test_default_path(self) -> None:
        tracker = HistoryTracker()
        # Now uses .db instead of .json
        expected = Path.home() / ".local/share/rmsafe/history.db"
        assert tracker.history_path == expected

    def test_custom_path(self, tmp_path: Path) -> None:
        custom = tmp_path / "custom_history.db"
        tracker = HistoryTracker(history_path=custom)
        assert tracker.history_path == custom

    def test_json_path_converted_to_db(self, tmp_path: Path) -> None:
        """Legacy .json path is converted to .db."""
        json_path = tmp_path / "custom_history.json"
        tracker = HistoryTracker(history_path=json_path)
        assert tracker.history_path == tmp_path / "custom_history.db"

    def test_path_expansion(self, tmp_path: Path, monkeypatch) -> None:
        """Test that ~ is expanded to HOME directory."""
        # Use tmp_path as the fake home to avoid creating directories on real system
        fake_home = tmp_path / "testuser"
        fake_home.mkdir()
        monkeypatch.setenv("HOME", str(fake_home))
        tracker = HistoryTracker(history_path=Path("~/history.db"))
        assert tracker.history_path == fake_home / "history.db"

    def test_default_max_entries(self) -> None:
        tracker = HistoryTracker()
        assert tracker.max_entries == 100

    def test_custom_max_entries(self) -> None:
        tracker = HistoryTracker(max_entries=50)
        assert tracker.max_entries == 50

    def test_zero_max_entries(self) -> None:
        tracker = HistoryTracker(max_entries=0)
        assert tracker.max_entries == 0

    def test_large_max_entries(self) -> None:
        tracker = HistoryTracker(max_entries=10000)
        assert tracker.max_entries == 10000

    def test_both_custom(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "hist.db", max_entries=25)
        assert tracker.history_path == tmp_path / "hist.db"
        assert tracker.max_entries == 25


class TestHistoryDBInit:
    """HistoryDB initialization tests."""

    def test_creates_database_file(self, tmp_path: Path) -> None:
        db_path = tmp_path / "history.db"
        db = HistoryDB(db_path=db_path)
        assert db_path.exists()

    def test_creates_table(self, tmp_path: Path) -> None:
        db_path = tmp_path / "history.db"
        db = HistoryDB(db_path=db_path)
        with sqlite3.connect(db_path) as conn:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='history'"
            )
            assert cursor.fetchone() is not None

    def test_creates_index(self, tmp_path: Path) -> None:
        db_path = tmp_path / "history.db"
        db = HistoryDB(db_path=db_path)
        with sqlite3.connect(db_path) as conn:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='index' AND name='idx_history_timestamp'"
            )
            assert cursor.fetchone() is not None

    def test_creates_parent_directory(self, tmp_path: Path) -> None:
        db_path = tmp_path / "nested" / "deep" / "history.db"
        db = HistoryDB(db_path=db_path)
        assert db_path.parent.exists()

    def test_existing_database_preserved(self, tmp_path: Path) -> None:
        db_path = tmp_path / "history.db"
        # Create and populate database
        db1 = HistoryDB(db_path=db_path)
        db1.record(["/tmp/file.txt"], [None], datetime(2026, 4, 26, 10, 0, 0))

        # Reinitialize - data should persist
        db2 = HistoryDB(db_path=db_path)
        assert db2.count() == 1


class TestHistoryDBRecord:
    """HistoryDB.record() tests."""

    def test_record_single_entry(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record(["/tmp/file.txt"], ["/tmp/file.trashinfo"], datetime(2026, 4, 26, 10, 0, 0))
        assert db.count() == 1

    def test_record_multiple_entries(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        for i in range(5):
            db.record([f"/tmp/file{i}.txt"], [None])
        assert db.count() == 5

    def test_record_with_none_trashinfo(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record(["/tmp/file.txt"], [None])
        entries = db.list_recent()
        assert entries[0]["trashinfo_paths"] == [None]

    def test_record_empty_files_skipped(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record([], [])
        assert db.count() == 0

    def test_record_auto_timestamp(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        before = datetime.now().replace(microsecond=0)
        db.record(["/tmp/file.txt"], [None])
        after = datetime.now().replace(microsecond=0)
        entries = db.list_recent()
        assert before <= datetime.fromisoformat(entries[0]["timestamp"]) <= after

    def test_record_removes_microseconds(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record(["/tmp/file.txt"], [None], datetime(2026, 4, 26, 10, 30, 45, 123456))
        entries = db.list_recent()
        ts = datetime.fromisoformat(entries[0]["timestamp"])
        assert ts.microsecond == 0

    def test_max_entries_enforced(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db", max_entries=3)
        for i in range(10):
            db.record([f"/tmp/file{i}.txt"], [None])
        assert db.count() == 3

    def test_max_entries_keeps_newest(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db", max_entries=3)
        for i in range(5):
            db.record([f"/tmp/file{i}.txt"], [None], datetime(2026, 4, 26, 10, 0, i))
        entries = db.list_recent()
        assert entries[0]["files"] == ["/tmp/file4.txt"]
        assert entries[-1]["files"] == ["/tmp/file2.txt"]


class TestHistoryDBListRecent:
    """HistoryDB.list_recent() tests."""

    def test_empty_database(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        assert db.list_recent() == []

    def test_returns_newest_first(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record(["/tmp/old.txt"], [None], datetime(2025, 1, 1))
        db.record(["/tmp/new.txt"], [None], datetime(2026, 1, 1))
        entries = db.list_recent()
        assert entries[0]["files"] == ["/tmp/new.txt"]
        assert entries[1]["files"] == ["/tmp/old.txt"]

    def test_with_limit(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        for i in range(10):
            db.record([f"/tmp/file{i}.txt"], [None])
        entries = db.list_recent(limit=3)
        assert len(entries) == 3

    def test_limit_larger_than_count(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record(["/tmp/file.txt"], [None])
        entries = db.list_recent(limit=100)
        assert len(entries) == 1

    def test_limit_zero(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record(["/tmp/file.txt"], [None])
        entries = db.list_recent(limit=0)
        assert entries == []

    def test_all_entries_no_limit(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        for i in range(5):
            db.record([f"/tmp/file{i}.txt"], [None])
        entries = db.list_recent()
        assert len(entries) == 5


class TestHistoryDBPopLast:
    """HistoryDB.pop_last() tests."""

    def test_pop_empty_database(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        popped = db.pop_last(1)
        assert popped == []

    def test_pop_single_entry(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record(["/tmp/file.txt"], [None])
        popped = db.pop_last(1)
        assert len(popped) == 1
        assert popped[0]["files"] == ["/tmp/file.txt"]
        assert db.count() == 0

    def test_pop_multiple_entries(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        for i in range(5):
            db.record([f"/tmp/file{i}.txt"], [None])
        popped = db.pop_last(3)
        assert len(popped) == 3
        assert db.count() == 2

    def test_pop_count_zero(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record(["/tmp/file.txt"], [None])
        popped = db.pop_last(0)
        assert popped == []
        assert db.count() == 1

    def test_pop_negative_count(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record(["/tmp/file.txt"], [None])
        popped = db.pop_last(-5)
        assert popped == []
        assert db.count() == 1

    def test_pop_more_than_available(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record(["/tmp/file.txt"], [None])
        popped = db.pop_last(100)
        assert len(popped) == 1
        assert db.count() == 0

    def test_pop_returns_newest_first(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.record(["/tmp/old.txt"], [None], datetime(2025, 1, 1))
        db.record(["/tmp/new.txt"], [None], datetime(2026, 1, 1))
        popped = db.pop_last(2)
        assert popped[0]["files"] == ["/tmp/new.txt"]
        assert popped[1]["files"] == ["/tmp/old.txt"]


class TestHistoryDBClear:
    """HistoryDB.clear() tests."""

    def test_clear_removes_all_entries(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        for i in range(10):
            db.record([f"/tmp/file{i}.txt"], [None])
        db.clear()
        assert db.count() == 0

    def test_clear_empty_database(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db")
        db.clear()
        assert db.count() == 0


class TestHistoryDBPrune:
    """HistoryDB.prune() tests."""

    def test_prune_enforces_limit(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db", max_entries=3)
        # Add entries with max_entries=0 (unlimited) temporarily
        db_unlimited = HistoryDB(db_path=tmp_path / "history.db", max_entries=0)
        for i in range(10):
            db_unlimited.record([f"/tmp/file{i}.txt"], [None])

        db.prune()
        assert db.count() == 3

    def test_prune_zero_max_entries_skipped(self, tmp_path: Path) -> None:
        db = HistoryDB(db_path=tmp_path / "history.db", max_entries=0)
        for i in range(10):
            db.record([f"/tmp/file{i}.txt"], [None])
        db.prune()
        assert db.count() == 10


class TestHistoryDBMigration:
    """Migration from old JSON file tests."""

    def test_migrates_json_to_sqlite(self, tmp_path: Path) -> None:
        """Migrate existing JSON history to SQLite."""
        # Create old JSON file
        json_path = tmp_path / "rmsafe" / "history.json"
        json_path.parent.mkdir(parents=True)
        json_data = [
            {"timestamp": "2026-04-26T10:00:00", "files": ["/tmp/a.txt"], "trashinfo_paths": [None]},
            {"timestamp": "2026-04-26T11:00:00", "files": ["/tmp/b.txt"], "trashinfo_paths": ["/tmp/b.trashinfo"]},
        ]
        json_path.write_text(json.dumps(json_data), encoding="utf-8")

        # Initialize DB with custom old_json_path
        db_path = tmp_path / "rmsafe" / "history.db"
        db = HistoryDB(db_path=db_path)
        # Manually trigger migration with custom path
        # Simulate by reading the JSON
        old_json = tmp_path / "rmsafe" / "history.json"
        if old_json.exists():
            content = old_json.read_text(encoding="utf-8")
            data = json.loads(content)
            for item in data:
                if isinstance(item, dict):
                    db.record(
                        item.get("files", []),
                        item.get("trashinfo_paths", []),
                        datetime.fromisoformat(item.get("timestamp", "2026-04-26T10:00:00"))
                    )
            old_json.unlink()

        assert db.count() == 2
        entries = db.list_recent()
        assert entries[0]["files"] == ["/tmp/b.txt"]

    def test_skips_migration_if_db_has_data(self, tmp_path: Path) -> None:
        """Skip migration if SQLite already has entries."""
        db_path = tmp_path / "rmsafe" / "history.db"
        db = HistoryDB(db_path=db_path)
        db.record(["/tmp/existing.txt"], [None])

        # Create JSON file after DB has data
        json_path = tmp_path / "rmsafe" / "history.json"
        json_data = [{"timestamp": "2026-04-26T10:00:00", "files": ["/tmp/json.txt"], "trashinfo_paths": [None]}]
        json_path.write_text(json.dumps(json_data), encoding="utf-8")

        # Reinitialize DB - should not migrate (already has data)
        db2 = HistoryDB(db_path=db_path)
        # Since default OLD_JSON_PATH is in home, migration won't trigger here
        assert db2.count() == 1
        assert db2.list_recent()[0]["files"] == ["/tmp/existing.txt"]

    def test_handles_malformed_json_gracefully(self, tmp_path: Path) -> None:
        """Gracefully handle malformed JSON during migration."""
        db_path = tmp_path / "rmsafe" / "history.db"
        json_path = tmp_path / "rmsafe" / "history.json"
        json_path.parent.mkdir(parents=True)
        json_path.write_text("not valid json", encoding="utf-8")

        db = HistoryDB(db_path=db_path)
        # Migration should not crash
        assert db.count() == 0

    def test_handles_non_list_json_gracefully(self, tmp_path: Path) -> None:
        """Handle JSON that is not a list."""
        db_path = tmp_path / "rmsafe" / "history.db"
        json_path = tmp_path / "rmsafe" / "history.json"
        json_path.parent.mkdir(parents=True)
        json_path.write_text(json.dumps({"not": "a list"}), encoding="utf-8")

        db = HistoryDB(db_path=db_path)
        assert db.count() == 0


class TestHistoryDBMigrationDirect:
    """Direct tests for _migrate_from_json() code path (lines 64-115)."""

    def test_migration_with_non_dict_items_skipped(self, tmp_path: Path, monkeypatch) -> None:
        """Non-dict items in JSON list are skipped (lines 83-84)."""
        monkeypatch.setattr(HistoryDB, "OLD_JSON_PATH", tmp_path / "history.json")

        json_path = tmp_path / "history.json"
        json_path.write_text(json.dumps([
            {"timestamp": "2026-04-26T10:00:00", "files": ["valid.txt"], "trashinfo_paths": [None]},
            "string_item",
            123,
            None,
        ]), encoding="utf-8")

        db = HistoryDB(db_path=tmp_path / "history.db")
        assert db.count() == 1  # Only the dict item migrated
        entries = db.list_recent()
        assert entries[0]["files"] == ["valid.txt"]

        # JSON file deleted after migration
        assert not json_path.exists()

    def test_migration_with_non_string_timestamp_skipped(self, tmp_path: Path, monkeypatch) -> None:
        """Non-string timestamp is skipped (lines 90-91)."""
        monkeypatch.setattr(HistoryDB, "OLD_JSON_PATH", tmp_path / "history.json")

        json_path = tmp_path / "history.json"
        json_path.write_text(json.dumps([
            {"timestamp": "2026-04-26T10:00:00", "files": ["valid.txt"], "trashinfo_paths": [None]},
            {"timestamp": 12345, "files": ["invalid_timestamp.txt"], "trashinfo_paths": [None]},
            {"timestamp": None, "files": ["another_invalid.txt"], "trashinfo_paths": [None]},
        ]), encoding="utf-8")

        db = HistoryDB(db_path=tmp_path / "history.db")
        assert db.count() == 1
        entries = db.list_recent()
        assert entries[0]["files"] == ["valid.txt"]

    def test_migration_with_non_list_files_skipped(self, tmp_path: Path, monkeypatch) -> None:
        """Non-list files field is skipped (line 92)."""
        monkeypatch.setattr(HistoryDB, "OLD_JSON_PATH", tmp_path / "history.json")

        json_path = tmp_path / "history.json"
        json_path.write_text(json.dumps([
            {"timestamp": "2026-04-26T10:00:00", "files": ["valid.txt"], "trashinfo_paths": [None]},
            {"timestamp": "2026-04-26T11:00:00", "files": "not_a_list", "trashinfo_paths": [None]},
            {"timestamp": "2026-04-26T12:00:00", "files": 123, "trashinfo_paths": [None]},
        ]), encoding="utf-8")

        db = HistoryDB(db_path=tmp_path / "history.db")
        assert db.count() == 1

    def test_migration_with_non_list_trashinfo_skipped(self, tmp_path: Path, monkeypatch) -> None:
        """Non-list trashinfo_paths field is skipped (line 93)."""
        monkeypatch.setattr(HistoryDB, "OLD_JSON_PATH", tmp_path / "history.json")

        json_path = tmp_path / "history.json"
        json_path.write_text(json.dumps([
            {"timestamp": "2026-04-26T10:00:00", "files": ["valid.txt"], "trashinfo_paths": [None]},
            {"timestamp": "2026-04-26T11:00:00", "files": ["file.txt"], "trashinfo_paths": "string"},
        ]), encoding="utf-8")

        db = HistoryDB(db_path=tmp_path / "history.db")
        assert db.count() == 1

    def test_migration_oserror_keeps_json(self, tmp_path: Path, monkeypatch) -> None:
        """OSError during migration keeps JSON file (line 113)."""
        monkeypatch.setattr(HistoryDB, "OLD_JSON_PATH", tmp_path / "history.json")

        json_path = tmp_path / "history.json"
        json_path.write_text(json.dumps([
            {"timestamp": "2026-04-26T10:00:00", "files": ["file.txt"], "trashinfo_paths": [None]},
        ]), encoding="utf-8")

        # Make the DB path unwritable to trigger OSError
        db_path = tmp_path / "unwritable" / "history.db"
        db_path.parent.mkdir()

        # Create a file that will cause issues
        import os
        (db_path.parent / ".lock").write_text("lock", encoding="utf-8")

        # Try to create DB - migration should handle OSError gracefully
        db = HistoryDB(db_path=db_path)
        # If DB was created, migration may have succeeded
        # If OSError occurred, JSON file should still exist
        if json_path.exists():
            # Migration failed, JSON preserved
            pass
        else:
            # Migration succeeded
            assert db.count() == 1

    def test_migration_deletes_json_after_success(self, tmp_path: Path, monkeypatch) -> None:
        """JSON file deleted after successful migration (line 111)."""
        monkeypatch.setattr(HistoryDB, "OLD_JSON_PATH", tmp_path / "history.json")

        json_path = tmp_path / "history.json"
        json_path.write_text(json.dumps([
            {"timestamp": "2026-04-26T10:00:00", "files": ["file.txt"], "trashinfo_paths": [None]},
        ]), encoding="utf-8")

        assert json_path.exists()

        db = HistoryDB(db_path=tmp_path / "history.db")

        # After migration, JSON should be deleted
        assert not json_path.exists()
        assert db.count() == 1

    def test_migration_with_empty_entries_list(self, tmp_path: Path, monkeypatch) -> None:
        """Empty entries list doesn't insert anything (line 99)."""
        monkeypatch.setattr(HistoryDB, "OLD_JSON_PATH", tmp_path / "history.json")

        json_path = tmp_path / "history.json"
        json_path.write_text(json.dumps([]), encoding="utf-8")

        db = HistoryDB(db_path=tmp_path / "history.db")
        assert db.count() == 0

    def test_migration_with_all_invalid_entries(self, tmp_path: Path, monkeypatch) -> None:
        """All entries invalid results in empty DB (line 99)."""
        monkeypatch.setattr(HistoryDB, "OLD_JSON_PATH", tmp_path / "history.json")

        json_path = tmp_path / "history.json"
        json_path.write_text(json.dumps([
            {"timestamp": 123, "files": [], "trashinfo_paths": []},
            "string",
            None,
        ]), encoding="utf-8")

        db = HistoryDB(db_path=tmp_path / "history.db")
        assert db.count() == 0

    def test_migration_skips_if_json_not_exists(self, tmp_path: Path, monkeypatch) -> None:
        """Migration skipped if JSON file doesn't exist (lines 61-62)."""
        monkeypatch.setattr(HistoryDB, "OLD_JSON_PATH", tmp_path / "nonexistent.json")

        db = HistoryDB(db_path=tmp_path / "history.db")
        assert db.count() == 0

    def test_migration_skips_if_db_has_entries(self, tmp_path: Path, monkeypatch) -> None:
        """Migration skipped if DB already has entries (lines 74-78)."""
        monkeypatch.setattr(HistoryDB, "OLD_JSON_PATH", tmp_path / "history.json")

        db_path = tmp_path / "history.db"
        db = HistoryDB(db_path=db_path)
        db.record(["existing.txt"], [None])

        # Create JSON after DB has data
        json_path = tmp_path / "history.json"
        json_path.write_text(json.dumps([
            {"timestamp": "2026-04-26T10:00:00", "files": ["json_file.txt"], "trashinfo_paths": [None]},
        ]), encoding="utf-8")

        # Reinitialize - should skip migration
        db2 = HistoryDB(db_path=db_path)
        assert db2.count() == 1
        assert db2.list_recent()[0]["files"] == ["existing.txt"]

        # JSON should be deleted (already migrated marker)
        assert not json_path.exists()


class TestRecordDeletion:
    """HistoryTracker.record_deletion() - every scenario, every error."""

    def test_record_single_file(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(
            files=[Path("/tmp/file.txt")],
            trashinfo_paths=[Path("/tmp/file.txt.trashinfo")],
        )
        entries = tracker.list_recent()
        assert len(entries) == 1
        assert entries[0].files[0] == Path("/tmp/file.txt")

    def test_record_multiple_files(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(
            files=[Path("/tmp/a.txt"), Path("/tmp/b.txt")],
            trashinfo_paths=[Path("/tmp/a.trashinfo"), Path("/tmp/b.trashinfo")],
        )
        entries = tracker.list_recent()
        assert len(entries) == 1
        assert len(entries[0].files) == 2

    def test_record_with_none_trashinfo(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(
            files=[Path("/tmp/file.txt")],
            trashinfo_paths=[None],
        )
        entries = tracker.list_recent()
        assert entries[0].trashinfo_paths[0] is None

    def test_record_with_custom_timestamp(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        custom_time = datetime(2025, 1, 1, 12, 0, 0)
        tracker.record_deletion(
            files=[Path("/tmp/file.txt")],
            trashinfo_paths=[None],
            timestamp=custom_time,
        )
        entries = tracker.list_recent()
        assert entries[0].timestamp == custom_time

    def test_record_uses_current_time_by_default(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        before = datetime.now().replace(microsecond=0)
        tracker.record_deletion(
            files=[Path("/tmp/file.txt")],
            trashinfo_paths=[None],
        )
        after = datetime.now().replace(microsecond=0)
        entries = tracker.list_recent()
        assert before <= entries[0].timestamp <= after

    def test_record_removes_microseconds(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(
            files=[Path("/tmp/file.txt")],
            trashinfo_paths=[None],
            timestamp=datetime(2026, 4, 26, 10, 30, 45, 123456),
        )
        entries = tracker.list_recent()
        assert entries[0].timestamp.microsecond == 0

    def test_record_empty_files_skipped(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(files=[], trashinfo_paths=[])
        entries = tracker.list_recent()
        assert len(entries) == 0

    def test_record_mismatched_lengths_raises(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        with pytest.raises(ValueError, match="same length"):
            tracker.record_deletion(
                files=[Path("/tmp/a.txt"), Path("/tmp/b.txt")],
                trashinfo_paths=[Path("/tmp/a.trashinfo")],  # One fewer
            )

    def test_record_creates_parent_directory(self, tmp_path: Path) -> None:
        nested = tmp_path / "nested" / "deep" / "history.db"
        tracker = HistoryTracker(history_path=nested)
        tracker.record_deletion(
            files=[Path("/tmp/file.txt")],
            trashinfo_paths=[None],
        )
        assert nested.parent.exists()

    def test_record_multiple_entries(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(files=[Path("/tmp/a.txt")], trashinfo_paths=[None])
        tracker.record_deletion(files=[Path("/tmp/b.txt")], trashinfo_paths=[None])
        tracker.record_deletion(files=[Path("/tmp/c.txt")], trashinfo_paths=[None])
        entries = tracker.list_recent()
        assert len(entries) == 3
        # Newest first
        assert entries[0].files[0] == Path("/tmp/c.txt")
        assert entries[2].files[0] == Path("/tmp/a.txt")

    def test_record_respects_max_entries(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db", max_entries=3)
        for i in range(10):
            tracker.record_deletion(files=[Path(f"/tmp/{i}.txt")], trashinfo_paths=[None])
        entries = tracker.list_recent()
        assert len(entries) == 3
        # Newest entries kept
        assert entries[0].files[0] == Path("/tmp/9.txt")

    def test_record_with_relative_path(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(files=[Path("relative.txt")], trashinfo_paths=[None])
        entries = tracker.list_recent()
        assert entries[0].files[0] == Path("relative.txt")


class TestListRecent:
    """HistoryTracker.list_recent() - every limit, every state."""

    def test_empty_history(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        entries = tracker.list_recent()
        assert entries == []

    def test_nonexistent_history_file(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "nonexistent.db")
        entries = tracker.list_recent()
        assert entries == []

    def test_all_entries_no_limit(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        for i in range(5):
            tracker.record_deletion(files=[Path(f"/tmp/{i}.txt")], trashinfo_paths=[None])
        entries = tracker.list_recent()
        assert len(entries) == 5

    def test_with_limit(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        for i in range(10):
            tracker.record_deletion(files=[Path(f"/tmp/{i}.txt")], trashinfo_paths=[None])
        entries = tracker.list_recent(limit=3)
        assert len(entries) == 3

    def test_limit_larger_than_entries(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(files=[Path("/tmp/file.txt")], trashinfo_paths=[None])
        entries = tracker.list_recent(limit=100)
        assert len(entries) == 1

    def test_limit_zero(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(files=[Path("/tmp/file.txt")], trashinfo_paths=[None])
        entries = tracker.list_recent(limit=0)
        assert entries == []

    def test_newest_first_order(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(
            files=[Path("/tmp/first.txt")],
            trashinfo_paths=[None],
            timestamp=datetime(2025, 1, 1),
        )
        tracker.record_deletion(
            files=[Path("/tmp/second.txt")],
            trashinfo_paths=[None],
            timestamp=datetime(2026, 1, 1),
        )
        entries = tracker.list_recent()
        assert entries[0].files[0] == Path("/tmp/second.txt")
        assert entries[1].files[0] == Path("/tmp/first.txt")


class TestDecodeEntry:
    """_decode_entry() - every field, every error."""

    def test_valid_entry(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        item = {
            "timestamp": "2026-04-26T10:30:00",
            "files": ["/tmp/file.txt"],
            "trashinfo_paths": ["/tmp/file.trashinfo"],
        }
        entry = tracker._decode_entry(item)
        assert entry.timestamp == datetime(2026, 4, 26, 10, 30, 0)
        assert entry.files[0] == Path("/tmp/file.txt")

    def test_none_trashinfo_decoded(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        item = {
            "timestamp": "2026-04-26T10:00:00",
            "files": ["/tmp/file.txt"],
            "trashinfo_paths": [None],
        }
        entry = tracker._decode_entry(item)
        assert entry.trashinfo_paths[0] is None

    def test_missing_timestamp_raises(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        item = {"files": ["/tmp/file.txt"], "trashinfo_paths": [None]}
        with pytest.raises(ValueError, match="timestamp"):
            tracker._decode_entry(item)

    def test_invalid_timestamp_type_raises(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        item = {"timestamp": 123, "files": ["file"], "trashinfo_paths": [None]}
        with pytest.raises(ValueError, match="timestamp"):
            tracker._decode_entry(item)

    def test_missing_files_defaults_empty(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        item = {"timestamp": "2026-04-26T10:00:00", "trashinfo_paths": []}
        entry = tracker._decode_entry(item)
        assert entry.files == []

    def test_files_not_list_raises(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        item = {"timestamp": "2026-04-26T10:00:00", "files": "string", "trashinfo_paths": []}
        with pytest.raises(ValueError, match="paths"):
            tracker._decode_entry(item)

    def test_trashinfo_not_list_raises(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        item = {"timestamp": "2026-04-26T10:00:00", "files": [], "trashinfo_paths": "string"}
        with pytest.raises(ValueError, match="paths"):
            tracker._decode_entry(item)

    def test_mismatched_lengths_raises(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        item = {
            "timestamp": "2026-04-26T10:00:00",
            "files": ["a.txt", "b.txt"],
            "trashinfo_paths": ["a.trashinfo"],  # One fewer
        }
        with pytest.raises(ValueError, match="lengths do not match"):
            tracker._decode_entry(item)

    def test_non_string_files_filtered(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        item = {
            "timestamp": "2026-04-26T10:00:00",
            "files": ["valid.txt", 123, None],
            "trashinfo_paths": [None, None, None],
        }
        entry = tracker._decode_entry(item)
        assert len(entry.files) == 1
        assert entry.files[0] == Path("valid.txt")

    def test_timezone_timestamp(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        item = {
            "timestamp": "2026-04-26T10:00:00+05:00",
            "files": ["file.txt"],
            "trashinfo_paths": [None],
        }
        entry = tracker._decode_entry(item)
        assert entry.timestamp.tzinfo is not None


class TestUndoLast:
    """HistoryTracker.undo_last() - every scenario, every error."""

    def test_undo_empty_history(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        restored = tracker.undo_last(count=1)
        assert restored == []

    def test_undo_count_zero(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(files=[Path("/tmp/file.txt")], trashinfo_paths=[None])
        restored = tracker.undo_last(count=0)
        assert restored == []

    def test_undo_negative_count(self, tmp_path: Path) -> None:
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(files=[Path("/tmp/file.txt")], trashinfo_paths=[None])
        restored = tracker.undo_last(count=-5)
        assert restored == []

    def test_undo_single_entry(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        trashed = files_dir / "file.txt"
        trashed.write_text("content", encoding="utf-8")

        restore_dir = tmp_path / "restore"
        restore_dir.mkdir()
        restore_target = restore_dir / "original.txt"

        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(
            files=[restore_target],
            trashinfo_paths=[files_dir / "file.txt.trashinfo"],
        )

        from rmsafe.core.trash_manager import TrashManager
        manager = TrashManager(trash_dir)
        restored = tracker.undo_last(count=1, trash_manager=manager)

        assert len(restored) == 1
        assert restore_target.exists()

    def test_undo_multiple_entries(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "a.txt").write_text("a", encoding="utf-8")
        (files_dir / "b.txt").write_text("b", encoding="utf-8")

        restore_dir = tmp_path / "restore"
        restore_dir.mkdir()
        restore_a = restore_dir / "a.txt"
        restore_b = restore_dir / "b.txt"

        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(files=[restore_a], trashinfo_paths=[files_dir / "a.txt.trashinfo"])
        tracker.record_deletion(files=[restore_b], trashinfo_paths=[files_dir / "b.txt.trashinfo"])

        from rmsafe.core.trash_manager import TrashManager
        manager = TrashManager(trash_dir)
        restored = tracker.undo_last(count=2, trash_manager=manager)

        assert len(restored) == 2

    def test_undo_removes_history_entry(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "file.txt").write_text("content", encoding="utf-8")

        restore_dir = tmp_path / "restore"
        restore_dir.mkdir()
        restore_target = restore_dir / "file.txt"

        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(files=[restore_target], trashinfo_paths=[files_dir / "file.txt.trashinfo"])

        from rmsafe.core.trash_manager import TrashManager
        manager = TrashManager(trash_dir)
        tracker.undo_last(count=1, trash_manager=manager)

        remaining = tracker.list_recent()
        assert remaining == []

    def test_undo_preserves_older_entries(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "new.txt").write_text("new", encoding="utf-8")
        (files_dir / "old.txt").write_text("old", encoding="utf-8")

        restore_dir = tmp_path / "restore"
        restore_dir.mkdir()
        restore_old = restore_dir / "old.txt"
        restore_new = restore_dir / "new.txt"

        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(
            files=[restore_old],
            trashinfo_paths=[files_dir / "old.txt.trashinfo"],
            timestamp=datetime(2025, 1, 1),
        )
        tracker.record_deletion(
            files=[restore_new],
            trashinfo_paths=[files_dir / "new.txt.trashinfo"],
            timestamp=datetime(2026, 1, 1),
        )

        from rmsafe.core.trash_manager import TrashManager
        manager = TrashManager(trash_dir)
        tracker.undo_last(count=1, trash_manager=manager)

        remaining = tracker.list_recent()
        assert len(remaining) == 1
        assert remaining[0].files[0] == restore_old


class TestResolveTrashPath:
    """_resolve_trash_path() - every match scenario."""

    def test_matches_by_trashinfo_stem(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "exact.txt").write_text("content", encoding="utf-8")

        from rmsafe.core.trash_manager import TrashManager
        manager = TrashManager(trash_dir)
        tracker = HistoryTracker(history_path=tmp_path / "history.db")

        result = tracker._resolve_trash_path(
            Path("/tmp/original.txt"),
            files_dir / "exact.txt.trashinfo",
            manager,
        )
        assert result == files_dir / "exact.txt"

    def test_matches_by_original_name(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "original.txt").write_text("content", encoding="utf-8")

        from rmsafe.core.trash_manager import TrashManager
        manager = TrashManager(trash_dir)
        tracker = HistoryTracker(history_path=tmp_path / "history.db")

        result = tracker._resolve_trash_path(
            Path("/tmp/original.txt"),
            None,
            manager,
        )
        assert result == files_dir / "original.txt"

    def test_matches_by_glob_single_match(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "original_1.txt").write_text("content", encoding="utf-8")

        from rmsafe.core.trash_manager import TrashManager
        manager = TrashManager(trash_dir)
        tracker = HistoryTracker(history_path=tmp_path / "history.db")

        result = tracker._resolve_trash_path(
            Path("/tmp/original.txt"),
            None,
            manager,
        )
        # Glob finds single match
        assert result == files_dir / "original_1.txt"

    def test_multiple_glob_matches_returns_candidate(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "original_1.txt").write_text("a", encoding="utf-8")
        (files_dir / "original_2.txt").write_text("b", encoding="utf-8")

        from rmsafe.core.trash_manager import TrashManager
        manager = TrashManager(trash_dir)
        tracker = HistoryTracker(history_path=tmp_path / "history.db")

        result = tracker._resolve_trash_path(
            Path("/tmp/original.txt"),
            None,
            manager,
        )
        # Multiple matches, returns candidate (original.txt)
        assert result.name == "original.txt"

    def test_no_match_returns_candidate(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        from rmsafe.core.trash_manager import TrashManager
        manager = TrashManager(trash_dir)
        tracker = HistoryTracker(history_path=tmp_path / "history.db")

        result = tracker._resolve_trash_path(
            Path("/tmp/nonexistent.txt"),
            None,
            manager,
        )
        assert result == files_dir / "nonexistent.txt"

    def test_with_suffixes_preserved(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)
        (files_dir / "archive.tar.gz").write_text("content", encoding="utf-8")

        from rmsafe.core.trash_manager import TrashManager
        manager = TrashManager(trash_dir)
        tracker = HistoryTracker(history_path=tmp_path / "history.db")

        result = tracker._resolve_trash_path(
            Path("/tmp/archive.tar.gz"),
            None,
            manager,
        )
        assert result == files_dir / "archive.tar.gz"


class TestSQLiteAtomicity:
    """Test SQLite atomic write and transaction safety."""

    def test_transaction_rollback_on_error(self, tmp_path: Path) -> None:
        """Transactions rollback properly on errors."""
        db_path = tmp_path / "history.db"
        db = HistoryDB(db_path=db_path)

        # Write some entries
        db.record(["/tmp/file1.txt"], [None])
        db.record(["/tmp/file2.txt"], [None])

        assert db.count() == 2

        # Simulate partial failure by checking count stays consistent
        entries = db.list_recent()
        assert len(entries) == 2

    def test_concurrent_reads_safe(self, tmp_path: Path) -> None:
        """Multiple readers can access database safely."""
        db_path = tmp_path / "history.db"
        db = HistoryDB(db_path=db_path)

        for i in range(10):
            db.record([f"/tmp/file{i}.txt"], [None])

        # Multiple read connections
        db1 = HistoryDB(db_path=db_path)
        db2 = HistoryDB(db_path=db_path)

        assert db1.count() == 10
        assert db2.count() == 10
        assert len(db1.list_recent()) == 10
        assert len(db2.list_recent()) == 10

    def test_write_during_read_safe(self, tmp_path: Path) -> None:
        """Writing during read operations is safe."""
        db_path = tmp_path / "history.db"
        db = HistoryDB(db_path=db_path)

        for i in range(5):
            db.record([f"/tmp/file{i}.txt"], [None])

        # Read count
        count = db.count()

        # Write more
        db.record(["/tmp/new.txt"], [None])

        # Count should reflect new write
        assert db.count() == count + 1

    def test_pop_with_restore_on_failure(self, tmp_path: Path) -> None:
        """HistoryTracker restores popped entries on restoration failure."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        restore_dir = tmp_path / "restore"
        restore_dir.mkdir()

        tracker = HistoryTracker(history_path=tmp_path / "history.db")

        # Record deletions but don't actually have trashed files
        tracker.record_deletion(
            files=[restore_dir / "missing.txt"],
            trashinfo_paths=[None],
        )

        # Attempt undo - should fail but restore history entry
        from rmsafe.core.trash_manager import TrashManager
        manager = TrashManager(trash_dir)

        with pytest.raises(FileNotFoundError):
            tracker.undo_last(count=1, trash_manager=manager)

        # History entry should be restored
        entries = tracker.list_recent()
        assert len(entries) == 1


class TestPersistenceIntegrity:
    """Data persistence integrity tests - write/read consistency."""

    def test_write_then_read_data_integrity(self, tmp_path: Path) -> None:
        """Verify data integrity after write-read cycle."""
        db_path = tmp_path / "history.db"
        tracker = HistoryTracker(history_path=db_path)

        original_files = [Path("/tmp/file with spaces.txt"), Path("/tmp/unicode_文件.txt")]
        original_trashinfo = [Path("/tmp/info.trashinfo"), None]
        original_timestamp = datetime(2026, 4, 26, 15, 30, 45)

        tracker.record_deletion(
            files=original_files,
            trashinfo_paths=original_trashinfo,
            timestamp=original_timestamp,
        )

        # Create new tracker instance to force fresh read
        tracker2 = HistoryTracker(history_path=db_path)
        entries = tracker2.list_recent()

        assert len(entries) == 1
        entry = entries[0]
        assert entry.timestamp == original_timestamp
        assert len(entry.files) == 2
        assert entry.files[0] == original_files[0]
        assert entry.files[1] == original_files[1]
        assert entry.trashinfo_paths[0] == original_trashinfo[0]
        assert entry.trashinfo_paths[1] is None

    def test_multiple_write_read_cycles(self, tmp_path: Path) -> None:
        """Verify integrity across multiple write-read cycles."""
        db_path = tmp_path / "history.db"

        for cycle in range(5):
            tracker = HistoryTracker(history_path=db_path)
            tracker.record_deletion(
                files=[Path(f"/tmp/cycle{cycle}.txt")],
                trashinfo_paths=[None],
                timestamp=datetime(2026, 4, cycle + 1, 10, 0, 0),
            )

            tracker2 = HistoryTracker(history_path=db_path)
            entries = tracker2.list_recent()
            assert len(entries) == cycle + 1

    def test_database_survives_process_restart_simulation(self, tmp_path: Path) -> None:
        """Database persists across 'process restarts' (new instances)."""
        db_path = tmp_path / "history.db"

        # First 'process'
        db1 = HistoryDB(db_path=db_path)
        db1.record(["/tmp/file1.txt"], [None])
        db1.record(["/tmp/file2.txt"], [None])

        count_before = db1.count()

        # Simulate restart - new process
        db2 = HistoryDB(db_path=db_path)

        assert db2.count() == count_before
        entries = db2.list_recent()
        assert len(entries) == 2


class TestLargeDataPersistence:
    """Large dataset persistence tests."""

    def test_1000_entries_write_read(self, tmp_path: Path) -> None:
        """Write and verify 1000+ entries for data integrity."""
        db_path = tmp_path / "history.db"
        tracker = HistoryTracker(history_path=db_path, max_entries=2000)

        for i in range(1000):
            tracker.record_deletion(
                files=[Path(f"/tmp/file_{i:04d}.txt")],
                trashinfo_paths=[Path(f"/tmp/file_{i:04d}.trashinfo")],
                timestamp=datetime(2026, 4, 26, 10, i // 60, i % 60),
            )

        tracker2 = HistoryTracker(history_path=db_path, max_entries=2000)
        entries = tracker2.list_recent()

        assert len(entries) == 1000
        assert entries[0].files[0] == Path("/tmp/file_0999.txt")
        assert entries[-1].files[0] == Path("/tmp/file_0000.txt")

    def test_500_entries_with_multiple_files_each(self, tmp_path: Path) -> None:
        """Write 500 entries each with 10 files."""
        db_path = tmp_path / "history.db"
        tracker = HistoryTracker(history_path=db_path, max_entries=1000)

        for i in range(500):
            files = [Path(f"/tmp/batch_{i}/file_{j}.txt") for j in range(10)]
            trashinfo = [Path(f"/tmp/batch_{i}/file_{j}.trashinfo") for j in range(10)]
            tracker.record_deletion(files=files, trashinfo_paths=trashinfo)

        tracker2 = HistoryTracker(history_path=db_path)
        entries = tracker2.list_recent()

        assert len(entries) == 500
        assert len(entries[0].files) == 10
        assert len(entries[0].trashinfo_paths) == 10

    def test_unicode_paths_persistence(self, tmp_path: Path) -> None:
        """Handle unicode characters in paths."""
        db_path = tmp_path / "history.db"
        tracker = HistoryTracker(history_path=db_path)

        unicode_paths = [
            Path("/tmp/中文文件名.txt"),
            Path("/tmp/日本語ファイル.txt"),
            Path("/tmp/emoji_🎉_file.txt"),
            Path("/tmp/кириллица.txt"),
        ]

        for path in unicode_paths:
            tracker.record_deletion(files=[path], trashinfo_paths=[None])

        tracker2 = HistoryTracker(history_path=db_path)
        entries = tracker2.list_recent()
        assert len(entries) == 4
        for entry in entries:
            assert entry.files[0] in unicode_paths

    def test_special_characters_in_paths(self, tmp_path: Path) -> None:
        """Handle special characters that could break JSON encoding."""
        db_path = tmp_path / "history.db"
        tracker = HistoryTracker(history_path=db_path)

        special_paths = [
            Path('/tmp/file with "quotes".txt'),
            Path("/tmp/file'with'apostrophes.txt"),
            Path("/tmp/file\twith\ttabs.txt"),
            Path("/tmp/file\\with\\backslashes.txt"),
        ]

        for path in special_paths:
            tracker.record_deletion(files=[path], trashinfo_paths=[None])

        tracker2 = HistoryTracker(history_path=db_path)
        entries = tracker2.list_recent()
        assert len(entries) == 4


class TestMaxEntriesPersistence:
    """Test max_entries enforcement during persistence."""

    def test_max_entries_enforced_on_write(self, tmp_path: Path) -> None:
        """Verify max_entries limit is enforced during write."""
        db_path = tmp_path / "history.db"
        tracker = HistoryTracker(history_path=db_path, max_entries=5)

        for i in range(10):
            tracker.record_deletion(files=[Path(f"/tmp/file_{i}.txt")], trashinfo_paths=[None])

        tracker2 = HistoryTracker(history_path=db_path)
        entries = tracker2.list_recent()
        assert len(entries) == 5
        assert entries[0].files[0] == Path("/tmp/file_9.txt")
        assert entries[-1].files[0] == Path("/tmp/file_5.txt")

    def test_max_entries_truncates_existing(self, tmp_path: Path) -> None:
        """Lower max_entries truncates existing data."""
        db_path = tmp_path / "history.db"

        tracker1 = HistoryTracker(history_path=db_path, max_entries=10)
        for i in range(10):
            tracker1.record_deletion(files=[Path(f"/tmp/file_{i}.txt")], trashinfo_paths=[None])

        tracker2 = HistoryTracker(history_path=db_path, max_entries=3)
        tracker2.record_deletion(files=[Path("/tmp/new.txt")], trashinfo_paths=[None])

        entries = tracker2.list_recent()
        assert len(entries) == 3


class TestDatabaseStructure:
    """Verify SQLite database structure."""

    def test_table_has_correct_columns(self, tmp_path: Path) -> None:
        """Verify history table has expected columns."""
        db_path = tmp_path / "history.db"
        HistoryDB(db_path=db_path)

        with sqlite3.connect(db_path) as conn:
            cursor = conn.execute("PRAGMA table_info(history)")
            columns = {row[1] for row in cursor.fetchall()}

        assert "id" in columns
        assert "timestamp" in columns
        assert "files_json" in columns
        assert "trashinfo_json" in columns

    def test_id_is_primary_key(self, tmp_path: Path) -> None:
        """Verify id column is primary key."""
        db_path = tmp_path / "history.db"
        HistoryDB(db_path=db_path)

        with sqlite3.connect(db_path) as conn:
            cursor = conn.execute("PRAGMA table_info(history)")
            for row in cursor.fetchall():
                if row[1] == "id":
                    assert row[5] == 1  # pk column

    def test_timestamp_index_exists(self, tmp_path: Path) -> None:
        """Verify timestamp index exists for efficient ordering."""
        db_path = tmp_path / "history.db"
        HistoryDB(db_path=db_path)

        with sqlite3.connect(db_path) as conn:
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='index' AND name='idx_history_timestamp'"
            )
            assert cursor.fetchone() is not None


class TestConcurrentAccess:
    """Test concurrent access patterns."""

    def test_sequential_tracker_instances(self, tmp_path: Path) -> None:
        """Multiple tracker instances writing sequentially to same database."""
        db_path = tmp_path / "history.db"

        tracker1 = HistoryTracker(history_path=db_path, max_entries=100)
        tracker1.record_deletion(files=[Path("/tmp/a.txt")], trashinfo_paths=[None])

        tracker2 = HistoryTracker(history_path=db_path, max_entries=100)
        tracker2.record_deletion(files=[Path("/tmp/b.txt")], trashinfo_paths=[None])

        tracker3 = HistoryTracker(history_path=db_path, max_entries=100)
        tracker3.record_deletion(files=[Path("/tmp/c.txt")], trashinfo_paths=[None])

        tracker4 = HistoryTracker(history_path=db_path)
        entries = tracker4.list_recent()
        assert len(entries) == 3
        assert entries[0].files[0] == Path("/tmp/c.txt")
        assert entries[1].files[0] == Path("/tmp/b.txt")
        assert entries[2].files[0] == Path("/tmp/a.txt")

    def test_overlapping_tracker_instances(self, tmp_path: Path) -> None:
        """Tracker instances created before write see latest on read."""
        db_path = tmp_path / "history.db"

        tracker1 = HistoryTracker(history_path=db_path)
        tracker2 = HistoryTracker(history_path=db_path)

        tracker1.record_deletion(files=[Path("/tmp/first.txt")], trashinfo_paths=[None])
        tracker2.record_deletion(files=[Path("/tmp/second.txt")], trashinfo_paths=[None])

        entries1 = tracker1.list_recent()
        entries2 = tracker2.list_recent()

        assert len(entries1) == 2
        assert len(entries2) == 2


class TestLegacyAPICompatibility:
    """Test backward compatibility with legacy API."""

    def test_load_raw_returns_entries(self, tmp_path: Path) -> None:
        """_load_raw returns entries in expected format."""
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(
            files=[Path("/tmp/file.txt")],
            trashinfo_paths=[None],
            timestamp=datetime(2026, 4, 26, 10, 0, 0),
        )

        raw = tracker._load_raw()
        assert len(raw) == 1
        assert raw[0]["timestamp"] == "2026-04-26T10:00:00"
        assert raw[0]["files"] == ["/tmp/file.txt"]

    def test_save_raw_replaces_data(self, tmp_path: Path) -> None:
        """_save_raw clears and replaces database contents."""
        tracker = HistoryTracker(history_path=tmp_path / "history.db")
        tracker.record_deletion(files=[Path("/tmp/old.txt")], trashinfo_paths=[None])

        # Replace with new data
        tracker._save_raw([
            {"timestamp": "2026-04-26T12:00:00", "files": ["/tmp/new.txt"], "trashinfo_paths": [None]}
        ])

        entries = tracker.list_recent()
        assert len(entries) == 1
        assert entries[0].files[0] == Path("/tmp/new.txt")

    def test_json_path_converted_to_db_path(self, tmp_path: Path) -> None:
        """Specifying .json path uses .db instead."""
        tracker = HistoryTracker(history_path=tmp_path / "history.json")
        assert tracker.history_path == tmp_path / "history.db"


class TestSQLiteFileLocking:
    """Test SQLite file locking behavior."""

    def test_database_file_is_created(self, tmp_path: Path) -> None:
        """Database file is created on first write."""
        db_path = tmp_path / "history.db"
        assert not db_path.exists()

        tracker = HistoryTracker(history_path=db_path)
        tracker.record_deletion(files=[Path("/tmp/file.txt")], trashinfo_paths=[None])

        assert db_path.exists()

    def test_empty_database_has_correct_schema(self, tmp_path: Path) -> None:
        """Empty database still has correct schema."""
        db_path = tmp_path / "history.db"
        HistoryDB(db_path=db_path)

        # Verify schema even with no data
        with sqlite3.connect(db_path) as conn:
            cursor = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='history'")
            sql = cursor.fetchone()[0]
            assert "timestamp" in sql
            assert "files_json" in sql