"""Comprehensive tests for commands/status.py following SQLite test philosophy."""
from __future__ import annotations

from datetime import datetime, timedelta
from io import StringIO
from pathlib import Path
import sys

import pytest

import rmsafe.commands.status
from rmsafe.commands.status import run, _collect_stats, _format_time
from rmsafe.config.schema import Config
from rmsafe.core.trash_manager import TrashManager
from rmsafe.core.trashinfo import write_trashinfo


class TestFormatTime:
    """_format_time() - every input type."""

    def test_none_returns_dash(self) -> None:
        result = _format_time(None)
        assert result == "-"

    def test_datetime_format(self) -> None:
        dt = datetime(2024, 6, 15, 14, 30, 45, 123456)
        result = _format_time(dt)
        assert result == "2024-06-15 14:30:45"

    def test_datetime_without_microseconds(self) -> None:
        dt = datetime(2024, 1, 1, 0, 0, 0)
        result = _format_time(dt)
        assert result == "2024-01-01 00:00:00"


class TestCollectStats:
    """_collect_stats() - every trash state."""

    def test_empty_trash_no_files_dir(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        manager = TrashManager(trash_dir)

        count, size, oldest, newest = _collect_stats(manager)

        assert count == 0
        assert size == 0
        assert oldest is None
        assert newest is None

    def test_empty_trash_with_files_dir(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        (trash_dir / "files").mkdir(parents=True)
        manager = TrashManager(trash_dir)

        count, size, oldest, newest = _collect_stats(manager)

        assert count == 0
        assert size == 0
        assert oldest is None
        assert newest is None

    def test_single_file_with_info(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        file_path = files_dir / "test.txt"
        file_path.write_text("hello world", encoding="utf-8")

        deletion_time = datetime(2024, 6, 15, 10, 30, 0)
        write_trashinfo(info_dir / "test.txt.trashinfo", Path("/original/test.txt"), deletion_time)

        manager = TrashManager(trash_dir)
        count, size, oldest, newest = _collect_stats(manager)

        assert count == 1
        assert size == 11  # "hello world" is 11 bytes
        assert oldest == deletion_time
        assert newest == deletion_time

    def test_multiple_files_with_info(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create multiple files with different timestamps
        times = [
            datetime(2024, 6, 10, 10, 0, 0),
            datetime(2024, 6, 15, 14, 30, 0),
            datetime(2024, 6, 12, 9, 0, 0),
        ]

        for i, t in enumerate(times):
            file_path = files_dir / f"file{i}.txt"
            file_path.write_text(f"content {i}", encoding="utf-8")
            write_trashinfo(info_dir / f"file{i}.txt.trashinfo", Path(f"/original/file{i}.txt"), t)

        manager = TrashManager(trash_dir)
        count, size, oldest, newest = _collect_stats(manager)

        assert count == 3
        assert oldest == datetime(2024, 6, 10, 10, 0, 0)
        assert newest == datetime(2024, 6, 15, 14, 30, 0)

    def test_missing_info_file(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # File with info
        file1 = files_dir / "with_info.txt"
        file1.write_text("content", encoding="utf-8")
        write_trashinfo(info_dir / "with_info.txt.trashinfo", Path("/original/with_info.txt"), datetime(2024, 6, 15, 10, 0, 0))

        # File without info (orphaned)
        file2 = files_dir / "no_info.txt"
        file2.write_text("orphaned", encoding="utf-8")

        manager = TrashManager(trash_dir)
        count, size, oldest, newest = _collect_stats(manager)

        # Both files counted
        assert count == 2
        # Size includes both
        assert size == 7 + 8  # "content" + "orphaned"
        # Timestamps only from file with info
        assert oldest == datetime(2024, 6, 15, 10, 0, 0)
        assert newest == datetime(2024, 6, 15, 10, 0, 0)

    def test_all_files_missing_info(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        # Multiple files, none with info
        for i in range(3):
            file_path = files_dir / f"file{i}.txt"
            file_path.write_text(f"content {i}", encoding="utf-8")

        manager = TrashManager(trash_dir)
        count, size, oldest, newest = _collect_stats(manager)

        assert count == 3
        assert size > 0
        assert oldest is None
        assert newest is None

    def test_invalid_info_file(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        file1 = files_dir / "valid.txt"
        file1.write_text("valid", encoding="utf-8")
        write_trashinfo(info_dir / "valid.txt.trashinfo", Path("/original/valid.txt"), datetime(2024, 6, 15, 10, 0, 0))

        file2 = files_dir / "invalid.txt"
        file2.write_text("invalid", encoding="utf-8")
        # Invalid info file (missing required fields)
        (info_dir / "invalid.txt.trashinfo").write_text("[Trash Info]\n", encoding="utf-8")

        manager = TrashManager(trash_dir)
        count, size, oldest, newest = _collect_stats(manager)

        assert count == 2
        # Only valid file's timestamp is captured
        assert oldest == datetime(2024, 6, 15, 10, 0, 0)
        assert newest == datetime(2024, 6, 15, 10, 0, 0)

    def test_directory_size_calculation(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create a directory in trash
        dir_path = files_dir / "mydir"
        dir_path.mkdir()
        (dir_path / "file1.txt").write_text("aaaa", encoding="utf-8")  # 4 bytes
        (dir_path / "file2.txt").write_text("bbbbbb", encoding="utf-8")  # 6 bytes
        # Total: 10 bytes

        write_trashinfo(info_dir / "mydir.trashinfo", Path("/original/mydir"), datetime(2024, 6, 15, 10, 0, 0))

        manager = TrashManager(trash_dir)
        count, size, oldest, newest = _collect_stats(manager)

        assert count == 1
        assert size == 10  # Total of all files in directory

    def test_symlink_size(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create a symlink
        link = files_dir / "link.txt"
        link.symlink_to("/some/target")

        write_trashinfo(info_dir / "link.txt.trashinfo", Path("/original/link.txt"), datetime(2024, 6, 15, 10, 0, 0))

        manager = TrashManager(trash_dir)
        count, size, oldest, newest = _collect_stats(manager)

        assert count == 1
        # Symlink size is small (size of link itself, not target)
        assert size >= 0  # Just verify it doesn't crash

    def test_sorted_by_name_case_insensitive(self, tmp_path: Path) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create files with various cases - timestamps should reflect order processed
        names = ["Zebra.txt", "apple.txt", "Banana.txt"]
        base_time = datetime(2024, 6, 15, 10, 0, 0)

        for i, name in enumerate(names):
            file_path = files_dir / name
            file_path.write_text(f"content {i}", encoding="utf-8")
            write_trashinfo(info_dir / f"{name}.trashinfo", Path(f"/original/{name}"), base_time + timedelta(hours=i))

        manager = TrashManager(trash_dir)
        count, size, oldest, newest = _collect_stats(manager)

        assert count == 3
        # Processing order is sorted alphabetically by lowercase name
        # apple.txt (hour 0), Banana.txt (hour 1), Zebra.txt (hour 2)
        # But timestamps are from their actual info files
        assert oldest == base_time  # apple.txt timestamp
        assert newest == base_time + timedelta(hours=2)  # Zebra.txt timestamp


class TestRun:
    """run() - every output scenario."""

    def test_empty_trash_output(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        trash_dir.mkdir(parents=True)
        config = Config()
        config.trash.location = trash_dir

        # Mock load_config to return test config
        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        # Capture output
        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        # New Panel format
        assert "Empty trash" in result
        assert "undo: nothing to restore" in result

    def test_single_file_output(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        file_path = files_dir / "document.txt"
        file_path.write_text("Hello, World!", encoding="utf-8")  # 13 bytes

        deletion_time = datetime(2024, 6, 15, 10, 30, 0)
        write_trashinfo(info_dir / "document.txt.trashinfo", Path("/home/user/document.txt"), deletion_time)

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        # New Panel format
        assert "1 file" in result  # Singular
        assert "13 bytes" in result
        assert "undo available" in result
        # Path is displayed
        assert "path:" in result

    def test_multiple_files_output(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        files_data = [
            ("file1.txt", "aaaa", datetime(2024, 6, 10, 9, 0, 0)),  # 4 bytes
            ("file2.txt", "bbbbbb", datetime(2024, 6, 12, 15, 30, 0)),  # 6 bytes
            ("file3.txt", "cccccccc", datetime(2024, 6, 15, 10, 0, 0)),  # 8 bytes
        ]

        for name, content, t in files_data:
            (files_dir / name).write_text(content, encoding="utf-8")
            write_trashinfo(info_dir / f"{name}.trashinfo", Path(f"/original/{name}"), t)

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        # New Panel format
        assert "3 files" in result  # Plural
        assert "18 bytes" in result

    def test_large_size_formatting(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create file with ~2KB content
        file_path = files_dir / "large.txt"
        file_path.write_text("x" * 2048, encoding="utf-8")

        write_trashinfo(info_dir / "large.txt.trashinfo", Path("/original/large.txt"), datetime(2024, 6, 15, 10, 0, 0))

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        # New Panel format - format_size() shows "2 KB"
        assert "1 file" in result
        assert "2 KB" in result

    def test_very_large_size_formatting(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create file with ~2MB content
        file_path = files_dir / "huge.bin"
        file_path.write_bytes(b"\x00" * (2 * 1024 * 1024))

        write_trashinfo(info_dir / "huge.bin.trashinfo", Path("/original/huge.bin"), datetime(2024, 6, 15, 10, 0, 0))

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        # New Panel format - format_size() shows "2.0 MB" or similar
        assert "1 file" in result
        assert "2 MB" in result or "2.0 MB" in result

    def test_missing_info_oldest_newest_dash(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        files_dir.mkdir(parents=True)

        # File without info
        file_path = files_dir / "orphan.txt"
        file_path.write_text("orphaned file", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        # New Panel format - file still counted, but no time info shown
        assert "1 file" in result
        # When no timestamps, oldest/newest lines are not shown

    def test_output_with_colors_never(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        trash_dir.mkdir(parents=True)
        config = Config()
        config.trash.location = trash_dir
        config.output.color = "never"

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        # New Panel format - just verify it runs without crashing
        # Rich may still output Panel borders even without ANSI colors
        assert "Empty trash" in result

    def test_trash_path_displayed(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "CustomTrash"
        trash_dir.mkdir(parents=True)
        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        # New Panel format - path shown as "path: {path}"
        assert "path:" in result
        assert "CustomTrash" in result


class TestMacStyleTrash:
    """macOS-style trash (no info directory)."""

    @pytest.mark.skipif(sys.platform != "darwin", reason="macOS .Trash layout only works on Darwin")
    def test_mac_style_trash_no_info_dir(self, tmp_path: Path, monkeypatch) -> None:
        # Simulate macOS .Trash directory (no info subdir)
        trash_dir = tmp_path / ".Trash"
        trash_dir.mkdir(parents=True)

        file_path = trash_dir / "file.txt"
        file_path.write_text("content", encoding="utf-8")

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        assert "1 file" in result
        # No timestamps without info files


class TestEdgeCases:
    """Edge cases and unusual scenarios."""

    def test_special_characters_in_filename(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # File with spaces and special chars
        file_path = files_dir / "file with spaces #2.txt"
        file_path.write_text("content", encoding="utf-8")

        write_trashinfo(
            info_dir / "file with spaces #2.txt.trashinfo",
            Path("/original/file with spaces #2.txt"),
            datetime(2024, 6, 15, 10, 0, 0),
        )

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        assert "1 file" in result

    def test_unicode_filename(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        file_path = files_dir / "你好世界.txt"
        file_path.write_text("unicode content", encoding="utf-8")

        write_trashinfo(
            info_dir / "你好世界.txt.trashinfo",
            Path("/original/你好世界.txt"),
            datetime(2024, 6, 15, 10, 0, 0),
        )

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        assert "1 file" in result

    def test_mixed_files_and_directories(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Regular file
        file_path = files_dir / "file.txt"
        file_path.write_text("file content", encoding="utf-8")
        write_trashinfo(info_dir / "file.txt.trashinfo", Path("/original/file.txt"), datetime(2024, 6, 10, 10, 0, 0))

        # Directory
        dir_path = files_dir / "directory"
        dir_path.mkdir()
        (dir_path / "inner.txt").write_text("inner content", encoding="utf-8")
        write_trashinfo(info_dir / "directory.trashinfo", Path("/original/directory"), datetime(2024, 6, 15, 10, 0, 0))

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        assert "2 files" in result
        # Oldest from file.txt, newest from directory
        assert "2024-06-10" in result
        assert "2024-06-15" in result

    def test_empty_files(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Empty file
        file_path = files_dir / "empty.txt"
        file_path.write_text("", encoding="utf-8")

        write_trashinfo(info_dir / "empty.txt.trashinfo", Path("/original/empty.txt"), datetime(2024, 6, 15, 10, 0, 0))

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        assert "1 file" in result
        assert "0 bytes" in result

    def test_single_byte_file(self, tmp_path: Path, monkeypatch) -> None:
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        file_path = files_dir / "single.txt"
        file_path.write_text("x", encoding="utf-8")

        write_trashinfo(info_dir / "single.txt.trashinfo", Path("/original/single.txt"), datetime(2024, 6, 15, 10, 0, 0))

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        assert "1 file" in result
        assert "1 byte" in result  # Singular "byte"

    def test_files_sorted_alphabetically(self, tmp_path: Path, monkeypatch) -> None:
        """Verify files are processed in sorted order (affects iteration)."""
        trash_dir = tmp_path / "Trash"
        files_dir = trash_dir / "files"
        info_dir = trash_dir / "info"
        files_dir.mkdir(parents=True)
        info_dir.mkdir(parents=True)

        # Create files with names that would sort differently by case
        names = ["zebra.txt", "Apple.txt", "banana.txt"]
        base_time = datetime(2024, 6, 15, 10, 0, 0)

        for i, name in enumerate(names):
            file_path = files_dir / name
            file_path.write_text(f"content {i}", encoding="utf-8")
            write_trashinfo(info_dir / f"{name}.trashinfo", Path(f"/original/{name}"), base_time + timedelta(hours=i))

        config = Config()
        config.trash.location = trash_dir

        monkeypatch.setattr(rmsafe.commands.status, "load_config", lambda: config)

        output = StringIO()
        monkeypatch.setattr(sys, "stdout", output)

        run()

        result = output.getvalue()
        assert "3 files" in result