"""Tests for progress bar module - following SQLite test philosophy."""

from __future__ import annotations

from pathlib import Path

import pytest

from rmsafe.output.progress import (
    should_show_progress,
    create_progress_bar,
    format_summary,
    PROGRESS_THRESHOLD,
)
from rmsafe.output.colors import ColorManager
from rmsafe.output.icons import IconManager


class TestShouldShowProgress:
    """should_show_progress() - threshold behavior."""

    def test_empty_list_no_progress(self) -> None:
        """Empty file list returns False."""
        assert should_show_progress([]) is False

    def test_single_file_no_progress(self) -> None:
        """Single file returns False."""
        assert should_show_progress([Path("file.txt")]) is False

    def test_two_files_no_progress(self) -> None:
        """Two files returns False."""
        assert should_show_progress([Path("a.txt"), Path("b.txt")]) is False

    def test_three_files_no_progress(self) -> None:
        """Three files (below threshold) returns False."""
        files = [Path("a.txt"), Path("b.txt"), Path("c.txt")]
        assert should_show_progress(files) is False

    def test_four_files_show_progress(self) -> None:
        """Four files (at threshold) returns True."""
        files = [Path("a.txt"), Path("b.txt"), Path("c.txt"), Path("d.txt")]
        assert should_show_progress(files) is True

    def test_many_files_show_progress(self) -> None:
        """Many files returns True."""
        files = [Path(f"file{i}.txt") for i in range(100)]
        assert should_show_progress(files) is True

    def test_threshold_constant(self) -> None:
        """Threshold is 4."""
        assert PROGRESS_THRESHOLD == 4


class TestCreateProgressBar:
    """create_progress_bar() - Rich Progress configuration."""

    @pytest.fixture
    def colors(self) -> ColorManager:
        return ColorManager("never")

    @pytest.fixture
    def icons(self) -> IconManager:
        return IconManager(use_icons=True)

    def test_returns_progress_object(self, colors: ColorManager, icons: IconManager) -> None:
        """Returns a Rich Progress instance."""
        progress = create_progress_bar(colors, icons)
        assert progress is not None

    def test_transient_is_true(self, colors: ColorManager, icons: IconManager) -> None:
        """Progress bar is transient (disappears after completion)."""
        progress = create_progress_bar(colors, icons)
        # transient is passed to Progress constructor, not a public attribute
        # We verify by checking it was created correctly
        assert progress is not None

    def test_has_spinner_column(self, colors: ColorManager, icons: IconManager) -> None:
        """Progress bar includes spinner column."""
        progress = create_progress_bar(colors, icons)
        # Check columns exist
        assert len(progress.columns) >= 4

    def test_has_text_column(self, colors: ColorManager, icons: IconManager) -> None:
        """Progress bar includes filename column."""
        progress = create_progress_bar(colors, icons)
        # Columns include Spinner, Text, Bar, TaskProgress
        assert len(progress.columns) == 4

    def test_progress_context_manager(self, colors: ColorManager, icons: IconManager) -> None:
        """Progress can be used as context manager."""
        with create_progress_bar(colors, icons) as progress:
            task = progress.add_task("test", total=10, filename="test.txt")
            progress.advance(task)
        # Context closes cleanly

    def test_colors_disabled(self) -> None:
        """Progress works with colors disabled."""
        colors = ColorManager("never")
        icons = IconManager(use_icons=False)
        progress = create_progress_bar(colors, icons)
        # Verify progress was created
        assert progress is not None

    def test_colors_enabled(self) -> None:
        """Progress works with colors enabled."""
        colors = ColorManager("always")
        icons = IconManager(use_icons=True)
        progress = create_progress_bar(colors, icons)
        # Verify progress was created
        assert progress is not None


class TestFormatSummary:
    """format_summary() - completion message formatting."""

    @pytest.fixture
    def colors(self) -> ColorManager:
        return ColorManager("never")

    @pytest.fixture
    def icons_enabled(self) -> IconManager:
        return IconManager(use_icons=True)

    @pytest.fixture
    def icons_disabled(self) -> IconManager:
        return IconManager(use_icons=False)

    def test_single_file_summary(self, colors: ColorManager, icons_enabled: IconManager) -> None:
        """Single file uses singular form."""
        summary = format_summary(1, 100, colors, icons_enabled)
        assert "1 file" in summary
        assert "files" not in summary  # plural not used

    def test_multiple_files_summary(self, colors: ColorManager, icons_enabled: IconManager) -> None:
        """Multiple files uses plural form."""
        summary = format_summary(5, 1000, colors, icons_enabled)
        assert "5 files" in summary

    def test_size_formatting_bytes(self, colors: ColorManager, icons_enabled: IconManager) -> None:
        """Size is formatted with format_size."""
        summary = format_summary(2, 500, colors, icons_enabled)
        assert "500 bytes" in summary

    def test_size_formatting_kb(self, colors: ColorManager, icons_enabled: IconManager) -> None:
        """Large sizes are formatted with KB."""
        summary = format_summary(1, 2048, colors, icons_enabled)
        assert "2 KB" in summary

    def test_size_formatting_mb(self, colors: ColorManager, icons_enabled: IconManager) -> None:
        """Very large sizes are formatted with MB."""
        summary = format_summary(3, 3 * 1024 * 1024, colors, icons_enabled)
        assert "3 MB" in summary or "3.0 MB" in summary

    def test_contains_icon_when_enabled(self, colors: ColorManager, icons_enabled: IconManager) -> None:
        """Summary contains success icon when icons enabled."""
        summary = format_summary(1, 100, colors, icons_enabled)
        # IconManager.success() returns "✓ "
        assert "✓" in summary

    def test_no_icon_when_disabled(self, colors: ColorManager, icons_disabled: IconManager) -> None:
        """Summary has no icon when icons disabled."""
        summary = format_summary(1, 100, colors, icons_disabled)
        # IconManager.success() returns "" when disabled
        assert "✓" not in summary

    def test_zero_bytes(self, colors: ColorManager, icons_enabled: IconManager) -> None:
        """Zero bytes is formatted correctly."""
        summary = format_summary(2, 0, colors, icons_enabled)
        assert "0 bytes" in summary

    def test_single_byte(self, colors: ColorManager, icons_enabled: IconManager) -> None:
        """Single byte uses singular."""
        summary = format_summary(1, 1, colors, icons_enabled)
        assert "1 byte" in summary

    def test_contains_trashed_word(self, colors: ColorManager, icons_enabled: IconManager) -> None:
        """Summary contains 'Trashed' word."""
        summary = format_summary(3, 100, colors, icons_enabled)
        assert "Trashed" in summary

    def test_contains_freed_word(self, colors: ColorManager, icons_enabled: IconManager) -> None:
        """Summary contains 'freed' word."""
        summary = format_summary(2, 500, colors, icons_enabled)
        assert "freed" in summary


class TestProgressIntegration:
    """Integration tests for progress bar with actual operations."""

    def test_threshold_behavior_matches_function(self) -> None:
        """PROGRESS_THRESHOLD matches should_show_progress behavior."""
        # Exactly at threshold
        files_at_threshold = [Path(f"f{i}.txt") for i in range(PROGRESS_THRESHOLD)]
        assert should_show_progress(files_at_threshold) is True

        # Below threshold
        files_below = [Path(f"f{i}.txt") for i in range(PROGRESS_THRESHOLD - 1)]
        assert should_show_progress(files_below) is False

    def test_progress_with_multiple_files(self, tmp_path: Path) -> None:
        """Progress bar can handle multiple files."""
        colors = ColorManager("never")
        icons = IconManager(use_icons=True)

        # Create 5 files
        files = []
        for i in range(5):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content{i}")
            files.append(f)

        # Simulate progress bar usage
        with create_progress_bar(colors, icons) as progress:
            task = progress.add_task("test", total=len(files), filename="")
            for f in files:
                progress.update(task, filename=f.name)
                progress.advance(task)

        # Should complete without error

    def test_progress_bar_transient_cleanup(self, tmp_path: Path) -> None:
        """Progress bar disappears after context closes (transient=True)."""
        colors = ColorManager("never")
        icons = IconManager(use_icons=True)

        # When transient=True, progress should clean up after completion
        with create_progress_bar(colors, icons) as progress:
            task = progress.add_task("test", total=5, filename="test.txt")
            for i in range(5):
                progress.update(task, filename=f"file{i}.txt")
                progress.advance(task)
        # After context closes, transient bar is removed from terminal

    def test_summary_after_progress(self) -> None:
        """Summary is shown after progress bar completes."""
        colors = ColorManager("never")
        icons = IconManager(use_icons=True)

        # Simulate completion
        total_bytes = 1024 * 10  # 10 KB
        summary = format_summary(5, total_bytes, colors, icons)

        assert "5 files" in summary
        assert "10 KB" in summary


class TestEdgeCases:
    """Edge cases for progress bar."""

    @pytest.fixture
    def colors(self) -> ColorManager:
        return ColorManager("never")

    @pytest.fixture
    def icons(self) -> IconManager:
        return IconManager(use_icons=True)

    def test_very_large_file_count(self) -> None:
        """Large file count handled correctly."""
        files = [Path(f"file{i}.txt") for i in range(10000)]
        assert should_show_progress(files) is True

    def test_progress_with_zero_files(self) -> None:
        """Progress with empty list is False."""
        assert should_show_progress([]) is False

    def test_progress_with_unicode_filenames(self, tmp_path: Path) -> None:
        """Unicode filenames work in progress bar."""
        colors = ColorManager("never")
        icons = IconManager(use_icons=True)

        files = [tmp_path / "你好.txt", tmp_path / "世界.txt"]
        # Below threshold, no progress
        assert should_show_progress(files) is False

        # Add more to reach threshold
        files.extend([tmp_path / "a.txt", tmp_path / "b.txt"])
        assert should_show_progress(files) is True

    def test_summary_with_zero_count(self, colors: ColorManager, icons: IconManager) -> None:
        """Zero count in summary."""
        summary = format_summary(0, 0, colors, icons)
        assert "0 files" in summary
        assert "0 bytes" in summary

    def test_summary_with_very_large_size(self, colors: ColorManager, icons: IconManager) -> None:
        """Very large size formatted correctly."""
        large_bytes = 1024 * 1024 * 1024 * 5  # 5 GB
        summary = format_summary(1, large_bytes, colors, icons)
        assert "5 GB" in summary or "5.0 GB" in summary


class TestProgressThresholdConstants:
    """Test threshold constants and behavior."""

    def test_threshold_is_four(self) -> None:
        """PROGRESS_THRESHOLD equals 4."""
        assert PROGRESS_THRESHOLD == 4

    def test_threshold_behavior_consistent(self) -> None:
        """Threshold behavior is consistent across calls."""
        files = [Path(f"f{i}") for i in range(3)]
        assert should_show_progress(files) is False

        files.append(Path("f3"))
        assert should_show_progress(files) is True