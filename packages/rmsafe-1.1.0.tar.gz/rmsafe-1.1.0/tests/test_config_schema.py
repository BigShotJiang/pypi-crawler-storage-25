"""Comprehensive tests for config/schema.py following SQLite test philosophy."""
from __future__ import annotations

from pathlib import Path

import pytest

from rmsafe.config.schema import (
    BehaviorConfig,
    BtrfsConfig,
    Config,
    OutputConfig,
    TrashConfig,
    _normalize_color,
    _normalize_size,
    _as_path,
    _require_mapping,
)


class TestNormalizeSize:
    """_normalize_size() - every format, every error."""

    def test_valid_bytes(self) -> None:
        assert _normalize_size("10B", "field") == "10B"

    def test_valid_kb(self) -> None:
        assert _normalize_size("10KB", "field") == "10KB"

    def test_valid_mb(self) -> None:
        assert _normalize_size("10MB", "field") == "10MB"

    def test_valid_gb(self) -> None:
        assert _normalize_size("10GB", "field") == "10GB"

    def test_valid_tb(self) -> None:
        assert _normalize_size("10TB", "field") == "10TB"

    def test_lowercase(self) -> None:
        assert _normalize_size("10mb", "field") == "10MB"

    def test_with_space(self) -> None:
        assert _normalize_size("10 MB", "field") == "10MB"

    def test_decimal(self) -> None:
        assert _normalize_size("1.5MB", "field") == "1.5MB"

    def test_whitespace(self) -> None:
        assert _normalize_size("  10 MB  ", "field") == "10MB"

    def test_invalid_unit(self) -> None:
        with pytest.raises(ValueError, match="look like"):
            _normalize_size("10PB", "field")

    def test_invalid_format(self) -> None:
        with pytest.raises(ValueError, match="look like"):
            _normalize_size("abc", "field")

    def test_empty_string(self) -> None:
        with pytest.raises(ValueError, match="look like"):
            _normalize_size("", "field")

    def test_invalid_type_int(self) -> None:
        with pytest.raises(ValueError, match="must be a string"):
            _normalize_size(10, "field")

    def test_invalid_type_none(self) -> None:
        with pytest.raises(ValueError, match="must be a string"):
            _normalize_size(None, "field")


class TestNormalizeColor:
    """_normalize_color() - every value, every error."""

    def test_always(self) -> None:
        assert _normalize_color("always") == "always"

    def test_never(self) -> None:
        assert _normalize_color("never") == "never"

    def test_auto(self) -> None:
        assert _normalize_color("auto") == "auto"

    def test_uppercase(self) -> None:
        assert _normalize_color("ALWAYS") == "always"
        assert _normalize_color("NEVER") == "never"
        assert _normalize_color("AUTO") == "auto"

    def test_mixed_case(self) -> None:
        assert _normalize_color("Always") == "always"
        assert _normalize_color("AuTo") == "auto"

    def test_whitespace(self) -> None:
        assert _normalize_color("  always  ") == "always"
        assert _normalize_color(" never ") == "never"

    def test_invalid_value(self) -> None:
        with pytest.raises(ValueError, match="must be one of"):
            _normalize_color("invalid")

    def test_empty_string(self) -> None:
        with pytest.raises(ValueError, match="must be one of"):
            _normalize_color("")

    def test_invalid_type_int(self) -> None:
        with pytest.raises(ValueError, match="must be a string"):
            _normalize_color(1)

    def test_invalid_type_none(self) -> None:
        with pytest.raises(ValueError, match="must be a string"):
            _normalize_color(None)


class TestAsPath:
    """_as_path() - every input type, every error."""

    def test_none_returns_none(self) -> None:
        assert _as_path(None, "field") is None

    def test_empty_string_returns_none(self) -> None:
        assert _as_path("", "field") is None

    def test_string_path(self) -> None:
        result = _as_path("/tmp/test", "field")
        assert result == Path("/tmp/test")

    def test_path_object(self) -> None:
        result = _as_path(Path("/tmp/test"), "field")
        assert result == Path("/tmp/test")

    def test_home_expansion(self, monkeypatch) -> None:
        monkeypatch.setenv("HOME", "/home/user")
        result = _as_path("~/test", "field")
        assert result == Path("/home/user/test")

    def test_path_object_with_home(self, monkeypatch) -> None:
        monkeypatch.setenv("HOME", "/home/user")
        result = _as_path(Path("~/test"), "field")
        assert result == Path("/home/user/test")

    def test_invalid_type_int(self) -> None:
        with pytest.raises(ValueError, match="must be a string path"):
            _as_path(123, "field")

    def test_invalid_type_list(self) -> None:
        with pytest.raises(ValueError, match="must be a string path"):
            _as_path(["/tmp"], "field")


class TestRequireMapping:
    """_require_mapping() - every input type."""

    def test_none_returns_empty(self) -> None:
        assert _require_mapping(None, "field") == {}

    def test_dict(self) -> None:
        result = _require_mapping({"key": "value"}, "field")
        assert result == {"key": "value"}

    def test_empty_dict(self) -> None:
        assert _require_mapping({}, "field") == {}

    def test_invalid_type_string(self) -> None:
        with pytest.raises(ValueError, match="must be a mapping"):
            _require_mapping("string", "field")

    def test_invalid_type_list(self) -> None:
        with pytest.raises(ValueError, match="must be a mapping"):
            _require_mapping(["a", "b"], "field")

    def test_invalid_type_int(self) -> None:
        with pytest.raises(ValueError, match="must be a mapping"):
            _require_mapping(123, "field")


class TestTrashConfig:
    """TrashConfig - defaults and validation."""

    def test_defaults(self) -> None:
        config = TrashConfig()
        assert config.max_size == "500MB"
        assert config.location is None
        assert config.auto_clean_days == 30

    def test_custom_values(self) -> None:
        config = TrashConfig(max_size="1GB", location=Path("/tmp/trash"), auto_clean_days=7)
        assert config.max_size == "1GB"
        assert config.location == Path("/tmp/trash")
        assert config.auto_clean_days == 7

    def test_zero_auto_clean_days(self) -> None:
        config = TrashConfig(auto_clean_days=0)
        assert config.auto_clean_days == 0


class TestBehaviorConfig:
    """BehaviorConfig - defaults and validation."""

    def test_defaults(self) -> None:
        config = BehaviorConfig()
        assert config.confirm_large_files == "10MB"
        assert config.confirm_directories is True
        assert config.undo_history_limit == 100

    def test_custom_values(self) -> None:
        config = BehaviorConfig(confirm_large_files="5MB", confirm_directories=False, undo_history_limit=50)
        assert config.confirm_large_files == "5MB"
        assert config.confirm_directories is False
        assert config.undo_history_limit == 50

    def test_zero_undo_history_limit(self) -> None:
        config = BehaviorConfig(undo_history_limit=0)
        assert config.undo_history_limit == 0


class TestOutputConfig:
    """OutputConfig - defaults and validation."""

    def test_defaults(self) -> None:
        config = OutputConfig()
        assert config.color == "auto"
        assert config.verbose is True
        assert config.icons is True
        assert config.table_format == "rounded"

    def test_custom_values(self) -> None:
        config = OutputConfig(color="never", verbose=False, icons=False, table_format="plain")
        assert config.color == "never"
        assert config.verbose is False
        assert config.icons is False
        assert config.table_format == "plain"


class TestBtrfsConfig:
    """BtrfsConfig - defaults."""

    def test_defaults(self) -> None:
        config = BtrfsConfig()
        assert config.enable_clone is True
        assert config.fallback_on_error is True

    def test_custom_values(self) -> None:
        config = BtrfsConfig(enable_clone=False, fallback_on_error=False)
        assert config.enable_clone is False
        assert config.fallback_on_error is False


class TestConfigFromMapping:
    """Config.from_mapping() - every combination, every error."""

    def test_empty_mapping_uses_defaults(self) -> None:
        config = Config.from_mapping({})
        assert config.trash.max_size == "500MB"
        assert config.behavior.confirm_large_files == "10MB"
        assert config.output.color == "auto"

    def test_partial_mapping(self) -> None:
        config = Config.from_mapping({"trash": {"max_size": "1GB"}})
        assert config.trash.max_size == "1GB"
        # Other values use defaults
        assert config.trash.auto_clean_days == 30
        assert config.behavior.confirm_large_files == "10MB"

    def test_full_mapping(self) -> None:
        config = Config.from_mapping({
            "trash": {"max_size": "1GB", "auto_clean_days": 7},
            "behavior": {"confirm_large_files": "5MB", "confirm_directories": False},
            "output": {"color": "never", "verbose": False},
            "btrfs": {"enable_clone": False},
        })
        assert config.trash.max_size == "1GB"
        assert config.trash.auto_clean_days == 7
        assert config.behavior.confirm_large_files == "5MB"
        assert config.behavior.confirm_directories is False
        assert config.output.color == "never"
        assert config.output.verbose is False
        assert config.btrfs.enable_clone is False

    def test_default_trash_location_applied(self) -> None:
        config = Config.from_mapping({}, default_trash_location=Path("/default/trash"))
        assert config.trash.location == Path("/default/trash")

    def test_explicit_location_overrides_default(self) -> None:
        config = Config.from_mapping(
            {"trash": {"location": "/explicit"}},
            default_trash_location=Path("/default/trash")
        )
        assert config.trash.location == Path("/explicit")

    def test_null_location_keeps_default(self) -> None:
        config = Config.from_mapping(
            {"trash": {"location": None}},
            default_trash_location=Path("/default/trash")
        )
        assert config.trash.location == Path("/default/trash")

    def test_empty_string_location_keeps_default(self) -> None:
        config = Config.from_mapping(
            {"trash": {"location": ""}},
            default_trash_location=Path("/default/trash")
        )
        assert config.trash.location == Path("/default/trash")

    def test_invalid_max_size(self) -> None:
        with pytest.raises(ValueError, match="look like"):
            Config.from_mapping({"trash": {"max_size": "invalid"}})

    def test_invalid_auto_clean_days_negative(self) -> None:
        with pytest.raises(ValueError, match="must be >= 0"):
            Config.from_mapping({"trash": {"auto_clean_days": -1}})

    def test_invalid_auto_clean_days_string(self) -> None:
        with pytest.raises(ValueError, match="must be an integer"):
            Config.from_mapping({"trash": {"auto_clean_days": "abc"}})

    def test_invalid_auto_clean_days_bool(self) -> None:
        with pytest.raises(ValueError, match="must be an integer"):
            Config.from_mapping({"trash": {"auto_clean_days": True}})

    def test_invalid_confirm_directories(self) -> None:
        with pytest.raises(ValueError, match="must be true or false"):
            Config.from_mapping({"behavior": {"confirm_directories": "yes"}})

    def test_invalid_undo_history_limit_negative(self) -> None:
        with pytest.raises(ValueError, match="must be >= 0"):
            Config.from_mapping({"behavior": {"undo_history_limit": -10}})

    def test_invalid_undo_history_limit_string(self) -> None:
        with pytest.raises(ValueError, match="must be an integer"):
            Config.from_mapping({"behavior": {"undo_history_limit": "high"}})

    def test_invalid_color(self) -> None:
        with pytest.raises(ValueError, match="must be one of"):
            Config.from_mapping({"output": {"color": "red"}})

    def test_invalid_verbose(self) -> None:
        with pytest.raises(ValueError, match="must be true or false"):
            Config.from_mapping({"output": {"verbose": "yes"}})

    def test_invalid_icons(self) -> None:
        with pytest.raises(ValueError, match="must be true or false"):
            Config.from_mapping({"output": {"icons": 1}})

    def test_invalid_table_format_empty(self) -> None:
        with pytest.raises(ValueError, match="must be a non-empty string"):
            Config.from_mapping({"output": {"table_format": ""}})

    def test_invalid_table_format_whitespace(self) -> None:
        with pytest.raises(ValueError, match="must be a non-empty string"):
            Config.from_mapping({"output": {"table_format": "   "}})

    def test_invalid_table_format_int(self) -> None:
        with pytest.raises(ValueError, match="must be a non-empty string"):
            Config.from_mapping({"output": {"table_format": 1}})

    def test_invalid_btrfs_enable_clone(self) -> None:
        with pytest.raises(ValueError, match="must be true or false"):
            Config.from_mapping({"btrfs": {"enable_clone": "yes"}})

    def test_invalid_trash_mapping_type(self) -> None:
        with pytest.raises(ValueError, match="must be a mapping"):
            Config.from_mapping({"trash": "invalid"})

    def test_invalid_behavior_mapping_type(self) -> None:
        with pytest.raises(ValueError, match="must be a mapping"):
            Config.from_mapping({"behavior": "invalid"})

    def test_invalid_output_mapping_type(self) -> None:
        with pytest.raises(ValueError, match="must be a mapping"):
            Config.from_mapping({"output": "invalid"})

    def test_invalid_btrfs_mapping_type(self) -> None:
        with pytest.raises(ValueError, match="must be a mapping"):
            Config.from_mapping({"btrfs": "invalid"})


class TestConfigDefaults:
    """Config - default factory behavior."""

    def test_defaults(self) -> None:
        config = Config()
        assert isinstance(config.trash, TrashConfig)
        assert isinstance(config.behavior, BehaviorConfig)
        assert isinstance(config.output, OutputConfig)
        assert isinstance(config.btrfs, BtrfsConfig)

    def test_nested_defaults_are_independent(self) -> None:
        config1 = Config()
        config2 = Config()
        # Modifying one doesn't affect the other
        config1.trash.max_size = "1GB"
        assert config2.trash.max_size == "500MB"