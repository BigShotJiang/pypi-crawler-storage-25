from __future__ import annotations

from datetime import datetime
from pathlib import Path

from rmsafe.commands import list_command
from rmsafe.config.schema import BtrfsConfig, BehaviorConfig, Config, OutputConfig, TrashConfig


def test_list_command_renders_table(tmp_path: Path, monkeypatch, capsys) -> None:
    trash_dir = tmp_path / "Trash"
    files_dir = trash_dir / "files"
    info_dir = trash_dir / "info"
    files_dir.mkdir(parents=True)
    info_dir.mkdir(parents=True)

    first = files_dir / "alpha.txt"
    second = files_dir / "beta.txt"
    first.write_text("abc", encoding="utf-8")
    second.write_text("abcdef", encoding="utf-8")

    (info_dir / "alpha.txt.trashinfo").write_text(
        "[Trash Info]\nPath=/orig/alpha.txt\nDeletionDate=2026-04-26T10:00:00\n",
        encoding="utf-8",
    )
    (info_dir / "beta.txt.trashinfo").write_text(
        "[Trash Info]\nPath=/orig/beta.txt\nDeletionDate=2026-04-26T11:00:00\n",
        encoding="utf-8",
    )

    config = Config(
        trash=TrashConfig(location=trash_dir),
        behavior=BehaviorConfig(),
        output=OutputConfig(color="never", verbose=True, icons=True, table_format="rounded"),
        btrfs=BtrfsConfig(),
    )

    monkeypatch.setattr(list_command, "load_config", lambda: config)

    list_command.run("*.txt", sort="size")

    out = capsys.readouterr().out
    assert "Trash" in out
    assert "alpha.txt" in out
    assert "beta.txt" in out
    assert "6 bytes" in out
    assert "9 bytes" in out or "3 bytes" in out
    assert "2 file(s)" in out
