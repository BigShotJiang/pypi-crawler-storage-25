"""Comprehensive tests for platform/macos.py following SQLite test philosophy."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

from rmsafe.platform.macos import get_default_trash_path, is_mac_trash, names_match


class TestGetDefaultTrashPath:
    """get_default_trash_path() - every scenario."""

    def test_returns_home_trash(self) -> None:
        result = get_default_trash_path()
        expected = Path.home() / ".Trash"
        assert result == expected

    def test_name_is_dot_trash(self) -> None:
        result = get_default_trash_path()
        assert result.name == ".Trash"

    def test_is_absolute(self) -> None:
        result = get_default_trash_path()
        assert result.is_absolute()

    def test_parent_is_home(self) -> None:
        result = get_default_trash_path()
        assert result.parent == Path.home()

    def test_multiple_calls_same_result(self) -> None:
        first = get_default_trash_path()
        second = get_default_trash_path()
        assert first == second

    def test_returns_path_object(self) -> None:
        result = get_default_trash_path()
        assert isinstance(result, Path)


class TestIsMacTrash:
    """is_mac_trash() - every platform, every path."""

    def test_darwin_with_dot_trash(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        result = is_mac_trash(Path("/Users/test/.Trash"))
        assert result is True

    def test_darwin_without_dot_trash(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        result = is_mac_trash(Path("/Users/test/Trash"))
        assert result is False

    def test_darwin_with_custom_name(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        result = is_mac_trash(Path("/Users/test/custom_trash"))
        assert result is False

    def test_linux_with_dot_trash(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "linux")
        result = is_mac_trash(Path("/home/test/.Trash"))
        assert result is False

    def test_linux_without_dot_trash(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "linux")
        result = is_mac_trash(Path("/home/test/Trash"))
        assert result is False

    def test_windows_with_dot_trash(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "win32")
        result = is_mac_trash(Path("C:/Users/test/.Trash"))
        assert result is False

    def test_relative_path(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        result = is_mac_trash(Path(".Trash"))
        # Name matches, platform matches
        assert result is True

    def test_path_with_parent_dot_trash(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        # Only the final name matters
        result = is_mac_trash(Path("/some/path/.Trash"))
        assert result is True

    def test_string_vs_path_input(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        # Function expects Path
        result = is_mac_trash(Path("/Users/.Trash"))
        assert isinstance(result, bool)

    def test_dot_trash_in_middle_of_name(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        # Name must be exactly ".Trash"
        result = is_mac_trash(Path("/Users/test/.Trash-backup"))
        assert result is False

    def test_exact_dot_trash_name(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        result = is_mac_trash(Path(".Trash"))
        assert result is True


class TestNamesMatch:
    """names_match() - every platform, every case."""

    def test_exact_match_darwin(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("file.txt", "file.txt") is True

    def test_exact_match_linux(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "linux")
        assert names_match("file.txt", "file.txt") is True

    def test_different_names_darwin(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("file.txt", "other.txt") is False

    def test_different_names_linux(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "linux")
        assert names_match("file.txt", "other.txt") is False

    def test_case_insensitive_darwin(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("File.txt", "file.txt") is True
        assert names_match("FILE.TXT", "file.txt") is True
        assert names_match("file.TXT", "FILE.txt") is True

    def test_case_sensitive_linux(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "linux")
        assert names_match("File.txt", "file.txt") is False
        assert names_match("FILE.TXT", "file.txt") is False

    def test_case_sensitive_windows(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "win32")
        # Windows is not darwin, so case sensitive
        assert names_match("File.txt", "file.txt") is False

    def test_empty_strings_match(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("", "") is True

    def test_empty_vs_nonempty(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("", "file.txt") is False
        assert names_match("file.txt", "") is False

    def test_special_chars_match(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("file-test.txt", "file-test.txt") is True

    def test_special_chars_case_darwin(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("FILE-TEST.TXT", "file-test.txt") is True

    def test_unicode_match(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("你好.txt", "你好.txt") is True

    def test_unicode_case_darwin(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        # Unicode case folding
        assert names_match("Å.txt", "å.txt") is True

    def test_unicode_case_linux(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "linux")
        assert names_match("Å.txt", "å.txt") is False

    def test_spaces_match(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("file with spaces.txt", "file with spaces.txt") is True

    def test_spaces_case_darwin(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("FILE WITH SPACES.TXT", "file with spaces.txt") is True

    def test_dots_in_name(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("file.tar.gz", "file.tar.gz") is True

    def test_dots_case_darwin(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("FILE.TAR.GZ", "file.tar.gz") is True

    def test_leading_dot(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match(".hidden", ".hidden") is True
        assert names_match(".HIDDEN", ".hidden") is True

    def test_trailing_dot(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        # Trailing dots are valid on some filesystems
        assert names_match("file.", "file.") is True

    def test_casefold_unicode(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        # casefold handles various unicode cases
        assert names_match("Straße.txt", "strasse.txt") is True

    def test_casefold_unicode_linux(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "linux")
        # No casefold on Linux
        assert names_match("Straße.txt", "strasse.txt") is False


class TestPlatformDetection:
    """Platform detection scenarios."""

    def test_lowercase_darwin(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "Darwin")
        # sys.platform is lowercase "darwin", not "Darwin"
        # But if someone sets it differently
        result = is_mac_trash(Path(".Trash"))
        # Would be False because sys.platform != "darwin"
        assert isinstance(result, bool)

    def test_platform_attribute_exists(self) -> None:
        assert hasattr(sys, "platform")

    def test_platform_is_string(self) -> None:
        assert isinstance(sys.platform, str)


class TestEdgeCases:
    """Edge cases and unusual inputs."""

    def test_very_long_name(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        long_name = "a" * 255 + ".txt"
        assert names_match(long_name, long_name) is True

    def test_very_long_name_case(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        long_name = "a" * 255 + ".txt"
        long_upper = "A" * 255 + ".TXT"
        assert names_match(long_upper, long_name) is True

    def test_single_char_match(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("a", "a") is True

    def test_single_char_case(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("A", "a") is True

    def test_only_extension(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match(".txt", ".txt") is True
        assert names_match(".TXT", ".txt") is True

    def test_newline_in_name(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        # Unusual but technically possible
        assert names_match("file\n.txt", "file\n.txt") is True

    def test_tab_in_name(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        assert names_match("file\t.txt", "file\t.txt") is True

    def test_null_byte_not_tested(self, monkeypatch) -> None:
        # Null bytes in filenames are generally not allowed
        # Not testing this edge case
        pass


class TestIntegrationWithTrashManager:
    """Integration scenarios with TrashManager."""

    def test_dot_trash_detection_consistency(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        trash_path = get_default_trash_path()
        assert is_mac_trash(trash_path) is True

    def test_custom_trash_not_mac_style(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        custom = Path.home() / "custom_trash"
        assert is_mac_trash(custom) is False

    def test_names_match_used_for_restore(self, monkeypatch) -> None:
        monkeypatch.setattr(sys, "platform", "darwin")
        # When restoring on macOS, case-insensitive matching is used
        trashed = "File.TXT"
        requested = "file.txt"
        assert names_match(requested, trashed) is True