from __future__ import annotations

from datetime import datetime
from pathlib import Path

import rmsafe.config.loader as config_loader
from rmsafe.core.trash_manager import TrashManager
from rmsafe.core.trashinfo import parse_trashinfo, write_trashinfo
from rmsafe.utils.size import format_size


def test_format_size() -> None:
    assert format_size(0) == "0 bytes"
    assert format_size(1) == "1 byte"
    assert format_size(1024) == "1 KB"
    assert format_size(5 * 1024 * 1024) == "5 MB"


def test_write_trashinfo(tmp_path: Path) -> None:
    info_path = tmp_path / "sample.txt.trashinfo"
    write_trashinfo(info_path, Path("/tmp/sample.txt"), datetime(2026, 4, 26, 0, 0, 0))

    assert info_path.read_text(encoding="utf-8") == (
        "[Trash Info]\n"
        "Path=/tmp/sample.txt\n"
        "DeletionDate=2026-04-26T00:00:00\n"
    )


def test_parse_trashinfo(tmp_path: Path) -> None:
    info_path = tmp_path / "sample.txt.trashinfo"
    info_path.write_text(
        "[Trash Info]\nPath=/tmp/sample.txt\nDeletionDate=2026-04-26T00:00:00\n",
        encoding="utf-8",
    )

    info = parse_trashinfo(info_path)
    assert info.original_path == Path("/tmp/sample.txt")
    assert info.deletion_date == datetime(2026, 4, 26, 0, 0, 0)


def test_trash_manager_moves_file_and_writes_info(tmp_path: Path) -> None:
    trash_dir = tmp_path / "Trash"
    src = tmp_path / "single_file.txt"
    src.write_text("test content", encoding="utf-8")

    manager = TrashManager(trash_dir)
    result = manager.trash_file(src)

    assert result.success is True
    destination = result.destination
    assert destination is not None
    assert destination == trash_dir / "files" / "single_file.txt"
    info_path = result.info_path
    assert info_path is not None
    assert info_path == trash_dir / "info" / "single_file.txt.trashinfo"
    assert result.size_text == "12 bytes"
    assert not src.exists()
    assert destination.read_text(encoding="utf-8") == "test content"
    assert info_path.read_text(encoding="utf-8").startswith("[Trash Info]\nPath=")


def test_trash_manager_adds_suffix_for_conflicts(tmp_path: Path) -> None:
    trash_dir = tmp_path / "Trash"
    manager = TrashManager(trash_dir)

    first = tmp_path / "dup.txt"
    second = tmp_path / "dup.txt"

    first.write_text("first", encoding="utf-8")
    first_result = manager.trash_file(first)

    second.write_text("second", encoding="utf-8")
    second_result = manager.trash_file(second)

    assert first_result.destination == trash_dir / "files" / "dup.txt"
    assert second_result.destination == trash_dir / "files" / "dup_1.txt"
    assert (trash_dir / "files" / "dup.txt").exists()
    assert (trash_dir / "files" / "dup_1.txt").exists()


def test_trash_manager_dry_run_preserves_source(tmp_path: Path) -> None:
    trash_dir = tmp_path / "Trash"
    src = tmp_path / "dry.txt"
    src.write_text("dry", encoding="utf-8")

    manager = TrashManager(trash_dir)
    result = manager.trash_file(src, dry_run=True)

    assert result.success is True
    assert src.exists()
    assert not (trash_dir / "files").exists()


def test_get_default_trash_path_uses_macos_trash(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setattr(config_loader.platform, "system", lambda: "Darwin")
    monkeypatch.setattr(config_loader.Path, "home", lambda: tmp_path)

    assert config_loader.get_default_trash_path() == tmp_path / ".Trash"


def test_trash_manager_uses_macos_layout_without_info_dir(tmp_path: Path, monkeypatch) -> None:
    trash_dir = tmp_path / ".Trash"
    src = tmp_path / "mac.txt"
    src.write_text("mac", encoding="utf-8")

    monkeypatch.setattr(TrashManager, "_is_mac_trash", staticmethod(lambda trash_dir: True))

    manager = TrashManager(trash_dir)
    result = manager.trash_file(src)

    assert result.success is True
    assert result.destination == trash_dir / "mac.txt"
    assert result.info_path is None
    assert not src.exists()
    assert (trash_dir / "mac.txt").read_text(encoding="utf-8") == "mac"
