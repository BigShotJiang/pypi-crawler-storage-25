"""Conversation branching — fork, switch, compare, and merge conversation states.

DeepCraft v0.23 — the first coding agent with conversation branching.
Enables exploring alternative approaches in parallel, then intelligently
merging results via LLM analysis.

Architecture:
    ConversationState       JSON-serializable snapshot of context + metadata
    BranchManager           Create / switch / list / compare / merge / delete branches
    LLM-driven merge        Analyzes branch diffs and proposes a combined result

Integration:
    - ContextManager: to_state() / from_state() for context serialization
    - CheckpointManager: file state tracked per-branch
    - AgentMode: mode is saved per-branch

Storage: .deepcraft/branches/<name>/state.json
"""

from __future__ import annotations

import json
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------


@dataclass
class ConversationState:
    """Full serializable snapshot of a conversation branch."""

    messages: list[dict[str, Any]]  # ChatMessage.model_dump() list
    token_count: int
    turn_count: int
    mode: str  # "react" | "plan" | "sub" | "auto"
    created_at: str
    updated_at: str
    parent_branch: str | None = None  # branch this was forked from
    description: str = ""  # user-provided or LLM-generated summary
    file_checkpoint_id: int | None = None  # last checkpoint ID when saved
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "messages": self.messages,
            "token_count": self.token_count,
            "turn_count": self.turn_count,
            "mode": self.mode,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "parent_branch": self.parent_branch,
            "description": self.description,
            "file_checkpoint_id": self.file_checkpoint_id,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ConversationState:
        return cls(
            messages=data["messages"],
            token_count=data["token_count"],
            turn_count=data["turn_count"],
            mode=data["mode"],
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            parent_branch=data.get("parent_branch"),
            description=data.get("description", ""),
            file_checkpoint_id=data.get("file_checkpoint_id"),
            metadata=data.get("metadata", {}),
        )


@dataclass
class BranchInfo:
    """Lightweight branch metadata (no messages)."""

    name: str
    description: str
    token_count: int
    turn_count: int
    mode: str
    created_at: str
    updated_at: str
    is_current: bool = False


@dataclass
class MergeProposal:
    """LLM-generated proposal for merging two branches."""

    branch_from: str
    branch_to: str
    summary_from: str  # what branch_from accomplished
    summary_to: str  # what branch_to accomplished
    conflicts: list[str]  # conflicting changes
    shared_insights: list[str]  # useful findings from both
    recommendation: str  # which files/approaches to keep
    merged_description: str  # description for the merged branch


# ---------------------------------------------------------------------------
# BranchManager
# ---------------------------------------------------------------------------


class BranchManager:
    """Manages conversation branches: create, switch, compare, merge.

    Branches are stored as JSON in .deepcraft/branches/<name>/state.json.

    Usage:
        bm = BranchManager(project_root=".")
        bm.create("try-async", ctx, mode, checkpoint_mgr)
        bm.switch("try-async", ctx, mode, checkpoint_mgr)
        proposal = await bm.compare("try-async", llm)
    """

    def __init__(self, project_root: str | Path = ".") -> None:
        self._project_root = Path(project_root).resolve()
        self._branches_dir = self._project_root / ".deepcraft" / "branches"
        self._branches_dir.mkdir(parents=True, exist_ok=True)
        self._current_branch = "main"
        self._ensure_main_exists()

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def current_branch(self) -> str:
        return self._current_branch

    @property
    def branches_dir(self) -> Path:
        return self._branches_dir

    # ------------------------------------------------------------------
    # Core operations
    # ------------------------------------------------------------------

    def _ensure_main_exists(self) -> None:
        """Create main branch metadata if not present."""
        main_dir = self._branches_dir / "main"
        if not main_dir.exists():
            main_dir.mkdir(parents=True, exist_ok=True)
            now = self._now()
            state = ConversationState(
                messages=[],
                token_count=0,
                turn_count=0,
                mode="auto",
                created_at=now,
                updated_at=now,
                description="Default branch",
            )
            self._save_branch("main", state)

    def _branch_dir(self, name: str) -> Path:
        return self._branches_dir / name

    def _state_path(self, name: str) -> Path:
        return self._branch_dir(name) / "state.json"

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def exists(self, name: str) -> bool:
        return self._state_path(name).exists()

    # ------------------------------------------------------------------
    # Save / Load
    # ------------------------------------------------------------------

    def _save_branch(self, name: str, state: ConversationState) -> None:
        """Persist branch state to disk."""
        bdir = self._branch_dir(name)
        bdir.mkdir(parents=True, exist_ok=True)
        path = self._state_path(name)
        state.updated_at = self._now()
        path.write_text(json.dumps(state.to_dict(), indent=2, ensure_ascii=False))

    def _load_branch(self, name: str) -> ConversationState:
        """Load branch state from disk."""
        path = self._state_path(name)
        if not path.exists():
            raise ValueError(f"Branch '{name}' does not exist")
        data = json.loads(path.read_text())
        return ConversationState.from_dict(data)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def create(
        self,
        name: str,
        messages: list[dict[str, Any]],
        token_count: int,
        turn_count: int,
        mode: str,
        description: str = "",
        checkpoint_mgr: Any | None = None,
    ) -> ConversationState:
        """Create a new branch from current state.

        Args:
            name: Branch name (slug-friendly).
            messages: Current conversation messages as dicts.
            token_count: Current token count.
            turn_count: Current turn count.
            mode: Current agent mode.
            description: Optional human-readable description.
            checkpoint_mgr: Optional CheckpointManager for file state tracking.

        Returns:
            The newly created ConversationState.

        Raises:
            ValueError: If branch already exists.
        """
        if self.exists(name):
            raise ValueError(f"Branch '{name}' already exists")

        now = self._now()
        ckpt_id = None
        if checkpoint_mgr and hasattr(checkpoint_mgr, "_snapshots"):
            snapshots = checkpoint_mgr._snapshots  # type: ignore[union-attr]
            if snapshots:
                ckpt_id = snapshots[-1].id

        state = ConversationState(
            messages=messages,
            token_count=token_count,
            turn_count=turn_count,
            mode=mode,
            created_at=now,
            updated_at=now,
            parent_branch=self._current_branch,
            description=description,
            file_checkpoint_id=ckpt_id,
        )
        self._save_branch(name, state)
        return state

    def snapshot_current(
        self,
        messages: list[dict[str, Any]],
        token_count: int,
        turn_count: int,
        mode: str,
    ) -> None:
        """Update current branch state (call before switching away)."""
        state = self._load_branch(self._current_branch)
        state.messages = messages
        state.token_count = token_count
        state.turn_count = turn_count
        state.mode = mode
        self._save_branch(self._current_branch, state)

    def switch(self, name: str) -> ConversationState:
        """Switch to another branch and return its state.

        Raises:
            ValueError: If branch does not exist.
        """
        if not self.exists(name):
            raise ValueError(f"Branch '{name}' does not exist")
        self._current_branch = name
        return self._load_branch(name)

    def list_branches(self) -> list[BranchInfo]:
        """List all branches with metadata."""
        branches: list[BranchInfo] = []
        for entry in sorted(self._branches_dir.iterdir()):
            if entry.is_dir():
                state_path = entry / "state.json"
                if state_path.exists():
                    try:
                        state = self._load_branch(entry.name)
                        branches.append(
                            BranchInfo(
                                name=entry.name,
                                description=state.description,
                                token_count=state.token_count,
                                turn_count=state.turn_count,
                                mode=state.mode,
                                created_at=state.created_at,
                                updated_at=state.updated_at,
                                is_current=(entry.name == self._current_branch),
                            )
                        )
                    except Exception:
                        continue
        return branches

    def delete(self, name: str) -> None:
        """Delete a branch. Cannot delete current branch."""
        if name == self._current_branch:
            raise ValueError("Cannot delete the current branch")
        if name == "main":
            raise ValueError("Cannot delete the 'main' branch")
        if not self.exists(name):
            raise ValueError(f"Branch '{name}' does not exist")

        shutil.rmtree(self._branch_dir(name), ignore_errors=True)

    # ------------------------------------------------------------------
    # Compare & Merge (LLM-driven)
    # ------------------------------------------------------------------

    async def compare(
        self,
        other_branch: str,
        llm: Any,
        current_messages: list[dict[str, Any]],
    ) -> MergeProposal:
        """LLM-driven comparison of two branches.

        Args:
            other_branch: Name of the branch to compare against.
            llm: LLMProvider instance.
            current_messages: Current conversation messages (not yet saved).

        Returns:
            MergeProposal with analysis.
        """
        if not self.exists(other_branch):
            raise ValueError(f"Branch '{other_branch}' does not exist")

        other_state = self._load_branch(other_branch)

        # Extract what each branch accomplished
        other_summary = self._extract_accomplishments(other_state.messages)
        current_summary = self._extract_accomplishments(current_messages)

        prompt = f"""You are comparing two conversation branches in a coding agent session.

BRANCH A ({self._current_branch}): {current_summary}

BRANCH B ({other_branch}): {other_summary}

Analyze the differences and respond with a JSON object:

{{
    "summary_from": "what branch A ({self._current_branch}) accomplished",
    "summary_to": "what branch B ({other_branch}) accomplished",
    "conflicts": ["list of conflicting changes between the branches"],
    "shared_insights": ["useful findings or approaches that can be combined"],
    "recommendation": "specific recommendation for merging (keep from A, keep from B, combine)",
    "merged_description": "a one-line description for the merged result"
}}

Focus on file changes, design decisions, bug fixes, and architectural insights.
Be specific — mention actual files, functions, and approaches when possible."""

        response = await llm.chat(
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
        )
        content = response.get("content", "{}")
        # Parse JSON from response (handle markdown code blocks)
        json_str = content
        if "```json" in json_str:
            json_str = json_str.split("```json")[1].split("```")[0].strip()
        elif "```" in json_str:
            json_str = json_str.split("```")[1].split("```")[0].strip()

        try:
            data = json.loads(json_str)
        except json.JSONDecodeError:
            data = {
                "summary_from": f"Branch {self._current_branch}",
                "summary_to": f"Branch {other_branch}",
                "conflicts": [],
                "shared_insights": [],
                "recommendation": "Manual merge required — LLM analysis failed",
                "merged_description": f"Merge {other_branch} into {self._current_branch}",
            }

        return MergeProposal(
            branch_from=other_branch,
            branch_to=self._current_branch,
            summary_from=data.get("summary_from", ""),
            summary_to=data.get("summary_to", ""),
            conflicts=data.get("conflicts", []),
            shared_insights=data.get("shared_insights", []),
            recommendation=data.get("recommendation", ""),
            merged_description=data.get("merged_description", ""),
        )

    def merge(
        self,
        from_branch: str,
        current_messages: list[dict[str, Any]],
        current_token_count: int,
        current_turn_count: int,
        current_mode: str,
    ) -> ConversationState:
        """Merge another branch into current.

        This is a state-level merge: saves current state, loads from_branch,
        then appends a merge note to the context.

        The actual file-level merge is handled by the agent after analyzing
        the MergeProposal from compare().
        """
        if not self.exists(from_branch):
            raise ValueError(f"Branch '{from_branch}' does not exist")

        # Save current state
        self.snapshot_current(
            messages=current_messages,
            token_count=current_token_count,
            turn_count=current_turn_count,
            mode=current_mode,
        )

        # Load target branch
        target_state = self._load_branch(from_branch)

        # Add merge marker to context
        merge_note: dict[str, Any] = {
            "role": "user",
            "content": (
                f"[Branch merge: '{from_branch}' merged into '{self._current_branch}'. "
                f"Changes from '{from_branch}' are now the working state. "
                "Review differences and reconcile file changes as needed.]"
            ),
        }
        target_state.messages.append(merge_note)
        target_state.description = f"Merged from {from_branch}"
        target_state.parent_branch = from_branch

        # Save merged state back to current branch
        self._save_branch(self._current_branch, target_state)
        return target_state

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_accomplishments(messages: list[dict[str, Any]]) -> str:
        """Extract a summary of what was accomplished from message list."""
        user_messages = [m for m in messages if m.get("role") == "user"]
        assistant_messages = [m for m in messages if m.get("role") == "assistant"]

        parts: list[str] = []
        # Show user intents
        for m in user_messages[-5:]:  # Last 5 user requests
            content = str(m.get("content", ""))[:200]
            if content:
                parts.append(f"  Task: {content}")

        # Show what was done
        for m in assistant_messages[-5:]:  # Last 5 responses
            content = str(m.get("content", ""))[:300]
            if content and "✅" in content:
                parts.append(f"  Done: {content}")

        if not parts:
            return f"{len(messages)} messages, {len(assistant_messages)} responses"
        return "\n".join(parts)
