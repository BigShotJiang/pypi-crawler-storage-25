"""Shared GitHub REST API client — used by PRWorkflow and ReviewEngine.

Replaces duplicated urllib.request patterns across the codebase.
"""

from __future__ import annotations

import json as _json
import urllib.request
from typing import Any


class GitHubClient:
    """Minimal GitHub REST API client.

    Usage:
        client = GitHubClient(token="ghp_xxx", owner="liyuan1161", repo="deepcraft")
        pr = client.get("/pulls/5")
        client.post("/pulls", {"title": "feat: ...", "head": "branch", "base": "main"})
    """

    def __init__(self, token: str, owner: str, repo: str) -> None:
        self.token = token
        self.owner = owner
        self.repo = repo
        self._base = f"https://api.github.com/repos/{owner}/{repo}"

    def _headers(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        h = {
            "Authorization": f"token {self.token}",
            "User-Agent": "deepcraft",
        }
        if extra:
            h.update(extra)
        return h

    def _request(
        self,
        method: str,
        path: str,
        data: Any = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make a GitHub API request and return parsed JSON response.

        Args:
            method: HTTP method (GET, POST, PATCH, etc.)
            path: API path relative to repo base (e.g., '/pulls', '/git/blobs').
            data: JSON-serializable body for POST/PATCH requests.
            headers: Additional HTTP headers.

        Returns:
            Parsed JSON response dict.

        Raises:
            RuntimeError: On non-2xx HTTP response.
        """
        url = f"{self._base}{path}"
        h = self._headers(headers)
        body: bytes | None = None
        if data is not None:
            body = _json.dumps(data).encode()
            h["Content-Type"] = "application/json"

        req = urllib.request.Request(url, data=body, headers=h, method=method)
        try:
            with urllib.request.urlopen(req) as resp:
                return _json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            error_body = e.read().decode() if e.fp else str(e)
            raise RuntimeError(f"GitHub API {method} {path}: {e.code} — {error_body}") from e

    def _request_raw(self, method: str, path: str, headers: dict[str, str] | None = None) -> str:
        """Make a GitHub API request and return raw string (for diff endpoints)."""
        url = f"{self._base}{path}"
        h = self._headers(headers)
        req = urllib.request.Request(url, headers=h, method=method)
        try:
            with urllib.request.urlopen(req) as resp:
                return resp.read().decode()
        except urllib.error.HTTPError as e:
            error_body = e.read().decode() if e.fp else str(e)
            raise RuntimeError(f"GitHub API {method} {path}: {e.code} — {error_body}") from e

    # Convenience methods

    def get(self, path: str, headers: dict[str, str] | None = None) -> dict[str, Any]:
        return self._request("GET", path, headers=headers)

    def post(self, path: str, data: Any = None) -> dict[str, Any]:
        return self._request("POST", path, data=data)

    def patch(self, path: str, data: Any = None) -> dict[str, Any]:
        return self._request("PATCH", path, data=data)

    def get_raw(self, path: str, headers: dict[str, str] | None = None) -> str:
        return self._request_raw("GET", path, headers=headers)
