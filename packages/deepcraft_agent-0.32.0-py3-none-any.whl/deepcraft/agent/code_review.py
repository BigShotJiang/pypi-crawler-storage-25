"""GitHub PR Code Review engine — diff analysis, issue detection, review submission.

Architecture:
    ReviewEngine
    ├── fetch_pr_diff()    → download PR diff from GitHub
    ├── analyze_diff()     → parse hunks, detect issues per file
    ├── auto_detect()      → run lint-like rules on changed lines
    ├── interactive()      → step through files, user toggles approve/comment/skip
    ├── submit_review()    → POST review via REST API
    └── format_review()    → structured summary for Agent context

Zero external dependencies — urllib + json + difflib from stdlib.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from deepcraft.agent.github_client import GitHubClient


class Severity(str, Enum):
    """Issue severity level."""
    CRITICAL = "critical"
    WARNING = "warning"
    SUGGESTION = "suggestion"


@dataclass
class ReviewIssue:
    """A single issue found in a file."""
    file: str
    line: int
    severity: Severity
    message: str
    suggestion: str = ""  # suggested fix or improvement

    def format_short(self) -> str:
        emoji = {"critical": "🔴", "warning": "🟡", "suggestion": "🔵"}
        return f"{emoji.get(self.severity, '⚪')} [{self.file}:{self.line}] {self.message}"


@dataclass 
class FileReview:
    """Review results for a single file."""
    path: str
    hunks: list[dict[str, Any]] = field(default_factory=list)
    issues: list[ReviewIssue] = field(default_factory=list)
    approved: bool = False
    lines_added: int = 0
    lines_removed: int = 0

    @property
    def has_issues(self) -> bool:
        return len(self.issues) > 0
    
    def add_issue(self, line: int, severity: Severity, message: str, suggestion: str = ""):
        self.issues.append(ReviewIssue(
            file=self.path, line=line, severity=severity,
            message=message, suggestion=suggestion,
        ))


@dataclass
class ReviewResult:
    """Complete review of a PR."""
    pr_number: int
    pr_title: str = ""
    files: list[FileReview] = field(default_factory=list)
    total_issues: int = 0
    critical: int = 0
    warnings: int = 0
    suggestions: int = 0
    approved_files: int = 0
    commented_files: int = 0

    @property
    def summary_text(self) -> str:
        lines = [
            f"📊 PR #{self.pr_number} Review",
            f"   Files: {len(self.files)} reviewed",
            f"   Issues: {self.total_issues} "
            f"({self.critical}c / {self.warnings}w / {self.suggestions}s)",
        ]
        if self.approved_files:
            lines.append(f"   Approved: {self.approved_files} files")
        return "\n".join(lines)


class ReviewEngine:
    """PR code review engine — fetch, analyze, review.

    Usage:
        engine = ReviewEngine(pr_workflow)
        result = engine.fetch_and_analyze(5)
        print(engine.format_issues(result))

        # Interactive
        decision = engine.interactive(result)
        engine.submit_review(5, decision)

        # Agent mode
        result = engine.fetch_and_analyze(5)
        return engine.format_issues(result)
    """

    def __init__(self, pr_workflow: Any = None) -> None:
        """Initialize with a PRWorkflow instance.

        If pr_workflow is None, creates a standalone instance without
        GitHub API access (dry-run mode for local review).
        """
        self._prwf = pr_workflow
        self._token: str | None = None
        self._owner: str = ""
        self._repo: str = ""
        self._client: GitHubClient | None = None
        if pr_workflow:
            self._token = pr_workflow.token
            self._owner = pr_workflow.owner
            self._repo = pr_workflow.repo
            self._client = GitHubClient(self._token, self._owner, self._repo)
    
    # ── Fetch ──────────────────────────────────────────────────────

    def fetch_pr_diff(self, pr_number: int) -> str:
        """Fetch the unified diff for a PR."""
        if not self._client:
            raise RuntimeError("No GitHub token configured")
        return self._client.get_raw(
            f"/pulls/{pr_number}",
            headers={"Accept": "application/vnd.github.v3.diff"},
        )

    def fetch_and_analyze(self, pr_number: int) -> ReviewResult:
        """Fetch PR diff and run automatic analysis."""
        diff_text = self.fetch_pr_diff(pr_number)
        
        # Get PR title
        pr_info = {}
        try:
            if self._client:
                pr_info = self._client.get(f"/pulls/{pr_number}")
        except Exception:
            pass
        
        result = self.analyze_diff(diff_text)
        result.pr_number = pr_number
        result.pr_title = pr_info.get("title", "")
        return result

    # ── Analysis ───────────────────────────────────────────────────

    def analyze_diff(self, diff_text: str) -> ReviewResult:
        """Parse a unified diff and run issue detection on each file."""
        result = ReviewResult(pr_number=0)
        file_chunks = self._split_diff(diff_text)

        for path, hunks in file_chunks.items():
            review = FileReview(path=path, hunks=hunks)
            
            # Count additions/removals
            for hunk in hunks:
                for line in hunk.get("lines", []):
                    if line.startswith("+"):
                        review.lines_added += 1
                    elif line.startswith("-"):
                        review.lines_removed += 1

            # Run auto-detection
            self._detect_issues(path, hunks, review)
            result.files.append(review)

        # Aggregate stats
        for fr in result.files:
            result.total_issues += len(fr.issues)
            for issue in fr.issues:
                if issue.severity == Severity.CRITICAL:
                    result.critical += 1
                elif issue.severity == Severity.WARNING:
                    result.warnings += 1
                elif issue.severity == Severity.SUGGESTION:
                    result.suggestions += 1
        
        return result

    def _split_diff(self, diff: str) -> dict[str, list[dict]]:
        """Split unified diff into per-file hunk data."""
        files: dict[str, list[dict]] = {}
        current_file = ""
        current_hunk: dict[str, Any] = {}
        
        for line in diff.splitlines():
            # File header: diff --git a/path b/path
            m = re.match(r'^diff --git a/(.*?) b/(.*?)$', line)
            if m:
                current_file = m.group(2)
                files[current_file] = []
                current_hunk = {}
                continue
            
            # Hunk header: @@ -old,count +new,count @@ context
            m = re.match(r'^@@ -(\d+),?(\d*) \+(\d+),?(\d*) @@ ?(.*)', line)
            if m and current_file:
                if current_hunk:
                    files[current_file].append(current_hunk)
                old_start = int(m.group(1))
                old_count = int(m.group(2)) if m.group(2) else 1
                new_start = int(m.group(3))
                new_count = int(m.group(4)) if m.group(4) else 1
                current_hunk = {
                    "old_start": old_start,
                    "old_count": old_count,
                    "new_start": new_start,
                    "new_count": new_count,
                    "header": m.group(5) or "",
                    "lines": [],
                }
                continue
            
            if current_file and current_hunk:
                current_hunk["lines"].append(line)

        # Last hunk
        if current_file and current_hunk:
            files[current_file].append(current_hunk)
        
        return files

    def _detect_issues(
        self, path: str, hunks: list[dict], review: FileReview,
    ) -> None:
        """Run static analysis rules on changed lines."""
        if not path.endswith(".py"):
            return  # Only analyze Python files for now
        
        # Build line number tracking
        for hunk in hunks:
            new_line = hunk.get("new_start", 0)
            for line_text in hunk.get("lines", []):
                if line_text.startswith("-"):
                    continue  # deletions don't advance new_line
                elif line_text.startswith("+"):
                    stripped = line_text[1:]  # remove '+'
                    self._check_line(path, new_line, stripped, review)
                    new_line += 1
                else:
                    new_line += 1

    def _check_line(
        self, path: str, line_num: int, line: str, review: FileReview,
    ) -> None:
        """Run individual rules on a single added line."""
        stripped = line.strip()

        # ═══ CRITICAL ══════════════════════════════════════════════
        
        # Bare except
        if stripped == "except:" or stripped.startswith("except:"):
            review.add_issue(line_num, Severity.CRITICAL,
                "Bare except clause — catching all exceptions",
                "Use 'except Exception as e:' instead")

        # Password/secret in plaintext
        if re.search(r'(password|secret|token|key)\s*=\s*["\']\S+["\']', stripped, re.IGNORECASE):
            review.add_issue(line_num, Severity.CRITICAL,
                "Hardcoded secret detected",
                "Use environment variables or secrets manager")

        # print() left in (not a test)
        if stripped.startswith("print(") and "test" not in path.lower():
            review.add_issue(line_num, Severity.WARNING,
                "print() statement — use logger instead",
                "Replace with logging.info() or logging.debug()")

        # ═══ WARNING ═══════════════════════════════════════════════
        
        # SQL injection risk — string formatting in execute
        if re.search(r'\.execute\s*\(.*[%f].*\)', stripped):
            review.add_issue(line_num, Severity.WARNING,
                "Potential SQL injection — use parameterized queries",
                "Use cursor.execute(query, params)")

        # os.system() usage
        if stripped.startswith("os.system("):
            review.add_issue(line_num, Severity.WARNING,
                "os.system() — unsafe, use subprocess.run()",
                "Replace with subprocess.run(..., shell=False)")

        # Empty except block
        if stripped == "pass" and line.strip().startswith("pass"):
            # Check if we're inside an except (hard to do statically, skip)
            pass

        # Too-long line
        _max_line = 120  # allow slightly longer
        if len(line.rstrip()) > _max_line:
            review.add_issue(line_num, Severity.SUGGESTION,
                f"Line too long ({len(line.rstrip())} chars > 120)",
                "Break into multiple lines or extract variable")

        # ═══ SUGGESTION ════════════════════════════════════════════
        
        # No type hints on function def (def foo(...): without ->)
        m = re.match(r'def (\w+)\(([^)]*)\):', stripped)
        if m and "->" not in stripped and not stripped.startswith("def test_"):
            review.add_issue(line_num, Severity.SUGGESTION,
                f"Function '{m.group(1)}' missing return type annotation",
                "Add '-> None' or appropriate return type")

        # Generic Exception catch
        if "except Exception as" in stripped:
            review.add_issue(line_num, Severity.SUGGESTION,
                "Catching generic Exception — consider more specific exception types",
                "Use specific exceptions (ValueError, KeyError, etc.)")

    # ── Formatting ─────────────────────────────────────────────────

    def format_issues(self, result: ReviewResult, max_per_file: int = 10) -> str:
        """Format review issues for Agent context."""
        if result.total_issues == 0:
            return f"✅ PR #{result.pr_number}: No issues found\n"

        lines = [result.summary_text, ""]
        for fr in result.files:
            if not fr.issues:
                continue
            lines.append(f"  📄 {fr.path} (+{fr.lines_added} / -{fr.lines_removed})")
            for issue in fr.issues[:max_per_file]:
                lines.append(f"    {issue.format_short()}")
                if issue.suggestion:
                    lines.append(f"       💡 {issue.suggestion}")
            if len(fr.issues) > max_per_file:
                lines.append(f"    ... ({len(fr.issues) - max_per_file} more)")
            lines.append("")
        
        return "\n".join(lines)

    def format_file_diff(self, fr: FileReview, max_lines: int = 60) -> str:
        """Format a single file's diff for interactive review."""
        lines = [
            f"📄 {fr.path}  +{fr.lines_added} / -{fr.lines_removed}",
            "─" * 60,
        ]
        
        # Show issues if any
        if fr.issues:
            lines.append("")
            for issue in fr.issues:
                lines.append(f"  {issue.format_short()}")
            lines.append("")

        # Show diff hunks
        for hunk in fr.hunks:
            hdr = hunk.get("header", "")
            os_ = hunk.get("old_start", 0)
            oc_ = hunk.get("old_count", 0)
            ns_ = hunk.get("new_start", 0)
            nc_ = hunk.get("new_count", 0)
            if hdr:
                lines.append(f"  @@ {hdr}")
            else:
                lines.append(f"  @@ -{os_},{oc_} +{ns_},{nc_} @@")
            for dl in hunk.get("lines", [])[:max_lines]:
                lines.append(f"    {dl}")
        
        return "\n".join(lines)

    def format_interactive_menu(self, result: ReviewResult) -> str:
        """Format PR-level summary for interactive mode start."""
        lines = [
            f"📋 PR #{result.pr_number}: {result.pr_title}",
            f"   {len(result.files)} files  ({result.total_issues} issues)",
            f"   {result.critical}c / {result.warnings}w / {result.suggestions}s",
            "   [a]pprove all   [i]nteractive   [s]kip   [q]uit",
        ]
        return "\n".join(lines)

    # ── Submission ─────────────────────────────────────────────────

    def submit_review(
        self,
        pr_number: int,
        body: str = "",
        event: str = "COMMENT",
        comments: list[dict[str, Any]] | None = None,
    ) -> dict:
        """Submit a review to GitHub.

        Args:
            pr_number: PR number.
            body: Review body text.
            event: APPROVE, REQUEST_CHANGES, or COMMENT.
            comments: List of line-level comments [{path, line, body}, ...].

        Returns:
            API response dict.
        """
        if not self._client:
            raise RuntimeError("No GitHub token configured")
        payload: dict[str, Any] = {"body": body, "event": event}
        if comments:
            payload["comments"] = comments
        return self._client.post(f"/pulls/{pr_number}/reviews", payload)

    def submit_single_comment(
        self, pr_number: int, commit_id: str, path: str, line: int, body: str,
    ) -> dict:
        """Submit a single line-level comment on a PR."""
        if not self._client:
            raise RuntimeError("No GitHub token configured")
        return self._client.post(
            f"/pulls/{pr_number}/comments",
            {"commit_id": commit_id, "path": path, "line": line, "body": body},
        )

    def get_pr_head_sha(self, pr_number: int) -> str:
        """Get the HEAD commit SHA for a PR."""
        if not self._client:
            raise RuntimeError("No GitHub token configured")
        return self._client.get(f"/pulls/{pr_number}")["head"]["sha"]
