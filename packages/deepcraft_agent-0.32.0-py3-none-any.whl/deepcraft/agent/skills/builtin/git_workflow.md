---
name: git_workflow
description: Git workflow conventions — branching, commits, PRs
triggers: [git workflow, git 工作流, commit, branching]
---

# Git Workflow

- **Branch naming**: `feature/description`, `fix/description`, `chore/description`.
- **Commit messages**: Conventional Commits format — `type(scope): description`. Types: feat, fix, chore, docs, refactor, test.
- **Keep commits atomic**: One logical change per commit.
- **Rebase before merge**: Keep history linear. Rebase feature branches onto main before creating a PR.
- **PR descriptions**: Include what changed, why, testing performed, and any breaking changes.
- **Never force-push to main or shared branches.**
