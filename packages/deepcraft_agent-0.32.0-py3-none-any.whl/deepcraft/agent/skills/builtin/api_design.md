---
name: api_design
description: REST API design principles — URLs, status codes, pagination, auth
triggers: [api design, API 设计, REST, endpoint]
---

# API Design Guidelines

- **URLs**: Resource-oriented nouns (not verbs). Use plural: `/users`, `/users/123/orders`. Nest max 2 levels deep.
- **HTTP methods**: GET (read), POST (create), PUT/PATCH (update), DELETE (remove).
- **Status codes**: 200 (OK), 201 (Created), 204 (No Content), 400 (Bad Request), 401 (Unauthorized), 403 (Forbidden), 404 (Not Found), 409 (Conflict), 500 (Internal Error).
- **Pagination**: Use `offset`/`limit` or cursor-based. Always return total count in response.
- **Error responses**: Consistent format — `{"error": {"code": "...", "message": "..."}}`.
- **Authentication**: Bearer token in Authorization header. Never put secrets in URLs or query params.
- **Versioning**: URL prefix (`/v1/`) or Accept header. Deprecate with `Sunset` header.
