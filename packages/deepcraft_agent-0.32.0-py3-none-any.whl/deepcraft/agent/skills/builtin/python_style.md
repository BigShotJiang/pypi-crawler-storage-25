---
name: python_style
description: Python style guide — PEP 8, type hints, Pythonic idioms
triggers: [python style, python 规范, type hints, PEP 8]
---

# Python Style Guide

Follow these conventions:

- **PEP 8**: 4-space indentation, 100-char line limit, snake_case for functions/variables, PascalCase for classes.
- **Type hints**: All function signatures must include type annotations. Use `from __future__ import annotations` for forward references.
- **Imports**: Standard library first, then third-party, then local. One import per line.
- **Docstrings**: Google-style for public APIs. Triple quotes, first line is a one-line summary.
- **Pythonic**: Use list/dict comprehensions, context managers (`with`), f-strings, `pathlib` over `os.path`.
- **Error handling**: Specific exceptions, never bare `except:`. Use `try/finally` for cleanup.
