---
name: code_review
description: Four-dimensional code review (security, performance, quality, maintainability)
triggers: [code review, 代码审查, review code, 审查代码]
---

# Code Review Guidelines

When reviewing code, evaluate across four dimensions:

1. **Security**: Check for injection vulnerabilities, hardcoded secrets, unsafe deserialization, path traversal.
2. **Performance**: Identify N+1 queries, unnecessary allocations, blocking I/O, missing caching.
3. **Quality**: Verify error handling, input validation, test coverage, type safety.
4. **Maintainability**: Assess naming consistency, function length, coupling, documentation.

For each issue found, report: file location, severity (critical/high/medium/low), and a concrete fix suggestion.
