---
name: testing
description: Testing best practices — pytest, fixtures, mocking, coverage
triggers: [testing, 测试, pytest, unit test, 单元测试]
---

# Testing Guidelines

- **Framework**: pytest. Use `pytest.mark.asyncio` for async tests.
- **Structure**: Mirror source tree. `tests/test_module.py` for `deepcraft/module.py`.
- **Fixtures**: Use `conftest.py` for shared fixtures. Keep fixtures focused — one responsibility each.
- **Mocking**: Use `unittest.mock` for external dependencies. Mock at the boundary, not internals.
- **Parametrization**: `@pytest.mark.parametrize` for testing multiple inputs.
- **Coverage**: Aim for >80% on new code. Focus on edge cases: empty inputs, None values, boundary conditions.
- **Test names**: `test_<function>_<scenario>_<expected_result>`. Descriptive, not cryptic.
- **Speed**: Unit tests should complete in milliseconds. Integration tests in seconds.
