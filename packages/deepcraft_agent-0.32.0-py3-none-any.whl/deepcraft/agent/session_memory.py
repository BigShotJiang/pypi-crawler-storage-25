"""Cross-session memory with LLM-driven extraction and BM25 retrieval.

Architecture:
    SessionMemory
    ├── capture(turn)         → LLM extracts facts from conversation turns
    ├── search(query)         → BM25-relevant + recency-scored facts
    ├── inject()              → context string for session startup
    ├── consolidate()         → dedup + merge similar memories
    ├── save() / load()       → JSON persistence
    └── stats()               → memory statistics

Uses SemanticSearcher (v0.21 BM25) for relevance matching.
Zero new dependencies — uses existing Agent LLM for extraction.
"""

from __future__ import annotations

import json as _json
import re as _re
import time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from deepcraft.agent.semantic_search import SemanticSearcher

if TYPE_CHECKING:
    from deepcraft.agent.loop import Agent

_HOURS_PER_2DAYS = 48
_MIN_ENTRIES = 2


@dataclass
class MemoryEntry:
    """A single durable memory fact."""

    key: str
    value: str
    timestamp: float = field(default_factory=time.time)
    session_id: str = ""
    importance: float = 1.0
    access_count: int = 0
    last_accessed: float = 0.0

    def touch(self) -> None:
        self.access_count += 1
        self.last_accessed = time.time()

    def age_hours(self) -> float:
        return (time.time() - self.timestamp) / 3600


class SessionMemory:
    """Cross-session persistent memory with LLM extraction."""


    EXTRACT_PROMPT = (
        "Extract durable facts from this conversation.\n\n"
        "Return JSON array. Each fact: key (short slug), value (one sentence), "
        "importance (1-10). Focus on preferences, decisions, conventions, quirks. "
        "Skip task progress and temporary TODOs.\n\n"
        "User: {user_msg}\nAssistant: {assistant_msg}\n\n"
        "Return ONLY: ```json\n[{{\"key\":\"x\",\"value\":\"...\",\"importance\":5}}]\n```"
    )

    CONSOLIDATE_PROMPT = (
        "Merge duplicate memories. Same meaning → combine. Different → keep both.\n\n"
        "{memories}\n\n"
        "Return JSON array with key and value."
    )

    def __init__(
        self,
        agent: Agent | None = None,
        store_dir: str | Path = "~/.hermes/deepcraft",
    ) -> None:
        self._agent = agent
        self._store_dir = Path(store_dir).expanduser()
        self._store_dir.mkdir(parents=True, exist_ok=True)
        self._path = self._store_dir / "session_memory.json"
        self._searcher = SemanticSearcher()
        self._entries: dict[str, MemoryEntry] = {}
        self._session_id: str = ""

    def add(self, key: str, value: str, importance: float = 5.0) -> MemoryEntry:
        entry = MemoryEntry(
            key=key, value=value, importance=importance,
            session_id=self._session_id or "unknown",
        )
        self._searcher.index(key, value)
        self._entries[key] = entry
        self.save()
        return entry

    def get(self, key: str) -> MemoryEntry | None:
        e = self._entries.get(key)
        if e:
            e.touch()
        return e

    def remove(self, key: str) -> bool:
        if key in self._entries:
            del self._entries[key]
            self._searcher.remove(key)
            self.save()
            return True
        return False

    def clear(self) -> None:
        self._entries.clear()
        self._searcher = SemanticSearcher()
        self.save()

    async def capture(
        self, user_msg: str, assistant_msg: str,
    ) -> list[dict[str, Any]]:
        """Extract facts from a conversation turn using LLM."""
        if not self._agent:
            return []
        prompt = self.EXTRACT_PROMPT.format(
            user_msg=user_msg[:2000], assistant_msg=assistant_msg[:2000],
        )
        try:
            response = await self._agent._call_llm_raw(prompt)
            facts = _parse_json_array(response)
        except Exception:
            return []
        captured = []
        for fact in facts:
            key = fact.get("key", "").strip()
            value = fact.get("value", "").strip()
            imp = float(fact.get("importance", 5))
            if not key or not value:
                continue
            existing = self._entries.get(key)
            if existing:
                existing.value = value
                existing.timestamp = time.time()
                existing.importance = max(existing.importance, imp)
                self._searcher.index(key, value)
            else:
                self.add(key, value, imp)
            captured.append({"key": key, "value": value, "importance": imp})
        if captured:
            self.save()
        return captured

    def search(self, query: str, top_k: int = 10) -> list[dict[str, Any]]:
        """Search memories with BM25 relevance + recency boost."""
        results = self._searcher.search_with_snippets(query, top_k=top_k * 2)
        now = time.time()
        scored = []
        for r in results:
            entry = self._entries.get(r["doc_id"])
            if not entry:
                scored.append(r)
                continue
            age_days = (now - entry.timestamp) / 86400
            recency = 2.0 ** (-age_days / 7.0)
            imp_boost = 0.5 + (entry.importance / 10) * 1.5
            access_bonus = min(1.5, 1.0 + entry.access_count * 0.05)
            final = r["score"] * recency * imp_boost * access_bonus
            scored.append({**r, "score": round(final, 4)})
            entry.touch()
        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:top_k]

    def inject(self, context: str = "", top_k: int = 8) -> str:
        """Generate memory context for session startup."""
        if not self._entries:
            return ""
        results = self.search(context or "recent", top_k=top_k)
        if not results:
            return ""
        lines = ["[PERSISTENT MEMORY - facts from past sessions]\n"]
        for r in results:
            entry = self._entries.get(r["doc_id"])
            if entry:
                stars = "⭐" * min(5, max(1, int(entry.importance / 2)))
                age = entry.age_hours()
                age_s = f"{age:.0f}h" if age < _HOURS_PER_2DAYS else f"{age/24:.0f}d"
                lines.append(f"  {stars} [{age_s}] {entry.value}")
            else:
                lines.append(f"  {r['snippet']}")
        lines.append("\n[End of persistent memory]\n")
        return "\n".join(lines)

    async def consolidate(self) -> int:
        """Dedup and merge similar memories using LLM."""
        if len(self._entries) < _MIN_ENTRIES or not self._agent:
            return 0
        entries = list(self._entries.values())
        groups: dict[str, list[MemoryEntry]] = defaultdict(list)
        for e in entries:
            groups[e.key.split("-")[0]].append(e)
        removed = 0
        for group in groups.values():
            if len(group) < _MIN_ENTRIES:
                continue
            text = "\n".join(f"[{e.key}] {e.value}" for e in group)
            prompt = self.CONSOLIDATE_PROMPT.format(memories=text)
            try:
                resp = await self._agent._call_llm_raw(prompt)
                merged = _parse_json_array(resp)
            except Exception:
                continue
            if len(merged) < len(group):
                for e in group:
                    self.remove(e.key)
                    removed += 1
                for m in merged:
                    self.add(
                        m.get("key", f"{group[0].key}-merged"),
                        m.get("value", ""), importance=6.0,
                    )
        if removed:
            self.save()
        return removed

    def save(self) -> None:
        data = {
            "entries": {
                k: {
                    "key": e.key, "value": e.value,
                    "timestamp": e.timestamp, "session_id": e.session_id,
                    "importance": e.importance,
                    "access_count": e.access_count,
                    "last_accessed": e.last_accessed,
                }
                for k, e in self._entries.items()
            },
        }
        self._path.write_text(_json.dumps(data, ensure_ascii=False, indent=2))

    def load(self) -> None:
        if not self._path.exists():
            return
        try:
            data = _json.loads(self._path.read_text())
            for d in data.get("entries", {}).values():
                entry = MemoryEntry(
                    key=d["key"], value=d["value"],
                    timestamp=d.get("timestamp", 0),
                    session_id=d.get("session_id", ""),
                    importance=d.get("importance", 5.0),
                    access_count=d.get("access_count", 0),
                    last_accessed=d.get("last_accessed", 0),
                )
                self._entries[entry.key] = entry
                self._searcher.index(entry.key, entry.value)
        except Exception:
            pass

    def stats(self) -> dict[str, Any]:
        total = len(self._entries)
        if total == 0:
            return {"total": 0, "avg_importance": 0}
        avg = sum(e.importance for e in self._entries.values()) / total
        newest = max(e.timestamp for e in self._entries.values())
        return {
            "total": total,
            "avg_importance": round(avg, 1),
            "newest_age_hours": round((time.time() - newest) / 3600, 1),
            "store_path": str(self._path),
        }


def _parse_json_array(text: str) -> list[dict]:
    """Extract JSON array from LLM response text."""
    m = _re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, _re.DOTALL)
    if m:
        try:
            result = _json.loads(m.group(1).strip())
            if isinstance(result, list):
                return result
        except _json.JSONDecodeError:
            pass
    m = _re.search(r"\[.*\]", text, _re.DOTALL)
    if m:
        try:
            result = _json.loads(m.group(0))
            if isinstance(result, list):
                return result
        except _json.JSONDecodeError:
            pass
    return []
