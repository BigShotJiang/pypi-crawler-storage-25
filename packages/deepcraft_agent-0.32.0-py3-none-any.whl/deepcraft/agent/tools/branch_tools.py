"""Agent tools for conversation branching.

Exposes BranchManager operations as Function Call tools so the agent
can switch branches, compare approaches, and merge results autonomously.
"""

from __future__ import annotations

from typing import Any

from deepcraft.agent.tools.base import BaseTool


class BranchListTool(BaseTool):
    """List all conversation branches."""

    @property
    def name(self) -> str:
        return "branch_list"

    @property
    def description(self) -> str:
        return "List all conversation branches with their status, token counts, and descriptions."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {},
        }

    def execute(self, **kwargs: Any) -> str:  # type: ignore[override]
        """List branches — actual data injected by REPL via _manager attr."""
        manager = getattr(self, "_manager", None)
        if manager is None:
            return "Branch manager not initialized."

        branches = manager.list_branches()
        if not branches:
            return "No branches found."

        lines = ["**Conversation Branches:**", ""]
        lines.append("| Name | Mode | Turns | Tokens | Current | Description |")
        lines.append("|------|------|-------|--------|---------|-------------|")
        for b in branches:
            current_mark = "✅" if b.is_current else ""
            lines.append(
                f"| {b.name} | {b.mode} | {b.turn_count} | {b.token_count:,} "
                f"| {current_mark} | {b.description} |"
            )
        return "\n".join(lines)


class BranchCreateTool(BaseTool):
    """Create a new conversation branch."""

    @property
    def name(self) -> str:
        return "branch_create"

    @property
    def description(self) -> str:
        return (
            "Create a new conversation branch from the current state. "
            "Use this to fork the conversation and try an alternative approach."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": (
                        "Name for the new branch "
                        "(use slug format: try-async, experiment-x)"
                    ),
                },
                "description": {
                    "type": "string",
                    "description": "What this branch will explore",
                },
            },
            "required": ["name", "description"],
        }

    def execute(self, name: str, description: str, **kwargs: Any) -> str:  # type: ignore[override]
        manager = getattr(self, "_manager", None)
        ctx = getattr(self, "_context", None)
        current_mode = getattr(self, "_current_mode", "auto")
        checkpoint_mgr = getattr(self, "_checkpoint_mgr", None)

        if manager is None:
            return "Branch manager not initialized."

        try:
            messages = ctx.export_json() if ctx else []
            token_count = ctx.token_count if ctx else 0
            turn_count = getattr(self, "_turn_count", 0)

            manager.create(
                name=name,
                messages=messages,
                token_count=token_count,
                turn_count=turn_count,
                mode=current_mode,
                description=description,
                checkpoint_mgr=checkpoint_mgr,
            )
            return f"✅ Branch '{name}' created from '{manager.current_branch}'"
        except ValueError as e:
            return f"❌ {e}"


class BranchSwitchTool(BaseTool):
    """Switch to another conversation branch."""

    @property
    def name(self) -> str:
        return "branch_switch"

    @property
    def description(self) -> str:
        return "Switch to another conversation branch. Saves current branch state before switching."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Name of the branch to switch to",
                },
            },
            "required": ["name"],
        }

    def execute(self, name: str, **kwargs: Any) -> str:  # type: ignore[override]
        manager = getattr(self, "_manager", None)
        if manager is None:
            return "Branch manager not initialized."

        try:
            state = manager.switch(name)
            return (
                f"✅ Switched to branch '{name}'\n"
                f"   Turn count: {state.turn_count}\n"
                f"   Token count: {state.token_count:,}\n"
                f"   Mode: {state.mode}"
            )
        except ValueError as e:
            return f"❌ {e}"


class BranchCompareTool(BaseTool):
    """Compare two conversation branches."""

    @property
    def name(self) -> str:
        return "branch_compare"

    @property
    def description(self) -> str:
        return (
            "Compare another branch with the current one. "
            "The agent analyzes differences and proposes a merge strategy."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Name of the branch to compare against current",
                },
            },
            "required": ["name"],
        }

    def execute(self, name: str, **kwargs: Any) -> str:  # type: ignore[override]
        manager = getattr(self, "_manager", None)
        if manager is None:
            return "Branch manager not initialized."

        if not manager.exists(name):
            return f"❌ Branch '{name}' does not exist."

        # Defer to REPL for LLM-driven comparison (tool can't do async)
        return (
            f"🔍 Comparing '{manager.current_branch}' vs '{name}'...\n"
            f"Use /branch compare {name} in REPL for full LLM analysis."
        )


class BranchMergeTool(BaseTool):
    """Merge another branch into current."""

    @property
    def name(self) -> str:
        return "branch_merge"

    @property
    def description(self) -> str:
        return (
            "Merge another conversation branch into the current one. "
            "Review the merge proposal before applying."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Name of the branch to merge into current",
                },
            },
            "required": ["name"],
        }

    def execute(self, name: str, **kwargs: Any) -> str:  # type: ignore[override]
        manager = getattr(self, "_manager", None)
        if manager is None:
            return "Branch manager not initialized."

        if not manager.exists(name):
            return f"❌ Branch '{name}' does not exist."

        # Defer to REPL for LLM-assisted merge
        return (
            f"🔄 Merge '{name}' into '{manager.current_branch}'...\n"
            f"Use /branch compare {name} first to review the proposal,\n"
            f"then /branch merge {name} to complete the merge."
        )
