"""Code review tools — Agent-accessible PR review and line comments."""

from __future__ import annotations

from typing import Any

from deepcraft.agent.code_review import ReviewEngine
from deepcraft.agent.tools.base import Tool, ToolResult

REVIEW_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "review_pr",
        "description": (
            "Analyze a GitHub PR diff and detect code issues. "
            "Returns structured issues with severity levels "
            "(critical, warning, suggestion). Use BEFORE merging to "
            "catch bugs, style issues, and security problems."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "pr_number": {
                    "type": "integer",
                    "description": "The PR number to review.",
                },
                "depth": {
                    "type": "string",
                    "enum": ["quick", "full"],
                    "description": "Review depth: quick (top issues) or full (all files).",
                },
            },
            "required": ["pr_number"],
        },
    },
}

COMMENT_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "review_comment",
        "description": (
            "Submit a line-level comment on a GitHub PR. "
            "Use to suggest improvements or flag issues on specific lines."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "pr_number": {
                    "type": "integer",
                    "description": "The PR number to comment on.",
                },
                "file": {
                    "type": "string",
                    "description": "File path relative to repo root.",
                },
                "line": {
                    "type": "integer",
                    "description": "Line number in the PR diff (new file).",
                },
                "body": {
                    "type": "string",
                    "description": "Comment text (markdown supported).",
                },
            },
            "required": ["pr_number", "file", "line", "body"],
        },
    },
}


class ReviewPRTool(Tool):
    """Agent tool — analyze a PR diff and detect issues."""

    def __init__(self, engine: ReviewEngine) -> None:
        self._engine = engine

    @property
    def name(self) -> str:
        return "review_pr"

    @property
    def description(self) -> str:
        return "Review a GitHub PR — detect bugs, security issues, style problems."

    @property
    def definition(self) -> dict[str, Any]:
        return REVIEW_DEFINITION

    async def execute(
        self,
        pr_number: int,
        depth: str = "full",
    ) -> ToolResult:
        try:
            result = self._engine.fetch_and_analyze(pr_number)
            
            if depth == "full":
                content = self._engine.format_issues(result, max_per_file=50)
            else:
                # Quick: only show critical + warnings
                result.critical = sum(
                    1 for f in result.files for i in f.issues
                    if i.severity == "critical"
                )
                result.warnings = sum(
                    1 for f in result.files for i in f.issues
                    if i.severity == "warning"
                )
                content = (
                    f"PR #{pr_number}: {result.critical} critical, "
                    f"{result.warnings} warnings "
                    f"(skipped suggestions — use depth='full' for details)\n"
                )
                # Still show criticals
                for fr in result.files:
                    for issue in fr.issues:
                        if issue.severity in ("critical", "warning"):
                            content += f"  {issue.format_short()}\n"

            return ToolResult(content=content.rstrip(), is_error=False)
        except Exception as e:
            return ToolResult(content=f"Review failed: {e}", is_error=True)


class ReviewCommentTool(Tool):
    """Agent tool — submit line-level comment on a PR."""

    def __init__(self, engine: ReviewEngine) -> None:
        self._engine = engine

    @property
    def name(self) -> str:
        return "review_comment"

    @property
    def description(self) -> str:
        return "Submit a line-level comment on a GitHub PR."

    @property
    def definition(self) -> dict[str, Any]:
        return COMMENT_DEFINITION

    async def execute(
        self,
        pr_number: int,
        file: str,
        line: int,
        body: str,
    ) -> ToolResult:
        try:
            commit_id = self._engine.get_pr_head_sha(pr_number)
            result = self._engine.submit_single_comment(
                pr_number, commit_id, file, line, body,
            )
            return ToolResult(
                content=f"✅ Comment submitted to {file}:{line}\n"
                        f"   URL: {result.get('html_url', 'N/A')}",
                is_error=False,
            )
        except Exception as e:
            return ToolResult(content=f"Comment failed: {e}", is_error=True)
