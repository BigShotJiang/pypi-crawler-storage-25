"""Session memory tools — persistent cross-session memory for Agent."""

from __future__ import annotations

from typing import Any

from deepcraft.agent.session_memory import SessionMemory
from deepcraft.agent.tools.base import Tool, ToolResult

MEMORY_SEARCH_DEF: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "memory_search",
        "description": (
            "Search persistent cross-session memories. Use to recall user preferences, "
            "project conventions, past decisions, and environment details from "
            "previous conversations. Memories are ranked by BM25 relevance + recency."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query — keywords or natural language.",
                },
                "top_k": {
                    "type": "integer",
                    "description": "Max results (default: 5).",
                },
            },
            "required": ["query"],
        },
    },
}

MEMORY_SAVE_DEF: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "memory_save",
        "description": (
            "Save a durable fact to cross-session memory. Use for user preferences, "
            "project conventions, or any information that should persist across "
            "future conversations."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "key": {
                    "type": "string",
                    "description": "Short slug (lowercase, hyphens, max 40 chars).",
                },
                "value": {
                    "type": "string",
                    "description": "The fact to remember (one sentence).",
                },
                "importance": {
                    "type": "number",
                    "description": "Importance 1-10 (10 = critical, default: 5).",
                },
            },
            "required": ["key", "value"],
        },
    },
}


class MemorySearchTool(Tool):
    """Agent tool — search persistent memories."""

    def __init__(self, memory: SessionMemory) -> None:
        self._mem = memory

    @property
    def name(self) -> str:
        return "memory_search"

    @property
    def description(self) -> str:
        return "Search cross-session memories — user preferences, conventions, past decisions."

    @property
    def definition(self) -> dict[str, Any]:
        return MEMORY_SEARCH_DEF

    async def execute(self, query: str, top_k: int = 5) -> ToolResult:
        try:
            results = self._mem.search(query, top_k=min(top_k, 10))
            if not results:
                return ToolResult(content="No matching memories.", is_error=False)
            lines = [f"Found {len(results)} memory(s):\n"]
            for r in results:
                lines.append(f"  - [{r['doc_id']}] {r['snippet']}")
            return ToolResult(content="\n".join(lines), is_error=False)
        except Exception as e:
            return ToolResult(content=f"Memory search failed: {e}", is_error=True)


class MemorySaveTool(Tool):
    """Agent tool — save a fact to persistent memory."""

    def __init__(self, memory: SessionMemory) -> None:
        self._mem = memory

    @property
    def name(self) -> str:
        return "memory_save"

    @property
    def description(self) -> str:
        return "Save a durable fact to cross-session persistent memory."

    @property
    def definition(self) -> dict[str, Any]:
        return MEMORY_SAVE_DEF

    async def execute(
        self, key: str, value: str, importance: float = 5.0
    ) -> ToolResult:
        try:
            entry = self._mem.add(key, value, importance=min(10, max(1, importance)))
            return ToolResult(
                content=f"✅ Memory saved: {key}\n   {value}\n   Importance: {entry.importance}",
                is_error=False,
            )
        except Exception as e:
            return ToolResult(content=f"Memory save failed: {e}", is_error=True)
