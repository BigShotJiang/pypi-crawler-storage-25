"""Semantic search tools — BM25-powered document search for the Agent."""

from __future__ import annotations

from typing import Any

from deepcraft.agent.semantic_search import SemanticSearcher
from deepcraft.agent.tools.base import Tool, ToolResult

SEARCH_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "semantic_search",
        "description": (
            "Search the codebase knowledge base using BM25 semantic ranking. "
            "Better than keyword search — understands CJK bigrams, English stems, "
            "and ranks by relevance. Use for finding docs, code patterns, and concepts."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query — natural language or code pattern.",
                },
                "top_k": {
                    "type": "integer",
                    "description": "Max results to return (default: 10, max: 20).",
                },
            },
            "required": ["query"],
        },
    },
}

INDEX_DEFINITION: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "semantic_index",
        "description": (
            "Add a document to the semantic search index. "
            "Use for code files, documentation, API specs, or any text "
            "that should be searchable later."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "doc_id": {
                    "type": "string",
                    "description": "Unique document identifier (e.g., file path).",
                },
                "content": {
                    "type": "string",
                    "description": "Document content to index.",
                },
            },
            "required": ["doc_id", "content"],
        },
    },
}


class SemanticSearchTool(Tool):
    """Agent tool — BM25 semantic search."""

    def __init__(self, searcher: SemanticSearcher) -> None:
        self._searcher = searcher

    @property
    def name(self) -> str:
        return "semantic_search"

    @property
    def description(self) -> str:
        return "BM25 semantic search — find relevant docs and code patterns."

    @property
    def definition(self) -> dict[str, Any]:
        return SEARCH_DEFINITION

    async def execute(self, query: str, top_k: int = 10) -> ToolResult:
        try:
            top_k = min(top_k, 20)
            results = self._searcher.search_with_snippets(query, top_k=top_k)
            if not results:
                return ToolResult(
                    content="No matching documents found. Try different keywords.",
                    is_error=False,
                )
            lines = [f"Found {len(results)} result(s) for: {query}\n"]
            for i, r in enumerate(results, 1):
                lines.append(
                    f"  {i}. [{r['doc_id']}] (score: {r['score']:.3f})\n"
                    f"     {r['snippet']}"
                )
            return ToolResult(content="\n".join(lines), is_error=False)
        except Exception as e:
            return ToolResult(content=f"Search failed: {e}", is_error=True)


class SemanticIndexTool(Tool):
    """Agent tool — add document to semantic index."""

    def __init__(self, searcher: SemanticSearcher) -> None:
        self._searcher = searcher

    @property
    def name(self) -> str:
        return "semantic_index"

    @property
    def description(self) -> str:
        return "Add a document to the semantic search index."

    @property
    def definition(self) -> dict[str, Any]:
        return INDEX_DEFINITION

    async def execute(self, doc_id: str, content: str) -> ToolResult:
        try:
            self._searcher.index(doc_id, content)
            return ToolResult(
                content=(
                    f"Indexed: {doc_id} "
                    f"({len(content)} chars, "
                    f"{self._searcher.document_count} docs total)"
                ),
                is_error=False,
            )
        except Exception as e:
            return ToolResult(content=f"Index failed: {e}", is_error=True)
