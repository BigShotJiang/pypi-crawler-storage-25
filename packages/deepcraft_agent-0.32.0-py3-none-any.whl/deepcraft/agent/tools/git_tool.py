"""Git operations tool — branch, commit, status, diff."""

from __future__ import annotations

import asyncio

from deepcraft.agent.tools.base import BaseTool, ToolResult
from deepcraft.config import WORKDIR


async def _run_git(args: list[str], cwd: str) -> tuple[int, str]:
    """Run a git command and return (exit_code, output)."""
    process = await asyncio.create_subprocess_exec(
        "git",
        *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=cwd,
    )
    stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=60)
    output = stdout.decode("utf-8", errors="replace")
    if stderr:
        err = stderr.decode("utf-8", errors="replace")
        if err.strip():
            output += "\n" + err
    return process.returncode or 0, output.strip()


class GitTool(BaseTool):
    name = "git"
    description = "Execute git commands: status, diff, log, branch, add, commit, push."

    parameters = {
        "action": {
            "type": "string",
            "enum": ["status", "diff", "log", "branch", "add", "commit", "push", "pull"],
            "description": "Git action to perform",
        },
        "target": {
            "type": "string",
            "description": ("Target: file path for add, branch name for branch, commit message for commit"),
        },
    }

    async def execute(self, action: str, target: str = "") -> ToolResult:  # type: ignore[override]
        cwd = str(WORKDIR)

        try:
            if action == "status":
                _code, out = await _run_git(["status", "--short"], cwd)
                return ToolResult(content=out or "clean working tree")

            elif action == "diff":
                args = ["diff"]
                if target:
                    args.append(target)
                _code, out = await _run_git(args, cwd)
                return ToolResult(content=out or "no changes")

            elif action == "log":
                _code, out = await _run_git(["log", "--oneline", "--graph", "-20"], cwd)
                return ToolResult(content=out or "no commits")

            elif action == "branch":
                _code, out = await _run_git(["branch", "-a"], cwd)
                return ToolResult(content=out)

            elif action == "add":
                if not target:
                    target = "."
                _code, out = await _run_git(["add", target], cwd)
                return ToolResult(content=out or f"staged: {target}")

            elif action == "commit":
                if not target:
                    return ToolResult(content="commit message required", is_error=True)
                __code, out = await _run_git(["commit", "-m", target], cwd)
                return ToolResult(content=out)

            elif action == "push":
                __code, out = await _run_git(["push"], cwd)
                return ToolResult(content=out or "pushed")

            elif action == "pull":
                __code, out = await _run_git(["pull"], cwd)
                return ToolResult(content=out or "up to date")

            else:
                return ToolResult(content=f"Unknown action: {action}", is_error=True)

        except TimeoutError:
            return ToolResult(content="Git command timed out", is_error=True)
        except FileNotFoundError:
            return ToolResult(content="Git not found on this system", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Git error: {e}", is_error=True)
