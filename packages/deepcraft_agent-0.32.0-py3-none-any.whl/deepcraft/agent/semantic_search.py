"""Semantic search engine with BM25 scoring and CJK-aware tokenization.

Architecture:
    SemanticSearcher
    ├── tokenize()          → n-gram tokenization (CJK bigrams, English words)
    ├── index()             → add documents with BM25-ready stats
    ├── search()            → BM25-scored retrieval with dedup + ranking
    ├── remove()            → remove documents
    └── stats()             → index statistics

Zero external dependencies — pure Python math.
BM25 parameters: k1=1.5, b=0.75 (standard defaults).
CJK tokens: unigrams + bigrams for Chinese/Japanese/Korean text.
"""

from __future__ import annotations

import json as _json
import math
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Unicode CJK ranges
_CJK_UNIFIED = (0x4E00, 0x9FFF)
_CJK_EXT_A = (0x3400, 0x4DBF)
_HIRAGANA = (0x3040, 0x309F)
_KATAKANA = (0x30A0, 0x30FF)
_HANGUL = (0xAC00, 0xD7AF)


# ── Tokenization ──────────────────────────────────────────────────

def tokenize(text: str, ngram: int = 2) -> list[str]:
    """Split text into n-gram tokens, handling CJK and English.

    CJK characters are split into character-level n-grams.
    English words are split on word boundaries.
    """
    tokens: list[str] = []
    cjk_buf: list[str] = []
    eng_buf: list[str] = []

    def flush_cjk():
        if not cjk_buf:
            return
        # Unigrams
        tokens.extend(cjk_buf)
        # Bigrams
        for i in range(len(cjk_buf) - 1):
            tokens.append(cjk_buf[i] + cjk_buf[i + 1])
        cjk_buf.clear()

    def flush_eng():
        if eng_buf:
            word = "".join(eng_buf).lower()
            if len(word) > 1:
                tokens.append(word)
            eng_buf.clear()

    for ch in text:
        if _is_cjk(ch):
            flush_eng()
            cjk_buf.append(ch)
        elif ch.isalnum():
            if cjk_buf:
                flush_cjk()
            eng_buf.append(ch)
        else:
            flush_cjk()
            flush_eng()

    flush_cjk()
    flush_eng()
    return tokens


def _is_cjk(ch: str) -> bool:
    """Check if character is in CJK Unified Ideographs range."""
    cp = ord(ch)
    return (
        (_CJK_UNIFIED[0] <= cp <= _CJK_UNIFIED[1])
        or (_CJK_EXT_A[0] <= cp <= _CJK_EXT_A[1])
        or (_HIRAGANA[0] <= cp <= _HIRAGANA[1])
        or (_KATAKANA[0] <= cp <= _KATAKANA[1])
        or (_HANGUL[0] <= cp <= _HANGUL[1])
    )


# ── BM25 ──────────────────────────────────────────────────────────

@dataclass
class DocEntry:
    """A document in the search index."""
    doc_id: str
    text: str
    tokens: list[str] = field(default_factory=list)
    term_freq: dict[str, int] = field(default_factory=dict)
    length: int = 0


class SemanticSearcher:
    """BM25-powered semantic search engine.

    Usage:
        searcher = SemanticSearcher()
        searcher.index("doc1", "Python 异步编程指南")
        searcher.index("doc2", "async/await 使用教程")
        results = searcher.search("异步编程")
        for doc_id, score in results:
            print(f"{doc_id}: {score:.3f}")
    """

    def __init__(
        self,
        k1: float = 1.5,
        b: float = 0.75,
        idf_floor: float = 0.5,
    ) -> None:
        self.k1 = k1
        self.b = b
        self.idf_floor = idf_floor
        self._docs: dict[str, DocEntry] = {}
        self._df: dict[str, int] = Counter()  # document frequency
        self._avgdl: float = 0.0
        self._total_docs = 0

    # ── Indexing ──────────────────────────────────────────────────

    def index(self, doc_id: str, text: str) -> None:
        """Add or update a document in the index."""
        tokens = tokenize(text)
        tf = Counter(tokens)

        # Update global stats
        old_entry = self._docs.get(doc_id)
        if old_entry:
            # Remove old document from DF counts
            for term in old_entry.term_freq:
                self._df[term] = max(0, self._df[term] - 1)
                if self._df[term] == 0:
                    del self._df[term]

        for term in tf:
            self._df[term] += 1

        self._docs[doc_id] = DocEntry(
            doc_id=doc_id,
            text=text,
            tokens=tokens,
            term_freq=dict(tf),
            length=len(tokens),
        )
        self._total_docs = len(self._docs)
        self._avgdl = (
            sum(d.length for d in self._docs.values()) / self._total_docs
            if self._total_docs > 0
            else 0.0
        )

    def index_batch(self, items: list[tuple[str, str]]) -> None:
        """Index multiple documents at once."""
        for doc_id, text in items:
            self.index(doc_id, text)

    def remove(self, doc_id: str) -> bool:
        """Remove a document from the index."""
        entry = self._docs.pop(doc_id, None)
        if not entry:
            return False
        for term in entry.term_freq:
            self._df[term] = max(0, self._df[term] - 1)
            if self._df[term] == 0:
                del self._df[term]
        self._total_docs = len(self._docs)
        self._avgdl = (
            sum(d.length for d in self._docs.values()) / self._total_docs
            if self._total_docs > 0
            else 0.0
        )
        return True

    # ── Search ────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        top_k: int = 10,
        min_score: float = 0.0,
    ) -> list[tuple[str, float]]:
        """Search for documents matching the query.

        Returns:
            List of (doc_id, score) tuples, sorted by descending score.
        """
        if not self._docs:
            return []

        query_tokens = tokenize(query)
        if not query_tokens:
            return []

        # Unique query tokens with their frequency
        qtf = Counter(query_tokens)

        scores: dict[str, float] = defaultdict(float)
        n_docs = self._total_docs

        for term, qf in qtf.items():
            df = self._df.get(term, 0)
            if df == 0:
                continue

            # IDF with smoothing
            idf = math.log((n_docs - df + 0.5) / (df + 0.5) + 1.0)
            idf = max(idf, self.idf_floor)

            # Score each document containing this term
            for doc_id, entry in self._docs.items():
                tf = entry.term_freq.get(term, 0)
                if tf == 0:
                    continue

                # BM25 term weight
                numerator = tf * (self.k1 + 1)
                denominator = tf + self.k1 * (
                    1 - self.b + self.b * (entry.length / self._avgdl)
                )
                scores[doc_id] += idf * (numerator / denominator) * qf

        # Sort and filter
        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        if min_score > 0:
            ranked = [(did, s) for did, s in ranked if s >= min_score]
        return ranked[:top_k]

    def search_with_snippets(
        self,
        query: str,
        top_k: int = 10,
        snippet_len: int = 120,
    ) -> list[dict[str, Any]]:
        """Search and return results with context snippets.

        Returns:
            List of dicts with keys: doc_id, score, text, snippet.
        """
        results = self.search(query, top_k)
        return [
            {
                "doc_id": did,
                "score": round(score, 4),
                "text": self._docs[did].text[:500],
                "snippet": self._extract_snippet(self._docs[did].text, query, snippet_len),
            }
            for did, score in results
        ]

    def _extract_snippet(self, text: str, query: str, max_len: int) -> str:
        """Extract a relevant snippet around query terms."""
        query_terms = set(tokenize(query))
        if not query_terms:
            return text[:max_len]

        # Find best window
        tokens = tokenize(text)
        best_start = 0
        best_score = 0

        for i in range(len(tokens)):
            score = sum(
                1 for t in tokens[i : i + max_len // 2]
                if t in query_terms
            )
            if score > best_score:
                best_score = score
                best_start = i

        # Reconstruct snippet from original text
        # Use character-level window around the matched position
        char_pos = 0
        tok_count = 0
        for ch in text:
            if tok_count >= best_start:
                break
            if _is_cjk(ch) or (ch.isalnum() and (
                tok_count == 0
                or (char_pos > 0 and not text[char_pos - 1].isalnum())
                or char_pos == 0
            )):
                tok_count += 1
            char_pos += 1

        start = max(0, char_pos - max_len // 2)
        end = min(len(text), char_pos + max_len // 2)
        snippet = text[start:end].strip()
        if start > 0:
            snippet = "…" + snippet
        if end < len(text):
            snippet = snippet + "…"
        return snippet

    # ── Stats ─────────────────────────────────────────────────────

    @property
    def document_count(self) -> int:
        return self._total_docs

    @property
    def vocabulary_size(self) -> int:
        return len(self._df)

    def stats(self) -> dict[str, Any]:
        return {
            "documents": self.document_count,
            "vocabulary_size": self.vocabulary_size,
            "avg_doc_length": round(self._avgdl, 1),
            "bm25_params": {"k1": self.k1, "b": self.b},
        }

    # ── Persistence ───────────────────────────────────────────────

    def save(self, path: str | Path) -> None:
        """Save index to a JSON file."""
        data = {
            "docs": {
                did: {"text": d.text, "tokens": d.tokens}
                for did, d in self._docs.items()
            },
            "df": dict(self._df),
            "avgdl": self._avgdl,
            "params": {"k1": self.k1, "b": self.b, "idf_floor": self.idf_floor},
        }
        Path(path).write_text(_json.dumps(data, ensure_ascii=False, indent=2))

    @classmethod
    def load(cls, path: str | Path) -> SemanticSearcher:
        """Load index from a JSON file."""
        data = _json.loads(Path(path).read_text())
        params = data.get("params", {})
        searcher = cls(
            k1=params.get("k1", 1.5),
            b=params.get("b", 0.75),
            idf_floor=params.get("idf_floor", 0.5),
        )
        for doc_id, doc_data in data["docs"].items():
            searcher.index(doc_id, doc_data["text"])
        # Restore DF counts exactly
        searcher._df = Counter(data["df"])
        searcher._avgdl = data["avgdl"]
        searcher._total_docs = len(searcher._docs)
        return searcher
