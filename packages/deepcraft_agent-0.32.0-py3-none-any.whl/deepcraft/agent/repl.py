"""REPL and single-run entry points for DeepCraft."""

from __future__ import annotations

import asyncio
import glob as _glob
import json
import os
import shlex

try:
    import readline
    _HAS_READLINE = True
except ImportError:
    _HAS_READLINE = False
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt
from rich.table import Table

from deepcraft import __version__
from deepcraft.agent.autonomous import AutonomousRunner
from deepcraft.agent.branch import BranchManager
from deepcraft.agent.code_index import build_index as build_code_index
from deepcraft.agent.code_review import ReviewEngine
from deepcraft.agent.context import CompressionStrategy, ContextManager
from deepcraft.agent.diff_view import DiffViewer
from deepcraft.agent.knowledge import KnowledgeBase
from deepcraft.agent.loop import Agent
from deepcraft.agent.mcp.client import MCPManager
from deepcraft.agent.mesh import AgentMesh, AgentRole
from deepcraft.agent.modes import AgentMode
from deepcraft.agent.pr_workflow import PRWorkflow
from deepcraft.agent.refactor import AtomicRefactor, FileChange, RefactorPlan
from deepcraft.agent.sandbox import DockerSandbox, SandboxMode
from deepcraft.agent.semantic_search import SemanticSearcher
from deepcraft.agent.session_memory import SessionMemory
from deepcraft.agent.skills import SkillLoader
from deepcraft.agent.symbol_index import SymbolIndex
from deepcraft.agent.test_gen import TestGenerator
from deepcraft.agent.tools.base import ToolRegistry
from deepcraft.agent.tools.branch_tools import (
    BranchCompareTool,
    BranchCreateTool,
    BranchListTool,
    BranchMergeTool,
    BranchSwitchTool,
)
from deepcraft.agent.tools.checkpoint import CheckpointManager
from deepcraft.agent.tools.code_review import ReviewCommentTool, ReviewPRTool
from deepcraft.agent.tools.diff_view import DiffPreviewTool, DiffTool
from deepcraft.agent.tools.file import ReadFileTool, SearchFilesTool, WriteFileTool
from deepcraft.agent.tools.git_tool import GitTool
from deepcraft.agent.tools.knowledge import KnowledgeAddTool, KnowledgeSearchTool
from deepcraft.agent.tools.pr_tools import (
    CreatePRTool,
    ListPRsTool,
    MergePRTool,
    PRStatusTool,
)
from deepcraft.agent.tools.refactor import RefactorTool
from deepcraft.agent.tools.sandbox import SandboxTool
from deepcraft.agent.tools.search_replace import SearchReplaceTool
from deepcraft.agent.tools.semantic_search import SemanticIndexTool, SemanticSearchTool
from deepcraft.agent.tools.session_memory import MemorySaveTool, MemorySearchTool
from deepcraft.agent.tools.symbol_nav import (
    FindReferencesTool,
    GotoDefinitionTool,
    RenameSymbolTool,
)
from deepcraft.agent.tools.terminal import TerminalTool
from deepcraft.agent.tools.test_gen import TestGenTool
from deepcraft.agent.tools.web_search import WebFetchTool, WebSearchTool
from deepcraft.config import COMPRESSION_STRATEGY, PROVIDER, _get_provider_config, parse_mcp_servers
from deepcraft.memory import MemoryStore
from deepcraft.providers import create_provider
from deepcraft.session import SessionRecorder

console = Console()


def _create_agent() -> Agent:
    """Create a fully configured agent with default tools."""
    tools = ToolRegistry()
    checkpoint = CheckpointManager(max_snapshots=30)

    # File tools with checkpoint
    write_tool = WriteFileTool()
    write_tool.checkpoint_manager = checkpoint
    search_replace_tool = SearchReplaceTool()
    search_replace_tool.checkpoint_manager = checkpoint

    tools.register(ReadFileTool())
    tools.register(write_tool)
    tools.register(SearchFilesTool())
    tools.register(TerminalTool())
    tools.register(GitTool())
    tools.register(WebSearchTool())
    tools.register(WebFetchTool())
    tools.register(search_replace_tool)
    tools.register(DiffTool())
    tools.register(DiffPreviewTool())

    provider_config = _get_provider_config(PROVIDER)
    llm = create_provider(PROVIDER, provider_config)
    ctx = ContextManager(
        llm=llm,
        strategy=CompressionStrategy(COMPRESSION_STRATEGY),
    )
    return Agent(
        llm=llm,
        tools=tools,
        context=ctx,
    )


def _create_agent_with_checkpoint() -> tuple[Agent, CheckpointManager]:
    """Create agent + checkpoint manager (exposed for slash commands)."""
    agent = _create_agent()
    # Find the checkpoint manager from one of the file tools
    write_tool = agent.tools.get("write_file")
    if write_tool and hasattr(write_tool, "checkpoint_manager"):
        return agent, write_tool.checkpoint_manager
    return agent, CheckpointManager()


async def _connect_mcp_servers(agent: Agent, mcp_manager: MCPManager) -> None:
    """Connect all configured MCP servers and register their tools."""
    servers = parse_mcp_servers()
    if not servers:
        return

    console.print("\n[dim]Connecting MCP servers...[/]")
    for srv in servers:
        name = srv["name"]
        try:
            if "url" in srv:
                headers = srv.get("headers")
                await mcp_manager.connect_http_server(name, srv["url"], headers=headers)
                console.print(f"  ✅ [green]{name}[/] (HTTP) connected")
            elif "command" in srv:
                argv = shlex.split(srv["command"])
                await mcp_manager.connect_server(name, argv)
                console.print(f"  ✅ [green]{name}[/] (stdio) connected")
            else:
                console.print(f"  ⚠️  [yellow]{name}[/] — missing command or url")
        except Exception as e:
            console.print(f"  ❌ [red]{name}[/] — {e}")


def run_repl() -> None:
    """Start the interactive REPL loop."""
    console.print(
        Panel.fit(
            f"DeepCraft v{__version__} — DeepSeek-powered AI coding agent\nType /help for commands, /quit to exit",
            title="DeepCraft",
            border_style="blue",
        )
    )

    agent = _create_agent()
    mcp_manager = MCPManager(agent.tools)
    current_mode = AgentMode.AUTO
    recorder = SessionRecorder()
    memory = MemoryStore(llm=agent.llm)

    # Checkpoint manager
    write_tool = agent.tools.get("write_file")
    checkpoint_mgr = (
        write_tool.checkpoint_manager
        if write_tool and hasattr(write_tool, "checkpoint_manager")
        else CheckpointManager()
    )

    # Agent Mesh: multi-agent orchestration
    mesh = AgentMesh(provider_factory=lambda: create_provider(PROVIDER, _get_provider_config(PROVIDER)))
    mesh._router_llm = agent.llm  # Use main agent's LLM for routing
    mesh.setup_defaults()

    # Sandbox: Docker container for isolated command execution
    sandbox = DockerSandbox()
    sandbox_tool = SandboxTool(sandbox)
    agent.tools.register(sandbox_tool)

    # Knowledge Base: RAG semantic search
    kb = KnowledgeBase()
    try:
        kb_ok = kb.load()
    except Exception as e:
        kb_ok = False
        console.print(f"  [yellow]⚠ KB: {e}[/]")
    if kb_ok:
        kbs = kb.stats()
        ndocs = kbs["documents"]
        nchunks = kbs["chunks"]
        console.print(f"[dim]KB loaded: {ndocs} docs, {nchunks} chunks[/]")
    else:
        console.print("[dim]KB: empty (use /knowledge add <path> to index)[/]")
    agent.tools.register(KnowledgeSearchTool(kb))
    agent.tools.register(KnowledgeAddTool(kb))

    # Skills — load builtin skills, display summary
    skills_dir = Path(__file__).parent / "skills" / "builtin"
    builtin_skills = SkillLoader.load_from_dir(skills_dir)
    if builtin_skills:
        names = ", ".join(s.name for s in builtin_skills)
        console.print(f"[dim]Skills: {len(builtin_skills)} loaded ({names})[/]")
    else:
        console.print("[dim]Skills: none loaded[/]")
    agent.skills = builtin_skills

    # Test Generator: auto-generate pytest skeletons
    test_gen = TestGenerator()
    agent.tools.register(TestGenTool(test_gen))
    console.print("[dim]Tools: test_gen registered[/]")

    # Atomic Refactor: multi-file changes with rollback
    refactor = AtomicRefactor(checkpoint_mgr)
    agent.tools.register(RefactorTool(refactor))
    console.print("[dim]Tools: refactor registered[/]")

    # Symbol Index: go-to-def, find-refs, rename
    sym_index = SymbolIndex()
    agent.tools.register(GotoDefinitionTool(sym_index))
    agent.tools.register(FindReferencesTool(sym_index))
    agent.tools.register(RenameSymbolTool(sym_index))

    # Diff Viewer: visual diffs with Rich rendering
    diff_viewer = DiffViewer(context_lines=3, max_width=120)
    dt = agent.tools.get("diff_view")
    if dt and hasattr(dt, "_viewer"):
        dt._viewer = diff_viewer
    dpt = agent.tools.get("diff_preview")
    if dpt and hasattr(dpt, "_viewer"):
        dpt._viewer = diff_viewer
    console.print("[dim]Tools: diff_view, diff_preview registered[/]")

    # PR Workflow: create/list/status/merge GitHub PRs
    try:
        prwf = PRWorkflow.auto()
        agent.tools.register(CreatePRTool(prwf))
        agent.tools.register(ListPRsTool(prwf))
        agent.tools.register(PRStatusTool(prwf))
        agent.tools.register(MergePRTool(prwf))
        console.print(f"[dim]PR Workflow: {prwf.owner}/{prwf.repo}[/]")
    except Exception as e:
        prwf = None
        console.print(f"[dim]PR Workflow: not available ({e})[/]")

    # Code Review Engine
    if prwf:
        review_engine = ReviewEngine(prwf)
        agent.tools.register(ReviewPRTool(review_engine))
        agent.tools.register(ReviewCommentTool(review_engine))
        console.print("[dim]Tools: code_review, review_pr, review_comment registered[/]")
    else:
        review_engine = None

    # Semantic Search Engine — lightweight creation, tools register now,
    # then parallel I/O-heavy file scanning below
    semantic_searcher = SemanticSearcher()
    agent.tools.register(SemanticSearchTool(semantic_searcher))
    agent.tools.register(SemanticIndexTool(semantic_searcher))

    # Session Memory — cross-session persistent memory
    session_mem = SessionMemory(agent=agent)
    agent.tools.register(MemorySearchTool(session_mem))
    agent.tools.register(MemorySaveTool(session_mem))

    # ─── Parallel I/O-heavy initialization ───

    def _build_symbols() -> tuple[int, int]:
        sym_index.build(os.getcwd())
        st = sym_index.stats()
        return st["symbols"], st["references"]

    def _scan_semantic() -> int:
        cache_path = Path(".deepcraft/semantic_index.json")
        # Try loading from cache
        if cache_path.exists():
            try:
                cache_data = json.loads(cache_path.read_text())
                cached_mtimes: dict[str, float] = cache_data.get("file_mtimes", {})
                if cached_mtimes:
                    stale = False
                    for f in _glob.iglob(
                        "**/*.py", root_dir=os.getcwd(), recursive=True
                    ):
                        if "/.venv/" in f or "/venv/" in f or "/__pycache__/" in f:
                            continue
                        current = Path(f).stat().st_mtime
                        cached = cached_mtimes.get(f, 0)
                        if abs(current - cached) > 1.0:
                            stale = True
                            break
                    if not stale:
                        loaded = SemanticSearcher.load(cache_path)
                        semantic_searcher._docs = loaded._docs
                        semantic_searcher._df = loaded._df
                        semantic_searcher._avgdl = loaded._avgdl
                        semantic_searcher._total_docs = loaded._total_docs
                        return loaded.document_count
            except Exception:
                pass  # Cache corrupt or incompatible — rebuild
        # Full rebuild
        count = 0
        file_mtimes: dict[str, float] = {}
        for f in _glob.iglob("**/*.py", root_dir=os.getcwd(), recursive=True):
            if "/.venv/" in f or "/venv/" in f or "/__pycache__/" in f:
                continue
            try:
                content = Path(f).read_text(encoding="utf-8")
                semantic_searcher.index(f, content)
                file_mtimes[f] = Path(f).stat().st_mtime
                count += 1
            except Exception:
                pass
        # Persist cache with mtime snapshot
        try:
            semantic_searcher.save(cache_path)
            data = json.loads(cache_path.read_text())
            data["file_mtimes"] = file_mtimes
            cache_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))
        except Exception:
            pass
        return count

    def _build_code_index() -> None:
        nonlocal code_index
        code_index = build_code_index(os.getcwd(), cache=True)

    def _load_session() -> None:
        session_mem.load()

    code_index = None
    init_tasks = {
        "Symbol index": _build_symbols,
        "Semantic index": _scan_semantic,
        "Codebase index": _build_code_index,
        "Session memory": _load_session,
    }
    results: dict[str, object] = {}
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures_map = {pool.submit(fn): name for name, fn in init_tasks.items()}
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            pbar = progress.add_task("[dim]Initializing...", total=len(futures_map))
            for future in as_completed(futures_map):
                name = futures_map[future]
                try:
                    results[name] = future.result()
                    progress.advance(pbar, description=f"[dim]{name} ✓[/]")
                except Exception as e:
                    console.print(f"  [yellow]⚠ {name}: {e}[/]")
                    progress.advance(pbar)

    # Report results
    if "Symbol index" in results:
        ns, nr = results["Symbol index"]
        console.print(f"[dim]Symbols indexed: {ns} symbols, {nr} refs[/]")
    if "Semantic index" in results:
        count = results["Semantic index"]
        if count > 0:
            console.print(
                f"[dim]Semantic index: {count} source files, "
                f"{semantic_searcher.vocabulary_size} terms[/]"
            )
    if "Session memory" in results:
        st = session_mem.stats()
        console.print(f"[dim]Session Memory: {st['total']} facts loaded[/]")
    if "Codebase index" in results and code_index is not None:
        index_ctx = code_index.to_context(max_items=60)
        if len(index_ctx) > 100:
            agent.ctx.set_codebase_index(index_ctx)
        console.print(
            f"[dim]Codebase indexed: {code_index.total_files} files, "
            f"{code_index.total_functions} functions, "
            f"{code_index.total_classes} classes[/]"
        )

    # Summarize missing modules
    missing: list[str] = []
    if "Symbol index" not in results:
        missing.append("Symbol index")
    if "Semantic index" not in results:
        missing.append("Semantic index")
    if "Codebase index" not in results or code_index is None:
        missing.append("Codebase index")
    if "Session memory" not in results:
        missing.append("Session memory")
    if missing:
        console.print(f"  [yellow]⚠ Not loaded: {', '.join(missing)}[/]")
    elif results:
        console.print("  [dim]All modules loaded ✓[/]")

    # Inject relevant memories into context (needs session_mem loaded)
    mem_context = session_mem.inject("", top_k=8)
    if mem_context:
        agent.ctx.add_message("user", mem_context)

    # Load recent memories into context on startup
    recent = memory.load_recent(5)
    if recent:
        agent.ctx.add_message("user", recent)

    # Conversation Branching — fork, switch, compare, merge
    branch_mgr = BranchManager()
    b_list_tool = BranchListTool()
    b_list_tool._manager = branch_mgr  # type: ignore[attr-defined]
    b_create_tool = BranchCreateTool()
    b_create_tool._manager = branch_mgr  # type: ignore[attr-defined]
    b_create_tool._context = agent.ctx  # type: ignore[attr-defined]
    b_create_tool._current_mode = current_mode  # type: ignore[attr-defined]
    b_create_tool._checkpoint_mgr = checkpoint_mgr  # type: ignore[attr-defined]
    b_switch_tool = BranchSwitchTool()
    b_switch_tool._manager = branch_mgr  # type: ignore[attr-defined]
    b_compare_tool = BranchCompareTool()
    b_compare_tool._manager = branch_mgr  # type: ignore[attr-defined]
    b_merge_tool = BranchMergeTool()
    b_merge_tool._manager = branch_mgr  # type: ignore[attr-defined]
    agent.tools.register(b_list_tool)
    agent.tools.register(b_create_tool)
    agent.tools.register(b_switch_tool)
    agent.tools.register(b_compare_tool)
    agent.tools.register(b_merge_tool)
    console.print(f"[dim]Branching: {branch_mgr.current_branch} (create/switch/compare/merge)[/]")

    # ─── Tab completion (readline) ───
    _slash_commands = [
        "agent", "auto", "branch", "cache", "checkpoint", "checkpoints",
        "clear", "def", "diff", "diff-review", "diff-side", "exit",
        "export", "help", "hover", "index", "knowledge", "mcp",
        "mem", "memory", "mesh", "mode", "pr", "q",
        "quit", "record", "refactor", "refs", "rename", "replay",
        "review", "rollback", "sandbox", "search", "status", "test-gen",
    ]

    def _completer(text: str, state: int) -> str | None:
        """Readline completer: / commands + file paths."""
        if text.startswith("/"):
            prefix = text[1:]
            matches = [f"/{c} " for c in _slash_commands if c.startswith(prefix)]
            return matches[state] if state < len(matches) else None
        # File path completion
        matches = _glob.glob(text + "*")
        if not matches:
            matches = _glob.glob(text + "**/*", recursive=True)[:20]
        matches = [m + ("/" if os.path.isdir(m) else " ") for m in sorted(matches)]
        return matches[state] if state < len(matches) else None

    if _HAS_READLINE:
        readline.set_completer(_completer)
        readline.parse_and_bind("tab: complete")
        console.print("[dim]Tab completion: /commands + file paths[/]")

    async def repl() -> None:
        nonlocal current_mode

        # Connect MCP servers on startup
        await _connect_mcp_servers(agent, mcp_manager)

        try:
            while True:
                try:
                    user_input = Prompt.ask("\n[bold green]▸[/]")
                except (KeyboardInterrupt, EOFError):
                    console.print("\nGoodbye!")
                    break

                if not user_input.strip():
                    continue

                # Commands
                if user_input.startswith("/"):
                    cmd = user_input[1:].strip().lower()
                    if cmd in ("quit", "exit", "q"):
                        # Session summary
                        msgs = agent.ctx.get_full_messages()
                        user_msgs = [m for m in msgs if m.role == "user" and m.content]
                        if len(user_msgs) > 1 and agent.llm:
                            from deepcraft.agent.types import ChatMessage
                            recent = msgs[-12:]
                            conv_text = "\n".join(
                                f"[{m.role}] {m.content or ''}"[:200]
                                for m in recent if m.role != "system"
                            )
                            try:
                                summary_resp = agent.llm.chat(
                                    messages=[ChatMessage(
                                        role="user",
                                        content=(
                                            "Summarize this coding session in one sentence "
                                            "(Chinese): what was worked on, what was "
                                            "accomplished, any key decisions.\n\n"
                                            f"{conv_text}"
                                        ),
                                    )],
                                )
                                if summary_resp:
                                    # Extract summary from streaming response
                                    summary = ""
                                    async for chunk in summary_resp:
                                        if chunk.delta and chunk.delta.content:
                                            summary += chunk.delta.content
                                    if summary.strip():
                                        console.print(
                                            f"\n[dim]📝 {summary.strip()}[/]"
                                        )
                            except Exception:
                                pass  # Summary is optional
                        console.print("Goodbye!")
                        if sandbox:
                            sandbox.cleanup()
                        kb.save()
                        break
                    elif cmd == "help":
                        sections = [
                            ("💬 会话", [
                                ("/quit, /exit, /q", "Exit"),
                                ("/help", "Show commands"),
                                ("/clear", "Clear conversation"),
                                ("/status", "Token usage, tools, mode"),
                                ("/cache", "Prompt cache layers"),
                                ("/mode react|plan|sub|auto", "Switch agent mode"),
                            ]),
                            ("📁 文件 & 导航", [
                                ("/diff <file> [vs]", "Git diff or compare files"),
                                ("/diff-side <a> <b>", "Side-by-side diff"),
                                ("/diff-review", "All uncommitted changes"),
                                ("/def <symbol>", "Go to definition"),
                                ("/refs <symbol>", "Find all references"),
                                ("/rename <old> <new>", "Rename symbol"),
                                ("/hover <file:line>", "Symbol info at cursor"),
                                ("/index", "Codebase index stats"),
                            ]),
                            ("🔧 重构 & 安全", [
                                ("/refactor <desc>", "Atomic multi-file refactor"),
                                ("/checkpoint", "Save file snapshot"),
                                ("/rollback [N]", "Restore snapshot N"),
                                ("/checkpoints", "List all snapshots"),
                            ]),
                            ("🔍 搜索 & 知识", [
                                ("/search <query>", "BM25 semantic search"),
                                ("/search index <id> <text>", "Index a document"),
                                ("/search stats", "Search index stats"),
                                ("/knowledge", "KB status"),
                                ("/knowledge add <path>", "Add doc to KB"),
                                ("/knowledge search <q>", "Search KB"),
                                ("/knowledge clear", "Clear KB"),
                            ]),
                            ("🧠 记忆", [
                                ("/mem search <query>", "Cross-session memory"),
                                ("/mem save <key> <val>", "Save memory fact"),
                                ("/mem stats", "Memory statistics"),
                                ("/mem consolidate", "Dedup memories"),
                                ("/memory save <k> <v>", "Save persistent memory"),
                                ("/memory search <q>", "Search persistent"),
                                ("/memory list", "List all memories"),
                                ("/memory clear", "Delete all memories"),
                            ]),
                            ("🔀 PR & Review", [
                                ("/pr create <title>", "Create PR"),
                                ("/pr list [open|closed]", "List PRs"),
                                ("/pr status <N>", "Check PR CI"),
                                ("/pr merge <N>", "Merge PR"),
                                ("/review pr <N>", "Interactive review"),
                                ("/review approve <N>", "Approve PR"),
                                ("/review comment <N> <f:l> <m>", "Line comment"),
                                ("/review request-changes <N> <m>", "Request changes"),
                                ("/review summary <N>", "Quick summary"),
                            ]),
                            ("🤖 多 Agent (A2A)", [
                                ("/agent list", "List nodes"),
                                ("/agent create <n> <r>", "Create agent"),
                                ("/agent run <n> <t>", "Run task"),
                                ("/mesh route <task>", "Auto-route"),
                                ("/mesh pipeline a,b <t>", "Chain a→b"),
                                ("/mesh broadcast a,b <t>", "Parallel execute"),
                            ]),
                            ("🌿 对话分支", [
                                ("/branch list", "List branches"),
                                ("/branch create <name>", "Fork branch"),
                                ("/branch switch <name>", "Switch branch"),
                                ("/branch compare <name>", "LLM diff analysis"),
                                ("/branch merge <name>", "Merge branch"),
                                ("/branch delete <name>", "Delete branch"),
                            ]),
                            ("🔌 MCP & 执行", [
                                ("/mcp", "List MCP servers"),
                                ("/mcp connect <n> <url>", "Connect MCP"),
                                ("/auto <task>", "Autonomous execute"),
                                ("/test-gen <path>", "Generate pytest stubs"),
                                ("/sandbox run <cmd>", "Run in Docker sandbox"),
                                ("/sandbox status", "Sandbox status"),
                                ("/sandbox mode <m>", "Set sandbox mode"),
                            ]),
                            ("📦 导出 & 录制", [
                                ("/export md|json [path]", "Export conversation"),
                                ("/record start", "Start recording"),
                                ("/record stop", "Stop recording"),
                                ("/record status", "Recording status"),
                                ("/replay <path>", "Replay recorded session"),
                            ]),
                        ]
                        console.print(Panel("DeepCraft REPL — 命令速查", border_style="blue"))
                        for title, cmds in sections:
                            t = Table(title=title, show_header=False, box=None,
                                      padding=(0, 1), title_style="bold")
                            t.add_column("cmd", style="bold cyan", no_wrap=True)
                            t.add_column("desc", style="dim")
                            for c, d in cmds:
                                t.add_row(c, d)
                            console.print(t)
                    elif cmd == "clear":
                        agent.ctx.reset()
                        console.print("[dim]Conversation cleared.[/]")
                    elif cmd == "sandbox":
                        st = sandbox.status
                        ctn = st["container"]
                        run = st["running"]
                        img = st["image"]
                        mod = st["mode"]
                        cmds = st["commands_run"]
                        ws = st["workspace"]
                        console.print(
                            f"Container: {ctn}\n"
                            f"Running:   {run}\n"
                            f"Image:     {img}\n"
                            f"Mode:      {mod}\n"
                            f"Commands:  {cmds}\n"
                            f"Workspace: {ws}"
                        )
                    elif cmd.startswith("sandbox run "):
                        cmd_to_run = user_input[13:].strip()
                        result = sandbox.run(cmd_to_run)
                        if result.stdout.strip():
                            console.print(result.stdout.strip())
                        if result.stderr.strip():
                            console.print(f"[red]{result.stderr.strip()}[/]")
                        console.print(f"[dim]exit={result.exit_code}  {result.duration_ms}ms[/]")
                    elif cmd.startswith("sandbox mode "):
                        mode_str = cmd[13:].strip().lower()
                        try:
                            sandbox._config.mode = SandboxMode(mode_str)
                            console.print(f"[green]Sandbox mode: {mode_str}[/]")
                            sandbox.cleanup()  # Restart with new mode
                        except ValueError:
                            console.print(f"[red]Invalid mode: {mode_str}. Use: default, restricted, offline[/]")
                    elif cmd == "cache":
                        console.print(agent.ctx.usage_report)
                    elif cmd == "knowledge":
                        st = kb.stats()
                        docs = kb.list_documents()
                        nd = st["documents"]
                        nc = st["chunks"]
                        nv = st["vocabulary_size"]
                        console.print(f"📚 Knowledge Base: {nd} docs, {nc} chunks\nVocabulary: {nv} terms")
                        if docs:
                            for d in docs:
                                console.print(f"  📄 {d}")
                    elif cmd.startswith("knowledge search "):
                        query = user_input[18:].strip()
                        results = kb.search(query, top_k=5)
                        if not results:
                            console.print("[dim]No results.[/]")
                        else:
                            for i, r in enumerate(results, 1):
                                console.print(f"[bold]#{i}[/] [{r.score:.2f}] {r.chunk.source}")
                                console.print(f"   {r.chunk.text[:200]}...")
                                console.print()
                    elif cmd.startswith("knowledge add "):
                        filepath = user_input[15:].strip()
                        try:
                            n = kb.add_file(filepath)
                            console.print(f"[green]+{n} chunks[/] from {filepath}")
                        except FileNotFoundError:
                            console.print(f"[red]File not found: {filepath}[/]")
                        except Exception as e:
                            console.print(f"[red]{e}[/]")
                    elif cmd == "knowledge clear":
                        kb.clear()
                        console.print("[dim]Knowledge base cleared.[/]")
                    elif cmd.startswith("test-gen "):
                        target_path = user_input[9:].strip()
                        try:
                            p = Path(target_path)
                            if p.is_dir():
                                suites = test_gen.generate_directory(target_path)
                                written = []
                                for suite in suites:
                                    wp = test_gen.write_test_file(suite)
                                    written.append(str(wp))
                                console.print(f"[green]+{len(written)} test files[/]")
                                for w in written:
                                    console.print(f"  📄 {w}")
                            else:
                                suite = test_gen.generate(target_path)
                                wp = test_gen.write_test_file(suite)
                                console.print(f"[green]+{suite.target_count} tests[/] → {wp}")
                        except Exception as e:
                            console.print(f"[red]{e}[/]")
                    elif cmd.startswith("auto "):
                        task = user_input[5:].strip()
                        runner = AutonomousRunner(
                            llm=agent.llm,
                            tools=agent.tools,
                        )
                        report = await runner.run(task, console=console)
                        console.print(f"\n[bold]📋 Report: {report.goal}[/]")
                        for d in report.details:
                            console.print(f"  {d}")
                        console.print(
                            f"\n[bold]{report.summary}[/]\n"
                            f"[dim]{report.steps_done}/{report.steps_total} steps, "
                            f"{report.total_duration_ms}ms[/]"
                        )
                    elif cmd.startswith("refactor "):
                        desc = user_input[9:].strip()
                        console.print(f"[bold cyan]🔧 Refactor: {desc}[/]")
                        console.print("[dim]Enter changes (path old→new), empty line to execute:[/]")
                        changes = []
                        while True:
                            line = Prompt.ask("[dim]  change[/]")
                            if not line.strip():
                                break
                            parts = line.split(" → ", 2)
                            if len(parts) < 3:
                                console.print("[red]Format: path :: old :: new[/]")
                                continue
                            changes.append(
                                FileChange(
                                    path=parts[0].strip(),
                                    old_string=parts[1].strip(),
                                    new_string=parts[2].strip(),
                                )
                            )
                        if changes:
                            plan = RefactorPlan(description=desc, changes=changes)
                            # Preview
                            preview = refactor.preview(plan)
                            console.print(f"[dim]{preview[:1000]}[/]")
                            confirm = Prompt.ask("Apply? [y/N]", default="n")
                            if confirm.lower() == "y":
                                result = refactor.apply(plan)
                                if result.success:
                                    console.print(
                                        f"[green]✅ {result.files_modified} files, "
                                        f"+{result.lines_added}/-{result.lines_removed} lines[/]"
                                    )
                                else:
                                    console.print(f"[red]❌ Rolled back: {result.errors}[/]")
                    elif cmd.startswith("def "):
                        symbol = user_input[4:].strip()
                        locs = sym_index.go_to_definition(symbol)
                        if locs:
                            for loc in locs:
                                console.print(f"📄 {loc.file}:{loc.line} [{loc.kind}]")
                        else:
                            console.print(f"[dim]Symbol not found: {symbol}[/]")
                    elif cmd.startswith("refs "):
                        symbol = user_input[5:].strip()
                        refs = sym_index.find_references(symbol)
                        if refs:
                            for r in refs[:30]:
                                console.print(f"📄 {r.file}:{r.line} [{r.kind}]")
                            if len(refs) > 30:
                                console.print(f"[dim]... and {len(refs) - 30} more[/]")
                        else:
                            console.print(f"[dim]No references: {symbol}[/]")
                    elif cmd.startswith("rename "):
                        parts = user_input[7:].strip().split()
                        if len(parts) < 2:
                            console.print("[red]Usage: /rename old_name new_name[/]")
                        else:
                            old, new = parts[0], parts[1]
                            plan = sym_index.rename_symbol(old, new)
                            if plan:
                                console.print(f"[bold]Rename: {old} → {new}[/]")
                                console.print(f"  Def: {plan.definition.file}:{plan.definition.line}")
                                console.print(f"  Refs: {len(plan.references)} ({plan.total_locations} total)")
                                console.print(f"  Files: {len(plan.changes)}")
                                confirm = Prompt.ask("Apply? [y/N]", default="n")
                                if confirm.lower() == "y":
                                    rp = RefactorPlan(
                                        description=f"Rename {old}→{new}",
                                        changes=[FileChange(**c) for c in plan.changes],
                                    )
                                    result = refactor.apply(rp)
                                    if result.success:
                                        console.print(f"[green]✅ Renamed in {result.files_modified} files[/]")
                                    else:
                                        console.print(f"[red]❌ {result.errors}[/]")
                            else:
                                console.print(f"[dim]Symbol not found: {old}[/]")
                    elif cmd.startswith("hover "):
                        loc_str = user_input[6:].strip()
                        # Parse "file:line" or just symbol name
                        if ":" in loc_str:
                            file, line_str = loc_str.rsplit(":", 1)
                            try:
                                line = int(line_str)
                                info = sym_index.hover(file, line)
                                if info:
                                    console.print(f"[bold]{info.symbol}[/] [{info.kind}]")
                                    if info.signature:
                                        console.print(f"  {info.signature}")
                                    if info.docstring:
                                        console.print(f"  [dim]{info.docstring[:200]}[/]")
                                else:
                                    console.print(f"[dim]No symbol at {file}:{line}[/]")
                            except ValueError:
                                console.print("[red]Format: /hover file.py:line[/]")
                    elif cmd == "status":
                        mcp_count = len(mcp_manager.servers)
                        console.print(
                            f"{agent.ctx.usage_report}\n"
                            f"Mode:   {current_mode.value}\n"
                            f"Tokens: ~{agent.ctx.token_count:,}\n"
                            f"Tools:  {len(agent.tools)} registered"
                            + (f" ({mcp_count} MCP servers)\n" if mcp_count else "\n")
                            + f"Turns:  {agent._turn_count}"
                        )
                    elif cmd.startswith("diff "):
                        args = user_input[5:].strip()
                        if not args:
                            console.print("[red]Usage: /diff <file> [vs_file|--staged][/]")
                            console.print("  /diff file.py        — git diff vs HEAD")
                            console.print("  /diff a.py b.py      — compare two files")
                        elif " " in args:
                            # /diff a.py b.py — compare two files
                            parts = args.split(maxsplit=1)
                            file_a, file_b = parts[0], parts[1]
                            result = diff_viewer.file_diff(file_a, file_b)
                            if result.is_binary:
                                console.print("[dim]Binary file — diff not shown.[/]")
                            elif not result.hunks:
                                console.print("[dim]No differences.[/]")
                            else:
                                panel = diff_viewer.unified_diff(result)
                                console.print(panel)
                        else:
                            # /diff file.py — git diff vs HEAD
                            result = diff_viewer.git_diff(args)
                            if result is None:
                                console.print(
                                    "[dim]No git history or file untracked. Use /diff a.py b.py to compare files.[/]"
                                )
                            elif not result.hunks:
                                console.print(f"[dim]No changes in {args} (vs HEAD).[/]")
                            else:
                                panel = diff_viewer.unified_diff(result)
                                console.print(panel)
                    elif cmd == "diff-side":
                        console.print("[red]Usage: /diff-side a.py b.py[/]")
                    elif cmd.startswith("diff-side "):
                        args = user_input[10:].strip()
                        if " " not in args:
                            console.print("[red]Usage: /diff-side a.py b.py[/]")
                        else:
                            parts = args.split(maxsplit=1)
                            result = diff_viewer.file_diff(parts[0], parts[1])
                            if result.is_binary:
                                console.print("[dim]Binary file — diff not shown.[/]")
                            elif not result.hunks:
                                console.print("[dim]No differences.[/]")
                            else:
                                table = diff_viewer.side_by_side(result)
                                console.print(table)
                    elif cmd.startswith("diff-review"):
                        console.print("[dim]Review last refactor changes...[/]")
                        # Show git diff for working tree
                        import subprocess as _sp

                        try:
                            changed = _sp.check_output(
                                ["git", "diff", "--name-only"],
                                text=True,
                                stderr=_sp.DEVNULL,
                            ).strip()
                            if not changed:
                                console.print("[dim]No uncommitted changes.[/]")
                            else:
                                for f in changed.splitlines():
                                    if not f:
                                        continue
                                    r = diff_viewer.git_diff(f)
                                    if r and r.hunks:
                                        console.print(diff_viewer.unified_diff(r))
                        except Exception:
                            console.print("[dim]git unavailable.[/]")
                    elif cmd.startswith("pr "):
                        # /pr create|list|status|merge
                        subcmd = user_input[3:].strip()
                        if not prwf:
                            console.print("[red]PR Workflow not available. Check GitHub token and git remote.[/]")
                        elif subcmd.startswith("create "):
                            title = subcmd[7:].strip()
                            if not title:
                                console.print("[red]Usage: /pr create <title>[/]")
                            else:
                                try:
                                    body = Prompt.ask("Description (markdown, empty to skip)")
                                    pr_info = prwf.create_pr(title=title, body=body or "")
                                    console.print(f"[green]✅ PR created: {pr_info.url}[/]")
                                    console.print(prwf.format_pr(pr_info))
                                except Exception as e:
                                    console.print(f"[red]{e}[/]")
                        elif subcmd == "list" or subcmd.startswith("list "):
                            state = "open"
                            parts = subcmd.split()
                            if len(parts) > 1 and parts[1] in ("open", "closed", "all"):
                                state = parts[1]
                            try:
                                prs = prwf.list_prs(state=state)
                                if not prs:
                                    console.print(f"[dim]No {state} PRs.[/]")
                                else:
                                    console.print(prwf.format_list(prs))
                            except Exception as e:
                                console.print(f"[red]{e}[/]")
                        elif subcmd.startswith("status "):
                            try:
                                n = int(subcmd.split()[1])
                                status = prwf.pr_status(n)
                                console.print(prwf.format_status(status))
                            except (IndexError, ValueError):
                                console.print("[red]Usage: /pr status <number>[/]")
                            except Exception as e:
                                console.print(f"[red]{e}[/]")
                        elif subcmd.startswith("merge "):
                            parts = subcmd.split()
                            if len(parts) < 2:
                                console.print("[red]Usage: /pr merge <number> [squash|merge|rebase][/]")
                            else:
                                try:
                                    n = int(parts[1])
                                    method = parts[2] if len(parts) > 2 else "squash"
                                    result = prwf.merge_pr(n, method)
                                    if result.get("merged"):
                                        console.print(f"[green]✅ Merged PR #{n} ({method})[/]")
                                    else:
                                        console.print(f"[yellow]{result.get('message', 'Unknown')}[/]")
                                except ValueError:
                                    console.print("[red]PR number must be an integer.[/]")
                                except Exception as e:
                                    console.print(f"[red]{e}[/]")
                        else:
                            console.print("Usage: /pr create|list|status|merge")
                    elif cmd.startswith("review "):
                        # /review pr|approve|comment|request-changes|summary
                        subcmd = user_input[7:].strip()
                        if not review_engine:
                            console.print("[red]Code Review not available. PR Workflow must be configured first.[/]")
                        elif subcmd.startswith("pr "):
                            try:
                                n = int(subcmd.split()[1])
                                if prwf:
                                    pr_info = prwf.get_pr(n)
                                    console.print(f"\n📋 PR #{n}: {pr_info.get('title', 'N/A')}")
                                console.print("[dim]Fetching diff and analyzing...[/]")
                                result = review_engine.fetch_and_analyze(n)
                                console.print(review_engine.format_interactive_menu(result))
                                # Interactive mode
                                for fr in result.files:
                                    console.print(review_engine.format_file_diff(fr))
                                    choice = Prompt.ask(
                                        "  [a]pprove  [c]omment  [s]kip  [q]uit",
                                        choices=["a", "c", "s", "q"],
                                        default="a",
                                    )
                                    if choice == "q":
                                        break
                                    elif choice == "s":
                                        continue
                                    elif choice == "c":
                                        line_str = Prompt.ask("  Line number")
                                        comment = Prompt.ask("  Comment")
                                        try:
                                            commit_id = review_engine.get_pr_head_sha(n)
                                            review_engine.submit_single_comment(
                                                n, commit_id, fr.path,
                                                int(line_str), comment,
                                            )
                                            console.print(f"[green]  ✅ Comment added to {fr.path}:{line_str}[/]")
                                        except Exception as e:
                                            console.print(f"[red]  Failed: {e}[/]")
                                    elif choice == "a":
                                        fr.approved = True
                                        result.approved_files += 1
                                        console.print(f"[green]  ✅ {fr.path} approved[/]")
                                # Final decision
                                console.print(f"\n{result.summary_text}")
                                final = Prompt.ask(
                                    "Submit as: [a]pprove  [c]omment  [r]equest changes  [d]iscard",
                                    choices=["a", "c", "r", "d"],
                                    default="c",
                                )
                                events = {"a": "APPROVE", "c": "COMMENT", "r": "REQUEST_CHANGES"}
                                if final in events:
                                    body = Prompt.ask("Final comment (optional)")
                                    review_engine.submit_review(n, body, events[final])
                                    console.print(f"[green]✅ Review submitted — {events[final]}[/]")
                                else:
                                    console.print("[dim]Review discarded.[/]")
                            except (ValueError, IndexError):
                                console.print("[red]Usage: /review pr <number>[/]")
                            except Exception as e:
                                console.print(f"[red]{e}[/]")
                        elif subcmd.startswith("approve "):
                            try:
                                parts = subcmd.split(maxsplit=1)
                                n = int(parts[0].split()[0] if " " in subcmd else parts[0])
                                msg = parts[1] if len(parts) > 1 and " " in subcmd else (
                                    " ".join(subcmd.split()[1:]) if len(subcmd.split()) > 1 else "LGTM"
                                )
                                # Note: parts handling is tricky — simplify
                                args = subcmd.split()
                                n = int(args[0])
                                msg = " ".join(args[1:]) if len(args) > 1 else "LGTM"
                                review_engine.submit_review(n, msg, "APPROVE")
                                console.print(f"[green]✅ Approved PR #{n}[/]")
                            except Exception as e:
                                console.print(f"[red]{e}[/]")
                        elif subcmd.startswith("comment "):
                            try:
                                # Format: /review comment <N> <file:line> <message>
                                rest = subcmd[8:].strip()
                                parts = rest.split(maxsplit=2)
                                n = int(parts[0])
                                file_line = parts[1] if len(parts) > 1 else ""
                                body = parts[2] if len(parts) > 2 else ""
                                if ":" in file_line:
                                    fpath, line_s = file_line.rsplit(":", 1)
                                    line_no = int(line_s)
                                    commit_id = review_engine.get_pr_head_sha(n)
                                    review_engine.submit_single_comment(n, commit_id, fpath, line_no, body)
                                    console.print(f"[green]✅ Comment on PR #{n} {fpath}:{line_no}[/]")
                                else:
                                    console.print("[red]Format: /review comment <N> <file:line> <message>[/]")
                            except Exception as e:
                                console.print(f"[red]{e}[/]")
                        elif subcmd.startswith("request-changes "):
                            try:
                                rest = subcmd[17:].strip()
                                parts = rest.split(maxsplit=1)
                                n = int(parts[0])
                                msg = parts[1] if len(parts) > 1 else "Please address review comments."
                                review_engine.submit_review(n, msg, "REQUEST_CHANGES")
                                console.print(f"[yellow]⚠ Changes requested on PR #{n}[/]")
                            except Exception as e:
                                console.print(f"[red]{e}[/]")
                        elif subcmd.startswith("summary "):
                            try:
                                n = int(subcmd.split()[1])
                                console.print("[dim]Fetching...[/]")
                                result = review_engine.fetch_and_analyze(n)
                                console.print(result.summary_text)
                                if result.total_issues > 0:
                                    console.print(review_engine.format_issues(result))
                            except Exception as e:
                                console.print(f"[red]{e}[/]")
                        else:
                            console.print("Usage: /review pr|approve|comment|summary <N>")
                    elif cmd.startswith("search "):
                        subcmd = user_input[7:].strip()
                        if subcmd.startswith("index "):
                            parts = subcmd[6:].strip().split(maxsplit=1)
                            if len(parts) < 2:
                                console.print("[red]Usage: /search index <id> <content>[/]")
                            else:
                                semantic_searcher.index(parts[0], parts[1])
                                console.print(
                                    f"[green]✅ Indexed: {parts[0]} "
                                    f"({semantic_searcher.document_count} docs)[/]"
                                )
                        elif subcmd == "stats":
                            st = semantic_searcher.stats()
                            console.print(
                                f"[dim]Semantic Index: {st['documents']} docs, "
                                f"{st['vocabulary_size']} terms, "
                                f"avg length {st['avg_doc_length']}[/]"
                            )
                        else:
                            results = semantic_searcher.search_with_snippets(
                                subcmd, top_k=10
                            )
                            if not results:
                                console.print("[dim]No results. Try different keywords.[/]")
                            else:
                                for i, r in enumerate(results, 1):
                                    console.print(
                                        f"[bold]{i}.[/] [cyan]{r['doc_id']}[/] "
                                        f"[dim](score: {r['score']:.3f})[/]"
                                    )
                                    console.print(f"   {r['snippet']}")
                                    console.print("")
                    elif cmd.startswith("mem "):
                        subcmd = user_input[4:].strip()
                        if subcmd.startswith("search "):
                            query = subcmd[7:].strip()
                            results = session_mem.search(query, top_k=8)
                            if not results:
                                console.print("[dim]No matching memories.[/]")
                            else:
                                for i, r in enumerate(results, 1):
                                    console.print(
                                        f"[bold]{i}.[/] [cyan]{r['doc_id']}[/] "
                                        f"[dim]({r['score']:.3f})[/]"
                                    )
                                    console.print(f"   {r['snippet']}")
                                    console.print("")
                        elif subcmd.startswith("save "):
                            rest = subcmd[5:].strip()
                            parts = rest.split(" ", 1)
                            if len(parts) < 2:
                                console.print("[red]/mem save <key> <value>[/]")
                            else:
                                session_mem.add(parts[0], parts[1])
                                console.print(f"[green]✅ Saved: {parts[0]}[/]")
                        elif subcmd == "stats":
                            st = session_mem.stats()
                            console.print(
                                f"[dim]Memories: {st['total']} "
                                f"(avg importance {st['avg_importance']}) "
                                f"| newest {st['newest_age_hours']}h ago[/]"
                            )
                        elif subcmd == "consolidate":
                            console.print("[dim]Consolidating...[/]")
                            removed = await session_mem.consolidate()
                            console.print(
                                f"[green]✅ Removed {removed} duplicate memories[/]"
                            )
                        else:
                            console.print("/mem search|save|stats|consolidate")
                    elif cmd == "branch" or cmd.startswith("branch "):
                        # /branch list|create|switch|compare|merge|delete
                        if cmd == "branch":
                            console.print(
                                "Usage: /branch list|create <name>|switch <name>|"
                                "compare <name>|merge <name>|delete <name>"
                            )
                            continue
                        subcmd = user_input[8:].strip()
                        if subcmd == "list":
                            branches = branch_mgr.list_branches()
                            if not branches:
                                console.print("[dim]No branches found.[/]")
                            else:
                                table = Table(title="Conversation Branches")
                                table.add_column("Name", style="cyan")
                                table.add_column("Mode")
                                table.add_column("Turns")
                                table.add_column("Tokens")
                                table.add_column("Current")
                                table.add_column("Description")
                                for b in branches:
                                    current_mark = "✅" if b.is_current else ""
                                    table.add_row(
                                        b.name,
                                        b.mode,
                                        str(b.turn_count),
                                        f"{b.token_count:,}",
                                        current_mark,
                                        b.description[:60],
                                    )
                                console.print(table)
                        elif subcmd.startswith("create "):
                            rest = subcmd[7:].strip()
                            parts = rest.split(" ", 1)
                            name = parts[0]
                            desc = parts[1] if len(parts) > 1 else ""
                            try:
                                branch_mgr.create(
                                    name=name,
                                    messages=agent.ctx.export_json(),
                                    token_count=agent.ctx.token_count,
                                    turn_count=agent._turn_count,
                                    mode=current_mode.value,
                                    description=desc,
                                    checkpoint_mgr=checkpoint_mgr,
                                )
                                console.print(
                                    f"[green]✅ Branch '{name}' created from '{branch_mgr.current_branch}'[/]"
                                )
                            except ValueError as e:
                                console.print(f"[red]{e}[/]")
                        elif subcmd.startswith("switch "):
                            name = subcmd[7:].strip()
                            if not branch_mgr.exists(name):
                                console.print(f"[red]Branch '{name}' does not exist[/]")
                            elif name == branch_mgr.current_branch:
                                console.print(f"[dim]Already on branch '{name}'[/]")
                            else:
                                # Save current state
                                branch_mgr.snapshot_current(
                                    messages=agent.ctx.export_json(),
                                    token_count=agent.ctx.token_count,
                                    turn_count=agent._turn_count,
                                    mode=current_mode.value,
                                )
                                # Load target
                                try:
                                    state = branch_mgr.switch(name)
                                    agent.ctx.restore_state(state.messages)
                                    agent._turn_count = state.turn_count
                                    mode_name = state.mode
                                    mode_map = {
                                        "react": AgentMode.REACT,
                                        "plan": AgentMode.PLAN_EXECUTE,
                                        "sub": AgentMode.SUBAGENT,
                                        "auto": AgentMode.AUTO,
                                    }
                                    current_mode = mode_map.get(mode_name, AgentMode.AUTO)
                                    console.print(
                                        f"[green]✅ Switched to '{name}' "
                                        f"({state.turn_count} turns, {state.token_count:,} tokens)[/]"
                                    )
                                except Exception as e:
                                    console.print(f"[red]Failed to switch: {e}[/]")
                        elif subcmd.startswith("compare "):
                            name = subcmd[8:].strip()
                            if not branch_mgr.exists(name):
                                console.print(f"[red]Branch '{name}' does not exist[/]")
                            else:
                                console.print(f"[dim]Analyzing {branch_mgr.current_branch} vs {name}...[/]")
                                try:
                                    proposal = await branch_mgr.compare(
                                        other_branch=name,
                                        llm=agent.llm,
                                        current_messages=agent.ctx.export_json(),
                                    )
                                    console.print(
                                        f"\\n[bold]📊 Branch Comparison: "
                                        f"{proposal.branch_to} vs {proposal.branch_from}[/]\\n"
                                    )
                                    console.print(f"[bold cyan]Current ({proposal.branch_to}):[/]")
                                    console.print(f"  {proposal.summary_to}")
                                    console.print(f"\\n[bold yellow]Other ({proposal.branch_from}):[/]")
                                    console.print(f"  {proposal.summary_from}")
                                    if proposal.conflicts:
                                        console.print("\\n[bold red]⚠ Conflicts:[/]")
                                        for c in proposal.conflicts:
                                            console.print(f"  • {c}")
                                    if proposal.shared_insights:
                                        console.print("\\n[bold green]💡 Shared Insights:[/]")
                                        for s in proposal.shared_insights:
                                            console.print(f"  • {s}")
                                    console.print(
                                        f"\\n[bold]📋 Recommendation:[/] {proposal.recommendation}"
                                    )
                                except Exception as e:
                                    console.print(f"[red]Comparison failed: {e}[/]")
                        elif subcmd.startswith("merge "):
                            name = subcmd[6:].strip()
                            if not branch_mgr.exists(name):
                                console.print(f"[red]Branch '{name}' does not exist[/]")
                            elif name == branch_mgr.current_branch:
                                console.print("[red]Cannot merge a branch into itself[/]")
                            else:
                                console.print(
                                    f"[yellow]⚠ Merging '{name}' into '{branch_mgr.current_branch}'...[/]"
                                )
                                console.print("[dim]Run /branch compare first to review differences.[/]")
                                try:
                                    state = branch_mgr.merge(
                                        from_branch=name,
                                        current_messages=agent.ctx.export_json(),
                                        current_token_count=agent.ctx.token_count,
                                        current_turn_count=agent._turn_count,
                                        current_mode=current_mode.value,
                                    )
                                    agent.ctx.restore_state(state.messages)
                                    console.print(
                                        f"[green]✅ Merged '{name}' into '{branch_mgr.current_branch}'[/]"
                                    )
                                    console.print(
                                        f"[dim]{state.turn_count} turns, {state.token_count:,} tokens[/]"
                                    )
                                except Exception as e:
                                    console.print(f"[red]Merge failed: {e}[/]")
                        elif subcmd.startswith("delete "):
                            name = subcmd[7:].strip()
                            try:
                                branch_mgr.delete(name)
                                console.print(f"[green]✅ Deleted '{name}'[/]")
                            except ValueError as e:
                                console.print(f"[red]{e}[/]")
                        else:
                            console.print(
                                "Usage: /branch list|create <name>|switch <name>|"
                                "compare <name>|merge <name>|delete <name>"
                            )
                    elif cmd == "mode":
                        console.print(f"Current mode: {current_mode.value}")
                    elif cmd == "index":
                        if code_index:
                            console.print(code_index.to_context(max_items=200))
                        else:
                            console.print("[dim]No codebase index available.[/]")
                    elif cmd == "checkpoint":
                        sid = checkpoint_mgr.save_before_write(".")
                        console.print(f"[green]✅ Checkpoint #{sid} saved[/]")
                    elif cmd == "checkpoints":
                        snaps = checkpoint_mgr.list_snapshots()
                        if not snaps:
                            console.print("[dim]No checkpoints yet.[/]")
                        else:
                            for s in snaps:
                                console.print(f"  #{s['id']} {s['filename']} ({s['timestamp'][:19]})")
                    elif cmd.startswith("rollback"):
                        parts = cmd.split()
                        sid = int(parts[1]) if len(parts) > 1 else None
                        result = checkpoint_mgr.rollback(sid)
                        if result:
                            console.print(
                                f"[green]⏪ Rolled back to snapshot{' #' + str(sid) if sid else ''} → {result}[/]"
                            )
                        else:
                            console.print("[dim]No checkpoints to rollback.[/]")
                    elif cmd == "record" or cmd == "record " or cmd.startswith("record "):
                        sub = cmd[7:] if cmd.startswith("record ") else ""
                        if sub == "start":
                            if recorder.is_recording:
                                console.print("[yellow]Already recording.[/]")
                            else:
                                path = recorder.start()
                                console.print(f"[green]🔴 Recording started → {path}[/]")
                        elif sub == "stop":
                            if not recorder.is_recording:
                                console.print("[dim]Not recording.[/]")
                            else:
                                path = recorder.stop()
                                console.print(f"[green]⏹ Recording stopped → {path}[/]")
                        elif sub in ("status", ""):
                            if recorder.is_recording:
                                size = ""
                                if recorder.path.exists():
                                    size = f", {recorder.path.stat().st_size} bytes"
                                console.print(f"[cyan]🔴 Recording → {recorder.path}{size}[/]")
                            else:
                                console.print("[dim]Not recording. Use /record start[/]")
                        else:
                            console.print("Usage: /record start|stop|status")
                    elif cmd.startswith("replay "):
                        replay_path = user_input[8:].strip()
                        SessionRecorder.replay(replay_path, console=console)
                    elif cmd == "memory" or cmd == "memory ":
                        console.print(
                            "Memory commands:\n"
                            "  /memory save <key> <value> — Save a memory\n"
                            "  /memory search <query>  — Search memories\n"
                            "  /memory list           — List all memories\n"
                            "  /memory clear          — Delete all memories"
                            "  /index — Show codebase index\n"
                        )
                    elif cmd.startswith("memory save "):
                        parts = user_input.split(maxsplit=3)
                        if len(parts) < 4:
                            console.print("Usage: /memory save <key> <value>")
                        else:
                            entry = memory.save(parts[2], parts[3])
                            console.print(f"[green]Saved: {entry.key}[/]")
                    elif cmd.startswith("memory search "):
                        query = user_input[15:].strip()
                        if not query:
                            console.print("Usage: /memory search <query>")
                        else:
                            results = await memory.search(query)
                            if not results:
                                console.print("[dim]No matching memories.[/]")
                            else:
                                for m in results:
                                    console.print(f"[cyan]{m.key}[/]: {m.value[:200]}")
                    elif cmd == "memory list":
                        entries = memory.list()
                        if not entries:
                            console.print("[dim]No memories yet.[/]")
                        else:
                            for m in entries:
                                ts = m.timestamp[:10]
                                console.print(f"[cyan]{m.key}[/] [{ts}]: {m.value[:150]}")
                    elif cmd == "memory clear":
                        memory.clear()
                        console.print("[dim]All memories cleared.[/]")
                    elif cmd == "agent list":
                        nodes = mesh.list_nodes()
                        if not nodes:
                            console.print("[dim]No agent nodes.[/]")
                        else:
                            for n in nodes:
                                prompt_preview = n.system_prompt[:60].replace("\n", " ")
                                console.print(f"  [cyan]{n.name}[/] [{n.role.value}] {prompt_preview}...")
                    elif cmd.startswith("agent create "):
                        parts = user_input.split(maxsplit=3)
                        if len(parts) < 3:
                            console.print("Usage: /agent create <name> <role> [coder|reviewer|researcher|planner]")
                        else:
                            name = parts[2]
                            role_str = parts[3] if len(parts) > 3 else "coder"
                            try:
                                role = AgentRole(role_str)
                            except ValueError:
                                console.print(f"Unknown role: {role_str}. Use: coder, reviewer, researcher, planner")
                                continue
                            try:
                                mesh.add_node(name, role)
                                console.print(f"[green]Created agent: {name} ({role})[/]")
                            except ValueError as e:
                                console.print(f"[red]{e}[/]")
                    elif cmd.startswith("agent run "):
                        parts = user_input.split(maxsplit=2)
                        if len(parts) < 3:
                            console.print("Usage: /agent run <name> <task>")
                        else:
                            rest = parts[2].split(maxsplit=1)
                            name = rest[0]
                            task = rest[1] if len(rest) > 1 else ""
                            if not task:
                                console.print("Usage: /agent run <name> <task>")
                            else:
                                result = (
                                    await mesh.route(task)
                                    if name == "auto"
                                    else await mesh._execute_node(mesh.get_node(name), task, label=name)
                                    if mesh.get_node(name)
                                    else None
                                )
                                if result is None:
                                    console.print(f"[red]Node '{name}' not found.[/]")
                                elif result.success:
                                    console.print(
                                        f"\n[bold cyan]{result.node_name}[/] ([{result.role}]):\n{result.output}"
                                    )
                                else:
                                    console.print(f"[red]{result.error}[/]")
                    elif cmd.startswith("mesh route "):
                        task = user_input[12:].strip()
                        if not task:
                            console.print("Usage: /mesh route <task>")
                        else:
                            result = await mesh.route(task)
                            if result.success:
                                console.print(f"\n[bold cyan]{result.node_name}[/] ([{result.role}]):\n{result.output}")
                            else:
                                console.print(f"[red]{result.error}[/]")
                    elif cmd.startswith("mesh pipeline "):
                        rest = user_input[15:].strip()
                        space_idx = rest.find(" ")
                        if space_idx == -1:
                            console.print("Usage: /mesh pipeline n1,n2 <task>")
                        else:
                            nodes_str = rest[:space_idx]
                            task = rest[space_idx + 1 :].strip()
                            node_names = [n.strip() for n in nodes_str.split(",") if n.strip()]
                            if not node_names or not task:
                                console.print("Usage: /mesh pipeline n1,n2 <task>")
                            else:
                                result = await mesh.pipeline(node_names, task)
                                if result.success:
                                    console.print(
                                        f"\n[bold cyan]Pipeline done ({result.duration_ms}ms)[/]:\n{result.output}"
                                    )
                                else:
                                    console.print(f"[red]Pipeline failed at {result.node_name}: {result.error}[/]")
                    elif cmd.startswith("mesh broadcast "):
                        rest = user_input[16:].strip()
                        space_idx = rest.find(" ")
                        if space_idx == -1:
                            console.print("Usage: /mesh broadcast n1,n2 <task>")
                        else:
                            nodes_str = rest[:space_idx]
                            task = rest[space_idx + 1 :].strip()
                            node_names = [n.strip() for n in nodes_str.split(",") if n.strip()]
                            if not node_names or not task:
                                console.print("Usage: /mesh broadcast n1,n2 <task>")
                            else:
                                results = await mesh.broadcast(node_names, task)
                                for r in results:
                                    status = "✅" if r.success else "❌"
                                    msg = (
                                        f"\n{status} [cyan]{r.node_name}[/]"
                                        f" [{r.role}] ({r.duration_ms}ms):\n{r.output[:500]}"
                                    )
                                    console.print(msg)
                                # Synthesize
                                syn = await mesh.synthesize(task, results)
                                console.print(f"\n[bold]🧠 Synthesis:[/]\n{syn}")
                    elif cmd.startswith("mode "):
                        mode_name = cmd[5:].strip()
                        mode_map = {
                            "react": AgentMode.REACT,
                            "plan": AgentMode.PLAN_EXECUTE,
                            "sub": AgentMode.SUBAGENT,
                            "auto": AgentMode.AUTO,
                        }
                        if mode_name in mode_map:
                            current_mode = mode_map[mode_name]
                            console.print(f"[cyan]Mode set to: {current_mode.value}[/]")
                        else:
                            console.print(f"Unknown mode: {mode_name}")
                    elif cmd == "mcp" or cmd == "mcp ":
                        # /mcp — list servers & tools
                        if not mcp_manager.servers:
                            console.print("[dim]No MCP servers connected.[/]")
                            console.print(
                                "Configure via DEEPCRAFT_MCP_SERVERS env var, "
                                "e.g. github:npx -y @modelcontextprotocol/server-github"
                            )
                        else:
                            for srv_name in mcp_manager.servers:
                                table = Table(title=f"MCP: {srv_name}")
                                table.add_column("Tool", style="cyan")
                                table.add_column("Description", style="dim")
                                prefix = f"mcp_{srv_name}_"
                                for t in agent.tools.list_definitions():
                                    if t.name.startswith(prefix):
                                        table.add_row(
                                            t.name,
                                            t.description[:80],
                                        )
                                console.print(table)
                    elif cmd.startswith("mcp connect "):
                        # /mcp connect <name> <command|url>
                        parts = shlex.split(user_input)
                        if len(parts) < 4:
                            console.print(
                                "Usage: /mcp connect <name> <command>     (stdio)\n"
                                "       /mcp connect <name> <url>         (HTTP)"
                            )
                        else:
                            name = parts[2]
                            target = " ".join(parts[3:])
                            try:
                                if target.startswith("http://") or target.startswith("https://"):
                                    await mcp_manager.connect_http_server(name, target)
                                else:
                                    await mcp_manager.connect_server(name, parts[3:])
                                console.print(f"[green]✅ MCP server '{name}' connected![/]")
                            except Exception as e:
                                console.print(f"[red]❌ Failed: {e}[/]")
                    elif cmd.startswith("export "):
                        parts = cmd.split(maxsplit=2)
                        fmt = parts[1] if len(parts) > 1 else "md"
                        path = parts[2] if len(parts) > 2 else ""
                        if fmt not in ("md", "json"):
                            console.print("Usage: /export md|json [path]")
                            continue
                        if not path:
                            ts = __import__("datetime").datetime.now().strftime("%Y%m%d_%H%M%S")
                            path = f"deepcraft_export_{ts}.{fmt}"
                        try:
                            if fmt == "md":
                                content = agent.ctx.export_markdown()
                            else:
                                content = __import__("json").dumps(
                                    agent.ctx.export_json(), ensure_ascii=False, indent=2
                                )
                            with open(path, "w", encoding="utf-8") as f:
                                f.write(content)
                            console.print(f"[green]✅ Exported {len(agent.ctx)} messages → {path}[/]")
                        except Exception as e:
                            console.print(f"[red]❌ Export failed: {e}[/]")
                    else:
                        console.print(f"Unknown command: /{cmd}")
                    continue

                # Normal input → agent loop with mode
                console.print()
                try:
                    import time as _time

                    _start = _time.monotonic()
                    await agent.run_with_mode(user_input, mode=current_mode)
                    _elapsed = int((_time.monotonic() - _start) * 1000)
                    console.print(f"[dim]{agent.ctx.usage_report}[/]")

                    # Auto-record if active
                    if recorder.is_recording:
                        # Collect tool calls from last assistant message
                        tool_calls = []
                        for msg in reversed(agent.ctx._messages):
                            if msg.role == "assistant" and msg.tool_calls:
                                for tc in msg.tool_calls:
                                    tool_calls.append(
                                        {
                                            "name": tc["function"]["name"],
                                            "arguments": tc["function"]["arguments"],
                                        }
                                    )
                                break

                        recorder.record_turn(
                            turn=agent._turn_count,
                            user_input=user_input,
                            tool_calls=tool_calls,
                            duration_ms=_elapsed,
                            token_estimate=agent.ctx.token_count,
                            compression_count=agent.ctx.compression_count,
                        )

                    # Auto-capture memory every 5 turns
                    if agent._turn_count > 0 and agent._turn_count % 5 == 0:
                        try:
                            # Extract last 10 messages as context for memory extraction
                            recent_msgs = agent.ctx._messages[-15:]
                            context = "\n".join(f"[{m.role}] {m.content or ''}" for m in recent_msgs)
                            new_memories = await memory.auto_capture(context[:4000])
                            if new_memories:
                                keys = [m.key for m in new_memories]
                                console.print(f"[dim]🧠 Auto-memorized: {', '.join(keys)}[/]")
                        except Exception:
                            pass  # silent fail for auto-capture

                    # Auto-capture session memory every 3 turns
                    if agent._turn_count > 0 and agent._turn_count % 3 == 0:
                        try:
                            recent = agent.ctx._messages[-6:]
                            user_msgs = [
                                m.content or ""
                                for m in recent
                                if getattr(m, "role", "") == "user"
                            ]
                            asst_msgs = [
                                m.content or ""
                                for m in recent
                                if getattr(m, "role", "") == "assistant"
                            ]
                            if user_msgs and asst_msgs:
                                captured = await session_mem.capture(
                                    user_msgs[-1], asst_msgs[-1],
                                )
                                if captured:
                                    keys = [c["key"] for c in captured]
                                    console.print(
                                        f"[dim]🧠 Cross-session memory: "
                                        f"{', '.join(keys)}[/]"
                                    )
                        except Exception:
                            pass
                except Exception as e:
                    console.print(f"\n[red]Error: {e}[/]")

        finally:
            await mcp_manager.close_all()
            await agent.close()

    asyncio.run(repl())


def run_once(prompt: str, mode: AgentMode = AgentMode.AUTO) -> None:
    """Run a single prompt and exit.

    Args:
        prompt: The user's input.
        mode: Agent mode to use (default: auto-detect).
    """

    async def _run() -> None:
        agent = _create_agent()
        mcp_manager = MCPManager(agent.tools)
        try:
            await _connect_mcp_servers(agent, mcp_manager)
            await agent.run_with_mode(prompt, mode=mode)
        finally:
            await mcp_manager.close_all()
            await agent.close()

    asyncio.run(_run())
