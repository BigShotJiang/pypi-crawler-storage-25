"""Context and memory management — conversation history, compression, system prompt.

Uses PromptCache internally for layered context budgeting.
"""

from __future__ import annotations

import os
from enum import Enum
from typing import TYPE_CHECKING

from deepcraft.agent.prompt_cache import MAX_TOTAL_TOKENS as _MAX_TOTAL_TOKENS
from deepcraft.agent.prompt_cache import PromptCache
from deepcraft.agent.types import ChatMessage, Role

if TYPE_CHECKING:
    from deepcraft.providers import LLMProvider

# --- Budget (moved to prompt_cache.py for single source of truth) ---
# Re-export for backward compat
TOKENS_PER_CHAR = 0.4
MAX_CONTEXT_TOKENS = 120_000
COMPRESS_THRESHOLD = 0.75

# How many recent turns to keep verbatim (1 turn = user + assistant + tools)
KEEP_TURNS_VERBATIM = 5

SYSTEM_PROMPT = """You are DeepCraft, an AI coding agent with 28+ tools for
file operations, terminal, git, search, refactoring, PRs, code review, and more.

## Tool Usage
- **read_file / search_files** — inspect code before editing.
- **write_file / search_replace** — modify files. SearchReplace for targeted edits.
- **terminal** — run shell commands. Prefer tools over raw shell scripts.
- **git_tool** — branch, commit, diff, log. Use instead of raw git in terminal.
- **web_search / web_fetch** — look up docs, APIs, error messages online.
- **Checkpoint** — major file changes auto-save snapshots. /rollback to recover.

## Available Modes
- **React** (default): iterative tool calling loop. Use for most tasks.
- **Plan-Execute**: plan first, then execute step by step. Complex multi-step.
- **SubAgent**: decompose into parallel subtasks. Independent work.

## Error Recovery
- If a tool fails, read the error, adjust, and retry differently.
- Wrong file path? Use search_files to find the correct one.
- Command fails? Check working directory and environment.
- Don't repeat the same failing call > 3 times — switch strategies.

## Guidelines
- Be concise. No fluff, no self-praise.
- Think step by step: understand → plan → execute → verify.
- When unsure, ask the user rather than guessing.
- If context gets full, ask the user to /clear."""

_DEFAULT_PROMPT = SYSTEM_PROMPT


def _load_system_prompt() -> str:
    """Load system prompt from env var or file, falling back to default."""
    env_prompt = os.getenv("DEEPCRAFT_SYSTEM_PROMPT")
    if env_prompt:
        return env_prompt
    prompt_path = os.path.expanduser("~/.deepcraft/system_prompt.txt")
    try:
        return open(prompt_path).read()
    except FileNotFoundError:
        return _DEFAULT_PROMPT


def get_system_prompt() -> str:
    """Return the active system prompt (loads once, cached)."""
    return _load_system_prompt()


COMPRESSION_PROMPT = """Summarize the following conversation fragment. Keep it concise.
Preserve: user goals/decisions, key facts discovered, errors encountered and their fixes.
Omit: redundant tool output, repeated attempts, boilerplate.
Respond with the summary only, no preamble."""


class CompressionStrategy(str, Enum):
    """Compression strategy for context management."""

    AUTO = "auto"  # LLM-powered summary when threshold hit (default)
    AGGRESSIVE = "aggressive"  # Truncate aggressively, no LLM call
    OFF = "off"  # Never compress (may hit token limits)


class ContextManager:
    """Manages conversation context: messages, token counting, compression.

    Delegates to PromptCache for layered budgeting.
    """

    def __init__(
        self,
        system_prompt: str | None = None,
        strategy: CompressionStrategy = CompressionStrategy.AUTO,
        llm: LLMProvider | None = None,
    ) -> None:
        self._system_prompt = system_prompt or get_system_prompt()
        self._strategy = strategy
        self._llm = llm
        self._compression_count = 0
        self._cache = PromptCache(
            llm=llm,
            system_prompt=self._system_prompt,
        )

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def strategy(self) -> CompressionStrategy:
        return self._strategy

    @strategy.setter
    def strategy(self, value: CompressionStrategy) -> None:
        self._strategy = value

    @property
    def token_count(self) -> int:
        """Estimate token count (delegated to PromptCache)."""
        return self._cache.total_tokens

    @property
    def compression_count(self) -> int:
        """Number of compressions performed this session."""
        return self._cache.compression_count

    @property
    def usage_report(self) -> str:
        """Human-readable token budget report."""
        return self._cache.usage_report

    @property
    def usage_ratio(self) -> float:
        """Token usage ratio (0.0-1.0)."""
        return self._cache.total_tokens / _MAX_TOTAL_TOKENS

    @property
    def _messages(self) -> list[ChatMessage]:
        """Access internal messages (for sub-classes, loop.py)."""
        return self._cache.get_messages()

    # ------------------------------------------------------------------
    # Codebase index
    # ------------------------------------------------------------------

    def set_codebase_index(self, index_text: str) -> None:
        """Set codebase index for fixed context layer."""
        self._cache.set_codebase_index(index_text)

    # ------------------------------------------------------------------
    # Message management
    # ------------------------------------------------------------------

    def add_message(
        self,
        role: Role | str,
        content: str | None = None,
        tool_call_id: str | None = None,
        name: str | None = None,
    ) -> None:
        """Add a message to the conversation. Auto-triggers compression if needed."""
        self._cache.add_message(
            role=role,
            content=content,
            tool_call_id=tool_call_id,
            name=name,
        )

    def get_messages(self) -> list[ChatMessage]:
        """Get all messages for LLM context (uses layered caching internally).

        Returns ChatMessage objects — the provider serializes them.
        """
        return self._cache.build_chat_messages()

    def get_full_messages(self) -> list[ChatMessage]:
        """Get all ChatMessage objects (for export/inspection)."""
        return self._cache.get_messages()

    def reset(self) -> None:
        """Reset conversation, keeping only system prompt."""
        self._cache.reset()

    def __len__(self) -> int:
        return len(self._messages)

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export(self, session_title: str = "DeepCraft Session") -> str:
        """Export conversation as Markdown.

        Returns:
            Markdown string of the full conversation.
        """
        lines = [f"# {session_title}", ""]
        for msg in self._cache.get_messages():
            if msg.role == "system":
                continue
            role_label = msg.role.upper()
            content = msg.content or ""
            if msg.tool_call_id:
                role_label = f"TOOL [{msg.tool_call_id}]"
            lines.append(f"**{role_label}**: {content}")
            lines.append("")
        return "\n".join(lines)

    def export_json(self) -> list[dict[str, object]]:
        """Export conversation as JSON-serializable list.

        Returns:
            List of message dicts with role, content, tool_call_id.
        """
        result: list[dict[str, object]] = []
        for msg in self._cache.get_messages():
            entry: dict[str, object] = {"role": msg.role}
            if msg.content:
                entry["content"] = msg.content
            if msg.tool_call_id:
                entry["tool_call_id"] = msg.tool_call_id
            if msg.tool_calls:
                entry["tool_calls"] = msg.tool_calls
            result.append(entry)
        return result

    def restore_state(self, messages: list[dict[str, object]]) -> None:
        """Restore conversation from a previously exported state.

        Clears the current conversation and replays all messages.
        Used by conversation branching to switch branches.

        Args:
            messages: List of message dicts from export_json().
        """
        self.reset()
        for msg in messages:
            tool_calls = msg.get("tool_calls")
            if tool_calls:
                # Assistant message with tool_calls
                tc_list = (
                    list(tool_calls)
                    if isinstance(tool_calls, list)
                    else [tool_calls]
                )
                tc_id = (
                    str(msg.get("tool_call_id"))
                    if msg.get("tool_call_id")
                    else None
                )
                self._cache._full_messages.append(
                    ChatMessage(
                        role=str(msg["role"]),
                        content=str(msg.get("content", "")),
                        tool_calls=tc_list,
                        tool_call_id=tc_id,
                    )
                )
            else:
                self.add_message(
                    role=str(msg["role"]),
                    content=str(msg.get("content", "")),
                    tool_call_id=str(msg.get("tool_call_id")) if msg.get("tool_call_id") else None,
                )
