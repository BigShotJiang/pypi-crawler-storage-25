"""Sub-agent delegation — spawn child agents for parallel subtasks.

v0.30: timeout, retry, validation, progress, context, cancellation.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from rich.console import Console

from deepcraft.agent.llm import DeepSeekLLM
from deepcraft.agent.tools.base import ToolRegistry
from deepcraft.agent.types import ChatMessage

console = Console()

# --- Configurable defaults ---
DEFAULT_TIMEOUT = 120  # seconds per subagent
DEFAULT_MAX_RETRIES = 2
DEFAULT_MAX_STEPS = 5
MIN_OUTPUT_LENGTH = 20  # chars — shorter = suspicious


# =============================================================================
# Data types
# =============================================================================


@dataclass
class SubTask:
    """A task to be delegated to a sub-agent."""

    description: str
    context: str = ""
    allowed_tools: list[str] | None = None  # None = all tools
    project_context: str = ""  # v0.30: codebase index, git status, etc.
    expected_keywords: list[str] = field(default_factory=list)  # v0.30: validation hints


@dataclass
class SubResult:
    """Result from a sub-agent."""

    task: str
    output: str
    success: bool
    validated: bool = True  # v0.30: did output pass validation?
    elapsed_ms: int = 0  # v0.30: execution time
    retries: int = 0  # v0.30: how many retries were needed
    error_type: str = ""  # v0.30: timeout / tool_error / llm_error / validation


# v0.30: progress callback type
ProgressCallback = Callable[[int, int, str, str], Awaitable[None]]
# (completed, total, task_name, status: "running" | "done" | "failed" | "retry")


# =============================================================================
# Prompts
# =============================================================================

SUBAGENT_PROMPT = """你是一个专门的子代理，负责完成一个具体子任务。

任务：{task}

可用工具：
{tools}

{project_context}

请完成任务并返回结果。直接输出结果，不需要额外对话。"""


# =============================================================================
# SubAgent
# =============================================================================


class SubAgent:
    """A lightweight agent that executes a single subtask.

    v0.30 adds: timeout, cancellation, structured context.
    """

    def __init__(
        self,
        llm: DeepSeekLLM | None = None,
        tools: ToolRegistry | None = None,
        cancel_event: asyncio.Event | None = None,
    ) -> None:
        self.llm = llm or DeepSeekLLM()
        self.tools = tools or ToolRegistry()
        self.cancel_event = cancel_event or asyncio.Event()

    async def execute(
        self,
        task: str,
        context: str = "",
        project_context: str = "",
        max_steps: int = DEFAULT_MAX_STEPS,
        timeout: int = DEFAULT_TIMEOUT,
    ) -> SubResult:
        """Execute a single subtask with timeout protection.

        Returns SubResult — never raises on timeout/cancel.
        """
        start_time = time.monotonic()
        try:
            result = await asyncio.wait_for(
                self._run_loop(task, context, project_context, max_steps),
                timeout=timeout,
            )
            elapsed = int((time.monotonic() - start_time) * 1000)
            result.elapsed_ms = elapsed
            return result
        except asyncio.TimeoutError:
            elapsed = int((time.monotonic() - start_time) * 1000)
            return SubResult(
                task=task,
                output=f"Timeout after {timeout}s",
                success=False,
                validated=False,
                elapsed_ms=elapsed,
                error_type="timeout",
            )
        except asyncio.CancelledError:
            elapsed = int((time.monotonic() - start_time) * 1000)
            return SubResult(
                task=task,
                output="Cancelled",
                success=False,
                validated=False,
                elapsed_ms=elapsed,
                error_type="cancelled",
            )

    async def _run_loop(
        self,
        task: str,
        context: str,
        project_context: str,
        max_steps: int,
    ) -> SubResult:
        """Internal loop — can be cancelled/timeout via caller."""
        pc_block = (
            f"项目上下文：\n{project_context}" if project_context else ""
        )
        tool_list = "\n".join(
            f"- {t.name}: {t.description}" for t in self.tools.list_definitions()
        )

        system = SUBAGENT_PROMPT.format(
            task=task, tools=tool_list, project_context=pc_block
        )
        messages = [
            ChatMessage(role="system", content=system),
        ]
        if context:
            messages.append(ChatMessage(role="user", content=f"上下文：{context}"))
        messages.append(ChatMessage(role="user", content="请完成此任务。"))

        result_text = ""
        tool_defs = self.tools.list_definitions()

        for _step in range(max_steps):
            # Check cancellation
            if self.cancel_event.is_set():
                return SubResult(
                    task=task,
                    output=result_text or "(cancelled during execution)",
                    success=False,
                    validated=False,
                    error_type="cancelled",
                )

            tool_calls_buffer: dict[int, dict[str, Any]] = {}
            content_parts: list[str] = []

            async for chunk in self.llm.chat(messages, tools=tool_defs or None):
                if self.cancel_event.is_set():
                    break
                if chunk.delta and chunk.delta.content:
                    content_parts.append(chunk.delta.content)
                if chunk.delta and chunk.delta.tool_calls:
                    for tc in chunk.delta.tool_calls:
                        idx = len(tool_calls_buffer)
                        if tc.get("id"):
                            tool_calls_buffer[idx] = tc
                        elif idx in tool_calls_buffer:
                            tool_calls_buffer[idx]["function"]["arguments"] += tc[
                                "function"
                            ].get("arguments", "")

            result_text = "".join(content_parts)

            if not tool_calls_buffer:
                break

            # Execute tools
            for tc in tool_calls_buffer.values():
                import json as _json

                tool_name = tc["function"]["name"]
                tool_id = tc["id"]
                try:
                    raw_args = tc["function"]["arguments"]
                    args = _json.loads(raw_args) if raw_args else {}
                except _json.JSONDecodeError:
                    args = {}

                args_str = _json.dumps(args, ensure_ascii=False)
                console.print(f"    🤖 {tool_name}({args_str})", style="dim")

                try:
                    tool_result = await self.tools.execute(tool_name, args)
                except Exception as exc:
                    # Tool execution error — still record so subagent can self-correct
                    tool_result = type(
                        "ToolResult",
                        (),
                        {"content": f"Error: {exc}", "is_error": True},
                    )()

                messages.append(
                    ChatMessage(
                        role="assistant",
                        content=result_text or None,
                        tool_calls=[
                            {
                                "id": tool_id,
                                "type": "function",
                                "function": {
                                    "name": tool_name,
                                    "arguments": tc["function"]["arguments"],
                                },
                            }
                        ],
                    )
                )
                messages.append(
                    ChatMessage(
                        role="tool",
                        content=tool_result.content,
                        tool_call_id=tool_id,
                    )
                )

        return SubResult(
            task=task,
            output=result_text or "(no output)",
            success=True,
        )

    async def close(self) -> None:
        await self.llm.close()


# =============================================================================
# Result Validation (v0.30)
# =============================================================================


def validate_result(result: SubResult, task: SubTask) -> SubResult:
    """Validate a SubResult against basic quality checks.

    Returns a new SubResult with validated and success fields updated.
    """
    output = result.output.strip()

    # 1. Non-empty check
    if not output or output in ("(no output)", ""):
        result.validated = False
        result.success = False
        result.error_type = "validation: empty output"
        return result

    # 2. Minimum length
    if len(output) < MIN_OUTPUT_LENGTH:
        result.validated = False
        result.success = False
        result.error_type = f"validation: output too short ({len(output)} chars)"
        return result

    # 3. Expected keywords (if specified)
    if task.expected_keywords:
        missing = [kw for kw in task.expected_keywords if kw.lower() not in output.lower()]
        if len(missing) == len(task.expected_keywords):
            result.validated = False
            result.success = False
            result.error_type = f"validation: missing expected keywords {missing}"
            return result

    # 4. Error indicators
    error_indicators = ["traceback", "exception:", "error 500", "internal server error"]
    for indicator in error_indicators:
        if indicator in output.lower():
            result.validated = False
            result.success = False
            result.error_type = f"validation: contains error indicator '{indicator}'"
            return result

    result.validated = True
    return result


# =============================================================================
# Delegator (v0.30: retry + progress + cancel)
# =============================================================================


class Delegator:
    """Manage parallel execution of subtasks via sub-agents.

    v0.30 adds: retry, progress callback, cancel-all, structured context.
    """

    def __init__(
        self,
        llm: DeepSeekLLM | None = None,
        tools: ToolRegistry | None = None,
    ) -> None:
        self.llm = llm or DeepSeekLLM()
        self.tools = tools or ToolRegistry()
        self._cancel_event = asyncio.Event()
        self._active_agents: list[SubAgent] = []

    def cancel_all(self) -> None:
        """Cancel all running sub-agents."""
        self._cancel_event.set()

    async def delegate(
        self,
        subtasks: list[SubTask],
        max_concurrent: int = 3,
        max_retries: int = DEFAULT_MAX_RETRIES,
        timeout: int = DEFAULT_TIMEOUT,
        on_progress: ProgressCallback | None = None,
    ) -> list[SubResult]:
        """Execute multiple subtasks in parallel with retry and progress.

        Args:
            subtasks: List of subtasks to delegate.
            max_concurrent: Maximum concurrent sub-agents.
            max_retries: Retry failed subtasks up to this many times.
            timeout: Per-subagent timeout in seconds.
            on_progress: Callback(completed, total, task_name, status).

        Returns:
            List of SubResult, one per subtask.
        """
        self._cancel_event.clear()
        semaphore = asyncio.Semaphore(max_concurrent)
        total = len(subtasks)
        completed_count = 0
        results: list[SubResult | None] = [None] * total

        async def _run_one(index: int, task: SubTask, attempt: int = 0) -> None:
            nonlocal completed_count
            async with semaphore:
                if self._cancel_event.is_set():
                    results[index] = SubResult(
                        task=task.description, output="Cancelled",
                        success=False, validated=False, error_type="cancelled",
                    )
                    return

                if on_progress and attempt == 0:
                    await on_progress(completed_count, total, task.description[:60], "running")

                sub = SubAgent(
                    llm=DeepSeekLLM(),
                    tools=self.tools,
                    cancel_event=self._cancel_event,
                )
                self._active_agents.append(sub)
                try:
                    result = await sub.execute(
                        task=task.description,
                        context=task.context,
                        project_context=task.project_context,
                        timeout=timeout,
                    )
                    # Validate
                    result = validate_result(result, task)

                    if not result.success and attempt < max_retries:
                        # Retry
                        result.retries = attempt + 1
                        if on_progress:
                            await on_progress(
                                completed_count, total,
                                task.description[:60],
                                f"retry {attempt + 1}/{max_retries}",
                            )
                        await asyncio.sleep(2 ** attempt)  # exponential backoff
                        return await _run_one(index, task, attempt + 1)

                    result.retries = attempt
                    results[index] = result

                except Exception as exc:
                    if attempt < max_retries:
                        if on_progress:
                            await on_progress(
                                completed_count, total,
                                task.description[:60],
                                f"retry {attempt + 1}/{max_retries}",
                            )
                        await asyncio.sleep(2 ** attempt)
                        return await _run_one(index, task, attempt + 1)

                    results[index] = SubResult(
                        task=task.description, output=str(exc),
                        success=False, validated=False,
                        error_type="exception", retries=attempt,
                    )

                finally:
                    await sub.close()
                    if sub in self._active_agents:
                        self._active_agents.remove(sub)
                    completed_count += 1
                    status = "done" if (results[index] and results[index].success) else "failed"
                    if on_progress:
                        await on_progress(completed_count, total, task.description[:40], status)

        await asyncio.gather(*[_run_one(i, t) for i, t in enumerate(subtasks)])
        return [r for r in results if r is not None]  # type: ignore[return-value]

    async def close(self) -> None:
        self.cancel_all()
        for agent in self._active_agents:
            await agent.close()
        self._active_agents.clear()
        await self.llm.close()
