"""DeepCraft — DeepSeek-powered AI coding agent."""

__version__ = "0.32.0"
