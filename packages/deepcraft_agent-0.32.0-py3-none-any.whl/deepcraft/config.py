"""Configuration management — env vars > YAML config > defaults."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

from dotenv import load_dotenv


def _load_dotenv() -> None:
    """Load .env from current directory and home directory."""
    for path in (Path.cwd() / ".env", Path.home() / ".deepcraft" / ".env"):
        if path.exists():
            load_dotenv(path)


def _load_yaml() -> dict[str, Any]:
    """Load YAML config from standard locations."""
    paths = [
        Path.cwd() / "deepcraft.yaml",
        Path.cwd() / ".deepcraft.yaml",
        Path.home() / ".deepcraft" / "config.yaml",
        Path.home() / ".config" / "deepcraft" / "config.yaml",
    ]
    for path in paths:
        if path.exists():
            try:
                import yaml  # type: ignore[import-untyped]

                with open(path) as f:
                    return yaml.safe_load(f) or {}
            except ImportError:
                pass
            except Exception:
                pass
    return {}


def _get(key: str, yaml_cfg: dict[str, Any], default: Any = "") -> Any:
    """Get config value: env var > YAML > default."""
    env_val = os.getenv(key)
    if env_val is not None:
        return env_val

    # Walk nested YAML keys
    parts = key.lower().split("_", 1)
    node: Any = yaml_cfg
    for part in parts:
        if isinstance(node, dict):
            node = node.get(part, {})
        else:
            return default
    if isinstance(node, dict):
        return default
    return node if node else default


_load_dotenv()
_YAML = _load_yaml()


# ---- DeepSeek API ----
DEEPSEEK_API_KEY: str = str(_get("DEEPSEEK_API_KEY", _YAML, ""))
DEEPSEEK_BASE_URL: str = str(_get("DEEPSEEK_BASE_URL", _YAML, "https://api.deepseek.com"))
DEEPSEEK_MODEL: str = str(_get("DEEPSEEK_MODEL", _YAML, "deepseek-chat"))
DEEPSEEK_MAX_TOKENS: int = int(_get("DEEPSEEK_MAX_TOKENS", _YAML, "8192"))

# ---- LLM Provider ----
# Active provider: deepseek | openai | anthropic | ollama
PROVIDER: str = os.getenv("DEEPCRAFT_PROVIDER") or str(_YAML.get("provider", "deepseek"))


# Provider-specific configs (from YAML providers.* or env vars)
def _get_provider_config(name: str) -> dict[str, Any]:
    """Get provider config from YAML or env vars."""
    yaml_cfg = _YAML.get("providers", {}).get(name, {})
    config: dict[str, Any] = {}

    # Map of config_key -> (env_var, default)
    keys = {
        "api_key": (f"{name.upper()}_API_KEY", ""),
        "base_url": (f"{name.upper()}_BASE_URL", ""),
        "model": (f"{name.upper()}_MODEL", ""),
        "max_tokens": (f"{name.upper()}_MAX_TOKENS", "8192"),
    }

    for key, (env_var, default) in keys.items():
        config[key] = os.getenv(env_var) or yaml_cfg.get(key) or default

    # For max_tokens, convert to int
    if "max_tokens" in config and isinstance(config["max_tokens"], str):
        try:
            config["max_tokens"] = int(config["max_tokens"])
        except ValueError:
            config["max_tokens"] = 8192

    return config


# Backward compat: if DEEPSEEK_API_KEY is set and no provider configured, use deepseek
if not _YAML.get("provider") and not os.getenv("DEEPCRAFT_PROVIDER"):
    PROVIDER = "deepseek"

# ---- Agent ----
MAX_TURNS: int = int(_get("DEEPCRAFT_MAX_TURNS", _YAML, "25"))
WORKDIR: Path = Path(str(_get("DEEPCRAFT_WORKDIR", _YAML, "."))).resolve()

# Compression strategy: env var DEEPCRAFT_COMPRESSION or YAML agent.compression
COMPRESSION_STRATEGY: str = os.getenv("DEEPCRAFT_COMPRESSION") or str(_YAML.get("agent", {}).get("compression", "auto"))

# ---- Server ----
SERVER_HOST: str = os.getenv("DEEPCRAFT_HOST") or str(_YAML.get("server", {}).get("host", "127.0.0.1"))
SERVER_PORT: int = int(os.getenv("DEEPCRAFT_PORT") or str(_YAML.get("server", {}).get("port", "8080")))
# ---- MCP Servers ----
# Accept both old env var format and new YAML format
MCP_SERVERS: str = str(_get("DEEPCRAFT_MCP_SERVERS", _YAML, ""))


def parse_mcp_servers() -> list[dict[str, Any]]:
    """Parse MCP server config — YAML servers list or legacy env var format.

    Each entry has one of:
      - name + command     → stdio transport
      - name + url         → HTTP transport
    """
    servers: list[dict[str, Any]] = []

    # Try YAML mcp.servers list first
    mcp_cfg = _YAML.get("mcp", {})
    yaml_servers = mcp_cfg.get("servers", [])
    if isinstance(yaml_servers, list):
        for s in yaml_servers:
            if isinstance(s, dict) and "name" in s:
                entry: dict[str, Any] = {"name": s["name"]}
                if "command" in s:
                    entry["command"] = s["command"]
                if "url" in s:
                    entry["url"] = s["url"]
                if "headers" in s and isinstance(s["headers"], dict):
                    entry["headers"] = s["headers"]
                if "command" in entry or "url" in entry:
                    servers.append(entry)

    if servers:
        return servers

    # Fallback: legacy comma-separated env var
    raw = MCP_SERVERS.strip()
    if not raw:
        return servers
    for entry in raw.split(","):
        entry = entry.strip()
        if ":" not in entry:
            continue
        name, cmd = entry.split(":", 1)
        servers.append({"name": name.strip(), "command": cmd.strip()})
    return servers


def validate() -> None:
    """Verify required config. Guides user through setup if missing."""
    if not DEEPSEEK_API_KEY:
        print()
        print("╔══════════════════════════════════════════════════════╗")
        print("║  🚀 欢迎使用 DeepCraft！                              ║")
        print("║                                                      ║")
        print("║  需要 DeepSeek API Key 才能开始。                      ║")
        print("║                                                      ║")
        print("║  获取方式：                                           ║")
        print("║    1. 访问 https://platform.deepseek.com/api_keys      ║")
        print("║    2. 注册并创建 API Key                               ║")
        print("║    3. 运行以下命令设置：                               ║")
        print("║                                                      ║")
        print("║    export DEEPSEEK_API_KEY=sk-your-key-here            ║")
        print("║                                                      ║")
        print("║  或使用配置向导：                                      ║")
        print("║    deepcraft config set DEEPSEEK_API_KEY <your-key>    ║")
        print("║                                                      ║")
        print("╚══════════════════════════════════════════════════════╝")
        print()
        sys.exit(1)