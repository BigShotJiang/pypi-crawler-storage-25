"""FastAPI server — Cursor-style IDE with SSE streaming, file explorer, terminal.

DeepCraft v0.24: Full IDE experience in the browser.
- File tree explorer (left panel)
- Monaco code editor (center)
- AI chat with tool cards (right panel)
- Terminal output (bottom)
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

from deepcraft import __version__
from deepcraft.agent.mcp.client import MCPManager
from deepcraft.agent.repl import (
    _connect_mcp_servers,
    _create_agent,
)
from deepcraft.config import PROVIDER, _get_provider_config
from deepcraft.server.runner import SSERunner

STATIC_DIR = Path(__file__).parent.parent / "static"
PROJECT_ROOT = Path.cwd()

# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------


class ChatRequest(BaseModel):
    prompt: str


class FileWriteRequest(BaseModel):
    content: str


class TerminalRequest(BaseModel):
    command: str
    timeout: int = 30
    stdin: str | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_path(rel: str) -> Path:
    """Resolve and validate file path, blocking traversal attacks."""
    resolved = (PROJECT_ROOT / rel).resolve()
    if not str(resolved).startswith(str(PROJECT_ROOT.resolve())):
        raise HTTPException(status_code=403, detail="Path traversal blocked")
    return resolved


def _scan_dir(directory: Path, prefix: str = "", git_status: dict[str, str] | None = None) -> list[dict[str, Any]]:
    """Recursively scan a directory, returning a flat list for the file tree.

    If git_status is provided, annotate files with their git status.
    """
    if git_status is None:
        git_status = {}
    items: list[dict[str, Any]] = []
    try:
        for entry in sorted(directory.iterdir()):
            if entry.name.startswith("."):
                continue
            if entry.name in ("__pycache__", ".venv", "venv", "node_modules",
                              "dist", "build", ".git", ".mypy_cache", ".ruff_cache",
                              ".pytest_cache", "*.egg-info"):
                continue
            rel = f"{prefix}{entry.name}" if prefix else entry.name
            if entry.is_dir():
                items.append({"path": rel, "type": "dir"})
                items.extend(_scan_dir(entry, prefix=f"{rel}/", git_status=git_status))
            elif entry.is_file():
                items.append({
                    "path": rel,
                    "type": "file",
                    "status": git_status.get(rel),
                })
    except PermissionError:
        pass
    return items


def _get_git_status_map() -> dict[str, str]:
    """Parse git status --porcelain into {path: status} map."""
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, timeout=10,
            cwd=str(PROJECT_ROOT), check=False,
        )
        status_map: dict[str, str] = {}
        for line in result.stdout.strip().split("\n"):
            if not line:
                continue
            st = line[:2].strip()
            fp = line[3:].strip()
            if fp in status_map:
                # Merge: prefer M > A > D > ??
                existing = status_map[fp]
                priority = {"M": 0, "A": 1, "D": 2, "??": 3}
                if priority.get(st, 4) < priority.get(existing, 4):
                    status_map[fp] = st
            else:
                label = {"M": "modified", "A": "added", "D": "deleted",
                         "??": "untracked"}.get(st, st)
                status_map[fp] = label
        return status_map
    except Exception:
        return {}


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------


def create_app() -> FastAPI:
    app = FastAPI(
        title="DeepCraft IDE",
        version=__version__,
        description="Cursor-style AI coding IDE — file explorer, Monaco editor, SSE chat",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ---- Status ----
    @app.get("/api/status")
    async def status() -> dict[str, Any]:
        return {
            "version": __version__,
            "provider": PROVIDER,
            "model": _get_provider_config(PROVIDER).get("model", "unknown"),
        }

    # ---- File Explorer ----
    @app.get("/api/files")
    async def list_files(dir_: str = Query(default="", alias="dir")) -> dict[str, Any]:
        """List project files with git status annotations. ?dir=subdir."""
        root = _safe_path(dir_) if dir_ else PROJECT_ROOT
        if not root.exists():
            raise HTTPException(status_code=404, detail="Directory not found")
        if root.is_file():
            raise HTTPException(status_code=400, detail="Path is a file")

        prefix = f"{dir_}/" if dir_ else ""
        git_map = _get_git_status_map()
        items = _scan_dir(root, prefix=prefix, git_status=git_map)
        return {"tree": items, "root": str(PROJECT_ROOT)}

    @app.get("/api/files/{file_path:path}")
    async def read_file(file_path: str) -> dict[str, Any]:
        """Read a file's content."""
        target = _safe_path(file_path)
        if not target.exists():
            raise HTTPException(status_code=404, detail="File not found")
        if target.is_dir():
            raise HTTPException(status_code=400, detail="Path is a directory")

        try:
            content = target.read_text(encoding="utf-8")
        except UnicodeDecodeError as err:
            raise HTTPException(status_code=400, detail="Binary file — cannot display") from err

        return {
            "path": file_path,
            "content": content,
            "size": target.stat().st_size,
            "language": target.suffix.lstrip("."),
        }

    @app.put("/api/files/{file_path:path}")
    async def write_file(file_path: str, req: FileWriteRequest) -> dict[str, Any]:
        """Write content to a file."""
        target = _safe_path(file_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(req.content, encoding="utf-8")
        return {
            "path": file_path,
            "saved": True,
            "size": target.stat().st_size,
        }

    # ---- Terminal ----
    @app.post("/api/terminal")
    async def run_terminal(req: TerminalRequest) -> dict[str, Any]:
        """Execute a shell command and return output."""
        try:
            result = subprocess.run(
                req.command,
                shell=True,
                capture_output=True,
                text=True,
                input=req.stdin,
                timeout=req.timeout,
                cwd=str(PROJECT_ROOT),
                check=False,
            )
            return {
                "output": result.stdout[:10000],
                "error": result.stderr[:10000] if result.stderr else None,
                "exit_code": result.returncode,
            }
        except subprocess.TimeoutExpired as err:
            raise HTTPException(status_code=408, detail="Command timed out") from err
        except Exception as err:
            raise HTTPException(status_code=500, detail=str(err)) from err

    # ---- Chat (SSE) ----
    @app.post("/api/chat")
    async def chat_stream(req: ChatRequest) -> StreamingResponse:
        """SSE streaming chat endpoint."""

        async def event_stream():
            agent = _create_agent()
            mcp_manager = MCPManager(agent.tools)

            try:
                await _connect_mcp_servers(agent, mcp_manager)
                runner = SSERunner(agent)
                async for event in runner.run(req.prompt):
                    yield event.to_sse()
            except Exception as e:
                yield f"event: error\ndata: {json.dumps({'message': str(e)})}\n\n"
            finally:
                await mcp_manager.close_all()
                await agent.close()

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    @app.post("/api/chat/sync")
    async def chat_sync(req: ChatRequest) -> dict[str, Any]:
        """Non-streaming chat."""
        agent = _create_agent()
        mcp_manager = MCPManager(agent.tools)
        try:
            await _connect_mcp_servers(agent, mcp_manager)
            response = await agent.run(req.prompt)
            return {"response": response}
        finally:
            await mcp_manager.close_all()
            await agent.close()

    # ---- Tools list ----
    @app.get("/api/tools")
    async def tools() -> list[dict[str, Any]]:
        agent = _create_agent()
        defs = []
        for t in agent.tools.list_definitions():
            if hasattr(t, 'model_dump'):
                defs.append(t.model_dump())
            elif isinstance(t, dict):
                # Already a dict — pass through
                defs.append(t)
            elif hasattr(t, 'name'):
                # ToolDefinition or similar
                defs.append({"name": t.name, "description": getattr(t, 'description', '')})
        return defs

    # ---- Git status ----
    @app.get("/api/git/status")
    async def git_status() -> dict[str, Any]:
        """Return git status — modified, added, deleted files."""
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                capture_output=True,
                text=True,
                timeout=10,
                cwd=str(PROJECT_ROOT),
                check=False,
            )
            mod, add, dele, unt = [], [], [], []
            for line in result.stdout.strip().split("\n"):
                if not line:
                    continue
                st = line[:2]
                fp = line[3:].strip()
                if "M" in st:
                    mod.append(fp)
                elif "A" in st:
                    add.append(fp)
                elif "D" in st:
                    dele.append(fp)
                elif "??" in st:
                    unt.append(fp)
            files = {"modified": mod, "added": add, "deleted": dele, "untracked": unt}
            total = len(mod) + len(add) + len(dele) + len(unt)
            return {"files": files, "total": total, "dirty": total > 0}
        except Exception:
            empty = {"modified": [], "added": [], "deleted": [], "untracked": []}
            return {"files": empty, "total": 0, "dirty": False}

    # ---- Static UI ----
    @app.get("/")
    async def index() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    @app.get("/favicon.ico")
    async def favicon() -> dict[str, Any]:
        return {}

    return app


def run_server(host: str = "127.0.0.1", port: int = 8080) -> None:
    """Run the server via uvicorn."""
    import uvicorn

    uvicorn.run(create_app(), host=host, port=port, log_level="info")
