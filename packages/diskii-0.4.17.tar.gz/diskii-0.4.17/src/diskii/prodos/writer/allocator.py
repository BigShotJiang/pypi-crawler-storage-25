"""ProDOS block allocation and utility functions."""

import struct
from datetime import datetime
from typing import Any

from ...exceptions import (
    FilesystemError,
)
from ..filesystem import ProDOSVolumeBitmap


def _invalidate_image_cache(image: Any) -> None:
    """Invalidate file list cache if image supports it."""
    if hasattr(image, "_file_list_cache"):
        image._file_list_cache = None


def datetime_to_prodos_date(dt: datetime | None) -> bytes:
    """Convert Python datetime to ProDOS date format (4 bytes).

    ProDOS date format (from ProDOS Technical Reference):
    Date (2 bytes):
    - Bits 15-9: Year (5 bits) - stored as year - 1900
    - Bits 8-5: Month (4 bits)
    - Bits 4-0: Day (5 bits)

    Time (2 bytes):
    - Bits 15-13: Always "000"
    - Bits 12-8: Hour (5 bits)
    - Bits 7-6: Always "00"
    - Bits 5-0: Minute (6 bits)
    """
    if dt is None:
        dt = datetime.now()

    # ProDOS year is stored as year % 100 (compatible with reference implementations)
    year_prodos = dt.year % 100
    if year_prodos > 127:
        # Clamp to valid range (though year % 100 should never exceed 127)
        year_prodos = 127

    # Pack date word: year(7 bits) + month(4 bits) + day(5 bits)
    date_word = (year_prodos << 9) | (dt.month << 5) | dt.day

    # Pack time word: reserved(3 bits=0) + hour(5 bits) + reserved(2 bits=0) +
    # minute(6 bits)
    time_word = (dt.hour << 8) | dt.minute

    return struct.pack("<HH", date_word, time_word)


class ProDOSBlockAllocator:
    """Manages ProDOS block allocation using the volume bitmap."""

    def __init__(self, image: Any) -> None:
        self.image = image
        self.bitmap = ProDOSVolumeBitmap(image)

    def find_free_blocks(self, count: int, contiguous: bool = False) -> list[int]:
        """Find free blocks on the disk.

        Args:
            count: Number of blocks needed
            contiguous: If True, find contiguous blocks

        Returns:
            List of available block numbers

        Raises:
            FilesystemError: If not enough free blocks available
        """
        # Get actually used blocks from existing files to avoid corrupted bitmap issues
        actually_used_blocks = self._get_actually_used_blocks()

        free_blocks = []
        total_blocks = self.image.total_blocks

        if contiguous:
            # Find contiguous sequence
            consecutive_count = 0
            start_block = None

            for block_num in range(total_blocks):
                # Block is truly free if both bitmap says free AND it's not
                # actually used by files
                if (
                    self.bitmap.is_block_free(block_num)
                    and block_num not in actually_used_blocks
                ):
                    if consecutive_count == 0:
                        start_block = block_num
                    consecutive_count += 1

                    if consecutive_count >= count and start_block is not None:
                        return list(range(start_block, start_block + count))
                else:
                    consecutive_count = 0
                    start_block = None

            raise FilesystemError(
                f"Cannot find {count} contiguous free blocks", str(self.image.file_path)
            )
        else:
            # Find any free blocks
            for block_num in range(total_blocks):
                # Block is truly free if both bitmap says free AND it's not
                # actually used by files
                if (
                    self.bitmap.is_block_free(block_num)
                    and block_num not in actually_used_blocks
                ):
                    free_blocks.append(block_num)
                    if len(free_blocks) >= count:
                        return free_blocks[:count]

        raise FilesystemError(
            f"Not enough free blocks: need {count}, found {len(free_blocks)}",
            str(self.image.file_path),
        )

    def _get_actually_used_blocks(self) -> set[int]:
        """Get blocks that are actually in use by existing files, ignoring
        corrupted bitmap.

        This protects against corrupted volume bitmaps that incorrectly mark allocated
        blocks as free, which would cause file corruption.
        """
        used_blocks: set[int] = set()

        # Reserve system blocks: boot (0-1), volume directory (2-5)
        used_blocks.update(range(6))

        # Reserve volume bitmap blocks (block 6 onwards)
        try:
            volume_block = self.image.read_block(2)
            bitmap_ptr = struct.unpack_from("<H", volume_block, 0x27)[0]
            total_blocks = self.image.total_blocks
            bitmap_blocks_needed = (total_blocks + 4095) // 4096
            used_blocks.update(range(bitmap_ptr, bitmap_ptr + bitmap_blocks_needed))
        except Exception:
            # Fallback: assume bitmap starts at block 6 for a 140K disk (1 block)
            used_blocks.add(6)

        try:
            # Get all existing files and their block usage
            files = self.image.get_file_list()
            for file_entry in files:
                # Add the key block (index block for sapling/tree, data block
                # for seedling)
                used_blocks.add(file_entry.key_block)

                if file_entry.is_sapling or file_entry.is_tree:
                    # Read index block to get data blocks
                    try:
                        index_block = self.image.read_block(file_entry.key_block)

                        # Extract data block pointers (ProDOS split-block format)
                        for i in range(256):
                            low_byte = index_block[i]
                            high_byte = (
                                index_block[i + 256]
                                if i + 256 < len(index_block)
                                else 0
                            )
                            block_num = (high_byte << 8) | low_byte
                            if block_num != 0:
                                used_blocks.add(block_num)

                        # For tree files, we need to read each index block to get
                        # data blocks
                        if file_entry.is_tree:
                            for i in range(256):
                                low_byte = index_block[i]
                                high_byte = (
                                    index_block[i + 256]
                                    if i + 256 < len(index_block)
                                    else 0
                                )
                                index_block_num = (high_byte << 8) | low_byte
                                if index_block_num != 0:
                                    try:
                                        sub_index_block = self.image.read_block(
                                            index_block_num
                                        )
                                        for j in range(256):
                                            low_byte = sub_index_block[j]
                                            high_byte = (
                                                sub_index_block[j + 256]
                                                if j + 256 < len(sub_index_block)
                                                else 0
                                            )
                                            data_block_num = (high_byte << 8) | low_byte
                                            if data_block_num != 0:
                                                used_blocks.add(data_block_num)
                                    except Exception:
                                        pass  # Skip corrupted index blocks
                    except Exception:
                        pass  # Skip files we can't read
        except Exception:
            pass  # If we can't read file list, just use system blocks

        return used_blocks

    def allocate_blocks(self, block_numbers: list[int]) -> None:
        """Mark blocks as allocated in the volume bitmap."""
        bitmap_start_block = self.bitmap._find_bitmap_block()
        blocks_per_bitmap = 512 * 8

        # Group blocks by which bitmap block they belong to
        bitmap_updates: dict[int, dict[str, Any]] = {}

        for block_num in block_numbers:
            bitmap_block_index = block_num // blocks_per_bitmap
            if bitmap_block_index not in bitmap_updates:
                bitmap_block_num = bitmap_start_block + bitmap_block_index
                bitmap_updates[bitmap_block_index] = {
                    "block_num": bitmap_block_num,
                    "data": bytearray(self.image.read_block(bitmap_block_num)),
                    "changes": [],
                }

            block_within_bitmap = block_num % blocks_per_bitmap
            byte_offset = block_within_bitmap // 8
            # ProDOS uses big-endian bit ordering: bit 7 = lowest block in byte
            bit_pos = 7 - (block_within_bitmap % 8)

            bitmap_updates[bitmap_block_index]["changes"].append((byte_offset, bit_pos))

        # Apply changes and write bitmap blocks
        for bitmap_info in bitmap_updates.values():
            data = bitmap_info["data"]
            for byte_offset, bit_pos in bitmap_info["changes"]:
                # Clear the bit (0 = allocated, 1 = free)
                data[byte_offset] &= ~(1 << bit_pos)

            self.image.write_block(bitmap_info["block_num"], bytes(data))

    def deallocate_blocks(self, block_numbers: list[int]) -> None:
        """Mark blocks as free in the volume bitmap."""
        bitmap_start_block = self.bitmap._find_bitmap_block()
        blocks_per_bitmap = 512 * 8

        bitmap_updates: dict[int, dict[str, Any]] = {}

        for block_num in block_numbers:
            bitmap_block_index = block_num // blocks_per_bitmap
            if bitmap_block_index not in bitmap_updates:
                bitmap_block_num = bitmap_start_block + bitmap_block_index
                bitmap_updates[bitmap_block_index] = {
                    "block_num": bitmap_block_num,
                    "data": bytearray(self.image.read_block(bitmap_block_num)),
                    "changes": [],
                }

            block_within_bitmap = block_num % blocks_per_bitmap
            byte_offset = block_within_bitmap // 8
            # ProDOS uses big-endian bit ordering: bit 7 = lowest block in byte
            bit_pos = 7 - (block_within_bitmap % 8)

            bitmap_updates[bitmap_block_index]["changes"].append((byte_offset, bit_pos))

        # Apply changes and write bitmap blocks
        for bitmap_info in bitmap_updates.values():
            data = bitmap_info["data"]
            for byte_offset, bit_pos in bitmap_info["changes"]:
                # Set the bit (1 = free, 0 = allocated)
                data[byte_offset] |= 1 << bit_pos

            self.image.write_block(bitmap_info["block_num"], bytes(data))
