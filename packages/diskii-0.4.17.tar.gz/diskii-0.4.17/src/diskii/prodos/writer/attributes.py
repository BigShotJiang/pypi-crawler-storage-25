"""ProDOS file attribute modification."""

import struct
from typing import Any

from ...exceptions import (
    FileNotFoundError,
    FilesystemError,
)
from .allocator import (
    _invalidate_image_cache,
    datetime_to_prodos_date,
)


def modify_prodos_file_attributes(image: Any, filename: str, **attrs: Any) -> None:
    """Modify ProDOS file attributes.
    Args:
        image: ProDOS disk image
        filename: Name of file to modify (special case: use empty string "" for
            volume directory)
        **attrs: Attributes to modify (file_type, aux_type, access, etc.)
    """
    # Special case: modify volume directory attributes
    if filename == "":
        return _modify_volume_directory_attributes(image, **attrs)

    from .directory import _find_directory_entry, _resolve_parent_directory

    parent_block, leaf_name = _resolve_parent_directory(image, filename)
    hit = _find_directory_entry(image, parent_block, leaf_name)
    if hit is None:
        raise FileNotFoundError(filename, str(image.file_path))
    block_num, block_data, offset, _storage_type = hit

    if "file_type" in attrs:
        file_type = attrs["file_type"]
        if isinstance(file_type, str):
            from ...file_type_conversion import normalize_prodos_file_type

            file_type = normalize_prodos_file_type(file_type)
        block_data[offset + 16] = file_type & 0xFF

    if "aux_type" in attrs:
        aux_type = attrs["aux_type"]
        struct.pack_into("<H", block_data, offset + 31, aux_type)

    if "access" in attrs:
        access = attrs["access"]
        block_data[offset + 30] = access & 0xFF

    if "creation_date" in attrs:
        creation_date = attrs["creation_date"]
        if creation_date is not None:
            date_bytes = datetime_to_prodos_date(creation_date)
            block_data[offset + 24 : offset + 28] = date_bytes

    if "mod_date" in attrs:
        mod_date = attrs["mod_date"]
        if mod_date is not None:
            date_bytes = datetime_to_prodos_date(mod_date)
            block_data[offset + 33 : offset + 37] = date_bytes

    # HFS attributes: accepted for compatibility but not persisted.
    if "hfs_file_type" in attrs:
        hfs_file_type = attrs["hfs_file_type"]
        if isinstance(hfs_file_type, bytes) and len(hfs_file_type) == 4:
            pass

    if "hfs_creator" in attrs:
        hfs_creator = attrs["hfs_creator"]
        if isinstance(hfs_creator, bytes) and len(hfs_creator) == 4:
            pass

    image.write_block(block_num, bytes(block_data))
    _invalidate_image_cache(image)


def _modify_volume_directory_attributes(image: Any, **attrs: Any) -> None:
    """Modify ProDOS volume directory header attributes.
    Args:
        image: ProDOS disk image
        **attrs: Attributes to modify (access, volume_name, creation_date)
    """
    # Read volume directory header block
    volume_data = bytearray(image.read_block(2))

    # Volume directory header starts at offset 4
    header_offset = 4

    # Check that this is indeed a volume directory header (storage type 0xF)
    storage_and_length = volume_data[header_offset]
    storage_type = (storage_and_length >> 4) & 0x0F
    if storage_type != 0x0F:
        raise FilesystemError(
            f"Invalid volume directory header storage type: 0x{storage_type:X}"
        )

    modified = False

    # Modify volume name
    if "volume_name" in attrs:
        new_name = attrs["volume_name"].upper()
        if len(new_name) > 15:
            raise ValueError(f"Volume name too long: {len(new_name)} > 15")

        # Update storage type and name length byte
        volume_data[header_offset] = 0xF0 | len(new_name)

        # Clear old name area (15 bytes max)
        for i in range(15):
            volume_data[header_offset + 1 + i] = 0x00

        # Write new name
        name_bytes = new_name.encode("ascii")
        volume_data[header_offset + 1 : header_offset + 1 + len(name_bytes)] = (
            name_bytes
        )
        modified = True

    # Modify access permissions
    if "access" in attrs:
        access = attrs["access"]
        # Access byte is at offset 0x22 from block start (based on
        # disk_creator.py structure)
        volume_data[0x22] = access & 0xFF
        modified = True

    # Modify creation date
    if "creation_date" in attrs:
        creation_date = attrs["creation_date"]
        if creation_date is not None:
            date_bytes = datetime_to_prodos_date(creation_date)
            # Creation date is at offset 0x1C from block start (based on
            # disk_creator.py)
            volume_data[0x1C:0x20] = date_bytes
            modified = True

    if modified:
        # Write updated volume directory block
        image.write_block(2, bytes(volume_data))
