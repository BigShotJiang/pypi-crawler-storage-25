"""ProDOS file creation, deletion, truncation, and move operations."""

from datetime import UTC, datetime
from typing import Any

from ...exceptions import (
    FileNotFoundError,
    FilesystemError,
    InvalidFileError,
)
from .allocator import (
    ProDOSBlockAllocator,
    _invalidate_image_cache,
)
from .directory import (
    _add_directory_entry,
    _find_directory_entry,
    _resolve_parent_directory,
    _validate_directory_header,
)


def create_prodos_file(
    image: Any,
    filename: str,
    file_type: int,
    data: bytes,
    aux_type: int = 0,
    created: datetime | None = None,
    access: int = 0xC3,
) -> None:
    """Create a new file on a ProDOS disk image.

    The ``filename`` argument may be a bare name, a relative path
    (``"DIR/FILE"``), a path with a leading slash (``"/DIR/FILE"``), or a
    fully-qualified ProDOS pathname (``"/VOLUME/DIR/FILE"``); every
    intermediate directory must already exist.

    Args:
        image: UnifiedDiskImage instance
        filename: Name or path of the file to create
        file_type: ProDOS file type (e.g., 0x04 for text, 0x06 for binary)
        data: File content bytes
        aux_type: Auxiliary type information
        created: Creation date (defaults to current time)

    Raises:
        InvalidFileError: If filename already exists or is invalid
        FilesystemError: If not enough free space
    """
    if created is None:
        created = datetime.now(UTC)

    parent_block, leaf_name = _resolve_parent_directory(image, filename)

    # Validate leaf filename
    if not leaf_name or len(leaf_name) > 15:
        raise InvalidFileError(f"Invalid filename: {filename}")

    _validate_directory_header(image, parent_block)

    # Check if file already exists in the target parent directory.
    if _find_directory_entry(image, parent_block, leaf_name) is not None:
        raise InvalidFileError(f"File already exists: {filename}")

    # Determine storage type based on file size
    file_size = len(data)

    if file_size <= 512:
        storage_type = 1
        blocks_needed = 1
    elif file_size <= 131072:
        storage_type = 2
        data_blocks_needed = (file_size + 511) // 512
        blocks_needed = data_blocks_needed + 1
    else:
        storage_type = 3
        data_blocks_needed = (file_size + 511) // 512
        index_blocks_needed = (data_blocks_needed + 255) // 256
        blocks_needed = data_blocks_needed + index_blocks_needed + 1

    allocator = ProDOSBlockAllocator(image)
    allocated_blocks = allocator.find_free_blocks(blocks_needed)

    # Snapshot the parent directory's header block so we can roll back on
    # failure. (For non-root paths, the volume directory itself is not
    # modified by file creation, only the parent directory's chain is.)
    original_parent_block = image.read_block(parent_block)

    try:
        if storage_type == 1:
            key_block = allocated_blocks[0]
            padded_data = data.ljust(512, b"\x00")
            image.write_block(key_block, padded_data)

        elif storage_type == 2:
            key_block = allocated_blocks[0]
            data_blocks = allocated_blocks[1:]

            index_data = bytearray(512)
            for i, data_block in enumerate(data_blocks):
                if i < 256:
                    low_byte = data_block & 0xFF
                    high_byte = (data_block >> 8) & 0xFF
                    index_data[i] = low_byte
                    index_data[i + 256] = high_byte

            image.write_block(key_block, bytes(index_data))

            for i, data_block in enumerate(data_blocks):
                start_offset = i * 512
                end_offset = min(start_offset + 512, len(data))
                block_data = data[start_offset:end_offset].ljust(512, b"\x00")
                image.write_block(data_block, block_data)

        else:  # storage_type == 3
            key_block = allocated_blocks[0]
            remaining_blocks = allocated_blocks[1:]

            data_blocks_needed = (file_size + 511) // 512
            index_blocks_needed = (data_blocks_needed + 255) // 256

            index_blocks = remaining_blocks[:index_blocks_needed]
            data_blocks = remaining_blocks[index_blocks_needed:]

            master_index = bytearray(512)
            for i, index_block in enumerate(index_blocks):
                if i < 256:
                    low_byte = index_block & 0xFF
                    high_byte = (index_block >> 8) & 0xFF
                    master_index[i] = low_byte
                    master_index[i + 256] = high_byte

            image.write_block(key_block, bytes(master_index))

            data_block_index = 0
            for _, index_block in enumerate(index_blocks):
                index_data = bytearray(512)

                for j in range(256):
                    if data_block_index < len(data_blocks):
                        data_block_num = data_blocks[data_block_index]
                        low_byte = data_block_num & 0xFF
                        high_byte = (data_block_num >> 8) & 0xFF
                        index_data[j] = low_byte
                        index_data[j + 256] = high_byte

                        start_offset = data_block_index * 512
                        end_offset = min(start_offset + 512, len(data))
                        block_data = data[start_offset:end_offset].ljust(512, b"\x00")
                        image.write_block(data_blocks[data_block_index], block_data)

                        data_block_index += 1
                    else:
                        break

                image.write_block(index_block, bytes(index_data))

        _add_directory_entry(
            image,
            leaf_name,
            file_type,
            file_size,
            storage_type,
            key_block,
            len(allocated_blocks),
            aux_type,
            created,
            access,
            header_block=parent_block,
        )

        allocator.allocate_blocks(allocated_blocks)

    except Exception as e:
        try:
            image.write_block(parent_block, original_parent_block)
        except Exception as restore_error:
            raise FilesystemError(
                f"CRITICAL: Failed to restore directory after error in "
                f"{filename}: {restore_error}. Original error: {e}"
            ) from e

        raise FilesystemError(f"Failed to create file {filename}: {e}") from e


def delete_prodos_file(image: Any, filename: str) -> None:
    """Delete a file from a ProDOS disk image.

    Accepts the same path forms as :func:`create_prodos_file`.

    Args:
        image: UnifiedDiskImage instance
        filename: Name or path of the file to delete

    Raises:
        FileNotFoundError: If file doesn't exist
    """
    from .directory import _remove_directory_entry

    parent_block, leaf_name = _resolve_parent_directory(image, filename)
    hit = _find_directory_entry(image, parent_block, leaf_name)
    if hit is None:
        raise FileNotFoundError(filename, str(image.file_path))
    _, block_data, offset, storage_type = hit

    import struct

    key_block = struct.unpack("<H", block_data[offset + 17 : offset + 19])[0]

    # Walk the storage tree and collect blocks to free.
    blocks_to_free: list[int] = [key_block]

    if storage_type == 1:
        pass
    elif storage_type == 2:
        index_data = image.read_block(key_block)
        for i in range(256):
            low_byte = index_data[i]
            high_byte = index_data[i + 256] if i + 256 < len(index_data) else 0
            data_block = low_byte | (high_byte << 8)
            if data_block != 0:
                blocks_to_free.append(data_block)
    elif storage_type == 3:
        master_index = image.read_block(key_block)
        for i in range(256):
            low_byte = master_index[i]
            high_byte = master_index[i + 256] if i + 256 < len(master_index) else 0
            index_block = low_byte | (high_byte << 8)

            if index_block != 0:
                blocks_to_free.append(index_block)

                index_data = image.read_block(index_block)
                for j in range(256):
                    low_byte = index_data[j]
                    high_byte = index_data[j + 256] if j + 256 < len(index_data) else 0
                    data_block = low_byte | (high_byte << 8)
                    if data_block != 0:
                        blocks_to_free.append(data_block)
    # storage_type 0x0D = directory: just free the directory's header block,
    # which is already in blocks_to_free as key_block. (Recursive deletion of
    # subdirectory contents is the caller's responsibility.)

    allocator = ProDOSBlockAllocator(image)
    allocator.deallocate_blocks(blocks_to_free)

    _remove_directory_entry(image, filename)


def truncate_prodos_file(image: Any, filename: str, new_size: int) -> None:
    """Truncate a ProDOS file to a new size.
    Args:
        image: ProDOS disk image
        filename: Name of file to truncate
        new_size: New size in bytes
    """
    file_entry = image._find_file_entry(filename)

    current_size = file_entry.size

    if new_size == current_size:
        return

    if new_size > current_size:
        current_data = file_entry.read_data()
        new_data = current_data + b"\x00" * (new_size - current_size)

        delete_prodos_file(image, filename)
        _invalidate_image_cache(image)
        from ...fileentry import convert_file_type

        file_type_int = convert_file_type(file_entry.file_type, "prodos")
        assert isinstance(file_type_int, int)
        create_prodos_file(
            image,
            filename,
            file_type_int,
            new_data,
            aux_type=getattr(file_entry, "aux_type", 0),
        )

    else:
        current_data = file_entry.read_data()
        new_data = current_data[:new_size]

        delete_prodos_file(image, filename)
        _invalidate_image_cache(image)
        from ...fileentry import convert_file_type

        file_type_int = convert_file_type(file_entry.file_type, "prodos")
        assert isinstance(file_type_int, int)
        create_prodos_file(
            image,
            filename,
            file_type_int,
            new_data,
            aux_type=getattr(file_entry, "aux_type", 0),
        )


def move_prodos_file(image: Any, src_filename: str, dest_filename: str) -> None:
    """Rename a ProDOS file in place.

    Both source and destination must resolve to the same parent directory —
    this function does not move files between directories. The destination
    name may be supplied either bare or with the same parent path as the
    source.
    """
    src_parent, src_leaf = _resolve_parent_directory(image, src_filename)

    # Allow dest to be either a bare name or a full path matching the source's
    # parent. Reject cross-directory moves.
    if "/" in dest_filename.strip("/"):
        dest_parent, dest_leaf = _resolve_parent_directory(image, dest_filename)
        if dest_parent != src_parent:
            raise FilesystemError("Cross-directory move is not supported; rename only")
    else:
        dest_leaf = dest_filename

    new_name = dest_leaf.upper()
    if len(new_name) > 15:
        raise ValueError(f"Filename too long: {len(new_name)} > 15")

    hit = _find_directory_entry(image, src_parent, src_leaf)
    if hit is None:
        raise FileNotFoundError(src_filename, str(image.file_path))
    block_num, block_data, offset, storage_type = hit

    block_data[offset] = (storage_type << 4) | len(new_name)
    for i in range(15):
        block_data[offset + 1 + i] = 0x00
    name_bytes = new_name.encode("ascii")
    block_data[offset + 1 : offset + 1 + len(name_bytes)] = name_bytes

    image.write_block(block_num, bytes(block_data))
    _invalidate_image_cache(image)
