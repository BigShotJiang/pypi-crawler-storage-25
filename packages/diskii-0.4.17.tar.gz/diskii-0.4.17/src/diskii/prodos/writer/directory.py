"""ProDOS directory creation and manipulation.

The volume directory (always rooted at block 2) and every subdirectory share
the same physical layout: a chain of 512-byte blocks linked by prev/next
pointers at offsets 0-3, with 13 entry slots of 39 bytes each starting at
offset 4. The only differences are:

* The first slot of a *header* block holds a directory-header entry
  (storage type 0xF for the volume directory, 0xE for a subdirectory) instead
  of a file entry; continuation blocks use all 13 slots for entries.
* The directory's file_count lives at offset 0x25 of the header block — that
  is, offset 0x21 within the header entry that starts at block offset 4.

The helpers below are therefore parameterised by ``header_block`` so the same
code path mutates the volume directory and any subdirectory.
"""

import struct
from datetime import UTC, datetime
from typing import Any

from ...exceptions import (
    FileNotFoundError,
    FilesystemError,
    InvalidFileError,
)
from .allocator import (
    ProDOSBlockAllocator,
    _invalidate_image_cache,
    datetime_to_prodos_date,
)

_ENTRY_SIZE = 39
_ENTRIES_PER_BLOCK = 13
_HEADER_ENTRY_OFFSET = 4
_FILE_COUNT_OFFSET = _HEADER_ENTRY_OFFSET + 0x21  # 0x25


def _iter_directory_blocks(image: Any, header_block: int) -> Any:
    """Yield ``(block_num, block_data)`` for the header block and every
    continuation block in the directory chain. ``block_data`` is a fresh
    ``bytearray`` the caller may mutate and write back.

    Raises ``FilesystemError`` if a circular continuation chain is detected.
    """
    current = header_block
    seen: set[int] = set()
    while current != 0:
        if current in seen:
            raise FilesystemError("Directory continuation chain contains a cycle")
        seen.add(current)
        block = bytearray(image.read_block(current))
        yield current, block
        if len(block) < 4:
            return
        current = struct.unpack("<H", block[2:4])[0]


def _iter_volume_directory_blocks(image: Any) -> Any:
    """Backwards-compatible alias used in the volume-directory case."""
    yield from _iter_directory_blocks(image, 2)


def _entry_slot_offset(block_num: int, header_block: int, slot: int) -> int:
    """Return the byte offset of the ``slot``-th entry in ``block_num``.

    Slot indices are 0-based and the count of available slots depends on
    whether this is the header block of the chain (slot 0 is reserved for
    the directory header entry).
    """
    if block_num == header_block:
        return _HEADER_ENTRY_OFFSET + slot * _ENTRY_SIZE
    return _HEADER_ENTRY_OFFSET + slot * _ENTRY_SIZE


def _find_directory_entry(
    image: Any, header_block: int, filename: str
) -> tuple[int, bytearray, int, int] | None:
    """Find a file entry by name in the directory chain starting at
    ``header_block``.

    Returns ``(block_num, block_data, offset, storage_type)`` for the
    matching entry, or ``None`` if no match exists. Matching is
    case-insensitive. ``block_data`` is a fresh ``bytearray`` the caller
    may mutate and write back via ``image.write_block(block_num, ...)``.
    """
    target = filename.upper()
    for block_num, block in _iter_directory_blocks(image, header_block):
        # The header block reserves its first slot for the directory header
        # entry; continuation blocks use all 13 slots.
        start = 1 if block_num == header_block else 0
        for i in range(start, _ENTRIES_PER_BLOCK):
            offset = _HEADER_ENTRY_OFFSET + i * _ENTRY_SIZE
            if offset + _ENTRY_SIZE > len(block):
                break
            storage_and_length = block[offset]
            storage_type = (storage_and_length >> 4) & 0x0F
            name_length = storage_and_length & 0x0F
            if storage_type == 0 or name_length == 0:
                continue
            try:
                entry_name = block[offset + 1 : offset + 1 + name_length].decode(
                    "ascii"
                )
            except UnicodeDecodeError:
                continue
            if entry_name.upper() == target:
                return block_num, block, offset, storage_type
    return None


def _find_volume_directory_entry(
    image: Any, filename: str
) -> tuple[int, bytearray, int, int] | None:
    """Backwards-compatible alias for the volume directory."""
    return _find_directory_entry(image, 2, filename)


def _expected_header_storage_type(header_block: int) -> int:
    """0xF for the volume directory, 0xE for a subdirectory."""
    return 0x0F if header_block == 2 else 0x0E


def _validate_directory_space(image: Any, filename: str) -> None:
    """Validate that the volume directory is well-formed before a write.

    Kept for backwards compatibility; the directory-block walker will
    create continuation blocks as needed.
    """
    _validate_directory_header(image, 2)


def _validate_directory_header(image: Any, header_block: int) -> None:
    """Sanity-check that ``header_block`` looks like a directory header."""
    try:
        block = image.read_block(header_block)
        if len(block) != 512:
            raise FilesystemError(f"Invalid directory block size: {len(block)}")

        storage_type = (block[_HEADER_ENTRY_OFFSET] >> 4) & 0x0F
        expected = _expected_header_storage_type(header_block)
        if storage_type != expected:
            raise FilesystemError(
                f"Invalid directory header signature at block {header_block}: "
                f"expected 0x{expected:X}, got 0x{storage_type:X}"
            )
    except FilesystemError:
        raise
    except Exception as e:
        raise FilesystemError(f"Cannot validate directory structure: {e}") from e


def _add_entry_to_directory(
    image: Any,
    header_block: int,
    entry_data: bytes,
) -> tuple[int, int]:
    """Insert ``entry_data`` into the first empty slot of the directory chain
    starting at ``header_block``, allocating a continuation block if no
    existing slot is free. Bumps the directory's file_count.

    Returns ``(block_num, slot_index_1_based)`` — useful for callers (like
    subdirectory creation) that need to record where they landed.
    """
    if len(entry_data) != _ENTRY_SIZE:
        raise FilesystemError(
            f"Directory entry must be {_ENTRY_SIZE} bytes, got {len(entry_data)}"
        )

    visited: set[int] = set()
    current_block_num = header_block
    current_block_data = bytearray(image.read_block(current_block_num))

    while current_block_num != 0:
        if current_block_num in visited:
            raise FilesystemError("Directory continuation chain contains a cycle")
        visited.add(current_block_num)

        start_slot = 1 if current_block_num == header_block else 0
        for slot in range(start_slot, _ENTRIES_PER_BLOCK):
            offset = _HEADER_ENTRY_OFFSET + slot * _ENTRY_SIZE
            if offset + _ENTRY_SIZE > len(current_block_data):
                break
            existing_storage_type = (current_block_data[offset] >> 4) & 0x0F
            if existing_storage_type != 0:
                continue

            current_block_data[offset : offset + _ENTRY_SIZE] = entry_data

            # file_count lives in the header block.
            if current_block_num == header_block:
                header_data = current_block_data
            else:
                header_data = bytearray(image.read_block(header_block))
            file_count = struct.unpack(
                "<H", header_data[_FILE_COUNT_OFFSET : _FILE_COUNT_OFFSET + 2]
            )[0]
            struct.pack_into("<H", header_data, _FILE_COUNT_OFFSET, file_count + 1)

            image.write_block(current_block_num, bytes(current_block_data))
            if current_block_num != header_block:
                image.write_block(header_block, bytes(header_data))

            _invalidate_image_cache(image)
            return current_block_num, slot + 1

        # No free slot — follow chain or allocate a continuation block.
        if len(current_block_data) < 4:
            break
        next_block = struct.unpack("<H", current_block_data[2:4])[0]

        if next_block != 0:
            current_block_num = next_block
            current_block_data = bytearray(image.read_block(current_block_num))
            continue

        # End of chain: allocate a fresh continuation block.
        allocator = ProDOSBlockAllocator(image)
        try:
            new_blocks = allocator.find_free_blocks(1)
            new_block = new_blocks[0]
            allocator.allocate_blocks([new_block])
        except FilesystemError as e:
            raise FilesystemError(
                "Disk is full - cannot allocate directory continuation block"
            ) from e

        new_block_data = bytearray(512)
        struct.pack_into("<H", new_block_data, 0, current_block_num)
        struct.pack_into("<H", new_block_data, 2, 0)
        new_block_data[_HEADER_ENTRY_OFFSET : _HEADER_ENTRY_OFFSET + _ENTRY_SIZE] = (
            entry_data
        )

        struct.pack_into("<H", current_block_data, 2, new_block)

        if current_block_num == header_block:
            header_data = current_block_data
        else:
            header_data = bytearray(image.read_block(header_block))
        file_count = struct.unpack(
            "<H", header_data[_FILE_COUNT_OFFSET : _FILE_COUNT_OFFSET + 2]
        )[0]
        struct.pack_into("<H", header_data, _FILE_COUNT_OFFSET, file_count + 1)

        image.write_block(current_block_num, bytes(current_block_data))
        image.write_block(new_block, bytes(new_block_data))
        if current_block_num != header_block:
            image.write_block(header_block, bytes(header_data))

        _invalidate_image_cache(image)
        return new_block, 1

    raise FilesystemError("Directory continuation failed - possible circular reference")


def _add_directory_entry(
    image: Any,
    filename: str,
    file_type: int,
    file_size: int,
    storage_type: int,
    key_block: int,
    blocks_used: int,
    aux_type: int,
    created: datetime,
    access: int = 0xC3,
    header_block: int = 2,
) -> tuple[int, int]:
    """Build a directory entry for a new file and insert it into the directory
    chain rooted at ``header_block``. Returns ``(block_num, slot_index_1_based)``
    so callers that need backreferences (e.g. subdirectory creation) can patch
    the new entry's location into the child header.
    """
    name_bytes = filename.upper().encode("ascii")
    if len(name_bytes) > 15:
        name_bytes = name_bytes[:15]

    entry_data = bytearray(_ENTRY_SIZE)
    entry_data[0] = (storage_type << 4) | len(name_bytes)
    entry_data[1 : 1 + len(name_bytes)] = name_bytes
    entry_data[16] = file_type
    struct.pack_into("<H", entry_data, 17, key_block)
    struct.pack_into("<H", entry_data, 19, blocks_used)
    entry_data[21] = file_size & 0xFF
    entry_data[22] = (file_size >> 8) & 0xFF
    entry_data[23] = (file_size >> 16) & 0xFF
    date_bytes = datetime_to_prodos_date(created)
    entry_data[24:28] = date_bytes
    entry_data[30] = access
    struct.pack_into("<H", entry_data, 31, aux_type)
    entry_data[33:37] = date_bytes
    # Header pointer = which directory contains this entry.
    struct.pack_into("<H", entry_data, 37, header_block)

    return _add_entry_to_directory(image, header_block, bytes(entry_data))


def create_prodos_directory(image: Any, directory_path: str) -> None:
    """Create a new ProDOS directory.

    Args:
        image: ProDOS disk image
        directory_path: Path of directory to create — supports nested paths
            like ``"DIR1/SUBDIR"`` provided every intermediate directory
            already exists.
    """
    from ..types import ProDOSFileType

    parent_block, directory_name = _resolve_parent_directory(image, directory_path)
    directory_name = directory_name.upper()

    if not (1 <= len(directory_name) <= 15):
        raise InvalidFileError(
            f"Directory name must be 1-15 characters: {directory_name}"
        )

    # Check for collision within the target parent only.
    if _find_directory_entry(image, parent_block, directory_name) is not None:
        raise FilesystemError(f"Directory already exists: {directory_name}")

    _validate_directory_header(image, parent_block)

    allocator = ProDOSBlockAllocator(image)
    directory_blocks = allocator.find_free_blocks(1)
    if not directory_blocks:
        raise FilesystemError("No space available for directory")
    directory_block = directory_blocks[0]

    try:
        _create_directory_block(
            image, directory_block, directory_name, parent_block=parent_block
        )

        _, slot = _add_directory_entry(
            image,
            directory_name,
            ProDOSFileType.DIR,
            0,
            0x0D,
            directory_block,
            1,
            0,
            datetime.now(UTC),
            header_block=parent_block,
        )

        # Patch parent_entry into the subdirectory's header now that the slot
        # is known.
        subdir_block = bytearray(image.read_block(directory_block))
        # Header entry layout: offset 4 in block; parent_pointer at +0x23,
        # parent_entry at +0x25, parent_entry_length at +0x26.
        struct.pack_into("<H", subdir_block, _HEADER_ENTRY_OFFSET + 0x23, parent_block)
        subdir_block[_HEADER_ENTRY_OFFSET + 0x25] = slot
        subdir_block[_HEADER_ENTRY_OFFSET + 0x26] = _ENTRY_SIZE
        image.write_block(directory_block, bytes(subdir_block))

        allocator.allocate_blocks(directory_blocks)
        _invalidate_image_cache(image)

    except Exception:
        try:
            allocator.deallocate_blocks(directory_blocks)
        except Exception:
            pass
        raise


def delete_prodos_directory(image: Any, directory_path: str) -> None:
    """Delete a ProDOS directory.

    Args:
        image: ProDOS disk image
        directory_path: Path of directory to delete (supports nested paths
            when every intermediate directory exists).
    """
    parent_block, directory_name = _resolve_parent_directory(image, directory_path)
    directory_name = directory_name.upper()

    hit = _find_directory_entry(image, parent_block, directory_name)
    if hit is None:
        raise FileNotFoundError(directory_name, str(image.file_path))
    _, _, offset, storage_type = hit
    if storage_type != 0x0D:
        raise FilesystemError(f"Not a directory: {directory_path}")

    # Free the directory's header block.
    block_num_data = bytearray(hit[1])
    key_block = struct.unpack("<H", block_num_data[offset + 17 : offset + 19])[0]

    allocator = ProDOSBlockAllocator(image)
    if key_block > 0:
        allocator.deallocate_blocks([key_block])

    _remove_directory_entry(image, directory_path)
    _invalidate_image_cache(image)


def _create_directory_block(
    image: Any,
    block_num: int,
    directory_name: str,
    parent_block: int = 2,
) -> None:
    """Lay out a fresh subdirectory in ``block_num``.

    Args:
        image: ProDOS disk image
        block_num: Block to overwrite with the new directory structure
        directory_name: Name of the directory (already validated upstream)
        parent_block: Block number of the parent directory (defaults to the
            volume directory). The parent-entry slot index is patched in by
            the caller after the parent entry is actually placed.
    """
    dir_data = bytearray(512)

    # prev/next pointers at offsets 0-3 stay zero — this is a fresh chain.

    # Subdirectory header entry begins at offset 4 of the block.
    base = _HEADER_ENTRY_OFFSET

    # Storage type 0xE (subdirectory header) + name length.
    dir_data[base + 0x00] = 0xE0 | len(directory_name)
    dir_data[base + 0x01 : base + 0x01 + len(directory_name)] = directory_name.encode(
        "ascii"
    )

    # Reserved area at +0x10..+0x17 stays zero.

    creation_time = datetime_to_prodos_date(datetime.now(UTC))
    dir_data[base + 0x18 : base + 0x1C] = creation_time

    dir_data[base + 0x1C] = 0x00  # version
    dir_data[base + 0x1D] = 0x00  # min_version
    dir_data[base + 0x1E] = 0xC3  # access
    dir_data[base + 0x1F] = _ENTRY_SIZE  # entry_length
    dir_data[base + 0x20] = _ENTRIES_PER_BLOCK  # entries_per_block
    dir_data[base + 0x21] = 0x00  # file_count low
    dir_data[base + 0x22] = 0x00  # file_count high

    # parent_pointer at +0x23 (uint16 LE)
    struct.pack_into("<H", dir_data, base + 0x23, parent_block)
    # parent_entry (+0x25) and parent_entry_length (+0x26) are patched by the
    # caller once the slot in the parent directory is known.
    dir_data[base + 0x25] = 0x00
    dir_data[base + 0x26] = _ENTRY_SIZE

    image.write_block(block_num, bytes(dir_data))


def _remove_directory_entry(image: Any, filename: str) -> None:
    """Remove a file/directory entry, supporting nested paths.

    Walks the appropriate directory's continuation chain, so entries that
    live beyond the first directory block delete correctly.
    """
    parent_block, leaf_name = _resolve_parent_directory(image, filename)
    hit = _find_directory_entry(image, parent_block, leaf_name)
    if hit is None:
        raise FileNotFoundError(filename, str(image.file_path))
    block_num, block_data, offset, _ = hit

    block_data[offset : offset + _ENTRY_SIZE] = bytes(_ENTRY_SIZE)

    if block_num == parent_block:
        header_data = block_data
    else:
        header_data = bytearray(image.read_block(parent_block))
    current_file_count = struct.unpack(
        "<H", header_data[_FILE_COUNT_OFFSET : _FILE_COUNT_OFFSET + 2]
    )[0]
    struct.pack_into(
        "<H", header_data, _FILE_COUNT_OFFSET, max(0, current_file_count - 1)
    )

    image.write_block(block_num, bytes(block_data))
    if block_num != parent_block:
        image.write_block(parent_block, bytes(header_data))

    _invalidate_image_cache(image)


# --- Path resolution -------------------------------------------------------


def _normalize_path_segments(image: Any, path: str) -> list[str]:
    """Split a ProDOS path into its segments, stripping leading slashes and
    an optional leading volume-name component.

    Matching is case-insensitive (ProDOS paths are case-preserving but
    compared case-insensitively).
    """
    stripped = path.strip("/")
    if not stripped:
        raise InvalidFileError(f"Empty path: {path!r}")

    segments = stripped.split("/")
    # Strip leading volume name when present.
    try:
        volume = image.get_volume_name()
    except Exception:
        volume = ""
    if volume and len(segments) > 1 and segments[0].upper() == volume.upper():
        segments = segments[1:]
    if not segments:
        raise InvalidFileError(f"Empty path after volume strip: {path!r}")
    return segments


def _resolve_parent_directory(image: Any, path: str) -> tuple[int, str]:
    """Resolve the parent directory of ``path`` and return
    ``(header_block, leaf_name)``.

    ``header_block`` is 2 for the volume root, or a subdirectory's key block
    when the path is nested. Raises ``FileNotFoundError`` if any intermediate
    directory does not exist, and ``InvalidFileError`` if an intermediate
    segment names a non-directory.
    """
    segments = _normalize_path_segments(image, path)
    *dirs, leaf = segments

    current_block = 2
    for segment in dirs:
        hit = _find_directory_entry(image, current_block, segment)
        if hit is None:
            raise FileNotFoundError(segment, str(image.file_path))
        _, block_data, offset, storage_type = hit
        if storage_type != 0x0D:
            raise InvalidFileError(
                f"Path component {segment!r} in {path!r} is not a directory"
            )
        current_block = struct.unpack("<H", block_data[offset + 17 : offset + 19])[0]

    return current_block, leaf
