"""Applesoft BASIC detokenizer — ROM-compliant implementation.

Mirrors the LIST routine at $D6A5-$D764 in the Applesoft ROM.
See https://6502disassembly.com/a2-rom/Applesoft.html
"""

import struct

from ..common import BaseDetokenizer
from ..tokens import get_applesoft_table


class ApplesoftDetokenizer(BaseDetokenizer):
    """Converts tokenized Applesoft BASIC programs back to plain text.

    The ROM LIST routine ($D6F5-$D764) outputs keyword characters
    directly from the token table — no spaces are added before or after.
    The only space LIST adds is one space after the line number.
    Non-token bytes are printed as-is.
    """

    def __init__(self) -> None:
        """Initialize Applesoft BASIC detokenizer."""
        super().__init__("applesoft")
        self.token_table = get_applesoft_table()

    def detokenize_program(self, data: bytes) -> str:
        """Convert tokenized BASIC program to plain text."""
        if not data:
            return ""

        lines: list[str] = []
        offset = 0

        # Check for immediate mode command (starts with token, not line pointer)
        if len(data) >= 2:
            first_byte = data[0]
            if 0x80 <= first_byte <= 0xFF:
                end_pos = data.find(0)
                if end_pos != -1:
                    return self._detokenize_content(data[:end_pos])

        while offset < len(data):
            if offset + 4 > len(data):
                break

            next_line_ptr = struct.unpack("<H", data[offset : offset + 2])[0]
            offset += 2

            if next_line_ptr == 0:
                if offset + 2 < len(data):
                    potential_line_num = struct.unpack("<H", data[offset : offset + 2])[
                        0
                    ]
                    if potential_line_num == 0:
                        break
                else:
                    break

            line_number = struct.unpack("<H", data[offset : offset + 2])[0]
            offset += 2

            line_start = offset
            while offset < len(data) and data[offset] != 0:
                offset += 1

            if offset >= len(data):
                break

            line_content = self._detokenize_content(data[line_start:offset])
            lines.append(f"{line_number} {line_content}")

            offset += 1  # skip null terminator

        return "\n".join(lines)

    def _detokenize_content(self, content_data: bytes) -> str:
        """Detokenize line content using ROM LIST behavior.

        ROM LIST ($D6F5-$D764):
        - If byte >= $80: look up keyword in token table, output chars directly
        - If byte < $80: output as ASCII character
        - REM token ($B2): output keyword, then rest of line verbatim
        - DATA token ($83): no special handling in LIST (only tokenizer cares)
        - No spaces added around keywords — ROM outputs keyword chars only
        """
        parts: list[str] = []
        i = 0
        in_rem = False

        while i < len(content_data):
            byte_val = content_data[i]

            if in_rem:
                # After REM token, everything is literal
                if 0x20 <= byte_val <= 0x7E:
                    parts.append(chr(byte_val))
                else:
                    parts.append(f"[${byte_val:02X}]")
                i += 1
                continue

            if byte_val >= 0x80:
                keyword = self.token_table.get_keyword(byte_val)
                if keyword:
                    # ROM LIST: output keyword characters directly, no spaces
                    parts.append(keyword)

                    if byte_val == 0xB2:  # REM
                        in_rem = True
                else:
                    parts.append(f"[${byte_val:02X}]")
            elif 0x20 <= byte_val <= 0x7E:
                parts.append(chr(byte_val))
            elif byte_val == 0x0D:
                parts.append("\r")
            elif byte_val == 0x0A:
                parts.append("\n")
            else:
                parts.append(f"[${byte_val:02X}]")

            i += 1

        return "".join(parts)
