"""Applesoft BASIC tokenizer — ROM-compliant implementation.

Mirrors the behavior of the Applesoft ROM tokenizer at $D559-$D619.
See https://6502disassembly.com/a2-rom/Applesoft.html for the
canonical reference.
"""

import struct

from ..common import BaseTokenizer, is_immediate_mode_command
from ..tokens import APPLESOFT_TOKENS

# Build keyword list in token order ($80-$EA), matching the ROM's
# TOKEN_NAME_TABLE at $D0D0.  The ROM tries keywords in this exact
# order; the first match wins.
_TOKEN_TABLE: list[tuple[int, str]] = [
    (tok, kw)
    for tok, kw in sorted(APPLESOFT_TOKENS.items())
    if kw  # skip empty/unused entries
]


class ApplesoftTokenizer(BaseTokenizer):
    """Converts plain text Applesoft BASIC programs to tokenized format.

    This implementation mirrors the ROM tokenizer at $D559-$D619:
    - Character-by-character keyword matching (no word boundaries)
    - Spaces skipped outside strings/DATA/REM
    - `?` replaced with PRINT token ($BA)
    - DATA sets a flag; content stored verbatim until `:`
    - REM stores everything to end of line verbatim
    - Quoted strings copied verbatim (no escape sequences)
    - AT token ($C5) disambiguated against ATN/A TO per ROM
    """

    def __init__(self) -> None:
        """Initialize Applesoft BASIC tokenizer."""
        super().__init__("applesoft")

    def tokenize(self, text: str) -> bytes:
        """Convert plain text BASIC program to tokenized format."""
        return self.tokenize_program(text)

    def tokenize_program(self, text: str) -> bytes:
        """Convert plain text BASIC program to tokenized format."""
        if not text.strip():
            return b"\x00\x00"

        lines = self._parse_lines(text)
        if not lines:
            return b"\x00\x00"

        tokenized_lines = []
        line_info = []
        for line_num, line_text in lines:
            tokenized_line = self._tokenize_line(line_num, line_text)
            tokenized_lines.append(tokenized_line)
            line_info.append(line_num)

        APPLESOFT_START_ADDR = 0x0801
        result = bytearray()
        current_offset = 0

        for i, line_data in enumerate(tokenized_lines):
            if line_info[i] == -1:
                result.extend(line_data)
            else:
                line_with_pointer = bytearray(line_data)
                next_line_offset = (
                    APPLESOFT_START_ADDR + current_offset + len(line_data)
                )
                line_with_pointer[0:2] = struct.pack("<H", next_line_offset)
                result.extend(line_with_pointer)

            current_offset += len(line_data)

        result.extend(b"\x00\x00")
        return bytes(result)

    def _tokenize_line(self, line_num: int, line_text: str) -> bytes:
        """Tokenize a single Applesoft BASIC line."""
        if line_num == -1:
            return self._tokenize_immediate_mode(line_text)

        line_data = bytearray()
        line_data.extend(b"\x00\x00")  # next-line pointer placeholder
        line_data.extend(struct.pack("<H", line_num))
        line_data.extend(self._tokenize_content(line_text))
        line_data.append(0x00)  # line terminator
        return bytes(line_data)

    def _tokenize_immediate_mode(self, line_text: str) -> bytes:
        """Tokenize immediate mode command for Applesoft BASIC."""
        if not is_immediate_mode_command(line_text):
            return self._tokenize_content(line_text) + b"\x00"
        return self._tokenize_content(line_text) + b"\x00"

    def _tokenize_content(self, content: str) -> bytes:
        """Tokenize line content using ROM-compliant algorithm.

        Mirrors the PARSE routine at $D56C-$D619:
        - Main loop reads one character at a time
        - Spaces skipped unless in_data flag is set
        - `?` → PRINT token
        - `"` → literal copy until closing quote or EOL
        - Digits and `:` `;` → literal ASCII
        - Everything else → try keyword table match
        - After storing DATA token, set in_data flag
        - After storing `:`, clear in_data flag
        - After storing REM token, copy rest of line verbatim
        """
        result = bytearray()
        i = 0
        in_data = False  # DATAFLG in ROM

        while i < len(content):
            ch = content[i]

            # --- DATAFLG check (ROM $D570-$D572) ---
            # If in DATA, skip space-stripping and keyword matching;
            # store characters verbatim.
            if in_data:
                if ch == ":":
                    # Colon ends DATA context (ROM $D5D7-$D5E0)
                    result.append(ord(":"))
                    in_data = False
                    i += 1
                else:
                    result.append(ord(ch))
                    i += 1
                continue

            # --- Space stripping (ROM $D574-$D576) ---
            if ch == " ":
                i += 1
                continue

            # --- Quote handling (ROM $D57A-$D57C → $D5F2) ---
            if ch == '"':
                result.append(ord('"'))
                i += 1
                # Copy verbatim until closing quote or EOL
                while i < len(content):
                    ch2 = content[i]
                    result.append(ord(ch2))
                    i += 1
                    if ch2 == '"':
                        break
                continue

            # --- `?` → PRINT (ROM $D580-$D586) ---
            if ch == "?":
                result.append(0xBA)  # PRINT token
                i += 1
                continue

            # --- Digits and `:` `;` stored as literals (ROM $D588-$D58E) ---
            # ROM: chars $30-$3B are stored directly.
            if "0" <= ch <= ";":
                result.append(ord(ch))
                i += 1
                continue

            # --- Keyword table search (ROM $D590-$D60B) ---
            matched_token, chars_consumed = self._match_keyword(content, i)

            if matched_token is not None:
                result.append(matched_token)
                i += chars_consumed

                # Check what we just stored for special handling
                if matched_token == 0xB2:
                    # REM token: copy rest of line verbatim (ROM $D5E7-$D5F7)
                    while i < len(content):
                        result.append(ord(content[i]))
                        i += 1
                elif matched_token == 0x83:
                    # DATA token: set in_data flag (ROM $D5DC-$D5E0)
                    in_data = True
            else:
                # No keyword match — store as literal ASCII (ROM $D60B-$D60E)
                result.append(ord(ch))
                i += 1

        return bytes(result)

    @staticmethod
    def _match_keyword(content: str, start: int) -> tuple[int | None, int]:
        """Try to match a keyword at the current position.

        Mirrors the ROM's token table search at $D590-$D60B:
        - Iterates through keywords in token-number order
        - Compares character-by-character, skipping spaces in input
        - First full match wins
        - Special AT disambiguation per ROM ($D5BA-$D5C7)

        Returns:
            (token_value, chars_consumed) or (None, 0) if no match
        """
        input_upper = content.upper()

        for token_val, keyword in _TOKEN_TABLE:
            j = start  # input position
            k = 0  # keyword position
            matched = True

            while k < len(keyword):
                # Skip spaces in input during matching (ROM $D5AB-$D5AD)
                while j < len(input_upper) and input_upper[j] == " ":
                    j += 1

                if j >= len(input_upper):
                    matched = False
                    break

                if input_upper[j] != keyword[k]:
                    matched = False
                    break

                j += 1
                k += 1

            if not matched:
                continue

            # Full keyword matched.  Apply AT disambiguation (ROM $D5BA-$D5C7):
            # If we matched AT ($C5), check if the next input char is 'N' (→ ATN)
            # or 'O' (→ could be "A TO").  If so, reject this match so ATN or
            # TO gets a chance later in the table.
            if token_val == 0xC5:  # AT
                peek = j
                while peek < len(input_upper) and input_upper[peek] == " ":
                    peek += 1
                if peek < len(input_upper) and input_upper[peek] in ("N", "O"):
                    continue  # reject AT, let ATN or TO match instead

            return token_val, j - start

        return None, 0

    # ---- keep _parse_string_literal / _parse_numeric_literal for any
    #      callers that still reference them, but they are no longer used
    #      by _tokenize_content.

    def _parse_string_literal(self, content: str, start: int) -> tuple[bytes, int]:
        """Parse string literal in Applesoft BASIC format."""
        # Simple ROM-style: copy from opening quote to closing quote or EOL
        result = bytearray()
        i = start
        if i < len(content) and content[i] == '"':
            result.append(ord('"'))
            i += 1
            while i < len(content):
                result.append(ord(content[i]))
                if content[i] == '"':
                    i += 1
                    break
                i += 1
        return bytes(result), i - start

    def _parse_numeric_literal(self, content: str, start: int) -> tuple[bytes, int]:
        """Parse numeric literal in Applesoft BASIC format."""
        i = start
        while i < len(content) and (
            content[i].isdigit() or content[i] == "." or content[i].upper() == "E"
        ):
            i += 1
        number_str = content[start:i]
        return number_str.encode("ascii"), i - start
