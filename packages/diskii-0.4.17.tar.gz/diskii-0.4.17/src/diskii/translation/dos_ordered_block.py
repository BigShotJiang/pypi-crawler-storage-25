"""DOS-ordered block translator for ProDOS filesystems in .dsk files."""

from ..exceptions import CorruptedImageError
from ..exceptions import IOError as DiskiiIOError
from .interface import BlockTranslator, TranslationMode


class DOSOrderedBlockTranslator(BlockTranslator):
    """Handles ProDOS blocks in DOS sector-ordered disk images.

    This translator reads DOS-ordered sectors and reorders them into
    proper ProDOS blocks, using the official Apple II ProDOS Technical
    Reference Manual sector-to-block conversion table.
    """

    mode = TranslationMode.DOS_ORDER
    SECTORS_PER_TRACK = 16

    def _calculate_total_blocks(self) -> int:
        """Calculate total blocks from file size."""
        total_sectors = self.file_path.stat().st_size // 256
        return total_sectors // 2

    def read_block(self, logical_block_num: int) -> bytes:
        """Read a ProDOS block using DOS sector translation.

        Args:
            logical_block_num: Logical block number as expected by ProDOS code

        Returns:
            512-byte block data
        """
        try:
            return self._read_physical_block(logical_block_num)
        except Exception as e:
            raise CorruptedImageError(
                f"Failed to read DOS-ordered ProDOS block {logical_block_num}: {e}",
                str(self.file_path),
            ) from e

    def _read_physical_block(self, block_num: int) -> bytes:
        """Read a physical block using DOS sector-to-block translation.

        Args:
            block_num: Physical block number in the image

        Returns:
            512-byte block data with sectors in ProDOS order
        """
        if block_num < 0 or block_num >= self.total_blocks:
            raise ValueError(
                f"Block {block_num} out of range (0-{self.total_blocks - 1})"
            )

        # Use official Apple II ProDOS Technical Reference Manual Figure B-15
        # Sector to Block conversion table

        track = block_num // 8
        block_in_track = block_num % 8

        # Official Apple II ProDOS sector offset table (Figure B-15)
        # Sector:       0 1 2 3 4 5 6 7 8 9 A B C D E F
        # Sector Offset:0 7 6 6 5 5 4 4 3 3 2 2 1 1 0 7
        # Half of Block:1 1 2 1 2 1 2 1 2 1 2 1 2 1 2 2

        # Find which DOS sectors map to this block
        sector1 = None
        sector2 = None

        for dos_sector in range(16):
            sector_offsets = [0, 7, 6, 6, 5, 5, 4, 4, 3, 3, 2, 2, 1, 1, 0, 7]
            half_of_blocks = [1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 2]

            if sector_offsets[dos_sector] == block_in_track:
                if half_of_blocks[dos_sector] == 1:
                    sector1 = dos_sector
                elif half_of_blocks[dos_sector] == 2:
                    sector2 = dos_sector

        if sector1 is None or sector2 is None:
            raise ValueError(f"Could not find DOS sectors for block {block_num}")

        # Calculate linear sector numbers within the disk
        linear_sector1 = track * self.SECTORS_PER_TRACK + sector1
        linear_sector2 = track * self.SECTORS_PER_TRACK + sector2

        # Read both sectors
        sector1_data = self._read_dos_sector(linear_sector1)

        if linear_sector2 < self.total_sectors:
            sector2_data = self._read_dos_sector(linear_sector2)
        else:
            # Handle edge case where block spans beyond disk
            sector2_data = b"\x00" * 256

        # Return sectors in order: first sector + second sector
        return sector1_data + sector2_data

    def _read_dos_sector(self, linear_sector: int) -> bytes:
        """Read a DOS sector from linear sector number.

        Args:
            linear_sector: Linear sector number (0-based)

        Returns:
            256-byte sector data
        """
        if linear_sector >= self.total_sectors:
            raise ValueError(
                f"Sector {linear_sector} out of range (max {self.total_sectors - 1})"
            )

        try:
            offset = linear_sector * 256
            self.file_handle.seek(offset)
            data = self.file_handle.read(256)

            if len(data) != 256:
                raise CorruptedImageError(
                    f"Sector {linear_sector} incomplete: got {len(data)} bytes, "
                    f"expected 256",
                    str(self.file_path),
                )
            return data

        except OSError as e:
            raise DiskiiIOError(f"Error reading sector {linear_sector}: {e}") from e

    def write_block(self, block_num: int, data: bytes) -> None:
        """Write a ProDOS block using DOS sector translation.

        Args:
            block_num: Logical block number
            data: 512 bytes of block data
        """
        if len(data) != self.BLOCK_SIZE:
            raise ValueError(
                f"Block data must be exactly {self.BLOCK_SIZE} bytes, got {len(data)}"
            )

        # Use the same sector mapping as read operations
        track = block_num // 8
        block_in_track = block_num % 8

        # Official Apple II ProDOS sector offset table (Figure B-15)
        # Find which DOS sectors map to this block
        sector1 = None
        sector2 = None

        for dos_sector in range(16):
            sector_offsets = [0, 7, 6, 6, 5, 5, 4, 4, 3, 3, 2, 2, 1, 1, 0, 7]
            half_of_blocks = [1, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 2]

            if sector_offsets[dos_sector] == block_in_track:
                if half_of_blocks[dos_sector] == 1:
                    sector1 = dos_sector
                elif half_of_blocks[dos_sector] == 2:
                    sector2 = dos_sector

        if sector1 is None or sector2 is None:
            raise ValueError(f"Could not find DOS sectors for block {block_num}")

        # Calculate linear sector numbers within the disk
        linear_sector1 = track * self.SECTORS_PER_TRACK + sector1
        linear_sector2 = track * self.SECTORS_PER_TRACK + sector2

        # Write sectors in order: first sector gets first 256 bytes,
        # second sector gets next 256 bytes
        self._write_dos_sector(linear_sector1, data[:256])
        if linear_sector2 < self.total_sectors:
            self._write_dos_sector(linear_sector2, data[256:])

    def _write_dos_sector(self, linear_sector: int, data: bytes) -> None:
        """Write a DOS sector.

        Args:
            linear_sector: Linear sector number
            data: 256 bytes of sector data
        """
        if len(data) != 256:
            raise ValueError(f"Sector data must be exactly 256 bytes, got {len(data)}")

        if linear_sector >= self.total_sectors:
            raise ValueError(
                f"Sector {linear_sector} out of range (max {self.total_sectors - 1})"
            )

        try:
            offset = linear_sector * 256
            self.file_handle.seek(offset)
            self.file_handle.write(data)
            self.file_handle.flush()
        except OSError as e:
            raise DiskiiIOError(f"Error writing sector {linear_sector}: {e}") from e
