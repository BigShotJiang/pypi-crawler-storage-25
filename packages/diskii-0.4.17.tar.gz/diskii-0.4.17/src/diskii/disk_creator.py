#!/usr/bin/env python3
"""Disk image creation utilities for diskii library."""

from datetime import datetime
from pathlib import Path

from .exceptions import DiskiiError


def create_blank_dos33_image(file_path: str | Path, volume_number: int = 254) -> None:
    """Create a blank DOS 3.3 disk image.

    Args:
        file_path: Path where the disk image will be created
        volume_number: DOS volume number (default 254)
    """
    file_path = Path(file_path)

    # DOS 3.3 specifications
    TRACKS = 35
    SECTORS_PER_TRACK = 16
    BYTES_PER_SECTOR = 256
    TOTAL_SIZE = TRACKS * SECTORS_PER_TRACK * BYTES_PER_SECTOR  # 143,360 bytes

    # Create blank disk image file
    with open(file_path, "wb") as f:
        f.write(b"\x00" * TOTAL_SIZE)

    # Use UnifiedDiskImage to write sectors with proper ordering
    from .image import UnifiedDiskImage
    from .types import FilesystemType, ImageFormat, SectorOrdering

    # Create format specification for DOS 3.3 in DOS ordering
    dos_format = ImageFormat(SectorOrdering.DOS_ORDER, FilesystemType.DOS33)

    with UnifiedDiskImage(file_path, dos_format, read_only=False) as img:
        # Create VTOC (Volume Table of Contents) at track 17, sector 0
        vtoc_data = _create_dos33_vtoc(volume_number)
        img.write_sector(17, 0, vtoc_data)

        # Create initial catalog at track 17, sector 15
        catalog_data = _create_dos33_catalog()
        img.write_sector(17, 15, catalog_data)


def create_blank_prodos_image(
    file_path: str | Path,
    volume_name: str = "BLANK.DISK",
    total_blocks: int = 280,
) -> None:
    """Create a blank ProDOS disk image.

    Args:
        file_path: Path where the disk image will be created
        volume_name: ProDOS volume name (15 chars max)
        total_blocks: Total blocks in the disk (default 280 for 140K disk)
                     Maximum 65535 blocks (32MB)
    """
    file_path = Path(file_path)

    # Validate parameters
    if len(volume_name) > 15:
        raise DiskiiError(f"Volume name too long: {volume_name} (max 15 chars)")
    if total_blocks > 65535:
        raise DiskiiError(f"Too many blocks: {total_blocks} (max 65535)")
    if total_blocks < 5:
        raise DiskiiError(f"Too few blocks: {total_blocks} (min 5)")

    # ProDOS specifications
    BYTES_PER_BLOCK = 512
    # For max-size volumes (65535 blocks), create a full 32MB image (65536 * 512)
    # to match real Apple II hard drive images. The extra block exists in the
    # image file but isn't tracked by the filesystem.
    if total_blocks == 65535:
        total_size = 65536 * BYTES_PER_BLOCK
    else:
        total_size = total_blocks * BYTES_PER_BLOCK

    # Create blank disk image
    with open(file_path, "wb") as f:
        # Initialize with zeros
        f.write(b"\x00" * total_size)

        # Create boot blocks (blocks 0-1) - minimal boot code
        f.seek(0)
        boot_block = _create_prodos_boot_blocks()
        f.write(boot_block)

        # Create volume directory (block 2)
        f.seek(2 * BYTES_PER_BLOCK)
        volume_dir = _create_prodos_volume_directory(volume_name, total_blocks)
        f.write(volume_dir)

        # Create directory continuation blocks (blocks 3, 4, 5)
        f.seek(3 * BYTES_PER_BLOCK)
        continuation_block3 = _create_prodos_directory_continuation(
            prev_block=2, next_block=4
        )
        f.write(continuation_block3)

        f.seek(4 * BYTES_PER_BLOCK)
        continuation_block4 = _create_prodos_directory_continuation(
            prev_block=3, next_block=5
        )
        f.write(continuation_block4)

        f.seek(5 * BYTES_PER_BLOCK)
        continuation_block5 = _create_prodos_directory_continuation(
            prev_block=4, next_block=0
        )  # 0 = end of chain
        f.write(continuation_block5)

        # Create volume bitmap (block 6 and following)
        bitmap_start_block = 6
        bitmap_blocks_needed = (
            total_blocks + 4095
        ) // 4096  # Each block covers 4096 blocks

        f.seek(bitmap_start_block * BYTES_PER_BLOCK)
        volume_bitmap = _create_prodos_volume_bitmap(
            total_blocks, bitmap_start_block, bitmap_blocks_needed
        )
        f.write(volume_bitmap)


def create_blank_dos_ordered_prodos_image(
    file_path: str | Path,
    volume_name: str = "BLANK.DISK",
    total_blocks: int = 280,
) -> None:
    """Create a blank ProDOS disk image with DOS sector ordering (.dsk format).

    Args:
        file_path: Path where the disk image will be created
        volume_name: ProDOS volume name (15 chars max)
        total_blocks: Total blocks in the disk (default 280 for 140K disk)
    """
    file_path = Path(file_path)

    # Validate parameters (same as regular ProDOS)
    if len(volume_name) > 15:
        raise DiskiiError(f"Volume name too long: {volume_name} (max 15 chars)")
    if total_blocks > 65535:
        raise DiskiiError(f"Too many blocks: {total_blocks} (max 65535)")
    if total_blocks < 5:
        raise DiskiiError(f"Too few blocks: {total_blocks} (min 5)")

    # Create the disk with DOS sector ordering
    # DOS 3.3 specifications for physical layout
    TRACKS = 35
    SECTORS_PER_TRACK = 16
    BYTES_PER_SECTOR = 256
    TOTAL_SIZE = TRACKS * SECTORS_PER_TRACK * BYTES_PER_SECTOR  # 143,360 bytes

    # Ensure we don't exceed DOS disk capacity
    max_dos_blocks = TOTAL_SIZE // 512  # 280 blocks max for standard DOS disk
    if total_blocks > max_dos_blocks:
        raise DiskiiError(
            f"Too many blocks for DOS-ordered disk: {total_blocks} "
            f"(max {max_dos_blocks})"
        )

    # Create blank disk image
    with open(file_path, "wb") as f:
        f.write(b"\x00" * TOTAL_SIZE)

    # Use UnifiedDiskImage to write ProDOS structures with DOS sector ordering
    from .image import UnifiedDiskImage
    from .types import FilesystemType, ImageFormat, SectorOrdering

    # Create image format descriptor for DOS-ordered ProDOS
    image_format = ImageFormat(SectorOrdering.DOS_ORDER, FilesystemType.PRODOS)

    with UnifiedDiskImage(file_path, image_format, read_only=False) as img:
        # Create boot blocks (blocks 0-1)
        img.write_block(0, b"\x00" * 512)  # Boot block 0
        img.write_block(1, b"\x00" * 512)  # Boot block 1

        # Create volume directory header block (block 2)
        volume_dir = _create_prodos_volume_directory(volume_name, total_blocks)
        img.write_block(2, volume_dir)

        # Create directory continuation block (block 3)
        continuation_block = _create_prodos_directory_continuation(
            2, 0
        )  # Prev=2 (volume dir), Next=0 (end)
        img.write_block(3, continuation_block)

        # Blocks 4-5 are typically unused but available
        img.write_block(4, b"\x00" * 512)
        img.write_block(5, b"\x00" * 512)

        # Create volume bitmap (block 6 and following)
        bitmap_start_block = 6
        bitmap_blocks_needed = (
            total_blocks + 4095
        ) // 4096  # Each block covers 4096 blocks

        volume_bitmap = _create_prodos_volume_bitmap(
            total_blocks, bitmap_start_block, bitmap_blocks_needed
        )
        img.write_block(bitmap_start_block, volume_bitmap)


def create_blank_dos32_image(file_path: str | Path, volume_number: int = 254) -> None:
    """Create a blank DOS 3.2 disk image (13-sector format).

    Args:
        file_path: Path where the disk image will be created
        volume_number: DOS volume number (default 254)
    """
    file_path = Path(file_path)

    # DOS 3.2 specifications
    TRACKS = 35
    SECTORS_PER_TRACK = 13
    BYTES_PER_SECTOR = 256
    TOTAL_SIZE = TRACKS * SECTORS_PER_TRACK * BYTES_PER_SECTOR  # 116,480 bytes

    # Create blank disk image file
    with open(file_path, "wb") as f:
        f.write(b"\x00" * TOTAL_SIZE)

    # Use UnifiedDiskImage to write sectors with proper ordering
    from .image import UnifiedDiskImage
    from .types import FilesystemType, ImageFormat, SectorOrdering

    # Create format specification for DOS 3.2 in DOS32 ordering (13-sector)
    dos32_format = ImageFormat(SectorOrdering.DOS32_ORDER, FilesystemType.DOS32)

    with UnifiedDiskImage(file_path, dos32_format, read_only=False) as img:
        # Create VTOC at track 17, sector 0
        vtoc_data = _create_dos32_vtoc(volume_number)
        img.write_sector(17, 0, vtoc_data)

        # Create initial catalog at track 17, sector 12 (different from DOS 3.3)
        catalog_data = _create_dos32_catalog()
        img.write_sector(17, 12, catalog_data)


def _get_dos_sector_offset(track: int, sector: int) -> int:
    """Get file offset for DOS 3.3 track/sector."""
    return (track * 16 + sector) * 256


def _get_dos32_sector_offset(track: int, sector: int) -> int:
    """Get file offset for DOS 3.2 track/sector."""
    return (track * 13 + sector) * 256


def _create_dos33_vtoc(volume_number: int) -> bytes:
    """Create DOS 3.3 VTOC (Volume Table of Contents)."""
    vtoc = bytearray(256)

    # VTOC header
    vtoc[0x01] = 17  # Catalog track
    vtoc[0x02] = 15  # Catalog sector (first catalog sector)
    vtoc[0x03] = 3  # Release number
    vtoc[0x06] = volume_number  # Volume number (byte 6)
    vtoc[0x27] = 122  # Maximum track/sector list sectors
    vtoc[0x30] = 1  # Last track where sectors were allocated
    vtoc[0x31] = 1  # Direction of track allocation (+1)
    vtoc[0x34] = 35  # Number of tracks per disk
    vtoc[0x35] = 16  # Number of sectors per track
    vtoc[0x36] = 0  # Number of bytes per sector (low byte)
    vtoc[0x37] = 1  # Number of bytes per sector (high byte) -> 256 bytes

    # Track allocation bitmap - mark most sectors as free
    # Each track has 2 bytes for sector allocation (16 bits for 16 sectors)
    for track in range(35):
        offset = 0x38 + track * 4  # Track allocation starts at 0x38

        if track == 0:
            # Boot track - mark sectors 0-2 as used, rest free
            vtoc[offset] = 0xF8  # Low byte: 11111000 (sectors 0-2 used)
            vtoc[offset + 1] = 0xFF  # High byte: all free
        elif track == 17:
            # VTOC/Catalog track - mark VTOC and catalog sectors as used
            vtoc[offset] = 0x00  # Sector 0 (VTOC) used
            vtoc[offset + 1] = 0x7F  # Sector 15 (catalog) used, others free
        else:
            # All other tracks - all sectors free
            vtoc[offset] = 0xFF
            vtoc[offset + 1] = 0xFF

    return bytes(vtoc)


def _create_dos32_vtoc(volume_number: int) -> bytes:
    """Create DOS 3.2 VTOC."""
    vtoc = bytearray(256)

    # VTOC header for DOS 3.2
    vtoc[0x01] = 17  # Catalog track
    vtoc[0x02] = 12  # Catalog sector (DOS 3.2 uses sector 12)
    vtoc[0x03] = 2  # Release number (DOS 3.2)
    vtoc[0x27] = 122  # Maximum track/sector list sectors
    vtoc[0x30] = 1  # Last track where sectors were allocated
    vtoc[0x31] = 1  # Direction of track allocation
    vtoc[0x34] = 35  # Number of tracks per disk
    vtoc[0x35] = 13  # Number of sectors per track (DOS 3.2 difference)
    vtoc[0x36] = 0  # Number of bytes per sector (low)
    vtoc[0x37] = 1  # Number of bytes per sector (high)

    # Track allocation bitmap for 13 sectors per track
    for track in range(35):
        offset = 0x38 + track * 4

        if track == 0:
            # Boot track
            vtoc[offset] = 0xF8  # Sectors 0-2 used
            vtoc[offset + 1] = 0x1F  # Only 13 sectors total (bits 0-12)
        elif track == 17:
            # VTOC/Catalog track
            vtoc[offset] = 0x00  # Sector 0 (VTOC) used
            vtoc[offset + 1] = 0x0F  # Sector 12 (catalog) used, others free
        else:
            # All other tracks - all 13 sectors free
            vtoc[offset] = 0xFF
            vtoc[offset + 1] = 0x1F  # Only 13 bits set (0-12)

    return bytes(vtoc)


def _create_dos33_catalog() -> bytes:
    """Create initial empty DOS 3.3 catalog sector."""
    catalog = bytearray(256)

    # Catalog header
    catalog[0x00] = 0x00  # Reserved/unused
    catalog[0x01] = 0x00  # Next catalog track (0 = no next sector)
    catalog[0x02] = 0x00  # Next catalog sector

    # Mark all file entries as deleted (0x00 in track field)
    for i in range(7):  # 7 file entries per catalog sector
        offset = 0x0B + i * 35  # File entries start at 0x0B
        catalog[offset] = 0x00  # Track = 0x00 (deleted entry)

    return bytes(catalog)


def _create_dos33_catalog_continuation() -> bytes:
    """Create DOS 3.3 catalog continuation sector."""
    catalog = bytearray(256)

    # Catalog header for continuation sector
    catalog[0x00] = 0x00  # Reserved/unused
    catalog[0x01] = 0x11  # Previous catalog track (17)
    catalog[0x02] = 0x0F  # Previous catalog sector (15) - link back

    # Mark all file entries as deleted (0x00 in track field)
    for i in range(7):  # 7 file entries per catalog sector
        offset = 0x0B + i * 35  # File entries start at 0x0B
        catalog[offset] = 0x00  # Track = 0x00 (deleted entry)

    return bytes(catalog)


def _create_dos32_catalog() -> bytes:
    """Create initial empty DOS 3.2 catalog sector."""
    # DOS 3.2 catalog structure is the same as DOS 3.3
    return _create_dos33_catalog()


def _create_prodos_boot_blocks() -> bytes:
    """Create standard ProDOS boot blocks (blocks 0-1).

    Boot block 0 contains the ProDOS boot loader from ProDOS 2.4.2.
    It searches the volume directory for a file named "PRODOS" and
    loads it. Displays "*** UNABLE TO LOAD PRODOS ***" if not found.
    Block 1 is all zeros.
    """
    boot_data = bytearray(1024)  # 2 blocks = 1024 bytes

    # fmt: off
    standard_boot = bytes([
        0x01, 0x38, 0xB0, 0x03, 0x4C, 0x32, 0xA1, 0x86,
        0x43, 0xC9, 0x03, 0x08, 0x8A, 0x29, 0x70, 0x4A,
        0x4A, 0x4A, 0x4A, 0x09, 0xC0, 0x85, 0x49, 0xA0,
        0xFF, 0x84, 0x48, 0x28, 0xC8, 0xB1, 0x48, 0xD0,
        0x3A, 0xB0, 0x0E, 0xA9, 0x03, 0x8D, 0x00, 0x08,
        0xE6, 0x3D, 0xA5, 0x49, 0x48, 0xA9, 0x5B, 0x48,
        0x60, 0x85, 0x40, 0x85, 0x48, 0xA0, 0x63, 0xB1,
        0x48, 0x99, 0x94, 0x09, 0xC8, 0xC0, 0xEB, 0xD0,
        0xF6, 0xA2, 0x06, 0xBC, 0x1D, 0x09, 0xBD, 0x24,
        0x09, 0x99, 0xF2, 0x09, 0xBD, 0x2B, 0x09, 0x9D,
        0x7F, 0x0A, 0xCA, 0x10, 0xEE, 0xA9, 0x09, 0x85,
        0x49, 0xA9, 0x86, 0xA0, 0x00, 0xC9, 0xF9, 0xB0,
        0x2F, 0x85, 0x48, 0x84, 0x60, 0x84, 0x4A, 0x84,
        0x4C, 0x84, 0x4E, 0x84, 0x47, 0xC8, 0x84, 0x42,
        0xC8, 0x84, 0x46, 0xA9, 0x0C, 0x85, 0x61, 0x85,
        0x4B, 0x20, 0x12, 0x09, 0xB0, 0x68, 0xE6, 0x61,
        0xE6, 0x61, 0xE6, 0x46, 0xA5, 0x46, 0xC9, 0x06,
        0x90, 0xEF, 0xAD, 0x00, 0x0C, 0x0D, 0x01, 0x0C,
        0xD0, 0x6D, 0xA9, 0x04, 0xD0, 0x02, 0xA5, 0x4A,
        0x18, 0x6D, 0x23, 0x0C, 0xA8, 0x90, 0x0D, 0xE6,
        0x4B, 0xA5, 0x4B, 0x4A, 0xB0, 0x06, 0xC9, 0x0A,
        0xF0, 0x55, 0xA0, 0x04, 0x84, 0x4A, 0xAD, 0x02,
        0x09, 0x29, 0x0F, 0xA8, 0xB1, 0x4A, 0xD9, 0x02,
        0x09, 0xD0, 0xDB, 0x88, 0x10, 0xF6, 0x29, 0xF0,
        0xC9, 0x20, 0xD0, 0x3B, 0xA0, 0x10, 0xB1, 0x4A,
        0xC9, 0xFF, 0xD0, 0x33, 0xC8, 0xB1, 0x4A, 0x85,
        0x46, 0xC8, 0xB1, 0x4A, 0x85, 0x47, 0xA9, 0x00,
        0x85, 0x4A, 0xA0, 0x1E, 0x84, 0x4B, 0x84, 0x61,
        0xC8, 0x84, 0x4D, 0x20, 0x12, 0x09, 0xB0, 0x17,
        0xE6, 0x61, 0xE6, 0x61, 0xA4, 0x4E, 0xE6, 0x4E,
        0xB1, 0x4A, 0x85, 0x46, 0xB1, 0x4C, 0x85, 0x47,
        0x11, 0x4A, 0xD0, 0xE7, 0x4C, 0x00, 0x20, 0x4C,
        0x3F, 0x09, 0x26, 0x50, 0x52, 0x4F, 0x44, 0x4F,
        0x53, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
        0x20, 0x20, 0xA5, 0x60, 0x85, 0x44, 0xA5, 0x61,
        0x85, 0x45, 0x6C, 0x48, 0x00, 0x08, 0x1E, 0x24,
        0x3F, 0x45, 0x47, 0x76, 0xF4, 0xD7, 0xD1, 0xB6,
        0x4B, 0xB4, 0xAC, 0xA6, 0x2B, 0x18, 0x60, 0x4C,
        0xBC, 0x09, 0xA9, 0x9F, 0x48, 0xA9, 0xFF, 0x48,
        0xA9, 0x01, 0xA2, 0x00, 0x4C, 0x79, 0xF4, 0x20,
        0x58, 0xFC, 0xA0, 0x1C, 0xB9, 0x50, 0x09, 0x99,
        0xAE, 0x05, 0x88, 0x10, 0xF7, 0x4C, 0x4D, 0x09,
        0xAA, 0xAA, 0xAA, 0xA0, 0xD5, 0xCE, 0xC1, 0xC2,
        0xCC, 0xC5, 0xA0, 0xD4, 0xCF, 0xA0, 0xCC, 0xCF,
        0xC1, 0xC4, 0xA0, 0xD0, 0xD2, 0xCF, 0xC4, 0xCF,
        0xD3, 0xA0, 0xAA, 0xAA, 0xAA, 0xA5, 0x53, 0x29,
        0x03, 0x2A, 0x05, 0x2B, 0xAA, 0xBD, 0x80, 0xC0,
        0xA9, 0x2C, 0xA2, 0x11, 0xCA, 0xD0, 0xFD, 0xE9,
        0x01, 0xD0, 0xF7, 0xA6, 0x2B, 0x60, 0xA5, 0x46,
        0x29, 0x07, 0xC9, 0x04, 0x29, 0x03, 0x08, 0x0A,
        0x28, 0x2A, 0x85, 0x3D, 0xA5, 0x47, 0x4A, 0xA5,
        0x46, 0x6A, 0x4A, 0x4A, 0x85, 0x41, 0x0A, 0x85,
        0x51, 0xA5, 0x45, 0x85, 0x27, 0xA6, 0x2B, 0xBD,
        0x89, 0xC0, 0x20, 0xBC, 0x09, 0xE6, 0x27, 0xE6,
        0x3D, 0xE6, 0x3D, 0xB0, 0x03, 0x20, 0xBC, 0x09,
        0xBC, 0x88, 0xC0, 0x60, 0xA5, 0x40, 0x0A, 0x85,
        0x53, 0xA9, 0x00, 0x85, 0x54, 0xA5, 0x53, 0x85,
        0x50, 0x38, 0xE5, 0x51, 0xF0, 0x14, 0xB0, 0x04,
        0xE6, 0x53, 0x90, 0x02, 0xC6, 0x53, 0x38, 0x20,
        0x6D, 0x09, 0xA5, 0x50, 0x18, 0x20, 0x6F, 0x09,
        0xD0, 0xE3, 0xA0, 0x7F, 0x84, 0x52, 0x08, 0x28,
        0x38, 0xC6, 0x52, 0xF0, 0xCE, 0x18, 0x08, 0x88,
        0xF0, 0xF5, 0xBD, 0x8C, 0xC0, 0x10, 0xFB, 0x00,
    ])
    # fmt: on

    boot_data[: len(standard_boot)] = standard_boot

    return bytes(boot_data)


def _create_prodos_volume_directory(volume_name: str, total_blocks: int) -> bytes:
    """Create ProDOS volume directory (block 2)."""
    volume_dir = bytearray(512)

    # ProDOS directory block header (first 4 bytes)
    volume_dir[0x00] = 0x00  # Previous block pointer (low) - 0 for volume directory
    volume_dir[0x01] = 0x00  # Previous block pointer (high)
    volume_dir[0x02] = 0x03  # Next block pointer (low) - 3 for continuation block
    volume_dir[0x03] = 0x00  # Next block pointer (high)

    # Volume directory header entry starts at offset 4
    # Storage type (0xF in high nibble for volume directory header)
    # and name length (low nibble)
    volume_dir[0x04] = 0xF0 | len(volume_name)  # Storage type 0xF + name length
    volume_dir[0x05 : 0x05 + len(volume_name)] = volume_name.encode("ascii").upper()

    # Reserved field (entry offset 0x10-0x17, block offset 0x14-0x1B)
    # ProDOS 2.4+ stores creation date/time at bytes 2-5 of reserved area
    now = datetime.now()
    date_time = _encode_prodos_datetime(now)
    volume_dir[0x16:0x1A] = date_time  # Creation date in reserved area

    # Creation date/time (current time)
    volume_dir[0x1C:0x20] = date_time

    # Version info
    volume_dir[0x20] = 0x05  # Version (ProDOS 2.4+)
    volume_dir[0x21] = 0x00  # Min version
    volume_dir[0x22] = 0xC3  # Access permissions (destroy/rename/read/write)
    volume_dir[0x23] = 0x27  # Entry length (39 bytes)
    volume_dir[0x24] = 0x0D  # Entries per block (13)
    volume_dir[0x25] = 0x00  # File count (low) - start with 0 files
    volume_dir[0x26] = 0x00  # File count (high)

    # Volume bitmap pointer (block 6)
    volume_dir[0x27] = 0x06  # Bitmap pointer (low)
    volume_dir[0x28] = 0x00  # Bitmap pointer (high)

    # Total blocks
    volume_dir[0x29] = total_blocks & 0xFF  # Total blocks (low)
    volume_dir[0x2A] = (total_blocks >> 8) & 0xFF  # Total blocks (high)

    return bytes(volume_dir)


def _create_prodos_directory_continuation(prev_block: int, next_block: int) -> bytes:
    """Create ProDOS directory continuation block."""
    continuation_block = bytearray(512)

    # Directory block header (first 4 bytes)
    continuation_block[0x00] = prev_block & 0xFF  # Previous block pointer (low)
    continuation_block[0x01] = (prev_block >> 8) & 0xFF  # Previous block pointer (high)
    continuation_block[0x02] = next_block & 0xFF  # Next block pointer (low) - 0 if last
    continuation_block[0x03] = (next_block >> 8) & 0xFF  # Next block pointer (high)

    # Rest of block remains zeros (empty directory entries)
    return bytes(continuation_block)


def _create_prodos_volume_bitmap(
    total_blocks: int, start_block: int, bitmap_blocks: int
) -> bytes:
    """Create ProDOS volume bitmap."""
    bitmap_size = bitmap_blocks * 512
    bitmap = bytearray(bitmap_size)

    # Mark system blocks as used (blocks 0-5 including directory
    # continuation, and bitmap blocks)
    system_blocks = set(
        range(6)
    )  # Blocks 0-5 (includes boot blocks 0-1, volume dir 2, continuation 3, empty 4-5)
    system_blocks.update(
        range(start_block, start_block + bitmap_blocks)
    )  # Bitmap blocks

    # Set bits for all blocks (1 = free, 0 = used)
    for block in range(total_blocks):
        byte_offset = block // 8
        bit_offset = 7 - (block % 8)  # ProDOS uses big-endian bit ordering

        if byte_offset < len(bitmap):
            if block not in system_blocks:
                bitmap[byte_offset] |= 1 << bit_offset  # Mark as free
            # Used blocks remain 0 (already initialized)

    return bytes(bitmap)


def _encode_prodos_datetime(dt: datetime) -> bytes:
    """Encode datetime in ProDOS format."""
    # Use the same encoding as prodos_writer.py for consistency
    from .prodos import datetime_to_prodos_date

    return datetime_to_prodos_date(dt)


# Convenience functions for common disk sizes
def create_140k_dos_disk(file_path: str | Path) -> None:
    """Create standard 140K DOS 3.3 disk."""
    create_blank_dos33_image(file_path)


def create_140k_prodos_disk(
    file_path: str | Path, volume_name: str = "BLANK.DISK"
) -> None:
    """Create standard 140K ProDOS disk."""
    create_blank_prodos_image(file_path, volume_name, 280)  # 280 blocks = 140K


def create_800k_prodos_disk(
    file_path: str | Path, volume_name: str = "BLANK.DISK"
) -> None:
    """Create 800K ProDOS disk."""
    create_blank_prodos_image(file_path, volume_name, 1600)  # 1600 blocks = 800K


def create_32mb_prodos_disk(
    file_path: str | Path, volume_name: str = "BLANK.DISK"
) -> None:
    """Create maximum 32MB ProDOS disk.

    ProDOS total_blocks is a 16-bit field (max 65535), but the image file
    is 65536 * 512 = 32MB to match real Apple II hard drive images.
    """
    create_blank_prodos_image(file_path, volume_name, 65535)  # Maximum ProDOS blocks
