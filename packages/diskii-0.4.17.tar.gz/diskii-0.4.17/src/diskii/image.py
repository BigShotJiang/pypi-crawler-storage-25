"""Base classes for disk image handling."""

from abc import ABC, abstractmethod
from io import BytesIO
from pathlib import Path
from typing import TYPE_CHECKING, Any, BinaryIO, Optional, cast

# Import fcntl for file locking on Unix-like systems
try:
    import fcntl

    HAS_FCNTL = True
except ImportError:
    HAS_FCNTL = False

if TYPE_CHECKING:
    from .translation import BlockTranslator, SectorTranslator

from .exceptions import (
    UnsupportedOperationError,
)
from .translation import TranslatorFactory
from .types import FilesystemType, ImageFormat


class DiskImage(ABC):
    """Abstract base class for disk image readers."""

    def __init__(
        self,
        file_path: str | Path,
        image_format: Optional["ImageFormat"] = None,
        read_only: bool = True,
    ):
        self.file_path = Path(file_path)
        self._file_handle: BinaryIO | None = None
        self._image_format = image_format
        self._read_only = read_only
        self._translator: SectorTranslator | BlockTranslator | None = None

    def __enter__(self) -> "DiskImage":
        mode = "rb" if self._read_only else "r+b"
        self._file_handle = cast(BinaryIO, open(self.file_path, mode))

        try:
            # Apply file locking for write operations (Unix-like systems only)
            if not self._read_only and HAS_FCNTL:
                try:
                    fcntl.flock(
                        self._file_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB
                    )
                except OSError as e:
                    raise RuntimeError(
                        f"Cannot acquire exclusive lock on {self.file_path}: "
                        "file may be in use by another process"
                    ) from e

            # Initialize translator - auto-detect format if not provided
            if self._image_format is None:
                self._image_format = self.format  # Trigger format detection

            assert self._file_handle is not None  # We just opened it above
            self._translator = TranslatorFactory.create_translator(
                self._image_format.filesystem,
                self._image_format.sector_ordering,
                self._file_handle,
                self.file_path,
            )

            return self
        except Exception:
            # Ensure file handle is closed if initialization fails
            if self._file_handle:
                # Release lock if we acquired it
                if not self._read_only and HAS_FCNTL:
                    try:
                        fcntl.flock(self._file_handle.fileno(), fcntl.LOCK_UN)
                    except OSError:
                        pass  # Ignore unlock errors during cleanup
                self._file_handle.close()
                self._file_handle = None
            raise

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        if self._file_handle:
            # Release lock if we acquired it
            if not self._read_only and HAS_FCNTL:
                try:
                    fcntl.flock(self._file_handle.fileno(), fcntl.LOCK_UN)
                except OSError:
                    pass  # Ignore unlock errors during cleanup
            self._file_handle.close()
            self._file_handle = None
        self._translator = None

    @property
    def read_only(self) -> bool:
        """Check if the image is opened in read-only mode."""
        return self._read_only

    @property
    def is_open(self) -> bool:
        """Check if the image file is currently open."""
        return self._file_handle is not None and not self._file_handle.closed

    def _find_file_entry(self, filename: str) -> Any:
        """Find a file entry by filename.

        Accepts every path form ProDOS itself accepts. Matching is
        case-insensitive (ProDOS filenames are case-preserving but
        compared case-insensitively).

          - ``"FILE"`` — top-level
          - ``"DIR/FILE"`` / ``"DIR/SUB/FILE"`` — nested, image-relative
          - ``"/DIR/FILE"`` — image-relative with leading slash
          - ``"/VOLUME/..."`` — fully-qualified ProDOS pathname

        Args:
            filename: Name or path of the file to find.

        Returns:
            The matching file entry.

        Raises:
            FileNotFoundError: If the file doesn't exist.
        """
        normalized = self._normalize_lookup_path(filename)

        # Nested path: search recursively and match against _full_path so that
        # callers can use the same path string that get_all_files() advertises.
        if "/" in normalized:
            target = normalized.upper()
            for entry in self.get_all_files(recursive=True):
                full = getattr(entry, "_full_path", None)
                if full is not None and full.upper() == target:
                    return entry
            raise FileNotFoundError(f"File '{filename}' not found on disk image")

        target = normalized.upper()
        for entry in self.get_file_list():
            if entry.filename.upper() == target:
                return entry
        raise FileNotFoundError(f"File '{filename}' not found on disk image")

    def _normalize_lookup_path(self, filename: str) -> str:
        """Strip slashes and an optional leading volume-name component.

        Returns the image-relative path with no leading/trailing slash.
        If the first segment of an absolute path matches the volume
        name (case-insensitive), it is consumed — that is the
        fully-qualified ProDOS pathname form ``/VOLUME/...``.
        """
        stripped = filename.strip("/")
        if not stripped or "/" not in stripped:
            return stripped

        first, _, rest = stripped.partition("/")
        try:
            volume = self.get_volume_name()
        except Exception:
            volume = ""
        if volume and first.upper() == volume.upper():
            return rest
        return stripped

    def read_block(self, block_num: int) -> bytes:
        """Read a logical block from the disk image."""
        if not self.is_open:
            raise RuntimeError("Image file is not open")

        if self._translator is None:
            raise RuntimeError("Translator not initialized")

        # Check if translator supports block operations
        if hasattr(self._translator, "read_block"):
            return self._translator.read_block(block_num)
        else:
            # Fall back to sector-based operations (convert block to sectors)
            # Block size is always 512 bytes (2 sectors of 256 bytes each)
            # Convert block number to two consecutive linear sectors
            from .addressing import SectorAddress

            # Determine sectors per track based on filesystem
            if (
                self._image_format is not None
                and self._image_format.filesystem == FilesystemType.DOS32
            ):
                sectors_per_track = 13
            else:  # DOS33 or ProDOS
                sectors_per_track = 16

            linear_sector_0 = block_num * 2
            linear_sector_1 = block_num * 2 + 1

            # Convert to track/sector addresses
            addr_0 = SectorAddress.from_linear_sector(
                linear_sector_0, sectors_per_track
            )
            addr_1 = SectorAddress.from_linear_sector(
                linear_sector_1, sectors_per_track
            )

            sector_0 = self._translator.read_sector(addr_0.track, addr_0.sector)
            sector_1 = self._translator.read_sector(addr_1.track, addr_1.sector)
            return sector_0 + sector_1

    def read_sector(self, track: int, sector: int) -> bytes:
        """Read a physical sector from the disk image."""
        if not self.is_open:
            raise RuntimeError("Image file is not open")

        if self._translator is None:
            raise RuntimeError("Translator not initialized")

        return self._translator.read_sector(track, sector)

    def write_block(self, block_num: int, data: bytes) -> None:
        """Write a logical block to the disk image."""
        if self._read_only:
            raise UnsupportedOperationError("write", "read-only image")

        if not self.is_open:
            raise RuntimeError("Image file is not open")

        if self._translator is None:
            raise RuntimeError("Translator not initialized")

        # Check if translator supports block operations
        if hasattr(self._translator, "write_block"):
            self._translator.write_block(block_num, data)
        else:
            # Fall back to sector-based operations (convert block to sectors)
            # Block size is always 512 bytes (2 sectors of 256 bytes each)
            from .addressing import SectorAddress

            # Determine sectors per track based on filesystem
            if (
                self._image_format is not None
                and self._image_format.filesystem == FilesystemType.DOS32
            ):
                sectors_per_track = 13
            else:  # DOS33 or ProDOS
                sectors_per_track = 16

            linear_sector_0 = block_num * 2
            linear_sector_1 = block_num * 2 + 1

            # Convert to track/sector addresses
            addr_0 = SectorAddress.from_linear_sector(
                linear_sector_0, sectors_per_track
            )
            addr_1 = SectorAddress.from_linear_sector(
                linear_sector_1, sectors_per_track
            )

            sector_0 = data[:256]
            sector_1 = data[256:512] if len(data) > 256 else b"\x00" * 256

            self._translator.write_sector(addr_0.track, addr_0.sector, sector_0)
            self._translator.write_sector(addr_1.track, addr_1.sector, sector_1)

    def write_sector(self, track: int, sector: int, data: bytes) -> None:
        """Write a physical sector to the disk image."""
        if self._read_only:
            raise UnsupportedOperationError("write", "read-only image")

        if not self.is_open:
            raise RuntimeError("Image file is not open")

        if self._translator is None:
            raise RuntimeError("Translator not initialized")

        self._translator.write_sector(track, sector, data)

    @abstractmethod
    def get_volume_name(self) -> str:
        """Get the volume name from the disk image."""
        pass

    @abstractmethod
    def get_file_list(self) -> list[Any]:  # Returns FileEntry subclasses
        """Get a list of files on the disk image."""
        pass

    def get_all_files(
        self, recursive: bool = True
    ) -> list[Any]:  # Returns FileEntry subclasses
        """Get all files, with recursive support for subdirectories."""
        return self.get_file_list()

    @abstractmethod
    def get_free_space(self) -> int:
        """Get the amount of free space on the disk in bytes."""
        pass

    def create_file(
        self,
        filename: str,
        file_type: int | str,
        data: bytes | Path | BytesIO,
        **kwargs: Any,
    ) -> None:
        """Create a new file on the disk image.

        Args:
            filename: Name of the file to create
            file_type: File type (int for ProDOS, int or str for DOS)
            data: File content as bytes, Path object, or BytesIO stream
            **kwargs: Additional arguments (aux_type, etc.)
        """
        if self._read_only:
            raise UnsupportedOperationError("create_file", "read-only image")

        # Convert data to bytes if needed
        if isinstance(data, Path):
            data = data.read_bytes()
        elif isinstance(data, BytesIO):
            data = data.read()

        self._create_file_impl(filename, file_type, data, **kwargs)

    def read_file(
        self,
        filename: str,
        output: Path | BytesIO | None = None,
        *,
        strip_binary_headers: bool = False,
    ) -> bytes:
        """Read a file from the disk image.

        Args:
            filename: Name of the file to read
            output: Optional Path or BytesIO to write the data to
            strip_binary_headers: If True, strip DOS headers from binary files

        Returns:
            File content as bytes (also written to output if provided)

        Raises:
            FileNotFoundError: If the file doesn't exist
        """
        file_entry = self._find_file_entry(filename)

        # Read the file data
        data = cast(
            bytes, file_entry.read_data(self, strip_binary_headers=strip_binary_headers)
        )

        # Write to output if provided
        if output is not None:
            if isinstance(output, Path):
                output.write_bytes(data)
            elif isinstance(output, BytesIO):
                output.write(data)
                output.seek(0)  # Reset position for reading

        return data

    def file_exists(self, filename: str) -> bool:
        """Check if a file exists on the disk image.

        Args:
            filename: Name of the file to check

        Returns:
            True if the file exists, False otherwise
        """
        try:
            self._find_file_entry(filename)
            return True
        except FileNotFoundError:
            return False

    def delete_file(self, filename: str) -> None:
        """Delete a file from the disk image."""
        if self._read_only:
            raise UnsupportedOperationError("delete_file", "read-only image")
        self._delete_file_impl(filename)

    def create_files(
        self,
        files: dict[str, tuple[int | str, bytes | Path | BytesIO]],
        **kwargs: Any,
    ) -> None:
        """Create multiple files in a single operation.

        Args:
            files: Dict mapping filename to (file_type, data) tuples
            **kwargs: Additional arguments passed to each create_file call
        """
        if self._read_only:
            raise UnsupportedOperationError("create_files", "read-only image")

        for filename, (file_type, data) in files.items():
            self.create_file(filename, file_type, data, **kwargs)

    def delete_files(self, filenames: list[str]) -> None:
        """Delete multiple files in a single operation.

        Args:
            filenames: List of filenames to delete
        """
        if self._read_only:
            raise UnsupportedOperationError("delete_files", "read-only image")

        for filename in filenames:
            self.delete_file(filename)

    def copy_file(self, source_filename: str, dest_filename: str) -> None:
        """Copy a file within the disk image.

        Args:
            source_filename: Name of the file to copy
            dest_filename: Name for the copy

        Raises:
            FileNotFoundError: If source file doesn't exist
        """
        if self._read_only:
            raise UnsupportedOperationError("copy_file", "read-only image")

        source_entry = self._find_file_entry(source_filename)
        data = source_entry.read_data(self)

        # Convert file type to appropriate format for this filesystem
        from .fileentry import convert_file_type

        file_type = source_entry.file_type
        if self._image_format and self._image_format.filesystem in (
            FilesystemType.DOS33,
            FilesystemType.DOS32,
        ):
            file_type = convert_file_type(file_type, "dos")
        elif (
            self._image_format
            and self._image_format.filesystem == FilesystemType.PRODOS
        ):
            file_type = convert_file_type(file_type, "prodos")

        self.create_file(dest_filename, file_type, data)

    def open_file(self, filename: str, mode: str = "r") -> "FileContextManager":
        """Open a file for reading/writing with context manager support.

        Args:
            filename: Name of the file to open
            mode: File mode - "r" for read, "w" for write, "a" for append

        Returns:
            FileContextManager instance for use with 'with' statement

        Example:
            with image.open_file("HELLO") as f:
                data = f.read()

            with image.open_file("NEWFILE", "w") as f:
                f.write(b"Hello, World!")
        """
        return FileContextManager(self, filename, mode)

    def modify_file_attributes(self, filename: str, **attrs: Any) -> None:
        """Modify file attributes (file type, aux type, etc.).

        Args:
            filename: Name of the file to modify
            **attrs: Attributes to modify (file_type, aux_type, access, etc.)
        """
        if self._read_only:
            raise UnsupportedOperationError("modify_file_attributes", "read-only image")
        self._modify_file_attributes_impl(filename, **attrs)

    def truncate_file(self, filename: str, new_size: int) -> None:
        """Truncate a file to a new size.

        Args:
            filename: Name of the file to truncate
            new_size: New size in bytes
        """
        if self._read_only:
            raise UnsupportedOperationError("truncate_file", "read-only image")
        if new_size < 0:
            raise ValueError("File size cannot be negative")
        self._truncate_file_impl(filename, new_size)

    def move_file(self, src_filename: str, dest_filename: str) -> None:
        """Move/rename a file on the disk image.

        Args:
            src_filename: Current name of the file
            dest_filename: New name/location for the file
        """
        if self._read_only:
            raise UnsupportedOperationError("move_file", "read-only image")
        self._move_file_impl(src_filename, dest_filename)

    def rename_file(self, old_filename: str, new_filename: str) -> None:
        """Rename a file on the disk image.

        Args:
            old_filename: Current name of the file
            new_filename: New name for the file
        """
        if self._read_only:
            raise UnsupportedOperationError("rename_file", "read-only image")
        self._move_file_impl(old_filename, new_filename)

    @abstractmethod
    def _create_file_impl(
        self, filename: str, file_type: int | str, data: bytes, **kwargs: Any
    ) -> None:
        """Implementation-specific file creation."""
        pass

    @abstractmethod
    def _delete_file_impl(self, filename: str) -> None:
        """Implementation-specific file deletion."""
        pass

    @abstractmethod
    def _modify_file_attributes_impl(self, filename: str, **attrs: Any) -> None:
        """Implementation-specific file attribute modification."""
        pass

    @abstractmethod
    def _truncate_file_impl(self, filename: str, new_size: int) -> None:
        """Implementation-specific file truncation."""
        pass

    @abstractmethod
    def _move_file_impl(self, src_filename: str, dest_filename: str) -> None:
        """Implementation-specific file move/rename."""
        pass

    @property
    def format(self) -> "ImageFormat":
        """Get the image format type."""
        if self._image_format is None:
            # Fallback: detect format if not provided
            from .detection import detect_format

            self._image_format = detect_format(self.file_path)
        return self._image_format

    @property
    def total_blocks(self) -> int:
        """Get the total number of blocks in the image."""
        if self._translator is None:
            # Fallback calculation
            return self.file_path.stat().st_size // 512

        if hasattr(self._translator, "total_blocks"):
            return self._translator.total_blocks
        else:
            # For sector-based translators, convert sectors to blocks
            return self._translator.total_sectors // 2

    @property
    def total_sectors(self) -> int:
        """Get the total number of sectors in the image."""
        if self._translator is None:
            # Fallback calculation
            return self.file_path.stat().st_size // 256

        return self._translator.total_sectors


class UnifiedDiskImage(DiskImage):
    """Unified disk image handler that supports all filesystem/ordering combinations."""

    def __init__(
        self,
        file_path: str | Path,
        image_format: Optional["ImageFormat"] = None,
        read_only: bool = True,
    ):
        super().__init__(file_path, image_format, read_only)
        self._volume_name: str | None = None
        self._file_list_cache: list | None = None

    def get_volume_name(self) -> str:
        """Get the volume name from the appropriate filesystem."""
        if self._volume_name is None:
            if self._image_format is None:
                self._image_format = self.format  # Trigger format detection

            if self._image_format.filesystem == FilesystemType.PRODOS:
                from .prodos import parse_prodos_directory

                directory = parse_prodos_directory(self)
                self._volume_name = directory.volume_name
            elif self._image_format.filesystem == FilesystemType.DOS33:
                from .dos import DOSCatalog

                dos33_catalog = DOSCatalog(self)
                self._volume_name = dos33_catalog.vtoc.volume_name
            elif self._image_format.filesystem == FilesystemType.DOS32:
                from .dos import DOS32Catalog

                dos32_catalog = DOS32Catalog(self)
                self._volume_name = dos32_catalog.vtoc.volume_name
            else:
                self._volume_name = "Unknown"  # type: ignore[unreachable]

        return self._volume_name

    def get_file_list(self) -> list[Any]:  # Returns FileEntry subclasses
        """Get a list of files using the appropriate filesystem parser."""
        if self._file_list_cache is not None:
            return self._file_list_cache

        if self._image_format is None:
            self._image_format = self.format  # Trigger format detection

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import parse_prodos_directory

            directory = parse_prodos_directory(self)
            self._file_list_cache = directory.parse()
        elif self._image_format.filesystem == FilesystemType.DOS33:
            from .dos import parse_dos33_catalog

            dos33_catalog = parse_dos33_catalog(self)
            self._file_list_cache = dos33_catalog.parse()
        elif self._image_format.filesystem == FilesystemType.DOS32:
            from .dos import parse_dos32_catalog

            dos32_catalog = parse_dos32_catalog(self)
            self._file_list_cache = dos32_catalog.parse()
        else:
            self._file_list_cache = []  # type: ignore[unreachable]

        return self._file_list_cache

    def get_all_files(
        self, recursive: bool = True
    ) -> list[Any]:  # Returns FileEntry subclasses
        """Get all files, with recursive support for ProDOS."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import parse_prodos_directory

            directory = parse_prodos_directory(self)
            return directory.get_all_files(recursive=recursive)
        else:
            # DOS doesn't support subdirectories
            return self.get_file_list()

    def get_free_space(self) -> int:
        """Get the amount of free space on the disk in bytes."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import parse_prodos_directory

            volume = parse_prodos_directory(self)
            free_space_info = volume.get_free_space_info()
            free_blocks = int(free_space_info.get("free_blocks", 0))
            return free_blocks * 512
        elif self._image_format.filesystem == FilesystemType.DOS33:
            from .dos import DOSVTOC

            dos33_vtoc = DOSVTOC(self)
            free_sectors = dos33_vtoc.free_sectors
            return free_sectors * 256
        elif self._image_format.filesystem == FilesystemType.DOS32:
            from .dos import DOS32VTOC

            dos32_vtoc = DOS32VTOC(self)
            free_sectors = dos32_vtoc.free_sectors
            return free_sectors * 256
        else:
            return 0  # type: ignore[unreachable]

    def _create_file_impl(
        self, filename: str, file_type: int | str, data: bytes, **kwargs: Any
    ) -> None:
        """Create a new file using the appropriate writer."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .file_type_conversion import (
                get_prodos_aux_type_for_basic,
                normalize_prodos_file_type,
            )
            from .prodos import create_prodos_file

            # Normalize file type to ProDOS integer format
            prodos_file_type = normalize_prodos_file_type(file_type)

            # Set default aux_type for BASIC programs if not specified
            if "aux_type" not in kwargs:
                aux_type = get_prodos_aux_type_for_basic(file_type)
                if aux_type != 0:
                    kwargs["aux_type"] = aux_type

            create_prodos_file(self, filename, prodos_file_type, data, **kwargs)

        elif self._image_format.filesystem in (
            FilesystemType.DOS33,
            FilesystemType.DOS32,
        ):
            from .dos import create_dos_file
            from .file_type_conversion import normalize_dos_file_type

            # Normalize file type to DOS string format
            dos_file_type = normalize_dos_file_type(file_type)
            create_dos_file(self, filename, dos_file_type, data, **kwargs)

        # Invalidate file list cache since we modified the filesystem
        self._file_list_cache = None

    def _delete_file_impl(self, filename: str) -> None:
        """Delete a file using the appropriate writer."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import delete_prodos_file

            delete_prodos_file(self, filename)
        elif self._image_format.filesystem in (
            FilesystemType.DOS33,
            FilesystemType.DOS32,
        ):
            from .dos import delete_dos_file

            delete_dos_file(self, filename)

        # Invalidate file list cache since we modified the filesystem
        self._file_list_cache = None

    def _modify_file_attributes_impl(self, filename: str, **attrs: Any) -> None:
        """Modify file attributes using the appropriate writer."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import modify_prodos_file_attributes

            modify_prodos_file_attributes(self, filename, **attrs)
        else:
            raise UnsupportedOperationError("modify_file_attributes", "DOS filesystem")

        # Invalidate file list cache since we modified the filesystem
        self._file_list_cache = None

    def _truncate_file_impl(self, filename: str, new_size: int) -> None:
        """Truncate a file using the appropriate writer."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import truncate_prodos_file

            truncate_prodos_file(self, filename, new_size)
        else:
            raise UnsupportedOperationError("truncate_file", "DOS filesystem")

        # Invalidate file list cache since we modified the filesystem
        self._file_list_cache = None

    def _move_file_impl(self, src_filename: str, dest_filename: str) -> None:
        """Move/rename a file using the appropriate writer."""
        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import move_prodos_file

            move_prodos_file(self, src_filename, dest_filename)
        elif self._image_format.filesystem in (
            FilesystemType.DOS33,
            FilesystemType.DOS32,
        ):
            from .dos import rename_dos_file

            rename_dos_file(self, src_filename, dest_filename)

        # Invalidate file list cache since we modified the filesystem
        self._file_list_cache = None

    def create_directory(self, directory_path: str) -> None:
        """Create a new directory (ProDOS only).

        Args:
            directory_path: Path of the directory to create (e.g., "SUBDIR")
        """
        if self._read_only:
            raise UnsupportedOperationError("create_directory", "read-only image")

        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import create_prodos_directory

            create_prodos_directory(self, directory_path)
        else:
            raise UnsupportedOperationError("create_directory", "DOS filesystem")

    def delete_directory(self, directory_path: str) -> None:
        """Delete a directory (ProDOS only).

        Args:
            directory_path: Path of the directory to delete (e.g., "SUBDIR")
        """
        if self._read_only:
            raise UnsupportedOperationError("delete_directory", "read-only image")

        if self._image_format is None:
            self._image_format = self.format

        if self._image_format.filesystem == FilesystemType.PRODOS:
            from .prodos import delete_prodos_directory

            delete_prodos_directory(self, directory_path)
        else:
            raise UnsupportedOperationError("delete_directory", "DOS filesystem")

    def __str__(self) -> str:
        """String representation of the disk image."""
        if self._image_format is None:
            self._image_format = self.format  # Trigger format detection

        filesystem_name = self._image_format.filesystem.name
        return f"UnifiedDiskImage({self.file_path.name}, {filesystem_name})"


def _guess_dos_file_type_from_content(data: bytes) -> str:
    """Guess appropriate DOS file type by analyzing file content.

    Args:
        data: File content bytes

    Returns:
        Single-character DOS file type: 'T', 'A', 'I', 'B', etc.
    """
    if not data:
        return "T"  # Empty files default to text

    # Check for Applesoft BASIC tokens
    # Applesoft structure: next-line-ptr (2 bytes) + line-number (2 bytes) + tokens...
    if len(data) >= 10:
        # Look for high-bit tokens (0x80+) in the token area after the 4-byte header
        token_count = sum(1 for b in data[4:10] if b >= 0x80)
        if token_count >= 2:
            return "A"  # Applesoft BASIC

    # Check for Integer BASIC patterns
    if len(data) >= 3 and data[0] in (0x01, 0x02, 0x03):
        return "I"  # Integer BASIC

    # Check if content is primarily printable ASCII text (sample first 512 bytes)
    sample = data[:512]
    printable_chars = sum(1 for b in sample if 32 <= b <= 126 or b in (9, 10, 13))
    if printable_chars / len(sample) > 0.8:
        return "T"  # Text

    # Default to binary (safer than corrupting binary data as text)
    return "B"  # Binary


class FileContextManager:
    """Context manager for file operations within disk images."""

    def __init__(self, disk_image: DiskImage, filename: str, mode: str):
        self.disk_image = disk_image
        self.filename = filename
        self.mode = mode.lower()
        self._data = BytesIO()
        self._closed = False

        # Validate mode
        if self.mode not in ("r", "w", "a"):
            raise ValueError(f"Invalid mode '{mode}'. Must be 'r', 'w', or 'a'")

        # Check read-only status for write operations
        if self.mode in ("w", "a") and disk_image.read_only:
            raise UnsupportedOperationError(
                f"open_file mode '{mode}'", "read-only image"
            )

    def __enter__(self) -> "FileContextManager":
        """Enter the context manager."""
        if self._closed:
            raise RuntimeError("FileContextManager is closed")

        # For read and append modes, load existing file data if it exists
        if self.mode in ("r", "a"):
            try:
                existing_data = self.disk_image.read_file(self.filename)
                self._data = BytesIO(existing_data)
                if self.mode == "a":
                    # Position at end for append mode
                    self._data.seek(0, 2)
                else:
                    # Position at start for read mode
                    self._data.seek(0)
            except FileNotFoundError:
                if self.mode == "r":
                    raise  # Re-raise for read mode
                # For append mode, start with empty data if file doesn't exist
                self._data = BytesIO()

        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit the context manager. Skips write-back if an exception occurred."""
        if not self._closed and self.mode in ("w", "a") and exc_type is None:
            # Save data back to disk for write/append modes (only on clean exit)
            self._data.seek(0)
            data = self._data.read()

            # Determine file type — try to preserve existing, default to binary
            from .fileentry import convert_file_type

            file_type: str | int = "B"
            try:
                entry = self.disk_image._find_file_entry(self.filename)
                converted = convert_file_type(entry.file_type, "dos")
                if isinstance(converted, (str, int)):
                    file_type = converted
                # Delete existing file first (DOS doesn't support overwriting)
                self.disk_image.delete_file(self.filename)
            except FileNotFoundError:
                pass  # New file, use default type

            self.disk_image.create_file(self.filename, file_type, data)

        self._closed = True

    def read(self, size: int = -1) -> bytes:
        """Read data from the file."""
        if self._closed:
            raise RuntimeError("I/O operation on closed file")
        if self.mode not in ("r", "a"):
            raise RuntimeError(f"File not open for reading (mode: '{self.mode}')")
        return self._data.read(size)

    def write(self, data: bytes) -> int:
        """Write data to the file."""
        if self._closed:
            raise RuntimeError("I/O operation on closed file")
        if self.mode not in ("w", "a"):
            raise RuntimeError(f"File not open for writing (mode: '{self.mode}')")
        return self._data.write(data)

    def seek(self, offset: int, whence: int = 0) -> int:
        """Seek to a position in the file."""
        if self._closed:
            raise RuntimeError("I/O operation on closed file")
        return self._data.seek(offset, whence)

    def tell(self) -> int:
        """Get current position in the file."""
        if self._closed:
            raise RuntimeError("I/O operation on closed file")
        return self._data.tell()

    def close(self) -> None:
        """Close the file context manager."""
        if not self._closed:
            self.__exit__(None, None, None)
