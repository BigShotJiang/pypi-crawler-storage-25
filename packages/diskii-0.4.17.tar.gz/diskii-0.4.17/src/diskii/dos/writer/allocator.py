"""DOS track/sector allocation management."""

import struct
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...image import UnifiedDiskImage

from ...exceptions import FilesystemError
from ..dos32 import DOS32VTOC
from ..dos33 import DOSVTOC


def _invalidate_image_cache(image: "UnifiedDiskImage") -> None:
    """Invalidate file list cache if image supports it."""
    if hasattr(image, "_file_list_cache"):
        image._file_list_cache = None


class DOSTrackSectorAllocator:
    """Manages track/sector allocation using the DOS VTOC."""

    def __init__(
        self,
        image: "UnifiedDiskImage",
        vtoc_class: type[DOSVTOC] | type[DOS32VTOC] = DOSVTOC,
    ) -> None:
        self.image = image
        self.vtoc_class = vtoc_class
        self._vtoc: DOSVTOC | DOS32VTOC | None = None

    @property
    def vtoc(self) -> DOSVTOC | DOS32VTOC:
        """Get or create VTOC instance."""
        if self._vtoc is None:
            self._vtoc = self.vtoc_class(self.image)
        assert self._vtoc is not None  # We just assigned it above
        return self._vtoc

    def find_free_sectors(self, count: int) -> list[tuple[int, int]]:
        """Find free track/sector pairs.

        Args:
            count: Number of sectors needed

        Returns:
            List of (track, sector) tuples

        Raises:
            FilesystemError: If not enough free sectors
        """
        free_sectors = []

        # Skip track 17 (VTOC track) and tracks used for catalog
        total_tracks = (
            35 if isinstance(self.vtoc, DOSVTOC) else 35
        )  # DOS 3.2 also has 35 tracks
        sectors_per_track = self.vtoc.sectors_per_track

        for track in range(total_tracks):
            # Skip track 0 (boot sectors) and track 17 (VTOC/catalog track)
            if track == 0 or track == self.vtoc.catalog_track:
                continue

            # Get free sector bitmap for this track
            if (
                hasattr(self.vtoc, "_track_sector_maps")
                and self.vtoc._track_sector_maps
            ):
                track_bitmap = self.vtoc._track_sector_maps.get(track, 0)
            else:
                # Read VTOC to get track bitmap
                vtoc_data = self.image.read_sector(
                    17, 0
                )  # VTOC is always at track 17, sector 0
                track_bitmap = struct.unpack_from("<I", vtoc_data, 56 + track * 4)[
                    0
                ]  # Track allocation map

            # Check each sector in the track
            for sector in range(sectors_per_track):
                if track_bitmap & (1 << sector):  # Bit set = free
                    free_sectors.append((track, sector))
                    if len(free_sectors) >= count:
                        return free_sectors[:count]

        raise FilesystemError(
            f"Not enough free sectors: need {count}, found {len(free_sectors)}",
            str(self.image.file_path),
        )

    def allocate_sectors(self, sector_list: list[tuple[int, int]]) -> None:
        """Mark sectors as allocated in the VTOC."""
        # Read current VTOC
        vtoc_data = bytearray(self.image.read_sector(17, 0))

        # Update track allocation maps
        for track, sector in sector_list:
            # Each track has a 4-byte entry in the allocation table
            # starting at offset 56
            track_offset = 56 + track * 4

            # Read current bitmap for this track (4 bytes per track)
            track_bitmap = struct.unpack_from("<I", vtoc_data, track_offset)[0]

            # Clear the bit for this sector (0 = allocated, 1 = free)
            track_bitmap &= ~(1 << sector)

            # Write back the updated bitmap
            struct.pack_into("<I", vtoc_data, track_offset, track_bitmap)

        # Write updated VTOC
        self.image.write_sector(17, 0, bytes(vtoc_data))

    def deallocate_sectors(self, sector_list: list[tuple[int, int]]) -> None:
        """Mark sectors as free in the VTOC."""
        # Read current VTOC
        vtoc_data = bytearray(self.image.read_sector(17, 0))

        # Update track allocation maps
        for track, sector in sector_list:
            track_offset = 56 + track * 4

            # Read current bitmap for this track (4 bytes per track)
            track_bitmap = struct.unpack_from("<I", vtoc_data, track_offset)[0]

            # Set the bit for this sector (1 = free, 0 = allocated)
            track_bitmap |= 1 << sector

            # Write back the updated bitmap
            struct.pack_into("<I", vtoc_data, track_offset, track_bitmap)

        # Write updated VTOC
        self.image.write_sector(17, 0, bytes(vtoc_data))
