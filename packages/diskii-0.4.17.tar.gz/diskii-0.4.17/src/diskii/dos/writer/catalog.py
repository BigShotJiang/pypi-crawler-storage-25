"""DOS catalog and track/sector list helper functions."""

import struct
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...image import UnifiedDiskImage

from ...exceptions import (
    FileNotFoundError,
    FilesystemError,
)
from ...fileentry import DOSFileEntry
from ..dos32 import DOS32VTOC
from ..dos33 import DOSVTOC
from .allocator import _invalidate_image_cache  # noqa: F401


def _create_chained_track_sector_lists(
    image: "UnifiedDiskImage",
    ts_sectors: list[tuple[int, int]],
    data_sectors: list[tuple[int, int]],
) -> None:
    """Create chained track/sector lists for large files."""
    sectors_per_ts_list = 122  # Maximum data sectors per T/S list

    for ts_index, (ts_track, ts_sector) in enumerate(ts_sectors):
        # Calculate which data sectors this T/S list handles
        start_sector = ts_index * sectors_per_ts_list
        end_sector = min(start_sector + sectors_per_ts_list, len(data_sectors))
        current_data_sectors = data_sectors[start_sector:end_sector]

        # Create T/S list data
        ts_data = bytearray(256)

        # Set next T/S list pointer
        if ts_index + 1 < len(ts_sectors):
            # Not the last T/S list
            next_ts_track, next_ts_sector = ts_sectors[ts_index + 1]
            ts_data[1] = next_ts_track
            ts_data[2] = next_ts_sector
        else:
            # Last T/S list
            ts_data[1] = 0
            ts_data[2] = 0

        # Set sector offset within file (not used by most DOS implementations)
        ts_data[5] = start_sector & 0xFF
        ts_data[6] = (start_sector >> 8) & 0xFF

        # Write track/sector pairs starting at offset 12
        for i, (track, sector) in enumerate(current_data_sectors):
            offset = 12 + (i * 2)
            if offset < 254:  # Ensure we don't overflow
                ts_data[offset] = track
                ts_data[offset + 1] = sector

        # Write the T/S list sector
        image.write_sector(ts_track, ts_sector, bytes(ts_data))


def _create_track_sector_list(
    data_sectors: list[tuple[int, int]], sector_count: int
) -> bytes:
    """Create a DOS track/sector list sector."""
    ts_data = bytearray(256)

    # Standard DOS 3.3 T/S list format:
    # Byte 0: not used (or next T/S track)
    # Byte 1: track of next T/S list (0 if last)
    # Byte 2: sector of next T/S list (0 if last)
    # Bytes 5-6: sector offset within file
    # Bytes 12+: track/sector pairs

    ts_data[1] = 0  # No next T/S list track
    ts_data[2] = 0  # No next T/S list sector

    # Track/sector pairs start at offset 12
    for i, (track, sector) in enumerate(data_sectors[:122]):  # Max 122 entries
        offset = 12 + (i * 2)
        if offset < 254:  # Make sure we don't overflow
            ts_data[offset] = track
            ts_data[offset + 1] = sector

    return bytes(ts_data)


def _add_catalog_entry(
    image: "UnifiedDiskImage",
    filename: str,
    file_type: str,
    ts_track: int,
    ts_sector: int,
    file_size: int,
    locked: bool,
    vtoc_class: type[DOSVTOC] | type[DOS32VTOC],
) -> None:
    """Add a catalog entry for a new DOS file."""

    # Get catalog location from VTOC
    vtoc = vtoc_class(image)
    catalog_track = vtoc.catalog_track
    catalog_sector = vtoc.catalog_sector

    # Search through catalog sectors for an empty slot
    while True:
        try:
            catalog_data = bytearray(image.read_sector(catalog_track, catalog_sector))
        except Exception as e:
            raise FilesystemError(
                "Cannot read catalog sector", str(image.file_path)
            ) from e

        # Check for empty catalog entry (track = 0xFF or track = 0x00)
        for i in range(7):  # 7 entries per catalog sector
            offset = 0x0B + i * 35  # File entries start at 0x0B, each entry is 35 bytes

            if offset + 35 > len(catalog_data):
                break

            entry_track = catalog_data[offset]

            # Check if entry is truly empty (track=0 AND sector=0) or deleted
            # (track=0xFF)
            entry_sector = (
                catalog_data[offset + 1] if offset + 1 < len(catalog_data) else 0
            )
            is_empty = (
                entry_track == 0x00 and entry_sector == 0x00
            ) or entry_track == 0xFF

            if is_empty:
                # Found empty entry
                _write_catalog_entry(
                    catalog_data,
                    offset,
                    filename,
                    file_type,
                    ts_track,
                    ts_sector,
                    file_size,
                    locked,
                )

                # Write updated catalog sector
                image.write_sector(catalog_track, catalog_sector, bytes(catalog_data))
                return

        # Check next catalog sector
        next_track = catalog_data[1]
        next_sector = catalog_data[2]

        if next_track == 0:
            # Allocate new catalog sector
            new_track, new_sector = _allocate_new_catalog_sector(image, vtoc)

            # Update current catalog sector to point to new one
            catalog_data[1] = new_track
            catalog_data[2] = new_sector
            image.write_sector(catalog_track, catalog_sector, bytes(catalog_data))

            # Initialize new catalog sector
            new_catalog_data = _create_empty_catalog_sector()
            image.write_sector(new_track, new_sector, new_catalog_data)

            # Continue with new catalog sector
            catalog_track = new_track
            catalog_sector = new_sector
            continue  # Loop back to check for empty slots in new sector

        catalog_track = next_track
        catalog_sector = next_sector


def _write_catalog_entry(
    catalog_data: bytearray,
    offset: int,
    filename: str,
    file_type: str,
    ts_track: int,
    ts_sector: int,
    file_size: int,
    locked: bool,
) -> None:
    """Write a DOS catalog entry at the specified offset."""

    # Byte 0: Track of first track/sector list
    catalog_data[offset] = ts_track

    # Byte 1: Sector of first track/sector list
    catalog_data[offset + 1] = ts_sector

    # Byte 2: File type and flags
    type_byte = 0x80  # Normal file
    if locked:
        type_byte |= 0x40

    type_mapping = {"T": 0x00, "I": 0x01, "A": 0x02, "B": 0x04, "S": 0x08, "R": 0x10}
    type_byte |= type_mapping.get(file_type, 0x00)

    catalog_data[offset + 2] = type_byte

    # Bytes 3-32: Filename (30 bytes, high ASCII, padded with spaces)
    name_bytes = filename.upper().encode("ascii")[:30]
    # Convert to high ASCII
    name_bytes = bytes(b | 0x80 for b in name_bytes)
    name_bytes = name_bytes.ljust(30, b"\xa0")  # Pad with high ASCII space

    catalog_data[offset + 3 : offset + 33] = name_bytes

    # Bytes 33-34: File size in sectors (little endian)
    sector_count = (file_size + 255) // 256
    struct.pack_into("<H", catalog_data, offset + 33, sector_count)


def _remove_catalog_entry(
    image: "UnifiedDiskImage",
    filename: str,
    vtoc_class: type[DOSVTOC] | type[DOS32VTOC],
) -> None:
    """Remove a DOS catalog entry by marking it as deleted."""

    # Get catalog location from VTOC
    vtoc = vtoc_class(image)
    catalog_track = vtoc.catalog_track
    catalog_sector = vtoc.catalog_sector

    # Search through catalog sectors
    while True:
        try:
            catalog_data = bytearray(image.read_sector(catalog_track, catalog_sector))
        except Exception as e:
            raise FileNotFoundError(filename, str(image.file_path)) from e

        # Check each catalog entry
        for i in range(7):  # 7 entries per sector
            offset = 0x0B + i * 35  # File entries start at 0x0B

            if offset + 35 > len(catalog_data):
                break

            entry_track = catalog_data[offset]

            # Check if entry is a valid file (not empty: track=0 AND sector=0,
            # not deleted: track=0xFF)
            entry_sector = (
                catalog_data[offset + 1] if offset + 1 < len(catalog_data) else 0
            )
            is_valid_file = not (
                (entry_track == 0x00 and entry_sector == 0x00) or entry_track == 0xFF
            )

            if is_valid_file:
                # Read filename from entry
                name_bytes = catalog_data[offset + 3 : offset + 33]
                # Convert from high ASCII and strip padding
                entry_filename = (
                    bytes(b & 0x7F for b in name_bytes).decode("ascii").rstrip(" ")
                )

                if entry_filename.upper() == filename.upper():
                    # Found the entry, mark as deleted
                    catalog_data[offset] = 0xFF  # Mark as deleted

                    # Write updated catalog sector
                    image.write_sector(
                        catalog_track, catalog_sector, bytes(catalog_data)
                    )
                    return

        # Check next catalog sector
        next_track = catalog_data[1]
        next_sector = catalog_data[2]

        if next_track == 0:
            break

        catalog_track = next_track
        catalog_sector = next_sector

    # File not found in any catalog sector
    raise FileNotFoundError(filename, str(image.file_path))


def _create_empty_catalog_sector() -> bytes:
    """Create properly formatted empty catalog sector per DOS 3.3 spec."""
    catalog = bytearray(256)

    # Byte 0: Reserved (0x00)
    catalog[0] = 0x00

    # Bytes 1-2: Next catalog track/sector (0x00 = end of chain)
    catalog[1] = 0x00
    catalog[2] = 0x00

    # Bytes 3-10: Reserved (0x00)
    for i in range(3, 11):
        catalog[i] = 0x00

    # Bytes 11+: Initialize file entries as unused (track=0)
    for i in range(7):  # 7 file entries per catalog sector
        entry_offset = 11 + (i * 35)
        catalog[entry_offset] = 0x00  # Track=0 means unused

    return bytes(catalog)


def _allocate_new_catalog_sector(
    image: "UnifiedDiskImage", vtoc: DOSVTOC | DOS32VTOC
) -> tuple[int, int]:
    """Find and allocate a free sector for catalog expansion."""
    # First try to find a free sector on the catalog track (Track 17)
    catalog_track = vtoc.catalog_track

    for sector in range(vtoc.sectors_per_track):
        if vtoc.is_sector_free(catalog_track, sector):
            # Found free sector on catalog track
            _mark_catalog_sector_allocated(image, vtoc, catalog_track, sector)
            return catalog_track, sector

    # If catalog track is full, find any free sector
    free_sectors = vtoc.get_free_sector_list()
    if not free_sectors:
        raise FilesystemError(
            "Disk is full - no sectors available for catalog expansion",
            str(image.file_path),
        )

    # Use the first available free sector
    track, sector = free_sectors[0]
    _mark_catalog_sector_allocated(image, vtoc, track, sector)
    return track, sector


def _mark_catalog_sector_allocated(
    image: "UnifiedDiskImage",
    vtoc: DOSVTOC | DOS32VTOC,
    track: int,
    sector: int,
) -> None:
    """Mark catalog sector as allocated in VTOC bitmap."""
    # Read current VTOC
    vtoc_data = bytearray(image.read_sector(17, 0))

    # Calculate bitmap offset for this track
    bitmap_offset = 56 + (track * 4)

    if bitmap_offset + 4 <= len(vtoc_data):
        # Read current 4-byte bitmap for this track
        current_bitmap = struct.unpack(
            "<I", vtoc_data[bitmap_offset : bitmap_offset + 4]
        )[0]

        # Clear the bit for this sector (mark as allocated)
        updated_bitmap = current_bitmap & ~(1 << sector)

        # Write updated bitmap back
        struct.pack_into("<I", vtoc_data, bitmap_offset, updated_bitmap)

        # Write updated VTOC back to disk
        image.write_sector(17, 0, bytes(vtoc_data))


def _update_catalog_entry(
    image: "UnifiedDiskImage",
    file_entry: DOSFileEntry,
    vtoc_class: type[DOSVTOC] | type[DOS32VTOC],
) -> None:
    """Update a catalog entry on disk.

    Args:
        image: DOS disk image
        file_entry: File entry to update
        vtoc_class: VTOC class (DOSVTOC or DOS32VTOC)
    """
    vtoc = vtoc_class(image)
    current_track = vtoc.catalog_track
    current_sector = vtoc.catalog_sector

    while current_track != 0:
        # Read catalog sector
        catalog_data = bytearray(image.read_sector(current_track, current_sector))

        # Parse entries in this sector
        for i in range(7):  # 7 entries per sector
            entry_offset = 11 + (i * 35)  # Skip 11-byte header
            if entry_offset + 35 > len(catalog_data):
                break

            entry_data = catalog_data[entry_offset : entry_offset + 35]

            # Check if this is our target file
            # Compare track/sector and filename
            ts_track = entry_data[0]
            ts_sector = entry_data[1]

            if ts_track == file_entry.track and ts_sector == file_entry.sector:
                # Found our file - update the catalog entry
                new_entry = file_entry.get_catalog_entry_bytes()
                catalog_data[entry_offset : entry_offset + 35] = new_entry

                # Write the updated catalog sector back
                image.write_sector(current_track, current_sector, bytes(catalog_data))
                return

        # Move to next catalog sector
        next_track = catalog_data[1] if len(catalog_data) > 1 else 0
        next_sector = catalog_data[2] if len(catalog_data) > 2 else 0

        if next_track == 0:
            break

        current_track = next_track
        current_sector = next_sector

    raise FilesystemError(
        f"Could not find catalog entry for file '{file_entry.filename}'"
    )
