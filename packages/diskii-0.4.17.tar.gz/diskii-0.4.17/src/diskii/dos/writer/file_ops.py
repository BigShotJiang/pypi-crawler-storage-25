"""DOS file operations: create, delete, rename, set attributes."""

import struct
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ...image import UnifiedDiskImage

from ...exceptions import (
    FileNotFoundError,
    FilesystemError,
    InvalidFileError,
)
from ..dos32 import DOS32VTOC, DOS32Catalog
from ..dos33 import DOSVTOC, DOSCatalog
from .allocator import DOSTrackSectorAllocator, _invalidate_image_cache
from .catalog import (
    _add_catalog_entry,
    _create_chained_track_sector_lists,
    _remove_catalog_entry,
    _update_catalog_entry,
)


def create_dos_file(
    image: "UnifiedDiskImage",
    filename: str,
    file_type: str,
    data: bytes,
    locked: bool = False,
) -> None:
    """Create a new file on a DOS disk image.

    Args:
        image: UnifiedDiskImage instance
        filename: Name of the file to create (up to 30 chars)
        file_type: DOS file type ('T', 'I', 'A', 'B', 'S', 'R')
        data: File content bytes
        locked: Whether the file should be locked

    Raises:
        InvalidFileError: If filename already exists or is invalid
        FilesystemError: If not enough free space
    """
    # Validate filename
    if not filename or len(filename) > 30:
        raise InvalidFileError(f"Invalid filename: {filename}")

    if file_type not in ["T", "I", "A", "B", "S", "R"]:
        raise InvalidFileError(f"Invalid DOS file type: {file_type}")

    # Check if file already exists
    existing_files = image.get_file_list()
    for existing_file in existing_files:
        if existing_file.filename.upper() == filename.upper():
            raise InvalidFileError(f"File already exists: {filename}")

    # Determine VTOC class and catalog class based on image type
    from ...types import FilesystemType

    vtoc_class = (
        DOS32VTOC
        if hasattr(image, "SECTORS_PER_TRACK") and image.SECTORS_PER_TRACK == 13
        else DOSVTOC
    )

    # Check catalog capacity
    if hasattr(image, "format") and image.format.filesystem == FilesystemType.DOS33:
        catalog: DOSCatalog | DOS32Catalog = DOSCatalog(image)
    elif hasattr(image, "format") and image.format.filesystem == FilesystemType.DOS32:
        catalog = DOS32Catalog(image)
    else:
        # Fall back to DOS33 catalog for images without format info
        catalog = DOSCatalog(image)

    if catalog.is_catalog_full():
        raise FilesystemError(
            "Catalog is full - cannot add more files (maximum 105 files)"
        )

    # For binary files, prepend exact file size to preserve cross-format integrity
    actual_data = data
    if file_type == "B":
        # Check if this looks like it already has a DOS binary header
        has_dos_header = False
        if len(data) >= 4:
            start_addr = struct.unpack("<H", data[0:2])[0]
            file_length = struct.unpack("<H", data[2:4])[0]

            # Validate DOS binary header format
            # Standard DOS binary: load_addr(2) + length(2) + data
            # Both address and length must be reasonable
            actual_data_size = len(data) - 4

            if (
                0x0800 <= start_addr <= 0xBFFF  # Valid Apple II address range
                and 0 < file_length <= actual_data_size  # Length must fit
                and file_length < 32768  # Reasonable maximum size
                # Additional validation: ensure this looks like a real header
                and file_length != start_addr  # Avoid false positives like 'XXXX'
                and file_length <= 16384  # More conservative size limit for headers
            ):
                has_dos_header = True

        if not has_dos_header:
            # Add our own size metadata for cross-format integrity
            # Format: 2 bytes = original file length (little-endian 16-bit)
            # to match what _calculate_dos_file_size expects
            file_length = min(len(data), 65535)  # Cap at 16-bit max
            size_header = struct.pack("<H", file_length)
            actual_data = size_header + data

    # Calculate sectors needed based on actual data (including any headers)
    sector_size = 256  # Bytes per sector
    sectors_needed = (len(actual_data) + sector_size - 1) // sector_size

    # Empty files don't need data sectors, only track/sector list
    # This matches CiderPress behavior where empty files have zero length

    # Add one extra sector for track/sector list if file is large
    ts_sectors_needed = 1
    if sectors_needed > 122:  # 122 entries fit in one T/S list sector
        ts_sectors_needed = (sectors_needed + 121) // 122  # Additional T/S list sectors

    total_sectors_needed = sectors_needed + ts_sectors_needed

    # Allocate sectors
    allocator = DOSTrackSectorAllocator(image, vtoc_class)
    allocated_sectors = allocator.find_free_sectors(total_sectors_needed)

    try:
        # First allocated sector is the track/sector list
        ts_track, ts_sector = allocated_sectors[0]
        data_sectors = allocated_sectors[1:]

        # Create track/sector lists (may be chained for large files)
        ts_sectors = allocated_sectors[:ts_sectors_needed]  # T/S list sectors
        data_sectors = allocated_sectors[ts_sectors_needed:]  # Data sectors

        _create_chained_track_sector_lists(image, ts_sectors, data_sectors)

        # Write data sectors
        for i, (track, sector) in enumerate(data_sectors):
            start_offset = i * 256
            end_offset = min(start_offset + 256, len(actual_data))

            if start_offset < len(actual_data):
                sector_data = actual_data[start_offset:end_offset]
                # Pad sector to 256 bytes
                sector_data = sector_data.ljust(256, b"\x00")
                image.write_sector(track, sector, sector_data)
            else:
                # Empty sector for padding
                image.write_sector(track, sector, b"\x00" * 256)

        # Mark sectors as allocated
        allocator.allocate_sectors(allocated_sectors)

        # Add catalog entry with original data length (not including headers)
        _add_catalog_entry(
            image,
            filename,
            file_type,
            ts_track,
            ts_sector,
            len(
                data
            ),  # Use original data length, not actual_data which may include headers
            locked,
            vtoc_class,
        )

    except Exception as e:
        # If anything fails, deallocate sectors that were allocated
        try:
            allocator.deallocate_sectors(allocated_sectors)
        except Exception:
            pass  # Best effort cleanup
        raise FilesystemError(f"Failed to create file {filename}: {e}") from e

    # Invalidate file list cache after successful creation
    _invalidate_image_cache(image)


def delete_dos_file(image: "UnifiedDiskImage", filename: str) -> None:
    """Delete a file from a DOS disk image.

    Args:
        image: UnifiedDiskImage instance
        filename: Name of the file to delete

    Raises:
        FileNotFoundError: If file doesn't exist
    """
    # Determine VTOC and catalog classes
    vtoc_class = (
        DOS32VTOC
        if hasattr(image, "SECTORS_PER_TRACK") and image.SECTORS_PER_TRACK == 13
        else DOSVTOC
    )
    catalog_class = DOS32Catalog if vtoc_class == DOS32VTOC else DOSCatalog

    # Find the file in catalog
    catalog = catalog_class(image)
    files = catalog.parse()

    target_file = None
    for file_entry in files:
        # Compare both display filename and cleaned filename
        display_name = file_entry.filename.strip().upper()
        clean_name = display_name.replace("[", "").replace("]", "")
        target_name = filename.strip().upper()

        if display_name == target_name or clean_name == target_name:
            target_file = file_entry
            break

    if target_file is None:
        raise FileNotFoundError(filename, str(image.file_path))

    # Collect sectors to deallocate
    sectors_to_free = []

    # Add track/sector list sector
    sectors_to_free.append((target_file.track, target_file.sector))

    # Read track/sector list to get data sector locations
    ts_data = image.read_sector(target_file.track, target_file.sector)

    # Parse track/sector list to find data sectors (starts at offset 12)
    for i in range(12, 256, 2):
        if i + 1 >= len(ts_data):
            break

        data_track = ts_data[i]
        data_sector = ts_data[i + 1]

        if data_track == 0:  # End of valid entries
            break

        sectors_to_free.append((data_track, data_sector))

    # Deallocate sectors
    allocator = DOSTrackSectorAllocator(image, vtoc_class)
    allocator.deallocate_sectors(sectors_to_free)

    # Remove catalog entry
    _remove_catalog_entry(image, filename, vtoc_class)

    # Invalidate file list cache after successful deletion
    _invalidate_image_cache(image)


def rename_dos_file(
    image: "UnifiedDiskImage", old_filename: str, new_filename: str
) -> None:
    """Rename a DOS file.

    Args:
        image: DOS disk image
        old_filename: Current name of file
        new_filename: New name for file

    Raises:
        FileNotFoundError: If file doesn't exist
        InvalidFileError: If new filename is invalid or already exists
        FilesystemError: If unable to update catalog
    """
    from ...types import FilesystemType
    from ..filename import validate_dos_filename

    # Validate new filename
    if not validate_dos_filename(new_filename):
        raise InvalidFileError(f"Invalid DOS filename: {new_filename}")

    # Check if new filename already exists
    existing_files = image.get_file_list()
    for existing_file in existing_files:
        clean_existing = (
            existing_file.filename.strip().replace("[", "").replace("]", "")
        )
        if clean_existing.upper() == new_filename.strip().upper():
            raise InvalidFileError(f"File already exists: {new_filename}")

    # Determine DOS version and get appropriate catalog
    if hasattr(image, "format") and image.format.filesystem == FilesystemType.DOS33:
        catalog: DOSCatalog | DOS32Catalog = DOSCatalog(image)
        vtoc_class: type[DOSVTOC] | type[DOS32VTOC] = DOSVTOC
    elif hasattr(image, "format") and image.format.filesystem == FilesystemType.DOS32:
        catalog = DOS32Catalog(image)
        vtoc_class = DOS32VTOC
    else:
        # Fall back to DOS33
        catalog = DOSCatalog(image)
        vtoc_class = DOSVTOC

    # Find the file
    files = catalog.parse()
    target_file = None

    for file_entry in files:
        # Compare both display filename and cleaned filename
        display_name = file_entry.filename.strip().upper()
        clean_name = display_name.replace("[", "").replace("]", "")
        target_name = old_filename.strip().upper()

        if display_name == target_name or clean_name == target_name:
            target_file = file_entry
            break

    if target_file is None:
        raise FileNotFoundError(old_filename)

    # Update the filename
    target_file.set_filename(new_filename)

    # Update the catalog entry on disk
    _update_catalog_entry(image, target_file, vtoc_class)

    # Invalidate file list cache after successful rename
    _invalidate_image_cache(image)


def set_dos_file_attributes(
    image: "UnifiedDiskImage", filename: str, *, locked: bool | None = None
) -> None:
    """Set DOS file attributes.

    Args:
        image: DOS disk image
        filename: Name of file to modify
        locked: True to lock file, False to unlock, None to leave unchanged

    Raises:
        FileNotFoundError: If file doesn't exist
        FilesystemError: If unable to update catalog
    """
    from ...types import FilesystemType

    # Determine DOS version and get appropriate catalog
    if image.format.filesystem == FilesystemType.DOS33:
        catalog: DOSCatalog | DOS32Catalog = DOSCatalog(image)
        vtoc_class: type[DOSVTOC] | type[DOS32VTOC] = DOSVTOC
    elif image.format.filesystem == FilesystemType.DOS32:
        catalog = DOS32Catalog(image)
        vtoc_class = DOS32VTOC
    else:
        raise FilesystemError("Image is not a DOS disk")

    # Find the file
    files = catalog.parse()
    target_file = None

    for file_entry in files:
        # Compare both display filename and padded filename
        display_name = file_entry.filename.strip().upper()
        # Also try removing the DOS filename decorations like [X]
        clean_name = display_name.replace("[", "").replace("]", "")
        target_name = filename.strip().upper()

        if display_name == target_name or clean_name == target_name:
            target_file = file_entry
            break

    if target_file is None:
        raise FileNotFoundError(filename)

    # Update attributes
    if locked is not None:
        target_file.set_locked(locked)

    # Find and update the catalog entry
    _update_catalog_entry(image, target_file, vtoc_class)

    # Invalidate file list cache after successful attribute update
    _invalidate_image_cache(image)
