#!/usr/bin/env python3
"""
Quick examples: spinless Haldane (one spin sector / 2x2), then Kane–Mele
(4x4, spinful + TRS) for nearest-neighbor hopping ``t`` and ``-t``.

From the package root (with the package installed, e.g. ``uv pip install -e .``):

    python examples/quick_start.py
"""

from __future__ import annotations

import numpy as np

from c2_invariants import C2Model, make_invariant, standard_trs_unitary_spin_pairs

# --- Spinless Haldane (same square BZ / NNN-on-a1 structure as tests) ----------

C2_OP_SPINLESS = np.array([[0, 1], [1, 0]], dtype=float)


def haldane_bloch(kx: float, ky: float) -> np.ndarray:
    """Simplified Haldane model (2x2), 2pi-periodic in kx, ky."""
    t, t_2, M = -1.0, 0.3, 0.0
    a1 = np.array([1.0, 0.0])
    a2 = np.array([0.0, 1.0])
    k = np.array([kx, ky])
    f_k = t * (1 + np.exp(-1j * k @ a1) + np.exp(-1j * k @ a2))
    g_k = 2 * t_2 * np.sin(k @ a1)
    return np.array(
        [
            [M + g_k, f_k],
            [np.conj(f_k), -M - g_k],
        ],
        dtype=complex,
    )


# --- Kane–Mele (minimal 4x4; band order A↑, A↓, B↑, B↓) -------------------------
#
# With band order A↑, A↓, B↑, B↓ the outer (slow) index labels sublattice
# and the inner (fast) index labels spin. Pauli matrices are named by the
# space they act on: ``S_*`` on spin, ``TAU_*`` on sublattice.

S_Z = np.array([[1, 0], [0, -1]], dtype=float)
S_0 = np.eye(2)
TAU_X = np.array([[0, 1], [1, 0]], dtype=complex)


def kane_mele_bloch(
    kx: float, ky: float, t: float, lambda_so: float = 0.1, m: float = 0.0
) -> np.ndarray:
    """Simplified Kane–Mele model (4x4), same embedding as tests."""
    a1 = np.array([1.0, 0.0])
    a2 = np.array([0.0, 1.0])
    k = np.array([kx, ky])
    f_k = t * (1 + np.exp(-1j * k @ a1) + np.exp(-1j * k @ a2))
    g_k = 2 * lambda_so * np.sin(k @ a1)
    h = np.zeros((4, 4), dtype=complex)
    h[0:2, 0:2] = m * S_0 + g_k * S_Z
    h[2:4, 2:4] = -m * S_0 - g_k * S_Z
    h[0:2, 2:4] = f_k * S_0
    h[2:4, 0:2] = np.conj(f_k) * S_0
    return h


def spinful_c2() -> np.ndarray:
    """C2 = i tau_x^sub ⊗ s_z^spin (4x4), basis A↑, A↓, B↑, B↓."""
    return 1j * np.kron(TAU_X, S_Z)


# --- Atomic-limit (single intra-unit-cell hopping) --------------------------
#
# Zero all inter-cell hoppings and all further-neighbor terms. The Bloch
# Hamiltonian becomes k-independent (flat bands) and the real-space invariants
# can be read off analytically.

def haldane_atomic(kx: float, ky: float, t: float = 1.0) -> np.ndarray:
    """Spinless Haldane with only the intra-cell A<->B hopping: H(k) = t sigma_x."""
    return np.array([[0.0, t], [t, 0.0]], dtype=complex)


def kane_mele_atomic(kx: float, ky: float, t: float = 1.0) -> np.ndarray:
    """Kane-Mele with only the intra-cell A<->B hopping (no SO): H(k) = t (tau_x x s_0)."""
    h = np.zeros((4, 4), dtype=complex)
    h[0:2, 2:4] = t * S_0
    h[2:4, 0:2] = t * S_0
    return h


def main() -> None:
    print("--- Spinless Haldane (2x2, one spin sector) ---")
    model_h = C2Model(
        h_func=haldane_bloch,
        n_occ=1,
        c2_op=C2_OP_SPINLESS,
    )
    inv_h = make_invariant(model_h)
    print("nu(1d):", inv_h.nu("1d"))
    print("c2_counts:", inv_h.c2_counts)

    trs_u = standard_trs_unitary_spin_pairs(4)
    c2_km = spinful_c2()

    for t_val, label in ((1.0, "t > 0"), (-1.0, "t < 0")):
        print(f"\n--- Kane–Mele (4x4, spinful + TRS), {label} ---")
        model_km = C2Model(
            h_func=lambda kx, ky, _t=t_val: kane_mele_bloch(kx, ky, t=_t),
            n_occ=2,
            c2_op=c2_km,
            spinful=True,
            trs=True,
            trs_unitary=trs_u,
        )
        inv_km = make_invariant(model_km)
        print("nu(1d):", inv_km.nu("1d"))

    # --- Atomic-limit cases: only intra-unit-cell hopping --------------------

    print("\n=== Atomic limit: only the single intra-unit-cell hopping ===")

    for t_val in (1.0, -1.0):
        print(f"\n--- Spinless Haldane atomic limit, t = {t_val:+g} ---")
        model_h_atomic = C2Model(
            h_func=lambda kx, ky, _t=t_val: haldane_atomic(kx, ky, t=_t),
            n_occ=1,
            c2_op=C2_OP_SPINLESS,
        )
        inv_h_atomic = make_invariant(model_h_atomic)
        for w in ("1a", "1b", "1c", "1d"):
            print(f"  nu({w}) = {inv_h_atomic.nu(w):+.6f}")
        print(f"  expected: nu(1a) = {-t_val:+g}, nu(1b,1c,1d) = 0")

    for t_val in (1.0, -1.0):
        print(f"\n--- Kane–Mele atomic limit, t = {t_val:+g} ---")
        model_km_atomic = C2Model(
            h_func=lambda kx, ky, _t=t_val: kane_mele_atomic(kx, ky, t=_t),
            n_occ=2,
            c2_op=c2_km,
            spinful=True,
            trs=True,
            trs_unitary=trs_u,
        )
        inv_km_atomic = make_invariant(model_km_atomic)
        for w in ("1a", "1b", "1c", "1d"):
            print(f"  nu({w}) = {inv_km_atomic.nu(w):+.6f}")
        print(f"  C_I_bnd = {inv_km_atomic.partial_chern_boundary:+.6e}")
        print(f"  nu_Z2   = {inv_km_atomic.z2_winding}")
        print(f"  C_I     = {inv_km_atomic.partial_chern:+.6e}")
        print("  expected: nu(1a) = 1 (mod 2), nu(1b,1c,1d) = 0 (mod 2), C_I = 0")


if __name__ == "__main__":
    main()
