"""
Tests for the c2-invariants package.

Tests:
  1. Character table verification
  2. Closed-form formulas vs direct Hadamard inversion (spinless)
  3. Sum rule: nu_a + nu_b + nu_c + nu_d = Gamma_- - Gamma_+
  4. Atomic-limit models with known Wannier positions
  5. Half-integer invariants for Chern insulators (Ch=+/-1)
  6. Spinful invariants (Kane-Mele, no TRS decomposition)
"""

import numpy as np
import pytest

from c2_invariants import (
    C2Model,
    SpinlessInvariant,
    SpinfulInvariant,
    make_invariant,
    standard_trs_unitary_spin_pairs,
)
from c2_invariants.chern import ChernCalculator
from c2_invariants.invariants import c2_eigenvalue_counts


# ===================================================================
# Minimal Bloch Hamiltonians (self-contained, no kwant dependency)
# ===================================================================

SX = np.array([[0, 1], [1, 0]])
SZ = np.array([[1, 0], [0, -1]])
S0 = np.eye(2)
TAU_Z = np.array([[1, 0], [0, -1]], dtype=complex)


def haldane_bloch(kx, ky, t=1.0, t_2=0.3, M=0.0):
    """Simplified Haldane model (NNN along a1 only), 2x2."""
    a1 = np.array([1.0, 0.0])
    a2 = np.array([0.0, 1.0])
    k = np.array([kx, ky])
    f_k = t * (1 + np.exp(-1j * k @ a1) + np.exp(-1j * k @ a2))
    g_k = 2 * t_2 * np.sin(k @ a1)
    return np.array([
        [M + g_k, f_k],
        [np.conj(f_k), -M - g_k],
    ])


def kane_mele_bloch(kx, ky, t=1.0, lambda_SO=0.1, M=0.0):
    """Simplified Kane-Mele model, 4x4."""
    a1 = np.array([1.0, 0.0])
    a2 = np.array([0.0, 1.0])
    k = np.array([kx, ky])
    f_k = t * (1 + np.exp(-1j * k @ a1) + np.exp(-1j * k @ a2))
    g_k = 2 * lambda_SO * np.sin(k @ a1)
    H = np.zeros((4, 4), dtype=complex)
    H[0:2, 0:2] = (M + g_k) * SZ
    H[2:4, 2:4] = (-M - g_k) * SZ
    H[0:2, 2:4] = f_k * S0
    H[2:4, 0:2] = np.conj(f_k) * S0
    return H


def spinful_c2():
    """C2 = i sigma_x^spin x tau_z^sub for 4x4 Kane-Mele."""
    return 1j * np.kron(SX, TAU_Z)


def haldane_atomic(kx, ky, t=1.0):
    """Atomic limit of haldane_bloch: only intra-cell A->B hopping."""
    return np.array([[0.0, t], [t, 0.0]], dtype=complex)


def kane_mele_atomic(kx, ky, t=1.0):
    """Atomic limit of kane_mele_bloch: only intra-cell A->B hopping, no SO."""
    H = np.zeros((4, 4), dtype=complex)
    H[0:2, 2:4] = t * S0
    H[2:4, 0:2] = t * S0
    return H


HALDANE_C2 = np.array([[0, 1], [1, 0]])  # sigma_x


# ===================================================================
# Tests
# ===================================================================

class TestCharacterTable:
    def test_character_table(self):
        """Verify the character table: xi(k) = xi * exp(i k . 2w)."""
        positions = {
            "1a": np.array([0.0, 0.0]),
            "1b": np.array([0.5, 0.0]),
            "1c": np.array([0.0, 0.5]),
            "1d": np.array([0.5, 0.5]),
        }
        hsps = {
            "Gamma": np.array([0.0, 0.0]),
            "X": np.array([np.pi, 0.0]),
            "Y": np.array([0.0, np.pi]),
            "M": np.array([np.pi, np.pi]),
        }
        expected = {
            "1a": [+1, +1, +1, +1],
            "1b": [+1, -1, +1, -1],
            "1c": [+1, +1, -1, -1],
            "1d": [+1, -1, -1, +1],
        }
        for wname, w in positions.items():
            for (hname, k), exp_sign in zip(hsps.items(), expected[wname]):
                phase = np.exp(1j * np.dot(k, 2 * w))
                actual = int(np.round(np.real(phase)))
                assert actual == exp_sign, \
                    f"Mismatch at {wname}, {hname}: got {actual}, expected {exp_sign}"


class TestFormulaVsHadamard:
    """Closed-form formulas vs direct Hadamard inversion (spinless)."""

    @pytest.fixture(params=[
        ("t>0, Chern", lambda kx, ky: haldane_bloch(kx, ky, t=1.0, t_2=0.3, M=0.0)),
        ("t<0, Chern", lambda kx, ky: haldane_bloch(kx, ky, t=-1.0, t_2=0.3, M=0.0)),
        ("trivial M=5", lambda kx, ky: haldane_bloch(kx, ky, t=1.0, t_2=0.3, M=5.0)),
        ("trivial t2=0", lambda kx, ky: haldane_bloch(kx, ky, t=1.0, t_2=0.0, M=0.5)),
    ])
    def haldane_model(self, request):
        label, h_func = request.param
        return label, C2Model(h_func=h_func, n_occ=1, c2_op=HALDANE_C2)

    def test_formula_matches_hadamard(self, haldane_model):
        """The closed-form formulas negate the raw Hadamard inversion."""
        label, model = haldane_model
        inv = SpinlessInvariant(model)
        counts = inv.c2_counts

        dG = counts["Gamma"]["-"] - counts["Gamma"]["+"]
        dX = counts["X"]["-"] - counts["X"]["+"]
        dY = counts["Y"]["-"] - counts["Y"]["+"]
        dM = counts["M"]["-"] - counts["M"]["+"]

        # Raw Hadamard gives delta-based values; the closed-form formulas negate these
        hadamard = {
            "1a": 0.25 * (dG + dX + dY + dM),
            "1b": 0.25 * (dG - dX + dY - dM),
            "1c": 0.25 * (dG + dX - dY - dM),
            "1d": 0.25 * (dG - dX - dY + dM),
        }

        for w in ("1a", "1b", "1c", "1d"):
            assert np.isclose(inv.nu(w), -hadamard[w], atol=1e-10), \
                f"{label}: nu_{w} formula={inv.nu(w)}, -hadamard={-hadamard[w]}"


class TestSumRule:
    """nu_a + nu_b + nu_c + nu_d = Gamma_+ - Gamma_-."""

    @pytest.fixture(params=[
        lambda kx, ky: haldane_bloch(kx, ky, t=1.0, t_2=0.3, M=0.0),
        lambda kx, ky: haldane_bloch(kx, ky, t=-1.0, t_2=0.3, M=0.0),
        lambda kx, ky: haldane_bloch(kx, ky, t=1.0, t_2=0.3, M=5.0),
    ])
    def model(self, request):
        return C2Model(h_func=request.param, n_occ=1, c2_op=HALDANE_C2)

    def test_sum_rule(self, model):
        inv = SpinlessInvariant(model)
        counts = inv.c2_counts
        expected = counts["Gamma"]["+"] - counts["Gamma"]["-"]
        nu_sum = sum(inv.nu(w) for w in ("1a", "1b", "1c", "1d"))
        assert np.isclose(nu_sum, expected, atol=1e-10)


class TestAtomicLimit:
    """Atomic-limit models with known Wannier function positions."""

    def test_plus1_occupied(self):
        """Occupy +1 eigenvalue orbital at 1a => nu_1a = +1."""
        c2 = np.diag([1.0, -1.0])
        model = C2Model(
            h_func=lambda kx, ky: np.diag([-1.0, +1.0]),
            n_occ=1, c2_op=c2,
        )
        inv = SpinlessInvariant(model)
        assert np.isclose(inv.nu("1a"), +1, atol=1e-10)
        for w in ("1b", "1c", "1d"):
            assert np.isclose(inv.nu(w), 0, atol=1e-10)

    def test_minus1_occupied(self):
        """Occupy -1 eigenvalue orbital at 1a => nu_1a = -1."""
        c2 = np.diag([1.0, -1.0])
        model = C2Model(
            h_func=lambda kx, ky: np.diag([+1.0, -1.0]),
            n_occ=1, c2_op=c2,
        )
        inv = SpinlessInvariant(model)
        assert np.isclose(inv.nu("1a"), -1, atol=1e-10)
        for w in ("1b", "1c", "1d"):
            assert np.isclose(inv.nu(w), 0, atol=1e-10)

    def test_both_occupied(self):
        c2 = np.diag([1.0, -1.0])
        model = C2Model(
            h_func=lambda kx, ky: np.diag([-1.0, -0.5]),
            n_occ=2, c2_op=c2,
        )
        inv = SpinlessInvariant(model)
        for w in ("1a", "1b", "1c", "1d"):
            assert np.isclose(inv.nu(w), 0, atol=1e-10)

    def test_wf_at_1d(self):
        c2_z = np.diag([1.0, -1.0])
        model = C2Model(
            h_func=lambda kx, ky: np.diag(
                [-np.cos(kx) * np.cos(ky), np.cos(kx) * np.cos(ky)]
            ),
            n_occ=1, c2_op=c2_z,
        )
        inv = SpinlessInvariant(model)
        expected = {"1a": 0, "1b": 0, "1c": 0, "1d": +1}
        for w, exp in expected.items():
            assert np.isclose(inv.nu(w), exp, atol=1e-10)


class TestChernHalfInteger:
    """For Chern insulators with odd Ch, nu_{1x} should be half-integer."""

    @pytest.mark.parametrize("t_val", [1.0, -1.0])
    def test_half_integer(self, t_val):
        model = C2Model(
            h_func=lambda kx, ky, t=t_val: haldane_bloch(kx, ky, t=t, t_2=0.3, M=0.0),
            n_occ=1, c2_op=HALDANE_C2,
        )
        inv = SpinlessInvariant(model)
        for w in ("1a", "1b", "1c", "1d"):
            nu = inv.nu(w)
            assert np.isclose(nu * 2, round(nu * 2), atol=1e-6), \
                f"nu_{w}={nu} is not half-integer for t={t_val}"


class TestSpinful:
    """Spinful invariants (Kane-Mele) formula consistency."""

    @pytest.mark.parametrize("t_val", [1.0, -1.0])
    def test_formula_vs_hadamard_spinful(self, t_val):
        c2_op = spinful_c2()
        model = C2Model(
            h_func=lambda kx, ky, t=t_val: kane_mele_bloch(kx, ky, t=t, lambda_SO=0.3),
            n_occ=2, c2_op=c2_op, spinful=True,
        )
        inv = SpinfulInvariant(model)
        counts = inv.c2_counts
        chern = inv.chern_number

        dG = counts["Gamma"]["-"] - counts["Gamma"]["+"]
        dX = counts["X"]["-"] - counts["X"]["+"]
        dY = counts["Y"]["-"] - counts["Y"]["+"]
        dM = counts["M"]["-"] - counts["M"]["+"]

        # Negate the raw Hadamard, then add Chern correction
        nu_a_expected = -0.25 * (dG + dX + dY + dM) + 0.5 * chern
        nu_d_expected = -0.25 * (dG - dX - dY + dM) + 0.5 * chern

        assert np.isclose(inv.nu("1a"), nu_a_expected, atol=1e-10)
        assert np.isclose(inv.nu("1d"), nu_d_expected, atol=1e-10)


class TestAtomicLimitHaldane:
    """Spinless Haldane with only the intra-cell A->B hopping: H(k) = t sigma_x.

    Flat bands, zero Chern. At every HSP the occupied band has C2 eigenvalue
    -sign(t), so nu_1a = -sign(t) and nu_1b = nu_1c = nu_1d = 0.
    """

    @pytest.mark.parametrize("t_val", [1.0, -1.0])
    def test_atomic_limit(self, t_val):
        model = C2Model(
            h_func=lambda kx, ky, t=t_val: haldane_atomic(kx, ky, t=t),
            n_occ=1, c2_op=HALDANE_C2,
        )
        inv = SpinlessInvariant(model)
        expected_1a = -np.sign(t_val)
        assert np.isclose(inv.nu("1a"), expected_1a, atol=1e-10), \
            f"t={t_val}: nu_1a={inv.nu('1a')}, expected {expected_1a}"
        for w in ("1b", "1c", "1d"):
            assert np.isclose(inv.nu(w), 0.0, atol=1e-10), \
                f"t={t_val}: nu_{w}={inv.nu(w)}, expected 0"


class TestAtomicLimitKaneMele:
    """Kane-Mele with only the intra-cell A<->B hopping: H(k) = t (tau_x x s_0).

    Flat bands, zero partial Chern, zero Z2 winding. The sector-I Wyckoff
    invariants satisfy nu^I_1a = 1 (mod 2) and nu^I_{1b,c,d} = 0 (mod 2) for
    both signs of t.
    """

    @pytest.mark.parametrize("t_val", [1.0, -1.0])
    def test_atomic_limit(self, t_val):
        from c2_invariants import TRSInvariant
        model = C2Model(
            h_func=lambda kx, ky, t=t_val: kane_mele_atomic(kx, ky, t=t),
            n_occ=2,
            c2_op=spinful_c2(),
            spinful=True,
            trs=True,
            trs_unitary=standard_trs_unitary_spin_pairs(4),
        )
        inv = TRSInvariant(model)

        assert np.isclose(inv.partial_chern_boundary, 0.0, atol=1e-6), \
            f"t={t_val}: partial_chern_boundary={inv.partial_chern_boundary}, expected 0"
        assert inv.z2_winding == 0, \
            f"t={t_val}: z2_winding={inv.z2_winding}, expected 0"
        assert np.isclose(inv.partial_chern, 0.0, atol=1e-6), \
            f"t={t_val}: partial_chern={inv.partial_chern}, expected 0"

        assert round(inv.nu("1a")) % 2 == 1, \
            f"t={t_val}: nu_1a={inv.nu('1a')}, expected 1 (mod 2)"
        for w in ("1b", "1c", "1d"):
            assert round(inv.nu(w)) % 2 == 0, \
                f"t={t_val}: nu_{w}={inv.nu(w)}, expected 0 (mod 2)"


class TestMakeInvariant:
    """Factory dispatches correctly."""

    def test_spinless(self):
        model = C2Model(
            h_func=lambda kx, ky: haldane_bloch(kx, ky),
            n_occ=1, c2_op=HALDANE_C2,
        )
        inv = make_invariant(model)
        assert isinstance(inv, SpinlessInvariant)

    def test_spinful(self):
        model = C2Model(
            h_func=lambda kx, ky: kane_mele_bloch(kx, ky),
            n_occ=2, c2_op=spinful_c2(), spinful=True,
        )
        inv = make_invariant(model)
        assert isinstance(inv, SpinfulInvariant)

    def test_trs(self):
        from c2_invariants import TRSInvariant
        model = C2Model(
            h_func=lambda kx, ky: kane_mele_bloch(kx, ky),
            n_occ=2,
            c2_op=spinful_c2(),
            spinful=True,
            trs=True,
            trs_unitary=standard_trs_unitary_spin_pairs(4),
        )
        inv = make_invariant(model)
        assert isinstance(inv, TRSInvariant)
        d = inv.diagnostics()
        assert inv.partial_chern_boundary == d["C_I_bnd"]
        assert inv.partial_chern == d["C_I"]
        assert inv.partial_chern == inv.partial_chern_boundary + 2 * inv.z2_winding
        w = d["winding"]
        assert w.partial_chern_boundary == inv.partial_chern_boundary


class TestModelValidation:
    """C2Model validates inputs."""

    def test_trs_requires_spinful(self):
        with pytest.raises(ValueError, match="trs=True requires spinful=True"):
            C2Model(
                h_func=lambda kx, ky: np.eye(2),
                n_occ=1, c2_op=np.eye(2), trs=True,
            )

    def test_trs_requires_even_nocc(self):
        with pytest.raises(ValueError, match="even n_occ"):
            C2Model(
                h_func=lambda kx, ky: np.eye(4),
                n_occ=3,
                c2_op=np.eye(4),
                spinful=True,
                trs=True,
                trs_unitary=standard_trs_unitary_spin_pairs(4),
            )

    def test_trs_requires_trs_unitary(self):
        with pytest.raises(ValueError, match="trs_unitary"):
            C2Model(
                h_func=lambda kx, ky: kane_mele_bloch(kx, ky),
                n_occ=2,
                c2_op=spinful_c2(),
                spinful=True,
                trs=True,
            )

    def test_trs_unitary_none_when_not_trs(self):
        with pytest.raises(ValueError, match="trs_unitary must be None"):
            C2Model(
                h_func=lambda kx, ky: kane_mele_bloch(kx, ky),
                n_occ=2,
                c2_op=spinful_c2(),
                spinful=True,
                trs=False,
                trs_unitary=standard_trs_unitary_spin_pairs(4),
            )
