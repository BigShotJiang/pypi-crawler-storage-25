# Real-space invariants in `c2-invariants`

This is an introduction of the real-space invariants
$\nu_{1x}$ used in the package, from the simplest case (spinless) to the full
spinful + time-reversal-symmetric (TRS) setting. The invariants are
**Wannier-function (WF) multiplicity counts** at the four maximal Wyckoff
positions of wallpaper group $p2$, determined by the $C_2$ eigenvalues at the
four time-reversal-invariant momenta (TRIMs). The underlying references are
van Miert and Ortix, Phys. Rev. B **98**, 235130 (2018) and Kooi, van Miert
and Ortix, *npj Quantum Materials* **6**, 1 (2021). For implementation details,
see [boundary-gauge.md](boundary-gauge.md),
[interior-gauge.md](interior-gauge.md),
[winding-number.md](winding-number.md), and the module docstring of
[src/c2_invariants/invariants.py](../src/c2_invariants/invariants.py).

## 1. Wyckoff positions and TRIMs

Wallpaper group $p2$ has four maximal Wyckoff positions in the square unit
cell used by the package:

$$1a = (0, 0), \quad 1b = (\tfrac12, 0), \quad 1c = (0, \tfrac12), \quad 1d = (\tfrac12, \tfrac12).$$

The four TRIMs are

$$\Gamma = (0, 0), \quad X = (\pi, 0), \quad Y = (0, \pi), \quad M = (\pi, \pi).$$

The API labels them `'1a', '1b', '1c', '1d'` and `'Gamma', 'X', 'Y', 'M'`.

**Effective Brillouin zone.** The Brillouin zone is the torus
$\mathbf k = (k_x, k_y) \in [-\pi, \pi]^2$ with $2\pi$-periodic Bloch
Hamiltonian. The **effective Brillouin zone (EBZ)** is the right half
$[0, \pi] \times [-\pi, \pi]$, a fundamental domain of the $C_2$ action
$\mathbf k \mapsto -\mathbf k$. Its boundary is a closed loop through all
four TRIMs; see [boundary-gauge.md](boundary-gauge.md) for the explicit
parameterization.

## 2. Spinless regime: even and odd Wannier functions

A spinless Wannier function localized at Wyckoff position $w$ is either
**even** ($\xi = +1$) or **odd** ($\xi = -1$) under the $C_2$ rotation about
that position. Its contribution to the $C_2$ eigenvalue at TRIM $k$ is

$$\chi_w(k) = \xi \, e^{i\, k \cdot 2w}.$$

Let $N_{x, \pm}$ denote the number of WFs with $\xi = \pm 1$ at Wyckoff $1x$,
and let $K_\pm$ be the total number of $\pm 1$ $C_2$ eigenvalues among
occupied Bloch states at TRIM $K$. Summing $\chi_w$ over WFs and over TRIMs
assembles a $4 \times 4$ Hadamard system (the character table of
$(\mathbb Z_2)^2$) for the net excesses
$\delta_K \equiv K_- - K_+$.

Defining $\nu_x \equiv N_{x, -} - N_{x, +}$, the inversion gives

$$\nu_{1a} = n_{\rm occ} - \tfrac{1}{2}(G_- + X_- + Y_- + M_-),$$
$$\nu_{1b} = \tfrac{1}{2}(-G_- + X_- - Y_- + M_-),$$
$$\nu_{1c} = \tfrac{1}{2}(-G_- - X_- + Y_- + M_-),$$
$$\nu_{1d} = \tfrac{1}{2}(-G_- + X_- + Y_- - M_-).$$

Here $G_\pm, X_\pm, Y_\pm, M_\pm$ are the multiplicities of $\pm 1$ $C_2$
eigenvalues among occupied states at the four TRIMs. This matches
`_WYCKOFF_FORMULAS` in
[src/c2_invariants/invariants.py](../src/c2_invariants/invariants.py) and is
evaluated by `SpinlessInvariant`.

## 3. Spinful without TRS: Chern correction

For spin- $\tfrac{1}{2}$ bands the $C_2$ eigenvalues are $\pm i$ instead of $\pm 1$:
$C_2^2 = -1$ on each band. The character table is rewritten with $\pm i$ in
place of $\pm 1$; the Hadamard inversion is modified accordingly, and an
additional term proportional to the first Chern number $Ch$ of the occupied
subspace appears:

$$\nu^{\rm spinful}_{1x} = \nu^{\rm spinless}_{1x}(\pm i) + \alpha_{1/2} \, Ch,
\qquad \alpha_{1/2} = \tfrac12.$$

**Why a Chern term, and why $\alpha_{1/2} = \tfrac{1}{2}$.** Real-space
positions of Wannier centers are manifestly invariant under a hypothetical
flip of the arrow of time: a WF at Wyckoff $w$ remains at $w$. Under such a
flip, however, the Chern number changes sign, $Ch \to -Ch$. For $\nu_{1x}$
to remain a well-defined WF count, the Chern contribution must enter with a
coefficient such that $\pm Ch$ describe the same real-space configuration
modulo the quantization of $\nu_{1x}$. Combined with the spin- $\tfrac{1}{2}$
Kramers doubling (each Chern quantum is carried by a pair of bands), this
forces $\alpha_{1/2} = \tfrac{1}{2}$.

In code, two Wyckoff positions are implemented for this regime (see
`_WYCKOFF_FORMULAS_SPINFUL` in
[src/c2_invariants/invariants.py](../src/c2_invariants/invariants.py)):

$$\nu^{\rm spinful}_{1a} = -G_+ + \tfrac{1}{2}(-G_- + X_- + Y_- + M_- + Ch),$$
$$\nu^{\rm spinful}_{1d} = \tfrac{1}{2}(G_- - X_- - Y_- + M_- + Ch).$$

Here $G_+, G_-, X_-, Y_-, M_-$ now count $\pm i$ $C_2$ eigenvalues
($+$ for $+i$, $-$ for $-i$), and $Ch$ is the Fukui–Hatsugai–Suzuki Chern
integer of the occupied subspace (provided by `_chern_number` in
[src/c2_invariants/chern.py](../src/c2_invariants/chern.py)). This is evaluated
by `SpinfulInvariant`.

## 4. Spinful with TRS: idealized $C_2$-invariant Kramers split

Add time-reversal symmetry $\Theta$ with $\Theta^2 = -1$. At every TRIM, the
$C_2$ eigenvalues of occupied states come in **Kramers-partnered pairs**
$(+i, -i)$: $\Theta$ exchanges the partners and flips the $C_2$ eigenvalue
sign. In particular, the total $G_+$ equals the total $G_-$ (same for $X, Y,
M$), and the unrestricted spinful formulas of section 3 collapse to
tautologies.

**Idealized split.** Suppose one could decompose the occupied subspace into
two $n_{\rm half}$-dimensional subspaces — call them **sector I** and
**sector II** — that

- are each **$C_2$-invariant**, and
- are exchanged by $\Theta$ (so sector I contains exactly one member of each
  Kramers pair at every TRIM).

Within sector I alone, TRS is absent (it maps out of the sector), and the
spinful-without-TRS formulas of section 3 apply with

- $G_+, G_-, X_-, Y_-, M_-$ now counting the $\pm i$ $C_2$ multiplicities
  **in sector I** at each TRIM, and
- the Chern integer replaced by the **partial Chern number** of sector I,
  $C_I$.

This gives the **partial real-space invariants** at each Wyckoff:

$$\nu^I_{1a} = -G_+ + \tfrac{1}{2}(-G_- + X_- + Y_- + M_-) + \tfrac{C_I}{2},$$
$$\nu^I_{1b} = \tfrac{1}{2}(G_- - X_- + Y_- - M_-) + \tfrac{C_I}{2},$$
$$\nu^I_{1c} = \tfrac{1}{2}(G_- + X_- - Y_- - M_-) + \tfrac{C_I}{2},$$
$$\nu^I_{1d} = \tfrac{1}{2}(G_- - X_- - Y_- + M_-) + \tfrac{C_I}{2}.$$

By Kramers, sector II contributes identically at each Wyckoff, so the total
WF multiplicity is twice the sector-I count.

Globally constructing a smooth $C_2$-invariant, TRS-paired split on the
full half Brillouin zone is obstructed in general. The next section is the
key insight: **we never need such a global construction.**

## 5. Key insight: a boundary gauge is almost enough

The formulas of section 4 ask for two things: (i) sector-I $C_2$
multiplicities at the four TRIMs, and (ii) the partial Chern number $C_I$ of
sector I. Remarkably, a symmetric gauge defined **only on the closed boundary
of the effective Brillouin zone (EBZ)** is almost enough: it determines the
multiplicities exactly and fixes $C_I$ up to an integer ambiguity of $\pm 2$
that is detected by a single $\mathbb Z_2$ invariant measuring whether the
boundary gauge extends smoothly over the half-BZ (EBZ) interior.

**What the boundary gauge gives you directly.**
Construct a Kramers-paired frame $V_K(\mathbf k)$ along the closed EBZ
boundary loop that is smooth along the loop and in which $C_2$ is diagonal
at each of the four TRIMs (see [boundary-gauge.md](boundary-gauge.md)). From
this single boundary object one reads off:

- **Sector-I $C_2$ multiplicities.** At every TRIM the cached diagonal
  $V_K^\dagger \hat C\, V_K$ splits into two Kramers partners; calling the
  first $n_{\rm half}$ columns "sector I" gives $G_\pm, X_-, Y_-, M_-$
  immediately.
- **Boundary partial Chern number** $C_I^{\rm bnd} \equiv \gamma_I / \pi$,
  where
  $$\gamma_I = \sum_j \mathrm{Arg} \bigl(\det\bigl(\Phi_j^\dagger \Phi_{j+1}\bigr)\bigr)$$
  is the unwrapped Berry phase of the sector-I columns $\Phi_j$ summed
  around the closed boundary loop (see [boundary-gauge.md](boundary-gauge.md)
  §7).

Neither of these uses interior data.

**What the interior gauge is for: an extendability check.** The remaining
question is whether the chosen boundary gauge can be extended smoothly into
the half-BZ interior as a $C_2 \cdot \Theta$-symmetric Kramers frame. This is
a yes/no topological property of the boundary gauge, measured by the
$\mathbb Z_2$ winding number $\nu_{Z2}$
(see [winding-number.md](winding-number.md)). Operationally, the library
builds an independent interior gauge by parallel transport on a half-BZ mesh
(see [interior-gauge.md](interior-gauge.md)) and compares it to the boundary
gauge along the loop.

- **$\nu_{Z2} = 0$.** The boundary gauge extends. The boundary Berry phase
  $\gamma_I$ is the honest sector-I holonomy on the loop and
  $C_I = C_I^{\rm bnd}$.
- **$\nu_{Z2} = 1$.** No such extension exists. Any gauge that *does* extend
  differs from the current boundary gauge by a twist that shifts the
  sector-I Berry phase by $2\pi$. One absorbs that shift by defining the
  **partial Chern number** as

  $$C_I = C_I^{\rm bnd} + 2\nu_{Z2},$$

  which is the quantity that enters the Wyckoff formulas in section 4.

**Takeaway.** No globally smooth symmetric gauge on the half-BZ is needed to
compute the invariants. It is enough to

1. build a good symmetric gauge on the EBZ **boundary**, from which all
   multiplicities and $C_I^{\rm bnd}$ follow, and
2. test one bit — $\nu_{Z2}$ — telling you whether that boundary gauge is
   compatible with any interior extension, and shifting $C_I$ by
   $2\nu_{Z2}$ if not.

Everything else in the library is machinery for producing those two
ingredients reliably.

## 6. Implementation pointers

The three real-space-invariant classes are in
[src/c2_invariants/invariants.py](../src/c2_invariants/invariants.py):

- `SpinlessInvariant` — section 2.
- `SpinfulInvariant` — section 3.
- `TRSInvariant` — sections 4–5.

For the TRS regime, the pipeline is: boundary gauge
([boundary-gauge.md](boundary-gauge.md), `BoundaryGauge`) $\to$ interior
gauge ([interior-gauge.md](interior-gauge.md), `InteriorGauge`) $\to$ Berry
phase $\gamma_I$ and $\mathbb Z_2$ winding $\nu_{Z2}$
([winding-number.md](winding-number.md), `WindingCalculator`) $\to$ partial
Wyckoff invariants (`TRSInvariant`).

Relevant API on `TRSInvariant`: `nu(wyckoff)`, `partial_chern` ($C_I$),
`partial_chern_boundary` ($C_I^{\rm bnd}$), `z2_winding` ($\nu_{Z2}$),
`sector1_counts`, and `diagnostics()` for the full dict including the
underlying gauge objects.

## 7. Gauge labeling and mod 2

The split "sector I vs sector II" in section 4 is a labeling convention: at
each TRIM, either Kramers partner may be called sector I. Swapping the label
permutes the sector-I multiplicities ($G_\pm \leftrightarrow$ the other
partner's counts), and independently changes the sign of the partial
boundary Chern $C_I^{\rm bnd}$. Consequently, the raw inputs
$G_\pm, X_-, Y_-, M_-, C_I^{\rm bnd}$ are not individually invariant. The
specific combinations $\nu^I_{1x}$, however, are defined **modulo 2**, and
in that sense are robust to the sector-I / sector-II swap and other
allowed gauge redefinitions of the boundary frame.

As an illustrative example: consider stacking two copies of the Kane–Mele model at half-filling. Picking sector I to contain the spin-up band of both copies gives partial Chern $(C_I, C_{II}) = (+2, -2)$; picking spin-up from one copy and spin-down from the other gives $(0, 0)$. The sector-I $C_2$ multiplicities at the TRIMs differ between the two labelings (because opposite Kramers partners have opposite $C_2$ eigenvalues), but the differences exactly cancel against the shift in $C_I/2$, leaving $\nu^I_{1x}$ unchanged modulo 2.
