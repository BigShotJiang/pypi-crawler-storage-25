# Boundary gauge construction on the EBZ (spinful + TRS regime)

This document describes how `BoundaryGauge` in
[src/c2_invariants/gauge/boundary.py](../src/c2_invariants/gauge/boundary.py)
(with primitives from
[src/c2_invariants/gauge/p_symmetric.py](../src/c2_invariants/gauge/p_symmetric.py))
builds a smooth $C_2 \Theta$-symmetric Kramers gauge on the closed loop
that bounds the effective Brillouin zone (EBZ). This gauge is used only by
the `TRSInvariant` path (and by `WindingCalculator`); the spinless and
spinful-no-TRS regimes do not need it. Throughout we assume $n_{\rm occ}$
is even and write $n_{\rm half} = n_{\rm occ}/2$.

## 0. Setup and conventions

**$2\pi$-periodicity of the Bloch Hamiltonian.** The Bloch Hamiltonian
$\hat H(\mathbf k)$ with $\mathbf k = (k_x, k_y)$ is assumed Hermitian
and $2\pi$-periodic in each component:

$$
\hat H(k_x + 2\pi,  k_y)  =  \hat H(k_x,  k_y)  =  \hat H(k_x,  k_y + 2\pi) .
$$

In the square embedding used throughout the library the four
time-reversal-invariant momenta are

- $\Gamma = (0, 0)$,
- $X = (\pi, 0)$,
- $Y = (0, \pi)$,
- $M = (\pi, \pi)$,

and in particular $k_y = -\pi$ labels the **same** Bloch Hamiltonian as
$k_y = +\pi$ (and likewise for $k_x$). This identification is used
below to relate the lower-half boundary to the upper-half one.

**Symmetries.** Let $\hat C$ be the $\mathbf k$-independent unitary
$C_2$ operator (same Bloch gauge as $\hat H$), with $\hat C^{2} =
-\mathbb 1$ in the spinful case. Time reversal is
$\hat\Theta = U_\Theta \hat K$ (complex conjugation $\hat K$) with
$U_\Theta U_\Theta^{\ast} = -\mathbb 1$. The combined anti-unitary is

$$
\hat P  \equiv  \hat C \hat\Theta  =  U_P \hat K,
\qquad
U_P  =  \hat C U_\Theta,
\qquad
U_P U_P^{\ast} = +\mathbb 1,
\qquad
U_P  =  U_P^{\top},
\qquad
\hat P^{2}  =  +\mathbb 1 .
$$

$U_P$ is built by `u_p_c2theta(c2_op, trs_unitary)` at
[src/c2_invariants/gauge/boundary.py:32](../src/c2_invariants/gauge/boundary.py).

Because $\hat P \hat H(\mathbf k) \hat P^{-1} = \hat H(\mathbf k)$
pointwise ($\hat C$ sends $\mathbf k \to -\mathbf k$ and $\hat\Theta$
does the same, so the two cancel), $\hat P$ acts on each Bloch fibre
separately, which makes a fibrewise symmetric gauge well-defined.

**Sewing matrix.** For any orthonormal frame
$\lbrace \lvert\psi_i(\mathbf k)\rangle \rbrace$ on the occupied subspace define

$$
\mathcal M_{ij}(\mathbf k) =
\langle\psi_i(\mathbf k)\lvert \hat P \rvert\psi_j(\mathbf k)\rangle =
\sum_{a,b} \psi_i^{\ast}(\mathbf k)_a (U_P)_{ab} \psi_j^{\ast}(\mathbf k)_b .
$$

This is computed by `sewing_matrix_p` as
`states.conj().T @ (u_p @ np.conj(states))` at
[src/c2_invariants/gauge/p_symmetric.py:186](../src/c2_invariants/gauge/p_symmetric.py).

**Two equivalent frames** are used interchangeably:

- **Kramers-sector frame** $V_K(\mathbf k)$. Columns ordered as
  $\bigl[\lvert\varphi_{1}\rangle,\dots,\lvert\varphi_{n_{\rm half}}\rangle, 
  \lvert\chi_{1}\rangle,\dots,\lvert\chi_{n_{\rm half}}\rangle\bigr]$.
  Target sewing matrix: $\mathcal M = \sigma_x \otimes \mathbb 1_{n_{\rm half}}$.

- **Real $P$-invariant frame** $V_R(\mathbf k) = V_K(\mathbf k) W$,
  with target sewing matrix $\mathcal M = \mathbb 1_{n_{\rm occ}}$ and
  bridge

$$
W  =  \tfrac{1}{\sqrt 2}
\begin{pmatrix} \mathbb 1_{n_{\rm half}} & -i \mathbb 1_{n_{\rm half}}\\
                 \mathbb 1_{n_{\rm half}} & +i \mathbb 1_{n_{\rm half}}
\end{pmatrix} .
$$

See `_kramers_to_p_real_W` at
[src/c2_invariants/gauge/p_symmetric.py:124](../src/c2_invariants/gauge/p_symmetric.py).
The real frame is preferred for transport because overlaps between
$P$-invariant frames are real, and the relevant gauge group reduces
from $\mathrm U(n_{\rm occ})$ to $\mathrm O(n_{\rm occ})$.

## 1. HSP anchor frames at $\Gamma, Y, M, X$

Done in `_build_upper` at
[src/c2_invariants/gauge/boundary.py:102-114](../src/c2_invariants/gauge/boundary.py).
For each $\mathbf k_\alpha \in \lbrace \Gamma, Y, M, X \rbrace$:

**(a) Occupied subspace.** Diagonalize $\hat H(\mathbf k_\alpha)$ and
keep the lowest $n_{\rm occ}$ bands, giving the projector

$$
\Pi(\mathbf k_\alpha)  =  \sum_{n=1}^{n_{\rm occ}} 
\lvert u_n(\mathbf k_\alpha)\rangle\langle u_n(\mathbf k_\alpha)\rvert .
$$

**(b) Split by $C_2$ eigenvalue.** At an HSP one has
$[\hat H, \hat C] = 0$ (because $\mathbf k_\alpha = -\mathbf k_\alpha
\bmod 2\pi$), and $\hat C^{2} = -\mathbb 1$ implies that the occupied
block $\hat C_{\rm occ} = \langle u_m\rvert \hat C \rvert u_n\rangle$
has eigenvalues $\pm i$. The helper `_c2_eigsort` at
[src/c2_invariants/gauge/boundary.py:49](../src/c2_invariants/gauge/boundary.py)
diagonalizes the Hermitian matrix $i \hat C_{\rm occ}$ with
`np.linalg.eigh`, producing two sectors of $n_{\rm half}$ vectors
each. Sector I is the $C_2 = +i$ eigenspace:

$$
\hat C \lvert\varphi_a(\mathbf k_\alpha)\rangle
 =  +i \lvert\varphi_a(\mathbf k_\alpha)\rangle,
\qquad a = 1, \dots, n_{\rm half} .
$$

Within each sector the states are re-ordered by ascending
$\langle\varphi_a\rvert \hat H \rvert\varphi_a\rangle$ via `lexsort`.

**(c) Kramers partner in sector II.** For each sector-I state define

$$
\lvert\chi_a(\mathbf k_\alpha)\rangle \equiv
\hat P \lvert\varphi_a(\mathbf k_\alpha)\rangle =
U_P \lvert\varphi_a^{\ast}(\mathbf k_\alpha)\rangle .
$$

Because $\lbrace \hat C, \hat P \rbrace  = 0$, these are $C_2 = -i$ eigenstates
and are orthonormal to the $\varphi$'s:

$$
\hat C \lvert\chi_a\rangle = -i \lvert\chi_a\rangle,
\qquad
\langle\varphi_a\lvert\chi_b\rangle = 0,
\qquad
\langle\chi_a\lvert\chi_b\rangle = \delta_{ab} .
$$

**(d) Anchor frames and stored $C_2$ matrix.**

$$
V_K(\mathbf k_\alpha)  = 
\bigl[\lvert\varphi_{1}\rangle,\dots,\lvert\varphi_{n_{\rm half}}\rangle, 
       \lvert\chi_{1}\rangle,\dots,\lvert\chi_{n_{\rm half}}\rangle\bigr],
\qquad
V_R(\mathbf k_\alpha)  =  V_K(\mathbf k_\alpha) W .
$$

By construction
$\mathcal M\bigl[V_K(\mathbf k_\alpha)\bigr] = \sigma_x \otimes \mathbb 1$
and
$\mathcal M\bigl[V_R(\mathbf k_\alpha)\bigr] = \mathbb 1$. The diagonal
$V_K^\dagger \hat C V_K = \mathrm{diag}(+i,\dots,+i,-i,\dots,-i)$ is
cached (as `hsp_c2_matrices`) for use in Step 5.

## 2. SVD parallel transport on the upper half

For each segment $\mathbf k_{\rm start} \to \mathbf k_{\rm end}$ in
$\bigl\lbrace \Gamma \to Y, Y \to M, M \to X \bigr\rbrace$ (see
`SEGMENTS` at
[src/c2_invariants/gauge/boundary.py:116-120](../src/c2_invariants/gauge/boundary.py)),
discretize with $n_k$ sub-intervals:

$$
\mathbf k_i  =  \bigl(1 - i/n_k\bigr) \mathbf k_{\rm start}
               +  \bigl(i/n_k\bigr) \mathbf k_{\rm end},
\qquad i = 0, 1, \dots, n_k - 1 .
$$

Only the sector-I half-frame
$\Phi(\mathbf k) = [\lvert\varphi_{1}\rangle,\dots,\lvert\varphi_{n_{\rm half}}\rangle]$
is transported; the $\chi$-partners are regenerated at each step by
applying $\hat P$. Initialize
$\Phi_{\rm prev} = \Phi(\mathbf k_{\rm start})$ from the anchor.

At each step $i \ge 1$
(code at
[src/c2_invariants/gauge/boundary.py:137-151](../src/c2_invariants/gauge/boundary.py)):

1. Diagonalize $\hat H(\mathbf k_i)$ and assemble the occupied frame
   $U_{\rm occ}(\mathbf k_i)$ (columns
   $\lvert u_n(\mathbf k_i)\rangle$, $n = 1, \dots, n_{\rm occ}$).

2. Form the overlap

$$
S  =  U_{\rm occ}(\mathbf k_i)^{\dagger} \Phi_{\rm prev}
 =  \bigl[\langle u_m(\mathbf k_i)\lvert\varphi_a(\mathbf k_{i-1})\rangle\bigr]_{m,a}
 ,\qquad
S \in \mathbb C^{n_{\rm occ} \times n_{\rm half}} .
$$

3. Polar-decompose via SVD: $S = \tilde U \Sigma \tilde V^\dagger$,
   set $R = \tilde U \tilde V^\dagger$ (the unitary part of $S$).
   This is the Kato / polar-decomposition parallel-transport step:
   $R$ is the isometry closest to $S$, and

$$
\Phi(\mathbf k_i)  =  U_{\rm occ}(\mathbf k_i) R
 =  \arg\min_{\substack{\Phi\subset\mathrm{occ}(\mathbf k_i)\\
                          \Phi^\dagger \Phi  =  \mathbb 1}}
       \bigl\lVert \Phi  -  \Pi(\mathbf k_i) \Phi_{\rm prev} \bigr\rVert_F .
$$

4. Regenerate partners:
   $\lvert\chi_a(\mathbf k_i)\rangle = \hat P \lvert\varphi_a(\mathbf k_i)\rangle
     = U_P \lvert\varphi_a^{\ast}(\mathbf k_i)\rangle$.

5. Assemble
   $V_K(\mathbf k_i) = [\Phi(\mathbf k_i), \hat P \Phi(\mathbf k_i)]$
   and
   $V_R(\mathbf k_i) = V_K(\mathbf k_i) W$.

6. Set $\Phi_{\rm prev} \leftarrow \Phi(\mathbf k_i)$.

Because the $\chi$'s are obtained by applying $\hat P$ to the
$\varphi$'s, the sewing matrix
$\mathcal M\bigl[V_K(\mathbf k_i)\bigr] = \sigma_x \otimes \mathbb 1$
holds **exactly** at every interior $\mathbf k_i$. The only failure
mode is that at the end of the segment the transported frame need not
coincide with the pre-chosen anchor at $\mathbf k_{\rm end}$.

## 3. Kramers-flip detection

At the end of each segment
([src/c2_invariants/gauge/boundary.py:153-165](../src/c2_invariants/gauge/boundary.py))
compute the endpoint gauge offset in the real frame:

$$
\mathcal R  =  V_R(\mathbf k_{n_k - 1})^{\dagger} V_R(\mathbf k_{\rm end})
\in \mathbb C^{n_{\rm occ}\times n_{\rm occ}} .
$$

Since both frames are $P$-invariant, $\mathcal R$ is real up to
numerical noise. Take $\mathcal R_{\mathbb R} = \mathrm{Re} \mathcal R$,
SVD $\mathcal R_{\mathbb R} = \tilde U \Sigma \tilde V^\top$, and set
$\mathcal R_{\rm SO} = \tilde U \tilde V^\top \in \mathrm O(n_{\rm occ})$.

- If $\det \mathcal R_{\rm SO} = +1$: no flip.
- If $\det \mathcal R_{\rm SO} = -1$: a **Kramers flip** is detected —
  the transported frame reaches $\mathbf k_{\rm end}$ in the opposite
  component of $\mathrm O(n_{\rm occ})$ from the pre-chosen anchor.
  Fix by flipping the sign of one designated column of the anchor,
  $V_R(\mathbf k_{\rm end})[:, n_{\rm half}] \mapsto -V_R(\mathbf k_{\rm end})[:, n_{\rm half}]$, then rebuild
  $V_K(\mathbf k_{\rm end}) = V_R(\mathbf k_{\rm end}) W^{\dagger}$
  and the stored HSP $C_2$ matrix. The flipped endpoint is recorded in
  the result dict as `kramers_flips[end_name] = True`.

## 4. SO drift correction across the segment

After any flip fix, a small residual offset
$\mathcal R_{\rm SO, ep} \in \mathrm{SO}(n_{\rm occ})$ remains between
the transported endpoint and the anchor. The code spreads it smoothly
across the segment
([src/c2_invariants/gauge/boundary.py:167-178](../src/c2_invariants/gauge/boundary.py)):

1. Take the matrix logarithm and antisymmetrize:

$$
\mathbf A  =  \tfrac{1}{2}\Bigl(\mathrm{Re} \log \mathcal R_{\rm SO, ep}
 -  ( \mathrm{Re} \log \mathcal R_{\rm SO, ep} )^{\top}\Bigr)
 \in  \mathfrak{so}(n_{\rm occ}) .
$$

2. For each step $j = 0, \dots, n_k - 1$ of the segment, with
   $f_j = j/(n_k - 1)$ (or $f_j = 0$ if $n_k = 1$), correct

$$
V_R^{\rm corr}(\mathbf k_j)  =  V_R(\mathbf k_j) \exp\bigl(f_j \mathbf A\bigr) .
$$

By construction $V_R^{\rm corr}(\mathbf k_0) = V_R(\mathbf k_0)$ and
$V_R^{\rm corr}(\mathbf k_{n_k - 1}) = V_R(\mathbf k_{\rm end})$, so
neighboring segments join seamlessly at HSPs. Because
$\exp(f_j \mathbf A) \in \mathrm{SO}(n_{\rm occ})$ is real, the
$P$-invariance condition $\mathcal M[V_R] = \mathbb 1$ is preserved.
The corresponding Kramers frame is
$V_K^{\rm corr} = V_R^{\rm corr} W^{\dagger}$.

## 5. Lower half: three edges, three identifications

This step is the crux of the construction and deserves care. The lower
half of the EBZ boundary is **not** uniformly the $C_2$-image of the
upper half. It consists of three edges, each related to a specific
upper-half segment by a **distinct** identification:

```mermaid
flowchart LR
    Gamma["Gamma = (0,0)"] -- "SVD transport" --> Y["Y = (0, pi)"]
    Y -- "SVD transport" --> M["M = (pi, pi)"]
    M -- "SVD transport" --> X["X = (pi, 0)"]
    X -- "Edge A: C2 + 2pi in kx" --> Mp["M' = (pi, -pi)"]
    Mp -- "Edge B: 2pi in ky only" --> Yp["Y' = (0, -pi)"]
    Yp -- "Edge C: C2" --> Gamma
```

Denote by $c_a^{\alpha} \in \lbrace +i, -i \rbrace$ the $C_2$ eigenvalue of the
$a$-th Kramers column of $V_K$ at HSP $\alpha$, read from the
diagonal of the cached $V_K^\dagger \hat C V_K$.

### Edge A: $k_x = \pi$, $k_y \in [0, -\pi]$, $X \to M'$

$C_2$-fold of the upper $M \to X$ segment, composed with
$2\pi$-periodicity in $k_x$. Explicitly,

$$
\hat C \hat H(\pi, k_y) \hat C^{\dagger} =
\hat H(-\pi, -k_y) \stackrel{2\pi\text{-period. in } k_x}{=}
\hat H(+\pi, -k_y) ,
$$

so the lower point $(\pi, k_y)$ with $k_y \in [0, -\pi]$ is the
$C_2$ image of the upper point $(\pi, -k_y)$ with
$-k_y \in [0, +\pi]$, after identifying $k_x = -\pi$ with
$k_x = +\pi$. The code implements this as (lines 250-258 of
[boundary.py](../src/c2_invariants/gauge/boundary.py))

$$
\lvert\psi^{\rm low}_a(\pi, k_y)\rangle
 =  \lambda^{A}_a(k_y) \hat C \lvert\psi^{\rm up}_a(\pi, -k_y)\rangle ,
\qquad
\lambda^{A}_a(k_y)
 =  - \exp\Bigl[\tfrac{k_y}{2} (c^M_a - c^X_a)\Bigr] c^X_a .
$$

### Edge B: $k_y = -\pi$, $k_x \in [\pi, 0]$, $M' \to Y'$

**Pure $2\pi$-periodicity** in $k_y$. No $C_2$ and no phase. By

$$
\hat H(k_x,  -\pi)  =  \hat H(k_x,  +\pi) ,
$$

the Bloch Hamiltonians on the lower Edge B and the upper $Y \to M$
segment (which lives at $k_y = +\pi$) are literally identical, so the
**same occupied frames** are reused unchanged. The code at lines 260-267
of [boundary.py](../src/c2_invariants/gauge/boundary.py) is simply

```python
for j in range(nk + 1):
    upper_idx = 2 * nk - j
    kx_j      = np.pi * (nk - j) / nk
    edge_b.append(upper_states[upper_idx])
    mom_b.append((kx_j, -np.pi))
```

Note the absence of `_fold_column` and of any phase factor. In bra-ket
notation,

$$
\lvert\psi^{\rm low}_a(k_x, -\pi)\rangle
 =  \lvert\psi^{\rm up}_a(k_x, +\pi)\rangle .
$$

### Edge C: $k_x = 0$, $k_y \in [-\pi, 0]$, $Y' \to \Gamma$

Clean $C_2$-fold of the upper $\Gamma \to Y$ segment. Here

$$
\hat C \hat H(0, k_y) \hat C^{\dagger}  =  \hat H(0, -k_y) ,
$$

and no periodicity shift is needed because $k_x = 0$ is already
invariant under $k_x \mapsto -k_x$. The code at lines 269-277 of
[boundary.py](../src/c2_invariants/gauge/boundary.py) gives

$$
\lvert\psi^{\rm low}_a(0, k_y)\rangle
 =  \lambda^{C}_a(k_y) \hat C \lvert\psi^{\rm up}_a(0, -k_y)\rangle ,
\qquad
\lambda^{C}_a(k_y)
 =  - \exp\Bigl[\tfrac{k_y}{2} (c^Y_a - c^\Gamma_a)\Bigr] c^\Gamma_a .
$$

### Phase design

Each $\lambda_a$ on edges A and C linearly interpolates between the
two endpoint $C_2$ eigenvalues of column $a$. At the starting HSP
($k_y = 0$ on both edges) it reduces to $-c_a^{X}$ or
$-c_a^{\Gamma}$, which times $\hat C$ acting on the sector-I/II
label reproduces the anchor there; at the ending HSP
($k_y = -\pi$) it matches the partner anchor at $M$ or $Y$ after
$C_2$-folding. The phase is chosen so that the sewing condition
$\mathcal M\bigl[V_K\bigr] = \sigma_x \otimes \mathbb 1$ is preserved
throughout and the frame joins smoothly onto the anchors at the edge
endpoints.

## 6. Full-loop assembly and closure

`_build_full` at
[src/c2_invariants/gauge/boundary.py:311](../src/c2_invariants/gauge/boundary.py)
concatenates

$$
\text{full states} =
\underbrace{\bigl\lbrace V_K^{\rm corr}(\mathbf k_{0}),\dots,V_K(X)\bigr\rbrace}_{\text{upper, }3 n_k + 1\text{ points}}
\cup
\underbrace{\bigl\lbrace V_K^{\rm low}(\mathbf k_{1}),\dots,V_K(\Gamma)\bigr\rbrace}_{\text{lower, dropping duplicate at }X}
$$

giving $6 n_k + 1$ frames on the closed loop. Closure at $\Gamma$
relies on $2\pi$-periodicity: the final frame sits at $\mathbf k$
approaching $\Gamma$ from below, and can be compared to the initial
anchor at $\Gamma$. The nontrivial $\mathrm U(n_{\rm occ})$
rotation relating the two frames around the loop is precisely the
winding read off by `WindingCalculator` (see
[src/c2_invariants/winding.py](../src/c2_invariants/winding.py)).

## 7. Sector-I Berry phase along the EBZ loop

The list `full_states` is also the input to the **sector-I Berry phase** used in
the TRS pipeline. Let $\Phi_j \in \mathbb C^{N \times n_{\rm half}}$ be the first
$n_{\rm half}$ columns of the $j$-th Kramers frame (sector I only). Write
$L$ for the length of the `full_states` list and $n_{\rm links} = L - 1$. The
implementation sums one contribution per consecutive pair (same indexing as
`_sector1_berry_phase` in
[src/c2_invariants/winding.py](../src/c2_invariants/winding.py)):

$$
\gamma_I = \sum_{j=0}^{n_{\rm links} - 1} \mathrm{Arg}\, \det\bigl(
\Phi_j^{\dagger} \Phi_{j+1} \bigr).
$$

When $L = 6 n_k + 1$, there are $n_{\rm links} = 6 n_k$ links along the ordered
boundary path. The code uses `np.angle(np.linalg.det(overlap))` on each overlap
matrix $\Phi_j^{\dagger} \Phi_{j+1}$.

Define the **boundary partial Chern number**

$$
C_I^{\rm bnd} = \gamma_I / \pi .
$$

`WindingCalculator.sector1_berry_phase` returns $\gamma_I$; the same object as
$C_I^{\rm bnd}$ is `WindingCalculator.partial_chern_boundary` and
`TRSInvariant.partial_chern_boundary` (see
[real-space-invariants.md](real-space-invariants.md)). It is a **partial**
holonomy of the sector-I subbundle on the EBZ boundary **in the constructed
gauge**; it is not the Fukui–Hatsugai–Suzuki Chern number on the full torus.
Relative obstructions between this boundary gauge and the **separate** interior
construction appear in $\nu_{Z2}$ and in the full partial Chern
$C_I = C_I^{\rm bnd} + 2\nu_{Z2}$; see
**Key insight: a boundary gauge is almost enough** in
[real-space-invariants.md](real-space-invariants.md).

The **$\mathbb Z_2$ winding** from boundary–interior mismatch is a separate
quantity; see [winding-number.md](winding-number.md).

## 8. Diagnostics

At every $\mathbf k_j$ of the loop the builders write three quality
metrics into the result dict (see lines 196-211, 289-301, 334-346 of
[boundary.py](../src/c2_invariants/gauge/boundary.py)):

- Kramers sewing error:
  $\epsilon^{ \rm sew}_K(\mathbf k_j)  = 
    \bigl\lVert\mathcal M\bigl[V_K(\mathbf k_j)\bigr]  -  \sigma_x \otimes \mathbb 1\bigr\rVert_F$.
- Real sewing error:
  $\epsilon^{ \rm sew}_R(\mathbf k_j)  = 
    \bigl\lVert\mathcal M\bigl[V_R(\mathbf k_j)\bigr]  -  \mathbb 1\bigr\rVert_F$.
- Link smoothness:
  $\ell_j  = 
    \bigl\lVert V_R(\mathbf k_j)^{\dagger} V_R(\mathbf k_{j+1})  -  \mathbb 1\bigr\rVert_F$.

Small $\epsilon^{ \rm sew}$ certifies that the gauge respects
$\hat P$ pointwise; small $\ell_j$ certifies that the gauge is
smooth.

## What each step preserves

- **Step 1 (HSP anchors).** $\mathcal M_K = \sigma_x \otimes \mathbb 1$ and
  $\mathcal M_R = \mathbb 1$ at the four TRIMs; diagonal $C_2$
  block $V_K^\dagger \hat C V_K$ cached for use later.
- **Step 2 (SVD transport).** $\mathcal M_K = \sigma_x \otimes \mathbb 1$
  exact at every interior $\mathbf k$; smoothness is approximate but
  optimal in the Frobenius sense.
- **Step 3 (flip detection).** Fixes the $\mathrm O(n_{\rm occ})$
  component of the endpoint offset by permuting the Kramers label of
  the anchor.
- **Step 4 (SO correction).** Fixes the $\mathrm{SO}(n_{\rm occ})$
  drift smoothly across the segment; preserves $\mathcal M_R = \mathbb 1$.
- **Step 5 (lower half).** Preserves $\mathcal M_K = \sigma_x \otimes \mathbb 1$
  along each lower edge and matches the anchors at $X, M', Y', \Gamma$,
  using $C_2$ on edges A and C and only $2\pi$-periodicity on edge B.
- **Step 6 (assembly).** Produces a closed $6 n_k + 1$-point loop
  around the EBZ, ready for the winding calculation.

The end product `BoundaryGauge.full_states` is a closed, approximately
smooth, exactly $\hat P$-symmetric Kramers frame around the EBZ
boundary, which is then fed to the winding / partial-$\nu^{I}$
computation for the TRS regime.
