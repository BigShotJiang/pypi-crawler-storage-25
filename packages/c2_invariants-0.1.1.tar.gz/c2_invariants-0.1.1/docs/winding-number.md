# $\mathbb Z_2$ winding from boundary–interior mismatch (spinful + TRS)

This document describes the **$\mathbb Z_2$ winding number** computed in
[src/c2_invariants/winding.py](../src/c2_invariants/winding.py) and the
**principal-log / crossing** machinery in
[src/c2_invariants/chern.py](../src/c2_invariants/chern.py). It quantifies how the
**explicit** Kramers frame on the EBZ boundary (`BoundaryGauge.full_states`)
fails to agree with the frame obtained by **interior parallel transport**
(`InteriorGauge`) when both are compared along the **same** closed loop in
$\mathbf k$-space.

This is **not** the same object as the Fukui–Hatsugai–Suzuki Chern number on a
full torus (`ChernCalculator` in
[src/c2_invariants/chern.py](../src/c2_invariants/chern.py)); see
[real-space-invariants.md](real-space-invariants.md) for how $\nu_{Z2}$ combines
with sector-I data into the partial real-space invariants.

**Obstruction to gluing.** Heuristically, $\nu_{Z2}$ detects whether the
boundary-built and interior-transported symmetric frames can be related along
the EBZ loop by an **interior-only** gauge redefinition (trivial winding) or
whether a **boundary** twist is required (nontrivial winding). In the latter
case the boundary gauge choice shifts the accumulated sector-I Berry / partial
Chern bookkeeping; the code encodes that in the partial Chern number
$C_I = C_I^{\rm bnd} + 2\nu_{Z2}$. See
**Key insight: a boundary gauge is almost enough** in
[real-space-invariants.md](real-space-invariants.md).

**References.** The `principal_log` and `crossing_indicator` construction
follows the SO($N$) branch-cut logic of Kooi, van Miert and Ortix, *npj Quantum
Materials* **6**, 1 (2021), as noted in `chern.py`.

## Matched points on the loop

Let `full_bnd` be `boundary_result["full_states"]`, a list of length
$6 n_k + 1$ Kramers frames $V_K$ on the closed EBZ boundary (ordering as in
[boundary-gauge.md](boundary-gauge.md) §6).

The interior mesh is sampled along the **same** geometric loop by
`_assemble_interior_boundary(interior_result)`, producing `full_int` of the
same length. Each entry is a column-orthonormal $V_K(\mathbf k)$ taken from the
`InteriorGauge.states` array at the grid index that lies on that edge.

## Real $P$-symmetric gauge and $\mathrm{SO}(n_{\rm occ})$ overlaps

Kramers frames are converted to the **real** $P$-invariant basis via
`kramers_sectors_to_p_real` (see
[src/c2_invariants/gauge/p_symmetric.py](../src/c2_invariants/gauge/p_symmetric.py)),
giving $V_R$ with sewing matrix $\mathbb 1$.

For each matched index $j$,

$$
R_j = \mathrm{Re}\bigl( V_{R,\mathrm{bnd}}^{(j)\,\dagger} V_{R,\mathrm{int}}^{(j)} \bigr) \in \mathbb R^{n_{\rm occ} \times n_{\rm occ}}.
$$

If $\det R_j < 0$, the **last column of $R_j$ is flipped** so that after the
fix $R_j \in \mathrm{SO}(n_{\rm occ})$ (`_compute_R_list`). This chooses a
consistent orientation along the loop.

## Principal logarithm and crossing indicator

For a special orthogonal matrix $M$, `principal_log(M)` returns a real
antisymmetric matrix $X_0$ built from the real Schur form of $M$ (Eqs. (14)–(15)
in Kooi et al.).

For two nearby $\mathrm{SO}(N)$ matrices $M_1, M_2$ on the loop, the function
`crossing_indicator` in `chern.py` returns $0$ or $1$, counting **branch-cut
crossings** of the principal logarithm between $M_1$ and $M_2$. Let $L_i$ be
the output of `principal_log` on $M_i$, and $\Delta = L_2 - L_1$. The code
implements the criterion in `crossing_indicator` using $\Delta / (2\pi)$.

## $\mathbb Z_2$ winding

Summing over consecutive links along the closed loop,

$$
\nu_{Z2} = \sum_{j} k_j \pmod 2,
\qquad
k_j \in \lbrace 0, 1 \rbrace .
$$

Each $k_j$ is the integer returned by `crossing_indicator` applied to the pair
$(R_j, R_{j+1})$.

This is `WindingCalculator.z2_winding` / `TRSInvariant.z2_winding`.

**Interpretation.** Nonzero $\nu_{Z2}$ means the interior-transported gauge and
the boundary-constructed gauge sit in different $\mathrm{SO}(n_{\rm occ})$
sectors relative to one another around the loop, in the sense measured by
principal-log crossings — an obstruction to gluing them into a single smooth
gauge on the whole EBZ half-plane without a defect.

## Diagnostics

`WindingCalculator.boundary_overlap_report` returns `edge_crossing` (per-link
indicators), `R_list`, optional `theta` when $n_{\rm occ} = 2$ (planar
angles), and `nu_z2`.

## Related: sector-I Berry phase and partial Chern number

The **Berry phase** along the boundary uses only sector-I columns of
`full_states`; it is documented in [boundary-gauge.md](boundary-gauge.md) §7 and
implemented as `_sector1_berry_phase` in `winding.py`. The **boundary partial
Chern number** $C_I^{\rm bnd} = \gamma_I / \pi$ is `partial_chern_boundary` on
`WindingCalculator`. It is independent of the $\nu_{Z2}$ sum above, though
both are exposed by `WindingCalculator`. The **partial Chern number**
$C_I = C_I^{\rm bnd} + 2\nu_{Z2}$ (end result) is assembled in
`TRSInvariant`; see [real-space-invariants.md](real-space-invariants.md).
