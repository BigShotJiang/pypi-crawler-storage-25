"""
Input data containers for C2-symmetric Bloch Hamiltonians.

A ``BlochModel`` wraps a callable ``H(kx, ky) -> ndarray`` together with
the number of occupied bands. ``C2Model`` extends it with a C2 rotation
matrix and flags for spin and time-reversal symmetry.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import numpy as np


def standard_trs_unitary_spin_pairs(n_bands: int) -> np.ndarray:
    """Unitary ``U`` in ``Θ = U K`` (time reversal as complex conjugation ``K``).

    Uses ``i σ_y`` on each consecutive pair of indices
    ``(0,1), (2,3), …``, i.e. Kane–Mele-style ordering with two spin
    components per orbital.

    Parameters
    ----------
    n_bands : int
        Matrix dimension; must be even.

    Returns
    -------
    U : ndarray, shape (n_bands, n_bands)
        Pass as ``trs_unitary`` when ``trs=True``.
    """
    if n_bands % 2:
        raise ValueError("n_bands must be even for spinful TRS pairs")
    u = np.zeros((n_bands, n_bands), dtype=complex)
    sy = np.array([[0.0, -1j], [1j, 0.0]])
    for orb in range(n_bands // 2):
        u[2 * orb : 2 * orb + 2, 2 * orb : 2 * orb + 2] = 1j * sy
    return u


@dataclass(frozen=True)
class BlochModel:
    """Bloch Hamiltonian H(kx, ky) and band-filling information.

    Parameters
    ----------
    h_func : callable
        ``h_func(kx, ky)`` returns an ``(N, N)`` Hermitian ndarray.
        Must be 2pi-periodic in both arguments.
    n_occ : int
        Number of occupied bands.
    """

    h_func: Callable[[float, float], np.ndarray]
    n_occ: int
    n_bands: int = field(init=False)

    def __post_init__(self) -> None:
        n = self.h_func(0.0, 0.0).shape[0]
        object.__setattr__(self, "n_bands", n)


@dataclass(frozen=True)
class C2Model(BlochModel):
    """Bloch Hamiltonian with a C2 rotation symmetry.

    Parameters
    ----------
    h_func : callable
        ``h_func(kx, ky)`` returns an ``(N, N)`` Hermitian ndarray.
    n_occ : int
        Number of occupied bands.
    c2_op : ndarray (N, N)
        k-independent C2 rotation matrix.  Eigenvalues are +/-1 for
        spinless systems and +/-i for spinful systems.
    spinful : bool
        ``True`` for spin-1/2 systems (C2 eigenvalues +/-i).
    trs : bool
        ``True`` for time-reversal-symmetric systems.  Requires
        ``spinful=True`` and even ``n_occ``.
    trs_unitary : ndarray or None
        When ``trs=True``, the unitary ``U`` in ``Θ = U K`` (same basis as
        ``h_func`` and ``c2_op``).  Shape ``(n_bands, n_bands)``.  Must be
        ``None`` when ``trs=False``.
    """

    c2_op: np.ndarray = field(default_factory=lambda: np.eye(2))
    spinful: bool = False
    trs: bool = False
    trs_unitary: np.ndarray | None = None

    def __post_init__(self) -> None:
        super().__post_init__()
        if self.trs and not self.spinful:
            raise ValueError("trs=True requires spinful=True")
        if self.trs and self.n_occ % 2 != 0:
            raise ValueError("trs=True requires even n_occ (Kramers pairs)")
        if self.trs:
            if self.trs_unitary is None:
                raise ValueError(
                    "trs=True requires trs_unitary: unitary U in Θ = U K "
                    "(e.g. standard_trs_unitary_spin_pairs(n_bands))"
                )
            tu = np.asarray(self.trs_unitary)
            if tu.shape != (self.n_bands, self.n_bands):
                raise ValueError(
                    f"trs_unitary must have shape ({self.n_bands}, {self.n_bands}), "
                    f"got {tu.shape}"
                )
            object.__setattr__(self, "trs_unitary", tu.astype(complex, copy=False))
        elif self.trs_unitary is not None:
            raise ValueError("trs_unitary must be None when trs=False")
