"""
Real-space topological invariants for C2-symmetric crystals.

Public API
----------
SpinlessInvariant
    nu_{1x} for spinless C2-symmetric crystals (Z4 quantization).
SpinfulInvariant
    nu_{1x} for spinful without TRS, including Chern correction.
TRSInvariant
    Partial nu^I_{1x} for spinful TRS systems via Kramers sector decomposition.
make_invariant
    Factory that dispatches to the correct class based on C2Model flags.

Derivation of the real-space invariant formulas
================================================

The unit cell occupies (-1/2, 1/2] x (-1/2, 1/2] in Bravais coordinates.
The four maximal Wyckoff positions of wallpaper group p2 are:

    1a = (0, 0)      center of unit cell / C2 center
    1b = (1/2, 0)    half along a1
    1c = (0, 1/2)    half along a2
    1d = (1/2, 1/2)  corner of unit cell

The high-symmetry points (HSPs) of the BZ are:

    Gamma = (0, 0),  X = (pi, 0),  Y = (0, pi),  M = (pi, pi)

Step 1 -- Character table
--------------------------
A Wannier function (WF) at position w with C2 eigenvalue xi contributes
to the C2 eigenvalue at HSP k as  xi(k) = xi * exp(i k . 2w).

Step 2 -- Linear system
------------------------
Defining nu_x = N_{x,-} - N_{x,+} (signed WF count at position x),
the net eigenvalue excess delta_K = K_- - K_+ at each HSP is a 4x4
Hadamard system (the character table of (Z_2)^2).

Step 3 -- Inversion
--------------------
    nu_a = (1/4)(delta_Gamma + delta_X + delta_Y + delta_M)
    nu_b = (1/4)(delta_Gamma - delta_X + delta_Y - delta_M)
    nu_c = (1/4)(delta_Gamma + delta_X - delta_Y - delta_M)
    nu_d = (1/4)(delta_Gamma - delta_X - delta_Y + delta_M)

Step 4 -- Express using K_- only
----------------------------------
    nu_a = n_occ - (1/2)(Gamma_- + X_- + Y_- + M_-)
    nu_b = (1/2)(-Gamma_- + X_- - Y_- + M_-)
    nu_c = (1/2)(-Gamma_- - X_- + Y_- + M_-)
    nu_d = (1/2)(-Gamma_- + X_- + Y_- - M_-)

Spinful extension: for spin-1/2 the C2 eigenvalues are +/-i, and a
Chern-number correction alpha_{1/2} = 1/2 is needed:

    nu_{1x, spinful} = nu_{1x, spinless}(+/-i) + (1/2) * Ch

References
----------
van Miert & Ortix, Phys. Rev. B 98, 235130 (2018).
Kooi, van Miert & Ortix, npj Quantum Materials 6, 1 (2021).
"""

from __future__ import annotations

from functools import cached_property

import numpy as np

from .model import C2Model
from .chern import _chern_number

__all__ = [
    "c2_eigenvalue_counts",
    "SpinlessInvariant",
    "SpinfulInvariant",
    "TRSInvariant",
    "make_invariant",
]


# ===================================================================
# C2 eigenvalue counting
# ===================================================================

def c2_eigenvalue_counts(h_func, c2_op, n_occ: int, spinful: bool = False) -> dict:
    """Count C2 eigenvalue multiplicities at the four HSPs.

    Returns
    -------
    dict : keys are HSP names, values are dicts with '+' and '-' counts.
           Spinless: '+' = +1, '-' = -1.
           Spinful:  '+' = +i, '-' = -i.
    """
    hsp_coords = {
        "Gamma": (0.0, 0.0),
        "X": (np.pi, 0.0),
        "Y": (0.0, np.pi),
        "M": (np.pi, np.pi),
    }

    counts = {}
    for name, (kx, ky) in hsp_coords.items():
        H = h_func(kx, ky)
        eigvals, eigvecs = np.linalg.eigh(H)
        occ_vecs = eigvecs[:, :n_occ]

        c2_sub = occ_vecs.conj().T @ c2_op @ occ_vecs
        c2_eigs = np.linalg.eigvalsh(
            1j * c2_sub if spinful else c2_sub
        )

        if spinful:
            n_minus = int(np.sum(c2_eigs > 0))
            n_plus = n_occ - n_minus
        else:
            n_plus = int(np.sum(c2_eigs > 0))
            n_minus = n_occ - n_plus

        counts[name] = {"+": n_plus, "-": n_minus}

    return counts


# ===================================================================
# Hadamard inversion (shared logic)
# ===================================================================

_WYCKOFF_FORMULAS = {
    "1a": lambda G_p, G_m, X_m, Y_m, M_m: G_p - 0.5 * (-G_m + X_m + Y_m + M_m),
    "1b": lambda G_p, G_m, X_m, Y_m, M_m: 0.5 * (-G_m + X_m - Y_m + M_m),
    "1c": lambda G_p, G_m, X_m, Y_m, M_m: 0.5 * (-G_m - X_m + Y_m + M_m),
    "1d": lambda G_p, G_m, X_m, Y_m, M_m: 0.5 * (-G_m + X_m + Y_m - M_m),
}

_WYCKOFF_FORMULAS_SPINFUL = {
    "1a": lambda G_p, G_m, X_m, Y_m, M_m, Ch: -G_p + 0.5 * (-G_m + X_m + Y_m + M_m + Ch),
    "1d": lambda G_p, G_m, X_m, Y_m, M_m, Ch: 0.5 * (G_m - X_m - Y_m + M_m + Ch),
}


def _extract_counts(counts: dict):
    """Unpack eigenvalue counts into (G_p, G_m, X_m, Y_m, M_m)."""
    return (
        counts["Gamma"]["+"],
        counts["Gamma"]["-"],
        counts["X"]["-"],
        counts["Y"]["-"],
        counts["M"]["-"],
    )


# ===================================================================
# SpinlessInvariant
# ===================================================================

class SpinlessInvariant:
    """Real-space invariant nu_{1x} for spinless C2-symmetric crystals.

    Parameters
    ----------
    model : C2Model
        Must have ``spinful=False``.
    """

    def __init__(self, model: C2Model) -> None:
        if model.spinful:
            raise ValueError(
                "SpinlessInvariant requires spinful=False; "
                "use SpinfulInvariant or TRSInvariant instead."
            )
        self._model = model

    @cached_property
    def c2_counts(self) -> dict:
        """C2 eigenvalue multiplicities at the four HSPs."""
        return c2_eigenvalue_counts(
            self._model.h_func, self._model.c2_op,
            self._model.n_occ, spinful=False,
        )

    def nu(self, wyckoff: str = "1d") -> float:
        """Real-space invariant at the given Wyckoff position.

        Parameters
        ----------
        wyckoff : str
            One of '1a', '1b', '1c', '1d'.
        """
        if wyckoff not in _WYCKOFF_FORMULAS:
            raise ValueError(f"Unknown Wyckoff position: {wyckoff}")
        G_p, G_m, X_m, Y_m, M_m = _extract_counts(self.c2_counts)
        return _WYCKOFF_FORMULAS[wyckoff](G_p, G_m, X_m, Y_m, M_m)


# ===================================================================
# SpinfulInvariant
# ===================================================================

class SpinfulInvariant:
    """Real-space invariant nu_{1x} for spinful C2-symmetric crystals (no TRS).

    Includes the Chern-number correction alpha_{1/2} = 1/2.

    Parameters
    ----------
    model : C2Model
        Must have ``spinful=True`` and ``trs=False``.
    chern : int or None
        Pre-computed Chern number. If None, computed automatically.
    nk : int
        k-mesh for Chern number if not provided.
    """

    def __init__(
        self, model: C2Model, chern: int | None = None, nk: int = 50
    ) -> None:
        if not model.spinful:
            raise ValueError(
                "SpinfulInvariant requires spinful=True."
            )
        if model.trs:
            raise ValueError(
                "SpinfulInvariant is for trs=False; use TRSInvariant instead."
            )
        self._model = model
        self._chern_override = chern
        self._nk = nk

    @cached_property
    def c2_counts(self) -> dict:
        """C2 eigenvalue multiplicities at the four HSPs."""
        return c2_eigenvalue_counts(
            self._model.h_func, self._model.c2_op,
            self._model.n_occ, spinful=True,
        )

    @cached_property
    def chern_number(self) -> int:
        """Chern number (integer)."""
        if self._chern_override is not None:
            return self._chern_override
        raw = _chern_number(self._model.h_func, self._model.n_occ, nk=self._nk)
        return round(raw)

    def nu(self, wyckoff: str = "1d") -> float:
        """Real-space invariant at the given Wyckoff position.

        Parameters
        ----------
        wyckoff : str
            Currently '1a' and '1d' are implemented.
        """
        if wyckoff not in _WYCKOFF_FORMULAS_SPINFUL:
            raise ValueError(
                f"Wyckoff position {wyckoff} not yet implemented for spinful case. "
                f"Available: {list(_WYCKOFF_FORMULAS_SPINFUL.keys())}"
            )
        G_p, G_m, X_m, Y_m, M_m = _extract_counts(self.c2_counts)
        return _WYCKOFF_FORMULAS_SPINFUL[wyckoff](
            G_p, G_m, X_m, Y_m, M_m, self.chern_number
        )


# ===================================================================
# TRSInvariant
# ===================================================================

class TRSInvariant:
    """Partial real-space invariant nu^I_{1x} for spinful TRS systems.

    Uses Kramers sector decomposition via the C2*Theta gauge construction.

    **Partial Chern numbers (TRS).** Two related scalars are used:

    - **Partial Chern number** — $C_I = C_I^{\\rm bnd} + 2\\nu_{Z2}$,
      the end result combining the boundary Berry phase with the
      interior-boundary winding. Exposed as `partial_chern` and `C_I` in
      diagnostics. Not the same as the Fukui–Hatsugai–Suzuki Chern integer on
      the full Brillouin torus.
    - **Boundary partial Chern number** — $C_I^{\\rm bnd} = \\gamma_I / \\pi$,
      with $\\gamma_I$ the sector-I Berry phase sum on the EBZ boundary loop
      (constructed gauge). Exposed as `partial_chern_boundary` and `C_I_bnd`
      in diagnostics.

    **Gauge and mod 2.** Sector-I vs sector-II labeling is a convention; raw
    ``sector1_counts`` and ``partial_chern_boundary`` are not individually
    gauge-independent. The partial Wyckoff invariants ``nu`` combine these inputs
    with $\\nu_{Z2}$ in a way appropriate to $C_2$ + TRS real-space topology
    (mod $2$ / $\\mathbb Z_2$ bookkeeping). See ``docs/real-space-invariants.md``
    in the repository for discussion, including a qualitative doubled Kane–Mele
    example.

    Parameters
    ----------
    model : C2Model
        Must have ``spinful=True``, ``trs=True``, even ``n_occ``, and a
        ``trs_unitary`` matrix (unitary ``U`` in ``Θ = U K``).
    nk : int
        k-points per half-segment for the boundary gauge.
    nkx_factor : int
        kx refinement factor for the interior gauge.
    """

    def __init__(
        self, model: C2Model, nk: int = 60, nkx_factor: int = 10
    ) -> None:
        if not model.trs:
            raise ValueError("TRSInvariant requires trs=True.")
        self._model = model
        self._nk = nk
        self._nkx_factor = nkx_factor
        self._computed: dict | None = None

    def _compute(self) -> None:
        if self._computed is not None:
            return

        from .gauge.boundary import BoundaryGauge
        from .gauge.interior import InteriorGauge
        from .winding import WindingCalculator

        model = self._model
        nk = self._nk
        n_occ = model.n_occ
        n_half = n_occ // 2

        boundary = BoundaryGauge(model, nk)
        interior = InteriorGauge(model, nk, boundary, nkx_factor=self._nkx_factor)
        winding = WindingCalculator(boundary, interior, n_occ, model.c2_op)

        gamma_I = winding.sector1_berry_phase
        C_I_bnd = gamma_I / np.pi
        nu_z2 = winding.z2_winding
        C_I = C_I_bnd + 2 * nu_z2

        # C2 eigenvalue counts within sector I at each TRIM
        hsp_c2 = boundary.hsp_c2_matrices
        counts_sector1 = {}
        for name in ("Gamma", "X", "Y", "M"):
            eigs_s1 = np.diag(hsp_c2[name])[:n_half]
            n_m = int(np.sum(np.imag(eigs_s1) < 0))
            n_p = n_half - n_m
            counts_sector1[name] = {"+": n_p, "-": n_m}

        G_m = counts_sector1["Gamma"]["-"]
        X_m = counts_sector1["X"]["-"]
        Y_m = counts_sector1["Y"]["-"]
        M_m = counts_sector1["M"]["-"]
        G_p = counts_sector1["Gamma"]["+"]

        half_C = 0.5 * C_I
        nu_1a = (-G_p + 0.5 * (-G_m + X_m + Y_m + M_m)) + half_C
        nu_1b = 0.5 * (G_m - X_m + Y_m - M_m) + half_C
        nu_1c = 0.5 * (G_m + X_m - Y_m - M_m) + half_C
        nu_1d = 0.5 * (G_m - X_m - Y_m + M_m) + half_C

        self._computed = {
            "nu_1a":            nu_1a,
            "nu_1b":            nu_1b,
            "nu_1c":            nu_1c,
            "nu_1d":            nu_1d,
            "gamma_I":          gamma_I,
            "C_I":              C_I,
            "C_I_bnd":          C_I_bnd,
            "nu_z2":            nu_z2,
            "counts_sector1":   counts_sector1,
            "boundary":         boundary,
            "interior":         interior,
            "winding":          winding,
        }

    def nu(self, wyckoff: str = "1d") -> float:
        """Partial real-space invariant at the given Wyckoff position.

        Parameters
        ----------
        wyckoff : str
            One of '1a', '1b', '1c', '1d'.
        """
        self._compute()
        key = f"nu_{wyckoff}"
        if key not in self._computed:  # type: ignore[operator]
            raise ValueError(f"Unknown Wyckoff position: {wyckoff}")
        return self._computed[key]  # type: ignore[index]

    @property
    def partial_chern_boundary(self) -> float:
        """Boundary partial Chern number from the sector-I Berry phase.

        Returns $C_I^{\\rm bnd} = \\gamma_I / \\pi$ (same value as ``C_I_bnd``
        in ``diagnostics()``). Not the Fukui–Hatsugai–Suzuki Chern number on
        the full torus.
        """
        self._compute()
        return self._computed["C_I_bnd"]  # type: ignore[index]

    @property
    def partial_chern(self) -> float:
        """Partial Chern number $C_I = C_I^{\\rm bnd} + 2\\nu_{Z2}$.

        End-result scalar combining the sector-I boundary Berry phase with the
        interior-boundary $\\mathbb Z_2$ winding. Same value as ``C_I`` in
        ``diagnostics()``.
        """
        self._compute()
        return self._computed["C_I"]  # type: ignore[index]

    @property
    def z2_winding(self) -> int:
        """Z2 winding number from the interior-boundary mismatch."""
        self._compute()
        return self._computed["nu_z2"]  # type: ignore[index]

    @property
    def sector1_counts(self) -> dict:
        """C2 eigenvalue counts within sector I at each TRIM."""
        self._compute()
        return self._computed["counts_sector1"]  # type: ignore[index]

    def diagnostics(self) -> dict:
        """Full diagnostic dictionary including gauge objects."""
        self._compute()
        return dict(self._computed)  # type: ignore[arg-type]


# ===================================================================
# Factory
# ===================================================================

def make_invariant(
    model: C2Model, **kwargs
) -> SpinlessInvariant | SpinfulInvariant | TRSInvariant:
    """Create the appropriate invariant calculator for a C2Model.

    Dispatches based on ``model.spinful`` and ``model.trs``.

    Parameters
    ----------
    model : C2Model
        The Bloch model with C2 symmetry info.
    **kwargs
        Forwarded to the invariant class constructor (e.g. ``nk``,
        ``chern``, ``nkx_factor``).
    """
    if model.trs:
        return TRSInvariant(model, **kwargs)
    elif model.spinful:
        return SpinfulInvariant(model, **kwargs)
    else:
        return SpinlessInvariant(model, **kwargs)
