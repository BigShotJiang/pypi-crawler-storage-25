"""
Chern number and Berry curvature via Fukui-Hatsugai-Suzuki, plus SO(N)
branch-cut utilities for the Z2 winding computation.

Public API
----------
ChernCalculator
    Lazy-computing wrapper around the FHS Chern number and Berry curvature.
    Constructed from a :class:`~c2_invariants.model.BlochModel`.

principal_log, crossing_indicator
    SO(N) branch-cut utilities used by the winding module.
"""

from __future__ import annotations

from functools import cached_property

import numpy as np
from scipy.linalg import schur

from .model import BlochModel
from ._sort_real_schur import sort_real_schur


class ChernCalculator:
    """Fukui-Hatsugai-Suzuki Chern number and Berry curvature.

    Parameters
    ----------
    model : BlochModel
        Bloch Hamiltonian and band filling.
    nk : int
        Default k-mesh density (per direction) for the Chern number.
    """

    def __init__(self, model: BlochModel, nk: int = 50) -> None:
        self._model = model
        self._nk = nk

    @cached_property
    def chern_number(self) -> float:
        """Chern number (should be close to an integer)."""
        return _chern_number(
            self._model.h_func, self._model.n_occ, self._nk
        )

    def berry_curvature(
        self, kx_array: np.ndarray, ky_array: np.ndarray
    ) -> np.ndarray:
        """FHS plaquette Berry curvature on an arbitrary grid.

        Returns
        -------
        F : ndarray of shape ``(len(kx_array), len(ky_array))``
        """
        return _berry_curvature(
            self._model.h_func, self._model.n_occ, kx_array, ky_array
        )


# ===================================================================
# Standalone functions (used internally and by other modules)
# ===================================================================

def _chern_number(h_func, n_occ: int, nk: int = 50) -> float:
    """Compute the Chern number using the FHS lattice gauge method."""
    kx_vals = np.linspace(0, 2 * np.pi, nk, endpoint=False)
    ky_vals = np.linspace(0, 2 * np.pi, nk, endpoint=False)

    states = np.empty((nk, nk, h_func(0, 0).shape[0], n_occ), dtype=complex)
    for ix, kx in enumerate(kx_vals):
        for iy, ky in enumerate(ky_vals):
            eigvals, eigvecs = np.linalg.eigh(h_func(kx, ky))
            states[ix, iy] = eigvecs[:, :n_occ]

    total_phase = 0.0
    for ix in range(nk):
        ixp = (ix + 1) % nk
        for iy in range(nk):
            iyp = (iy + 1) % nk

            U1 = np.linalg.det(states[ix, iy].conj().T @ states[ixp, iy])
            U2 = np.linalg.det(states[ixp, iy].conj().T @ states[ixp, iyp])
            U3 = np.linalg.det(states[ixp, iyp].conj().T @ states[ix, iyp])
            U4 = np.linalg.det(states[ix, iyp].conj().T @ states[ix, iy])

            total_phase += np.imag(np.log(U1 * U2 * U3 * U4))

    return total_phase / (2 * np.pi)


def _berry_curvature(h_func, n_occ: int, kx_array, ky_array) -> np.ndarray:
    """FHS plaquette Berry curvature on an arbitrary grid."""
    nkx = len(kx_array)
    nky = len(ky_array)
    dkx = kx_array[1] - kx_array[0] if nkx > 1 else 1.0
    dky = ky_array[1] - ky_array[0] if nky > 1 else 1.0

    nbands = h_func(0, 0).shape[0]
    states = np.empty((nkx + 1, nky + 1, nbands, n_occ), dtype=complex)

    for ix in range(nkx + 1):
        kx = kx_array[0] + ix * dkx if ix < nkx else kx_array[0] + nkx * dkx
        for iy in range(nky + 1):
            ky = ky_array[0] + iy * dky if iy < nky else ky_array[0] + nky * dky
            _, vecs = np.linalg.eigh(h_func(kx, ky))
            states[ix, iy] = vecs[:, :n_occ]

    F = np.zeros((nkx, nky))
    for ix in range(nkx):
        for iy in range(nky):
            U1 = np.linalg.det(states[ix, iy].conj().T @ states[ix + 1, iy])
            U2 = np.linalg.det(states[ix + 1, iy].conj().T @ states[ix + 1, iy + 1])
            U3 = np.linalg.det(states[ix + 1, iy + 1].conj().T @ states[ix, iy + 1])
            U4 = np.linalg.det(states[ix, iy + 1].conj().T @ states[ix, iy])
            F[ix, iy] = np.imag(np.log(U1 * U2 * U3 * U4)) / (dkx * dky)

    return F


# ===================================================================
# SO(N) branch-cut utilities
# (Kooi, van Miert & Ortix, npj Quantum Materials 6, 1 (2021))
# ===================================================================

def principal_log(M: np.ndarray) -> np.ndarray:
    """Principal logarithm of a special orthogonal matrix (Eq. 14-15 of Kooi et al.)."""
    T, Z = schur(M, output="real")
    sort_real_schur(Z, T, 1.0, 0, inplace=True)
    Nf = len(M)
    X0 = np.zeros((Nf, Nf))
    for i in range(Nf // 2):
        u = Z[:, 2 * i : 2 * i + 1]
        v = Z[:, 2 * i + 1 : 2 * i + 2]
        x = u @ v.T - v @ u.T
        theta = np.arctan2(T[2 * i, 2 * i + 1], T[2 * i, 2 * i])
        X0 += theta * x.copy()
    return X0


def crossing_indicator(M1: np.ndarray, M2: np.ndarray) -> int:
    """Count branch-cut crossings of principal log between two nearby SO(N) matrices."""
    L1 = principal_log(M1)
    L2 = principal_log(M2)
    delta = L2 - L1
    k = np.linalg.norm(delta / (2 * np.pi), ord="fro") ** 2 / 2
    return round(k)
