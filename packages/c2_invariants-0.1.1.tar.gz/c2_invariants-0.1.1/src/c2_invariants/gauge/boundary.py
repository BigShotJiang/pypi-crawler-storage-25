"""
Smooth C2*TRS-symmetric boundary gauge on the effective Brillouin zone (EBZ).

Public API
----------
BoundaryGauge
    OOP wrapper that lazily builds the full EBZ boundary gauge.

u_p_c2theta
    Unitary part of ``P = C2 Θ`` with ``Θ = trs_unitary K``.

Free functions (used internally)
    _c2_eigsort, _build_upper, _build_lower, _build_full
"""

from __future__ import annotations

import numpy as np

from ..model import C2Model
from .p_symmetric import (
    sewing_matrix_p,
    kramers_sectors_to_p_real,
    p_real_to_kramers_sectors,
)


# ===================================================================
# Helpers
# ===================================================================

def u_p_c2theta(c2_op: np.ndarray, trs_unitary: np.ndarray) -> np.ndarray:
    """Unitary part ``U_P`` of ``P = C2 Θ`` with ``Θ = trs_unitary K``.

    Parameters
    ----------
    c2_op : ndarray, shape (N, N)
    trs_unitary : ndarray, shape (N, N)
        Unitary ``U`` in ``Θ = U K`` (complex conjugation ``K``).
    """
    trs_u = np.asarray(trs_unitary, dtype=complex)
    if trs_u.shape != c2_op.shape:
        raise ValueError(
            f"trs_unitary shape {trs_u.shape} does not match c2_op {c2_op.shape}"
        )
    return c2_op @ trs_u


def _c2_eigsort(occ, c2_op, h_full=None):
    """Sort occupied states by C2 eigenvalue.

    Sector I (first n_occ/2 columns): C2 = +i eigenstates.
    Sector II: C2 = -i.
    Within each sector, columns ordered by ascending energy if h_full given.
    """
    c2_sub = occ.conj().T @ c2_op @ occ
    ic2_eigvals, c2_eigvecs = np.linalg.eigh(1j * c2_sub)
    if h_full is not None:
        h_diag = np.real(np.diag(occ.conj().T @ h_full @ occ)).astype(float)
        h_expect = np.sum(
            np.abs(c2_eigvecs) ** 2 * h_diag[:, np.newaxis],
            axis=0,
        )
        sorted_idx = np.lexsort((h_expect, ic2_eigvals.astype(float)))
    else:
        sorted_idx = np.argsort(ic2_eigvals, kind="mergesort")
    c2_eigenvalues = -1j * ic2_eigvals[sorted_idx]
    return occ @ c2_eigvecs[:, sorted_idx], c2_eigenvalues


# ===================================================================
# Core builders (free functions)
# ===================================================================

def _build_upper(
    h_func,
    c2_op: np.ndarray,
    n_occ: int,
    nk: int,
    trs_unitary: np.ndarray,
) -> dict:
    """Sector-I SVD transport along Gamma->Y->M->X with Kramers-flip detection."""
    from scipy.linalg import logm as _sp_logm, expm as _sp_expm

    if n_occ % 2:
        raise ValueError("n_occ must be even (Kramers pairs).")
    n_half = n_occ // 2
    u_p = u_p_c2theta(c2_op, trs_unitary)

    HSP_NAMES = ["Gamma", "Y", "M", "X"]
    HSP_COORDS: dict[str, tuple[float, float]] = {
        "Gamma": (0.0, 0.0),
        "Y":     (0.0, np.pi),
        "M":     (np.pi, np.pi),
        "X":     (np.pi, 0.0),
    }

    hsp_anchors_kramers: dict[str, np.ndarray] = {}
    hsp_anchors_real:    dict[str, np.ndarray] = {}
    hsp_c2_matrices:     dict[str, np.ndarray] = {}

    for name in HSP_NAMES:
        kx, ky = HSP_COORDS[name]
        H = h_func(kx, ky)
        _, vecs = np.linalg.eigh(H)
        occ = vecs[:, :n_occ]
        sorted_occ, _ = _c2_eigsort(occ, c2_op, H)
        phi = sorted_occ[:, :n_half]
        chi = u_p @ np.conj(phi)
        V_K = np.concatenate([phi, chi], axis=1)
        V_R = kramers_sectors_to_p_real(V_K, n_half)
        hsp_anchors_kramers[name] = V_K
        hsp_anchors_real[name]    = V_R
        hsp_c2_matrices[name]     = V_K.conj().T @ c2_op @ V_K

    SEGMENTS = [
        ("Gamma", "Y", (0.0, 0.0),     (0.0, np.pi)),
        ("Y",     "M", (0.0, np.pi),   (np.pi, np.pi)),
        ("M",     "X", (np.pi, np.pi), (np.pi, 0.0)),
    ]

    all_states_kramers: list[np.ndarray] = []
    all_states_real:    list[np.ndarray] = []
    all_momenta:        list[tuple]       = []
    kramers_flips:      dict[str, bool]   = {}

    for start_name, end_name, k_start, k_end in SEGMENTS:
        seg_vr:  list[np.ndarray] = []
        seg_mom: list[tuple]       = []
        phi_prev = hsp_anchors_kramers[start_name][:, :n_half].copy()

        for i in range(nk):
            frac = i / nk
            kx = k_start[0] + frac * (k_end[0] - k_start[0])
            ky = k_start[1] + frac * (k_end[1] - k_start[1])

            if i == 0:
                phi_i = phi_prev.copy()
            else:
                H_k = h_func(kx, ky)
                _, vecs = np.linalg.eigh(H_k)
                occ = vecs[:, :n_occ]
                S = occ.conj().T @ phi_prev
                U_sv, _, Vh_sv = np.linalg.svd(S, full_matrices=False)
                phi_i = occ @ (U_sv @ Vh_sv)

            chi_i = u_p @ np.conj(phi_i)
            V_K_i = np.concatenate([phi_i, chi_i], axis=1)
            seg_vr.append(kramers_sectors_to_p_real(V_K_i, n_half))
            seg_mom.append((kx, ky))
            phi_prev = phi_i

        # Kramers flip detection
        R_raw = seg_vr[-1].conj().T @ hsp_anchors_real[end_name]
        R_real = np.real(R_raw)
        uu_f, _, vvt_f = np.linalg.svd(R_real, full_matrices=False)
        R_so = uu_f @ vvt_f
        if float(np.linalg.det(R_so)) < 0:
            new_vr = hsp_anchors_real[end_name].copy()
            new_vr[:, n_half] *= -1.0
            hsp_anchors_real[end_name]    = new_vr
            new_vk = p_real_to_kramers_sectors(new_vr, n_half)
            hsp_anchors_kramers[end_name] = new_vk
            hsp_c2_matrices[end_name]     = new_vk.conj().T @ c2_op @ new_vk
            kramers_flips[end_name]       = True

        # Endpoint correction
        R_ep = seg_vr[-1].conj().T @ hsp_anchors_real[end_name]
        R_ep_real = np.real(R_ep)
        uu_ep, _, vvt_ep = np.linalg.svd(R_ep_real, full_matrices=False)
        R_so_ep = uu_ep @ vvt_ep
        A_mat = np.real(_sp_logm(R_so_ep))
        A_mat = 0.5 * (A_mat - A_mat.T)
        ns = len(seg_vr)
        corrected = []
        for j in range(ns):
            f = j / (ns - 1) if ns > 1 else 0.0
            corrected.append(seg_vr[j] @ _sp_expm(f * A_mat))

        all_states_real.extend(corrected)
        all_momenta.extend(seg_mom)
        for V_R_corr in corrected:
            all_states_kramers.append(p_real_to_kramers_sectors(V_R_corr, n_half))

    all_states_kramers.append(hsp_anchors_kramers["X"])
    all_states_real.append(hsp_anchors_real["X"])
    all_momenta.append(HSP_COORDS["X"])

    # Diagnostics
    n_states   = len(all_states_kramers)
    I_nocc     = np.eye(n_occ, dtype=complex)
    sigma_x_I  = np.zeros((n_occ, n_occ), dtype=complex)
    sigma_x_I[:n_half, n_half:] = np.eye(n_half)
    sigma_x_I[n_half:, :n_half] = np.eye(n_half)

    sewing_err_kramers = np.empty(n_states)
    sewing_err_real    = np.empty(n_states)
    for j in range(n_states):
        M_K = sewing_matrix_p(all_states_kramers[j], u_p)
        sewing_err_kramers[j] = float(np.linalg.norm(M_K - sigma_x_I, ord="fro"))
        M_R = sewing_matrix_p(all_states_real[j], u_p)
        sewing_err_real[j] = float(np.linalg.norm(M_R - I_nocc, ord="fro"))

    link_fro = np.empty(n_states - 1)
    for j in range(n_states - 1):
        link_fro[j] = float(
            np.linalg.norm(
                all_states_real[j].conj().T @ all_states_real[j + 1] - I_nocc,
                ord="fro",
            )
        )

    return {
        "upper_states":        all_states_kramers,
        "upper_states_real":   all_states_real,
        "upper_momenta":       all_momenta,
        "hsp_anchors_kramers": hsp_anchors_kramers,
        "hsp_c2_matrices":     hsp_c2_matrices,
        "sewing_err_kramers":  sewing_err_kramers,
        "sewing_err_real":     sewing_err_real,
        "link_fro":            link_fro,
        "kramers_flips":       kramers_flips,
    }


def _build_lower(
    upper_result: dict,
    c2_op: np.ndarray,
    n_occ: int,
    nk: int,
    trs_unitary: np.ndarray,
) -> dict:
    """C2-fold the upper gauge to the lower half-boundary."""
    upper_states = upper_result["upper_states"]
    hsp_c2       = upper_result["hsp_c2_matrices"]

    n_half = n_occ // 2
    u_p    = u_p_c2theta(c2_op, trs_unitary)

    eig: dict[str, np.ndarray] = {}
    for name in ("Gamma", "Y", "M", "X"):
        eig[name] = np.diag(hsp_c2[name])

    def _fold_column(upper_VK: np.ndarray, phase: np.ndarray) -> np.ndarray:
        result = np.empty_like(upper_VK)
        for a in range(n_occ):
            result[:, a] = phase[a] * (c2_op @ upper_VK[:, a])
        return result

    # Edge A: kx=pi, ky from 0 to -pi (X -> M lower)
    edge_a: list[np.ndarray] = []
    mom_a:  list[tuple]       = []
    for j in range(nk + 1):
        ky_j      = -j * np.pi / nk
        upper_idx = 3 * nk - j
        phase     = -np.exp(ky_j * (eig["M"] - eig["X"]) / 2) * eig["X"]
        edge_a.append(_fold_column(upper_states[upper_idx], phase))
        mom_a.append((np.pi, ky_j))

    # Edge B: ky=-pi, kx from pi to 0 (M lower -> Y lower)
    edge_b: list[np.ndarray] = []
    mom_b:  list[tuple]       = []
    for j in range(nk + 1):
        upper_idx = 2 * nk - j
        kx_j      = np.pi * (nk - j) / nk
        edge_b.append(upper_states[upper_idx])
        mom_b.append((kx_j, -np.pi))

    # Edge C: kx=0, ky from -pi to 0 (Y lower -> Gamma)
    edge_c: list[np.ndarray] = []
    mom_c:  list[tuple]       = []
    for j in range(nk + 1):
        ky_j      = -(nk - j) * np.pi / nk
        upper_idx = nk - j
        phase     = -np.exp(ky_j * (eig["Y"] - eig["Gamma"]) / 2) * eig["Gamma"]
        edge_c.append(_fold_column(upper_states[upper_idx], phase))
        mom_c.append((0.0, ky_j))

    all_states = edge_a + edge_b[1:] + edge_c[1:]
    all_momenta = mom_a + mom_b[1:] + mom_c[1:]

    # Diagnostics
    n_states  = len(all_states)
    I_nocc    = np.eye(n_occ, dtype=complex)
    sigma_x_I = np.zeros((n_occ, n_occ), dtype=complex)
    sigma_x_I[:n_half, n_half:] = np.eye(n_half)
    sigma_x_I[n_half:, :n_half] = np.eye(n_half)

    sewing_err_kramers = np.empty(n_states)
    for j in range(n_states):
        M_K = sewing_matrix_p(all_states[j], u_p)
        sewing_err_kramers[j] = float(np.linalg.norm(M_K - sigma_x_I, ord="fro"))

    link_fro = np.empty(n_states - 1)
    for j in range(n_states - 1):
        link_fro[j] = float(
            np.linalg.norm(
                all_states[j].conj().T @ all_states[j + 1] - I_nocc,
                ord="fro",
            )
        )

    return {
        "lower_states":       all_states,
        "lower_momenta":      all_momenta,
        "link_fro":           link_fro,
        "sewing_err_kramers": sewing_err_kramers,
    }


def _build_full(
    h_func,
    c2_op: np.ndarray,
    n_occ: int,
    nk: int,
    trs_unitary: np.ndarray,
) -> dict:
    """Build the complete gauge around the full EBZ loop."""
    upper = _build_upper(h_func, c2_op, n_occ, nk, trs_unitary)
    lower = _build_lower(upper, c2_op, n_occ, nk, trs_unitary)

    full_states  = upper["upper_states"] + lower["lower_states"][1:]
    full_momenta = upper["upper_momenta"] + lower["lower_momenta"][1:]

    n_states = len(full_states)
    n_occ_   = n_occ
    I_nocc   = np.eye(n_occ_, dtype=complex)
    u_p      = u_p_c2theta(c2_op, trs_unitary)
    n_half_  = n_occ_ // 2
    sigma_x_I = np.zeros((n_occ_, n_occ_), dtype=complex)
    sigma_x_I[:n_half_, n_half_:] = np.eye(n_half_)
    sigma_x_I[n_half_:, :n_half_] = np.eye(n_half_)

    sewing_err = np.empty(n_states)
    for j in range(n_states):
        M_K = sewing_matrix_p(full_states[j], u_p)
        sewing_err[j] = float(np.linalg.norm(M_K - sigma_x_I, ord="fro"))

    link_fro = np.empty(n_states - 1)
    for j in range(n_states - 1):
        link_fro[j] = float(
            np.linalg.norm(
                full_states[j].conj().T @ full_states[j + 1] - I_nocc,
                ord="fro",
            )
        )

    return {
        "full_states":        full_states,
        "full_momenta":       full_momenta,
        "link_fro":           link_fro,
        "sewing_err_kramers": sewing_err,
        "upper":              upper,
        "lower":              lower,
    }


# ===================================================================
# BoundaryGauge class
# ===================================================================

class BoundaryGauge:
    """Smooth C2*TRS-symmetric boundary gauge on the EBZ loop.

    Parameters
    ----------
    model : C2Model
        Must have ``spinful=True``, ``trs=True``, even ``n_occ``, and
        ``trs_unitary`` set.
    nk : int
        Number of k-points per boundary segment.
    """

    def __init__(self, model: C2Model, nk: int = 60) -> None:
        self._model = model
        self._nk = nk
        self._result: dict | None = None

    def _build(self) -> None:
        if self._result is not None:
            return
        tu = self._model.trs_unitary
        assert tu is not None
        self._result = _build_full(
            self._model.h_func, self._model.c2_op,
            self._model.n_occ, self._nk, tu,
        )

    @property
    def result(self) -> dict:
        """Raw result dict from the full boundary gauge builder."""
        self._build()
        return self._result  # type: ignore[return-value]

    @property
    def full_states(self) -> list:
        """Kramers frames at all 6*nk+1 k-points around the EBZ loop."""
        return self.result["full_states"]

    @property
    def upper(self) -> dict:
        """Upper half-boundary result (Gamma->Y->M->X)."""
        return self.result["upper"]

    @property
    def lower(self) -> dict:
        """Lower half-boundary result (X->M'->Y'->Gamma)."""
        return self.result["lower"]

    @property
    def hsp_c2_matrices(self) -> dict:
        """C2 matrix in the anchor Kramers basis at each HSP."""
        return self.upper["hsp_c2_matrices"]

    @property
    def link_fro(self) -> np.ndarray:
        """Smoothness per link around the full loop."""
        return self.result["link_fro"]

    @property
    def sewing_err(self) -> np.ndarray:
        """Sewing error at each k-point."""
        return self.result["sewing_err_kramers"]
