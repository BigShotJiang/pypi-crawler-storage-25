"""
c2_invariants.gauge -- smooth C2*TRS-symmetric gauge construction.

Sub-modules
-----------
boundary
    BoundaryGauge and free-function builders for the EBZ boundary loop.
interior
    InteriorGauge for the half-BZ interior mesh.
p_symmetric
    PSymmetricGauge class and low-level P = C2*Theta primitives.
"""

from .boundary import BoundaryGauge, u_p_c2theta
from .interior import InteriorGauge
from .p_symmetric import (
    PSymmetricGauge,
    kramers_sectors_to_p_real,
    p_real_to_kramers_sectors,
    sewing_matrix_p,
)

__all__ = [
    "BoundaryGauge",
    "InteriorGauge",
    "PSymmetricGauge",
    "u_p_c2theta",
    "kramers_sectors_to_p_real",
    "p_real_to_kramers_sectors",
    "sewing_matrix_p",
]
