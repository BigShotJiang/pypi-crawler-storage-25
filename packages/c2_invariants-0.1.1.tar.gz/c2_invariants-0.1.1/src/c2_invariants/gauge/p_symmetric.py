"""
Symmetry-constrained smooth gauge for P = C2 * Theta (anti-unitary, P^2 = +1).

Implements the projection + real-SVD parallel transport recipe (Kooi-style
symmetric gauge). The unitary part U_P of P = U_P K satisfies
U_P U_P^* = I and U_P = U_P^T (so P^2 = +1 on single-particle space).

Public API
----------
PSymmetricGauge
    High-level class for building P-symmetric gauges on a k-mesh.

Free functions
    Low-level primitives used by BoundaryGauge, InteriorGauge, and
    WindingCalculator.
"""

from __future__ import annotations

import numpy as np

from ..model import C2Model, standard_trs_unitary_spin_pairs


# ===================================================================
# Free-function primitives
# ===================================================================

def p_partner(psi: np.ndarray, u_p: np.ndarray) -> np.ndarray:
    """P|psi> with P = U_P K: returns U_P |psi*>."""
    return u_p @ np.conj(psi)


def p_invariant_from_state(
    psi: np.ndarray,
    u_p: np.ndarray,
    *,
    projector: np.ndarray | None = None,
) -> np.ndarray:
    """
    Build |psi> + P|psi> and i|psi> + P(i|psi>) (optionally projected),
    keep the larger-norm candidate, then normalize.
    """
    def _projected_sum(trial: np.ndarray) -> np.ndarray:
        w = trial + p_partner(trial, u_p)
        if projector is not None:
            w = projector @ w
        return w

    w_sym = _projected_sum(psi)
    w_alt = _projected_sum(1j * psi)
    n_sym = float(np.linalg.norm(w_sym))
    n_alt = float(np.linalg.norm(w_alt))
    if n_sym < 1e-14 and n_alt < 1e-14:
        return np.zeros_like(w_sym)
    w = w_alt if n_alt > n_sym else w_sym
    n = max(n_alt, n_sym)
    return w / n


def gram_schmidt_p_invariant(
    vectors: list[np.ndarray],
) -> list[np.ndarray]:
    """Orthonormalize P-invariant vectors (overlaps are real)."""
    out: list[np.ndarray] = []
    for v in vectors:
        w = v.copy()
        for u in out:
            c = np.vdot(u, w)
            w -= c * u
        nw = np.linalg.norm(w)
        if nw > 1e-12:
            out.append(w / nw)
    return out


def occupied_subspace(
    h: np.ndarray,
    n_occ: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Return (eigenvalues, eigenvectors columns) for lowest n_occ bands."""
    evals, evecs = np.linalg.eigh(h)
    return evals[:n_occ], evecs[:, :n_occ]


def p_invariant_basis_at_k(
    h: np.ndarray,
    n_occ: int,
    u_p: np.ndarray,
    *,
    rng: np.random.Generator | None = None,
) -> np.ndarray:
    """Build n_occ orthonormal P-invariant vectors spanning the occupied subspace."""
    rng = rng or np.random.default_rng()
    _, v_occ = occupied_subspace(h, n_occ)
    proj = v_occ @ v_occ.conj().T

    trials = [v_occ[:, j] for j in range(n_occ)]
    for _ in range(n_occ):
        z = rng.standard_normal(h.shape[0]) + 1j * rng.standard_normal(h.shape[0])
        z = proj @ z
        z /= np.linalg.norm(z) + 1e-30
        trials.append(z)

    raw: list[np.ndarray] = []
    for t in trials:
        w = p_invariant_from_state(t, u_p, projector=proj)
        if np.linalg.norm(w) > 1e-12:
            raw.append(w)
        if len(raw) >= n_occ * 4:
            break

    basis = gram_schmidt_p_invariant(raw)
    if len(basis) < n_occ:
        raise RuntimeError(
            f"Could not build {n_occ} P-invariant vectors (got {len(basis)})."
        )

    u_mat = np.column_stack(basis[:n_occ])
    q, _ = np.linalg.qr(u_mat, mode="reduced")
    return q


def _kramers_to_p_real_W(n_half: int) -> np.ndarray:
    """
    Bridge matrix W: kramers_states @ W = real_states.

    W = (1/sqrt(2)) [[ I_n, -i I_n ], [ I_n, +i I_n ]].
    """
    i_n = np.eye(n_half, dtype=complex)
    inv_sq2 = 1.0 / np.sqrt(2.0)
    return inv_sq2 * np.block([[i_n, -1j * i_n], [i_n, 1j * i_n]])


def kramers_sectors_to_p_real(v_kramers: np.ndarray, n_half: int) -> np.ndarray:
    """V_kramers @ W."""
    return v_kramers @ _kramers_to_p_real_W(n_half)


def p_real_to_kramers_sectors(u_p_real: np.ndarray, n_half: int) -> np.ndarray:
    """Inverse: V_kramers = U_p_real @ W^H."""
    w = _kramers_to_p_real_W(n_half)
    return u_p_real @ w.conj().T


def real_parallel_transport_step(
    u_prev: np.ndarray,
    v_trial: np.ndarray,
    *,
    kramers_column_order: bool = False,
) -> np.ndarray:
    """One discrete transport step between orthonormal occupied frames."""
    if u_prev.shape != v_trial.shape:
        raise ValueError("u_prev and v_trial must have the same shape")
    n_occ = u_prev.shape[1]

    if kramers_column_order:
        n_half = n_occ // 2
        if n_occ != 2 * n_half:
            raise ValueError("kramers_column_order requires even n_occ")
        w_mat = _kramers_to_p_real_W(n_half)
        real_from = u_prev @ w_mat
        real_trial = v_trial @ w_mat
        s = real_from.conj().T @ real_trial
        s_r = np.asarray(np.real(s), dtype=float)
        s_r = 0.5 * (s_r + s_r.T)
        imag_noise = float(np.linalg.norm(np.imag(s)))
        if imag_noise > 1e-6:
            s_r = np.asarray(np.real((s + s.conj().T) / 2.0), dtype=float)
            s_r = 0.5 * (s_r + s_r.T)
        u_svd, _, vt = np.linalg.svd(s_r, full_matrices=False)
        o_mat = u_svd @ vt
        real_next = real_trial @ o_mat.T
        return real_next @ w_mat.conj().T

    s = u_prev.conj().T @ v_trial
    s_r = np.asarray(np.real(s), dtype=float)
    imag_noise = np.linalg.norm(np.imag(s))
    if imag_noise > 1e-8:
        s_r = np.asarray(np.real((s + s.conj().T) / 2.0), dtype=float)
    w, _, vt = np.linalg.svd(s_r, full_matrices=False)
    o_mat = w @ vt
    return v_trial @ o_mat.T


def sewing_matrix_p(
    states: np.ndarray,
    u_p: np.ndarray,
) -> np.ndarray:
    """M_ij = <psi_i|P|psi_j> = psi_i^H U_P psi_j*."""
    return states.conj().T @ (u_p @ np.conj(states))


def sectors_sigma_x_gauge(
    u_basis: np.ndarray,
    n_half: int,
    u_p: np.ndarray,
) -> np.ndarray:
    """
    From P-invariant orthonormal u_1..u_{2n}, build
    phi_a = (u_a + i u_{n+a})/sqrt(2), chi_a = P|phi_a>,
    return N x (2n) matrix [phi_1..phi_n, chi_1..chi_n].
    """
    n_occ = 2 * n_half
    if u_basis.shape[1] != n_occ:
        raise ValueError("u_basis must have 2*n_half columns")
    phi = np.zeros((u_basis.shape[0], n_half), dtype=complex)
    chi = np.zeros((u_basis.shape[0], n_half), dtype=complex)
    for a in range(n_half):
        ua = u_basis[:, a]
        ub = u_basis[:, n_half + a]
        phi[:, a] = (ua + 1j * ub) / np.sqrt(2.0)
        chi[:, a] = p_partner(phi[:, a], u_p)
    return np.concatenate([phi, chi], axis=1)


def verify_sigma_x_sewing(
    psi_sectors: np.ndarray,
    u_p: np.ndarray,
    n_half: int,
    *,
    atol: float = 1e-8,
) -> tuple[bool, float, np.ndarray]:
    """Return (ok, Frobenius error, M)."""
    n_occ = 2 * n_half
    m = sewing_matrix_p(psi_sectors, u_p)
    target = np.zeros((n_occ, n_occ), dtype=complex)
    target[:n_half, n_half:] = np.eye(n_half)
    target[n_half:, :n_half] = np.eye(n_half)
    err = min(
        np.linalg.norm(m - target),
        np.linalg.norm(m + target),
        np.linalg.norm(m - 1j * target),
        np.linalg.norm(m + 1j * target),
    )
    return err < atol, err, m


# ===================================================================
# PSymmetricGauge class
# ===================================================================

class PSymmetricGauge:
    """Build a P-symmetric gauge on a Cartesian k-mesh.

    Parameters
    ----------
    model : C2Model
        Must have ``spinful=True`` and even ``n_occ``.
    kx_grid, ky_grid : ndarray
        1-D arrays of kx and ky values.
    """

    def __init__(
        self,
        model: C2Model,
        kx_grid: np.ndarray,
        ky_grid: np.ndarray,
        *,
        rng: np.random.Generator | None = None,
    ) -> None:
        self._model = model
        self._kx_grid = kx_grid
        self._ky_grid = ky_grid
        self._rng = rng
        self._states: np.ndarray | None = None
        self._sectors: np.ndarray | None = None

    def _build(self) -> None:
        if self._states is not None:
            return

        from .boundary import u_p_c2theta

        model = self._model
        n_occ = model.n_occ
        n_half = n_occ // 2
        trs_u = (
            model.trs_unitary
            if model.trs
            else standard_trs_unitary_spin_pairs(model.n_bands)
        )
        u_p = u_p_c2theta(model.c2_op, trs_u)
        rng = self._rng or np.random.default_rng()

        kx_grid = self._kx_grid
        ky_grid = self._ky_grid
        nkx, nky = len(kx_grid), len(ky_grid)
        n_dim = u_p.shape[0]
        states = np.empty((nkx, nky, n_dim, n_occ), dtype=complex)
        sectors = np.empty((nkx, nky, n_dim, n_occ), dtype=complex)

        kx0, ky0 = float(kx_grid[0]), float(ky_grid[0])
        h00 = model.h_func(kx0, ky0)
        u = p_invariant_basis_at_k(h00, n_occ, u_p, rng=rng)
        states[0, 0, :, :] = u

        for ix in range(1, nkx):
            h = model.h_func(float(kx_grid[ix]), ky0)
            v_try = p_invariant_basis_at_k(h, n_occ, u_p, rng=rng)
            u = real_parallel_transport_step(u, v_try)
            states[ix, 0, :, :] = u

        for iy in range(1, nky):
            ky = float(ky_grid[iy])
            h0y = model.h_func(kx0, ky)
            v_try = p_invariant_basis_at_k(h0y, n_occ, u_p, rng=rng)
            u = real_parallel_transport_step(states[0, iy - 1, :, :], v_try)
            states[0, iy, :, :] = u
            for ix in range(1, nkx):
                h = model.h_func(float(kx_grid[ix]), ky)
                v_try = p_invariant_basis_at_k(h, n_occ, u_p, rng=rng)
                u = real_parallel_transport_step(states[ix - 1, iy, :, :], v_try)
                states[ix, iy, :, :] = u

        for iy in range(nky):
            for ix in range(nkx):
                sectors[ix, iy, :, :] = sectors_sigma_x_gauge(
                    states[ix, iy, :, :], n_half, u_p
                )

        self._states = states
        self._sectors = sectors

    @property
    def states(self) -> np.ndarray:
        """P-invariant states on the mesh, shape ``(nkx, nky, N, n_occ)``."""
        self._build()
        return self._states  # type: ignore[return-value]

    @property
    def sectors(self) -> np.ndarray:
        """Kramers-sector states with sigma_x sewing, shape ``(nkx, nky, N, n_occ)``."""
        self._build()
        return self._sectors  # type: ignore[return-value]
