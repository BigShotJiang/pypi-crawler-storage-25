"""
Interior C2*TRS-symmetric gauge on the half Brillouin zone [0,pi] x [-pi,pi].

Public API
----------
InteriorGauge
    OOP wrapper that lazily builds the interior gauge, seeded from a
    BoundaryGauge.
"""

from __future__ import annotations

import numpy as np

from ..model import C2Model
from .boundary import u_p_c2theta, BoundaryGauge
from .p_symmetric import sewing_matrix_p


def _svd_transport_sector1(
    phi_prev: np.ndarray,
    H_k: np.ndarray,
    n_occ: int,
) -> np.ndarray:
    """One SVD Procrustes step for sector I."""
    _, vecs = np.linalg.eigh(H_k)
    occ = vecs[:, :n_occ]
    S = occ.conj().T @ phi_prev
    U_sv, _, Vh_sv = np.linalg.svd(S, full_matrices=False)
    return occ @ (U_sv @ Vh_sv)


def _build_interior(
    h_func,
    c2_op: np.ndarray,
    n_occ: int,
    nk: int,
    boundary_result: dict,
    trs_unitary: np.ndarray,
    nkx_factor: int = 10,
) -> dict:
    """Build the interior gauge on [0,pi] x [-pi,pi]."""
    if n_occ % 2:
        raise ValueError("n_occ must be even (Kramers pairs).")
    n_half = n_occ // 2
    u_p = u_p_c2theta(c2_op, trs_unitary)
    N = c2_op.shape[0]

    nkx = nk * nkx_factor
    kx_grid = np.linspace(0.0, np.pi, nkx + 1)
    ky_grid = np.linspace(-np.pi, np.pi, 2 * nk + 1)

    states = np.empty((nkx + 1, 2 * nk + 1, N, n_occ), dtype=complex)

    # Pass 1: equator row (ky = -pi) by kx transport
    lower_states = boundary_result["lower"]["lower_states"]
    states[0, 0] = lower_states[2 * nk]
    phi_prev_kx = states[0, 0, :, :n_half].copy()
    for ix in range(1, nkx + 1):
        phi_new = _svd_transport_sector1(
            phi_prev_kx, h_func(float(kx_grid[ix]), -np.pi), n_occ
        )
        chi_new = u_p @ np.conj(phi_new)
        states[ix, 0] = np.concatenate([phi_new, chi_new], axis=1)
        phi_prev_kx = phi_new

    # Pass 2: column-by-column ky transport
    for ix in range(nkx + 1):
        kx = float(kx_grid[ix])
        phi_prev = states[ix, 0, :, :n_half].copy()
        for iy in range(1, 2 * nk + 1):
            phi_i = _svd_transport_sector1(
                phi_prev, h_func(kx, float(ky_grid[iy])), n_occ
            )
            chi_i = u_p @ np.conj(phi_i)
            states[ix, iy] = np.concatenate([phi_i, chi_i], axis=1)
            phi_prev = phi_i

    # Diagnostics
    I_nocc = np.eye(n_occ, dtype=complex)
    sigma_x_I = np.zeros((n_occ, n_occ), dtype=complex)
    sigma_x_I[:n_half, n_half:] = np.eye(n_half)
    sigma_x_I[n_half:, :n_half] = np.eye(n_half)

    sewing_err = np.empty((nkx + 1, 2 * nk + 1))
    for ix in range(nkx + 1):
        for iy in range(2 * nk + 1):
            sewing_err[ix, iy] = float(
                np.linalg.norm(
                    sewing_matrix_p(states[ix, iy], u_p) - sigma_x_I, "fro"
                )
            )

    link_fro_kx = np.empty((nkx, 2 * nk + 1))
    for ix in range(nkx):
        for iy in range(2 * nk + 1):
            link_fro_kx[ix, iy] = float(
                np.linalg.norm(
                    states[ix, iy].conj().T @ states[ix + 1, iy] - I_nocc, "fro"
                )
            )

    link_fro_ky = np.empty((nkx + 1, 2 * nk))
    for ix in range(nkx + 1):
        for iy in range(2 * nk):
            link_fro_ky[ix, iy] = float(
                np.linalg.norm(
                    states[ix, iy].conj().T @ states[ix, iy + 1] - I_nocc, "fro"
                )
            )

    return {
        "states":      states,
        "kx_grid":     kx_grid,
        "ky_grid":     ky_grid,
        "link_fro_kx": link_fro_kx,
        "link_fro_ky": link_fro_ky,
        "sewing_err":  sewing_err,
    }


class InteriorGauge:
    """Smooth C2*TRS-symmetric gauge on [0,pi] x [-pi,pi].

    Parameters
    ----------
    model : C2Model
        Must have ``spinful=True``, ``trs=True``, even ``n_occ``, and
        ``trs_unitary`` set.
    nk : int
        k-points per half-segment (must match the BoundaryGauge).
    boundary : BoundaryGauge
        The boundary gauge this interior gauge is seeded from.
    nkx_factor : int
        kx refinement factor (default 10).
    """

    def __init__(
        self,
        model: C2Model,
        nk: int,
        boundary: BoundaryGauge,
        nkx_factor: int = 10,
    ) -> None:
        self._model = model
        self._nk = nk
        self._boundary = boundary
        self._nkx_factor = nkx_factor
        self._result: dict | None = None

    def _build(self) -> None:
        if self._result is not None:
            return
        tu = self._model.trs_unitary
        assert tu is not None
        self._result = _build_interior(
            self._model.h_func, self._model.c2_op,
            self._model.n_occ, self._nk,
            self._boundary.result,
            tu,
            nkx_factor=self._nkx_factor,
        )

    @property
    def result(self) -> dict:
        """Raw result dict from the interior gauge builder."""
        self._build()
        return self._result  # type: ignore[return-value]

    @property
    def states(self) -> np.ndarray:
        """Kramers frames, shape ``(nkx+1, 2*nk+1, N, n_occ)``."""
        return self.result["states"]

    @property
    def kx_grid(self) -> np.ndarray:
        return self.result["kx_grid"]

    @property
    def ky_grid(self) -> np.ndarray:
        return self.result["ky_grid"]

    @property
    def sewing_err(self) -> np.ndarray:
        return self.result["sewing_err"]
