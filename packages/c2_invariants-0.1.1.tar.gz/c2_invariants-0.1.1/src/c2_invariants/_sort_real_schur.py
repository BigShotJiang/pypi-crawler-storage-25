"""
Sorting Real Schur Forms.

Python version of the Matlab code by Jan Brandts (2002).
Source: https://gist.github.com/fabian-paul/14679b43ed27aa25fdb8a2e8f021bad5

Reference:
  J.H. Brandts, "Matlab code for sorted real Schur forms",
  Numerical Linear Algebra with Applications 9(3):249-261 (2002)
"""

import numpy as np


def sort_real_schur(Q, R, z, b, inplace=False):
    eps = np.finfo(R.dtype).eps
    if not np.all(np.abs(np.tril(R, -2)) <= 100 * eps):
        raise ValueError("R is not block-triangular")
    if not inplace:
        Q = Q.copy()
        R = R.copy()

    r = np.where(np.abs(np.diag(R, -1)) > 100 * eps)[0]
    s = [i for i in range(R.shape[0] + 1) if i not in r + 1]
    p = [None] * (len(s) - 1)

    for k in range(len(s) - 1):
        sk = s[k]
        if s[k + 1] - sk == 2:
            Q, R = _normalize(Q, R, slice(sk, s[k + 1]), inplace=True)
            p[k] = R[sk, sk] + np.lib.scimath.sqrt(
                R[sk + 1, sk] * R[sk, sk + 1]
            )
        else:
            p[k] = R[s[k], s[k]]

    ap = []
    for k in _swaplist(p, s, z, b):
        v = list(range(s[k], s[k + 1]))
        w = list(range(s[k + 1], s[k + 2]))
        vw = v + w
        nrA = np.linalg.norm(R[np.ix_(vw, vw)], ord=np.inf)
        Q, R = _swap(Q, R, v, w, inplace=True)
        p[k], p[k + 1] = p[k + 1], p[k]
        s[k + 1] = s[k] + s[k + 2] - s[k + 1]
        v = list(range(s[k], s[k + 1]))
        w = list(range(s[k + 1], s[k + 2]))
        if len(v) == 2:
            Q, R = _normalize(Q, R, v, inplace=True)
        if len(w) == 2:
            Q, R = _normalize(Q, R, w, inplace=True)
        ap.append(np.linalg.norm(R[np.ix_(w, v)], ord=np.inf) / (10 * eps * nrA))

    R = R - np.tril(R, -2)
    for k in range(1, len(s) - 1):
        R[s[k], s[k] - 1] = 0

    return Q, R, ap


def _normalize(U, S, v, inplace=False):
    Q = _rot(S[v, :][:, v])
    if not inplace:
        S = S.copy()
        U = U.copy()
    S[:, v] = np.dot(S[:, v], Q)
    S[v, :] = np.dot(Q.T, S[v, :])
    U[:, v] = np.dot(U[:, v], Q)
    return U, S


def _rot(X):
    c = 1.0
    s = 0.0
    if X[0, 0] != X[1, 1]:
        tau = (X[0, 1] + X[1, 0]) / (X[0, 0] - X[1, 1])
        off = (tau**2 + 1) ** 0.5
        v = [tau - off, tau + off]
        w = np.argmin(np.abs(v))
        c = 1.0 / (1.0 + v[w] ** 2) ** 0.5
        s = v[w] * c
    return np.array([[c, -s], [s, c]], dtype=X.dtype)


def _swaplist(p, s, z, b):
    n = len(p)
    p = list(p)
    k = 0
    v = []
    srtd = 0
    q = list(np.diff(s))
    fini = False
    while not fini:
        _, j = _select(p[k:n], z)
        p[k : n + 1] = [p[j + k]] + p[k:n]
        del p[j + k + 1]
        q[k : n + 1] = [q[j + k]] + q[k:n]
        del q[j + k + 1]
        v = v + list(range(k, j + k))[::-1]
        srtd = srtd + q[k]
        k += 1
        fini = k >= n - 1 or k == -b or srtd == b or (srtd == b + 1 and b != 0)
    return v


def _select(p, z):
    if np.isinf(z):
        pos = np.argmax(np.abs(p))
        return -abs(p[pos]), pos
    else:
        y = np.real(z) + np.abs(np.imag(z)) * 1j
        delta = np.abs(np.array(p) - y)
        pos = np.argmin(delta)
        return delta[pos], pos


def _swap(U, S, v, w, inplace=False):
    p, q = S[np.ix_(v, w)].shape
    Ip = np.eye(p)
    Iq = np.eye(q)
    r = np.concatenate([S[v, w[j]] for j in range(q)])
    K = np.kron(Iq, S[np.ix_(v, v)]) - np.kron(S[np.ix_(w, w)].T, Ip)
    L, H, P, Q_ = _lu_complpiv(K, overwrite=True)
    e = np.min(np.abs(np.diag(H)))
    sigp = np.arange(p * q)
    for k in range(p * q - 1):
        sigp[[k, P[k]]] = sigp[[P[k], k]].copy()
    r = e * r[sigp]
    x = np.linalg.solve(H, np.linalg.solve(L, r))
    sigq = np.arange(p * q)
    for k in range(p * q - 1):
        sigq[[k, Q_[k]]] = sigq[[Q_[k], k]].copy()
    x[sigq] = x.copy()
    X = np.vstack([x[j * p : (j + 1) * p] for j in range(q)]).T
    Q_qr, _ = np.linalg.qr(np.vstack((-X, e * Iq)), mode="complete")
    vw = list(v) + list(w)
    if not inplace:
        S = S.copy()
        U = U.copy()
    S[:, vw] = np.dot(S[:, vw], Q_qr)
    S[vw, :] = np.dot(Q_qr.T, S[vw, :])
    U[:, vw] = np.dot(U[:, vw], Q_qr)
    return U, S


def _lu_complpiv(A, overwrite=False):
    if not overwrite:
        A = A.copy()
    n = A.shape[0]
    P = np.zeros(n - 1, dtype=int)
    Q = np.zeros(n - 1, dtype=int)
    for k in range(n - 1):
        Ak = A[k:n, k:n]
        rw, cl = np.unravel_index(np.argmax(np.abs(Ak), axis=None), Ak.shape)
        rw += k
        cl += k
        A[[k, rw], :] = A[[rw, k], :].copy()
        A[:, [k, cl]] = A[:, [cl, k]].copy()
        P[k] = rw
        Q[k] = cl
        if A[k, k] != 0:
            rs = slice(k + 1, n)
            A[rs, k] = A[rs, k] / A[k, k]
            A[rs, :][:, rs] = A[rs, :][:, rs] - A[rs, k][:, np.newaxis] * A[k, rs]
    U = np.tril(A.T).T
    L = np.tril(A, -1) + np.eye(n)
    return L, U, P, Q
