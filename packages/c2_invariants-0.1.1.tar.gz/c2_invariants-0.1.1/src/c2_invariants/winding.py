"""
Step-4 invariant computations for spinful TRS systems.

Public API
----------
WindingCalculator
    Sector-I Berry phase, boundary partial Chern number (C_I_bnd = gamma_I / pi),
    and Z2 winding number. The full partial Chern number
    C_I = C_I_bnd + 2 * nu_z2 is assembled in ``TRSInvariant``.
"""

from __future__ import annotations

import numpy as np

from .gauge.p_symmetric import kramers_sectors_to_p_real
from .gauge.boundary import BoundaryGauge
from .gauge.interior import InteriorGauge
from .chern import crossing_indicator


class WindingCalculator:
    """Sector-I Berry phase, boundary partial Chern number, and Z2 winding.

    The sector-I quantity $C_I^{\\rm bnd} = \\gamma_I / \\pi$ is the
    **boundary partial Chern number** (boundary / constructed gauge), not the
    full-BZ Fukui–Hatsugai–Suzuki Chern integer. The full partial Chern number
    $C_I = C_I^{\\rm bnd} + 2\\nu_{Z2}$ is assembled in ``TRSInvariant``.

    Parameters
    ----------
    boundary : BoundaryGauge
        The boundary gauge (full EBZ loop).
    interior : InteriorGauge
        The interior gauge (half-BZ mesh).
    n_occ : int
        Number of occupied bands (must be even).
    c2_op : ndarray (N, N)
        C2 rotation operator.
    """

    def __init__(
        self,
        boundary: BoundaryGauge,
        interior: InteriorGauge,
        n_occ: int,
        c2_op: np.ndarray,
    ) -> None:
        self._boundary = boundary
        self._interior = interior
        self._n_occ = n_occ
        self._c2_op = c2_op
        self._berry_phase: float | None = None
        self._z2: int | None = None

    @property
    def sector1_berry_phase(self) -> float:
        """Unwrapped Berry phase $\\gamma_I$ of sector I along the boundary loop.

        Together with `partial_chern_boundary` ($\\gamma_I / \\pi$), this fixes
        the boundary contribution to the TRS partial Chern numbers in
        `TRSInvariant`.
        """
        if self._berry_phase is None:
            self._berry_phase = _sector1_berry_phase(
                self._boundary.result, self._n_occ
            )
        return self._berry_phase

    @property
    def partial_chern_boundary(self) -> float:
        """Boundary partial Chern number $C_I^{\\rm bnd} = \\gamma_I / \\pi$.

        Same as ``sector1_berry_phase / np.pi``. Not the full-BZ FHS Chern
        number. The full partial Chern $C_I = C_I^{\\rm bnd} + 2\\nu_{Z2}$ is
        assembled in ``TRSInvariant``.
        """
        return self.sector1_berry_phase / np.pi

    @property
    def z2_winding(self) -> int:
        """Z2 winding number from full-boundary interior-boundary overlap."""
        if self._z2 is None:
            self._z2 = _z2_winding_interior_boundary(
                self._boundary.result,
                self._interior.result,
                self._n_occ,
                self._c2_op,
            )
        return self._z2

    def boundary_overlap_report(self) -> dict:
        """Diagnostic: per-link crossing indicators and SO(2) angle along the full boundary."""
        return _boundary_overlap_report(
            self._boundary.result,
            self._interior.result,
            self._n_occ,
        )


# ===================================================================
# Free-function implementations
# ===================================================================

def _sector1_berry_phase(boundary_result: dict, n_occ: int) -> float:
    """Full (unwrapped) Berry phase of sector I along the closed half-BZ boundary."""
    n_half = n_occ // 2
    full_states = boundary_result["full_states"]
    n_links = len(full_states) - 1
    gamma = 0.0
    for j in range(n_links):
        phi_j   = full_states[j][:, :n_half]
        phi_jp1 = full_states[j + 1][:, :n_half]
        overlap = phi_j.conj().T @ phi_jp1
        gamma  += np.angle(np.linalg.det(overlap))
    return float(gamma)


def _assemble_interior_boundary(
    interior_result: dict,
) -> list[np.ndarray]:
    """Collect interior-gauge states along the full EBZ boundary (6*nk+1 points).

    The ordering matches ``full_states`` from the boundary gauge:
    Gamma -> Y -> M -> X -> M_lower -> Y_lower -> Gamma.

    Each boundary point sits on one of the four edges of the interior grid
    ``[0, pi] x [-pi, pi]``, so the matching interior state is looked up by
    index.
    """
    states = interior_result["states"]   # (nkx+1, 2*nk+1, N, n_occ)
    ky_grid = interior_result["ky_grid"]
    kx_grid = interior_result["kx_grid"]
    nkx = len(kx_grid) - 1
    nk = len(ky_grid) // 2
    nkx_factor = nkx // nk

    out: list[np.ndarray] = []

    # Upper half: Gamma(0,0) -> Y(0,pi) -> M(pi,pi) -> X(pi,0)
    # Segment Gamma->Y: kx=0, ky = i*pi/nk  (i=0..nk-1)
    for i in range(nk):
        out.append(states[0, nk + i])
    # Segment Y->M: ky=pi, kx = i*pi/nk  (i=0..nk-1, offset from Y)
    for i in range(nk):
        out.append(states[i * nkx_factor, 2 * nk])
    # Segment M->X: kx=pi, ky = pi - i*pi/nk  (i=0..nk-1)
    for i in range(nk):
        out.append(states[nkx, 2 * nk - i])
    # X endpoint: kx=pi, ky=0
    out.append(states[nkx, nk])

    # Lower half: X(pi,0) -> M_lower(pi,-pi) -> Y_lower(0,-pi) -> Gamma(0,0)
    # Edge A (X->M_lower): kx=pi, ky = -j*pi/nk  (j=1..nk)
    for j in range(1, nk + 1):
        out.append(states[nkx, nk - j])
    # Edge B (M_lower->Y_lower): ky=-pi, kx = (nk-j)*pi/nk  (j=1..nk)
    for j in range(1, nk + 1):
        out.append(states[(nk - j) * nkx_factor, 0])
    # Edge C (Y_lower->Gamma): kx=0, ky = -(nk-j)*pi/nk  (j=1..nk)
    for j in range(1, nk + 1):
        out.append(states[0, j])

    return out


def _compute_R_list(
    bnd_states: list[np.ndarray],
    int_states: list[np.ndarray],
    n_occ: int,
) -> list[np.ndarray]:
    """Overlap matrices R in SO(n_occ) between boundary and interior frames."""
    n_half = n_occ // 2
    R_list = []
    for V_bnd, V_int in zip(bnd_states, int_states):
        V_bnd_R = kramers_sectors_to_p_real(V_bnd, n_half)
        V_int_R = kramers_sectors_to_p_real(V_int, n_half)
        R = np.real(V_bnd_R.conj().T @ V_int_R)
        if np.linalg.det(R) < 0:
            R[:, -1] *= -1
        R_list.append(R)
    return R_list


def _z2_winding_interior_boundary(
    boundary_result: dict,
    interior_result: dict,
    n_occ: int,
    c2_op: np.ndarray,
) -> int:
    """Z2 winding number along the full EBZ boundary loop."""
    full_bnd = boundary_result["full_states"]
    full_int = _assemble_interior_boundary(interior_result)
    R_list = _compute_R_list(full_bnd, full_int, n_occ)

    nu = 0
    for i in range(len(R_list) - 1):
        nu += crossing_indicator(R_list[i], R_list[i + 1])
    return int(nu % 2)


def _boundary_overlap_report(
    boundary_result: dict,
    interior_result: dict,
    n_occ: int,
) -> dict:
    """Diagnostic: per-link crossing indicators and SO(2) angle along the full boundary."""
    full_bnd = boundary_result["full_states"]
    full_int = _assemble_interior_boundary(interior_result)
    R_list = _compute_R_list(full_bnd, full_int, n_occ)

    edge_crossing = np.array(
        [crossing_indicator(R_list[i], R_list[i + 1]) for i in range(len(R_list) - 1)],
        dtype=int,
    )
    nu_z2 = int(edge_crossing.sum() % 2)

    theta = None
    if n_occ == 2:
        theta = np.array([np.arctan2(R[1, 0], R[0, 0]) for R in R_list])

    arc = np.linspace(0, 1, len(R_list))

    return {
        "arc":           arc,
        "R_list":        R_list,
        "theta":         theta,
        "edge_crossing": edge_crossing,
        "nu_z2":         nu_z2,
    }
