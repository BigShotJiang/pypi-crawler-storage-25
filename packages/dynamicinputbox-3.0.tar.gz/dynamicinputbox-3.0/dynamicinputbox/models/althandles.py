"""
Dataclass definition for alternative widget handles.

This module defines the widget references used to access and manage a built
alternative selection field in the dialog UI.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from dataclasses import dataclass
from tkinter import StringVar
from tkinter.ttk import Combobox, Label


@dataclass
class AltHandles:
    """ Widget handles for a built alternative selection field

    Attributes:
        label (Label): Label widget describing the alternative field
        combobox (Combobox): Combobox widget used for selecting a value
        var (StringVar): Tk variable storing the current selected value
    """

    label: Label
    combobox: Combobox
    var: StringVar
