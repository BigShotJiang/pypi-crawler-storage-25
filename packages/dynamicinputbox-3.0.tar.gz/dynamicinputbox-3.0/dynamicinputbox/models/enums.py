"""
Shared style helpers used across the library UI.

This module currently provides cached font definitions used when rendering
dialog titles, regular text, and preset placeholder text.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from tkinter.font import Font


class Fonts:
    """ Lazily created shared font styles for dialog widgets """

    _title: Font | None = None
    _ordinary: Font | None = None
    _preset: Font | None = None


    @classmethod
    def title( cls ) -> Font:
        """ Return the shared font used for field and section titles

        Returns:
            Font: Bold title font
        """

        if cls._title is None:
            cls._title = Font( family = 'Calibri', size = 14, weight = 'bold' )

        return cls._title


    @classmethod
    def ordinary( cls ) -> Font:
        """ Return the shared font used for regular dialog text

        Returns:
            Font: Standard body-text font
        """

        if cls._ordinary is None:
            cls._ordinary = Font( family = 'Calibri', size = 12, weight = 'normal' )

        return cls._ordinary


    @classmethod
    def preset( cls ) -> Font:
        """ Return the shared font used for preset placeholder text

        Returns:
            Font: Italic placeholder-text font.
        """

        if cls._preset is None:
            cls._preset = Font( family = 'Calibri', size = 12, slant = 'italic' )

        return cls._preset
