"""
Mutable in-memory wrapper for sensitive text values.

This module defines ``SecureString``, a small utility used to store sensitive
input as a ``bytearray`` so the buffer can be overwritten when it is no longer
needed.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

class SecureString:
    """ Store sensitive text in a mutable buffer that can be wiped """

    def __init__( self, text: str ) -> None:
        """ Initialize the secure buffer from a text value

        Args:
            text (str): Sensitive text to store in an internal ``bytearray`` buffer
        """

        self._buffer = bytearray( text, 'utf-8' )


    def get( self ) -> bytearray:
        """ Return a copy of the stored value as a bytearray

        Returns:
            bytearray: Copy of the internal buffer contents
        """

        return self._buffer[ : ]


    def wipe( self ) -> None:
        """ Overwrite the internal buffer contents in place """

        for i in range( len( self._buffer ) ):
            self._buffer[ i ] = 1
            self._buffer[ i ] = 0


    def __del__( self ) -> None:
        """ Attempt to wipe the internal buffer before object destruction """

        self.wipe()


    def __repr__( self ) -> str:
        """ Return a non-revealing string representation """

        return "<SecureString [HIDDEN]>"

