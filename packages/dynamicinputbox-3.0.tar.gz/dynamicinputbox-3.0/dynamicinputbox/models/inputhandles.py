"""
Dataclass definition for input widget handles.

This module defines the widget references and state used to access and manage
a built text input field in the dialog UI.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from dataclasses import dataclass
from tkinter import StringVar
from tkinter.ttk import Entry, Label


@dataclass
class InputHandles:
    """ Widget handles and metadata for a built input field

    Attributes:
        label (Label): Label widget describing the input field
        widget (Entry): Entry widget used for text input
        var (StringVar): Tk variable storing the current input value
        is_text (bool): Indicates that this handle represents a text-entry field
        show (str): Optional masking character used for hidden input
        is_first (bool): Whether this is the first input field in the dialog
    """

    label: Label
    widget: Entry
    var: StringVar
    is_text: bool
    show: str = ''
    is_first: bool = False
