"""
Dataclass definition for collected dialog UI handles.

This module defines the container used to store references to the widgets and
shared state created when building the dialog interface.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from dataclasses import dataclass
from tkinter import StringVar, Tk, Toplevel
from tkinter.ttk import Button, Frame, Widget

from .althandles import AltHandles
from .inputhandles import InputHandles


@dataclass
class UIHandles:
    """ Collected widget handles and shared state for a built dialog

    Attributes:
        window (Tk | Toplevel): Top-level dialog window
        clicked_var (StringVar): Tk variable holding the final clicked button
            label
        container (Frame | None): Main container frame for the dialog content
        message_widget (Widget | None): Widget or frame holding the dialog
            message area
        input_widgets (dict[str, InputHandles] | None): Mapping of input names to
            their widget handles
        alternative_widgets (dict[str, AltHandles] | None): Mapping of
            alternative labels to their widget handles
        buttons (dict[str, Button] | None): Mapping of button labels to their
            button widgets
    """

    window: Tk | Toplevel
    clicked_var: StringVar

    container: Frame | None = None

    message_widget: Widget | None = None

    input_widgets: dict[ str, InputHandles ] | None = None
    alternative_widgets: dict[ str, AltHandles ] | None = None
    buttons: dict[ str, Button ] | None = None
