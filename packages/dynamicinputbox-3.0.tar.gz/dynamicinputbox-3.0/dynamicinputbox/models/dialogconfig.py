"""
Dataclass definition for dialog UI configuration.

This module defines the normalized configuration object used when constructing
the dialog window and its content.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from dataclasses import dataclass
from tkinter import Tk, Toplevel

from .AlternativeSpec import AlternativeSpec
from .InputSpec import InputSpec

@dataclass
class DialogConfig:
    """ Normalized configuration for building a dialog window

    Attributes:
        title (str): Window title shown in the dialog title bar
        message (str | None): Optional message displayed above the dialog content
        input_specs (list[InputSpec]): Normalized text-input field definitions
        alt_specs (list[AlternativeSpec]): Normalized alternative field definitions
        button_labels (list[str]): Labels for the dialog buttons, in display order
        default_button (str | None): Label of the button treated as the default
            action
        cancel_button (str | None): Label of the button treated as the cancel
            action
        message_wraplength (int | None): Preferred wrap width for the message
            area, in pixels
        max_width_ratio (float | None): Maximum fraction of the screen width that
            the dialog content may occupy
        min_width_px (int | None): Minimum dialog content width, in pixels
        max_width_px (int | None): Optional absolute maximum dialog content width,
            in pixels
        padding_px (int | None): Base padding value used when laying out dialog
            content
        resizable (bool | None): Whether the dialog window should be resizable
        topmost (bool | None): Whether the dialog window should stay above other
            windows
        parent (Tk | Toplevel | None): Optional parent window for transient
            behavior and modal ownership
    """

    title: str
    message: str | None

    input_specs: list[ InputSpec ]
    alt_specs: list[ AlternativeSpec ]
    button_labels: list[ str ]

    default_button: str | None
    cancel_button: str | None

    message_wraplength: int | None
    max_width_ratio: float | None
    min_width_px: int | None
    max_width_px: int | None
    padding_px: int | None
    resizable: bool | None
    topmost: bool | None

    parent: Tk | Toplevel | None
