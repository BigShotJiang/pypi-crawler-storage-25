"""
Type definitions for dialog result values.

This module defines the supported result shapes returned by the dialog API,
including both dictionary-based and tuple-based forms.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from typing import NotRequired, TypeAlias, TypedDict


class ResultDict( TypedDict ):
    """ Typed dictionary representation of a dialog result

    Attributes:
        button (str): Label of the button that closed the dialog
        inputs (dict[str, str | bytearray]): Optional collected input values
            Secure inputs may be returned as ``bytearray`` values
        alternatives (dict[str, str]): Optional collected alternative selections
    """

    button: str
    inputs: NotRequired[ dict[ str, str | bytearray ] ]
    alternatives: NotRequired[ dict[ str, str ] ]


"""Tuple-based representation of a dialog result.

The tuple elements are ordered as ``(inputs, alternatives, button)``.
"""
ResultTuple: TypeAlias = tuple[
    dict[ str, str | bytearray ] | None,
    dict[ str, str ],
    str,
]

"""Union of all supported dialog result representations."""
Result = ResultDict | ResultTuple