"""
Dataclass definition for a normalized text input field.

This module defines the internal model used to represent a text input field
after user input has been validated and normalized.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from dataclasses import dataclass

@dataclass
class InputSpec:
    """ Normalized definition of a text input field

    Attributes:
        name (str): Explicit or generated name used to identify the input in the
            returned result
        label (str | None): Display label shown next to the input widget
        default (str | None): Initial text shown in the input field
        show (str | None): Optional masking character used for hidden input
        preset (str | None): Optional placeholder-style text shown until the user
            starts typing
    """

    name: str
    label: str | None
    default: str | None = ''
    show: str | None = None
    preset: str | None = None
