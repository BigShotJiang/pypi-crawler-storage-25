"""
Typed dictionary definition for text input configuration.

This module defines the dictionary shape accepted by the public API when
describing a text input field for the dialog.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from typing import NotRequired, TypedDict


class InputDict( TypedDict ):
    """ Typed dictionary describing a text input field

    Attributes:
        name (str): Optional explicit name used to identify the input in the
            returned result. If omitted, a generated name is assigned
        label (str): Display label shown next to the input widget
        default (str): Optional initial text shown in the input field
        show (str): Optional masking character used for hidden input, such as
            passwords
        preset (str): Optional placeholder-style text shown until the user starts
            typing
    """

    name: NotRequired[ str ]
    label: str
    default: NotRequired[ str ]
    show: NotRequired[ str ]
    preset: NotRequired[ str ]
