"""
Dataclass definition for a dialog button.

This module defines the internal model used to describe a button shown in the
dialog button area.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from dataclasses import dataclass

@dataclass
class ButtonSpec:
    """ Normalized definition of a dialog button

    Attributes:
        label (str): Text displayed on the button
    """

    label: str
