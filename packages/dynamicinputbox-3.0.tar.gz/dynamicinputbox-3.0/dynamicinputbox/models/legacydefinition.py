"""
Dataclass definition for legacy input configuration.

This module defines the compatibility model used to translate deprecated
single-input arguments into the modern ``InputSpec`` representation.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from dataclasses import dataclass

from .InputSpec import InputSpec


@dataclass
class LegacyDefinition:
    """ Legacy single-input configuration used for backward compatibility

    Attributes:
        input (bool | None): Whether the legacy API requested an input field
        default (str | None): Initial text for the legacy input field
        label (str | None): Display label for the legacy input field
        show (str | None): Optional masking character for hidden input
    """

    input: bool | None
    default: str | None
    label: str | None
    show: str | None


    def normalize_to_modern( self ) -> InputSpec:
        """ Convert the legacy input definition into a modern ``InputSpec``

        If a legacy label is provided, it is also used as the generated input name
        Otherwise, the fallback name ``"Input"`` is used

        Returns:
            InputSpec: Normalized input definition derived from the legacy settings
        """

        if self.label:
            name = str( self.label )
        else:
            name = 'Input'

        return InputSpec( name = name, label = self.label, default = self.default, show = self.show, preset = '' )
