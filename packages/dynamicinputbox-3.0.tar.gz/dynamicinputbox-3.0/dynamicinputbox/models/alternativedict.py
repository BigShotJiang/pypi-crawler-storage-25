"""
Typed dictionary definition for alternative selector configuration.

This module defines the dictionary shape accepted by the public API when
describing an alternative field for the dialog.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from typing import TypedDict


class AlternativeDict( TypedDict ):
    """ Typed dictionary describing an alternative selection field

    Attributes:
        label (str): Display label shown next to the alternative widget
        options (list[str] | None): Selectable values offered by the widget
        default (str | None): Initially selected value
    """

    label: str
    options: list[ str ] | None
    default: str | None
