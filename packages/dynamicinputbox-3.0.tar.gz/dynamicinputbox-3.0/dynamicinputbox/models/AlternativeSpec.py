"""
Dataclass definition for a normalized alternative field.

This module defines the internal model used to represent an alternative
selection field after user input has been validated and normalized.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from dataclasses import dataclass, field


@dataclass
class AlternativeSpec:
    """ Normalized definition of an alternative selection field

    Attributes:
        label (str): Display label shown next to the alternative widget
        options (list[str]): Selectable values offered by the widget
        default (str | None): Initially selected value
    """

    label: str
    options: list[ str ] = field( default_factory = list )
    default: str | None = None

