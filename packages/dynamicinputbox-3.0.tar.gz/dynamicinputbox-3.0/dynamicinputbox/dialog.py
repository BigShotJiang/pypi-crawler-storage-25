"""
Main public dialog API for the ``dynamicinputbox`` package.

This module defines ``DynamicInputBox``, the primary class used to configure,
display, and retrieve results from a dynamic Tkinter-based dialog.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from tkinter import Tk, Toplevel

from .models.AlternativeSpec import AlternativeSpec
from .models.InputSpec import InputSpec
from .models.SecureString import SecureString
from .models.alternativedict import AlternativeDict
from .models.dialogconfig import DialogConfig
from .models.inputdict import InputDict
from .models.legacydefinition import LegacyDefinition
from .models.resulttypes import Result, ResultDict, ResultTuple
from .models.uihandles import UIHandles
from .ui.alternatives import read_alternatives
from .ui.inputs import read_inputs
from .ui.window import build_dialog_ui, run_dialog


class DynamicInputBox:
    """ Configurable dialog for collecting text input and alternative selections """

    def __init__( self, *, title: str = "DynamicInputBox", message: str | None = None,
        # Modern API
        inputs: list[ InputDict ] | None = None, alternatives: list[ AlternativeDict ] | None = None,

        # Buttons
        buttons: list[ str ] =  [ 'OK' ], default_button: str | None = None, cancel_button: str | None = None,

        # Behavior
        dictionary: bool = False, wipe_after_get: bool = False, topmost: bool = False, resizable: bool = False, parent: Tk | Toplevel | None = None,

        # Sizing policy
        message_wraplength: int | None = None, max_width_ratio: float = 0.8, min_width_px: int = 320, max_width_px: int | None = None, padding_px: int = 10,

        # Legacy API (deprecated)
        input: bool | None = None, input_default: str | None = None, input_label: str | None = None, input_show: str | None = None,
    ) -> None:
        """ Initialize a new dialog configuration

        The dialog may include an optional message, one or more text input fields,
        optional alternative selection fields, and a customizable button row.
        Deprecated legacy single-input arguments are still supported for backward
        compatibility.

        Args:
            title (str): Window title shown in the dialog title bar
            message (str | None): Optional message displayed above the dialog content
            inputs (list[InputDict] | None): Modern input field definitions
            alternatives (list[AlternativeDict] | None): Alternative field
                definitions
            buttons (list[str]): Button labels shown in the dialog
            default_button (str | None): Preferred default action button
            cancel_button (str | None): Preferred cancel action button
            dictionary (bool): Default result format used by ``get()``
            wipe_after_get (bool): Whether secure values should be wiped after they
                are retrieved
            topmost (bool): Whether the dialog should stay above other windows
            resizable (bool): Whether the dialog window should be resizable
            parent (Tk | Toplevel | None): Optional parent window
            message_wraplength (int | None): Preferred wrap width for the message
                area, in pixels
            max_width_ratio (float): Maximum fraction of screen width that the dialog
                may occupy
            min_width_px (int): Minimum dialog width in pixels
            max_width_px (int | None): Optional absolute maximum dialog width in
                pixels
            padding_px (int): Base padding value used for layout
            input (bool | None): Deprecated legacy flag for enabling a single input
            input_default (str | None): Deprecated default value for the legacy input
            input_label (str | None): Deprecated label for the legacy input
            input_show (str | None): Deprecated masking character for the legacy
                input
        """

        if inputs is None and input:
            normalized_inputs = self._normalize_legacy_input(
                input = input,
                input_default = input_default,
                input_label = input_label,
                input_show = input_show,
            ) or []
        else:
            input_dicts: list[ InputDict ] = [ InputDict( **x ) if isinstance( x, dict ) else x for x in inputs or [] ]
            normalized_inputs: list[ InputSpec ] = self._parse_inputs( inputs = input_dicts )

        alt_dicts: list[ AlternativeDict ] = [ AlternativeDict( **a ) if isinstance( a, dict ) else a for a in alternatives or []  ]
        normalized_alternatives: list[ AlternativeSpec ] = self._parse_alternatives( alts = alt_dicts )

        default_btn_label: str
        if isinstance( buttons, list ) and len( buttons ) > 0:
            default_btn_label = buttons[ 0 ]
        else:
            default_btn_label = default_button or 'OK'

        self.dialog_config = DialogConfig(
            title = title,
            message = message,
            input_specs = normalized_inputs,
            alt_specs = normalized_alternatives,
            button_labels = buttons,
            default_button = default_btn_label,
            cancel_button = cancel_button,
            message_wraplength = message_wraplength,
            max_width_ratio = max_width_ratio,
            min_width_px = min_width_px,
            max_width_px = max_width_px,
            padding_px = padding_px,
            resizable = resizable,
            topmost = topmost,
            parent = parent
        )
        self._title: str = title
        self._message: str | None = message

        # API
        self._inputs: list[ InputDict ] | None = inputs
        self._alternatives: list[ AlternativeDict ] | None = alternatives

        self._buttons: list[ str ] = buttons if buttons else [ 'OK' ]
        self._default_button: str | None = default_button
        self._cancel_button: str | None = cancel_button

        # Behavior
        self._dictionary: bool = dictionary
        self._wipe_after_get: bool = wipe_after_get
        self._topmost: bool = topmost
        self._resizable: bool = resizable
        self._parent: Tk | Toplevel | None = parent

        # Policy
        self._message_wraplength: int | None = message_wraplength
        self._max_width_ratio: float = max_width_ratio
        self._min_width_px: int = min_width_px
        self._max_width_px: int | None = max_width_px
        self._padding_px: int = padding_px

        # Legacy definition
        self._legacy_input: bool | None = input
        self._legacy_input_default: str | None =input_default
        self._legacy_input_label: str | None = input_label
        self._legacy_input_show: str | None = input_show

        self._shown: bool = False


    def _apply_secure_policy( self, inputs_raw: dict[ str, str ], input_specs: list[ InputSpec ] ) -> dict[ str, str | SecureString ]:
        """ Convert masked input values into ``SecureString`` instances

        Any input whose normalized specification defines a ``show`` character is
        treated as sensitive and wrapped in ``SecureString``. Other input values are
        kept as plain strings.

        Args:
            inputs_raw (dict[str, str]): Collected plain-text input values
            input_specs (list[InputSpec]): Normalized input definitions used to decide
                which fields are sensitive

        Returns:
            dict[str, str | SecureString]: Input values after applying the secure
            storage policy
        """

        secure_names: set[ str ] = {
            spec.name
            for spec in input_specs
            if spec.show
        }

        normalized: dict[ str, str | SecureString ] = {}

        for name, value in inputs_raw.items():
            if name in secure_names:
                normalized[ name ] = SecureString( value )
            else:
                normalized[ name ] = value

        return normalized


    def _format_result( self, inputs_out: dict, alternatives_out: dict, clicked_button: str, dictionary: bool ) -> Result:
        """ Return the dialog result in dictionary or tuple form

        Args:
            inputs_out (dict[str, str | bytearray]): Collected input values prepared
                for return
            alternatives_out (dict[str, str]): Collected alternative selections
            clicked_button (str): Label of the button that closed the dialog
            dictionary (bool): Whether to return dictionary form instead of tuple
                form

        Returns:
            Result: Dialog result in the configured representation
        """

        if dictionary:
            result: ResultDict = { 'button': clicked_button }

            if inputs_out:
                result[ 'inputs' ] = inputs_out

            if alternatives_out:
                result[ 'alternatives' ] = alternatives_out

            return result

        return ( inputs_out if inputs_out else None, alternatives_out, clicked_button )


    def _normalize_legacy_input( self, input: bool | None, input_default: str | None, input_label: str | None, input_show: str | None ) -> list[ InputSpec ] | None:
        """ Convert deprecated legacy input arguments into modern input definitions

        Args:
            input (bool | None): Whether the legacy API requested an input field
            input_default (str | None): Default text for the legacy input field
            input_label (str | None): Display label for the legacy input field
            input_show (str | None): Optional masking character for hidden input

        Returns:
            list[InputSpec] | None: Modern normalized input definitions derived from
            the legacy arguments
        """

        self._legacy_definition = LegacyDefinition( input = input, default = input_default, label = input_label, show = input_show )

        return [ self._legacy_definition.normalize_to_modern() ]


    def _parse_alternatives( self, alts: list[ AlternativeDict ] | None ) -> list[ AlternativeSpec ]:
        """ Convert public alternative dictionaries into normalized specifications

        Args:
            alts (list[AlternativeDict] | None): Alternative field definitions
                supplied by the caller

        Returns:
            list[AlternativeSpec]: Normalized alternative specifications

        Raises:
            ValueError: If an alternative definition does not provide ``options``
        """

        if not alts:

            return []

        transformed: list[ AlternativeSpec ] = []

        for alt in alts:
            if alt[ 'options' ] is None:

                raise ValueError( f'Alternative configuration with no options, label \'{ alt[ 'label' ] }\'' )

            transformed.append( AlternativeSpec( label = alt[ 'label' ], options = alt[ 'options' ], default = alt[ 'default' ] ) )

        return transformed


    def _parse_inputs( self, inputs: list[ InputDict ] | None ) -> list[ InputSpec ]:
        """ Convert public input dictionaries into normalized specifications

        Inputs without an explicit name are assigned generated names such as
        ``"Input1"``.

        Args:
            inputs (list[InputDict] | None): Input field definitions supplied by the
                caller

        Returns:
            list[InputSpec]: Normalized input specifications
        """

        if not inputs:

            return []

        parsed_inputs: list[ InputSpec ] = []

        unnamed_input_index = 1

        for input in inputs:
            if input.get( 'name', None ) is None:
                input[ 'name' ] = f'Input{ unnamed_input_index }'
                unnamed_input_index += 1

            input_def = InputSpec( **input )

            parsed_inputs.append( input_def  )

        return parsed_inputs


    def _run_dialog_and_collect( self ) -> tuple[ dict[ str, str ], dict[ str, str ], str ]:
        """ Build the dialog UI, run it, and collect the raw result values

        Returns:
            tuple[dict[str, str], dict[str, str], str]: Collected input values,
            collected alternative values, and the clicked button label
        """

        handles: UIHandles = build_dialog_ui( config = self.dialog_config )
        clicked: str = run_dialog( handles )

        inputs_raw: dict[ str, str ] = (
            read_inputs( handles.input_widgets )
            if handles.input_widgets
            else {}
        )
        alts_raw: dict[ str,  str ] = (
            read_alternatives( handles.alternative_widgets )
            if handles.alternative_widgets
            else {}
        )

        return inputs_raw, alts_raw, clicked


    def get( self, *, dictionary: bool | None = None ) -> ResultDict | ResultTuple:
        """ Return the dialog result after the dialog has been shown

        Sensitive input values are returned as ``bytearray`` objects. If
        ``wipe_after_get`` is enabled, secure internal buffers are overwritten after
        their values have been retrieved.

        Args:
            dictionary (bool | None): Overrides the instance default result format
                If ``True``, returns dictionary form. Otherwise, returns tuple form

        Returns:
            ResultDict | ResultTuple: Dialog result in dictionary or tuple form

        Raises:
            RuntimeError: If the dialog has not been shown yet
        """

        if not self._shown:
            raise RuntimeError( 'Dialog has not been shown yet.' )

        if dictionary is None:
            dictionary = self._dictionary

        inputs_out: dict[ str, str | bytearray ] = {}

        for name, value in self._inputs_processed.items():

            if isinstance( value, SecureString ):
                buf: bytearray = value.get()
                inputs_out[ name ] = buf

                if self._wipe_after_get:
                    value.wipe()
                    self._inputs_processed[ name ] = SecureString( '' )

            else:
                inputs_out[ name ] = value

        return self._format_result(
            inputs_out = inputs_out,
            alternatives_out = self._alts_raw,
            clicked_button = self._clicked_button,
            dictionary = bool( dictionary ),
        )


    def show( self ) -> 'DynamicInputBox':
        """Build, display, and block on the dialog until it is closed.

        Returns:
            DynamicInputBox: The current dialog instance

        Raises:
            RuntimeError: If the dialog has already been shown
        """

        if self._shown:
            raise RuntimeError( 'Dialog has already been shown.' )

        inputs_raw: dict[ str, str ]
        alts_raw: dict[ str, str ]
        clicked: str
        inputs_raw, alts_raw, clicked = self._run_dialog_and_collect()

        self._inputs_processed: dict[ str, str | SecureString ] = self._apply_secure_policy(
            inputs_raw = inputs_raw,
            input_specs = self.dialog_config.input_specs
        )

        self._inputs_raw: dict[ str, str ] = inputs_raw
        self._alts_raw: dict[ str, str ] = alts_raw
        self._clicked_button: str = clicked

        self._shown = True

        return self
