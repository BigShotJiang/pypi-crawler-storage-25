"""
Backward-compatibility shim for legacy imports.

This module re-exports the modern dialog implementation under the legacy
module path and class alias.
"""

from .dialog import DynamicInputBox

dynamic_inputbox = DynamicInputBox

__all__: list[ str ] = [
    'DynamicInputBox',
    'dynamic_inputbox'
]
