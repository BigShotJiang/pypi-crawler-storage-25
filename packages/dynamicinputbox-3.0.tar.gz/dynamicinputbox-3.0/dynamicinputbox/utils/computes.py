"""
Utility helpers for dialog layout calculations.

This module contains small computation functions used when sizing and placing
the dialog window, including centering the window on screen and calculating a
clamped wrap width for message text.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from tkinter import Tk, Toplevel


def compose_center_geometry( window: Tk | Toplevel ) -> str:
    """ Compute a geometry string that centers the window on screen

    The returned geometry string preserves the window's current content size and
    computes screen coordinates that place the full window, including frame and
    title bar, approximately in the center of the screen.

    Args:
        window (Tk | Toplevel): Window whose geometry should be centered

    Returns:
        str: Tk geometry string in the form ``"<width>x<height>+<x>+<y>"``
    """

    window.update_idletasks()
    width: int = window.winfo_width()
    frm_width: int = window.winfo_rootx() - window.winfo_x()
    win_width: int = width + 2 * frm_width
    height: int = window.winfo_height()
    titlebar_height: int = window.winfo_rooty() - window.winfo_y()
    win_height: int = height + titlebar_height + frm_width
    x: int = window.winfo_screenwidth() // 2 - win_width // 2
    y: int = window.winfo_screenheight() // 2 - win_height // 2

    return f'{ width }x{ height }+{ x }+{ y }'


def compute_wrap_px( window: Tk | Toplevel, message_wraplength: int | None, *, max_width_ratio: float, min_width_px: int, max_width_px: int | None, ) -> int:
    """ Compute a clamped message wrap width in pixels

    The wrap width is limited by the screen width ratio, the optional absolute
    maximum width, and the configured minimum width. If ``message_wraplength`` is
    not provided or is not positive, the maximum allowed width is used before
    clamping.

    Args:
        window (Tk | Toplevel): Main window, used to query the current screen width
        message_wraplength (int | None): Requested wrap width in pixels
        max_width_ratio (float): Maximum portion of the screen width that the
            wrapped message area may occupy
        min_width_px (int): Minimum allowed wrap width in pixels
        max_width_px (int | None): Optional absolute maximum wrap width in pixels

    Returns:
        int: Final wrap width in pixels
    """

    screen_width: int = window.winfo_screenwidth()

    # Maximum width allowed by screen
    max_screen_px = int( screen_width * max_width_ratio )

    # Apply optional absolute max
    if max_width_px is not None:
        max_allowed: int = min( max_screen_px, max_width_px )
    else:
        max_allowed = max_screen_px

    # User requested value
    requested: int = (
        message_wraplength
        if message_wraplength and message_wraplength > 0
        else max_allowed
    )

    # Clamp
    wrap_px: int = max( min_width_px, min( requested, max_allowed ) )

    return wrap_px
