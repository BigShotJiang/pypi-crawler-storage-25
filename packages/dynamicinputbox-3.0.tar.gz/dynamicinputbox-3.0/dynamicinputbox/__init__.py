"""
Public package interface for ``dynamicinputbox``.

This module re-exports the main dialog class together with selected public
types used to configure dialog inputs and interpret dialog results.

Exports:
    DynamicInputBox: Main dialog class.
    dynamic_inputbox: Backward-compatible alias for ``DynamicInputBox``.
    SecureString: Mutable wrapper for sensitive text values.
    InputDict: Typed dictionary for input field configuration.
    AlternativeDict: Typed dictionary for alternative field configuration.
    Result: Union of supported dialog result representations.
    ResultDict: Dictionary-based dialog result type.
    ResultTuple: Tuple-based dialog result type.
"""


from .dialog import DynamicInputBox
from .models.SecureString import SecureString
from .models.inputdict import InputDict
from .models.alternativedict import AlternativeDict
from .models.resulttypes import Result, ResultDict, ResultTuple

dynamic_inputbox = DynamicInputBox

__all__: list[str] = [
    'DynamicInputBox',
    'dynamic_inputbox',
    'SecureString',
    'InputDict',
    'AlternativeDict',
    'Result',
    'ResultDict',
    'ResultTuple',
]
