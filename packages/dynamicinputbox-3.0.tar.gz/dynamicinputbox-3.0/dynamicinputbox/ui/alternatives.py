"""
Helpers for building and reading the dialog alternative fields.

This module creates labeled combobox widgets from ``AlternativeSpec``
definitions and provides a utility for reading the selected values.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from tkinter import Misc, StringVar
from tkinter.ttk import Combobox, Frame, Label, Separator

from ..models.AlternativeSpec import AlternativeSpec
from ..models.althandles import AltHandles
from ..models.enums import Fonts


def build_alternatives( parent: Misc, alt_specs: list[ AlternativeSpec ], use_separator: bool = False, padding_px: int = 0, ) -> tuple[ Frame, dict[ str, AltHandles ] ]:
    """ Build the dialog alternative-selection area

    A label and combobox widget are created for each alternative definition. The
    returned mapping uses the alternative label as its key.

    Args:
        parent (Misc): Parent widget that will contain the alternatives area
        alt_specs (list[AlternativeSpec]): Alternative definitions to convert into
            labeled combobox widgets
        use_separator (bool): Whether to insert a horizontal separator above the
            alternatives area
        padding_px (int): Reserved padding setting for layout

    Returns:
        tuple[Frame, dict[str, AltHandles]]: The container frame holding the
        alternative widgets and a mapping from alternative label to its widget
        handles
    """

    alts_content_frame = Frame( master = parent )
    alts_collection: dict[ str, AltHandles ] = {}
    row_index: int = 0

    if use_separator:
        separator = Separator( master = alts_content_frame, orient = 'horizontal' )
        separator.grid( row = row_index, sticky = 'we', padx = 10, pady = ( 10, 5 ) )
        row_index += 1

    row_index += 1
    for alternative in alt_specs:
        var = StringVar( value = alternative.default )

        label = Label( master = alts_content_frame, text = alternative.label, font = Fonts.title(), justify = 'left' )
        label.grid( row = row_index, sticky = 'W', padx = 10 )

        combobox = Combobox( master = alts_content_frame, values = alternative.options, textvariable = var )
        combobox.grid( row = row_index + 1, sticky = 'we', padx = 5 )

        alts_collection[ alternative.label ] = AltHandles( label = label, combobox = combobox, var = var)
        row_index += 2

    return alts_content_frame, alts_collection


def read_alternatives( alts: dict[ str, AltHandles ] ) -> dict[ str, str ]:
    """ Read the current selected values from the alternative field collection

    Args:
        alts (dict[str, AltHandles]): Mapping of alternative labels to their
            widget handles

    Returns:
        dict[str, str]: Collected alternative values in the form
        ``alternative_label -> selected_value``
    """

    collected: dict[ str, str ] = {}

    for name, alt in alts.items():
        collected[ name ] = alt.var.get()

    return collected
