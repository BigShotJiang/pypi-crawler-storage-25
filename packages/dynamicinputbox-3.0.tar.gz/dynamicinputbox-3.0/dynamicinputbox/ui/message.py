"""
Helpers for building the dialog message area.

This module creates the message section shown above the dialog inputs and
alternatives. Short messages are displayed in a wrapped label, while longer
messages are placed in a read-only scrollable text area.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from tkinter import Text
from tkinter.ttk import Frame, Label, Scrollbar

from ..models.enums import Fonts


def build_message( parent: Frame, message: str, wrap_px: int, padding_px: int = 0, ) -> Frame:
    """ Build and return the dialog message section

    The message is first measured using a temporary wrapped label to estimate its
    rendered height. If the message would exceed the dialog height policy, it is
    shown in a read-only scrollable text widget. Otherwise, it is shown in a
    standard wrapped label

    Args:
        parent (Frame): Parent widget that will contain the message area
        message (str): Message text to display
        wrap_px (int): Wrap width, in pixels, used when rendering the message
        padding_px (int): Reserved padding setting for layout

    Returns:
        Frame: Container frame holding the rendered message widget
    """

    message_content_frame = Frame( master = parent )

    screen_h: int = parent.winfo_screenheight()

    dummy = Label(
        master = message_content_frame,
        text = message,
        font = Fonts.ordinary(),
        wraplength = wrap_px,
        justify = 'left'
    )
    dummy.grid( row = 0, column = 0, sticky = 'nw', padx = 10, pady = 5 )
    dummy.update_idletasks()
    wrapped_height: int = dummy.winfo_reqheight()
    dummy.destroy()

    max_dialog_h = int( screen_h * 0.6 )
    use_scrollbox: bool = wrapped_height > max_dialog_h

    if use_scrollbox:
        message_frame = Frame( master = message_content_frame, borderwidth = 1, relief = 'solid' )
        message_frame.grid( row = 0, column = 0, padx = 10, pady = 10, sticky = 'nswe' )
        message_frame.grid_columnconfigure( 0, weight = 1 )

        avg_char_px: int = max( Fonts.ordinary().measure( '0' ), 1 )
        text_width_chars: int = max( 20, int( wrap_px / avg_char_px ) )

        line_h: int = max( Fonts.ordinary().metrics( 'linespace' ), 1 )
        ideal_lines: int = max( 6, int( max_dialog_h / line_h ) )
        text_height_lines: int = min( ideal_lines, 20 )

        message_text = Text(
            master = message_frame,
            width = text_width_chars,
            height = text_height_lines,
            wrap = 'word',
            font = Fonts.ordinary(),
            highlightthickness = 0,
            borderwidth = 0,
        )
        message_text.insert( '1.0', message )
        message_text.configure( state = 'disabled' )
        message_text.grid( row = 0, column = 0, sticky = 'nswe' )

        message_scrollbar = Scrollbar( master = message_frame, orient = 'vertical', command = message_text.yview )
        message_scrollbar.grid( row = 0, column = 1, sticky = 'ns' )
        message_text.config( yscrollcommand = message_scrollbar.set )

    else:
        label = Label(
            master = message_content_frame,
            text = message,
            font = Fonts.ordinary(),
            wraplength = wrap_px,
            justify = 'left'
        )
        label.grid( row = 0, column = 0, padx = 10, pady = 5, sticky = 'nw' )

    return message_content_frame
