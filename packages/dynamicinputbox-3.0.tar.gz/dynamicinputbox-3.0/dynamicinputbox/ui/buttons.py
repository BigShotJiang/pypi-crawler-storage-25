"""
Helpers for building and wiring the button area.

This module creates the dialog buttons and binds keyboard shortcuts for
confirm and cancel actions. It also centralizes the logic for storing the
clicked button label before the dialog is closed.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from tkinter import Misc, StringVar
from tkinter.ttk import Button, Frame
from typing import Callable, Sequence


def _button_click( clicked: str, clicked_var: StringVar, on_close: Callable[ [], None ] ) -> None:
    """ Store the clicked button label and trigger dialog shutdown

    Args:
        clicked (str): Label of the button that was activated
        clicked_var (StringVar): Shared Tk variable used to store the final
            clicked button label for the dialog result
        on_close (Callable[[], None]): Callback that performs the dialog close
            behavior after the button value has been recorded
    """

    clicked_var.set( clicked )
    on_close()


def bind_default_keys( window: Misc, buttons: dict[ str, Button ], default_button: str | None, cancel_button: str | None, clicked_var: StringVar, on_close: Callable[ [], None ], on_cancel = Callable[ [], None ] ) -> None:
    """ Bind Enter and Escape keys to the dialog button actions

    Escape triggers the configured cancel action if string is available in configured
    button label, if not present, say if misspelled, ``"Aborted"`` will be used as the
    clicked label. Enter triggers the configured default button if that button exists
    in the provided button collection.

    Args:
        window (Misc): Top-level dialog widget that receives the key bindings
        buttons (dict[str, Button]): Mapping of button labels to created button
            widgets
        default_button (str | None): Label of the button that should be
            triggered by Enter
        cancel_button (str | None): Label of the button that should be
            triggered by Escape
        clicked_var (StringVar): Shared Tk variable used to store the final
            clicked button label for the dialog result
        on_close (Callable[[], None]): Callback used for normal close behavior,
            including the default button action
        on_cancel (Callable[[], None]): Callback used for cancel behavior when
            Escape is pressed
    """

    cancel: str = 'Aborted'
    if cancel_button and cancel_button in buttons:
        cancel = cancel_button

    window.bind(
        '<Escape>',
        lambda event: _button_click( clicked = cancel, clicked_var = clicked_var, on_close = on_cancel )
    )

    if default_button and default_button in buttons:
        window.bind(
            '<Return>',
            lambda event: _button_click( clicked = default_button, clicked_var = clicked_var, on_close = on_close )
        )


def build_buttons_area( parent: Misc, labels: Sequence[ str ], clicked_var: StringVar, on_close: Callable[ [], None ], on_cancel = Callable[ [], None ], default_button: str | None = None, cancel_button: str | None = None, padding_px: int = 0 ) -> tuple[ Frame, dict[ str, Button ] ]:
    """ Create the dialog button row and return the widgets by label

    Each created button stores its own label in ``clicked_var`` and then calls
    the provided close callback when activated

    Args:
        parent (Misc): Parent widget that will contain the button area
        labels (Sequence[str]): Button labels to create, in display order
        clicked_var (StringVar): Shared Tk variable used to store the final
            clicked button label for the dialog result
        on_close (Callable[[], None]): Callback to run after a button is
            clicked and its label has been stored
        on_cancel (Callable[[], None]): Reserved cancel callback parameter
        default_button (str | None): Label intended to represent the default
            action for the dialog
        cancel_button (str | None): Label intended to represent the cancel
            action for the dialog
        padding_px (int): Reserved padding setting for button-area layout

    Returns:
        tuple[Frame, dict[str, Button]]: The container frame holding the buttons
        and a mapping from button label to its corresponding widget
    """

    buttons_content_frame: Frame = Frame( master = parent )
    buttons_collection: dict[ str, Button ] = {}
    col_index = 0

    for button_label in labels:
        b = Button(
            master = buttons_content_frame,
            text = button_label,
            width = 10,
            command = lambda t = button_label: _button_click( clicked = t, clicked_var = clicked_var, on_close = on_close )
        )
        b.grid( column = col_index, row = 0, padx = 5, pady = 10 )
        col_index += 1
        buttons_collection[ button_label ] = b

    return buttons_content_frame, buttons_collection
