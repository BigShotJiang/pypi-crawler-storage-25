"""
Helpers for constructing and running the main dialog window.

This module assembles the top-level dialog UI from the provided configuration,
including the message area, input fields, alternatives, and buttons. It also
applies focus behavior, modal grab behavior, and the blocking wait used while
the dialog is open.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""


from tkinter import StringVar, TclError, Tk, Toplevel
from tkinter.ttk import Frame

from ..models.dialogconfig import DialogConfig
from ..models.uihandles import UIHandles
from ..ui.alternatives import build_alternatives
from ..ui.buttons import bind_default_keys, build_buttons_area
from ..ui.inputs import build_inputs
from ..ui.message import build_message
from ..utils.computes import compose_center_geometry, compute_wrap_px


def _close_window( window: Tk | Toplevel ) -> None:
    """ Release any active modal grab and destroy the dialog window

    Args:
        window (Tk | Toplevel): Dialog window to close
    """

    try:
        window.grab_release()

    except TclError:
        pass

    window.destroy()


def build_dialog_ui( config: DialogConfig ) -> UIHandles:
    """ Build and configure the dialog user interface

    The returned UI includes the top-level window, the main container, and any
    message, input, alternative, and button widgets created from the supplied
    configuration. The dialog is centered on screen, optionally made transient to
    its parent, and attempts to acquire a modal grab when possible.

    Focus is assigned to the first input field if one exists. Otherwise, focus is
    given to the configured default button when available.

    Args:
        config (DialogConfig): Complete dialog configuration describing content,
            layout policy, button behavior, and parent/window options

    Returns:
        UIHandles: Collected references to the created widgets and dialog state
        holders
    """

    window: Toplevel | Tk = Toplevel( master = config.parent ) if config.parent else Tk()
    window.title( config.title )
    window.resizable( bool( config.resizable ), bool( config.resizable ) )

    if config.topmost:
        window.attributes( '-topmost', True )

    clicked_var = StringVar( master = window, value = config.default_button )

    handles = UIHandles( window = window, clicked_var = clicked_var )

    container = Frame( master = window )
    container.grid( row = 0, column = 0, sticky = 'nsew' )
    container.grid_columnconfigure( index = 0, weight = 1 )
    handles.container = container

    row_index = 0
    has_content_before = False


    def _on_close() -> None:
        _close_window( window )


    def _cancel() -> None:
        _on_close()

    window.protocol( 'WM_DELETE_WINDOW', _cancel )

    if config.message:
        wrap_px: int = compute_wrap_px(
            window = window,
            message_wraplength = config.message_wraplength,
            max_width_ratio = config.max_width_ratio or 0.8,
            min_width_px = config.min_width_px or 320,
            max_width_px = config.max_width_px,
        )
        message_widget: Frame = build_message(
            parent = container,
            message = config.message,
            wrap_px = wrap_px,
            padding_px = config.padding_px or 0,
        )
        message_widget.grid( row = row_index, column = 0, sticky = 'we' )
        handles.message_widget = message_widget
        row_index += 1
        has_content_before = True

    if config.input_specs:
        inputs_frame, input_widgets = build_inputs(
            parent = container,
            input_specs = config.input_specs,
            use_separator = has_content_before,
            padding_px = config.padding_px or 0,
        )
        inputs_frame.grid( row = row_index, column = 0, sticky = 'we' )
        inputs_frame.grid_columnconfigure( index = 0, weight = 1 )
        handles.input_widgets = input_widgets
        row_index += 1
        has_content_before = True

    if config.alt_specs:
        alts_frame, alt_widgets = build_alternatives(
            parent = container,
            alt_specs = config.alt_specs,
            use_separator = has_content_before,
            padding_px = config.padding_px or 0,
        )
        alts_frame.grid( row = row_index, column = 0, sticky = 'we' )
        alts_frame.grid_columnconfigure( index  = 0, weight = 1 )
        handles.alternative_widgets = alt_widgets
        row_index += 1

    button_labels: list[ str ] = config.button_labels or [ 'OK' ]
    buttons_frame, buttons = build_buttons_area(
        parent = container,
        labels = button_labels,
        clicked_var = clicked_var,
        on_close = _on_close,
        on_cancel = _cancel,
        default_button = config.default_button,
        cancel_button = config.cancel_button,
        padding_px = config.padding_px or 0,
    )
    buttons_frame.grid( row = row_index, column = 0, sticky = 'e' )
    handles.buttons = buttons

    bind_default_keys(
        window = window,
        buttons = buttons,
        default_button = config.default_button or ( button_labels[ 0 ] if button_labels else None ),
        cancel_button = config.cancel_button,
        clicked_var = clicked_var,
        on_close = _on_close,
        on_cancel = _cancel
    )

    window.update_idletasks()
    window.geometry( compose_center_geometry( window ) )

    if config.parent:
        try:
            window.transient( config.parent )

        except TclError:
            pass

    try:
        window.grab_set()

    except TclError:
        pass

    # Focus policy: first input if any, otherwise default button, otherwise first button
    focused = False
    if handles.input_widgets:
        for field in handles.input_widgets.values():
            if field.is_first:
                try:
                    field.widget.focus_set()
                    focused = True
                    break

                except TclError:
                    pass

    if not focused:
        default_label: str | None = config.default_button or ( button_labels[ 0 ] if button_labels else None )
        if default_label and default_label in buttons:
            try:
                buttons[ default_label ].focus_set()

            except TclError:
                pass

    return handles


def run_dialog( ui: UIHandles ) -> str:
    """ Block until the dialog window is closed and return the clicked label

    Args:
        ui (UIHandles): Widget handles and dialog state returned by
            ``build_dialog_ui()``

    Returns:
        str: Final button label stored for the dialog result
    """

    ui.window.wait_window()

    return ui.clicked_var.get()
