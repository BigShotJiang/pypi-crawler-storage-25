"""
Helpers for building and reading the input fields.

This module creates labeled text-entry widgets from ``InputSpec`` definitions,
supports preset placeholder text and masked input, and provides utilities for
reading collected values and focusing the first input field.

Author: Smorkster
GitHub: https://github.com/Smorkster/dynamicinputbox
License: MIT
"""

from tkinter import W, Event, StringVar
from tkinter.font import Font
from tkinter.ttk import Entry, Frame, Label, Separator
from typing import cast

from ..models.InputSpec import InputSpec
from ..models.enums import Fonts
from ..models.inputhandles import InputHandles


def build_inputs(
    parent: Frame,
    input_specs: list[ InputSpec ],
    use_separator: bool,
    padding_px: int = 0,
) -> tuple[ Frame, dict[ str, InputHandles ] ]:
    """ Build the dialog input area from the provided input specifications

    A label and entry widget are created for each input definition. Inputs with
    no explicit name are assigned generated names, such as ``"Input1"``. If an
    input defines a preset text and no default value, the preset is shown in
    italic placeholder style until the user starts typing. If an input defines
    ``show``, the entry is configured as a masked field.

    Args:
        parent (Frame): Parent widget that will contain the input area
        input_specs (list[InputSpec]): Input definitions to convert into labeled
            entry widgets
        use_separator (bool): Whether to insert a horizontal separator above the
            input area
        padding_px (int): Reserved padding setting for layout

    Returns:
        tuple[Frame, dict[str, InputHandles]]: The container frame holding the
        input widgets and a mapping from input name to its widget handles
    """


    def _preset_keypress( event: Event ) -> None:
        """ Clear preset placeholder text on the first keypress

        If the current entry still displays placeholder text in italic style, that
        text is removed and the widget is restored to normal text styling. If the
        field is configured as masked input, its masking character is also restored.

        Args:
            event (Event): Tk keypress event for the entry widget being edited.
        """

        widget: Entry = cast( Entry, event.widget )
        # Find which input this widget corresponds to (by comparing with self.input_fields)
        if Font( font = widget.cget( 'font' ) ).actual().get( 'slant' ) == 'italic':
            widget.delete( 0, 'end' )

            # Restore font to normal style and color to black
            field: InputHandles | None = next(
                ( val for val in input_fields.values() if val.widget ==  widget ),
                None
            )

            if field:
                s: str = field.show[ 0 ] if field else ''
                widget.config(
                    font = ( 'Calibri', 12, 'normal' ),
                    foreground = '#000000',
                    show = s
                )
            parent.update_idletasks()


    firstentry: Entry | None = None
    row_index: int = 0
    unnamed_count: int = 0 # Track unnamed inputs
    input_fields: dict[ str, InputHandles ] = {}

    inputs_content_frame: Frame = Frame( master = parent )

    if use_separator:
        separator: Separator = Separator( master = inputs_content_frame, orient = 'horizontal' )
        separator.grid( row = 0, sticky = 'we', padx = 10, pady = 5 )
        row_index += 1

    for i, input_def in enumerate( input_specs ):
        # Assign a safe name
        if not input_def.name:
            unnamed_count += 1
            name: str = f'Input{ unnamed_count }'
            input_def.name = name

        name = input_def.name.strip()

        label_text: str = input_def.label if input_def.label else name
        default: str = input_def.default if input_def.default else ''
        show: str = input_def.show if input_def.show else ''
        preset: str | None = input_def.preset if input_def.preset else None

        lbl = Label( master = inputs_content_frame, text = label_text, font = Fonts.title(), justify = 'left' )
        lbl.grid( row = row_index, sticky = W, padx = 10 )

        var: StringVar = StringVar( master = inputs_content_frame )
        entry: Entry = Entry( master = inputs_content_frame, font = Fonts.ordinary(), textvariable = var )
        entry.insert( 0, default )
        entry.grid( row = row_index + 1, padx = 10, pady = 2, sticky = 'we' )


        if firstentry is None:
            firstentry = entry

        if preset and not default:
            entry.insert( 0, preset )
            entry.config( foreground = '#D3D3D3', font = ( 'Calibri', 12, 'italic' ) )

        elif show:
            entry.config( show = show[ 0 ] )

        entry.bind( '<KeyPress>', _preset_keypress )
        row_index += 2

        # Store entry widget by name
        input_fields[ name ] = InputHandles( label = lbl, widget = entry, var = var, is_text = True, show = show, is_first = ( firstentry == entry ) )

    return inputs_content_frame, input_fields


def read_inputs( fields: dict[ str, InputHandles ] ) -> dict[ str, str ]:
    """ Read the current text values from the input field collection

    Args:
        fields (dict[str, InputHandles]): Mapping of input names to their widget
            handles

    Returns:
        dict[str, str]: Collected input values in the form
        ``input_name -> current_text``
    """

    collected: dict[ str, str ] = {}

    for k, v in fields.items():
        collected[ k ] = v.var.get()

    return collected


def focus_first_input( fields: dict[ str, InputHandles ] ) -> None:
    """ Set keyboard focus to the first configured input field

    Args:
        fields (dict[str, InputHandles]): Mapping of input names to their widget
            handles
    """

    for input in fields.values():
        if input.is_first:
            input.widget.focus()
            break
