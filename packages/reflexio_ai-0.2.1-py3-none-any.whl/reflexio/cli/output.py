"""Structured output formatting for Reflexio CLI.

All commands produce output through this module, ensuring a consistent
JSON envelope for agent consumption and Rich formatting for humans.
"""

from __future__ import annotations

import json
import sys
from datetime import UTC
from typing import Any

# ---------------------------------------------------------------------------
# JSON envelope
# ---------------------------------------------------------------------------


def render(
    data: Any,
    *,
    json_mode: bool = False,
    meta: dict[str, Any] | None = None,
    exclude_none: bool = True,
) -> None:
    """Render command output to stdout.

    In JSON mode, wraps data in a standard envelope:
    ``{"ok": true, "data": ..., "meta": {...}}``

    In human mode, prints the data as-is (string) or pretty-prints dicts/lists.

    Args:
        data: The data to render (dict, list, string, or Pydantic model)
        json_mode: If True, output JSON envelope; otherwise human-readable
        meta: Optional metadata (count, limit, has_more, etc.)
        exclude_none: If True (default), omit None fields from Pydantic models
    """
    if json_mode:
        envelope: dict[str, Any] = {
            "ok": True,
            "data": _serialize(data, exclude_none=exclude_none),
        }
        if meta:
            envelope["meta"] = meta
        print(json.dumps(envelope, indent=2, default=str))
    elif isinstance(data, str):
        print(data)
    elif isinstance(data, (dict, list)):
        print(json.dumps(data, indent=2, default=str))
    elif hasattr(data, "model_dump"):
        # Pydantic model safety net — serialize to dict instead of __repr__
        print(
            json.dumps(
                data.model_dump(mode="json", exclude_none=exclude_none),
                indent=2,
                default=str,
            )
        )
    else:
        print(data)


def _serialize(data: Any, *, exclude_none: bool = True) -> Any:
    """Serialize data for JSON output, handling Pydantic models.

    Args:
        data: Data to serialize
        exclude_none: If True, omit None fields from Pydantic models

    Returns:
        Any: JSON-serializable data
    """
    if hasattr(data, "model_dump"):
        return data.model_dump(mode="json", exclude_none=exclude_none)
    if isinstance(data, list):
        return [_serialize(item, exclude_none=exclude_none) for item in data]
    return data


# ---------------------------------------------------------------------------
# Human-readable formatters (kept from _output.py for backward compat)
# ---------------------------------------------------------------------------


def print_info(msg: str) -> None:
    """Print an informational message to stderr.

    Args:
        msg: Message to print
    """
    print(msg, file=sys.stderr)


def print_error(msg: str) -> None:
    """Print an error message to stderr.

    Args:
        msg: Error message to print
    """
    print(f"Error: {msg}", file=sys.stderr)


def _lifecycle_tag(obj: Any) -> str:
    """Return a lifecycle status tag for objects with a ``status`` attribute.

    Only emits a tag for non-current statuses (PENDING, ARCHIVED).  Objects
    whose status is CURRENT or None are considered active and get no tag.

    Args:
        obj: Any object that may have a ``status`` attribute

    Returns:
        str: Tag string like " [PENDING]" or "", including leading space
    """
    status = getattr(obj, "status", None)
    if (
        status is not None
        and isinstance(status, str)
        and status.upper() not in ("CURRENT", "")
    ):
        return f" [{status.upper()}]"
    # Handle enum-style status where .value is not None
    if status is not None and hasattr(status, "value") and status.value is not None:
        return f" [{str(status.value).upper()}]"
    return ""


def format_profiles(profiles: list[Any]) -> str:
    """Format profile objects as markdown bullet list.

    Shows a lifecycle tag ([PENDING]/[ARCHIVED]) when the profile status is
    not CURRENT or None.

    Args:
        profiles: Profile objects with a profile_content attribute

    Returns:
        str: Formatted profiles, one per line
    """
    if not profiles:
        return ""
    return "\n".join(f"- {p.content}{_lifecycle_tag(p)}" for p in profiles)


def _structured_lines(sd: Any) -> list[str]:
    """Build indented structured-data lines from a StructuredData-like object.

    Uses the canonical labels: Trigger, Instruction, Pitfall, Rationale.

    Args:
        sd: Object with optional trigger, instruction, pitfall, rationale attrs

    Returns:
        list[str]: Indented lines (may be empty)
    """
    lines: list[str] = []
    if sd is None:
        return lines
    if getattr(sd, "trigger", None):
        lines.append(f"  Trigger: {sd.trigger}")
    if getattr(sd, "instruction", None):
        lines.append(f"  Instruction: {sd.instruction}")
    if getattr(sd, "pitfall", None):
        lines.append(f"  Pitfall: {sd.pitfall}")
    if getattr(sd, "rationale", None):
        lines.append(f"  Rationale: {sd.rationale}")
    return lines


def format_agent_playbooks(agent_playbooks: list[Any]) -> str:
    """Format agent playbook objects with structured data.

    Shows an approval status tag ([APPROVED]/[PENDING]/[REJECTED]) from
    ``playbook_status`` and a lifecycle tag ([PENDING]/[ARCHIVED]) from
    ``status`` when not CURRENT/None.

    Args:
        agent_playbooks: Agent playbook objects with content and structured_data

    Returns:
        str: Formatted agent playbooks with structured action lines
    """
    if not agent_playbooks:
        return ""
    blocks: list[str] = []
    for playbook in agent_playbooks:
        # Approval status tag from playbook_status
        approval_tag = ""
        ps = getattr(playbook, "playbook_status", None)
        if ps is not None:
            ps_str = str(ps).upper() if not isinstance(ps, str) else ps.upper()
            if ps_str:
                approval_tag = f" [{ps_str}]"

        lifecycle = _lifecycle_tag(playbook)
        parts = [f"- {playbook.content}{approval_tag}{lifecycle}"]
        parts.extend(_structured_lines(playbook.structured_data))
        blocks.append("\n".join(parts))
    return "\n\n".join(blocks)


def format_user_playbooks(user_playbooks: list[Any]) -> str:
    """Format user playbook objects with structured data and source metadata.

    User playbooks show source/request_id metadata instead of approval status.
    A lifecycle tag ([PENDING]/[ARCHIVED]) is shown when status is not
    CURRENT/None.

    Args:
        user_playbooks: User playbook objects with content, structured_data,
            source, and request_id

    Returns:
        str: Formatted user playbooks with structured action lines and source
    """
    if not user_playbooks:
        return ""
    blocks: list[str] = []
    for playbook in user_playbooks:
        lifecycle = _lifecycle_tag(playbook)
        parts = [f"- {playbook.content}{lifecycle}"]
        parts.extend(_structured_lines(playbook.structured_data))
        source = getattr(playbook, "source", None) or "unknown"
        request_id = getattr(playbook, "request_id", None) or "unknown"
        parts.append(f"  Source: {source} (request: {request_id})")
        blocks.append("\n".join(parts))
    return "\n\n".join(blocks)


def format_interactions(interactions: list[Any]) -> str:
    """Format interaction objects grouped by request_id as conversation turns.

    Args:
        interactions: InteractionView objects with request_id, role, content, created_at

    Returns:
        str: Formatted conversation turns
    """
    if not interactions:
        return ""

    from collections import defaultdict
    from datetime import datetime

    groups: dict[str, list[Any]] = defaultdict(list)
    for ix in interactions:
        groups[ix.request_id].append(ix)

    # Sort groups by earliest created_at
    sorted_groups = sorted(
        groups.items(), key=lambda g: min(i.created_at for i in g[1])
    )

    blocks: list[str] = []
    for request_id, items in sorted_groups:
        ts = min(i.created_at for i in items)
        try:
            dt = datetime.fromtimestamp(ts, tz=UTC).strftime("%Y-%m-%d %H:%M")
        except TypeError, ValueError, OSError:
            dt = "unknown"
        short_id = request_id[:8]
        header = f"── {short_id} ({dt} UTC) ──"
        lines = [header]
        for item in sorted(items, key=lambda i: i.created_at):
            role = item.role.capitalize()
            lines.append(f"  {role}: {item.content}")
        blocks.append("\n".join(lines))

    return "\n\n".join(blocks)


def format_context(
    profiles: list[Any],
    agent_playbooks: list[Any],
) -> str:
    """Build a combined context block from profiles and agent playbooks.

    Args:
        profiles: Profile objects
        agent_playbooks: Agent playbook objects

    Returns:
        str: Combined markdown context block, or empty string if all empty
    """
    sections: list[str] = []

    if profile_text := format_profiles(profiles):
        sections.append(f"## Known User Preferences & Information\n{profile_text}")

    if playbook_text := format_agent_playbooks(agent_playbooks):
        sections.append(f"## Behavior Corrections\n{playbook_text}")

    if not sections:
        return ""

    return (
        "---\n# Context and Corrections from Past Experience\n\n"
        + "\n\n".join(sections)
        + "\n---"
    )


def pagination_meta(
    items: list[Any],
    limit: int,
) -> dict[str, Any]:
    """Build pagination metadata for output envelope.

    Args:
        items: The items returned
        limit: The requested limit

    Returns:
        dict: Metadata with count, limit, and has_more flag
    """
    return {
        "count": len(items),
        "limit": limit,
        "has_more": len(items) == limit,
    }
