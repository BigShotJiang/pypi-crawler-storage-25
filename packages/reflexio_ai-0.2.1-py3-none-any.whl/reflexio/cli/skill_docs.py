"""Agent skill documentation for Reflexio CLI.

Contains a ~800 token reference document that teaches AI agents
how to use the CLI effectively. Per ScaleKit research, adding
structured CLI documentation to agent context reduces tool calls
by ~33% and is 4-32x cheaper than MCP-based tool access.
"""

from __future__ import annotations

AGENT_SKILL_DOCS = """# Reflexio CLI Quick Reference (for AI agents)

## Setup
```bash
reflexio auth login --api-key KEY --url http://localhost:8081
reflexio status check  # verify connection
```

## Publish interactions
```bash
# Single turn
reflexio publish --user-id UID --user-message "hello" --agent-response "hi there"

# From JSON file
reflexio interactions publish --user-id UID --file interactions.json --wait

# Inline JSON
reflexio interactions publish --user-id UID --data '{"interactions": [{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]}'
```

## Search (unified across profiles and playbooks)
```bash
reflexio search "query text" --json --top-k 5
reflexio interactions search --query "topic" --user-id UID --json
reflexio profiles search "query" --user-id UID --json
reflexio agent-playbooks search "query" --json
```

## Context retrieval (for agent bootstrap injection)
```bash
reflexio context --user-id UID --query "topic" --json
# Returns combined profiles + agent playbooks in structured format
```

## Manage playbooks
```bash
reflexio user-playbooks add --content "Always use formal tone" --trigger "greeting" --instruction "Use Mr/Ms" --pitfall "Don't use first names"
reflexio user-playbooks list --json --limit 20
reflexio agent-playbooks aggregate --wait  # cluster similar playbooks
reflexio agent-playbooks delete --id PLAYBOOK_ID
```

## Manage profiles
```bash
reflexio profiles list --user-id UID --json
reflexio profiles generate --user-id UID --wait  # re-extract profiles
reflexio profiles delete --user-id UID --profile-id PID
```

## Configuration
```bash
reflexio config show --json
reflexio config set --data '{"batch_size": 10}'
reflexio config set --file config.json
```

## Raw API access
```bash
reflexio api GET /health
reflexio api POST /api/search --data '{"query": "test"}'
```

## Output format
All commands support `--json` for structured output:
```json
{"ok": true, "data": [...], "meta": {"count": 5, "limit": 20, "has_more": false}}
```

Errors:
```json
{"ok": false, "error": {"type": "auth", "message": "...", "hint": "Run: reflexio auth login ..."}}
```

## Global flags
- `--json` — structured JSON envelope output (always use for programmatic access)
- `--url URL` — server URL override
- `--api-key KEY` — API key override
- `--yes` / `-y` — skip confirmation prompts on destructive operations
"""
