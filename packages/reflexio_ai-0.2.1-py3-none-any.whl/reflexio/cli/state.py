"""Shared CLI state management for Reflexio CLI.

Provides a CliState dataclass that travels through the Typer context,
and a helper to lazily create a ReflexioClient from the state + config
resolution chain.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import typer

from reflexio.cli._client import _CONFIG_PATH, _DEFAULT_URL, _load_config_file
from reflexio.defaults import DEFAULT_AGENT_VERSION, DEFAULT_USER_ID

if TYPE_CHECKING:
    from reflexio import ReflexioClient


@dataclass
class CliState:
    """Global CLI state passed via typer.Context.obj.

    Attributes:
        json_mode: Whether to output JSON envelopes
        server_url: Backend API server URL override (from --server-url flag)
        api_key: API key override (from --api-key flag)
    """

    json_mode: bool = False
    server_url: str | None = None
    api_key: str | None = None
    _client: ReflexioClient | None = field(default=None, repr=False)


def get_client(ctx: typer.Context) -> ReflexioClient:
    """Get or create a ReflexioClient from the CLI context.

    Resolution order (highest to lowest priority):
        1. CLI flags (--server-url, --api-key via CliState)
        2. Environment variables (REFLEXIO_URL, REFLEXIO_API_KEY)
        3. Config file (~/.openclaw/workspace/.reflexio/config.json)
        4. Defaults (http://localhost:8081, no api_key)

    Args:
        ctx: Typer context with CliState in ctx.obj

    Returns:
        ReflexioClient: Configured client instance
    """
    state: CliState = ctx.obj
    if state._client is not None:
        return state._client

    from reflexio import ReflexioClient

    config = _load_config_file()

    # Resolve URL: flag > env > config > default
    url = (
        state.server_url
        or os.environ.get("REFLEXIO_URL")
        or config.get("url")
        or _DEFAULT_URL
    )

    # Resolve API key: flag > env > config > empty
    api_key = (
        state.api_key
        or os.environ.get("REFLEXIO_API_KEY")
        or config.get("api_key")
        or ""
    )

    state._client = ReflexioClient(url_endpoint=url, api_key=api_key)
    return state._client


def resolve_user_id(user_id: str | None = None) -> str:
    """Resolve user_id from flag, env var, config file, or default.

    Args:
        user_id: Explicit user_id from CLI flag

    Returns:
        str: Resolved user ID
    """
    if user_id:
        return user_id
    if env_val := os.environ.get("REFLEXIO_USER_ID"):
        return env_val
    config = _load_config_file()
    if config_val := config.get("user_id"):
        return config_val
    return DEFAULT_USER_ID


def resolve_agent_version(agent_version: str | None = None) -> str:
    """Resolve agent_version from flag, env var, config file, or default.

    Args:
        agent_version: Explicit agent_version from CLI flag

    Returns:
        str: Resolved agent version
    """
    if agent_version:
        return agent_version
    if env_val := os.environ.get("REFLEXIO_AGENT_VERSION"):
        return env_val
    config = _load_config_file()
    if config_val := config.get("agent_version"):
        return config_val
    return DEFAULT_AGENT_VERSION


def get_config_path() -> str:
    """Return the config file path as a string.

    Returns:
        str: Path to the config file
    """
    return str(_CONFIG_PATH)
