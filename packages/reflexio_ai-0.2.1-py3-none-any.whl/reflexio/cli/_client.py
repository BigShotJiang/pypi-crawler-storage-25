"""ReflexioClient factory with layered config resolution."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any

from reflexio import ReflexioClient
from reflexio.defaults import DEFAULT_AGENT_VERSION, DEFAULT_USER_ID

_DEFAULT_URL = "http://localhost:8081"
_CONFIG_PATH = Path.home() / ".openclaw" / "workspace" / ".reflexio" / "config.json"


def _load_config_file() -> dict[str, Any]:
    """
    Load config from the default config file path.

    Returns:
        dict[str, Any]: Parsed config dict, or empty dict if file missing/invalid.
    """
    try:
        return json.loads(_CONFIG_PATH.read_text())
    except (FileNotFoundError, json.JSONDecodeError, OSError):  # fmt: skip
        return {}


def _resolve(
    args: argparse.Namespace | None,
    arg_name: str,
    env_var: str,
    config: dict[str, Any],
    config_key: str,
    default: str,
) -> str:
    """
    Resolve a config value through the priority chain: CLI flag -> env var -> config file -> default.

    Args:
        args (argparse.Namespace | None): Parsed CLI arguments
        arg_name (str): Attribute name on the args namespace
        env_var (str): Environment variable name
        config (dict[str, Any]): Loaded config file contents
        config_key (str): Key in the config dict
        default (str): Fallback default value

    Returns:
        str: The resolved value
    """
    if args and hasattr(args, arg_name) and getattr(args, arg_name):
        return getattr(args, arg_name)
    if env_val := os.environ.get(env_var):
        return env_val
    if config_val := config.get(config_key):
        return config_val
    return default


def create_client(args: argparse.Namespace | None = None) -> ReflexioClient:
    """
    Create a ReflexioClient with config resolved from CLI flags, env vars, config file, and defaults.

    Resolution order (highest to lowest priority):
        1. CLI flags (args.url, args.api_key)
        2. Environment variables (REFLEXIO_URL, REFLEXIO_API_KEY)
        3. Config file (~/.openclaw/workspace/.reflexio/config.json)
        4. Defaults (http://localhost:8081, no api_key)

    Args:
        args (argparse.Namespace | None): Parsed CLI arguments, or None for env/config/defaults only

    Returns:
        ReflexioClient: Configured client instance
    """
    config = _load_config_file()
    url = _resolve(args, "url", "REFLEXIO_URL", config, "url", _DEFAULT_URL)
    api_key = _resolve(args, "api_key", "REFLEXIO_API_KEY", config, "api_key", "")
    return ReflexioClient(url_endpoint=url, api_key=api_key)


def resolve_user_id(args: argparse.Namespace | None = None) -> str:
    """
    Resolve user_id from CLI flags, env var, config file, or default.

    Args:
        args (argparse.Namespace | None): Parsed CLI arguments

    Returns:
        str: Resolved user ID
    """
    config = _load_config_file()
    return _resolve(
        args, "user_id", "REFLEXIO_USER_ID", config, "user_id", DEFAULT_USER_ID
    )


def resolve_agent_version(args: argparse.Namespace | None = None) -> str:
    """
    Resolve agent_version from CLI flags, env var, config file, or default.

    Args:
        args (argparse.Namespace | None): Parsed CLI arguments

    Returns:
        str: Resolved agent version
    """
    config = _load_config_file()
    return _resolve(
        args,
        "agent_version",
        "REFLEXIO_AGENT_VERSION",
        config,
        "agent_version",
        DEFAULT_AGENT_VERSION,
    )
