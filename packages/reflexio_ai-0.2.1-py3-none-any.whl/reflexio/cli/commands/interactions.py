"""Manage interactions (conversations) via the Reflexio CLI."""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Annotated

import typer

from reflexio.cli.errors import EXIT_VALIDATION, CliError, handle_errors
from reflexio.cli.output import format_interactions, pagination_meta, print_info, render
from reflexio.cli.state import get_client, resolve_agent_version
from reflexio.models.api_schema.service_schemas import InteractionData

app = typer.Typer(help="Manage interactions (conversations).")


# ---------------------------------------------------------------------------
# Helpers (ported from capture.py)
# ---------------------------------------------------------------------------


def _parse_json_payload(raw: str) -> list[dict]:
    """Parse JSON or JSONL text into a list of conversation payloads.

    Args:
        raw (str): Raw JSON or JSONL string.

    Returns:
        list[dict]: List of parsed payload dicts, each containing an
            ``interactions`` key at minimum.

    Raises:
        CliError: If the input is empty or contains invalid JSON.
    """
    stripped = raw.strip()
    if not stripped:
        raise CliError(
            error_type="validation",
            message="Empty input",
            exit_code=EXIT_VALIDATION,
        )

    # Try single JSON object/array first
    try:
        data = json.loads(stripped)
        if isinstance(data, dict):
            return [data]
        if isinstance(data, list):
            if not all(isinstance(item, dict) for item in data):
                raise CliError(
                    error_type="validation",
                    message="JSON array elements must be objects, not primitives",
                    exit_code=EXIT_VALIDATION,
                )
            return data
    except json.JSONDecodeError:
        pass

    # Fall back to JSONL (one JSON object per line)
    payloads: list[dict] = []
    for lineno, line in enumerate(stripped.splitlines(), start=1):
        line = line.strip()
        if not line:
            continue
        try:
            payloads.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise CliError(
                error_type="validation",
                message=f"Invalid JSON on line {lineno}: {exc}",
                exit_code=EXIT_VALIDATION,
            ) from exc
    return payloads


def _interactions_from_payload(payload: dict) -> list[InteractionData]:
    """Convert a payload dict into a list of InteractionData objects.

    Args:
        payload (dict): Payload with an ``interactions`` list of
            ``{"role": ..., "content": ...}`` dicts.

    Returns:
        list[InteractionData]: Parsed interaction data objects.

    Raises:
        CliError: If the payload is missing the ``interactions`` list.
    """
    raw_interactions = payload.get("interactions", [])
    if not raw_interactions:
        raise CliError(
            error_type="validation",
            message="Payload missing 'interactions' list",
            exit_code=EXIT_VALIDATION,
        )
    return [
        InteractionData(role=item.get("role", "User"), content=item.get("content", ""))
        for item in raw_interactions
    ]


def _read_data_arg(data: str) -> str:
    """Read inline JSON or from a file path prefixed with ``@``.

    Args:
        data (str): JSON string, or ``@filepath`` to read from disk.

    Returns:
        str: Raw JSON content.

    Raises:
        CliError: If the referenced file does not exist.
    """
    if data.startswith("@"):
        path = Path(data[1:])
        if not path.exists():
            raise CliError(
                error_type="validation",
                message=f"File not found: {path}",
                exit_code=EXIT_VALIDATION,
            )
        return path.read_text()
    return data


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@app.command()
@handle_errors
def publish(
    ctx: typer.Context,
    user_id: Annotated[str, typer.Option(help="User identifier")],
    session_id: Annotated[
        str | None, typer.Option(help="Session ID for grouping")
    ] = None,
    source: Annotated[str, typer.Option(help="Source tag")] = "cli",
    agent_version: Annotated[
        str | None, typer.Option(help="Agent version string")
    ] = None,
    wait: Annotated[
        bool, typer.Option(help="Block until processing completes")
    ] = False,
    data: Annotated[str | None, typer.Option(help="JSON string or @filepath")] = None,
    file: Annotated[Path | None, typer.Option(help="Path to JSON/JSONL file")] = None,
    stdin: Annotated[bool, typer.Option(help="Read JSON data from stdin")] = False,
    user_message: Annotated[
        str | None, typer.Option(help="Single-turn user message")
    ] = None,
    agent_response: Annotated[
        str | None, typer.Option(help="Single-turn agent response")
    ] = None,
    skip_aggregation: Annotated[
        bool,
        typer.Option(
            "--skip-aggregation",
            help="Extract profiles/playbooks but skip aggregation to agent playbooks",
        ),
    ] = False,
    force_extraction: Annotated[
        bool,
        typer.Option(
            "--force-extraction",
            help="Bypass batch_interval checks and always run extractors",
        ),
    ] = False,
) -> None:
    """Publish interaction data for a user.

    Supports three input modes:
    1. ``--user-message`` + ``--agent-response`` for single-turn conversations.
    2. ``--file`` or ``--stdin`` for JSON/JSONL payloads.
    3. ``--data`` for inline JSON (prefix with ``@`` for a file path).
    """
    client = get_client(ctx)
    json_mode: bool = ctx.obj.json_mode

    # Mode 1: single-turn
    if user_message is not None:
        if agent_response is None:
            raise CliError(
                error_type="validation",
                message="--agent-response is required with --user-message",
                exit_code=EXIT_VALIDATION,
            )
        interactions: list[InteractionData | dict] = [
            InteractionData(role="user", content=user_message),
            InteractionData(role="assistant", content=agent_response),
        ]
        result = client.publish_interaction(
            user_id=user_id,
            interactions=interactions,
            source=source,
            agent_version=resolve_agent_version(agent_version),
            session_id=session_id,
            wait_for_response=wait,
            skip_aggregation=skip_aggregation,
            force_extraction=force_extraction,
        )
        if json_mode:
            render(result, json_mode=True)
        else:
            msg = getattr(result, "msg", None) or "Published"
            req_id = getattr(result, "request_id", "")
            print_info(f"{msg} (request_id={req_id})" if req_id else msg)
        return

    # Determine raw JSON from --data, --file, or --stdin
    raw: str | None = None
    if data is not None:
        raw = _read_data_arg(data)
    elif file is not None:
        if not file.exists():
            raise CliError(
                error_type="validation",
                message=f"File not found: {file}",
                exit_code=EXIT_VALIDATION,
            )
        raw = file.read_text()
    elif stdin:
        raw = sys.stdin.read()

    if raw is None:
        raise CliError(
            error_type="validation",
            message="Specify --user-message/--agent-response, --file, --stdin, or --data",
            exit_code=EXIT_VALIDATION,
        )

    payloads = _parse_json_payload(raw)
    print_info(f"Processing {len(payloads)} payload(s)...")

    resolved_version = resolve_agent_version(agent_version)
    for payload in payloads:
        interaction_items = _interactions_from_payload(payload)
        result = client.publish_interaction(
            user_id=payload.get("user_id", user_id),
            interactions=interaction_items,  # type: ignore[arg-type]
            source=payload.get("source", source),
            agent_version=payload.get("agent_version", resolved_version),
            session_id=payload.get("session_id", session_id),
            wait_for_response=wait,
            skip_aggregation=payload.get("skip_aggregation", skip_aggregation),
            force_extraction=payload.get("force_extraction", force_extraction),
        )
        if json_mode:
            render(result, json_mode=True)
        else:
            msg = getattr(result, "msg", None) or "Published"
            req_id = getattr(result, "request_id", "")
            print_info(f"{msg} (request_id={req_id})" if req_id else msg)


@app.command(name="list")
@handle_errors
def list_interactions(
    ctx: typer.Context,
    user_id: Annotated[str | None, typer.Option(help="Filter by user ID")] = None,
    limit: Annotated[
        int, typer.Option(help="Maximum number of interactions to return")
    ] = 20,
) -> None:
    """List interactions, optionally filtered by user."""
    client = get_client(ctx)
    result = client.get_interactions(user_id=user_id, top_k=limit)
    interactions = result.interactions or []

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(interactions, json_mode=True, meta=pagination_meta(interactions, limit))
    else:
        print_info(f"Found {len(interactions)} interaction(s)")
        if interactions:
            print(format_interactions(interactions))


@app.command()
@handle_errors
def search(
    ctx: typer.Context,
    query: Annotated[str, typer.Option(help="Search query string")],
    user_id: Annotated[str | None, typer.Option(help="Filter by user ID")] = None,
    limit: Annotated[int, typer.Option(help="Maximum number of results")] = 10,
) -> None:
    """Search interactions by semantic query."""
    client = get_client(ctx)
    result = client.search_interactions(query=query, user_id=user_id, top_k=limit)
    interactions = result.interactions or []

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(interactions, json_mode=True, meta=pagination_meta(interactions, limit))
    else:
        print_info(f"Found {len(interactions)} interaction(s)")
        if interactions:
            print(format_interactions(interactions))


@app.command()
@handle_errors
def delete(
    ctx: typer.Context,
    interaction_id: Annotated[str, typer.Option(help="Interaction ID to delete")],
    user_id: Annotated[str, typer.Option(help="User ID that owns the interaction")],
) -> None:
    """Delete a single interaction by ID."""
    client = get_client(ctx)
    result = client.delete_interaction(
        user_id=user_id,
        interaction_id=interaction_id,
        wait_for_response=True,
    )
    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(result, json_mode=True)
    else:
        print_info(f"Deleted interaction {interaction_id}")


@app.command(name="delete-all")
@handle_errors
def delete_all(
    ctx: typer.Context,
    yes: Annotated[
        bool, typer.Option("--yes", "-y", help="Skip confirmation prompt")
    ] = False,
) -> None:
    """Delete ALL interactions. This cannot be undone."""
    if not yes:
        typer.confirm("Delete all interactions? This cannot be undone", abort=True)
    client = get_client(ctx)
    result = client.delete_all_interactions()
    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(result, json_mode=True)
    else:
        print_info("All interactions deleted")
