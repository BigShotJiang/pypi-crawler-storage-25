"""Authentication and configuration setup commands."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from reflexio.cli._client import _CONFIG_PATH, _load_config_file
from reflexio.cli.errors import handle_errors
from reflexio.cli.output import render
from reflexio.defaults import DEFAULT_AGENT_VERSION, DEFAULT_USER_ID

app = typer.Typer(help="Authentication and configuration setup.")


@app.command()
@handle_errors
def login(
    ctx: typer.Context,
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", help="Reflexio API key"),
    ] = None,
    server_url: Annotated[
        str | None,
        typer.Option("--server-url", help="Backend API server URL"),
    ] = None,
    mode: Annotated[
        str | None,
        typer.Option("--mode", help="Server mode (local or remote)"),
    ] = None,
) -> None:
    """Save authentication credentials to the config file.

    Args:
        ctx: Typer context with CliState in ctx.obj
        api_key: API key to store
        server_url: Backend API server URL to store
        mode: Server mode (local or remote)
    """
    config: dict[str, str | None] = {
        "url": server_url,
        "api_key": api_key,
        "mode": mode,
        "user_id": DEFAULT_USER_ID,
        "agent_version": DEFAULT_AGENT_VERSION,
    }

    _CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_PATH.write_text(json.dumps(config, indent=2) + "\n")
    _CONFIG_PATH.chmod(0o600)

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render({"config_path": str(_CONFIG_PATH)}, json_mode=True)
    else:
        print(f"Credentials saved to {_CONFIG_PATH}")


@app.command()
@handle_errors
def status(
    ctx: typer.Context,
) -> None:
    """Show current authentication status and config.

    Args:
        ctx: Typer context with CliState in ctx.obj
    """
    config = _load_config_file()

    raw_key = config.get("api_key", "")
    masked_key = f"{raw_key[:8]}..." if raw_key and len(raw_key) > 8 else raw_key or ""

    info = {
        "url": config.get("url", ""),
        "api_key": masked_key,
        "mode": config.get("mode", ""),
        "config_path": str(_CONFIG_PATH),
    }

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(info, json_mode=True)
    else:
        print(f"URL:         {info['url']}")
        print(f"API Key:     {info['api_key']}")
        print(f"Mode:        {info['mode']}")
        print(f"Config file: {info['config_path']}")


@app.command()
@handle_errors
def logout(
    ctx: typer.Context,
) -> None:
    """Remove stored credentials by deleting the config file.

    Args:
        ctx: Typer context with CliState in ctx.obj
    """
    config_path = Path(_CONFIG_PATH)
    if config_path.exists():
        config_path.unlink()

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render({"message": "Logged out"}, json_mode=True)
    else:
        print("Logged out. Config file removed.")
