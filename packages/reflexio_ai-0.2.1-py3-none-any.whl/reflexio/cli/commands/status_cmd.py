"""Server health and status check."""

from __future__ import annotations

import json
import os
import sys

import requests
import typer

from reflexio.cli._client import _DEFAULT_URL, _load_config_file
from reflexio.cli.errors import EXIT_NETWORK, CliError, handle_errors, render_error
from reflexio.cli.state import CliState

app = typer.Typer(help="Server health and status.")


def _resolve_url(state: CliState) -> str:
    """Resolve the server URL from CLI state, env, config, or default.

    Args:
        state: CLI state with optional URL override

    Returns:
        str: Resolved server URL
    """
    return (
        state.server_url
        or os.environ.get("REFLEXIO_URL")
        or _load_config_file().get("url")
        or _DEFAULT_URL
    )


def _resolve_api_key(state: CliState) -> str:
    """Resolve the API key from CLI state, env, config, or default.

    Args:
        state: CLI state with optional API key override

    Returns:
        str: Resolved API key
    """
    return (
        state.api_key
        or os.environ.get("REFLEXIO_API_KEY")
        or _load_config_file().get("api_key")
        or ""
    )


@app.command()
@handle_errors
def check(
    ctx: typer.Context,
) -> None:
    """Check server health status.

    Makes a GET request to the /health endpoint and reports whether
    the server is reachable and healthy.

    Args:
        ctx: Typer context with CliState in ctx.obj
    """
    state: CliState = ctx.obj
    json_mode: bool = state.json_mode
    url = _resolve_url(state)
    api_key = _resolve_api_key(state)

    headers: dict[str, str] = {}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    try:
        resp = requests.get(f"{url}/health", headers=headers, timeout=10)
        resp.raise_for_status()
    except requests.ConnectionError as exc:
        err = CliError(
            error_type="network",
            message=f"Cannot reach server at {url}",
            hint="Is the Reflexio server running? Try: reflexio services start",
            exit_code=EXIT_NETWORK,
        )
        render_error(err, json_mode=json_mode)
        raise SystemExit(1) from exc
    except requests.HTTPError as exc:
        if json_mode:
            envelope = {
                "ok": False,
                "error": {"type": "unhealthy", "message": str(exc), "url": url},
            }
            print(json.dumps(envelope, indent=2), file=sys.stderr)
        else:
            print(
                f"Error: Server at {url} returned {exc.response.status_code}",
                file=sys.stderr,
            )
        raise SystemExit(1) from exc

    if json_mode:
        envelope = {"ok": True, "data": {"status": "healthy", "url": url}}
        print(json.dumps(envelope, indent=2))
    else:
        print(f"Connected to {url} (healthy)")
