"""User playbook management commands (list, search, add, delete)."""

from __future__ import annotations

from typing import Annotated

import typer

from reflexio.cli.errors import EXIT_VALIDATION, CliError, handle_errors
from reflexio.cli.output import (
    format_user_playbooks,
    pagination_meta,
    print_info,
    render,
)
from reflexio.cli.state import get_client

app = typer.Typer(help="Manage user playbooks.")

_STATUS_MAP = {
    "current": "current",
    "pending": "pending",
    "archived": "archived",
}


@app.command(name="list")
@handle_errors
def list_user_playbooks(
    ctx: typer.Context,
    user_id: Annotated[
        str | None,
        typer.Option("--user-id", help="Filter by user ID"),
    ] = None,
    limit: Annotated[
        int,
        typer.Option("--limit", help="Maximum number of playbooks to return"),
    ] = 20,
    playbook_name: Annotated[
        str | None,
        typer.Option("--playbook-name", help="Filter by playbook name"),
    ] = None,
    agent_version: Annotated[
        str | None,
        typer.Option("--agent-version", help="Filter by agent version"),
    ] = None,
    status: Annotated[
        str | None,
        typer.Option("--status", help="Status filter (current/pending/archived)"),
    ] = None,
) -> None:
    """List user playbooks.

    Args:
        ctx: Typer context with CliState in ctx.obj
        user_id: Optional user ID filter
        limit: Maximum number of playbooks to return
        playbook_name: Optional playbook name filter
        agent_version: Optional agent version filter
        status: Optional status filter (current, pending, archived)
    """
    from reflexio.models.api_schema.service_schemas import Status

    if status and status not in _STATUS_MAP:
        raise CliError(
            error_type="validation",
            message=f"Invalid status: {status}. Must be current, pending, or archived.",
            exit_code=EXIT_VALIDATION,
        )

    status_filter: list[Status | None] | None = None
    if status == "current":
        status_filter = [Status.CURRENT]
    elif status == "pending":
        status_filter = [Status.PENDING]
    elif status == "archived":
        status_filter = [Status.ARCHIVED]

    client = get_client(ctx)
    resp = client.get_user_playbooks(
        limit=limit,
        user_id=user_id,
        playbook_name=playbook_name,
        agent_version=agent_version,
        status_filter=status_filter,
    )
    playbooks = resp.user_playbooks or []

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(playbooks, json_mode=True, meta=pagination_meta(playbooks, limit))
    else:
        print_info(f"Found {len(playbooks)} user playbook(s)")
        if playbooks:
            print(format_user_playbooks(playbooks))


@app.command()
@handle_errors
def search(
    ctx: typer.Context,
    query: Annotated[
        str,
        typer.Argument(help="Semantic search query for user playbooks"),
    ],
    limit: Annotated[
        int,
        typer.Option("--limit", help="Maximum number of results"),
    ] = 10,
    agent_version: Annotated[
        str | None,
        typer.Option("--agent-version", help="Agent version to filter by"),
    ] = None,
) -> None:
    """Search user playbooks by semantic query.

    Args:
        ctx: Typer context with CliState in ctx.obj
        query: Search query string
        limit: Maximum number of results
        agent_version: Optional agent version filter
    """
    client = get_client(ctx)

    resp = client.search_user_playbooks(
        query=query,
        agent_version=agent_version,
        top_k=limit,
    )
    playbooks = resp.user_playbooks or []

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(playbooks, json_mode=True, meta=pagination_meta(playbooks, limit))
    else:
        print_info(f"Found {len(playbooks)} user playbook(s)")
        if playbooks:
            print(format_user_playbooks(playbooks))


@app.command()
@handle_errors
def add(
    ctx: typer.Context,
    content: Annotated[
        str,
        typer.Option("--content", help="Playbook content text"),
    ],
    playbook_name: Annotated[
        str,
        typer.Option("--playbook-name", help="Playbook category name"),
    ] = "agent_corrections",
    trigger: Annotated[
        str | None,
        typer.Option("--trigger", help="When this playbook applies"),
    ] = None,
    instruction: Annotated[
        str | None,
        typer.Option("--instruction", help="What to do (DO)"),
    ] = None,
    pitfall: Annotated[
        str | None,
        typer.Option("--pitfall", help="What not to do (DON'T)"),
    ] = None,
    rationale: Annotated[
        str | None,
        typer.Option("--rationale", help="Why this playbook matters"),
    ] = None,
) -> None:
    """Add a manual user playbook entry.

    Args:
        ctx: Typer context with CliState in ctx.obj
        content: Playbook content text
        playbook_name: Playbook category name
        trigger: When this playbook applies
        instruction: What to do
        pitfall: What not to do
        rationale: Why this playbook matters
    """
    from reflexio.models.api_schema.service_schemas import StructuredData, UserPlaybook

    structured_data = StructuredData(
        trigger=trigger,
        instruction=instruction,
        pitfall=pitfall,
        rationale=rationale,
    )
    playbook = UserPlaybook(
        agent_version="cli",
        request_id="cli-manual",
        playbook_name=playbook_name,
        content=content,
        structured_data=structured_data,
    )

    client = get_client(ctx)
    resp = client.add_user_playbook([playbook])

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True)
    else:
        print_info(f"User playbook added: {content[:80]}")


@app.command()
@handle_errors
def delete(
    ctx: typer.Context,
    id: Annotated[  # noqa: A002
        str,
        typer.Option("--id", help="User playbook ID"),
    ],
) -> None:
    """Delete a user playbook by ID.

    Args:
        ctx: Typer context with CliState in ctx.obj
        id: User playbook ID to delete
    """
    client = get_client(ctx)
    resp = client.delete_user_playbook(
        user_playbook_id=int(id),
        wait_for_response=True,
    )

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True)
    else:
        print_info(f"Deleted user playbook {id}")


@app.command(name="delete-all")
@handle_errors
def delete_all(
    ctx: typer.Context,
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompt"),
    ] = False,
) -> None:
    """Delete all user playbooks.

    Fetches all user playbook IDs, then deletes them in bulk via
    ``delete_user_playbooks_by_ids``.

    Args:
        ctx: Typer context with CliState in ctx.obj
        yes: If True, skip confirmation prompt
    """
    if not yes:
        confirmed = typer.confirm("Are you sure you want to delete all user playbooks?")
        if not confirmed:
            raise typer.Abort()

    client = get_client(ctx)

    # Fetch all user playbook IDs first, then delete by IDs
    all_playbooks = client.get_user_playbooks(limit=10000)
    raw_ids = [
        pb.id for pb in (all_playbooks.user_playbooks or []) if pb.id is not None
    ]

    if not raw_ids:
        json_mode: bool = ctx.obj.json_mode
        if json_mode:
            render({"deleted_count": 0}, json_mode=True)
        else:
            print_info("No user playbooks to delete")
        return

    resp = client.delete_user_playbooks_by_ids(user_playbook_ids=raw_ids)

    json_mode = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True)
    else:
        print_info(f"Deleted {len(raw_ids)} user playbook(s)")
