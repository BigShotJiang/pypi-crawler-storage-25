"""Diagnostic health check command."""

from __future__ import annotations

import os
import sys
from typing import Any

import requests
import typer

from reflexio.cli._client import _CONFIG_PATH, _DEFAULT_URL, _load_config_file
from reflexio.cli.errors import handle_errors
from reflexio.cli.output import render

app = typer.Typer(help="Diagnose Reflexio setup.")


@app.command("check")
@handle_errors
def doctor(ctx: typer.Context) -> None:
    """Run diagnostic checks on Reflexio configuration and connectivity."""
    json_mode = ctx.obj.json_mode
    state = ctx.obj
    checks: list[dict[str, Any]] = []

    # 1. Config file
    config_exists = _CONFIG_PATH.exists()
    checks.append(
        {
            "name": "config_file",
            "status": "pass" if config_exists else "warn",
            "message": f"Config file at {_CONFIG_PATH}"
            if config_exists
            else f"No config file at {_CONFIG_PATH}",
            "hint": None
            if config_exists
            else "Run: reflexio auth login --api-key KEY --server-url URL",
        }
    )

    # 2. Resolve connection info
    config = _load_config_file()
    url = (
        state.server_url
        or os.environ.get("REFLEXIO_URL")
        or config.get("url")
        or _DEFAULT_URL
    )
    api_key = (
        state.api_key
        or os.environ.get("REFLEXIO_API_KEY")
        or config.get("api_key")
        or ""
    )

    has_key = bool(api_key)
    checks.append(
        {
            "name": "api_key",
            "status": "pass" if has_key else "warn",
            "message": f"API key configured (****{api_key[-4:]})"
            if has_key
            else "No API key configured",
            "hint": None
            if has_key
            else "Set REFLEXIO_API_KEY env var or run: reflexio auth login --api-key KEY",
        }
    )

    # 3. Server connectivity
    headers: dict[str, str] = {}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    try:
        resp = requests.get(f"{url.rstrip('/')}/health", headers=headers, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        status = data.get("status", "unknown")
        checks.append(
            {
                "name": "server_health",
                "status": "pass" if status == "healthy" else "warn",
                "message": f"Server at {url} is {status}",
                "hint": None,
            }
        )
    except requests.ConnectionError:
        checks.append(
            {
                "name": "server_health",
                "status": "fail",
                "message": f"Cannot connect to {url}",
                "hint": "Start the server: reflexio services start",
            }
        )
    except requests.HTTPError as exc:
        code = exc.response.status_code if exc.response is not None else 0
        checks.append(
            {
                "name": "server_health",
                "status": "fail",
                "message": f"Server returned HTTP {code}",
                "hint": "Check server logs for details",
            }
        )

    # 4. Python version
    py_version = (
        f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )
    checks.append(
        {
            "name": "python_version",
            "status": "pass" if sys.version_info >= (3, 11) else "warn",
            "message": f"Python {py_version}",
            "hint": None if sys.version_info >= (3, 11) else "Python 3.11+ recommended",
        }
    )

    # Render output
    if json_mode:
        all_pass = all(c["status"] == "pass" for c in checks)
        render(checks, json_mode=True, meta={"all_pass": all_pass})
    else:
        for check in checks:
            icon = {"pass": "+", "warn": "~", "fail": "x"}[check["status"]]
            print(f"[{icon}] {check['name']}: {check['message']}")
            if check["hint"]:
                print(f"    Hint: {check['hint']}")

        fails = sum(1 for c in checks if c["status"] == "fail")
        if fails:
            raise SystemExit(1)
