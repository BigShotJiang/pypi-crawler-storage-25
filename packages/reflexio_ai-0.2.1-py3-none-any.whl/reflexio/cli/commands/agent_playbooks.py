"""Agent playbook management commands (list, search, delete, aggregate, regenerate)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Annotated

import typer

from reflexio.cli.errors import EXIT_VALIDATION, CliError, handle_errors

if TYPE_CHECKING:
    from reflexio.models.api_schema.service_schemas import PlaybookStatus
from reflexio.cli.output import (
    format_agent_playbooks,
    pagination_meta,
    print_info,
    render,
)
from reflexio.cli.state import get_client, resolve_agent_version

app = typer.Typer(help="Manage agent playbooks.")

_PLAYBOOK_STATUS_MAP = {
    "pending": "pending",
    "approved": "approved",
    "rejected": "rejected",
}


def _validate_playbook_status(value: str | None) -> PlaybookStatus | None:
    """Validate and convert a playbook status string to PlaybookStatus enum.

    Args:
        value (str | None): Raw status string from CLI input

    Returns:
        PlaybookStatus | None: Parsed enum value, or None if input is None

    Raises:
        CliError: If the value is not a valid playbook status
    """
    from reflexio.models.api_schema.service_schemas import PlaybookStatus

    if not value:
        return None
    if value not in _PLAYBOOK_STATUS_MAP:
        raise CliError(
            error_type="validation",
            message=f"Invalid playbook status: {value}. Must be pending, approved, or rejected.",
            exit_code=EXIT_VALIDATION,
        )
    return PlaybookStatus(value)


@app.command(name="list")
@handle_errors
def list_agent_playbooks(
    ctx: typer.Context,
    limit: Annotated[
        int,
        typer.Option("--limit", help="Maximum number of playbooks to return"),
    ] = 20,
    playbook_name: Annotated[
        str | None,
        typer.Option("--playbook-name", help="Filter by playbook name"),
    ] = None,
    agent_version: Annotated[
        str | None,
        typer.Option("--agent-version", help="Filter by agent version"),
    ] = None,
    playbook_status: Annotated[
        str | None,
        typer.Option(
            "--playbook-status",
            help="Filter by approval status (pending/approved/rejected)",
        ),
    ] = None,
) -> None:
    """List agent playbooks.

    Args:
        ctx: Typer context with CliState in ctx.obj
        limit: Maximum number of playbooks to return
        playbook_name: Optional playbook name filter
        agent_version: Optional agent version filter
        playbook_status: Optional approval status filter
    """
    pb_status_filter = _validate_playbook_status(playbook_status)

    client = get_client(ctx)
    resp = client.get_agent_playbooks(
        limit=limit,
        playbook_name=playbook_name,
        agent_version=agent_version,
        playbook_status_filter=pb_status_filter,
    )
    playbooks = resp.agent_playbooks or []

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(playbooks, json_mode=True, meta=pagination_meta(playbooks, limit))
    else:
        print_info(f"Found {len(playbooks)} agent playbook(s)")
        if playbooks:
            print(format_agent_playbooks(playbooks))


@app.command()
@handle_errors
def search(
    ctx: typer.Context,
    query: Annotated[
        str,
        typer.Argument(help="Semantic search query for agent playbooks"),
    ],
    limit: Annotated[
        int,
        typer.Option("--limit", help="Maximum number of results"),
    ] = 10,
    agent_version: Annotated[
        str | None,
        typer.Option("--agent-version", help="Agent version to filter by"),
    ] = None,
    playbook_status: Annotated[
        str | None,
        typer.Option(
            "--playbook-status",
            help="Filter by approval status (pending/approved/rejected)",
        ),
    ] = None,
) -> None:
    """Search agent playbooks by semantic query.

    Args:
        ctx: Typer context with CliState in ctx.obj
        query: Search query string
        limit: Maximum number of results
        agent_version: Optional agent version filter
        playbook_status: Optional approval status filter
    """
    pb_status_filter = _validate_playbook_status(playbook_status)

    client = get_client(ctx)

    resp = client.search_agent_playbooks(
        query=query,
        agent_version=agent_version,
        playbook_status_filter=pb_status_filter,
        top_k=limit,
    )
    playbooks = resp.agent_playbooks or []

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(playbooks, json_mode=True, meta=pagination_meta(playbooks, limit))
    else:
        print_info(f"Found {len(playbooks)} agent playbook(s)")
        if playbooks:
            print(format_agent_playbooks(playbooks))


@app.command()
@handle_errors
def delete(
    ctx: typer.Context,
    id: Annotated[  # noqa: A002
        str,
        typer.Option("--id", help="Agent playbook ID"),
    ],
) -> None:
    """Delete an agent playbook by ID.

    Args:
        ctx: Typer context with CliState in ctx.obj
        id: Agent playbook ID to delete
    """
    client = get_client(ctx)
    resp = client.delete_agent_playbook(
        agent_playbook_id=int(id),
        wait_for_response=True,
    )

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True)
    else:
        print_info(f"Deleted agent playbook {id}")


@app.command(name="delete-all")
@handle_errors
def delete_all(
    ctx: typer.Context,
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompt"),
    ] = False,
) -> None:
    """Delete all playbooks (user and agent).

    Args:
        ctx: Typer context with CliState in ctx.obj
        yes: If True, skip confirmation prompt
    """
    if not yes:
        confirmed = typer.confirm("Are you sure you want to delete all playbooks?")
        if not confirmed:
            raise typer.Abort()

    client = get_client(ctx)
    resp = client.delete_all_playbooks()

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True)
    else:
        print_info("All playbooks deleted")


@app.command()
@handle_errors
def aggregate(
    ctx: typer.Context,
    wait: Annotated[
        bool,
        typer.Option("--wait", help="Wait for aggregation to complete"),
    ] = False,
    agent_version: Annotated[
        str | None,
        typer.Option("--agent-version", help="Agent version to aggregate"),
    ] = None,
) -> None:
    """Run playbook aggregation to cluster similar user playbooks.

    Args:
        ctx: Typer context with CliState in ctx.obj
        wait: If True, wait for aggregation to complete
        agent_version: Optional agent version filter
    """
    client = get_client(ctx)
    resolved_version = resolve_agent_version(agent_version)

    resp = client.run_playbook_aggregation(
        agent_version=resolved_version,
        wait_for_response=wait,
    )

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True)
    elif wait:
        print_info("Aggregation complete")
    else:
        print_info("Aggregation started")


@app.command()
@handle_errors
def regenerate(
    ctx: typer.Context,
    wait: Annotated[
        bool,
        typer.Option("--wait", help="Wait for regeneration to complete"),
    ] = False,
    agent_version: Annotated[
        str | None,
        typer.Option("--agent-version", help="Agent version to regenerate"),
    ] = None,
) -> None:
    """Rerun playbook generation for an agent version.

    Args:
        ctx: Typer context with CliState in ctx.obj
        wait: If True, wait for regeneration to complete
        agent_version: Optional agent version filter
    """
    client = get_client(ctx)
    resolved_version = resolve_agent_version(agent_version)

    resp = client.rerun_playbook_generation(
        agent_version=resolved_version,
        wait_for_response=wait,
    )

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True)
    elif wait:
        print_info("Playbook regeneration complete")
    else:
        print_info("Playbook regeneration started")
