"""Profile management commands (list, search, delete, generate)."""

from __future__ import annotations

from typing import Annotated

import typer

from reflexio.cli.errors import EXIT_VALIDATION, CliError, handle_errors
from reflexio.cli.output import format_profiles, pagination_meta, print_info, render
from reflexio.cli.state import get_client, resolve_user_id

app = typer.Typer(help="Manage user profiles.")


@app.command(name="list")
@handle_errors
def list_profiles(
    ctx: typer.Context,
    user_id: Annotated[
        str | None,
        typer.Option("--user-id", help="User ID to filter profiles"),
    ] = None,
    limit: Annotated[
        int,
        typer.Option("--limit", help="Maximum number of profiles to return"),
    ] = 20,
    status: Annotated[
        str | None,
        typer.Option("--status", help="Status filter (current/pending/archived)"),
    ] = None,
) -> None:
    """List user profiles.

    Args:
        ctx: Typer context with CliState in ctx.obj
        user_id: Optional user ID filter
        limit: Maximum number of profiles to return
        status: Optional status filter (current, pending, archived)
    """
    if status and status not in ("current", "pending", "archived"):
        raise CliError(
            error_type="validation",
            message=f"Invalid status: {status}. Must be current, pending, or archived.",
            exit_code=EXIT_VALIDATION,
        )

    client = get_client(ctx)
    resolved_user_id = resolve_user_id(user_id)
    resp = client.get_profiles(
        user_id=resolved_user_id,
        top_k=limit,
        status_filter=[status] if status else None,
    )
    profiles = resp.user_profiles or []

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(profiles, json_mode=True, meta=pagination_meta(profiles, limit))
    else:
        print_info(f"Found {len(profiles)} profile(s)")
        if profiles:
            print(format_profiles(profiles))


@app.command()
@handle_errors
def search(
    ctx: typer.Context,
    query: Annotated[
        str,
        typer.Argument(help="Semantic search query for profiles"),
    ],
    user_id: Annotated[
        str | None,
        typer.Option("--user-id", help="User ID to filter profiles"),
    ] = None,
    limit: Annotated[
        int,
        typer.Option("--limit", help="Maximum number of results"),
    ] = 10,
    threshold: Annotated[
        float | None,
        typer.Option("--threshold", help="Similarity threshold"),
    ] = None,
) -> None:
    """Search profiles by semantic query.

    Args:
        ctx: Typer context with CliState in ctx.obj
        query: Search query string
        user_id: Optional user ID filter
        limit: Maximum number of results
        threshold: Optional similarity threshold
    """
    client = get_client(ctx)
    resolved_user_id = resolve_user_id(user_id)

    kwargs: dict = {
        "query": query,
        "user_id": resolved_user_id,
        "top_k": limit,
    }
    if threshold is not None:
        kwargs["threshold"] = threshold

    resp = client.search_profiles(**kwargs)
    profiles = resp.user_profiles or []

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(profiles, json_mode=True, meta=pagination_meta(profiles, limit))
    else:
        print_info(f"Found {len(profiles)} profile(s)")
        if profiles:
            print(format_profiles(profiles))


@app.command()
@handle_errors
def delete(
    ctx: typer.Context,
    user_id: Annotated[
        str,
        typer.Option("--user-id", help="User ID (required)"),
    ],
    profile_id: Annotated[
        str,
        typer.Option("--profile-id", help="Specific profile ID to delete"),
    ] = "",
) -> None:
    """Delete a user profile.

    Args:
        ctx: Typer context with CliState in ctx.obj
        user_id: User ID owning the profile
        profile_id: Specific profile ID to delete (empty string for all user profiles)
    """
    client = get_client(ctx)
    resp = client.delete_profile(
        user_id=user_id,
        profile_id=profile_id,
        wait_for_response=True,
    )

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True)
    else:
        label = (
            f"profile {profile_id}" if profile_id else f"profiles for user {user_id}"
        )
        print_info(f"Deleted {label}")


@app.command(name="delete-all")
@handle_errors
def delete_all(
    ctx: typer.Context,
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompt"),
    ] = False,
) -> None:
    """Delete all profiles.

    Args:
        ctx: Typer context with CliState in ctx.obj
        yes: If True, skip confirmation prompt
    """
    if not yes:
        confirmed = typer.confirm("Are you sure you want to delete all profiles?")
        if not confirmed:
            raise typer.Abort()

    client = get_client(ctx)
    resp = client.delete_all_profiles()

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True)
    else:
        print_info("All profiles deleted")


@app.command()
@handle_errors
def generate(
    ctx: typer.Context,
    user_id: Annotated[
        str,
        typer.Option("--user-id", help="User ID (required)"),
    ],
    wait: Annotated[
        bool,
        typer.Option("--wait", help="Wait for profile generation to complete"),
    ] = False,
) -> None:
    """Re-run profile generation for a user.

    Args:
        ctx: Typer context with CliState in ctx.obj
        user_id: User ID to generate profiles for
        wait: If True, wait for generation to complete
    """
    client = get_client(ctx)
    resp = client.rerun_profile_generation(
        user_id=user_id,
        wait_for_response=wait,
    )

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True)
    elif wait:
        print_info("Profile generation complete")
    else:
        print_info("Profile generation started")
