"""Configuration management commands (show, set)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from reflexio.cli.errors import EXIT_VALIDATION, CliError, handle_errors
from reflexio.cli.output import print_info, render
from reflexio.cli.state import get_client

app = typer.Typer(help="View and update server configuration.")


def _resolve_data(data: str) -> dict:
    """Resolve a JSON data string, supporting @filepath syntax.

    If the string starts with '@', reads the file at the given path
    and parses it as JSON. Otherwise, parses the string directly.

    Args:
        data: JSON string or @filepath reference

    Returns:
        dict: Parsed configuration data
    """
    if data.startswith("@"):
        return json.loads(Path(data[1:]).read_text())
    return json.loads(data)


@app.command()
@handle_errors
def show(
    ctx: typer.Context,
    show_all: Annotated[
        bool,
        typer.Option(
            "--all",
            help="Show all fields including unset optional settings with defaults",
        ),
    ] = False,
) -> None:
    """Show current server configuration.

    Args:
        ctx: Typer context with CliState in ctx.obj
        show_all: If True, include all fields (even None/default) in output
    """
    client = get_client(ctx)
    resp = client.get_config()

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True, exclude_none=not show_all)
    else:
        config_data = (
            resp.model_dump(mode="json", exclude_none=not show_all)
            if hasattr(resp, "model_dump")
            else resp
        )
        print_info("Server configuration:")
        print(json.dumps(config_data, indent=2, default=str))


@app.command(name="set")
@handle_errors
def set_config(
    ctx: typer.Context,
    data: Annotated[
        str | None,
        typer.Option("--data", help="JSON string or @filepath with config data"),
    ] = None,
    file: Annotated[
        Path | None,
        typer.Option("--file", help="Path to JSON config file"),
    ] = None,
) -> None:
    """Update server configuration.

    Provide configuration data via --data (inline JSON or @filepath) or --file.

    Args:
        ctx: Typer context with CliState in ctx.obj
        data: JSON string or @filepath with configuration data
        file: Path to a JSON configuration file
    """
    if not data and not file:
        raise CliError(
            error_type="validation",
            message="Must provide either --data or --file",
            hint="Use --data '{...}' or --data @path/to/config.json or --file path/to/config.json",
            exit_code=EXIT_VALIDATION,
        )

    if data and file:
        raise CliError(
            error_type="validation",
            message="Cannot provide both --data and --file",
            exit_code=EXIT_VALIDATION,
        )

    try:
        if data:
            config_data = _resolve_data(data)
        else:
            assert file is not None  # guaranteed by guard above  # noqa: S101
            config_data = json.loads(file.read_text())
    except (json.JSONDecodeError, FileNotFoundError, OSError) as exc:
        raise CliError(
            error_type="validation",
            message=f"Failed to parse config data: {exc}",
            exit_code=EXIT_VALIDATION,
        ) from exc

    client = get_client(ctx)
    resp = client.set_config(config_data)

    json_mode: bool = ctx.obj.json_mode
    if json_mode:
        render(resp, json_mode=True)
    else:
        print_info("Configuration updated")
