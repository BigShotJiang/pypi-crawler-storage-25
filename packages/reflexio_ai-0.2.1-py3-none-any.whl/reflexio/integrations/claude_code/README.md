# Reflexio + Claude Code Integration

**Reflexio helps Claude Code remember what it learns about you and your projects across sessions.** It extracts two types of knowledge from your conversations:

- **User Profiles** — facts about you, your preferences, and your environment (expertise, communication style, tools, project conventions, constraints)
- **User Playbooks** — behavioral rules for Claude, often derived from corrections but also from observing effective patterns (trigger → instruction, pitfall to avoid, rationale)

In future sessions, Reflexio searches for relevant profiles and playbooks before Claude responds — so Claude adapts to your style and doesn't repeat mistakes.

## How Reflexio Works

### What it extracts

**User Profiles** capture stable facts:
- About you: "senior backend engineer", "prefers concise responses"
- About your preferences: "always use type hints", "uses pnpm not npm"
- About your environment: "monorepo with pnpm workspaces", "company requires SOC2 compliance"

**User Playbooks** capture behavioral rules. Each playbook has a freeform **content** field — a natural-language summary that is the core of the playbook (e.g., "When creating search API endpoints that need complex filters, use POST with a request body instead of GET with query parameters"). Playbooks also include optional structured fields for richer context:
- **trigger**: the situation this rule applies to
- **instruction**: what Claude should do
- **pitfall**: what Claude should avoid
- **rationale**: why this rule matters

Playbooks are often extracted from corrections, but can also come from observing effective approaches or explicit instructions.

### How it flows

1. **Search** — Before Claude responds to your message, the `UserPromptSubmit` hook runs `reflexio search` with your message. Matching profiles and playbooks are injected as context Claude sees.
2. **Extract** — Knowledge is published to Reflexio in two ways (expert mode only):
   - **Automatic**: The expert skill detects when you correct Claude and publishes a curated summary immediately
   - **Manual**: You run `/reflexio-extract` to have Claude summarize the full conversation (including reasoning, tool calls, dead ends) and publish it

   In both cases, the Reflexio server LLM analyzes the published summary and extracts profiles and playbooks automatically.
3. **Apply** — In future sessions, Claude finds the relevant profiles and playbooks via search and follows them.

## Prerequisites

- **Python >=3.11** (the `reflexio-ai` package requires `>=3.11` — see `pyproject.toml`)
- **Node.js** (for the search hook that runs on every user message)
- **An LLM API key** (e.g., `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`) — needed for the Reflexio server's extraction pipeline. **Note:** If you're connecting to a remote Reflexio server that already has its own LLM keys configured, you don't need a local LLM key — you only need the `REFLEXIO_API_KEY` for authentication.
- **Claude Code** installed and working

## Install

```bash
pip install reflexio-ai
```

This installs:
- The **Reflexio client** (Python library for interacting with the Reflexio server)
- The **`reflexio` CLI** (built on top of the client — provides `reflexio search`, `reflexio publish`, `reflexio setup`, etc.)
- The **Reflexio server** (FastAPI backend that handles extraction and storage)
- The **Claude Code integration files** (skills, hooks, commands)

## Set Up Claude Code Integration

Navigate to your project directory and run:

```bash
cd your-project/
reflexio setup claude-code            # Normal mode (search-only)
# or
reflexio setup claude-code --expert   # Expert mode (search + publish + /reflexio-extract)
```

The setup wizard will:
1. Ask you to choose a storage backend (SQLite is the default — no external database needed)
2. Ask you to choose an LLM provider and enter your API key — **only if using local storage**. If you chose a cloud Supabase server, this step is skipped (the remote server handles extraction).
3. Configure `REFLEXIO_USER_ID=claude-code` for consistent user identification
4. Install the skill and search hook into your project's `.claude/` directory

### What gets installed

**Normal mode:**
- `.claude/skills/reflexio/SKILL.md` — the normal skill that teaches Claude to search Reflexio
- `.claude/settings.json` — adds `UserPromptSubmit` hook (runs `reflexio search` on every user message)

**Expert mode:**
- `.claude/skills/reflexio/SKILL.md` — the expert skill (different content from normal — includes instructions for publishing corrections and references `/reflexio-extract`)
- `.claude/commands/reflexio-extract/SKILL.md` — the `/reflexio-extract` slash command for manual extraction
- `.claude/settings.json` — same `UserPromptSubmit` hook as normal mode

### Local mode vs Remote mode

**Local mode** (default — SQLite):
- Reflexio server runs on your machine
- Data stored at `~/.reflexio/data/reflexio.db`
- No external database or cloud service needed
- Server auto-starts when Claude needs it
- **Requires:** an LLM API key for the extraction pipeline

**Remote mode — Local Supabase:**
- Reflexio server runs locally but stores data in a local Supabase instance
- Choose "Supabase" during setup and provide:
  - Supabase URL (default: `http://127.0.0.1:54321`)
  - Supabase key
  - Supabase DB URL (default: `postgresql://postgres:postgres@127.0.0.1:54322/postgres`)
  - Reflexio API key
- **Requires:** local Supabase running (via Docker), an LLM API key

**Remote mode — Cloud Supabase:**
- Reflexio server connects to a hosted Supabase instance
- Same setup as local Supabase, but with cloud URLs
- **Requires:** Supabase cloud account, `REFLEXIO_API_KEY` for authentication
- **Does not require** a local LLM API key if the remote server handles extraction

## Uninstall

```bash
cd your-project/
reflexio setup claude-code --uninstall
```

This removes the skill, commands, and hooks from your project. Your extracted data in `~/.reflexio/` is preserved.

To fully remove Reflexio:
```bash
pip uninstall reflexio-ai
rm -rf ~/.reflexio/    # delete all data, configs, and logs
```

---

## How to Use: Normal Mode

Normal mode is search-only — Claude searches Reflexio on **every message** you send (not just the first one). You don't need to do anything special.

### Step 1: Start Claude Code

```bash
cd your-project/
claude
```

### Step 2: Work normally

Give Claude any task. On every message you send:
1. The `UserPromptSubmit` hook runs `reflexio search` with your message
2. If relevant profiles or playbooks are found, Claude sees them before responding
3. Claude adapts: follows playbook instructions, respects your preferences from profiles

**First session:** No profiles or playbooks exist yet — this is the "cold start". Claude works as usual. To build up knowledge, switch to expert mode (which can auto-publish corrections and provides the `/reflexio-extract` command).

### Step 3: Correct Claude when needed

When Claude does something wrong, correct it naturally:

> **You:** Write a Python function to calculate area.
>
> **Claude:** *(writes function without type hints)*
>
> **You:** No, always use type hints in this project.

In normal mode, these corrections are **not** automatically published to Reflexio. To build up your knowledge base, switch to expert mode.

---

## How to Use: Expert Mode

Expert mode adds the ability to publish knowledge to Reflexio — both automatically (when Claude detects corrections) and manually (via `/reflexio-extract`).

### Step 1: Start Claude Code

```bash
cd your-project/
claude
```

### Step 2: Work and correct Claude

Give Claude tasks and correct mistakes as they come up:

> **You:** Write a Python function called `calculate_area` that takes width and height. Put it in `geometry.py`
>
> **Claude:** *(writes function)*
>
> **You:** Now add `calculate_perimeter` and `calculate_diagonal`.
>
> **Claude:** *(writes more functions)*
>
> **You:** No, all functions must have type hints and Google-style docstrings. Fix all three.

The expert skill detects this correction and publishes it to Reflexio automatically. You'll see Claude run a `reflexio publish` command.

### Step 3: Use `/reflexio-extract` for comprehensive extraction

At any point, run:

```
/reflexio-extract
```

Claude will:
1. Review the full conversation — including reasoning, tool calls, dead ends, and corrections
2. Summarize key learnings into a structured format
3. Publish to Reflexio for profile and playbook extraction

This captures richer context than the automatic mid-session publish because Claude includes its chain-of-thought reasoning and intermediate steps.

### Step 4: Verify what was extracted

```bash
# Check playbooks (behavioral rules)
reflexio user-playbooks list --user-id claude-code

# Check profiles (facts about you and your environment)
reflexio user-profiles list --user-id claude-code

# Test search (what Claude sees before responding)
reflexio search "write a Python function"
```

Note: `reflexio search` uses the `REFLEXIO_USER_ID` from your `.env` (set to `claude-code` by the setup wizard), so you don't need to pass `--user-id` explicitly.

### Step 5: Next session — knowledge applied

```bash
claude
```

> **You:** Write a function called `convert_temperature` that takes celsius and returns fahrenheit. Put it in `utils.py`
>
> **Claude:** *(searches Reflexio, finds the type hints + docstrings playbook, writes function with both from the start)*

No correction needed — Claude remembered.

---

## Normal vs Expert: Which to Choose?

| | Normal | Expert |
|---|---|---|
| **Search on every message** | ✓ Automatic (hook) | ✓ Automatic (hook) |
| **Auto-publish corrections** | ✗ | ✓ (skill detects corrections) |
| **`/reflexio-extract` command** | ✗ | ✓ (user-invoked) |
| **Best for** | Consuming knowledge from an existing server | Building up your knowledge base |
| **Complexity** | Zero — just use Claude normally | Low — corrections are auto-detected |

**Start with expert mode** if you're building knowledge from scratch. **Switch to normal mode** once you have a good knowledge base and just want to consume it.

---

## Monitoring & Troubleshooting

### Check server status

```bash
reflexio status check
```

### View server logs

```bash
cat ~/.reflexio/logs/server.log
```

### Query extracted data

```bash
# List playbooks
reflexio user-playbooks list --user-id claude-code

# List profiles
reflexio user-profiles list --user-id claude-code

# Search (what Claude sees on every message)
reflexio search "your task description"
```

### Query the SQLite database directly

```bash
# Count entities
sqlite3 ~/.reflexio/data/reflexio.db "
SELECT 'playbooks' as type, count(*) FROM user_playbooks
UNION ALL SELECT 'profiles', count(*) FROM profiles
UNION ALL SELECT 'interactions', count(*) FROM interactions;
"

# View playbook details
sqlite3 ~/.reflexio/data/reflexio.db "
SELECT content, structured_data FROM user_playbooks
ORDER BY user_playbook_id DESC LIMIT 5;
"
```

### Common issues

| Problem | Solution |
|---------|----------|
| `reflexio: command not found` | `pip install reflexio-ai` |
| Search returns 0 results | Cold start — no knowledge yet. Use expert mode to publish. |
| Server not starting | Check `~/.reflexio/logs/server.log`. Ensure LLM API key is set. |
| Skill not loading | Verify `.claude/skills/reflexio/SKILL.md` exists in your project. |
| Wrong user_id | Run `reflexio setup claude-code` to reconfigure. |

---

## How It Works (Technical)

```
User sends message to Claude Code
  │
  ├── UserPromptSubmit hook fires (every message)
  │     └── search_hook.js runs `reflexio search "<message>" --user-id claude-code`
  │     └── Matching profiles + playbooks injected as context
  │
  ├── Claude responds (adapting to profiles, following playbooks)
  │
  ├── [Expert] If user corrects Claude:
  │     └── Skill publishes curated summary
  │     └── Server extracts profiles + playbooks
  │
  └── [Expert] User runs /reflexio-extract (optional):
        └── Claude summarizes full conversation with reasoning context
        └── Server extracts profiles + playbooks
```

### File structure

```
your-project/
└── .claude/
    ├── settings.json                    ← Hook configuration
    ├── skills/
    │   └── reflexio/
    │       └── SKILL.md                 ← Normal or expert skill
    └── commands/                         ← Expert mode only
        └── reflexio-extract/
            └── SKILL.md                 ← /reflexio-extract command

~/.reflexio/
├── .env                                 ← API keys, REFLEXIO_USER_ID
├── data/
│   └── reflexio.db                      ← SQLite database
├── configs/
│   └── config_self-host-org.json        ← Server configuration
└── logs/
    └── server.log                       ← Server logs
```
