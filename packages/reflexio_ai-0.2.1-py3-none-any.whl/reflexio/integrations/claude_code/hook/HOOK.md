---
name: reflexio-capture
description: "Capture Claude Code session transcripts and publish to Reflexio for automatic playbook and profile extraction"
events: ["Stop"]
requires:
  bins: ["reflexio", "node"]
---

# Reflexio Capture Hook

Automatically captures Claude Code session transcripts at session end and publishes them to Reflexio for self-improvement.

## What It Does

### On `Stop` (session end)

1. Reads the session transcript JSONL file from `transcript_path` in the event payload
2. Extracts user queries and assistant text responses (skips thinking blocks, tool calls, system messages)
3. Writes the formatted payload to a temp file
4. Spawns a detached `reflexio interactions publish --file <payload>` process (fire-and-forget)
5. Outputs `{}` on stdout and exits immediately — does not block session shutdown

The Reflexio server then analyzes the conversation for learning signals (corrections, friction, re-steering) and extracts playbooks and user profiles automatically.

## Prerequisites

- The `reflexio` CLI installed and on PATH (`pip install reflexio`)
- A running Reflexio server (local or remote)
- Node.js runtime (for the hook script)

## Configuration

| Variable | Default | Required | Description |
|----------|---------|----------|-------------|
| `REFLEXIO_URL` | `http://127.0.0.1:8081` | No | Reflexio server URL (configured via `reflexio auth login`) |
| `REFLEXIO_API_KEY` | — | Cloud mode only | API key for authenticated access to remote Reflexio server |
| `REFLEXIO_USER_ID` | `claude-code` | No | User ID for scoping profiles and playbooks |
| `REFLEXIO_AGENT_VERSION` | `claude-code` | No | Agent version tag for playbook filtering |

## Installation

Add to your Claude Code `settings.json` (user or project level):

```json
{
  "hooks": {
    "Stop": [
      {
        "type": "command",
        "command": "node /path/to/reflexio/integrations/claude_code/hook/handler.js"
      }
    ]
  }
}
```

## Safety

- The hook checks `stop_hook_active` to prevent infinite loops
- Publishing is fire-and-forget — failures do not affect the Claude Code session
- Transcript data is written to a temp file with restricted permissions (0600)
- The temp file is cleaned up after publishing
