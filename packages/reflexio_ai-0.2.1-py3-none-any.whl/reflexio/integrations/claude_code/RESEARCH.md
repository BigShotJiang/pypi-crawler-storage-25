# Claude Code Integration Mechanisms: Research Report

This document synthesizes research into Claude Code's extension architecture, with a focus on
identifying the right integration surface for Reflexio's playbook system (corrections and
learning from past mistakes). It covers all six extension mechanisms, deep dives into hooks
and MCP/plugins, the JSONL transcript format, and the architecture decision rationale for
choosing Hook + Skill as Reflexio's integration approach.

---

## Table of Contents

1. [Claude Code's Six Extension Mechanisms](#1-claude-codes-six-extension-mechanisms)
2. [Hook System Deep Dive](#2-hook-system-deep-dive)
3. [MCP Server Architecture](#3-mcp-server-architecture)
4. [Plugin System](#4-plugin-system)
5. [JSONL Transcript Format](#5-jsonl-transcript-format)
6. [Architecture Decision: Why Hook + Skill](#6-architecture-decision-why-hook--skill)
7. [Comparison with OpenClaw and LangChain](#7-comparison-with-openclaw-and-langchain)

---

## 1. Claude Code's Six Extension Mechanisms

Claude Code provides six complementary extension layers, each at a different abstraction level:

```
+-------------------------------------------------------------------+
|                    CLAUDE CODE CLI SESSION                         |
|                                                                   |
|  +-------------------------------------------------------------+ |
|  |  CLAUDE.md / .claude/rules/   (Advisory project context)    | |
|  +-------------------------------------------------------------+ |
|                                                                   |
|  +-------------------------------------------------------------+ |
|  |  Skills (.claude/skills/ & .claude/commands/)                | |
|  |  Model-invoked or user-invoked markdown instruction sets     | |
|  +-------------------------------------------------------------+ |
|                                                                   |
|  +-------------------------------------------------------------+ |
|  |  Hooks (settings.json)                                       | |
|  |  Deterministic lifecycle event handlers                      | |
|  |  (command / prompt / agent / http handler types)             | |
|  +-------------------------------------------------------------+ |
|                                                                   |
|  +-------------------------------------------------------------+ |
|  |  MCP Servers (stdio / HTTP / SSE transports)                 | |
|  |  External tool + data source connections                     | |
|  +-------------------------------------------------------------+ |
|                                                                   |
|  +-------------------------------------------------------------+ |
|  |  Plugins (.claude-plugin/)                                   | |
|  |  Shareable bundles: skills + hooks + MCP + agents            | |
|  +-------------------------------------------------------------+ |
|                                                                   |
|  +-------------------------------------------------------------+ |
|  |  Agent Teams (experimental)                                  | |
|  |  Multi-session orchestration: TeamCreate, SendMessage, Tasks | |
|  +-------------------------------------------------------------+ |
+-------------------------------------------------------------------+
```

### 1.1 CLAUDE.md and Rules

Markdown files providing persistent project context. Read automatically at session start.

- `~/.claude/CLAUDE.md` -- user-global instructions
- `./CLAUDE.md` or `./.claude/CLAUDE.md` -- project-level
- `./subdir/CLAUDE.md` -- sub-directory scoped
- `.claude/rules/*.md` -- topic-specific rules with optional path-scoped frontmatter

**Characteristics**: Advisory (~80% compliance), zero-infrastructure, version-controlled.
Best for coding standards, architecture decisions, and project conventions.

### 1.2 Skills

Folders containing a `SKILL.md` file that Claude discovers dynamically. Two modes:

- **Slash commands** (`/commit`, `/review`) -- user-invoked workflows in `.claude/commands/`
- **Auto-invoked knowledge** -- Claude loads automatically when context matches, in `.claude/skills/`

SKILL.md frontmatter fields:
- `name` -- becomes the `/slash-command`
- `description` -- helps Claude decide when to auto-load
- `allowed-tools` -- additional tool permissions while skill is active
- `disable-model-invocation: true` -- only user can invoke (for side-effect workflows)
- `user-invocable: false` -- only Claude invokes (for background knowledge)

**Characteristics**: Zero infrastructure, version-controlled, advisory. Cannot execute code
directly; they instruct Claude what to do. Recommended size: under 500 lines for SKILL.md
with reference material in separate files.

### 1.3 Hooks

Deterministic lifecycle event handlers that fire every time, regardless of model behavior.
Configured in `settings.json` (not CLAUDE.md). Four handler types: command, prompt, agent, http.

See [Section 2](#2-hook-system-deep-dive) for the full deep dive.

### 1.4 MCP Servers

Model Context Protocol servers expose external tools, resources, and prompts to Claude via a
standard protocol. Three transports: stdio (local process), HTTP (recommended for remote),
SSE (deprecated).

See [Section 3](#3-mcp-server-architecture) for the full deep dive.

### 1.5 Plugins

Distribution packaging that bundles skills, hooks, MCP servers, agents, and commands into a
single installable unit. Installed from marketplaces (Anthropic official or custom).

See [Section 4](#4-plugin-system) for details.

### 1.6 Agent Teams

Experimental feature (released with Claude Opus 4.6, Feb 2026) for orchestrating 2-16
independent Claude Code sessions working on a shared project. Each teammate has its own
context window. Coordination happens via shared task lists and peer-to-peer messaging
(TeamCreate, TaskCreate, SendMessage tools).

### 1.7 Feature Comparison

| Feature | CLAUDE.md | Skills | Hooks | MCP | Plugins | Agent Teams |
|---------|-----------|--------|-------|-----|---------|-------------|
| **Deterministic** | No (~80%) | No | Yes (100%) | Yes | Mixed | Yes |
| **External access** | No | No | Limited (shell) | Yes (any API) | Yes | Inherited |
| **Setup complexity** | Trivial | Low | Medium | Medium-High | Medium | Low |
| **Can block actions** | No | No | Yes | No | Via hooks | No |
| **Provides knowledge** | Yes | Yes | No | Yes (data) | Yes | No |
| **Auto-invoked** | Always | Context-matched | Event-driven | Tool-called | Per-component | Task-driven |

---

## 2. Hook System Deep Dive

### 2.1 Event Catalog (25 events)

| # | Event | When It Fires | Matcher Field | Can Block? |
|---|-------|--------------|---------------|------------|
| 1 | `SessionStart` | Session begins or resumes | `source`: startup, resume, clear, compact | No |
| 2 | `UserPromptSubmit` | User submits a prompt | No matcher | Yes |
| 3 | `PreToolUse` | Before a tool call executes | `tool_name` (regex) | Yes |
| 4 | `PermissionRequest` | When permission dialog would appear | `tool_name` (regex) | Yes |
| 5 | `PostToolUse` | After a tool call succeeds | `tool_name` (regex) | No* |
| 6 | `PostToolUseFailure` | After a tool call fails | `tool_name` (regex) | No |
| 7 | `Notification` | Claude sends a notification | `notification_type` | No |
| 8 | `SubagentStart` | A subagent is spawned | `agent_type` | No |
| 9 | `SubagentStop` | A subagent finishes | `agent_type` | Yes |
| 10 | `TaskCreated` | Task created via TaskCreate | No matcher | Yes |
| 11 | `TaskCompleted` | Task marked completed | No matcher | Yes |
| 12 | `Stop` | Claude finishes responding | No matcher | Yes |
| 13 | `StopFailure` | Turn ends due to API error | `error` | No |
| 14 | `TeammateIdle` | Agent team teammate going idle | No matcher | Yes |
| 15 | `InstructionsLoaded` | CLAUDE.md or rules file loaded | `load_reason` | No |
| 16 | `ConfigChange` | Configuration file changes | `source` | Yes |
| 17 | `CwdChanged` | Working directory changes | No matcher | No |
| 18 | `FileChanged` | Watched file changes on disk | Filename | No |
| 19 | `WorktreeCreate` | Worktree being created | No matcher | Yes |
| 20 | `WorktreeRemove` | Worktree being removed | No matcher | No |
| 21 | `PreCompact` | Before context compaction | `compaction_trigger` | No |
| 22 | `PostCompact` | After context compaction | `compaction_trigger` | No |
| 23 | `Elicitation` | MCP server requests user input | `mcp_server_name` | Yes |
| 24 | `ElicitationResult` | User responds to MCP elicitation | `mcp_server_name` | Yes |
| 25 | `SessionEnd` | Session terminates | `reason` | No |

*PostToolUse `decision:block` shows feedback to Claude but does not reverse the action.

### 2.2 Common Input Fields (All Events)

```json
{
  "session_id": "string",
  "transcript_path": "string (absolute path to conversation JSONL)",
  "cwd": "string (current working directory)",
  "permission_mode": "default|plan|acceptEdits|auto|dontAsk|bypassPermissions",
  "hook_event_name": "string",
  "agent_id": "string (optional, present in subagent context)",
  "agent_type": "string (optional)"
}
```

### 2.3 Key Event Payloads

**PreToolUse**:
```json
{
  "tool_name": "Bash|Edit|Write|Read|Glob|Grep|Agent|WebFetch|WebSearch|mcp__<server>__<tool>",
  "tool_input": { /* varies by tool */ },
  "tool_use_id": "string"
}
```

Tool input schemas by tool:
- **Bash**: `{ "command": "string", "description": "string?", "timeout": "number?", "run_in_background": "boolean?" }`
- **Write**: `{ "file_path": "string", "content": "string" }`
- **Edit**: `{ "file_path": "string", "old_string": "string", "new_string": "string", "replace_all": "boolean?" }`
- **Read**: `{ "file_path": "string", "offset": "number?", "limit": "number?" }`
- **Glob**: `{ "pattern": "string", "path": "string?" }`
- **Grep**: `{ "pattern": "string", "path": "string?", "glob": "string?", "output_mode": "string?", "-i": "boolean?", "multiline": "boolean?" }`
- **Agent**: `{ "prompt": "string", "description": "string?", "subagent_type": "string", "model": "string?" }`

**PostToolUse** (same as PreToolUse plus):
```json
{
  "tool_response": { /* tool's actual output, varies by tool */ },
  "tool_use_id": "string"
}
```

**Stop**:
```json
{
  "stop_hook_active": "boolean (true if recursive -- check to prevent infinite loops)",
  "last_assistant_message": "string (Claude's final response text)"
}
```

**SubagentStop**:
```json
{
  "stop_hook_active": "boolean",
  "agent_id": "string",
  "agent_type": "string",
  "agent_transcript_path": "string (path to subagent's JSONL)",
  "last_assistant_message": "string"
}
```

**SessionStart**:
```json
{
  "source": "startup|resume|clear|compact",
  "model": "string (e.g. claude-sonnet-4-20250514)"
}
```

**UserPromptSubmit**:
```json
{
  "prompt": "string (the text the user submitted)"
}
```

### 2.4 Handler Types

#### Command Handler (`type: "command"`)

```json
{
  "type": "command",
  "command": "string (shell command)",
  "async": "boolean (default: false)",
  "shell": "bash|powershell (default: bash)",
  "if": "string (permission rule syntax, tool events only, v2.1.85+)",
  "timeout": "number (seconds, default: 600)",
  "statusMessage": "string (spinner message)",
  "once": "boolean (skills only, run once per session)"
}
```

Event JSON is piped to the script's stdin. Communication via exit codes and stdout/stderr:
- Exit 0 = proceed (stdout parsed as JSON)
- Exit 2 = block (stderr fed to Claude as feedback)
- Other = non-blocking error

#### HTTP Handler (`type: "http"`)

```json
{
  "type": "http",
  "url": "string (POST endpoint)",
  "headers": { "HeaderName": "value with $VAR_NAME interpolation" },
  "allowedEnvVars": ["VAR_NAME1"],
  "timeout": "number (seconds, default: 30)"
}
```

POSTs the same JSON a command hook receives. Response body parsed like command hook output.
Cannot block via HTTP status code alone -- must return 2xx with JSON decision fields.

#### Prompt Handler (`type: "prompt"`)

```json
{
  "type": "prompt",
  "prompt": "string (sent to Claude model, use $ARGUMENTS for event JSON)",
  "model": "string (optional, defaults to fast model like Haiku)",
  "timeout": "number (seconds, default: 30)"
}
```

Returns `{ "ok": true }` or `{ "ok": false, "reason": "..." }`. Best for decisions
requiring LLM judgment rather than deterministic rules.

#### Agent Handler (`type: "agent"`)

```json
{
  "type": "agent",
  "prompt": "string (task for the agent, $ARGUMENTS for event JSON)",
  "timeout": "number (seconds, default: 60)"
}
```

Spawns a subagent with access to Read, Grep, Glob, Bash tools (up to 50 tool-use turns).
Returns same ok/reason format. Most powerful but slowest.

### 2.5 Configuration Locations

| Location | Scope | Shareable |
|----------|-------|-----------|
| `~/.claude/settings.json` | All projects | No |
| `.claude/settings.json` | Single project | Yes (commit to repo) |
| `.claude/settings.local.json` | Single project | No (gitignored) |
| Managed policy settings | Organization-wide | Yes (admin-controlled) |
| Plugin `hooks/hooks.json` | When plugin enabled | Yes |
| Skill/agent frontmatter | While component active | Yes |

Configuration structure:
```json
{
  "hooks": {
    "EventName": [
      {
        "matcher": "regex_pattern",
        "hooks": [
          { "type": "command|http|prompt|agent", ... }
        ]
      }
    ]
  }
}
```

### 2.6 The `if` Field (v2.1.85+)

Filters by tool name AND arguments together, inside the individual hook handler:

```json
{
  "hooks": {
    "PreToolUse": [{
      "matcher": "Bash",
      "hooks": [{
        "type": "command",
        "if": "Bash(git *)",
        "command": ".claude/hooks/check-git-policy.sh"
      }]
    }]
  }
}
```

Only works on tool events: PreToolUse, PostToolUse, PostToolUseFailure, PermissionRequest.

### 2.7 Hook Output Schemas

**PreToolUse output** (to modify/block):
```json
{
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "allow|deny",
    "updatedInput": { /* modified tool input */ }
  }
}
```

**PostToolUse output** (feedback to Claude):
```json
{
  "decision": "block",
  "reason": "Explanation shown to Claude",
  "hookSpecificOutput": {
    "hookEventName": "PostToolUse",
    "additionalContext": "string (appended to tool result context)",
    "updatedMCPToolOutput": "any (MCP tools only -- replaces tool output)"
  }
}
```

**Stop output** (force continuation):
```json
{
  "decision": "block",
  "reason": "Tests have not been run yet. Please run the test suite."
}
```

### 2.8 Environment Variables Available to Hooks

| Variable | Available in | Description |
|----------|-------------|-------------|
| `CLAUDE_PROJECT_DIR` | All hooks | Project root directory |
| `CLAUDE_PLUGIN_ROOT` | Plugin hooks | Plugin installation directory |
| `CLAUDE_PLUGIN_DATA` | Plugin hooks | Plugin persistent data directory |
| `CLAUDE_CODE_REMOTE` | All hooks | "true" in remote environments |
| `CLAUDE_ENV_FILE` | SessionStart, CwdChanged, FileChanged | Path for environment persistence |

### 2.9 Key Limitations

1. **Cannot trigger slash commands or tool calls.** Hooks communicate only through stdout/stderr/exit codes.
2. **Cannot directly modify Claude's text or reasoning.** They provide context and block operations.
3. **Cannot inject messages as user/assistant turns.** Text returned via `additionalContext` is a system reminder.
4. **PostToolUse cannot reliably inject context for built-in tools.** Issue #18427 (closed NOT PLANNED) confirmed `additionalContext` does not work reliably for Edit, Write, etc. Partially works for MCP tools.
5. **Cannot undo tool actions.** PostToolUse fires after execution.
6. **When multiple PreToolUse hooks return `updatedInput`, the last one wins** (non-deterministic order).
7. **`PermissionRequest` hooks do not fire in non-interactive mode (`-p`).** Use PreToolUse for headless.
8. **Cannot access Claude's internal reasoning/thinking.** Only visible text in `last_assistant_message`.
9. **Cannot modify conversation history.** `transcript_path` is read-only from the hook's perspective.
10. **`Stop` hooks fire on every response, not just task completion.** Hook must determine if task is done.
11. **Async hooks have no decision control.** Exit codes and JSON output are ignored.
12. **Shell profile `echo` statements break JSON parsing.** Must wrap in `[[ $- == *i* ]]` guards.

### 2.10 What Hooks CAN Do

- Read the full conversation transcript via `transcript_path`
- Block tool execution (PreToolUse exit 2 or permissionDecision: deny)
- Modify tool input before execution (PreToolUse `updatedInput`)
- Auto-approve permission prompts (PermissionRequest behavior: allow)
- Inject context into Claude's prompt (SessionStart/UserPromptSubmit stdout)
- Force Claude to continue working (Stop decision: block with reason)
- Run external commands, HTTP requests, or LLM evaluations
- Persist environment variables via `CLAUDE_ENV_FILE`
- Replace MCP tool output (PostToolUse `updatedMCPToolOutput`)
- Enforce policy that cannot be bypassed (PreToolUse deny works even in bypassPermissions mode)

---

## 3. MCP Server Architecture

### 3.1 Protocol Fundamentals

MCP (Model Context Protocol) is an open standard using **JSON-RPC 2.0** over the wire.
Current specification version: **`2025-11-25`** (previous: `2024-11-05`).

**Request**:
```json
{ "jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": { "name": "my-tool", "arguments": {} } }
```

**Response**:
```json
{ "jsonrpc": "2.0", "id": 1, "result": { ... } }
```

**Notification** (no response expected):
```json
{ "jsonrpc": "2.0", "method": "notifications/initialized" }
```

### 3.2 Initialization Handshake

1. Client sends `initialize` with protocol version, capabilities, and client info
2. Server responds with its capabilities and server info
3. Client sends `initialized` notification

Client capabilities: `roots`, `sampling`, `elicitation`, `tasks`
Server capabilities: `tools`, `resources`, `prompts`, `logging`, `completions`, `tasks`

### 3.3 Transport Types

| Transport | Status | Use Case |
|-----------|--------|----------|
| **stdio** | Active | Local processes, scripts |
| **Streamable HTTP** | Active (recommended) | Remote cloud services |
| **SSE** | Deprecated | Legacy remote servers |

### 3.4 Configuration Format

**Stdio** (local process):
```json
{
  "mcpServers": {
    "my-server": {
      "command": "npx",
      "args": ["-y", "@company/mcp-server"],
      "env": { "API_KEY": "value" }
    }
  }
}
```

**HTTP** (remote):
```json
{
  "mcpServers": {
    "my-api": {
      "type": "http",
      "url": "https://mcp.example.com/mcp",
      "headers": { "Authorization": "Bearer ${API_KEY}" }
    }
  }
}
```

**Configuration file locations** (precedence: local > project > user):

| Scope | File |
|-------|------|
| Local | `~/.claude.json` (under project path key) |
| Project | `.mcp.json` in project root (version-controlled) |
| User | `~/.claude.json` (global `mcpServers` key) |
| Managed | `/Library/Application Support/ClaudeCode/managed-mcp.json` (macOS) |

Environment variable expansion: `${VAR}` and `${VAR:-default}` supported in command, args, env, url, headers.

### 3.5 Official SDKs

| SDK | Package | Tier |
|-----|---------|------|
| TypeScript | `@modelcontextprotocol/sdk` | Tier 1 |
| Python | `mcp` (pip: `mcp[cli]`) | Tier 1 |
| C# | csharp-sdk | Tier 1 |
| Go | go-sdk | Tier 1 |
| Java | java-sdk | Tier 2 |
| Rust | rust-sdk | Tier 2 |
| Swift, Ruby, PHP | respective SDKs | Tier 3 |

### 3.6 Minimal Python MCP Server

```python
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Demo")

@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    return f"Hello, {name}!"

if __name__ == "__main__":
    mcp.run(transport="streamable-http")  # or "stdio"
```

### 3.7 Claude Code MCP Support

- **Tools**: Full support; MCP tools appear alongside built-in tools
- **Resources**: Yes, via `@server:protocol://path` mentions
- **Prompts**: Yes, as `/mcp__servername__promptname` commands
- **Elicitation**: Yes, displays form dialogs or opens browser URLs
- **Deferred tool loading**: Only tool names loaded at start; full definitions fetched on demand via ToolSearch
- **`list_changed` notifications**: Supported; servers can add/remove tools at runtime

### 3.8 Lifecycle in Claude Code

1. At session start, reads MCP configs from all applicable scopes
2. For stdio: spawns child process, connects via stdin/stdout
3. For HTTP: establishes HTTP connection to URL
4. Performs MCP `initialize` handshake
5. Tool names loaded into context (full definitions deferred)

**Startup timeout**: Configurable via `MCP_TIMEOUT` env var.
**Output limits**: Warning at 10,000 tokens; default max 25,000 (configurable via `MAX_MCP_OUTPUT_TOKENS`).
**Crash behavior**: Stdio crashes lose connection; no automatic restart for user-configured servers.

---

## 4. Plugin System

### 4.1 What Plugins Are

A plugin is a self-contained directory that extends Claude Code with skills, agents, hooks,
MCP servers, LSP servers, commands, and output styles. Installed from marketplaces.

### 4.2 Directory Structure

```
my-plugin/
  .claude-plugin/
    plugin.json            # Metadata (optional -- auto-discovery if omitted)
  commands/                # Slash commands
  agents/                  # Subagent definitions
  skills/                  # Skills with SKILL.md
  output-styles/           # Output style definitions
  hooks/
    hooks.json             # Hook configurations
  settings.json            # Default settings
  .mcp.json                # MCP server definitions
  .lsp.json                # LSP server configs
  scripts/                 # Hook/utility scripts
```

### 4.3 plugin.json Schema

```json
{
  "name": "plugin-name",
  "version": "2.1.0",
  "description": "Brief description",
  "author": { "name": "Name", "email": "email", "url": "url" },
  "homepage": "https://...",
  "repository": "https://...",
  "license": "MIT",
  "keywords": ["keyword1"],
  "commands": ["./custom/commands/special.md"],
  "agents": "./custom/agents/",
  "skills": "./custom/skills/",
  "hooks": "./config/hooks.json",
  "mcpServers": "./mcp-config.json",
  "outputStyles": "./styles/",
  "lspServers": "./.lsp.json",
  "userConfig": {
    "api_endpoint": { "description": "Your API endpoint", "sensitive": false },
    "api_token": { "description": "API token", "sensitive": true }
  },
  "channels": [
    { "server": "telegram", "userConfig": { "bot_token": { "description": "...", "sensitive": true } } }
  ]
}
```

### 4.4 Installation and Management

```bash
# Install
claude plugin install <name>@<marketplace> [--scope user|project|local]

# Manage
claude plugin enable <name>@<marketplace>
claude plugin disable <name>@<marketplace>
claude plugin update <name>@<marketplace>
claude plugin uninstall <name>@<marketplace>
claude plugin validate

# In-session
/plugin install <name>@<marketplace>
/reload-plugins
```

### 4.5 Marketplace Format

Default: `anthropics/claude-plugins-official` (200+ plugins, automatically available).

Custom marketplaces added via:
```bash
/plugin marketplace add anthropics/claude-code          # GitHub shorthand
/plugin marketplace add ./local-path                     # Local directory
/plugin marketplace add https://example.com/marketplace.json  # URL
```

marketplace.json format:
```json
{
  "$schema": "https://anthropic.com/claude-code/marketplace.schema.json",
  "name": "my-marketplace",
  "plugins": [
    {
      "name": "plugin-name",
      "description": "Brief description",
      "category": "development",
      "source": "./plugins/my-plugin",
      "version": "1.0.0"
    }
  ]
}
```

### 4.6 Environment Variables for Plugins

- `${CLAUDE_PLUGIN_ROOT}` -- plugin installation directory (changes on update)
- `${CLAUDE_PLUGIN_DATA}` -- persistent data directory (~/.claude/plugins/data/{id}/, survives updates)
- `${user_config.KEY}` -- substituted from userConfig values
- `CLAUDE_PLUGIN_OPTION_<KEY>` -- userConfig as env vars for subprocesses

### 4.7 Plugin Caching

Marketplace plugins are copied to `~/.claude/plugins/cache/` rather than used in-place.
Paths traversing outside the plugin root (like `../shared-utils`) will not work.

---

## 5. JSONL Transcript Format

### 5.1 Location

Session transcripts are stored at:
```
~/.claude/projects/<project-hash>/<session-id>.jsonl
```

Where `<project-hash>` is the absolute path with `/` replaced by `-` (e.g.,
`-Users-name-projects-foo`).

### 5.2 Entry Types

Each line is one JSON object. The `type` field determines the entry kind.

**Types observed**: `user`, `assistant`, `system`, `file-history-snapshot`, `progress`, `last-prompt`

### 5.3 Common Fields (All Entries)

```json
{
  "uuid": "string (unique ID)",
  "parentUuid": "string (parent in conversation tree)",
  "isSidechain": "boolean",
  "timestamp": "ISO 8601",
  "sessionId": "UUID",
  "version": "string (Claude Code version, e.g. 2.1.78)",
  "userType": "external",
  "entrypoint": "cli",
  "cwd": "string (working directory)",
  "gitBranch": "string"
}
```

### 5.4 Message Entry Schemas

**User message** (`type: "user"`):
```json
{
  "type": "user",
  "promptId": "string",
  "message": { "role": "user", "content": "string" },
  "isMeta": "boolean"
}
```

**Assistant message** (`type: "assistant"`):
```json
{
  "type": "assistant",
  "message": {
    "model": "claude-sonnet-4-20250514",
    "id": "msg_...",
    "type": "message",
    "role": "assistant",
    "content": [
      { "type": "text", "text": "..." },
      { "type": "tool_use", "id": "toolu_...", "name": "Edit", "input": { ... } }
    ]
  },
  "requestId": "req_...",
  "slug": "string"
}
```

**File history snapshot** (`type: "file-history-snapshot"`):
```json
{
  "type": "file-history-snapshot",
  "messageId": "string",
  "snapshot": {
    "messageId": "string",
    "trackedFileBackups": { ... },
    "timestamp": "string"
  },
  "isSnapshotUpdate": "boolean"
}
```

### 5.5 Access from Hooks

Hooks receive `transcript_path` in their input payload, pointing to the full JSONL file.
Scripts can read and parse the entire conversation history. The transcript is read-only from
the hook's perspective -- writing to it has no effect on what Claude sees.

### 5.6 Session Metadata

Active sessions tracked in `~/.claude/sessions/{pid}.json`:
```json
{
  "pid": 71690,
  "sessionId": "de8f7816-8c2d-4060-a434-51721c08238a",
  "cwd": "/Users/.../project",
  "startedAt": 1775000481242
}
```

---

## 6. Architecture Decision: Why Hook + Skill

### 6.1 Requirements for Reflexio's Playbook Integration

Reflexio's playbook system needs to:
1. **Capture**: Record Claude Code interactions (what was attempted, what went wrong, corrections made)
2. **Retrieve**: Before Claude acts, fetch relevant playbooks to prevent repeated mistakes
3. **Inject**: Provide playbook context so Claude applies learned corrections
4. **Enforce**: Ensure playbooks are consulted deterministically, not advisory

### 6.2 Why Not MCP Server Alone

An MCP server would make Reflexio's tools callable by Claude, but has critical gaps:

- **No lifecycle hooks**: MCP tools are called when Claude decides to, not deterministically at specific lifecycle points. There is no way to force Claude to consult playbooks before every tool use.
- **Advisory, not enforced**: Claude might skip calling the MCP tool, especially under context pressure or when it believes the task is straightforward.
- **No transcript access**: MCP servers do not receive the session transcript or session ID directly. They cannot passively observe the conversation to capture interactions.
- **Latency per call**: Each MCP tool call adds network latency. For something that should happen on every tool use, this compounds.
- **Output limits**: MCP output is capped at 25,000 tokens by default. Playbook context could be large.

### 6.3 Why Not Plugin Alone

A plugin could bundle everything, but:

- **Distribution overhead**: Plugins require marketplace submission and review. For first-party integration, this adds unnecessary friction.
- **Coupling to marketplace**: Updates require marketplace pipeline. Direct repo integration is faster for iteration.
- **Plugin is a packaging format, not a mechanism**: A plugin would still need to use hooks + skills internally. The plugin is the container, not the integration surface.

The plugin approach makes sense for community distribution later, but not for initial development.

### 6.4 Why Hook + Skill

**Hooks provide deterministic capture and injection**:
- `Stop` hook: Fires after every Claude response. Can read the full transcript via `transcript_path`, extract the interaction, and publish it to Reflexio for playbook extraction.
- `SessionStart` hook: Fires at session start. Can fetch relevant playbooks and inject them as context.
- `PreToolUse` hook: Fires before every tool call. Can fetch playbooks relevant to the specific tool/file being touched and inject them as context via stdout.
- Exit code control: Can block actions that violate playbook rules.

**Skills provide procedural knowledge**:
- Teach Claude how to interpret playbook context
- Provide slash commands for manual playbook management (`/playbooks`, `/playbook-review`)
- Auto-invoked skill loads when context matches playbook-related tasks
- Markdown format is easy to maintain and version-control

**The combination**:
- Hooks ensure 100% deterministic execution (capture and retrieval happen every time)
- Skills ensure Claude knows what to do with the playbook context (advisory but high-quality)
- No external server process to manage (hooks run shell commands)
- Transcript access via `transcript_path` enables rich interaction capture
- Works with both local (sqlite) and remote (API) Reflexio backends

### 6.5 Integration Architecture

```
SessionStart hook
  --> fetch playbooks from Reflexio API
  --> inject as context (stdout)

PreToolUse hook (matcher: Edit|Write|Bash)
  --> read tool_input (file path, command)
  --> fetch file/command-specific playbooks
  --> inject as context or block if playbook says "never do X"

Stop hook
  --> read transcript_path (full JSONL)
  --> extract interaction summary
  --> publish to Reflexio for playbook analysis

Skill (SKILL.md)
  --> teaches Claude how to interpret playbook context
  --> provides /playbooks slash command for manual review
  --> auto-invoked when task matches playbook-relevant context
```

### 6.6 Trade-offs Accepted

- **Hook timeout**: Hooks have a default 10-minute timeout (600s for command, 30s for HTTP). Reflexio API calls must be fast.
- **Shell profile pollution risk**: Hook scripts must handle non-interactive shell profiles carefully.
- **PostToolUse limitation**: Cannot reliably inject context for built-in tools (Issue #18427). Using PreToolUse instead for context injection.
- **Stop hook fires on every response**: Must determine if the interaction is worth capturing (not every "sure, what next?" response).
- **Advisory skill compliance**: ~80% compliance for skill instructions. Critical enforcement done via hooks, not skills.

---

## 7. Comparison with OpenClaw and LangChain

### 7.1 OpenClaw (OpenHands / All-Hands)

OpenClaw (formerly OpenDevin, now OpenHands) is an open-source AI software engineering agent
platform. Its approach to memory and learning differs from Reflexio's Claude Code integration:

**Architecture**: OpenClaw runs its own agent loop with a custom runtime environment
(Docker sandbox). It does not integrate into an existing coding agent; it IS the agent.

**Memory mechanism**: OpenClaw uses a micro-agent pattern where specialized sub-agents handle
different aspects of coding. Memory is managed through:
- Workspace state (file system snapshots)
- Conversation history in the agent loop
- No persistent cross-session playbook system comparable to Reflexio

**Integration surface**: Since OpenClaw is a standalone agent, there is no hook/plugin system
for third-party integration. Extensions happen at the Python level by modifying the agent
loop or adding new micro-agents.

**Key difference from Reflexio's approach**: OpenClaw owns the entire agent loop, so it can
intercept any step natively. Reflexio must integrate into Claude Code's loop externally via
hooks and skills. This means Reflexio's integration is non-invasive (no fork required) but
has less control over the agent's internal state.

### 7.2 LangChain / LangSmith

LangChain provides a framework for building LLM applications with chains, agents, and tools.
LangSmith is its observability and evaluation platform.

**Memory mechanism**: LangChain offers several memory types:
- `ConversationBufferMemory` -- full conversation history
- `ConversationSummaryMemory` -- LLM-summarized history
- `VectorStoreRetrieverMemory` -- semantic search over past interactions
- `EntityMemory` -- tracks entities mentioned across conversations

**Playbook equivalent**: LangChain's closest analog to Reflexio's playbook system is
`VectorStoreRetrieverMemory` combined with custom chains that retrieve relevant past
experiences before acting. However, this requires building the application from scratch
using LangChain's framework -- it is not a drop-in integration for existing agents.

**LangSmith for capture**: LangSmith traces every LLM call, tool use, and chain step. This
is similar to Reflexio's interaction capture via the Stop hook + transcript parsing. However,
LangSmith is purely observational (dashboards, evaluation) -- it does not inject learned
corrections back into the agent loop.

**Integration surface**: LangChain is a framework (you build on it), not a plugin for
existing agents. There is no LangChain plugin for Claude Code. LangSmith observability
could theoretically be added via MCP or hooks, but it would only provide tracing, not
playbook injection.

**Key difference from Reflexio's approach**: LangChain/LangSmith require building the agent
from scratch using their framework. Reflexio integrates into an existing agent (Claude Code)
without modifying it. This makes Reflexio's approach applicable to any Claude Code user
without framework lock-in.

### 7.3 Summary Comparison

| Dimension | Reflexio (Hook + Skill) | OpenClaw | LangChain/LangSmith |
|-----------|------------------------|----------|---------------------|
| **Integration model** | External plugin for existing agent | Standalone agent platform | Application framework |
| **Capture mechanism** | Stop hook + transcript parsing | Native agent loop | LangSmith tracing |
| **Injection mechanism** | PreToolUse hook + SessionStart hook | Micro-agent prompts | Chain memory retrieval |
| **Playbook persistence** | Reflexio API (sqlite/supabase) | None (workspace state only) | VectorStore (custom) |
| **Framework lock-in** | None (Claude Code only dependency) | Full (OpenClaw runtime) | Full (LangChain framework) |
| **Cross-session learning** | Yes (playbooks persist and improve) | No | Possible but manual |
| **Deterministic enforcement** | Yes (hooks are 100% deterministic) | Yes (owns the loop) | Yes (owns the chain) |
| **Setup complexity** | Low (hook config + skill files) | High (Docker + runtime) | Medium (framework + vectorstore) |

---

## Sources

### Official Documentation
- [Claude Code Hooks Reference](https://code.claude.com/docs/en/hooks)
- [Claude Code Hooks Guide](https://code.claude.com/docs/en/hooks-guide)
- [Claude Code MCP Documentation](https://code.claude.com/docs/en/mcp)
- [Claude Code Plugins Reference](https://code.claude.com/docs/en/plugins-reference)
- [Claude Code Skills Documentation](https://code.claude.com/docs/en/skills)
- [Claude Code Agent Teams](https://code.claude.com/docs/en/agent-teams)
- [Claude Code Memory (CLAUDE.md)](https://code.claude.com/docs/en/memory)
- [MCP Specification 2025-11-25](https://modelcontextprotocol.io/specification/2025-11-25)

### MCP SDKs and Ecosystem
- [MCP TypeScript SDK](https://github.com/modelcontextprotocol/typescript-sdk)
- [MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk)
- [Claude Plugins Official Marketplace](https://github.com/anthropics/claude-plugins-official)

### Community Resources
- [disler/claude-code-hooks-mastery](https://github.com/disler/claude-code-hooks-mastery) -- 13 hook implementations
- [disler/claude-code-hooks-multi-agent-observability](https://github.com/disler/claude-code-hooks-multi-agent-observability)
- [hgeldenhuys/claude-hooks-sdk](https://github.com/hgeldenhuys/claude-hooks-sdk) -- Production SDK
- [constellos/claude-code](https://github.com/constellos/claude-code) -- TypeScript types for hooks
- [Claude Code Hook Development SKILL.md](https://github.com/anthropics/claude-code/blob/main/plugins/plugin-dev/skills/hook-development/SKILL.md)

### Known Issues
- [Issue #18427: PostToolUse hooks cannot inject context for built-in tools](https://github.com/anthropics/claude-code/issues/18427) (closed NOT PLANNED)
- [Issue #9188: Stale session_id/transcript_path after /exit](https://github.com/anthropics/claude-code/issues/9188)

### Analysis and Tutorials
- [Understanding Claude Code's Full Stack](https://alexop.dev/posts/understanding-claude-code-full-stack/)
- [From Tasks to Swarms: Agent Teams](https://alexop.dev/posts/from-tasks-to-swarms-agent-teams-in-claude-code/)
- [Anatomy of the .claude/ Folder](https://blog.dailydoseofds.com/p/anatomy-of-the-claude-folder)
- [GitButler Blog: Automate with Claude Code Hooks](https://blog.gitbutler.com/automate-your-ai-workflows-with-claude-code-hooks/)
