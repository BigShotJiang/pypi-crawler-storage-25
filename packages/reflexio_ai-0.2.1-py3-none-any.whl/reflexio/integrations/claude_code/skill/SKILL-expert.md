---
name: reflexio-expert
description: "Triggers on TWO events: (1) Before starting any task — search Reflexio for corrections and preferences from past sessions. (2) When the user corrects you, states a preference, or says 'no, do X instead' — publish the correction to Reflexio so future sessions learn from it. Covers all domains, not just coding."
---

# Reflexio: Learn from Past Sessions (Expert)

Reflexio remembers corrections and preferences from your past conversations with this user.

**This skill triggers on TWO types of messages:**
1. **Task requests** — user asks you to do something → search Reflexio first
2. **Corrections and preferences** — user says "no, do X instead", "always use Y", "I prefer Z" → publish to Reflexio

The user can also run `/reflexio-extract` at any time to summarize the full conversation and extract learnings.

---

## Step-by-Step: When User Gives a Task

Follow these steps IN ORDER:

**Step 1 — Ensure server is running:**
```bash
reflexio status check
```
If this fails with a connection error, start the server in a background subagent:
```
Agent(prompt="Start the Reflexio server: nohup reflexio services start --only backend > ~/.reflexio/logs/server.log 2>&1 & sleep 5 && reflexio status check", run_in_background=true)
```
Then continue to Step 2 immediately (don't wait for the subagent).

**Step 2 — Search for relevant corrections:**
```bash
reflexio search "<the user's request or task description>"
```
If the server wasn't ready yet (connection error), skip this and proceed — you'll retry later.

**Step 3 — Apply results and do the task:**
- If search returned playbooks → follow the instructions, avoid the pitfalls
- If search returned profiles → adapt your approach to the user's preferences
- If search returned nothing or failed → proceed normally

---

## Step-by-Step: When User Corrects You

When the user corrects your approach or states a preference, follow these steps:

**Step 1 — Apply the correction** to your work first.

**Step 2 — Ensure server is running** (same as above — `reflexio status check`, start if needed).

**Step 3 — Publish the correction to Reflexio:**

Write a summary JSON and publish it:
```bash
cat > /tmp/reflexio-summary.json << 'SUMMARY_EOF'
{
  "user_id": "claude-code",
  "agent_version": "claude-code",
  "source": "claude-code-expert",
  "interactions": [
    {"role": "user", "content": "<what the user originally asked>"},
    {"role": "assistant", "content": "<your initial approach that was wrong>"},
    {"role": "user", "content": "<the user's correction — preserve their exact words>"},
    {"role": "assistant", "content": "<your acknowledgment and corrected approach>"}
  ]
}
SUMMARY_EOF
reflexio publish --user-id claude-code --agent-version claude-code --source claude-code-expert --skip-aggregation --force-extraction --wait --file /tmp/reflexio-summary.json && rm -f /tmp/reflexio-summary.json
```

**Detect correction patterns:**
- "No, use X instead of Y"
- "Don't do X, always do Y"
- "I prefer X", "Always use X in this project"
- "That's wrong, the correct approach is..."

**When to publish:**
- **Simple correction** (e.g., "always use type hints") → publish immediately, context is self-contained
- **Multi-turn correction** (user corrects, then explains why, then adds exceptions) → wait until complete, then publish the full chain

**Tip:** The user can also run `/reflexio-extract` at the end of the session to do a comprehensive extraction of all learnings — including intermediate reasoning, tool calls, and context that mid-session publishes might miss.

---

## What Reflexio Stores

**User Profiles** — stable facts learned from conversations:
- **About the user**: expertise, background, role
- **User preferences**: communication style, tools, conventions
- **About the environment**: project setup, team conventions, constraints

**User Playbooks** — behavioral corrections with structured fields:
- **trigger**: when does this rule apply?
- **instruction**: what to do instead
- **pitfall**: what to avoid
- **rationale**: why the correction matters

You don't decide what gets extracted — the Reflexio server LLM analyzes your published summary and determines profiles vs playbooks automatically.

---

## Server Management

The Reflexio server must be running for `reflexio search` and `reflexio publish` to work.

**Check:** `reflexio status check`
**Start (background subagent):**
```
Agent(prompt="Start the Reflexio server: nohup reflexio services start --only backend > ~/.reflexio/logs/server.log 2>&1 & sleep 5 && reflexio status check", run_in_background=true)
```

- Always use a background subagent to start the server — never run it in the main agent (it blocks)
- Never ask the user to start the server — handle it silently
- If `reflexio` is not found, ask the user to install it: `pip install reflexio-ai`

---

## Tips

- **Use the user's actual request as the search query** — not keywords
- **Preserve the user's exact words** in the correction summary
- **Include enough context** — what you did wrong + the correction + why
- **If Reflexio is unreachable, proceed normally** — it enhances but never blocks
- **Don't mention Reflexio to the user** unless they ask
- **Suggest `/reflexio-extract`** if a session had many corrections or learnings
