---
name: reflexio-extract
description: "Summarize the current conversation — including reasoning, tool calls, corrections, and preferences — and publish to Reflexio for user profile and playbook extraction."
---

# Extract Learnings to Reflexio

Summarize this conversation and publish to Reflexio so future sessions can learn from it.

## What to Do

Review the full conversation above, including your chain-of-thought reasoning, tool calls, tool results, and all user messages. Create a summary that captures:

1. **User corrections** — places where the user said "no, do X instead" or corrected your approach. Preserve their exact words.
2. **User preferences** — statements about how they like things done, their expertise, communication style, or project conventions.
3. **Environment facts** — things you learned about the project setup, tools, constraints, or team conventions.
4. **Non-obvious learnings** — things that surprised you, dead ends you hit, workarounds you discovered.

Skip routine interactions with no learning signal.

## How to Publish

1. Ensure the server is running:
```bash
reflexio status check
```
If not running, start it:
```bash
nohup reflexio services start --only backend > ~/.reflexio/logs/server.log 2>&1 &
sleep 5
```

2. Write the summary as a JSON file:
```bash
cat > /tmp/reflexio-extract.json << 'EXTRACT_EOF'
{
  "user_id": "claude-code",
  "agent_version": "claude-code",
  "source": "claude-code-expert",
  "interactions": [
    {"role": "user", "content": "<summarized user message or correction>"},
    {"role": "assistant", "content": "<summarized response including reasoning and context>"},
    ...more pairs as needed...
  ]
}
EXTRACT_EOF
```

3. Publish with forced extraction:
```bash
reflexio publish --user-id claude-code --agent-version claude-code --source claude-code-expert --skip-aggregation --force-extraction --wait --file /tmp/reflexio-extract.json && rm -f /tmp/reflexio-extract.json
```

4. Report what was published (brief summary to the user).

## Summary Guidelines

- **Preserve user corrections verbatim** — their exact words are the highest-signal input
- **Include reasoning context** — WHY you took an approach, what tools you used, what failed
- **Organize as meaningful pairs** — each user/assistant pair should capture one coherent learning, not be a 1:1 copy of raw turns
- **Be concise** — focus on what would help a future session, not a full conversation replay
