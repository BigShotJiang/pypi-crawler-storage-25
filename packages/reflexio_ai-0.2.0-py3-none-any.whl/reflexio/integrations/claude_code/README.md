# Reflexio Claude Code Integration

Connect [Claude Code](https://claude.ai/code) to [Reflexio](https://github.com/reflexio-ai/reflexio) for automatic self-improvement. Conversations are captured automatically at session end; task-specific playbooks are retrieved on-demand via the `reflexio` CLI.

## How It Works

The integration has two independent mechanisms:

### 1. Capture (Hook — automatic, runs every session end)

```
Session End (Stop event)
  └── Read transcript JSONL at transcript_path
      └── Extract user queries + assistant text responses
          └── Skip thinking blocks, tool_use, tool results, system messages
      └── reflexio interactions publish --file → publish to Reflexio server
          └── Server automatically:
              1. Detects learning signals (corrections, friction, re-steering)
              2. Extracts playbooks: freeform content + optional structured fields
              3. Extracts user profiles (preferences, expertise, communication style)
              4. Stores everything with vector embeddings for semantic search
```

### 2. Retrieve (Skill — on-demand, per-task)

```
Agent receives task from user
  └── reflexio search "<the user's actual task>"
      └── Semantic search matches query against playbook trigger fields
      └── Returns only playbooks relevant to THIS specific task

Agent needs to personalize response
  └── reflexio user-profiles search "<what to know about the user>"
      └── Returns relevant user preferences, expertise, communication style
```

### Key Design Differences from OpenClaw

Claude Code hooks **cannot inject messages** into the conversation (no `bootstrapFiles`), but they **can read the full transcript** via `transcript_path` in the Stop event. So:

- **Capture**: The hook reads the complete JSONL transcript at session end (vs. OpenClaw's per-turn buffering via `message:sent`)
- **Retrieve**: The skill teaches Claude to run `reflexio search` before tasks (same pattern as OpenClaw)
- **No bootstrap**: Claude Code has no `agent:bootstrap` event, so there's no automatic profile injection at session start

## Prerequisites

- The `reflexio` CLI on PATH: `pip install reflexio-ai`
- A running Reflexio server (local or remote)
- Node.js runtime (for the hook script)

## Installation

### 1. Install the Skill

Copy or symlink the skill into your Claude Code skills directory:

```bash
# Project-level (recommended)
mkdir -p .claude/skills/reflexio
cp /path/to/reflexio/integrations/claude_code/skill/SKILL.md .claude/skills/reflexio/SKILL.md

# Or symlink
ln -s /path/to/reflexio/integrations/claude_code/skill/SKILL.md .claude/skills/reflexio/SKILL.md
```

### 2. Install the Hook

Add the Stop hook to your Claude Code `settings.json`:

**Project-level** (`.claude/settings.json`):
```json
{
  "hooks": {
    "Stop": [
      {
        "type": "command",
        "command": "node /path/to/reflexio/integrations/claude_code/hook/handler.js"
      }
    ]
  }
}
```

**User-level** (`~/.claude/settings.json`) — applies to all projects:
```json
{
  "hooks": {
    "Stop": [
      {
        "type": "command",
        "command": "node /path/to/reflexio/integrations/claude_code/hook/handler.js"
      }
    ]
  }
}
```

### 3. Configure Reflexio

**Local mode** (SQLite storage, no API key needed):

```bash
# Set your LLM API key for playbook extraction
export OPENAI_API_KEY=sk-...  # or ANTHROPIC_API_KEY

# Configure and start
reflexio auth login --url http://localhost:8081
reflexio services start
reflexio status check
```

**Cloud mode** (Supabase storage, API key required):

```bash
# Set environment variables
export REFLEXIO_API_KEY=rflx-xxxxxxxxxxxx

# Configure
reflexio auth login --url https://your-server.com --api-key $REFLEXIO_API_KEY
reflexio status check
```

## Configuration

| Variable | Default | Required | Description |
|----------|---------|----------|-------------|
| `REFLEXIO_URL` | `http://127.0.0.1:8081` | No | Reflexio server URL (set via `reflexio auth login`) |
| `REFLEXIO_API_KEY` | — | Cloud only | API key for remote Reflexio server |
| `REFLEXIO_USER_ID` | `claude-code` | No | User ID for profile and playbook scoping |
| `REFLEXIO_AGENT_VERSION` | `claude-code` | No | Agent version tag for playbook filtering |

## What to Expect

**Session 1 (cold start):** No playbooks exist yet. The agent works normally. At session end, the hook captures the full conversation. Reflexio's server-side LLM pipeline analyzes it and extracts any corrections or user preferences.

**Session 2+:** Before each task, the agent runs `reflexio search "<task>"` and gets task-specific corrections from past sessions. Over time:

- Mistakes made once are not repeated (corrections match by trigger similarity)
- User preferences are remembered (profiles extracted automatically)
- The agent adapts its approach per-task based on accumulated playbooks

**The feedback loop:**
1. Agent works on a task -> user corrects a mistake
2. Session ends -> hook reads transcript -> publishes to Reflexio -> server extracts playbook
3. Next session, similar task -> agent searches -> gets the correction -> applies the guideline
4. Mistake not repeated

## Troubleshooting

### `reflexio: command not found`
Install the CLI: `pip install reflexio-ai` (or `uv pip install reflexio-ai`)

### Hook not firing
1. Check `settings.json` has the correct path to `handler.js`
2. Verify Node.js is available: `node --version`
3. Check Claude Code recognizes the hook: look for `[reflexio]` in stderr output

### No playbooks returned from search
1. Verify the server is running: `reflexio status check`
2. Check that previous sessions were captured: conversations need to be published first
3. The first session has no playbooks — it's a cold start

### Authentication errors (cloud mode)
1. Verify `REFLEXIO_API_KEY` is set: `echo $REFLEXIO_API_KEY`
2. Re-authenticate: `reflexio auth login --url <server-url> --api-key <key>`

## File Structure

```
claude_code/
├── __init__.py         ← Python package marker
├── README.md           ← This file
├── RESEARCH.md         ← Research report on Claude Code extension mechanisms
├── hook/               ← Automatic: capture transcripts at session end
│   ├── handler.js      ← Stop event handler: reads JSONL, publishes to Reflexio
│   ├── HOOK.md         ← Hook metadata (events, requirements, config)
│   └── package.json    ← npm package manifest
└── skill/              ← On-demand: search for task-specific playbooks
    └── SKILL.md        ← Teaches Claude when/how to use reflexio CLI
```

## Comparison with Other Integrations

| Aspect | Claude Code | OpenClaw | LangChain |
|--------|------------|----------|-----------|
| Integration method | Hook + Skill (JS + MD) | Hook + Skill (JS + MD) | Python SDK + callbacks |
| Conversation capture | Stop hook reads transcript JSONL | Per-turn buffering + session-end flush | Callback captures per chain run |
| Context retrieval | Per-task via `reflexio search` | Per-task via `reflexio search` + bootstrap profiles | Per-LLM-call via middleware |
| Profile injection | None (no bootstrap event) | Bootstrap hook injects profiles | Automatic via middleware |
| Agent teaching | SKILL.md (natural language) | SKILL.md (natural language) | Tool definition (structured) |
| Dependencies | `reflexio` CLI + Node.js | `reflexio` CLI + Node.js | `langchain-core >= 0.3.0` |

All integrations connect to the same Reflexio server and share the same playbook/profile data.
