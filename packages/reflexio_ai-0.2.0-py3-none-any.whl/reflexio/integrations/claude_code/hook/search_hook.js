import { execFileSync, spawn } from "node:child_process";
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";

/**
 * Claude Code UserPromptSubmit hook for Reflexio.
 *
 * Runs `reflexio search` with the user's prompt and outputs results to stdout.
 * Claude Code injects stdout content as context Claude sees before responding.
 *
 * This is intentionally synchronous — results must be available before Claude
 * responds. Timeout is 5 seconds to avoid blocking the UI too long.
 *
 * If the Reflexio server is not running (connection refused), starts it in the
 * background and exits silently (next message will find the server ready).
 */

const SEARCH_TIMEOUT_MS = 5_000;
const MIN_PROMPT_LENGTH = 10;
const LOG_DIR = join(homedir(), ".reflexio", "logs");
const STARTING_FLAG = join(LOG_DIR, ".server-starting");

async function main() {
	const input = readFileSync("/dev/stdin", "utf-8").trim();
	if (!input) {
		process.exit(0);
	}

	let event;
	try {
		event = JSON.parse(input);
	} catch {
		process.exit(0);
	}

	const prompt = event.prompt || "";

	// Skip short messages (greetings, "yes", "ok", etc.)
	if (prompt.length < MIN_PROMPT_LENGTH) {
		process.exit(0);
	}

	try {
		const result = execFileSync(
			"reflexio",
			["search", prompt],
			{
				timeout: SEARCH_TIMEOUT_MS,
				encoding: "utf-8",
			},
		);

		const trimmed = result.trim();
		if (trimmed && !trimmed.includes("Found 0 profiles, 0 playbooks")) {
			// Output to stdout — Claude sees this as injected context
			process.stdout.write(trimmed + "\n");
		}
	} catch (err) {
		// Only start server if the error looks like a connection failure
		const stderr = err.stderr || "";
		const message = err.message || "";
		const isConnectionError =
			stderr.includes("Cannot reach server") ||
			stderr.includes("Connection refused") ||
			stderr.includes("ECONNREFUSED") ||
			message.includes("ECONNREFUSED") ||
			message.includes("ENOENT"); // reflexio binary not found (unlikely but safe)

		if (!isConnectionError) {
			// Server is running but search failed for another reason — don't start server
			return;
		}

		// Guard: don't spawn multiple server starts within a session
		if (existsSync(STARTING_FLAG)) {
			return;
		}

		try {
			mkdirSync(LOG_DIR, { recursive: true, mode: 0o700 });
			// Create flag file to prevent repeated starts
			require("node:fs").writeFileSync(STARTING_FLAG, String(Date.now()));

			const child = spawn(
				"sh",
				[
					"-c",
					`reflexio services start --only backend > "${join(LOG_DIR, "server.log")}" 2>&1 & sleep 5 && rm -f "${STARTING_FLAG}"`,
				],
				{
					detached: true,
					stdio: ["ignore", "ignore", "ignore"],
				},
			);
			child.unref();
		} catch {
			// ignore — reflexio may not be installed
		}
	}
}

main().catch(() => {
	process.exit(0);
});
