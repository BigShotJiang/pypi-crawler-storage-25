"""Interactive setup wizard for Reflexio integrations."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path
from typing import Annotated

import typer

app = typer.Typer(help="Set up Reflexio integrations.")

_PROVIDERS: dict[str, dict[str, str]] = {
    "openai": {"env_var": "OPENAI_API_KEY", "model": "gpt-5-mini", "display": "OpenAI"},
    "anthropic": {
        "env_var": "ANTHROPIC_API_KEY",
        "model": "claude-sonnet-4-6",
        "display": "Anthropic",
    },
    "gemini": {
        "env_var": "GEMINI_API_KEY",
        "model": "gemini-3-flash-preview",
        "display": "Gemini",
    },
    "deepseek": {
        "env_var": "DEEPSEEK_API_KEY",
        "model": "deepseek-chat",
        "display": "DeepSeek",
    },
    "openrouter": {
        "env_var": "OPENROUTER_API_KEY",
        "model": "gemini-3-flash-preview",
        "display": "OpenRouter",
    },
    "minimax": {
        "env_var": "MINIMAX_API_KEY",
        "model": "MiniMax-M2.5",
        "display": "MiniMax",
    },
    "dashscope": {
        "env_var": "DASHSCOPE_API_KEY",
        "model": "qwen-plus",
        "display": "DashScope",
    },
    "xai": {"env_var": "XAI_API_KEY", "model": "grok-3-mini", "display": "xAI"},
    "moonshot": {
        "env_var": "MOONSHOT_API_KEY",
        "model": "moonshot-v1-8k",
        "display": "Moonshot",
    },
    "zai": {"env_var": "ZAI_API_KEY", "model": "glm-4-flash", "display": "ZAI"},
}


def _set_env_var(env_path: Path, key: str, value: str) -> None:
    """Write or update an environment variable in a .env file.

    If the key already exists (active or commented-out), the line is replaced
    in-place. Active (uncommented) lines are prioritized over commented ones.
    Values are always wrapped in double quotes for safe parsing.

    Args:
        env_path (Path): Path to the .env file.
        key (str): Environment variable name.
        value (str): Environment variable value.
    """
    content = env_path.read_text() if env_path.exists() else ""
    lines = content.splitlines()
    pattern = re.compile(rf"^#?\s*{re.escape(key)}=")
    active_idx: int | None = None
    commented_idx: int | None = None
    for i, line in enumerate(lines):
        if not pattern.match(line):
            continue
        if line.lstrip().startswith("#"):
            if commented_idx is None:
                commented_idx = i
        else:
            active_idx = i
            break
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    replacement = f'{key}="{escaped}"'
    target = active_idx if active_idx is not None else commented_idx
    if target is not None:
        lines[target] = replacement
    else:
        lines.append(replacement)
    env_path.write_text("\n".join(lines) + "\n")
    env_path.chmod(0o600)


def _prompt_llm_provider(env_path: Path) -> tuple[str, str]:
    """Interactively prompt the user to choose an LLM provider and API key.

    Args:
        env_path (Path): Path to the .env file for writing the key.

    Returns:
        tuple[str, str]: The display name and default model for the chosen provider.
    """
    provider_keys = list(_PROVIDERS.keys())

    typer.echo("\nWhich LLM provider for feedback extraction?")
    for idx, key in enumerate(provider_keys, 1):
        display = _PROVIDERS[key]["display"]
        model = _PROVIDERS[key]["model"]
        typer.echo(f"  [{idx}] {display:<14s} ({model})")

    choice = typer.prompt("Choice", type=int)
    if not 1 <= choice <= len(provider_keys):
        typer.echo(f"Error: choice must be between 1 and {len(provider_keys)}")
        raise typer.Exit(1)

    selected_key = provider_keys[choice - 1]
    provider_info = _PROVIDERS[selected_key]
    env_var = provider_info["env_var"]
    model = provider_info["model"]
    display_name = provider_info["display"]

    api_key = typer.prompt(f"Enter your {env_var}", hide_input=True)
    if not api_key.strip():
        typer.echo("Error: API key cannot be empty")
        raise typer.Exit(1)
    _set_env_var(env_path, env_var, api_key)

    return display_name, model


def _prompt_storage(env_path: Path) -> str:
    """Interactively prompt the user to choose a storage backend.

    Args:
        env_path (Path): Path to the .env file for writing Supabase credentials.

    Returns:
        str: The storage mode label for the summary.
    """
    typer.echo("\nWhere should Reflexio store data?")
    typer.echo("  [1] Local SQLite (default, no setup needed)")
    typer.echo("  [2] Supabase (local or cloud)")

    choice = typer.prompt("Choice", type=int, default=1)

    if choice == 1:
        return "SQLite (local)"

    if choice != 2:
        typer.echo("Error: choice must be 1 or 2")
        raise typer.Exit(1)

    supabase_url = typer.prompt("Supabase URL", default="http://127.0.0.1:54321")
    supabase_key = typer.prompt("Supabase key", hide_input=True)
    if not supabase_key.strip():
        typer.echo("Error: API key cannot be empty")
        raise typer.Exit(1)
    supabase_db_url = typer.prompt(
        "Supabase DB URL",
        default="postgresql://postgres:postgres@127.0.0.1:54322/postgres",
    )
    reflexio_api_key = typer.prompt("Reflexio API key", hide_input=True)
    if not reflexio_api_key.strip():
        typer.echo("Error: API key cannot be empty")
        raise typer.Exit(1)

    _set_env_var(env_path, "SUPABASE_URL", supabase_url)
    _set_env_var(env_path, "SUPABASE_KEY", supabase_key)
    _set_env_var(env_path, "SUPABASE_DB_URL", supabase_db_url)
    _set_env_var(env_path, "REFLEXIO_API_KEY", reflexio_api_key)

    return "Supabase"


def _install_openclaw_integration() -> bool:
    """Install the Reflexio hook and skill into OpenClaw.

    Returns:
        bool: True if the hook was verified as registered.

    Raises:
        typer.Exit: If the openclaw CLI is not found on PATH.
    """
    if not shutil.which("openclaw"):
        typer.echo("Error: openclaw CLI not found. Install from https://openclaw.ai")
        raise typer.Exit(1)

    import reflexio

    pkg_dir = Path(reflexio.__file__).parent
    hook_dir = pkg_dir / "integrations" / "openclaw" / "hook"
    skill_dir = pkg_dir / "integrations" / "openclaw" / "skill"

    # Install plugin and enable hook
    try:
        subprocess.run(
            ["openclaw", "plugins", "install", str(hook_dir), "--link"],
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            ["openclaw", "hooks", "enable", "reflexio-context"],
            check=True,
            capture_output=True,
            text=True,
        )
    except subprocess.CalledProcessError as exc:
        typer.echo(f"Error: openclaw command failed: {exc.stderr or exc.stdout}")
        raise typer.Exit(1) from exc

    # Copy skill directory
    workspace_skills = Path.home() / ".openclaw" / "skills" / "reflexio"
    if workspace_skills.exists():
        shutil.rmtree(workspace_skills)
    shutil.copytree(skill_dir, workspace_skills)

    # Verify
    result = subprocess.run(
        ["openclaw", "hooks", "list"],
        capture_output=True,
        text=True,
    )
    if "reflexio-context" in result.stdout:
        typer.echo("Hook installed and registered")
        return True

    typer.echo("Warning: Hook may not be registered -- check 'openclaw hooks list'")
    return False


def _uninstall_openclaw() -> None:
    """Remove the Reflexio integration from OpenClaw."""
    typer.confirm(
        "This will remove the Reflexio integration from OpenClaw. Continue?",
        abort=True,
    )
    if shutil.which("openclaw"):
        subprocess.run(
            ["openclaw", "hooks", "disable", "reflexio-context"],
            check=False,
            capture_output=True,
            text=True,
        )
        subprocess.run(
            ["openclaw", "plugins", "uninstall", "reflexio-context"],
            check=False,
            capture_output=True,
            text=True,
        )
    else:
        typer.echo("Warning: openclaw CLI not found on PATH, skipping hook removal")
    workspace_skills = Path.home() / ".openclaw" / "skills" / "reflexio"
    if workspace_skills.exists():
        shutil.rmtree(workspace_skills)
    typer.echo("Reflexio integration removed from OpenClaw.")


@app.command("openclaw")
def openclaw(
    uninstall: Annotated[
        bool,
        typer.Option(
            "--uninstall", help="Remove the Reflexio integration from OpenClaw"
        ),
    ] = False,
) -> None:
    """Set up (or remove) the Reflexio integration for OpenClaw."""
    if uninstall:
        _uninstall_openclaw()
        return

    # Step 1: Load .env path
    from reflexio.cli.env_loader import load_reflexio_env

    env_path = load_reflexio_env()
    if env_path is None:
        typer.echo("Error: could not locate or create a .env file")
        raise typer.Exit(1)

    # Step 2: LLM provider
    display_name, model = _prompt_llm_provider(env_path)

    # Step 3: Storage
    storage_label = _prompt_storage(env_path)

    # Step 4: Install OpenClaw integration
    typer.echo("")
    hook_ok = _install_openclaw_integration()

    # Step 5: Summary
    hook_status = "reflexio-context" if hook_ok else "reflexio-context (unverified)"
    skill_path = Path.home() / ".openclaw" / "skills" / "reflexio"

    typer.echo("")
    typer.echo("Setup complete!")
    typer.echo(f"  LLM Provider: {display_name} ({model})")
    typer.echo(f"  Storage: {storage_label}")
    typer.echo(f"  Hook: {hook_status}")
    typer.echo(f"  Skill: {skill_path}")
    typer.echo("")
    typer.echo("Next steps:")
    typer.echo("  1. Start Reflexio: reflexio services start")
    typer.echo("  2. Restart OpenClaw gateway: openclaw gateway restart")
    typer.echo(
        "  3. Start a conversation -- Reflexio will capture and learn automatically"
    )


# ---------------------------------------------------------------------------
# Claude Code integration
# ---------------------------------------------------------------------------


def _get_integration_dir() -> Path:
    """Locate the claude_code integration directory within the installed package."""
    import reflexio

    return Path(reflexio.__file__).parent / "integrations" / "claude_code"


def _upsert_hook(
    hooks: dict, event_name: str, hook_command: str
) -> None:
    """Add or update a hook entry for the given event in the hooks dict.

    Args:
        hooks: The hooks dict from settings.json.
        event_name: The hook event name (e.g., "Stop", "UserPromptSubmit").
        hook_command: The shell command to run.
    """
    event_hooks: list[dict] = hooks.setdefault(event_name, [])
    hook_entry = {
        "matcher": "",
        "hooks": [{"type": "command", "command": hook_command}],
    }
    for existing in event_hooks:
        inner = existing.get("hooks", [])
        if any("reflexio" in h.get("command", "") for h in inner):
            existing["hooks"] = hook_entry["hooks"]
            return
    event_hooks.append(hook_entry)


def _merge_hook_config(
    settings_path: Path, handler_js_path: Path
) -> None:
    """Add or update Reflexio hooks in .claude/settings.json.

    Installs the search hook (UserPromptSubmit) which runs `reflexio search`
    on every user prompt and injects results as context Claude sees.

    No Stop hook is installed — conversation capture is handled by the expert
    skill's mid-session publish or by an explicit `/reflexio-extract` command,
    giving the user control over when to extract learnings.

    Args:
        settings_path: Path to the project's .claude/settings.json.
        handler_js_path: Absolute path to handler.js in the installed package.
    """
    settings: dict = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    hooks = settings.setdefault("hooks", {})

    # Search hook (UserPromptSubmit) — injects Reflexio context before Claude responds
    search_hook_js = handler_js_path.parent / "search_hook.js"
    _upsert_hook(hooks, "UserPromptSubmit", f"node {search_hook_js}")

    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings_path.write_text(json.dumps(settings, indent=2) + "\n")


def _remove_hook_config(settings_path: Path) -> None:
    """Remove all Reflexio hooks from .claude/settings.json.

    Args:
        settings_path: Path to the project's .claude/settings.json.
    """
    if not settings_path.exists():
        return
    try:
        settings = json.loads(settings_path.read_text())
    except (json.JSONDecodeError, OSError):
        return

    hooks = settings.get("hooks")
    if not hooks:
        return

    for event_name in ["Stop", "UserPromptSubmit"]:
        event_hooks = hooks.get(event_name, [])
        hooks[event_name] = [
            entry for entry in event_hooks
            if not any("reflexio" in h.get("command", "") for h in entry.get("hooks", []))
        ]
        if not hooks[event_name]:
            del hooks[event_name]
    if not settings["hooks"]:
        del settings["hooks"]

    settings_path.write_text(json.dumps(settings, indent=2) + "\n")


def _install_claude_code_integration(
    project_dir: Path, *, expert: bool = False
) -> tuple[Path, Path]:
    """Install the Reflexio skill and hook into a Claude Code project.

    Args:
        project_dir: Root directory of the Claude Code project.
        expert: If True, install the expert skill instead of the normal skill.

    Returns:
        tuple[Path, Path]: (skill_path, handler_js_path) for the summary.
    """
    integration_dir = _get_integration_dir()
    if not integration_dir.exists():
        typer.echo(f"Error: integration files not found at {integration_dir}")
        raise typer.Exit(1)

    # Copy skill
    skill_src = (
        integration_dir / "skill" / "SKILL-expert.md"
        if expert
        else integration_dir / "skill" / "SKILL.md"
    )
    skill_dest = project_dir / ".claude" / "skills" / "reflexio" / "SKILL.md"
    skill_dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(skill_src, skill_dest)

    # Expert mode: also install /reflexio-extract command
    if expert:
        cmd_src = integration_dir / "commands" / "reflexio-extract" / "SKILL.md"
        cmd_dest = (
            project_dir / ".claude" / "commands" / "reflexio-extract" / "SKILL.md"
        )
        cmd_dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(cmd_src, cmd_dest)

    # Configure hook
    handler_js = integration_dir / "hook" / "handler.js"
    settings_path = project_dir / ".claude" / "settings.json"
    _merge_hook_config(settings_path, handler_js)

    return skill_dest, handler_js


def _uninstall_claude_code(project_dir: Path) -> None:
    """Remove the Reflexio integration from a Claude Code project.

    Args:
        project_dir: Root directory of the Claude Code project.
    """
    typer.confirm(
        "This will remove the Reflexio skill and hook from this project. Continue?",
        abort=True,
    )

    # Remove skill directory
    skill_dir = project_dir / ".claude" / "skills" / "reflexio"
    if skill_dir.exists():
        shutil.rmtree(skill_dir)
        typer.echo(f"  Removed skill: {skill_dir}")

    # Remove /reflexio-extract command
    cmd_dir = project_dir / ".claude" / "commands" / "reflexio-extract"
    if cmd_dir.exists():
        shutil.rmtree(cmd_dir)
        typer.echo(f"  Removed command: {cmd_dir}")

    # Remove hook from settings
    settings_path = project_dir / ".claude" / "settings.json"
    _remove_hook_config(settings_path)
    typer.echo(f"  Removed hook from: {settings_path}")

    typer.echo("Reflexio integration removed from Claude Code project.")


@app.command("claude-code")
def claude_code_setup(
    uninstall: Annotated[
        bool,
        typer.Option("--uninstall", help="Remove the Reflexio integration"),
    ] = False,
    expert: Annotated[
        bool,
        typer.Option(
            "--expert",
            help="Install the expert skill (search + summarize + publish)",
        ),
    ] = False,
    project_dir: Annotated[
        Path | None,
        typer.Option(
            "--project-dir",
            help="Target project directory (default: current directory)",
        ),
    ] = None,
) -> None:
    """Set up (or remove) the Reflexio integration for Claude Code."""
    target = Path(project_dir) if project_dir else Path.cwd()

    if uninstall:
        _uninstall_claude_code(target)
        return

    # Step 1: Load .env path
    from reflexio.cli.env_loader import load_reflexio_env

    env_path = load_reflexio_env()
    if env_path is None:
        typer.echo("Error: could not locate or create a .env file")
        raise typer.Exit(1)

    # Step 2: LLM provider
    display_name, model = _prompt_llm_provider(env_path)

    # Step 3: Storage
    storage_label = _prompt_storage(env_path)

    # Step 4: Install skill + hook
    typer.echo("")
    skill_path, handler_path = _install_claude_code_integration(
        target, expert=expert
    )
    skill_type = "expert" if expert else "normal"

    # Step 5: Summary
    typer.echo("")
    typer.echo("Setup complete!")
    typer.echo(f"  LLM Provider: {display_name} ({model})")
    typer.echo(f"  Storage: {storage_label}")
    typer.echo(f"  Skill ({skill_type}): {skill_path}")
    typer.echo(f"  Hook: Stop → node {handler_path}")
    typer.echo("")
    typer.echo("Next: Start a Claude Code session in this project.")
    typer.echo(
        "The skill will guide Claude to check and start the Reflexio server automatically."
    )
