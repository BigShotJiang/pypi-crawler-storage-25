from __future__ import annotations

from pathlib import Path


def test_upsert_template_overwrite_true_is_on_conflict_do_update(monkeypatch):
    import daylily_tapdb.cli.db as m

    captured = {}

    def fake_run_psql(env, *, sql=None, file=None):
        captured["sql"] = sql
        captured["file"] = file
        return True, "t"

    monkeypatch.setattr(m, "_run_psql", fake_run_psql)

    ok, _out = m._upsert_template(
        m.Environment.dev,
        template={
            "name": "x",
            "polymorphic_discriminator": "generic_template",
            "category": "generic",
            "type": "tube",
            "subtype": "micro",
            "version": "1.0",
            "instance_prefix": "GX",
            "json_addl": {"k": "v"},
        },
        overwrite=True,
    )

    assert ok is True
    assert captured["file"] is None
    sql = captured["sql"]
    assert "ON CONFLICT (category, type, subtype, version)" in sql
    assert "DO UPDATE SET" in sql
    assert "RETURNING" in sql


def test_upsert_template_overwrite_false_is_on_conflict_do_nothing(monkeypatch):
    import daylily_tapdb.cli.db as m

    captured = {}

    def fake_run_psql(env, *, sql=None, file=None):
        captured["sql"] = sql
        captured["file"] = file
        return True, "1"

    monkeypatch.setattr(m, "_run_psql", fake_run_psql)

    ok, _out = m._upsert_template(
        m.Environment.dev,
        template={
            "name": "x",
            "polymorphic_discriminator": "generic_template",
            "category": "generic",
            "type": "tube",
            "subtype": "micro",
            "version": "1.0",
            "instance_prefix": "GX",
            "json_addl": {"k": "v"},
        },
        overwrite=False,
    )

    assert ok is True
    assert captured["file"] is None
    sql = captured["sql"]
    assert "ON CONFLICT (category, type, subtype, version)" in sql
    assert "DO NOTHING" in sql
    assert "RETURNING 1" in sql


def test_db_migrate_idempotent_when_all_migrations_already_applied(
    tmp_path, monkeypatch
):
    """Safety: if migrations exist but have already been recorded as applied,
    db_migrate should not attempt to apply them again.
    """
    import daylily_tapdb.cli.db as m

    # Point db_migrate's computed migrations_dir at a temp tree.
    fake_cli_dir = tmp_path / "daylily_tapdb" / "cli"
    fake_cli_dir.mkdir(parents=True)
    fake_db_py = fake_cli_dir / "db.py"
    fake_db_py.write_text("# test stub\n")
    monkeypatch.setattr(m, "__file__", str(fake_db_py))

    migrations_dir = tmp_path / "schema" / "migrations"
    migrations_dir.mkdir(parents=True)
    (migrations_dir / "001_test.sql").write_text("SELECT 1;\n")

    monkeypatch.setattr(m, "_get_db_config", lambda env: {"database": "tapdb"})
    monkeypatch.setattr(m, "_check_db_exists", lambda env, db: True)
    monkeypatch.setattr(m, "_schema_exists", lambda env: True)

    calls: list[dict] = []

    def fake_run_psql(env, *, sql=None, file: Path | None = None):
        calls.append({"sql": sql, "file": file})
        if sql and "SELECT filename FROM _tapdb_migrations" in sql:
            return True, "001_test.sql\n"
        return True, ""

    monkeypatch.setattr(m, "_run_psql", fake_run_psql)

    m.db_migrate(m.Environment.dev, dry_run=False)

    # Ensure we never attempted to apply a migration file.
    assert not any(c["file"] is not None for c in calls)


def test_db_migrate_uses_installed_data_migrations(tmp_path, monkeypatch):
    """When repo schema is absent, migrations should resolve from data-dir schema."""
    import daylily_tapdb.cli.db as m

    fake_cli_dir = tmp_path / "site-packages" / "daylily_tapdb" / "cli"
    fake_cli_dir.mkdir(parents=True)
    fake_db_py = fake_cli_dir / "db.py"
    fake_db_py.write_text("# test stub\n")
    monkeypatch.setattr(m, "__file__", str(fake_db_py))

    data_root = tmp_path / "py-data"
    migrations_dir = data_root / "schema" / "migrations"
    migrations_dir.mkdir(parents=True)
    migration_file = migrations_dir / "001_test.sql"
    migration_file.write_text("SELECT 1;\n")

    monkeypatch.setattr(m.sysconfig, "get_paths", lambda: {"data": str(data_root)})
    monkeypatch.setattr(m, "_get_db_config", lambda env: {"database": "tapdb"})
    monkeypatch.setattr(m, "_check_db_exists", lambda env, db: True)
    monkeypatch.setattr(m, "_schema_exists", lambda env: True)

    calls: list[dict] = []

    def fake_run_psql(env, *, sql=None, file: Path | None = None):
        calls.append({"sql": sql, "file": file})
        if sql and "SELECT filename FROM _tapdb_migrations" in sql:
            return True, ""
        return True, ""

    monkeypatch.setattr(m, "_run_psql", fake_run_psql)
    monkeypatch.setattr(m, "_log_operation", lambda *_args, **_kwargs: None)

    m.db_migrate(m.Environment.dev, dry_run=False)

    assert any(c["file"] == migration_file for c in calls)


# ---------------------------------------------------------------------------
# M5: _ensure_instance_prefix_sequence rejects non-alpha prefixes
# ---------------------------------------------------------------------------


def test_ensure_instance_prefix_sequence_rejects_non_alpha():
    import pytest

    import daylily_tapdb.cli.db as m

    with pytest.raises(ValueError, match="letters only"):
        m._ensure_instance_prefix_sequence(m.Environment.dev, "AB123")

    with pytest.raises(ValueError, match="cannot be empty"):
        m._ensure_instance_prefix_sequence(m.Environment.dev, "")

    with pytest.raises(ValueError, match="cannot be empty"):
        m._ensure_instance_prefix_sequence(m.Environment.dev, "   ")


def test_ensure_instance_prefix_sequence_quotes_sql(monkeypatch):
    """Verify sequence names are double-quoted in SQL."""
    import daylily_tapdb.cli.db as m

    captured = {}

    def fake_run_psql(env, *, sql=None, file=None):
        captured["sql"] = sql
        return True, ""

    monkeypatch.setattr(m, "_run_psql", fake_run_psql)
    m._ensure_instance_prefix_sequence(m.Environment.dev, "GX")

    sql = captured["sql"]
    assert '"gx_instance_seq"' in sql
