""" gitodo-bin-linux-x64-gnu """


def main() -> None:
    print("  gitodo-bin-linux-x64-gnu  ")
