from pathlib import Path
import os
from PyQt6.QtGui import QPixmap
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QApplication

_SNIPPETS = {
    'main_py': r'''import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLineEdit, QPushButton, QMessageBox, QLabel
from PyQt6.QtGui import QIcon, QPixmap
from PyQt6.QtCore import Qt
from db import get_db
from client import ClientWindow
from manager import ManagerWindow
from admin import AdminWindow

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Вход")
        self.setWindowIcon(QIcon("images/ava_kit.jpg"))
        layout = QVBoxLayout(self)
        
        self.logo_l = QLabel()
        self.logo_l.setPixmap(QPixmap("images/ava_kit.jpg"))
        self.logo_l.setScaledContents(True)
        self.logo_l.setFixedSize(100, 100)
        layout.addWidget(self.logo_l, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.login_input = QLineEdit(placeholderText="Логин")
        self.password_input = QLineEdit(placeholderText="Пароль", echoMode=QLineEdit.EchoMode.Password)
        self.login_btn = QPushButton("Войти")
        self.guest_btn = QPushButton("Войти как гость")

        self.login_btn.clicked.connect(self.auth)
        self.guest_btn.clicked.connect(self.guest_auth)

        layout.addWidget(self.login_input)
        layout.addWidget(self.password_input)
        layout.addWidget(self.login_btn) 
        layout.addWidget(self.guest_btn)

    def auth(self):
        try:
            con = get_db()
            cur = con.cursor()
            cur.execute("SELECT u.*, r.name as role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE login=%s AND password=%s", (self.login_input.text(), self.password_input.text()))
            user = cur.fetchone()
            con.close()

            if user:
                if user['role_name'] == 'Клиент':
                    self.main = ClientWindow(user)
                elif user['role_name'] == 'Менеджер':
                    self.main = ManagerWindow(user)
                elif user['role_name'] == 'Администратор':
                    self.main = AdminWindow(user)
                self.main.show()
                self.close()
            else:
                QMessageBox.warning(self, "Ошибка", "Неверный логин или пароль")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def guest_auth(self):
        user = {'id': None, 'user_fio': 'Гость', 'role_name': 'Гость'}
        self.main = ClientWindow(user)
        self.main.show()
        self.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("images/picture.png"))
    win = LoginWindow()
    win.show()
    sys.exit(app.exec())''',

    'client_py': r'''from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea, QMessageBox
import datetime
from db import get_db, ProductCard, ensure_picture

class ClientWindow(QWidget):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.role = user['role_name']
        self.setWindowTitle("Товары (Клиент/Гость)")
        self.resize(800, 600)
        
        main_layout = QVBoxLayout(self)
        
        header = QHBoxLayout()
        header.addWidget(QLabel(f"<b>{user['user_fio']}</b> ({self.role})"))
        out_btn = QPushButton("Выход")
        out_btn.clicked.connect(self.logout)
        header.addStretch()
        header.addWidget(out_btn)
        main_layout.addLayout(header)
        
        self.scroll = QScrollArea(widgetResizable=True)
        self.list_widget = QWidget()
        self.list_layout = QVBoxLayout(self.list_widget)
        self.scroll.setWidget(self.list_widget)
        main_layout.addWidget(self.scroll)
        
        if self.role == 'Клиент':
            footer = QHBoxLayout()
            self.order_btn = QPushButton("Оформить заказ")
            self.order_btn.clicked.connect(self.place_order)
            self.total_lbl = QLabel("Итого: 0 руб.")
            footer.addWidget(self.order_btn)
            footer.addWidget(self.total_lbl)
            main_layout.addLayout(footer)
            
        self.cards = []
        ensure_picture()
        self.load_products()

    def logout(self):
        from main import LoginWindow
        self.w = LoginWindow()
        self.w.show()
        self.close()

    def load_products(self):
        while self.list_layout.count():
            item = self.list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.cards.clear()
        
        con = get_db()
        cur = con.cursor()
        cur.execute("SELECT p.*, s.name AS supplier FROM products p LEFT JOIN suppliers s ON p.supplier_id = s.id")
        for row in cur.fetchall():
            card = ProductCard(row, self.role, self)
            self.list_layout.addWidget(card)
            self.cards.append(card)
        con.close()
        self.list_layout.addStretch()

    def update_total(self):
        total = sum(c.count * (float(c.product['price']) * (1 - float(c.product['discount'])/100)) for c in self.cards)
        self.total_lbl.setText(f"Итого: {total:.2f} руб.")

    def place_order(self):
        items = [c for c in self.cards if c.count > 0]
        if not items: return QMessageBox.warning(self, "Пусто", "Корзина пуста!")
        
        try:
            con = get_db()
            cur = con.cursor()
            for c in items:
                p = c.product
                price = c.count * (float(p['price']) * (1 - float(p['discount'])/100))
                dt = datetime.date.today()
                cur.execute("INSERT INTO orders (article, product_id, user_id, quantity, final_price, status, pickup_point, order_date, delivery_date) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                            (f"ORD-{p['id']}-{dt.day}", p['id'], self.user['id'], c.count, price, 'Новый', 'Пункт выдачи №1', dt, dt + datetime.timedelta(days=3)))
                cur.execute("UPDATE products SET quantity = quantity - %s WHERE id = %s", (c.count, p['id']))
                c.count = 0
                c.count_lbl.setText("0")
            con.commit()
            con.close()
            self.update_total()
            self.load_products()
            QMessageBox.information(self, "Успех", "Заказ оформлен!")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", f"Ошибка при оформлении заказа: {str(e)}")''',

    'manager_py': r'''from PyQt6.QtWidgets import *
from db import get_db, ProductCard, ensure_picture

class OrdersWindow(QTableWidget):
    def __init__(self, role):
        super().__init__(0, 6)
        self.role = role
        self.setHorizontalHeaderLabels(["ID Заказа", "Товар", "Сумма", "Статус", "Клиент", "Действие (Админ)"])
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.setColumnWidth(5, 150)
        self.resize(800, 300)
        self.load_data()
        self.cellClicked.connect(self.delete_order)

    def load_data(self):
        self.setRowCount(0)
        con = get_db()
        cur = con.cursor()
        cur.execute("SELECT o.*, u.user_fio, p.name AS product_name FROM orders o JOIN users u ON o.user_id = u.id JOIN products p ON o.product_id = p.id")
        for i, row in enumerate(cur.fetchall()):
            self.insertRow(i)
            self.setItem(i, 0, QTableWidgetItem(str(row['id'])))
            self.setItem(i, 1, QTableWidgetItem(row['product_name']))
            self.setItem(i, 2, QTableWidgetItem(str(row['final_price'])))
            self.setItem(i, 3, QTableWidgetItem(row['status']))
            self.setItem(i, 4, QTableWidgetItem(row['user_fio']))
            if self.role == 'Администратор':
                self.setItem(i, 5, QTableWidgetItem("Удалить заказ"))
            else:
                self.setItem(i, 5, QTableWidgetItem("-"))
        con.close()

    def delete_order(self, row, col):
        if col == 5 and self.role == 'Администратор':
            con = get_db()
            cur = con.cursor()
            cur.execute("DELETE FROM orders WHERE id=%s", (self.item(row, 0).text(),))
            con.commit()
            con.close()
            self.load_data()

class ManagerWindow(QWidget):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.role = user['role_name']
        self.setWindowTitle("Товары (Менеджер)")
        self.resize(800, 600)
        
        main_layout = QVBoxLayout(self)
        
        header = QHBoxLayout()
        header.addWidget(QLabel(f"<b>{user['user_fio']}</b> ({self.role})"))
        out_btn = QPushButton("Выход")
        out_btn.clicked.connect(self.logout)
        header.addStretch()
        header.addWidget(out_btn)
        main_layout.addLayout(header)
        
        tools = QHBoxLayout()
        self.search = QLineEdit(placeholderText="Поиск...")
        self.search.textChanged.connect(self.load_products)
        self.sort = QComboBox()
        self.sort.addItems(["Без сортировки", "Сначала дешевые", "Сначала дорогие"])
        self.sort.currentIndexChanged.connect(self.load_products)
        self.filter = QComboBox()
        self.filter.addItem("Все поставщики")
        
        con = get_db()
        cur = con.cursor()
        cur.execute("SELECT name FROM suppliers")
        for row in cur.fetchall():
            self.filter.addItem(row['name'])
        con.close()
        
        self.filter.currentIndexChanged.connect(self.load_products)
        tools.addWidget(self.search)
        tools.addWidget(self.sort)
        tools.addWidget(self.filter)
        main_layout.addLayout(tools)
        
        orders_btn = QPushButton("Все заказы")
        orders_btn.clicked.connect(self.open_orders)
        main_layout.addWidget(orders_btn)
        
        self.scroll = QScrollArea(widgetResizable=True)
        self.list_widget = QWidget()
        self.list_layout = QVBoxLayout(self.list_widget)
        self.scroll.setWidget(self.list_widget)
        main_layout.addWidget(self.scroll)
        
        self.cards = []
        ensure_picture()
        self.load_products()

    def logout(self):
        from main import LoginWindow
        self.w = LoginWindow()
        self.w.show()
        self.close()

    def load_products(self):
        con = get_db()
        cur = con.cursor()
        cur.execute("SELECT name FROM suppliers")
        suppliers = ["Все поставщики"] + [row['name'] for row in cur.fetchall()]
        
        current_items = [self.filter.itemText(i) for i in range(self.filter.count())]
        if set(suppliers) != set(current_items):
            current_sel = self.filter.currentText()
            self.filter.blockSignals(True)
            self.filter.clear()
            self.filter.addItems(suppliers)
            if current_sel in suppliers:
                self.filter.setCurrentText(current_sel)
            self.filter.blockSignals(False)

        while self.list_layout.count():
            item = self.list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.cards.clear()
        
        query = "SELECT p.*, s.name AS supplier FROM products p LEFT JOIN suppliers s ON p.supplier_id = s.id WHERE 1=1"
        params = []
        
        s = self.search.text()
        if s:
            query += " AND (p.name LIKE %s OR p.description LIKE %s)"
            params.extend([f"%{s}%", f"%{s}%"])
        f = self.filter.currentText()
        if f != "Все поставщики":
            query += " AND s.name = %s"
            params.append(f)
        if self.sort.currentIndex() == 1: query += " ORDER BY p.price ASC"
        elif self.sort.currentIndex() == 2: query += " ORDER BY p.price DESC"

        con = get_db()
        cur = con.cursor()
        cur.execute(query, params)
        for row in cur.fetchall():
            card = ProductCard(row, self.role, self)
            self.list_layout.addWidget(card)
            self.cards.append(card)
        con.close()
        self.list_layout.addStretch()

    def open_orders(self):
        self.orders = OrdersWindow(self.role)
        self.orders.show()''',

    'admin_py': r'''import os, shutil, pymysql
from PyQt6.QtWidgets import QWidget, QFormLayout, QLineEdit, QPushButton, QLabel, QFileDialog, QComboBox, QMessageBox
from db import get_db
from manager import ManagerWindow

class ProductEditor(QWidget):
    def __init__(self, prod, parent):
        super().__init__()
        self.prod = prod
        self.parent_win = parent
        layout = QFormLayout(self)
        
        self.article = QLineEdit(prod['article'] if prod else "ART-NEW")
        self.name = QLineEdit(prod['name'] if prod else "")
        self.cat = QLineEdit(prod['category'] if prod else "Одежда")
        self.desc = QLineEdit(prod['description'] if prod else "")
        self.manuf = QLineEdit(prod['manufacturer'] if prod else "")
        self.supp = QComboBox()
        self.supp.setEditable(True)
        con = get_db()
        cur = con.cursor()
        cur.execute("SELECT name FROM suppliers")
        for row in cur.fetchall():
            self.supp.addItem(row['name'])
        con.close()
        if prod and 'supplier' in prod:
            self.supp.setCurrentText(prod['supplier'])
        self.price = QLineEdit(str(prod['price']) if prod else "0")
        self.qty = QLineEdit(str(prod['quantity']) if prod else "0")
        self.discount = QLineEdit(str(prod['discount']) if prod else "0")
        self.photo_path = prod['photo_path'] if prod and prod['photo_path'] else ""
        
        self.photo_btn = QPushButton("Выбрать фото")
        self.photo_btn.clicked.connect(self.load_photo)
        
        layout.addRow("Артикул", self.article)
        layout.addRow("Название", self.name)
        layout.addRow("Категория", self.cat)
        layout.addRow("Описание", self.desc)
        layout.addRow("Производитель", self.manuf)
        layout.addRow("Поставщик", self.supp)
        layout.addRow("Цена", self.price)
        layout.addRow("Количество", self.qty)
        layout.addRow("Скидка (%)", self.discount)
        self.photo_lbl = QLabel(self.photo_path)
        layout.addRow(self.photo_btn, self.photo_lbl)
        
        save_btn = QPushButton("Сохранить")
        save_btn.clicked.connect(self.save)
        layout.addRow(save_btn)

    def load_photo(self):
        path, _ = QFileDialog.getOpenFileName(self, "Фото")
        if path:
            self.photo_path = os.path.basename(path)
            if not os.path.exists('images'): os.makedirs('images')
            try:
                shutil.copy(path, f"images/{self.photo_path}")
            except shutil.SameFileError:
                pass
            self.photo_lbl.setText(self.photo_path)

    def save(self):
        con = get_db()
        cur = con.cursor()
        
        sup_name = self.supp.currentText().strip()
        if not sup_name:
            QMessageBox.warning(self, "Ошибка", "Поставщик не может быть пустым!")
            return
            
        cur.execute("SELECT id FROM suppliers WHERE name = %s", (sup_name,))
        sup_row = cur.fetchone()
        if sup_row:
            sup_id = sup_row['id']
        else:
            cur.execute("INSERT INTO suppliers (name) VALUES (%s)", (sup_name,))
            sup_id = cur.lastrowid
            
        data = (self.article.text(), self.name.text(), self.cat.text(), self.desc.text(), 
                self.manuf.text(), sup_id, self.price.text(), 
                self.qty.text(), self.discount.text(), self.photo_path)
                
        try:
            if self.prod:
                cur.execute("UPDATE products SET article=%s, name=%s, category=%s, description=%s, manufacturer=%s, supplier_id=%s, price=%s, quantity=%s, discount=%s, photo_path=%s WHERE id=%s", data + (self.prod['id'],))
            else:
                cur.execute("INSERT INTO products (article, name, category, description, manufacturer, supplier_id, price, quantity, discount, photo_path) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", data)
            con.commit()
        except pymysql.err.IntegrityError as e:
            if e.args[0] == 1062:
                QMessageBox.warning(self, "Ошибка", "Товар с таким артикулом уже существует! Пожалуйста, придумайте другой.")
            else:
                QMessageBox.warning(self, "Ошибка БД", str(e))
            return
        finally:
            con.close()
            
        self.parent_win.load_products()
        self.close()

class AdminWindow(ManagerWindow):
    def __init__(self, user):
        super().__init__(user)
        self.setWindowTitle("Товары (Администратор)")
        
        add_btn = QPushButton("Добавить товар")
        add_btn.clicked.connect(lambda: self.open_editor(None))
        self.layout().insertWidget(2, add_btn)

    def open_editor(self, prod):
        self.editor = ProductEditor(prod, self)
        self.editor.show()''',

    'db_py': r'''import pymysql
import os
from PyQt6.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QLabel, QPushButton, QMessageBox
from PyQt6.QtGui import QPixmap
from PyQt6.QtCore import Qt

def get_db():
    return pymysql.connect(host='localhost', user='root', password='', database='exam_db', cursorclass=pymysql.cursors.DictCursor)

def ensure_picture():
    os.makedirs('images', exist_ok=True)
    if not os.path.exists('images/picture.png'):
        p = QPixmap(100, 100)
        p.fill(Qt.GlobalColor.lightGray)
        p.save('images/picture.png')

class ProductCard(QFrame):
    def __init__(self, product, role, window):
        super().__init__()
        self.product = product
        self.role = role
        self.window = window
        self.count = 0
        
        self.setFrameShape(QFrame.Shape.Box)
        layout = QHBoxLayout(self)
        
        self.img = QLabel()
        self.img.setFixedSize(100, 100)
        self.img.setScaledContents(True)
        photo = f"images/{product['photo_path']}" if product['photo_path'] and os.path.exists(f"images/{product['photo_path']}") else 'images/picture.png'
        self.img.setPixmap(QPixmap(photo))
        
        info = QVBoxLayout()
        info.addWidget(QLabel(f"<b>{product['name']}</b> ({product['category']})"))
        info.addWidget(QLabel(product['description']))
        info.addWidget(QLabel(f"Производитель: {product['manufacturer']} | Поставщик: {product['supplier']}"))
        info.addWidget(QLabel(f"На складе: {product['quantity']}"))
        
        price = float(product['price'])
        discount = float(product['discount'])
        actual_price = price - (price * discount / 100)
        
        if discount > 0:
            info.addWidget(QLabel(f"<s>{price}</s> <b>{actual_price} руб.</b> (Скидка {discount}%)"))
        else:
            info.addWidget(QLabel(f"<b>{price} руб.</b>"))
        
        layout.addWidget(self.img)
        layout.addLayout(info)
        
        if product['quantity'] == 0:
            self.setStyleSheet("background-color: lightblue;")
        elif discount > 15:
            self.setStyleSheet("background-color: #2E8B57; color: white;")
            
        controls = QVBoxLayout()
        if role == 'Клиент':
            self.plus_btn = QPushButton("+")
            self.count_lbl = QLabel("0", alignment=Qt.AlignmentFlag.AlignCenter)
            self.minus_btn = QPushButton("-")
            self.plus_btn.clicked.connect(self.add)
            self.minus_btn.clicked.connect(self.rem)
            controls.addWidget(self.plus_btn)
            controls.addWidget(self.count_lbl)
            controls.addWidget(self.minus_btn)
        elif role == 'Администратор':
            self.edit_btn = QPushButton("Редактировать")
            self.del_btn = QPushButton("Удалить")
            self.edit_btn.clicked.connect(lambda: self.window.open_editor(self.product))
            self.del_btn.clicked.connect(self.delete_product)
            controls.addWidget(self.edit_btn)
            controls.addWidget(self.del_btn)
            
        if role in ['Клиент', 'Администратор']:
            layout.addLayout(controls)

    def add(self):
        if self.count < self.product['quantity']:
            self.count += 1
            self.count_lbl.setText(str(self.count))
            self.window.update_total()

    def rem(self):
        if self.count > 0:
            self.count -= 1
            self.count_lbl.setText(str(self.count))
            self.window.update_total()

    def delete_product(self):
        if QMessageBox.question(self, "Удаление", "Удалить товар?") == QMessageBox.StandardButton.Yes:
            con = get_db()
            cur = con.cursor()
            cur.execute("SELECT * FROM orders WHERE product_id=%s", (self.product['id'],))
            if cur.fetchone():
                QMessageBox.warning(self, "Ошибка", "Товар есть в заказах!")
            else:
                cur.execute("DELETE FROM products WHERE id=%s", (self.product['id'],))
                con.commit()
                self.window.load_products()
            con.close()''',

    'init_db_sql': r'''CREATE DATABASE IF NOT EXISTS exam_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE exam_db;

CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL
);

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_fio VARCHAR(255) NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE TABLE suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    article VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    description TEXT,
    manufacturer VARCHAR(100),
    supplier_id INT,
    price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
    quantity INT NOT NULL CHECK (quantity >= 0),
    discount DECIMAL(5,2) DEFAULT 0,
    photo_path VARCHAR(255),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id)
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    article VARCHAR(50) NOT NULL,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    quantity INT NOT NULL,
    final_price DECIMAL(10,2) NOT NULL,
    status VARCHAR(50) NOT NULL,
    pickup_point VARCHAR(255) NOT NULL,
    order_date DATE NOT NULL,
    delivery_date DATE NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Тестовые данные
INSERT INTO roles (name) VALUES ('Клиент'), ('Менеджер'), ('Администратор');

INSERT INTO users (user_fio, login, password, role_id) VALUES
('Иванов Иван Иванович', 'client', '123', 1),
('Смирнова Анна Петровна', 'manager', '123', 2),
('Сидоров Алексей Сергеевич', 'admin', '123', 3);

INSERT INTO suppliers (name) VALUES ('ООО Ромашка'), ('ЗАО Поставки');

INSERT INTO products (article, name, category, description, manufacturer, supplier_id, price, quantity, discount, photo_path) VALUES
('A001', 'Смартфон X', 'Электроника', 'Мощный смартфон', 'Apple', 1, 50000.00, 10, 10.00, NULL),
('A002', 'Кроссовки', 'Одежда', 'Спортивные кроссовки', 'Nike', 2, 5000.00, 5, 20.00, NULL);'''
}

_FILES = {
    'main_py': 'main.py',
    'client_py': 'client.py',
    'manager_py': 'manager.py',
    'admin_py': 'admin.py',
    'db_py': 'db.py',
    'init_db_sql': 'init_db.sql'
}

def _write_file(filename, text):
    path = Path(filename)
    path.write_text(text, encoding="utf-8")
    print(f"Создан файл: {filename}")
    return str(path)

def create(name):
    key = name.replace('.', '_') if '.' in name else name
    if key in _FILES:
        return _write_file(_FILES[key], _SNIPPETS[key])
    else:
        available = ', '.join(_FILES.values())
        print(f"Ошибка: Файл '{name}' не найден. Доступные файлы: {available}")
        return None

def show(name):
    key = name.replace('.', '_') if '.' in name else name
    if key in _FILES:
        print(f"--- Код файла: {_FILES[key]} ---")
        print(_SNIPPETS[key])
        print("-" * 40)
    else:
        available = ', '.join(_FILES.values())
        print(f"Ошибка: Файл '{name}' не найден. Доступные файлы: {available}")

def create_all():
    files = []
    for name, filename in _FILES.items():
        files.append(_write_file(filename, _SNIPPETS[name]))

    # Создаем папку images и серую картинку
    os.makedirs('images', exist_ok=True)
    if not os.path.exists('images/picture.png'):
        # Нужно инициализировать QApp для QPixmap
        import sys
        app = QApplication.instance()
        if not app:
            app = QApplication(sys.argv)
            
        p = QPixmap(100, 100)
        p.fill(Qt.GlobalColor.lightGray)
        p.save('images/picture.png')
        print("Создана папка images и файл picture.png")
    
    return files

if __name__ == '__main__':
    create_all()
    print("Все файлы успешно сгенерированы!")