#!/usr/bin/env python3
"""AI Teammate ROS2 Bridge CLI"""

from ai_teammate_ros2_bridge import DeviceBridge


def main():
    bridge = DeviceBridge.from_env()
    bridge.run()


if __name__ == '__main__':
    main()
