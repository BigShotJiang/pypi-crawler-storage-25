# AI Teammate Robot Bridge

Connects ROS2 robots to AI Teammate Device Gateway via WebSocket.

## Features
- **rclpy native** — DDS 직접 참여, rosbridge 불필요
- Sensor data streaming (IMU, odometry, battery, temperature)
- Command reception (MOVE, TURN, STOP) → ROS2 cmd_vel publish (10Hz continuous)
- Auto-reconnect on disconnect
- Simulator mode for non-ROS2 environments

## Quick Install

```bash
curl -sL "https://ai-teammate.net/api/b2b/install/DEVICE_ID?key=YOUR_API_KEY" | bash
```

Get your API key from Control Tower > Devices > + button.

## Manual Setup

```bash
pip3 install websockets psutil

cat > .env << EOF
DEVICE_ID=my-robot-01
GATEWAY_URL=wss://ai-teammate.net/gw
API_KEY=dk_YOUR_API_KEY
CONNECTION_MODE=rclpy
STATUS_REPORT_INTERVAL=1.0
CMD_VEL_TOPIC=/base_controller/cmd_vel_unstamped
IMU_TOPIC=/imu/data
ODOM_TOPIC=/odom
EOF

# ROS2 환경 source 후 실행
source /opt/ros/humble/setup.bash
python3 device_bridge.py
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DEVICE_ID` | required | Unique device identifier |
| `GATEWAY_URL` | required | Device Gateway WebSocket URL |
| `API_KEY` | required | Device API key (`dk_xxx`) |
| `CONNECTION_MODE` | `rclpy` | `rclpy` for ROS2 native, `simulator` for fake data |
| `STATUS_REPORT_INTERVAL` | `1.0` | Sensor data send interval (seconds) |
| `CMD_VEL_TOPIC` | `/cmd_vel` | ROS2 velocity command topic |
| `IMU_TOPIC` | `/imu/data` | ROS2 IMU topic |
| `ODOM_TOPIC` | `/odom` | ROS2 odometry topic |

## Prerequisites

- Python 3.8+
- ROS2 Humble (optional — simulator mode works without)
- **rosbridge 불필요** — rclpy로 DDS 직접 통신

## Architecture

```
Robot                          AWS
┌─────────────────┐           ┌─────────────────┐
│ device_bridge.py │──WSS────▶│ Device Gateway   │
│   ├─ send sensor │          │ (port 8003)      │
│   └─ recv cmd    │◀─WSS────│   └─ /ws/stream  │──▶ Control Tower
│                  │          └─────────────────┘
│ rclpy (native)   │
│   ├─ cmd_vel pub │  DDS direct (no rosbridge)
│   ├─ odom sub    │
│   └─ imu sub     │
└─────────────────┘
```

## Systemd Service

설치 스크립트가 자동으로 등록합니다. 수동 관리:

```bash
sudo systemctl status ai-teammate-bridge
sudo systemctl restart ai-teammate-bridge
journalctl -u ai-teammate-bridge -f
```
