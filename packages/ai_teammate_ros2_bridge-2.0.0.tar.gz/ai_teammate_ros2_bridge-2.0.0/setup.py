from setuptools import setup, find_packages

try:
    from Cython.Build import cythonize
    USE_CYTHON = True
except ImportError:
    USE_CYTHON = False

ext_modules = []
if USE_CYTHON:
    ext_modules = cythonize([
        "ai_teammate_ros2_bridge/commands.py",
        "ai_teammate_ros2_bridge/ws_client.py",
        "ai_teammate_ros2_bridge/motion.py",
        "ai_teammate_ros2_bridge/ros2_node.py",
        "ai_teammate_ros2_bridge/slam.py",
        "ai_teammate_ros2_bridge/keyframe.py",
    ])

setup(
    ext_modules=ext_modules,
)
