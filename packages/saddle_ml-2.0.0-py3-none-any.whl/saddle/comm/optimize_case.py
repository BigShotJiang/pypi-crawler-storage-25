#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
优化案例处理脚本
功能：读取配置文件和数据，执行优化计算，保存结果和日志
"""

import os
import sys
import json
import logging
import pandas as pd
import traceback
from datetime import datetime
from typing import Dict, Any, Optional, Tuple
import argparse
import math


def set_logging(log_dir: str, file_name: str, mode: str = 'dev'):
    """设置日志配置"""
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"{file_name}.log")

    logging.basicConfig(
        level=logging.INFO,
        format='[%(asctime)s][%(name)s][%(levelname)s][%(filename)s:%(lineno)d]- %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )


def resolve_data_path(data_path: str) -> str:
    """
    解析数据文件路径
    如果data_path是hash文件名，则在projects/data/files目录下查找
    Args:
        data_path: 数据文件路径或hash文件名
    Returns:
        解析后的完整文件路径
    """
    # 如果已经是完整路径且文件存在，直接返回
    if os.path.exists(data_path):
        return data_path

    # 如果是hash文件名，在projects/data/files目录下查找
    projects_data_files_dir = os.path.join('projects', 'data', 'files')
    hash_file_path = os.path.join(projects_data_files_dir, data_path)

    # 检查文件是否存在（尝试添加常见扩展名）
    possible_paths = [
        hash_file_path,
        hash_file_path + '.csv',
        hash_file_path + '.xlsx',
        hash_file_path + '.json',
        hash_file_path + '.parquet'
    ]

    for path in possible_paths:
        if os.path.exists(path):
            logging.info(f"找到数据文件: {path}")
            return path

    # 如果都没找到，返回原始路径（让后续代码处理错误）
    logging.warning(f"未在{projects_data_files_dir}目录下找到数据文件: {data_path}")
    return data_path


def load_config_and_data(config_path: str, data_path: str) -> Tuple[Dict, pd.DataFrame]:
    try:
        logging.info(f"正在加载配置文件: {config_path}")
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        logging.info(f"配置文件加载成功，配置项数量: {len(config)}")

        # 解析数据文件路径
        resolved_data_path = resolve_data_path(data_path)
        logging.info(f"正在加载数据文件: {resolved_data_path}")

        if resolved_data_path.endswith('.csv'):
            df = pd.read_csv(resolved_data_path)
        elif resolved_data_path.endswith('.xlsx'):
            df = pd.read_excel(resolved_data_path)
        elif resolved_data_path.endswith('.json'):
            df = pd.read_json(resolved_data_path)
        elif resolved_data_path.endswith('.parquet'):
            df = pd.read_parquet(resolved_data_path)
        else:
            # 尝试自动推断文件格式
            try:
                df = pd.read_csv(resolved_data_path)
            except:
                try:
                    df = pd.read_excel(resolved_data_path)
                except:
                    try:
                        df = pd.read_json(resolved_data_path)
                    except:
                        raise ValueError(f"不支持的数据文件格式: {resolved_data_path}")

        logging.info(f"数据加载成功，数据形状: {df.shape}")
        logging.info(f"数据列名: {list(df.columns)}")

        return config, df

    except Exception as e:
        logging.error(f"加载文件失败: {str(e)}")
        raise


class JSONSerializableEncoder(json.JSONEncoder):
    """自定义JSON编码器，处理不可序列化的对象"""

    def default(self, obj):
        if isinstance(obj, type(math)):  # 如果是模块对象
            return f"<module '{obj.__name__}'>"
        elif callable(obj):  # 如果是函数/可调用对象
            return f"<function {obj.__name__ if hasattr(obj, '__name__') else 'anonymous'}>"
        elif hasattr(obj, '__dict__'):  # 如果是对象实例
            return obj.__dict__
        return super().default(obj)


def save_results(result_path: str, results: Dict, success: bool = True, error_msg: str = None) -> None:
    try:
        result_dir = os.path.dirname(result_path)
        if result_dir and not os.path.exists(result_dir):
            os.makedirs(result_dir, exist_ok=True)

        final_result = {
            "success": success,
            "timestamp": datetime.now().isoformat(),
            "results": results if success else "",
        }
        if not success:
            final_result["error"] = error_msg

        logging.info(f"final_result keys: {list(final_result.keys())}")
        with open(result_path, 'w', encoding='utf-8') as f:
            json.dump(final_result, f, ensure_ascii=False, indent=2, cls=JSONSerializableEncoder)

        logging.info(f"结果已保存到: {result_path}")

    except Exception as e:
        logging.error(f"保存结果失败: {str(e)}")
        raise


from .express_merge import merge_expression_to_final
from .optimize_engine import OptimizationEngine
from dataclasses import dataclass, asdict
import logging
import traceback
from typing import Dict, Any, List, Optional, Tuple
import pandas as pd
import numpy as np
import types

# 关键：定义通用的序列化清理函数
# def clean_serializable(obj):
#     """递归清理不可序列化的对象，转换为可JSON序列化的类型"""
#     # 处理 numpy 数值类型
#     if isinstance(obj, (np.integer, np.floating)):
#         return obj.item()
#     # 处理 numpy 数组
#     elif isinstance(obj, np.ndarray):
#         return obj.tolist()
#     # 过滤模块对象
#     elif isinstance(obj, types.ModuleType):
#         return f"<module: {obj.__name__}>"
#     # 过滤函数/方法
#     elif callable(obj):
#         return f"<function: {obj.__name__ if hasattr(obj, '__name__') else 'unknown'}>"
#     # 过滤类实例（非基础类型）
#     elif hasattr(obj, '__dict__') and not isinstance(obj, (dict, list, tuple, str, int, float, bool)):
#         return f"<instance: {obj.__class__.__name__}>"
#     # 递归处理字典
#     elif isinstance(obj, dict):
#         return {k: clean_serializable(v) for k, v in obj.items()}
#     # 递归处理列表/元组
#     elif isinstance(obj, (list, tuple)):
#         return [clean_serializable(v) for v in obj]
#     # 处理 None/基础类型
#     elif obj is None or isinstance(obj, (str, int, float, bool)):
#         return obj
#     # 其他类型转为字符串
#     else:
#         return str(obj)
def clean_serializable(obj):
    """递归清理不可序列化的对象，转换为可JSON序列化的类型"""
    # 处理 numpy 数值类型
    if isinstance(obj, (np.integer, np.floating)):
        obj = obj.item()  # 关键修改：把return改为赋值，不终止函数！
        # 新增：处理转原生float后的特殊值
        if isinstance(obj, float):
            if np.isinf(obj):
                return 1e18 if obj > 0 else -1e18  # 用极大/极小值代替无穷大，而非字符串/None
            elif np.isnan(obj):
                return 0.0  # 用0代替NaN，或根据业务逻辑调整
        return obj  # 普通numpy数值（int/float）原样返回
    # 处理 numpy 数组
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    # 过滤模块对象
    elif isinstance(obj, types.ModuleType):
        return f"<module: {obj.__name__}>"
    # 过滤函数/方法
    elif callable(obj):
        return f"<function: {obj.__name__ if hasattr(obj, '__name__') else 'unknown'}>"
    # 过滤类实例（非基础类型）
    elif hasattr(obj, '__dict__') and not isinstance(obj, (dict, list, tuple, str, int, float, bool)):
        return f"<instance: {obj.__class__.__name__}>"
    # 递归处理字典
    elif isinstance(obj, dict):
        return {k: clean_serializable(v) for k, v in obj.items()}
    # 递归处理列表/元组
    elif isinstance(obj, (list, tuple)):
        return [clean_serializable(v) for v in obj]
    # 处理 None/基础类型（新增：这里也加一层特殊值判断，覆盖原生float）
    elif obj is None or isinstance(obj, (str, int, float, bool)):
        if isinstance(obj, float):
            if np.isinf(obj):
                return "Infinity" if obj > 0 else "-Infinity"
            elif np.isnan(obj):
                return "NaN"
        return obj
    # 其他类型转为字符串
    else:
        return str(obj)

@dataclass
class OptimizationResponse:
    """统一的优化结果返回结构"""
    success: bool
    message: str
    result_type: str  # "single" | "multi" | "error"
    optimal_variables: Optional[Dict[str, Any]] = None
    optimal_objective: Optional[float] = None
    pareto_front: Optional[List[Any]] = None
    ideal_point: Optional[List[float]] = None
    nadir_point: Optional[List[float]] = None
    convergence_data: Optional[Dict[str, Any]] = None
    n_evaluations: int = 0
    # 元数据
    original_expression: str = ""
    final_expression: str = ""
    expression_context: Optional[Dict[str, Any]] = None
    data_shape: Optional[Tuple[int, int]] = None
    data_columns: Optional[List[str]] = None

    def to_dict(self) -> Dict[str, Any]:
        """转换为可JSON序列化的字典，清理不可序列化对象"""
        # 先转为基础字典
        raw_dict = asdict(self)
        # 深度清理不可序列化内容
        cleaned_dict = clean_serializable(raw_dict)
        # 过滤空值（可选）
        def filter_none(obj):
            if isinstance(obj, dict):
                return {k: filter_none(v) for k, v in obj.items() if v is not None and v != "" and v != []}
            elif isinstance(obj, list):
                return [filter_none(v) for v in obj if v is not None]
            else:
                return obj
        return filter_none(cleaned_dict)

def optimize_case(df: pd.DataFrame, config: Dict) -> Dict:
    try:
        logging.info("开始优化案例处理")

        if 'objectives' not in config or not config['objectives']:
            raise ValueError("配置中必须包含 objectives 字段")

        original_expression = config['objectives'][0]['expression']
        logging.info(f"原始表达式: {original_expression}")

        final_expression, context = merge_expression_to_final(original_expression, df)
        logging.info(f"归并后表达式: {final_expression}")

        merged_config = config.copy()
        merged_config['objectives'][0]['expression'] = final_expression
        merged_config['expression_context'] = context

        engine = OptimizationEngine(merged_config)
        engine.load_data(df)
        raw_result = engine.run_optimization()

        # ========== 核心：统一结果格式 + 过滤冗余数据 ==========
        if hasattr(raw_result, 'pareto_front'):  # 多目标结果
            # 处理 numpy 数组（如果有）
            pareto_front = raw_result.pareto_front.tolist() if isinstance(raw_result.pareto_front, np.ndarray) else raw_result.pareto_front
            ideal_point = raw_result.ideal_point.tolist() if isinstance(raw_result.ideal_point, np.ndarray) else raw_result.ideal_point
            nadir_point = raw_result.nadir_point.tolist() if isinstance(raw_result.nadir_point, np.ndarray) else raw_result.nadir_point

            response = OptimizationResponse(
                success=raw_result.success,
                message=raw_result.message,
                result_type="multi",
                pareto_front=pareto_front,
                ideal_point=ideal_point,
                nadir_point=nadir_point,
                n_evaluations=raw_result.n_evaluations,
                # 元数据（仅保留必要内容，避免context包含不可序列化对象）
                original_expression=original_expression,
                final_expression=final_expression,
                expression_context={k: v for k, v in context.items() if isinstance(v, (str, int, float, list, dict))},
                data_shape=df.shape,
                data_columns=list(df.columns)
            )
        else:  # 单目标结果
            # 清理最优变量中的numpy类型
            optimal_vars = {}
            if raw_result.optimal_variables:
                for k, v in raw_result.optimal_variables.items():
                    if isinstance(v, (np.integer, np.floating)):
                        optimal_vars[k] = v.item()
                    elif isinstance(v, np.ndarray):
                        optimal_vars[k] = v.tolist()
                    else:
                        optimal_vars[k] = v

            optimal_obj = None
            if raw_result.optimal_objective is not None:
                # 转为浮点型
                optimal_obj = float(raw_result.optimal_objective)
                # 判断并替换无穷大/无穷小/NaN
                if np.isinf(optimal_obj):
                    optimal_obj = None  # 无穷大/小转为None，也可改为"Inf"/"-Inf"或业务允许的极值
                elif np.isnan(optimal_obj):
                    optimal_obj = None  # NaN转为None

            response = OptimizationResponse(
                success=raw_result.success,
                message=raw_result.message,
                result_type="single",
                optimal_variables=optimal_vars,
                optimal_objective=optimal_obj,  # 已处理无穷值的结果
                convergence_data=raw_result.convergence_data,
                n_evaluations=raw_result.n_evaluations,
                # 元数据（过滤context中的不可序列化对象）
                original_expression=original_expression,
                final_expression=final_expression,
                expression_context={k: v for k, v in context.items() if isinstance(v, (str, int, float, list, dict))},
                data_shape=df.shape,
                data_columns=list(df.columns)
            )

        logging.info("优化案例处理完成")
        return response.to_dict()

    except Exception as e:
        logging.error(f"优化案例处理失败: {str(e)}")
        logging.error(traceback.format_exc())
        # 异常时返回统一结构
        error_response = OptimizationResponse(
            success=False,
            message=f"优化失败: {str(e)}",
            result_type="error"
        )
        return error_response.to_dict()

def main_wrapper(config_path: str, data_path: str, result_path: str, log_path: str) -> bool:
    try:
        log_dir = os.path.dirname(log_path)
        log_file = os.path.basename(log_path).replace('.log', '')
        set_logging(log_dir=log_dir, file_name=log_file, mode='dev')
        logging.info("=" * 50)
        logging.info("开始执行优化案例")
        logging.info(f"配置文件: {config_path}")
        logging.info(f"数据文件: {data_path}")
        logging.info(f"结果文件: {result_path}")
        logging.info(f"日志文件: {log_path}")
        logging.info("=" * 50)
        config, df = load_config_and_data(config_path, data_path)

        results = optimize_case(df, config)

        save_results(result_path, results, success=True)

        logging.info("优化案例执行成功完成")
        return True

    except Exception as e:
        error_msg = f"执行失败: {str(e)}\n{traceback.format_exc()}"
        logging.error(error_msg)

        try:
            save_results(result_path, {}, success=False, error_msg=error_msg)
        except:
            pass

        return False


def parse_arguments():
    parser = argparse.ArgumentParser(description='优化案例处理脚本')
    parser.add_argument('--config', required=True, help='配置文件路径（JSON格式）')
    parser.add_argument('--data', required=True, help='数据文件路径或hash文件名')
    parser.add_argument('--result', required=True, help='结果文件路径（JSON格式）')
    parser.add_argument('--log', required=True, help='日志文件路径')
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_arguments()

    success = main_wrapper(
        config_path=args.config,
        data_path=args.data,
        result_path=args.result,
        log_path=args.log
    )

    sys.exit(0 if success else 1)