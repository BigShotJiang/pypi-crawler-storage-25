#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import json
import logging
import os
import sys
import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional
import traceback
import time
import hashlib


# 设置日志
def set_logging(log_dir: str, file_name: str, mode: str = 'dev'):
    """设置日志配置"""
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"{file_name}.log")

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - [%(filename)s:%(lineno)s-%(name)s]- %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )


class NumpyEncoder(json.JSONEncoder):
    """自定义JSON编码器，处理numpy类型"""

    def default(self, obj):
        if isinstance(obj, (np.integer, np.int32, np.int64)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float32, np.float64)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.bool_):
            return bool(obj)
        elif pd.isna(obj):
            return None
        return super(NumpyEncoder, self).default(obj)


class TablePipeline:
    """基于TableDataEngine的表格数据处理流水线"""

    def __init__(self, data_files_dir: str = "./projects/data/files"):
        self.current_data = None
        self.step_results = []
        self.engine = None
        self.data_files_dir = data_files_dir
        self._initialize_engine()

    def _initialize_engine(self):
        """初始化数据处理引擎"""
        try:
            # 动态导入TableDataEngine
            from tabledataproc import TableDataEngine
            self.engine = TableDataEngine()
            logging.info("TableDataEngine初始化成功")
        except ImportError as e:
            logging.error(f"无法导入TableDataEngine: {str(e)}")
            # 创建简易的引擎备用
            self.engine = self._create_fallback_engine()

    def _create_fallback_engine(self):
        """创建备用引擎"""

        class FallbackEngine:
            def __getattr__(self, name):
                # 对于所有方法，返回一个什么都不做的函数
                def method(*args, **kwargs):
                    if len(args) > 0 and isinstance(args[0], pd.DataFrame):
                        return args[0].copy()
                    return pd.DataFrame()

                return method

        return FallbackEngine()

    def _get_file_path_by_hash(self, filehash: str, filename: str) -> str:
        """根据文件hash获取实际文件路径"""
        if not filehash:
            raise ValueError("文件hash不能为空")

        # 方法1: 直接使用hash作为文件名（无后缀）
        hash_based_path = os.path.join(self.data_files_dir, filehash)

        # 方法2: 使用hash作为文件名，加上原文件后缀
        file_ext = os.path.splitext(filename)[1]
        hash_with_ext = os.path.join(self.data_files_dir, filehash + file_ext)

        # 方法3: 遍历目录查找匹配hash的文件
        logging.info(f"在目录 {self.data_files_dir} 中查找hash为 {filehash} 的文件...")
        for root, dirs, files in os.walk(self.data_files_dir):
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    # 计算文件hash进行匹配
                    with open(file_path, 'rb') as f:
                        file_content = f.read()
                        current_hash = hashlib.md5(file_content).hexdigest()
                        if current_hash == filehash:
                            logging.info(f"找到匹配文件: {file_path}")
                            return file_path
                except Exception as e:
                    logging.warning(f"计算文件hash失败 {file_path}: {str(e)}")
                    continue

        # 检查前两种方法
        if os.path.exists(hash_based_path):
            logging.info(f"找到文件: {hash_based_path}")
            return hash_based_path
        elif os.path.exists(hash_with_ext):
            logging.info(f"找到文件: {hash_with_ext}")
            return hash_with_ext
        else:
            # 最后尝试直接使用文件名
            direct_path = os.path.join(self.data_files_dir, filename)
            if os.path.exists(direct_path):
                logging.info(f"找到文件: {direct_path}")
                return direct_path

        raise FileNotFoundError(f"在目录 {self.data_files_dir} 中找不到hash为 {filehash} 的文件 {filename}")

    def load_table_data(self, table_metadata: Dict) -> pd.DataFrame:
        """加载表格数据 - 适配实际配置结构"""
        try:
            file_path = table_metadata.get('file_path', '')
            file_type = table_metadata.get('file_type', '')
            filename = table_metadata.get('name', '')
            filehash = table_metadata.get('filehash', '')

            logging.info(f"文件信息 - 文件名: {filename}, 文件路径: {file_path}, 文件hash: {filehash}")

            # 优先使用filehash查找文件
            if filehash:
                actual_file_path = self._get_file_path_by_hash(filehash, filename)
            elif file_path:
                # 如果file_path是相对路径，在数据目录中查找
                if not os.path.isabs(file_path):
                    actual_file_path = os.path.join(self.data_files_dir, file_path)
                else:
                    actual_file_path = file_path
            else:
                # 最后使用文件名查找
                actual_file_path = os.path.join(self.data_files_dir, filename)

            # 检查文件是否存在
            if not os.path.exists(actual_file_path):
                raise FileNotFoundError(f"文件不存在: {actual_file_path}")

            # 根据文件扩展名判断类型
            if not file_type:
                file_ext = os.path.splitext(actual_file_path)[1].lower().lstrip('.')
                if file_ext:
                    file_type = file_ext
                else:
                    file_type = self._detect_file_type(actual_file_path)

            logging.info(f"加载表格文件: {actual_file_path}, 类型: {file_type}")

            # 加载数据
            if file_type == 'csv':
                df = pd.read_csv(actual_file_path)
            elif file_type in ['excel', 'xlsx', 'xls']:
                df = pd.read_excel(actual_file_path)
            elif file_type == 'json':
                df = pd.read_json(actual_file_path)
            elif file_type == 'parquet':
                df = pd.read_parquet(actual_file_path)
            else:
                # 尝试自动检测
                try:
                    df = pd.read_csv(actual_file_path)
                    file_type = 'csv'
                except:
                    try:
                        df = pd.read_excel(actual_file_path)
                        file_type = 'excel'
                    except:
                        raise ValueError(f"不支持的文件类型: {file_type}")

            logging.info(f"表格加载成功: {len(df)} 行, {len(df.columns)} 列")
            logging.info(f"列名: {list(df.columns)}")

            return df

        except Exception as e:
            logging.error(f"加载表格数据失败: {str(e)}")
            raise

    def _detect_file_type(self, file_path: str) -> str:
        """检测文件类型"""
        import mimetypes
        mime_type, _ = mimetypes.guess_type(file_path)

        if mime_type:
            if mime_type == 'text/csv':
                return 'csv'
            elif mime_type in ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']:
                return 'excel'
            elif mime_type == 'application/json':
                return 'json'
            elif mime_type == 'application/parquet':
                return 'parquet'

        # 根据扩展名判断
        ext = os.path.splitext(file_path)[1].lower()
        if ext == '.csv':
            return 'csv'
        elif ext in ['.xlsx', '.xls']:
            return 'excel'
        elif ext == '.json':
            return 'json'
        elif ext == '.parquet':
            return 'parquet'

        return 'unknown'

    def execute_step(self, step_config: Dict, step_index: int) -> Dict:
        """执行单个处理步骤"""
        step_type = step_config['type']
        step_id = step_config.get('id', f'step_{step_index}')
        config = step_config.get('config', {})

        logging.info(f"执行步骤 {step_index + 1}: {step_type} (ID: {step_id})")

        start_time = time.time()

        try:
            # 记录步骤前的状态
            before_columns = list(self.current_data.columns)
            before_count = len(self.current_data)
            before_sample = self._get_sample_data(3)

            # 执行步骤处理
            result_data = self._execute_step_processing(step_type, config, step_id)

            # 更新当前数据
            self.current_data = result_data

            # 记录步骤后的状态
            after_columns = list(self.current_data.columns)
            after_count = len(self.current_data)
            after_sample = self._get_sample_data(3)

            execution_time = round(time.time() - start_time, 3)

            # 构建步骤结果
            step_result = {
                "step_id": step_id,
                "step_type": step_type,
                "step_index": step_index,
                "success": True,
                "message": f"步骤 {step_type} 执行成功",
                "input_columns": before_columns,
                "output_columns": after_columns,
                "input_data_length": before_count,
                "output_data_length": after_count,
                "execution_time": f"{execution_time}s",
                "input_sample_data": before_sample,
                "output_sample_data": after_sample
            }

            # 添加步骤特定的统计信息
            step_stats = self._get_step_statistics(step_type, before_count, after_count, before_columns, after_columns, config)
            step_result.update(step_stats)

            logging.info(f"步骤完成: {before_count} -> {after_count} 行, {len(before_columns)} -> {len(after_columns)} 列")

            return step_result

        except Exception as e:
            import traceback
            execution_time = round(time.time() - start_time, 3)
            logging.error(f"步骤执行失败: {str(e)} {traceback.format_exc()}")

            return {
                "step_id": step_id,
                "step_type": step_type,
                "step_index": step_index,
                "success": False,
                "message": f"步骤执行失败: {str(e)}  {traceback.format_exc()}",
                "error": str(e),
                "input_columns": list(self.current_data.columns) if self.current_data is not None else [],
                "output_columns": list(self.current_data.columns) if self.current_data is not None else [],
                "input_data_length": len(self.current_data) if self.current_data is not None else 0,
                "output_data_length": len(self.current_data) if self.current_data is not None else 0,
                "execution_time": f"{execution_time}s",
                "input_sample_data": self._get_sample_data(3) if self.current_data is not None else [],
                "output_sample_data": self._get_sample_data(3) if self.current_data is not None else []
            }

    def _execute_step_processing(self, step_type: str, config: Dict, step_id: str) -> pd.DataFrame:
        """执行具体的步骤处理"""
        if step_type == 'Rename':
            return self.engine.rename(self.current_data, config)

        elif step_type == 'Filter':
            return self.engine.filter(self.current_data, config)

        elif step_type == 'Sample':
            return self.engine.sample(self.current_data, config)

        elif step_type == 'Deduplicate':
            return self.engine.deduplicate(self.current_data, config)

        elif step_type in ['type_transform','typeConfig',"Type"] :
            return self.engine.type_transform(self.current_data, config)

        elif step_type == 'Sort':
            return self.engine.sort(self.current_data, config)

        elif step_type == 'Feature_derive':
            return self.engine.feature_derive(self.current_data, config)


        elif step_type == 'Merge':
            # 1. 从配置中提取右表的元数据（前端需传递右表信息）
            right_table_metadata = config.get('rightTable', {})  # 右表元数据
            if not right_table_metadata:
                raise ValueError("Merge配置中缺少右表元数据（rightTable）")
            # 2. 加载右表数据（复用已有的加载逻辑）
            right_df = self.load_table_data(right_table_metadata)
            if right_df.empty:
                raise ValueError("右表数据为空，无法执行合并操作")
            # 3. 调用引擎的merge方法（左表：current_data，右表：right_df，配置：config）

            merged_df = self.engine.merge(self.current_data, right_df, config)

            logging.info(f"Merge操作完成：左表{self.current_data.shape} + 右表{right_df.shape} = 合并后{merged_df.shape}")
            return merged_df

            #raise NotImplementedError("合并操作需要额外的配置支持")

        elif step_type == 'Append':
            # 追加操作需要额外的数据框列表
            raise NotImplementedError("追加操作需要额外的配置支持")

        elif step_type == 'DataEdit':
            return self.engine.data_edit(self.current_data, config)

        elif step_type == 'fill_missing':
            return self.engine.fill_missing(self.current_data, config)

        else:
            raise ValueError(f"未知的步骤类型: {step_type}")

    def _get_step_statistics(self, step_type: str, before_count: int, after_count: int,
                             before_columns: List, after_columns: List, config: Dict) -> Dict:
        """获取步骤统计信息"""
        stats = {
            "rows_changed": after_count - before_count,
            "columns_changed": len(after_columns) - len(before_columns),
            "rows_change_percentage": round((after_count - before_count) / before_count * 100, 2) if before_count > 0 else 0
        }

        # 根据步骤类型添加特定统计
        if step_type == 'rename':
            rename_mapping = config.get('renameMapping', {})
            stats["renamed_columns"] = len(rename_mapping)
            stats["rename_mapping"] = rename_mapping

        elif step_type == 'filter':
            stats["filtered_rows"] = before_count - after_count
            stats["filtered_percentage"] = round((before_count - after_count) / before_count * 100, 2) if before_count > 0 else 0

        elif step_type == 'sample':
            stats["sampling_ratio"] = round(after_count / before_count, 2) if before_count > 0 else 0

        elif step_type == 'deduplicate':
            stats["duplicates_removed"] = before_count - after_count
            stats["duplicate_percentage"] = round((before_count - after_count) / before_count * 100, 2) if before_count > 0 else 0

        elif step_type == 'feature_derive':
            new_columns = [col for col in after_columns if col not in before_columns]
            stats["new_features"] = new_columns
            stats["features_count"] = len(new_columns)

        elif step_type == 'type_transform':
            transform_configs = config.get('transformConfigs', [])
            stats["type_transforms"] = len(transform_configs)

        return stats

    def _get_sample_data(self, n: int = 3) -> List[Dict]:
        """获取样例数据"""
        if self.current_data is None or len(self.current_data) == 0:
            return []

        sample_size = min(n, len(self.current_data))

        try:
            sample_data = self.engine.get_sample_data(self.current_data, sample_size)
            return sample_data
        except:
            # 备用方案
            sample_df = self.current_data.head(sample_size)
            sample_data = sample_df.replace({np.nan: None}).to_dict('records')
            return sample_data

    def process_pipeline(self, main_table_metadata: Dict, processing_steps: List[Dict], output_config: Dict, work_dir: str) -> Dict:
        """执行完整的处理流水线"""
        try:
            # 加载主表数据
            logging.info(f"开始加载主表数据: {main_table_metadata}")
            self.current_data = self.load_table_data(main_table_metadata)
            original_columns = list(self.current_data.columns)
            original_count = len(self.current_data)
            original_sample = self._get_sample_data(5)

            logging.info(f"开始执行处理流水线，共 {len(processing_steps)} 个步骤")

            # 执行每个步骤
            total_steps = len(processing_steps)
            completed_steps = 0
            failed_steps = []

            for i, step in enumerate(processing_steps):
                step_result = self.execute_step(step, i)
                self.step_results.append(step_result)

                if step_result['success']:
                    completed_steps += 1
                    logging.info(f"步骤 {i + 1} 执行成功")
                else:
                    failed_steps.append({
                        "step_index": i,
                        "step_id": step_result.get('step_id'),
                        "error": step_result.get('error')
                    })
                    logging.error(f"步骤 {i + 1} 执行失败: {step_result['message']}")

            # 检查是否有失败的步骤，如果有则整个流水线失败
            if failed_steps:
                logging.error(f"流水线执行失败，共有 {len(failed_steps)} 个步骤失败")
                return {
                    "success": False,
                    "error": f"{len(failed_steps)} 个步骤执行失败",
                    "failed_steps": failed_steps,
                    "completed_steps": completed_steps,
                    "total_steps": total_steps,
                    "record_id": getattr(self, 'record_id', 'unknown')
                }

            # 准备最终输出
            final_columns = list(self.current_data.columns)
            final_count = len(self.current_data)
            final_sample = self._get_sample_data(5)

            # 保存处理结果
            output_format = output_config.get('format', 'csv')
            include_steps = output_config.get('includeSteps', True)

            # 使用work_dir作为输出目录
            os.makedirs(work_dir, exist_ok=True)

            # 生成输出文件名
            output_filename = f"output_{int(time.time())}.{output_format}"
            output_file = os.path.join(work_dir, output_filename)

            if output_format == 'csv':
                self.current_data.to_csv(output_file, index=False, encoding='utf-8')
            elif output_format == 'excel':
                self.current_data.to_excel(output_file, index=False)
            elif output_format == 'json':
                self.current_data.to_json(output_file, orient='records', indent=2, force_ascii=False)
            elif output_format == 'parquet':
                self.current_data.to_parquet(output_file, index=False)

            logging.info(f"处理结果保存到: {output_file}")

            # 构建最终结果
            result = {
                "success": True,
                "record_id": getattr(self, 'record_id', 'unknown'),
                "input_table": main_table_metadata.get('name', 'unknown'),
                "original_columns": original_columns,
                "original_count": original_count,
                "original_sample_data": original_sample,
                "final_columns": final_columns,
                "final_count": final_count,
                "final_sample_data": final_sample,
                "total_steps": total_steps,
                "completed_steps": completed_steps,
                "failed_steps": failed_steps,
                "step_results": self.step_results,
                "output_file": output_file,
                "output_filename": output_filename,
                "processing_summary": {
                    "input_shape": (original_count, len(original_columns)),
                    "output_shape": (final_count, len(final_columns)),
                    "total_processing_time": sum(float(step.get('execution_time', '0s').rstrip('s')) for step in self.step_results),
                    "success_rate": round(completed_steps / total_steps * 100, 2) if total_steps > 0 else 0
                }
            }

            logging.info(f"处理流水线执行完成: {completed_steps}/{total_steps} 个步骤成功")
            logging.info(f"数据变化: {original_count}行/{len(original_columns)}列 -> {final_count}行/{len(final_columns)}列")

            return result

        except Exception as e:
            logging.error(f"处理流水线执行失败: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "traceback": traceback.format_exc(),
                "completed_steps": completed_steps if 'completed_steps' in locals() else 0,
                "total_steps": total_steps if 'total_steps' in locals() else len(processing_steps),
                "failed_steps": failed_steps if 'failed_steps' in locals() else []
            }


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='表格数据处理流水线')
    parser.add_argument('--config_file', type=str, required=True, help='配置文件路径'    )
    parser.add_argument('--result_file', type=str, required=True, help='结果文件路径'    )
    parser.add_argument('--log_path',    type=str, required=True, help='日志文件路径'       )
    parser.add_argument('--data_dir',    type=str, default='./projects/data/files', help='数据文件目录')

    args = parser.parse_args()

    # 设置日志
    log_dir = os.path.dirname(args.log_path)
    log_file = os.path.basename(args.log_path).replace('.log', '')
    set_logging(log_dir=log_dir, file_name=log_file, mode='dev')

    try:
        # 读取配置文件
        with open(args.config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)

        logging.info(f"加载配置文件: {args.config_file}")

        # 提取配置参数 - 根据实际配置结构
        record_id = config.get('record_id', 'unknown')
        table_metadata = config.get('table_metadata', {})
        processing_steps = config.get('processing_steps', [])
        output_config = config.get('output_config', {})
        work_dir = config.get('work_dir', '.')

        # 设置record_id
        TablePipeline.record_id = record_id

        logging.info(f"开始处理记录: {record_id}")
        logging.info(f"主表: {table_metadata.get('main_table', {}).get('name', 'unknown')}")
        logging.info(f"处理步骤: {len(processing_steps)} 个")
        logging.info(f"工作目录: {work_dir}")

        # 执行表格处理流水线
        pipeline = TablePipeline(data_files_dir=args.data_dir)
        result = pipeline.process_pipeline(
            table_metadata['main_table'],
            processing_steps,
            output_config,
            work_dir
        )

        # 添加record_id到结果
        result['record_id'] = record_id

        # 保存结果
        with open(args.result_file, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2, cls=NumpyEncoder)

        # 创建简化结果用于日志输出
        simplified_result = {
            "success": result["success"],
            "record_id": record_id,
            "input_table": result.get("input_table", "unknown"),
            "original_count": result.get("original_count", 0),
            "final_count": result.get("final_count", 0),
            "total_steps": result.get("total_steps", 0),
            "completed_steps": result.get("completed_steps", 0),
            "output_file": result.get("output_file", ""),
            "success_rate": result.get("processing_summary", {}).get("success_rate", 0)
        }

        if not result["success"]:
            simplified_result["error"] = result.get("error", "未知错误")

        logging.info(f"处理完成摘要: {json.dumps(simplified_result, ensure_ascii=False, indent=2)}")

        if result["success"]:
            print(f"处理完成! 结果保存在: {args.result_file}")
        else:
            print(f"处理失败! 错误信息: {result.get('error', '未知错误')}")
            sys.exit(1)

    except Exception as e:
        import traceback
        logging.error(f"表格处理流水线执行失败: {str(e)}  {traceback.format_exc()}")
        # 保存错误结果
        error_result = {
            "success": False,
            "error": str(e),
            "traceback": traceback.format_exc(),
            "config_file": args.config_file,
            "record_id": config.get('record_id', 'unknown') if 'config' in locals() else 'unknown'
        }
        with open(args.result_file, 'w', encoding='utf-8') as f:
            json.dump(error_result, f, ensure_ascii=False, indent=2)
        print(f"处理失败! 错误信息: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()