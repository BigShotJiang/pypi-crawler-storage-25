# 组件工具类（单例模式，缓存模型）
class ExtendedTool:
    _instance = None
    _models = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def load_sam_model(self, model_type: str = "vit_b") -> SamAutomaticMaskGenerator:
        """加载SAM分割模型（自动下载预训练权重）"""
        model_key = f"sam_{model_type}"
        if model_key in self._models:
            return self._models[model_key]

        # SAM权重下载地址（官方提供）
        sam_weights_url = {
            "vit_h": "https://dl.fbaipublicfiles.com/segment_anything/sam_vit_h_4b8939.pth",
            "vit_l": "https://dl.fbaipublicfiles.com/segment_anything/sam_vit_l_0b3195.pth",
            "vit_b": "https://dl.fbaipublicfiles.com/segment_anything/sam_vit_b_01ec64.pth"
        }
        weight_path = f"./models/sam_{model_type}.pth"
        os.makedirs("./models", exist_ok=True)

        # 自动下载权重
        if not os.path.exists(weight_path):
            import requests
            print(f"自动下载SAM模型权重：{sam_weights_url[model_type]}")
            response = requests.get(sam_weights_url[model_type], stream=True)
            with open(weight_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=1024):
                    if chunk:
                        f.write(chunk)

        # 初始化模型
        sam = sam_model_registry[model_type](checkpoint=weight_path)
        mask_generator = SamAutomaticMaskGenerator(
            sam,
            points_per_side=32,
            pred_iou_thresh=0.88,
            stability_score_thresh=0.95,
            crop_n_layers=1,
            crop_n_points_downscale_factor=2,
            min_mask_region_area=100
        )
        self._models[model_key] = mask_generator
        return mask_generator

    def load_easyocr_model(self, languages: List[str] = ["ch_sim", "en"]) -> easyocr.Reader:
        """加载EasyOCR模型（自动下载语言包）"""
        model_key = f"easyocr_{'_'.join(languages)}"
        if model_key in self._models:
            return self._models[model_key]

        # 初始化OCR阅读器（自动下载语言包）
        reader = easyocr.Reader(languages, gpu=False)  # gpu=True需安装CUDA
        self._models[model_key] = reader
        return reader