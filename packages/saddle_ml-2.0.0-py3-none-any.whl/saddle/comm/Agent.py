import json
import os
import base64
import sys
import asyncio
from typing import Dict, List, Optional, Union, Any, Tuple, Callable
from pydantic import BaseModel, field_validator, Field, ConfigDict
import requests
import numpy as np
from abc import ABC, abstractmethod
from datetime import datetime
from enum import Enum
import hashlib
from collections import deque
import importlib
import inspect
from PIL import Image
from io import BytesIO
from openai import OpenAI
import logging
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor
import concurrent.futures

def setup_logging():
    """设置统一的日志系统"""
    log_dir = "./logs"
    os.makedirs(log_dir, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_dir, f"multi_agent_engine_{timestamp}.log")

    # 配置日志
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s][%(name)s][%(levelname)s][%(module)s:%(lineno)d] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger("agent")

setup_logging()

class ModalityType(str, Enum):
    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    MULTIMODAL = "multimodal"


class OutputType(str, Enum):
    TEXT = "text"
    JSON = "json"
    IMAGE = "image"
    AUDIO = "audio"
    MARKDOWN = "markdown"
    HTML = "html"


class PromptType(str, Enum):
    SIMPLE = "simple"
    CHAT = "chat"
    FEW_SHOT = "few_shot"
    MMR_FEW_SHOT = "mmr_few_shot"
    CHAT_WITH_HISTORY = "chat_with_history"
    FEW_SHOT_CHAT = "few_shot_chat"


class ExecutionStrategy(str, Enum):
    SINGLE = "single"
    PARALLEL = "parallel"
    SEQUENTIAL = "sequential"
    VOTE = "vote"


class ModelWeightStrategy(str, Enum):
    WEIGHTED = "weighted"
    AVERAGE = "average"
    RANK = "rank"


class MemoryType(str, Enum):
    FULL = "full"
    SUMMARY = "summary"
    RELEVANT = "relevant"


class VectorStoreType(str, Enum):
    FAISS = "faiss"
    CHROMA = "chroma"
    MILVUS = "milvus"
    PINECONE = "pinecone"


# ====================== 配置模型 ======================
class ToolParameter(BaseModel):
    name: str
    type: str
    required: bool = True
    description: Optional[str] = None
    enum: Optional[List[str]] = None
    format: Optional[str] = None

    model_config = ConfigDict(extra='ignore', strict=False)


class ToolConfig(BaseModel):
    name: str
    description: str
    parameters: List[ToolParameter]
    code: Optional[str] = None
    is_custom: bool = False
    output_types: List[OutputType] = [OutputType.TEXT]

    model_config = ConfigDict(extra='ignore', strict=False)


class ModelConfig(BaseModel):
    """模型配置类 - 支持豆包、Ollama等多种模型"""
    model_type: str
    api_key: Optional[str] = None  # 可选，Ollama不需要
    base_url: str = "https://ark.cn-beijing.volces.com/api/v3"  # 豆包默认
    model_name: str  # 模型ID（如doubao-seed-1-6-250615或llama3.2）

    # Ollama特有配置
    ollama_host: str = "http://127.0.0.1:11434"  # Ollama默认地址
    ollama_stream: bool = False  # 是否流式输出

    # 通用参数
    temperature: float = 0.7
    max_tokens: int = 1024
    top_p: float = 1.0
    frequency_penalty: float = 0
    presence_penalty: float = 0

    model_config = ConfigDict(extra='ignore', strict=False)


class PromptExample(BaseModel):
    input: str
    output: str

    model_config = ConfigDict(extra='ignore', strict=False)


class PromptConfig(BaseModel):
    prompt_type: PromptType = PromptType.CHAT
    template: Optional[str] = None
    system_message: Optional[str] = None
    human_template: Optional[str] = None
    examples: Optional[List[PromptExample]] = None
    example_template: Optional[str] = None
    prefix: Optional[str] = None
    suffix: Optional[str] = None
    input_variables: List[str] = []
    history_variable: str = "history"
    embeddings_model_path: Optional[str] = None
    k: int = 4

    model_config = ConfigDict(extra='ignore', strict=False)


class MemoryConfig(BaseModel):
    enabled: bool = True
    size: int = 10
    type: MemoryType = MemoryType.FULL
    persist: bool = False

    model_config = ConfigDict(extra='ignore', strict=False)


class VectorStoreConfig(BaseModel):
    type: VectorStoreType = VectorStoreType.FAISS
    path: Optional[str] = "./vector_store"
    url: Optional[str] = None
    api_key: Optional[str] = None

    model_config = ConfigDict(extra='ignore', strict=False)


class AgentConfig(BaseModel):
    agent_name: str = "SmartAgent"
    exec_strategy: ExecutionStrategy = ExecutionStrategy.SINGLE
    participating_agents: List[str] = []
    execution_order: Optional[str] = None
    vote_threshold: float = 0.7

    prompt_config: PromptConfig = Field(default_factory=PromptConfig)

    model_mode: str = "single"
    model_type: Optional[str] = None  # 对应ModelConfig的model_type
    model_settings: Dict[str, Any] = Field(default_factory=dict)  # 存储豆包API密钥、模型ID等

    multi_model_configs: Optional[List[ModelConfig]] = None
    model_weight_strategy: Optional[ModelWeightStrategy] = None

    temperature: float = 0.7
    max_tokens: int = 1024
    top_p: float = 0.7
    frequency_penalty: float = 0

    enabled_tools: List[str] = []
    custom_tools: List[ToolConfig] = []
    action_timeout: int = 60
    action_rate_limit: int = 60
    action_safety_check: str = "medium"
    forbidden_actions: List[str] = []

    memory_config: MemoryConfig = Field(default_factory=MemoryConfig)
    vector_store_config: VectorStoreConfig = Field(default_factory=VectorStoreConfig)

    max_iterations: int = 5
    early_stopping: bool = True
    verbose: bool = False

    supports_multimodal: bool = True  # 默认支持多模态（适配豆包）
    input_modality: ModalityType = ModalityType.TEXT
    default_output_type: OutputType = OutputType.TEXT

    @field_validator('model_mode')
    def validate_model_mode(cls, v):
        if v not in ['single', 'multiple']:
            raise ValueError('model_mode must be "single" or "multiple"')
        return v

    model_config = ConfigDict(extra='ignore', strict=False)


# ====================== 基础组件 ======================
class BaseLLM(ABC):
    def __init__(self, config: ModelConfig):
        self.config = config
        self.supported_modalities = [ModalityType.TEXT]

    @abstractmethod
    def generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        pass

    @abstractmethod
    async def async_generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        pass


class BaseTool(ABC):
    def __init__(self, config: ToolConfig):
        self.config = config
        self.name = config.name
        self.description = config.description
        self.parameters = config.parameters
        self.output_types = config.output_types

    @abstractmethod
    def execute(self, **kwargs) -> Dict:
        pass

    @abstractmethod
    async def async_execute(self, **kwargs) -> Dict:
        pass


class BaseMultiModalTool(BaseTool):
    def __init__(self, config: ToolConfig):
        super().__init__(config)
        self.supported_modalities = self._init_modalities()

    def _init_modalities(self) -> List[ModalityType]:
        modalities = []
        for param in self.parameters:
            if param.format == 'base64':
                if param.name.startswith('image'):
                    modalities.append(ModalityType.IMAGE)
                elif param.name.startswith('audio'):
                    modalities.append(ModalityType.AUDIO)
                elif param.name.startswith('video'):
                    modalities.append(ModalityType.VIDEO)
        return list(set(modalities))


class BaseMemory(ABC):
    def __init__(self, config: MemoryConfig):
        self.config = config
        self.memory = deque(maxlen=config.size)

    def add(self, message: str):
        self.memory.append(message)

    def get(self) -> List[str]:
        return list(self.memory)

    def clear(self):
        self.memory.clear()

    @abstractmethod
    def summarize(self) -> str:
        pass


class OllamaModel(BaseLLM):
    def __init__(self, config: ModelConfig):
        super().__init__(config)
        self.model_name = config.model_name
        self.raw_base_url = config.base_url
        self.stream = config.ollama_stream
        self.temperature = config.temperature
        self.max_tokens = config.max_tokens
        self.api_info = self._parse_api_endpoint(self.raw_base_url)
        self.api_root = self.api_info["api_root"]
        self.preferred_endpoint = self.api_info["endpoint"]
        self.effective_api_type = None
        self.request_kwargs = {
            "proxies": {"http": None, "https": None},
            "verify": False,
            "headers": {"Content-Type": "application/json"}
        }
        # 支持的模态类型
        self.supported_modalities = [ModalityType.TEXT]
        logging.info(f"Ollama初始化完成 - API根地址: {self.api_root}, 指定端点: {self.preferred_endpoint}")

    def _parse_api_endpoint(self, raw_url: str) -> Dict:
        """解析URL，智能判断用户意图的API端点"""
        try:
            # 补全协议头
            if not raw_url.startswith(("http://", "https://")):
                raw_url = f"http://{raw_url}"

            parsed = urlparse(raw_url)

            # 提取host和port
            host = parsed.hostname or "127.0.0.1"
            port = parsed.port or 11434

            # 构建API根地址（协议+主机+端口）
            scheme = parsed.scheme or "http"
            api_root = f"{scheme}://{host}:{port}"

            # 分析路径部分，判断用户指定的API端点
            endpoint = None
            if parsed.path:
                # 清理路径，去除前后斜杠
                clean_path = parsed.path.strip('/')

                # 检查是否明确指定了API端点
                if clean_path.startswith("api/"):
                    # 提取API端点路径
                    endpoint_path = clean_path.replace("api/", "", 1)

                    if endpoint_path == "generate":
                        endpoint = "generate"
                        logging.info(f"用户明确指定使用generate端点: {endpoint_path}")
                    elif endpoint_path == "chat":
                        endpoint = "chat"
                        logging.info(f"用户明确指定使用chat端点: {endpoint_path}")
                    elif endpoint_path == "" or endpoint_path == "/":
                        # 仅/api/，未指定具体端点
                        endpoint = None
                    else:
                        # 其他未知路径
                        logging.warning(f"未知的API路径: {endpoint_path}，将自动检测")

                else:
                    # 非API路径，可能是其他配置
                    logging.warning(f"URL包含非标准API路径: {parsed.path}，将使用自动检测")

            return {
                "api_root": api_root,
                "endpoint": endpoint,  # None表示未指定，需要自动检测
                "original_path": parsed.path
            }

        except Exception as e:
            raise ValueError(f"URL解析失败: {raw_url}, 错误: {str(e)}")

    def _detect_best_api(self) -> str:
        """自动检测可用的最佳API端点"""
        test_prompt = "test"

        # 1. 如果用户明确指定了端点，直接返回
        if self.preferred_endpoint:
            logging.info(f"{self.model_name},Using user-specified  endpoint: {self.preferred_endpoint}")
            return self.preferred_endpoint

        # 2. 用户未指定，按顺序检测
        logging.info("用户未指定API端点，开始自动检测...")

        # 优先级：先尝试chat（功能更强），再尝试generate
        for api_type in ["chat", "generate"]:
            api_url = f"{self.api_root}/api/{api_type}"
            try:
                test_data = {
                    "model": self.model_name,
                    "stream": False,
                    "options": {"num_predict": 1}
                }

                # 调整数据结构以适应不同API
                if api_type == "chat":
                    test_data["messages"] = [{"role": "user", "content": test_prompt}]
                else:
                    test_data["prompt"] = test_prompt

                response = requests.post(
                    api_url,
                    json=test_data,
                    timeout=5,
                    **self.request_kwargs
                )

                if response.status_code == 200:
                    logging.info(f"✓ 检测到可用{api_type}端点，将使用该接口")
                    return api_type
                else:
                    logging.warning(f"✗ {api_type}端点返回异常状态码: {response.status_code}")

            except Exception as e:
                logging.warning(f"✗ {api_type}端点检测失败: {str(e)}")

        # 3. 所有检测都失败
        raise ConnectionError(
            f"无法连接到任何Ollama API端点 ({self.api_root})\n"
            f"1. 确保Ollama服务正在运行 (ollama serve)\n"
            f"2. 检查服务地址是否正确\n"
            f"3. 确认模型 {self.model_name} 已拉取 (ollama pull {self.model_name})"
        )

    def _check_ollama_health(self):
        """健康检查，验证服务状态和模型"""
        try:
            response = requests.get(
                f"{self.api_root}/api/tags",
                timeout=5,
                **self.request_kwargs
            )

            if response.status_code != 200:
                raise ConnectionError(
                    f"Ollama服务异常，状态码: {response.status_code}，响应: {response.text}"
                )

            # 检查模型是否存在
            models = response.json().get("models", [])
            model_names = [m.get("name") for m in models]
            if self.model_name not in model_names:
                raise ConnectionError(f"模型 {self.model_name} 未找到，可用模型: {model_names}")

            logging.info(f"✓ Ollama服务正常，模型 {self.model_name} 可用")

        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(
                f"无法连接到Ollama服务 ({self.api_root})，请检查:\n"
                f"1. Ollama是否运行 (ollama serve)\n"
                f"2. 网络连接是否正常\n"
                f"3. 防火墙设置\n"
                f"错误详情: {str(e)}"
            )
        except Exception as e:
            raise ConnectionError(f"健康检查失败: {str(e)}")

    def _build_chat_request(self, prompt: Union[str, Dict]) -> Dict:
        """构建chat API请求参数"""
        messages = []

        # 系统消息
        if hasattr(self.config, "extra") and self.config.extra.get("system_message"):
            messages.append({
                "role": "system",
                "content": self.config.extra.get("system_message")
            })

        # 用户消息
        if isinstance(prompt, dict):
            if "text" in prompt:
                messages.append({"role": "user", "content": prompt["text"].strip()})
            elif "images" in prompt:
                messages.append({
                    "role": "user",
                    "content": "",
                    "images": prompt["images"]
                })
            else:
                messages.append({"role": "user", "content": str(prompt).strip()})
        else:
            messages.append({"role": "user", "content": prompt.strip()})

        return {
            "model": self.model_name,
            "messages": messages,
            "stream": self.stream,
            "options": {
                "temperature": self.temperature,
                "num_predict": self.max_tokens,
                "top_p": self.config.top_p,
                "repeat_penalty": self.config.frequency_penalty + 1.0
            }
        }

    def _build_generate_request(self, prompt: Union[str, Dict]) -> Dict:
        """构建generate API请求参数"""
        if isinstance(prompt, dict):
            prompt_text = prompt.get("text", str(prompt)).strip()
        else:
            prompt_text = prompt.strip()

        return {
            "model": self.model_name,
            "prompt": prompt_text,
            "stream": self.stream,
            "options": {
                "temperature": self.temperature,
                "num_predict": self.max_tokens,
                "top_p": self.config.top_p,
                "repeat_penalty": self.config.frequency_penalty + 1.0
            }
        }

    def _parse_response(self, response, api_type: str) -> Dict:
        """统一解析响应（根据API类型）"""
        if self.stream:
            full_content = ""
            raw_chunks = []

            for line in response.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line.decode('utf-8'))
                        raw_chunks.append(chunk)

                        # 提取内容 - 适配chat接口的特殊字段
                        if api_type == "chat":
                            # 优先读取content，为空则读取thinking
                            chunk_content = chunk.get("message", {}).get("content", "")
                            if not chunk_content:
                                chunk_content = chunk.get("message", {}).get("thinking", "")
                            full_content += chunk_content
                        else:  # generate
                            if "response" in chunk:
                                full_content += chunk["response"]

                        # 检查是否结束
                        if chunk.get("done", False):
                            break

                    except json.JSONDecodeError:
                        logging.warning(f"流式响应解析失败: {line}")
                        continue

            # 处理空内容情况
            if not full_content and raw_chunks:
                # 从最后一个chunk尝试提取thinking
                last_chunk = raw_chunks[-1]
                full_content = last_chunk.get("message", {}).get("thinking", "") or "未获取到有效响应"

            return {
                "output_type": OutputType.TEXT,
                "data": full_content.strip(),
                "raw_response": raw_chunks if raw_chunks else {"stream_content": full_content}
            }
        else:
            result = response.json()

            # 提取内容 - 核心修复点
            content = ""
            if api_type == "chat":
                # 1. 优先读取content字段
                content = result.get("message", {}).get("content", "").strip()
                # 2. content为空时，读取thinking字段（Qwen3模型的特殊处理）
                if not content:
                    content = result.get("message", {}).get("thinking", "").strip()
                    logging.info(f"Chat接口content为空，使用thinking字段内容: {content[:50]}...")
            else:  # generate
                content = result.get("response", "").strip()

            # 优化异常判断：只有真的空内容才提示异常
            if not content:
                content = f"{api_type}接口未返回有效内容，原始响应: {str(result)[:200]}..."

            return {
                "output_type": OutputType.TEXT,
                "data": content,
                "raw_response": result
            }

    def generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        """同步调用Ollama API"""
        try:
            # 1. 首次调用时检测API端点
            if not self.effective_api_type:
                self.effective_api_type = self._detect_best_api()
                logging.info(f"selecte API endpoint: {self.effective_api_type}")

            # 2. 构建请求
            api_url = f"{self.api_root}/api/{self.effective_api_type}"

            if self.effective_api_type == "chat":
                request_data = self._build_chat_request(prompt)
            else:
                request_data = self._build_generate_request(prompt)

            # 3. 发送请求
            timeout = kwargs.get("timeout", 300)  # 默认5分钟超时
            response = requests.post(
                api_url,
                json=request_data,
                stream=self.stream,
                timeout=timeout,
                **self.request_kwargs
            )

            # 4. 检查响应
            if response.status_code != 200:
                try:
                    error_detail = response.json().get("error", response.text)
                except:
                    error_detail = response.text

                error_msg = f"API调用失败 ({api_url})，状态码: {response.status_code}，详情: {error_detail}"
                logging.error(error_msg)
                return {
                    "output_type": OutputType.TEXT,
                    "data": error_msg,
                    "error": True
                }

            # 5. 解析响应
            return self._parse_response(response, self.effective_api_type)

        except requests.exceptions.Timeout:
            error_msg = f"API调用超时 ({self.api_root})，请检查网络或增加超时时间"
            logging.error(error_msg)
            return {
                "output_type": OutputType.TEXT,
                "data": "run error, fail",
                "error": True
            }
        except requests.exceptions.ConnectionError as e:
            error_msg = f"无法连接到Ollama服务 ({self.api_root})，请检查服务状态"
            logging.error(f"{error_msg}，详情: {str(e)}")
            return {
                "output_type": OutputType.TEXT,
                "data": "run error, fail",  #error_msg
                "error": True
            }
        except Exception as e:
            error_msg = f"API调用异常: {str(e)}"
            logging.error(error_msg)
            return {
                "output_type": OutputType.TEXT,
                "data": "run error, fail",
                "error": True
            }

    async def async_generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        """异步调用Ollama API"""
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        # 使用线程池执行同步方法
        with ThreadPoolExecutor(max_workers=1) as pool:
            result = await loop.run_in_executor(
                pool,
                lambda: self.generate(prompt, **kwargs)
            )
        return result

# ====================== 其他模型实现 ======================
class DoubaoModel(BaseLLM):
    """豆包大模型实现 - 基于官方API示例修复"""

    def __init__(self, config: ModelConfig):
        super().__init__(config)
        # 从配置中读取豆包必要参数（严格匹配官方示例）
        self.api_key = config.api_key
        self.base_url = config.base_url
        self.model_name = config.model_name  # 豆包模型ID（如doubao-seed-1-6-250615）
        self.temperature = config.temperature
        self.max_tokens = config.max_tokens

        # 初始化豆包OpenAI客户端（严格遵循官方示例）
        self.client = OpenAI(
            api_key=self.api_key,
            base_url=self.base_url
        )
        # 豆包支持的模态（文本+图像）
        self.supported_modalities = [ModalityType.TEXT, ModalityType.IMAGE]

    def _has_valid_credentials(self) -> bool:
        """检查API密钥是否有效（非空）"""
        return bool(self.api_key.strip())

    def _build_messages(self, prompt: Union[str, Dict]) -> List[Dict]:
        """构建豆包要求的消息格式（支持纯文本/多模态）"""
        messages = []

        # 1. 处理系统消息（若有）
        system_msg = self.config.extra.get("system_message") if hasattr(self.config, "extra") else None
        if system_msg:
            messages.append({"role": "system", "content": system_msg})

        # 2. 处理用户输入（纯文本/多模态）
        if isinstance(prompt, dict):
            # 多模态输入（文本+图像）
            user_content = []
            # 处理文本部分
            if "text" in prompt and prompt["text"].strip():
                user_content.append({"type": "text", "text": prompt["text"].strip()})
            # 处理图像部分（支持Base64或URL，遵循官方示例）
            if "image" in prompt:
                image_data = prompt["image"]
                if image_data.startswith("http"):
                    # 图像URL格式
                    user_content.append({
                        "type": "image_url",
                        "image_url": {"url": image_data}
                    })
                else:
                    # Base64格式（需添加数据头）
                    user_content.append({
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{image_data}"}
                    })
            messages.append({"role": "user", "content": user_content})

        else:
            # 纯文本输入（直接作为字符串）
            messages.append({"role": "user", "content": prompt.strip()})

        return messages

    def generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        """同步调用豆包API（修复认证、消息格式、错误处理）"""
        # 1. 先检查API密钥
        if not self._has_valid_credentials():
            return {
                "output_type": OutputType.TEXT,
                "data": "错误：豆包API密钥不能为空，请在model_settings中配置api_key"
            }

        try:
            # 2. 构建消息
            messages = self._build_messages(prompt)

            # 3. 提取调用参数（优先用kwargs，其次用配置）
            call_params = {
                "model": self.model_name,
                "messages": messages,
                "temperature": kwargs.get("temperature", self.temperature),
                "max_tokens": kwargs.get("max_tokens", self.max_tokens)
            }

            # 4. 调用豆包API（严格遵循官方示例）
            response = self.client.chat.completions.create(**call_params)

            # 5. 解析响应（提取文本结果）
            if response.choices and len(response.choices) > 0:
                result_text = response.choices[0].message.content.strip()
                return {
                    "output_type": OutputType.TEXT,
                    "data": result_text,
                    "raw_response": response.model_dump()  # 保留原始响应（可选）
                }
            else:
                return {
                    "output_type": OutputType.TEXT,
                    "data": "错误：豆包API返回空结果"
                }

        except Exception as e:
            # 详细错误信息（便于调试）
            error_msg = f"豆包API调用失败：{str(e)}"
            # 捕获API密钥错误（常见场景）
            if "invalid api key" in str(e).lower():
                error_msg += "（请检查API密钥是否正确）"
            # 捕获模型ID错误
            if "model not found" in str(e).lower():
                error_msg += "（请检查模型ID是否正确，如doubao-seed-1-6-250615）"
            return {
                "output_type": OutputType.TEXT,
                "data":  "run error, fail",
            }

    async def async_generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        """异步调用豆包API（基于线程池实现，避免阻塞）"""
        try:
            # 获取当前事件循环（兼容不同Python版本）
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        # 使用线程池执行同步generate（避免阻塞事件循环）
        with asyncio.ThreadPoolExecutor(max_workers=1) as pool:
            result = await loop.run_in_executor(
                pool,
                lambda: self.generate(prompt, **kwargs)
            )
        return result

class DeepSeekModel(BaseLLM):
    """DeepSeek模型实现（适配其OpenAI兼容API）"""

    def __init__(self, config: ModelConfig):
        super().__init__(config)
        # 从配置读取DeepSeek必要参数（适配其API要求）
        self.api_key = config.api_key  # DeepSeek仅需api_key，无需secret_key
        self.base_url = config.base_url.replace("chat/completions",
                                                "") or "https://api.deepseek.com/v1"  # DeepSeek默认API地址
        self.model_name = config.model_name or "deepseek-chat"  # DeepSeek默认模型ID
        self.temperature = config.temperature
        self.max_tokens = config.max_tokens

        # 初始化DeepSeek客户端（兼容OpenAI SDK格式）
        self.client = OpenAI(
            api_key=self.api_key,
            base_url=self.base_url
        )
        # DeepSeek支持的模态（目前主要为文本，部分模型支持代码）
        self.supported_modalities = [ModalityType.TEXT]

    def _has_valid_credentials(self) -> bool:
        """检查API密钥是否有效"""
        return bool(self.api_key.strip())

    def _build_messages(self, prompt: Union[str, Dict]) -> List[Dict]:
        """构建DeepSeek要求的消息格式（文本优先，暂不支持多模态）"""
        messages = []

        # 处理系统消息（若有）
        system_msg = self.config.extra.get("system_message") if hasattr(self.config, "extra") else None
        if system_msg:
            messages.append({"role": "system", "content": system_msg})

        # 处理用户输入（DeepSeek目前优先支持纯文本，多模态需参考其最新API）
        if isinstance(prompt, dict):
            # 若输入为字典，提取text字段（忽略图像等其他模态，避免报错）
            user_text = prompt.get("text", "").strip()
            if not user_text:
                raise ValueError("DeepSeek模型暂不支持纯图像输入，请提供文本描述")
            messages.append({"role": "user", "content": user_text})
        else:
            # 纯文本输入
            messages.append({"role": "user", "content": prompt.strip()})

        return messages

    def generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        """同步调用DeepSeek API"""
        if not self._has_valid_credentials():
            return {
                "output_type": OutputType.TEXT,
                "data": "错误：DeepSeek API密钥不能为空，请在model_settings中配置api_key"
            }

        try:
            # 构建消息
            messages = self._build_messages(prompt)
            # 组装调用参数（DeepSeek支持OpenAI标准参数）
            call_params = {
                "model": self.model_name,
                "messages": messages,
                "temperature": kwargs.get("temperature", self.temperature),
                "max_tokens": kwargs.get("max_tokens", self.max_tokens)
            }
            # 调用DeepSeek API
            response = self.client.chat.completions.create(**call_params)
            # 解析结果
            if response.choices and len(response.choices) > 0:
                result_text = response.choices[0].message.content.strip()
                return {
                    "output_type": OutputType.TEXT,
                    "data": result_text,
                    "raw_response": response.model_dump()
                }
            else:
                return {"output_type": OutputType.TEXT, "data": "错误：DeepSeek API返回空结果"}

        except Exception as e:
            error_msg = f"DeepSeek API调用失败：{str(e)}"
            if "invalid api key" in str(e).lower():
                error_msg += "（请检查DeepSeek API密钥是否正确）"
            if "model not found" in str(e).lower():
                error_msg += "（请检查DeepSeek模型ID是否正确，如deepseek-chat）"
            return {"output_type": OutputType.TEXT, "data": "run error, fail" }

    async def async_generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        """异步调用DeepSeek API（基于线程池实现）"""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        with asyncio.ThreadPoolExecutor(max_workers=1) as pool:
            result = await loop.run_in_executor(
                pool,
                lambda: self.generate(prompt, **kwargs)
            )
        return result

# 其他模型实现（保持不变）
class OpenAIModel(BaseLLM):
    def __init__(self, config: ModelConfig):
        super().__init__(config)
        self.config = config
        self.supported_modalities = [ModalityType.TEXT]

    def generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        return {"output_type": OutputType.TEXT, "data": "OpenAI模型未配置"}

    async def async_generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        return {"output_type": OutputType.TEXT, "data": "OpenAI模型未配置"}


class OpenAIMultiModalModel(OpenAIModel):
    def __init__(self, config: ModelConfig):
        super().__init__(config)
        self.supported_modalities = [ModalityType.TEXT, ModalityType.IMAGE]


class WenxinModel(BaseLLM):
    def __init__(self, config: ModelConfig):
        super().__init__(config)
        self.config = config
        self.supported_modalities = [ModalityType.TEXT]

    def generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        return {"output_type": OutputType.TEXT, "data": "文心一言模型未配置，请使用豆包模型"}

    async def async_generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        return {"output_type": OutputType.TEXT, "data": "文心一言模型未配置，请使用豆包模型"}

# ====================== 工具实现 ======================
class ArxivSearchTool(BaseTool):
    def execute(self, **kwargs) -> Dict:
        import arxiv
        search = arxiv.Search(
            query=kwargs.get('query', ''),
            max_results=kwargs.get('max_results', 5),
            sort_by=arxiv.SortCriterion.Relevance
        )
        results = []
        for result in search.results():
            results.append({
                "title": result.title,
                "authors": [a.name for a in result.authors],
                "summary": result.summary,
                "published": result.published,
                "pdf_url": result.pdf_url
            })
        return {"output_type": OutputType.JSON, "data": results}

    async def async_execute(self, **kwargs) -> Dict:
        return self.execute(**kwargs)


class MathSolverTool(BaseTool):
    def execute(self, **kwargs) -> Dict:
        from sympy import sympify, solve, Eq, symbols
        from sympy.parsing.sympy_parser import parse_expr

        problem = kwargs.get('problem', '')
        try:
            if "=" in problem:
                lhs, rhs = problem.split("=", 1)
                expr = Eq(parse_expr(lhs.strip()), parse_expr(rhs.strip()))
            else:
                expr = parse_expr(problem.strip())

            variables = expr.free_symbols
            if not variables:
                return {"output_type": OutputType.TEXT, "data": str(expr.evalf())}

            solution = solve(expr, dict=True)
            return {
                "output_type": OutputType.JSON,
                "data": {
                    "variables": [str(v) for v in variables],
                    "solutions": [str(s) for s in solution]
                }
            }
        except Exception as e:
            return {"output_type": OutputType.TEXT, "data": f"Error: {str(e)}"}

    async def async_execute(self, **kwargs) -> Dict:
        return self.execute(**kwargs)


class ImageProcessingTool(BaseMultiModalTool):
    def execute(self, **kwargs) -> Dict:
        import io
        import base64

        operation = kwargs.get("operation", "analyze")
        image_data = kwargs.get("image_data")

        if operation == "analyze":
            return {
                "output_type": OutputType.JSON,
                "data": self._analyze_image(image_data)
            }
        elif operation == "edit":
            return {
                "output_type": OutputType.IMAGE,
                "data": self._edit_image(image_data, kwargs)
            }
        elif operation == "generate":
            return {
                "output_type": OutputType.IMAGE,
                "data": self._generate_image(kwargs)
            }
        else:
            return {
                "output_type": OutputType.TEXT,
                "data": f"Unsupported operation: {operation}"
            }

    def _analyze_image(self, image_data: str) -> Dict:
        """分析图像内容"""
        try:
            image = Image.open(io.BytesIO(base64.b64decode(image_data)))
            return {
                "size": f"{image.width}x{image.height}",
                "format": image.format,
                "mode": image.mode,
                "analysis": "This is a placeholder for image analysis results"
            }
        except Exception as e:
            return {"error": str(e)}

    def _edit_image(self, image_data: str, params: Dict) -> str:
        """编辑图像"""
        try:
            image = Image.open(io.BytesIO(base64.b64decode(image_data)))

            # 简单编辑示例：调整大小
            if "width" in params and "height" in params:
                image = image.resize((int(params["width"]), int(params["height"])))

            # 转换为JPEG格式返回
            buffered = io.BytesIO()
            image.save(buffered, format="JPEG")
            return base64.b64encode(buffered.getvalue()).decode('utf-8')
        except Exception as e:
            raise ValueError(f"Image editing failed: {str(e)}")

    def _generate_image(self, params: Dict) -> str:
        """生成图像"""
        try:
            # 简单示例：生成纯色图像
            from PIL import ImageDraw
            width = int(params.get("width", 512))
            height = int(params.get("height", 512))
            color = params.get("color", "blue")

            image = Image.new("RGB", (width, height), color)
            draw = ImageDraw.Draw(image)

            # 添加简单文本
            if "text" in params:
                draw.text((10, 10), params["text"], fill="white")

            buffered = io.BytesIO()
            image.save(buffered, format="JPEG")
            return base64.b64encode(buffered.getvalue()).decode('utf-8')
        except Exception as e:
            raise ValueError(f"Image generation failed: {str(e)}")

    async def async_execute(self, **kwargs) -> Dict:
        return self.execute(**kwargs)


class AudioProcessingTool(BaseMultiModalTool):
    def execute(self, **kwargs) -> Dict:
        operation = kwargs.get("operation", "transcribe")

        if operation == "transcribe":
            return {
                "output_type": OutputType.TEXT,
                "data": self._transcribe_audio(kwargs.get("audio_data"))
            }
        elif operation == "generate":
            return {
                "output_type": OutputType.AUDIO,
                "data": self._generate_audio(
                    kwargs.get("text", ""),
                    kwargs.get("voice", "alloy")
                )
            }
        else:
            return {
                "output_type": OutputType.TEXT,
                "data": f"Unsupported operation: {operation}"
            }

    def _transcribe_audio(self, audio_data: str) -> str:
        """语音转文字"""
        try:
            # 实际场景需替换为真实语音识别API
            return "这是语音转文字的结果（实际应用中需调用真实API）"
        except Exception as e:
            return f"语音转文字失败: {str(e)}"

    def _generate_audio(self, text: str, voice: str = "alloy") -> str:
        """文字转语音"""
        try:
            # 实际场景需替换为真实语音合成API
            return "base64_encoded_audio_data_placeholder"
        except Exception as e:
            raise ValueError(f"语音生成失败: {str(e)}")

    async def async_execute(self, **kwargs) -> Dict:
        return self.execute(**kwargs)


import logging


# ====================== 记忆实现 ======================
class SimpleMemory(BaseMemory):
    def summarize(self) -> str:
        if not self.memory:
            return "No conversation history"

        return "\n".join([
            f"Previous conversation ({len(self.memory)} messages):",
            *[f"- {msg}" for msg in self.memory]
        ])


# ====================== 工厂类 ======================
class ModelFactory:
    @staticmethod
    def create_model(config: ModelConfig) -> BaseLLM:
        """创建模型实例 - 增加Ollama支持"""
        model_type = config.model_type.lower()
        if model_type == 'ollama':
            return OllamaModel(config)
        elif model_type == 'doubao':
            return DoubaoModel(config)
        elif model_type == 'deepseek':
            return DeepSeekModel(config)
        elif model_type == 'openai':
            return OpenAIModel(config)
        elif model_type == 'openai_multimodal':
            return OpenAIMultiModalModel(config)
        elif model_type == 'wenxin':
            return WenxinModel(config)
        elif model_type in ['chatglm', 'tongyi', 'local']:
            return OpenAIModel(config)  # 占位实现
        else:
            raise ValueError(f"不支持的模型类型: {config.model_type}")


class ToolFactory:
    @staticmethod
    def create_tool(config: ToolConfig) -> BaseTool:
        if config.is_custom:
            return CustomTool(config)
        elif config.name == 'arxiv_search':
            return ArxivSearchTool(config)
        elif config.name == 'math_solver':
            return MathSolverTool(config)
        elif config.name == 'image_processor':
            return ImageProcessingTool(config)
        elif config.name == 'audio_processor':
            return AudioProcessingTool(config)
        elif config.name in ['shell_exec', 'code_generator']:
            raise NotImplementedError(f"Tool {config.name} not implemented yet")
        else:
            raise ValueError(f"Unsupported tool: {config.name}")


# ====================== 核心Agent类 ======================
class LLMAgent:
    def __init__(self, config: Union[Dict, AgentConfig]):
        """初始化Agent（修复配置解析逻辑）"""
        if isinstance(config, dict):
            self.config = AgentConfig(**config)  # 字典转AgentConfig实例
        else:
            self.config = config
        self.name = self.config.agent_name

        # 初始化核心组件
        self.model = self._init_model()
        self.tools = self._init_tools()
        self.memory = SimpleMemory(self.config.memory_config)
        self.vector_store = self._init_vector_store()

        # 执行统计
        self.execution_count = 0
        self.last_execution_time = None

        # 多模态支持
        self.supported_modalities = self._init_modalities()
        self.output_handlers = self._init_output_handlers()

    def _init_model(self) -> Union[BaseLLM, List[BaseLLM]]:
        """初始化模型（修复单模型配置传递）"""
        logging.info("model_mode :%s", self.config.model_mode)
        if self.config.model_mode == 'single':
            # 单模型：从model_settings构建ModelConfig
            model_settings = self.config.model_settings
            logging.info("model_type :%s",self.config.model_type)
            if self.config.model_type == 'ollama':
                model_settings = self.config.model_settings
                model_config = ModelConfig(
                    model_type =self.config.model_type,
                    model_name =model_settings.get("model_name", "llama3.2"),
                    api_key=None,
                    base_url=model_settings.get("base_url", "http://localhost:11434"),
                    #ollama_host=model_settings.get("base_url", "http://localhost:11434").replace("/api/generate", ""),
                    temperature=model_settings.get("temperature", self.config.temperature),
                    max_tokens =model_settings.get("max_tokens", self.config.max_tokens)
                )
                return ModelFactory.create_model(model_config)
            else:

                model_config = ModelConfig(
                    model_type  =self.config.model_type,
                    api_key     = model_settings.get("api_key"),
                    model_name  = model_settings.get("model_name"),
                    temperature = model_settings.get("temperature", self.config.temperature),
                    max_tokens  = model_settings.get("max_tokens", self.config.max_tokens),
                    base_url=self.config.model_settings.get("base_url").replace("chat/completions", "")
                )
                return ModelFactory.create_model(model_config)
        else:
            # 多模型：直接使用multi_model_configs
            if not self.config.multi_model_configs:
                raise ValueError("multi_model_configs is required for model_mode='multiple'")
            return [ModelFactory.create_model(cfg) for cfg in self.config.multi_model_configs]

    def _init_modalities(self) -> List[ModalityType]:
        """初始化支持的模态类型（合并模型和工具的模态）"""
        modalities = {ModalityType.TEXT}  # 基础支持文本

        # 合并模型支持的模态
        if isinstance(self.model, list):
            for m in self.model:
                modalities.update(m.supported_modalities)
        else:
            modalities.update(self.model.supported_modalities)

        # 合并工具支持的模态
        for tool in self.tools.values():
            if isinstance(tool, BaseMultiModalTool):
                modalities.update(tool.supported_modalities)

        return list(modalities)

    def _init_tools(self) -> Dict[str, BaseTool]:
        """初始化工具（修复预定义工具配置）"""
        tools = {}

        # 1. 处理预定义工具
        predefined_tool_configs = {
            'arxiv_search': ToolConfig(
                name='arxiv_search',
                description='Search academic papers on Arxiv',
                parameters=[
                    ToolParameter(name='query', type='string', required=True, description='搜索关键词'),
                    ToolParameter(name='max_results', type='integer', required=False, default=5,
                                  description='返回结果数量')
                ]
            ),
            'math_solver': ToolConfig(
                name='math_solver',
                description='Solve math problems symbolically',
                parameters=[
                    ToolParameter(name='problem', type='string', required=True,
                                  description='数学问题表达式，如"x^2 + 3x + 2 = 0"')
                ]
            ),
            'image_processor': ToolConfig(
                name='image_processor',
                description='Process and analyze images (supports analyze/edit/generate)',
                parameters=[
                    ToolParameter(name='operation', type='string', required=True, enum=['analyze', 'edit', 'generate'],
                                  description='操作类型'),
                    ToolParameter(name='image_data', type='string', required=False, format='base64',
                                  description='Base64编码的图像数据（analyze/edit时需提供）'),
                    ToolParameter(name='width', type='integer', required=False,
                                  description='图像宽度（edit/generate时需提供）'),
                    ToolParameter(name='height', type='integer', required=False,
                                  description='图像高度（edit/generate时需提供）'),
                    ToolParameter(name='text', type='string', required=False,
                                  description='添加到图像的文本（generate时可选）')
                ],
                output_types=[OutputType.IMAGE, OutputType.JSON]
            ),
            'audio_processor': ToolConfig(
                name='audio_processor',
                description='Process and generate audio (supports transcribe/generate)',
                parameters=[
                    ToolParameter(name='operation', type='string', required=True, enum=['transcribe', 'generate'],
                                  description='操作类型'),
                    ToolParameter(name='audio_data', type='string', required=False, format='base64',
                                  description='Base64编码的音频数据（transcribe时需提供）'),
                    ToolParameter(name='text', type='string', required=False,
                                  description='待合成的文本（generate时需提供）'),
                    ToolParameter(name='voice', type='string', required=False, enum=['alloy', 'echo', 'fable'],
                                  description='语音类型（generate时可选）')
                ],
                output_types=[OutputType.AUDIO, OutputType.TEXT]
            )
        }

        # 2. 加载启用的工具
        for tool_name in self.config.enabled_tools:
            if tool_name.startswith('custom_'):
                # 处理自定义工具（去掉前缀）
                custom_tool_name = tool_name[7:]
                tool_cfg = next((t for t in self.config.custom_tools if t.name == custom_tool_name), None)
                if not tool_cfg:
                    raise ValueError(f"Custom tool {custom_tool_name} not found in custom_tools")
                tools[custom_tool_name] = ToolFactory.create_tool(tool_cfg)
            else:
                # 处理预定义工具
                if tool_name not in predefined_tool_configs:
                    raise ValueError(f"Predefined tool {tool_name} not found")
                tools[tool_name] = ToolFactory.create_tool(predefined_tool_configs[tool_name])

        return tools

    def _init_output_handlers(self) -> Dict[OutputType, Callable]:
        """初始化输出处理器（保持不变）"""
        return {
            OutputType.TEXT: self._handle_text_output,
            OutputType.JSON: self._handle_json_output,
            OutputType.IMAGE: self._handle_image_output,
            OutputType.AUDIO: self._handle_audio_output,
            OutputType.MARKDOWN: self._handle_markdown_output,
            OutputType.HTML: self._handle_html_output
        }

    def _init_vector_store(self):
        """初始化向量存储（占位，可后续扩展）"""
        if self.config.vector_store_config.type == VectorStoreType.FAISS:
            try:
                import faiss
                return faiss.IndexFlatL2(768)  # 示例：768维向量存储
            except ImportError:
                raise ImportError("faiss not installed. Install with 'pip install faiss-cpu'")
        else:
            raise NotImplementedError(f"Vector store type {self.config.vector_store_config.type} not implemented")

    def _process_prompt(self, prompt: str, variables: Dict[str, Any] = None) -> str:
        """处理提示词模板（支持多类型prompt）"""
        variables = variables or {}
        variables.setdefault('agentName', self.name)
        variables.setdefault('currentTime', datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        variables.setdefault('history', self.memory.summarize())

        prompt_cfg = self.config.prompt_config
        if prompt_cfg.prompt_type == PromptType.SIMPLE:
            return (prompt_cfg.template or "{input}").format(**variables, input=prompt)
        elif prompt_cfg.prompt_type == PromptType.CHAT:
            system_msg = prompt_cfg.system_message or "你是一个智能助手，请友好回答用户问题。"
            human_msg = (prompt_cfg.human_template or "{input}").format(**variables, input=prompt)
            return f"System: {system_msg}\nHuman: {human_msg}"
        elif prompt_cfg.prompt_type == PromptType.FEW_SHOT:
            if not prompt_cfg.examples:
                raise ValueError("examples required for FEW_SHOT prompt type")
            examples_str = "\n".join(
                (prompt_cfg.example_template or "Input: {input}\nOutput: {output}").format(**e.dict())
                for e in prompt_cfg.examples
            )
            return f"{prompt_cfg.prefix or ''}\n{examples_str}\n{prompt_cfg.suffix or ''}\nInput: {prompt}\nOutput:"
        else:
            return prompt

    def _preprocess_input(self, input_data: Union[str, Dict]) -> Union[str, Dict]:
        """预处理输入（支持多模态）"""
        if isinstance(input_data, dict):
            # 多模态输入：处理文本，保留图像/音频原始数据
            processed = {}
            # 处理文本部分（应用prompt模板）
            if "text" in input_data:
                processed["text"] = self._process_prompt(input_data["text"])
            # 保留图像数据（Base64或URL）
            if "image" in input_data and ModalityType.IMAGE in self.supported_modalities:
                processed["image"] = input_data["image"]
            # 处理音频数据（转文字后合并到文本）
            if "audio" in input_data and ModalityType.AUDIO in self.supported_modalities:
                if "audio_processor" in self.tools:
                    audio_result = self.tools["audio_processor"].execute(
                        operation="transcribe",
                        audio_data=input_data["audio"]
                    )
                    processed["text"] = f"{processed.get('text', '')}\n（音频转文字结果：{audio_result['data']}）"
            return processed
        else:
            # 纯文本输入：直接处理模板
            return self._process_prompt(input_data)

    def _postprocess_output(self, raw_result: Dict, output_type: OutputType) -> Dict:
        """后处理输出（统一格式）"""
        if not isinstance(raw_result, dict) or "output_type" not in raw_result:
            return self.output_handlers[output_type](raw_result)
        # 若原始结果已包含类型，直接返回
        return raw_result

    # 输出处理器实现
    def _handle_text_output(self, data: Any) -> Dict:
        return {"output_type": OutputType.TEXT, "data": str(data)}

    def _handle_json_output(self, data: Any) -> Dict:
        import json
        try:
            if isinstance(data, dict):
                return {"output_type": OutputType.JSON, "data": data}
            return {"output_type": OutputType.JSON, "data": json.loads(str(data))}
        except:
            return self._handle_text_output(data)

    def _handle_image_output(self, data: Any) -> Dict:
        if isinstance(data, dict) and "data" in data and data["output_type"] == OutputType.IMAGE:
            return data
        return {"output_type": OutputType.TEXT, "data": "无法生成图像输出（格式错误）"}

    def _handle_audio_output(self, data: Any) -> Dict:
        if isinstance(data, dict) and "data" in data and data["output_type"] == OutputType.AUDIO:
            return data
        return {"output_type": OutputType.TEXT, "data": "无法生成音频输出（格式错误）"}

    def _handle_markdown_output(self, data: Any) -> Dict:
        return {"output_type": OutputType.MARKDOWN, "data": str(data)}

    def _handle_html_output(self, data: Any) -> Dict:
        return {"output_type": OutputType.HTML, "data": str(data)}

    def generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        """生成响应（单模型/多模型逻辑）"""
        output_type = kwargs.get("output_type", self.config.default_output_type)
        processed_input = self._preprocess_input(prompt)

        # 单模型调用
        if not isinstance(self.model, list):
            raw_result = self.model.generate(processed_input, **kwargs)
            logging.info(f"{self.model.model_name} finish gen")
            logging.info("raw_result:%s", str(raw_result) ) #[:20]
        # 多模型调用
        else:
            if self.config.model_weight_strategy == ModelWeightStrategy.WEIGHTED:
                # 加权选择模型
                weights = [getattr(cfg, "weight", 1.0) for cfg in self.config.multi_model_configs]
                total = sum(weights)
                normalized = [w / total for w in weights]
                selected_idx = np.random.choice(len(self.model), p=normalized)
                raw_result = self.model[selected_idx].generate(processed_input, **kwargs)
            else:
                # 简单取第一个模型结果
                raw_result = self.model[0].generate(processed_input, **kwargs)

        # 后处理并更新记忆
        result = self._postprocess_output(raw_result, output_type)
        self._update_memory(prompt, result)
        return result

    async def async_generate(self, prompt: Union[str, Dict], **kwargs) -> Dict:
        """异步生成响应"""
        output_type = kwargs.get("output_type", self.config.default_output_type)
        processed_input = self._preprocess_input(prompt)

        if not isinstance(self.model, list):
            raw_result = await self.model.async_generate(processed_input, **kwargs)
        else:
            if self.config.model_weight_strategy == ModelWeightStrategy.WEIGHTED:
                weights = [getattr(cfg, "weight", 1.0) for cfg in self.config.multi_model_configs]
                total = sum(weights)
                normalized = [w / total for w in weights]
                selected_idx = np.random.choice(len(self.model), p=normalized)
                raw_result = await self.model[selected_idx].async_generate(processed_input, **kwargs)
            else:
                raw_result = await self.model[0].async_generate(processed_input, **kwargs)

        result = self._postprocess_output(raw_result, output_type)
        self._update_memory(prompt, result)
        return result

    def _update_memory(self, prompt: Union[str, Dict], result: Dict):
        """更新对话记忆"""
        user_msg = str(prompt)[:100] + "..." if len(str(prompt)) > 100 else str(prompt)
        bot_msg = str(result["data"])[:100] + "..." if len(str(result["data"])) > 100 else str(result["data"])
        self.memory.add(f"User: {user_msg}")
        self.memory.add(f"Assistant: {bot_msg}")
        self.execution_count += 1
        self.last_execution_time = datetime.now()

    def execute_tool(self, tool_name: str, params: Dict) -> Dict:
        """执行工具（带安全检查）"""
        if tool_name not in self.tools:
            return {"output_type": OutputType.TEXT, "data": f"工具 {tool_name} 不存在"}

        # 安全检查
        if self.config.action_safety_check != 'off':
            try:
                self._check_tool_safety(tool_name, params)
            except PermissionError as e:
                return {"output_type": OutputType.TEXT, "data": f"工具调用被拒绝：{str(e)}"}

        # 执行工具
        try:
            return self.tools[tool_name].execute(**params)
        except Exception as e:
            return {"output_type": OutputType.TEXT, "data": f"工具执行失败：{str(e)}"}

    async def async_execute_tool(self, tool_name: str, params: Dict) -> Dict:
        """异步执行工具"""
        if tool_name not in self.tools:
            return {"output_type": OutputType.TEXT, "data": f"工具 {tool_name} 不存在"}

        if self.config.action_safety_check != 'off':
            try:
                self._check_tool_safety(tool_name, params)
            except PermissionError as e:
                return {"output_type": OutputType.TEXT, "data": f"工具调用被拒绝：{str(e)}"}

        try:
            return await self.tools[tool_name].async_execute(**params)
        except Exception as e:
            return {"output_type": OutputType.TEXT, "data": f"工具执行失败：{str(e)}"}

    def _check_tool_safety(self, tool_name: str, params: Dict):
        """工具调用安全检查"""
        forbidden = {
            'shell_exec': '禁止执行系统命令',
            'file_write': '禁止文件写入操作',
            'network_request': '禁止网络请求'
        }
        if tool_name in forbidden:
            raise PermissionError(forbidden[tool_name])


# ====================== 多Agent协同 ======================
class MultiAgentSystem:
    def __init__(self, agents: Dict[str, LLMAgent], config: Dict):
        self.agents = agents
        self.config = config
        self.conversation_history = []

    def execute(self, prompt: Union[str, Dict], initiator: str = None) -> Dict[str, Any]:
        """执行多Agent协作"""
        if not initiator:
            initiator = next(iter(self.agents.keys()))

        strategy = self.config.get('exec_strategy', ExecutionStrategy.SINGLE)
        if strategy == ExecutionStrategy.SINGLE:
            return self._execute_single(prompt, initiator)
        elif strategy == ExecutionStrategy.PARALLEL:
            return self._execute_parallel(prompt)
        elif strategy == ExecutionStrategy.SEQUENTIAL:
            return self._execute_sequential(prompt)
        elif strategy == ExecutionStrategy.VOTE:
            return self._execute_vote(prompt)
        else:
            raise ValueError(f"不支持的执行策略：{strategy}")

    def _execute_single(self, prompt: Union[str, Dict], agent_name: str) -> Dict:
        agent = self.agents.get(agent_name)
        if not agent:
            return {"error": f"Agent {agent_name} 不存在"}
        result = agent.generate(prompt)
        return {
            "strategy": "single",
            "results": {agent_name: result},
            "final_result": result
        }

    def _execute_parallel(self, prompt: Union[str, Dict]) -> Dict:
        """并行执行多个Agent"""
        results = {}
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = {
                executor.submit(agent.generate, prompt): name
                for name, agent in self.agents.items()
            }
            for future in concurrent.futures.as_completed(futures):
                name = futures[future]
                try:
                    results[name] = future.result()
                except Exception as e:
                    results[name] = {"output_type": OutputType.TEXT, "data": f"Agent {name} 执行失败：{str(e)}"}

        # 选择第一个有效结果
        final_result = next(
            (r for r in results.values() if "error" not in r and "失败" not in r.get("data", "")),
            {"output_type": OutputType.TEXT, "data": "所有Agent执行失败"}
        )
        return {
            "strategy": "parallel",
            "results": results,
            "final_result": final_result
        }

    def _execute_sequential(self, prompt: Union[str, Dict]) -> Dict:
        """顺序执行多个Agent"""
        current_prompt = prompt
        results = {}
        execution_order = self.config.get('execution_order', '').split(',')

        for agent_name in [n.strip() for n in execution_order if n.strip()]:
            agent = self.agents.get(agent_name)
            if not agent:
                results[agent_name] = {"output_type": OutputType.TEXT, "data": f"Agent {agent_name} 不存在"}
                continue

            result = agent.generate(current_prompt)
            results[agent_name] = result
            current_prompt = result["data"]  # 前一个结果作为下一个输入

        return {
            "strategy": "sequential",
            "results": results,
            "final_result": {"output_type": OutputType.TEXT, "data": current_prompt}
        }

    def _execute_vote(self, prompt: Union[str, Dict]) -> Dict:
        """投票机制（选择最常见的结果）"""
        results = {name: agent.generate(prompt) for name, agent in self.agents.items()}

        # 统计结果出现次数
        from collections import defaultdict
        vote_counts = defaultdict(int)
        for res in results.values():
            vote_counts[res["data"]] += 1

        # 选择得票最高的结果
        final_result_data = max(vote_counts.items(), key=lambda x: x[1])[0]
        final_result = next(r for r in results.values() if r["data"] == final_result_data)

        return {
            "strategy": "vote",
            "results": results,
            "final_result": final_result,
            "vote_stats": dict(vote_counts)
        }


# ====================== 自定义工具实现 ======================
class CustomTool(BaseTool):
    def __init__(self, config: ToolConfig):
        super().__init__(config)
        self._compile_custom_code()

    def _compile_custom_code(self):
        """动态编译自定义工具代码"""
        if not self.config.code:
            raise ValueError("自定义工具必须提供code字段")

        try:
            # 创建临时模块执行代码
            module = type(sys)('custom_tool')
            exec(self.config.code, module.__dict__)

            # 查找工具函数
            if not hasattr(module, 'tool_function'):
                raise ValueError("自定义工具代码必须包含tool_function函数")

            self._tool_func = module.tool_function
        except Exception as e:
            raise ValueError(f"自定义工具编译失败：{str(e)}")

    def execute(self, **kwargs) -> Dict:
        try:
            result = self._tool_func(**kwargs)
            if isinstance(result, dict) and "output_type" in result:
                return result
            return {"output_type": OutputType.TEXT, "data": result}
        except Exception as e:
            return {"output_type": OutputType.TEXT, "data": f"自定义工具执行失败：{str(e)}"}

    async def async_execute(self, **kwargs) -> Dict:
        loop = asyncio.get_event_loop()
        with ThreadPoolExecutor() as pool:
            result = await loop.run_in_executor(pool, lambda: self._tool_func(**kwargs))

        if isinstance(result, dict) and "output_type" in result:
            return result
        return {"output_type": OutputType.TEXT, "data": result}


if __name__ == "__main__":
    ollama_config = {
        "agent_name": "Ollama助手",
        "model_mode": "single",
        "model_type": "ollama",
        "model_settings": {
            "model_name": "qwen3:4b",  # 或"qwen2.5:7b", "gemma2:2b"等
            "base_url": "http://127.0.0.1:11434/api/generate",  # Ollama默认地址  generate
            "temperature": 0.7,
            "max_tokens": 512
        },
        "prompt_config": {
            "prompt_type": "chat",
            "system_message": "你是一个本地运行的AI助手，请用中文简洁回答。",
            "human_template": "{input}"
        },
        "enabled_tools": ["math_solver"],
        "supports_multimodal": False,
        "memory_config": {"enabled": True, "size": 5}
    }

    try:
        ollama_agent = LLMAgent(ollama_config)
        response     = ollama_agent.generate("你好，请简要快速介绍下你自己")
        logging.info(f"{response}")
        logging.info(f"Ollama回答: {response['data'][:100]}...")
    except Exception as e:
        import traceback
        print(f"Ollama测试失败（需要先安装并运行Ollama）: {e}  {traceback.format_exc()} ")

    print("\n" + "=" * 50 + "\n")


    exit()
    # 豆包模型配置（请替换为您的实际API密钥和模型ID）
    doubao_config = {
        "agent_name": "豆包多模态助手",
        "model_mode": "single",
        "model_type": "doubao",  # 指定使用豆包模型
        "model_settings": {
            "api_key": "9441e427-cc8d-4f74-b679-aa44ff1ab53a",  # 替换为您的API密钥
            "model_name": "doubao-seed-1-6-250615",  # 替换为您的模型ID
            "temperature": 0.7,
            "max_tokens": 2048
        },
        "prompt_config": {
            "prompt_type": "chat",
            "system_message": "你是一个智能多模态助手，擅长处理文本和图像问题，请用中文友好回答。",
            "human_template": "{input}"
        },
        "enabled_tools": ["arxiv_search", "image_processor"],  # 启用的工具
        "supports_multimodal": True,
        "memory_config": {
            "enabled": True,
            "size": 5  # 保留最近5条对话
        }
    }

    # 创建Agent
    agent = LLMAgent(doubao_config)
    print("=== 豆包多模态助手初始化完成 ===")

    # 1. 文本交互示例
    print("\n=== 文本问答示例 ===")
    text_response = agent.generate("请简要介绍量子计算的应用场景")
    print("回答:", text_response["data"])
    exit()
    # ====================== DeepSeek模型配置 ======================
    deepseek_config = {
        "agent_name": "DeepSeek文本助手",  # Agent名称
        "model_mode": "single",  # 单模型模式
        "model_type": "deepseek",  # 关键：指定使用DeepSeek模型
        "model_settings": {
            "api_key": "sk-923104df62de492cbdb6a8992dc68890",  # 替换为你的DeepSeek API密钥
            "model_name": "deepseek-chat",  # DeepSeek常用模型ID（可选：deepseek-coder-v2）
            "base_url": "https://api.deepseek.com",  # "https://api.deepseek.com/v1",  # DeepSeek官方API地址（默认可省略）
            "temperature": 0.7,  # 随机性（0-1，越小越确定）
            "max_tokens": 2048  # 最大输出长度
        },
        "prompt_config": {
            "prompt_type": "chat",
            "system_message": "你是一个专业的文本助手，擅长解答技术问题，请用简洁的中文回答。",
            "human_template": "{input}"
        },
        "enabled_tools": ["arxiv_search", "math_solver"],  # 启用的工具（工具调用不依赖模型）
        "supports_multimodal": False,  # DeepSeek目前优先支持文本，关闭多模态
        "memory_config": {
            "enabled": True,
            "size": 5  # 保留最近5条对话历史
        }
    }

    deepseek_config = {'actionRateLimit': 60, 'actionSafetyCheck': 'medium', 'actionTimeout': 30,
                       'agentName': 'SmartAgent', 'algoKeys': None, 'columns': [], 'csvDelimiter': ',',
                       'deriveInputMode': 'single', 'earlyStopping': True,
                       'enabledTools': ['arxiv_search', 'shell_exec', 'math_solver', 'code_generator'],
                       'execStrategy': 'single', 'frequencyPenalty': 0, 'maxIterations': 5, 'maxTokens': 1024,
                       'memoryEnabled': True, 'model_settings': {'api_key': 'sk-923104df62de492cbdb6a8992dc68890',
                                                                 "model_name": "deepseek-chat",
                                                                 "base_url": "https://api.deepseek.com",
                                                                 "temperature": 0.7, "max_tokens": 2048},
                       'model_mode': 'single', 'model_type': 'deepseek',
                       'promptConfig': {'human_template': '{question}',
                                        'system_message': '你是一个专业助手，需要根据用户问题提供准确、简洁的回答。可使用工具获取必要信息，回答需基于事实。'},
                       'splitColumn': '', 'splitMethod': 'percentage', 'splitPercentage': 80, 'splitValue': '',
                       'supportsMultimodal': False, 'temperature': 0.7, 'topP': 0.7, 'trainNode': None,
                       'vectorStore': 'faiss', 'verbose': False}
    deepseek_config = {'agent_name': 'SmartAgent', 'exec_strategy': 'single', 'prompt_config': {
        'system_message': '你是一个专业助手，需要根据用户问题提供准确、简洁的回答。可使用工具获取必要信息，回答需基于事实。',
        'human_template': '{input}'}, 'model_mode': 'single', 'model_type': 'deepseek', 'supportsMultimodal': False,
                       'temperature': 0.7, 'maxTokens': 1024, 'topP': 0.7, 'frequencyPenalty': 0, 'enabledTools': [],
                       'actionTimeout': 30, 'actionRateLimit': 60, 'actionSafetyCheck': 'medium',
                       'model_settings': {'api_key': 'sk-923104df62de492cbdb6a8992dc68890',
                                          'model_name': 'deepseek-chat', 'base_url': 'https://api.deepseek.com'},
                       'AlgoMode': '', 'AlgoType': '', 'algoKeys': None, 'splitMethod': 'percentage',
                       'splitPercentage': 80, 'splitColumn': '', 'splitValue': '', 'trainNode': None,
                       'csvDelimiter': ',', 'deriveFunc': '', 'deriveInputMode': 'single', 'columns': []}
    # 1. 创建DeepSeek Agent
    agent = LLMAgent(deepseek_config)
    print("=== DeepSeek文本助手初始化完成 ===")

    # 2. 文本问答示例（调用DeepSeek模型）
    print("\n=== 文本问答示例（DeepSeek）===")
    text_prompt = "请解释什么是大语言模型（LLM），并说明其核心原理"
    text_response = agent.generate(text_prompt)
    print("DeepSeek回答:", text_response["data"])

    # 3. 工具调用示例（Arxiv论文搜索，不依赖DeepSeek）
    print("\n=== 工具调用示例（Arxiv搜索）===")
    arxiv_params = {
        "query": "large language model principle",  # 搜索关键词
        "max_results": 2  # 返回2篇论文
    }
    arxiv_result = agent.execute_tool("arxiv_search", arxiv_params)
    if arxiv_result["output_type"] == OutputType.JSON:
        for i, paper in enumerate(arxiv_result["data"], 1):
            print(f"\n{i}. 论文标题：{paper['title']}")
            print(f"   作者：{', '.join(paper['authors'][:2])}等")
            print(f"   PDF链接：{paper['pdf_url']}")
    else:
        print("工具调用失败:", arxiv_result["data"])

    # 4. 数学解题示例（工具调用，不依赖模型）
    print("\n=== 工具调用示例（数学解题）===")
    math_params = {"problem": "解方程 x^2 - 5x + 6 = 0"}
    math_result = agent.execute_tool("math_solver", math_params)
    print("数学解题结果:", math_result["data"])

    exit()
    # 豆包模型配置（请替换为您的实际API密钥和模型ID）
    doubao_config = {
        "agent_name": "豆包多模态助手",
        "model_mode": "single",
        "model_type": "doubao",  # 指定使用豆包模型
        "model_settings": {
            "api_key": "9441e427-cc8d-4f74-b679-aa44ff1ab53a",  # 替换为您的API密钥
            "model_name": "doubao-seed-1-6-250615",  # 替换为您的模型ID
            "temperature": 0.7,
            "max_tokens": 2048
        },
        "prompt_config": {
            "prompt_type": "chat",
            "system_message": "你是一个智能多模态助手，擅长处理文本和图像问题，请用中文友好回答。",
            "human_template": "{input}"
        },
        "enabled_tools": ["arxiv_search", "image_processor"],  # 启用的工具
        "supports_multimodal": True,
        "memory_config": {
            "enabled": True,
            "size": 5  # 保留最近5条对话
        }
    }

    # 创建Agent
    agent = LLMAgent(doubao_config)
    print("=== 豆包多模态助手初始化完成 ===")

    # 1. 文本交互示例
    print("\n=== 文本问答示例 ===")
    text_response = agent.generate("请简要介绍量子计算的应用场景")
    print("回答:", text_response["data"])

    # 2. 图像理解示例（使用网络图片URL）
    print("\n=== 图像理解示例 ===")
    image_input = {
        "text": "请描述这张图片的内容",
        "image": "https://ark-project.tos-cn-beijing.ivolces.com/images/view.jpeg"  # 示例图片URL
    }
    try:
        image_response = agent.generate(image_input)
        print("图像描述:", image_response["data"])
    except Exception as e:
        print("图像处理失败:", str(e))

    # 3. Arxiv论文搜索示例
    print("\n=== Arxiv论文搜索示例 ===")
    try:
        arxiv_result = agent.execute_tool(
            "arxiv_search",
            {"query": "quantum computing applications", "max_results": 2}
        )
        if arxiv_result["output_type"] == OutputType.JSON:
            for i, paper in enumerate(arxiv_result["data"], 1):
                print(f"{i}. {paper['title']}")
                print(f"   作者: {', '.join(paper['authors'][:2])}等")
                print(f"   链接: {paper['pdf_url']}\n")
        else:
            print("搜索结果:", arxiv_result["data"])
    except Exception as e:
        print("论文搜索失败:", str(e))


# if __name__ == "__main__":
#     # 豆包模型配置（请替换为您的实际API密钥和模型ID）
#     doubao_config = {
#         "agent_name": "豆包多模态助手",
#         "model_mode": "single",
#         "model_type": "doubao",  # 指定使用豆包模型
#         "model_settings": {
#             "api_key": "9441e427-cc8d-4f74-b679-aa44ff1ab53a",  # 替换为您的API密钥
#             "model_name": "doubao-seed-1-6-250615",  # 替换为您的模型ID
#             "temperature": 0.7,
#             "max_tokens": 2048
#         },
#         "prompt_config": {
#             "prompt_type": "chat",
#             "system_message": "你是一个智能多模态助手，擅长处理文本和图像问题，请用中文友好回答。",
#             "human_template": "{input}"
#         },
#         "enabled_tools": ["arxiv_search", "image_processor"],  # 启用的工具
#         "supports_multimodal": True,
#         "memory_config": {
#             "enabled": True,
#             "size": 5  # 保留最近5条对话
#         }
#     }
#
#     # 创建Agent
#     agent = LLMAgent(doubao_config)
#     print("=== 豆包多模态助手初始化完成 ===")
#
#     # 1. 文本交互示例
#     print("\n=== 文本问答示例 ===")
#     text_response = agent.generate("请简要介绍量子计算的应用场景")
#     print("回答:", text_response["data"])
#     exit()
#     # ====================== DeepSeek模型配置 ======================
#     deepseek_config = {
#         "agent_name": "DeepSeek文本助手",  # Agent名称
#         "model_mode": "single",  # 单模型模式
#         "model_type": "deepseek",  # 关键：指定使用DeepSeek模型
#         "model_settings": {
#             "api_key": "sk-923104df62de492cbdb6a8992dc68890",  # 替换为你的DeepSeek API密钥
#             "model_name": "deepseek-chat",  # DeepSeek常用模型ID（可选：deepseek-coder-v2）
#             "base_url": "https://api.deepseek.com",#"https://api.deepseek.com/v1",  # DeepSeek官方API地址（默认可省略）
#             "temperature": 0.7,  # 随机性（0-1，越小越确定）
#             "max_tokens": 2048  # 最大输出长度
#         },
#         "prompt_config": {
#             "prompt_type": "chat",
#             "system_message": "你是一个专业的文本助手，擅长解答技术问题，请用简洁的中文回答。",
#             "human_template": "{input}"
#         },
#         "enabled_tools": ["arxiv_search", "math_solver"],  # 启用的工具（工具调用不依赖模型）
#         "supports_multimodal": False,  # DeepSeek目前优先支持文本，关闭多模态
#         "memory_config": {
#             "enabled": True,
#             "size": 5  # 保留最近5条对话历史
#         }
#     }
#
#     deepseek_config={'actionRateLimit': 60, 'actionSafetyCheck': 'medium', 'actionTimeout': 30, 'agentName': 'SmartAgent', 'algoKeys': None, 'columns': [], 'csvDelimiter': ',', 'deriveInputMode': 'single', 'earlyStopping': True, 'enabledTools': ['arxiv_search', 'shell_exec', 'math_solver', 'code_generator'], 'execStrategy': 'single', 'frequencyPenalty': 0, 'maxIterations': 5, 'maxTokens': 1024, 'memoryEnabled': True, 'model_settings': {'api_key': 'sk-923104df62de492cbdb6a8992dc68890',"model_name": "deepseek-chat","base_url": "https://api.deepseek.com","temperature": 0.7,"max_tokens": 2048},
#                      'model_mode': 'single', 'model_type': 'deepseek', 'promptConfig': {'human_template': '{question}', 'system_message': '你是一个专业助手，需要根据用户问题提供准确、简洁的回答。可使用工具获取必要信息，回答需基于事实。'}, 'splitColumn': '', 'splitMethod': 'percentage', 'splitPercentage': 80, 'splitValue': '', 'supportsMultimodal': False, 'temperature': 0.7, 'topP': 0.7, 'trainNode': None, 'vectorStore': 'faiss', 'verbose': False}
#     deepseek_config = {'agent_name': 'SmartAgent', 'exec_strategy': 'single', 'prompt_config': {'system_message': '你是一个专业助手，需要根据用户问题提供准确、简洁的回答。可使用工具获取必要信息，回答需基于事实。', 'human_template': '{input}'}, 'model_mode': 'single', 'model_type': 'deepseek', 'supportsMultimodal': False, 'temperature': 0.7, 'maxTokens': 1024, 'topP': 0.7, 'frequencyPenalty': 0, 'enabledTools': [], 'actionTimeout': 30, 'actionRateLimit': 60, 'actionSafetyCheck': 'medium', 'model_settings': {'api_key': 'sk-923104df62de492cbdb6a8992dc68890', 'model_name': 'deepseek-chat', 'base_url': 'https://api.deepseek.com'}, 'AlgoMode': '', 'AlgoType': '', 'algoKeys': None, 'splitMethod': 'percentage', 'splitPercentage': 80, 'splitColumn': '', 'splitValue': '', 'trainNode': None, 'csvDelimiter': ',', 'deriveFunc': '', 'deriveInputMode': 'single', 'columns': []}
#     # 1. 创建DeepSeek Agent
#     agent = LLMAgent(deepseek_config)
#     print("=== DeepSeek文本助手初始化完成 ===")
#
#     # 2. 文本问答示例（调用DeepSeek模型）
#     print("\n=== 文本问答示例（DeepSeek）===")
#     text_prompt = "请解释什么是大语言模型（LLM），并说明其核心原理"
#     text_response = agent.generate(text_prompt)
#     print("DeepSeek回答:", text_response["data"])
#
#     # 3. 工具调用示例（Arxiv论文搜索，不依赖DeepSeek）
#     print("\n=== 工具调用示例（Arxiv搜索）===")
#     arxiv_params = {
#         "query": "large language model principle",  # 搜索关键词
#         "max_results": 2  # 返回2篇论文
#     }
#     arxiv_result = agent.execute_tool("arxiv_search", arxiv_params)
#     if arxiv_result["output_type"] == OutputType.JSON:
#         for i, paper in enumerate(arxiv_result["data"], 1):
#             print(f"\n{i}. 论文标题：{paper['title']}")
#             print(f"   作者：{', '.join(paper['authors'][:2])}等")
#             print(f"   PDF链接：{paper['pdf_url']}")
#     else:
#         print("工具调用失败:", arxiv_result["data"])
#
#     # 4. 数学解题示例（工具调用，不依赖模型）
#     print("\n=== 工具调用示例（数学解题）===")
#     math_params = {"problem": "解方程 x^2 - 5x + 6 = 0"}
#     math_result = agent.execute_tool("math_solver", math_params)
#     print("数学解题结果:", math_result["data"])
#
#     exit()
#     # 豆包模型配置（请替换为您的实际API密钥和模型ID）
#     doubao_config = {
#         "agent_name": "豆包多模态助手",
#         "model_mode": "single",
#         "model_type": "doubao",  # 指定使用豆包模型
#         "model_settings": {
#             "api_key": "9441e427-cc8d-4f74-b679-aa44ff1ab53a",  # 替换为您的API密钥
#             "model_name": "doubao-seed-1-6-250615",  # 替换为您的模型ID
#             "temperature": 0.7,
#             "max_tokens": 2048
#         },
#         "prompt_config": {
#             "prompt_type": "chat",
#             "system_message": "你是一个智能多模态助手，擅长处理文本和图像问题，请用中文友好回答。",
#             "human_template": "{input}"
#         },
#         "enabled_tools": ["arxiv_search", "image_processor"],  # 启用的工具
#         "supports_multimodal": True,
#         "memory_config": {
#             "enabled": True,
#             "size": 5  # 保留最近5条对话
#         }
#     }
#
#     # 创建Agent
#     agent = LLMAgent(doubao_config)
#     print("=== 豆包多模态助手初始化完成 ===")
#
#     # 1. 文本交互示例
#     print("\n=== 文本问答示例 ===")
#     text_response = agent.generate("请简要介绍量子计算的应用场景")
#     print("回答:", text_response["data"])
#
#     # 2. 图像理解示例（使用网络图片URL）
#     print("\n=== 图像理解示例 ===")
#     image_input = {
#         "text": "请描述这张图片的内容",
#         "image": "https://ark-project.tos-cn-beijing.ivolces.com/images/view.jpeg"  # 示例图片URL
#     }
#     try:
#         image_response = agent.generate(image_input)
#         print("图像描述:", image_response["data"])
#     except Exception as e:
#         print("图像处理失败:", str(e))
#
#     # 3. Arxiv论文搜索示例
#     print("\n=== Arxiv论文搜索示例 ===")
#     try:
#         arxiv_result = agent.execute_tool(
#             "arxiv_search",
#             {"query": "quantum computing applications", "max_results": 2}
#         )
#         if arxiv_result["output_type"] == OutputType.JSON:
#             for i, paper in enumerate(arxiv_result["data"], 1):
#                 print(f"{i}. {paper['title']}")
#                 print(f"   作者: {', '.join(paper['authors'][:2])}等")
#                 print(f"   链接: {paper['pdf_url']}\n")
#         else:
#             print("搜索结果:", arxiv_result["data"])
#     except Exception as e:
#         print("论文搜索失败:", str(e))
