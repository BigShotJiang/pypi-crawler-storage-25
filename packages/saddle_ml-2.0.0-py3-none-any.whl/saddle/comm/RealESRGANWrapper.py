import os
import cv2
import numpy as np
import torch
from pathlib import Path


class RealESRGANWrapper:
    """Real-ESRGAN封装类，兼容现有接口"""
    def __init__(self):
        self.upsamplers = {}  # 缓存不同模型的upsampler
        self.model_dir = "weights"  # 模型存放目录

    def _get_model_path(self, model_name: str) -> str:
        """获取模型文件路径"""
        model_map = {
            'RealESRGAN_x4plus': 'RealESRGAN_x4plus.pth',
            'RealESRNet_x4plus': 'RealESRNet_x4plus.pth',
            'RealESRGAN_x4plus_anime_6B': 'RealESRGAN_x4plus_anime_6B.pth'
        }

        filename = model_map.get(model_name, 'RealESRGAN_x4plus.pth')
        model_path = os.path.join(self.model_dir, filename)

        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Real-ESRGAN模型文件不存在: {model_path}")

        return model_path

    def _init_upsampler(self, model_name: str, scale: int = 4) -> bool:
        """初始化Real-ESRGAN upsampler"""
        try:
            # 延迟导入，避免依赖问题
            from realesrgan import RealESRGANer

            if model_name in self.upsamplers:
                return True

            model_path = self._get_model_path(model_name)

            # 根据模型名称确定网络架构
            if 'anime' in model_name:
                from basicsr.archs.rrdbnet_arch import RRDBNet
                model = RRDBNet(num_in_ch=3, num_out_ch=3, num_feat=64,
                                num_block=6, num_grow_ch=32, scale=scale)
            else:
                model = None  # RealESRGANer会自动处理

            # 创建upsampler
            self.upsamplers[model_name] = RealESRGANer(
                scale=scale,
                model_path=model_path,
                model=model,
                tile=0,  # 在enhance时动态设置
                tile_pad=10,
                pre_pad=0,
                device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            )

            return True

        except ImportError as e:
            logging.error(f"Real-ESRGAN未安装: {e}")
            return False
        except Exception as e:
            logging.error(f"初始化Real-ESRGAN失败: {e}")
            return False

    def enhance_single_image(self, image: np.ndarray, model_name: str = 'RealESRGAN_x4plus',
                             scale: int = 4, tile: int = 0, tile_pad: int = 10,
                             pre_pad: int = 0) -> np.ndarray:
        """增强单张图像"""
        try:
            # 确保模型已初始化
            if not self._init_upsampler(model_name, scale):
                logging.warning("Real-ESRGAN初始化失败，返回原图")
                return image

            upsampler = self.upsamplers[model_name]

            # 设置参数
            upsampler.tile = tile
            upsampler.tile_pad = tile_pad
            upsampler.pre_pad = pre_pad

            # 执行增强
            output, _ = upsampler.enhance(
                image,
                outscale=scale,
                # alpha_upsampler='realesrgan'  # 如果需要alpha通道
            )

            return output

        except Exception as e:
            logging.error(f"Real-ESRGAN增强失败: {e}")
            return image

    def enhance_batch_images(self, images: list, **kwargs) -> list:
        """批量增强图像列表"""
        enhanced_images = []
        for img in images:
            enhanced = self.enhance_single_image(img, **kwargs)
            enhanced_images.append(enhanced)
        return enhanced_images