import os
import argparse
import numpy as np
import matplotlib.pyplot as plt
import shap
import matplotlib.font_manager as fm
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import accuracy_score, r2_score
from sklearn.preprocessing import LabelEncoder
from base64 import b64encode
from datetime import datetime
from io import BytesIO
import warnings
import traceback
import logging

warnings.filterwarnings('ignore')

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
def setup_fonts():
    """Setup fonts for matplotlib"""
    try:
        plt.rcParams["font.family"] = ["DejaVu Sans", "Arial", "sans-serif"]
        plt.rcParams['axes.unicode_minus'] = False
    except:
        pass


class DataPreprocessor:
    @staticmethod
    def preprocess_data(df, target_column=None):
        """Preprocess data: handle categorical variables and missing values"""
        df_processed = df.copy()

        if target_column is None:
            target_column = df.columns[-1]

        y = df_processed[target_column]
        X = df_processed.drop(columns=[target_column])

        label_encoders = {}
        categorical_columns = []

        for col in X.columns:
            if X[col].dtype == 'object' or (
                    X[col].nunique() < 20 and X[col].dtype != 'float64' and X[col].dtype != 'int64'):
                try:
                    le = LabelEncoder()
                    X[col] = le.fit_transform(X[col].astype(str))
                    label_encoders[col] = le
                    categorical_columns.append(col)
                except Exception:
                    try:
                        X[col] = X[col].astype('category').cat.codes
                    except:
                        X = X.drop(columns=[col])

        numeric_columns = X.select_dtypes(include=[np.number]).columns
        if len(numeric_columns) > 0:
            X[numeric_columns] = X[numeric_columns].fillna(X[numeric_columns].mean())

        for col in X.columns:
            if X[col].dtype == 'object':
                X[col] = pd.to_numeric(X[col], errors='coerce').fillna(0)

        if y.dtype == 'object':
            le_target = LabelEncoder()
            y = le_target.fit_transform(y.astype(str))
            target_names = [f"Class{cls}" for cls in le_target.classes_]
        else:
            le_target = None
            if len(np.unique(y)) <= 10:
                target_names = [f"Class{int(c)}" for c in np.unique(y)]
            else:
                target_names = ["Target"]

        feature_names = X.columns.tolist()

        return {
            "X": X.values.astype(np.float64),
            "y": y,
            "feature_names": feature_names,
            "target_names": target_names,
            "target_column": target_column,
            "label_encoders": label_encoders,
            "le_target": le_target,
            "categorical_columns": categorical_columns
        }


class DataLoader:
    @staticmethod
    def load_data(file_path, target_column=None):
        """Load data from CSV file"""
        try:
            df = pd.read_csv(file_path)
            processed_data = DataPreprocessor.preprocess_data(df, target_column)
            return processed_data

        except Exception as e:
            logging.info(f"Data loading failed: {str(e)}")
            traceback.print_exc()
            raise


class ModelTrainer:
    @staticmethod
    def train_model(X_train, y_train, task="classification", **model_params):
        if task == "classification":
            model = RandomForestClassifier(**model_params)
        elif task == "regression":
            model = RandomForestRegressor(**model_params)
        else:
            raise ValueError(f"Unsupported task type: {task}")

        model.fit(X_train, y_train)
        return model

    @staticmethod
    def evaluate_model(model, X_test, y_test, task="classification"):
        y_pred = model.predict(X_test)
        if task == "classification":
            accuracy = accuracy_score(y_test, y_pred)
            return {"accuracy": accuracy}
        elif task == "regression":
            r2 = r2_score(y_test, y_pred)
            return {"r2": r2}


def _create_fallback_guide():
        """生成备用的简单指南"""
        fig, ax = plt.subplots(figsize=(12, 8))
        ax.text(0.1, 0.9, "SHAP值解读指南", fontsize=16, fontweight='bold')
        ax.text(0.1, 0.8, "• SHAP值显示特征对预测的贡献", fontsize=12)
        ax.text(0.1, 0.75, "• 基准值 = 所有样本的平均预测值", fontsize=12)
        ax.text(0.1, 0.7, "• 最终预测 = 基准值 + 所有SHAP值之和", fontsize=12)
        ax.text(0.1, 0.65, "• 正值：让预测比基准增加", fontsize=12)
        ax.text(0.1, 0.6, "• 负值：让预测比基准减少", fontsize=12)
        ax.axis('off')
        return fig
class SHAPInterpretationGuideChinese:
    """SHAP可视化解读指南 - 中文小白版"""

    @staticmethod
    def generate_shap_interpretation_guide():
        """生成SHAP解读指南图表 - 中文版"""
        try:
            fig, axes = plt.subplots(2, 1, figsize=(16, 14))
            plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False

            # 第一图：SHAP基础概念
            ax1 = axes[0]
            ax1.set_title(' SHAP值完全解读指南', fontsize=16, fontweight='bold', pad=25, color='darkblue')

            text_content = [
                " 什么是SHAP值？",
                "• SHAP值显示每个特征对预测的边际贡献",
                "• 基准值：所有样本预测值的平均值（参考基准）",
                "• 正值：让预测结果比基准值增加  负值：让预测结果比基准值减少",
                "• 绝对值越大：特征对预测的影响力越大",
                "",
                " 核心公式：",
                "最终预测值 = 基准值 + Σ(所有特征的SHAP值)",
                "基准值 = E[f(X)] = 模型在所有样本上的平均预测",
                "",
                " 关键理解：",
                "• 每个样本的每个特征都有一个SHAP值  同样的特征值在不同样本中可能有不同的SHAP值",
                "• SHAP值已经包含了特征之间的交互效应 不是特征值越大SHAP值就一定越大"
                "",
                "房价预测例子：",
                "基准值（平均房价）= 100万元",
                "• 面积SHAP值 +50万：面积让房价比平均高了50万",
                "• 位置SHAP值 -20万：位置让房价比平均低了20万",
                "• 最终预测 = 100 + 50 - 20 = 130万元",
                "",
                " 简单理解：就像考试：个人总分 = 班级平均分 + 各科加分减分 SHAP值就是各科相对于平均分的'贡献分'"
            ]

            for i, line in enumerate(text_content):
                y_pos = 0.98 - i * 0.04
                if "📊" in line or "🎯" in line or "💡" in line:
                    ax1.text(0.05, y_pos, line, fontsize=13, fontweight='bold',
                             color='darkblue', transform=ax1.transAxes)
                elif line.startswith("•"):
                    ax1.text(0.08, y_pos, line, fontsize=12, transform=ax1.transAxes)
                elif "基准值" in line or "最终预测" in line:
                    ax1.text(0.05, y_pos, line, fontsize=12, color='darkred',
                             fontweight='bold', transform=ax1.transAxes)
                else:
                    ax1.text(0.05, y_pos, line, fontsize=12, transform=ax1.transAxes)

            ax1.axis('off')

            # 第二图：图表解读指南
            ax2 = axes[1]
            ax2.set_title(' 如何看懂各种SHAP图表', fontsize=16, fontweight='bold', pad=25, color='darkblue')

            plot_guides = [
                "特征总览图（Summary Plot - 点图版本）：",
                "• Y轴：特征按重要性排序（最重要的在上面）,每个特征那一行：所有样本的散点; X轴：SHAP值大小（正值在右，负值在左）;每个点：一个样本中该特征的SHAP值",
                "• 颜色：该样本中这个特征的实际值大小",
                "• 看点：特征的整体影响模式？特征值与SHAP值的关系？示例：红色点在右侧 = 特征值大的样本且让预测增加",

                "",
                "特征总览图（Feature Importance - 条形图版本）：",
                "• Y轴：特征按重要性排序  X轴：平均|SHAP值|（取绝对值后的平均值）",
                "• 每个条形：该特征的平均影响力大小.看点：哪些特征总体上最重要？",


                "⚡ 单样本影响力图（Force Plot）：",
                "• 显示单个样本的预测分解",
                "• 基准线：显示基准值（平均预测）",
                "• 红色箭头：让预测比基准值增加的特征",
                "• 蓝色箭头：让预测比基准值减少的特征",
                "• 箭头长度：影响力大小（SHAP绝对值）",
                "• 最终值：基准值 + 所有箭头之和",
                "• 看点：这个样本为什么是这个预测结果？",
                "",
                "瀑布图（Waterfall Plot）：",
                "• 从左到右：显示预测从基准值到最终值的过程",
                "• 每个柱子：一个特征的SHAP贡献",
                "• 向上柱子：正值，让预测增加 向下柱子：负值，让预测减少 ,看点：预测值是如何一步步从基准值变化来的？",
                "",
                "Summary Plot点图的深入解读：",
                "• 点分散：说明特征的影响因样本而异（受其他特征影响）  点集中：说明特征的影响比较一致",
                "• 红色在右+蓝色在左：特征值与预测正相关  红色在左+蓝色在右：特征值与预测负相关",
                "• 红蓝混杂：关系复杂，依赖其他特征",
                " 特征依赖图（Feature Dependence Plot）- 深度解读：",
                " 核心意义：揭示特征影响模式 + 发现特征交互效应",
                "",
                " 如何解读：",
                "• X轴：主要特征的值（如'面积'）  Y轴：该特征的SHAP值（对预测的贡献）",
                "• 颜色：第二个特征的值（如'位置'，显示交互效应）",
                "",
                " 看趋势线：",
                "↗ 向上倾斜：特征值越大，正面影响越强（正相关） ↘ 向下倾斜：特征值越大，负面影响越强（负相关）",
                "➡ 水平线：特征对预测影响不大   ⤴ 曲线：非线性关系（如边际效应递减）",
                "",
                " 看颜色模式：",
                " 红色点在高SHAP区：当第二个特征值大时，主要特征影响更强",
                " 蓝色点在低SHAP区：当第二个特征值小时，主要特征影响更弱",
                " 红蓝混杂：复杂的多特征交互",
                "",
                "业务洞察：",
                "• 发现特征的最佳取值范围",
                "• 识别风险组合（如低收入+高负债）  找到机会点（如特定区位的投资价值）  验证业务假设是否成立",
                "",
                " 房价预测示例：",
                "• 看'面积'依赖图：发现180㎡以上边际收益递减   看'位置'颜色：发现同样面积，市中心溢价明显",
                "• 决策：投资150-180㎡的市中心房产最划算"
            ]

            for i, line in enumerate(plot_guides):
                y_pos = 0.98 - i * 0.03
                if any(icon in line for icon in ["📊", "⚡", "🌊", "💡"]):
                    ax2.text(0.05, y_pos, line, fontsize=12, fontweight='bold',
                             color='darkblue', transform=ax2.transAxes)
                elif line.startswith("•"):
                    ax2.text(0.08, y_pos, line, fontsize=12, transform=ax2.transAxes)
                elif "看点" in line or "示例" in line:
                    ax2.text(0.08, y_pos, line, fontsize=12, color='darkgreen',
                             fontweight='bold', transform=ax2.transAxes)
                else:
                    ax2.text(0.05, y_pos, line, fontsize=12, transform=ax2.transAxes)

            ax2.axis('off')
            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"中文SHAP解读指南生成失败: {str(e)}")
            return _create_fallback_guide()



    @staticmethod
    def _create_fallback_guide():
        """创建备用指南"""
        try:
            fig, ax = plt.subplots(figsize=(12, 8))
            ax.set_title('SHAP解读指南', fontsize=16, fontweight='bold')

            content = [
                "SHAP值解读指南",
                "",
                "什么是SHAP值？",
                "- 显示每个特征对预测的贡献",
                "- 正值：增加预测结果",
                "- 负值：减少预测结果",
                "- 值越大：特征越重要",
                "",
                "如何看图？",
                "1. 特征总览图：看哪些特征最重要",
                "2. 影响力图：看单个预测的原因",
                "3. 决策路径图：看预测形成过程",
                "",
                "重点关注：",
                "• 前3-5个最重要的特征",
                "• 特征影响是否符合业务常识",
                "• 有没有异常的模式"
            ]

            for i, line in enumerate(content):
                y_pos = 0.9 - i * 0.06
                if "指南" in line or "什么是" in line or "如何看图" in line or "重点关注" in line:
                    ax.text(0.1, y_pos, line, fontsize=12, fontweight='bold', transform=ax.transAxes)
                else:
                    ax.text(0.15, y_pos, line, fontsize=10, transform=ax.transAxes)

            ax.axis('off')
            plt.tight_layout()
            return fig
        except:
            return None

    @staticmethod
    def generate_feature_importance_guide():
        """生成特征重要性解读指南 - 中文版"""
        try:
            fig, ax = plt.subplots(figsize=(12, 8))

            # 设置中文字体
            plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False

            ax.set_title('特征重要性解读指南', fontsize=16, fontweight='bold', pad=20, color='darkred')

            content = [
                "🎯 特征重要性的三种类型：",
                "",
                "1. 全局重要性：",
                "   • 所有样本的平均影响",
                "   • 回答：哪些特征总体上最重要？",
                "   • 查看：SHAP条形图、特征总览图",
                "",
                "2. 局部重要性：",
                "   • 对单个预测的影响",
                "   • 回答：为什么这个样本得到这个预测？",
                "   • 查看：影响力图、瀑布图",
                "",
                "3. 交互重要性：",
                "   • 特征之间的相互作用",
                "   • 回答：特征如何共同影响预测？",
                "   • 查看：依赖图",
                "",
                "💡 解读技巧：",
                "• 高重要性：模型主要依赖这些特征做决策",
                "• 要检查：重要特征是否符合业务逻辑？",
                "• 低重要性：可以考虑移除以简化模型",
                "• 异常模式：可能表示数据问题或过拟合",
                "",
                "🚀 行动建议：",
                "• 重点关注前3-5个重要特征",
                "• 验证重要特征的业务合理性",
                "• 考虑移除不重要特征简化模型",
                "• 对异常模式深入分析原因"
            ]

            for i, line in enumerate(content):
                y_pos = 0.98 - i * 0.045
                if "🎯" in line or "💡" in line or "🚀" in line:
                    ax.text(0.05, y_pos, line, fontsize=12, fontweight='bold',
                            color='darkred', transform=ax.transAxes)
                elif line.startswith("1.") or line.startswith("2.") or line.startswith("3."):
                    ax.text(0.05, y_pos, line, fontsize=11, fontweight='bold',
                            color='darkblue', transform=ax.transAxes)
                elif line.startswith("   •"):
                    ax.text(0.08, y_pos, line, fontsize=9, transform=ax.transAxes)
                elif line.startswith("•"):
                    ax.text(0.08, y_pos, line, fontsize=10, transform=ax.transAxes)
                else:
                    ax.text(0.05, y_pos, line, fontsize=10, transform=ax.transAxes)

            ax.axis('off')
            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"中文特征重要性指南生成失败: {str(e)}")
            return None

    @staticmethod
    def generate_model_evaluation_guide():
        """生成模型评估指南 - 中文版"""
        try:
            fig, ax = plt.subplots(figsize=(12, 6))

            plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False

            ax.set_title('模型质量评估指南', fontsize=16, fontweight='bold', pad=20, color='darkgreen')

            content = [
                "✅ 好模型的迹象：",
                "• 特征重要性清晰，前几个特征主导",
                "• SHAP值与业务常识一致",
                "• 依赖图显示合理的模式",
                "• 混淆矩阵对角线明显（分类问题）",
                "• 预测值与实际值接近（回归问题）",
                "",
                "❌ 需要改进的迹象：",
                "• 特征重要性分散，没有明显重要特征",
                "• SHAP值与业务逻辑矛盾",
                "• 依赖图显示异常模式",
                "• 准确率/R²分数很低",
                "• 残差图显示系统偏差",
                "",
                "🔍 检查清单：",
                "1. 最重要的特征是否符合业务预期？",
                "2. 模型预测是否有合理的解释？",
                "3. 性能指标是否达到业务要求？",
                "4. 有没有发现数据质量问题？",
                "5. 模型是否过于复杂或简单？"
            ]

            for i, line in enumerate(content):
                y_pos = 0.95 - i * 0.06
                if "✅" in line or "❌" in line or "🔍" in line:
                    ax.text(0.05, y_pos, line, fontsize=12, fontweight='bold',
                            transform=ax.transAxes)
                elif line.startswith("•"):
                    ax.text(0.08, y_pos, line, fontsize=10, transform=ax.transAxes)
                elif line.startswith("1.") or line.startswith("2.") or line.startswith("3."):
                    ax.text(0.08, y_pos, line, fontsize=10, transform=ax.transAxes)
                else:
                    ax.text(0.05, y_pos, line, fontsize=10, transform=ax.transAxes)

            # 给好迹象标绿色，问题标红色
            ax.text(0.05, 0.95, "✅", color='green', fontsize=12, fontweight='bold', transform=ax.transAxes)
            ax.text(0.05, 0.65, "❌", color='red', fontsize=12, fontweight='bold', transform=ax.transAxes)
            ax.text(0.05, 0.35, "🔍", color='blue', fontsize=12, fontweight='bold', transform=ax.transAxes)

            ax.axis('off')
            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"模型评估指南生成失败: {str(e)}")
            return None
class SHAPInterpretationGuide:
    """SHAP可视化解读指南 - 修复乱码版本"""

    @staticmethod
    def generate_shap_interpretation_guide():
        """生成SHAP解读指南图表 - 简化版本避免乱码"""
        try:
            fig, axes = plt.subplots(2, 1, figsize=(14, 12))

            # 第一图：SHAP基础概念
            ax1 = axes[0]
            ax1.set_title('SHAP Value Interpretation Guide', fontsize=16, fontweight='bold', pad=20)

            # 使用简单的文本布局
            text_content = [
                "SHAP VALUES EXPLANATION",
                "",
                "What are SHAP values?",
                "- Show how each feature contributes to predictions",
                "- Positive values: Increase prediction",
                "- Negative values: Decrease prediction",
                "- Larger absolute values: More important features",
                "",
                "Base Value: Average prediction across all samples",
                "Final Prediction = Base Value + Sum of all SHAP values",
                "",
                "Key Insights:",
                "1. Identify most important features",
                "2. Understand prediction drivers",
                "3. Validate model behavior",
                "4. Detect potential issues"
            ]

            for i, line in enumerate(text_content):
                y_pos = 0.9 - i * 0.06
                if line.startswith("SHAP") or line.startswith("What") or line.startswith("Key"):
                    ax1.text(0.05, y_pos, line, fontsize=12, fontweight='bold', transform=ax1.transAxes)
                elif line.startswith("-") or line.startswith("Base") or line.startswith("Final"):
                    ax1.text(0.08, y_pos, line, fontsize=10, transform=ax1.transAxes)
                else:
                    ax1.text(0.05, y_pos, line, fontsize=10, transform=ax1.transAxes)

            ax1.axis('off')

            # 第二图：图表解读指南
            ax2 = axes[1]
            ax2.set_title('How to Read SHAP Plots', fontsize=16, fontweight='bold', pad=20)

            plot_guides = [
                "SUMMARY PLOT:",
                "- Features sorted by importance (top to bottom)",
                "- X-axis: SHAP value impact",
                "- Color: Feature value (red=high, blue=low)",
                "- Look for: Most important features & patterns",
                "",
                "FORCE PLOT:",
                "- Shows prediction breakdown for one sample",
                "- Red: Features increasing prediction",
                "- Blue: Features decreasing prediction",
                "- Length: Strength of influence",
                "",
                "DECISION PLOT:",
                "- Shows prediction path from base to final",
                "- Each line: One sample's prediction journey",
                "- Steep slopes: Important decision points"
            ]

            for i, line in enumerate(plot_guides):
                y_pos = 0.9 - i * 0.05
                if "PLOT:" in line:
                    ax2.text(0.05, y_pos, line, fontsize=11, fontweight='bold',
                             color='darkblue', transform=ax2.transAxes)
                else:
                    ax2.text(0.08, y_pos, line, fontsize=9, transform=ax2.transAxes)

            ax2.axis('off')
            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"SHAP interpretation guide failed: {str(e)}")
            # 返回一个简单的备用图
            try:
                fig, ax = plt.subplots(figsize=(10, 6))
                ax.text(0.5, 0.5,
                        'SHAP Interpretation Guide\n\nPlease refer to the detailed descriptions\nin the report for each plot type.',
                        ha='center', va='center', fontsize=14, transform=ax.transAxes)
                ax.set_title('SHAP Analysis Guide', fontsize=16)
                ax.axis('off')
                return fig
            except:
                return None

    @staticmethod
    def generate_feature_importance_guide():
        """生成特征重要性解读指南 - 简化版本"""
        try:
            fig, ax = plt.subplots(figsize=(12, 8))

            ax.set_title('Feature Importance Interpretation', fontsize=16, fontweight='bold', pad=20)

            content = [
                "FEATURE IMPORTANCE TYPES:",
                "",
                "1. GLOBAL IMPORTANCE:",
                "   - Average impact across all samples",
                "   - Shows which features matter most overall",
                "   - View: SHAP bar plot, summary plot",
                "",
                "2. LOCAL IMPORTANCE:",
                "   - Impact on individual predictions",
                "   - Explains why specific predictions were made",
                "   - View: Force plot, waterfall plot",
                "",
                "3. INTERACTION IMPORTANCE:",
                "   - How features work together",
                "   - Shows feature dependencies",
                "   - View: Dependence plot",
                "",
                "INTERPRETATION TIPS:",
                "- High importance: Model relies heavily on these",
                "- Check if important features make business sense",
                "- Low importance: May be removed to simplify model",
                "- Unexpected patterns: May indicate data issues"
            ]

            for i, line in enumerate(content):
                y_pos = 0.95 - i * 0.045
                if "IMPORTANCE" in line or "TIPS" in line:
                    ax.text(0.05, y_pos, line, fontsize=11, fontweight='bold',
                            color='darkred', transform=ax.transAxes)
                else:
                    ax.text(0.08, y_pos, line, fontsize=9, transform=ax.transAxes)

            ax.axis('off')
            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"Feature importance guide failed: {str(e)}")
            return None

class SHAPAnalyzer:
    def __init__(self, model, X_train, task="classification", feature_names=None):
        self.model = model
        self.task = task
        self.feature_names = feature_names or [f"Feature_{i}" for i in range(X_train.shape[1])]
        self.plots = {}

        try:
            self.explainer = shap.TreeExplainer(model)
        except Exception as e:
            logging.info(f"SHAP TreeExplainer failed: {str(e)}")
            try:
                self.explainer = shap.Explainer(model, X_train)
            except Exception:
                traceback.print_exc()
                raise
        self.interpretation_guide = SHAPInterpretationGuideChinese()

    def _fig_to_base64(self, fig):
        """Convert figure to base64"""
        try:
            buf = BytesIO()
            fig.savefig(buf, format='png', dpi=100, bbox_inches='tight')
            buf.seek(0)
            img_base64 = b64encode(buf.read()).decode('utf-8')
            buf.close()
            plt.close(fig)
            return f"data:image/png;base64,{img_base64}"
        except Exception:
            return ""

    def _create_custom_force_plot(self, base_value, shap_values, feature_names, sample_idx, predicted_class=None):
        """Create a custom force plot using matplotlib when SHAP force plot fails"""
        try:
            plt.figure(figsize=(14, 8))

            # 安全处理基础值
            try:
                if isinstance(base_value, (list, np.ndarray)):
                    base_val = float(base_value[0]) if len(base_value) > 0 else 0.0
                else:
                    base_val = float(base_value)
            except (TypeError, ValueError, IndexError):
                base_val = 0.0

            # 确保shap_values是numpy数组
            shap_array = np.array(shap_values)

            # 创建特征影响力数据
            features = []
            values = []
            impacts = []

            for i, (feature, value) in enumerate(zip(feature_names, shap_array)):
                if abs(value) > 0.001:  # 只显示有显著影响的特征
                    features.append(feature)
                    values.append(value)
                    impacts.append(abs(value))

            # 按影响力排序
            if impacts:
                indices = np.argsort(impacts)[::-1]
                sorted_features = [features[i] for i in indices]
                sorted_values = [values[i] for i in indices]

                # 创建颜色数组
                colors = ['#FF6B6B' if x > 0 else '#4ECDC4' for x in sorted_values]

                # 绘制水平条形图
                y_pos = np.arange(len(sorted_features))
                bars = plt.barh(y_pos, sorted_values, color=colors, alpha=0.8, height=0.7)

                # 设置标签和标题
                plt.yticks(y_pos, sorted_features, fontsize=10)
                plt.xlabel('SHAP Value Impact', fontsize=12, fontweight='bold')
                plt.ylabel('Features', fontsize=12, fontweight='bold')

                # 计算最终预测值
                final_prediction = base_val + sum(sorted_values)

                # 设置标题
                title = f'Force Plot - sample {sample_idx}\n'
                title += f'basevalue: {base_val:.4f} | final value: {final_prediction:.4f}'
                if predicted_class is not None:
                    title += f' | 预测类别: {predicted_class}'
                plt.title(title, fontsize=14, fontweight='bold', pad=20)

                # 添加数值标签
                for i, (bar, value) in enumerate(zip(bars, sorted_values)):
                    width = bar.get_width()
                    if abs(width) > 0:
                        ha = 'left' if width > 0 else 'right'
                        x_pos = width + (0.01 if width > 0 else -0.01)
                        color = 'darkred' if width > 0 else 'darkblue'
                        plt.text(x_pos, bar.get_y() + bar.get_height() / 2,
                                 f'{value:+.4f}', ha=ha, va='center',
                                 fontweight='bold', color=color, fontsize=9)

                # 添加基准线
                plt.axvline(x=0, color='black', linestyle='-', alpha=0.5, linewidth=1)

                # 添加网格
                plt.grid(axis='x', alpha=0.3, linestyle='--')
                plt.gca().set_axisbelow(True)

                # 添加图例
                from matplotlib.patches import Patch
                legend_elements = [
                    Patch(facecolor='#FF6B6B', label='正向影响 (增加预测值)'),
                    Patch(facecolor='#4ECDC4', label='负向影响 (减少预测值)')
                ]
                plt.legend(handles=legend_elements, loc='lower right', frameon=True)

                plt.tight_layout()
                return True

            else:
                # 如果没有显著特征，显示提示信息
                plt.text(0.5, 0.5, 'No significant features found\nfor this sample',
                         ha='center', va='center', transform=plt.gca().transAxes, fontsize=12)
                plt.title(f'Force Plot - Sample {sample_idx}', fontsize=14)
                plt.axis('off')
                return True

        except Exception as e:
            logging.info(f"Custom force plot failed: {str(e)}")
            traceback.print_exc()
            return False

    def generate_basic_plots(self, X_test, y_test, feature_names, target_names, sample_idx=0):
        """Generate comprehensive SHAP plots"""
        plots = {}

        try:
            # interpretation_fig = self.interpretation_guide.generate_shap_interpretation_guide()
            # if interpretation_fig :
            #     plots["shap_guide"] = {
            #         "title": "SHAP Interpretation Guide (Read First)",
            #         "content": self._fig_to_base64(interpretation_fig),
            #         "description": self._get_guide_description(),
            #         "type": "image"
            #     }
            #
            # # 2. 生成特征重要性指南
            # feature_guide_fig = self.interpretation_guide.generate_feature_importance_guide()
            # if feature_guide_fig:
            #     plots["feature_guide"] = {
            #         "title": "Feature Importance Guide",
            #         "content": self._fig_to_base64(feature_guide_fig),
            #         "description": "Understanding different types of feature importance and how to interpret them",
            #         "type": "image"
            #     }
            shap_values = self.explainer.shap_values(X_test)
            base_value = self.explainer.expected_value

            logging.info(f"SHAP values type: {type(shap_values)}")
            logging.info(f"SHAP values shape: {np.array(shap_values).shape if hasattr(shap_values, '__len__') else 'scalar'}")
            logging.info(f"Base value type: {type(base_value)}")
            logging.info(f"Base value: {base_value}")

            # 1. Summary plot
            try:
                plt.figure(figsize=(12, 8))
                if isinstance(shap_values, list) or (isinstance(shap_values, np.ndarray) and shap_values.ndim == 3):
                    shap.summary_plot(shap_values, X_test, feature_names=feature_names, show=False)
                else:
                    shap.summary_plot(shap_values, X_test, feature_names=feature_names, show=False)
                plt.title("SHAP Summary Plot", fontsize=16, pad=20)
                plt.tight_layout()

                plots["summary"] = {
                    "title": "SHAP Summary Plot",
                    "content": self._fig_to_base64(plt.gcf()),
                    "description": "SHAP (SHapley Additive exPlanations) 基于博弈论中的Shapley值原理，为每个特征分配对预测结果的贡献值。Shapley值考虑了特征所有可能的组合顺序，公平地计算每个特征的边际贡献，确保解释的一致性和准确性。"
                   "SHAP 值显示每个特征对预测的边际贡献，基准值：所有样本预测值的平均值（参考基准）・正值：让预测结果比基准值增加 负值：让预测结果比基准值减少・绝对值越大：特征对预测的影响力越大。"
                   "核心公式：最终预测值 = 基准值 + Σ(所有特征的 SHAP 值) ; 基准值 = E[f(X)] = 模型在所有样本上的平均预测。每个样本的每个特征都有独立的SHAP值，且已包含特征间的交互效应。"
                   "房价预测例子：基准值（平均房价）= 100 万元・面积 SHAP 值 +50 万：面积让房价比平均高了 50 万・位置 SHAP 值 -20 万：位置让房价比平均低了 20 万・最终预测 = 100 + 50 - 20 = 130 万元。"
                   "简单理解：就像考试：个人总分 = 班级平均分 + 各科加分减分 SHAP 值就是各科相对于平均分的贡献分。"
                   "特征总览图（Summary Plot - 点图版本）解读：Y轴为按重要性排序的特征，X轴为SHAP值大小，每个点代表一个样本中该特征的SHAP值，颜色表示特征实际值大小。可观察特征的整体影响模式、特征值与SHAP值的关系（红色点在右侧表示特征值大的样本让预测增加）。",

                    "type": "image"
                }
            except Exception as e:
                logging.info(f"Summary plot failed: {str(e)}")

            # 2. Bar plot
            try:
                plt.figure(figsize=(12, 8))
                if isinstance(shap_values, list) or (isinstance(shap_values, np.ndarray) and shap_values.ndim == 3):
                    shap.summary_plot(shap_values, X_test, feature_names=feature_names, plot_type="bar", show=False)
                else:
                    shap.summary_plot(shap_values, X_test, feature_names=feature_names, plot_type="bar", show=False)
                plt.title("SHAP Feature Importance", fontsize=16, pad=20)
                plt.tight_layout()

                plots["bar"] = {
                    "title": "SHAP Feature Importance",
                    "content": self._fig_to_base64(plt.gcf()),
                    "description": "Bar chart showing mean absolute SHAP values for each feature.",
                    "type": "image"
                }
            except Exception as e:
                logging.info(f"Bar plot failed: {str(e)}")

            # 3. Decision plot
            try:
                plt.figure(figsize=(12, 8))
                sample_idx = min(sample_idx, len(X_test) - 1)

                if isinstance(shap_values, list):
                    # Multi-class: use the predicted class
                    y_pred_sample = self.model.predict(X_test[sample_idx:sample_idx + 1])[0]
                    if y_pred_sample < len(shap_values):
                        shap_val_sample = shap_values[y_pred_sample][sample_idx]
                        base_val = base_value[y_pred_sample] if isinstance(base_value,
                                                                           (list, np.ndarray)) else base_value
                    else:
                        shap_val_sample = shap_values[0][sample_idx]
                        base_val = base_value[0] if isinstance(base_value, (list, np.ndarray)) else base_value
                elif isinstance(shap_values, np.ndarray) and shap_values.ndim == 3:
                    y_pred_sample = self.model.predict(X_test[sample_idx:sample_idx + 1])[0]
                    if shap_values.shape[2] > y_pred_sample:
                        shap_val_sample = shap_values[sample_idx, :, y_pred_sample]
                        base_val = base_value[y_pred_sample] if isinstance(base_value,
                                                                           (list, np.ndarray)) else base_value
                    else:
                        shap_val_sample = shap_values[sample_idx, :, 0]
                        base_val = base_value[0] if isinstance(base_value, (list, np.ndarray)) else base_value
                else:
                    shap_val_sample = shap_values[sample_idx]
                    base_val = base_value

                shap.decision_plot(base_val, shap_val_sample, feature_names=feature_names, show=False)
                plt.title(f"Decision Plot - Sample {sample_idx}", fontsize=16, pad=20)
                plt.tight_layout()

                plots["decision"] = {
                    "title": "Decision Plot",
                    "content": self._fig_to_base64(plt.gcf()),
                    "description": "Shows how features contribute to push the model output from base value to final prediction. "
                                   "解读方法：Y轴为预测值/模型输出，X轴为样本排序；每条线代表一个样本的决策路径，从基准值（Base Value）开始，每条彩色横线代表一个特征的贡献值，最终汇聚到该样本的预测值。"
                                   "颜色区分不同特征，线的垂直偏移量代表特征贡献大小，可直观比较不同样本的决策驱动因素和特征影响模式。",
                }
            except Exception as e:
                logging.info(f"Decision plot failed: {str(e)}")

            try:
                sample_idx = min(sample_idx, len(X_test) - 1)

                # 处理基础值和SHAP值
                if isinstance(shap_values, list):
                    # 多分类情况
                    y_pred_sample = self.model.predict(X_test[sample_idx:sample_idx + 1])[0]
                    if y_pred_sample < len(shap_values):
                        shap_val_sample = shap_values[y_pred_sample][sample_idx]
                        base_val = base_value[y_pred_sample] if isinstance(base_value,
                                                                           (list, np.ndarray)) else base_value
                    else:
                        shap_val_sample = shap_values[0][sample_idx]
                        base_val = base_value[0] if isinstance(base_value, (list, np.ndarray)) else base_value
                elif isinstance(shap_values, np.ndarray) and shap_values.ndim == 3:
                    # 3D数组情况
                    y_pred_sample = self.model.predict(X_test[sample_idx:sample_idx + 1])[0]
                    if shap_values.shape[2] > y_pred_sample:
                        shap_val_sample = shap_values[sample_idx, :, y_pred_sample]
                        base_val = base_value[y_pred_sample] if isinstance(base_value,
                                                                           (list, np.ndarray)) else base_value
                    else:
                        shap_val_sample = shap_values[sample_idx, :, 0]
                        base_val = base_value[0] if isinstance(base_value, (list, np.ndarray)) else base_value
                else:
                    # 回归或二分类情况
                    shap_val_sample = shap_values[sample_idx]
                    base_val = base_value[0] if isinstance(base_value, (list, np.ndarray)) and len(
                        base_value) > 0 else base_value

                # 版本1: 系统默认Force Plot (完整版)
                try:
                    plt.figure(figsize=(16, 4))
                    shap.force_plot(
                        base_val,
                        shap_val_sample,
                        X_test[sample_idx],
                        feature_names=feature_names,
                        matplotlib=True,
                        show=False,
                        text_rotation=15,
                        contribution_threshold=0.02
                    )
                    plt.title(f"Force Plot - sample {sample_idx}", fontsize=14, fontweight='bold', pad=20)
                    plt.tight_layout()

                    plots["force_original"] = {
                        "title": "⚡ 特征影响力图 (系统默认版)",
                        "content": self._fig_to_base64(plt.gcf()),
                        "description": self._get_chinese_force_original_description(),
                        "type": "image"
                    }
                except Exception as e1:
                    logging.info(f"Original force plot failed: {str(e1)}")

                # 版本2: 自定义表格版Force Plot
                try:
                    table_fig = self._create_force_plot_table(base_val, shap_val_sample, X_test[sample_idx],
                                                              feature_names, sample_idx)
                    if table_fig:
                        plots["force_table"] = {
                            "title": "📊 特征影响力表格版",
                            "content": self._fig_to_base64(table_fig),
                            "description": self._get_chinese_force_table_description(),
                            "type": "image"
                        }
                except Exception as e2:
                    logging.info(f"Table force plot failed: {str(e2)}")


            except Exception as e:
                logging.info(f"All force plot versions failed: {str(e)}")

            # 4. Waterfall plot
            try:
                plt.figure(figsize=(12, 8))
                sample_idx = min(sample_idx, len(X_test) - 1)

                if isinstance(shap_values, list):
                    y_pred_sample = self.model.predict(X_test[sample_idx:sample_idx + 1])[0]
                    if y_pred_sample < len(shap_values):
                        shap_val_sample = shap_values[y_pred_sample][sample_idx]
                        base_val = base_value[y_pred_sample] if isinstance(base_value,
                                                                           (list, np.ndarray)) else base_value
                    else:
                        shap_val_sample = shap_values[0][sample_idx]
                        base_val = base_value[0] if isinstance(base_value, (list, np.ndarray)) else base_value
                elif isinstance(shap_values, np.ndarray) and shap_values.ndim == 3:
                    y_pred_sample = self.model.predict(X_test[sample_idx:sample_idx + 1])[0]
                    if shap_values.shape[2] > y_pred_sample:
                        shap_val_sample = shap_values[sample_idx, :, y_pred_sample]
                        base_val = base_value[y_pred_sample] if isinstance(base_value,
                                                                           (list, np.ndarray)) else base_value
                    else:
                        shap_val_sample = shap_values[sample_idx, :, 0]
                        base_val = base_value[0] if isinstance(base_value, (list, np.ndarray)) else base_value
                else:
                    shap_val_sample = shap_values[sample_idx]
                    base_val = base_value

                shap.waterfall_plot(shap.Explanation(values=shap_val_sample, base_values=base_val,
                                                     data=X_test[sample_idx], feature_names=feature_names),
                                    show=False)
                plt.title(f"Waterfall Plot - Sample {sample_idx}", fontsize=16, pad=20)
                plt.tight_layout()

                plots["waterfall"] = {
                    "title": "Waterfall Plot",
                    "content": self._fig_to_base64(plt.gcf()),
                    "description": "Shows how each feature contributes to the prediction from base value to final output.瀑布图（Waterfall Plot）：从左到右 或 从右到左显示预测从基准值到最终值的演变过程，每个柱子代表一个特征的SHAP贡献值，向上柱子为正值（增加预测），向下柱子为负值（减少预测）。看点：预测值如何一步步从基准值变化而来。"
                    "关于数值加总疑问：瀑布图通常只展示**主要特征**（按贡献大小排序），省略了贡献较小的特征，因此可见特征的SHAP值之和与最终预测值的差值，即为被省略的所有小贡献特征的总和，保证最终预测值 = 基准值 + Σ(所有特征SHAP值)的数学恒等式成立。",
                    "type": "image"
                }
            except Exception as e:
                logging.info(f"Waterfall plot failed: {str(e)}")

            # 5. Dependence plot for top feature
            try:
                plt.figure(figsize=(12, 8))

                # Get top feature index
                if isinstance(shap_values, list):
                    mean_abs_shap = np.mean(np.abs(shap_values[0]), axis=0)
                elif isinstance(shap_values, np.ndarray) and shap_values.ndim == 3:
                    mean_abs_shap = np.mean(np.abs(shap_values[:, :, 0]), axis=0)
                else:
                    mean_abs_shap = np.mean(np.abs(shap_values), axis=0)

                top_feature_idx = np.argmax(mean_abs_shap)

                if isinstance(shap_values, list):
                    shap.dependence_plot(top_feature_idx, shap_values[0], X_test,
                                         feature_names=feature_names, show=False)
                elif isinstance(shap_values, np.ndarray) and shap_values.ndim == 3:
                    shap.dependence_plot(top_feature_idx, shap_values[:, :, 0], X_test,
                                         feature_names=feature_names, show=False)
                else:
                    shap.dependence_plot(top_feature_idx, shap_values, X_test,
                                         feature_names=feature_names, show=False)

                plt.title(f"Dependence Plot - {feature_names[top_feature_idx]}", fontsize=16, pad=20)
                plt.tight_layout()

                plots["dependence"] = {
                    "title": "Feature Dependence Plot",
                    "content": self._fig_to_base64(plt.gcf()),
                    "description": f"Shows how the model's output depends on '{feature_names[top_feature_idx]}' and its interaction with other features. "
                                   f"SHAP特征依赖图（Feature Dependence Plot）揭示'{feature_names[top_feature_idx]}'对模型预测的影响模式及交互效应：X轴为'{feature_names[top_feature_idx]}'的特征值，Y轴为该特征的SHAP值（对预测的边际贡献），颜色表示第二个特征的值（展示交互效应）。"
                                   "看点：↗向上倾斜=特征值越大正面影响越强；↘向下倾斜=特征值越大负面影响越强；水平线=影响微弱；颜色聚类=存在特征交互。可发现特征的最佳取值范围及复杂影响关系。",
                    "type": "image"
                }
            except Exception as e:
                logging.info(f"Dependence plot failed: {str(e)}")

            # 6. Confusion Matrix (for classification tasks)
            if hasattr(self.model, 'predict') and hasattr(target_names, '__len__') and len(target_names) > 1:
                try:
                    import seaborn as sns
                    from sklearn.metrics import confusion_matrix

                    y_pred = self.model.predict(X_test)
                    cm = confusion_matrix(y_test, y_pred)

                    plt.figure(figsize=(10, 8))

                    # 使用 Seaborn 创建热图
                    ax = sns.heatmap(cm,
                                     annot=True,  # 在格子中显示数值
                                     fmt='d',  # 整数格式
                                     cmap='Blues',  # 颜色方案
                                     cbar=True,  # 显示颜色条
                                     square=True,  # 使格子为正方形
                                     linewidths=0.5,  # 格子之间的线宽
                                     linecolor='white',  # 格子之间的线颜色
                                     annot_kws={"size": 12, "weight": "bold"},  # 注释文本样式
                                     xticklabels=target_names,
                                     yticklabels=target_names)

                    # 美化标题和标签
                    plt.title("Confusion Matrix", fontsize=18, fontweight='bold', pad=20)
                    plt.xlabel('Predicted Labels', fontsize=14, fontweight='bold')
                    plt.ylabel('Actual Labels', fontsize=14, fontweight='bold')

                    # 调整刻度标签
                    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right')
                    ax.set_yticklabels(ax.get_yticklabels(), rotation=0)

                    # 添加网格线效果
                    ax.set_facecolor('#f8f9fa')

                    plt.tight_layout()

                    plots["confusion_matrix"] = {
                        "title": "Confusion Matrix",
                        "content": self._fig_to_base64(plt.gcf()),
                        "description": "Shows the performance of the classification model by comparing actual vs predicted labels. Diagonal elements represent correct predictions.",
                        "type": "image"
                    }

                except Exception as e:
                    logging.info(f"Seaborn confusion matrix failed: {str(e)}")
                    # 备选方案：使用 matplotlib
                    try:
                        from sklearn.metrics import ConfusionMatrixDisplay

                        plt.figure(figsize=(10, 8))
                        disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=target_names)
                        disp.plot(cmap='Blues', ax=plt.gca(), values_format='d')
                        plt.title("Confusion Matrix", fontsize=16, pad=20)
                        plt.tight_layout()

                        plots["confusion_matrix"] = {
                            "title": "Confusion Matrix",
                            "content": self._fig_to_base64(plt.gcf()),
                            "description": "Shows the performance of the classification model by comparing actual vs predicted labels.",
                            "type": "image"
                        }
                    except Exception as e2:
                        logging.info(f"Matplotlib confusion matrix also failed: {str(e2)}")

            # 7. Feature Correlation Heatmap
            try:
                # Create correlation matrix of features
                if hasattr(X_test, 'shape') and X_test.shape[1] > 1:
                    if hasattr(X_test, 'T'):
                        corr_matrix = np.corrcoef(X_test.T)
                    else:
                        corr_matrix = np.corrcoef(X_test, rowvar=False)

                    plt.figure(figsize=(12, 10))
                    im = plt.imshow(corr_matrix, cmap='coolwarm', aspect='auto', vmin=-1, vmax=1)
                    plt.colorbar(im, fraction=0.046, pad=0.04)
                    plt.xticks(range(len(feature_names)), feature_names, rotation=45, ha='right')
                    plt.yticks(range(len(feature_names)), feature_names)
                    plt.title("Feature Correlation Heatmap", fontsize=16, pad=20)

                    # Add correlation values as text
                    for i in range(len(feature_names)):
                        for j in range(len(feature_names)):
                            plt.text(j, i, f'{corr_matrix[i, j]:.2f}',
                                     ha='center', va='center', fontsize=8,
                                     color='white' if abs(corr_matrix[i, j]) > 0.5 else 'black')

                    plt.tight_layout()

                    plots["correlation_heatmap"] = {
                        "title": "Feature Correlation Heatmap",
                        "content": self._fig_to_base64(plt.gcf()),
                        "description": "Shows correlations between different features. High correlations may indicate multicollinearity.",
                        "type": "image"
                    }
            except Exception as e:
                logging.info(f"Correlation heatmap failed: {str(e)}")

            # 8. Force plot (with custom implementation as fallback)
            try:
                # Create correlation matrix of features
                if hasattr(X_test, 'shape') and X_test.shape[1] > 1:
                    import seaborn as sns

                    # 计算相关性矩阵
                    if hasattr(X_test, 'T'):
                        corr_matrix = np.corrcoef(X_test.T)
                    else:
                        corr_matrix = np.corrcoef(X_test, rowvar=False)

                    # 创建掩码来隐藏上三角（可选）
                    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))

                    plt.figure(figsize=(14, 12))

                    # 创建自定义颜色映射来突出显示高相关性
                    import matplotlib.colors as mcolors
                    colors = ['#2166ac', '#4393c3', '#92c5de', '#d1e5f0', '#f7f7f7', '#fddbc7', '#f4a582', '#d6604d',
                              '#b2182b']
                    cmap = mcolors.LinearSegmentedColormap.from_list("custom_rdbu", colors)

                    ax = sns.heatmap(corr_matrix,
                                     mask=np.triu(np.ones_like(corr_matrix, dtype=bool)),
                                     annot=True,
                                     fmt='.2f',
                                     cmap=cmap,
                                     center=0,
                                     square=True,
                                     cbar_kws={"shrink": .8, "label": "Correlation Coefficient"},
                                     linewidths=0.5,
                                     linecolor='white',
                                     annot_kws={"size": 9, "weight": "bold",
                                                "color": "white" if len(feature_names) < 15 else "black"},
                                     xticklabels=feature_names,
                                     yticklabels=feature_names)

                    plt.title("Feature Correlation Heatmap", fontsize=18, fontweight='bold', pad=25)
                    plt.xlabel('Features', fontsize=14, fontweight='bold')
                    plt.ylabel('Features', fontsize=14, fontweight='bold')

                    ax.set_xticklabels(ax.get_xticklabels(), rotation=45, ha='right', fontsize=9)
                    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=9)

                    # 添加高相关性警告
                    high_corr_indices = np.where(np.abs(corr_matrix) > 0.8)
                    high_corr_pairs = [(i, j) for i, j in zip(*high_corr_indices) if i != j]
                    if high_corr_pairs:
                        plt.figtext(0.5, 0.01, f"Warning: {len(high_corr_pairs)} feature pairs with correlation > 0.8",
                                    ha='center', fontsize=10, style='italic', color='red')

                    plt.tight_layout()

                    plots["correlation_heatmap"] = {
                        "title": "Feature Correlation Heatmap",
                        "content": self._fig_to_base64(plt.gcf()),
                        "description": "Shows correlations between different features. Red indicates positive correlation, blue indicates negative correlation. High correlations (>0.8) may indicate multicollinearity.",
                        "type": "image"
                    }

            except Exception as e:
                logging.info(f"Correlation heatmap failed: {str(e)}")
                traceback.print_exc()


            # 9. Comprehensive Model Performance Summary
            try:
                plt.figure(figsize=(14, 10))

                if hasattr(self.model, 'predict'):
                    y_pred = self.model.predict(X_test)
                    y_pred_proba = self.model.predict_proba(X_test) if hasattr(self.model, 'predict_proba') else None

                    if hasattr(target_names, '__len__') and len(target_names) > 1:
                        # ========== CLASSIFICATION METRICS ==========
                        from sklearn.metrics import (precision_score, recall_score, f1_score,
                                                     roc_auc_score, log_loss, precision_recall_curve,
                                                     roc_curve, classification_report, cohen_kappa_score)
                        from sklearn.preprocessing import label_binarize
                        import scipy.stats as stats

                        # Basic metrics
                        accuracy = accuracy_score(y_test, y_pred)
                        precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
                        recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)
                        f1 = f1_score(y_test, y_pred, average='weighted', zero_division=0)
                        kappa = cohen_kappa_score(y_test, y_pred)

                        # Advanced metrics
                        metrics_names = []
                        metrics_values = []

                        # Basic metrics
                        metrics_names.extend(['Accuracy', 'Precision', 'Recall', 'F1-Score', 'Cohen Kappa'])
                        metrics_values.extend([accuracy, precision, recall, f1, kappa])

                        # ROC-AUC for multi-class
                        if y_pred_proba is not None and len(target_names) > 1:
                            try:
                                if len(target_names) == 2:
                                    # Binary classification
                                    roc_auc = roc_auc_score(y_test, y_pred_proba[:, 1])
                                else:
                                    # Multi-class classification
                                    y_test_bin = label_binarize(y_test, classes=range(len(target_names)))
                                    roc_auc = roc_auc_score(y_test_bin, y_pred_proba, average='weighted',
                                                            multi_class='ovr')
                                metrics_names.append('ROC AUC')
                                metrics_values.append(roc_auc)
                            except:
                                pass

                        # Log Loss
                        if y_pred_proba is not None:
                            try:
                                logloss = log_loss(y_test, y_pred_proba)
                                metrics_names.append('Log Loss')
                                metrics_values.append(logloss)
                            except:
                                pass

                        # Matthews Correlation Coefficient for binary
                        if len(target_names) == 2:
                            from sklearn.metrics import matthews_corrcoef
                            mcc = matthews_corrcoef(y_test, y_pred)
                            metrics_names.append('MCC')
                            metrics_values.append(mcc)

                        # Balanced Accuracy
                        from sklearn.metrics import balanced_accuracy_score
                        balanced_acc = balanced_accuracy_score(y_test, y_pred)
                        metrics_names.append('Balanced Acc')
                        metrics_values.append(balanced_acc)

                        # Create subplots for better visualization
                        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))

                        # Plot 1: Enhanced Classification Metrics Bar Chart with Better Readability
                        try:
                            # 使用更鲜明的颜色方案
                            colors1 = ['#3498db', '#2ecc71', '#e74c3c', '#f39c12',
                                       '#9b59b6', '#1abc9c', '#34495e', '#e67e22',
                                       '#27ae60', '#8e44ad', '#16a085', '#f1c40f']
                            colors1 = colors1[:len(metrics_names)]

                            # 创建柱状图
                            bars1 = ax1.bar(metrics_names, metrics_values,
                                            color=colors1,
                                            alpha=0.85,
                                            edgecolor='white',
                                            linewidth=2,
                                            width=0.7)

                            # 设置标题和标签 - 增大字体
                            ax1.set_title('Classification Performance Metrics',
                                          fontsize=18, fontweight='bold', pad=30, color='#2c3e50')
                            ax1.set_ylabel('Score', fontsize=14, fontweight='bold', color='#2c3e50')
                            ax1.set_ylim(0, 1.2)

                            # 美化坐标轴
                            ax1.spines['top'].set_visible(False)
                            ax1.spines['right'].set_visible(False)
                            ax1.spines['left'].set_linewidth(1.5)
                            ax1.spines['bottom'].set_linewidth(1.5)

                            # 设置网格线
                            ax1.grid(True, axis='y', alpha=0.4, linestyle='--', linewidth=0.8)
                            ax1.set_axisbelow(True)

                            # 增大刻度标签字体
                            ax1.tick_params(axis='x', rotation=45, labelsize=12, colors='#2c3e50')
                            ax1.tick_params(axis='y', labelsize=12, colors='#2c3e50')

                            # 添加性能基准线 - 使用虚线
                            ax1.axhline(y=0.9, color='#27ae60', linestyle='--', alpha=0.8, linewidth=2.5,
                                        label='Excellent (≥0.9)')
                            ax1.axhline(y=0.8, color='#f39c12', linestyle='--', alpha=0.8, linewidth=2.5,
                                        label='Good (0.8-0.9)')
                            ax1.axhline(y=0.7, color='#e74c3c', linestyle='--', alpha=0.8, linewidth=2.5,
                                        label='Fair (0.7-0.8)')
                            ax1.axhline(y=0.6, color='#c0392b', linestyle='--', alpha=0.8, linewidth=2.5,
                                        label='Poor (<0.7)')

                            # 添加数值标签 - 增大字体
                            for bar, value in zip(bars1, metrics_values):
                                height = bar.get_height()

                                # 根据数值大小决定标签位置和样式
                                if value >= 0.9:
                                    label_color = 'white'
                                    bg_color = '#27ae60'
                                    label_y = height - 0.05  # 在柱状图内部显示
                                elif value >= 0.8:
                                    label_color = 'white'
                                    bg_color = '#f39c12'
                                    label_y = height - 0.05
                                elif value >= 0.7:
                                    label_color = 'white'
                                    bg_color = '#e74c3c'
                                    label_y = height - 0.05
                                else:
                                    label_color = 'white'
                                    bg_color = '#c0392b'
                                    label_y = height + 0.02  # 在柱状图上方显示

                                ax1.text(bar.get_x() + bar.get_width() / 2, label_y,
                                         f'{value:.3f}',
                                         ha='center', va='center' if value >= 0.7 else 'bottom',
                                         fontweight='bold', fontsize=13,  # 增大字体
                                         color=label_color,
                                         bbox=dict(boxstyle="round,pad=0.4",
                                                   facecolor=bg_color,
                                                   alpha=0.9,
                                                   edgecolor='white',
                                                   linewidth=1.5))

                            # 添加图例 - 增大字体
                            ax1.legend(loc='upper right', frameon=True, fancybox=True,
                                       shadow=True, framealpha=0.95, fontsize=11,
                                       bbox_to_anchor=(1, 1))

                        except Exception as e:
                            logging.info(f"Enhanced readable bar chart failed: {str(e)}")

                        # Plot 2: Confusion Matrix (if not too many classes)
                        if len(target_names) <= 10:
                            from sklearn.metrics import ConfusionMatrixDisplay
                            cm = confusion_matrix(y_test, y_pred)
                            disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=target_names)
                            disp.plot(ax=ax2, cmap='Blues', colorbar=False)
                            ax2.set_title('Confusion Matrix', fontsize=14, fontweight='bold', pad=20)

                        # Plot 3: ROC Curve (for binary classification)
                        if len(target_names) == 2:
                            try:
                                # 确保我们有概率预测
                                if y_pred_proba is not None and hasattr(y_pred_proba, 'shape'):
                                    # 检查概率数组的形状
                                    if y_pred_proba.shape[1] == 2:
                                        # 标准的二元分类概率形状 [n_samples, 2]
                                        fpr, tpr, _ = roc_curve(y_test, y_pred_proba[:, 1])
                                        roc_auc = roc_auc_score(y_test, y_pred_proba[:, 1])
                                    elif y_pred_proba.shape[1] == 1:
                                        # 有些模型可能只返回正类的概率
                                        fpr, tpr, _ = roc_curve(y_test, y_pred_proba[:, 0])
                                        roc_auc = roc_auc_score(y_test, y_pred_proba[:, 0])
                                    else:
                                        # 如果形状不对，尝试使用预测标签
                                        fpr, tpr, _ = roc_curve(y_test, y_pred)
                                        roc_auc = roc_auc_score(y_test, y_pred)
                                else:
                                    # 如果没有概率预测，使用预测标签
                                    fpr, tpr, _ = roc_curve(y_test, y_pred)
                                    roc_auc = roc_auc_score(y_test, y_pred)

                                # 绘制 ROC 曲线
                                ax3.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (AUC = {roc_auc:.3f})')
                                ax3.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', alpha=0.5,
                                         label='Random classifier')
                                ax3.set_xlim([0.0, 1.0])
                                ax3.set_ylim([0.0, 1.05])
                                ax3.set_xlabel('False Positive Rate')
                                ax3.set_ylabel('True Positive Rate')
                                ax3.set_title(f'ROC Curve (AUC = {roc_auc:.3f})', fontsize=14, fontweight='bold',
                                              pad=20)
                                ax3.legend(loc="lower right")
                                ax3.grid(True, alpha=0.3)


                                logging.info(f"ROC Curve - AUC: {roc_auc:.3f}")
                                logging.info(f"FPR shape: {fpr.shape}, TPR shape: {tpr.shape}")

                            except Exception as roc_error:
                                logging.info(f"ROC curve failed: {str(roc_error)}")
                                # 如果 ROC 曲线失败，显示错误信息
                                ax3.text(0.5, 0.5, 'ROC Curve\nNot Available',
                                         ha='center', va='center', transform=ax3.transAxes, fontsize=12)
                                ax3.set_title('ROC Curve (Not Available)', fontsize=14, fontweight='bold', pad=20)
                                ax3.grid(True, alpha=0.3)
                        # Plot 3: Multi-class Visualization (when len(target_names) > 2)
                        if len(target_names) > 2:
                            try:
                                # 选项1: 多类别ROC曲线（一对多）
                                from sklearn.preprocessing import label_binarize
                                from sklearn.metrics import roc_auc_score, roc_curve

                                # 将标签二值化
                                y_test_bin = label_binarize(y_test, classes=range(len(target_names)))

                                if y_pred_proba is not None and y_pred_proba.shape[1] == len(target_names):
                                    # 计算每个类别的ROC曲线和AUC
                                    fpr = dict()
                                    tpr = dict()
                                    roc_auc = dict()

                                    for i in range(len(target_names)):
                                        fpr[i], tpr[i], _ = roc_curve(y_test_bin[:, i], y_pred_proba[:, i])
                                        roc_auc[i] = roc_auc_score(y_test_bin[:, i], y_pred_proba[:, i])

                                    # 计算微平均ROC曲线
                                    fpr["micro"], tpr["micro"], _ = roc_curve(y_test_bin.ravel(), y_pred_proba.ravel())
                                    roc_auc["micro"] = roc_auc_score(y_test_bin, y_pred_proba, average="micro")

                                    # 绘制微平均ROC曲线
                                    ax3.plot(fpr["micro"], tpr["micro"],
                                             label=f'micro-average ROC (AUC = {roc_auc["micro"]:.3f})',
                                             color='deeppink', linestyle=':', linewidth=4)

                                    # 绘制几个主要类别的ROC曲线
                                    colors = ['aqua', 'darkorange', 'cornflowerblue', 'green', 'red', 'purple']
                                    for i, color in zip(range(min(3, len(target_names))), colors):
                                        ax3.plot(fpr[i], tpr[i], color=color, lw=2,
                                                 label=f'Class {target_names[i]} (AUC = {roc_auc[i]:.3f})')

                                    ax3.plot([0, 1], [0, 1], 'k--', lw=2, alpha=0.5, label='Random classifier')
                                    ax3.set_xlim([0.0, 1.0])
                                    ax3.set_ylim([0.0, 1.05])
                                    ax3.set_xlabel('False Positive Rate')
                                    ax3.set_ylabel('True Positive Rate')
                                    ax3.set_title('Multi-class ROC Curves', fontsize=14, fontweight='bold', pad=20)
                                    ax3.legend(loc="lower right", fontsize=9)
                                    ax3.grid(True, alpha=0.3)

                                else:
                                    # 选项2: 类别分布和准确率
                                    from sklearn.metrics import classification_report

                                    # 计算每个类别的准确率
                                    class_accuracy = []
                                    for i in range(len(target_names)):
                                        mask = y_test == i
                                        if np.sum(mask) > 0:
                                            class_acc = accuracy_score(y_test[mask], y_pred[mask])
                                        else:
                                            class_acc = 0
                                        class_accuracy.append(class_acc)

                                    # 创建双Y轴图表
                                    fig, (ax31, ax32) = plt.subplots(1, 2, figsize=(14, 6))

                                    # 左图: 类别分布
                                    unique, counts = np.unique(y_test, return_counts=True)
                                    bars1 = ax31.bar(range(len(unique)), counts, color='lightblue', alpha=0.7,
                                                     label='Test Samples')
                                    ax31.set_xlabel('Class')
                                    ax31.set_ylabel('Number of Samples', color='blue')
                                    ax31.set_xticks(range(len(unique)))
                                    ax31.set_xticklabels([target_names[i] for i in unique], rotation=45)
                                    ax31.tick_params(axis='y', labelcolor='blue')
                                    ax31.set_title('Class Distribution in Test Set', fontsize=12, fontweight='bold')

                                    # 在柱状图上添加数值
                                    for i, count in enumerate(counts):
                                        ax31.text(i, count + max(counts) * 0.01, str(count), ha='center', va='bottom',
                                                  fontweight='bold')

                                    # 右图: 每个类别的准确率
                                    ax32_twin = ax32.twinx()
                                    bars2 = ax32.bar(range(len(class_accuracy)), class_accuracy,
                                                     color='lightcoral', alpha=0.7, label='Class Accuracy')
                                    ax32.set_xlabel('Class')
                                    ax32.set_ylabel('Accuracy', color='red')
                                    ax32.set_xticks(range(len(class_accuracy)))
                                    ax32.set_xticklabels(target_names, rotation=45)
                                    ax32.tick_params(axis='y', labelcolor='red')
                                    ax32.set_ylim(0, 1.0)
                                    ax32.set_title('Per-Class Accuracy', fontsize=12, fontweight='bold')

                                    # 在准确率柱状图上添加数值
                                    for i, acc in enumerate(class_accuracy):
                                        ax32.text(i, acc + 0.02, f'{acc:.3f}', ha='center', va='bottom',
                                                  fontweight='bold')

                                    plt.tight_layout()

                            except Exception as multi_error:
                                logging.info(f"Multi-class visualization failed: {str(multi_error)}")
                                # 备选方案: 简单的类别统计
                                try:
                                    # 计算每个类别的统计信息
                                    unique, counts = np.unique(y_test, return_counts=True)
                                    correct_predictions = [np.sum((y_test == i) & (y_pred == i)) for i in unique]
                                    accuracy_per_class = [correct / total if total > 0 else 0 for correct, total in
                                                          zip(correct_predictions, counts)]

                                    # 创建堆叠柱状图
                                    x_pos = np.arange(len(unique))
                                    width = 0.6

                                    bars_correct = ax3.bar(x_pos, correct_predictions, width, label='Correct',
                                                           color='#2ecc71')
                                    bars_incorrect = ax3.bar(x_pos, [counts[i] - correct_predictions[i] for i in
                                                                     range(len(unique))],
                                                             width, bottom=correct_predictions, label='Incorrect',
                                                             color='#e74c3c')

                                    ax3.set_xlabel('Class')
                                    ax3.set_ylabel('Number of Samples')
                                    ax3.set_title('Prediction Results by Class', fontsize=14, fontweight='bold', pad=20)
                                    ax3.set_xticks(x_pos)
                                    ax3.set_xticklabels([target_names[i] for i in unique], rotation=45)
                                    ax3.legend()
                                    ax3.grid(True, alpha=0.3, axis='y')

                                    # 添加准确率文本
                                    for i, (correct, total, acc) in enumerate(
                                            zip(correct_predictions, counts, accuracy_per_class)):
                                        ax3.text(i, total + max(counts) * 0.02, f'{acc:.1%}', ha='center', va='bottom',
                                                 fontweight='bold', fontsize=10)

                                except Exception as simple_error:
                                    logging.info(f"Simple multi-class visualization also failed: {str(simple_error)}")
                                    # 最后备选: 显示基本信息
                                    ax3.text(0.5, 0.5,
                                             f'Multi-class Analysis\n{len(target_names)} Classes\nTotal Samples: {len(y_test)}',
                                             ha='center', va='center', transform=ax3.transAxes, fontsize=12)
                                    ax3.set_title('Multi-class Overview', fontsize=14, fontweight='bold', pad=20)
                                    ax3.grid(False)

                        # Plot 4: Feature Importance Comparison
                        if hasattr(self.model, 'feature_importances_'):
                            importances = self.model.feature_importances_
                            indices = np.argsort(importances)[::-1]
                            top_features = min(10, len(feature_names))

                            ax4.barh(range(top_features), importances[indices[:top_features]][::-1],
                                     color=plt.cm.viridis(np.linspace(0, 1, top_features)))
                            ax4.set_yticks(range(top_features))
                            ax4.set_yticklabels([feature_names[i] for i in indices[:top_features]][::-1])
                            ax4.set_xlabel('Importance')
                            ax4.set_title(f'Top {top_features} Feature Importances', fontsize=14, fontweight='bold',
                                          pad=20)
                            ax4.grid(True, alpha=0.3, axis='x')

                        plt.tight_layout()

                    else:
                        # ========== REGRESSION METRICS ==========
                        from sklearn.metrics import (mean_absolute_error, mean_squared_error,
                                                     mean_absolute_percentage_error, r2_score,
                                                     explained_variance_score, max_error)
                        from scipy.stats import pearsonr

                        # Calculate all regression metrics
                        mae = mean_absolute_error(y_test, y_pred)
                        mse = mean_squared_error(y_test, y_pred)
                        rmse = np.sqrt(mse)
                        r2 = r2_score(y_test, y_pred)
                        evs = explained_variance_score(y_test, y_pred)
                        max_err = max_error(y_test, y_pred)

                        # Additional metrics
                        try:
                            mape = mean_absolute_percentage_error(y_test, y_pred)
                        except:
                            mape = np.nan

                        # Correlation
                        correlation, _ = pearsonr(y_test, y_pred)

                        # Create comprehensive metrics list
                        metrics_names = ['R² Score', 'Explained Variance', 'MAE', 'RMSE', 'MSE',
                                         'Max Error', 'Correlation']
                        metrics_values = [r2, evs, mae, rmse, mse, max_err, correlation]

                        if not np.isnan(mape):
                            metrics_names.append('MAPE (%)')
                            metrics_values.append(mape * 100)  # Convert to percentage

                        # Create subplots for regression
                        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))

                        # Plot 1: Metrics Bar Chart
                        colors1 = plt.cm.Paired(np.linspace(0, 1, len(metrics_names)))
                        bars1 = ax1.bar(metrics_names, metrics_values, color=colors1, alpha=0.8, edgecolor='black')
                        ax1.set_title('Regression Metrics Summary', fontsize=14, fontweight='bold', pad=20)
                        ax1.set_ylabel('Score')
                        ax1.tick_params(axis='x', rotation=45)

                        # Add value labels on bars
                        for bar, value in zip(bars1, metrics_values):
                            height = bar.get_height()
                            ax1.text(bar.get_x() + bar.get_width() / 2, height + (0.01 * max(metrics_values)),
                                     f'{value:.3f}', ha='center', va='bottom', fontweight='bold', fontsize=9)

                        # Plot 2: Actual vs Predicted Scatter
                        ax2.scatter(y_test, y_pred, alpha=0.6, color='blue', s=30)
                        ax2.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
                        ax2.set_xlabel('Actual Values')
                        ax2.set_ylabel('Predicted Values')
                        ax2.set_title(f'Actual vs Predicted (R² = {r2:.3f})', fontsize=14, fontweight='bold', pad=20)
                        ax2.grid(True, alpha=0.3)

                        # Plot 3: Residuals Plot
                        residuals = y_test - y_pred
                        ax3.scatter(y_pred, residuals, alpha=0.6, color='green', s=30)
                        ax3.axhline(y=0, color='red', linestyle='--', alpha=0.8)
                        ax3.set_xlabel('Predicted Values')
                        ax3.set_ylabel('Residuals')
                        ax3.set_title('Residuals Plot', fontsize=14, fontweight='bold', pad=20)
                        ax3.grid(True, alpha=0.3)

                        # Plot 4: Error Distribution
                        ax4.hist(residuals, bins=30, alpha=0.7, color='orange', edgecolor='black')
                        ax4.axvline(x=0, color='red', linestyle='--', alpha=0.8, label='Zero Error')
                        ax4.set_xlabel('Residuals')
                        ax4.set_ylabel('Frequency')
                        ax4.set_title('Error Distribution', fontsize=14, fontweight='bold', pad=20)
                        ax4.legend()
                        ax4.grid(True, alpha=0.3)

                        plt.tight_layout()

                    plots["performance"] = {
                        "title": "Comprehensive Model Performance",
                        "content": self._fig_to_base64(fig),
                        "description": "Detailed performance metrics and diagnostic plots for model evaluation.",
                        "type": "image"
                    }

            except Exception as e:
                logging.info(f"Comprehensive performance summary failed: {str(e)}")
                traceback.print_exc()

        except Exception as e:
            logging.info(f"SHAP plot generation failed: {str(e)}")
            traceback.print_exc()

        return plots

    def _create_force_plot_table(self, base_value, shap_values, feature_values, feature_names, sample_idx):
        """创建美观的表格版Force Plot"""
        try:
            fig = plt.figure(figsize=(16, 12))

            # 创建网格布局
            gs = plt.GridSpec(2, 1, height_ratios=[1, 2], hspace=0.05)
            ax1 = fig.add_subplot(gs[0])  # 摘要区域
            ax2 = fig.add_subplot(gs[1])  # 表格区域

            # 安全处理基础值
            try:
                if isinstance(base_value, (list, np.ndarray)):
                    base_val = float(base_value[0]) if len(base_value) > 0 else 0.0
                else:
                    base_val = float(base_value)
            except (TypeError, ValueError, IndexError):
                base_val = 0.0

            shap_array = np.array(shap_values)

            # 准备表格数据
            table_data = []
            total_positive = 0
            total_negative = 0

            for i, (feature, shap_val, feat_val) in enumerate(zip(feature_names, shap_array, feature_values)):
                if abs(shap_val) > 0.001:  # 只显示有显著影响的特征
                    contribution_percent = (abs(shap_val) / np.sum(np.abs(shap_array))) * 100
                    table_data.append({
                        'feature': feature,
                        'feature_value': round(float(feat_val), 4),
                        'shap_value': round(shap_val, 6),
                        'contribution_percent': round(contribution_percent, 2),
                        'direction': 'postive' if shap_val > 0 else 'neg',
                        'abs_impact': abs(shap_val)
                    })
                    if shap_val > 0:
                        total_positive += shap_val
                    else:
                        total_negative += shap_val

            # 按贡献度排序
            table_data.sort(key=lambda x: x['abs_impact'], reverse=True)

            # 计算最终预测值
            final_prediction = base_val + sum(item['shap_value'] for item in table_data)

            # 上部分：精美的摘要信息
            ax1.axis('off')

            # 背景色
            ax1.set_facecolor('#f8f9fa')

            # 主标题
            ax1.text(0.5, 0.85, f"sample {sample_idx} ",
                     fontsize=20, fontweight='bold', ha='center',
                     transform=ax1.transAxes, color="#a4c1df")

            # 关键指标卡片
            metrics = [
                ('Base Value', f'{base_val:.4f}', '#3498db'),
                ('Final Prediction', f'{final_prediction:.4f}', '#2ecc71'),
                ('Positive Impact', f'{total_positive:+.4f}', '#e74c3c'),
                ('Negative Impact', f'{total_negative:+.4f}', '#9b59b6')
            ]

            for i, (label, value, color) in enumerate(metrics):
                x_pos = 0.15 + i * 0.2
                # 指标卡片背景
                rect = plt.Rectangle((x_pos - 0.08, 0.45), 0.16, 0.3,
                                     transform=ax1.transAxes,
                                     facecolor=color, alpha=0.1,
                                     edgecolor=color, linewidth=2)
                ax1.add_patch(rect)

                # 指标值
                ax1.text(x_pos, 0.65, value, fontsize=16, fontweight='bold',
                         ha='center', transform=ax1.transAxes, color=color)
                # 指标标签
                ax1.text(x_pos, 0.5, label, fontsize=11,
                         ha='center', transform=ax1.transAxes, color='#7f8c8d')

            # 额外信息
            info_text = f"important feature num: {len(table_data)} | Net Impact: {total_positive + total_negative:+.4f}"
            ax1.text(0.5, 0.25, info_text, fontsize=12,
                     ha='center', transform=ax1.transAxes, color='#95a5a6')

            # 下部分：现代化表格
            if table_data:
                ax2.axis('off')

                # 创建表格
                table_headers = ['Rank', 'Feature Name', 'Feature Value', 'SHAP Value', 'Contribution', 'Impact Direction']
                table_content = []

                for idx, row in enumerate(table_data, 1):
                    # 缩短过长的特征名称
                    feature_name = row['feature']
                    if len(feature_name) > 25:
                        feature_name = feature_name[:22] + '...'

                    # 根据贡献度设置颜色强度
                    contribution_color = '#ff6b6b' if row['direction'] == 'postive' else '#4ecdc4'
                    contribution_alpha = min(0.3 + (row['contribution_percent'] / 100) * 0.7, 1.0)

                    table_content.append([
                        f"{idx}",
                        feature_name,
                        f"{row['feature_value']}",
                        f"{row['shap_value']:+.6f}",
                        f"{row['contribution_percent']:.1f}%",
                        row['direction']
                    ])

                # 创建表格
                table = ax2.table(cellText=table_content,
                                  colLabels=table_headers,
                                  cellLoc='center',
                                  loc='center',
                                  bbox=[0.02, 0.02, 0.96, 0.96])

                # 表格样式设计
                table.auto_set_font_size(False)
                table.set_fontsize(10)
                table.scale(1, 2.0)

                # 设置列宽
                col_widths = [0.05, 0.35, 0.15, 0.2, 0.1, 0.15]
                for j, width in enumerate(col_widths):
                    table.auto_set_column_width(j)

                # 表头样式
                for j in range(len(table_headers)):
                    cell = table[(0, j)]
                    cell.set_facecolor("#96bde4")
                    cell.set_text_props(color='white', weight='bold', size=11)
                    cell.set_height(0.08)

                # 数据行样式
                for i in range(len(table_data)):
                    for j in range(len(table_headers)):
                        cell = table[(i + 1, j)]

                        # 设置行背景色
                        if i % 2 == 0:
                            cell.set_facecolor('#f8f9fa')
                        else:
                            cell.set_facecolor('#ffffff')

                        # 设置边框
                        cell.set_edgecolor('#e9ecef')

                        # 特殊列样式
                        if j == 0:  # 排名列
                            cell.set_facecolor('#ecf0f1')
                            cell.set_text_props(weight='bold', color='#2c3e50')
                        elif j == 3:  # SHAP值列
                            shap_val = table_data[i]['shap_value']
                            if shap_val > 0:
                                cell.set_text_props(color='#e74c3c', weight='bold')
                            else:
                                cell.set_text_props(color='#3498db', weight='bold')
                        elif j == 4:  # 贡献度列
                            cell.set_text_props(weight='bold', color="#89b7e6")
                        elif j == 5:  # 影响方向列
                            if table_data[i]['direction'] == 'postive':
                                cell.set_facecolor('#ffebee')
                                cell.set_text_props(color='#e74c3c', weight='bold')
                            else:
                                cell.set_facecolor('#e3f2fd')
                                cell.set_text_props(color='#1976d2', weight='bold')

                # 表格标题
                ax2.text(0.02, 0.98, '',
                         fontsize=14, fontweight='bold',
                         transform=ax2.transAxes, color='#2c3e50',
                         verticalalignment='top')

            else:
                ax2.text(0.5, 0.5, '',
                         ha='center', va='center', transform=ax2.transAxes,
                         fontsize=16, color='#95a5a6')
                ax2.axis('off')

            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"Force plot table creation failed: {str(e)}")
            # 返回一个简单的错误提示图
            fig, ax = plt.subplots(figsize=(10, 6))
            ax.text(0.5, 0.5, f'表格生成失败: {str(e)}',
                    ha='center', va='center', transform=ax.transAxes)
            ax.axis('off')
            return fig
    def _get_guide_description(self):
        """生成指南的描述"""
        return """
        This guide explains how to interpret SHAP values and plots. 
        SHAP values show how each feature contributes to model predictions.
        - Positive SHAP values increase the prediction
        - Negative SHAP values decrease the prediction  
        - Larger absolute values indicate more important features
        Use this guide to understand the different plot types and what to look for.
        """

    def _get_summary_plot_description(self):
        """生成Summary Plot的详细解读"""
        return """
        <div style="background: #f0f8ff; padding: 15px; border-radius: 8px; border-left: 4px solid #3498db;">
        <h4 style="margin-top: 0; color: #2c3e50;">How to read this plot:</h4>
        <ul style="margin-bottom: 0;">
            <li><strong>Y-axis</strong>: Features sorted by importance (most important at top)</li>
            <li><strong>X-axis</strong>: SHAP value impact on prediction</li>
            <li><strong>Color</strong>: Red = high feature value, Blue = low feature value</li>
            <li><strong>Point density</strong>: Shows where most samples are concentrated</li>
        </ul>
        <p style="margin: 10px 0 0 0;"><strong>Key insights to look for:</strong></p>
        <ul style="margin-bottom: 0;">
            <li>Identify the most influential features</li>
            <li>Understand how feature values affect predictions</li>
            <li>Spot unusual patterns that might indicate issues</li>
        </ul>
        </div>
        """

    def _get_force_plot_description(self):
        """生成Force Plot的详细解读"""
        return """
        <div style="background: #fff0f0; padding: 15px; border-radius: 8px; border-left: 4px solid #e74c3c;">
        <h4 style="margin-top: 0; color: #2c3e50;">How to read this plot:</h4>
        <ul style="margin-bottom: 0;">
            <li><strong>Base value</strong>: Average prediction across all samples</li>
            <li><strong>Red arrows</strong>: Features increasing the prediction</li>
            <li><strong>Blue arrows</strong>: Features decreasing the prediction</li>
            <li><strong>Arrow length</strong>: Strength of the feature's influence</li>
            <li><strong>Final value</strong>: The model's prediction for this sample</li>
        </ul>
        <p style="margin: 10px 0 0 0;"><strong>Use this to:</strong></p>
        <ul style="margin-bottom: 0;">
            <li>Understand why a specific prediction was made</li>
            <li>Identify the main drivers for individual cases</li>
            <li>Compare different samples to see pattern variations</li>
        </ul>
        </div>
        """

    def _get_chinese_guide_description(self):
        """生成中文指南描述"""
        return """
        <div style="background: #f0f8ff; padding: 15px; border-radius: 8px; border-left: 4px solid #3498db;">
        <h4 style="margin-top: 0; color: #2c3e50;">📖 使用说明：</h4>
        <p>本指南专为机器学习初学者设计，用简单易懂的方式解释SHAP值的概念。</p>
        <p><strong>建议阅读顺序：</strong></p>
        <ol>
            <li>先看本指南 - 了解基本概念</li>
            <li>再看特征重要性指南 - 学习如何解读重要性</li>
            <li>然后查看具体图表 - 应用所学知识分析模型</li>
        </ol>
        </div>
        """

    def _get_chinese_force_original_description(self):
        """生成系统默认版Force Plot描述"""
        return """
        <div style="background: #fff0f0; padding: 15px; border-radius: 8px; border-left: 4px solid #e74c3c;">
        <h4 style="margin-top: 0; color: #2c3e50;">⚡ 系统默认版Force Plot：</h4>
        <ul style="margin-bottom: 0;">
            <li><strong>完整可视化</strong>：显示所有特征的完整影响力链条</li>
            <li><strong>直观展示</strong>：红色推动预测增加，蓝色推动预测减少</li>
            <li><strong>专业标准</strong>：使用SHAP官方标准可视化</li>
        </ul>
        <p style="margin: 10px 0 0 0;"><strong>💡 适用场景：</strong></p>
        <ul style="margin-bottom: 0;">
            <li>需要完整查看所有特征影响时</li>
            <li>特征名称较短，显示效果良好时</li>
            <li>需要标准化的专业报告时</li>
        </ul>
        </div>
        """

    def _get_chinese_force_table_description(self):
        """生成表格版Force Plot描述"""
        return """
        <div style="background: #f0f8ff; padding: 15px; border-radius: 8px; border-left: 4px solid #3498db;">
        <h4 style="margin-top: 0; color: #2c3e50;">📊 表格版Force Plot：</h4>
        <p style="margin: 10px 0 0 0;"><strong>💡 适用场景：</strong></p>
        <ul style="margin-bottom: 0;">
            <li>特征名称较长，需要优化显示时</li>
            <li>需要精确数值分析时</li>
            <li>制作正式报告需要表格数据时</li>
        </ul>
        </div>
        """

    def _get_chinese_force_visual_description(self):
        """生成可视化版Force Plot描述"""
        return """
        <div style="background: #f0fff0; padding: 15px; border-radius: 8px; border-left: 4px solid #27ae60;">
        <h4 style="margin-top: 0; color: #2c3e50;">📈 可视化版Force Plot：</h4>
        <ul style="margin-bottom: 0;">
            <li><strong>多角度分析</strong>：结合条形图和饼图多维度展示</li>
            <li><strong>影响力分布</strong>：清晰显示正向和负向影响的比例</li>
            <li><strong>重点突出</strong>：自动聚焦于最重要的特征</li>
            <li><strong>美观易读</strong>：优化视觉效果，便于理解</li>
        </ul>
        <p style="margin: 10px 0 0 0;"><strong>💡 适用场景：</strong></p>
        <ul style="margin-bottom: 0;">
            <li>需要快速理解主要影响因素时</li>
            <li>向非技术人员展示分析结果时</li>
            <li>制作演示材料时</li>
        </ul>
        </div>
        """

    def _create_force_plot_visualization(self, base_value, shap_values, feature_values, feature_names, sample_idx):
        """创建可视化版的Force Plot"""
        try:
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))

            # 安全处理基础值
            try:
                if isinstance(base_value, (list, np.ndarray)):
                    base_val = float(base_value[0]) if len(base_value) > 0 else 0.0
                else:
                    base_val = float(base_value)
            except (TypeError, ValueError, IndexError):
                base_val = 0.0

            shap_array = np.array(shap_values)

            # 左图：特征影响力条形图
            features = []
            values = []
            colors = []

            for i, (feature, value) in enumerate(zip(feature_names, shap_array)):
                if abs(value) > 0.001:
                    features.append(feature)
                    values.append(value)
                    colors.append('#FF6B6B' if value > 0 else '#4ECDC4')

            if features:
                # 按影响力绝对值排序
                indices = np.argsort(np.abs(values))[::-1]
                sorted_features = [features[i] for i in indices]
                sorted_values = [values[i] for i in indices]
                sorted_colors = [colors[i] for i in indices]

                # 限制显示数量，避免过于拥挤
                max_features = min(15, len(sorted_features))
                sorted_features = sorted_features[:max_features]
                sorted_values = sorted_values[:max_features]
                sorted_colors = sorted_colors[:max_features]

                y_pos = np.arange(len(sorted_features))
                bars = ax1.barh(y_pos, sorted_values, color=sorted_colors, alpha=0.8, height=0.7)

                # 添加数值标签
                for i, (bar, value) in enumerate(zip(bars, sorted_values)):
                    width = bar.get_width()
                    if abs(width) > 0:
                        ha = 'left' if width > 0 else 'right'
                        x_pos = width + (0.01 if width > 0 else -0.01)
                        color = 'darkred' if width > 0 else 'darkblue'
                        ax1.text(x_pos, bar.get_y() + bar.get_height() / 2,
                                 f'{value:+.4f}', ha=ha, va='center',
                                 fontweight='bold', color=color, fontsize=9)

                ax1.set_yticks(y_pos)
                ax1.set_yticklabels(sorted_features, fontsize=9)
                ax1.set_xlabel('SHAP值影响力', fontsize=11, fontweight='bold')
                ax1.set_title('特征影响力排序', fontsize=12, fontweight='bold')
                ax1.axvline(x=0, color='black', linestyle='-', alpha=0.5)
                ax1.grid(axis='x', alpha=0.3)

            else:
                ax1.text(0.5, 0.5, '没有显著影响的特征',
                         ha='center', va='center', transform=ax1.transAxes, fontsize=12)
                ax1.axis('off')

            # 右图：影响力分布饼图
            if len(values) > 0:
                positive_impact = sum(v for v in values if v > 0)
                negative_impact = sum(v for v in values if v < 0)
                total_impact = positive_impact + abs(negative_impact)

                if total_impact > 0:
                    sizes = [positive_impact, abs(negative_impact)]
                    labels = [f'正向影响\n{positive_impact:+.4f}', f'负向影响\n{negative_impact:+.4f}']
                    colors_pie = ['#FF6B6B', '#4ECDC4']

                    wedges, texts, autotexts = ax2.pie(sizes, labels=labels, colors=colors_pie,
                                                       autopct='%1.1f%%', startangle=90)

                    for autotext in autotexts:
                        autotext.set_color('white')
                        autotext.set_fontweight('bold')

                    ax2.set_title('影响力分布', fontsize=12, fontweight='bold')

                # 添加预测信息
                final_prediction = base_val + sum(values)
                info_text = f"基础值: {base_val:.4f}\n最终预测: {final_prediction:.4f}"
                ax2.text(0.5, -0.1, info_text, ha='center', va='center',
                         transform=ax2.transAxes, fontsize=10,
                         bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgray"))

            else:
                ax2.text(0.5, 0.5, '无显著影响力分布',
                         ha='center', va='center', transform=ax2.transAxes, fontsize=12)
                ax2.axis('off')

            plt.suptitle(f'样本 {sample_idx} - 特征影响力分析', fontsize=14, fontweight='bold')
            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"Force plot visualization creation failed: {str(e)}")
            return None

class HTMLReportGenerator:
    @staticmethod
    def generate_report(plots, output_path, task, dataset_name, model_metrics):
        """Generate HTML report"""
        try:
            tab_buttons = []
            tab_contents = []

            for i, (plot_id, plot_info) in enumerate(plots.items()):
                tab_id = f"tab_{i}"
                tab_buttons.append(f'<button class="tab-btn" data-tab="{tab_id}">{plot_info["title"]}</button>')

                content = f'<img src="{plot_info["content"]}" class="plot-image" alt="{plot_info["title"]}">'

                tab_contents.append(f'''
                <div id="{tab_id}" class="tab-content">
                    <h2 class="plot-title">{plot_info["title"]}</h2>
                    <div class="plot-description">{plot_info["description"]}</div>
                    {content}
                </div>
                ''')

            metrics_text = ""
            if task == "classification":
                accuracy = model_metrics.get('accuracy', 0)
                metrics_text = f"Accuracy: {accuracy:.4f}"
            else:
                r2 = model_metrics.get('r2', 0)
                metrics_text = f"R² Score: {r2:.4f}"

            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SHAP Analysis Report - {task} - {dataset_name}</title>
    <style>
        body {{
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f7fa; /* Light gray background instead of gradient */
            min-height: 100vh;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white; /* White container as requested */
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08); /* Subtler shadow */
            overflow: hidden;
        }}
        .header {{
            background:  linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); /* Softer red (reduced saturation) */
            color: white;
            padding: 3px 15px; /* Reduced padding for smaller height */
            text-align: left;
        }}
        .metrics {{
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); /* Softer blue */
            color: white;
            padding: 2px 10px; /* Reduced padding */
            text-align: left;
            font-size: 16px; /* Slightly smaller font */
            font-weight: 600;
        }}
        .tab-container {{
            padding: 20px;
        }}
        .tab-buttons {{
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
        }}
        .tab-btn {{
            padding: 10px 20px; /* Slightly smaller buttons */
            background: #9b59b6; /* Softer purple */
            color: white;
            border: none;
            border-radius: 20px; /* Slightly smaller radius */
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
            font-size: 14px;
        }}
        .tab-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(155, 89, 182, 0.3);
        }}
        .tab-btn.active {{
            background: #e74c3c; /* Matching header color */
        }}
        .tab-content {{
            display: none;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
        }}
        .tab-content.active {{
            display: block;
            animation: fadeIn 0.5s ease;
        }}
        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(10px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}
        .plot-title {{
            color: #2d3436;
            border-bottom: 2px solid #e74c3c; /* Matching header color */
            padding-bottom: 8px;
            margin-top: 0;
            font-size: 1.4em;
        }}
        .plot-description {{
            color: #636e72;
            line-height: 1.6;
            margin-bottom: 20px;
            font-size: 15px;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border-left: 3px solid #3498db; /* Matching metrics color */
        }}
        .plot-image {{
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            display: block;
            margin: 0 auto;
        }}
        .footer {{
            text-align: center;
            padding: 15px;
            color: #636e72;
            font-size: 13px;
            background: #f8f9fa;
            border-top: 1px solid #eee;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h4>SHAP Analysis Report</h1>
            <p>Task: {task} | Dataset: {dataset_name} | Generated: {current_time}</p>
        </div>

        <div class="metrics">
            <h5>Model Performance</h3>
            <p>{metrics_text}</p>
        </div>

        <div class="tab-container">
            <div class="tab-buttons">
                {tab_buttons}
            </div>

            {tab_contents}
        </div>

        <div class="footer">
            <p>SHAP Analysis Report Tool | Generated with by your friends  </p>
        </div>
    </div>

    <script>
        document.querySelectorAll('.tab-btn').forEach(button => {{
            button.addEventListener('click', () => {{
                document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
                button.classList.add('active');
                document.getElementById(button.getAttribute('data-tab')).classList.add('active');
            }});
        }});
        if (document.querySelector('.tab-btn')) {{
            document.querySelector('.tab-btn').classList.add('active');
            document.querySelector('.tab-content').classList.add('active');
        }}
    </script>
</body>
</html>
            """

            html_content = html_template.format(
                task=task,
                dataset_name=dataset_name,
                metrics_text=metrics_text,
                tab_buttons=''.join(tab_buttons),
                tab_contents=''.join(tab_contents),
                current_time=current_time
            )

            output_dir = os.path.dirname(output_path)
            if output_dir and not os.path.exists(output_dir):
                os.makedirs(output_dir, exist_ok=True)

            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)

            logging.info(f"Report generated: {os.path.abspath(output_path)}")
            return output_path

        except Exception as e:
            logging.info(f"HTML report generation failed: {str(e)}")
            traceback.print_exc()
            raise

def embeding_shapAnalyzer_inTrain( model, task,X_train, y_train,X_test, y_test,feature_names , ouput_file, target_names=None,dataset_name="" ):
    if task in ["reg"]:
        task ="regression"
    elif task in ['clc','clf']:
        task = 'classification'
    else:
        pass
    if task in ["regression"]:target_names=None
    model_metrics = ModelTrainer.evaluate_model(model, X_test, y_test, task=task)
    analyzer = SHAPAnalyzer(model, X_train, task=task, feature_names=feature_names)
    plots = analyzer.generate_basic_plots(X_test, y_test, feature_names, target_names)
    logging.info("plots keys:%s", plots.keys())
    logging.info("plots keys:", plots.keys())
    if not plots:
        plots = {"empty": {
            "title": "No Plots",
            "content": "",
            "description": "No LIME plots were generated",
            "type": "text"
        }}

    model_metrics = ModelTrainer.evaluate_model(model, X_test, y_test, task=task)
    # SHAP analysis
    logging.info(f"explainer modelmetrics:{model_metrics}")


    if not plots:
        plots = {"empty": {
            "title": "No Plots",
            "content": "",
            "description": "No SHAP plots were generated",
            "type": "text"
        }}

    # Generate report

    output_path = HTMLReportGenerator.generate_report(
        plots,
        ouput_file,
        task=task,
        dataset_name=dataset_name,
        model_metrics=model_metrics
    )
    return output_path

def main():
    try:
        parser = argparse.ArgumentParser(description='SHAP Model Analysis Tool')
        parser.add_argument('--input_file', type=str, default="./diamonds.csv", help='Input CSV file path')
        parser.add_argument('--output', type=str, default="test_final.html", help='Output HTML report path')
        parser.add_argument('--task', type=str, default="regression", choices=["classification", "regression"],
                            help='Task type')
        parser.add_argument('--target_column', type=str, help='Target column name')
        parser.add_argument('--test_size', type=float, default=0.3, help='Test set ratio')
        parser.add_argument('--random_state', type=int, default=42, help='Random seed')
        parser.add_argument('--n_estimators', type=int, default=50, help='Number of trees')
        parser.add_argument('--max_depth', type=int, default=3, help='Max depth')
        parser.add_argument('--sample_idx', type=int, default=0, help='Sample index for explanation')

        args = parser.parse_args()

        setup_fonts()

        # Load data
        data = DataLoader.load_data(args.input_file, args.target_column)
        X, y = data["X"], data["y"]
        feature_names = data["feature_names"]
        target_names = data["target_names"]
        dataset_name = os.path.basename(args.input_file).replace('.csv', '')

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=args.test_size,
                                                            random_state=args.random_state,
                                                            stratify=y if args.task == "classification" else None)

        # Train model
        model_params = {"n_estimators": args.n_estimators, "max_depth": args.max_depth,
                        "random_state": args.random_state, "n_jobs": -1}
        model = ModelTrainer.train_model(X_train, y_train, task=args.task, **model_params)
        # Evaluate model
        model_metrics = ModelTrainer.evaluate_model(model, X_test, y_test, task=args.task)

        # SHAP analysis
        analyzer = SHAPAnalyzer(model, X_train, task=args.task, feature_names=feature_names)
        plots = analyzer.generate_basic_plots(X_test, y_test, feature_names, target_names, args.sample_idx)
        logging.info("plots keys:%s", plots.keys())
        logging.info("plots keys:%s", plots.keys())
        if not plots:
            plots = {"empty": {
                "title": "No Plots",
                "content": "",
                "description": "No SHAP plots were generated",
                "type": "text"
            }}

        # Generate report
        output_path = HTMLReportGenerator.generate_report(
            plots,
            args.output,
            task=args.task,
            dataset_name=dataset_name,
            model_metrics=model_metrics
        )

        logging.info(f"Analysis completed: {os.path.abspath(output_path)}")

    except Exception as e:
        logging.info(f"SHAP analysis failed: {str(e)}")
        traceback.print_exc()
        raise


if __name__ == "__main__":
    main()