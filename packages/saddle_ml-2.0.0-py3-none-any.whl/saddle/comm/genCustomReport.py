import sys

sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')
import json
import pandas as pd
from jinja2 import Environment, FileSystemLoader
from datetime import datetime
import os
from typing import Dict, List, Any
import argparse
import json
from pathlib import Path
import logging

class InlineReportGenerator:
    def __init__(self, template_path: str, output_filepath: str = "reports.html"):
        """初始化内联报表生成器"""
        self.template = self._load_template(template_path)
        self.data = self._load_data()
        self.env = self._init_jinja_env()
        self.output_filepath = output_filepath

    def _load_template(self, template_path: str) -> Dict:
        """加载JSON模板"""
        try:
            if not os.path.exists(template_path):
                raise FileNotFoundError(f"模板文件不存在: {template_path}")
            with open(template_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            raise RuntimeError(f"加载模板失败: {str(e)}")

    def _load_data(self) -> pd.DataFrame:
        """加载CSV数据源"""
        metadata = self.template.get('metadata', {})
        data_path = metadata.get('filePath', '')

        if not data_path:
            raise ValueError("模板metadata中未配置filePath（数据文件路径）")

        # 处理相对路径/绝对路径
        abs_data_path = data_path if os.path.isabs(data_path) else os.path.join(os.getcwd(), data_path)
        if not os.path.exists(abs_data_path):
            raise FileNotFoundError(f"数据文件不存在: {abs_data_path}")

        try:
            return pd.read_csv(abs_data_path).head(20)
        except Exception as e:
            raise RuntimeError(f"读取CSV数据失败: {str(e)}")

    def _init_jinja_env(self) -> Environment:
        """初始化Jinja2环境"""
        preview_config = self.template.get('preview', {})
        jinja2_config = preview_config.get('jinja2Config', {})

        # 处理基础模板路径
        base_template_path = jinja2_config.get('baseTemplatePath', 'templates/base_report.html')

        # 检查基础模板是否存在
        if not os.path.isfile(base_template_path):
            default_path = os.path.join(os.getcwd(), 'templates', 'base_report.html')
            if os.path.isfile(default_path):
                base_template_path = default_path
                print(f"警告：使用默认模板路径: {base_template_path}")
            else:
                template_dir = os.path.join(os.getcwd(), 'templates')
                charts_dir = os.path.join(template_dir, 'charts')
                os.makedirs(charts_dir, exist_ok=True)
                base_template_path = os.path.join(template_dir, 'base_report.html')
                print(f"警告：创建默认模板目录: {template_dir}")

        # 获取模板目录
        template_dir = os.path.dirname(os.path.abspath(base_template_path))
        print(f"模板目录: {template_dir}")

        return Environment(
            loader=FileSystemLoader(template_dir),
            autoescape=True,
            trim_blocks=True,
            lstrip_blocks=True
        )

    def _load_inline_resources(self):
        """加载并内联所有静态资源（修复HTML转义问题）"""
        resources = {
            'css': {},
            'js': {}
        }

        # 加载CSS文件
        css_files = ['font-awesome.min.css', 'tailwind.css']
        for css_file in css_files:
            css_path = Path('static/css') / css_file
            if css_path.exists():
                with open(css_path, 'r', encoding='utf-8') as f:
                    # CSS内容直接存储，不需要额外处理
                    resources['css'][css_file] = f.read()
                print(f"✅ 内联CSS: {css_file}")
            else:
                print(f"⚠️  CSS文件不存在: {css_path}")

        # 加载JS文件 - 关键修复：使用二进制读取避免编码问题
        js_files = ['chart.umd.min.js', 'chartjs-plugin-annotation.min.js', 'echarts.min.js']
        for js_file in js_files:
            js_path = Path('static/js') / js_file
            if js_path.exists():
                try:
                    # 先尝试UTF-8读取
                    with open(js_path, 'r', encoding='utf-8') as f:
                        js_content = f.read()
                    resources['js'][js_file] = js_content
                    print(f"✅ 内联JS: {js_file} (UTF-8)")
                except UnicodeDecodeError:
                    # 如果UTF-8失败，尝试Latin-1
                    try:
                        with open(js_path, 'r', encoding='latin-1') as f:
                            js_content = f.read()
                        resources['js'][js_file] = js_content
                        print(f"✅ 内联JS: {js_file} (Latin-1)")
                    except Exception as e:
                        print(f"❌ JS文件读取失败 {js_file}: {str(e)}")
                        # 创建占位符
                        resources['js'][js_file] = f"console.error('JS资源加载失败: {js_file}');"
            else:
                print(f"⚠️  JS文件不存在: {js_path}")
                # 创建占位符
                resources['js'][js_file] = f"console.error('JS文件缺失: {js_file}');"

        return resources

    def _process_data(self, block: Dict) -> Dict[str, Any]:
        """根据图表类型动态处理数据"""
        block_type = block.get('type', 'unknown')
        config = block.get('config', {})

        # 图表处理器映射
        processors = {
            'quadrant': self._process_quadrant,
            'bar': self._process_bar,
            'line': self._process_line,
            'table': self._process_table,
            'pie': self._process_pie,
            'radar': self._process_radar,
            'gantt': self._process_gantt,
            'kline': self._process_kline,
            'wafermap': self._process_wafermap,
        }

        if block_type not in processors:
            print(f"警告：未支持的图表类型 '{block_type}'，使用默认表格展示")
            return self._process_table(block, config)

        return processors[block_type](block, config)

    def _apply_aggregation(self, data: pd.DataFrame, x_axis: str, y_axis: str, agg_type: str) -> pd.DataFrame:
        """应用数据聚合"""
        if not x_axis or not y_axis or x_axis not in data.columns or y_axis not in data.columns:
            return pd.DataFrame()

        agg_map = {
            'mean': 'mean', 'sum': 'sum', 'count': 'count',
            'max': 'max', 'min': 'min', 'median': 'median'
        }
        agg_func = agg_map.get(agg_type.lower(), 'mean')

        try:
            return data.groupby(x_axis)[y_axis].agg(agg_func).reset_index()
        except Exception as e:
            print(f"聚合数据失败（{agg_func}）：{str(e)}，返回原始数据")
            return data[[x_axis, y_axis]].dropna()

    def _apply_sampling(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """应用数据采样"""
        if not config.get('sampling', False) or data.empty:
            return data

        sample_size = config.get('sampleSize', 1000)
        if len(data) <= sample_size:
            return data

        try:
            return data.sample(sample_size, random_state=42)
        except Exception as e:
            print(f"采样数据失败：{str(e)}，返回全部数据")
            return data

    def _get_default_dimension(self, exclude: List[str] = None, categorical: bool = False) -> str:
        """获取默认字段"""
        exclude = exclude or []
        data_cols = self.data.columns.tolist()

        available_cols = [col for col in data_cols if col not in exclude]
        if not available_cols:
            return data_cols[0] if data_cols else 'unknown'

        for col in available_cols:
            if categorical and self.data[col].dtype == 'object':
                return col
            if pd.api.types.is_numeric_dtype(self.data[col]):
                return col

        return available_cols[0]

    def _clean_nan_values(self, data: pd.DataFrame) -> pd.DataFrame:
        """清理数据中的 NaN 值"""
        nan_count = data.isna().sum()
        if nan_count.sum() > 0:
            print("⚠️  数据中存在 NaN 值：")
            print(nan_count[nan_count > 0])

        cleaned_data = data.dropna()
        print(f"✅ 数据清理完成：{len(cleaned_data)}行（原始{len(data)}行）")

        if len(cleaned_data) == 0:
            raise ValueError("❌ 清理后无有效数据，请检查原始数据")
        return cleaned_data

    # 各图表数据处理器（保持原有逻辑）
    def _process_wafermap(self, block: Dict, config: Dict) -> Dict[str, Any]:
        """wafermap数据处理"""
        try:
            wafer_id_field = config.get('waferIdField', 'wafer_id')
            wafer_x_field = config.get('waferXField', 'x_coordinate')
            wafer_y_field = config.get('waferYField', 'y_coordinate')
            wafer_value_field = config.get('waferValueField', 'measurement_value')
            defect_type_field = config.get('defectTypeField', 'defect_type')

            required_fields = [wafer_id_field, wafer_x_field, wafer_y_field, wafer_value_field, defect_type_field]
            missing_fields = [f for f in required_fields if f not in self.data.columns]

            if missing_fields:
                available_fields = self.data.columns.tolist()
                raise ValueError(f"晶圆图缺少必要字段：{missing_fields}。可用字段：{available_fields}")

            wafer_data = self.data[required_fields].copy()

            for field in [wafer_x_field, wafer_y_field, wafer_value_field, defect_type_field]:
                wafer_data[field] = pd.to_numeric(wafer_data[field], errors='coerce')

            wafer_data = wafer_data.dropna(subset=required_fields)
            wafer_ids = wafer_data[wafer_id_field].unique().tolist()

            max_points = 2000
            if len(wafer_data) > max_points:
                wafer_data = wafer_data.sample(max_points, random_state=42)

            x_min = float(wafer_data[wafer_x_field].min())
            x_max = float(wafer_data[wafer_x_field].max())
            y_min = float(wafer_data[wafer_y_field].min())
            y_max = float(wafer_data[wafer_y_field].max())

            defect_stats = wafer_data[defect_type_field].value_counts().to_dict()
            total_dies = len(wafer_data)

            display_data = []
            for _, row in wafer_data.iterrows():
                display_data.append({
                    'wafer_id': row[wafer_id_field],
                    'x': float(row[wafer_x_field]),
                    'y': float(row[wafer_y_field]),
                    'value': float(row[wafer_value_field]),
                    'defect_type': int(row[defect_type_field])
                })

            return {
                'type': 'wafermap',
                'wafer_id_field': wafer_id_field,
                'wafer_x_field': wafer_x_field,
                'wafer_y_field': wafer_y_field,
                'wafer_value_field': wafer_value_field,
                'defect_type_field': defect_type_field,
                'wafer_diameter': config.get('waferDiameter', 300),
                'show_grid': config.get('waferShowGrid', True),
                'show_axis': config.get('waferShowAxis', True),
                'color_scheme': config.get('waferColorScheme', 'standard'),
                'wafer_ids': wafer_ids,
                'data': display_data,
                'total_dies': total_dies,
                'defect_stats': defect_stats,
                'coord_range': {
                    'x_min': x_min,
                    'x_max': x_max,
                    'y_min': y_min,
                    'y_max': y_max
                },
                'config': config
            }

        except Exception as e:
            print(f"Error processing wafermap: {str(e)}")
            import traceback
            traceback.print_exc()
            raise

    def _process_kline(self, block: Dict, config: Dict) -> Dict[str, Any]:
        """K线图数据处理"""
        time_field = config.get('klineTimeField', 'date')
        open_field = config.get('klineOpen', 'open')
        close_field = config.get('klineClose', 'close')
        high_field = config.get('klineHigh', 'high')
        low_field = config.get('klineLow', 'low')
        sampling = config.get('sampling', True)
        sample_size = config.get('sampleSize', 1000)

        required_fields = [time_field, open_field, close_field, high_field, low_field]
        missing_fields = [f for f in required_fields if f not in self.data.columns]
        if missing_fields:
            raise ValueError(f"K线图缺少必要字段：{', '.join(missing_fields)}")

        kline_data = self.data[required_fields].copy()

        price_fields = [open_field, close_field, high_field, low_field]
        for field in price_fields:
            kline_data[field] = pd.to_numeric(kline_data[field], errors='coerce')
            kline_data[field] = kline_data[field].fillna(method='ffill').fillna(method='bfill')

        date_format = "%Y-%m-%d"
        if pd.api.types.is_datetime64_any_dtype(kline_data[time_field]):
            kline_data[time_field] = kline_data[time_field].dt.strftime(date_format)
        else:
            try:
                kline_data[time_field] = pd.to_datetime(
                    kline_data[time_field], errors='coerce'
                ).dt.strftime(date_format)
            except Exception as e:
                print(f"警告：时间字段 {time_field} 转换失败，使用原始值：{str(e)}")

        kline_data = kline_data.dropna(subset=required_fields)
        kline_data['_sort_date'] = pd.to_datetime(kline_data[time_field])
        kline_data = kline_data.sort_values(by='_sort_date').drop(columns=['_sort_date'])

        if sampling and len(kline_data) > sample_size:
            kline_data = self._apply_sampling(kline_data, config)

        time_range = config.get('klineTimeRange', 'auto')
        if time_range == 'auto' and not kline_data.empty:
            dates = pd.to_datetime(kline_data[time_field], errors='coerce')
            min_date = dates.min()
            max_date = dates.max()
            time_range = {
                'start': min_date.strftime(date_format),
                'end': max_date.strftime(date_format)
            }
        else:
            time_range = {
                'start': time_range.get('start', '2024-01-01'),
                'end': time_range.get('end', '2024-12-31')
            }

        formatted_data = []
        for _, row in kline_data.iterrows():
            formatted_data.append({
                'time': row[time_field],
                'value': [
                    float(row[open_field]),
                    float(row[close_field]),
                    float(row[low_field]),
                    float(row[high_field])
                ]
            })

        return {
            'type': 'kline',
            'klineTimeField': time_field,
            'klineOpen': open_field,
            'klineClose': close_field,
            'klineHigh': high_field,
            'klineLow': low_field,
            'sampling': sampling,
            'sampleSize': sample_size,
            'time_range': time_range,
            'data': formatted_data,
            'data_count': len(formatted_data),
            'config': config
        }

    def _process_gantt(self, block: Dict, config: Dict) -> Dict[str, Any]:
        """甘特图数据处理"""
        task_field = config.get('ganttTaskField', 'Task Name')
        start_field = config.get('ganttStartField', 'Start Date')
        end_field = config.get('ganttEndField', 'End Date')
        progress_field = config.get('ganttProgressField', 'Progress')
        show_progress = config.get('ganttShowProgress', True)
        show_labels = config.get('ganttShowLabels', True)
        bar_height = config.get('ganttBarHeight', 20)

        required_fields = [task_field, start_field, end_field]
        missing_fields = [f for f in required_fields if f not in self.data.columns]
        if missing_fields:
            raise ValueError(f"甘特图缺少必要字段：{', '.join(missing_fields)}")

        gantt_data = self.data[required_fields].copy()
        if show_progress and progress_field not in gantt_data.columns:
            gantt_data[progress_field] = 0.0
        elif show_progress:
            gantt_data[progress_field] = gantt_data[progress_field].fillna(0.0)
            gantt_data[progress_field] = gantt_data[progress_field].clip(0.0, 1.0)

        date_format = "%Y-%m-%d"
        for date_field in [start_field, end_field]:
            if pd.api.types.is_datetime64_any_dtype(gantt_data[date_field]):
                gantt_data[date_field] = gantt_data[date_field].dt.strftime(date_format)
            else:
                try:
                    gantt_data[date_field] = pd.to_datetime(
                        gantt_data[date_field], errors='coerce'
                    ).dt.strftime(date_format)
                except Exception as e:
                    print(f"警告：日期字段 {date_field} 转换失败，使用原始值：{str(e)}")

        gantt_data = gantt_data.dropna(subset=[task_field, start_field, end_field])
        gantt_data = gantt_data.drop_duplicates(subset=[task_field])
        gantt_data = self._apply_sampling(gantt_data, config)

        time_range = config.get('ganttTimeRange', 'auto')
        if time_range == 'auto' and not gantt_data.empty:
            start_dates = pd.to_datetime(gantt_data[start_field], errors='coerce')
            end_dates = pd.to_datetime(gantt_data[end_field], errors='coerce')
            min_date = start_dates.min() - pd.Timedelta(days=1)
            max_date = end_dates.max() + pd.Timedelta(days=1)
            time_range = {
                'start': min_date.strftime(date_format),
                'end': max_date.strftime(date_format)
            }
        else:
            time_range = {
                'start': time_range.get('start', '2024-01-01'),
                'end': time_range.get('end', '2024-12-31')
            }

        color_mode = config.get('ganttColorMode', 'progress')
        gantt_data['task_color'] = gantt_data.apply(
            lambda row: self._get_gantt_color(row, color_mode, progress_field),
            axis=1
        )

        return {
            'type': 'gantt',
            'task_field': task_field,
            'start_field': start_field,
            'end_field': end_field,
            'progress_field': progress_field if show_progress else None,
            'show_progress': show_progress,
            'show_labels': show_labels,
            'bar_height': bar_height,
            'time_range': time_range,
            'data': gantt_data.to_dict('records'),
            'total_tasks': len(gantt_data),
            'total_rows': len(gantt_data),
            'config': config
        }

    def _get_gantt_color(self, row: pd.Series, color_mode: str, progress_field: str) -> str:
        """生成甘特图任务条颜色"""
        if color_mode == 'progress' and progress_field in row:
            progress = row[progress_field]
            hue = int(progress * 120)
            return f"hsl({hue}, 70%, 50%)"
        return "hsl(210, 70%, 50%)"

    def _process_quadrant(self, block: Dict, config: Dict) -> Dict:
        """象限图数据处理"""
        dim_fields = config.get('dimFields', [])
        value_fields = config.get('valueFields', [])

        if len(dim_fields) < 2:
            raise ValueError("散点图需要至少2个dimFields（X轴1和X轴2）")
        if not value_fields:
            raise ValueError("散点图需要至少1个valueFields（气泡大小）")

        x_dim1, x_dim2 = dim_fields[0], dim_fields[1]
        y_dim = value_fields[0]

        processed_data = self.data[[x_dim1, x_dim2, y_dim]].copy()
        processed_data = self._clean_nan_values(processed_data)
        processed_data = self._apply_sampling(processed_data, config)

        return {
            'type': 'quadrant',
            'data': processed_data.to_dict('records'),
            'x_dim1': x_dim1,
            'x_dim2': x_dim2,
            'y_dim': y_dim,
            'config': config
        }

    def _process_bar(self, block: Dict, config: Dict) -> Dict:
        """柱状图数据处理"""
        dim_fields = config.get('dimFields', [])
        value_fields = config.get('valueFields', [])

        x_dim = dim_fields[0] if (dim_fields and len(dim_fields) > 0) else self._get_default_dimension()
        y_dims = value_fields if value_fields else [self._get_default_dimension(exclude=[x_dim])]

        series_data = []
        for y_dim in y_dims:
            agg_type = config.get('aggregations', {}).get(y_dim, 'mean')
            data = self._apply_aggregation(self.data, x_dim, y_dim, agg_type)
            data = self._apply_sampling(data, config)

            series_data.append({
                'name': y_dim,
                'data': data.to_dict('records')
            })

        return {
            'type': 'bar',
            'x_dim': x_dim,
            'series': series_data,
            'config': config
        }

    def _process_line(self, block: Dict, config: Dict) -> Dict:
        """折线图数据处理"""
        line_data = self._process_bar(block, config)
        line_data['type'] = 'line'
        return line_data

    def _process_table(self, block: Dict, config: Dict) -> Dict:
        """表格数据处理"""
        columns = []
        if config.get('xAxis'):
            columns.append(config['xAxis'])
        columns.extend(config.get('yAxis', []))

        if not columns:
            columns = self.data.columns.tolist()

        valid_columns = [col for col in columns if col in self.data.columns]
        if not valid_columns:
            valid_columns = self.data.columns.tolist()

        processed_data = self.data[valid_columns].copy()
        processed_data = self._apply_sampling(processed_data, config)

        for col in valid_columns:
            if pd.api.types.is_numeric_dtype(processed_data[col]):
                processed_data[col] = processed_data[col].round(2)

        return {
            'type': 'table',
            'columns': valid_columns,
            'data': processed_data.to_dict('records'),
            'total_rows': len(processed_data)
        }

    def _process_pie(self, block: Dict, config: Dict) -> Dict:
        """饼图数据处理"""
        dim_fields = config.get('dimFields', [])
        value_fields = config.get('valueFields', [])

        categorydim = dim_fields[0] if (dim_fields and len(dim_fields) > 0) else self._get_default_dimension(
            categorical=True)
        value_dim = value_fields[0] if (value_fields and len(value_fields) > 0) else self._get_default_dimension(
            exclude=[categorydim])
        agg_type = config.get('aggregations', {}).get(value_dim, 'sum')

        processed_data = self._apply_aggregation(self.data, categorydim, value_dim, agg_type)
        if not processed_data.empty and value_dim in processed_data.columns:
            processed_data = processed_data[processed_data[value_dim] > 0]

        return {
            'type': 'pie',
            'categorydim': categorydim,
            'valuedim': value_dim,
            'data': processed_data.to_dict('records'),
            'total_items': len(processed_data)
        }

    def _process_radar(self, block: Dict, config: Dict) -> Dict:
        """雷达图数据处理"""
        dim_fields = config.get('dimFields', [])
        value_fields = config.get('valueFields', [])
        agg_config = config.get('aggregations', {})
        sampling = config.get('sampling', True)
        sample_size = config.get('sampleSize', 1000)

        if not dim_fields:
            raise ValueError("❌ 配置中未指定dimFields（雷达图维度字段）")
        dim_field = dim_fields[0]

        if not value_fields:
            raise ValueError("❌ 配置中未指定valueFields（雷达图数据系列）")

        valid_value_fields = []
        for vf in value_fields:
            if vf not in self.data.columns:
                print(f"⚠️  指标字段「{vf}」不存在，已跳过")
                continue
            if not pd.api.types.is_numeric_dtype(self.data[vf]):
                print(f"⚠️  指标字段「{vf}」不是数值类型，已跳过")
                continue
            valid_value_fields.append(vf)
        if not valid_value_fields:
            raise ValueError("❌ 无有效指标字段（valueFields需包含至少1个数值字段）")
        value_fields = valid_value_fields

        all_columns = self.data.columns.tolist()
        if dim_field not in all_columns:
            raise ValueError(f"❌ 维度字段「{dim_field}」不存在于数据中（数据列：{all_columns}）")

        try:
            agg_dict = {}
            for vf in value_fields:
                agg_type = agg_config.get(vf, 'mean').lower()
                agg_dict[vf] = self._get_aggregator(agg_type)

            aggregated_data = self.data.groupby(dim_field, as_index=False).agg(agg_dict)
            aggregated_data = aggregated_data.rename(columns={dim_field: "radar_dimension"})

            aggregated_data["radar_dimension"] = aggregated_data["radar_dimension"].fillna("未知维度")
            if pd.api.types.is_numeric_dtype(aggregated_data["radar_dimension"]):
                aggregated_data["radar_dimension"] = aggregated_data["radar_dimension"].astype(str)

            if sampling and len(aggregated_data) > sample_size:
                aggregated_data = aggregated_data.head(sample_size).reset_index(drop=True)

            for vf in value_fields:
                aggregated_data[vf] = aggregated_data[vf].fillna(0).round(2)

            series_data = []
            for vf in value_fields:
                series_data.append({
                    "name": vf,
                    "data": aggregated_data[vf].tolist(),
                    "agg_type": agg_config.get(vf, 'mean').lower()
                })

            return {
                'type': 'radar',
                'radardimensions': aggregated_data["radar_dimension"].tolist() if not aggregated_data.empty else [],
                'series': series_data if series_data else [],
                "series_key": value_fields,
                'data_raw': aggregated_data.to_dict('records') if not aggregated_data.empty else [],
                'agg_info': {vf: agg_config.get(vf, 'mean') for vf in value_fields} if value_fields else {},
                'total_dimensions': len(aggregated_data) if not aggregated_data.empty else 0,
                'total_series': len(value_fields) if value_fields else 0,
                'config': config or {}
            }

        except Exception as e:
            raise RuntimeError(f"❌ 按{dim_field}分组聚合失败：{str(e)}") from e

    def _get_aggregator(self, agg_type: str):
        """根据聚合类型返回pandas支持的聚合函数"""
        agg_map = {
            'mean': 'mean', 'sum': 'sum', 'count': 'count',
            'max': 'max', 'min': 'min', 'median': 'median'
        }
        return agg_map.get(agg_type.lower(), 'mean')

    def generate(self) -> str:
        """生成内联资源的静态HTML报表"""
        try:
            # 处理所有区块数据
            processed_structure = []
            for row in self.template.get('structure', []):
                processed_row = []
                for block in row:
                    try:
                        processed_block = {**block, **self._process_data(block)}
                        processed_row.append(processed_block)
                    except Exception as e:
                        print(f"处理区块 {block.get('id', '未知ID')} 失败：{str(e)}")
                        processed_row.append({
                            **block,
                            'error': f"区块加载失败：{str(e)}",
                            'type': 'error'
                        })
                processed_structure.append(processed_row)

            output_path = self.output_filepath

            # 加载基础模板
            preview_config = self.template.get('preview', {})
            jinja2_config = preview_config.get('jinja2Config', {})
            base_template = os.path.basename(jinja2_config.get('baseTemplatePath', 'base_report.html'))

            try:
                template = self.env.get_template(base_template)
            except Exception as e:
                print(f"加载模板 '{base_template}' 失败，使用默认模板：{str(e)}")
                template = self.env.get_template('base_report.html')

            # 加载并内联所有静态资源
            print("📦 加载静态资源...")
            inline_resources = self._load_inline_resources()

            # 准备模板渲染数据
            render_context = {
                'report_title': self.template.get('metadata', {}).get('templateName', '数据报表'),
                'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'current_year': datetime.now().year,
                'structure': processed_structure,
                'preview': preview_config,
                'total_blocks': sum(len(row) for row in processed_structure),
                'metadata': self.template.get('metadata', {}),
                'inline_resources': inline_resources,  # 传递内联资源
                'enable_inline': True  # 启用内联标志
            }

            # 渲染并保存HTML
            html_content = template.render(render_context)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)

            print(f"🎉 内联报表生成成功！路径：{output_path}")
            print("📊 报表特性：")
            print("   ✅ 所有CSS/JS资源已内联")
            print("   ✅ 单个HTML文件，无需额外依赖")
            print("   ✅ 完全离线可用")

            return output_path

        except Exception as e:
            import traceback
            traceback.print_exc()
            raise RuntimeError(f"生成报表失败：{str(e)}")


class FixedInlineReportGenerator(InlineReportGenerator):
    """修复内联资源转义问题的报表生成器"""

    def generate(self) -> str:
        """生成内联资源的静态HTML报表（修复版本）"""
        try:
            # 处理所有区块数据
            processed_structure = []
            for row in self.template.get('structure', []):
                processed_row = []
                for block in row:
                    try:
                        processed_block = {**block, **self._process_data(block)}
                        processed_row.append(processed_block)
                    except Exception as e:
                        print(f"处理区块 {block.get('id', '未知ID')} 失败：{str(e)}")
                        processed_row.append({
                            **block,
                            'error': f"区块加载失败：{str(e)}",
                            'type': 'error'
                        })
                processed_structure.append(processed_row)

            output_path = self.output_filepath

            # 加载基础模板
            preview_config = self.template.get('preview', {})
            jinja2_config = preview_config.get('jinja2Config', {})
            base_template = os.path.basename(jinja2_config.get('baseTemplatePath', 'base_report.html'))

            try:
                template = self.env.get_template(base_template)
            except Exception as e:
                print(f"加载模板 '{base_template}' 失败，使用默认模板：{str(e)}")
                template = self.env.get_template('base_report.html')

            # 加载并内联所有静态资源
            print("📦 加载静态资源...")
            inline_resources = self._load_inline_resources()

            # 准备模板渲染数据
            render_context = {
                'report_title': self.template.get('metadata', {}).get('templateName', '数据报表'),
                'generated_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'current_year': datetime.now().year,
                'structure': processed_structure,
                'preview': preview_config,
                'total_blocks': sum(len(row) for row in processed_structure),
                'metadata': self.template.get('metadata', {}),
                'inline_resources': inline_resources,
                'enable_inline': True
            }

            # 渲染并保存HTML
            html_content = template.render(render_context)

            # 修复：手动处理JS内联的转义问题
            html_content = self._fix_js_inline(html_content)

            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)

            print(f"🎉 内联报表生成成功！路径：{output_path}")
            print("📊 报表特性：")
            print("   ✅ 所有CSS/JS资源已内联")
            print("   ✅ 单个HTML文件，无需额外依赖")
            print("   ✅ 完全离线可用")

            return output_path

        except Exception as e:
            import traceback
            traceback.print_exc()
            raise RuntimeError(f"生成报表失败：{str(e)}")

    def _fix_js_inline(self, html_content: str) -> str:
        """修复JS内联的转义问题"""
        import re

        # 修复 Chart.js 内联
        chartjs_pattern = r'<script>\s*/\*\s*chart\.umd\.min\.js\s*\*/(.*?)</script>'

        def replace_chartjs(match):
            js_content = match.group(1)
            # 清理可能的转义字符
            js_content = js_content.replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')
            return f'<script>\n{js_content}\n</script>'

        html_content = re.sub(chartjs_pattern, replace_chartjs, html_content, flags=re.DOTALL)

        # 修复其他JS文件的内联
        js_patterns = [
            ('chartjs-plugin-annotation.min.js', r'/\*\s*chartjs-plugin-annotation\.min\.js\s*\*/(.*?)</script>'),
            ('echarts.min.js', r'/\*\s*echarts\.min\.js\s*\*/(.*?)</script>')
        ]

        for js_name, pattern in js_patterns:
            def replacer(match):
                js_content = match.group(1)
                js_content = js_content.replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')
                return f'{js_content}</script>'

            html_content = re.sub(pattern, replacer, html_content, flags=re.DOTALL)

        return html_content

def set_args():
    parser = argparse.ArgumentParser(description="生成内联资源报表 HTML 文件")
    parser.add_argument("--template", type=str, required=False, default='./Charts-08125456_jcfg.json',
                        help="模板 JSON 文件的完整路径")
    parser.add_argument("--output_filepath", type=str, required=False, default='./reports/final.html',
                        help="生成的 HTML 文件完整路径")
    args = parser.parse_args()
    return args


if __name__ == '__main__':
    args = set_args()
    try:
        generator = FixedInlineReportGenerator(template_path=args.template, output_filepath=args.output_filepath)
        generator.generate()
    except Exception as e:
        import traceback

        print("error:%s", traceback.format_exc())
        logging.info("error:%s",traceback.format_exc())

        exit(1)