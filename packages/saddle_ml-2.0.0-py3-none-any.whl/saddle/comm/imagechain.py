#!/usr/bin/env python3
"""
Image Processing Chain
"""

import os
import sys
import json
import traceback

import cv2
import numpy as np
import argparse
from pathlib import Path
import logging
from typing import Dict, List, Any, Tuple, Union

# 尝试导入日志工具
try:
    from .utils import set_logging
except ImportError:
    # 如果导入失败，创建简单的日志设置函数
    def set_logging(log_dir='log', file_name='task_dispatch', mode='dev'):
        """简单的日志设置函数"""
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        log_file = os.path.join(log_dir, f"{file_name}.log")

        logging.basicConfig(
            level=logging.DEBUG if mode == 'dev' else logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler(sys.stdout)
            ]
        )
        return logging.getLogger(__name__)

imageActions = {
    "gaussian_blur": {
        "name": "高斯模糊", "description": "应用高斯模糊模糊滤波器进行图像平滑处理", "category": "preprocessing",
        "opencv_function": "cv2.GaussianBlur", "input_type": "image:np.ndarray|list:image:np.ndarray",
        "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "kernel_size": {"type": "odd_int", "default": 3, "min": 1, "max": 31, "description": "高斯核大小，必须是奇数"},
            "sigma_x": {"type": "float", "default": 0, "min": 0, "max": 10, "description": "X方向标准差"},
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"}
        }
    },
    "median_blur": {
        "name": "中值滤波", "description": "应用中值滤波器去除椒盐噪声", "category": "preprocessing",
        "opencv_function": "cv2.medianBlur", "input_type": "image:np.ndarray|list:image:np.ndarray",
        "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "kernel_size": {"type": "odd_int", "default": 3, "min": 3, "max": 31, "description": "孔径大小，必须是奇数"},
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"}
        }
    },
    "guided_filter": {
        "name": "导向滤波", "description": "平滑纹理同时保留边缘，比双边滤波更细腻",
        "input_type": "image:np.ndarray|list:image:np.ndarray", "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"},
            "radius": {"type": "int", "default": 5, "min": 1, "max": 21, "description": "滤波半径"},
            "eps": {"type": "float", "default": 0.01, "min": 0.001, "max": 1.0, "description": "平滑系数"}
        }
    },
    "msrcr": {
        "name": "多尺度Retinex增强", "description": "改善光照不均，增强局部对比度（自然不刺眼）",
        "parameters": {
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"},
            "sigma_list": {"type": "list:int", "default": [15, 80, 250], "description": "多尺度高斯核大小"}
        }
    },
    "fast_nl_means_denoising_colored": {
        "name": "彩色图像非局部均值去噪", "description": "针对彩色图像的高效去噪算法，保留细节的同时去除高斯噪声和斑点噪声（比普通高斯滤波效果更好）",
        "category": "denoising", "opencv_function": "cv2.fastNlMeansDenoisingColored",
        "input_type": "image:np.ndarray|list:image:np.ndarray", "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...；彩色图默认处理所有通道）"},
            "h": {"type": "float", "default": 10.0, "min": 1.0, "max": 50.0, "step": 0.5, "description": "控制去噪强度（值越大去噪效果越强，但可能丢失细节；建议5-20）"},
            "h_color": {"type": "float", "default": 10.0, "min": 1.0, "max": 50.0, "step": 0.5, "description": "彩色通道去噪强度（与h配合使用，通常与h保持一致）"},
            "template_window_size": {"type": "odd_int", "default": 7, "min": 3, "max": 15, "description": "模板窗口大小（用于寻找相似区域，建议5-9）"},
            "search_window_size": {"type": "odd_int", "default": 21, "min": 11, "max": 41, "description": "搜索窗口大小（范围越大去噪越彻底，但速度越慢；建议15-31）"}
        }
    },
    "laplacian_edge": {
        "name": "拉普拉斯边缘增强", "description": "通过拉普拉斯算子提取图像细节边缘，并与原图叠加，增强细微纹理（如文字、纹路）",
        "category": "enhancement", "opencv_function": "cv2.Laplacian + cv2.addWeighted",
        "input_type": "image:np.ndarray|list:image:np.ndarray", "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...；建议对亮度通道单独增强）"},
            "ksize": {"type": "odd_int", "default": 3, "min": 3, "max": 7, "options": [3, 5, 7], "description": "拉普拉斯核大小（3=细边缘，7=粗边缘）"},
            "scale": {"type": "float", "default": 1.0, "min": 0.5, "max": 2.0, "step": 0.1, "description": "边缘强度缩放因子（值越大边缘越明显）"},
            "delta": {"type": "int", "default": 0, "min": 0, "max": 50, "description": "边缘像素值偏移量（增加亮度，避免边缘过暗）"}
        }
    },
    "bilateral_filter": {
        "name": "双边滤波", "description": "保持边缘的滤波方式", "category": "preprocessing",
        "opencv_function": "cv2.bilateralFilter", "input_type": "image:np.ndarray|list:image:np.ndarray",
        "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "d": {"type": "int", "default": 9, "min": 1, "max": 50, "description": "每个像素邻域的直径"},
            "sigma_color": {"type": "float", "default": 75, "min": 1, "max": 200, "description": "颜色空间的标准差"},
            "sigma_space": {"type": "float", "default": 75, "min": 1, "max": 200, "description": "坐标空间的标准差"},
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"}
        }
    },
    "binary_threshold": {
        "name": "二值化阈值", "description": "全局固定阈值二值化", "category": "thresholding",
        "opencv_function": "cv2.threshold", "input_type": "image:np.ndarray", "output_type": "image:np.ndarray",
        "parameters": {
            "thresh": {"type": "int", "default": 127, "min": 0, "max": 255, "description": "阈值"},
            "maxval": {"type": "int", "default": 255, "min": 0, "max": 255, "description": "最大值"},
            "type": {"type": "select", "options": ["THRESH_BINARY", "THRESH_BINARY_INV", "THRESH_TRUNC", "THRESH_TOZERO", "THRESH_TOZERO_INV"], "default": "THRESH_BINARY", "description": "阈值类型"}
        }
    },
    "adaptive_threshold": {
        "name": "自适应阈值", "description": "局部自适应阈值二值化", "category": "thresholding",
        "opencv_function": "cv2.adaptiveThreshold", "input_type": "image:np.ndarray", "output_type": "image:np.ndarray",
        "parameters": {
            "max_value": {"type": "int", "default": 255, "min": 0, "max": 255, "description": "分配给满足条件的像素的非零值"},
            "adaptive_method": {"type": "select", "options": ["ADAPTIVE_THRESH_MEAN_C", "ADAPTIVE_THRESH_GAUSSIAN_C"], "default": "ADAPTIVE_THRESH_MEAN_C", "description": "自适应方法"},
            "threshold_type": {"type": "select", "options": ["THRESH_BINARY", "THRESH_BINARY_INV"], "default": "THRESH_BINARY", "description": "阈值类型"},
            "block_size": {"type": "odd_int", "default": 11, "min": 3, "max": 51, "description": "像素邻域大小，必须是奇数"},
            "C": {"type": "int", "default": 2, "min": -50, "max": 50, "description": "从平均值或加权平均值中减去的常数"}
        }
    },
    "otsu_threshold": {
        "name": "大津阈值", "description": "自动计算最佳全局阈值", "category": "thresholding",
        "opencv_function": "cv2.threshold", "input_type": "image:np.ndarray", "output_type": "image:np.ndarray",
        "parameters": {"maxval": {"type": "int", "default": 255, "min": 0, "max": 255, "description": "最大值"}}
    },
    "erode": {
        "name": "腐蚀", "description": "形态学腐蚀操作", "category": "morphological",
        "opencv_function": "cv2.erode", "input_type": "image:np.ndarray|list:image:np.ndarray",
        "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "kernel_size": {"type": "int", "default": 3, "min": 1, "max": 21, "description": "结构元素大小"},
            "iterations": {"type": "int", "default": 1, "min": 1, "max": 10, "description": "腐蚀次数"},
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"}
        }
    },
    "dilate": {
        "name": "膨胀", "description": "形态学膨胀操作", "category": "morphological",
        "opencv_function": "cv2.dilate", "input_type": "image:np.ndarray|list:image:np.ndarray",
        "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "kernel_size": {"type": "int", "default": 3, "min": 1, "max": 21, "description": "结构元素大小"},
            "iterations": {"type": "int", "default": 1, "min": 1, "max": 10, "description": "膨胀次数"},
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"}
        }
    },
    "morph_open": {
        "name": "开运算", "description": "先腐蚀后膨胀，去除小物体", "category": "morphological",
        "opencv_function": "cv2.morphologyEx", "input_type": "image:np.ndarray|list:image:np.ndarray",
        "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "kernel_size": {"type": "int", "default": 3, "min": 1, "max": 21, "description": "结构元素大小"},
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"}
        }
    },
    "morph_close": {
        "name": "闭运算", "description": "先膨胀后腐蚀，填充小孔洞", "category": "morphological",
        "opencv_function": "cv2.morphologyEx", "input_type": "image:np.ndarray|list:image:np.ndarray",
        "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "kernel_size": {"type": "int", "default": 3, "min": 1, "max": 21, "description": "结构元素大小"},
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"}
        }
    },
    "canny_edge": {
        "name": "Canny边缘检测", "description": "Canny算法边缘检测", "category": "edge_detection",
        "opencv_function": "cv2.Canny", "input_type": "image:np.ndarray|list:image:np.ndarray",
        "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "threshold1": {"type": "int", "default": 50, "min": 0, "max": 255, "description": "第一个阈值"},
            "threshold2": {"type": "int", "default": 150, "min": 0, "max": 255, "description": "第二个阈值"},
            "aperture_size": {"type": "odd_int", "default": 3, "min": 3, "max": 7, "description": "Sobel算子大小"},
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"}
        }
    },
    "sobel_edge": {
        "name": "Sobel边缘检测", "description": "Sobel算子边缘检测", "category": "edge_detection",
        "opencv_function": "cv2.Sobel", "input_type": "image:np.ndarray|list:image:np.ndarray",
        "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "dx": {"type": "int", "default": 1, "min": 0, "max": 2, "description": "x方向导数阶数"},
            "dy": {"type": "int", "default": 0, "min": 0, "max": 2, "description": "y方向导数阶数"},
            "ksize": {"type": "odd_int", "default": 3, "min": 1, "max": 7, "description": "Sobel核大小"},
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"}
        }
    },
    "unsharp_mask": {
        "name": "USM锐化", "description": "使用非锐化掩模增强图像细节", "category": "enhancement",
        "input_type": "image:np.ndarray|list:image:np.ndarray", "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "strength": {"type": "float", "default": 1.5, "min": 0.5, "max": 3.0, "description": "锐化强度"},
            "blur_amount": {"type": "float", "default": 1.0, "min": 0.5, "max": 5.0, "description": "模糊程度"},
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"}
        }
    },
    "blob_detect": {
        "name": "斑点检测", "description": "连通区域分析和斑点检测", "category": "feature_detection",
        "opencv_function": "cv2.SimpleBlobDetector", "input_type": "image:np.ndarray", "output_type": "list,num:int",
        "parameters": {
            "min_threshold": {"type": "int", "default": 50, "min": 0, "max": 255, "description": "最小阈值"},
            "max_threshold": {"type": "int", "default": 220, "min": 0, "max": 255, "description": "最大阈值"},
            "min_area": {"type": "float", "default": 10, "min": 0, "max": 10000, "description": "最小斑点面积"},
            "max_area": {"type": "float", "default": 5000, "min": 0, "max": 100000, "description": "最大斑点面积"},
            "min_circularity": {"type": "float", "default": 0.1, "min": 0, "max": 1, "description": "最小圆度"},
            "min_convexity": {"type": "float", "default": 0.5, "min": 0, "max": 1, "description": "最小凸度"}
        }
    },
    "contour_detect": {
        "name": "轮廓检测", "description": "查找图像中的轮廓", "category": "feature_detection",
        "opencv_function": "cv2.findContours", "input_type": "image:np.ndarray", "output_type": "list,num:int,image:np.ndarray",
        "parameters": {
            "mode": {"type": "select", "options": ["RETR_EXTERNAL", "RETR_LIST", "RETR_CCOMP", "RETR_TREE"], "default": "RETR_EXTERNAL", "description": "轮廓检索模式"},
            "method": {"type": "select", "options": ["CHAIN_APPROX_NONE", "CHAIN_APPROX_SIMPLE"], "default": "CHAIN_APPROX_SIMPLE", "description": "轮廓近似方法"},
            "min_area": {"type": "float", "default": 100, "min": 0, "max": 100000, "description": "最小轮廓面积"}
        }
    },
    "color_space_convert": {
        "name": "颜色空间转换", "description": "转换图像颜色空间", "category": "color_processing",
        "opencv_function": "cv2.cvtColor", "input_type": "image:np.ndarray", "output_type": "image:np.ndarray",
        "parameters": {
            "code": {"type": "select", "options": ["BGR2GRAY", "BGR2HSV", "BGR2LAB", "HSV2BGR", "LAB2BGR"], "default": "BGR2GRAY", "description": "颜色转换代码"}
        }
    },
    "color_threshold": {
        "name": "颜色阈值", "description": "基于颜色范围的阈值分割", "category": "color_processing",
        "opencv_function": "cv2.inRange", "input_type": "image:np.ndarray", "output_type": "image:np.ndarray",
        "parameters": {
            "lower_H": {"type": "int", "default": 0, "min": 0, "max": 255, "description": "色调下限"},
            "lower_S": {"type": "int", "default": 0, "min": 0, "max": 255, "description": "饱和度下限"},
            "lower_V": {"type": "int", "default": 0, "min": 0, "max": 255, "description": "明度下限"},
            "upper_H": {"type": "int", "default": 180, "min": 0, "max": 255, "description": "色调上限"},
            "upper_S": {"type": "int", "default": 255, "min": 0, "max": 255, "description": "饱和度上限"},
            "upper_V": {"type": "int", "default": 255, "min": 0, "max": 255, "description": "明度上限"}
        }
    },
    "resize": {
        "name": "图像缩放", "description": "调整图像尺寸", "category": "geometric_transforms",
        "opencv_function": "cv2.resize", "input_type": "image:np.ndarray", "output_type": "image:np.ndarray",
        "parameters": {
            "width": {"type": "int", "default": 640, "min": 1, "max": 4096, "description": "目标宽度"},
            "height": {"type": "int", "default": 480, "min": 1, "max": 4096, "description": "目标高度"},
            "interpolation": {"type": "select", "options": ["INTER_NEAREST", "INTER_LINEAR", "INTER_CUBIC", "INTER_AREA"], "default": "INTER_LINEAR", "description": "插值方法"}
        }
    },
    "rotate": {
        "name": "图像旋转", "description": "旋转图像", "category": "geometric_transforms",
        "opencv_function": "cv2.rotate", "input_type": "image:np.ndarray", "output_type": "image:np.ndarray",
        "parameters": {"angle": {"type": "float", "default": 90, "min": -360, "max": 360, "description": "旋转角度"}}
    },
    "distance_measure": {
        "name": "距离测量", "description": "测量两点之间的距离", "category": "measurement_tools",
        "input_type": "image:np.ndarray,num:int,num:int,num:int,num:int", "output_type": "num:float",
        "parameters": {"pixel_to_mm_ratio": {"type": "float", "default": 1.0, "description": "像素到毫米的转换比例"}}
    },
    "angle_measure": {
        "name": "角度测量", "description": "测量三点形成的角度", "category": "measurement_tools",
        "input_type": "image:np.ndarray,num:int,num:int,num:int,num:int,num:int,num:int", "output_type": "num:float",
        "parameters": {}
    },
    "connected_component_count": {
        "name": "连通区域计数", "description": "计算二值图像中连通区域的数量", "category": "feature_detection",
        "opencv_function": "cv2.connectedComponentsWithStats", "input_type": "image:np.ndarray", "output_type": "num:int,image:np.ndarray",
        "parameters": {
            "connectivity": {"type": "int", "default": 8, "min": 4, "max": 8, "description": "连通性（4或8邻接）"},
            "min_area": {"type": "float", "default": 10, "min": 1, "max": 100000, "description": "最小区域面积阈值"}
        }
    },
    "histogram_equalize": {
        "name": "直方图均衡化", "description": "增强图像对比度", "category": "preprocessing",
        "opencv_function": "cv2.equalizeHist", "input_type": "image:np.ndarray|list:image:np.ndarray",
        "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {"channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"}}
    },
    "clahe": {
        "name": "限制对比度自适应直方图均衡化", "description": "增强图像对比度的同时避免细节丢失，适合处理明暗差异大的图像",
        "category": "preprocessing", "opencv_function": "cv2.createCLAHE + apply",
        "input_type": "image:np.ndarray|list:image:np.ndarray", "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"},
            "clip_limit": {"type": "float", "default": 2.0, "min": 0.1, "max": 10.0, "step": 0.1, "description": "对比度限制阈值（值越小，细节保留越好；值越大，对比度增强越明显）"},
            "grid_size": {"type": "int", "default": 8, "min": 2, "max": 32, "step": 2, "description": "图像分割的网格大小（N×N，需为偶数，值越小细节保留越精细）"}
        }
    },
    "split_channels": {
        "name": "通道拆分", "description": "拆分多通道图像为单通道列表（如BGR拆分为[B,G,R]）", "category": "color_processing",
        "input_type": "image:np.ndarray", "output_type": "list:image:np.ndarray", "parameters": {}
    },
    "merge_channels": {
        "name": "通道合并", "description": "将单通道列表合并为多通道图像（需保持拆分顺序）", "category": "color_processing",
        "input_type": "list:image:np.ndarray", "output_type": "image:np.ndarray", "parameters": {}
    },
    "fast_nl_means_denoising": {
        "name": "非局部均值去噪", "description": "高效去除高斯噪声和运动模糊，保留细节", "category": "preprocessing",
        "opencv_function": "cv2.fastNlMeansDenoising", "input_type": "image:np.ndarray", "output_type": "image:np.ndarray",
        "parameters": {
            "h": {"type": "float", "default": 10, "min": 1, "max": 30, "description": "控制滤波强度，值越大去噪越强但可能模糊细节"},
            "template_window_size": {"type": "odd_int", "default": 7, "min": 3, "max": 15, "description": "模板窗口大小（奇数），用于查找相似区域"},
            "search_window_size": {"type": "odd_int", "default": 21, "min": 11, "max": 41, "description": "搜索窗口大小（奇数），范围越大去噪效果越好但速度越慢"}
        }
    },
    "motion_blur_restore": {
        "name": "运动模糊修复（已知方向）", "description": "修复沿特定方向的运动模糊（需手动指定模糊方向和长度）",
        "input_type": "image:np.ndarray|list:image:np.ndarray", "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"},
            "angle": {"type": "float", "default": 0, "min": 0, "max": 180, "description": "模糊方向（度）"},
            "length": {"type": "int", "default": 15, "min": 5, "max": 50, "description": "模糊长度（像素）"}
        }
    },
    "blind_deconvolution": {
        "name": "盲去卷积（未知模糊核）", "description": "自动估计模糊核并修复运动模糊（对噪声敏感，建议先去噪）",
        "input_type": "image:np.ndarray|list:image:np.ndarray", "output_type": "image:np.ndarray|list:image:np.ndarray",
        "parameters": {
            "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1=全部通道，0=第一个通道...）"},
            "iterations": {"type": "int", "default": 30, "min": 10, "max": 100, "description": "迭代次数"}
        }
    },
    "haar_cascade_detect": {
        "name": "Haar级联检测", "description": "使用Haar特征检测目标（如人脸、眼睛），返回目标矩形坐标", "category": "detection",
        "opencv_function": "cv2.CascadeClassifier.detectMultiScale", "input_type": "image:np.ndarray", "output_type": "image:np.ndarray",
        "parameters": {
            "cascade_path": {"type": "str", "default": "haarcascade_frontalface_default.xml", "description": "Haar级联模型文件路径（需提前下载）"},
            "scale_factor": {"type": "float", "default": 1.1, "min": 1.01, "max": 1.5, "step": 0.01, "description": "检测窗口缩放比例"},
            "min_neighbors": {"type": "int", "default": 5, "min": 1, "max": 10, "description": "构成检测目标的相邻矩形最小数量（越大越严格）"},
            "min_size": {"type": "list:int", "default": [30, 30], "description": "目标最小尺寸（宽,高），小于此尺寸的目标不检测"},
            "max_size": {"type": "list:int", "default": [0, 0], "description": "目标最大尺寸（宽,高），0表示无限制"}
        }
    },
    "face_align": {
        "name": "人脸对齐", "description": "根据 facial landmark 调整人脸角度，使其水平端正", "category": "preprocessing",
        "opencv_function": "cv2.estimateAffinePartial2D + cv2.warpAffine", "input_type": "image:np.ndarray,list:rect",
        "output_type": "image:np.ndarray",
        "parameters": {
            "landmark_model": {"type": "str", "default": "lbfmodel.yaml", "description": "人脸关键点模型文件路径（需提前下载）"},
            "output_size": {"type": "list:int", "default": [150, 150], "description": "对齐后人脸的尺寸（宽,高）"}
        }
    },
    "perspective_transform": {
        "name": "透视变换", "description": "将倾斜的四边形目标矫正为正矩形（如车牌、文档）", "category": "geometry",
        "opencv_function": "cv2.getPerspectiveTransform + cv2.warpPerspective", "input_type": "image:np.ndarray,list:rect",
        "output_type": "image:np.ndarray",
        "parameters": {
            "output_width": {"type": "int", "default": 400, "min": 100, "max": 2000, "description": "矫正后图像的宽度"},
            "output_height": {"type": "int", "default": 200, "min": 50, "max": 1000, "description": "矫正后图像的高度"}
        }
    },
    "layer_merge": {
        "name": "图层融合", "description": "将两个图层按透明度混合（支持带Alpha通道的顶层图像）", "category": "compositing",
        "input_type": "image:np.ndarray,image:np.ndarray", "output_type": "image:np.ndarray",
        "parameters": {
            "alpha": {"type": "float", "default": 0.5, "min": 0.0, "max": 1.0, "description": "顶层图像透明度"},
            "x_offset": {"type": "int", "default": 0, "min": -1000, "max": 1000, "description": "顶层X方向偏移量"},
            "y_offset": {"type": "int", "default": 0, "min": -1000, "max": 1000, "description": "顶层Y方向偏移量"}
        }
    },
   "nafnet_deblur": {"name": "NAFNet 去模糊", "description": "使用 NAFNet 模型进行图像去模糊处理", "category": "advanced", "input_type": "image:np.ndarray|list:image:np.ndarray", "output_type": "image:np.ndarray|list:image:np.ndarray", "parameters": {"model_name": {"type": "select", "options": ["iic/cv_nafnet_image-deblur_reds", "iic/cv_nafnet_image-deblur_gopro"], "default": "iic/cv_nafnet_image-deblur_reds", "description": "NAFNet 模型类型"}, "channel_index": {"type": "int", "default": -1, "min": -1, "max": 3, "description": "通道索引（-1 = 全部通道）"}}}

}

import json
import numpy as np


class NumpyEncoder(json.JSONEncoder):
    """自定义JSON编码器，处理numpy数据类型"""

    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()  # 将numpy数组转换为list
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.bool_):
            return bool(obj)
        return super().default(obj)

from typing import Any, Callable  # 需导入Callable
class ImageProcessor:
    """图像处理器类"""
    def __init__(self):
        self.base_actions = self._load_base_actions()

    def _load_base_actions(self) -> Dict:
        """加载基础动作配置"""
        return imageActions

    def _ensure_odd(self, value: int) -> int:
        """确保数值为奇数"""
        return value if value % 2 == 1 else value + 1



    def _parse_output_type(self, output_type: str) -> Tuple[str, ...]:
        """解析输出类型"""
        return tuple(output_type.split(','))

    def _save_image(self, image: np.ndarray, output_path: str) -> bool:
        """保存图像，处理单通道和彩色图像"""
        try:
            # 如果是单通道图像，转换为3通道以便正确显示
            if len(image.shape) == 2:
                # 灰度图直接保存
                success = cv2.imwrite(output_path, image)
            else:
                # 彩色图直接保存
                success = cv2.imwrite(output_path, image)

            if not success:
                logging.error(f"保存图像失败: {output_path}")
                return False
            return True
        except Exception as e:
            logging.error(f"保存图像时出错 {output_path}: {str(e)}")
            return False

    def process_step(self, step: Dict, input_data: Tuple[np.ndarray, Dict], step_index: int, output_dir: str) -> Tuple[Dict, Tuple[np.ndarray, Dict]]:
        """处理单个步骤（修改input参数名为input_data，支持字典格式）"""
        action = step.get('action')
        params = step.get('params', {})
        step_id = step.get('id', step_index)

        logging.info(f"执行步骤 {step_index}: {action}")

        # 解析输入数据：如果是字典，提取图像和元数据；否则默认图像为输入，元数据为空
        input_image, input_metadata = input_data  # 分离图像和元数据
        input_metadata = input_metadata or {}  # 确保元数据是字典
        # 检查动作是否支持
        if action not in self.base_actions:
            raise ValueError(f"不支持的动作: {action}")

        action_config = self.base_actions[action]
        output_types = self._parse_output_type(action_config['output_type'])

        # 执行图像处理：将元数据也传入_execute_action（供需要的动作使用）
        result = self._execute_action(action, input_image, params, step_index, output_dir, input_metadata)

        # 准备步骤结果 - 简化输出
        step_result = {
            "step_id": step_id,
            "action": action,
            "name": step.get('name', action_config['name']),
            "description": step.get('description', action_config['description']),
            "input_shape": input_image.shape if input_image is not None else None,
            "output_types": list(output_types),
            "success": True
        }

        # 解析执行结果：分离主输出、元数据（如果有的话）
        main_result = result
        output_metadata = {}
        if isinstance(result, tuple) and len(result) == 2:
            main_result, output_metadata = result  # 若动作返回 (结果, 元数据)，则分离

        # 新增：收集元数据中的关键结果
        if output_metadata:
            if "aligned_count" in output_metadata:
                step_result["numeric_result"] = output_metadata["aligned_count"]
            if "rects" in output_metadata:
                step_result["list_count"] = len(output_metadata["rects"])

        # 根据输出类型处理结果
        try:
            if len(output_types) == 1:
                if output_types[0].startswith('image:'):
                    output_image = main_result
                    step_result["output_shape"] = output_image.shape
                    output_filename = f"step_{step_index:02d}_{action}.jpg"
                    output_path = os.path.join(output_dir, output_filename)
                    if self._save_image(output_image, output_path):
                        step_result["output_image"] = output_filename
                        step_result["output_path"] = output_path
                    else:
                        step_result["output_image"] = None
                        step_result["output_path"] = None

                elif output_types[0].startswith('num:'):
                    step_result["numeric_result"] = float(main_result) if main_result is not None else 0
                    step_result["output_image"] = None

                elif output_types[0].startswith('list:'):
                    step_result["list_count"] = len(main_result) if main_result is not None else 0
                    if main_result and len(main_result) > 0:
                        step_result["list_summary"] = f"包含 {len(main_result)} 个元素"
                    step_result["output_image"] = None

            elif len(output_types) == 2:
                if action in ["connected_component_count"]:
                    num_result, img_result = main_result
                    step_result["numeric_result"] = int(num_result) if num_result is not None else 0
                    if img_result is not None:
                        step_result["output_shape"] = img_result.shape
                        output_filename = f"step_{step_index:02d}_{action}.jpg"
                        output_path = os.path.join(output_dir, output_filename)
                        if self._save_image(img_result, output_path):
                            step_result["output_image"] = output_filename
                            step_result["output_path"] = output_path
                        else:
                            step_result["output_image"] = None
                            step_result["output_path"] = None
                    else:
                        step_result["output_image"] = None
                else:
                    # 对haar_cascade_detect，视为单图像输出（元数据已分离）
                    output_image = main_result[0] if isinstance(main_result, tuple) else main_result
                    step_result["output_shape"] = output_image.shape
                    output_filename = f"step_{step_index:02d}_{action}.jpg"
                    output_path = os.path.join(output_dir, output_filename)
                    if self._save_image(output_image, output_path):
                        step_result["output_image"] = output_filename
                        step_result["output_path"] = output_path
                    else:
                        step_result["output_image"] = None
                        step_result["output_path"] = None
                # logging.info(f"main_result:{main_result}")
                # num_result, img_result = main_result
                # step_result["numeric_result"] = int(num_result) if num_result is not None else 0
                # if img_result is not None:
                #     step_result["output_shape"] = img_result.shape
                #     output_filename = f"step_{step_index:02d}_{action}.jpg"
                #     output_path = os.path.join(output_dir, output_filename)
                #     if self._save_image(img_result, output_path):
                #         step_result["output_image"] = output_filename
                #         step_result["output_path"] = output_path
                #     else:
                #         step_result["output_image"] = None
                #         step_result["output_path"] = None
                # else:
                #     step_result["output_image"] = None

            elif len(output_types) == 3:
                list_result, num_result, img_result = main_result
                step_result["list_count"] = len(list_result) if list_result is not None else 0
                if list_result and len(list_result) > 0:
                    areas = [cv2.contourArea(contour) for contour in list_result]
                    step_result["contour_summary"] = {
                        "count": len(list_result),
                        "total_area": sum(areas),
                        "avg_area": sum(areas) / len(areas) if areas else 0,
                        "min_area": min(areas) if areas else 0,
                        "max_area": max(areas) if areas else 0
                    }
                step_result["numeric_result"] = int(num_result) if num_result is not None else 0
                if img_result is not None:
                    step_result["output_shape"] = img_result.shape
                    output_filename = f"step_{step_index:02d}_{action}.jpg"
                    output_path = os.path.join(output_dir, output_filename)
                    if self._save_image(img_result, output_path):
                        step_result["output_image"] = output_filename
                        step_result["output_path"] = output_path
                    else:
                        step_result["output_image"] = None
                        step_result["output_path"] = None
                else:
                    step_result["output_image"] = None

        except Exception as e:
            logging.error(f"处理步骤结果时出错: {str(e)}  {traceback.format_exc()}")
            step_result["success"] = False
            step_result["error"] = str(e)

        logging.info(f"步骤 {step_index} 完成: {action}")

        # 准备下一步的输入数据（字典格式：包含图像和元数据）
        next_image = None
        if len(output_types) == 1 and output_types[0].startswith('image:'):
            next_image = main_result
        elif len(output_types) == 2:
            next_image = main_result[1] if len(main_result) > 1 else main_result[0]
        elif len(output_types) == 3:
            next_image = main_result[2] if len(main_result) > 2 else ( main_result[1] if len(main_result) > 1 else main_result[0])

        # 下一步的输入数据：{image: 图像, metadata: 元数据}
        next_data = (next_image, output_metadata)
        return step_result, next_data

    # def _get_opencv_constant(self, constant_name: str) -> int:
    #     """获取OpenCV常量值"""
    #     return getattr(cv2, constant_name)
    def _get_opencv_constant(self, constant_name: str) -> int:
        """获取OpenCV常量值"""
        # 特殊处理颜色空间转换常量
        if constant_name in ['BGR2GRAY', 'BGR2HSV', 'BGR2LAB', 'HSV2BGR', 'LAB2BGR']:
            opencv_code_map = {
                'BGR2GRAY': cv2.COLOR_BGR2GRAY,
                'BGR2HSV': cv2.COLOR_BGR2HSV,
                'BGR2LAB': cv2.COLOR_BGR2LAB,
                'HSV2BGR': cv2.COLOR_HSV2BGR,
                'LAB2BGR': cv2.COLOR_LAB2BGR
            }
            return opencv_code_map.get(constant_name, cv2.COLOR_BGR2GRAY)

        # 其他常量正常获取
        return getattr(cv2, constant_name)

    def _process_by_channel(self,
                            image: Any,
                            process_func: Callable[[np.ndarray], np.ndarray],  # 改用Callable
                            channel_index: int = -1) -> Any:
        """

        通用通道处理函数：根据channel_index对指定通道应用处理函数

        参数:
            image: 输入图像（可能是单通道ndarray、多通道ndarray、通道列表）
            process_func: 处理单通道的函数（输入单通道ndarray，返回处理后的单通道ndarray）
            channel_index: 通道索引（-1=所有通道，0=第一个通道...）

        返回:
            处理后的图像（与输入格式一致）
        """
        # 情况1：输入是通道列表（如split_channels的输出）
        if isinstance(image, list) and all(isinstance(ch, np.ndarray) for ch in image):
            if channel_index == -1:
                # 处理所有通道
                return [process_func(ch) for ch in image]
            elif 0 <= channel_index < len(image):
                # 处理指定通道，其他通道不变
                new_channels = image.copy()
                new_channels[channel_index] = process_func(new_channels[channel_index])
                return new_channels
            else:
                raise IndexError(f"通道索引超出范围（共{len(image)}个通道）")

        # 情况2：输入是单通道图像（2D数组）
        elif isinstance(image, np.ndarray) and len(image.shape) == 2:
            # 单通道无需区分索引，直接处理
            return process_func(image)

        # 情况3：输入是多通道图像（3D数组，如BGR图）
        elif isinstance(image, np.ndarray) and len(image.shape) == 3:
            # 先拆分通道，并转换为列表（元组→列表，列表支持copy()）
            channels = list(cv2.split(image))  # 关键修复：用list()转换元组为列表
            if channel_index == -1:
                # 处理所有通道后合并
                processed_channels = [process_func(ch) for ch in channels]
            else:
                # 处理指定通道，其他通道不变
                if not (0 <= channel_index < len(channels)):
                    raise IndexError(f"通道索引超出范围（共{len(channels)}个通道）")
                processed_channels = channels.copy()  # 列表支持copy()，此处不再报错
                processed_channels[channel_index] = process_func(processed_channels[channel_index])
            # 合并通道返回
            return cv2.merge(processed_channels)

        # 不支持的输入类型
        else:
            raise TypeError("输入必须是单通道图像、多通道图像或通道列表")
    def _execute_action(self, action: str, image: np.ndarray, params: Dict, step_index: int, output_dir: str, input_metadata: Dict = None) -> Any:
        """执行具体的图像处理动作"""

        if action == "gaussian_blur":
            kernel_size = self._ensure_odd(params.get('kernel_size', 3))
            sigma_x = params.get('sigma_x', 0)
            channel_index = params.get("channel_index", -1)
            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                return cv2.GaussianBlur(ch, (kernel_size, kernel_size), sigma_x)
            return self._process_by_channel(image, process_single_channel, channel_index)

        elif action == "median_blur":
            kernel_size = self._ensure_odd(params.get('kernel_size', 3))
            channel_index = params.get("channel_index", -1)
            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                return cv2.medianBlur(ch, kernel_size)
            return self._process_by_channel(image, process_single_channel, channel_index)

        elif action == "guided_filter":
            radius = params.get('radius', 5)
            eps = params.get('eps', 0.01)
            channel_index = params.get("channel_index", -1)

            # 自定义导向滤波（无依赖实现）
            def guided_filter(guide: np.ndarray, src: np.ndarray, radius: int, eps: float) -> np.ndarray:
                guide = guide.astype(np.float32) / 255.0
                src = src.astype(np.float32) / 255.0
                mean_guide = cv2.boxFilter(guide, -1, (radius, radius), normalize=True)
                mean_src = cv2.boxFilter(src, -1, (radius, radius), normalize=True)
                mean_guide_src = cv2.boxFilter(guide * src, -1, (radius, radius), normalize=True)
                cov_guide_src = mean_guide_src - mean_guide * mean_src
                mean_guide_sq = cv2.boxFilter(guide * guide, -1, (radius, radius), normalize=True)
                var_guide = mean_guide_sq - mean_guide * mean_guide
                a = cov_guide_src / (var_guide + eps)
                b = mean_src - a * mean_guide
                mean_a = cv2.boxFilter(a, -1, (radius, radius), normalize=True)
                mean_b = cv2.boxFilter(b, -1, (radius, radius), normalize=True)
                output = mean_a * guide + mean_b
                return np.uint8(np.clip(output * 255, 0, 255))

            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                return guided_filter(guide=ch, src=ch, radius=radius, eps=eps)

            return self._process_by_channel(image, process_single_channel, channel_index)
        elif action == "msrcr":
            sigma_list = params.get('sigma_list', [15, 80, 250])  # 多尺度高斯核
            channel_index = params.get("channel_index", -1)
            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                # 归一化到0-1
                ch_norm = ch / 255.0
                # 多尺度Retinex计算
                retinex = np.zeros_like(ch_norm)
                for sigma in sigma_list:
                    blur = cv2.GaussianBlur(ch_norm, (0, 0), sigma)
                    retinex += np.log1p(ch_norm) - np.log1p(blur + 1e-6)
                retinex = retinex / len(sigma_list)
                # 对比度拉伸
                retinex = (retinex - np.min(retinex)) / (np.max(retinex) - np.min(retinex) + 1e-6)
                return np.uint8(retinex * 255)
            return self._process_by_channel(image, process_single_channel, channel_index)


        elif action == "blind_deconvolution":
            iterations = params.get('iterations', 30)
            channel_index = params.get("channel_index", -1)
            # 自定义Richardson-Lucy盲去卷积（不依赖ximgproc）
            def richardson_lucy_deconv(image: np.ndarray, kernel: np.ndarray, iterations: int) -> np.ndarray:
                image = image.astype(np.float32) / 255.0
                kernel = kernel.astype(np.float32) / np.sum(kernel)
                kernel_t = np.flipud(np.fliplr(kernel))  # 核转置
                restored = np.copy(image)
                for _ in range(iterations):
                    estimate = cv2.filter2D(restored, -1, kernel, borderType=cv2.BORDER_REFLECT)
                    ratio = image / (estimate + 1e-6)
                    correction = cv2.filter2D(ratio, -1, kernel_t, borderType=cv2.BORDER_REFLECT)
                    restored *= correction
                return np.uint8(np.clip(restored * 255, 0, 255))
            def process_single_channel(ch: np.ndarray) -> np.ndarray:

                denoised = cv2.fastNlMeansDenoising(ch, h=5)
                # 初始模糊核（5x5平均核）
                kernel = np.ones((5, 5), np.float32) / 25
                # 用自定义算法替代deconvblind
                restored = richardson_lucy_deconv(denoised, kernel, iterations)
                return cv2.equalizeHist(restored)
            return self._process_by_channel(image, process_single_channel, channel_index)

        elif action == "bilateral_filter":

            d = params.get('d', 9)
            sigma_color = params.get('sigma_color', 75)
            sigma_space = params.get('sigma_space', 75)
            channel_index = params.get("channel_index", -1)
            # 定义单通道处理函数
            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                return cv2.bilateralFilter(ch, d, sigma_color, sigma_space)
            return self._process_by_channel(image, process_single_channel, channel_index)

        elif action == "fast_nl_means_denoising_colored":
            h = params.get('h', 10)  # 控制去噪强度（越大去噪越强，细节损失越多）
            h_color = params.get('h_color', 10)  # 彩色通道去噪强度
            template_window_size = self._ensure_odd(params.get('template_window_size', 7))
            search_window_size = self._ensure_odd(params.get('search_window_size', 21))
            channel_index = params.get("channel_index", -1)

            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                # 单通道用普通非局部均值
                return cv2.fastNlMeansDenoising(
                    ch, h=h, templateWindowSize=template_window_size, searchWindowSize=search_window_size
                )

            # 若输入是多通道且处理所有通道，直接用彩色优化版
            if isinstance(image, np.ndarray) and len(image.shape) == 3 and channel_index == -1:
                return cv2.fastNlMeansDenoisingColored(
                    image, h=h, hColor=h_color,
                    templateWindowSize=template_window_size,
                    searchWindowSize=search_window_size
                )
            else:
                # 单通道或指定通道，用通用处理
                return self._process_by_channel(image, process_single_channel, channel_index)
        elif action == "laplacian_edge":
            ksize = self._ensure_odd(params.get('ksize', 3))  # 核大小（3/5/7）
            scale = params.get('scale', 1.0)  # 边缘强度缩放
            delta = params.get('delta', 0)  # 偏移值
            channel_index = params.get("channel_index", -1)

            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                laplacian = cv2.Laplacian(ch, cv2.CV_64F, ksize=ksize, scale=scale, delta=delta)
                # 转换为uint8并增强到原图
                laplacian = np.uint8(np.absolute(laplacian))
                return cv2.addWeighted(ch, 0.7, laplacian, 0.3, 0)  # 原图+边缘叠加

            return self._process_by_channel(image, process_single_channel, channel_index)
        elif action == "motion_blur_restore":
            # 模糊核参数（需根据实际模糊方向调整）
            angle = params.get('angle', 0)  # 模糊方向（0=水平，90=垂直，45=对角线）
            length = params.get('length', 15)  # 模糊长度（越大模糊越严重，需与实际匹配）
            channel_index = params.get("channel_index", -1)

            # 生成运动模糊核（线性核）
            def create_motion_kernel(angle: float, length: int) -> np.ndarray:
                kernel = np.zeros((length, length), np.float32)
                angle_rad = np.deg2rad(angle)
                # 计算核中心
                center = length // 2
                # 沿角度方向填充1（形成线性模糊核）
                for i in range(length):
                    x = int(center + i * np.cos(angle_rad))
                    y = int(center + i * np.sin(angle_rad))
                    if 0 <= x < length and 0 <= y < length:
                        kernel[y, x] = 1
                # 归一化
                return kernel / np.sum(kernel)

            # 单通道处理函数：逆滤波+边缘增强
            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                kernel = create_motion_kernel(angle, length)
                # 对模糊图像做傅里叶变换
                fft_img = np.fft.fft2(ch)
                fft_kernel = np.fft.fft2(kernel, s=ch.shape)
                # 逆滤波（频域除法）+ 正则化（避免噪声放大）
                fft_restored = fft_img / (fft_kernel + 1e-6)  # 加小值防止除零
                restored = np.fft.ifft2(fft_restored).real
                restored = np.uint8(np.clip(restored, 0, 255))
                # 边缘增强（修复逆滤波导致的模糊）
                laplacian = cv2.Laplacian(restored, cv2.CV_64F, ksize=3)
                edge_enhanced = cv2.addWeighted(restored, 1.2, np.uint8(np.abs(laplacian)), 0.2, 0)
                return edge_enhanced

            return self._process_by_channel(image, process_single_channel, channel_index)



        elif action == "binary_threshold":
            thresh = params.get('thresh', 127)
            maxval = params.get('maxval', 255)
            thresh_type = self._get_opencv_constant(params.get('type', 'THRESH_BINARY'))
            _, result = cv2.threshold(image, thresh, maxval, thresh_type)
            return result

        elif action == "adaptive_threshold":
            max_value = params.get('max_value', 255)
            adaptive_method = self._get_opencv_constant(params.get('adaptive_method', 'ADAPTIVE_THRESH_MEAN_C'))
            threshold_type = self._get_opencv_constant(params.get('threshold_type', 'THRESH_BINARY'))
            block_size = self._ensure_odd(params.get('block_size', 11))
            C = params.get('C', 2)
            return cv2.adaptiveThreshold(image, max_value, adaptive_method, threshold_type, block_size, C)

        elif action == "otsu_threshold":
            maxval = params.get('maxval', 255)
            _, result = cv2.threshold(image, 0, maxval, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            return result

        elif action == "erode":
            kernel_size = params.get('kernel_size', 3)
            iterations = params.get('iterations', 1)
            kernel = np.ones((kernel_size, kernel_size), np.uint8)
            channel_index = params.get("channel_index", -1)

            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                return cv2.erode(ch, kernel, iterations=iterations)

            return self._process_by_channel(image, process_single_channel, channel_index)
        elif action == "dilate":
            # kernel_size = params.get('kernel_size', 3)
            # iterations = params.get('iterations', 1)
            # kernel = np.ones((kernel_size, kernel_size), np.uint8)
            # return cv2.dilate(image, kernel, iterations=iterations)
            kernel_size = params.get('kernel_size', 3)
            iterations = params.get('iterations', 1)
            kernel = np.ones((kernel_size, kernel_size), np.uint8)
            channel_index = params.get("channel_index", -1)

            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                return cv2.dilate(ch, kernel, iterations=iterations)

            return self._process_by_channel(image, process_single_channel, channel_index)
        elif action == "morph_open":
            kernel_size = params.get('kernel_size', 3)
            kernel = np.ones((kernel_size, kernel_size), np.uint8)
            channel_index = params.get("channel_index", -1)
            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                return cv2.morphologyEx(ch, cv2.MORPH_OPEN, kernel)
            return self._process_by_channel(image, process_single_channel, channel_index)


        elif action == "morph_close":
            kernel_size = params.get('kernel_size', 3)
            kernel = np.ones((kernel_size, kernel_size), np.uint8)
            channel_index = params.get("channel_index", -1)
            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                return cv2.morphologyEx(ch, cv2.MORPH_CLOSE, kernel)
            return self._process_by_channel(image, process_single_channel, channel_index)


        elif action == "canny_edge":
            threshold1 = params.get('threshold1', 50)
            threshold2 = params.get('threshold2', 150)
            aperture_size = self._ensure_odd(params.get('aperture_size', 3))
            channel_index = params.get("channel_index", -1)
            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                return cv2.Canny(ch, threshold1, threshold2, apertureSize=aperture_size)

            return self._process_by_channel(image, process_single_channel, channel_index)


        elif action == "sobel_edge":

            try:
                dx = params.get('dx', 1)
                dy = params.get('dy', 0)
                ksize = self._ensure_odd(params.get('ksize', 3))
                channel_index = params.get("channel_index", -1)
                # 定义单通道Sobel处理函数（核心逻辑）
                def process_single_channel(ch: np.ndarray) -> np.ndarray:
                    sobel_x = cv2.Sobel(ch, cv2.CV_64F, dx, 0, ksize=ksize)
                    sobel_y = cv2.Sobel(ch, cv2.CV_64F, 0, dy, ksize=ksize)
                    sobel_magnitude = np.sqrt(sobel_x ** 2 + sobel_y ** 2)
                    # 标准化到0-255
                    return np.uint8(
                        255 * sobel_magnitude / np.max(sobel_magnitude) if np.max(sobel_magnitude) != 0 else 0)
                # 调用通用通道处理函数（处理后得到边缘图通道）
                edge_channels = self._process_by_channel(image, process_single_channel, channel_index)
                # 若输入是多通道图且未拆分，需将边缘结果合并回原图（保持与原逻辑兼容）
                if isinstance(image, np.ndarray) and len(image.shape) == 3 and not isinstance(edge_channels, list):
                    # 转换到LAB空间，将边缘增强到L通道
                    lab = cv2.cvtColor(image, cv2.COLOR_BGR2LAB)
                    l_channel = lab[:, :, 0]
                    # 边缘图可能是单通道或多通道，取第一个通道增强
                    edge_single = edge_channels[:, :, 0] if len(edge_channels.shape) == 3 else edge_channels
                    enhanced_l = cv2.addWeighted(l_channel, 0.7, edge_single, 0.3, 0)
                    lab[:, :, 0] = enhanced_l
                    return cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
                else:
                    # 输入是单通道或通道列表，直接返回边缘结果
                    return edge_channels
            except Exception as e:
                logging.error(f"Sobel边缘检测失败: {e}")

                return image
        elif action == "unsharp_mask":
            strength = params.get('strength', 1.5)
            blur_amount = params.get('blur_amount', 1.0)
            channel_index = params.get("channel_index", -1)  # 新增通道索引参数

            # 定义单通道非锐化掩模处理函数
            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                # 对单个通道执行高斯模糊
                blurred = cv2.GaussianBlur(ch, (0, 0), blur_amount)
                # 非锐化公式：原图*(1+strength) - 模糊图*strength
                return cv2.addWeighted(ch, 1.0 + strength, blurred, -strength, 0)
            # 调用通用通道处理函数
            return self._process_by_channel(image, process_single_channel, channel_index)



        elif action == "color_space_convert":
            code_name = params.get('code', 'BGR2GRAY')
            opencv_code_map = {
                'BGR2GRAY': cv2.COLOR_BGR2GRAY,
                'BGR2HSV': cv2.COLOR_BGR2HSV,
                'BGR2LAB': cv2.COLOR_BGR2LAB,
                'HSV2BGR': cv2.COLOR_HSV2BGR,
                'LAB2BGR': cv2.COLOR_LAB2BGR,
                'GRAY2BGR': cv2.COLOR_GRAY2BGR,
                'RGB2GRAY': cv2.COLOR_RGB2GRAY,
                'RGB2HSV': cv2.COLOR_RGB2HSV,
                'BGR2YCrCb': cv2.COLOR_BGR2YCrCb,
                'YCrCb2BGR': cv2.COLOR_YCrCb2BGR
            }

            if code_name not in opencv_code_map:
                raise ValueError(f"不支持的颜色空间转换代码: {code_name}")

            code = opencv_code_map[code_name]

            input_channels = image.shape[2] if len(image.shape) == 3 else 1  # 获取输入通道数

            # 定义转换代码所需的输入通道数（key: 转换代码名, value: 所需通道数）

            required_channels = {
                'BGR2GRAY': 3,  # BGR转灰度需要3通道
                'BGR2HSV': 3,  # BGR转HSV需要3通道
                'BGR2LAB': 3,
                'HSV2BGR': 3,  # HSV转BGR需要3通道
                'LAB2BGR': 3,
                'GRAY2BGR': 1,  # 灰度转BGR需要1通道
                'RGB2GRAY': 3,
                'RGB2HSV': 3,
                'BGR2YCrCb': 3,
                'YCrCb2BGR': 3
            }
            # 检查输入通道数是否匹配，不匹配则自动转换通道数
            if input_channels != required_channels[code_name]:
                logging.warning(
                    f"颜色转换通道不匹配：转换 {code_name} 需要 {required_channels[code_name]} 通道，但输入图像是 {input_channels} 通道，将自动适配"
                )
                # 灰度图（1通道）转3通道BGR（用于需要3通道输入的转换）
                if input_channels == 1 and required_channels[code_name] == 3:
                    image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
                # 3通道转灰度（用于需要1通道输入的转换，如GRAY2BGR）
                elif input_channels == 3 and required_channels[code_name] == 1:
                    image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            return cv2.cvtColor(image, code)

        elif action == "color_threshold":
            lower_bound = np.array([
                params.get('lower_H', 0),
                params.get('lower_S', 0),
                params.get('lower_V', 0)
            ])
            upper_bound = np.array([
                params.get('upper_H', 180),
                params.get('upper_S', 255),
                params.get('upper_V', 255)
            ])
            return cv2.inRange(image, lower_bound, upper_bound)

        elif action == "resize":
            width = params.get('width', 640)
            height = params.get('height', 480)
            interpolation = self._get_opencv_constant(params.get('interpolation', 'INTER_LINEAR'))
            return cv2.resize(image, (width, height), interpolation=interpolation)


        elif action == "histogram_equalize":
            channel_index = params.get("channel_index", -1)
            if isinstance(image, list) and all(isinstance(ch, np.ndarray) for ch in image):
                if channel_index == -1:  # 处理所有通道
                    return [cv2.equalizeHist(ch) for ch in image]
                elif 0 <= channel_index < len(image):  # 处理指定通道
                    new_channels = image.copy()  # 列表支持copy()
                    new_channels[channel_index] = cv2.equalizeHist(new_channels[channel_index])
                    return new_channels
                else:
                    raise IndexError(f"通道索引超出范围（共{len(image)}个通道）")
            elif isinstance(image, np.ndarray) and len(image.shape) == 2:
                return cv2.equalizeHist(image)
            elif isinstance(image, np.ndarray) and len(image.shape) == 3:
                # 关键修复：将split返回的元组转为列表（元组无copy()方法）
                channels = list(cv2.split(image))  # 元组 → 列表
                if channel_index == -1:
                    equalized = [cv2.equalizeHist(ch) for ch in channels]
                else:
                    if 0 <= channel_index < len(channels):
                        equalized = channels.copy()  # 列表支持copy()
                        equalized[channel_index] = cv2.equalizeHist(equalized[channel_index])
                    else:
                        raise IndexError(f"通道索引超出范围（共{len(channels)}个通道）")
                return cv2.merge(equalized)
            else:
                raise TypeError("输入必须是单通道图像、多通道图像或通道列表")
        elif action == "clahe":
            # 获取参数（默认值适合大多数场景）
            clip_limit = params.get('clip_limit', 2.0)  # 对比度限制阈值（越大增强越强，建议1.0-3.0）
            grid_size = params.get('grid_size', 8)  # 网格大小（将图像分成 grid_size×grid_size 块，建议8-16）
            channel_index = params.get("channel_index", -1)  # 通道索引（支持指定通道处理）
            clahe    = cv2.createCLAHE( clipLimit=clip_limit,tileGridSize=(grid_size, grid_size)   )
            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                return clahe.apply(ch)  # 对单通道执行CLAHE
            return self._process_by_channel(image, process_single_channel, channel_index)

        elif action == "connected_component_count":
            connectivity = params.get('connectivity', 8)
            min_area = params.get('min_area', 10)
            # 执行连通组件分析
            num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(image, connectivity=connectivity)
            # 过滤小区域
            valid_labels = []
            for i in range(1, num_labels):  # 跳过背景
                if stats[i, cv2.CC_STAT_AREA] >= min_area:
                    valid_labels.append(i)

            count = len(valid_labels)

            # 创建可视化图像
            if len(image.shape) == 2:
                output_image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
            else:
                output_image = image.copy()

            # 标记连通区域
            for label in valid_labels:
                # 获取区域边界框
                x = stats[label, cv2.CC_STAT_LEFT]
                y = stats[label, cv2.CC_STAT_TOP]
                w = stats[label, cv2.CC_STAT_WIDTH]
                h = stats[label, cv2.CC_STAT_HEIGHT]

                # 绘制边界框
                cv2.rectangle(output_image, (x, y), (x + w, y + h), (0, 255, 0), 2)

                # 绘制中心点
                center_x, center_y = int(centroids[label, 0]), int(centroids[label, 1])
                cv2.circle(output_image, (center_x, center_y), 3, (0, 0, 255), -1)

                # 添加标签
                cv2.putText(output_image, str(label), (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)

            return count, output_image

        elif action == "contour_detect":
            mode = self._get_opencv_constant(params.get('mode', 'RETR_EXTERNAL'))
            method = self._get_opencv_constant(params.get('method', 'CHAIN_APPROX_SIMPLE'))
            min_area = params.get('min_area', 100)

            # OpenCV版本兼容性处理
            if cv2.__version__.startswith('3'):
                # OpenCV 3.x
                _, contours, hierarchy = cv2.findContours(image, mode, method)
            else:
                # OpenCV 4.x
                contours, hierarchy = cv2.findContours(image, mode, method)

            # 过滤小轮廓
            valid_contours = []
            for contour in contours:
                area = cv2.contourArea(contour)
                if area >= min_area:
                    valid_contours.append(contour)

            # 创建可视化图像
            if len(image.shape) == 2:
                output_image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
            else:
                output_image = image.copy()

            # 绘制轮廓
            cv2.drawContours(output_image, valid_contours, -1, (0, 255, 0), 2)

            # 添加轮廓编号
            for i, contour in enumerate(valid_contours):
                M = cv2.moments(contour)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    cv2.putText(output_image, str(i + 1), (cx, cy), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)

            # 返回3个值：轮廓列表、轮廓数量、可视化图像
            return valid_contours, len(valid_contours), output_image

        elif action == "split_channels":
            if len(image.shape) < 3:
                raise ValueError("split_channels仅支持多通道图像")
            return list(cv2.split(image))  # 返回列表便于处理
        elif action == "merge_channels":
            if not isinstance(image, list) or not all(isinstance(ch, np.ndarray) for ch in image):
                raise TypeError("merge_channels的输入必须是单通道列表")
            return cv2.merge(image)
        elif action == "haar_cascade_detect":
            import os
            cascade_path = params.get("cascade_path", "haarcascade_frontalface_default.xml")
            scale_factor = params.get("scale_factor", 1.1)
            min_neighbors = params.get("min_neighbors", 5)
            min_size = tuple(params.get("min_size", [30, 30]))
            max_size = tuple(params.get("max_size", [0, 0])) if params.get("max_size", [0, 0]) != [0, 0] else None

            # 检查模型文件是否存在
            if not os.path.exists(cascade_path):
                raise FileNotFoundError(f"Haar级联模型文件不存在：{cascade_path}（需从OpenCV官网下载）")

            # 加载级联分类器
            cascade = cv2.CascadeClassifier(cascade_path)

            # 转换为灰度图（检测要求）
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image

            # 检测目标
            objects = cascade.detectMultiScale(
                gray,
                scaleFactor=scale_factor,
                minNeighbors=min_neighbors,
                minSize=min_size,
                maxSize=max_size
            )
            valid_objects = []
            img_h, img_w = gray.shape[:2]
            for (x, y, w, h) in objects:
                # 排除宽高为0、超出图像范围的矩形
                if w > 0 and h > 0 and x + w <= img_w and y + h <= img_h:
                    valid_objects.append((x, y, w, h))
            objects = valid_objects  # 替换为有效矩形
            # 标记目标到原图
            marked_image = image.copy()
            rects_list = [list(rect) for rect in objects]  # 人脸矩形列表
            logging.info(f"rects_list len: {len(rects_list)} {rects_list} ")
            marked_image = image.copy()
            for (x, y, w, h) in objects:
                cv2.rectangle(marked_image, (x, y), (x + w, y + h), (0, 255, 0), 2)

            return marked_image, {"rects": rects_list}

        elif action == "face_align":
            output_size = tuple(params.get("output_size", [150, 150]))
            face_rects = input_metadata.get("rects", [])
            if not face_rects:
                logging.warning("未检测到人脸，返回原图")
                return image, {}

            aligned_faces = []
            for rect in face_rects:
                x, y, w, h = rect
                # 1. 计算裁剪区域（确保在图像范围内）
                x1 = max(0, x - int(w * 0.1))
                y1 = max(0, y - int(h * 0.1))
                x2 = min(image.shape[1], x + w + int(w * 0.1))
                y2 = min(image.shape[0], y + h + int(h * 0.1))

                # 2. 检查裁剪区域有效性（避免宽或高为0）
                if x2 <= x1 or y2 <= y1:
                    logging.warning(f"无效的人脸区域：x1={x1}, y1={y1}, x2={x2}, y2={y2}，跳过该区域")
                    continue

                # 3. 裁剪并 resize
                face_crop = image[y1:y2, x1:x2]
                # 确保 output_size 是有效的正整数（避免0或负数）
                if output_size[0] <= 0 or output_size[1] <= 0:
                    output_size = (150, 150)  # 默认为有效尺寸
                    logging.warning(f"输出尺寸无效，使用默认值 {output_size}")

                aligned_face = cv2.resize(face_crop, output_size, interpolation=cv2.INTER_CUBIC)
                aligned_faces.append(aligned_face)

            # 4. 处理无有效对齐人脸的情况
            if not aligned_faces:
                logging.warning("所有人脸区域均无效，返回原图")
                return image, {"aligned_count": 0}

            # 5. 合并对齐的人脸（如果有多个）
            merged_aligned = cv2.hconcat(aligned_faces) if len(aligned_faces) > 1 else aligned_faces[0]
            return merged_aligned, {"aligned_count": len(aligned_faces)}


        elif action == "perspective_transform":
            # 参数解析
            output_width = params.get("output_width", 400)
            output_height = params.get("output_height", 200)

            # 输入为（原图, 轮廓点列表），轮廓点需是4个点（顺时针或逆时针）
            if not isinstance(image, tuple) or len(image) != 2:
                raise TypeError("perspective_transform输入必须是 (原图, 4个轮廓点列表)")
            original_img, contour_points = image

            # 检查轮廓点数量
            if len(contour_points) != 4:
                raise ValueError("透视变换需要4个轮廓点（构成四边形）")

            # 排序轮廓点（确保是顺时针：左上→右上→右下→左下）
            pts = np.array(contour_points, dtype=np.float32)
            # 按x+y排序（左上最小，右下最大）
            sum_pts = pts.sum(axis=1)
            top_left = pts[np.argmin(sum_pts)]
            bottom_right = pts[np.argmax(sum_pts)]
            # 按x-y排序（右上最小，左下最大）
            diff_pts = np.diff(pts, axis=1)
            top_right = pts[np.argmin(diff_pts)]
            bottom_left = pts[np.argmax(diff_pts)]
            src_pts = np.array([top_left, top_right, bottom_right, bottom_left], dtype=np.float32)

            # 目标点（正矩形）
            dst_pts = np.array([
                [0, 0],  # 左上
                [output_width - 1, 0],  # 右上
                [output_width - 1, output_height - 1],  # 右下
                [0, output_height - 1]  # 左下
            ], dtype=np.float32)

            # 计算透视变换矩阵
            M = cv2.getPerspectiveTransform(src_pts, dst_pts)
            # 执行透视变换
            transformed = cv2.warpPerspective(
                original_img,
                M,
                (output_width, output_height),
                flags=cv2.INTER_LINEAR
            )

            return transformed

        elif action == "layer_merge":
            # 输入必须是（底层图, 顶层图）的元组
            if not isinstance(image, tuple) or len(image) != 2:
                raise TypeError("layer_merge的输入必须是（底层图像, 顶层图像）的元组")
            background, foreground = image

            # 确保输入是BGR格式（OpenCV默认）
            if len(background.shape) != 3 or background.shape[2] not in (3, 4):
                raise ValueError("底层图像必须是3通道（BGR）或4通道（BGR+Alpha）图像")
            if len(foreground.shape) != 3 or foreground.shape[2] not in (3, 4):
                raise ValueError("顶层图像必须是3通道（BGR）或4通道（BGR+Alpha）图像")

            # 获取参数
            alpha = params.get("alpha", 0.5)
            x_offset = params.get("x_offset", 0)
            y_offset = params.get("y_offset", 0)

            # 提取顶层Alpha通道（如果有）
            if foreground.shape[2] == 4:
                fg_bgr = foreground[:, :, :3]  # BGR通道
                fg_alpha = foreground[:, :, 3] / 255.0  # Alpha通道归一化到0-1
                # 结合透明度参数
                fg_alpha = fg_alpha * alpha
            else:
                fg_bgr = foreground
                fg_alpha = alpha  # 无Alpha通道时直接使用透明度参数

            # 计算顶层在底层的放置区域
            bg_h, bg_w = background.shape[:2]
            fg_h, fg_w = fg_bgr.shape[:2]

            # 计算有效区域（防止偏移超出底层范围）
            x1 = max(0, x_offset)
            y1 = max(0, y_offset)
            x2 = min(bg_w, x_offset + fg_w)
            y2 = min(bg_h, y_offset + fg_h)

            # 计算顶层对应的区域
            fg_x1 = max(0, -x_offset)
            fg_y1 = max(0, -y_offset)
            fg_x2 = fg_x1 + (x2 - x1)
            fg_y2 = fg_y1 + (y2 - y1)

            # 如果没有重叠区域，直接返回底层
            if x1 >= x2 or y1 >= y2:
                return background.copy()

            # 提取背景和前景的重叠区域
            bg_roi = background[y1:y2, x1:x2].copy()
            fg_roi = fg_bgr[fg_y1:fg_y2, fg_x1:fg_x2].copy()

            # 如果前景Alpha是单值（无Alpha通道）
            if isinstance(fg_alpha, float):
                merged_roi = cv2.addWeighted(fg_roi, fg_alpha, bg_roi, 1 - fg_alpha, 0)
            else:
                # 如果前景有Alpha通道（需裁剪到ROI大小）
                alpha_roi = fg_alpha[fg_y1:fg_y2, fg_x1:fg_x2].copy()
                # 扩展Alpha通道为3维（与BGR匹配）
                alpha_roi_3d = np.stack([alpha_roi] * 3, axis=2)
                # 融合公式：前景*alpha + 背景*(1-alpha)
                merged_roi = fg_roi * alpha_roi_3d + bg_roi * (1 - alpha_roi_3d)
                merged_roi = merged_roi.astype(np.uint8)

            # 将融合区域放回底层图像
            result = background.copy()
            result[y1:y2, x1:x2] = merged_roi

            return result

        elif action == "nafnet_deblur":
            model_name = params.get('model_name', 'iic/cv_nafnet_image-deblur_reds')
            channel_index = params.get('channel_index', -1)

            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                """使用NAFNet进行图像去模糊"""
                try:
                    # 检查modelscope是否可用
                    try:
                        from modelscope.pipelines import pipeline
                        from modelscope.utils.constant import Tasks
                        from modelscope.outputs import OutputKeys
                    except ImportError:
                        logging.error(f"{traceback.format_exc()}")
                        return ch

                    # 确保图像是3通道的BGR格式
                    if len(ch.shape) == 2:
                        # 灰度图转BGR
                        ch_bgr = cv2.cvtColor(ch, cv2.COLOR_GRAY2BGR)
                    else:
                        ch_bgr = ch
                    import os
                    # 临时保存图像，因为ModelScope pipeline需要文件路径
                    temp_input_path = os.path.join(output_dir, f"temp_input_{step_index}.png")
                    temp_output_path = os.path.join(output_dir, f"temp_output_{step_index}.png")

                    # 保存临时输入文件
                    cv2.imwrite(temp_input_path, ch_bgr)

                    try:
                        # 创建去模糊pipeline
                        deblur_pipeline = pipeline(Tasks.image_deblurring, model_name)

                        # 执行去模糊
                        result = deblur_pipeline(temp_input_path)

                        # 获取输出图像
                        output_img = result[OutputKeys.OUTPUT_IMG]

                        # 确保输出是numpy数组
                        if not isinstance(output_img, np.ndarray):
                            output_img = np.array(output_img)

                        # 如果原图是灰度图，转换回灰度
                        if len(ch.shape) == 2:
                            output_img = cv2.cvtColor(output_img, cv2.COLOR_BGR2GRAY)

                        logging.info(f"NAFNet去模糊完成，输入形状: {ch.shape}, 输出形状: {output_img.shape}")
                        return output_img

                    except Exception as e:
                        logging.error(f"NAFNet处理失败: {e}  {traceback.format_exc()}")
                        return ch
                    finally:
                        import os
                        try:
                            if os.path.exists(temp_input_path):
                                os.remove(temp_input_path)
                            if os.path.exists(temp_output_path):
                                os.remove(temp_output_path)
                        except:
                            pass

                except Exception as e:
                    logging.error(f"NAFNet去模糊整体失败: {e}  {traceback.format_exc()}")
                    return ch

            return self._process_by_channel(image, process_single_channel, channel_index)

        elif action == "fast_nl_means_denoising":

            h = params.get('h', 10)
            template_window_size = self._ensure_odd(params.get('template_window_size', 7))
            search_window_size = self._ensure_odd(params.get('search_window_size', 21))
            channel_index = params.get("channel_index", -1)
            # 定义单通道处理函数（仅处理单通道，无需转灰度）
            def process_single_channel(ch: np.ndarray) -> np.ndarray:
                return cv2.fastNlMeansDenoising(
                    ch,
                    h=h,
                    templateWindowSize=template_window_size,
                    searchWindowSize=search_window_size
                )
            # 注意：输入若为多通道图，会按channel_index处理指定通道（不再强制转灰度）
            return self._process_by_channel(image, process_single_channel, channel_index)

            # 新增彩色非局部均值去噪（彩色图）
        # elif action == "fast_nl_means_denoising_colored":
        #     h = params.get('h', 10)
        #     h_color = params.get('h_color', 10)
        #     template_window_size = self._ensure_odd(params.get('template_window_size', 7))
        #     search_window_size = self._ensure_odd(params.get('search_window_size', 21))
        #     return cv2.fastNlMeansDenoisingColored(
        #         image,
        #         h=h,
        #         hColor=h_color,
        #         templateWindowSize=template_window_size,
        #         searchWindowSize=search_window_size
        #     )
        #
        # else:
        #     raise ValueError(f"未实现的图像处理动作: {action}")


class ImageChain:
    """图像处理链主类"""

    def __init__(self):
        self.processor = ImageProcessor()

    def process_chain(self, input_path: str, steps: List[Dict], output_dir: str) -> Dict:
        """处理整个图像处理链"""

        os.makedirs(output_dir, exist_ok=True)
        # 读取输入图像
        if not os.path.exists(input_path):
            raise FileNotFoundError(f"输入图像不存在: {input_path}")

        image = cv2.imread(input_path)
        if image is None:
            raise ValueError(f"无法读取图像文件: {input_path}")

        logging.info(f"成功读取图像: {input_path}, 形状: {image.shape}")

        original_path = os.path.join(output_dir, "original.jpg")
        cv2.imwrite(original_path, image)
        current_data = (image, {})
        step_results = []
        final_results = {}

        for i, step in enumerate(steps):
            try:
                step_result, next_data = self.processor.process_step(step, current_data, i, output_dir)
                step_results.append(step_result)

                # 更新当前图像为下一个步骤的输入
                if next_data is not None:
                    current_data = next_data

                # 收集数值结果
                if "numeric_result" in step_result:
                    final_results[f"step_{i}_{step['action']}"] = step_result["numeric_result"]
                if "list_count" in step_result:
                    final_results[f"step_{i}_{step['action']}_count"] = step_result["list_count"]

            except Exception as e:
                import traceback
                logging.error(f"步骤 {i} 执行失败: {str(e)}  {traceback.format_exc()}")
                step_results.append({
                    "step_id": step.get('id', i),
                    "action": step.get('action'),
                    "error": str(e),
                    "success": False
                })
                break

        # 准备最终结果
        result = {
            "success": True,
            "input_image": input_path,
            "output_dir": output_dir,
            "original_shape": image.shape,
            "step_results": step_results,
            "final_results": final_results,
            "total_steps": len(steps),
            "completed_steps": len([r for r in step_results if r.get('success', True)])
        }

        logging.info("图像处理链执行完成")
        return result


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='图像处理链')
    parser.add_argument('--task',           type=str, default='offline' ,required=False, help='任务类型: offline|online')
    parser.add_argument('--input_path',     type=str, default='./women.jpg',required=False, help='输入图像路径')
    parser.add_argument('--steps_filepath', type=str, default='./steps.json',required=False, help='步骤配置文件路径')
    parser.add_argument('--annotations',    type=str, default='[]', help='标注信息')
    parser.add_argument('--resultfile_path',type=str, default='./imagechain.json',required=False, help='结果文件路径')
    parser.add_argument('--log_path',       type=str, default='./imagechain.log',required=False, help='日志文件路径')
    parser.add_argument('--record_id',      type=int, default=111,required=False, help='记录ID')

    args = parser.parse_args()

    # 设置日志
    log_dir = os.path.dirname(args.log_path)
    log_file = os.path.basename(args.log_path).replace('.log', '')
    set_logging(log_dir=log_dir, file_name=log_file, mode='dev')

    try:
        # 读取步骤配置
        with open(args.steps_filepath, 'r', encoding='utf-8') as f:
            steps = json.load(f)

        logging.info(f"加载步骤配置: {len(steps)} 个步骤")
        # 创建输出目录
        output_dir = os.path.join(os.path.dirname(args.resultfile_path), "output_images")
        # 执行图像处理链
        chain = ImageChain()
        result = chain.process_chain(args.input_path, steps, output_dir)
        logging.info(f"result:{result}")
        # 保存结果
        with open(args.resultfile_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2, cls=NumpyEncoder)

        # 同时创建一个简化的结果用于日志输出
        simplified_result = {
            "success": result["success"],
            "input_image": result["input_image"],
            "total_steps": result["total_steps"],
            "completed_steps": result["completed_steps"],
            "final_results": result["final_results"]
        }

        # 添加步骤摘要
        step_summary = []
        for step in result["step_results"]:
            step_info = {
                "step_id": step.get("step_id"),
                "action": step.get("action"),
                "success": step.get("success", True)
            }
            if "numeric_result" in step:
                step_info["numeric_result"] = step["numeric_result"]
            if "list_count" in step:
                step_info["list_count"] = step["list_count"]
            step_summary.append(step_info)

        simplified_result["step_summary"] = step_summary

        logging.info(f"处理完成摘要: {json.dumps(simplified_result, ensure_ascii=False, indent=2)}")
        print(f"处理完成! 结果保存在: {args.resultfile_path}")

    except Exception as e:
        logging.error(f"图像处理链执行失败: {str(e)}")
        # 保存错误结果
        error_result = {
            "success": False,
            "error": str(e),
            "input_path": args.input_path,
            "record_id": args.record_id
        }
        with open(args.resultfile_path, 'w', encoding='utf-8') as f:
            json.dump(error_result, f, ensure_ascii=False, indent=2)
        sys.exit(1)


if __name__ == "__main__":
    main()