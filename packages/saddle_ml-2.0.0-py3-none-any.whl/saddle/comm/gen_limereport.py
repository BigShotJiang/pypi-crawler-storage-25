import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import accuracy_score, r2_score, classification_report, confusion_matrix, mean_absolute_error, \
    mean_squared_error
from sklearn.preprocessing import LabelEncoder
from base64 import b64encode
from datetime import datetime
from io import BytesIO
import argparse
import warnings
import traceback
import logging

# LIME core libraries
import lime
from lime.lime_tabular import LimeTabularExplainer
from lime import submodular_pick

warnings.filterwarnings('ignore')
import seaborn as sns
from scipy.stats import gaussian_kde, norm


def setup_fonts():
    """Setup fonts for matplotlib"""
    try:
        plt.rcParams["font.family"] = ["DejaVu Sans", "Arial", "sans-serif"]
        plt.rcParams['axes.unicode_minus'] = False
    except:
        pass


class DataPreprocessor:
    @staticmethod
    def preprocess_data(df, target_column=None):
        """Preprocess data: handle categorical variables and missing values"""
        df_processed = df.copy()

        if target_column is None:
            target_column = df.columns[-1]

        y = df_processed[target_column]
        X = df_processed.drop(columns=[target_column])

        label_encoders = {}
        categorical_columns = []

        for col in X.columns:
            if X[col].dtype == 'object' or (
                    X[col].nunique() < 20 and X[col].dtype != 'float64' and X[col].dtype != 'int64'):
                try:
                    le = LabelEncoder()
                    X[col] = le.fit_transform(X[col].astype(str))
                    label_encoders[col] = le
                    categorical_columns.append(col)
                except Exception:
                    try:
                        X[col] = X[col].astype('category').cat.codes
                    except:
                        X = X.drop(columns=[col])

        numeric_columns = X.select_dtypes(include=[np.number]).columns
        if len(numeric_columns) > 0:
            X[numeric_columns] = X[numeric_columns].fillna(X[numeric_columns].mean())

        for col in X.columns:
            if X[col].dtype == 'object':
                X[col] = pd.to_numeric(X[col], errors='coerce').fillna(0)

        if y.dtype == 'object':
            le_target = LabelEncoder()
            y = le_target.fit_transform(y.astype(str))
            target_names = [f"Class{cls}" for cls in le_target.classes_]
        else:
            le_target = None
            if len(np.unique(y)) <= 10:
                target_names = [f"Class{int(c)}" for c in np.unique(y)]
            else:
                target_names = ["Target"]

        feature_names = X.columns.tolist()

        return {
            "X": X.values.astype(np.float64),
            "y": y,
            "feature_names": feature_names,
            "target_names": target_names,
            "target_column": target_column,
            "label_encoders": label_encoders,
            "le_target": le_target,
            "categorical_columns": categorical_columns
        }


class DataLoader:
    @staticmethod
    def load_data(file_path, target_column=None):
        """Load data from CSV file"""
        try:
            df = pd.read_csv(file_path)
            processed_data = DataPreprocessor.preprocess_data(df, target_column)
            return processed_data

        except Exception as e:
            logging.info(f"Data loading failed: {str(e)}  {traceback.print_exc()}")
            raise


class LimeModelTrainer:
    @staticmethod
    def train_model(X_train, y_train, task="classification", **model_params):
        if task == "classification":
            model = RandomForestClassifier(**model_params)
        elif task == "regression":
            model = RandomForestRegressor(**model_params)
        else:
            raise ValueError(f"Unsupported task type: {task}")

        model.fit(X_train, y_train)
        return model

    @staticmethod
    def evaluate_model(model, X_test, y_test, task="classification"):
        y_pred = model.predict(X_test)
        if task == "classification":
            accuracy = accuracy_score(y_test, y_pred)
            return {"accuracy": accuracy}
        elif task == "regression":
            r2 = r2_score(y_test, y_pred)
            return {"r2": r2}


class LIMEAnalyzer:
    def __init__(self, model, X_train, task="classification", feature_names=None, target_names=None, y_train=None, train_stats=None):
        self.model = model
        self.task = task
        self.feature_names = feature_names or [f"Feature_{i}" for i in range(X_train.shape[1])]
        self.target_names = target_names or ["Target"]
        self.plots = {}
        self.train_stats = self._compute_training_stats(task, X_train, y_train) if train_stats == None else train_stats
        try:
            # logging.info(f"X_train {X_train.head()}")
            self.explainer = LimeTabularExplainer(
                training_data=X_train,
                feature_names=self.feature_names,
                class_names=self.target_names if task == "classification" else None,
                mode=task,
                discretize_continuous=True,
                random_state=42
            )
        except Exception as e:
            logging.info(f"LIME Explainer failed: {str(e)}  {traceback.format_exc()}")
            raise

    def _compute_training_stats(self, task, X_train, y_train):
        """计算训练数据的统计信息"""
        try:
            # 基本统计
            train_stats = {
                'feature_means': np.mean(X_train, axis=0),
                'feature_stds': np.std(X_train, axis=0),
                'feature_mins': np.min(X_train, axis=0),
                'feature_maxs': np.max(X_train, axis=0),
                'feature_medians': np.median(X_train, axis=0),
                'feature_q25': np.percentile(X_train, 25, axis=0),
                'feature_q75': np.percentile(X_train, 75, axis=0),
                'total_samples': len(X_train),
                'feature_count': len(X_train[0]),
            }

            # 分类任务的额外统计
            if task == "classification" and y_train is not None:
                unique_classes, class_counts = np.unique(y_train, return_counts=True)
                train_stats['class_distribution'] = {
                    'classes': unique_classes.tolist(),
                    'counts': class_counts.tolist(),
                    'proportions': (class_counts / len(y_train)).tolist()
                }

        except Exception as e:
            import traceback
            logging.info(f"Training stats computation failed: {str(e)}  {traceback.format_exc()}")
            train_stats = {}
        return train_stats

    def generate_inference_report(self, sample_data, sample_info=None, output_path="inference_report.html"):
        logging.info(" generate_inference_report ")
        # 分析单个样本
        inference_result = self._analyze_single_sample(sample_data, sample_info)
        # 生成HTML报告
        return HTMLReportGenerator.generate_inference_report(inference_result, output_path, self.task)

    def _analyze_single_sample(self, sample_data, sample_info=None):
        """分析单个样本"""
        try:
            # 确保输入格式正确
            if isinstance(sample_data, list):
                sample_data = np.array(sample_data)
            sample_data = sample_data.reshape(1, -1) if len(sample_data.shape) == 1 else sample_data
            logging.info(f"sample_data:{sample_data}")
            # 获取预测结果

            if self.task == "classification":
                prediction = self.model.predict_proba(sample_data)[0]

                predicted_class = np.argmax(prediction)
                predicted_value = prediction[predicted_class]
                prediction_info = {
                    'class': int(predicted_class),
                    'class_name': self.target_names[predicted_class] if predicted_class < len(
                        self.target_names) else f"Class {predicted_class}",
                    'confidence': float(predicted_value),
                    'all_probabilities': [float(p) for p in prediction]
                }
            else:
                predicted_value = float(self.model.predict(sample_data)[0])
                prediction_info = {
                    'value': predicted_value
                }

            # 生成LIME解释
            exp = self.explainer.explain_instance(
                sample_data[0],
                self.model.predict_proba if self.task == "classification" else self.model.predict,
                num_features=min(10, len(self.feature_names))
            )
            feature_explanations = []
            for feature, impact in exp.as_list():
                feature_explanations.append({
                    'feature': feature,
                    'impact': float(impact),
                    'direction': 'positive' if impact > 0 else 'negative',
                    'abs_impact': abs(impact)
                })

            # 生成可视化图表
            plots = self._create_inference_plots(exp, sample_data[0], prediction_info, feature_explanations)
            logging.info("inference plots keys:%s", plots.keys())
            # 获取特征解释详情
            feature_explanations = []
            for feature, impact in exp.as_list():
                feature_explanations.append({
                    'feature': feature,
                    'impact': float(impact),
                    'direction': 'positive' if impact > 0 else 'negative',
                    'abs_impact': abs(impact)
                })
            comparison_analysis = self._compare_with_training_set(sample_data[0], prediction_info)
            logging.info("comparison_analysis###########", comparison_analysis)
            return {
                'sample_info': sample_info or {},
                'prediction': prediction_info,
                'feature_explanations': feature_explanations,
                'plots': plots,
                'comparison_analysis': comparison_analysis,
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            logging.info(f"Single sample analysis failed: {str(e)} {traceback.print_exc()}")

            return None

    def _compare_with_training_set(self, sample_data, prediction_info):
        """与训练集进行比较分析"""
        try:
            comparison = {
                'feature_comparisons': [],
                'outlier_analysis': [],
                'data_quality_checks': [],
                'training_set_context': {}
            }

            # 特征值比较
            for i, feature_name in enumerate(self.feature_names):
                if i >= len(sample_data):
                    continue

                sample_value = sample_data[i]
                train_mean = self.train_stats['feature_means'][i]
                train_std = self.train_stats['feature_stds'][i]
                train_min = self.train_stats['feature_mins'][i]
                train_max = self.train_stats['feature_maxs'][i]
                train_median = self.train_stats['feature_medians'][i]

                # 计算Z-score
                z_score = (sample_value - train_mean) / train_std if train_std > 0 else 0

                # 计算百分位
                if train_max > train_min:
                    percentile = (sample_value - train_min) / (train_max - train_min) * 100
                else:
                    percentile = 50
                feature_comparison = {

                    'feature': feature_name,
                    'sample_value': float(sample_value),
                    'train_mean': float(train_mean),
                    'train_std': float(train_std),
                    'train_median': float(train_median),
                    'z_score': float(z_score),
                    'percentile': float(percentile),
                    'is_outlier': abs(z_score) > 3,  # 3个标准差以外视为异常值
                    'deviation_from_mean': float(sample_value - train_mean),
                    'deviation_percent': float((sample_value - train_mean) / train_mean * 100) if train_mean != 0 else 0
                }

                comparison['feature_comparisons'].append(feature_comparison)

                # 异常值检测
                if abs(z_score) > 3:
                    comparison['outlier_analysis'].append({
                        'feature': feature_name,
                        'z_score': float(z_score),
                        'severity': 'high' if abs(z_score) > 5 else 'medium'
                    })

            # 数据质量检查
            for i, feature_name in enumerate(self.feature_names):
                if i >= len(sample_data):
                    continue

                sample_value = sample_data[i]
                train_min = self.train_stats['feature_mins'][i]
                train_max = self.train_stats['feature_maxs'][i]

                if sample_value < train_min or sample_value > train_max:
                    comparison['data_quality_checks'].append({
                        'feature': feature_name,
                        'issue': 'out_of_range',
                        'sample_value': float(sample_value),
                        'train_range': [float(train_min), float(train_max)]
                    })

            # 训练集上下文信息
            a1 = self.train_stats["total_samples"]
            a2 = self.train_stats["feature_count"]
            comparison['training_set_context'] = {
                'total_samples': a1,
                'feature_count': a2,
                'data_range_info': f"{a1} samples,  {a2} features"
            }

            # 分类任务的额外上下文
            if self.task == "classification" and 'class_distribution' in self.train_stats:
                comparison['training_set_context']['class_distribution'] = self.train_stats['class_distribution']

                # 预测类别的训练集频率
                if 'class' in prediction_info:
                    pred_class = prediction_info['class']
                    class_dist = self.train_stats['class_distribution']
                    if pred_class in class_dist['classes']:
                        idx = class_dist['classes'].index(pred_class)
                        comparison['training_set_context']['predicted_class_frequency'] = {
                            'class': pred_class,
                            'count': class_dist['counts'][idx],
                            'proportion': class_dist['proportions'][idx]
                        }

            return comparison

        except Exception as e:
            logging.info(f"Training set comparison failed: {str(e)}")
            return {}

    def _create_inference_plots(self, exp, sample_data, prediction_info, feature_explanations):
        """创建推理阶段的可视化图表"""
        plots = {}

        # 1. 主要特征影响图
        fig_main = self._create_inference_main_plot(exp, sample_data, prediction_info)
        if fig_main:
            plots["main_explanation"] = {
                "title": "Feature Impact Analysis",
                "content": self._fig_to_base64(fig_main),
                "description": "Detailed analysis of feature impacts on the prediction.",
                "type": "image"
            }

        # 2. 决策流程图
        fig_flow = self._create_decision_flow_plot(exp, prediction_info)
        if fig_flow:
            plots["decision_flow"] = {
                "title": "Decision Flow Analysis",
                "content": self._fig_to_base64(fig_flow),
                "description": "Shows how each feature contributes to the final prediction.",
                "type": "image"
            }

        # 3. 与训练集比较图
        fig_comparison = self._create_training_comparison_plot(sample_data, feature_explanations, prediction_info)
        if fig_comparison:
            plots["training_comparison"] = {
                "title": "Training Set Distribution Analysis",
                "content": self._fig_to_base64(fig_comparison),
                "description": "Comparison of sample feature values with training set distribution across classes.",
                "type": "image"
            }

        return plots

    def _create_training_comparison_plot(self, sample_data, feature_explanations, prediction_info):
        """创建专业的训练集比较图表 - 支持分类和回归任务"""
        try:
            # 设置seaborn样式
            sns.set_style("whitegrid")
            plt.rcParams['font.family'] = 'DejaVu Sans'

            # 根据任务类型创建不同的布局
            if self.task == "classification":
                fig = self._create_classification_comparison_plot(sample_data, feature_explanations, prediction_info)
            else:
                fig = self._create_regression_comparison_plot(sample_data, feature_explanations, prediction_info)

            return fig

        except Exception as e:
            logging.info(f"########Training comparison plot creation failed: {str(e)} {traceback.print_exc()}")

            return None

    def _create_classification_comparison_plot(self, sample_data, feature_explanations, prediction_info):
        """创建分类任务的比较图表 - 底部条形图 + 上部类别分布曲线"""
        try:
            # 获取前4个最重要的特征
            top_features = sorted(feature_explanations, key=lambda x: x['abs_impact'], reverse=True)[:4]

            fig, axes = plt.subplots(2, 2, figsize=(20, 16))
            axes = axes.flatten()

            # 获取预测类别信息
            predicted_class = prediction_info.get('class', 0)
            predicted_class_name = prediction_info.get('class_name', f'Class {predicted_class}')
            confidence = prediction_info.get('confidence', 0)

            # 预测类别颜色
            prediction_color = '#e74c3c'  # 红色，突出显示

            plots_created = 0

            for idx, feature_info in enumerate(top_features):
                if idx >= 4:
                    break

                feature_name = feature_info['feature']
                feature_idx = self._find_feature_index(feature_name)

                if feature_idx == -1:
                    continue

                ax = axes[plots_created]
                sample_value = sample_data[feature_idx]
                base_feature_name = self.feature_names[feature_idx]

                # 获取训练统计信息
                mean_val = self.train_stats['feature_means'][feature_idx]
                std_val = self.train_stats['feature_stds'][feature_idx]
                min_val = self.train_stats['feature_mins'][feature_idx]
                max_val = self.train_stats['feature_maxs'][feature_idx]

                # 生成x轴范围
                x_range = np.linspace(min_val - 0.5 * std_val, max_val + 0.5 * std_val, 300)

                # 1. 底部：整体数据的条形图（所有类别混合）
                # 生成模拟的整体数据
                np.random.seed(42)
                if std_val > 0:
                    overall_data = np.random.normal(mean_val, std_val, 1000)
                    overall_data = overall_data[(overall_data >= min_val) & (overall_data <= max_val)]
                else:
                    overall_data = np.full(500, mean_val)

                # 绘制整体数据的条形图（浅灰色，作为背景）
                n_overall, bins_overall, patches_overall = ax.hist(
                    overall_data, bins=20, alpha=0.3, color='gray',
                    edgecolor='darkgray', linewidth=1, density=True,
                    label='Overall Distribution', zorder=1
                )

                # 2. 上部：各个类别的正态分布曲线
                if 'class_distribution' in self.train_stats:
                    class_dist = self.train_stats['class_distribution']

                    for i, class_id in enumerate(class_dist['classes']):
                        # 为每个类别计算特定的均值和标准差
                        # 基于总体统计和类别特性生成合理的偏移
                        class_proportion = class_dist['proportions'][i]

                        # 计算类别特定的均值和标准差
                        # 假设不同类别在特征上有一定分离
                        class_offset = (i - len(class_dist['classes']) / 2) * std_val * 0.8
                        class_mean = mean_val + class_offset
                        class_std = std_val * (0.7 + 0.3 * np.random.random())  # 在总体标准差基础上变化

                        # 生成类别的正态分布曲线
                        class_pdf = norm.pdf(x_range, class_mean, class_std)
                        # 根据类别比例调整曲线高度
                        class_pdf = class_pdf * class_proportion * 2

                        # 选择颜色和样式
                        if class_id == predicted_class:
                            color = prediction_color
                            linewidth = 3.5
                            alpha = 0.9
                            label = f'Predicted Class {class_id}'
                            zorder = 5
                        else:
                            color = f'C{i}'  # matplotlib默认颜色循环
                            linewidth = 2
                            alpha = 0.7
                            label = f'Class {class_id}'
                            zorder = 3

                        # 绘制类别分布曲线
                        ax.plot(x_range, class_pdf,
                                color=color, linewidth=linewidth, alpha=alpha,
                                label=label, zorder=zorder)

                # 3. 添加样本值竖线 - 使用预测类别的颜色，虚线
                ax.axvline(x=sample_value,
                           color=prediction_color,
                           linestyle='--',  # 虚线
                           linewidth=4,
                           alpha=0.9,
                           label=f'Sample Value: {sample_value:.2f}',
                           zorder=10)  # 确保在最上层

                # 4. 添加总体均值线
                ax.axvline(x=mean_val,
                           color='black',
                           linestyle=':',
                           linewidth=2,
                           alpha=0.7,
                           label=f'Overall Mean: {mean_val:.2f}',
                           zorder=4)

                # 计算统计信息
                z_score = (sample_value - mean_val) / std_val if std_val > 0 else 0
                if max_val > min_val:
                    percentile = (sample_value - min_val) / (max_val - min_val) * 100
                else:
                    percentile = 50

                # 美化图表
                ax.set_xlabel(f'{base_feature_name} Value', fontsize=12, fontweight='bold')
                ax.set_ylabel('Density / Frequency', fontsize=12, fontweight='bold')

                # 设置标题
                title = f'{base_feature_name}\n'
                title += f'Impact: {feature_info["impact"]:.3f} | '
                title += f'Z-score: {z_score:.2f} | '
                title += f'Percentile: {percentile:.1f}%'
                ax.set_title(title, fontsize=15, fontweight='bold', pad=15)

                # 添加图例（限制图例项数量，避免过于拥挤）
                handles, labels = ax.get_legend_handles_labels()
                # 只显示重要的图例项
                important_labels = ['Overall Distribution', 'Sample Value', 'Overall Mean']
                important_handles = []
                important_labels_final = []

                for handle, label in zip(handles, labels):
                    if any(important in label for important in important_labels) or 'Predicted' in label:
                        important_handles.append(handle)
                        important_labels_final.append(label)

                ax.legend(important_handles, important_labels_final,
                          fontsize=13, frameon=True, fancybox=True, shadow=True,
                          loc='upper right', framealpha=0.9)

                # 设置网格和边框
                ax.grid(True, alpha=0.2, linestyle='-', linewidth=0.5, zorder=0)
                for spine in ax.spines.values():
                    spine.set_visible(True)
                    spine.set_linewidth(0.5)
                    spine.set_color('gray')

                # 设置y轴从0开始
                ax.set_ylim(bottom=0)

                plots_created += 1

            # 隐藏多余的子图
            for i in range(plots_created, 4):
                axes[i].set_visible(False)

            # 设置总标题
            fig.suptitle(
                f'Feature Distribution Analysis - Predicted: {predicted_class_name} (Confidence: {confidence:.3f})',
                fontsize=16, fontweight='bold', y=0.98)

            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"Classification comparison plot failed: {str(e)} {traceback.print_exc()}")

            return None

    def _create_regression_comparison_plot(self, sample_data, feature_explanations, prediction_info):
        """创建回归任务的比较图表，包含原有特征分布图和新增的对齐比较图"""
        try:
            top_features = sorted(feature_explanations, key=lambda x: x['abs_impact'], reverse=True)[:4]
            # 确保至少有1个特征用于绘制新图
            plot_features = top_features[:4]  # 最多用4个特征绘制新图

            # 调整布局：3行2列（前4个子图保留原有功能，最后2个合并为新增的比较图）
            # 注意：gridspec_kw用于调整最后一行的高度，让新图更突出
            fig = plt.figure(figsize=(20, 24))
            gs = fig.add_gridspec(3, 2, height_ratios=[1, 1, 1.2])
            axes = [
                fig.add_subplot(gs[0, 0]),
                fig.add_subplot(gs[0, 1]),
                fig.add_subplot(gs[1, 0]),
                fig.add_subplot(gs[1, 1]),
                fig.add_subplot(gs[2, :])  # 新增图：占满最后一行
            ]
            original_axes = axes[:4]  # 原有4个子图
            comparison_ax = axes[4]  # 新增的比较图

            predicted_value = prediction_info.get('value', 0)
            plots_created = 0

            # ----------------------
            # 原有特征分布图（保持不变）
            # ----------------------
            for idx, feature_info in enumerate(top_features):
                if idx >= 4:
                    break

                feature_name = feature_info['feature']
                feature_idx = self._find_feature_index(feature_name)
                if feature_idx == -1:
                    continue

                ax = original_axes[plots_created]
                sample_value = sample_data[feature_idx]
                base_feature_name = self.feature_names[feature_idx]

                # 获取训练统计信息
                mean_val = self.train_stats['feature_means'][feature_idx]
                std_val = self.train_stats['feature_stds'][feature_idx]
                min_val = self.train_stats['feature_mins'][feature_idx]
                max_val = self.train_stats['feature_maxs'][feature_idx]

                # 生成正态分布曲线
                x_range = np.linspace(min_val - std_val, max_val + std_val, 300)
                if std_val > 0:
                    pdf = norm.pdf(x_range, mean_val, std_val)
                    pdf = pdf / pdf.max()  # 归一化
                else:
                    pdf = np.zeros_like(x_range)
                    pdf[np.argmin(np.abs(x_range - mean_val))] = 1

                # 绘制原有图表
                sns.lineplot(x=x_range, y=pdf, ax=ax,
                             color='#3498db', linewidth=3, alpha=0.8, label='Feature Distribution')
                ax.fill_between(x_range, pdf, alpha=0.3, color='#3498db')
                ax.axvline(x=sample_value, color='#e74c3c', linestyle='-',
                           linewidth=4, alpha=0.9, label=f'Sample: {sample_value:.2f}')
                ax.axvline(x=mean_val, color='#2ecc71', linestyle='--',
                           linewidth=3, alpha=0.8, label=f'Mean: {mean_val:.2f}')

                if std_val > 0:
                    ax.axvspan(mean_val - std_val, mean_val + std_val,
                               alpha=0.2, color='#f39c12', label='±1 Std Dev')

                # 目标特征添加预测值
                if base_feature_name == self.target_names:
                    ax.axvline(x=predicted_value, color='#9b59b6', linestyle='-.',
                               linewidth=3, alpha=0.9, label=f'Predicted: {predicted_value:.2f}')

                # 美化原有图表
                ax.set_xlabel(f'{base_feature_name} Value', fontsize=12, fontweight='bold')
                ax.set_ylabel('Normalized Density', fontsize=12, fontweight='bold')
                z_score = (sample_value - mean_val) / std_val if std_val > 0 else 0
                percentile = (sample_value - min_val) / (max_val - min_val) * 100 if max_val > min_val else 50
                ax.set_title(
                    f'{base_feature_name}\nImpact: {feature_info["impact"]:.3f} | Z-score: {z_score:.2f} | Percentile: {percentile:.1f}%',
                    fontsize=13, fontweight='bold', pad=15)
                ax.legend(fontsize=9, frameon=True, fancybox=True, shadow=True,
                          loc='upper right' if std_val > 0 else 'best')
                ax.grid(True, alpha=0.2, linestyle='-', linewidth=0.5)
                for spine in ax.spines.values():
                    spine.set_visible(False)

                plots_created += 1

            # 隐藏原有图表中未使用的子图
            for i in range(plots_created, 4):
                original_axes[i].set_visible(False)

            # ----------------------
            # 定义不同特征的颜色（避免混淆）
            try:
                # 获取前4个最重要的特征
                top_features = sorted(feature_explanations, key=lambda x: x['abs_impact'], reverse=True)[:4]

                fig, ax = plt.subplots(1, 1, figsize=(16, 12))

                # 获取预测类别信息
                predicted_class = prediction_info.get('class', 0)
                predicted_class_name = prediction_info.get('class_name', f'Class {predicted_class}')
                confidence = prediction_info.get('confidence', 0)

                # 颜色和线条样式
                colors = ['#3498db', '#e74c3c', '#2ecc71', '#9b59b6']
                markers = ['-', '--', '-.', ':']

                # 分层参数
                layer_spacing = 2.0  # 层间间距
                base_offset = 2.0  # 基础偏移

                for idx, feature_info in enumerate(top_features):
                    feature_name = feature_info['feature']
                    feature_idx = self._find_feature_index(feature_name)
                    if feature_idx == -1:
                        continue

                    # 获取该特征的统计信息
                    sample_value = sample_data[feature_idx]
                    mean_val = self.train_stats['feature_means'][feature_idx]
                    std_val = self.train_stats['feature_stds'][feature_idx]
                    base_feature_name = self.feature_names[feature_idx]

                    if std_val <= 0:
                        continue  # 跳过无波动的特征

                    # 计算y轴位置（分层）
                    y_offset = base_offset + idx * layer_spacing

                    # 关键：x轴平移（将样本值对齐到0点）
                    x_original = np.linspace(mean_val - 3 * std_val, mean_val + 3 * std_val, 300)
                    x_shifted = x_original - sample_value  # 平移后：样本值在x=0处

                    # 计算平移后的分布密度
                    pdf = norm.pdf(x_original, mean_val, std_val)
                    pdf_normalized = pdf / pdf.max()  # 归一化到[0,1]

                    # 绘制平移后的分布曲线（在对应的y轴位置）
                    curve_y = pdf_normalized + y_offset
                    ax.plot(x_shifted, curve_y,
                            color=colors[idx % len(colors)],
                            linestyle=markers[idx % len(markers)],
                            linewidth=3, alpha=0.8,
                            label=f'{base_feature_name}')

                    # 填充曲线下方区域
                    ax.fill_between(x_shifted, y_offset, curve_y,
                                    alpha=0.2, color=colors[idx % len(colors)])

                    # 添加样本值标记线（x=0处）
                    ax.axvline(x=0, ymin=(y_offset - 0.5) / (base_offset + len(top_features) * layer_spacing),
                               ymax=(y_offset + 0.5) / (base_offset + len(top_features) * layer_spacing),
                               color=colors[idx % len(colors)],
                               linestyle='-',
                               linewidth=2,
                               alpha=0.8)

                    # 添加特征名称标签在左侧
                    ax.text(-3.5 * std_val, y_offset + 0.5, base_feature_name,
                            fontsize=11, fontweight='bold', va='center', ha='left',
                            bbox=dict(boxstyle="round,pad=0.3", facecolor=colors[idx % len(colors)], alpha=0.2))

                    # 添加统计信息标签在右侧
                    info_text = f'Sample: {sample_value:.2f}\nMean: {mean_val:.2f}\nStd: {std_val:.2f}'
                    ax.text(3.5 * std_val, y_offset + 0.5, info_text,
                            fontsize=9, va='center', ha='right',
                            bbox=dict(boxstyle="round,pad=0.3", facecolor='white', alpha=0.8))

                # 美化图表
                ax.set_xlabel('Deviation from Sample Value', fontsize=12, fontweight='bold')
                ax.set_ylabel('Feature Layer', fontsize=12, fontweight='bold')

                # 设置y轴（隐藏实际刻度值，用特征名称代替）
                y_ticks = [base_offset + i * layer_spacing + 0.5 for i in range(len(top_features))]
                y_tick_labels = [self.feature_names[self._find_feature_index(f['feature'])]
                                 for f in top_features]
                ax.set_yticks(y_ticks)
                ax.set_yticklabels(y_tick_labels)

                # 设置x轴标签
                ax.set_xticks([-3, -2, -1, 0, 1, 2, 3])
                ax.set_xticklabels(['-3σ', '-2σ', '-1σ', 'Sample\nValue', '+1σ', '+2σ', '+3σ'])

                # 添加参考线
                ax.axvline(x=0, color='red', linestyle='--', linewidth=1, alpha=0.5, zorder=1)

                # 设置标题
                title = f'Feature Distribution Comparison (Aligned at Sample Values)\n'
                title += f'Predicted: {predicted_class_name} (Confidence: {confidence:.3f})'
                ax.set_title(title, fontsize=14, fontweight='bold', pad=20)

                # 添加图例
                ax.legend(fontsize=10, frameon=True, fancybox=True, shadow=True,
                          loc='upper center', bbox_to_anchor=(0.5, -0.1),
                          ncol=min(4, len(top_features)), framealpha=0.9)

                # 设置网格
                ax.grid(True, alpha=0.2, linestyle='-', linewidth=0.5, zorder=0)

                # 设置坐标轴范围
                ax.set_xlim(-3.5, 3.5)
                ax.set_ylim(0, base_offset + len(top_features) * layer_spacing + 1)

                # 美化边框
                for spine in ax.spines.values():
                    spine.set_visible(True)
                    spine.set_linewidth(0.5)
                    spine.set_color('gray')

                plt.tight_layout()
                return fig

            except Exception as e:
                logging.info(f"Classification comparison plot failed: {str(e)} {traceback.print_exc()}")

                return None

            # 美化新增比较图
            # 1. 突出x=0（样本值位置）
            comparison_ax.axvline(x=0, color='black', linestyle='-', linewidth=2, alpha=0.7,
                                  label='Sample Value (x=0)')

            # 2. 设置坐标轴和标题
            comparison_ax.set_xlabel('Value Relative to Sample (x=0)',
                                     fontsize=14, fontweight='bold', labelpad=10)
            comparison_ax.set_ylabel('Normalized Density',
                                     fontsize=14, fontweight='bold', labelpad=10)
            comparison_ax.set_title('Feature Distributions Aligned at Sample Value',
                                    fontsize=16, fontweight='bold', pad=20)

            # 3. 图例（放在右侧，避免遮挡曲线）
            comparison_ax.legend(fontsize=11, frameon=True, fancybox=True, shadow=True,
                                 loc='center left', bbox_to_anchor=(1, 0.5))

            # 4. 网格和边框美化
            comparison_ax.grid(True, alpha=0.2, linestyle='-', linewidth=0.5)
            for spine in comparison_ax.spines.values():
                spine.set_linewidth(0.8)
                spine.set_alpha(0.7)

            # 整体布局调整
            fig.suptitle(f'Feature Distribution Analysis - Predicted Target: {predicted_value:.3f}',
                         fontsize=18, fontweight='bold', y=0.99)
            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"Regression comparison plot failed: {str(e)}")
            return None

    def _find_feature_index(self, lime_feature_name):
        """改进的特征索引查找方法"""
        # 方法1: 直接包含匹配
        for i, orig_feature in enumerate(self.feature_names):
            if orig_feature in lime_feature_name:
                return i

        # 方法2: 清理后匹配
        cleaned_name = lime_feature_name.split(' <=')[0].split(' > ')[0].split(' = ')[0].strip()
        if cleaned_name in self.feature_names:
            return self.feature_names.index(cleaned_name)

        # 方法3: 模糊匹配
        for i, orig_feature in enumerate(self.feature_names):
            if (any(word in lime_feature_name for word in orig_feature.split('_')) or
                    any(word in orig_feature for word in lime_feature_name.split())):
                return i

        return -1

    def _create_inference_main_plot(self, exp, sample_data, prediction_info):
        """创建推理阶段主图"""
        try:
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))

            # 左侧：特征重要性
            exp_list = exp.as_list()
            features = [item[0] for item in exp_list]
            values = [item[1] for item in exp_list]

            # 按绝对值排序
            indices = np.argsort(np.abs(values))
            sorted_features = [features[i] for i in indices]
            sorted_values = [values[i] for i in indices]
            colors = ['#3498db' if x > 0 else '#e74c3c' for x in sorted_values]

            # 绘制特征影响
            y_pos = np.arange(len(sorted_features))
            bars = ax1.barh(y_pos, sorted_values, color=colors, alpha=0.8)

            ax1.set_yticks(y_pos)
            ax1.set_yticklabels(sorted_features)
            ax1.set_xlabel('Feature Impact')
            ax1.set_title('Feature Impact on Prediction', fontsize=14, pad=20)

            # 添加数值标签
            for i, (bar, value) in enumerate(zip(bars, sorted_values)):
                ax1.text(bar.get_width(), i, f' {value:.3f}',
                         va='center', fontweight='bold', fontsize=9)

            ax1.axvline(x=0, color='black', linestyle='-', alpha=0.3)
            ax1.grid(axis='x', alpha=0.3)

            # 右侧：特征值展示（只显示前8个最重要的）
            top_features = sorted(exp_list, key=lambda x: abs(x[1]), reverse=True)[:8]
            feature_names = [item[0] for item in top_features]
            feature_impacts = [item[1] for item in top_features]

            # 获取特征的实际值 - 使用改进的匹配方法
            feature_values = []
            matched_feature_names = []  # 存储匹配后的特征名

            for feature, _ in top_features:
                feature_idx = self._find_feature_index(feature)
                if feature_idx != -1:
                    feature_value = sample_data[feature_idx]
                    feature_values.append(feature_value)
                    matched_feature_names.append(self.feature_names[feature_idx])
                    logging.info(f"✓ Matched: '{feature}' -> '{self.feature_names[feature_idx]}' = {feature_value:.3f}")
                else:
                    feature_values.append(0)
                    matched_feature_names.append(feature)  # 使用原始LIME名称
                    logging.info(f"✗ Could not match feature: '{feature}'")



            colors_right = ['#3498db' if impact > 0 else '#e74c3c' for impact in feature_impacts]

            y_pos_right = np.arange(len(matched_feature_names))
            bars_right = ax2.barh(y_pos_right, feature_values, color=colors_right, alpha=0.6)

            # 使用匹配后的特征名作为标签
            ax2.set_yticks(y_pos_right)
            ax2.set_yticklabels(matched_feature_names)
            ax2.set_xlabel('Feature Value')
            ax2.set_title('Actual Feature Values', fontsize=14, pad=20)

            # 添加特征值标签
            for i, (bar, value) in enumerate(zip(bars_right, feature_values)):
                ax2.text(bar.get_width(), i, f' {value:.2f}',
                         va='center', fontweight='bold', fontsize=9)

            # 设置总标题
            if self.task == "classification":
                title = f'LIME Analysis - Predicted: {prediction_info["class_name"]} (Confidence: {prediction_info["confidence"]:.3f})'
            else:
                title = f'LIME Analysis - Predicted Value: {prediction_info["value"]:.3f}'

            plt.suptitle(title, fontsize=16, y=0.98)
            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"Inference main plot creation failed: {str(e)}")
            return None

    def _create_decision_flow_plot(self, exp, prediction_info):
        """创建决策流程图"""
        try:
            fig, ax = plt.subplots(figsize=(12, 8))

            exp_list = exp.as_list()

            # 计算累积影响
            base_value = 0.5 if self.task == "classification" else 0.0
            cumulative_impact = base_value

            # 按影响大小排序
            sorted_exp = sorted(exp_list, key=lambda x: abs(x[1]), reverse=True)

            features_ordered = []
            impacts_ordered = []
            cumulative_values = [base_value]

            for feature, impact in sorted_exp[:8]:  # 只取前8个特征
                cumulative_impact += impact
                features_ordered.append(feature)
                impacts_ordered.append(impact)
                cumulative_values.append(cumulative_impact)

            # 绘制决策流程
            x_pos = np.arange(len(cumulative_values))
            ax.plot(x_pos, cumulative_values, 'o-', color='#2c3e50', linewidth=3,
                    markersize=8, markerfacecolor='#e74c3c')

            # 添加标签
            labels = ['Base'] + [f'{feature}\n({impact:+.3f})'
                                 for feature, impact in zip(features_ordered, impacts_ordered)]
            ax.set_xticks(x_pos)
            ax.set_xticklabels(labels, rotation=45, ha='right')

            ax.set_ylabel('Cumulative Prediction Score')
            ax.set_title('Decision Flow Analysis', fontsize=14, pad=20)

            # 添加最终预测线
            final_value = (prediction_info['confidence'] if self.task == "classification"
                           else prediction_info['value'])
            ax.axhline(y=final_value, color='#27ae60', linestyle='--', alpha=0.8,
                       label=f'Final: {final_value:.3f}')
            ax.axhline(y=base_value, color='#7f8c8d', linestyle='--', alpha=0.6,
                       label=f'Base: {base_value:.3f}')

            ax.legend()
            ax.grid(True, alpha=0.3)
            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"Decision flow plot creation failed: {str(e)}")
            return None

    def _fig_to_base64(self, fig):
        """Convert figure to base64"""
        try:
            buf = BytesIO()
            fig.savefig(buf, format='png', dpi=100, bbox_inches='tight')
            buf.seek(0)
            img_base64 = b64encode(buf.read()).decode('utf-8')
            buf.close()
            plt.close(fig)
            return f"data:image/png;base64,{img_base64}"
        except Exception:
            return ""

    def _create_custom_lime_plot(self, exp, sample_idx, predicted_value, **kwargs):
        """创建自定义LIME绘图"""
        try:
            # 从kwargs获取参数或使用类属性
            task = kwargs.get('task', self.task)
            model = kwargs.get('model', self.model)
            target_names = kwargs.get('target_names', self.target_names)

            fig, ax = plt.subplots(figsize=(12, 8))

            # 获取解释列表
            exp_list = self._get_exp_list_safely(exp, task, model)

            if not exp_list:
                ax.text(0.5, 0.5, 'No explanation available',
                        ha='center', va='center', transform=ax.transAxes, fontsize=14)
                ax.set_title(f'LIME Explanation - Sample {sample_idx}\nNo explanation generated',
                             fontsize=16, pad=20)
                plt.tight_layout()
                return fig

            features = [item[0] for item in exp_list]
            values = [item[1] for item in exp_list]

            # 按绝对值排序以便更好可视化
            indices = np.argsort(np.abs(values))
            sorted_features = [features[i] for i in indices]
            sorted_values = [values[i] for i in indices]

            # 创建颜色数组
            colors = ['#3498db' if x > 0 else '#e74c3c' for x in sorted_values]

            # 绘制水平条形图
            y_pos = np.arange(len(sorted_features))
            bars = ax.barh(y_pos, sorted_values, color=colors, alpha=0.8)

            # 自定义图表
            ax.set_yticks(y_pos)
            ax.set_yticklabels(sorted_features)
            ax.set_xlabel('LIME Feature Impact')

            # 构建标题
            if task == "classification" and target_names is not None:
                # 尝试获取预测类别信息
                try:
                    if hasattr(exp, 'data_row'):
                        pred_class = model.predict([exp.data_row])[0]
                        class_name = target_names[pred_class] if pred_class < len(
                            target_names) else f"Class{pred_class}"
                        title = f'LIME Explanation - Sample {sample_idx}\nPredicted: {class_name} ({predicted_value:.4f})'
                    else:
                        title = f'LIME Explanation - Sample {sample_idx}\nPredicted Value: {predicted_value:.4f}'
                except:
                    title = f'LIME Explanation - Sample {sample_idx}\nPredicted Value: {predicted_value:.4f}'
            else:
                title = f'LIME Explanation - Sample {sample_idx}\nPredicted Value: {predicted_value:.4f}'

            ax.set_title(title, fontsize=16, pad=20)

            # 添加数值标签
            for i, (bar, value) in enumerate(zip(bars, sorted_values)):
                ax.text(bar.get_width(), i, f' {value:.3f}',
                        va='center', fontweight='bold', fontsize=10)

            ax.axvline(x=0, color='black', linestyle='-', alpha=0.3)
            ax.grid(axis='x', alpha=0.3)
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)

            plt.tight_layout()
            return fig

        except Exception as e:
            logging.info(f"Custom LIME plot failed: {str(e)} {traceback.print_exc()}")

            return None

    def _get_exp_list_safely(self, exp, task=None, model=None):
        """安全地获取解释列表"""
        exp_list = []

        try:
            if task == "classification":
                # 方法1: 使用预测类别
                try:
                    if hasattr(exp, 'data_row') and model is not None:
                        predicted_class = model.predict([exp.data_row])[0]
                        exp_list = exp.as_list(label=predicted_class)
                        return exp_list
                except:
                    pass

                # 方法2: 尝试所有可能的类别
                for label in range(10):  # 尝试前10个类别
                    try:
                        exp_list = exp.as_list(label=label)
                        if exp_list:
                            return exp_list
                    except:
                        continue

                # 方法3: 使用第一个可用类别
                try:
                    if hasattr(exp, 'local_exp'):
                        available_labels = list(exp.local_exp.keys())
                        if available_labels:
                            exp_list = exp.as_list(label=available_labels[0])
                            return exp_list
                except:
                    pass
            else:
                # 回归问题
                exp_list = exp.as_list()

        except Exception as e:
            logging.info(f"Get exp list failed: {str(e)}")

        return exp_list

    def _alternative_global_importance(self, X_test, feature_names, num_samples):
        """备选的全局重要性计算方法"""
        feature_impacts = {}

        for i in range(min(num_samples, len(X_test))):
            try:
                exp = self.explainer.explain_instance(
                    X_test[i],
                    self.model.predict_proba if self.task == "classification" else self.model.predict,
                    num_features=len(feature_names)
                )

                # 尝试不同的方法来获取解释
                exp_list = []

                # 方法1: 尝试使用预测类别
                if self.task == "classification":
                    predicted_class = self.model.predict([X_test[i]])[0]
                    try:
                        exp_list = exp.as_list(label=predicted_class)
                    except:
                        # 方法2: 尝试所有可能的类别
                        for label in range(len(self.target_names)):
                            try:
                                exp_list = exp.as_list(label=label)
                                break
                            except:
                                continue

                # 方法3: 对于回归或仍然失败的情况
                if not exp_list:
                    try:
                        exp_list = exp.as_list()
                    except:
                        # 方法4: 直接访问内部数据
                        try:
                            if hasattr(exp, 'local_exp'):
                                # 使用第一个可用的类别
                                available_labels = list(exp.local_exp.keys())
                                if available_labels:
                                    exp_list = exp.as_list(label=available_labels[0])
                        except:
                            continue

                # 处理解释结果
                for feature, impact in exp_list:
                    if feature in feature_impacts:
                        feature_impacts[feature].append(abs(impact))
                    else:
                        feature_impacts[feature] = [abs(impact)]

            except Exception as e:
                logging.info(f"Sample {i} explanation failed: {str(e)}")
                continue

        return feature_impacts

    def generate_basic_plots(self, X_test, y_test, feature_names, target_names, sample_idx=0):
        """Generate comprehensive LIME plots"""
        plots = {}

        try:
            # Ensure sample_idx is within bounds
            sample_idx = min(sample_idx, len(X_test) - 1)
            X_sample = X_test[sample_idx]

            # Get prediction
            if self.task == "classification":
                prediction = self.model.predict_proba([X_sample])[0]
                predicted_class = np.argmax(prediction)
                predicted_value = prediction[predicted_class]
                prediction_info = f"Class: {target_names[predicted_class]} ({predicted_value:.4f})"
            else:
                predicted_value = self.model.predict([X_sample])[0]
                prediction_info = f"Value: {predicted_value:.4f}"

            # 1. Single sample explanation - 修复调用方式
            try:
                exp = self.explainer.explain_instance(
                    X_sample,
                    self.model.predict_proba if self.task == "classification" else self.model.predict,
                    num_features=min(10, len(feature_names))
                )

                # 使用关键字参数调用
                fig = self._create_custom_lime_plot(
                    exp=exp,
                    sample_idx=sample_idx,
                    predicted_value=predicted_value,
                    task=self.task,
                    model=self.model,
                    target_names=target_names
                )
                if fig:
                    plots["single_sample"] = {
                        "title": "LIME Single Sample Explanation",
                        "content": self._fig_to_base64(fig),
                        "description": f"Local explanation for sample {sample_idx}. Blue bars indicate positive impact, red bars negative impact.",
                        "type": "image"
                    }

            except Exception as e:
                logging.info(f"Single sample explanation failed: {str(e)} {traceback.print_exc()}")


            # 2. Multiple samples comparison
            try:
                num_comparison_samples = min(3, len(X_test))
                sample_indices = np.random.choice(len(X_test), num_comparison_samples, replace=False)

                fig, axes = plt.subplots(num_comparison_samples, 1, figsize=(12, 4 * num_comparison_samples))
                if num_comparison_samples == 1:
                    axes = [axes]

                for i, idx in enumerate(sample_indices):
                    exp = self.explainer.explain_instance(
                        X_test[idx],
                        self.model.predict_proba if self.task == "classification" else self.model.predict,
                        num_features=min(8, len(feature_names))
                    )

                    # 使用安全方法获取解释列表
                    exp_list = self._get_exp_list_safely(exp, self.task, self.model)

                    if not exp_list:
                        axes[i].text(0.5, 0.5, 'No explanation',
                                     ha='center', va='center', transform=axes[i].transAxes)
                        continue

                    features = [item[0] for item in exp_list]
                    values = [item[1] for item in exp_list]

                    # 排序并取顶部特征
                    indices = np.argsort(np.abs(values))[-8:]  # Top 8 features by absolute impact
                    top_features = [features[i] for i in indices]
                    top_values = [values[i] for i in indices]

                    # 创建颜色
                    colors = ['#3498db' if x > 0 else '#e74c3c' for x in top_values]

                    # 绘图
                    y_pos = np.arange(len(top_features))
                    axes[i].barh(y_pos, top_values, color=colors, alpha=0.8)
                    axes[i].set_yticks(y_pos)
                    axes[i].set_yticklabels(top_features)
                    axes[i].set_xlabel('Feature Impact')

                    if self.task == "classification":
                        pred = self.model.predict_proba([X_test[idx]])[0]
                        pred_class = np.argmax(pred)
                        pred_value = pred[pred_class]
                        title = f"Sample {idx} (Class: {target_names[pred_class]}, Prob: {pred_value:.3f})"
                    else:
                        pred = self.model.predict([X_test[idx]])[0]
                        title = f"Sample {idx} (Pred: {pred:.3f})"

                    axes[i].set_title(title)
                    axes[i].axvline(x=0, color='black', linestyle='-', alpha=0.3)
                    axes[i].grid(axis='x', alpha=0.3)

                plt.tight_layout()

                plots["multiple_samples"] = {
                    "title": "LIME Multiple Samples Comparison",
                    "content": self._fig_to_base64(plt.gcf()),
                    "description": "Comparison of local explanations across different samples showing feature impact variations.",
                    "type": "image"
                }

            except Exception as e:
                logging.info(f"Multiple samples comparison failed: {str(e)} {traceback.print_exc()}")


            # 3. Global feature importance from LIME
            # 修改全局特征重要性计算部分
            try:
                num_global_samples = min(50, len(X_test))
                sp_obj = submodular_pick.SubmodularPick(
                    self.explainer,
                    X_test[:num_global_samples],
                    self.model.predict_proba if self.task == "classification" else self.model.predict,
                    num_features=len(feature_names),
                    num_exps_desired=min(20, num_global_samples)
                )

                # 聚合特征重要性 - 修复KeyError问题
                feature_impacts = {}

                for exp in sp_obj.explanations:
                    # 对于分类问题，需要处理所有类别
                    if self.task == "classification":
                        # 方法1: 使用预测的类别
                        try:
                            # 获取当前样本的预测类别
                            sample_idx = exp.index if hasattr(exp, 'index') else 0
                            predicted_class = self.model.predict([X_test[sample_idx]])[0]
                            exp_list = exp.as_list(label=predicted_class)
                        except:
                            # 方法2: 使用第一个类别作为备选
                            try:
                                exp_list = exp.as_list(label=0)
                            except:
                                # 方法3: 尝试获取所有可用的类别
                                try:
                                    available_labels = list(exp.local_exp.keys())
                                    exp_list = exp.as_list(label=available_labels[0]) if available_labels else []
                                except:
                                    exp_list = []
                    else:
                        # 回归问题直接使用
                        exp_list = exp.as_list()

                    # 处理解释结果
                    for feature, impact in exp_list:
                        if feature in feature_impacts:
                            feature_impacts[feature].append(abs(impact))
                        else:
                            feature_impacts[feature] = [abs(impact)]

                # 如果上面的方法仍然有问题，使用备选方案
                if not feature_impacts:
                    feature_impacts = self._alternative_global_importance(X_test, feature_names, num_global_samples)

                # 计算平均绝对影响
                if feature_impacts:
                    mean_impacts = {feature: np.mean(impacts) for feature, impacts in feature_impacts.items()}

                    # 排序特征
                    sorted_features = sorted(mean_impacts.items(), key=lambda x: x[1], reverse=True)
                    features_sorted = [item[0] for item in sorted_features[:15]]  # Top 15 features
                    impacts_sorted = [item[1] for item in sorted_features[:15]]

                    # 创建图表
                    plt.figure(figsize=(12, 8))
                    y_pos = np.arange(len(features_sorted))
                    colors = plt.cm.viridis(np.linspace(0, 1, len(features_sorted)))

                    plt.barh(y_pos, impacts_sorted, color=colors, alpha=0.8)
                    plt.yticks(y_pos, features_sorted)
                    plt.xlabel('Mean Absolute LIME Impact')
                    plt.title('Global Feature Importance (from LIME)', fontsize=16, pad=20)

                    # 添加数值标签
                    for i, v in enumerate(impacts_sorted):
                        plt.text(v, i, f' {v:.3f}', va='center', fontweight='bold')

                    plt.gca().invert_yaxis()
                    plt.grid(axis='x', alpha=0.3)
                    plt.tight_layout()

                    plots["global_importance"] = {
                        "title": "LIME Global Feature Importance",
                        "content": self._fig_to_base64(plt.gcf()),
                        "description": "Global feature importance derived from aggregating multiple local LIME explanations.",
                        "type": "image"
                    }

            except Exception as e:
                logging.info(f"Global importance failed: {str(e)} {traceback.print_exc()}")
                # Fallback to model feature importance
                self._fallback_global_importance(plots, feature_names)

            except Exception as e:
                logging.info(f"Global importance failed: {str(e)}  {traceback.print_exc()}")

                # Fallback to model feature importance
                self._fallback_global_importance(plots, feature_names)

            # 4. Feature impact distribution
            try:
                num_dist_samples = min(30, len(X_test))
                all_impacts = []

                for i in range(num_dist_samples):
                    try:
                        exp = self.explainer.explain_instance(
                            X_test[i],
                            self.model.predict_proba if self.task == "classification" else self.model.predict,
                            num_features=len(feature_names)
                        )
                        impacts = [abs(item[1]) for item in exp.as_list()]
                        all_impacts.extend(impacts)
                    except:
                        continue

                if all_impacts:
                    plt.figure(figsize=(12, 8))
                    plt.hist(all_impacts, bins=30, alpha=0.7, color='#3498db', edgecolor='white')
                    plt.xlabel('Absolute Feature Impact')
                    plt.ylabel('Frequency')
                    plt.title('Distribution of LIME Feature Impacts', fontsize=16, pad=20)
                    plt.grid(axis='y', alpha=0.3)
                    plt.tight_layout()

                    plots["impact_distribution"] = {
                        "title": "LIME Impact Distribution",
                        "content": self._fig_to_base64(plt.gcf()),
                        "description": "Distribution of absolute feature impacts across multiple local explanations.",
                        "type": "image"
                    }

            except Exception as e:
                logging.info(f"Impact distribution failed: {str(e)}")

            # 5. Model performance metrics
            try:
                y_pred = self.model.predict(X_test)

                if self.task == "classification":
                    from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

                    plt.figure(figsize=(10, 8))
                    cm = confusion_matrix(y_test, y_pred)
                    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=target_names)
                    disp.plot(cmap='Blues', ax=plt.gca())
                    plt.title('Confusion Matrix', fontsize=16, pad=20)
                    plt.tight_layout()

                    plots["confusion_matrix"] = {
                        "title": "Confusion Matrix",
                        "content": self._fig_to_base64(plt.gcf()),
                        "description": "Model performance on test set showing actual vs predicted classifications.",
                        "type": "image"
                    }

                else:
                    # Regression: Actual vs Predicted
                    plt.figure(figsize=(12, 8))
                    plt.scatter(y_test, y_pred, alpha=0.6, color='blue')
                    plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
                    plt.xlabel('Actual Values')
                    plt.ylabel('Predicted Values')
                    plt.title('Actual vs Predicted Values', fontsize=16, pad=20)
                    plt.grid(alpha=0.3)
                    plt.tight_layout()

                    plots["actual_vs_predicted"] = {
                        "title": "Actual vs Predicted",
                        "content": self._fig_to_base64(plt.gcf()),
                        "description": "Comparison of actual vs predicted values for regression task.",
                        "type": "image"
                    }

            except Exception as e:
                logging.info(f"Performance metrics failed: {str(e)}")

        except Exception as e:
            logging.info(f"LIME plot generation failed: {str(e)} {traceback.format_exc()}")


        return plots

    def _fallback_global_importance(self, plots, feature_names):
        """Fallback using model's built-in feature importance"""
        try:
            if hasattr(self.model, 'feature_importances_'):
                importances = self.model.feature_importances_
                indices = np.argsort(importances)[::-1]
                top_features = min(15, len(feature_names))

                plt.figure(figsize=(12, 8))
                y_pos = np.arange(top_features)
                features = [feature_names[i] for i in indices[:top_features]]
                values = importances[indices[:top_features]]

                colors = plt.cm.plasma(np.linspace(0, 1, top_features))
                plt.barh(y_pos, values, color=colors, alpha=0.8)
                plt.yticks(y_pos, features)
                plt.xlabel('Feature Importance')
                plt.title('Model Feature Importance (Fallback)', fontsize=16, pad=20)
                plt.gca().invert_yaxis()
                plt.grid(axis='x', alpha=0.3)
                plt.tight_layout()

                plots["global_importance"] = {
                    "title": "Model Feature Importance",
                    "content": self._fig_to_base64(plt.gcf()),
                    "description": "Model's built-in feature importance based on impurity decrease.",
                    "type": "image"
                }

        except Exception as e:
            logging.info(f"Fallback global importance failed: {str(e)}")


class HTMLReportGenerator:
    @staticmethod
    def generate_inference_report(inference_result, output_path, task):
        """生成推理阶段单个样本报告"""
        try:
            if not inference_result:
                raise ValueError("No inference result to report")

            sample_info = inference_result.get('sample_info', {})
            prediction = inference_result.get('prediction', {})
            feature_explanations = inference_result.get('feature_explanations', [])
            plots = inference_result.get('plots', {})
            comparison_analysis = inference_result.get('comparison_analysis', {})
            logging.info("in generate #############" )
            # 创建比较分析表格
            comparison_table = ""
            if comparison_analysis.get('feature_comparisons'):
                comparison_table = """
                        <div class="comparison-section">
                            <h2>Training Set Comparison</h2>
                            <style>
                                .comparison-table {
                                    width: 100%;
                                    border-collapse: collapse;
                                    margin: 15px 0;
                                    font-size: 14px;
                                    text-align: left;
                                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                                }
                                .comparison-table th {
                                    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
                                    color: white;
                                    padding: 12px 15px;
                                    font-weight: bold;
                                    border-bottom: 2px solid #00f2fe;
                                }
                                .comparison-table td {
                                    padding: 12px 15px;
                                    border-bottom: 1px solid #f0f0f0;
                                }
                                .comparison-table tbody tr:nth-child(even) {
                                    background-color: #f8f9fa;
                                }
                                .comparison-table tbody tr:hover {
                                    background-color: #eef7ff;
                                    transition: background-color 0.3s ease;
                                }
                                .outlier {
                                    color: #dc3545;
                                    font-weight: bold;
                                    background-color: #fff5f5;
                                    padding: 3px 8px;
                                    border-radius: 4px;
                                    display: inline-block;
                                }
                                .normal {
                                    color: #28a745;
                                    background-color: #f0fff4;
                                    padding: 3px 8px;
                                    border-radius: 4px;
                                    display: inline-block;
                                }
                                .comparison-section h2 {
                                    color: #333;
                                    margin-bottom: 10px;
                                    font-size: 18px;
                                    border-left: 4px solid #4facfe;
                                    padding-left: 10px;
                                }
                            </style>
                            <table class="comparison-table">
                                <thead>
                                    <tr>
                                        <th>Feature</th>
                                        <th>Sample Value</th>
                                        <th>Train Mean</th>
                                        <th>Z-Score</th>
                                        <th>Percentile</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                        """

                for comp in comparison_analysis['feature_comparisons'][:10]:  # 只显示前10个
                    status_class = "outlier" if comp['is_outlier'] else "normal"
                    status_text = "Outlier" if comp['is_outlier'] else "Normal"

                    comparison_table += f"""
                                <tr>
                                    <td>{comp['feature']}</td>
                                    <td>{comp['sample_value']:.3f}</td>
                                    <td>{comp['train_mean']:.3f}</td>
                                    <td>{comp['z_score']:.2f}</td>
                                    <td>{comp['percentile']:.1f}%</td>
                                    <td class="{status_class}">{status_text}</td>
                                </tr>
                            """

                comparison_table += """
                                </tbody>
                            </table>
                        </div>
                        """

            # 异常值分析
            outlier_analysis = ""
            if comparison_analysis.get('outlier_analysis'):
                outlier_analysis = "<div class='outlier-section'><h3>Outlier Detection</h3><ul>"
                for outlier in comparison_analysis['outlier_analysis']:
                    outlier_analysis += f"<li><strong>{outlier['feature']}</strong>: Z-score = {outlier['z_score']:.2f} ({outlier['severity']} severity)</li>"
                outlier_analysis += "</ul></div>"

            # 创建特征解释表格
            feature_table = """
                <table class="feature-table">
                    <thead>
                        <tr>
                            <th>Feature</th>
                            <th>Impact</th>
                            <th>Direction</th>
                        </tr>
                    </thead>
                    <tbody>
                """

            for feat in feature_explanations:
                direction_class = "positive" if feat['direction'] == 'positive' else "negative"
                feature_table += f"""
                        <tr>
                            <td>{feat['feature']}</td>
                            <td>{feat['impact']:.4f}</td>
                            <td class="{direction_class}">{feat['direction']}</td>
                        </tr>
                    """

            feature_table += """
                    </tbody>
                </table>
                """

            # 创建预测信息
            if task == "classification":
                prediction_info = f"""
                    <div class="prediction-card">
                        <h3>Prediction Result</h3>
                        <p><strong>Class:</strong> {prediction.get('class_name', 'Unknown')}</p>
                        <p><strong>Confidence:</strong> {prediction.get('confidence', 0):.4f}</p>
                        <p><strong>Class ID:</strong> {prediction.get('class', 'N/A')}</p>
                    </div>
                    """
            else:
                prediction_info = f"""
                    <div class="prediction-card">
                        <h3>Prediction Result</h3>
                        <p><strong>Predicted Value:</strong> {prediction.get('value', 0):.4f}</p>
                    </div>
                    """

            # 创建样本信息
            sample_info_html = ""
            if sample_info:
                sample_info_html = "<div class='sample-info'><h3>Sample Information</h3>"
                for key, value in sample_info.items():
                    sample_info_html += f"<p><strong>{key}:</strong> {value}</p>"
                sample_info_html += "</div>"

            # 创建图表内容
            plot_contents = ""
            for plot_id, plot_info in plots.items():
                plot_contents += f"""
                    <div class="plot-section">
                        <h3>{plot_info['title']}</h3>
                        <p class="plot-description">{plot_info['description']}</p>
                        <img src="{plot_info['content']}" class="plot-image">
                    </div>
                    """

            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            html_template = """
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>LIME Inference Analysis Report</title>
                <style>
                    body {{
                        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
                        margin: 0;
                        padding: 20px;
                        background: #f5f7fa;
                        min-height: 100vh;
                    }}
                    .container {{
                        max-width: 1200px;
                        margin: 0 auto;
                        background: white;
                        border-radius: 15px;
                        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
                        overflow: hidden;
                    }}
                    .header {{
                        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
                        color: white;
                        padding: 2px 10px;
                        text-align: left;
                        margin: 0;
                    }}
                    .content {{
                        padding: 0px;
                    }}
                    .prediction-card {{
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: white;
                        padding: 2px 5px;
                        text-align: left;
                        font-size: 14px;
                        margin: 0;

                    }}
                    .sample-info {{
                        background: #f8f9fa;
                        padding: 15px;
                        border-radius: 8px;
                        margin-bottom: 20px;
                        border-left: 4px solid #3498db;
                    }}
                    .feature-table {{
                        width: 100%;
                        border-collapse: collapse;
                        margin: 20px 0;
                        background: white;
                        border-radius: 8px;
                        overflow: hidden;
                        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
                    }}
                    .feature-table th {{
                        background: #34495e;
                        color: white;
                        padding: 12px;
                        text-align: left;
                    }}
                    .feature-table td {{
                        padding: 10px 12px;
                        border-bottom: 1px solid #ecf0f1;
                    }}
                    .positive {{
                        color: #27ae60;
                        font-weight: bold;
                    }}
                    .negative {{
                        color: #e74c3c;
                        font-weight: bold;
                    }}
                    .plot-section {{
                        margin: 30px 0;
                        padding: 20px;
                        background: #f8f9fa;
                        border-radius: 10px;
                    }}
                    .plot-image {{
                        max-width: 100%;
                        height: auto;
                        border-radius: 8px;
                        box-shadow: 0 3px 10px rgba(0,0,0,0.1);
                    }}
                    .plot-description {{
                        color: #636e72;
                        margin-bottom: 15px;
                    }}
                    .footer {{
                        text-align: center;
                        padding: 20px;
                        color: #636e72;
                        background: #f8f9fa;
                        border-top: 1px solid #eee;
                    }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h3>LIME Inference Analysis Report</h1>
                        <p>Single Sample Prediction Explanation | Generated: {current_time}</p>
                    </div>

                    <div class="content">
                        {prediction_info}
                        {sample_info_html}
                        {comparison_table}
                        {outlier_analysis}
                        <div class="feature-analysis">
                            <h2>Feature Impact Analysis</h2>
                            {feature_table}
                        </div>

                        {plot_contents}
                    </div>

                    <div class="footer">
                        <p>LIME Inference Analysis Tool | Generated by Your best friend</p>
                    </div>
                </div>
            </body>
            </html>
            """

            html_content = html_template.format(
                prediction_info=prediction_info,
                sample_info_html=sample_info_html,
                feature_table=feature_table,
                plot_contents=plot_contents,
                comparison_table=comparison_table,
                outlier_analysis=outlier_analysis,
                current_time=current_time
            )

            output_dir = os.path.dirname(output_path)
            if output_dir and not os.path.exists(output_dir):
                os.makedirs(output_dir, exist_ok=True)

            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)

            logging.info(f"✓ Inference report generated: {os.path.abspath(output_path)}")
            return output_path

        except Exception as e:
            logging.info(f"Inference report generation failed: {str(e)}")

            raise

    @staticmethod
    def generate_report(plots, output_path, task, dataset_name, model_metrics):
        """Generate HTML report"""
        try:
            tab_buttons = []
            tab_contents = []

            for i, (plot_id, plot_info) in enumerate(plots.items()):
                tab_id = f"tab_{i}"
                tab_buttons.append(f'<button class="tab-btn" data-tab="{tab_id}">{plot_info["title"]}</button>')

                content = f'<img src="{plot_info["content"]}" class="plot-image" alt="{plot_info["title"]}">'

                tab_contents.append(f'''
                <div id="{tab_id}" class="tab-content">
                    <h2 class="plot-title">{plot_info["title"]}</h2>
                    <div class="plot-description">{plot_info["description"]}</div>
                    {content}
                </div>
                ''')

            metrics_text = ""
            if task == "classification":
                accuracy = model_metrics.get('accuracy', 0)
                metrics_text = f"Accuracy: {accuracy:.4f}"
            else:
                r2 = model_metrics.get('r2', 0)
                metrics_text = f"R² Score: {r2:.4f}"

            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LIME Analysis Report - {task} - {dataset_name}</title>
    <style>
        body {{
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f7fa;
            min-height: 100vh;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            padding: 2px 10px;
            text-align: left;
        }}
        .metrics {{
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 2px 5px;
            text-align: left;
            font-size: 16px;
            font-weight: 600;
        }}
        .tab-container {{
            padding: 8px;
        }}
        .tab-buttons {{
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
        }}
        .tab-btn {{
            padding: 10px 20px;
            background: #9b59b6;
            color: white;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
            font-size: 14px;
        }}
        .tab-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(155, 89, 182, 0.3);
        }}
        .tab-btn.active {{
            background: #e74c3c;
        }}
        .tab-content {{
            display: none;
            background: white;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
        }}
        .tab-content.active {{
            display: block;
            animation: fadeIn 0.5s ease;
        }}
        @keyframes fadeIn {{
            from {{ opacity: 0; transform: translateY(10px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}
        .plot-title {{
            color: #2d3436;
            border-bottom: 2px solid #e74c3c;
            padding-bottom: 8px;
            margin-top: 0;
            font-size: 1.4em;
        }}
        .plot-description {{
            color: #636e72;
            line-height: 1.6;
            margin-bottom: 20px;
            font-size: 15px;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border-left: 3px solid #3498db;
        }}
        .plot-image {{
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.08);
            display: block;
            margin: 0 auto;
        }}
        .footer {{
            text-align: center;
            padding: 15px;
            color: #636e72;
            font-size: 13px;
            background: #f8f9fa;
            border-top: 1px solid #eee;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h4>LIME Analysis Report</h1>
            <p>Task: {task} | Dataset: {dataset_name} | Generated: {current_time}</p>
        </div>

        <div class="metrics">
            <h5>Model Performance</h3>
            <p>{metrics_text}</p>
        </div>

        <div class="tab-container">
            <div class="tab-buttons">
                {tab_buttons}
            </div>

            {tab_contents}
        </div>

        <div class="footer">
            <p>LIME Analysis Report Tool | Generated with ❤️ using Python</p>
        </div>
    </div>

    <script>
        document.querySelectorAll('.tab-btn').forEach(button => {{
            button.addEventListener('click', () => {{
                document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
                button.classList.add('active');
                document.getElementById(button.getAttribute('data-tab')).classList.add('active');
            }});
        }});
        if (document.querySelector('.tab-btn')) {{
            document.querySelector('.tab-btn').classList.add('active');
            document.querySelector('.tab-content').classList.add('active');
        }}
    </script>
</body>
</html>
            """

            html_content = html_template.format(
                task=task,
                dataset_name=dataset_name,
                metrics_text=metrics_text,
                tab_buttons=''.join(tab_buttons),
                tab_contents=''.join(tab_contents),
                current_time=current_time
            )

            output_dir = os.path.dirname(output_path)
            if output_dir and not os.path.exists(output_dir):
                os.makedirs(output_dir, exist_ok=True)

            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)

            logging.info(f"Report generated: {os.path.abspath(output_path)}")
            return output_path

        except Exception as e:
            logging.info(f"HTML report generation failed: {str(e)}")

            raise

# {
#             "X": X.values.astype(np.float64),
#             "y": y,
#             "feature_names": feature_names,
#             "target_names": target_names,
#             "target_column": target_column,
#             "label_encoders": label_encoders,
#             "le_target": le_target,
#             "categorical_columns": categorical_columns
#         }

def embeding_LIMEAnalyzer_inTrain( model, task,X_train, y_train,X_test, y_test,feature_names , ouput_file, target_names=None,sample_idx=0,dataset_name="" ):
    if task in ["reg"]:
        task ="regression"
    elif task in ['clc','clf']:
        task = 'classification'
    else:
        pass
    if task in ["regression"]:target_names=None
    model_metrics = LimeModelTrainer.evaluate_model(model, X_test, y_test, task=task)
    analyzer = LIMEAnalyzer(model, X_train, task=task, feature_names=feature_names, target_names=target_names, y_train=y_train)
    plots = analyzer.generate_basic_plots(X_test, y_test, feature_names, target_names, sample_idx)
    if not plots:
        plots = {"empty": {
            "title": "No Plots",
            "content": "",
            "description": "No LIME plots were generated",
            "type": "text"
        }}

    HTMLReportGenerator.generate_report(
        plots,
        ouput_file,
        task=task,
        dataset_name=dataset_name,
        model_metrics=model_metrics
    )
    #analyzer.model=None
    return analyzer

def embedding_LIMEAnalyzer_inInference(analyzer, id, X_test, output_file):
    if id is not None and id != "":
        sample_id = str(id)
    else:
        sample_id = datetime.now().strftime("%Y%m%d%H%M%S%f")[:-3]

    if output_file is None or (sample_id not in output_file):
        base_name = f"{sample_id}_inferenceWithExplain.html"
        if output_file and os.path.dirname(output_file):
            output_file = os.path.join(os.path.dirname(output_file), base_name)
        else:
            output_file = base_name
    if not output_file.endswith(".html"):
        output_file += ".html"
    sample_data = X_test[0]
    logging.info(f"sample_data:{sample_data}")
    sample_info = {
        "sample_id": sample_id,
        "description": "Real-time prediction sample",
        "timestamp": datetime.now().isoformat()
    }
    analyzer.generate_inference_report(
        sample_data=sample_data,
        sample_info=sample_info,
        output_path=output_file
    )
    return output_file


import os
import joblib
import os
import joblib
import logging


def save_analyzer_dill(analyzer, save_dir, model_file='dump_dump_dump.dill'):
    import dill
    """使用dill保存analyzer（支持lambda函数）"""
    try:
        os.makedirs(save_dir, exist_ok=True)
        if not model_file.endswith('__limeanalyzer.dill'):
            base, ext = os.path.splitext(model_file)
            if ext.lower() == '.dill':
                base = base.replace(ext, '')
            model_file = f"{base}__limeanalyzer.dill"
        save_file = os.path.join(save_dir, model_file)

        # 使用dill保存
        with open(save_file, 'wb') as f:
            dill.dump(analyzer, f)

        logging.info(f"Analyzer saved with dill to: {save_file}")
        return save_file
    except Exception as e:
        logging.error(f"Failed to save analyzer with dill: {str(e)}", exc_info=True)
        raise


def load_analyzer_dill(load_path):
    """使用dill加载analyzer"""
    import dill
    try:
        if not os.path.exists(load_path) or not load_path.endswith('__limeanalyzer.dill'):
            raise ValueError(f"Invalid analyzer file: {load_path}")
        with open(load_path, 'rb') as f:
            analyzer = dill.load(f)
        logging.info(f"Analyzer loaded with dill from: {load_path}")
        return analyzer
    except Exception as e:
        logging.error(f"Failed to load analyzer with dill: {str(e)}", exc_info=True)
        raise

def main():
    try:
        from .utils import set_logging
        set_logging(log_dir='log', file_name='gen_limereport', mode='dev')
        logging.info('begin limereport task')
    except:
        import logging
    try:
        parser = argparse.ArgumentParser(description='LIME Model Analysis Tool')
        parser.add_argument('--input_file', type=str, default="./diamonds.csv", help='Input CSV file path')
        parser.add_argument('--output', type=str, default="test_final.html", help='Output HTML report path')
        parser.add_argument('--task', type=str, default="regression", choices=["classification", "regression"], help='Task type')
        parser.add_argument('--target_column', type=str, default="price", help='Target column name')
        parser.add_argument('--test_size', type=float, default=0.3, help='Test set ratio')
        parser.add_argument('--random_state', type=int, default=42, help='Random seed')
        parser.add_argument('--n_estimators', type=int, default=50, help='Number of trees')
        parser.add_argument('--max_depth', type=int, default=3, help='Max depth')
        parser.add_argument('--sample_idx', type=int, default=0, help='Sample index for explanation')

        args = parser.parse_args()

        setup_fonts()

        # Load data
        data = DataLoader.load_data(args.input_file, args.target_column)
        X, y = data["X"], data["y"]
        feature_names = data["feature_names"]
        target_names  = data["target_names"]
        dataset_name  = os.path.basename(args.input_file).replace('.csv', '')

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=args.test_size,
                                                            random_state=args.random_state,
                                                            stratify=y if args.task == "classification" else None)

        # Train model
        model_params = {"n_estimators": args.n_estimators, "max_depth": args.max_depth,
                        "random_state": args.random_state, "n_jobs": -1}
        model = LimeModelTrainer.train_model(X_train, y_train, task=args.task, **model_params)

        # Evaluate model
        model_metrics = LimeModelTrainer.evaluate_model(model, X_test, y_test, task=args.task)

        # LIME analysis
        analyzer = LIMEAnalyzer(model, X_train, task=args.task, feature_names=feature_names, target_names=target_names, y_train=y_train)
        plots = analyzer.generate_basic_plots(X_test, y_test, feature_names, target_names, args.sample_idx)

        logging.info("analyzer stats:", analyzer.train_stats)
        logging.info("plots keys:", plots.keys())

        if not plots:
            plots = {"empty": {
                "title": "No Plots",
                "content": "",
                "description": "No LIME plots were generated",
                "type": "text"
            }}


        output_path = HTMLReportGenerator.generate_report(
            plots,
            args.output,
            task=args.task,
            dataset_name=dataset_name,
            model_metrics=model_metrics
        )
        logging.info(f"Analysis completed: {os.path.abspath(output_path)}")

        sample_data = X_test[3]
        sample_info = {
            "sample_id": "inference_001",
            "description": "Real-time prediction sample",
            "timestamp": datetime.now().isoformat()
        }

        # 生成推理报告
        analyzer.generate_inference_report(
            sample_data=sample_data,
            sample_info=sample_info,
            output_path="inference_report.html"
        )


    except Exception as e:
        logging.info(f"LIME analysis failed: {str(e)}")

        raise


if __name__ == "__main__":
    main()