# optimization_engine.py
import numpy as np
import pandas as pd
import json
import pickle
import re
import math
import os
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
import logging
import tempfile
import warnings

warnings.filterwarnings('ignore')

# 机器学习库
from sklearn.ensemble import RandomForestRegressor
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel, Matern, RationalQuadratic
import lightgbm as lgb
import xgboost as xgb
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

# 优化算法
from pyswarm import pso
from scipy.optimize import minimize, differential_evolution, NonlinearConstraint
from skopt import gp_minimize
from skopt.space import Real, Integer, Categorical

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@dataclass
class OptimizationResult:
    """优化结果"""
    success: bool
    message: str
    optimal_variables: Dict[str, Any]
    optimal_objective: float
    model_metrics: Optional[Dict] = None
    trained_model_path: Optional[str] = None
    optimization_history: Optional[List] = None
    portfolio_metrics: Optional[Dict] = None
    optimization_type: str = "forward"  # forward, inverse, multi_objective


@dataclass
class PortfolioMetrics:
    """投资组合指标"""
    expected_return: float
    volatility: float
    sharpe_ratio: float
    max_drawdown: Optional[float] = None
    var: Optional[float] = None
    cvar: Optional[float] = None
    diversification_ratio: Optional[float] = None


class SurrogateModel:
    """增强的代理模型基类"""

    def __init__(self, model_type: str, params: Dict[str, Any] = None):
        self.model_type = model_type
        self.params = params or {}
        self.model = None
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.is_trained = False
        self.feature_names = []
        self.target_scaler = StandardScaler()
        self.use_target_scaling = False

    def preprocess_features(self, X: pd.DataFrame, variable_info: Dict) -> np.ndarray:
        """预处理特征"""
        processed_features = []
        self.feature_names = list(variable_info.keys())

        for var_name in self.feature_names:
            if var_name not in X.columns:
                raise ValueError(f"Variable {var_name} not found in data")

            info = variable_info[var_name]
            if info['type'] == 'continuous':
                # 连续变量标准化
                values = X[var_name].values.reshape(-1, 1)
                if not hasattr(self.scaler, 'n_features_in_'):
                    scaled = self.scaler.fit_transform(values).flatten()
                else:
                    scaled = self.scaler.transform(values).flatten()
                processed_features.append(scaled)

            elif info['type'] == 'categorical':
                # 分类变量编码
                if var_name not in self.label_encoders:
                    self.label_encoders[var_name] = LabelEncoder()
                    encoded = self.label_encoders[var_name].fit_transform(X[var_name])
                else:
                    encoded = self.label_encoders[var_name].transform(X[var_name])
                processed_features.append(encoded)

            elif info['type'] == 'ordinal':
                # 有序分类变量
                categories = info.get('categories', [])
                if var_name not in self.label_encoders:
                    self.label_encoders[var_name] = LabelEncoder()
                    self.label_encoders[var_name].classes_ = np.array(categories)
                    encoded = self.label_encoders[var_name].transform(X[var_name])
                else:
                    encoded = self.label_encoders[var_name].transform(X[var_name])
                processed_features.append(encoded)

        return np.column_stack(processed_features)

    def train(self, X: pd.DataFrame, y: np.ndarray, variable_info: Dict):
        """训练模型"""
        X_processed = self.preprocess_features(X, variable_info)

        # 目标变量标准化（可选）
        if self.params.get('scale_target', False):
            y = self.target_scaler.fit_transform(y.reshape(-1, 1)).flatten()
            self.use_target_scaling = True

        self.model.fit(X_processed, y)
        self.is_trained = True
        logger.info(f"Model trained successfully with {X_processed.shape[0]} samples")

    def predict(self, X: pd.DataFrame, variable_info: Dict) -> np.ndarray:
        """预测"""
        if not self.is_trained:
            raise ValueError("Model not trained")
        X_processed = self.preprocess_features(X, variable_info)
        predictions = self.model.predict(X_processed)

        # 如果目标变量被标准化，需要反标准化
        if self.use_target_scaling:
            predictions = self.target_scaler.inverse_transform(predictions.reshape(-1, 1)).flatten()

        return predictions

    def save(self, path: str):
        """保存模型"""
        model_data = {
            'model_type': self.model_type,
            'params': self.params,
            'model': self.model,
            'scaler': self.scaler,
            'label_encoders': self.label_encoders,
            'is_trained': self.is_trained,
            'feature_names': self.feature_names,
            'target_scaler': self.target_scaler,
            'use_target_scaling': self.use_target_scaling
        }
        with open(path, 'wb') as f:
            pickle.dump(model_data, f)
        logger.info(f"Model saved to {path}")

    def load(self, path: str):
        """加载模型"""
        with open(path, 'rb') as f:
            model_data = pickle.load(f)

        self.model_type = model_data['model_type']
        self.params = model_data['params']
        self.model = model_data['model']
        self.scaler = model_data['scaler']
        self.label_encoders = model_data['label_encoders']
        self.is_trained = model_data['is_trained']
        self.feature_names = model_data['feature_names']
        self.target_scaler = model_data.get('target_scaler', StandardScaler())
        self.use_target_scaling = model_data.get('use_target_scaling', False)
        logger.info(f"Model loaded from {path}")


class LightGBMModel(SurrogateModel):
    """LightGBM模型"""

    def __init__(self, params: Dict[str, Any] = None):
        super().__init__("lightgbm", params)
        default_params = {
            'num_leaves': 31,
            'learning_rate': 0.1,
            'n_estimators': 100,
            'max_depth': -1,
            'random_state': 42,
            'verbose': -1
        }
        default_params.update(params or {})
        self.model = lgb.LGBMRegressor(**default_params)


class GaussianProcessModel(SurrogateModel):
    """高斯过程模型"""

    def __init__(self, params: Dict[str, Any] = None):
        super().__init__("gaussian", params)
        kernel_name = params.get('kernel', 'rbf') if params else 'rbf'

        if kernel_name == 'rbf':
            kernel = ConstantKernel(1.0) * RBF(length_scale=1.0)
        elif kernel_name == 'matern':
            kernel = ConstantKernel(1.0) * Matern(length_scale=1.0, nu=1.5)
        elif kernel_name == 'rational_quadratic':
            kernel = ConstantKernel(1.0) * RationalQuadratic(length_scale=1.0, alpha=1.0)
        else:
            kernel = ConstantKernel(1.0) * RBF(length_scale=1.0)

        default_params = {
            'kernel': kernel,
            'alpha': 1e-10,
            'n_restarts_optimizer': 10,
            'random_state': 42
        }
        default_params.update(params or {})
        self.model = GaussianProcessRegressor(**default_params)


class RandomForestModel(SurrogateModel):
    """随机森林模型"""

    def __init__(self, params: Dict[str, Any] = None):
        super().__init__("randomForest", params)
        default_params = {
            'n_estimators': 100,
            'max_depth': 10,
            'min_samples_split': 2,
            'random_state': 42
        }
        default_params.update(params or {})
        self.model = RandomForestRegressor(**default_params)


class XGBoostModel(SurrogateModel):
    """XGBoost模型"""

    def __init__(self, params: Dict[str, Any] = None):
        super().__init__("xgboost", params)
        default_params = {
            'n_estimators': 100,
            'max_depth': 6,
            'learning_rate': 0.1,
            'random_state': 42
        }
        default_params.update(params or {})
        self.model = xgb.XGBRegressor(**default_params)


class MLPModel(SurrogateModel):
    """神经网络模型"""

    def __init__(self, params: Dict[str, Any] = None):
        super().__init__("mlp", params)
        default_params = {
            'hidden_layer_sizes': (100, 50),
            'activation': 'relu',
            'solver': 'adam',
            'max_iter': 1000,
            'random_state': 42
        }
        default_params.update(params or {})
        self.model = MLPRegressor(**default_params)


class FinancialPortfolioEngine:
    """金融投资组合专用引擎"""

    @staticmethod
    def calculate_portfolio_metrics(weights: Dict[str, float], returns_data: pd.DataFrame,
                                    risk_free_rate: float = 0.02) -> PortfolioMetrics:
        """计算投资组合指标"""
        # 将权重转换为数组
        asset_names = list(weights.keys())
        weight_array = np.array([weights[asset] for asset in asset_names])

        # 计算组合收益
        portfolio_returns = (returns_data[asset_names] * weight_array).sum(axis=1)

        # 基本指标
        expected_return = portfolio_returns.mean() * 252  # 年化
        volatility = portfolio_returns.std() * np.sqrt(252)  # 年化
        sharpe_ratio = (expected_return - risk_free_rate) / volatility if volatility > 0 else 0

        # 最大回撤
        cumulative_returns = (1 + portfolio_returns).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        max_drawdown = drawdown.min()

        # VaR和CVaR (95%置信水平)
        var_95 = np.percentile(portfolio_returns, 5)
        cvar_95 = portfolio_returns[portfolio_returns <= var_95].mean()

        # 分散化比率 (简化版)
        individual_volatilities = returns_data[asset_names].std() * np.sqrt(252)
        weighted_vol = np.sqrt(np.sum((weight_array * individual_volatilities) ** 2))
        diversification_ratio = weighted_vol / volatility if volatility > 0 else 1

        return PortfolioMetrics(
            expected_return=expected_return,
            volatility=volatility,
            sharpe_ratio=sharpe_ratio,
            max_drawdown=max_drawdown,
            var=var_95,
            cvar=cvar_95,
            diversification_ratio=diversification_ratio
        )


class EnhancedOptimizationEngine(OptimizationEngine):
    """增强的优化引擎，支持金融资产配置和逆向优化"""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.portfolio_engine = FinancialPortfolioEngine()
        self.returns_data = None
        self.risk_free_rate = config.get('risk_free_rate', 0.02)

    def load_returns_data(self, returns_data: pd.DataFrame):
        """加载收益率数据（用于投资组合优化）"""
        self.returns_data = returns_data
        logger.info(f"Returns data loaded: {returns_data.shape}")

    def setup_variables(self):
        """增强的变量设置，支持投资组合权重约束"""
        variables = self.config.get('variables', [])

        # 检查是否是投资组合优化
        is_portfolio_optimization = any(
            var.get('portfolio_weight', False) for var in variables
        ) or self.config.get('optimizationType') == 'portfolio'

        for var in variables:
            var_info = {
                'type': var['type'],
                'bounds': var.get('bounds', []),
                'categories': var.get('categories', []),
                'portfolio_weight': var.get('portfolio_weight', is_portfolio_optimization)
            }
            self.variable_info[var['name']] = var_info

        # 如果是投资组合优化，自动添加权重和为1的约束
        if is_portfolio_optimization and not any(
                'weight_sum' in str(c.get('expression', '')) for c in self.config.get('constraints', [])
        ):
            weight_constraint = {
                'expression': ' + '.join([f'[{v}]' for v in self.variable_info.keys()]) + ' == 1',
                'type': 'eq',
                'name': 'weight_sum_constraint'
            }
            if 'constraints' not in self.config:
                self.config['constraints'] = []
            self.config['constraints'].append(weight_constraint)

        logger.info(f"Setup {len(variables)} variables: {list(self.variable_info.keys())}")

    def create_inverse_objective_function(self, target_value: float, target_variable: str,
                                          tolerance: float = 0.01) -> callable:
        """创建逆向优化目标函数"""

        def inverse_objective(x):
            # 将输入转换为DataFrame
            input_dict = {}
            for i, var_name in enumerate(self.variable_info.keys()):
                input_dict[var_name] = x[i]

            input_df = pd.DataFrame([input_dict])

            # 预测目标值
            if self.model and self.model.is_trained:
                prediction = self.model.predict(input_df, self.variable_info)[0]
            else:
                # 如果没有模型，使用表达式计算
                prediction = self.safe_eval(f'[{target_variable}]', input_dict)

            # 目标是使预测值尽可能接近目标值
            error = abs(prediction - target_value)

            # 添加惩罚项以确保在容差范围内
            if error > tolerance:
                error += 10.0  # 大幅惩罚超出容差的范围

            # 记录优化历史
            self.optimization_history.append({
                'variables': input_dict.copy(),
                'predicted_value': float(prediction),
                'target_value': float(target_value),
                'error': float(error)
            })

            return error

        return inverse_objective

    def create_multi_objective_function(self, objectives: List[Dict]) -> callable:
        """创建多目标优化函数（加权和法）"""
        weights = [obj.get('weight', 1.0) for obj in objectives]
        directions = [1 if obj.get('type') == 'minimize' else -1 for obj in objectives]

        def multi_objective(x):
            input_dict = {}
            for i, var_name in enumerate(self.variable_info.keys()):
                input_dict[var_name] = x[i]

            input_df = pd.DataFrame([input_dict])
            total_objective = 0.0

            # 计算每个目标函数
            objective_values = {}
            for i, obj in enumerate(objectives):
                if self.model and self.model.is_trained:
                    # 如果有模型，使用模型预测
                    prediction = self.model.predict(input_df, self.variable_info)[0]
                else:
                    # 使用表达式计算
                    prediction = self.safe_eval(obj['expression'], input_dict)

                # 根据方向调整
                weighted_value = directions[i] * weights[i] * prediction
                total_objective += weighted_value
                objective_values[obj['name']] = float(prediction)

            # 记录优化历史
            self.optimization_history.append({
                'variables': input_dict.copy(),
                'objective_values': objective_values,
                'total_objective': float(total_objective)
            })

            return total_objective

        return multi_objective

    def run_inverse_optimization(self, target_value: float, target_variable: str,
                                 tolerance: float = 0.01) -> OptimizationResult:
        """运行逆向优化：根据目标值反推最优配置"""
        try:
            # 设置变量和约束
            self.setup_variables()
            self.setup_constraints()

            # 创建逆向优化目标函数
            objective_func = self.create_inverse_objective_function(
                target_value, target_variable, tolerance
            )

            # 定义变量边界
            bounds = self._get_variable_bounds()

            # 运行优化
            optimizer = self.config.get('optimizer', 'pso')
            optimizer_params = self.config.get('optimizerParams', {})

            optimization_result = self._run_optimization(
                objective_func, bounds, optimizer, optimizer_params
            )

            # 构建最终结果
            optimal_variables = self._build_optimal_variables(optimization_result['x'])

            # 计算投资组合指标（如果适用）
            portfolio_metrics = None
            if self.returns_data is not None:
                portfolio_metrics = self.portfolio_engine.calculate_portfolio_metrics(
                    optimal_variables, self.returns_data, self.risk_free_rate
                ).__dict__

            # 计算最终预测值
            input_df = pd.DataFrame([optimal_variables])
            final_prediction = self.model.predict(input_df, self.variable_info)[0] if self.model else target_value

            return OptimizationResult(
                success=optimization_result['success'],
                message=f"Inverse optimization completed. Target: {target_value}, Achieved: {final_prediction:.4f}",
                optimal_variables=optimal_variables,
                optimal_objective=optimization_result['fun'],
                portfolio_metrics=portfolio_metrics,
                optimization_type="inverse",
                optimization_history=self.optimization_history
            )

        except Exception as e:
            logger.error(f"Inverse optimization failed: {e}")
            return OptimizationResult(
                success=False,
                message=str(e),
                optimal_variables={},
                optimal_objective=float('inf'),
                optimization_type="inverse",
                optimization_history=[]
            )

    def run_multi_objective_optimization(self) -> OptimizationResult:
        """运行多目标优化"""
        try:
            self.setup_variables()
            self.setup_constraints()

            objectives = self.config.get('objectives', [])
            if len(objectives) < 2:
                raise ValueError("Multi-objective optimization requires at least 2 objectives")

            # 创建多目标函数
            objective_func = self.create_multi_objective_function(objectives)

            # 定义变量边界
            bounds = self._get_variable_bounds()

            # 运行优化
            optimizer = self.config.get('optimizer', 'pso')
            optimizer_params = self.config.get('optimizerParams', {})

            optimization_result = self._run_optimization(
                objective_func, bounds, optimizer, optimizer_params
            )

            # 构建最终结果
            optimal_variables = self._build_optimal_variables(optimization_result['x'])

            # 计算投资组合指标（如果适用）
            portfolio_metrics = None
            if self.returns_data is not None:
                portfolio_metrics = self.portfolio_engine.calculate_portfolio_metrics(
                    optimal_variables, self.returns_data, self.risk_free_rate
                ).__dict__

            return OptimizationResult(
                success=optimization_result['success'],
                message=optimization_result['message'],
                optimal_variables=optimal_variables,
                optimal_objective=optimization_result['fun'],
                portfolio_metrics=portfolio_metrics,
                optimization_type="multi_objective",
                optimization_history=self.optimization_history
            )

        except Exception as e:
            logger.error(f"Multi-objective optimization failed: {e}")
            return OptimizationResult(
                success=False,
                message=str(e),
                optimal_variables={},
                optimal_objective=float('inf'),
                optimization_type="multi_objective",
                optimization_history=[]
            )

    def run_optimization(self) -> OptimizationResult:
        """增强的运行优化方法，支持多种优化类型"""
        optimization_type = self.config.get('optimizationType', 'forward')

        if optimization_type == 'inverse':
            target_value = self.config.get('inverseTargetValue')
            target_variable = self.config.get('inverseTargetVariable')
            tolerance = self.config.get('inverseTolerance', 0.01)

            if target_value is None or target_variable is None:
                raise ValueError("Inverse optimization requires targetValue and targetVariable")

            return self.run_inverse_optimization(target_value, target_variable, tolerance)

        elif optimization_type == 'multi_objective':
            return self.run_multi_objective_optimization()

        else:
            # 默认正向优化
            return super().run_optimization()

    def _get_variable_bounds(self) -> List[List[float]]:
        """获取变量边界"""
        bounds = []
        for var_name in self.variable_info.keys():
            info = self.variable_info[var_name]
            if info['type'] == 'continuous':
                bounds.append(info['bounds'])
            else:
                bounds.append([0, len(info.get('categories', [])) - 1])
        return bounds

    def _build_optimal_variables(self, x: List[float]) -> Dict[str, float]:
        """构建最优变量字典"""
        optimal_variables = {}
        for i, var_name in enumerate(self.variable_info.keys()):
            optimal_variables[var_name] = float(x[i])
        return optimal_variables

    def evaluate_current_portfolio(self, weights: Dict[str, float]) -> PortfolioMetrics:
        """评估当前投资组合"""
        if self.returns_data is None:
            raise ValueError("No returns data loaded")

        return self.portfolio_engine.calculate_portfolio_metrics(
            weights, self.returns_data, self.risk_free_rate
        )


# 测试函数
def test_financial_optimization():
    """测试金融资产配置优化"""
    print("=== 金融资产配置优化测试 ===\n")

    # 生成模拟的收益率数据
    np.random.seed(42)
    n_assets = 6
    n_periods = 1000

    # 生成相关的收益率数据
    means = np.random.uniform(0.001, 0.003, n_assets)  # 日收益率
    cov = np.random.uniform(0.0001, 0.0003, (n_assets, n_assets))
    cov = (cov + cov.T) / 2  # 确保对称
    np.fill_diagonal(cov, np.random.uniform(0.0002, 0.0005, n_assets))  # 对角线元素稍大

    returns = np.random.multivariate_normal(means, cov, n_periods)
    returns_df = pd.DataFrame(returns, columns=[f'asset_{i}' for i in range(n_assets)])

    # 生成训练数据
    n_samples = 500
    portfolios = []

    for i in range(n_samples):
        weights = np.random.dirichlet(np.ones(n_assets), size=1)[0]
        weight_dict = {f'asset_{j}': weight for j, weight in enumerate(weights)}

        # 计算投资组合指标
        portfolio_returns = (returns_df * weights).sum(axis=1)
        expected_return = portfolio_returns.mean() * 252
        volatility = portfolio_returns.std() * np.sqrt(252)
        sharpe_ratio = (expected_return - 0.02) / volatility if volatility > 0 else 0

        portfolio_data = weight_dict.copy()
        portfolio_data['expected_return'] = expected_return
        portfolio_data['volatility'] = volatility
        portfolio_data['sharpe_ratio'] = sharpe_ratio

        portfolios.append(portfolio_data)

    training_data = pd.DataFrame(portfolios)

    print("训练数据统计:")
    print(f"样本数量: {len(training_data)}")
    print(f"夏普比率范围: {training_data['sharpe_ratio'].min():.3f} ~ {training_data['sharpe_ratio'].max():.3f}")
    print(f"预期收益范围: {training_data['expected_return'].min():.3f} ~ {training_data['expected_return'].max():.3f}")
    print()

    # 测试1: 正向优化 - 最大化夏普比率
    print("1. 正向优化 - 最大化夏普比率")
    config_forward = {
        "optimizationType": "forward",
        "optimizationMode": "training",
        "surrogateModel": "lightgbm",
        "optimizer": "pso",
        "variables": [
            {"name": f"asset_{i}", "type": "continuous", "bounds": [0.0, 0.5], "portfolio_weight": True}
            for i in range(n_assets)
        ],
        "objectives": [
            {"name": "maximize_sharpe", "expression": "[sharpe_ratio]", "type": "maximize"}
        ],
        "constraints": [
            {"expression": "[asset_0] + [asset_1] + [asset_2] <= 0.6", "type": "ineq"},
            {"expression": "[asset_3] + [asset_4] + [asset_5] >= 0.2", "type": "ineq"}
        ],
        "targetVariable": "sharpe_ratio",
        "optimizerParams": {"swarmsize": 20, "maxiter": 30}
    }

    engine_forward = EnhancedOptimizationEngine(config_forward)
    engine_forward.load_data(training_data)
    engine_forward.load_returns_data(returns_df)

    result_forward = engine_forward.run_optimization()

    if result_forward.success:
        print("✅ 正向优化成功!")
        print("最优配置:")
        for asset, weight in result_forward.optimal_variables.items():
            print(f"  {asset}: {weight:.3f} ({weight * 100:.1f}%)")

        if result_forward.portfolio_metrics:
            print("\n投资组合指标:")
            for metric, value in result_forward.portfolio_metrics.items():
                print(f"  {metric}: {value:.4f}")
    else:
        print("❌ 正向优化失败:", result_forward.message)

    print("\n" + "=" * 50)

    # 测试2: 逆向优化 - 根据目标夏普比率反推配置
    print("2. 逆向优化 - 目标夏普比率 = 1.0")
    config_inverse = {
        "optimizationType": "inverse",
        "optimizationMode": "training",
        "surrogateModel": "lightgbm",
        "optimizer": "pso",
        "variables": [
            {"name": f"asset_{i}", "type": "continuous", "bounds": [0.0, 0.5], "portfolio_weight": True}
            for i in range(n_assets)
        ],
        "constraints": [
            {"expression": "[asset_0] + [asset_1] + [asset_2] <= 0.7", "type": "ineq"}
        ],
        "targetVariable": "sharpe_ratio",
        "inverseTargetValue": 1.0,
        "inverseTargetVariable": "sharpe_ratio",
        "inverseTolerance": 0.05,
        "optimizerParams": {"swarmsize": 20, "maxiter": 30}
    }

    engine_inverse = EnhancedOptimizationEngine(config_inverse)
    engine_inverse.load_data(training_data)
    engine_inverse.load_returns_data(returns_df)

    result_inverse = engine_inverse.run_optimization()

    if result_inverse.success:
        print("✅ 逆向优化成功!")
        print("最优配置:")
        for asset, weight in result_inverse.optimal_variables.items():
            print(f"  {asset}: {weight:.3f} ({weight * 100:.1f}%)")

        # 验证结果
        input_df = pd.DataFrame([result_inverse.optimal_variables])
        achieved_sharpe = engine_inverse.model.predict(input_df, engine_inverse.variable_info)[0]
        print(f"目标夏普比率: 1.0, 实现夏普比率: {achieved_sharpe:.4f}")
    else:
        print("❌ 逆向优化失败:", result_inverse.message)

    print("\n" + "=" * 50)

    # 测试3: 多目标优化
    print("3. 多目标优化 - 平衡收益和风险")
    config_multi = {
        "optimizationType": "multi_objective",
        "optimizationMode": "training",
        "surrogateModel": "lightgbm",
        "optimizer": "pso",
        "variables": [
            {"name": f"asset_{i}", "type": "continuous", "bounds": [0.0, 0.5], "portfolio_weight": True}
            for i in range(n_assets)
        ],
        "objectives": [
            {"name": "maximize_return", "expression": "[expected_return]", "type": "maximize", "weight": 0.7},
            {"name": "minimize_volatility", "expression": "[volatility]", "type": "minimize", "weight": 0.3}
        ],
        "targetVariable": "expected_return",  # 主要用于训练
        "optimizerParams": {"swarmsize": 20, "maxiter": 30}
    }

    engine_multi = EnhancedOptimizationEngine(config_multi)
    engine_multi.load_data(training_data)
    engine_multi.load_returns_data(returns_df)

    result_multi = engine_multi.run_optimization()

    if result_multi.success:
        print("✅ 多目标优化成功!")
        print("最优配置:")
        for asset, weight in result_multi.optimal_variables.items():
            print(f"  {asset}: {weight:.3f} ({weight * 100:.1f}%)")

        if result_multi.portfolio_metrics:
            print("\n投资组合指标:")
            for metric, value in result_multi.portfolio_metrics.items():
                print(f"  {metric}: {value:.4f}")
    else:
        print("❌ 多目标优化失败:", result_multi.message)


if __name__ == "__main__":
    test_financial_optimization()