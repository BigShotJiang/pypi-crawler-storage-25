import traceback

import pandas as pd
import numpy as np
import logging
import re
import copy
from typing import Dict, List, Any, Optional
import ast


class TableDataEngine:
    """
    表格数据处理引擎
    封装所有数据处理方法，专注于数据转换，不返回统计信息
    """
    def __init__(self):
        """初始化引擎，不存储任何数据状态"""
        # 安全表达式评估的环境
        self.safe_env = {
            'pd': pd,
            'np': np,
            'abs': abs, 'min': min, 'max': max,
            'sum': sum, 'len': len, 'round': round,
            'sqrt': np.sqrt, 'log': np.log, 'exp': np.exp,
            'sin': np.sin, 'cos': np.cos, 'tan': np.tan,
        }

    def rename(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """字段重命名"""
        rename_mapping = config.get('renameMapping', {})

        if not rename_mapping:
            logging.warning("重命名映射为空，跳过此步骤")
            return data.copy()

        # 只重命名存在的列
        existing_columns = set(data.columns)
        valid_mapping = {old: new for old, new in rename_mapping.items() if old in existing_columns}

        if not valid_mapping:
            logging.warning("没有找到有效的列进行重命名")
            return data.copy()

        result_data = data.rename(columns=valid_mapping)
        logging.info(f"重命名完成: {valid_mapping}")

        return result_data

    def filter(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """数据筛选"""
        conditions = config.get('conditions', [])

        if not conditions:
            logging.warning("筛选条件为空，跳过此步骤")
            return data.copy()

        result_data = data.copy()

        # 操作符映射表 - 将前端操作符映射到后端处理逻辑
        operator_mapping = {
            # 等于和不等于
            '==': 'equals',
            '=': 'equals',
            'equals': 'equals',
            '!=': 'not_equals',
            '<>': 'not_equals',
            'not_equals': 'not_equals',

            # 比较操作符
            '>': 'greater_than',
            'greater_than': 'greater_than',
            '<': 'less_than',
            'less_than': 'less_than',
            '>=': 'greater_equal',
            'greater_equal': 'greater_equal',
            '<=': 'less_equal',
            'less_equal': 'less_equal',

            # 包含操作
            'contains': 'contains',
            'not_contains': 'not_contains',
            'in': 'contains',
            'not_in': 'not_contains',

            # 空值判断
            'is_null': 'is_null',
            'is_not_null': 'is_not_null',
            'null': 'is_null',
            'not_null': 'is_not_null'
        }

        # 构建筛选条件
        filter_condition = None
        for condition in conditions:
            column = condition.get('column')
            operator = condition.get('operator')
            value = condition.get('value')

            if not all([column, operator]) or column not in result_data.columns:
                logging.warning(f"条件不完整或列不存在: {column}")
                continue

            # 标准化操作符
            normalized_operator = operator_mapping.get(operator, operator)
            logging.info(f"处理条件: {column} {operator} -> {normalized_operator} {value}")

            # 构建单个条件
            try:
                if normalized_operator == 'equals':
                    cond = (result_data[column] == value)
                elif normalized_operator == 'not_equals':
                    cond = (result_data[column] != value)
                elif normalized_operator == 'greater_than':
                    cond = (result_data[column] > value)
                elif normalized_operator == 'less_than':
                    cond = (result_data[column] < value)
                elif normalized_operator == 'greater_equal':
                    cond = (result_data[column] >= value)
                elif normalized_operator == 'less_equal':
                    cond = (result_data[column] <= value)
                elif normalized_operator == 'contains':
                    # 对包含操作的值进行正则转义
                    escaped_value = re.escape(str(value))
                    cond = result_data[column].astype(str).str.contains(escaped_value, na=False, regex=True)
                elif normalized_operator == 'not_contains':
                    # 对不包含操作的值进行正则转义
                    escaped_value = re.escape(str(value))
                    cond = ~result_data[column].astype(str).str.contains(escaped_value, na=False, regex=True)
                elif normalized_operator == 'is_null':
                    cond = result_data[column].isna()
                elif normalized_operator == 'is_not_null':
                    cond = result_data[column].notna()
                else:
                    logging.warning(f"未知的操作符: {operator} (标准化后: {normalized_operator})")
                    continue

                # 组合条件
                if filter_condition is None:
                    filter_condition = cond
                else:
                    filter_condition = filter_condition & cond

            except Exception as e:
                import traceback
                logging.error(f"构建条件失败 {column} {operator} {value}: {str(e)} error: {traceback.format_exc()}")
                continue

        if filter_condition is not None:
            filtered_data = result_data[filter_condition]
            logging.info(f"数据筛选完成: {len(result_data)} -> {len(filtered_data)} 行")
            return filtered_data

        logging.warning("没有有效的筛选条件，返回原数据")
        return result_data

    def sample(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """数据采样"""
        sample_type = config.get('sampleType', 'whole')
        sample_method = config.get('sampleMethod', 'downsample')
        sample_ratio = config.get('sampleRatio', 10)
        sample_size = config.get('sampleSize')

        if sample_type == 'whole':
            logging.info("采样类型为完整数据，跳过采样")
            return data.copy()

        result_data = data.copy()

        try:
            if sample_method == 'downsample':
                # 下采样
                if sample_size:
                    sample_size = min(sample_size, len(result_data))
                else:
                    sample_size = max(1, len(result_data) // sample_ratio)
                result_data = result_data.sample(n=sample_size, random_state=42)

            elif sample_method == 'upsample':
                # 上采样（复制数据）
                if sample_size:
                    sample_size = min(sample_size, len(result_data) * 10)  # 限制最大上采样倍数
                else:
                    sample_size = len(result_data) * sample_ratio
                result_data = result_data.sample(n=sample_size, replace=True, random_state=42)

            elif sample_method == 'random':
                # 随机采样比例
                fraction = config.get('sampleFraction', 0.1)
                result_data = result_data.sample(frac=fraction, random_state=42)

            else:
                logging.warning(f"未知的采样方法: {sample_method}")
                return data.copy()

            logging.info(f"数据采样完成: {len(data)} -> {len(result_data)} 行")
            return result_data

        except Exception as e:
            logging.error(f"采样失败: {str(e)}")
            return data.copy()

    def deduplicate(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """数据去重"""
        deduplicate_columns = config.get('deduplicateColumns', [])
        keep_method = config.get('keepMethod', 'first')

        result_data = data.copy()

        try:
            if not deduplicate_columns:
                # 如果没有指定列，对所有列进行去重
                result_data = result_data.drop_duplicates(keep=keep_method)
            else:
                # 只对指定列进行去重
                existing_columns = [col for col in deduplicate_columns if col in result_data.columns]
                if existing_columns:
                    result_data = result_data.drop_duplicates(subset=existing_columns, keep=keep_method)
                else:
                    logging.warning("指定的去重列不存在，跳过此步骤")
                    return data.copy()

            logging.info(f"数据去重完成: {len(data)} -> {len(result_data)} 行")
            return result_data

        except Exception as e:
            logging.error(f"去重失败: {str(e)}")
            return data.copy()

    def type_transform(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """
        类型转换核心方法
        支持的配置格式：
        1. 标准格式：{'transformConfigs': [{'column': 'col', 'targetType': 'numeric'}]}
        2. 兼容格式：{'typeConfigs': [{'column': 'col', 'dataType': 'number', 'type': 'string_to_number'}]}
        3. 简化格式：{'column': 'col', 'targetType': 'numeric'}
        """
        logging.info(f"原始配置: {config}")
        # 步骤1：统一提取转换配置列表（修复原优先级逻辑缺陷）
        transform_configs = self._extract_transform_configs(config)
        logging.info(f"提取后的转换配置列表: {transform_configs}")

        result_data = data.copy()

        for transform in transform_configs:
            # 步骤2：标准化配置字段，解决字段名不匹配问题
            column, target_type = self._normalize_config(transform)

            # 校验必要参数
            if not column or not target_type:
                logging.warning(f"列名或目标类型为空，配置：{transform}，跳过类型转换")
                continue

            # 校验列是否存在
            if column not in result_data.columns:
                logging.warning(f"列 {column} 不存在，跳过类型转换")
                continue

            try:
                # 执行类型转换（传递原始配置，保留扩展参数）
                self._convert_column_type(result_data, column, target_type, transform)
                logging.info(f"类型转换完成: {column} -> {target_type}")
            except Exception as e:
                logging.error(f"类型转换失败 {column} -> {target_type}: {str(e)}", exc_info=True)

        return result_data

    def _extract_transform_configs(self, config: Dict) -> list:
        """
        提取并统一转换配置列表，修复原优先级逻辑缺陷
        优先级：简化格式（column+targetType/dataType）> transformConfigs > typeConfigs
        """
        # 先处理简化格式（单个列配置），避免被后续逻辑覆盖
        if 'column' in config and ('targetType' in config or 'dataType' in config):
            return [config]
        # 再处理批量配置
        elif "transformConfigs" in config:
            return config.get("transformConfigs", [])
        elif "typeConfigs" in config:
            return config.get("typeConfigs", [])
        else:
            logging.warning("未找到任何类型转换配置")
            return []

    def _normalize_config(self, transform: Dict) -> tuple:
        """
        标准化配置字段，解决字段名不匹配问题
        返回：(column, target_type)
        """
        # 1. 提取列名（兼容column字段）
        column = transform.get('column')

        # 2. 提取目标类型（兼容targetType/dataType/type，做类型映射）
        # 原始配置中的类型映射：number -> numeric，string_to_number -> numeric（示例）
        type_mapping = {
            'number': 'numeric',  # 配置中的number映射为代码支持的numeric
            'string': 'string',
            'int': 'integer',
            'float': 'float',
            'bool': 'boolean',
            'datetime': 'datetime',
            'category': 'category',
            # 处理配置中的转换类型标识（如string_to_number）
            'string_to_number': 'numeric',
            'number_to_string': 'string'
        }

        # 优先读取targetType，其次dataType，最后type
        raw_type = transform.get('targetType') or transform.get('dataType') or transform.get('type')
        # 映射为代码支持的目标类型
        target_type = type_mapping.get(raw_type, raw_type) if raw_type else None

        # 3. 特殊处理：如果type是转换方式（如string_to_number），dataType是实际类型
        # 例如：{'column': 'f6', 'dataType': 'number', 'type': 'string_to_number'}
        if transform.get('type') in ['string_to_number', 'number_to_string'] and transform.get('dataType'):
            target_type = type_mapping.get(transform.get('dataType'), transform.get('dataType'))

        return column, target_type

    def _convert_column_type(self, data: pd.DataFrame, column: str, target_type: str, config: Dict = None):
        """执行单个列的类型转换（保留原有逻辑，仅优化注释）"""
        if config is None:
            config = {}

        # 日期格式参数
        date_format = config.get('dateFormat')
        # 数值处理参数
        decimal_separator = config.get('decimalSeparator', '.')
        thousands_separator = config.get('thousandsSeparator', '')
        # 布尔值映射
        true_values = config.get('trueValues', ['true', 'yes', '1', '是', 't', 'y'])
        false_values = config.get('falseValues', ['false', 'no', '0', '否', 'f', 'n'])

        if target_type == 'string':
            data[column] = data[column].astype(str)

        elif target_type == 'numeric':
            # 处理千分位分隔符
            series = data[column].astype(str)
            if thousands_separator:
                series = series.str.replace(thousands_separator, '', regex=False)
            if decimal_separator != '.':
                series = series.str.replace(decimal_separator, '.', regex=False)
            data[column] = pd.to_numeric(series, errors='coerce')

        elif target_type == 'integer':
            # 先转换为数值，再转换为整数
            series = data[column].astype(str)
            if thousands_separator:
                series = series.str.replace(thousands_separator, '', regex=False)
            data[column] = pd.to_numeric(series, errors='coerce').astype('Int64')

        elif target_type == 'float':
            series = data[column].astype(str)
            if thousands_separator:
                series = series.str.replace(thousands_separator, '', regex=False)
            if decimal_separator != '.':
                series = series.str.replace(decimal_separator, '.', regex=False)
            data[column] = pd.to_numeric(series, errors='coerce').astype(float)

        elif target_type == 'datetime':
            if date_format:
                data[column] = pd.to_datetime(data[column], format=date_format, errors='coerce')
            else:
                data[column] = pd.to_datetime(data[column], errors='coerce')

        elif target_type == 'boolean':
            # 自定义布尔值映射
            def custom_bool_convert(x):
                if pd.isna(x):
                    return pd.NA
                x_str = str(x).lower().strip()
                if x_str in [v.lower() for v in true_values]:
                    return True
                elif x_str in [v.lower() for v in false_values]:
                    return False
                else:
                    try:
                        return bool(float(x))
                    except:
                        return pd.NA

            data[column] = data[column].apply(custom_bool_convert).astype('boolean')

        elif target_type == 'category':
            data[column] = data[column].astype('category')

        else:
            raise ValueError(f"不支持的目标类型: {target_type}")

    def sort(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """数据排序"""
        sort_by = config.get('sortBy', [])

        if not sort_by:
            logging.warning("排序条件为空，跳过此步骤")
            return data.copy()

        result_data = data.copy()
        sort_columns = []
        ascending_flags = []

        for sort_item in sort_by:
            column = sort_item.get('column')
            order = sort_item.get('order', 'asc')

            if column not in result_data.columns:
                logging.warning(f"排序列 {column} 不存在，跳过")
                continue

            sort_columns.append(column)
            ascending_flags.append(order.lower() == 'asc')

        if sort_columns:
            result_data = result_data.sort_values(by=sort_columns, ascending=ascending_flags)
            logging.info(f"数据排序完成: 按 {sort_columns} 排序")
            return result_data

        return result_data

    def feature_derive(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """特征衍生"""
        new_features = config.get('newFeatures', [])

        result_data = data.copy()

        for feature in new_features:
            feature_name = feature.get('name')
            expression = feature.get('expression')

            if not feature_name or not expression:
                logging.warning("特征名称或表达式为空，跳过")
                continue

            # 检查特征名是否已存在
            if feature_name in result_data.columns:
                logging.warning(f"特征名 {feature_name} 已存在，跳过")
                continue

            try:
                # 安全地执行表达式
                result_data[feature_name] = self._safe_eval_expression(expression, result_data)
                logging.info(f"特征衍生完成: {feature_name} = {expression}")

            except Exception as e:
                logging.error(f"特征衍生失败 {feature_name}: {str(e)}")

        return result_data

    def _safe_eval_expression(self, expression: str, data: pd.DataFrame) -> pd.Series:
        """安全地评估表达式"""
        # 替换列引用为安全的访问方式
        def replace_column_ref(match):
            col_name = match.group(1)
            if col_name in data.columns:
                return f"data['{col_name}']"
            else:
                raise ValueError(f"列 '{col_name}' 不存在")

        # 处理 [column] 格式的引用
        safe_expr = re.sub(r'\[(.*?)\]', replace_column_ref, expression)

        # 创建安全环境
        local_env = self.safe_env.copy()
        local_env['data'] = data

        try:
            # 使用 ast 进行安全解析
            parsed_expr = ast.parse(safe_expr, mode='eval')
            result = eval(compile(parsed_expr, '<string>', 'eval'), {"__builtins__": {}}, local_env)
            return result
        except Exception as e:
            # 如果安全方式失败，尝试原始方式（保持向后兼容）
            try:
                local_env['df'] = data  # 向后兼容
                return eval(expression, {"__builtins__": {}}, local_env)
            except:
                raise e

    def merge(self, left_df: pd.DataFrame, right_df: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """
        数据合并优化：
        1. 适配前端配置字段（selectedKeys/mergeHow/suffixes等）
        2. 支持列连接、索引连接、交叉连接
        3. 支持列筛选
        4. 完善异常处理和日志
        """
        # -------------------------- 1. 提取前端配置并做兼容处理 --------------------------
        # 前端字段映射（根据前端实际传递的字段名调整，与前端generateConfig对应）
        merge_on_type = config.get('mergeOn', 'columns')  # columns/index
        merge_keys = config.get('selectedKeys', [])       # 连接键（列名列表）
        merge_type = config.get('mergeHow', 'inner')      # inner/left/right/outer/cross
        suffixes = config.get('suffixes', {'left': '_x', 'right': '_y'})
        suffix_left = suffixes.get('left', '_x')
        suffix_right = suffixes.get('right', '_y')

        # 列筛选配置
        selected_left_cols = config.get('selectedLeftColumns', left_df.columns.tolist())
        selected_right_cols = config.get('selectedRightColumns', right_df.columns.tolist())

        # -------------------------- 2. 列筛选（前端选择的列） --------------------------
        try:
            # 校验筛选的列是否存在，不存在则保留原列
            valid_left_cols = [col for col in selected_left_cols if col in left_df.columns]
            valid_right_cols = [col for col in selected_right_cols if col in right_df.columns]

            if not valid_left_cols:
                logging.warning("No valid left columns selected, using all columns")
                valid_left_cols = left_df.columns.tolist()
            if not valid_right_cols:
                logging.warning("No valid right columns selected, using all columns")
                valid_right_cols = right_df.columns.tolist()

            # 应用列筛选
            left_df_filtered = left_df[valid_left_cols].copy()
            right_df_filtered = right_df[valid_right_cols].copy()
        except Exception as e:
            logging.error(f"Column filtering failed: {str(e)}, using original columns")
            left_df_filtered = left_df.copy()
            right_df_filtered = right_df.copy()

        # -------------------------- 3. 处理不同的合并方式 --------------------------
        try:
            # 3.1 交叉连接（cross）：无需连接键，直接笛卡尔积
            if merge_type == 'cross':
                merged_df = pd.merge(
                    left_df_filtered,
                    right_df_filtered,
                    how='cross'
                )
                logging.info(f"Cross merge completed: shape {merged_df.shape}")
                return merged_df

            # 3.2 索引连接（index）：使用索引作为连接键
            elif merge_on_type == 'index':
                merged_df = pd.merge(
                    left_df_filtered,
                    right_df_filtered,
                    how=merge_type,
                    left_index=True,
                    right_index=True,
                    suffixes=(suffix_left, suffix_right)
                )
                logging.info(f"Index merge completed: shape {merged_df.shape}")
                return merged_df

            # 3.3 列连接（columns）：使用指定的列作为连接键
            elif merge_on_type == 'columns':
                # 校验合并键是否为空
                if not merge_keys:
                    logging.error("Merge keys are empty for column merge")
                    # 可选：返回左表或抛出异常，根据业务需求调整
                    return left_df_filtered.copy()

                # 校验合并键是否存在于两个表中
                missing_left = [key for key in merge_keys if key not in left_df_filtered.columns]
                missing_right = [key for key in merge_keys if key not in right_df_filtered.columns]

                if missing_left or missing_right:
                    error_msg = f"Merge keys not found: left missing {missing_left}, right missing {missing_right}"
                    logging.error(error_msg)
                    # 可选：返回左表或抛出异常
                    return left_df_filtered.copy()

                # 执行列连接
                merged_df = pd.merge(
                    left_df_filtered,
                    right_df_filtered,
                    on=merge_keys,
                    how=merge_type,
                    suffixes=(suffix_left, suffix_right)
                )
                logging.info(f"Column merge completed: shape {merged_df.shape} (keys: {merge_keys}, type: {merge_type})")
                return merged_df

            # 3.4 未知的合并方式
            else:
                logging.error(f"Unsupported merge on type: {merge_on_type}, using left dataframe")
                return left_df_filtered.copy()

        # -------------------------- 4. 合并异常处理 --------------------------
        except Exception as e:
            import traceback
            logging.error(f"Merge failed: {str(e)}, using left dataframe   {traceback.format_exc()}")
            # 可选：抛出异常（raise e）或返回左表，根据业务需求调整
            return left_df_filtered.copy()

    def append(self, dataframes: List[pd.DataFrame]) -> pd.DataFrame:
        """数据追加"""
        if not dataframes:
            return pd.DataFrame()

        try:
            # 检查所有数据框的列是否一致
            first_columns = set(dataframes[0].columns)
            for i, df in enumerate(dataframes[1:], 1):
                if set(df.columns) != first_columns:
                    logging.warning(f"数据框 {i} 的列不一致，尝试对齐列")
                    # 对齐列
                    all_columns = list(first_columns.union(set(df.columns)))
                    for j, temp_df in enumerate(dataframes):
                        for col in all_columns:
                            if col not in temp_df.columns:
                                temp_df[col] = np.nan
                        dataframes[j] = temp_df[all_columns]

            appended_df = pd.concat(dataframes, ignore_index=True)
            logging.info(f"数据追加完成: 合并 {len(dataframes)} 个数据框")
            return appended_df

        except Exception as e:
            logging.error(f"数据追加失败: {str(e)}")
            return dataframes[0].copy() if dataframes else pd.DataFrame()

    def advanced_filter(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """高级筛选（支持行列筛选）"""
        filter_mode = config.get("filterMode", "include")
        selected_columns = config.get("selectedColumns", [])
        conditions = config.get("conditions", [])

        result_data = data.copy()

        # 第一步：行筛选
        if conditions:
            result_data = self.filter(result_data, {"conditions": conditions})
            logging.info(f'应用了 {len(conditions)} 个行筛选条件')

        # 第二步：列筛选
        if selected_columns:
            available_columns = [col for col in selected_columns if col in result_data.columns]

            if filter_mode == 'include':
                # 只保留选中的列
                if available_columns:
                    result_data = result_data[available_columns]
                else:
                    logging.warning("没有有效的列包含，保持原数据")
            else:  # exclude
                # 排除选中的列
                columns_to_keep = [col for col in result_data.columns if col not in selected_columns]
                result_data = result_data[columns_to_keep]

            logging.info(f'应用了列筛选 ({filter_mode})')

        return result_data

    def data_edit(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """数据编辑操作"""
        selected_operation = config.get('selectedOperation')
        selected_columns = config.get('selectedColumns', [])

        result_data = data.copy()

        # 先执行列筛选
        if selected_columns and isinstance(selected_columns, list) and len(selected_columns) > 0:
            valid_columns = [col for col in selected_columns if col in result_data.columns]
            if valid_columns:
                result_data = result_data[valid_columns]

        # 根据操作类型执行相应操作
        logging.info(f"selected_operation###:{selected_operation}")
        logging.info(f"config#####:{config}")
        if selected_operation == 'expression':
            result_data = self._process_expression_columns(result_data, config.get('expressionColumns', []))
        elif selected_operation == 'merge':
            result_data = self._process_merge_columns(result_data, config.get('mergeColumns', []))
        elif selected_operation == 'pivot':
            result_data = self._process_pivot_columns(result_data, config.get('pivotColumns', []))

        return result_data

    def _process_expression_columns(self, data: pd.DataFrame, expression_columns: List[Dict]) -> pd.DataFrame:
        """处理表达式列衍生"""
        result_data = data.copy()

        for expr_col in expression_columns:
            if not isinstance(expr_col, dict):
                continue

            col_name = expr_col.get('name')
            expression = expr_col.get('expression')

            if not col_name or not expression:
                continue

            # 检查列名是否已存在
            if col_name in result_data.columns:
                logging.warning(f'列名 {col_name} 已存在，跳过')
                continue

            try:
                result_data[col_name] = self._safe_eval_expression(expression, result_data)
            except Exception as e:
                logging.error(f"表达式列衍生失败 {col_name}: {str(e)}")

        return result_data

    def _process_merge_columns(self, data: pd.DataFrame, merge_columns: List[Dict]) -> pd.DataFrame:
        """处理列合并"""
        result_data = data.copy()

        for merge_col in merge_columns:
            if not isinstance(merge_col, dict):
                continue

            col_name = merge_col.get('name')
            source_columns = merge_col.get('sourceColumns', [])
            separator = merge_col.get('separator', '_')

            if not col_name or not isinstance(source_columns, list) or len(source_columns) < 2:
                continue

            # 检查列名是否已存在
            if col_name in result_data.columns:
                logging.warning(f'列名 {col_name} 已存在，跳过')
                continue

            try:
                missing_cols = [col for col in source_columns if col not in result_data.columns]

                if missing_cols:
                    logging.error(f'缺失源列: {missing_cols}')
                    continue

                # 执行列合并
                result_data[col_name] = result_data[source_columns].apply(
                    lambda row: separator.join([str(val) for val in row if pd.notna(val) and str(val).strip() != '']),
                    axis=1
                )

            except Exception as e:
                logging.error(f"列合并失败 {col_name}: {str(e)}")

        return result_data

    def _process_pivot_columns(self, data: pd.DataFrame, pivot_columns: List[Dict]) -> pd.DataFrame:
        """处理透视表生成"""
        # 简化实现，实际应用中需要更复杂的处理
        logging.info("透视表功能需要单独实现，当前版本暂不支持完整的透视表操作")
        return data.copy()

    def fill_missing(self, data: pd.DataFrame, config: Dict) -> pd.DataFrame:
        """填充缺失值"""
        fill_configs = config.get('fillConfigs', [])
        result_data = data.copy()

        for fill_config in fill_configs:
            column = fill_config.get('column')
            method = fill_config.get('method', 'mean')
            value = fill_config.get('value')

            if not column or column not in result_data.columns:
                continue

            try:
                if method == 'mean':
                    fill_value = result_data[column].mean()
                elif method == 'median':
                    fill_value = result_data[column].median()
                elif method == 'mode':
                    fill_value = result_data[column].mode()[0] if not result_data[column].mode().empty else None
                elif method == 'value':
                    fill_value = value
                elif method == 'forward':
                    result_data[column] = result_data[column].fillna(method='ffill')
                    continue
                elif method == 'backward':
                    result_data[column] = result_data[column].fillna(method='bfill')
                    continue
                else:
                    continue

                if fill_value is not None:
                    result_data[column] = result_data[column].fillna(fill_value)

                logging.info(f"填充完成: {column} 使用 {method} 方法")

            except Exception as e:
                logging.error(f"填充失败 {column}: {str(e)}")

        return result_data

    def get_sample_data(self, data: pd.DataFrame, n: int = 5) -> List[Dict]:
        """获取样例数据"""
        if data is None or len(data) == 0:
            return []

        sample_size = min(n, len(data))
        sample_df = data.head(sample_size)

        # 转换DataFrame为字典列表
        sample_data = sample_df.replace({np.nan: None}).to_dict('records')

        return sample_data

    def validate_data(self, data: pd.DataFrame) -> Dict[str, Any]:
        """验证数据质量"""
        if data is None or len(data) == 0:
            return {
                "valid": False,
                "message": "数据为空"
            }

        total_rows = len(data)
        total_columns = len(data.columns)

        # 检查缺失值
        missing_values = data.isnull().sum().to_dict()
        total_missing = sum(missing_values.values())

        # 检查重复行
        duplicate_rows = data.duplicated().sum()

        quality_score = max(0, 100 -
                            (total_missing / (total_rows * total_columns) * 50) -
                            (duplicate_rows / total_rows * 50))

        return {
            "valid": True,
            "total_rows": total_rows,
            "total_columns": total_columns,
            "total_missing": total_missing,
            "duplicate_rows": duplicate_rows,
            "quality_score": round(quality_score, 2)
        }

    def get_statistics(self, data: pd.DataFrame) -> Dict[str, Any]:
        """获取数据统计信息"""
        if data is None or len(data) == 0:
            return {}

        stats = {
            "shape": data.shape,
            "columns": list(data.columns),
            "data_types": data.dtypes.astype(str).to_dict(),
            "memory_usage": data.memory_usage(deep=True).sum(),
            "missing_percentage": (data.isnull().sum() / len(data)).to_dict()
        }

        return stats


def test_table_data_engine():
    """测试表格数据处理引擎"""
    engine = TableDataEngine()

    # 创建测试数据
    base_df = pd.DataFrame({
        'id': [1, 2, 3, 4, 5],
        'name': ['Alice', 'Bob', 'Charlie', 'David', 'Eve'],
        'age': [25, 30, 35, 40, 45],
        'salary': [50000, 60000, 70000, 80000, 90000],
        'department': ['IT', 'HR', 'IT', 'Finance', 'HR']
    })

    # 测试重命名
    renamed_df = engine.rename(base_df, {
        'renameMapping': {
            'id': 'employee_id',
            'name': 'employee_name'
        }
    })
    print(f"重命名结果: {list(renamed_df.columns)}")

    # 测试筛选
    filtered_df = engine.filter(base_df, {
        'conditions': [
            {'column': 'age', 'operator': 'greater_than', 'value': 30},
            {'column': 'department', 'operator': 'equals', 'value': 'IT'}
        ]
    })
    print(f"筛选结果: {len(filtered_df)} 行数据")

    # 测试特征衍生
    feature_df = engine.feature_derive(base_df, {
        'newFeatures': [
            {'name': 'bonus', 'expression': '[salary] * 0.1'},
            {'name': 'age_group', 'expression': "np.where([age] > 35, 'Senior', 'Junior')"}
        ]
    })
    print(f"特征衍生结果: {list(feature_df.columns)}")

    # 测试数据验证
    validation_result = engine.validate_data(base_df)
    print(f"数据验证 - 质量分数: {validation_result['quality_score']}")

    print("所有测试完成！")


import pandas as pd
import numpy as np
import logging
from datetime import datetime, timedelta
import random


def comprehensive_test_table_data_engine():
    """全面测试表格数据处理引擎"""
    engine = TableDataEngine()

    print("=" * 60)
    print("开始全面测试表格数据处理引擎")
    print("=" * 60)

    # 测试1: 基础数据创建
    print("\n1. 基础数据创建测试")
    base_df = create_test_data()
    print(f"创建测试数据: {base_df.shape}")
    print(f"列名: {list(base_df.columns)}")
    print(f"前3行数据:")
    print(base_df.head(3))

    # 测试2: 重命名功能
    print("\n2. 重命名功能测试")
    test_rename(engine, base_df.copy())

    # 测试3: 数据筛选功能
    print("\n3. 数据筛选功能测试")
    test_filter(engine, base_df.copy())

    # 测试4: 数据采样功能
    print("\n4. 数据采样功能测试")
    test_sample(engine, base_df.copy())

    # 测试5: 数据去重功能
    print("\n5. 数据去重功能测试")
    test_deduplicate(engine, base_df.copy())

    # 测试6: 类型转换功能
    print("\n6. 类型转换功能测试")
    test_type_transform(engine)

    # 测试7: 数据排序功能
    print("\n7. 数据排序功能测试")
    test_sort(engine, base_df.copy())

    # 测试8: 特征衍生功能
    print("\n8. 特征衍生功能测试")
    test_feature_derive(engine, base_df.copy())

    # 测试9: 数据合并功能
    print("\n9. 数据合并功能测试")
    test_merge(engine)

    # 测试10: 数据追加功能
    print("\n10. 数据追加功能测试")
    test_append(engine)

    # 测试11: 高级筛选功能
    print("\n11. 高级筛选功能测试")
    test_advanced_filter(engine, base_df.copy())

    # 测试12: 数据编辑功能
    print("\n12. 数据编辑功能测试")
    test_data_edit(engine, base_df.copy())

    # 测试13: 缺失值填充功能
    print("\n13. 缺失值填充功能测试")
    test_fill_missing(engine)

    # 测试14: 数据验证功能
    print("\n14. 数据验证功能测试")
    test_validate_data(engine, base_df.copy())

    # 测试15: 复杂场景集成测试
    print("\n15. 复杂场景集成测试")
    test_complex_scenario(engine)

    print("\n" + "=" * 60)
    print("所有测试完成！")
    print("=" * 60)


def create_test_data():
    """创建综合测试数据"""
    np.random.seed(42)
    random.seed(42)

    # 基础数据
    data = {
        'id': range(1, 101),
        'name': [f'User_{i}' for i in range(1, 101)],
        'age': np.random.randint(18, 65, 100),
        'salary': np.random.randint(30000, 150000, 100),
        'department': np.random.choice(['IT', 'HR', 'Finance', 'Marketing', 'Operations'], 100),
        'join_date': [datetime(2020, 1, 1) + timedelta(days=np.random.randint(0, 1000)) for _ in range(100)],
        'performance_score': np.random.uniform(1.0, 5.0, 100).round(2),
        'is_active': np.random.choice([True, False], 100, p=[0.8, 0.2])
    }

    # 添加一些重复数据用于测试去重
    data['duplicate_col'] = np.random.choice(['A', 'B', 'C', 'D'], 100)

    return pd.DataFrame(data)


def test_rename(engine, df):
    """测试重命名功能"""
    print("原始列名:", list(df.columns))

    # 测试1: 正常重命名
    result1 = engine.rename(df, {
        'renameMapping': {
            'id': 'employee_id',
            'name': 'employee_name',
            'salary': 'annual_salary'
        }
    })
    print("重命名后:", list(result1.columns))

    # 测试2: 包含不存在的列
    result2 = engine.rename(df, {
        'renameMapping': {
            'id': 'new_id',
            'nonexistent_col': 'new_col'  # 不存在的列
        }
    })
    print("包含不存在列的重命名:", list(result2.columns))

    # 测试3: 空映射
    result3 = engine.rename(df, {'renameMapping': {}})
    print("空映射重命名:", list(result3.columns))

    assert 'employee_id' in result1.columns
    assert 'id' not in result1.columns
    assert 'nonexistent_col' not in result2.columns


def test_filter(engine, df):
    """测试数据筛选功能"""
    original_count = len(df)

    # 测试1: 单条件筛选
    result1 = engine.filter(df, {
        'conditions': [
            {'column': 'age', 'operator': 'greater_than', 'value': 30}
        ]
    })
    print(f"年龄>30筛选: {original_count} -> {len(result1)}")
    assert all(result1['age'] > 30)

    # 测试2: 多条件组合筛选
    result2 = engine.filter(df, {
        'conditions': [
            {'column': 'age', 'operator': 'greater_equal', 'value': 25},
            {'column': 'department', 'operator': 'equals', 'value': 'IT'},
            {'column': 'salary', 'operator': 'greater_than', 'value': 50000}
        ]
    })
    print(f"多条件筛选: {original_count} -> {len(result2)}")

    # 测试3: 包含条件
    result3 = engine.filter(df, {
        'conditions': [
            {'column': 'name', 'operator': 'contains', 'value': 'User_1'}
        ]
    })
    print(f"包含'User_1'筛选: {original_count} -> {len(result3)}")
    assert all('User_1' in name for name in result3['name'])

    # 测试4: 空值条件
    df_with_nulls = df.copy()
    df_with_nulls.loc[10:15, 'age'] = None
    result4 = engine.filter(df_with_nulls, {
        'conditions': [
            {'column': 'age', 'operator': 'is_not_null', 'value': None}
        ]
    })
    print(f"非空年龄筛选: {len(df_with_nulls)} -> {len(result4)}")

    # 测试5: 不存在列的条件
    result5 = engine.filter(df, {
        'conditions': [
            {'column': 'nonexistent_col', 'operator': 'equals', 'value': 'test'}
        ]
    })
    print(f"不存在列筛选: {original_count} -> {len(result5)} (应保持不变)")


def test_sample(engine, df):
    """测试数据采样功能"""
    original_count = len(df)

    # 测试1: 下采样
    result1 = engine.sample(df, {
        'sampleType': 'partial',
        'sampleMethod': 'downsample',
        'sampleSize': 10
    })
    print(f"下采样到10行: {original_count} -> {len(result1)}")
    assert len(result1) == 10

    # 测试2: 上采样
    result2 = engine.sample(df, {
        'sampleType': 'partial',
        'sampleMethod': 'upsample',
        'sampleSize': 150
    })
    print(f"上采样到150行: {original_count} -> {len(result2)}")
    assert len(result2) == 150

    # 测试3: 随机比例采样
    result3 = engine.sample(df, {
        'sampleType': 'partial',
        'sampleMethod': 'random',
        'sampleFraction': 0.2
    })
    print(f"20%随机采样: {original_count} -> {len(result3)}")

    # 测试4: 完整数据（不采样）
    result4 = engine.sample(df, {
        'sampleType': 'whole'
    })
    print(f"完整数据: {original_count} -> {len(result4)}")
    assert len(result4) == original_count


def test_deduplicate(engine, df):
    """测试数据去重功能"""
    # 创建有重复数据的数据框
    duplicate_df = pd.concat([df, df.head(10)], ignore_index=True)
    original_count = len(duplicate_df)

    print(f"去重前数据量: {original_count}")

    # 测试1: 基于特定列去重
    result1 = engine.deduplicate(duplicate_df, {
        'deduplicateColumns': ['id', 'name'],
        'keepMethod': 'first'
    })
    print(f"基于id,name去重: {original_count} -> {len(result1)}")

    # 测试2: 全列去重
    result2 = engine.deduplicate(duplicate_df, {
        'deduplicateColumns': [],
        'keepMethod': 'last'
    })
    print(f"全列去重: {original_count} -> {len(result2)}")

    # 测试3: 基于不存在列去重
    result3 = engine.deduplicate(duplicate_df, {
        'deduplicateColumns': ['nonexistent_col'],
        'keepMethod': 'first'
    })
    print(f"基于不存在列去重: {original_count} -> {len(result3)} (应保持不变)")

    assert len(result1) <= original_count
    assert len(result2) <= original_count


def test_type_transform(engine):
    """测试类型转换功能"""
    # 创建包含各种数据类型的测试数据
    type_test_df = pd.DataFrame({
        'string_numbers': ['100', '200', '300', '400', '500'],
        'formatted_numbers': ['1,000.50', '2,500.75', '3,000.25', '4,500.80', 'invalid'],
        'date_strings': ['2023-01-01', '2023-02-15', '2023-03-20', '2023-04-10', 'invalid_date'],
        'boolean_strings': ['true', 'false', 'yes', 'no', '1' ],
        'mixed_data': ['100', '200.5', 'text', '300', '400.75'],
        'categories': ['A', 'B', 'A', 'C', 'B']
    })

    print("原始数据类型:")
    print(type_test_df.dtypes)

    # 测试综合类型转换
    result = engine.type_transform(type_test_df, {
        'transformConfigs': [
            {
                'column': 'string_numbers',
                'targetType': 'integer'
            },
            {
                'column': 'formatted_numbers',
                'targetType': 'float',
                'thousandsSeparator': ',',
                'decimalSeparator': '.'
            },
            {
                'column': 'date_strings',
                'targetType': 'datetime',
                'dateFormat': '%Y-%m-%d'
            },
            {
                'column': 'boolean_strings',
                'targetType': 'boolean',
                'trueValues': ['true', 'yes', '1'],
                'falseValues': ['false', 'no', '0']
            },
            {
                'column': 'mixed_data',
                'targetType': 'numeric'
            },
            {
                'column': 'categories',
                'targetType': 'category'
            }
        ]
    })

    print("\n转换后数据类型:")
    print(result.dtypes)
    print("\n转换后数据样例:")
    print(result.head())


def test_sort(engine, df):
    """测试数据排序功能"""
    print("原始数据前5行:")
    print(df[['id', 'age', 'salary']].head())

    # 测试1: 单列排序
    result1 = engine.sort(df, {
        'sortBy': [
            {'column': 'age', 'order': 'asc'}
        ]
    })
    print("\n按年龄升序排序前5行:")
    print(result1[['id', 'age', 'salary']].head())
    assert all(result1['age'].values == np.sort(result1['age'].values))

    # 测试2: 多列排序
    result2 = engine.sort(df, {
        'sortBy': [
            {'column': 'department', 'order': 'asc'},
            {'column': 'salary', 'order': 'desc'}
        ]
    })
    print("\n按部门升序、工资降序排序前5行:")
    print(result2[['id', 'department', 'salary']].head())

    # 测试3: 包含不存在列的排序
    result3 = engine.sort(df, {
        'sortBy': [
            {'column': 'nonexistent_col', 'order': 'asc'},
            {'column': 'age', 'order': 'desc'}
        ]
    })
    print(f"包含不存在列排序后的数据量: {len(result3)}")


def test_feature_derive(engine, df):
    """测试特征衍生功能"""
    original_columns = set(df.columns)

    # 测试1: 数值计算特征
    result1 = engine.feature_derive(df, {
        'newFeatures': [
            {
                'name': 'salary_to_age_ratio',
                'expression': '[salary] / [age]'
            },
            {
                'name': 'bonus',
                'expression': '[salary] * 0.1 + [performance_score] * 1000'
            }
        ]
    })
    new_columns1 = set(result1.columns) - original_columns
    print(f"衍生数值特征: {new_columns1}")
    print("新特征样例:")
    print(result1[['salary', 'age', 'salary_to_age_ratio']].head())

    # 测试2: 条件特征
    result2 = engine.feature_derive(df, {
        'newFeatures': [
            {
                'name': 'age_group',
                'expression': "np.where([age] < 30, 'Young', np.where([age] < 50, 'Middle', 'Senior'))"
            },
            {
                'name': 'high_performer',
                'expression': "([performance_score] > 4.0) & ([salary] > 80000)"
            }
        ]
    })
    new_columns2 = set(result2.columns) - original_columns
    print(f"\n衍生条件特征: {new_columns2}")

    # 测试3: 字符串特征
    result3 = engine.feature_derive(df, {
        'newFeatures': [
            {
                'name': 'name_length',
                'expression': "[name].str.len()"
            }
        ]
    })
    print(f"\n衍生字符串特征: 名称长度统计")


def test_merge(engine):
    """测试数据合并功能"""
    # 创建两个测试数据框
    employees_df = pd.DataFrame({
        'emp_id': [1, 2, 3, 4, 5],
        'name': ['Alice', 'Bob', 'Charlie', 'David', 'Eve'],
        'dept_id': [101, 102, 101, 103, 102]
    })

    departments_df = pd.DataFrame({
        'dept_id': [101, 102, 104],
        'dept_name': ['Engineering', 'Marketing', 'Sales'],
        'manager': ['John', 'Jane', 'Mike']
    })

    print("员工表:")
    print(employees_df)
    print("\n部门表:")
    print(departments_df)

    # 测试1: 内连接
    result1 = engine.merge(employees_df, departments_df, {
        'mergeKeys': ['dept_id'],
        'mergeType': 'inner'
    })
    print(f"\n内连接结果 ({result1.shape}):")
    print(result1)

    # 测试2: 左连接
    result2 = engine.merge(employees_df, departments_df, {
        'mergeKeys': ['dept_id'],
        'mergeType': 'left'
    })
    print(f"\n左连接结果 ({result2.shape}):")
    print(result2)

    # 测试3: 不存在键的连接
    result3 = engine.merge(employees_df, departments_df, {
        'mergeKeys': ['nonexistent_key'],
        'mergeType': 'inner'
    })
    print(f"\n不存在键连接结果: {result3.shape} (应返回左表)")


def test_append(engine):
    """测试数据追加功能"""
    # 创建多个测试数据框
    df1 = pd.DataFrame({
        'A': [1, 2, 3],
        'B': ['X', 'Y', 'Z'],
        'C': [10.1, 20.2, 30.3]
    })

    df2 = pd.DataFrame({
        'A': [4, 5, 6],
        'B': ['P', 'Q', 'R'],
        'C': [40.4, 50.5, 60.6]
    })

    df3 = pd.DataFrame({
        'A': [7, 8],
        'B': ['S', 'T'],
        'C': [70.7, 80.8],
        'D': ['new', 'col']  # 额外列
    })

    print("数据框1:")
    print(df1)
    print("\n数据框2:")
    print(df2)
    print("\n数据框3 (有额外列):")
    print(df3)

    # 测试追加
    result = engine.append([df1, df2, df3])
    print(f"\n追加后结果 ({result.shape}):")
    print(result)


def test_advanced_filter(engine, df):
    """测试高级筛选功能"""
    original_shape = df.shape

    # 测试1: 包含模式的列筛选
    result1 = engine.advanced_filter(df, {
        'filterMode': 'include',
        'selectedColumns': ['id', 'name', 'age', 'salary'],
        'conditions': [
            {'column': 'age', 'operator': 'greater_than', 'value': 30},
            {'column': 'salary', 'operator': 'greater_than', 'value': 60000}
        ]
    })
    print(f"包含模式筛选: {original_shape} -> {result1.shape}")
    print("结果列:", list(result1.columns))

    # 测试2: 排除模式的列筛选
    result2 = engine.advanced_filter(df, {
        'filterMode': 'exclude',
        'selectedColumns': ['id', 'join_date'],  # 排除这些列
        'conditions': [
            {'column': 'department', 'operator': 'equals', 'value': 'IT'}
        ]
    })
    print(f"\n排除模式筛选: {original_shape} -> {result2.shape}")
    print("结果列:", list(result2.columns))
    assert 'id' not in result2.columns
    assert 'join_date' not in result2.columns


def test_data_edit(engine, df):
    """测试数据编辑功能"""
    # 测试表达式列
    result = engine.data_edit(df, {
        'selectedOperation': 'expression',
        'selectedColumns': ['id', 'name', 'age', 'salary'],
        'expressionColumns': [
            {
                'name': 'adjusted_salary',
                'expression': '[salary] * 1.1'  # 涨薪10%
            },
            {
                'name': 'experience_level',
                'expression': "np.where([age] < 30, 'Junior', 'Senior')"
            }
        ]
    })

    print(f"数据编辑后形状: {result.shape}")
    print("新列:", [col for col in result.columns if col not in df.columns])
    print("编辑后数据样例:")
    print(result[['id', 'salary', 'adjusted_salary', 'experience_level']].head())


def test_fill_missing(engine):
    """测试缺失值填充功能"""
    # 创建有缺失值的数据
    missing_df = pd.DataFrame({
        'A': [1, 2, None, 4, 5, None, 7],
        'B': [10, None, None, 40, 50, 60, 70],
        'C': [100, 200, 300, None, 500, 600, None],
        'D': ['X', 'Y', None, 'Z', 'W', None, 'V']
    })

    print("原始数据 (含缺失值):")
    print(missing_df)
    print("\n缺失值统计:")
    print(missing_df.isnull().sum())

    # 测试多种填充方式
    result = engine.fill_missing(missing_df, {
        'fillConfigs': [
            {'column': 'A', 'method': 'mean'},
            {'column': 'B', 'method': 'median'},
            {'column': 'C', 'method': 'forward'},
            {'column': 'D', 'method': 'value', 'value': 'Unknown'}
        ]
    })

    print("\n填充后数据:")
    print(result)
    print("\n填充后缺失值统计:")
    print(result.isnull().sum())


def test_validate_data(engine, df):
    """测试数据验证功能"""
    # 创建有质量问题的数据
    quality_df = df.copy()
    quality_df.loc[10:15, 'age'] = None  # 添加缺失值
    quality_df.loc[20:25, 'salary'] = None  # 添加缺失值
    quality_df = pd.concat([quality_df, quality_df.head(5)], ignore_index=True)  # 添加重复行

    validation_result = engine.validate_data(quality_df)

    print("数据验证结果:")
    for key, value in validation_result.items():
        print(f"  {key}: {value}")


def test_complex_scenario(engine):
    """测试复杂场景集成"""
    print("执行复杂场景集成测试...")

    # 创建复杂测试数据
    complex_df = pd.DataFrame({
        'transaction_id': range(1, 1001),
        'customer_id': np.random.choice(['C001', 'C002', 'C003', 'C004', 'C005'], 1000),
        'product_id': np.random.choice(['P1', 'P2', 'P3', 'P4', 'P5', 'P6'], 1000),
        'amount': np.random.uniform(10, 2000, 1000).round(2),
        'quantity': np.random.randint(1, 20, 1000),
        'region': np.random.choice(['North', 'South', 'East', 'West'], 1000),
        'date': pd.date_range('2023-01-01', periods=1000, freq='H'),
        'category': np.random.choice(['Electronics', 'Clothing', 'Food', 'Books'], 1000)
    })

    # 添加一些缺失值和异常值
    complex_df.loc[100:150, 'amount'] = None
    complex_df.loc[200:250, 'quantity'] = None
    complex_df.loc[300:310, 'amount'] = 999999  # 异常值

    original_shape = complex_df.shape
    print(f"原始数据形状: {original_shape}")

    # 执行复杂的数据处理流水线
    result = complex_df.copy()

    # 1. 重命名
    result = engine.rename(result, {
        'renameMapping': {
            'transaction_id': 'txn_id',
            'customer_id': 'cust_id',
            'product_id': 'prod_id'
        }
    })

    # 2. 筛选有效数据
    result = engine.filter(result, {
        'conditions': [
            {'column': 'amount', 'operator': 'is_not_null', 'value': None},
            {'column': 'amount', 'operator': 'less_than', 'value': 100000}  # 排除异常值
        ]
    })

    # 3. 特征衍生
    result = engine.feature_derive(result, {
        'newFeatures': [
            {'name': 'unit_price', 'expression': '[amount] / [quantity]'},
            {'name': 'is_high_value', 'expression': 'np.where([amount] > 1000, "High", "Normal")'},
            {'name': 'sales_region', 'expression': "[region] + '_' + [category]"}
        ]
    })

    # 4. 缺失值填充
    result = engine.fill_missing(result, {
        'fillConfigs': [
            {'column': 'quantity', 'method': 'median'}
        ]
    })

    # 5. 排序
    result = engine.sort(result, {
        'sortBy': [
            {'column': 'date', 'order': 'desc'},
            {'column': 'amount', 'order': 'desc'}
        ]
    })

    # 6. 采样
    result = engine.sample(result, {
        'sampleType': 'partial',
        'sampleMethod': 'downsample',
        'sampleSize': 200
    })

    final_shape = result.shape
    print(f"最终数据形状: {final_shape}")
    print(f"处理流水线完成: {original_shape} -> {final_shape}")

    # 验证结果
    validation = engine.validate_data(result)
    print(f"最终数据质量分数: {validation['quality_score']}")

    # 显示样例数据
    sample_data = engine.get_sample_data(result, 3)
    print("\n最终数据样例:")
    for i, row in enumerate(sample_data):
        print(f"  样例{i + 1}: {row}")


if __name__ == "__main__":
    # 设置日志级别为WARNING，减少输出噪音
    logging.basicConfig(level=logging.WARNING, format='%(asctime)s - %(levelname)s - %(message)s')

    comprehensive_test_table_data_engine()