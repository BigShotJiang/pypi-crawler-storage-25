"""Build the search index for the frontend full-text search (MiniSearch)."""

from __future__ import annotations

from typing import Any


def build_search_index(
    models: dict[str, Any],
    sources: dict[str, Any],
    seeds: dict[str, Any],
    snapshots: dict[str, Any],
) -> list[dict[str, Any]]:
    """Build the search index for MiniSearch.

    Each entry has a unique ``id`` field required by MiniSearch. Emits two
    kinds of entries:
    - **resource entries** (model / source / seed / snapshot) — one per resource,
      searchable by name, description, and tags.
    - **column entries** — one per column per resource, enabling users to search
      for a column name and jump directly to the model + column.
    """
    entries: list[dict[str, Any]] = []

    for collection, resource_type in [
        (models, "model"),
        (sources, "source"),
        (seeds, "seed"),
        (snapshots, "snapshot"),
    ]:
        for uid, data in collection.items():
            columns = data.get("columns", [])
            model_name = data.get("name", "")

            # Resource-level entry
            entries.append(
                {
                    "id": uid,
                    "unique_id": uid,
                    "name": model_name,
                    "resource_type": resource_type,
                    "description": data.get("description", ""),
                    "tags": ", ".join(data.get("tags", [])),
                }
            )

            # Column-level entries — one per column
            for col in columns:
                col_name: str = col.get("name", "")
                if not col_name:
                    continue
                entries.append(
                    {
                        "id": f"{uid}::{col_name}",
                        "unique_id": uid,
                        "name": col_name,
                        "resource_type": "column",
                        "column_name": col_name,
                        "model_name": model_name,
                        "description": col.get("description", ""),
                    }
                )

    return entries
