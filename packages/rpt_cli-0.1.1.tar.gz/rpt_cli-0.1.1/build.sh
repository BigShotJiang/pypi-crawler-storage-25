#!/usr/bin/env bash
#
# Stage the lean CLI modules from the monorepo into packaging/rpt-cli/src/
# and build the sdist + wheel.
#
# Why a script: hatchling (and setuptools with native builders) don't
# allow relative paths that climb above the package root, so we can't
# point the build directly at ../../src/rsc_hub/cli/*. Copying is
# cheap, reproducible, and keeps the monorepo as the single source of
# truth — src/ in this folder is a build artefact, not something to
# hand-edit.

set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd "$here/../.." && pwd)"
staged="$here/src/rsc_hub"

# Only the remote-first CLI modules end up in the lean package. The
# server-admin subtree (cmd_admin*) is intentionally excluded — it
# reaches into the DB via SQLAlchemy and needs the server package.
lean_files=(
    "__init__.py"
    "cli/__init__.py"
    "cli/main.py"
    "cli/client.py"
    "cli/formatters.py"
    "cli/cmd_configure.py"
    "cli/cmd_feed.py"
    "cli/cmd_note.py"
    "cli/cmd_providers.py"
    "cli/cmd_search.py"
    "cli/cmd_watchlist.py"
)

# Clean staging area — everything here is derived from the monorepo.
rm -rf "$staged"
mkdir -p "$staged/cli"

for rel in "${lean_files[@]}"; do
    src="$repo_root/src/rsc_hub/$rel"
    dst="$staged/$rel"
    mkdir -p "$(dirname "$dst")"
    cp "$src" "$dst"
done

# The whole provider/ subtree (REST-only admin commands) comes across.
cp -R "$repo_root/src/rsc_hub/cli/provider" "$staged/cli/provider"

# Clean any build artefacts before building.
rm -rf "$here/dist" "$here/build"

# Build sdist + wheel using the active Python's build frontend.
cd "$here"
python -m build

echo
echo "Built wheels in $here/dist/:"
ls -1 "$here/dist/"
