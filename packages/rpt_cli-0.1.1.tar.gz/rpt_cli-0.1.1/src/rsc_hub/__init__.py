"""RSC Research Hub - Standardised API gateway for investment research."""

__version__ = "0.1.0"
