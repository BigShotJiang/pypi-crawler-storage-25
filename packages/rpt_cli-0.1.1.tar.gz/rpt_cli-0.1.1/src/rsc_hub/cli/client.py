"""HTTP client for the RPT Hub API.

Thin wrapper around httpx that handles base URL, API key auth,
and error formatting. All CLI commands use this client rather
than making HTTP calls directly.
"""

import sys
from pathlib import Path
from typing import Any, NoReturn

import httpx

# Config file location
CONFIG_DIR = Path.home() / ".rpt"
CONFIG_FILE = CONFIG_DIR / "config"

# Defaults
DEFAULT_BASE_URL = "http://localhost:8000"


def _load_config() -> dict[str, str]:
    """Load key=value config from ~/.rpt/config.

    Returns:
        Dict of configuration values.
    """
    config: dict[str, str] = {}
    if CONFIG_FILE.exists():
        for line in CONFIG_FILE.read_text().strip().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                config[key.strip()] = value.strip()
    return config


def get_base_url() -> str:
    """Get the API base URL from config or default.

    Returns:
        The hub API base URL.
    """
    config = _load_config()
    return config.get("base_url", DEFAULT_BASE_URL)


def get_api_key() -> str | None:
    """Get the API key from config.

    Returns:
        The API key string, or None if not configured.
    """
    config = _load_config()
    return config.get("api_key")


def make_request(
    method: str,
    path: str,
    *,
    params: dict[str, Any] | None = None,
    json_body: dict[str, Any] | None = None,
    require_auth: bool = False,
) -> dict[str, Any]:
    """Make an HTTP request to the RSC Hub API.

    Args:
        method: HTTP method (GET, POST, etc.).
        path: API path (e.g. /api/v1/search).
        params: Query parameters.
        json_body: JSON request body.
        require_auth: If True, exit with error when no API key configured.

    Returns:
        The parsed JSON response.
    """
    base_url = get_base_url()
    api_key = get_api_key()

    if require_auth and not api_key:
        _error("No API key configured. Run: rsc configure --api-key YOUR_KEY")

    headers: dict[str, str] = {}
    if api_key:
        headers["X-API-Key"] = api_key

    try:
        response = httpx.request(
            method,
            f"{base_url}{path}",
            params=params,
            json=json_body,
            headers=headers,
            timeout=30.0,
        )
    except httpx.ConnectError:
        _error(f"Cannot connect to {base_url}. Is the hub running?")

    if response.status_code >= 400:
        detail = response.json().get("detail", response.text)
        _error(f"API error ({response.status_code}): {detail}")

    result: dict[str, Any] = response.json()
    return result


def _error(message: str) -> NoReturn:
    """Print an error message and exit.

    Args:
        message: The error message to display.
    """
    print(f"Error: {message}", file=sys.stderr)
    sys.exit(1)
