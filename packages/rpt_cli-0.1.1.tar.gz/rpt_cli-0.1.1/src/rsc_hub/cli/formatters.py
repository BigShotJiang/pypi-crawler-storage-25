"""Output formatters for CLI results.

Handles rich terminal output for search results, stock intelligence,
provider listings, and note details. Keeps display logic out of
the command handlers.
"""

from datetime import datetime
from typing import Any


def format_search_results(data: dict[str, Any]) -> str:
    """Format search response for terminal display.

    Args:
        data: Parsed JSON from the search endpoint.

    Returns:
        Formatted string for terminal output.
    """
    total = data.get("total", 0)
    query = data.get("query", "")
    results = data.get("results", [])

    lines = [f'\n  Search: "{query}" — {total} result(s)\n']

    for i, note in enumerate(results, 1):
        rating = (note.get("rating") or "—").upper()
        target = note.get("price_target")
        ccy = note.get("price_currency", "")
        target_str = f" | {ccy}{target}" if target else ""
        provider = note.get("provider_name", "Unknown")
        published = _format_date(note.get("published_at", ""))
        sectors = ", ".join(note.get("sectors", []))

        lines.append(f"  {i}. {note['title']}")
        lines.append(f"     {provider} | {rating}{target_str} | {published}")
        if sectors:
            lines.append(f"     Sectors: {sectors}")

        companies = note.get("companies", [])
        tickers = [f"{c['ticker']}.{c['exchange']}" for c in companies if c.get("ticker")]
        if tickers:
            lines.append(f"     Tickers: {', '.join(tickers)}")

        lines.append(f"     ID: {note['id']}")
        lines.append("")

    return "\n".join(lines)


def format_note_detail(data: dict[str, Any]) -> str:
    """Format a single note for detailed terminal display.

    Args:
        data: Parsed JSON note object.

    Returns:
        Formatted string for terminal output.
    """
    lines = [
        f"\n  {data.get('title', 'Untitled')}",
        f"  {'=' * min(len(data.get('title', '')), 70)}",
        f"  Provider:  {data.get('provider_name', 'Unknown')}",
        f"  Authors:   {', '.join(data.get('authors', []))}",
        f"  Published: {_format_date(data.get('published_at', ''))}",
        f"  Type:      {data.get('note_type', '—')}",
    ]

    rating = data.get("rating")
    if rating:
        target = data.get("price_target")
        ccy = data.get("price_currency", "")
        target_str = f" | Target: {ccy}{target}" if target else ""
        lines.append(f"  Rating:    {rating.upper()}{target_str}")

    fmt = data.get("content_format", "pdf").upper()
    lines.append(f"  Format:   {fmt}")

    abstract = data.get("abstract")
    if abstract:
        lines.append(f"\n  {abstract}")

    # Content redirect URL (if entitlement check passed)
    redirect = data.get("content_redirect")
    if redirect:
        url = redirect.get("redirect_url") or redirect.get("url")
        mode = redirect.get("content_mode", "redirect")
        if url:
            lines.append(f"\n  Content ({mode}): {url}")

    lines.append(f"\n  ID: {data.get('id', '—')}")
    lines.append("")
    return "\n".join(lines)


def format_providers(data: dict[str, Any]) -> str:
    """Format provider listing for terminal display.

    Args:
        data: Parsed JSON from the providers endpoint.

    Returns:
        Formatted string for terminal output.
    """
    providers = data.get("providers", [])
    total = data.get("total", 0)

    lines = [f"\n  Connected Providers ({total})\n"]

    for p in providers:
        status = "✓" if p.get("health_status") == "healthy" else "?"
        mode = p.get("metadata_mode", "push")
        count = p.get("note_count", 0)
        latest = _format_date(p.get("latest_note", "")) if p.get("latest_note") else "—"

        lines.append(f"  {status} {p['display_name']}")
        lines.append(f"    Notes: {count} | Mode: {mode} | Latest: {latest}")
        lines.append(f"    ID: {p['id']}")
        lines.append("")

    return "\n".join(lines)


def _format_date(iso_str: str) -> str:
    """Format an ISO date string for display.

    Args:
        iso_str: ISO 8601 datetime string.

    Returns:
        Human-readable date string, or '—' if unparseable.
    """
    if not iso_str:
        return "—"
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
        return dt.strftime("%d %b %Y")
    except (ValueError, AttributeError):
        return iso_str[:10] if len(iso_str) >= 10 else "—"
