"""CLI command: rsc providers — list connected research providers."""

import typer

from rsc_hub.cli.client import make_request
from rsc_hub.cli.formatters import format_providers


def providers(
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """List all connected sell-side research providers.

    Shows provider name, health status, note count, and metadata mode.

    Examples:
        rsc providers
        rsc providers --json
    """
    data = make_request("GET", "/api/v1/providers")

    if json_output:
        import json

        print(json.dumps(data, indent=2))
    else:
        print(format_providers(data))
