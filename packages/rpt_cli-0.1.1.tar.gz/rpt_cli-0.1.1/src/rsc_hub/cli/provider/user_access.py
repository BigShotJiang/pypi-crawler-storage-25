"""CLI: rpt provider user-access — allow / deny / reset / list.

Operates on a user-scoped entitlement (see
`rpt provider entitlements user-scope`). Users are identified by
email; the CLI resolves them via the backend user-access list, which
returns every user the provider may assign (users who've interacted
plus anyone already on the list).
"""

import csv
from pathlib import Path
from typing import Any

import typer

from rsc_hub.cli.provider._common import _error, emit, parse_emails, request, require_api_key_present

app = typer.Typer(help="Manage per-user access on user-scoped entitlements.", no_args_is_help=True)


def _resolve_user_ids(entitlement_id: str, emails: list[str]) -> list[str]:
    """Look up user UUIDs by email via the existing list endpoint."""
    data = request("GET", f"/api/v1/providers/me/entitlements/{entitlement_id}/user-access")
    lookup = {e["email"].lower(): e["user_id"] for e in data.get("entries", [])}
    missing = [em for em in emails if em not in lookup]
    if missing:
        _error(
            "Could not find these users on this entitlement:\n  "
            + "\n  ".join(missing)
            + "\nUsers appear only once they've interacted with your research, "
            "or after you've assigned them previously."
        )
    return [lookup[em] for em in emails]


def _bulk(entitlement_id: str, emails: list[str], state: str, as_json: bool) -> None:
    """Shared bulk setter for allow / deny / reset."""
    require_api_key_present()
    normalised = parse_emails(emails)
    if not normalised:
        _error("No valid emails supplied.")
    user_ids = _resolve_user_ids(entitlement_id, normalised)
    body = {"user_ids": user_ids, "state": state}
    data = request(
        "POST",
        f"/api/v1/providers/me/entitlements/{entitlement_id}/user-access/bulk",
        json_body=body,
    )

    def _table(payload: dict[str, Any]) -> None:
        labels = {"allow": "Allowed", "deny": "Disallowed", "not_set": "Reset"}
        print(f"{labels.get(state, state)} {payload.get('affected', 0)} user(s) on {entitlement_id}.")

    emit(data, as_json, _table)


@app.command("list")
def list_access(
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Show every visible user with their allow / deny / not-set state."""
    require_api_key_present()
    data = request("GET", f"/api/v1/providers/me/entitlements/{entitlement_id}/user-access")

    def _table(payload: dict[str, Any]) -> None:
        entries = payload.get("entries", [])
        scope = "user-scoped" if payload.get("user_scoping") else "org-wide"
        print(f"Entitlement {entitlement_id}  ({scope})")
        if not entries:
            print("No users visible yet — they appear here once they interact with your research.")
            return
        counts = {"allow": 0, "deny": 0, "not_set": 0}
        for e in entries:
            counts[e["state"]] = counts.get(e["state"], 0) + 1
        print(f"Allow: {counts['allow']}   Disallow: {counts['deny']}   Not set: {counts['not_set']}")
        print()
        print(f"{'User':<32} {'Email':<32} {'State':<10} {'Set by':<20}")
        print("-" * 95)
        for e in entries:
            print(
                f"{(e.get('display_name') or '—')[:32]:<32} "
                f"{e['email'][:32]:<32} "
                f"{e['state']:<10} "
                f"{(e.get('granted_by_display_name') or '—')[:20]:<20}"
            )

    emit(data, as_json, _table)


@app.command("allow")
def allow_users(
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID"),
    emails: list[str] = typer.Argument(..., help="One or more user emails"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Grant allow-state to one or more users on a user-scoped entitlement."""
    _bulk(entitlement_id, emails, "allow", as_json)


@app.command("deny")
def deny_users(
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID"),
    emails: list[str] = typer.Argument(..., help="One or more user emails"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Deny one or more users access on a user-scoped entitlement."""
    _bulk(entitlement_id, emails, "deny", as_json)


@app.command("reset")
def reset_users(
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID"),
    emails: list[str] = typer.Argument(..., help="One or more user emails"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Remove explicit allow / deny rows (users revert to 'Not set')."""
    _bulk(entitlement_id, emails, "not_set", as_json)


@app.command("from-csv")
def from_csv(
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID"),
    path: Path = typer.Argument(..., exists=True, help="CSV with columns: email,state"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Bulk apply states from a CSV. Columns: email, state (allow/deny/not_set)."""
    require_api_key_present()
    grouped: dict[str, list[str]] = {"allow": [], "deny": [], "not_set": []}
    with path.open() as fh:
        reader = csv.DictReader(fh)
        if not reader.fieldnames or "email" not in reader.fieldnames or "state" not in reader.fieldnames:
            _error("CSV must have 'email' and 'state' columns.")
        for row in reader:
            state = (row.get("state") or "").strip().lower()
            email = (row.get("email") or "").strip().lower()
            if state not in grouped or not email:
                continue
            grouped[state].append(email)

    summary: dict[str, int] = {}
    for state, emails in grouped.items():
        if not emails:
            continue
        user_ids = _resolve_user_ids(entitlement_id, parse_emails(emails))
        body = {"user_ids": user_ids, "state": state}
        data = request(
            "POST",
            f"/api/v1/providers/me/entitlements/{entitlement_id}/user-access/bulk",
            json_body=body,
        )
        summary[state] = data.get("affected", 0)

    def _table(_payload: dict[str, Any]) -> None:
        if not summary:
            print("Nothing applied — CSV had no recognised rows.")
            return
        for state, count in summary.items():
            print(f"{state}: {count}")

    emit(summary, as_json, _table)
