"""CLI: rpt provider rate-limits — per-client rate limit CRUD."""

from typing import Any

import typer

from rsc_hub.cli.provider._common import emit, request, require_api_key_present

app = typer.Typer(help="Per-client rate limit rules.", no_args_is_help=True)


@app.command("list")
def list_rate_limits(
    client: str | None = typer.Option(None, "--client", help="Filter to a buy-side org UUID"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Show every rate-limit rule on your provider."""
    require_api_key_present()
    data = request("GET", "/api/v1/providers/me/rate-limits")
    rules = data.get("rules", [])
    if client:
        rules = [r for r in rules if r.get("buy_side_org_id") == client]

    def _table(_payload: dict[str, Any]) -> None:
        if not rules:
            print("No rate-limit rules configured.")
            return
        print(f"{'ID':<38} {'Client':<24} {'Daily':>8} {'Monthly':>10} {'Scope':<10}")
        print("-" * 92)
        for r in rules:
            scope = "user" if r.get("user_id") else "org"
            print(
                f"{r['id']:<38} "
                f"{(r.get('org_name') or (r.get('buy_side_org_id') or '')[:8])[:24]:<24} "
                f"{r.get('daily_limit') or '—':>8} "
                f"{r.get('monthly_limit') or '—':>10} "
                f"{scope:<10}"
            )

    emit({"rules": rules, "total": len(rules)}, as_json, _table)


@app.command("set")
def set_rate_limit(
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID to attach the limit to"),
    daily: int | None = typer.Option(None, "--daily", help="Requests per day"),
    monthly: int | None = typer.Option(None, "--monthly", help="Requests per month"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Create or update a per-entitlement rate-limit rule."""
    require_api_key_present()
    body: dict[str, Any] = {"entitlement_id": entitlement_id}
    if daily is not None:
        body["daily_limit"] = daily
    if monthly is not None:
        body["monthly_limit"] = monthly
    data = request("POST", "/api/v1/providers/me/rate-limits", json_body=body)

    def _table(payload: dict[str, Any]) -> None:
        print(
            f"Rate limit set on {entitlement_id}: "
            f"daily={payload.get('daily_limit') or '—'}, "
            f"monthly={payload.get('monthly_limit') or '—'}."
        )

    emit(data, as_json, _table)


@app.command("status")
def rate_limit_status(
    provider_id: str = typer.Argument(..., help="Provider UUID (your own)"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Show current consumption against the configured limits."""
    require_api_key_present()
    data = request("GET", f"/api/v1/rate-limits/status/{provider_id}")

    def _table(payload: dict[str, Any]) -> None:
        print(
            f"Daily: {payload.get('daily_count', 0)} / {payload.get('daily_limit') or '∞'}\n"
            f"Monthly: {payload.get('monthly_count', 0)} / {payload.get('monthly_limit') or '∞'}"
        )

    emit(data, as_json, _table)
