"""CLI: rpt provider templates — list, apply, detach, sync."""

from typing import Any

import typer

from rsc_hub.cli.provider._common import emit, request, require_api_key_present

app = typer.Typer(help="Manage reusable access templates.", no_args_is_help=True)


@app.command("list")
def list_templates(as_json: bool = typer.Option(False, "--json")) -> None:
    """Show every template on your provider."""
    require_api_key_present()
    data = request("GET", "/api/v1/providers/me/templates")

    def _table(payload: dict[str, Any]) -> None:
        tmpls = payload.get("templates", [])
        if not tmpls:
            print("No templates yet.")
            return
        print(f"{'ID':<38} {'Name':<30} {'Version':<8} {'Description':<30}")
        print("-" * 115)
        for t in tmpls:
            print(
                f"{t['id']:<38} "
                f"{(t.get('name') or '—')[:30]:<30} "
                f"v{t.get('version', 1):<7} "
                f"{(t.get('description') or '—')[:30]:<30}"
            )

    emit(data, as_json, _table)


@app.command("apply")
def apply_template(
    template_id: str = typer.Argument(..., help="Template UUID"),
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID to apply the template to"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Apply a template to an entitlement (replaces existing rules)."""
    require_api_key_present()
    body = {"template_id": template_id}
    data = request(
        "POST",
        f"/api/v1/providers/me/entitlements/{entitlement_id}/apply-template",
        json_body=body,
    )

    def _table(payload: dict[str, Any]) -> None:
        print(
            f"Applied template {template_id} to entitlement {entitlement_id} — "
            f"{payload.get('rules_applied', 0)} rule(s) copied "
            f"(template version {payload.get('template_version', '?')})."
        )

    emit(data, as_json, _table)


@app.command("detach")
def detach_template(
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Detach whatever template is applied (rules stay as manual edits)."""
    require_api_key_present()
    data = request("POST", f"/api/v1/providers/me/entitlements/{entitlement_id}/detach-template")

    def _table(_payload: dict[str, Any]) -> None:
        print(f"Detached template from entitlement {entitlement_id}.")

    emit(data, as_json, _table)


@app.command("sync")
def sync_template(
    template_id: str = typer.Argument(..., help="Template UUID"),
    force: bool = typer.Option(False, "--force", help="Re-apply even to entitlements on a newer version"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Re-apply a template's current rules to every linked entitlement."""
    require_api_key_present()
    data = request(
        "POST",
        f"/api/v1/providers/me/templates/{template_id}/sync?force={'true' if force else 'false'}",
    )

    def _table(payload: dict[str, Any]) -> None:
        print(
            f"Synced template {template_id}: "
            f"{payload.get('synced', 0)} entitlement(s) updated, "
            f"{payload.get('skipped', 0)} skipped "
            f"(template v{payload.get('template_version', '?')})."
        )

    emit(data, as_json, _table)
