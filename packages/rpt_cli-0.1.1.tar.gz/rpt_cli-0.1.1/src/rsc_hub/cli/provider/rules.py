"""CLI: rpt provider rules — direct per-entitlement rule CRUD."""

from typing import Any

import typer

from rsc_hub.cli.provider._common import _error, emit, request, require_api_key_present

app = typer.Typer(help="Per-entitlement access rules (templates are usually preferable).", no_args_is_help=True)


@app.command("list")
def list_rules(
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Show every rule on a single entitlement."""
    require_api_key_present()
    data = request("GET", f"/api/v1/providers/me/entitlements/{entitlement_id}/rules")

    def _table(payload: dict[str, Any]) -> None:
        rules = payload.get("rules", [])
        if not rules:
            print("No rules. Client has full access to your content.")
            return
        print(f"{'ID':<38} {'Type':<16} {'Config':<50}")
        print("-" * 105)
        for r in rules:
            cfg_str = ", ".join(f"{k}={v}" for k, v in (r.get("config") or {}).items())[:50]
            print(f"{r['id']:<38} {r['rule_type']:<16} {cfg_str:<50}")

    emit(data, as_json, _table)


@app.command("add")
def add_rule(
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID"),
    rule_type: str = typer.Option(
        ..., "--type", help="analyst | sector | company | region | research_type | embargo | field_access | note"
    ),
    values: str | None = typer.Option(
        None, "--values", help="Comma-separated values for set-type rules (e.g. 'Defence,Tech')"
    ),
    hours: int | None = typer.Option(None, "--hours", help="Embargo hours (for --type embargo)"),
    days: int | None = typer.Option(None, "--days", help="Embargo days (for --type embargo)"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Add a single rule to an entitlement. Prefer templates for bulk."""
    require_api_key_present()
    config: dict[str, Any] = {}
    if rule_type == "embargo":
        if hours is not None:
            config["hours"] = hours
        if days is not None:
            config["days"] = days
        if not config:
            _error("Embargo rule needs --hours or --days.")
    else:
        if not values:
            _error(f"--values is required for rule type '{rule_type}'.")
        # Map rule_type → the config key the backend expects.
        key_map = {
            "analyst": "analysts",
            "sector": "sectors",
            "company": "tickers",
            "region": "regions",
            "research_type": "types",
            "field_access": "fields",
            "note": "note_ids",
            "analyst_team": "teams",
        }
        key = key_map.get(rule_type, "values")
        config[key] = [v.strip() for v in values.split(",") if v.strip()]

    body = {"entitlement_id": entitlement_id, "rule_type": rule_type, "config": config}
    data = request(
        "POST",
        f"/api/v1/providers/me/entitlements/{entitlement_id}/rules",
        json_body=body,
    )

    def _table(payload: dict[str, Any]) -> None:
        print(f"Added {rule_type} rule {payload.get('id')} to {entitlement_id}.")

    emit(data, as_json, _table)


@app.command("remove")
def remove_rule(
    rule_id: str = typer.Argument(..., help="Rule UUID"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Delete a single rule by ID."""
    require_api_key_present()
    data = request("DELETE", f"/api/v1/providers/me/rules/{rule_id}")

    def _table(_payload: dict[str, Any]) -> None:
        print(f"Removed rule {rule_id}.")

    emit(data, as_json, _table)
