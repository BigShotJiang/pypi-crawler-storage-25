"""CLI: rpt provider entitlements — list, grant, revoke, scope-mode."""

from typing import Any

import typer

from rsc_hub.cli.provider._common import emit, request, require_api_key_present

app = typer.Typer(help="Manage client entitlements with your provider.", no_args_is_help=True)


@app.command("list")
def list_entitlements(
    client: str | None = typer.Option(None, "--client", help="Filter to a buy-side org UUID"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """List every entitlement on your provider record."""
    require_api_key_present()
    data = request("GET", "/api/v1/providers/me/entitlements")
    ents = data.get("entitlements", [])
    if client:
        ents = [e for e in ents if e.get("buy_side_org_id") == client]

    def _table(_payload: dict[str, Any]) -> None:
        if not ents:
            print("No entitlements match.")
            return
        print(f"{'ID':<38} {'Client':<24} {'Access':<10} {'Template':<18} {'Scope':<12}")
        print("-" * 105)
        for e in ents:
            scope = "user-scoped" if e.get("user_scoping") else "org-wide"
            print(
                f"{e['id']:<38} "
                f"{(e.get('org_name') or e['buy_side_org_id'][:8])[:24]:<24} "
                f"{e.get('access_type', '—'):<10} "
                f"{(e.get('template_name') or '—')[:18]:<18} "
                f"{scope:<12}"
            )

    emit({"entitlements": ents, "total": len(ents)}, as_json, _table)


@app.command("grant")
def grant_entitlement(
    client_org_id: str = typer.Argument(..., help="Buy-side organisation UUID"),
    access_type: str = typer.Option("retainer", "--access-type", help="retainer | trial | occasional"),
    expires: str | None = typer.Option(None, "--expires", help="YYYY-MM-DD expiry, omit for perpetual"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Grant this client access to your content."""
    require_api_key_present()
    body: dict[str, Any] = {"buy_side_org_id": client_org_id, "access_type": access_type}
    if expires:
        body["expires_at"] = f"{expires}T23:59:59Z"
    data = request("POST", "/api/v1/providers/me/entitlements/grant", json_body=body)

    def _table(payload: dict[str, Any]) -> None:
        print(f"Granted {access_type} access: entitlement {payload.get('id')}")

    emit(data, as_json, _table)


@app.command("revoke")
def revoke_entitlement(
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID to revoke"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Block an entitlement (access_type → 'blocked')."""
    require_api_key_present()
    data = request("POST", f"/api/v1/providers/me/entitlements/{entitlement_id}/revoke")

    def _table(_payload: dict[str, Any]) -> None:
        print(f"Revoked entitlement {entitlement_id}.")

    emit(data, as_json, _table)


@app.command("user-scope")
def set_user_scope(
    entitlement_id: str = typer.Argument(..., help="Entitlement UUID"),
    on: bool = typer.Option(False, "--on", help="Turn user_scoping ON (allow-list semantics)"),
    off: bool = typer.Option(False, "--off", help="Turn user_scoping OFF (org-wide)"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Flip per-user allow-list gating on an entitlement."""
    require_api_key_present()
    if on == off:
        from rsc_hub.cli.provider._common import _error

        _error("Pick exactly one of --on or --off.")
    body = {"user_scoping": bool(on)}
    data = request("PATCH", f"/api/v1/providers/me/entitlements/{entitlement_id}/scope-mode", json_body=body)

    def _table(payload: dict[str, Any]) -> None:
        state = "user-scoped" if payload.get("user_scoping") else "org-wide"
        print(f"Entitlement {entitlement_id} is now {state}.")

    emit(data, as_json, _table)
