"""CLI: rpt provider clients — list and inspect client orgs."""

from typing import Any

import typer

from rsc_hub.cli.provider._common import emit, request, require_api_key_present

app = typer.Typer(help="Inspect your client organisations.", no_args_is_help=True)


@app.command("list")
def list_clients(as_json: bool = typer.Option(False, "--json", help="Output raw JSON")) -> None:
    """Show every client org with access type, health, and MTD downloads."""
    require_api_key_present()
    data = request("GET", "/api/v1/providers/me/analytics/clients")

    def _table(payload: dict[str, Any]) -> None:
        rows = payload.get("clients", [])
        if not rows:
            print("No clients yet.")
            return
        print(f"{'Client':<30} {'Access':<12} {'Health':<10} {'MTD DL':>7} {'Last Access':<12}")
        print("-" * 75)
        for r in rows:
            last = (r.get("last_access") or "")[:10] or "—"
            print(
                f"{(r.get('org_name') or r['org_id'][:8])[:30]:<30} "
                f"{r.get('access_type', '—'):<12} "
                f"{r.get('health', '—'):<10} "
                f"{r.get('downloads_this_month', 0):>7} "
                f"{last:<12}"
            )

    emit(data, as_json, _table)


@app.command("show")
def show_client(
    client_org_id: str = typer.Argument(..., help="Buy-side organisation UUID"),
    as_json: bool = typer.Option(False, "--json"),
) -> None:
    """Show a single client's entitlements with this provider."""
    require_api_key_present()
    data = request("GET", "/api/v1/providers/me/entitlements")
    matching = [e for e in data.get("entitlements", []) if e.get("buy_side_org_id") == client_org_id]
    out = {"client_org_id": client_org_id, "entitlements": matching, "total": len(matching)}

    def _table(payload: dict[str, Any]) -> None:
        ents = payload.get("entitlements", [])
        if not ents:
            print(f"No entitlements for client {client_org_id}.")
            return
        print(f"Client: {ents[0].get('org_name') or client_org_id}")
        print(f"{'Entitlement ID':<38} {'Access':<12} {'Template':<20} {'Scope':<12}")
        print("-" * 85)
        for e in ents:
            scope = "user-scoped" if e.get("user_scoping") else "org-wide"
            print(
                f"{e['id']:<38} {e.get('access_type', '—'):<12} {(e.get('template_name') or '—')[:20]:<20} {scope:<12}"
            )

    emit(out, as_json, _table)
