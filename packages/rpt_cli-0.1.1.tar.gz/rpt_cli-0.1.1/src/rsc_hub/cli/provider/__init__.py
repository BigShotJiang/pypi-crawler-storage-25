"""Provider-admin CLI subcommand tree.

Wraps the /providers/me/* REST endpoints so a sell-side admin can
manage clients, entitlements, user-access, templates, rules, and
rate limits from the terminal. Auth via the configured API key
(must have admin scope).

Command groups are registered here and picked up by cli.main as
`rpt provider ...`.
"""

import typer

from rsc_hub.cli.provider import clients, entitlements, rate_limits, rules, templates, user_access

provider_app = typer.Typer(
    name="provider",
    help="Provider-admin commands: clients, entitlements, templates, rules, rate limits.",
    no_args_is_help=True,
)

provider_app.add_typer(clients.app, name="clients")
provider_app.add_typer(entitlements.app, name="entitlements")
provider_app.add_typer(user_access.app, name="user-access")
provider_app.add_typer(templates.app, name="templates")
provider_app.add_typer(rules.app, name="rules")
provider_app.add_typer(rate_limits.app, name="rate-limits")
