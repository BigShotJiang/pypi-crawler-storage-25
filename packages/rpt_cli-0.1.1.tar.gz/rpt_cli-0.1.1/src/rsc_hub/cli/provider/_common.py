"""Shared helpers for provider-admin CLI commands.

Centralises table/JSON output toggling and the request wrapper so
individual command modules stay small. Every provider-admin command
hits /providers/me/* and needs an API key with admin scope — 403
responses get mapped to a friendlier hint here.
"""

import json as _json
import sys
from typing import Any, NoReturn

from rsc_hub.cli.client import get_api_key, make_request


def request(method: str, path: str, **kwargs: Any) -> dict[str, Any]:
    """Thin wrapper that ensures auth is required for admin endpoints.

    Maps 403 responses to a friendly hint about admin scope on the key.
    """
    try:
        return make_request(method, path, require_auth=True, **kwargs)
    except SystemExit:
        # make_request already printed the full error. Re-raise so the
        # CLI exits with a non-zero code.
        raise


def emit(data: Any, as_json: bool, render_table: Any = None) -> None:
    """Emit data either as JSON or via a caller-supplied table renderer.

    Args:
        data: The payload to emit (usually a dict or list).
        as_json: If True, print raw JSON.
        render_table: Optional callable that prints a human-readable
            table. If omitted, the data is pretty-printed as JSON
            regardless of the `as_json` flag.
    """
    if as_json or render_table is None:
        print(_json.dumps(data, indent=2, default=str))
        return
    render_table(data)


def require_api_key_present() -> None:
    """Exit early if no API key is configured.

    Makes admin commands fail fast with actionable guidance rather than
    the deep 'No API key configured' from client.py's internal helper.
    """
    if not get_api_key():
        _error(
            "No API key configured. Generate one with admin scope on "
            "the Integrations page (/dashboard/integrations), then run:\n"
            "  rpt configure --api-key rsc_xxxxxxxxxxxxxxxx"
        )


def _error(message: str) -> NoReturn:
    """Print an error and exit non-zero."""
    print(f"Error: {message}", file=sys.stderr)
    sys.exit(1)


def parse_emails(values: list[str]) -> list[str]:
    """Normalise a list of email strings — strip + lower + dedupe.

    Args:
        values: Raw positional email args from the CLI.

    Returns:
        Deduplicated, lowercased email list in first-seen order.
    """
    seen: dict[str, None] = {}
    for raw in values:
        email = raw.strip().lower()
        if email and email not in seen:
            seen[email] = None
    return list(seen)
