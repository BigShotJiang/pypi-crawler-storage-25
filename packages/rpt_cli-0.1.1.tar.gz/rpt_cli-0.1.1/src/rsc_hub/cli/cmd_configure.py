"""CLI command: rsc configure — set up API connection details."""

import typer

from rsc_hub.cli.client import CONFIG_DIR, CONFIG_FILE, get_api_key, get_base_url


def configure(
    api_key: str | None = typer.Option(None, "--api-key", "-k", help="Set your API key"),
    base_url: str | None = typer.Option(None, "--url", "-u", help="Set the hub base URL"),
    show: bool = typer.Option(False, "--show", help="Show current configuration"),
) -> None:
    """Configure the RPT Hub CLI.

    Settings are stored in ~/.rpt/config.

    Examples:
        rsc configure --api-key rsc_demo_capitalgroup_7c3758b1
        rsc configure --url http://localhost:8000
        rsc configure --show
    """
    if show:
        _show_config()
        return

    if api_key is None and base_url is None:
        _show_config()
        return

    config = _load_existing()

    if api_key is not None:
        config["api_key"] = api_key
    if base_url is not None:
        config["base_url"] = base_url

    _save_config(config)
    print("Configuration saved to ~/.rpt/config")

    if api_key:
        prefix = api_key[:8] if len(api_key) >= 8 else api_key
        print(f"  API key: {prefix}...")
    if base_url:
        print(f"  Base URL: {base_url}")


def _show_config() -> None:
    """Display the current configuration."""
    current_url = get_base_url()
    current_key = get_api_key()

    print("\n  RPT Hub CLI Configuration")
    print(f"  Config file: {CONFIG_FILE}")
    print(f"  Base URL:    {current_url}")

    if current_key:
        prefix = current_key[:8] if len(current_key) >= 8 else current_key
        print(f"  API key:     {prefix}...")
    else:
        print("  API key:     (not set)")

    print()


def _load_existing() -> dict[str, str]:
    """Load existing config values.

    Returns:
        Dict of current configuration.
    """
    config: dict[str, str] = {}
    if CONFIG_FILE.exists():
        for line in CONFIG_FILE.read_text().strip().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                config[key.strip()] = value.strip()
    return config


def _save_config(config: dict[str, str]) -> None:
    """Write config dict to ~/.rpt/config.

    Args:
        config: Key-value pairs to persist.
    """
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = [f"{key}={value}" for key, value in sorted(config.items())]
    CONFIG_FILE.write_text("\n".join(lines) + "\n")
