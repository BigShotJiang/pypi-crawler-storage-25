"""CLI command: rsc search — cross-library research search."""

import typer

from rsc_hub.cli.client import make_request
from rsc_hub.cli.formatters import format_search_results


def search(
    query: str = typer.Argument(..., help="Search query (e.g. 'ARM Holdings', 'semiconductor')"),
    sector: str | None = typer.Option(None, "--sector", "-s", help="Filter by sector"),
    ticker: str | None = typer.Option(None, "--ticker", "-t", help="Filter by ticker"),
    rating: str | None = typer.Option(None, "--rating", "-r", help="Filter by rating (buy/hold/sell)"),
    limit: int = typer.Option(10, "--limit", "-n", help="Number of results"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """Search cross-library research notes.

    Examples:
        rsc search "ARM Holdings"
        rsc search semiconductor --sector Technology --limit 5
        rsc search housebuilders --rating buy
        rsc search "Rolls-Royce" --ticker RR. --json
    """
    params: dict[str, str | int] = {"q": query, "limit": limit, "offset": 0}
    if sector:
        params["sectors"] = sector
    if ticker:
        params["tickers"] = ticker
    if rating:
        params["rating"] = rating

    data = make_request("GET", "/api/v1/search", params=params)

    if json_output:
        import json

        print(json.dumps(data, indent=2))
    else:
        print(format_search_results(data))
