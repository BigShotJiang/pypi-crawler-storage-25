"""CLI command: rsc note — view research note details and stock intelligence."""

from typing import Any

import typer

from rsc_hub.cli.client import make_request
from rsc_hub.cli.formatters import format_note_detail


def note(
    identifier: str = typer.Argument(..., help="Note UUID or ticker (e.g. ARM, RR.)"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """View a specific research note or stock intelligence.

    Pass a UUID to view a specific note, or a ticker symbol to get
    the full cross-library stock intelligence briefing.

    Examples:
        rsc note ARM                    # Stock intelligence for ARM
        rsc note RR.                    # Stock intelligence for Rolls-Royce
        rsc note 87a9ac76-bcc1-...     # Specific note by ID
    """
    if _looks_like_uuid(identifier):
        _show_note_by_id(identifier, json_output)
    else:
        _show_stock_intelligence(identifier, json_output)


def _show_note_by_id(note_id: str, json_output: bool) -> None:
    """Fetch and display a single note by UUID.

    Args:
        note_id: The note's UUID string.
        json_output: Whether to output raw JSON.
    """
    note = make_request("GET", f"/api/v1/notes/{note_id}")

    # Fetch content redirect URL
    try:
        content = make_request("GET", f"/api/v1/notes/{note_id}/content")
        note["content_redirect"] = content
    except Exception:
        pass

    if json_output:
        import json

        print(json.dumps(note, indent=2))
    else:
        print(format_note_detail(note))


def _show_stock_intelligence(ticker: str, json_output: bool) -> None:
    """Fetch and display stock intelligence for a ticker.

    Args:
        ticker: The stock ticker symbol.
        json_output: Whether to output raw JSON.
    """
    data = make_request("GET", f"/api/v1/intelligence/stock/{ticker}")

    if json_output:
        import json

        print(json.dumps(data, indent=2))
    else:
        _format_intelligence(data)


def _format_intelligence(data: dict[str, Any]) -> None:
    """Format stock intelligence for terminal display.

    Args:
        data: Parsed JSON from the intelligence endpoint.
    """
    ticker = data.get("ticker", "?")
    company = data.get("company_name", "")
    consensus = data.get("consensus", "—")
    coverage = data.get("coverage_count", 0)

    lines = [f"\n  {ticker} — {company}", f"  {'=' * min(len(f'{ticker} — {company}'), 70)}"]
    lines.append(f"  Consensus: {(consensus or '—').upper()} | Coverage: {coverage} providers")

    pt = data.get("price_target_stats")
    if pt and pt.get("count"):
        lines.append(
            f"  Targets: avg {pt.get('currency', '')}{pt.get('average', 0):.0f}"
            f" | range {pt.get('low', 0):.0f}-{pt.get('high', 0):.0f}"
            f" | dispersion {pt.get('dispersion_pct', 0):.1f}%"
        )

    vel = data.get("velocity")
    if vel:
        lines.append(f"  Velocity: {vel.get('notes_7d', 0)} notes (7d) | {vel.get('notes_30d', 0)} (30d)")

    flags = data.get("contrarian_flags", [])
    if flags:
        lines.append(f"  Contrarian: {', '.join(flags)}")

    notes = data.get("latest_notes", [])
    if notes:
        lines.append("\n  Latest Notes:")
        for n in notes[:5]:
            r = (n.get("rating") or "—").upper()
            p = n.get("provider_name", "")
            lines.append(f"    • [{r}] {n.get('title', '')} ({p})")

    lines.append("")
    print("\n".join(lines))


def _looks_like_uuid(s: str) -> bool:
    """Check if a string looks like a UUID.

    Args:
        s: The string to check.

    Returns:
        True if it matches UUID format.
    """
    return len(s) == 36 and s.count("-") == 4
