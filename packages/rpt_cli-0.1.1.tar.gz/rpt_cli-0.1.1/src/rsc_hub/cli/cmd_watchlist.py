"""CLI command: rpt watchlist — manage and monitor named watchlists.

Add, remove, list, and monitor tickers across named watchlists.
Supports user-scoped named watchlists (Default, Tech, etc.).
"""

import json

import typer

from rsc_hub.cli.client import make_request

watchlist_app = typer.Typer(help="Manage and monitor your portfolio watchlists.")


@watchlist_app.command("lists")
def list_watchlists(
    as_json: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """List all named watchlists."""
    data = make_request("GET", "/api/v1/watchlist", require_auth=True)

    if as_json:
        print(json.dumps(data, indent=2, default=str))
        return

    watchlists = data.get("watchlists", [])
    print(f"\n  Watchlists ({len(watchlists)})\n")
    for w in watchlists:
        print(f"  {w['name']} ({w['count']} tickers)")
    print()


@watchlist_app.command("list")
def list_tickers(
    name: str = typer.Argument("Default", help="Watchlist name"),
    as_json: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """List tickers in a named watchlist."""
    data = make_request("GET", f"/api/v1/watchlist/{name}", require_auth=True)

    if as_json:
        print(json.dumps(data, indent=2, default=str))
        return

    tickers = data.get("tickers", [])
    print(f"\n  {name} ({len(tickers)} tickers)\n")
    for t in tickers:
        exchange = f" ({t['exchange']})" if t.get("exchange") else ""
        print(f"  {t['ticker']}{exchange}")
    print()


@watchlist_app.command("add")
def add_ticker(
    ticker: str = typer.Argument(..., help="Ticker symbol (e.g. ARM, RR.)"),
    name: str = typer.Option("Default", "--name", "-n", help="Watchlist name"),
    exchange: str | None = typer.Option(None, "--exchange", "-e", help="Exchange code"),
) -> None:
    """Add a ticker to a named watchlist."""
    body: dict[str, str] = {"ticker": ticker.upper()}
    if exchange:
        body["exchange"] = exchange.upper()
    make_request("POST", f"/api/v1/watchlist/{name}/tickers", json_body=body, require_auth=True)
    print(f"  Added {ticker.upper()} to {name}")


@watchlist_app.command("remove")
def remove_ticker(
    ticker: str = typer.Argument(..., help="Ticker to remove"),
    name: str = typer.Option("Default", "--name", "-n", help="Watchlist name"),
) -> None:
    """Remove a ticker from a named watchlist."""
    make_request("DELETE", f"/api/v1/watchlist/{name}/tickers/{ticker.upper()}", require_auth=True)
    print(f"  Removed {ticker.upper()} from {name}")


@watchlist_app.command("create")
def create_watchlist(
    name: str = typer.Argument(..., help="Name for the new watchlist"),
) -> None:
    """Create a new named watchlist."""
    body = {"name": name, "tickers": []}
    make_request("POST", "/api/v1/watchlist", json_body=body, require_auth=True)
    print(f"  Created watchlist: {name}")


@watchlist_app.command("delete")
def delete_watchlist(
    name: str = typer.Argument(..., help="Watchlist to delete"),
) -> None:
    """Delete a named watchlist and all its tickers."""
    data = make_request("DELETE", f"/api/v1/watchlist/{name}", require_auth=True)
    removed = data.get("tickers_removed", 0)
    print(f"  Deleted {name} ({removed} tickers removed)")


@watchlist_app.command("monitor")
def monitor(
    name: str = typer.Option("Default", "--name", "-n", help="Watchlist name"),
    days: int = typer.Option(7, "--days", "-d", help="Lookback period in days"),
    as_json: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """Monitor a watchlist for rating changes and new research."""
    data = make_request("GET", f"/api/v1/watchlist/{name}/monitor", params={"days": days}, require_auth=True)

    if as_json:
        print(json.dumps(data, indent=2, default=str))
        return

    tickers = data.get("tickers", [])
    print(f"\n  {name} monitor ({len(tickers)} tickers, last {days} days)\n")
    for t in tickers:
        consensus = f" [{t['consensus_rating'].upper()}]" if t.get("consensus_rating") else ""
        print(f"  {t['ticker']}{consensus}")
        print(f"    Coverage: {t.get('coverage_count', 0)} analysts | New: {t.get('new_notes_count', 0)} notes")

        for c in t.get("rating_changes", []):
            old = c.get("old_rating", "?")
            new = c.get("new_rating", "?")
            prov = c.get("provider_name", "")
            print(f"    Rating change: {old} -> {new} ({prov})")

        latest = t.get("latest_note")
        if latest:
            title = latest.get("title", "") if isinstance(latest, dict) else latest
            print(f"    Latest: {title}")
        print()
