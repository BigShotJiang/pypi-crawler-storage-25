"""RPT Hub CLI: query cross-library research from the terminal.

Provides search, note, feed, providers, watchlist, configure, and
(when the server package is present) admin commands.

Two distributions share this entry point:
- ``rsc-hub`` — the full monorepo, includes the server-admin CLI
  which reaches into the DB (``cmd_admin``) and needs server deps.
- ``rpt-cli`` — the lean PyPI package for buy-side / sell-side
  users. Excludes ``cmd_admin*``; the admin subtree is hidden
  gracefully if the import fails.
"""

import typer

from rsc_hub.cli.cmd_configure import configure
from rsc_hub.cli.cmd_feed import feed
from rsc_hub.cli.cmd_note import note
from rsc_hub.cli.cmd_providers import providers
from rsc_hub.cli.cmd_search import search
from rsc_hub.cli.cmd_watchlist import watchlist_app
from rsc_hub.cli.provider import provider_app

app = typer.Typer(
    name="rpt",
    help="RPT Research Hub CLI — cross-library research intelligence.",
    no_args_is_help=True,
)

app.command("search")(search)
app.command("note")(note)
app.command("feed")(feed)
app.command("providers")(providers)
app.command("configure")(configure)
app.add_typer(watchlist_app, name="watchlist")
app.add_typer(provider_app, name="provider")

# Server-admin commands are optional. They live in cmd_admin* and
# touch the DB directly (SQLAlchemy, hub models). When running from
# the lean rpt-cli wheel those modules aren't packaged, so the
# imports fail and we skip silently — the other subcommands still
# register and work.
try:
    import rsc_hub.cli.cmd_admin_list  # noqa: F401 — registers list-orgs/list-keys on admin_app
    from rsc_hub.cli.cmd_admin import admin_app

    app.add_typer(admin_app, name="admin")
except ImportError:
    pass


if __name__ == "__main__":
    app()
