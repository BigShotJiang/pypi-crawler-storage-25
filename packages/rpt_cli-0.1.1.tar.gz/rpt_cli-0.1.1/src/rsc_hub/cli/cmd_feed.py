"""CLI command: rpt feed — browse latest research without searching.

Shows recently published research from connected providers,
sorted by publication date. Filter by sector or note type.
"""

import json

import typer

from rsc_hub.cli.client import make_request


def feed(
    limit: int = typer.Option(20, "--limit", "-n", help="Max results (1-100)"),
    sector: str | None = typer.Option(None, "--sector", "-s", help="Filter by sector"),
    note_type: str | None = typer.Option(None, "--type", "-t", help="Filter by note type"),
    as_json: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """Browse the latest research from all connected providers.

    Shows recently published notes without needing a search query.
    Useful for morning briefings and research scanning.
    """
    params: dict[str, object] = {"limit": limit}
    if sector:
        params["sectors"] = sector
    if note_type:
        params["note_type"] = note_type

    data = make_request("GET", "/api/v1/feed", params=params, require_auth=True)

    if as_json:
        print(json.dumps(data, indent=2, default=str))
        return

    notes = data.get("notes", [])
    total = data.get("total", 0)
    print(f"\n  Latest research ({total} total)\n")

    for n in notes:
        title = n.get("title", "Untitled")
        provider = n.get("provider_name", "Unknown")
        rating = n.get("rating", "")
        published = str(n.get("published_at", ""))[:10]
        authors = ", ".join(n.get("authors", []))
        rating_str = f" [{rating.upper()}]" if rating else ""
        print(f"  {title}{rating_str}")
        print(f"    {provider} | {authors} | {published}")
        print()
