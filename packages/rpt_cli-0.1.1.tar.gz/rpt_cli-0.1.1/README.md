# rpt-cli

Query cross-library investment research from your terminal.

## Install

```bash
pip install rpt-cli
```

## Configure

```bash
rpt configure --api-key <your-key>
```

Configuration lives at `~/.rpt/config`. Grab an API key from
`/dashboard/integrations` on the RPT platform or your broker's branded
portal.

If you're using a branded portal (e.g. Shore Capital's), point the CLI
at it so all commands are scoped to that provider's research:

```bash
rpt configure --api-key <your-key> --url https://shore-capital.researchprotocol.io
```

## Usage

```bash
# Cross-library search
rpt search "Rolls-Royce" --rating buy

# Recent research feed
rpt feed --limit 20

# Open a single note by ID or ticker
rpt note ARM

# List entitled providers
rpt providers

# Manage watchlists
rpt watchlist list
rpt watchlist add ARM

# Provider-admin (requires an API key with admin scope)
rpt provider clients list
rpt provider templates list
rpt provider rate-limits set <entitlement-id> --daily 1000
```

Run `rpt --help` for the full command tree.

## What this package is

`rpt-cli` is the lean CLI half of the [RPT Research Hub](https://www.researchprotocol.io) —
a standardised API gateway for investment research across multiple
sell-side providers. It talks to the public REST API and ships with no
server dependencies (no FastAPI, no SQLAlchemy, no Stripe). Install it
wherever you need to query research from a shell or script.

The server half lives in the same repository but is published
separately; if you're deploying the hub itself you want that package,
not this one.

## Links

- Homepage — https://www.researchprotocol.io
- API reference — https://www.researchprotocol.io/api-reference
- Source — https://github.com/viridios/rsc-hub

## License

MIT
