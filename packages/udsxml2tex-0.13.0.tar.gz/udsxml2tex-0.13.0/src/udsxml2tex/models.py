"""Data models for UDS specification parsed from ARXML."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Optional


class SessionType(IntEnum):
    """UDS diagnostic session types."""

    DEFAULT = 0x01
    PROGRAMMING = 0x02
    EXTENDED = 0x03


@dataclass
class DiagSession:
    """Diagnostic session definition."""

    short_name: str
    session_id: int
    p2_server_max: float = 0.05  # seconds
    p2_star_server_max: float = 5.0  # seconds
    comm_ctrl_option_mask: int = 0  # DcmDspSessionCommCtrlOptionMask

    @property
    def session_id_hex(self) -> str:
        return f"0x{self.session_id:02X}"


@dataclass
class SecurityLevel:
    """Security access level definition."""

    short_name: str
    security_level: int
    num_max_attempts: int = 3
    attempt_delay: float = 0.0  # seconds – delay after failed attempts
    key_size: int = 0  # bytes
    seed_size: int = 0  # bytes
    adr_size: int = 0  # bytes – AccessDataRecord size
    num_provided_seed_attempts: int = 0  # DcmDspSecurityNumProvidedSeedAttempts
    algorithm_ref: str = ""  # DcmDspSecurityAlgorithmRef
    seed_key_increment_mode: str = ""  # DcmDspSecuritySeedAndKeyTypeIncrementMode
    delay_time_on_boot: float = 0.0  # DcmDspSecurityDelayTimeOnBoot
    attempt_counter_enabled: bool = True  # DcmDspSecurityAttemptCounterEnabled

    @property
    def security_level_hex(self) -> str:
        return f"0x{self.security_level:02X}"


@dataclass
class DataElement:
    """A data element within a DID or routine parameter."""

    short_name: str
    byte_position: int = 0
    bit_position: int = 0
    bit_size: int = 8
    description: str = ""
    data_type: str = "uint8"
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    unit: str = ""
    coding: str = ""
    endianness: str = ""  # BIG_ENDIAN, LITTLE_ENDIAN
    fixed_length: bool = True


@dataclass
class SubFunction:
    """UDS service sub-function definition."""

    short_name: str
    sub_function_id: int
    description: str = ""
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    suppress_pos_rsp: bool = False  # suppressPosRspMsgIndicationBit
    data_block_size: int = 0  # DcmDsdSubServiceDataBlockSize

    @property
    def sub_function_id_hex(self) -> str:
        return f"0x{self.sub_function_id:02X}"


@dataclass
class Did:
    """Data Identifier (DID) definition."""

    short_name: str
    did_id: int
    description: str = ""
    data_elements: list[DataElement] = field(default_factory=list)
    read_access: bool = True
    write_access: bool = False
    snapshot_record: bool = False
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    total_byte_length: int = 0

    @property
    def did_id_hex(self) -> str:
        return f"0x{self.did_id:04X}"


@dataclass
class RoutineParameter:
    """Parameter for a routine control service."""

    short_name: str
    direction: str = "in"  # "in", "out"
    byte_position: int = 0
    bit_size: int = 8
    description: str = ""
    data_type: str = "uint8"


@dataclass
class Routine:
    """Routine control definition."""

    short_name: str
    routine_id: int
    description: str = ""
    start_supported: bool = True
    stop_supported: bool = False
    result_supported: bool = False
    in_parameters: list[RoutineParameter] = field(default_factory=list)
    out_parameters: list[RoutineParameter] = field(default_factory=list)
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    max_number_of_options: int = 0  # DcmDspRoutineMaxNumberOfOptions
    access_type_required: bool = False  # DcmDspRoutineAccessTypeRequired

    @property
    def routine_id_hex(self) -> str:
        return f"0x{self.routine_id:04X}"


@dataclass
class NrcEntry:
    """Negative Response Code entry for a service."""

    nrc_code: int
    nrc_name: str
    description: str = ""

    @property
    def nrc_code_hex(self) -> str:
        return f"0x{self.nrc_code:02X}"


# Standard NRC definitions
STANDARD_NRCS: dict[int, str] = {
    0x10: "generalReject",
    0x11: "serviceNotSupported",
    0x12: "subFunctionNotSupported",
    0x13: "incorrectMessageLengthOrInvalidFormat",
    0x14: "responseTooLong",
    0x21: "busyRepeatRequest",
    0x22: "conditionsNotCorrect",
    0x24: "requestSequenceError",
    0x25: "noResponseFromSubnetComponent",
    0x26: "failurePreventsExecutionOfRequestedAction",
    0x31: "requestOutOfRange",
    0x33: "securityAccessDenied",
    0x35: "invalidKey",
    0x36: "exceededNumberOfAttempts",
    0x37: "requiredTimeDelayNotExpired",
    0x70: "uploadDownloadNotAccepted",
    0x71: "transferDataSuspended",
    0x72: "generalProgrammingFailure",
    0x73: "wrongBlockSequenceCounter",
    0x78: "requestCorrectlyReceivedResponsePending",
    0x7E: "subFunctionNotSupportedInActiveSession",
    0x7F: "serviceNotSupportedInActiveSession",
}

# NRC checking order per ISO 14229-1 for flowchart generation.
# Each entry: (nrc_code, short_question_label)
# The flowchart shows decision diamonds in this order; only NRCs
# present in the service's nrc_list are included.
NRC_CHECK_ORDER: list[tuple[int, str]] = [
    (0x11, "Service\\\\supported?"),
    (0x13, "Message length\\\\valid?"),
    (0x12, "Sub-function\\\\supported?"),
    (0x7F, "Service supported\\\\in active session?"),
    (0x7E, "Sub-function supported\\\\in active session?"),
    (0x33, "Security\\\\access granted?"),
    (0x35, "Key\\\\valid?"),
    (0x36, "Attempts\\\\not exceeded?"),
    (0x37, "Time delay\\\\expired?"),
    (0x24, "Request sequence\\\\correct?"),
    (0x22, "Conditions\\\\correct?"),
    (0x31, "Request\\\\in range?"),
    (0x70, "Upload/Download\\\\accepted?"),
    (0x71, "Transfer data\\\\not suspended?"),
    (0x72, "Programming\\\\OK?"),
    (0x73, "Block sequence\\\\correct?"),
    (0x14, "Response length\\\\OK?"),
    (0x10, "No general\\\\reject?"),
]


@dataclass
class UdsService:
    """UDS diagnostic service definition."""

    short_name: str
    service_id: int
    description: str = ""
    sub_functions: list[SubFunction] = field(default_factory=list)
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    nrc_list: list[NrcEntry] = field(default_factory=list)
    addressing_modes: list[str] = field(default_factory=list)  # physical, functional
    suppress_pos_rsp: bool = False  # suppressPosRspMsgIndicationBit
    request_min_length: int = 0  # DcmDsdServiceRequestMinLength
    request_max_length: int = 0  # DcmDsdServiceRequestMaxLength
    response_min_length: int = 0  # DcmDsdServiceResponseMinLength
    response_max_length: int = 0  # DcmDsdServiceResponseMaxLength

    @property
    def service_id_hex(self) -> str:
        return f"0x{self.service_id:02X}"

    @property
    def positive_response_id(self) -> int:
        return self.service_id + 0x40

    @property
    def positive_response_id_hex(self) -> str:
        return f"0x{self.positive_response_id:02X}"


# Standard UDS service names
UDS_SERVICE_NAMES: dict[int, str] = {
    0x10: "DiagnosticSessionControl",
    0x11: "ECUReset",
    0x14: "ClearDiagnosticInformation",
    0x19: "ReadDTCInformation",
    0x22: "ReadDataByIdentifier",
    0x23: "ReadMemoryByAddress",
    0x24: "ReadScalingDataByIdentifier",
    0x27: "SecurityAccess",
    0x28: "CommunicationControl",
    0x29: "Authentication",
    0x2A: "ReadDataByPeriodicIdentifier",
    0x2C: "DynamicallyDefineDataIdentifier",
    0x2E: "WriteDataByIdentifier",
    0x2F: "InputOutputControlByIdentifier",
    0x31: "RoutineControl",
    0x34: "RequestDownload",
    0x35: "RequestUpload",
    0x36: "TransferData",
    0x37: "RequestTransferExit",
    0x38: "RequestFileTransfer",
    0x3D: "WriteMemoryByAddress",
    0x3E: "TesterPresent",
    0x84: "SecuredDataTransmission",
    0x85: "ControlDTCSetting",
    0x86: "ResponseOnEvent",
    0x87: "LinkControl",
}

# ISO 14229-1 section order for UDS services
# Maps SID to its section order in the standard
ISO14229_SERVICE_ORDER: dict[int, int] = {
    0x10: 1,   # DiagnosticSessionControl (§9.2)
    0x11: 2,   # ECUReset (§9.3)
    0x27: 3,   # SecurityAccess (§9.4)
    0x28: 4,   # CommunicationControl (§9.5)
    0x29: 5,   # Authentication (§9.6)
    0x3E: 6,   # TesterPresent (§9.7)
    0x85: 7,   # ControlDTCSetting (§9.8)
    0x86: 8,   # ResponseOnEvent (§9.9)
    0x87: 9,   # LinkControl (§9.10)
    0x22: 10,  # ReadDataByIdentifier (§10.2)
    0x23: 11,  # ReadMemoryByAddress (§10.3)
    0x24: 12,  # ReadScalingDataByIdentifier (§10.4)
    0x2A: 13,  # ReadDataByPeriodicIdentifier (§10.5)
    0x2C: 14,  # DynamicallyDefineDataIdentifier (§10.6)
    0x2E: 15,  # WriteDataByIdentifier (§10.7)
    0x3D: 16,  # WriteMemoryByAddress (§10.8)
    0x14: 17,  # ClearDiagnosticInformation (§11.2)
    0x19: 18,  # ReadDTCInformation (§11.3)
    0x2F: 19,  # InputOutputControlByIdentifier (§12.2)
    0x31: 20,  # RoutineControl (§12.3)
    0x34: 21,  # RequestDownload (§13.2)
    0x35: 22,  # RequestUpload (§13.3)
    0x36: 23,  # TransferData (§13.4)
    0x37: 24,  # RequestTransferExit (§13.5)
    0x38: 25,  # RequestFileTransfer (§13.6)
    0x84: 26,  # SecuredDataTransmission (§14.2)
}


# Standard addressing modes per ISO 14229-1
# Maps SID -> list of addressing modes (physical, functional)
STANDARD_ADDRESSING_MODES: dict[int, list[str]] = {
    0x10: ["physical", "functional"],  # DiagnosticSessionControl
    0x11: ["physical", "functional"],  # ECUReset
    0x14: ["physical", "functional"],  # ClearDiagnosticInformation
    0x19: ["physical", "functional"],  # ReadDTCInformation
    0x22: ["physical", "functional"],  # ReadDataByIdentifier
    0x23: ["physical"],               # ReadMemoryByAddress
    0x24: ["physical"],               # ReadScalingDataByIdentifier
    0x27: ["physical"],               # SecurityAccess
    0x28: ["physical", "functional"],  # CommunicationControl
    0x29: ["physical"],               # Authentication
    0x2A: ["physical"],               # ReadDataByPeriodicIdentifier
    0x2C: ["physical"],               # DynamicallyDefineDataIdentifier
    0x2E: ["physical"],               # WriteDataByIdentifier
    0x2F: ["physical"],               # InputOutputControlByIdentifier
    0x31: ["physical"],               # RoutineControl
    0x34: ["physical"],               # RequestDownload
    0x35: ["physical"],               # RequestUpload
    0x36: ["physical"],               # TransferData
    0x37: ["physical"],               # RequestTransferExit
    0x38: ["physical"],               # RequestFileTransfer
    0x3D: ["physical"],               # WriteMemoryByAddress
    0x3E: ["physical", "functional"],  # TesterPresent
    0x84: ["physical"],               # SecuredDataTransmission
    0x85: ["physical", "functional"],  # ControlDTCSetting
    0x86: ["physical"],               # ResponseOnEvent
    0x87: ["physical"],               # LinkControl
}


# Standard sub-function definitions per ISO 14229-1
# Maps SID -> list of (sub_function_id, short_name)
STANDARD_SUB_FUNCTIONS: dict[int, list[tuple[int, str]]] = {
    # DiagnosticSessionControl (§9.2)
    0x10: [
        (0x01, "defaultSession"),
        (0x02, "programmingSession"),
        (0x03, "extendedDiagnosticSession"),
    ],
    # ECUReset (§9.3)
    0x11: [
        (0x01, "hardReset"),
        (0x02, "keyOffOnReset"),
        (0x03, "softReset"),
    ],
    # ReadDTCInformation (§11.3)
    0x19: [
        (0x01, "reportNumberOfDTCByStatusMask"),
        (0x02, "reportDTCByStatusMask"),
        (0x03, "reportDTCSnapshotIdentification"),
        (0x04, "reportDTCSnapshotRecordByDTCNumber"),
        (0x05, "reportDTCStoredDataByRecordNumber"),
        (0x06, "reportDTCExtDataRecordByDTCNumber"),
        (0x0A, "reportSupportedDTC"),
        (0x14, "reportDTCFaultDetectionCounter"),
        (0x15, "reportDTCWithPermanentStatus"),
    ],
    # SecurityAccess (§9.4) — odd = requestSeed, even = sendKey
    0x27: [
        (0x01, "requestSeed (Level 1)"),
        (0x02, "sendKey (Level 1)"),
        (0x03, "requestSeed (Level 2)"),
        (0x04, "sendKey (Level 2)"),
    ],
    # CommunicationControl (§9.5)
    0x28: [
        (0x00, "enableRxAndTx"),
        (0x01, "enableRxAndDisableTx"),
        (0x02, "disableRxAndEnableTx"),
        (0x03, "disableRxAndTx"),
    ],
    # Authentication (§9.6)
    0x29: [
        (0x00, "deAuthenticate"),
        (0x01, "verifyCertificateUnidirectional"),
        (0x02, "verifyCertificateBidirectional"),
        (0x03, "proofOfOwnership"),
        (0x04, "transmitCertificate"),
        (0x05, "requestChallengeForAuthentication"),
        (0x06, "verifyProofOfOwnershipUnidirectional"),
        (0x07, "verifyProofOfOwnershipBidirectional"),
        (0x08, "authenticationConfiguration"),
    ],
    # RoutineControl (§12.3)
    0x31: [
        (0x01, "startRoutine"),
        (0x02, "stopRoutine"),
        (0x03, "requestRoutineResults"),
    ],
    # DynamicallyDefineDataIdentifier (§10.6)
    0x2C: [
        (0x01, "defineByIdentifier"),
        (0x02, "defineByMemoryAddress"),
        (0x03, "clearDynamicallyDefinedDataIdentifier"),
    ],
    # TesterPresent (§9.7)
    0x3E: [
        (0x00, "zeroSubFunction"),
    ],
    # ControlDTCSetting (§9.8)
    0x85: [
        (0x01, "on"),
        (0x02, "off"),
    ],
    # LinkControl (§9.10)
    0x87: [
        (0x01, "verifyModeTransitionWithFixedParameter"),
        (0x02, "verifyModeTransitionWithSpecificParameter"),
        (0x03, "transitionMode"),
    ],
}


# UDS Request / Positive-Response message-format definitions per ISO 14229-1
# Maps SID -> (request_rows, response_rows)
# Each row: (byte_position, parameter_name, display_value, is_fixed_hex)
#   is_fixed_hex=True  -> render with \hexval (subscript-16)
#   is_fixed_hex=False -> render with \texttt (variable content)
UDS_MESSAGE_FORMATS: dict[int, tuple[list[tuple[str, str, str, bool]],
                                      list[tuple[str, str, str, bool]]]] = {
    # ---- DiagnosticSessionControl (§9.2) ----
    0x10: (
        [("#1", "Service ID (SID)", "10", True),
         ("#2", "sub-function = sessionType", "xx", False)],
        [("#1", "Response SID", "50", True),
         ("#2", "sub-function = sessionType", "xx", False),
         ("#3--#4", "P2ServerMax (high byte, low byte)", "xx xx", False),
         ("#5--#6", "P2*ServerMax / 10 (high byte, low byte)", "xx xx", False)],
    ),
    # ---- ECUReset (§9.3) ----
    0x11: (
        [("#1", "Service ID (SID)", "11", True),
         ("#2", "sub-function = resetType", "xx", False)],
        [("#1", "Response SID", "51", True),
         ("#2", "sub-function = resetType", "xx", False),
         ("#3", "powerDownTime", "xx", False)],
    ),
    # ---- ClearDiagnosticInformation (§11.2) ----
    0x14: (
        [("#1", "Service ID (SID)", "14", True),
         ("#2--#4", "groupOfDTC[]", "xx xx xx", False)],
        [("#1", "Response SID", "54", True)],
    ),
    # ---- ReadDTCInformation (§11.3) ----
    0x19: (
        [("#1", "Service ID (SID)", "19", True),
         ("#2", "sub-function = reportType", "xx", False),
         ("#3--#N", "DTC status mask / DTC number (report-type dependent)", "...", False)],
        [("#1", "Response SID", "59", True),
         ("#2", "sub-function = reportType", "xx", False),
         ("#3--#N", "data[] (report-type dependent)", "...", False)],
    ),
    # ---- ReadDataByIdentifier (§10.2) ----
    0x22: (
        [("#1", "Service ID (SID)", "22", True),
         ("#2--#3", "dataIdentifier[] (1st DID)", "xx xx", False),
         ("#4--#N", "dataIdentifier[] (additional DIDs, optional)", "...", False)],
        [("#1", "Response SID", "62", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4--#N", "dataRecord[]", "...", False)],
    ),
    # ---- SecurityAccess (§9.4) ----
    0x27: (
        [("#1", "Service ID (SID)", "27", True),
         ("#2", "sub-function = securityAccessType", "xx", False),
         ("#3--#N", "securityAccessDataRecord / securityKey", "...", False)],
        [("#1", "Response SID", "67", True),
         ("#2", "sub-function = securityAccessType", "xx", False),
         ("#3--#N", "securitySeed (requestSeed response only)", "...", False)],
    ),
    # ---- CommunicationControl (§9.5) ----
    0x28: (
        [("#1", "Service ID (SID)", "28", True),
         ("#2", "sub-function = controlType", "xx", False),
         ("#3", "communicationType", "xx", False),
         ("#4--#5", "nodeIdentificationNumber (optional)", "xx xx", False)],
        [("#1", "Response SID", "68", True),
         ("#2", "sub-function = controlType", "xx", False)],
    ),
    # ---- Authentication (§9.6) ----
    0x29: (
        [("#1", "Service ID (SID)", "29", True),
         ("#2", "sub-function = authenticationTask", "xx", False),
         ("#3--#N", "authenticationParameter[]", "...", False)],
        [("#1", "Response SID", "69", True),
         ("#2", "sub-function = authenticationTask", "xx", False),
         ("#3", "authenticationReturnParameter", "xx", False),
         ("#4--#N", "authenticationParameter[]", "...", False)],
    ),
    # ---- WriteDataByIdentifier (§10.7) ----
    0x2E: (
        [("#1", "Service ID (SID)", "2E", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4--#N", "dataRecord[]", "...", False)],
        [("#1", "Response SID", "6E", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False)],
    ),
    # ---- RoutineControl (§12.3) ----
    0x31: (
        [("#1", "Service ID (SID)", "31", True),
         ("#2", "sub-function = routineControlType", "xx", False),
         ("#3--#4", "routineIdentifier[]", "xx xx", False),
         ("#5--#N", "routineOptionRecord[]", "...", False)],
        [("#1", "Response SID", "71", True),
         ("#2", "sub-function = routineControlType", "xx", False),
         ("#3--#4", "routineIdentifier[]", "xx xx", False),
         ("#5--#N", "routineStatusRecord[]", "...", False)],
    ),
    # ---- RequestDownload (§13.2) ----
    0x34: (
        [("#1", "Service ID (SID)", "34", True),
         ("#2", "dataFormatIdentifier", "xx", False),
         ("#3", "addressAndLengthFormatIdentifier", "xx", False),
         ("#4--#m", "memoryAddress[]", "...", False),
         ("#(m+1)--#n", "memorySize[]", "...", False)],
        [("#1", "Response SID", "74", True),
         ("#2", "lengthFormatIdentifier", "xx", False),
         ("#3--#N", "maxNumberOfBlockLength", "...", False)],
    ),
    # ---- TransferData (§13.4) ----
    0x36: (
        [("#1", "Service ID (SID)", "36", True),
         ("#2", "blockSequenceCounter", "xx", False),
         ("#3--#N", "transferRequestParameterRecord[]", "...", False)],
        [("#1", "Response SID", "76", True),
         ("#2", "blockSequenceCounter", "xx", False),
         ("#3--#N", "transferResponseParameterRecord[]", "...", False)],
    ),
    # ---- RequestTransferExit (§13.5) ----
    0x37: (
        [("#1", "Service ID (SID)", "37", True),
         ("#2--#N", "transferRequestParameterRecord[]", "...", False)],
        [("#1", "Response SID", "77", True),
         ("#2--#N", "transferResponseParameterRecord[]", "...", False)],
    ),
    # ---- TesterPresent (§9.7) ----
    0x3E: (
        [("#1", "Service ID (SID)", "3E", True),
         ("#2", "sub-function", "xx", False)],
        [("#1", "Response SID", "7E", True),
         ("#2", "sub-function", "xx", False)],
    ),
    # ---- ControlDTCSetting (§9.8) ----
    0x85: (
        [("#1", "Service ID (SID)", "85", True),
         ("#2", "sub-function = DTCSettingType", "xx", False),
         ("#3--#N", "DTCSettingControlOptionRecord (optional)", "...", False)],
        [("#1", "Response SID", "C5", True),
         ("#2", "sub-function = DTCSettingType", "xx", False)],
    ),
    # ---- ResponseOnEvent (§9.9) ----
    0x86: (
        [("#1", "Service ID (SID)", "86", True),
         ("#2", "sub-function = eventType", "xx", False),
         ("#3", "eventWindowTime", "xx", False),
         ("#4--#N", "eventTypeRecord / serviceToRespondToRecord", "...", False)],
        [("#1", "Response SID", "C6", True),
         ("#2", "sub-function = eventType", "xx", False),
         ("#3", "numberOfIdentifiedEvents", "xx", False),
         ("#4", "eventWindowTime", "xx", False),
         ("#5--#N", "eventTypeRecord / serviceToRespondToRecord", "...", False)],
    ),
    # ---- RequestFileTransfer (§13.6) ----
    0x38: (
        [("#1", "Service ID (SID)", "38", True),
         ("#2", "modeOfOperation", "xx", False),
         ("#3--#4", "filePathAndNameLength", "xx xx", False),
         ("#5--#m", "filePathAndName[]", "...", False),
         ("#(m+1)", "dataFormatIdentifier", "xx", False),
         ("#(m+2)--#N", "fileSizeParameterLength", "...", False)],
        [("#1", "Response SID", "78", True),
         ("#2", "modeOfOperation", "xx", False),
         ("#3", "lengthFormatIdentifier", "xx", False),
         ("#4--#m", "maxNumberOfBlockLength", "...", False),
         ("#(m+1)", "dataFormatIdentifier", "xx", False),
         ("#(m+2)--#N", "fileSizeOrDirInfoParameterLength", "...", False)],
    ),
    # ---- ReadMemoryByAddress (§10.3) ----
    0x23: (
        [("#1", "Service ID (SID)", "23", True),
         ("#2", "addressAndLengthFormatIdentifier", "xx", False),
         ("#3--#m", "memoryAddress[]", "...", False),
         ("#(m+1)--#n", "memorySize[]", "...", False)],
        [("#1", "Response SID", "63", True),
         ("#2--#N", "dataRecord[]", "...", False)],
    ),
    # ---- InputOutputControlByIdentifier (§12.2) ----
    0x2F: (
        [("#1", "Service ID (SID)", "2F", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4", "controlOptionRecord = controlEnableMaskRecord", "xx", False),
         ("#5--#N", "controlEnableMaskRecord[]", "...", False)],
        [("#1", "Response SID", "6F", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4", "controlOptionRecord", "xx", False),
         ("#5--#N", "controlStatusRecord[]", "...", False)],
    ),
    # ---- ReadDataByPeriodicIdentifier (§10.5) ----
    0x2A: (
        [("#1", "Service ID (SID)", "2A", True),
         ("#2", "transmissionMode", "xx", False),
         ("#3--#N", "periodicDataIdentifier[]", "...", False)],
        [("#1", "Response SID", "6A", True),
         ("#2--#N", "periodicDataIdentifier + dataRecord", "...", False)],
    ),
    # ---- WriteMemoryByAddress (§10.8) ----
    0x3D: (
        [("#1", "Service ID (SID)", "3D", True),
         ("#2", "addressAndLengthFormatIdentifier", "xx", False),
         ("#3--#m", "memoryAddress[]", "...", False),
         ("#(m+1)--#n", "memorySize[]", "...", False),
         ("#(n+1)--#N", "dataRecord[]", "...", False)],
        [("#1", "Response SID", "7D", True),
         ("#2", "addressAndLengthFormatIdentifier", "xx", False),
         ("#3--#m", "memoryAddress[]", "...", False),
         ("#(m+1)--#n", "memorySize[]", "...", False)],
    ),
    # ---- RequestUpload (§13.3) ----
    0x35: (
        [("#1", "Service ID (SID)", "35", True),
         ("#2", "dataFormatIdentifier", "xx", False),
         ("#3", "addressAndLengthFormatIdentifier", "xx", False),
         ("#4--#m", "memoryAddress[]", "...", False),
         ("#(m+1)--#n", "memorySize[]", "...", False)],
        [("#1", "Response SID", "75", True),
         ("#2", "lengthFormatIdentifier", "xx", False),
         ("#3--#N", "maxNumberOfBlockLength", "...", False)],
    ),
    # ---- ReadScalingDataByIdentifier (§10.4) ----
    0x24: (
        [("#1", "Service ID (SID)", "24", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False)],
        [("#1", "Response SID", "64", True),
         ("#2--#3", "dataIdentifier[]", "xx xx", False),
         ("#4--#N", "scalingData (formulaIdentifier + scalingExtension)", "...", False)],
    ),
    # ---- DynamicallyDefineDataIdentifier (§10.6) ----
    0x2C: (
        [("#1", "Service ID (SID)", "2C", True),
         ("#2", "sub-function = definitionType", "xx", False),
         ("#3--#4", "dynamicallyDefinedDataIdentifier[]", "xx xx", False),
         ("#5--#N", "sourceDataIdentifier / memoryAddress / memorySize (definition-type dependent)", "...", False)],
        [("#1", "Response SID", "6C", True),
         ("#2", "sub-function = definitionType", "xx", False),
         ("#3--#4", "dynamicallyDefinedDataIdentifier[]", "xx xx", False)],
    ),
    # ---- SecuredDataTransmission (§14.2) ----
    0x84: (
        [("#1", "Service ID (SID)", "84", True),
         ("#2--#N", "securityDataRequestRecord[]", "...", False)],
        [("#1", "Response SID", "C4", True),
         ("#2--#N", "securityDataResponseRecord[]", "...", False)],
    ),
    # ---- LinkControl (§9.10) ----
    0x87: (
        [("#1", "Service ID (SID)", "87", True),
         ("#2", "sub-function = linkControlType", "xx", False),
         ("#3--#N", "linkBaudrateRecord[] (sub-function dependent)", "...", False)],
        [("#1", "Response SID", "C7", True),
         ("#2", "sub-function = linkControlType", "xx", False)],
    ),
}


@dataclass
class DtcExtendedDataRecord:
    """Extended data record associated with a DTC."""

    record_number: int
    short_name: str = ""
    data_size: int = 0  # bytes

    @property
    def record_number_hex(self) -> str:
        return f"0x{self.record_number:02X}"


@dataclass
class DtcSnapshotRecord:
    """Snapshot (freeze-frame) record associated with a DTC."""

    record_number: int
    short_name: str = ""
    dids: list[int] = field(default_factory=list)  # DID IDs captured in snapshot

    @property
    def record_number_hex(self) -> str:
        return f"0x{self.record_number:02X}"


@dataclass
class DtcDefinition:
    """DTC (Diagnostic Trouble Code) definition."""

    short_name: str
    dtc_id: int
    functional_unit: str = ""
    severity: str = ""
    description: str = ""
    extended_data_records: list[DtcExtendedDataRecord] = field(default_factory=list)
    snapshot_records: list[DtcSnapshotRecord] = field(default_factory=list)
    manufacturer_severity: str = ""  # DcmDspDtcManufacturerSeverity
    aging_cycle_counter_threshold: int = 0  # DcmDspDtcAgingCycleCounterThreshold
    aging_allowed: bool = True  # DcmDspDtcAgingAllowed
    priority: int = 0  # DcmDspDtcPriority
    dtc_kind: str = ""  # DcmDspDtcKind (EMISSION / NON_EMISSION)
    immediate_nv_storage: bool = False  # DcmDspDtcImmediateNvStorage
    occurrence_counter_processing: str = ""  # DcmDspDtcOccurrenceCounterProcessing

    @property
    def dtc_id_hex(self) -> str:
        return f"0x{self.dtc_id:06X}"


@dataclass
class MemoryRange:
    """Memory address range for ReadMemoryByAddress / WriteMemoryByAddress."""

    short_name: str
    start_address: int = 0
    end_address: int = 0
    read_access: bool = False
    write_access: bool = False
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    addressing_mode: str = ""  # DcmDspMemoryRangeAddressingMode
    memory_range_length: int = 0  # DcmDspMemoryRangeLength
    memory_id_value: int = 0  # DcmDspMemoryIdValue

    @property
    def start_address_hex(self) -> str:
        return f"0x{self.start_address:08X}"

    @property
    def end_address_hex(self) -> str:
        return f"0x{self.end_address:08X}"


@dataclass
class IoControlDid:
    """IO Control By Identifier DID definition."""

    short_name: str
    did_id: int
    control_mask_size: int = 0  # bits
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    return_control_to_ecu: bool = True
    reset_to_default: bool = False
    freeze_current_state: bool = False
    short_term_adjustment: bool = False
    control_option_record_size: int = 0  # DcmDspDidControlOptionRecordSize
    support_on_physical: bool = True  # DcmDspDidControlSupportOnPhysicalRequest
    support_on_functional: bool = False  # DcmDspDidControlSupportOnFunctionalRequest

    @property
    def did_id_hex(self) -> str:
        return f"0x{self.did_id:04X}"


@dataclass
class PeriodicDid:
    """Periodic Data Identifier definition."""

    short_name: str
    did_id: int
    transmission_mode: str = ""  # slowRate, mediumRate, fastRate
    supported_sessions: list[str] = field(default_factory=list)
    update_period: float = 0.0  # DcmDspPeriodicDidUpdatePeriod (ms)
    required_security_levels: list[str] = field(default_factory=list)

    @property
    def did_id_hex(self) -> str:
        return f"0x{self.did_id:04X}"


@dataclass
class ComControlSubNode:
    """Communication Control sub-node definition."""

    short_name: str
    communication_type: int = 0  # bitmask: bit0=normal, bit1=nm
    subnet_number: int = 0

    @property
    def communication_type_hex(self) -> str:
        return f"0x{self.communication_type:02X}"


@dataclass
class ComControlConfig:
    """CommunicationControl (0x28) configuration."""

    sub_nodes: list[ComControlSubNode] = field(default_factory=list)
    supported_sessions: list[str] = field(default_factory=list)
    suppressor_rx_using_mask: bool = False  # DcmDspComControlSuppressorRxUsingMask


@dataclass
class ResponseOnEventConfig:
    """ResponseOnEvent (0x86) configuration."""

    short_name: str = ""
    event_window_time: int = 0  # seconds
    store_event: bool = False
    service_to_respond_to: int = 0  # SID to trigger
    supported_sessions: list[str] = field(default_factory=list)
    event_type: str = ""  # onDTCStatusChange, onTimerInterrupt, etc.
    max_event_map_range_identifier: int = 0  # DcmDspRoeMaxEventMapRangeIdentifier
    transmission_mode: str = ""  # DcmDspRoeTransmissionMode

    @property
    def service_to_respond_to_hex(self) -> str:
        return f"0x{self.service_to_respond_to:02X}"


@dataclass
class RequestFileTransferConfig:
    """RequestFileTransfer (0x38) configuration."""

    short_name: str = ""
    max_file_path_length: int = 0
    max_file_size: int = 0
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    format_identifier: int = 0  # DcmDspRequestFileTransferFormatIdentifier
    data_block_size: int = 0  # DcmDspRequestFileTransferDataBlockSize
    address_length: int = 0  # DcmDspRequestFileTransferAddressLength
    length_length: int = 0  # DcmDspRequestFileTransferLengthLength


@dataclass
class ClearDtcNotification:
    """ClearDiagnosticInformation (0x14) notification configuration."""

    short_name: str = ""
    notification_class: str = ""  # e.g., DcmDspClearDTCNotificationClass


@dataclass
class DidRange:
    """DID range definition (consecutive DID block)."""

    short_name: str
    lower_did: int
    upper_did: int
    read_access: bool = True
    write_access: bool = False
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)
    has_gaps: bool = True  # DcmDspDidRangeHasGaps
    data_length: int = 0  # DcmDspDidRangeDataLength

    @property
    def lower_did_hex(self) -> str:
        return f"0x{self.lower_did:04X}"

    @property
    def upper_did_hex(self) -> str:
        return f"0x{self.upper_did:04X}"


@dataclass
class CanTpChannel:
    """CAN Transport Protocol channel configuration (ISO 15765)."""

    short_name: str
    rx_pdu_id: str = ""
    tx_pdu_id: str = ""
    rx_addressing_format: str = "STANDARD"  # STANDARD, EXTENDED, MIXED
    tx_addressing_format: str = "STANDARD"
    bs: int = 0  # Block Size
    stmin: float = 0.0  # Separation Time minimum (ms)
    n_as: float = 0.0  # N_As timeout (s)
    n_bs: float = 0.0  # N_Bs timeout (s)
    n_cs: float = 0.0  # N_Cs timeout (s)
    n_ar: float = 0.0  # N_Ar timeout (s)
    n_br: float = 0.0  # N_Br timeout (s)
    n_cr: float = 0.0  # N_Cr timeout (s)
    padding_activation: bool = True
    padding_byte: int = 0xFF
    channel_mode: str = "FULL_DUPLEX"  # FULL_DUPLEX, HALF_DUPLEX
    max_data_length: int = 8  # 8 for classic CAN, 64 for CAN FD
    rx_ta_type: str = ""  # PHYSICAL, FUNCTIONAL
    tx_ta_type: str = ""  # PHYSICAL, FUNCTIONAL
    rx_nsa: int = 0  # Network Source Address
    rx_nta: int = 0  # Network Target Address
    tx_nsa: int = 0  # Tx Network Source Address
    tx_nta: int = 0  # Tx Network Target Address
    rx_fc_dl: int = 0  # CanTpRxFcDl (CAN-FD FC frame data length)
    tx_fc_dl: int = 0  # CanTpTxFcDl (CAN-FD FC frame data length)

    @property
    def padding_byte_hex(self) -> str:
        return f"0x{self.padding_byte:02X}"


@dataclass
class CanTpConfig:
    """CAN Transport Protocol configuration parsed from CanTp ARXML."""

    channels: list[CanTpChannel] = field(default_factory=list)
    main_function_period: float = 0.005  # seconds
    can_fd_enabled: bool = False  # CanTpCanFdEnabled
    wft_max: int = 0  # CanTpWftMax
    change_parm_api: bool = False  # CanTpChangeParmApi
    tc: bool = False  # CanTpTc (transmit cancellation)
    dev_error_detect: bool = False  # CanTpDevErrorDetect
    version_info_api: bool = False  # CanTpVersionInfoApi
    padding_byte: int = 0xFF  # CanTpPaddingByte (global default)


@dataclass
class DslConnection:
    """DSL connection (client endpoint) configuration."""

    short_name: str
    rx_pdu_id: str = ""
    tx_pdu_id: str = ""
    rx_addr: str = ""  # DcmDslConnectionRxAddr / Rx CAN ID
    tx_addr: str = ""  # DcmDslConnectionTxAddr / Tx CAN ID
    connection_mode: str = ""  # DcmDslConnectionMode (TYPE1 / TYPE2)
    end_of_connection_type: str = ""  # DcmDslConnectionDcmEndOfConnectionType
    periodic_tx_pdu_id: str = ""  # DcmDslPeriodicConnection Tx PDU
    roe_tx_pdu_id: str = ""  # DcmDslROEConnection Tx PDU


@dataclass
class ProtocolRow:
    """DcmDslProtocolRow — one protocol/client configuration."""

    short_name: str
    protocol_type: str = ""  # DCM_UDS_ON_CAN, etc.
    priority: int = 0  # DcmDslProtocolPriority (lower = higher priority)
    preempt_timeout: float = 0.0  # DcmDslProtocolPreemptTimeout (s)
    trans_type: str = ""  # DcmDslProtocolTransType (TYPE1 / TYPE2)
    max_response_length: int = 0  # DcmDslProtocolMaximumResponseLength
    connections: list[DslConnection] = field(default_factory=list)


@dataclass
class AuthenticationConfig:
    """Authentication service (0x29) configuration — ISO 14229-1:2020 §9.6."""

    short_name: str = ""
    role: str = ""  # DcmDspAuthenticationRole
    white_list: list[str] = field(default_factory=list)  # DcmDspAuthenticationWhiteList services
    certificate_id: str = ""  # DcmDspAuthenticationCertificateId
    psk_identity: str = ""  # DcmDspAuthenticationPSKIdentity
    num_max_attempts: int = 0  # DcmDspAuthenticationNumMaxAuthAttempts
    delay_time: float = 0.0  # DcmDspAuthenticationDelayTime (s)
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)


@dataclass
class AccessTimingRow:
    """Access Timing Parameter row — ISO 14229-2 / DcmDspTimingRow."""

    short_name: str
    p2_server_max: float = 0.05  # DcmDspTimingP2ServerMax (s)
    p2_star_server_max: float = 5.0  # DcmDspTimingP2StarServerMax (s)
    s3_server: float = 5.0  # DcmDspTimingS3Server (s)
    timing_type: str = ""  # DEFAULT, CURRENT, LIMIT


@dataclass
class UdsSpecification:
    """Complete UDS specification extracted from ARXML."""

    ecu_name: str = "ECU"
    description: str = ""
    sessions: list[DiagSession] = field(default_factory=list)
    security_levels: list[SecurityLevel] = field(default_factory=list)
    services: list[UdsService] = field(default_factory=list)
    dids: list[Did] = field(default_factory=list)
    routines: list[Routine] = field(default_factory=list)
    dtcs: list[DtcDefinition] = field(default_factory=list)
    memory_ranges: list[MemoryRange] = field(default_factory=list)
    io_control_dids: list[IoControlDid] = field(default_factory=list)
    periodic_dids: list[PeriodicDid] = field(default_factory=list)
    did_ranges: list[DidRange] = field(default_factory=list)
    com_control: Optional[ComControlConfig] = None
    response_on_event: list[ResponseOnEventConfig] = field(default_factory=list)
    dtc_status_availability_mask: int = 0xFF  # DcmDspDtcStatusAvailabilityMask
    max_num_resp_pend: int = 0  # DcmDslDiagRespMaxNumRespPend
    max_response_length: int = 0  # DcmDslProtocolMaximumResponseLength
    request_file_transfer: list[RequestFileTransferConfig] = field(default_factory=list)
    clear_dtc_notifications: list[ClearDtcNotification] = field(default_factory=list)
    protocol_name: str = "UDS on CAN"
    protocol_type: str = ""  # raw value from DcmDslProtocolType
    can_rx_id: str = ""
    can_tx_id: str = ""
    can_functional_id: str = ""
    s3_server: float = 5.0  # seconds – ISO 14229-2 S3Server timeout
    dsl_rx_buffer_size: int = 0
    dsl_tx_buffer_size: int = 0
    transport_config: Optional[CanTpConfig] = None
    connection_mode: str = ""  # DcmDslConnectionMode (ON_BOARD / OFF_BOARD)
    connection_end_of_type: str = ""  # DcmDslConnectionDcmEndOfConnectionType
    cdtc_status_mask: int = 0  # DcmDspCDTCStatusMask
    clear_dtc_group: int = 0xFFFFFF  # DcmDspClearDTCGroup
    module_main_function_period: float = 0.0  # DcmModuleMainFunctionPeriod
    enable_fim_trigger: bool = False  # DcmEnableFimTrigger
    dynamic_dids: list["DynamicDidDefinition"] = field(default_factory=list)
    protocol_priority: int = 0  # DcmDslProtocolPriority
    protocol_trans_type: str = ""  # DcmDslProtocolTransType
    protocol_preempt_timeout: float = 0.0  # DcmDslProtocolPreemptTimeout
    periodic_slow_rate: float = 0.0  # DcmDslPeriodicTransmissionSlowRate
    periodic_medium_rate: float = 0.0  # DcmDslPeriodicTransmissionMediumRate
    periodic_fast_rate: float = 0.0  # DcmDslPeriodicTransmissionFastRate
    memory_compression_method: str = ""  # DcmDspMemoryCompressionMethod
    memory_encrypting_method: str = ""  # DcmDspMemoryEncryptingMethod
    dev_error_detect: bool = False  # DcmDevErrorDetect
    version_info_api: bool = False  # DcmVersionInfoApi
    task_time: float = 0.0  # DcmTaskTime
    respond_all_request: bool = True  # DcmRespondAllRequest
    # Multi-Client / Multi-Protocol (ISO 14229-1 Annex D)
    protocol_rows: list["ProtocolRow"] = field(default_factory=list)
    # Authentication (ISO 14229-1:2020 §9.6)
    authentication_config: Optional["AuthenticationConfig"] = None
    # Access Timing Parameters (ISO 14229-2)
    access_timing_rows: list["AccessTimingRow"] = field(default_factory=list)
    # DEM (Diagnostic Event Manager) configuration
    dem_general: Optional["DemGeneralConfig"] = None
    dem_operation_cycles: list["DemOperationCycle"] = field(default_factory=list)
    dem_event_parameters: list["DemEventParameter"] = field(default_factory=list)
    dem_indicators: list["DemIndicatorConfig"] = field(default_factory=list)
    dem_enable_conditions: list["DemEnableCondition"] = field(default_factory=list)
    dem_storage_conditions: list["DemStorageCondition"] = field(default_factory=list)
    dem_event_memories: list["DemEventMemoryConfig"] = field(default_factory=list)


@dataclass
class DynamicDidDefinition:
    """DynamicallyDefineDataIdentifier (0x2C) definition."""

    short_name: str
    did_id: int = 0
    max_number_of_source_elements: int = 0
    supported_sessions: list[str] = field(default_factory=list)
    required_security_levels: list[str] = field(default_factory=list)

    @property
    def did_id_hex(self) -> str:
        return f"0x{self.did_id:04X}"


# ---- DEM (Diagnostic Event Manager) models ----


@dataclass
class DemOperationCycle:
    """DEM operation cycle definition (DemOperationCycle container)."""

    short_name: str
    cycle_id: int = 0
    cycle_type: str = ""  # DEM_OPCYC_IGNITION, DEM_OPCYC_POWER, etc.
    autostart: bool = False  # DemOperationCycleAutostart


@dataclass
class DemDebounceConfig:
    """DEM debounce algorithm configuration for an event."""

    algorithm: str = ""  # COUNTER_BASED, TIME_BASED, MONITOR_INTERNAL
    counter_failed_threshold: int = 127  # DemDebounceCounterFailedThreshold
    counter_passed_threshold: int = -128  # DemDebounceCounterPassedThreshold
    counter_increment_step: int = 1  # DemDebounceCounterIncrementStepSize
    counter_decrement_step: int = 1  # DemDebounceCounterDecrementStepSize
    counter_jump_up: bool = False  # DemDebounceCounterJumpUp
    counter_jump_down: bool = False  # DemDebounceCounterJumpDown
    counter_storage: bool = False  # DemDebounceCounterStorage
    time_failed_threshold: float = 0.0  # DemDebounceTimeFailedThreshold (s)
    time_passed_threshold: float = 0.0  # DemDebounceTimePassedThreshold (s)


@dataclass
class DemIndicatorConfig:
    """DEM indicator (e.g. MIL/warning lamp) configuration."""

    short_name: str
    indicator_id: int = 0  # DemIndicatorId
    behaviour: str = ""  # BLINKING, CONTINUOUS, SHORT_BUT_SLOW_FLASHING, etc.
    failure_cycle_counter_threshold: int = 0  # DemIndicatorFailureCycleCounterThreshold
    healing_cycle_counter_threshold: int = 0  # DemIndicatorHealingCycleCounterThreshold


@dataclass
class DemEnableCondition:
    """DEM enable condition definition."""

    short_name: str
    condition_id: int = 0  # DemEnableConditionId
    initial_status: bool = True  # DemEnableConditionStatus


@dataclass
class DemStorageCondition:
    """DEM storage condition definition."""

    short_name: str
    condition_id: int = 0  # DemStorageConditionId
    initial_status: bool = True  # DemStorageConditionStatus
    replacement_event_ref: str = ""  # DemStorageConditionReplacementEventRef


@dataclass
class DemEventMemoryConfig:
    """DEM event memory configuration (DemPrimaryMemory / DemUserDefinedMemory)."""

    short_name: str = "Primary"
    memory_type: str = "PRIMARY"  # PRIMARY, USER_DEFINED, MIRROR, PERMANENT
    max_number_event_entries: int = 0  # DemMaxNumberEventEntryPrimary etc.
    displacement_strategy: str = ""  # DEM_DISPLACEMENT_NONE / FULL / PRIO_OCC
    occurrence_counter_processing: str = ""  # DEM_PROCESS_OCCCTR_TF / CDTC
    event_memory_entry_storage_trigger: str = ""  # DEM_TRIGGER_ON_*
    freeze_frame_record_trigger: str = ""  # DEM_TRIGGER_ON_*
    extended_data_record_trigger: str = ""  # DEM_TRIGGER_ON_*
    type_of_freeze_frame_record_numeration: str = ""  # CALCULATED / CONFIGURED
    max_number_freeze_frame_records: int = 0  # DemMaxNumberFreezeFrameRecords


@dataclass
class DemEventParameter:
    """DEM event parameter — links an event to its DTC and configuration."""

    short_name: str
    event_id: int = 0  # DemEventId
    event_kind: str = ""  # DEM_EVENT_KIND_SWC / BSW
    confirmation_threshold: int = 1  # DemEventConfirmationThreshold
    operation_cycle_ref: str = ""  # DemOperationCycleRef (short name)
    enable_condition_group_ref: str = ""  # DemEnableConditionGroupRef
    storage_condition_group_ref: str = ""  # DemStorageConditionGroupRef
    dtc_ref: str = ""  # DemDTCRef (short name of DemDTC)
    debounce: Optional[DemDebounceConfig] = None
    indicator_refs: list[str] = field(default_factory=list)  # DemIndicatorRef names
    recoverable_in_same_cycle: bool = True  # DemEventRecoverableInSameOperationCycle
    report_behavior: str = ""  # REPORT_BEFORE_INIT / REPORT_AFTER_INIT
    ff_prestorage_supported: bool = False  # DemFFPrestorageSupported


@dataclass
class DemGeneralConfig:
    """DEM general configuration (DemGeneral container)."""

    status_bit_storage_test_failed: bool = True  # DemStatusBitStorageTestFailed
    status_bit_handling_tfslc: str = ""  # DemStatusBitHandlingTestFailedSinceLastClear
    reset_confirmed_bit_on_overflow: bool = True  # DemResetConfirmedBitOnOverflow
    operation_cycle_status_storage: bool = False  # DemOperationCycleStatusStorage
    suppression_support: bool = False  # DemSuppressionSupport
    availability_support: bool = False  # DemAvailabilitySupport
    trigger_fim_reports: bool = False  # DemTriggerFiMReports
    type_of_dtc_supported: str = ""  # DemTypeOfDTCSupported
    clear_dtc_limitation: str = ""  # DemClearDTCLimitation
