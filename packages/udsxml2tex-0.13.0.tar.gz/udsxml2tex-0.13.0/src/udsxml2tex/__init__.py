"""udsxml2tex - Convert AUTOSAR DCM/CanTp arxml to LaTeX UDS specification documents."""

__version__ = "0.13.0"

from udsxml2tex.cantp_parser import CanTpParser
from udsxml2tex.config import GenerationConfig
from udsxml2tex.generator import TexGenerator
from udsxml2tex.interactive import InteractiveSession
from udsxml2tex.models import (
    AccessTimingRow,
    AuthenticationConfig,
    CanTpChannel,
    CanTpConfig,
    DataElement,
    DemDebounceConfig,
    DemEnableCondition,
    DemEventMemoryConfig,
    DemEventParameter,
    DemGeneralConfig,
    DemIndicatorConfig,
    DemOperationCycle,
    DemStorageCondition,
    DiagSession,
    Did,
    DslConnection,
    NrcEntry,
    ProtocolRow,
    Routine,
    RoutineParameter,
    SecurityLevel,
    SubFunction,
    UdsService,
    UdsSpecification,
)
from udsxml2tex.parser import ArxmlParser, ArxmlValidationError, ArxmlValidationWarning

__all__ = [
    "AccessTimingRow",
    "ArxmlParser",
    "ArxmlValidationError",
    "ArxmlValidationWarning",
    "AuthenticationConfig",
    "CanTpParser",
    "DemDebounceConfig",
    "DemEnableCondition",
    "DemEventMemoryConfig",
    "DemEventParameter",
    "DemGeneralConfig",
    "DemIndicatorConfig",
    "DemOperationCycle",
    "DemStorageCondition",
    "DslConnection",
    "GenerationConfig",
    "InteractiveSession",
    "ProtocolRow",
    "TexGenerator",
    "UdsSpecification",
    "UdsService",
    "DiagSession",
    "SecurityLevel",
    "Did",
    "DataElement",
    "Routine",
    "RoutineParameter",
    "SubFunction",
    "NrcEntry",
    "CanTpChannel",
    "CanTpConfig",
]
