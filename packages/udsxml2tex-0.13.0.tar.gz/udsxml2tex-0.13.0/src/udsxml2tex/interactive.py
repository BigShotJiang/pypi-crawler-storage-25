"""Interactive mode for udsxml2tex."""

from __future__ import annotations

import logging
import os
import re
import shutil
import sys
from pathlib import Path
from typing import Optional

from udsxml2tex.config import GenerationConfig
from udsxml2tex.generator import TexGenerator
from udsxml2tex.models import UDS_SERVICE_NAMES, UdsSpecification
from udsxml2tex.parser import ArxmlParser

logger = logging.getLogger(__name__)

# ANSI colour helpers (disabled when not a tty)
_USE_COLOR = hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def _bold(text: str) -> str:
    return f"\033[1m{text}\033[0m" if _USE_COLOR else text


def _cyan(text: str) -> str:
    return f"\033[36m{text}\033[0m" if _USE_COLOR else text


def _green(text: str) -> str:
    return f"\033[32m{text}\033[0m" if _USE_COLOR else text


def _yellow(text: str) -> str:
    return f"\033[33m{text}\033[0m" if _USE_COLOR else text


def _prompt(msg: str, default: str = "") -> str:
    """Show a prompt and return user input (stripped)."""
    suffix = f" [{default}]" if default else ""
    try:
        ans = input(f"{_cyan('>')} {msg}{suffix}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        sys.exit(130)
    return ans if ans else default


def _prompt_yes_no(msg: str, default: bool = True) -> bool:
    hint = "Y/n" if default else "y/N"
    ans = _prompt(f"{msg} ({hint})")
    if not ans:
        return default
    return ans.lower().startswith("y")


def _prompt_choice(msg: str, choices: list[str], default: str = "") -> str:
    """Let the user pick one option from a numbered list."""
    print(f"\n{_bold(msg)}")
    for i, c in enumerate(choices, 1):
        marker = " *" if c == default else ""
        print(f"  {i}. {c}{marker}")
    while True:
        ans = _prompt("番号を入力してください", default=str(choices.index(default) + 1) if default in choices else "1")
        try:
            idx = int(ans) - 1
            if 0 <= idx < len(choices):
                return choices[idx]
        except ValueError:
            pass
        print("  無効な入力です。もう一度入力してください。")


def _prompt_multi_choice(msg: str, items: list[tuple[str, str]], default_all: bool = True) -> list[str]:
    """Let the user pick multiple items. Returns list of keys.

    items: list of (key, display_label)
    """
    print(f"\n{_bold(msg)}")
    for i, (key, label) in enumerate(items, 1):
        print(f"  {i}. {label}")
    hint = "全て" if default_all else "なし"
    print(f"  番号をカンマ区切りで入力 (例: 1,3,5)。'all'で全選択、'none'で全解除 [デフォルト: {hint}]")
    ans = _prompt("選択").lower()
    if not ans:
        return [k for k, _ in items] if default_all else []
    if ans in ("all", "a", "全て"):
        return [k for k, _ in items]
    if ans in ("none", "n", "なし"):
        return []
    selected = []
    for part in ans.split(","):
        part = part.strip()
        try:
            idx = int(part) - 1
            if 0 <= idx < len(items):
                selected.append(items[idx][0])
        except ValueError:
            pass
    return selected


def _prompt_file_path(msg: str, must_exist: bool = True, suffix: str = "") -> str:
    """Prompt for a file path with validation."""
    while True:
        path_str = _prompt(msg)
        if not path_str:
            return ""
        p = Path(path_str).expanduser().resolve()
        if must_exist and not p.exists():
            print(f"  ファイルが見つかりません: {p}")
            continue
        if suffix and not p.name.endswith(suffix):
            print(f"  警告: ファイルの拡張子が {suffix} ではありません")
        return str(p)


def _extract_nrc22_from_source(source_path: str) -> str:
    """Attempt to extract NRC 0x22 condition descriptions from C source code.

    Looks for patterns like:
      - if (...) { /* conditionsNotCorrect */ Dcm_SetNegResponse(0x22); }
      - Comments near NRC 0x22 / conditionsNotCorrect
    Returns a summary string.
    """
    p = Path(source_path)
    if not p.exists():
        return f"(ソースファイルが見つかりません: {source_path})"
    try:
        content = p.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return f"(ソースファイルの読み取りに失敗: {source_path})"

    # Heuristic: find lines referencing NRC 0x22 or conditionsNotCorrect
    patterns = [
        re.compile(r".*(?:0x22|conditionsNotCorrect|CONDITIONS_NOT_CORRECT).*", re.IGNORECASE),
    ]
    relevant_lines: list[str] = []
    lines = content.splitlines()
    for i, line in enumerate(lines):
        for pat in patterns:
            if pat.match(line):
                # Grab surrounding context (2 lines before/after)
                start = max(0, i - 2)
                end = min(len(lines), i + 3)
                snippet = "\n".join(lines[start:end])
                relevant_lines.append(snippet)
                break

    if not relevant_lines:
        return f"NRC 0x22 の条件: (ソースコード {p.name} に該当パターンが見つかりませんでした)"

    # Build summary
    parts = [f"NRC 0x22 の条件 (ソースコード {p.name} より抽出):"]
    for i, snippet in enumerate(relevant_lines[:5], 1):  # limit to 5 matches
        parts.append(f"  [{i}] {snippet.strip()}")
    return "\n".join(parts)


class InteractiveSession:
    """Runs the interactive Q&A flow to generate a UDS spec document."""

    def __init__(self) -> None:
        self.config = GenerationConfig()
        self._spec: Optional[UdsSpecification] = None

    def run(self) -> int:
        """Execute the full interactive flow. Returns exit code."""
        self._print_banner()

        # Step 1: ARXML type selection
        self._ask_arxml_type()

        # Step 2: File paths
        self._ask_file_paths()

        # Step 3: Parse ARXML
        if not self._parse_arxml():
            return 1

        assert self._spec is not None

        # Step 4: ECU name
        self._ask_ecu_name()

        # Step 5: Select items to include
        self._ask_include_services()
        self._ask_include_dids()
        self._ask_include_routines()
        self._ask_include_sessions()
        self._ask_timing_params()

        # Step 6: NRC 0x22 details
        self._ask_nrc22_details()

        # Step 7: CLS file
        self._ask_cls_file()

        # Step 8: Output settings
        self._ask_output()

        # Step 9: Save config?
        self._ask_save_config()

        # Step 10: Generate
        return self._generate()

    # ---- Banner --------------------------------------------------------

    def _print_banner(self) -> None:
        print()
        print(_bold("=" * 60))
        print(_bold("  udsxml2tex - インタラクションモード"))
        print(_bold("=" * 60))
        print("  対話形式で UDS 仕様書 (LaTeX) を生成します。")
        print("  Ctrl+C でいつでも中断できます。")
        print()

    # ---- Step 1: ARXML type -------------------------------------------

    def _ask_arxml_type(self) -> None:
        choices = ["DCM (診断サービス定義)", "CanTp (トランスポート層)", "両方 (DCM + CanTp)"]
        choice = _prompt_choice("インポートする ARXML の種類を選択してください:", choices, default=choices[0])
        if "DCM" in choice:
            self.config.arxml_type = "dcm"
        elif "CanTp" in choice:
            self.config.arxml_type = "cantp"
        else:
            self.config.arxml_type = "both"

    # ---- Step 2: File paths -------------------------------------------

    def _ask_file_paths(self) -> None:
        if self.config.arxml_type in ("dcm", "both"):
            self.config.dcm_arxml_path = _prompt_file_path(
                "DCM ARXML ファイルのパスを入力してください", suffix=".arxml"
            )
        if self.config.arxml_type in ("cantp", "both"):
            self.config.cantp_arxml_path = _prompt_file_path(
                "CanTp ARXML ファイルのパスを入力してください", suffix=".arxml"
            )

    # ---- Step 3: Parse -------------------------------------------------

    def _parse_arxml(self) -> bool:
        arxml_parser = ArxmlParser()
        paths: list[Path] = []
        if self.config.dcm_arxml_path:
            paths.append(Path(self.config.dcm_arxml_path))
        if self.config.cantp_arxml_path:
            paths.append(Path(self.config.cantp_arxml_path))

        if not paths:
            print(_yellow("  ARXML ファイルが指定されていません。"))
            return False

        try:
            print(f"\n{_bold('ARXML を読み込み中...')}")
            if len(paths) == 1:
                self._spec = arxml_parser.parse(paths[0])
            else:
                self._spec = arxml_parser.parse_multi(paths)
            print(_green(f"  読み込み完了: "
                         f"{len(self._spec.services)} サービス, "
                         f"{len(self._spec.dids)} DID, "
                         f"{len(self._spec.routines)} ルーチン, "
                         f"{len(self._spec.sessions)} セッション"))
        except Exception as e:
            logger.error("ARXML 解析に失敗しました: %s", e)
            print(f"  エラー: {e}")
            return False
        return True

    # ---- Step 4: ECU name ----------------------------------------------

    def _ask_ecu_name(self) -> None:
        assert self._spec is not None
        current = self._spec.ecu_name or "ECU"
        name = _prompt(f"ECU 名を入力してください", default=current)
        self.config.ecu_name = name
        self._spec.ecu_name = name

    # ---- Step 5a: Services (SID) selection -----------------------------

    def _ask_include_services(self) -> None:
        assert self._spec is not None
        if not self._spec.services:
            return
        items = []
        for svc in sorted(self._spec.services, key=lambda s: s.service_id):
            label = f"0x{svc.service_id:02X} - {UDS_SERVICE_NAMES.get(svc.service_id, svc.short_name)}"
            items.append((str(svc.service_id), label))
        selected = _prompt_multi_choice(
            "仕様書に含める SID (サービス) を選択してください:", items, default_all=True
        )
        self.config.include_services = [int(s) for s in selected]

    # ---- Step 5b: DIDs selection ---------------------------------------

    def _ask_include_dids(self) -> None:
        assert self._spec is not None
        if not self._spec.dids:
            return
        items = []
        for did in sorted(self._spec.dids, key=lambda d: d.did_id):
            label = f"0x{did.did_id:04X} - {did.short_name}"
            items.append((str(did.did_id), label))
        selected = _prompt_multi_choice(
            "仕様書に含める DID を選択してください:", items, default_all=True
        )
        self.config.include_dids = [int(s) for s in selected]

    # ---- Step 5c: Routines selection -----------------------------------

    def _ask_include_routines(self) -> None:
        assert self._spec is not None
        if not self._spec.routines:
            return
        items = []
        for rtn in sorted(self._spec.routines, key=lambda r: r.routine_id):
            label = f"0x{rtn.routine_id:04X} - {rtn.short_name}"
            items.append((str(rtn.routine_id), label))
        selected = _prompt_multi_choice(
            "仕様書に含めるルーチンを選択してください:", items, default_all=True
        )
        self.config.include_routines = [int(s) for s in selected]

    # ---- Step 5d: Sessions selection -----------------------------------

    def _ask_include_sessions(self) -> None:
        assert self._spec is not None
        if not self._spec.sessions:
            return
        items = []
        for sess in sorted(self._spec.sessions, key=lambda s: s.session_id):
            label = f"0x{sess.session_id:02X} - {sess.short_name}"
            items.append((sess.short_name, label))
        selected = _prompt_multi_choice(
            "仕様書に含めるセッションを選択してください:", items, default_all=True
        )
        self.config.include_sessions = selected

    # ---- Step 5e: Timing parameters ------------------------------------

    def _ask_timing_params(self) -> None:
        self.config.include_timing_params = _prompt_yes_no(
            "セッションタイミングパラメータ (P2, P2*) を含めますか？"
        )
        if self._spec and self._spec.transport_config:
            self.config.include_cantp_timing = _prompt_yes_no(
                "CanTp タイミングパラメータ (N_As, N_Bs 等) を含めますか？"
            )

    # ---- Step 6: NRC 0x22 details --------------------------------------

    def _ask_nrc22_details(self) -> None:
        assert self._spec is not None
        # Find services that have NRC 0x22 in their NRC list
        nrc22_services = []
        for svc in self._spec.services:
            if svc.service_id not in self.config.include_services:
                continue
            has_nrc22 = any(n.nrc_code == 0x22 for n in svc.nrc_list)
            if has_nrc22:
                nrc22_services.append(svc)

        if not nrc22_services:
            return

        print(f"\n{_bold('NRC 0x22 (conditionsNotCorrect) の詳細設定')}")
        print("  以下のサービスは NRC 0x22 をサポートしています。")
        print("  各サービスについて条件の詳細を入力するか、")
        print("  実装ソースコードのパスを入力してください。\n")

        for svc in nrc22_services:
            svc_name = UDS_SERVICE_NAMES.get(svc.service_id, svc.short_name)
            print(f"  {_bold(f'0x{svc.service_id:02X} - {svc_name}')}")
            choices = [
                "スキップ (NRC 0x22 の詳細を記載しない)",
                "自由記入で条件を入力",
                "ソースコードのパスを指定して自動抽出",
            ]
            choice = _prompt_choice("NRC 0x22 の詳細をどのように記載しますか？:", choices, default=choices[0])
            if "自由記入" in choice:
                detail = _prompt("NRC 0x22 が返される条件を記述してください")
                if detail:
                    self.config.nrc22_details[str(svc.service_id)] = detail
            elif "ソースコード" in choice:
                src_path = _prompt_file_path("ソースコードファイルのパスを入力してください", must_exist=True)
                if src_path:
                    extracted = _extract_nrc22_from_source(src_path)
                    print(f"\n  {_green('抽出結果:')}")
                    for line in extracted.splitlines():
                        print(f"    {line}")
                    if _prompt_yes_no("この内容を採用しますか？"):
                        self.config.nrc22_details[str(svc.service_id)] = extracted
                    else:
                        detail = _prompt("代わりに自由記入で条件を入力してください")
                        if detail:
                            self.config.nrc22_details[str(svc.service_id)] = detail

    # ---- Step 7: CLS file ----------------------------------------------

    def _ask_cls_file(self) -> None:
        if _prompt_yes_no("デフォルトの udsspec.cls を使用しますか？"):
            self.config.cls_file_path = ""
        else:
            self.config.cls_file_path = _prompt_file_path(
                "カスタム cls ファイルのパスを入力してください", must_exist=True, suffix=".cls"
            )

    # ---- Step 8: Output path -------------------------------------------

    def _ask_output(self) -> None:
        default_name = ""
        if self.config.dcm_arxml_path:
            stem = Path(self.config.dcm_arxml_path).stem
            default_name = f"{stem}_uds_spec.tex"
        path = _prompt("出力 .tex ファイルのパスを入力してください", default=default_name)
        self.config.output_path = path
        # Template customisation
        if self.config.template_dir:
            tmpl = _prompt("テンプレートファイル名", default=self.config.template)
            self.config.template = tmpl

    # ---- Step 9: Save config -------------------------------------------

    def _ask_save_config(self) -> None:
        if _prompt_yes_no("この設定をコンフィグファイルに保存しますか？", default=False):
            default_cfg = "udsxml2tex_config.json"
            cfg_path = _prompt("保存先のパスを入力してください", default=default_cfg)
            try:
                self.config.save(cfg_path)
                print(_green(f"  設定を保存しました: {cfg_path}"))
            except Exception as e:
                print(f"  保存に失敗しました: {e}")

    # ---- Step 10: Generate ---------------------------------------------

    def _generate(self) -> int:
        assert self._spec is not None
        return generate_from_config(self.config, self._spec)


def apply_config_filter(spec: UdsSpecification, config: GenerationConfig) -> None:
    """Filter the specification data according to the configuration."""
    if config.include_services:
        spec.services = [s for s in spec.services if s.service_id in config.include_services]
    if config.include_dids:
        spec.dids = [d for d in spec.dids if d.did_id in config.include_dids]
    if config.include_routines:
        spec.routines = [r for r in spec.routines if r.routine_id in config.include_routines]
    if config.include_sessions:
        spec.sessions = [s for s in spec.sessions if s.short_name in config.include_sessions]

    # Inject NRC 0x22 details into service NRC entries
    for svc in spec.services:
        sid_key = str(svc.service_id)
        if sid_key in config.nrc22_details:
            detail = config.nrc22_details[sid_key]
            for nrc in svc.nrc_list:
                if nrc.nrc_code == 0x22:
                    nrc.description = detail

    # Remove timing parameters if not wanted
    if not config.include_timing_params:
        for sess in spec.sessions:
            sess.p2_server_max = 0.0
            sess.p2_star_server_max = 0.0
    if not config.include_cantp_timing and spec.transport_config:
        for ch in spec.transport_config.channels:
            ch.n_as = 0.0
            ch.n_bs = 0.0
            ch.n_cs = 0.0
            ch.n_ar = 0.0
            ch.n_br = 0.0
            ch.n_cr = 0.0


def generate_from_config(
    config: GenerationConfig,
    spec: Optional[UdsSpecification] = None,
) -> int:
    """Run generation using a config (from interactive session or config file).

    If *spec* is None the ARXML files referenced in *config* are parsed first.
    Returns exit code.
    """
    if spec is None:
        arxml_parser = ArxmlParser()
        paths: list[Path] = []
        if config.dcm_arxml_path:
            paths.append(Path(config.dcm_arxml_path))
        if config.cantp_arxml_path:
            paths.append(Path(config.cantp_arxml_path))
        if not paths:
            logging.error("ARXML ファイルが設定されていません。")
            return 1
        try:
            if len(paths) == 1:
                spec = arxml_parser.parse(paths[0])
            else:
                spec = arxml_parser.parse_multi(paths)
        except Exception as e:
            logging.error("ARXML 解析に失敗しました: %s", e)
            return 1

    # Apply ECU name override
    if config.ecu_name:
        spec.ecu_name = config.ecu_name

    # Apply filters
    apply_config_filter(spec, config)

    # Determine output path
    if config.output_path:
        output_path = Path(config.output_path)
    elif config.dcm_arxml_path:
        stem = Path(config.dcm_arxml_path).stem
        output_path = Path(f"{stem}_uds_spec.tex")
    else:
        output_path = Path("uds_spec.tex")

    # Generate
    try:
        template_dir = config.template_dir if config.template_dir else None
        tex_gen = TexGenerator(template_dir=template_dir)

        # Handle custom CLS file
        if config.cls_file_path:
            cls_src = Path(config.cls_file_path)
            if cls_src.exists():
                cls_dst = output_path.parent / cls_src.name
                output_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(cls_src, cls_dst)
                logging.info("カスタム cls ファイルをコピーしました: %s", cls_dst)

        result = tex_gen.generate(spec, output_path, template_name=config.template)
        print(_green(f"\n  仕様書を生成しました: {result}"))
    except Exception as e:
        logging.error("LaTeX 生成に失敗しました: %s", e)
        return 1

    return 0
