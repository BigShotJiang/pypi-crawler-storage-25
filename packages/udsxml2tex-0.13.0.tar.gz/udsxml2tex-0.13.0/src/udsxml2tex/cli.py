"""Command-line interface for udsxml2tex."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from udsxml2tex import __version__
from udsxml2tex.generator import TexGenerator
from udsxml2tex.parser import ArxmlParser


_EPILOG = """\
使用モード:
  1) CLI モード (デフォルト):
       udsxml2tex input.arxml -o output.tex
     ARXML ファイルを直接指定して一括変換します。

  2) インタラクションモード:
       udsxml2tex -I
     対話形式で ARXML の種類・ファイルパス・含める項目などを
     ステップごとに選択しながら仕様書を生成します。

  3) コンフィグファイルモード:
       udsxml2tex --config udsxml2tex_config.json
     事前に保存した設定ファイルを読み込んで仕様書を生成します。
     設定ファイルはインタラクションモードで保存できます。

  4) Python ライブラリとして使用:
       from udsxml2tex import ArxmlParser, TexGenerator
       spec = ArxmlParser().parse("input.arxml")
       TexGenerator().generate(spec, "output.tex")
     Python コードから直接インポートして使えます。
"""


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="udsxml2tex",
        description="Convert AUTOSAR DCM/CanTp arxml to LaTeX UDS specification documents.",
        epilog=_EPILOG,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "input",
        nargs="*",
        help="Input ARXML file(s). Multiple files will be merged. "
             "Not required when using -I or --config.",
    )
    parser.add_argument(
        "-I",
        "--interactive",
        action="store_true",
        help="Launch interactive mode — step-by-step guided generation.",
    )
    parser.add_argument(
        "--config",
        default=None,
        metavar="FILE",
        help="Path to a JSON config file (saved from interactive mode).",
    )
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output .tex file path. Default: <input_stem>_uds_spec.tex",
    )
    parser.add_argument(
        "--ecu-name",
        default=None,
        help="Override ECU name in the generated document.",
    )
    parser.add_argument(
        "--template-dir",
        default=None,
        help="Directory containing custom Jinja2 LaTeX templates.",
    )
    parser.add_argument(
        "--template",
        default="uds_spec.tex.j2",
        help="Template file name (default: uds_spec.tex.j2).",
    )
    parser.add_argument(
        "--pdf",
        action="store_true",
        help="Compile the generated .tex to PDF (requires latexmk or pdflatex).",
    )
    parser.add_argument(
        "--html",
        action="store_true",
        help="Generate an HTML document instead of (or in addition to) LaTeX.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Parse ARXML and print a summary without generating any output files.",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose logging output.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    """Main entry point for the CLI.

    Args:
        argv: Command-line arguments. Defaults to sys.argv[1:].

    Returns:
        Exit code (0 for success).
    """
    parser = _build_parser()
    args = parser.parse_args(argv)

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(levelname)s: %(message)s",
    )

    # --- Interactive mode -----------------------------------------------
    if args.interactive:
        from udsxml2tex.interactive import InteractiveSession

        return InteractiveSession().run()

    # --- Config-file mode -----------------------------------------------
    if args.config:
        from udsxml2tex.config import GenerationConfig
        from udsxml2tex.interactive import generate_from_config

        try:
            config = GenerationConfig.load(args.config)
        except Exception as e:
            logging.error("Failed to load config: %s", e)
            return 1
        # Allow CLI overrides on top of config
        if args.output:
            config.output_path = args.output
        if args.ecu_name:
            config.ecu_name = args.ecu_name
        if args.template_dir:
            config.template_dir = args.template_dir
        if args.template != "uds_spec.tex.j2":
            config.template = args.template
        return generate_from_config(config)

    # --- Direct CLI mode ------------------------------------------------
    if not args.input:
        parser.print_help()
        return 1

    # Validate input files
    input_paths = [Path(p) for p in args.input]
    for p in input_paths:
        if not p.exists():
            logging.error("Input file not found: %s", p)
            return 1
        if not p.suffix.lower() == ".arxml":
            logging.warning(
                "File does not have .arxml extension: %s", p
            )

    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        stem = input_paths[0].stem
        suffix = ".html" if args.html and not args.pdf else ".tex"
        output_path = input_paths[0].parent / f"{stem}_uds_spec{suffix}"

    # Parse ARXML
    arxml_parser = ArxmlParser()
    try:
        if len(input_paths) == 1:
            spec = arxml_parser.parse(input_paths[0])
        else:
            spec = arxml_parser.parse_multi(input_paths)
    except Exception as e:
        logging.error("Failed to parse ARXML: %s", e)
        return 1

    # Report validation warnings
    if arxml_parser.warnings:
        for w in arxml_parser.warnings:
            logging.warning("[%s] %s", w.section, w.message)

    # Override ECU name if specified
    if args.ecu_name:
        spec.ecu_name = args.ecu_name

    # --- Dry-run mode: print summary and exit ---------------------------
    if args.dry_run:
        return _print_dry_run_summary(spec, arxml_parser)

    # --- Generate output ------------------------------------------------
    try:
        tex_gen = TexGenerator(template_dir=args.template_dir)

        # Generate LaTeX (always, unless --html is the sole output)
        if not args.html:
            tex_output = output_path.with_suffix(".tex") if args.pdf else output_path
            result = tex_gen.generate(
                spec, tex_output, template_name=args.template
            )
            logging.info("LaTeX output written to: %s", result)

            # Compile to PDF if requested
            if args.pdf:
                pdf_path = tex_gen.compile_pdf(result)
                logging.info("PDF output written to: %s", pdf_path)
        else:
            # HTML-only output
            html_output = output_path.with_suffix(".html")
            tex_gen.generate_html(spec, html_output)
            logging.info("HTML output written to: %s", html_output)

        # Generate HTML as additional output when --html + --pdf / default
        if args.html and not args.html:
            pass  # already handled above

    except FileNotFoundError as e:
        logging.error("%s", e)
        return 1
    except Exception as e:
        logging.error("Failed to generate output: %s", e)
        return 1

    return 0


def _print_dry_run_summary(spec, arxml_parser) -> int:
    """Print a summary of the parsed ARXML data."""
    from udsxml2tex.models import UDS_SERVICE_NAMES

    print(f"\n{'=' * 60}")
    print(f"  udsxml2tex -- Dry Run Summary")
    print(f"{'=' * 60}")
    print(f"  ECU Name:          {spec.ecu_name}")
    print(f"  Protocol:          {spec.protocol_name}")
    if spec.protocol_type:
        print(f"  Protocol Type:     {spec.protocol_type}")
    print(f"  S3 Server Timeout: {spec.s3_server} s")
    print()

    print(f"  Sessions:          {len(spec.sessions)}")
    for s in sorted(spec.sessions, key=lambda x: x.session_id):
        print(f"    0x{s.session_id:02X} - {s.short_name} "
              f"(P2={s.p2_server_max}s, P2*={s.p2_star_server_max}s)")

    print(f"  Security Levels:   {len(spec.security_levels)}")
    for s in sorted(spec.security_levels, key=lambda x: x.security_level):
        print(f"    Level {s.security_level} - {s.short_name} "
              f"(seed={s.seed_size}B, key={s.key_size}B)")

    print(f"  Services:          {len(spec.services)}")
    for s in sorted(spec.services, key=lambda x: x.service_id):
        name = UDS_SERVICE_NAMES.get(s.service_id, s.short_name)
        sf_count = len(s.sub_functions)
        nrc_count = len(s.nrc_list)
        print(f"    0x{s.service_id:02X} - {name} "
              f"({sf_count} sub-functions, {nrc_count} NRCs)")

    print(f"  DIDs:              {len(spec.dids)}")
    print(f"  Routines:          {len(spec.routines)}")
    print(f"  DTCs:              {len(spec.dtcs)}")
    print(f"  Memory Ranges:     {len(spec.memory_ranges)}")
    print(f"  IO Control DIDs:   {len(spec.io_control_dids)}")
    print(f"  Periodic DIDs:     {len(spec.periodic_dids)}")
    print(f"  DID Ranges:        {len(spec.did_ranges)}")
    print(f"  Dynamic DIDs:      {len(spec.dynamic_dids)}")

    if spec.transport_config:
        print(f"  CanTp Channels:    {len(spec.transport_config.channels)}")
        print(f"  CAN-FD:            {'Yes' if spec.transport_config.can_fd_enabled else 'No'}")

    if arxml_parser.warnings:
        print(f"\n  Warnings:          {len(arxml_parser.warnings)}")
        for w in arxml_parser.warnings:
            print(f"    [{w.section}] {w.message}")

    print(f"\n{'=' * 60}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
