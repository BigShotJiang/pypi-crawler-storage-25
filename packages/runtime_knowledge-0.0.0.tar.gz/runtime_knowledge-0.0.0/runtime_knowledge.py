print("runtime-knowledge")
