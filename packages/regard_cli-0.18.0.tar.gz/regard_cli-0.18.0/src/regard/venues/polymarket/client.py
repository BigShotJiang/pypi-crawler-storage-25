"""Client factory — creates Polymarket CLOB and Gamma API clients."""

import os

import eth_account
import httpx
from pydantic import ValidationError

from regard.core.output import die
from regard.venues.polymarket.models import DataApiPosition


def _validate(model_cls, data, label: str = ""):
    """Validate data against a Pydantic model. Silently passes on failure."""
    try:
        model_cls.model_validate(data)
    except ValidationError:
        pass

GAMMA_BASE_URL = "https://gamma-api.polymarket.com"
DEFAULT_CLOB_URL = "https://clob-v2.polymarket.com"
DEFAULT_POLYGON_RPC = "https://rpc.regard.computer/regard/evm/137"


_v1_url_warned = False


def get_clob_url() -> str:
    """Resolve CLOB base URL. Priority: env var > settings.json > default.

    Default is clob-v2.polymarket.com (V2 backend). After cutover on April 28, 2026
    ~11:00 UTC, clob.polymarket.com also serves V2 — either URL is valid.

    If an override points at the V1 production URL (clob.polymarket.com) before
    cutover, emit a one-time warning: the SDK will sign V1 orders, but our client
    removed the fee_rate_bps fetch (V2-only code path). Orders will set feeRateBps=0
    and be rejected by the V1 exchange on markets with non-zero fees.
    """
    from regard.venues.hyperliquid.client import _load_settings_env
    url = (
        os.environ.get("POLYMARKET_CLOB_URL")
        or _load_settings_env().get("POLYMARKET_CLOB_URL")
        or DEFAULT_CLOB_URL
    )
    global _v1_url_warned
    if not _v1_url_warned and url.rstrip("/") == "https://clob.polymarket.com":
        import sys
        print(
            "WARNING: POLYMARKET_CLOB_URL points at clob.polymarket.com. Until the "
            "2026-04-28 ~11:00 UTC V2 cutover this endpoint routes V1 orders, which "
            "this CLI no longer fully supports (fee_rate_bps is no longer set on signed "
            "orders). Order placement may fail with non-zero-fee markets. Unset the "
            "override to use clob-v2.polymarket.com (default) before cutover.",
            file=sys.stderr,
        )
        _v1_url_warned = True
    return url

# Polymarket Polygon mainnet contracts (V2 + pUSD)
CONTRACTS = {
    # Core V2 exchanges
    "CTF_EXCHANGE": "0xE111180000d2663C0091e4f400237545B87B996B",
    "NEG_RISK_CTF_EXCHANGE": "0xe2222d279d744050d28e00520010520000310F59",
    "NEG_RISK_ADAPTER": "0xd91E80cF2E7be2e162c6513ceD06f1dD0dA35296",
    "CTF": "0x4D97DCd97eC945f40cF65F87097ACe5EA0476045",
    # V2 collateral (Polymarket USD)
    "PUSD": "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB",
    "COLLATERAL_ONRAMP": "0x93070a847efEf7F70739046A929D47a521F5B8ee",
    "COLLATERAL_OFFRAMP": "0x2957922Eb93258b93368531d39fAcCA3B4dC5854",
    # Wrap source / residual recovery (USDC.e — V1-era collateral)
    "USDC_E": "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174",
}

ERC20_ABI = [
    {"constant": True, "inputs": [{"name": "_owner", "type": "address"}], "name": "balanceOf", "outputs": [{"name": "", "type": "uint256"}], "type": "function"},
    {"constant": True, "inputs": [{"name": "_owner", "type": "address"}, {"name": "_spender", "type": "address"}], "name": "allowance", "outputs": [{"name": "", "type": "uint256"}], "type": "function"},
    {"constant": False, "inputs": [{"name": "_spender", "type": "address"}, {"name": "_value", "type": "uint256"}], "name": "approve", "outputs": [{"name": "", "type": "bool"}], "type": "function"},
]

CTF_ABI = [
    {"constant": True, "inputs": [{"name": "_owner", "type": "address"}, {"name": "_operator", "type": "address"}], "name": "isApprovedForAll", "outputs": [{"name": "", "type": "bool"}], "type": "function"},
    {"constant": False, "inputs": [{"name": "_operator", "type": "address"}, {"name": "_approved", "type": "bool"}], "name": "setApprovalForAll", "outputs": [], "type": "function"},
]

EXCHANGE_ABI = [
    {"constant": True, "inputs": [], "name": "getCollateral", "outputs": [{"name": "", "type": "address"}], "type": "function"},
]

ONRAMP_ABI = [
    {"inputs": [{"name": "_asset", "type": "address"}, {"name": "_to", "type": "address"}, {"name": "_amount", "type": "uint256"}], "name": "wrap", "outputs": [], "type": "function"},
]

OFFRAMP_ABI = [
    {"inputs": [{"name": "_asset", "type": "address"}, {"name": "_to", "type": "address"}, {"name": "_amount", "type": "uint256"}], "name": "unwrap", "outputs": [], "type": "function"},
]

# Known token names by address (for display)
TOKEN_NAMES = {
    "0xC011a7E12a19f7B1f670d46F03B03f3342E82DFB": "pUSD",
    "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174": "USDC.e",
    "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359": "USDC",
}


def _get_key() -> str:
    key = os.environ.get("POLYMARKET_PRIVATE_KEY")
    if not key:
        # Fallback: read from settings file directly
        from regard.venues.hyperliquid.client import _load_settings_env
        key = _load_settings_env().get("POLYMARKET_PRIVATE_KEY")
    if not key:
        die(
            "auth_error", "NO_KEY",
            "No Polymarket key set",
            hint="Run 'regard auth <key>' in a separate terminal from this project dir",
            exit_code=3,
        )
    return key


def get_address(explicit: str = None) -> str:
    """Get Polygon wallet address. Priority: explicit arg > derived from key."""
    if explicit:
        return explicit
    key = _get_key()
    return eth_account.Account.from_key(key).address


def get_gamma_client() -> httpx.Client:
    """Create Gamma API client (unauthenticated, no geo-restriction)."""
    return httpx.Client(base_url=GAMMA_BASE_URL, timeout=30.0)


DATA_API_BASE = "https://data-api.polymarket.com"


def get_positions(address: str = None, raise_on_error: bool = False) -> list:
    """Fetch current positions from the Polymarket Data API.

    Not geo-restricted (unlike CLOB). Returns normalized list matching
    the field names used throughout the codebase.

    Args:
        raise_on_error: If True, propagate exceptions instead of returning [].
            Use True in killswitch (must know if fetch failed vs empty account).
    """
    if not address:
        address = get_address()
    all_positions = []
    try:
        offset = 0
        limit = 500
        while True:
            resp = httpx.get(
                f"{DATA_API_BASE}/positions",
                params={"user": address, "sizeThreshold": 0, "limit": limit, "offset": offset},
                timeout=30.0,
            )
            resp.raise_for_status()
            page = resp.json()
            if not isinstance(page, list):
                break
            all_positions.extend(page)
            if len(page) < limit:
                break
            offset += limit
    except Exception:
        if raise_on_error:
            raise
        if not all_positions:
            return []
        # Partial results from earlier pages — return what we have

    result = []
    for p in all_positions:
        _validate(DataApiPosition, p, "position")
        size = float(p.get("size", 0) or 0)
        if size == 0:
            continue
        result.append({
            "asset_id": p.get("asset", ""),
            "market": p.get("title", ""),
            "side": "BUY",  # Data API positions are always long (you hold outcome tokens)
            "size": str(size),
            "avg_price": str(p.get("avgPrice", "")),
            "cur_price": str(p.get("curPrice", "")),
            "pnl": str(p.get("cashPnl", "")),
            "condition_id": p.get("conditionId", ""),
            "outcome": p.get("outcome", ""),
            "redeemable": p.get("redeemable", False),
            "mergeable": p.get("mergeable", False),
        })
    return result


def get_clob_client():
    """Create authenticated CLOB client with derived API credentials.

    Geo-restricted — will fail from blocked regions (US, Singapore, etc.).
    Use Dublin VPN for trading.
    """
    from py_clob_client_v2.client import ClobClient

    key = _get_key()
    if not key.startswith("0x"):
        key = f"0x{key}"
    address = eth_account.Account.from_key(key).address

    client = ClobClient(
        get_clob_url(),
        key=key,
        chain_id=137,
        signature_type=0,
        funder=address,
    )
    creds = client.derive_api_key()
    client.set_api_creds(creds)
    return client


def _make_retry_session():
    """Create a requests Session with retry-on-429 and transient error handling."""
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry

    retry = Retry(
        total=3,
        backoff_factor=1,             # 1s, 2s, 4s
        status_forcelist=[429, 502, 503, 504],
        allowed_methods=["POST"],      # JSON-RPC is always POST
        raise_on_status=False,         # let web3 handle the response
    )
    session = requests.Session()
    session.mount("https://", HTTPAdapter(max_retries=retry))
    session.mount("http://", HTTPAdapter(max_retries=retry))
    return session


def get_web3():
    """Create Web3 client for Polygon mainnet.

    Uses POLYGON_RPC from settings if set (with eRPC as fallback),
    otherwise the default eRPC endpoint. All sessions retry on 429/5xx.
    """
    from web3 import Web3

    from regard.venues.hyperliquid.client import _load_settings_env

    custom = _load_settings_env().get("POLYGON_RPC")
    rpcs = [custom, DEFAULT_POLYGON_RPC] if custom else [DEFAULT_POLYGON_RPC]
    session = _make_retry_session()

    for rpc_url in rpcs:
        try:
            w3 = Web3(Web3.HTTPProvider(rpc_url, session=session, request_kwargs={"timeout": 10}))
            w3.eth.block_number  # verify connectivity (is_connected uses web3_clientVersion which eRPC blocks)
            return w3
        except Exception:
            continue

    return Web3(Web3.HTTPProvider(DEFAULT_POLYGON_RPC, session=session, request_kwargs={"timeout": 30}))


_collateral_cache = None


def clear_collateral_cache():
    """Reset collateral cache. Used by tests to prevent cross-test pollution."""
    global _collateral_cache
    _collateral_cache = None


DECIMALS_ABI = [
    {"constant": True, "inputs": [], "name": "decimals", "outputs": [{"name": "", "type": "uint8"}], "type": "function"},
]


def get_collateral_token(w3=None) -> dict:
    """Discover the collateral token Polymarket uses.

    Reads on-chain from CTF Exchange getCollateral(). Falls back to
    hardcoded pUSD address if RPC is unavailable. Cached after first call.

    Returns {"address": "0x...", "name": "pUSD", "decimals": 6, "source": "on-chain"|"fallback"}.
    """
    global _collateral_cache
    if _collateral_cache is not None:
        return _collateral_cache

    if w3 is None:
        w3 = get_web3()

    fallback = CONTRACTS["PUSD"]

    try:
        exchange = w3.eth.contract(
            address=w3.to_checksum_address(CONTRACTS["CTF_EXCHANGE"]),
            abi=EXCHANGE_ABI,
        )
        address = exchange.functions.getCollateral().call()
        name = TOKEN_NAMES.get(address, "unknown")

        # Read decimals from the token contract
        try:
            token = w3.eth.contract(address=w3.to_checksum_address(address), abi=DECIMALS_ABI)
            decimals = token.functions.decimals().call()
        except Exception:
            decimals = 6  # pUSD, USDC.e, native USDC all 6

        if address.lower() != fallback.lower():
            import sys
            print(f"warning: collateral token changed to {name} ({address})", file=sys.stderr)

        _collateral_cache = {"address": address, "name": name, "decimals": decimals, "source": "on-chain"}
    except Exception:
        _collateral_cache = {"address": fallback, "name": "pUSD", "decimals": 6, "source": "fallback"}

    return _collateral_cache


USDC_NATIVE = "0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359"


def get_wallet_balances(w3=None, address=None) -> dict:
    """Get on-chain wallet balances on Polygon (pUSD, USDC.e, USDC native, POL).

    Returns {"pusd": "5.00", "usdc_e": "0.00", "usdc": "5.00", "pol": "2.94", "rpc_ok": true}.
    Sets rpc_ok=false if RPC is unreachable — balances may be stale/wrong.
    """
    if w3 is None:
        w3 = get_web3()
    if address is None:
        address = get_address()

    checksummed = w3.to_checksum_address(address)
    result = {"pusd": "0.00", "usdc_e": "0.00", "usdc": "0.00", "pol": "0.00", "rpc_ok": False}

    ok = False
    try:
        pol_wei = w3.eth.get_balance(checksummed)
        result["pol"] = f"{pol_wei / 1e18:.4f}"
        ok = True
    except Exception:
        pass
    try:
        pusd = w3.eth.contract(address=w3.to_checksum_address(CONTRACTS["PUSD"]), abi=ERC20_ABI)
        result["pusd"] = f"{pusd.functions.balanceOf(checksummed).call() / 1e6:.2f}"
        ok = True
    except Exception:
        pass
    try:
        usdc_e = w3.eth.contract(address=w3.to_checksum_address(CONTRACTS["USDC_E"]), abi=ERC20_ABI)
        result["usdc_e"] = f"{usdc_e.functions.balanceOf(checksummed).call() / 1e6:.2f}"
        ok = True
    except Exception:
        pass
    try:
        usdc = w3.eth.contract(address=w3.to_checksum_address(USDC_NATIVE), abi=ERC20_ABI)
        result["usdc"] = f"{usdc.functions.balanceOf(checksummed).call() / 1e6:.2f}"
        ok = True
    except Exception:
        pass

    result["rpc_ok"] = ok
    return result


# ---------------------------------------------------------------------------
# CTF on-chain operations (redeem / merge)
# ---------------------------------------------------------------------------

CTF_REDEEM_ABI = [{"inputs": [{"name": "collateralToken", "type": "address"}, {"name": "parentCollectionId", "type": "bytes32"}, {"name": "conditionId", "type": "bytes32"}, {"name": "indexSets", "type": "uint256[]"}], "name": "redeemPositions", "outputs": [], "type": "function"}]
CTF_MERGE_ABI = [{"inputs": [{"name": "collateralToken", "type": "address"}, {"name": "parentCollectionId", "type": "bytes32"}, {"name": "conditionId", "type": "bytes32"}, {"name": "partition", "type": "uint256[]"}, {"name": "amount", "type": "uint256"}], "name": "mergePositions", "outputs": [], "type": "function"}]
# NEG_RISK_ADAPTER has a simplified mergePositions — only conditionId + amount.
# Collateral, parentCollectionId, and partition are implicit in the adapter.
NEG_RISK_MERGE_ABI = [{"inputs": [{"name": "conditionId", "type": "bytes32"}, {"name": "amount", "type": "uint256"}], "name": "mergePositions", "outputs": [], "type": "function"}]


def derive_binary_position_id(collateral_addr: str, condition_id: str, outcome: str) -> int:
    """Derive the CTF ERC1155 position ID for a binary (non-neg_risk) market outcome.

    positionId = uint256(keccak256(abi.encodePacked(collateralToken, collectionId)))
    collectionId = keccak256(abi.encodePacked(bytes32(0), conditionId, indexSet))
    indexSet = 1 for YES, 2 for NO (binary markets)

    Lets callers reverse-resolve which collateral a position was split from by
    matching candidate derivations against the wallet's asset_id. NegRisk markets
    use a different scheme via NEG_RISK_ADAPTER and are not valid here.
    """
    from eth_utils.crypto import keccak

    cid_hex = condition_id[2:] if condition_id.startswith("0x") else condition_id
    cid_bytes = bytes.fromhex(cid_hex)
    if len(cid_bytes) != 32:
        raise ValueError(f"condition_id must be 32 bytes, got {len(cid_bytes)}")
    parent = bytes(32)
    index_set = 1 if outcome.upper() == "YES" else 2
    index_bytes = index_set.to_bytes(32, "big")
    collection_id = keccak(parent + cid_bytes + index_bytes)

    addr_hex = collateral_addr[2:] if collateral_addr.startswith("0x") else collateral_addr
    collateral_bytes = bytes.fromhex(addr_hex)
    if len(collateral_bytes) != 20:
        raise ValueError(f"collateral_addr must be 20 bytes, got {len(collateral_bytes)}")
    return int.from_bytes(keccak(collateral_bytes + collection_id), "big")


def resolve_binary_collateral(condition_id: str, token_id: str, outcome: str) -> str:
    """Match a position's asset_id against pUSD- and USDC.e-derived position IDs
    to determine which collateral the market was split with.

    Pre-V2 markets use USDC.e; post-V2 markets use pUSD. CTF.mergePositions and
    redeemPositions need the correct collateral parameter — passing pUSD for a
    USDC.e-split market would target non-existent ERC1155 token IDs and revert.

    Only applies to binary (neg_risk=False) markets. NegRisk markets bypass the
    collateralToken parameter via NEG_RISK_ADAPTER.

    Returns collateral address. Raises ValueError if no candidate matches.
    """
    token_id_int = int(token_id)
    for addr_key in ("PUSD", "USDC_E"):
        addr = CONTRACTS[addr_key]
        if derive_binary_position_id(addr, condition_id, outcome) == token_id_int:
            return addr
    raise ValueError(
        f"token_id {token_id} doesn't match pUSD- or USDC.e-derived position IDs "
        f"for condition {condition_id}; market may use a non-standard collateral"
    )


def ctf_call(condition_id: str, size: float, token_id: str, action: str,
             neg_risk: bool = False, collateral_addr: str | None = None) -> dict:
    """Execute a redeem or merge on the CTF contract.

    For negRisk (multi-outcome) markets, merge routes through NEG_RISK_ADAPTER
    which has a simplified 2-param mergePositions(conditionId, amount) — the
    collateral parameter is ignored. Binary markets use the CTF contract's
    5-param mergePositions/redeemPositions with explicit collateralToken.

    For binary markets, callers should pass `collateral_addr` derived from the
    position's token_id (see resolve_binary_collateral). If omitted, falls back
    to get_collateral_token() which assumes the current V2 collateral — correct
    for post-V2 markets, wrong for pre-V2 (USDC.e-era) markets.

    Returns {"token_id": ..., "action": ..., "size": ..., "collateral": "pUSD|USDC.e",
    "tx": "0x..."}. Raises RuntimeError on revert, EVMSafetyError on gas/simulation failure.
    """
    from regard.core.evm import get_safe_gas_price, simulate_and_send

    w3 = get_web3()
    account = eth_account.Account.from_key(_get_key())
    sender = w3.to_checksum_address(account.address)
    if collateral_addr is None:
        # Default — matches current V2 state. Safe for neg_risk (ignored) and
        # for post-V2 binary markets. Wrong for pre-V2 binary markets; callers
        # should resolve per-position before calling.
        collateral = get_collateral_token(w3)
        collateral_addr = collateral["address"]
        decimals = collateral["decimals"]
    else:
        decimals = 6  # pUSD and USDC.e are both 6; both candidates for binary merges
    collateral_name = TOKEN_NAMES.get(collateral_addr, "unknown")
    cid_bytes = bytes.fromhex(condition_id[2:] if condition_id.startswith("0x") else condition_id)

    if action == "redeem":
        ctf = w3.eth.contract(address=w3.to_checksum_address(CONTRACTS["CTF"]), abi=CTF_REDEEM_ABI)
        fn = ctf.functions.redeemPositions(
            w3.to_checksum_address(collateral_addr), bytes(32), cid_bytes, [1, 2],
        )
    else:
        amount_raw = int(round(size * 10**decimals))
        if neg_risk:
            # NEG_RISK_ADAPTER: simplified 2-param merge
            adapter = w3.eth.contract(
                address=w3.to_checksum_address(CONTRACTS["NEG_RISK_ADAPTER"]),
                abi=NEG_RISK_MERGE_ABI,
            )
            fn = adapter.functions.mergePositions(cid_bytes, amount_raw)
        else:
            # CTF: full 5-param merge
            ctf = w3.eth.contract(
                address=w3.to_checksum_address(CONTRACTS["CTF"]),
                abi=CTF_MERGE_ABI,
            )
            fn = ctf.functions.mergePositions(
                w3.to_checksum_address(collateral_addr), bytes(32), cid_bytes, [1, 2], amount_raw,
            )

    # NEG_RISK_ADAPTER proxies through CTF internally — needs more gas than direct CTF calls
    gas_limit = 350_000 if neg_risk else 200_000
    gas_price = get_safe_gas_price(w3)
    nonce = w3.eth.get_transaction_count(sender, "pending")
    tx = fn.build_transaction({"from": sender, "nonce": nonce, "gas": gas_limit, "gasPrice": gas_price, "chainId": 137})
    tx_hash = simulate_and_send(w3, tx, account)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)
    if receipt["status"] != 1:
        raise RuntimeError(f"{action} tx reverted: 0x{tx_hash.hex()}")
    return {
        "token_id": token_id,
        "action": action,
        "size": size,
        "collateral": collateral_name,
        "tx": f"0x{tx_hash.hex()}",
    }


def ctf_redeem(condition_id: str, size: float, token_id: str,
               collateral_addr: str | None = None) -> dict:
    """Redeem resolved position tokens for collateral."""
    return ctf_call(condition_id, size, token_id, "redeem", collateral_addr=collateral_addr)


def ctf_merge(condition_id: str, size: float, token_id: str,
              neg_risk: bool = False, collateral_addr: str | None = None) -> dict:
    """Merge YES + NO tokens back into collateral.

    For negRisk markets, routes through NEG_RISK_ADAPTER — collateral_addr ignored.
    """
    return ctf_call(condition_id, size, token_id, "merge",
                    neg_risk=neg_risk, collateral_addr=collateral_addr)


def lookup_neg_risk(condition_ids: list[str], token_ids: dict[str, str] | None = None) -> dict[str, bool]:
    """Look up negRisk flag for a list of condition IDs.

    Uses the CLOB /neg-risk endpoint (public, no auth, exact match by token_id).
    Falls back to False on lookup failure.

    Args:
        condition_ids: List of condition IDs to look up.
        token_ids: Optional mapping {condition_id: token_id} for direct CLOB lookup.
            When provided, skips Gamma entirely. Callers with position data should
            pass this for faster, more reliable lookups.

    Returns {condition_id: bool}.
    """
    import sys

    result = {}
    for cid in set(condition_ids):
        tid = token_ids.get(cid) if token_ids else None
        if not tid:
            result[cid] = False
            continue
        try:
            resp = httpx.get(
                f"{get_clob_url()}/neg-risk",
                params={"token_id": tid},
                timeout=10.0,
            )
            resp.raise_for_status()
            data = resp.json()
            result[cid] = bool(data.get("neg_risk", False))
        except Exception as e:
            print(f"[lookup_neg_risk] WARN: failed for {cid[:16]}...: {e}", file=sys.stderr)
            result[cid] = False
    return result


def plan_merges(positions: list[dict]) -> list[dict]:
    """Build a merge plan from a list of positions.

    Filters for mergeable positions, groups by condition_id, computes
    min(YES, NO) per condition, and looks up negRisk routing.

    Returns a list of merge entries:
        [{"condition_id": str, "merge_size": float, "neg_risk": bool,
          "market": str, "legs": [{"token_id": str, "outcome": str, "size": float}]}]

    Shared by both `regard poly merge` and the killswitch merge path.
    """
    # Filter mergeable positions with nonzero size
    mergeable = [
        p for p in positions
        if p.get("mergeable") and p.get("condition_id") and float(p.get("size", 0) or 0) > 0
    ]
    if not mergeable:
        return []

    # Group by condition_id
    by_cid: dict[str, list[dict]] = {}
    for p in mergeable:
        by_cid.setdefault(p["condition_id"], []).append(p)

    # Look up negRisk via CLOB endpoint — pass one token_id per condition_id
    cid_to_token: dict[str, str] = {}
    for cid, legs in by_cid.items():
        for p in legs:
            tid = p.get("asset_id") or p.get("token_id", "")
            if tid:
                cid_to_token[cid] = tid
                break

    neg_risk_map = {}
    try:
        neg_risk_map = lookup_neg_risk(list(by_cid.keys()), token_ids=cid_to_token)
    except Exception as e:
        import sys
        print(f"[plan_merges] WARN: negRisk lookup failed ({e}), assuming binary for all merges", file=sys.stderr)

    # Build merge plan
    merges = []
    for cid, legs in by_cid.items():
        sizes = [float(p["size"]) for p in legs]
        merge_size = min(sizes)
        if merge_size <= 0:
            continue
        merges.append({
            "condition_id": cid,
            "merge_size": merge_size,
            "neg_risk": neg_risk_map.get(cid, False),
            "market": legs[0].get("market", ""),
            "legs": [
                {"token_id": p["asset_id"], "outcome": p.get("outcome", ""), "size": float(p["size"])}
                for p in legs
            ],
        })
    return merges


# Close-only jurisdictions: can close existing positions (market sell) but not
# open new ones. Per https://docs.polymarket.com/api-reference/geoblock —
# refresh periodically. Other blocked countries are discovered dynamically via
# the `blocked` flag in the geoblock response.
CLOSE_ONLY_COUNTRIES = frozenset({"PL", "SG", "TH", "TW"})


def get_geo_status() -> dict:
    """Fetch structured geo status from Polymarket's official endpoint.

    Returns: {"blocked": bool, "ip": str, "country": str, "region": str,
              "close_only": bool}. Raises httpx.HTTPError on network failure.
    """
    resp = httpx.get("https://polymarket.com/api/geoblock", timeout=10.0)
    resp.raise_for_status()
    data = resp.json()
    data["close_only"] = data.get("country") in CLOSE_ONLY_COUNTRIES
    return data


def check_geo_block():
    """Gate order-placement operations by IP region.

    Calls Polymarket's authoritative geoblock endpoint. Dies if the IP is in
    a fully-blocked region. Close-only regions (PL/SG/TH/TW) pass this gate
    because users there can still place closing orders (market sells); the
    CLOB itself will reject opening orders with its own 403. Cancel operations
    are not geo-restricted at all and MUST NOT call this function.
    """
    try:
        status = get_geo_status()
    except httpx.HTTPError:
        return  # network error: let the actual trade call handle it
    if status.get("blocked") and not status.get("close_only"):
        country = status.get("country", "unknown")
        die(
            "geo_error", "GEO_BLOCKED",
            f"Polymarket order placement is restricted from {country}",
            hint="You can still cancel orders and use on-chain merge/redeem. "
                 "To place new orders, connect from a non-restricted jurisdiction.",
            exit_code=4,
        )
