"""Auth + selfup command tests.

Tests the unified `regard auth` command:
- Bare `regard auth` reports status JSON
- `regard auth <key>` saves key for all venues to project-local settings
- `regard auth prompt` interactive path is getpass, covered via key validation
"""

import json
import os
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from regard.commands.auth import _validate_hex_key
from regard.commands.update import _parse_version
from regard.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Key validation
# ---------------------------------------------------------------------------

class TestValidateHexKey:
    def test_valid_with_prefix(self):
        key = "0x" + "a" * 64
        assert _validate_hex_key(key) == "0x" + "a" * 64

    def test_valid_without_prefix(self):
        key = "b" * 64
        assert _validate_hex_key(key) == "0x" + "b" * 64

    def test_too_short(self):
        assert _validate_hex_key("0xabc") == ""

    def test_too_long(self):
        assert _validate_hex_key("0x" + "a" * 65) == ""

    def test_non_hex(self):
        assert _validate_hex_key("0x" + "g" * 64) == ""

    def test_empty(self):
        assert _validate_hex_key("") == ""

    def test_whitespace_stripped(self):
        key = "  0x" + "c" * 64 + "  "
        assert _validate_hex_key(key) == "0x" + "c" * 64


# ---------------------------------------------------------------------------
# Auth check
# ---------------------------------------------------------------------------

class TestAuthStatus:
    """`regard auth` with no args reports status."""

    def test_no_credentials(self):
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.venues.hyperliquid.client._load_settings_env", return_value={}):
                result = runner.invoke(app, ["auth"])
                d = json.loads(result.stdout)
                assert d["ok"] is True
                hl = d["data"]["venues"]["hyperliquid"]
                assert hl["configured"] is False
                poly = d["data"]["venues"]["polymarket"]
                assert poly["configured"] is False
                assert "unified_key" not in d["data"]

    def test_with_hl_key_only(self):
        fake_key = "0x" + "a" * 64
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        env["HYPERLIQUID_PRIVATE_KEY"] = fake_key
        mock_account = MagicMock(address="0xTEST")
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.venues.hyperliquid.client._load_settings_env", return_value={}):
                with patch("eth_account.Account.from_key", return_value=mock_account):
                    result = runner.invoke(app, ["auth"])
                    d = json.loads(result.stdout)
                    assert d["ok"] is True
                    hl = d["data"]["venues"]["hyperliquid"]
                    assert hl["configured"] is True
                    assert hl["address"] == "0xTEST"
                    assert "mode" not in hl
                    # Poly side reports not configured — no unified_key claim
                    assert d["data"]["venues"]["polymarket"]["configured"] is False
                    assert "unified_key" not in d["data"]

    def test_with_poly_key_only(self):
        fake_key = "0x" + "b" * 64
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        env["POLYMARKET_PRIVATE_KEY"] = fake_key
        mock_account = MagicMock(address="0xPOLY")
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.venues.hyperliquid.client._load_settings_env", return_value={}):
                with patch("eth_account.Account.from_key", return_value=mock_account):
                    result = runner.invoke(app, ["auth"])
                    d = json.loads(result.stdout)
                    poly = d["data"]["venues"]["polymarket"]
                    assert poly["configured"] is True
                    assert poly["address"] == "0xPOLY"

    def test_unified_key_collapses_address(self):
        """When HL + Poly resolve to the same address, report it at the top level."""
        fake_key = "0x" + "c" * 64
        env = {k: v for k, v in os.environ.items()
               if not any(x in k for x in ("HYPERLIQUID", "POLYMARKET"))}
        env["HYPERLIQUID_PRIVATE_KEY"] = fake_key
        env["POLYMARKET_PRIVATE_KEY"] = fake_key
        mock_account = MagicMock(address="0xUNIFIED")
        with patch.dict(os.environ, env, clear=True):
            with patch("regard.venues.hyperliquid.client._load_settings_env", return_value={}):
                with patch("eth_account.Account.from_key", return_value=mock_account):
                    result = runner.invoke(app, ["auth"])
                    d = json.loads(result.stdout)
                    assert d["data"]["unified_key"] is True
                    assert d["data"]["address"] == "0xUNIFIED"


class TestAuthSaveKey:
    """`regard auth <key>` writes to `<cwd>/.claude/settings.local.json`."""

    def test_saves_to_project_local(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        fake_key = "0x" + "d" * 64
        # Skip eth_account derivation; just verify the write path
        mock_account = MagicMock(address="0xDEED")
        with patch("eth_account.Account.from_key", return_value=mock_account):
            result = runner.invoke(app, ["auth", fake_key])
        assert result.exit_code == 0

        settings_path = tmp_path / ".claude" / "settings.local.json"
        assert settings_path.exists()
        data = json.loads(settings_path.read_text())
        assert data["env"]["HYPERLIQUID_PRIVATE_KEY"] == fake_key
        assert data["env"]["POLYMARKET_PRIVATE_KEY"] == fake_key

    def test_rejects_invalid_key(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(app, ["auth", "not-a-key"])
        assert result.exit_code == 1
        # no file written
        assert not (tmp_path / ".claude" / "settings.local.json").exists()

    def test_strips_legacy_agent_key(self, tmp_path, monkeypatch):
        """Existing HYPERLIQUID_AGENT_KEY entry should be cleaned on save."""
        monkeypatch.chdir(tmp_path)
        settings_path = tmp_path / ".claude" / "settings.local.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(json.dumps({"env": {"HYPERLIQUID_AGENT_KEY": "legacy"}}))

        fake_key = "0x" + "e" * 64
        with patch("eth_account.Account.from_key", return_value=MagicMock(address="0xEEE")):
            result = runner.invoke(app, ["auth", fake_key])
        assert result.exit_code == 0

        data = json.loads(settings_path.read_text())
        assert "HYPERLIQUID_AGENT_KEY" not in data["env"]
        assert data["env"]["HYPERLIQUID_PRIVATE_KEY"] == fake_key

    def test_preserves_non_env_settings(self, tmp_path, monkeypatch):
        """Permissions / other top-level keys must survive."""
        monkeypatch.chdir(tmp_path)
        settings_path = tmp_path / ".claude" / "settings.local.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(json.dumps({
            "permissions": {"allow": ["Bash(ls)"]},
            "env": {"OTHER_VAR": "keep-me"},
        }))

        fake_key = "0x" + "f" * 64
        with patch("eth_account.Account.from_key", return_value=MagicMock(address="0xFFF")):
            result = runner.invoke(app, ["auth", fake_key])
        assert result.exit_code == 0

        data = json.loads(settings_path.read_text())
        assert data["permissions"]["allow"] == ["Bash(ls)"]
        assert data["env"]["OTHER_VAR"] == "keep-me"
        assert data["env"]["HYPERLIQUID_PRIVATE_KEY"] == fake_key


class TestSettingsPathIsProjectLocal:
    """Make sure _load_settings_env reads from the nearest project settings,
    walking up from CWD but stopping at HOME."""

    def test_reads_from_cwd(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path.parent)
        settings_path = tmp_path / ".claude" / "settings.local.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(json.dumps({"env": {"TEST_VAR": "from-project"}}))

        from regard.venues.hyperliquid.client import _load_settings_env
        env = _load_settings_env()
        assert env.get("TEST_VAR") == "from-project"

    def test_walks_up_from_subdirectory(self, tmp_path, monkeypatch):
        """User running `regard` from a subdir of the project should still
        resolve the settings file at the project root."""
        project = tmp_path / "my-project"
        subdir = project / "subdir" / "deeper"
        subdir.mkdir(parents=True)
        settings_path = project / ".claude" / "settings.local.json"
        settings_path.parent.mkdir(parents=True)
        settings_path.write_text(json.dumps({"env": {"FROM_ROOT": "yes"}}))

        monkeypatch.chdir(subdir)
        # Pretend HOME is above tmp_path so traversal won't stop prematurely
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path.parent)

        from regard.venues.hyperliquid.client import _load_settings_env
        env = _load_settings_env()
        assert env.get("FROM_ROOT") == "yes"

    def test_walk_stops_at_home(self, tmp_path, monkeypatch):
        """Walk must not pick up ~/.claude/settings.local.json even if it exists."""
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        (fake_home / ".claude").mkdir()
        (fake_home / ".claude" / "settings.local.json").write_text(
            json.dumps({"env": {"FROM_HOME": "leak"}})
        )

        project = fake_home / "project"
        project.mkdir()

        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

        from regard.venues.hyperliquid.client import _load_settings_env
        env = _load_settings_env()
        # HOME settings must not leak — project has no .claude, walk stops at HOME
        assert env == {}

    def test_ignores_home_when_no_project_settings(self, tmp_path, monkeypatch):
        """Empty project dir + $HOME with old keys → still returns {}."""
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        (fake_home / ".claude").mkdir()
        (fake_home / ".claude" / "settings.local.json").write_text(
            json.dumps({"env": {"HYPERLIQUID_PRIVATE_KEY": "0x" + "a" * 64}})
        )
        project = fake_home / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

        from regard.venues.hyperliquid.client import _load_settings_env
        env = _load_settings_env()
        assert env == {}


class TestAuthValidatesKeyCurve:
    """Valid hex but invalid secp256k1 scalar must abort, not save a bad key.

    Note: eth_account 0.13+ actually accepts the all-zero scalar and derives a
    deterministic address from it, so we can't use that as a test case — the
    "invalid scalar" surface is specifically values >= curve order n.
    """

    def test_rejects_above_curve_order(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path.parent)
        # All-Fs is above the secp256k1 curve order n — eth_account rejects
        bad_key = "0x" + "f" * 64
        result = runner.invoke(app, ["auth", bad_key])
        assert result.exit_code == 1
        # No file should be written — we abort BEFORE persisting
        assert not (tmp_path / ".claude" / "settings.local.json").exists()


class TestAuthPromptEmpty:
    """`regard auth --prompt` with empty input must error, not fall through to status."""

    def test_prompt_empty_errors(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # Mock getpass to return empty string (simulating user just pressing Enter)
        with patch("getpass.getpass", return_value=""):
            # Force stdin.isatty() so --prompt doesn't bail on non-interactive
            with patch("sys.stdin.isatty", return_value=True):
                result = runner.invoke(app, ["auth", "--prompt"])
        assert result.exit_code == 1
        # Make sure we did NOT get a status JSON back
        assert not (tmp_path / ".claude" / "settings.local.json").exists()


class TestAtomicWrite:
    """`_save_env_vars` uses tmp+rename so a crash mid-write can't wipe settings."""

    def test_uses_tmp_file_and_rename(self, tmp_path, monkeypatch):
        """Verify the write path creates .tmp and ends with os.replace."""
        from regard.commands.auth import _save_env_vars
        target = tmp_path / ".claude" / "settings.local.json"
        _save_env_vars({"K": "V"}, target)
        assert target.exists()
        assert not (target.parent / (target.name + ".tmp")).exists()  # tmp cleaned up
        assert json.loads(target.read_text())["env"]["K"] == "V"

    def test_preserves_contents_on_simulated_crash(self, tmp_path, monkeypatch):
        """If write_text to .tmp raises, the real settings file must be intact."""
        from regard.commands.auth import _save_env_vars
        target = tmp_path / ".claude" / "settings.local.json"
        target.parent.mkdir(parents=True)
        target.write_text(json.dumps({"env": {"EXISTING": "keep-me"}}))

        original = Path  # type: ignore[assignment]

        def write_text_fail(self, *a, **kw):
            if self.suffix == ".tmp":
                raise OSError("disk full")
            return original.write_text(self, *a, **kw)

        with patch.object(Path, "write_text", write_text_fail):
            try:
                _save_env_vars({"K": "V"}, target)
            except OSError:
                pass  # expected

        # Original file must still have EXISTING
        data = json.loads(target.read_text())
        assert data["env"]["EXISTING"] == "keep-me"


class TestStrandedGlobalKeysWarning:
    """When user has legacy keys in ~/.claude/settings.local.json but the
    project has no settings, the CLI should emit a migration hint on stderr."""

    def test_warns_on_stranded_hl_key(self, tmp_path, monkeypatch, capsys):
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        (fake_home / ".claude").mkdir()
        (fake_home / ".claude" / "settings.local.json").write_text(
            json.dumps({"env": {"HYPERLIQUID_PRIVATE_KEY": "0x" + "a" * 64}})
        )
        project = fake_home / "project"
        project.mkdir()
        monkeypatch.chdir(project)
        monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

        from regard.venues.hyperliquid.client import _warn_stranded_global_keys
        _warn_stranded_global_keys()
        captured = capsys.readouterr()
        assert "HYPERLIQUID_PRIVATE_KEY" in captured.err
        assert "project-local scope" in captured.err or "v0.17" in captured.err

    def test_no_warning_when_no_global_keys(self, tmp_path, monkeypatch, capsys):
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)
        monkeypatch.chdir(tmp_path)

        from regard.venues.hyperliquid.client import _warn_stranded_global_keys
        _warn_stranded_global_keys()
        captured = capsys.readouterr()
        assert captured.err == ""


# ---------------------------------------------------------------------------
# Selfup
# ---------------------------------------------------------------------------

class TestSelfup:
    def test_no_update(self):
        with patch("regard.commands.update._get_pypi_latest", return_value="0.6.0"):
            result = runner.invoke(app, ["selfup"])
            d = json.loads(result.stdout)
            assert d["ok"] is True
            assert d["data"]["update_available"] is False

    def test_update_available(self):
        with patch("regard.commands.update._get_pypi_latest", return_value="99.0.0"):
            result = runner.invoke(app, ["selfup"])
            d = json.loads(result.stdout)
            assert d["ok"] is True
            assert d["data"]["update_available"] is True
            assert "command" in d["data"]

    def test_pypi_unreachable(self):
        with patch("regard.commands.update._get_pypi_latest", return_value=None):
            result = runner.invoke(app, ["selfup"])
            d = json.loads(result.stdout)
            assert d["ok"] is True
            assert d["data"]["update_available"] is False
            assert d["data"]["latest"] is None


class TestParseVersion:
    def test_basic(self):
        from packaging.version import Version
        assert _parse_version("0.10.6") == Version("0.10.6")

    def test_comparison(self):
        assert _parse_version("0.10.6") > _parse_version("0.10.5")
        assert _parse_version("0.11.0") > _parse_version("0.10.99")
        assert _parse_version("1.0.0") > _parse_version("0.99.99")

    def test_rc_comparison(self):
        assert _parse_version("0.15.0rc1") > _parse_version("0.6.0")
        assert _parse_version("0.15.0") > _parse_version("0.15.0rc1")
        assert _parse_version("0.15.0rc2") > _parse_version("0.15.0rc1")

    def test_invalid(self):
        from packaging.version import Version
        assert _parse_version("") == Version("0")
        assert _parse_version(None) == Version("0")
