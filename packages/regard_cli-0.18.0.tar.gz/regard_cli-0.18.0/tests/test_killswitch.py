"""Tests for regard killswitch command."""

import json
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from regard.main import app
from tests.conftest import load_fixture

# Spot token entries for known assets (USDC, USDH, USDE, USDT0) are derived from
# the golden fixture — Constitution Article IV forbids hand-authored shapes for
# real coins. See test_constitution_alignment.py for the guardrail.
_SPOT_GOLDEN = load_fixture("hyperliquid", "spot_meta")


def _spot_token(name: str) -> dict:
    for t in _SPOT_GOLDEN["tokens"]:
        if t["name"] == name:
            return dict(t)
    raise KeyError(f"{name} not in golden spot_meta.json tokens")

runner = CliRunner()


def _parse_json(result):
    """Extract JSON from runner output, skipping any stderr progress lines."""
    # Typer's CliRunner mixes stderr into output. Find the JSON line.
    for line in reversed(result.output.strip().splitlines()):
        line = line.strip()
        if line.startswith("{"):
            return json.loads(line)
    raise AssertionError(f"No JSON found in output: {result.output!r}")

# Patch paths — _kill_hl imports from these modules at call time
_C = "regard.venues.hyperliquid.client"
_R = "regard.venues.hyperliquid.resolver"
_K = "regard.commands.killswitch"


def test_killswitch_no_address():
    """killswitch dies with clear error when no KILLSWITCH_ADDRESS configured."""
    with patch(f"{_K}._get_killswitch_address", return_value=None):
        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 2
        data = _parse_json(result)
        assert data["ok"] is False
        assert data["error"]["code"] == "NO_KILLSWITCH_ADDRESS"
        assert "config" in data["error"]["hint"]


def test_killswitch_with_address_hl_no_positions():
    """killswitch succeeds with no positions/orders to close."""
    with patch(f"{_K}._get_killswitch_address", return_value="0x1234567890abcdef1234567890abcdef12345678"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_hl.return_value = {
            "cancelled_orders": 0,
            "closed_positions": [],
            "transferred": [],
        }
        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["ok"] is True
        assert data["data"]["destination"] == "0x1234567890abcdef1234567890abcdef12345678"
        assert data["data"]["hl"]["cancelled_orders"] == 0
        assert data["data"]["hl"]["closed_positions"] == []
        assert data["data"]["poly"]["skipped"] == "not configured"


def test_killswitch_hl_error_does_not_crash():
    """HL errors are caught and reported, poly still runs."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl", side_effect=Exception("connection failed")), \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["ok"] is True
        assert data["data"]["hl"]["error"] == "connection failed"
        assert data["data"]["poly"]["skipped"] == "not configured"


def test_killswitch_poly_error_does_not_crash():
    """Poly errors are caught and reported, HL still runs."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly", side_effect=Exception("geo-blocked")):

        mock_hl.return_value = {
            "cancelled_orders": 0,
            "closed_positions": [],
            "transferred": [],
        }

        result = runner.invoke(app, ["killswitch"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["ok"] is True
        assert data["data"]["hl"]["cancelled_orders"] == 0
        assert data["data"]["poly"]["error"] == "geo-blocked"


# ---------------------------------------------------------------------------
# Close logic tests — test _kill_hl internals with mocked SDK
# ---------------------------------------------------------------------------

def _mock_kill_hl(positions, close_response, orders=None):
    """Run _kill_hl with mocked SDK. Returns the result dict."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": "0"}
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info
    mock_exchange.market_close.return_value = close_response

    with patch(f"{_C}.get_exchange", return_value=mock_exchange), \
         patch(f"{_C}.get_address", return_value="0xaddr"), \
         patch(f"{_C}.get_all_positions", return_value=positions), \
         patch(f"{_C}.get_all_orders", return_value=orders or []), \
         patch(f"{_C}.get_spot_balances", return_value=[]), \
         patch(f"{_C}.get_dex_balances", return_value=[]), \
         patch(f"{_R}.get_resolver", return_value=MagicMock()):

        from regard.commands.killswitch import _kill_hl
        return _kill_hl("0xdest")


def test_close_filled():
    """Position close that fills reports avg_price and status."""
    result = _mock_kill_hl(
        positions=[{"coin": "BTC", "szi": "-0.1"}],
        close_response={"status": "ok", "response": {"data": {"statuses": [
            {"filled": {"totalSz": "0.1", "avgPx": "95100.5", "oid": 123}}
        ]}}},
    )
    closed = result["closed_positions"][0]
    assert closed["status"] == "filled"
    assert closed["avg_price"] == "95100.5"
    assert closed["side"] == "buy"


def test_close_error_from_exchange():
    """Exchange returns error status."""
    result = _mock_kill_hl(
        positions=[{"coin": "ETH", "szi": "1.0"}],
        close_response={"status": "err", "response": "Insufficient margin"},
    )
    closed = result["closed_positions"][0]
    assert "error" in closed
    assert "Insufficient margin" in closed["error"]


def test_close_ioc_expired():
    """IOC order expires without filling — resting instead of filled."""
    result = _mock_kill_hl(
        positions=[{"coin": "SOL", "szi": "-10.0"}],
        close_response={"status": "ok", "response": {"data": {"statuses": [
            {"resting": {"oid": 456}}
        ]}}},
    )
    closed = result["closed_positions"][0]
    assert "error" in closed
    assert "no fill" in closed["error"]


def test_close_order_error_in_status():
    """Exchange returns error inside statuses array."""
    result = _mock_kill_hl(
        positions=[{"coin": "xyz:NATGAS", "szi": "-12.0"}],
        close_response={"status": "ok", "response": {"data": {"statuses": [
            {"error": "reduce only order would increase position"}
        ]}}},
    )
    closed = result["closed_positions"][0]
    assert closed["error"] == "reduce only order would increase position"


def test_close_market_close_returns_none():
    """market_close returns None when position not found by SDK."""
    result = _mock_kill_hl(
        positions=[{"coin": "UNKNOWN", "szi": "5.0"}],
        close_response=None,
    )
    closed = result["closed_positions"][0]
    assert "not found" in closed["error"]


def test_close_zero_position_skipped():
    """Positions with szi=0 are skipped."""
    result = _mock_kill_hl(
        positions=[{"coin": "BTC", "szi": "0.0"}],
        close_response=None,
    )
    assert result["closed_positions"] == []


def test_close_exception_caught():
    """SDK exception during market_close is caught and reported."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": "0"}
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info
    mock_exchange.market_close.side_effect = Exception("connection reset")

    with patch(f"{_C}.get_exchange", return_value=mock_exchange), \
         patch(f"{_C}.get_address", return_value="0xaddr"), \
         patch(f"{_C}.get_all_positions", return_value=[{"coin": "BTC", "szi": "0.5"}]), \
         patch(f"{_C}.get_all_orders", return_value=[]), \
         patch(f"{_C}.get_spot_balances", return_value=[]), \
         patch(f"{_C}.get_dex_balances", return_value=[]), \
         patch(f"{_R}.get_resolver", return_value=MagicMock()):

        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")

    closed = result["closed_positions"][0]
    assert closed["error"] == "connection reset"
    assert closed["side"] == "sell"


# ---------------------------------------------------------------------------
# Transfer logic tests — unified and legacy accounts
# ---------------------------------------------------------------------------

_USDC = _spot_token("USDC")
_USDH = _spot_token("USDH")
_USDE = _spot_token("USDE")
_USDT0 = _spot_token("USDT0")

SPOT_META = {
    "tokens": [_USDC, _USDH, _USDE, _USDT0],
}


COLLATERAL_MAP = {
    "": (_USDC["name"], _USDC["index"]),
    "xyz": (_USDC["name"], _USDC["index"]),
    "para": (_USDC["name"], _USDC["index"]),
    "flx": (_USDH["name"], _USDH["index"]),
    "vntl": (_USDH["name"], _USDH["index"]),
    "km": (_USDH["name"], _USDH["index"]),
    "hyna": (_USDE["name"], _USDE["index"]),
    "cash": (_USDT0["name"], _USDT0["index"]),
}


def _make_transfer_mocks(account_mode="unifiedAccount", spot_balances=None, dex_balances=None, withdrawable="0"):
    """Create mocks for transfer logic tests."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": withdrawable}
    mock_info.spot_meta.return_value = SPOT_META
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info
    mock_exchange.market_close.return_value = None  # no positions to close
    mock_exchange.send_asset.return_value = {"status": "ok", "response": {"type": "default"}}
    mock_exchange.spot_transfer.return_value = {"status": "ok"}

    # Simulate real-world state transition: after usd_transfer, withdrawable drops to 0.
    # Required for the step 3e (final perp sweep) to not double-send in tests with
    # static mocks. Matches on-chain behavior where funds leave the perp account.
    def _usd_transfer_zero_out(*_args, **_kwargs):
        mock_info.user_state.return_value = {"withdrawable": "0"}
        return {"status": "ok"}
    mock_exchange.usd_transfer.side_effect = _usd_transfer_zero_out

    return mock_info, mock_exchange, [
        patch(f"{_C}.get_exchange", return_value=mock_exchange),
        patch(f"{_C}.get_address", return_value="0xaddr"),
        patch(f"{_C}.get_all_positions", return_value=[]),
        patch(f"{_C}.get_all_orders", return_value=[]),
        patch(f"{_C}.get_spot_balances", return_value=spot_balances or []),
        patch(f"{_C}.get_dex_balances", return_value=dex_balances or []),
        patch(f"{_C}.get_account_mode", return_value=account_mode),
        patch(f"{_C}.get_collateral_map", return_value=dict(COLLATERAL_MAP)),
        patch(f"{_R}.get_resolver", return_value=MagicMock()),
    ]


def test_unified_transfer_uses_send_asset():
    """Unified account uses send_asset(dest, 'spot', 'spot', ...) for transfers."""
    _, mock_exchange, patches = _make_transfer_mocks(
        spot_balances=[
            {"token": "USDC", "balance": "25.00", "token_index": 0},
            {"token": "USDH", "balance": "15.00", "token_index": 360},
        ],
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    assert len(result["transferred"]) == 2
    # USDC uses plain name (canonical)
    mock_exchange.send_asset.assert_any_call("0xdest", "spot", "spot", "USDC", 24.99)
    # USDH uses TOKEN:tokenId format (non-canonical)
    mock_exchange.send_asset.assert_any_call("0xdest", "spot", "spot", f"USDH:{_USDH['tokenId']}", 14.99)
    # spot_transfer should NOT be called on unified accounts
    mock_exchange.spot_transfer.assert_not_called()
    mock_exchange.usd_transfer.assert_not_called()


def test_unified_transfer_dust_buffer():
    """Large balances get dust buffer deducted, sub-cent dust skipped."""
    _, mock_exchange, patches = _make_transfer_mocks(
        spot_balances=[
            {"token": "USDC", "balance": "50.00", "token_index": 0},  # > 0.02 → dust buffer applied
            {"token": "USDH", "balance": "0.005", "token_index": 360},  # ≤ 0.02 → skipped (dust)
        ],
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    transfers = result["transferred"]
    # USDC: 50.00 - 0.01 dust = 49.99
    assert transfers[0]["amount"] == 49.99
    # USDH: 0.005 skipped — sub-cent dust not worth API call
    assert len(transfers) == 1


def test_unified_transfer_send_asset_error():
    """send_asset error on unified account is reported, doesn't crash."""
    _, mock_exchange, patches = _make_transfer_mocks(
        spot_balances=[{"token": "USDC", "balance": "10.00", "token_index": 0}],
    )
    mock_exchange.send_asset.return_value = {"status": "err", "response": "Insufficient balance"}
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    assert result["transferred"][0]["error"] == "Insufficient balance"


def test_legacy_transfer_uses_usd_and_spot_transfer():
    """Legacy account uses usd_transfer for perp USDC and spot_transfer for spot tokens."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        spot_balances=[{"token": "USDH", "balance": "5.00", "token_index": 360}],
        withdrawable="100.50",
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    mock_exchange.usd_transfer.assert_called_once_with(100.50, "0xdest")
    # spot_transfer uses NAME:tokenId for non-canonical tokens + dust buffer
    mock_exchange.spot_transfer.assert_called_once_with(4.99, "0xdest", f"USDH:{_USDH['tokenId']}")
    mock_exchange.send_asset.assert_not_called()


def test_legacy_hip3_dex_consolidated_on_master_key():
    """Master key consolidates HIP-3 dex balances via send_asset."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        dex_balances=[
            {"dex": "default", "account_value": "0", "positions": 0},
            {"dex": "xyz", "account_value": "20.0", "positions": 0},
        ],
        withdrawable="0",
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    consolidated = [t for t in result["transferred"] if t.get("consolidated")]
    assert len(consolidated) == 1
    assert consolidated[0]["source"] == "dex:xyz"
    # send_asset routes to "spot", not default perp
    mock_exchange.send_asset.assert_called_once()
    call_args = mock_exchange.send_asset.call_args[0]
    assert call_args[1] == "xyz"    # source dex
    assert call_args[2] == "spot"   # destination


def test_legacy_hip3_non_usdc_consolidation():
    """Non-USDC HIP-3 dex (flx→USDH) consolidates to spot with correct token format."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        dex_balances=[
            {"dex": "default", "account_value": "0", "positions": 0},
            {"dex": "flx", "account_value": "75.0", "positions": 0},
        ],
        withdrawable="0",
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    consolidated = [t for t in result["transferred"] if t.get("consolidated")]
    assert len(consolidated) == 1
    assert consolidated[0]["source"] == "dex:flx"
    assert consolidated[0]["token"] == "USDH"
    # send_asset must use NAME:tokenId format and route to "spot"
    mock_exchange.send_asset.assert_called_once()
    call_args = mock_exchange.send_asset.call_args[0]
    assert call_args[1] == "flx"
    assert call_args[2] == "spot"
    assert call_args[3] == f"USDH:{_USDH['tokenId']}"


def test_legacy_hip3_mixed_dex_collateral():
    """Multiple HIP-3 dexes with different collateral types consolidate correctly."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        dex_balances=[
            {"dex": "default", "account_value": "0", "positions": 0},
            {"dex": "xyz", "account_value": "30.0", "positions": 0},
            {"dex": "flx", "account_value": "50.0", "positions": 0},
        ],
        spot_balances=[{"token": "USDC", "balance": "10.00", "token_index": 0}],
        withdrawable="0",
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    consolidated = [t for t in result["transferred"] if t.get("consolidated")]
    assert len(consolidated) == 2
    dexes = {c["source"] for c in consolidated}
    assert "dex:xyz" in dexes
    assert "dex:flx" in dexes

    # Both send to "spot"
    for call in mock_exchange.send_asset.call_args_list:
        assert call[0][2] == "spot"

    # Spot sweep runs after consolidation
    spot_transfers = [t for t in result["transferred"] if t.get("source") == "spot"]
    assert len(spot_transfers) >= 1  # at least the pre-existing USDC


def test_legacy_hip3_all_non_usdc_collateral_types():
    """All non-USDC collateral types (USDH, USDE, USDT0) consolidate with correct token format."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        dex_balances=[
            {"dex": "default", "account_value": "0", "positions": 0},
            {"dex": "flx", "account_value": "40.0", "positions": 0},   # USDH
            {"dex": "hyna", "account_value": "30.0", "positions": 0},  # USDE
            {"dex": "cash", "account_value": "20.0", "positions": 0},  # USDT0
        ],
        withdrawable="0",
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    consolidated = [t for t in result["transferred"] if t.get("consolidated")]
    assert len(consolidated) == 3

    # Verify each dex used the right collateral token
    by_source = {c["source"]: c for c in consolidated}
    assert by_source["dex:flx"]["token"] == "USDH"
    assert by_source["dex:hyna"]["token"] == "USDE"
    assert by_source["dex:cash"]["token"] == "USDT0"

    # Verify send_asset used NAME:tokenId format for all
    assert mock_exchange.send_asset.call_count == 3
    token_args = {call[0][3] for call in mock_exchange.send_asset.call_args_list}
    assert f"USDH:{_USDH['tokenId']}" in token_args
    assert f"USDE:{_USDE['tokenId']}" in token_args
    assert f"USDT0:{_USDT0['tokenId']}" in token_args

    # All routed to "spot"
    for call in mock_exchange.send_asset.call_args_list:
        assert call[0][2] == "spot"


def test_legacy_hip3_dry_run():
    """Dry run reports consolidation without executing."""
    _, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        dex_balances=[
            {"dex": "default", "account_value": "0", "positions": 0},
            {"dex": "flx", "account_value": "25.0", "positions": 0},
        ],
        withdrawable="0",
    )
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest", dry_run=True)
    finally:
        for p in patches:
            p.stop()

    consolidated = [t for t in result["transferred"] if t.get("consolidated")]
    assert len(consolidated) == 1
    assert consolidated[0]["status"] == "dry_run"
    # No actual API calls
    mock_exchange.send_asset.assert_not_called()
    mock_exchange.spot_transfer.assert_not_called()


def test_cancel_orders_flow():
    """Cancel orders calls bulk_cancel with correct format."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": "0"}
    mock_info.spot_meta.return_value = SPOT_META
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info
    mock_exchange.bulk_cancel.return_value = {"status": "ok"}

    orders = [
        {"coin": "BTC", "oid": 123},
        {"coin": "ETH", "oid": 456},
        {"coin": "xyz:TSLA", "oid": 789},
    ]

    with patch(f"{_C}.get_exchange", return_value=mock_exchange), \
         patch(f"{_C}.get_address", return_value="0xaddr"), \
         patch(f"{_C}.get_all_positions", return_value=[]), \
         patch(f"{_C}.get_all_orders", return_value=orders), \
         patch(f"{_C}.get_spot_balances", return_value=[]), \
         patch(f"{_C}.get_dex_balances", return_value=[]), \
         patch(f"{_C}.get_account_mode", return_value="default"), \
         patch(f"{_R}.get_resolver", return_value=MagicMock()):

        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")

    assert result["cancelled_orders"] == 3
    mock_exchange.bulk_cancel.assert_called_once()
    cancel_args = mock_exchange.bulk_cancel.call_args[0][0]
    assert len(cancel_args) == 3
    assert cancel_args[0] == {"coin": "BTC", "oid": 123}


def test_slippage_config_read():
    """_get_killswitch_slippage reads from settings."""
    from regard.commands.killswitch import _get_killswitch_slippage

    with patch(f"{_C}._load_settings_env", return_value={"KILLSWITCH_SLIPPAGE": "0.15"}):
        assert _get_killswitch_slippage() == 0.15

    with patch(f"{_C}._load_settings_env", return_value={}):
        assert _get_killswitch_slippage() == 0.10  # default

    with patch(f"{_C}._load_settings_env", return_value={"KILLSWITCH_SLIPPAGE": "garbage"}):
        assert _get_killswitch_slippage() == 0.10  # fallback on bad value

    with patch(f"{_C}._load_settings_env", return_value={"KILLSWITCH_SLIPPAGE": "10"}):
        assert _get_killswitch_slippage() == 0.10  # out of range, fallback

    with patch(f"{_C}._load_settings_env", return_value={"KILLSWITCH_SLIPPAGE": "0.0001"}):
        assert _get_killswitch_slippage() == 0.10  # too small, fallback

    with patch(f"{_C}._load_settings_env", return_value={"KILLSWITCH_SLIPPAGE": "0.5"}):
        assert _get_killswitch_slippage() == 0.5  # max allowed


def test_legacy_perp_final_error_surfaced():
    """Step 3e usd_transfer error is recorded, not silently swallowed."""
    mock_info, mock_exchange, patches = _make_transfer_mocks(
        account_mode="default",
        withdrawable="50.0",
    )
    # Master key (not agent)
    # First user_state returns withdrawable for step 3a, second for step 3e
    mock_info.user_state.side_effect = [
        {"withdrawable": "50.0"},  # step 3a — initial perp sweep
        {"withdrawable": "25.0"},  # step 3e — post-consolidation sweep (fails)
    ]
    mock_exchange.usd_transfer.side_effect = [
        {"status": "ok"},  # step 3a succeeds
        {"status": "err", "response": "rate limited"},  # step 3e fails
    ]
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest")
    finally:
        for p in patches:
            p.stop()

    perp_final = [t for t in result["transferred"] if t.get("source") == "perp_final"]
    assert len(perp_final) == 1
    assert perp_final[0]["error"] == "rate limited"
    assert "amount" not in perp_final[0]


# ---------------------------------------------------------------------------
# Poly CLOB close tests — exercises _kill_poly's create_market_order path
# ---------------------------------------------------------------------------

_P = "regard.venues.polymarket.client"


def _make_poly_mocks(positions, geo_ok=True, neg_risk_map=None):
    """Build mocks for _kill_poly with given positions."""
    mock_clob = MagicMock()
    mock_clob.create_market_order.return_value = {"signed": True}
    mock_clob.post_order.return_value = {"success": True, "status": "matched"}
    mock_clob.get_fee_rate_bps.return_value = 1000
    mock_web3 = MagicMock()
    mock_web3.eth.get_balance.return_value = 0
    patches = [
        patch(f"{_P}._get_key", return_value="0xdeadbeef"),
        patch(f"{_P}.check_geo_block"),
        patch(f"{_P}.get_clob_client", return_value=mock_clob),
        patch(f"{_P}.get_positions", return_value=positions),
        patch(f"{_P}.get_web3", return_value=mock_web3),
        patch(f"{_P}.lookup_neg_risk", return_value=neg_risk_map or {}),
    ]
    return mock_clob, mock_web3, patches


def test_poly_close_active_position_uses_market_order():
    """Active (non-redeemable, non-mergeable) position uses create_market_order."""
    positions = [{
        "asset_id": "token123",
        "condition_id": "cond456",
        "side": "BUY",
        "size": "10.0",
    }]
    mock_clob, _, patches = _make_poly_mocks(positions)
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_poly
        result = _kill_poly("0xdest")
    finally:
        for p in patches:
            p.stop()

    # create_market_order called with correct args
    mock_clob.create_market_order.assert_called_once()
    call_args = mock_clob.create_market_order.call_args[0][0]
    assert call_args.token_id == "token123"
    assert call_args.amount == 10.0
    # BUY position → close with SELL
    from py_clob_client_v2.order_builder.constants import SELL as CLOB_SELL
    assert call_args.side == CLOB_SELL
    # V2 orders: fees calculated match-time by exchange, not set on signed order
    assert not hasattr(call_args, "fee_rate_bps") or getattr(call_args, "fee_rate_bps", None) in (None, 0)

    # Posted as FOK
    from py_clob_client_v2.clob_types import OrderType
    mock_clob.post_order.assert_called_once()
    assert mock_clob.post_order.call_args[0][1] == OrderType.FOK

    # Result recorded
    closed = result["closed_positions"]
    assert len(closed) == 1
    assert closed[0]["side"] == "SELL"
    assert closed[0]["size"] == 10.0
    assert closed[0]["status"] == "filled"
    assert "error" not in closed[0]


def test_poly_close_fok_no_fill_recorded():
    """FOK order that returns 200 but doesn't fill is recorded as error."""
    positions = [{
        "asset_id": "token_nofill",
        "condition_id": "cond_nofill",
        "side": "BUY",
        "size": "5.0",
    }]
    mock_clob, _, patches = _make_poly_mocks(positions)
    mock_clob.post_order.return_value = {"success": True, "status": "live", "orderID": "0xabc"}
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_poly
        result = _kill_poly("0xdest")
    finally:
        for p in patches:
            p.stop()

    closed = result["closed_positions"]
    assert len(closed) == 1
    assert "error" in closed[0]
    assert "FOK not filled" in closed[0]["error"]


def test_poly_close_order_rejected_recorded():
    """post_order returning success=false is recorded as error."""
    positions = [{
        "asset_id": "token_reject",
        "condition_id": "cond_reject",
        "side": "BUY",
        "size": "5.0",
    }]
    mock_clob, _, patches = _make_poly_mocks(positions)
    mock_clob.post_order.return_value = {"success": False, "errorMsg": "insufficient liquidity"}
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_poly
        result = _kill_poly("0xdest")
    finally:
        for p in patches:
            p.stop()

    closed = result["closed_positions"]
    assert len(closed) == 1
    assert closed[0]["error"] == "insufficient liquidity"


def test_poly_close_market_order_failure_recorded():
    """create_market_order exception is caught and recorded, not raised."""
    positions = [{
        "asset_id": "token_fail",
        "condition_id": "cond789",
        "side": "BUY",
        "size": "5.0",
    }]
    mock_clob, _, patches = _make_poly_mocks(positions)
    mock_clob.create_market_order.side_effect = Exception("no match — empty book")
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_poly
        result = _kill_poly("0xdest")
    finally:
        for p in patches:
            p.stop()

    closed = result["closed_positions"]
    assert len(closed) == 1
    assert closed[0]["error"] == "no match — empty book"
    # post_order never called
    mock_clob.post_order.assert_not_called()


def test_poly_cancel_all_failure_surfaced():
    """cancel_all failure is recorded in result, does not crash killswitch."""
    positions = []
    mock_clob, _, patches = _make_poly_mocks(positions)
    mock_clob.cancel_all.side_effect = Exception("service unavailable")
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_poly
        result = _kill_poly("0xdest")
    finally:
        for p in patches:
            p.stop()

    assert "failed:" in result["cancelled_orders"]
    assert "service unavailable" in result["cancelled_orders"]


def test_poly_merge_uses_min_size_and_sells_residual():
    """Merge uses min(YES, NO) size, then market-sells residual shares."""
    positions = [
        {"asset_id": "yes_token", "condition_id": "cond1", "side": "BUY", "size": "10.0", "mergeable": True},
        {"asset_id": "no_token", "condition_id": "cond1", "side": "BUY", "size": "7.0", "mergeable": True},
    ]
    mock_clob, _, patches = _make_poly_mocks(positions)
    mock_merge = MagicMock(return_value={"action": "merge", "size": 7.0, "token_id": "yes_token"})
    patches.append(patch(f"{_K}._ctf_merge", mock_merge))
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_poly
        result = _kill_poly("0xdest")
    finally:
        for p in patches:
            p.stop()

    # _ctf_merge called once with min size (7.0), not first leg (10.0)
    mock_merge.assert_called_once()
    assert mock_merge.call_args[0][1] == 7.0  # size argument

    # Residual 3.0 YES shares market-sold via create_market_order
    mock_clob.create_market_order.assert_called_once()
    order_args = mock_clob.create_market_order.call_args[0][0]
    assert order_args.amount == 3.0  # 10.0 - 7.0

    closed = result["closed_positions"]
    # Two entries: merge + residual sell
    assert len(closed) == 2
    assert closed[0]["size"] == 7.0
    assert closed[0]["action"] == "merge"
    assert closed[1]["size"] == 3.0


def test_poly_merge_neg_risk_routes_through_adapter():
    """negRisk mergeable positions pass neg_risk=True to _ctf_merge."""
    positions = [
        {"asset_id": "yes_token", "condition_id": "cond_neg", "side": "BUY", "size": "5.0", "mergeable": True},
        {"asset_id": "no_token", "condition_id": "cond_neg", "side": "BUY", "size": "5.0", "mergeable": True},
    ]
    mock_clob, _, patches = _make_poly_mocks(positions, neg_risk_map={"cond_neg": True})
    mock_merge = MagicMock(return_value={"action": "merge", "size": 5.0, "token_id": "yes_token"})
    patches.append(patch(f"{_K}._ctf_merge", mock_merge))
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_poly
        result = _kill_poly("0xdest")
    finally:
        for p in patches:
            p.stop()

    mock_merge.assert_called_once_with("cond_neg", 5.0, "yes_token", neg_risk=True)
    closed = result["closed_positions"]
    assert len(closed) == 1
    assert closed[0]["action"] == "merge"


def test_poly_merge_binary_no_neg_risk():
    """Binary (non-negRisk) mergeable positions pass neg_risk=False."""
    positions = [
        {"asset_id": "yes_token", "condition_id": "cond_bin", "side": "BUY", "size": "5.0", "mergeable": True},
        {"asset_id": "no_token", "condition_id": "cond_bin", "side": "BUY", "size": "5.0", "mergeable": True},
    ]
    mock_clob, _, patches = _make_poly_mocks(positions, neg_risk_map={"cond_bin": False})
    mock_merge = MagicMock(return_value={"action": "merge", "size": 5.0, "token_id": "yes_token"})
    patches.append(patch(f"{_K}._ctf_merge", mock_merge))
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_poly
        result = _kill_poly("0xdest")
    finally:
        for p in patches:
            p.stop()

    mock_merge.assert_called_once_with("cond_bin", 5.0, "yes_token", neg_risk=False)
    closed = result["closed_positions"]
    assert len(closed) == 1
    assert closed[0]["action"] == "merge"


def test_poly_merge_neg_risk_lookup_failure_falls_back_to_binary():
    """If lookup_neg_risk raises, killswitch still merges (assumes binary)."""
    positions = [
        {"asset_id": "yes_token", "condition_id": "cond1", "side": "BUY", "size": "5.0", "mergeable": True},
        {"asset_id": "no_token", "condition_id": "cond1", "side": "BUY", "size": "5.0", "mergeable": True},
    ]
    mock_clob, _, patches = _make_poly_mocks(positions)
    # Override the lookup_neg_risk patch to raise
    for i, p in enumerate(patches):
        if hasattr(p, 'attribute') and p.attribute == 'lookup_neg_risk':
            patches.pop(i)
            break
    patches.append(patch(f"{_P}.lookup_neg_risk", side_effect=Exception("Gamma API down")))
    mock_merge = MagicMock(return_value={"action": "merge", "size": 5.0, "token_id": "yes_token"})
    patches.append(patch(f"{_K}._ctf_merge", mock_merge))
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_poly
        result = _kill_poly("0xdest")
    finally:
        for p in patches:
            p.stop()

    # Falls back to neg_risk=False (binary)
    mock_merge.assert_called_once_with("cond1", 5.0, "yes_token", neg_risk=False)
    closed = result["closed_positions"]
    assert len(closed) == 1
    assert closed[0]["action"] == "merge"


def test_poly_merge_failure_falls_back_to_clob_sell():
    """If merge tx reverts, both legs fall back to CLOB sell instead of stranding tokens."""
    positions = [
        {"asset_id": "yes_token", "condition_id": "cond1", "side": "BUY", "size": "5.0", "mergeable": True},
        {"asset_id": "no_token", "condition_id": "cond1", "side": "BUY", "size": "5.0", "mergeable": True},
    ]
    mock_clob, _, patches = _make_poly_mocks(positions)
    mock_merge = MagicMock(side_effect=RuntimeError("tx reverted"))
    patches.append(patch(f"{_K}._ctf_merge", mock_merge))
    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_poly
        result = _kill_poly("0xdest")
    finally:
        for p in patches:
            p.stop()

    # Both legs attempted merge, both failed, both fell back to CLOB sell
    assert mock_merge.call_count == 2
    assert mock_clob.create_market_order.call_count == 2
    closed = result["closed_positions"]
    # Each leg: merge error + CLOB sell = 4 entries
    merge_errors = [c for c in closed if c.get("action") == "merge" and "error" in c]
    sells = [c for c in closed if c.get("size") == 5.0 and "error" not in c and c.get("action") != "merge"]
    assert len(merge_errors) == 2
    assert len(sells) == 2


def test_poly_dry_run_pol_projection_includes_onchain_op_gas():
    """Dry-run POL transfer must subtract projected merge + ERC-20 gas, matching actual execution.

    Before the fix, dry-run only reserved POL-tx-own gas (21000×1.5) and ignored the
    gas that merges/redeems/ERC-20 transfers would consume. Result: projected POL
    transfer over-shot actual by 5-15% on cycles with on-chain ops.
    """
    # One mergeable YES+NO pair → 1 merge + 1 USDC.e ERC-20 transfer
    positions = [
        {"asset_id": "yes_token", "condition_id": "cond1", "side": "BUY", "size": "5.0", "mergeable": True},
        {"asset_id": "no_token", "condition_id": "cond1", "side": "BUY", "size": "5.0", "mergeable": True},
    ]
    mock_clob, mock_web3, patches = _make_poly_mocks(positions)

    # Fix POL balance + gas price so projected math is deterministic.
    pol_balance = int(0.3 * 1e18)
    gas_price = 25 * 10**9  # 25 gwei
    mock_web3.eth.get_balance.return_value = pol_balance
    mock_web3.eth.gas_price = gas_price
    # get_transaction_count for nonce — just return 0
    mock_web3.eth.get_transaction_count.return_value = 0

    # Patch the evm helpers the POL branch imports
    patches.append(patch("regard.core.evm.get_erc20_balance", return_value=0))  # USDC.e starts at 0, gets projected from merge
    patches.append(patch("regard.core.evm.get_safe_gas_price", return_value=gas_price))
    # Override the short stub key with a valid 32-byte test key (eth_account rejects shorter)
    patches.append(patch(f"{_P}._get_key", return_value="0x" + "11" * 32))

    for p in patches:
        p.start()
    try:
        from regard.commands.killswitch import _kill_poly
        result = _kill_poly("0xdest", dry_run=True)
    finally:
        for p in patches:
            p.stop()

    # Expected POL projection: pol_balance − (21000×1.5 + 1 merge ×150k + 1 ERC-20 ×100k) × gas_price
    expected_gas = (int(21000 * 1.5) + 150_000 + 100_000) * gas_price
    expected_send = pol_balance - expected_gas

    transferred = result["transferred"]
    pol_entries = [t for t in transferred if t.get("token") == "POL"]
    assert len(pol_entries) == 1
    # Accept tight tolerance (integer rounding)
    actual_send_wei = int(pol_entries[0]["amount"] * 1e18)
    assert abs(actual_send_wei - expected_send) < 10**12, (
        f"POL projection {actual_send_wei} differs from expected {expected_send} by more than 0.000001 POL"
    )


# ---------------------------------------------------------------------------
# Dry run tests
# ---------------------------------------------------------------------------

def test_dry_run_does_not_execute():
    """--dry-run reports what would happen without calling exchange methods."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl") as mock_hl, \
         patch(f"{_K}._kill_poly") as mock_poly:

        mock_hl.return_value = {
            "cancelled_orders": 2,
            "closed_positions": [{"asset": "BTC", "side": "sell", "size": 0.1, "status": "dry_run"}],
            "transferred": [{"source": "spot", "token": "USDC", "amount": 100, "status": "dry_run"}],
        }
        mock_poly.return_value = {"skipped": "not configured"}

        result = runner.invoke(app, ["killswitch", "--dry-run"])
        assert result.exit_code == 0
        data = _parse_json(result)
        assert data["data"]["dry_run"] is True
        # Verify _kill_hl was called with dry_run=True
        mock_hl.assert_called_once_with("0xdead", dry_run=True)


def test_dry_run_close_logic():
    """Dry run skips market_close and reports dry_run status."""
    mock_info = MagicMock()
    mock_info.user_state.return_value = {"withdrawable": "0"}
    mock_exchange = MagicMock()
    mock_exchange.info = mock_info

    with patch(f"{_C}.get_exchange", return_value=mock_exchange), \
         patch(f"{_C}.get_address", return_value="0xaddr"), \
         patch(f"{_C}.get_all_positions", return_value=[{"coin": "BTC", "szi": "-0.5"}]), \
         patch(f"{_C}.get_all_orders", return_value=[{"coin": "BTC", "oid": 123}]), \
         patch(f"{_C}.get_spot_balances", return_value=[]), \
         patch(f"{_C}.get_dex_balances", return_value=[]), \
         patch(f"{_R}.get_resolver", return_value=MagicMock()), \
         patch(f"{_C}.get_account_mode", return_value="default"):

        from regard.commands.killswitch import _kill_hl
        result = _kill_hl("0xdest", dry_run=True)

    # Orders counted but not cancelled
    assert result["cancelled_orders"] == 1
    mock_exchange.bulk_cancel.assert_not_called()

    # Position reported but not closed
    assert result["closed_positions"][0]["status"] == "dry_run"
    mock_exchange.market_close.assert_not_called()


# ---------------------------------------------------------------------------
# Contract tests — envelope shape, no tracebacks
# ---------------------------------------------------------------------------

def test_killswitch_no_address_envelope():
    """killswitch error produces valid JSON envelope with correct shape."""
    with patch(f"{_K}._get_killswitch_address", return_value=None):
        result = runner.invoke(app, ["killswitch"])
        assert "Traceback" not in result.output
        data = _parse_json(result)
        assert "ok" in data
        assert data["ok"] is False
        assert "error" in data
        assert "type" in data["error"]
        assert "code" in data["error"]
        assert "message" in data["error"]


def test_killswitch_success_envelope():
    """killswitch success produces valid JSON envelope with meta."""
    with patch(f"{_K}._get_killswitch_address", return_value="0xdead"), \
         patch(f"{_K}._kill_hl", return_value={"cancelled_orders": 0, "closed_positions": [], "transferred": []}), \
         patch(f"{_K}._kill_poly", return_value={"skipped": "not configured"}):

        result = runner.invoke(app, ["killswitch"])
        assert "Traceback" not in result.output
        data = _parse_json(result)
        assert data["ok"] is True
        assert "data" in data
        assert "meta" in data
        assert "timestamp" in data["meta"]


def test_killswitch_unknown_option_produces_json():
    """Unknown flags produce JSON error, not Rich/Click text."""
    result = runner.invoke(app, ["killswitch", "--nonexistent"])
    assert "Traceback" not in result.output
    data = _parse_json(result)
    assert data["ok"] is False


# ---------------------------------------------------------------------------
# Config integration tests
# ---------------------------------------------------------------------------

def test_config_show_includes_killswitch_address(tmp_path, monkeypatch):
    """config show surfaces killswitch_address field."""
    project = tmp_path / "project"
    project.mkdir()
    settings = project / ".claude" / "settings.local.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({"env": {"KILLSWITCH_ADDRESS": "0xdead"}}))
    monkeypatch.chdir(project)
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    result = runner.invoke(app, ["config", "show"])
    assert result.exit_code == 0
    data = _parse_json(result)
    ks = data["data"]["killswitch_address"]
    assert ks["current"] == "0xdead"
    assert ks["configured"] is True


def test_config_show_killswitch_not_configured(tmp_path, monkeypatch):
    """config show shows killswitch_address as null when not set."""
    settings = tmp_path / ".claude" / "settings.local.json"
    settings.parent.mkdir(parents=True)
    settings.write_text(json.dumps({"env": {}}))
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

    result = runner.invoke(app, ["config", "show"])
    data = _parse_json(result)
    ks = data["data"]["killswitch_address"]
    assert ks["configured"] is False
