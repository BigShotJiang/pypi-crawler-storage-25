import httpx

class ClozlyResponse:
    def __init__(self, data):
        self._url = data.get("generatedImageUrl")
        self.id = data.get("id")
        self.status = "succeeded"
        self.raw = data

    def url(self):
        return self._url


class Clozly:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = 'https://clozly.ru/api/module-VTON/tryon'

    async def run(self, product_id: str, user_photo_url: str, use_back_view: bool = False):
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
        
        payload = {
            'productId': product_id,
            'userPhotoUrl': user_photo_url,
            'useBackView': use_back_view
        }

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(self.base_url, headers=headers, json=payload)
                
                if not response.is_success:
                    error_text = response.text
                    raise Exception(f"Ошибка сервера ({response.status_code}): {error_text[:50]}")
                
                data = response.json()
                return ClozlyResponse(data)

        except Exception as err:
            raise Exception(f"Сетевая ошибка: {err}")