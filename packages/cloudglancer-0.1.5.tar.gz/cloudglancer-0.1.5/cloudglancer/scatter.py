"""Core scatter plotting functionality for 3D point clouds."""

from typing import Optional, List, Dict, Union
import plotly.express as px
import pandas as pd
import numpy as np
from plotly.graph_objects import Figure


def plot(
    points: np.ndarray,
    labels: Optional[np.ndarray] = None,
    label_map: Optional[Dict] = None,
    color_map: Optional[Union[List[str], Dict[str, str], float]] = None,
    batch_colors: Optional[List[str]] = None,
    size: float = 1.5,
    title: Optional[str] = None,
    aspectmode: Optional[str] = 'data'
) -> Figure:
    """
    Render an interactive 3D scatter plot using Plotly.

    Args:
        points (np.ndarray): Array of shape (n_points, 3) or (batch, n_points, 3)
            containing 3D coordinates. When a 3D array is provided, each batch element
            is rendered as a separate point cloud with a distinct color.
        labels (np.ndarray, optional): Array of labels for color grouping. When provided
            with label_map, enables discrete color mapping. Without label_map, creates
            a continuous color scale. Not supported for batched input.
        label_map (dict, optional): Maps label values to display names. When provided,
            enables discrete color mapping.
        color_map (list, dict, or float, optional): When label_map is provided, a
            {display_name: color} dict (preferred) or a list of color strings aligned
            with label_map values for discrete coloring. Without label_map, this can be
            a float specifying the continuous color scale midpoint.
        batch_colors (list, optional): List of color strings, one per batch element.
            Only used when points is 3D. Defaults to Plotly's qualitative palette.
        size (float, optional): Size of the scatter plot markers. Default is 1.5.
        title (str, optional): Title of the plot.
        aspectmode (str, optional): Aspect ratio mode for the 3D scene. Default is 'data' (Check plotly docs for available modes).

    Returns:
        plotly.graph_objects.Figure: Interactive 3D scatter plot.

    Raises:
        ValueError: If points array shape is invalid or incompatible options are used.

    Examples:
        Basic scatter plot:
        >>> import numpy as np
        >>> points = np.random.randn(100, 3)
        >>> fig = plot(points, title="Random Points")
        >>> fig.show()

        Plot with categorical labels:
        >>> labels = np.random.choice([0, 1, 2], size=100)
        >>> label_map = {0: "Class A", 1: "Class B", 2: "Class C"}
        >>> color_map = ["red", "blue", "green"]
        >>> fig = plot(points, labels=labels, label_map=label_map, color_map=color_map)
        >>> fig.show()

        Batched point clouds:
        >>> points = np.random.randn(3, 100, 3)
        >>> fig = plot(points, batch_colors=["red", "green", "blue"])
        >>> fig.show()
    """
    if points.ndim == 3:
        B, N, D = points.shape
        if D != 3:
            raise ValueError("points must be of shape (B, N, 3)")
        if labels is not None:
            raise ValueError("labels are not supported for batched point clouds")

        flat_points = points.reshape(-1, 3)
        batch_labels = np.repeat(np.arange(B), N).astype(str)

        if batch_colors is None:
            batch_colors = px.colors.qualitative.Plotly[:B]

        df = pd.DataFrame(flat_points, columns=["x", "y", "z"])
        df["batch"] = batch_labels
        fig = px.scatter_3d(df, x="x", y="y", z="z", color="batch",
                            color_discrete_sequence=batch_colors)
    else:
        if points.shape[1] != 3:
            raise ValueError("points must be of shape (n_points, 3)")

        # Create a DataFrame for easier plotting
        df = pd.DataFrame(points, columns=["x", "y", "z"])

        if labels is not None:
            df["label"] = labels
            if label_map:
                df["label"] = df["label"].map(label_map).fillna(df["label"])
                category_orders = {"label": list(label_map.values())}
                if isinstance(color_map, dict):
                    discrete_map = color_map
                elif isinstance(color_map, list):
                    discrete_map = dict(zip(label_map.values(), color_map))
                else:
                    discrete_map = None
                fig = px.scatter_3d(
                    df, x="x", y="y", z="z", color="label",
                    color_discrete_map=discrete_map,
                    category_orders=category_orders,
                )
            else:
                fig = px.scatter_3d(df, x="x", y="y", z="z", color="label",
                                  color_continuous_midpoint=color_map, range_color=[0, 1])
        else:
            fig = px.scatter_3d(df, x="x", y="y", z="z")

    fig.update_traces(marker=dict(size=size))

    fig.update_layout(
        scene=dict(
            aspectmode=aspectmode
        )
    )

    if title:
        fig.update_layout(title=title)

    return fig


def combine_plots(figs: List[Figure], rows: int = 1, cols: int = 2, aspectmode: Optional[str] = 'data') -> Figure:
    """
    Combine multiple 3D plots into a single figure with subplots.

    Args:
        figs (list): List of Plotly figures to combine.
        rows (int, optional): Number of rows in the subplot grid. Default is 1.
        cols (int, optional): Number of columns in the subplot grid. Default is 2.
        aspectmode (str, optional): Aspect ratio mode for the 3D scene. Default is 'data' (Check plotly docs for available modes).

    Returns:
        plotly.graph_objects.Figure: Combined figure with all plots arranged in a grid.

    Raises:
        ValueError: If the number of figures doesn't match rows * cols.

    Examples:
        Combine two plots side by side:
        >>> points1 = np.random.randn(100, 3)
        >>> points2 = np.random.randn(100, 3) + 5
        >>> fig1 = plot(points1, title="Dataset 1")
        >>> fig2 = plot(points2, title="Dataset 2")
        >>> combined = combine_plots([fig1, fig2], rows=1, cols=2)
        >>> combined.show()
    """
    from plotly.subplots import make_subplots

    # Fix: Validate figure count
    if len(figs) != rows * cols:
        raise ValueError(
            f"Number of figures ({len(figs)}) must equal rows * cols ({rows * cols})"
        )

    # Fix: Generate specs dynamically based on rows and cols
    specs = [[{"type": "scene"} for _ in range(cols)] for _ in range(rows)]

    combined_fig = make_subplots(
        rows=rows, cols=cols,
        specs=specs
    )

    for i, fig in enumerate(figs):
        for trace in fig.data:
            combined_fig.add_trace(trace, row=(i // cols) + 1, col=(i % cols) + 1)

    scene_updates = {}
    for i in range(len(figs)):
        key = "scene" if i == 0 else f"scene{i + 1}"
        scene_updates[key] = dict(aspectmode=aspectmode)

    combined_fig.update_layout(**scene_updates,
        margin=dict(l=0, r=0, t=0, b=0)
    )

    return combined_fig
