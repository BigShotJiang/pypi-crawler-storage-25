"""Packaged baseline workspace assets."""
