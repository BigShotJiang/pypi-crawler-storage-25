import random
import sys
import chess
import copy
def evaluate_material(board):
    if board.is_checkmate():
        # If it's checkmate, return ±infinity based on who won
        return float('-inf') if board.turn else float('inf')

    piece_values = {
        chess.PAWN: 100,
        chess.KNIGHT: 300,
        chess.BISHOP: 300,
        chess.ROOK: 500,
        chess.QUEEN: 900
    }

    white_score = 0
    black_score = 0
    white_bishops = 0
    black_bishops = 0

    for square, piece in board.piece_map().items():
        value = piece_values.get(piece.piece_type, 0)
        if piece.color == chess.WHITE:
            white_score += value
            if piece.piece_type == chess.BISHOP:
                white_bishops += 1
        else:
            black_score += value
            if piece.piece_type == chess.BISHOP:
                black_bishops += 1

    # Bishop pair bonus
    if white_bishops >= 2:
        white_score += 50
    if black_bishops >= 2:
        black_score += 50

    return white_score - black_score
def normalize_fen(fen):
    parts = fen.split(" ")
    return parts[0]

position_history = []

def legal_moves_without_threefold_repetition(board):
    global position_history
    legal_moves = []
    
    for move in board.legal_moves:
        board.push(move)
        normalized_fen = normalize_fen(board.fen())
        if position_history.count(normalized_fen) > 1 or board.halfmove_clock > 10 or board.is_stalemate():
            board.pop()  # Undo the move
            continue  # Skip this move
        
        legal_moves.append(move)
        
        board.pop()  # Undo the move

    return legal_moves

def negamax_capture_pv(board, depth, alpha=float("-inf"), beta=float("inf"), loc=None):
    if depth == 0 or board.is_game_over():
        return colorsign(board) * evaluate_material(board), []

    max_eval = float("-inf")
    best_line = []

    # Capture moves
    for move in legal_moves_without_threefold_repetition(board):
        if board.is_capture(move) and (loc is None or loc == move.to_square):
            board.push(move)
            score, line = negamax_capture_pv(board, depth - 1, -beta, -alpha, move.to_square)
            board.pop()

            score = -score
            if score > max_eval:
                max_eval = score
                best_line = [move] + line
            alpha = max(alpha, score)
            if alpha >= beta:
                break  # Beta cutoff

    # Quiet moves at depth 0
    for move in legal_moves_without_threefold_repetition(board):
        if not board.is_capture(move):
            board.push(move)
            score, line = negamax_capture_pv(board, 0, -beta, -alpha)
            board.pop()

            score = -score
            if score > max_eval:
                max_eval = score
                best_line = [move] + line
            alpha = max(alpha, score)
            if alpha >= beta:
                break  # Beta cutoff

    if max_eval == float("-inf"):
        return colorsign(board) * evaluate_material(board), []

    return max_eval, best_line



def colorsign(board):
    return 1 if board.turn == chess.WHITE else -1

PST = {
    chess.PAWN: [
         0,  0,  0,  0,  0,  0,  0,  0,
         5,  5,  5,  5,  5,  5,  5,  5,
         1,  1,  2,  3,  3,  2,  1,  1,
         0,  0,  0,  2,  2,  0,  0,  0,
         0,  0,  0, -2, -2,  0,  0,  0,
         1, -1, -2,  0,  0, -2, -1,  1,
         1,  2,  2, -2, -2,  2,  2,  1,
         0,  0,  0,  0,  0,  0,  0,  0
    ],

    chess.KNIGHT: [
        -5, -4, -3, -3, -3, -3, -4, -5,
        -4, -2,  0,  0,  0,  0, -2, -4,
        -3,  0,  1,  1.5, 1.5, 1,  0, -3,
        -3,  0.5, 1.5, 2,  2,  1.5, 0.5, -3,
        -3,  0,  1.5, 2,  2,  1.5, 0, -3,
        -3,  0.5, 1,  1.5, 1.5, 1,  0.5, -3,
        -4, -2,  0,  0.5, 0.5, 0, -2, -4,
        -5, -4, -3, -3, -3, -3, -4, -5
    ],

    chess.BISHOP: [
        -2, -1, -1, -1, -1, -1, -1, -2,
        -1, 0,  0,  0,  0,  0,  0, -1,
        -1, 0,  0.5, 1,  1,  0.5, 0, -1,
        -1, 0.5, 0.5, 1,  1,  0.5, 0.5, -1,
        -1, 0,  1,  1,  1,  1,  0, -1,
        -1, 1,  1,  1,  1,  1,  1, -1,
        -1, 0.5, 0,  0,  0,  0,  0.5, -1,
        -2, -1, -1, -1, -1, -1, -1, -2
    ],

    chess.ROOK: [
         0,  0,  0,  0,  0,  0,  0,  0,
         0.5, 1,  1,  1,  1,  1,  1,  0.5,
        -0.5, 0,  0,  0,  0,  0,  0, -0.5,
        -0.5, 0,  0,  0,  0,  0,  0, -0.5,
        -0.5, 0,  0,  0,  0,  0,  0, -0.5,
        -0.5, 0,  0,  0,  0,  0,  0, -0.5,
        -0.5, 0,  0,  0,  0,  0,  0, -0.5,
         0,  0,  0,  0.5, 0.5,  0,  0,  0
    ],

    chess.QUEEN: [
        -2, -1, -1, -0.5, -0.5, -1, -1, -2,
        -1, 0,  0,  0,  0,  0,  0, -1,
        -1, 0,  0.5, 0.5, 0.5, 0.5,  0, -1,
        -0.5, 0,  0.5, 0.5, 0.5, 0.5,  0, -0.5,
         0,  0,  0.5, 0.5, 0.5, 0.5,  0, -0.5,
        -1, 0.5, 0.5, 0.5, 0.5, 0.5,  0, -1,
        -1, 0,  0.5, 0,  0,  0,  0, -1,
        -2, -1, -1, -0.5, -0.5, -1, -1, -2
    ],

    chess.KING: [
        -3, -4, -4, -5, -5, -4, -4, -3,
        -3, -4, -4, -5, -5, -4, -4, -3,
        -3, -4, -4, -5, -5, -4, -4, -3,
        -3, -4, -4, -5, -5, -4, -4, -3,
        -2, -3, -3, -4, -4, -3, -3, -2,
        -1, -2, -2, -2, -2, -2, -2, -1,
         2,  2,  0,  0,  0,  0,  2,  2,
         2,  3,  1,  0,  0,  1,  3,  2
    ]
}


# Get PST value depending on piece color
def pst_value(piece_type, square, color):
    if piece_type not in PST:
        return 0
    index = square if color == chess.WHITE else chess.square_mirror(square)
    return PST[piece_type][index]

# Sort legal moves by PST score
def sort_moves_by_pst(board):
    legal_moves = list(legal_moves_without_threefold_repetition(board))

    def move_score(move):
        piece = board.piece_at(move.from_square)
        if piece is None:
            return 0
        return pst_value(piece.piece_type, move.to_square, piece.color)

    return sorted(legal_moves, key=move_score, reverse=True)


def try_center_push(board):
    sorted_moves = sort_moves_by_pst(board)
    lst = []
    for move in sorted_moves:
        board2 = copy.deepcopy(board)
        board2.push(move)
        tmp, line = negamax_capture_pv(board2, 100)
        lst.append([move, tmp])
        print(line)
        print(tmp)
        print(evaluate_material(board))
        if board.turn == chess.BLACK and -tmp - evaluate_material(board) >= 0:
            return move
        if board.turn == chess.WHITE and -tmp - evaluate_material(board) >= 0:
            return move
    if lst == []:
        return None
    return sorted(lst, key=lambda x: x[1])[0][0]


def king_search(board, depth=2, alpha=float("-inf"), beta=float("inf")):

    if depth == 0 or board.is_game_over():
        return colorsign(board) * evaluate_material(board), []

    max_eval = float("-inf")
    best_line = []

    if depth == 2:
        legal = [move for move in legal_moves_without_threefold_repetition(board) if board.gives_check(move)]
    else:
        legal = list(legal_moves_without_threefold_repetition(board))
    
    for move in legal:
        board.push(move)
        score, line = None, None
        if depth == 1:
            score, line = negamax_capture_pv(board, 100, -beta, -alpha)
        else:
            score, line = king_search(board, depth - 1, -beta, -alpha)
        board.pop()

        score = -score
        if score > max_eval:
            max_eval = score
            best_line = [move] + line

        alpha = max(alpha, score)
        if alpha >= beta:
            break  # Beta cutoff

    if max_eval == float("-inf"):
        return colorsign(board) * evaluate_material(board), []

    return max_eval, best_line


'''
board = chess.Board()

fen = "r1b1kbnr/1pp1pppp/n7/p2q4/3P4/5N2/PPP2PPP/RNBQKB1R w KQkq - 0 1"
fen = "r1bk1bnr/1pNp1ppp/2n2q2/p3p3/4P3/5N2/PPPP1PPP/R1BQKB1R w KQkq - 0 1"
board.set_fen(fen)

print(board)
print(evaluate_material(board))
print()
print()

position startpos moves e2e3 g8f6 d2d3 f6e4 d3e4 b8c6
position startpos moves e2e3 g8f6 d2d3 f6e4 d3e4 b8c6 f2f3 d7d5
position startpos moves e2e3 g8f6 d2d3 f6e4 d3e4 b8c6 f2f3 d7d5 d1d5 d8d5 e4d5 c8d7 d5c6 d7c6 e3e4 e8c8 c2c3 e7e5
'''

def playmove2(board):
    
    score, line = king_search(board)
    if board.turn == chess.WHITE and score - evaluate_material(board) > 0:
        
        return line[0]
    elif board.turn == chess.BLACK and score - evaluate_material(board) > 0:
        
        return line[0]
    
    score, line = negamax_capture_pv(board, 100)
    if board.turn == chess.WHITE and score - evaluate_material(board) > 0:
        return line[0]
    elif board.turn == chess.BLACK and score - evaluate_material(board) > 0:
        
        return line[0]
        
    tmp = try_center_push(board)
        
    if tmp is not None:
        return tmp
    return random.choice(list(board.legal_moves))

def playmove(board):
    tmp = playmove2(board)
    if tmp is None:
        return None
    # Return the new board after applying the move from playmove2
    board.push(tmp)
    return board

def uci_loop():
    global position_history
    board = chess.Board()

    while True:
        try:
            command = input().strip()
        except EOFError:
            break

        if command == "uci":
            print("id name MyEngine")
            print("id author You")
            print("uciok")
        elif command == "isready":
            print("readyok")
        elif command.startswith("position"):
            tokens = command.split()
            board = chess.Board()
            position_history = []
            if "startpos" in tokens:
                moves_index = tokens.index("moves") if "moves" in tokens else None
                if moves_index:
                    for move in tokens[moves_index + 1:]:
                        board.push_uci(move)
                        position_history.append(normalize_fen(board.fen()))
            # You can also add support for "fen" if needed to initialize the board
        elif command.startswith("go"):
            new_board = playmove(board)
            if new_board:
                move = new_board.peek()  # Get the most recent move after playing the move
                print(f"bestmove {move}")
            else:
                print("bestmove 0000")
        elif command == "quit":
            break

if __name__ == "__main__":
    uci_loop()

