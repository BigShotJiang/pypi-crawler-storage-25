from setuptools import setup, find_packages

setup(
    name="rust_lob_pratima",
    version="0.1.1",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        'console_scripts': [
            'rust_lob_pratima = rust_lob_pratima.cli:main',
        ]
    },
    description="Run Rust Orderbook via Python CLI",
    author="Your Name",
    author_email="your@email.com",
    url="https://github.com/YOUR_GITHUB_USER/YOUR_REPO",
    include_package_data=True,
    python_requires=">=3.6",
)