"""Tests for Claude Switch."""
