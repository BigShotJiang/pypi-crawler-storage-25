"""Exception types raised by the Amaneki client."""

from __future__ import annotations


class AmanekiError(Exception):
    """Base class for all client errors."""

    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class AuthError(AmanekiError):
    """HTTP 401 — missing or invalid API key."""


class NotFoundError(AmanekiError):
    """HTTP 404 — symbol not tracked."""


class RateLimitError(AmanekiError):
    """HTTP 429 — rate limit exceeded."""

    def __init__(self, message: str, *, retry_after: int | None = None) -> None:
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class ServerError(AmanekiError):
    """HTTP 5xx — upstream failure."""
