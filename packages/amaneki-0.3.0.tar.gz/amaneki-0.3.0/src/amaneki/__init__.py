"""Amaneki Python client.

    from amaneki import Client

    c = Client(api_key="ak_...")
    r = c.get_regime("btcusdt")
    print(r.regime, r.z_vol)

Async usage:

    async with AsyncClient(api_key="ak_...") as c:
        async for ev in c.stream():
            print(ev)
"""

from amaneki._client import AsyncClient, Client
from amaneki._errors import (
    AmanekiError,
    AuthError,
    NotFoundError,
    RateLimitError,
    ServerError,
)
from amaneki._types import (
    BacktestResult,
    BacktestTrade,
    Consensus,
    IvGap,
    MarketCorrelation,
    RegimeSnapshot,
    RegimeTransition,
    StreamEvent,
    SymbolCorrelation,
    VenueSnapshot,
    WebhookSubscription,
)

__all__ = [
    "AmanekiError",
    "AsyncClient",
    "AuthError",
    "BacktestResult",
    "BacktestTrade",
    "Client",
    "Consensus",
    "IvGap",
    "MarketCorrelation",
    "NotFoundError",
    "RateLimitError",
    "RegimeSnapshot",
    "RegimeTransition",
    "ServerError",
    "StreamEvent",
    "SymbolCorrelation",
    "VenueSnapshot",
    "WebhookSubscription",
]

__version__ = "0.3.0"
