"""Async + sync HTTP/WS clients."""

from __future__ import annotations

import asyncio
import json
from collections.abc import AsyncIterator, Iterator
from types import TracebackType
from typing import Any

import httpx

from amaneki._errors import (
    AmanekiError,
    AuthError,
    NotFoundError,
    RateLimitError,
    ServerError,
)
from amaneki._types import (
    BacktestResult,
    Consensus,
    IvGap,
    MarketCorrelation,
    RegimeSnapshot,
    RegimeTransition,
    StreamEvent,
    SymbolCorrelation,
    WebhookSubscription,
)

_DEFAULT_BASE = "https://api.amaneki.com/v1"
_DEFAULT_TIMEOUT = 10.0
_USER_AGENT = "amaneki-py/0.1.0"


def _raise_for_status(r: httpx.Response) -> None:
    if r.status_code < 400:
        return
    try:
        detail = r.json().get("detail", r.text)
    except Exception:  # noqa: BLE001
        detail = r.text
    msg = f"{r.status_code}: {detail}"
    if r.status_code == 401:
        raise AuthError(msg, status_code=401)
    if r.status_code == 404:
        raise NotFoundError(msg, status_code=404)
    if r.status_code == 429:
        ra = r.headers.get("Retry-After")
        raise RateLimitError(msg, retry_after=int(ra) if ra and ra.isdigit() else None)
    if r.status_code >= 500:
        raise ServerError(msg, status_code=r.status_code)
    raise AmanekiError(msg, status_code=r.status_code)


class AsyncClient:
    """Async client. Prefer as an ``async with`` context manager."""

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = _DEFAULT_BASE,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        headers = {"User-Agent": _USER_AGENT}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._http = httpx.AsyncClient(
            base_url=self._base_url, headers=headers, timeout=timeout
        )

    async def __aenter__(self) -> AsyncClient:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.close()

    async def close(self) -> None:
        await self._http.aclose()

    async def get_regime(self, symbol: str, *, timeframe: str = "1m") -> RegimeSnapshot:
        r = await self._http.get(
            f"/regime/{symbol.lower()}", params={"timeframe": timeframe}
        )
        _raise_for_status(r)
        return RegimeSnapshot.from_json(r.json())

    async def get_history(
        self,
        symbol: str,
        *,
        timeframe: str = "1m",
        from_ms: int | None = None,
        to_ms: int | None = None,
        limit: int = 100,
    ) -> list[RegimeTransition]:
        params: dict[str, Any] = {"limit": limit, "timeframe": timeframe}
        if from_ms is not None:
            params["from_ms"] = from_ms
        if to_ms is not None:
            params["to_ms"] = to_ms
        r = await self._http.get(f"/regime/{symbol.lower()}/history", params=params)
        _raise_for_status(r)
        data = r.json()
        return [RegimeTransition.from_json(t) for t in data.get("transitions", [])]

    async def get_consensus(
        self, symbol: str, *, timeframe: str = "1m"
    ) -> Consensus:
        r = await self._http.get(
            f"/consensus/{symbol.lower()}", params={"timeframe": timeframe}
        )
        _raise_for_status(r)
        return Consensus.from_json(r.json())

    async def run_backtest(
        self,
        symbol: str,
        *,
        timeframe: str = "1m",
        rule: str = "long_low_exit_normal",
        from_ms: int | None = None,
        to_ms: int | None = None,
        thresholds: dict | None = None,
    ) -> BacktestResult:
        body: dict[str, Any] = {
            "symbol": symbol.lower(),
            "timeframe": timeframe,
            "rule": rule,
        }
        if from_ms is not None:
            body["from_ms"] = from_ms
        if to_ms is not None:
            body["to_ms"] = to_ms
        if thresholds is not None:
            body["thresholds"] = thresholds
        r = await self._http.post("/backtest", json=body)
        _raise_for_status(r)
        return BacktestResult.from_json(r.json())

    async def get_symbols(self) -> list[str]:
        r = await self._http.get("/symbols")
        _raise_for_status(r)
        return list(r.json().get("symbols", []))

    async def get_timeframes(self) -> list[str]:
        r = await self._http.get("/timeframes")
        _raise_for_status(r)
        return list(r.json().get("timeframes", []))

    async def get_presets(self) -> dict:
        r = await self._http.get("/presets")
        _raise_for_status(r)
        return r.json()

    async def create_webhook(
        self,
        url: str,
        *,
        symbols: list[str] | None = None,
        timeframes: list[str] | None = None,
        to_regimes: list[str] | None = None,
    ) -> WebhookSubscription:
        body = {"url": url}
        if symbols is not None:
            body["symbols"] = [s.lower() for s in symbols]
        if timeframes is not None:
            body["timeframes"] = timeframes
        if to_regimes is not None:
            body["to_regimes"] = to_regimes
        r = await self._http.post("/webhooks", json=body)
        _raise_for_status(r)
        return WebhookSubscription.from_json(r.json())

    async def list_webhooks(self) -> list[WebhookSubscription]:
        r = await self._http.get("/webhooks")
        _raise_for_status(r)
        return [
            WebhookSubscription.from_json(s)
            for s in r.json().get("subscriptions", [])
        ]

    async def delete_webhook(self, subscription_id: int) -> None:
        r = await self._http.request("DELETE", f"/webhooks/{subscription_id}")
        _raise_for_status(r)

    async def get_market_correlation(
        self, *, timeframe: str = "1m", window: int = 60
    ) -> MarketCorrelation:
        r = await self._http.get(
            "/correlation/market",
            params={"timeframe": timeframe, "window": window},
        )
        _raise_for_status(r)
        return MarketCorrelation.from_json(r.json())

    async def get_symbol_correlation(
        self,
        symbol: str,
        *,
        timeframe: str = "1m",
        window: int = 60,
        reference: str = "btcusdt",
    ) -> SymbolCorrelation:
        r = await self._http.get(
            f"/correlation/{symbol.lower()}",
            params={"timeframe": timeframe, "window": window, "reference": reference},
        )
        _raise_for_status(r)
        return SymbolCorrelation.from_json(r.json())

    async def get_iv_gap(self, symbol: str) -> IvGap:
        r = await self._http.get(f"/iv-gap/{symbol.lower()}")
        _raise_for_status(r)
        return IvGap.from_json(r.json())

    async def stream(
        self, *, reconnect: bool = True, backoff_s: float = 5.0
    ) -> AsyncIterator[StreamEvent]:
        """Yield stream events until cancelled. Reconnects on failure."""
        import websockets

        ws_base = self._base_url.replace("https://", "wss://").replace(
            "http://", "ws://"
        )
        url = f"{ws_base}/stream"
        if self._api_key:
            url = f"{url}?api_key={self._api_key}"

        while True:
            try:
                async with websockets.connect(
                    url, user_agent_header=_USER_AGENT
                ) as ws:
                    async for raw in ws:
                        try:
                            yield StreamEvent.from_json(json.loads(raw))
                        except (TypeError, json.JSONDecodeError):
                            continue
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001
                if not reconnect:
                    raise
                await asyncio.sleep(backoff_s)


class Client:
    """Synchronous client. Internally wraps an asyncio loop per call.

    For production async apps, prefer ``AsyncClient`` directly.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = _DEFAULT_BASE,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        headers = {"User-Agent": _USER_AGENT}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._http = httpx.Client(
            base_url=self._base_url, headers=headers, timeout=timeout
        )

    def __enter__(self) -> Client:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def close(self) -> None:
        self._http.close()

    def get_regime(self, symbol: str, *, timeframe: str = "1m") -> RegimeSnapshot:
        r = self._http.get(
            f"/regime/{symbol.lower()}", params={"timeframe": timeframe}
        )
        _raise_for_status(r)
        return RegimeSnapshot.from_json(r.json())

    def get_history(
        self,
        symbol: str,
        *,
        timeframe: str = "1m",
        from_ms: int | None = None,
        to_ms: int | None = None,
        limit: int = 100,
    ) -> list[RegimeTransition]:
        params: dict[str, Any] = {"limit": limit, "timeframe": timeframe}
        if from_ms is not None:
            params["from_ms"] = from_ms
        if to_ms is not None:
            params["to_ms"] = to_ms
        r = self._http.get(f"/regime/{symbol.lower()}/history", params=params)
        _raise_for_status(r)
        data = r.json()
        return [RegimeTransition.from_json(t) for t in data.get("transitions", [])]

    def get_consensus(
        self, symbol: str, *, timeframe: str = "1m"
    ) -> Consensus:
        r = self._http.get(
            f"/consensus/{symbol.lower()}", params={"timeframe": timeframe}
        )
        _raise_for_status(r)
        return Consensus.from_json(r.json())

    def run_backtest(
        self,
        symbol: str,
        *,
        timeframe: str = "1m",
        rule: str = "long_low_exit_normal",
        from_ms: int | None = None,
        to_ms: int | None = None,
        thresholds: dict | None = None,
    ) -> BacktestResult:
        body: dict[str, Any] = {
            "symbol": symbol.lower(),
            "timeframe": timeframe,
            "rule": rule,
        }
        if from_ms is not None:
            body["from_ms"] = from_ms
        if to_ms is not None:
            body["to_ms"] = to_ms
        if thresholds is not None:
            body["thresholds"] = thresholds
        r = self._http.post("/backtest", json=body)
        _raise_for_status(r)
        return BacktestResult.from_json(r.json())

    def get_symbols(self) -> list[str]:
        r = self._http.get("/symbols")
        _raise_for_status(r)
        return list(r.json().get("symbols", []))

    def get_timeframes(self) -> list[str]:
        r = self._http.get("/timeframes")
        _raise_for_status(r)
        return list(r.json().get("timeframes", []))

    def get_presets(self) -> dict:
        r = self._http.get("/presets")
        _raise_for_status(r)
        return r.json()

    def create_webhook(
        self,
        url: str,
        *,
        symbols: list[str] | None = None,
        timeframes: list[str] | None = None,
        to_regimes: list[str] | None = None,
    ) -> WebhookSubscription:
        body = {"url": url}
        if symbols is not None:
            body["symbols"] = [s.lower() for s in symbols]
        if timeframes is not None:
            body["timeframes"] = timeframes
        if to_regimes is not None:
            body["to_regimes"] = to_regimes
        r = self._http.post("/webhooks", json=body)
        _raise_for_status(r)
        return WebhookSubscription.from_json(r.json())

    def list_webhooks(self) -> list[WebhookSubscription]:
        r = self._http.get("/webhooks")
        _raise_for_status(r)
        return [
            WebhookSubscription.from_json(s)
            for s in r.json().get("subscriptions", [])
        ]

    def delete_webhook(self, subscription_id: int) -> None:
        r = self._http.request("DELETE", f"/webhooks/{subscription_id}")
        _raise_for_status(r)

    def get_market_correlation(
        self, *, timeframe: str = "1m", window: int = 60
    ) -> MarketCorrelation:
        r = self._http.get(
            "/correlation/market",
            params={"timeframe": timeframe, "window": window},
        )
        _raise_for_status(r)
        return MarketCorrelation.from_json(r.json())

    def get_symbol_correlation(
        self,
        symbol: str,
        *,
        timeframe: str = "1m",
        window: int = 60,
        reference: str = "btcusdt",
    ) -> SymbolCorrelation:
        r = self._http.get(
            f"/correlation/{symbol.lower()}",
            params={"timeframe": timeframe, "window": window, "reference": reference},
        )
        _raise_for_status(r)
        return SymbolCorrelation.from_json(r.json())

    def get_iv_gap(self, symbol: str) -> IvGap:
        r = self._http.get(f"/iv-gap/{symbol.lower()}")
        _raise_for_status(r)
        return IvGap.from_json(r.json())

    def stream(
        self, *, reconnect: bool = True, backoff_s: float = 5.0
    ) -> Iterator[StreamEvent]:
        """Blocking iterator over stream events. Drives an internal loop."""
        loop = asyncio.new_event_loop()
        agen = AsyncClient(
            api_key=self._api_key, base_url=self._base_url
        ).stream(reconnect=reconnect, backoff_s=backoff_s)
        try:
            while True:
                try:
                    yield loop.run_until_complete(agen.__anext__())
                except StopAsyncIteration:
                    return
        finally:
            loop.run_until_complete(agen.aclose())
            loop.close()
