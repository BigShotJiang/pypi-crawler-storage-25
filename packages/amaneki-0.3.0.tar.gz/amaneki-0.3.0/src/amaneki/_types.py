"""Typed response models."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Regime = Literal["low", "normal", "high"]


@dataclass(frozen=True, slots=True)
class RegimeSnapshot:
    """Current state of one (symbol, timeframe). Returned by ``get_regime``."""

    symbol: str
    timeframe: str
    regime: Regime
    z_vol: float | None
    realized_vol: float | None
    baseline_vol: float | None
    close: float | None
    last_update_ms: int | None
    seconds_in_state: int | None = None
    warmup: bool = False

    @classmethod
    def from_json(cls, data: dict) -> RegimeSnapshot:
        return cls(
            symbol=data["symbol"],
            timeframe=data.get("timeframe", "1m"),
            regime=data.get("regime", "normal"),
            z_vol=data.get("z_vol"),
            realized_vol=data.get("realized_vol"),
            baseline_vol=data.get("baseline_vol"),
            close=data.get("close"),
            last_update_ms=data.get("last_update_ms"),
            seconds_in_state=data.get("seconds_in_state"),
            warmup=bool(data.get("warmup", False)),
        )


@dataclass(frozen=True, slots=True)
class RegimeTransition:
    """One row from ``get_history``."""

    ts_ms: int
    from_regime: Regime
    to_regime: Regime
    z_vol: float
    close: float

    @classmethod
    def from_json(cls, data: dict) -> RegimeTransition:
        return cls(
            ts_ms=int(data["ts_ms"]),
            from_regime=data["from"],
            to_regime=data["to"],
            z_vol=float(data["z_vol"]),
            close=float(data["close"]),
        )


@dataclass(frozen=True, slots=True)
class VenueSnapshot:
    """One venue's view inside a consensus payload."""

    regime: Regime
    z_vol: float | None
    realized_vol: float | None
    baseline_vol: float | None
    close: float | None
    last_update_ms: int | None
    error: str | None = None

    @classmethod
    def from_json(cls, data: dict) -> VenueSnapshot:
        return cls(
            regime=data.get("regime", "normal"),
            z_vol=data.get("z_vol"),
            realized_vol=data.get("realized_vol"),
            baseline_vol=data.get("baseline_vol"),
            close=data.get("close"),
            last_update_ms=data.get("last_update_ms"),
            error=data.get("error"),
        )


@dataclass(frozen=True, slots=True)
class Consensus:
    """Returned by ``get_consensus``."""

    symbol: str
    timeframe: str
    consensus: Regime | str
    agreed: int
    available: int
    refreshed_at_ms: int
    fresh: bool
    venues: dict[str, VenueSnapshot]

    @classmethod
    def from_json(cls, data: dict) -> Consensus:
        return cls(
            symbol=data["symbol"],
            timeframe=data["timeframe"],
            consensus=data.get("consensus", "unknown"),
            agreed=int(data.get("agreed", 0)),
            available=int(data.get("available", 0)),
            refreshed_at_ms=int(data.get("refreshed_at_ms", 0)),
            fresh=bool(data.get("fresh", False)),
            venues={
                k: VenueSnapshot.from_json(v)
                for k, v in (data.get("venues") or {}).items()
            },
        )


@dataclass(frozen=True, slots=True)
class BacktestTrade:
    entry_ts_ms: int
    exit_ts_ms: int
    entry_close: float
    exit_close: float
    side: str
    return_pct: float


@dataclass(frozen=True, slots=True)
class BacktestResult:
    symbol: str
    timeframe: str
    rule: str
    replayed_bars: int
    n_trades: int
    win_rate: float
    total_return: float
    max_drawdown: float
    sharpe_per_trade: float
    trades: list[BacktestTrade]

    @classmethod
    def from_json(cls, data: dict) -> BacktestResult:
        stats = data.get("stats") or {}
        return cls(
            symbol=data["symbol"],
            timeframe=data["timeframe"],
            rule=data["rule"],
            replayed_bars=int(data.get("replayed_bars", 0)),
            n_trades=int(stats.get("n_trades", 0)),
            win_rate=float(stats.get("win_rate", 0.0)),
            total_return=float(stats.get("total_return", 0.0)),
            max_drawdown=float(stats.get("max_drawdown", 0.0)),
            sharpe_per_trade=float(stats.get("sharpe_per_trade", 0.0)),
            trades=[
                BacktestTrade(
                    entry_ts_ms=int(t["entry_ts_ms"]),
                    exit_ts_ms=int(t["exit_ts_ms"]),
                    entry_close=float(t["entry_close"]),
                    exit_close=float(t["exit_close"]),
                    side=t["side"],
                    return_pct=float(t["return"]),
                )
                for t in (data.get("trades") or [])
            ],
        )


@dataclass(frozen=True, slots=True)
class MarketCorrelation:
    """Returned by ``get_market_correlation``."""

    timeframe: str
    window_bars: int
    symbols: list[str]
    mean_correlation: float
    stdev_correlation: float
    regime: str

    @classmethod
    def from_json(cls, data: dict) -> MarketCorrelation:
        return cls(
            timeframe=data["timeframe"],
            window_bars=int(data.get("window_bars", 0)),
            symbols=list(data.get("symbols", [])),
            mean_correlation=float(data.get("mean_correlation", 0.0)),
            stdev_correlation=float(data.get("stdev_correlation", 0.0)),
            regime=data.get("regime", "mixed"),
        )


@dataclass(frozen=True, slots=True)
class SymbolCorrelation:
    """Returned by ``get_symbol_correlation``."""

    symbol: str
    timeframe: str
    window_bars: int
    reference: str
    beta_to_reference: float
    correlation_with_peers: dict[str, float]

    @classmethod
    def from_json(cls, data: dict) -> SymbolCorrelation:
        return cls(
            symbol=data["symbol"],
            timeframe=data["timeframe"],
            window_bars=int(data.get("window_bars", 0)),
            reference=data.get("reference", "btcusdt"),
            beta_to_reference=float(data.get("beta_to_reference", 0.0)),
            correlation_with_peers={
                k: float(v)
                for k, v in (data.get("correlation_with_peers") or {}).items()
            },
        )


@dataclass(frozen=True, slots=True)
class IvGap:
    """Returned by ``get_iv_gap``. BTC and ETH only."""

    symbol: str
    timeframe: str
    realized_vol: float
    implied_vol: float
    gap: float
    label: str
    rv_ts_ms: int
    iv_ts_ms: int

    @classmethod
    def from_json(cls, data: dict) -> IvGap:
        return cls(
            symbol=data["symbol"],
            timeframe=data.get("timeframe", "1m"),
            realized_vol=float(data["realized_vol"]),
            implied_vol=float(data["implied_vol"]),
            gap=float(data["gap"]),
            label=data.get("label", "aligned"),
            rv_ts_ms=int(data.get("rv_ts_ms", 0)),
            iv_ts_ms=int(data.get("iv_ts_ms", 0)),
        )


@dataclass(frozen=True, slots=True)
class WebhookSubscription:
    id: int
    url: str
    symbols: list[str]
    timeframes: list[str]
    to_regimes: list[str]
    created_at: str
    last_success_at: str | None
    last_failure_at: str | None
    failure_count: int
    disabled_at: str | None
    signing_secret: str | None = None  # only returned at creation

    @classmethod
    def from_json(cls, data: dict) -> WebhookSubscription:
        return cls(
            id=int(data["id"]),
            url=data["url"],
            symbols=list(data.get("symbols") or []),
            timeframes=list(data.get("timeframes") or []),
            to_regimes=list(data.get("to_regimes") or []),
            created_at=data.get("created_at", ""),
            last_success_at=data.get("last_success_at"),
            last_failure_at=data.get("last_failure_at"),
            failure_count=int(data.get("failure_count", 0)),
            disabled_at=data.get("disabled_at"),
            signing_secret=data.get("signing_secret"),
        )


@dataclass(frozen=True, slots=True)
class StreamEvent:
    """One message from the WebSocket stream."""

    type: str
    symbol: str | None
    ts_ms: int | None
    from_regime: Regime | None
    to_regime: Regime | None
    z_vol: float | None
    close: float | None
    raw: dict

    @classmethod
    def from_json(cls, data: dict) -> StreamEvent:
        return cls(
            type=data.get("type", "unknown"),
            symbol=data.get("symbol"),
            ts_ms=data.get("ts_ms"),
            from_regime=data.get("from"),
            to_regime=data.get("to"),
            z_vol=data.get("z_vol"),
            close=data.get("close"),
            raw=data,
        )
