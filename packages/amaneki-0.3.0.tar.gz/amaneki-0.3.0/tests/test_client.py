"""Smoke tests for the SDK against a mocked transport."""

from __future__ import annotations

import httpx
import pytest

from amaneki import (
    AsyncClient,
    AuthError,
    Client,
    NotFoundError,
    RateLimitError,
    RegimeSnapshot,
    RegimeTransition,
)

_REGIME = {
    "symbol": "btcusdt",
    "regime": "normal",
    "z_vol": -0.83,
    "realized_vol": 0.23,
    "baseline_vol": 0.29,
    "close": 74915.42,
    "last_update_ms": 1776324240000,
    "last_transition": None,
}

_HISTORY = {
    "symbol": "btcusdt",
    "source": "postgres",
    "count": 1,
    "transitions": [
        {"ts_ms": 1, "from": "normal", "to": "high", "z_vol": 2.9, "close": 75000.0}
    ],
}


def _handler(status: int = 200, payload: dict | None = None, headers: dict | None = None):
    def _h(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status, json=payload or {}, headers=headers or {})
    return _h


def _sync_with(handler):
    c = Client(api_key="ak_test")
    c._http = httpx.Client(
        transport=httpx.MockTransport(handler),
        base_url="https://api.amaneki.com/v1",
        headers={"Authorization": "Bearer ak_test"},
    )
    return c


def _async_with(handler):
    c = AsyncClient(api_key="ak_test")
    c._http = httpx.AsyncClient(
        transport=httpx.MockTransport(handler),
        base_url="https://api.amaneki.com/v1",
        headers={"Authorization": "Bearer ak_test"},
    )
    return c


def test_sync_get_regime_parses() -> None:
    with _sync_with(_handler(200, _REGIME)) as c:
        snap = c.get_regime("btcusdt")
        assert isinstance(snap, RegimeSnapshot)
        assert snap.regime == "normal"
        assert snap.close == 74915.42


def test_sync_get_history_parses() -> None:
    with _sync_with(_handler(200, _HISTORY)) as c:
        rows = c.get_history("btcusdt", from_ms=1)
        assert len(rows) == 1
        assert isinstance(rows[0], RegimeTransition)
        assert rows[0].to_regime == "high"


def test_sync_raises_auth_error() -> None:
    with (
        _sync_with(_handler(401, {"detail": "invalid api key"})) as c,
        pytest.raises(AuthError),
    ):
        c.get_regime("btcusdt")


def test_sync_raises_rate_limit_with_retry_after() -> None:
    with _sync_with(_handler(429, {"detail": "over"}, {"Retry-After": "60"})) as c:
        with pytest.raises(RateLimitError) as exc:
            c.get_regime("btcusdt")
        assert exc.value.retry_after == 60


def test_sync_raises_not_found() -> None:
    with (
        _sync_with(_handler(404, {"detail": "not tracked"})) as c,
        pytest.raises(NotFoundError),
    ):
        c.get_regime("xrpusdt")


async def test_async_get_regime_parses() -> None:
    async with _async_with(_handler(200, _REGIME)) as c:
        snap = await c.get_regime("BTCUSDT")  # uppercase ok
        assert snap.z_vol == -0.83
