# amaneki

Python client for the [Amaneki](https://amaneki.com) volatility-regime API.

```
pip install amaneki
```

## Usage

```python
from amaneki import Client

c = Client(api_key="ak_...")
snap = c.get_regime("btcusdt")
print(snap.regime, snap.z_vol)  # e.g. "normal" -0.83

for t in c.get_history("btcusdt", from_ms=1776000000000):
    print(t.ts_ms, t.from_regime, "→", t.to_regime)
```

### Cross-exchange consensus

```python
cs = c.get_consensus("btcusdt", timeframe="15m")
print(cs.consensus, f"{cs.agreed}/{cs.available}")
for name, v in cs.venues.items():
    print(name, v.regime, v.z_vol)
```

### Backtest

```python
r = c.run_backtest("btcusdt", timeframe="15m", rule="long_low_exit_normal")
print(r.n_trades, r.total_return, r.max_drawdown)
```

Rules: `long_low_exit_normal`, `short_high_exit_normal`, `avoid_high`.
Optional `thresholds={"high_enter": 3.0, ...}` overrides the running preset.

### Async + streaming

```python
import asyncio
from amaneki import AsyncClient

async def main():
    async with AsyncClient(api_key="ak_...") as c:
        async for ev in c.stream():
            print(ev.type, ev.symbol, ev.to_regime)

asyncio.run(main())
```

### No key

`get_regime` and `get_history` are callable without an API key — you
get the free tier, capped at 60 requests/minute per IP.

## Errors

```python
from amaneki import AuthError, RateLimitError, NotFoundError
```

Raised on HTTP 401 / 429 / 404. `RateLimitError.retry_after` holds the
seconds from the `Retry-After` header when the server provides one.
