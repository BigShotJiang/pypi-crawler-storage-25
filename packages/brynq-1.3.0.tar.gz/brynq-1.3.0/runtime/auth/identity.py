"""
Backwards-compatible shim.

The real identity module is now at runtime/identity.py.
This file preserves imports for existing code that does:
    from runtime.auth.identity import IdentityManager
"""

from runtime.identity import Identity


class NotLoggedInError(Exception):
    pass


class IdentityManager:
    """Legacy shim wrapping the new Identity class.

    Old code used IdentityManager.login(api_key) with a dummy token.
    New code should use Identity directly.
    """

    def __init__(self):
        self._identity = Identity()
        self._identity.ensure_identity()

    @property
    def token(self) -> str | None:
        return self._identity.token

    def login(self, api_key_or_email: str, password: str = "") -> bool:
        """Login. If password is provided, does email/password auth.
        Otherwise falls back to the old API-key style (for compat)."""
        if password:
            self._identity.login(api_key_or_email, password)
            return True
        # Legacy: treat as API key (just store it)
        if not api_key_or_email:
            raise ValueError("API key is required")
        # For backwards compat, just store the key as a token
        from pathlib import Path
        self._identity._token = api_key_or_email
        self._identity._save_token(api_key_or_email)
        return True

    def get_auth_header(self) -> dict:
        if not self._identity.token:
            raise NotLoggedInError("User is not logged in")
        return self._identity.get_auth_headers()
