"""Common content gathering and rendering functions."""

from pathlib import Path
from typing import Optional

from mcp_guide.content.utils import resolve_patterns
from mcp_guide.discovery.files import FileInfo, discover_documents
from mcp_guide.models import (
    CategoryNotFoundError,
    DocumentExpression,
    ExpressionParseError,
    Project,
)
from mcp_guide.session import Session


def parse_expression(expression: str) -> list[DocumentExpression]:
    """Parse comma-separated expression into DocumentExpression objects.

    Args:
        expression: User input expression (e.g., "cat1/pat1,cat2,cat3/pat2")

    Returns:
        List of DocumentExpression objects

    Raises:
        ExpressionParseError: If expression is malformed
    """
    if not expression or expression.isspace():
        raise ExpressionParseError("Expression cannot be empty")

    expressions = []

    # Split by comma and process each sub-expression
    for sub_expr in expression.split(","):
        sub_expr = sub_expr.strip()
        if not sub_expr:
            continue  # Skip empty sub-expressions

        # Handle multiple slashes - only first slash is delimiter
        if "/" in sub_expr:
            parts = sub_expr.split("/", 1)  # Split on first slash only
            name = parts[0].strip()
            pattern_part = parts[1].strip() if len(parts) > 1 else ""

            if not name:
                raise ExpressionParseError(f"Empty category/collection name in expression: '{sub_expr}'")

            if pattern_part:
                # Split patterns by + for multi-pattern support
                pattern_list: list[str] = []
                for p in pattern_part.split("+"):
                    if p := p.strip():
                        pattern_list.append(p)

                # If no valid patterns after filtering, treat as None
                patterns: Optional[list[str]] = pattern_list or None
            else:
                patterns = None
        else:
            name = sub_expr.strip()
            patterns = None

            if not name:
                raise ExpressionParseError(f"Empty category/collection name in expression: '{sub_expr}'")

        expressions.append(DocumentExpression(raw_input=sub_expr, name=name, patterns=patterns))

    if not expressions:
        raise ExpressionParseError("No valid expressions found")

    return expressions


async def gather_content(
    session: Session,
    project: Project,
    expression: str,
    visited_collections: Optional[set[str]] = None,
) -> list[FileInfo]:
    """Process expression and return unified FileInfo list.

    Args:
        session: Current session
        project: Project configuration
        expression: User expression to process
        visited_collections: Set of collection names already visited (for circular reference prevention)

    Returns:
        List of FileInfo objects from all matched categories/collections

    Raises:
        ExpressionParseError: If expression parsing fails
        CategoryNotFoundError: If a referenced category doesn't exist
        CollectionNotFoundError: If a referenced collection doesn't exist
    """
    # Initialize visited collections set if not provided
    if visited_collections is None:
        visited_collections = set()

    expressions = parse_expression(expression)
    all_files = []
    # Track processed (category_name, patterns) combinations to allow multiple pattern sets per category
    processed_combinations = set()

    for expr in expressions:
        if expr.name in project.collections:
            # Check for circular reference
            if expr.name in visited_collections:
                continue  # Skip already visited collection

            # Mark collection as visited
            visited_collections.add(expr.name)

            # Handle collection - expand to its categories (which may be expressions or other collections)
            collection = project.collections[expr.name]
            for category_expr in collection.categories:
                # Check if this is a nested collection reference (and NOT also a category)
                # If it's both a collection and category, treat it as a category
                if category_expr in project.collections and category_expr not in project.categories:
                    # Recursively resolve nested collection
                    nested_files = await gather_content(session, project, category_expr, visited_collections)
                    all_files.extend(nested_files)
                else:
                    # Parse category expression (e.g., "review/commit")
                    cat_expressions = parse_expression(category_expr)
                    for cat_expr in cat_expressions:
                        # Merge patterns from collection-level expression with category expression
                        merged_patterns = cat_expr.patterns or expr.patterns
                        patterns_key = tuple(sorted(merged_patterns)) if merged_patterns else None
                        combination_key = (cat_expr.name, patterns_key)

                        if combination_key not in processed_combinations:
                            try:
                                files = await gather_category_fileinfos(
                                    session, project, cat_expr.name, merged_patterns
                                )
                                all_files.extend(files)
                                processed_combinations.add(combination_key)
                            except CategoryNotFoundError as e:
                                # Re-raise with context about which collection referenced the missing category
                                raise CategoryNotFoundError(
                                    f"{cat_expr.name} (referenced by collection '{expr.name}')"
                                ) from e

        elif expr.name in project.categories:
            # Handle category - use gather_category_fileinfos
            patterns_key = tuple(sorted(expr.patterns)) if expr.patterns else None
            combination_key = (expr.name, patterns_key)

            if combination_key not in processed_combinations:
                files = await gather_category_fileinfos(session, project, expr.name, expr.patterns)
                all_files.extend(files)
                processed_combinations.add(combination_key)
        else:
            raise CategoryNotFoundError(expr.name)

    # De-duplicate: filesystem files by absolute path, stored documents by (category, name)
    seen_paths: set[Path] = set()
    seen_docs: set[tuple[str, str]] = set()
    unique_files = []
    docroot = Path(await session.get_docroot())

    for file in all_files:
        if not file.category or file.category.name not in project.categories:
            continue
        if file.source == "store":
            doc_key = (file.category.name, file.name)
            if doc_key not in seen_docs:
                seen_docs.add(doc_key)
                unique_files.append(file)
        else:
            category_dir = docroot / file.category.dir
            absolute_path = category_dir / file.path
            if absolute_path not in seen_paths:
                seen_paths.add(absolute_path)
                unique_files.append(file)

    return unique_files


async def gather_category_fileinfos(
    session: Session,
    project: Project,
    category_name: str,
    patterns: Optional[list[str]] = None,
    collection_overrides: Optional[dict[str, list[str]]] = None,
) -> list[FileInfo]:
    """Common function to gather FileInfo for a category with pattern resolution.

    Args:
        session: Current session
        project: Project configuration
        category_name: Name of the category
        patterns: Optional patterns to override defaults
        collection_overrides: Optional collection pattern overrides

    Returns:
        List of FileInfo objects for the category

    Raises:
        CategoryNotFoundError: If category doesn't exist
    """
    # Resolve category
    category = project.categories.get(category_name)
    if category is None:
        raise CategoryNotFoundError(category_name)

    # Resolve patterns with three-tier priority:
    # 1. Explicit patterns parameter (highest)
    # 2. Collection overrides (medium)
    # 3. Category defaults (lowest)
    #
    # Special case: a single trailing-slash pattern (e.g. "git/ops/") is a sub-path filter,
    # not a pattern override. It filters the category's configured patterns to those that
    # start with the given prefix, preserving the user's selection intent.
    if patterns is not None and len(patterns) == 1 and patterns[0].endswith("/"):
        sub_path_prefix = patterns[0]
        configured = (
            collection_overrides[category_name]
            if collection_overrides and category_name in collection_overrides
            else category.patterns
        )
        resolved_patterns = [p for p in configured if p.startswith(sub_path_prefix)]
    elif patterns is not None:
        resolved_patterns = patterns
    elif collection_overrides and category_name in collection_overrides:
        resolved_patterns = collection_overrides[category_name]
    else:
        resolved_patterns = resolve_patterns(None, category.patterns)

    # Discover files
    docroot = Path(await session.get_docroot())
    category_dir = docroot / category.dir
    files = await discover_documents(category_dir, resolved_patterns, category=category_name)

    # Exclude filesystem files where any path component starts with '_' (system/partial files).
    # Stored documents are user-imported and not subject to this exclusion.
    files = [f for f in files if f.source == "store" or not any(part.startswith("_") for part in f.path.parts)]

    # Set category object on all FileInfo objects
    for file in files:
        file.category = category

    return files
