"""Document store package."""
