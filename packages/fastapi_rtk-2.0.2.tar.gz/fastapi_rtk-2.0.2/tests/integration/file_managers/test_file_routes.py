"""Integration: /_file/{filename} + /_image/{filename} route handlers.

Defines a Widget with FileColumn + ImageColumn lazily (after UPLOAD_FOLDER
config is in place), writes a file directly into the manager's upload
folder, and asserts the GET route serves it. Skips multipart-upload
codepath (covered by `_process_body_file` unit tests in tier 12).
"""

import contextlib
import sys

import httpx
import pytest
import pytest_asyncio
import sqlalchemy

pytestmark = pytest.mark.asyncio


def _build_file_models():
    """Define FileWidget + FileWidgetsApi lazily so FileColumn class init
    happens only after UPLOAD_FOLDER is configured.
    """
    from fastapi_rtk.api.model_rest_api import ModelRestApi
    from fastapi_rtk.backends.sqla.interface import SQLAInterface
    from fastapi_rtk.backends.sqla.model import Model
    from fastapi_rtk.types import FileColumn, ImageColumn

    # Re-use the same class name so re-imports don't pile up new tables.
    if "integration_file_widget" in Model.metadata.tables:
        existing_table = Model.metadata.tables["integration_file_widget"]

        # Find existing class via the registry.
        for mapper in Model.registry.mappers:
            if mapper.local_table is existing_table:
                FileWidget = mapper.class_
                break
        else:
            FileWidget = None
    else:
        FileWidget = None

    if FileWidget is None:

        class FileWidget(Model):  # noqa: F811
            __tablename__ = "integration_file_widget"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            name = sqlalchemy.Column(sqlalchemy.String(50), nullable=False)
            document = sqlalchemy.Column(FileColumn(allowed_extensions=["txt", "pdf"]))
            avatar = sqlalchemy.Column(ImageColumn(allowed_extensions=["png", "jpg"]))

    class FileWidgetsApi(ModelRestApi):
        resource_name = "filewidgets"
        datamodel = SQLAInterface(FileWidget)

    return FileWidget, FileWidgetsApi


@pytest_asyncio.fixture
async def file_app(make_toolkit_app, tmp_path, config_setter):
    upload_folder = tmp_path / "uploads"
    img_folder = tmp_path / "img_uploads"
    upload_folder.mkdir()
    img_folder.mkdir()
    config_setter("UPLOAD_FOLDER", str(upload_folder))
    config_setter("IMG_UPLOAD_FOLDER", str(img_folder))
    config_setter("FILE_ALLOWED_EXTENSIONS", ["txt", "pdf", "png", "jpg"])

    FileWidget, FileWidgetsApi = _build_file_models()

    @contextlib.asynccontextmanager
    async def file_widget_lifespan(_app):
        from sqlalchemy.ext.asyncio import AsyncEngine

        engine = sys.modules["fastapi_rtk.db"].db._engine
        if isinstance(engine, AsyncEngine):
            async with engine.begin() as conn:
                await conn.run_sync(
                    lambda c: FileWidget.__table__.create(c, checkfirst=True)
                )
        yield

    fastapi_app = make_toolkit_app(
        extra_apis=[FileWidgetsApi],
        extra_lifespans=[file_widget_lifespan],
    )
    yield fastapi_app, upload_folder, img_folder


@pytest_asyncio.fixture
async def file_client(file_app):
    fastapi_app, upload_folder, img_folder = file_app
    transport = httpx.ASGITransport(app=fastapi_app)
    async with fastapi_app.router.lifespan_context(fastapi_app):
        async with httpx.AsyncClient(
            transport=transport, base_url="http://testserver"
        ) as ac:
            yield ac, upload_folder, img_folder


@pytest_asyncio.fixture
async def file_admin_token(file_client):
    client, _, _ = file_client
    db = sys.modules["fastapi_rtk.db"].db
    from fastapi_rtk.globals import g

    sm = g.current_app.sm
    async with db.session() as session:
        await sm.create_user(
            username="admin",
            email="admin@example.com",
            password="adminpass123",
            roles=["Admin"],
            session=session,
            raise_exception=True,
        )

    response = await client.post(
        "/api/v1/auth/jwt/login",
        data={"username": "admin", "password": "adminpass123"},
    )
    assert response.status_code == 200, response.text
    return response.json()["access_token"]


class TestFileRoute:
    async def test_get_file_returns_content(
        self, file_client, file_admin_token
    ):
        client, upload_folder, _ = file_client
        widget_folder = upload_folder / "integration_file_widget"
        widget_folder.mkdir(parents=True, exist_ok=True)
        f = widget_folder / "report.txt"
        f.write_text("hello document")

        response = await client.get(
            "/api/v1/filewidgets/_file/report.txt",
            headers={"Authorization": f"Bearer {file_admin_token}"},
        )
        assert response.status_code == 200, response.text
        assert "hello document" in response.text

    async def test_get_file_missing_returns_404(
        self, file_client, file_admin_token
    ):
        client, _, _ = file_client
        response = await client.get(
            "/api/v1/filewidgets/_file/missing.txt",
            headers={"Authorization": f"Bearer {file_admin_token}"},
        )
        assert response.status_code == 404

    async def test_get_file_no_token_returns_401(self, file_client):
        client, _, _ = file_client
        response = await client.get("/api/v1/filewidgets/_file/x.txt")
        assert response.status_code == 401


class TestImageRoute:
    async def test_get_image_returns_content(
        self, file_client, file_admin_token
    ):
        client, _, img_folder = file_client
        widget_folder = img_folder / "integration_file_widget"
        widget_folder.mkdir(parents=True, exist_ok=True)
        f = widget_folder / "avatar.png"
        f.write_bytes(b"\x89PNG\r\n\x1a\n" + b"fake image bytes")

        response = await client.get(
            "/api/v1/filewidgets/_image/avatar.png",
            headers={"Authorization": f"Bearer {file_admin_token}"},
        )
        assert response.status_code == 200, response.text
        assert b"PNG" in response.content

    async def test_get_image_missing_returns_404(
        self, file_client, file_admin_token
    ):
        client, _, _ = file_client
        response = await client.get(
            "/api/v1/filewidgets/_image/missing.png",
            headers={"Authorization": f"Bearer {file_admin_token}"},
        )
        assert response.status_code == 404


class TestMultipartUpload:
    async def test_post_with_file_saves_and_creates_row(
        self, file_client, file_admin_token
    ):
        client, upload_folder, _ = file_client
        # POST a row with a file attached via multipart/form-data.
        # FastAPI form-data + UploadFile -> _process_body_file is invoked.
        files = {"document": ("upload.txt", b"hello upload", "text/plain")}
        data = {"name": "WidgetWithFile"}
        response = await client.post(
            "/api/v1/filewidgets/",
            headers={"Authorization": f"Bearer {file_admin_token}"},
            data=data,
            files=files,
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert body["result"]["name"] == "WidgetWithFile"
        # File ends up under <UPLOAD_FOLDER>/integration_file_widget/<filename>
        widget_folder = upload_folder / "integration_file_widget"
        assert widget_folder.exists()
        # File generated_secure_filename writes some flavor of the original name.
        files_on_disk = list(widget_folder.glob("*upload*"))
        assert files_on_disk, f"No file found in {widget_folder}"

    async def test_post_with_image_saves_and_creates_row(
        self, file_client, file_admin_token
    ):
        client, _, img_folder = file_client
        files = {"avatar": ("pic.png", b"\x89PNG\r\n\x1a\nfake", "image/png")}
        data = {"name": "WidgetWithImage"}
        response = await client.post(
            "/api/v1/filewidgets/",
            headers={"Authorization": f"Bearer {file_admin_token}"},
            data=data,
            files=files,
        )
        assert response.status_code == 200, response.text
        widget_folder = img_folder / "integration_file_widget"
        assert widget_folder.exists()
        files_on_disk = list(widget_folder.glob("*pic*"))
        assert files_on_disk

    async def test_post_with_disallowed_extension_rejected(
        self, file_client, file_admin_token
    ):
        client, _, _ = file_client
        files = {"document": ("evil.exe", b"binary", "application/octet-stream")}
        data = {"name": "Bad"}
        response = await client.post(
            "/api/v1/filewidgets/",
            headers={"Authorization": f"Bearer {file_admin_token}"},
            data=data,
            files=files,
        )
        # disallowed extension should fail (400-range)
        assert response.status_code >= 400


class TestFileLifecycle:
    """File replacement on PUT + cleanup on DELETE."""

    async def test_put_replaces_file(self, file_client, file_admin_token):
        client, upload_folder, _ = file_client
        # Create initial row with file.
        post = await client.post(
            "/api/v1/filewidgets/",
            headers={"Authorization": f"Bearer {file_admin_token}"},
            data={"name": "ToReplace"},
            files={"document": ("first.txt", b"first content", "text/plain")},
        )
        assert post.status_code == 200, post.text
        widget_id = post.json()["id"]

        # PUT with a new file.
        put = await client.put(
            f"/api/v1/filewidgets/{widget_id}",
            headers={"Authorization": f"Bearer {file_admin_token}"},
            data={"name": "Replaced"},
            files={"document": ("second.txt", b"second content", "text/plain")},
        )
        assert put.status_code == 200, put.text

        # New file present.
        widget_folder = upload_folder / "integration_file_widget"
        new_files = list(widget_folder.glob("*second*"))
        assert new_files

    async def test_delete_removes_file(self, file_client, file_admin_token):
        client, upload_folder, _ = file_client
        post = await client.post(
            "/api/v1/filewidgets/",
            headers={"Authorization": f"Bearer {file_admin_token}"},
            data={"name": "Deletable"},
            files={"document": ("byebye.txt", b"goodbye", "text/plain")},
        )
        assert post.status_code == 200
        widget_id = post.json()["id"]

        widget_folder = upload_folder / "integration_file_widget"
        before = list(widget_folder.glob("*byebye*"))
        assert before

        await client.delete(
            f"/api/v1/filewidgets/{widget_id}",
            headers={"Authorization": f"Bearer {file_admin_token}"},
        )
        # Row deleted; file may or may not be cleaned up depending on
        # configuration. Either way, the row should be gone.
        check = await client.get(
            f"/api/v1/filewidgets/{widget_id}",
            headers={"Authorization": f"Bearer {file_admin_token}"},
        )
        assert check.status_code == 404


class TestRoutesRegistration:
    async def test_file_widget_routes_registered(self, file_client):
        client, _, _ = file_client
        response = await client.get("/openapi.json")
        paths = response.json()["paths"]
        assert "/api/v1/filewidgets/_file/{filename}" in paths
        assert "/api/v1/filewidgets/_image/{filename}" in paths

    async def test_plain_widget_has_no_file_routes(self, client):
        # The IntegrationWidget has no FileColumn/ImageColumn -> routes filtered.
        response = await client.get("/openapi.json")
        paths = response.json()["paths"]
        assert "/api/v1/widgets/_file/{filename}" not in paths
        assert "/api/v1/widgets/_image/{filename}" not in paths
