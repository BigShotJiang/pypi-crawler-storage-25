"""Integration: SecurityManager flows that need UserManager + live db.

Covers create_user / update_user / reset_password / get_user / get_roles
(the codepaths that delegate to UserManager and that unit tests in
tier 10 deferred).
"""

import sys

import pytest
import pytest_asyncio
import sqlalchemy
from fastapi_users.exceptions import UserAlreadyExists

pytestmark = pytest.mark.asyncio


@pytest_asyncio.fixture
async def sm(client):
    """SecurityManager wired by the running toolkit."""
    from fastapi_rtk.globals import g

    return g.current_app.sm


@pytest_asyncio.fixture
async def db_session():
    """Live db.session() context for direct ORM ops."""
    from fastapi_rtk.globals import g  # noqa: F401

    db = sys.modules["fastapi_rtk.db"].db
    return db


class TestSMCreateUser:
    async def test_create_user_basic(self, client, sm, db_session):
        async with db_session.session() as session:
            user = await sm.create_user(
                username="newbie",
                email="newbie@example.com",
                password="secret123",
                session=session,
                raise_exception=True,
            )
            assert user.username == "newbie"
            assert user.email == "newbie@example.com"
            assert user.id is not None

    async def test_create_user_with_roles(self, client, sm, db_session, admin_user):
        async with db_session.session() as session:
            user = await sm.create_user(
                username="editor",
                email="editor@example.com",
                password="pass1234",
                roles=["Admin"],
                session=session,
                raise_exception=True,
            )
            assert any(r.name == "Admin" for r in user.roles)

    async def test_create_user_duplicate_email_user_exists(
        self, client, sm, db_session, admin_user
    ):
        async with db_session.session() as session:
            with pytest.raises(UserAlreadyExists):
                await sm.create_user(
                    username="other",
                    email="admin@example.com",  # already exists
                    password="x",
                    session=session,
                    raise_exception="user_exists",
                )

    async def test_create_user_no_raise(self, client, sm, db_session, admin_user):
        async with db_session.session() as session:
            result = await sm.create_user(
                username="other2",
                email="admin@example.com",
                password="x",
                session=session,
                raise_exception=False,
            )
            assert result is None


class TestSMUpdateUser:
    async def test_update_user_first_name(self, client, sm, db_session, admin_user):
        async with db_session.session() as session:
            user = await sm.get_user("admin", session=session)
            updated = await sm.update_user(
                {"first_name": "Alice"}, user, session=session
            )
            assert updated.first_name == "Alice"

    async def test_update_user_with_roles(
        self, client, sm, db_session, admin_user
    ):
        async with db_session.session() as session:
            # Create a non-builtin role so update_user roles parameter has work
            role = await sm.create_role("Editor", session=session)
            user = await sm.get_user("admin", session=session)
            updated = await sm.update_user(
                {"first_name": "X"},
                user,
                roles=[role.name],
                session=session,
            )
            assert any(r.name == "Editor" for r in updated.roles)


class TestSMGetUser:
    async def test_get_user_by_email(self, client, sm, db_session, admin_user):
        async with db_session.session() as session:
            u = await sm.get_user("admin@example.com", session=session)
            assert u is not None
            assert u.username == "admin"

    async def test_get_user_by_username(self, client, sm, db_session, admin_user):
        async with db_session.session() as session:
            u = await sm.get_user("admin", session=session)
            assert u is not None
            assert u.email == "admin@example.com"

    async def test_get_user_missing_returns_none(self, client, sm, db_session):
        async with db_session.session() as session:
            u = await sm.get_user("ghost", session=session)
            assert u is None


class TestSMResetPassword:
    async def test_reset_password_changes_hash(
        self, client, sm, db_session, admin_user
    ):
        async with db_session.session() as session:
            user = await sm.get_user("admin", session=session)
            old_hash = user.hashed_password
            await sm.reset_password(user, "newsecret123", session=session)
            await session.refresh(user)
            assert user.hashed_password != old_hash

    async def test_reset_password_inactive_raises(
        self, client, sm, db_session, admin_user
    ):
        from fastapi_users.exceptions import UserInactive

        async with db_session.session() as session:
            user = await sm.get_user("admin", session=session)
            user.active = False
            session.add(user)
            await session.commit()

            with pytest.raises(UserInactive):
                await sm.reset_password(
                    user,
                    "x",
                    session=session,
                    raise_exception="user_inactive",
                )


class TestSMGetRoles:
    async def test_get_roles_existing(self, client, sm, db_session, admin_user):
        async with db_session.session() as session:
            roles = await sm.get_roles(["Admin"], session=session)
            assert len(roles) == 1
            assert roles[0].name == "Admin"

    async def test_get_roles_mismatch_raises(
        self, client, sm, db_session, admin_user
    ):
        from fastapi_rtk.exceptions import RolesMismatchException

        async with db_session.session() as session:
            with pytest.raises(RolesMismatchException):
                await sm.get_roles(
                    ["Admin", "Nonexistent"],
                    session=session,
                    raise_exception="roles_mismatch",
                )

    async def test_get_roles_no_raise(self, client, sm, db_session, admin_user):
        async with db_session.session() as session:
            roles = await sm.get_roles(
                ["Admin", "Nonexistent"],
                session=session,
                raise_exception=False,
            )
            assert roles is None or len(roles) == 1


class TestSMSessionlessPaths:
    """Methods called without an explicit session open one internally."""

    async def test_create_user_without_session(self, client, sm):
        # Hits lines 122-134 (sessionless recursive call)
        user = await sm.create_user(
            username="solo",
            email="solo@example.com",
            password="solo1234",
            raise_exception=True,
        )
        assert user.username == "solo"

    async def test_get_user_without_session(self, client, sm, admin_user):
        # Lines 75-77
        user = await sm.get_user("admin")
        assert user is not None

    async def test_update_user_without_session(
        self, client, sm, db_session, admin_user
    ):
        async with db_session.session() as session:
            user = await sm.get_user("admin", session=session)
        # Lines 183-191
        updated = await sm.update_user({"first_name": "ZZZ"}, user)
        assert updated.first_name == "ZZZ"

    async def test_get_roles_without_session(self, client, sm, admin_user):
        # Lines 227-231
        roles = await sm.get_roles(["Admin"])
        assert len(roles) == 1

    async def test_create_role_without_session(self, client, sm):
        # Lines 266-270
        role = await sm.create_role("Solo")
        assert role.name == "Solo"

    async def test_reset_password_without_session(self, client, sm, admin_user):
        # Lines 305-312
        async with sys.modules["fastapi_rtk.db"].db.session() as session:
            user = await sm.get_user("admin", session=session)
        result = await sm.reset_password(user, "newpw1234")
        assert result is not None

    async def test_export_data_without_session(self, client, sm, admin_user):
        # Lines 347-349
        out = await sm.export_data("users", "json")
        assert "admin" in out

    async def test_create_permissions_without_session(self, client, sm):
        # Lines for create_permissions sessionless path
        perms = await sm.create_permissions(["can_test1", "can_test2"])
        assert len(perms) == 2

    async def test_create_apis_without_session(self, client, sm):
        apis = await sm.create_apis(["TestApi1", "TestApi2"])
        assert len(apis) == 2

    async def test_create_roles_without_session(self, client, sm):
        roles = await sm.create_roles(["RoleA", "RoleB"])
        assert len(roles) == 2

    async def test_associate_permission_with_api_without_session(self, client, sm):
        # Lines 581-587
        async with sys.modules["fastapi_rtk.db"].db.session() as session:
            perms = await sm.create_permissions(["can_assoc"], session=session)
            apis = await sm.create_apis(["AssocApi"], session=session)
        await sm.associate_list_of_permission_with_api(
            [(perms[0], apis[0])]
        )

    async def test_get_roles_no_raise_swallows_error(
        self, client, sm, monkeypatch, db_session
    ):
        # Force get_roles to raise via swapping the manager
        async with db_session.session() as session:
            from fastapi_users.exceptions import UserNotExists

            class BoomManager:
                async def get_roles_by_names(self, *args, **kwargs):
                    raise UserNotExists()

            from fastapi_rtk.globals import g

            monkeypatch.setattr(
                g.auth, "get_user_manager", lambda user_db: iter([BoomManager()])
            )
            result = await sm.get_roles(
                ["X"], session=session, raise_exception=False
            )
            assert result is None

    async def test_create_role_no_raise_swallows_error(
        self, client, sm, db_session, monkeypatch
    ):
        # Make Role constructor blow up
        async with db_session.session() as session:
            from fastapi_rtk.security.sqla import security_manager as sm_mod

            class Boom:
                def __init__(self, **kw):
                    raise RuntimeError("boom")

            monkeypatch.setattr(sm_mod, "Role", Boom)
            result = await sm.create_role(
                "X", session=session, raise_exception=False
            )
            assert result is None

    async def test_reset_password_no_raise_swallows(
        self, client, sm, admin_user, db_session, monkeypatch
    ):
        async with db_session.session() as session:
            user = await sm.get_user("admin", session=session)

            from fastapi_rtk.globals import g

            class BoomManager:
                async def forgot_password(self, *a, **kw):
                    raise RuntimeError("nope")

            monkeypatch.setattr(
                g.auth, "get_user_manager", lambda user_db: iter([BoomManager()])
            )
            result = await sm.reset_password(
                user, "x", session=session, raise_exception=False
            )
            assert result is None

    async def test_update_user_user_exists_re_raises(
        self, client, sm, admin_user, db_session, monkeypatch
    ):
        # `raise_exception="user_exists"` re-raises only UserAlreadyExists.
        # Other exceptions propagate too (final else branch).
        async with db_session.session() as session:
            user = await sm.get_user("admin", session=session)

            from fastapi_users.exceptions import UserAlreadyExists
            from fastapi_rtk.globals import g

            class BoomManager:
                async def update(self, *a, **kw):
                    raise UserAlreadyExists()

            monkeypatch.setattr(
                g.auth, "get_user_manager", lambda user_db: iter([BoomManager()])
            )
            import pytest

            with pytest.raises(UserAlreadyExists):
                await sm.update_user(
                    {"first_name": "Z"},
                    user,
                    session=session,
                    raise_exception="user_exists",
                )

    async def test_associate_permission_no_raise_swallows(
        self, client, sm, db_session, monkeypatch
    ):
        async with db_session.session() as session:
            # Force commit to fail
            real_commit = session.commit

            async def boom(*a, **kw):
                raise RuntimeError("commit boom")

            monkeypatch.setattr(session, "commit", boom)

            result = await sm.associate_list_of_permission_with_api(
                [], session=session, raise_exception=False
            )
            assert result is None
            # Restore
            monkeypatch.setattr(session, "commit", real_commit)

    async def test_associate_role_no_raise_swallows(
        self, client, sm, db_session, monkeypatch
    ):
        async with db_session.session() as session:

            async def boom(*a, **kw):
                raise RuntimeError("commit boom")

            monkeypatch.setattr(session, "commit", boom)
            result = await sm.associate_list_of_role_with_permission_api(
                [], session=session, raise_exception=False
            )
            assert result is None

    async def test_associate_role_with_permission_api_without_session(
        self, client, sm
    ):
        # Lines 652-658
        async with sys.modules["fastapi_rtk.db"].db.session() as session:
            perms = await sm.create_permissions(["can_assoc2"], session=session)
            apis = await sm.create_apis(["AssocApi2"], session=session)
            roles = await sm.create_roles(["AssocRole"], session=session)
            permission_apis = await sm.associate_list_of_permission_with_api(
                [(perms[0], apis[0])], session=session
            )
        await sm.associate_list_of_role_with_permission_api(
            [(roles[0], permission_apis[0])]
        )


class TestUsersApiCRUD:
    async def test_post_user_runs_post_add_hook(self, client, admin_token):
        # Triggers UsersApi.post_add (lines 243-248)
        response = await client.post(
            "/api/v1/users/",
            headers={"Authorization": f"Bearer {admin_token}"},
            json={
                "username": "newuser",
                "email": "newuser@example.com",
                "password": "userpw1234",
                "first_name": "",
                "last_name": "",
                "roles": [],
            },
        )
        assert response.status_code in (200, 201), response.text

    async def test_put_user_with_password_runs_post_update_hook(
        self, client, admin_token
    ):
        # Create a user
        post = await client.post(
            "/api/v1/users/",
            headers={"Authorization": f"Bearer {admin_token}"},
            json={
                "username": "putuser",
                "email": "putuser@example.com",
                "password": "userpw1234",
                "first_name": "",
                "last_name": "",
                "roles": [],
            },
        )
        assert post.status_code in (200, 201), post.text
        user_id = post.json()["id"]

        # PUT with new password -> post_update password branch (lines 251-257)
        put = await client.put(
            f"/api/v1/users/{user_id}",
            headers={"Authorization": f"Bearer {admin_token}"},
            json={
                "first_name": "Renamed",
                "password": "newpassword123",
            },
        )
        assert put.status_code == 200, put.text


class TestSMExportData:
    async def test_export_users_json(self, client, sm, db_session, admin_user):
        async with db_session.session() as session:
            out = await sm.export_data("users", "json", session=session)
            assert "admin" in out

    async def test_export_users_csv(self, client, sm, db_session, admin_user):
        async with db_session.session() as session:
            out = await sm.export_data("users", "csv", session=session)
            assert out.startswith("Username,Data\n")
            assert "admin" in out
