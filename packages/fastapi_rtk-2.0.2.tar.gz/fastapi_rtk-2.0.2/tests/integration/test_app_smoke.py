"""Integration smoke tests: verify the toolkit app boots, registers routes,
and serves the basics."""

import pytest

pytestmark = pytest.mark.asyncio


class TestAppBoots:
    async def test_openapi_schema_available(self, client):
        response = await client.get("/openapi.json")
        assert response.status_code == 200
        schema = response.json()
        assert "paths" in schema

    async def test_widgets_routes_registered(self, client):
        response = await client.get("/openapi.json")
        paths = response.json()["paths"]
        assert "/api/v1/widgets/" in paths
        assert "/api/v1/widgets/_info" in paths

    async def test_auth_routes_registered(self, client):
        response = await client.get("/openapi.json")
        paths = response.json()["paths"]
        # JWT login route
        assert any("/auth/jwt/login" in p for p in paths)

    async def test_metrics_exposed(self, client):
        response = await client.get("/metrics")
        assert response.status_code == 200
        assert "python_info" in response.text or "process_" in response.text
