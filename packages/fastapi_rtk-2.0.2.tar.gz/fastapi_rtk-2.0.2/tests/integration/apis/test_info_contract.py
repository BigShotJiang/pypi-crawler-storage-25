"""Integration: /_info JSON shape - the frontend ApiProvider contract.

Snapshot the keys the JS side depends on. Drift on any of these would
silently break the React frontend, so guard them explicitly.
"""

import pytest

pytestmark = pytest.mark.asyncio


class TestInfoShape:
    async def test_info_returns_200(self, client, admin_token):
        response = await client.get(
            "/api/v1/widgets/_info",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert response.status_code == 200

    async def test_info_top_level_keys(self, client, admin_token):
        response = await client.get(
            "/api/v1/widgets/_info",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        body = response.json()
        # Frontend ApiProvider relies on these
        for key in (
            "permissions",
            "add_columns",
            "edit_columns",
            "filters",
            "filter_options",
            "add_schema",
            "edit_schema",
            "add_title",
            "edit_title",
            "relations",
        ):
            assert key in body, f"missing key: {key}"

    async def test_info_columns_are_descriptors(self, client, admin_token):
        response = await client.get(
            "/api/v1/widgets/_info",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        body = response.json()
        # add_columns / edit_columns are list of objects with name + required
        for col in body["add_columns"]:
            assert "name" in col
            assert "required" in col

    async def test_info_includes_widget_columns(self, client, admin_token):
        response = await client.get(
            "/api/v1/widgets/_info",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        body = response.json()
        names = [c["name"] for c in body["add_columns"]]
        assert "name" in names

    async def test_info_permissions_reflect_role(self, client, admin_token):
        response = await client.get(
            "/api/v1/widgets/_info",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        body = response.json()
        # Admin role has all permissions
        assert "can_get" in body["permissions"]
        assert "can_post" in body["permissions"]

    async def test_info_no_token_returns_401(self, client):
        response = await client.get("/api/v1/widgets/_info")
        assert response.status_code == 401


class TestRelationsInInfo:
    async def test_widget_info_includes_country_relation(self, client, admin_token):
        response = await client.get(
            "/api/v1/widgets/_info",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        body = response.json()
        # `country` relation should appear in add_columns / edit_columns
        add_cols = [c["name"] for c in body["add_columns"]]
        assert "country" in add_cols or "country_id" in add_cols

    async def test_post_widget_with_country_relation(
        self, client, admin_token
    ):
        # Create a country first.
        country_resp = await client.post(
            "/api/v1/countries/",
            headers={"Authorization": f"Bearer {admin_token}"},
            json={"name": "Germany"},
        )
        assert country_resp.status_code == 200, country_resp.text
        country_id = country_resp.json()["id"]

        # Create a widget linked to that country.
        widget_resp = await client.post(
            "/api/v1/widgets/",
            headers={"Authorization": f"Bearer {admin_token}"},
            json={"name": "Bauhaus", "country": country_id},
        )
        assert widget_resp.status_code == 200, widget_resp.text
