"""Integration: OAuth login + callback HTTP routes.

Mocks an `httpx_oauth.BaseOAuth2` client and registers it via OAUTH_CLIENTS
config. Tests cover the authorize-redirect path and callback decode-error
path. Full callback (token exchange + user creation) requires deeper
httpx_oauth mocking, deferred.
"""

import contextlib
import sys
from unittest.mock import AsyncMock

import httpx
import pytest
import pytest_asyncio
from httpx_oauth.oauth2 import BaseOAuth2

pytestmark = pytest.mark.asyncio


@pytest_asyncio.fixture
async def oauth_app(make_toolkit_app, config_setter):
    """Toolkit app with cookie auth + a fake OAuth2 client registered."""
    fake_client = BaseOAuth2(
        client_id="cid",
        client_secret="csec",
        authorize_endpoint="https://oauth.example.com/authorize",
        access_token_endpoint="https://oauth.example.com/token",
        name="fake",
    )

    config_setter("AUTH_LOGIN_COOKIE", True)
    config_setter("OAUTH_PROVIDERS", [{"oauth_client": fake_client}])

    fastapi_app = make_toolkit_app()
    yield fastapi_app, fake_client


@pytest_asyncio.fixture
async def oauth_client(oauth_app):
    fastapi_app, fake_client = oauth_app
    transport = httpx.ASGITransport(app=fastapi_app)
    async with fastapi_app.router.lifespan_context(fastapi_app):
        async with httpx.AsyncClient(
            transport=transport, base_url="http://testserver"
        ) as ac:
            yield ac, fake_client


class TestOAuthRouteRegistration:
    async def test_authorize_route_registered(self, oauth_client):
        client, _ = oauth_client
        response = await client.get("/openapi.json")
        paths = response.json()["paths"]
        # cookie backend prefix is "auth", oauth login at /auth/login/<client>
        assert any("login/fake" in p for p in paths)

    async def test_callback_route_registered(self, oauth_client):
        client, _ = oauth_client
        response = await client.get("/openapi.json")
        paths = response.json()["paths"]
        assert any("oauth-authorized/fake" in p for p in paths)


class TestAuthorizeRedirect:
    async def test_authorize_redirects_to_provider(self, oauth_client):
        client, _ = oauth_client
        # Don't follow redirect - we want to inspect Location header
        response = await client.get(
            "/api/v1/auth/login/fake",
            follow_redirects=False,
        )
        assert response.status_code in (302, 307)
        assert "oauth.example.com/authorize" in response.headers.get("location", "")

    async def test_authorize_with_popup_param(self, oauth_client):
        client, _ = oauth_client
        response = await client.get(
            "/api/v1/auth/login/fake?popup=1",
            follow_redirects=False,
        )
        assert response.status_code in (302, 307)

    async def test_authorize_with_popup_true_param(self, oauth_client):
        client, _ = oauth_client
        response = await client.get(
            "/api/v1/auth/login/fake?popup=true",
            follow_redirects=False,
        )
        assert response.status_code in (302, 307)


class TestAuthorizeRedirectUrlBranches:
    """redirect_url + redirect_url_factory route branches."""

    async def test_redirect_url_branch(
        self, make_toolkit_app, config_setter
    ):
        fake_client = BaseOAuth2(
            client_id="cid",
            client_secret="csec",
            authorize_endpoint="https://oauth.example.com/authorize",
            access_token_endpoint="https://oauth.example.com/token",
            name="fakeRedirectUrl",
        )
        config_setter("AUTH_LOGIN_COOKIE", True)
        config_setter(
            "OAUTH_PROVIDERS",
            [
                {
                    "oauth_client": fake_client,
                    "redirect_url": "https://app.example.com/cb",
                }
            ],
        )
        app = make_toolkit_app()
        transport = httpx.ASGITransport(app=app)
        async with app.router.lifespan_context(app):
            async with httpx.AsyncClient(
                transport=transport, base_url="http://testserver"
            ) as ac:
                r = await ac.get(
                    "/api/v1/auth/login/fakeRedirectUrl",
                    follow_redirects=False,
                )
                assert r.status_code in (302, 307)
                # redirect_url=https://app.example.com/cb is encoded in the
                # provider authorize URL as redirect_uri
                assert "app.example.com" in r.headers.get("location", "")

    async def test_redirect_url_factory_branch(
        self, make_toolkit_app, config_setter
    ):
        fake_client = BaseOAuth2(
            client_id="cid",
            client_secret="csec",
            authorize_endpoint="https://oauth.example.com/authorize",
            access_token_endpoint="https://oauth.example.com/token",
            name="fakeFactory",
        )

        async def factory(request, scopes):
            return "https://factory.example.com/cb"

        config_setter("AUTH_LOGIN_COOKIE", True)
        config_setter(
            "OAUTH_PROVIDERS",
            [
                {
                    "oauth_client": fake_client,
                    "redirect_url_factory": factory,
                }
            ],
        )
        app = make_toolkit_app()
        transport = httpx.ASGITransport(app=app)
        async with app.router.lifespan_context(app):
            async with httpx.AsyncClient(
                transport=transport, base_url="http://testserver"
            ) as ac:
                r = await ac.get(
                    "/api/v1/auth/login/fakeFactory", follow_redirects=False
                )
                assert r.status_code in (302, 307)
                assert "factory.example.com" in r.headers.get("location", "")


class TestCallbackErrors:
    async def test_callback_invalid_state_returns_400(self, oauth_client, monkeypatch):
        client, fake_client = oauth_client

        # Patch get_access_token + get_id_email so the OAuth2AuthorizeCallback
        # dependency doesn't actually hit the network.
        from httpx_oauth.oauth2 import OAuth2Token

        async def fake_get_access_token(self, code, redirect_uri, code_verifier=None):
            return OAuth2Token({"access_token": "fake-token"})

        async def fake_get_id_email(self, token):
            return ("acct-1", "oauth-user@example.com")

        monkeypatch.setattr(BaseOAuth2, "get_access_token", fake_get_access_token)
        monkeypatch.setattr(BaseOAuth2, "get_id_email", fake_get_id_email)

        response = await client.get(
            "/api/v1/auth/oauth-authorized/fake?code=x&state=invalid-jwt",
        )
        assert response.status_code == 400
        body = response.json()
        # Either OAuth2AuthorizeCallback rejects state with INVALID_STATE_TOKEN
        # OR routers.py callback decodes failure with ACCESS_TOKEN_DECODE_ERROR.
        # Both are 400.
        assert "detail" in body

    async def test_callback_no_state_returns_error(self, oauth_client):
        client, _ = oauth_client
        response = await client.get(
            "/api/v1/auth/oauth-authorized/fake",
        )
        # Missing query params -> validation error or 400
        assert response.status_code >= 400

    async def test_callback_expired_state_returns_400(
        self, oauth_client, monkeypatch
    ):
        from datetime import datetime, timedelta, timezone

        import jwt as pyjwt
        from fastapi_users.router.oauth import STATE_TOKEN_AUDIENCE
        from httpx_oauth.oauth2 import OAuth2Token
        from fastapi_rtk.globals import g

        client, fake_client = oauth_client

        async def fake_get_access_token(self, code, redirect_uri, code_verifier=None):
            return OAuth2Token({"access_token": "tok"})

        async def fake_get_id_email(self, token):
            return ("acct-exp", "exp@example.com")

        monkeypatch.setattr(BaseOAuth2, "get_access_token", fake_get_access_token)
        monkeypatch.setattr(BaseOAuth2, "get_id_email", fake_get_id_email)

        # Hand-craft an expired state JWT (exp in the past)
        secret = g.auth.secret_key
        if hasattr(secret, "get_secret_value"):
            secret = secret.get_secret_value()
        payload = {
            "aud": STATE_TOKEN_AUDIENCE,
            "exp": datetime.now(timezone.utc) - timedelta(hours=1),
        }
        expired = pyjwt.encode(payload, secret, algorithm="HS256")
        response = await client.get(
            f"/api/v1/auth/oauth-authorized/fake?code=x&state={expired}",
        )
        assert response.status_code == 400
        assert "ACCESS_TOKEN_ALREADY_EXPIRED" in response.text


class TestCallbackSuccessFlow:
    """Successful OAuth callback creates a new user and authenticates."""

    async def test_callback_creates_new_user(self, oauth_client, monkeypatch):
        from fastapi_users.router.oauth import (
            STATE_TOKEN_AUDIENCE,
            generate_state_token,
        )
        from fastapi_users.jwt import SecretType
        from httpx_oauth.oauth2 import OAuth2Token
        from fastapi_rtk.globals import g

        client, fake_client = oauth_client

        async def fake_get_access_token(self, code, redirect_uri, code_verifier=None):
            return OAuth2Token(
                {"access_token": "fake-token", "expires_at": 9999999999}
            )

        async def fake_get_id_email(self, token):
            return ("oauth-acct-1", "newoauth@example.com")

        monkeypatch.setattr(BaseOAuth2, "get_access_token", fake_get_access_token)
        monkeypatch.setattr(BaseOAuth2, "get_id_email", fake_get_id_email)

        # Generate a valid state JWT using the toolkit's auth secret.
        state = generate_state_token({}, g.auth.secret_key)

        response = await client.get(
            f"/api/v1/auth/oauth-authorized/fake?code=x&state={state}",
            follow_redirects=False,
        )
        # Cookie backend success returns 204 with Set-Cookie OR redirects.
        assert response.status_code in (200, 204, 302, 307)

    async def test_callback_existing_email_no_associate_returns_400(
        self, oauth_client, monkeypatch
    ):
        from fastapi_users.router.oauth import generate_state_token
        from httpx_oauth.oauth2 import OAuth2Token
        from fastapi_rtk.globals import g

        client, fake_client = oauth_client

        # Pre-create a user with the email the OAuth provider returns.
        import sys

        db = sys.modules["fastapi_rtk.db"].db
        sm = g.current_app.sm
        async with db.session() as session:
            await sm.create_user(
                username="existing",
                email="existing@example.com",
                password="pw1234",
                session=session,
                raise_exception=True,
            )

        async def fake_get_access_token(self, code, redirect_uri, code_verifier=None):
            return OAuth2Token({"access_token": "tok"})

        async def fake_get_id_email(self, token):
            return ("acct-x", "existing@example.com")

        monkeypatch.setattr(BaseOAuth2, "get_access_token", fake_get_access_token)
        monkeypatch.setattr(BaseOAuth2, "get_id_email", fake_get_id_email)

        state = generate_state_token({}, g.auth.secret_key)
        response = await client.get(
            f"/api/v1/auth/oauth-authorized/fake?code=x&state={state}",
        )
        # Email collision without associate_by_email -> OAUTH_USER_ALREADY_EXISTS
        assert response.status_code == 400

    async def test_callback_popup_returns_html(self, oauth_client, monkeypatch):
        from fastapi_users.router.oauth import generate_state_token
        from httpx_oauth.oauth2 import OAuth2Token
        from fastapi_rtk.globals import g

        client, fake_client = oauth_client

        async def fake_get_access_token(self, code, redirect_uri, code_verifier=None):
            return OAuth2Token({"access_token": "tok"})

        async def fake_get_id_email(self, token):
            return ("acct-popup", "popup@example.com")

        monkeypatch.setattr(BaseOAuth2, "get_access_token", fake_get_access_token)
        monkeypatch.setattr(BaseOAuth2, "get_id_email", fake_get_id_email)

        # Generate state token with popup=true so callback returns HTML response
        state = generate_state_token({"popup": "true"}, g.auth.secret_key)
        response = await client.get(
            f"/api/v1/auth/oauth-authorized/fake?code=x&state={state}",
            follow_redirects=False,
        )
        assert response.status_code == 200
        assert "text/html" in response.headers.get("content-type", "")

    async def test_callback_redirect_url_after_callback(
        self, make_toolkit_app, config_setter
    ):
        from fastapi_users.router.oauth import generate_state_token
        from httpx_oauth.oauth2 import OAuth2Token
        from fastapi_rtk.globals import g

        fake_client = BaseOAuth2(
            client_id="cid",
            client_secret="csec",
            authorize_endpoint="https://oauth.example.com/authorize",
            access_token_endpoint="https://oauth.example.com/token",
            name="fakeRedirAfter",
        )
        config_setter("AUTH_LOGIN_COOKIE", True)
        config_setter(
            "OAUTH_PROVIDERS",
            [
                {
                    "oauth_client": fake_client,
                    "redirect_url_after_callback": "https://app.example.com/done",
                }
            ],
        )
        app = make_toolkit_app()

        async def fake_get_access_token(self, code, redirect_uri, code_verifier=None):
            return OAuth2Token({"access_token": "tok"})

        async def fake_get_id_email(self, token):
            return ("acct-redir", "redir@example.com")

        from unittest.mock import patch

        transport = httpx.ASGITransport(app=app)
        async with app.router.lifespan_context(app):
            async with httpx.AsyncClient(
                transport=transport, base_url="http://testserver"
            ) as ac:
                with patch.object(BaseOAuth2, "get_access_token", fake_get_access_token), \
                    patch.object(BaseOAuth2, "get_id_email", fake_get_id_email):
                    state = generate_state_token({}, g.auth.secret_key)
                    r = await ac.get(
                        f"/api/v1/auth/oauth-authorized/fakeRedirAfter?code=x&state={state}",
                        follow_redirects=False,
                    )
                    assert r.status_code in (302, 307)
                    assert "app.example.com/done" in r.headers.get("location", "")

    async def test_callback_email_unavailable_returns_400(
        self, oauth_client, monkeypatch
    ):
        from fastapi_users.router.oauth import generate_state_token
        from httpx_oauth.oauth2 import OAuth2Token
        from fastapi_rtk.globals import g

        client, fake_client = oauth_client

        async def fake_get_access_token(self, code, redirect_uri, code_verifier=None):
            return OAuth2Token({"access_token": "tok"})

        async def fake_get_id_email(self, token):
            return ("acct-y", None)  # Provider didn't return an email

        monkeypatch.setattr(BaseOAuth2, "get_access_token", fake_get_access_token)
        monkeypatch.setattr(BaseOAuth2, "get_id_email", fake_get_id_email)

        state = generate_state_token({}, g.auth.secret_key)
        response = await client.get(
            f"/api/v1/auth/oauth-authorized/fake?code=x&state={state}",
        )
        assert response.status_code == 400
        assert "OAUTH_NOT_AVAILABLE_EMAIL" in response.text


@pytest_asyncio.fixture
async def associate_app(make_toolkit_app, config_setter):
    """Toolkit app with cookie auth + associate router mounted manually."""
    from fastapi import APIRouter
    from fastapi_rtk.routers import get_oauth_associate_router

    fake_client = BaseOAuth2(
        client_id="cid",
        client_secret="csec",
        authorize_endpoint="https://oauth.example.com/authorize",
        access_token_endpoint="https://oauth.example.com/token",
        name="associate",
    )

    config_setter("AUTH_LOGIN_COOKIE", True)
    config_setter("OAUTH_PROVIDERS", [])

    fastapi_app = make_toolkit_app()

    # Mount associate router after toolkit init
    from fastapi_rtk.globals import g
    from fastapi_rtk.security.sqla.models import User
    from fastapi_rtk.schemas import generate_user_get_schema

    user_schema = generate_user_get_schema(User)
    associate_router = get_oauth_associate_router(
        oauth_client=fake_client,
        authenticator=g.auth.fastapi_users.authenticator,
        get_user_manager=g.auth.fastapi_users.get_user_manager,
        user_schema=user_schema,
        state_secret=g.auth.secret_key,
        redirect_url_after_callback="https://app.example.com/done",
    )
    fastapi_app.include_router(associate_router, prefix="/api/v1/auth/associate")
    yield fastapi_app, fake_client


@pytest_asyncio.fixture
async def associate_client(associate_app):
    fastapi_app, fake_client = associate_app
    transport = httpx.ASGITransport(app=fastapi_app)
    async with fastapi_app.router.lifespan_context(fastapi_app):
        async with httpx.AsyncClient(
            transport=transport, base_url="http://testserver"
        ) as ac:
            yield ac, fake_client


class TestAssociateRouter:
    async def test_associate_routes_registered(self, associate_client):
        client, _ = associate_client
        response = await client.get("/openapi.json")
        paths = response.json()["paths"]
        assert any("/api/v1/auth/associate/login/associate" in p for p in paths)
        assert any(
            "/api/v1/auth/associate/oauth-authorized/associate" in p for p in paths
        )

    async def test_associate_authorize_requires_auth(self, associate_client):
        client, _ = associate_client
        # No bearer/cookie -> 401
        r = await client.get(
            "/api/v1/auth/associate/login/associate", follow_redirects=False
        )
        assert r.status_code == 401

    async def test_associate_callback_requires_auth(self, associate_client):
        client, _ = associate_client
        r = await client.get(
            "/api/v1/auth/associate/oauth-authorized/associate?code=x&state=y"
        )
        assert r.status_code == 401

    async def test_associate_authorize_authenticated_redirects(
        self, associate_client
    ):
        import sys

        from fastapi_rtk.globals import g

        client, _ = associate_client

        # Seed an admin user + login
        db = sys.modules["fastapi_rtk.db"].db
        sm = g.current_app.sm
        async with db.session() as session:
            await sm.create_user(
                username="assoc_admin",
                email="assoc@example.com",
                password="assoc123pw",
                roles=["Admin"],
                session=session,
                raise_exception=True,
            )
        login = await client.post(
            "/api/v1/auth/jwt/login",
            data={"username": "assoc_admin", "password": "assoc123pw"},
        )
        token = login.json()["access_token"]

        r = await client.get(
            "/api/v1/auth/associate/login/associate",
            headers={"Authorization": f"Bearer {token}"},
            follow_redirects=False,
        )
        assert r.status_code in (302, 307)
        assert "oauth.example.com" in r.headers.get("location", "")
