"""Integration: login -> token -> protected request flow."""

import pytest

pytestmark = pytest.mark.asyncio


class TestLogin:
    async def test_login_returns_token(self, client, admin_user):
        response = await client.post(
            "/api/v1/auth/jwt/login",
            data={"username": "admin", "password": "adminpass123"},
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert "access_token" in body
        assert body["token_type"] == "bearer"

    async def test_login_wrong_password(self, client, admin_user):
        response = await client.post(
            "/api/v1/auth/jwt/login",
            data={"username": "admin", "password": "wrong"},
        )
        assert response.status_code == 400

    async def test_login_unknown_user(self, client, admin_user):
        response = await client.post(
            "/api/v1/auth/jwt/login",
            data={"username": "ghost", "password": "x"},
        )
        assert response.status_code == 400


class TestGetUserEndpoint:
    async def test_returns_current_user(self, client, admin_token):
        response = await client.get(
            "/api/v1/auth/user",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert response.status_code == 200
        body = response.json()
        assert body["username"] == "admin"
        assert body["email"] == "admin@example.com"

    async def test_no_token_returns_401(self, client):
        response = await client.get("/api/v1/auth/user")
        assert response.status_code == 401


class TestUpdateUserEndpoint:
    async def test_update_user_changes_email(self, client, admin_token):
        response = await client.put(
            "/api/v1/auth/user",
            headers={"Authorization": f"Bearer {admin_token}"},
            json={"email": "renamed@example.com"},
        )
        assert response.status_code == 200, response.text
        # Re-fetch and verify
        check = await client.get(
            "/api/v1/auth/user",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert check.json()["email"] == "renamed@example.com"

    async def test_update_user_no_token_returns_401(self, client):
        response = await client.put("/api/v1/auth/user", json={})
        assert response.status_code == 401


class TestLoginJson:
    async def test_login_json_returns_token(self, client, admin_user):
        response = await client.post(
            "/api/v1/auth/jwt/login-json",
            json={"username": "admin", "password": "adminpass123"},
        )
        assert response.status_code == 200, response.text
        body = response.json()
        assert "access_token" in body

    async def test_login_json_wrong_password(self, client, admin_user):
        response = await client.post(
            "/api/v1/auth/jwt/login-json",
            json={"username": "admin", "password": "wrong"},
        )
        assert response.status_code == 400


class TestLogout:
    async def test_logout_returns_204(self, client, admin_user):
        # Cookie backend returns 204 on logout. JWT bearer just clears.
        login = await client.post(
            "/api/v1/auth/jwt/login",
            data={"username": "admin", "password": "adminpass123"},
        )
        token = login.json()["access_token"]
        response = await client.post(
            "/api/v1/auth/jwt/logout",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code in (200, 204)


class TestOptionalAuthRouters:
    """Reset-password + verify routes only registered when settings flip on."""

    async def test_reset_password_router_registered(
        self, make_toolkit_app, config_setter
    ):
        import httpx

        config_setter("AUTH_USER_RESET_PASSWORD", True)
        config_setter("AUTH_USER_VERIFY", True)
        app = make_toolkit_app()
        async with app.router.lifespan_context(app):
            transport = httpx.ASGITransport(app=app)
            async with httpx.AsyncClient(
                transport=transport, base_url="http://testserver"
            ) as ac:
                r = await ac.get("/openapi.json")
                paths = r.json()["paths"]
                # Both routers attached -> their paths show up
                assert any("forgot-password" in p for p in paths)
                assert any("verify" in p for p in paths)
