"""Integration fixtures: a live FastAPI app with sqlite + JWT auth.

Each test gets its own app instance and in-memory database so state doesn't
leak across tests. The fixture exposes:

- `app` - FastAPI instance with toolkit initialized + a Widget API mounted
- `client` - httpx.AsyncClient bound to the app via ASGITransport
- `admin_token` - bearer token for an Admin user (full RBAC)
- `viewer_token` - bearer token for a read-only user (no Admin role)

Builds on top-level `make_toolkit_app` factory in `tests/conftest.py`.
"""

import contextlib

import httpx
import pytest_asyncio
import sqlalchemy

from fastapi_rtk.api.model_rest_api import ModelRestApi
from fastapi_rtk.backends.sqla.interface import SQLAInterface
from fastapi_rtk.backends.sqla.model import Model


class IntegrationCountry(Model):
    __tablename__ = "integration_country"
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
    name = sqlalchemy.Column(sqlalchemy.String(50), nullable=False)


class IntegrationWidget(Model):
    __tablename__ = "integration_widget"
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
    name = sqlalchemy.Column(sqlalchemy.String(50), nullable=False)
    description = sqlalchemy.Column(sqlalchemy.String(200))
    country_id = sqlalchemy.Column(
        sqlalchemy.Integer, sqlalchemy.ForeignKey("integration_country.id")
    )
    country = sqlalchemy.orm.relationship("IntegrationCountry")


class WidgetsApi(ModelRestApi):
    resource_name = "widgets"
    datamodel = SQLAInterface(IntegrationWidget)


class CountriesApi(ModelRestApi):
    resource_name = "countries"
    datamodel = SQLAInterface(IntegrationCountry)


@pytest_asyncio.fixture
async def app(make_toolkit_app):
    """Toolkit-wired FastAPI app with sqlite + Widget API."""
    import sys

    @contextlib.asynccontextmanager
    async def widget_lifespan(_app):
        # Create only the IntegrationCountry + IntegrationWidget tables after
        # the toolkit's lifespan has initialized the engine + ab_* tables.
        # Avoids pulling unrelated tables registered by other tests (audit
        # JSONB columns won't render under sqlite).
        from sqlalchemy.ext.asyncio import AsyncEngine

        engine = sys.modules["fastapi_rtk.db"].db._engine
        if isinstance(engine, AsyncEngine):
            async with engine.begin() as conn:
                # Country first (parent of FK)
                await conn.run_sync(
                    lambda c: IntegrationCountry.__table__.create(c, checkfirst=True)
                )
                await conn.run_sync(
                    lambda c: IntegrationWidget.__table__.create(c, checkfirst=True)
                )
        yield

    fastapi_app = make_toolkit_app(
        extra_apis=[CountriesApi, WidgetsApi],
        extra_lifespans=[widget_lifespan],
    )
    yield fastapi_app


@pytest_asyncio.fixture
async def client(app):
    """An httpx.AsyncClient with lifespan='on' so startup hooks fire."""
    transport = httpx.ASGITransport(app=app)
    async with _lifespan_context(app):
        async with httpx.AsyncClient(
            transport=transport, base_url="http://testserver"
        ) as ac:
            yield ac


@contextlib.asynccontextmanager
async def _lifespan_context(app):
    """Run the FastAPI lifespan context."""
    async with app.router.lifespan_context(app):
        yield


@pytest_asyncio.fixture
async def admin_user(client):
    """Seed an admin user via the SecurityManager."""
    import sys

    db = sys.modules["fastapi_rtk.db"].db
    from fastapi_rtk.globals import g

    sm = g.current_app.sm
    async with db.session() as session:
        user = await sm.create_user(
            username="admin",
            email="admin@example.com",
            password="adminpass123",
            roles=["Admin"],
            session=session,
            raise_exception=True,
        )
        assert user is not None
        return user


@pytest_asyncio.fixture
async def viewer_user(client):
    """Seed a read-only user (no roles)."""
    import sys

    db = sys.modules["fastapi_rtk.db"].db
    from fastapi_rtk.globals import g

    sm = g.current_app.sm
    async with db.session() as session:
        user = await sm.create_user(
            username="viewer",
            email="viewer@example.com",
            password="viewerpass123",
            session=session,
            raise_exception=True,
        )
        assert user is not None
        return user


@pytest_asyncio.fixture
async def admin_token(client, admin_user):
    """Login the admin and return the JWT bearer token."""
    response = await client.post(
        "/api/v1/auth/jwt/login",
        data={"username": "admin", "password": "adminpass123"},
    )
    assert response.status_code == 200, response.text
    return response.json()["access_token"]


@pytest_asyncio.fixture
async def viewer_token(client, viewer_user):
    """Login the viewer and return the JWT bearer token."""
    response = await client.post(
        "/api/v1/auth/jwt/login",
        data={"username": "viewer", "password": "viewerpass123"},
    )
    assert response.status_code == 200, response.text
    return response.json()["access_token"]
