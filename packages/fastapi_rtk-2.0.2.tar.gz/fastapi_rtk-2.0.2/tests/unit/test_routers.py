"""Tier 11 - tests for fastapi_rtk.routers.

Smoke tests cover OAuth2AuthorizeCallback init branches + JWT decode error,
plus router-builder smoke tests for get_oauth_router / get_oauth_associate_router /
get_auth_router that verify route names are registered. End-to-end auth flows
(login/logout/oauth callback) are deferred to tier 15.
"""

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
from fastapi_users.authentication import (
    AuthenticationBackend,
    BearerTransport,
    JWTStrategy,
)
from fastapi_users.router.oauth import STATE_TOKEN_AUDIENCE, generate_state_token
from httpx_oauth.integrations.fastapi import OAuth2AuthorizeCallbackError
from httpx_oauth.oauth2 import BaseOAuth2

from fastapi_rtk.routers import (
    OAuth2AuthorizeCallback,
    get_auth_router,
    get_oauth_associate_router,
    get_oauth_router,
)


@pytest.fixture
def oauth_client():
    return BaseOAuth2(
        client_id="cid",
        client_secret="csec",
        authorize_endpoint="https://example.com/authorize",
        access_token_endpoint="https://example.com/token",
        name="dummy",
    )


@pytest.fixture
def state_secret():
    return "tier11-secret-key-32-bytes-padding"


@pytest.fixture
def backend():
    transport = BearerTransport(tokenUrl="auth/jwt/login")

    def get_strategy():
        return JWTStrategy(secret="x" * 32, lifetime_seconds=3600)

    return AuthenticationBackend(
        name="jwt", transport=transport, get_strategy=get_strategy
    )


class TestOAuth2AuthorizeCallbackInit:
    def test_with_state_secret(self, oauth_client, state_secret):
        cb = OAuth2AuthorizeCallback(oauth_client, state_secret=state_secret)
        assert cb.state_secret == state_secret

    def test_without_state_secret(self, oauth_client):
        cb = OAuth2AuthorizeCallback(oauth_client, route_name="route")
        assert cb.state_secret is None


class TestOAuth2AuthorizeCallbackCall:
    @pytest.mark.asyncio
    async def test_invalid_state_token_raises(self, oauth_client, state_secret):
        cb = OAuth2AuthorizeCallback(oauth_client, state_secret=state_secret)
        request = SimpleNamespace(state=SimpleNamespace())
        with pytest.raises(OAuth2AuthorizeCallbackError):
            await cb(request, code="x", state="not-a-jwt")

    @pytest.mark.asyncio
    async def test_decoded_state_used_as_redirect(self, oauth_client, state_secret):
        cb = OAuth2AuthorizeCallback(oauth_client, state_secret=state_secret)
        token = generate_state_token(
            {"redirect_url": "https://app.example.com/cb"}, state_secret
        )
        request = SimpleNamespace(state=SimpleNamespace())

        # Call into super().__call__ patched out, just verify state decodes.
        async def fake_super(self, request, code, code_verifier, state, error):
            return ("token", state)

        cb_super = OAuth2AuthorizeCallback.__bases__[0]
        original = cb_super.__call__
        try:
            cb_super.__call__ = fake_super
            await cb(request, code="x", state=token)
        finally:
            cb_super.__call__ = original

        assert request.state.state_data["redirect_url"] == "https://app.example.com/cb"


class TestGetOAuthRouter:
    def test_redirect_url_path(self, oauth_client, backend, state_secret):
        router = get_oauth_router(
            oauth_client=oauth_client,
            backend=backend,
            get_user_manager=MagicMock(),
            state_secret=state_secret,
            redirect_url="https://app.example.com/cb",
        )
        names = [r.name for r in router.routes]
        assert "oauth:dummy.jwt.authorize" in names
        assert "oauth:dummy.jwt.callback" in names

    def test_redirect_url_factory_path(self, oauth_client, backend, state_secret):
        router = get_oauth_router(
            oauth_client=oauth_client,
            backend=backend,
            get_user_manager=MagicMock(),
            state_secret=state_secret,
            redirect_url_factory=lambda req, scopes: "https://x",
        )
        assert router is not None
        assert len(router.routes) == 2

    def test_default_path(self, oauth_client, backend, state_secret):
        router = get_oauth_router(
            oauth_client=oauth_client,
            backend=backend,
            get_user_manager=MagicMock(),
            state_secret=state_secret,
        )
        names = [r.name for r in router.routes]
        assert "oauth:dummy.jwt.authorize" in names


class TestGetOAuthAssociateRouter:
    def test_default_path(self, oauth_client, backend, state_secret):
        authenticator = MagicMock()
        authenticator.current_user = MagicMock(return_value=lambda: None)
        router = get_oauth_associate_router(
            oauth_client=oauth_client,
            authenticator=authenticator,
            get_user_manager=MagicMock(),
            user_schema=MagicMock,
            state_secret=state_secret,
        )
        names = [r.name for r in router.routes]
        assert "oauth-associate:dummy.authorize" in names
        assert "oauth-associate:dummy.callback" in names

    def test_with_redirect_url(self, oauth_client, backend, state_secret):
        authenticator = MagicMock()
        authenticator.current_user = MagicMock(return_value=lambda: None)
        router = get_oauth_associate_router(
            oauth_client=oauth_client,
            authenticator=authenticator,
            get_user_manager=MagicMock(),
            user_schema=MagicMock,
            state_secret=state_secret,
            redirect_url="https://app.example.com/cb",
        )
        assert router is not None

    def test_with_redirect_url_factory(self, oauth_client, backend, state_secret):
        authenticator = MagicMock()
        authenticator.current_user = MagicMock(return_value=lambda: None)
        router = get_oauth_associate_router(
            oauth_client=oauth_client,
            authenticator=authenticator,
            get_user_manager=MagicMock(),
            user_schema=MagicMock,
            state_secret=state_secret,
            redirect_url_factory=lambda req, scopes: "https://x",
        )
        assert router is not None


class TestGetAuthRouter:
    def test_login_logout_routes(self, backend):
        authenticator = MagicMock()
        authenticator.current_user_token = MagicMock(return_value=lambda: None)
        router = get_auth_router(
            backend=backend,
            get_user_manager=MagicMock(),
            authenticator=authenticator,
        )
        names = [r.name for r in router.routes]
        assert "auth:jwt.login" in names
        assert "auth:jwt.login-json" in names
        assert "auth:jwt.logout" in names

    def test_with_auth_type_ldap(self, backend):
        authenticator = MagicMock()
        authenticator.current_user_token = MagicMock(return_value=lambda: None)
        router = get_auth_router(
            backend=backend,
            get_user_manager=MagicMock(),
            authenticator=authenticator,
            auth_type="ldap",
        )
        names = [r.name for r in router.routes]
        assert "auth:jwt.login" in names

    def test_with_requires_verification(self, backend):
        authenticator = MagicMock()
        authenticator.current_user_token = MagicMock(return_value=lambda: None)
        router = get_auth_router(
            backend=backend,
            get_user_manager=MagicMock(),
            authenticator=authenticator,
            requires_verification=True,
        )
        # Ensure constructed without error.
        authenticator.current_user_token.assert_called_with(
            active=True, verified=True
        )
        assert router is not None


class TestGetOAuthAssociateRouterEndpointBodies:
    """Direct calls to the associate router endpoints to cover lines 339-443."""

    def _endpoint(self, router, name):
        return next(r.endpoint for r in router.routes if r.name == name)

    @pytest.mark.asyncio
    async def test_authorize_with_redirect_url_branch(self, oauth_client, state_secret):
        from unittest.mock import AsyncMock

        authenticator = MagicMock()
        authenticator.current_user = MagicMock(return_value=lambda: None)
        router = get_oauth_associate_router(
            oauth_client=oauth_client,
            authenticator=authenticator,
            get_user_manager=MagicMock(),
            user_schema=MagicMock,
            state_secret=state_secret,
            redirect_url="https://app.example.com/cb",
        )
        authorize = self._endpoint(router, "oauth-associate:dummy.authorize")

        from unittest.mock import patch

        request = MagicMock()
        user = MagicMock(id=42)
        with patch.object(
            oauth_client,
            "get_authorization_url",
            AsyncMock(return_value="https://oauth/redirect"),
        ):
            resp = await authorize(request, scopes=["read"], user=user)
        # Status code 307 default for RedirectResponse
        assert resp.status_code in (302, 307)

    @pytest.mark.asyncio
    async def test_authorize_with_redirect_url_factory_branch(
        self, oauth_client, state_secret
    ):
        from unittest.mock import AsyncMock

        async def factory(request, scopes):
            return "https://factory.example.com/cb"

        authenticator = MagicMock()
        authenticator.current_user = MagicMock(return_value=lambda: None)
        router = get_oauth_associate_router(
            oauth_client=oauth_client,
            authenticator=authenticator,
            get_user_manager=MagicMock(),
            user_schema=MagicMock,
            state_secret=state_secret,
            redirect_url_factory=factory,
        )
        authorize = self._endpoint(router, "oauth-associate:dummy.authorize")

        from unittest.mock import patch

        request = MagicMock()
        user = MagicMock(id=7)
        with patch.object(
            oauth_client,
            "get_authorization_url",
            AsyncMock(return_value="https://oauth/redirect"),
        ):
            resp = await authorize(request, scopes=["read"], user=user)
        assert resp.status_code in (302, 307)

    @pytest.mark.asyncio
    async def test_callback_email_unavailable_raises(self, oauth_client, state_secret):
        from unittest.mock import AsyncMock

        from fastapi import HTTPException

        authenticator = MagicMock()
        authenticator.current_user = MagicMock(return_value=lambda: None)
        router = get_oauth_associate_router(
            oauth_client=oauth_client,
            authenticator=authenticator,
            get_user_manager=MagicMock(),
            user_schema=MagicMock,
            state_secret=state_secret,
        )
        callback = self._endpoint(router, "oauth-associate:dummy.callback")

        from unittest.mock import patch

        with patch.object(
            oauth_client,
            "get_id_email",
            AsyncMock(return_value=("acc", None)),
        ):
            request = MagicMock(state=SimpleNamespace())
            user = MagicMock(id=1)
            access_token_state = ({"access_token": "tok"}, "state-x")
            mgr = MagicMock()
            with pytest.raises(HTTPException) as exc:
                await callback(request, user, access_token_state, mgr)
            assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_callback_invalid_state_decode_raises(
        self, oauth_client, state_secret
    ):
        from unittest.mock import AsyncMock

        from fastapi import HTTPException

        authenticator = MagicMock()
        authenticator.current_user = MagicMock(return_value=lambda: None)
        router = get_oauth_associate_router(
            oauth_client=oauth_client,
            authenticator=authenticator,
            get_user_manager=MagicMock(),
            user_schema=MagicMock,
            state_secret=state_secret,
        )
        callback = self._endpoint(router, "oauth-associate:dummy.callback")

        from unittest.mock import patch

        with patch.object(
            oauth_client,
            "get_id_email",
            AsyncMock(return_value=("acc", "x@y.com")),
        ):
            request = MagicMock(state=SimpleNamespace())
            user = MagicMock(id=1)
            access_token_state = ({"access_token": "tok"}, "not-a-jwt")
            mgr = MagicMock()
            with pytest.raises(HTTPException) as exc:
                await callback(request, user, access_token_state, mgr)
            assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_callback_state_sub_mismatch_raises(
        self, oauth_client, state_secret
    ):
        from unittest.mock import AsyncMock

        from fastapi import HTTPException

        authenticator = MagicMock()
        authenticator.current_user = MagicMock(return_value=lambda: None)
        router = get_oauth_associate_router(
            oauth_client=oauth_client,
            authenticator=authenticator,
            get_user_manager=MagicMock(),
            user_schema=MagicMock,
            state_secret=state_secret,
        )
        callback = self._endpoint(router, "oauth-associate:dummy.callback")

        from unittest.mock import patch

        # state_data["sub"] = "99" but user.id = 1 -> mismatch
        token = generate_state_token({"sub": "99"}, state_secret)

        with patch.object(
            oauth_client,
            "get_id_email",
            AsyncMock(return_value=("acc", "x@y.com")),
        ):
            request = MagicMock(state=SimpleNamespace())
            user = MagicMock(id=1)
            access_token_state = ({"access_token": "tok"}, token)
            mgr = MagicMock()
            with pytest.raises(HTTPException) as exc:
                await callback(request, user, access_token_state, mgr)
            assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_callback_success_returns_user_schema(
        self, oauth_client, state_secret
    ):
        from unittest.mock import AsyncMock

        authenticator = MagicMock()
        authenticator.current_user = MagicMock(return_value=lambda: None)
        user_schema = MagicMock()
        user_schema.model_validate = MagicMock(return_value="validated-user")
        router = get_oauth_associate_router(
            oauth_client=oauth_client,
            authenticator=authenticator,
            get_user_manager=MagicMock(),
            user_schema=user_schema,
            state_secret=state_secret,
        )
        callback = self._endpoint(router, "oauth-associate:dummy.callback")

        from unittest.mock import patch

        token = generate_state_token({"sub": "1"}, state_secret)

        with patch.object(
            oauth_client,
            "get_id_email",
            AsyncMock(return_value=("acc", "x@y.com")),
        ):
            request = MagicMock(state=SimpleNamespace())
            user = MagicMock(id=1)
            access_token_state = (
                {"access_token": "tok", "expires_at": 1, "refresh_token": "rt"},
                token,
            )
            mgr = MagicMock()
            mgr.oauth_associate_callback = AsyncMock(return_value="updated")
            result = await callback(request, user, access_token_state, mgr)
        assert result == "validated-user"

    @pytest.mark.asyncio
    async def test_callback_success_with_redirect_url_after_callback(
        self, oauth_client, state_secret
    ):
        from unittest.mock import AsyncMock

        authenticator = MagicMock()
        authenticator.current_user = MagicMock(return_value=lambda: None)
        router = get_oauth_associate_router(
            oauth_client=oauth_client,
            authenticator=authenticator,
            get_user_manager=MagicMock(),
            user_schema=MagicMock,
            state_secret=state_secret,
            redirect_url_after_callback="https://app.example.com/done",
        )
        callback = self._endpoint(router, "oauth-associate:dummy.callback")

        from unittest.mock import patch

        token = generate_state_token({"sub": "1"}, state_secret)

        with patch.object(
            oauth_client,
            "get_id_email",
            AsyncMock(return_value=("acc", "x@y.com")),
        ):
            request = MagicMock(state=SimpleNamespace())
            user = MagicMock(id=1)
            access_token_state = (
                {"access_token": "tok"},
                token,
            )
            mgr = MagicMock()
            mgr.oauth_associate_callback = AsyncMock(return_value="updated")
            result = await callback(request, user, access_token_state, mgr)
        assert result.status_code in (302, 307)


class TestGetOAuthRouterCallbackBody:
    """Direct calls to the get_oauth_router callback endpoint (lines 253-281)."""

    def _endpoint(self, router, name):
        return next(r.endpoint for r in router.routes if r.name == name)

    @pytest.mark.asyncio
    async def test_callback_user_already_exists_raises_400(
        self, oauth_client, backend, state_secret
    ):
        from unittest.mock import AsyncMock

        from fastapi import HTTPException
        from fastapi_users import exceptions

        router = get_oauth_router(
            oauth_client=oauth_client,
            backend=backend,
            get_user_manager=MagicMock(),
            state_secret=state_secret,
        )
        callback = self._endpoint(router, "oauth:dummy.jwt.callback")

        from unittest.mock import patch

        with patch.object(
            oauth_client,
            "get_id_email",
            AsyncMock(return_value=("acc", "x@y.com")),
        ):
            request = MagicMock(
                state=SimpleNamespace(state_data={"redirect": "x"})
            )
            access_token_state = ({"access_token": "tok"}, "state-x")
            mgr = MagicMock()
            mgr.oauth_callback = AsyncMock(side_effect=exceptions.UserAlreadyExists())
            strategy = MagicMock()
            with pytest.raises(HTTPException) as exc:
                await callback(request, access_token_state, mgr, strategy)
            assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_callback_inactive_user_raises_400(
        self, oauth_client, backend, state_secret
    ):
        from unittest.mock import AsyncMock

        from fastapi import HTTPException

        router = get_oauth_router(
            oauth_client=oauth_client,
            backend=backend,
            get_user_manager=MagicMock(),
            state_secret=state_secret,
        )
        callback = self._endpoint(router, "oauth:dummy.jwt.callback")

        from unittest.mock import patch

        inactive_user = MagicMock(is_active=False)
        with patch.object(
            oauth_client,
            "get_id_email",
            AsyncMock(return_value=("acc", "x@y.com")),
        ):
            request = MagicMock(
                state=SimpleNamespace(state_data={"redirect": "x"})
            )
            access_token_state = ({"access_token": "tok"}, "state-x")
            mgr = MagicMock()
            mgr.oauth_callback = AsyncMock(return_value=inactive_user)
            strategy = MagicMock()
            with pytest.raises(HTTPException) as exc:
                await callback(request, access_token_state, mgr, strategy)
            assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_callback_returns_response_default(
        self, oauth_client, backend, state_secret
    ):
        from unittest.mock import AsyncMock

        router = get_oauth_router(
            oauth_client=oauth_client,
            backend=backend,
            get_user_manager=MagicMock(),
            state_secret=state_secret,
        )
        callback = self._endpoint(router, "oauth:dummy.jwt.callback")

        from unittest.mock import patch

        active_user = MagicMock(is_active=True)
        with patch.object(
            oauth_client,
            "get_id_email",
            AsyncMock(return_value=("acc", "x@y.com")),
        ), patch.object(backend, "login", AsyncMock(return_value="response")):
            request = MagicMock(state=SimpleNamespace(state_data={}))
            access_token_state = ({"access_token": "tok"}, "state-x")
            mgr = MagicMock()
            mgr.oauth_callback = AsyncMock(return_value=active_user)
            mgr.on_after_login = AsyncMock()
            strategy = MagicMock()
            result = await callback(request, access_token_state, mgr, strategy)
        assert result == "response"


class TestGetAuthRouterEndpointBodies:
    """Unit tests that call the closure-built endpoints directly so coverage
    traces the inner function bodies (not just the factory's outer scope).

    pytest-cov sometimes fails to attribute lines inside async closures that
    only get invoked via FastAPI's request dispatcher (Depends resolution
    runs in an isolated trampoline). Calling the endpoint as a plain
    coroutine bypasses that and re-traces the lines.
    """

    def _endpoint(self, router, name):
        return next(r.endpoint for r in router.routes if r.name == name)

    def _build_router(self, backend, **kwargs):
        authenticator = MagicMock()
        authenticator.current_user_token = MagicMock(return_value=lambda: None)
        manager = MagicMock()
        return (
            get_auth_router(
                backend=backend,
                get_user_manager=lambda: manager,
                authenticator=authenticator,
                **kwargs,
            ),
            manager,
        )

    @pytest.mark.asyncio
    async def test_login_success_returns_response(self, backend):
        from fastapi.security import OAuth2PasswordRequestForm
        from unittest.mock import AsyncMock

        router, _ = self._build_router(backend)
        login = self._endpoint(router, "auth:jwt.login")

        active_user = MagicMock(is_active=True, is_verified=True)
        manager = MagicMock()
        manager.authenticate = AsyncMock(return_value=active_user)
        manager.on_after_login = AsyncMock()
        backend_mock = MagicMock()
        backend_mock.login = AsyncMock(return_value="response-obj")

        # Patch backend.login on the closure backend the route captured
        from unittest.mock import patch

        with patch.object(backend, "login", AsyncMock(return_value="response-obj")):
            request = MagicMock()
            credentials = OAuth2PasswordRequestForm(username="u", password="p")
            strategy = MagicMock()
            result = await login(request, credentials, manager, strategy)
        assert result == "response-obj"
        manager.authenticate.assert_called_once()

    @pytest.mark.asyncio
    async def test_login_inactive_user_raises_400(self, backend):
        from fastapi.security import OAuth2PasswordRequestForm
        from unittest.mock import AsyncMock

        from fastapi import HTTPException

        router, _ = self._build_router(backend)
        login = self._endpoint(router, "auth:jwt.login")

        manager = MagicMock()
        manager.authenticate = AsyncMock(return_value=None)
        request = MagicMock()
        credentials = OAuth2PasswordRequestForm(username="u", password="p")
        strategy = MagicMock()
        with pytest.raises(HTTPException) as exc:
            await login(request, credentials, manager, strategy)
        assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_login_with_ldap_auth_type_dispatches_authenticate_ldap(self, backend):
        from fastapi.security import OAuth2PasswordRequestForm
        from unittest.mock import AsyncMock

        from fastapi import HTTPException

        router, _ = self._build_router(backend, auth_type="ldap")
        login = self._endpoint(router, "auth:jwt.login")

        manager = MagicMock()
        manager.authenticate_ldap = AsyncMock(return_value=None)
        request = MagicMock()
        credentials = OAuth2PasswordRequestForm(username="u", password="p")
        strategy = MagicMock()
        with pytest.raises(HTTPException):
            await login(request, credentials, manager, strategy)
        manager.authenticate_ldap.assert_called_once()

    @pytest.mark.asyncio
    async def test_login_unverified_user_raises_400_when_required(self, backend):
        from fastapi.security import OAuth2PasswordRequestForm
        from unittest.mock import AsyncMock

        from fastapi import HTTPException

        router, _ = self._build_router(backend, requires_verification=True)
        login = self._endpoint(router, "auth:jwt.login")

        unverified = MagicMock(is_active=True, is_verified=False)
        manager = MagicMock()
        manager.authenticate = AsyncMock(return_value=unverified)
        request = MagicMock()
        credentials = OAuth2PasswordRequestForm(username="u", password="p")
        strategy = MagicMock()
        with pytest.raises(HTTPException) as exc:
            await login(request, credentials, manager, strategy)
        assert exc.value.status_code == 400

    @pytest.mark.asyncio
    async def test_login_with_json_dispatches_to_login(self, backend):
        from unittest.mock import AsyncMock

        from fastapi_rtk.routers import get_auth_router

        authenticator = MagicMock()
        authenticator.current_user_token = MagicMock(return_value=lambda: None)
        active_user = MagicMock(is_active=True, is_verified=True)
        manager = MagicMock()
        manager.authenticate = AsyncMock(return_value=active_user)
        manager.on_after_login = AsyncMock()

        router = get_auth_router(
            backend=backend,
            get_user_manager=lambda: manager,
            authenticator=authenticator,
        )
        login_with_json = self._endpoint(router, "auth:jwt.login-json")

        from unittest.mock import patch

        with patch.object(backend, "login", AsyncMock(return_value="ok")):
            from fastapi_rtk.routers import (  # noqa: F401  - LoginBody isn't exported
                get_auth_router as _,
            )

            class FakeBody:
                username = "u"
                password = "p"

            request = MagicMock()
            strategy = MagicMock()
            result = await login_with_json(request, FakeBody(), manager, strategy)
        assert result == "ok"

    @pytest.mark.asyncio
    async def test_logout_204_resets_g_user(self, backend):
        from unittest.mock import AsyncMock

        from fastapi import status

        from fastapi_rtk.globals import g

        authenticator = MagicMock()
        authenticator.current_user_token = MagicMock(return_value=lambda: None)
        manager = MagicMock()
        manager.on_after_logout = AsyncMock()

        router = get_auth_router(
            backend=backend,
            get_user_manager=lambda: manager,
            authenticator=authenticator,
        )
        logout = self._endpoint(router, "auth:jwt.logout")

        from unittest.mock import patch

        response_204 = MagicMock(status_code=status.HTTP_204_NO_CONTENT)
        with patch.object(backend, "logout", AsyncMock(return_value=response_204)):
            request = MagicMock()
            strategy = MagicMock()
            user_token = (MagicMock(), "tok")
            g.user = MagicMock()
            await logout(request, user_token, manager, strategy)
        assert g.user is None

    @pytest.mark.asyncio
    async def test_logout_non_204_keeps_g_user(self, backend):
        from unittest.mock import AsyncMock

        from fastapi_rtk.globals import g

        authenticator = MagicMock()
        authenticator.current_user_token = MagicMock(return_value=lambda: None)
        manager = MagicMock()
        manager.on_after_logout = AsyncMock()

        router = get_auth_router(
            backend=backend,
            get_user_manager=lambda: manager,
            authenticator=authenticator,
        )
        logout = self._endpoint(router, "auth:jwt.logout")

        from unittest.mock import patch

        response_200 = MagicMock(status_code=200)
        with patch.object(backend, "logout", AsyncMock(return_value=response_200)):
            request = MagicMock()
            strategy = MagicMock()
            user_token = (MagicMock(), "tok")
            sentinel = object()
            g.user = sentinel
            await logout(request, user_token, manager, strategy)
        assert g.user is sentinel


class TestOAuthAssociateRouterRegistration:
    """Lines 271, 277, 420-421: associate router authorize + callback routes
    are registered with the right names."""

    @pytest.mark.asyncio
    async def test_associate_router_registers_authorize_and_callback(self):
        from unittest.mock import AsyncMock

        from fastapi_users import schemas as fu_schemas

        from fastapi_rtk import routers as rt_mod

        oauth_client = MagicMock()
        oauth_client.name = "stub"
        oauth_client.get_id_email = AsyncMock(
            side_effect=lambda token: ("abc", "x@y.com")
        )

        authenticator = MagicMock()
        authenticator.current_user = lambda **kw: lambda: MagicMock(
            id=1, is_active=True
        )

        get_user_manager = lambda: MagicMock()  # noqa: E731
        user_schema = fu_schemas.BaseUser
        secret = "tier-secret-32-bytes!!"

        rt = rt_mod.get_oauth_associate_router(
            oauth_client=oauth_client,
            authenticator=authenticator,
            get_user_manager=get_user_manager,
            user_schema=user_schema,
            state_secret=secret,
        )
        names = [r.name for r in rt.routes]
        assert any("authorize" in n for n in names)
        assert any("callback" in n for n in names)
