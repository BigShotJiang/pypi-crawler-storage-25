import pytest
from fastapi_users.authentication.strategy.db import DatabaseStrategy

from fastapi_rtk.auth.strategies.db import (
    AccessToken,
    SQLAlchemyAccessTokenDatabase,
    get_database_strategy_generator,
)
from fastapi_rtk.const import ACCESSTOKEN_TABLE


class TestAccessTokenModel:
    def test_tablename(self):
        assert AccessToken.__tablename__ == ACCESSTOKEN_TABLE

    def test_user_id_column_present(self):
        assert "user_id" in AccessToken.__table__.columns


class TestGetDatabaseStrategyGenerator:
    def test_returns_callable(self):
        gen = get_database_strategy_generator({})
        assert callable(gen)

    def test_with_lifetime(self):
        gen = get_database_strategy_generator({"lifetime_seconds": 3600})
        assert callable(gen)

    def test_invalid_lifetime_raises(self):
        with pytest.raises(Exception):
            get_database_strategy_generator({"lifetime_seconds": "not-int"})


class TestSQLAlchemyAccessTokenDatabaseInit:
    def test_stores_session_and_table(self):
        sentinel_session = object()
        db = SQLAlchemyAccessTokenDatabase(sentinel_session, AccessToken)
        assert db.session is sentinel_session
        assert db.access_token_table is AccessToken


class _FakeResult:
    def __init__(self, ret):
        self._ret = ret

    def scalar_one_or_none(self):
        return self._ret


class _FakeSession:
    """Stub session covering execute / add / commit / refresh / delete."""

    def __init__(self, scalar_value=None):
        self.scalar_value = scalar_value
        self.added = []
        self.deleted = []
        self.commits = 0
        self.refreshes = 0

    async def execute(self, stmt):
        self.last_statement = stmt
        return _FakeResult(self.scalar_value)

    def add(self, instance=None, **_):
        self.added.append(instance)

    async def commit(self):
        self.commits += 1

    async def refresh(self, instance):
        self.refreshes += 1

    async def delete(self, instance):
        self.deleted.append(instance)


@pytest.mark.asyncio
class TestSQLAlchemyAccessTokenDatabaseOps:
    async def test_get_by_token_no_max_age(self):
        sentinel = object()
        sess = _FakeSession(scalar_value=sentinel)
        db = SQLAlchemyAccessTokenDatabase(sess, AccessToken)
        result = await db.get_by_token("tok")
        assert result is sentinel

    async def test_get_by_token_with_max_age(self):
        from datetime import datetime, timezone

        sess = _FakeSession(scalar_value=None)
        db = SQLAlchemyAccessTokenDatabase(sess, AccessToken)
        result = await db.get_by_token("tok", max_age=datetime.now(timezone.utc))
        assert result is None

    async def test_create_adds_commits_refreshes(self):
        sess = _FakeSession()
        db = SQLAlchemyAccessTokenDatabase(sess, AccessToken)
        token = await db.create({"token": "abc", "user_id": 1})
        assert sess.added == [token]
        assert sess.commits == 1
        assert sess.refreshes == 1

    async def test_update_sets_attrs_and_commits(self):
        sess = _FakeSession()
        db = SQLAlchemyAccessTokenDatabase(sess, AccessToken)
        token = AccessToken(token="orig", user_id=1)
        result = await db.update(token, {"token": "new"})
        assert result.token == "new"
        assert sess.commits == 1

    async def test_delete_calls_session_delete_and_commit(self):
        sess = _FakeSession()
        db = SQLAlchemyAccessTokenDatabase(sess, AccessToken)
        token = AccessToken(token="x", user_id=1)
        await db.delete(token)
        assert sess.deleted == [token]
        assert sess.commits == 1


@pytest.mark.asyncio
class TestGetAccessTokenDb:
    async def test_yields_database_adapter(self):
        from fastapi_rtk.auth.strategies.db import get_access_token_db

        sess = _FakeSession()
        gen = get_access_token_db(session=sess)
        adapter = await gen.__anext__()
        assert isinstance(adapter, SQLAlchemyAccessTokenDatabase)
        assert adapter.session is sess
        assert adapter.access_token_table is AccessToken


class TestGetDatabaseStrategyInner:
    def test_inner_function_returns_db_strategy(self):
        gen = get_database_strategy_generator({"lifetime_seconds": 60})
        # The inner dep receives an access_token_db; pass a stub.
        sess = _FakeSession()
        adapter = SQLAlchemyAccessTokenDatabase(sess, AccessToken)
        strategy = gen(access_token_db=adapter)
        assert isinstance(strategy, DatabaseStrategy)
