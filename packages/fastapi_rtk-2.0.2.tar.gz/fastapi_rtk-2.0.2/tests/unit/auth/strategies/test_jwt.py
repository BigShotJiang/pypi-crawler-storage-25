import pytest
from fastapi_users.authentication import JWTStrategy

from fastapi_rtk.auth.strategies.jwt import get_jwt_strategy_generator


class TestGetJwtStrategyGenerator:
    def test_returns_callable(self):
        get_strategy = get_jwt_strategy_generator({"secret": "abc"})
        assert callable(get_strategy)

    def test_generator_returns_jwt_strategy(self):
        get_strategy = get_jwt_strategy_generator(
            {"secret": "abc", "lifetime_seconds": 3600}
        )
        s = get_strategy()
        assert isinstance(s, JWTStrategy)

    def test_secret_passed_through(self):
        get_strategy = get_jwt_strategy_generator(
            {"secret": "supersecret", "lifetime_seconds": 3600}
        )
        s = get_strategy()
        assert s.secret == "supersecret"

    def test_lifetime_seconds_passed_through(self):
        get_strategy = get_jwt_strategy_generator(
            {"secret": "abc", "lifetime_seconds": 1234}
        )
        s = get_strategy()
        assert s.lifetime_seconds == 1234

    def test_token_audience_passed_through(self):
        get_strategy = get_jwt_strategy_generator(
            {"secret": "abc", "lifetime_seconds": 3600, "token_audience": ["a", "b"]}
        )
        s = get_strategy()
        assert s.token_audience == ["a", "b"]

    def test_algorithm_passed_through(self):
        get_strategy = get_jwt_strategy_generator(
            {"secret": "abc", "lifetime_seconds": 3600, "algorithm": "HS512"}
        )
        s = get_strategy()
        assert s.algorithm == "HS512"

    def test_missing_secret_raises(self):
        with pytest.raises(Exception):
            get_jwt_strategy_generator({})

    def test_invalid_lifetime_seconds_raises(self):
        with pytest.raises(Exception):
            get_jwt_strategy_generator(
                {"secret": "abc", "lifetime_seconds": "not-int"}
            )
