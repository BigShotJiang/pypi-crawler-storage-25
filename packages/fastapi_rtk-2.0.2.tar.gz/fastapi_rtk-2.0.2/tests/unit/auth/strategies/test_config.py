import typing

from fastapi_users.authentication import JWTStrategy
from fastapi_users.authentication.strategy.db import DatabaseStrategy

from fastapi_rtk.auth.strategies.config import (
    DatabaseStrategyConfig,
    JWTStrategyConfig,
    Strategy,
    StrategyConfig,
)


class TestJWTStrategyConfig:
    def test_required_secret_field(self):
        cfg: JWTStrategyConfig = {"secret": "abc"}
        assert cfg["secret"] == "abc"

    def test_optional_fields(self):
        cfg: JWTStrategyConfig = {
            "secret": "abc",
            "lifetime_seconds": 3600,
            "token_audience": ["aud1"],
            "algorithm": "HS256",
            "public_key": "pk",
        }
        assert cfg["lifetime_seconds"] == 3600


class TestDatabaseStrategyConfig:
    def test_lifetime_optional(self):
        cfg: DatabaseStrategyConfig = {}
        assert cfg == {}

    def test_with_lifetime(self):
        cfg: DatabaseStrategyConfig = {"lifetime_seconds": 7200}
        assert cfg["lifetime_seconds"] == 7200


class TestUnionAliases:
    def test_strategy_config_union(self):
        args = typing.get_args(StrategyConfig)
        assert DatabaseStrategyConfig in args
        assert JWTStrategyConfig in args

    def test_strategy_union(self):
        args = typing.get_args(Strategy)
        assert JWTStrategy in args
        assert DatabaseStrategy in args
