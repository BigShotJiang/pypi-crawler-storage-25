from fastapi_rtk.auth.hashers.scrypt import ScryptHasher


class TestIdentify:
    def test_identifies_scrypt_hash(self):
        h = ScryptHasher().hash("password")
        assert ScryptHasher.identify(h) is True

    def test_rejects_pbkdf2_hash(self):
        assert ScryptHasher.identify("pbkdf2:sha256:600000$x") is False

    def test_accepts_bytes(self):
        assert ScryptHasher.identify(b"scrypt:32768:8:1$xyz") is True


class TestHashAndVerify:
    def test_roundtrip(self):
        h = ScryptHasher()
        hashed = h.hash("secret")
        assert h.verify("secret", hashed) is True

    def test_wrong_password_returns_false(self):
        h = ScryptHasher()
        hashed = h.hash("secret")
        assert h.verify("wrong", hashed) is False

    def test_invalid_hash_returns_false(self):
        h = ScryptHasher()
        assert h.verify("anything", "garbage") is False

    def test_none_hash_returns_false_via_exception(self):
        h = ScryptHasher()
        assert h.verify("anything", None) is False

    def test_hash_starts_with_scrypt(self):
        h = ScryptHasher()
        assert h.hash("x").startswith("scrypt")

    def test_check_needs_rehash_always_false(self):
        h = ScryptHasher()
        assert h.check_needs_rehash(h.hash("x")) is False
