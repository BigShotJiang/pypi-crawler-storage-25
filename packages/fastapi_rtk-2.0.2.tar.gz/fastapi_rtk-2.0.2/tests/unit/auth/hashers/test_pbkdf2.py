from fastapi_rtk.auth.hashers.pbkdf2 import PBKDF2Hasher


class TestIdentify:
    def test_identifies_pbkdf2_hash(self):
        h = PBKDF2Hasher().hash("password")
        assert PBKDF2Hasher.identify(h) is True

    def test_rejects_other_format(self):
        assert PBKDF2Hasher.identify("scrypt:32768:8:1$xyz") is False

    def test_accepts_bytes(self):
        assert PBKDF2Hasher.identify(b"pbkdf2:sha256:600000$x") is True


class TestHashAndVerify:
    def test_roundtrip(self):
        h = PBKDF2Hasher()
        hashed = h.hash("secret")
        assert h.verify("secret", hashed) is True

    def test_wrong_password_returns_false(self):
        h = PBKDF2Hasher()
        hashed = h.hash("secret")
        assert h.verify("wrong", hashed) is False

    def test_invalid_hash_returns_false(self):
        h = PBKDF2Hasher()
        assert h.verify("anything", "not-a-valid-hash-at-all") is False

    def test_none_hash_returns_false_via_exception(self):
        """Triggers AttributeError inside check_password_hash -> caught by except branch."""
        h = PBKDF2Hasher()
        assert h.verify("anything", None) is False

    def test_hash_starts_with_pbkdf2(self):
        h = PBKDF2Hasher()
        assert h.hash("x").startswith("pbkdf2")

    def test_check_needs_rehash_always_false(self):
        h = PBKDF2Hasher()
        assert h.check_needs_rehash(h.hash("x")) is False
