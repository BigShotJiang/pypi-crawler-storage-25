from fastapi_users.password import PasswordHelper

from fastapi_rtk.auth.password_helpers.fab import FABPasswordHelper


class TestFABPasswordHelper:
    def test_inherits_password_helper(self):
        assert issubclass(FABPasswordHelper, PasswordHelper)

    def test_default_password_hash_uses_both_hashers(self):
        h = FABPasswordHelper()
        # password_hash internal hashers list should have 2 entries
        hashers = h.password_hash.hashers
        assert len(hashers) == 2

    def test_first_hash_starts_with_scrypt(self):
        """Default hasher (first in pwdlib chain) is ScryptHasher."""
        h = FABPasswordHelper()
        hashed = h.password_hash.hash("pw")
        assert hashed.startswith("scrypt")

    def test_verify_pbkdf2_legacy_password(self):
        """FABPasswordHelper still verifies legacy pbkdf2 hashes."""
        from fastapi_rtk.auth.hashers.pbkdf2 import PBKDF2Hasher

        h = FABPasswordHelper()
        legacy_hash = PBKDF2Hasher().hash("legacy-pw")
        ok, _ = h.password_hash.verify_and_update("legacy-pw", legacy_hash)
        assert ok is True

    def test_verify_scrypt_password(self):
        h = FABPasswordHelper()
        hashed = h.password_hash.hash("modern-pw")
        ok, _ = h.password_hash.verify_and_update("modern-pw", hashed)
        assert ok is True
