import logging

import pytest
from fastapi_users.authentication import (
    AuthenticationBackend,
    BearerTransport,
    CookieTransport,
)

from fastapi_rtk.auth.auth import (
    Auth,
    AuthConfigurator,
    Authenticator,
    BearerConfig,
    CookieConfig,
)
from fastapi_rtk.const import (
    DEFAULT_COOKIE_NAME,
    DEFAULT_SECRET,
    DEFAULT_TOKEN_URL,
)


class TestTypedDicts:
    def test_cookie_config_minimal(self):
        cfg: CookieConfig = {"cookie_name": "x"}
        assert cfg["cookie_name"] == "x"

    def test_bearer_config_minimal(self):
        cfg: BearerConfig = {"tokenUrl": "/token"}
        assert cfg["tokenUrl"] == "/token"

    def test_auth_typed_dict_keys_optional(self):
        a: Auth = {}
        assert a == {}


class TestAuthConfiguratorDefaults:
    def test_secret_key_default_warns(self, caplog):
        ac = AuthConfigurator()
        with caplog.at_level(logging.WARNING, logger="DT_FASTAPI"):
            secret = ac.secret_key
        assert secret == DEFAULT_SECRET
        assert any("default secret key" in r.message for r in caplog.records)

    def test_secret_key_warns_only_once(self, caplog):
        ac = AuthConfigurator()
        with caplog.at_level(logging.WARNING, logger="DT_FASTAPI"):
            ac.secret_key
            count_first = sum(1 for r in caplog.records if "default secret" in r.message)
            ac.secret_key
            count_second = sum(
                1 for r in caplog.records if "default secret" in r.message
            )
        # Same warning count after second access
        assert count_first == count_second

    def test_secret_key_setter(self):
        ac = AuthConfigurator()
        ac.secret_key = "mysecret"
        assert ac.secret_key == "mysecret"

    def test_user_manager_default(self):
        from fastapi_rtk.manager import UserManager

        ac = AuthConfigurator()
        assert ac.user_manager is UserManager

    def test_user_manager_setter(self):
        ac = AuthConfigurator()

        class CustomUM:
            pass

        ac.user_manager = CustomUM
        assert ac.user_manager is CustomUM


class TestCookieAndBearerConfigDefaults:
    def test_cookie_config_default_set_lazily(self):
        from fastapi_rtk.auth.auth import AuthConfigurator

        ac = AuthConfigurator()
        # Defaults populate from g.config; we just check it returns a CookieConfig dict
        cfg = ac.cookie_config
        assert "cookie_name" in cfg

    def test_bearer_config_default_set_lazily(self):
        ac = AuthConfigurator()
        cfg = ac.bearer_config
        assert "tokenUrl" in cfg


class TestTransports:
    def test_cookie_transport_default_uses_cookie_config(self):
        ac = AuthConfigurator()
        t = ac.cookie_transport
        assert isinstance(t, CookieTransport)

    def test_bearer_transport_default(self):
        ac = AuthConfigurator()
        t = ac.bearer_transport
        assert isinstance(t, BearerTransport)

    def test_cookie_transport_setter_clears_backend(self):
        ac = AuthConfigurator()
        # Force backend to populate
        _ = ac.cookie_backend
        assert ac._cookie_backend is not None
        ac.cookie_transport = CookieTransport(cookie_name="x")
        # Setter clears backend
        assert ac._cookie_backend is None

    def test_bearer_transport_setter_clears_backend(self):
        ac = AuthConfigurator()
        _ = ac.bearer_backend
        assert ac._bearer_backend is not None
        ac.bearer_transport = BearerTransport(tokenUrl="/x")
        assert ac._bearer_backend is None


class TestBackends:
    def test_cookie_backend_default(self):
        ac = AuthConfigurator()
        b = ac.cookie_backend
        assert isinstance(b, AuthenticationBackend)
        assert b.name == "cookie"

    def test_bearer_backend_default(self):
        ac = AuthConfigurator()
        b = ac.bearer_backend
        assert isinstance(b, AuthenticationBackend)
        assert b.name == "jwt"

    def test_cookie_backend_setter_clears_authenticator(self):
        ac = AuthConfigurator()
        _ = ac.authenticator
        assert ac._authenticator is not None
        ac.cookie_backend = ac.cookie_backend
        assert ac._authenticator is None


class TestAuthenticator:
    def test_inherits_base(self):
        from fastapi_users.authentication import Authenticator as BaseAuthenticator

        assert issubclass(Authenticator, BaseAuthenticator)


class TestSetterUpdatesDefaultClasses:
    def test_bearer_backend_setter_records_class(self):
        ac = AuthConfigurator()
        # Force first construction so the default classes are populated
        original = ac.bearer_backend
        ac.bearer_backend = original  # setter records type(value) at line 437
        # Setting to None re-uses the recorded class on next access
        ac.bearer_backend = None
        assert isinstance(ac.bearer_backend, AuthenticationBackend)

    def test_authenticator_setter_records_class(self):
        ac = AuthConfigurator()
        original = ac.authenticator
        ac.authenticator = original  # line 470
        ac.authenticator = None
        assert isinstance(ac.authenticator, Authenticator)

    def test_fastapi_users_setter_records_class(self):
        ac = AuthConfigurator()
        original = ac.fastapi_users
        ac.fastapi_users = original  # line 505
        ac.fastapi_users = None
        # Re-resolves to a fresh instance via the recorded class
        assert ac.fastapi_users is not None


class TestStrategyBackendSetter:
    def test_set_jwt_string(self):
        from fastapi_rtk.auth.auth import get_jwt_strategy_generator

        ac = AuthConfigurator()
        ac.strategy_backend = "JWT"
        assert ac.strategy_backend is get_jwt_strategy_generator

    def test_set_db_string(self):
        from fastapi_rtk.auth.strategies.db import (
            get_database_strategy_generator,
        )

        ac = AuthConfigurator()
        ac.strategy_backend = "DB"
        assert ac.strategy_backend is get_database_strategy_generator

    def test_set_custom_callable(self):
        ac = AuthConfigurator()

        def custom(_):
            def get():
                return None

            return get

        ac.strategy_backend = custom
        assert ac.strategy_backend is custom


class TestConfigSettersClearDependents:
    def test_cookie_config_setter_clears_transport(self):
        ac = AuthConfigurator()
        _ = ac.cookie_transport
        assert ac._cookie_transport is not None
        ac.cookie_config = {"cookie_name": "v2"}
        # Setter clears cookie_transport (line 611)
        assert ac._cookie_transport is None

    def test_bearer_config_setter_clears_transport(self):
        ac = AuthConfigurator()
        _ = ac.bearer_transport
        assert ac._bearer_transport is not None
        ac.bearer_config = {"tokenUrl": "/v2"}
        # Line 629
        assert ac._bearer_transport is None

    def test_cookie_strategy_config_setter_clears_backend(self):
        ac = AuthConfigurator()
        _ = ac.cookie_backend
        assert ac._cookie_backend is not None
        ac.cookie_strategy_config = {"lifetime_seconds": 60}
        # Line 647
        assert ac._cookie_backend is None

    def test_bearer_strategy_config_setter_clears_backend(self):
        ac = AuthConfigurator()
        _ = ac.bearer_backend
        assert ac._bearer_backend is not None
        ac.bearer_strategy_config = {"lifetime_seconds": 60}
        # Line 665
        assert ac._bearer_backend is None


class TestAuthenticatorBackends:
    def test_get_enabled_backends_returns_callable(self):
        ac = AuthConfigurator()
        # Accessing authenticator builds via the recorded class
        auth = ac.authenticator
        dep = auth.get_enabled_backends()
        assert callable(dep)


class TestAuthConfiguratorMisc:
    def test_auth_config_uppercase_mapping(self):
        # Line 587 - covers the auth_config helper.
        ac = AuthConfigurator()
        keys = ac.auth_config()
        for k in keys:
            assert k == k.upper()


class TestAuthenticatorEnabledBackendsBody:
    """Lines 150, 181 in auth.py: enabled_backends_dependency body returns
    (args, kwargs); authenticate() falls back to ()/{} when strategy_params
    is None."""

    def _build_authenticator(self):
        from unittest.mock import MagicMock

        from fastapi_users.authentication import (
            AuthenticationBackend,
            BearerTransport,
            JWTStrategy,
        )

        from fastapi_rtk.auth import Authenticator

        bearer_transport = BearerTransport(tokenUrl="auth/jwt/login")

        def get_jwt_strategy():
            return JWTStrategy(secret="tier-secret-32-bytes!!", lifetime_seconds=60)

        backend = AuthenticationBackend(
            name="jwt",
            transport=bearer_transport,
            get_strategy=get_jwt_strategy,
        )

        async def fake_get_user_manager():
            yield MagicMock()

        return Authenticator([backend], fake_get_user_manager)

    @pytest.mark.asyncio
    async def test_enabled_backends_dependency_body(self):
        # Line 150: `return args, kwargs`
        auth = self._build_authenticator()
        dep = auth.get_enabled_backends()
        result = await dep()
        assert isinstance(result, tuple) and len(result) == 2

    @pytest.mark.asyncio
    async def test_authenticate_with_strategy_params_none(self):
        from unittest.mock import MagicMock

        # Line 181: `*strategy_params[0] if strategy_params else ()` fallback
        auth = self._build_authenticator()

        async def fake_internal(*args, **kwargs):
            return ("user_stub", "token_stub")

        auth._authenticate = fake_internal
        result = await auth.authenticate(MagicMock(), strategy_params=None)
        assert result == ("user_stub", "token_stub")
