"""Tier 15 - tests for fastapi_rtk.fastapi_react_toolkit.FastAPIReactToolkit.

Covers __init__ config storage, add_api semantics (add, replace, post-mount
raise), total_permissions aggregation, connect_to_database missing-URI guard,
init_database missing-engine guard, _init_basic_apis exclusion, _init_config
metadata wiring, and a smoke end-to-end assembly with sqlite-in-memory.

Full HTTP integration (login -> /list -> /post -> RBAC) needs httpx async
client + working auth backend; remains follow-up work.
"""

from contextlib import asynccontextmanager
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest
from fastapi import FastAPI
from fastapi_rtk.fastapi_react_toolkit import FastAPIReactToolkit


@pytest.fixture(autouse=True)
def reset_g_user_session():
    """Each test gets a clean app instance with no leaked toolkit attrs."""
    yield


class TestInit:
    def test_init_stores_config_flags(self):
        toolkit = FastAPIReactToolkit(
            create_tables=True,
            upgrade_db=True,
            cleanup=True,
            init_db=False,
            global_user_dependency=False,
            global_background_tasks=False,
            global_request=False,
        )
        assert toolkit.create_tables is True
        assert toolkit.upgrade_db is True
        assert toolkit.cleanup is True
        assert toolkit.init_db is False
        assert toolkit.global_user_dependency is False
        assert toolkit.global_background_tasks is False
        assert toolkit.global_request is False

    def test_init_stores_lifespans(self):
        @asynccontextmanager
        async def lifespan(app):
            yield

        toolkit = FastAPIReactToolkit(lifespans=[lifespan])
        assert toolkit.lifespans == [lifespan]

    def test_init_normalizes_single_lifespan_to_list(self):
        @asynccontextmanager
        async def lifespan(app):
            yield

        toolkit = FastAPIReactToolkit(lifespans=lifespan)
        assert toolkit.lifespans == [lifespan]

    def test_init_no_lifespan_empty_list(self):
        toolkit = FastAPIReactToolkit()
        assert toolkit.lifespans == []

    def test_init_exclude_apis(self):
        toolkit = FastAPIReactToolkit(exclude_apis=["LicenseApi"])
        assert toolkit.exclude_apis == ["LicenseApi"]

    def test_init_sets_g_current_app(self):
        toolkit = FastAPIReactToolkit()
        from fastapi_rtk.globals import g

        # g.current_app set on toolkit construction
        assert g.current_app is toolkit

    def test_init_with_auth_dict_dispatches_to_g_auth(self, global_setter):
        from fastapi_rtk.auth.auth import AuthConfigurator
        from fastapi_rtk.globals import g

        ac = AuthConfigurator()
        global_setter("auth", ac)

        FastAPIReactToolkit(auth={"secret_key": "abcd-from-auth-dict"})
        assert ac.secret_key == "abcd-from-auth-dict"

    def test_init_with_instrumentator_keeps_override(self):
        sentinel = MagicMock()
        toolkit = FastAPIReactToolkit(instrumentator=sentinel)
        assert toolkit.instrumentator is sentinel

    def test_init_with_app_calls_initialize(self, config_setter):
        config_setter("SECWEB_ENABLED", False)
        config_setter("PROFILER_ENABLED", False)
        app = FastAPI()
        toolkit = FastAPIReactToolkit(app=app)
        # initialize() ran -> initialized flag flipped
        assert toolkit.initialized is True

    def test_initialize_idempotent(self):
        app = FastAPI()
        toolkit = FastAPIReactToolkit()
        toolkit.initialize(app)
        toolkit.initialize(app)  # second call short-circuits at line 286
        assert toolkit.initialized is True

    def test_init_with_debug_lowers_log_level(self):
        import logging

        from fastapi_rtk.const import logger as rtk_logger

        previous_level = rtk_logger.level
        try:
            FastAPIReactToolkit(debug=True)
            assert rtk_logger.level == logging.DEBUG
        finally:
            rtk_logger.setLevel(previous_level)


class TestInitializeWithFeatures:
    def test_secweb_enabled_adds_middlewares(self, config_setter):
        config_setter("SECWEB_ENABLED", True)
        config_setter("SECWEB_PATCH_DOCS", True)
        config_setter("SECWEB_PATCH_REDOC", True)
        config_setter("PROFILER_ENABLED", False)

        app = FastAPI()
        toolkit = FastAPIReactToolkit()
        toolkit.initialize(app)
        # SecWeb attaches its own middlewares; the patch docs/redoc ones
        # should be in the user middleware stack
        names = [m.cls.__name__ for m in app.user_middleware]
        assert "SecWebPatchDocsMiddleware" in names
        assert "SecWebPatchReDocMiddleware" in names

    def test_profiler_enabled_adds_middleware(self, config_setter, tmp_path, monkeypatch):
        import sys
        from unittest.mock import MagicMock

        config_setter("PROFILER_ENABLED", True)
        config_setter("PROFILER_FOLDER", str(tmp_path / "prof"))
        config_setter("SECWEB_ENABLED", False)

        # Inject a fake pyinstrument module so the import path succeeds
        fake = MagicMock()
        monkeypatch.setitem(sys.modules, "pyinstrument", fake)

        app = FastAPI()
        toolkit = FastAPIReactToolkit()
        toolkit.initialize(app)
        names = [m.cls.__name__ for m in app.user_middleware]
        assert "ProfilerMiddleware" in names

    def test_profiler_enabled_missing_pyinstrument_raises(
        self, config_setter, monkeypatch
    ):
        import builtins

        config_setter("PROFILER_ENABLED", True)
        config_setter("SECWEB_ENABLED", False)

        real_import = builtins.__import__

        def fake_import(name, *args, **kwargs):
            if name == "pyinstrument":
                raise ImportError("forced")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", fake_import)

        app = FastAPI()
        toolkit = FastAPIReactToolkit()
        import pytest

        with pytest.raises(ImportError, match="pyinstrument"):
            toolkit.initialize(app)


class TestMountFolders:
    def test_mount_static_folder_creates_dir(self, tmp_path, config_setter):
        config_setter("STATIC_FOLDER", str(tmp_path / "static_x"))
        toolkit = FastAPIReactToolkit()
        toolkit.app = FastAPI()
        toolkit._mount_static_folder()
        assert (tmp_path / "static_x").exists()

    def test_mount_template_folder_creates_dir(self, tmp_path, config_setter):
        config_setter("TEMPLATE_FOLDER", str(tmp_path / "templates_x"))
        toolkit = FastAPIReactToolkit()
        toolkit.app = FastAPI()
        toolkit._mount_template_folder()
        assert (tmp_path / "templates_x").exists()


class TestJsManifest:
    def test_init_js_manifest_registers_route(self, tmp_path, config_setter):
        config_setter("FAB_REACT_CONFIG", {"foo": "bar"})
        config_setter("TRANSLATIONS", {"en": {"hi": "hello"}})

        toolkit = FastAPIReactToolkit()
        toolkit.app = FastAPI()
        toolkit._init_js_manifest()
        # Server-config route registered
        paths = [r.path for r in toolkit.app.routes if hasattr(r, "path")]
        assert "/server-config.js" in paths

    def test_js_manifest_renders_react_vars(self, config_setter):
        import httpx

        config_setter("FAB_REACT_CONFIG", {"foo": "bar"})
        config_setter("TRANSLATIONS", {"en": {"hi": "hello"}})
        config_setter("TRANSLATIONS_KEY", "translations")

        toolkit = FastAPIReactToolkit()
        toolkit.app = FastAPI()
        toolkit._init_js_manifest()

        from starlette.testclient import TestClient

        with TestClient(toolkit.app) as tc:
            r = tc.get("/server-config.js")
            assert r.status_code == 200
            assert "fab_react_config" in r.text
            assert "foo" in r.text


class TestTemplateFolderRoute:
    def test_template_folder_index_returns_404_when_missing(
        self, tmp_path, config_setter
    ):
        from starlette.testclient import TestClient

        config_setter("TEMPLATE_FOLDER", str(tmp_path / "tmpl_x"))
        toolkit = FastAPIReactToolkit()
        toolkit.app = FastAPI()
        toolkit._mount_template_folder()
        with TestClient(toolkit.app) as tc:
            r = tc.get("/anything")
            # Without index.html we hit the TemplateNotFound -> 404
            assert r.status_code == 404

    def test_template_folder_index_renders_when_present(
        self, tmp_path, config_setter
    ):
        from starlette.testclient import TestClient

        tmpl_dir = tmp_path / "tmpl"
        tmpl_dir.mkdir()
        (tmpl_dir / "index.html").write_text(
            "<html>{{ app_name }}</html>"
        )
        config_setter("TEMPLATE_FOLDER", str(tmpl_dir))
        config_setter("APP_NAME", "MyApp")

        toolkit = FastAPIReactToolkit()
        toolkit.app = FastAPI()
        toolkit._mount_template_folder()
        with TestClient(toolkit.app) as tc:
            r = tc.get("/something")
            assert r.status_code == 200
            assert "MyApp" in r.text


class TestAddApi:
    def test_add_class_instantiates(self):
        toolkit = FastAPIReactToolkit()
        # InfoApi can be added without datamodel
        from fastapi_rtk.apis.info import InfoApi

        toolkit.add_api(InfoApi)
        assert any(isinstance(a, InfoApi) for a in toolkit.apis)

    def test_replaces_existing_with_same_resource_name(self):
        toolkit = FastAPIReactToolkit()
        from fastapi_rtk.apis.info import InfoApi

        toolkit.add_api(InfoApi)
        first_count = len(toolkit.apis)
        toolkit.add_api(InfoApi)
        # Same resource_name -> replaces, total count unchanged
        assert len(toolkit.apis) == first_count

    def test_post_mount_raises(self):
        toolkit = FastAPIReactToolkit()
        toolkit._mounted = True
        from fastapi_rtk.apis.info import InfoApi

        with pytest.raises(ValueError, match="API Mounted after"):
            toolkit.add_api(InfoApi)

    def test_sets_toolkit_on_api(self):
        toolkit = FastAPIReactToolkit()
        from fastapi_rtk.apis.info import InfoApi

        toolkit.add_api(InfoApi)
        assert toolkit.apis[-1].toolkit is toolkit


class TestTotalPermissions:
    def test_aggregates_unique_permissions(self):
        toolkit = FastAPIReactToolkit()
        api1 = SimpleNamespace(permissions=["can_get", "can_post"])
        api2 = SimpleNamespace(permissions=["can_post", "can_delete"])
        toolkit.apis = [api1, api2]
        result = toolkit.total_permissions()
        assert sorted(result) == ["can_delete", "can_get", "can_post"]

    def test_handles_apis_without_permissions(self):
        toolkit = FastAPIReactToolkit()
        api1 = SimpleNamespace(permissions=["x"])
        api2 = SimpleNamespace()  # no `permissions` attr
        toolkit.apis = [api1, api2]
        result = toolkit.total_permissions()
        assert result == ["x"]


class TestConnectToDatabase:
    def test_no_uri_logs_warning_and_returns(self, config_setter, caplog):
        config_setter("SQLALCHEMY_DATABASE_URI", "")
        toolkit = FastAPIReactToolkit()
        with caplog.at_level("WARNING", logger="DT_FASTAPI"):
            toolkit.connect_to_database()
        assert any(
            "SQLALCHEMY_DATABASE_URI is not set" in r.message for r in caplog.records
        )

    def test_with_uri_initializes(self, config_setter):
        config_setter("SQLALCHEMY_DATABASE_URI", "sqlite+aiosqlite:///:memory:")
        toolkit = FastAPIReactToolkit()
        with patch("fastapi_rtk.fastapi_react_toolkit.db") as mock_db:
            mock_db._engine_binds = {}
            mock_db._engine = MagicMock(url="sqlite+aiosqlite:///:memory:")
            toolkit.connect_to_database()
            mock_db.init_db.assert_called_once()


class TestInitDatabase:
    @pytest.mark.asyncio
    async def test_no_engine_logs_and_returns(self, caplog):
        toolkit = FastAPIReactToolkit()
        with patch("fastapi_rtk.fastapi_react_toolkit.db") as mock_db:
            mock_db._engine = None
            with caplog.at_level("WARNING", logger="DT_FASTAPI"):
                await toolkit.init_database()
            assert any("Database not connected" in r.message for r in caplog.records)


class TestInitBasicApis:
    def test_excludes_named_apis(self):
        toolkit = FastAPIReactToolkit(exclude_apis=["LicenseApi", "InfoApi"])
        toolkit._init_basic_apis()
        names = [a.__class__.__name__ for a in toolkit.apis]
        assert "LicenseApi" not in names
        assert "InfoApi" not in names
        assert "AuthApi" in names

    def test_includes_all_when_no_exclusion(self):
        toolkit = FastAPIReactToolkit()
        toolkit._init_basic_apis()
        names = [a.__class__.__name__ for a in toolkit.apis]
        for cls_name in (
            "InfoApi",
            "AuthApi",
            "ViewsMenusApi",
            "PermissionsApi",
            "PermissionViewApi",
            "UsersApi",
            "RolesApi",
        ):
            assert cls_name in names


class TestInitConfig:
    def test_app_metadata_set(self, config_setter):
        config_setter("APP_NAME", "TierTestApp")
        config_setter("APP_VERSION", "9.9.9")
        config_setter("APP_SUMMARY", "summary")
        config_setter("APP_DESCRIPTION", "desc")

        app = FastAPI()
        toolkit = FastAPIReactToolkit()
        toolkit.app = app
        toolkit._init_config()

        assert app.title == "TierTestApp"
        assert app.version == "9.9.9"
        assert app.summary == "summary"
        assert app.description == "desc"


class TestConfigProperty:
    def test_config_returns_g_config(self):
        from fastapi_rtk.globals import g

        toolkit = FastAPIReactToolkit()
        assert toolkit.config is g.config


class TestInsertHelpers:
    @pytest.mark.asyncio
    async def test_insert_permissions_dedupes(self):
        toolkit = FastAPIReactToolkit()
        toolkit.apis = [
            SimpleNamespace(permissions=["can_get", "can_post"]),
            SimpleNamespace(permissions=["can_post"]),
        ]

        captured = []

        async def fake_create_permissions(perms, *, session):
            captured.append(perms)
            return [SimpleNamespace(name=p) for p in perms]

        toolkit.sm = SimpleNamespace(
            create_permissions=fake_create_permissions,
            get_api_permission_tuples_from_builtin_roles=lambda: [
                ("X", "can_post"),
                ("Y", "can_extra"),
            ],
        )
        result = await toolkit._insert_permissions(session=None)
        # Dedupes can_post; can_extra added from builtin roles
        names = [p.name for p in result]
        assert sorted(names) == ["can_extra", "can_get", "can_post"]

    @pytest.mark.asyncio
    async def test_insert_apis_dedupes(self):
        toolkit = FastAPIReactToolkit()
        toolkit.apis = [
            SimpleNamespace(__class__=type("FooApi", (), {}), permissions=[]),
        ]
        # Replace __class__ name properly
        api_obj = SimpleNamespace(permissions=[])
        type("FooApi", (), {})  # ensure class exists
        toolkit.apis = [api_obj]

        async def fake_create_apis(apis, *, session):
            return [SimpleNamespace(name=a) for a in apis]

        toolkit.sm = SimpleNamespace(
            create_apis=fake_create_apis,
            get_api_permission_tuples_from_builtin_roles=lambda: [
                ("BuiltinApi", "can_x")
            ],
        )

        # api_obj.__class__.__name__ -> "SimpleNamespace"
        result = await toolkit._insert_apis(session=None)
        names = [a.name for a in result]
        assert "BuiltinApi" in names
        assert "SimpleNamespace" in names


class TestInitDatabaseLogsBinds:
    """Cover the BINDS log loop (lines 417-420) when binds exist."""

    async def test_engine_with_binds_logs(
        self, make_toolkit_app, config_setter, caplog
    ):
        import logging

        config_setter(
            "SQLALCHEMY_BINDS",
            {"audit": "sqlite+aiosqlite:///:memory:"},
        )
        app = make_toolkit_app()
        with caplog.at_level(logging.INFO, logger="DT_FASTAPI"):
            async with app.router.lifespan_context(app):
                pass
        # 'BINDS ===' headers logged when engine_binds exists
        assert any("BINDS" in r.getMessage() for r in caplog.records)


class TestLifespanAlreadySetRaises:
    """Cover line 720 - ValueError when app.lifespan already configured."""

    def test_app_with_lifespan_pre_set_raises(self, config_setter, tmp_path):
        from contextlib import asynccontextmanager

        config_setter("SQLALCHEMY_DATABASE_URI", "sqlite+aiosqlite:///:memory:")
        config_setter("STATIC_FOLDER", str(tmp_path / "static"))
        config_setter("TEMPLATE_FOLDER", str(tmp_path / "templates"))
        config_setter("PROFILER_ENABLED", False)
        config_setter("SECWEB_ENABLED", False)

        @asynccontextmanager
        async def custom_lifespan(_app):
            yield

        app = FastAPI(lifespan=custom_lifespan)
        toolkit = FastAPIReactToolkit(exclude_apis=["LicenseApi"])
        with pytest.raises(ValueError, match="Lifespan already set"):
            toolkit.initialize(app)


class TestOnStartupShutdownArgVariants:
    """Cover lines 663-669 + 685-691 - on_startup/on_shutdown with/without arg."""

    async def test_on_startup_no_arg_invocation(self, make_toolkit_app):
        called = []

        async def hook():
            called.append("startup")

        app = make_toolkit_app(config_overrides={"on_startup": hook})
        # Toolkit doesn't pull on_startup from config; set on instance.
        from fastapi_rtk.globals import g

        g.current_app.on_startup = hook
        async with app.router.lifespan_context(app):
            pass
        assert "startup" in called

    async def test_on_startup_with_arg_invocation(self, make_toolkit_app):
        called = []

        async def hook(_app):
            called.append("startup")

        from fastapi_rtk.globals import g

        app = make_toolkit_app()
        g.current_app.on_startup = hook
        async with app.router.lifespan_context(app):
            pass
        assert "startup" in called

    async def test_on_shutdown_no_arg(self, make_toolkit_app):
        called = []

        def hook():
            called.append("shutdown")

        from fastapi_rtk.globals import g

        app = make_toolkit_app()
        g.current_app.on_shutdown = hook
        async with app.router.lifespan_context(app):
            pass
        assert "shutdown" in called

    async def test_on_shutdown_with_arg(self, make_toolkit_app):
        called = []

        def hook(_app):
            called.append("shutdown")

        from fastapi_rtk.globals import g

        app = make_toolkit_app()
        g.current_app.on_shutdown = hook
        async with app.router.lifespan_context(app):
            pass
        assert "shutdown" in called


class TestAppMetadataFallbacks:
    """Cover lines 630, 634 - APP_VERSION default branch + DEBUG log level."""

    def test_debug_lowers_log_level_via_init(self, config_setter, tmp_path):
        import logging

        from fastapi_rtk.const import logger as rtk_logger

        config_setter("SQLALCHEMY_DATABASE_URI", "sqlite+aiosqlite:///:memory:")
        config_setter("STATIC_FOLDER", str(tmp_path / "static"))
        config_setter("TEMPLATE_FOLDER", str(tmp_path / "templates"))
        config_setter("PROFILER_ENABLED", False)
        config_setter("SECWEB_ENABLED", False)
        config_setter("DEBUG", True)

        original_level = rtk_logger.level
        try:
            app = FastAPI()
            toolkit = FastAPIReactToolkit(exclude_apis=["LicenseApi"])
            toolkit.initialize(app)
            assert rtk_logger.level == logging.DEBUG
        finally:
            rtk_logger.setLevel(original_level)


class TestEndToEndAssembly:
    """Build a tiny app with sqlite and call initialize() to ensure the
    full assembly path doesn't blow up on a minimal config.
    """

    def test_initialize_smoke(self, config_setter, tmp_path):
        config_setter("SQLALCHEMY_DATABASE_URI", "sqlite+aiosqlite:///:memory:")
        config_setter("STATIC_FOLDER", str(tmp_path / "static"))
        config_setter("TEMPLATE_FOLDER", str(tmp_path / "templates"))
        config_setter("PROFILER_ENABLED", False)
        config_setter("SECWEB_ENABLED", False)
        config_setter("DEBUG", False)

        app = FastAPI()
        toolkit = FastAPIReactToolkit(exclude_apis=["LicenseApi"])
        toolkit.initialize(app)

        # Toolkit registered
        assert toolkit.initialized is True
        # Basic APIs added
        names = [a.__class__.__name__ for a in toolkit.apis]
        assert "InfoApi" in names
        assert "AuthApi" in names
        # `LicenseApi` excluded
        assert "LicenseApi" not in names


class TestToolkitLifespanSmoke:
    """Drive the lifespan_context to exercise init_db + permission seed paths."""

    @pytest.mark.asyncio
    async def test_lifespan_context_runs(self, make_toolkit_app):
        app = make_toolkit_app()
        async with app.router.lifespan_context(app):
            assert app is not None


class TestToolkitDebugLogLevel:
    """Line 634: DEBUG=True sets logger level to DEBUG."""

    def test_debug_config_sets_log_level(self, make_toolkit_app):
        app = make_toolkit_app(config_overrides={"DEBUG": True})
        assert app is not None
