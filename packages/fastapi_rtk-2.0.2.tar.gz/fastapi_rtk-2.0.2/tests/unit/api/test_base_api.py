"""Tier 12 - tests for fastapi_rtk.api.base_api.BaseApi.

Covers class attributes, _initialize_router with @expose decorated methods,
_is_in_base_permissions logic, and integrate_router with a stub toolkit.
End-to-end HTTP integration is deferred to tier 15.
"""

from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
from fastapi import APIRouter

from fastapi_rtk.api.base_api import BaseApi
from fastapi_rtk.const import PERMISSION_PREFIX
from fastapi_rtk.decorators import expose, login_required, permission_name, protect


class TestClassAttributes:
    def test_default_version(self):
        assert BaseApi.version == "v1"

    def test_default_resource_name_is_class_name(self):
        class TierMyApi(BaseApi):
            pass

        api = TierMyApi()
        assert api.resource_name == "tiermyapi"

    def test_explicit_resource_name(self):
        class TierMyApi(BaseApi):
            resource_name = "explicit"

        api = TierMyApi()
        assert api.resource_name == "explicit"

    def test_router_lazy_prefix(self):
        class TierRouterApi(BaseApi):
            resource_name = "router_test"

        api = TierRouterApi()
        assert api.router.prefix == "/api/v1/router_test"
        assert api.router.tags == ["TierRouterApi"]

    def test_default_base_permissions_none(self):
        assert BaseApi.base_permissions is None


class TestIsInBasePermissions:
    def test_no_base_permissions_returns_true(self):
        class TierApi1(BaseApi):
            pass

        api = TierApi1()
        assert api._is_in_base_permissions("anything") is True

    def test_in_base_permissions_returns_true(self):
        class TierApi2(BaseApi):
            base_permissions = [f"{PERMISSION_PREFIX}get", f"{PERMISSION_PREFIX}post"]

        api = TierApi2()
        assert api._is_in_base_permissions("get") is True
        assert api._is_in_base_permissions("post") is True

    def test_not_in_base_permissions_returns_false(self):
        class TierApi3(BaseApi):
            base_permissions = [f"{PERMISSION_PREFIX}get"]

        api = TierApi3()
        assert api._is_in_base_permissions("delete") is False


class TestExposedRoutes:
    def test_route_registers_via_expose(self):
        class TierExposeApi(BaseApi):
            resource_name = "expose_test"

            @expose("/hello", methods=["GET"])
            async def hello(self):
                return {"message": "hi"}

        api = TierExposeApi()
        # routes_to_register contains tuples for each registered path/method
        assert len(api.routes_to_register) >= 1
        registered_paths = [
            rest_data["path"] for _, rest_data, _, _ in api.routes_to_register
        ]
        assert "/hello" in registered_paths

    def test_route_with_permission_filtered_out(self):
        class TierPermApi(BaseApi):
            base_permissions = [f"{PERMISSION_PREFIX}get"]

            @expose("/restricted", methods=["GET"])
            @protect()
            @permission_name("write")
            async def restricted(self):
                return {}

        api = TierPermApi()
        # `write` not in base_permissions -> route not registered
        registered_paths = [
            rest_data["path"] for _, rest_data, _, _ in api.routes_to_register
        ]
        assert "/restricted" not in registered_paths

    def test_route_with_permission_in_base_registered(self):
        class TierPermOkApi(BaseApi):
            base_permissions = [f"{PERMISSION_PREFIX}read"]

            @expose("/allowed", methods=["GET"])
            @protect()
            @permission_name("read")
            async def allowed(self):
                return {}

        api = TierPermOkApi()
        registered_paths = [
            rest_data["path"] for _, rest_data, _, _ in api.routes_to_register
        ]
        assert "/allowed" in registered_paths
        assert f"{PERMISSION_PREFIX}read" in api.permissions

    def test_messages_populated(self):
        class TierMsgApi(BaseApi):
            @expose("/path1", methods=["GET"])
            async def hello(self):
                return {}

        api = TierMsgApi()
        assert any("Registering route" in m for m in api.messages)


class TestPriorityRoutes:
    def test_priority_routes_reordered(self):
        from fastapi_rtk.decorators import priority

        class TierPrioApi(BaseApi):
            @expose("/lowprio", methods=["GET"])
            @priority(1)
            async def low(self):
                return {}

            @expose("/highprio", methods=["GET"])
            @priority(10)
            async def high(self):
                return {}

        api = TierPrioApi()
        # Last registered routes are priority routes sorted desc.
        assert len(api.routes_to_register) >= 2


class TestLifecycleHooks:
    @pytest.mark.asyncio
    async def test_on_startup_default_noop(self):
        class TierLifeApi(BaseApi):
            pass

        api = TierLifeApi()
        result = await api.on_startup()
        assert result is None

    @pytest.mark.asyncio
    async def test_on_shutdown_default_noop(self):
        class TierLifeApi(BaseApi):
            pass

        api = TierLifeApi()
        result = await api.on_shutdown()
        assert result is None


class TestIntegrateRouter:
    def test_integrates_routes_into_app(self):
        class TierIntApi(BaseApi):
            resource_name = "integrate_test"

            @expose("/ping", methods=["GET"])
            async def ping(self):
                return {"pong": True}

        api = TierIntApi()
        api.toolkit = SimpleNamespace(global_user_dependency=False)
        app_router = APIRouter()
        api.integrate_router(app_router)

        # router has the route now
        paths = [r.path for r in api.router.routes]
        assert any("/ping" in p for p in paths)

    def test_integrate_with_global_user_dep_adds_dependency(self):
        from fastapi import Depends

        class TierIntDepApi(BaseApi):
            resource_name = "integrate_dep_test"

            @expose("/ping", methods=["GET"])
            async def ping(self):
                return {}

        api = TierIntDepApi()
        api.toolkit = SimpleNamespace(global_user_dependency=True)
        app_router = APIRouter()
        api.integrate_router(app_router)
        # No exception means the dependency was injected without error
        assert any("/ping" in r.path for r in api.router.routes)

    def test_integrate_logs_messages(self, caplog):
        class TierLogApi(BaseApi):
            @expose("/log", methods=["GET"])
            async def x(self):
                return {}

        api = TierLogApi()
        api.toolkit = SimpleNamespace(global_user_dependency=False)
        app_router = APIRouter()
        with caplog.at_level("INFO", logger="DT_FASTAPI"):
            api.integrate_router(app_router)
        assert any("Registering route" in r.message for r in caplog.records)


class TestRouteSuffix:
    def test_headless_method_skipped_unless_in_routes(self):
        # Methods ending in `_headless` are skipped when not opted in
        class TierHeadless(BaseApi):
            @expose("/external", methods=["GET"])
            async def external(self):
                return {}

            async def helper_headless(self):
                """Should NOT be registered."""
                return {}

        api = TierHeadless()
        registered_paths = [
            rest_data["path"] for _, rest_data, _, _ in api.routes_to_register
        ]
        assert "/external" in registered_paths


class TestBaseApiResponseModelStr:
    """Line 200: response_model_str metadata resolves to attr on Api class."""

    def test_response_model_str_resolved_on_route(self):
        from pydantic import BaseModel

        from fastapi_rtk.api.base_api import BaseApi
        from fastapi_rtk.decorators import expose, response_model_str

        class WidgetSchema(BaseModel):
            name: str

        class FooApi(BaseApi):
            resource_name = "foo_response_model"
            widget_schema = WidgetSchema

            @expose("/foo", methods=["GET"])
            @response_model_str("widget_schema")
            async def foo(self):
                return {"name": "bar"}

        api = FooApi()
        matching = [
            rest_data
            for _func, rest_data, _attr, _meta in api.routes_to_register
            if rest_data.get("response_model") is WidgetSchema
        ]
        assert matching, "response_model_str not resolved on registered route"
