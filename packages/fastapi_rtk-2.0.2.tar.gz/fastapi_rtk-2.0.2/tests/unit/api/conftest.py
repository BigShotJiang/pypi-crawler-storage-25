"""Shared fixtures for tier 12 api/ tests."""

import pytest
import sqlalchemy

from fastapi_rtk.backends.sqla.model import Model


class TierWidget(Model):
    __tablename__ = "tier12_widget"
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
    name = sqlalchemy.Column(sqlalchemy.String(50), nullable=False)
    description = sqlalchemy.Column(sqlalchemy.String(200))
    quantity = sqlalchemy.Column(sqlalchemy.Integer, default=0)


@pytest.fixture
def Widget_cls():
    return TierWidget


@pytest.fixture
def widget_interface():
    from fastapi_rtk.backends.sqla.interface import SQLAInterface

    return SQLAInterface(TierWidget)
