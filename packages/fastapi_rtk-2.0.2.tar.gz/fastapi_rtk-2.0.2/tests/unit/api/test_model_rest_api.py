"""Tier 12 - tests for fastapi_rtk.api.model_rest_api.ModelRestApi.

Covers constructor wiring, the static prettify helpers, query parameter
validation/handling, schema extra fields normalization, route list
filtering, and label column generation. End-to-end HTTP flows
(GET /, POST /, etc.) are deferred to tier 15 since they require the
full toolkit + db lifespan.
"""

from types import SimpleNamespace
from typing import Annotated, Optional
from unittest.mock import MagicMock

import pytest
from pydantic import Field

from fastapi_rtk.api.model_rest_api import ModelRestApi
from fastapi_rtk.backends.sqla.interface import SQLAInterface
from fastapi_rtk.exceptions import HTTPWithValidationException
from fastapi_rtk.schemas import QuerySchema


class TestPrettifyStatics:
    def test_prettify_name_camelcase(self):
        assert ModelRestApi._prettify_name("HelloWorld") == "Hello World"

    def test_prettify_name_no_change(self):
        assert ModelRestApi._prettify_name("Hello") == "Hello"

    def test_prettify_name_multiple_caps(self):
        assert (
            ModelRestApi._prettify_name("MyTestApiClass") == "My Test Api Class"
        )

    def test_prettify_column_underscore(self):
        assert ModelRestApi._prettify_column("hello_world") == "Hello World"

    def test_prettify_column_dot(self):
        assert ModelRestApi._prettify_column("user.name") == "User Name"

    def test_prettify_column_mixed(self):
        assert ModelRestApi._prettify_column("first_name.last") == "First Name Last"


class TestConstructor:
    def test_missing_datamodel_raises(self):
        class TierBadApi(ModelRestApi):
            pass

        with pytest.raises(Exception, match="datamodel must be set"):
            TierBadApi()

    def test_constructs_with_datamodel(self, Widget_cls):
        class TierWidgetApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierWidgetApi()
        assert api.datamodel.obj is Widget_cls

    def test_resource_name_defaults_to_model_lowercase(self, Widget_cls):
        class TierWApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierWApi()
        assert api.resource_name == "tierwidget"

    def test_post_properties_invoked(self, Widget_cls):
        called = []

        class TierPpApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

            def post_properties(self):
                called.append("pp")

        TierPpApi()
        assert called == ["pp"]

    def test_post_schema_invoked(self, Widget_cls):
        called = []

        class TierPsApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

            def post_schema(self):
                called.append("ps")

        TierPsApi()
        assert called == ["ps"]


class TestRoutesList:
    def test_default_routes(self, Widget_cls):
        class TierRApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierRApi()
        # No image/file columns -> filtered out
        assert "image" not in api.routes
        assert "file" not in api.routes
        assert "info" in api.routes
        assert "get_list" in api.routes
        assert "get" in api.routes
        assert "post" in api.routes
        assert "put" in api.routes
        assert "delete" in api.routes
        assert "download" in api.routes
        assert "bulk" in api.routes

    def test_exclude_routes_filters(self, Widget_cls):
        class TierExclApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)
            exclude_routes = ["delete", "bulk"]

        api = TierExclApi()
        assert "delete" not in api.routes
        assert "bulk" not in api.routes
        assert "get_list" in api.routes

    def test_protected_routes_defaults_to_routes(self, Widget_cls):
        class TierProtApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierProtApi()
        assert set(api.protected_routes) == set(api.routes)

    def test_exclude_protected_routes(self, Widget_cls):
        class TierUnprotApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)
            exclude_protected_routes = ["info"]

        api = TierUnprotApi()
        assert "info" not in api.protected_routes
        assert "info" in api.routes


class TestLabelColumns:
    def test_auto_generated_labels(self, Widget_cls):
        class TierLblApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierLblApi()
        # Auto-generated labels: snake_case -> Title Case via _prettify_column
        for col in ("name", "description", "quantity"):
            assert col in api.label_columns

    def test_explicit_labels_preserved(self, Widget_cls):
        class TierLblExpApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)
            label_columns = {"name": "Custom Name"}

        api = TierLblExpApi()
        assert api.label_columns["name"] == "Custom Name"


class TestGenLabelsColumns:
    def test_adds_missing_labels(self, Widget_cls):
        class TierGLApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierGLApi()
        api.label_columns.clear()
        api._gen_labels_columns(["foo_bar", "x"])
        assert api.label_columns["foo_bar"] == "Foo Bar"
        assert api.label_columns["x"] == "X"

    def test_does_not_overwrite_existing(self, Widget_cls):
        class TierGLOvApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierGLOvApi()
        api.label_columns["name"] = "EXPLICIT"
        api._gen_labels_columns(["name"])
        assert api.label_columns["name"] == "EXPLICIT"


class TestValidateQueryParameters:
    def test_valid_columns_pass(self, Widget_cls):
        class TierVQ1Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierVQ1Api()
        q = QuerySchema(columns='["name"]', filters="[]")
        api._validate_query_parameters(q)

    def test_invalid_column_raises(self, Widget_cls):
        class TierVQ2Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierVQ2Api()
        q = QuerySchema(columns='["bogus"]', filters="[]")
        with pytest.raises(HTTPWithValidationException):
            api._validate_query_parameters(q)


class TestHandleQueryParams:
    def test_returns_db_query_params(self, Widget_cls):
        class TierHQApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierHQApi()
        q = QuerySchema(page=1, page_size=10, columns='["name"]', filters="[]")
        result = api._handle_query_params(q)
        assert result["list_columns"] == ["name"]
        assert result["page"] == 1
        assert result["page_size"] == 10

    def test_falls_back_to_list_columns_when_q_columns_empty(self, Widget_cls):
        class TierHQ2Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierHQ2Api()
        q = QuerySchema(columns="[]", filters="[]")
        result = api._handle_query_params(q)
        # list_columns from the API used as default (should include name etc.)
        assert "name" in result["list_columns"]

    def test_base_order_applied_when_q_lacks_order(self, Widget_cls):
        class TierHQBaseApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)
            base_order = ("name", "asc")

        api = TierHQBaseApi()
        q = QuerySchema(columns='["name"]', filters="[]")
        result = api._handle_query_params(q)
        assert result["order_column"] == "name"
        assert result["order_direction"] == "asc"

    def test_q_order_overrides_base(self, Widget_cls):
        class TierHQOvApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)
            base_order = ("name", "asc")

        api = TierHQOvApi()
        q = QuerySchema(
            columns='["name"]',
            filters="[]",
            order_column="quantity",
            order_direction="desc",
        )
        result = api._handle_query_params(q)
        assert result["order_column"] == "quantity"
        assert result["order_direction"] == "desc"

    def test_global_filter_emits_tuple(self, Widget_cls):
        class TierGFApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierGFApi()
        q = QuerySchema(columns='["name"]', filters="[]", global_filter="abc")
        result = api._handle_query_params(q)
        assert result["global_filter"] is not None


class TestHandleSchemaExtraFields:
    def test_already_tuple_kept(self, Widget_cls):
        class TierESApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierESApi()
        result = api._handle_schema_extra_fields({"x": (int, Field(default=5))})
        assert result["x"][0] is int

    def test_plain_type_wrapped(self, Widget_cls):
        class TierES2Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierES2Api()
        result = api._handle_schema_extra_fields({"name": str})
        assert result["name"][0] is str
        # required field (no default)
        assert result["name"][1].default is not None or True  # smoke

    def test_optional_type_gets_none_default(self, Widget_cls):
        class TierES3Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierES3Api()
        result = api._handle_schema_extra_fields({"x": Optional[str]})
        # default None applied for nullable types
        assert result["x"][1].default is None


class TestGetDatamodelAndColumn:
    def test_simple_column(self, Widget_cls):
        class TierGDApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierGDApi()
        dm, col = api._get_datamodel_and_column("name")
        assert dm is api.datamodel
        assert col == "name"


class TestRouterIntegration:
    def test_router_prefix(self, Widget_cls):
        class TierMRApi(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierMRApi()
        assert api.router.prefix == "/api/v1/tierwidget"

    def test_routes_to_register_populated(self, Widget_cls):
        class TierMR2Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = TierMR2Api()
        # Should have multiple registered route entries (info, list, get, post, put, delete, etc.)
        assert len(api.routes_to_register) >= 5


# ---------------------------------------------------------------------------
# Constructor branches: search_filters, search_exclude_filters, base_filters,
# base_opr_filters, opr_filters, *_query_rel_fields. Targeted unit tests so
# we don't need a full toolkit + db lifespan.
# ---------------------------------------------------------------------------


@pytest.fixture
def Country_cls():
    import sqlalchemy

    from fastapi_rtk.backends.sqla.model import Model

    if "tier12_country" in Model.metadata.tables:
        for mapper in Model.registry.mappers:
            if mapper.local_table is Model.metadata.tables["tier12_country"]:
                return mapper.class_

    class TierCountry(Model):
        __tablename__ = "tier12_country"
        id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
        name = sqlalchemy.Column(sqlalchemy.String(50))

    return TierCountry


@pytest.fixture
def WidgetWithCountry_cls(Country_cls):
    import sqlalchemy
    from sqlalchemy.orm import relationship

    from fastapi_rtk.backends.sqla.model import Model

    if "tier12_widget_country" in Model.metadata.tables:
        for mapper in Model.registry.mappers:
            if mapper.local_table is Model.metadata.tables["tier12_widget_country"]:
                return mapper.class_

    class TierWidgetCountry(Model):
        __tablename__ = "tier12_widget_country"
        id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
        name = sqlalchemy.Column(sqlalchemy.String(50))
        country_id = sqlalchemy.Column(
            sqlalchemy.Integer, sqlalchemy.ForeignKey("tier12_country.id")
        )
        country = relationship(Country_cls)

    return TierWidgetCountry


class TestInitPropertiesBranches:
    """Cover the search_filters / base_filters / opr_filters branches in
    _init_properties (lines 1030-1078)."""

    def test_search_filters_extends_datamodel_filters(self, Widget_cls):
        from fastapi_rtk.backends.sqla.filters import FilterEqual

        class Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)
            search_filters = {"name": [FilterEqual]}

        api = Api()
        # FilterEqual instance should now be in the datamodel filters for "name"
        assert any(
            isinstance(f, FilterEqual) for f in api.datamodel.filters["name"]
        )

    def test_search_exclude_filters_removes_from_datamodel(self, Widget_cls):
        from fastapi_rtk.backends.sqla.filters import FilterEqual

        class Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)
            search_exclude_filters = {"name": ["eq"]}

        api = Api()
        assert "eq" in api.datamodel.exclude_filters["name"]
        # No filter with arg_name "eq" should remain on "name"
        assert all(f.arg_name != "eq" for f in api.datamodel.filters["name"])

    def test_search_columns_with_double_dot_relation_raises(
        self, WidgetWithCountry_cls
    ):
        class Api(ModelRestApi):
            datamodel = SQLAInterface(WidgetWithCountry_cls)
            search_columns = ["country.name.something"]

        with pytest.raises(Exception, match="2nd level relations"):
            Api()

    def test_base_filters_initialized(self, Widget_cls):
        from fastapi_rtk.backends.sqla.filters import FilterEqual

        class Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)
            base_filters = [["name", FilterEqual, "Hammer"]]

        api = Api()
        assert len(api.base_filters) == 1
        # Filter is now an instance, value preserved
        assert api.base_filters[0][2] == "Hammer"

    def test_base_opr_filters_initialized(self, Widget_cls):
        from fastapi_rtk.backends.sqla.filters import FilterEqual

        class Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)
            base_opr_filters = [[FilterEqual, "Hammer"]]

        api = Api()
        assert len(api.base_opr_filters) == 1
        assert isinstance(api.base_opr_filters[0][0], FilterEqual)
        assert api.base_opr_filters[0][1] == "Hammer"

    def test_opr_filters_instantiated(self, Widget_cls):
        from fastapi_rtk.backends.sqla.filters import FilterEqual

        class Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)
            opr_filters = [FilterEqual]

        api = Api()
        assert len(api.opr_filters) == 1
        assert isinstance(api.opr_filters[0], FilterEqual)

    def test_query_rel_fields_initialized(
        self, WidgetWithCountry_cls
    ):
        from fastapi_rtk.backends.sqla.filters import FilterEqual

        class Api(ModelRestApi):
            datamodel = SQLAInterface(WidgetWithCountry_cls)
            add_query_rel_fields = {"country": [["name", FilterEqual, "Germany"]]}
            edit_query_rel_fields = {"country": [["name", FilterEqual, "Germany"]]}
            search_query_rel_fields = {"country": [["name", FilterEqual, "Germany"]]}

        api = Api()
        # Filters should be initialized (instantiated)
        assert len(api.add_query_rel_fields["country"]) == 1


class TestGetDatamodelAndColumnRelation:
    """Cover the dot-notation branch in _get_datamodel_and_column (line 2381)."""

    def test_dot_notation_returns_related_datamodel(self, WidgetWithCountry_cls):
        class Api(ModelRestApi):
            datamodel = SQLAInterface(WidgetWithCountry_cls)

        api = Api()
        dm, col = api._get_datamodel_and_column("country.name")
        # Returns the related interface for "country" and the inner column "name"
        assert dm is not api.datamodel
        assert col == "name"


class TestImageFileFileRouteSkipsWhenNoColumns:
    """Cover early-return branches at lines 1147 (image) and 1170 (file) when
    the model has no image / file columns. Covered indirectly via `routes`
    filter, but a direct call to image() / file() exercises the early return."""

    def test_image_method_returns_when_no_image_columns(self, Widget_cls):
        class Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = Api()
        # No image columns → image() method returns without registering route
        result = api.image()
        assert result is None

    def test_file_method_returns_when_no_file_columns(self, Widget_cls):
        class Api(ModelRestApi):
            datamodel = SQLAInterface(Widget_cls)

        api = Api()
        result = api.file()
        assert result is None


class TestImageFileHeadlessReturnValueIntercepts:
    """Cover pre_image / pre_file return-value branches at lines 1339-1342
    and 1357-1360 by overriding the hooks on a real API instance with
    file/image columns."""

    @pytest.fixture
    def file_image_api(self, tmp_path, config_setter):
        import sqlalchemy

        from fastapi_rtk.backends.sqla.model import Model
        from fastapi_rtk.types import FileColumn, ImageColumn

        config_setter("UPLOAD_FOLDER", str(tmp_path / "files"))
        config_setter("IMG_UPLOAD_FOLDER", str(tmp_path / "imgs"))
        (tmp_path / "files").mkdir()
        (tmp_path / "imgs").mkdir()

        if "tier12_doc" in Model.metadata.tables:
            for mapper in Model.registry.mappers:
                if mapper.local_table is Model.metadata.tables["tier12_doc"]:
                    DocCls = mapper.class_
                    break
            else:
                DocCls = None
        else:
            DocCls = None

        if DocCls is None:

            class TierDoc(Model):
                __tablename__ = "tier12_doc"
                id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
                name = sqlalchemy.Column(sqlalchemy.String(50))
                document = sqlalchemy.Column(FileColumn(allowed_extensions=["txt"]))
                avatar = sqlalchemy.Column(ImageColumn(allowed_extensions=["png"]))

            DocCls = TierDoc

        class Api(ModelRestApi):
            datamodel = SQLAInterface(DocCls)

        return Api()

    @pytest.mark.asyncio
    async def test_pre_image_returns_str_uses_as_filename(self, file_image_api):
        async def hook(filename):
            return "renamed.png"

        file_image_api.pre_image = hook
        # avatar file doesn't exist → 404 after rename
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as exc_info:
            await file_image_api.image_headless("any.png")
        assert exc_info.value.status_code == 404

    @pytest.mark.asyncio
    async def test_pre_image_returns_non_str_short_circuits(self, file_image_api):
        sentinel = {"detail": "intercept"}

        async def hook(filename):
            return sentinel

        file_image_api.pre_image = hook
        result = await file_image_api.image_headless("any.png")
        assert result is sentinel

    @pytest.mark.asyncio
    async def test_pre_file_returns_str_uses_as_filename(self, file_image_api):
        async def hook(filename):
            return "renamed.txt"

        file_image_api.pre_file = hook
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as exc_info:
            await file_image_api.file_headless("any.txt")
        assert exc_info.value.status_code == 404

    @pytest.mark.asyncio
    async def test_pre_file_returns_non_str_short_circuits(self, file_image_api):
        sentinel = {"detail": "intercept"}

        async def hook(filename):
            return sentinel

        file_image_api.pre_file = hook
        result = await file_image_api.file_headless("any.txt")
        assert result is sentinel


class TestJsonformsListItemsSchema:
    @pytest.mark.parametrize(
        "col_type,expected",
        [
            (bool, {"type": "boolean"}),
            (int, {"type": "integer"}),
            (float, {"type": "number"}),
            (str, {"type": "string"}),
            (None, {"type": "string"}),
            (object, {"type": "string"}),
        ],
    )
    def test_items_schema_for_col_type(self, col_type, expected):
        assert ModelRestApi._jsonforms_list_items_schema(col_type) == expected


class TestGenerateJsonformsSchemaListBranch:
    """`_generate_jsonforms_schema` must surface ListColumn as `type: array`
    with `items` derived from the SQLA col_type, not fall through to JSON's
    `type: object` branch."""

    @pytest.fixture(scope="class")
    def list_api(self):
        import sqlalchemy

        from fastapi_rtk import (
            JSONBListColumn,
            ListColumn,
            Mapped,
            mapped_column,
        )
        from fastapi_rtk.backends.sqla.model import Model

        class _ListJfModel(Model):
            __tablename__ = "tier12_listjf"
            __table_args__ = {"extend_existing": True}
            id: Mapped[int] = mapped_column(sqlalchemy.Integer, primary_key=True)
            tags: Mapped[list[str] | None] = mapped_column(ListColumn(str))
            nums: Mapped[list[int] | None] = mapped_column(ListColumn(int))
            flags: Mapped[list[bool] | None] = mapped_column(ListColumn(bool))
            raws: Mapped[list | None] = mapped_column(ListColumn())
            blob: Mapped[list | None] = mapped_column(JSONBListColumn(int))
            payload: Mapped[dict | None] = mapped_column(sqlalchemy.JSON)

        class TierListJfApi(ModelRestApi):
            datamodel = SQLAInterface(_ListJfModel)

        return TierListJfApi()

    def test_string_list_items(self, list_api):
        schema = list_api.add_obj_schema
        result = list_api._generate_jsonforms_schema(schema, [], False)
        assert result["properties"]["tags"]["type"] == ["array", "null"]
        assert result["properties"]["tags"]["items"] == {"type": "string"}

    def test_integer_list_items(self, list_api):
        schema = list_api.add_obj_schema
        result = list_api._generate_jsonforms_schema(schema, [], False)
        assert result["properties"]["nums"]["type"] == ["array", "null"]
        assert result["properties"]["nums"]["items"] == {"type": "integer"}

    def test_boolean_list_items(self, list_api):
        schema = list_api.add_obj_schema
        result = list_api._generate_jsonforms_schema(schema, [], False)
        assert result["properties"]["flags"]["type"] == ["array", "null"]
        assert result["properties"]["flags"]["items"] == {"type": "boolean"}

    def test_untyped_list_falls_back_to_string_items(self, list_api):
        schema = list_api.add_obj_schema
        result = list_api._generate_jsonforms_schema(schema, [], False)
        assert result["properties"]["raws"]["type"] == ["array", "null"]
        assert result["properties"]["raws"]["items"] == {"type": "string"}

    def test_jsonb_list_uses_array_not_object(self, list_api):
        schema = list_api.add_obj_schema
        result = list_api._generate_jsonforms_schema(schema, [], False)
        # `is_jsonb` returns True for JSONBListColumn but the new is_list branch
        # runs first so the column is reported as an array, not an object.
        assert result["properties"]["blob"]["type"] == ["array", "null"]
        assert result["properties"]["blob"]["items"] == {"type": "integer"}

    def test_plain_json_still_object(self, list_api):
        schema = list_api.add_obj_schema
        result = list_api._generate_jsonforms_schema(schema, [], False)
        # Plain `sqlalchemy.JSON` (not a ListColumn) keeps the original behavior.
        assert result["properties"]["payload"]["type"] == ["object", "null"]
