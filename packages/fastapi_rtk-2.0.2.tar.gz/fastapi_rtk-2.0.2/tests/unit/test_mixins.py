import logging

from fastapi_rtk.const import logger as root_logger
from fastapi_rtk.mixins import LoggerMixin


class TestLoggerMixin:
    def test_logger_is_child_of_root(self):
        class Foo(LoggerMixin):
            pass

        instance = Foo()
        assert instance.logger.name == f"{root_logger.name}.Foo"

    def test_logger_is_logger_instance(self):
        class Bar(LoggerMixin):
            pass

        assert isinstance(Bar().logger, logging.Logger)

    def test_logger_named_after_subclass(self):
        class Parent(LoggerMixin):
            pass

        class Child(Parent):
            pass

        assert Child().logger.name == f"{root_logger.name}.Child"
        assert Parent().logger.name == f"{root_logger.name}.Parent"

    def test_logger_lazy_cached_per_instance(self):
        class Baz(LoggerMixin):
            pass

        b = Baz()
        assert b.logger is b.logger
