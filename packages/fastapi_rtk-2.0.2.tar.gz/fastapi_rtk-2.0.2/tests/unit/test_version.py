import re

from fastapi_rtk import version


def test_version_module_has_version_attr():
    assert hasattr(version, "__version__")
    assert isinstance(version.__version__, str)
    assert version.__version__


def test_version_string_is_pep440_like():
    assert re.match(r"^\d+\.\d+", version.__version__) or version.__version__ == "0.0.0"


def test_top_level_re_export():
    import fastapi_rtk

    assert fastapi_rtk.__version__ == version.__version__
