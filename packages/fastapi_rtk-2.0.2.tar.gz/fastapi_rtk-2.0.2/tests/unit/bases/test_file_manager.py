import pytest

from fastapi_rtk.bases.file_manager import (
    AbstractFileManager,
    AbstractImageManager,
    BaseFileException,
    FileNotAllowedException,
    FileTooLargeException,
)
from fastapi_rtk.exceptions import FastAPIReactToolkitException


class StubFileManager(AbstractFileManager):
    """Concrete subclass of AbstractFileManager for testing non-abstract behavior."""

    def get_path(self, filename):
        return f"{self.base_path}/{filename}"

    def get_file(self, filename):
        return b"data"

    async def stream_file(self, filename):
        yield b"chunk"

    def save_file(self, file_data, filename):
        return self.get_path(filename)

    def save_content_to_file(self, content, filename):
        return self.get_path(filename)

    def delete_file(self, filename):
        return None

    def file_exists(self, filename):
        return False


class TestExceptions:
    def test_base_file_exception_inherits_rtk(self):
        assert issubclass(BaseFileException, FastAPIReactToolkitException)

    def test_file_not_allowed_message(self):
        e = FileNotAllowedException("foo.exe")
        assert "foo.exe" in str(e)
        assert "not allowed" in str(e)

    def test_file_not_allowed_inherits_base(self):
        assert issubclass(FileNotAllowedException, BaseFileException)

    def test_file_too_large_message(self):
        e = FileTooLargeException("big.bin", 1024)
        assert "big.bin" in str(e)
        assert "1024" in str(e)


class TestAbstractFileManagerInit:
    def test_requires_base_path(self):
        with pytest.raises(ValueError, match="base_path"):
            StubFileManager()

    def test_base_path_trailing_slash_stripped(self):
        m = StubFileManager(base_path="/tmp/x/")
        assert m.base_path == "/tmp/x"

    def test_constructor_stores_attrs(self):
        m = StubFileManager(
            base_path="/tmp/x",
            allowed_extensions=["png"],
            max_file_size=1000,
        )
        assert m.allowed_extensions == ["png"]
        assert m.max_file_size == 1000

    def test_default_namegen_is_uuid_namegen(self):
        from fastapi_rtk.utils import uuid_namegen

        m = StubFileManager(base_path="/tmp/x")
        assert m.namegen is uuid_namegen

    def test_custom_namegen(self):
        m = StubFileManager(base_path="/tmp/x", namegen=lambda f: f"P_{f}")
        assert m.namegen("a.txt") == "P_a.txt"

    def test_default_permission(self):
        m = StubFileManager(base_path="/tmp/x")
        assert m.permission == 0o755

    def test_custom_permission(self):
        m = StubFileManager(base_path="/tmp/x", permission=0o700)
        assert m.permission == 0o700


class TestIsFilenameAllowed:
    def test_no_extensions_allow_all(self):
        m = StubFileManager(base_path="/tmp/x")
        assert m.is_filename_allowed("anything.xyz") is True

    def test_allowed_extension(self):
        m = StubFileManager(base_path="/tmp/x", allowed_extensions=["png", "jpg"])
        assert m.is_filename_allowed("photo.png") is True

    def test_disallowed_extension(self):
        m = StubFileManager(base_path="/tmp/x", allowed_extensions=["png"])
        assert m.is_filename_allowed("evil.exe") is False

    def test_no_extension_disallowed_when_list_set(self):
        m = StubFileManager(base_path="/tmp/x", allowed_extensions=["png"])
        assert m.is_filename_allowed("noext") is False

    def test_case_insensitive(self):
        m = StubFileManager(base_path="/tmp/x", allowed_extensions=["png"])
        assert m.is_filename_allowed("photo.PNG") is True


class TestIsFileSizeAllowed:
    def test_no_max_allow_all(self):
        m = StubFileManager(base_path="/tmp/x")
        assert m.is_file_size_allowed(10**9) is True

    def test_int_under_limit(self):
        m = StubFileManager(base_path="/tmp/x", max_file_size=100)
        assert m.is_file_size_allowed(50) is True

    def test_int_at_limit(self):
        m = StubFileManager(base_path="/tmp/x", max_file_size=100)
        assert m.is_file_size_allowed(100) is True

    def test_int_over_limit(self):
        m = StubFileManager(base_path="/tmp/x", max_file_size=100)
        assert m.is_file_size_allowed(101) is False

    def test_bytes_size_calculated(self):
        m = StubFileManager(base_path="/tmp/x", max_file_size=10)
        assert m.is_file_size_allowed(b"hello") is True
        assert m.is_file_size_allowed(b"hello world!") is False

    def test_str_size_calculated(self):
        m = StubFileManager(base_path="/tmp/x", max_file_size=5)
        assert m.is_file_size_allowed("ok") is True
        assert m.is_file_size_allowed("toolong") is False

    def test_upload_file_size_attr(self):
        import io

        from fastapi import UploadFile

        m = StubFileManager(base_path="/tmp/x", max_file_size=100)
        uf = UploadFile(file=io.BytesIO(b"hi"), filename="x.txt", size=50)
        assert m.is_file_size_allowed(uf) is True
        uf_big = UploadFile(file=io.BytesIO(b"hi"), filename="x.txt", size=200)
        assert m.is_file_size_allowed(uf_big) is False

    def test_upload_file_no_size_treated_as_zero(self):
        import io

        from fastapi import UploadFile

        m = StubFileManager(base_path="/tmp/x", max_file_size=100)
        uf = UploadFile(file=io.BytesIO(b"hi"), filename="x.txt")
        assert m.is_file_size_allowed(uf) is True


class TestGenerateName:
    def test_uses_namegen(self):
        m = StubFileManager(base_path="/tmp/x", namegen=lambda f: f"X_{f}")
        assert m.generate_name("a.txt") == "X_a.txt"


class TestGetInstanceWithSubfolder:
    def test_returns_new_instance_with_appended_path(self):
        m = StubFileManager(
            base_path="/tmp/x", allowed_extensions=["png"], max_file_size=1000
        )
        sub = m.get_instance_with_subfolder("subdir")
        assert sub is not m
        assert sub.base_path == "/tmp/x/subdir"
        assert sub.allowed_extensions == ["png"]
        assert sub.max_file_size == 1000


class TestSaveFileHooks:
    def test_save_file_rejects_disallowed_extension(self):
        m = StubFileManager(base_path="/tmp/x", allowed_extensions=["png"])
        with pytest.raises(FileNotAllowedException):
            m.save_file(b"data", "evil.exe")

    def test_save_content_rejects_disallowed_extension(self):
        m = StubFileManager(base_path="/tmp/x", allowed_extensions=["png"])
        with pytest.raises(FileNotAllowedException):
            m.save_content_to_file(b"x", "evil.exe")

    def test_save_file_rejects_too_large(self):
        m = StubFileManager(
            base_path="/tmp/x", allowed_extensions=["txt"], max_file_size=2
        )
        with pytest.raises(FileTooLargeException):
            m.save_file(b"abcde", "big.txt")

    def test_save_file_allowed_passes(self):
        m = StubFileManager(base_path="/tmp/x", allowed_extensions=["txt"])
        result = m.save_file(b"x", "ok.txt")
        assert result == "/tmp/x/ok.txt"

    def test_save_file_no_filename_or_data_raises(self):
        """Outer hook (size check) runs first; complains when either is missing."""
        m = StubFileManager(base_path="/tmp/x", allowed_extensions=["txt"])
        with pytest.raises(ValueError, match="filename and file data"):
            m.save_file(b"x", "")

    def test_save_file_no_data_raises(self):
        m = StubFileManager(base_path="/tmp/x", max_file_size=10)
        with pytest.raises(ValueError, match="filename and file data"):
            m.save_file(None, "x.txt")


class TestPostInitHook:
    def test_post_init_called(self):
        called = []

        class Sub(StubFileManager):
            def post_init(self):
                called.append(True)

        Sub(base_path="/tmp/x")
        assert called == [True]


class TestAbstractImageManager:
    def test_inherits_from_file_manager(self):
        assert issubclass(AbstractImageManager, AbstractFileManager)
