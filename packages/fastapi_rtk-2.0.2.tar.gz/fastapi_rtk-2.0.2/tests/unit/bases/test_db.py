from types import SimpleNamespace

import pytest

from fastapi_rtk.bases.db import AbstractQueryBuilder, DBQueryParams
from fastapi_rtk.exceptions import HTTPWithValidationException


class StubInterface:
    """Minimal datamodel stub matching AbstractInterface methods used by AbstractQueryBuilder."""

    def __init__(self, pk_attrs=None, composite=False):
        self._pk_attrs = pk_attrs or ["id"]
        self._composite = composite

    def get_pk_attrs(self):
        return list(self._pk_attrs)

    def get_pk_attr(self):
        return self._pk_attrs[0]

    def is_pk_composite(self):
        return self._composite


class StubQueryBuilder(AbstractQueryBuilder):
    """Concrete AbstractQueryBuilder for orchestration tests. Records calls."""

    statement = "INITIAL"

    def __init__(self, datamodel, statement=None):
        self.calls = []
        super().__init__(datamodel, statement)

    async def apply_list_columns(self, statement, list_columns):
        self.calls.append(("list_columns", list_columns))
        return f"{statement}|cols={list_columns}"

    async def apply_pagination(self, statement, page, page_size):
        self.calls.append(("pagination", page, page_size))
        return f"{statement}|page={page}/{page_size}"

    async def apply_order_by(self, statement, col, direction):
        self.calls.append(("order_by", col, direction))
        return f"{statement}|order={col}-{direction}"

    async def apply_where(self, statement, col, val):
        self.calls.append(("where", col, val))
        return f"{statement}|where={col}={val}"

    async def apply_where_in(self, statement, col, vals):
        self.calls.append(("where_in", col, vals))
        return f"{statement}|wherein={col}={vals}"

    async def apply_filter(self, statement, filter):
        self.calls.append(("filter", filter))
        return f"{statement}|filter"

    async def apply_filter_class(self, statement, col, filter_class, value):
        self.calls.append(("filter_class", col, filter_class, value))
        return f"{statement}|fclass"

    async def apply_opr_filter(self, statement, filter):
        self.calls.append(("opr_filter", filter))
        return f"{statement}|opr"

    async def apply_opr_filter_class(self, statement, filter_class, value):
        self.calls.append(("opr_filter_class", filter_class, value))
        return f"{statement}|oprclass"

    async def apply_global_filter(self, statement, columns, global_filter):
        self.calls.append(("global_filter", columns, global_filter))
        return f"{statement}|global={global_filter}"


class TestDBQueryParams:
    def test_typed_dict_keys(self):
        p = DBQueryParams(
            list_columns=["a"],
            page=1,
            page_size=10,
            order_column=None,
            order_direction=None,
            where=None,
            where_in=None,
            where_id=None,
            where_id_in=None,
            filters=None,
            filter_classes=None,
            opr_filters=None,
            opr_filter_classes=None,
            global_filter=None,
        )
        assert p["list_columns"] == ["a"]
        assert p["page"] == 1


class TestQueryBuilderInit:
    def test_requires_statement(self):
        class NoStatement(StubQueryBuilder):
            statement = None

        with pytest.raises(RuntimeError, match="statement must be provided"):
            NoStatement(datamodel=StubInterface())

    def test_explicit_statement_overrides(self):
        qb = StubQueryBuilder(datamodel=StubInterface(), statement="OVR")
        assert qb.statement == "OVR"

    def test_default_statement_used(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        assert qb.statement == "INITIAL"


@pytest.mark.asyncio
class TestBuildQuery:
    async def test_no_params_returns_initial_statement(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        result = await qb.build_query()
        assert result == "INITIAL"
        assert qb.calls == []

    async def test_list_columns_step_runs(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"list_columns": ["a", "b"]})
        assert qb.calls == [("list_columns", ["a", "b"])]

    async def test_pagination_requires_both_page_and_page_size(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"page": 1})
        assert qb.calls == []

        await qb.build_query({"page": 1, "page_size": 10})
        assert ("pagination", 1, 10) in qb.calls

    async def test_order_by_requires_both(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"order_column": "name", "order_direction": "asc"})
        assert ("order_by", "name", "asc") in qb.calls

    async def test_where_single_tuple_wrapped_to_list(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"where": ("a", 1)})
        assert ("where", "a", 1) in qb.calls

    async def test_where_list_of_tuples(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"where": [("a", 1), ("b", 2)]})
        wheres = [c for c in qb.calls if c[0] == "where"]
        assert wheres == [("where", "a", 1), ("where", "b", 2)]

    async def test_where_in(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"where_in": ("a", [1, 2, 3])})
        assert ("where_in", "a", [1, 2, 3]) in qb.calls

    async def test_filters_dict_converted_to_schema(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"filters": [{"col": "a", "opr": "eq", "value": 1}]})
        assert any(c[0] == "filter" for c in qb.calls)

    async def test_filters_tuple_converted_to_schema(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"filters": [("a", "eq", 1)]})
        assert any(c[0] == "filter" for c in qb.calls)

    async def test_filter_classes(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"filter_classes": [("col", "FILTER_OBJ", 42)]})
        assert ("filter_class", "col", "FILTER_OBJ", 42) in qb.calls

    async def test_opr_filters_dict_converted(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"opr_filters": [{"opr": "eq", "value": 1}]})
        assert any(c[0] == "opr_filter" for c in qb.calls)

    async def test_opr_filters_tuple_converted(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"opr_filters": [("eq", 1)]})
        assert any(c[0] == "opr_filter" for c in qb.calls)

    async def test_opr_filter_classes(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"opr_filter_classes": [("FILTER_OBJ", 42)]})
        assert ("opr_filter_class", "FILTER_OBJ", 42) in qb.calls

    async def test_global_filter(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        await qb.build_query({"global_filter": (["a", "b"], "search")})
        assert ("global_filter", ["a", "b"], "search") in qb.calls

    async def test_unknown_step_raises(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        qb.build_steps = ["bogus"]
        qb._duplicates_removed = False
        with pytest.raises(Exception, match="Unknown build step"):
            await qb.build_query({})

    async def test_duplicate_steps_deduped_once(self):
        qb = StubQueryBuilder(datamodel=StubInterface())
        qb.build_steps = ["list_columns", "list_columns", "where"]
        qb._duplicates_removed = False
        await qb.build_query({"list_columns": ["a"], "where": ("x", 1)})
        list_calls = [c for c in qb.calls if c[0] == "list_columns"]
        assert len(list_calls) == 1


@pytest.mark.asyncio
class TestApplyWhereId:
    async def test_single_pk_calls_where(self):
        qb = StubQueryBuilder(datamodel=StubInterface(pk_attrs=["id"], composite=False))
        await qb.build_query({"where_id": 5})
        assert ("where", "id", 5) in qb.calls

    async def test_composite_pk_string_split(self):
        qb = StubQueryBuilder(
            datamodel=StubInterface(pk_attrs=["a", "b"], composite=True)
        )
        await qb.build_query({"where_id": "1,2"})
        wheres = [c for c in qb.calls if c[0] == "where"]
        assert ("where", "a", "1") in wheres
        assert ("where", "b", "2") in wheres

    async def test_composite_pk_wrong_length_raises(self):
        qb = StubQueryBuilder(
            datamodel=StubInterface(pk_attrs=["a", "b"], composite=True)
        )
        with pytest.raises(HTTPWithValidationException):
            await qb.build_query({"where_id": "1"})

    async def test_composite_pk_invalid_input_raises(self):
        qb = StubQueryBuilder(
            datamodel=StubInterface(pk_attrs=["a", "b"], composite=True)
        )
        with pytest.raises(HTTPWithValidationException):
            await qb.build_query({"where_id": 42})


@pytest.mark.asyncio
class TestApplyWhereIdIn:
    async def test_single_pk_collects_into_list(self):
        qb = StubQueryBuilder(datamodel=StubInterface(pk_attrs=["id"], composite=False))
        await qb.build_query({"where_id_in": [1, 2, 3]})
        in_calls = [c for c in qb.calls if c[0] == "where_in"]
        assert ("where_in", "id", [1, 2, 3]) in in_calls

    async def test_composite_pk_columns_collected(self):
        qb = StubQueryBuilder(
            datamodel=StubInterface(pk_attrs=["a", "b"], composite=True)
        )
        await qb.build_query({"where_id_in": ["1,2", "3,4"]})
        in_calls = [c for c in qb.calls if c[0] == "where_in"]
        # values consumed by .pop(0) -> 1st entry has "1","3", but pop modifies list
        # tracked: ('where_in', 'a', [...]) and ('where_in', 'b', [...])
        cols_seen = {c[1] for c in in_calls}
        assert cols_seen == {"a", "b"}
