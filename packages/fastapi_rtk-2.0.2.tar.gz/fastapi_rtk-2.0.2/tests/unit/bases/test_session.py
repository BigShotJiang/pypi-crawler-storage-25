import abc

from fastapi_rtk.bases.session import AbstractSession


class TestAbstractSession:
    def test_is_abc(self):
        assert issubclass(AbstractSession, abc.ABC)

    def test_cannot_be_used_directly_without_subclass(self):
        """No abstract methods declared, so instantiation succeeds."""
        instance = AbstractSession()
        assert isinstance(instance, AbstractSession)

    def test_subclass_smoke(self):
        class MySession(AbstractSession):
            pass

        s = MySession()
        assert isinstance(s, AbstractSession)
