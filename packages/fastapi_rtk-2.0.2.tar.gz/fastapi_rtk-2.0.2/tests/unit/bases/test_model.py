import pytest

from fastapi_rtk.bases.model import BasicModel


class TestUpdate:
    def test_sets_attributes_from_dict(self):
        m = BasicModel()
        m.update({"a": 1, "b": "x"})
        assert m.a == 1
        assert m.b == "x"

    def test_overwrites_existing(self):
        m = BasicModel()
        m.a = 0
        m.update({"a": 99})
        assert m.a == 99

    def test_empty_dict_is_noop(self):
        m = BasicModel()
        m.update({})
        assert not hasattr(m, "a")


class TestNameProperty:
    def test_returns_str_repr(self):
        class Sub(BasicModel):
            def __str__(self):
                return "i-am-a-thing"

        assert Sub().name_ == "i-am-a-thing"

    def test_default_uses_object_repr(self):
        m = BasicModel()
        assert m.name_ == str(m)


class TestIdProperty:
    def test_single_pk_returns_scalar(self):
        class Sub(BasicModel):
            id = 7

            @classmethod
            def get_pk_attrs(cls):
                return ["id"]

        assert Sub().id_ == "7"

    def test_composite_pk_returns_list(self):
        class Sub(BasicModel):
            a = 1
            b = "x"

            @classmethod
            def get_pk_attrs(cls):
                return ["a", "b"]

        assert Sub().id_ == ["1", "x"]


class TestGetPkAttrs:
    def test_default_raises_not_implemented(self):
        with pytest.raises(NotImplementedError):
            BasicModel.get_pk_attrs()
