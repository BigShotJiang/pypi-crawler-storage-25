import pytest

from fastapi_rtk.bases.interface import AbstractInterface, PydanticGenerationSchema


class TestPydanticGenerationSchema:
    def test_typed_dict_construction(self):
        s = PydanticGenerationSchema(
            __config__={},
            __async_columns__=["x"],
            __columns__=None,
            __with_id__=True,
            __with_name__=True,
            __with_property__=False,
            __optional__=False,
            __hide_sensitive_columns__=True,
            __with_fk__=True,
            __name__=None,
            id_=None,
            name_=None,
        )
        assert s["__with_id__"] is True
        assert s["__async_columns__"] == ["x"]


def _make_concrete_subclass():
    """Build a concrete AbstractInterface subclass implementing all abstract methods with no-op stubs."""

    class Sub(AbstractInterface):
        def get_session_factory(self):
            return None

        async def count(self, session, params=None):
            return 0

        async def get_many(self, session, params=None):
            return []

        async def get_one(self, session, params=None):
            return None

        async def yield_per(self, session, params=None):
            yield

        async def add(self, session, item, **kw):
            return item

        async def edit(self, session, item, **kw):
            return item

        async def delete(self, session, item, **kw):
            return None

        async def commit(self, session):
            return None

        async def close(self, session):
            return None

        def get_add_column_list(self):
            return []

        def get_edit_column_list(self):
            return []

        def get_order_column_list(self, list_columns):
            return list(list_columns)

        def get_search_column_list(self, list_columns):
            return list(list_columns)

        def get_type(self, col):
            return str

        def get_type_name(self, col):
            return "str"

        def get_enum_value(self, col_name):
            return []

        def get_related_model(self, col_name):
            return type(None)

    return Sub


class TestAbstractInterfaceUnsetLazyDescriptors:
    def test_filter_converter_raises(self):
        from fastapi_rtk.exceptions import FastAPIReactToolkitException

        Sub = _make_concrete_subclass()
        sub = Sub(obj=type("M", (), {}))
        with pytest.raises(FastAPIReactToolkitException, match="filter_converter"):
            _ = sub.filter_converter

    def test_global_filter_class_raises(self):
        from fastapi_rtk.exceptions import FastAPIReactToolkitException

        Sub = _make_concrete_subclass()
        sub = Sub(obj=type("M", (), {}))
        with pytest.raises(FastAPIReactToolkitException, match="global_filter_class"):
            _ = sub.global_filter_class

    def test_file_manager_raises(self):
        from fastapi_rtk.exceptions import FastAPIReactToolkitException

        Sub = _make_concrete_subclass()
        sub = Sub(obj=type("M", (), {}))
        with pytest.raises(FastAPIReactToolkitException, match="file_manager"):
            _ = sub.file_manager

    def test_image_manager_raises(self):
        from fastapi_rtk.exceptions import FastAPIReactToolkitException

        Sub = _make_concrete_subclass()
        sub = Sub(obj=type("M", (), {}))
        with pytest.raises(FastAPIReactToolkitException, match="image_manager"):
            _ = sub.image_manager

    def test_obj_and_with_fk_stored(self):
        Sub = _make_concrete_subclass()
        Model = type("Model", (), {})
        sub = Sub(obj=Model, with_fk=False)
        assert sub.obj is Model
        assert sub.with_fk is False

    def test_with_fk_default_true(self):
        Sub = _make_concrete_subclass()
        sub = Sub(obj=type("M", (), {}))
        assert sub.with_fk is True

    def test_aliases_resolve_to_methods(self):
        Sub = _make_concrete_subclass()
        sub = Sub(obj=type("M", (), {}))
        assert sub.all == sub.get_many
        assert sub.first == sub.get_one
        assert sub.create == sub.add
        assert sub.update == sub.edit


class TestCannotInstantiateAbstract:
    def test_missing_abstract_methods_blocks_instantiation(self):
        class Half(AbstractInterface):
            def get_session_factory(self):
                return None

        with pytest.raises(TypeError, match="abstract"):
            Half(obj=type("M", (), {}))


class TestDefaultIsMethodsReturnFalse:
    """Default `return False` shims on the abstract base."""

    def _sub(self):
        Sub = _make_concrete_subclass()
        return Sub(obj=type("M", (), {}))

    @pytest.mark.parametrize(
        "method",
        [
            "is_pk_composite",
            "is_pk",
            "is_fk",
            "is_nullable",
            "is_unique",
            "is_images",
            "is_files",
            "is_image",
            "is_file",
            "is_string",
            "is_text",
            "is_binary",
            "is_integer",
            "is_numeric",
            "is_float",
            "is_boolean",
            "is_date",
            "is_datetime",
            "is_enum",
            "is_json",
            "is_jsonb",
            "is_list",
            "is_relation",
            "is_relation_one_to_one",
            "is_relation_one_to_many",
            "is_relation_many_to_one",
            "is_relation_many_to_many",
        ],
    )
    def test_each_returns_false(self, method):
        sub = self._sub()
        fn = getattr(sub, method)
        # is_pk_composite takes no args; the rest take col_name
        if method == "is_pk_composite":
            assert fn() is False
        else:
            assert fn("any") is False

    def test_get_list_col_type_default(self):
        sub = self._sub()
        assert sub.get_list_col_type("anything") is None

    def test_get_max_length_default(self):
        sub = self._sub()
        assert sub.get_max_length("anything") == -1

    def test_get_min_length_default(self):
        sub = self._sub()
        assert sub.get_min_length("anything") == -1


class TestImplementedHelpers:
    def test_get_file_column_list_default_empty(self):
        Sub = _make_concrete_subclass()
        sub = Sub(obj=type("M", (), {}))
        assert sub.get_file_column_list() == []

    def test_get_image_column_list_default_empty(self):
        Sub = _make_concrete_subclass()
        sub = Sub(obj=type("M", (), {}))
        assert sub.get_image_column_list() == []

    def test_is_property(self):
        Sub = _make_concrete_subclass()

        class M:
            @property
            def name(self):
                return "x"

        sub = Sub(obj=M)
        assert sub.is_property("name") is True
        assert sub.is_property("ghost") is False

    def test_is_function(self):
        Sub = _make_concrete_subclass()

        class M:
            def fn(self):
                return None

        sub = Sub(obj=M)
        assert sub.is_function("fn") is True
        # Bare attribute lookup on missing returns None which has no __call__
        assert sub.is_function("ghost") is False

    def test_get_pk_attr_raises_when_missing(self):
        Sub = _make_concrete_subclass()
        sub = Sub(obj=type("M", (), {}))
        # Override list_columns so the iteration runs but is_pk default False
        sub.list_columns = {"a": None, "b": None}
        with pytest.raises(Exception, match="primary key"):
            sub.get_pk_attr()


@pytest.mark.asyncio
class TestLifespanDefaults:
    async def test_on_startup_default_noop(self):
        Sub = _make_concrete_subclass()
        sub = Sub(obj=type("M", (), {}))
        # Cover lines 689-703 default body
        await sub.on_startup()

    async def test_on_shutdown_default_noop(self):
        Sub = _make_concrete_subclass()
        sub = Sub(obj=type("M", (), {}))
        await sub.on_shutdown()


class TestSqlaCompositePKReportsTrue:
    """Composite primary keys flip is_pk_composite()."""

    def test_composite_pk(self):
        import sqlalchemy

        from fastapi_rtk.backends.sqla.interface import SQLAInterface
        from fastapi_rtk.backends.sqla.model import Model

        class _CompositePKModel(Model):
            __tablename__ = "composite_pk_model_bases"
            __table_args__ = {"extend_existing": True}
            left_id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            right_id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            note = sqlalchemy.Column(sqlalchemy.String(50))

        interface = SQLAInterface(_CompositePKModel)
        assert interface.is_pk_composite() is True
