import pytest

from fastapi_rtk.bases.filter import AbstractBaseFilter, AbstractBaseOprFilter


class TestAbstractBaseFilter:
    def test_cannot_instantiate_without_apply(self):
        with pytest.raises(TypeError):
            AbstractBaseFilter(datamodel=object())

    def test_subclass_with_apply_can_instantiate(self):
        class MyFilter(AbstractBaseFilter):
            name = "my"
            arg_name = "my_arg"

            def apply(self, statement, col, value):
                return statement

        f = MyFilter(datamodel=object())
        assert f.apply("stmt", "col", 1) == "stmt"

    def test_datamodel_stored(self):
        class MyFilter(AbstractBaseFilter):
            name = "n"
            arg_name = "an"

            def apply(self, statement, col, value):
                return statement

        dm = object()
        assert MyFilter(datamodel=dm).datamodel is dm

    def test_is_heavy_default_false(self):
        assert AbstractBaseFilter.is_heavy is False


class TestAbstractBaseOprFilter:
    def test_cannot_instantiate_without_apply(self):
        with pytest.raises(TypeError):
            AbstractBaseOprFilter(datamodel=object())

    def test_subclass_apply_signature_no_col(self):
        class MyOpr(AbstractBaseOprFilter):
            name = "n"
            arg_name = "a"

            def apply(self, statement, value):
                return f"{statement}+{value}"

        f = MyOpr(datamodel=object())
        assert f.apply("stmt", 5) == "stmt+5"

    def test_inherits_from_base_filter(self):
        assert issubclass(AbstractBaseOprFilter, AbstractBaseFilter)
