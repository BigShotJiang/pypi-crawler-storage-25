import pytest

from fastapi_rtk.registry import APIRouteMetadata, APIRouteRegistry


@pytest.fixture(autouse=True)
def clean_registry():
    snapshot = dict(APIRouteRegistry.route_map)
    APIRouteRegistry.route_map.clear()
    yield
    APIRouteRegistry.route_map.clear()
    APIRouteRegistry.route_map.update(snapshot)


class TestGetId:
    def test_id_for_plain_function(self):
        def fn():
            pass

        assert APIRouteRegistry._get_id(fn) == id(fn)

    def test_id_for_bound_method_is_tuple(self):
        class C:
            def m(self):
                pass

        c = C()
        assert APIRouteRegistry._get_id(c.m) == (id(C.m), id(c))


class TestEnsureRoute:
    def test_creates_metadata_when_missing(self):
        def fn():
            pass

        APIRouteRegistry._ensure_route(fn)
        assert id(fn) in APIRouteRegistry.route_map
        assert isinstance(APIRouteRegistry.route_map[id(fn)], dict)

    def test_idempotent(self):
        def fn():
            pass

        APIRouteRegistry._ensure_route(fn)
        APIRouteRegistry.route_map[id(fn)]["permission_name"] = "marker"
        APIRouteRegistry._ensure_route(fn)
        assert APIRouteRegistry.route_map[id(fn)]["permission_name"] == "marker"

    def test_accepts_raw_id(self):
        APIRouteRegistry._ensure_route(12345)
        assert 12345 in APIRouteRegistry.route_map


class TestAddPermissionName:
    def test_sets_permission_name(self):
        def fn():
            pass

        APIRouteRegistry.add_permission_name(fn, "can_read")
        assert APIRouteRegistry.route_map[id(fn)]["permission_name"] == "can_read"

    def test_overwrites_existing(self):
        def fn():
            pass

        APIRouteRegistry.add_permission_name(fn, "first")
        APIRouteRegistry.add_permission_name(fn, "second")
        assert APIRouteRegistry.route_map[id(fn)]["permission_name"] == "second"


class TestAddUrls:
    def test_appends_urls(self):
        def fn():
            pass

        APIRouteRegistry.add_urls(fn, {"path": "/a"}, {"path": "/b"})
        urls = APIRouteRegistry.route_map[id(fn)]["urls"]
        assert urls == [{"path": "/a"}, {"path": "/b"}]

    def test_extends_existing(self):
        def fn():
            pass

        APIRouteRegistry.add_urls(fn, {"path": "/a"})
        APIRouteRegistry.add_urls(fn, {"path": "/b"})
        urls = APIRouteRegistry.route_map[id(fn)]["urls"]
        assert urls == [{"path": "/a"}, {"path": "/b"}]


class TestAddDependencies:
    def test_appends_dependencies(self):
        def fn():
            pass

        dep = (lambda: None, None)
        APIRouteRegistry.add_dependencies(fn, dep)
        deps = APIRouteRegistry.route_map[id(fn)]["dependencies"]
        assert deps == [dep]

    def test_extends_existing(self):
        def fn():
            pass

        d1 = (lambda: None, None)
        d2 = (lambda: None, {"x": 1})
        APIRouteRegistry.add_dependencies(fn, d1)
        APIRouteRegistry.add_dependencies(fn, d2)
        deps = APIRouteRegistry.route_map[id(fn)]["dependencies"]
        assert deps == [d1, d2]


class TestAddPriority:
    def test_sets_priority(self):
        def fn():
            pass

        APIRouteRegistry.add_priority(fn, 5)
        assert APIRouteRegistry.route_map[id(fn)]["priority"] == 5


class TestAddResponseModelStr:
    def test_sets_response_model_str(self):
        def fn():
            pass

        APIRouteRegistry.add_response_model_str(fn, "MyResponse")
        assert APIRouteRegistry.route_map[id(fn)]["response_model_str"] == "MyResponse"


class TestAddIgnoreGlobalUserDependency:
    def test_sets_flag_true(self):
        def fn():
            pass

        APIRouteRegistry.add_ignore_global_user_dependency(fn)
        assert (
            APIRouteRegistry.route_map[id(fn)]["ignore_global_user_dependency"] is True
        )


class TestGetRouteMetadata:
    def test_returns_none_when_unregistered(self):
        def fn():
            pass

        assert APIRouteRegistry.get_route_metadata(fn) is None

    def test_returns_registered_metadata(self):
        def fn():
            pass

        APIRouteRegistry.add_permission_name(fn, "can_x")
        meta = APIRouteRegistry.get_route_metadata(fn)
        assert meta is not None
        assert meta["permission_name"] == "can_x"

    def test_bound_method_falls_back_to_unbound_func_id(self):
        class C:
            def m(self):
                pass

        APIRouteRegistry.add_permission_name(C.m, "class_level")
        c = C()
        meta = APIRouteRegistry.get_route_metadata(c.m)
        assert meta is not None
        assert meta["permission_name"] == "class_level"

    def test_bound_method_combined_id_takes_precedence(self):
        class C:
            def m(self):
                pass

        c = C()
        APIRouteRegistry.add_permission_name(C.m, "class_level")
        APIRouteRegistry.add_permission_name(c.m, "instance_level")
        meta = APIRouteRegistry.get_route_metadata(c.m)
        assert meta["permission_name"] == "instance_level"


class TestAPIRouteMetadataTypedDict:
    def test_keys_present(self):
        meta = APIRouteMetadata(
            urls=[],
            dependencies=[],
            permission_name=None,
            priority=None,
            response_model_str=None,
            ignore_global_user_dependency=None,
        )
        assert set(meta.keys()) == {
            "urls",
            "dependencies",
            "permission_name",
            "priority",
            "response_model_str",
            "ignore_global_user_dependency",
        }
