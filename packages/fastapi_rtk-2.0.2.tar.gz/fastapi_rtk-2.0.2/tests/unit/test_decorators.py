import pytest

from fastapi_rtk.decorators import (
    expose,
    ignore_g_user,
    login_required,
    permission_name,
    priority,
    protect,
    response_model_str,
)
from fastapi_rtk.registry import APIRouteRegistry


@pytest.fixture(autouse=True)
def clean_registry():
    snapshot = dict(APIRouteRegistry.route_map)
    APIRouteRegistry.route_map.clear()
    yield
    APIRouteRegistry.route_map.clear()
    APIRouteRegistry.route_map.update(snapshot)


class TestPermissionName:
    def test_registers_permission_name(self):
        @permission_name("info")
        def f():
            pass

        meta = APIRouteRegistry.get_route_metadata(f)
        assert meta["permission_name"] == "info"

    def test_returns_original_function(self):
        def f():
            pass

        assert permission_name("info")(f) is f


class TestExpose:
    def test_registers_url(self):
        @expose("/foo", methods=["GET", "POST"])
        def f():
            pass

        meta = APIRouteRegistry.get_route_metadata(f)
        urls = meta["urls"]
        assert urls[0]["path"] == "/foo"
        assert sorted(urls[0]["methods"]) == ["GET", "POST"]

    def test_passes_through_kwargs(self):
        @expose("/x", summary="Sum", deprecated=True)
        def f():
            pass

        meta = APIRouteRegistry.get_route_metadata(f)
        assert meta["urls"][0]["summary"] == "Sum"
        assert meta["urls"][0]["deprecated"] is True

    def test_returns_original_function(self):
        def f():
            pass

        assert expose("/p")(f) is f

    def test_multiple_calls_extend_urls(self):
        def f():
            pass

        expose("/a")(f)
        expose("/b")(f)
        meta = APIRouteRegistry.get_route_metadata(f)
        paths = [u["path"] for u in meta["urls"]]
        assert paths == ["/a", "/b"]


class TestLoginRequired:
    def test_registers_dependency(self):
        @login_required
        def f():
            pass

        meta = APIRouteRegistry.get_route_metadata(f)
        assert len(meta["dependencies"]) == 1


class TestProtect:
    def test_callable_form(self):
        @protect()
        def f():
            pass

        meta = APIRouteRegistry.get_route_metadata(f)
        deps = meta["dependencies"]
        assert len(deps) == 1
        # Dependency tuple: (factory, kwargs)
        _factory, kwargs = deps[0]
        assert kwargs["api"] == ":self"
        assert kwargs["permission"] == ":f.permission_name"

    def test_bare_decorator_form(self):
        @protect
        def f():
            pass

        meta = APIRouteRegistry.get_route_metadata(f)
        assert len(meta["dependencies"]) == 1

    def test_returns_original_function_in_callable_form(self):
        def f():
            pass

        assert protect()(f) is f


class TestResponseModelStr:
    def test_registers_response_model_str(self):
        @response_model_str("info_return_schema")
        def f():
            pass

        meta = APIRouteRegistry.get_route_metadata(f)
        assert meta["response_model_str"] == "info_return_schema"


class TestIgnoreGUser:
    def test_sets_flag(self):
        @ignore_g_user
        def f():
            pass

        meta = APIRouteRegistry.get_route_metadata(f)
        assert meta["ignore_global_user_dependency"] is True


class TestPriority:
    def test_sets_priority(self):
        @priority(5)
        def f():
            pass

        meta = APIRouteRegistry.get_route_metadata(f)
        assert meta["priority"] == 5


class TestStackedDecorators:
    def test_full_stack_registers_everything(self):
        @expose("/items", methods=["GET"])
        @protect()
        @permission_name("info")
        @response_model_str("schema")
        @priority(10)
        def f():
            pass

        meta = APIRouteRegistry.get_route_metadata(f)
        assert meta["urls"][0]["path"] == "/items"
        assert meta["permission_name"] == "info"
        assert meta["response_model_str"] == "schema"
        assert meta["priority"] == 10
        assert len(meta["dependencies"]) == 1


class TestRelationshipFilter:
    def test_filter_registers_on_model(self):
        from sqlalchemy.orm import relationship

        from fastapi_rtk.backends.sqla.model import Model
        from fastapi_rtk.decorators import relationship_filter
        import sqlalchemy

        class RFParent2(Model):
            __tablename__ = "rf2_parent"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            name = sqlalchemy.Column(sqlalchemy.String(50))

        class RFChild2(Model):
            __tablename__ = "rf2_child"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            parent_id = sqlalchemy.Column(
                sqlalchemy.Integer, sqlalchemy.ForeignKey("rf2_parent.id")
            )
            parent = relationship("RFParent2")

            @relationship_filter("parent")
            @classmethod
            def only_active_parent(cls):
                return RFParent2.name != ""

        assert "parent" in RFChild2._relationship_filters
        assert "only_active_parent" in RFChild2._relationship_filters["parent"]

    def test_filter_via_attr_introspection(self):
        from sqlalchemy.orm import relationship

        from fastapi_rtk.backends.sqla.model import Model
        from fastapi_rtk.decorators import relationship_filter
        import sqlalchemy

        class RFParent3(Model):
            __tablename__ = "rf3_parent"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            name = sqlalchemy.Column(sqlalchemy.String(50))

        class RFChild3(Model):
            __tablename__ = "rf3_child"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            parent_id = sqlalchemy.Column(
                sqlalchemy.Integer, sqlalchemy.ForeignKey("rf3_parent.id")
            )
            other = relationship("RFParent3")

            # Pass attribute itself (relationship descriptor) to test introspection
            @relationship_filter(other)
            @classmethod
            def only_named(cls):
                return RFParent3.name != ""

        assert "other" in RFChild3._relationship_filters


class TestDocsDecorator:
    def test_attaches_documentation_to_model(self):
        from fastapi_rtk.backends.sqla.model import Model
        from fastapi_rtk.cli.commands.export import table_documentation
        from fastapi_rtk.decorators import docs
        import sqlalchemy

        @docs(description="my table", data={"col1": "first column"})
        class DocModel(Model):
            __tablename__ = "doc_model_test"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            col1 = sqlalchemy.Column(sqlalchemy.String(50))

        assert table_documentation["doc_model_test"]["description"] == "my table"
        assert table_documentation["doc_model_test"]["columns"]["col1"] == "first column"

    def test_rejects_non_model_class(self):
        from fastapi_rtk.decorators import docs

        with pytest.raises(TypeError, match="can only be used on classes"):
            @docs(description="x")
            class NotAModel:
                pass

    def test_docs_on_sa_table(self):
        # Line 410: SA_Table branch — uses table.name instead of __tablename__
        from sqlalchemy import Column, Integer, MetaData, String
        from sqlalchemy import Table as SA_Table

        from fastapi_rtk.cli.commands.export import table_documentation
        from fastapi_rtk.decorators import docs

        metadata = MetaData()
        table = SA_Table(
            "my_doc_table",
            metadata,
            Column("id", Integer, primary_key=True),
            Column("name", String(20)),
        )
        decorated = docs(description="Coverage doc", data={"name": "Name col"})(table)
        assert decorated is table
        assert table_documentation["my_doc_table"]["description"] == "Coverage doc"
