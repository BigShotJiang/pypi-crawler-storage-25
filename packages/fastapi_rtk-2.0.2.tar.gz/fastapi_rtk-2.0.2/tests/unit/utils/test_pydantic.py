import typing
from typing import NotRequired

import pydantic
import pytest
from fastapi_rtk.utils.pydantic import (
    _get_list_of_singular_type,
    generate_schema_from_typed_dict,
    get_pydantic_model_field,
)


class TestGenerateSchemaFromTypedDict:
    def test_simple_typed_dict(self):
        class SimpleDict(typing.TypedDict):
            name: str
            age: int

        model = generate_schema_from_typed_dict(SimpleDict)
        assert issubclass(model, pydantic.BaseModel)
        assert model.__name__ == "SimpleDict"
        assert "name" in model.model_fields
        assert "age" in model.model_fields
        assert model.model_fields["name"].is_required()
        assert model.model_fields["age"].is_required()

    def test_typed_dict_with_not_required(self):
        class OptionalDict(typing.TypedDict):
            required_field: str
            optional_field: NotRequired[int]

        model = generate_schema_from_typed_dict(OptionalDict)
        assert model.model_fields["required_field"].is_required()
        assert not model.model_fields["optional_field"].is_required()

    def test_typed_dict_with_complex_types(self):
        class ComplexDict(typing.TypedDict):
            items: list[str]
            mapping: dict[str, int]

        model = generate_schema_from_typed_dict(ComplexDict)
        instance = model(items=["a", "b"], mapping={"x": 1})
        assert instance.items == ["a", "b"]
        assert instance.mapping == {"x": 1}

    def test_invalid_input_not_a_type(self):
        with pytest.raises(
            TypeError, match="typed_dict must be a type that is a subclass of dict"
        ):
            generate_schema_from_typed_dict("not a type")

    def test_invalid_input_not_dict_subclass(self):
        with pytest.raises(
            TypeError, match="typed_dict must be a type that is a subclass of dict"
        ):
            generate_schema_from_typed_dict(str)


class TestGetPydanticModelField:
    def test_simple_model_field(self):
        class NestedModel(pydantic.BaseModel):
            value: str

        class OuterModel(pydantic.BaseModel):
            nested: NestedModel

        result = get_pydantic_model_field(OuterModel, "nested")
        assert result == NestedModel

    def test_list_of_models_field(self):
        class ItemModel(pydantic.BaseModel):
            name: str

        class ContainerModel(pydantic.BaseModel):
            items: list[ItemModel]

        result = get_pydantic_model_field(ContainerModel, "items")
        assert result == ItemModel

    def test_optional_model_field(self):
        class NestedModel(pydantic.BaseModel):
            value: str

        class OuterModel(pydantic.BaseModel):
            nested: typing.Optional[NestedModel]

        result = get_pydantic_model_field(OuterModel, "nested")
        assert result == NestedModel

    def test_non_model_field(self):
        class SimpleModel(pydantic.BaseModel):
            text: str

        result = get_pydantic_model_field(SimpleModel, "text")
        assert result is None

    def test_union_with_model(self):
        class ModelA(pydantic.BaseModel):
            a: str

        class ModelB(pydantic.BaseModel):
            b: int

        class UnionModel(pydantic.BaseModel):
            field: typing.Union[ModelA, str]

        result = get_pydantic_model_field(UnionModel, "field")
        assert result == ModelA


class TestGetListOfSingularType:
    def test_simple_type(self):
        result = _get_list_of_singular_type(str)
        assert result == [str]

    def test_list_type(self):
        result = _get_list_of_singular_type(list[str])
        assert result == [str]

    def test_union_type(self):
        result = _get_list_of_singular_type(typing.Union[str, int])
        assert set(result) == {str, int}

    def test_nested_generic_types(self):
        result = _get_list_of_singular_type(list[typing.Union[str, int]])
        assert set(result) == {str, int}

    def test_optional_type(self):
        result = _get_list_of_singular_type(typing.Optional[str])
        assert set(result) == {str, type(None)}

    def test_complex_nested_structure(self):
        complex_type = typing.Union[list[str], dict[str, int], typing.Optional[bool]]
        result = _get_list_of_singular_type(complex_type)
        assert str in result
        assert int in result
        assert bool in result
        assert type(None) in result
