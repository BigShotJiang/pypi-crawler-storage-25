from fastapi_rtk.utils.class_factory import class_factory_from_dict


def test_class_factory_basic_creation():
    """Test basic class creation with default parameters."""
    TestClass = class_factory_from_dict("TestClass")
    assert TestClass.__name__ == "TestClass"
    assert TestClass.__bases__ == (object,)


def test_class_factory_with_attributes():
    """Test class creation with custom attributes."""
    TestClass = class_factory_from_dict(
        "TestClass", attr1="value1", attr2=42, attr3=lambda x: x * 2
    )
    assert TestClass.attr1 == "value1"
    assert TestClass.attr2 == 42
    assert TestClass.attr3(5) == 10


def test_class_factory_with_methods():
    """Test class creation with methods."""

    def greet(self, name):
        return f"Hello, {name}!"

    TestClass = class_factory_from_dict("TestClass", greet=greet)
    instance = TestClass()
    assert instance.greet("World") == "Hello, World!"


def test_class_factory_with_custom_base_class():
    """Test class creation with custom base classes."""

    class BaseClass:
        base_attr = "base_value"

    TestClass = class_factory_from_dict(
        "TestClass", base_classes=(BaseClass,), custom_attr="custom_value"
    )
    assert issubclass(TestClass, BaseClass)
    assert TestClass.base_attr == "base_value"
    assert TestClass.custom_attr == "custom_value"


def test_class_factory_with_multiple_base_classes():
    """Test class creation with multiple base classes."""

    class Base1:
        attr1 = "value1"

    class Base2:
        attr2 = "value2"

    TestClass = class_factory_from_dict(
        "TestClass", base_classes=(Base1, Base2), attr3="value3"
    )
    assert issubclass(TestClass, Base1)
    assert issubclass(TestClass, Base2)
    assert TestClass.attr1 == "value1"
    assert TestClass.attr2 == "value2"
    assert TestClass.attr3 == "value3"


def test_class_factory_instantiation():
    """Test that created classes can be instantiated."""
    TestClass = class_factory_from_dict("TestClass", x=10, y=20)
    instance = TestClass()
    assert isinstance(instance, TestClass)
    assert instance.x == 10
    assert instance.y == 20


def test_class_factory_with_init_method():
    """Test class creation with custom __init__ method."""

    def __init__(self, value):
        self.value = value

    TestClass = class_factory_from_dict("TestClass", __init__=__init__)
    instance = TestClass(42)
    assert instance.value == 42


def test_class_factory_with_special_methods():
    """Test class creation with special methods like __str__."""

    def __str__(self):
        return "CustomString"

    TestClass = class_factory_from_dict("TestClass", __str__=__str__)
    instance = TestClass()
    assert str(instance) == "CustomString"


def test_class_factory_empty_kwargs():
    """Test class creation with no additional attributes."""
    TestClass = class_factory_from_dict("TestClass", base_classes=(object,))
    assert TestClass.__name__ == "TestClass"
    assert TestClass.__bases__ == (object,)


def test_class_factory_with_various_types():
    """Test class creation with various attribute types."""
    TestClass = class_factory_from_dict(
        "TestClass",
        string_attr="test",
        int_attr=123,
        float_attr=45.67,
        list_attr=[1, 2, 3],
        dict_attr={"key": "value"},
        bool_attr=True,
        none_attr=None,
    )
    assert TestClass.string_attr == "test"
    assert TestClass.int_attr == 123
    assert TestClass.float_attr == 45.67
    assert TestClass.list_attr == [1, 2, 3]
    assert TestClass.dict_attr == {"key": "value"}
    assert TestClass.bool_attr is True
    assert TestClass.none_attr is None
