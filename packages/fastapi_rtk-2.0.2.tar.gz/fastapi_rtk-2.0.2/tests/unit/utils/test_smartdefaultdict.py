import pytest
from fastapi_rtk.utils.smartdefaultdict import smartdefaultdict


class TestSmartDefaultDict:
    def test_initialization_with_callable(self):
        """Test that smartdefaultdict can be initialized with a callable."""
        sdd = smartdefaultdict(lambda key: f"default_{key}")
        assert sdd.default_factory is not None

    def test_initialization_with_none(self):
        """Test that smartdefaultdict can be initialized with None."""
        sdd = smartdefaultdict(None)
        assert sdd.default_factory is None

    def test_missing_key_calls_factory_with_key(self):
        """Test that accessing a missing key calls default_factory with the key."""
        sdd = smartdefaultdict(lambda key: f"value_for_{key}")
        result = sdd["test_key"]
        assert result == "value_for_test_key"

    def test_multiple_missing_keys(self):
        """Test that multiple missing keys get different values based on key."""
        sdd = smartdefaultdict(lambda key: key * 2)
        assert sdd[5] == 10
        assert sdd[3] == 6
        assert sdd[7] == 14

    def test_existing_key_not_overwritten(self):
        """Test that existing keys are not overwritten by default_factory."""
        sdd = smartdefaultdict(lambda key: f"default_{key}")
        sdd["key1"] = "custom_value"
        assert sdd["key1"] == "custom_value"

    def test_key_stored_after_first_access(self):
        """Test that the key-value pair is stored after first access."""
        call_count = []

        def factory(key):
            call_count.append(key)
            return f"value_{key}"

        sdd = smartdefaultdict(factory)
        _ = sdd["test"]
        _ = sdd["test"]  # Second access should not call factory
        assert len(call_count) == 1

    def test_with_complex_objects_as_keys(self):
        """Test smartdefaultdict with tuple keys."""
        sdd = smartdefaultdict(lambda key: list(key))
        result = sdd[(1, 2, 3)]
        assert result == [1, 2, 3]

    def test_with_list_factory(self):
        """Test creating lists based on key length."""
        sdd = smartdefaultdict(lambda key: [0] * len(key))
        assert sdd["abc"] == [0, 0, 0]
        assert sdd["x"] == [0]

    def test_none_factory_raises_error(self):
        """Test that None factory raises TypeError on missing key."""
        sdd = smartdefaultdict(None)
        with pytest.raises(TypeError):
            _ = sdd["missing_key"]

    def test_len_and_keys(self):
        """Test that len and keys work correctly."""
        sdd = smartdefaultdict(lambda key: key.upper())
        _ = sdd["a"]
        _ = sdd["b"]
        assert len(sdd) == 2
        assert set(sdd.keys()) == {"a", "b"}

    def test_get_method(self):
        """Test the get method behavior."""
        sdd = smartdefaultdict(lambda key: f"default_{key}")
        assert sdd.get("missing") is None
        assert sdd.get("missing", "fallback") == "fallback"

    def test_setdefault_method(self):
        """Test setdefault method."""
        sdd = smartdefaultdict(lambda key: f"default_{key}")
        result = sdd.setdefault("key1", "custom")
        assert result == "custom"
        assert sdd["key1"] == "custom"

    def test_inheritance_from_defaultdict(self):
        """Test that smartdefaultdict inherits from defaultdict."""
        sdd = smartdefaultdict(lambda key: key)
        assert isinstance(sdd, smartdefaultdict)
        assert isinstance(sdd, dict)
