from fastapi_rtk.utils.formatter import format_file_size, prettify_dict, prettify_list


class TestPrettifyDict:
    def test_empty_dict(self):
        result = prettify_dict({})
        assert result == ""

    def test_simple_dict(self):
        d = {"name": "John", "age": 30}
        result = prettify_dict(d)
        assert "name: John\n" in result
        assert "age: 30\n" in result

    def test_nested_dict(self):
        d = {"user": {"name": "John", "age": 30}}
        result = prettify_dict(d)
        assert "user:\n" in result
        assert "  name: John\n" in result
        assert "  age: 30\n" in result

    def test_deeply_nested_dict(self):
        d = {"level1": {"level2": {"level3": "value"}}}
        result = prettify_dict(d)
        assert "level1:\n" in result
        assert "  level2:\n" in result
        assert "    level3: value\n" in result

    def test_mixed_values(self):
        d = {"string": "text", "number": 42, "boolean": True, "none": None}
        result = prettify_dict(d)
        assert "string: text\n" in result
        assert "number: 42\n" in result
        assert "boolean: True\n" in result
        assert "none: None\n" in result

    def test_custom_indent(self):
        d = {"key": "value"}
        result = prettify_dict(d, indent=4)
        assert result == "    key: value\n"

    def test_dict_with_list_value(self):
        d = {"items": ["a", "b"]}
        result = prettify_dict(d)
        assert result == "items:\n  - a\n  - b\n"


class TestPrettifyList:
    def test_empty_list(self):
        assert prettify_list([]) == ""

    def test_scalar_items(self):
        assert prettify_list(["a", "b", 1]) == "- a\n- b\n- 1\n"

    def test_list_with_dict_item(self):
        result = prettify_list([{"k": "v"}])
        assert result == "- k: v\n"

    def test_list_with_nested_list(self):
        result = prettify_list([["a", "b"]])
        assert result == "- - a\n  - b\n"

    def test_list_with_mixed_items(self):
        result = prettify_list(["x", {"k": "v"}, ["a"]])
        assert "- x\n" in result
        assert "- k: v\n" in result
        assert "- - a\n" in result


class TestFormatFileSize:
    def test_zero_bytes(self):
        assert format_file_size(0) == "0B"

    def test_bytes(self):
        assert format_file_size(500) == "500 B"
        assert format_file_size(1023) == "1023 B"

    def test_kilobytes(self):
        assert format_file_size(1024) == "1 KB"
        assert format_file_size(1536) == "1.5 KB"
        assert format_file_size(2048) == "2 KB"

    def test_megabytes(self):
        assert format_file_size(1048576) == "1 MB"
        assert format_file_size(1572864) == "1.5 MB"
        assert format_file_size(5242880) == "5 MB"

    def test_gigabytes(self):
        assert format_file_size(1073741824) == "1 GB"
        assert format_file_size(2147483648) == "2 GB"

    def test_terabytes(self):
        assert format_file_size(1099511627776) == "1 TB"

    def test_rounding(self):
        assert format_file_size(1234567) == "1.18 MB"
        assert format_file_size(123456789) == "117.74 MB"

    def test_integer_results(self):
        # Should return integer when result is whole number
        result = format_file_size(2048)
        assert result == "2 KB"
        assert "2.0" not in result
