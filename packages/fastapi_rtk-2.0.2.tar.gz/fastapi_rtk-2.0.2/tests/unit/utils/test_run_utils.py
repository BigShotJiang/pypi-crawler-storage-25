import asyncio
import contextvars

import pytest
from fastapi_rtk.utils.run_utils import (
    call_with_valid_kwargs,
    parse_from_values_or_func,
    run_coroutine_in_threadpool,
    run_function_in_threadpool,
    safe_call,
    safe_call_sync,
    smart_run,
    smart_run_sync,
)


class TestSmartRun:
    @pytest.mark.asyncio
    async def test_smart_run_with_async_function(self):
        async def async_func(x, y):
            return x + y

        result = await smart_run(async_func, 1, 2)
        assert result == 3

    @pytest.mark.asyncio
    async def test_smart_run_with_sync_function(self):
        def sync_func(x, y):
            return x * y

        result = await smart_run(sync_func, 3, 4)
        assert result == 12

    @pytest.mark.asyncio
    async def test_smart_run_with_kwargs(self):
        async def async_func(a, b=10):
            return a + b

        result = await smart_run(async_func, 5, b=20)
        assert result == 25

    @pytest.mark.asyncio
    async def test_smart_run_with_contextvars(self):
        var = contextvars.ContextVar("test_var", default="default")

        async def async_func():
            return var.get()

        result = await smart_run(async_func)
        assert result == "default"

        var.set("new value")
        result = await smart_run(async_func)
        assert result == "new value"


class TestSmartRunSync:
    def test_smart_run_sync_with_async_function(self):
        async def async_func(x):
            await asyncio.sleep(0.01)
            return x * 2

        result = smart_run_sync(async_func, 5)
        assert result == 10

    def test_smart_run_sync_with_sync_function(self):
        def sync_func(x):
            return x + 10

        result = smart_run_sync(sync_func, 5)
        assert result == 15

    def test_smart_run_sync_with_kwargs(self):
        def sync_func(a, b=5):
            return a - b

        result = smart_run_sync(sync_func, 10, b=3)
        assert result == 7

    def test_smart_run_sync_with_contextvars(self):
        var = contextvars.ContextVar("test_var", default="default")

        async def async_func():
            return var.get()

        result = smart_run_sync(async_func)
        assert result == "default"

        var.set("new value")
        result = smart_run_sync(async_func)
        assert result == "new value"


class TestSafeCall:
    @pytest.mark.asyncio
    async def test_safe_call_with_coroutine(self):
        async def async_func():
            return "async result"

        result = await safe_call(async_func())
        assert result == "async result"

    @pytest.mark.asyncio
    async def test_safe_call_with_non_coroutine(self):
        result = await safe_call("direct value")
        assert result == "direct value"

    @pytest.mark.asyncio
    async def test_safe_call_with_number(self):
        result = await safe_call(42)
        assert result == 42

    @pytest.mark.asyncio
    async def test_safe_call_with_none(self):
        result = await safe_call(None)
        assert result is None

    @pytest.mark.asyncio
    async def test_safe_call_with_contextvars(self):
        var = contextvars.ContextVar("test_var", default="default")

        async def async_func():
            return var.get()

        result = await safe_call(async_func())
        assert result == "default"

        var.set("new value")
        result = await safe_call(async_func())
        assert result == "new value"


class TestSafeCallSync:
    def test_safe_call_sync_with_coroutine(self):
        async def async_func():
            await asyncio.sleep(0.01)
            return "async result"

        result = safe_call_sync(async_func())
        assert result == "async result"

    def test_safe_call_sync_with_direct_value(self):
        result = safe_call_sync("direct value")
        assert result == "direct value"

    def test_safe_call_sync_with_max_workers(self):
        async def async_func():
            return "result"

        result = safe_call_sync(async_func(), max_workers=2)
        assert result == "result"

    def test_safe_call_sync_with_contextvars(self):
        var = contextvars.ContextVar("test_var", default="default")

        async def async_func():
            return var.get()

        result = safe_call_sync(async_func())
        assert result == "default"

        var.set("new value")
        result = safe_call_sync(async_func())
        assert result == "new value"


class TestRunCoroutineInThreadpool:
    def test_run_coroutine_in_threadpool(self):
        async def async_func(x, y):
            await asyncio.sleep(0.01)
            return x + y

        result = run_coroutine_in_threadpool(async_func(10, 20))
        assert result == 30

    def test_run_coroutine_in_threadpool_with_max_workers(self):
        async def async_func():
            return "result"

        result = run_coroutine_in_threadpool(async_func(), max_workers=2)
        assert result == "result"

    def test_run_coroutine_in_threadpool_with_contextvars(self):
        var = contextvars.ContextVar("test_var", default="default")

        async def async_func():
            return var.get()

        result = run_coroutine_in_threadpool(async_func())
        assert result == "default"

        var.set("new value")
        result = run_coroutine_in_threadpool(async_func())
        assert result == "new value"


class TestRunFunctionInThreadpool:
    def test_run_function_in_threadpool(self):
        def sync_func(x):
            return x * 2

        result = run_function_in_threadpool(sync_func, 5)
        assert result == 10

    def test_run_function_in_threadpool_with_kwargs(self):
        def sync_func(a, b):
            return a + b

        result = run_function_in_threadpool(sync_func, 3, b=7)
        assert result == 10

    def test_run_function_in_threadpool_with_max_workers(self):
        def sync_func(x):
            return x**2

        result = run_function_in_threadpool(sync_func, 4, max_workers=2)
        assert result == 16

    def test_run_function_in_threadpool_with_thread_pool_kwargs(self):
        def sync_func(x):
            return x + 1

        result = run_function_in_threadpool(
            sync_func,
            5,
            max_workers=1,
            thread_pool_kwargs={"thread_name_prefix": "test"},
        )
        assert result == 6

    def test_run_function_in_threadpool_with_contextvars(self):
        var = contextvars.ContextVar("test_var", default="default")

        def sync_func():
            return var.get()

        result = run_function_in_threadpool(sync_func)
        assert result == "default"

        var.set("new value")
        result = run_function_in_threadpool(sync_func)
        assert result == "new value"


class TestCallWithValidKwargs:
    def test_call_with_valid_kwargs_all_params_present(self):
        def func(a, b, c=3):
            return a + b + c

        params = {"a": 1, "b": 2, "c": 5}
        result = call_with_valid_kwargs(func, params)
        assert result == 8

    def test_call_with_valid_kwargs_extra_params(self):
        def func(a, b):
            return a * b

        params = {"a": 3, "b": 4, "extra": 100}
        result = call_with_valid_kwargs(func, params)
        assert result == 12

    def test_call_with_valid_kwargs_with_defaults(self):
        def func(a, b=10):
            return a + b

        params = {"a": 5}
        result = call_with_valid_kwargs(func, params)
        assert result == 15

    def test_call_with_valid_kwargs_missing_required_param(self):
        def func(a, b):
            return a + b

        params = {"a": 1}
        with pytest.raises(ValueError, match="Missing required parameter `b`"):
            call_with_valid_kwargs(func, params)

    def test_call_with_valid_kwargs_no_params(self):
        def func():
            return "no params"

        params = {}
        result = call_with_valid_kwargs(func, params)
        assert result == "no params"

    def test_call_with_valid_kwargs_missing_multiple_required_params(self):
        def func(a, b, c):
            return a + b + c

        params = {"a": 1}
        with pytest.raises(ValueError, match="Missing required parameter `b`"):
            call_with_valid_kwargs(func, params)


class TestParseFromValuesOrFunc:
    def test_returns_value_when_not_callable(self):
        assert parse_from_values_or_func(42) == 42
        assert parse_from_values_or_func("hello") == "hello"
        assert parse_from_values_or_func(None) is None
        assert parse_from_values_or_func({"a": 1}) == {"a": 1}

    def test_calls_function_with_no_args(self):
        assert parse_from_values_or_func(lambda: "result") == "result"

    def test_calls_function_with_positional_args(self):
        assert parse_from_values_or_func(lambda a, b: a + b, 1, 2) == 3

    def test_calls_function_with_kwargs(self):
        def fn(a, b=10):
            return a * b

        assert parse_from_values_or_func(fn, 3, b=4) == 12

    def test_calls_function_with_mixed_args(self):
        def fn(a, b, c=0):
            return a + b + c

        assert parse_from_values_or_func(fn, 1, 2, c=3) == 6
