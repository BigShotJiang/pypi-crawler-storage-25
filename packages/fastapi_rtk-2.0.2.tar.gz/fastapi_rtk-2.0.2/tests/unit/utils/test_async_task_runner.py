import asyncio
from unittest.mock import patch

import pytest
from fastapi_rtk.globals import g
from fastapi_rtk.setting import Setting
from fastapi_rtk.utils.async_task_runner import (
    AsyncTask,
    AsyncTaskException,
    AsyncTaskRunner,
    AsyncTaskRunnerException,
    CallerInfo,
    DuplicateRunnerIDException,
)
from fastapi_rtk.utils.formatter import prettify_dict


class TestAsyncTaskRunner:
    """Test suite for AsyncTaskRunner class."""

    @pytest.mark.asyncio
    async def test_basic_task_execution(self):
        """Test that a simple task is executed when exiting context."""
        result = []

        async def simple_task():
            result.append("executed")

        async with AsyncTaskRunner():
            AsyncTaskRunner.add_task(simple_task)

        assert result == ["executed"]

    @pytest.mark.asyncio
    async def test_multiple_tasks_execution(self):
        """Test that multiple tasks are executed in order."""
        results = []

        async def task1():
            results.append(1)

        async def task2():
            results.append(2)

        async def task3():
            results.append(3)

        async with AsyncTaskRunner():
            AsyncTaskRunner.add_task(task1, task2, task3)

        assert results == [1, 2, 3]

    @pytest.mark.asyncio
    async def test_nested_contexts(self):
        """Test nested AsyncTaskRunner contexts."""
        results = []

        async def outer_task():
            results.append("outer")

        async def inner_task():
            results.append("inner")

        async with AsyncTaskRunner() as outer:
            outer.add_task(outer_task)
            async with AsyncTaskRunner() as inner:
                inner.add_task(inner_task)
            # Inner task should execute before outer
        assert results == ["inner", "outer"]

    @pytest.mark.asyncio
    async def test_nested_context_stack_management(self):
        """Test that nested contexts properly manage parent/child relationships."""
        async with AsyncTaskRunner(id="outer") as outer:
            assert outer.parent is None
            assert outer.child is None

            async with AsyncTaskRunner(id="middle") as middle:
                assert middle.parent is outer
                assert outer.child is middle
                assert middle.child is None

                async with AsyncTaskRunner(id="inner") as inner:
                    assert inner.parent is middle
                    assert middle.child is inner
                    assert inner.child is None

                # After inner exits
                assert middle.child is inner
                assert middle.parent is outer

            # After middle exits
            assert outer.child is middle

    @pytest.mark.asyncio
    async def test_task_with_return_value(self):
        """Test task that returns a value."""

        async def task_with_value():
            return 42

        async with AsyncTaskRunner():
            task = AsyncTaskRunner.add_task(task_with_value)
            # Task hasn't run yet
            with pytest.raises(RuntimeError, match="has not been executed yet"):
                _ = task.result._ensure_result()

        # After context exit, result should be available
        assert await task.result == 42

    @pytest.mark.asyncio
    async def test_single_task_return_not_list(self):
        """Test that adding a single task returns AsyncTask, not a list."""

        async def single_task():
            return "result"

        async with AsyncTaskRunner():
            task = AsyncTaskRunner.add_task(single_task)
            # Should return AsyncTask, not list
            assert isinstance(task, AsyncTask)
            assert not isinstance(task, list)

    @pytest.mark.asyncio
    async def test_multiple_tasks_return_list(self):
        """Test that adding multiple tasks returns a list of AsyncTask."""

        async def task1():
            return 1

        async def task2():
            return 2

        async with AsyncTaskRunner():
            tasks = AsyncTaskRunner.add_task(task1, task2)
            # Should return list
            assert isinstance(tasks, list)
            assert len(tasks) == 2
            assert all(isinstance(t, AsyncTask) for t in tasks)

    @pytest.mark.asyncio
    async def test_multiple_tasks_with_same_tags(self):
        """Test that multiple tasks can share the same tags."""
        results = []

        async def task1():
            results.append(1)

        async def task2():
            results.append(2)

        async with AsyncTaskRunner():
            AsyncTaskRunner.add_task(task1, task2, tags=["shared"])

        assert results == [1, 2]

    @pytest.mark.asyncio
    async def test_task_exception_handling(self):
        """Test that task exceptions are properly wrapped."""

        async def failing_task():
            raise ValueError("Task failed")

        with pytest.raises(AsyncTaskRunnerException, match="One or more tasks failed"):
            async with AsyncTaskRunner():
                AsyncTaskRunner.add_task(failing_task)

    @pytest.mark.asyncio
    async def test_task_exception_contains_caller_info(self):
        """Test that exceptions include caller information."""

        async def failing_task():
            raise ValueError("Task failed")

        try:
            async with AsyncTaskRunner():
                AsyncTaskRunner.add_task(failing_task)
        except AsyncTaskRunnerException as e:
            error_msg = str(e)
            assert "caller" in error_msg.lower()
            assert "traceback" in error_msg.lower()

    @pytest.mark.asyncio
    async def test_task_exception_with_caller_none(self):
        """Test AsyncTaskException can be created with caller=None."""
        exc = AsyncTaskException(
            "Test error", original_exception=ValueError("Original"), caller=None
        )
        assert exc.original_exception is not None
        assert exc.caller is None

    @pytest.mark.asyncio
    async def test_multiple_task_exceptions(self):
        """Test handling of multiple failing tasks."""

        async def task1():
            raise ValueError("Task 1 failed")

        async def task2():
            raise RuntimeError("Task 2 failed")

        with pytest.raises(AsyncTaskRunnerException) as exc_info:
            async with AsyncTaskRunner():
                AsyncTaskRunner.add_task(task1, task2)

        error_msg = str(exc_info.value)
        assert "Task 1 failed" in error_msg
        assert "Task 2 failed" in error_msg

    @pytest.mark.asyncio
    async def test_run_tasks_even_if_exception_false(self):
        """Test that tasks don't run if context exception occurs (default behavior)."""
        results = []

        async def task():
            results.append("executed")

        with pytest.raises(RuntimeError, match="Context error"):
            async with AsyncTaskRunner():
                AsyncTaskRunner.add_task(task)
                raise RuntimeError("Context error")

        assert results == []

    @pytest.mark.asyncio
    async def test_run_tasks_even_if_exception_true(self):
        """Test that tasks run even if context exception occurs."""
        results = []

        async def task():
            results.append("executed")

        with pytest.raises(RuntimeError, match="Context error"):
            async with AsyncTaskRunner(run_tasks_even_if_exception=True):
                AsyncTaskRunner.add_task(task)
                raise RuntimeError("Context error")

        assert results == ["executed"]

    @pytest.mark.asyncio
    async def test_custom_runner_id(self):
        """Test creating runner with custom ID."""
        async with AsyncTaskRunner(id="custom-id") as runner:
            assert runner.id == "custom-id"

    @pytest.mark.asyncio
    async def test_duplicate_runner_id_raises_exception(self):
        """Test that duplicate runner IDs raise an exception."""
        with pytest.raises(DuplicateRunnerIDException):
            async with AsyncTaskRunner(id="duplicate-id"):
                async with AsyncTaskRunner(id="duplicate-id"):
                    pass

    @pytest.mark.asyncio
    async def test_get_current_runner(self):
        """Test retrieving current runner from context."""
        async with AsyncTaskRunner() as runner:
            current = AsyncTaskRunner.get_current_runner()
            assert current is runner

    @pytest.mark.asyncio
    async def test_get_current_runner_outside_context(self):
        """Test that getting current runner outside context raises error."""

        def mock_on_exit(self):
            """
            Mock logic to run when exiting the context. Used to test when somehow the stack is an empty list and current runner can not be found.

            - Removes this instance from the runner stack (regardless of position).
            - If this is the last instance, resets the context variable to clean up.
            """

            stack = self._get_current_stack("_on_exit")

            try:
                stack.remove(self)
            except ValueError:
                raise RuntimeError(
                    prettify_dict(
                        {
                            "message": "Runner instance not found in stack.",
                            "runner": self,
                            "current_stack": stack,
                            "possible_causes": [
                                "Instance was already removed from the stack.",
                                "Instance was never added to the stack.",
                            ],
                            "suggestions": [
                                "Ensure that the context manager is used correctly.",
                                "Check for nested contexts and their management.",
                            ],
                        }
                    )
                )

            # Last one out cleans up - reset context var if stack is now empty
            if not stack:
                # Assume something went wrong and stack was not set to None
                # self._stack.set(None)
                pass

        with patch.object(AsyncTaskRunner, "_on_exit", new=mock_on_exit):
            # Now we can trigger the condition where the stack is empty and current runner cannot be found
            with pytest.raises(
                RuntimeError,
                match="This error can only occurs when the stack is an empty list",
            ):
                async with AsyncTaskRunner():
                    pass
                AsyncTaskRunner.get_current_runner()

    @pytest.mark.asyncio
    async def test_get_runner_by_id(self):
        """Test retrieving runner by ID."""
        async with AsyncTaskRunner(id="test-id") as runner:
            found = AsyncTaskRunner.get_runner("test-id")
            assert found is runner

    @pytest.mark.asyncio
    async def test_get_runner_by_id_not_found(self):
        """Test that getting non-existent runner by ID raises error."""
        async with AsyncTaskRunner():
            with pytest.raises(ValueError, match="No AsyncTaskRunner with id"):
                AsyncTaskRunner.get_runner("non-existent")

    @pytest.mark.asyncio
    async def test_get_runner_by_id_outside_context(self):
        """Test that getting runner by ID outside context raises error."""
        with pytest.raises(RuntimeError, match="called outside of context"):
            AsyncTaskRunner.get_runner("any-id")

    @pytest.mark.asyncio
    async def test_add_task_after_exit_raises_error(self):
        """Test that adding tasks after context exit raises error."""
        runner = AsyncTaskRunner()
        async with runner:
            pass

        with pytest.raises(
            RuntimeError, match="Cannot add task.*after it has been exited"
        ):
            runner.add_task(lambda: asyncio.sleep(0))

    @pytest.mark.asyncio
    async def test_add_task_outside_context_raises_error(self):
        """Test that adding task outside context raises RuntimeError."""

        async def dummy_task():
            pass

        with pytest.raises(RuntimeError, match="called outside of context"):
            AsyncTaskRunner.add_task(dummy_task)

    @pytest.mark.asyncio
    async def test_add_existing_async_task_instance(self):
        """Test adding an existing AsyncTask instance directly."""
        results = []

        async def wrapped_task():
            results.append("wrapped")
            return "result"

        task = AsyncTask(wrapped_task, caller=CallerInfo("test.py", 1, "test"))

        async with AsyncTaskRunner():
            returned_task = AsyncTaskRunner.add_task(task)
            # Should return the same task instance
            assert returned_task is task

        assert results == ["wrapped"]

    @pytest.mark.asyncio
    async def test_tags_on_tasks(self):
        """Test adding tags to tasks."""
        results = []

        async def tagged_task():
            results.append("tagged")

        async with AsyncTaskRunner():
            AsyncTaskRunner.add_task(tagged_task, tags=["test", "important"])

        assert results == ["tagged"]

    @pytest.mark.asyncio
    async def test_remove_tasks_by_tag(self):
        """Test removing tasks by tag."""
        results = []

        async def task1():
            results.append(1)

        async def task2():
            results.append(2)

        async def task3():
            results.append(3)

        async with AsyncTaskRunner():
            AsyncTaskRunner.add_task(task1, tags=["keep"])
            AsyncTaskRunner.add_task(task2, tags=["remove"])
            AsyncTaskRunner.add_task(task3, tags=["keep"])
            AsyncTaskRunner.remove_tasks_by_tag("remove")

        assert results == [1, 3]

    @pytest.mark.asyncio
    async def test_remove_tasks_by_tag_queue_empty_exception(self):
        """Test that queue.Empty exception is handled during task removal."""

        results = []

        async def task1():
            results.append(1)

        async def task2():
            results.append(2)

        async with AsyncTaskRunner() as runner:
            AsyncTaskRunner.add_task(task2, tags=["remove"])

            # Save original methods
            original_get = runner.task_queue.get

            def patched_get(timeout=None):
                item = original_get(timeout=timeout)
                if runner.task_queue.empty():
                    item = original_get(block=False)  # This will raise queue.Empty
                return item

            with patch.object(runner.task_queue, "get", new=patched_get):
                AsyncTaskRunner.remove_tasks_by_tag("remove")

    @pytest.mark.asyncio
    async def test_remove_tasks_by_tag_outside_context(self):
        """Test that removing tasks by tag outside context raises error."""
        with pytest.raises(RuntimeError, match="called outside of context"):
            AsyncTaskRunner.remove_tasks_by_tag("tag")

    @pytest.mark.asyncio
    async def test_empty_tag_list(self):
        """Test that tasks can be added with empty tag list."""
        results = []

        async def task():
            results.append("executed")

        async with AsyncTaskRunner():
            AsyncTaskRunner.add_task(task, tags=[])

        assert results == ["executed"]

    @pytest.mark.asyncio
    async def test_async_task_callable(self):
        """Test AsyncTask as a callable."""

        async def sample_task():
            return "result"

        task = AsyncTask(sample_task)
        result = await task()
        assert result == "result"

    @pytest.mark.asyncio
    async def test_async_task_awaitable(self):
        """Test AsyncTask as an awaitable."""

        async def sample_task():
            return "result"

        task = AsyncTask(sample_task)
        result = await task
        assert result == "result"

    @pytest.mark.asyncio
    async def test_async_task_caching(self):
        """Test that AsyncTask caches its result."""
        call_count = 0

        async def counted_task():
            nonlocal call_count
            call_count += 1
            return "result"

        task = AsyncTask(counted_task)
        result1 = await task
        result2 = await task
        assert result1 == result2
        assert call_count == 1  # Should only be called once

    @pytest.mark.asyncio
    async def test_task_queue_timeout_handling(self):
        """Test that task queue operations respect timeout."""
        results = []

        async def task():
            results.append("executed")

        async with AsyncTaskRunner():
            # Add a task normally - should complete within timeout
            AsyncTaskRunner.add_task(task)

        assert results == ["executed"]

    @pytest.mark.asyncio
    async def test_caller_info_with_no_frame(self):
        """Test AsyncTask creation when frame info is unavailable."""
        import inspect

        async def task():
            return "result"

        # Patch currentframe to return None (simulating when frame info is unavailable)
        with patch.object(inspect, "currentframe", return_value=None):
            async with AsyncTaskRunner():
                task_obj = AsyncTaskRunner.add_task(task)
                # Should fallback to unknown caller info
                assert task_obj.caller is not None
                assert task_obj.caller.filename == "<unknown>"
                assert task_obj.caller.lineno == 0
                assert task_obj.caller.name == "<unknown>"

    @pytest.mark.asyncio
    async def test_debug_logging(self):
        """Test that debug logging works when Setting.DEBUG is True."""

        original_debug = Setting.DEBUG
        g.config["DEBUG"] = True  # Ensure DEBUG is True for this test

        try:
            results = []

            async def task():
                results.append("logged")

            async with AsyncTaskRunner():
                AsyncTaskRunner.add_task(task)

            assert results == ["logged"]
        finally:
            g.config["DEBUG"] = original_debug  # Restore original DEBUG value

    @pytest.mark.asyncio
    async def test_exception_traceback_formatting(self):
        """Test that exception tracebacks are properly formatted."""

        async def failing_task():
            raise ValueError("Detailed error message")

        try:
            async with AsyncTaskRunner():
                AsyncTaskRunner.add_task(failing_task)
        except AsyncTaskRunnerException as e:
            error_str = str(e)
            # Should contain traceback information
            assert "traceback" in error_str.lower()
            assert "Detailed error message" in error_str

    @pytest.mark.asyncio
    async def test_result_accessor_await(self):
        """Test ResultAccessor can be awaited."""

        async def sample_task():
            return 42

        task = AsyncTask(sample_task)
        await task
        result = await task.result
        assert result == 42

    @pytest.mark.asyncio
    async def test_result_accessor_direct_access_before_execution(self):
        """Test that direct access before execution raises error."""

        async def sample_task():
            return 42

        task = AsyncTask(sample_task)
        with pytest.raises(RuntimeError, match="has not been executed yet"):
            str(task.result)

    @pytest.mark.asyncio
    async def test_result_accessor_direct_access_after_execution(self):
        """Test direct access to result after execution."""

        async def sample_task():
            return 42

        task = AsyncTask(sample_task)
        await task
        assert str(task.result) == "42"
        assert repr(task.result) == "42"

    @pytest.mark.asyncio
    async def test_result_accessor_getattr(self):
        """Test ResultAccessor __getattr__ access to result attributes."""

        async def sample_task():
            class Result:
                value = 42
                name = "test"

            return Result()

        task = AsyncTask(sample_task)
        await task
        assert task.result.value == 42
        assert task.result.name == "test"

    @pytest.mark.asyncio
    async def test_parent_child_references(self):
        """Test parent-child relationships in nested contexts."""
        async with AsyncTaskRunner() as parent:
            assert parent.parent is None
            assert parent.child is None

            async with AsyncTaskRunner() as child:
                assert child.parent is parent
                assert parent.child is child

            # After child exits, reference should remain
            assert parent.child is child

    @pytest.mark.asyncio
    async def test_coroutine_directly_as_task(self):
        """Test adding a coroutine directly instead of a callable."""
        results = []

        async def coro_task():
            results.append("executed")

        async with AsyncTaskRunner():
            # Add coroutine directly (though callable is preferred)
            AsyncTaskRunner.add_task(coro_task())

        assert results == ["executed"]

    @pytest.mark.asyncio
    async def test_async_task_wrapper(self):
        """Test adding an AsyncTask instance."""
        results = []

        async def wrapped_task():
            results.append("wrapped")

        task = AsyncTask(wrapped_task)

        async with AsyncTaskRunner():
            AsyncTaskRunner.add_task(task)

        assert results == ["wrapped"]

    @pytest.mark.asyncio
    async def test_runner_repr(self):
        """Test runner string representation."""
        runner = AsyncTaskRunner(id="test-repr")
        repr_str = repr(runner)
        assert "AsyncTaskRunner" in repr_str
        assert "test-repr" in repr_str
        assert "frozen=False" in repr_str

    @pytest.mark.asyncio
    async def test_caller_info_repr(self):
        """Test CallerInfo string representation."""
        caller = CallerInfo(filename="test.py", lineno=10, name="test_function")
        repr_str = repr(caller)
        assert "test.py" in repr_str
        assert "10" in repr_str
        assert "test_function" in repr_str

    @pytest.mark.asyncio
    async def test_frozen_state_after_exit(self):
        """Test that runner is frozen after exiting context."""
        runner = AsyncTaskRunner()
        assert runner.frozen is False

        async with runner:
            assert runner.frozen is False

        assert runner.frozen is True

    @pytest.mark.asyncio
    async def test_concurrent_tasks(self):
        """Test that tasks run concurrently."""
        start_times = []
        end_times = []

        async def slow_task(task_id):
            start_times.append((task_id, asyncio.get_event_loop().time()))
            await asyncio.sleep(0.1)
            end_times.append((task_id, asyncio.get_event_loop().time()))

        async with AsyncTaskRunner():
            AsyncTaskRunner.add_task(
                lambda: slow_task(1),
                lambda: slow_task(2),
                lambda: slow_task(3),
            )

        # All tasks should start before any ends (concurrent execution)
        assert len(start_times) == 3
        assert len(end_times) == 3

    @pytest.mark.asyncio
    async def test_runner_not_found_in_stack_on_exit(self):
        """Test that ValueError in _on_exit when runner is not in stack raises RuntimeError."""

        with pytest.raises(RuntimeError, match="Runner instance not found in stack"):
            async with AsyncTaskRunner() as runner:
                stack = runner._get_current_stack(
                    "test_runner_not_found_in_stack_on_exit"
                )
                stack.remove(runner)  # Remove runner manually
