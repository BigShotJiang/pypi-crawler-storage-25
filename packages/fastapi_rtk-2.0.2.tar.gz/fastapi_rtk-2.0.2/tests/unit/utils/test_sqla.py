from fastapi_rtk.utils.sqla import is_sqla_type
from sqlalchemy import Boolean, Column, DateTime, Float, Integer, String
from sqlalchemy.types import TypeDecorator


class CustomString(TypeDecorator):
    """Custom type decorator for testing."""

    impl = String
    cache_ok = True


class CustomInteger(TypeDecorator):
    """Custom type decorator for testing."""

    impl = Integer
    cache_ok = True


class TestIsSqlaType:
    """Test suite for is_sqla_type function."""

    def test_direct_type_match(self):
        """Test direct type matching."""
        col = Column(Integer)
        assert is_sqla_type(col.type, Integer) is True

    def test_direct_type_mismatch(self):
        """Test direct type mismatch."""
        col = Column(Integer)
        assert is_sqla_type(col.type, String) is False

    def test_string_type_match(self):
        """Test String type matching."""
        col = Column(String)
        assert is_sqla_type(col.type, String) is True

    def test_datetime_type_match(self):
        """Test DateTime type matching."""
        col = Column(DateTime)
        assert is_sqla_type(col.type, DateTime) is True

    def test_boolean_type_match(self):
        """Test Boolean type matching."""
        col = Column(Boolean)
        assert is_sqla_type(col.type, Boolean) is True

    def test_float_type_match(self):
        """Test Float type matching."""
        col = Column(Float)
        assert is_sqla_type(col.type, Float) is True

    def test_type_decorator_match(self):
        """Test TypeDecorator with matching impl type."""
        col = Column(CustomString())
        assert is_sqla_type(col.type, String) is True

    def test_type_decorator_mismatch(self):
        """Test TypeDecorator with non-matching impl type."""
        col = Column(CustomString())
        assert is_sqla_type(col.type, Integer) is False

    def test_type_decorator_integer_match(self):
        """Test TypeDecorator with Integer impl type."""
        col = Column(CustomInteger())
        assert is_sqla_type(col.type, Integer) is True

    def test_type_decorator_integer_mismatch(self):
        """Test TypeDecorator with Integer impl checking against String."""
        col = Column(CustomInteger())
        assert is_sqla_type(col.type, String) is False

    def test_multiple_columns_different_types(self):
        """Test multiple columns with different types."""
        int_col = Column(Integer)
        str_col = Column(String)

        assert is_sqla_type(int_col.type, Integer) is True
        assert is_sqla_type(str_col.type, String) is True
        assert is_sqla_type(int_col.type, String) is False
        assert is_sqla_type(str_col.type, Integer) is False
