from fastapi_rtk.utils.extender_mixin import ExtenderMixin


class TestExtenderMixin:
    def test_basic_extension(self):
        """Test that child class extends parent class with new attributes"""

        class Parent:
            parent_attr = "parent"

        class Child(ExtenderMixin, Parent):
            child_attr = "child"

        assert hasattr(Parent, "parent_attr")
        assert hasattr(Parent, "child_attr")
        assert Parent.parent_attr == "parent"
        assert Parent.child_attr == "child"

    def test_multiple_attributes_extension(self):
        """Test extending parent with multiple attributes"""

        class Parent:
            existing = "exists"

        class Child(ExtenderMixin, Parent):
            attr1 = "value1"
            attr2 = "value2"
            attr3 = 123

        assert Parent.attr1 == "value1"
        assert Parent.attr2 == "value2"
        assert Parent.attr3 == 123

    def test_method_extension(self):
        """Test that methods are also extended to parent"""

        class Parent:
            pass

        class Child(ExtenderMixin, Parent):
            def child_method(self):
                return "child"

        assert hasattr(Parent, "child_method")
        parent_instance = Parent()
        assert parent_instance.child_method() == "child"

    def test_multiple_parents(self):
        """Test extending multiple parent classes"""

        class Parent1:
            parent1_attr = "p1"

        class Parent2:
            parent2_attr = "p2"

        class Child(ExtenderMixin, Parent1, Parent2):
            child_attr = "child"

        assert hasattr(Parent1, "child_attr")
        assert hasattr(Parent2, "child_attr")
        assert Parent1.child_attr == "child"
        assert Parent2.child_attr == "child"

    def test_no_module_or_doc_extension(self):
        """Test that __module__ and __doc__ are not extended"""

        class Parent:
            pass

        class Child(ExtenderMixin, Parent):
            """Child docstring"""

            pass

        assert not hasattr(Parent, "__doc__") or Parent.__doc__ is None

    def test_nested_inheritance(self):
        """Test extension with nested inheritance"""

        class GrandParent:
            grandparent_attr = "gp"

        class Parent(GrandParent):
            parent_attr = "p"

        class Child(ExtenderMixin, Parent):
            child_attr = "child"

        assert hasattr(Parent, "child_attr")
        assert Parent.child_attr == "child"

    def test_class_variables(self):
        """Test extending class variables"""

        class Parent:
            counter = 0

        class Child(ExtenderMixin, Parent):
            max_count = 100

        assert Parent.max_count == 100

    def test_extender_not_direct_base(self):
        """Test that ExtenderMixin only works when directly inherited"""

        class Parent:
            parent_attr = "parent"

        class Middle(ExtenderMixin, Parent):
            middle_attr = "middle"

        class Child(Middle):
            child_attr = "child"

        assert hasattr(Parent, "middle_attr")
        assert not hasattr(Parent, "child_attr")
        assert not hasattr(Middle, "child_attr")

    def test_override_parent_attribute(self):
        """Test that child can override parent attributes"""

        class Parent:
            shared_attr = "parent_value"

        class Child(ExtenderMixin, Parent):
            shared_attr = "child_value"

        assert Parent.shared_attr == "child_value"

    def test_callable_attributes(self):
        """Test extending with callable attributes"""

        class Parent:
            pass

        def external_func():
            return "external"

        class Child(ExtenderMixin, Parent):
            func = external_func

        assert hasattr(Parent, "func")
        assert Parent.func() == "external"

