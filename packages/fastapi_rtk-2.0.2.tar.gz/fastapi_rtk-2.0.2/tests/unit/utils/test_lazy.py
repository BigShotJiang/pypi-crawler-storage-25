from typing import TypeVar

import pytest
from fastapi_rtk.utils.lazy import lazy, lazy_import, lazy_self


class TestLazy:
    """Test suite for the lazy descriptor."""

    def test_lazy_decorator_style(self):
        """Test lazy evaluation using decorator style."""
        call_count = 0

        class MyClass:
            @lazy
            def expensive_operation(self):
                nonlocal call_count
                call_count += 1
                return "expensive_result"

        instance = MyClass()
        assert call_count == 0

        # First access should compute the value
        result1 = instance.expensive_operation
        assert call_count == 1
        assert result1 == "expensive_result"

        # Second access should use cached value
        result2 = instance.expensive_operation
        assert call_count == 1
        assert result2 == "expensive_result"

    def test_lazy_property_style(self):
        """Test lazy evaluation using property style."""
        call_count = 0

        class MyClass:
            expensive_operation = lazy(
                lambda self: (self.increment_call_count(), "result")[1]
            )

            @classmethod
            def increment_call_count(cls):
                nonlocal call_count
                call_count += 1

        instance = MyClass()
        result1 = instance.expensive_operation
        result2 = instance.expensive_operation
        assert result1 == result2

    def test_lazy_no_cache(self):
        """Test lazy evaluation without caching."""
        call_count = 0

        class MyClass:
            @lazy(cache=False)
            def dynamic_value(self):
                nonlocal call_count
                call_count += 1
                return call_count

        instance = MyClass()
        assert instance.dynamic_value == 1
        assert instance.dynamic_value == 2
        assert instance.dynamic_value == 3

    def test_lazy_only_instance_false(self):
        """Test lazy evaluation on class level."""
        call_count = 0

        class MyClass:
            @lazy(only_instance=False)
            def class_value(cls):
                nonlocal call_count
                call_count += 1
                return "class_result"

        # Access on class should work
        result1 = MyClass.class_value
        assert call_count == 1
        assert result1 == "class_result"

        # Should use cached value
        result2 = MyClass.class_value
        assert call_count == 1
        assert result2 == "class_result"

        # Instance should also use the same cached value
        instance = MyClass()
        result3 = instance.class_value
        assert call_count == 1
        assert result3 == "class_result"

    def test_lazy_only_instance_true_class_access(self):
        """Test that accessing lazy with only_instance=True on class returns descriptor."""

        class MyClass:
            @lazy(only_instance=True)
            def instance_only(self):
                return "result"

        # Accessing on class should return the descriptor
        assert isinstance(MyClass.instance_only, lazy)

    def test_lazy_with_dependencies(self):
        """Test lazy attributes that depend on other lazy attributes."""

        class MyClass:
            @lazy
            def first(self):
                return 10

            second = lazy(lambda self: self.first + 5)

            @lazy(cache=False)
            def third(self):
                return self.second + 3

        instance = MyClass()
        assert instance.first == 10
        assert instance.second == 15
        assert instance.third == 18

    def test_lazy_private_attribute(self):
        """Test lazy evaluation with private attributes (name mangling)."""
        call_count = 0

        class MyClass:
            @lazy
            def __private(self):
                nonlocal call_count
                call_count += 1
                return "private_result"

            def get_private(self):
                return self.__private

        instance = MyClass()
        result = instance.get_private()
        assert call_count == 1
        assert result == "private_result"

        # Second access should use cached value
        result2 = instance.get_private()
        assert call_count == 1
        assert result2 == "private_result"

        # Verify the attribute is stored with name mangling in __dict__
        assert "_MyClass__private" in instance.__dict__
        assert instance.__dict__["_MyClass__private"] == "private_result"

    def test_lazy_private_attribute_with_property(self):
        """Test lazy evaluation with private attributes (name mangling)."""
        call_count = 0

        def increment_call_count():
            nonlocal call_count
            call_count += 1

        class MyClass:
            __private = lazy(lambda: (increment_call_count(), "private_result")[1])

            def get_private(self):
                return self.__private

        instance = MyClass()
        result = instance.get_private()
        assert call_count == 1
        assert result == "private_result"

        # Second access should use cached value
        result2 = instance.get_private()
        assert call_count == 1
        assert result2 == "private_result"

        # Verify the attribute is stored with name mangling in __dict__
        assert "_MyClass__private" in instance.__dict__
        assert instance.__dict__["_MyClass__private"] == "private_result"

    def test_lazy_no_self_parameter(self):
        """Test lazy with function that takes no parameters."""
        call_count = 0

        class MyClass:
            value = lazy(lambda: (MyClass.increment_call_count(), 42)[1])

            @staticmethod
            def increment_call_count():
                nonlocal call_count
                call_count += 1

        instance = MyClass()
        # This should work but won't cache properly without self
        result = instance.value
        assert result == 42

    def test_lazy_multiple_instances(self):
        """Test that lazy values are instance-specific."""

        class MyClass:
            def __init__(self, value):
                self._value = value

            @lazy
            def computed(self):
                return self._value * 2

        instance1 = MyClass(5)
        instance2 = MyClass(10)

        assert instance1.computed == 10
        assert instance2.computed == 20

    def test_lazy_is_lazy_method(self):
        """Test the is_lazy class method."""

        class MyClass:
            @lazy
            def lazy_attr(self):
                return "lazy"

            def regular_method(self):
                return "regular"

        assert lazy.is_lazy(MyClass, "lazy_attr") is True
        assert lazy.is_lazy(MyClass, "regular_method") is False
        assert lazy.is_lazy(MyClass, "nonexistent") is False

        instance = MyClass()
        assert lazy.is_lazy(instance, "lazy_attr") is True

    def test_lazy_get_lazy_method(self):
        """Test the get_lazy class method."""

        class MyClass:
            @lazy
            def lazy_attr(self):
                return "lazy"

            def regular_method(self):
                return "regular"

        descriptor = lazy.get_lazy(MyClass, "lazy_attr")
        assert isinstance(descriptor, lazy)

        with pytest.raises(TypeError):
            lazy.get_lazy(MyClass, "regular_method")

        with pytest.raises(AttributeError):
            lazy.get_lazy(MyClass, "nonexistent")

    def test_lazy_without_dict(self):
        """Test lazy with objects that don't have __dict__."""

        class MyClass:
            __slots__ = ("value",)

            def __init__(self):
                self.value = 42

            @lazy
            def computed(self):
                return self.value * 2

        instance = MyClass()
        with pytest.raises(AttributeError, match="does not have a __dict__ attribute"):
            _ = instance.computed


class TestLazyImport:
    """Test suite for the lazy_import descriptor."""

    def test_lazy_import_module_attribute(self):
        """Test lazy import of a module attribute."""

        class MyClass:
            path = lazy_import("os.path", "join")

        instance = MyClass()
        # Should import os.path and get the join function
        assert callable(instance.path)
        assert instance.path("a", "b") == "a/b" or instance.path("a", "b") == "a\\b"

    def test_lazy_import_with_callable_getter(self):
        """Test lazy import with a callable getter."""

        class MyClass:
            version = lazy_import("sys", lambda mod: mod.version_info.major)

        instance = MyClass()
        assert isinstance(instance.version, int)
        assert instance.version >= 3

    def test_lazy_import_caching(self):
        """Test that lazy import caches the result."""

        class MyClass:
            random = lazy_import("random", "random")

        instance = MyClass()
        # Get the function reference (not call it)
        func1 = instance.random
        func2 = instance.random
        # Should be the same object due to caching
        assert func1 is func2


class TestLazySelf:
    """Test suite for the lazy_self descriptor."""

    def test_lazy_self_basic(self):
        """Test lazy_self basic functionality."""
        call_count = 0

        def increment_call_count():
            nonlocal call_count
            call_count += 1

        class MyClass:
            value = 42

            expensive = lazy_self(
                lambda self: (increment_call_count(), self.value * 2)[1]
            )

        instance = MyClass()
        result1 = instance.expensive
        result2 = instance.expensive
        assert call_count == 1
        assert result1 == 84
        assert result2 == 84

    def test_lazy_self_with_method_call(self):
        """Test lazy_self calling instance methods."""

        class MyClass:
            def compute(self):
                return "computed"

            result = lazy_self(lambda self: self.compute())

        instance = MyClass()
        assert instance.result == "computed"

    def test_lazy_self_type_hinting_pattern(self):
        """Test the recommended type hinting pattern for lazy_self."""

        T = TypeVar("T")

        class MyLazy(lazy_self["MyClass", T]):
            pass

        class MyClass:
            value = 10
            doubled = MyLazy(lambda self: self.value * 2)

        instance = MyClass()
        assert instance.doubled == 20
