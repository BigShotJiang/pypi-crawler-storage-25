import json
import uuid
from unittest.mock import patch

import pytest

from fastapi_rtk.utils import flask_appbuilder_utils
from fastapi_rtk.utils.flask_appbuilder_utils import rison_loads, uuid_namegen


def test_uuid_namegen_returns_string():
    """Test that uuid_namegen returns a string."""
    result = uuid_namegen("test.txt")
    assert isinstance(result, str)


def test_uuid_namegen_contains_separator():
    """Test that the result contains the separator '_sep_'."""
    result = uuid_namegen("test.txt")
    assert "_sep_" in result


def test_uuid_namegen_contains_original_filename():
    """Test that the result contains the original filename."""
    filename = "test.txt"
    result = uuid_namegen(filename)
    assert result.endswith(filename)


def test_uuid_namegen_generates_unique_names():
    """Test that multiple calls generate different UUIDs."""
    filename = "test.txt"
    result1 = uuid_namegen(filename)
    result2 = uuid_namegen(filename)
    assert result1 != result2


def test_uuid_namegen_with_empty_string():
    """Test uuid_namegen with an empty filename."""
    result = uuid_namegen("")
    assert "_sep_" in result
    assert result.endswith("")


def test_uuid_namegen_with_special_characters():
    """Test uuid_namegen with special characters in filename."""
    filename = "test_file!@#$%.txt"
    result = uuid_namegen(filename)
    assert filename in result
    assert "_sep_" in result


def test_uuid_namegen_with_path_separator():
    """Test uuid_namegen with path separators in filename."""
    filename = "folder/subfolder/test.txt"
    result = uuid_namegen(filename)
    assert filename in result


@patch("fastapi_rtk.utils.flask_appbuilder_utils.uuid.uuid1")
def test_uuid_namegen_format(mock_uuid1):
    """Test the exact format of the generated name."""
    mock_uuid = uuid.UUID("12345678-1234-5678-1234-567812345678")
    mock_uuid1.return_value = mock_uuid

    filename = "test.txt"
    result = uuid_namegen(filename)
    expected = f"{str(mock_uuid)}_sep_{filename}"
    assert result == expected


def test_uuid_namegen_with_unicode_filename():
    """Test uuid_namegen with unicode characters in filename."""
    filename = "测试文件.txt"
    result = uuid_namegen(filename)
    assert filename in result
    assert "_sep_" in result


class TestRisonLoads:
    def test_parses_valid_rison_via_prison(self):
        """rison string parses through prison when available."""
        assert rison_loads("(a:1,b:!t)") == {"a": 1, "b": True}

    def test_parses_valid_json_when_prison_present(self):
        """Valid JSON also accepted when prison is available (prison happens to parse most JSON literals too)."""
        assert rison_loads('{"a": 1}') == {"a": 1}

    def test_invalid_rison_with_fallback_parses_as_json(self):
        """If prison fails to parse, fallback_to_json=True tries JSON next."""
        assert rison_loads('{"a": 1, "b": true}', fallback_to_json=True) == {
            "a": 1,
            "b": True,
        }

    def test_invalid_rison_no_fallback_raises_value_error(self):
        """fallback_to_json=False causes ValueError on prison parse failure."""
        with pytest.raises(ValueError, match="Not a valid rison string"):
            rison_loads("foo bar", fallback_to_json=False)

    def test_invalid_rison_invalid_json_raises_json_decode_error(self):
        """Both prison and JSON fail -> JSONDecodeError re-raised."""
        with pytest.raises(json.JSONDecodeError):
            rison_loads("foo bar", fallback_to_json=True)

    def test_parses_via_json_when_prison_unavailable(self, monkeypatch):
        """When prison is not installed, JSON path runs."""
        monkeypatch.setattr(flask_appbuilder_utils, "prison", None)
        assert rison_loads('{"a": 1}') == {"a": 1}

    def test_invalid_input_raises_import_error_when_prison_unavailable(
        self, monkeypatch
    ):
        """When prison missing and JSON parse fails, ImportError raised."""
        monkeypatch.setattr(flask_appbuilder_utils, "prison", None)
        with pytest.raises(ImportError, match="prison is required"):
            rison_loads("(a:1)")

    def test_module_level_import_fallback(self, monkeypatch):
        """Reload module with prison unimportable - except branch sets prison=None."""
        import builtins
        import importlib

        real_import = builtins.__import__

        def fake_import(name, *args, **kwargs):
            if name == "prison" or name.startswith("prison."):
                raise ImportError("simulated missing prison")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", fake_import)
        reloaded = importlib.reload(flask_appbuilder_utils)
        try:
            assert reloaded.prison is None
        finally:
            monkeypatch.setattr(builtins, "__import__", real_import)
            importlib.reload(flask_appbuilder_utils)
