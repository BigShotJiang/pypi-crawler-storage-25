from fastapi_rtk.utils.use_default_when_none import use_default_when_none


class TestUseDefaultWhenNone:
    def test_returns_value_when_not_none(self):
        """Test that the function returns the value when it is not None."""
        assert use_default_when_none(5, 10) == 5
        assert use_default_when_none("hello", "default") == "hello"
        assert use_default_when_none([1, 2, 3], []) == [1, 2, 3]
        assert use_default_when_none({"key": "value"}, {}) == {"key": "value"}

    def test_returns_default_when_none(self):
        """Test that the function returns the default value when value is None."""
        assert use_default_when_none(None, 10) == 10
        assert use_default_when_none(None, "default") == "default"
        assert use_default_when_none(None, []) == []
        assert use_default_when_none(None, {}) == {}

    def test_with_zero_value(self):
        """Test that zero is treated as a valid value, not None."""
        assert use_default_when_none(0, 10) == 0
        assert use_default_when_none(0.0, 5.5) == 0.0

    def test_with_empty_collections(self):
        """Test that empty collections are treated as valid values, not None."""
        assert use_default_when_none("", "default") == ""
        assert use_default_when_none([], [1, 2, 3]) == []
        assert use_default_when_none({}, {"key": "value"}) == {}

    def test_with_false_value(self):
        """Test that False is treated as a valid value, not None."""
        assert use_default_when_none(False, True) is False

    def test_with_different_types(self):
        """Test with various data types."""
        assert use_default_when_none(42, "default") == 42
        assert use_default_when_none((1, 2), (3, 4)) == (1, 2)
        assert use_default_when_none(None, (3, 4)) == (3, 4)

    def test_with_none_as_default(self):
        """Test when default value is None."""
        assert use_default_when_none(None, None) is None
        assert use_default_when_none(5, None) == 5
