import inspect

import fastapi
import fastapi.params
from fastapi_rtk.utils.self_dependencies import SelfDepends, SelfType
from fastapi_rtk.utils.update_signature import copy_function, update_signature


class TestUpdateSignature:
    def test_update_signature_with_self_parameter(self):
        """Test that 'self' parameter is replaced with Depends."""

        class MyClass:
            pass

        instance = MyClass()

        def method(self, x: int, y: str):
            pass

        updated = update_signature(instance, method)
        sig = inspect.signature(updated)
        params = list(sig.parameters.values())

        assert len(params) == 3
        assert params[0].name == "self"
        assert isinstance(params[0].default, fastapi.params.Depends)
        assert params[1].kind == inspect.Parameter.KEYWORD_ONLY
        assert params[2].kind == inspect.Parameter.KEYWORD_ONLY

    def test_update_signature_with_cls_parameter(self):
        """Test that 'cls' parameter is replaced with Depends."""

        class MyClass:
            pass

        def classmethod_func(cls, x: int):
            pass

        updated = update_signature(MyClass, classmethod_func)
        sig = inspect.signature(updated)
        params = list(sig.parameters.values())

        assert params[0].name == "cls"
        assert isinstance(params[0].default, fastapi.params.Depends)

    def test_update_signature_without_self_parameter(self):
        """Test that functions without 'self' or 'cls' are unchanged."""

        def regular_function(x: int, y: str):
            pass

        updated = update_signature(None, regular_function)

        assert updated is regular_function

    def test_update_signature_with_empty_parameters(self):
        """Test function with no parameters."""

        def empty_func():
            pass

        updated = update_signature(None, empty_func)

        assert updated is empty_func

    def test_update_signature_with_self_depends(self):
        """Test that SelfDepends is properly replaced."""

        class MyClass:
            def value(self):
                return 42

        instance = MyClass()
        self_depends = SelfDepends().value

        def method(self, x: int = self_depends):
            pass

        updated = update_signature(instance, method)
        sig = inspect.signature(updated)
        params = list(sig.parameters.values())

        assert len(params) == 2
        assert params[1].name == "x"
        assert params[1].default == self_depends(instance)

    def test_update_signature_with_self_type_depends(self):
        """Test that SelfType with depends=True is properly replaced."""

        class MyClass:
            value = int

        instance = MyClass()
        self_type = SelfType(depends=True).value

        def method(self, x=self_type):
            pass

        updated = update_signature(instance, method)
        sig = inspect.signature(updated)
        params = list(sig.parameters.values())

        assert len(params) == 2
        assert params[1].annotation == self_type(instance)
        assert params[1].annotation is int
        assert isinstance(params[1].default, fastapi.params.Depends)

    def test_update_signature_with_self_type_no_depends(self):
        """Test that SelfType with depends=False is properly replaced."""

        class MyClass:
            value = int

        instance = MyClass()
        self_type = SelfType().value

        def method(self, x=self_type):
            pass

        updated = update_signature(instance, method)
        sig = inspect.signature(updated)
        params = list(sig.parameters.values())

        assert len(params) == 2
        assert params[1].annotation == self_type(instance)
        assert params[1].annotation is int
        assert params[1].default == inspect.Parameter.empty

    def test_update_signature_preserves_annotations(self):
        """Test that parameter annotations are preserved."""

        class MyClass:
            pass

        instance = MyClass()

        def method(self, x: int, y: str = "default"):
            pass

        updated = update_signature(instance, method)
        sig = inspect.signature(updated)
        params = list(sig.parameters.values())

        assert params[1].annotation is int
        assert params[2].annotation is str
        assert params[2].default == "default"

    def test_update_signature_creates_copy(self):
        """Test that update_signature creates a copy of the function."""

        class MyClass:
            pass

        instance = MyClass()

        def method(self, x: int):
            pass

        updated = update_signature(instance, method)

        assert updated is not method
        assert updated.__name__ == method.__name__

    def test_copy_function(self):
        """Test that copy_function creates a proper copy."""

        def original(x, y=10):
            return x + y

        copied = copy_function(original)

        assert copied is not original
        assert copied.__name__ == original.__name__
        assert copied.__code__ is original.__code__
        assert copied(5) == 15

    def test_update_signature_with_multiple_parameters(self):
        """Test with multiple parameters of different types."""

        class MyClass:
            def value(self):
                return 42

            value_type = int

        instance = MyClass()
        self_depends = SelfDepends().value
        self_type = SelfType().value_type

        def method(self, a: int, b=self_depends, c=self_type, d: str = "default"):
            pass

        updated = update_signature(instance, method)
        sig = inspect.signature(updated)
        params = list(sig.parameters.values())

        assert len(params) == 5
        assert params[0].name == "self"
        assert params[1].name == "a"
        assert params[2].name == "b"
        assert params[3].name == "c"
        assert params[4].name == "d"
        assert all(p.kind == inspect.Parameter.KEYWORD_ONLY for p in params[1:])

        assert params[2].default == self_depends(instance)
        assert params[3].annotation == self_type(instance)
        assert params[3].annotation is int
        assert params[3].default == inspect.Parameter.empty
        assert params[4].default == "default"
