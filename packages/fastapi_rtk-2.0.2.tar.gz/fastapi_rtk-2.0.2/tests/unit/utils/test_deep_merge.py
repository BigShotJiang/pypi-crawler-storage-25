from fastapi_rtk.utils.deep_merge import deep_merge


class TestDeepMerge:
    def test_merge_empty_dicts(self):
        """Test merging empty dictionaries."""
        result = deep_merge({}, {})
        assert result == {}

    def test_merge_single_dict(self):
        """Test merging a single dictionary."""
        data = {"a": 1, "b": 2}
        result = deep_merge(data)
        assert result == {"a": 1, "b": 2}
        assert result is not data  # Ensure deep copy

    def test_merge_two_simple_dicts(self):
        """Test merging two simple dictionaries."""
        result = deep_merge({"a": 1}, {"b": 2})
        assert result == {"a": 1, "b": 2}

    def test_merge_overwrite_values(self):
        """Test that later values overwrite earlier ones."""
        result = deep_merge({"a": 1}, {"a": 2})
        assert result == {"a": 2}

    def test_merge_nested_dicts(self):
        """Test merging nested dictionaries."""
        dict1 = {"a": {"b": 1, "c": 2}}
        dict2 = {"a": {"c": 3, "d": 4}}
        result = deep_merge(dict1, dict2)
        assert result == {"a": {"b": 1, "c": 3, "d": 4}}

    def test_merge_deeply_nested_dicts(self):
        """Test merging deeply nested dictionaries."""
        dict1 = {"a": {"b": {"c": 1}}}
        dict2 = {"a": {"b": {"d": 2}}}
        result = deep_merge(dict1, dict2)
        assert result == {"a": {"b": {"c": 1, "d": 2}}}

    def test_merge_lists_no_duplicates(self):
        """Test merging lists without duplicates."""
        dict1 = {"items": [1, 2, 3]}
        dict2 = {"items": [3, 4, 5]}
        result = deep_merge(dict1, dict2)
        assert result == {"items": [1, 2, 3, 4, 5]}

    def test_merge_lists_with_duplicates(self):
        """Test that duplicate items are not added."""
        dict1 = {"items": [1, 2]}
        dict2 = {"items": [2, 3]}
        result = deep_merge(dict1, dict2)
        assert result["items"] == [1, 2, 3]

    def test_merge_multiple_dicts(self):
        """Test merging more than two dictionaries."""
        result = deep_merge({"a": 1}, {"b": 2}, {"c": 3})
        assert result == {"a": 1, "b": 2, "c": 3}

    def test_merge_with_none_values(self):
        """Test merging dictionaries with None values."""
        result = deep_merge({"a": None}, {"a": 1})
        assert result == {"a": 1}

    def test_merge_mixed_types(self):
        """Test merging with mixed value types."""
        dict1 = {"a": 1, "b": [1, 2], "c": {"d": 1}}
        dict2 = {"a": 2, "b": [3], "c": {"e": 2}}
        result = deep_merge(dict1, dict2)
        assert result == {"a": 2, "b": [1, 2, 3], "c": {"d": 1, "e": 2}}

    def test_merge_with_rules_overwrite(self):
        """Test merging with custom rules that allow overwrite."""

        def rule(old, new):
            return new > old

        dict1 = {"a": 1}
        dict2 = {"a": 2}
        result = deep_merge(dict1, dict2, rules={"a": rule})
        assert result == {"a": 2}

    def test_merge_with_rules_no_overwrite(self):
        """Test merging with custom rules that prevent overwrite."""

        def rule(old, new):
            return new > old

        dict1 = {"a": 5}
        dict2 = {"a": 2}
        result = deep_merge(dict1, dict2, rules={"a": rule})
        assert result == {"a": 5}

    def test_merge_with_rules_multiple_keys(self):
        """Test merging with rules for multiple keys."""
        rules = {
            "a": lambda old, new: new > old,
            "b": lambda old, new: len(new) > len(old),
        }
        dict1 = {"a": 10, "b": "short"}
        dict2 = {"a": 5, "b": "longer string"}
        result = deep_merge(dict1, dict2, rules=rules)
        assert result == {"a": 10, "b": "longer string"}

    def test_merge_preserves_original(self):
        """Test that original dictionaries are not modified."""
        dict1 = {"a": {"b": 1}}
        dict2 = {"a": {"c": 2}}
        original_dict1 = {"a": {"b": 1}}
        deep_merge(dict1, dict2)
        assert dict1 == original_dict1

    def test_merge_complex_nested_structure(self):
        """Test merging complex nested structures."""
        dict1 = {
            "config": {
                "database": {"host": "localhost", "port": 5432},
                "cache": {"enabled": True},
            },
            "features": ["auth", "logging"],
        }
        dict2 = {
            "config": {"database": {"port": 3306, "name": "mydb"}, "timeout": 30},
            "features": ["monitoring"],
        }
        result = deep_merge(dict1, dict2)
        expected = {
            "config": {
                "database": {"host": "localhost", "port": 3306, "name": "mydb"},
                "cache": {"enabled": True},
                "timeout": 30,
            },
            "features": ["auth", "logging", "monitoring"],
        }
        assert result == expected

    def test_merge_empty_nested_dicts(self):
        """Test merging with empty nested dictionaries."""
        dict1 = {"a": {}}
        dict2 = {"a": {"b": 1}}
        result = deep_merge(dict1, dict2)
        assert result == {"a": {"b": 1}}

    def test_merge_list_of_dicts(self):
        """Test that lists of dicts are concatenated, not merged."""
        dict1 = {"items": [{"id": 1}, {"id": 2}]}
        dict2 = {"items": [{"id": 3}]}
        result = deep_merge(dict1, dict2)
        assert result == {"items": [{"id": 1}, {"id": 2}, {"id": 3}]}
