import pydantic
import pytest
from fastapi_rtk.utils.merge_schema import merge_schema


class TestMergeSchema:
    def test_merge_schema_add_new_fields(self):
        """Test adding new fields to a schema."""

        class OriginalSchema(pydantic.BaseModel):
            name: str
            age: int

        new_fields = {
            "email": (str, pydantic.Field(default="test@example.com")),
            "active": (bool, pydantic.Field(default=True)),
        }

        merged = merge_schema(OriginalSchema, new_fields, name="MergedSchema")

        assert "name" in merged.model_fields
        assert "age" in merged.model_fields
        assert "email" in merged.model_fields
        assert "active" in merged.model_fields

        instance = merged(name="John", age=30)
        assert instance.email == "test@example.com"
        assert instance.active is True

    def test_merge_schema_only_update_existing_fields(self):
        """Test updating only existing fields when only_update=True."""

        class OriginalSchema(pydantic.BaseModel):
            name: str
            age: int

        new_fields = {
            "name": (str, pydantic.Field(default="Default Name")),
            "email": (str, pydantic.Field(default="test@example.com")),
        }

        merged = merge_schema(
            OriginalSchema, new_fields, only_update=True, name="UpdatedSchema"
        )

        assert "name" in merged.model_fields
        assert "age" in merged.model_fields
        assert "email" not in merged.model_fields

        instance = merged(age=25)
        assert instance.name == "Default Name"

    def test_merge_schema_with_field_info_only(self):
        """Test updating with FieldInfo only (not tuple)."""

        class OriginalSchema(pydantic.BaseModel):
            name: str
            age: int

        new_fields = {
            "name": pydantic.Field(default="Updated Name"),
        }

        merged = merge_schema(
            OriginalSchema, new_fields, only_update=True, name="FieldInfoSchema"
        )

        instance = merged(age=30)
        assert instance.name == "Updated Name"

    def test_merge_schema_auto_generated_name(self):
        """Test that schema name is auto-generated when not provided."""

        class OriginalSchema(pydantic.BaseModel):
            name: str

        new_fields = {"age": (int, pydantic.Field(default=0))}

        merged = merge_schema(OriginalSchema, new_fields)

        assert merged.__name__.startswith("OriginalSchema-")
        assert len(merged.__name__) > len("OriginalSchema-")

    def test_merge_schema_custom_name(self):
        """Test providing a custom name for merged schema."""

        class OriginalSchema(pydantic.BaseModel):
            name: str

        new_fields = {"age": (int, pydantic.Field(default=0))}

        merged = merge_schema(OriginalSchema, new_fields, name="CustomSchema")

        assert merged.__name__ == "CustomSchema"

    def test_merge_schema_empty_fields(self):
        """Test merging with empty fields dictionary."""

        class OriginalSchema(pydantic.BaseModel):
            name: str
            age: int

        merged = merge_schema(OriginalSchema, {}, name="EmptyMerge")

        assert "name" in merged.model_fields
        assert "age" in merged.model_fields

    def test_merge_schema_preserves_validation(self):
        """Test that validation rules are preserved."""

        class OriginalSchema(pydantic.BaseModel):
            name: str
            age: int = pydantic.Field(gt=0)

        new_fields = {"email": (str, pydantic.Field())}

        merged = merge_schema(OriginalSchema, new_fields, name="ValidatedSchema")

        with pytest.raises(pydantic.ValidationError):
            merged(name="John", age=-5, email="test@example.com")

    def test_merge_schema_inheritance(self):
        """Test that merged schema inherits from original schema."""

        class OriginalSchema(pydantic.BaseModel):
            name: str

        new_fields = {"age": (int, pydantic.Field(default=0))}

        merged = merge_schema(OriginalSchema, new_fields, name="InheritedSchema")

        assert issubclass(merged, OriginalSchema)
