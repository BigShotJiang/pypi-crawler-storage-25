from datetime import datetime, timedelta, timezone

import pytest
from fastapi_rtk.utils.timezone import ensure_tz_info, validate_utc


class TestEnsureTzInfo:
    def test_datetime_with_utc_timezone(self):
        dt = datetime(2023, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        result = ensure_tz_info(dt)
        assert result == dt
        assert result.tzinfo == timezone.utc

    def test_datetime_without_timezone(self):
        dt = datetime(2023, 1, 1, 12, 0, 0)
        result = ensure_tz_info(dt)
        assert result.tzinfo == timezone.utc
        assert result.replace(tzinfo=None) == dt

    def test_datetime_with_non_utc_timezone(self):
        tz = timezone(timedelta(hours=5))
        dt = datetime(2023, 1, 1, 12, 0, 0, tzinfo=tz)
        result = ensure_tz_info(dt)
        assert result == dt
        assert result.tzinfo == tz

    def test_string_with_timezone(self):
        dt_str = "2023-01-01T12:00:00+00:00"
        result = ensure_tz_info(dt_str)
        assert isinstance(result, datetime)
        assert result.tzinfo is not None

    def test_string_without_timezone(self):
        dt_str = "2023-01-01T12:00:00"
        result = ensure_tz_info(dt_str)
        assert isinstance(result, datetime)
        assert result.tzinfo == timezone.utc

    def test_string_with_non_utc_timezone(self):
        dt_str = "2023-01-01T12:00:00+05:00"
        result = ensure_tz_info(dt_str)
        assert isinstance(result, datetime)
        assert result.tzinfo.utcoffset(result) == timedelta(hours=5)


class TestValidateUtc:
    def test_valid_utc_datetime(self):
        dt = datetime(2023, 1, 1, 12, 0, 0, tzinfo=timezone.utc)
        result = validate_utc(dt)
        assert result == dt

    def test_invalid_non_utc_timezone(self):
        tz = timezone(timedelta(hours=5))
        dt = datetime(2023, 1, 1, 12, 0, 0, tzinfo=tz)
        with pytest.raises(ValueError, match="Timezone must be UTC"):
            validate_utc(dt)

    def test_invalid_negative_offset_timezone(self):
        tz = timezone(timedelta(hours=-3))
        dt = datetime(2023, 1, 1, 12, 0, 0, tzinfo=tz)
        with pytest.raises(ValueError, match="Timezone must be UTC"):
            validate_utc(dt)

    def test_utc_timezone_variant(self):
        dt = datetime(2023, 1, 1, 12, 0, 0, tzinfo=timezone(timedelta(0)))
        result = validate_utc(dt)
        assert result == dt
