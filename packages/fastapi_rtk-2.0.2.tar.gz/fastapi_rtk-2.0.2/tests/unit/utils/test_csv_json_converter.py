import enum
from unittest.mock import Mock, patch

import pytest
from fastapi_rtk.utils.csv_json_converter import (
    AsyncColumnProcessor,
    ColumnProcessor,
    CSVJSONConverter,
    DataPipeline,
    DictProcessor,
    EnumProcessor,
    FallbackProcessor,
    Line,
    ListProcessor,
    ModelProcessor,
)


class TestLine:
    def test_write_and_read(self):
        line = Line()
        line.write("test line")
        assert line.read() == "test line"

    def test_multiple_writes(self):
        line = Line()
        line.write("first")
        line.write("second")
        assert line.read() == "second"


class TestCSVJSONConverter:
    def test_csv_to_json_basic(self):
        csv_data = "name,age\nAlice,30\nBob,25"
        result = CSVJSONConverter.csv_to_json(csv_data)
        assert len(result) == 2
        assert result[0] == {"name": "Alice", "age": "30"}
        assert result[1] == {"name": "Bob", "age": "25"}

    def test_csv_to_json_bytes(self):
        csv_data = b"name,age\nAlice,30"
        result = CSVJSONConverter.csv_to_json(csv_data)
        assert len(result) == 1
        assert result[0] == {"name": "Alice", "age": "30"}

    def test_csv_to_json_custom_delimiter(self):
        csv_data = "name;age\nAlice;30"
        result = CSVJSONConverter.csv_to_json(csv_data, delimiter=";")
        assert result[0] == {"name": "Alice", "age": "30"}

    def test_csv_to_json_with_quotechar(self):
        csv_data = 'name,description\nAlice,"Hello, World"'
        result = CSVJSONConverter.csv_to_json(csv_data, quotechar='"')
        assert result[0] == {"name": "Alice", "description": "Hello, World"}

    def test_csv_to_json_with_nested_columns(self):
        csv_data = "name,address.city,address.state\nAlice,New York,NY"
        result = CSVJSONConverter.csv_to_json(csv_data)
        assert result[0]["name"] == "Alice"
        assert result[0]["address"]["city"] == "New York"
        assert result[0]["address"]["state"] == "NY"

    def test_csv_to_json_with_list_values(self):
        csv_data = "name,tags\nAlice,tag1;tag2;tag3"
        result = CSVJSONConverter.csv_to_json(csv_data)
        assert result[0]["tags"] == ["tag1", "tag2", "tag3"]

    def test_json_to_csv_basic(self):
        data = {"name": "Alice", "age": 30}
        result = CSVJSONConverter.json_to_csv(
            data,
            list_columns=["name", "age"],
            label_columns={"name": "Name", "age": "Age"},
        )
        lines = [x.strip() for x in result.split("\n")]
        assert lines[0] == "Name,Age"
        assert lines[1] == "Alice,30"

    def test_json_to_csv_list_of_dicts(self):
        data = [{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}]
        result = CSVJSONConverter.json_to_csv(
            data,
            list_columns=["name", "age"],
            label_columns={"name": "Name", "age": "Age"},
        )
        lines = [x.strip() for x in result.split("\n")]
        assert len(lines) == 3
        assert lines[1] == "Alice,30"
        assert lines[2] == "Bob,25"

    def test_json_to_csv_without_header(self):
        data = {"name": "Alice", "age": 30}
        result = CSVJSONConverter.json_to_csv(
            data,
            list_columns=["name", "age"],
            label_columns={"name": "Name", "age": "Age"},
            with_header=False,
        )
        assert result == "Alice,30"

    def test_json_to_csv_custom_delimiter(self):
        data = {"name": "Alice", "age": 30}
        result = CSVJSONConverter.json_to_csv(
            data,
            list_columns=["name", "age"],
            label_columns={"name": "Name", "age": "Age"},
            delimiter=";",
        )
        lines = [x.strip() for x in result.split("\n")]
        assert lines[0] == "Name;Age"
        assert lines[1] == "Alice;30"

    def test_json_to_csv_single_basic(self):
        data = {"name": "Alice", "age": 30}
        result = CSVJSONConverter.json_to_csv_single(data, list_columns=["name", "age"])
        assert result == ["Alice", "30"]

    def test_json_to_csv_single_with_nested_keys(self):
        data = {"name": "Alice", "address": {"city": "New York"}}
        result = CSVJSONConverter.json_to_csv_single(
            data, list_columns=["name", "address.city"]
        )
        assert result == ["Alice", "New York"]

    @pytest.mark.asyncio
    async def test_ajson_to_csv_single_basic(self):
        data = {"name": "Alice", "age": 30}
        result = await CSVJSONConverter.ajson_to_csv_single(
            data, list_columns=["name", "age"]
        )
        assert result == ["Alice", "30"]

    def test_convert_nested_col_into_dict(self):
        data = {
            "name": "Alice",
            "address.city": "New York",
            "address.state": "NY",
        }
        result = CSVJSONConverter._convert_nested_col_into_dict(data)
        assert result["name"] == "Alice"
        assert result["address"]["city"] == "New York"
        assert result["address"]["state"] == "NY"

    def test_convert_nested_col_into_dict_with_list(self):
        data = {"name": "Alice", "tags": "tag1;tag2;tag3"}
        result = CSVJSONConverter._convert_nested_col_into_dict(data)
        assert result["tags"] == ["tag1", "tag2", "tag3"]

    def test_convert_nested_col_custom_separator(self):
        data = {"name": "Alice", "address->city": "New York"}
        result = CSVJSONConverter._convert_nested_col_into_dict(data, separator="->")
        assert result["address"]["city"] == "New York"


class TestDataPipeline:
    def test_add_processor(self):
        pipeline = DataPipeline()
        processor = FallbackProcessor()
        pipeline.add_processor(processor)
        assert len(pipeline.processors) == 1

    def test_process(self):
        pipeline = DataPipeline()
        pipeline.add_processor(FallbackProcessor())
        result = pipeline.process(None, "col")
        assert result == ""

    @pytest.mark.asyncio
    async def test_aprocess(self):
        pipeline = DataPipeline()
        pipeline.add_processor(FallbackProcessor())
        result = await pipeline.aprocess(None, "col")
        assert result == ""


class TestColumnProcessor:
    def test_process_dict_simple(self):
        processor = ColumnProcessor()
        data = {"name": "Alice", "age": 30}
        result, col, continue_processing = processor.process(data, "name")
        assert result == "Alice"
        assert continue_processing is True

    def test_process_dict_nested(self):
        processor = ColumnProcessor()
        data = {"address": {"city": "New York"}}
        result, col, continue_processing = processor.process(data, "address.city")
        assert result == "New York"
        assert continue_processing is True

    def test_process_object_attribute(self):
        processor = ColumnProcessor()
        obj = Mock()
        obj.name = "Alice"
        result, col, continue_processing = processor.process(obj, "name")
        assert result == "Alice"
        assert continue_processing is True

    def test_process_missing_key(self):
        processor = ColumnProcessor()
        data = {"name": "Alice"}
        result, col, continue_processing = processor.process(data, "age")
        assert result == ""
        assert continue_processing is True


class TestAsyncColumnProcessor:
    @pytest.mark.asyncio
    async def test_process_with_coroutine(self):
        processor = AsyncColumnProcessor()

        async def async_value():
            return "async result"

        obj = Mock()
        obj.name = async_value()
        result, col, continue_processing = await processor.process(obj, "name")
        assert result == "async result"
        assert continue_processing is True


class TestModelProcessor:
    def test_process_with_basic_model(self):
        processor = ModelProcessor()
        mock_model = Mock()
        mock_model.name_ = "Test Model"

        # Simulate BasicModel check
        with patch(
            "fastapi_rtk.utils.csv_json_converter.isinstance"
        ) as mock_isinstance:
            mock_isinstance.return_value = True
            result, col, continue_processing = processor.process(mock_model, "col")
            assert result == "Test Model"
            assert continue_processing is False

    def test_process_without_basic_model(self):
        processor = ModelProcessor()
        data = {"name": "Alice"}
        result, col, continue_processing = processor.process(data, "col")
        assert result == {"name": "Alice"}
        assert continue_processing is True


class TestDictProcessor:
    def test_process_dict(self):
        """Test that DictProcessor processes dictionaries correctly."""
        processor = DictProcessor()
        data = {"key": "value", "number": 42, "name_": "Model Name"}
        result, col, continue_processing = processor.process(data, "col")
        assert isinstance(result, str)
        assert result == "Model Name"
        assert continue_processing is False

    def test_process_non_dict(self):
        """Test that DictProcessor passes through non-dict values."""
        processor = DictProcessor()
        data = "not a dict"
        result, col, continue_processing = processor.process(data, "col")
        assert result == "not a dict"
        assert continue_processing is True

    def test_process_empty_dict(self):
        """Test that DictProcessor handles empty dictionaries."""
        processor = DictProcessor()
        data = {}
        result, col, continue_processing = processor.process(data, "col")
        assert result == "{}"
        assert continue_processing is False

    def test_process_nested_dict(self):
        """Test that DictProcessor handles nested dictionaries."""
        processor = DictProcessor()
        data = {"outer": {"inner": "value"}}
        result, col, continue_processing = processor.process(data, "col")
        assert result == '{"outer": {"inner": "value"}}'
        assert continue_processing is False


class TestListProcessor:
    def test_process_list_of_strings(self):
        processor = ListProcessor()
        data = ["item1", "item2", "item3"]
        result, col, continue_processing = processor.process(data, "col")
        assert result == "item1;item2;item3"
        assert continue_processing is False

    def test_process_non_list(self):
        processor = ListProcessor()
        data = "not a list"
        result, col, continue_processing = processor.process(data, "col")
        assert result == "not a list"
        assert continue_processing is True

    def test_process_list_with_custom_delimiter(self):
        processor = ListProcessor(delimiter=";")
        data = ["item1", "item2"]
        result, col, continue_processing = processor.process(data, "col")
        assert result == "item1,item2"
        assert continue_processing is False

    def test_process_list_of_dicts_without_name(self):
        """Test processing a list of dicts without name_ attribute."""
        processor = ListProcessor()
        data = [{"key": "value1"}, {"key": "value2"}]
        result, col, continue_processing = processor.process(data, "col")
        # Should serialize dicts as JSON strings
        assert '{"key": "value1"}' in result
        assert '{"key": "value2"}' in result
        assert continue_processing is False

    def test_process_list_of_basic_models(self):
        """Test processing a list containing BasicModel instances."""
        processor = ListProcessor()

        # Create mock BasicModel instances
        model1 = Mock()
        model1.name_ = "Model1"

        model2 = Mock()
        model2.name_ = "Model2"

        # Patch isinstance to recognize our mocks as BasicModel
        original_isinstance = isinstance

        with patch(
            "fastapi_rtk.utils.csv_json_converter.isinstance"
        ) as mock_isinstance:

            def isinstance_side_effect(obj, type_):
                if obj in [model1, model2]:
                    # Check if checking for BasicModel
                    if hasattr(type_, "__name__") and "BasicModel" in str(type_):
                        return True
                # Use built-in isinstance for other checks
                return original_isinstance(obj, type_)

            mock_isinstance.side_effect = isinstance_side_effect

            data = [model1, model2]
            result, col, continue_processing = processor.process(data, "col")

            assert result == "Model1;Model2"
            assert continue_processing is False

    def test_process_list_mixed_types(self):
        """Test processing a list with mixed types (strings, dicts, models)."""
        processor = ListProcessor()

        mock_model = Mock()
        mock_model.name_ = "ModelItem"

        original_isinstance = isinstance

        with patch(
            "fastapi_rtk.utils.csv_json_converter.isinstance"
        ) as mock_isinstance:

            def isinstance_side_effect(obj, type_):
                if (
                    obj == mock_model
                    and hasattr(type_, "__name__")
                    and "BasicModel" in str(type_)
                ):
                    return True
                # Use built-in isinstance for other checks
                return original_isinstance(obj, type_)

            mock_isinstance.side_effect = isinstance_side_effect

            data = ["string_item", {"name_": "DictItem"}, mock_model, 42]
            result, col, continue_processing = processor.process(data, "col")

            # Should process each item according to its type
            assert "string_item" in result
            assert "DictItem" in result
            assert "ModelItem" in result
            assert "42" in result
            assert continue_processing is False

    def test_process_empty_list(self):
        """Test processing an empty list."""
        processor = ListProcessor()
        data = []
        result, col, continue_processing = processor.process(data, "col")
        assert result == ""
        assert continue_processing is False


class TestEnumProcessor:
    def test_process_enum(self):
        class Color(enum.Enum):
            RED = "red"
            BLUE = "blue"

        processor = EnumProcessor()
        result, col, continue_processing = processor.process(Color.RED, "col")
        assert result == "red"
        assert continue_processing is False

    def test_process_non_enum(self):
        processor = EnumProcessor()
        result, col, continue_processing = processor.process("not enum", "col")
        assert result == "not enum"
        assert continue_processing is True


class TestFallbackProcessor:
    def test_process_none(self):
        processor = FallbackProcessor()
        result, col, continue_processing = processor.process(None, "col")
        assert result == ""
        assert continue_processing is False

    def test_process_value(self):
        processor = FallbackProcessor()
        result, col, continue_processing = processor.process(123, "col")
        assert result == "123"
        assert continue_processing is False

    def test_process_string(self):
        processor = FallbackProcessor()
        result, col, continue_processing = processor.process("test", "col")
        assert result == "test"
        assert continue_processing is False
