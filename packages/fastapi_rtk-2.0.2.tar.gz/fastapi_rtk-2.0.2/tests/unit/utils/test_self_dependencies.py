import fastapi
from fastapi_rtk.utils.self_dependencies import BaseSelf, SelfDepends, SelfType


class TestBaseSelf:
    def test_base_self_initialization(self):
        base = BaseSelf()
        assert base.attr is None
        assert "attr" in base.ignored_keys
        assert "__class__" in base.ignored_keys

    def test_base_self_getattribute_single_attr(self):
        base = BaseSelf()
        result = base.some_attr
        assert result.attr == "some_attr"
        assert isinstance(result, BaseSelf)

    def test_base_self_getattribute_chained_attrs(self):
        base = BaseSelf()
        result = base.first.second.third
        assert result.attr == "first.second.third"

    def test_base_self_getattribute_ignored_keys(self):
        base = BaseSelf()
        ignored = base.ignored_keys
        assert isinstance(ignored, list)
        assert base.attr is None

    def test_base_self_call_single_attr(self):
        class TestClass:
            value = "test_value"

        base = BaseSelf()
        base.value
        result = base(TestClass)
        assert result == "test_value"

    def test_base_self_call_nested_attr(self):
        class Inner:
            data = "nested_data"

        class Outer:
            inner = Inner()

        base = BaseSelf()
        base.inner.data
        result = base(Outer)
        assert result == "nested_data"


class TestSelfDepends:
    def test_self_depends_initialization(self):
        sd = SelfDepends()
        assert sd.args == ()
        assert sd.kwargs == {}
        assert "args" in sd.ignored_keys
        assert "kwargs" in sd.ignored_keys

    def test_self_depends_with_args(self):
        sd = SelfDepends("arg1", "arg2")
        assert sd.args == ("arg1", "arg2")
        assert sd.kwargs == {}

    def test_self_depends_with_kwargs(self):
        sd = SelfDepends(key1="value1", key2="value2")
        assert sd.args == ()
        assert sd.kwargs == {"key1": "value1", "key2": "value2"}

    def test_self_depends_with_args_and_kwargs(self):
        sd = SelfDepends("arg1", key1="value1")
        assert sd.args == ("arg1",)
        assert sd.kwargs == {"key1": "value1"}

    def test_self_depends_call_returns_fastapi_depends(self):
        def dependency_func():
            return "dependency_result"

        class TestClass:
            method = dependency_func

        sd = SelfDepends()
        sd.method
        result = sd(TestClass)
        assert isinstance(result, fastapi.params.Depends)

    def test_self_depends_call_with_callable_method(self):
        def dep_factory(arg1, kwarg1=None):
            def actual_dependency():
                return f"{arg1}_{kwarg1}"

            return actual_dependency

        class TestClass:
            get_dependency = dep_factory

        sd = SelfDepends("test_arg", kwarg1="test_kwarg")
        sd.get_dependency
        result = sd(TestClass)
        assert isinstance(result, fastapi.params.Depends)

    def test_self_depends_chained_attributes(self):
        class Inner:
            def dependency(self):
                return "result"

            method = dependency

        class Outer:
            inner = Inner()

        sd = SelfDepends()
        sd.inner.method
        result = sd(Outer)
        assert isinstance(result, fastapi.params.Depends)


class TestSelfType:
    def test_self_type_initialization(self):
        st = SelfType()
        assert st.depends is False
        assert st.attr is None
        assert "depends" in st.ignored_keys

    def test_self_type_with_depends_true(self):
        st = SelfType(depends=True)
        assert st.depends is True

    def test_self_type_with_depends_classmethod(self):
        st = SelfType.with_depends()
        assert st.depends is True
        assert isinstance(st, SelfType)

    def test_self_type_getattribute_single(self):
        st = SelfType()
        result = st.schema
        assert result.attr == "schema"
        assert isinstance(result, SelfType)

    def test_self_type_getattribute_chained(self):
        st = SelfType()
        result = st.datamodel.obj.schema
        assert result.attr == "datamodel.obj.schema"

    def test_self_type_call_returns_type(self):
        class Schema:
            pass

        class TestClass:
            schema = Schema

        st = SelfType()
        st.schema
        result = st(TestClass)
        assert result == Schema

    def test_self_type_call_nested_type(self):
        class InnerSchema:
            pass

        class DataModel:
            schema = InnerSchema

        class TestClass:
            datamodel = DataModel()

        st = SelfType()
        st.datamodel.schema
        result = st(TestClass)
        assert result == InnerSchema

    def test_self_type_depends_false_does_not_wrap(self):
        class Schema:
            pass

        class TestClass:
            schema = Schema

        st = SelfType(depends=False)
        st.schema
        result = st(TestClass)
        assert result == Schema
        assert not isinstance(result, fastapi.params.Depends)

    def test_self_type_attr_reset_on_new_instance(self):
        st1 = SelfType()
        st1.first.second

        st2 = SelfType()
        st2.other

        assert st1.attr == "first.second"
        assert st2.attr == "other"


class TestIntegration:
    def test_self_depends_in_class_context(self):
        class MyApi:
            def get_permissions(self):
                def actual_dependency():
                    return ["read", "write"]

                return actual_dependency

        api = MyApi()
        sd = SelfDepends()
        sd.get_permissions
        result = sd(api)

        assert isinstance(result, fastapi.params.Depends)

    def test_self_type_in_class_context(self):
        class MySchema:
            field: str = "test"

        class MyApi:
            schema = MySchema

        api = MyApi()
        st = SelfType()
        st.schema
        result = st(api)

        assert result == MySchema

    def test_multiple_instances_independent(self):
        sd1 = SelfDepends()
        sd1.method1

        sd2 = SelfDepends()
        sd2.method2

        assert sd1.attr == "method1"
        assert sd2.attr == "method2"
