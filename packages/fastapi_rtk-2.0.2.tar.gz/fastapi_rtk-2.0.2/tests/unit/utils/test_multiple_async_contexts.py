import contextlib

import pytest
from fastapi_rtk.utils.multiple_async_contexts import multiple_async_contexts


class AsyncContextExample:
    """Helper class for testing async context managers."""

    def __init__(self, value, should_raise=False):
        self.value = value
        self.should_raise = should_raise
        self.entered = False
        self.exited = False

    async def __aenter__(self):
        self.entered = True
        if self.should_raise:
            raise ValueError(f"Error entering context with value {self.value}")
        return self.value

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.exited = True
        return False


@pytest.mark.asyncio
async def test_multiple_async_contexts_with_single_context():
    """Test with a single async context manager."""
    ctx = AsyncContextExample("test_value")

    async with multiple_async_contexts([ctx]) as values:
        assert values == ["test_value"]
        assert ctx.entered is True
        assert ctx.exited is False

    assert ctx.exited is True


@pytest.mark.asyncio
async def test_multiple_async_contexts_with_multiple_contexts():
    """Test with multiple async context managers."""
    ctx1 = AsyncContextExample("value1")
    ctx2 = AsyncContextExample("value2")
    ctx3 = AsyncContextExample("value3")

    async with multiple_async_contexts([ctx1, ctx2, ctx3]) as values:
        assert values == ["value1", "value2", "value3"]
        assert all([ctx1.entered, ctx2.entered, ctx3.entered])
        assert not any([ctx1.exited, ctx2.exited, ctx3.exited])

    assert all([ctx1.exited, ctx2.exited, ctx3.exited])


@pytest.mark.asyncio
async def test_multiple_async_contexts_with_empty_list():
    """Test with an empty list of contexts."""
    async with multiple_async_contexts([]) as values:
        assert values == []


@pytest.mark.asyncio
async def test_multiple_async_contexts_exception_handling():
    """Test that exceptions during context entry are handled properly."""
    ctx1 = AsyncContextExample("value1")
    ctx2 = AsyncContextExample("value2", should_raise=True)
    ctx3 = AsyncContextExample("value3")

    with pytest.raises(ValueError, match="Error entering context with value value2"):
        async with multiple_async_contexts([ctx1, ctx2, ctx3]):
            pass

    # First context should have been entered and exited
    assert ctx1.entered is True
    assert ctx1.exited is True
    # Third context should never be entered
    assert ctx3.entered is False


@pytest.mark.asyncio
async def test_multiple_async_contexts_with_contextlib_managers():
    """Test with standard contextlib async context managers."""

    @contextlib.asynccontextmanager
    async def example_context(value):
        yield value

    contexts = [example_context(i) for i in range(3)]

    async with multiple_async_contexts(contexts) as values:
        assert values == [0, 1, 2]


@pytest.mark.asyncio
async def test_multiple_async_contexts_cleanup_on_exception():
    """Test that all contexts are properly cleaned up when exception occurs inside the with block."""
    ctx1 = AsyncContextExample("value1")
    ctx2 = AsyncContextExample("value2")

    with pytest.raises(RuntimeError, match="Test exception"):
        async with multiple_async_contexts([ctx1, ctx2]) as values:
            assert values == ["value1", "value2"]
            raise RuntimeError("Test exception")

    # Both contexts should be properly exited
    assert ctx1.exited is True
    assert ctx2.exited is True
