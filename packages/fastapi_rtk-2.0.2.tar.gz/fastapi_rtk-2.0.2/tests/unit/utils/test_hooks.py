import pytest
from fastapi_rtk.utils.hooks import hooks


def test_hooks_with_no_hooks():
    """Test that function works normally without pre/post hooks."""

    @hooks()
    def add(a, b):
        return a + b

    assert add(2, 3) == 5


def test_hooks_with_pre_hook():
    """Test that pre hook is called before function execution."""
    call_order = []

    def pre_hook(*args, **kwargs):
        call_order.append("pre")

    @hooks(pre=pre_hook)
    def add(a, b):
        call_order.append("main")
        return a + b

    result = add(2, 3)
    assert result == 5
    assert call_order == ["pre", "main"]


def test_hooks_with_post_hook():
    """Test that post hook is called after function execution."""
    call_order = []

    def post_hook(result, *args, **kwargs):
        call_order.append(f"post-{result}")

    @hooks(post=post_hook)
    def add(a, b):
        call_order.append("main")
        return a + b

    result = add(2, 3)
    assert result == 5
    assert call_order == ["main", "post-5"]


def test_hooks_with_both_hooks():
    """Test that both pre and post hooks are called in correct order."""
    call_order = []

    def pre_hook(*args, **kwargs):
        call_order.append("pre")

    def post_hook(result, *args, **kwargs):
        call_order.append("post")

    @hooks(pre=pre_hook, post=post_hook)
    def multiply(a, b):
        call_order.append("main")
        return a * b

    result = multiply(3, 4)
    assert result == 12
    assert call_order == ["pre", "main", "post"]


def test_hooks_receives_correct_arguments():
    """Test that hooks receive the correct arguments."""
    received_args = {}

    def pre_hook(*args, **kwargs):
        received_args["pre_args"] = args
        received_args["pre_kwargs"] = kwargs

    def post_hook(result, *args, **kwargs):
        received_args["post_result"] = result
        received_args["post_args"] = args
        received_args["post_kwargs"] = kwargs

    @hooks(pre=pre_hook, post=post_hook)
    def greet(name, greeting="Hello"):
        return f"{greeting}, {name}!"

    result = greet("Alice", greeting="Hi")

    assert result == "Hi, Alice!"
    assert received_args["pre_args"] == ("Alice",)
    assert received_args["pre_kwargs"] == {"greeting": "Hi"}
    assert received_args["post_result"] == "Hi, Alice!"
    assert received_args["post_args"] == ("Alice",)
    assert received_args["post_kwargs"] == {"greeting": "Hi"}


def test_hooks_preserves_function_metadata():
    """Test that decorator preserves function metadata."""

    @hooks()
    def sample_function():
        """Sample docstring."""
        pass

    assert sample_function.__name__ == "sample_function"
    assert sample_function.__doc__ == "Sample docstring."


def test_hooks_with_exception_in_main_function():
    """Test that exception in main function propagates correctly."""

    def pre_hook(*args, **kwargs):
        pass

    def post_hook(result, *args, **kwargs):
        pass

    @hooks(pre=pre_hook, post=post_hook)
    def failing_function():
        raise ValueError("Test error")

    with pytest.raises(ValueError, match="Test error"):
        failing_function()


def test_hooks_post_not_called_on_exception():
    """Test that post hook is not called when main function raises exception."""
    call_order = []

    def pre_hook(*args, **kwargs):
        call_order.append("pre")

    def post_hook(result, *args, **kwargs):
        call_order.append("post")

    @hooks(pre=pre_hook, post=post_hook)
    def failing_function():
        call_order.append("main")
        raise ValueError("Test error")

    with pytest.raises(ValueError):
        failing_function()

    assert call_order == ["pre", "main"]
    assert "post" not in call_order
