import importlib
import sys


class TestFiltersDeprecated:
    def test_warns_on_import(self, caplog):
        if "fastapi_rtk.filters" in sys.modules:
            del sys.modules["fastapi_rtk.filters"]
        with caplog.at_level("WARNING", logger="DT_FASTAPI"):
            importlib.import_module("fastapi_rtk.filters")
        assert any("deprecated" in rec.message for rec in caplog.records)

    def test_re_exports_sqla_filters(self):
        if "fastapi_rtk.filters" in sys.modules:
            del sys.modules["fastapi_rtk.filters"]
        mod = importlib.import_module("fastapi_rtk.filters")
        sqla_filters = importlib.import_module("fastapi_rtk.backends.sqla.filters")
        for name in getattr(sqla_filters, "__all__", []):
            assert hasattr(mod, name)
