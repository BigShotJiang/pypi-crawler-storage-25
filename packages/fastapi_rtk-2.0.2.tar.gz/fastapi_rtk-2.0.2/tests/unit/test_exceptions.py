import fastapi
import pydantic
import pytest

from fastapi_rtk.exceptions import (
    FastAPIReactToolkitException,
    HTTPWithValidationException,
    RolesMismatchException,
    raise_exception,
)


class TestRaiseException:
    def test_raises_base_exception(self):
        with pytest.raises(FastAPIReactToolkitException, match="boom"):
            raise_exception("boom")

    def test_return_type_arg_ignored(self):
        """return_type is type-hint only; function still raises."""
        with pytest.raises(FastAPIReactToolkitException):
            raise_exception("x", return_type=int)


class TestExceptionHierarchy:
    def test_base_is_exception(self):
        assert issubclass(FastAPIReactToolkitException, Exception)

    def test_roles_mismatch_inherits_base(self):
        assert issubclass(RolesMismatchException, FastAPIReactToolkitException)

    def test_http_with_validation_inherits_fastapi_http(self):
        assert issubclass(HTTPWithValidationException, fastapi.HTTPException)


class TestHTTPWithValidationException:
    def test_basic_construction(self):
        exc = HTTPWithValidationException(
            status_code=422,
            type="missing",
            location_type="body",
            field="name",
            msg="field required",
        )
        assert exc.status_code == 422
        assert isinstance(exc.detail, list)
        d = exc.detail[0]
        assert d["type"] == "missing"
        assert d["loc"] == ["body", "name"]
        assert d["msg"] == "field required"
        assert d["url"].endswith("/missing")
        assert "input" not in d

    def test_with_scalar_input(self):
        exc = HTTPWithValidationException(
            status_code=422,
            type="string_type",
            location_type="query",
            field="age",
            msg="must be string",
            input=42,
        )
        assert exc.detail[0]["input"] == "42"

    def test_with_pydantic_model_input(self):
        class Foo(pydantic.BaseModel):
            x: int

        exc = HTTPWithValidationException(
            status_code=422,
            type="t",
            location_type="body",
            field="f",
            msg="m",
            input=Foo(x=7),
        )
        assert exc.detail[0]["input"] == {"x": 7}

    def test_url_uses_pydantic_short_version(self):
        short = pydantic.version.version_short()
        exc = HTTPWithValidationException(
            status_code=400,
            type="validation_error",
            location_type="path",
            field="id",
            msg="bad",
        )
        assert short in exc.detail[0]["url"]

    def test_headers_passed_through(self):
        exc = HTTPWithValidationException(
            status_code=400,
            type="t",
            location_type="path",
            field="f",
            msg="m",
            headers={"X-Test": "1"},
        )
        assert exc.headers == {"X-Test": "1"}

    def test_input_omitted_by_default(self):
        exc = HTTPWithValidationException(
            status_code=400,
            type="t",
            location_type="path",
            field="f",
            msg="m",
        )
        assert "input" not in exc.detail[0]
