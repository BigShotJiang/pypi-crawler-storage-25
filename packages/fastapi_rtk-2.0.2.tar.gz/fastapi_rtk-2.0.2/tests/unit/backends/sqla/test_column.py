from sqlalchemy import Column as SAColumn
from sqlalchemy.orm import Mapped as SAMapped
from sqlalchemy.orm import backref as sa_backref
from sqlalchemy.orm import mapped_column as sa_mapped_column
from sqlalchemy.orm import relationship as sa_relationship

from fastapi_rtk.backends.sqla.column import (
    Column,
    Mapped,
    backref,
    mapped_column,
    relationship,
)


class TestReExports:
    def test_column_is_sa_column(self):
        assert Column is SAColumn

    def test_mapped_is_sa_mapped(self):
        assert Mapped is SAMapped

    def test_mapped_column_is_sa_mapped_column(self):
        assert mapped_column is sa_mapped_column

    def test_relationship_is_sa_relationship(self):
        assert relationship is sa_relationship

    def test_backref_is_sa_backref(self):
        assert backref is sa_backref
