"""Shared fixtures for sqla backend tests using sqlite in-memory.

Models defined once at module load to avoid SAWarning on re-declaration
and to keep relationship registry consistent across tests.
"""

import pytest
import sqlalchemy
from sqlalchemy.orm import Session, relationship

from fastapi_rtk.backends.sqla.model import Model


class Country(Model):
    __tablename__ = "tier8_country"
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
    name = sqlalchemy.Column(sqlalchemy.String(50), nullable=False)


class Person(Model):
    __tablename__ = "tier8_person"
    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
    name = sqlalchemy.Column(sqlalchemy.String(50), nullable=False)
    age = sqlalchemy.Column(sqlalchemy.Integer)
    active = sqlalchemy.Column(sqlalchemy.Boolean, default=True)
    country_id = sqlalchemy.Column(
        sqlalchemy.Integer, sqlalchemy.ForeignKey("tier8_country.id")
    )
    country = relationship("Country", back_populates="people")


Country.people = relationship("Person", back_populates="country")


@pytest.fixture
def Person_cls():
    return Person


@pytest.fixture
def Country_cls():
    return Country


# Backwards-compat aliases (some tests use Person/Country directly)
@pytest.fixture
def Person_(Person_cls):
    return Person_cls


@pytest.fixture
def Country_(Country_cls):
    return Country_cls


@pytest.fixture
def engine():
    from sqlalchemy.pool import StaticPool

    eng = sqlalchemy.create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Country.__table__.create(eng)
    Person.__table__.create(eng)
    yield eng
    Person.__table__.drop(eng)
    Country.__table__.drop(eng)
    eng.dispose()


@pytest.fixture
def session(engine):
    with Session(engine) as s:
        s.add_all(
            [
                Country(id=1, name="Germany"),
                Country(id=2, name="USA"),
            ]
        )
        s.add_all(
            [
                Person(id=1, name="Alice", age=20, active=True, country_id=1),
                Person(id=2, name="Bob", age=30, active=True, country_id=1),
                Person(id=3, name="Carol", age=40, active=False, country_id=2),
            ]
        )
        s.commit()
        yield s
