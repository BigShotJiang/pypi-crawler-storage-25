from __future__ import annotations

import collections

import pytest
import sqlalchemy

from fastapi_rtk.backends.sqla.extensions.audit.audit import (
    BASE_AUDIT_TABLE_NAME,
    Audit,
    audit_model_factory,
)
from fastapi_rtk.backends.sqla.extensions.audit.types import AuditEntry, AuditOperation
from fastapi_rtk.backends.sqla.model import Model


class TestAuditModelFactory:
    def test_default_class_name(self):
        cls = audit_model_factory(
            class_name="TestAuditClassName", __tablename__="audit_class_name_test"
        )
        assert cls.__name__ == "TestAuditClassName"

    def test_default_tablename(self):
        cls = audit_model_factory(class_name="TestAuditTablenameDefault")
        assert cls.__tablename__ == BASE_AUDIT_TABLE_NAME

    def test_inherits_model(self):
        cls = audit_model_factory(
            class_name="TestAuditInherit", __tablename__="audit_inherit_test"
        )
        assert issubclass(cls, Model)

    def test_required_columns_present(self):
        cls = audit_model_factory(
            class_name="TestAuditCols", __tablename__="audit_cols_test"
        )
        cols = cls.__table__.columns.keys()
        for col in (
            "id",
            "created",
            "table_name",
            "table_id",
            "operation",
            "data",
            "updates",
            "created_by_fk",
        ):
            assert col in cols

    def test_postgresql_dialect_uses_jsonb(self):
        from sqlalchemy.dialects.postgresql import JSONB

        cls = audit_model_factory(
            class_name="TestAuditPG",
            dialects="postgresql",
            __tablename__="audit_pg_test",
        )
        col = cls.__table__.columns["data"]
        assert isinstance(col.type, JSONB)

    def test_default_dialect_uses_json(self):
        cls = audit_model_factory(
            class_name="TestAuditJSON", __tablename__="audit_json_test"
        )
        col = cls.__table__.columns["data"]
        assert isinstance(col.type, sqlalchemy.JSON)

    def test_repr_returns_string(self):
        cls = audit_model_factory(
            class_name="TestAuditRepr", __tablename__="audit_repr_test"
        )
        instance = cls(table_name="x", table_id="1", operation="insert")
        instance.id = 1
        instance.created = None
        instance.data = None
        instance.updates = None
        result = repr(instance)
        assert "table_name" in result


class TestAuditClassConfig:
    def test_audit_model_excluded(self):
        @Audit.exclude_model
        class TestExcludedModel(Model):
            __tablename__ = "test_excluded"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

        assert TestExcludedModel in Audit.excluded_models

    def test_audit_model_included(self):
        @Audit.audit_model
        class TestIncludedModel(Model):
            __tablename__ = "test_included"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

        assert TestIncludedModel in Audit.models

    def test_include_properties(self):
        @Audit.audit_model
        @Audit.include_properties(["name"])
        class TestIncludedPropsModel(Model):
            __tablename__ = "test_inc_props"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            name = sqlalchemy.Column(sqlalchemy.String(50))

        assert "name" in Audit.included_properties[TestIncludedPropsModel]

    def test_exclude_properties(self):
        @Audit.audit_model
        @Audit.exclude_properties(["password"])
        class TestExcludedPropsModel(Model):
            __tablename__ = "test_exc_props"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            password = sqlalchemy.Column(sqlalchemy.String(50))

        assert "password" in Audit.excluded_properties[TestExcludedPropsModel]

    def test_include_properties_string_separator(self):
        @Audit.audit_model
        @Audit.include_properties("a,b,c")
        class TestStrSepModel(Model):
            __tablename__ = "test_str_sep"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            a = sqlalchemy.Column(sqlalchemy.String(50))
            b = sqlalchemy.Column(sqlalchemy.String(50))
            c = sqlalchemy.Column(sqlalchemy.String(50))

        assert sorted(Audit.included_properties[TestStrSepModel]) == ["a", "b", "c"]

    def test_callback_registers_function(self):
        callbacks_before = len(Audit.callbacks)

        @Audit.callback
        async def my_callback(entry):
            pass

        assert len(Audit.callbacks) == callbacks_before + 1
        Audit.callbacks.remove(my_callback)

    def test_coalesce_updates(self):
        original = Audit._coalesce_updates
        Audit.coalesce_updates(False)
        assert Audit._coalesce_updates is False
        Audit.coalesce_updates(original)


class TestShouldAudit:
    def test_in_audited_models_returns_true(self):
        @Audit.audit_model
        class TestShouldAuditYes(Model):
            __tablename__ = "test_should_audit_yes"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

        assert Audit._should_audit(TestShouldAuditYes()) is True

    def test_excluded_model_returns_false(self):
        @Audit.exclude_model
        class TestShouldAuditNo(Model):
            __tablename__ = "test_should_audit_no"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

        assert Audit._should_audit(TestShouldAuditNo()) is False


class TestAuditDecoratorWithKwargs:
    """audit_model with include/exclude/insert_updates kwargs."""

    def test_audit_model_with_include_kwarg(self):
        decorator = Audit.audit_model(include="name,description")

        class Tracked1(Model):
            __tablename__ = "audit_kwarg_inc1"
            __table_args__ = {"extend_existing": True}
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            name = sqlalchemy.Column(sqlalchemy.String(80))
            description = sqlalchemy.Column(sqlalchemy.String(200))

        Tracked1 = decorator(Tracked1)
        assert Tracked1 in Audit.models
        assert "name" in Audit.included_properties[Tracked1]
        assert "description" in Audit.included_properties[Tracked1]

    def test_audit_model_with_exclude_kwarg(self):
        decorator = Audit.audit_model(exclude="password")

        class Tracked2(Model):
            __tablename__ = "audit_kwarg_exc"
            __table_args__ = {"extend_existing": True}
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            password = sqlalchemy.Column(sqlalchemy.String(80))

        Tracked2 = decorator(Tracked2)
        assert "password" in Audit.excluded_properties[Tracked2]

    def test_audit_model_with_insert_updates_kwarg(self):
        decorator = Audit.audit_model(insert_updates_when_no_changes=False)

        class Tracked3(Model):
            __tablename__ = "audit_kwarg_iu"
            __table_args__ = {"extend_existing": True}
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            name = sqlalchemy.Column(sqlalchemy.String(80))

        Tracked3 = decorator(Tracked3)
        assert Audit.mapping_insert_updates_when_no_changes[Tracked3] is False

    def test_audit_model_no_args_raises(self):
        with pytest.raises(ValueError, match="Model class must be provided"):
            Audit.audit_model()


class TestExcludePropertiesString:
    """exclude_properties splits string by separator."""

    def test_exclude_properties_with_str_separator(self):
        decorator = Audit.exclude_properties("a|b|c", separator="|")

        class Tracked4(Model):
            __tablename__ = "audit_exc_sep"
            __table_args__ = {"extend_existing": True}
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            a = sqlalchemy.Column(sqlalchemy.String(50))
            b = sqlalchemy.Column(sqlalchemy.String(50))
            c = sqlalchemy.Column(sqlalchemy.String(50))

        decorator(Tracked4)
        assert sorted(Audit.excluded_properties[Tracked4])[:3] == ["a", "b", "c"]


class TestInsertUpdatesWhenNoChanges:
    """insert_updates_when_no_changes setter + decorator forms."""

    def test_setter_default(self):
        original = Audit.mapping_insert_updates_when_no_changes_default
        Audit.insert_updates_when_no_changes(False)
        assert Audit.mapping_insert_updates_when_no_changes_default is False
        Audit.insert_updates_when_no_changes(original)

    def test_decorator_form(self):
        wrapped = Audit.insert_updates_when_no_changes(True, decorator=True)

        class TrackedIU(Model):
            __tablename__ = "audit_iu_dec"
            __table_args__ = {"extend_existing": True}
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

        wrapped(TrackedIU)
        assert Audit.mapping_insert_updates_when_no_changes[TrackedIU] is True


class TestRunInBackgroundImportError:
    """run_in_background ImportError path when apscheduler missing."""

    def test_run_in_background_apscheduler_missing(self, monkeypatch):
        import sys

        original = sys.modules.get("apscheduler.schedulers.asyncio")
        sys.modules.pop("apscheduler.schedulers.asyncio", None)
        sys.modules.pop("apscheduler.schedulers", None)
        sys.modules.pop("apscheduler", None)
        sys.modules["apscheduler"] = None  # type: ignore[assignment]

        try:
            with pytest.raises(ImportError, match="apscheduler is required"):
                Audit.run_in_background(True)
        finally:
            sys.modules.pop("apscheduler", None)
            if original is not None:
                sys.modules["apscheduler.schedulers.asyncio"] = original
            Audit._run_in_background = False


class TestSetModel:
    """set_model assigns audit table model."""

    def test_set_model_assigns_class(self):
        cls = audit_model_factory(
            class_name="SetModelTest",
            __tablename__="audit_set_model_test",
        )
        original = Audit.__dict__.get("model")
        Audit.set_model(cls)
        assert Audit.model is cls
        if original is not None:
            Audit.model = original


class TestCreateEntryHelper:
    """create_entry + create_table_sync."""

    def test_create_entry_callable_user_id(self):
        cls = audit_model_factory(
            class_name="CreateEntryTest",
            __tablename__="audit_create_entry_test",
        )
        Audit.set_model(cls)

        class FakeModel:
            __tablename__ = "x"
            id_ = "42"

        entry = AuditEntry(
            model=FakeModel,
            operation=AuditOperation.INSERT,
            pk="42",
            data={"foo": "bar"},
            updates=None,
        )
        out = Audit.create_entry(entry, user_id=lambda: 7)
        assert out.table_name == "x"
        assert out.table_id == "42"
        assert out.operation == AuditOperation.INSERT
        assert out.created_by_fk == 7

    def test_create_entry_int_user_id(self):
        cls = audit_model_factory(
            class_name="CreateEntryIntTest",
            __tablename__="audit_create_entry_int_test",
        )
        Audit.set_model(cls)

        class FakeModel:
            __tablename__ = "y"
            id_ = "99"

        entry = AuditEntry(
            model=FakeModel,
            operation=AuditOperation.UPDATE,
            pk="99",
            data={"foo": "qux"},
            updates={"foo": ("old", "qux")},
        )
        out = Audit.create_entry(entry, user_id=42)
        assert out.created_by_fk == 42


class TestAfterRollbackClearsCallbacks:
    """_after_rollback pops session state."""

    def test_after_rollback_clears(self):
        fake_session = object()
        Audit._session_callbacks_after_commit[fake_session].append(lambda: None)
        Audit._session_pending_entries[fake_session].append(
            AuditEntry(
                model=type("M", (), {"__tablename__": "x"}),
                operation=AuditOperation.INSERT,
                pk="1",
                data={},
                updates=None,
            )
        )
        Audit._after_rollback(fake_session)
        assert fake_session not in Audit._session_callbacks_after_commit
        assert fake_session not in Audit._session_pending_entries


class TestAfterCommitRunsCallbacks:
    """_after_commit pops + runs registered callbacks."""

    def test_after_commit_runs_each_callback(self):
        fake_session = object()
        called = []
        Audit._session_callbacks_after_commit[fake_session].append(
            lambda: called.append("a")
        )
        Audit._session_callbacks_after_commit[fake_session].append(
            lambda: called.append("b")
        )
        Audit._after_commit(fake_session)
        assert called == ["a", "b"]
        assert Audit._session_is_commited[fake_session] is True


class TestMergeUpdateEntries:
    """_merge_update_entries combines repeated UPDATEs."""

    def test_merge_update_entries_combines_updates(self):
        class FakeModel:
            __tablename__ = "merge_t"

        e1 = AuditEntry(
            model=FakeModel,
            operation=AuditOperation.UPDATE,
            pk="1",
            data={"name": "v1"},
            updates={"name": ("orig", "v1")},
        )
        e2 = AuditEntry(
            model=FakeModel,
            operation=AuditOperation.UPDATE,
            pk="1",
            data={"name": "v2", "age": 30},
            updates={"name": ("v1", "v2"), "age": (None, 30)},
        )
        merged = Audit._merge_update_entries([e1, e2])
        assert len(merged) == 1
        merged_updates = merged[0]["updates"]
        assert merged_updates["name"] == ("orig", "v2")
        assert merged_updates["age"] == (None, 30)

    def test_merge_update_entries_passes_through_non_update(self):
        class FakeModel:
            __tablename__ = "merge_t2"

        delete_entry = AuditEntry(
            model=FakeModel,
            operation=AuditOperation.DELETE,
            pk="9",
            data=None,
            updates=None,
        )
        merged = Audit._merge_update_entries([delete_entry])
        assert merged == [delete_entry]


class TestGetAuditPropertiesExcludeInheritance:
    """_get_audit_properties walks excluded_properties for parent classes."""

    def test_inherited_excluded_properties(self):
        @Audit.audit_model
        @Audit.exclude_properties(["secret"])
        class ParentTracked(Model):
            __tablename__ = "audit_parent_tr"
            __table_args__ = {"extend_existing": True}
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            secret = sqlalchemy.Column(sqlalchemy.String(50))
            visible = sqlalchemy.Column(sqlalchemy.String(50))

        instance = ParentTracked(id=1, secret="x", visible="y")
        props = Audit._get_audit_properties(instance)
        assert "secret" not in props
        assert "visible" in props


class TestProcessModelOperationsDelete:
    """_process_model_operations DELETE branch."""

    def test_process_delete_only(self):
        class FakeModel:
            __tablename__ = "proc_del_t"
            id_ = "11"

        deque = collections.deque(
            [
                (FakeModel, AuditOperation.DELETE, [], {}),
            ]
        )
        result = Audit._process_model_operations(deque)
        assert len(result) == 1
        assert result[0]["operation"] == AuditOperation.DELETE
        assert result[0]["pk"] == "11"


class TestRunCallbacks:
    """_run_callbacks invokes registered callbacks."""

    @pytest.mark.asyncio
    async def test_run_callbacks_dispatches(self):
        called = []

        async def my_callback(entry):
            called.append(entry)

        Audit.callbacks.append(my_callback)
        try:

            class FakeModel:
                __tablename__ = "rcb_t"

            entries = [
                AuditEntry(
                    model=FakeModel,
                    operation=AuditOperation.INSERT,
                    pk="x",
                    data={"a": 1},
                    updates=None,
                ),
            ]
            await Audit._run_callbacks(entries)
            assert len(called) == 1
        finally:
            Audit.callbacks.remove(my_callback)


# ---------------------------------------------------------------------------
# Full lifecycle: real sync sqlalchemy.orm.Session driving INSERT/UPDATE/DELETE
# through the audit listeners. Covers insert_entries, _before_commit existing-
# session branch, _after_flush merge path, _process_model_operations
# INSERT/UPDATE branches, and _get_model_operations new/dirty/deleted scans.
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def lifecycle_engine_and_models():
    """Fresh sync sqlite engine + a Tracked model + a generated audit table.

    Module-scoped because audit_model_factory + Model declarative metadata
    don't tolerate redeclaration across tests. Each test uses unique row
    ids so cross-test pollution is bounded.
    """
    from sqlalchemy.pool import StaticPool

    from fastapi_rtk.backends.sqla.interface import SQLAInterface

    saved_models = list(Audit.models)
    saved_excluded = list(Audit.excluded_models)
    saved_callbacks = list(Audit.callbacks)
    saved_run_bg = Audit._run_in_background
    saved_coalesce = Audit._coalesce_updates
    saved_default_iu = Audit.mapping_insert_updates_when_no_changes_default
    saved_model_attr = Audit.__dict__.get("model")
    Audit.models.clear()
    Audit.excluded_models.clear()
    Audit.callbacks.clear()
    Audit._coalesce_updates = True
    Audit.mapping_insert_updates_when_no_changes_default = False

    @Audit.audit_model
    class Tracked(Model):
        __tablename__ = "lc_tracked"
        __table_args__ = {"extend_existing": True}
        id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
        name = sqlalchemy.Column(sqlalchemy.String(50))
        description = sqlalchemy.Column(sqlalchemy.String(200))

    @Audit.exclude_model
    class Skipped(Model):
        __tablename__ = "lc_skipped"
        __table_args__ = {"extend_existing": True}
        id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
        name = sqlalchemy.Column(sqlalchemy.String(50))

    AuditTable = audit_model_factory(
        class_name="LcAuditTable",
        __tablename__="lc_audit",
    )
    Audit.set_model(AuditTable)
    Audit.interfaces[Tracked] = SQLAInterface(Tracked)

    eng = sqlalchemy.create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Tracked.__table__.create(eng)
    Skipped.__table__.create(eng)
    AuditTable.__table__.create(eng)

    try:
        yield eng, Tracked, Skipped, AuditTable
    finally:
        eng.dispose()
        Audit.models[:] = saved_models
        Audit.excluded_models[:] = saved_excluded
        Audit.callbacks[:] = saved_callbacks
        Audit._run_in_background = saved_run_bg
        Audit._coalesce_updates = saved_coalesce
        Audit.mapping_insert_updates_when_no_changes_default = saved_default_iu
        if saved_model_attr is not None:
            Audit.model = saved_model_attr


class TestAuditLifecycleIntegration:
    """Drive INSERT/UPDATE/DELETE through a real sync Session and assert the
    audit table receives matching rows."""

    def _audit_for(self, engine, AuditTable, table_id):
        from sqlalchemy.orm import Session

        with Session(engine) as s:
            return list(
                s.query(AuditTable)
                .filter(AuditTable.table_id == str(table_id))
                .order_by(AuditTable.id)
                .all()
            )

    def test_insert_writes_audit_row(self, lifecycle_engine_and_models):
        from sqlalchemy.orm import Session

        engine, Tracked, _, AuditTable = lifecycle_engine_and_models
        with Session(engine) as s:
            s.add(Tracked(id=101, name="alpha", description="first"))
            s.flush()
            s.commit()

        rows = self._audit_for(engine, AuditTable, 101)
        assert len(rows) == 1
        assert rows[0].operation == AuditOperation.INSERT
        assert rows[0].table_name == "lc_tracked"
        assert rows[0].data["name"] == "alpha"

    def test_update_writes_audit_row_with_diff(self, lifecycle_engine_and_models):
        from sqlalchemy.orm import Session

        engine, Tracked, _, AuditTable = lifecycle_engine_and_models
        with Session(engine) as s:
            s.add(Tracked(id=102, name="orig", description="d"))
            s.flush()
            s.commit()
        with Session(engine) as s:
            obj = s.get(Tracked, 102)
            obj.name = "renamed"
            s.flush()
            s.commit()

        rows = self._audit_for(engine, AuditTable, 102)
        ops = [r.operation for r in rows]
        assert AuditOperation.INSERT in ops
        assert AuditOperation.UPDATE in ops
        update_row = next(r for r in rows if r.operation == AuditOperation.UPDATE)
        assert "name" in update_row.updates
        old, new = update_row.updates["name"]
        assert old == "orig"
        assert new == "renamed"

    def test_delete_writes_audit_row(self, lifecycle_engine_and_models):
        from sqlalchemy.orm import Session

        engine, Tracked, _, AuditTable = lifecycle_engine_and_models
        with Session(engine) as s:
            s.add(Tracked(id=103, name="doomed"))
            s.flush()
            s.commit()
        with Session(engine) as s:
            obj = s.get(Tracked, 103)
            s.delete(obj)
            s.flush()
            s.commit()

        rows = self._audit_for(engine, AuditTable, 103)
        ops = [r.operation for r in rows]
        assert AuditOperation.DELETE in ops

    def test_excluded_model_not_audited(self, lifecycle_engine_and_models):
        from sqlalchemy.orm import Session

        engine, _, Skipped, AuditTable = lifecycle_engine_and_models
        with Session(engine) as s:
            s.add(Skipped(id=104, name="ignored"))
            s.flush()
            s.commit()

        # Audit rows for an excluded model are scoped by tablename; query both
        # to be defensive against any cross-test bleed.
        from sqlalchemy.orm import Session as _S

        with _S(engine) as s:
            rows = list(
                s.query(AuditTable).filter(AuditTable.table_name == "lc_skipped").all()
            )
        assert rows == []

    def test_rollback_discards_pending(self, lifecycle_engine_and_models):
        from sqlalchemy.orm import Session

        engine, Tracked, _, AuditTable = lifecycle_engine_and_models
        with Session(engine) as s:
            s.add(Tracked(id=105, name="ghost"))
            s.flush()
            s.rollback()

        rows = self._audit_for(engine, AuditTable, 105)
        assert rows == []

    def test_coalesced_repeat_updates_become_single_entry(
        self, lifecycle_engine_and_models
    ):
        from sqlalchemy.orm import Session

        engine, Tracked, _, AuditTable = lifecycle_engine_and_models
        with Session(engine) as s:
            s.add(Tracked(id=106, name="v0", description="d0"))
            s.flush()
            s.commit()
        with Session(engine) as s:
            obj = s.get(Tracked, 106)
            obj.name = "v1"
            s.flush()
            obj.name = "v2"
            s.flush()
            s.commit()

        update_rows = [
            r
            for r in self._audit_for(engine, AuditTable, 106)
            if r.operation == AuditOperation.UPDATE
        ]
        assert len(update_rows) == 1
        old, new = update_rows[0].updates["name"]
        assert old == "v0"
        assert new == "v2"

    def test_update_with_no_actual_changes_skipped_by_default(
        self, lifecycle_engine_and_models
    ):
        from sqlalchemy.orm import Session

        engine, Tracked, _, AuditTable = lifecycle_engine_and_models
        with Session(engine) as s:
            s.add(Tracked(id=107, name="same"))
            s.flush()
            s.commit()
        with Session(engine) as s:
            obj = s.get(Tracked, 107)
            obj.name = "different"
            obj.name = "same"
            s.flush()
            s.commit()

        update_rows = [
            r
            for r in self._audit_for(engine, AuditTable, 107)
            if r.operation == AuditOperation.UPDATE
        ]
        assert update_rows == []


class TestRunInBackgroundWithApscheduler:
    """run_in_background(True) initialises an AsyncIOScheduler when
    apscheduler is installed, then run_in_background(False) tears it down.
    AsyncIOScheduler.start() needs a running event loop so this test is
    async."""

    @pytest.mark.asyncio
    async def test_starts_scheduler(self):
        pytest.importorskip("apscheduler")
        original_run_bg = Audit._run_in_background
        try:
            Audit.run_in_background(True)
            assert Audit._run_in_background is True
            assert Audit.scheduler.running
        finally:
            try:
                Audit.scheduler.shutdown(wait=False)
            except Exception:
                pass
            Audit._run_in_background = original_run_bg
            Audit.run_in_background(False)


class TestRunAsyncFunctionOrDelegateToRunner:
    """_run_async_function_or_delegate_to_runner: success path returns the
    awaited result via safe_call_sync."""

    def test_successful_coroutine_runs_synchronously(self):
        called = []

        async def my_async(x):
            called.append(x)
            return x * 2

        result = Audit._run_async_function_or_delegate_to_runner(my_async, 5)
        assert result == 10
        assert called == [5]

    def test_failing_coroutine_with_no_runner_logs_and_returns_none(self):
        async def my_async():
            raise RuntimeError("boom")

        # No active AsyncTaskRunner → except RuntimeError → logs error,
        # returns None.
        result = Audit._run_async_function_or_delegate_to_runner(my_async)
        assert result is None



class TestCreateTableSync:
    """create_table_sync delegates to run_coroutine_in_threadpool around the
    async create_table. Patch create_table to a no-op coroutine so we don't
    need a real db engine."""

    def test_create_table_sync_invokes_create_table(self, monkeypatch):
        called = []

        async def fake_create_table():
            called.append("ran")
            return "done"

        monkeypatch.setattr(Audit, "create_table", fake_create_table)
        result = Audit.create_table_sync()
        assert called == ["ran"]
        assert result == "done"


class TestInsertEntriesDirect:
    """Direct calls into insert_entries to cover commit=True success branch
    and the error/raise_exception path."""

    @pytest.fixture(scope="class")
    def sync_engine_and_audit(self):
        from sqlalchemy.orm import Session
        from sqlalchemy.pool import StaticPool

        AuditCls = audit_model_factory(
            class_name="DirectAuditTable",
            __tablename__="direct_audit_table",
        )
        saved_model = Audit.__dict__.get("model")
        Audit.set_model(AuditCls)

        eng = sqlalchemy.create_engine(
            "sqlite://",
            connect_args={"check_same_thread": False},
            poolclass=StaticPool,
        )
        AuditCls.__table__.create(eng)
        try:
            yield eng, AuditCls, Session
        finally:
            eng.dispose()
            if saved_model is not None:
                Audit.model = saved_model

    @pytest.mark.asyncio
    async def test_insert_entries_commit_true_writes_and_runs_callbacks(
        self, sync_engine_and_audit
    ):
        engine, AuditCls, Session = sync_engine_and_audit

        called = []

        async def cb(entry):
            called.append(entry["pk"])

        Audit.callbacks.append(cb)
        try:

            class FakeModel:
                __tablename__ = "fake_t"

            entry = AuditEntry(
                model=FakeModel,
                operation=AuditOperation.INSERT,
                pk="abc",
                data={"x": 1},
                updates=None,
            )
            with Session(engine) as s:
                await Audit.insert_entries(
                    [entry], user_id=1, session=s, commit=True
                )
            with Session(engine) as s:
                rows = list(s.query(AuditCls).all())
            assert len(rows) == 1
            assert rows[0].table_id == "abc"
            assert called == ["abc"]
        finally:
            Audit.callbacks.remove(cb)

    @pytest.mark.asyncio
    async def test_insert_entries_raise_exception_propagates(
        self, sync_engine_and_audit
    ):
        engine, AuditCls, Session = sync_engine_and_audit

        class FakeModel:
            __tablename__ = "fake_t2"

        entry = AuditEntry(
            model=FakeModel,
            operation=AuditOperation.INSERT,
            pk="x",
            data={"x": 1},
            updates=None,
        )

        # Pass a session that fails on add_all to trigger the except branch.
        class BadSession:
            def add_all(self, _):
                raise RuntimeError("session boom")

        bad = BadSession()
        # _session_is_commited is a defaultdict; pre-set to False so the
        # initial lookup doesn't raise.
        Audit._session_is_commited[bad] = False
        try:
            with pytest.raises(RuntimeError, match="session boom"):
                await Audit.insert_entries(
                    [entry], user_id=1, session=bad, raise_exception=True
                )
        finally:
            Audit._session_is_commited.pop(bad, None)

    @pytest.mark.asyncio
    async def test_insert_entries_swallows_when_raise_exception_false(
        self, sync_engine_and_audit
    ):
        engine, AuditCls, Session = sync_engine_and_audit

        class FakeModel:
            __tablename__ = "fake_t3"

        entry = AuditEntry(
            model=FakeModel,
            operation=AuditOperation.INSERT,
            pk="x",
            data=None,
            updates=None,
        )

        class BadSession:
            def add_all(self, _):
                raise RuntimeError("ignored")

        bad = BadSession()
        Audit._session_is_commited[bad] = False
        try:
            result = await Audit.insert_entries(
                [entry], user_id=1, session=bad, raise_exception=False
            )
            assert result is None
        finally:
            Audit._session_is_commited.pop(bad, None)


class TestBeforeCommitWithoutExistingSession:
    """When no entry's bind_key matches the audit Model's bind_key,
    _before_commit registers a callback_for_commit that runs insert_entries
    without an existing session (the session=None / commit=True branch)."""

    def test_before_commit_with_mismatched_bind_key_registers_callback(self):
        # Create a fake Audit Model with __bind_key__ = "audit_db".
        AuditCls = audit_model_factory(
            class_name="BindKeyAuditTable",
            __tablename__="bind_key_audit_table",
            __bind_key__="audit_db",
        )
        saved_model = Audit.__dict__.get("model")
        Audit.set_model(AuditCls)

        class OtherModel:
            __tablename__ = "other_t"
            __bind_key__ = "other_db"

        fake_session = object()
        entry = AuditEntry(
            model=OtherModel,
            operation=AuditOperation.INSERT,
            pk="z",
            data=None,
            updates=None,
        )
        Audit._session_pending_entries[fake_session] = [entry]

        try:
            Audit._before_commit(fake_session)
            callbacks = Audit._session_callbacks_after_commit.get(fake_session, [])
            assert len(callbacks) == 1
        finally:
            Audit._session_callbacks_after_commit.pop(fake_session, None)
            Audit._session_pending_entries.pop(fake_session, None)
            if saved_model is not None:
                Audit.model = saved_model
