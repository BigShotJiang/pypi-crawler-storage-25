import typing

from sqlalchemy import Connection as SAConnection
from sqlalchemy.ext.asyncio import AsyncConnection as SAAsyncConnection
from sqlalchemy.ext.asyncio import AsyncSession as SAAsyncSession
from sqlalchemy.orm import Session as SASession

from fastapi_rtk.backends.sqla.session import (
    AsyncConnection,
    AsyncSession,
    Connection,
    Session,
    SQLAConnection,
    SQLASession,
)


class TestReExports:
    def test_session_alias(self):
        assert Session is SASession

    def test_async_session_alias(self):
        assert AsyncSession is SAAsyncSession

    def test_connection_alias(self):
        assert Connection is SAConnection

    def test_async_connection_alias(self):
        assert AsyncConnection is SAAsyncConnection


class TestUnionAliases:
    def test_sqla_session_is_union(self):
        # SQLASession = Session | AsyncSession
        assert typing.get_args(SQLASession) == (SASession, SAAsyncSession)

    def test_sqla_connection_is_union(self):
        assert typing.get_args(SQLAConnection) == (SAConnection, SAAsyncConnection)
