import pytest

from fastapi_rtk.backends.sqla.db import (
    SQLAQueryBuilder,
    create_load_column,
)
from fastapi_rtk.backends.sqla.interface import SQLAInterface
from fastapi_rtk.exceptions import HTTPWithValidationException


@pytest.fixture
def iface(Person_cls):
    return SQLAInterface(Person_cls)


class TestCreateLoadColumn:
    def test_default_values(self):
        lc = create_load_column()
        assert lc["statement"] is None
        assert lc["type"] == "defer"
        assert lc["columns"] == []

    def test_with_statement(self):
        lc = create_load_column(statement="STMT")
        assert lc["statement"] == "STMT"


@pytest.mark.asyncio
class TestQueryBuilderBasic:
    async def test_pagination_via_iface(self, session, iface):
        result = await iface.get_many(session, {"page": 0, "page_size": 2})
        assert len(result) == 2

    async def test_order_by_strips_class_prefix(self, session, iface):
        result = await iface.get_many(
            session, {"order_column": "Person.age", "order_direction": "asc"}
        )
        assert [p.age for p in result] == [20, 30, 40]

    async def test_apply_where(self, session, iface):
        result = await iface.get_many(session, {"where": ("name", "Alice")})
        assert [p.name for p in result] == ["Alice"]

    async def test_apply_where_in(self, session, iface):
        result = await iface.get_many(
            session, {"where_in": ("name", ["Alice", "Bob"])}
        )
        names = sorted(p.name for p in result)
        assert names == ["Alice", "Bob"]


@pytest.mark.asyncio
class TestQueryBuilderFilters:
    async def test_apply_filter_invalid_opr_raises(self, session, iface):
        with pytest.raises(HTTPWithValidationException):
            await iface.get_many(
                session,
                {"filters": [{"col": "name", "opr": "bogus_op", "value": "x"}]},
            )

    async def test_apply_filter_via_eq(self, session, iface):
        result = await iface.get_many(
            session, {"filters": [{"col": "name", "opr": "eq", "value": "Bob"}]}
        )
        assert [p.name for p in result] == ["Bob"]


@pytest.mark.asyncio
class TestListColumns:
    async def test_simple_columns_loaded(self, session, iface):
        result = await iface.get_many(session, {"list_columns": ["id", "name"]})
        assert all(p.id is not None for p in result)
        assert all(p.name for p in result)

    async def test_caching_does_not_break_repeated_calls(self, session, iface):
        # Run twice to exercise cache hit
        await iface.get_many(session, {"list_columns": ["id", "name"]})
        result = await iface.get_many(session, {"list_columns": ["id", "name"]})
        assert len(result) == 3

    async def test_list_columns_with_relation(self, session, iface):
        # `country` is a relation; the load path joins the related interface
        result = await iface.get_many(
            session, {"list_columns": ["id", "name", "country"]}
        )
        assert len(result) == 3

    async def test_list_columns_with_nested_relation(self, session, iface):
        # `country.name` exercises nested-relation load path
        result = await iface.get_many(
            session, {"list_columns": ["id", "name", "country.name"]}
        )
        assert len(result) == 3


@pytest.mark.asyncio
class TestRelationFiltering:
    async def test_filter_via_relation_subcol(self, session, iface):
        # Filter Person by country.name (one-to-many relation -> .has())
        result = await iface.get_many(
            session,
            {
                "filters": [
                    {"col": "country.name", "opr": "eq", "value": "Germany"}
                ]
            },
        )
        assert len(result) == 2
        assert all(p.country_id == 1 for p in result)

    async def test_filter_relation_subcol_no_match(self, session, iface):
        result = await iface.get_many(
            session,
            {
                "filters": [
                    {"col": "country.name", "opr": "eq", "value": "Atlantis"}
                ]
            },
        )
        assert len(result) == 0


@pytest.mark.asyncio
class TestOrderByOnRelation:
    async def test_order_by_relation_column(self, session, iface):
        # Ordering by `country.name` requires joining the related interface
        result = await iface.get_many(
            session,
            {"order_column": "country.name", "order_direction": "asc"},
        )
        # Three rows present; the ordering doesn't need to be exhaustively
        # asserted - what matters is the join+order path executed.
        assert len(result) == 3

    async def test_order_by_descending(self, session, iface):
        result = await iface.get_many(
            session, {"order_column": "age", "order_direction": "desc"}
        )
        assert [p.age for p in result] == [40, 30, 20]


@pytest.mark.asyncio
class TestApplyOprFilter:
    """Cover sqla/db lines 184-204 - apply_opr_filter unknown opr + dispatch."""

    async def test_unknown_opr_raises(self, session, iface):
        from fastapi_rtk.schemas import OprFilterSchema

        qb = SQLAQueryBuilder(iface)
        from sqlalchemy import select

        stmt = select(iface.obj)
        with pytest.raises(HTTPWithValidationException):
            await qb.apply_opr_filter(
                stmt, OprFilterSchema(opr="ghost_op", value="x")
            )

    async def test_known_opr_dispatches(self, session, iface):
        from fastapi_rtk.schemas import OprFilterSchema

        qb = SQLAQueryBuilder(iface)
        from sqlalchemy import select

        stmt = select(iface.obj)
        # opr_filters table on Person - find any registered opr by name
        opr_names = [f.arg_name for f in iface.opr_filters]
        if opr_names:
            stmt = await qb.apply_opr_filter(
                stmt, OprFilterSchema(opr=opr_names[0], value="x")
            )
            session.execute(stmt).scalars().all()  # smoke

    async def test_apply_opr_filter_class_direct(self, session, iface):
        qb = SQLAQueryBuilder(iface)
        from sqlalchemy import select

        stmt = select(iface.obj)
        # Pull a registered opr-filter class
        if iface.opr_filters:
            cls = iface.opr_filters[0]
            stmt = await qb.apply_opr_filter_class(stmt, cls, "x")


@pytest.mark.asyncio
class TestRelationFilterDispatch:
    """Cover line 179 - apply_filter_class with `.` in col routes through _filter_relation."""

    async def test_filter_class_with_dotted_col(self, session, iface):
        from fastapi_rtk.backends.sqla.filters import FilterEqual
        from sqlalchemy import select

        qb = SQLAQueryBuilder(iface)
        stmt = select(iface.obj)
        # _filter_relation expects a filter instance bound to the related interface
        rel_iface = iface.get_related_interface("country")
        filter_inst = FilterEqual(rel_iface)
        stmt = await qb.apply_filter_class(stmt, "country.name", filter_inst, "Germany")
        result = session.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Alice", "Bob"}


@pytest.mark.asyncio
class TestLoadColumnDeferAndCache:
    """Cover lines 339-349 + cache list-options path (104)."""

    async def test_defer_type_via_no_columns(self, session, iface):
        # When list_columns is missing/empty, defer non-relation user cols
        result = await iface.get_many(session, {})
        assert len(result) >= 1

    async def test_load_column_cache_hit_with_list(self, session, iface):
        # First call populates cache; second call hits the cached list-of-options branch
        await iface.get_many(session, {"list_columns": ["country"]})
        await iface.get_many(session, {"list_columns": ["country"]})  # cache hit


class _CacheWidget:
    """Module-level helper class declared lazily inside the test methods to
    avoid `extend_existing` collisions during collection across files."""


@pytest.mark.asyncio
class TestApplyListColumnsCache:
    """Lines 100-107: cache-hit branch in apply_list_columns."""

    async def test_apply_list_columns_cache_hit_via_repeated_call(self):
        from sqlalchemy.ext.asyncio import (
            AsyncSession,
            async_sessionmaker,
            create_async_engine,
        )
        import sqlalchemy as _sa

        from fastapi_rtk.backends.sqla.interface import SQLAInterface
        from fastapi_rtk.backends.sqla.model import Model

        class CacheWidgetDb(Model):
            __tablename__ = "cache_widget_db"
            __table_args__ = {"extend_existing": True}
            id = _sa.Column(_sa.Integer, primary_key=True)
            name = _sa.Column(_sa.String(20))

        engine = create_async_engine("sqlite+aiosqlite:///:memory:")
        async with engine.begin() as conn:
            await conn.run_sync(
                lambda c: CacheWidgetDb.__table__.create(c, checkfirst=True)
            )
        sm = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

        async with sm() as session:
            interface = SQLAInterface(CacheWidgetDb)
            qb = interface.query
            stmt1 = qb.apply_list_columns(_sa.select(CacheWidgetDb), ["name"])
            stmt2 = qb.apply_list_columns(_sa.select(CacheWidgetDb), ["name"])
            assert stmt1 is not None and stmt2 is not None

        await engine.dispose()


@pytest.mark.asyncio
class TestApplyFilterClassHeavy:
    """Lines 312-313: `is_heavy` filter dispatched via smart_run."""

    async def test_heavy_filter_uses_smart_run(self):
        from sqlalchemy.ext.asyncio import (
            AsyncSession,
            async_sessionmaker,
            create_async_engine,
        )
        import sqlalchemy as _sa

        from fastapi_rtk.backends.sqla.filters import BaseFilter
        from fastapi_rtk.backends.sqla.interface import SQLAInterface
        from fastapi_rtk.backends.sqla.model import Model

        class HeavyWidgetDb(Model):
            __tablename__ = "heavy_widget_db"
            __table_args__ = {"extend_existing": True}
            id = _sa.Column(_sa.Integer, primary_key=True)
            name = _sa.Column(_sa.String(50))

        engine = create_async_engine("sqlite+aiosqlite:///:memory:")
        async with engine.begin() as conn:
            await conn.run_sync(
                lambda c: HeavyWidgetDb.__table__.create(c, checkfirst=True)
            )
        sm = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

        async with sm() as session:
            session.add(HeavyWidgetDb(name="A"))
            session.add(HeavyWidgetDb(name="B"))
            await session.commit()

        interface = SQLAInterface(HeavyWidgetDb)

        class HeavyEqualFilter(BaseFilter):
            arg_name = "heavy_eq"
            translation_key = "heavy_eq"
            is_heavy = True

            def apply(self, statement, col, value):
                return statement.where(getattr(self.datamodel.obj, col) == value)

        async with sm() as session:
            stmt = _sa.select(HeavyWidgetDb)
            stmt = await interface.query.apply_filter_class(
                stmt, "name", HeavyEqualFilter(interface), "A"
            )
            result = (await session.execute(stmt)).scalars().all()
            assert len(result) == 1
            assert result[0].name == "A"

        await engine.dispose()
