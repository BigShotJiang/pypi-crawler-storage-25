from fastapi_rtk.backends.sqla.extensions.audit.types import (
    AuditEntry,
    AuditOperation,
)


class TestAuditOperation:
    def test_is_str_enum(self):
        assert issubclass(AuditOperation, str)

    def test_values(self):
        assert AuditOperation.INSERT.value == "insert"
        assert AuditOperation.UPDATE.value == "update"
        assert AuditOperation.DELETE.value == "delete"

    def test_members(self):
        assert {m.name for m in AuditOperation} == {"INSERT", "UPDATE", "DELETE"}


class TestAuditEntry:
    def test_typed_dict_keys(self):
        e = AuditEntry(
            model=None,
            operation=AuditOperation.INSERT,
            pk=1,
            data={"x": 1},
            updates=None,
        )
        assert e["operation"] == AuditOperation.INSERT
        assert e["pk"] == 1
        assert e["data"] == {"x": 1}
