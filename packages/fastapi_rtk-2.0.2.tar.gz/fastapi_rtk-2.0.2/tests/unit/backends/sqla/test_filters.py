import pytest
from sqlalchemy import select

from fastapi_rtk.backends.sqla.filters import (
    FilterBetween,
    FilterContains,
    FilterEndsWith,
    FilterEqual,
    FilterGreater,
    FilterGreaterEqual,
    FilterIn,
    FilterNotContains,
    FilterNotEndsWith,
    FilterNotEqual,
    FilterNotStartsWith,
    FilterSmaller,
    FilterSmallerEqual,
    FilterStartsWith,
    FilterTextContains,
    SQLAFilterConverter,
)
from fastapi_rtk.backends.sqla.interface import SQLAInterface
from fastapi_rtk.exceptions import HTTPWithValidationException


@pytest.fixture
def iface(Person_cls):
    return SQLAInterface(Person_cls)


def _exec(session, iface, filter_cls, col, value):
    stmt = select(iface.obj)
    f = filter_cls(iface)
    stmt = f.apply(stmt, col, value)
    return session.execute(stmt).scalars().all()


class TestFilterEqual:
    def test_string(self, session, iface, Person_cls):
        result = _exec(session, iface, FilterEqual, "name", "Alice")
        assert [p.name for p in result] == ["Alice"]

    def test_integer(self, session, iface, Person_cls):
        result = _exec(session, iface, FilterEqual, "age", 30)
        assert [p.name for p in result] == ["Bob"]


class TestFilterNotEqual:
    def test_string(self, session, iface, Person_cls):
        result = _exec(session, iface, FilterNotEqual, "name", "Alice")
        names = [p.name for p in result]
        assert "Alice" not in names


class TestFilterStartsAndEnds:
    def test_starts_with(self, session, iface):
        result = _exec(session, iface, FilterStartsWith, "name", "A")
        assert [p.name for p in result] == ["Alice"]

    def test_not_starts_with(self, session, iface):
        result = _exec(session, iface, FilterNotStartsWith, "name", "A")
        assert all(p.name != "Alice" for p in result)

    def test_ends_with(self, session, iface):
        result = _exec(session, iface, FilterEndsWith, "name", "ol")
        assert [p.name for p in result] == ["Carol"]

    def test_not_ends_with(self, session, iface):
        result = _exec(session, iface, FilterNotEndsWith, "name", "ol")
        assert all(p.name != "Carol" for p in result)


class TestFilterContains:
    def test_contains(self, session, iface):
        result = _exec(session, iface, FilterContains, "name", "ar")
        assert [p.name for p in result] == ["Carol"]

    def test_not_contains(self, session, iface):
        result = _exec(session, iface, FilterNotContains, "name", "ar")
        assert all(p.name != "Carol" for p in result)


class TestFilterComparisons:
    def test_greater(self, session, iface):
        result = _exec(session, iface, FilterGreater, "age", "25")
        ages = sorted(p.age for p in result)
        assert ages == [30, 40]

    def test_smaller(self, session, iface):
        result = _exec(session, iface, FilterSmaller, "age", "35")
        ages = sorted(p.age for p in result)
        assert ages == [20, 30]

    def test_greater_equal(self, session, iface):
        result = _exec(session, iface, FilterGreaterEqual, "age", "30")
        ages = sorted(p.age for p in result)
        assert ages == [30, 40]

    def test_smaller_equal(self, session, iface):
        result = _exec(session, iface, FilterSmallerEqual, "age", "30")
        ages = sorted(p.age for p in result)
        assert ages == [20, 30]


class TestFilterIn:
    def test_in(self, session, iface):
        result = _exec(session, iface, FilterIn, "name", ["Alice", "Bob"])
        names = sorted(p.name for p in result)
        assert names == ["Alice", "Bob"]


class TestFilterBetween:
    def test_between_int(self, session, iface):
        result = _exec(session, iface, FilterBetween, "age", ["20", "30"])
        ages = sorted(p.age for p in result)
        assert ages == [20, 30]

    def test_between_empty_value_skipped(self, session, iface):
        result = _exec(session, iface, FilterBetween, "age", [])
        # No filter -> all rows
        assert len(result) == 3

    def test_between_wrong_arity_raises(self, session, iface):
        with pytest.raises(HTTPWithValidationException):
            _exec(session, iface, FilterBetween, "age", ["20"])

    def test_between_with_none_returns_unfiltered(self, session, iface):
        result = _exec(session, iface, FilterBetween, "age", [None, "30"])
        assert len(result) == 3  # NULL bounds skip filter


class TestFilterTextContains:
    def test_basic(self, session, iface):
        result = _exec(session, iface, FilterTextContains, "name", "lic")
        assert [p.name for p in result] == ["Alice"]

    def test_separator_split(self, session, iface, config_setter):
        config_setter("TEXT_FILTER_SEPARATOR", ";")
        # Should match Alice (lic) AND something with "20"... but and_ requires ALL match
        # Just verify "lic" alone works
        result = _exec(session, iface, FilterTextContains, "name", "lic")
        assert [p.name for p in result] == ["Alice"]

    def test_boolean_column_true(self, session, iface):
        result = _exec(session, iface, FilterTextContains, "active", "true")
        assert all(p.active for p in result)
        assert len(result) == 2

    def test_boolean_column_false(self, session, iface):
        result = _exec(session, iface, FilterTextContains, "active", "false")
        assert all(not p.active for p in result)


class TestCastValue:
    def test_null_string_to_none(self, iface):
        f = FilterEqual(iface)
        assert f._cast_value("name", "NULL") is None

    def test_list_recursive(self, iface):
        f = FilterEqual(iface)
        assert f._cast_value("age", ["1", "2"]) == [1, 2]

    def test_string_cast(self, iface):
        f = FilterEqual(iface)
        assert f._cast_value("name", 42) == "42"

    def test_integer_cast(self, iface):
        f = FilterEqual(iface)
        assert f._cast_value("age", "5") == 5

    def test_invalid_cast_returns_value(self, iface, caplog):
        f = FilterEqual(iface)
        with caplog.at_level("WARNING", logger="DT_FASTAPI"):
            result = f._cast_value("age", "not-int")
        assert result == "not-int"

    def test_boolean_true_string(self, iface):
        f = FilterEqual(iface)
        assert f._cast_value("active", "true") is True

    def test_boolean_one(self, iface):
        f = FilterEqual(iface)
        assert f._cast_value("active", 1) is True

    def test_boolean_false_string(self, iface):
        f = FilterEqual(iface)
        assert f._cast_value("active", "false") is False


class TestSQLAFilterConverter:
    def test_conversion_table_present(self):
        keys = [t[0] for t in SQLAFilterConverter.conversion_table]
        for k in ("is_string", "is_integer", "is_boolean"):
            assert k in keys

    def test_is_list_row_present_before_is_json(self):
        keys = [t[0] for t in SQLAFilterConverter.conversion_table]
        assert "is_list" in keys
        assert keys.index("is_list") < keys.index("is_json")

    def test_is_list_filter_set_minimal(self):
        from fastapi_rtk.backends.sqla.filters import (
            FilterEqual,
            FilterNotEqual,
            FilterTextContains,
        )

        row = next(t for t in SQLAFilterConverter.conversion_table if t[0] == "is_list")
        assert row[1] == [FilterTextContains, FilterEqual, FilterNotEqual]

    def test_init_filters_picks_list_row_for_list_column(self):
        import sqlalchemy

        from fastapi_rtk import ListColumn, Mapped, mapped_column
        from fastapi_rtk.backends.sqla.filters import (
            FilterEqual,
            FilterNotEqual,
            FilterTextContains,
        )
        from fastapi_rtk.backends.sqla.model import Model

        class _ListFilterModel(Model):
            __tablename__ = "list_filter_model"
            __table_args__ = {"extend_existing": True}
            id: Mapped[int] = mapped_column(sqlalchemy.Integer, primary_key=True)
            tags: Mapped[list[str] | None] = mapped_column(ListColumn(str))

        iface = SQLAInterface(_ListFilterModel)
        filters = iface.init_filters()
        assert "tags" in filters
        applied = [type(f) for f in filters["tags"]]
        assert applied == [FilterTextContains, FilterEqual, FilterNotEqual]


class TestFilterRelationOneToOneOrManyToOne:
    def test_equal_filter_via_relation_pk(self, session, Person_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToOneOrManyToOneEqual,
        )

        iface = SQLAInterface(Person_cls)
        f = FilterRelationOneToOneOrManyToOneEqual(iface)
        stmt = select(iface.obj)
        # Filter by country pk=1 (Germany)
        stmt = f.apply(stmt, "country", 1)
        result = session.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Alice", "Bob"}

    def test_equal_filter_with_model_instance(self, session, Person_cls, Country_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToOneOrManyToOneEqual,
        )

        iface = SQLAInterface(Person_cls)
        f = FilterRelationOneToOneOrManyToOneEqual(iface)
        country = session.get(Country_cls, 2)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, "country", country)
        result = session.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Carol"}

    def test_equal_filter_empty_value_skips(self, session, Person_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToOneOrManyToOneEqual,
        )

        iface = SQLAInterface(Person_cls)
        f = FilterRelationOneToOneOrManyToOneEqual(iface)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, "country", None)
        result = session.execute(stmt).scalars().all()
        assert len(result) == 3

    def test_equal_filter_with_string_value(self, session, Person_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToOneOrManyToOneEqual,
        )

        iface = SQLAInterface(Person_cls)
        f = FilterRelationOneToOneOrManyToOneEqual(iface)
        stmt = select(iface.obj)
        # String pk -> split by comma
        stmt = f.apply(stmt, "country", "1")
        result = session.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Alice", "Bob"}

    def test_not_equal_filter(self, session, Person_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToOneOrManyToOneNotEqual,
        )

        iface = SQLAInterface(Person_cls)
        f = FilterRelationOneToOneOrManyToOneNotEqual(iface)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, "country", 1)
        result = session.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Carol"}

    def test_not_equal_filter_with_model_instance(
        self, session, Person_cls, Country_cls
    ):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToOneOrManyToOneNotEqual,
        )

        iface = SQLAInterface(Person_cls)
        f = FilterRelationOneToOneOrManyToOneNotEqual(iface)
        country = session.get(Country_cls, 1)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, "country", country)
        result = session.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Carol"}

    def test_not_equal_filter_empty_value(self, session, Person_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToOneOrManyToOneNotEqual,
        )

        iface = SQLAInterface(Person_cls)
        f = FilterRelationOneToOneOrManyToOneNotEqual(iface)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, "country", None)
        assert len(session.execute(stmt).scalars().all()) == 3


class TestFilterRelationOneToManyOrManyToMany:
    def test_in_filter_pk_values(self, session, Country_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToManyOrManyToManyIn,
        )

        iface = SQLAInterface(Country_cls)
        f = FilterRelationOneToManyOrManyToManyIn(iface)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, "people", [1, 2])
        result = session.execute(stmt).scalars().all()
        assert any(c.name == "Germany" for c in result)

    def test_in_filter_with_model_instances(self, session, Country_cls, Person_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToManyOrManyToManyIn,
        )

        iface = SQLAInterface(Country_cls)
        f = FilterRelationOneToManyOrManyToManyIn(iface)
        people = (
            session.execute(select(Person_cls).filter(Person_cls.id.in_([1, 2])))
            .scalars()
            .all()
        )
        stmt = select(iface.obj)
        stmt = f.apply(stmt, "people", people)
        result = session.execute(stmt).scalars().all()
        assert any(c.name == "Germany" for c in result)

    def test_in_filter_empty_value(self, session, Country_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToManyOrManyToManyIn,
        )

        iface = SQLAInterface(Country_cls)
        f = FilterRelationOneToManyOrManyToManyIn(iface)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, "people", [])
        assert len(session.execute(stmt).scalars().all()) == 2

    def test_not_in_filter_pk_values(self, session, Country_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToManyOrManyToManyNotIn,
        )

        iface = SQLAInterface(Country_cls)
        f = FilterRelationOneToManyOrManyToManyNotIn(iface)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, "people", [1])
        result = session.execute(stmt).scalars().all()
        # NotIn returns all countries except those linked to person 1
        assert any(c.name == "USA" for c in result)

    def test_not_in_filter_with_model_instances(self, session, Country_cls, Person_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToManyOrManyToManyNotIn,
        )

        iface = SQLAInterface(Country_cls)
        f = FilterRelationOneToManyOrManyToManyNotIn(iface)
        person = session.get(Person_cls, 3)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, "people", [person])
        result = session.execute(stmt).scalars().all()
        assert len(result) >= 1

    def test_not_in_filter_empty_value(self, session, Country_cls):
        from fastapi_rtk.backends.sqla.filters import (
            FilterRelationOneToManyOrManyToManyNotIn,
        )

        iface = SQLAInterface(Country_cls)
        f = FilterRelationOneToManyOrManyToManyNotIn(iface)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, "people", [])
        assert len(session.execute(stmt).scalars().all()) == 2


class TestFilterGlobalSqla:
    def test_global_filter_across_columns(self, session, Person_cls):
        from fastapi_rtk.backends.sqla.filters import FilterGlobal

        iface = SQLAInterface(Person_cls)
        f = FilterGlobal(iface)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, ["name", "country.name"], "Alice")
        result = session.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Alice"}

    def test_global_filter_separator_split(self, session, Person_cls, config_setter):
        from fastapi_rtk.backends.sqla.filters import FilterGlobal

        config_setter("TEXT_FILTER_SEPARATOR", "|")
        iface = SQLAInterface(Person_cls)
        f = FilterGlobal(iface)
        stmt = select(iface.obj)
        # Both "Alice" and "Bob" individually match — AND across the values
        # means a single row that matches both (unlikely) gets returned. Use
        # one value to verify the separator branch fires without error.
        stmt = f.apply(stmt, ["name"], "Alice|")
        session.execute(stmt).scalars().all()  # smoke

    def test_global_filter_with_boolean_column(self, session, Person_cls):
        from fastapi_rtk.backends.sqla.filters import FilterGlobal

        iface = SQLAInterface(Person_cls)
        f = FilterGlobal(iface)
        stmt = select(iface.obj)
        stmt = f.apply(stmt, ["active"], "true")
        session.execute(stmt).scalars().all()  # smoke - boolean branch


class TestFilterTextContainsOnRelation:
    def test_text_contains_on_relation_subcol(self, session, Person_cls):
        iface = SQLAInterface(Person_cls)
        f = FilterTextContains(iface)
        stmt = select(iface.obj)
        # Searches via Person.country.name LIKE
        stmt = f.apply(stmt, "country.name", "Germany")
        result = session.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Alice", "Bob"}

    def test_text_contains_on_relation_default_columns(self, session, Person_cls):
        iface = SQLAInterface(Person_cls)
        f = FilterTextContains(iface)
        stmt = select(iface.obj)
        # Whole-relation contains scan
        stmt = f.apply(stmt, "country", "USA")
        result = session.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Carol"}


class TestSqlaFiltersCastValueExtras:
    """`_cast_value` branches on enum non-EnumType, boolean integer/string,
    list dispatch, NULL passthrough."""

    @pytest.fixture
    def filter_with_dm(self):
        from unittest.mock import MagicMock

        from fastapi_rtk.backends.sqla.filters import BaseFilter

        dm = MagicMock()
        dm.is_jsonb.return_value = False
        dm.is_enum.return_value = False
        dm.is_string.return_value = False
        dm.is_integer.return_value = False
        dm.is_float.return_value = False
        dm.is_boolean.return_value = False
        dm.is_date.return_value = False
        dm.is_datetime.return_value = False

        class _Filter(BaseFilter):
            arg_name = "test"
            translation_key = "test"

            def apply(self, *a, **kw):
                return None

        f = _Filter(dm)
        return f, dm

    def test_cast_value_null_returns_none(self, filter_with_dm):
        f, _ = filter_with_dm
        assert f._cast_value("col", "NULL") is None

    def test_cast_value_enum_non_enumtype_returns_value(self, filter_with_dm):
        f, dm = filter_with_dm
        dm.is_enum.return_value = True
        # Plain list (non-EnumType) → fallthrough to return value (line 112)
        dm.get_enum_value.return_value = ["a", "b"]
        assert f._cast_value("col", "a") == "a"

    def test_cast_value_boolean_int_one(self, filter_with_dm):
        f, dm = filter_with_dm
        dm.is_boolean.return_value = True
        # value == 1 path (line 119)
        assert f._cast_value("col", 1) is True

    def test_cast_value_boolean_string_truthy(self, filter_with_dm):
        f, dm = filter_with_dm
        dm.is_boolean.return_value = True
        # value.lower() in ["true", "1"] (line 121)
        assert f._cast_value("col", "True") is True

    def test_cast_value_boolean_string_falsey(self, filter_with_dm):
        f, dm = filter_with_dm
        dm.is_boolean.return_value = True
        assert f._cast_value("col", "false") is False

    def test_cast_value_list_dispatch(self, filter_with_dm):
        f, dm = filter_with_dm
        dm.is_string.return_value = True
        out = f._cast_value("col", [1, 2, 3])
        # Recursive: list of casted values
        assert out == ["1", "2", "3"]
