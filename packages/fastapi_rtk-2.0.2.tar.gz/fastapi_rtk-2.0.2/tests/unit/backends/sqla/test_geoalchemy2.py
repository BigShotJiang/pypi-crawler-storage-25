"""Tests for geoalchemy2 extension when the deps are absent."""

import pytest

from fastapi_rtk.backends.sqla.extensions import geoalchemy2 as ga2_mod


class TestImportFallback:
    """When geoalchemy2/shapely are not installed, classes become _GeoAlchemy2ImportError stubs."""

    @pytest.mark.parametrize(
        "name",
        [
            "GeoBaseFilter",
            "GeoFilterEqual",
            "GeoFilterNotEqual",
            "GeoFilterContains",
            "GeoFilterNotContains",
            "GeoFilterIntersects",
            "GeoFilterNotIntersects",
            "GeoFilterOverlaps",
            "GeoFilterNotOverlaps",
            "GeometryConverter",
        ],
    )
    def test_attr_access_raises_import_error(self, name):
        try:
            import geoalchemy2  # noqa: F401
        except ImportError:
            pytest.importorskip("geoalchemy2")

        # If geoalchemy2 IS installed, the symbol is a real class - skip
        try:
            import geoalchemy2  # noqa: F401

            pytest.skip("geoalchemy2 installed; fallback path not exercised")
        except ImportError:
            pass

        sym = getattr(ga2_mod, name)
        with pytest.raises(ImportError, match="geoalchemy2"):
            sym.something_random

    def test_call_raises_import_error(self):
        try:
            import geoalchemy2  # noqa: F401

            pytest.skip("geoalchemy2 installed; fallback path not exercised")
        except ImportError:
            pass
        with pytest.raises(ImportError, match="geoalchemy2"):
            ga2_mod.GeometryConverter()


class TestGeometryConverter:
    """Real geoalchemy2 + shapely tests when extras installed."""

    @pytest.fixture(autouse=True)
    def _require_geoalchemy(self):
        try:
            import geoalchemy2  # noqa: F401
            import shapely  # noqa: F401
        except ImportError:
            pytest.skip("geoalchemy2/shapely not installed")

    def test_two_way_converter_dict_to_wkt(self):
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.geometry_converter import (
            GeometryConverter,
        )

        gc = GeometryConverter()
        result = gc.two_way_converter(
            {"type": "Point", "coordinates": [1.0, 2.0]}
        )
        assert "POINT" in result.upper()

    def test_two_way_converter_wkt_passthrough(self):
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.geometry_converter import (
            GeometryConverter,
        )

        gc = GeometryConverter()
        wkt = "POINT (1 2)"
        result = gc.two_way_converter(wkt)
        assert result == wkt

    def test_two_way_converter_wkt_type_mismatch_raises(self):
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.geometry_converter import (
            GeometryConverter,
        )

        gc = GeometryConverter()
        with pytest.raises(ValueError, match="Expected"):
            gc.two_way_converter("POINT (1 2)", type="Polygon")

    def test_two_way_converter_invalid_wkt_raises(self):
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.geometry_converter import (
            GeometryConverter,
        )

        gc = GeometryConverter()
        with pytest.raises(ValueError):
            gc.two_way_converter("not-a-wkt-string")

    def test_two_way_converter_invalid_geojson_raises(self):
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.geometry_converter import (
            GeometryConverter,
        )

        gc = GeometryConverter()
        with pytest.raises(ValueError):
            gc.two_way_converter({"type": "Bogus", "coordinates": []})

    def test_two_way_converter_shapely_geometry_returns_geojson(self):
        import shapely.geometry

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.geometry_converter import (
            GeometryConverter,
        )

        gc = GeometryConverter()
        result = gc.two_way_converter(shapely.geometry.Point(1, 2))
        assert result["type"] == "Point"
        assert result["coordinates"] == [1.0, 2.0]

    def test_to_geojson_with_wkb_element(self):
        import geoalchemy2
        import shapely.geometry

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.geometry_converter import (
            GeometryConverter,
        )

        gc = GeometryConverter()
        wkb_data = shapely.geometry.Point(1, 2).wkb
        wkb = geoalchemy2.WKBElement(wkb_data, srid=4326)
        result = gc.to_geojson(wkb)
        assert result["type"] == "Point"

    def test_two_way_converter_wkb_element_returns_geojson(self):
        import geoalchemy2
        import shapely.geometry

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.geometry_converter import (
            GeometryConverter,
        )

        gc = GeometryConverter()
        wkb_data = shapely.geometry.Point(3, 4).wkb
        wkb = geoalchemy2.WKBElement(wkb_data, srid=4326)
        result = gc.two_way_converter(wkb)
        assert result["type"] == "Point"

    def test_from_geojson_string_form(self):
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.geometry_converter import (
            GeometryConverter,
        )

        gc = GeometryConverter()
        geom = gc.from_geojson('{"type":"Point","coordinates":[5,6]}')
        assert geom.geom_type == "Point"

    def test_from_geojson_dict_form(self):
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.geometry_converter import (
            GeometryConverter,
        )

        gc = GeometryConverter()
        geom = gc.from_geojson({"type": "Point", "coordinates": [7, 8]})
        assert geom.geom_type == "Point"

    def test_two_way_converter_generator_returns_callable(self):
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.geometry_converter import (
            GeometryConverter,
        )

        gc = GeometryConverter()
        conv = gc.two_way_converter_generator("Point")
        result = conv("POINT (1 2)")
        assert "POINT" in result.upper()


class TestGeoFiltersConvertValue:
    """Cover GeoBaseFilter._convert_value branches when geo extras installed."""

    @pytest.fixture(autouse=True)
    def _require_geoalchemy(self):
        try:
            import geoalchemy2  # noqa: F401
            import shapely  # noqa: F401
        except ImportError:
            pytest.skip("geoalchemy2/shapely not installed")

    def test_convert_value_invalid_geometry_raises_validation(self):
        from unittest.mock import MagicMock

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoBaseFilter,
        )
        from fastapi_rtk.exceptions import HTTPWithValidationException

        datamodel = MagicMock()
        datamodel.geometry_converter.two_way_converter.side_effect = ValueError(
            "bad geom"
        )
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoFilterIntersects,
        )
        f = GeoFilterIntersects.__new__(GeoFilterIntersects)
        f.datamodel = datamodel
        with pytest.raises(HTTPWithValidationException):
            f._convert_value("not-a-geom", "geo_col")

    def test_convert_value_dict_returns_geomfromgeojson(self):
        from unittest.mock import MagicMock

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoBaseFilter,
        )

        datamodel = MagicMock()
        datamodel.geometry_converter.two_way_converter.return_value = {
            "type": "Point",
            "coordinates": [1, 2],
        }
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoFilterIntersects,
        )
        f = GeoFilterIntersects.__new__(GeoFilterIntersects)
        f.datamodel = datamodel
        result = f._convert_value({"type": "Point"}, "geo_col")
        # func.ST_GeomFromGeoJSON returns a SQLAlchemy function element
        assert result is not None

    def test_convert_value_str_returns_geomfromewkt(self):
        from unittest.mock import MagicMock

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoBaseFilter,
        )

        datamodel = MagicMock()
        datamodel.geometry_converter.two_way_converter.return_value = "POINT (1 2)"
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoFilterIntersects,
        )
        f = GeoFilterIntersects.__new__(GeoFilterIntersects)
        f.datamodel = datamodel
        result = f._convert_value("POINT (1 2)", "geo_col")
        assert result is not None


def _postgis_url():
    """Return PostGIS URL if container is up; else None.

    Spin up via `docker compose -f tests/docker-compose.gis.yml up -d`.
    """
    import socket

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.5)
    try:
        s.connect(("127.0.0.1", 5434))
        s.close()
        return (
            "postgresql+psycopg2://postgres:postgres"
            "@127.0.0.1:5434/fastapi_rtk_test_gis"
        )
    except OSError:
        return None


class TestGeoFiltersApplyAgainstPostgis:
    """Real PostGIS round-trip for GeoFilter*.apply methods.

    Spin up: `docker compose -f tests/docker-compose.gis.yml up -d`.
    """

    @pytest.fixture(scope="class")
    def engine(self):
        url = _postgis_url()
        if not url:
            pytest.skip(
                "PostGIS not running on :5434 - "
                "`docker compose -f tests/docker-compose.gis.yml up -d`"
            )
        try:
            import psycopg2  # noqa: F401
        except ImportError:
            pytest.skip("psycopg2 not installed")

        import sqlalchemy

        eng = sqlalchemy.create_engine(url)
        # Ensure PostGIS extension exists
        with eng.begin() as conn:
            conn.execute(sqlalchemy.text("CREATE EXTENSION IF NOT EXISTS postgis"))
        yield eng
        eng.dispose()

    @pytest.fixture(scope="class")
    def geo_iface(self, engine):
        import enum

        import geoalchemy2
        import sqlalchemy
        from sqlalchemy.orm import Session

        from fastapi_rtk import Mapped, mapped_column
        from fastapi_rtk.backends.sqla.extensions.geoalchemy2 import (
            GeometryConverter,
        )
        from fastapi_rtk.backends.sqla.interface import SQLAInterface
        from fastapi_rtk.backends.sqla.model import Model

        # Unique table per run to dodge cross-test pollution
        table_name = "geo_place_t"

        class Place(Model):
            __tablename__ = table_name
            __table_args__ = {"extend_existing": True}
            id: Mapped[int] = mapped_column(primary_key=True)
            name: Mapped[str | None] = mapped_column(sqlalchemy.String(50))
            geom = sqlalchemy.Column(geoalchemy2.Geometry(geometry_type="POINT"))

        # Create + seed
        Place.__table__.drop(engine, checkfirst=True)
        Place.__table__.create(engine)
        with Session(engine) as s:
            s.execute(
                sqlalchemy.text(
                    f"INSERT INTO {table_name}(id, name, geom) VALUES "
                    "(1, 'Berlin', ST_GeomFromText('POINT(13.405 52.52)')),"
                    "(2, 'Munich', ST_GeomFromText('POINT(11.582 48.135)'))"
                )
            )
            s.commit()

        iface = SQLAInterface(Place)
        iface.geometry_converter = GeometryConverter()
        yield iface, engine, Place

        Place.__table__.drop(engine)

    def test_geo_filter_equal(self, geo_iface):
        from sqlalchemy import select
        from sqlalchemy.orm import Session

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoFilterEqual,
        )

        iface, engine, Place = geo_iface
        f = GeoFilterEqual(iface)
        stmt = f.apply(select(Place), "geom", {"type": "Point", "coordinates": [13.405, 52.52]})
        with Session(engine) as s:
            result = s.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Berlin"}

    def test_geo_filter_not_equal(self, geo_iface):
        from sqlalchemy import select
        from sqlalchemy.orm import Session

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoFilterNotEqual,
        )

        iface, engine, Place = geo_iface
        f = GeoFilterNotEqual(iface)
        stmt = f.apply(select(Place), "geom", {"type": "Point", "coordinates": [13.405, 52.52]})
        with Session(engine) as s:
            result = s.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Munich"}

    def test_geo_filter_contains(self, geo_iface):
        from sqlalchemy import select
        from sqlalchemy.orm import Session

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoFilterContains,
        )

        iface, engine, Place = geo_iface
        f = GeoFilterContains(iface)
        # Using identical point - ST_Contains is True for self
        stmt = f.apply(select(Place), "geom", {"type": "Point", "coordinates": [13.405, 52.52]})
        with Session(engine) as s:
            s.execute(stmt).scalars().all()  # smoke

    def test_geo_filter_not_contains(self, geo_iface):
        from sqlalchemy import select
        from sqlalchemy.orm import Session

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoFilterNotContains,
        )

        iface, engine, Place = geo_iface
        f = GeoFilterNotContains(iface)
        stmt = f.apply(select(Place), "geom", {"type": "Point", "coordinates": [0, 0]})
        with Session(engine) as s:
            s.execute(stmt).scalars().all()  # smoke

    def test_geo_filter_intersects(self, geo_iface):
        from sqlalchemy import select
        from sqlalchemy.orm import Session

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoFilterIntersects,
        )

        iface, engine, Place = geo_iface
        f = GeoFilterIntersects(iface)
        stmt = f.apply(select(Place), "geom", {"type": "Polygon", "coordinates": [[[10, 45], [15, 45], [15, 55], [10, 55], [10, 45]]]})
        with Session(engine) as s:
            result = s.execute(stmt).scalars().all()
        # Both Berlin (13.405, 52.52) and Munich (11.582, 48.135) inside polygon
        assert {p.name for p in result} == {"Berlin", "Munich"}

    def test_geo_filter_not_intersects(self, geo_iface):
        from sqlalchemy import select
        from sqlalchemy.orm import Session

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoFilterNotIntersects,
        )

        iface, engine, Place = geo_iface
        f = GeoFilterNotIntersects(iface)
        stmt = f.apply(select(Place), "geom", {"type": "Polygon", "coordinates": [[[100, 0], [110, 0], [110, 10], [100, 10], [100, 0]]]})
        with Session(engine) as s:
            result = s.execute(stmt).scalars().all()
        assert {p.name for p in result} == {"Berlin", "Munich"}

    def test_geo_filter_overlaps(self, geo_iface):
        from sqlalchemy import select
        from sqlalchemy.orm import Session

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoFilterOverlaps,
        )

        iface, engine, Place = geo_iface
        f = GeoFilterOverlaps(iface)
        stmt = f.apply(select(Place), "geom", {"type": "Point", "coordinates": [13.405, 52.52]})
        with Session(engine) as s:
            s.execute(stmt).scalars().all()  # smoke

    def test_geo_filter_not_overlaps(self, geo_iface):
        from sqlalchemy import select
        from sqlalchemy.orm import Session

        from fastapi_rtk.backends.sqla.extensions.geoalchemy2.filters import (
            GeoFilterNotOverlaps,
        )

        iface, engine, Place = geo_iface
        f = GeoFilterNotOverlaps(iface)
        stmt = f.apply(select(Place), "geom", {"type": "Point", "coordinates": [0, 0]})
        with Session(engine) as s:
            s.execute(stmt).scalars().all()  # smoke


class TestModuleAlwaysExportsNames:
    @pytest.mark.parametrize(
        "name",
        [
            "GeoBaseFilter",
            "GeoFilterEqual",
            "GeoFilterNotEqual",
            "GeoFilterContains",
            "GeoFilterNotContains",
            "GeoFilterIntersects",
            "GeoFilterNotIntersects",
            "GeoFilterOverlaps",
            "GeoFilterNotOverlaps",
            "GeometryConverter",
        ],
    )
    def test_name_present_regardless_of_install(self, name):
        assert hasattr(ga2_mod, name)
