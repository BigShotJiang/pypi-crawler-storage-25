import pytest
import sqlalchemy

from fastapi_rtk.backends.sqla.model import (
    Base,
    Model,
    camel_to_snake_case,
    metadata,
    metadatas,
)
from fastapi_rtk.const import DEFAULT_METADATA_KEY
from fastapi_rtk.exceptions import FastAPIReactToolkitException


class TestCamelToSnakeCase:
    def test_simple(self):
        assert camel_to_snake_case("MyModel") == "my_model"

    def test_already_lowercase(self):
        assert camel_to_snake_case("model") == "model"

    def test_acronym(self):
        assert camel_to_snake_case("HTTPRequest") == "http_request"

    def test_multiple_words(self):
        assert camel_to_snake_case("MyHTTPModel") == "my_http_model"

    def test_with_digits(self):
        assert camel_to_snake_case("Model2Name") == "model2_name"


class TestModelMetadata:
    def test_default_metadata_present(self):
        assert DEFAULT_METADATA_KEY in metadatas

    def test_metadata_alias(self):
        assert metadata is metadatas[DEFAULT_METADATA_KEY]

    def test_base_alias(self):
        assert Base is Model


class TestTableNameAutoGen:
    def test_camelcase_to_snakecase(self):
        class TestSnakeAuto(Model):
            __tablename__ = camel_to_snake_case("TestSnakeAuto")
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

        assert TestSnakeAuto.__tablename__ == "test_snake_auto"

    def test_default_tablename_inferred(self):
        class AnotherModelExample(Model):
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

        assert AnotherModelExample.__tablename__ == "another_model_example"


class TestGetPkAttrs:
    def test_single_pk(self):
        class SimpleSinglePk(Model):
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

        assert SimpleSinglePk.get_pk_attrs() == ["id"]

    def test_composite_pk(self):
        class CompPk(Model):
            a = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            b = sqlalchemy.Column(sqlalchemy.String, primary_key=True)

        assert sorted(CompPk.get_pk_attrs()) == ["a", "b"]


class TestBindKey:
    def test_default_bind_key_is_none(self):
        class NoBind(Model):
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

        assert NoBind.__bind_key__ is None

    def test_default_metadata_key_rejected(self):
        with pytest.raises(FastAPIReactToolkitException, match="cannot be"):

            class BadBind(Model):
                __bind_key__ = DEFAULT_METADATA_KEY
                id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

    def test_custom_bind_key_creates_metadata(self):
        bind_name = "test_bind_xyz"
        # Cleanup before
        metadatas.pop(bind_name, None)

        class WithBind(Model):
            __bind_key__ = bind_name
            __tablename__ = "with_bind"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

        assert bind_name in metadatas
        assert WithBind.metadata is metadatas[bind_name]


class TestExtendExisting:
    def test_extend_existing_in_table_args(self):
        # Used so re-defining the same class doesn't error
        assert Model.__table_args__["extend_existing"] is True


class TestLoadOptions:
    def test_no_relationship_filter_returns_attr(self):
        from sqlalchemy.orm import Mapped, relationship

        class Parent(Model):
            __tablename__ = "load_opts_parent"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)

        class Child(Model):
            __tablename__ = "load_opts_child"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            parent_id = sqlalchemy.Column(
                sqlalchemy.Integer, sqlalchemy.ForeignKey("load_opts_parent.id")
            )

        attr = Child.parent_id
        loaded = Child.load_options("parent_id")
        # Without filters, returns attribute as-is
        assert loaded is attr

    def test_relationship_filter_applied(self):
        import collections

        from sqlalchemy.orm import relationship

        class RFParent(Model):
            __tablename__ = "rf_parent"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            name = sqlalchemy.Column(sqlalchemy.String(50))

        class RFChild(Model):
            __tablename__ = "rf_child"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            parent_id = sqlalchemy.Column(
                sqlalchemy.Integer, sqlalchemy.ForeignKey("rf_parent.id")
            )
            parent = relationship("RFParent")

            @classmethod
            def only_active_parent(cls):
                return RFParent.name != ""

        RFChild._relationship_filters = collections.defaultdict(list)
        RFChild._relationship_filters["parent"] = ["only_active_parent"]
        try:
            loaded = RFChild.load_options("parent")
            # `attr.and_(...)` returns an attribute proxy, not the original attr
            assert loaded is not RFChild.parent
        finally:
            RFChild._relationship_filters = None


@pytest.mark.asyncio
class TestModelLoad:
    async def test_load_no_op_when_already_loaded(self):
        # Filter path: nothing to load -> early return at line 143.
        class LoadModel(Model):
            __tablename__ = "load_noop"
            id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
            name = sqlalchemy.Column(sqlalchemy.String(50))

        m = LoadModel(id=1, name="x")
        # `name` already in __dict__ -> filtered out -> no awaitable_attrs access.
        await m.load("name")


class TestModelBindKeyInheritance:
    """Lines 71-73: __bind_key__ inferred from __table__.metadata identity."""

    def test_bind_key_inferred_from_metadata(self):
        from sqlalchemy import MetaData

        from fastapi_rtk.backends.sqla.model import Model, metadatas

        new_meta = MetaData()
        metadatas["custom_bind_test"] = new_meta

        class CustomBindWidget(Model):
            __tablename__ = "bind_inferred_widget"
            __table__ = sqlalchemy.Table(
                "bind_inferred_widget",
                new_meta,
                sqlalchemy.Column("id", sqlalchemy.Integer, primary_key=True),
            )

        assert CustomBindWidget.__bind_key__ == "custom_bind_test"


class TestRtkTableAutoload:
    """Lines 180-190: rtk Table.__init__ with autoload_with on a sync Engine
    initializes a DatabaseSessionManager and runs SA_Table.__init__ in
    smart_run_sync."""

    @pytest.mark.asyncio
    async def test_table_autoloads_from_existing_engine(self, tmp_path):
        from sqlalchemy import Column, Integer, MetaData, String

        from fastapi_rtk.backends.sqla.model import Table as RtkTable

        sync_url = f"sqlite:///{tmp_path / 'autoload.db'}"
        sync_engine = sqlalchemy.create_engine(sync_url)
        seed_meta = MetaData()
        sqlalchemy.Table(
            "autoload_widget",
            seed_meta,
            Column("id", Integer, primary_key=True),
            Column("name", String(20)),
        ).create(sync_engine)

        meta = MetaData()
        loaded = RtkTable("autoload_widget", meta, autoload_with=sync_engine)
        assert "id" in [c.name for c in loaded.columns]
        sync_engine.dispose()
