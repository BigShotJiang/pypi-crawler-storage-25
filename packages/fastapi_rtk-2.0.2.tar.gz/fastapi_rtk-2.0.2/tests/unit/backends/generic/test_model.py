import pytest

from fastapi_rtk.backends.generic.column import GenericColumn
from fastapi_rtk.backends.generic.exceptions import (
    MultipleColumnsException,
    PKMissingException,
    PKMultipleException,
)
from fastapi_rtk.backends.generic.model import GenericMapper, GenericModel


class TestGenericMapper:
    def test_init_state(self):
        m = GenericMapper()
        assert m.properties == {}
        assert m.columns == []
        assert m.pk is None


class TestSubclassPKValidation:
    def test_pk_missing_raises(self):
        with pytest.raises(PKMissingException):

            class M(GenericModel):
                x = GenericColumn(int)

    def test_multiple_pk_raises(self):
        with pytest.raises(PKMultipleException):

            class M(GenericModel):
                a = GenericColumn(int, primary_key=True, auto_increment=True)
                b = GenericColumn(str, primary_key=True)

    def test_ignore_init_skips_validation(self):
        class M(GenericModel):
            __ignore_init__ = True

        # No exception even though no PK


class TestModelInit:
    def _model(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            name = GenericColumn(str)

        return M

    def test_empty_kwargs_no_validation(self):
        M = self._model()
        m = M()  # bypass validation entirely
        assert m is not None

    def test_kwargs_unknown_keys_skipped(self):
        M = self._model()
        m = M(name="x", bogus=1, __check_on_init__=False)
        assert m.name == "x"
        assert not hasattr(m, "_bogus")

    def test_check_on_init_raises_when_required_unset(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True)
            required = GenericColumn(str, nullable=False)

        with pytest.raises(MultipleColumnsException):
            M(id=1, __check_on_init__=True)  # required unset -> MultipleColumnsException


class TestPKAccessors:
    def _model(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            name = GenericColumn(str)

        return M

    def test_get_pk_returns_pk_value(self):
        M = self._model()
        m = M(__check_on_init__=False)
        m.id = 42
        assert m.get_pk() == 42

    def test_set_pk(self):
        M = self._model()
        m = M(__check_on_init__=False)
        m.set_pk(7)
        assert m.id == 7

    def test_get_pk_attrs(self):
        M = self._model()
        assert M.get_pk_attrs() == ["id"]

    def test_get_col_type(self):
        M = self._model()
        m = M(__check_on_init__=False)
        assert m.get_col_type("id") is int
        assert m.get_col_type("name") is str


class TestUpdateAndValidity:
    def _model(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            name = GenericColumn(str)

        return M

    def test_update_runs_validation_by_default(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True)
            required = GenericColumn(str, nullable=False)

        m = M(id=1, required="ok", __check_on_init__=False)
        m.is_model_valid()
        # Manually clear required to simulate invalid state, then update with check
        m.__dict__.pop("_required", None)
        with pytest.raises(MultipleColumnsException):
            m.update({})  # check=True, required is now UNSET

    def test_update_skip_check(self):
        M = self._model()
        m = M(__check_on_init__=False)
        # Should not raise - check disabled
        m.update({"name": "ok"}, check=False)
        assert m.name == "ok"

    def test_is_model_valid_saves_last_valid_state(self):
        M = self._model()
        m = M(name="ok", __check_on_init__=False)
        m.is_model_valid()
        assert m._last_valid_state == {"id": m.id, "name": "ok"}


class TestRepr:
    def test_repr_includes_columns(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            name = GenericColumn(str)

        m = M(name="abc", __check_on_init__=False)
        r = repr(m)
        assert "M(" in r
        assert "name=abc" in r
