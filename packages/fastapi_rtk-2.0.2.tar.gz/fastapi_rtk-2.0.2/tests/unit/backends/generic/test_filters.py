from datetime import date, datetime

import pytest

from fastapi_rtk.backends.generic.column import GenericColumn
from fastapi_rtk.backends.generic.filters import (
    GenericBaseFilter,
    GenericBaseOprFilter,
    GenericFilterContains,
    GenericFilterConverter,
    GenericFilterEndsWith,
    GenericFilterEqual,
    GenericFilterGlobal,
    GenericFilterGreater,
    GenericFilterGreaterEqual,
    GenericFilterIContains,
    GenericFilterIn,
    GenericFilterNotContains,
    GenericFilterNotEndsWith,
    GenericFilterNotEqual,
    GenericFilterNotStartsWith,
    GenericFilterSmaller,
    GenericFilterSmallerEqual,
    GenericFilterStartsWith,
    GenericFilterTextContains,
)
from fastapi_rtk.backends.generic.model import GenericModel
from fastapi_rtk.backends.generic.session import GenericSession


@pytest.fixture
def Person():
    class Person(GenericModel):
        id = GenericColumn(int, primary_key=True, auto_increment=True)
        name = GenericColumn(str)
        age = GenericColumn(int)

    return Person


@pytest.fixture
def Sess():
    class TS(GenericSession):
        pass

    return TS


@pytest.fixture
def session(Sess):
    return Sess()


class StubInterface:
    def __init__(self, types=None):
        self._types = types or {}

    def is_enum(self, col):
        return False

    def is_string(self, col):
        return self._types.get(col) is str

    def is_integer(self, col):
        return self._types.get(col) is int

    def is_float(self, col):
        return self._types.get(col) is float

    def is_boolean(self, col):
        return self._types.get(col) is bool

    def is_date(self, col):
        return self._types.get(col) is date

    def is_datetime(self, col):
        return self._types.get(col) is datetime


class TestCastValue:
    def test_null_returns_none(self):
        f = GenericFilterEqual(StubInterface())
        assert f._cast_value("name", "NULL") is None

    def test_list_recursive(self):
        f = GenericFilterEqual(StubInterface({"age": int}))
        assert f._cast_value("age", ["1", "2"]) == [1, 2]

    def test_string_cast(self):
        f = GenericFilterEqual(StubInterface({"name": str}))
        assert f._cast_value("name", 42) == "42"

    def test_integer_cast(self):
        f = GenericFilterEqual(StubInterface({"age": int}))
        assert f._cast_value("age", "5") == 5

    def test_float_cast(self):
        f = GenericFilterEqual(StubInterface({"x": float}))
        assert f._cast_value("x", "1.5") == 1.5

    def test_boolean_cast_true_string(self):
        f = GenericFilterEqual(StubInterface({"flag": bool}))
        assert f._cast_value("flag", "true") is True

    def test_boolean_cast_false_string(self):
        f = GenericFilterEqual(StubInterface({"flag": bool}))
        assert f._cast_value("flag", "false") is False

    def test_boolean_cast_one(self):
        f = GenericFilterEqual(StubInterface({"flag": bool}))
        assert f._cast_value("flag", 1) is True

    def test_date_cast(self):
        f = GenericFilterEqual(StubInterface({"d": date}))
        assert f._cast_value("d", "2024-01-15") == date(2024, 1, 15)

    def test_datetime_cast(self):
        f = GenericFilterEqual(StubInterface({"d": datetime}))
        result = f._cast_value("d", "2024-01-15T12:00:00")
        assert isinstance(result, datetime)

    def test_enum_cast_via_enumtype(self):
        import enum

        class Color(enum.Enum):
            red = "red"
            blue = "blue"

        class EnumStub(StubInterface):
            def is_enum(self, col):
                return True

            def get_enum_value(self, col):
                return Color

        f = GenericFilterEqual(EnumStub())
        assert f._cast_value("color", "red") is Color.red

    def test_enum_cast_when_get_enum_value_not_enumtype(self):
        class EnumStub(StubInterface):
            def is_enum(self, col):
                return True

            def get_enum_value(self, col):
                # Not an enum.EnumType -> filter returns the raw value
                return ["red", "blue"]

        f = GenericFilterEqual(EnumStub())
        assert f._cast_value("color", "red") == "red"

    def test_no_type_match_returns_value_as_is(self):
        # Stub claims none of the types match -> hits final `return value`
        f = GenericFilterEqual(StubInterface())
        assert f._cast_value("anything", object) is object

    def test_invalid_cast_logs_and_returns_value(self, caplog):
        f = GenericFilterEqual(StubInterface({"age": int}))
        with caplog.at_level("WARNING", logger="DT_FASTAPI"):
            result = f._cast_value("age", "not-int")
        assert result == "not-int"
        assert any("Failed to cast" in r.message for r in caplog.records)


class TestApplyMethods:
    def _add_data(self, session, Person):
        for n, age in [("Alice", 20), ("Bob", 30), ("Carol", 40)]:
            session.add(Person(name=n, age=age, __check_on_init__=False))

    def test_filter_equal(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterEqual(StubInterface({"name": str}))
        result = f.apply(stmt, "name", "Alice").all()
        assert [p.name for p in result] == ["Alice"]

    def test_filter_not_equal(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterNotEqual(StubInterface({"name": str}))
        result = f.apply(stmt, "name", "Alice").all()
        names = [p.name for p in result]
        assert "Alice" not in names

    def test_filter_starts_with(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterStartsWith(StubInterface({"name": str}))
        result = f.apply(stmt, "name", "A").all()
        assert [p.name for p in result] == ["Alice"]

    def test_filter_not_starts_with(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterNotStartsWith(StubInterface({"name": str}))
        result = f.apply(stmt, "name", "A").all()
        assert all(p.name != "Alice" for p in result)

    def test_filter_ends_with(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterEndsWith(StubInterface({"name": str}))
        result = f.apply(stmt, "name", "ol").all()
        assert [p.name for p in result] == ["Carol"]

    def test_filter_not_ends_with(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterNotEndsWith(StubInterface({"name": str}))
        result = f.apply(stmt, "name", "ol").all()
        assert all(p.name != "Carol" for p in result)

    def test_filter_contains(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterContains(StubInterface({"name": str}))
        result = f.apply(stmt, "name", "ar").all()
        assert [p.name for p in result] == ["Carol"]

    def test_filter_icontains(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterIContains(StubInterface({"name": str}))
        result = f.apply(stmt, "name", "AR").all()
        assert [p.name for p in result] == ["Carol"]

    def test_filter_not_contains(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterNotContains(StubInterface({"name": str}))
        result = f.apply(stmt, "name", "ar").all()
        assert all(p.name != "Carol" for p in result)

    def test_filter_greater(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterGreater(StubInterface({"age": int}))
        result = f.apply(stmt, "age", "25").all()
        assert sorted(p.age for p in result) == [30, 40]

    def test_filter_smaller(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterSmaller(StubInterface({"age": int}))
        result = f.apply(stmt, "age", "35").all()
        assert sorted(p.age for p in result) == [20, 30]

    def test_filter_greater_equal(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterGreaterEqual(StubInterface({"age": int}))
        result = f.apply(stmt, "age", "30").all()
        assert sorted(p.age for p in result) == [30, 40]

    def test_filter_smaller_equal(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterSmallerEqual(StubInterface({"age": int}))
        result = f.apply(stmt, "age", "30").all()
        assert sorted(p.age for p in result) == [20, 30]

    def test_filter_in(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterIn(StubInterface({"name": str}))
        result = f.apply(stmt, "name", ["Alice", "Bob"]).all()
        assert sorted(p.name for p in result) == ["Alice", "Bob"]

    def test_filter_text_contains(self, session, Person):
        self._add_data(session, Person)
        stmt = session.query(Person)
        f = GenericFilterTextContains(StubInterface({"name": str}))
        result = f.apply(stmt, "name", "lic").all()
        assert [p.name for p in result] == ["Alice"]


class TestFilterConverter:
    def test_conversion_table_keys_present(self):
        keys = [t[0] for t in GenericFilterConverter.conversion_table]
        for k in [
            "is_enum",
            "is_boolean",
            "is_text",
            "is_string",
            "is_integer",
            "is_date",
            "is_datetime",
        ]:
            assert k in keys

    def test_filter_classes_subclass_base(self):
        for _, filters in GenericFilterConverter.conversion_table:
            for fc in filters:
                assert issubclass(fc, GenericBaseFilter)

    def test_is_list_row_present(self):
        keys = [t[0] for t in GenericFilterConverter.conversion_table]
        assert "is_list" in keys

    def test_is_list_filter_set_minimal(self):
        from fastapi_rtk.backends.generic.filters import (
            GenericFilterEqual,
            GenericFilterNotEqual,
            GenericFilterTextContains,
        )

        row = next(
            t for t in GenericFilterConverter.conversion_table if t[0] == "is_list"
        )
        assert row[1] == [
            GenericFilterTextContains,
            GenericFilterEqual,
            GenericFilterNotEqual,
        ]

    def test_is_json_row_present(self):
        keys = [t[0] for t in GenericFilterConverter.conversion_table]
        assert "is_json" in keys

    def test_is_json_filter_set(self):
        from fastapi_rtk.backends.generic.filters import (
            GenericFilterContains,
            GenericFilterEndsWith,
            GenericFilterEqual,
            GenericFilterIContains,
            GenericFilterIn,
            GenericFilterNotContains,
            GenericFilterNotEndsWith,
            GenericFilterNotEqual,
            GenericFilterNotStartsWith,
            GenericFilterStartsWith,
            GenericFilterTextContains,
        )

        row = next(
            t for t in GenericFilterConverter.conversion_table if t[0] == "is_json"
        )
        assert row[1] == [
            GenericFilterTextContains,
            GenericFilterStartsWith,
            GenericFilterNotStartsWith,
            GenericFilterEndsWith,
            GenericFilterNotEndsWith,
            GenericFilterContains,
            GenericFilterIContains,
            GenericFilterNotContains,
            GenericFilterEqual,
            GenericFilterNotEqual,
            GenericFilterIn,
        ]


class TestOprFilterBaseClass:
    def test_subclass_of_both(self):
        assert issubclass(GenericBaseOprFilter, GenericBaseFilter)
