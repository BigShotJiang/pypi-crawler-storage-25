import pytest

from fastapi_rtk.backends.generic.column import GenericColumn
from fastapi_rtk.backends.generic.model import GenericModel
from fastapi_rtk.backends.generic.session import GenericSession


@pytest.fixture
def Person():
    class Person(GenericModel):
        id = GenericColumn(int, primary_key=True, auto_increment=True)
        name = GenericColumn(str)
        age = GenericColumn(int)

    return Person


@pytest.fixture
def Sess():
    class TestSession(GenericSession):
        pass

    return TestSession


@pytest.fixture
def session(Sess):
    return Sess()


class TestAddAndGet:
    def test_add_with_auto_increment_assigns_pk(self, session, Person):
        p = Person(name="A", age=20, __check_on_init__=False)
        session.add(p)
        assert p.get_pk() == 1
        assert session.get(p, 1) is p

    def test_add_multiple_increments_pk(self, session, Person):
        p1 = Person(name="A", age=20, __check_on_init__=False)
        p2 = Person(name="B", age=30, __check_on_init__=False)
        session.add(p1)
        session.add(p2)
        assert p2.get_pk() == 2

    def test_explicit_pk(self, session, Person):
        p = Person(name="X", age=99, __check_on_init__=False)
        p.set_pk(42)
        session.add(p)
        assert session.get(p, 42) is p

    def test_duplicate_pk_raises(self, session, Person):
        p1 = Person(name="A", age=20, __check_on_init__=False)
        p1.set_pk(5)
        p2 = Person(name="B", age=30, __check_on_init__=False)
        p2.set_pk(5)
        session.add(p1)
        with pytest.raises(ValueError, match="already exists"):
            session.add(p2)


class TestQueryAll:
    def test_returns_all_added(self, session, Person):
        for n in ["A", "B", "C"]:
            session.add(Person(name=n, age=20, __check_on_init__=False))
        result = session.query(Person).all()
        assert len(result) == 3

    def test_query_required_for_all(self, session, Person):
        with pytest.raises(ValueError, match="No model set"):
            session.all()


class TestFilters:
    def test_equal(self, session, Person):
        a = Person(name="A", age=20, __check_on_init__=False)
        b = Person(name="B", age=30, __check_on_init__=False)
        session.add(a)
        session.add(b)
        result = session.query(Person).equal("name", "A").all()
        assert result == [a]

    def test_not_equal(self, session, Person):
        a = Person(name="A", age=20, __check_on_init__=False)
        b = Person(name="B", age=30, __check_on_init__=False)
        session.add(a)
        session.add(b)
        result = session.query(Person).not_equal("name", "A").all()
        assert result == [b]

    def test_in_(self, session, Person):
        for n, age in [("A", 1), ("B", 2), ("C", 3)]:
            session.add(Person(name=n, age=age, __check_on_init__=False))
        result = session.query(Person).in_("name", ["A", "C"]).all()
        names = [p.name for p in result]
        assert sorted(names) == ["A", "C"]

    def test_starts_with(self, session, Person):
        for n in ["alice", "bob", "albert"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).starts_with("name", "al").all()
        assert sorted(p.name for p in result) == ["albert", "alice"]

    def test_ends_with(self, session, Person):
        for n in ["abcdef", "bcd", "ghidef"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).ends_with("name", "def").all()
        assert sorted(p.name for p in result) == ["abcdef", "ghidef"]

    def test_text_contains_case_insensitive(self, session, Person):
        for n in ["Alice", "bob", "Charlie"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).text_contains("name", "ALI").all()
        assert [p.name for p in result] == ["Alice"]

    def test_greater(self, session, Person):
        for n, age in [("A", 10), ("B", 20), ("C", 30)]:
            session.add(Person(name=n, age=age, __check_on_init__=False))
        result = session.query(Person).greater("age", 15).all()
        assert sorted(p.name for p in result) == ["B", "C"]

    def test_smaller_equal(self, session, Person):
        for n, age in [("A", 10), ("B", 20), ("C", 30)]:
            session.add(Person(name=n, age=age, __check_on_init__=False))
        result = session.query(Person).smaller_equal("age", 20).all()
        assert sorted(p.name for p in result) == ["A", "B"]


class TestOrderLimitOffset:
    def test_order_by_asc(self, session, Person):
        for n, age in [("C", 30), ("A", 10), ("B", 20)]:
            session.add(Person(name=n, age=age, __check_on_init__=False))
        result = session.query(Person).order_by("age", "asc").all()
        assert [p.age for p in result] == [10, 20, 30]

    def test_order_by_desc(self, session, Person):
        for n, age in [("C", 30), ("A", 10), ("B", 20)]:
            session.add(Person(name=n, age=age, __check_on_init__=False))
        result = session.query(Person).order_by("age", "desc").all()
        assert [p.age for p in result] == [30, 20, 10]

    def test_offset_and_limit(self, session, Person):
        for n in ["A", "B", "C", "D", "E"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = (
            session.query(Person).order_by("name", "asc").offset(1).limit(2).all()
        )
        assert [p.name for p in result] == ["B", "C"]


class TestCountAndFirst:
    def test_count(self, session, Person):
        for n in ["A", "B", "C"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        assert session.query(Person).count() == 3

    def test_first(self, session, Person):
        a = Person(name="A", age=1, __check_on_init__=False)
        session.add(a)
        assert session.query(Person).first() is a

    def test_first_returns_none_when_empty(self, session, Person):
        assert session.query(Person).first() is None


class TestMergeAndDelete:
    def test_merge_existing_replaces(self, session, Person):
        p = Person(name="A", age=20, __check_on_init__=False)
        session.add(p)
        replacement = Person(name="A2", age=20, __check_on_init__=False)
        replacement.set_pk(p.get_pk())
        session.merge(replacement)
        assert session.get(p, p.get_pk()) is replacement

    def test_merge_new_adds(self, session, Person):
        p = Person(name="X", age=10, __check_on_init__=False)
        p.set_pk(99)
        session.merge(p)
        assert session.get(p, 99) is p

    def test_delete(self, session, Person):
        p = Person(name="A", age=1, __check_on_init__=False)
        session.add(p)
        session.delete(p)
        assert session.get(p, p.get_pk()) is None


class TestQueryReset:
    def test_after_all_query_is_reset(self, session, Person):
        session.add(Person(name="A", age=1, __check_on_init__=False))
        session.query(Person).all()
        assert session._query is None

    def test_yield_per_returns_all(self, session, Person):
        for n in ["A", "B"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).yield_per(10)
        assert len(result) == 2


class TestNoOps:
    def test_commit_flush_refresh_close_no_error(self, session):
        session.commit()
        session.flush()
        session.refresh(None)
        session.close()


class TestAddIdempotency:
    def test_add_existing_table_self_updates_in_place(self, session, Person):
        # If model.__table__ is the session itself, add() updates the slot
        p = Person(name="A", age=1, __check_on_init__=False)
        session.add(p)
        # Re-add same model -> hits "already in self" branch (lines 30-32)
        session.add(p)
        assert session.get(p, p.get_pk()) is p


class TestSaveLoadHooks:
    def test_load_data_default_noop(self, session):
        # Cover line 365 default body
        assert session.load_data() is None

    def test_save_data_default_noop(self, session):
        # Cover line 371 default body
        assert session.save_data() is None


class TestStringFilters:
    def test_not_starts_with(self, session, Person):
        for n in ["alice", "bob"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).not_starts_with("name", "al").all()
        assert [p.name for p in result] == ["bob"]

    def test_not_ends_with(self, session, Person):
        for n in ["abc", "abdef"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).not_ends_with("name", "def").all()
        assert [p.name for p in result] == ["abc"]

    def test_like(self, session, Person):
        for n in ["alpha", "beta"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).like("name", "alpha beta").all()
        names = sorted(p.name for p in result)
        assert names == ["alpha", "beta"]

    def test_not_like(self, session, Person):
        for n in ["alpha", "beta"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).not_like("name", "alpha").all()
        assert [p.name for p in result] == ["beta"]

    def test_ilike(self, session, Person):
        for n in ["Alpha", "Beta"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).ilike("name", "ALPHA bETa").all()
        names = sorted(p.name for p in result)
        assert names == ["Alpha", "Beta"]


class TestNumericFilters:
    def test_greater_equal(self, session, Person):
        for n, age in [("A", 10), ("B", 20), ("C", 30)]:
            session.add(Person(name=n, age=age, __check_on_init__=False))
        result = session.query(Person).greater_equal("age", 20).all()
        assert sorted(p.name for p in result) == ["B", "C"]

    def test_smaller(self, session, Person):
        for n, age in [("A", 10), ("B", 20)]:
            session.add(Person(name=n, age=age, __check_on_init__=False))
        result = session.query(Person).smaller("age", 20).all()
        assert [p.name for p in result] == ["A"]

    def test_compare_with_none_value(self, session, Person):
        # value=None short-circuits compare to False (line 587)
        session.add(Person(name="A", age=10, __check_on_init__=False))
        result = session.query(Person).greater("age", None).all()
        assert result == []


class TestGlobalFilter:
    def test_global_filter_matches(self, session, Person):
        for n in ["alice", "bob"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).global_filter(["name"], "alice").all()
        assert [p.name for p in result] == ["alice"]

    def test_global_filter_empty_value_returns_all(self, session, Person):
        # Line 567 short-circuit: empty value -> True for every item
        for n in ["a", "b"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).global_filter(["name"], "").all()
        assert len(result) == 2


class TestOrderByNoOrderApplied:
    def test_query_without_order_by_returns_data_unchanged(self, session, Person):
        # No order_by call -> _order_by_func short-circuits at line 304
        for n in ["a", "b"]:
            session.add(Person(name=n, age=1, __check_on_init__=False))
        result = session.query(Person).all()
        assert len(result) == 2


class TestFilterExceptionBranches:
    """Filter ops swallow AttributeError/TypeError to keep query iteration safe.

    Uncasted columns (`bad` not registered as a GenericColumn) trigger
    `_convert_value` -> `get_col_type` KeyError, which bubbles to the
    filter's `except Exception: return False` branch.
    """

    def _add_with_unknown_attr(self, session, Person):
        # Add a model and stash a string attribute the column ops don't know.
        p = Person(name="A", age=1, __check_on_init__=False)
        # Force-set raw attribute that get_col_type can't resolve
        object.__setattr__(p, "_unmanaged", "value")
        session.add(p)
        return p

    def test_starts_with_invalid_col_returns_false(self, session, Person):
        self._add_with_unknown_attr(session, Person)
        result = session.query(Person).starts_with("ghost", "x").all()
        assert result == []

    def test_not_starts_with_invalid_col_returns_false(self, session, Person):
        self._add_with_unknown_attr(session, Person)
        result = session.query(Person).not_starts_with("ghost", "x").all()
        assert result == []

    def test_ends_with_invalid_col_returns_false(self, session, Person):
        self._add_with_unknown_attr(session, Person)
        result = session.query(Person).ends_with("ghost", "x").all()
        assert result == []

    def test_not_ends_with_invalid_col_returns_false(self, session, Person):
        self._add_with_unknown_attr(session, Person)
        result = session.query(Person).not_ends_with("ghost", "x").all()
        assert result == []

    def test_like_invalid_col_returns_false(self, session, Person):
        self._add_with_unknown_attr(session, Person)
        result = session.query(Person).like("ghost", "x").all()
        assert result == []

    def test_not_like_invalid_col_returns_false(self, session, Person):
        self._add_with_unknown_attr(session, Person)
        result = session.query(Person).not_like("ghost", "x").all()
        assert result == []

    def test_ilike_invalid_col_returns_false(self, session, Person):
        self._add_with_unknown_attr(session, Person)
        result = session.query(Person).ilike("ghost", "x").all()
        assert result == []

    def test_equal_invalid_col_returns_false(self, session, Person):
        self._add_with_unknown_attr(session, Person)
        result = session.query(Person).equal("ghost", "x").all()
        assert result == []

    def test_not_equal_invalid_col_returns_false(self, session, Person):
        self._add_with_unknown_attr(session, Person)
        result = session.query(Person).not_equal("ghost", "x").all()
        assert result == []

    def test_in_invalid_col_returns_false(self, session, Person):
        self._add_with_unknown_attr(session, Person)
        result = session.query(Person).in_("ghost", ["x"]).all()
        assert result == []

    def test_compare_with_uncastable_value(self, session, Person):
        # Pass a non-numeric value into a numeric compare -> hits except branch
        session.add(Person(name="A", age=10, __check_on_init__=False))
        result = session.query(Person).greater("age", "not-a-number").all()
        # Filter swallows TypeError and yields nothing
        assert result == []

    def test_convert_value_with_date(self, session, Person):
        # Cover line 611 datetime.strptime with a date instance
        from datetime import date as _date

        # date triggers strptime branch in _convert_value; passing into _equal
        # The conversion happens internally; assert the filter doesn't crash.
        session.add(Person(name="A", age=1, __check_on_init__=False))
        result = session.query(Person).equal("name", _date(2024, 1, 1)).all()
        # Either swallowed or returns empty; either way doesn't crash
        assert isinstance(result, list)

    def test_convert_value_with_datetime(self, session, Person):
        # Cover line 613 (datetime.timestamp branch)
        from datetime import datetime as _dt

        session.add(Person(name="A", age=1, __check_on_init__=False))
        result = (
            session.query(Person).equal("name", _dt(2024, 1, 1, 0, 0, 0)).all()
        )
        assert isinstance(result, list)


class TestGenericSessionExtras:
    """Lines 304, 392-395: order_by no-data passthrough + silent=False raise.
    Plus load_data/save_data noop hooks."""

    def test_order_by_func_returns_data_when_no_order(self):
        from fastapi_rtk.backends.generic.session import GenericSession

        s = GenericSession()
        assert s._order_by is None
        out = s._order_by_func([1, 2, 3])
        assert out == [1, 2, 3]

    def test_text_contains_with_silent_false_raises(self):
        from fastapi_rtk.backends.generic.session import GenericSession

        s = GenericSession()

        class Blower:
            def __getattr__(self, name):
                raise RuntimeError("boom")

        with pytest.raises(RuntimeError):
            s._text_contains(Blower(), "missing", "x", silent=False)

    def test_load_data_save_data_are_noops(self):
        from fastapi_rtk.backends.generic.session import GenericSession

        s = GenericSession()
        assert s.load_data() is None
        assert s.save_data() is None
