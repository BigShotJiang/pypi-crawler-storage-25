import datetime
from enum import Enum

import pytest
from pydantic import EmailStr

from fastapi_rtk.backends.generic.column import GenericColumn
from fastapi_rtk.backends.generic.filters import (
    GenericFilterConverter,
    GenericFilterGlobal,
)
from fastapi_rtk.backends.generic.interface import GenericInterface
from fastapi_rtk.backends.generic.model import GenericModel
from fastapi_rtk.backends.generic.session import GenericSession


@pytest.fixture
def Person():
    class Person(GenericModel):
        id = GenericColumn(int, primary_key=True, auto_increment=True)
        name = GenericColumn(str)
        age = GenericColumn(int)

    return Person


@pytest.fixture
def Sess():
    class TS(GenericSession):
        pass

    return TS


@pytest.fixture
def iface(Person, Sess):
    return GenericInterface(Person, Sess)


@pytest.fixture
def populated(iface, Person, Sess):
    s = Sess()
    for n, age in [("Alice", 20), ("Bob", 30), ("Carol", 40)]:
        s.add(Person(name=n, age=age, __check_on_init__=False))
    yield s, iface


class TestInit:
    def test_session_must_be_class(self, Person, Sess):
        with pytest.raises(ValueError, match="must be a class"):
            GenericInterface(Person, Sess())

    def test_overloads_set(self, iface):
        assert isinstance(iface.filter_converter, GenericFilterConverter)
        assert iface.global_filter_class is GenericFilterGlobal

    def test_get_session_factory(self, iface, Sess):
        assert iface.get_session_factory() is Sess


class TestIsTypeChecks:
    def test_is_pk(self, iface):
        assert iface.is_pk("id") is True
        assert iface.is_pk("name") is False

    def test_is_nullable(self, iface):
        assert iface.is_nullable("name") is True

    def test_is_unique(self, iface):
        assert iface.is_unique("id") is True

    def test_is_string(self, iface):
        assert iface.is_string("name") is True
        assert iface.is_string("age") is False

    def test_is_integer(self, iface):
        assert iface.is_integer("age") is True

    def test_is_text_alias(self, iface):
        assert iface.is_text("name") is True

    def test_is_numeric_alias(self, iface):
        assert iface.is_numeric("age") is True

    def test_is_float_alias(self, iface):
        assert iface.is_float("age") is True  # float aliased to integer

    def test_is_boolean_with_bool_col(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            flag = GenericColumn(bool)

        class TS(GenericSession):
            pass

        m = GenericInterface(M, TS)
        assert m.is_boolean("flag") is True

    def test_is_date_with_date_col(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            d = GenericColumn(datetime.date)

        class TS(GenericSession):
            pass

        m = GenericInterface(M, TS)
        assert m.is_date("d") is True

    def test_is_datetime_with_dt_col(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            d = GenericColumn(datetime.datetime)

        class TS(GenericSession):
            pass

        m = GenericInterface(M, TS)
        assert m.is_datetime("d") is True

    def test_is_json_dict_col(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            data = GenericColumn(dict)

        class TS(GenericSession):
            pass

        m = GenericInterface(M, TS)
        assert m.is_json("data") is True
        assert m.is_jsonb("data") is True

    def test_is_list_bare_list_col(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            tags = GenericColumn(list)

        class TS(GenericSession):
            pass

        m = GenericInterface(M, TS)
        assert m.is_list("tags") is True
        assert m.get_list_col_type("tags") is None

    def test_is_list_parametrized_str(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            tags = GenericColumn(list[str])

        class TS(GenericSession):
            pass

        m = GenericInterface(M, TS)
        assert m.is_list("tags") is True
        assert m.get_list_col_type("tags") is str

    def test_is_list_parametrized_int(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            nums = GenericColumn(list[int])

        class TS(GenericSession):
            pass

        m = GenericInterface(M, TS)
        assert m.is_list("nums") is True
        assert m.get_list_col_type("nums") is int

    def test_is_list_false_for_non_list(self, iface):
        assert iface.is_list("name") is False
        assert iface.get_list_col_type("name") is None

    def test_is_list_unknown_returns_false(self, iface):
        assert iface.is_list("ghost") is False
        assert iface.get_list_col_type("ghost") is None

    def test_is_relation_returns_false_for_scalar(self, iface):
        assert iface.is_relation("name") is False

    def test_unknown_col_returns_false(self, iface):
        assert iface.is_pk("ghost") is False
        assert iface.is_string("ghost") is False
        assert iface.is_integer("ghost") is False


class TestTypeName:
    def test_string(self, iface):
        assert iface.get_type_name("name") == "String"

    def test_integer(self, iface):
        assert iface.get_type_name("age") == "Integer"

    def test_unknown_returns_raw(self, iface):
        assert iface.get_type_name("ghost") == "Raw"


class TestColumnLists:
    def test_init_list_columns(self, iface):
        cols = iface.init_list_columns()
        assert set(cols.keys()) == {"id", "name", "age"}

    def test_init_list_properties(self, iface):
        props = iface.init_list_properties()
        assert "id" in props


class TestRelatedModel:
    def test_raises_on_non_relation(self, iface):
        with pytest.raises(ValueError, match="not a relation"):
            iface.get_related_model("name")


@pytest.mark.asyncio
class TestCRUDViaSession:
    async def test_count(self, populated):
        sess, iface = populated
        assert await iface.count(sess) == 3

    async def test_get_many(self, populated):
        sess, iface = populated
        result = await iface.get_many(sess)
        assert len(result) == 3

    async def test_get_one(self, populated):
        sess, iface = populated
        item = await iface.get_one(sess)
        assert item is not None

    async def test_yield_per(self, populated):
        sess, iface = populated
        chunks = []
        async for chunk in iface.yield_per(sess, {"page_size": 2}):
            chunks.append(chunk)
        total = sum(len(c) for c in chunks)
        assert total == 3

    async def test_add(self, iface, Person, Sess):
        sess = Sess()
        p = Person(name="X", age=1, __check_on_init__=False)
        result = await iface.add(sess, p)
        assert result is p
        assert sess.get(p, p.get_pk()) is p

    async def test_edit_via_merge(self, iface, Person, Sess):
        sess = Sess()
        p = Person(name="A", age=1, __check_on_init__=False)
        await iface.add(sess, p)
        p.name = "B"
        result = await iface.edit(sess, p)
        assert result is p

    async def test_delete(self, iface, Person, Sess):
        sess = Sess()
        p = Person(name="A", age=1, __check_on_init__=False)
        await iface.add(sess, p)
        await iface.delete(sess, p)
        assert sess.get(p, p.get_pk()) is None

    async def test_commit_close_noop(self, iface, Sess):
        sess = Sess()
        await iface.commit(sess)
        await iface.close(sess)

    async def test_edit_with_refresh(self, iface, Person, Sess):
        sess = Sess()
        p = Person(name="A", age=1, __check_on_init__=False)
        await iface.add(sess, p)
        result = await iface.edit(sess, p, refresh=True)
        assert result is p


class TestColumnListHelpers:
    def test_get_add_column_list(self, iface):
        # Generic backend: add list == user column list
        cols = iface.get_add_column_list()
        assert "name" in cols
        assert "age" in cols

    def test_get_edit_column_list(self, iface):
        cols = iface.get_edit_column_list()
        assert "name" in cols

    def test_get_order_column_list(self, iface):
        ordered = iface.get_order_column_list(["id", "name", "age"])
        # No property columns, so all stay
        assert "name" in ordered

    def test_get_search_column_list(self, iface):
        # Excludes pk + relations
        result = iface.get_search_column_list(["id", "name", "age"])
        assert "id" not in result
        assert "name" in result


class TestGetType:
    def test_get_type_returns_col_type(self, iface):
        assert iface.get_type("name") is str
        assert iface.get_type("age") is int

    def test_get_enum_value_returns_type(self, iface):
        # Generic backend aliases get_enum_value to get_type
        assert iface.get_enum_value("name") is str


class TestTypeNameExtras:
    def test_boolean(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            flag = GenericColumn(bool)

        class TS(GenericSession):
            pass

        m = GenericInterface(M, TS)
        assert m.get_type_name("flag") == "Boolean"

    def test_datetime_label_via_date_col(self):
        # get_type_name maps is_date -> "DateTime"
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            d = GenericColumn(datetime.date)

        class TS(GenericSession):
            pass

        m = GenericInterface(M, TS)
        assert m.get_type_name("d") == "DateTime"


class TestIsKeyErrorBranches:
    def test_is_nullable_unknown_returns_false(self, iface):
        assert iface.is_nullable("ghost") is False

    def test_is_unique_unknown_returns_false(self, iface):
        assert iface.is_unique("ghost") is False

    def test_is_datetime_unknown_returns_false(self, iface):
        assert iface.is_datetime("ghost") is False

    def test_is_enum_unknown_returns_false(self, iface):
        assert iface.is_enum("ghost") is False

    def test_is_json_unknown_returns_false(self, iface):
        assert iface.is_json("ghost") is False


class TestRelationKeyErrorBranches:
    def test_relation_one_to_one_unknown(self, iface):
        # KeyError -> bare `False` statement (line 291 dead code), should return None
        result = iface.is_relation_one_to_one("ghost")
        assert result in (False, None)

    def test_relation_one_to_many_with_list_value(self):
        # Hit the inner loop on lines 297-303: list of properties
        class Child(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)

        class Parent(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)

        class TS(GenericSession):
            pass

        m = GenericInterface(Parent, TS)
        # Manually set a list property of GenericModel instances
        m.list_properties["children"] = [
            Child(__check_on_init__=False),
            Child(__check_on_init__=False),
        ]
        assert m.is_relation_one_to_many("children") is True

    def test_relation_one_to_many_with_non_genericmodel_in_list(self):
        class TS(GenericSession):
            pass

        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)

        m = GenericInterface(M, TS)
        m.list_properties["bad"] = ["not", "models"]
        assert m.is_relation_one_to_many("bad") is False

    def test_relation_one_to_many_unknown(self, iface):
        assert iface.is_relation_one_to_many("ghost") is False

    def test_relation_many_to_one_returns_false(self, iface):
        assert iface.is_relation_many_to_one("name") is False

    def test_relation_many_to_many_returns_false(self, iface):
        assert iface.is_relation_many_to_many("name") is False


class TestGetRelatedModelWithRelation:
    def test_get_related_model_for_relation(self):
        class Child(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)

        class Parent(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)

        class TS(GenericSession):
            pass

        m = GenericInterface(Parent, TS)
        m.list_properties["child"] = Child(__check_on_init__=False)
        result = m.get_related_model("child")
        # Returns __class__ of the property
        assert result is Child


@pytest.mark.asyncio
class TestOnShutdown:
    async def test_on_shutdown_calls_save(self, iface, monkeypatch):
        called = {"flag": False}

        # Patch the session class' save_data so on_shutdown invokes it
        def fake_save(self):
            called["flag"] = True

        monkeypatch.setattr(iface.session, "save_data", fake_save)
        await iface.on_shutdown()
        assert called["flag"] is True
