import pytest

from fastapi_rtk.backends.generic.column import (
    PK_AUTO_INCREMENT,
    UNSET,
    GenericColumn,
    GenericPKAutoIncrement,
    GenericUnset,
)
from fastapi_rtk.backends.generic.exceptions import (
    ColumnInvalidTypeException,
    GenericColumnException,
)
from fastapi_rtk.backends.generic.model import GenericModel


class TestSentinels:
    def test_pk_auto_increment_repr(self):
        assert repr(PK_AUTO_INCREMENT) == "GENERICPKAUTOINCREMENT"

    def test_unset_repr(self):
        assert repr(UNSET) == "GENERICUNSET"

    def test_pk_auto_increment_is_singleton_type(self):
        assert isinstance(PK_AUTO_INCREMENT, GenericPKAutoIncrement)

    def test_unset_is_singleton_type(self):
        assert isinstance(UNSET, GenericUnset)


class TestColumnInit:
    def test_primary_key_forces_unique_and_not_nullable(self):
        col = GenericColumn(int, primary_key=True)
        assert col.unique is True
        assert col.nullable is False

    def test_auto_increment_requires_primary_key(self):
        with pytest.raises(GenericColumnException, match="primary key"):
            GenericColumn(int, auto_increment=True)

    def test_auto_increment_requires_int_type(self):
        with pytest.raises(GenericColumnException, match="must be of type int"):
            GenericColumn(str, primary_key=True, auto_increment=True)

    def test_default_callable_no_args_wrapped(self):
        col = GenericColumn(int, default=lambda: 42)
        assert callable(col.default)
        # Wrapped lambda accepts (instance) but discards it
        assert col.default(None) == 42

    def test_default_callable_with_instance_param_kept(self):
        def with_instance(instance):
            return id(instance)

        col = GenericColumn(int, default=with_instance)
        assert col.default is with_instance


class TestColumnDescriptorAccess:
    def _make_model(self, **column_kwargs):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            x = GenericColumn(int, **column_kwargs)

        return M

    def test_get_on_class_returns_descriptor(self):
        M = self._make_model()
        assert isinstance(M.x, GenericColumn)

    def test_get_unset_nullable_returns_none(self):
        M = self._make_model(nullable=True)
        m = M(__check_on_init__=False)
        assert m.x is None

    def test_get_unset_with_default_returns_default(self):
        M = self._make_model(default=99)
        m = M(__check_on_init__=False)
        assert m.x == 99

    def test_get_unset_with_callable_default_invokes_callable(self):
        M = self._make_model(default=lambda instance: 7)
        m = M(__check_on_init__=False)
        assert m.x == 7

    def test_set_validates_type(self):
        M = self._make_model()
        m = M(__check_on_init__=False)
        with pytest.raises(ColumnInvalidTypeException):
            m.x = "not-an-int"

    def test_set_then_get(self):
        M = self._make_model()
        m = M(__check_on_init__=False)
        m.x = 7
        assert m.x == 7

    def test_pk_auto_increment_returns_sentinel_when_not_set(self):
        M = self._make_model()
        m = M(__check_on_init__=False)
        # id is auto_increment pk, not yet set
        assert m.id is PK_AUTO_INCREMENT


class TestIsColumnSet:
    def test_unset_returns_false(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            x = GenericColumn(int)

        m = M(__check_on_init__=False)
        assert M.x.is_column_set(m) is False

    def test_set_returns_true(self):
        class M(GenericModel):
            id = GenericColumn(int, primary_key=True, auto_increment=True)
            x = GenericColumn(int)

        m = M(__check_on_init__=False)
        m.x = 5
        assert M.x.is_column_set(m) is True


class TestRepr:
    def test_repr_includes_attrs(self):
        col = GenericColumn(int, primary_key=True)
        r = repr(col)
        assert "GenericColumn" in r
        assert "primary_key=True" in r
