import pytest

from fastapi_rtk.backends.generic.column import GenericColumn
from fastapi_rtk.backends.generic.db import GenericQueryBuilder
from fastapi_rtk.backends.generic.interface import GenericInterface
from fastapi_rtk.backends.generic.model import GenericModel
from fastapi_rtk.backends.generic.session import GenericSession
from fastapi_rtk.exceptions import HTTPWithValidationException


@pytest.fixture
def Person():
    class Person(GenericModel):
        id = GenericColumn(int, primary_key=True, auto_increment=True)
        name = GenericColumn(str)
        age = GenericColumn(int)

    return Person


@pytest.fixture
def Sess():
    class TS(GenericSession):
        pass

    return TS


@pytest.fixture
def iface(Person, Sess):
    return GenericInterface(Person, Sess)


@pytest.fixture
def populated(iface, Person, Sess):
    sess = Sess()
    for n, age in [("Alice", 20), ("Bob", 30), ("Carol", 40)]:
        sess.add(Person(name=n, age=age, __check_on_init__=False))
    return sess, iface


@pytest.mark.asyncio
class TestApplyMethods:
    async def test_pagination(self, populated):
        sess, iface = populated
        # Use page=0 page_size=2 -> first 2 items
        result = await iface.query.build_query({"page": 0, "page_size": 2})
        assert len(result.all()) == 2

    async def test_order_by_strips_class_prefix(self, populated):
        sess, iface = populated
        result = await iface.query.build_query(
            {"order_column": "Person.age", "order_direction": "asc"}
        )
        ages = [p.age for p in result.all()]
        assert ages == sorted(ages)

    async def test_apply_where_via_equal(self, populated):
        sess, iface = populated
        result = await iface.query.build_query({"where": ("name", "Alice")})
        names = [p.name for p in result.all()]
        assert names == ["Alice"]

    async def test_apply_where_in(self, populated):
        sess, iface = populated
        result = await iface.query.build_query(
            {"where_in": ("name", ["Alice", "Bob"])}
        )
        names = sorted(p.name for p in result.all())
        assert names == ["Alice", "Bob"]

    async def test_apply_filter_invalid_opr_raises(self, populated):
        sess, iface = populated
        with pytest.raises(HTTPWithValidationException):
            await iface.query.build_query(
                {"filters": [{"col": "name", "opr": "bogus_op", "value": "x"}]}
            )

    async def test_apply_filter_via_eq(self, populated):
        sess, iface = populated
        result = await iface.query.build_query(
            {"filters": [{"col": "name", "opr": "eq", "value": "Bob"}]}
        )
        assert [p.name for p in result.all()] == ["Bob"]

    async def test_apply_global_filter(self, populated):
        sess, iface = populated
        result = await iface.query.build_query(
            {"global_filter": (["name"], "Alice")}
        )
        assert any(p.name == "Alice" for p in result.all())

    async def test_apply_opr_filter_invalid_raises(self, populated):
        sess, iface = populated
        with pytest.raises(HTTPWithValidationException):
            await iface.query.build_query(
                {"opr_filters": [{"opr": "bogus_op", "value": "x"}]}
            )

    async def test_apply_opr_filter_class_with_opr_filter(self, populated):
        sess, iface = populated

        from fastapi_rtk.backends.generic.filters import GenericBaseOprFilter

        class MyOpr(GenericBaseOprFilter):
            name = "my"
            arg_name = "my"

            def apply(self, statement, value):
                return statement

        f = MyOpr(iface)
        result = await iface.query.build_query(
            {"opr_filter_classes": [(f, "anything")]}
        )
        assert len(result.all()) == 3

    async def test_apply_list_columns_is_noop(self, populated):
        sess, iface = populated
        # apply_list_columns is a noop in generic backend (line 31).
        result = await iface.query.build_query({"list_columns": ["name", "age"]})
        assert len(result.all()) == 3

    async def test_apply_opr_filter_resolves_via_arg_name(self, populated):
        sess, iface = populated

        from fastapi_rtk.backends.generic.filters import GenericBaseOprFilter

        class NoopOpr(GenericBaseOprFilter):
            name = "noop"
            arg_name = "noop"

            def apply(self, statement, value):
                return statement

        # Register filter on the interface so apply_opr_filter resolves it by arg_name
        iface.opr_filters.append(NoopOpr(iface))
        result = await iface.query.build_query(
            {"opr_filters": [{"opr": "noop", "value": "x"}]}
        )
        assert len(result.all()) == 3

    async def test_apply_opr_filter_class_with_regular_filter(self, populated):
        sess, iface = populated

        from fastapi_rtk.backends.generic.filters import GenericBaseFilter

        class MyFilter(GenericBaseFilter):
            name = "f"
            arg_name = "f"

            def apply(self, statement, col, value):
                return statement.equal("name", "Alice")

        f = MyFilter(iface)
        result = await iface.query.build_query(
            {"opr_filter_classes": [(f, "anything")]}
        )
        assert [p.name for p in result.all()] == ["Alice"]
