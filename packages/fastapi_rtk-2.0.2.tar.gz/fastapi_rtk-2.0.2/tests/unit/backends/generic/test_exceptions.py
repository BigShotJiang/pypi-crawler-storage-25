from fastapi_rtk.backends.generic.exceptions import (
    ColumnInvalidTypeException,
    ColumnNotSetException,
    GenericColumnException,
    MultipleColumnsException,
    PKMissingException,
    PKMultipleException,
)


class TestGenericColumnException:
    def test_stores_column_and_message(self):
        e = GenericColumnException(column="COL", message="bad")
        assert e.column == "COL"
        assert e.message == "bad"

    def test_repr_includes_message_and_column(self):
        e = GenericColumnException(column="COL", message="bad")
        assert "bad" in repr(e)
        assert "COL" in repr(e)


class TestModelClassExceptions:
    def test_pk_missing(self):
        e = PKMissingException("Foo", "Primary key is missing")
        assert e.model_name == "Foo"
        assert "Foo" in repr(e)

    def test_pk_multiple(self):
        e = PKMultipleException("Foo", "Only one primary key is allowed")
        assert e.message == "Only one primary key is allowed"

    def test_repr_format(self):
        e = PKMissingException("M", "msg")
        assert repr(e) == "msg for model M"


class TestColumnNotSet:
    def test_stores_model(self):
        e = ColumnNotSetException("M", "Column x not set")
        assert e.model == "M"
        assert e.message == "Column x not set"


class TestColumnInvalidType:
    def test_stores_model_and_message(self):
        e = ColumnInvalidTypeException("M", "Invalid type")
        assert e.message == "Invalid type"


class TestMultipleColumnsException:
    def test_aggregates_messages(self):
        errs = [
            ColumnNotSetException("M", "a missing"),
            ColumnNotSetException("M", "b missing"),
        ]
        e = MultipleColumnsException("M", errs)
        assert e.errors == errs
        assert "a missing" in e.message
        assert "b missing" in e.message
