from types import SimpleNamespace

import pytest
import sqlalchemy.dialects.postgresql as postgresql
import sqlalchemy.types as sa_types

from fastapi_rtk import types as rtk_types
from fastapi_rtk.exceptions import FastAPIReactToolkitException


def _stub_global(name):
    g = rtk_types.g
    sentinel = object()
    original_default = g._defaults.get(name, sentinel)
    original_bootstrap = g._bootstrap_values.get(name, sentinel)

    def _set(mgr):
        g._defaults[name] = mgr
        g._bootstrap_values[name] = mgr

    def _restore():
        if original_default is sentinel:
            g._defaults.pop(name, None)
        else:
            g._defaults[name] = original_default
        if original_bootstrap is sentinel:
            g._bootstrap_values.pop(name, None)
        else:
            g._bootstrap_values[name] = original_bootstrap

    return _set, _restore


@pytest.fixture
def stub_file_manager():
    setter, restore = _stub_global("file_manager")
    yield setter
    restore()


@pytest.fixture
def stub_image_manager():
    setter, restore = _stub_global("image_manager")
    yield setter
    restore()


class TestListColumn:
    def test_default_impl_is_json(self):
        assert rtk_types.ListColumn.impl is sa_types.JSON

    def test_process_bind_param_passes_list_through(self):
        col = rtk_types.ListColumn()
        assert col.process_bind_param([1, 2, 3], dialect=None) == [1, 2, 3]

    def test_process_bind_param_falsy_returns_value(self):
        col = rtk_types.ListColumn()
        assert col.process_bind_param(None, dialect=None) is None
        assert col.process_bind_param([], dialect=None) == []

    def test_process_bind_param_rejects_non_list(self):
        col = rtk_types.ListColumn()
        with pytest.raises(ValueError, match="must be a list"):
            col.process_bind_param("not-a-list", dialect=None)

    def test_process_bind_param_coerces_with_col_type(self):
        col = rtk_types.ListColumn(col_type=int)
        assert col.process_bind_param(["1", "2", "3"], dialect=None) == [1, 2, 3]

    def test_col_type_default_none(self):
        col = rtk_types.ListColumn()
        assert col.col_type is None

    def test_cache_ok(self):
        assert rtk_types.ListColumn.cache_ok is True


class TestJSONBListColumn:
    def test_impl_is_jsonb(self):
        assert rtk_types.JSONBListColumn.impl is postgresql.JSONB

    def test_inherits_from_list_column(self):
        assert issubclass(rtk_types.JSONBListColumn, rtk_types.ListColumn)


class TestFileColumn:
    def test_init_uses_manager_allowed_extensions_when_none(self, stub_file_manager):
        stub_file_manager(SimpleNamespace(allowed_extensions=["png", "jpg"]))
        col = rtk_types.FileColumn()
        assert col.allowed_extensions == ["png", "jpg"]

    def test_init_with_subset_allowed(self, stub_file_manager):
        stub_file_manager(SimpleNamespace(allowed_extensions=["png", "jpg", "gif"]))
        col = rtk_types.FileColumn(allowed_extensions=["png"])
        assert col.allowed_extensions == ["png"]

    def test_init_rejects_extension_not_allowed_by_manager(self, stub_file_manager):
        stub_file_manager(SimpleNamespace(allowed_extensions=["png"]))
        with pytest.raises(FastAPIReactToolkitException, match="not in the allowed"):
            rtk_types.FileColumn(allowed_extensions=["exe"])

    def test_init_with_manager_allowing_all(self, stub_file_manager):
        stub_file_manager(SimpleNamespace(allowed_extensions=None))
        col = rtk_types.FileColumn(allowed_extensions=["anything"])
        assert col.allowed_extensions == ["anything"]

    def test_impl_is_text(self):
        assert rtk_types.FileColumn.impl is sa_types.Text


class TestImageColumn:
    def test_uses_image_manager(self, stub_image_manager):
        stub_image_manager(SimpleNamespace(allowed_extensions=["png", "jpg"]))
        col = rtk_types.ImageColumn()
        assert col.allowed_extensions == ["png", "jpg"]

    def test_default_thumbnail_and_size(self, stub_image_manager):
        stub_image_manager(SimpleNamespace(allowed_extensions=None))
        col = rtk_types.ImageColumn()
        assert col.thumbnail_size == (20, 20, True)
        assert col.size == (100, 100, True)

    def test_custom_thumbnail_and_size(self, stub_image_manager):
        stub_image_manager(SimpleNamespace(allowed_extensions=None))
        col = rtk_types.ImageColumn(
            allowed_extensions=["png"], thumbnail_size=(50, 50, False), size=(300, 300, False)
        )
        assert col.thumbnail_size == (50, 50, False)
        assert col.size == (300, 300, False)


class TestColumnAggregates:
    def test_file_columns_impl_is_list_column(self):
        assert rtk_types.FileColumns.impl is rtk_types.ListColumn

    def test_image_columns_impl_is_list_column(self):
        assert rtk_types.ImageColumns.impl is rtk_types.ListColumn

    def test_jsonb_file_columns_impl_is_jsonb_list(self):
        assert rtk_types.JSONBFileColumns.impl is rtk_types.JSONBListColumn

    def test_jsonb_image_columns_impl_is_jsonb_list(self):
        assert rtk_types.JSONBImageColumns.impl is rtk_types.JSONBListColumn

    def test_all_export_list(self):
        for name in rtk_types.__all__:
            assert hasattr(rtk_types, name)
