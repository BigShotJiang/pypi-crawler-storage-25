import importlib
import sys


class TestModelsDeprecated:
    def test_warns_on_import(self, caplog):
        if "fastapi_rtk.models" in sys.modules:
            del sys.modules["fastapi_rtk.models"]
        with caplog.at_level("WARNING", logger="DT_FASTAPI"):
            importlib.import_module("fastapi_rtk.models")
        assert any("deprecated" in rec.message for rec in caplog.records)

    def test_re_exports_security_models(self):
        if "fastapi_rtk.models" in sys.modules:
            del sys.modules["fastapi_rtk.models"]
        mod = importlib.import_module("fastapi_rtk.models")
        sec_models = importlib.import_module("fastapi_rtk.security.sqla.models")
        for name in getattr(sec_models, "__all__", []):
            assert hasattr(mod, name)
