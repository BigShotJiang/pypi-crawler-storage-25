"""Tier - QuerySchema validator coverage. Many branches encode contract
errors the frontend depends on; guard the failure shape too.
"""

import pytest

from fastapi_rtk.exceptions import HTTPWithValidationException
from fastapi_rtk.schemas import (
    FilterSchema,
    OprFilterSchema,
    QueryBody,
    QuerySchema,
)


class TestColumnsValidator:
    def test_valid_list_string(self):
        q = QuerySchema(columns='["a", "b"]')
        assert q.columns == ["a", "b"]

    def test_non_list_raises(self):
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(columns='{"x": 1}')

    def test_invalid_json_raises(self):
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(columns="not-json")


class TestOrderValidator:
    def test_only_direction_raises(self):
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(order_direction="asc")

    def test_both_present_ok(self):
        q = QuerySchema(order_column="x", order_direction="asc")
        assert q.order_direction == "asc"


class TestFiltersValidator:
    def test_valid_dict_list_string(self):
        q = QuerySchema(filters='[{"col":"a","opr":"eq","value":"x"}]')
        assert isinstance(q.filters[0], FilterSchema)

    def test_non_list_raises(self):
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(filters='{"a":"b"}')

    def test_invalid_json_raises(self):
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(filters="garbage")

    def test_querybody_accepts_filter_objects(self):
        # QueryBody has list[FilterSchema] - validator branch for FilterSchema instance.
        body = QueryBody(filters=[FilterSchema(col="a", opr="eq", value="x")])
        assert isinstance(body.filters[0], FilterSchema)


class TestOprFiltersValidator:
    def test_valid_dict_list_string(self):
        q = QuerySchema(opr_filters='[{"opr":"x","value":"y"}]')
        assert isinstance(q.opr_filters[0], OprFilterSchema)

    def test_non_list_raises(self):
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(opr_filters='{"x":"y"}')

    def test_invalid_json_raises(self):
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(opr_filters="not-json")


class TestQValidator:
    def test_q_none(self):
        q = QuerySchema(q=None)
        assert q.q is None

    def test_q_rison_object_replaces(self):
        # rison form: page=1
        q = QuerySchema(q="(page:1)")
        # After replace_with_q the page got applied
        assert q.page == 1

    def test_q_non_dict_raises(self):
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(q="!t")  # rison true literal -> non-dict

    def test_q_invalid_json_raises(self):
        # Trigger json.JSONDecodeError branch (line 579) by passing
        # a string that is neither valid rison nor JSON.
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(q="!@#$ not-rison-not-json")


class TestFiltersValidationError:
    def test_filter_non_dict_element_raises(self):
        # Element in the list isn't a dict -> hits dict_type raise (485).
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(filters='[123]')

    def test_filter_validation_error_raises(self):
        # Filter dict missing required `col` field forces FilterSchema
        # ValidationError -> hits literal_error raise (504).
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(filters='[{"opr":"eq","value":"x"}]')


class TestOprFiltersValidationError:
    def test_opr_filter_non_dict_element_raises(self):
        # Element in opr_filters list isn't a dict -> hits dict_type raise (535).
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(opr_filters='[42]')

    def test_opr_filter_validation_error_raises(self):
        # Missing required `opr` field -> hits literal_error (554).
        with pytest.raises(HTTPWithValidationException):
            QuerySchema(opr_filters='[{"value":"x"}]')


class TestFilterSchemaInstancesPassThrough:
    def test_filters_with_filter_schema_instance(self):
        # A FilterSchema instance in the input list is appended as-is
        # (line 481 branch).
        from fastapi_rtk.schemas import QueryBody

        f = FilterSchema(col="a", opr="eq", value="x")
        body = QueryBody(filters=[f])
        assert body.filters[0] is f

