"""Tier 13 - tests for fastapi_rtk.apis.license."""

import pytest
from fastapi_rtk.apis.license import (
    LicenseApi,
    LicenseModel,
    LicenseParser,
    LicenseParserError,
    LicenseParserRegistry,
    LicenseSession,
    NPMLicenseCheckerParser,
    PIPLicenseParser,
)


class TestLicenseParserError:
    def test_message_and_data(self):
        err = LicenseParserError({"foo": "bar"}, "boom")
        assert err.data == {"foo": "bar"}
        assert err.message == "boom"

    def test_default_message(self):
        err = LicenseParserError([])
        assert err.message == "Error processing license data"

    def test_str_includes_message(self):
        err = LicenseParserError([], "custom")
        assert "custom" in str(err)


class TestLicenseModel:
    def test_columns_present(self):
        for col in ("id", "name", "version", "license", "license_text", "metadata"):
            assert col in LicenseModel.__mapper__.properties

    def test_assignment(self):
        m = LicenseModel()
        m.name = "pkg"
        m.version = "1.0"
        assert m.name == "pkg"
        assert m.version == "1.0"


class TestPIPLicenseParser:
    def test_processes_valid_data(self):
        parser = PIPLicenseParser()
        data = [
            {
                "Name": "requests",
                "Version": "2.31.0",
                "License": "Apache 2.0",
                "LicenseFile": "/tmp/x",
                "LicenseText": "Apache License...",
            }
        ]
        models, errors = parser.process(data)
        assert len(models) == 1
        assert models[0].name == "requests"
        assert models[0].version == "2.31.0"
        assert models[0].license == "Apache 2.0"
        assert errors == []

    def test_non_list_raises(self):
        parser = PIPLicenseParser()
        with pytest.raises(LicenseParserError):
            parser.process({"not": "a list"})

    def test_missing_keys_collects_error(self):
        parser = PIPLicenseParser()
        data = [{"Name": "incomplete"}]
        models, errors = parser.process(data)
        assert models == []
        assert len(errors) == 1


class TestNPMLicenseCheckerParser:
    def test_processes_valid_data(self):
        parser = NPMLicenseCheckerParser()
        data = {
            "react@18.0.0": {
                "licenses": "MIT",
                "path": "/node_modules/react",
                "licenseFile": "/nonexistent",
            }
        }
        models, errors = parser.process(data)
        assert len(models) == 1
        assert models[0].name == "react"
        assert models[0].version == "18.0.0"
        assert models[0].license == "MIT"
        assert models[0].license_text == ""

    def test_no_at_in_key(self):
        parser = NPMLicenseCheckerParser()
        data = {
            "noversion": {
                "licenses": "MIT",
                "path": "/x",
                "licenseFile": "",
            }
        }
        models, _ = parser.process(data)
        assert models[0].name == "noversion"
        assert models[0].version == ""

    def test_reads_license_file_when_exists(self, tmp_path):
        parser = NPMLicenseCheckerParser()
        f = tmp_path / "LICENSE"
        f.write_text("Hello license content")
        data = {
            "pkg@1.0": {
                "licenses": "MIT",
                "path": str(tmp_path),
                "licenseFile": str(f),
            }
        }
        models, _ = parser.process(data)
        assert "Hello license content" in models[0].license_text

    def test_license_file_read_error_caught(self, tmp_path, monkeypatch):
        parser = NPMLicenseCheckerParser()
        f = tmp_path / "LICENSE"
        f.write_text("ok")

        real_open = open

        def fake_open(path, *args, **kwargs):
            if str(path) == str(f):
                raise OSError("nope")
            return real_open(path, *args, **kwargs)

        monkeypatch.setattr("builtins.open", fake_open)

        data = {
            "pkg@1.0": {
                "licenses": "MIT",
                "path": str(tmp_path),
                "licenseFile": str(f),
            }
        }
        models, _ = parser.process(data)
        assert models[0].license_text == ""

    def test_non_dict_raises(self):
        parser = NPMLicenseCheckerParser()
        with pytest.raises(LicenseParserError):
            parser.process(["not", "a", "dict"])

    def test_missing_keys_skipped_with_error(self):
        parser = NPMLicenseCheckerParser()
        data = {"pkg@1": {"licenses": "MIT"}}  # missing path + licenseFile
        models, errors = parser.process(data)
        assert models == []
        assert len(errors) == 1


class TestLicenseParserRegistry:
    def test_get_licenses_pip_path(self):
        data = [
            {
                "Name": "requests",
                "Version": "2.31.0",
                "License": "Apache 2.0",
                "LicenseFile": "",
                "LicenseText": "",
            }
        ]
        models, _ = LicenseParserRegistry.get_licenses(data)
        assert models[0].name == "requests"

    def test_get_licenses_npm_path(self):
        data = {
            "react@18": {
                "licenses": "MIT",
                "path": "/x",
                "licenseFile": "",
            }
        }
        models, _ = LicenseParserRegistry.get_licenses(data)
        assert models[0].name == "react"

    def test_all_processors_fail_raises(self):
        # Bare string doesn't match list (pip) or dict (npm)
        # Wait - npm requires dict, pip requires list. Use int.
        with pytest.raises(LicenseParserError, match="All processors failed"):
            LicenseParserRegistry.get_licenses(42)

    def test_register_processor(self):
        class FakeParser(LicenseParser):
            def process(self, data):
                return [], []

        original_count = len(LicenseParserRegistry.processors)
        try:
            LicenseParserRegistry.register_processor(FakeParser())
            assert len(LicenseParserRegistry.processors) == original_count + 1
        finally:
            LicenseParserRegistry.processors.pop()


class TestLicenseSession:
    def test_load_data_no_folder(self, config_setter):
        config_setter("LICENSE_FOLDER", "/nonexistent/path/xyz")
        original_add_api = LicenseSession.add_api
        try:
            session = LicenseSession()
            session.load_data()
            # Folder absent -> add_api stays at original value
            assert LicenseSession.add_api == original_add_api
        finally:
            LicenseSession.add_api = original_add_api

    def test_load_data_with_valid_pip_file(self, tmp_path, config_setter):
        config_setter("LICENSE_FOLDER", str(tmp_path))
        license_file = tmp_path / "pip.json"
        import json

        license_file.write_text(
            json.dumps(
                [
                    {
                        "Name": "requests",
                        "Version": "2.31.0",
                        "License": "Apache 2.0",
                        "LicenseFile": "",
                        "LicenseText": "",
                    }
                ]
            )
        )
        original_add_api = LicenseSession.add_api
        try:
            session = LicenseSession()
            session.load_data()
            assert LicenseSession.add_api is True
        finally:
            LicenseSession.add_api = original_add_api

    def test_load_data_skips_non_json(self, tmp_path, config_setter):
        config_setter("LICENSE_FOLDER", str(tmp_path))
        (tmp_path / "readme.txt").write_text("not json")
        original_add_api = LicenseSession.add_api
        try:
            session = LicenseSession()
            session.load_data()
            # Folder exists but no .json -> add_api set to True regardless
            # (set when folder exists, before iterating)
            assert LicenseSession.add_api is True
        finally:
            LicenseSession.add_api = original_add_api

    def test_load_data_with_partial_errors_logs_warning(
        self, tmp_path, config_setter, caplog
    ):
        # Mixed dict: one valid entry + one missing keys -> errors list non-empty
        # so the warning branch (line 181) fires.
        config_setter("LICENSE_FOLDER", str(tmp_path))
        license_file = tmp_path / "npm.json"
        import json

        license_file.write_text(
            json.dumps(
                {
                    "good@1.0": {
                        "licenses": "MIT",
                        "path": "/x",
                        "licenseFile": "",
                    },
                    "broken@2.0": {"licenses": "MIT"},
                }
            )
        )
        original_add_api = LicenseSession.add_api
        try:
            session = LicenseSession()
            with caplog.at_level("WARNING"):
                session.load_data()
            assert any("with some errors" in r.message for r in caplog.records)
        finally:
            LicenseSession.add_api = original_add_api

    def test_load_data_handles_invalid_json(self, tmp_path, config_setter):
        config_setter("LICENSE_FOLDER", str(tmp_path))
        (tmp_path / "bad.json").write_text("{not valid json")
        original_add_api = LicenseSession.add_api
        try:
            session = LicenseSession()
            # Errors are logged but don't crash
            session.load_data()
        finally:
            LicenseSession.add_api = original_add_api


class TestLicenseApi:
    def test_resource_name(self):
        assert LicenseApi.resource_name == "licenses"

    def test_modelrestapi_branch_when_add_api_true(
        self, tmp_path, config_setter, monkeypatch
    ):
        # Force LicenseSession.add_api=True at module reload time so the
        # `if LicenseSession.add_api:` branch creates the ModelRestApi version
        # of LicenseApi. Validates lines 192-200.
        import importlib
        import json

        config_setter("LICENSE_FOLDER", str(tmp_path))
        config_setter("LICENSE_SHOW_METADATA", False)
        (tmp_path / "lic.json").write_text(
            json.dumps(
                [
                    {
                        "Name": "x",
                        "Version": "1",
                        "License": "MIT",
                        "LicenseFile": "",
                        "LicenseText": "",
                    }
                ]
            )
        )

        import fastapi_rtk.apis.license as lic_mod

        # Set add_api=True before reload so the if-branch is taken.
        original_add_api = lic_mod.LicenseSession.add_api
        try:
            # Pre-populate add_api so the module-level conditional triggers
            # the ModelRestApi branch on reload.
            monkeypatch.setattr(lic_mod.LicenseSession, "add_api", True)
            reloaded = importlib.reload(lic_mod)
            assert reloaded.LicenseApi.resource_name == "licenses"
            assert "download" in reloaded.LicenseApi.routes
        finally:
            lic_mod.LicenseSession.add_api = original_add_api
            importlib.reload(lic_mod)
