"""Tier 13 - tests for fastapi_rtk.apis.info.InfoApi."""

from types import SimpleNamespace

from fastapi_rtk.apis.info import InfoApi


class TestInfoApiAttributes:
    def test_resource_name(self):
        assert InfoApi.resource_name == "info"

    def test_security_level_apis(self):
        for name in (
            "PermissionsApi",
            "RolesApi",
            "UsersApi",
            "ViewsMenusApi",
            "PermissionViewApi",
        ):
            assert name in InfoApi.security_level_apis

    def test_excluded_apis(self):
        assert "InfoApi" in InfoApi.excluded_apis
        assert "AuthApi" in InfoApi.excluded_apis


class TestGetInfoNoToolkit:
    def test_returns_empty_when_no_toolkit(self):
        api = InfoApi()
        api.toolkit = None
        assert api.get_info() == []


class TestGetInfo:
    def _make_api_obj(self, cls_name, has_datamodel=True, resource_name=None):
        cls = type(cls_name, (), {})
        obj = cls()
        obj.resource_name = resource_name or cls_name.lower()
        if has_datamodel:
            obj.datamodel = SimpleNamespace()
        return obj

    def test_lists_apis_excluding_self(self):
        api = InfoApi()
        widgets = self._make_api_obj("WidgetsApi", resource_name="widgets")
        info_obj = self._make_api_obj("InfoApi", resource_name="info")
        auth_obj = self._make_api_obj("AuthApi", resource_name="auth")
        api.toolkit = SimpleNamespace(apis=[widgets, info_obj, auth_obj])

        result = api.get_info()
        names = [r["name"] for r in result]
        assert "Widgets" in names
        # InfoApi + AuthApi excluded
        assert "Info" not in names
        assert "Auth" not in names

    def test_security_level_marked(self):
        api = InfoApi()
        users = self._make_api_obj("UsersApi", resource_name="users")
        api.toolkit = SimpleNamespace(apis=[users])

        result = api.get_info()
        assert result[0]["level"] == "security"

    def test_default_level(self):
        api = InfoApi()
        widgets = self._make_api_obj("WidgetsApi", resource_name="widgets")
        api.toolkit = SimpleNamespace(apis=[widgets])

        result = api.get_info()
        assert result[0]["level"] == "default"

    def test_table_type_when_datamodel_present(self):
        api = InfoApi()
        widgets = self._make_api_obj(
            "WidgetsApi", has_datamodel=True, resource_name="widgets"
        )
        api.toolkit = SimpleNamespace(apis=[widgets])

        result = api.get_info()
        assert result[0]["type"] == "table"
        assert result[0]["icon"] == "Table"

    def test_default_type_when_no_datamodel(self):
        api = InfoApi()
        plain = self._make_api_obj(
            "PlainApi", has_datamodel=False, resource_name="plain"
        )
        api.toolkit = SimpleNamespace(apis=[plain])

        result = api.get_info()
        assert result[0]["type"] == "default"
        assert result[0]["icon"] == ""

    def test_path_uses_resource_name(self):
        api = InfoApi()
        widgets = self._make_api_obj("WidgetsApi", resource_name="custom_path")
        api.toolkit = SimpleNamespace(apis=[widgets])

        result = api.get_info()
        assert result[0]["path"] == "custom_path"

    def test_permission_name_uses_class_name(self):
        api = InfoApi()
        widgets = self._make_api_obj("WidgetsApi", resource_name="widgets")
        api.toolkit = SimpleNamespace(apis=[widgets])

        result = api.get_info()
        assert result[0]["permission_name"] == "WidgetsApi"

    def test_caches_result(self):
        api = InfoApi()
        widgets = self._make_api_obj("WidgetsApi", resource_name="widgets")
        api.toolkit = SimpleNamespace(apis=[widgets])

        first = api.get_info()
        # Mutate toolkit; cached value returned regardless
        api.toolkit.apis = []
        second = api.get_info()
        assert first is second
        assert len(second) == 1


class TestRouteRegistration:
    def test_route_registered_at_root(self):
        api = InfoApi()
        paths = [rest_data["path"] for _, rest_data, _, _ in api.routes_to_register]
        assert "/" in paths
