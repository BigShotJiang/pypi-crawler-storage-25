import pytest

from fastapi_rtk.bases.file_manager import AbstractImageManager
from fastapi_rtk.file_managers.file_manager import FileManager
from fastapi_rtk.file_managers.image_manager import ImageManager


class TestImageManagerInheritance:
    def test_inherits_file_manager(self):
        assert issubclass(ImageManager, FileManager)

    def test_inherits_abstract_image_manager(self):
        assert issubclass(ImageManager, AbstractImageManager)


class TestPostInit:
    def test_raises_when_img_upload_folder_missing(self, config_setter):
        config_setter("IMG_UPLOAD_FOLDER", None)
        with pytest.raises(ValueError, match="IMG_UPLOAD_FOLDER"):
            ImageManager()

    def test_uses_img_upload_folder(self, tmp_path, config_setter):
        config_setter("IMG_UPLOAD_FOLDER", str(tmp_path))
        m = ImageManager()
        assert m.base_path == str(tmp_path)

    def test_default_allowed_extensions_set(self, tmp_path, config_setter):
        config_setter("IMG_UPLOAD_FOLDER", str(tmp_path))
        m = ImageManager()
        assert "png" in m.allowed_extensions
        assert "jpg" in m.allowed_extensions


class TestSaveRoundtrip:
    def test_save_and_get(self, tmp_path, config_setter):
        config_setter("IMG_UPLOAD_FOLDER", str(tmp_path))
        m = ImageManager()
        m.save_content_to_file(b"\x89PNGdata", "logo.png")
        assert m.get_file("logo.png") == b"\x89PNGdata"
