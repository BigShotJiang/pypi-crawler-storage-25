import io
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest
from fastapi import UploadFile

from fastapi_rtk.file_managers.s3_file_manager import S3FileManager


def _make_fm(**overrides):
    defaults = dict(
        base_path="s3://my-bucket/data",
        bucket_name="my-bucket",
        bucket_subfolder=None,
        access_key="AKIA",
        secret_key="SECRET",
        boto3_client=MagicMock(),
    )
    defaults.update(overrides)
    return S3FileManager(**defaults)


class TestInit:
    def test_requires_bucket_name(self):
        with pytest.raises(ValueError, match="Bucket name"):
            S3FileManager(
                base_path="s3://x/y",
                access_key="k",
                secret_key="s",
                boto3_client=MagicMock(),
            )

    def test_requires_access_key(self):
        with pytest.raises(ValueError, match="Access key"):
            S3FileManager(
                base_path="s3://x/y",
                bucket_name="b",
                secret_key="s",
                boto3_client=MagicMock(),
            )

    def test_requires_secret_key(self):
        with pytest.raises(ValueError, match="Secret key"):
            S3FileManager(
                base_path="s3://x/y",
                bucket_name="b",
                access_key="k",
                boto3_client=MagicMock(),
            )

    def test_default_boto3_client_created_when_not_provided(self):
        with patch("boto3.client") as mock_client:
            S3FileManager(
                base_path="s3://x/y",
                bucket_name="b",
                access_key="k",
                secret_key="s",
            )
        mock_client.assert_called_once()
        args, kwargs = mock_client.call_args
        assert args == ("s3",)
        assert kwargs["aws_access_key_id"] == "k"
        assert kwargs["aws_secret_access_key"] == "s"

    def test_insecure_endpoint_url_disables_ssl(self):
        with patch("boto3.client") as mock_client:
            S3FileManager(
                base_path="s3://x/y",
                bucket_name="b",
                access_key="k",
                secret_key="s",
                insecure_endpoint_url="http://minio:9000",
            )
        kwargs = mock_client.call_args.kwargs
        assert kwargs["endpoint_url"] == "http://minio:9000"
        assert kwargs["use_ssl"] is False
        assert kwargs["verify"] is False

    def test_explicit_boto3_client_used(self):
        client = MagicMock()
        m = _make_fm(boto3_client=client)
        assert m.boto3_client is client

    def test_open_params_get_transport_client(self):
        client = MagicMock()
        m = _make_fm(boto3_client=client)
        assert m.open_params["transport_params"]["client"] is client

    def test_smart_open_import_failure_raises_import_error(self):
        """When smart_open missing, S3FileManager raises ImportError."""
        with patch.dict("sys.modules", {"smart_open": None, "boto3": None}):
            with pytest.raises(ImportError, match="smart_open is required"):
                S3FileManager(
                    base_path="s3://x/y",
                    bucket_name="b",
                    access_key="k",
                    secret_key="s",
                )


class TestGetPath:
    def test_joins_base_and_filename(self):
        m = _make_fm()
        assert m.get_path("a.txt") == "s3://my-bucket/data/a.txt"


class TestReadWrite:
    def test_get_file_reads_via_smart_open(self):
        m = _make_fm()
        fake_file = MagicMock()
        fake_file.read.return_value = b"contents"
        fake_cm = MagicMock(__enter__=lambda s: fake_file, __exit__=lambda *a: None)
        with patch.object(m.smart_open, "open", return_value=fake_cm) as mock_open:
            data = m.get_file("a.txt")
        assert data == b"contents"
        mock_open.assert_called_once()
        path, mode = mock_open.call_args.args
        assert path == "s3://my-bucket/data/a.txt"
        assert mode == "rb"

    def test_save_content_to_file(self):
        m = _make_fm()
        fake_file = MagicMock()
        fake_cm = MagicMock(__enter__=lambda s: fake_file, __exit__=lambda *a: None)
        with patch.object(m.smart_open, "open", return_value=fake_cm) as mock_open:
            m.save_content_to_file(b"data", "y.txt")
        fake_file.write.assert_called_once_with(b"data")
        assert mock_open.call_args.args[1] == "wb"

    def test_save_file_uses_uploadfile(self):
        m = _make_fm()
        fake_file = MagicMock()
        fake_cm = MagicMock(__enter__=lambda s: fake_file, __exit__=lambda *a: None)
        uf = UploadFile(file=io.BytesIO(b"upload"), filename="z.txt", size=6)
        with patch.object(m.smart_open, "open", return_value=fake_cm):
            m.save_file(uf, "z.txt")
        fake_file.write.assert_called_once_with(b"upload")


class TestStreamFile:
    @pytest.mark.asyncio
    async def test_stream_yields_chunks(self):
        m = _make_fm()
        chunks_iter = iter([b"abc", b"def", b""])

        def fake_read(n):
            return next(chunks_iter)

        fake_file = MagicMock()
        fake_file.read.side_effect = fake_read
        fake_cm = MagicMock(__enter__=lambda s: fake_file, __exit__=lambda *a: None)
        with patch.object(m.smart_open, "open", return_value=fake_cm):
            chunks = []
            async for c in m.stream_file("a.txt"):
                chunks.append(c)
        assert chunks == [b"abc", b"def"]


class TestDeleteFile:
    def test_deletes_when_exists(self):
        m = _make_fm()
        fake_file = MagicMock()
        fake_file.read.return_value = b"x"
        fake_cm = MagicMock(__enter__=lambda s: fake_file, __exit__=lambda *a: None)
        with patch.object(m.smart_open, "open", return_value=fake_cm):
            m.delete_file("doomed.txt")
        m.boto3_client.delete_object.assert_called_once_with(
            Bucket="my-bucket", Key="doomed.txt"
        )

    def test_uses_subfolder_in_key(self):
        m = _make_fm(bucket_subfolder="sub")
        fake_file = MagicMock()
        fake_file.read.return_value = b"x"
        fake_cm = MagicMock(__enter__=lambda s: fake_file, __exit__=lambda *a: None)
        with patch.object(m.smart_open, "open", return_value=fake_cm):
            m.delete_file("doomed.txt")
        m.boto3_client.delete_object.assert_called_once_with(
            Bucket="my-bucket", Key="sub/doomed.txt"
        )

    def test_skips_when_not_exists(self):
        m = _make_fm()

        client_error = m.botocore.client.ClientError(
            {"Error": {"Code": m.ERROR_CODE_FILE_NOT_FOUND}}, "GetObject"
        )
        ioerr = IOError("missing")
        ioerr.backend_error = client_error

        with patch.object(m.smart_open, "open", side_effect=ioerr):
            m.delete_file("missing.txt")
        m.boto3_client.delete_object.assert_not_called()


class TestFileExists:
    def test_returns_true_when_readable(self):
        m = _make_fm()
        fake_file = MagicMock()
        fake_file.read.return_value = b"x"
        fake_cm = MagicMock(__enter__=lambda s: fake_file, __exit__=lambda *a: None)
        with patch.object(m.smart_open, "open", return_value=fake_cm):
            assert m.file_exists("a.txt") is True

    def test_returns_false_on_no_such_key(self):
        m = _make_fm()

        client_error = m.botocore.client.ClientError(
            {"Error": {"Code": m.ERROR_CODE_FILE_NOT_FOUND}}, "GetObject"
        )
        ioerr = IOError("missing")
        ioerr.backend_error = client_error

        with patch.object(m.smart_open, "open", side_effect=ioerr):
            assert m.file_exists("missing.txt") is False

    def test_reraises_other_io_errors(self):
        m = _make_fm()
        with patch.object(m.smart_open, "open", side_effect=IOError("boom")):
            with pytest.raises(IOError, match="boom"):
                m.file_exists("any.txt")


class TestGetInstanceWithSubfolder:
    def test_appends_subfolder_to_bucket_subfolder(self):
        m = _make_fm(bucket_subfolder="root")
        sub = m.get_instance_with_subfolder("kid")
        assert sub.bucket_subfolder == "root/kid"
        assert sub.bucket_name == "my-bucket"
        assert sub.boto3_client is m.boto3_client

    def test_sets_bucket_subfolder_when_none(self):
        m = _make_fm(bucket_subfolder=None)
        sub = m.get_instance_with_subfolder("kid")
        assert sub.bucket_subfolder == "kid"
