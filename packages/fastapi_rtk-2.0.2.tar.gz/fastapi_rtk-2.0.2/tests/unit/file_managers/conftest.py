import pytest

from fastapi_rtk.globals import g


@pytest.fixture
def config_setter():
    """Set/restore values in g.config dict."""
    saved = {}
    keys_set = []

    def _set(key, value):
        if key not in saved:
            saved[key] = g.config.get(key, _MISSING)
            keys_set.append(key)
        g.config[key] = value

    yield _set

    for key in keys_set:
        if saved[key] is _MISSING:
            g.config.pop(key, None)
        else:
            g.config[key] = saved[key]


_MISSING = object()
