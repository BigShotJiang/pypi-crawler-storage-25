from unittest.mock import MagicMock

from fastapi_rtk.bases.file_manager import AbstractImageManager
from fastapi_rtk.file_managers.s3_file_manager import S3FileManager
from fastapi_rtk.file_managers.s3_image_manager import S3ImageManager


class TestS3ImageManagerInheritance:
    def test_inherits_s3_file_manager(self):
        assert issubclass(S3ImageManager, S3FileManager)

    def test_inherits_abstract_image_manager(self):
        assert issubclass(S3ImageManager, AbstractImageManager)


class TestSmoke:
    def test_can_instantiate_with_required_args(self):
        m = S3ImageManager(
            base_path="s3://b/img",
            bucket_name="b",
            access_key="k",
            secret_key="s",
            boto3_client=MagicMock(),
        )
        assert m.bucket_name == "b"
        assert m.base_path == "s3://b/img"

    def test_default_image_extensions(self):
        m = S3ImageManager(
            base_path="s3://b/img",
            bucket_name="b",
            access_key="k",
            secret_key="s",
            boto3_client=MagicMock(),
        )
        assert "png" in m.allowed_extensions
        assert "jpg" in m.allowed_extensions
