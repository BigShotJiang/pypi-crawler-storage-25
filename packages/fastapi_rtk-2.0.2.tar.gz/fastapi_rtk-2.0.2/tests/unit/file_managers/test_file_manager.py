import io

import pytest
from fastapi import UploadFile

from fastapi_rtk.file_managers.file_manager import FileManager


@pytest.fixture
def fm(tmp_path, config_setter):
    config_setter("UPLOAD_FOLDER", str(tmp_path))
    return FileManager()


class TestPostInit:
    def test_raises_when_upload_folder_missing(self, config_setter):
        config_setter("UPLOAD_FOLDER", None)
        with pytest.raises(ValueError, match="UPLOAD_FOLDER"):
            FileManager()

    def test_creates_base_path_when_missing(self, tmp_path, config_setter):
        target = tmp_path / "newdir"
        config_setter("UPLOAD_FOLDER", str(target))
        FileManager()
        assert target.is_dir()

    def test_uses_existing_base_path(self, tmp_path, config_setter):
        config_setter("UPLOAD_FOLDER", str(tmp_path))
        m = FileManager()
        assert m.base_path == str(tmp_path)


class TestGetPath:
    def test_joins_base_and_filename(self, fm, tmp_path):
        assert fm.get_path("a.txt") == f"{tmp_path}/a.txt"


class TestSaveAndRead:
    def test_save_content_to_file_writes_bytes(self, fm, tmp_path):
        path = fm.save_content_to_file(b"hello", "x.txt")
        assert (tmp_path / "x.txt").read_bytes() == b"hello"
        assert path.endswith("x.txt")

    def test_get_file_reads_bytes(self, fm):
        fm.save_content_to_file(b"abc", "x.txt")
        assert fm.get_file("x.txt") == b"abc"

    def test_save_file_uses_uploadfile(self, fm, tmp_path):
        uf = UploadFile(file=io.BytesIO(b"world"), filename="y.txt", size=5)
        fm.save_file(uf, "y.txt")
        assert (tmp_path / "y.txt").read_bytes() == b"world"


class TestStreamFile:
    @pytest.mark.asyncio
    async def test_stream_yields_chunks(self, fm):
        fm.save_content_to_file(b"a" * 20000, "big.txt")
        chunks = []
        async for chunk in fm.stream_file("big.txt"):
            chunks.append(chunk)
        assert b"".join(chunks) == b"a" * 20000
        assert len(chunks) >= 2  # default chunk size 8192


class TestDeleteFile:
    def test_deletes_existing_file(self, fm, tmp_path):
        fm.save_content_to_file(b"x", "delme.txt")
        assert (tmp_path / "delme.txt").exists()
        fm.delete_file("delme.txt")
        assert not (tmp_path / "delme.txt").exists()

    def test_no_error_when_file_missing(self, fm):
        fm.delete_file("ghost.txt")  # no-op


class TestFileExists:
    def test_returns_true_after_save(self, fm):
        fm.save_content_to_file(b"x", "exists.txt")
        assert fm.file_exists("exists.txt") is True

    def test_returns_false_when_missing(self, fm):
        assert fm.file_exists("nope.txt") is False


class TestSecureFilename:
    def test_unsafe_chars_stripped(self, fm):
        secured, path = fm.generate_secure_filename("../etc/passwd")
        assert ".." not in secured
        assert "/" not in secured

    def test_returns_tuple_of_secured_and_path(self, fm, tmp_path):
        secured, path = fm.generate_secure_filename("hello world.txt")
        assert "hello_world" in secured
        assert path.startswith(str(tmp_path))


class TestSubfolder:
    def test_subfolder_instance(self, fm, tmp_path, config_setter):
        sub = fm.get_instance_with_subfolder("foo")
        assert sub.base_path == f"{tmp_path}/foo"
        assert (tmp_path / "foo").is_dir()
