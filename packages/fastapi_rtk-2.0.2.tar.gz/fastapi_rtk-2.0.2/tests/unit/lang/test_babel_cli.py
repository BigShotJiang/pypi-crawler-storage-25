import tempfile
from types import SimpleNamespace
from unittest.mock import patch

import fastapi_babel

from fastapi_rtk.lang.babel.cli import FastAPIRTKBabelCLI
from fastapi_rtk.lang.babel.config import FastAPIRTKBabelConfigs


def _make_cli():
    with tempfile.TemporaryDirectory() as d:
        cfg = FastAPIRTKBabelConfigs(
            ROOT_DIR=d,
            BABEL_DEFAULT_LOCALE="en",
            BABEL_TRANSLATION_DIRECTORY="trans",
        )
    babel = SimpleNamespace(config=cfg)
    cli = FastAPIRTKBabelCLI.__new__(FastAPIRTKBabelCLI)
    cli.babel = babel
    return cli, cfg


class TestFastAPIRTKBabelCLI:
    def test_inherits_babel_cli(self):
        assert issubclass(FastAPIRTKBabelCLI, fastapi_babel.BabelCli)

    def test_extract_invokes_pybabel_with_correct_args(self):
        cli, cfg = _make_cli()
        with patch("fastapi_rtk.lang.babel.cli.run") as mock_run:
            cli.extract("/some/path")
        called_args = mock_run.call_args[0][0]
        assert called_args[0] == cli.__module_name__
        assert called_args[1] == "extract"
        assert "-F" in called_args
        assert cfg.BABEL_CONFIG_FILE in called_args
        assert "-o" in called_args
        assert cfg.BABEL_MESSAGE_POT_FILE in called_args
        assert called_args[-1] == "/some/path"

    def test_extract_with_keywords(self):
        cli, _ = _make_cli()
        with patch("fastapi_rtk.lang.babel.cli.run") as mock_run:
            cli.extract("/p", keywords="lazy_text _:1")
        args = mock_run.call_args[0][0]
        assert "-k" in args
        idx = args.index("-k")
        assert args[idx + 1] == "lazy_text _:1"

    def test_extract_without_keywords_omits_k_flag(self):
        cli, _ = _make_cli()
        with patch("fastapi_rtk.lang.babel.cli.run") as mock_run:
            cli.extract("/p")
        args = mock_run.call_args[0][0]
        assert "-k" not in args

    def test_extract_watch_dir_is_last(self):
        cli, _ = _make_cli()
        with patch("fastapi_rtk.lang.babel.cli.run") as mock_run:
            cli.extract("/p", keywords="kw")
        args = mock_run.call_args[0][0]
        assert args[-1] == "/p"
