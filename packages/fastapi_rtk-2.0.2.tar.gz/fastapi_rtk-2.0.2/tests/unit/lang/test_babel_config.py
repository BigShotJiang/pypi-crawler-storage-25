import os
import tempfile

import fastapi_babel

from fastapi_rtk.lang.babel.config import FastAPIRTKBabelConfigs


class TestFastAPIRTKBabelConfigs:
    def test_inherits_babel_configs(self):
        assert issubclass(FastAPIRTKBabelConfigs, fastapi_babel.BabelConfigs)

    def test_root_dir_neutralizes_parent_parent_call(self):
        """Parent BabelConfigs.__post_init__ does ROOT_DIR=ROOT_DIR.parent.
        Subclass joins 'dummy' first so net result keeps original ROOT_DIR.
        """
        with tempfile.TemporaryDirectory() as d:
            cfg = FastAPIRTKBabelConfigs(
                ROOT_DIR=d,
                BABEL_DEFAULT_LOCALE="en",
                BABEL_TRANSLATION_DIRECTORY="trans",
            )
            assert str(cfg.ROOT_DIR) == d

    def test_translation_directory_under_root(self):
        with tempfile.TemporaryDirectory() as d:
            cfg = FastAPIRTKBabelConfigs(
                ROOT_DIR=d,
                BABEL_DEFAULT_LOCALE="en",
                BABEL_TRANSLATION_DIRECTORY="trans",
            )
            assert cfg.BABEL_TRANSLATION_DIRECTORY == os.path.join(d, "trans")

    def test_config_file_under_root(self):
        with tempfile.TemporaryDirectory() as d:
            cfg = FastAPIRTKBabelConfigs(
                ROOT_DIR=d,
                BABEL_DEFAULT_LOCALE="en",
                BABEL_TRANSLATION_DIRECTORY="trans",
            )
            assert cfg.BABEL_CONFIG_FILE == os.path.join(d, "babel.cfg")

    def test_message_pot_file_under_root(self):
        with tempfile.TemporaryDirectory() as d:
            cfg = FastAPIRTKBabelConfigs(
                ROOT_DIR=d,
                BABEL_DEFAULT_LOCALE="en",
                BABEL_TRANSLATION_DIRECTORY="trans",
            )
            assert cfg.BABEL_MESSAGE_POT_FILE == os.path.join(d, "messages.pot")
