import sys
from types import SimpleNamespace

import pytest

from fastapi_rtk.globals import g
from fastapi_rtk.lang.lazy_text import _, lazy_text, translate

lazy_text_mod = sys.modules["fastapi_rtk.lang.lazy_text"]


class TestLazyText:
    def test_no_format_returns_message(self):
        lt = lazy_text("Hello")
        assert lt() == "Hello"

    def test_repr_returns_translated(self):
        lt = lazy_text("Hello")
        assert repr(lt) == "Hello"

    def test_underscore_classmethod_returns_lazy_text(self):
        result = lazy_text._("foo")
        assert isinstance(result, lazy_text)
        assert result() == "foo"

    def test_format_positional_args(self):
        lt = lazy_text("Hi {0}", "Bob")
        assert lt() == "Hi Bob"

    def test_format_keyword_args(self):
        lt = lazy_text("Hi {name}", name="Eve")
        assert lt() == "Hi Eve"

    def test_no_cache_each_call_evaluates(self, monkeypatch):
        calls = []

        def fake_translate(message, *args, **kwargs):
            calls.append(message)
            return message

        monkeypatch.setattr(lazy_text_mod, "translate", fake_translate)
        lt = lazy_text("X")
        lt()
        lt()
        assert len(calls) == 2


class TestTranslate:
    def test_returns_message_when_no_context(self):
        assert translate("untranslated message") == "untranslated message"

    def test_format_positional(self):
        assert translate("Hi {0}", "Bob") == "Hi Bob"

    def test_format_keyword(self):
        assert translate("Hi {name}", name="Eve") == "Hi Eve"

    def test_ensure_context_raises_lookup_error(self):
        with pytest.raises(LookupError):
            translate("msg", ensure_context=True)

    def test_alias_underscore_equals_translate(self):
        assert _ is translate


@pytest.fixture
def stub_translations():
    """Set/restore g.config['TRANSLATIONS'] and g.request via _defaults."""
    sentinel = object()
    saved = {
        "TRANSLATIONS": g.config.pop("TRANSLATIONS", sentinel),
    }
    yield
    if saved["TRANSLATIONS"] is sentinel:
        g.config.pop("TRANSLATIONS", None)
    else:
        g.config["TRANSLATIONS"] = saved["TRANSLATIONS"]


@pytest.fixture
def stub_request():
    sentinel = object()
    orig_default = g._defaults.get("request", sentinel)
    orig_boot = g._bootstrap_values.get("request", sentinel)

    def _set(req):
        g._defaults["request"] = req
        g._bootstrap_values["request"] = req

    yield _set

    if orig_default is sentinel:
        g._defaults.pop("request", None)
    else:
        g._defaults["request"] = orig_default
    if orig_boot is sentinel:
        g._bootstrap_values.pop("request", None)
    else:
        g._bootstrap_values["request"] = orig_boot


@pytest.fixture
def fake_babel(monkeypatch):
    """Make fastapi_babel._ return the message unchanged so settings fallback runs."""
    import fastapi_babel

    monkeypatch.setattr(fastapi_babel, "_", lambda msg: msg)


class TestUseSettingsTranslations:
    def test_no_translations_returns_message(self, stub_translations, fake_babel):
        assert translate("hi") == "hi"

    def test_setting_translations_used_when_request_present(
        self, stub_translations, stub_request, fake_babel
    ):
        g.config["TRANSLATIONS"] = {"de": {"hello": "hallo"}}
        stub_request(
            SimpleNamespace(state=SimpleNamespace(babel=SimpleNamespace(locale="de")))
        )
        assert translate("hello") == "hallo"

    def test_setting_translations_swallows_exception(
        self, stub_translations, stub_request, fake_babel
    ):
        g.config["TRANSLATIONS"] = {"de": {"hello": "hallo"}}
        stub_request(SimpleNamespace(state=SimpleNamespace()))
        assert translate("hello") == "hello"

    def test_locale_not_in_translations_returns_message(
        self, stub_translations, stub_request, fake_babel
    ):
        g.config["TRANSLATIONS"] = {"de": {"hello": "hallo"}}
        stub_request(
            SimpleNamespace(state=SimpleNamespace(babel=SimpleNamespace(locale="fr")))
        )
        assert translate("hello") == "hello"

    def test_use_settings_translations_disabled(
        self, stub_translations, stub_request, fake_babel
    ):
        g.config["TRANSLATIONS"] = {"de": {"hello": "hallo"}}
        stub_request(
            SimpleNamespace(state=SimpleNamespace(babel=SimpleNamespace(locale="de")))
        )
        assert translate("hello", use_settings_translations=False) == "hello"


class TestExports:
    def test_dunder_all(self):
        for name in lazy_text_mod.__all__:
            assert hasattr(lazy_text_mod, name)


@pytest.fixture
def stub_current_app():
    sentinel = object()
    orig_default = g._defaults.get("current_app", sentinel)
    orig_boot = g._bootstrap_values.get("current_app", sentinel)

    def _set(app):
        g._defaults["current_app"] = app
        g._bootstrap_values["current_app"] = app

    yield _set

    if orig_default is sentinel:
        g._defaults.pop("current_app", None)
    else:
        g._defaults["current_app"] = orig_default
    if orig_boot is sentinel:
        g._bootstrap_values.pop("current_app", None)
    else:
        g._bootstrap_values["current_app"] = orig_boot


class TestTranslateLogging:
    def test_warns_when_app_started(self, stub_current_app, caplog):
        """LookupError path -> if current_app.started, log warning. Covers lines 84-89."""
        # Reset module-level logger so it re-initializes
        lazy_text_mod.logger = None
        stub_current_app(SimpleNamespace(started=True))
        with caplog.at_level("WARNING", logger="DT_FASTAPI.lang"):
            result = translate("untranslated")
        assert result == "untranslated"
        assert any("untranslated" in rec.message for rec in caplog.records)

    def test_no_warn_when_app_not_started(self, stub_current_app, caplog):
        lazy_text_mod.logger = None
        stub_current_app(SimpleNamespace(started=False))
        with caplog.at_level("WARNING", logger="DT_FASTAPI.lang"):
            translate("untranslated2")
        assert not any("untranslated2" in rec.message for rec in caplog.records)

    def test_logger_reused_after_first_init(self, stub_current_app, caplog):
        lazy_text_mod.logger = None
        stub_current_app(SimpleNamespace(started=True))
        translate("first")
        first_logger = lazy_text_mod.logger
        translate("second")
        assert lazy_text_mod.logger is first_logger
