import logging

import pytest

from fastapi_rtk import const


class TestTableNames:
    def test_user_tables(self):
        assert const.USER_TABLE == "ab_user"
        assert const.USER_SEQUENCE == "ab_user_id_seq"

    def test_role_tables(self):
        assert const.ROLE_TABLE == "ab_role"
        assert const.ROLE_SEQUENCE == "ab_role_id_seq"

    def test_permission_tables(self):
        assert const.PERMISSION_TABLE == "ab_permission"
        assert const.API_TABLE == "ab_view_menu"
        assert const.PERMISSION_API_TABLE == "ab_permission_view"

    def test_assoc_tables(self):
        assert const.ASSOC_PERMISSION_API_ROLE_TABLE == "ab_permission_view_role"
        assert const.ASSOC_USER_ROLE_TABLE == "ab_user_role"

    def test_oauth_and_token_tables(self):
        assert const.OAUTH_TABLE == "ab_oauth_account"
        assert const.ACCESSTOKEN_TABLE == "ab_accesstoken"


class TestFastapiRtkTables:
    def test_includes_all_managed_tables(self):
        expected = {
            const.USER_TABLE,
            const.ROLE_TABLE,
            const.PERMISSION_TABLE,
            const.API_TABLE,
            const.PERMISSION_API_TABLE,
            const.ASSOC_PERMISSION_API_ROLE_TABLE,
            const.ASSOC_USER_ROLE_TABLE,
            const.OAUTH_TABLE,
            const.ACCESSTOKEN_TABLE,
        }
        assert set(const.FASTAPI_RTK_TABLES) == expected

    def test_no_duplicates(self):
        assert len(const.FASTAPI_RTK_TABLES) == len(set(const.FASTAPI_RTK_TABLES))


class TestDefaults:
    def test_permission_prefix(self):
        assert const.PERMISSION_PREFIX == "can_"

    def test_default_roles(self):
        assert const.DEFAULT_ADMIN_ROLE == "Admin"
        assert const.DEFAULT_PUBLIC_ROLE == "Public"

    def test_default_page_sizes(self):
        assert const.DEFAULT_API_PAGE_SIZE == 25
        assert const.DEFAULT_API_MAX_PAGE_SIZE == 25

    def test_default_token_url(self):
        assert const.DEFAULT_TOKEN_URL.startswith("/")
        assert "auth" in const.DEFAULT_TOKEN_URL

    def test_default_cookie_name(self):
        assert const.DEFAULT_COOKIE_NAME == "dataTactics"

    def test_default_basedir_paths_consistent(self):
        assert const.DEFAULT_STATIC_FOLDER.startswith(const.DEFAULT_BASEDIR + "/")
        assert const.DEFAULT_TEMPLATE_FOLDER.startswith(const.DEFAULT_BASEDIR + "/")
        assert const.DEFAULT_LICENSE_FOLDER.startswith(const.DEFAULT_BASEDIR + "/")
        assert const.DEFAULT_LANG_FOLDER.startswith(const.DEFAULT_BASEDIR + "/")
        assert const.DEFAULT_PROFILER_FOLDER.startswith(const.DEFAULT_STATIC_FOLDER + "/")

    def test_default_languages(self):
        assert "en" in const.DEFAULT_LANGUAGES
        assert "de" in const.DEFAULT_LANGUAGES

    def test_default_metadata_key(self):
        assert const.DEFAULT_METADATA_KEY == "default"


class TestSecwebDefaults:
    def test_secweb_options_present(self):
        assert "Option" in const.DEFAULT_SECWEB_PARAMS
        assert "csp" in const.DEFAULT_SECWEB_PARAMS["Option"]
        assert "hsts" in const.DEFAULT_SECWEB_PARAMS["Option"]

    def test_csp_unsafe_inline_stripped(self):
        assert "'unsafe-inline'" not in const.DEFAULT_SECWEB_PARAMS["Option"]["csp"][
            "style-src"
        ]

    def test_hsts_max_age_overridden(self):
        assert const.DEFAULT_SECWEB_PARAMS["Option"]["hsts"]["max-age"] == 63072000

    def test_require_trusted_types_removed(self):
        assert (
            "require-trusted-types-for"
            not in const.DEFAULT_SECWEB_PARAMS["Option"]["csp"]
        )

    def test_nonces_enabled(self):
        assert const.DEFAULT_SECWEB_PARAMS["script_nonce"] is True
        assert const.DEFAULT_SECWEB_PARAMS["style_nonce"] is True


class TestLangFolders:
    def test_internal_lang_folder_resolves(self):
        import os

        assert os.path.isdir(const.INTERNAL_LANG_FOLDER)

    def test_internal_babel_folder_under_lang(self):
        assert const.INTERNAL_BABEL_FOLDER.startswith(const.INTERNAL_LANG_FOLDER)
        assert const.INTERNAL_BABEL_FOLDER.endswith("babel")


class TestCookieAndBearerConfig:
    def test_cookie_prefix_and_keys(self):
        assert const.COOKIE_PREFIX == "COOKIE_"
        for key in const.COOKIE_CONFIG:
            assert key.startswith(const.COOKIE_PREFIX)

    def test_bearer_prefix_and_keys(self):
        assert const.BEARER_PREFIX == "BEARER_"
        for key in const.BEARER_CONFIG:
            assert key.startswith(const.BEARER_PREFIX)
        for key in const.BEARER_STRATEGY_CONFIG:
            assert key.startswith(const.BEARER_PREFIX)

    def test_auth_role_prefix_and_keys(self):
        assert const.AUTH_ROLE_PREFIX == "AUTH_"
        for key in const.AUTH_ROLE_CONFIG:
            assert key.startswith(const.AUTH_ROLE_PREFIX)


class TestErrorCodeEnum:
    def test_is_str_enum(self):
        assert issubclass(const.ErrorCode, str)
        assert issubclass(const.ErrorCode, __import__("enum").Enum)

    @pytest.mark.parametrize(
        "name",
        [
            "GET_USER_MISSING_TOKEN_OR_INACTIVE_USER",
            "GET_USER_NO_ROLES",
            "PERMISSION_DENIED",
            "FEATURE_NOT_IMPLEMENTED",
            "PAGE_NOT_FOUND",
            "ITEM_NOT_FOUND",
            "HANDLER_NOT_FOUND",
            "FILE_NOT_FOUND",
            "IMAGE_NOT_FOUND",
        ],
    )
    def test_each_member_value_matches_name(self, name):
        member = getattr(const.ErrorCode, name)
        assert member.value == name


class TestAuthTypeEnum:
    def test_is_str_enum(self):
        assert issubclass(const.AuthType, str)

    def test_ldap_member(self):
        assert const.AuthType.LDAP.value == "ldap"


class TestLogger:
    def test_logger_name(self):
        assert const.logger.name == "DT_FASTAPI"

    def test_logger_level(self):
        assert const.logger.level == logging.INFO

    def test_logger_is_logger_instance(self):
        assert isinstance(const.logger, logging.Logger)
