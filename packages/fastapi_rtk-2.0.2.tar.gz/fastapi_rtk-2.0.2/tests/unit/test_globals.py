import asyncio
from contextvars import copy_context

import pytest

from fastapi_rtk.config import Config
from fastapi_rtk.globals import (
    Globals,
    background_tasks,
    current_app,
    current_user,
    g,
    request,
)


class TestGlobalsInit:
    def test_fresh_globals_state(self):
        h = Globals()
        assert h._vars == {}
        assert h._defaults == {}
        assert h._bootstrap_values == {}
        assert h._frozen is False


class TestSetGetBeforeFreeze:
    def test_set_writes_bootstrap(self):
        h = Globals()
        h.foo = 1
        assert h._bootstrap_values["foo"] == 1

    def test_get_reads_bootstrap(self):
        h = Globals()
        h.foo = "bar"
        assert h.foo == "bar"

    def test_get_returns_default_when_unset(self):
        h = Globals()
        h.set_default("foo", "default")
        assert h.foo == "default"


class TestSetDefault:
    def test_simple_default(self):
        h = Globals()
        h.set_default("x", 42)
        assert h.x == 42

    def test_callable_default_evaluated(self):
        h = Globals()
        h.set_default("x", lambda: "lazy")
        assert h.x == "lazy"

    def test_setting_same_default_idempotent(self):
        h = Globals()
        sentinel = object()
        h.set_default("x", sentinel)
        h.set_default("x", sentinel)  # no error

    def test_already_set_var_blocks_default(self):
        h = Globals()
        h.freeze_bootstrap()
        # Now _vars has nothing yet; trigger var creation
        h.foo = 1
        assert "foo" in h._vars
        with pytest.raises(RuntimeError, match="Cannot set default"):
            h.set_default("foo", 99)


class TestFreezeBootstrap:
    def test_freezes_once(self):
        h = Globals()
        h.foo = 1
        h.freeze_bootstrap()
        assert h._frozen is True
        # Idempotent
        h.freeze_bootstrap()

    def test_frozen_values_persist_in_new_context(self):
        h = Globals()
        h.foo = "before-freeze"
        h.freeze_bootstrap()

        ctx = copy_context()
        result = ctx.run(lambda: h.foo)
        assert result == "before-freeze"

    def test_set_after_freeze_uses_contextvar(self):
        h = Globals()
        h.foo = "initial"
        h.freeze_bootstrap()

        async def task1():
            h.foo = "task1"
            await asyncio.sleep(0)
            return h.foo

        async def task2():
            h.foo = "task2"
            await asyncio.sleep(0)
            return h.foo

        async def runner():
            r1, r2 = await asyncio.gather(task1(), task2())
            return r1, r2

        r1, r2 = asyncio.run(runner())
        assert r1 == "task1"
        assert r2 == "task2"


class TestGlobalSingletonState:
    def test_g_has_config(self):
        assert isinstance(g.config, Config)

    def test_g_admin_role_property(self, config_setter):
        config_setter("AUTH_ROLE_ADMIN", "MyAdmin")
        assert g.admin_role == "MyAdmin"

    def test_g_public_role_property(self, config_setter):
        config_setter("AUTH_ROLE_PUBLIC", "MyPublic")
        assert g.public_role == "MyPublic"

    def test_is_migrate_default_false(self):
        assert g.is_migrate is False

    def test_sensitive_data_default(self):
        assert "User" in g.sensitive_data


class TestLocalProxies:
    def test_current_app_proxy_resolves_to_g_current_app(self, global_setter):
        sentinel = object()
        global_setter("current_app", sentinel)
        assert current_app == sentinel

    def test_current_user_proxy(self, global_setter):
        u = object()
        global_setter("user", u)
        assert current_user == u

    def test_request_proxy(self, global_setter):
        r = object()
        global_setter("request", r)
        assert request == r

    def test_background_tasks_proxy(self, global_setter):
        bt = object()
        global_setter("background_tasks", bt)
        assert background_tasks == bt


class TestBasicCallback:
    def test_dispatches_each_config_section(self, config_setter, global_setter):
        from fastapi_rtk.auth.auth import AuthConfigurator
        from fastapi_rtk.globals import basic_callback

        ac = AuthConfigurator()
        global_setter("auth", ac)

        # One key per dispatched bucket so each branch fires
        config_setter("SECRET_KEY", "secret-key-value-32-bytes-long!!")
        config_setter("COOKIE_NAME", "myCookie")
        config_setter("BEARER_TOKEN_URL", "/custom/login")
        config_setter("COOKIE_LIFETIME_SECONDS", 1234)
        config_setter("BEARER_LIFETIME_SECONDS", 5678)
        config_setter("AUTH_ADMIN_ROLE", "Boss")
        config_setter("AUTH_PUBLIC_ROLE", "Guest")

        basic_callback()

        assert ac.secret_key == "secret-key-value-32-bytes-long!!"
        assert ac.cookie_config["cookie_name"] == "myCookie"
        assert ac.bearer_config["tokenUrl"] == "/custom/login"
        assert ac.cookie_strategy_config["lifetime_seconds"] == 1234
        assert ac.bearer_strategy_config["lifetime_seconds"] == 5678
        # admin_role / public_role write into _bootstrap_values; the property
        # itself still resolves through Setting + config, so just verify the
        # bootstrap got written so AUTH_ROLE_CONFIG branch executed.
        assert g._bootstrap_values.get("admin_role") == "Boss"
        assert g._bootstrap_values.get("public_role") == "Guest"
