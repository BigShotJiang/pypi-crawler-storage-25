"""Shared fixtures for tier 10 security/sqla tests.

Uses sqlite-in-memory + StaticPool to share a single connection across
threadpool dispatches. Only `ab_*` tables from Model.metadata are created
to avoid pulling in unrelated tables registered by other test tiers.
"""

import pytest
import sqlalchemy
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from fastapi_rtk.backends.sqla.model import Model


def _ab_tables():
    return [t for n, t in Model.metadata.tables.items() if n.startswith("ab_")]


@pytest.fixture
def engine():
    eng = sqlalchemy.create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    tables = _ab_tables()
    Model.metadata.create_all(eng, tables=tables)
    yield eng
    Model.metadata.drop_all(eng, tables=tables)
    eng.dispose()


@pytest.fixture
def session(engine):
    with Session(engine) as s:
        yield s
