"""Tier 10 - tests for fastapi_rtk.security.sqla.apis class attributes.

Full instantiation of these classes requires the toolkit, g.auth wiring,
fastapi_users routers, and a registered SecurityManager - those flows
are exercised at tier 11/12. This file covers the static contract:
class attrs, datamodels, exclude lists, label_columns, max_page_size,
base_permissions, plus the pre_info side-effect logic on UsersApi which
can be tested with a constructed UsersApi without going through
`__init__`.
"""

from types import SimpleNamespace

import pytest
from pydantic import EmailStr

from fastapi_rtk.security.sqla.apis import (
    AuthApi,
    PermissionsApi,
    PermissionViewApi,
    RolesApi,
    UsersApi,
    ViewsMenusApi,
)
from fastapi_rtk.security.sqla.models import Api, Permission, PermissionApi, Role, User


class TestAuthApiAttributes:
    def test_resource_name(self):
        assert AuthApi.resource_name == "auth"

    def test_description(self):
        assert "authentication" in AuthApi.description.lower()

    def test_datamodel_targets_user(self):
        assert AuthApi.datamodel.obj is User


class TestViewsMenusApiAttributes:
    def test_resource_name(self):
        assert ViewsMenusApi.resource_name == "viewsmenus"

    def test_datamodel_targets_api_model(self):
        assert ViewsMenusApi.datamodel.obj is Api

    def test_max_page_size(self):
        assert ViewsMenusApi.max_page_size == 200

    def test_base_permissions(self):
        assert ViewsMenusApi.base_permissions == ["can_get", "can_info"]


class TestPermissionsApiAttributes:
    def test_resource_name(self):
        assert PermissionsApi.resource_name == "permissions"

    def test_datamodel_targets_permission(self):
        assert PermissionsApi.datamodel.obj is Permission

    def test_max_page_size(self):
        assert PermissionsApi.max_page_size == 200

    def test_base_permissions(self):
        assert PermissionsApi.base_permissions == ["can_get", "can_info"]


class TestPermissionViewApiAttributes:
    def test_resource_name(self):
        assert PermissionViewApi.resource_name == "permissionview"

    def test_datamodel_targets_permission_api(self):
        assert PermissionViewApi.datamodel.obj is PermissionApi

    def test_max_page_size(self):
        assert PermissionViewApi.max_page_size == 200

    def test_base_permissions(self):
        assert PermissionViewApi.base_permissions == ["can_get", "can_info"]


class TestUsersApiAttributes:
    def test_resource_name(self):
        assert UsersApi.resource_name == "users"

    def test_datamodel_targets_user(self):
        assert UsersApi.datamodel.obj is User

    def test_password_excluded_from_lists(self):
        for attr in (
            "list_exclude_columns",
            "show_exclude_columns",
            "search_exclude_columns",
        ):
            cols = getattr(UsersApi, attr)
            assert "password" in cols
            assert "hashed_password" in cols
            assert "oauth_accounts" in cols

    def test_add_excludes_audit_fields(self):
        for c in ("active", "last_login", "login_count", "fail_login_count",
                  "created_on", "changed_on", "oauth_accounts"):
            assert c in UsersApi.add_exclude_columns

    def test_edit_excludes_username_and_audit(self):
        assert "username" in UsersApi.edit_exclude_columns
        assert "last_login" in UsersApi.edit_exclude_columns

    def test_label_columns(self):
        # `label_columns` is a `lazy()` descriptor returning a fresh dict per
        # instance; on the class itself the descriptor object is exposed.
        api = object.__new__(UsersApi)
        assert api.label_columns == {"password": "Password"}


class TestUsersApiPreInfo:
    def test_password_marked_optional(self):
        # Build an info-like object: edit_columns is a list of column descriptors
        # that have name + required attrs.
        col_pw = SimpleNamespace(name="password", required=True)
        col_other = SimpleNamespace(name="email", required=True)
        info = SimpleNamespace(edit_columns=[col_pw, col_other])

        # Bypass __init__ - we only need an instance to bind self
        api = object.__new__(UsersApi)
        api.pre_info(info, [], session=None)

        assert col_pw.required is False
        # Other columns untouched.
        assert col_other.required is True


class TestRolesApiAttributes:
    def test_resource_name(self):
        assert RolesApi.resource_name == "roles"

    def test_datamodel_targets_role(self):
        assert RolesApi.datamodel.obj is Role

    def test_max_page_size(self):
        assert RolesApi.max_page_size == 200

    def test_extra_fetch_columns(self):
        assert RolesApi.extra_list_fetch_columns == ["users.roles"]
        assert RolesApi.extra_show_fetch_columns == ["users.roles"]


class TestAuthApiSchemas:
    def test_get_user_schema_lazy(self):
        # `get_user_schema` is a `lazy(...)` descriptor on the class - resolving
        # it should yield a Pydantic model class.
        api = object.__new__(AuthApi)
        schema = api.get_user_schema
        assert schema.__name__.startswith("User") or schema.__name__.endswith("Get")

    def test_update_user_schema_lazy(self):
        api = object.__new__(AuthApi)
        schema = api.update_user_schema
        assert schema is not None
