from types import SimpleNamespace

import pytest

from fastapi_rtk.const import (
    API_TABLE,
    ASSOC_PERMISSION_API_ROLE_TABLE,
    ASSOC_USER_ROLE_TABLE,
    OAUTH_TABLE,
    PERMISSION_API_TABLE,
    PERMISSION_TABLE,
    ROLE_TABLE,
    USER_TABLE,
)
from fastapi_rtk.security.sqla.models import (
    Api,
    OAuthAccount,
    Permission,
    PermissionApi,
    Role,
    User,
    assoc_permission_api_role,
    assoc_user_role,
)


class TestTableNames:
    def test_user_table(self):
        assert User.__tablename__ == USER_TABLE

    def test_role_table(self):
        assert Role.__tablename__ == ROLE_TABLE

    def test_permission_table(self):
        assert Permission.__tablename__ == PERMISSION_TABLE

    def test_api_table(self):
        assert Api.__tablename__ == API_TABLE

    def test_permission_api_table(self):
        assert PermissionApi.__tablename__ == PERMISSION_API_TABLE

    def test_oauth_table(self):
        assert OAuthAccount.__tablename__ == OAUTH_TABLE

    def test_assoc_user_role_table(self):
        assert assoc_user_role.name == ASSOC_USER_ROLE_TABLE

    def test_assoc_permission_api_role_table(self):
        assert assoc_permission_api_role.name == ASSOC_PERMISSION_API_ROLE_TABLE


class TestRoleRepr:
    def test_repr_returns_name(self):
        r = Role(name="Admin")
        assert repr(r) == "Admin"


class TestPermissionRepr:
    def test_repr_returns_name(self):
        p = Permission(name="can_get")
        assert repr(p) == "can_get"


class TestApiEqAndRepr:
    def test_repr_returns_name(self):
        a = Api(name="UsersApi")
        assert repr(a) == "UsersApi"

    def test_eq_same_name(self):
        a1 = Api(name="UsersApi")
        a2 = Api(name="UsersApi")
        assert a1 == a2

    def test_eq_different_name(self):
        a1 = Api(name="UsersApi")
        a2 = Api(name="RolesApi")
        assert a1 != a2

    def test_eq_other_type_returns_false(self):
        a1 = Api(name="UsersApi")
        assert (a1 == "UsersApi") is False

    def test_neq_different_name(self):
        a1 = Api(name="UsersApi")
        a2 = Api(name="RolesApi")
        assert a1.__neq__(a2) is True

    def test_neq_same_name(self):
        a1 = Api(name="UsersApi")
        a2 = Api(name="UsersApi")
        assert a1.__neq__(a2) is False


class TestPermissionApiRepr:
    def test_repr_combines_perm_and_api(self):
        p = Permission(name="can_get")
        a = Api(name="UsersApi")
        pa = PermissionApi(permission=p, api=a)
        assert "can_get" in repr(pa)
        assert "UsersApi" in repr(pa)


class TestUserInit:
    def test_username_defaults_to_email(self):
        u = User(email="x@example.com", password="pw")
        assert u.username == "x@example.com"

    def test_username_explicit_kept(self):
        u = User(email="x@example.com", username="alice", password="pw")
        assert u.username == "alice"


class TestUserHashedPassword:
    def test_get(self):
        u = User(email="x@y.z", password="hash1")
        assert u.hashed_password == "hash1"

    def test_set(self):
        u = User(email="x@y.z", password="hash1")
        u.hashed_password = "hash2"
        assert u.password == "hash2"


class TestUserFullName:
    def test_full_name(self):
        u = User(email="x@y.z", password="pw", first_name="John", last_name="Doe")
        assert u.full_name == "John Doe"


class TestUserActiveFlags:
    def test_is_active_true(self):
        u = User(email="x@y.z", password="pw", active=True)
        assert u.is_active is True

    def test_is_active_false(self):
        u = User(email="x@y.z", password="pw", active=False)
        assert u.is_active is False

    def test_is_authenticated_mirrors_active(self):
        u = User(email="x@y.z", password="pw", active=True)
        assert u.is_authenticated is True

    def test_is_anonymous_always_false(self):
        u = User(email="x@y.z", password="pw")
        assert u.is_anonymous is False


class TestUserVerified:
    def test_is_verified_default_false(self):
        u = User(email="x@y.z", password="pw")
        assert u.is_verified is False

    def test_is_verified_setter_no_attr_silent(self):
        u = User(email="x@y.z", password="pw")
        u.is_verified = True  # no-op since no `verified` attr
        assert u.is_verified is False

    def test_is_verified_setter_sets_when_attr_present(self):
        u = User(email="x@y.z", password="pw")
        u.verified = False
        u.is_verified = True
        assert u.verified is True


class TestUserIsSuperuser:
    def test_admin_role_match(self, global_setter, config_setter):
        config_setter("AUTH_ROLE_ADMIN", "Admin")
        u = User(email="x@y.z", password="pw")
        u.roles = [Role(name="Admin")]
        assert u.is_superuser is True

    def test_no_admin_role(self, config_setter):
        config_setter("AUTH_ROLE_ADMIN", "Admin")
        u = User(email="x@y.z", password="pw")
        u.roles = [Role(name="Viewer")]
        assert u.is_superuser is False

    def test_no_roles(self, config_setter):
        config_setter("AUTH_ROLE_ADMIN", "Admin")
        u = User(email="x@y.z", password="pw")
        u.roles = []
        assert u.is_superuser is False


class TestUserGetUserId:
    def test_returns_none_when_no_g_user(self, global_setter):
        global_setter("user", None)
        assert User.get_user_id() is None

    def test_returns_id_when_g_user_set(self, global_setter):
        global_setter("user", SimpleNamespace(id=42))
        assert User.get_user_id() == 42

    def test_swallows_exception(self, global_setter):
        # Force AttributeError by giving an object without `id`
        class NoId:
            @property
            def id(self):
                raise RuntimeError("boom")

        global_setter("user", NoId())
        assert User.get_user_id() is None


class TestUserRepr:
    def test_repr_returns_full_name(self):
        u = User(
            email="x@y.z", password="pw", first_name="Jane", last_name="Doe"
        )
        assert repr(u) == "Jane Doe"


class TestUserPersist:
    def test_create_and_query(self, session):
        u = User(
            username="alice",
            email="alice@example.com",
            password="hashed",
        )
        session.add(u)
        session.commit()
        assert u.id is not None

        fetched = session.query(User).filter_by(username="alice").one()
        assert fetched.email == "alice@example.com"

    def test_unique_email(self, session):
        session.add(User(username="a", email="dup@x.com", password="p"))
        session.commit()
        session.add(User(username="b", email="dup@x.com", password="p"))
        with pytest.raises(Exception):
            session.commit()
        session.rollback()

    def test_role_assignment(self, session):
        role = Role(name="Editor")
        user = User(username="bob", email="bob@x.com", password="p", roles=[role])
        session.add(user)
        session.commit()
        assert role in user.roles
        assert user in role.users


class TestPermissionApiPersist:
    def test_associate(self, session):
        p = Permission(name="can_edit")
        a = Api(name="WidgetApi")
        pa = PermissionApi(permission=p, api=a)
        session.add(pa)
        session.commit()
        assert pa.id is not None
        assert pa.permission.name == "can_edit"
        assert pa.api.name == "WidgetApi"
