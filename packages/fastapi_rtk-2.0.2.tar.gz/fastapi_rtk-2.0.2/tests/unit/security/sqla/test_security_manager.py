import pytest

from fastapi_rtk.security.sqla.models import Api, Permission, PermissionApi, Role
from fastapi_rtk.security.sqla.security_manager import SecurityManager


@pytest.fixture
def sm():
    return SecurityManager(toolkit=None)


@pytest.fixture
def sm_with_roles(sm, config_setter):
    config_setter(
        "ROLES",
        {
            "Editor": [("WidgetApi", "can_edit"), ("UserApi|RoleApi", "can_get|can_info")],
            "Viewer": [("WidgetApi", "can_get")],
        },
    )
    # `builtin_roles` is a `lazy()` descriptor cached on the instance.
    # Bust the cache so each test sees the freshly configured ROLES.
    sm.__dict__.pop("builtin_roles", None)
    return sm


class TestBuiltinRolesAccess:
    def test_has_access_in_builtin_roles_true(self, sm_with_roles):
        assert (
            sm_with_roles.has_access_in_builtin_roles("Editor", "WidgetApi", "can_edit")
            is True
        )

    def test_compound_api_match(self, sm_with_roles):
        assert (
            sm_with_roles.has_access_in_builtin_roles("Editor", "UserApi", "can_get")
            is True
        )

    def test_compound_perm_match(self, sm_with_roles):
        assert (
            sm_with_roles.has_access_in_builtin_roles("Editor", "RoleApi", "can_info")
            is True
        )

    def test_unknown_role_false(self, sm_with_roles):
        assert (
            sm_with_roles.has_access_in_builtin_roles("Ghost", "WidgetApi", "can_get")
            is False
        )

    def test_no_match_false(self, sm_with_roles):
        assert (
            sm_with_roles.has_access_in_builtin_roles(
                "Viewer", "WidgetApi", "can_delete"
            )
            is False
        )

    def test_get_roles_from_builtin(self, sm_with_roles):
        assert sorted(sm_with_roles.get_roles_from_builtin_roles()) == [
            "Editor",
            "Viewer",
        ]

    def test_get_api_permission_tuples_all(self, sm_with_roles):
        tuples = sm_with_roles.get_api_permission_tuples_from_builtin_roles()
        assert ("WidgetApi", "can_edit") in tuples
        assert ("WidgetApi", "can_get") in tuples
        assert ("UserApi|RoleApi", "can_get|can_info") in tuples
        assert len(tuples) == 3

    def test_get_api_permission_tuples_filtered(self, sm_with_roles):
        tuples = sm_with_roles.get_api_permission_tuples_from_builtin_roles("Viewer")
        assert tuples == [("WidgetApi", "can_get")]

    def test_get_role_and_api_permission_tuples(self, sm_with_roles):
        result = sm_with_roles.get_role_and_api_permission_tuples_from_builtin_roles()
        assert ("Editor", [("WidgetApi", "can_edit"), ("UserApi|RoleApi", "can_get|can_info")]) in result
        assert ("Viewer", [("WidgetApi", "can_get")]) in result


@pytest.mark.asyncio
class TestCreateRoles:
    async def test_create_roles_new(self, sm, session):
        roles = await sm.create_roles(["Admin", "User"], session=session)
        assert sorted(r.name for r in roles) == ["Admin", "User"]

    async def test_create_roles_dedupes_existing(self, sm, session):
        await sm.create_roles(["Admin"], session=session)
        roles = await sm.create_roles(["Admin", "User"], session=session)
        # both returned - first existing, second new
        assert sorted(r.name for r in roles) == ["Admin", "User"]
        from sqlalchemy import select

        result = session.scalars(select(Role)).all()
        assert sorted(r.name for r in result) == ["Admin", "User"]

    async def test_create_role_single(self, sm, session):
        r = await sm.create_role("Solo", session=session)
        assert r.name == "Solo"

    async def test_create_role_swallows_when_no_raise(self, sm, session):
        await sm.create_role("Dup", session=session)
        # Reuse same session; second add violates unique constraint on commit.
        result = await sm.create_role(
            "Dup", session=session, raise_exception=False
        )
        assert result is None


@pytest.mark.asyncio
class TestCreatePermissions:
    async def test_create_permissions(self, sm, session):
        perms = await sm.create_permissions(["can_get", "can_edit"], session=session)
        assert sorted(p.name for p in perms) == ["can_edit", "can_get"]

    async def test_create_apis(self, sm, session):
        apis = await sm.create_apis(["UsersApi", "RolesApi"], session=session)
        assert sorted(a.name for a in apis) == ["RolesApi", "UsersApi"]


@pytest.mark.asyncio
class TestCreateEntitiesErrorPath:
    async def test_raises_on_failure_default(self, sm, session):
        # Pre-create then create again with same name - unique constraint trips on commit.
        await sm.create_roles(["X"], session=session)
        # Add a role manually with same name to force IntegrityError on commit.
        session.add(Role(name="X"))
        with pytest.raises(Exception):
            await sm.create_roles(["X"], session=session)
        session.rollback()

    async def test_swallows_failure_when_no_raise(self, sm, session):
        await sm.create_roles(["Y"], session=session)
        session.add(Role(name="Y"))
        result = await sm.create_roles(
            ["Y"], session=session, raise_exception=False
        )
        assert result is None
        session.rollback()


@pytest.mark.asyncio
class TestAssociateLists:
    async def test_associate_permission_with_api(self, sm, session):
        perms = await sm.create_permissions(["can_get"], session=session)
        apis = await sm.create_apis(["WidgetApi"], session=session)
        pas = await sm.associate_list_of_permission_with_api(
            [(perms[0], apis[0])], session=session
        )
        assert len(pas) == 1
        assert pas[0].permission.name == "can_get"
        assert pas[0].api.name == "WidgetApi"

    async def test_associate_dedupes(self, sm, session):
        perms = await sm.create_permissions(["can_get"], session=session)
        apis = await sm.create_apis(["WidgetApi"], session=session)
        await sm.associate_list_of_permission_with_api(
            [(perms[0], apis[0])], session=session
        )
        again = await sm.associate_list_of_permission_with_api(
            [(perms[0], apis[0])], session=session
        )
        # Returns existing only - no new rows.
        assert len(again) == 1
        from sqlalchemy import select

        rows = session.scalars(select(PermissionApi)).all()
        assert len(rows) == 1

    async def test_associate_role_with_permission_api(self, sm, session):
        perms = await sm.create_permissions(["can_get"], session=session)
        apis = await sm.create_apis(["WidgetApi"], session=session)
        roles = await sm.create_roles(["Editor"], session=session)
        pas = await sm.associate_list_of_permission_with_api(
            [(perms[0], apis[0])], session=session
        )
        await sm.associate_list_of_role_with_permission_api(
            [(roles[0], pas[0])], session=session
        )
        assert roles[0] in pas[0].roles

    async def test_associate_role_dedupes(self, sm, session):
        perms = await sm.create_permissions(["can_get"], session=session)
        apis = await sm.create_apis(["WidgetApi"], session=session)
        roles = await sm.create_roles(["Editor"], session=session)
        pas = await sm.associate_list_of_permission_with_api(
            [(perms[0], apis[0])], session=session
        )
        await sm.associate_list_of_role_with_permission_api(
            [(roles[0], pas[0])], session=session
        )
        # Re-call shouldn't duplicate
        await sm.associate_list_of_role_with_permission_api(
            [(roles[0], pas[0])], session=session
        )
        assert pas[0].roles.count(roles[0]) == 1


@pytest.mark.asyncio
class TestCleanup:
    async def test_cleanup_requires_toolkit(self, sm, session):
        with pytest.raises(Exception, match="FastAPIReactToolkit"):
            await sm.cleanup(session=session)

    async def test_cleanup_removes_unused(
        self, sm_with_roles, session, config_setter
    ):
        from types import SimpleNamespace

        sm_with_roles.toolkit = SimpleNamespace(
            apis=[],
            total_permissions=lambda: ["can_edit", "can_get", "can_info"],
        )

        # Pre-seed: relevant entities + an unused one.
        editor = (await sm_with_roles.create_roles(["Editor"], session=session))[0]
        widget = (await sm_with_roles.create_apis(["WidgetApi"], session=session))[0]
        ghost_api = (await sm_with_roles.create_apis(["GhostApi"], session=session))[0]
        can_edit = (
            await sm_with_roles.create_permissions(["can_edit"], session=session)
        )[0]
        ghost_perm = (
            await sm_with_roles.create_permissions(["can_ghost"], session=session)
        )[0]
        pas = await sm_with_roles.associate_list_of_permission_with_api(
            [(can_edit, widget)], session=session
        )
        await sm_with_roles.associate_list_of_role_with_permission_api(
            [(editor, pas[0])], session=session
        )

        await sm_with_roles.cleanup(session=session)

        from sqlalchemy import select

        remaining_perms = sorted(
            p.name for p in session.scalars(select(Permission)).all()
        )
        remaining_apis = sorted(a.name for a in session.scalars(select(Api)).all())
        assert "can_ghost" not in remaining_perms
        assert "GhostApi" not in remaining_apis


@pytest.mark.asyncio
class TestExportData:
    async def test_export_roles_json(self, sm, session):
        await sm.create_roles(["Admin"], session=session)
        out = await sm.export_data("roles", "json", session=session)
        assert "Admin" in out

    async def test_export_roles_csv(self, sm, session):
        await sm.create_roles(["Admin"], session=session)
        out = await sm.export_data("roles", "csv", session=session)
        assert out.startswith("Role,Data\n")
        assert "Admin" in out


@pytest.mark.asyncio
class TestSecurityManagerSwallowExceptionPaths:
    """Cover get_roles / create_role / reset_password swallow-error branches
    when raise_exception=False."""

    async def test_get_roles_swallows_exception_when_raise_false(self, global_setter):
        from unittest.mock import MagicMock

        from fastapi_rtk.security.sqla.security_manager import SecurityManager

        sm = SecurityManager.__new__(SecurityManager)
        boom_session = MagicMock()

        def boom_manager(_db):
            raise RuntimeError("boom")
            yield  # noqa: unreachable

        auth_stub = MagicMock()
        auth_stub.get_user_manager = boom_manager
        global_setter("auth", auth_stub)

        result = await sm.get_roles(["X"], session=boom_session, raise_exception=False)
        assert result is None

    async def test_create_role_swallows_exception(self):
        from unittest.mock import MagicMock

        from fastapi_rtk.security.sqla.security_manager import SecurityManager

        sm = SecurityManager.__new__(SecurityManager)
        boom_session = MagicMock()
        boom_session.add = MagicMock(side_effect=Exception("boom"))
        result = await sm.create_role("X", session=boom_session, raise_exception=False)
        assert result is None

    async def test_reset_password_swallows_exception(self, global_setter):
        from unittest.mock import MagicMock

        from fastapi_rtk.security.sqla.security_manager import SecurityManager

        sm = SecurityManager.__new__(SecurityManager)
        user = MagicMock(active=False)
        boom_session = MagicMock()

        def boom_manager(_db):
            raise RuntimeError("boom")
            yield  # noqa: unreachable

        auth_stub = MagicMock()
        auth_stub.get_user_manager = boom_manager
        global_setter("auth", auth_stub)

        result = await sm.reset_password(
            user, "newpw", session=boom_session, raise_exception=False
        )
        assert result is None
