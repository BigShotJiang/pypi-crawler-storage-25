"""Tier 14 - tests for fastapi_rtk.cli.cli (top-level Typer app)."""

import io
import zipfile
from unittest.mock import patch

from typer.testing import CliRunner

from fastapi_rtk.cli.cli import app, main
from fastapi_rtk.version import __version__

runner = CliRunner()


def _build_skeleton_zip(*, with_naked_root_entry: bool = False) -> bytes:
    """Synthetic skeleton archive that mimics the layout of the upstream zip."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        if with_naked_root_entry:
            # Triggers the empty-target_path continue branch
            zf.writestr("skeleton-main", "")
        zf.writestr("skeleton-main/", "")
        zf.writestr("skeleton-main/README.md", "# skeleton")
        zf.writestr("skeleton-main/app/", "")
        zf.writestr("skeleton-main/app/main.py", "print('ok')")
    return buf.getvalue()


class TestHelp:
    def test_help_returns_zero(self):
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0

    def test_help_shows_create_app(self):
        result = runner.invoke(app, ["--help"])
        assert "create-app" in result.output


class TestVersion:
    def test_version_returns_zero(self):
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0

    def test_version_shows_version_string(self):
        result = runner.invoke(app, ["--version"])
        assert __version__ in result.output


class TestCreateAppHelp:
    def test_create_app_help(self):
        result = runner.invoke(app, ["create-app", "--help"])
        assert result.exit_code == 0
        assert "directory" in result.output.lower()


class TestCreateAppExtraction:
    def test_create_app_extracts_skeleton(self, tmp_path):
        # Mock httpx.Client to return a fake zip archive so the command
        # exercises its extraction logic without hitting the network.
        zip_bytes = _build_skeleton_zip()

        class FakeResponse:
            content = zip_bytes

            def raise_for_status(self):
                pass

        class FakeClient:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                pass

            def get(self, url):
                return FakeResponse()

        with patch("fastapi_rtk.cli.cli.httpx.Client", FakeClient):
            result = runner.invoke(app, ["create-app", "--directory", str(tmp_path)])
        assert result.exit_code == 0, result.output
        assert (tmp_path / "README.md").exists()
        assert (tmp_path / "app" / "main.py").exists()
        assert "skeleton created" in result.output

    def test_create_app_handles_naked_root_entry(self, tmp_path):
        # Some zip producers list the top-level dir without a trailing slash;
        # exercise the empty-target_path skip branch.
        zip_bytes = _build_skeleton_zip(with_naked_root_entry=True)

        class FakeResponse:
            content = zip_bytes

            def raise_for_status(self):
                pass

        class FakeClient:
            def __enter__(self):
                return self

            def __exit__(self, *a):
                pass

            def get(self, url):
                return FakeResponse()

        with patch("fastapi_rtk.cli.cli.httpx.Client", FakeClient):
            result = runner.invoke(app, ["create-app", "--directory", str(tmp_path)])
        assert result.exit_code == 0, result.output
        assert (tmp_path / "README.md").exists()


class TestMain:
    def test_main_invokes_app(self):
        # main() calls app() under typer; verify it's a callable that runs.
        with patch("fastapi_rtk.cli.cli.app") as mock_app:
            main()
            mock_app.assert_called_once()
