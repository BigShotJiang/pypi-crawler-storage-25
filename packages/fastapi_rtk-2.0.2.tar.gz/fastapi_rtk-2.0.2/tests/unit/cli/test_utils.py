"""Tier 14 - tests for fastapi_rtk.cli.utils."""

import asyncio

import polib
import pytest

from fastapi_rtk.cli.utils import (
    json_to_markdown,
    merge_pot_files,
    run_in_current_event_loop,
)


class TestRunInCurrentEventLoop:
    def test_runs_coroutine(self):
        async def add():
            return 42

        result = run_in_current_event_loop(add())
        assert result == 42

    def test_propagates_exception(self):
        async def boom():
            raise RuntimeError("nope")

        with pytest.raises(RuntimeError, match="nope"):
            run_in_current_event_loop(boom())

    def test_raises_when_called_inside_running_loop(self):
        async def use_helper():
            async def inner():
                return 1

            run_in_current_event_loop(inner())

        with pytest.raises(RuntimeError, match="already running"):
            asyncio.run(use_helper())


class TestJsonToMarkdown:
    def test_simple_dict(self):
        md = json_to_markdown({"key": "value"})
        assert "# key" in md
        assert "value" in md

    def test_nested_dict(self):
        md = json_to_markdown({"a": {"b": "c"}})
        assert "# a" in md
        assert "## b" in md
        assert "c" in md

    def test_list_as_bullets(self):
        md = json_to_markdown({"items": ["x", "y"]})
        assert "- x" in md
        assert "- y" in md

    def test_list_as_table(self):
        md = json_to_markdown(
            {"rows": [{"a": 1, "b": 2}, {"a": 3, "b": 4}]},
            list_as_table=True,
            configuration={"rows": {"list_as_table": True}},
        )
        assert "| a | b |" in md
        assert "| 1 | 2 |" in md

    def test_list_as_is_via_configuration(self):
        md = json_to_markdown(
            {"items": ["x"]},
            configuration={"items": {"list_as_is": True}},
        )
        # list_as_is True at the recursive call -> no bullet prefix
        assert "- x" not in md
        assert "x" in md

    def test_heading_too_deep_raises(self):
        with pytest.raises(ValueError, match="Heading level"):
            json_to_markdown({"a": {"b": {"c": {"d": {"e": {"f": {"g": "x"}}}}}}})

    def test_scalar_passthrough(self):
        result = json_to_markdown("plain string")
        assert "plain string" in result

    def test_empty_list_as_table(self):
        md = json_to_markdown(
            {"rows": []},
            configuration={"rows": {"list_as_table": True}},
        )
        # Empty list -> nothing emitted under the heading
        assert "| " not in md

    def test_list_of_dicts_without_table(self):
        md = json_to_markdown({"items": [{"a": 1}, {"b": 2}]})
        # Each dict gets nested heading
        assert "## a" in md
        assert "## b" in md


class TestMergePotFiles:
    def test_merges_two_files(self, tmp_path):
        file1 = tmp_path / "a.pot"
        file2 = tmp_path / "b.pot"
        out = tmp_path / "merged.pot"

        po1 = polib.POFile()
        po1.metadata = {
            "Content-Type": "text/plain; charset=UTF-8",
            "MIME-Version": "1.0",
        }
        e1 = polib.POEntry(msgid="hello", msgstr="hello1")
        po1.append(e1)
        po1.save(str(file1))

        po2 = polib.POFile()
        po2.metadata = {
            "Content-Type": "text/plain; charset=UTF-8",
            "MIME-Version": "1.0",
        }
        e2 = polib.POEntry(msgid="world", msgstr="world2")
        po2.append(e2)
        po2.save(str(file2))

        merge_pot_files([str(file1), str(file2)], str(out))

        merged = polib.pofile(str(out))
        msgs = [e.msgid for e in merged]
        assert "hello" in msgs
        assert "world" in msgs

    def test_dedupes_existing_entries(self, tmp_path):
        file1 = tmp_path / "a.pot"
        file2 = tmp_path / "b.pot"
        out = tmp_path / "merged.pot"

        for f in (file1, file2):
            po = polib.POFile()
            po.metadata = {
                "Content-Type": "text/plain; charset=UTF-8",
                "MIME-Version": "1.0",
            }
            e = polib.POEntry(msgid="shared", msgstr="x", occurrences=[("a.py", "1")])
            po.append(e)
            po.save(str(f))

        merge_pot_files([str(file1), str(file2)], str(out))

        merged = polib.pofile(str(out))
        msgs = [e.msgid for e in merged]
        # Single entry only
        assert msgs.count("shared") == 1
