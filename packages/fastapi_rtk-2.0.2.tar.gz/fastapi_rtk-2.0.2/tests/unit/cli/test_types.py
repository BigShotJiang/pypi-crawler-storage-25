"""Tier 14 - smoke tests for fastapi_rtk.cli.types TypedDicts."""

from fastapi_rtk.cli.types import (
    APIDataDocs,
    APIDocs,
    APIMetadataDocs,
    APIPathDocs,
    DBDataDocs,
    DBDocs,
    DBTableColumnDocs,
    DBTableDocs,
    TableDocumentation,
)


class TestTypedDictsAvailable:
    def test_api_path_docs(self):
        v: APIPathDocs = {
            "path": "/x",
            "method": "GET",
            "description": "d",
            "result": "r",
        }
        assert v["path"] == "/x"

    def test_api_metadata_docs(self):
        v: APIMetadataDocs = {"Parameters": [], "Body": {}, "Responses": []}
        assert v["Parameters"] == []

    def test_api_data_docs(self):
        v: APIDataDocs = {"Description": "d", "Paths": [], "Metadata": {}}
        assert v["Description"] == "d"

    def test_api_docs(self):
        v: APIDocs = {"APIs": {}, "Schemas": {}}
        assert v["APIs"] == {}

    def test_db_table_column_docs(self):
        v: DBTableColumnDocs = {
            "name": "id",
            "type": "INT",
            "nullable": False,
            "description": "primary key",
            "default": "",
        }
        assert v["nullable"] is False

    def test_db_table_docs(self):
        v: DBTableDocs = {"Description": "x", "Columns": [], "PrimaryKeys": []}
        assert v["Description"] == "x"

    def test_db_data_docs(self):
        v: DBDataDocs = {"Summary": [], "Tables": {}}
        assert v["Tables"] == {}

    def test_db_docs(self):
        v: DBDocs = {"Database": {}}
        assert v["Database"] == {}

    def test_table_documentation(self):
        v: TableDocumentation = {"description": "d", "columns": {"id": "x"}}
        assert v["columns"]["id"] == "x"
