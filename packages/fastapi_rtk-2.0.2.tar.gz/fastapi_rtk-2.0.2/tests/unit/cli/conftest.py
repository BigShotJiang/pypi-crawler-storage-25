"""Shared fixtures for tier 14 cli/ tests.

Some typer command callbacks are decorated with `@ensure_fastapi_rtk_tables_exist`,
which sets `g.is_migrate = True`. Even invoking with `--help` runs the
callback, so the flag leaks into later tests. Reset it after each test.
"""

import pytest

from fastapi_rtk.globals import g


@pytest.fixture(autouse=True)
def _reset_is_migrate():
    yield
    g.is_migrate = False
