"""Tier 14 - tests for fastapi_rtk.cli.decorators."""

from unittest.mock import MagicMock, patch

import pytest
import typer

from fastapi_rtk.cli.decorators import (
    _check_existing_app,
    _set_migrate_mode,
    check_existing_app_silent,
    ensure_fastapi_rtk_tables_exist,
)


class TestSetMigrateMode:
    def test_sets_migrate_flag(self, global_setter):
        global_setter("is_migrate", False)

        from fastapi_rtk.globals import g

        captured = []

        @_set_migrate_mode
        def fn():
            captured.append(g.is_migrate)
            return "ok"

        try:
            result = fn()
            assert result == "ok"
            assert captured == [True]
        finally:
            # Restore the default - the decorator writes to g._vars which
            # bypasses the global_setter fixture's restore semantics.
            g.is_migrate = False


class TestCheckExistingApp:
    def test_runs_when_app_exists(self):
        with patch("fastapi_rtk.cli.decorators.get_import_data"):
            calls = []

            @_check_existing_app
            def fn():
                calls.append(1)
                return "result"

            assert fn() == "result"
            assert calls == [1]

    def test_raises_typer_exit_on_error(self):
        from fastapi_cli.exceptions import FastAPICLIException

        with patch(
            "fastapi_rtk.cli.decorators.get_import_data",
            side_effect=FastAPICLIException("missing app"),
        ):

            @_check_existing_app
            def fn():
                return "should not run"

            with pytest.raises(typer.Exit):
                fn()


class TestCheckExistingAppSilent:
    def test_runs_when_app_exists(self):
        with patch("fastapi_rtk.cli.decorators.get_import_data"):
            calls = []

            @check_existing_app_silent
            def fn():
                calls.append(1)
                return "result"

            assert fn() == "result"

    def test_silent_swallows_error(self):
        from fastapi_cli.exceptions import FastAPICLIException

        with patch(
            "fastapi_rtk.cli.decorators.get_import_data",
            side_effect=FastAPICLIException("missing app"),
        ):
            calls = []

            @check_existing_app_silent
            def fn():
                calls.append(1)
                return "result"

            # Silent variant should not raise; runs the wrapped function
            assert fn() == "result"


class TestEnsureFastapiRtkTablesExist:
    def test_initializes_tables(self):
        with patch("fastapi_rtk.cli.decorators.get_import_data"), patch(
            "fastapi_rtk.cli.decorators.db"
        ) as mock_db, patch(
            "fastapi_rtk.cli.decorators.run_in_current_event_loop"
        ) as mock_run:
            mock_db.init_fastapi_rtk_tables.return_value = MagicMock()

            @ensure_fastapi_rtk_tables_exist
            def fn():
                return "done"

            result = fn()
            assert result == "done"
            mock_run.assert_called_once()
