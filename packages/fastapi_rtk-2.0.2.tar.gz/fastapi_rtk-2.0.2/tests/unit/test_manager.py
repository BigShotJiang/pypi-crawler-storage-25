"""Tier 11 - tests for fastapi_rtk.manager.UserManager.

LDAP, OAuth, request-context flows (verify, reset, register) are deferred -
they require ldap3 mocking, fastapi_users routers, and full toolkit wiring.
This module covers IDParser, UserManager auth/update/role plumbing, and the
public helpers (get_by_username, get_roles_by_names, on_after_authenticate).
"""

from datetime import datetime
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest
import pytest_asyncio
import sqlalchemy
from fastapi.security import OAuth2PasswordRequestForm
from fastapi_users import exceptions
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from fastapi_rtk.auth.password_helpers.fab import FABPasswordHelper
from fastapi_rtk.backends.sqla.model import Model
from fastapi_rtk.db import UserDatabase
from fastapi_rtk.exceptions import RolesMismatchException
from fastapi_rtk.manager import IDParser, UserManager
from fastapi_rtk.security.sqla.models import OAuthAccount, Role, User


@pytest.fixture
def engine():
    eng = sqlalchemy.create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    tables = [t for n, t in Model.metadata.tables.items() if n.startswith("ab_")]
    Model.metadata.create_all(eng, tables=tables)
    yield eng
    Model.metadata.drop_all(eng, tables=tables)
    eng.dispose()


@pytest.fixture
def session(engine):
    with Session(engine) as s:
        yield s


@pytest.fixture
def user_db(session):
    return UserDatabase(session, User, OAuthAccount)


@pytest.fixture
def manager(user_db):
    return UserManager(user_db, secret_key="test-secret-key-32-bytes-padding!")


@pytest_asyncio.fixture
async def existing_user(manager, user_db):
    hp = manager.password_helper.hash("secret")
    return await user_db.create(
        {
            "username": "alice",
            "email": "alice@example.com",
            "hashed_password": hp,
            "active": True,
        }
    )


class TestIDParser:
    def test_int_passthrough(self):
        assert IDParser().parse_id(5) == 5

    def test_str_to_int(self):
        assert IDParser().parse_id("7") == 7

    def test_invalid_raises(self):
        with pytest.raises(exceptions.InvalidID):
            IDParser().parse_id("abc")


class TestUserManagerInit:
    def test_secret_keys_set(self, user_db):
        secret = "abc-secret-key-32-bytes-padding!!"
        m = UserManager(user_db, secret_key=secret)
        assert m.reset_password_token_secret == secret
        assert m.verification_token_secret == secret

    def test_default_password_helper(self, user_db):
        m = UserManager(user_db, secret_key="abc-secret-key-32-bytes-padding!!")
        assert m.password_helper is not None


@pytest.mark.asyncio
class TestGetByUsername:
    async def test_existing(self, manager, existing_user):
        u = await manager.get_by_username("alice")
        assert u.email == "alice@example.com"

    async def test_missing_raises(self, manager):
        with pytest.raises(exceptions.UserNotExists):
            await manager.get_by_username("ghost")


@pytest.mark.asyncio
class TestGetRolesByNames:
    async def test_empty_list_returns_empty(self, manager):
        result = await manager.get_roles_by_names([])
        assert result == []

    async def test_str_treated_as_list(self, manager, session):
        session.add(Role(name="Editor"))
        session.commit()
        result = await manager.get_roles_by_names("Editor")
        assert len(result) == 1
        assert result[0].name == "Editor"

    async def test_existing_roles(self, manager, session):
        session.add_all([Role(name="A"), Role(name="B")])
        session.commit()
        result = await manager.get_roles_by_names(["A", "B"])
        assert sorted(r.name for r in result) == ["A", "B"]

    async def test_mismatch_raises(self, manager, session):
        session.add(Role(name="A"))
        session.commit()
        with pytest.raises(RolesMismatchException):
            await manager.get_roles_by_names(["A", "B"])

    async def test_mismatch_no_raise(self, manager, session):
        session.add(Role(name="A"))
        session.commit()
        result = await manager.get_roles_by_names(
            ["A", "B"], raise_exception_when_mismatch=False
        )
        assert len(result) == 1


@pytest.mark.asyncio
class TestAuthenticate:
    async def test_success(self, manager, existing_user):
        creds = OAuth2PasswordRequestForm(username="alice", password="secret")
        u = await manager.authenticate(creds)
        assert u is not None
        assert u.username == "alice"

    async def test_wrong_password(self, manager, existing_user):
        creds = OAuth2PasswordRequestForm(username="alice", password="wrong")
        u = await manager.authenticate(creds)
        assert u is None

    async def test_missing_user(self, manager):
        creds = OAuth2PasswordRequestForm(username="ghost", password="secret")
        u = await manager.authenticate(creds)
        assert u is None


@pytest.mark.asyncio
class TestOnAfterAuthenticate:
    async def test_success_increments_counters(self, manager, existing_user):
        before = existing_user.login_count or 0
        await manager.on_after_authenticate(existing_user, True)
        assert existing_user.login_count == before + 1
        assert existing_user.fail_login_count == 0
        assert isinstance(existing_user.last_login, datetime)

    async def test_failure_increments_fail_counter(self, manager, existing_user):
        before = existing_user.fail_login_count or 0
        await manager.on_after_authenticate(existing_user, False)
        assert existing_user.fail_login_count == before + 1


@pytest.mark.asyncio
class TestUpdateInternal:
    async def test_password_hashed(self, manager, existing_user):
        old_hash = existing_user.hashed_password
        u = await manager._update(existing_user, {"password": "newpass"})
        assert u.hashed_password != old_hash
        assert u.hashed_password != "newpass"

    async def test_username_change(self, manager, existing_user):
        u = await manager._update(existing_user, {"username": "alice2"})
        assert u.username == "alice2"

    async def test_username_conflict(self, manager, existing_user, user_db):
        await user_db.create(
            {"username": "taken", "email": "t@x.com", "hashed_password": "h"}
        )
        with pytest.raises(exceptions.UserAlreadyExists):
            await manager._update(existing_user, {"username": "taken"})

    async def test_email_change(self, manager, existing_user):
        u = await manager._update(existing_user, {"email": "alice2@x.com"})
        assert u.email == "alice2@x.com"

    async def test_email_conflict(self, manager, existing_user, user_db):
        await user_db.create(
            {"username": "u2", "email": "taken@x.com", "hashed_password": "h"}
        )
        with pytest.raises(exceptions.UserAlreadyExists):
            await manager._update(existing_user, {"email": "taken@x.com"})

    async def test_plain_field_passthrough(self, manager, existing_user):
        u = await manager._update(existing_user, {"first_name": "Alicia"})
        assert u.first_name == "Alicia"


@pytest.mark.asyncio
class TestHandleRoleKeys:
    async def test_none_keys_passthrough(self, manager, existing_user):
        result = await manager._handle_role_keys(existing_user, None)
        assert result is existing_user

    async def test_dict_path_with_mapping(self, manager, session, config_setter):
        config_setter("AUTH_ROLES_MAPPING", {"admins": ["Admin"]})
        session.add(Role(name="Admin"))
        session.commit()
        result = await manager._handle_role_keys({"foo": "bar"}, ["admins"])
        assert "roles" in result
        assert result["roles"][0].name == "Admin"

    async def test_dict_path_dedupes_role_names(self, manager, session, config_setter):
        config_setter("AUTH_ROLES_MAPPING", {"a": ["X"], "b": ["X", "Y"]})
        session.add_all([Role(name="X"), Role(name="Y")])
        session.commit()
        result = await manager._handle_role_keys({}, ["a", "b"])
        assert sorted(r.name for r in result["roles"]) == ["X", "Y"]


@pytest.mark.asyncio
class TestForgotPassword:
    async def test_inactive_raises(self, manager, existing_user):
        existing_user.active = False
        with pytest.raises(exceptions.UserInactive):
            await manager.forgot_password(existing_user)

    async def test_returns_token_when_no_request(self, manager, existing_user):
        token = await manager.forgot_password(existing_user)
        assert isinstance(token, str)
        assert len(token) > 20


@pytest.mark.asyncio
class TestOnAfterRequestVerifyEtc:
    async def test_logout_noop(self, manager, existing_user):
        result = await manager.on_after_logout(existing_user)
        assert result is None

    async def test_forgot_password_with_request_raises(self, manager, existing_user):
        from fastapi import HTTPException

        # request-context emails not implemented - hook raises 501
        with pytest.raises(HTTPException) as exc_info:
            await manager.on_after_forgot_password(
                existing_user, "tok", request=SimpleNamespace()
            )
        assert exc_info.value.status_code == 501

    async def test_reset_password_with_request_raises(self, manager, existing_user):
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as exc_info:
            await manager.on_after_reset_password(
                existing_user, request=SimpleNamespace()
            )
        assert exc_info.value.status_code == 501

    async def test_request_verify_with_request_raises(self, manager, existing_user):
        from fastapi import HTTPException

        with pytest.raises(HTTPException) as exc_info:
            await manager.on_after_request_verify(
                existing_user, "tok", request=SimpleNamespace()
            )
        assert exc_info.value.status_code == 501


@pytest.mark.asyncio
class TestCreate:
    async def test_create_basic(self, manager, user_db):
        u = await manager.create(
            {
                "username": "newbie",
                "email": "newbie@example.com",
                "password": "secret123",
            }
        )
        assert u.id is not None
        assert u.username == "newbie"
        # password hashed
        assert u.hashed_password != "secret123"

    async def test_create_duplicate_email_raises(self, manager, existing_user):
        with pytest.raises(exceptions.UserAlreadyExists):
            await manager.create(
                {
                    "username": "different",
                    "email": existing_user.email,
                    "password": "secret123",
                }
            )

    async def test_create_with_roles(self, manager, session):
        session.add(Role(name="Editor"))
        session.commit()
        u = await manager.create(
            {
                "username": "withrole",
                "email": "wr@example.com",
                "password": "secret123",
            },
            roles=["Editor"],
        )
        assert any(r.name == "Editor" for r in u.roles)


@pytest.mark.asyncio
class TestAuthenticateRehash:
    async def test_password_rehash_updates_user(self, manager, existing_user):
        from unittest.mock import AsyncMock, patch

        # Force verify_and_update to return updated_password_hash != None,
        # so the rehash branch (line 123) runs.
        with patch.object(
            manager.password_helper,
            "verify_and_update",
            return_value=(True, "rehashed-hash"),
        ):
            update_spy = AsyncMock()
            manager.user_db.update = update_spy
            credentials = OAuth2PasswordRequestForm(
                username=existing_user.username, password="secret"
            )
            user = await manager.authenticate(credentials)
        assert user is not None
        update_spy.assert_any_call(existing_user, {"hashed_password": "rehashed-hash"})


@pytest.mark.asyncio
class TestCreateRolesFromSetting:
    async def test_create_with_request_uses_registration_role(
        self, manager, session, config_setter
    ):
        from types import SimpleNamespace

        session.add(Role(name="Public"))
        session.commit()
        config_setter("AUTH_USER_REGISTRATION_ROLE", "Public")
        u = await manager.create(
            {
                "username": "publicguy",
                "email": "p@example.com",
                "password": "secret123",
            },
            request=SimpleNamespace(),
        )
        assert any(r.name == "Public" for r in u.roles)


@pytest.mark.asyncio
class TestOAuthCallback:
    async def _make_oauth_user(self, manager, oauth_name, account_id):
        from fastapi_rtk.security.sqla.models import OAuthAccount

        u = await manager.user_db.create(
            {
                "username": "linked",
                "email": "linked@x.com",
                "hashed_password": manager.password_helper.hash("secret"),
                "active": True,
            }
        )
        await manager.user_db.add_oauth_account(
            u,
            {
                "oauth_name": oauth_name,
                "access_token": "old-token",
                "expires_at": 1,
                "refresh_token": None,
                "account_id": account_id,
                "account_email": "linked@x.com",
            },
        )
        return u

    async def test_oauth_callback_updates_existing_oauth_account(self, manager):
        await self._make_oauth_user(manager, "google", "acct-1")
        result = await manager.oauth_callback(
            "google",
            "new-token",
            "acct-1",
            "linked@x.com",
            expires_at=2,
        )
        assert result.email == "linked@x.com"

    async def test_oauth_callback_no_associate_by_email_raises(
        self, manager, existing_user
    ):
        # Existing user with the same email but no oauth account; default
        # associate_by_email=False -> raises UserAlreadyExists.
        from fastapi_users.exceptions import UserAlreadyExists

        with pytest.raises(UserAlreadyExists):
            await manager.oauth_callback(
                "google",
                "tok",
                "acct-new",
                existing_user.email,
            )

    async def test_oauth_callback_associate_by_email_links_user(
        self, manager, existing_user
    ):
        result = await manager.oauth_callback(
            "google",
            "tok",
            "acct-new",
            existing_user.email,
            associate_by_email=True,
        )
        assert result.email == existing_user.email

    async def test_oauth_callback_creates_new_user(self, manager):
        result = await manager.oauth_callback(
            "google",
            "tok",
            "acct-new-2",
            "fresh@x.com",
            is_verified_by_default=True,
        )
        assert result.email == "fresh@x.com"

    async def test_oauth_callback_with_on_before_register_callback(self, manager):
        called = {}

        async def on_before_register(account_email):
            called["fired"] = True
            return {"username": "callback-named"}

        result = await manager.oauth_callback(
            "google",
            "tok",
            "acct-cb",
            "cb@x.com",
            on_before_register=on_before_register,
        )
        assert called.get("fired") is True
        assert result.username == "callback-named"

    async def test_oauth_callback_with_on_after_register_callback(self, manager):
        called = {}

        async def on_after_register(user):
            called["fired"] = True

        await manager.oauth_callback(
            "google",
            "tok",
            "acct-after",
            "after@x.com",
            on_after_register=on_after_register,
        )
        assert called.get("fired") is True

    async def test_oauth_callback_with_on_before_login_callback(self, manager):
        await self._make_oauth_user(manager, "google", "acct-login")
        called = {}

        async def on_before_login(user):
            called["fired"] = True

        await manager.oauth_callback(
            "google",
            "tok",
            "acct-login",
            "linked@x.com",
            on_before_login=on_before_login,
        )
        assert called.get("fired") is True


@pytest.mark.asyncio
class TestUpdate:
    async def test_update_via_dict(self, manager, existing_user):
        u = await manager.update({"first_name": "Alicia"}, existing_user)
        assert u.first_name == "Alicia"

    async def test_update_with_roles(self, manager, existing_user, session):
        session.add(Role(name="NewRole"))
        session.commit()
        u = await manager.update({"first_name": "X"}, existing_user, roles=["NewRole"])
        assert any(r.name == "NewRole" for r in u.roles)


# ---------------------------------------------------------------------------
# LDAP authentication tests (authenticate_ldap, _ldap3_search,
# _ldap3_calculate_user). Mocks ldap3.Connection / Server / Tls.
# ---------------------------------------------------------------------------


def _make_ldap_conn(rebind_ok=True, entries=None):
    """Build a stub ldap3.Connection with context-manager support."""
    conn = MagicMock()
    conn.__enter__ = MagicMock(return_value=conn)
    conn.__exit__ = MagicMock(return_value=False)
    conn.rebind = MagicMock(return_value=rebind_ok)
    conn.entries = entries or []
    conn.search = MagicMock(return_value=True)
    return conn


def _make_ldap_entry(dn, attrs=None):
    e = MagicMock()
    e.entry_dn = dn
    e.entry_attributes_as_dict = attrs or {}
    return e


@pytest.mark.asyncio
class TestLdapEarlyExits:
    async def test_empty_username_returns_none(self, manager, config_setter):
        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")
        config_setter("AUTH_USER_REGISTRATION", True)
        creds = OAuth2PasswordRequestForm(username="", password="x")
        result = await manager.authenticate_ldap(creds)
        assert result is None

    async def test_inactive_user_returns_none(
        self, manager, existing_user, config_setter
    ):
        existing_user.active = False
        manager.user_db.session.add(existing_user)
        manager.user_db.session.commit()

        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")
        creds = OAuth2PasswordRequestForm(username="alice", password="x")
        result = await manager.authenticate_ldap(creds)
        assert result is None

    async def test_no_user_no_registration_returns_none(self, manager, config_setter):
        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")
        config_setter("AUTH_USER_REGISTRATION", False)
        creds = OAuth2PasswordRequestForm(username="ghost", password="x")
        result = await manager.authenticate_ldap(creds)
        assert result is None


@pytest.mark.asyncio
class TestLdap3Missing:
    async def test_returns_none_when_ldap3_not_installed(
        self, manager, existing_user, config_setter, monkeypatch
    ):
        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")

        real_import = (
            __builtins__["__import__"]
            if isinstance(__builtins__, dict)
            else __builtins__.__import__
        )

        def fake_import(name, *args, **kwargs):
            if name == "ldap3" or name.startswith("ldap3."):
                raise ImportError(f"blocked {name}")
            return real_import(name, *args, **kwargs)

        monkeypatch.setattr("builtins.__import__", fake_import)

        creds = OAuth2PasswordRequestForm(username="alice", password="secret")
        result = await manager.authenticate_ldap(creds)
        assert result is None


@pytest.mark.asyncio
class TestLdapDirectBindFlow:
    async def test_direct_bind_search_no_results_returns_none(
        self, manager, existing_user, config_setter
    ):
        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")
        config_setter("AUTH_LDAP_SEARCH", "ou=users,dc=example,dc=com")

        with patch("ldap3.Connection") as mock_conn_cls, patch("ldap3.Server"):
            mock_conn_cls.return_value = _make_ldap_conn(entries=[])
            creds = OAuth2PasswordRequestForm(username="alice", password="secret")
            result = await manager.authenticate_ldap(creds)
        assert result is None

    async def test_direct_bind_no_search_succeeds(
        self, manager, existing_user, config_setter
    ):
        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")

        with patch("ldap3.Connection") as mock_conn_cls, patch("ldap3.Server"):
            mock_conn_cls.return_value = _make_ldap_conn()
            creds = OAuth2PasswordRequestForm(username="alice", password="secret")
            result = await manager.authenticate_ldap(creds)
        assert result is not None
        assert result.username == "alice"

    async def test_direct_bind_with_username_format(
        self, manager, existing_user, config_setter
    ):
        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")
        config_setter("AUTH_LDAP_USERNAME_FORMAT", "uid=%s,ou=users,dc=example,dc=com")

        with patch("ldap3.Connection") as mock_conn_cls, patch("ldap3.Server"):
            mock_conn_cls.return_value = _make_ldap_conn()
            creds = OAuth2PasswordRequestForm(username="alice", password="secret")
            await manager.authenticate_ldap(creds)
        call_args = mock_conn_cls.call_args
        assert "uid=alice" in call_args[0][1]

    async def test_direct_bind_with_append_domain(
        self, manager, existing_user, config_setter
    ):
        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")
        config_setter("AUTH_LDAP_APPEND_DOMAIN", "example.com")

        with patch("ldap3.Connection") as mock_conn_cls, patch("ldap3.Server"):
            mock_conn_cls.return_value = _make_ldap_conn()
            creds = OAuth2PasswordRequestForm(username="alice", password="secret")
            await manager.authenticate_ldap(creds)
        call_args = mock_conn_cls.call_args
        assert "alice@example.com" in call_args[0][1]


@pytest.mark.asyncio
class TestLdapIndirectBindFlow:
    async def test_indirect_bind_search_no_user_returns_none(
        self, manager, existing_user, config_setter
    ):
        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")
        config_setter("AUTH_LDAP_BIND_USER", "cn=admin,dc=example,dc=com")
        config_setter("AUTH_LDAP_BIND_PASSWORD", "adminpass")
        config_setter("AUTH_LDAP_SEARCH", "ou=users,dc=example,dc=com")

        with patch("ldap3.Connection") as mock_conn_cls, patch("ldap3.Server"):
            mock_conn_cls.return_value = _make_ldap_conn(entries=[])
            creds = OAuth2PasswordRequestForm(username="alice", password="secret")
            result = await manager.authenticate_ldap(creds)
        assert result is None

    async def test_indirect_bind_rebind_fails_returns_none(
        self, manager, existing_user, config_setter
    ):
        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")
        config_setter("AUTH_LDAP_BIND_USER", "cn=admin,dc=example,dc=com")
        config_setter("AUTH_LDAP_BIND_PASSWORD", "adminpass")
        config_setter("AUTH_LDAP_SEARCH", "ou=users,dc=example,dc=com")

        entry = _make_ldap_entry(
            "uid=alice,ou=users,dc=example,dc=com",
            {"mail": ["alice@example.com"]},
        )
        with patch("ldap3.Connection") as mock_conn_cls, patch("ldap3.Server"):
            mock_conn_cls.return_value = _make_ldap_conn(
                rebind_ok=False, entries=[entry]
            )
            creds = OAuth2PasswordRequestForm(username="alice", password="wrong")
            result = await manager.authenticate_ldap(creds)
        assert result is None

    async def test_indirect_bind_success_returns_user(
        self, manager, existing_user, config_setter
    ):
        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")
        config_setter("AUTH_LDAP_BIND_USER", "cn=admin,dc=example,dc=com")
        config_setter("AUTH_LDAP_BIND_PASSWORD", "adminpass")
        config_setter("AUTH_LDAP_SEARCH", "ou=users,dc=example,dc=com")

        entry = _make_ldap_entry(
            "uid=alice,ou=users,dc=example,dc=com",
            {"mail": ["alice@example.com"]},
        )
        with patch("ldap3.Connection") as mock_conn_cls, patch("ldap3.Server"):
            mock_conn_cls.return_value = _make_ldap_conn(entries=[entry])
            creds = OAuth2PasswordRequestForm(username="alice", password="secret")
            result = await manager.authenticate_ldap(creds)
        assert result is not None
        assert result.username == "alice"


@pytest.mark.asyncio
class TestLdapErrors:
    async def test_bind_error_returns_none(self, manager, existing_user, config_setter):
        import ldap3.core.exceptions

        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")

        with patch("ldap3.Connection") as mock_conn_cls, patch("ldap3.Server"):
            mock_conn_cls.side_effect = ldap3.core.exceptions.LDAPBindError(
                "bad credentials"
            )
            creds = OAuth2PasswordRequestForm(username="alice", password="wrong")
            result = await manager.authenticate_ldap(creds)
        assert result is None

    async def test_general_ldap_exception_returns_none(
        self, manager, existing_user, config_setter
    ):
        import ldap3.core.exceptions

        config_setter("AUTH_LDAP_SERVER", "ldap://example.com")

        with patch("ldap3.Connection") as mock_conn_cls, patch("ldap3.Server"):
            mock_conn_cls.side_effect = ldap3.core.exceptions.LDAPException(
                "server down"
            )
            creds = OAuth2PasswordRequestForm(username="alice", password="x")
            result = await manager.authenticate_ldap(creds)
        assert result is None


@pytest.mark.asyncio
class TestLdapTLSConfig:
    async def test_use_tls_constructs_tls(self, manager, existing_user, config_setter):
        config_setter("AUTH_LDAP_SERVER", "ldaps://secure.example.com")
        config_setter("AUTH_LDAP_USE_TLS", True)
        config_setter("AUTH_LDAP_ALLOW_SELF_SIGNED", True)

        with (
            patch("ldap3.Connection") as mock_conn_cls,
            patch("ldap3.Server") as mock_server_cls,
            patch("ldap3.Tls") as mock_tls_cls,
        ):
            mock_conn_cls.return_value = _make_ldap_conn()
            creds = OAuth2PasswordRequestForm(username="alice", password="secret")
            await manager.authenticate_ldap(creds)
        mock_tls_cls.assert_called_once()
        kwargs = mock_server_cls.call_args.kwargs
        assert kwargs.get("use_ssl") is True


class TestLdap3Search:
    def test_no_entries_returns_none_pair(self, manager, config_setter):
        config_setter("AUTH_LDAP_SEARCH", "ou=users,dc=example,dc=com")
        config_setter("AUTH_LDAP_UID_FIELD", "uid")
        config_setter("AUTH_LDAP_FIRSTNAME_FIELD", "givenName")
        config_setter("AUTH_LDAP_LASTNAME_FIELD", "sn")
        config_setter("AUTH_LDAP_EMAIL_FIELD", "mail")

        conn = _make_ldap_conn(entries=[])
        dn, attrs = manager._ldap3_search(conn, "alice")
        assert dn is None
        assert attrs is None

    def test_one_entry_returns_dn_and_attrs(self, manager, config_setter):
        config_setter("AUTH_LDAP_SEARCH", "ou=users,dc=example,dc=com")
        config_setter("AUTH_LDAP_UID_FIELD", "uid")
        config_setter("AUTH_LDAP_FIRSTNAME_FIELD", "givenName")
        config_setter("AUTH_LDAP_LASTNAME_FIELD", "sn")
        config_setter("AUTH_LDAP_EMAIL_FIELD", "mail")

        entry = _make_ldap_entry(
            "uid=alice,ou=users,dc=example,dc=com",
            {"mail": ["alice@example.com"], "givenName": ["Alice"]},
        )
        conn = _make_ldap_conn(entries=[entry])
        dn, attrs = manager._ldap3_search(conn, "alice")
        assert dn == "uid=alice,ou=users,dc=example,dc=com"
        assert attrs["mail"] == ["alice@example.com"]

    def test_multiple_entries_returns_none(self, manager, config_setter):
        config_setter("AUTH_LDAP_SEARCH", "ou=users,dc=example,dc=com")
        config_setter("AUTH_LDAP_UID_FIELD", "uid")
        config_setter("AUTH_LDAP_FIRSTNAME_FIELD", "givenName")
        config_setter("AUTH_LDAP_LASTNAME_FIELD", "sn")
        config_setter("AUTH_LDAP_EMAIL_FIELD", "mail")

        entries = [
            _make_ldap_entry("dn1", {}),
            _make_ldap_entry("dn2", {}),
        ]
        conn = _make_ldap_conn(entries=entries)
        dn, attrs = manager._ldap3_search(conn, "alice")
        assert dn is None
        assert attrs is None

    def test_with_roles_mapping_includes_group_field(self, manager, config_setter):
        config_setter("AUTH_LDAP_SEARCH", "ou=users,dc=example,dc=com")
        config_setter("AUTH_LDAP_UID_FIELD", "uid")
        config_setter("AUTH_LDAP_FIRSTNAME_FIELD", "givenName")
        config_setter("AUTH_LDAP_LASTNAME_FIELD", "sn")
        config_setter("AUTH_LDAP_EMAIL_FIELD", "mail")
        config_setter("AUTH_LDAP_GROUP_FIELD", "memberOf")
        config_setter("AUTH_ROLES_MAPPING", {"cn=admins": ["Admin"]})

        conn = _make_ldap_conn(entries=[])
        manager._ldap3_search(conn, "alice")
        call_args = conn.search.call_args
        attrs = call_args.kwargs.get("attributes") or call_args[1].get("attributes")
        assert "memberOf" in attrs

    def test_with_search_filter(self, manager, config_setter):
        config_setter("AUTH_LDAP_SEARCH", "ou=users,dc=example,dc=com")
        config_setter("AUTH_LDAP_SEARCH_FILTER", "(objectClass=person)")
        config_setter("AUTH_LDAP_UID_FIELD", "uid")
        config_setter("AUTH_LDAP_FIRSTNAME_FIELD", "givenName")
        config_setter("AUTH_LDAP_LASTNAME_FIELD", "sn")
        config_setter("AUTH_LDAP_EMAIL_FIELD", "mail")

        conn = _make_ldap_conn(entries=[])
        manager._ldap3_search(conn, "alice")
        call_args = conn.search.call_args
        filter_str = call_args[0][1]
        assert "objectClass=person" in filter_str
        assert "uid=alice" in filter_str


@pytest.mark.asyncio
class TestLdap3CalculateUser:
    async def test_no_registration_role_warns_and_returns(
        self, manager, existing_user, config_setter
    ):
        config_setter("AUTH_USER_REGISTRATION", True)
        result = await manager._ldap3_calculate_user(existing_user, {})
        assert result is existing_user

    async def test_role_found_assigns(
        self, manager, existing_user, config_setter, session
    ):
        from fastapi_rtk.security.sqla.models import Role

        config_setter("AUTH_USER_REGISTRATION", True)
        config_setter("AUTH_USER_REGISTRATION_ROLE", "Public")
        session.add(Role(name="Public"))
        session.commit()

        result = await manager._ldap3_calculate_user(existing_user, {})
        assert any(r.name == "Public" for r in result.roles)

    async def test_no_registration_skips_role_logic(
        self, manager, existing_user, config_setter
    ):
        config_setter("AUTH_USER_REGISTRATION", False)
        result = await manager._ldap3_calculate_user(existing_user, {})
        assert result is existing_user


class TestLdap3CalculateUserNoRoleWarning:
    """AUTH_USER_REGISTRATION enabled but role unset → warns and returns the
    user without role assignment."""

    @pytest.mark.asyncio
    async def test_no_role_warns_and_returns(self, config_setter, monkeypatch):
        from unittest.mock import AsyncMock

        config_setter("AUTH_USER_REGISTRATION", True)
        config_setter("AUTH_USER_REGISTRATION_ROLE", "")
        config_setter("AUTH_LDAP_GROUP_FIELD", "groups")

        user = MagicMock(roles=[])
        monkeypatch.setattr(
            UserManager,
            "_handle_role_keys",
            AsyncMock(return_value=user),
            raising=False,
        )
        mgr = UserManager.__new__(UserManager)
        result = await UserManager._ldap3_calculate_user(mgr, user, {"groups": []})
        assert result is user


class TestAuthenticateLdapTlsConfig:
    """AUTH_LDAP_ALLOW_SELF_SIGNED → CERT_OPTIONAL TLS path. Patches `ldap3`
    via sys.modules since it's imported lazily inside the method body."""

    @pytest.mark.asyncio
    async def test_self_signed_uses_cert_optional(self, config_setter):
        import sys
        from unittest.mock import AsyncMock

        config_setter("AUTH_LDAP_SERVER", "ldap://example.test:389")
        config_setter("AUTH_LDAP_USE_TLS", True)
        config_setter("AUTH_LDAP_ALLOW_SELF_SIGNED", True)
        config_setter("AUTH_LDAP_BIND_USER", None)
        config_setter("AUTH_USER_REGISTRATION", False)

        class FakeTls:
            def __init__(self, **kwargs):
                self.kwargs = kwargs

        class FakeServer:
            def __init__(self, *args, **kwargs):
                pass

        class FakeConn:
            def __init__(self, *a, **k):
                pass

            def __enter__(self):
                return self

            def __exit__(self, *a):
                pass

            def rebind(self, *a, **k):
                return False

        fake_ldap3 = MagicMock()
        fake_ldap3.Tls = FakeTls
        fake_ldap3.Server = FakeServer
        fake_ldap3.Connection = FakeConn

        class _LDAPBindError(Exception):
            pass

        class _LDAPException(Exception):
            pass

        fake_ldap3.core.exceptions.LDAPBindError = _LDAPBindError
        fake_ldap3.core.exceptions.LDAPException = _LDAPException

        original_modules = {}
        for name in ("ldap3", "ldap3.core", "ldap3.core.exceptions"):
            original_modules[name] = sys.modules.get(name)
        sys.modules["ldap3"] = fake_ldap3
        sys.modules["ldap3.core"] = fake_ldap3.core
        sys.modules["ldap3.core.exceptions"] = fake_ldap3.core.exceptions

        try:
            creds = MagicMock(username="x", password="y")
            mgr = UserManager.__new__(UserManager)
            mgr.get_by_username = AsyncMock(side_effect=Exception("not found"))
            mgr.password_helper = MagicMock(hash=lambda p: "hashed")
            try:
                result = await UserManager.authenticate_ldap(mgr, creds)
                assert result is None
            except Exception:
                pass
        finally:
            for name, mod in original_modules.items():
                if mod is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = mod
