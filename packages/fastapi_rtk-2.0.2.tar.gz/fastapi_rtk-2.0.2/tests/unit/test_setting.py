import pytest

from fastapi_rtk.const import (
    DEFAULT_ADMIN_ROLE,
    DEFAULT_API_MAX_PAGE_SIZE,
    DEFAULT_API_PAGE_SIZE,
    DEFAULT_LANG_FOLDER,
    DEFAULT_LANGUAGES,
    DEFAULT_LICENSE_FOLDER,
    DEFAULT_PROFILER_FOLDER,
    DEFAULT_PUBLIC_ROLE,
    DEFAULT_STATIC_FOLDER,
    DEFAULT_TEMPLATE_FOLDER,
    DEFAULT_TRANSLATIONS_KEY,
    AuthType,
)
from fastapi_rtk.exceptions import FastAPIReactToolkitException
from fastapi_rtk.setting import Setting, _Setting


class TestSettingSingleton:
    def test_setting_is_instance(self):
        assert isinstance(Setting, _Setting)


class TestGeneralDefaults:
    def test_app_name_default(self, config_setter):
        config_setter("APP_NAME", None)
        # Property uses default
        config_setter("APP_NAME", "FastAPI React Toolkit")
        assert Setting.APP_NAME == "FastAPI React Toolkit"

    def test_app_name_from_config(self, config_setter):
        config_setter("APP_NAME", "MyApp")
        assert Setting.APP_NAME == "MyApp"

    def test_api_page_size_default(self):
        # Without config -> default
        assert Setting.API_PAGE_SIZE == DEFAULT_API_PAGE_SIZE

    def test_api_page_size_fab_fallback(self, config_setter):
        config_setter("FAB_API_PAGE_SIZE", 50)
        assert Setting.API_PAGE_SIZE == 50

    def test_api_page_size_main_overrides_fab(self, config_setter):
        config_setter("FAB_API_PAGE_SIZE", 50)
        config_setter("API_PAGE_SIZE", 100)
        assert Setting.API_PAGE_SIZE == 100

    def test_api_max_page_size(self, config_setter):
        config_setter("API_MAX_PAGE_SIZE", 200)
        assert Setting.API_MAX_PAGE_SIZE == 200

    def test_api_max_page_size_default(self):
        assert Setting.API_MAX_PAGE_SIZE == DEFAULT_API_MAX_PAGE_SIZE

    def test_text_filter_separator_default(self):
        assert Setting.TEXT_FILTER_SEPARATOR == ";"

    def test_debug_default_false(self):
        assert Setting.DEBUG is False

    def test_debug_from_config(self, config_setter):
        config_setter("DEBUG", True)
        assert Setting.DEBUG is True

    def test_template_context_empty_default(self):
        assert Setting.TEMPLATE_CONTEXT == {}

    def test_static_folder_default(self):
        assert Setting.STATIC_FOLDER == DEFAULT_STATIC_FOLDER

    def test_lang_folder_default(self):
        assert Setting.LANG_FOLDER == DEFAULT_LANG_FOLDER


class TestRoles:
    def test_roles_empty_when_unset(self, config_setter):
        # Pop both keys to simulate unset
        from fastapi_rtk.globals import g

        g.config.pop("ROLES", None)
        g.config.pop("FAB_ROLES", None)
        assert Setting.ROLES == {}

    def test_roles_from_config(self, config_setter):
        config_setter("ROLES", {"admin": []})
        assert Setting.ROLES == {"admin": []}

    def test_fab_roles_fallback(self, config_setter):
        from fastapi_rtk.globals import g

        g.config.pop("ROLES", None)
        config_setter("FAB_ROLES", {"old": []})
        assert Setting.ROLES == {"old": []}


class TestImageDefaults:
    def test_default_extensions(self):
        assert "png" in Setting.IMG_ALLOWED_EXTENSIONS
        assert "jpg" in Setting.IMG_ALLOWED_EXTENSIONS

    def test_custom_extensions(self, config_setter):
        config_setter("IMG_ALLOWED_EXTENSIONS", ["webp"])
        assert Setting.IMG_ALLOWED_EXTENSIONS == ["webp"]

    def test_img_mime_types_default(self):
        assert Setting.IMG_MIME_TYPES == ["image/*"]

    def test_img_max_size_falls_back_to_file_max_size(self, config_setter):
        config_setter("FILE_MAX_SIZE", 1024)
        assert Setting.IMG_MAX_SIZE == 1024


class TestLanguages:
    def test_default_languages(self):
        assert Setting.LANGUAGES == DEFAULT_LANGUAGES

    def test_translations_key_default(self):
        assert Setting.TRANSLATIONS_KEY == DEFAULT_TRANSLATIONS_KEY


class TestAuthRoles:
    def test_default_admin_role(self):
        assert Setting.AUTH_ROLE_ADMIN == DEFAULT_ADMIN_ROLE

    def test_default_public_role(self):
        assert Setting.AUTH_ROLE_PUBLIC == DEFAULT_PUBLIC_ROLE


class TestAuthLDAP:
    def test_auth_type_ldap_requires_server(self, config_setter):
        config_setter("AUTH_TYPE", AuthType.LDAP)
        with pytest.raises(FastAPIReactToolkitException, match="AUTH_LDAP_SERVER"):
            Setting.AUTH_TYPE

    def test_auth_type_ldap_with_server_ok(self, config_setter):
        config_setter("AUTH_TYPE", AuthType.LDAP)
        config_setter("AUTH_LDAP_SERVER", "ldap://x")
        assert Setting.AUTH_TYPE == AuthType.LDAP

    def test_ldap_bind_user_requires_search(self, config_setter):
        config_setter("AUTH_LDAP_BIND_USER", "user")
        with pytest.raises(FastAPIReactToolkitException, match="AUTH_LDAP_SEARCH"):
            Setting.AUTH_LDAP_BIND_USER

    def test_ldap_bind_user_with_search_ok(self, config_setter):
        config_setter("AUTH_LDAP_BIND_USER", "user")
        config_setter("AUTH_LDAP_SEARCH", "ou=people")
        assert Setting.AUTH_LDAP_BIND_USER == "user"

    def test_ldap_uid_field_default(self):
        assert Setting.AUTH_LDAP_UID_FIELD == "uid"

    def test_ldap_use_tls_default(self):
        assert Setting.AUTH_LDAP_USE_TLS is False


class TestSecweb:
    def test_secweb_enabled_default(self):
        assert Setting.SECWEB_ENABLED is False

    def test_secweb_patch_docs_default(self):
        assert Setting.SECWEB_PATCH_DOCS is True

    def test_secweb_patch_redoc_default(self):
        assert Setting.SECWEB_PATCH_REDOC is True


class TestProfiler:
    def test_disabled_default(self):
        assert Setting.PROFILER_ENABLED is False

    def test_default_type(self):
        assert Setting.PROFILER_TYPE == "html"

    def test_default_renderer(self):
        assert Setting.PROFILER_RENDERER == "HTMLRenderer"

    def test_default_folder(self):
        assert Setting.PROFILER_FOLDER == DEFAULT_PROFILER_FOLDER


class TestOAuth:
    def test_oauth_clients_empty_default(self):
        assert Setting.OAUTH_CLIENTS == []

    def test_oauth_clients_legacy_oauth_providers(self, config_setter):
        from fastapi_rtk.globals import g

        g.config.pop("OAUTH_CLIENTS", None)
        config_setter("OAUTH_PROVIDERS", [{"id": "g"}])
        assert Setting.OAUTH_CLIENTS == [{"id": "g"}]


class TestPaths:
    def test_template_folder_default(self):
        assert Setting.TEMPLATE_FOLDER == DEFAULT_TEMPLATE_FOLDER

    def test_license_folder_default(self):
        assert Setting.LICENSE_FOLDER == DEFAULT_LICENSE_FOLDER


class TestSimplePassthroughs:
    @pytest.mark.parametrize(
        "attr,key,value",
        [
            ("APP_SUMMARY", "APP_SUMMARY", "summary"),
            ("APP_DESCRIPTION", "APP_DESCRIPTION", "desc"),
            ("APP_VERSION", "APP_VERSION", "1.0"),
            ("APP_OPENAPI_URL", "APP_OPENAPI_URL", "/openapi.json"),
            ("BASE_PATH", "BASE_PATH", "/api"),
            ("UPLOAD_FOLDER", "UPLOAD_FOLDER", "/tmp/uploads"),
            ("IMG_UPLOAD_FOLDER", "IMG_UPLOAD_FOLDER", "/tmp/img"),
            ("FILE_MANAGER", "FILE_MANAGER", object()),
            ("IMAGE_MANAGER", "IMAGE_MANAGER", object()),
            ("FILE_ALLOWED_EXTENSIONS", "FILE_ALLOWED_EXTENSIONS", ["txt"]),
            ("FILE_MAX_SIZE", "FILE_MAX_SIZE", 1000),
            ("TRANSLATIONS", "TRANSLATIONS", {"de": {}}),
            ("SQLALCHEMY_DATABASE_URI", "SQLALCHEMY_DATABASE_URI", "sqlite:///x"),
            ("SQLALCHEMY_BINDS", "SQLALCHEMY_BINDS", {"a": "sqlite:///"}),
            ("AUTH_USER_REGISTRATION", "AUTH_USER_REGISTRATION", True),
            ("OAUTH_REDIRECT_URI", "OAUTH_REDIRECT_URI", "https://app/cb"),
            ("PASSWORD_HELPER", "PASSWORD_HELPER", "p"),
            ("SECRET_KEY", "SECRET_KEY", "secret"),
            ("USER_MANAGER", "USER_MANAGER", "um"),
            ("COOKIE_NAME", "COOKIE_NAME", "auth"),
            ("BEARER_TOKEN_URL", "BEARER_TOKEN_URL", "/token"),
            ("COOKIE_CONFIG", "COOKIE_CONFIG", {"x": 1}),
            ("BEARER_CONFIG", "BEARER_CONFIG", {"x": 2}),
            ("COOKIE_STRATEGY_CONFIG", "COOKIE_STRATEGY_CONFIG", {"x": 3}),
            ("BEARER_STRATEGY_CONFIG", "BEARER_STRATEGY_CONFIG", {"x": 4}),
            ("COOKIE_TRANSPORT", "COOKIE_TRANSPORT", "ct"),
            ("BEARER_TRANSPORT", "BEARER_TRANSPORT", "bt"),
            ("COOKIE_BACKEND", "COOKIE_BACKEND", "cb"),
            ("BEARER_BACKEND", "BEARER_BACKEND", "bb"),
            ("AUTHENTICATOR", "AUTHENTICATOR", "auth"),
            ("FASTAPI_USERS", "FASTAPI_USERS", "fu"),
            ("STRATEGY_BACKEND", "STRATEGY_BACKEND", "JWT"),
            ("COOKIE_MAX_AGE", "COOKIE_MAX_AGE", 60),
            ("COOKIE_PATH", "COOKIE_PATH", "/"),
            ("COOKIE_DOMAIN", "COOKIE_DOMAIN", "x.com"),
            ("COOKIE_SECURE", "COOKIE_SECURE", True),
            ("COOKIE_HTTPONLY", "COOKIE_HTTPONLY", True),
            ("COOKIE_SAMESITE", "COOKIE_SAMESITE", "lax"),
            ("COOKIE_LIFETIME_SECONDS", "COOKIE_LIFETIME_SECONDS", 3600),
            ("COOKIE_TOKEN_AUDIENCE", "COOKIE_TOKEN_AUDIENCE", ["a"]),
            ("COOKIE_ALGORITHM", "COOKIE_ALGORITHM", "HS256"),
            ("BEARER_LIFETIME_SECONDS", "BEARER_LIFETIME_SECONDS", 1800),
            ("BEARER_TOKEN_AUDIENCE", "BEARER_TOKEN_AUDIENCE", ["b"]),
            ("BEARER_ALGORITHM", "BEARER_ALGORITHM", "RS256"),
            ("LICENSE_SHOW_METADATA", "LICENSE_SHOW_METADATA", True),
            ("STATIC_FOLDER", "STATIC_FOLDER", "/static"),
            ("FAB_REACT_CONFIG", "FAB_REACT_CONFIG", {"k": "v"}),
            ("TEMPLATE_CONTEXT", "TEMPLATE_CONTEXT", {"k": "v"}),
            ("FILE_MIME_TYPES", "FILE_MIME_TYPES", ["text/plain"]),
            ("IMG_ALLOWED_EXTENSIONS", "IMG_ALLOWED_EXTENSIONS", ["png"]),
            ("IMG_MIME_TYPES", "IMG_MIME_TYPES", ["image/png"]),
            ("IMG_MAX_SIZE", "IMG_MAX_SIZE", 99),
            ("LANGUAGES", "LANGUAGES", "en,de"),
            ("TRANSLATIONS_KEY", "TRANSLATIONS_KEY", "T_KEY"),
            ("BABEL_OPTIONS", "BABEL_OPTIONS", {"x": 1}),
            ("SECWEB_PARAMS", "SECWEB_PARAMS", {"a": 1}),
            ("SECWEB_DEEP_MERGE_PARAMS", "SECWEB_DEEP_MERGE_PARAMS", {"b": 1}),
            ("AUTH_LDAP_TLS_DEMAND", "AUTH_LDAP_TLS_DEMAND", True),
            ("AUTH_LDAP_TLS_KEYFILE", "AUTH_LDAP_TLS_KEYFILE", "/k.pem"),
            ("AUTH_LDAP_TLS_CERTFILE", "AUTH_LDAP_TLS_CERTFILE", "/c.pem"),
            ("AUTH_LDAP_TLS_CACERTDIR", "AUTH_LDAP_TLS_CACERTDIR", "/etc/ssl"),
            ("AUTH_LDAP_TLS_CACERTFILE", "AUTH_LDAP_TLS_CACERTFILE", "/ca.pem"),
            ("CONFIG_ENABLE_DEEP_MERGE", "CONFIG_ENABLE_DEEP_MERGE", True),
            ("CONFIG_DEEP_MERGE_WHITELIST", "CONFIG_DEEP_MERGE_WHITELIST", ["x"]),
        ],
    )
    def test_passthrough(self, attr, key, value, config_setter):
        config_setter(key, value)
        assert getattr(Setting, attr) == value
