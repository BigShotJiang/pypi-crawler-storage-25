import json
import os

import pytest

from fastapi_rtk.config import Config, ConfigKeyword


@pytest.fixture
def cfg():
    return Config()


class TestBasicDictBehavior:
    def test_is_dict_subclass(self):
        assert isinstance(Config(), dict)

    def test_setitem_getitem(self, cfg):
        cfg["KEY"] = "value"
        assert cfg["KEY"] == "value"

    def test_repr_includes_class_and_dict(self, cfg):
        cfg["X"] = 1
        r = repr(cfg)
        assert "Config" in r
        assert "X" in r


class TestFromMapping:
    def test_uppercase_only(self, cfg):
        cfg.from_mapping({"UP": 1, "low": 2})
        assert "UP" in cfg
        assert "low" not in cfg

    def test_kwargs_merged(self, cfg):
        cfg.from_mapping(BASE=1, EXTRA=2)
        assert cfg["BASE"] == 1
        assert cfg["EXTRA"] == 2

    def test_returns_true(self, cfg):
        assert cfg.from_mapping(X=1) is True

    def test_runs_callbacks(self, cfg):
        called = []
        cfg.add_callback(lambda: called.append(1))
        cfg.from_mapping(X=1)
        assert called == [1]


class TestFromObject:
    def test_loads_uppercase_attrs_from_object(self, cfg):
        class C:
            UPPER = 1
            lower = 2

        cfg.from_object(C)
        assert cfg["UPPER"] == 1
        assert "lower" not in cfg

    def test_loads_from_string_path(self, cfg):
        cfg.from_object("os.path")
        # os.path module-level uppercase attrs (e.g. ALTSEP)
        assert any(k.isupper() for k in cfg)


class TestFromPyFile:
    def test_loads_from_file(self, cfg, tmp_path):
        f = tmp_path / "cfg.py"
        f.write_text("FOO = 'bar'\nNUM = 42\n")
        assert cfg.from_pyfile(str(f)) is True
        assert cfg["FOO"] == "bar"
        assert cfg["NUM"] == 42

    def test_silent_returns_false_for_missing_file(self, cfg, tmp_path):
        f = tmp_path / "missing.py"
        assert cfg.from_pyfile(str(f), silent=True) is False

    def test_raises_when_not_silent_and_missing(self, cfg, tmp_path):
        f = tmp_path / "missing.py"
        with pytest.raises(OSError):
            cfg.from_pyfile(str(f))


class TestFromEnvvar:
    def test_loads_from_env(self, cfg, tmp_path, monkeypatch):
        f = tmp_path / "cfg.py"
        f.write_text("X = 1\n")
        monkeypatch.setenv("MY_CFG", str(f))
        assert cfg.from_envvar("MY_CFG") is True
        assert cfg["X"] == 1

    def test_silent_returns_false(self, cfg, monkeypatch):
        monkeypatch.delenv("MISSING_VAR", raising=False)
        assert cfg.from_envvar("MISSING_VAR", silent=True) is False

    def test_raises_when_not_set(self, cfg, monkeypatch):
        monkeypatch.delenv("UNSET_VAR", raising=False)
        with pytest.raises(RuntimeError, match="not set"):
            cfg.from_envvar("UNSET_VAR")


class TestFromPrefixedEnv:
    def test_loads_prefixed_keys(self, cfg, monkeypatch):
        monkeypatch.setenv("FASTAPI_FOO", "bar")
        monkeypatch.setenv("FASTAPI_NUM", "42")
        cfg.from_prefixed_env()
        assert cfg["FOO"] == "bar"
        assert cfg["NUM"] == 42  # JSON-parsed

    def test_loads_with_custom_prefix(self, cfg, monkeypatch):
        monkeypatch.setenv("MYAPP_KEY", "v")
        cfg.from_prefixed_env(prefix="MYAPP")
        assert cfg["KEY"] == "v"

    def test_nested_keys_via_double_underscore(self, cfg, monkeypatch):
        monkeypatch.setenv("FASTAPI_DB__HOST", "localhost")
        cfg.from_prefixed_env()
        assert cfg["DB"]["HOST"] == "localhost"

    def test_invalid_json_kept_as_string(self, cfg, monkeypatch):
        monkeypatch.setenv("FASTAPI_X", "not-json")
        cfg.from_prefixed_env()
        assert cfg["X"] == "not-json"


class TestFromFile:
    def test_loads_json(self, cfg, tmp_path):
        f = tmp_path / "cfg.json"
        f.write_text('{"X": 1, "Y": "str"}')
        assert cfg.from_file(str(f), load=json.load) is True
        assert cfg["X"] == 1
        assert cfg["Y"] == "str"

    def test_silent_missing(self, cfg):
        assert cfg.from_file("/nonexistent/file", load=json.load, silent=True) is False

    def test_raises_when_missing(self, cfg):
        with pytest.raises(OSError):
            cfg.from_file("/nonexistent/file", load=json.load)


class TestGetNamespace:
    def test_returns_subset_with_lowercase_trim(self, cfg):
        cfg["IMG_PATH"] = "p"
        cfg["IMG_TYPE"] = "t"
        cfg["OTHER"] = "x"
        ns = cfg.get_namespace("IMG_")
        assert ns == {"path": "p", "type": "t"}

    def test_keep_namespace(self, cfg):
        cfg["IMG_PATH"] = "p"
        ns = cfg.get_namespace("IMG_", trim_namespace=False)
        assert ns == {"img_path": "p"}

    def test_no_lowercase(self, cfg):
        cfg["IMG_PATH"] = "p"
        ns = cfg.get_namespace("IMG_", lowercase=False)
        assert ns == {"PATH": "p"}


class TestDeepMerge:
    def test_disabled_by_default(self, cfg):
        cfg["X"] = {"a": 1}
        cfg["X"] = {"b": 2}
        assert cfg["X"] == {"b": 2}

    def test_enabled_merges_dicts(self, cfg):
        cfg["CONFIG_ENABLE_DEEP_MERGE"] = True
        cfg["X"] = {"a": 1}
        cfg["X"] = {"b": 2}
        assert cfg["X"] == {"a": 1, "b": 2}

    def test_whitelist_filters_keys(self, cfg):
        cfg["CONFIG_ENABLE_DEEP_MERGE"] = True
        cfg["CONFIG_DEEP_MERGE_WHITELIST"] = ["MERGED"]
        cfg["MERGED"] = {"a": 1}
        cfg["MERGED"] = {"b": 2}
        cfg["UNMERGED"] = {"a": 1}
        cfg["UNMERGED"] = {"b": 2}
        assert cfg["MERGED"] == {"a": 1, "b": 2}
        assert cfg["UNMERGED"] == {"b": 2}


class TestConfigKeyword:
    def test_check_key_value_accepts_correct_type(self):
        ConfigKeyword.check_key_value("CONFIG_ENABLE_DEEP_MERGE", True)

    def test_check_key_value_rejects_wrong_type(self):
        with pytest.raises(TypeError, match="Expected type"):
            ConfigKeyword.check_key_value("CONFIG_ENABLE_DEEP_MERGE", "not-bool")

    def test_unrelated_key_is_no_op(self):
        ConfigKeyword.check_key_value("RANDOM", "anything")  # no exception


class TestCallbacks:
    def test_callbacks_run_on_from_object(self, cfg):
        called = []
        cfg.add_callback(lambda: called.append("ran"))

        class C:
            FOO = 1

        cfg.from_object(C)
        assert called == ["ran"]

    def test_callbacks_run_on_from_prefixed_env(self, cfg, monkeypatch):
        called = []
        cfg.add_callback(lambda: called.append("ran"))
        monkeypatch.setenv("FASTAPI_X", "1")
        cfg.from_prefixed_env()
        assert called == ["ran"]

    def test_no_callbacks_safe(self, cfg):
        # Without any add_callback, _run_callbacks is no-op
        cfg.from_mapping(X=1)  # should not raise
