from unittest.mock import MagicMock

import pytest
from fastapi import FastAPI

from fastapi_rtk.middlewares import (
    csp_dict_to_string,
    csp_string_to_dict,
    get_swagger_ui_script_hash,
    patch_csp_string,
)


class TestCspStringToDict:
    def test_empty(self):
        assert csp_string_to_dict("") == {}

    def test_basic_directives(self):
        d = csp_string_to_dict("default-src 'self'; img-src https: data:;")
        assert d == {"default-src": ["'self'"], "img-src": ["https:", "data:"]}

    def test_directive_without_values(self):
        d = csp_string_to_dict("upgrade-insecure-requests;")
        assert d == {"upgrade-insecure-requests": []}


class TestCspDictToString:
    def test_basic_dict(self):
        s = csp_dict_to_string({"default-src": ["'self'"]})
        assert "default-src 'self'" in s
        assert s.endswith(";")

    def test_directive_without_values(self):
        s = csp_dict_to_string({"upgrade-insecure-requests": []})
        assert "upgrade-insecure-requests" in s

    def test_round_trip(self):
        original = "default-src 'self'; img-src https:;"
        d = csp_string_to_dict(original)
        s = csp_dict_to_string(d)
        # Round-trip should yield equivalent dict
        assert csp_string_to_dict(s) == d


class TestPatchCspString:
    def test_appends_to_existing_directive(self):
        result = patch_csp_string("img-src 'self';", {"img-src": ["data:"]})
        d = csp_string_to_dict(result)
        assert "data:" in d["img-src"]
        assert "'self'" in d["img-src"]

    def test_adds_new_directive(self):
        result = patch_csp_string("img-src 'self';", {"script-src": ["'self'"]})
        d = csp_string_to_dict(result)
        assert d["script-src"] == ["'self'"]

    def test_override_replaces(self):
        result = patch_csp_string(
            "style-src 'self' 'unsafe-inline';",
            {"style-src": ["https:"]},
            override=["style-src"],
        )
        d = csp_string_to_dict(result)
        assert d["style-src"] == ["https:"]

    def test_none_value_removes_directive(self):
        result = patch_csp_string(
            "default-src 'self'; img-src 'self';",
            {"img-src": None},
        )
        d = csp_string_to_dict(result)
        assert "img-src" not in d
        assert "default-src" in d


class TestGetSwaggerUIScriptHash:
    def test_returns_sha256_hash_string(self):
        app = FastAPI()
        result = get_swagger_ui_script_hash(app)
        assert result.startswith("'sha256-")
        assert result.endswith("'")

    def test_deterministic(self):
        app = FastAPI()
        h1 = get_swagger_ui_script_hash(app)
        h2 = get_swagger_ui_script_hash(app)
        assert h1 == h2

    def test_raises_when_script_missing(self, monkeypatch):
        from fastapi_rtk import middlewares

        class FakeBody:
            def decode(self, _enc):
                # HTML with no <script> blocks at all
                return "<html><body>no scripts</body></html>"

        class FakeSwagger:
            body = FakeBody()

        monkeypatch.setattr(
            middlewares, "get_swagger_ui_html", lambda **kw: FakeSwagger()
        )

        app = FastAPI()
        with pytest.raises(ValueError, match="No SwaggerUIBundle"):
            get_swagger_ui_script_hash(app)


class TestMiddlewareConstructors:
    def test_profiler_middleware_creates_folder(self, tmp_path, config_setter):
        from fastapi_rtk.middlewares import ProfilerMiddleware

        config_setter("PROFILER_FOLDER", str(tmp_path / "prof"))

        async def stub_app(scope, receive, send):
            pass

        ProfilerMiddleware(stub_app)
        assert (tmp_path / "prof").exists()

    def test_secweb_patch_docs_middleware_constructs(self):
        from fastapi_rtk.middlewares import SecWebPatchDocsMiddleware

        async def stub_app(scope, receive, send):
            pass

        SecWebPatchDocsMiddleware(stub_app, FastAPI())

    def test_secweb_patch_redoc_middleware_constructs(self):
        from fastapi_rtk.middlewares import SecWebPatchReDocMiddleware

        async def stub_app(scope, receive, send):
            pass

        SecWebPatchReDocMiddleware(stub_app)


class _FakeUrl:
    def __init__(self, path):
        self.path = path


class _FakeApp:
    def __init__(self, *, docs_url="/docs", redoc_url="/redoc"):
        self.docs_url = docs_url
        self.redoc_url = redoc_url


class _FakeRequest:
    def __init__(self, path, *, app=None, method="GET"):
        self.url = _FakeUrl(path)
        self.app = app or _FakeApp()
        self.method = method


class _FakeResponse:
    def __init__(self, headers=None):
        self.headers = headers or {}


@pytest.mark.asyncio
class TestSecWebDocsDispatch:
    async def test_patches_csp_on_docs_path(self):
        from fastapi_rtk.middlewares import (
            get_sec_web_patch_docs_middleware_dispatch,
        )

        dispatch = get_sec_web_patch_docs_middleware_dispatch("'sha256-x'")
        resp = _FakeResponse(headers={"Content-Security-Policy": "img-src 'self';"})

        async def call_next(_req):
            return resp

        out = await dispatch(_FakeRequest("/docs"), call_next)
        assert "https://fastapi.tiangolo.com" in out.headers["Content-Security-Policy"]
        assert "'sha256-x'" in out.headers["Content-Security-Policy"]

    async def test_skips_patching_for_non_docs_path(self):
        from fastapi_rtk.middlewares import (
            get_sec_web_patch_docs_middleware_dispatch,
        )

        dispatch = get_sec_web_patch_docs_middleware_dispatch("'sha256-x'")
        original_csp = "img-src 'self';"
        resp = _FakeResponse(headers={"Content-Security-Policy": original_csp})

        async def call_next(_req):
            return resp

        out = await dispatch(_FakeRequest("/other"), call_next)
        assert out.headers["Content-Security-Policy"] == original_csp

    async def test_no_csp_header_unchanged(self):
        from fastapi_rtk.middlewares import (
            get_sec_web_patch_docs_middleware_dispatch,
        )

        dispatch = get_sec_web_patch_docs_middleware_dispatch("'sha256-x'")
        resp = _FakeResponse(headers={})

        async def call_next(_req):
            return resp

        out = await dispatch(_FakeRequest("/docs"), call_next)
        assert "Content-Security-Policy" not in out.headers


@pytest.mark.asyncio
class TestProfilerDispatch:
    async def test_dispatch_uses_pyinstrument(
        self, tmp_path, config_setter, global_setter
    ):
        from unittest.mock import MagicMock

        from fastapi_rtk.middlewares import profiler_middleware_dispatch

        config_setter("PROFILER_TYPE", "html")
        config_setter("PROFILER_RENDERER", "HTMLRenderer")
        config_setter("PROFILER_FOLDER", str(tmp_path / "prof"))

        # Build a fake pyinstrument module + renderer cache so the dispatch
        # exercises the full profile flow without importing real pyinstrument.
        fake_renderer_cls = MagicMock(return_value=MagicMock())
        fake_profiler = MagicMock()
        fake_profiler.__enter__ = MagicMock(return_value=fake_profiler)
        fake_profiler.__exit__ = MagicMock(return_value=False)
        fake_profiler.output = MagicMock(return_value="<html>profile</html>")

        fake_pyinst = MagicMock()
        fake_pyinst.renderers.HTMLRenderer = fake_renderer_cls
        fake_pyinst.Profiler = MagicMock(return_value=fake_profiler)

        global_setter("pyinstrument", fake_pyinst)
        global_setter("renderer_cache", None)

        async def call_next(_req):
            return _FakeResponse()

        out = await profiler_middleware_dispatch(_FakeRequest("/x"), call_next)
        assert out is not None
        # Profile dump landed in <PROFILER_FOLDER>/<path>/<method>.<type>
        target = tmp_path / "prof" / "x" / "GET.html"
        assert target.exists()
        assert "<html>profile</html>" in target.read_text()


@pytest.mark.asyncio
class TestSecWebRedocDispatch:
    async def test_patches_csp_on_redoc_path(self):
        from fastapi_rtk.middlewares import sec_web_patch_redoc_middleware_dispatch

        resp = _FakeResponse(
            headers={"Content-Security-Policy": "style-src 'self';"}
        )

        async def call_next(_req):
            return resp

        out = await sec_web_patch_redoc_middleware_dispatch(
            _FakeRequest("/redoc"), call_next
        )
        csp = out.headers["Content-Security-Policy"]
        assert "redoc.standalone.js" in csp
        # style-src override -> only the patch values
        assert "'unsafe-inline'" in csp

    async def test_skips_patching_for_non_redoc_path(self):
        from fastapi_rtk.middlewares import sec_web_patch_redoc_middleware_dispatch

        original = "style-src 'self';"
        resp = _FakeResponse(headers={"Content-Security-Policy": original})

        async def call_next(_req):
            return resp

        out = await sec_web_patch_redoc_middleware_dispatch(
            _FakeRequest("/notredoc"), call_next
        )
        assert out.headers["Content-Security-Policy"] == original
