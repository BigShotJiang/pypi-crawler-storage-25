"""Tier 11 - tests for fastapi_rtk.db (DatabaseSessionManager + UserDatabase).

Uses sqlite-in-memory + StaticPool. Driver `sqlite+aiosqlite://` → AsyncEngine.
The `db` module-level singleton is reset in fixtures so other tests aren't
affected.
"""

from datetime import datetime
from types import SimpleNamespace

import pytest
import pytest_asyncio
import sqlalchemy
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession
from sqlalchemy.orm import Session
from sqlalchemy.pool import StaticPool

from fastapi_rtk.backends.sqla.model import Model
from fastapi_rtk.db import (
    DatabaseSessionManager,
    UserDatabase,
    get_scoped_session,
    get_session_factory,
    get_user_db,
)
from fastapi_rtk.exceptions import FastAPIReactToolkitException
from fastapi_rtk.security.sqla.models import OAuthAccount, User


@pytest_asyncio.fixture
async def async_dbm():
    dbm = DatabaseSessionManager()
    dbm.init_db("sqlite+aiosqlite:///:memory:")
    yield dbm
    await dbm.close()


@pytest_asyncio.fixture
async def sync_dbm():
    dbm = DatabaseSessionManager()
    dbm.init_db("sqlite:///:memory:")
    yield dbm
    await dbm.close()


@pytest_asyncio.fixture
async def dbm_with_bind():
    dbm = DatabaseSessionManager()
    dbm.init_db("sqlite+aiosqlite:///:memory:", binds={"audit": "sqlite:///:memory:"})
    yield dbm
    await dbm.close()


@pytest.mark.asyncio
class TestInit:
    async def test_init_creates_async_engine(self, async_dbm):
        assert isinstance(async_dbm.get_engine(), AsyncEngine)

    async def test_init_creates_sync_engine(self, sync_dbm):
        assert isinstance(sync_dbm.get_engine(), sqlalchemy.engine.Engine)

    async def test_get_engine_unknown_bind_returns_none(self, async_dbm):
        assert async_dbm.get_engine("missing") is None

    async def test_init_with_binds(self, dbm_with_bind):
        assert dbm_with_bind.get_engine() is not None
        assert dbm_with_bind.get_engine("audit") is not None


class TestGetMetadata:
    def test_default_returns_root_metadata(self):
        from fastapi_rtk.backends.sqla.model import metadata

        dbm = DatabaseSessionManager()
        assert dbm.get_metadata() is metadata

    def test_bind_creates_new_metadata_if_absent(self):
        from fastapi_rtk.backends.sqla.model import metadatas

        dbm = DatabaseSessionManager()
        new_bind = "tier11_db_bind_xyz"
        metadatas.pop(new_bind, None)
        md = dbm.get_metadata(new_bind)
        assert md is not None
        assert metadatas[new_bind] is md
        metadatas.pop(new_bind, None)


@pytest.mark.asyncio
class TestSession:
    async def test_session_yields_async_session(self, async_dbm):
        async with async_dbm.session() as s:
            assert isinstance(s, AsyncSession)

    async def test_session_yields_sync_session(self, sync_dbm):
        async with sync_dbm.session() as s:
            assert isinstance(s, Session)

    async def test_session_context_var(self, async_dbm):
        async with async_dbm.session() as s:
            assert async_dbm.current_session is s

    async def test_session_uninitialized_raises(self):
        dbm = DatabaseSessionManager()
        with pytest.raises(Exception, match="not initialized"):
            async with dbm.session():
                pass

    async def test_session_unknown_bind_raises(self, async_dbm):
        with pytest.raises(Exception, match="not initialized"):
            async with async_dbm.session(bind="nope"):
                pass

    async def test_session_default_metadata_key_treated_as_none(self, async_dbm):
        from fastapi_rtk.const import DEFAULT_METADATA_KEY

        async with async_dbm.session(bind=DEFAULT_METADATA_KEY) as s:
            assert isinstance(s, AsyncSession)

    async def test_session_rollback_on_exception(self, async_dbm):
        with pytest.raises(RuntimeError, match="boom"):
            async with async_dbm.session():
                raise RuntimeError("boom")


@pytest.mark.asyncio
class TestConnect:
    async def test_connect_yields_async_conn(self, async_dbm):
        async with async_dbm.connect() as c:
            assert c is not None

    async def test_connect_yields_sync_conn(self, sync_dbm):
        async with sync_dbm.connect() as c:
            assert c is not None

    async def test_connect_uninitialized_raises(self):
        dbm = DatabaseSessionManager()
        with pytest.raises(Exception, match="not initialized"):
            async with dbm.connect():
                pass

    async def test_connect_default_metadata_key(self, async_dbm):
        from fastapi_rtk.const import DEFAULT_METADATA_KEY

        async with async_dbm.connect(bind=DEFAULT_METADATA_KEY) as c:
            assert c is not None


@pytest.mark.asyncio
class TestScopedSession:
    async def test_scoped_session_yields(self, async_dbm):
        async with async_dbm.scoped_session() as s:
            assert s is not None

    async def test_scoped_session_uninitialized_raises(self):
        dbm = DatabaseSessionManager()
        with pytest.raises(Exception, match="not initialized"):
            async with dbm.scoped_session():
                pass


@pytest.mark.asyncio
class TestCreateDropAll:
    async def test_create_all_unknown_bind_raises(self, async_dbm):
        with pytest.raises(FastAPIReactToolkitException, match="not found"):
            await async_dbm.create_all(binds="missing_bind_xyz")

    async def test_connect_rolls_back_on_exception(self, async_dbm):
        # Async engine: raising inside `async with db.connect()` should
        # trigger the rollback branch at lines 352-357.
        with pytest.raises(ValueError, match="boom"):
            async with async_dbm.connect():
                raise ValueError("boom")

    async def test_connect_unknown_bind_raises_with_bind_in_msg(self, async_dbm):
        # Line 345: bind name appears in error message
        with pytest.raises(Exception, match="not initialized.*missing_bind"):
            async with async_dbm.connect(bind="missing_bind"):
                pass

    async def test_create_all_with_default_bind_branch(self, async_dbm, monkeypatch):
        # binds == DEFAULT_METADATA_KEY -> append default metadata at line 469.
        # Stub _create_all to avoid hitting JSONB tables registered by the audit
        # tier in the shared metadata.
        from fastapi_rtk.const import DEFAULT_METADATA_KEY

        called = []

        async def fake_create(self, conn, md, **kw):
            called.append((md, kw))

        monkeypatch.setattr(
            type(async_dbm), "_create_all", fake_create, raising=True
        )
        await async_dbm.create_all(binds=DEFAULT_METADATA_KEY)
        assert len(called) >= 1

    async def test_create_all_with_none_bind_branch(self, async_dbm, monkeypatch):
        called = []

        async def fake_create(self, conn, md, **kw):
            called.append((md, kw))

        monkeypatch.setattr(
            type(async_dbm), "_create_all", fake_create, raising=True
        )
        await async_dbm.create_all(binds=None)
        assert len(called) >= 1

    async def test_create_all_with_explicit_default_in_list(
        self, async_dbm, monkeypatch
    ):
        # Line 478: bind == DEFAULT_METADATA_KEY in list path
        from fastapi_rtk.const import DEFAULT_METADATA_KEY

        called = []

        async def fake_create(self, conn, md, **kw):
            called.append((md, kw))

        monkeypatch.setattr(
            type(async_dbm), "_create_all", fake_create, raising=True
        )
        await async_dbm.create_all(binds=[DEFAULT_METADATA_KEY])
        assert len(called) >= 1

    async def test_create_all_all_with_extra_bind(self, async_dbm, monkeypatch):
        # Line 471: binds == "all" extends with bind keys
        from sqlalchemy import MetaData

        from fastapi_rtk.backends.sqla.model import metadatas

        bind = "tier11_all_test_bind"
        metadatas[bind] = MetaData()
        async_dbm._engine_binds[bind] = async_dbm._init_engine(
            "sqlite+aiosqlite:///:memory:", {}
        )
        called = []

        async def fake_create(self, conn, md, **kw):
            called.append((md, kw))

        monkeypatch.setattr(
            type(async_dbm), "_create_all", fake_create, raising=True
        )
        try:
            await async_dbm.create_all(binds="all")
            assert len(called) >= 2  # default + extra bind
        finally:
            await async_dbm._engine_binds[bind].dispose()
            del async_dbm._engine_binds[bind]
            metadatas.pop(bind, None)


@pytest.mark.asyncio
class TestConnectErrorRollbackPaths:
    """Cover lines 355-367 - rollback inside connect() exception handler."""

    async def test_async_connect_rollback_on_exception(self, async_dbm):
        with pytest.raises(RuntimeError):
            async with async_dbm.connect() as conn:
                raise RuntimeError("force rollback")

    async def test_sync_connect_rollback_on_exception(self, sync_dbm):
        with pytest.raises(RuntimeError):
            async with sync_dbm.connect() as conn:
                raise RuntimeError("force rollback")


@pytest.mark.asyncio
class TestScopedSessionRollbackPath:
    """Cover lines 448-450 - scoped_session rollback on exception."""

    async def test_scoped_session_rollback_on_exception(self, async_dbm):
        with pytest.raises(RuntimeError):
            async with async_dbm.scoped_session() as session:
                raise RuntimeError("force scoped rollback")


class TestCreateAllSyncBranch:
    """Cover line 606 - _create_all sync branch (non-AsyncConnection)."""

    def test_sync_drop_via_metadata(self):
        import asyncio

        import sqlalchemy

        from fastapi_rtk.db import DatabaseSessionManager

        dbm = DatabaseSessionManager()
        dbm.init_db("sqlite:///:memory:")
        engine = dbm._engine
        meta = sqlalchemy.MetaData()
        sqlalchemy.Table(
            "tmp_drop_me",
            meta,
            sqlalchemy.Column("id", sqlalchemy.Integer, primary_key=True),
        )
        with engine.begin() as conn:
            meta.create_all(conn)

        async def runner():
            with engine.begin() as conn:
                await dbm._create_all(conn, meta, drop=True)

        asyncio.run(runner())
        engine.dispose()


@pytest.mark.asyncio
class TestScopedSessionBindError:
    async def test_scoped_session_unknown_bind_raises_with_bind_in_msg(self):
        from fastapi_rtk.db import DatabaseSessionManager

        dbm = DatabaseSessionManager()
        with pytest.raises(Exception, match="not initialized.*ghost_bind"):
            async with dbm.scoped_session(bind="ghost_bind"):
                pass


@pytest.mark.asyncio
class TestAutoloadTable:
    async def test_no_engine_runs_func_with_none(self):
        from fastapi_rtk.db import DatabaseSessionManager

        dbm = DatabaseSessionManager()
        called = {"conn": "sentinel"}

        def loader(conn):
            called["conn"] = conn
            return "result"

        result = await dbm.autoload_table(loader)
        assert result == "result"
        assert called["conn"] is None

    async def test_with_async_engine_runs_via_run_sync(self):
        from fastapi_rtk.db import DatabaseSessionManager

        dbm = DatabaseSessionManager()
        dbm.init_db("sqlite+aiosqlite:///:memory:")

        called = {"flag": False}

        def loader(conn):
            called["flag"] = True
            return "loaded"

        result = await dbm.autoload_table(loader)
        assert result == "loaded"
        assert called["flag"] is True
        # autoload_table closes the db on exit
        assert dbm._engine is None

    async def test_create_all_isolated_metadata(self, async_dbm):
        # Use a fresh bind so we don't trigger cross-test pollution from the
        # shared root metadata (other tiers register their own models there).
        from fastapi_rtk.backends.sqla.model import metadatas

        bind = "tier11_create_all_test"
        metadatas.pop(bind, None)
        async_dbm._engine_binds[bind] = async_dbm._init_engine(
            "sqlite+aiosqlite:///:memory:", {}
        )
        try:
            # Empty metadata - just smoke that the path runs.
            md = async_dbm.get_metadata(bind)
            await async_dbm.create_all(binds=bind)
            await async_dbm.drop_all(binds=bind)
        finally:
            await async_dbm._engine_binds[bind].dispose()
            del async_dbm._engine_binds[bind]
            metadatas.pop(bind, None)


@pytest.mark.asyncio
class TestSessionFactory:
    async def test_get_session_factory_yields(self, monkeypatch):
        import sys

        db_module = sys.modules["fastapi_rtk.db"]
        dbm = DatabaseSessionManager()
        dbm.init_db("sqlite+aiosqlite:///:memory:")
        monkeypatch.setattr(db_module, "db", dbm)

        gen = get_session_factory()()
        try:
            session = await gen.__anext__()
            assert isinstance(session, AsyncSession)
        finally:
            with pytest.raises(StopAsyncIteration):
                await gen.__anext__()
        await dbm.close()

    async def test_get_scoped_session_yields(self, monkeypatch):
        import sys

        db_module = sys.modules["fastapi_rtk.db"]
        dbm = DatabaseSessionManager()
        dbm.init_db("sqlite+aiosqlite:///:memory:")
        monkeypatch.setattr(db_module, "db", dbm)

        gen = get_scoped_session()()
        try:
            session = await gen.__anext__()
            assert session is not None
        finally:
            with pytest.raises(StopAsyncIteration):
                await gen.__anext__()
        await dbm.close()


# ---------- UserDatabase tests ----------


@pytest.fixture
def user_engine():
    eng = sqlalchemy.create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    tables = [t for n, t in Model.metadata.tables.items() if n.startswith("ab_")]
    Model.metadata.create_all(eng, tables=tables)
    yield eng
    Model.metadata.drop_all(eng, tables=tables)
    eng.dispose()


@pytest.fixture
def user_session(user_engine):
    with Session(user_engine) as s:
        yield s


@pytest.fixture
def user_db(user_session):
    return UserDatabase(user_session, User, OAuthAccount)


@pytest.mark.asyncio
class TestUserDatabaseCRUD:
    async def test_create_and_get(self, user_db, user_session):
        u = await user_db.create(
            {
                "username": "alice",
                "email": "alice@example.com",
                "hashed_password": "h",
            }
        )
        assert u.id is not None
        fetched = await user_db.get(u.id)
        assert fetched.username == "alice"

    async def test_get_by_email_case_insensitive(self, user_db):
        await user_db.create(
            {"username": "bob", "email": "Bob@Example.Com", "hashed_password": "h"}
        )
        u = await user_db.get_by_email("bob@example.com")
        assert u is not None
        assert u.username == "bob"

    async def test_get_by_username_case_insensitive(self, user_db):
        await user_db.create(
            {"username": "Carol", "email": "c@x.com", "hashed_password": "h"}
        )
        u = await user_db.get_by_username("carol")
        assert u is not None
        assert u.email == "c@x.com"

    async def test_get_by_username_missing_returns_none(self, user_db):
        u = await user_db.get_by_username("ghost")
        assert u is None

    async def test_update(self, user_db):
        u = await user_db.create(
            {"username": "dan", "email": "d@x.com", "hashed_password": "h"}
        )
        u = await user_db.update(u, {"first_name": "Dan"})
        assert u.first_name == "Dan"

    async def test_delete(self, user_db):
        u = await user_db.create(
            {"username": "eve", "email": "e@x.com", "hashed_password": "h"}
        )
        await user_db.delete(u)
        again = await user_db.get(u.id)
        assert again is None


@pytest.mark.asyncio
class TestUserDatabaseOAuth:
    async def test_get_by_oauth_no_table_raises(self, user_session):
        ud = UserDatabase(user_session, User)  # no oauth table
        with pytest.raises(NotImplementedError):
            await ud.get_by_oauth_account("google", "123")

    async def test_add_oauth_account_no_table_raises(self, user_session):
        ud = UserDatabase(user_session, User)
        with pytest.raises(NotImplementedError):
            await ud.add_oauth_account(SimpleNamespace(), {})

    async def test_update_oauth_account_no_table_raises(self, user_session):
        ud = UserDatabase(user_session, User)
        with pytest.raises(NotImplementedError):
            await ud.update_oauth_account(SimpleNamespace(), SimpleNamespace(), {})

    async def test_get_by_oauth_account_missing_returns_none(self, user_db):
        u = await user_db.get_by_oauth_account("google", "missing")
        assert u is None


@pytest.mark.asyncio
class TestSessionRollbackErrorLog:
    """Line 405 (logger.error("Failed to rollback session")) — rollback
    itself raising on the except path."""

    async def test_session_rollback_exception_logged(self, caplog):
        from unittest.mock import AsyncMock, MagicMock

        from fastapi_rtk.db import DatabaseSessionManager

        dbm = DatabaseSessionManager()
        dbm.init_db("sqlite+aiosqlite:///:memory:")

        boom_session = MagicMock()
        boom_session.rollback = AsyncMock(side_effect=Exception("rollback boom"))
        boom_session.close = AsyncMock()

        sm = MagicMock()
        sm.return_value = boom_session
        dbm._sessionmaker = sm

        with caplog.at_level("ERROR"):
            with pytest.raises(RuntimeError):
                async with dbm.session():
                    raise RuntimeError("trigger except path")
        msgs = " ".join(r.getMessage() for r in caplog.records)
        assert "rollback" in msgs.lower()
        await dbm.close()


@pytest.mark.asyncio
class TestConnectRollbackErrorLog:
    """Line 356 (logger.error in connect()) — async rollback raising."""

    async def test_connect_async_rollback_exception_logged(self, caplog):
        from unittest.mock import AsyncMock, MagicMock

        from sqlalchemy.ext.asyncio import AsyncEngine

        from fastapi_rtk.db import DatabaseSessionManager

        dbm = DatabaseSessionManager()
        dbm.init_db("sqlite+aiosqlite:///:memory:")

        async def _make_boom_conn():
            c = MagicMock()
            c.rollback = AsyncMock(side_effect=Exception("rollback boom"))
            return c

        boom_cm = MagicMock()
        boom_cm.__aenter__ = AsyncMock(side_effect=_make_boom_conn)
        boom_cm.__aexit__ = AsyncMock(return_value=False)

        engine_mock = MagicMock(spec=AsyncEngine)
        engine_mock.begin.return_value = boom_cm
        dbm._engine = engine_mock

        with caplog.at_level("ERROR"):
            with pytest.raises(RuntimeError):
                async with dbm.connect():
                    raise RuntimeError("trigger")
        msgs = " ".join(r.getMessage() for r in caplog.records)
        assert "rollback" in msgs.lower()
