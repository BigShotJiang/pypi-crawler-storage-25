"""Top-level shared fixtures for the test suite.

`config_setter` and `global_setter` manage ephemeral writes to `g.config` /
`g._defaults` / `g._bootstrap_values`. `make_toolkit_app` is a factory used
by integration tier fixtures to spin up a minimal FastAPIReactToolkit app
backed by sqlite-aiosqlite. Future tiers that need an HTTP integration
client should reuse this factory rather than re-implementing the singleton
swap dance.
"""

import contextlib
import sys
from typing import Any, Callable, Iterable

import pytest

from fastapi_rtk.globals import g

_MISSING = object()


@pytest.fixture
def config_setter():
    """Set/restore values in g.config dict."""
    saved = {}
    keys_set = []

    def _set(key, value):
        if key not in saved:
            saved[key] = g.config.get(key, _MISSING)
            keys_set.append(key)
        g.config[key] = value

    yield _set

    for key in keys_set:
        if saved[key] is _MISSING:
            g.config.pop(key, None)
        else:
            g.config[key] = saved[key]


@pytest.fixture
def global_setter():
    """Set/restore g._defaults[key] and g._bootstrap_values[key]."""
    saved = []

    def _set(key, value):
        sentinel = object()
        orig_default = g._defaults.get(key, sentinel)
        orig_boot = g._bootstrap_values.get(key, sentinel)
        saved.append((key, orig_default, orig_boot, sentinel))
        g._defaults[key] = value
        g._bootstrap_values[key] = value

    yield _set

    for key, orig_default, orig_boot, sentinel in saved:
        if orig_default is sentinel:
            g._defaults.pop(key, None)
        else:
            g._defaults[key] = orig_default
        if orig_boot is sentinel:
            g._bootstrap_values.pop(key, None)
        else:
            g._bootstrap_values[key] = orig_boot


@contextlib.contextmanager
def _swap_db_singletons(fresh_dbm):
    """Swap the module-level `db` reference across every module that
    captured it at import time. Restore on exit.
    """
    db_module = sys.modules["fastapi_rtk.db"]
    import fastapi_rtk.fastapi_react_toolkit as toolkit_module
    import fastapi_rtk.security.sqla.apis as sec_apis_module
    import fastapi_rtk.security.sqla.security_manager as sm_module

    originals = {
        "db": db_module.db,
        "toolkit": toolkit_module.db,
        "sm": sm_module.db,
        "sec_apis": sec_apis_module.db,
    }
    db_module.db = fresh_dbm
    toolkit_module.db = fresh_dbm
    sm_module.db = fresh_dbm
    sec_apis_module.db = fresh_dbm
    try:
        yield
    finally:
        db_module.db = originals["db"]
        toolkit_module.db = originals["toolkit"]
        sm_module.db = originals["sm"]
        sec_apis_module.db = originals["sec_apis"]


@contextlib.contextmanager
def _snapshot_g_state():
    """Snapshot/restore g._vars + _defaults + _bootstrap_values + _frozen
    so toolkit construction (which writes to all four) doesn't leak into
    other tests.
    """
    saved_vars = dict(g._vars)
    saved_defaults = dict(g._defaults)
    saved_bootstrap = dict(g._bootstrap_values)
    saved_frozen = g._frozen
    try:
        yield
    finally:
        g._vars.clear()
        g._vars.update(saved_vars)
        g._defaults.clear()
        g._defaults.update(saved_defaults)
        g._bootstrap_values.clear()
        g._bootstrap_values.update(saved_bootstrap)
        object.__setattr__(g, "_frozen", saved_frozen)


@pytest.fixture
def make_toolkit_app(tmp_path, config_setter):
    """Factory fixture: returns a callable that builds a minimal toolkit
    app backed by sqlite-aiosqlite.

    Args:
        extra_apis: optional list of API classes to register via add_api.
        extra_lifespans: optional list of async context managers.
        config_overrides: optional dict of additional config values.

    Returns:
        FastAPI app instance with toolkit initialized.

    Yields fresh `db` singleton + restored g-state on teardown.
    """
    from fastapi import FastAPI

    cleanup_stack: list[Callable[[], None]] = []

    def _factory(
        extra_apis: Iterable[Any] | None = None,
        extra_lifespans: Iterable[Any] | None = None,
        config_overrides: dict | None = None,
    ):
        db_path = tmp_path / "test.db"
        config_setter("SQLALCHEMY_DATABASE_URI", f"sqlite+aiosqlite:///{db_path}")
        config_setter("STATIC_FOLDER", str(tmp_path / "static"))
        config_setter("TEMPLATE_FOLDER", str(tmp_path / "templates"))
        config_setter("PROFILER_ENABLED", False)
        config_setter("SECWEB_ENABLED", False)
        config_setter("DEBUG", False)
        config_setter("AUTH_USER_REGISTRATION", True)
        config_setter("AUTH_USER_REGISTRATION_ROLE", "Public")
        config_setter("AUTH_LOGIN_JWT", True)
        config_setter("AUTH_LOGIN_COOKIE", False)
        config_setter("SECRET_KEY", "tier-integration-secret-32-bytes!!")
        for k, v in (config_overrides or {}).items():
            config_setter(k, v)

        # Build a fresh DatabaseSessionManager and swap it into every module
        # that captured the singleton.
        db_module = sys.modules["fastapi_rtk.db"]
        fresh_dbm = type(db_module.db)()
        swap_cm = _swap_db_singletons(fresh_dbm)
        swap_cm.__enter__()
        cleanup_stack.append(lambda cm=swap_cm: cm.__exit__(None, None, None))

        # Snapshot g state.
        snap_cm = _snapshot_g_state()
        snap_cm.__enter__()
        cleanup_stack.append(lambda cm=snap_cm: cm.__exit__(None, None, None))

        # Drop cached lazy-resolved managers so they re-resolve under the new
        # UPLOAD_FOLDER / IMG_UPLOAD_FOLDER config. They sit in
        # `_bootstrap_values` after first access and `_ensure_default_in_bootstrap`
        # is a no-op once cached.
        for key in ("file_manager", "image_manager"):
            g._bootstrap_values.pop(key, None)
            g._vars.pop(key, None)

        g._frozen = False

        from fastapi_rtk.fastapi_react_toolkit import FastAPIReactToolkit

        toolkit = FastAPIReactToolkit(
            create_tables=False,
            exclude_apis=["LicenseApi"],
            lifespans=list(extra_lifespans or []),
            auth={"secret_key": "tier-integration-secret-32-bytes!!"},
        )
        fastapi_app = FastAPI()
        toolkit.initialize(fastapi_app)
        for api in extra_apis or []:
            toolkit.add_api(api)
        return fastapi_app

    yield _factory

    # Tear down in reverse order.
    while cleanup_stack:
        cleanup_stack.pop()()
