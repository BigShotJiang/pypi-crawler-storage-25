import inspect
import types
import typing

import fastapi

from .self_dependencies import SelfDepends, SelfType

P = typing.ParamSpec("P")
T = typing.TypeVar("T")

__all__ = ["update_signature"]


def update_signature(class_or_instance: type | object, f: typing.Callable[P, T]):
    """
    Update the signature of a function to replace the first parameter (if named "self" or "cls") with a Depends on the given class or instance. Also replaces any parameters with default values of SelfDepends or SelfType with the appropriate Depends or annotation.

    Args:
        class_or_instance (type | object): The class or instance to be injected.
        f (typing.Callable[P, T]): The function to be updated.

    Returns:
        typing.Callable[P, T]: The updated function.
    """
    # Get the function's parameters
    old_signature = inspect.signature(f)
    old_parameters = list(old_signature.parameters.values())
    if not old_parameters:
        return f
    old_first_parameter, *old_parameters = old_parameters

    # If the first parameter is self or cls, replace it
    if old_first_parameter.name in ("self", "cls"):
        new_first_parameter = old_first_parameter.replace(
            default=fastapi.Depends(lambda: class_or_instance)
        )

        new_parameters = [new_first_parameter]
        for parameter in old_parameters:
            parameter = parameter.replace(kind=inspect.Parameter.KEYWORD_ONLY)
            if isinstance(parameter.default, SelfDepends):
                parameter = parameter.replace(
                    default=parameter.default(class_or_instance)
                )
            elif isinstance(parameter.default, SelfType):
                parameter = parameter.replace(
                    annotation=parameter.default(class_or_instance),
                    default=(
                        fastapi.Depends()
                        if parameter.default.depends
                        else inspect.Parameter.empty
                    ),
                )
            new_parameters.append(parameter)

        new_signature = old_signature.replace(parameters=new_parameters)

        # Copy the function to avoid modifying the original
        f = copy_function(f)

        setattr(
            f, "__signature__", new_signature
        )  # Set the new signature to the function

    return f


def copy_function(f):
    """Copy a function."""
    return types.FunctionType(
        f.__code__,
        f.__globals__,
        name=f.__name__,
        argdefs=f.__defaults__,
        closure=f.__closure__,
    )
