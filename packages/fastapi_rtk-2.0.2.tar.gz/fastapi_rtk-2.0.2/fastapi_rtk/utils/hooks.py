import functools
import typing

__all__ = ["hooks"]

P = typing.ParamSpec("P")
R = typing.TypeVar("R")


def hooks(
    pre: typing.Callable[..., None] | None = None,
    post: typing.Callable[..., None] | None = None,
) -> typing.Callable[[typing.Callable[P, R]], typing.Callable[P, R]]:
    """
    Decorator to add optional pre and post hook methods to a function.

    Args:
        pre (typing.Callable[..., None] | None): Function to run before the main function. Called with the same `*args, **kwargs` as the wrapped function. Defaults to None.
        post (typing.Callable[..., None] | None): Function to run after the main function. Called with `(result, *args, **kwargs)`, where `result` is the wrapped function's return value and the remaining args mirror its inputs. Defaults to None.

    Returns:
        typing.Callable[[typing.Callable[P, R]], typing.Callable[P, R]]: Decorator preserving wrapped signature.
    """

    def decorator(func: typing.Callable[P, R]) -> typing.Callable[P, R]:
        @functools.wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            if pre:
                pre(*args, **kwargs)
            result = func(*args, **kwargs)
            if post:
                post(result, *args, **kwargs)
            return result

        return wrapper

    return decorator
