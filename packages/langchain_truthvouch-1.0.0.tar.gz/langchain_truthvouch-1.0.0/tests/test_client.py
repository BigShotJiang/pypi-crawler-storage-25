"""Tests for TrustApiClient — both sync and async, with mocked httpx transport."""

import os
import pytest
import httpx
import respx

from truthvouch_langchain.client import TrustApiClient, TrustVerifyResult, ClaimResult

_VERIFY_URL = "http://localhost:5004/api/v1/trust/verify"

_MOCK_RESPONSE = {
    "requestId": "abc-123",
    "trustScore": 0.92,
    "claims": [
        {
            "claimText": "Paris is the capital of France.",
            "status": "verified",
            "confidenceScore": 0.97,
            "sourceReference": "Wikipedia",
            "suggestedCorrection": "",
        }
    ],
    "latencyMs": 120,
    "tokensUsed": 45,
    "cacheHits": 0,
    "verificationMode": "spot_check",
    "createdAt": "2026-03-06T10:00:00Z",
}

_MOCK_FAILED_RESPONSE = {
    "requestId": "def-456",
    "trustScore": 0.12,
    "claims": [
        {
            "claimText": "The Eiffel Tower is in Berlin.",
            "status": "failed",
            "confidenceScore": 0.95,
            "sourceReference": "Wikipedia",
            "suggestedCorrection": "The Eiffel Tower is located in Paris, France.",
        }
    ],
    "latencyMs": 200,
    "tokensUsed": 60,
    "cacheHits": 0,
    "verificationMode": "standard",
    "createdAt": "2026-03-06T10:01:00Z",
}


@pytest.fixture
def api_key(monkeypatch):
    monkeypatch.setenv("TRUTHVOUCH_API_KEY", "test-key-123")
    return "test-key-123"


def test_client_requires_api_key(monkeypatch):
    monkeypatch.delenv("TRUTHVOUCH_API_KEY", raising=False)
    with pytest.raises(ValueError, match="API key is required"):
        TrustApiClient()


def test_client_uses_env_var(api_key):
    client = TrustApiClient()
    assert client._api_key == "test-key-123"


def test_client_uses_constructor_arg():
    client = TrustApiClient(api_key="explicit-key")
    assert client._api_key == "explicit-key"


def test_client_constructor_takes_precedence_over_env(api_key):
    client = TrustApiClient(api_key="override-key")
    assert client._api_key == "override-key"


@respx.mock
def test_verify_sync_success(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_MOCK_RESPONSE))

    client = TrustApiClient()
    result = client.verify_sync("Paris is the capital of France.")

    assert isinstance(result, TrustVerifyResult)
    assert result.id == "abc-123"
    assert result.trust_score == pytest.approx(0.92)
    assert result.mode == "spot_check"
    assert result.cache_hit is False
    assert result.processing_time_ms == 120
    assert result.tokens_used == 45
    assert len(result.claims) == 1

    claim = result.claims[0]
    assert isinstance(claim, ClaimResult)
    assert claim.status == "verified"
    assert claim.confidence_score == pytest.approx(0.97)
    assert claim.source_reference == "Wikipedia"
    assert claim.suggested_correction == ""


@respx.mock
def test_verify_sync_failed_claim(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_MOCK_FAILED_RESPONSE))

    client = TrustApiClient()
    result = client.verify_sync("The Eiffel Tower is in Berlin.", mode="standard")

    assert result.trust_score == pytest.approx(0.12)
    assert len(result.claims) == 1
    assert result.claims[0].status == "failed"
    assert "Paris" in result.claims[0].suggested_correction


@respx.mock
def test_verify_sync_sends_correct_headers(api_key):
    route = respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_MOCK_RESPONSE))

    client = TrustApiClient()
    client.verify_sync("test content")

    request = route.calls.last.request
    assert request.headers["Authorization"] == "Bearer test-key-123"
    assert request.headers["Content-Type"] == "application/json"


@respx.mock
def test_verify_sync_sends_mode_in_payload(api_key):
    import json

    route = respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_MOCK_RESPONSE))

    client = TrustApiClient()
    client.verify_sync("test content", mode="full")

    request = route.calls.last.request
    payload = json.loads(request.content)
    assert payload["verificationMode"] == "full"
    assert payload["content"] == "test content"


@respx.mock
def test_verify_sync_http_error_raises(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(401, json={"error": "Unauthorized"}))

    client = TrustApiClient()
    with pytest.raises(httpx.HTTPStatusError):
        client.verify_sync("test content")


@respx.mock
def test_verify_sync_empty_claims(api_key):
    response_data = {**_MOCK_RESPONSE, "claims": [], "trustScore": 0.5}
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=response_data))

    client = TrustApiClient()
    result = client.verify_sync("minimal content")

    assert result.trust_score == pytest.approx(0.5)
    assert result.claims == []


@respx.mock
@pytest.mark.asyncio
async def test_verify_async_success(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_MOCK_RESPONSE))

    client = TrustApiClient()
    result = await client.verify("Paris is the capital of France.")

    assert isinstance(result, TrustVerifyResult)
    assert result.trust_score == pytest.approx(0.92)
    assert result.id == "abc-123"


@respx.mock
@pytest.mark.asyncio
async def test_verify_async_sends_correct_payload(api_key):
    import json

    route = respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_MOCK_RESPONSE))

    client = TrustApiClient()
    await client.verify("async test", mode="standard")

    request = route.calls.last.request
    payload = json.loads(request.content)
    assert payload["verificationMode"] == "standard"
    assert payload["content"] == "async test"


def test_trust_verify_result_from_dict():
    result = TrustVerifyResult.from_dict(_MOCK_RESPONSE)
    assert result.id == "abc-123"
    assert result.trust_score == pytest.approx(0.92)
    assert len(result.claims) == 1
    assert result.raw == _MOCK_RESPONSE


def test_trust_verify_result_from_dict_missing_fields():
    result = TrustVerifyResult.from_dict({})
    assert result.id == ""
    assert result.trust_score == 0.0
    assert result.claims == []
    assert result.mode == "spot_check"
