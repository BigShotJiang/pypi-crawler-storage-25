"""Tests for TruthVouchCallbackHandler with mocked httpx transport."""

import pytest
import httpx
import respx
from langchain_core.messages import AIMessage
from langchain_core.outputs import ChatGeneration, LLMResult

from truthvouch_langchain.callback import TruthVouchCallbackHandler, TrustThresholdError

_VERIFY_URL = "http://localhost:5004/api/v1/trust/verify"


def _make_response(trust_score: float) -> dict:
    return {
        "requestId": "cb-test",
        "trustScore": trust_score,
        "claims": [
            {
                "claimText": "test claim",
                "status": "verified" if trust_score >= 0.8 else "failed",
                "confidenceScore": 0.9,
                "sourceReference": "",
                "suggestedCorrection": "",
            }
        ],
        "latencyMs": 80,
        "tokensUsed": 20,
        "cacheHits": 0,
        "verificationMode": "spot_check",
        "createdAt": "2026-03-06T10:00:00Z",
    }


def _make_llm_result(text: str) -> LLMResult:
    """Build a minimal LLMResult with one generation."""
    gen = ChatGeneration(message=AIMessage(content=text), text=text)
    return LLMResult(generations=[[gen]])


@pytest.fixture
def api_key(monkeypatch):
    monkeypatch.setenv("TRUTHVOUCH_API_KEY", "test-key")
    return "test-key"


@respx.mock
def test_on_llm_end_high_trust_no_error(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.95)))

    handler = TruthVouchCallbackHandler(threshold=0.8)
    result = _make_llm_result("Paris is the capital of France.")

    # Should not raise
    handler.on_llm_end(result)

    assert handler.last_result is not None
    assert handler.last_result.trust_score == pytest.approx(0.95)


@respx.mock
def test_on_llm_end_low_trust_logs_warning(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.3)))

    handler = TruthVouchCallbackHandler(threshold=0.8, raise_on_low_trust=False)
    result = _make_llm_result("The Eiffel Tower is in Berlin.")

    # Should not raise when raise_on_low_trust=False
    handler.on_llm_end(result)
    assert handler.last_result.trust_score == pytest.approx(0.3)


@respx.mock
def test_on_llm_end_raises_on_low_trust_when_configured(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.3)))

    handler = TruthVouchCallbackHandler(threshold=0.8, raise_on_low_trust=True)
    result = _make_llm_result("The Eiffel Tower is in Berlin.")

    with pytest.raises(TrustThresholdError) as exc_info:
        handler.on_llm_end(result)

    error = exc_info.value
    assert error.trust_score == pytest.approx(0.3)
    assert error.threshold == pytest.approx(0.8)
    assert error.result is not None


@respx.mock
def test_on_llm_end_does_not_raise_above_threshold(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.85)))

    handler = TruthVouchCallbackHandler(threshold=0.8, raise_on_low_trust=True)
    result = _make_llm_result("Factual content here.")

    # 0.85 >= 0.8, so no error
    handler.on_llm_end(result)
    assert handler.last_result.trust_score == pytest.approx(0.85)


def test_on_llm_end_skips_empty_text(api_key, monkeypatch):
    handler = TruthVouchCallbackHandler()
    result = _make_llm_result("")
    # Should not call the API and not raise
    handler.on_llm_end(result)
    assert handler.last_result is None


def test_on_llm_end_skips_whitespace_text(api_key):
    handler = TruthVouchCallbackHandler()
    result = _make_llm_result("   \n\t  ")
    handler.on_llm_end(result)
    assert handler.last_result is None


@respx.mock
def test_on_llm_end_api_error_does_not_raise(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(500))

    handler = TruthVouchCallbackHandler(threshold=0.8, raise_on_low_trust=False)
    result = _make_llm_result("some content")

    # API error should be caught and logged, not re-raised
    handler.on_llm_end(result)
    assert handler.last_result is None


def test_on_llm_error_does_not_raise(api_key):
    handler = TruthVouchCallbackHandler()
    handler.on_llm_error(ValueError("LLM failed"))  # Should be a no-op


def test_trust_threshold_error_str():
    from truthvouch_langchain.client import TrustVerifyResult

    mock_result = TrustVerifyResult(
        id="x",
        trust_score=0.3,
        claims=[],
        processing_time_ms=0,
        tokens_used=0,
        cache_hit=False,
        mode="spot_check",
        created_at="",
    )
    err = TrustThresholdError(0.3, 0.8, mock_result)
    assert "0.300" in str(err)
    assert "0.80" in str(err)


@respx.mock
def test_on_llm_end_uses_configured_mode(api_key):
    import json

    route = respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.9))
    )

    handler = TruthVouchCallbackHandler(mode="standard")
    handler.on_llm_end(_make_llm_result("test text"))

    request = route.calls.last.request
    payload = json.loads(request.content)
    assert payload["verificationMode"] == "standard"
