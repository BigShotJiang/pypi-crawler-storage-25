"""Tests for TruthVouchGuard with mocked httpx transport."""

import pytest
import httpx
import respx

from truthvouch_langchain.guard import TruthVouchGuard, GuardResult

_VERIFY_URL = "http://localhost:5004/api/v1/trust/verify"


def _make_response(trust_score: float, status: str = "verified") -> dict:
    return {
        "requestId": "guard-test",
        "trustScore": trust_score,
        "claims": [
            {
                "claimText": "test claim",
                "status": status,
                "confidenceScore": 0.9,
                "sourceReference": "source",
                "suggestedCorrection": "correction" if status == "failed" else "",
            }
        ],
        "latencyMs": 60,
        "tokensUsed": 15,
        "cacheHits": 0,
        "verificationMode": "spot_check",
        "createdAt": "2026-03-06T10:00:00Z",
    }


@pytest.fixture
def api_key(monkeypatch):
    monkeypatch.setenv("TRUTHVOUCH_API_KEY", "test-key")
    return "test-key"


@respx.mock
def test_guard_passes_high_trust(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.95)))

    guard = TruthVouchGuard(threshold=0.8)
    result = guard("Paris is the capital of France.")

    assert isinstance(result, GuardResult)
    assert result.passed is True
    assert result.trust_score == pytest.approx(0.95)
    assert result.threshold == pytest.approx(0.8)


@respx.mock
def test_guard_fails_low_trust(api_key):
    respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.2, "failed"))
    )

    guard = TruthVouchGuard(threshold=0.8)
    result = guard("The Eiffel Tower is in Berlin.")

    assert result.passed is False
    assert result.trust_score == pytest.approx(0.2)


@respx.mock
def test_guard_exactly_at_threshold_passes(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.8)))

    guard = TruthVouchGuard(threshold=0.8)
    result = guard("Content at exact threshold.")

    assert result.passed is True


@respx.mock
def test_guard_returns_claims(api_key):
    respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.2, "failed"))
    )

    guard = TruthVouchGuard(threshold=0.8)
    result = guard("low trust text")

    assert len(result.claims) == 1
    assert result.claims[0].status == "failed"
    assert len(result.failed_claims) == 1
    assert len(result.unverifiable_claims) == 0


@respx.mock
def test_guard_unverifiable_claims(api_key):
    response = _make_response(0.5, "unverifiable")
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=response))

    guard = TruthVouchGuard(threshold=0.8)
    result = guard("unverifiable text")

    assert len(result.unverifiable_claims) == 1
    assert len(result.failed_claims) == 0


@respx.mock
def test_guard_exposes_processing_metadata(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.9)))

    guard = TruthVouchGuard(threshold=0.8)
    result = guard("some factual content")

    assert result.processing_time_ms == 60
    assert result.cache_hit is False
    assert result.verification_id == "guard-test"
    assert result.mode == "spot_check"


def test_guard_empty_string_returns_failed(api_key):
    guard = TruthVouchGuard(threshold=0.8)
    result = guard("")

    assert result.passed is False
    assert result.trust_score == 0.0


def test_guard_whitespace_only_returns_failed(api_key):
    guard = TruthVouchGuard(threshold=0.8)
    result = guard("   \n\t  ")

    assert result.passed is False


@respx.mock
def test_guard_custom_threshold(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.6)))

    guard = TruthVouchGuard(threshold=0.5)
    result = guard("content with mediocre trust")

    assert result.passed is True  # 0.6 >= 0.5


@respx.mock
def test_guard_custom_mode(api_key):
    import json

    route = respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.9))
    )

    guard = TruthVouchGuard(mode="full")
    guard("test text")

    payload = json.loads(route.calls.last.request.content)
    assert payload["verificationMode"] == "full"


@respx.mock
@pytest.mark.asyncio
async def test_guard_async_verify_passes(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.92)))

    guard = TruthVouchGuard(threshold=0.8)
    result = await guard.verify_async("async content")

    assert result.passed is True
    assert result.trust_score == pytest.approx(0.92)


@respx.mock
@pytest.mark.asyncio
async def test_guard_async_verify_fails(api_key):
    respx.post(_VERIFY_URL).mock(
        return_value=httpx.Response(200, json=_make_response(0.1, "failed"))
    )

    guard = TruthVouchGuard(threshold=0.8)
    result = await guard.verify_async("false content")

    assert result.passed is False


@pytest.mark.asyncio
async def test_guard_async_empty_returns_failed(api_key):
    guard = TruthVouchGuard(threshold=0.8)
    result = await guard.verify_async("")
    assert result.passed is False
