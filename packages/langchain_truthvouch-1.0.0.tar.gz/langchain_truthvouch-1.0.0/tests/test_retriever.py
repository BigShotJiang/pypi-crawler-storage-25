"""Tests for TruthVouchRetriever with mocked httpx transport."""

import pytest
import httpx
import respx
from langchain_core.documents import Document

from truthvouch_langchain.retriever import TruthVouchRetriever

_VERIFY_URL = "http://localhost:5004/api/v1/trust/verify"


def _make_response(trust_score: float, status: str = "verified") -> dict:
    return {
        "requestId": "test-id",
        "trustScore": trust_score,
        "claims": [
            {
                "claimText": "test claim",
                "status": status,
                "confidenceScore": 0.9,
                "sourceReference": "",
                "suggestedCorrection": "",
            }
        ],
        "latencyMs": 50,
        "tokensUsed": 10,
        "cacheHits": 0,
        "verificationMode": "spot_check",
        "createdAt": "2026-03-06T10:00:00Z",
    }


@pytest.fixture
def api_key(monkeypatch):
    monkeypatch.setenv("TRUTHVOUCH_API_KEY", "test-key")
    return "test-key"


@respx.mock
def test_verify_documents_all_pass(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.95)))

    retriever = TruthVouchRetriever(threshold=0.8)
    docs = [Document(page_content="Paris is the capital of France.")]
    result = retriever.verify_documents(docs)

    assert len(result) == 1
    assert result[0].metadata["trust_score"] == pytest.approx(0.95)
    assert "trust_claims" in result[0].metadata
    assert "trust_mode" in result[0].metadata


@respx.mock
def test_verify_documents_filters_low_score(api_key):
    # First call returns low score, second returns high
    call_count = 0

    def side_effect(request):
        nonlocal call_count
        call_count += 1
        score = 0.3 if call_count == 1 else 0.95
        return httpx.Response(200, json=_make_response(score))

    respx.post(_VERIFY_URL).mock(side_effect=side_effect)

    retriever = TruthVouchRetriever(threshold=0.8)
    docs = [
        Document(page_content="The Eiffel Tower is in Berlin."),
        Document(page_content="Paris is the capital of France."),
    ]
    result = retriever.verify_documents(docs)

    # Only the second doc should pass
    assert len(result) == 1
    assert result[0].page_content == "Paris is the capital of France."


@respx.mock
def test_verify_documents_no_filter_mode(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.3)))

    retriever = TruthVouchRetriever(threshold=0.8, filter_below_threshold=False)
    docs = [Document(page_content="Low trust content")]
    result = retriever.verify_documents(docs)

    # Should include the doc even with low score
    assert len(result) == 1
    assert result[0].metadata["trust_score"] == pytest.approx(0.3)


@respx.mock
def test_verify_documents_attaches_claims_metadata(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.9)))

    retriever = TruthVouchRetriever(threshold=0.5)
    docs = [Document(page_content="some factual content")]
    result = retriever.verify_documents(docs)

    assert len(result) == 1
    claims = result[0].metadata["trust_claims"]
    assert isinstance(claims, list)
    assert len(claims) == 1
    assert claims[0]["status"] == "verified"


@respx.mock
def test_verify_documents_handles_api_error_gracefully(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(500, text="Server Error"))

    retriever = TruthVouchRetriever(threshold=0.8, filter_below_threshold=True)
    docs = [Document(page_content="some content")]
    # Should not raise — errors are caught and logged; doc is filtered (score=0.0)
    result = retriever.verify_documents(docs)
    assert len(result) == 0


@respx.mock
def test_verify_documents_error_sets_trust_score_zero(api_key):
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(503))

    retriever = TruthVouchRetriever(threshold=0.8, filter_below_threshold=False)
    docs = [Document(page_content="content that errors")]
    result = retriever.verify_documents(docs)

    assert len(result) == 1
    assert result[0].metadata["trust_score"] == 0.0
    assert "trust_error" in result[0].metadata


@respx.mock
def test_verify_documents_cache_hit_recorded(api_key):
    cached_response = {**_make_response(0.9), "cacheHits": 1}
    respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=cached_response))

    retriever = TruthVouchRetriever(threshold=0.5)
    docs = [Document(page_content="cached content")]
    result = retriever.verify_documents(docs)

    assert result[0].metadata["trust_cache_hit"] is True


def test_retriever_empty_documents(api_key):
    retriever = TruthVouchRetriever(threshold=0.8)
    result = retriever.verify_documents([])
    assert result == []


@respx.mock
def test_retriever_uses_configured_mode(api_key):
    import json

    route = respx.post(_VERIFY_URL).mock(return_value=httpx.Response(200, json=_make_response(0.9)))

    retriever = TruthVouchRetriever(threshold=0.5, mode="full")
    retriever.verify_documents([Document(page_content="full mode test")])

    request = route.calls.last.request
    payload = json.loads(request.content)
    assert payload["verificationMode"] == "full"
