"""TruthVouch LangChain callback handler.

Automatically verifies LLM output text after each generation via the Trust API.
Optionally raises TrustThresholdError if the score is below the configured threshold.
"""

import logging
from typing import Any, Dict, List, Optional, Union

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.outputs import LLMResult

from truthvouch_langchain.client import TrustApiClient, TrustVerifyResult

logger = logging.getLogger(__name__)


class TrustThresholdError(Exception):
    """Raised when an LLM response trust score falls below the threshold.

    Attributes:
        trust_score: The actual score returned by the Trust API.
        threshold: The configured minimum acceptable score.
        result: Full TrustVerifyResult for inspection.
    """

    def __init__(self, trust_score: float, threshold: float, result: TrustVerifyResult) -> None:
        self.trust_score = trust_score
        self.threshold = threshold
        self.result = result
        super().__init__(
            f"LLM response trust score {trust_score:.3f} is below threshold {threshold:.2f}"
        )


class TruthVouchCallbackHandler(BaseCallbackHandler):
    """LangChain callback handler that verifies LLM responses via the Trust API.

    Attach this handler to any LangChain LLM or chain. On each LLM generation
    the output text is sent to the Trust API. The result is logged at INFO level.
    If raise_on_low_trust=True, TrustThresholdError is raised for low scores.

    Args:
        api_key: Trust API key. Defaults to TRUTHVOUCH_API_KEY env var.
        base_url: Trust API base URL.
        threshold: Minimum trust score; scores below this trigger warnings/errors.
        mode: Verification mode — "spot_check", "standard", or "full".
        raise_on_low_trust: If True, raise TrustThresholdError on low scores.

    Example:
        handler = TruthVouchCallbackHandler(api_key="key", threshold=0.8)
        llm = ChatOpenAI(callbacks=[handler])
        response = llm.invoke("Tell me about photosynthesis.")
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "http://localhost:5004/api/v1/trust",
        threshold: float = 0.8,
        mode: str = "spot_check",
        raise_on_low_trust: bool = False,
    ) -> None:
        super().__init__()
        self._client = TrustApiClient(api_key=api_key, base_url=base_url)
        self._threshold = threshold
        self._mode = mode
        self._raise_on_low_trust = raise_on_low_trust
        # Store last result for inspection
        self.last_result: Optional[TrustVerifyResult] = None

    def on_llm_end(self, response: LLMResult, **kwargs: Any) -> None:
        """Called after every LLM generation. Verifies the output text.

        Args:
            response: LangChain LLMResult containing generated text.
            **kwargs: Additional LangChain callback kwargs.

        Raises:
            TrustThresholdError: If raise_on_low_trust=True and score < threshold.
        """
        # Extract text from the first generation of the first batch
        try:
            text = response.generations[0][0].text
        except (IndexError, AttributeError):
            logger.warning("TruthVouch callback: could not extract generation text")
            return

        if not text or not text.strip():
            logger.debug("TruthVouch callback: skipping empty generation")
            return

        try:
            result = self._client.verify_sync(text, mode=self._mode)
            self.last_result = result
            log_level = logging.INFO if result.trust_score >= self._threshold else logging.WARNING
            logger.log(
                log_level,
                "TruthVouch callback: trust_score=%.3f threshold=%.2f mode=%s cache_hit=%s",
                result.trust_score,
                self._threshold,
                result.mode,
                result.cache_hit,
            )

            if result.trust_score < self._threshold:
                failed_claims = [c for c in result.claims if c.status == "failed"]
                if failed_claims:
                    logger.warning(
                        "TruthVouch callback: %d failed claim(s) detected",
                        len(failed_claims),
                    )
                if self._raise_on_low_trust:
                    raise TrustThresholdError(result.trust_score, self._threshold, result)

        except TrustThresholdError:
            raise
        except Exception as exc:
            logger.error("TruthVouch callback: verification error — %s", exc)

    def on_llm_error(
        self, error: Union[Exception, KeyboardInterrupt], **kwargs: Any
    ) -> None:
        """Called when an LLM error occurs. Skips verification."""
        logger.debug("TruthVouch callback: skipping verification due to LLM error — %s", error)
