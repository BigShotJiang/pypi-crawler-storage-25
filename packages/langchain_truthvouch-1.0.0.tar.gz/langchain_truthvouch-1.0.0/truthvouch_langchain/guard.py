"""TruthVouch Guard — simple callable for inline text verification.

Use this as a lightweight pass/fail gate before displaying or acting on any
AI-generated text.
"""

import logging
from dataclasses import dataclass, field
from typing import List, Optional

from truthvouch_langchain.client import ClaimResult, TrustApiClient, TrustVerifyResult

logger = logging.getLogger(__name__)


@dataclass
class GuardResult:
    """Result returned by TruthVouchGuard.__call__.

    Attributes:
        passed: True if trust_score >= threshold.
        trust_score: Raw trust score from the Trust API (0.0–1.0).
        threshold: The configured minimum score.
        claims: Per-claim verification details.
        processing_time_ms: Time taken by the Trust API in milliseconds.
        cache_hit: Whether the result was served from cache.
        verification_id: Unique ID for this verification event.
        mode: Verification mode used.
    """

    passed: bool
    trust_score: float
    threshold: float
    claims: List[ClaimResult] = field(default_factory=list)
    processing_time_ms: int = 0
    cache_hit: bool = False
    verification_id: str = ""
    mode: str = "spot_check"

    @property
    def failed_claims(self) -> List[ClaimResult]:
        """Claims with status 'failed'."""
        return [c for c in self.claims if c.status == "failed"]

    @property
    def unverifiable_claims(self) -> List[ClaimResult]:
        """Claims with status 'unverifiable'."""
        return [c for c in self.claims if c.status == "unverifiable"]


class TruthVouchGuard:
    """Simple callable guard that verifies text via the TruthVouch Trust API.

    Call an instance with any text string to get a GuardResult indicating
    whether the content passes the configured trust threshold.

    Args:
        api_key: Trust API key. Defaults to TRUTHVOUCH_API_KEY env var.
        base_url: Trust API base URL.
        threshold: Minimum trust score to pass (0.0–1.0). Default 0.8.
        mode: Verification mode — "spot_check", "standard", or "full".

    Example:
        guard = TruthVouchGuard(threshold=0.8)
        result = guard("The Eiffel Tower is in Paris, France.")
        if result.passed:
            display(result)
        else:
            print("Low trust score:", result.trust_score)
            for claim in result.failed_claims:
                print(" -", claim.claim_text, "->", claim.suggested_correction)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "http://localhost:5004/api/v1/trust",
        threshold: float = 0.8,
        mode: str = "spot_check",
    ) -> None:
        self._client = TrustApiClient(api_key=api_key, base_url=base_url)
        self._threshold = threshold
        self._mode = mode

    def __call__(self, text: str) -> GuardResult:
        """Verify text and return a GuardResult.

        Args:
            text: The text to verify.

        Returns:
            GuardResult with pass/fail status and detailed claim information.

        Raises:
            httpx.HTTPError: If the Trust API is unreachable.
        """
        if not text or not text.strip():
            logger.warning("TruthVouch guard: empty text provided, returning passed=False")
            return GuardResult(
                passed=False,
                trust_score=0.0,
                threshold=self._threshold,
            )

        result: TrustVerifyResult = self._client.verify_sync(text, mode=self._mode)
        passed = result.trust_score >= self._threshold

        logger.info(
            "TruthVouch guard: trust_score=%.3f threshold=%.2f passed=%s",
            result.trust_score,
            self._threshold,
            passed,
        )

        return GuardResult(
            passed=passed,
            trust_score=result.trust_score,
            threshold=self._threshold,
            claims=result.claims,
            processing_time_ms=result.processing_time_ms,
            cache_hit=result.cache_hit,
            verification_id=result.id,
            mode=result.mode,
        )

    async def verify_async(self, text: str) -> GuardResult:
        """Async version of __call__ for use in async contexts.

        Args:
            text: The text to verify.

        Returns:
            GuardResult with pass/fail status and detailed claim information.
        """
        if not text or not text.strip():
            logger.warning("TruthVouch guard: empty text provided, returning passed=False")
            return GuardResult(
                passed=False,
                trust_score=0.0,
                threshold=self._threshold,
            )

        result: TrustVerifyResult = await self._client.verify(text, mode=self._mode)
        passed = result.trust_score >= self._threshold

        logger.info(
            "TruthVouch guard: trust_score=%.3f threshold=%.2f passed=%s",
            result.trust_score,
            self._threshold,
            passed,
        )

        return GuardResult(
            passed=passed,
            trust_score=result.trust_score,
            threshold=self._threshold,
            claims=result.claims,
            processing_time_ms=result.processing_time_ms,
            cache_hit=result.cache_hit,
            verification_id=result.id,
            mode=result.mode,
        )
