"""TruthVouch LangChain integration package.

Provides LangChain-compatible components for hallucination detection and
content verification via the TruthVouch Trust API.
"""

from truthvouch_langchain.client import TrustApiClient, TrustVerifyResult
from truthvouch_langchain.retriever import TruthVouchRetriever
from truthvouch_langchain.callback import TruthVouchCallbackHandler, TrustThresholdError
from truthvouch_langchain.guard import TruthVouchGuard, GuardResult

__all__ = [
    "TrustApiClient",
    "TrustVerifyResult",
    "TruthVouchRetriever",
    "TruthVouchCallbackHandler",
    "TrustThresholdError",
    "TruthVouchGuard",
    "GuardResult",
    "__version__",
]

__version__ = "1.0.0"
