"""TruthVouch LangChain retriever.

Wraps document retrieval with Trust API verification. Documents with a trust
score below the threshold are filtered from the results.
"""

import logging
from typing import Any, Dict, List, Optional

from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from pydantic import ConfigDict

from truthvouch_langchain.client import TrustApiClient

logger = logging.getLogger(__name__)


class TruthVouchRetriever(BaseRetriever):
    """LangChain retriever that verifies document content via the Trust API.

    Each document's page_content is verified after retrieval. The trust score
    is stored in document.metadata["trust_score"]. Documents below the
    threshold are filtered out unless filter_below_threshold=False.

    Args:
        api_key: Trust API key. Defaults to TRUTHVOUCH_API_KEY env var.
        base_url: Trust API base URL.
        threshold: Minimum trust score to keep a document (0.0–1.0).
        mode: Verification mode — "spot_check", "standard", or "full".
        filter_below_threshold: If True, documents below threshold are removed.

    Example:
        retriever = TruthVouchRetriever(api_key="key", threshold=0.75)
        docs = retriever.get_relevant_documents("What is the capital of France?")
    """

    api_key: Optional[str] = None
    base_url: str = "http://localhost:5004/api/v1/trust"
    threshold: float = 0.8
    mode: str = "spot_check"
    filter_below_threshold: bool = True

    # Pydantic field for internal client — excluded from schema
    _client: Optional[TrustApiClient] = None

    model_config = ConfigDict(arbitrary_types_allowed=True)

    def _get_client(self) -> TrustApiClient:
        if self._client is None:
            self._client = TrustApiClient(
                api_key=self.api_key,
                base_url=self.base_url,
            )
        return self._client

    def _verify_document(self, doc: Document) -> Document:
        """Verify a single document and attach trust metadata.

        Args:
            doc: LangChain Document to verify.

        Returns:
            Document with trust_score, trust_mode, and trust_claims in metadata.
        """
        client = self._get_client()
        try:
            result = client.verify_sync(doc.page_content, mode=self.mode)
            doc.metadata["trust_score"] = result.trust_score
            doc.metadata["trust_mode"] = result.mode
            doc.metadata["trust_cache_hit"] = result.cache_hit
            doc.metadata["trust_claims"] = [
                {
                    "text": c.claim_text,
                    "status": c.status,
                    "confidence": c.confidence_score,
                }
                for c in result.claims
            ]
            logger.debug(
                "TruthVouch retriever: doc trust_score=%.3f threshold=%.2f",
                result.trust_score,
                self.threshold,
            )
        except Exception as exc:
            logger.warning("TruthVouch retriever: verification failed — %s", exc)
            doc.metadata["trust_score"] = 0.0
            doc.metadata["trust_error"] = str(exc)
        return doc

    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: CallbackManagerForRetrieverRun,
    ) -> List[Document]:
        """Return verified documents, filtering those below the trust threshold.

        Args:
            query: The search query (passed to inner retriever if composed;
                   in standalone mode this retriever acts on pre-fetched docs).
            run_manager: LangChain callback run manager.

        Returns:
            List of verified Documents with trust metadata attached.
        """
        # Standalone usage: subclasses or users must populate self._documents.
        # In composition with another retriever, override get_relevant_documents.
        documents: List[Document] = getattr(self, "_documents", [])
        verified: List[Document] = []

        for doc in documents:
            verified_doc = self._verify_document(doc)
            score = verified_doc.metadata.get("trust_score", 0.0)
            if self.filter_below_threshold and score < self.threshold:
                logger.info(
                    "TruthVouch retriever: filtered doc (score=%.3f < %.2f)",
                    score,
                    self.threshold,
                )
                continue
            verified.append(verified_doc)

        return verified

    def verify_documents(self, documents: List[Document]) -> List[Document]:
        """Verify a list of pre-fetched documents.

        This is the primary method for composed pipelines where another
        retriever fetches the documents and this verifier filters them.

        Args:
            documents: List of Documents to verify.

        Returns:
            Verified and optionally filtered Documents.
        """
        result: List[Document] = []
        for doc in documents:
            verified_doc = self._verify_document(doc)
            score = verified_doc.metadata.get("trust_score", 0.0)
            if self.filter_below_threshold and score < self.threshold:
                continue
            result.append(verified_doc)
        return result
