# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2026-04-03

### Added
- Initial public release
- TrustApiClient — async/sync client for TruthVouch Trust API verify endpoint
- TruthVouchRetriever — LangChain retriever with trust score filtering
- TruthVouchCallbackHandler — automatic LLM response verification callback
- TruthVouchGuard — simple callable guard for inline text verification
- PEP 561 py.typed marker for type checker support
