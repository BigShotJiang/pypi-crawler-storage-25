# langchain-truthvouch

LangChain integration for the [TruthVouch](https://truthvouch.com) Trust API. Add hallucination
detection and content verification to any LangChain pipeline in minutes.

## Installation

```bash
pip install langchain-truthvouch
```

## Quickstart

```python
import os
os.environ["TRUTHVOUCH_API_KEY"] = "your-api-key"

from truthvouch_langchain import TruthVouchGuard

guard = TruthVouchGuard(threshold=0.8)
result = guard("The Eiffel Tower is located in Berlin.")
print(result.passed)        # False — low trust score
print(result.trust_score)   # e.g. 0.21
print(result.claims)        # list of per-claim verification results
```

## Components

### TrustApiClient

Low-level async/sync client for the Trust API verify endpoint.

```python
from truthvouch_langchain import TrustApiClient

client = TrustApiClient(
    api_key="your-api-key",           # or set TRUTHVOUCH_API_KEY env var
    base_url="http://localhost:5004/api/v1/trust",  # default
)

result = client.verify_sync("Paris is the capital of France.", mode="standard")
print(result.trust_score)  # 0.97
```

### TruthVouchRetriever

Wraps any document list with trust verification. Documents below the threshold are filtered out.

```python
from langchain_core.documents import Document
from truthvouch_langchain import TruthVouchRetriever

retriever = TruthVouchRetriever(
    api_key="your-api-key",
    threshold=0.75,
    mode="spot_check",
)
docs = retriever.get_relevant_documents("What is the capital of France?")
# Each doc has doc.metadata["trust_score"] set
```

### TruthVouchCallbackHandler

Automatically verifies every LLM response via a LangChain callback.

```python
from langchain_openai import ChatOpenAI
from truthvouch_langchain import TruthVouchCallbackHandler

handler = TruthVouchCallbackHandler(
    api_key="your-api-key",
    threshold=0.8,
    raise_on_low_trust=False,  # set True to raise TrustThresholdError
)

llm = ChatOpenAI(callbacks=[handler])
response = llm.invoke("Tell me about the Eiffel Tower.")
```

### TruthVouchGuard

Simple callable guard — verify any text before displaying or acting on it.

```python
from truthvouch_langchain import TruthVouchGuard

guard = TruthVouchGuard(threshold=0.8)
result = guard("Some text to verify")
if not result.passed:
    print("Low trust score:", result.trust_score)
```

## Configuration

| Parameter | Env var | Default |
|---|---|---|
| `api_key` | `TRUTHVOUCH_API_KEY` | (required) |
| `base_url` | — | `http://localhost:5004/api/v1/trust` |
| `threshold` | — | `0.8` |
| `mode` | — | `spot_check` |

## License

Apache-2.0
