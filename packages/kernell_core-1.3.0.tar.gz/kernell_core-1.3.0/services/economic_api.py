#!/usr/bin/env python3
"""
services/economic_api.py
═════════════════════════
Kernell OS Economic Observability API

FastAPI backend that:
 - Reads aggregated metrics from Redis hot cache
 - Streams live receipt events via Redis PubSub
 - Exposes anomaly feed from Redis
 - Provides cognitive tier usage analytics

Runs on port 8420. Consumed by the dashboard frontend.
"""

import os
import json
import asyncio
from typing import List, Dict, Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
import redis.asyncio as redis_async
import redis

REDIS_HOST = "localhost"
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))  # Make sure this matches the VPS config (6380 or 6379)
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "")

app = FastAPI(title="Kernell OS Economic API", version="1.1")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Synchronous client for regular REST endpoints
r_kwargs = {"host": REDIS_HOST, "port": REDIS_PORT, "decode_responses": True}
if REDIS_PASSWORD:
    r_kwargs["password"] = REDIS_PASSWORD
r = redis.Redis(**r_kwargs)

# ── REST Endpoints ────────────────────────────────────────────────────

@app.get("/api/metrics")
def get_metrics() -> Dict[str, Any]:
    """Compute aggregate metrics from hot Redis cache."""
    try:
        # Global metrics
        global_stats = r.hgetall("kernell:metrics:global")
        
        # Calculate recent burn rate
        window_keys = r.smembers("kernell:metrics:window_keys")
        recent_cost = 0.0
        recent_count = 0
        
        # Clean up expired keys from the set while we iterate
        pipe = r.pipeline()
        for key in window_keys:
            pipe.get(key)
        
        results = pipe.execute()
        
        keys_to_remove = []
        for i, key in enumerate(window_keys):
            val = results[i]
            if val:
                data = json.loads(val)
                recent_cost += data.get("cost", 0.0)
                recent_count += 1
            else:
                keys_to_remove.append(key)
                
        if keys_to_remove:
            r.srem("kernell:metrics:window_keys", *keys_to_remove)

        burn_rate = round(recent_cost / 5.0, 8) if recent_count > 0 else 0.0

        # Provider stats
        providers = {}
        prov_set = r.smembers("kernell:metrics:providers_set")
        for prov in prov_set:
            stats = r.hgetall(f"kernell:metrics:provider:{prov}")
            if stats:
                count = int(stats.get("count", 0))
                cost = float(stats.get("cost", 0.0))
                fails = int(stats.get("fails", 0))
                lat_sum = float(stats.get("latency_sum", 0.0))
                
                providers[prov] = {
                    "requests": count,
                    "total_cost": round(cost, 8),
                    "avg_latency_ms": round(lat_sum / max(count, 1), 1),
                    "fail_rate": round(fails / max(count, 1) * 100, 1),
                }

        # Cognitive Tiers
        tier_usage = r.hgetall("kernell:metrics:tiers")
        tier_usage = {k: int(v) for k, v in tier_usage.items()}

        total_receipts = int(global_stats.get("total_receipts", 0))
        success_count = int(global_stats.get("success_count", 0))
        fail_count = int(global_stats.get("fail_count", 0))

        return {
            "total_receipts": total_receipts,
            "total_cost_usd": round(float(global_stats.get("total_cost_usd", 0.0)), 8),
            "total_tokens": int(global_stats.get("total_tokens", 0)),
            "success_count": success_count,
            "fail_count": fail_count,
            "success_rate": round(success_count / max(total_receipts, 1) * 100, 1),
            "burn_rate_usd_min": burn_rate,
            "requests_last_5min": recent_count,
            "providers": providers,
            "cognitive_tier_usage": tier_usage,
            "last_receipt_ts": global_stats.get("last_receipt_ts"),
            "ledger_integrity": global_stats.get("ledger_integrity", "unknown"),
        }
    except Exception as e:
        return {"error": str(e), "status": "redis_offline"}


@app.get("/api/cascades")
def get_cascades(limit: int = 20):
    try:
        raw = r.lrange("kernell:metrics:cascades", 0, limit - 1)
        return [json.loads(x) for x in raw]
    except Exception:
        return []


@app.get("/api/anomalies")
def get_anomalies(limit: int = 50):
    try:
        raw = r.lrange("kernell:security:economic_anomalies", 0, limit - 1)
        return [json.loads(x) for x in raw]
    except Exception:
        return []


@app.get("/api/receipts/recent")
def get_recent_receipts(count: int = 50):
    try:
        raw = r.lrange("kernell:metrics:recent_receipts", 0, count - 1)
        # Redis lrange returns newest first (since we use lpush), reverse it for chronological order
        receipts = [json.loads(x) for x in raw]
        receipts.reverse()
        return receipts
    except Exception:
        return []


@app.get("/api/health")
def health():
    try:
        return {
            "status": "ok",
            "redis_connected": r.ping(),
            "receipts_processed": r.hget("kernell:metrics:global", "total_receipts") or 0
        }
    except Exception:
        return {
            "status": "degraded",
            "redis_connected": False
        }


# ── WebSocket: Live Receipt Stream ───────────────────────────────────

@app.websocket("/ws/live")
async def websocket_live(websocket: WebSocket):
    await websocket.accept()
    
    # Use async redis client for pubsub
    async_r = redis_async.Redis(**r_kwargs)
    pubsub = async_r.pubsub()
    
    try:
        await pubsub.subscribe("kernell:live:receipts")
        
        while True:
            # Check for new messages from pubsub
            message = await pubsub.get_message(ignore_subscribe_messages=True, timeout=1.0)
            if message:
                try:
                    receipt = json.loads(message["data"])
                    await websocket.send_json({"type": "receipt", "data": receipt})
                except json.JSONDecodeError:
                    pass
            
            # Check for anomalies (we can just poll the latest one since they are rare)
            try:
                latest = r.lindex("kernell:security:economic_anomalies", 0)
                # Keep track of the last anomaly sent to avoid spam
                if latest:
                    # In a real app we'd use a cursor or ID, here we just send it if the WS is open
                    # A better way is to also publish anomalies to a pubsub channel
                    pass 
            except Exception:
                pass
            
            await asyncio.sleep(0.1)  # Yield control
            
    except WebSocketDisconnect:
        pass
    finally:
        await pubsub.unsubscribe("kernell:live:receipts")
        await pubsub.close()
        await async_r.aclose()


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8420)

