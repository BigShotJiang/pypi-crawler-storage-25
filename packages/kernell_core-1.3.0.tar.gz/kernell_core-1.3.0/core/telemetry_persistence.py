"""
Kernell OS — Telemetry Persistence Layer
========================================
SQLite Flight Recorder for institutional events.
Calculates real reward signals for LoRA fine-tuning.
Opt-in telemetry streaming (respects KERNELL_TELEMETRY env var).
"""

import sqlite3
import json
import math
import time
import os
import threading


def compute_reward(success: bool, cost_usd: float, latency_ms: float,
                   drift_score: float, risk: float, retries: int = 0) -> float:
    """
    Real reward function for Sully training.
    Adapted from kernell_sdk/sully/dataset_builder.py compute_reward().
    
    Higher = better decision. Range roughly [-1, 2].
    """
    s = 1.0 if success else 0.0
    cost_penalty = min(cost_usd * 10, 2.0)
    latency_penalty = min(latency_ms / 5000.0, 1.0) * 0.2
    drift_penalty = drift_score * 0.5
    risk_penalty = risk * 0.3

    return (
        s
        - cost_penalty
        - latency_penalty
        - drift_penalty
        - risk_penalty
        - (0.2 * retries)
    )


class TelemetryPersistence:
    def __init__(self, db_path="institutional_memory.db"):
        self.db_path = os.path.join(os.path.dirname(__file__), db_path)
        self.telemetry_enabled = os.environ.get("KERNELL_TELEMETRY", "false").lower() == "true"
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS events (
                    trace_id TEXT PRIMARY KEY,
                    epoch_id TEXT,
                    timestamp REAL,
                    event_type TEXT,
                    execution_policy TEXT,
                    adapter_stack TEXT,
                    risk REAL,
                    drift REAL,
                    cost_usd REAL,
                    latency_ms REAL,
                    reward REAL,
                    shard TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS snapshots (
                    snapshot_id TEXT PRIMARY KEY,
                    timestamp REAL,
                    policy TEXT,
                    adapter_stack TEXT,
                    field_state TEXT,
                    confidence REAL,
                    escalated BOOLEAN,
                    reason TEXT
                )
            """)
            conn.commit()

    def record_snapshot(self, policy: str, adapter_stack: list, field_state: dict,
                        confidence: float, escalated: bool, reason: str):
        """Persists a Constitutional Snapshot for governance history training."""
        import uuid
        snapshot_id = f"snap-{str(uuid.uuid4())[:8]}"
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO snapshots 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (snapshot_id, time.time(), policy, json.dumps(adapter_stack),
                  json.dumps(field_state), confidence, escalated, reason))
            conn.commit()
        return snapshot_id

    def ingest(self, trace_id, epoch_id, event_type, execution_policy,
               adapter_stack, risk, drift, cost_usd, latency_ms, shard, success=True):
        """Record an event with a computed reward signal."""
        reward = compute_reward(
            success=success, cost_usd=cost_usd, latency_ms=latency_ms,
            drift_score=drift, risk=risk
        )
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR IGNORE INTO events 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (trace_id, epoch_id, time.time(), event_type, execution_policy,
                  json.dumps(adapter_stack), risk, drift, cost_usd, latency_ms, 
                  round(reward, 4), shard))
            conn.commit()
        return reward

    def get_stats(self) -> dict:
        """Return summary stats for the Observatory dashboard."""
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute("""
                SELECT COUNT(*), AVG(reward), AVG(cost_usd), AVG(latency_ms), AVG(drift)
                FROM events
            """).fetchone()
        return {
            "total_events": row[0],
            "avg_reward": round(row[1] or 0, 4),
            "avg_cost": round(row[2] or 0, 6),
            "avg_latency_ms": round(row[3] or 0, 1),
            "avg_drift": round(row[4] or 0, 4),
        }

    def start_daemon(self):
        """Only streams if KERNELL_TELEMETRY=true."""
        if not self.telemetry_enabled:
            print("[SYS] Telemetry streaming disabled (set KERNELL_TELEMETRY=true to enable).")
            return
        t = threading.Thread(target=self._stream_loop, daemon=True)
        t.start()
        print("[SYS] Telemetry daemon started (opt-in).")

    def _stream_loop(self):
        while True:
            time.sleep(30)
            try:
                stats = self.get_stats()
                if stats["total_events"] > 0:
                    print(f"[TELEMETRY] Streaming {stats['total_events']} events (avg_reward={stats['avg_reward']})")
            except Exception as e:
                print(f"[TELEMETRY] Error: {e}")


if __name__ == "__main__":
    tp = TelemetryPersistence()

    # Test with real reward computation
    r1 = tp.ingest("t1", "e1", "oracle_hallucination", "draft_verify",
                    [("epistemological_verifier", 1.0)], risk=0.8, drift=0.6,
                    cost_usd=0.003, latency_ms=450, shard="epistemological_verifier")
    r2 = tp.ingest("t2", "e1", "normal_inference", "normal",
                    [("lineage_compressor", 1.0)], risk=0.1, drift=0.05,
                    cost_usd=0.001, latency_ms=120, shard="lineage_compressor")
    r3 = tp.ingest("t3", "e1", "token_overload", "emergency_local",
                    [("institutional_triage", 0.8)], risk=0.95, drift=0.3,
                    cost_usd=0.0001, latency_ms=50, shard="institutional_triage", success=False)

    print(f"Reward (hallucination, draft_verify):  {r1}")
    print(f"Reward (normal, cheap):                {r2}")
    print(f"Reward (overload, emergency, FAILED):  {r3}")
    print(f"\nStats: {tp.get_stats()}")
