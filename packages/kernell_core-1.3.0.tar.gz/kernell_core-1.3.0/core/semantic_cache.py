"""
Kernell OS — Semantic Execution Cache
=====================================
A hierarchical economic memory, not a probabilistic dumpster.
Caches verified reasoning fragments, task DAGs, and structural analyses.
Enforces a strict Cache Admission Policy to ensure we only store high-reward work.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib
from typing import Dict, Any, List, Optional
import math
import logging
import json
import os

try:
    from sentence_transformers import SentenceTransformer
    HAS_SENTENCE_TRANSFORMERS = True
except ImportError:
    HAS_SENTENCE_TRANSFORMERS = False
    logging.warning("sentence_transformers not installed. Semantic Cache will fallback to mock embeddings.")

@dataclass
class CacheFragment:
    fragment_id: str
    intent_class: str
    execution_profile: str
    semantic_embedding: List[float]
    input_signature: str
    output_payload: Dict[str, Any]
    
    # Governance & Quality Metrics
    reward_score: float
    drift_score: float
    verification_stage: str
    
    # Economics
    reuse_count: int = 0
    ttl_seconds: int = 86400 * 7 # 1 week by default
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    
    def to_dict(self):
        d = self.__dict__.copy()
        d["created_at"] = self.created_at.isoformat()
        return d
        
    @classmethod
    def from_dict(cls, data):
        data["created_at"] = datetime.fromisoformat(data["created_at"])
        return cls(**data)


class SemanticCache:
    def __init__(self, model_name: str = "BAAI/bge-small-en-v1.5", storage_path: str = "data/semantic_cache.json"):
        # In-memory dict for prototype, backed by a vector DB in production
        self._fragments: Dict[str, CacheFragment] = {}
        self.model_name = model_name
        self.storage_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), storage_path)
        self._embedder = None
        
        if HAS_SENTENCE_TRANSFORMERS:
            try:
                # Load small, fast local embedding model
                print(f"Loading local embedding model: {self.model_name}...")
                self._embedder = SentenceTransformer(self.model_name)
            except Exception as e:
                logging.error(f"Failed to load embedding model: {e}")
                
        self.load()

    def save(self):
        """Persist cache to disk."""
        os.makedirs(os.path.dirname(self.storage_path), exist_ok=True)
        with open(self.storage_path, "w") as f:
            json.dump({k: v.to_dict() for k, v in self._fragments.items()}, f)
            
    def load(self):
        """Load cache from disk."""
        if os.path.exists(self.storage_path):
            try:
                with open(self.storage_path, "r") as f:
                    data = json.load(f)
                    self._fragments = {k: CacheFragment.from_dict(v) for k, v in data.items()}
                print(f"Loaded {len(self._fragments)} fragments into Semantic Cache.")
            except Exception as e:
                logging.error(f"Error loading semantic cache: {e}")

    def _hash_input(self, payload: str) -> str:
        return hashlib.sha256(payload.encode('utf-8')).hexdigest()

    def _compute_embedding(self, text: str) -> List[float]:
        """Generates real local embeddings if available, else mocks."""
        if self._embedder:
            # We don't embed the full code, we embed the structural signature/intent 
            # (In production, the text here should already be summarized/AST-mapped)
            vec = self._embedder.encode(text[:5000]).tolist()
            return vec
            
        # Fallback placeholder
        return [0.1, 0.2, 0.3]
        
    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        # Mock distance calculation
        dot = sum(a*b for a, b in zip(vec1, vec2))
        mag1 = math.sqrt(sum(a*a for a in vec1))
        mag2 = math.sqrt(sum(b*b for b in vec2))
        if mag1 == 0 or mag2 == 0:
            return 0.0
        return dot / (mag1 * mag2)

    def check_structural_cache(self, intent_class: str, input_payload: str) -> Optional[CacheFragment]:
        """
        Layer 1: Structural Cache (O(1) lookup).
        Exact match on intent and input signature. Costs zero.
        """
        sig = self._hash_input(input_payload)
        for fragment in self._fragments.values():
            if fragment.intent_class == intent_class and fragment.input_signature == sig:
                fragment.reuse_count += 1
                return fragment
        return None

    def query_semantic_cache(self, intent_class: str, input_payload: str, threshold: float = 0.85) -> Optional[CacheFragment]:
        """
        Layer 2: Semantic Execution Cache (Vector lookup).
        Finds reasoning fragments that are semantically identical.
        """
        # Try structural first
        structural_hit = self.check_structural_cache(intent_class, input_payload)
        if structural_hit:
            return structural_hit
            
        target_embedding = self._compute_embedding(input_payload)
        best_match = None
        best_sim = -1.0
        
        for fragment in self._fragments.values():
            if fragment.intent_class != intent_class:
                continue
                
            sim = self._cosine_similarity(target_embedding, fragment.semantic_embedding)
            if sim >= threshold and sim > best_sim:
                best_sim = sim
                best_match = fragment
                
        if best_match:
            best_match.reuse_count += 1
            
        return best_match

    def admit_to_cache(self, fragment_id: str, intent_class: str, execution_profile: str, 
                       input_payload: str, output_payload: Dict[str, Any], 
                       reward_score: float, drift_score: float, verification_stage: str) -> bool:
        """
        CACHE ADMISSION POLICY
        Only verified, high-quality cognitive work enters the cache.
        """
        # Strict admission gates
        if reward_score < 0.8:
            return False
        if drift_score > 0.15:
            return False
        if verification_stage == "unverified" and execution_profile == "premium_verify":
            # If premium model failed to verify, don't cache
            return False
            
        # Passed admission
        embedding = self._compute_embedding(input_payload)
        sig = self._hash_input(input_payload)
        
        frag = CacheFragment(
            fragment_id=fragment_id,
            intent_class=intent_class,
            execution_profile=execution_profile,
            semantic_embedding=embedding,
            input_signature=sig,
            output_payload=output_payload,
            reward_score=reward_score,
            drift_score=drift_score,
            verification_stage=verification_stage
        )
        self._fragments[fragment_id] = frag
        self.save()
        return True

if __name__ == "__main__":
    cache = SemanticCache()
    
    # Simulate a bad inference (should be rejected)
    admitted = cache.admit_to_cache(
        "frag_1", "code_review", "premium_verify", "def bad(): pass", 
        {"issues": []}, reward_score=0.4, drift_score=0.5, verification_stage="failed"
    )
    print(f"Bad inference admitted: {admitted}")  # False
    
    # Simulate an excellent inference (should be admitted)
    admitted = cache.admit_to_cache(
        "frag_2", "code_review", "premium_verify", "def good(): return 42", 
        {"issues": []}, reward_score=0.92, drift_score=0.01, verification_stage="verified"
    )
    print(f"Good inference admitted: {admitted}")  # True
    
    # Test hit
    hit = cache.query_semantic_cache("code_review", "def good(): return 42")
    if hit:
        print(f"Cache Hit! Fragment ID: {hit.fragment_id}, Reuses: {hit.reuse_count}")
