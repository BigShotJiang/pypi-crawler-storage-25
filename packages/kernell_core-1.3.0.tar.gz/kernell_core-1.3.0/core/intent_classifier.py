"""
Kernell OS — Intent Classifier
==============================
Stage 1 of Multi-Stage Inference. Cost: almost zero.
Analyzes an incoming payload to determine the exact structural intent,
complexity, and risk without generating text or invoking premium models.

Output feeds into the Task Planner.
"""

import re
from typing import Dict, Any

class IntentClassifier:
    def __init__(self):
        # Heuristic rules for extremely fast, zero-inference classification
        self.risk_keywords = {"auth", "security", "payment", "encryption", "password", "crypto", "ledger"}
        self.structural_keywords = {"refactor", "architect", "split", "modularize", "rewrite"}
        self.verification_keywords = {"verify", "test", "audit", "check", "review"}
        
    def classify(self, prompt: str, payload_size_bytes: int = 0) -> Dict[str, Any]:
        """
        Heuristically classifies intent. In production, this can use a tiny
        local BERT-style model or fast embedder, but rules are cheaper.
        """
        prompt_lower = prompt.lower()
        words = set(re.findall(r'\w+', prompt_lower))
        
        # Determine intent category
        intent = "general_query"
        if words.intersection(self.structural_keywords):
            intent = "structural_refactor"
        elif words.intersection(self.verification_keywords):
            intent = "code_review"
        elif "explain" in words or "summarize" in words:
            intent = "summarization"
            
        # Determine complexity
        complexity = 0.2
        if payload_size_bytes > 10000 or len(words) > 200:
            complexity += 0.3
        if intent in ["structural_refactor", "code_review"]:
            complexity += 0.3
            
        # Determine risk level
        risk_level = "low"
        if words.intersection(self.risk_keywords):
            risk_level = "high"
            complexity += 0.2
        elif complexity > 0.6:
            risk_level = "medium"
            
        # Hard limits
        complexity = min(round(complexity, 2), 1.0)
        
        # Calculate cacheability (High risk = lower cacheability usually)
        cacheability = 0.9 if risk_level == "low" and intent == "summarization" else 0.4
        if intent == "structural_refactor":
            cacheability = 0.1 # AST changes are highly specific
            
        return {
            "intent": intent,
            "complexity": complexity,
            "risk_level": risk_level,
            "requires_verification": risk_level == "high" or complexity > 0.7,
            "cacheability": cacheability,
            "decomposable": intent in ["structural_refactor", "code_review"] or payload_size_bytes > 5000,
            "expected_reward_density": round(1.0 - (complexity * 0.3), 2)
        }

if __name__ == "__main__":
    classifier = IntentClassifier()
    
    prompts = [
        ("Summarize this README file.", 1500),
        ("Review this PR with 4200 LOC", 42000),
        ("Refactor the authentication controller into microservices.", 8000)
    ]
    
    print("--- Intent Classifier (Stage 1) ---")
    for p, size in prompts:
        res = classifier.classify(p, size)
        print(f"\nPrompt: '{p}'")
        for k, v in res.items():
            print(f"  {k}: {v}")
