"""
Kernell OS — Cognitive Budget Engine
====================================
Synthesizes execution policies under strict economic constraints.
Optimizes for: Verified Cognitive Yield per Constrained Dollar (VCY/USD).

The Hypervisor uses the output of the Budget Engine to govern execution.
"""

from dataclasses import dataclass
from typing import Dict, Any, Optional
from core.enterprise_sla import SLAGuarantee

POLICY_SCHEMA_VERSION = "v1"

@dataclass
class BudgetContext:
    session_budget_usd: float
    org_budget_remaining: float
    latency_slo_ms: int
    min_reward: float
    max_drift: float
    intent_class: str
    user_tier: str
    current_pressure: float
    historical_efficiency: float # Baseline VCY/USD
    effective_sla: Optional[SLAGuarantee] = None


@dataclass
class ExecutionBudgetPolicy:
    max_execution_tier: str
    verification_threshold: float
    decomposition_depth_limit: int
    cache_aggressiveness: float # 0.0 to 1.0
    escalation_cap_usd: float
    premium_token_budget: int
    planner_strategy: str # "cost_optimized", "latency_optimized", "quality_optimized"


class BudgetEngine:
    def __init__(self):
        # Baseline tuning weights (can be updated via Replay Simulator feedback)
        self._target_vcy_usd = 150.0 

    def synthesize_policy(self, context: BudgetContext) -> ExecutionBudgetPolicy:
        """
        Determines the optimal execution boundaries to maximize VCY/USD 
        while respecting SLA and budget constraints.
        """
        
        # 1. Base Budget Guardrails
        if context.org_budget_remaining <= 0 or context.session_budget_usd <= 0:
            return ExecutionBudgetPolicy(
                max_execution_tier="zero_inference",
                verification_threshold=1.0, # Never verify
                decomposition_depth_limit=1,
                cache_aggressiveness=1.0,
                escalation_cap_usd=0.0,
                premium_token_budget=0,
                planner_strategy="cache_only"
            )

        # 2. Intent-based Dynamic Verification
        # High risk intents mandate tighter thresholds
        base_threshold = 0.70
        planner_strategy = "cost_optimized"
        
        if context.intent_class in ["auth", "security", "payment", "crypto", "ledger"]:
            base_threshold = 0.85 # Mandatory high verification
            planner_strategy = "quality_optimized"
            max_tier = "premium_verify"
        elif context.intent_class in ["summarization", "formatting", "general_query"]:
            base_threshold = 0.50 # Loose verification
            max_tier = "local_reasoning"
        else:
            base_threshold = 0.75
            max_tier = "premium_draft"

        # 3. Pressure & Latency Adjustments
        if context.current_pressure > 0.8 or context.latency_slo_ms < 1000:
            planner_strategy = "latency_optimized"
            cache_agg = 0.9
            depth_limit = 2
        else:
            cache_agg = 0.6 if context.intent_class != "structural_refactor" else 0.2
            depth_limit = 5

        # 4. User Tier Economics
        if context.user_tier == "enterprise_premium":
            max_tier = "premium_verify"
            escalation_cap = min(context.session_budget_usd, 0.50) # Allow up to $0.50 per query
            premium_tokens = 32000
        else:
            escalation_cap = min(context.session_budget_usd, 0.05) # Restrict to $0.05
            premium_tokens = 4000

        # 5. Drift Suppression & SLA Enforcements
        if context.max_drift < 0.1:
            base_threshold = min(0.95, base_threshold + 0.1)
            
        if context.effective_sla:
            # Constrain by Enterprise SLA
            if context.effective_sla.max_premium_escalation_pct < 0.1:
                # Tight escalation cap
                escalation_cap = min(escalation_cap, 0.01)
                base_threshold = max(base_threshold, 0.85) # Verify less often to save premium, or demand high confidence locally
            if context.latency_slo_ms > context.effective_sla.max_latency_p95_ms:
                planner_strategy = "latency_optimized"

        return ExecutionBudgetPolicy(
            max_execution_tier=max_tier,
            verification_threshold=base_threshold,
            decomposition_depth_limit=depth_limit,
            cache_aggressiveness=cache_agg,
            escalation_cap_usd=escalation_cap,
            premium_token_budget=premium_tokens,
            planner_strategy=planner_strategy
        )

if __name__ == "__main__":
    engine = BudgetEngine()
    
    # Simulate a Junior Dev doing summarization under tight budget
    ctx_junior = BudgetContext(
        session_budget_usd=0.02,
        org_budget_remaining=100.0,
        latency_slo_ms=5000,
        min_reward=0.6,
        max_drift=0.4,
        intent_class="summarization",
        user_tier="standard",
        current_pressure=0.9,
        historical_efficiency=120.0
    )
    
    # Simulate a CI Pipeline doing security audit
    ctx_ci = BudgetContext(
        session_budget_usd=2.00,
        org_budget_remaining=5000.0,
        latency_slo_ms=30000,
        min_reward=0.9,
        max_drift=0.05, # Strict drift limits
        intent_class="security",
        user_tier="enterprise_premium",
        current_pressure=0.2,
        historical_efficiency=80.0
    )
    
    print("--- Budget Engine Policy Synthesis ---")
    
    print("\n[Scenario 1] Junior Dev / Summarization / High Pressure:")
    pol1 = engine.synthesize_policy(ctx_junior)
    for k, v in pol1.__dict__.items():
        print(f"  {k}: {v}")
        
    print("\n[Scenario 2] CI Pipeline / Security / Low Drift Tolerance:")
    pol2 = engine.synthesize_policy(ctx_ci)
    for k, v in pol2.__dict__.items():
        print(f"  {k}: {v}")
