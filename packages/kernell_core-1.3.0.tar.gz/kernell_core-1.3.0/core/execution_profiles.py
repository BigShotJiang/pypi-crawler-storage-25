"""
Kernell OS — Execution Profiles
=================================
Defines the institutional execution tiers. The Hypervisor governs profiles,
NOT specific models, avoiding vendor lock-in and allowing dynamic routing.
"""

from enum import Enum
from dataclasses import dataclass
from typing import List, Optional

class ExecutionTier(Enum):
    ZERO_INFERENCE = "zero_inference"   # Cache hits, rules, AST parsing
    LOCAL_FAST = "local_fast"           # Small local models (Llama-3-8B)
    LOCAL_REASONING = "local_reasoning" # Mid-size local models (Mixtral 8x7B)
    PREMIUM_DRAFT = "premium_draft"     # Hosted fast models (GPT-3.5, Haiku)
    PREMIUM_VERIFY = "premium_verify"   # Hosted reasoning models (GPT-4, Opus)

@dataclass
class ExecutionProfile:
    tier: ExecutionTier
    estimated_cost_per_1k: float
    max_context_window: int
    allowed_for_high_risk: bool
    requires_verification: bool
    description: str

# The institutional map of execution profiles
PROFILES = {
    ExecutionTier.ZERO_INFERENCE: ExecutionProfile(
        tier=ExecutionTier.ZERO_INFERENCE,
        estimated_cost_per_1k=0.0,
        max_context_window=1000000,
        allowed_for_high_risk=True,  # Deterministic logic is safe
        requires_verification=False,
        description="Deterministic AST parsers, rule engines, and semantic cache."
    ),
    ExecutionTier.LOCAL_FAST: ExecutionProfile(
        tier=ExecutionTier.LOCAL_FAST,
        estimated_cost_per_1k=0.0001,
        max_context_window=8192,
        allowed_for_high_risk=False,
        requires_verification=True,
        description="Fast, cheap local models for summarization and formatting."
    ),
    ExecutionTier.LOCAL_REASONING: ExecutionProfile(
        tier=ExecutionTier.LOCAL_REASONING,
        estimated_cost_per_1k=0.0005,
        max_context_window=32768,
        allowed_for_high_risk=False,
        requires_verification=True,
        description="Mid-tier local models for standard structural logic."
    ),
    ExecutionTier.PREMIUM_DRAFT: ExecutionProfile(
        tier=ExecutionTier.PREMIUM_DRAFT,
        estimated_cost_per_1k=0.0015,
        max_context_window=128000,
        allowed_for_high_risk=False,
        requires_verification=True,
        description="Hosted fast models for broad context gathering."
    ),
    ExecutionTier.PREMIUM_VERIFY: ExecutionProfile(
        tier=ExecutionTier.PREMIUM_VERIFY,
        estimated_cost_per_1k=0.03,
        max_context_window=128000,
        allowed_for_high_risk=True,
        requires_verification=False,
        description="Expensive frontier models used ONLY for critical verification and high-risk reasoning."
    )
}

def get_profile(tier: ExecutionTier) -> ExecutionProfile:
    return PROFILES[tier]
