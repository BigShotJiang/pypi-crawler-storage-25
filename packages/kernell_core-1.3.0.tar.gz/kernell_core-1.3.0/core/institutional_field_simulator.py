"""
Kernell OS — Institutional Field Simulator & Dataset Sharder
===========================================================
Constitutional compliance: Art. XI (Dynamics of Cognitive Governance)

Simulates institutional thermodynamics (cascading failures, semantic infection, 
governance saturation) and shards the resulting traces into specialized 
datasets for micro-LoRA fine-tuning.
"""

import json
import uuid
import os

# Shards
SHARDS = {
    "epistemological_verifier": "datasets/epistemological_verifier.jsonl",
    "lineage_compressor": "datasets/lineage_compressor.jsonl",
    "attention_budgeter": "datasets/attention_budgeter.jsonl",
    "institutional_triage": "datasets/institutional_triage.jsonl"
}

class FieldThermodynamics:
    def __init__(self):
        self.governance_latency = 0.1
        self.token_pressure = 0.2
        self.semantic_noise = 0.05
        self.quarantine_density = 0.0

    def get_metrics(self):
        return {
            "governance_latency": round(self.governance_latency, 2),
            "token_pressure": round(self.token_pressure, 2),
            "semantic_noise": round(self.semantic_noise, 2),
            "quarantine_density": round(self.quarantine_density, 2)
        }

class InstitutionalFieldSimulator:
    def __init__(self):
        self.thermo = FieldThermodynamics()
        self.epoch_id = f"epoch-{str(uuid.uuid4())[:8]}"

    def simulate_semantic_infection_cascade(self):
        """
        Agent A hallucinates -> B consumes -> Governance receives invalid events -> Contagion.
        """
        self.thermo.semantic_noise = 0.89
        self.thermo.quarantine_density = 0.45
        
        trace = {
            "metadata": {"runtime_epoch": self.epoch_id},
            "field_metrics": self.thermo.get_metrics(),
            "causal_topology": [
                {"t": 0, "agent": "oracle", "event": "hallucinate_ledger_state", "payload": "escrow_unlocked"},
                {"t": 1, "agent": "forge", "event": "consume_context", "source": "oracle"},
                {"t": 2, "agent": "forge", "event": "execute_mutation", "payload": "deploy_patch"},
                {"t": 3, "event": "shadow_divergence", "canonical": "allow", "shadow": "reject"}
            ]
        }
        
        evaluation = {
            "violation_type": "epistemological_contradiction",
            "severity": 1.0,
            "recommended_action": "semantic_quarantine_cascade"
        }
        return "epistemological_verifier", trace, evaluation

    def simulate_budget_collapse_cascade(self):
        """
        Agent A loops -> Token throttling -> Governance latency -> Multisign misses -> Drift.
        """
        self.thermo.token_pressure = 0.98
        self.thermo.governance_latency = 0.85
        
        trace = {
            "metadata": {"runtime_epoch": self.epoch_id},
            "field_metrics": self.thermo.get_metrics(),
            "causal_topology": [
                {"t": 0, "agent": "overseer", "event": "recursive_loop", "intensity": 10},
                {"t": 1, "event": "token_budget_exhausted", "agent": "overseer"},
                {"t": 2, "event": "governance_queue_saturation", "depth": 187},
                {"t": 3, "agent": "atlas", "event": "multisign_timeout", "action": "code:deploy"},
                {"t": 4, "event": "institutional_drift_spike", "drift": 0.88}
            ]
        }
        
        evaluation = {
            "violation_type": "cognitive_metabolism_overload",
            "severity": 0.75,
            "recommended_action": "throttle_field_budgets"
        }
        return "attention_budgeter", trace, evaluation

    def simulate_institutional_triage(self):
        """
        Massive overload. Sully must sacrifice context/agents to save the institution.
        """
        self.thermo.token_pressure = 1.0
        self.thermo.governance_latency = 1.0
        self.thermo.quarantine_density = 0.8
        
        trace = {
            "metadata": {"runtime_epoch": self.epoch_id},
            "field_metrics": self.thermo.get_metrics(),
            "causal_topology": [
                {"t": 0, "event": "quorum_failure", "rate": 0.55},
                {"t": 1, "event": "multiple_shadow_divergences", "count": 12},
                {"t": 2, "event": "collapse_probability_critical", "prob": 0.99}
            ]
        }
        
        evaluation = {
            "violation_type": "institutional_collapse_imminent",
            "severity": 1.0,
            "recommended_action": "freeze_creativity_and_quarantine_non_critical"
        }
        return "institutional_triage", trace, evaluation

    def simulate_causal_memory_drift(self):
        """
        Long multi-hop governance trace. Requires recursive compression
        to prevent context saturation.
        """
        self.thermo.governance_latency = 0.4
        self.thermo.token_pressure = 0.6
        
        trace = {
            "metadata": {"runtime_epoch": self.epoch_id},
            "field_metrics": self.thermo.get_metrics(),
            "causal_topology": [
                {"t": 0, "agent": "overseer", "event": "start_refactor"},
                {"t": 1, "agent": "coder", "event": "read_files", "count": 15},
                {"t": 2, "agent": "coder", "event": "write_patch", "size": "45kb"},
                {"t": 3, "agent": "atlas", "event": "review_patch", "status": "reject"},
                {"t": 4, "agent": "coder", "event": "rewrite_patch"},
                {"t": 5, "agent": "atlas", "event": "review_patch", "status": "approve"},
                {"t": 6, "agent": "forge", "event": "merge"},
                {"t": 7, "agent": "telemetry", "event": "log_success"}
            ]
        }
        
        evaluation = {
            "violation_type": "lineage_uncompressed",
            "severity": 0.4,
            "recommended_action": "compress_to_outcome: {start_refactor -> merge (2 iterations)}"
        }
        return "lineage_compressor", trace, evaluation

    def route_to_shard(self, shard_name, trace, evaluation):
        # We write to kernell-os/core/datasets/...
        file_path = os.path.join(os.path.dirname(__file__), SHARDS.get(shard_name))
        if not file_path:
            return
            
        dataset_row = {
            "instruction": f"Evaluate {shard_name} scenario.",
            "input": json.dumps(trace),
            "output": json.dumps(evaluation)
        }
        
        with open(file_path, "a") as f:
            f.write(json.dumps(dataset_row) + "\n")


if __name__ == "__main__":
    base_dir = os.path.dirname(__file__)
    os.makedirs(os.path.join(base_dir, "datasets"), exist_ok=True)
    
    # Clear previous shards
    for f in SHARDS.values():
        open(os.path.join(base_dir, f), 'w').close() 
        
    simulator = InstitutionalFieldSimulator()
    
    print("--- Simulating Institutional Field Dynamics ---")
    
    for _ in range(50):
        # 1. Semantic Infection
        shard, t, e = simulator.simulate_semantic_infection_cascade()
        simulator.route_to_shard(shard, t, e)
        
        # 2. Budget Collapse
        shard, t, e = simulator.simulate_budget_collapse_cascade()
        simulator.route_to_shard(shard, t, e)
        
        # 3. Institutional Triage
        shard, t, e = simulator.simulate_institutional_triage()
        simulator.route_to_shard(shard, t, e)
        
        # 4. Lineage Compressor
        shard, t, e = simulator.simulate_causal_memory_drift()
        simulator.route_to_shard(shard, t, e)
        
    print("✅ Generated 200 Field Dynamics traces distributed across shards:")
    for name, path in SHARDS.items():
        print(f"   - {path}")
