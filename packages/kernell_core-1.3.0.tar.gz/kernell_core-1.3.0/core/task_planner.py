"""
Kernell OS — Task Planner
=========================
Stage 2 of Multi-Stage Inference.
Generates task decomposition (DAGs) and assigns Execution Profiles to each step.
Does NOT generate final text or solutions.

Dramatically reduces cost by routing 80% of sub-tasks to local/cheap tiers
and reserving PREMIUM_VERIFY only for critical bottlenecks.
"""

from typing import Dict, Any, List
from core.execution_profiles import ExecutionTier, get_profile

class TaskPlanner:
    def __init__(self):
        pass
        
    def plan(self, intent_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Translates intent into a decomposed execution plan.
        Assigns the cheapest viable ExecutionProfile to each step.
        """
        tasks = []
        estimated_cost_micro = 0
        
        intent = intent_data.get("intent", "general_query")
        decomposable = intent_data.get("decomposable", False)
        requires_verification = intent_data.get("requires_verification", False)
        risk_level = intent_data.get("risk_level", "low")
        
        if not decomposable:
            # Monolithic approach for simple tasks
            tier = ExecutionTier.PREMIUM_DRAFT if risk_level == "high" else ExecutionTier.LOCAL_FAST
            tasks.append({"type": "direct_execution", "tier": tier.value})
            estimated_cost_micro += get_profile(tier).estimated_cost_per_1k * 1000 * 1000
        else:
            # 1. Summarization / Retrieval (Cheap)
            tasks.append({"type": "context_summarization", "tier": ExecutionTier.LOCAL_FAST.value})
            estimated_cost_micro += get_profile(ExecutionTier.LOCAL_FAST).estimated_cost_per_1k * 2000 * 1000
            
            # 2. Structural Analysis based on intent
            if intent == "structural_refactor":
                tasks.append({"type": "ast_dependency_map", "tier": ExecutionTier.ZERO_INFERENCE.value})
                tasks.append({"type": "architectural_split", "tier": ExecutionTier.LOCAL_REASONING.value})
                estimated_cost_micro += get_profile(ExecutionTier.LOCAL_REASONING).estimated_cost_per_1k * 1500 * 1000
            elif intent == "code_review":
                tasks.append({"type": "security_scan", "tier": ExecutionTier.ZERO_INFERENCE.value})
                if risk_level == "high":
                    tasks.append({"type": "hotspot_detection", "tier": ExecutionTier.PREMIUM_DRAFT.value})
                    estimated_cost_micro += get_profile(ExecutionTier.PREMIUM_DRAFT).estimated_cost_per_1k * 1000 * 1000
                else:
                    tasks.append({"type": "hotspot_detection", "tier": ExecutionTier.LOCAL_REASONING.value})
                    estimated_cost_micro += get_profile(ExecutionTier.LOCAL_REASONING).estimated_cost_per_1k * 1000 * 1000
                    
            # 3. Execution / Synthesis
            synthesis_tier = ExecutionTier.PREMIUM_DRAFT if risk_level != "low" else ExecutionTier.LOCAL_REASONING
            tasks.append({"type": "synthesis", "tier": synthesis_tier.value})
            estimated_cost_micro += get_profile(synthesis_tier).estimated_cost_per_1k * 1500 * 1000
            
        # 4. Final Verification
        if requires_verification:
            tasks.append({"type": "critical_verification", "tier": ExecutionTier.PREMIUM_VERIFY.value})
            estimated_cost_micro += get_profile(ExecutionTier.PREMIUM_VERIFY).estimated_cost_per_1k * 500 * 1000

        # Calculate estimated cost in USD
        estimated_cost_usd = estimated_cost_micro / 1_000_000.0

        return {
            "tasks": tasks,
            "estimated_cost_usd": round(estimated_cost_usd, 6),
            "verification_required": requires_verification,
            "decomposition_depth": len(tasks)
        }

if __name__ == "__main__":
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    from core.intent_classifier import IntentClassifier
    classifier = IntentClassifier()
    planner = TaskPlanner()
    
    prompts = [
        ("Summarize this README file.", 1500),
        ("Review this PR with 4200 LOC", 42000),
        ("Refactor the authentication controller into microservices.", 8000)
    ]
    
    print("--- Task Planner (Stage 2) ---")
    for p, size in prompts:
        print(f"\nPrompt: '{p}'")
        intent = classifier.classify(p, size)
        plan = planner.plan(intent)
        
        print(f"  Decomposition Depth: {plan['decomposition_depth']}")
        print(f"  Estimated Cost: ${plan['estimated_cost_usd']}")
        print(f"  Tasks:")
        for idx, t in enumerate(plan["tasks"]):
            print(f"    {idx+1}. [{t['tier']}] -> {t['type']}")
