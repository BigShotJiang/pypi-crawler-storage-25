"""
Kernell OS — Replay Simulator
=============================
Answers the question: "What would have happened if we changed the thresholds?"
Takes historical traces from the Flight Recorder and simulates alternative
economics (cost, reward, escalation frequency) without running real inferences.
"""

from typing import List, Dict, Any

class ReplaySimulator:
    def __init__(self):
        pass
        
    def simulate(self, historical_traces: List[Dict[str, Any]], alternative_config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Replays traces through new rules.
        """
        new_threshold = alternative_config.get("early_exit_threshold", 0.75)
        
        orig_cost = 0.0
        orig_reward = 0.0
        orig_escalations = 0
        
        sim_cost = 0.0
        sim_reward = 0.0
        sim_escalations = 0
        
        for trace in historical_traces:
            orig_cost += trace.get("cost_usd", 0.0)
            orig_reward += trace.get("reward", 0.0)
            if trace.get("escalated", False):
                orig_escalations += 1
                
            # Simulate the alternative reality
            # If the original confidence was below the NEW threshold, it escalates.
            confidence = trace.get("confidence", 1.0)
            base_cost = trace.get("base_cost", 0.0001)
            premium_cost = trace.get("premium_cost", 0.003)
            
            if confidence < new_threshold:
                # Escalates in simulation
                sim_escalations += 1
                sim_cost += premium_cost
                # Reward goes up when escalated
                sim_reward += min(1.0, trace.get("reward", 0.5) + 0.3)
            else:
                # Does not escalate
                sim_cost += base_cost
                sim_reward += trace.get("reward", 0.5)
                
        num_traces = max(1, len(historical_traces))
                
        return {
            "historical": {
                "total_cost": orig_cost,
                "avg_reward": orig_reward / num_traces,
                "escalation_rate": orig_escalations / num_traces
            },
            "simulated": {
                "total_cost": sim_cost,
                "avg_reward": sim_reward / num_traces,
                "escalation_rate": sim_escalations / num_traces
            },
            "delta_cost_pct": ((sim_cost - orig_cost) / orig_cost) * 100 if orig_cost > 0 else 0,
            "delta_reward": (sim_reward - orig_reward) / num_traces
        }

if __name__ == "__main__":
    simulator = ReplaySimulator()
    
    # Mock traces from Flight Recorder
    historical_traces = [
        {"trace_id": "1", "confidence": 0.8, "escalated": False, "cost_usd": 0.0001, "reward": 0.6, "base_cost": 0.0001, "premium_cost": 0.003},
        {"trace_id": "2", "confidence": 0.6, "escalated": True, "cost_usd": 0.0031, "reward": 0.9, "base_cost": 0.0001, "premium_cost": 0.003},
        {"trace_id": "3", "confidence": 0.9, "escalated": False, "cost_usd": 0.0001, "reward": 0.8, "base_cost": 0.0001, "premium_cost": 0.003},
        {"trace_id": "4", "confidence": 0.72, "escalated": False, "cost_usd": 0.0001, "reward": 0.4, "base_cost": 0.0001, "premium_cost": 0.003},
    ]
    
    print("--- Replay Simulator ---")
    print("What if we increased safety (early_exit_threshold = 0.85)?")
    
    results = simulator.simulate(historical_traces, {"early_exit_threshold": 0.85})
    
    print(f"\nHistorical Cost: ${results['historical']['total_cost']:.4f}")
    print(f"Historical Reward: {results['historical']['avg_reward']:.2f}")
    print(f"Historical Escalation Rate: {results['historical']['escalation_rate']*100:.1f}%\n")
    
    print(f"Simulated Cost: ${results['simulated']['total_cost']:.4f}")
    print(f"Simulated Reward: {results['simulated']['avg_reward']:.2f}")
    print(f"Simulated Escalation Rate: {results['simulated']['escalation_rate']*100:.1f}%\n")
    
    print(f"Cost Change: {results['delta_cost_pct']:+.1f}%")
    print(f"Reward Change: {results['delta_reward']:+.2f}")
