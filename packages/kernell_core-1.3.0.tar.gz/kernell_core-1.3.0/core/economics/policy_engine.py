import json
import hashlib
from typing import List, Dict, Optional
from enum import Enum

class DenialReason(Enum):
    TIER_VIOLATION = "TIER_VIOLATION"
    MAX_RETRY_DEPTH_EXCEEDED = "MAX_RETRY_DEPTH_EXCEEDED"
    INVALID_RUNTIME_STATE = "INVALID_RUNTIME_STATE"
    SURVIVAL_ENVELOPE_VIOLATION = "SURVIVAL_ENVELOPE_VIOLATION"
    COST_EXCEEDS_BUDGET = "COST_EXCEEDS_BUDGET"
    LOW_CONFIDENCE_ESTIMATE = "LOW_CONFIDENCE_ESTIMATE"
    RUNTIME_BACKPRESSURE = "RUNTIME_BACKPRESSURE"
    QUARANTINED = "QUARANTINED"
    TENANT_BUDGET_EXHAUSTED = "TENANT_BUDGET_EXHAUSTED"

class EconomicPolicy:
    """
    Immutable Policy Object.
    Governs execution constraints based on tenant and cognitive state.
    """
    def __init__(self, policy_data: dict):
        self.policy_id = policy_data.get("policy_id", "default-policy")
        self.policy_version = int(policy_data.get("policy_version", 1))
        self.max_request_cost = float(policy_data.get("max_request_cost", 0.05))
        self.max_survival_cost = float(policy_data.get("max_survival_cost", 0.25))
        self.max_retry_depth = int(policy_data.get("max_retry_depth", 3))
        self.allowed_tiers = set(policy_data.get("allowed_tiers", [0, 1, 2, 3, 4, 5]))
        self.fallback_floor = int(policy_data.get("fallback_floor", 4))
        self.quarantine_threshold = float(policy_data.get("quarantine_threshold", 0.72))
        
        # Survival Envelopes map RuntimeState to allowed execution bounds
        self.survival_envelopes = policy_data.get("survival_envelopes", {
            "HEALTHY": {"allowed_tiers": [0, 1, 2, 3], "max_cost": self.max_request_cost, "min_confidence": 0.50},
            "DEGRADED": {"allowed_tiers": [1, 2, 3, 4], "max_cost": self.max_request_cost * 0.5, "min_confidence": 0.70},
            "SURVIVAL": {"allowed_tiers": [3, 4, 5], "max_cost": self.max_survival_cost, "min_confidence": 0.85},
            "RECOVERING": {"allowed_tiers": [2, 3, 4], "max_cost": self.max_request_cost * 0.25, "min_confidence": 0.80}
        })
        
        # Ensure policy is mathematically frozen
        canonical = json.dumps(policy_data, sort_keys=True, separators=(',', ':'))
        self.policy_hash = hashlib.sha256(canonical.encode()).hexdigest()

    def as_dict(self):
        return {
            "policy_id": self.policy_id,
            "policy_version": self.policy_version,
            "policy_hash": self.policy_hash,
            "max_request_cost": self.max_request_cost,
            "max_survival_cost": self.max_survival_cost,
            "max_retry_depth": self.max_retry_depth,
            "allowed_tiers": list(self.allowed_tiers),
            "fallback_floor": self.fallback_floor,
            "quarantine_threshold": self.quarantine_threshold,
            "survival_envelopes": self.survival_envelopes
        }

class PolicyEngine:
    """
    Evaluates Execution Requests against the Immutable Policy Object.
    Transitions runtime from Reactive to Preventive.
    """
    def __init__(self, policy: EconomicPolicy):
        self.policy = policy
    
    def evaluate_request(self, runtime_state: str, requested_tier: int, model: str, estimated_cost: float, retry_depth: int, prompt_hash: str) -> dict:
        """
        Pre-execution resolution check.
        Returns a decision payload that can be directly recorded in the WAL.
        """
        
        # Compute Execution Intent Hash
        canonical_intent = f"{model}:{requested_tier}:{prompt_hash}:{self.policy.policy_hash}:{runtime_state}"
        intent_hash = hashlib.sha256(canonical_intent.encode()).hexdigest()
        
        # Estimate Cost Confidence (heuristic based on model type)
        cost_confidence = 0.95 if "ollama" in model.lower() or "local" in model.lower() else 0.70
        if "reasoning" in model.lower() or "o1" in model.lower() or "o3" in model.lower():
            cost_confidence = 0.40  # Highly unpredictable token usage
            
        # 1. Global Tier Check
        if requested_tier not in self.policy.allowed_tiers:
            return self._reject(DenialReason.TIER_VIOLATION, estimated_cost, cost_confidence, intent_hash)
            
        # 2. Retry Depth Check
        if retry_depth > self.policy.max_retry_depth:
            return self._reject(DenialReason.MAX_RETRY_DEPTH_EXCEEDED, estimated_cost, cost_confidence, intent_hash)
            
        # 3. Survival Envelope Enforcement
        envelope = self.policy.survival_envelopes.get(runtime_state)
        if not envelope:
            return self._reject(DenialReason.INVALID_RUNTIME_STATE, estimated_cost, cost_confidence, intent_hash)
            
        if requested_tier not in envelope["allowed_tiers"]:
            return self._reject(DenialReason.SURVIVAL_ENVELOPE_VIOLATION, estimated_cost, cost_confidence, intent_hash, expected_tiers=envelope["allowed_tiers"])
            
        if estimated_cost > envelope["max_cost"]:
            return self._reject(DenialReason.COST_EXCEEDS_BUDGET, estimated_cost, cost_confidence, intent_hash, allowed_cost=envelope["max_cost"])
            
        if cost_confidence < envelope.get("min_confidence", 0.0):
            return self._reject(DenialReason.LOW_CONFIDENCE_ESTIMATE, estimated_cost, cost_confidence, intent_hash, required_confidence=envelope["min_confidence"])
            
        # 4. Success -> Approved
        return {
            "type": "policy_resolution",
            "decision": "approved",
            "policy_id": self.policy.policy_id,
            "policy_version": self.policy.policy_version,
            "policy_hash": self.policy.policy_hash,
            "intent_hash": intent_hash,
            "estimated_cost": f"{estimated_cost:.8f}",
            "cost_confidence": cost_confidence,
            "runtime_state": runtime_state
        }

    def _reject(self, reason: DenialReason, estimated_cost: float, cost_confidence: float, intent_hash: str, **kwargs) -> dict:
        payload = {
            "type": "policy_resolution",
            "decision": "rejected",
            "reason": reason.value,
            "policy_id": self.policy.policy_id,
            "policy_version": self.policy.policy_version,
            "policy_hash": self.policy.policy_hash,
            "intent_hash": intent_hash,
            "estimated_cost": f"{estimated_cost:.8f}",
            "cost_confidence": cost_confidence
        }
        payload.update(kwargs)
        return payload
