import json
import hashlib
from typing import Dict, Any
from core.runtime.invariants.base import RuntimeInvariant, InvariantViolation

class HashIntegrityInvariant(RuntimeInvariant):
    """
    ∀ receipt: hash(canonical(receipt_without_hash)) == receipt.hash
    AND prev_hash == hash(receipt_n-1)
    """
    
    @property
    def name(self) -> str:
        return "HASH_INTEGRITY"
        
    @property
    def severity(self) -> str:
        return "critical"
        
    def evaluate(self, receipt: Dict[str, Any], global_state: Dict[str, Any]) -> None:
        if "hash" not in receipt:
            return
            
        stored_hash = receipt["hash"]
        prev_hash = receipt.get("prev_hash")
        violation = None
        
        # 1. Verify prev_hash link
        expected_prev = global_state.get("last_verified_hash", "genesis")
        if prev_hash and expected_prev != "genesis" and prev_hash != expected_prev:
            violation = InvariantViolation(
                self.name,
                f"Hash chain break. Expected prev_hash={expected_prev}, got {prev_hash}",
                {"expected_prev": expected_prev, "actual_prev": prev_hash, "seq": receipt.get("seq")}
            )
            
        # 2. Verify payload hash
        payload_copy = receipt.copy()
        payload_copy.pop("hash", None)
        canonical = json.dumps(payload_copy, sort_keys=True, separators=(',', ':'))
        computed_hash = hashlib.sha256(canonical.encode()).hexdigest()[:32]
        
        if computed_hash != stored_hash and violation is None:
            violation = InvariantViolation(
                self.name,
                f"Payload hash mismatch. Computed={computed_hash}, Stored={stored_hash}",
                {"computed_hash": computed_hash, "stored_hash": stored_hash, "seq": receipt.get("seq")}
            )
            
        # ALWAYS advance the chain tracker to prevent cascading false positives
        global_state["last_verified_hash"] = stored_hash
        
        if violation:
            raise violation
