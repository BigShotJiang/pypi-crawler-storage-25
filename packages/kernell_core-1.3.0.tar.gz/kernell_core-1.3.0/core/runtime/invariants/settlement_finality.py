from typing import Dict, Any
from core.runtime.invariants.base import RuntimeInvariant, InvariantViolation

class SettlementFinalityInvariant(RuntimeInvariant):
    """
    Finalized settlements cannot revert to pending, nor can a single intent_hash
    have multiple settlements.
    """
    
    @property
    def name(self) -> str:
        return "SETTLEMENT_FINALITY"
        
    @property
    def severity(self) -> str:
        return "critical"
        
    def evaluate(self, receipt: Dict[str, Any], global_state: Dict[str, Any]) -> None:
        if "finalized_intents" not in global_state:
            global_state["finalized_intents"] = set()
            
        r_type = receipt.get("type")
        intent_hash = receipt.get("intent_hash")
        
        if not intent_hash or r_type != "execution_settlement":
            return
            
        status = receipt.get("settlement_status", "finalized")
        tenant = receipt.get("tenant_id", "default")
        global_key = f"{tenant}:{intent_hash}"
        
        if status == "finalized":
            if global_key in global_state["finalized_intents"]:
                raise InvariantViolation(
                    self.name,
                    f"Double settlement detected for intent_hash={intent_hash}",
                    {"intent_hash": intent_hash, "tenant_id": tenant}
                )
            global_state["finalized_intents"].add(global_key)
