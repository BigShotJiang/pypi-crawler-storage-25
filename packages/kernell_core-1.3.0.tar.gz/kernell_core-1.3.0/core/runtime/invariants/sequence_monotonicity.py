from typing import Dict, Any
from core.runtime.invariants.base import RuntimeInvariant, InvariantViolation

class SequenceMonotonicityInvariant(RuntimeInvariant):
    """
    ∀ seq: seq(n) > seq(n-1)
    Sequence numbers must strictly monotonically increase. 
    A violation implies race conditions, dirty file rolls, or simultaneous writes.
    """
    
    @property
    def name(self) -> str:
        return "SEQUENCE_MONOTONICITY"
        
    @property
    def severity(self) -> str:
        return "critical"
        
    def evaluate(self, receipt: Dict[str, Any], global_state: Dict[str, Any]) -> None:
        seq = receipt.get("seq")
        if seq is None:
            return
            
        last_seq = global_state.get("last_seen_seq", 0)
        violation = None
        
        if seq <= last_seq and last_seq != 0:
            violation = InvariantViolation(
                self.name,
                f"Sequence broken. Expected > {last_seq}, got {seq}",
                {"last_seq": last_seq, "current_seq": seq}
            )
            
        # ALWAYS advance to prevent cascading false positives
        global_state["last_seen_seq"] = seq
        
        if violation:
            raise violation
