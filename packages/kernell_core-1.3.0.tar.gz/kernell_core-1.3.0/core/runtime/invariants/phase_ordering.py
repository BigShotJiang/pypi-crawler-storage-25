from typing import Dict, Any
from core.runtime.invariants.base import RuntimeInvariant, InvariantViolation

class PhaseOrderingInvariant(RuntimeInvariant):
    """
    ∀ settlement: phase_a_exists(intent_id) AND decision == 'approved'
    A settlement (Phase B) CANNOT exist without a preceding approved intent (Phase A).
    """
    
    @property
    def name(self) -> str:
        return "PHASE_ORDERING"
        
    @property
    def severity(self) -> str:
        return "critical"
        
    def evaluate(self, receipt: Dict[str, Any], global_state: Dict[str, Any]) -> None:
        if "approved_intents" not in global_state:
            global_state["approved_intents"] = set()
            
        r_type = receipt.get("type")
        intent_id = receipt.get("intent_id")
        
        if not intent_id:
            return # Only evaluate intents
            
        if r_type == "policy_resolution" and receipt.get("decision") == "approved":
            global_state["approved_intents"].add(intent_id)
            
        elif r_type == "execution_settlement":
            if intent_id not in global_state["approved_intents"]:
                raise InvariantViolation(
                    self.name,
                    f"Orphan settlement detected. No preceding approved policy_resolution for intent_id={intent_id}",
                    {"intent_id": intent_id, "type": r_type}
                )
