from abc import ABC, abstractmethod
from typing import Dict, Any, Optional

class InvariantViolation(Exception):
    def __init__(self, rule_name: str, message: str, context: dict, severity: str = "critical"):
        self.rule_name = rule_name
        self.message = message
        self.context = context
        self.severity = severity
        super().__init__(f"{rule_name} Violation: {message}")

class RuntimeInvariant(ABC):
    """
    Base class for mathematical rules governing the Economic Runtime.
    An invariant MUST hold true for every state transition in the WAL.
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        pass
        
    @property
    @abstractmethod
    def severity(self) -> str:
        """critical, high, medium"""
        return "critical"
        
    @abstractmethod
    def evaluate(self, receipt: Dict[str, Any], global_state: Dict[str, Any]) -> None:
        """
        Evaluates the current receipt against the global invariant state.
        Raises InvariantViolation if the mathematical rule is broken.
        """
        pass
