import os
import json
import asyncio
import hashlib
import time
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger("WalWriter")

class WalWriter:
    """
    Dedicated async Write-Ahead Ledger (WAL) writer subsystem.
    Guarantees:
    - Monotonic sequencing
    - Atomic hash chaining
    - Strict serialization
    - No concurrent file access (single writer task)
    """
    def __init__(self, log_path: str = "/var/log/kernell/receipts.jsonl"):
        self.log_path = log_path
        self._queue = asyncio.Queue(maxsize=10000)
        self._write_task: Optional[asyncio.Task] = None
        
        # State tracking for chain
        self._current_seq = 0
        self._last_hash = "genesis"
        
        # Lock for initialization
        self._init_lock = asyncio.Lock()
        self._initialized = False

    async def _init_state(self):
        """Reads the tail of the WAL to recover sequence and hash."""
        if not os.path.exists(self.log_path):
            os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
            # Create empty if not exists
            open(self.log_path, 'a').close()
            self._current_seq = 0
            self._last_hash = "genesis"
            return

        # Simple tail recovery (in prod, we might want a checkpoint or efficient reverse read)
        last_line = ""
        try:
            with open(self.log_path, 'r') as f:
                # For large files, use os.lseek, but for now we iterate (or read last few bytes)
                # To be efficient, we assume log rotated or reasonable size
                lines = f.readlines()
                if lines:
                    last_line = lines[-1].strip()
        except Exception as e:
            logger.error(f"Failed to read WAL tail: {e}")
            
        if last_line:
            try:
                receipt = json.loads(last_line)
                self._current_seq = receipt.get("seq", 0)
                self._last_hash = receipt.get("hash", "genesis")
            except Exception:
                pass
                
        logger.info(f"WAL Writer recovered at seq {self._current_seq}, hash {self._last_hash[:8]}")

    async def start(self):
        """Starts the dedicated writer loop."""
        async with self._init_lock:
            if not self._initialized:
                await self._init_state()
                self._initialized = True
                
        if self._write_task is None or self._write_task.done():
            self._write_task = asyncio.create_task(self._writer_loop())

    async def stop(self):
        """Gracefully stops the writer, flushing the queue."""
        if self._write_task:
            await self._queue.put(None) # Sentinel
            await self._write_task

    def _compute_hash(self, payload: dict) -> str:
        canonical = json.dumps(payload, sort_keys=True, separators=(',', ':'))
        return hashlib.sha256(canonical.encode()).hexdigest()[:32]

    async def _writer_loop(self):
        """The single async consumer that mutates the file."""
        while True:
            batch = []
            item = await self._queue.get()
            if item is None:
                self._queue.task_done()
                break
                
            batch.append(item)
            # Drain queue for batching
            while not self._queue.empty():
                try:
                    next_item = self._queue.get_nowait()
                    if next_item is None:
                        # Re-enqueue sentinel for next iteration break
                        self._queue.put_nowait(None)
                        break
                    batch.append(next_item)
                except asyncio.QueueEmpty:
                    break

            # Process and write batch
            try:
                with open(self.log_path, 'a') as f:
                    for payload in batch:
                        # 1. Enforce monotonic seq
                        self._current_seq += 1
                        payload["seq"] = self._current_seq
                        
                        # 2. Enforce prev_hash chain
                        payload["prev_hash"] = self._last_hash
                        
                        # 3. Compute final hash
                        current_hash = self._compute_hash(payload)
                        payload["hash"] = current_hash
                        
                        # 4. Update state
                        self._last_hash = current_hash
                        
                        # Write payload
                        line = json.dumps(payload, separators=(',', ':')) + "\n"
                        f.write(line)
                    
                    f.flush()
                    os.fsync(f.fileno())
                    
            except Exception as e:
                logger.error(f"Critical WAL write failure: {e}")
                # We do not advance sequence if write failed
            finally:
                for _ in batch:
                    self._queue.task_done()

    async def append(self, payload: dict):
        """Submits a payload for chronological append to the WAL."""
        if not self._initialized:
            await self.start()
            
        # Add local timestamp to enforce temporal ordering at submission time
        if "timestamp" not in payload and "ts" not in payload:
            payload["ts"] = time.time()
            
        await self._queue.put(payload)
