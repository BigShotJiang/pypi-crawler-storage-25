import time
from enum import Enum, auto
from typing import Dict, Any, List, Optional
from collections import deque

class RuntimeState(Enum):
    HEALTHY = "HEALTHY"
    DEGRADED = "DEGRADED"
    SURVIVAL = "SURVIVAL"
    RECOVERING = "RECOVERING"

class SecurityState(Enum):
    NORMAL = "NORMAL"
    RESTRICTED = "RESTRICTED"
    QUARANTINED = "QUARANTINED"
    ISOLATED = "ISOLATED"
    LOCKDOWN = "LOCKDOWN"

class KernellStateMachine:
    """
    Formal state machine managing Runtime and Security state independently.
    Implements Cognitive Pressure Index (CPI) via Sliding Time Window.
    """
    
    RECOVERY_SUCCESS_THRESHOLD = 3
    RECOVERY_WINDOW_SECONDS = 120
    CPI_WINDOW_SECONDS = 300

    def __init__(self):
        self.runtime_state = RuntimeState.HEALTHY
        self.security_state = SecurityState.NORMAL
        
        # Hysteresis state
        self._recovery_successes = 0
        self._recovery_start_time = 0
        
        # Sliding Window for Events
        # Elements: dict with ts, success, provider, tier, fallback, anomaly, retry, containment
        self.events_window = deque()

    def _prune_window(self, current_ts: float):
        """Remove events older than CPI_WINDOW_SECONDS"""
        while self.events_window and current_ts - self.events_window[0]["ts"] > self.CPI_WINDOW_SECONDS:
            self.events_window.popleft()

    def compute_cpi(self) -> float:
        """
        Cognitive Pressure Index (CPI): 0.0 to 1.0
        Measures composite systemic pressure over the sliding window.
        """
        total_calls = len(self.events_window)
        if total_calls == 0:
            return 0.0
            
        provider_failures = 0
        retry_depth = 0
        fallback_frequency = 0
        containments = 0
        policy_rejections = 0
        
        for ev in self.events_window:
            if not ev.get("success", True): provider_failures += 1
            if ev.get("retry"): retry_depth += 1
            if ev.get("fallback"): fallback_frequency += 1
            if ev.get("hallucination_contained"): containments += 1
            if ev.get("policy_rejected"): policy_rejections += 1
            
        fail_rate = provider_failures / total_calls
        rejection_rate = policy_rejections / total_calls
        
        # Weights (normalized but aggressive for sustained failures)
        # Non-linear scaling for failures: 70% failures should almost guarantee SURVIVAL
        w_fail = min(0.65, fail_rate * 0.8) 
        w_retry = min(0.20, retry_depth * 0.05)
        w_fallback = min(0.20, fallback_frequency * 0.1)
        w_containment = min(0.25, containments * 0.1)
        w_rejection = min(0.35, rejection_rate * 0.5)  # High rejection = high pressure
        
        return min(1.0, w_fail + w_retry + w_fallback + w_containment + w_rejection)

    def ingest_event(self, event: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Ingests a normalized event envelope and computes state transitions.
        Returns a list of state transition receipt dictionaries if transitions occurred.
        
        Event structure expected:
        {
            "ts": float,
            "success": bool,
            "provider": str,
            "tier": int,
            "fallback": bool,
            "anomaly": bool,
            "retry": bool,
            "hallucination_contained": bool,
            "policy_rejected": bool
        }
        """
        current_ts = event.get("ts", time.time())
        self.events_window.append(event)
        self._prune_window(current_ts)
        
        transitions = []
        cpi = self.compute_cpi()
        
        old_runtime = self.runtime_state
        old_security = self.security_state
        
        tier = event.get("tier", 1)
        success = event.get("success", True)
        fallback = event.get("fallback", False)
        anomaly = event.get("anomaly", False)
        containment = event.get("hallucination_contained", False)

        # ─── Security Transitions ───
        
        if containment:
            if self.security_state == SecurityState.NORMAL:
                self.security_state = SecurityState.RESTRICTED
            elif self.security_state == SecurityState.RESTRICTED:
                # If window has many containments, escalate
                containments_in_window = sum(1 for e in self.events_window if e.get("hallucination_contained"))
                if containments_in_window > 3:
                    self.security_state = SecurityState.QUARANTINED
                if containments_in_window > 6:
                    self.security_state = SecurityState.ISOLATED

        # ─── Runtime Transitions ───
        
        if self.runtime_state == RuntimeState.HEALTHY:
            if cpi > 0.55 or fallback:
                self.runtime_state = RuntimeState.SURVIVAL if fallback and tier >= 4 else RuntimeState.DEGRADED
            elif cpi > 0.25:
                self.runtime_state = RuntimeState.DEGRADED
                
        elif self.runtime_state == RuntimeState.DEGRADED:
            if cpi > 0.55 or fallback:
                self.runtime_state = RuntimeState.SURVIVAL
            elif cpi <= 0.25:
                self.runtime_state = RuntimeState.HEALTHY
                
        elif self.runtime_state == RuntimeState.SURVIVAL:
            if cpi <= 0.35:
                self.runtime_state = RuntimeState.RECOVERING
                self._recovery_start_time = current_ts
                self._recovery_successes = 0
                
        elif self.runtime_state == RuntimeState.RECOVERING:
            if cpi > 0.50 or fallback:
                self.runtime_state = RuntimeState.SURVIVAL
            elif current_ts - self._recovery_start_time > self.RECOVERY_WINDOW_SECONDS:
                self.runtime_state = RuntimeState.SURVIVAL if cpi > 0.55 else RuntimeState.DEGRADED
                self._recovery_successes = 0
            elif not success or fallback or anomaly:
                self.runtime_state = RuntimeState.SURVIVAL
                self._recovery_successes = 0
            elif success and tier < 4:
                self._recovery_successes += 1
                if self._recovery_successes >= self.RECOVERY_SUCCESS_THRESHOLD:
                    self.runtime_state = RuntimeState.HEALTHY
                    self._recovery_successes = 0

        # Generate Transition Receipts
        if old_runtime != self.runtime_state:
            transitions.append({
                "type": "runtime_transition",
                "from_state": old_runtime.value,
                "to_state": self.runtime_state.value,
                "cpi": round(cpi, 4),
                "reason": "cpi_threshold" if not fallback else "fallback_cascade",
                "ts": current_ts
            })
            
        if old_security != self.security_state:
            transitions.append({
                "type": "security_transition",
                "from_state": old_security.value,
                "to_state": self.security_state.value,
                "cpi": round(cpi, 4),
                "reason": "containment_escalation",
                "ts": current_ts
            })

        return transitions
