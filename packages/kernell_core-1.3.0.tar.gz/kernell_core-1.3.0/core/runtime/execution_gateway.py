import os
import json
import time
import uuid
import asyncio
import hashlib
from typing import Dict, Any, Optional
from redis.asyncio import Redis
from core.economics.policy_engine import PolicyEngine, DenialReason

from core.runtime.wal_writer import WalWriter

# Configuration
RECEIPTS_PATH = "/var/log/kernell/receipts.jsonl"

class ExecutionIntent:
    """Canonical representation of an execution intent."""
    def __init__(self, data: Dict[str, Any]):
        self.intent_id = data.get("intent_id", f"int_{uuid.uuid4().hex[:12]}")
        self.tenant_id = data.get("tenant_id", "default_tenant")
        self.agent_id = data.get("agent_id", "unknown_agent")
        self.model = data.get("model", "")
        self.provider = data.get("provider", "")
        self.tier = int(data.get("tier", 1))
        self.prompt_hash = data.get("prompt_hash", "")
        self.estimated_tokens = int(data.get("estimated_tokens", 0))
        self.estimated_cost = float(data.get("estimated_cost", 0.0))
        self.retry_depth = int(data.get("retry_depth", 0))
        self.metadata = data.get("metadata", {})
        
        # State snapshot - filled by Gateway
        self.runtime_state_snapshot = "UNKNOWN"
        self.security_state_snapshot = "UNKNOWN"
        self.cpi_snapshot = 0.0

    def canonical_json(self) -> str:
        payload = {
            "intent_id": self.intent_id,
            "tenant_id": self.tenant_id,
            "agent_id": self.agent_id,
            "model": self.model,
            "provider": self.provider,
            "tier": self.tier,
            "prompt_hash": self.prompt_hash,
            "estimated_tokens": self.estimated_tokens,
            "estimated_cost": f"{self.estimated_cost:.8f}",
            "retry_depth": self.retry_depth,
            "runtime_state_snapshot": self.runtime_state_snapshot,
            "security_state_snapshot": self.security_state_snapshot,
            "cpi_snapshot": f"{self.cpi_snapshot:.4f}"
        }
        return json.dumps(payload, sort_keys=True, separators=(',', ':'))

class ExecutionGateway:
    """
    The hypervisor for economic runtime execution.
    Provides async mediation, backpressure, and Two-Phase Economic Commits to the WAL.
    """
    def __init__(self, policy_engine: PolicyEngine, redis_client: Redis, wal_writer: WalWriter, max_concurrent: int = 50):
        self.policy_engine = policy_engine
        self.redis = redis_client
        self.wal_writer = wal_writer
        self.concurrency_limit = asyncio.Semaphore(max_concurrent)
        self.active_intents = 0
        
        # Background task to consume external WAL writes (e.g. from ValidatorDaemon)
        self._external_wal_task = asyncio.create_task(self._consume_external_wal())
        
    async def _consume_external_wal(self):
        while True:
            try:
                # Block until an item is available
                result = await self.redis.blpop("kernell:wal:queue", timeout=1)
                if result:
                    _, payload_bytes = result
                    payload = json.loads(payload_bytes)
                    await self.wal_writer.append(payload)
            except Exception as e:
                # Log but continue
                await asyncio.sleep(1)

    async def _fetch_runtime_snapshot(self, intent: ExecutionIntent):
        """Fetches frozen state directly from the Validator Daemon via Redis"""
        runtime = await self.redis.get("kernell:state:runtime")
        security = await self.redis.get("kernell:state:security")
        cpi = await self.redis.get("kernell:state:cpi")
        
        intent.runtime_state_snapshot = runtime.decode('utf-8') if runtime else "HEALTHY"
        intent.security_state_snapshot = security.decode('utf-8') if security else "NORMAL"
        try:
            intent.cpi_snapshot = float(cpi) if cpi else 0.0
        except ValueError:
            intent.cpi_snapshot = 0.0

    async def execute_intent(self, intent_data: Dict[str, Any], provider_callback) -> Dict[str, Any]:
        """
        The main choke point for execution.
        Returns the Phase B Settlement receipt if successful, or Phase A Rejection if blocked.
        """
        intent = ExecutionIntent(intent_data)
        
        # 1. Backpressure Check
        if self.concurrency_limit.locked():
            reject_receipt = {
                "type": "policy_resolution",
                "decision": "rejected",
                "reason": DenialReason.RUNTIME_BACKPRESSURE.value,
                "intent_id": intent.intent_id,
                "tenant_id": intent.tenant_id,
                "ts": time.time()
            }
            await self.wal_writer.append(reject_receipt)
            return reject_receipt

        async with self.concurrency_limit:
            self.active_intents += 1
            try:
                # 2. Freeze State
                await self._fetch_runtime_snapshot(intent)

                # 3. Policy Resolution (Phase A)
                resolution = self.policy_engine.evaluate_request(
                    runtime_state=intent.runtime_state_snapshot,
                    requested_tier=intent.tier,
                    model=intent.model,
                    estimated_cost=intent.estimated_cost,
                    retry_depth=intent.retry_depth,
                    prompt_hash=intent.prompt_hash
                )
                
                # Attach canonical intent info
                resolution["intent_id"] = intent.intent_id
                resolution["tenant_id"] = intent.tenant_id
                resolution["canonical_intent"] = intent.canonical_json()
                resolution["ts"] = time.time()
                
                # Intent Replay / Deduplication Protection
                intent_hash = resolution.get("intent_hash")
                if intent_hash:
                    # Check Redis for existing intent within 60s
                    # status can be: pending, committed, finalized
                    cache_key = f"kernell:intent:{intent.tenant_id}:{intent_hash}"
                    existing_status = await self.redis.get(cache_key)
                    if existing_status:
                        reject_receipt = {
                            "type": "policy_resolution",
                            "decision": "rejected",
                            "reason": "DUPLICATE_INTENT_SUPPRESSED",
                            "intent_id": intent.intent_id,
                            "intent_hash": intent_hash,
                            "tenant_id": intent.tenant_id,
                            "ts": time.time()
                        }
                        await self.wal_writer.append(reject_receipt)
                        return reject_receipt
                        
                    # Mark as pending execution
                    await self.redis.setex(cache_key, 60, "pending")

                # Write Phase A Receipt (Approved or Rejected)
                await self.wal_writer.append(resolution)
                
                # If rejected, short circuit immediately
                if resolution["decision"] != "approved":
                    if intent_hash:
                        await self.redis.delete(f"kernell:intent:{intent.tenant_id}:{intent_hash}")
                    return resolution
                
                # 4. Execute via Provider Router
                start_time = time.time()
                try:
                    result = await provider_callback(intent)
                    latency = time.time() - start_time
                    success = True
                    actual_cost = result.get("cost_usd", 0.0)
                    error = None
                except Exception as e:
                    latency = time.time() - start_time
                    success = False
                    actual_cost = 0.0
                    error = str(e)
                    result = {}

                # 5. Settlement Receipt (Phase B)
                settlement = {
                    "type": "execution_settlement",
                    "settlement_status": "finalized",
                    "intent_id": intent.intent_id,
                    "tenant_id": intent.tenant_id,
                    "policy_id": resolution.get("policy_id"),
                    "intent_hash": intent_hash,
                    "success": success,
                    "actual_cost": actual_cost,
                    "latency_ms": latency * 1000,
                    "error": error,
                    "tokens_total": result.get("tokens_total", 0),
                    "provider": intent.provider,
                    "model": intent.model,
                    "cognitive_tier": intent.tier,
                    "ts": time.time()
                }
                
                # Mark as finalized
                if intent_hash:
                    await self.redis.setex(f"kernell:intent:{intent.tenant_id}:{intent_hash}", 3600, "finalized")
                
                # Write Phase B
                await self.wal_writer.append(settlement)
                
                return settlement
                
            finally:
                self.active_intents -= 1
