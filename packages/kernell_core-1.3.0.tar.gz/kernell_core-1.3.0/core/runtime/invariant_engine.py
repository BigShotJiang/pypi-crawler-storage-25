import json
import time
import logging
from typing import List, Dict, Any
from redis import Redis

from core.runtime.invariants.base import RuntimeInvariant, InvariantViolation
from core.runtime.invariants.phase_ordering import PhaseOrderingInvariant
from core.runtime.invariants.hash_integrity import HashIntegrityInvariant
from core.runtime.invariants.settlement_finality import SettlementFinalityInvariant
from core.runtime.invariants.sequence_monotonicity import SequenceMonotonicityInvariant
from core.runtime.state_machine import SecurityState

logger = logging.getLogger("InvariantEngine")

class InvariantEngine:
    """
    Economic Theorem Verifier.
    Consumes the WAL and enforces mathematical invariants.
    """
    def __init__(self, redis_client: Redis, wal_path: str = "/var/log/kernell/receipts.jsonl"):
        self.redis = redis_client
        self.wal_path = wal_path
        self.invariants: List[RuntimeInvariant] = [
            HashIntegrityInvariant(),
            SequenceMonotonicityInvariant(),
            PhaseOrderingInvariant(),
            SettlementFinalityInvariant()
        ]
        self.global_state: Dict[str, Any] = {}

    def ingest_receipt(self, receipt: Dict[str, Any]) -> None:
        """
        Evaluates a single receipt against all active invariants.
        """
        # Do not evaluate invariant violation receipts themselves to prevent loops,
        # but DO update chain tracking state so the hash chain stays continuous.
        if receipt.get("type") == "invariant_violation":
            if "hash" in receipt:
                self.global_state["last_verified_hash"] = receipt["hash"]
            if "seq" in receipt:
                self.global_state["last_seen_seq"] = receipt["seq"]
            return
            
        for invariant in self.invariants:
            try:
                invariant.evaluate(receipt, self.global_state)
            except InvariantViolation as e:
                self._handle_violation(e, receipt)

    def _handle_violation(self, violation: InvariantViolation, triggering_receipt: Dict[str, Any]) -> None:
        """
        Handles the breach of an invariant.
        1. Emits invariant_violation_receipt
        2. Appends to WAL
        3. Elevates SecurityState to ISOLATED if critical
        4. Publishes to Redis
        """
        logger.critical(f"INVARIANT BROKEN: {violation.rule_name} - {violation.message}")
        
        violation_receipt = {
            "type": "invariant_violation",
            "rule_broken": violation.rule_name,
            "severity": violation.severity,
            "message": violation.message,
            "context": violation.context,
            "triggering_seq": triggering_receipt.get("seq"),
            "triggering_hash": triggering_receipt.get("hash"),
            "ts": time.time()
        }
        
        # 1. Update SecurityState
        if violation.severity == "critical":
            self.redis.set("kernell:state:security", SecurityState.ISOLATED.value)
            # Send immediate kill switch signal
            self.redis.publish("kernell:system:kill_switch", json.dumps({"reason": "invariant_violation", "rule": violation.rule_name}))
            
        # 2. Publish to Redis anomalies
        self.redis.lpush("kernell:security:economic_anomalies", json.dumps(violation_receipt))
        
        # 3. Push to WAL external queue instead of writing directly to avoid collisions
        try:
            self.redis.rpush("kernell:wal:queue", json.dumps(violation_receipt))
        except Exception as e:
            logger.error(f"Failed to push invariant violation to WAL queue: {e}")
