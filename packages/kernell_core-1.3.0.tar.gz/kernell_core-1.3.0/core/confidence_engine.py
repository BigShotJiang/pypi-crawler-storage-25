"""
Kernell OS — Confidence Engine
==============================
Calibrates response confidence to enable safe Early Exit (cheap -> premium).
Ensures we only skip the premium model if the cheap model's output is actually robust.
"""



class ConfidenceEngine:
    def __init__(self):
        pass
        
    def evaluate(self, response_payload: str, prompt_features: dict) -> dict:
        """
        Heuristic evaluation of confidence for the response.
        In a real system, this could use a small local cross-encoder,
        but here we use structural proxy metrics.
        """
        if not response_payload:
            return {"confidence": 0.0, "hallucination_risk": 1.0, "requires_escalation": True, "reason": "Empty response"}
            
        # 1. Length coherence (did it completely truncate?)
        expected_len = prompt_features.get("expected_output_tokens", 100) * 4 # rough chars
        actual_len = len(response_payload)
        length_ratio = min(actual_len / max(expected_len, 1), 1.0)
        
        # 2. Structural integrity (did it finish its thought?)
        finished_thought = response_payload.strip().endswith((".", "}", "]", "```", ">", '"'))
        
        # 3. Complexity vs Output (if task is complex but output is simple, low confidence)
        complexity = prompt_features.get("complexity_score", 0.5)
        
        # Base confidence calculation
        confidence = (length_ratio * 0.4) + (0.3 if finished_thought else 0.0) + ((1.0 - complexity) * 0.3)
        
        # Modifiers based on task requirements
        if prompt_features.get("requires_strict_format", False):
            # Example check: if it requires JSON, does it look like JSON?
            looks_like_json = response_payload.strip().startswith("{") and response_payload.strip().endswith("}")
            if not looks_like_json:
                confidence *= 0.2
                
        # Calculate Hallucination Risk
        # (High complexity + high length ratio usually increases risk if local model)
        risk = (complexity * 0.6) + (length_ratio * 0.4)
        if not finished_thought:
            risk += 0.3
            
        risk = min(risk, 1.0)
        confidence = min(max(confidence, 0.0), 1.0)
        
        # Escalation decision
        threshold = prompt_features.get("early_exit_threshold", 0.8)
        requires_escalation = confidence < threshold
        
        reason = "Confidence high" if not requires_escalation else f"Confidence ({confidence:.2f}) < Threshold ({threshold})"
        
        return {
            "confidence": round(confidence, 4),
            "hallucination_risk": round(risk, 4),
            "requires_escalation": requires_escalation,
            "reason": reason
        }

if __name__ == "__main__":
    engine = ConfidenceEngine()
    
    scenarios = [
        {"name": "Good Code Output", "output": "def foo():\n    return 42\n", "features": {"expected_output_tokens": 10, "complexity_score": 0.2, "early_exit_threshold": 0.75}},
        {"name": "Cutoff Response", "output": "The solution is to use a", "features": {"expected_output_tokens": 50, "complexity_score": 0.4, "early_exit_threshold": 0.7}},
        {"name": "Complex Math Fail", "output": "42", "features": {"expected_output_tokens": 100, "complexity_score": 0.9, "early_exit_threshold": 0.85}},
    ]
    
    print("--- Confidence Engine Evaluation ---")
    for s in scenarios:
        res = engine.evaluate(s["output"], s["features"])
        print(f"\n[{s['name']}]")
        print(f"  Output length: {len(s['output'])} chars")
        print(f"  Confidence:    {res['confidence']}")
        print(f"  Risk:          {res['hallucination_risk']}")
        print(f"  Escalate?:     {res['requires_escalation']} ({res['reason']})")
