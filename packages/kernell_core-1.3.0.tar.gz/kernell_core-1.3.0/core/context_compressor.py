"""
Kernell OS — Context Compressor
===============================
Reduces token pressure BEFORE inference by applying structural compression
and rolling summaries. Triggered when Hypervisor outputs 'compress_context=True'.
"""

import json
import logging

class ContextCompressor:
    def __init__(self, compression_ratio: float = 0.5):
        self.compression_ratio = compression_ratio
        
    def compress_payload(self, payload: dict) -> dict:
        """
        Applies heuristic structural compression to a payload.
        Removes verbosity, truncates long lists, drops metadata.
        """
        compressed = {}
        for k, v in payload.items():
            if isinstance(v, str):
                # Simple truncation for strings
                max_len = 500
                if len(v) > max_len:
                    compressed[k] = v[:max_len] + "... [TRUNCATED]"
                else:
                    compressed[k] = v
            elif isinstance(v, list):
                # Keep only top and bottom elements for long lists
                if len(v) > 10:
                    compressed[k] = v[:5] + ["... [SNIP] ..."] + v[-5:]
                else:
                    compressed[k] = v
            elif isinstance(v, dict):
                # Drop common heavy metadata keys
                if k in ["metadata", "headers", "raw_traces"]:
                    compressed[k] = {"__compressed__": True, "keys_dropped": list(v.keys())}
                else:
                    compressed[k] = self.compress_payload(v)
            else:
                compressed[k] = v
                
        return compressed

    def apply_compression(self, envelope: dict) -> dict:
        """
        Checks if the envelope's cognitive setup requires compression.
        If so, compresses the payload inplace.
        """
        setup = envelope.get("cognitive_setup", {})
        if setup.get("compress_context", False):
            original_payload = envelope.get("payload", {})
            original_size = len(json.dumps(original_payload))
            
            compressed_payload = self.compress_payload(original_payload)
            compressed_size = len(json.dumps(compressed_payload))
            
            envelope["payload"] = compressed_payload
            envelope["compression_stats"] = {
                "original_bytes": original_size,
                "compressed_bytes": compressed_size,
                "saved_bytes": original_size - compressed_size,
                "ratio": round(compressed_size / max(original_size, 1), 2)
            }
        return envelope

if __name__ == "__main__":
    compressor = ContextCompressor()
    
    heavy_payload = {
        "action": "analyze_logs",
        "raw_traces": {"t1": "...", "t2": "...", "t3": "..."},
        "logs": ["log1", "log2", "log3", "log4", "log5", "log6", "log7", "log8", "log9", "log10", "log11", "log12"],
        "content": "A" * 2000
    }
    
    envelope = {
        "cognitive_setup": {"compress_context": True},
        "payload": heavy_payload
    }
    
    compressed_env = compressor.apply_compression(envelope)
    print("--- Context Compressor Test ---")
    print(json.dumps(compressed_env, indent=2))
