"""
Kernell OS — Runtime Safety Layer
=================================
Circuit breakers for institutional economics.
Detects economic anomalies like escalation storms, drift runaway, 
or cache poisoning, and triggers Safe Mode to prevent burning thousands of dollars.
"""

from typing import Dict, List, Any
import logging

class RuntimeSafeMode(Exception):
    """Triggered when the economic safety layer trips a circuit breaker."""
    pass

class EconomicCircuitBreaker:
    def __init__(self, history_window: int = 50):
        self.history_window = history_window
        self.recent_traces: List[Dict[str, Any]] = []
        
        # Institutional Limits
        self.MAX_ESCALATION_RATE = 0.35 # >35% escalations triggers safe mode
        self.MAX_CACHE_REWARD_DROP = 0.30 # Cache returning garbage
        self.MAX_DRIFT_RUNAWAY = 0.40 # Planners are losing control of the intent
        
    def _cull_history(self):
        if len(self.recent_traces) > self.history_window:
            self.recent_traces = self.recent_traces[-self.history_window:]

    def ingest_trace(self, trace: Dict[str, Any]):
        """Ingests a live trace and evaluates circuit breakers."""
        self.recent_traces.append(trace)
        self._cull_history()
        
        # Wait until we have enough statistical significance
        if len(self.recent_traces) < 10:
            return
            
        self._check_escalation_storm()
        self._check_cache_poisoning()
        self._check_drift_runaway()

    def _check_escalation_storm(self):
        """
        Detects if too many requests are escalating to premium.
        This usually means a configuration error or an adversarial workload.
        """
        escalations = sum(1 for t in self.recent_traces if t.get("escalation_path", "none") != "none")
        rate = escalations / len(self.recent_traces)
        
        if rate > self.MAX_ESCALATION_RATE:
            msg = f"Escalation Storm Detected: {rate*100:.1f}% > {self.MAX_ESCALATION_RATE*100:.1f}%. Triggering Safe Mode."
            logging.critical(msg)
            raise RuntimeSafeMode(msg)

    def _check_cache_poisoning(self):
        """
        Detects if cached items are suddenly receiving very low reward scores 
        or causing failures.
        """
        cache_hits = [t for t in self.recent_traces if t.get("cache_hit", False)]
        if not cache_hits:
            return
            
        avg_cache_reward = sum(t.get("reward_score", 0) for t in cache_hits) / len(cache_hits)
        
        if avg_cache_reward < (1.0 - self.MAX_CACHE_REWARD_DROP):
            msg = f"Cache Poisoning Detected: Avg Cache Reward dropped to {avg_cache_reward:.2f}. Triggering Safe Mode."
            logging.critical(msg)
            raise RuntimeSafeMode(msg)

    def _check_drift_runaway(self):
        """
        Detects if the system is repeatedly failing to satisfy the original intent.
        """
        avg_drift = sum(t.get("drift_score", 0) for t in self.recent_traces) / len(self.recent_traces)
        
        if avg_drift > self.MAX_DRIFT_RUNAWAY:
            msg = f"Drift Runaway Detected: Avg Drift {avg_drift:.2f} > {self.MAX_DRIFT_RUNAWAY}. Triggering Safe Mode."
            logging.critical(msg)
            raise RuntimeSafeMode(msg)

if __name__ == "__main__":
    breaker = EconomicCircuitBreaker()
    print("--- Runtime Safety Layer ---")
    
    # Simulate normal traffic
    for i in range(15):
        breaker.ingest_trace({
            "escalation_path": "none",
            "reward_score": 0.85,
            "drift_score": 0.05,
            "cache_hit": False
        })
    print("✅ Normal traffic passed.")
    
    # Simulate Escalation Storm
    try:
        for i in range(10):
            breaker.ingest_trace({
                "escalation_path": "local -> premium",
                "reward_score": 0.90,
                "drift_score": 0.02,
                "cache_hit": False
            })
    except RuntimeSafeMode as e:
        print(f"🛡️ CIRCUIT BREAKER TRIPPED: {e}")
