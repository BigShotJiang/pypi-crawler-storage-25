"""
Kernell OS — Enterprise SLA Layer
=================================
Converts optimization into hard contractual economic guarantees.
Defines Org, Workspace, and Tenant constraints.
"""

from dataclasses import dataclass
from typing import Dict, Any, List, Optional
from enum import Enum

POLICY_SCHEMA_VERSION = "v1"

class GovernanceLevel(Enum):
    ORG = "organization"
    WORKSPACE = "workspace"
    PROJECT = "project"
    TEAM = "team"


@dataclass
class SLAGuarantee:
    """Hard contractual limits that the system is forbidden to violate."""
    max_premium_escalation_pct: float # e.g. 0.15 for 15%
    max_drift_auth_security: float    # e.g. 0.05
    max_latency_p95_ms: int           # e.g. 1200
    min_reward_retention: float       # e.g. 0.92
    budget_cap_daily_usd: float       # e.g. 300.0
    hard_stop_on_breach: bool         # If True, refuse inference rather than breach budget


class GovernancePolicy:
    """
    Inheritable governance policy. Workspaces inherit from Orgs, etc.
    """
    def __init__(self, level: GovernanceLevel, entity_id: str, sla: SLAGuarantee, parent: Optional['GovernancePolicy'] = None):
        self.level = level
        self.entity_id = entity_id
        self.sla = sla
        self.parent = parent
        
    def resolve_effective_sla(self) -> SLAGuarantee:
        """
        Resolves SLA by inheriting the strictest constraints from parents.
        """
        if not self.parent:
            return self.sla
            
        parent_sla = self.parent.resolve_effective_sla()
        
        # Take the most restrictive constraint across the inheritance chain
        return SLAGuarantee(
            max_premium_escalation_pct=min(self.sla.max_premium_escalation_pct, parent_sla.max_premium_escalation_pct),
            max_drift_auth_security=min(self.sla.max_drift_auth_security, parent_sla.max_drift_auth_security),
            max_latency_p95_ms=min(self.sla.max_latency_p95_ms, parent_sla.max_latency_p95_ms),
            min_reward_retention=max(self.sla.min_reward_retention, parent_sla.min_reward_retention),
            budget_cap_daily_usd=min(self.sla.budget_cap_daily_usd, parent_sla.budget_cap_daily_usd),
            hard_stop_on_breach=self.sla.hard_stop_on_breach or parent_sla.hard_stop_on_breach
        )


class EnterpriseSLALayer:
    """
    Validates if the current running telemetry violates the SLA.
    If it is nearing breach, it signals the BudgetEngine to throttle.
    """
    def __init__(self):
        self.policies: Dict[str, GovernancePolicy] = {}
        
    def register_policy(self, policy: GovernancePolicy):
        self.policies[policy.entity_id] = policy
        
    def evaluate_compliance(self, entity_id: str, current_telemetry: Dict[str, float]) -> Dict[str, Any]:
        """
        Checks current tenant telemetry against their effective SLA.
        Returns compliance status and throttle recommendations.
        """
        if entity_id not in self.policies:
            return {"status": "no_policy", "breach": False}
            
        effective_sla = self.policies[entity_id].resolve_effective_sla()
        
        breaches = []
        warnings = []
        
        # Evaluate Premium Escalation
        current_escalation = current_telemetry.get("escalation_rate", 0.0)
        if current_escalation > effective_sla.max_premium_escalation_pct:
            breaches.append(f"Escalation rate {current_escalation:.1%} exceeds SLA {effective_sla.max_premium_escalation_pct:.1%}")
        elif current_escalation > effective_sla.max_premium_escalation_pct * 0.8:
            warnings.append("Approaching escalation cap")
            
        # Evaluate Budget
        current_spend = current_telemetry.get("daily_spend_usd", 0.0)
        if current_spend > effective_sla.budget_cap_daily_usd:
            breaches.append(f"Spend ${current_spend} exceeds budget cap ${effective_sla.budget_cap_daily_usd}")
            
        # Evaluate Latency
        current_p95 = current_telemetry.get("latency_p95_ms", 0)
        if current_p95 > effective_sla.max_latency_p95_ms:
            breaches.append(f"p95 Latency {current_p95}ms exceeds SLA {effective_sla.max_latency_p95_ms}ms")
            
        status = "breached" if breaches else "warning" if warnings else "compliant"
        
        # If breached and hard stop is enabled, trigger shutdown
        trigger_hard_stop = status == "breached" and effective_sla.hard_stop_on_breach
        
        return {
            "status": status,
            "breaches": breaches,
            "warnings": warnings,
            "trigger_hard_stop": trigger_hard_stop,
            "throttle_premium": "Approaching escalation cap" in warnings or status == "breached",
            "effective_sla": effective_sla.__dict__
        }

if __name__ == "__main__":
    # Define Org Policy
    org_sla = SLAGuarantee(
        max_premium_escalation_pct=0.20, # Org allows 20%
        max_drift_auth_security=0.05,
        max_latency_p95_ms=2000,
        min_reward_retention=0.85,
        budget_cap_daily_usd=1000.0,
        hard_stop_on_breach=True
    )
    org_policy = GovernancePolicy(GovernanceLevel.ORG, "org_acme", org_sla)
    
    # Define Workspace Policy (Inherits from Org, but stricter on budget)
    ws_sla = SLAGuarantee(
        max_premium_escalation_pct=0.50, # Workspace tries to be loose (50%)
        max_drift_auth_security=0.10,
        max_latency_p95_ms=5000,
        min_reward_retention=0.80,
        budget_cap_daily_usd=200.0,      # Stricter budget
        hard_stop_on_breach=False
    )
    ws_policy = GovernancePolicy(GovernanceLevel.WORKSPACE, "ws_frontend", ws_sla, parent=org_policy)
    
    layer = EnterpriseSLALayer()
    layer.register_policy(org_policy)
    layer.register_policy(ws_policy)
    
    # Current telemetry for the workspace
    current_metrics = {
        "escalation_rate": 0.25, # Exceeds Org limit (20%), even though WS requested 50%
        "daily_spend_usd": 150.0, # Within budget
        "latency_p95_ms": 1100,
    }
    
    print("--- Enterprise SLA Compliance Check ---")
    compliance = layer.evaluate_compliance("ws_frontend", current_metrics)
    
    print(f"\nStatus: {compliance['status'].upper()}")
    if compliance['breaches']:
        print("Breaches:")
        for b in compliance['breaches']:
            print(f"  ❌ {b}")
            
    print(f"\nHard Stop Triggered: {compliance['trigger_hard_stop']}")
    print(f"Throttle Premium Escalations: {compliance['throttle_premium']}")
