"""
Kernell OS — Economic Explainability API
========================================
Exports the exact reasons why a trace escalated, bypassed verification,
or consumed specific budget amounts. Essential for enterprise auditability.
"""

from typing import Dict, Any, List

class EconomicExplainabilityAPI:
    def __init__(self, workload_capture_layer, budget_engine, sla_layer):
        # In a real system, these would read from the DB or be injected services
        self.capture = workload_capture_layer
        self.budget = budget_engine
        self.sla = sla_layer
        
    def generate_explanation(self, trace_id: str) -> Dict[str, Any]:
        """
        Takes a trace ID and reconstructs the causal chain of its economic path.
        """
        # Fetch trace (Mocked extraction from the capture layer)
        if trace_id not in self.capture.dataset:
            return {"error": "Trace not found"}
            
        trace = self.capture.dataset[trace_id]
        
        reasons = []
        
        # 1. Intent & SLA constraints
        if trace.intent_class in ["security_audit", "auth", "crypto", "payment"]:
            reasons.append(f"Intent classified as '{trace.intent_class}' which mandates strict verification SLA.")
            
        # 2. Cache
        if trace.cache_hit:
            reasons.append("Structural signature hit the Semantic Cache. Verification bypassed to save $0.03.")
            
        # 3. Escalations
        if trace.escalation_path != "none" and trace.escalation_path != "local_fast -> premium_verify":
            reasons.append(f"Confidence score fell below threshold (0.85). Triggered escalation path: {trace.escalation_path}.")
            
        # 4. Human feedback loop
        if trace.human_accept_reject is False:
            reasons.append("Human explicitly rejected the output. Trace flagged for Learning Loop counterfactual training.")
            
        # Compile response
        return {
            "trace_id": trace_id,
            "tenant_id": trace.tenant_id,
            "cost_incurred_usd": trace.final_cost_usd,
            "reward_score": trace.reward_score,
            "escalated": trace.escalation_path != "none",
            "why_escalated": reasons if trace.escalation_path != "none" else [],
            "why_bypassed": reasons if trace.cache_hit else [],
            "economic_efficiency": {
                "vcy_usd": trace.reward_score / trace.final_cost_usd if trace.final_cost_usd > 0 else "infinite",
                "premium_avoided": trace.cache_hit
            }
        }

if __name__ == "__main__":
    from core.workload_capture import WorkloadCaptureLayer
    
    # Setup dependencies
    capture = WorkloadCaptureLayer()
    trace_id = capture.ingest_trace({
        "intent_class": "security_audit",
        "escalation_path": "local -> premium_verify",
        "cost_usd": 0.031,
        "reward": 0.95,
        "cache_hit": False
    }, "def audit(): pass")
    
    api = EconomicExplainabilityAPI(capture, None, None)
    
    import json
    print(json.dumps(api.generate_explanation(trace_id), indent=2))
