"""
Kernell OS — Cognitive Hypervisor
=================================
Governance layer that sits ABOVE the SDK's IntelligentRouter.
Does NOT replace economic routing — it modifies execution_policy
based on system pressure metrics.

Outputs:
  - execution_policy: tells the SDK Router HOW to behave
  - adapter_stack: which cognitive LoRAs to activate
  - telemetry: auditable trace of the decision
"""

import yaml
import time
import uuid
import os
from core.budget_engine import ExecutionBudgetPolicy
from core.budget_engine import ExecutionBudgetPolicy


class CognitiveHypervisor:
    def __init__(self, registry_path="config/adapter_registry.yaml", ema_alpha=0.3):
        self.adapters = self._load_registry(registry_path)
        # Temporal Governance State
        self.ema_alpha = ema_alpha
        self.state_buffer = {
            "semantic_noise": 0.0,
            "governance_latency": 0.0,
            "token_pressure": 0.0,
            "error_rate": 0.0,
            "cache_miss_rate": 0.0
        }

    def _load_registry(self, path):
        full_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), path)
        try:
            with open(full_path, 'r') as f:
                return yaml.safe_load(f).get("adapters", {})
        except Exception as e:
            print(f"Warning: Could not load registry ({e}). Using defaults.")
            return {}
            
    def _apply_hysteresis(self, raw_metrics: dict) -> dict:
        """
        Smooths institutional pressure using an Exponential Moving Average (EMA).
        Prevents the hypervisor from oscillating rapidly between policies.
        """
        for k, v in raw_metrics.items():
            if k in self.state_buffer:
                # EMA formula: S_t = alpha * Y_t + (1 - alpha) * S_{t-1}
                self.state_buffer[k] = (self.ema_alpha * v) + ((1.0 - self.ema_alpha) * self.state_buffer[k])
            else:
                self.state_buffer[k] = v
        return self.state_buffer.copy()

    def compute_execution_policy(self, raw_metrics: dict, budget_policy: ExecutionBudgetPolicy) -> dict:
        """
        Maps system pressure and BUDGET CONSTRAINTS to an execution_policy.
        The Budget Engine defines the economic space (budget_policy).
        The Hypervisor decides the operational tactic within that space.
        """
        field_metrics = self._apply_hysteresis(raw_metrics)
        
        noise = field_metrics.get("semantic_noise", 0.0)
        latency = field_metrics.get("governance_latency", 0.0)
        pressure = field_metrics.get("token_pressure", 0.0)
        
        max_tier = budget_policy.max_execution_tier
        
        # Operational policy within budget
        if max_tier in ["zero_inference", "local_fast"] or budget_policy.planner_strategy == "latency_optimized":
            policy = "emergency_local"
            adapters = [("institutional_triage", 0.8), ("attention_budgeter", 0.2)]
            compress = True
        elif budget_policy.verification_threshold > 0.8:
            policy = "draft_verify"
            adapters = [("epistemological_verifier", 1.0)]
            compress = False
        else:
            policy = "cheap_first"
            adapters = [("attention_budgeter", 0.6), ("lineage_compressor", 0.4)]
            compress = True

        return {
            "policy": policy,
            "adapter_stack": adapters,
            "max_budget_usd": budget_policy.escalation_cap_usd,
            "compress_context": compress,
            "early_exit_threshold": budget_policy.verification_threshold,
            "decomposition_depth_limit": budget_policy.decomposition_depth_limit,
            "reason": f"Constrained by {budget_policy.planner_strategy} (Max: {max_tier})"
        }

    def route_inference(self, payload: dict, field_metrics: dict, budget_policy: ExecutionBudgetPolicy) -> tuple:
        """
        Wraps the policy decision in a traceable envelope.
        Returns (envelope, telemetry) for the Forge and Persistence layers.
        """
        start_time = time.time()
        policy = self.compute_execution_policy(field_metrics, budget_policy)

        envelope = {
            "trace_id": f"inf-{str(uuid.uuid4())[:8]}",
            "execution_policy": policy["policy"],
            "cognitive_setup": {
                "adapter_stack": policy["adapter_stack"],
                "max_budget_usd": policy["max_budget_usd"],
                "compress_context": policy["compress_context"],
                "early_exit_threshold": policy["early_exit_threshold"],
            },
            "payload": payload
        }

        telemetry = {
            "adapter_stack": policy["adapter_stack"],
            "execution_policy": policy["policy"],
            "constitutional_risk": max(field_metrics.values()) if field_metrics else 0,
            "early_exit_threshold": policy["early_exit_threshold"],
            "reason": policy["reason"],
            "routing_time_ms": round((time.time() - start_time) * 1000, 2)
        }

        return envelope, telemetry


if __name__ == "__main__":
    hypervisor = CognitiveHypervisor()

    scenarios = [
        {"name": "Peace Time",         "metrics": {"semantic_noise": 0.1, "token_pressure": 0.3, "governance_latency": 0.2, "error_rate": 0.02, "cache_miss_rate": 0.3}},
        {"name": "Semantic Infection",  "metrics": {"semantic_noise": 0.85, "token_pressure": 0.5, "governance_latency": 0.4, "error_rate": 0.1, "cache_miss_rate": 0.5}},
        {"name": "Budget Pressure",     "metrics": {"semantic_noise": 0.2, "token_pressure": 0.7, "governance_latency": 0.3, "error_rate": 0.05, "cache_miss_rate": 0.8}},
        {"name": "Cascading Collapse",  "metrics": {"semantic_noise": 0.6, "token_pressure": 0.95, "governance_latency": 0.88, "error_rate": 0.3, "cache_miss_rate": 0.9}},
    ]

    print("--- Cognitive Hypervisor (Governance Policy Layer) ---")
    for s in scenarios:
        env, tel = hypervisor.route_inference({"action": "review_patch"}, s["metrics"])
        print(f"\n[{s['name']}]")
        print(f"  Policy:          {tel['execution_policy']}")
        print(f"  Adapters:        {tel['adapter_stack']}")
        print(f"  Early Exit @:    {tel['early_exit_threshold']}")
        print(f"  Max Budget:      ${env['cognitive_setup']['max_budget_usd']}")
        print(f"  Compress Ctx:    {env['cognitive_setup']['compress_context']}")
        print(f"  Reason:          {tel['reason']}")
