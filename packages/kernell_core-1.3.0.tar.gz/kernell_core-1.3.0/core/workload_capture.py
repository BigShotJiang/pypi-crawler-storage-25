"""
Kernell OS — Workload Capture Layer
===================================
The foundation of the institutional dataset.
Captures 'Trace Packets' from real developer workloads, anonymizes them
(stripping PII and secrets), and records 'Human Outcome Signals' to train
the Counterfactual Optimizer and Semantic Cache.
"""

from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone
import hashlib
import re

@dataclass
class TracePacket:
    trace_id: str
    tenant_id: str
    
    # Core physiological metrics
    intent_class: str
    input_size_bytes: int
    decomposition_depth: int
    execution_profile: str
    escalation_path: str # e.g., "local_fast -> premium_verify"
    
    # Economics & Performance
    latency_ms: float
    final_cost_usd: float
    cache_hit: bool
    
    # Outcomes (Crucial for Learning Loop)
    reward_score: float
    drift_score: float
    verification_outcome: str # "bypassed", "verified", "failed"
    
    # Ground Truth (Added asynchronously)
    human_accept_reject: Optional[bool] = None
    human_outcome_notes: Optional[str] = None
    
    # Context
    repo_domain: str = "unknown"
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class WorkloadCaptureLayer:
    def __init__(self):
        # In-memory dataset for prototype. In prod: specialized telemetry DB or object storage.
        self.dataset: Dict[str, TracePacket] = {}
        
    def _hash_identifier(self, value: str) -> str:
        return hashlib.sha256(value.encode('utf-8')).hexdigest()[:12]

    def anonymize_payload(self, raw_payload: str) -> Dict[str, Any]:
        """
        Enterprise-grade anonymization.
        Strips secrets, hashes PII/identifiers, redacts raw code.
        Returns structural metrics and redacted intent, NOT the code.
        """
        # Redact common secrets (mock logic)
        redacted = re.sub(r'(api_key|password|secret|token)\s*[:=]\s*["\'].*?["\']', r'\1 = [REDACTED]', raw_payload, flags=re.IGNORECASE)
        
        # We DO NOT store the raw code in the trace packet.
        # We only store the structural signature and size.
        return {
            "size_bytes": len(raw_payload),
            "content_hash": self._hash_identifier(raw_payload),
            "redacted_snippet": redacted[:200] + "..." if len(redacted) > 200 else redacted
        }

    def ingest_trace(self, raw_telemetry: Dict[str, Any], raw_payload: str) -> str:
        """
        Ingests raw execution telemetry, anonymizes the payload, and structures it 
        into an institutional Trace Packet.
        """
        trace_id = raw_telemetry.get("trace_id", self._hash_identifier(str(datetime.now().timestamp())))
        
        # Anonymize
        anon_payload = self.anonymize_payload(raw_payload)
        
        packet = TracePacket(
            trace_id=trace_id,
            tenant_id=self._hash_identifier(raw_telemetry.get("tenant_id", "default_org")),
            intent_class=raw_telemetry.get("intent_class", "unknown"),
            input_size_bytes=anon_payload["size_bytes"],
            decomposition_depth=raw_telemetry.get("decomposition_depth", 1),
            execution_profile=raw_telemetry.get("execution_policy", "normal"),
            escalation_path=raw_telemetry.get("escalation_path", "none"),
            latency_ms=raw_telemetry.get("latency_ms", 0.0),
            final_cost_usd=raw_telemetry.get("cost_usd", 0.0),
            cache_hit=raw_telemetry.get("cache_hit", False),
            reward_score=raw_telemetry.get("reward", 0.0),
            drift_score=raw_telemetry.get("drift", 0.0),
            verification_outcome=raw_telemetry.get("verification_outcome", "unverified"),
            repo_domain=self._hash_identifier(raw_telemetry.get("repo_url", "local_repo"))
        )
        
        self.dataset[trace_id] = packet
        return trace_id

    def attach_human_outcome(self, trace_id: str, accepted: bool, notes: str = "") -> bool:
        """
        Asynchronously called when the human dev accepts a PR, reverts a change,
        or explicitly rates the output. This is the GROUND TRUTH.
        """
        if trace_id in self.dataset:
            self.dataset[trace_id].human_accept_reject = accepted
            self.dataset[trace_id].human_outcome_notes = notes
            
            # Recalibrate internal reward based on human ground truth
            if accepted:
                self.dataset[trace_id].reward_score = min(1.0, self.dataset[trace_id].reward_score + 0.2)
            else:
                self.dataset[trace_id].reward_score = max(0.0, self.dataset[trace_id].reward_score - 0.5)
            return True
        return False

    def export_dataset(self) -> List[Dict[str, Any]]:
        """
        Exports the dataset for the ReplaySimulator and PolicyTrainer.
        Only exports traces that have mature outcomes (e.g., human ground truth or verified).
        """
        # In a real system, we'd filter by maturation (e.g., older than 24h to allow human feedback)
        return [p.__dict__ for p in self.dataset.values()]


if __name__ == "__main__":
    capture = WorkloadCaptureLayer()
    
    print("--- Workload Capture Layer ---")
    # Simulate an incoming inference event
    raw_payload = "def connect():\n    api_key = 'sk-1234567890abcdef'\n    db.connect(api_key)"
    raw_telemetry = {
        "trace_id": "trace-998877",
        "tenant_id": "acme_corp",
        "intent_class": "code_review",
        "decomposition_depth": 3,
        "execution_policy": "premium_draft",
        "escalation_path": "local_fast -> premium_draft",
        "latency_ms": 1200.5,
        "cost_usd": 0.0015,
        "cache_hit": False,
        "reward": 0.75,
        "drift": 0.05,
        "verification_outcome": "verified",
        "repo_url": "github.com/acme/core-service"
    }
    
    print("\n[1] Ingesting & Anonymizing Trace...")
    tid = capture.ingest_trace(raw_telemetry, raw_payload)
    print(f"    Trace ID: {tid}")
    print(f"    Redacted Snippet: {capture.anonymize_payload(raw_payload)['redacted_snippet'].strip()}")
    
    print("\n[2] Waiting for Human Ground Truth...")
    # Human rejected it because it hallucinated a db connection parameter
    capture.attach_human_outcome(tid, accepted=False, notes="Hallucinated db parameter")
    print("    Human Rejected: True")
    print(f"    Recalibrated Reward Score: {capture.dataset[tid].reward_score}")
    
    print("\n[3] Exporting Trace for Learning Loop...")
    ds = capture.export_dataset()
    print(f"    Dataset Size: {len(ds)} traces ready for optimization.")
