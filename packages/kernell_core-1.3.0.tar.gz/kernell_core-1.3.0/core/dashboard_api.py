"""
Kernell OS — Forge Observatory API
==================================
Serves real telemetry and governance stats to the React Dashboard.
Reads from the SQLite Flight Recorder.
"""

import sqlite3
import json
import asyncio
import os
import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Forge Observatory")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

DB_PATH = os.path.join(os.path.dirname(__file__), "institutional_memory.db")

def get_stats():
    if not os.path.exists(DB_PATH):
        return {"error": "No database"}
    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row
        
        total = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        if total == 0:
            return {"total_events": 0}
            
        stats = conn.execute("""
            SELECT AVG(reward) as avg_reward, 
                   AVG(cost_usd) as avg_cost, 
                   AVG(latency_ms) as avg_latency, 
                   AVG(drift) as avg_drift,
                   AVG(risk) as avg_risk
            FROM events
        """).fetchone()
        
        recent = conn.execute("""
            SELECT * FROM events ORDER BY timestamp DESC LIMIT 50
        """).fetchall()
        
        # Calculate policy distribution
        policies = conn.execute("""
            SELECT execution_policy, COUNT(*) as count 
            FROM events GROUP BY execution_policy
        """).fetchall()
        
    return {
        "total_events": total,
        "avg_reward": round(stats["avg_reward"] or 0, 4),
        "avg_cost": round(stats["avg_cost"] or 0, 6),
        "avg_latency": round(stats["avg_latency"] or 0, 1),
        "avg_drift": round(stats["avg_drift"] or 0, 4),
        "avg_risk": round(stats["avg_risk"] or 0, 4),
        "policies": {p["execution_policy"]: p["count"] for p in policies},
        "recent_events": [dict(r) for r in recent]
    }

@app.get("/api/forge/stats")
def fetch_stats():
    return get_stats()

@app.websocket("/ws/events")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    try:
        last_count = 0
        while True:
            stats = get_stats()
            if stats.get("total_events", 0) > last_count:
                last_count = stats["total_events"]
                await ws.send_json({"type": "live_telemetry", "data": stats})
            await asyncio.sleep(1.0)
    except WebSocketDisconnect:
        pass

if __name__ == "__main__":
    uvicorn.run("dashboard_api:app", host="0.0.0.0", port=23816, reload=True)
