"""
Kernell OS — Learning Loop & Counterfactual Optimizer
=====================================================
Converts historical telemetry into institutional economic intelligence.
Answers: "What policy SHOULD have been used to maximize VCY/USD?"
and automatically tunes the Budget Engine's parameters.
"""

from typing import List, Dict, Any, Tuple
import math

class CounterfactualOptimizer:
    """
    Evaluates alternative policies against historical traces to find the
    globally optimal configuration for a given intent or workspace.
    """
    def __init__(self):
        # Candidate policies to search over
        self.policy_space = [
            {"tier": "zero_inference", "cost_base": 0.0, "reward_expected": 0.2, "latency": 10},
            {"tier": "local_fast", "cost_base": 0.0001, "reward_expected": 0.5, "latency": 200},
            {"tier": "local_reasoning", "cost_base": 0.0005, "reward_expected": 0.75, "latency": 800},
            {"tier": "premium_draft", "cost_base": 0.0015, "reward_expected": 0.85, "latency": 1500},
            {"tier": "premium_verify", "cost_base": 0.03, "reward_expected": 0.95, "latency": 4000}
        ]

    def evaluate_trace(self, trace: Dict[str, Any], candidate_policy: Dict[str, Any]) -> Dict[str, float]:
        """
        Simulates what would have happened if the trace used the candidate policy.
        """
        intent = trace.get("intent_class", "general")
        complexity = trace.get("complexity", 0.5)
        
        # Simulated outcomes
        sim_cost = candidate_policy["cost_base"] * (1.0 + complexity)
        sim_latency = candidate_policy["latency"] * (1.0 + complexity)
        
        # Reward is constrained by the policy's theoretical max, but degraded by task complexity
        degradation = max(0, complexity - 0.3) if candidate_policy["tier"] != "premium_verify" else 0
        sim_reward = max(0.1, candidate_policy["reward_expected"] - degradation)
        
        # Escalation mechanics
        # If simulated reward falls below trace's minimum acceptable reward, it triggers escalation
        escalation_cost = 0
        if sim_reward < trace.get("min_acceptable_reward", 0.7):
            escalation_cost = 0.03 # premium verify cost
            sim_reward = 0.9 # Escalation fixes reward
            sim_latency += 4000
            
        final_cost = sim_cost + escalation_cost
        vcy_usd = sim_reward / final_cost if final_cost > 0 else 0
        
        return {
            "sim_cost": final_cost,
            "sim_reward": sim_reward,
            "sim_latency": sim_latency,
            "vcy_usd": vcy_usd,
            "escalated": escalation_cost > 0
        }

    def find_optimal_policy(self, traces: List[Dict[str, Any]]) -> str:
        """
        Finds the policy tier that maximizes VCY/USD across all traces.
        """
        best_policy = None
        best_vcy = -1
        
        for candidate in self.policy_space:
            total_vcy = 0
            for trace in traces:
                result = self.evaluate_trace(trace, candidate)
                total_vcy += result["vcy_usd"]
                
            avg_vcy = total_vcy / len(traces)
            if avg_vcy > best_vcy:
                best_vcy = avg_vcy
                best_policy = candidate["tier"]
                
        return best_policy


class PolicyTrainer:
    """
    Updates the institutional memory (adaptive thresholds) based on counterfactual analysis.
    """
    def __init__(self):
        self.optimizer = CounterfactualOptimizer()
        self.learned_thresholds = {}

    def train(self, historical_traces: List[Dict[str, Any]]):
        """
        Groups traces by intent and finds the optimal policy mapping.
        """
        grouped_traces = {}
        for t in historical_traces:
            intent = t.get("intent_class", "general")
            if intent not in grouped_traces:
                grouped_traces[intent] = []
            grouped_traces[intent].append(t)
            
        print("\n🎓 TRAINING LEARNING LOOP: Counterfactual Policy Optimization")
        print("-" * 60)
        
        for intent, traces in grouped_traces.items():
            optimal_tier = self.optimizer.find_optimal_policy(traces)
            
            # Map tier back to verification threshold (heuristic mapping for now)
            if optimal_tier == "premium_verify":
                threshold = 0.95
            elif optimal_tier == "premium_draft":
                threshold = 0.85
            elif optimal_tier == "local_reasoning":
                threshold = 0.70
            elif optimal_tier == "local_fast":
                threshold = 0.50
            else:
                threshold = 0.99 # Force zero inference cache
                
            self.learned_thresholds[intent] = {
                "optimal_tier": optimal_tier,
                "recommended_threshold": threshold,
                "traces_analyzed": len(traces)
            }
            
            print(f"Intent: {intent:<20} | Optimal Tier: {optimal_tier:<15} | New Threshold: {threshold}")
            
        print("-" * 60)
        return self.learned_thresholds

if __name__ == "__main__":
    # Mock Traces
    traces = [
        {"intent_class": "summarization", "complexity": 0.2, "min_acceptable_reward": 0.4},
        {"intent_class": "summarization", "complexity": 0.3, "min_acceptable_reward": 0.5},
        
        {"intent_class": "code_review", "complexity": 0.8, "min_acceptable_reward": 0.85},
        {"intent_class": "code_review", "complexity": 0.9, "min_acceptable_reward": 0.9},
        
        {"intent_class": "security_audit", "complexity": 0.95, "min_acceptable_reward": 0.95},
    ]
    
    trainer = PolicyTrainer()
    trainer.train(traces)
