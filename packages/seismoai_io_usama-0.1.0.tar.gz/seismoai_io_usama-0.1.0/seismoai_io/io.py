"""I/O helpers for loading and preparing seismic SGY gathers."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import segyio


def _read_sgy_contents(file_path: Path) -> tuple[np.ndarray, pd.DataFrame]:
    """Read SGY traces and headers, falling back to little-endian files when needed."""
    open_attempts = (
        {"ignore_geometry": True},
        {"ignore_geometry": True, "endian": "little"},
    )

    last_error: Exception | None = None
    for open_kwargs in open_attempts:
        try:
            with segyio.open(str(file_path), **open_kwargs) as handle:
                traces = np.asarray(segyio.tools.collect(handle.trace[:]), dtype=np.float32)
                headers = pd.DataFrame(
                    [{str(key): value for key, value in handle.header[index].items()} for index in range(handle.tracecount)]
                )
            return traces, headers
        except RuntimeError as error:
            last_error = error

    raise ValueError(f"Unable to read SGY file: {file_path}") from last_error


def load_sgy(path: str | Path) -> dict[str, Any]:
    """Load one SGY file and return its traces, headers, and source path.

    Args:
        path: Path to a `.sgy` or `.segy` file on disk.

    Returns:
        A dictionary with the absolute file path, the trace matrix as a NumPy
        array, and the trace headers as a pandas DataFrame.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the path is not an SGY/SEGY file or the file contains no traces.
    """
    file_path = Path(path).expanduser().resolve()
    if not file_path.exists():
        raise FileNotFoundError(f"SGY file not found: {file_path}")
    if file_path.suffix.lower() not in {".sgy", ".segy"}:
        raise ValueError(f"Expected an SGY/SEGY file, got: {file_path.name}")

    traces, headers = _read_sgy_contents(file_path)

    if traces.ndim != 2 or traces.size == 0:
        raise ValueError(f"SGY file did not contain a valid 2D trace matrix: {file_path}")

    return {
        "path": str(file_path),
        "traces": traces,
        "headers": headers,
    }


def load_sgy_folder(folder_path: str | Path) -> dict[str, dict[str, Any]]:
    """Load all SGY files in a folder and return them keyed by filename.

    Args:
        folder_path: Directory containing one or more `.sgy` or `.segy` files.

    Returns:
        A dictionary mapping each SGY filename to the loaded output from
        `load_sgy()`.

    Raises:
        FileNotFoundError: If the folder does not exist.
        NotADirectoryError: If the provided path is not a directory.
        ValueError: If the folder contains no SGY/SEGY files.
    """
    directory = Path(folder_path).expanduser().resolve()
    if not directory.exists():
        raise FileNotFoundError(f"Folder not found: {directory}")
    if not directory.is_dir():
        raise NotADirectoryError(f"Expected a directory, got: {directory}")

    sgy_files = sorted(
        [candidate for candidate in directory.iterdir() if candidate.is_file() and candidate.suffix.lower() in {".sgy", ".segy"}]
    )
    if not sgy_files:
        raise ValueError(f"No SGY/SEGY files found in folder: {directory}")

    return {sgy_file.name: load_sgy(sgy_file) for sgy_file in sgy_files}


def normalize_traces(traces: np.ndarray, method: str = "zscore") -> np.ndarray:
    """Normalize a 2D trace matrix so downstream modules see stable amplitudes.

    Args:
        traces: Seismic traces with shape `(n_traces, n_samples)`.
        method: Normalization method. Only `"zscore"` is currently supported.

    Returns:
        A normalized copy of the input trace matrix as `float32`.

    Raises:
        ValueError: If the traces are not a 2D matrix or the method is unsupported.
    """
    if method != "zscore":
        raise ValueError(f"Unsupported normalization method: {method}")

    trace_array = np.asarray(traces, dtype=np.float32)
    if trace_array.ndim != 2 or trace_array.size == 0:
        raise ValueError("Traces must be a non-empty 2D array.")

    means = trace_array.mean(axis=1, keepdims=True)
    stds = trace_array.std(axis=1, keepdims=True)
    safe_stds = np.where(stds == 0.0, 1.0, stds)
    normalized = (trace_array - means) / safe_stds

    return normalized.astype(np.float32, copy=False)
