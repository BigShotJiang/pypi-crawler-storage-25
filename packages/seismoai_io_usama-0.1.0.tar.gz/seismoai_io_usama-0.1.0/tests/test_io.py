"""Tests for the seismoai_io Module 1 API."""

from __future__ import annotations

import shutil
import zipfile
from pathlib import Path

import numpy as np
import pytest

from seismoai_io import load_sgy, load_sgy_folder, normalize_traces

DATASET_ZIP = Path(r"C:\Users\hp\Downloads\Correlated_Shot_Gathers-20260417T172906Z-3-001.zip")


def _extract_real_sgy_samples(tmp_path: Path, sample_count: int = 2) -> list[Path]:
    """Extract a small number of real SGY files from the provided archive for tests."""
    if not DATASET_ZIP.exists():
        pytest.skip(f"Real SGY dataset zip not found: {DATASET_ZIP}")

    target_dir = tmp_path / "real_sgy_samples"
    target_dir.mkdir(parents=True, exist_ok=True)

    extracted: list[Path] = []
    with zipfile.ZipFile(DATASET_ZIP) as archive:
        members = [member for member in archive.namelist() if member.lower().endswith(".sgy")]
        if len(members) < sample_count:
            pytest.skip("Dataset zip does not contain enough SGY samples for folder loading tests.")

        for member in members[:sample_count]:
            archive.extract(member, path=target_dir)
            source = target_dir / member
            destination = target_dir / Path(member).name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(source), str(destination))
            extracted.append(destination)

    nested_root = target_dir / "Correlated_Shot_Gathers"
    if nested_root.exists():
        shutil.rmtree(nested_root)

    return extracted


def test_load_sgy_reads_real_dataset_file(tmp_path: Path) -> None:
    sample_file = _extract_real_sgy_samples(tmp_path, sample_count=1)[0]

    result = load_sgy(sample_file)

    assert result["path"].endswith(sample_file.name)
    assert result["traces"].shape == (167, 4001)
    assert not result["headers"].empty
    assert result["headers"].shape[0] == 167


def test_load_sgy_folder_reads_multiple_real_files(tmp_path: Path) -> None:
    sample_files = _extract_real_sgy_samples(tmp_path, sample_count=2)

    result = load_sgy_folder(sample_files[0].parent)

    assert set(result) == {sample_file.name for sample_file in sample_files}
    for payload in result.values():
        assert payload["traces"].shape == (167, 4001)
        assert payload["headers"].shape[0] == 167


def test_normalize_traces_preserves_shape_and_centers_each_trace() -> None:
    traces = np.array([[1.0, 2.0, 3.0], [10.0, 10.0, 10.0]], dtype=np.float32)

    normalized = normalize_traces(traces)

    assert normalized.shape == traces.shape
    assert normalized.dtype == np.float32
    np.testing.assert_allclose(normalized[0].mean(), 0.0, atol=1e-6)
    np.testing.assert_allclose(normalized[0].std(), 1.0, atol=1e-6)
    np.testing.assert_allclose(normalized[1], np.zeros(3, dtype=np.float32))
