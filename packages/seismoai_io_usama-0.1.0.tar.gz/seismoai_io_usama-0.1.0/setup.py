from pathlib import Path

from setuptools import find_packages, setup


README = Path(__file__).with_name("README.md").read_text(encoding="utf-8")


setup(
    name="seismoai-io-usama",
    version="0.1.0",
    description="Module 1 library for loading and preparing seismic SGY files.",
    author="Usama Sherazi",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://github.com/usama-sherazi/seismoai_io",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "pandas",
        "segyio",
    ],
    python_requires=">=3.10",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
