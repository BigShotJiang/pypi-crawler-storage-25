from flask_restx import abort


class DatabaseException(Exception):
    """Base exception for database-related errors."""
    def __init__(self, status_code: int, message: str, data: dict | None = None):
        self.status_code = status_code
        self.message = message
        self.data = data or {}
        super().__init__(self.message)


class FieldValidationError(DatabaseException):
    """Raised when a field validation fails."""
    def __init__(self, field: str):
        super().__init__(
            status_code=400,
            message=f'{field} cannot be null',
            data={'field': field}
        )
        self.field = field


class ForeignKeyNotFoundError(DatabaseException):
    """Raised when a foreign key reference is not found."""
    def __init__(self, field: str, value: str):
        super().__init__(
            status_code=400,
            message=f'invalid foreign key: {field} with id {value} not found',
            data={}
        )
        self.field = field
        self.value = value


class NotFoundError(DatabaseException):
    """Raised when a database entity is not found."""
    def __init__(self, entity_name: str, **kwargs):
        super().__init__(
            status_code=404,
            message=f'{entity_name} with {kwargs} not found',
            data=kwargs
        )
        self.entity_name = entity_name


class AlreadyExistsError(DatabaseException):
    """Raised when attempting to create a duplicate entity."""
    def __init__(self, entity_name: str, details: str, **kwargs):
        super().__init__(
            status_code=409,
            message=f'{entity_name} {details}',
            data=kwargs
        )
        self.entity_name = entity_name
        self.details = details


class DatabaseFailureError(DatabaseException):
    """Raised when a database operation fails."""
    def __init__(self, message: str, **kwargs):
        super().__init__(
            status_code=500,
            message=message,
            data=kwargs
        )


class ErrorResponse:
    @staticmethod
    def error_response(error: tuple[dict]):
        response = error[0]
        status_code = response['status_code']
        message = response['message']
        data = response['data']
        abort(status_code, message, data=data)