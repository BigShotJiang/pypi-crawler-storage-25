try:
    from gevent import monkey
    monkey.patch_all()
    GEVENT_AVAILABLE = True
except ImportError: # pragma: no cover
    GEVENT_AVAILABLE = False
from flask import Flask, request
from flask_restx import Api, Namespace, abort
from flask_restx._http import HTTPStatus
from flask_cors import CORS
from eaasy.api import liveness_ns
from gunicorn.app.base import BaseApplication
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_oidc import OpenIDConnect
from flask_socketio import SocketIO
import redis
import redis.exceptions
import logging
import json
import time
import os

limiter = Limiter(get_remote_address)


class ColoredFormatter(logging.Formatter):  # pragma: no cover
    COLORS = {
        # Gray
        'DEBUG': '\033[90m',
        # Blue
        'INFO': '\033[94m',
        # Yellow
        'WARNING': '\033[93m',
        # Red
        'ERROR': '\033[91m',
        # Magenta
        'CRITICAL': '\033[91m',
    }
    RESET = '\033[0m'

    converter = time.gmtime

    def format(self, record):
        levelname_color = self.COLORS.get(record.levelname, self.RESET)
        record.levelname = f"{levelname_color}{record.levelname}{self.RESET}{f' File:{record.filename} Line:{record.lineno}' if record.levelname in [
            'ERROR', 'WARNING', 'CRITICAL'] else ''}"
        return super().format(record)


class Eaasy:
    def __init__(self, logger: logging.Logger | bool | None = None, **kwargs):
        self._logger = self.__init_logger(logger)

        # Get Flask app and API parameters from kwargs
        name = kwargs.get('name', __name__)
        version = kwargs.get('version', '1.0')
        title = kwargs.get('title', 'API')
        description = kwargs.get('description', 'A simple API')
        doc = kwargs.get('doc', '/swagger')
        authorizations = kwargs.get('authorizations', None)
        security = kwargs.get('security', None)
        config = kwargs.get('config', {})
        oidc = kwargs.get('oidc', None)
        enable_limiter = kwargs.get('enable_limiter', False)
        enable_socket = kwargs.get('enable_socket', False)
        socketio_kwargs = kwargs.get('socketio_kwargs', {})

        # Create Flask app and API
        self._app = Flask(name)
        self._app.config.update(config)

        methods = kwargs.get(
            'methods', ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])
        allow_headers = kwargs.get(
            'allow_headers', ['Content-Type', 'Authorization'])
        expose_headers = kwargs.get('expose_headers', ["Content-Disposition"])
        resources = kwargs.get('resources', {r"/*": {"origins": "*"}})
        supports_credentials = kwargs.get('supports_credentials', True)

        CORS(
            self._app,
            methods=methods,
            allow_headers=allow_headers,
            expose_headers=expose_headers,
            resources=resources,
            supports_credentials=supports_credentials)
        self._app.before_request(self.__before_request)
        self._api = Api(self._app, version=version, title=title, description=description,
                        doc=doc, authorizations=authorizations, security=security)
        self._api.add_namespace(liveness_ns)

        # Initialize OpenID Connect
        if oidc is True:
            self._oidc = OpenIDConnect(self._app)
        elif isinstance(oidc, OpenIDConnect):
            self._oidc = oidc
        else:
            self._oidc = None

        if enable_limiter:
            # Initialize rate limiter
            self.__init_limiter()

        if enable_socket:
            # Initialize SocketIO
            self.__init_socket(socketio_kwargs=socketio_kwargs)

    def __init_limiter(self):
        redis_uri = os.getenv("REDIS_URI", default=None)

        if redis_uri:
            try:
                r = redis.Redis.from_url(redis_uri)
                r.ping()
                self._app.config["RATELIMIT_STORAGE_URI"] = redis_uri
            except redis.exceptions.ConnectionError:
                print(
                    "Could not connect to Redis. Use in-memory storage. \033[93mNot recommended for production.\033[0m")
                redis_uri = None

        limiter.init_app(self._app)

    def __init_logger(self, logger: logging.Logger | bool | None) -> logging.Logger | None:
        if logger is None or logger is False:
            return None
        elif isinstance(logger, bool):
            logging.basicConfig(
                level=logging.INFO,
                format='[%(asctime)s] [%(levelname)s] %(message)s',
                handlers=[logging.StreamHandler()]
            )
            for handler in logging.getLogger().handlers:
                handler.setFormatter(ColoredFormatter(
                    '[%(asctime)s] [%(levelname)s] %(message)s', datefmt="%Y-%m-%d %H:%M:%S +0000"))
            return logging.getLogger(__name__)
        return logger
    
    def __init_socket(self, socketio_kwargs: dict):
        if GEVENT_AVAILABLE:
            async_mode = 'gevent'
            if self._logger:
                self._logger.info('Using gevent async mode for SocketIO')
        else:
            async_mode = 'threading'
            if self._logger:
                self._logger.warning('gevent not found, using threading mode. Install gevent for production use.')
        
        socketio_kwargs.setdefault('async_mode', async_mode)
        socketio_kwargs.setdefault('cors_allowed_origins', "*")
        socketio_kwargs.setdefault('logger', self._logger is not None)
        socketio_kwargs.setdefault('engineio_logger', self._logger is not None)
        if 'message_queue' in socketio_kwargs and socketio_kwargs['message_queue'] is not None and self._logger: # pragma: no cover
            self._logger.info(f"Using message queue for SocketIO: {socketio_kwargs['message_queue']}")
        self._socketio = SocketIO(self._app, **socketio_kwargs)

    def __before_request(self):
        if self._logger:
            self._logger.info(
                f'{request.method} {request.endpoint} {request.remote_addr} {request.user_agent}')

        try:
            if request.method == 'POST' or request.method == 'PUT':
                if request.data:
                    if self._logger:
                        self._logger.debug(
                            f'Payload: {json.dumps(json.loads(request.data))}')
        except Exception as e:
            if self._logger:
                self._logger.error(f'{e}')
            abort(HTTPStatus.BAD_REQUEST, 'Invalid payload',
                  data=f'{request.data.decode()}')

    def run(self, host: str = '127.0.0.1', port: int = 5000, debug: bool = False, **kwargs):
        if hasattr(self, '_socketio'):
            self._socketio.run(self._app, host=host, port=port, debug=debug, log_output=self._logger is not None, **kwargs) # pragma: no cover
        else:
            self._app.run(host=host, port=port, debug=debug, **kwargs)

    def add_namespace(self, namespace: Namespace):
        self._api.add_namespace(namespace)

    @property
    def app(self) -> Flask:
        return self._app

    @property
    def logger(self) -> logging.Logger:
        if self._logger is None:
            raise ValueError('Logger is not enabled')
        return self._logger

    @property
    def oidc(self) -> OpenIDConnect:
        if self._oidc is None:
            raise ValueError('OpenID Connect is not enabled')
        return self._oidc
    
    @property
    def socketio(self) -> SocketIO:
        if not hasattr(self, '_socketio'):
            raise ValueError('SocketIO is not enabled')
        return self._socketio


class GunEaasy(BaseApplication):  # pragma: no cover
    def __init__(self, app: Flask | Eaasy, options: dict | None = None):
        self.options = options or {}
        if isinstance(app, Eaasy):
            self.eaasy = app
            self.application = app.app
        else:
            self.eaasy = None
            self.application = app

        self.__try_init_socket(app)
        
        super().__init__()

    def __try_init_socket(self, app: Eaasy | Flask):
        # Automatically set gevent worker when SocketIO is enabled
        if self.eaasy and hasattr(self.eaasy, '_socketio'):
            if GEVENT_AVAILABLE:
                self.__configure_gevent_worker()
            else:
                self.__configure_sync_worker()
        elif self.eaasy is None and isinstance(app, Flask):
            # Check if the Flask app might have been created by Eaasy with SocketIO
            if hasattr(app, 'extensions') and 'socketio' in app.extensions:
                import warnings
                warnings.warn(
                    "SocketIO detected but GunEaasy received a Flask app instead of an Eaasy instance. "
                    "Pass the Eaasy instance directly to enable auto-configuration: GunEaasy(eaasy_app, options) "
                    "instead of GunEaasy(eaasy_app.app, options)",
                    UserWarning,
                    stacklevel=2
                )
    
    def __configure_gevent_worker(self):
        logger = self.eaasy._logger if self.eaasy else None
        # Set worker_class to gevent if not already specified
        if 'worker_class' not in self.options:
            self.options['worker_class'] = 'gevent'
            if logger:
                logger.info('Auto-configuring Gunicorn to use gevent worker for SocketIO')
        # Force workers to 1 for SocketIO (sticky sessions requirement)
        if 'workers' not in self.options:
            self.options['workers'] = 1

    def __configure_sync_worker(self):
        logger = self.eaasy._logger if self.eaasy else None
        # Use sync worker as fallback
        if 'worker_class' not in self.options:
            self.options['worker_class'] = 'sync'
            if logger:
                logger.warning('gevent not available, using sync worker')

    def load_config(self):
        config = {
            key: value for key, value in self.options.items()
            if self.cfg is not None and key in self.cfg.settings and value is not None}
        if self.cfg is not None:
            for key, value in config.items():
                self.cfg.set(key.lower(), value)

    def load(self): # type: ignore[return-value]
        # Always return the Flask application
        # SocketIO is already attached as middleware to the Flask app
        return self.application
