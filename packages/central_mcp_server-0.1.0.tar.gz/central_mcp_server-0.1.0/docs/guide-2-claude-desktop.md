# Setup: Claude Desktop

Connect the Central MCP Server to Claude Desktop on macOS or Windows.

---

## Before You Begin

Complete **Steps 1 and 2** of the [main setup guide](./guide-2-setup.md) first:
- Step 1 — Get your Central credentials (`CENTRAL_BASE_URL`, `CENTRAL_CLIENT_ID`, `CENTRAL_CLIENT_SECRET`)
- Step 2 — Install the server (`uv tool install --prerelease=allow central-mcp-server`)

---

## Step 1 — Edit the Config File

**Config file location:**
- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`

Open the file (create it if it doesn't exist) and add the `central-mcp` entry under `mcpServers`:

> ## ❗ Important
>
> Never paste your `CENTRAL_CLIENT_SECRET` into the Claude chat window. Anything typed into chat is sent to Anthropic's servers. Credentials belong only in the config file below.

```json
{
  "mcpServers": {
    "central-mcp": {
      "command": "uvx",
      "args": ["--prerelease=allow", "central-mcp-server"],
      "env": {
        "CENTRAL_BASE_URL": "https://us5.api.central.arubanetworks.com",
        "CENTRAL_CLIENT_ID": "your-client-id",
        "CENTRAL_CLIENT_SECRET": "your-client-secret"
      }
    }
  }
}
```

Replace all placeholder values with your actual credentials.

> ## 📘 Why this config file is safe
>
> This file is stored at the system level outside any project workspace — Claude cannot read it. Credentials in the `env` block are passed as OS environment variables to start the server process and are never included in messages sent to Anthropic. See [How credentials stay secure](./guide-2-setup.md#-how-credentials-stay-secure) for the full explanation.

After saving, **fully quit and relaunch Claude Desktop** — changes are only picked up on a fresh start.

---

## Step 2 — Verify the Connection

A hammer icon (🔨) appears in the bottom-right corner of the chat input bar when at least one MCP server is connected. Click it to see the tools list.

![Claude Desktop hammer icon](./images/claude-desktop-hammer-icon.png)

> ## 📘 What tools will I see?
>
> The server uses **dynamic tool loading** (CodeMode). You will see discovery meta-tools — `Search`, `GetSchemas`, `GetTags`, `Execute` — rather than individual `central_*` tools. This is expected. The AI uses these meta-tools to find and call the right Central tools on demand when you ask a question.

---

## Step 3 — First Test

In the Claude Desktop chat, ask:

```
Which sites have poor health scores right now?
```

A successful response retrieves live site data from your Central instance and returns health scores. If you see tool call activity followed by a structured response, the connection is working.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| Hammer icon not appearing | Config file not saved or Claude not relaunched | Fully quit (not just close the window) and relaunch Claude Desktop |
| `command not found: uvx` | `uv` not installed or not on PATH | Install `uv` and ensure it's on your system PATH |
| `CENTRAL_BASE_URL` error | Incorrect URL format | URL must start with `https://` and have no trailing slash |
| Authentication error | Wrong or expired credentials | Verify Client ID and Secret; recreate the API client in HPE GreenLake if needed |
| Only see `Search`/`Execute` tools | CodeMode is active — expected | Ask questions naturally; the AI discovers and calls the right tools on demand |

---

## What's Next

- [Using the Guided Prompts](./guide-3-guided-prompts.md) — Run pre-built investigation workflows with a single `/` command
- [Central MCP in Action](./guide-4-in-action.md) — See Claude Desktop walkthrough with sample output
