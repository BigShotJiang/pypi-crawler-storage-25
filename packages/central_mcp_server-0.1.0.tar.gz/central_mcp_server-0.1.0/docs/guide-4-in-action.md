# Central MCP Server in Action

Live examples across Claude Desktop, GitHub Copilot Chat, and Claude Code.

---

Each example below shows a real query, the tool calls the AI makes automatically, and the output returned — using realistic network data to illustrate what you can expect.

---

## Claude Desktop — Troubleshooting a Site

Claude Desktop surfaces MCP prompts through a slash-command picker. This example uses the `troubleshoot_site` guided prompt to run a full site investigation in one step.

### Invocation

In the Claude Desktop chat input, type `/` to open the prompt picker. Scroll to or search for `troubleshoot_site`, then select it.

![Claude Desktop prompt picker](./images/claude-desktop-prompt-picker.gif)

Claude prompts you to fill in the `site_name` argument. Enter the site name exactly as it appears in HPE Aruba Networking Central.

![Claude Desktop argument dialog](./images/claude-desktop-argument-dialog.png)

### What the AI Does

The server uses **dynamic tool loading** (CodeMode) — Claude does not call `central_*` tools directly. Instead, it uses the `Search` and `GetSchemas` meta-tools to discover the tools it needs for this investigation, then calls `Execute` to run a script that chains `central_get_site_name_id_mapping` → `central_get_sites` → `central_get_alerts` → `central_get_devices` in sequence. The full investigation takes 10–15 seconds.

![Claude Desktop CodeMode response](./images/claude-desktop-codemode-response.png)

### Sample Output

```
## HQ Campus — Site Troubleshooting Summary

Health Score: 58/100 (Fair)
  Poor: 28% | Fair: 34% | Good: 38%

Devices: 62 total
  Online: 57 | Offline: 5

Clients: 487 connected, 11 failed

Active Alerts: 14
  Critical: 3 | High: 6 | Medium: 4 | Low: 1

─────────────────────────────────────────
CRITICAL ALERTS
─────────────────────────────────────────
1. WAN Link Down
   Gateway GW-HQ-CORE-01 — primary WAN uplink unreachable for 3h 42m
   Category: WAN

2. AP Down
   Access Point AP-CONF-B2-07 offline — no response to keepalives for 2h 10m
   Category: WLAN

3. High Client Failure Rate
   Switch SW-FLOOR3-01 — 18% client failure rate on port-group VLAN 40
   Category: Clients

─────────────────────────────────────────
DEVICE STATUS
─────────────────────────────────────────
Access Points:  38 total — 36 online, 2 offline
  Offline: AP-CONF-B2-07, AP-LOBBY-NORTH-01

Switches:       18 total — 18 online

Gateways:        6 total — 3 online, 3 offline
  Offline: GW-HQ-CORE-01, GW-HQ-CORE-02, GW-HQ-BRANCH-01

─────────────────────────────────────────
RECOMMENDED NEXT STEPS
─────────────────────────────────────────
1. Verify WAN uplink and failover state on GW-HQ-CORE-01 — three gateways offline
   suggests a WAN or uplink aggregation issue, not individual device failures.
2. Check physical connectivity for AP-CONF-B2-07 and AP-LOBBY-NORTH-01.
3. Investigate client failures on SW-FLOOR3-01 VLAN 40 — run
   `failed_clients_investigation` for HQ Campus to identify affected devices.
```

---

## GitHub Copilot Chat — Investigating Failed Clients

GitHub Copilot Chat in VS Code agent mode supports direct conversational queries. This example asks a natural-language question without using a guided prompt — the AI selects and calls the appropriate tools on its own.

### Invocation

Open the **Copilot Chat** panel in VS Code (View → GitHub Copilot → Open Chat). Switch to **Agent mode** using the mode selector at the top of the panel.

![VS Code Copilot Agent mode](./images/vscode-copilot-agent-mode.png)

Type your question directly:

```
Show me all failed wireless clients at the Chicago office in the last 24 hours.
```

![VS Code Copilot query typed](./images/vscode-copilot-query-typed.png)

### What the AI Does

Copilot uses the `Search` meta-tool to identify the client lookup tools, retrieves their schemas via `GetSchemas`, then executes a script that resolves "Chicago office" to a site name via `central_get_site_name_id_mapping` and calls `central_get_clients` with `site_name="Chicago Office"`, `connection_type="Wireless"`, and `status="Failed"`.

![VS Code Copilot response](./images/vscode-copilot-response.png)

### Sample Output

```
Found 8 failed wireless clients at Chicago Office in the last 24 hours.

CLIENT DETAILS
──────────────────────────────────────────────────────────────────
MAC Address        Name              Status   WLAN           Band   Last Seen
──────────────────────────────────────────────────────────────────
b8:27:eb:4a:1f:cc  LAPTOP-CHI-047   Failed   Corp-Secure    5 GHz  2h 14m ago
a4:c3:f0:88:2e:91  LAPTOP-CHI-052   Failed   Corp-Secure    5 GHz  2h 16m ago
dc:a6:32:71:9d:3b  PHONE-CHI-019    Failed   Corp-Mobile    5 GHz  3h 05m ago
f0:18:98:b3:7c:44  LAPTOP-CHI-031   Failed   Corp-Secure    2.4GHz 4h 22m ago
18:65:90:cc:5a:87  LAPTOP-CHI-038   Failed   Corp-Secure    2.4GHz 4h 23m ago
30:b5:c2:e7:4d:19  IPAD-CHI-006     Failed   Corp-Mobile    5 GHz  5h 51m ago
7c:2f:80:a1:d3:5e  PHONE-CHI-024    Failed   Corp-Mobile    2.4GHz 6h 17m ago
e4:5f:01:6b:88:c0  LAPTOP-CHI-011   Failed   Corp-Secure    5 GHz  8h 03m ago
──────────────────────────────────────────────────────────────────

PATTERNS OBSERVED
- 5 of 8 failures are on Corp-Secure WLAN (802.1X authentication).
- 3 of 8 failures are on Corp-Mobile WLAN (PSK).
- Failures are distributed across both 2.4 GHz and 5 GHz — not a band-specific issue.
- All 8 clients last failed within an 8-hour window starting ~2h ago,
  suggesting a possible authentication server or RADIUS event during that period.

SUGGESTED FOLLOW-UP
Run `failed_clients_investigation` for Chicago Office for device-level detail,
or check RADIUS server logs for authentication failures in the same time window.
```

---

## Claude Code — Network Health Overview

Claude Code is a terminal-based AI assistant. This example shows a conversational session where the network health overview is triggered through natural language — no slash command required.

### Invocation

Start a Claude Code session from the terminal:

```bash
claude
```

Ask the question conversationally:

```
Give me a health overview of the whole network.
```

![Claude Code session running](./images/claude-code-session-running.png)

### What the AI Does

Claude uses `Search` to find the site listing tools, fetches their schemas via `GetSchemas`, then runs an `Execute` script that calls `central_get_site_name_id_mapping` to retrieve all sites, identifies those with poor health or elevated alert counts, and calls `central_get_sites` for up to 5 flagged sites to retrieve detailed metrics — all in a single execution.

![Claude Code response complete](./images/claude-code-response-complete.png)

### Sample Output

```
NETWORK HEALTH OVERVIEW
Retrieved: 2026-03-24 09:15 UTC
─────────────────────────────────────────────────────────────────────────
SITE SUMMARY (18 sites total)

Site                  Health   Devices   Clients   Alerts
─────────────────────────────────────────────────────────────────────────
HQ Campus             58       62        498       14  ← Poor
Chicago Office        71       41        312        6  ← Fair
Austin Branch         79       28        204        2
Seattle Office        82       35        267        1
Boston Campus         85       54        431        3
Dallas Hub            88       19         98        0
Atlanta Branch        89       22        143        0
Denver Office         90       17         87        0
Miami Branch          91       14         72        1
Portland Office       93       11         54        0
... (8 additional sites, all health ≥ 90, 0–1 alerts each)
─────────────────────────────────────────────────────────────────────────

SITES REQUIRING ATTENTION

HQ Campus (Health: 58 — Fair/Poor)
  Active Alerts: 14 (3 Critical, 6 High)
  Devices Offline: 5 (2 APs, 3 Gateways)
  Critical: WAN Link Down on GW-HQ-CORE-01 — affects 3 gateway cluster

Chicago Office (Health: 71 — Fair)
  Active Alerts: 6 (1 Critical, 3 High)
  Devices Offline: 1 (Switch SW-CHI-ACCESS-04)
  Critical: Switch Down — SW-CHI-ACCESS-04 offline 4h 30m, 47 clients affected

─────────────────────────────────────────────────────────────────────────
OVERALL ASSESSMENT

16 of 18 sites are in Good health (≥80). Two sites require immediate attention:

- HQ Campus: Gateway cluster issue with WAN link down. High client failure rate
  on VLAN 40 suggests downstream impact. Recommend escalating WAN investigation.

- Chicago Office: Access switch offline for 4+ hours with significant client impact.
  Physical or uplink failure likely — check switch power and uplink port.

Run `troubleshoot_site` for either site for a full device and alert breakdown.
```

---

## What's Next

**Set up your client:**
- [Claude Desktop](./guide-2-claude-desktop.md)
- [Claude Code CLI](./guide-2-claude-code.md)
- [VS Code with GitHub Copilot Chat](./guide-2-github-copilot.md)
- [All clients and shared setup](./guide-2-setup.md)

**Explore the workflows:**
- [Using the Guided Prompts](./guide-3-guided-prompts.md) — Full reference for all 10 built-in workflows
