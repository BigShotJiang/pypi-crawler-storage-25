# Setup and Configuration

Install the Central MCP Server and connect it to your AI assistant client.

---

## Prerequisites

Before you begin, confirm you have:

- An HPE Aruba Networking Central account with API access enabled
- [`uv`](https://docs.astral.sh/uv/getting-started/installation/) installed (`uv --version` to verify)
- One of the supported AI clients: Claude Desktop, Claude Code CLI, or VS Code with GitHub Copilot Chat

---

## Step 1 — Get Your Credentials

You need three values: `CENTRAL_BASE_URL`, `CENTRAL_CLIENT_ID`, and `CENTRAL_CLIENT_SECRET`.

### CENTRAL_BASE_URL

The API gateway base URL for your Central instance (e.g. `https://us5.api.central.arubanetworks.com`).

> ## 📘 Important Links
>
> - [Finding Your Base URL in Central](https://developer.arubanetworks.com/new-central/docs/getting-started-with-rest-apis#finding-your-base-url)

### CENTRAL_CLIENT_ID and CENTRAL_CLIENT_SECRET

OAuth credentials created through the HPE GreenLake Platform:

1. Log in to your HPE GreenLake account and open **Manage Workspace**.
2. Click **Personal API clients**.
3. Click **Create Personal API client**.
4. Enter a nickname (e.g. `central-mcp-server`) and select your **HPE Aruba Networking Central** instance from the service dropdown.
5. Click **Create personal API client**.
6. Copy both the **Client ID** and **Client Secret** immediately.

> ## ❗ Important
>
> The HPE GreenLake Platform does not store the Client Secret after creation. If you navigate away without copying it, you must delete the client and create a new one.

> ## 📘 Important Links
>
> - [Generating and Managing Access Tokens](https://developer.arubanetworks.com/new-central/docs/generating-and-managing-access-tokens)

---

> ## ❗ How credentials stay secure
>
> Credentials in the `env` block of an MCP config file are passed as OS-level environment variables to the server process at startup — the same mechanism as `docker run -e KEY=val`. These values **never appear in any message sent to the AI provider.** The AI model only receives the data your tools return (your Central network data), not the credentials used to start the server.
>
> **VS Code note:** `.vscode/mcp.json` lives inside your project workspace. Add it to `.gitignore` so credentials are never committed to version control. See the [VS Code setup guide](./guide-2-github-copilot.md) for details.
>
> **One universal rule:** Never type or paste credentials directly into the AI chat window. Anything typed into chat is sent to the AI provider.

## Step 2 — Install the Server

```bash
uv tool install --prerelease=allow central-mcp-server
```

---

## Step 3 — Configure Your AI Client

Select your client for platform-specific configuration:

| Client | Setup Guide |
|--------|------------|
| **Claude Desktop** | [Setup: Claude Desktop](./guide-2-claude-desktop.md) |
| **Claude Code CLI** | [Setup: Claude Code CLI](./guide-2-claude-code.md) |
| **VS Code with GitHub Copilot Chat** | [Setup: VS Code / GitHub Copilot Chat](./guide-2-github-copilot.md) |

---

## Shared Troubleshooting

These issues apply across all clients. For client-specific problems, see the individual setup guide for your client.

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| `command not found: uvx` | `uv` not installed or not on PATH | Install `uv` and ensure it is on your system PATH |
| Dependency resolution error mentioning `pycentral` | Pre-release dependency not enabled | Re-run install with `uv tool install --prerelease=allow central-mcp-server` |
| Credentials not found on first tool call | `env` block missing or values not filled in | Check that the `env` block in your MCP config file contains your actual credentials (not placeholder text) |
| `CENTRAL_BASE_URL` error on first tool call | Incorrect URL format | URL must start with `https://` and have no trailing slash (e.g. `https://us5.api.central.arubanetworks.com`) |
| Authentication error on first tool call | Wrong or expired credentials | Verify Client ID and Secret; if the secret was not copied immediately after creation, create a new API client in HPE GreenLake |
| Only see `Search`/`GetSchemas`/`Execute` instead of `central_*` tools | CodeMode is active — this is expected | Ask questions naturally; the AI discovers and calls the right tools on demand |

---

## What's Next

- [Using the Guided Prompts](./guide-3-guided-prompts.md) — Run pre-built investigation workflows without knowing which tools to call
- [Central MCP in Action](./guide-4-in-action.md) — See live examples across Claude Desktop, GitHub Copilot Chat, and Claude Code
