# Setup: VS Code with GitHub Copilot Chat

Connect the Central MCP Server to GitHub Copilot Chat in VS Code agent mode.

---

## Requirements

Before you begin, confirm you have all of the following:

| Requirement | How to verify |
|------------|---------------|
| VS Code **1.99 or later** | Help → About, or `code --version` |
| **GitHub Copilot Chat** extension (not just base Copilot) | Extensions panel — search "GitHub Copilot Chat" |
| `"chat.mcp.enabled": true` in VS Code settings | Settings UI → search "chat mcp" or add to `settings.json` |
| Central credentials from the [main setup guide](./guide-2-setup.md) | `CENTRAL_BASE_URL`, `CENTRAL_CLIENT_ID`, `CENTRAL_CLIENT_SECRET` |
| `uv` installed | `uv --version` in terminal |

> ## ❗ Important
>
> Without `"chat.mcp.enabled": true` in your VS Code settings, VS Code silently ignores the `.vscode/mcp.json` file. This is the most common reason MCP tools don't appear in Copilot Chat. Set this first before adding the config file.

**To enable MCP in VS Code settings:**
- Open Settings (**Ctrl/Cmd+,**), search for `chat.mcp`, and toggle **Chat: MCP Enabled** to on
- Or add directly to `settings.json`: `"chat.mcp.enabled": true`

---

## Step 1 — Install the Server

```bash
uv tool install --prerelease=allow central-mcp-server
```

---

## Step 2 — Create the MCP Config File

Create `.vscode/mcp.json` in your workspace root (the file and directory won't exist by default):

> ## ❗ Important
>
> Never paste your `CENTRAL_CLIENT_SECRET` into the Copilot chat window. Anything typed into chat is sent to GitHub's servers. Credentials belong only in the config file below.

```json
{
  "servers": {
    "central-mcp": {
      "type": "stdio",
      "command": "uvx",
      "args": ["--prerelease=allow", "central-mcp-server"],
      "env": {
        "CENTRAL_BASE_URL": "https://us5.api.central.arubanetworks.com",
        "CENTRAL_CLIENT_ID": "your-client-id",
        "CENTRAL_CLIENT_SECRET": "your-client-secret"
      }
    }
  }
}
```

Replace all placeholder values with your actual credentials.

> ## 📘 VS Code uses a different JSON schema
>
> VS Code's MCP config uses `"servers"` (not `"mcpServers"`) and requires `"type": "stdio"` for each server entry. This is different from Claude Desktop, Cursor, and Windsurf — using the wrong schema will cause the server to be ignored silently.

---

## Step 3 — Add `.vscode/mcp.json` to `.gitignore`

The config file contains your credentials and must not be committed to version control. Add it to your `.gitignore`:

```
.vscode/mcp.json
```

If your workspace doesn't have a `.gitignore` yet, create one at the workspace root with this line.

> ## 📘 Why gitignore instead of env variable references
>
> An earlier approach used `${env:VARIABLE}` references in `mcp.json` and required exporting credentials to your shell profile (`~/.zshrc`). This silently broke when VS Code was opened from the Dock or Spotlight rather than a terminal. Putting credentials directly in `mcp.json` and gitignoring the file is simpler and works regardless of how VS Code is launched.

After saving, reload the VS Code window: **Ctrl/Cmd+Shift+P → Developer: Reload Window**.

---

## Step 4 — Approve Tool Calls

On the first time a Central MCP tool is used, VS Code will prompt you to approve it. Click **Allow** to proceed. You can also set tools to always allow from the same dialog.

![VS Code tool approval dialog](./images/vscode-tool-approval-dialog.gif)

---

## Step 5 — Verify the Connection

Open the **Copilot Chat** panel (**View → GitHub Copilot → Open Chat**). Switch to **Agent mode** using the mode selector at the top of the panel.

![VS Code Agent mode selector](./images/vscode-agent-mode-selector.png)

Click the tools icon to expand the tool list. You should see the `central-mcp` server listed with CodeMode discovery tools (`Search`, `GetSchemas`, `Execute`).

> ## 📘 What tools will I see?
>
> The server uses **dynamic tool loading** (CodeMode). You will see discovery meta-tools — `Search`, `GetSchemas`, `Execute` — rather than individual `central_*` tools. This is expected. Copilot uses these meta-tools to discover and call the right Central tools on demand based on your question.

---

## Step 6 — First Test

In the Copilot Chat panel (Agent mode), ask:

```
Which sites have poor health scores right now?
```

A successful response retrieves live site data from your Central instance. If Copilot runs tool calls and returns a structured response, the connection is working.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| No MCP tools in Copilot Chat | `chat.mcp.enabled` not set | Add `"chat.mcp.enabled": true` to VS Code settings |
| Agent mode unavailable | VS Code < 1.99 or GitHub Copilot Chat extension not installed | Update VS Code to 1.99+ and install the **GitHub Copilot Chat** extension |
| Server not appearing after adding `.vscode/mcp.json` | Window not reloaded | **Ctrl/Cmd+Shift+P → Developer: Reload Window** |
| `command not found: uvx` | `uv` not installed or not on PATH | Install `uv` and ensure it's on your system PATH |
| Credentials not found error | `env` block values not filled in | Verify `.vscode/mcp.json` contains your actual credentials (not placeholder text) |
| Authentication error | Wrong or expired credentials | Verify Client ID and Secret; recreate the API client in HPE GreenLake if needed |
| Only see `Search`/`Execute` tools | CodeMode is active — expected | Ask questions naturally; Copilot discovers and calls the right tools on demand |

---

## What's Next

- [Using the Guided Prompts](./guide-3-guided-prompts.md) — Run pre-built investigation workflows in agent mode
- [Central MCP in Action](./guide-4-in-action.md) — See a GitHub Copilot Chat walkthrough with sample output
