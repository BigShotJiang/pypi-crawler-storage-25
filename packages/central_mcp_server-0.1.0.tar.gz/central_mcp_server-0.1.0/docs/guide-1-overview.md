# Central MCP Server

Connect AI assistants to your HPE Aruba Networking Central instance and query live network data through conversation.

> ## 🚧 Unofficial Community Project
>
> This is **not** an officially supported product of HPE. It is provided as-is, with no warranty or guarantee of fitness for any purpose. Review your organization's corporate device and data policies before connecting this server to any AI assistant.

---

The Central MCP Server wraps the HPE Aruba Networking Central REST APIs and exposes them as [MCP (Model Context Protocol)](https://modelcontextprotocol.io) tools. Once configured, an AI assistant in a supported client — Claude Desktop, VS Code with GitHub Copilot Chat, or Claude Code — can answer network questions by calling these tools and reporting the live results.

> ## 📘 What is MCP?
>
> The [Model Context Protocol](https://modelcontextprotocol.io) (MCP) is an open standard that defines how AI models connect to external tools and data sources. It provides a uniform interface — any MCP-compatible AI client (Claude, GitHub Copilot) can connect to any MCP server without custom integration work. The Central MCP Server implements this protocol so that any supported client can call Central's APIs through the same connection setup.
>
> Learn more at [modelcontextprotocol.io](https://modelcontextprotocol.io).

## What You Can Ask

Once connected, you can ask your AI assistant questions like:

- *"Which sites have poor health scores right now?"*
- *"Show me all failed wireless clients at site HQ in the last 24 hours."*
- *"What events happened on switch SW-CORE-01 yesterday?"*
- *"Are there any critical alerts active on the Boston campus?"*
- *"Compare the health of Site A and Site B."*
- *"How many clients are connected at the Chicago office right now?"*

The assistant retrieves live data from Central to answer each question — it does not draw from cached or static snapshots.

## What It Cannot Do

The server is **read-only**. It exposes only GET operations against the Central API. It cannot:

- Modify device configuration or apply templates
- Provision or deprovision devices
- Trigger firmware upgrades or reboots
- Create, acknowledge, or clear alerts
- Write to or modify any data in Central

> ## 📘 Note
>
> This constraint is intentional. The server is scoped to monitoring and diagnostics use cases. Any action that changes network state must be performed directly in Central.

## What the Server Exposes

### Tools

The server provides 9 underlying tools, organized by resource type:

| Category | Tools |
|----------|-------|
| **Sites** | `central_get_sites`, `central_get_site_name_id_mapping` |
| **Devices** | `central_get_devices`, `central_find_device` |
| **Clients** | `central_get_clients`, `central_find_client` |
| **Alerts** | `central_get_alerts` |
| **Events** | `central_get_events`, `central_get_events_count` |

Tools are invoked automatically by the AI assistant in response to your questions. You do not call them directly.

> ## 📘 Dynamic Tool Loading
>
> The server uses **dynamic tool loading** (FastMCP's CodeMode). Instead of sending the full catalog of 9 tools to your AI client upfront — which burns context tokens before you've asked a question — CodeMode gives the AI meta-tools for on-demand discovery:
>
> - **Search** — finds relevant tools by keyword
> - **GetSchemas** — fetches parameter details for tools it needs
> - **Execute** — runs code that chains multiple tool calls in a single request
>
> **Benefits:** smaller token footprint, faster responses, and better multi-step orchestration. This is transparent to you — ask questions naturally and the AI discovers the right tools on its own. You won't see `central_*` tool names in your client's tool picker, and that's expected.

### Guided Prompts

The server also includes 10 built-in guided prompts — pre-built investigation workflows that instruct the AI to run a specific sequence of tool calls and return a structured analysis. These cover common monitoring tasks like site troubleshooting, failed client investigation, and network-wide health reviews.

See [Using the Guided Prompts](/new-central/docs/central-mcp-guided-prompts) for the full list and how to invoke them.

## Data and Security

All queries go directly from your machine to your HPE Aruba Networking Central instance via the Central REST API. No network data passes through the MCP server itself or to any third party.

Your AI assistant does receive the API responses — the same data you would see in the Central UI. Before connecting, confirm that your organization's security policies permit AI assistant access to this data.

> ## ❗ How credentials stay secure
>
> Credentials in the `env` block of an MCP config file are passed as OS-level environment variables to the server process at startup — the same mechanism as `docker run -e KEY=val` or CI/CD secret injection. These values **never appear in any message sent to the AI provider.** The AI model only receives the data your tools return (your Central network data), not the configuration used to start the server.
>
> **The exception — workspace-level config files:** AI assistants with file-reading capabilities (Copilot in agent mode, Claude Code) can read files inside your project directory. If credentials are hardcoded in a workspace file like `.vscode/mcp.json`, they could be pulled into context sent to the AI provider. The [VS Code setup guide](./guide-2-github-copilot.md) uses `${env:VAR}` references to avoid this.
>
> **One universal rule:** Never type or paste credentials directly into the AI chat window. Anything typed into chat is sent to the AI provider.

## Prerequisites

Before you configure the server, you need:

- An **HPE Aruba Networking Central** account with API access enabled
- [`uv`](https://docs.astral.sh/uv/getting-started/installation/) installed on your machine
- One of the [supported MCP clients](#supported-clients): Claude Desktop, VS Code with GitHub Copilot Chat, or Claude Code CLI

## Supported Clients

| Client | Notes |
|--------|-------|
| Claude Desktop | macOS and Windows |
| VS Code with GitHub Copilot Chat | Workspace-level config via `.vscode/mcp.json` |
| Claude Code CLI | Command-line setup |

---

## What's Next

- [Setup and Configuration](/new-central/docs/central-mcp-setup) — Install the server and configure your MCP client
- [Using the Guided Prompts](/new-central/docs/central-mcp-guided-prompts) — Run pre-built network investigation workflows
