# Using the Guided Prompts

Pre-built investigation workflows for common network monitoring tasks.

---

Guided prompts are structured workflows built into the Central MCP Server. When you invoke one, the AI assistant follows a specific sequence of tool calls — fetching sites, devices, alerts, and events in the right order — and returns a structured analysis. You do not need to know which tools to call or in what sequence.

Each prompt accepts one or more named inputs (a site name, a MAC address, a time range) and runs a complete investigation from there.

---

## How to Invoke a Prompt

### Claude Desktop

Type `/` in the chat input box. A menu appears listing all available prompts from connected MCP servers. Select a prompt from the list, then fill in any required inputs when prompted.

[SCREENSHOT: Claude Desktop chat input showing the `/` prompt menu with Central MCP prompts listed]

### Cursor

In agent mode, type `/` or use the `@` mention followed by the prompt name. Cursor surfaces MCP prompts as slash commands in the agent input.

### VS Code with GitHub Copilot

In the Copilot Chat panel in **Agent mode**, type `/` to trigger the prompt list. Select the prompt and provide the required inputs in the chat.

### Windsurf

In the Cascade agent panel, type `/` to list available prompts. Select from the menu and follow the input fields.

### Claude Code CLI

Pass the prompt as a one-shot query using the `-p` flag:

```bash
claude -p "Run the troubleshoot_site prompt for site HQ Campus"
```

Or start an interactive session and describe the investigation conversationally — the AI will select and invoke the appropriate prompt based on your description:

```bash
claude
> Troubleshoot the HQ Campus site
```

---

## Prompt Reference

The 10 prompts are organized into three workflow categories.

### Network-Wide Assessment

Use these when you want a view across the entire network, not scoped to a single site.

| Prompt | Inputs | What it does |
|--------|--------|-------------|
| `network_health_overview` | None | Fetches all sites, identifies those with poor health or high alert counts, retrieves detailed metrics for up to 5 of them, and returns a network-wide health summary with flagged sites |
| `critical_alerts_review` | None | Fetches alert counts for every site, pulls active alerts for all sites that have any, filters to Critical severity, and returns a ranked list of affected sites with recommended actions |

**When to use:** Morning health checks, NOC dashboards, executive summaries, or any time you want to know the overall state of the network before drilling in.

---

### Site-Level Investigation

Use these when you have a specific site in mind.

| Prompt | Inputs | What it does |
|--------|--------|-------------|
| `troubleshoot_site` | `site_name` | Verifies the site, pulls detailed metrics, retrieves all active alerts prioritized by severity, lists all devices, and returns a structured troubleshooting summary with recommended next steps |
| `site_event_summary` | `site_name`, `time_range` (default: `last_24h`) | Gets all events at a site for the specified window, groups them by category and event type, and highlights spikes, repeated errors, and critical events |
| `site_client_overview` | `site_name` | Fetches all clients at a site and breaks them down by connection type (Wired/Wireless), status (Connected/Failed), and VLAN — with WLAN distribution for wireless clients |
| `failed_clients_investigation` | `site_name` | Finds all failed clients at the site, checks the health of their connected devices, pulls client-category alerts, and identifies common failure patterns and likely root causes |
| `device_type_health` | `site_name`, `device_type` | Lists all devices of the specified type at the site, pulls relevant active alerts, checks event counts for alerting devices, and summarizes provisioning status and recommended actions |
| `compare_site_health` | `site_names` (list) | Fetches detailed metrics and active alert breakdowns for each site in the list and presents a side-by-side comparison table ranked from worst to best health |

**When to use:** Incident response, proactive site reviews, or investigating a specific user complaint about a named location.

---

### Entity-Level Lookup

Use these when you have a specific device serial number or client MAC address.

| Prompt | Inputs | What it does |
|--------|--------|-------------|
| `client_connectivity_check` | `mac_address` | Looks up the client, retrieves site-level active alerts, checks the health of the client's connected device, and returns connection details with a likely root cause if the client is in a Failed state |
| `investigate_device_events` | `serial_number`, `time_range` (default: `last_24h`) | Confirms the device exists, maps it to the correct event context type, gets a count breakdown of events, fetches full event details if any exist, and returns a timeline with dominant event types and recommendations |

**When to use:** Helpdesk tickets ("this user can't connect"), device-specific anomaly investigation, or post-change verification for a known device.

---

## Walkthrough: `troubleshoot_site`

Here is how a `troubleshoot_site` investigation runs end to end.

### Invocation

In Claude Desktop, type `/` and select `troubleshoot_site`. Enter the site name when prompted:

```
site_name: HQ Campus
```

### What the AI Does

The prompt instructs the assistant to run this sequence:

1. **`central_get_site_name_id_mapping`** — Verifies `"HQ Campus"` exists in Central and retrieves its `site_id` and current health score.
2. **`central_get_sites`** with `site_names=["HQ Campus"]` — Fetches detailed metrics: health score breakdown (Poor/Fair/Good percentages), device counts, client counts, and alert totals.
3. **`central_get_alerts`** with `site_id=<id>` and `status="Active"` — Retrieves all active alerts at the site, sorted newest first, prioritized by severity (Critical → High → Medium → Low).
4. **`central_get_devices`** with `site_id=<id>` — Lists all devices at the site with their status, type, model, and firmware version.

### Example Output

```
## HQ Campus — Site Troubleshooting Summary

**Health Score:** 62/100 (Fair)
- Good: 40% | Fair: 35% | Poor: 25%

**Devices:** 48 total — 44 online, 4 offline
**Clients:** 312 connected, 7 failed
**Active Alerts:** 9 (2 Critical, 4 High, 3 Medium)

---

### Active Alerts (Critical)
1. **AP Down** — Access Point AP-CONF-03 has been offline for 2h 14m (Severity: Critical, Category: WLAN)
2. **WAN Link Down** — Primary WAN uplink on GW-HQ-01 is unreachable (Severity: Critical, Category: WAN)

### Active Alerts (High)
...

### Device Status Overview
- Access Points: 28 total — 26 online, 2 offline (AP-CONF-03, AP-LOBBY-01)
- Switches: 14 total — 14 online
- Gateways: 6 total — 4 online, 2 offline

### Recommended Next Steps
- Investigate AP-CONF-03 and AP-LOBBY-01 offline status — check power and uplink connectivity
- Confirm WAN failover is active on GW-HQ-01
- Review 7 failed clients — run `failed_clients_investigation` for HQ Campus for detail
```

---

## Prompts vs. Direct Questions

**Use a guided prompt** when you have a known starting point (a site name, a serial number, a MAC address) and want a structured, multi-step investigation returned as a complete analysis.

**Ask a direct question** when you want a quick, targeted lookup — for example, `"What is the health score of Site A?"` or `"Is device SN-12345 online?"`. The AI will call the appropriate tool and answer directly without running a full workflow.

You can also combine both: start with `network_health_overview` to identify a problem site, then follow up with direct questions to dig into specific devices or clients.

---

## What's Next

- [Central MCP Server Overview](/new-central/docs/central-mcp-overview) — What the server does and what it cannot do
- [Setup and Configuration](/new-central/docs/central-mcp-setup) — Install the server and configure your MCP client
