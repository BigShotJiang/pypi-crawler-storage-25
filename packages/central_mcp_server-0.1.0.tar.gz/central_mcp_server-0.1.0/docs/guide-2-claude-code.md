# Setup: Claude Code CLI

Connect the Central MCP Server to Claude Code, Anthropic's terminal-based AI assistant.

---

## Before You Begin

Complete **Steps 1 and 2** of the [main setup guide](./guide-2-setup.md) first:
- Step 1 — Get your Central credentials (`CENTRAL_BASE_URL`, `CENTRAL_CLIENT_ID`, `CENTRAL_CLIENT_SECRET`)
- Step 2 — Install the server (`uv tool install --prerelease=allow central-mcp-server`)

---

## Step 1 — Register the Server

Run this command once to register the Central MCP Server with Claude Code:

> ## ❗ Important
>
> Never paste your `CENTRAL_CLIENT_SECRET` into the Claude chat window. Anything typed into chat is sent to Anthropic's servers. Pass credentials only via the `-e` flags below.

```bash
claude mcp add central-mcp \
  -e CENTRAL_BASE_URL=https://us5.api.central.arubanetworks.com \
  -e CENTRAL_CLIENT_ID=your-client-id \
  -e CENTRAL_CLIENT_SECRET=your-client-secret \
  -- uvx --prerelease=allow central-mcp-server
```

Replace all placeholder values with your actual credentials.

> ## 📘 Why this command is safe
>
> `claude mcp add` stores credentials in Claude's own settings file outside any project workspace. They are not included in messages sent to Anthropic. See [How credentials stay secure](./guide-2-setup.md#-how-credentials-stay-secure) for the full explanation.

> ## 📘 Config Scope
>
> By default, `claude mcp add` registers the server at the **user level** — available across all your projects. To scope it to a single project only, add `-s project` to the command before the server name:
>
> ```bash
> claude mcp add -s project central-mcp \
>   -e CENTRAL_BASE_URL=... \
>   ...
> ```

---

## Step 2 — Verify the Registration

```bash
claude mcp list
```

The output should include `central-mcp` with its command (`uvx --prerelease=allow central-mcp-server`) and the environment variable keys.

---

## Step 3 — First Test

**One-shot query:**

```bash
claude -p "Which sites have poor health scores right now?"
```

**Or start an interactive session:**

```bash
claude
> Which sites have poor health scores right now?
```

A successful response retrieves live site data from your Central instance. You'll see tool call activity in the terminal as the AI uses CodeMode discovery tools to find and call the appropriate Central tools.

> ## 📘 What tools will I see?
>
> The server uses **dynamic tool loading** (CodeMode). Claude will call `Search`, `GetSchemas`, and `Execute` meta-tools rather than individual `central_*` tools directly. This is expected — CodeMode chains the tool calls internally and returns only the final result.

---

## Using Guided Prompts

In an interactive Claude Code session, describe the investigation conversationally:

```
Troubleshoot the HQ Campus site
```

Or as a one-shot query:

```bash
claude -p "Run a full site troubleshoot for HQ Campus"
```

The AI will select and invoke the appropriate guided prompt based on your description.

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| `command not found: claude` | Claude Code CLI not installed | Install Claude Code: `npm install -g @anthropic-ai/claude-code` |
| `command not found: uvx` | `uv` not installed or not on PATH | Install `uv` and ensure it's on your system PATH |
| `central-mcp` not in `claude mcp list` | Registration command failed | Re-run the `claude mcp add` command; check for typos in credential values |
| Authentication error on first query | Wrong or expired credentials | Verify Client ID and Secret; recreate the API client in HPE GreenLake if needed |

---

## What's Next

- [Using the Guided Prompts](./guide-3-guided-prompts.md) — Full reference for all 10 built-in investigation workflows
- [Central MCP in Action](./guide-4-in-action.md) — See a Claude Code walkthrough with sample network health output
