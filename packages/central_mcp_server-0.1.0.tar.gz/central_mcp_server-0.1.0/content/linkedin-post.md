> **Draft — edit before posting**

---

I spent a weekend wiring up an MCP server for HPE Aruba Networking Central. Here's why.

I work with Central's REST APIs regularly. The data is excellent — site health scores, device inventory, client connectivity, alerts, events. But getting to it means knowing the right endpoint, constructing the right filter, paginating through results, and mentally assembling the picture. That's fine for a script. It's friction when you're troubleshooting at 11pm.

HPE already ships [Networking CoPilot](https://www.arubanetworks.com/products/network-management-operations/ai-ops/) — a capable AI built into Central for exactly these workflows. This project isn't trying to compete with that. It's for a specific use case: developers and network engineers who want to connect their own AI assistant (Claude, Copilot, Cursor) directly to their Central instance, query live data through conversation, and extend or customize the tooling themselves.

That's what `central-mcp-server` does.

[MCP (Model Context Protocol)](https://modelcontextprotocol.io) lets AI assistants call structured tools during a conversation — not simulate it, actually call them. The server wraps Central's APIs and exposes them as typed MCP tools. Ask your AI:

- *"Which sites have poor health scores right now?"*
- *"Show me all failed wireless clients at HQ in the last hour."*
- *"What events hit switch SW-CORE-01 yesterday?"*

The server handles the API calls, pagination, retries, and data cleaning. The AI handles the synthesis.

A few things I'm happy with:

**Tool docstrings are prompts.** FastMCP surfaces Python docstrings directly to the AI as tool descriptions. So when a tool says "call `central_get_site_name_id_mapping` first to get site IDs before filtering," the model actually follows that. The docstring is both documentation and instruction.

**Guided prompts.** 10 built-in multi-step workflows — network health overview, site troubleshooting, failed client investigation, critical alerts review, and more. The AI runs a sequence of tool calls, correlates the results, and gives you an answer. You don't have to know which tools to call or in what order.

**Read-only by design.** All tools carry `readOnlyHint: True`. Nothing writes to Central. Explicit about it in the tool metadata, not just the README.

Installs in one line via `uv`:

```
uv tool install central-mcp-server
```

Works with Claude Desktop, Claude Code, Cursor, GitHub Copilot, and Windsurf.

Unofficial community project — not affiliated with HPE. Full source and setup guides linked below.

\#networking #MCP #AI #HPEAruba #ArubaNetworks #NetworkAutomation
