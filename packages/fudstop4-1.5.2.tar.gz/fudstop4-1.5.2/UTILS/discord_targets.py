import re
from typing import Any
from urllib.parse import parse_qs, urlparse, urlunparse


_DISCORD_WEBHOOK_RE = re.compile(
    r"^https://discord(?:app)?\.com/api/webhooks/(?P<webhook_id>\d+)/[^/?#]+"
)


def _webhook_id_from_url(value: Any) -> str:
    text = str(value or "").strip()
    match = _DISCORD_WEBHOOK_RE.match(text)
    return str(match.group("webhook_id")) if match else ""


def split_discord_webhook_target(
    value: Any,
    fallback_thread_id: Any = "",
) -> tuple[str, str]:
    text = str(value or "").strip()
    thread_id = str(fallback_thread_id or "").strip()
    if not text:
        return "", ""

    parsed = urlparse(text)
    query_thread_id = str(parse_qs(parsed.query).get("thread_id", [""])[0]).strip()
    if query_thread_id:
        thread_id = query_thread_id

    if thread_id and "thread_id=" not in text and text.endswith(thread_id):
        candidate = text[: -len(thread_id)]
        if _webhook_id_from_url(candidate):
            return candidate, thread_id

    if not _webhook_id_from_url(text):
        return "", ""

    normalized = urlunparse(parsed._replace(query="", fragment=""))
    return normalized, thread_id
