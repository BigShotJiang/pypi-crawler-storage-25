import pandas as pd


def _to_float(value):
    if value in (None, "", "--", "—"):
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


class HighDividendTicker:
    def __init__(self, ticker):
        self.tickerId = [i.get('tickerId') for i in ticker]
        self.name = [i.get('name') for i in ticker]
        self.symbol = [i.get('symbol') for i in ticker]
        self.tradeTime = [i.get('tradeTime') for i in ticker]
        self.close = [_to_float(i.get('close')) for i in ticker]
        self.change = [_to_float(i.get('change')) for i in ticker]
        self.changeRatio = [round(_to_float(i.get('changeRatio')) * 100, 2) for i in ticker]
        self.marketValue = [_to_float(i.get('marketValue')) for i in ticker]
        self.volume = [_to_float(i.get('volume')) for i in ticker]
        self.turnoverRate = [_to_float(i.get('turnoverRate')) for i in ticker]
        self.peTtm = [_to_float(i.get('peTtm')) for i in ticker]
        self.dividend = [_to_float(i.get('dividend')) for i in ticker]
        self.fiftyTwoWkHigh = [_to_float(i.get('fiftyTwoWkHigh')) for i in ticker]
        self.fiftyTwoWkLow = [_to_float(i.get('fiftyTwoWkLow')) for i in ticker]
        self.open = [_to_float(i.get('open')) for i in ticker]
        self.high = [_to_float(i.get('high')) for i in ticker]
        self.low = [_to_float(i.get('low')) for i in ticker]
        self.vibrateRatio = [_to_float(i.get('vibrateRatio')) for i in ticker]


        self.data_dict = {
            'ticker_id': self.tickerId,
            'name': self.name,
            'ticker': self.symbol,
            'trade_time': self.tradeTime,
            'open': self.open,
            'high': self.high,
            'low': self.low,
            'close': self.close,
            'change': self.change,
            'change_pct': self.changeRatio,
            'market_value': self.marketValue,
            'volume': self.volume,
            'turnover_rate': self.turnoverRate,
            'pe_ttm': self.peTtm,
            'dividend': self.dividend,
            'fifty_high': self.fiftyTwoWkHigh,
            'fifty_low': self.fiftyTwoWkLow,
            'vibration': self.vibrateRatio


        }


        self.as_dataframe = pd.DataFrame(self.data_dict)


class DividendsValues:
    def __init__(self, values):
        self.tickerId = [i.get('tickerId') for i in values]
        self._yield = [_to_float(i.get('yield')) for i in values]
        self.dividend = [_to_float(i.get('dividend')) for i in values]
        self.exDate = [i.get('exDate') for i in values]


        self.data_dict = { 
            'ticker_id': self.tickerId,
            'yield': self._yield,
            'dividend': self.dividend,
            'ex_date': self.exDate
        }


        self.as_dataframe = pd.DataFrame(self.data_dict)
