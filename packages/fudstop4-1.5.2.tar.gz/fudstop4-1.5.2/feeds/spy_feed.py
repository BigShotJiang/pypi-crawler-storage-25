import asyncio
import os
from dotenv import load_dotenv
load_dotenv()
ACCESS_TOKEN = os.environ.get('ACCESS_TOKEN')
ACCESS_TOKEN_BLOCK = os.environ.get('ACCESS_TOKEN_BLOCK')
import os
from datetime import timedelta
import uuid
import pandas as pd
from discord_webhook import AsyncDiscordWebhook, DiscordEmbed
import requests
from fudstop4.apis.polygonio.polygon_options import PolygonOptions
from fudstop4.apis.helpers import generate_webull_headers
PAPER_ID = 56840164
PAPER_ID_BLOCK= 56851633
import time
import hashlib
import hashlib
import random
import string
import time
db = PolygonOptions()

import asyncio
from discord_webhook import AsyncDiscordWebhook
from fudstop4._markets.list_sets.ticker_lists import most_active_tight_spread_tickers

try:
    from .discord_routes import resolve_webhook_url
except ImportError:
    from feeds.discord_routes import resolve_webhook_url

try:
    from .feed_runtime import touch_feed_heartbeat
except ImportError:
    from feeds.feed_runtime import touch_feed_heartbeat

WEBHOOK_URL = resolve_webhook_url(
    "SPY_FEED_WEBHOOK",
    route_id="spy_feed",
)

# simple in-memory debounce
alerted = set()  # (ticker, side)

async def main():
    await db.connect()

    tickers = tuple(most_active_tight_spread_tickers)

    while True:

        await touch_feed_heartbeat(db, "spy_feed", __file__)
        query = f"""
        SELECT DISTINCT ON (ticker)
  ticker, timespan, ts_utc, insertion_timestamp,
  rsi, td_buy_count, td_sell_count, c, bb_width
FROM ca_live
WHERE timespan = 'm1'
  AND ticker = ANY($1)
ORDER BY ticker, ts_utc::timestamptz DESC, insertion_timestamp DESC;
        """

        rows = await db.fetch_new(query, tickers)

        for row in rows:
            ticker = row["ticker"]
            rsi = row["rsi"]
            tdb = row["td_buy_count"]
            tds = row["td_sell_count"]
            c   = row["c"]
            bbw = row["bb_width"]

            # -------- BULLISH TD9 ON DECK --------
            if tdb == 8:
                key = (ticker, "BULL")
                if key not in alerted:
                    alerted.add(key)

                    msg = (
                        
                        f"> **TD9 ON DECK (BULLISH)** 📈\n"
                        f"> **{ticker}** just printed **TD8** on the 1m\n"
                        f"> RSI: `{rsi:.1f}` | BBW: `{bbw:.3f}` | Price: `{c}`\n"
                        f"> ⚠️ Watch for TD9 reversal setup"
                    )

                    await AsyncDiscordWebhook(WEBHOOK_URL, content=msg).execute()

            # -------- BEARISH TD9 ON DECK --------
            if tds == 8:
                key = (ticker, "BEAR")
                if key not in alerted:
                    alerted.add(key)

                    msg = (
                        f"> **TD9 ON DECK (BEARISH)** 📉\n"
                        f"> **{ticker}** just printed **TD8** on the 1m\n"
                        f"> RSI: `{rsi:.1f}` | BBW: `{bbw:.3f}` | Price: `{c}`\n"
                        f"> ⚠️ Watch for TD9 exhaustion"
                    )

                    await AsyncDiscordWebhook(WEBHOOK_URL, content=msg).execute()

            # -------- RESET LOGIC --------
            # once TD resets, allow future alerts again
            if tdb < 7:
                alerted.discard((ticker, "BULL"))
            if tds < 7:
                alerted.discard((ticker, "BEAR"))

        await asyncio.sleep(3)

asyncio.run(main())
