from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

from dotenv import load_dotenv

load_dotenv()

DEFAULT_DISCORD_GUILD_ID = "1457091273243758614"
DEFAULT_DISCORD_CATEGORY_NAME = "WEBHOOKS"
DEFAULT_REGISTRY_PATH = Path(
    os.getenv("FEED_DISCORD_REGISTRY_PATH", "data/feed_discord_registry.json")
)
DEFAULT_ENV_EXPORT_PATH = Path(
    os.getenv("FEED_DISCORD_ENV_EXPORT_PATH", "data/feed_discord_webhooks.env")
)


@dataclass(frozen=True)
class FeedDiscordRoute:
    route_id: str
    script_path: str
    display_name: str
    channel_name: str
    topic: str
    webhook_env: str
    webhook_name: str
    fallback_envs: Tuple[str, ...] = ()


FEED_DISCORD_ROUTES: Tuple[FeedDiscordRoute, ...] = (
    FeedDiscordRoute(
        route_id="rsi_td9_bbands_bull",
        script_path="feeds/rsi_td9_bbands.py",
        display_name="RSI TD9 BBands Bull",
        channel_name="live-rsi-td9-bbands-bull",
        topic="Bullish RSI/TD9 reversal feed when price closes below the lower Bollinger band.",
        webhook_env="RSI_TD9_BBANDS_WEBHOOK",
        webhook_name="RSI TD9 BBands Bull",
    ),
    FeedDiscordRoute(
        route_id="rsi_td9_bbands_bear",
        script_path="feeds/rsi_td9_bbands_bear.py",
        display_name="RSI TD9 BBands Bear",
        channel_name="live-rsi-td9-bbands-bear",
        topic="Bearish RSI/TD9 reversal feed when price closes above the upper Bollinger band.",
        webhook_env="RSI_TD9_BBANDS_BEAR_WEBHOOK",
        webhook_name="RSI TD9 BBands Bear",
        fallback_envs=("RSI_TD9_BBANDS_WEBHOOK",),
    ),
    FeedDiscordRoute(
        route_id="rsi_td9_bbands_rvol_bull",
        script_path="feeds/rsi_td9_bbands_rvol.py",
        display_name="RSI TD9 RVOL Bull",
        channel_name="live-rsi-td9-rvol-bull",
        topic="Bullish RSI/TD9 reversal feed with relative-volume and Bollinger-width confirmation.",
        webhook_env="RSI_TD9_BBANDS_RVOL_WEBHOOK",
        webhook_name="RSI TD9 RVOL Bull",
        fallback_envs=("RSI_TD9_BBANDS_WEBHOOK",),
    ),
    FeedDiscordRoute(
        route_id="rsi_td9_bbands_rvol_bear",
        script_path="feeds/rsi_td9_bbands_rvol_bear.py",
        display_name="RSI TD9 RVOL Bear",
        channel_name="live-rsi-td9-rvol-bear",
        topic="Bearish RSI/TD9 reversal feed with relative-volume and Bollinger-width confirmation.",
        webhook_env="RSI_TD9_BBANDS_RVOL_BEAR_WEBHOOK",
        webhook_name="RSI TD9 RVOL Bear",
        fallback_envs=("RSI_TD9_BBANDS_BEAR_WEBHOOK", "RSI_TD9_BBANDS_WEBHOOK"),
    ),
    FeedDiscordRoute(
        route_id="top_bullish_feed",
        script_path="feeds/top_bullish_feed.py",
        display_name="Top Bullish Reversal",
        channel_name="top-bullish-reversal",
        topic="Highest-conviction bullish reversal alerts from the live feed stack.",
        webhook_env="TOP_BULLISH_FEED_WEBHOOK",
        webhook_name="Top Bullish Reversal",
        fallback_envs=("RSI_TD9_BBANDS_WEBHOOK",),
    ),
    FeedDiscordRoute(
        route_id="top_bearish_feed",
        script_path="feeds/top_bearish_feed.py",
        display_name="Top Bearish Reversal",
        channel_name="top-bearish-reversal",
        topic="Highest-conviction bearish reversal alerts from the live feed stack.",
        webhook_env="TOP_BEARISH_FEED_WEBHOOK",
        webhook_name="Top Bearish Reversal",
        fallback_envs=("RSI_TD9_BBANDS_BEAR_WEBHOOK", "RSI_TD9_BBANDS_WEBHOOK"),
    ),
    FeedDiscordRoute(
        route_id="bull_atr_rvol",
        script_path="feeds/bull_atr_rvol_feed.py",
        display_name="Bull ATR RVOL",
        channel_name="bull-atr-rvol",
        topic="Bullish feed combining ATR expansion with relative-volume confirmation.",
        webhook_env="BULL_ATR_RVOL_WEBHOOK",
        webhook_name="Bull ATR RVOL",
        fallback_envs=("RSI_TD9_BBANDS_WEBHOOK",),
    ),
    FeedDiscordRoute(
        route_id="bull_atr_volconfirm_open",
        script_path="feeds/bull_atr_volconfirm_open_feed.py",
        display_name="Bull ATR Vol Confirm Open",
        channel_name="bull-atr-volconfirm-open",
        topic="Bullish ATR and volume-confirmation feed tuned for the opening session.",
        webhook_env="BULL_ATR_VOLCONF_OPEN_WEBHOOK",
        webhook_name="Bull ATR Vol Confirm Open",
        fallback_envs=("BULL_ATR_RVOL_WEBHOOK", "RSI_TD9_BBANDS_WEBHOOK"),
    ),
    FeedDiscordRoute(
        route_id="bull_bb_atr_volconfirm",
        script_path="feeds/bull_bb_atr_volconfirm_feed.py",
        display_name="Bull BB ATR Vol Confirm",
        channel_name="bull-bb-atr-volconfirm",
        topic="Bullish confluence feed combining Bollinger context, ATR, and volume confirmation.",
        webhook_env="BULL_BB_ATR_VOLCONF_WEBHOOK",
        webhook_name="Bull BB ATR Vol Confirm",
        fallback_envs=("BULL_ATR_RVOL_WEBHOOK", "RSI_TD9_BBANDS_WEBHOOK"),
    ),
    FeedDiscordRoute(
        route_id="bull_bb_volconfirm",
        script_path="feeds/bull_bb_volconfirm_feed.py",
        display_name="Bull BB Vol Confirm",
        channel_name="bull-bb-volconfirm",
        topic="Bullish Bollinger-band reversal feed with volume confirmation.",
        webhook_env="BULL_BB_VOLCONF_WEBHOOK",
        webhook_name="Bull BB Vol Confirm",
        fallback_envs=("BULL_ATR_RVOL_WEBHOOK", "RSI_TD9_BBANDS_WEBHOOK"),
    ),
    FeedDiscordRoute(
        route_id="bull_bb_volconfirm_stochrsi",
        script_path="feeds/bull_bb_volconfirm_stochrsi_feed.py",
        display_name="Bull BB Vol StochRSI",
        channel_name="bull-bb-volconfirm-stochrsi",
        topic="Bullish Bollinger-band reversal feed with volume confirmation and StochRSI filter.",
        webhook_env="BULL_BB_VOL_STOCHRSI_WEBHOOK",
        webhook_name="Bull BB Vol StochRSI",
        fallback_envs=("BULL_BB_VOLCONF_WEBHOOK", "RSI_TD9_BBANDS_WEBHOOK"),
    ),
    FeedDiscordRoute(
        route_id="bear_bb_adx_rsi80",
        script_path="feeds/bear_bb_adx_rsi80_feed.py",
        display_name="Bear BB ADX RSI80",
        channel_name="bear-bb-adx-rsi80",
        topic="Bearish Bollinger and ADX feed for strong overbought exhaustion.",
        webhook_env="BEAR_BB_ADX_RSI80_WEBHOOK",
        webhook_name="Bear BB ADX RSI80",
        fallback_envs=("RSI_TD9_BBANDS_BEAR_WEBHOOK", "RSI_TD9_BBANDS_WEBHOOK"),
    ),
    FeedDiscordRoute(
        route_id="bear_atr_mfi_adx",
        script_path="feeds/bear_atr_mfi_adx_feed.py",
        display_name="Bear ATR MFI ADX",
        channel_name="bear-atr-mfi-adx",
        topic="Bearish ATR, money-flow, and ADX confluence feed.",
        webhook_env="BEAR_ATR_MFI_ADX_WEBHOOK",
        webhook_name="Bear ATR MFI ADX",
        fallback_envs=("BEAR_BB_ADX_RSI80_WEBHOOK", "RSI_TD9_BBANDS_BEAR_WEBHOOK"),
    ),
    FeedDiscordRoute(
        route_id="bear_atr_mfi_td13",
        script_path="feeds/bear_atr_mfi_td13_feed.py",
        display_name="Bear ATR MFI TD13",
        channel_name="bear-atr-mfi-td13",
        topic="Bearish ATR, money-flow, and TD13 exhaustion feed.",
        webhook_env="BEAR_ATR_MFI_TD13_WEBHOOK",
        webhook_name="Bear ATR MFI TD13",
        fallback_envs=("BEAR_BB_ADX_RSI80_WEBHOOK", "RSI_TD9_BBANDS_BEAR_WEBHOOK"),
    ),
    FeedDiscordRoute(
        route_id="secapi_bull",
        script_path="feeds/secapi_bull_feed.py",
        display_name="SECAPI Bull",
        channel_name="secapi-bull",
        topic="Bullish SECAPI-style confluence feed for oversold momentum reversals.",
        webhook_env="SECAPI_BULL_WEBHOOK",
        webhook_name="SECAPI Bull",
        fallback_envs=("SHORT_TERM", "RSI_TD9_BBANDS_WEBHOOK"),
    ),
    FeedDiscordRoute(
        route_id="secapi_bear",
        script_path="feeds/secapi_bear_feed.py",
        display_name="SECAPI Bear",
        channel_name="secapi-bear",
        topic="Bearish SECAPI-style confluence feed for overbought momentum reversals.",
        webhook_env="SECAPI_BEAR_WEBHOOK",
        webhook_name="SECAPI Bear",
        fallback_envs=("MID_TERM", "RSI_TD9_BBANDS_BEAR_WEBHOOK"),
    ),
    FeedDiscordRoute(
        route_id="spy_feed",
        script_path="feeds/spy_feed.py",
        display_name="SPY Feed",
        channel_name="spy-td8-watch",
        topic="Fast SPY and index watchlist channel for TD8-on-deck alerts.",
        webhook_env="SPY_FEED_WEBHOOK",
        webhook_name="SPY Feed",
    ),
    FeedDiscordRoute(
        route_id="overextended_atr",
        script_path="feeds/overextended_atr.py",
        display_name="Overextended ATR",
        channel_name="overextended-atr",
        topic="ATR-extension alerts for names moving far outside normal bar range.",
        webhook_env="OVEREXTENDED_ATR_WEBHOOK",
        webhook_name="Overextended ATR",
    ),
    FeedDiscordRoute(
        route_id="top_reversal_bull",
        script_path="feeds/top_reversal_feeds.py",
        display_name="Top Reversal Bull Queue",
        channel_name="top-reversal-bull",
        topic="Bullish top-reversal queue with chart attachments and tracked outcomes.",
        webhook_env="TOP_FEEDS_BULL_WEBHOOKS",
        webhook_name="Top Reversal Bull",
        fallback_envs=("CA_TOP_WEBHOOK", "LONG_TERM"),
    ),
    FeedDiscordRoute(
        route_id="top_reversal_bear",
        script_path="feeds/top_reversal_feeds.py",
        display_name="Top Reversal Bear Queue",
        channel_name="top-reversal-bear",
        topic="Bearish top-reversal queue with chart attachments and tracked outcomes.",
        webhook_env="TOP_FEEDS_BEAR_WEBHOOKS",
        webhook_name="Top Reversal Bear",
        fallback_envs=("CA_TOP_WEBHOOK", "LONG_TERM"),
    ),
    FeedDiscordRoute(
        route_id="ca_quick_bull",
        script_path="feeds/ca_live_diverse_feeds.py",
        display_name="CA Quick Bull",
        channel_name="ca-quick-bull",
        topic="Fast bullish candle-analysis alerts for quick m1 reversals.",
        webhook_env="QUICK_BULL",
        webhook_name="CA Quick Bull",
    ),
    FeedDiscordRoute(
        route_id="ca_quick_bear",
        script_path="feeds/ca_live_diverse_feeds.py",
        display_name="CA Quick Bear",
        channel_name="ca-quick-bear",
        topic="Fast bearish candle-analysis alerts for quick m1 reversals.",
        webhook_env="QUICK_BEAR",
        webhook_name="CA Quick Bear",
    ),
    FeedDiscordRoute(
        route_id="ca_short_term",
        script_path="feeds/ca_live_diverse_feeds.py",
        display_name="CA Short Term",
        channel_name="ca-short-term",
        topic="Short-term candle-analysis alerts covering intraday continuation and reversal windows.",
        webhook_env="SHORT_TERM",
        webhook_name="CA Short Term",
    ),
    FeedDiscordRoute(
        route_id="ca_mid_term",
        script_path="feeds/ca_live_diverse_feeds.py",
        display_name="CA Mid Term",
        channel_name="ca-mid-term",
        topic="Mid-term candle-analysis alerts across m30 and m60 windows.",
        webhook_env="MID_TERM",
        webhook_name="CA Mid Term",
    ),
    FeedDiscordRoute(
        route_id="ca_long_term",
        script_path="feeds/ca_live_diverse_feeds.py",
        display_name="CA Long Term",
        channel_name="ca-long-term",
        topic="Longer-horizon candle-analysis alerts for m120, daily, and weekly windows.",
        webhook_env="LONG_TERM",
        webhook_name="CA Long Term",
    ),
    FeedDiscordRoute(
        route_id="ca_240m",
        script_path="feeds/ca_live_diverse_feeds.py",
        display_name="CA 240 Minute",
        channel_name="ca-240m",
        topic="Candle-analysis alerts dedicated to the 240-minute timespan.",
        webhook_env="M_240_FEEDS",
        webhook_name="CA 240 Minute",
    ),
    FeedDiscordRoute(
        route_id="ca_rev_75",
        script_path="feeds/ca_rev_75_feeds.py",
        display_name="CA Rev 75",
        channel_name="ca-rev-75",
        topic="75th-percentile candle-analysis reversal feed.",
        webhook_env="CA_REV_WEBHOOK",
        webhook_name="CA Rev 75",
        fallback_envs=("LONG_TERM",),
    ),
    FeedDiscordRoute(
        route_id="ca_unified",
        script_path="feeds/ca_unified_feeds.py",
        display_name="CA Unified",
        channel_name="ca-unified",
        topic="Unified candle-analysis feed that consolidates qualifying reversal rules.",
        webhook_env="CA_UNIFIED_WEBHOOK",
        webhook_name="CA Unified",
        fallback_envs=("LONG_TERM",),
    ),
    FeedDiscordRoute(
        route_id="ca_results",
        script_path="feeds/ca_unified_feeds.py",
        display_name="CA Results",
        channel_name="ca-results",
        topic="Tracked candle-analysis result outcomes and follow-through reporting.",
        webhook_env="CA_RESULTS_WEBHOOK",
        webhook_name="CA Results",
        fallback_envs=("CA_UNIFIED_RESULTS_WEBHOOK", "LONG_TERM"),
    ),
    FeedDiscordRoute(
        route_id="ca_bull",
        script_path="feeds/ca_unified_feeds.py",
        display_name="CA Bull Composite",
        channel_name="ca-bull-composite",
        topic="Bullish candle-analysis composite feed used by the broader reversal engines.",
        webhook_env="CA_BULL_WEBHOOK",
        webhook_name="CA Bull Composite",
        fallback_envs=("SECAPI_BULL_WEBHOOK", "SHORT_TERM"),
    ),
    FeedDiscordRoute(
        route_id="ca_bear",
        script_path="feeds/ca_unified_feeds.py",
        display_name="CA Bear Composite",
        channel_name="ca-bear-composite",
        topic="Bearish candle-analysis composite feed used by the broader reversal engines.",
        webhook_env="CA_BEAR_WEBHOOK",
        webhook_name="CA Bear Composite",
        fallback_envs=("SECAPI_BEAR_WEBHOOK", "MID_TERM"),
    ),
)

ROUTES_BY_ID: Dict[str, FeedDiscordRoute] = {route.route_id: route for route in FEED_DISCORD_ROUTES}
ROUTES_BY_ENV: Dict[str, FeedDiscordRoute] = {route.webhook_env: route for route in FEED_DISCORD_ROUTES}

_REGISTRY_CACHE: Dict[str, Any] | None = None


def iter_routes() -> Tuple[FeedDiscordRoute, ...]:
    return FEED_DISCORD_ROUTES


def registry_path() -> Path:
    return DEFAULT_REGISTRY_PATH


def env_export_path() -> Path:
    return DEFAULT_ENV_EXPORT_PATH


def route_for_env(webhook_env: str) -> FeedDiscordRoute | None:
    return ROUTES_BY_ENV.get(str(webhook_env or "").strip())


def route_for_id(route_id: str) -> FeedDiscordRoute | None:
    return ROUTES_BY_ID.get(str(route_id or "").strip())


def _load_registry_file(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def load_registry(path: Path | None = None, *, refresh: bool = False) -> Dict[str, Any]:
    global _REGISTRY_CACHE
    resolved = Path(path or registry_path())
    if refresh or _REGISTRY_CACHE is None:
        _REGISTRY_CACHE = _load_registry_file(resolved)
    return _REGISTRY_CACHE or {}


def registry_route(route_id: str | None = None, *, webhook_env: str | None = None) -> Dict[str, Any]:
    registry = load_registry()
    routes = registry.get("routes") if isinstance(registry, dict) else None
    if not isinstance(routes, dict):
        return {}
    if route_id:
        route_payload = routes.get(str(route_id).strip())
        return route_payload if isinstance(route_payload, dict) else {}
    if webhook_env:
        env_name = str(webhook_env).strip()
        for route_payload in routes.values():
            if not isinstance(route_payload, dict):
                continue
            if str(route_payload.get("webhook_env") or "").strip() == env_name:
                return route_payload
    return {}


def resolve_webhook_url(*env_keys: str, route_id: str | None = None, default: str = "") -> str:
    route_payload = registry_route(route_id, webhook_env=env_keys[0] if env_keys else None)
    registry_url = str(route_payload.get("webhook_url") or "").strip()
    if registry_url:
        return registry_url

    for env_key in env_keys:
        value = str(os.getenv(env_key, "") or "").strip()
        if value:
            return value
    return default


def resolve_webhook_urls(*env_keys: str, route_id: str | None = None) -> List[str]:
    raw = resolve_webhook_url(*env_keys, route_id=route_id, default="")
    return [part.strip() for part in str(raw).split(",") if part.strip()]


def env_assignments(registry: Dict[str, Any] | None = None) -> List[Tuple[str, str]]:
    payload = registry if isinstance(registry, dict) else load_registry()
    routes = payload.get("routes") if isinstance(payload, dict) else None
    if not isinstance(routes, dict):
        return []

    assignments: List[Tuple[str, str]] = []
    for route in FEED_DISCORD_ROUTES:
        route_payload = routes.get(route.route_id)
        if not isinstance(route_payload, dict):
            continue
        webhook_url = str(route_payload.get("webhook_url") or "").strip()
        if webhook_url:
            assignments.append((route.webhook_env, webhook_url))
    return assignments


def write_env_export(registry: Dict[str, Any], path: Path | None = None) -> Path:
    resolved = Path(path or env_export_path())
    resolved.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Auto-generated by scripts/provision_feed_webhooks.py",
        f"# guild_id={registry.get('guild_id', DEFAULT_DISCORD_GUILD_ID)}",
    ]
    for key, value in env_assignments(registry):
        lines.append(f"{key}={value}")
    resolved.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return resolved
