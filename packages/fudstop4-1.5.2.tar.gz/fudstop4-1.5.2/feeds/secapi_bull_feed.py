import asyncio
import os
from datetime import timedelta

import pandas as pd
from dotenv import load_dotenv
from discord_webhook import AsyncDiscordWebhook, DiscordEmbed

from fudstop4.apis.polygonio.polygon_options import PolygonOptions

try:
    from .discord_routes import resolve_webhook_url
except ImportError:
    from feeds.discord_routes import resolve_webhook_url

try:
    from .feed_runtime import touch_feed_heartbeat
except ImportError:
    from feeds.feed_runtime import touch_feed_heartbeat

load_dotenv()

db = PolygonOptions()

# ---- Feed config ----
HOOK_URL = resolve_webhook_url(
    "SECAPI_BULL_WEBHOOK",
    "SHORT_TERM",
    route_id="secapi_bull",
)
LIVE_TABLE = os.getenv("CANDLE_LIVE_TABLE", "ca_live")
TIMESPAN = os.getenv("SECAPI_BULL_TIMESPAN", "m1")
LOOKBACK_MINUTES = int(os.getenv("SECAPI_BULL_LOOKBACK_MINUTES", "3"))
COOLDOWN_MINUTES = int(os.getenv("SECAPI_BULL_COOLDOWN_MINUTES", "20"))
POLL_SECONDS = float(os.getenv("SECAPI_BULL_POLL_SECONDS", "5"))

# ---- Rule (Tier-1 long) ----
RSI_LOW = 30.0
TD_BUY_MIN = 8
ATR_PCT_MIN = 0.003
VWAP_DIST_MAX = -0.01

# ---- Backtest stats (entry=next_open, exit=close, window=1-30, cooldown=20) ----
HOLD_MIN = 1
HOLD_MAX = 30
PROB_20BP = 0.8451
PROB_50BP = 0.6761


async def main() -> None:
    await db.connect()
    last_sent = {}

    while True:

        await touch_feed_heartbeat(db, "secapi_bull_feed", __file__)
        query = f"""
            SELECT
                ticker,
                timespan,
                ts_utc,
                c,
                rsi,
                td_buy_count,
                macd_line,
                macd_signal,
                (atr / NULLIF(c, 0)) AS atr_pct,
                vwap_dist_pct
            FROM {LIVE_TABLE}
            WHERE
                timespan = '{TIMESPAN}'
                AND ts_utc::timestamptz >= now() - interval '{LOOKBACK_MINUTES} minutes'
                AND rsi <= {RSI_LOW}
                AND td_buy_count >= {TD_BUY_MIN}
                AND macd_line > macd_signal
                AND (atr / NULLIF(c, 0)) >= {ATR_PCT_MIN}
                AND vwap_dist_pct <= {VWAP_DIST_MAX}
            ORDER BY ts_utc::timestamptz DESC;
        """

        results = await db.fetch(query)
        if not results:
            await asyncio.sleep(POLL_SECONDS)
            continue

        rows = sorted(results, key=lambda r: r["ts_utc"])
        for r in rows:
            ts_utc = pd.Timestamp(r["ts_utc"])
            if ts_utc.tzinfo is None:
                ts_utc = ts_utc.tz_localize("UTC")
            ts_et = ts_utc.tz_convert("America/New_York")

            key = (r["ticker"], "secapi_bull_t1")
            last_ts = last_sent.get(key)
            if last_ts and ts_utc <= last_ts + timedelta(minutes=COOLDOWN_MINUTES):
                continue
            last_sent[key] = ts_utc

            desc = (
                f"{r['ticker']} @ {ts_et.strftime('%Y-%m-%d %H:%M ET')}\n"
                "Rule: RSI<=30, TD Buy>=8, MACD line>signal, ATR%>=0.003, VWAP dist<=-1%\n"
                "Context: oversold reversal with volatility expansion under VWAP.\n"
                f"Probability (>=20bp / >=50bp in {HOLD_MIN}-{HOLD_MAX}m): "
                f"{PROB_20BP:.1%} / {PROB_50BP:.1%}\n"
                f"Hold window: {HOLD_MIN}-{HOLD_MAX} minutes"
            )

            embed = DiscordEmbed(
                title="SECAPI Bull Feed",
                description=desc,
                color="2ecc71",
            )
            embed.add_embed_field(
                name="Now",
                value=(
                    f"c={float(r['c']):.2f} | rsi={float(r['rsi']):.1f} | "
                    f"td={int(r['td_buy_count'])} | atr%={float(r['atr_pct']):.4f} | "
                    f"vwap_dist={float(r['vwap_dist_pct']):.4f}"
                ),
                inline=False,
            )
            embed.set_timestamp()
            embed.set_footer(text="Market Pulse")

            hook = AsyncDiscordWebhook(HOOK_URL)
            hook.add_embed(embed)
            await hook.execute()

        await asyncio.sleep(POLL_SECONDS)


asyncio.run(main())
