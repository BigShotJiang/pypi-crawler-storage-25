import asyncio
import os
from datetime import timedelta

import pandas as pd
from dotenv import load_dotenv

try:
    from discord_webhook import AsyncDiscordWebhook, DiscordEmbed
except Exception:
    from discord_webhook import AsyncDiscordWebhook, DiscordEmbed

try:
    from .discord_routes import resolve_webhook_url
except ImportError:
    from feeds.discord_routes import resolve_webhook_url

try:
    from .feed_runtime import touch_feed_heartbeat
except ImportError:
    from feeds.feed_runtime import touch_feed_heartbeat

from fudstop4.apis.polygonio.polygon_options import PolygonOptions

load_dotenv()

db = PolygonOptions()

# ---- Feed config ----
HOOK_URL = resolve_webhook_url(
    "BEAR_ATR_MFI_TD13_WEBHOOK",
    "BEAR_BB_ADX_RSI80_WEBHOOK",
    "RSI_TD9_BBANDS_BEAR_WEBHOOK",
    route_id="bear_atr_mfi_td13",
)
TIMESPAN = os.getenv("BEAR_ATR_MFI_TD13_TIMESPAN", "m1")
LOOKBACK_MINUTES = int(os.getenv("BEAR_ATR_MFI_TD13_LOOKBACK_MINUTES", "3"))
COOLDOWN_MINUTES = int(os.getenv("BEAR_ATR_MFI_TD13_COOLDOWN_MINUTES", "5"))
POLL_SECONDS = float(os.getenv("BEAR_ATR_MFI_TD13_POLL_SECONDS", "1"))

# ---- Rule stats (higher-BPS run) ----
HOLD_MIN = 1
HOLD_MAX = 20
PROB_40BP = 0.833333
PROB_50BP = 0.738095
AVG_MOVE = 0.010140
P15_MOVE = 0.003847


async def main() -> None:
    await db.connect()
    last_sent = {}

    while True:

        await touch_feed_heartbeat(db, "bear_atr_mfi_td13_feed", __file__)
        query = f"""
            SELECT
                ticker,
                ts_utc,
                rsi,
                td_sell_count,
                candle_completely_above_upper,
                (atr / NULLIF(c, 0)) AS atr_pct,
                mfi,
                vwap_dist_pct
            FROM ca_live
            WHERE
                timespan = '{TIMESPAN}'
                AND ts_utc::timestamptz >= now() - interval '{LOOKBACK_MINUTES} minutes'
                AND rsi >= 70
                AND td_sell_count >= 13
                AND candle_completely_above_upper = true
                AND vwap_dist_pct <= 0.0
                AND (atr / NULLIF(c, 0)) >= 0.003
                AND mfi >= 80
            ORDER BY ts_utc::timestamptz DESC;
        """

        results = await db.fetch(query)
        if not results:
            await asyncio.sleep(POLL_SECONDS)
            continue

        rows = sorted(results, key=lambda r: r["ts_utc"])
        for r in rows:
            ts_utc = pd.Timestamp(r["ts_utc"])
            if ts_utc.tzinfo is None:
                ts_utc = ts_utc.tz_localize("UTC")
            ts_et = ts_utc.tz_convert("America/New_York")

            key = (r["ticker"], "bear_atr_mfi_td13")
            last_ts = last_sent.get(key)
            if last_ts and ts_utc <= last_ts + timedelta(minutes=COOLDOWN_MINUTES):
                continue
            last_sent[key] = ts_utc

            embed = DiscordEmbed(
                title="Bearish TD + Flow Exhaustion",
                description=f"{r['ticker']} @ {ts_et.strftime('%Y-%m-%d %H:%M ET')}",
                color="e74c3c",
            )
            embed.add_embed_field(
                name="Setup",
                value=(
                    "RSI >= 70, TD Sell >= 13, Candle Completely Above Upper Band\n"
                    "VWAP <= 0, ATR% >= 0.003, MFI >= 80"
                ),
                inline=False,
            )
            embed.add_embed_field(
                name="Stats (historical)",
                value=(
                    f"Probability (>=40bp): **{PROB_40BP:.1%}**\n"
                    f"Probability (>=50bp): **{PROB_50BP:.1%}**\n"
                    f"Expected Hold: **{HOLD_MIN}-{HOLD_MAX} min**\n"
                    f"Expected Move (avg / p15): **{AVG_MOVE:.2%} / {P15_MOVE:.2%}**"
                ),
                inline=False,
            )
            embed.set_footer(text="Bearish feed (ATR + MFI + TD13)")
            embed.set_timestamp()

            webhook = AsyncDiscordWebhook(url=HOOK_URL)
            webhook.add_embed(embed)
            await webhook.execute()

        await asyncio.sleep(POLL_SECONDS)


asyncio.run(main())
