import os
from dotenv import load_dotenv
load_dotenv()
from discord_webhook import AsyncDiscordWebhook, DiscordEmbed
from fudstop4.apis._ta.ta_sdk import FudstopTA
from fudstop4.apis.helpers import generate_webull_headers
from fudstop4.apis.polygonio.polygon_options import PolygonOptions
import pandas as pd
import asyncio
from fudstop4._markets.list_sets.ticker_lists import most_active_tight_spread_tickers, most_active_tickers
from fudstop4._markets.list_sets.dicts import hex_color_dict
db = PolygonOptions()
_ta = FudstopTA()
import time
from tabulate import tabulate
green = hex_color_dict.get('green')
red = hex_color_dict.get('red')


