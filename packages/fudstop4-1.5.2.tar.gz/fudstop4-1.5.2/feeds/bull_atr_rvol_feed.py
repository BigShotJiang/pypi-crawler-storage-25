import asyncio
import os
from datetime import timedelta

import pandas as pd
from dotenv import load_dotenv

try:
    from discord_webhook import AsyncDiscordWebhook, DiscordEmbed
except Exception:
    from discord_webhook import AsyncDiscordWebhook, DiscordEmbed

try:
    from .discord_routes import resolve_webhook_url
except ImportError:
    from feeds.discord_routes import resolve_webhook_url

try:
    from .feed_runtime import touch_feed_heartbeat
except ImportError:
    from feeds.feed_runtime import touch_feed_heartbeat

from fudstop4.apis.polygonio.polygon_options import PolygonOptions

load_dotenv()

db = PolygonOptions()

# ---- Feed config ----
HOOK_URL = resolve_webhook_url(
    "BULL_ATR_RVOL_WEBHOOK",
    "RSI_TD9_BBANDS_WEBHOOK",
    route_id="bull_atr_rvol",
)
TIMESPAN = os.getenv("BULL_ATR_RVOL_TIMESPAN", "m1")
LOOKBACK_MINUTES = int(os.getenv("BULL_ATR_RVOL_LOOKBACK_MINUTES", "3"))
COOLDOWN_MINUTES = int(os.getenv("BULL_ATR_RVOL_COOLDOWN_MINUTES", "5"))
POLL_SECONDS = float(os.getenv("BULL_ATR_RVOL_POLL_SECONDS", "1"))

# ---- Rule stats (higher-BPS run) ----
HOLD_MIN = 1
HOLD_MAX = 15
PROB_40BP = 0.906977
PROB_50BP = 0.837209
AVG_MOVE = 0.012015
P15_MOVE = 0.004775


async def main() -> None:
    await db.connect()
    last_sent = {}

    while True:

        await touch_feed_heartbeat(db, "bull_atr_rvol_feed", __file__)
        query = f"""
            SELECT
                ticker,
                ts_utc,
                rsi,
                td_buy_count,
                candle_completely_below_lower,
                bb_width,
                rvol,
                (atr / NULLIF(c, 0)) AS atr_pct,
                vwap_dist_pct
            FROM ca_live
            WHERE
                timespan = '{TIMESPAN}'
                AND ts_utc::timestamptz >= now() - interval '{LOOKBACK_MINUTES} minutes'
                AND rsi <= 30
                AND td_buy_count >= 10
                AND candle_completely_below_lower = true
                AND vwap_dist_pct >= 0.0
                AND (atr / NULLIF(c, 0)) >= 0.003
                AND rvol >= 1.5
            ORDER BY ts_utc::timestamptz DESC;
        """

        results = await db.fetch(query)
        if not results:
            await asyncio.sleep(POLL_SECONDS)
            continue

        rows = sorted(results, key=lambda r: r["ts_utc"])
        for r in rows:
            ts_utc = pd.Timestamp(r["ts_utc"])
            if ts_utc.tzinfo is None:
                ts_utc = ts_utc.tz_localize("UTC")
            ts_et = ts_utc.tz_convert("America/New_York")

            key = (r["ticker"], "bull_atr_rvol")
            last_ts = last_sent.get(key)
            if last_ts and ts_utc <= last_ts + timedelta(minutes=COOLDOWN_MINUTES):
                continue
            last_sent[key] = ts_utc

            embed = DiscordEmbed(
                title="Bullish Momentum Reversal",
                description=f"{r['ticker']} @ {ts_et.strftime('%Y-%m-%d %H:%M ET')}",
                color="2ecc71",
            )
            embed.add_embed_field(
                name="Setup",
                value=(
                    "RSI <= 30, TD Buy >= 10, Candle Completely Below Lower Band\n"
                    "VWAP >= 0, ATR% >= 0.003, RVOL >= 1.5"
                ),
                inline=False,
            )
            embed.add_embed_field(
                name="Stats (historical)",
                value=(
                    f"Probability (>=40bp): **{PROB_40BP:.1%}**\n"
                    f"Probability (>=50bp): **{PROB_50BP:.1%}**\n"
                    f"Expected Hold: **{HOLD_MIN}-{HOLD_MAX} min**\n"
                    f"Expected Move (avg / p15): **{AVG_MOVE:.2%} / {P15_MOVE:.2%}**"
                ),
                inline=False,
            )
            embed.set_footer(text="Bullish feed (ATR + RVOL)")
            embed.set_timestamp()

            webhook = AsyncDiscordWebhook(url=HOOK_URL)
            webhook.add_embed(embed)
            await webhook.execute()

        await asyncio.sleep(POLL_SECONDS)


asyncio.run(main())
