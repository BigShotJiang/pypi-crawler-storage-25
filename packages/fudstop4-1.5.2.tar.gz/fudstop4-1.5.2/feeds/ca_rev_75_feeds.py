from __future__ import annotations

import ast
import asyncio
import json
import os
import re
from dataclasses import dataclass
from datetime import time, timedelta
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd
from discord_webhook import AsyncDiscordWebhook, DiscordEmbed

from fudstop4.apis.polygonio.polygon_options import PolygonOptions

try:
    from .discord_routes import resolve_webhook_url
except ImportError:
    from feeds.discord_routes import resolve_webhook_url

try:
    from .feed_runtime import touch_feed_heartbeat
except ImportError:
    from feeds.feed_runtime import touch_feed_heartbeat


LIVE_TABLE = os.getenv("CANDLE_LIVE_TABLE", "ca_live")
TIMESPAN = os.getenv("CA_REV_TIMESPAN", "m1")
LOOKBACK_MINUTES = int(os.getenv("CA_REV_LOOKBACK_MINUTES", "10"))
POLL_SECONDS = float(os.getenv("CA_REV_POLL_SECONDS", "5"))
COOLDOWN_MINUTES = int(os.getenv("CA_REV_COOLDOWN_MINUTES", "10"))
IGNORE_TOD = os.getenv("CA_REV_IGNORE_TOD", "1").strip().lower() in ("1", "true", "yes", "y", "on")
MIN_COND_COUNT = int(os.getenv("CA_REV_MIN_COND_COUNT", "2"))

CANDIDATES_CSV = Path(
    os.getenv(
        "CA_REV_CANDIDATES_CSV",
        "runs/ca_rev_m1_rsi_td_only_w5_10_ret20_all.csv",
    )
)
MIN_HIT20 = float(os.getenv("CA_REV_MIN_HIT20", "0.75"))
MIN_N = int(os.getenv("CA_REV_MIN_N", "25"))
MIN_AVG_MOVE = float(os.getenv("CA_REV_MIN_AVG_MOVE", "0"))
MIN_P15_MOVE = float(os.getenv("CA_REV_MIN_P15_MOVE", "0"))
MAX_RULES = int(os.getenv("CA_REV_MAX_RULES", "0"))
BASE_MODE = os.getenv("CA_REV_BASE_MODE", "rsi_td_only")

RSI_OVERSOLD = float(os.getenv("CA_REV_RSI_OVERSOLD", "30"))
RSI_OVERBOUGHT = float(os.getenv("CA_REV_RSI_OVERBOUGHT", "70"))
TD_COUNT_MIN = int(os.getenv("CA_REV_TD_COUNT_MIN", "8"))

REV_HOOK_URL = resolve_webhook_url("CA_REV_WEBHOOK", "LONG_TERM", route_id="ca_rev_75")
BULL_QUICK_HOOK_URL = resolve_webhook_url("QUICK_BULL", route_id="ca_quick_bull")
BEAR_QUICK_HOOK_URL = resolve_webhook_url("QUICK_BEAR", route_id="ca_quick_bear")
SHORT_TERM_HOOK_URL = resolve_webhook_url("SHORT_TERM", route_id="ca_short_term")
MID_TERM_HOOK_URL = resolve_webhook_url("MID_TERM", route_id="ca_mid_term")
LONG_TERM_HOOK_URL = resolve_webhook_url("LONG_TERM", route_id="ca_long_term")
M_240_HOOK_URL = resolve_webhook_url("M_240_FEEDS", route_id="ca_240m")
QUICK_MIN_HIT = float(os.getenv("QUICK_MIN_HIT", "0.85"))
BULL_HOOK_URL = resolve_webhook_url(
    "CA_BULL_WEBHOOK",
    "SECAPI_BULL_WEBHOOK",
    "SHORT_TERM",
    route_id="ca_bull",
)
BEAR_HOOK_URL = resolve_webhook_url(
    "CA_BEAR_WEBHOOK",
    "SECAPI_BEAR_WEBHOOK",
    "MID_TERM",
    route_id="ca_bear",
)

QUICK_TIMESPANS = {"m1"}
SHORT_TIMESPANS = {"m5", "m15"}
MID_TIMESPANS = {"m30", "m60"}
LONG_TIMESPANS = {"m120", "d1", "w1"}
M_240_TIMESPANS = {"m240"}

STATE_PATH = Path(os.getenv("CA_REV_STATE_PATH", "feeds_ca_rev_75_state.json"))
_TOD_COLUMNS = {"tod_open", "tod_mid", "tod_close"}


_ALLOWED_NODES = (
    ast.Expression,
    ast.BoolOp,
    ast.UnaryOp,
    ast.BinOp,
    ast.Compare,
    ast.Name,
    ast.Load,
    ast.Constant,
    ast.Tuple,
    ast.List,
    ast.And,
    ast.Or,
    ast.Not,
    ast.USub,
    ast.UAdd,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.Mod,
    ast.Pow,
    ast.Eq,
    ast.NotEq,
    ast.Lt,
    ast.LtE,
    ast.Gt,
    ast.GtE,
    ast.In,
    ast.NotIn,
)


def _normalize_expr(expr: str) -> str:
    s = expr.strip()
    s = re.sub(r"\bAND\b", "and", s, flags=re.IGNORECASE)
    s = re.sub(r"\bOR\b", "or", s, flags=re.IGNORECASE)
    s = re.sub(r"\bNOT\b", "not", s, flags=re.IGNORECASE)
    s = re.sub(r"\bTRUE\b", "True", s, flags=re.IGNORECASE)
    s = re.sub(r"\bFALSE\b", "False", s, flags=re.IGNORECASE)
    s = re.sub(r"\bIS\s+TRUE\b", "== True", s, flags=re.IGNORECASE)
    s = re.sub(r"\bIS\s+FALSE\b", "== False", s, flags=re.IGNORECASE)
    s = re.sub(r"\bNOT\s+IN\b", "not in", s, flags=re.IGNORECASE)
    s = re.sub(r"\bIN\b", "in", s, flags=re.IGNORECASE)
    s = s.replace("<>", "!=")
    s = re.sub(r"(?<![<>=!])=(?!=)", "==", s)
    return s


def _validate_ast(tree: ast.AST) -> None:
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            raise ValueError(f"Disallowed expression node: {type(node).__name__}")
        if isinstance(node, ast.Name) and node.id.startswith("__"):
            raise ValueError("Disallowed name")


@dataclass(frozen=True)
class CompiledCondition:
    raw: str
    expr: str
    code: Any
    names: Tuple[str, ...]


def compile_condition(raw: str) -> CompiledCondition:
    expr = _normalize_expr(raw)
    tree = ast.parse(expr, mode="eval")
    _validate_ast(tree)
    names = [node.id for node in ast.walk(tree) if isinstance(node, ast.Name)]
    code = compile(tree, "<condition>", "eval")
    return CompiledCondition(raw=raw, expr=expr, code=code, names=tuple(sorted(set(names))))


def eval_condition(cond: CompiledCondition, row: Dict[str, Any]) -> bool:
    locals_d: Dict[str, Any] = {}
    for name in cond.names:
        if name not in row:
            return False
        locals_d[name] = row[name]
    try:
        return bool(eval(cond.code, {"__builtins__": {}}, locals_d))
    except Exception:
        return False


@dataclass(frozen=True)
class FeedRule:
    name: str
    side: str
    conditions: Tuple[CompiledCondition, ...]
    raw_conditions: Tuple[str, ...]
    hit_20bp: float
    avg_best_move: float
    p15_best_move: float
    window_min: int
    window_max: int
    n_val: int
    tickers_val: int


def _load_state(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {"sent": {}}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"sent": {}}


def _save_state(path: Path, state: Dict[str, Any]) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def _prune_state(state: Dict[str, Any], now: pd.Timestamp) -> None:
    cutoff = now - timedelta(minutes=COOLDOWN_MINUTES * 6)
    sent = state.get("sent", {})
    stale = [k for k, v in sent.items() if pd.Timestamp(v) < cutoff]
    for k in stale:
        sent.pop(k, None)


def _signal_key(rule: FeedRule, ticker: str, ts_epoch: int) -> str:
    return f"{rule.name}|{ticker}|{ts_epoch}"


def _safe_int(value: Any) -> int:
    try:
        return int(float(str(value)))
    except Exception:
        return 0


def _slugify(text: str, limit: int = 80) -> str:
    slug = re.sub(r"[^A-Za-z0-9_]+", "_", text.strip())
    slug = slug.strip("_")
    return slug[:limit] if slug else "rule"


def _parse_conditions(raw: Any) -> List[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x) for x in raw if str(x).strip()]
    try:
        parsed = ast.literal_eval(str(raw))
    except Exception:
        return []
    if isinstance(parsed, list):
        return [str(x) for x in parsed if str(x).strip()]
    return []


def _strip_tod_conditions(conds: List[str]) -> List[str]:
    out: List[str] = []
    for cond in conds:
        lowered = cond.lower()
        if "tod_open" in lowered or "tod_mid" in lowered or "tod_close" in lowered or "time_et" in lowered:
            continue
        out.append(cond)
    return out


def _base_conditions(side: str) -> List[str]:
    if side == "bull":
        return [
            f"rsi <= {RSI_OVERSOLD:g}",
            f"td_buy_count >= {TD_COUNT_MIN}",
        ]
    return [
        f"rsi >= {RSI_OVERBOUGHT:g}",
        f"td_sell_count >= {TD_COUNT_MIN}",
    ]


def _load_rules() -> List[FeedRule]:
    if not CANDIDATES_CSV.exists():
        raise FileNotFoundError(f"missing candidates CSV: {CANDIDATES_CSV}")

    df = pd.read_csv(CANDIDATES_CSV)
    if df.empty:
        return []

    df = df[df["hit_20bp"] >= MIN_HIT20]
    df = df[df["n_val"] >= MIN_N]
    if MIN_AVG_MOVE > 0 and "avg_best_move" in df.columns:
        df = df[df["avg_best_move"] >= MIN_AVG_MOVE]
    if MIN_P15_MOVE > 0 and "p15_best_move" in df.columns:
        df = df[df["p15_best_move"] >= MIN_P15_MOVE]
    if BASE_MODE and "base_mode" in df.columns:
        df = df[df["base_mode"] == BASE_MODE]
    if df.empty:
        return []

    df = df.sort_values(["hit_20bp", "n_val"], ascending=[False, False])
    if MAX_RULES > 0:
        df = df.head(MAX_RULES)

    rules: List[FeedRule] = []
    for idx, row in df.iterrows():
        side = str(row.get("side", "")).strip().lower()
        if side not in ("bull", "bear"):
            continue
        conds = _parse_conditions(row.get("conditions"))
        if IGNORE_TOD:
            conds = _strip_tod_conditions(conds)
        if not conds or len(conds) < MIN_COND_COUNT:
            continue

        base = _base_conditions(side)
        raw_conditions = base + conds
        try:
            compiled = tuple(compile_condition(c) for c in raw_conditions)
        except Exception:
            continue

        label = str(row.get("label", "")).strip()
        slug = _slugify(label)
        name = f"rev75_{side}_{slug}_{idx}"

        rules.append(
            FeedRule(
                name=name,
                side=side,
                conditions=compiled,
                raw_conditions=tuple(raw_conditions),
                hit_20bp=float(row.get("hit_20bp", 0.0)),
                avg_best_move=float(row.get("avg_best_move", 0.0)),
                p15_best_move=float(row.get("p15_best_move", 0.0)),
                window_min=int(row.get("window_min", 0)),
                window_max=int(row.get("window_max", 0)),
                n_val=int(row.get("n_val", 0)),
                tickers_val=int(row.get("tickers_val", 0)),
            )
        )

    return rules


def _add_tod_flags(row: Dict[str, Any], ts_utc: pd.Timestamp) -> None:
    ts_et = ts_utc.tz_convert("America/New_York")
    t = ts_et.time()
    row["tod_open"] = time(9, 30) <= t < time(10, 30)
    row["tod_mid"] = time(10, 30) <= t < time(15, 0)
    row["tod_close"] = time(15, 0) <= t < time(16, 0)


def _row_ts_epoch(row: Dict[str, Any]) -> Optional[int]:
    ts_epoch = _safe_int(row.get("ts_epoch") or row.get("ts"))
    if ts_epoch:
        return ts_epoch
    ts_utc = row.get("ts_utc")
    if ts_utc is None:
        return None
    try:
        ts = pd.Timestamp(ts_utc)
        if ts.tzinfo is None:
            ts = ts.tz_localize("UTC")
        return int(ts.timestamp())
    except Exception:
        return None


def _select_ts_expr(columns: set[str]) -> str:
    if "ts" in columns:
        return "ts::bigint"
    if "ts_epoch" in columns:
        return "ts_epoch::bigint"
    if "ts_utc" in columns:
        return "EXTRACT(EPOCH FROM ts_utc)::bigint"
    raise RuntimeError(f"{LIVE_TABLE} missing a usable timestamp column (ts/ts_epoch/ts_utc)")


def _rule_missing_columns(rule: FeedRule, columns: set[str]) -> List[str]:
    required = {name.lower() for cond in rule.conditions for name in cond.names}
    required -= _TOD_COLUMNS
    return sorted({c for c in required if c not in columns})


def _fallback_hook(side: str) -> str:
    return BULL_HOOK_URL if side == "bull" else BEAR_HOOK_URL


def _select_hook(rule: FeedRule) -> str:
    if REV_HOOK_URL:
        return REV_HOOK_URL
    timespan = (TIMESPAN or "").strip().lower()
    hit = rule.hit_20bp if rule.hit_20bp is not None else None
    if timespan in M_240_TIMESPANS and M_240_HOOK_URL:
        return M_240_HOOK_URL
    if timespan in QUICK_TIMESPANS:
        if hit is not None and hit >= QUICK_MIN_HIT:
            return (BULL_QUICK_HOOK_URL if rule.side == "bull" else BEAR_QUICK_HOOK_URL) or _fallback_hook(rule.side)
        return SHORT_TERM_HOOK_URL or _fallback_hook(rule.side)
    if timespan in SHORT_TIMESPANS:
        return SHORT_TERM_HOOK_URL or _fallback_hook(rule.side)
    if timespan in MID_TIMESPANS:
        return MID_TERM_HOOK_URL or _fallback_hook(rule.side)
    if timespan in LONG_TIMESPANS:
        return LONG_TERM_HOOK_URL or _fallback_hook(rule.side)
    return _fallback_hook(rule.side)


def _build_embed(rule: FeedRule, row: Dict[str, Any], ts_utc: pd.Timestamp) -> DiscordEmbed:
    side = rule.side.lower()
    color = "2ecc71" if side == "bull" else "e74c3c"
    ts_et = ts_utc.tz_convert("America/New_York")

    title = f"CA Rev 75+ {side.upper()} {rule.name}"
    desc = f"{row.get('ticker')} @ {ts_et.strftime('%Y-%m-%d %H:%M ET')}"

    embed = DiscordEmbed(title=title, description=desc, color=color)
    embed.set_timestamp()

    embed.add_embed_field(name="Probability (20bp)", value=f"{rule.hit_20bp:.1%}", inline=True)
    embed.add_embed_field(name="Expected Hold", value=f"{rule.window_min}-{rule.window_max}m", inline=True)
    embed.add_embed_field(
        name="Expected Move",
        value=f"avg {rule.avg_best_move:.2%} | p15 {rule.p15_best_move:.2%}",
        inline=False,
    )
    embed.add_embed_field(
        name="Sample",
        value=f"n={rule.n_val}, tickers={rule.tickers_val}",
        inline=True,
    )

    cond_preview = " and ".join(rule.raw_conditions)[:900]
    embed.add_embed_field(name="Conditions", value=cond_preview, inline=False)
    return embed


async def _fetch_live_rows(
    db: PolygonOptions, cutoff_epoch: int, ts_expr: str
) -> List[Dict[str, Any]]:
    sql = f"""
        SELECT *
        FROM {LIVE_TABLE}
        WHERE timespan = $1
          AND {ts_expr} >= $2
    """
    rows = await db.fetch_new(sql, TIMESPAN, cutoff_epoch)
    return [dict(r) for r in rows or []]


async def main() -> None:
    rules = _load_rules()
    if not rules:
        raise SystemExit("no rules loaded (check candidates CSV / filters)")

    db = PolygonOptions()
    await db.connect()

    columns = {c.lower() for c in (await db.get_table_columns(LIVE_TABLE))}
    missing_core = [c for c in ("ticker", "timespan") if c not in columns]
    if missing_core:
        raise RuntimeError(f"{LIVE_TABLE} missing required columns: {missing_core}")
    ts_expr = _select_ts_expr(columns)

    filtered_rules: List[FeedRule] = []
    dropped: List[str] = []
    for rule in rules:
        missing = _rule_missing_columns(rule, columns)
        if missing:
            dropped.append(f"{rule.name} -> {missing}")
            continue
        filtered_rules.append(rule)

    if dropped:
        preview = "\n".join(dropped[:10])
        print(f"[WARN] dropped {len(dropped)} rules due to missing columns (showing 10):\n{preview}")
    rules = filtered_rules
    if not rules:
        raise SystemExit("no rules remaining after column validation")

    state = _load_state(STATE_PATH)
    last_sent: Dict[str, int] = {}

    try:
        while True:
            await touch_feed_heartbeat(db, "ca_rev_75_feeds", __file__)
            now = pd.Timestamp.now(tz="UTC")
            _prune_state(state, now)
            cutoff_epoch = int((now - timedelta(minutes=LOOKBACK_MINUTES)).timestamp())

            rows = await _fetch_live_rows(db, cutoff_epoch, ts_expr)
            if not rows:
                await asyncio.sleep(POLL_SECONDS)
                continue

            for row in rows:
                ts_epoch = _row_ts_epoch(row)
                if not ts_epoch:
                    continue
                ts_utc = pd.to_datetime(ts_epoch, unit="s", utc=True)
                _add_tod_flags(row, ts_utc)

                ticker = str(row.get("ticker", ""))
                if not ticker:
                    continue

                for rule in rules:
                    if not all(eval_condition(c, row) for c in rule.conditions):
                        continue
                    key = _signal_key(rule, ticker, ts_epoch)
                    if key in state.get("sent", {}):
                        continue
                    cooldown_key = f"{rule.name}|{ticker}"
                    last_ts = last_sent.get(cooldown_key)
                    if last_ts and ts_epoch <= last_ts + (COOLDOWN_MINUTES * 60):
                        continue
                    last_sent[cooldown_key] = ts_epoch
                    state.setdefault("sent", {})[key] = ts_utc.isoformat()

                    hook_url = _select_hook(rule)
                    if not hook_url:
                        continue

                    embed = _build_embed(rule, row, ts_utc)
                    webhook = AsyncDiscordWebhook(url=hook_url)
                    webhook.add_embed(embed)
                    await webhook.execute()

            _save_state(STATE_PATH, state)
            await asyncio.sleep(POLL_SECONDS)
    finally:
        _save_state(STATE_PATH, state)
        await db.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
