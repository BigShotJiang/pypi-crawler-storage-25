from __future__ import annotations

import ast
import asyncio
import json
import os
import re
from dataclasses import dataclass
from datetime import timedelta, time as dt_time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd
from discord_webhook import AsyncDiscordWebhook, DiscordEmbed

from fudstop4.apis.polygonio.polygon_options import PolygonOptions

try:
    from .discord_routes import resolve_webhook_url
except ImportError:
    from feeds.discord_routes import resolve_webhook_url

try:
    from .feed_runtime import touch_feed_heartbeat
except ImportError:
    from feeds.feed_runtime import touch_feed_heartbeat


SOURCE_TABLE = os.getenv("CA_UNIFIED_SOURCE_TABLE", "public.ca")
LIVE_TABLE = os.getenv("CANDLE_LIVE_TABLE", "ca_live")
DEFAULT_TIMESPAN = os.getenv("CA_UNIFIED_TIMESPAN", "m1")
TIMESPANS_RAW = os.getenv("CA_UNIFIED_TIMESPANS", "")
TIMESPANS = [t.strip() for t in TIMESPANS_RAW.split(",") if t.strip()] or [DEFAULT_TIMESPAN]
TIMESPAN = TIMESPANS[0] if TIMESPANS else DEFAULT_TIMESPAN
POLL_SECONDS = float(os.getenv("CA_UNIFIED_POLL_SECONDS", "5"))
COOLDOWN_MINUTES = int(os.getenv("CA_UNIFIED_COOLDOWN_MINUTES", "1"))
IGNORE_TOD = os.getenv("CA_UNIFIED_IGNORE_TOD", "1").strip().lower() in ("1", "true", "yes", "y", "on")
LOOKBACK_MINUTES = int(os.getenv("CA_UNIFIED_LOOKBACK_MINUTES", "60"))
LOOKBACK_BARS = int(os.getenv("CA_UNIFIED_LOOKBACK_BARS", "30"))
MIN_HITS = int(os.getenv("CA_UNIFIED_MIN_HITS", "2"))
MIN_HITS_QUICK = int(os.getenv("CA_UNIFIED_MIN_HITS_QUICK", "0"))
REQUIRE_LATEST = os.getenv("CA_UNIFIED_REQUIRE_LATEST", "1").strip().lower() in ("1", "true", "yes", "y", "on")
MIN_BARS_PER_TICKER = int(os.getenv("CA_UNIFIED_MIN_BARS_PER_TICKER", "10"))
MAX_STALENESS_MINUTES = int(os.getenv("CA_UNIFIED_MAX_STALENESS_MINUTES", "5"))
TRACK_RESULTS = os.getenv("CA_UNIFIED_TRACK_RESULTS", "1").strip().lower() in ("1", "true", "yes", "y", "on")
RESULTS_TARGET_RET = float(os.getenv("CA_UNIFIED_RESULTS_TARGET_RET", "0.002"))
RESULT_WINDOW_MIN = int(os.getenv("CA_UNIFIED_RESULT_WINDOW_MIN", "5"))
RESULT_WINDOW_MAX = int(os.getenv("CA_UNIFIED_RESULT_WINDOW_MAX", "20"))
RESULTS_STATE_PATH = Path(
    os.getenv("CA_UNIFIED_RESULTS_STATE_PATH", "logs/ca_unified_feed_results_state.json")
)
SHOW_CHART = os.getenv("CA_UNIFIED_SHOW_CHART", "1").strip().lower() in ("1", "true", "yes", "y", "on")
CHART_POINTS = int(os.getenv("CA_UNIFIED_CHART_POINTS", "24"))

CANDIDATES_CSV = Path(
    os.getenv(
        "CA_UNIFIED_CANDIDATES_CSV",
        "runs/ca_rev_m1_rsi_td_only_w5_10_ret20_all.csv",
    )
)
CANDIDATES_CSVS_RAW = os.getenv("CA_UNIFIED_CANDIDATES_CSVS", "")
CANDIDATES_DIR = Path(os.getenv("CA_UNIFIED_CANDIDATES_DIR", ""))
MIN_HIT20 = float(os.getenv("CA_UNIFIED_MIN_HIT20", "0.75"))
MIN_N = int(os.getenv("CA_UNIFIED_MIN_N", "25"))
MIN_AVG_MOVE = float(os.getenv("CA_UNIFIED_MIN_AVG_MOVE", "0"))
MIN_P15_MOVE = float(os.getenv("CA_UNIFIED_MIN_P15_MOVE", "0"))
QUICK_MIN_AVG_MOVE = float(os.getenv("CA_UNIFIED_QUICK_MIN_AVG_MOVE", "0"))
QUICK_MIN_P15_MOVE = float(os.getenv("CA_UNIFIED_QUICK_MIN_P15_MOVE", "0"))
MAX_RULES = int(os.getenv("CA_UNIFIED_MAX_RULES", "0"))
BASE_MODE = os.getenv("CA_UNIFIED_BASE_MODE", "rsi_td_only")
INCLUDE_BASE_RULES = os.getenv("CA_UNIFIED_INCLUDE_BASE_RULES", "0").strip().lower() in ("1", "true", "yes", "y", "on")
MAX_RULES_PER_TICKER = int(os.getenv("CA_UNIFIED_MAX_RULES_PER_TICKER", "1"))
INCLUDE_DIVERSE_RULES = os.getenv("CA_UNIFIED_INCLUDE_DIVERSE", "1").strip().lower() in ("1", "true", "yes", "y", "on")
INCLUDE_DIVERSE_ALL_TIMESPANS = os.getenv("CA_UNIFIED_DIVERSE_ALL_TIMESPANS", "0").strip().lower() in ("1", "true", "yes", "y", "on")

RSI_OVERSOLD = float(os.getenv("CA_UNIFIED_RSI_OVERSOLD", "30"))
RSI_OVERBOUGHT = float(os.getenv("CA_UNIFIED_RSI_OVERBOUGHT", "70"))
TD_COUNT_MIN = int(os.getenv("CA_UNIFIED_TD_COUNT_MIN", "8"))

BULL_QUICK_HOOK_URL = resolve_webhook_url("QUICK_BULL", route_id="ca_quick_bull")
BEAR_QUICK_HOOK_URL = resolve_webhook_url("QUICK_BEAR", route_id="ca_quick_bear")
SHORT_TERM_HOOK_URL = resolve_webhook_url("SHORT_TERM", route_id="ca_short_term")
MID_TERM_HOOK_URL = resolve_webhook_url("MID_TERM", route_id="ca_mid_term")
LONG_TERM_HOOK_URL = resolve_webhook_url("LONG_TERM", route_id="ca_long_term")
M_240_HOOK_URL = resolve_webhook_url("M_240_FEEDS", route_id="ca_240m")
QUICK_MIN_HIT = float(os.getenv("QUICK_MIN_HIT", "0.85"))
UNIFIED_HOOK_URL = resolve_webhook_url("CA_UNIFIED_WEBHOOK", "LONG_TERM", route_id="ca_unified")
BULL_HOOK_URL = resolve_webhook_url(
    "CA_BULL_WEBHOOK",
    "SECAPI_BULL_WEBHOOK",
    "SHORT_TERM",
    route_id="ca_bull",
)
BEAR_HOOK_URL = resolve_webhook_url(
    "CA_BEAR_WEBHOOK",
    "SECAPI_BEAR_WEBHOOK",
    "MID_TERM",
    route_id="ca_bear",
)
RESULTS_HOOK_URL = resolve_webhook_url(
    "CA_RESULTS_WEBHOOK",
    "CA_UNIFIED_RESULTS_WEBHOOK",
    "LONG_TERM",
    route_id="ca_results",
)
if not RESULTS_HOOK_URL:
    RESULTS_HOOK_URL = LONG_TERM_HOOK_URL

QUICK_TIMESPANS = {"m1"}
SHORT_TIMESPANS = {"m5", "m15"}
MID_TIMESPANS = {"m30", "m60"}
LONG_TIMESPANS = {"m120", "d1", "w1"}
M_240_TIMESPANS = {"m240"}
_TOD_COLUMNS = {"tod_open", "tod_mid", "tod_close"}


_ALLOWED_NODES = (
    ast.Expression,
    ast.BoolOp,
    ast.UnaryOp,
    ast.BinOp,
    ast.Compare,
    ast.Name,
    ast.Load,
    ast.Constant,
    ast.Tuple,
    ast.List,
    ast.And,
    ast.Or,
    ast.Not,
    ast.USub,
    ast.UAdd,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.Mod,
    ast.Pow,
    ast.Eq,
    ast.NotEq,
    ast.Lt,
    ast.LtE,
    ast.Gt,
    ast.GtE,
    ast.In,
    ast.NotIn,
)


@dataclass(frozen=True)
class CompiledCondition:
    raw: str
    expr: str
    code: Any
    names: Tuple[str, ...]


@dataclass(frozen=True)
class FeedRule:
    name: str
    side: str
    timespan: str
    conditions: Tuple[CompiledCondition, ...]
    raw_conditions: Tuple[str, ...]
    fields: Tuple[str, ...]
    description: str
    hit_20bp: Optional[float]
    hold: Optional[str]
    hold_category: Optional[str] = None
    window_min: Optional[int] = None
    window_max: Optional[int] = None
    avg_best_move: Optional[float] = None
    p15_best_move: Optional[float] = None
    n_val: Optional[int] = None
    tickers_val: Optional[int] = None


def _normalize_expr(expr: str) -> str:
    s = expr.strip()
    s = re.sub(r"\bAND\b", "and", s, flags=re.IGNORECASE)
    s = re.sub(r"\bOR\b", "or", s, flags=re.IGNORECASE)
    s = re.sub(r"\bNOT\b", "not", s, flags=re.IGNORECASE)
    s = re.sub(r"\bTRUE\b", "True", s, flags=re.IGNORECASE)
    s = re.sub(r"\bFALSE\b", "False", s, flags=re.IGNORECASE)
    s = re.sub(r"\bIS\s+TRUE\b", "== True", s, flags=re.IGNORECASE)
    s = re.sub(r"\bIS\s+FALSE\b", "== False", s, flags=re.IGNORECASE)
    s = re.sub(r"\bNOT\s+IN\b", "not in", s, flags=re.IGNORECASE)
    s = re.sub(r"\bIN\b", "in", s, flags=re.IGNORECASE)
    s = s.replace("<>", "!=")
    s = re.sub(r"(?<![<>=!])=(?!=)", "==", s)
    return s


def _validate_ast(tree: ast.AST) -> None:
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            raise ValueError(f"Disallowed expression node: {type(node).__name__}")
        if isinstance(node, ast.Name) and node.id.startswith("__"):
            raise ValueError("Disallowed name")


def compile_condition(raw: str) -> CompiledCondition:
    expr = _normalize_expr(raw)
    tree = ast.parse(expr, mode="eval")
    _validate_ast(tree)
    names = [node.id for node in ast.walk(tree) if isinstance(node, ast.Name)]
    code = compile(tree, "<condition>", "eval")
    return CompiledCondition(raw=raw, expr=expr, code=code, names=tuple(sorted(set(names))))


def eval_condition(cond: CompiledCondition, row: Dict[str, Any]) -> bool:
    locals_d: Dict[str, Any] = {}
    for name in cond.names:
        if name not in row:
            return False
        locals_d[name] = row[name]
    try:
        return bool(eval(cond.code, {"__builtins__": {}}, locals_d))
    except Exception:
        return False


def _parse_conditions(raw: Any) -> List[str]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x) for x in raw if str(x).strip()]
    try:
        parsed = ast.literal_eval(str(raw))
    except Exception:
        return []
    if isinstance(parsed, list):
        return [str(x) for x in parsed if str(x).strip()]
    return []


def _strip_tod_conditions(conds: Iterable[str]) -> List[str]:
    out: List[str] = []
    for cond in conds:
        lowered = cond.lower()
        if "tod_open" in lowered or "tod_mid" in lowered or "tod_close" in lowered or "time_et" in lowered:
            continue
        out.append(cond)
    return out


def _strip_tod_expr(expr: str) -> str:
    parts = re.split(r"\bAND\b", expr, flags=re.IGNORECASE)
    kept = []
    for part in parts:
        lowered = part.lower()
        if "tod_open" in lowered or "tod_mid" in lowered or "tod_close" in lowered or "time_et" in lowered:
            continue
        kept.append(part.strip())
    return " AND ".join([p for p in kept if p])


def _normalize_where_key(expr: str) -> str:
    normalized = " ".join(expr.lower().split())
    if " or " in normalized or "(" in normalized or ")" in normalized:
        return normalized
    parts = [p.strip() for p in re.split(r"\band\b", normalized) if p.strip()]
    return " and ".join(sorted(parts))


def _base_conditions(side: str) -> List[str]:
    if BASE_MODE == "none":
        return []
    if side == "bull":
        return [
            f"rsi <= {RSI_OVERSOLD:g}",
            f"td_buy_count >= {TD_COUNT_MIN}",
        ]
    return [
        f"rsi >= {RSI_OVERBOUGHT:g}",
        f"td_sell_count >= {TD_COUNT_MIN}",
    ]


def _safe_int(value: Any) -> int:
    try:
        return int(float(str(value)))
    except Exception:
        return 0


def _timespan_to_minutes(timespan: str) -> float:
    ts = (timespan or "").strip().lower()
    if not ts:
        return 0.0
    match = re.match(r"^([a-z]+)(\d+)$", ts)
    if match:
        unit = match.group(1)
        qty = int(match.group(2))
    else:
        match = re.match(r"^(\d+)([a-z]+)$", ts)
        if not match:
            return 0.0
        qty = int(match.group(1))
        unit = match.group(2)

    minutes_per_unit = {
        "s": 1.0 / 60.0,
        "sec": 1.0 / 60.0,
        "secs": 1.0 / 60.0,
        "second": 1.0 / 60.0,
        "seconds": 1.0 / 60.0,
        "m": 1.0,
        "min": 1.0,
        "mins": 1.0,
        "minute": 1.0,
        "minutes": 1.0,
        "h": 60.0,
        "hr": 60.0,
        "hrs": 60.0,
        "hour": 60.0,
        "hours": 60.0,
        "d": 1440.0,
        "day": 1440.0,
        "days": 1440.0,
    }
    if unit not in minutes_per_unit:
        return 0.0
    return float(qty) * minutes_per_unit[unit]


def _hold_category(minutes_max: float) -> str:
    if minutes_max <= 10:
        return "scalp"
    if minutes_max <= 30:
        return "short"
    if minutes_max <= 90:
        return "intraday"
    if minutes_max <= 240:
        return "swing"
    return "position"


def _format_hold_window(window_min: int, window_max: int, timespan: str) -> Optional[str]:
    if window_min <= 0 or window_max <= 0 or window_max < window_min:
        return None
    minutes_per_bar = _timespan_to_minutes(timespan)
    if minutes_per_bar <= 0:
        return None
    hold_min = int(round(window_min * minutes_per_bar))
    hold_max = int(round(window_max * minutes_per_bar))
    return f"{hold_min}-{hold_max}m"


def _infer_timespan_from_text(text: str) -> Optional[str]:
    if not text:
        return None
    match = re.search(r"([smhd]\d+)", text.lower())
    if not match:
        return None
    return match.group(1)


def _candidate_paths() -> List[Path]:
    paths: List[Path] = []
    if CANDIDATES_CSVS_RAW.strip():
        for raw in CANDIDATES_CSVS_RAW.split(","):
            p = raw.strip()
            if p:
                paths.append(Path(p))
    elif CANDIDATES_DIR and CANDIDATES_DIR.exists():
        paths.extend(sorted(CANDIDATES_DIR.glob("*.csv")))
    else:
        paths.append(CANDIDATES_CSV)
    return paths


def _lookback_seconds(timespan: str) -> int:
    minutes = _timespan_to_minutes(timespan)
    by_minutes = int(LOOKBACK_MINUTES * 60)
    if LOOKBACK_BARS <= 0 or minutes <= 0:
        return by_minutes
    by_bars = int(round(LOOKBACK_BARS * minutes * 60))
    return max(by_minutes, by_bars)


def _normalize_epoch(value: int) -> int:
    if value > 1_000_000_000_000:
        return int(value / 1000)
    return value


def _row_ts_epoch(row: Dict[str, Any]) -> Optional[int]:
    ts_epoch = _safe_int(row.get("ts_epoch") or row.get("ts"))
    if ts_epoch:
        return _normalize_epoch(ts_epoch)
    ts_utc = row.get("ts_utc")
    if ts_utc is None:
        return None
    try:
        ts = pd.Timestamp(ts_utc)
        if ts.tzinfo is None:
            ts = ts.tz_localize("UTC")
        return int(ts.timestamp())
    except Exception:
        return None


def _row_ts_utc(row: Dict[str, Any]) -> Optional[pd.Timestamp]:
    ts_utc = row.get("ts_utc")
    if ts_utc is not None:
        ts = pd.Timestamp(ts_utc)
        if ts.tzinfo is None:
            ts = ts.tz_localize("UTC")
        return ts
    ts_epoch = _row_ts_epoch(row)
    if not ts_epoch:
        return None
    return pd.to_datetime(ts_epoch, unit="s", utc=True)


def _apply_tod_flags(row: Dict[str, Any]) -> None:
    ts_utc = _row_ts_utc(row)
    if ts_utc is None:
        return
    ts_et = ts_utc.tz_convert("America/New_York")
    tod = ts_et.time()
    row["tod_open"] = (tod >= dt_time(9, 30)) and (tod < dt_time(10, 30))
    row["tod_mid"] = (tod >= dt_time(10, 30)) and (tod < dt_time(15, 0))
    row["tod_close"] = (tod >= dt_time(15, 0)) and (tod < dt_time(16, 0))


async def _fetch_recent_rows(
    db: PolygonOptions,
    *,
    table: str,
    timespan: str,
    start_ts: int,
    max_rows_per_ticker: int,
) -> List[dict]:
    start_ts_text = str(start_ts)
    sql = f"""
        SELECT *
        FROM (
            SELECT
                *,
                ROW_NUMBER() OVER (PARTITION BY ticker ORDER BY ts DESC) AS rn
            FROM {table}
            WHERE timespan = $1
              AND ts >= $2
        ) t
        WHERE rn <= $3
    """
    return await db.fetch_new(sql, timespan, start_ts_text, max_rows_per_ticker)


async def _fetch_outcome_rows(
    db: PolygonOptions,
    *,
    table: str,
    timespan: str,
    ticker: str,
    start_ts: int,
    end_ts: int,
) -> List[dict]:
    start_ts_text = str(start_ts)
    end_ts_text = str(end_ts)
    sql = f"""
        SELECT ts, h, l, c
        FROM {table}
        WHERE timespan = $1
          AND ticker = $2
          AND ts > $3
          AND ts <= $4
        ORDER BY ts ASC
    """
    return await db.fetch_new(sql, timespan, ticker, start_ts_text, end_ts_text)


def _format_value(value: Any) -> str:
    if value is None:
        return "n/a"
    if isinstance(value, bool):
        return "true" if value else "false"
    try:
        fval = float(value)
    except Exception:
        return str(value)
    abs_val = abs(fval)
    if abs_val >= 1000:
        return f"{fval:.0f}"
    if abs_val >= 100:
        return f"{fval:.1f}"
    if abs_val >= 10:
        return f"{fval:.2f}"
    if abs_val >= 1:
        return f"{fval:.3f}"
    return f"{fval:.4f}"


def _format_metrics(row: Dict[str, Any], fields: Iterable[str]) -> str:
    parts = []
    for field in fields:
        parts.append(f"{field}={_format_value(row.get(field))}")
    return " | ".join(parts)


def _rule_missing_columns(rule: FeedRule, columns: set[str]) -> List[str]:
    required = {name.lower() for cond in rule.conditions for name in cond.names}
    required.update({c.lower() for c in rule.fields})
    required -= _TOD_COLUMNS
    return sorted({c for c in required if c not in columns})


def _rule_score(rule: FeedRule) -> float:
    if rule.hit_20bp is None:
        return 0.0
    try:
        return float(rule.hit_20bp)
    except Exception:
        return 0.0


def _fallback_hook(rule: FeedRule) -> str:
    return BULL_HOOK_URL if rule.side == "bull" else BEAR_HOOK_URL


def _select_hook(rule: FeedRule) -> str:
    if UNIFIED_HOOK_URL:
        return UNIFIED_HOOK_URL
    timespan = (rule.timespan or "").strip().lower()
    hit = rule.hit_20bp if rule.hit_20bp is not None else None
    if timespan in M_240_TIMESPANS and M_240_HOOK_URL:
        return M_240_HOOK_URL
    if timespan in QUICK_TIMESPANS:
        if hit is not None and hit >= QUICK_MIN_HIT:
            return (BULL_QUICK_HOOK_URL if rule.side == "bull" else BEAR_QUICK_HOOK_URL) or _fallback_hook(rule)
        return SHORT_TERM_HOOK_URL or _fallback_hook(rule)
    if timespan in SHORT_TIMESPANS:
        return SHORT_TERM_HOOK_URL or _fallback_hook(rule)
    if timespan in MID_TIMESPANS:
        return MID_TERM_HOOK_URL or _fallback_hook(rule)
    if timespan in LONG_TIMESPANS:
        return LONG_TERM_HOOK_URL or _fallback_hook(rule)
    return _fallback_hook(rule)


def _rule_hit(rule: FeedRule, row: Dict[str, Any]) -> bool:
    return all(eval_condition(cond, row) for cond in rule.conditions)


def _dedupe_rules(rules: List[FeedRule]) -> List[FeedRule]:
    deduped: Dict[Tuple[str, str, str], FeedRule] = {}
    for rule in rules:
        key = (rule.timespan, rule.side, _normalize_where_key(" AND ".join(rule.raw_conditions)))
        current = deduped.get(key)
        if current is None or _rule_score(rule) > _rule_score(current):
            deduped[key] = rule
    return list(deduped.values())


def _ascii_sparkline(values: Iterable[float], width: int) -> str:
    series = [v for v in values if v is not None]
    if not series:
        return ""
    if width > 0 and len(series) > width:
        series = series[-width:]
    low = min(series)
    high = max(series)
    if high == low:
        return "-" * len(series)
    levels = " .:-=+*#%@"
    scale = (len(levels) - 1) / (high - low)
    chars = []
    for val in series:
        idx = int((val - low) * scale)
        idx = max(0, min(idx, len(levels) - 1))
        chars.append(levels[idx])
    return "".join(chars)


def _parse_hold_window(hold: Optional[str]) -> Tuple[int, int]:
    if hold:
        match = re.match(r"(\d+)\s*-\s*(\d+)\s*m", hold.strip(), re.IGNORECASE)
        if match:
            low = int(match.group(1))
            high = int(match.group(2))
            if low > 0 and high >= low:
                return low, high
    return RESULT_WINDOW_MIN, RESULT_WINDOW_MAX


def _load_results_state() -> List[dict]:
    if not RESULTS_STATE_PATH.exists():
        return []
    try:
        data = json.loads(RESULTS_STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return []
    if isinstance(data, list):
        return data
    return []


def _save_results_state(pending: List[dict]) -> None:
    RESULTS_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    RESULTS_STATE_PATH.write_text(json.dumps(pending, indent=2), encoding="utf-8")


def _result_key(item: dict) -> str:
    return f"{item.get('rule')}|{item.get('ticker')}|{item.get('entry_ts')}|{item.get('timespan')}"


def _coerce_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        return float(value)
    except Exception:
        return None


def _compute_outcome(
    rows: List[dict],
    *,
    side: str,
    entry_price: float,
) -> Optional[dict]:
    highs = []
    lows = []
    for row in rows:
        h = _coerce_float(row.get("h"))
        l = _coerce_float(row.get("l"))
        if h is not None:
            highs.append(h)
        if l is not None:
            lows.append(l)
    if not highs or not lows:
        return None
    max_h = max(highs)
    min_l = min(lows)

    if side == "bull":
        best_move = max_h / entry_price - 1.0
        adverse_move = min_l / entry_price - 1.0
    else:
        best_move = entry_price / min_l - 1.0
        adverse_move = entry_price / max_h - 1.0

    return {
        "max_h": max_h,
        "min_l": min_l,
        "best_move": best_move,
        "adverse_move": adverse_move,
    }


def _build_results_embed(
    rule: FeedRule,
    *,
    ticker: str,
    side: str,
    entry_ts: pd.Timestamp,
    entry_price: float,
    window_min: int,
    window_max: int,
    outcome: dict,
) -> DiscordEmbed:
    color = "2ecc71" if side == "bull" else "e74c3c"
    ts_et = entry_ts.tz_convert("America/New_York")
    title = f"CA RESULT: {rule.name}"
    desc = (
        f"{ticker} {side.upper()} | {rule.timespan} | entry {entry_price:.4f} "
        f"@ {ts_et.strftime('%Y-%m-%d %H:%M ET')}"
    )
    embed = DiscordEmbed(title=title, description=desc, color=color)
    embed.set_timestamp()

    embed.add_embed_field(name="Setup", value=rule.description, inline=False)

    best_move = outcome["best_move"]
    adverse_move = outcome["adverse_move"]
    hit_target = best_move >= RESULTS_TARGET_RET

    embed.add_embed_field(
        name="Outcome",
        value=(
            f"Window: {window_min}-{window_max}m\n"
            f"Best move: {best_move:.2%}\n"
            f"Adverse: {adverse_move:.2%}\n"
            f"Hit {RESULTS_TARGET_RET:.2%}: {hit_target}"
        ),
        inline=False,
    )

    stats_parts = []
    if rule.hit_20bp is not None:
        stats_parts.append(f"Hit 20bp: {rule.hit_20bp:.1%}")
    if rule.hold:
        stats_parts.append(f"Hold: {rule.hold}")
    if rule.hold_category:
        stats_parts.append(f"Hold cat: {rule.hold_category}")
    if stats_parts:
        embed.add_embed_field(name="Stats", value=" | ".join(stats_parts), inline=False)

    embed.set_footer(text="CA feed results")
    return embed


def _load_candidate_rules(
    candidate_paths: Iterable[Path],
    *,
    allowed_timespans: Iterable[str],
    default_timespan: str,
) -> List[FeedRule]:
    allowed = {t.lower() for t in allowed_timespans if t}
    default_timespan = (default_timespan or "").strip().lower() or "m1"
    rules: List[FeedRule] = []

    for path in candidate_paths:
        if not path.exists():
            continue
        if path.stat().st_size == 0:
            print(f"[WARN] candidates CSV is empty: {path}")
            continue
        try:
            df = pd.read_csv(path)
        except pd.errors.EmptyDataError:
            print(f"[WARN] candidates CSV has no columns: {path}")
            continue
        except Exception as exc:
            print(f"[WARN] failed to read candidates CSV {path}: {exc}")
            continue
        if df.empty:
            continue
        required_cols = {"hit_20bp", "n_val", "conditions", "side"}
        missing_cols = required_cols - set(df.columns)
        if missing_cols:
            print(f"[WARN] candidates CSV missing columns {sorted(missing_cols)}: {path}")
            continue

        df = df[df["hit_20bp"] >= MIN_HIT20]
        df = df[df["n_val"] >= MIN_N]
        if BASE_MODE and "base_mode" in df.columns:
            df = df[df["base_mode"] == BASE_MODE]
        if df.empty:
            continue

        df = df.sort_values(["hit_20bp", "n_val"], ascending=[False, False])

        inferred_ts = _infer_timespan_from_text(path.stem)
        for idx, row in df.iterrows():
            side = str(row.get("side", "")).strip().lower()
            if side not in ("bull", "bear"):
                continue
            conds = _parse_conditions(row.get("conditions"))
            if IGNORE_TOD:
                conds = _strip_tod_conditions(conds)
            if not conds:
                continue

            row_ts = str(row.get("timespan", "")).strip().lower()
            timespan = (row_ts or inferred_ts or default_timespan).lower()
            if allowed and timespan not in allowed:
                continue

            base = _base_conditions(side)
            raw_conditions = base + conds
            try:
                compiled = tuple(compile_condition(c) for c in raw_conditions)
            except Exception:
                continue

            label = str(row.get("label", "")).strip() or f"candidate_{idx}"
            name = f"cand_{side}_{timespan}_{label}"

            window_min = _safe_int(row.get("window_min"))
            window_max = _safe_int(row.get("window_max"))
            hold = _format_hold_window(window_min, window_max, timespan)
            hold_minutes_max = _timespan_to_minutes(timespan) * window_max if hold else 0.0
            hold_category = _hold_category(hold_minutes_max) if hold else None

            avg_move = float(row.get("avg_best_move", 0.0) or 0.0)
            p15_move = float(row.get("p15_best_move", 0.0) or 0.0)
            if timespan in QUICK_TIMESPANS:
                if QUICK_MIN_AVG_MOVE > 0 and avg_move < QUICK_MIN_AVG_MOVE:
                    continue
                if QUICK_MIN_P15_MOVE > 0 and p15_move < QUICK_MIN_P15_MOVE:
                    continue
            else:
                if MIN_AVG_MOVE > 0 and avg_move < MIN_AVG_MOVE:
                    continue
                if MIN_P15_MOVE > 0 and p15_move < MIN_P15_MOVE:
                    continue

            rules.append(
                FeedRule(
                    name=name,
                    side=side,
                    timespan=timespan,
                    conditions=compiled,
                    raw_conditions=tuple(raw_conditions),
                    fields=tuple(),
                    description="Candidate rule (auto-mined)",
                    hit_20bp=float(row.get("hit_20bp", 0.0)),
                    hold=hold,
                    hold_category=hold_category,
                    window_min=window_min if window_min > 0 else None,
                    window_max=window_max if window_max > 0 else None,
                    avg_best_move=avg_move,
                    p15_best_move=p15_move,
                    n_val=int(row.get("n_val", 0)),
                    tickers_val=int(row.get("tickers_val", 0)),
                )
            )

    if not rules:
        return []

    rules = sorted(
        rules,
        key=lambda r: (_rule_score(r), r.n_val or 0),
        reverse=True,
    )
    if MAX_RULES > 0:
        rules = rules[:MAX_RULES]
    return rules


def _load_diverse_rules(timespan: str) -> List[FeedRule]:
    timespan = (timespan or "").strip().lower()
    rules_raw = [
        {
            "name": "Top Bullish 90%+",
            "side": "bull",
            "where": "rsi <= 30 AND td_buy_count >= 10 AND candle_completely_below_lower = true "
            "AND bb_width >= 0.03 AND rvol >= 1.5 AND stoch_rsi_k <= 10",
            "fields": ["c", "rsi", "td_buy_count", "bb_width", "rvol", "stoch_rsi_k"],
            "desc": "RSI<=30, TD Buy>=10, candle fully below BB lower, BB width>=0.03, rvol>=1.5, Stoch RSI<=10",
            "hit_20bp": 0.96,
            "hold": "1-15m",
        },
        {
            "name": "TD9 BBands + RVOL",
            "side": "bull",
            "where": "rsi <= 30 AND td_buy_count >= 10 AND candle_completely_below_lower = true "
            "AND bb_width >= 0.03 AND rvol >= 1.5",
            "fields": ["c", "rsi", "td_buy_count", "bb_width", "rvol"],
            "desc": "RSI<=30, TD Buy>=10, candle fully below BB lower, BB width>=0.03, rvol>=1.5",
            "hit_20bp": 0.9,
            "hold": "1-10m",
        },
        {
            "name": "BB Vol Confirm",
            "side": "bull",
            "where": "rsi <= 30 AND td_buy_count >= 10 AND candle_completely_below_lower = true "
            "AND bb_width >= 0.03 AND volume_confirm = true AND vwap_dist_pct >= 0.0",
            "fields": ["c", "rsi", "td_buy_count", "bb_width", "volume_confirm", "vwap_dist_pct"],
            "desc": "RSI<=30, TD Buy>=10, candle fully below BB lower, BB width>=0.03, volume confirm, VWAP dist>=0.0",
            "hit_20bp": 0.9375,
            "hold": "1-15m",
        },
        {
            "name": "BB Vol Confirm + Stoch RSI",
            "side": "bull",
            "where": "rsi <= 30 AND td_buy_count >= 10 AND candle_completely_below_lower = true "
            "AND bb_width >= 0.03 AND volume_confirm = true AND vwap_dist_pct >= 0.0 AND stoch_rsi_k <= 20",
            "fields": ["c", "rsi", "td_buy_count", "bb_width", "volume_confirm", "stoch_rsi_k", "vwap_dist_pct"],
            "desc": "RSI<=30, TD Buy>=10, candle fully below BB lower, BB width>=0.03, volume confirm, VWAP dist>=0.0, Stoch RSI<=20",
            "hit_20bp": 0.934783,
            "hold": "1-15m",
        },
        {
            "name": "ATR + RVOL",
            "side": "bull",
            "where": "rsi <= 30 AND td_buy_count >= 10 AND candle_completely_below_lower = true "
            "AND atr_pct >= 0.003 AND rvol >= 1.5 AND vwap_dist_pct >= 0.0",
            "fields": ["c", "rsi", "td_buy_count", "atr_pct", "rvol", "vwap_dist_pct"],
            "desc": "RSI<=30, TD Buy>=10, candle fully below BB lower, ATR%>=0.003, rvol>=1.5, VWAP dist>=0.0",
            "hit_20bp": 0.930233,
            "hold": "1-15m",
        },
        {
            "name": "ATR + Vol Confirm",
            "side": "bull",
            "where": "rsi <= 30 AND td_buy_count >= 10 AND candle_completely_below_lower = true "
            "AND atr_pct >= 0.003 AND volume_confirm = true AND vwap_dist_pct >= 0.0",
            "fields": ["c", "rsi", "td_buy_count", "atr_pct", "volume_confirm", "vwap_dist_pct"],
            "desc": "RSI<=30, TD Buy>=10, candle fully below BB lower, ATR%>=0.003, volume confirm, VWAP dist>=0.0",
            "hit_20bp": 0.909091,
            "hold": "1-15m",
        },
        {
            "name": "BB Width + TOD Close (TD8)",
            "side": "bull",
            "where": "rsi <= 30 AND td_buy_count >= 8 AND bb_width >= 0.04 AND tod_close = true",
            "fields": ["c", "rsi", "td_buy_count", "bb_width", "tod_close"],
            "desc": "RSI<=30, TD Buy>=8, BB width>=0.04, TOD close (15:00-16:00 ET)",
            "hit_20bp": 0.970588,
            "hold": "5-10m",
        },
        {
            "name": "BB Width + Candle Green",
            "side": "bear",
            "where": "rsi >= 70 AND td_sell_count >= 10 AND candle_completely_above_upper = true "
            "AND bb_width >= 0.05 AND candle_green = true",
            "fields": ["c", "rsi", "td_sell_count", "bb_width", "candle_green"],
            "desc": "RSI>=70, TD Sell>=10, candle fully above BB upper, BB width>=0.05, green candle",
            "hit_20bp": 0.906976,
            "hold": "1-20m",
        },
        {
            "name": "ATR + MFI 90 (TD8, Mid)",
            "side": "bear",
            "where": "rsi >= 70 AND td_sell_count >= 8 AND atr_pct >= 0.006 AND mfi >= 90 AND tod_mid = true",
            "fields": ["c", "rsi", "td_sell_count", "atr_pct", "mfi", "tod_mid"],
            "desc": "RSI>=70, TD Sell>=8, ATR%>=0.006, MFI>=90, TOD mid (10:30-15:00 ET)",
            "hit_20bp": 0.92,
            "hold": "5-10m",
        },
        {
            "name": "ATR + MFI TD13",
            "side": "bear",
            "where": "rsi >= 70 AND td_sell_count >= 13 AND candle_completely_above_upper = true "
            "AND atr_pct >= 0.003 AND mfi >= 80 AND vwap_dist_pct <= 0.0",
            "fields": ["c", "rsi", "td_sell_count", "atr_pct", "mfi", "vwap_dist_pct"],
            "desc": "RSI>=70, TD Sell>=13, candle fully above BB upper, ATR%>=0.003, MFI>=80, VWAP dist<=0.0",
            "hit_20bp": 0.928571,
            "hold": "1-20m",
        },
        {
            "name": "TRIX + VWAP Dist (Bear)",
            "side": "bear",
            "where": "trix >= 0.2 AND vwap_dist_pct >= 0.02",
            "fields": ["c", "trix", "vwap_dist_pct"],
            "desc": "TRIX>=0.2, VWAP dist>=0.02",
            "hit_20bp": 0.970588,
            "hold": "5-15m",
        },
        {
            "name": "auto_bear_atr_pct_0_003_and_trix_0_2_and_vwap_dist_0_02",
            "side": "bear",
            "where": "atr_pct >= 0.003 AND trix >= 0.2 AND vwap_dist_pct >= 0.02",
            "fields": ["atr_pct", "c", "trix", "vwap_dist_pct"],
            "desc": "atr% >= 0.003 AND trix >= 0.2 AND vwap_dist% >= 0.02",
            "hit_20bp": 1.0,
            "hold": "5-20m",
        },
        {
            "name": "auto_bull_bb_width_0_03_and_vwap_dist_0_02_and_tsi_cross_up",
            "side": "bull",
            "where": "bb_width >= 0.03 AND vwap_dist_pct <= -0.02 AND tsi_cross_up = true",
            "fields": ["bb_width", "c", "tsi_cross_up", "vwap_dist_pct"],
            "desc": "bb_width >= 0.03 AND vwap_dist% <= -0.02 AND tsi_cross_up = true",
            "hit_20bp": 1.0,
            "hold": "5-20m",
        },
        {
            "name": "auto_bear_bb_width_0_04_and_vwap_dist_0_01_and_di_bear",
            "side": "bear",
            "where": "bb_width >= 0.04 AND vwap_dist_pct >= 0.01 AND di_bear = true",
            "fields": ["bb_width", "c", "di_bear", "vwap_dist_pct"],
            "desc": "bb_width >= 0.04 AND vwap_dist% >= 0.01 AND di_bear = true",
            "hit_20bp": 0.970149,
            "hold": "5-20m",
        },
        {
            "name": "auto_bear_bb_width_0_04_and_cmo_40_and_ema_stack_bear",
            "side": "bear",
            "where": "bb_width >= 0.04 AND cmo >= 40 AND ema_stack_bear = true",
            "fields": ["bb_width", "c", "cmo", "ema_stack_bear"],
            "desc": "bb_width >= 0.04 AND cmo >= 40 AND ema_stack_bear = true",
            "hit_20bp": 0.966667,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_trend_regime_and_vwap_dist_0_02_and_ema_stack_bear",
            "side": "bear",
            "where": "trend_regime = true AND vwap_dist_pct >= 0.02 AND ema_stack_bear = true",
            "fields": ["c", "ema_stack_bear", "trend_regime", "vwap_dist_pct"],
            "desc": "trend_regime = true AND vwap_dist% >= 0.02 AND ema_stack_bear = true",
            "hit_20bp": 0.96,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_rvol_1_5_and_stoch_rsi_k_90_and_trix_0_1",
            "side": "bear",
            "where": "rvol >= 1.5 AND stoch_rsi_k >= 90 AND trix >= 0.1",
            "fields": ["c", "rvol", "stoch_rsi_k", "trix"],
            "desc": "rvol >= 1.5 AND stoch_rsi_k >= 90 AND trix >= 0.1",
            "hit_20bp": 0.93617,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_bb_width_0_03_and_cmo_50_and_ema_stack_bear",
            "side": "bear",
            "where": "bb_width >= 0.03 AND cmo >= 50 AND ema_stack_bear = true",
            "fields": ["bb_width", "c", "cmo", "ema_stack_bear"],
            "desc": "bb_width >= 0.03 AND cmo >= 50 AND ema_stack_bear = true",
            "hit_20bp": 0.935484,
            "hold": "3-12m",
        },
        {
            "name": "auto_bull_atr_pct_0_006_and_chop_60_and_vwap_dist_0_02",
            "side": "bull",
            "where": "atr_pct >= 0.006 AND chop >= 60 AND vwap_dist_pct <= -0.02",
            "fields": ["atr_pct", "c", "chop", "vwap_dist_pct"],
            "desc": "atr% >= 0.006 AND chop >= 60 AND vwap_dist% <= -0.02",
            "hit_20bp": 0.933333,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_bb_width_0_03_and_cmo_50_and_di_bear",
            "side": "bear",
            "where": "bb_width >= 0.03 AND cmo >= 50 AND di_bear = true",
            "fields": ["bb_width", "c", "cmo", "di_bear"],
            "desc": "bb_width >= 0.03 AND cmo >= 50 AND di_bear = true",
            "hit_20bp": 0.931034,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_atr_pct_0_006_and_volume_confirm_and_candle_above_band",
            "side": "bear",
            "where": "atr_pct >= 0.006 AND volume_confirm = true AND candle_completely_above_upper = true",
            "fields": ["atr_pct", "c", "candle_completely_above_upper", "volume_confirm"],
            "desc": "atr% >= 0.006 AND volume_confirm = true AND candle_completely_above_upper = true",
            "hit_20bp": 0.931034,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_squeeze_off_and_roc_2_and_di_bear",
            "side": "bear",
            "where": "squeeze_off = true AND roc >= 2 AND di_bear = true",
            "fields": ["c", "di_bear", "roc", "squeeze_off"],
            "desc": "squeeze_off = true AND roc >= 2 AND di_bear = true",
            "hit_20bp": 0.92,
            "hold": "3-12m",
        },
        {
            "name": "auto_bull_stoch_rsi_k_10_and_trix_0_1_and_vwap_dist_0_02",
            "side": "bull",
            "where": "stoch_rsi_k <= 10 AND trix <= -0.1 AND vwap_dist_pct <= -0.02",
            "fields": ["c", "stoch_rsi_k", "trix", "vwap_dist_pct"],
            "desc": "stoch_rsi_k <= 10 AND trix <= -0.1 AND vwap_dist% <= -0.02",
            "hit_20bp": 0.918919,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_atr_pct_0_006_and_stoch_rsi_k_90_and_trix_0_1",
            "side": "bear",
            "where": "atr_pct >= 0.006 AND stoch_rsi_k >= 90 AND trix >= 0.1",
            "fields": ["atr_pct", "c", "stoch_rsi_k", "trix"],
            "desc": "atr% >= 0.006 AND stoch_rsi_k >= 90 AND trix >= 0.1",
            "hit_20bp": 0.913043,
            "hold": "5-20m",
        },
        {
            "name": "auto_bear_volume_confirm_and_bb_close_outside_upper_and_trix_0_1",
            "side": "bear",
            "where": "volume_confirm = true AND bb_close_outside_upper = true AND trix >= 0.1",
            "fields": ["bb_close_outside_upper", "c", "trix", "volume_confirm"],
            "desc": "volume_confirm = true AND bb_close_outside_upper = true AND trix >= 0.1",
            "hit_20bp": 0.913043,
            "hold": "5-20m",
        },
        {
            "name": "auto_bull_atr_pct_0_006_and_chop_60_and_vwap_dist_0_01",
            "side": "bull",
            "where": "atr_pct >= 0.006 AND chop >= 60 AND vwap_dist_pct <= -0.01",
            "fields": ["atr_pct", "c", "chop", "vwap_dist_pct"],
            "desc": "atr% >= 0.006 AND chop >= 60 AND vwap_dist% <= -0.01",
            "hit_20bp": 0.912281,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_squeeze_off_and_trix_0_2_and_vwap_dist_0_02",
            "side": "bear",
            "where": "squeeze_off = true AND trix >= 0.2 AND vwap_dist_pct >= 0.02",
            "fields": ["c", "squeeze_off", "trix", "vwap_dist_pct"],
            "desc": "squeeze_off = true AND trix >= 0.2 AND vwap_dist% >= 0.02",
            "hit_20bp": 0.911765,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_atr_pct_0_006_and_rvol_2_0_and_stoch_rsi_k_90",
            "side": "bear",
            "where": "atr_pct >= 0.006 AND rvol >= 2.0 AND stoch_rsi_k >= 90",
            "fields": ["atr_pct", "c", "rvol", "stoch_rsi_k"],
            "desc": "atr% >= 0.006 AND rvol >= 2.0 AND stoch_rsi_k >= 90",
            "hit_20bp": 0.909091,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_bb_close_outside_upper_and_trix_0_1_and_vwap_dist_0_02",
            "side": "bear",
            "where": "bb_close_outside_upper = true AND trix >= 0.1 AND vwap_dist_pct >= 0.02",
            "fields": ["bb_close_outside_upper", "c", "trix", "vwap_dist_pct"],
            "desc": "bb_close_outside_upper = true AND trix >= 0.1 AND vwap_dist% >= 0.02",
            "hit_20bp": 0.909091,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_atr_pct_0_006_and_ema_stack_bear_and_tsi_cross_dn",
            "side": "bear",
            "where": "atr_pct >= 0.006 AND ema_stack_bear = true AND tsi_cross_dn = true",
            "fields": ["atr_pct", "c", "ema_stack_bear", "tsi_cross_dn"],
            "desc": "atr% >= 0.006 AND ema_stack_bear = true AND tsi_cross_dn = true",
            "hit_20bp": 0.909091,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_bb_width_0_04_and_bb_close_outside_upper_and_vwap_dist_0_02",
            "side": "bear",
            "where": "bb_width >= 0.04 AND bb_close_outside_upper = true AND vwap_dist_pct >= 0.02",
            "fields": ["bb_close_outside_upper", "bb_width", "c", "vwap_dist_pct"],
            "desc": "bb_width >= 0.04 AND bb_close_outside_upper = true AND vwap_dist% >= 0.02",
            "hit_20bp": 0.906977,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_bb_close_outside_upper_and_stoch_rsi_k_90_and_trix_0_1",
            "side": "bear",
            "where": "bb_close_outside_upper = true AND stoch_rsi_k >= 90 AND trix >= 0.1",
            "fields": ["bb_close_outside_upper", "c", "stoch_rsi_k", "trix"],
            "desc": "bb_close_outside_upper = true AND stoch_rsi_k >= 90 AND trix >= 0.1",
            "hit_20bp": 0.90625,
            "hold": "5-20m",
        },
        {
            "name": "auto_bear_atr_pct_0_006_and_roc_1_and_trix_0_2",
            "side": "bear",
            "where": "atr_pct >= 0.006 AND roc >= 1 AND trix >= 0.2",
            "fields": ["atr_pct", "c", "roc", "trix"],
            "desc": "atr% >= 0.006 AND roc >= 1 AND trix >= 0.2",
            "hit_20bp": 0.905882,
            "hold": "5-20m",
        },
        {
            "name": "auto_bear_atr_pct_0_006_and_trix_0_2",
            "side": "bear",
            "where": "atr_pct >= 0.006 AND trix >= 0.2",
            "fields": ["atr_pct", "c", "trix"],
            "desc": "atr% >= 0.006 AND trix >= 0.2",
            "hit_20bp": 0.902256,
            "hold": "5-20m",
        },
        {
            "name": "auto_bear_atr_pct_0_006_and_keltner_width_0_01_and_trix_0_2",
            "side": "bear",
            "where": "atr_pct >= 0.006 AND keltner_width >= 0.01 AND trix >= 0.2",
            "fields": ["atr_pct", "c", "keltner_width", "trix"],
            "desc": "atr% >= 0.006 AND keltner_width >= 0.01 AND trix >= 0.2",
            "hit_20bp": 0.902256,
            "hold": "5-20m",
        },
        {
            "name": "auto_bear_atr_pct_0_006_and_rvol_2_0_and_cmo_40",
            "side": "bear",
            "where": "atr_pct >= 0.006 AND rvol >= 2.0 AND cmo >= 40",
            "fields": ["atr_pct", "c", "cmo", "rvol"],
            "desc": "atr% >= 0.006 AND rvol >= 2.0 AND cmo >= 40",
            "hit_20bp": 0.9,
            "hold": "3-12m",
        },
        {
            "name": "auto_bear_bb_width_0_03_and_vwap_dist_0_02",
            "side": "bear",
            "where": "bb_width >= 0.03 AND vwap_dist_pct >= 0.02",
            "fields": ["bb_width", "c", "vwap_dist_pct"],
            "desc": "bb_width >= 0.03 AND vwap_dist% >= 0.02",
            "hit_20bp": 1.0,
            "hold": "2-6m",
        },
        {
            "name": "auto_bull_bb_width_0_03_and_stoch_rsi_k_10",
            "side": "bull",
            "where": "bb_width >= 0.03 AND stoch_rsi_k <= 10",
            "fields": ["bb_width", "c", "stoch_rsi_k"],
            "desc": "bb_width >= 0.03 AND stoch_rsi_k <= 10",
            "hit_20bp": 0.962963,
            "hold": "4-12m",
        },
        {
            "name": "auto_bull_atr_pct_0_006_and_vwap_dist_0_01",
            "side": "bull",
            "where": "atr_pct >= 0.006 AND vwap_dist_pct <= -0.01",
            "fields": ["atr_pct", "c", "vwap_dist_pct"],
            "desc": "atr% >= 0.006 AND vwap_dist% <= -0.01",
            "hit_20bp": 1.0,
            "hold": "3-10m",
        },
        {
            "name": "auto_bull_atr_pct_0_006_and_stoch_rsi_k_10",
            "side": "bull",
            "where": "atr_pct >= 0.006 AND stoch_rsi_k <= 10",
            "fields": ["atr_pct", "c", "stoch_rsi_k"],
            "desc": "atr% >= 0.006 AND stoch_rsi_k <= 10",
            "hit_20bp": 0.933333,
            "hold": "3-10m",
        },
        {
            "name": "auto_bull_roc_2_and_stoch_rsi_k_10",
            "side": "bull",
            "where": "roc <= -2 AND stoch_rsi_k <= 10",
            "fields": ["c", "roc", "stoch_rsi_k"],
            "desc": "roc <= -2 AND stoch_rsi_k <= 10",
            "hit_20bp": 0.933333,
            "hold": "3-10m",
        },
        {
            "name": "auto_bull_bb_close_outside_lower_and_roc_2",
            "side": "bull",
            "where": "bb_close_outside_lower = true AND roc <= -2",
            "fields": ["bb_close_outside_lower", "c", "roc"],
            "desc": "bb_close_outside_lower = true AND roc <= -2",
            "hit_20bp": 0.928571,
            "hold": "3-10m",
        },
        {
            "name": "auto_bull_atr_pct_0_003_and_ultimate_osc_30",
            "side": "bull",
            "where": "atr_pct >= 0.003 AND ultimate_osc <= 30",
            "fields": ["atr_pct", "c", "ultimate_osc"],
            "desc": "atr% >= 0.003 AND ultimate_osc <= 30",
            "hit_20bp": 0.956522,
            "hold": "2-6m",
        },
        {
            "name": "auto_bull_keltner_width_0_01_and_vwap_dist_0_02",
            "side": "bull",
            "where": "keltner_width <= 0.01 AND vwap_dist_pct <= -0.02",
            "fields": ["c", "keltner_width", "vwap_dist_pct"],
            "desc": "keltner_width <= 0.01 AND vwap_dist% <= -0.02",
            "hit_20bp": 1.0,
            "hold": "6-20m",
        },
        {
            "name": "auto_bull_atr_pct_0_006_and_rvol_1_5",
            "side": "bull",
            "where": "atr_pct >= 0.006 AND rvol >= 1.5",
            "fields": ["atr_pct", "c", "rvol"],
            "desc": "atr% >= 0.006 AND rvol >= 1.5",
            "hit_20bp": 1.0,
            "hold": "6-20m",
        },
        {
            "name": "auto_bear_mfi_80_and_vwap_dist_0_02",
            "side": "bear",
            "where": "mfi >= 80 AND vwap_dist_pct >= 0.02",
            "fields": ["c", "mfi", "vwap_dist_pct"],
            "desc": "mfi >= 80 AND vwap_dist% >= 0.02",
            "hit_20bp": 0.964912,
            "hold": "5-20m",
        },
        {
            "name": "auto_bull_atr_pct_0_003_and_bb_close_outside_lower",
            "side": "bull",
            "where": "atr_pct >= 0.003 AND bb_close_outside_lower = true",
            "fields": ["atr_pct", "bb_close_outside_lower", "c"],
            "desc": "atr% >= 0.003 AND bb_close_outside_lower = true",
            "hit_20bp": 0.930233,
            "hold": "5-20m",
        },
        {
            "name": "auto_bull_atr_pct_0_006_and_stoch_rsi_k_20",
            "side": "bull",
            "where": "atr_pct >= 0.006 AND stoch_rsi_k <= 20",
            "fields": ["atr_pct", "c", "stoch_rsi_k"],
            "desc": "atr% >= 0.006 AND stoch_rsi_k <= 20",
            "hit_20bp": 0.92,
            "hold": "5-20m",
        },
        {
            "name": "auto_bull_rvol_2_0_and_chop_60",
            "side": "bull",
            "where": "rvol >= 2.0 AND chop >= 60",
            "fields": ["c", "chop", "rvol"],
            "desc": "rvol >= 2.0 AND chop >= 60",
            "hit_20bp": 0.909091,
            "hold": "5-20m",
        },
        {
            "name": "auto_bear_cmo_40_and_vwap_dist_0_02",
            "side": "bear",
            "where": "cmo >= 40 AND vwap_dist_pct >= 0.02",
            "fields": ["c", "cmo", "vwap_dist_pct"],
            "desc": "cmo >= 40 AND vwap_dist% >= 0.02",
            "hit_20bp": 0.903614,
            "hold": "5-20m",
        },
        {
            "name": "auto_bear_stoch_rsi_k_90_and_vwap_dist_0_02",
            "side": "bear",
            "where": "stoch_rsi_k >= 90 AND vwap_dist_pct >= 0.02",
            "fields": ["c", "stoch_rsi_k", "vwap_dist_pct"],
            "desc": "stoch_rsi_k >= 90 AND vwap_dist% >= 0.02",
            "hit_20bp": 0.902778,
            "hold": "5-20m",
        },
        {
            "name": "auto_bear_roc_1_and_trix_0_2_and_vwap_dist_0_02",
            "side": "bear",
            "where": "roc >= 1 AND trix >= 0.2 AND vwap_dist_pct >= 0.02",
            "fields": ["c", "roc", "trix", "vwap_dist_pct"],
            "desc": "roc >= 1 AND trix >= 0.2 AND vwap_dist% >= 0.02",
            "hit_20bp": 0.9,
            "hold": "3-12m",
        },
    ]

    if INCLUDE_BASE_RULES:
        rules_raw = [
            {
                "name": "Base RSI/TD + MACD Bull",
                "side": "bull",
                "where": f"rsi <= {RSI_OVERSOLD:g} AND td_buy_count >= {TD_COUNT_MIN} AND macd_line > macd_signal",
                "fields": ["c", "rsi", "td_buy_count", "macd_line", "macd_signal"],
                "desc": "RSI oversold + TD buy count + MACD line above signal",
                "hit_20bp": None,
                "hold": "1-10m",
            },
            {
                "name": "Base RSI/TD + MACD Cross Up",
                "side": "bull",
                "where": f"rsi <= {RSI_OVERSOLD:g} AND td_buy_count >= {TD_COUNT_MIN} AND macd_cross_up = true",
                "fields": ["c", "rsi", "td_buy_count", "macd_cross_up", "close_vwap_diff_pct"],
                "desc": "RSI oversold + TD buy count + MACD cross up",
                "hit_20bp": None,
                "hold": "1-10m",
            },
            {
                "name": "Base RSI/TD + MACD Bear",
                "side": "bear",
                "where": f"rsi >= {RSI_OVERBOUGHT:g} AND td_sell_count >= {TD_COUNT_MIN} AND macd_line < macd_signal",
                "fields": ["c", "rsi", "td_sell_count", "macd_line", "macd_signal"],
                "desc": "RSI overbought + TD sell count + MACD line below signal",
                "hit_20bp": None,
                "hold": "1-10m",
            },
            {
                "name": "Base RSI/TD + MACD Cross Down",
                "side": "bear",
                "where": f"rsi >= {RSI_OVERBOUGHT:g} AND td_sell_count >= {TD_COUNT_MIN} AND macd_cross_dn = true",
                "fields": ["c", "rsi", "td_sell_count", "macd_cross_dn", "close_vwap_diff_pct"],
                "desc": "RSI overbought + TD sell count + MACD cross down",
                "hit_20bp": None,
                "hold": "1-10m",
            },
        ] + rules_raw

    rules: List[FeedRule] = []
    seen_keys: set[str] = set()
    for rule in rules_raw:
        where = rule["where"]
        if IGNORE_TOD:
            where = _strip_tod_expr(where)
        if not where.strip():
            continue
        key = f"{timespan}|{rule['side']}|{_normalize_where_key(where)}"
        if key in seen_keys:
            continue
        seen_keys.add(key)
        try:
            compiled = (compile_condition(where),)
        except Exception:
            continue
        hold = rule.get("hold")
        hold_cat = None
        if hold:
            _min_h, _max_h = _parse_hold_window(hold)
            hold_cat = _hold_category(float(_max_h))
        rules.append(
            FeedRule(
                name=f"div_{rule['side']}_{timespan}_{rule['name']}",
                side=rule["side"],
                timespan=timespan,
                conditions=compiled,
                raw_conditions=(where,),
                fields=tuple(rule["fields"]),
                description=rule["desc"],
                hit_20bp=rule.get("hit_20bp"),
                hold=hold,
                hold_category=hold_cat,
            )
        )
    return rules


def _build_embed(
    rule: FeedRule,
    row: Dict[str, Any],
    ts_utc: pd.Timestamp,
    chart: str = "",
    chart_range: str = "",
) -> DiscordEmbed:
    side = rule.side.lower()
    color = "2ecc71" if side == "bull" else "e74c3c"
    ts_et = ts_utc.tz_convert("America/New_York")

    title = f"CA {side.upper()} {rule.timespan}: {rule.name}"
    desc = f"{row.get('ticker')} @ {ts_et.strftime('%Y-%m-%d %H:%M ET')}"

    embed = DiscordEmbed(title=title, description=desc, color=color)
    embed.set_timestamp()

    embed.add_embed_field(name="Setup", value=rule.description, inline=False)

    stats_parts = []
    if rule.hit_20bp is not None:
        stats_parts.append(f"Hit 20bp: {rule.hit_20bp:.1%}")
    if rule.hold:
        stats_parts.append(f"Hold: {rule.hold}")
    if rule.hold_category:
        stats_parts.append(f"Hold cat: {rule.hold_category}")
    if rule.avg_best_move is not None:
        stats_parts.append(f"Avg move: {rule.avg_best_move:.2%}")
    if rule.p15_best_move is not None:
        stats_parts.append(f"P15 move: {rule.p15_best_move:.2%}")
    if rule.n_val is not None:
        stats_parts.append(f"n={rule.n_val}")
    if rule.tickers_val is not None:
        stats_parts.append(f"tickers={rule.tickers_val}")
    if stats_parts:
        embed.add_embed_field(name="Stats", value=" | ".join(stats_parts), inline=False)

    if rule.raw_conditions:
        cond_preview = " and ".join(rule.raw_conditions)[:900]
        embed.add_embed_field(name="Conditions", value=cond_preview, inline=False)

    if rule.fields:
        metrics = _format_metrics(row, rule.fields)
        embed.add_embed_field(name="Now", value=metrics, inline=False)

    if chart:
        chart_block = f"```text\n{chart}\n```"
        if chart_range:
            chart_block = f"{chart_range}\n{chart_block}"
        embed.add_embed_field(name="Chart", value=chart_block, inline=False)

    embed.set_footer(text="CA unified feed")
    return embed


async def main() -> None:
    db = PolygonOptions()
    await db.connect()

    table_name = SOURCE_TABLE.split(".")[-1]
    columns = {c.lower() for c in (await db.get_table_columns(table_name))}
    missing_core = [c for c in ("ticker", "timespan") if c not in columns]
    if missing_core:
        raise RuntimeError(f"{SOURCE_TABLE} missing required columns: {missing_core}")

    rules: List[FeedRule] = []
    if INCLUDE_DIVERSE_RULES:
        diverse_spans = TIMESPANS if INCLUDE_DIVERSE_ALL_TIMESPANS else [TIMESPAN]
        for span in diverse_spans:
            rules.extend(_load_diverse_rules(span))
    rules.extend(
        _load_candidate_rules(
            _candidate_paths(),
            allowed_timespans=TIMESPANS,
            default_timespan=TIMESPAN,
        )
    )
    if not rules:
        raise SystemExit("no rules loaded (check candidates CSV / filters)")

    filtered: List[FeedRule] = []
    dropped: List[str] = []
    for rule in rules:
        missing = _rule_missing_columns(rule, columns)
        if missing:
            dropped.append(f"{rule.name} -> {missing}")
            continue
        filtered.append(rule)

    if dropped:
        preview = "\n".join(dropped[:10])
        print(f"[WARN] dropped {len(dropped)} rules due to missing columns (showing 10):\n{preview}")
    rules = _dedupe_rules(filtered)
    if not rules:
        raise SystemExit("no rules remaining after column validation")

    rules_by_name = {rule.name: rule for rule in rules}
    rules_by_timespan: Dict[str, List[FeedRule]] = {}
    for rule in rules:
        span = (rule.timespan or "").strip().lower()
        rules_by_timespan.setdefault(span, []).append(rule)

    print(
        "[unified] rules=%s source=%s timespans=%s lookback_min=%s lookback_bars=%s min_hits=%s",
        len(rules),
        SOURCE_TABLE,
        ",".join(TIMESPANS),
        LOOKBACK_MINUTES,
        LOOKBACK_BARS,
        MIN_HITS,
    )

    last_sent: Dict[Tuple[str, str, str], int] = {}
    pending_results = _load_results_state() if TRACK_RESULTS else []
    pending_keys = {_result_key(item) for item in pending_results}

    while True:

        await touch_feed_heartbeat(db, "ca_unified_feeds", __file__)
        now_epoch = int(pd.Timestamp.now(tz="UTC").timestamp())
        rows: List[dict] = []
        for span in TIMESPANS:
            start_ts = now_epoch - _lookback_seconds(span)
            rows.extend(
                await _fetch_recent_rows(
                    db,
                    table=SOURCE_TABLE,
                    timespan=span,
                    start_ts=start_ts,
                    max_rows_per_ticker=LOOKBACK_BARS,
                )
            )
        if not rows:
            await asyncio.sleep(POLL_SECONDS)
            continue

        rows_by_key: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
        for raw in rows:
            row = dict(raw)
            if "vwap_dist_pct" not in row and "close_vwap_diff_pct" in row:
                row["vwap_dist_pct"] = row.get("close_vwap_diff_pct")
            if not IGNORE_TOD:
                _apply_tod_flags(row)
            ticker = str(row.get("ticker", "")).strip()
            timespan = str(row.get("timespan", "")).strip().lower() or TIMESPAN
            if not ticker:
                continue
            if timespan and timespan not in rules_by_timespan:
                continue
            rows_by_key.setdefault((ticker, timespan), []).append(row)

        for (ticker, timespan), trows in rows_by_key.items():
            rules_for_span = rules_by_timespan.get(timespan, [])
            if not rules_for_span:
                continue
            trows_sorted = sorted(trows, key=lambda r: _row_ts_epoch(r) or 0)
            if len(trows_sorted) < MIN_BARS_PER_TICKER:
                continue

            latest_row = trows_sorted[-1]
            ts_epoch = _row_ts_epoch(latest_row)
            if not ts_epoch:
                continue
            if now_epoch - ts_epoch > MAX_STALENESS_MINUTES * 60:
                continue

            ts_utc = _row_ts_utc(latest_row)
            if ts_utc is None:
                continue

            lookback_rows = trows_sorted[-LOOKBACK_BARS:] if LOOKBACK_BARS > 0 else trows_sorted
            chart = ""
            chart_range = ""
            if SHOW_CHART:
                closes = []
                for row in lookback_rows[-CHART_POINTS:] if CHART_POINTS > 0 else lookback_rows:
                    close_val = _coerce_float(row.get("c"))
                    if close_val is not None:
                        closes.append(close_val)
                chart = _ascii_sparkline(closes, CHART_POINTS)
                if closes:
                    chart_range = f"Range: {min(closes):.4f} - {max(closes):.4f} | Last: {closes[-1]:.4f}"

            matched_rules = []
            min_hits = MIN_HITS_QUICK if (timespan in QUICK_TIMESPANS and MIN_HITS_QUICK > 0) else MIN_HITS
            for rule in rules_for_span:
                latest_hit = _rule_hit(rule, latest_row)
                if REQUIRE_LATEST and not latest_hit:
                    continue
                if min_hits <= 1:
                    if latest_hit or not REQUIRE_LATEST:
                        matched_rules.append(rule)
                    continue
                hit_count = 1 if latest_hit else 0
                if hit_count < min_hits:
                    for row in lookback_rows[:-1]:
                        if _rule_hit(rule, row):
                            hit_count += 1
                            if hit_count >= min_hits:
                                break
                if hit_count >= min_hits:
                    matched_rules.append(rule)

            if not matched_rules:
                continue

            bull_hits = [r for r in matched_rules if r.side == "bull"]
            bear_hits = [r for r in matched_rules if r.side == "bear"]
            if bull_hits and bear_hits:
                bull_score = max(_rule_score(r) for r in bull_hits)
                bear_score = max(_rule_score(r) for r in bear_hits)
                if bull_score == bear_score:
                    continue
                matched_rules = bull_hits if bull_score > bear_score else bear_hits

            matched_rules.sort(
                key=lambda r: (_rule_score(r), r.n_val or 0),
                reverse=True,
            )
            if MAX_RULES_PER_TICKER > 0:
                matched_rules = matched_rules[:MAX_RULES_PER_TICKER]

            for rule in matched_rules:
                key = (rule.name, ticker, timespan)
                last_ts = last_sent.get(key)
                if last_ts is not None:
                    if ts_epoch <= last_ts:
                        continue
                    if ts_epoch - last_ts < COOLDOWN_MINUTES * 60:
                        continue
                last_sent[key] = ts_epoch

                hook_url = _select_hook(rule)
                if not hook_url:
                    continue

                embed = _build_embed(rule, latest_row, ts_utc, chart=chart, chart_range=chart_range)
                webhook = AsyncDiscordWebhook(url=hook_url)
                webhook.add_embed(embed)
                await webhook.execute()

                if TRACK_RESULTS and RESULTS_HOOK_URL:
                    window_min, window_max = _parse_hold_window(rule.hold)
                    entry_price = _coerce_float(latest_row.get("c"))
                    if entry_price:
                        item = {
                            "rule": rule.name,
                            "side": rule.side,
                            "ticker": ticker,
                            "timespan": timespan,
                            "entry_ts": ts_epoch,
                            "entry_price": entry_price,
                            "window_min": window_min,
                            "window_max": window_max,
                        }
                        item_key = _result_key(item)
                        if item_key not in pending_keys:
                            pending_keys.add(item_key)
                            pending_results.append(item)

        if TRACK_RESULTS and RESULTS_HOOK_URL and pending_results:
            remaining: List[dict] = []
            for item in pending_results:
                entry_ts = int(item.get("entry_ts") or 0)
                window_max = int(item.get("window_max") or RESULT_WINDOW_MAX)
                if not entry_ts:
                    continue
                if now_epoch < entry_ts + window_max * 60:
                    remaining.append(item)
                    continue

                rows_out = await _fetch_outcome_rows(
                    db,
                    table=SOURCE_TABLE,
                    timespan=str(item.get("timespan") or TIMESPAN),
                    ticker=str(item.get("ticker")),
                    start_ts=entry_ts,
                    end_ts=entry_ts + window_max * 60,
                )
                if not rows_out:
                    remaining.append(item)
                    continue

                entry_price = float(item.get("entry_price"))
                outcome = _compute_outcome(
                    rows_out,
                    side=str(item.get("side")),
                    entry_price=entry_price,
                )
                if outcome is None:
                    remaining.append(item)
                    continue

                rule = rules_by_name.get(item.get("rule"))
                if not rule:
                    continue

                entry_ts_utc = pd.to_datetime(entry_ts, unit="s", utc=True)
                embed = _build_results_embed(
                    rule,
                    ticker=str(item.get("ticker")),
                    side=str(item.get("side")),
                    entry_ts=entry_ts_utc,
                    entry_price=entry_price,
                    window_min=int(item.get("window_min") or RESULT_WINDOW_MIN),
                    window_max=window_max,
                    outcome=outcome,
                )
                webhook = AsyncDiscordWebhook(url=RESULTS_HOOK_URL)
                webhook.add_embed(embed)
                await webhook.execute()

            pending_results = remaining
            pending_keys = {_result_key(item) for item in pending_results}
            _save_results_state(pending_results)

        await asyncio.sleep(POLL_SECONDS)


if __name__ == "__main__":
    asyncio.run(main())
