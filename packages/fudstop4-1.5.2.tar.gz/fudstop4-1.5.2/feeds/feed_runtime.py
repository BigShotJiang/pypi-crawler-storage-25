from __future__ import annotations

import json
import os
import time
from typing import Any, Iterable

import pandas as pd


HEARTBEAT_INTERVAL_SECONDS = int(os.getenv("FEED_HEARTBEAT_INTERVAL_SECONDS", "30"))
_LAST_HEARTBEAT_BY_FEED: dict[str, float] = {}


def _coerce_str(value: Any) -> str:
    return "" if value is None else str(value)


def _coerce_int(value: Any) -> int:
    try:
        return int(float(str(value)))
    except Exception:
        return 0


def _serialize_details(value: Any) -> str:
    if isinstance(value, str):
        text = value.strip()
        return text if text else "{}"
    if isinstance(value, dict):
        try:
            return json.dumps(value, ensure_ascii=True, sort_keys=True, default=str)
        except Exception:
            return "{}"
    if value is None:
        return "{}"
    try:
        return json.dumps(value, ensure_ascii=True, default=str)
    except Exception:
        return "{}"


def _eastern_now_naive():
    return pd.Timestamp.now(tz="America/New_York").tz_localize(None).to_pydatetime()


class FeedSignals:
    def __init__(self, data: Iterable[dict]):
        rows = list(data)

        self.feed_name = [_coerce_str(i.get("feed_name")) for i in rows]
        self.ticker = [_coerce_str(i.get("ticker")).upper() for i in rows]
        self.details = [_serialize_details(i.get("details")) for i in rows]
        self.last_seen = [
            i.get("last_seen") if i.get("last_seen") is not None else _eastern_now_naive()
            for i in rows
        ]

        self.data_dict = {
            "feed_name": self.feed_name,
            "ticker": self.ticker,
            "details": self.details,
            "last_seen": self.last_seen,
        }

        self.as_dataframe = pd.DataFrame(self.data_dict)


class FeedRuntimeStatus:
    def __init__(self, data: Iterable[dict]):
        rows = list(data)

        self.feed_name = [_coerce_str(i.get("feed_name")) for i in rows]
        self.script_path = [_coerce_str(i.get("script_path")) for i in rows]
        self.status = [_coerce_str(i.get("status")) or "running" for i in rows]
        self.pid = [_coerce_int(i.get("pid")) for i in rows]
        self.loop_count = [_coerce_int(i.get("loop_count")) for i in rows]
        self.message = [_coerce_str(i.get("message")) for i in rows]
        self.last_heartbeat = [
            i.get("last_heartbeat") if i.get("last_heartbeat") is not None else _eastern_now_naive()
            for i in rows
        ]

        self.data_dict = {
            "feed_name": self.feed_name,
            "script_path": self.script_path,
            "status": self.status,
            "pid": self.pid,
            "loop_count": self.loop_count,
            "message": self.message,
            "last_heartbeat": self.last_heartbeat,
        }

        self.as_dataframe = pd.DataFrame(self.data_dict)


async def record_feed_signal(db, feed_name: str, ticker: str, details: dict | str | None, last_seen=None) -> None:
    if db is None:
        return
    model = FeedSignals(
        [
            {
                "feed_name": feed_name,
                "ticker": ticker,
                "details": details or {},
                "last_seen": last_seen if last_seen is not None else _eastern_now_naive(),
            }
        ]
    )
    await db.batch_upsert_dataframe(
        model.as_dataframe,
        table_name="feed_signals",
        unique_columns=["feed_name", "ticker"],
    )


async def touch_feed_heartbeat(
    db,
    feed_name: str,
    script_path: str,
    *,
    status: str = "running",
    loop_count: int = 0,
    message: str = "",
) -> None:
    if db is None:
        return
    now_monotonic = time.monotonic()
    last_monotonic = _LAST_HEARTBEAT_BY_FEED.get(feed_name, 0.0)
    if HEARTBEAT_INTERVAL_SECONDS > 0 and now_monotonic - last_monotonic < HEARTBEAT_INTERVAL_SECONDS:
        return
    _LAST_HEARTBEAT_BY_FEED[feed_name] = now_monotonic
    model = FeedRuntimeStatus(
        [
            {
                "feed_name": feed_name,
                "script_path": script_path,
                "status": status,
                "pid": os.getpid(),
                "loop_count": loop_count,
                "message": message,
                "last_heartbeat": _eastern_now_naive(),
            }
        ]
    )
    await db.batch_upsert_dataframe(
        model.as_dataframe,
        table_name="feed_runtime_status",
        unique_columns=["feed_name"],
    )
