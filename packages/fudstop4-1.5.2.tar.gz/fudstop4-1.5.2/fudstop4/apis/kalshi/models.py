import pandas as pd





class Events:
    def __init__(self, data):

        self.series_ticker = [i.get('series_ticker') for i in data]
        self.series_title = [i.get('series_title') for i in data]
        self.event_ticker = [i.get('event_ticker') for i in data]
        self.event_subtitle = [i.get('event_subtitle') for i in data]
        self.event_title = [i.get('event_title') for i in data]
        self.category = [i.get('category') for i in data]
        
        self.total_series_volume = [i.get('total_series_volume') for i in data]
        self.total_volume = [i.get('total_volume') for i in data]
        self.total_market_count = [i.get('total_market_count') for i in data]
        self.active_market_count = [i.get('active_market_count') for i in data]
        self.is_trending = [i.get('is_trending') for i in data]
        self.is_new = [i.get('is_new') for i in data]
        self.is_closing = [i.get('is_closing') for i in data]
        self.is_price_delta = [i.get('is_price_delta') for i in data]
        self.search_score = [i.get('search_score') for i in data]
        self.fee_type = [i.get('fee_type') for i in data]
        self.fee_multiplier = [i.get('fee_multiplier') for i in data]
        product_metadata = [i.get('product_metadata') for i in data]
        self.categories = [','.join(i.get('categories')) for i in product_metadata]
    
        self.promoted_milestone_id = [i.get('promoted_milestone_id') for i in product_metadata]
        self.scope = [i.get('scope') for i in product_metadata]
        self.structured_icon = [i.get('structured_icon') for i in product_metadata]
        self.subcategories = [','.join(i.get('subcategories')) for i in product_metadata]
   


        self.data_dict = { 
            'ticker': self.series_ticker,
            'title': self.series_title,
            'event_ticker': self.event_ticker,
            'event_title': self.event_title,
            'event_subtitle': self.event_subtitle,
            'category': self.category,
            'total_volume': self.total_volume,
            'total_series_volume': self.total_series_volume,
            'total_market_count': self.total_market_count,
            'active_market_count': self.active_market_count,
            'is_trending': self.is_trending,
            'is_new': self.is_new,
            'is_closing': self.is_closing,
            'is_price_delta': self.is_price_delta,
            'search_score': self.search_score,
            'fee_type': self.fee_type,
            'fee_multiplier': self.fee_multiplier,
            'categories': self.categories,
            'sub_categories': self.subcategories


        }
        
        self.df = pd.DataFrame(self.data_dict)

class Markets:
    def __init__(self):

        pass