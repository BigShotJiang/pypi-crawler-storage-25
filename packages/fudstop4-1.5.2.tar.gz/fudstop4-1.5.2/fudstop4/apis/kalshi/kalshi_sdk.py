import asyncio
import pandas as pd
import aiohttp
from fudstop4.apis.polygonio.polygon_options import PolygonOptions
from .models import Events


db = PolygonOptions()




class KalshiSDK:
    def __init__(self):
        self.category_politics = 'Politics'
        self.category_international = 'International'
        self.headers = { 
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
            'x-csrf-token': 'p9rspy0ox3t1pV+3GnYAF2/pWsrxX6QJ50J1e/c5Zlk=',
            'cookie': '_gcl_gs=2.1.k1$i1769326233$u187610674; _gcl_au=1.1.863647201.1769326236; _fbp=fb.1.1769326235911.84050400582422749.AQYBAQIA; rskxRunCookie=0; rCookie=igrk5okmuhrm02tpm2h6mktf5p1t; _ga=GA1.1.1505093316.1769326236; _axwrt=1052aaeb-5bd0-4277-83ff-fbfb3cb7b86d; _tt_enable_cookie=1; _ttp=01KFT0ZMMP89WW2QD1TJJ2P1WS_.tt.1; __stripe_mid=01dd2653-1995-417b-aac8-3f3e1bb0b527e122ca; __ps_r=https://www.google.com/; __ps_lu=https://kalshi.com/?utm_source=google&utm_medium=cpc&utm_source=google&utm_medium=cpc&utm_campaign=23282953640&utm_term=prediction%20markets&utm_content=190414122153&gad_source=1&gad_campaignid=23282953640&gbraid=0AAAAABLs-QWismeABbwdUEKA1yKJEY-bl&gclid=Cj0KCQiA-NHLBhDSARIsAIhe9X2KHqshHmqw_0R23BBOjJw8ahzdx59wYG_PaagstvYRD56N5a0eyJkaAmZKEALw_wcB; __ps_did=pscrb_9a055838-748e-4a9b-a55e-705fbd9ded1d; __ps_fva=1769326238904; _gcl_aw=GCL.1769326250.Cj0KCQiA-NHLBhDSARIsAIhe9X2KHqshHmqw_0R23BBOjJw8ahzdx59wYG_PaagstvYRD56N5a0eyJkaAmZKEALw_wcB; _s_did=eyJraWQiOiJmMzRiN2YiLCJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJkaWQiOiIyZjc3ZDJkMS1lYTlhLTQyOTgtYTUzMS01NGQyZDUyZTM1MTcifQ.0Y-dHFHTKCZ60j0Rd-47SpUcmeWbhCfkweoza4bneW1mFdCmO0NRpJYJMRaMc1xBbV7g2L8eb-S0WVbUGbgQgg; AMP_MKTG_f06cc669b6=JTdCJTdE; sessions=6641ee97-f4cd-44ed-84b7-4ac8209478a2%3Axc7c2IlyYiKMjqoHLV0ocVRqFyZgU0JhLNNd0mWEME3khTyigzhyh7fCfOVdkyPP; userId=6641ee97-f4cd-44ed-84b7-4ac8209478a2; __ps_sr=_; __ps_slu=https://kalshi.com/; ax_visitor=%7B%22firstVisitTs%22%3A1769326248113%2C%22lastVisitTs%22%3A1769601744265%2C%22currentVisitStartTs%22%3A1769631103048%2C%22ts%22%3A1769631639663%2C%22visitCount%22%3A11%7D; lastRskxRun=1769631640385; _rdt_uuid=1769326236057.582aec5f-244e-4242-9146-256a3c2d672b; _ga_R10JTCKS4W=GS2.1.s1769631090$o14$g1$t1769631640$j59$l0$h0; ttcsid=1769631090741::D_VN2LGmfWoITJOrhIdR.10.1769631640877.0; ttcsid_CS8O933C77UC3ENMLB3G=1769631090741::Uc_Z0l_heEdgXhcf8gqP.8.1769631640877.1; AMP_f06cc669b6=JTdCJTIyZGV2aWNlSWQlMjIlM0ElMjI4ZDQ1MzIzYy0xNGI3LTQ2MWItYjRmZC00NTVjYTc0N2YyYjclMjIlMkMlMjJzZXNzaW9uSWQlMjIlM0ExNzY5NjMxMDkwNTUxJTJDJTIyb3B0T3V0JTIyJTNBZmFsc2UlMkMlMjJsYXN0RXZlbnRUaW1lJTIyJTNBMTc2OTYzMTY0MDk1NCUyQyUyMmxhc3RFdmVudElkJTIyJTNBMjcwJTJDJTIycGFnZUNvdW50ZXIlMjIlM0EzJTdE'
        }
        self.user_id = '6641ee97-f4cd-44ed-84b7-4ac8209478a2'



    async def http_get(self, url, params=None, headers=None):
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params, headers=headers) as resp:
                resp.raise_for_status()
                return await resp.json()


    async def get_all_events(self, page_size: int = 20, category: str = "Politics"):
        await db.connect()
        url = "https://api.elections.kalshi.com/v1/search/series"

        all_dfs = []
        cursor = None

        while True:
            params = {
                "order_by": "trending",
                "status": "open",
                "page_size": page_size,
                "category": category,
                "with_milestones": "true",
            }

            if cursor:
                params["cursor"] = cursor

            data = await self.http_get(url, params=params)

            page = Events(data.get("current_page"))
            all_dfs.append(page.df)

            cursor = data.get("next_cursor")
            if not cursor:
                break

        final_df = pd.concat(all_dfs, ignore_index=True)
        await db.batch_upsert_dataframe(final_df, table_name='event_markets', unique_columns=['event_ticker'])
        return final_df
    

    async def get_orderbook(self, title):
        await db.connect()


        query = f"""SELECT event_ticker from event_markets where title ILIKE '%{title}%' limit 1"""


        results = await db.fetch(query)

        results = [i.get('ticker') for i in results]

        ticker =  results[0]

        url = f"https://api.elections.kalshi.com/v1/markets/order_books?market_tickers={ticker}"


        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                data = await resp.json()


                order_books = data.get('order_books')

                for i in order_books:
                    print(i)
    
    async def get_tags(self):

        url = f"https://api.elections.kalshi.com/v1/search/tags_by_categories"

        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                data = await resp.json()
                tags = (data or {}).get("tags_by_categories") or {}

                rows = [
                    {"category": category, "tag": tag}
                    for category, tag_list in tags.items()
                    for tag in (tag_list or [])
                ]

                df = pd.DataFrame(rows)

          
                return df
            
    async def event_positions(self, user_id=None, limit:str='15', status:str='close'):
        if not user_id:
            user_id = self.user_id

        url = f"https://api.elections.kalshi.com/v1/users/{user_id}/event_positions?limit={limit}&position_status={status}&settlement_status=settled"
        print(url)
        async with aiohttp.ClientSession() as session:

            async with session.get(url, headers=self.headers) as resp:
                data = await resp.json()
                event_positions = data.get('event_positions')


                self.event_ticker = [i.get('event_ticker') for i in event_positions]
                self.last_updated_ts = [i.get('last_updated_ts') for i in event_positions]
                self.market_positions = [i.get('market_positions') for i in event_positions][0]
                self.collateral_returned_cents = [i.get('collateral_returned_cents') for i in event_positions]

                self.market_id = [i.get('market_id') for i in self.market_positions]
                self.market_ticker = [i.get('market_ticker') for i in self.market_positions]
                self.position = [i.get('position') for i in self.market_positions]
                self.position_cost = [i.get('position_cost') for i in self.market_positions]
                self.total_cost = [i.get('total_cost') for i in self.market_positions]
                self.buying_cost = [i.get('buying_cost') for i in self.market_positions]
                self.realized_pnl = [i.get('realized_pnl') for i in self.market_positions]
                self.fees_paid = [i.get('fees_paid') for i in self.market_positions]
                self.volume = [i.get('volume') for i in self.market_positions]
                self.final_position = [i.get('final_position') for i in self.market_positions]
                self.final_position_cost = [i.get('final_position_cost') for i in self.market_positions]
                self.is_settled = [i.get('is_settled') for i in self.market_positions]
                self.last_position = [i.get('last_position') for i in self.market_positions]
                self.is_closed = [i.get('is_closed') for i in self.market_positions]
                self.last_updated_ts = [i.get('last_updated_ts') for i in self.market_positions]
                self.position_cost_dollars = [i.get('position_cost_dollars') for i in self.market_positions]
                self.total_cost_dollars = [i.get('total_cost_dollars') for i in self.market_positions]
                self.buying_cost_dollars = [i.get('buying_cost_dollars') for i in self.market_positions]
                self.realized_pnl_dollars = [i.get('realized_pnl_dollars') for i in self.market_positions]
                self.fees_paid_dollars = [i.get('fees_paid_dollars') for i in self.market_positions]
                self.yes_buying_fee_cost_dollars = [i.get('yes_buying_fee_cost_dollars') for i in self.market_positions]
                self.no_buying_fee_cost_dollars = [i.get('no_buying_fee_cost_dollars') for i in self.market_positions]
                self.position_fee_cost_dollars = [i.get('position_fee_cost_dollars') for i in self.market_positions]
                self.final_position_cost_dollars = [i.get('final_position_cost_dollars') for i in self.market_positions]
                self.final_position_fee_cost_dollars = [i.get('final_position_fee_cost_dollars') for i in self.market_positions]
                self.resting_orders_count = [i.get('resting_orders_count') for i in self.market_positions]
                self.is_determined = [i.get('is_determined') for i in self.market_positions]
                self.determination_profits = [i.get('determination_profits') for i in self.market_positions]
                self.data_dict = {  
                    'event_ticker': self.event_ticker,
                    'last_updated_ts': self.last_updated_ts,
                    'market_id': self.market_id,
                    'market_ticker': self.market_ticker,
                    'position': self.position,
                    'position_cost': self.position_cost,
                    'total_cost': self.total_cost,
                    'buying_cost': self.buying_cost,
                    'realized_pnl': self.realized_pnl,
                    'fees_paid': self.fees_paid,
                    'volume': self.volume,
                    'final_position': self.final_position,
                    'final_position_cost': self.final_position_cost,
                    'is_settled': self.is_settled,
                    'last_position': self.last_position,
                    'is_closed': self.is_closed,
                    'last_updated_ts': self.last_updated_ts,
                    'position_cost_dollars': self.position_cost_dollars,
                    'total_cost_dollars': self.total_cost_dollars,
                    'buying_cost_dollars': self.buying_cost_dollars,
                    'realized_pnl_dollars': self.realized_pnl_dollars,
                    'fees_paid_dollars': self.fees_paid_dollars,
                    'yes_buying_fee_cost_dollars': self.yes_buying_fee_cost_dollars,
                    'no_buying_fee_cost_dollars': self.no_buying_fee_cost_dollars,
                    'position_fee_cost_dollars': self.position_fee_cost_dollars,
                    'final_position_cost_dollars': self.final_position_cost_dollars,
                    'final_position_fee_cost_dollars': self.final_position_fee_cost_dollars,
                    'resting_orders_count': self.resting_orders_count,
                    'is_determined': self.is_determined,
                    'determination_profits': self.determination_profits

                }


                self.df = pd.DataFrame(self.data_dict)

                return self.df
            

    async def place_order(self, user_id, count, side, price_dollars, max_cost_cents, market_id, order_action, user_side, order_type):

        if not user_id:
            user_id = self.user_id

        url = f"https://api.elections.kalshi.com/v1/users/{user_id}/orders"
        payload = {"count":count,"side":side,"price_dollars":price_dollars,"expiration_unix_ts":0,"time_in_force":"immediate_or_cancel","max_cost_cents":max_cost_cents,"sell_position_capped":False,"market_id":market_id,"order_action":order_action,"user_side":user_side,"order_type":order_type,"post_only":False}
        async with aiohttp.ClientSession(headers=self.headers) as session:
            async with session.post(url, json = payload) as resp:
                data = await resp.json()
                print("SUCCESS")
                return data
            
    
    async def get_markets(self):
        await db.connect()
        url = f"https://api.elections.kalshi.com/v1/events/?series_tickers=&single_event_per_series=true&tickers="

        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:

                data = await resp.json()
                events = data['events']
                ticker = [i.get('ticker') for i in events]
                series_ticker = [i.get('series_ticker') for i in events]
                target_datetime = [i.get('target_datetime') for i in events]
                mutually_exclusive = [i.get('mutually_exclusive') for i in events]
                collateral_return_type = [i.get('collateral_return_type') for i in events]
                event_title = [i.get('title') for i in events]
                category = [i.get('category') for i in events]
                tags = [i.get('tags') for i in events]
                keywords = [i.get('keywords') for i in events]
                min_tick_size = [i.get('min_tick_size') for i in events]
                settle_details = [i.get('settle_details') for i in events]
                description_context = [i.get('description_context') for i in events]
                underlying = [i.get('underlying') for i in events]
                metrics_tags = [i.get('metrics_tags') for i in events]
                event_mini_title = [i.get('mini_title') for i in events]
                event_sub_title = [i.get('sub_title') for i in events]
                max_close_ts = [i.get('max_close_ts') for i in events]


                markets = [i.get('markets') for i in events]
                markets = [item for sublist in markets for item in sublist]
                id = [i.get('id') for i in markets]
                ticker_name = [i.get('ticker_name') for i in markets]
                create_date = [i.get('create_date') for i in markets]
                list_date = [i.get('list_date') for i in markets]
                open_date = [i.get('open_date') for i in markets]
                close_date = [i.get('close_date') for i in markets]
                expiration_date = [i.get('expiration_date') for i in markets]
                settlement_timer_seconds = [i.get('settlement_timer_seconds') for i in markets]
                status = [i.get('status') for i in markets]
                expiration_value = [i.get('expiration_value') for i in markets]
                settlement_value_centicents = [i.get('settlement_value_centicents') for i in markets]
                result = [i.get('result') for i in markets]
                yes_bid = [i.get('yes_bid') for i in markets]
                yes_ask = [i.get('yes_ask') for i in markets]
                last_price = [i.get('last_price') for i in markets]
                prev_period_price = [i.get('prev_period_price') for i in markets]
                previous_hour_price = [i.get('previous_hour_price') for i in markets]
                previous_day_price = [i.get('previous_day_price') for i in markets]
                previous_week_price = [i.get('previous_week_price') for i in markets]
                yes_bid_dollars = [i.get('yes_bid_dollars') for i in markets]
                yes_ask_dollars = [i.get('yes_ask_dollars') for i in markets]
                last_price_dollars = [i.get('last_price_dollars') for i in markets]
                prev_period_price_dollars = [i.get('prev_period_price_dollars') for i in markets]
                previous_hour_price_dollars = [i.get('previous_hour_price_dollars') for i in markets]
                previous_day_price_dollars = [i.get('previous_day_price_dollars') for i in markets]
                previous_week_price_dollars = [i.get('previous_week_price_dollars') for i in markets]
                volume = [i.get('volume') for i in markets]
                recent_volume = [i.get('recent_volume') for i in markets]
                open_interest = [i.get('open_interest') for i in markets]
                liquidity = [i.get('liquidity') for i in markets]
                dollar_volume = [i.get('dollar_volume') for i in markets]
                dollar_recent_volume = [i.get('dollar_recent_volume') for i in markets]
                dollar_open_interest = [i.get('dollar_open_interest') for i in markets]
                sub_title = [i.get('sub_title') for i in markets]
                title = [i.get('title') for i in markets]
                mini_title = [i.get('mini_title') for i in markets]
                name = [i.get('name') for i in markets]
                can_close_early = [i.get('can_close_early') for i in markets]
                close_unconfirmed = [i.get('close_unconfirmed') for i in markets]
                risk_limit_cents = [i.get('risk_limit_cents') for i in markets]
                yes_sub_title = [i.get('yes_sub_title') for i in markets]
                no_sub_title = [i.get('no_sub_title') for i in markets]
                expected_expiration_date = [i.get('expected_expiration_date') for i in markets]
                component_leg_title = [i.get('component_leg_title') for i in markets]
                price_level_structure = [i.get('price_level_structure') for i in markets]


                event_data_dict = { 
                    'event_ticker': ticker,
                    'series_ticker': series_ticker,
                    'target_datetime': target_datetime,
                    'mutually_exclusive': mutually_exclusive,
                    'collateral_return_type': collateral_return_type,
                    'title': event_title,
                    'category': category,
                    'tags': tags,
                    'keywords': keywords,
                    'min_tick_size': min_tick_size,
                    'settle_details': settle_details,
                    'description_context': description_context,
                    'underlying': underlying,
                    'mini_title': event_mini_title,
                    'sub_title': event_sub_title,

                    'max_close_ts': max_close_ts,


                    
                }

                for k,v in event_data_dict.items():
                    print(k, len(v))

                markets_data_dict = { 
                    'market_id': id,
                    'ticker_name': ticker_name,
                    'create_date': create_date,
                    'list_date': list_date,
                    'open_date': open_date,
                    'close_date': close_date,
                    'expiration_date': expiration_date,
                    'settlement_timer_seconds': settlement_timer_seconds,
                    'status': status,
                    'expiration_value': expiration_value,
                    'settlement_value_centicents': settlement_value_centicents,
                    'result': result,
                    'yes_bid': yes_bid,
                    'yes_ask': yes_ask,
                    'last_price': last_price,
                    'prev_period_price': prev_period_price,
                    'previous_hour_price': previous_hour_price,
                    'previous_day_price': previous_day_price,
                    'previous_week_price': previous_week_price,
                    'yes_bid_dollars': yes_bid_dollars,
                    'yes_ask_dollars': yes_ask_dollars,
                    'last_price_dollars': last_price_dollars,
                    'prev_period_price_dollars': prev_period_price_dollars,
                    'previous_hour_price_dollars': previous_hour_price_dollars,
                    'previous_day_price_dollars': previous_day_price_dollars,
                    'previous_week_price_dollars': previous_week_price_dollars,
                    'volume': volume,
                    'recent_volume': recent_volume,
                    'open_interest': open_interest,
                    'liquidity': liquidity,
                    'dollar_volume': dollar_volume,
                    'dollar_recent_volume': dollar_recent_volume,
                    'dollar_open_interest': dollar_open_interest,

                    'sub_title': sub_title,
                    'title': title,
                    'mini_title': mini_title,
                    'name': name,
                    'can_close_early': can_close_early,
                    'close_unconfirmed': close_unconfirmed,
                    'risk_limit_cents': risk_limit_cents,
                    'yes_sub_title': yes_sub_title,
                    'no_sub_title': no_sub_title,
                    'expected_expiration_date': expected_expiration_date,
                    'component_leg_title': component_leg_title,
                    'price_level_structure': price_level_structure,

                }

                event_df=  pd.DataFrame(event_data_dict)

                market_df = pd.DataFrame(markets_data_dict)
                event_df['ticker'] = ticker
                event_df['series_ticker'] = series_ticker

                await db.batch_upsert_dataframe(event_df, table_name='kalshi_events', unique_columns=['ticker', 'series_ticker'])

                await db.batch_upsert_dataframe(market_df, table_name='kalshi_markets', unique_columns=['market_id'])
                return market_df, event_df
            

    async def get_sports(self):

        url = f"https://api.elections.kalshi.com/v1/search/series?order_by=trending&status=open%2Cunopened&category=Sports&scope=Games&hydrate=milestones%2Cstructured_targets&page_size=25&include_sports_derivatives=false&experiment_key=6aef5c0c960da6fb&with_milestones=true"

        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                data = await resp.json()

                print(data)
                total_count = data['total_results_count']
                current_page = data['current_page']
                
                print(current_page)