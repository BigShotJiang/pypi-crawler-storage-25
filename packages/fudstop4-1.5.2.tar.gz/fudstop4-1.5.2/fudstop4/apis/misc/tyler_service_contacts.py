from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import string
from dataclasses import dataclass
from typing import Iterable

import aiohttp
import pandas as pd


API_URL = "https://efiletx.tylertech.cloud/OfsEfsp/api/serviceContact/firm-public/get/"
DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/147.0.0.0 Safari/537.36"
)
RESULT_CAP = 100
ROOT_DOMAIN_CHARS = string.ascii_lowercase + string.digits
DOMAIN_CHARS = ROOT_DOMAIN_CHARS + ".-"
LOCAL_PART_CHARS = ROOT_DOMAIN_CHARS + "._%+-"

logger = logging.getLogger(__name__)


def build_tyler_headers(
    cookie: str | None = None,
    user_agent: str | None = None,
) -> dict[str, str]:
    resolved_cookie = cookie or os.environ.get("TYLER_EFILE_COOKIE")
    if not resolved_cookie:
        raise ValueError(
            "Missing Tyler cookie. Pass --cookie or set TYLER_EFILE_COOKIE."
        )

    return {
        "cookie": resolved_cookie,
        "user-agent": user_agent or os.environ.get(
            "TYLER_EFILE_USER_AGENT",
            DEFAULT_USER_AGENT,
        ),
    }


def build_tyler_payload(email_term: str, per_page: int = RESULT_CAP) -> dict[str, object]:
    return {
        "perPage": per_page,
        "pageNumber": 0,
        "isFirmServiceContactsSelected": False,
        "nameFirst": "",
        "email": email_term,
        "firmName": "",
    }


@dataclass(slots=True)
class SearchNode:
    term: str
    rows: list[dict]
    mode: str = "domain"
    depth: int = 1

    @property
    def count(self) -> int:
        return len(self.rows)


@dataclass(slots=True)
class HarvestResult:
    rows: list[dict]
    terminal_terms: list[str]
    saturated_terms: list[str]
    query_count: int
    truncated: bool


class TylerServiceContacts:
    def __init__(self, data: list[dict]):
        addresses = [item.get("address") or {} for item in data]

        self.service_contact_uid = [self.build_uid(item) for item in data]
        self.service_contact_id = [
            int(item.get("serviceContactId") or 0) for item in data
        ]
        self.service_contact_key = [
            str(item.get("serviceContactKey") or "") for item in data
        ]
        self.name_first = [str(item.get("nameFirst") or "") for item in data]
        self.name_middle = [str(item.get("nameMiddle") or "") for item in data]
        self.name_last = [str(item.get("nameLast") or "") for item in data]
        self.formatted_name = [str(item.get("formattedName") or "") for item in data]
        self.email = [str(item.get("email") or "") for item in data]
        self.secondary_email = [
            str(item.get("secondaryEmail") or "") for item in data
        ]
        self.phone_number = [str(item.get("phoneNumber") or "") for item in data]
        self.phone_extension = [
            str(item.get("phoneExtension") or "") for item in data
        ]
        self.efm_key = [str(item.get("efmKey") or "") for item in data]
        self.owned_by_firm_id = [
            str(item.get("ownedByFirmId") or "") for item in data
        ]
        self.firm_name = [str(item.get("firmName") or "") for item in data]
        self.is_public = [bool(item.get("isPublic")) for item in data]
        self.is_in_firm_master_list = [
            bool(item.get("isInFirmMasterList")) for item in data
        ]
        self.ineligible_for_electronic_service = [
            bool(item.get("ineligibleForElectronicService")) for item in data
        ]
        self.is_mail_service_contact = [
            bool(item.get("isMailServiceContact")) for item in data
        ]
        self.is_filer_in_owning_firm = [
            bool(item.get("isFilerInOwningFirm")) for item in data
        ]
        self.import_service_contact_id = [
            int(item.get("importServiceContactId") or 0) for item in data
        ]
        self.is_created = [bool(item.get("isCreated")) for item in data]
        self.is_deleted = [bool(item.get("isDeleted")) for item in data]
        self.timestamp_create = [item.get("timestampCreate") for item in data]
        self.timestamp_change = [item.get("timestampChange") for item in data]
        self.timestamp_delete = [item.get("timestampDelete") for item in data]
        self.user_create = [str(item.get("userCreate") or "") for item in data]
        self.user_change = [str(item.get("userChange") or "") for item in data]
        self.user_delete = [str(item.get("userDelete") or "") for item in data]

        self.address_line_1 = [str(address.get("addressLine1") or "") for address in addresses]
        self.address_line_2 = [str(address.get("addressLine2") or "") for address in addresses]
        self.address_line_3 = [str(address.get("addressLine3") or "") for address in addresses]
        self.address_line_4 = [str(address.get("addressLine4") or "") for address in addresses]
        self.city = [str(address.get("city") or "") for address in addresses]
        self.county = [str(address.get("county") or "") for address in addresses]
        self.region = [str(address.get("region") or "") for address in addresses]
        self.zip_code = [str(address.get("zipCode") or "") for address in addresses]
        self.country = [str(address.get("country") or "") for address in addresses]
        self.formatted_address = [
            str(address.get("formattedAddress") or "") for address in addresses
        ]

        self.data_dict = {
            "service_contact_uid": self.service_contact_uid,
            "service_contact_id": self.service_contact_id,
            "service_contact_key": self.service_contact_key,
            "name_first": self.name_first,
            "name_middle": self.name_middle,
            "name_last": self.name_last,
            "formatted_name": self.formatted_name,
            "email": self.email,
            "secondary_email": self.secondary_email,
            "phone_number": self.phone_number,
            "phone_extension": self.phone_extension,
            "efm_key": self.efm_key,
            "owned_by_firm_id": self.owned_by_firm_id,
            "firm_name": self.firm_name,
            "is_public": self.is_public,
            "is_in_firm_master_list": self.is_in_firm_master_list,
            "ineligible_for_electronic_service": self.ineligible_for_electronic_service,
            "is_mail_service_contact": self.is_mail_service_contact,
            "is_filer_in_owning_firm": self.is_filer_in_owning_firm,
            "import_service_contact_id": self.import_service_contact_id,
            "is_created": self.is_created,
            "is_deleted": self.is_deleted,
            "timestamp_create": self.timestamp_create,
            "timestamp_change": self.timestamp_change,
            "timestamp_delete": self.timestamp_delete,
            "user_create": self.user_create,
            "user_change": self.user_change,
            "user_delete": self.user_delete,
            "address_line_1": self.address_line_1,
            "address_line_2": self.address_line_2,
            "address_line_3": self.address_line_3,
            "address_line_4": self.address_line_4,
            "city": self.city,
            "county": self.county,
            "region": self.region,
            "zip_code": self.zip_code,
            "country": self.country,
            "formatted_address": self.formatted_address,
        }

        self.as_dataframe = pd.DataFrame(self.data_dict)

    @staticmethod
    def build_uid(item: dict) -> str:
        seed = "|".join(
            [
                str(item.get("efmKey") or "").strip().lower(),
                str(item.get("email") or "").strip().lower(),
                str(item.get("formattedName") or "").strip().lower(),
                str(item.get("ownedByFirmId") or "").strip().lower(),
            ]
        )
        return hashlib.sha1(seed.encode("utf-8")).hexdigest()


def dedupe_rows(rows: Iterable[dict]) -> list[dict]:
    unique: dict[str, dict] = {}
    for row in rows:
        unique[TylerServiceContacts.build_uid(row)] = row
    return list(unique.values())


class TylerServiceContactsHarvester:
    def __init__(
        self,
        headers: dict[str, str],
        *,
        result_cap: int = RESULT_CAP,
        throttle_seconds: float = 0.05,
        timeout_seconds: float = 30.0,
        progress_every: int = 0,
    ):
        self.headers = headers
        self.result_cap = result_cap
        self.throttle_seconds = throttle_seconds
        self.timeout_seconds = timeout_seconds
        self.progress_every = progress_every
        self.query_count = 0
        self._cache: dict[str, list[dict]] = {}

    def default_root_terms(self) -> list[str]:
        return [f"@{char}" for char in ROOT_DOMAIN_CHARS]

    async def fetch_rows(
        self,
        session: aiohttp.ClientSession,
        term: str,
    ) -> list[dict]:
        if term in self._cache:
            return self._cache[term]

        payload = build_tyler_payload(term, per_page=self.result_cap)
        timeout = aiohttp.ClientTimeout(total=self.timeout_seconds)

        async with session.post(
            API_URL,
            headers=self.headers,
            data=payload,
            timeout=timeout,
        ) as response:
            if response.status != 200:
                text = await response.text()
                raise RuntimeError(
                    f"Tyler request failed for {term!r}: HTTP {response.status}: {text[:500]}"
                )

            payload_json = await response.json()

        response_meta = payload_json.get("response") or {}
        if response_meta.get("responseCode") not in (None, 0):
            raise RuntimeError(
                f"Tyler request failed for {term!r}: {response_meta.get('responseErrorMessage')}"
            )

        rows = payload_json.get("data") or []
        if not isinstance(rows, list):
            raise RuntimeError(f"Unexpected Tyler payload for {term!r}: {type(rows)!r}")

        self._cache[term] = rows
        self.query_count += 1
        if self.progress_every and self.query_count % self.progress_every == 0:
            logger.info(
                "Tyler harvest progress: queries=%s cached_terms=%s last_term=%s matches=%s",
                self.query_count,
                len(self._cache),
                term,
                len(rows),
            )

        if self.throttle_seconds:
            await asyncio.sleep(self.throttle_seconds)

        return rows

    async def _expand_children(
        self,
        session: aiohttp.ClientSession,
        node: SearchNode,
        *,
        direction: str,
        alphabet: str,
        mode: str,
    ) -> list[SearchNode]:
        children: list[SearchNode] = []
        for char in alphabet:
            term = f"{node.term}{char}" if direction == "append" else f"{char}{node.term}"
            rows = await self.fetch_rows(session, term)
            if rows:
                children.append(
                    SearchNode(
                        term=term,
                        rows=rows,
                        mode=mode,
                        depth=node.depth + 1,
                    )
                )
        return children

    async def expand_node(
        self,
        session: aiohttp.ClientSession,
        node: SearchNode,
    ) -> list[SearchNode]:
        if node.mode == "domain":
            domain_children = await self._expand_children(
                session,
                node,
                direction="append",
                alphabet=DOMAIN_CHARS,
                mode="domain",
            )
            if domain_children:
                return domain_children

        return await self._expand_children(
            session,
            node,
            direction="prepend",
            alphabet=LOCAL_PART_CHARS,
            mode="local",
        )

    async def harvest(
        self,
        *,
        root_terms: Iterable[str] | None = None,
        max_queries: int | None = None,
    ) -> HarvestResult:
        seeds = list(root_terms or self.default_root_terms())
        pending: list[SearchNode] = []
        terminal_nodes: list[SearchNode] = []
        saturated_terms: list[str] = []
        truncated = False

        async with aiohttp.ClientSession() as session:
            for seed in seeds:
                rows = await self.fetch_rows(session, seed)
                if rows:
                    pending.append(SearchNode(term=seed, rows=rows))

            while pending:
                node = pending.pop()

                if node.count < self.result_cap:
                    terminal_nodes.append(node)
                    continue

                if max_queries is not None and self.query_count >= max_queries:
                    terminal_nodes.append(node)
                    truncated = True
                    continue

                children = await self.expand_node(session, node)
                if not children:
                    terminal_nodes.append(node)
                    saturated_terms.append(node.term)
                    continue

                pending.extend(reversed(children))

        unique_rows = dedupe_rows(
            row
            for node in terminal_nodes
            for row in node.rows
        )

        return HarvestResult(
            rows=unique_rows,
            terminal_terms=[node.term for node in terminal_nodes],
            saturated_terms=saturated_terms,
            query_count=self.query_count,
            truncated=truncated,
        )
