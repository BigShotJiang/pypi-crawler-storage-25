#!/usr/bin/env python3
"""
ta_pipeline_asyncpg.py

A minimal but high-performance pattern for:
  1) Defining indicator "pipelines" (mix/match)
  2) Computing indicators in Python (Pandas/NumPy/Numba)
  3) Persisting results back to Postgres via asyncpg (either into a features table or into your base table)

This script is intentionally DB-agnostic: fill in DSN + your own table names and key columns.

Requires:
  - asyncpg
  - pandas, numpy
  - your ta_sdk.py (FudstopTA class)

Notes
-----
For rapid experimentation, I strongly recommend a separate `ca_features` table, keyed by
(ticker, timespan, ts). That avoids rewriting your huge base candle rows when iterating.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import asyncpg  # type: ignore

# Adjust import to wherever you keep this file.
from ta_sdk import FudstopTA  # noqa: E402


# ------------------------------ config ------------------------------

@dataclass(frozen=True)
class TAConfig:
    # Core (you said these are fixed)
    rsi_window: int = 14

    macd_fast: int = 12
    macd_slow: int = 26  # set 29 if you truly want 12/29
    macd_signal: int = 9

    # Examples you may tune
    bb_window: int = 20
    bb_std: float = 2.0

    atr_window: int = 14
    chop_window: int = 14

    rvol_window: int = 20


@dataclass(frozen=True)
class IndicatorSpec:
    """
    One indicator "block".
    - outputs: column_name -> postgres_type
    - apply: function that adds columns onto the df
    """
    name: str
    outputs: Dict[str, str]
    apply: Callable[[pd.DataFrame, TAConfig], pd.DataFrame]
    warmup_bars: int = 0  # used to choose a safe lookback for incremental compute


# ------------------------------ indicator registry ------------------------------

def spec_core_rsi() -> IndicatorSpec:
    return IndicatorSpec(
        name="rsi",
        outputs={"rsi": "double precision"},
        warmup_bars=15,
        apply=lambda df, cfg: FudstopTA.compute_wilders_rsi(df, window=cfg.rsi_window),
    )


def spec_core_td9() -> IndicatorSpec:
    return IndicatorSpec(
        name="td9",
        outputs={"td_buy_count": "integer", "td_sell_count": "integer"},
        warmup_bars=5,
        apply=lambda df, cfg: FudstopTA.add_td9_counts(df),
    )


def spec_core_macd() -> IndicatorSpec:
    return IndicatorSpec(
        name="macd",
        outputs={
            "macd_line": "double precision",
            "macd_signal": "double precision",
            "macd_hist": "double precision",
            "macd_cross_up": "boolean",
            "macd_cross_dn": "boolean",
            "macd_hist_slope": "double precision",
            "macd_hist_slope3": "double precision",
        },
        # EMA warmups are "soft"; for stable MACD you usually want a few multiples of slow period.
        warmup_bars=150,
        apply=lambda df, cfg: FudstopTA.add_macd(
            df,
            fast_period=cfg.macd_fast,
            slow_period=cfg.macd_slow,
            signal_period=cfg.macd_signal,
        ),
    )


def spec_bollinger() -> IndicatorSpec:
    return IndicatorSpec(
        name="bbands",
        outputs={
            "middle_band": "double precision",
            "std": "double precision",
            "upper_band": "double precision",
            "lower_band": "double precision",
            "candle_above_upper": "boolean",
            "candle_below_lower": "boolean",
            "candle_completely_above_upper": "boolean",
            "candle_partially_above_upper": "boolean",
            "candle_completely_below_lower": "boolean",
            "candle_partially_below_lower": "boolean",
            "upper_bb_trend": "text",
            "lower_bb_trend": "text",
            "bb_width": "double precision",
            "bb_close_outside_lower": "boolean",
            "bb_close_outside_upper": "boolean",
            "bb_wick_outside_lower": "boolean",
            "bb_wick_outside_upper": "boolean",
            # plus some aliases the SDK adds
            "bb_close_outside": "boolean",
            "bb_wick_outside": "boolean",
        },
        warmup_bars=60,
        apply=lambda df, cfg: FudstopTA.add_band_position_metrics(
            FudstopTA.add_bollinger_bands(df, window=cfg.bb_window, num_std=cfg.bb_std)
        ),
    )


def spec_atr_chop_rvol() -> IndicatorSpec:
    # A small "regime" pack that helps reversal mining (choppy vs trending; participation).
    return IndicatorSpec(
        name="regime_pack",
        outputs={
            "atr": "double precision",
            "chop": "double precision",
            "rvol": "double precision",
        },
        warmup_bars=80,
        apply=lambda df, cfg: (
            FudstopTA.add_relative_volume(
                FudstopTA.add_choppiness_index(
                    FudstopTA.add_atr(df, window=cfg.atr_window),
                    window=cfg.chop_window,
                ),
                window=cfg.rvol_window,
            )
        ),
    )


def spec_momentum_flags() -> IndicatorSpec:
    # Uses adx/di/macd/tsi/chop/rvol if present; doesn't crash if some are missing.
    return IndicatorSpec(
        name="momentum_flags",
        outputs={
            "adx_strong": "boolean",
            "di_bull": "boolean",
            "di_bear": "boolean",
            "macd_bull": "boolean",
            "macd_bear": "boolean",
            "tsi_bull": "boolean",
            "tsi_bear": "boolean",
            "trend_regime": "boolean",
            "volume_confirm": "boolean",
            "momentum_confirm_bull": "boolean",
            "momentum_confirm_bear": "boolean",
        },
        warmup_bars=0,
        apply=lambda df, cfg: FudstopTA.add_momentum_flags(df),
    )


PIPELINES: Mapping[str, Sequence[IndicatorSpec]] = {
    "core": (spec_core_rsi(), spec_core_macd(), spec_core_td9()),
    "reversal_pack": (
        spec_core_rsi(),
        spec_core_macd(),
        spec_core_td9(),
        spec_bollinger(),
        spec_atr_chop_rvol(),
        spec_momentum_flags(),
    ),
}


def pipeline_outputs(pipeline: Sequence[IndicatorSpec]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for spec in pipeline:
        out.update(spec.outputs)
    return out


def pipeline_warmup(pipeline: Sequence[IndicatorSpec]) -> int:
    return int(max((s.warmup_bars for s in pipeline), default=0))


# ------------------------------ db helpers ------------------------------

def _quote_ident(name: str) -> str:
    # minimal identifier quoting for Postgres; do NOT pass untrusted user input here.
    return '"' + name.replace('"', '""') + '"'


async def ensure_feature_table(
    conn: asyncpg.Connection,
    feature_table: str,
    key_cols: Mapping[str, str],
    pipeline: Sequence[IndicatorSpec],
) -> None:
    """
    Create a features table if it doesn't exist. Safe to run repeatedly.
    """
    cols = {**key_cols, **pipeline_outputs(pipeline)}
    col_sql = ",\n  ".join(f"{_quote_ident(c)} {t}" for c, t in cols.items())
    pk_cols = ", ".join(_quote_ident(c) for c in key_cols.keys())

    sql = f"""
    CREATE TABLE IF NOT EXISTS {feature_table} (
      {col_sql},
      PRIMARY KEY ({pk_cols})
    );
    """
    await conn.execute(sql)


async def fetch_candles(
    conn: asyncpg.Connection,
    candle_table: str,
    ticker: str,
    timespan: str,
    *,
    limit: Optional[int] = None,
    since_ts: Optional[str] = None,
) -> pd.DataFrame:
    """
    Fetch candles ASC by ts. Assumes ts is lexicographically sortable (ISO-8601 text) or timestamp.
    """
    where = "WHERE ticker=$1 AND timespan=$2"
    params: List[object] = [ticker, timespan]

    if since_ts is not None:
        where += " AND ts >= $3"
        params.append(since_ts)

    lim = f"LIMIT {int(limit)}" if limit else ""
    sql = f"""
      SELECT ts, o, h, l, c, v, vw
      FROM {candle_table}
      {where}
      ORDER BY ts ASC
      {lim};
    """
    rows = await conn.fetch(sql, *params)
    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame([dict(r) for r in rows])
    return df


async def upsert_features(
    conn: asyncpg.Connection,
    feature_table: str,
    key_cols: Sequence[str],
    df: pd.DataFrame,
    feature_cols: Sequence[str],
) -> None:
    """
    Fast-ish upsert:
      - COPY into a temp table
      - INSERT .. SELECT .. ON CONFLICT DO UPDATE into feature_table

    If you do huge backfills, consider:
      - UNLOGGED staging table
      - partitioned feature tables
    """
    if df.empty:
        return

    cols = list(key_cols) + list(feature_cols)
    tmp = "tmp_features"

    await conn.execute(f"CREATE TEMP TABLE {tmp} (LIKE {feature_table}) ON COMMIT DROP;")

    records = [tuple(df[c].iloc[i] for c in cols) for i in range(len(df))]
    await conn.copy_records_to_table(tmp, records=records, columns=cols)

    set_clause = ", ".join(f"{_quote_ident(c)}=EXCLUDED.{_quote_ident(c)}" for c in feature_cols)
    col_list = ", ".join(_quote_ident(c) for c in cols)
    select_list = ", ".join(_quote_ident(c) for c in cols)
    pk = ", ".join(_quote_ident(c) for c in key_cols)

    sql = f"""
      INSERT INTO {feature_table} ({col_list})
      SELECT {select_list} FROM {tmp}
      ON CONFLICT ({pk}) DO UPDATE
      SET {set_clause};
    """
    await conn.execute(sql)


# ------------------------------ compute entrypoints ------------------------------

def compute_indicators(df: pd.DataFrame, cfg: TAConfig, pipeline: Sequence[IndicatorSpec]) -> pd.DataFrame:
    """
    Runs each indicator in-order. Each spec should be vectorized and return df.
    """
    out = df
    for spec in pipeline:
        out = spec.apply(out, cfg)
    return out


async def backfill_one(
    conn: asyncpg.Connection,
    candle_table: str,
    feature_table: str,
    ticker: str,
    timespan: str,
    pipeline_name: str,
    cfg: TAConfig,
    *,
    chunk_limit: Optional[int] = None,
) -> None:
    """
    Simple backfill for one ticker/timespan.
    For very large history, you may want chunking by date. Start with this.
    """
    pipeline = PIPELINES[pipeline_name]
    df = await fetch_candles(conn, candle_table, ticker, timespan, limit=chunk_limit)

    if df.empty:
        return

    df = compute_indicators(df, cfg, pipeline)

    key_cols = ("ticker", "timespan", "ts")
    # attach keys (you may already keep these in df; here we add them)
    df.insert(0, "ticker", ticker)
    df.insert(1, "timespan", timespan)

    feature_cols = [c for c in pipeline_outputs(pipeline).keys() if c in df.columns]
    await upsert_features(conn, feature_table, key_cols, df, feature_cols)


# ------------------------------ rule mining example ------------------------------

def mine_reversal_masks(
    df: pd.DataFrame,
    *,
    horizon_bars: int = 10,
    threshold: float = 0.002,
    min_samples: int = 200,
) -> pd.DataFrame:
    """
    Turn boolean conditions into a bitmask and compute win-rate of a forward-return label.
    This is a clean way to "mix/match" indicators without hand-writing 1000s of combos.
    """
    if df.empty:
        return pd.DataFrame()

    d = df.copy()
    d["fwd_ret"] = (d["c"].shift(-horizon_bars) / d["c"]) - 1.0
    d["label_up"] = d["fwd_ret"] >= threshold

    # Define your boolean conditions here (add/remove freely):
    conds: List[Tuple[str, pd.Series]] = [
        ("rsi_os", pd.to_numeric(d.get("rsi"), errors="coerce") < 30),
        ("td9_buy9", pd.to_numeric(d.get("td_buy_count"), errors="coerce") >= 9),
        ("macd_hist_rising", pd.to_numeric(d.get("macd_hist_slope"), errors="coerce") > 0),
        ("bb_wick_lower", d.get("bb_wick_outside_lower", False).astype(bool) if "bb_wick_outside_lower" in d.columns else pd.Series(False, index=d.index)),
        ("volume_confirm", d.get("volume_confirm", False).astype(bool) if "volume_confirm" in d.columns else pd.Series(False, index=d.index)),
        ("choppy_regime", (pd.to_numeric(d.get("chop"), errors="coerce") >= 55) if "chop" in d.columns else pd.Series(False, index=d.index)),
    ]

    mask = np.zeros(len(d), dtype=np.int64)
    for i, (_name, s) in enumerate(conds):
        mask |= (s.fillna(False).astype(np.int64) << i)

    d["mask"] = mask

    stats = (
        d.groupby("mask")
         .agg(
             n=("mask", "size"),
             winrate=("label_up", "mean"),
             avg_ret=("fwd_ret", "mean"),
         )
         .query("n >= @min_samples")
         .sort_values(["winrate", "avg_ret", "n"], ascending=False)
    )

    # Decode masks back into readable rules
    def decode(m: int) -> str:
        parts = [name for i, (name, _s) in enumerate(conds) if (m >> i) & 1]
        return " & ".join(parts) if parts else "(none)"

    stats["rule"] = [decode(int(m)) for m in stats.index]
    return stats.reset_index()


# ------------------------------ main (example) ------------------------------

async def main() -> None:
    dsn = "postgresql://USER:PASSWORD@HOST:5432/DBNAME"
    candle_table = "public.ca"
    feature_table = "public.ca_features_v1"
    key_cols = {"ticker": "text", "timespan": "text", "ts": "text"}

    cfg = TAConfig(rsi_window=14, macd_fast=12, macd_slow=26, macd_signal=9)

    conn = await asyncpg.connect(dsn)
    try:
        await ensure_feature_table(conn, feature_table, key_cols, PIPELINES["reversal_pack"])

        # Example backfill call (replace with your own ticker list)
        await backfill_one(conn, candle_table, feature_table, "AAPL", "1min", "reversal_pack", cfg)

        # Example: load back the joined view for mining (adjust to your schema)
        rows = await conn.fetch(
            f"""
            SELECT ca.ts, ca.o, ca.h, ca.l, ca.c, ca.v,
                   f.rsi, f.td_buy_count, f.macd_hist_slope, f.bb_wick_outside_lower, f.volume_confirm, f.chop
            FROM {candle_table} ca
            JOIN {feature_table} f
              ON (ca.ticker=f.ticker AND ca.timespan=f.timespan AND ca.ts=f.ts)
            WHERE ca.ticker=$1 AND ca.timespan=$2
            ORDER BY ca.ts ASC
            """,
            "AAPL", "1min"
        )
        df = pd.DataFrame([dict(r) for r in rows])
        stats = mine_reversal_masks(df, horizon_bars=10, threshold=0.002, min_samples=300)
        print(stats.head(20).to_string(index=False))

    finally:
        await conn.close()


if __name__ == "__main__":
    asyncio.run(main())
