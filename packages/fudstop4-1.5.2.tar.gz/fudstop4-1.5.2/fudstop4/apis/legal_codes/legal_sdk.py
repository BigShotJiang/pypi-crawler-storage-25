import pandas as pd
import asyncio
from fudstop4.apis.polygonio.polygon_options import PolygonOptions
import aiohttp
db = PolygonOptions()



class LegalCodesSDK:
    def __init__(self):

        self._statutes_dict = { 
            'texas_consti'
        }

    async def get(self, url, params=None):

        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def search(self, query):

        url = f"https://tcss.legis.texas.gov/api/TCASSearch/GetPage/1/ZZ/{query}"

        data = await self.get(url, params={"q": query})


        ResultNumber = [i.get('ResultNumber') for i in data]
        Title = [i.get('Title') for i in data]
        DocViewer = [i.get('DocViewer') for i in data]
        FileName = [i.get('FileName') for i in data]
        DocumentCode = [i.get('DocumentCode') for i in data]
        
        dict = { 
            'result_number': ResultNumber,
            'title': Title,
            'doc_viewer': DocViewer,
            'file_name': FileName,
            'document_code': DocumentCode

        }

        df = pd.DataFrame(dict)


        return df

    
