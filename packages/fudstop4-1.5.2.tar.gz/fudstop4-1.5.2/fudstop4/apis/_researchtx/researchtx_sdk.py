from __future__ import annotations

import asyncio
import os
import random
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Iterable

import aiohttp
import pandas as pd

from fudstop4.apis._researchtx.researchtx_models import (
    DEFAULT_RESEARCHTX_USER_AGENT,
    ResearchTexasCase,
    ResearchTexasEvent,
    ResearchTexasParty,
    ResearchTxCaseEvents,
    clean_text,
)


DEFAULT_BASE_URL = "https://research.txcourts.gov/CourtRecordsSearch"
DEFAULT_SEARCH_TIMEZONE_OFFSET = -300


class ResearchTexasAuthError(RuntimeError):
    pass


class ResearchTexasRequestError(RuntimeError):
    pass


def _normalize_case_number(case_number: str | None) -> str:
    text = clean_text(case_number) or ""
    return "".join(ch for ch in text.upper() if ch.isalnum())


class ResearchTexasAsyncClient:
    def __init__(
        self,
        cookie: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        user_agent: str | None = None,
        time_zone_offset_in_minutes: int = DEFAULT_SEARCH_TIMEZONE_OFFSET,
        max_retries: int = 5,
    ):
        resolved_cookie = cookie or os.environ.get("RESEARCHTX_COOKIE")
        if not resolved_cookie:
            raise ValueError(
                "Missing re:Search Texas cookie. Pass cookie=... or set RESEARCHTX_COOKIE."
            )

        self.base_url = base_url.rstrip("/")
        self.timeout = float(timeout)
        self.user_agent = user_agent or os.environ.get(
            "RESEARCHTX_USER_AGENT",
            DEFAULT_RESEARCHTX_USER_AGENT,
        )
        self.time_zone_offset_in_minutes = int(time_zone_offset_in_minutes)
        self.max_retries = int(max_retries)
        self._cookie = resolved_cookie

    @property
    def headers(self) -> dict[str, str]:
        return {
            "cookie": self._cookie,
            "user-agent": self.user_agent,
        }

    def update_cookie(self, cookie: str) -> None:
        if not cookie or not cookie.strip():
            raise ValueError("Cookie cannot be blank.")
        self._cookie = cookie.strip()

    @asynccontextmanager
    async def session(self) -> AsyncIterator[aiohttp.ClientSession]:
        timeout = aiohttp.ClientTimeout(total=self.timeout)
        async with aiohttp.ClientSession(headers=self.headers, timeout=timeout) as session:
            yield session

    def build_search_payload(
        self,
        *,
        query_string: str | None = None,
        page_size: int = 50,
        page_index: int = 0,
        advanced_conditions: list[dict[str, Any]] | None = None,
        search_index_type: str = "Cases",
        sort_fields: str = "0",
        sort_field_order: str = "desc",
    ) -> dict[str, Any]:
        return {
            "queryString": query_string or None,
            "pageSize": int(page_size),
            "pageIndex": int(page_index),
            "advancedSearchConditions": {
                "advancedSearchConditions": advanced_conditions or [],
            },
            "SearchIndexType": search_index_type,
            "sortFieldOrder": sort_field_order,
            "sortFields": sort_fields,
        }

    async def _post_json(
        self,
        session: aiohttp.ClientSession,
        url: str,
        *,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        last_error: Exception | None = None
        for attempt in range(self.max_retries):
            try:
                async with session.post(url, json=payload) as response:
                    text = await response.text()
                    if response.status in (401, 403):
                        raise ResearchTexasAuthError(
                            f"Authentication failed with HTTP {response.status}."
                        )
                    if response.status in (429, 500, 502, 503, 504):
                        raise ResearchTexasRequestError(
                            f"Transient ResearchTX error {response.status}: {text[:300]}"
                        )
                    if response.status >= 400:
                        raise ResearchTexasRequestError(
                            f"ResearchTX request failed with HTTP {response.status}: {text[:300]}"
                        )
                    if not text.strip():
                        return {}
                    return await response.json()
            except ResearchTexasAuthError:
                raise
            except (ResearchTexasRequestError, aiohttp.ClientError, asyncio.TimeoutError) as exc:
                last_error = exc
                if attempt == self.max_retries - 1:
                    break
                sleep_seconds = min(15.0, (0.75 * (2 ** attempt)) * (0.7 + 0.6 * random.random()))
                await asyncio.sleep(sleep_seconds)

        if isinstance(last_error, Exception):
            raise last_error
        raise ResearchTexasRequestError("ResearchTX request failed without an explicit error.")

    async def fetch_search_page(
        self,
        *,
        query_string: str | None = None,
        page_size: int = 50,
        page_index: int = 0,
        advanced_conditions: list[dict[str, Any]] | None = None,
        search_index_type: str = "Cases",
        sort_fields: str = "0",
        sort_field_order: str = "desc",
        session: aiohttp.ClientSession | None = None,
    ) -> dict[str, Any]:
        payload = self.build_search_payload(
            query_string=query_string,
            page_size=page_size,
            page_index=page_index,
            advanced_conditions=advanced_conditions,
            search_index_type=search_index_type,
            sort_fields=sort_fields,
            sort_field_order=sort_field_order,
        )
        url = (
            f"{self.base_url}/search?"
            f"timeZoneOffsetInMinutes={self.time_zone_offset_in_minutes}"
        )
        if session is None:
            async with self.session() as owned_session:
                return await self._post_json(owned_session, url, payload=payload)
        return await self._post_json(session, url, payload=payload)

    async def search_cases(
        self,
        *,
        query_string: str | None = None,
        page_size: int = 50,
        page_index: int = 0,
        advanced_conditions: list[dict[str, Any]] | None = None,
        search_index_type: str = "Cases",
        sort_fields: str = "0",
        sort_field_order: str = "desc",
        session: aiohttp.ClientSession | None = None,
    ) -> AsyncIterator[ResearchTexasCase]:
        current_page = int(page_index)
        while True:
            data = await self.fetch_search_page(
                query_string=query_string,
                page_size=page_size,
                page_index=current_page,
                advanced_conditions=advanced_conditions,
                search_index_type=search_index_type,
                sort_fields=sort_fields,
                sort_field_order=sort_field_order,
                session=session,
            )
            result = (data or {}).get("result") or {}
            search_results = result.get("searchResults") or {}
            hits = search_results.get("hits") or []
            if not hits:
                break

            for hit in hits:
                if isinstance(hit, dict):
                    yield ResearchTexasCase.from_search_hit(
                        hit,
                        seed_source="search",
                        seed_query=query_string,
                    )

            if len(hits) < int(page_size):
                break
            current_page += 1

    async def collect_search_cases(self, **kwargs: Any) -> list[ResearchTexasCase]:
        results: list[ResearchTexasCase] = []
        async for case in self.search_cases(**kwargs):
            results.append(case)
        return results

    async def search_case_by_number(
        self,
        case_number: str,
        *,
        jurisdiction: str | None = None,
        case_data_id: str | None = None,
        session: aiohttp.ClientSession | None = None,
    ) -> ResearchTexasCase | None:
        normalized_target = _normalize_case_number(case_number)
        best_match: ResearchTexasCase | None = None

        async for case in self.search_cases(
            query_string=case_number,
            page_size=10,
            session=session,
        ):
            normalized_candidate = _normalize_case_number(case.case_number)
            jurisdiction_matches = not jurisdiction or case.jurisdiction == jurisdiction
            data_id_matches = not case_data_id or case.case_data_id == case_data_id

            if normalized_candidate == normalized_target and jurisdiction_matches and data_id_matches:
                return case
            if normalized_candidate == normalized_target and jurisdiction_matches and best_match is None:
                best_match = case
            elif normalized_candidate == normalized_target and best_match is None:
                best_match = case

        return best_match

    async def fetch_case_events_page(
        self,
        case_data_id: str,
        *,
        page_size: int = 25,
        page_index: int = 0,
        search_text: str | None = None,
        sort_newest_to_oldest: bool = False,
        session: aiohttp.ClientSession | None = None,
    ) -> dict[str, Any]:
        payload = {
            "pageSize": int(page_size),
            "pageIndex": int(page_index),
            "sortNewestToOldest": bool(sort_newest_to_oldest),
            "searchText": search_text or None,
            "isSearchAll": True,
            "eventType": 0,
        }
        url = f"{self.base_url}/case/{case_data_id}/events"
        if session is None:
            async with self.session() as owned_session:
                return await self._post_json(owned_session, url, payload=payload)
        return await self._post_json(session, url, payload=payload)

    async def get_case_events(
        self,
        case_data_id: str,
        *,
        page_size: int = 25,
        page_index: int = 0,
        search_text: str | None = None,
        sort_newest_to_oldest: bool = False,
        session: aiohttp.ClientSession | None = None,
    ) -> list[ResearchTexasEvent]:
        current_page = int(page_index)
        payloads: list[dict[str, Any]] = []
        while True:
            response = await self.fetch_case_events_page(
                case_data_id,
                page_size=page_size,
                page_index=current_page,
                search_text=search_text,
                sort_newest_to_oldest=sort_newest_to_oldest,
                session=session,
            )
            batch = (response or {}).get("events") or []
            if not batch:
                break
            payloads.extend(batch)
            if len(batch) < int(page_size):
                break
            current_page += 1

        return ResearchTexasEvent.from_events_payload(case_data_id, payloads)

    def get_case_parties(
        self,
        case_payload_or_detail: ResearchTexasCase | dict[str, Any],
    ) -> list[ResearchTexasParty]:
        if isinstance(case_payload_or_detail, ResearchTexasCase):
            return case_payload_or_detail.parties
        return ResearchTexasCase.from_search_hit(case_payload_or_detail).parties

    async def search_cases_by_attorney_bar_number(
        self,
        bar_number: str,
        *,
        page_size: int = 50,
        session: aiohttp.ClientSession | None = None,
    ) -> list[ResearchTexasCase]:
        advanced_conditions = [
            {
                "conditionOperation": 0,
                "fieldOption": 17,
                "value": str(bar_number),
                "fromValue": None,
                "toValue": None,
                "firstName": None,
                "lastName": None,
                "valueSet": [],
            }
        ]
        return await self.collect_search_cases(
            query_string=None,
            page_size=page_size,
            advanced_conditions=advanced_conditions,
            session=session,
        )


class ResearchTexasSDK(ResearchTexasAsyncClient):
    async def get_filings(
        self,
        id: str,
        page_size: int = 25,
        search_text: str = "",
        index: int = 0,
    ) -> pd.DataFrame:
        events = await self.get_case_events(
            id,
            page_size=page_size,
            page_index=index,
            search_text=search_text or None,
            sort_newest_to_oldest=False,
        )
        return ResearchTxCaseEvents.from_event_models(events).as_dataframe

    async def get_events(
        self,
        pageindex: int = 0,
        case_number: str = "",
        page_size: int = 20,
    ) -> pd.DataFrame:
        events = await self.get_case_events(
            case_number,
            page_size=page_size,
            page_index=pageindex,
            sort_newest_to_oldest=True,
        )
        return ResearchTxCaseEvents.from_event_models(events).as_dataframe

    async def get_attorney(
        self,
        query_value: str = "24110698",
        page_size: int = 50,
    ) -> pd.DataFrame:
        cases = await self.search_cases_by_attorney_bar_number(
            query_value,
            page_size=page_size,
        )

        rows: list[dict[str, Any]] = []
        for case in cases:
            if not case.parties:
                rows.append(
                    {
                        "caseNumber": case.case_number,
                        "jurisdiction": case.jurisdiction,
                        "caseCategoryCode": case.case_category_code,
                        "dateFiled": case.date_filed_raw,
                        "status": case.status,
                        "statusActual": case.status_actual,
                        "isSealed": case.is_sealed,
                        "caseLastRefreshed": case.case_last_refreshed_raw,
                        "partyTypeCode": None,
                        "partyName": None,
                        "email": None,
                        "attorneyNames": None,
                        "attorneyBarNumbers": None,
                        "attorneyFirmNames": None,
                    }
                )
                continue

            for party in case.parties:
                rows.append(
                    {
                        "caseNumber": case.case_number,
                        "jurisdiction": case.jurisdiction,
                        "caseCategoryCode": case.case_category_code,
                        "dateFiled": case.date_filed_raw,
                        "status": case.status,
                        "statusActual": case.status_actual,
                        "isSealed": case.is_sealed,
                        "caseLastRefreshed": case.case_last_refreshed_raw,
                        "partyTypeCode": party.party_type_code,
                        "partyName": party.party_name,
                        "email": party.email,
                        "attorneyNames": "; ".join(
                            filter(None, (attorney.attorney_name for attorney in party.attorneys))
                        )
                        or None,
                        "attorneyBarNumbers": "; ".join(
                            filter(None, (attorney.bar_number for attorney in party.attorneys))
                        )
                        or None,
                        "attorneyFirmNames": "; ".join(
                            filter(None, (attorney.firm_name for attorney in party.attorneys))
                        )
                        or None,
                    }
                )

        return pd.DataFrame(rows)
