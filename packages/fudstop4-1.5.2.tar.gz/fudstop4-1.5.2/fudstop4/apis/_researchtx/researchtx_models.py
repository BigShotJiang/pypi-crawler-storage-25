from __future__ import annotations

import hashlib
import html
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable

import pandas as pd


DEFAULT_RESEARCHTX_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/147.0.0.0 Safari/537.36"
)


def clean_text(value: Any) -> str | None:
    if value is None:
        return None
    text = html.unescape(str(value))
    text = re.sub(r"<[^>]+>", "", text).strip()
    return text or None


def clean_int(value: Any) -> int | None:
    if value in (None, "", "--"):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def parse_iso_datetime(value: Any) -> datetime | None:
    if value in (None, "", "--"):
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value

    text = str(value).strip()
    if not text:
        return None

    normalized = text.replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        for fmt in (
            "%m/%d/%Y %I:%M:%S %p",
            "%m/%d/%Y %H:%M:%S",
            "%m/%d/%Y",
            "%Y-%m-%d",
        ):
            try:
                parsed = datetime.strptime(text, fmt)
                break
            except ValueError:
                continue
        else:
            return None

    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed


def json_dumps(value: Any) -> str | None:
    if value is None:
        return None
    return json.dumps(value, sort_keys=True, default=str)


def build_uid(*parts: Any) -> str:
    seed = "|".join("" if part is None else str(part).strip().lower() for part in parts)
    return hashlib.sha1(seed.encode("utf-8")).hexdigest()


def split_delimited(value: Any, delimiter: str = ";") -> list[str]:
    if value in (None, ""):
        return []
    return [part.strip() for part in str(value).split(delimiter) if part.strip()]


@dataclass(slots=True)
class ResearchTexasAttorney:
    attorney_name: str | None = None
    bar_number: str | None = None
    firm_name: str | None = None
    email: str | None = None
    raw_payload: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ResearchTexasAttorney":
        return cls(
            attorney_name=clean_text(payload.get("name")),
            bar_number=clean_text(payload.get("barNumber")),
            firm_name=clean_text(payload.get("firmName")),
            email=clean_text(payload.get("email")),
            raw_payload=payload,
        )

    def uid(
        self,
        *,
        case_data_id: str,
        party_uid: str | None = None,
        attorney_index: int | None = None,
    ) -> str:
        return build_uid(
            "attorney",
            case_data_id,
            party_uid or "",
            attorney_index or "",
            self.attorney_name,
            self.bar_number,
            self.firm_name,
            self.email,
        )

    def to_record(
        self,
        *,
        case_data_id: str,
        party_uid: str | None,
        attorney_index: int,
        fetched_at: datetime,
    ) -> dict[str, Any]:
        attorney_uid = self.uid(
            case_data_id=case_data_id,
            party_uid=party_uid,
            attorney_index=attorney_index,
        )
        return {
            "attorney_uid": attorney_uid,
            "case_data_id": case_data_id,
            "party_uid": party_uid,
            "attorney_index": attorney_index,
            "attorney_name": self.attorney_name,
            "bar_number": self.bar_number,
            "firm_name": self.firm_name,
            "email": self.email,
            "fetched_at": fetched_at,
            "updated_at": fetched_at,
            "raw_payload": json_dumps(self.raw_payload),
        }


@dataclass(slots=True)
class ResearchTexasParty:
    party_name: str | None = None
    party_type_code: str | None = None
    email: str | None = None
    attorneys: list[ResearchTexasAttorney] = field(default_factory=list)
    raw_payload: dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "ResearchTexasParty":
        attorneys = [
            ResearchTexasAttorney.from_payload(attorney)
            for attorney in (payload.get("attorneys") or [])
            if isinstance(attorney, dict)
        ]
        return cls(
            party_name=clean_text(payload.get("name")),
            party_type_code=clean_text(payload.get("partyTypeCode")),
            email=clean_text(payload.get("email")),
            attorneys=attorneys,
            raw_payload=payload,
        )

    def uid(self, *, case_data_id: str, party_index: int) -> str:
        return build_uid(
            "party",
            case_data_id,
            party_index,
            self.party_name,
            self.party_type_code,
            self.email,
        )

    def to_record(
        self,
        *,
        case_data_id: str,
        party_index: int,
        fetched_at: datetime,
    ) -> dict[str, Any]:
        party_uid = self.uid(case_data_id=case_data_id, party_index=party_index)
        return {
            "party_uid": party_uid,
            "case_data_id": case_data_id,
            "party_index": party_index,
            "party_name": self.party_name,
            "party_type_code": self.party_type_code,
            "email": self.email,
            "attorney_count": len(self.attorneys),
            "fetched_at": fetched_at,
            "updated_at": fetched_at,
            "raw_payload": json_dumps(self.raw_payload),
        }


@dataclass(slots=True)
class ResearchTexasEvent:
    case_data_id: str
    filing_id: str | None = None
    ofs_filing_id: str | None = None
    filing_code: str | None = None
    filing_code_description: str | None = None
    description: str | None = None
    submitted: datetime | None = None
    docketed: datetime | None = None
    submitter: str | None = None
    submitter_full_name: str | None = None
    event_type: str | None = None
    jurisdiction: str | None = None
    jurisdiction_key: str | None = None
    external_key: str | None = None
    is_hidden_from_public: bool = False
    has_manual_security_override: bool = False
    has_hidden_document: bool = False
    has_no_document: bool = False
    has_no_reported_documents: bool = False
    document_index_number: str | None = None
    timestamp_create: datetime | None = None
    doc_description: str | None = None
    doc_category_code: str | None = None
    doc_filing_code: str | None = None
    doc_page_count: int | None = None
    doc_text_content: str | None = None
    raw_payload: dict[str, Any] | None = None

    @property
    def event_uid(self) -> str:
        return build_uid(
            "event",
            self.case_data_id,
            self.filing_id,
            self.document_index_number,
            self.timestamp_create.isoformat() if self.timestamp_create else "",
            self.doc_description,
            self.doc_filing_code,
            self.description,
        )

    @classmethod
    def from_events_payload(
        cls,
        case_data_id: str,
        payloads: Iterable[dict[str, Any]] | None,
    ) -> list["ResearchTexasEvent"]:
        flattened: list[ResearchTexasEvent] = []
        for payload in payloads or []:
            documents = payload.get("documents") or [None]
            for document in documents:
                flattened.append(
                    cls(
                        case_data_id=case_data_id,
                        filing_id=clean_text(payload.get("filingID") or payload.get("filingId")),
                        ofs_filing_id=clean_text(payload.get("ofsFilingID") or payload.get("ofsFilingId")),
                        filing_code=clean_text(payload.get("filingCode")),
                        filing_code_description=clean_text(payload.get("filingCodeDescription")),
                        description=clean_text(payload.get("description")),
                        submitted=parse_iso_datetime(payload.get("submitted")),
                        docketed=parse_iso_datetime(payload.get("docketed")),
                        submitter=clean_text(payload.get("submitter")),
                        submitter_full_name=clean_text(payload.get("submitterFullName")),
                        event_type=clean_text(payload.get("eventType")),
                        jurisdiction=clean_text(payload.get("jurisdiction")),
                        jurisdiction_key=clean_text(payload.get("jurisdictionKey")),
                        external_key=clean_text(payload.get("externalKey")),
                        is_hidden_from_public=bool(payload.get("isHiddenFromPublic")),
                        has_manual_security_override=bool(payload.get("hasManualSecurityOverride")),
                        has_hidden_document=bool(payload.get("hasHiddenDocument")),
                        has_no_document=bool(payload.get("hasNoDocument")),
                        has_no_reported_documents=bool(payload.get("hasNoReportedDocuments")),
                        document_index_number=clean_text(payload.get("documentIndexNumber")),
                        timestamp_create=parse_iso_datetime(payload.get("timestampCreate")),
                        doc_description=clean_text((document or {}).get("description")),
                        doc_category_code=clean_text((document or {}).get("documentCategoryCode")),
                        doc_filing_code=clean_text((document or {}).get("filingCode")),
                        doc_page_count=clean_int((document or {}).get("pageCount")),
                        doc_text_content=clean_text((document or {}).get("textContent")),
                        raw_payload={
                            "event": payload,
                            "document": document,
                        },
                    )
                )
        return flattened

    def to_record(self, *, fetched_at: datetime) -> dict[str, Any]:
        return {
            "event_uid": self.event_uid,
            "case_data_id": self.case_data_id,
            "filing_id": self.filing_id,
            "ofs_filing_id": self.ofs_filing_id,
            "filing_code": self.filing_code,
            "filing_code_description": self.filing_code_description,
            "description": self.description,
            "submitted": self.submitted,
            "docketed": self.docketed,
            "submitter": self.submitter,
            "submitter_full_name": self.submitter_full_name,
            "event_type": self.event_type,
            "jurisdiction": self.jurisdiction,
            "jurisdiction_key": self.jurisdiction_key,
            "external_key": self.external_key,
            "is_hidden_from_public": self.is_hidden_from_public,
            "has_manual_security_override": self.has_manual_security_override,
            "has_hidden_document": self.has_hidden_document,
            "has_no_document": self.has_no_document,
            "has_no_reported_documents": self.has_no_reported_documents,
            "document_index_number": self.document_index_number,
            "timestamp_create": self.timestamp_create,
            "doc_description": self.doc_description,
            "doc_category_code": self.doc_category_code,
            "doc_filing_code": self.doc_filing_code,
            "doc_page_count": self.doc_page_count,
            "doc_text_content": self.doc_text_content,
            "fetched_at": fetched_at,
            "updated_at": fetched_at,
            "raw_payload": json_dumps(self.raw_payload),
        }

    def to_dataframe_row(self) -> dict[str, Any]:
        return {
            "filing_id": self.filing_id or "",
            "ofs_filing_id": self.ofs_filing_id or "",
            "filing_code": self.filing_code or "",
            "filing_code_description": self.filing_code_description or "",
            "description": self.description or "",
            "submitted": self.submitted.isoformat() if self.submitted else "",
            "docketed": self.docketed.isoformat() if self.docketed else "",
            "submitter": self.submitter or "",
            "submitter_full_name": self.submitter_full_name or "",
            "event_type": self.event_type or "",
            "jurisdiction": self.jurisdiction or "",
            "jurisdiction_key": self.jurisdiction_key or "",
            "external_key": self.external_key or "",
            "is_hidden_from_public": self.is_hidden_from_public,
            "has_manual_security_override": self.has_manual_security_override,
            "has_hidden_document": self.has_hidden_document,
            "has_no_document": self.has_no_document,
            "has_no_reported_documents": self.has_no_reported_documents,
            "document_index_number": self.document_index_number or "",
            "timestamp_create": self.timestamp_create.isoformat() if self.timestamp_create else "",
            "doc_description": self.doc_description or "",
            "doc_category_code": self.doc_category_code or "",
            "doc_filing_code": self.doc_filing_code or "",
            "doc_page_count": self.doc_page_count or 0,
            "doc_text_content": (self.doc_text_content or "").replace("\n", " "),
        }


@dataclass(slots=True)
class ResearchTexasCaseSeed:
    case_data_id: str
    case_number: str
    jurisdiction: str
    case_category_code: str | None = None
    case_type_code: str | None = None
    case_sub_type_code: str | None = None
    description: str | None = None
    date_filed_raw: str | None = None
    status: str | None = None
    status_actual: str | None = None
    judicial_officer_name: str | None = None
    party_names: list[str] = field(default_factory=list)
    party_emails: list[str] = field(default_factory=list)
    attorney_names: list[str] = field(default_factory=list)
    attorney_bar_numbers: list[str] = field(default_factory=list)
    attorney_firm_names: list[str] = field(default_factory=list)
    raw_payload: dict[str, Any] | None = None

    @classmethod
    def from_record(cls, record: Any) -> "ResearchTexasCaseSeed":
        as_dict = dict(record)
        return cls(
            case_data_id=str(as_dict.get("caseDataID") or as_dict.get("case_data_id") or ""),
            case_number=str(as_dict.get("caseNumber") or as_dict.get("case_number") or ""),
            jurisdiction=str(as_dict.get("jurisdiction") or ""),
            case_category_code=clean_text(as_dict.get("caseCategoryCode") or as_dict.get("case_category_code")),
            case_type_code=clean_text(as_dict.get("caseTypeCode") or as_dict.get("case_type_code")),
            case_sub_type_code=clean_text(as_dict.get("caseSubTypeCode") or as_dict.get("case_sub_type_code")),
            description=clean_text(as_dict.get("description")),
            date_filed_raw=clean_text(as_dict.get("dateFiled") or as_dict.get("date_filed")),
            status=clean_text(as_dict.get("status")),
            status_actual=clean_text(as_dict.get("statusActual") or as_dict.get("status_actual")),
            judicial_officer_name=clean_text(as_dict.get("judicialOfficerName") or as_dict.get("judicial_officer_name")),
            party_names=split_delimited(as_dict.get("party_names")),
            party_emails=split_delimited(as_dict.get("party_emails")),
            attorney_names=split_delimited(as_dict.get("attorney_names")),
            attorney_bar_numbers=split_delimited(as_dict.get("attorney_bar_numbers")),
            attorney_firm_names=split_delimited(as_dict.get("attorney_firm_names")),
            raw_payload=as_dict,
        )


@dataclass(slots=True)
class ResearchTexasCase:
    case_data_id: str
    case_number: str | None = None
    jurisdiction: str | None = None
    jurisdiction_id: int | None = None
    jurisdiction_key: str | None = None
    external_source: str | None = None
    case_category_code: str | None = None
    case_type_code: str | None = None
    case_sub_type_code: str | None = None
    description: str | None = None
    date_filed_raw: str | None = None
    status: str | None = None
    status_actual: str | None = None
    judicial_officer_name: str | None = None
    party_count: int | None = None
    case_last_refreshed_raw: str | None = None
    is_hidden_from_public: bool = False
    is_sealed: bool = False
    case_has_active_warrant: bool = False
    in_folder: str | None = None
    client_reference_number: str | None = None
    external_key: str | None = None
    ofs_case_data_id: str | None = None
    parties: list[ResearchTexasParty] = field(default_factory=list)
    standalone_attorneys: list[ResearchTexasAttorney] = field(default_factory=list)
    seed_source: str | None = None
    seed_query: str | None = None
    matched_from_seed: bool = False
    raw_payload: dict[str, Any] | None = None

    @property
    def date_filed(self) -> datetime | None:
        return parse_iso_datetime(self.date_filed_raw)

    @property
    def case_last_refreshed(self) -> datetime | None:
        return parse_iso_datetime(self.case_last_refreshed_raw)

    @classmethod
    def from_search_hit(
        cls,
        hit: dict[str, Any],
        *,
        seed_source: str | None = None,
        seed_query: str | None = None,
        matched_from_seed: bool = False,
    ) -> "ResearchTexasCase":
        parties = [
            ResearchTexasParty.from_payload(party)
            for party in (hit.get("parties") or [])
            if isinstance(party, dict)
        ]
        return cls(
            case_data_id=str(hit.get("caseDataID") or hit.get("caseDataId") or ""),
            case_number=clean_text(hit.get("caseNumber")),
            jurisdiction=clean_text(hit.get("jurisdiction")),
            jurisdiction_id=clean_int(hit.get("jurisdictionID")),
            jurisdiction_key=clean_text(hit.get("jurisdictionKey")),
            external_source=clean_text(hit.get("externalSource")),
            case_category_code=clean_text(hit.get("caseCategoryCode")),
            case_type_code=clean_text(hit.get("caseTypeCode")),
            case_sub_type_code=clean_text(hit.get("caseSubTypeCode")),
            description=clean_text(hit.get("description")),
            date_filed_raw=clean_text(hit.get("dateFiled")),
            status=clean_text(hit.get("status")),
            status_actual=clean_text(hit.get("statusActual")),
            judicial_officer_name=clean_text(hit.get("judicialOfficerName")),
            party_count=clean_int(hit.get("partyCount")),
            case_last_refreshed_raw=clean_text(hit.get("caseLastRefreshed")),
            is_hidden_from_public=bool(hit.get("isHiddenFromPublic")),
            is_sealed=bool(hit.get("isSealed")),
            case_has_active_warrant=bool(hit.get("caseHasActiveWarrant")),
            in_folder=clean_text(hit.get("inFolder")),
            client_reference_number=clean_text(hit.get("clientReferenceNumber")),
            external_key=clean_text(hit.get("externalKey")),
            ofs_case_data_id=clean_text(hit.get("ofsCaseDataID")),
            parties=parties,
            seed_source=seed_source,
            seed_query=seed_query,
            matched_from_seed=matched_from_seed,
            raw_payload=hit,
        )

    @classmethod
    def from_seed(
        cls,
        seed: ResearchTexasCaseSeed,
        *,
        seed_source: str = "all_cases_seed",
        matched_from_seed: bool = False,
    ) -> "ResearchTexasCase":
        parties: list[ResearchTexasParty] = []
        for index, party_name in enumerate(seed.party_names):
            email = seed.party_emails[index] if index < len(seed.party_emails) else None
            parties.append(
                ResearchTexasParty(
                    party_name=party_name,
                    email=email,
                    raw_payload={"seed_source": "all_cases"},
                )
            )

        standalone_attorneys: list[ResearchTexasAttorney] = []
        for index, attorney_name in enumerate(seed.attorney_names):
            bar_number = (
                seed.attorney_bar_numbers[index]
                if index < len(seed.attorney_bar_numbers)
                else None
            )
            firm_name = (
                seed.attorney_firm_names[index]
                if index < len(seed.attorney_firm_names)
                else None
            )
            standalone_attorneys.append(
                ResearchTexasAttorney(
                    attorney_name=attorney_name,
                    bar_number=bar_number,
                    firm_name=firm_name,
                    raw_payload={"seed_source": "all_cases"},
                )
            )

        return cls(
            case_data_id=seed.case_data_id,
            case_number=seed.case_number,
            jurisdiction=seed.jurisdiction,
            case_category_code=seed.case_category_code,
            case_type_code=seed.case_type_code,
            case_sub_type_code=seed.case_sub_type_code,
            description=seed.description,
            date_filed_raw=seed.date_filed_raw,
            status=seed.status,
            status_actual=seed.status_actual,
            judicial_officer_name=seed.judicial_officer_name,
            party_count=len(seed.party_names) or None,
            parties=parties,
            standalone_attorneys=standalone_attorneys,
            seed_source=seed_source,
            seed_query=seed.case_number,
            matched_from_seed=matched_from_seed,
            raw_payload=seed.raw_payload,
        )

    def all_attorney_records(self, *, fetched_at: datetime) -> list[dict[str, Any]]:
        records: list[dict[str, Any]] = []
        for party_index, party in enumerate(self.parties):
            party_uid = party.uid(case_data_id=self.case_data_id, party_index=party_index)
            for attorney_index, attorney in enumerate(party.attorneys):
                records.append(
                    attorney.to_record(
                        case_data_id=self.case_data_id,
                        party_uid=party_uid,
                        attorney_index=attorney_index,
                        fetched_at=fetched_at,
                    )
                )
        for attorney_index, attorney in enumerate(self.standalone_attorneys):
            records.append(
                attorney.to_record(
                    case_data_id=self.case_data_id,
                    party_uid=None,
                    attorney_index=attorney_index,
                    fetched_at=fetched_at,
                )
            )
        return records

    def party_records(self, *, fetched_at: datetime) -> list[dict[str, Any]]:
        return [
            party.to_record(
                case_data_id=self.case_data_id,
                party_index=index,
                fetched_at=fetched_at,
            )
            for index, party in enumerate(self.parties)
        ]

    def to_record(self, *, fetched_at: datetime) -> dict[str, Any]:
        return {
            "case_data_id": self.case_data_id,
            "case_number": self.case_number,
            "jurisdiction": self.jurisdiction,
            "jurisdiction_id": self.jurisdiction_id,
            "jurisdiction_key": self.jurisdiction_key,
            "external_source": self.external_source,
            "case_category_code": self.case_category_code,
            "case_type_code": self.case_type_code,
            "case_sub_type_code": self.case_sub_type_code,
            "description": self.description,
            "date_filed": self.date_filed,
            "status": self.status,
            "status_actual": self.status_actual,
            "judicial_officer_name": self.judicial_officer_name,
            "party_count": self.party_count,
            "case_last_refreshed": self.case_last_refreshed,
            "is_hidden_from_public": self.is_hidden_from_public,
            "is_sealed": self.is_sealed,
            "case_has_active_warrant": self.case_has_active_warrant,
            "in_folder": self.in_folder,
            "client_reference_number": self.client_reference_number,
            "external_key": self.external_key,
            "ofs_case_data_id": self.ofs_case_data_id,
            "seed_source": self.seed_source,
            "seed_query": self.seed_query,
            "matched_from_seed": self.matched_from_seed,
            "fetched_at": fetched_at,
            "updated_at": fetched_at,
            "raw_payload": json_dumps(self.raw_payload),
        }


def events_to_dataframe(events: Iterable[ResearchTexasEvent]) -> pd.DataFrame:
    return pd.DataFrame([event.to_dataframe_row() for event in events])


class ResearchTxCaseEvents:
    def __init__(self, data: Iterable[dict[str, Any]]):
        rows = ResearchTexasEvent.from_events_payload("", data)
        self.as_dataframe = events_to_dataframe(rows)

    @classmethod
    def from_event_models(
        cls,
        events: Iterable[ResearchTexasEvent],
    ) -> "ResearchTxCaseEvents":
        instance = cls([])
        instance.as_dataframe = events_to_dataframe(events)
        return instance
