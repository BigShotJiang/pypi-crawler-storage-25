from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Iterable

import asyncpg

from fudstop4.apis._researchtx.researchtx_models import (
    ResearchTexasCase,
    ResearchTexasCaseSeed,
    ResearchTexasEvent,
)


IVD_FILTER_SQL = """
(
    coalesce({category_column}, '') ilike '%Title IV-D%'
    or coalesce({type_column}, '') ilike '%Title IV-D%'
    or coalesce({type_column}, '') ilike '%Paternity%'
    or coalesce({type_column}, '') ilike '%Child Support%'
    or coalesce({type_column}, '') ilike '%Enforcement%'
)
"""


class ResearchTexasStore:
    def __init__(
        self,
        *,
        host: str = "localhost",
        user: str = "chuck",
        password: str = "fud",
        database: str = "courts",
        port: int = 5432,
        table_prefix: str = "researchtx",
    ):
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self.port = int(port)
        self.table_prefix = table_prefix
        self.pool: asyncpg.Pool | None = None

    @property
    def cases_table(self) -> str:
        return f"{self.table_prefix}_cases"

    @property
    def events_table(self) -> str:
        return f"{self.table_prefix}_case_events"

    @property
    def parties_table(self) -> str:
        return f"{self.table_prefix}_case_parties"

    @property
    def attorneys_table(self) -> str:
        return f"{self.table_prefix}_case_attorneys"

    @property
    def runs_table(self) -> str:
        return f"{self.table_prefix}_harvest_runs"

    @property
    def checkpoints_table(self) -> str:
        return f"{self.table_prefix}_harvest_checkpoints"

    @property
    def rollups_table(self) -> str:
        return f"{self.table_prefix}_ivd_case_rollups"

    @property
    def scenarios_table(self) -> str:
        return f"{self.table_prefix}_ivd_incentive_scenarios"

    async def connect(self) -> asyncpg.Pool:
        if self.pool is None:
            self.pool = await asyncpg.create_pool(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                port=self.port,
                min_size=1,
                max_size=10,
            )
        return self.pool

    async def close(self) -> None:
        if self.pool is not None:
            await self.pool.close()
            self.pool = None

    async def ensure_schema(self) -> None:
        await self.connect()
        statements = [
            f"""
            create table if not exists public.{self.cases_table} (
                case_data_id text primary key,
                case_number text,
                jurisdiction text,
                jurisdiction_id integer,
                jurisdiction_key text,
                external_source text,
                case_category_code text,
                case_type_code text,
                case_sub_type_code text,
                description text,
                date_filed timestamptz,
                status text,
                status_actual text,
                judicial_officer_name text,
                party_count integer,
                case_last_refreshed timestamptz,
                is_hidden_from_public boolean,
                is_sealed boolean,
                case_has_active_warrant boolean,
                in_folder text,
                client_reference_number text,
                external_key text,
                ofs_case_data_id text,
                seed_source text,
                seed_query text,
                matched_from_seed boolean,
                fetched_at timestamptz not null,
                updated_at timestamptz not null,
                raw_payload text
            )
            """,
            f"create index if not exists idx_{self.cases_table}_case_number on public.{self.cases_table}(case_number)",
            f"create index if not exists idx_{self.cases_table}_jurisdiction on public.{self.cases_table}(jurisdiction)",
            f"create index if not exists idx_{self.cases_table}_type on public.{self.cases_table}(case_type_code)",
            f"""
            create table if not exists public.{self.parties_table} (
                party_uid text primary key,
                case_data_id text not null references public.{self.cases_table}(case_data_id) on delete cascade,
                party_index integer not null,
                party_name text,
                party_type_code text,
                email text,
                attorney_count integer,
                fetched_at timestamptz not null,
                updated_at timestamptz not null,
                raw_payload text
            )
            """,
            f"create index if not exists idx_{self.parties_table}_case_data_id on public.{self.parties_table}(case_data_id)",
            f"""
            create table if not exists public.{self.attorneys_table} (
                attorney_uid text primary key,
                case_data_id text not null references public.{self.cases_table}(case_data_id) on delete cascade,
                party_uid text references public.{self.parties_table}(party_uid) on delete cascade,
                attorney_index integer not null,
                attorney_name text,
                bar_number text,
                firm_name text,
                email text,
                fetched_at timestamptz not null,
                updated_at timestamptz not null,
                raw_payload text
            )
            """,
            f"create index if not exists idx_{self.attorneys_table}_case_data_id on public.{self.attorneys_table}(case_data_id)",
            f"""
            create table if not exists public.{self.events_table} (
                event_uid text primary key,
                case_data_id text not null references public.{self.cases_table}(case_data_id) on delete cascade,
                filing_id text,
                ofs_filing_id text,
                filing_code text,
                filing_code_description text,
                description text,
                submitted timestamptz,
                docketed timestamptz,
                submitter text,
                submitter_full_name text,
                event_type text,
                jurisdiction text,
                jurisdiction_key text,
                external_key text,
                is_hidden_from_public boolean,
                has_manual_security_override boolean,
                has_hidden_document boolean,
                has_no_document boolean,
                has_no_reported_documents boolean,
                document_index_number text,
                timestamp_create timestamptz,
                doc_description text,
                doc_category_code text,
                doc_filing_code text,
                doc_page_count integer,
                doc_text_content text,
                fetched_at timestamptz not null,
                updated_at timestamptz not null,
                raw_payload text
            )
            """,
            f"create index if not exists idx_{self.events_table}_case_data_id on public.{self.events_table}(case_data_id)",
            f"""
            create table if not exists public.{self.runs_table} (
                run_id text primary key,
                run_type text not null,
                status text not null,
                started_at timestamptz not null,
                completed_at timestamptz,
                jurisdiction_filter text,
                seed_source text,
                case_limit integer,
                processed_cases integer not null default 0,
                upserted_cases integer not null default 0,
                upserted_parties integer not null default 0,
                upserted_attorneys integer not null default 0,
                upserted_events integer not null default 0,
                last_case_number text,
                last_case_data_id text,
                error_message text,
                metadata_json text
            )
            """,
            f"""
            create table if not exists public.{self.checkpoints_table} (
                checkpoint_key text primary key,
                run_id text references public.{self.runs_table}(run_id) on delete set null,
                checkpoint_type text not null,
                cursor_offset integer not null default 0,
                last_case_number text,
                last_case_data_id text,
                metadata_json text,
                updated_at timestamptz not null
            )
            """,
            f"""
            create table if not exists public.{self.rollups_table} (
                case_data_id text primary key references public.{self.cases_table}(case_data_id) on delete cascade,
                case_number text,
                jurisdiction text,
                case_category_code text,
                case_type_code text,
                support_lane text,
                date_filed timestamptz,
                age_days integer,
                age_bucket text,
                status text,
                status_bucket text,
                is_blank_status boolean,
                is_open_like boolean,
                is_reopened_like boolean,
                is_closed_like boolean,
                is_eligible_for_obligated_caseload boolean,
                is_stale_1y boolean,
                is_stale_3y boolean,
                is_stale_5y boolean,
                is_stale_10y boolean,
                has_oag_party boolean,
                has_holly_hayes boolean,
                has_oag_routed_attorney boolean,
                party_count integer,
                attorney_count integer,
                event_count integer,
                last_event_at timestamptz,
                party_names text,
                attorney_names text,
                updated_at timestamptz not null
            )
            """,
            f"""
            create table if not exists public.{self.scenarios_table} (
                analysis_run_id text not null,
                scenario_name text not null,
                jurisdiction text not null,
                generated_at timestamptz not null,
                case_count integer not null,
                eligible_case_count integer not null,
                open_like_case_count integer not null,
                blank_status_case_count integer not null,
                reopened_case_count integer not null,
                stale_case_count integer not null,
                oag_routed_case_count integer not null,
                enforcement_case_count integer not null,
                monthly_base_reimbursement_exposure numeric not null,
                monthly_quality_bonus_exposure numeric not null,
                annual_base_reimbursement_exposure numeric not null,
                annual_quality_bonus_exposure numeric not null,
                annual_current_support_collections_gross numeric not null,
                annual_arrears_collections_gross numeric not null,
                annual_collection_incentive_share_estimate numeric not null,
                annual_enforcement_cost_estimate numeric not null,
                annual_net_exposure numeric not null,
                assumptions_json text not null,
                primary key (analysis_run_id, scenario_name)
            )
            """,
        ]
        async with self.pool.acquire() as connection:
            for statement in statements:
                await connection.execute(statement)
            await connection.execute(
                f'alter table public.{self.events_table} add column if not exists ofs_filing_id text'
            )
            await connection.execute(
                f'alter table public.{self.events_table} add column if not exists submitter text'
            )

    def _serialize_row(self, row: dict[str, Any], columns: list[str]) -> list[Any]:
        values: list[Any] = []
        for column in columns:
            value = row.get(column)
            if isinstance(value, (dict, list)):
                values.append(json.dumps(value, sort_keys=True, default=str))
            else:
                values.append(value)
        return values

    async def _upsert_rows(
        self,
        *,
        table_name: str,
        rows: Iterable[dict[str, Any]],
        conflict_columns: list[str],
        update_columns: list[str] | None = None,
    ) -> int:
        row_list = [row for row in rows if row]
        if not row_list:
            return 0

        columns = list(row_list[0].keys())
        updates = update_columns or [column for column in columns if column not in conflict_columns]
        column_sql = ", ".join(f'"{column}"' for column in columns)
        placeholders = ", ".join(f"${index}" for index in range(1, len(columns) + 1))
        conflict_sql = ", ".join(f'"{column}"' for column in conflict_columns)
        update_sql = ", ".join(f'"{column}" = EXCLUDED."{column}"' for column in updates)
        query = (
            f'insert into public.{table_name} ({column_sql}) values ({placeholders}) '
            f'on conflict ({conflict_sql}) do update set {update_sql}'
        )
        records = [self._serialize_row(row, columns) for row in row_list]

        async with self.pool.acquire() as connection:
            async with connection.transaction():
                await connection.executemany(query, records)
        return len(row_list)

    async def upsert_case_bundle(self, case: ResearchTexasCase) -> dict[str, int]:
        fetched_at = datetime.now(timezone.utc)
        case_count = await self._upsert_rows(
            table_name=self.cases_table,
            rows=[case.to_record(fetched_at=fetched_at)],
            conflict_columns=["case_data_id"],
        )
        party_records = case.party_records(fetched_at=fetched_at)
        party_count = await self._upsert_rows(
            table_name=self.parties_table,
            rows=party_records,
            conflict_columns=["party_uid"],
        )
        attorney_records = case.all_attorney_records(fetched_at=fetched_at)
        attorney_count = await self._upsert_rows(
            table_name=self.attorneys_table,
            rows=attorney_records,
            conflict_columns=["attorney_uid"],
        )
        return {
            "cases": case_count,
            "parties": party_count,
            "attorneys": attorney_count,
        }

    async def upsert_events(self, events: Iterable[ResearchTexasEvent]) -> int:
        fetched_at = datetime.now(timezone.utc)
        return await self._upsert_rows(
            table_name=self.events_table,
            rows=[event.to_record(fetched_at=fetched_at) for event in events],
            conflict_columns=["event_uid"],
        )

    async def start_harvest_run(
        self,
        *,
        run_type: str,
        jurisdiction_filter: str,
        seed_source: str,
        case_limit: int | None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        run_id = str(uuid.uuid4())
        row = {
            "run_id": run_id,
            "run_type": run_type,
            "status": "running",
            "started_at": datetime.now(timezone.utc),
            "completed_at": None,
            "jurisdiction_filter": jurisdiction_filter,
            "seed_source": seed_source,
            "case_limit": case_limit,
            "processed_cases": 0,
            "upserted_cases": 0,
            "upserted_parties": 0,
            "upserted_attorneys": 0,
            "upserted_events": 0,
            "last_case_number": None,
            "last_case_data_id": None,
            "error_message": None,
            "metadata_json": json.dumps(metadata or {}, sort_keys=True, default=str),
        }
        await self._upsert_rows(
            table_name=self.runs_table,
            rows=[row],
            conflict_columns=["run_id"],
        )
        return run_id

    async def update_harvest_run(
        self,
        run_id: str,
        *,
        status: str,
        processed_cases: int,
        upserted_cases: int,
        upserted_parties: int,
        upserted_attorneys: int,
        upserted_events: int,
        last_case_number: str | None,
        last_case_data_id: str | None,
        error_message: str | None = None,
        completed: bool = False,
    ) -> None:
        completed_at = datetime.now(timezone.utc) if completed else None
        query = f"""
            update public.{self.runs_table}
            set status = $2,
                processed_cases = $3,
                upserted_cases = $4,
                upserted_parties = $5,
                upserted_attorneys = $6,
                upserted_events = $7,
                last_case_number = $8,
                last_case_data_id = $9,
                error_message = $10,
                completed_at = coalesce($11, completed_at)
            where run_id = $1
        """
        async with self.pool.acquire() as connection:
            await connection.execute(
                query,
                run_id,
                status,
                processed_cases,
                upserted_cases,
                upserted_parties,
                upserted_attorneys,
                upserted_events,
                last_case_number,
                last_case_data_id,
                error_message,
                completed_at,
            )

    async def load_checkpoint(self, checkpoint_key: str) -> dict[str, Any] | None:
        query = f"""
            select checkpoint_key, run_id, checkpoint_type, cursor_offset,
                   last_case_number, last_case_data_id, metadata_json, updated_at
            from public.{self.checkpoints_table}
            where checkpoint_key = $1
        """
        async with self.pool.acquire() as connection:
            row = await connection.fetchrow(query, checkpoint_key)
        return dict(row) if row else None

    async def upsert_checkpoint(
        self,
        *,
        checkpoint_key: str,
        run_id: str | None,
        checkpoint_type: str,
        cursor_offset: int,
        last_case_number: str | None,
        last_case_data_id: str | None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        row = {
            "checkpoint_key": checkpoint_key,
            "run_id": run_id,
            "checkpoint_type": checkpoint_type,
            "cursor_offset": cursor_offset,
            "last_case_number": last_case_number,
            "last_case_data_id": last_case_data_id,
            "metadata_json": json.dumps(metadata or {}, sort_keys=True, default=str),
            "updated_at": datetime.now(timezone.utc),
        }
        await self._upsert_rows(
            table_name=self.checkpoints_table,
            rows=[row],
            conflict_columns=["checkpoint_key"],
        )

    async def fetch_tarrant_ivd_seed_cases(
        self,
        *,
        limit: int,
        offset: int,
    ) -> list[ResearchTexasCaseSeed]:
        filter_sql = IVD_FILTER_SQL.format(
            category_column='"caseCategoryCode"',
            type_column='"caseTypeCode"',
        )
        query = f"""
            select
                "caseDataID",
                "caseNumber",
                "jurisdiction",
                "caseCategoryCode",
                "caseTypeCode",
                "caseSubTypeCode",
                "description",
                "dateFiled",
                "status",
                "statusActual",
                "judicialOfficerName",
                "party_names",
                "party_emails",
                "attorney_names",
                "attorney_bar_numbers",
                "attorney_firm_names"
            from public.all_cases
            where "jurisdiction" = 'Tarrant County - District Clerk'
              and {filter_sql}
              and coalesce("caseDataID", '') <> ''
              and coalesce("caseNumber", '') <> ''
            order by "dateFiled" asc nulls last, "caseNumber" asc
            offset $1
            limit $2
        """
        async with self.pool.acquire() as connection:
            rows = await connection.fetch(query, int(offset), int(limit))
        return [ResearchTexasCaseSeed.from_record(row) for row in rows]

    async def fetch_named_attorney_seed_cases(
        self,
        *,
        jurisdiction: str,
        target_names: list[str] | None,
        bar_numbers: list[str] | None,
        limit: int,
        offset: int,
    ) -> list[ResearchTexasCaseSeed]:
        normalized_names = [name.strip().upper() for name in (target_names or []) if name and name.strip()]
        normalized_bars = [str(bar).strip() for bar in (bar_numbers or []) if str(bar).strip()]
        if not normalized_names and not normalized_bars:
            return []

        conditions: list[str] = []
        args: list[Any] = [jurisdiction]
        next_index = 2

        if normalized_names:
            name_patterns = [f"%{name}%" for name in normalized_names]
            conditions.append(
                f"""(
                    upper(coalesce(attorney_name, '')) like any(${next_index}::text[])
                    or upper(coalesce(attorney_names, '')) like any(${next_index}::text[])
                    or upper(coalesce(matched_attorney_names, '')) like any(${next_index}::text[])
                )"""
            )
            args.append(name_patterns)
            next_index += 1

        if normalized_bars:
            bar_patterns = [f"%{bar}%" for bar in normalized_bars]
            conditions.append(
                f"""(
                    coalesce(attorney_bar_number::text, '') = any(${next_index}::text[])
                    or coalesce(attorney_bar_numbers, '') like any(${next_index + 1}::text[])
                )"""
            )
            args.append(normalized_bars)
            args.append(bar_patterns)
            next_index += 2

        match_sql = " or ".join(conditions)
        query = f"""
            with attorney_seed_matches as (
                select distinct on ("caseDataID")
                    "caseDataID",
                    "caseNumber",
                    "jurisdiction",
                    "caseCategoryCode",
                    "caseTypeCode",
                    "caseSubTypeCode",
                    "description",
                    "dateFiled",
                    "status",
                    "statusActual",
                    "judicialOfficerName",
                    party_names,
                    party_emails,
                    attorney_names,
                    attorney_bar_numbers,
                    attorney_firm_names
                from public.all_cases
                where "jurisdiction" = $1
                  and coalesce("caseDataID", '') <> ''
                  and coalesce("caseNumber", '') <> ''
                  and ({match_sql})
                order by "caseDataID", "dateFiled" desc nulls last, "caseNumber" asc
            )
            select *
            from attorney_seed_matches
            order by "dateFiled" desc nulls last, "caseNumber" asc
            offset ${next_index}
            limit ${next_index + 1}
        """
        args.extend([int(offset), int(limit)])
        async with self.pool.acquire() as connection:
            rows = await connection.fetch(query, *args)
        return [ResearchTexasCaseSeed.from_record(row) for row in rows]

    async def fetch_rollup_source(
        self,
        *,
        jurisdiction: str,
    ) -> dict[str, list[dict[str, Any]]]:
        filter_sql = IVD_FILTER_SQL.format(
            category_column="case_category_code",
            type_column="case_type_code",
        )
        cases_query = f"""
            select *
            from public.{self.cases_table}
            where jurisdiction = $1
              and {filter_sql}
            order by date_filed asc nulls last, case_number asc
        """
        parties_query = f"select * from public.{self.parties_table}"
        attorneys_query = f"select * from public.{self.attorneys_table}"
        events_query = f"""
            select case_data_id, count(*) as event_count,
                   max(coalesce(submitted, docketed, timestamp_create)) as last_event_at
            from public.{self.events_table}
            group by case_data_id
        """
        async with self.pool.acquire() as connection:
            cases = await connection.fetch(cases_query, jurisdiction)
            parties = await connection.fetch(parties_query)
            attorneys = await connection.fetch(attorneys_query)
            events = await connection.fetch(events_query)
        return {
            "cases": [dict(row) for row in cases],
            "parties": [dict(row) for row in parties],
            "attorneys": [dict(row) for row in attorneys],
            "events": [dict(row) for row in events],
        }

    async def upsert_rollups(self, rows: Iterable[dict[str, Any]]) -> int:
        return await self._upsert_rows(
            table_name=self.rollups_table,
            rows=list(rows),
            conflict_columns=["case_data_id"],
        )

    async def insert_scenarios(self, rows: Iterable[dict[str, Any]]) -> int:
        return await self._upsert_rows(
            table_name=self.scenarios_table,
            rows=list(rows),
            conflict_columns=["analysis_run_id", "scenario_name"],
        )
