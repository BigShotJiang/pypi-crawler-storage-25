from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from fudstop4.apis._researchtx.researchtx_models import (
    ResearchTexasCase,
    ResearchTexasCaseSeed,
)
from fudstop4.apis._researchtx.researchtx_sdk import (
    ResearchTexasAsyncClient,
    ResearchTexasAuthError,
)
from fudstop4.apis._researchtx.researchtx_store import ResearchTexasStore


DEFAULT_TARRANT_JURISDICTION = "Tarrant County - District Clerk"
DEFAULT_CHECKPOINT_KEY = "researchtx_tarrant_ivd_pilot"
DEFAULT_ATTORNEY_TARGET_CHECKPOINT_KEY = "researchtx_named_attorney_targets"


@dataclass(slots=True)
class HarvestReport:
    run_id: str
    processed_cases: int
    upserted_cases: int
    upserted_parties: int
    upserted_attorneys: int
    upserted_events: int
    last_case_number: str | None
    last_case_data_id: str | None
    resumed_from_offset: int
    checkpoint_key: str


class TarrantIVDPilotHarvester:
    def __init__(
        self,
        *,
        client: ResearchTexasAsyncClient,
        store: ResearchTexasStore,
        checkpoint_key: str = DEFAULT_CHECKPOINT_KEY,
        jurisdiction: str = DEFAULT_TARRANT_JURISDICTION,
    ):
        self.client = client
        self.store = store
        self.checkpoint_key = checkpoint_key
        self.jurisdiction = jurisdiction

    async def _resolve_case(
        self,
        seed: ResearchTexasCaseSeed,
        *,
        session,
    ) -> ResearchTexasCase:
        live_case = await self.client.search_case_by_number(
            seed.case_number,
            jurisdiction=seed.jurisdiction,
            case_data_id=seed.case_data_id,
            session=session,
        )
        if live_case is not None:
            live_case.seed_source = "public.all_cases"
            live_case.seed_query = seed.case_number
            live_case.matched_from_seed = True
            return live_case
        return ResearchTexasCase.from_seed(
            seed,
            seed_source="public.all_cases",
            matched_from_seed=False,
        )

    async def harvest(
        self,
        *,
        limit: int | None = None,
        resume: bool = True,
        batch_size: int = 25,
        progress_every: int = 10,
    ) -> HarvestReport:
        await self.store.ensure_schema()

        start_offset = 0
        checkpoint = None
        if resume:
            checkpoint = await self.store.load_checkpoint(self.checkpoint_key)
            if checkpoint:
                start_offset = int(checkpoint.get("cursor_offset") or 0)

        run_id = await self.store.start_harvest_run(
            run_type="tarrant_ivd_pilot",
            jurisdiction_filter=self.jurisdiction,
            seed_source="public.all_cases",
            case_limit=limit,
            metadata={
                "checkpoint_key": self.checkpoint_key,
                "resume": resume,
                "batch_size": batch_size,
            },
        )

        processed_cases = 0
        upserted_cases = 0
        upserted_parties = 0
        upserted_attorneys = 0
        upserted_events = 0
        offset = start_offset
        last_case_number: str | None = checkpoint.get("last_case_number") if checkpoint else None
        last_case_data_id: str | None = checkpoint.get("last_case_data_id") if checkpoint else None

        try:
            async with self.client.session() as session:
                while True:
                    if limit is not None and processed_cases >= int(limit):
                        break

                    remaining = None if limit is None else max(int(limit) - processed_cases, 0)
                    current_batch_size = batch_size if remaining is None else min(batch_size, remaining)
                    if current_batch_size == 0:
                        break

                    seeds = await self.store.fetch_tarrant_ivd_seed_cases(
                        limit=current_batch_size,
                        offset=offset,
                    )
                    if not seeds:
                        break

                    for seed in seeds:
                        if limit is not None and processed_cases >= int(limit):
                            break

                        case = await self._resolve_case(seed, session=session)
                        bundle_counts = await self.store.upsert_case_bundle(case)
                        events = []
                        if case.case_data_id:
                            events = await self.client.get_case_events(
                                case.case_data_id,
                                session=session,
                            )
                        event_count = await self.store.upsert_events(events)

                        processed_cases += 1
                        offset += 1
                        upserted_cases += bundle_counts["cases"]
                        upserted_parties += bundle_counts["parties"]
                        upserted_attorneys += bundle_counts["attorneys"]
                        upserted_events += event_count
                        last_case_number = case.case_number or seed.case_number
                        last_case_data_id = case.case_data_id or seed.case_data_id

                        if progress_every and processed_cases % progress_every == 0:
                            await self.store.update_harvest_run(
                                run_id,
                                status="running",
                                processed_cases=processed_cases,
                                upserted_cases=upserted_cases,
                                upserted_parties=upserted_parties,
                                upserted_attorneys=upserted_attorneys,
                                upserted_events=upserted_events,
                                last_case_number=last_case_number,
                                last_case_data_id=last_case_data_id,
                            )
                            await self.store.upsert_checkpoint(
                                checkpoint_key=self.checkpoint_key,
                                run_id=run_id,
                                checkpoint_type="seed_offset",
                                cursor_offset=offset,
                                last_case_number=last_case_number,
                                last_case_data_id=last_case_data_id,
                                metadata={
                                    "processed_cases": processed_cases,
                                },
                            )

            await self.store.update_harvest_run(
                run_id,
                status="completed",
                processed_cases=processed_cases,
                upserted_cases=upserted_cases,
                upserted_parties=upserted_parties,
                upserted_attorneys=upserted_attorneys,
                upserted_events=upserted_events,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                completed=True,
            )
            await self.store.upsert_checkpoint(
                checkpoint_key=self.checkpoint_key,
                run_id=run_id,
                checkpoint_type="seed_offset",
                cursor_offset=offset,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                metadata={
                    "processed_cases": processed_cases,
                    "completed": True,
                },
            )
            return HarvestReport(
                run_id=run_id,
                processed_cases=processed_cases,
                upserted_cases=upserted_cases,
                upserted_parties=upserted_parties,
                upserted_attorneys=upserted_attorneys,
                upserted_events=upserted_events,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                resumed_from_offset=start_offset,
                checkpoint_key=self.checkpoint_key,
            )
        except ResearchTexasAuthError as exc:
            await self.store.update_harvest_run(
                run_id,
                status="auth_error",
                processed_cases=processed_cases,
                upserted_cases=upserted_cases,
                upserted_parties=upserted_parties,
                upserted_attorneys=upserted_attorneys,
                upserted_events=upserted_events,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                error_message=str(exc),
            )
            await self.store.upsert_checkpoint(
                checkpoint_key=self.checkpoint_key,
                run_id=run_id,
                checkpoint_type="seed_offset",
                cursor_offset=offset,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                metadata={
                    "processed_cases": processed_cases,
                    "error": "auth_error",
                },
            )
            raise


class NamedAttorneyHarvester:
    def __init__(
        self,
        *,
        client: ResearchTexasAsyncClient,
        store: ResearchTexasStore,
        checkpoint_key: str = DEFAULT_ATTORNEY_TARGET_CHECKPOINT_KEY,
        jurisdiction: str = DEFAULT_TARRANT_JURISDICTION,
        target_names: list[str] | None = None,
        bar_numbers: list[str] | None = None,
    ):
        self.client = client
        self.store = store
        self.checkpoint_key = checkpoint_key
        self.jurisdiction = jurisdiction
        self.target_names = [name.strip().upper() for name in (target_names or []) if name and name.strip()]
        self.bar_numbers = [str(bar).strip() for bar in (bar_numbers or []) if str(bar).strip()]

    async def _resolve_case(
        self,
        seed: ResearchTexasCaseSeed,
        *,
        session,
    ) -> ResearchTexasCase:
        live_case = await self.client.search_case_by_number(
            seed.case_number,
            jurisdiction=seed.jurisdiction,
            case_data_id=seed.case_data_id,
            session=session,
        )
        if live_case is not None:
            live_case.seed_source = "public.all_cases_named_attorney"
            live_case.seed_query = seed.case_number
            live_case.matched_from_seed = True
            return live_case
        return ResearchTexasCase.from_seed(
            seed,
            seed_source="public.all_cases_named_attorney",
            matched_from_seed=False,
        )

    async def harvest(
        self,
        *,
        limit: int | None = None,
        resume: bool = True,
        batch_size: int = 25,
        progress_every: int = 10,
    ) -> HarvestReport:
        await self.store.ensure_schema()

        start_offset = 0
        checkpoint = None
        if resume:
            checkpoint = await self.store.load_checkpoint(self.checkpoint_key)
            if checkpoint:
                start_offset = int(checkpoint.get("cursor_offset") or 0)

        run_id = await self.store.start_harvest_run(
            run_type="named_attorney_targets",
            jurisdiction_filter=self.jurisdiction,
            seed_source="public.all_cases_named_attorney",
            case_limit=limit,
            metadata={
                "checkpoint_key": self.checkpoint_key,
                "resume": resume,
                "batch_size": batch_size,
                "target_names": self.target_names,
                "bar_numbers": self.bar_numbers,
            },
        )

        processed_cases = 0
        upserted_cases = 0
        upserted_parties = 0
        upserted_attorneys = 0
        upserted_events = 0
        offset = start_offset
        last_case_number: str | None = checkpoint.get("last_case_number") if checkpoint else None
        last_case_data_id: str | None = checkpoint.get("last_case_data_id") if checkpoint else None

        try:
            async with self.client.session() as session:
                while True:
                    if limit is not None and processed_cases >= int(limit):
                        break

                    remaining = None if limit is None else max(int(limit) - processed_cases, 0)
                    current_batch_size = batch_size if remaining is None else min(batch_size, remaining)
                    if current_batch_size == 0:
                        break

                    seeds = await self.store.fetch_named_attorney_seed_cases(
                        jurisdiction=self.jurisdiction,
                        target_names=self.target_names,
                        bar_numbers=self.bar_numbers,
                        limit=current_batch_size,
                        offset=offset,
                    )
                    if not seeds:
                        break

                    for seed in seeds:
                        if limit is not None and processed_cases >= int(limit):
                            break

                        case = await self._resolve_case(seed, session=session)
                        bundle_counts = await self.store.upsert_case_bundle(case)
                        events = []
                        if case.case_data_id:
                            events = await self.client.get_case_events(
                                case.case_data_id,
                                session=session,
                            )
                        event_count = await self.store.upsert_events(events)

                        processed_cases += 1
                        offset += 1
                        upserted_cases += bundle_counts["cases"]
                        upserted_parties += bundle_counts["parties"]
                        upserted_attorneys += bundle_counts["attorneys"]
                        upserted_events += event_count
                        last_case_number = case.case_number or seed.case_number
                        last_case_data_id = case.case_data_id or seed.case_data_id

                        if progress_every and processed_cases % progress_every == 0:
                            await self.store.update_harvest_run(
                                run_id,
                                status="running",
                                processed_cases=processed_cases,
                                upserted_cases=upserted_cases,
                                upserted_parties=upserted_parties,
                                upserted_attorneys=upserted_attorneys,
                                upserted_events=upserted_events,
                                last_case_number=last_case_number,
                                last_case_data_id=last_case_data_id,
                            )
                            await self.store.upsert_checkpoint(
                                checkpoint_key=self.checkpoint_key,
                                run_id=run_id,
                                checkpoint_type="seed_offset",
                                cursor_offset=offset,
                                last_case_number=last_case_number,
                                last_case_data_id=last_case_data_id,
                                metadata={
                                    "processed_cases": processed_cases,
                                    "target_names": self.target_names,
                                    "bar_numbers": self.bar_numbers,
                                },
                            )

            await self.store.update_harvest_run(
                run_id,
                status="completed",
                processed_cases=processed_cases,
                upserted_cases=upserted_cases,
                upserted_parties=upserted_parties,
                upserted_attorneys=upserted_attorneys,
                upserted_events=upserted_events,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                completed=True,
            )
            await self.store.upsert_checkpoint(
                checkpoint_key=self.checkpoint_key,
                run_id=run_id,
                checkpoint_type="seed_offset",
                cursor_offset=offset,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                metadata={
                    "processed_cases": processed_cases,
                    "completed": True,
                    "target_names": self.target_names,
                    "bar_numbers": self.bar_numbers,
                },
            )
            return HarvestReport(
                run_id=run_id,
                processed_cases=processed_cases,
                upserted_cases=upserted_cases,
                upserted_parties=upserted_parties,
                upserted_attorneys=upserted_attorneys,
                upserted_events=upserted_events,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                resumed_from_offset=start_offset,
                checkpoint_key=self.checkpoint_key,
            )
        except ResearchTexasAuthError as exc:
            await self.store.update_harvest_run(
                run_id,
                status="auth_error",
                processed_cases=processed_cases,
                upserted_cases=upserted_cases,
                upserted_parties=upserted_parties,
                upserted_attorneys=upserted_attorneys,
                upserted_events=upserted_events,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                error_message=str(exc),
            )
            await self.store.upsert_checkpoint(
                checkpoint_key=self.checkpoint_key,
                run_id=run_id,
                checkpoint_type="seed_offset",
                cursor_offset=offset,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                metadata={
                    "processed_cases": processed_cases,
                    "error": "auth_error",
                    "target_names": self.target_names,
                    "bar_numbers": self.bar_numbers,
                },
            )
            raise
        except Exception as exc:
            await self.store.update_harvest_run(
                run_id,
                status="failed",
                processed_cases=processed_cases,
                upserted_cases=upserted_cases,
                upserted_parties=upserted_parties,
                upserted_attorneys=upserted_attorneys,
                upserted_events=upserted_events,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                error_message=str(exc),
            )
            await self.store.upsert_checkpoint(
                checkpoint_key=self.checkpoint_key,
                run_id=run_id,
                checkpoint_type="seed_offset",
                cursor_offset=offset,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                metadata={
                    "processed_cases": processed_cases,
                    "error": "failed",
                    "target_names": self.target_names,
                    "bar_numbers": self.bar_numbers,
                },
            )
            raise
        except Exception as exc:
            await self.store.update_harvest_run(
                run_id,
                status="failed",
                processed_cases=processed_cases,
                upserted_cases=upserted_cases,
                upserted_parties=upserted_parties,
                upserted_attorneys=upserted_attorneys,
                upserted_events=upserted_events,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                error_message=str(exc),
            )
            await self.store.upsert_checkpoint(
                checkpoint_key=self.checkpoint_key,
                run_id=run_id,
                checkpoint_type="seed_offset",
                cursor_offset=offset,
                last_case_number=last_case_number,
                last_case_data_id=last_case_data_id,
                metadata={
                    "processed_cases": processed_cases,
                    "error": "failed",
                },
            )
            raise
