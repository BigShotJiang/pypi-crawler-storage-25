from __future__ import annotations

import json
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Any

from fudstop4.apis._researchtx.researchtx_store import ResearchTexasStore


MONTHLY_PER_CASE_REIMBURSEMENT = 19.0 * 0.66
MONTHLY_QUALITY_BONUS_CAP = 0.40


def _money(value: float) -> Decimal:
    return Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


@dataclass(frozen=True, slots=True)
class IncentiveScenarioConfig:
    name: str
    obligated_case_multiplier: float
    quality_bonus_case_multiplier: float
    quality_bonus_attainment_rate: float
    collections_case_multiplier: float
    avg_current_support_collection: float
    avg_arrears_collection: float
    current_support_incentive_share_rate: float
    arrears_incentive_share_rate: float
    monthly_enforcement_cost_per_case: float


DEFAULT_SCENARIOS = (
    IncentiveScenarioConfig(
        name="conservative",
        obligated_case_multiplier=0.35,
        quality_bonus_case_multiplier=0.25,
        quality_bonus_attainment_rate=0.10,
        collections_case_multiplier=0.01,
        avg_current_support_collection=600.0,
        avg_arrears_collection=150.0,
        current_support_incentive_share_rate=0.01,
        arrears_incentive_share_rate=0.01,
        monthly_enforcement_cost_per_case=35.0,
    ),
    IncentiveScenarioConfig(
        name="base",
        obligated_case_multiplier=0.60,
        quality_bonus_case_multiplier=0.50,
        quality_bonus_attainment_rate=0.50,
        collections_case_multiplier=0.04,
        avg_current_support_collection=900.0,
        avg_arrears_collection=250.0,
        current_support_incentive_share_rate=0.02,
        arrears_incentive_share_rate=0.02,
        monthly_enforcement_cost_per_case=60.0,
    ),
    IncentiveScenarioConfig(
        name="aggressive",
        obligated_case_multiplier=0.85,
        quality_bonus_case_multiplier=0.75,
        quality_bonus_attainment_rate=1.00,
        collections_case_multiplier=0.08,
        avg_current_support_collection=1200.0,
        avg_arrears_collection=400.0,
        current_support_incentive_share_rate=0.03,
        arrears_incentive_share_rate=0.03,
        monthly_enforcement_cost_per_case=85.0,
    ),
)


def _normalize_status(status: str | None) -> str:
    text = (status or "").strip().lower()
    if not text:
        return "blank"
    if "re-open" in text or "reopened" in text:
        return "reopened_like"
    if any(token in text for token in ("open", "active", "pending", "filed")):
        return "open_like"
    if any(token in text for token in ("close", "disposed", "dismiss", "transfer")):
        return "closed_like"
    return "unknown"


def _age_bucket(age_days: int | None) -> str:
    if age_days is None:
        return "unknown"
    if age_days < 365:
        return "<1y"
    if age_days < (365 * 3):
        return "1-3y"
    if age_days < (365 * 5):
        return "3-5y"
    if age_days < (365 * 10):
        return "5-10y"
    return "10y+"


def _support_lane(case_type_code: str | None, case_category_code: str | None) -> str:
    haystack = " ".join(filter(None, [case_category_code, case_type_code])).lower()
    if "enforcement" in haystack:
        return "enforcement"
    if "service" in haystack:
        return "service_docs"
    if "interstate" in haystack:
        return "interstate"
    if "child support" in haystack:
        return "child_support"
    if "paternity" in haystack or "parentage" in haystack:
        return "paternity"
    if "establishment" in haystack:
        return "establishment"
    return "other"


class ResearchTexasIVDAnalyzer:
    def __init__(self, *, store: ResearchTexasStore):
        self.store = store

    async def recompute_tarrant_scenarios(
        self,
        *,
        jurisdiction: str = "Tarrant County - District Clerk",
    ) -> dict[str, Any]:
        await self.store.ensure_schema()
        source = await self.store.fetch_rollup_source(jurisdiction=jurisdiction)

        parties_by_case: dict[str, list[dict[str, Any]]] = {}
        for party in source["parties"]:
            parties_by_case.setdefault(str(party["case_data_id"]), []).append(party)

        attorneys_by_case: dict[str, list[dict[str, Any]]] = {}
        for attorney in source["attorneys"]:
            attorneys_by_case.setdefault(str(attorney["case_data_id"]), []).append(attorney)

        events_by_case = {
            str(row["case_data_id"]): row
            for row in source["events"]
        }

        now = datetime.now(timezone.utc)
        rollups: list[dict[str, Any]] = []
        for case in source["cases"]:
            case_data_id = str(case["case_data_id"])
            party_rows = parties_by_case.get(case_data_id, [])
            attorney_rows = attorneys_by_case.get(case_data_id, [])
            event_row = events_by_case.get(case_data_id, {})

            date_filed = case.get("date_filed")
            age_days = (now - date_filed).days if date_filed else None
            status_bucket = _normalize_status(case.get("status"))
            party_names = sorted({row.get("party_name") for row in party_rows if row.get("party_name")})
            attorney_names = sorted({row.get("attorney_name") for row in attorney_rows if row.get("attorney_name")})
            has_oag_party = any(
                "ATTORNEY GENERAL OF TEXAS" in (name or "").upper()
                for name in party_names
            )
            has_holly_hayes = any(
                (name or "").strip().upper() == "HOLLY HAYES"
                for name in attorney_names
            )
            has_oag_routed_attorney = has_holly_hayes or any(
                "ATTORNEY GENERAL" in (name or "").upper()
                for name in attorney_names
            )
            rollups.append(
                {
                    "case_data_id": case_data_id,
                    "case_number": case.get("case_number"),
                    "jurisdiction": case.get("jurisdiction"),
                    "case_category_code": case.get("case_category_code"),
                    "case_type_code": case.get("case_type_code"),
                    "support_lane": _support_lane(
                        case.get("case_type_code"),
                        case.get("case_category_code"),
                    ),
                    "date_filed": date_filed,
                    "age_days": age_days,
                    "age_bucket": _age_bucket(age_days),
                    "status": case.get("status"),
                    "status_bucket": status_bucket,
                    "is_blank_status": status_bucket == "blank",
                    "is_open_like": status_bucket == "open_like",
                    "is_reopened_like": status_bucket == "reopened_like",
                    "is_closed_like": status_bucket == "closed_like",
                    "is_eligible_for_obligated_caseload": status_bucket in {"blank", "open_like", "reopened_like"},
                    "is_stale_1y": bool(age_days is not None and age_days >= 365),
                    "is_stale_3y": bool(age_days is not None and age_days >= (365 * 3)),
                    "is_stale_5y": bool(age_days is not None and age_days >= (365 * 5)),
                    "is_stale_10y": bool(age_days is not None and age_days >= (365 * 10)),
                    "has_oag_party": has_oag_party,
                    "has_holly_hayes": has_holly_hayes,
                    "has_oag_routed_attorney": has_oag_routed_attorney,
                    "party_count": len(party_rows),
                    "attorney_count": len(attorney_rows),
                    "event_count": int(event_row.get("event_count") or 0),
                    "last_event_at": event_row.get("last_event_at"),
                    "party_names": "; ".join(party_names) or None,
                    "attorney_names": "; ".join(attorney_names) or None,
                    "updated_at": now,
                }
            )

        await self.store.upsert_rollups(rollups)

        case_count = len(rollups)
        eligible_case_count = sum(int(row["is_eligible_for_obligated_caseload"]) for row in rollups)
        open_like_case_count = sum(int(row["is_open_like"]) for row in rollups)
        blank_status_case_count = sum(int(row["is_blank_status"]) for row in rollups)
        reopened_case_count = sum(int(row["is_reopened_like"]) for row in rollups)
        stale_case_count = sum(int(row["is_stale_3y"]) for row in rollups)
        oag_routed_case_count = sum(int(row["has_oag_party"] or row["has_oag_routed_attorney"]) for row in rollups)
        enforcement_case_count = sum(int(row["support_lane"] == "enforcement") for row in rollups)

        analysis_run_id = str(uuid.uuid4())
        generated_at = datetime.now(timezone.utc)
        scenario_rows: list[dict[str, Any]] = []
        for scenario in DEFAULT_SCENARIOS:
            collectible_case_count = eligible_case_count * scenario.collections_case_multiplier
            current_support_gross = collectible_case_count * scenario.avg_current_support_collection
            arrears_case_count = max(1, enforcement_case_count) * max(scenario.collections_case_multiplier / 2.0, 0.005)
            arrears_gross = arrears_case_count * scenario.avg_arrears_collection
            monthly_base = eligible_case_count * scenario.obligated_case_multiplier * MONTHLY_PER_CASE_REIMBURSEMENT
            monthly_quality = (
                eligible_case_count
                * scenario.quality_bonus_case_multiplier
                * scenario.quality_bonus_attainment_rate
                * MONTHLY_QUALITY_BONUS_CAP
            )
            annual_base = monthly_base * 12.0
            annual_quality = monthly_quality * 12.0
            annual_collection_share = (
                current_support_gross * scenario.current_support_incentive_share_rate
                + arrears_gross * scenario.arrears_incentive_share_rate
            )
            annual_enforcement_cost = eligible_case_count * scenario.monthly_enforcement_cost_per_case * 12.0
            annual_net = annual_base + annual_quality + annual_collection_share - annual_enforcement_cost
            scenario_rows.append(
                {
                    "analysis_run_id": analysis_run_id,
                    "scenario_name": scenario.name,
                    "jurisdiction": jurisdiction,
                    "generated_at": generated_at,
                    "case_count": case_count,
                    "eligible_case_count": eligible_case_count,
                    "open_like_case_count": open_like_case_count,
                    "blank_status_case_count": blank_status_case_count,
                    "reopened_case_count": reopened_case_count,
                    "stale_case_count": stale_case_count,
                    "oag_routed_case_count": oag_routed_case_count,
                    "enforcement_case_count": enforcement_case_count,
                    "monthly_base_reimbursement_exposure": _money(monthly_base),
                    "monthly_quality_bonus_exposure": _money(monthly_quality),
                    "annual_base_reimbursement_exposure": _money(annual_base),
                    "annual_quality_bonus_exposure": _money(annual_quality),
                    "annual_current_support_collections_gross": _money(current_support_gross),
                    "annual_arrears_collections_gross": _money(arrears_gross),
                    "annual_collection_incentive_share_estimate": _money(annual_collection_share),
                    "annual_enforcement_cost_estimate": _money(annual_enforcement_cost),
                    "annual_net_exposure": _money(annual_net),
                    "assumptions_json": json.dumps(asdict(scenario), sort_keys=True),
                }
            )

        await self.store.insert_scenarios(scenario_rows)
        return {
            "analysis_run_id": analysis_run_id,
            "jurisdiction": jurisdiction,
            "case_count": case_count,
            "eligible_case_count": eligible_case_count,
            "open_like_case_count": open_like_case_count,
            "blank_status_case_count": blank_status_case_count,
            "reopened_case_count": reopened_case_count,
            "stale_case_count": stale_case_count,
            "oag_routed_case_count": oag_routed_case_count,
            "enforcement_case_count": enforcement_case_count,
            "scenario_rows": scenario_rows,
        }
