from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo


EASTERN = ZoneInfo("America/New_York")
REGULAR_MARKET_OPEN = time(9, 30)
REGULAR_MARKET_CLOSE = time(16, 0)
FIXED_US_MARKET_HOLIDAYS = (
    (1, 1),
    (7, 4),
    (12, 25),
)


def eastern_now(reference: datetime | None = None) -> datetime:
    current = reference or datetime.now(timezone.utc)
    if current.tzinfo is None:
        current = current.replace(tzinfo=timezone.utc)
    return current.astimezone(EASTERN)


def nth_weekday_of_month(year: int, month: int, weekday: int, occurrence: int) -> date:
    first_day = date(year, month, 1)
    delta_days = (weekday - first_day.weekday()) % 7
    return first_day + timedelta(days=delta_days + ((occurrence - 1) * 7))


def last_weekday_of_month(year: int, month: int, weekday: int) -> date:
    if month == 12:
        next_month = date(year + 1, 1, 1)
    else:
        next_month = date(year, month + 1, 1)
    last_day = next_month - timedelta(days=1)
    delta_days = (last_day.weekday() - weekday) % 7
    return last_day - timedelta(days=delta_days)


def easter_sunday(year: int) -> date:
    a = year % 19
    b = year // 100
    c = year % 100
    d = b // 4
    e = b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i = c // 4
    k = c % 4
    l = (32 + (2 * e) + (2 * i) - h - k) % 7
    m = (a + (11 * h) + (22 * l)) // 451
    month = (h + l - (7 * m) + 114) // 31
    day = ((h + l - (7 * m) + 114) % 31) + 1
    return date(year, month, day)


def observed_market_holiday(day: date) -> date:
    if day.weekday() == 5:
        return day - timedelta(days=1)
    if day.weekday() == 6:
        return day + timedelta(days=1)
    return day


def us_market_holidays(year: int) -> set[date]:
    dynamic = {
        nth_weekday_of_month(year, 1, 0, 3),
        nth_weekday_of_month(year, 2, 0, 3),
        easter_sunday(year) - timedelta(days=2),
        last_weekday_of_month(year, 5, 0),
        nth_weekday_of_month(year, 9, 0, 1),
        nth_weekday_of_month(year, 11, 3, 4),
    }
    fixed = {
        observed_market_holiday(date(year, month, day))
        for month, day in FIXED_US_MARKET_HOLIDAYS
    }
    return dynamic | fixed


def is_trading_day(day: date) -> bool:
    return day.weekday() < 5 and day not in us_market_holidays(day.year)


def regular_session_bounds(reference: datetime | None = None) -> tuple[datetime, datetime]:
    current = eastern_now(reference)
    opened = datetime.combine(current.date(), REGULAR_MARKET_OPEN, tzinfo=EASTERN)
    closed = datetime.combine(current.date(), REGULAR_MARKET_CLOSE, tzinfo=EASTERN)
    return opened, closed


def is_market_open(reference: datetime | None = None) -> bool:
    current = eastern_now(reference)
    if not is_trading_day(current.date()):
        return False
    opened, closed = regular_session_bounds(current)
    return opened <= current <= closed


def next_market_open(reference: datetime | None = None) -> datetime:
    current = eastern_now(reference)
    opened, closed = regular_session_bounds(current)
    if is_trading_day(current.date()) and current < opened:
        return opened
    next_day = current.date() + timedelta(days=1)
    while not is_trading_day(next_day):
        next_day += timedelta(days=1)
    return datetime.combine(next_day, REGULAR_MARKET_OPEN, tzinfo=EASTERN)


def current_session_key(reference: datetime | None = None) -> str:
    return eastern_now(reference).strftime("%Y-%m-%d")
