from __future__ import annotations

import json
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from search_consecutive_color_prerun_patterns import (
    db_connect,
    load_env_defaults,
    parse_date,
    resolve_tickers,
)


MARKET_TZ = ZoneInfo("America/New_York")
REPO_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = REPO_ROOT / "LOGIC_RUNS"
RUN_DATE = datetime.now(tz=MARKET_TZ).strftime("%Y%m%d")
START_DATE = "2025-12-01"
END_DATE = "2026-04-14"
TIMESPAN = "m1"
UNIVERSE = "most_active"
CHUNK_SIZE = 10
VALIDATION_DAYS = 8
WINDOWS = [5, 10, 15]
THRESHOLDS = [0.001, 0.002, 0.003, 0.005, 0.01]
THRESHOLD_LABELS = {
    0.001: "10bp",
    0.002: "20bp",
    0.003: "30bp",
    0.005: "50bp",
    0.01: "100bp",
}

BULL_COMBOS = {
    "mfi_le_20 AND bb_width_ge_0_05": lambda df: (df["mfi"] <= 20.0) & (df["bb_width"] >= 0.05),
    "full_below_lower AND bb_width_ge_0_05": lambda df: df["candle_completely_below_lower"] & (df["bb_width"] >= 0.05),
    "bb_lower AND bb_width_ge_0_05": lambda df: df["bb_close_outside_lower"] & (df["bb_width"] >= 0.05),
    "prev3_red_ge_2 AND bb_width_ge_0_05": lambda df: (df["prev3_red_count"] >= 2) & (df["bb_width"] >= 0.05),
    "cmo_le_n20 AND bb_width_ge_0_05": lambda df: (df["cmo"] <= -20.0) & (df["bb_width"] >= 0.05),
    "candle_red AND bb_width_ge_0_05": lambda df: df["candle_red"] & (df["bb_width"] >= 0.05),
    "vwap_down_10bp AND bb_width_ge_0_05": lambda df: (df["vwap_dist_pct"] <= -0.0010) & (df["bb_width"] >= 0.05),
    "close_pos_lo AND bb_width_ge_0_05": lambda df: (df["close_pos_in_range"] <= 0.2) & (df["bb_width"] >= 0.05),
}

BEAR_COMBOS = {
    "prev3_green_ge_2 AND bb_width_ge_0_05": lambda df: (df["prev3_green_count"] >= 2) & (df["bb_width"] >= 0.05),
    "close_pos_hi AND bb_width_ge_0_05": lambda df: (df["close_pos_in_range"] >= 0.8) & (df["bb_width"] >= 0.05),
    "prev_bar_green AND bb_width_ge_0_05": lambda df: df["prev_bar_green"] & (df["bb_width"] >= 0.05),
    "candle_green AND bb_width_ge_0_05": lambda df: df["candle_green"] & (df["bb_width"] >= 0.05),
    "green_streak_ge_2 AND bb_width_ge_0_05": lambda df: (df["green_streak"] >= 2) & (df["bb_width"] >= 0.05),
    "green_streak_ge_3 AND bb_width_ge_0_05": lambda df: (df["green_streak"] >= 3) & (df["bb_width"] >= 0.05),
    "ema_stack_bear AND bb_width_ge_0_05": lambda df: df["ema_stack_bear"] & (df["bb_width"] >= 0.05),
}


@dataclass
class ComboAccumulator:
    combo: str
    side: str
    n: int = 0
    tickers: set[str] = field(default_factory=set)
    per_date_counts: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    per_date_tickers: dict[str, set[str]] = field(default_factory=lambda: defaultdict(set))
    hits: dict[str, int] = field(default_factory=lambda: defaultdict(int))
    per_date_hits: dict[str, dict[str, int]] = field(default_factory=lambda: defaultdict(lambda: defaultdict(int)))


def et_epoch(day: date, hour: int = 0, minute: int = 0) -> int:
    return int(datetime(day.year, day.month, day.day, hour, minute, tzinfo=MARKET_TZ).timestamp())


def sql_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def build_query(*, tickers: list[str], start_epoch: int, end_epoch: int) -> str:
    ticker_sql = ""
    if tickers:
        ticker_sql = f"\n          AND UPPER(BTRIM(ticker)) IN ({', '.join(sql_quote(value) for value in tickers)})"
    return f"""
        SELECT
            UPPER(BTRIM(ticker)) AS ticker,
            ts::bigint AS ts_epoch,
            insertion_timestamp,
            date_et,
            c,
            h,
            l,
            candle_green,
            candle_red,
            bb_width,
            mfi,
            cmo,
            vwap_dist_pct,
            bb_close_outside_lower,
            candle_completely_below_lower,
            ema_stack_bear
        FROM ca
        WHERE timespan = {sql_quote(TIMESPAN)}
          AND session = 'regular'
          AND bb_width IS NOT NULL
          AND ts::bigint >= {int(start_epoch)}
          AND ts::bigint < {int(end_epoch)}
          {ticker_sql}
    """


def compute_streaks(flags: list[bool]) -> list[int]:
    streaks: list[int] = []
    running = 0
    for flag in flags:
        if flag:
            running += 1
        else:
            running = 0
        streaks.append(running)
    return streaks


def prepare_chunk(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return frame
    df = frame.copy()
    df["ticker"] = df["ticker"].astype(str).str.strip().str.upper()
    df["date_et"] = df["date_et"].astype(str)
    df["ts_epoch"] = pd.to_numeric(df["ts_epoch"], errors="coerce").astype("Int64")
    df["insertion_timestamp"] = pd.to_datetime(df["insertion_timestamp"], errors="coerce")
    for column in ("c", "h", "l", "bb_width", "mfi", "cmo", "vwap_dist_pct"):
        df[column] = pd.to_numeric(df[column], errors="coerce")
    for column in ("candle_green", "candle_red", "bb_close_outside_lower", "candle_completely_below_lower", "ema_stack_bear"):
        df[column] = df[column].fillna(False).astype(bool)
    df = (
        df.sort_values(["ticker", "date_et", "ts_epoch", "insertion_timestamp"])
        .drop_duplicates(["ticker", "ts_epoch"], keep="last")
        .reset_index(drop=True)
    )
    price_range = (df["h"] - df["l"]).replace(0, np.nan)
    close_pos = (df["c"] - df["l"]) / price_range
    df["close_pos_in_range"] = close_pos.fillna(0.5).clip(0.0, 1.0)
    df["prev_bar_green"] = False
    df["prev3_green_count"] = 0
    df["prev3_red_count"] = 0
    df["green_streak"] = 0
    df["red_streak"] = 0
    for (_, _), group_index in df.groupby(["ticker", "date_et"], sort=False).groups.items():
        idxs = list(group_index)
        greens = df.loc[idxs, "candle_green"].tolist()
        reds = df.loc[idxs, "candle_red"].tolist()
        prev_bar_green = [False, *greens[:-1]]
        prev3_green_count: list[int] = []
        prev3_red_count: list[int] = []
        for idx in range(len(idxs)):
            start = max(0, idx - 3)
            prev3_green_count.append(sum(1 for value in greens[start:idx] if value))
            prev3_red_count.append(sum(1 for value in reds[start:idx] if value))
        df.loc[idxs, "prev_bar_green"] = prev_bar_green
        df.loc[idxs, "prev3_green_count"] = prev3_green_count
        df.loc[idxs, "prev3_red_count"] = prev3_red_count
        df.loc[idxs, "green_streak"] = compute_streaks(greens)
        df.loc[idxs, "red_streak"] = compute_streaks(reds)
        highs = df.loc[idxs, "h"].to_numpy(dtype=float)
        lows = df.loc[idxs, "l"].to_numpy(dtype=float)
        closes = df.loc[idxs, "c"].to_numpy(dtype=float)
        size = len(idxs)
        for window in WINDOWS:
            bull = np.full(size, np.nan, dtype=float)
            bear = np.full(size, np.nan, dtype=float)
            if size > window:
                high_windows = np.lib.stride_tricks.sliding_window_view(highs[1:], window_shape=window)
                low_windows = np.lib.stride_tricks.sliding_window_view(lows[1:], window_shape=window)
                future_max = high_windows.max(axis=1)
                future_min = low_windows.min(axis=1)
                base_close = closes[: len(future_max)]
                valid = base_close > 0
                bull_vals = np.full(len(future_max), np.nan, dtype=float)
                bear_vals = np.full(len(future_max), np.nan, dtype=float)
                bull_vals[valid] = (future_max[valid] / base_close[valid]) - 1.0
                bear_vals[valid] = 1.0 - (future_min[valid] / base_close[valid])
                bull[: len(future_max)] = bull_vals
                bear[: len(future_max)] = bear_vals
            df.loc[idxs, f"bull_best_{window}"] = bull
            df.loc[idxs, f"bear_best_{window}"] = bear
    return df


def update_combo(
    combo: str,
    side: str,
    df: pd.DataFrame,
    mask: pd.Series,
    acc: ComboAccumulator,
) -> None:
    if not int(mask.sum()):
        return
    subset = df.loc[mask, ["ticker", "date_et", *[f"{side}_best_{window}" for window in WINDOWS]]].copy()
    acc.n += int(len(subset))
    acc.tickers.update(subset["ticker"].astype(str).unique().tolist())
    for date_value, date_group in subset.groupby("date_et", sort=False):
        date_str = str(date_value)
        acc.per_date_counts[date_str] += int(len(date_group))
        acc.per_date_tickers[date_str].update(date_group["ticker"].astype(str).unique().tolist())
        for window in WINDOWS:
            values = pd.to_numeric(date_group[f"{side}_best_{window}"], errors="coerce")
            for threshold in THRESHOLDS:
                label = THRESHOLD_LABELS[threshold]
                key = f"w{window}_{label}"
                hit_count = int((values >= threshold).sum())
                acc.hits[key] += hit_count
                acc.per_date_hits[date_str][key] += hit_count


def finalize_combo(acc: ComboAccumulator, validation_dates: list[str]) -> dict[str, Any]:
    result: dict[str, Any] = {
        "conditions": acc.combo,
        "n": int(acc.n),
        "ticker_count": int(len(acc.tickers)),
        "val_n": int(sum(acc.per_date_counts.get(day, 0) for day in validation_dates)),
        "val_ticker_count": int(len(set().union(*(acc.per_date_tickers.get(day, set()) for day in validation_dates)))),
    }
    for window in WINDOWS:
        for threshold in THRESHOLDS:
            label = THRESHOLD_LABELS[threshold]
            key = f"w{window}_{label}"
            overall = (acc.hits.get(key, 0) / acc.n) if acc.n else 0.0
            val_hits = sum(acc.per_date_hits.get(day, {}).get(key, 0) for day in validation_dates)
            val_n = result["val_n"]
            val = (val_hits / val_n) if val_n else 0.0
            result[key] = round(float(overall), 4)
            result[f"{key}_val"] = round(float(val), 4)
    return result


def render_report(results: dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append("# Same-Color 10+ Full-Universe Move Probability Analysis")
    lines.append("")
    lines.append("Assumption:")
    lines.append("- Full baseline: all `m1` regular-session rows in the `most_active` universe from `2025-12-01` through `2026-04-14` with `bb_width IS NOT NULL`.")
    lines.append("- Bull combos are scored for future upside best excursion within the next `5`, `10`, and `15` bars.")
    lines.append("- Bear combos are scored for future downside best excursion within the next `5`, `10`, and `15` bars.")
    lines.append("- Thresholds tested: `10bp`, `20bp`, `30bp`, `50bp`, `100bp`.")
    lines.append("- Validation dates: `" + ", ".join(results["validation_dates"]) + "`")
    lines.append("")
    for side in ("bull", "bear"):
        side_label = side.title()
        lines.append(f"## {side_label} Combos")
        qualified = results[side]["qualified_85"]
        if qualified:
            lines.append("- `85%+` on both overall and validation:")
            for item in qualified:
                lines.append(
                    f"- `{item['conditions']}` -> `{item['threshold']}` in `{item['window']}` bars "
                    f"| `overall={item['overall_hit']:.4f}` `val={item['val_hit']:.4f}` "
                    f"`n={item['n']}` `val_n={item['val_n']}`"
                )
        else:
            lines.append("- No tested combo cleared `85%` on both overall and validation at any tested move threshold.")
        lines.append("")
        lines.append("Top combos by strongest validation hit:")
        for row in results[side]["results"][:6]:
            best = max(
                (
                    (window, THRESHOLD_LABELS[threshold], row[f"w{window}_{THRESHOLD_LABELS[threshold]}_val"], row[f"w{window}_{THRESHOLD_LABELS[threshold]}"])
                    for window in WINDOWS
                    for threshold in THRESHOLDS
                ),
                key=lambda item: item[2],
            )
            lines.append(
                f"- `{row['conditions']}` -> best validation `{best[2]:.4f}` at `{best[1]}` in `{best[0]}` bars "
                f"| `overall={best[3]:.4f}` `n={row['n']}` `val_n={row['val_n']}`"
            )
        lines.append("")
    return "\n".join(lines) + "\n"


def summarize_qualified(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    qualified: list[dict[str, Any]] = []
    for row in rows:
        for window in WINDOWS:
            for threshold in THRESHOLDS:
                label = THRESHOLD_LABELS[threshold]
                overall = float(row[f"w{window}_{label}"])
                val = float(row[f"w{window}_{label}_val"])
                if overall >= 0.85 and val >= 0.85:
                    qualified.append(
                        {
                            "conditions": row["conditions"],
                            "window": window,
                            "threshold": label,
                            "overall_hit": overall,
                            "val_hit": val,
                            "n": int(row["n"]),
                            "val_n": int(row["val_n"]),
                        }
                    )
    qualified.sort(
        key=lambda item: (item["val_hit"], item["overall_hit"], item["val_n"], item["n"]),
        reverse=True,
    )
    return qualified


def main() -> None:
    tickers = resolve_tickers("", UNIVERSE)
    start_epoch = et_epoch(parse_date(START_DATE))
    end_epoch = et_epoch(parse_date(END_DATE) + timedelta(days=1))
    tickers = list(tickers)
    chunks = [tickers[idx : idx + CHUNK_SIZE] for idx in range(0, len(tickers), CHUNK_SIZE)]
    accumulators = {
        "bull": {name: ComboAccumulator(combo=name, side="bull") for name in BULL_COMBOS},
        "bear": {name: ComboAccumulator(combo=name, side="bear") for name in BEAR_COMBOS},
    }
    all_dates: set[str] = set()
    conn = db_connect(load_env_defaults())
    try:
        for chunk_idx, chunk in enumerate(chunks, start=1):
            print(f"fetch chunk {chunk_idx}/{len(chunks)} ({len(chunk)} tickers)", flush=True)
            raw = pd.read_sql_query(build_query(tickers=chunk, start_epoch=start_epoch, end_epoch=end_epoch), conn)
            prepared = prepare_chunk(raw)
            if prepared.empty:
                continue
            all_dates.update(prepared["date_et"].astype(str).unique().tolist())
            for combo_name, combo_fn in BULL_COMBOS.items():
                update_combo(combo_name, "bull", prepared, combo_fn(prepared).fillna(False), accumulators["bull"][combo_name])
            for combo_name, combo_fn in BEAR_COMBOS.items():
                update_combo(combo_name, "bear", prepared, combo_fn(prepared).fillna(False), accumulators["bear"][combo_name])
    finally:
        conn.close()

    validation_dates = sorted(all_dates)[-VALIDATION_DAYS:]
    bull_results = [finalize_combo(acc, validation_dates) for acc in accumulators["bull"].values()]
    bear_results = [finalize_combo(acc, validation_dates) for acc in accumulators["bear"].values()]
    bull_results.sort(
        key=lambda row: max(row[f"w{window}_{THRESHOLD_LABELS[threshold]}_val"] for window in WINDOWS for threshold in THRESHOLDS),
        reverse=True,
    )
    bear_results.sort(
        key=lambda row: max(row[f"w{window}_{THRESHOLD_LABELS[threshold]}_val"] for window in WINDOWS for threshold in THRESHOLDS),
        reverse=True,
    )

    report = {
        "baseline": {
            "scope": "full_universe",
            "timespan": TIMESPAN,
            "start_date": START_DATE,
            "end_date": END_DATE,
            "universe": UNIVERSE,
            "ticker_count": len(tickers),
            "validation_dates": validation_dates,
        },
        "bull": {
            "results": bull_results,
            "qualified_85": summarize_qualified(bull_results),
        },
        "bear": {
            "results": bear_results,
            "qualified_85": summarize_qualified(bear_results),
        },
        "validation_dates": validation_dates,
    }

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    json_path = OUTPUT_DIR / f"SAMECOLOR10PLUS_FULLUNIVERSE_MOVE_STATS_{RUN_DATE}.json"
    md_path = OUTPUT_DIR / f"SAMECOLOR10PLUS_FULLUNIVERSE_MOVE_STATS_{RUN_DATE}.md"
    json_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    md_path.write_text(render_report(report), encoding="utf-8")
    print(json_path)
    print(md_path)


if __name__ == "__main__":
    main()
