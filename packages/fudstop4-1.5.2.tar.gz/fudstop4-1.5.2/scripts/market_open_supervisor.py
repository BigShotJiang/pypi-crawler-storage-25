#!/usr/bin/env python3
from __future__ import annotations

import asyncio
import datetime as dt
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Dict

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
REPO_ROOT = ROOT.parent
LOG_DIR = REPO_ROOT / "tmp" / "market_open_supervisor"
STATUS_PATH = LOG_DIR / "status.json"
BATCH_PATH = REPO_ROOT / "ALL SCRIPTS.bat"

repo_root_str = str(REPO_ROOT)
if repo_root_str not in sys.path:
    sys.path.append(repo_root_str)

load_dotenv(REPO_ROOT / ".env")

PYTHON_BIN = os.getenv("MARKET_STACK_PYTHON") or sys.executable
SCAN_INTERVAL_SECONDS = max(3, int(os.getenv("MARKET_STACK_SCAN_SECONDS", "5")))
ONE_SHOT_MIN_INTERVAL_SECONDS = max(60, int(os.getenv("MARKET_STACK_MIN_INTERVAL_SECONDS", "300")))
FORCE_OPEN = os.getenv("MARKET_STACK_FORCE_OPEN", "").strip().lower() in {"1", "true", "yes", "on"}

from feeds.discord_routes import iter_routes
from market_session import current_session_key, eastern_now, is_market_open, next_market_open


MANUAL_FRESHNESS_SECONDS: Dict[str, int] = {
    "active": 900,
    "alerts": 1800,
    "all_options": 900,
    "analysts": 86400,
    "atm_options": 300,
    "atm_vol_anal": 1800,
    "balance_sheet": 604800,
    "capital_flow": 3600,
    "ca_live_ingest": 300,
    "cash_flow": 604800,
    "cost_distribution": 7200,
    "crypto": 3600,
    "earnings": 86400,
    "etf_holdings": 86400,
    "events": 86400,
    "factors": 86400,
    "finra_shorts": 86400,
    "gaps": 1800,
    "gex": 600,
    "high_dividends": 86400,
    "historic_ivx": 600,
    "income_statement": 604800,
    "info": 86400,
    "institutions": 86400,
    "ipos": 86400,
    "itm_dollars": 1800,
    "iv_skew_new": 600,
    "macd_conditions_new": 300,
    "multi_quote_new": 300,
    "news": 900,
    "oi_outliers_new": 1800,
    "option_stats": 1800,
    "option_trades": 900,
    "options_charts": 1800,
    "options_monitor": 600,
    "options_query": 1800,
    "options_vol_anal": 1800,
    "overnight": 86400,
    "plays": 900,
    "rise_fall": 900,
    "rsi_conditions_new": 300,
    "short_interest": 86400,
    "stock_monitor": 1800,
    "technical_events": 180,
    "ticker_bonds": 86400,
    "top_followed": 86400,
    "us_bonds": 86400,
    "vol_anal": 1800,
    "volume_summary": 900,
    "yf_earnings_estimate": 86400,
    "yf_insider_roster_holdings": 86400,
    "yf_insiders": 86400,
    "yf_mfholders": 86400,
    "yf_news": 86400,
    "yf_pt": 86400,
}


@dataclass(frozen=True)
class ProcessSpec:
    name: str
    script_path: str
    source: str
    mode: str
    interval_seconds: int = 0


@dataclass
class ManagedProcess:
    spec: ProcessSpec
    process: asyncio.subprocess.Process
    log_handle: BinaryIO
    wait_task: asyncio.Task[int]


STATE: Dict[str, Dict[str, object]] = {}
HANDLES: Dict[str, ManagedProcess] = {}
NEXT_RUN_AT: Dict[str, dt.datetime] = {}
LAST_SESSION_STARTED: Dict[str, str] = {}


def now_utc() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def now_iso() -> str:
    return now_utc().isoformat()


def merged_env() -> Dict[str, str]:
    env = os.environ.copy()
    env.setdefault("PYTHONUNBUFFERED", "1")
    return env


def load_batch_modules() -> list[str]:
    if not BATCH_PATH.exists():
        return []
    text = BATCH_PATH.read_text(encoding="utf-8", errors="ignore")
    match = re.search(r"set scripts=(.+)", text)
    if not match:
        return []
    return [item.strip() for item in match.group(1).split() if item.strip()]


def classify_script_mode(script_path: Path) -> str:
    if not script_path.exists():
        return "missing"
    text = script_path.read_text(encoding="utf-8", errors="ignore")
    if "while True" in text:
        return "daemon"
    if "asyncio.sleep" in text:
        return "daemon"
    return "interval"


def interval_for_module(module_name: str) -> int:
    configured = int(MANUAL_FRESHNESS_SECONDS.get(module_name, 900))
    return max(ONE_SHOT_MIN_INTERVAL_SECONDS, configured)


def batch_specs() -> list[ProcessSpec]:
    specs: list[ProcessSpec] = []
    for module_name in load_batch_modules():
        script_path = ROOT / f"{module_name}.py"
        mode = classify_script_mode(script_path)
        specs.append(
            ProcessSpec(
                name=module_name,
                script_path=f"scripts/{module_name}.py",
                source="script",
                mode=mode,
                interval_seconds=interval_for_module(module_name) if mode == "interval" else 0,
            )
        )
    return specs


def feed_specs() -> list[ProcessSpec]:
    specs: list[ProcessSpec] = []
    seen: set[str] = set()
    for route in iter_routes():
        script_path = str(route.script_path).replace("\\", "/").strip()
        if not script_path or script_path in seen:
            continue
        seen.add(script_path)
        specs.append(
            ProcessSpec(
                name=f"feed_{Path(script_path).stem}",
                script_path=script_path,
                source="feed",
                mode="daemon",
            )
        )
    return specs


SPECS = sorted(batch_specs() + feed_specs(), key=lambda spec: (spec.source, spec.name))


def spec_path(spec: ProcessSpec) -> Path:
    return REPO_ROOT / spec.script_path


def is_session_open() -> bool:
    return FORCE_OPEN or is_market_open()


def next_session_open_iso() -> str:
    if FORCE_OPEN:
        return ""
    return next_market_open().astimezone(dt.timezone.utc).isoformat()


def find_existing_pid(spec: ProcessSpec) -> int:
    script_name = spec_path(spec).name.replace(".", "\\.")
    command = (
        "Get-CimInstance Win32_Process | Where-Object { "
        "$_.Name -match 'python' -and "
        f"$_.CommandLine -match '{script_name}'"
        "} | Select-Object -ExpandProperty ProcessId"
    )
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", command],
            capture_output=True,
            text=True,
            check=False,
            cwd=str(REPO_ROOT),
        )
    except Exception:
        return 0
    for line in result.stdout.splitlines():
        text = line.strip()
        if text.isdigit():
            return int(text)
    return 0


async def write_status_snapshot() -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "updated_at": now_iso(),
        "market_open": is_session_open(),
        "forced_open": FORCE_OPEN,
        "eastern_time": eastern_now().isoformat(),
        "next_market_open": next_session_open_iso(),
        "processes": STATE,
    }
    STATUS_PATH.write_text(json.dumps(payload, indent=2), encoding="utf-8")


async def spawn_process(spec: ProcessSpec) -> ManagedProcess:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_handle = open(LOG_DIR / f"{spec.name}.log", "ab")
    process = await asyncio.create_subprocess_exec(
        PYTHON_BIN,
        str(spec_path(spec)),
        cwd=str(REPO_ROOT),
        env=merged_env(),
        stdout=log_handle,
        stderr=asyncio.subprocess.STDOUT,
    )
    wait_task = asyncio.create_task(process.wait())
    handle = ManagedProcess(spec=spec, process=process, log_handle=log_handle, wait_task=wait_task)
    HANDLES[spec.name] = handle
    LAST_SESSION_STARTED[spec.name] = current_session_key()
    STATE.setdefault(spec.name, {})
    STATE[spec.name].update(
        {
            "source": spec.source,
            "script": spec.script_path,
            "mode": spec.mode,
            "interval_seconds": spec.interval_seconds,
            "pid": process.pid,
            "status": "running",
            "managed": True,
            "started_at": now_iso(),
            "restarts": int(STATE[spec.name].get("restarts", 0)),
        }
    )
    print(f"[market_open_supervisor] started {spec.name} pid={process.pid}")
    return handle


async def close_handle(name: str, *, terminate: bool, reason: str) -> None:
    handle = HANDLES.pop(name, None)
    if not handle:
        return
    try:
        if terminate and handle.process.returncode is None:
            handle.process.terminate()
            try:
                await asyncio.wait_for(handle.wait_task, timeout=10)
            except asyncio.TimeoutError:
                handle.process.kill()
                await handle.wait_task
        elif not handle.wait_task.done():
            await handle.wait_task
    finally:
        handle.log_handle.close()
    STATE.setdefault(name, {})
    STATE[name].update(
        {
            "status": reason,
            "managed": True,
            "last_stopped_at": now_iso(),
        }
    )


async def reap_completed_processes() -> None:
    for name, handle in list(HANDLES.items()):
        if not handle.wait_task.done():
            continue
        return_code = handle.wait_task.result()
        handle.log_handle.close()
        HANDLES.pop(name, None)
        restarts = int(STATE.get(name, {}).get("restarts", 0))
        if handle.spec.mode == "interval":
            NEXT_RUN_AT[name] = now_utc() + dt.timedelta(seconds=handle.spec.interval_seconds)
            next_run_at = NEXT_RUN_AT[name].isoformat()
            status = "sleeping"
        else:
            next_run_at = ""
            status = "stopped"
            restarts += 1
        STATE.setdefault(name, {})
        STATE[name].update(
            {
                "status": status,
                "managed": True,
                "last_exit_code": return_code,
                "last_stopped_at": now_iso(),
                "next_run_at": next_run_at,
                "restarts": restarts,
            }
        )


def mark_off_session(spec: ProcessSpec) -> None:
    STATE.setdefault(spec.name, {})
    STATE[spec.name].update(
        {
            "source": spec.source,
            "script": spec.script_path,
            "mode": spec.mode,
            "interval_seconds": spec.interval_seconds,
            "status": "waiting_for_open",
            "managed": False,
            "next_run_at": next_session_open_iso(),
        }
    )


async def ensure_market_session_state() -> None:
    if not is_session_open():
        for name in list(HANDLES):
            await close_handle(name, terminate=True, reason="waiting_for_open")
        for spec in SPECS:
            mark_off_session(spec)
        return

    session_key = current_session_key()
    for spec in SPECS:
        if not spec_path(spec).exists():
            STATE.setdefault(spec.name, {})
            STATE[spec.name].update(
                {
                    "source": spec.source,
                    "script": spec.script_path,
                    "mode": spec.mode,
                    "status": "missing_script",
                    "managed": False,
                }
            )
            continue

        if spec.name not in LAST_SESSION_STARTED or LAST_SESSION_STARTED[spec.name] != session_key:
            if spec.mode == "interval":
                NEXT_RUN_AT[spec.name] = now_utc()

        if spec.name in HANDLES:
            STATE.setdefault(spec.name, {})
            STATE[spec.name].update(
                {
                    "status": "running",
                    "managed": True,
                    "pid": HANDLES[spec.name].process.pid,
                }
            )
            continue

        external_pid = find_existing_pid(spec)
        if external_pid:
            STATE.setdefault(spec.name, {})
            STATE[spec.name].update(
                {
                    "source": spec.source,
                    "script": spec.script_path,
                    "mode": spec.mode,
                    "interval_seconds": spec.interval_seconds,
                    "pid": external_pid,
                    "status": "external",
                    "managed": False,
                    "checked_at": now_iso(),
                }
            )
            continue

        if spec.mode == "interval":
            due_at = NEXT_RUN_AT.get(spec.name)
            if due_at and now_utc() < due_at:
                STATE.setdefault(spec.name, {})
                STATE[spec.name].update(
                    {
                        "source": spec.source,
                        "script": spec.script_path,
                        "mode": spec.mode,
                        "interval_seconds": spec.interval_seconds,
                        "status": "sleeping",
                        "managed": False,
                        "next_run_at": due_at.isoformat(),
                    }
                )
                continue

        await spawn_process(spec)


async def main() -> None:
    try:
        while True:
            await reap_completed_processes()
            await ensure_market_session_state()
            await write_status_snapshot()
            await asyncio.sleep(SCAN_INTERVAL_SECONDS)
    finally:
        for name in list(HANDLES):
            await close_handle(name, terminate=True, reason="shutdown")
        await write_status_snapshot()


if __name__ == "__main__":
    asyncio.run(main())
