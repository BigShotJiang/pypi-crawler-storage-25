#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import io
import json
import re
import sys
from pathlib import Path
from typing import Iterable, Sequence

import psycopg2


ROOT = Path(__file__).resolve().parents[1]
ENV_PATH = ROOT / "stock_market_site" / "app" / ".env"
FORBIDDEN_SQL = (
    "insert",
    "update",
    "delete",
    "alter",
    "drop",
    "create",
    "truncate",
    "grant",
    "revoke",
    "copy",
    "vacuum",
    "analyze",
    "refresh",
    "merge",
    "call",
    "do",
)
CA_REFERENCE_PATTERNS = (
    r"\bfrom\s+ca\b",
    r"\bjoin\s+ca\b",
    r"\bfrom\s+public\.ca\b",
    r"\bjoin\s+public\.ca\b",
)


def load_env_defaults() -> dict[str, str]:
    values: dict[str, str] = {}
    if not ENV_PATH.exists():
        return values
    for raw_line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


ENV_DEFAULTS = load_env_defaults()


def env_default(key: str, fallback: str) -> str:
    value = str(ENV_DEFAULTS.get(key) or "").strip()
    return value if value else fallback


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run a read-only query against the ca table.",
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--sql", help="Inline SELECT/WITH query that reads from ca.")
    source.add_argument("--file", help="Path to a .sql file containing a read-only ca query.")
    parser.add_argument("--host", default=env_default("DB_HOST", "localhost"))
    parser.add_argument("--port", type=int, default=int(env_default("DB_PORT", "5432")))
    parser.add_argument("--user", default=env_default("DB_USER", "chuck"))
    parser.add_argument("--password", default=env_default("DB_PASSWORD", "fud"))
    parser.add_argument("--database", default=env_default("DB_NAME", "fudstop3"))
    parser.add_argument(
        "--format",
        choices=("table", "csv", "json"),
        default="table",
        help="Output format.",
    )
    parser.add_argument(
        "--max-rows",
        type=int,
        default=200,
        help="Maximum rows to print after the query returns.",
    )
    parser.add_argument(
        "--out",
        help="Optional output file path. Defaults to stdout.",
    )
    return parser.parse_args()


def load_query(args: argparse.Namespace) -> str:
    if args.sql:
        return str(args.sql)
    file_path = Path(str(args.file)).expanduser().resolve()
    return file_path.read_text(encoding="utf-8")


def normalize_query(query: str) -> str:
    return str(query or "").strip().rstrip(";").strip()


def ensure_safe_ca_query(query: str) -> None:
    normalized = normalize_query(query)
    if not normalized:
        raise ValueError("query is empty")
    lowered = normalized.lower()
    if ";" in normalized:
        raise ValueError("only a single statement is allowed")
    if not (lowered.startswith("select") or lowered.startswith("with")):
        raise ValueError("query must start with SELECT or WITH")
    for keyword in FORBIDDEN_SQL:
        if re.search(rf"\b{re.escape(keyword)}\b", lowered):
            raise ValueError(f"forbidden SQL keyword detected: {keyword}")
    if not any(re.search(pattern, lowered) for pattern in CA_REFERENCE_PATTERNS):
        raise ValueError("query must reference the ca table")


def run_query(args: argparse.Namespace, query: str) -> tuple[list[str], list[tuple[object, ...]]]:
    conn = psycopg2.connect(
        host=args.host,
        port=int(args.port),
        user=args.user,
        password=args.password,
        dbname=args.database,
        connect_timeout=5,
    )
    try:
        with conn.cursor() as cur:
            cur.execute(query)
            columns = [desc[0] for desc in cur.description or []]
            rows = cur.fetchmany(max(0, int(args.max_rows)))
            return columns, rows
    finally:
        conn.close()


def stringify(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=True)
    return str(value)


def render_table(columns: Sequence[str], rows: Sequence[Sequence[object]]) -> str:
    widths = [len(str(col)) for col in columns]
    cell_rows: list[list[str]] = []
    for row in rows:
        cell_row = [stringify(value) for value in row]
        cell_rows.append(cell_row)
        for idx, cell in enumerate(cell_row):
            widths[idx] = max(widths[idx], len(cell))
    header = " | ".join(str(col).ljust(widths[idx]) for idx, col in enumerate(columns))
    divider = "-+-".join("-" * widths[idx] for idx in range(len(columns)))
    body = [
        " | ".join(cell.ljust(widths[idx]) for idx, cell in enumerate(row))
        for row in cell_rows
    ]
    parts = [header, divider, *body]
    return "\n".join(parts)


def render_csv(columns: Sequence[str], rows: Sequence[Sequence[object]]) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(list(columns))
    for row in rows:
        writer.writerow([stringify(value) for value in row])
    return buffer.getvalue().rstrip()


def render_json(columns: Sequence[str], rows: Sequence[Sequence[object]]) -> str:
    payload = [
        {str(columns[idx]): row[idx] for idx in range(len(columns))}
        for row in rows
    ]
    return json.dumps(payload, indent=2, ensure_ascii=True, default=str)


def render_output(fmt: str, columns: Sequence[str], rows: Sequence[Sequence[object]]) -> str:
    if fmt == "csv":
        return render_csv(columns, rows)
    if fmt == "json":
        return render_json(columns, rows)
    return render_table(columns, rows)


def write_output(text: str, out_path: str | None) -> None:
    if out_path:
        Path(out_path).expanduser().resolve().write_text(text + "\n", encoding="utf-8")
        return
    sys.stdout.write(text + "\n")


def main() -> int:
    args = parse_args()
    query = load_query(args)
    try:
        ensure_safe_ca_query(query)
        columns, rows = run_query(args, normalize_query(query))
    except Exception as exc:  # pragma: no cover - CLI path
        sys.stderr.write(f"query_ca_table.py error: {exc}\n")
        return 1
    if not columns:
        write_output("Query ran but returned no columns.", args.out)
        return 0
    text = render_output(args.format, columns, rows)
    write_output(text, args.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
