from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd

from analyze_samecolor10plus_logic_runs import (
    BEAR_FOCUS,
    BULL_FOCUS,
    OUTPUT_DIR,
    RUN_DATE,
    build_event_summary,
    evaluate_focus_metrics,
    render_summary,
    sql_quote,
)
from search_consecutive_color_prerun_patterns import add_derived_columns, db_connect, load_env_defaults


REPO_ROOT = Path(__file__).resolve().parents[1]
RUNS_CSV = OUTPUT_DIR / f"SAMECOLOR10PLUS_BURST_RUNS_{RUN_DATE}.csv"


def fetch_run_day_frame(runs: pd.DataFrame) -> pd.DataFrame:
    pair_rows = (
        runs[["ticker", "date_et"]]
        .astype({"ticker": str, "date_et": str})
        .drop_duplicates()
        .sort_values(["ticker", "date_et"])
        .to_dict("records")
    )
    if not pair_rows:
        return pd.DataFrame()

    def build_query(chunk: list[dict[str, str]]) -> str:
        values_sql = ",\n                ".join(
            f"({sql_quote(item['ticker'])}, {sql_quote(item['date_et'])})"
            for item in chunk
        )
        return f"""
            WITH pairs(ticker, date_et) AS (
                VALUES
                {values_sql}
            )
            SELECT
                UPPER(BTRIM(ca.ticker)) AS ticker,
                ca.ts::bigint AS ts_epoch,
                ca.date_et,
                ca.time_et,
                ca.timespan,
                ca.o,
                ca.c,
                ca.h,
                ca.l,
                ca.v,
                ca.prev_close,
                ca.change_pct,
                ca.candle_green,
                ca.candle_red,
                ca.body_pct,
                ca.hl_range_pct,
                ca.upper_wick,
                ca.lower_wick,
                ca.wick_ratio,
                ca.oc_pct,
                ca.gap_pct,
                ca.is_gap,
                ca.is_inside_bar,
                ca.rsi,
                ca.td_buy_count,
                ca.td_sell_count,
                ca.macd_cross_up,
                ca.macd_cross_dn,
                ca.bb_width,
                ca.bb_close_outside_lower,
                ca.bb_close_outside_upper,
                ca.candle_completely_below_lower,
                ca.candle_completely_above_upper,
                ca.rvol,
                ca.atr_pct,
                ca.chop,
                ca.vwap_dist_pct,
                ca.vwap_cross_up,
                ca.vwap_cross_dn,
                ca.stoch_rsi_k,
                ca.stoch_rsi_d,
                ca.mfi,
                ca.cmo,
                ca.roc,
                ca.trix,
                ca.ultimate_osc,
                ca.adx,
                ca.trend_regime,
                ca.volume_confirm,
                ca.squeeze_off,
                ca.adx_strong,
                ca.di_bull,
                ca.di_bear,
                ca.macd_bull,
                ca.macd_bear,
                ca.tsi_bull,
                ca.tsi_bear,
                ca.ema_stack_bull,
                ca.ema_stack_bear,
                ca.momentum_confirm_bull,
                ca.momentum_confirm_bear
            FROM ca
            INNER JOIN pairs
                ON UPPER(BTRIM(ca.ticker)) = pairs.ticker
               AND ca.date_et::text = pairs.date_et
            WHERE ca.timespan = 'm1'
              AND ca.session = 'regular'
              AND ca.bb_width IS NOT NULL
        """

    conn = db_connect(load_env_defaults())
    try:
        frames: list[pd.DataFrame] = []
        chunk_size = 200
        chunks = [pair_rows[idx : idx + chunk_size] for idx in range(0, len(pair_rows), chunk_size)]
        for chunk_idx, chunk in enumerate(chunks, start=1):
            print(f"fetch pair chunk {chunk_idx}/{len(chunks)} ({len(chunk)} ticker-days)", flush=True)
            frames.append(pd.read_sql_query(build_query(chunk), conn))
    finally:
        conn.close()
    frame = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
    if frame.empty:
        return frame
    frame = frame.sort_values(["ticker", "date_et", "ts_epoch"]).drop_duplicates(["ticker", "ts_epoch"], keep="last")
    return frame.reset_index(drop=True)


def annotate_from_runs(frame: pd.DataFrame, runs: pd.DataFrame) -> pd.DataFrame:
    df = frame.copy()
    for column in ("bull_hit", "bear_hit"):
        df[column] = False
    for column in ("bull_lead", "bear_lead", "bull_run_len", "bear_run_len"):
        df[column] = 0
    row_lookup = {
        (str(row["ticker"]), int(row["ts_epoch"])): int(idx)
        for idx, row in df[["ticker", "ts_epoch"]].iterrows()
    }
    for _, run in runs.iterrows():
        prefix = "bull" if str(run["direction"]) == "bull" else "bear"
        run_start = int(run["run_start_epoch"])
        run_length = int(run["run_length"])
        ticker = str(run["ticker"])
        for lead in (1, 2, 3):
            key = (ticker, run_start - (lead * 60))
            idx = row_lookup.get(key)
            if idx is None:
                continue
            current_lead = int(df.at[idx, f"{prefix}_lead"])
            if current_lead and current_lead <= lead:
                continue
            df.at[idx, f"{prefix}_hit"] = True
            df.at[idx, f"{prefix}_lead"] = int(lead)
            df.at[idx, f"{prefix}_run_len"] = run_length
    return df


def main() -> None:
    if not RUNS_CSV.exists():
        raise SystemExit(f"Missing run csv: {RUNS_CSV}")
    runs = pd.read_csv(RUNS_CSV)
    print(f"loaded {len(runs)} saved same-color runs", flush=True)
    base = fetch_run_day_frame(runs)
    if base.empty:
        raise SystemExit("No matched-day rows returned for saved runs.")
    print(f"loaded {len(base)} matched-day rows", flush=True)
    enriched = add_derived_columns(base)
    print("derived matched-day columns ready", flush=True)
    annotated = annotate_from_runs(enriched, runs)
    print("annotated saved runs onto matched-day rows", flush=True)

    report = {
        "window": {
            "start_date": str(runs["run_start_et"].min()),
            "end_date": str(runs["run_end_et"].max()),
            "base_timespan": "m1",
            "universe": "saved_run_days",
            "min_run": 10,
            "lead_start": 1,
            "lead_end": 3,
            "baseline_scope": "all m1 rows on ticker-days that actually produced a 10+ same-color run",
        },
        "event_summary": {
            "bull": build_event_summary(runs, "bull"),
            "bear": build_event_summary(runs, "bear"),
        },
        "study": {
            "bull": evaluate_focus_metrics(annotated, "bull", BULL_FOCUS),
            "bear": evaluate_focus_metrics(annotated, "bear", BEAR_FOCUS),
        },
    }

    report_path = OUTPUT_DIR / f"SAMECOLOR10PLUS_MATCHEDDAY_PRERUN_ANALYSIS_{RUN_DATE}.md"
    json_path = OUTPUT_DIR / f"SAMECOLOR10PLUS_MATCHEDDAY_PRERUN_ANALYSIS_{RUN_DATE}.json"
    json_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    summary = render_summary(report)
    baseline_note = (
        "\n## Baseline Scope\n"
        f"- `{report['window']['baseline_scope']}`\n"
    )
    report_path.write_text(summary + baseline_note, encoding="utf-8")
    print(report_path)
    print(json_path)


if __name__ == "__main__":
    main()
