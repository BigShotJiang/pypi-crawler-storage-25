import asyncio
import sys
from pathlib import Path
from datetime import date, timedelta

import pandas as pd
from dotenv import load_dotenv

project_dir = str(Path(__file__).resolve().parents[1])
if project_dir not in sys.path:
    sys.path.append(project_dir)

from fudstop4.apis.nasdaq.nasdaq_sdk import Nasdaq
from fudstop4.apis.polygonio.polygon_options import PolygonOptions

load_dotenv()

db = PolygonOptions()
sdk = Nasdaq()


async def fetch_day(day_value: date):
    try:
        payload = await sdk.economic_events(date=day_value.isoformat())
    except Exception as exc:
        print(f"[events] Skipping {day_value.isoformat()}: {exc}")
        return None
    df = payload.as_dataframe
    if df is None or df.empty:
        return None
    df["event_date"] = day_value.isoformat()
    return df


async def events() -> None:
    start_day = date.today()
    days = [start_day + timedelta(days=i) for i in range(15)]
    results = await asyncio.gather(*(fetch_day(day_value) for day_value in days))
    frames = [df for df in results if df is not None]
    if not frames:
        print("[events] No economic events found in the next two weeks.")
        return

    full_df = pd.concat(frames, ignore_index=True)
    await db.batch_upsert_dataframe(
        full_df,
        table_name="economic_events",
        unique_columns=["country", "event", "description", "event_date"],
    )
    print("[events] Econ events stored.")


async def scheduler() -> None:
    await db.connect()
    while True:
        print("[events] Running economic events scan...")
        try:
            await events()
        except Exception as exc:
            print("[events] Error during events scan:", exc)
        await asyncio.sleep(60 * 60 * 3)


if __name__ == "__main__":
    asyncio.run(scheduler())
