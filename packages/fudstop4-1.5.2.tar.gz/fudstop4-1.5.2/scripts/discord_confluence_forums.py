from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Set

import httpx
import requests
from discord_webhook import AsyncDiscordWebhook, DiscordEmbed
from dotenv import dotenv_values, load_dotenv


PROJECT_ROOT = Path(__file__).resolve().parents[1]
APP_ROOT = PROJECT_ROOT / "stock_market_site" / "app"
DEFAULT_GUILD_ID = "1457091273243758614"
DEFAULT_CATEGORY_NAME = "REFERENCE DATA"
DEFAULT_DATABASE = "fudstop3"
DEFAULT_REGISTRY_PATH = PROJECT_ROOT / "data" / "discord_confluence_registry.json"
DEFAULT_LIVE_THREAD_NAME = "live-feed"
DEFAULT_CONFLUENCE_THREAD_NAME = "confluence-tracker"
THREAD_AUTO_ARCHIVE_DURATION = 4320
DISCORD_API_BASE = "https://discord.com/api/v9"
SOURCE_TABLE_ALIASES: Dict[str, str] = {
    "earnings_estimate": "yf_earnings_estimate",
}

for env_path in (
    PROJECT_ROOT / ".env",
    PROJECT_ROOT / "stock_market_site" / ".env",
    PROJECT_ROOT / "stock_market_site" / "app" / ".env",
):
    if env_path.exists():
        load_dotenv(env_path, override=False)

if str(APP_ROOT) not in sys.path:
    sys.path.insert(0, str(APP_ROOT))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import routes.webhookroutes as webhookroutes  # noqa: E402
from routes.webhookroutes import FEED_LOOKUP, WEBHOOK_FEEDS  # noqa: E402
from fudstop4.apis.polygonio.polygon_options import PolygonOptions  # noqa: E402
from discord_feeds.analysts import publish_analyst_ratings  # noqa: E402
from discord_feeds.sentiment import publish_sentiment_board  # noqa: E402
from discord_feeds.stock_alerts import publish_stock_alerts  # noqa: E402
from discord_feeds.technical_events import publish_technical_events  # noqa: E402
from discord_feeds.volatile_rank import publish_volatile_rank_board  # noqa: E402


# Force the webhook dispatcher layer onto stored database tables instead of live API calls.
webhookroutes.ultim = None


@dataclass(frozen=True)
class BoardSpec:
    board_id: str
    kind: str
    forum_name: str
    display_name: str
    topic: str
    source_tables: tuple[str, ...]
    category_name: str = DEFAULT_CATEGORY_NAME
    family_key: str = "reference"
    family_label: str = "Reference"
    feed_id: str = ""
    webhook_slots: tuple[str, ...] = ("default",)
    live_thread_name: str = ""
    confluence_thread_name: str = DEFAULT_CONFLUENCE_THREAD_NAME
    confluence_label: str = ""
    confluence_sources: tuple[str, ...] = ()


FAMILY_META: Dict[str, Dict[str, Any]] = {
    "momentum": {
        "category_name": "MOMENTUM STACK",
        "family_label": "Momentum stack",
        "confluence_label": "Momentum confluence tracker",
        "confluence_sources": ("plays", "multi_quote"),
    },
    "flow": {
        "category_name": "FLOW & DERIVATIVES",
        "family_label": "Flow desk",
        "confluence_label": "Flow confluence tracker",
        "confluence_sources": ("volume_analysis", "atm_options", "wb_opts", "wb_trades", "gex", "iv_skew"),
    },
    "fundamentals": {
        "category_name": "FUNDAMENTALS & OWNERSHIP",
        "family_label": "Fundamentals",
        "confluence_label": "Fundamental confluence tracker",
        "confluence_sources": ("price_target",),
    },
    "leadership": {
        "category_name": "LEADERSHIP & ROTATION",
        "family_label": "Leadership",
        "confluence_label": "Leadership confluence tracker",
        "confluence_sources": ("plays", "multi_quote", "volume_analysis"),
    },
    "macro": {
        "category_name": "NEWS & MACRO",
        "family_label": "Macro wire",
        "confluence_label": "Narrative confluence tracker",
        "confluence_sources": ("multi_quote",),
    },
    "rates": {
        "category_name": "RATES & CREDIT",
        "family_label": "Rates & credit",
        "confluence_label": "Rates pressure tracker",
        "confluence_sources": (),
    },
    "reference": {
        "category_name": DEFAULT_CATEGORY_NAME,
        "family_label": "Reference",
        "confluence_label": "Reference confluence tracker",
        "confluence_sources": (),
    },
}


DISPATCHER_BOARD_OVERRIDES: Dict[str, Dict[str, Any]] = {
    "volume_flow": {
        "display_name": "Volume Flow",
        "family_key": "flow",
        "confluence_label": "Flow pressure tracker",
    },
    "td_signals": {
        "display_name": "TD Signal Stack",
        "family_key": "momentum",
        "confluence_label": "TD/RSI/MACD tracker",
    },
    "oi_outliers": {
        "display_name": "Open Interest Outliers",
        "family_key": "flow",
        "confluence_label": "OI pressure tracker",
    },
    "dark_pool_heat": {
        "display_name": "Dark Pool Heatmap",
        "family_key": "flow",
        "confluence_label": "Dark-pool confluence tracker",
    },
    "earnings_watch": {
        "display_name": "Earnings Watch",
        "family_key": "fundamentals",
        "confluence_label": "Event-risk tracker",
    },
    "iv_rank": {
        "display_name": "IV Rank Leaders",
        "family_key": "flow",
        "confluence_label": "Volatility regime tracker",
    },
    "iv_skew": {
        "display_name": "IV Skew Watch",
        "family_key": "flow",
        "confluence_label": "Skew regime tracker",
    },
    "macd_curvature": {
        "display_name": "MACD Curvature",
        "family_key": "momentum",
        "confluence_label": "Momentum structure tracker",
    },
    "cost_distribution": {
        "display_name": "Cost Distribution",
        "family_key": "flow",
        "confluence_label": "Holder crowding tracker",
    },
    "etf_holdings": {
        "display_name": "ETF Holdings Heat",
        "family_key": "fundamentals",
        "confluence_label": "Allocation tracker",
    },
    "top_followed": {
        "display_name": "Top Followed",
        "family_key": "leadership",
        "confluence_label": "Leadership tracker",
    },
    "volume_analysis_live": {
        "display_name": "Live Volume Regime",
        "family_key": "flow",
        "confluence_label": "Volume regime tracker",
    },
    "options_monitor": {
        "display_name": "Options Monitor",
        "family_key": "flow",
        "confluence_label": "Contract pressure tracker",
    },
    "financials": {
        "display_name": "Financial Statements",
        "family_key": "fundamentals",
        "confluence_label": "Fundamental score tracker",
    },
    "insider_buys": {
        "display_name": "Insider Buys",
        "family_key": "fundamentals",
        "confluence_label": "Ownership tracker",
    },
    "news_sentiment": {
        "display_name": "News Sentiment",
        "family_key": "macro",
        "confluence_label": "Narrative tracker",
    },
    "macro_calendar": {
        "display_name": "Macro Calendar",
        "family_key": "macro",
        "confluence_label": "Macro event tracker",
    },
    "ai_news_flash": {
        "display_name": "AI News Flash",
        "family_key": "macro",
        "confluence_label": "Narrative tracker",
    },
    "finra_short_flash": {
        "display_name": "FINRA Short Volume",
        "family_key": "macro",
        "confluence_label": "Short-pressure tracker",
    },
    "itm_flow": {
        "display_name": "ITM Flow",
        "family_key": "flow",
        "confluence_label": "ITM flow tracker",
    },
    "macd_consensus": {
        "display_name": "MACD Consensus",
        "family_key": "momentum",
        "confluence_label": "Momentum consensus tracker",
    },
    "atm_options_heat": {
        "display_name": "ATM Options Heat",
        "family_key": "flow",
        "confluence_label": "ATM flow tracker",
    },
    "iv_skew_watch_live": {
        "display_name": "IV Skew Live",
        "family_key": "flow",
        "confluence_label": "Skew pulse tracker",
    },
    "gappers": {
        "display_name": "Gap Movers",
        "family_key": "leadership",
        "confluence_label": "Gap confluence tracker",
    },
    "rise_movers": {
        "display_name": "Top Risers",
        "family_key": "leadership",
        "confluence_label": "Leadership tracker",
    },
    "fall_movers": {
        "display_name": "Top Fallers",
        "family_key": "leadership",
        "confluence_label": "Leadership tracker",
    },
    "gamma_pressure": {
        "display_name": "Gamma Pressure",
        "family_key": "flow",
        "confluence_label": "Dealer gamma tracker",
        "confluence_sources": ("gex",),
    },
    "factor_regimes": {
        "display_name": "Factor Regimes",
        "family_key": "momentum",
        "confluence_label": "Regime tracker",
    },
    "vol_regime_history": {
        "display_name": "Historic IVX Regime",
        "family_key": "momentum",
        "confluence_label": "Volatility regime tracker",
        "confluence_sources": ("iv_skew", "multi_quote"),
    },
    "capital_rotation": {
        "display_name": "Capital Rotation",
        "family_key": "flow",
        "confluence_label": "Rotation tracker",
        "confluence_sources": ("volume_analysis", "wb_trades"),
    },
    "earnings_estimates": {
        "display_name": "Earnings Estimate Curve",
        "family_key": "fundamentals",
        "confluence_label": "Estimate tracker",
    },
    "economic_event_wire": {
        "display_name": "Economic Event Wire",
        "family_key": "macro",
        "confluence_label": "Macro event tracker",
    },
    "form_4_wire": {
        "display_name": "Form 4 Wire",
        "family_key": "fundamentals",
        "confluence_label": "Ownership tracker",
    },
    "treasury_curve": {
        "display_name": "Treasury Curve Radar",
        "family_key": "rates",
        "confluence_label": "Rates pressure tracker",
    },
    "corporate_credit": {
        "display_name": "Corporate Credit Radar",
        "family_key": "rates",
        "confluence_label": "Credit pressure tracker",
    },
}


def _family_meta(family_key: str) -> Dict[str, Any]:
    return FAMILY_META.get(family_key, FAMILY_META["reference"])


def _forum_slug(value: str, fallback: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", str(value or "").strip().lower()).strip("-")
    return slug or str(fallback or "").strip().lower().replace("_", "-")


def _canonical_source_table_name(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    return SOURCE_TABLE_ALIASES.get(text, text)

SPECIALIZED_BOARD_SPECS: tuple[BoardSpec, ...] = (
    BoardSpec(
        board_id="analyst_ratings",
        kind="analyst_ratings",
        forum_name="analyst-ratings",
        display_name="Analyst Ratings",
        topic="Grouped analyst-rating cohorts sourced from the analysts table.",
        source_tables=("analysts",),
        category_name=_family_meta("fundamentals")["category_name"],
        family_key="fundamentals",
        family_label=_family_meta("fundamentals")["family_label"],
        confluence_label="Analyst conviction tracker",
    ),
    BoardSpec(
        board_id="stock_alerts",
        kind="stock_alerts",
        forum_name="stock-alerts",
        display_name="Stock Alerts",
        topic="Grouped stock-alert buckets sourced from the volume_alerts and change_alerts tables.",
        source_tables=("volume_alerts", "change_alerts"),
        category_name=_family_meta("momentum")["category_name"],
        family_key="momentum",
        family_label=_family_meta("momentum")["family_label"],
        webhook_slots=("a", "b"),
        confluence_label="Alert pressure tracker",
        confluence_sources=("plays", "volume_analysis"),
    ),
    BoardSpec(
        board_id="technical_events",
        kind="technical_events",
        forum_name="technical-patterns",
        display_name="Technical Events",
        topic="Grouped technical-event cohorts sourced from the technical_events table.",
        source_tables=("technical_events",),
        category_name=_family_meta("momentum")["category_name"],
        family_key="momentum",
        family_label=_family_meta("momentum")["family_label"],
        webhook_slots=("a", "b"),
        confluence_label="Pattern confluence tracker",
        confluence_sources=("plays",),
    ),
    BoardSpec(
        board_id="volatile_rank",
        kind="volatile_rank",
        forum_name="volatile-rank",
        display_name="Volatile Rank",
        topic="Volatility-rank cohorts sourced from the info table.",
        source_tables=("info",),
        category_name=_family_meta("leadership")["category_name"],
        family_key="leadership",
        family_label=_family_meta("leadership")["family_label"],
        confluence_label="Volatility leadership tracker",
    ),
    BoardSpec(
        board_id="sentiment",
        kind="sentiment",
        forum_name="sentiment-pulse",
        display_name="Sentiment",
        topic="Sentiment cohorts sourced from the info table.",
        source_tables=("info",),
        category_name=_family_meta("leadership")["category_name"],
        family_key="leadership",
        family_label=_family_meta("leadership")["family_label"],
        confluence_label="Sentiment tracker",
    ),
)

SKIPPED_FEED_IDS = {"analyst_moves"}


def resolve_auth_token() -> str:
    env_paths = (
        PROJECT_ROOT / ".env",
        PROJECT_ROOT / "stock_market_site" / ".env",
        PROJECT_ROOT / "stock_market_site" / "app" / ".env",
    )
    env_keys = ("BOT_TOKEN", "DISCORD_BOT_TOKEN", "STOCK_MARKET_SENTINEL")

    for env_path in env_paths:
        if not env_path.exists():
            continue
        values = dotenv_values(env_path)
        for key in env_keys:
            token = str(values.get(key) or "").strip()
            if token:
                return token if token.startswith("Bot ") else f"Bot {token}"

    for key in env_keys:
        token = str(os.getenv(key) or "").strip()
        if token:
            return token if token.startswith("Bot ") else f"Bot {token}"

    raise RuntimeError(
        "Missing Discord bot token. Set DISCORD_BOT_TOKEN, BOT_TOKEN, or STOCK_MARKET_SENTINEL."
    )


def build_dispatcher_specs() -> tuple[BoardSpec, ...]:
    specs: List[BoardSpec] = []
    for feed in WEBHOOK_FEEDS:
        if feed.id in SKIPPED_FEED_IDS:
            continue
        override = DISPATCHER_BOARD_OVERRIDES.get(feed.id, {})
        family_key = str(override.get("family_key") or "reference")
        family = _family_meta(family_key)
        display_name = str(override.get("display_name") or feed.name or feed.id).strip() or feed.id
        table_name = str(feed.table_name or "").strip()
        topic = str(override.get("topic") or feed.description or "").strip()
        if table_name:
            topic = f"{topic} Source table: {table_name}."
        specs.append(
            BoardSpec(
                board_id=feed.id,
                kind="dispatcher",
                forum_name=str(override.get("forum_name") or _forum_slug(display_name, feed.id)).strip() or feed.id,
                display_name=display_name,
                topic=topic,
                source_tables=(table_name,) if table_name else (),
                category_name=str(override.get("category_name") or family["category_name"]),
                family_key=family_key,
                family_label=str(override.get("family_label") or family["family_label"]),
                feed_id=feed.id,
                live_thread_name=DEFAULT_LIVE_THREAD_NAME,
                confluence_thread_name=str(
                    override.get("confluence_thread_name") or DEFAULT_CONFLUENCE_THREAD_NAME
                ).strip()
                or DEFAULT_CONFLUENCE_THREAD_NAME,
                confluence_label=str(
                    override.get("confluence_label") or family["confluence_label"]
                ).strip(),
                confluence_sources=tuple(
                    str(item).strip()
                    for item in (override.get("confluence_sources") or family["confluence_sources"])
                    if str(item).strip()
                ),
            )
        )
    return tuple(specs)


BOARD_SPECS: tuple[BoardSpec, ...] = SPECIALIZED_BOARD_SPECS + build_dispatcher_specs()


def webhook_name_for(spec: BoardSpec, slot: str) -> str:
    if slot == "default":
        return spec.display_name
    return f"{spec.display_name} {slot.upper()}"


def starter_content_for(spec: BoardSpec) -> str:
    table_text = ", ".join(table for table in spec.source_tables if table)
    lines = [f"{spec.display_name} live sync thread."]
    if table_text:
        lines.append(f"Source tables: {table_text}.")
    if spec.kind == "dispatcher" and spec.feed_id:
        lines.append(f"Feed id: {spec.feed_id}.")
    lines.append("Webhook posts below are refreshed from the stored database tables.")
    return "\n".join(lines)


def confluence_starter_content_for(spec: BoardSpec) -> str:
    tables = ", ".join(table for table in spec.source_tables if table)
    lines = [f"{spec.display_name} confluence tracker thread."]
    if spec.confluence_label:
        lines.append(spec.confluence_label)
    if tables:
        lines.append(f"Source tables: {tables}.")
    lines.append("Board-specific confluence matches from the stored confluence tables land below.")
    return "\n".join(lines)


def load_registry(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def write_registry(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


class DiscordProvisioner:
    def __init__(self, auth_token: str, *, dry_run: bool = False):
        self.auth_token = str(auth_token or "").strip()
        if not self.auth_token:
            raise ValueError("Missing Discord auth token.")
        if not self.auth_token.startswith("Bot "):
            self.auth_token = f"Bot {self.auth_token}"
        self.dry_run = bool(dry_run)
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Authorization": self.auth_token,
                "Content-Type": "application/json",
                "Accept": "*/*",
                "User-Agent": "FUDSTOPDiscordProvisioner/1.0",
            }
        )

    def _request(
        self,
        method: str,
        path: str,
        *,
        expected: Sequence[int] = (200, 201, 204),
        json_payload: Dict[str, Any] | None = None,
        params: Dict[str, Any] | None = None,
    ) -> Any:
        url = f"{DISCORD_API_BASE}{path}"
        if self.dry_run:
            print(f"[dry-run] {method} {url}")
            if json_payload is not None:
                print(f"[dry-run] payload={json.dumps(json_payload, ensure_ascii=True)}")
            return {}

        while True:
            response = self.session.request(
                method,
                url,
                json=json_payload,
                params=params,
                timeout=30,
            )
            if response.status_code == 429:
                retry_after = 1.25
                try:
                    retry_after = float(response.json().get("retry_after", retry_after))
                except Exception:
                    pass
                time.sleep(max(0.25, retry_after))
                continue
            if response.status_code not in expected:
                raise RuntimeError(f"{method} {path} failed ({response.status_code}): {response.text[:800]}")
            if response.status_code == 204 or not response.content:
                return {}
            return response.json()

    def get_guild_channels(self, guild_id: str) -> List[Dict[str, Any]]:
        data = self._request("GET", f"/guilds/{guild_id}/channels")
        return data if isinstance(data, list) else []

    def get_channel(self, channel_id: str) -> Dict[str, Any] | None:
        try:
            payload = self._request("GET", f"/channels/{channel_id}", expected=(200,))
        except RuntimeError:
            return None
        return payload if isinstance(payload, dict) else None

    def ensure_category(self, guild_id: str, name: str) -> Dict[str, Any]:
        for channel in self.get_guild_channels(guild_id):
            if int(channel.get("type") or -1) != 4:
                continue
            if str(channel.get("name") or "").strip().lower() == name.strip().lower():
                return channel
        payload = {"name": name, "type": 4}
        created = self._request("POST", f"/guilds/{guild_id}/channels", expected=(200, 201), json_payload=payload)
        if self.dry_run and not created.get("id"):
            created["id"] = f"dry-category-{name}"
        print(f"[create] category {name} -> {created.get('id')}")
        return created

    def ensure_forum_channel(
        self,
        guild_id: str,
        *,
        parent_id: str,
        spec: BoardSpec,
        existing_channel_id: str = "",
    ) -> Dict[str, Any]:
        existing: Dict[str, Any] | None = None
        if existing_channel_id:
            current = self.get_channel(existing_channel_id)
            if current and int(current.get("type") or -1) == 15:
                existing = current
        for channel in self.get_guild_channels(guild_id):
            if existing is not None:
                break
            if int(channel.get("type") or -1) != 15:
                continue
            if str(channel.get("name") or "").strip().lower() != spec.forum_name.lower():
                continue
            existing = channel
            break

        if existing is None:
            payload = {
                "name": spec.forum_name,
                "type": 15,
                "topic": spec.topic,
                "parent_id": str(parent_id),
                "default_auto_archive_duration": THREAD_AUTO_ARCHIVE_DURATION,
                "rate_limit_per_user": 0,
                "nsfw": False,
            }
            created = self._request(
                "POST",
                f"/guilds/{guild_id}/channels",
                expected=(200, 201),
                json_payload=payload,
            )
            if self.dry_run and not created.get("id"):
                created["id"] = f"dry-forum-{spec.forum_name}"
            print(f"[create] forum {spec.forum_name} -> {created.get('id')}")
            return created

        updates: Dict[str, Any] = {}
        if str(existing.get("name") or "").strip() != spec.forum_name:
            updates["name"] = spec.forum_name
        if str(existing.get("topic") or "") != spec.topic:
            updates["topic"] = spec.topic
        if str(existing.get("parent_id") or "") != str(parent_id):
            updates["parent_id"] = str(parent_id)
        if updates:
            existing = self._request(
                "PATCH",
                f"/channels/{existing['id']}",
                expected=(200,),
                json_payload=updates,
            )
            print(f"[update] forum {spec.forum_name} topic/parent synced")
        return existing

    def channel_webhooks(self, channel_id: str) -> List[Dict[str, Any]]:
        data = self._request("GET", f"/channels/{channel_id}/webhooks", expected=(200,))
        return data if isinstance(data, list) else []

    def ensure_webhook(self, channel_id: str, *, name: str) -> Dict[str, Any]:
        for hook in self.channel_webhooks(channel_id):
            if str(hook.get("name") or "").strip().lower() == name.strip().lower():
                return hook

        if self.dry_run:
            return {
                "id": f"dry-webhook-{channel_id}-{name}",
                "name": name,
                "url": f"https://discord.com/api/webhooks/dry-{channel_id}/{name}",
            }

        created = self._request(
            "POST",
            f"/channels/{channel_id}/webhooks",
            expected=(200, 201),
            json_payload={"name": name},
        )
        if not isinstance(created, dict):
            raise RuntimeError(f"Webhook creation returned unexpected payload for channel {channel_id}")
        print(f"[create] webhook {name} -> {created.get('id')}")
        return created

    def ensure_live_thread(
        self,
        forum_channel_id: str,
        *,
        thread_name: str,
        starter_content: str,
        existing_thread_id: str = "",
    ) -> Dict[str, Any]:
        if existing_thread_id:
            existing = self.get_channel(existing_thread_id)
            if existing:
                if str(existing.get("name") or "").strip() != thread_name and not self.dry_run:
                    existing = self._request(
                        "PATCH",
                        f"/channels/{existing_thread_id}",
                        expected=(200,),
                        json_payload={"name": thread_name},
                    )
                return existing

        if self.dry_run:
            return {"id": f"dry-thread-{forum_channel_id}-{thread_name}", "name": thread_name}

        payload = {
            "name": thread_name,
            "auto_archive_duration": THREAD_AUTO_ARCHIVE_DURATION,
            "applied_tags": [],
            "message": {"content": starter_content},
        }
        created = self._request(
            "POST",
            f"/channels/{forum_channel_id}/threads",
            expected=(200, 201),
            params={"use_nested_fields": "true"},
            json_payload=payload,
        )
        if not isinstance(created, dict) or not created.get("id"):
            raise RuntimeError(f"Discord did not return a thread id for forum {forum_channel_id}")
        print(f"[create] thread {thread_name} -> {created.get('id')}")
        return created


def build_board_registry(
    *,
    provisioner: DiscordProvisioner,
    guild_id: str,
    category_name: str,
    registry_path: Path,
) -> Dict[str, Any]:
    existing_registry = load_registry(registry_path)
    existing_boards = existing_registry.get("boards") or {}
    category_cache: Dict[str, Dict[str, Any]] = {}
    categories_payload: Dict[str, Dict[str, Any]] = {}

    boards_payload: Dict[str, Any] = {}
    for spec in BOARD_SPECS:
        category_label = str(spec.category_name or category_name).strip() or category_name
        category = category_cache.get(category_label)
        if category is None:
            category = provisioner.ensure_category(guild_id, category_label)
            category_cache[category_label] = category
        category_id = str(category.get("id") or "")
        if not category_id:
            raise RuntimeError(f"Could not resolve category ID for {category_label}")
        categories_payload[category_label] = {
            "id": category_id,
            "name": category_label,
            "family_label": spec.family_label,
            "family_key": spec.family_key,
        }

        prior_board = existing_boards.get(spec.board_id) if isinstance(existing_boards, dict) else {}
        prior_forum_channel_id = str((prior_board or {}).get("forum_channel_id") or "").strip()
        forum = provisioner.ensure_forum_channel(
            guild_id,
            parent_id=category_id,
            spec=spec,
            existing_channel_id=prior_forum_channel_id,
        )
        forum_channel_id = str(forum.get("id") or "")
        if not forum_channel_id:
            raise RuntimeError(f"Could not resolve forum ID for {spec.board_id}")

        webhooks_payload: Dict[str, Any] = {}
        for slot in spec.webhook_slots:
            webhook = provisioner.ensure_webhook(forum_channel_id, name=webhook_name_for(spec, slot))
            webhook_url = str(webhook.get("url") or "").strip()
            if not webhook_url:
                raise RuntimeError(f"Discord did not return a webhook URL for {spec.board_id}/{slot}")
            webhooks_payload[slot] = {
                "id": str(webhook.get("id") or ""),
                "name": str(webhook.get("name") or ""),
                "url": webhook_url,
            }

        live_thread_payload: Dict[str, Any] | None = None
        if spec.live_thread_name:
            prior_live = prior_board.get("live_thread") if isinstance(prior_board, dict) else {}
            prior_thread_id = str((prior_live or {}).get("id") or "").strip()
            live_thread = provisioner.ensure_live_thread(
                forum_channel_id,
                thread_name=spec.live_thread_name,
                starter_content=starter_content_for(spec),
                existing_thread_id=prior_thread_id,
            )
            live_thread_payload = {
                "id": str(live_thread.get("id") or ""),
                "name": str(live_thread.get("name") or spec.live_thread_name),
            }

        confluence_tracker_payload: Dict[str, Any] | None = None
        if spec.confluence_thread_name:
            prior_tracker = prior_board.get("confluence_tracker") if isinstance(prior_board, dict) else {}
            prior_tracker_id = str((prior_tracker or {}).get("id") or "").strip()
            tracker_thread = provisioner.ensure_live_thread(
                forum_channel_id,
                thread_name=spec.confluence_thread_name,
                starter_content=confluence_starter_content_for(spec),
                existing_thread_id=prior_tracker_id,
            )
            confluence_tracker_payload = {
                "id": str(tracker_thread.get("id") or ""),
                "name": str(tracker_thread.get("name") or spec.confluence_thread_name),
                "label": spec.confluence_label,
                "sources": list(spec.confluence_sources),
            }

        boards_payload[spec.board_id] = {
            "board_id": spec.board_id,
            "kind": spec.kind,
            "display_name": spec.display_name,
            "forum_name": spec.forum_name,
            "forum_channel_id": forum_channel_id,
            "category_name": category_label,
            "category_id": category_id,
            "family_key": spec.family_key,
            "family_label": spec.family_label,
            "topic": spec.topic,
            "source_tables": list(spec.source_tables),
            "feed_id": spec.feed_id,
            "webhooks": webhooks_payload,
            "live_thread": live_thread_payload,
            "confluence_tracker": confluence_tracker_payload,
        }

    registry = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "guild_id": str(guild_id),
        "category_name": category_name,
        "categories": categories_payload,
        "board_count": len(boards_payload),
        "boards": boards_payload,
    }
    write_registry(registry_path, registry)
    return registry


async def discord_request(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    **kwargs: Any,
) -> httpx.Response:
    max_attempts = 5
    response: httpx.Response | None = None
    for _ in range(max_attempts):
        response = await client.request(method, url, **kwargs)
        if response.status_code != 429:
            return response
        retry_after = 1.0
        try:
            payload = response.json()
        except Exception:
            payload = {}
        retry_after = float(payload.get("retry_after") or retry_after)
        await asyncio.sleep(retry_after + 0.25)
    assert response is not None
    return response


async def ensure_thread_open(
    client: httpx.AsyncClient,
    auth_header: str,
    thread_id: str,
    *,
    dry_run: bool = False,
) -> None:
    headers = {"Authorization": auth_header, "Content-Type": "application/json"}
    endpoint = f"{DISCORD_API_BASE}/channels/{thread_id}"
    response = await discord_request(client, "GET", endpoint, headers=headers)
    if response.status_code == 404:
        raise RuntimeError(f"Discord thread {thread_id} no longer exists.")
    response.raise_for_status()
    metadata = (response.json().get("thread_metadata") or {})
    if not metadata.get("archived"):
        return
    if dry_run:
        print(f"[dry-run] unarchive thread -> {thread_id}")
        return
    patch = await discord_request(
        client,
        "PATCH",
        endpoint,
        headers=headers,
        json={"archived": False},
    )
    patch.raise_for_status()


async def remove_webhook_messages(
    client: httpx.AsyncClient,
    auth_header: str,
    thread_id: str,
    webhook_id: str,
    *,
    dry_run: bool = False,
) -> int:
    if not webhook_id:
        return 0
    headers = {"Authorization": auth_header, "Content-Type": "application/json"}
    response = await discord_request(
        client,
        "GET",
        f"{DISCORD_API_BASE}/channels/{thread_id}/messages?limit=50",
        headers=headers,
    )
    response.raise_for_status()
    removed = 0
    for message in response.json():
        message_id = str(message.get("id") or "").strip()
        message_webhook_id = str(message.get("webhook_id") or "").strip()
        if not message_id or message_id == thread_id or message_webhook_id != webhook_id:
            continue
        if dry_run:
            removed += 1
            continue
        delete_response = await discord_request(
            client,
            "DELETE",
            f"{DISCORD_API_BASE}/channels/{thread_id}/messages/{message_id}",
            headers=headers,
        )
        delete_response.raise_for_status()
        removed += 1
    return removed


async def post_status_embed(
    *,
    webhook_url: str,
    title: str,
    description: str,
    footer: str,
    color: int = 0x69E2FF,
    dry_run: bool = False,
) -> None:
    embed = DiscordEmbed(title=title, description=description, color=color)
    embed.set_footer(text=footer)
    embed.set_timestamp()
    if dry_run:
        print(f"[dry-run] status embed -> {title}")
        return
    hook = AsyncDiscordWebhook(url=webhook_url)
    hook.add_embed(embed)
    await hook.execute()


async def fetch_board_tickers(
    db: PolygonOptions,
    board: Dict[str, Any],
    *,
    limit: int = 18,
) -> List[str]:
    source_tables = [
        _canonical_source_table_name(table)
        for table in (board.get("source_tables") or [])
        if _canonical_source_table_name(table)
    ]
    ticker_candidates = ("ticker", "symbol", "underlying")
    order_candidates = ("insertion_timestamp", "publish_datetime", "event_date", "publish_date", "date", "start_date")
    tickers: List[str] = []
    seen: Set[str] = set()
    for table_name in source_tables:
        try:
            columns = await db.get_table_columns(table_name)
        except Exception:
            continue
        ticker_field = next((field for field in ticker_candidates if field in columns), "")
        if not ticker_field:
            continue
        order_field = next((field for field in order_candidates if field in columns), "")
        query = f"SELECT {ticker_field} AS ticker FROM {table_name}"
        if order_field:
            query += f" ORDER BY {order_field} DESC NULLS LAST"
        query += f" LIMIT {max(limit * 4, 24)}"
        try:
            rows = await db.fetch(query)
        except Exception:
            continue
        for raw in rows or []:
            ticker = str(dict(raw).get("ticker") or "").strip().upper()
            if not ticker or ticker in seen:
                continue
            seen.add(ticker)
            tickers.append(ticker)
            if len(tickers) >= limit:
                return tickers
    return tickers


async def fetch_confluence_matches(
    db: PolygonOptions,
    *,
    tickers: List[str],
    source_tokens: List[str],
    limit: int,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if tickers:
        try:
            master_rows = await db.fetch(
                """
                SELECT ticker, total_points, combined_signal, source_breakdown, insertion_timestamp
                FROM confluence_master
                WHERE ticker = ANY($1::text[])
                ORDER BY ABS(total_points) DESC NULLS LAST, insertion_timestamp DESC NULLS LAST
                LIMIT $2
                """,
                tickers,
                limit,
            )
            rows = [dict(row) for row in master_rows or []]
        except Exception:
            rows = []
        if not rows:
            try:
                focus_rows = await db.fetch(
                    """
                    SELECT
                        ticker,
                        total_points,
                        combined_signal,
                        CONCAT_WS(
                            ' | ',
                            NULLIF(COALESCE(gex_reason, ''), ''),
                            NULLIF(COALESCE(atm_reason, ''), ''),
                            NULLIF(COALESCE(price_target_reason, ''), '')
                        ) AS source_breakdown,
                        insertion_timestamp
                    FROM confluence_focus
                    WHERE ticker = ANY($1::text[])
                    ORDER BY ABS(total_points) DESC NULLS LAST, insertion_timestamp DESC NULLS LAST
                    LIMIT $2
                    """,
                    tickers,
                    limit,
                )
                rows = [dict(row) for row in focus_rows or []]
            except Exception:
                rows = []
        if rows:
            return rows

    try:
        master_rows = await db.fetch(
            """
            SELECT ticker, total_points, combined_signal, source_breakdown, insertion_timestamp
            FROM confluence_master
            ORDER BY ABS(total_points) DESC NULLS LAST, insertion_timestamp DESC NULLS LAST
            LIMIT 120
            """
        )
    except Exception:
        master_rows = []
    if source_tokens:
        lowered_tokens = [token.lower() for token in source_tokens if token]
        filtered = []
        for raw in master_rows or []:
            row = dict(raw)
            breakdown = str(row.get("source_breakdown") or "").lower()
            if any(token in breakdown for token in lowered_tokens):
                filtered.append(row)
            if len(filtered) >= limit:
                return filtered
        if filtered:
            return filtered
    if master_rows:
        return [dict(row) for row in list(master_rows)[:limit]]

    try:
        focus_rows = await db.fetch(
            """
            SELECT
                ticker,
                total_points,
                combined_signal,
                CONCAT_WS(
                    ' | ',
                    NULLIF(COALESCE(gex_reason, ''), ''),
                    NULLIF(COALESCE(atm_reason, ''), ''),
                    NULLIF(COALESCE(price_target_reason, ''), '')
                ) AS source_breakdown,
                insertion_timestamp
            FROM confluence_focus
            ORDER BY ABS(total_points) DESC NULLS LAST, insertion_timestamp DESC NULLS LAST
            LIMIT $1
            """,
            limit,
        )
    except Exception:
        focus_rows = []
    return [dict(row) for row in focus_rows or []]


async def sync_confluence_tracker(
    *,
    client: httpx.AsyncClient,
    auth_header: str,
    board: Dict[str, Any],
    db: PolygonOptions,
    limit: int,
    dry_run: bool = False,
) -> int:
    tracker = board.get("confluence_tracker") or {}
    thread_id = str(tracker.get("id") or "").strip()
    if not thread_id:
        return 0

    webhook_payload = (board.get("webhooks") or {}).get("default") or {}
    webhook_url = str(webhook_payload.get("url") or "").strip()
    webhook_id = str(webhook_payload.get("id") or "").strip()
    if not webhook_url:
        return 0

    await ensure_thread_open(client, auth_header, thread_id, dry_run=dry_run)
    await remove_webhook_messages(client, auth_header, thread_id, webhook_id, dry_run=dry_run)

    tickers = await fetch_board_tickers(db, board, limit=max(limit * 3, 12))
    source_tokens = [
        str(token).strip()
        for token in (tracker.get("sources") or [])
        if str(token).strip()
    ]
    rows = await fetch_confluence_matches(
        db,
        tickers=tickers,
        source_tokens=source_tokens,
        limit=max(1, limit),
    )

    sep = "&" if "?" in webhook_url else "?"
    target_url = f"{webhook_url}{sep}thread_id={thread_id}"
    tracker_label = str(tracker.get("label") or "Confluence tracker").strip() or "Confluence tracker"
    if not rows:
        await post_status_embed(
            webhook_url=target_url,
            title=f"{board.get('display_name')} - Confluence tracker idle",
            description="```py\nNo live confluence names are currently mapped to this board.\n```",
            footer=f"{board.get('board_id')} | confluence tracker",
            color=0x4C6A7F,
            dry_run=dry_run,
        )
        return 0

    lines: List[str] = []
    for raw in rows[:limit]:
        ticker = str(raw.get("ticker") or "").strip() or "Ticker"
        signal = str(raw.get("combined_signal") or "neutral").strip() or "neutral"
        total_points = raw.get("total_points")
        try:
            points_text = f"{float(total_points):+.2f}"
        except Exception:
            points_text = str(total_points or "n/a")
        breakdown = str(raw.get("source_breakdown") or "").strip()
        if len(breakdown) > 140:
            breakdown = f"{breakdown[:137]}..."
        lines.append(f"> **{ticker}** | {signal} | {points_text} pts")
        if breakdown:
            lines.append(f"> {breakdown}")

    embed = DiscordEmbed(
        title=f"{board.get('display_name')} - {tracker_label}",
        description="\n".join(lines) or "> No active confluence rows",
        color=0x69E2FF,
    )
    embed.set_footer(text=f"{board.get('board_id')} | confluence_master / confluence_focus")
    embed.set_timestamp()
    if dry_run:
        print(f"[dry-run] confluence tracker -> {board.get('board_id')}")
        return min(len(rows), limit)
    hook = AsyncDiscordWebhook(target_url)
    hook.add_embed(embed)
    await hook.execute()
    return min(len(rows), limit)


async def sync_dispatcher_board(
    *,
    client: httpx.AsyncClient,
    auth_header: str,
    board: Dict[str, Any],
    limit: int,
    dry_run: bool = False,
) -> int:
    feed_id = str(board.get("feed_id") or "").strip()
    if not feed_id:
        raise RuntimeError(f"Missing feed_id for board {board.get('board_id')}")
    feed = FEED_LOOKUP.get(feed_id)
    if feed is None:
        raise RuntimeError(f"Missing webhook dispatcher for feed {feed_id}")

    live_thread = board.get("live_thread") or {}
    thread_id = str(live_thread.get("id") or "").strip()
    if not thread_id:
        raise RuntimeError(f"Missing live thread for board {board.get('board_id')}")

    webhook_payload = (board.get("webhooks") or {}).get("default") or {}
    webhook_url = str(webhook_payload.get("url") or "").strip()
    webhook_id = str(webhook_payload.get("id") or "").strip()
    if not webhook_url:
        raise RuntimeError(f"Missing webhook URL for board {board.get('board_id')}")

    await ensure_thread_open(client, auth_header, thread_id, dry_run=dry_run)
    await remove_webhook_messages(client, auth_header, thread_id, webhook_id, dry_run=dry_run)

    sep = "&" if "?" in webhook_url else "?"
    target_url = f"{webhook_url}{sep}thread_id={thread_id}"
    sent_count = await feed.dispatcher(target_url, limit, dry_run)
    if sent_count:
        return int(sent_count)

    await post_status_embed(
        webhook_url=target_url,
        title=f"{board.get('display_name')} - No current rows",
        description="```py\nNo qualifying rows are currently available in the stored table snapshot for this board.\n```",
        footer=f"{board.get('board_id')} | table-backed forum sync",
        dry_run=dry_run,
    )
    return 0


async def sync_specialized_board(
    *,
    board: Dict[str, Any],
    database: str,
    dry_run: bool = False,
) -> None:
    board_id = str(board.get("board_id") or "")
    forum_channel_id = str(board.get("forum_channel_id") or "").strip()
    webhooks = board.get("webhooks") or {}

    if board_id == "analyst_ratings":
        await publish_analyst_ratings(
            webhook_url=str((webhooks.get("default") or {}).get("url") or "").strip(),
            database=database,
            dry_run=dry_run,
        )
        return

    if board_id == "stock_alerts":
        await publish_stock_alerts(
            webhook_a_url=str((webhooks.get("a") or {}).get("url") or "").strip(),
            webhook_b_url=str((webhooks.get("b") or {}).get("url") or "").strip(),
            database=database,
            dry_run=dry_run,
        )
        return

    if board_id == "technical_events":
        await publish_technical_events(
            channel_id=forum_channel_id,
            webhook_a_url=str((webhooks.get("a") or {}).get("url") or "").strip(),
            webhook_b_url=str((webhooks.get("b") or {}).get("url") or "").strip(),
            lookback_days=3,
            database=database,
            dry_run=dry_run,
        )
        return

    if board_id == "volatile_rank":
        await publish_volatile_rank_board(
            webhook_url=str((webhooks.get("default") or {}).get("url") or "").strip(),
            forum_channel_id=forum_channel_id,
            cache_path=PROJECT_ROOT / "data" / "volatile_rank_threads.json",
            dry_run=dry_run,
        )
        return

    if board_id == "sentiment":
        await publish_sentiment_board(
            webhook_url=str((webhooks.get("default") or {}).get("url") or "").strip(),
            forum_channel_id=forum_channel_id,
            cache_path=PROJECT_ROOT / "data" / "sentiment_threads.json",
            dry_run=dry_run,
        )
        return

    raise RuntimeError(f"Unsupported specialized board {board_id}")


async def sync_registry(
    *,
    registry: Dict[str, Any],
    auth_header: str,
    database: str,
    limit: int,
    dry_run: bool = False,
) -> Dict[str, Any]:
    results: Dict[str, Any] = {"synced": {}, "errors": {}}
    boards = registry.get("boards") or {}
    tracker_db = PolygonOptions(database=database)
    await tracker_db.connect()

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            for board_id, board in boards.items():
                try:
                    if str(board.get("kind") or "") == "dispatcher":
                        sent_count = await sync_dispatcher_board(
                            client=client,
                            auth_header=auth_header,
                            board=board,
                            limit=limit,
                            dry_run=dry_run,
                        )
                        tracker_count = await sync_confluence_tracker(
                            client=client,
                            auth_header=auth_header,
                            board=board,
                            db=tracker_db,
                            limit=limit,
                            dry_run=dry_run,
                        )
                        results["synced"][board_id] = {
                            "sent_count": int(sent_count),
                            "tracker_count": int(tracker_count),
                        }
                        continue

                    await sync_specialized_board(
                        board=board,
                        database=database,
                        dry_run=dry_run,
                    )
                    tracker_count = await sync_confluence_tracker(
                        client=client,
                        auth_header=auth_header,
                        board=board,
                        db=tracker_db,
                        limit=limit,
                        dry_run=dry_run,
                    )
                    results["synced"][board_id] = {
                        "sent_count": "specialized",
                        "tracker_count": int(tracker_count),
                    }
                except Exception as exc:
                    results["errors"][board_id] = str(exc)
                    print(f"[error] {board_id}: {exc}")
    finally:
        try:
            await tracker_db.disconnect()
        except Exception:
            pass
    return results


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Provision Discord forum boards and sync database-backed confluence feeds into them."
    )
    parser.add_argument("--guild-id", default=DEFAULT_GUILD_ID)
    parser.add_argument("--category-name", default=DEFAULT_CATEGORY_NAME)
    parser.add_argument("--database", default=DEFAULT_DATABASE)
    parser.add_argument("--registry-path", default=str(DEFAULT_REGISTRY_PATH))
    parser.add_argument("--limit", type=int, default=5)
    parser.add_argument("--provision-only", action="store_true")
    parser.add_argument("--sync-only", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


async def async_main(args: argparse.Namespace) -> int:
    auth_token = resolve_auth_token()
    registry_path = Path(args.registry_path)

    registry: Dict[str, Any]
    if args.sync_only:
        registry = load_registry(registry_path)
        if not registry:
            raise RuntimeError(f"Registry not found at {registry_path}. Run provisioning first.")
    else:
        provisioner = DiscordProvisioner(auth_token, dry_run=bool(args.dry_run))
        registry = build_board_registry(
            provisioner=provisioner,
            guild_id=str(args.guild_id),
            category_name=str(args.category_name),
            registry_path=registry_path,
        )
        print(f"[done] registry -> {registry_path}")
        if args.provision_only:
            return 0

    results = await sync_registry(
        registry=registry,
        auth_header=auth_token,
        database=str(args.database or DEFAULT_DATABASE),
        limit=max(1, min(int(args.limit or 1), 10)),
        dry_run=bool(args.dry_run),
    )
    registry["last_sync_at"] = datetime.now(timezone.utc).isoformat()
    registry["last_sync"] = results
    write_registry(registry_path, registry)
    print(
        f"[sync] ok={len(results['synced'])} error={len(results['errors'])} "
        f"registry={registry_path}"
    )
    return 0 if not results["errors"] else 1


def main() -> None:
    args = parse_args()
    raise SystemExit(asyncio.run(async_main(args)))


if __name__ == "__main__":
    main()
