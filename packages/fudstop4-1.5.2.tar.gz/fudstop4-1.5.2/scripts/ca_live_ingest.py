#!/usr/bin/env python3
"""
ca_live_ingest.py

Live multi-timespan candle ingestion for your ticker universe.

Goal:
- Maintain a "history" table: public.ca (already exists) with ONLY the base CA columns.
- Maintain a "live snapshot" table: public.ca_live with the latest candle per ticker+timespan
  PLUS the full TA indicator set from fudstop4.apis._ta.ta_sdk.FudstopTA.

Design choices (optimized for speed + "trade-like" usage):
- Poll every --sleep seconds (default 5s).
- Only do heavy indicator recompute when a NEW candle timestamp appears for a ticker+timespan.
  (So you can poll fast without recomputing TA every poll.)
- Keep a per-ticker rolling buffer in memory (default 1200 bars) so indicators compute fast
  without refetching large history every time.
- Upsert base rows into public.ca (on_conflict_update=True, so late corrections can update).
- Upsert ONE latest row per ticker+timespan into public.ca_live (primary key ticker+timespan).

Requirements:
- ACCESS_TOKEN in environment or .env (Webull)
- Your existing modules:
  - fudstop4.apis.helpers.generate_webull_headers
  - fudstop4.apis.webull.webull_trading.WebullTrading (ticker_to_id_map)
  - MODELS.webull_candles.WebullCandles (parses query-mini rows -> DataFrame)
  - fudstop4.apis.polygonio.polygon_options.PolygonOptions (DB wrapper)
  - fudstop4.apis._ta.ta_sdk.FudstopTA (indicators)
"""

import argparse
import asyncio
import json
import os
import re
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

import aiohttp
import numpy as np
import pandas as pd
from dotenv import load_dotenv
from zoneinfo import ZoneInfo

def _bootstrap_repo_path() -> Path:
    """
    Ensure imports resolve from this repo root.
    """
    here = Path(__file__).resolve()
    for candidate in [here.parent, *here.parents]:
        if (candidate / "MODELS").is_dir() and (candidate / "fudstop4").is_dir():
            root = candidate
            break
    else:
        # Expected layout fallback: <repo>/scripts/ca_live_ingest.py
        root = here.parents[1]

    root_str = str(root)
    if root_str in sys.path:
        sys.path.remove(root_str)
    sys.path.insert(0, root_str)
    return root


PROJECT_ROOT = _bootstrap_repo_path()
# Optional event-loop speedup (nice win if installed)
try:
    import uvloop  # type: ignore
    uvloop.install()
except Exception:
    pass

from fudstop4.apis.helpers import generate_webull_headers
from fudstop4.apis.webull.webull_trading import WebullTrading
from fudstop4.apis.polygonio.polygon_options import PolygonOptions
from fudstop4.apis._ta.ta_sdk import FudstopTA
from fudstop4._markets.list_sets.ticker_lists import most_active_tight_spread_tickers

from MODELS.webull_candles import WebullCandles
from scripts.ca_bollinger_config import CA_BB_NUM_STD, CA_BB_TREND_POINTS, CA_BB_WINDOW

ET = ZoneInfo("America/New_York")

QUERY_MINI_URL = "https://quotes-gw.webullfintech.com/api/quote/charts/query-mini"
QUERY_URL = "https://quotes-gw.webullfintech.com/api/quote/charts/query"
KDATA_LATEST_URL = "https://quotes-gw.webullfintech.com/api/quote/charts/kdata/latest"

# -------------------------
# Defaults / Speed knobs
# -------------------------
DEFAULT_TIMESPANS = ["m1", "m5", "m15", "m30", "m60", "m120", "m240", "d1", "w1", "mth1"]
DEFAULT_TIMESPAN = DEFAULT_TIMESPANS[0]
DEFAULT_SEED_COUNT = 1000        # initial buffer fill per ticker (covers most of a full extended-session day)
DEFAULT_LIVE_COUNT = 10          # small polling payload
DEFAULT_BUFFER_BARS = 1200       # rolling in-memory buffer per ticker
DEFAULT_SLEEP_S = 5.0
DEFAULT_PASS_BUDGET_S = 25.0
MIN_TA_WARMUP_BARS = 120

HTTP_RETRIES = 3
HTTP_RETRY_BACKOFF_S = 0.15
REQUEST_TIMEOUT_S = 20

MAX_CONCURRENT_TICKERS = 8       # lower default pressure to stay inside Webull limits
DB_BATCH_SIZE = 5000             # for batch_upsert_dataframe

# Candle request params
EXTEND_TRADING = 0
LOAD_FACTOR = 1
RESTORATION_TYPE = 1

# Base candle fields coming from WebullCandles
BASE_CANDLE_COLS = ["ts", "o", "c", "h", "l", "vw", "v", "a", "ticker", "ticker_id", "timespan"]

TIMESPAN_POLL_INTERVAL_SECONDS = {
    "m1": 45,
    "m5": 300,
    "m15": 900,
    "m30": 1800,
    "m60": 3600,
    "m120": 7200,
    "m240": 14400,
    "d1": 86400,
    "w1": 604800,
    "mth1": 2592000,
}

TIMESPAN_SEED_COUNT_CAPS = {
    "m1": 600,
    "m5": 320,
    "m15": 240,
    "m30": 180,
    "m60": 160,
    "m120": 140,
    "m240": 120,
    "d1": 90,
    "w1": 52,
    "mth1": 36,
}

TIMESPAN_LIVE_COUNT_CAPS = {
    "m1": 4,
    "m5": 3,
    "m15": 3,
    "m30": 2,
    "m60": 2,
    "m120": 2,
    "m240": 2,
    "d1": 2,
    "w1": 2,
    "mth1": 2,
}


# -------------------------
# CLI
# -------------------------
def _parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Live ingest multi-timespan candles into ca + ca_live.")
    ap.add_argument("--timespan", default="", help="Legacy single-timespan override.")
    ap.add_argument(
        "--timespans",
        default=",".join(DEFAULT_TIMESPANS),
        help="Comma list of raw Webull timespans to ingest concurrently.",
    )
    ap.add_argument("--sleep", type=float, default=DEFAULT_SLEEP_S)
    ap.add_argument("--pass-budget", type=float, default=DEFAULT_PASS_BUDGET_S)

    ap.add_argument("--use-most-active", action="store_true", help="Use most_active_tight_spread_tickers")
    ap.add_argument(
        "--tickers",
        default="",
        help="Comma list if not using --use-most-active",
    )
    ap.add_argument("--max-tickers", type=int, default=0)

    ap.add_argument("--seed-count", type=int, default=DEFAULT_SEED_COUNT)
    ap.add_argument("--live-count", type=int, default=DEFAULT_LIVE_COUNT)
    ap.add_argument("--buffer-bars", type=int, default=DEFAULT_BUFFER_BARS)

    ap.add_argument("--concurrency", type=int, default=MAX_CONCURRENT_TICKERS)

    ap.add_argument("--history-table", default="ca")
    ap.add_argument("--live-table", default="ca_live")

    ap.add_argument("--no-history", action="store_true", help="Do not write public.ca (debug)")
    ap.add_argument("--no-live", action="store_true", help="Do not write public.ca_live (debug)")

    ap.add_argument("--progress-every", type=int, default=25)
    ap.add_argument(
        "--state-file",
        default="ca_live_state.json",
        help="Local checkpoint file (last_ts per ticker|timespan pair)",
    )

    return ap.parse_args()


def _parse_tickers(raw: str) -> List[str]:
    return [t.strip().upper() for t in (raw or "").split(",") if t.strip()]


def _normalize_timespan_code(value: Any) -> str:
    raw = str(value or "").strip().lower()
    mapping = {
        "m1": "m1",
        "1m": "m1",
        "1min": "m1",
        "m5": "m5",
        "5m": "m5",
        "5min": "m5",
        "m15": "m15",
        "15m": "m15",
        "15min": "m15",
        "m30": "m30",
        "30m": "m30",
        "30min": "m30",
        "m60": "m60",
        "60m": "m60",
        "60min": "m60",
        "1h": "m60",
        "1hr": "m60",
        "h1": "m60",
        "m120": "m120",
        "120m": "m120",
        "120min": "m120",
        "2h": "m120",
        "2hr": "m120",
        "h2": "m120",
        "m240": "m240",
        "240m": "m240",
        "240min": "m240",
        "4h": "m240",
        "4hr": "m240",
        "h4": "m240",
        "d1": "d1",
        "1d": "d1",
        "day": "d1",
        "daily": "d1",
        "w1": "w1",
        "1w": "w1",
        "week": "w1",
        "weekly": "w1",
        "mth1": "mth1",
        "mo1": "mth1",
        "1mo": "mth1",
        "month": "mth1",
        "monthly": "mth1",
    }
    return mapping.get(raw, raw)


def _parse_timespans(raw: str) -> List[str]:
    seen: set[str] = set()
    ordered: List[str] = []
    for item in str(raw or "").split(","):
        normalized = _normalize_timespan_code(item)
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        ordered.append(normalized)
    return ordered


def _state_key(ticker: str, timespan: str) -> str:
    return f"{ticker}|{timespan}"


def _sql_quote(value: str) -> str:
    return value.replace("'", "''")


# -------------------------
# Small utilities
# -------------------------
def _timespan_to_seconds(timespan: str) -> int:
    normalized = _normalize_timespan_code(timespan)
    if not normalized:
        raise ValueError("timespan must be non-empty")

    match = re.match(r"^([a-z]+)(\d+)$", normalized)
    if match:
        unit = match.group(1)
        qty = int(match.group(2))
    else:
        match = re.match(r"^(\d+)([a-z]+)$", normalized)
        if not match:
            raise ValueError(f"unsupported timespan format: {timespan}")
        qty = int(match.group(1))
        unit = match.group(2)

    unit_seconds = {
        "s": 1, "sec": 1, "secs": 1, "second": 1, "seconds": 1,
        "m": 60, "min": 60, "mins": 60, "minute": 60, "minutes": 60,
        "h": 3600, "hr": 3600, "hrs": 3600, "hour": 3600, "hours": 3600,
        "d": 86400, "day": 86400, "days": 86400,
        "w": 604800, "wk": 604800, "wks": 604800, "week": 604800, "weeks": 604800,
        "mo": 2592000, "mon": 2592000, "mth": 2592000, "month": 2592000, "months": 2592000,
    }
    if unit not in unit_seconds:
        raise ValueError(f"unsupported timespan unit: {unit}")
    return qty * unit_seconds[unit]


def _poll_interval_for_timespan(timespan: str) -> int:
    normalized = _normalize_timespan_code(timespan)
    return int(TIMESPAN_POLL_INTERVAL_SECONDS.get(normalized, max(60, _timespan_to_seconds(normalized))))


def _seed_count_for_timespan(timespan: str, configured: int) -> int:
    normalized = _normalize_timespan_code(timespan)
    cap = TIMESPAN_SEED_COUNT_CAPS.get(normalized, int(configured))
    return max(60, min(int(configured), int(cap)))


def _live_count_for_timespan(timespan: str, configured: int) -> int:
    normalized = _normalize_timespan_code(timespan)
    cap = TIMESPAN_LIVE_COUNT_CAPS.get(normalized, int(configured))
    return max(2, min(int(configured), int(cap)))


async def _get_json_with_retries(
    session: aiohttp.ClientSession,
    url: str,
    *,
    retries: int = HTTP_RETRIES,
    backoff_s: float = HTTP_RETRY_BACKOFF_S,
    headers_factory: Optional[Callable[[], Dict[str, str]]] = None,
) -> Any:
    last_err: Optional[BaseException] = None
    for attempt in range(max(1, retries)):
        try:
            request_headers = headers_factory() if headers_factory else None
            async with session.get(url, headers=request_headers) as resp:
                if resp.status == 429:
                    retry_after = resp.headers.get("Retry-After")
                    wait_s = float(retry_after) if retry_after else backoff_s * (2 ** attempt)
                    resp.release()
                    await asyncio.sleep(wait_s)
                    continue
                if resp.status in (401, 403):
                    last_err = aiohttp.ClientResponseError(
                        resp.request_info,
                        resp.history,
                        status=resp.status,
                        message=resp.reason or "Forbidden",
                        headers=resp.headers,
                    )
                    resp.release()
                    if attempt == retries - 1:
                        raise last_err
                    await asyncio.sleep(backoff_s * (2 ** attempt))
                    continue
                resp.raise_for_status()
                return await resp.json(content_type=None)
        except Exception as e:
            last_err = e
            if attempt == retries - 1:
                raise
            await asyncio.sleep(backoff_s * (2 ** attempt))
    if last_err:
        raise last_err
    return None


def _parse_webull_rows(rows: List[str], *, ticker: str, ticker_id: int, timespan: str) -> pd.DataFrame:
    if not rows:
        return pd.DataFrame()
    model = WebullCandles(
        rows,
        ticker=ticker,
        ticker_id=ticker_id,
        timespan=timespan,
        fast_parse=True,
    )
    df = model.as_dataframe
    if df is None or df.empty:
        return pd.DataFrame()
    # Ensure base col order exists
    for col in BASE_CANDLE_COLS:
        if col not in df.columns:
            # WebullCandles should include these, but fail gracefully.
            df[col] = None
    return df[BASE_CANDLE_COLS].copy()


def _safe_int(v: Any, default: int = 0) -> int:
    try:
        return int(v)
    except Exception:
        return default


def _candle_endpoint_urls(*, ticker_id: int, timespan: str, count: int, anchor_ts: int) -> List[str]:
    normalized = _normalize_timespan_code(timespan)
    urls = [
        (
            f"{KDATA_LATEST_URL}"
            f"?tickerIds={int(ticker_id)}"
            f"&type={timespan}"
            f"&count={int(count)}"
            f"&timestamp={int(anchor_ts)}"
            f"&restorationType={int(RESTORATION_TYPE)}"
            f"&direction=1"
            f"&extendTrading={int(EXTEND_TRADING)}"
        ),
        (
            f"{QUERY_URL}"
            f"?tickerIds={int(ticker_id)}"
            f"&type={timespan}"
            f"&timestamp={int(anchor_ts)}"
            f"&count={int(count)}"
            f"&extendTrading={int(EXTEND_TRADING)}"
        ),
    ]
    if normalized not in {"d1", "w1", "mth1"}:
        urls.append(
            (
                f"{QUERY_MINI_URL}"
                f"?type={timespan}"
                f"&count={int(count)}"
                f"&timestamp={int(anchor_ts)}"
                f"&restorationType={int(RESTORATION_TYPE)}"
                f"&tickerId={int(ticker_id)}"
                f"&hasMore=true"
                f"&loadFactor={int(LOAD_FACTOR)}"
                f"&extendTrading={int(EXTEND_TRADING)}"
            )
        )
    return urls


def _add_time_columns(df: pd.DataFrame) -> pd.DataFrame:
    # ts is epoch seconds (int)
    dt_et = pd.to_datetime(pd.to_numeric(df["ts"], errors="coerce"), unit="s", utc=True).dt.tz_convert(ET)
    df["date_et"] = dt_et.dt.date.astype(str)
    df["time_et"] = dt_et.dt.strftime("%H:%M")
    df["dow_et"] = dt_et.dt.dayofweek.astype("int16")

    hhmm = dt_et.dt.hour * 100 + dt_et.dt.minute
    df["session"] = np.select(
        [
            (hhmm >= 400) & (hhmm < 930),
            (hhmm >= 930) & (hhmm < 1600),
            (hhmm >= 1600) & (hhmm <= 2000),
        ],
        ["pre", "regular", "after"],
        default="closed",
    )
    return df


def compute_local_metrics(df: pd.DataFrame, *, interval_s: int) -> pd.DataFrame:
    """
    Same spirit as your backfill script:
    - prev_* fields
    - candle body/wicks
    - gap detection
    - true range
    - inside bar
    """
    if df.empty:
        return df

    df = df.sort_values("ts", kind="mergesort").reset_index(drop=True)

    for col in ["o", "h", "l", "c", "v", "vw", "a"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    df["ts"] = pd.to_numeric(df["ts"], errors="coerce").astype("int64")

    df["prev_ts"] = df["ts"].shift(1)
    df["prev_close"] = df["c"].shift(1)
    df["prev_high"] = df["h"].shift(1)
    df["prev_low"] = df["l"].shift(1)

    df["change"] = df["c"] - df["prev_close"]
    df["change_pct"] = (df["change"] / df["prev_close"]) * 100.0
    with np.errstate(divide="ignore", invalid="ignore"):
        df["log_return"] = np.log(df["c"] / df["prev_close"])

    df["candle_color"] = np.select(
        [df["c"] > df["o"], df["c"] < df["o"]],
        ["green", "red"],
        default="doji",
    )
    df["candle_dir"] = np.select(
        [df["c"] > df["o"], df["c"] < df["o"]],
        [1, -1],
        default=0,
    ).astype("int8")

    df["hl_range"] = df["h"] - df["l"]
    df["body"] = (df["c"] - df["o"]).abs()
    df["upper_wick"] = df["h"] - df[["o", "c"]].max(axis=1)
    df["lower_wick"] = df[["o", "c"]].min(axis=1) - df["l"]

    df["hl_range_pct"] = (df["hl_range"] / df["o"]) * 100.0
    df["body_pct"] = (df["body"] / df["o"]) * 100.0
    df["wick_ratio"] = np.where(
        df["lower_wick"].abs() > 0,
        df["upper_wick"] / df["lower_wick"].abs(),
        0.0,
    )

    df["oc_change"] = df["c"] - df["o"]
    df["oc_pct"] = (df["oc_change"] / df["o"]) * 100.0

    df["close_vwap_diff"] = df["c"] - df["vw"]
    df["close_vwap_diff_pct"] = np.where(
        df["vw"].abs() > 0,
        (df["close_vwap_diff"] / df["vw"]) * 100.0,
        np.nan,
    )

    df["dollar_volume"] = df["c"] * df["v"]

    tr1 = df["hl_range"].to_numpy(dtype=np.float64)
    tr2 = (df["h"] - df["prev_close"]).abs().to_numpy(dtype=np.float64)
    tr3 = (df["l"] - df["prev_close"]).abs().to_numpy(dtype=np.float64)
    tr2 = np.nan_to_num(tr2, nan=-np.inf)
    tr3 = np.nan_to_num(tr3, nan=-np.inf)
    df["true_range"] = np.maximum.reduce([tr1, tr2, tr3])
    df["true_range_pct"] = (df["true_range"] / df["prev_close"]) * 100.0

    # time gaps (schema is text, but DB can cast; we keep numeric/bool here)
    df["delta_s"] = (df["ts"] - df["prev_ts"]).astype("float64")
    miss = (df["delta_s"] / float(interval_s)) - 1.0
    miss = np.where(np.isfinite(miss) & (miss > 0), miss, 0.0)
    df["missing_intervals"] = miss.round().astype("int64")
    df["is_time_gap"] = df["missing_intervals"] > 0

    # price gap vs prev close
    df["gap_size"] = df["o"] - df["prev_close"]
    df["gap_pct"] = (df["gap_size"] / df["prev_close"]) * 100.0
    df["gap_dir_code"] = np.select(
        [df["gap_size"] > 0, df["gap_size"] < 0],
        [1, -1],
        default=0,
    ).astype("int8")
    df["gap_dir"] = np.select(
        [df["gap_dir_code"] == 1, df["gap_dir_code"] == -1],
        ["up", "down"],
        default="flat",
    )
    df["is_gap"] = (
        df["prev_close"].notna()
        & (df["gap_dir_code"] != 0)
        & df["gap_pct"].notna()
        & (df["gap_pct"].abs() >= 0.0)
    )

    # placeholder (gap fill uses future candles; compute later in a nightly job if desired)
    df["gap_filled"] = False
    df["gap_unfilled"] = False
    df["gap_status"] = pd.NA

    df["is_inside_bar"] = (
        df["prev_high"].notna()
        & df["prev_low"].notna()
        & (df["h"] <= df["prev_high"])
        & (df["l"] >= df["prev_low"])
    )

    df = _add_time_columns(df)
    return df


def _ensure_ts_datetime_for_ta(df: pd.DataFrame) -> pd.DataFrame:
    """
    ta_sdk expects column 'ts' to be sortable and (for vwap reset_daily) ideally datetime w/ tz.
    We'll:
      - keep ts_epoch
      - set ts (temporarily) to UTC datetime
    """
    df = df.copy()
    df["ts_epoch"] = pd.to_numeric(df["ts"], errors="coerce").astype("int64")
    df["ts_utc"] = pd.to_datetime(df["ts_epoch"], unit="s", utc=True)
    df["ts"] = df["ts_utc"]
    return df


def _restore_ts_text(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if "ts_epoch" in df.columns:
        df["ts"] = df["ts_epoch"].astype("int64").astype(str)
    return df


def _add_macd_curvature_features(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or "macd_hist" not in df.columns:
        df["macd_curvature_code"] = 0
        df["macd_imminent_bull"] = False
        df["macd_imminent_bear"] = False
        return df

    hist = pd.to_numeric(df["macd_hist"], errors="coerce").astype(float)
    h1 = hist.shift(3)
    h2 = hist.shift(2)
    h3 = hist.shift(1)
    h4 = hist

    d1 = h2 - h1
    d2 = h3 - h2
    d3 = h4 - h3

    avg_hist_vol = (d1.abs() + d2.abs() + d3.abs()) / 3.0 + 1e-9
    strong = avg_hist_vol * 0.8
    small = avg_hist_vol * 0.2
    slope = h4 - h3

    imminent = (h4.abs() < (avg_hist_vol * 0.5)) & (slope.abs() < small)

    code = pd.Series(np.zeros(len(df), dtype=np.int16), index=df.index)
    code = code.mask(imminent & (h4 < 0), 7)
    code = code.mask(imminent & (h4 >= 0), 8)

    pos = (h4 > 0) & (~imminent)
    code = code.mask(pos & (slope > strong), 1)
    code = code.mask(pos & (slope < -strong), 3)
    code = code.mask(pos & (code == 0) & (h4 > 0), 5)

    neg = (h4 < 0) & (~imminent)
    code = code.mask(neg & (slope < -strong), 2)
    code = code.mask(neg & (slope > strong), 4)
    code = code.mask(neg & (code == 0), 6)

    df["macd_curvature_code"] = code.astype("int16")
    df["macd_imminent_bull"] = df["macd_curvature_code"] == 7
    df["macd_imminent_bear"] = df["macd_curvature_code"] == 8
    return df


def add_all_ta_indicators(df: pd.DataFrame, ta: FudstopTA) -> pd.DataFrame:
    """
    Applies (nearly) the full indicator suite from ta_sdk.
    Keep this as the single place to expand/contract indicator coverage.

    NOTE: vwap_dist_pct from ta_sdk is in fraction units (0.01 == 1%),
    unlike close_vwap_diff_pct (which we computed as percent*100). See ta_sdk implementation. fileciteturn2file0
    """
    # Many ta_sdk methods copy defensively; we also consolidate if fragmentation grows.
    df = ta.add_macd(df)
    df = _add_macd_curvature_features(df)
    df = ta.compute_wilders_rsi(df)
    df = ta.add_td9_counts(df)

    df = ta.add_ema_pack(df, periods=(9, 21, 50), slope_lookback=3)
    df = ta.add_bollinger_bands(
        df,
        window=CA_BB_WINDOW,
        num_std=CA_BB_NUM_STD,
        trend_points=CA_BB_TREND_POINTS,
    )
    df = ta.add_band_position_metrics(df)

    df = ta.add_volume_metrics(df)
    df = ta.add_obv(df)

    df = ta.add_atr(df)
    df = ta.add_cci(df)
    df = ta.add_cmo(df)
    df = ta.add_stochastic_oscillator(df)
    df = ta.add_awesome_oscillator(df)
    df = ta.add_donchian_channels(df)
    df = ta.add_aroon(df)
    df = ta.add_mfi(df)
    df = ta.add_williams_r(df)
    df = ta.add_vortex_indicator(df)
    df = ta.add_roc(df)
    df = ta.add_keltner_channels(df)
    df = ta.add_chaikin_money_flow(df)
    df = ta.add_choppiness_index(df)

    df = ta.add_vwap_features(df, reset_daily=True, tz="US/Eastern")
    df = ta.add_tsi(df)
    df = ta.add_stoch_rsi(df)
    df = ta.add_force_index(df)
    df = ta.add_relative_volume(df)
    df = ta.add_squeeze_flags(df)

    df = ta.add_candle_shape_metrics(df)
    df = ta.add_engulfing_patterns(df)

    df = ta.add_adx_clean(df)
    df = ta.add_momentum_flags(df)

    df = ta.add_ppo(df)
    df = ta.add_trix(df)
    df = ta.add_sdc_indicator(df)
    if {"sdc_upper", "sdc_lower", "c"}.issubset(df.columns):
        denom = df["c"].replace(0, np.nan)
        df["sdc_width"] = (df["sdc_upper"] - df["sdc_lower"]) / denom
    else:
        df["sdc_width"] = 0.0
    if {"keltner_upper", "keltner_lower", "c"}.issubset(df.columns):
        denom = df["c"].replace(0, np.nan)
        df["keltner_width"] = (df["keltner_upper"] - df["keltner_lower"]) / denom
    else:
        df["keltner_width"] = 0.0

    df = ta.add_parabolic_sar_signals(df)

    df = ta.add_accumulation_distribution(df)
    df = ta.add_ultimate_oscillator(df)

    # Optional: confluence score (kept neutral here; you can set bullish/bearish if you want)
    try:
        df = ta.add_confluence_score(df, macd_sentiment="neutral")
    except Exception:
        # Not critical for live ingestion.
        pass

    # Convenience derived columns commonly used in scans
    if "atr" in df.columns:
        df["atr_pct"] = df["atr"] / pd.to_numeric(df["c"], errors="coerce").replace(0, np.nan)

    return df


def _cast_text_cols(df: pd.DataFrame, cols: Iterable[str]) -> pd.DataFrame:
    df = df.copy()
    for c in cols:
        if c in df.columns:
            df[c] = df[c].where(df[c].isna(), df[c].astype(str))
    return df


async def _db_exec(db: PolygonOptions, sql: str, *params: Any) -> Any:
    """
    Your PolygonOptions wrapper differs slightly across repos. We try common methods.
    """
    for name in ("execute", "execute_new", "exec", "fetch_new", "fetch"):
        fn = getattr(db, name, None)
        if fn is None:
            continue
        try:
            return await fn(sql, *params)
        except TypeError:
            continue
    raise RuntimeError("PolygonOptions has no compatible execute method for SQL")


async def ensure_ca_live_table(db: PolygonOptions, table: str) -> None:
    """
    Create a tiny snapshot table (one row per ticker+timespan).
    Extra indicator columns get added automatically later.
    """
    sql = f"""
    CREATE TABLE IF NOT EXISTS public.{table} (
        ticker text NOT NULL,
        timespan text NOT NULL,
        ts text,
        ticker_id integer,
        insertion_timestamp timestamp without time zone,
        PRIMARY KEY (ticker, timespan)
    );
    """
    try:
        await _db_exec(db, sql)
    except Exception as e:
        print(f"[WARN] could not ensure {table} exists: {repr(e)}")


def _pg_type_for_series(s: pd.Series) -> str:
    if pd.api.types.is_bool_dtype(s):
        return "boolean"
    if pd.api.types.is_integer_dtype(s):
        return "integer"
    if pd.api.types.is_float_dtype(s):
        return "double precision"
    if pd.api.types.is_datetime64_any_dtype(s):
        return "timestamp with time zone"
    # default
    return "text"


async def ensure_table_has_columns(db: PolygonOptions, table: str, df: pd.DataFrame) -> None:
    """
    Adds missing columns to public.{table} to match df columns.
    Safe to run repeatedly.

    NOTE: For a live table this is usually fine. For huge history tables, avoid ALTERs.
    """
    try:
        existing = await db.get_table_columns(table)
    except Exception as e:
        print(f"[WARN] get_table_columns({table}) failed: {repr(e)}")
        return

    existing_set = set(existing or [])
    missing = [c for c in df.columns if c not in existing_set]

    if not missing:
        return

    for col in missing:
        # only allow safe identifiers
        if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_]*$", col):
            continue
        pg_type = _pg_type_for_series(df[col])
        sql = f'ALTER TABLE public.{table} ADD COLUMN IF NOT EXISTS "{col}" {pg_type};'
        try:
            await _db_exec(db, sql)
        except Exception as e:
            print(f"[WARN] add column {table}.{col} failed: {repr(e)}")


async def fetch_recent_candles(
    session: aiohttp.ClientSession,
    *,
    ticker: str,
    ticker_id: int,
    timespan: str,
    count: int,
    anchor_ts: int,
    access_token: str,
) -> pd.DataFrame:
    last_error: Optional[BaseException] = None
    best_df = pd.DataFrame()
    for url in _candle_endpoint_urls(
        ticker_id=ticker_id,
        timespan=timespan,
        count=count,
        anchor_ts=anchor_ts,
    ):
        for attempt in range(max(HTTP_RETRIES, 4)):
            try:
                request_headers = generate_webull_headers(access_token=access_token)
                async with session.get(url, headers=request_headers) as resp:
                    if resp.status == 429:
                        retry_after = resp.headers.get("Retry-After")
                        wait_s = float(retry_after) if retry_after else HTTP_RETRY_BACKOFF_S * (2 ** attempt)
                        await asyncio.sleep(wait_s)
                        continue
                    if resp.status in (401, 403):
                        last_error = aiohttp.ClientResponseError(
                            resp.request_info,
                            resp.history,
                            status=resp.status,
                            message=resp.reason or "Forbidden",
                            headers=resp.headers,
                        )
                        await asyncio.sleep(HTTP_RETRY_BACKOFF_S * (2 ** attempt))
                        continue
                    resp.raise_for_status()
                    payload = await resp.json(content_type=None)
            except Exception as exc:
                last_error = exc
                if attempt == max(HTTP_RETRIES, 4) - 1:
                    break
                await asyncio.sleep(HTTP_RETRY_BACKOFF_S * (2 ** attempt))
                continue

            rows = None
            if payload and isinstance(payload, list) and payload and isinstance(payload[0], dict):
                rows = payload[0].get("data")
            if rows:
                parsed = _parse_webull_rows(rows, ticker=ticker, ticker_id=ticker_id, timespan=timespan)
                if not parsed.empty and len(parsed) > len(best_df):
                    best_df = parsed
                if len(best_df) >= int(count):
                    return best_df
            break

    if not best_df.empty:
        return best_df
    if last_error is not None:
        raise last_error
    return pd.DataFrame()


@dataclass
class TickerSpanState:
    ticker: str
    ticker_id: int
    timespan: str
    interval_s: int
    poll_interval_s: int
    last_ts: int = 0           # last candle timestamp processed (epoch seconds)
    next_poll_at: float = 0.0
    buf: pd.DataFrame = field(default_factory=pd.DataFrame)


async def fetch_db_last_ts(
    db: PolygonOptions,
    *,
    table: str,
    tickers: List[str],
    timespans: List[str],
) -> Dict[Tuple[str, str], int]:
    """
    Returns {(ticker, timespan): max_ts_epoch} from the history table.
    """
    if not tickers or not timespans:
        return {}
    try:
        sql = f"""
            SELECT ticker, timespan, max(ts::bigint) AS max_ts
            FROM public.{table}
            WHERE timespan = ANY($1) AND ticker = ANY($2)
            GROUP BY ticker, timespan;
        """
        rows = await db.fetch_new(sql, timespans, tickers)  # type: ignore[attr-defined]
        out: Dict[Tuple[str, str], int] = {}
        for r in rows or []:
            key = (str(r["ticker"]), str(r["timespan"]))
            out[key] = _safe_int(r.get("max_ts"), 0)
        return out
    except Exception:
        tickers_sql = ", ".join([f"'{_sql_quote(t)}'" for t in tickers])
        timespans_sql = ", ".join([f"'{_sql_quote(t)}'" for t in timespans])
        sql = f"""
            SELECT ticker, timespan, max(ts::bigint) AS max_ts
            FROM public.{table}
            WHERE timespan IN ({timespans_sql}) AND ticker IN ({tickers_sql})
            GROUP BY ticker, timespan;
        """
        try:
            rows = await db.fetch(sql)  # type: ignore[attr-defined]
        except Exception:
            rows = await db.fetch_new(sql)
        out: Dict[Tuple[str, str], int] = {}
        for r in rows or []:
            key = (str(r["ticker"]), str(r["timespan"]))
            out[key] = _safe_int(r.get("max_ts"), 0)
        return out


def _merge_into_buffer(buf: pd.DataFrame, new_df: pd.DataFrame, *, buffer_bars: int) -> pd.DataFrame:
    if buf is None or buf.empty:
        out = new_df.copy()
    else:
        out = pd.concat([buf, new_df], ignore_index=True, copy=False)
    out = out.drop_duplicates(subset=["ts"], keep="last")
    out = out.sort_values("ts", kind="mergesort").reset_index(drop=True)
    if buffer_bars > 0 and len(out) > buffer_bars:
        out = out.iloc[-buffer_bars:].reset_index(drop=True)
    return out


def _enrich_buffer(
    buf: pd.DataFrame,
    *,
    timespan: str,
    interval_s: int,
    ta: FudstopTA,
) -> pd.DataFrame:
    """
    Full enrichment:
      - local candle metrics (prev_* etc)
      - TA indicators (full suite)
    """
    if buf.empty:
        return buf

    df = compute_local_metrics(buf, interval_s=interval_s)

    # TA step expects datetime 'ts'
    df_ta = _ensure_ts_datetime_for_ta(df)
    df_ta = add_all_ta_indicators(df_ta, ta)

    # restore ts to epoch-text for DB compatibility
    df_out = _restore_ts_text(df_ta)

    # Ensure required identity cols exist
    df_out["timespan"] = timespan
    return df_out


def _now_utc_ts() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


async def main() -> None:
    args = _parse_args()
    load_dotenv()

    access_token = os.environ.get("ACCESS_TOKEN")
    if not access_token:
        raise RuntimeError("ACCESS_TOKEN missing (set env var or .env)")

    timespans = _parse_timespans(args.timespan) if str(args.timespan or "").strip() else _parse_timespans(args.timespans)
    if not timespans:
        raise RuntimeError("No timespans selected")

    tickers = _parse_tickers(args.tickers)
    if args.use_most_active or not tickers:
        tickers = list(most_active_tight_spread_tickers)
    if args.max_tickers and args.max_tickers > 0:
        tickers = tickers[: args.max_tickers]
    if not tickers:
        raise RuntimeError("No tickers selected")

    # Resolve Webull ticker IDs
    wbt = WebullTrading()
    ticker_to_id = getattr(wbt, "ticker_to_id_map", {}) or {}
    jobs: List[TickerSpanState] = []
    for t in tickers:
        tid = ticker_to_id.get(t)
        if not tid:
            print(f"[WARN] no webull ticker_id for {t} (skipping)")
            continue
        for timespan in timespans:
            jobs.append(
                TickerSpanState(
                    ticker=t,
                    ticker_id=int(tid),
                    timespan=timespan,
                    interval_s=_timespan_to_seconds(timespan),
                    poll_interval_s=_poll_interval_for_timespan(timespan),
                )
            )

    if not jobs:
        raise RuntimeError("No ticker jobs resolved (check ticker_to_id_map)")

    # DB connect
    db = PolygonOptions()
    await db.connect()

    # Ensure ca_live exists
    if not args.no_live:
        await ensure_ca_live_table(db, args.live_table)

    # Pull base-history columns so we only write those to ca
    try:
        history_cols = await db.get_table_columns(args.history_table)
    except Exception as e:
        print(f"[WARN] get_table_columns({args.history_table}) failed, falling back to static list: {repr(e)}")
        history_cols = []

    if not history_cols:
        # Fallback: just write whatever columns exist in schema you provided; best-effort.
        history_cols = [
            "ts","o","c","h","l","vw","v","a","ticker","ticker_id","timespan",
            "prev_ts","prev_close","prev_high","prev_low","change","change_pct","log_return",
            "candle_color","candle_dir","hl_range","body","upper_wick","lower_wick",
            "hl_range_pct","body_pct","wick_ratio","oc_change","oc_pct",
            "close_vwap_diff","close_vwap_diff_pct","dollar_volume",
            "true_range","true_range_pct","delta_s","missing_intervals","is_time_gap",
            "gap_size","gap_pct","gap_dir_code","gap_dir","is_gap","gap_filled","gap_unfilled","gap_status",
            "is_inside_bar","date_et","time_et","dow_et","session","insertion_timestamp",
            "rsi","td_buy_count","td_sell_count",
            "macd_line","macd_signal","macd_hist","macd_cross_up","macd_cross_dn","macd_hist_slope","macd_hist_slope3",
        ]

    # Last seen from DB (for catchup)

    # Optional: local checkpoint (last_ts per ticker).
    # This is just a convenience for restarts; DB is still the source of truth.
    state_last: Dict[str, int] = {}
    try:
        p = Path(args.state_file)
        if p.exists():
            raw = json.loads(p.read_text() or "{}")
            if isinstance(raw, dict):
                state_last = {str(k): int(v) for k, v in raw.items() if v is not None}
            print(f"[INIT] loaded state_file={args.state_file} pairs={len(state_last)}")
    except Exception as e:
        print(f"[WARN] could not read state_file={args.state_file}: {repr(e)}")

    unique_tickers = sorted({j.ticker for j in jobs})
    db_last = await fetch_db_last_ts(
        db,
        table=args.history_table,
        tickers=unique_tickers,
        timespans=timespans,
    )
    for j in jobs:
        state_key = _state_key(j.ticker, j.timespan)
        j.last_ts = max(int(db_last.get((j.ticker, j.timespan), 0)), int(state_last.get(state_key, 0)))

    ta = FudstopTA()
    warmup_timespan = jobs[0].timespan
    warmup_interval_s = jobs[0].interval_s

    # Warm-up (helps if ta_sdk uses numba / jit in your environment)
    try:
        _ = add_all_ta_indicators(
            _ensure_ts_datetime_for_ta(
                compute_local_metrics(
                    pd.DataFrame(
                        {
                            "ts": np.arange(200, dtype=np.int64) * warmup_interval_s + int(time.time()) - 200 * warmup_interval_s,
                            "o": np.random.rand(200) + 100,
                            "h": np.random.rand(200) + 101,
                            "l": np.random.rand(200) + 99,
                            "c": np.random.rand(200) + 100,
                            "v": np.random.randint(1, 1000, 200),
                            "vw": np.random.rand(200) + 100,
                            "a": np.random.rand(200) + 100,
                            "ticker": ["WARM"] * 200,
                            "ticker_id": [0] * 200,
                            "timespan": [warmup_timespan] * 200,
                        }
                    ),
                    interval_s=warmup_interval_s,
                )
            ),
            ta,
        )
    except Exception:
        pass

    timeout = aiohttp.ClientTimeout(total=REQUEST_TIMEOUT_S)
    connector = aiohttp.TCPConnector(
        limit=max(50, args.concurrency * 4),
        limit_per_host=max(20, args.concurrency * 2),
        ttl_dns_cache=300,
        enable_cleanup_closed=True,
    )

    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        sem = asyncio.Semaphore(args.concurrency)

        async def seed_one(state: TickerSpanState) -> None:
            async with sem:
                try:
                    anchor = int(time.time())
                    df_seed = await fetch_recent_candles(
                        session,
                        ticker=state.ticker,
                        ticker_id=state.ticker_id,
                        timespan=state.timespan,
                        count=_seed_count_for_timespan(state.timespan, int(args.seed_count)),
                        anchor_ts=anchor,
                        access_token=access_token,
                    )
                    if df_seed.empty:
                        state.next_poll_at = time.monotonic() + max(10.0, float(state.poll_interval_s))
                        return
                    df_seed = df_seed.drop_duplicates(subset=["ts"], keep="last")
                    df_seed = df_seed.sort_values("ts", kind="mergesort").reset_index(drop=True)

                    # buffer is the rolling seed window
                    state.buf = _merge_into_buffer(pd.DataFrame(), df_seed, buffer_bars=int(args.buffer_bars))

                    # catch up history with any bars newer than DB max
                    if not args.no_history:
                        max_db_ts = int(state.last_ts or 0)
                        newer = df_seed[pd.to_numeric(df_seed["ts"], errors="coerce") > max_db_ts]
                        if not newer.empty:
                            enriched = _enrich_buffer(state.buf, timespan=state.timespan, interval_s=state.interval_s, ta=ta)
                            # only write the newer rows
                            newer_ts = set(pd.to_numeric(newer["ts"], errors="coerce").astype("int64").tolist())
                            hist_rows = enriched[pd.to_numeric(enriched["ts"], errors="coerce").astype("int64").isin(newer_ts)]
                            if not hist_rows.empty:
                                hist_rows = hist_rows.copy()
                                hist_rows["insertion_timestamp"] = _now_utc_ts()
                                hist_rows = _cast_text_cols(
                                    hist_rows,
                                    cols=["ts", "prev_ts", "ticker", "timespan", "candle_color", "gap_dir", "gap_status", "date_et", "time_et", "session"],
                                )
                                hist_rows = hist_rows[[c for c in history_cols if c in hist_rows.columns]]
                                await db.batch_upsert_dataframe(
                                    hist_rows,
                                    table_name=args.history_table,
                                    unique_columns=["ticker", "timespan", "ts"],
                                    batch_size=DB_BATCH_SIZE,
                                    on_conflict_update=True,
                                )
                                state.last_ts = int(pd.to_numeric(enriched["ts"], errors="coerce").max())

                    # write live snapshot (latest candle)
                    if not args.no_live and not state.buf.empty:
                        enriched = _enrich_buffer(state.buf, timespan=state.timespan, interval_s=state.interval_s, ta=ta)
                        if not enriched.empty:
                            live_row = enriched.tail(1).copy()
                            live_row["insertion_timestamp"] = _now_utc_ts()
                            live_row = _cast_text_cols(live_row, cols=["ts", "prev_ts", "ticker", "timespan", "candle_color", "gap_dir", "gap_status", "date_et", "time_et", "session"])

                            await ensure_table_has_columns(db, args.live_table, live_row)
                            await db.batch_upsert_dataframe(
                                live_row,
                                table_name=args.live_table,
                                unique_columns=["ticker", "timespan"],
                                batch_size=1,
                                on_conflict_update=True,
                            )
                    state.next_poll_at = time.monotonic() + max(10.0, float(state.poll_interval_s))
                except Exception as e:
                    state.next_poll_at = time.monotonic() + min(90.0, max(15.0, float(state.poll_interval_s) / 3.0))
                    print(f"[SEED-ERR] {state.ticker} [{state.timespan}] -> {repr(e)}")

        # ---- Initial seed (concurrent) ----
        print(
            f"[INIT] seeding pairs={len(jobs)} tickers={len(unique_tickers)} "
            f"timespans={','.join(timespans)} count={args.seed_count} ..."
        )
        await asyncio.gather(*[seed_one(j) for j in jobs])
        print("[INIT] seed done")

        # ---- Live loop ----
        pass_i = 0
        while True:
            due_now = time.monotonic()
            due_jobs = [job for job in jobs if due_now >= float(job.next_poll_at or 0.0)]
            if not due_jobs:
                next_due = min((float(job.next_poll_at or 0.0) for job in jobs), default=due_now + float(args.sleep))
                wait_s = max(1.0, min(float(args.sleep), next_due - due_now))
                await asyncio.sleep(wait_s)
                continue

            t0 = time.monotonic()
            pass_i += 1
            anchor = int(time.time())

            # Fetch only pairs that are due for this cycle.
            async def fetch_one(state: TickerSpanState) -> Tuple[TickerSpanState, pd.DataFrame]:
                async with sem:
                    try:
                        fetch_count = (
                            _seed_count_for_timespan(state.timespan, int(args.seed_count))
                            if state.buf is None or len(state.buf) < MIN_TA_WARMUP_BARS
                            else _live_count_for_timespan(state.timespan, int(args.live_count))
                        )
                        df = await fetch_recent_candles(
                            session,
                            ticker=state.ticker,
                            ticker_id=state.ticker_id,
                            timespan=state.timespan,
                            count=fetch_count,
                            anchor_ts=anchor,
                            access_token=access_token,
                        )
                        state.next_poll_at = time.monotonic() + max(10.0, float(state.poll_interval_s))
                        return state, df
                    except Exception as e:
                        state.next_poll_at = time.monotonic() + min(90.0, max(15.0, float(state.poll_interval_s) / 3.0))
                        print(f"[FETCH-ERR] {state.ticker} [{state.timespan}] -> {repr(e)}")
                        return state, pd.DataFrame()

            fetch_results = await asyncio.gather(*[fetch_one(j) for j in due_jobs])

            history_out_rows: List[pd.DataFrame] = []
            live_out_rows: List[pd.DataFrame] = []

            pairs_updated = 0
            bars_ingested = 0

            for idx, (state, df_recent) in enumerate(fetch_results, 1):
                if df_recent is None or df_recent.empty:
                    continue

                # keep only candles newer than our last_ts
                df_recent = df_recent.drop_duplicates(subset=["ts"], keep="last")
                df_recent = df_recent.sort_values("ts", kind="mergesort").reset_index(drop=True)

                ts_num = pd.to_numeric(df_recent["ts"], errors="coerce").astype("int64")
                new_mask = ts_num > int(state.last_ts or 0)
                df_new = df_recent[new_mask]
                if df_new.empty:
                    continue

                pairs_updated += 1
                bars_ingested += int(len(df_new))

                # update rolling buffer with the new bars
                state.buf = _merge_into_buffer(state.buf, df_new, buffer_bars=int(args.buffer_bars))

                # enrich (metrics + TA)
                enriched = _enrich_buffer(state.buf, timespan=state.timespan, interval_s=state.interval_s, ta=ta)
                if enriched.empty:
                    continue

                # history: only the new bars, and only base CA columns
                if not args.no_history:
                    new_ts_set = set(pd.to_numeric(df_new["ts"], errors="coerce").astype("int64").tolist())
                    hist_rows = enriched[pd.to_numeric(enriched["ts"], errors="coerce").astype("int64").isin(new_ts_set)]
                    if not hist_rows.empty:
                        hist_rows = hist_rows.copy()
                        hist_rows["insertion_timestamp"] = _now_utc_ts()
                        hist_rows = _cast_text_cols(
                            hist_rows,
                            cols=["ts", "prev_ts", "ticker", "timespan", "candle_color", "gap_dir", "gap_status", "date_et", "time_et", "session"],
                        )
                        hist_rows = hist_rows[[c for c in history_cols if c in hist_rows.columns]]
                        history_out_rows.append(hist_rows)

                # live: last candle only (full indicator set)
                if not args.no_live:
                    live_row = enriched.tail(1).copy()
                    live_row["insertion_timestamp"] = _now_utc_ts()
                    live_row = _cast_text_cols(
                        live_row,
                        cols=["ts", "prev_ts", "ticker", "timespan", "candle_color", "gap_dir", "gap_status", "date_et", "time_et", "session"],
                    )
                    live_out_rows.append(live_row)

                # update last_ts
                state.last_ts = int(pd.to_numeric(enriched["ts"], errors="coerce").astype("int64").max())

                if args.progress_every and idx % args.progress_every == 0:
                    print(f"[PASS {pass_i}] progress {idx}/{len(due_jobs)} updated_pairs={pairs_updated} new_bars={bars_ingested}")

            # DB flush (small batches)
            if history_out_rows and not args.no_history:
                hist_all = pd.concat(history_out_rows, ignore_index=True, copy=False)
                if not hist_all.empty:
                    await db.batch_upsert_dataframe(
                        hist_all,
                        table_name=args.history_table,
                        unique_columns=["ticker", "timespan", "ts"],
                        batch_size=DB_BATCH_SIZE,
                        on_conflict_update=True,
                    )

            if live_out_rows and not args.no_live:
                live_all = pd.concat(live_out_rows, ignore_index=True, copy=False)
                if not live_all.empty:
                    # Ensure live table schema has the columns we are about to write
                    await ensure_table_has_columns(db, args.live_table, live_all)
                    await db.batch_upsert_dataframe(
                        live_all,
                        table_name=args.live_table,
                        unique_columns=["ticker", "timespan"],
                        batch_size=DB_BATCH_SIZE,
                        on_conflict_update=True,
                    )

            dt = time.monotonic() - t0
            if dt > float(args.pass_budget):
                print(f"[WARN] pass {pass_i} took {dt:.2f}s (budget {args.pass_budget}s)")
            else:
                print(f"[PASS {pass_i}] ok {dt:.2f}s | updated_pairs={pairs_updated} new_bars={bars_ingested}")


            # checkpoint state (only when we actually ingested new bars)
            if pairs_updated > 0:
                try:
                    payload = {_state_key(s.ticker, s.timespan): int(s.last_ts or 0) for s in jobs}
                    tmp_path = Path(str(args.state_file) + ".tmp")
                    tmp_path.write_text(json.dumps(payload))
                    os.replace(str(tmp_path), str(args.state_file))
                except Exception as e:
                    print(f"[WARN] state_file write failed: {repr(e)}")

            # sleep
            await asyncio.sleep(max(1.0, min(float(args.sleep), 5.0)))

    # best-effort close
    try:
        await db.disconnect()
    except Exception:
        try:
            await db.close()
        except Exception:
            pass


if __name__ == "__main__":
    asyncio.run(main())
