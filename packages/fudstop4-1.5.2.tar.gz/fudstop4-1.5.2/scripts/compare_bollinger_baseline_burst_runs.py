#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
from dataclasses import asdict, dataclass
from datetime import datetime, time, timedelta
from pathlib import Path
from typing import Dict, Iterable, List, Sequence

import numpy as np
import pandas as pd

from fudstop4._markets.list_sets.ticker_lists import most_active_tickers
from fudstop4.apis._ta.ta_sdk import FudstopTA
from scripts.ca_bollinger_config import CA_BB_NUM_STD, CA_BB_TREND_POINTS, CA_BB_WINDOW
from scripts.ca_momentum_run_combo_scan import (
    DEFAULT_PSQL_PATH,
    MARKET_TZ,
    _run_copy_query,
)


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_ROOT = ROOT / "runs" / "ca_historical_reversal_research"
DEFAULT_START_DATE = "2026-01-02"
DEFAULT_END_DATE = "2026-04-10"
DEFAULT_TIMESPANS = ("m1", "m60", "d1")
LEGACY_BB_WINDOW = 20
LEGACY_BB_NUM_STD = 2.0
LEGACY_BB_TREND_POINTS = 13


@dataclass(frozen=True)
class ComparisonRow:
    version: str
    tone: str
    timespan: str
    signal_count: int
    hits: int
    hit_rate: float | None
    hit_50bp: float | None
    hit_100bp: float | None
    hit_150bp: float | None
    avg_best_ret: float | None
    median_best_ret: float | None
    avg_run_len: float | None
    median_run_len: float | None
    shared_with_other: int
    version_only: int
    definition: str


def _load_env_defaults() -> Dict[str, str]:
    env_path = ROOT / "stock_market_site" / "app" / ".env"
    values: Dict[str, str] = {}
    if not env_path.exists():
        return values
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


ENV_DEFAULTS = _load_env_defaults()


def _env_default(key: str, fallback: str) -> str:
    repo_value = str(ENV_DEFAULTS.get(key) or "").strip()
    if repo_value:
        return repo_value
    env_value = str(os.environ.get(key) or "").strip()
    if key == "DB_NAME" and env_value.lower() == "database":
        return fallback
    return env_value or fallback


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Compare legacy vs current Bollinger full-band + RSI baseline signals "
            "for 7+ consecutive same-color bursts."
        )
    )
    parser.add_argument("--host", default=_env_default("DB_HOST", "localhost"))
    parser.add_argument("--port", type=int, default=int(_env_default("DB_PORT", "5432")))
    parser.add_argument("--user", default=_env_default("DB_USER", "chuck"))
    parser.add_argument("--password", default=_env_default("DB_PASSWORD", "fud"))
    parser.add_argument("--database", default=_env_default("DB_NAME", "fudstop3"))
    parser.add_argument("--psql-path", default=_env_default("PSQL_PATH", DEFAULT_PSQL_PATH))
    parser.add_argument("--start-date", default=DEFAULT_START_DATE)
    parser.add_argument("--end-date", default=DEFAULT_END_DATE)
    parser.add_argument("--timespans", default=",".join(DEFAULT_TIMESPANS))
    parser.add_argument("--tickers", default="")
    parser.add_argument("--universe", choices=("all", "most_active"), default="most_active")
    parser.add_argument("--min-run-length", type=int, default=7)
    parser.add_argument("--signal-mode", choices=("pre_run", "run_start", "in_burst"), default="pre_run")
    parser.add_argument("--bull-rsi-threshold", type=float, default=30.0)
    parser.add_argument("--bear-rsi-threshold", type=float, default=70.0)
    parser.add_argument("--output-dir", default="")
    return parser.parse_args()


def _parse_csv(raw: str) -> List[str]:
    return [value.strip().lower() for value in str(raw or "").split(",") if value.strip()]


def _parse_tickers(raw: str) -> List[str]:
    return sorted({str(value or "").strip().upper() for value in str(raw or "").split(",") if str(value or "").strip()})


def _resolve_tickers(raw: str, universe: str) -> List[str]:
    explicit = _parse_tickers(raw)
    if explicit:
        return explicit
    if str(universe or "").strip().lower() == "most_active":
        return sorted({str(value or "").strip().upper() for value in most_active_tickers if str(value or "").strip()})
    return []


def _date_to_epoch_bounds(start_date: str, end_date: str) -> tuple[int, int]:
    start_day = datetime.strptime(start_date, "%Y-%m-%d").date()
    end_day = datetime.strptime(end_date, "%Y-%m-%d").date() + timedelta(days=1)
    start_dt = datetime.combine(start_day, time.min, tzinfo=MARKET_TZ)
    end_dt = datetime.combine(end_day, time.min, tzinfo=MARKET_TZ)
    return int(start_dt.timestamp()), int(end_dt.timestamp())


def _sql_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _build_query(
    *,
    start_epoch: int,
    end_epoch: int,
    timespans: Sequence[str],
    tickers: Sequence[str],
) -> str:
    quoted_timespans = ", ".join(_sql_quote(value) for value in timespans)
    ticker_sql = ""
    if tickers:
        ticker_sql = f"\n  AND UPPER(BTRIM(ticker)) IN ({', '.join(_sql_quote(value) for value in tickers)})"
    return f"""
SELECT
    UPPER(BTRIM(ticker)) AS ticker,
    LOWER(COALESCE(timespan, '')) AS timespan,
    ts::bigint AS ts_epoch,
    ts::bigint AS ts,
    to_timestamp(ts::bigint) AT TIME ZONE 'America/New_York' AS ts_et,
    session,
    o,
    c,
    h,
    l,
    v,
    rsi,
    candle_green,
    candle_red
FROM ca
WHERE LOWER(COALESCE(timespan, '')) IN ({quoted_timespans})
  AND ts::bigint >= {int(start_epoch)}
  AND ts::bigint < {int(end_epoch)}
  AND o IS NOT NULL
  AND h IS NOT NULL
  AND l IS NOT NULL
  AND c IS NOT NULL
  AND rsi IS NOT NULL
  AND (
        LOWER(COALESCE(timespan, '')) IN ('d1', 'w1', 'mth1')
        OR session = 'regular'
      )
  {ticker_sql}
ORDER BY LOWER(COALESCE(timespan, '')), UPPER(BTRIM(ticker)), ts::bigint
""".strip()


def _coerce_frame(df: pd.DataFrame) -> pd.DataFrame:
    bool_cols = ["candle_green", "candle_red"]
    num_cols = ["ts_epoch", "ts", "o", "c", "h", "l", "v", "rsi"]
    for col in num_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    for col in bool_cols:
        df[col] = (
            df[col]
            .astype(str)
            .str.strip()
            .str.lower()
            .isin({"t", "true", "1", "y", "yes"})
        )
    df["ticker"] = df["ticker"].astype(str).str.upper().str.strip()
    df["timespan"] = df["timespan"].astype(str).str.lower().str.strip()
    df["session"] = df["session"].astype(str).str.lower().str.strip()
    return df.sort_values(["timespan", "ticker", "ts_epoch"]).reset_index(drop=True)


def _recompute_band_flags(
    df: pd.DataFrame,
    *,
    prefix: str,
    window: int,
    num_std: float,
    trend_points: int,
) -> pd.DataFrame:
    ta = FudstopTA()
    parts: List[pd.DataFrame] = []
    for (_, _), group in df.groupby(["timespan", "ticker"], sort=False):
        local = group[["ticker", "timespan", "ts", "o", "h", "l", "c"]].copy()
        local = local.sort_values("ts", kind="mergesort").reset_index(drop=True)
        local = ta.add_bollinger_bands(
            local,
            window=int(window),
            num_std=float(num_std),
            trend_points=int(trend_points),
        )
        parts.append(
            pd.DataFrame(
                {
                    "timespan": group["timespan"].to_numpy(),
                    "ticker": group["ticker"].to_numpy(),
                    "ts_epoch": group["ts_epoch"].to_numpy(dtype=np.int64),
                    f"{prefix}_candle_completely_below_lower": local["candle_completely_below_lower"].fillna(False).astype(bool).to_numpy(),
                    f"{prefix}_candle_completely_above_upper": local["candle_completely_above_upper"].fillna(False).astype(bool).to_numpy(),
                }
            )
        )
    if not parts:
        return df
    flags = pd.concat(parts, ignore_index=True)
    return df.merge(flags, on=["timespan", "ticker", "ts_epoch"], how="left")


def _compute_signal_frame(df: pd.DataFrame, min_run_length: int, signal_mode: str) -> pd.DataFrame:
    signal_rows: List[pd.DataFrame] = []
    for (_, _), group in df.groupby(["timespan", "ticker"], sort=False):
        if len(group) <= min_run_length:
            continue
        local = group.copy()
        colors = np.zeros(len(local), dtype=np.int8)
        colors[local["candle_green"].to_numpy(dtype=bool)] = 1
        colors[local["candle_red"].to_numpy(dtype=bool)] = -1

        run_len = np.zeros(len(local), dtype=np.int16)
        if colors[-1] != 0:
            run_len[-1] = 1
        for idx in range(len(local) - 2, -1, -1):
            if colors[idx] != 0 and colors[idx] == colors[idx + 1]:
                run_len[idx] = np.int16(run_len[idx + 1] + 1)
            elif colors[idx] != 0:
                run_len[idx] = 1

        close_vals = local["c"].to_numpy(dtype=float)
        high_vals = local["h"].to_numpy(dtype=float)
        low_vals = local["l"].to_numpy(dtype=float)
        valid_mask = np.zeros(len(local), dtype=bool)
        bull_success = np.zeros(len(local), dtype=bool)
        bear_success = np.zeros(len(local), dtype=bool)
        bull_best_ret = np.full(len(local), np.nan, dtype=float)
        bear_best_ret = np.full(len(local), np.nan, dtype=float)
        bull_run_len = np.zeros(len(local), dtype=np.int16)
        bear_run_len = np.zeros(len(local), dtype=np.int16)

        for idx in range(len(local)):
            if signal_mode == "pre_run":
                start_idx = idx + 1
                end_idx = start_idx + min_run_length
            elif signal_mode == "run_start":
                start_idx = idx + 1
                end_idx = idx + min_run_length
            else:
                continue
            if end_idx > len(local):
                continue
            if not np.isfinite(close_vals[idx]) or close_vals[idx] == 0:
                continue
            valid_mask[idx] = True
            future_high = np.nanmax(high_vals[start_idx:end_idx])
            future_low = np.nanmin(low_vals[start_idx:end_idx])
            if np.isfinite(future_high):
                bull_best_ret[idx] = (future_high / close_vals[idx]) - 1.0
            if np.isfinite(future_low) and future_low != 0:
                bear_best_ret[idx] = (close_vals[idx] / future_low) - 1.0
            if signal_mode == "pre_run":
                next_idx = idx + 1
                if colors[next_idx] == 1 and run_len[next_idx] >= min_run_length:
                    bull_success[idx] = True
                    bull_run_len[idx] = run_len[next_idx]
                if colors[next_idx] == -1 and run_len[next_idx] >= min_run_length:
                    bear_success[idx] = True
                    bear_run_len[idx] = run_len[next_idx]
            elif signal_mode == "run_start":
                if colors[idx] == 1 and run_len[idx] >= min_run_length:
                    bull_success[idx] = True
                    bull_run_len[idx] = run_len[idx]
                if colors[idx] == -1 and run_len[idx] >= min_run_length:
                    bear_success[idx] = True
                    bear_run_len[idx] = run_len[idx]

        local["valid_signal_row"] = valid_mask
        local["bull_success"] = bull_success
        local["bear_success"] = bear_success
        local["bull_best_ret"] = bull_best_ret
        local["bear_best_ret"] = bear_best_ret
        local["bull_run_len"] = bull_run_len
        local["bear_run_len"] = bear_run_len
        signal_rows.append(local.loc[local["valid_signal_row"]].copy())

    if not signal_rows:
        return df.iloc[0:0].copy()
    return pd.concat(signal_rows, ignore_index=True)


def _signal_mask(df: pd.DataFrame, *, version: str, tone: str, bull_rsi: float, bear_rsi: float) -> pd.Series:
    if tone == "bull":
        return (
            df[f"{version}_candle_completely_below_lower"].fillna(False).astype(bool)
            & (pd.to_numeric(df["rsi"], errors="coerce") <= float(bull_rsi))
        )
    return (
        df[f"{version}_candle_completely_above_upper"].fillna(False).astype(bool)
        & (pd.to_numeric(df["rsi"], errors="coerce") >= float(bear_rsi))
    )


def _signal_index_set(df: pd.DataFrame, mask: pd.Series) -> set[tuple[str, str, int]]:
    if mask.empty:
        return set()
    rows = df.loc[mask, ["ticker", "timespan", "ts_epoch"]].copy()
    return {
        (str(row["ticker"]), str(row["timespan"]), int(row["ts_epoch"]))
        for _, row in rows.iterrows()
    }


def _build_row(
    *,
    df: pd.DataFrame,
    mask: pd.Series,
    version: str,
    tone: str,
    timespan: str,
    shared_count: int,
    version_only_count: int,
    definition: str,
) -> ComparisonRow:
    success_col = "bull_success" if tone == "bull" else "bear_success"
    best_ret_col = "bull_best_ret" if tone == "bull" else "bear_best_ret"
    run_len_col = "bull_run_len" if tone == "bull" else "bear_run_len"
    matched = df.loc[mask].copy()
    signal_count = int(len(matched))
    hits = int(matched[success_col].fillna(False).astype(bool).sum())
    best = pd.to_numeric(matched[best_ret_col], errors="coerce").dropna()
    run_len = pd.to_numeric(matched[run_len_col], errors="coerce")
    run_len = run_len[np.isfinite(run_len) & (run_len > 0)]
    hit_rate = (hits / signal_count) if signal_count else None
    return ComparisonRow(
        version=version,
        tone=tone,
        timespan=timespan,
        signal_count=signal_count,
        hits=hits,
        hit_rate=round(hit_rate, 4) if hit_rate is not None else None,
        hit_50bp=round(float((best >= 0.005).mean()), 4) if len(best) else None,
        hit_100bp=round(float((best >= 0.01).mean()), 4) if len(best) else None,
        hit_150bp=round(float((best >= 0.015).mean()), 4) if len(best) else None,
        avg_best_ret=round(float(best.mean()), 4) if len(best) else None,
        median_best_ret=round(float(best.median()), 4) if len(best) else None,
        avg_run_len=round(float(run_len.mean()), 2) if len(run_len) else None,
        median_run_len=round(float(np.median(run_len)), 2) if len(run_len) else None,
        shared_with_other=int(shared_count),
        version_only=int(version_only_count),
        definition=definition,
    )


def _write_summary(
    out_dir: Path,
    *,
    metadata: Dict[str, object],
    comparison_rows: List[ComparisonRow],
    delta_rows: List[Dict[str, object]],
) -> None:
    compare_df = pd.DataFrame([asdict(row) for row in comparison_rows])
    delta_df = pd.DataFrame(delta_rows)
    lines: List[str] = [
        "# Bollinger Baseline 7+ Burst Comparison",
        "",
        f"- Start date: `{metadata['start_date']}`",
        f"- End date: `{metadata['end_date']}`",
        f"- Timespans: `{', '.join(metadata['timespans'])}`",
        f"- Universe: `{metadata['universe']}`",
        f"- Ticker count: `{metadata['ticker_count']}`",
        f"- Signal mode: `{metadata['signal_mode']}`",
        f"- Minimum run length: `{metadata['min_run_length']}`",
        f"- Legacy BB: `window={metadata['legacy_bb_window']}`, `std={metadata['legacy_bb_num_std']}`",
        f"- Current BB: `window={metadata['current_bb_window']}`, `std={metadata['current_bb_num_std']}`",
        "",
    ]
    for tone in ("bull", "bear"):
        tone_df = compare_df[compare_df["tone"] == tone].copy()
        if tone_df.empty:
            continue
        lines.append(f"## {tone}")
        lines.append("")
        for timespan in metadata["timespans"]:
            bucket = tone_df[tone_df["timespan"] == timespan].copy()
            if bucket.empty:
                continue
            lines.append(f"### {timespan}")
            lines.append("")
            for _, row in bucket.sort_values(["version"]).iterrows():
                lines.append(
                    "- "
                    f"`{row['version']}`: "
                    f"`n={row['signal_count']}` `hits={row['hits']}` `hit={row['hit_rate']}` "
                    f"`hit100={row['hit_100bp']}` `avg={row['avg_best_ret']}` `avg_run={row['avg_run_len']}` "
                    f"`shared={row['shared_with_other']}` `version_only={row['version_only']}`"
                )
            delta = delta_df[(delta_df["tone"] == tone) & (delta_df["timespan"] == timespan)]
            if not delta.empty:
                drow = delta.iloc[0]
                lines.append(
                    "- "
                    f"`delta current-legacy`: "
                    f"`signal_count={drow['delta_signal_count']}` `hits={drow['delta_hits']}` "
                    f"`hit_rate={drow['delta_hit_rate']}` `hit100={drow['delta_hit_100bp']}` "
                    f"`avg_best_ret={drow['delta_avg_best_ret']}` `avg_run_len={drow['delta_avg_run_len']}`"
                )
            lines.append("")
    (out_dir / "summary.md").write_text("\n".join(lines).strip() + "\n", encoding="utf-8")


def main() -> None:
    args = _parse_args()
    timespans = _parse_csv(args.timespans) or list(DEFAULT_TIMESPANS)
    tickers = _resolve_tickers(args.tickers, args.universe)
    start_epoch, end_epoch = _date_to_epoch_bounds(args.start_date, args.end_date)
    query = _build_query(
        start_epoch=start_epoch,
        end_epoch=end_epoch,
        timespans=timespans,
        tickers=tickers,
    )

    stamp = datetime.now(MARKET_TZ).strftime("%Y-%m-%d")
    run_name = (
        f"bollinger_baseline_burst_compare_{'_'.join(timespans)}_"
        f"streak{int(args.min_run_length)}_{args.signal_mode}_{stamp}"
    )
    out_dir = Path(args.output_dir).expanduser().resolve() if str(args.output_dir or "").strip() else (OUTPUT_ROOT / run_name)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "event_universe.sql").write_text(query + "\n", encoding="utf-8")

    raw_df = _run_copy_query(
        psql_path=args.psql_path,
        host=args.host,
        port=args.port,
        user=args.user,
        password=args.password,
        database=args.database,
        query=query,
    )
    raw_df = _coerce_frame(raw_df)
    raw_df = _recompute_band_flags(
        raw_df,
        prefix="legacy",
        window=LEGACY_BB_WINDOW,
        num_std=LEGACY_BB_NUM_STD,
        trend_points=LEGACY_BB_TREND_POINTS,
    )
    raw_df = _recompute_band_flags(
        raw_df,
        prefix="current",
        window=CA_BB_WINDOW,
        num_std=CA_BB_NUM_STD,
        trend_points=CA_BB_TREND_POINTS,
    )
    raw_df.to_csv(out_dir / "raw_signal_universe_with_bbands.csv", index=False)

    signal_frame = _compute_signal_frame(raw_df, int(args.min_run_length), str(args.signal_mode))
    signal_frame.to_csv(out_dir / "signal_rows.csv", index=False)

    comparison_rows: List[ComparisonRow] = []
    delta_rows: List[Dict[str, object]] = []
    compare_records: Dict[tuple[str, str, str], ComparisonRow] = {}
    for tone in ("bull", "bear"):
        for timespan in timespans:
            bucket = signal_frame.loc[signal_frame["timespan"] == timespan].copy()
            if bucket.empty:
                continue
            legacy_mask = _signal_mask(
                bucket,
                version="legacy",
                tone=tone,
                bull_rsi=float(args.bull_rsi_threshold),
                bear_rsi=float(args.bear_rsi_threshold),
            )
            current_mask = _signal_mask(
                bucket,
                version="current",
                tone=tone,
                bull_rsi=float(args.bull_rsi_threshold),
                bear_rsi=float(args.bear_rsi_threshold),
            )
            legacy_set = _signal_index_set(bucket, legacy_mask)
            current_set = _signal_index_set(bucket, current_mask)
            shared_count = len(legacy_set & current_set)
            legacy_only = len(legacy_set - current_set)
            current_only = len(current_set - legacy_set)

            legacy_row = _build_row(
                df=bucket,
                mask=legacy_mask,
                version="legacy_20_2.0",
                tone=tone,
                timespan=timespan,
                shared_count=shared_count,
                version_only_count=legacy_only,
                definition=f"candle_completely + RSI ({'<= ' + str(args.bull_rsi_threshold) if tone == 'bull' else '>= ' + str(args.bear_rsi_threshold)}), BB {LEGACY_BB_WINDOW}/{LEGACY_BB_NUM_STD}",
            )
            current_row = _build_row(
                df=bucket,
                mask=current_mask,
                version="current_30_1.5",
                tone=tone,
                timespan=timespan,
                shared_count=shared_count,
                version_only_count=current_only,
                definition=f"candle_completely + RSI ({'<= ' + str(args.bull_rsi_threshold) if tone == 'bull' else '>= ' + str(args.bear_rsi_threshold)}), BB {CA_BB_WINDOW}/{CA_BB_NUM_STD}",
            )
            comparison_rows.extend([legacy_row, current_row])
            compare_records[(timespan, tone, legacy_row.version)] = legacy_row
            compare_records[(timespan, tone, current_row.version)] = current_row
            delta_rows.append(
                {
                    "timespan": timespan,
                    "tone": tone,
                    "delta_signal_count": current_row.signal_count - legacy_row.signal_count,
                    "delta_hits": current_row.hits - legacy_row.hits,
                    "delta_hit_rate": round((current_row.hit_rate or 0.0) - (legacy_row.hit_rate or 0.0), 4),
                    "delta_hit_100bp": round((current_row.hit_100bp or 0.0) - (legacy_row.hit_100bp or 0.0), 4),
                    "delta_avg_best_ret": round((current_row.avg_best_ret or 0.0) - (legacy_row.avg_best_ret or 0.0), 4),
                    "delta_avg_run_len": round((current_row.avg_run_len or 0.0) - (legacy_row.avg_run_len or 0.0), 2),
                    "shared_signals": shared_count,
                    "legacy_only_signals": legacy_only,
                    "current_only_signals": current_only,
                }
            )

    comparison_df = pd.DataFrame([asdict(row) for row in comparison_rows])
    comparison_df.to_csv(out_dir / "baseline_comparison.csv", index=False)
    (out_dir / "baseline_comparison.json").write_text(
        json.dumps([asdict(row) for row in comparison_rows], indent=2),
        encoding="utf-8",
    )
    pd.DataFrame(delta_rows).to_csv(out_dir / "baseline_deltas.csv", index=False)
    (out_dir / "baseline_deltas.json").write_text(
        json.dumps(delta_rows, indent=2),
        encoding="utf-8",
    )

    metadata = {
        "generated_at_et": datetime.now(MARKET_TZ).isoformat(),
        "start_date": args.start_date,
        "end_date": args.end_date,
        "timespans": timespans,
        "signal_mode": args.signal_mode,
        "min_run_length": int(args.min_run_length),
        "bull_rsi_threshold": float(args.bull_rsi_threshold),
        "bear_rsi_threshold": float(args.bear_rsi_threshold),
        "universe": str(args.universe),
        "ticker_count": int(len(tickers)),
        "tickers": tickers,
        "legacy_bb_window": LEGACY_BB_WINDOW,
        "legacy_bb_num_std": LEGACY_BB_NUM_STD,
        "legacy_bb_trend_points": LEGACY_BB_TREND_POINTS,
        "current_bb_window": CA_BB_WINDOW,
        "current_bb_num_std": CA_BB_NUM_STD,
        "current_bb_trend_points": CA_BB_TREND_POINTS,
        "raw_rows": int(len(raw_df)),
        "signal_rows": int(len(signal_frame)),
        "output_dir": str(out_dir),
    }
    (out_dir / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    _write_summary(out_dir, metadata=metadata, comparison_rows=comparison_rows, delta_rows=delta_rows)
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
