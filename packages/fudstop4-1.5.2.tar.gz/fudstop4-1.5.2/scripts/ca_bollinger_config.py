from __future__ import annotations


CA_BB_WINDOW = 30
CA_BB_NUM_STD = 1.5
CA_BB_TREND_POINTS = 13
