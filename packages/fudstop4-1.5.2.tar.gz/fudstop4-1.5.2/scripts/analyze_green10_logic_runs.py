from __future__ import annotations

import argparse
import json
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_WORKBOOK = REPO_ROOT / "LOGIC_RUNS" / "RESULTS_10_CANDLES_IN_A_ROW.xlsx"
DEFAULT_STUDY_SUMMARY = (
    REPO_ROOT
    / "runs"
    / "ca_historical_research"
    / "today_m1_15bar_upside_green10_prerun_study_2026-04-13"
    / "summary.json"
)
DEFAULT_COMBO_RATES = (
    REPO_ROOT
    / "runs"
    / "ca_historical_research"
    / "today_m1_15bar_upside_green10_prerun_study_2026-04-13"
    / "combo_rates.json"
)
DEFAULT_SIGNAL_SLATE = (
    REPO_ROOT
    / "runs"
    / "ca_historical_research"
    / "m1_majority_green_prerun_2026-04-14_signal_slate"
    / "signal_slate.json"
)
DEFAULT_REPORT = REPO_ROOT / "LOGIC_RUNS" / "GREEN10_PRERUN_FEED_ANALYSIS_20260414.md"
DEFAULT_JSON = REPO_ROOT / "LOGIC_RUNS" / "GREEN10_PRERUN_FEED_ANALYSIS_20260414.json"


@dataclass
class FeedCandidate:
    name: str
    conditions: str
    hit_rate: float
    val_hit_rate: float
    n: int
    val_n: int
    ticker_count: int
    val_ticker_count: int
    avg_future_move_15: float | None
    rationale: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "conditions": self.conditions,
            "hit_rate": self.hit_rate,
            "val_hit_rate": self.val_hit_rate,
            "n": self.n,
            "val_n": self.val_n,
            "ticker_count": self.ticker_count,
            "val_ticker_count": self.val_ticker_count,
            "avg_future_move_15": self.avg_future_move_15,
            "rationale": self.rationale,
        }


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _parse_workbook(path: Path) -> pd.DataFrame:
    df = pd.read_excel(path)
    df["ticker"] = (
        df["ticker"]
        .astype(str)
        .str.replace(r"\s+", "", regex=True)
        .str.upper()
    )
    df["run_start_et"] = pd.to_datetime(df["run_start_et"])
    df["run_end_et"] = pd.to_datetime(df["run_end_et"])
    return df


def _top_counts(series: pd.Series, limit: int = 15) -> list[dict[str, Any]]:
    counts = series.value_counts().head(limit)
    return [{"value": str(index), "count": int(value)} for index, value in counts.items()]


def _workbook_summary(df: pd.DataFrame) -> dict[str, Any]:
    return {
        "burst_rows": int(len(df)),
        "ticker_count": int(df["ticker"].nunique()),
        "start_min_et": df["run_start_et"].min().strftime("%Y/%m/%d %H:%M:%S"),
        "start_max_et": df["run_start_et"].max().strftime("%Y/%m/%d %H:%M:%S"),
        "end_min_et": df["run_end_et"].min().strftime("%Y/%m/%d %H:%M:%S"),
        "end_max_et": df["run_end_et"].max().strftime("%Y/%m/%d %H:%M:%S"),
        "top_tickers": _top_counts(df["ticker"]),
        "top_dates": _top_counts(df["run_start_et"].dt.strftime("%Y/%m/%d")),
    }


def _tokenize_conditions(conditions: str) -> list[str]:
    return [part.strip() for part in str(conditions or "").split(" AND ") if part.strip()]


def _condition_token_weights(
    study_summary: dict[str, Any],
    signal_slate: Iterable[dict[str, Any]],
) -> list[dict[str, Any]]:
    counter: Counter[str] = Counter()
    source_count: Counter[str] = Counter()

    for item in list(study_summary.get("top_conditions") or []):
        token = str(item.get("condition") or "").strip()
        if not token:
            continue
        counter[token] += float(item.get("lift_vs_baseline") or 0.0) * float(item.get("event_hits") or 0.0)
        source_count[token] += 1

    for item in list(signal_slate or []):
        weight = float(item.get("val_hit_rate") or 0.0) * max(int(item.get("val_n") or 0), 1)
        for token in _tokenize_conditions(str(item.get("conditions") or "")):
            counter[token] += weight
            source_count[token] += 1

    ranked: list[dict[str, Any]] = []
    for token, score in counter.most_common():
        ranked.append(
            {
                "condition": token,
                "weighted_score": round(float(score), 4),
                "source_mentions": int(source_count[token]),
            }
        )
    return ranked


def _find_signal(
    signal_slate: Iterable[dict[str, Any]],
    conditions: str,
) -> dict[str, Any]:
    for item in signal_slate:
        if str(item.get("conditions") or "").strip() == conditions:
            return dict(item)
    raise KeyError(f"Signal not found: {conditions}")


def _build_feed_candidates(signal_slate: Iterable[dict[str, Any]]) -> list[FeedCandidate]:
    selected = [
        (
            "Green10 Reclaim Cross",
            "down_close_streak>=2 AND macd_cross_up AND vwap<=-0.005",
            "Best current high-conviction reclaim trigger: two down closes into a MACD up-cross while price is still at least 50 bp below VWAP.",
        ),
        (
            "Green10 Reclaim CMO",
            "down_close_streak>=2 AND macd_cross_up AND cmo<=-20",
            "Same reclaim shape as the MACD/VWAP setup, but keyed to negative CMO instead of VWAP extension for slightly broader coverage.",
        ),
        (
            "Green10 Flush Momentum",
            "red_streak>=2 AND roc<=-1.5 AND rvol>=1.5",
            "Best broad flush pattern: a true two-bar red streak with sharp negative ROC and heavy RVOL consistently preceded the green10 upside path.",
        ),
        (
            "Green10 Trend Dip",
            "setup_red AND low_close<=0.35 AND adx_strong AND ema_stack_bull AND di_bull",
            "Broader trend-continuation version: a red setup candle closing weak inside an already-bullish, directional trend context.",
        ),
        (
            "Green10 Oversold Reset",
            "setup_red AND low_close<=0.35 AND rsi<=40 AND cmo<=-20",
            "Broad oversold pullback layer for coverage when the tape is not yet printing a clean MACD cross but momentum is materially negative.",
        ),
    ]
    candidates: list[FeedCandidate] = []
    for name, conditions, rationale in selected:
        item = _find_signal(signal_slate, conditions)
        candidates.append(
            FeedCandidate(
                name=name,
                conditions=conditions,
                hit_rate=float(item.get("hit_rate") or 0.0),
                val_hit_rate=float(item.get("val_hit_rate") or 0.0),
                n=int(item.get("n") or 0),
                val_n=int(item.get("val_n") or 0),
                ticker_count=int(item.get("ticker_count") or 0),
                val_ticker_count=int(item.get("val_ticker_count") or 0),
                avg_future_move_15=(
                    float(item.get("avg_future_move_15"))
                    if item.get("avg_future_move_15") not in (None, "")
                    else None
                ),
                rationale=rationale,
            )
        )
    return candidates


def _recommendation_text(feed_candidates: list[FeedCandidate]) -> list[str]:
    lines = [
        "Recommended feed shape:",
        "1. Use a two-tier feed instead of one giant rule.",
        "2. Tier 1 should be the reclaim trigger stack: `down_close_streak>=2 AND macd_cross_up AND vwap<=-0.005` plus `down_close_streak>=2 AND macd_cross_up AND cmo<=-20`.",
        "3. Tier 2 should be the broader flush stack: `red_streak>=2 AND roc<=-1.5 AND rvol>=1.5`.",
        "4. Keep the trend-dip and oversold-reset stacks as secondary breadth layers, not the only trigger.",
    ]
    if feed_candidates:
        best = max(feed_candidates, key=lambda item: (item.val_hit_rate, item.val_n, item.ticker_count))
        lines.append(
            "Primary launch candidate: "
            f"`{best.name}` with validation hit rate `{best.val_hit_rate:.4f}` over `{best.val_n}` validation rows."
        )
    return lines


def _render_markdown(
    workbook_summary: dict[str, Any],
    study_summary: dict[str, Any],
    combo_rates: dict[str, Any],
    token_weights: list[dict[str, Any]],
    feed_candidates: list[FeedCandidate],
) -> str:
    meta = study_summary.get("meta") or {}
    lines: list[str] = []
    lines.append("# Green10 Pre-Run Feed Analysis")
    lines.append("")
    lines.append("## Event Set")
    lines.append(f"- Workbook burst rows: `{workbook_summary['burst_rows']}`")
    lines.append(f"- Distinct tickers: `{workbook_summary['ticker_count']}`")
    lines.append(
        f"- Burst range ET: `{workbook_summary['start_min_et']}` to `{workbook_summary['end_max_et']}`"
    )
    lines.append(
        f"- Study window already available in saved research: `{meta.get('trade_day_et', 'n/a')}` same-day study and `2026-01-02` to `2026-04-13` historical majority-green search."
    )
    lines.append("")
    lines.append("Top workbook tickers:")
    for item in workbook_summary["top_tickers"][:10]:
        lines.append(f"- `{item['value']}` -> `{item['count']}` runs")
    lines.append("")
    lines.append("## Repeated Pre-Run Traits")
    top_conditions = list(study_summary.get("top_conditions") or [])[:12]
    for item in top_conditions:
        lines.append(
            f"- `{item['condition']}` -> event rate `{float(item.get('event_rate') or 0.0):.4f}`, "
            f"lift `{float(item.get('lift_vs_baseline') or 0.0):.2f}x`, hits `{int(item.get('event_hits') or 0)}`"
        )
    lines.append("")
    lines.append("Most repeated condition tokens across the saved studies and signal slate:")
    for item in token_weights[:12]:
        lines.append(
            f"- `{item['condition']}` -> weighted score `{item['weighted_score']}`, mentions `{item['source_mentions']}`"
        )
    lines.append("")
    lines.append("## Feed-Ready Stacks")
    for candidate in feed_candidates:
        lines.append(
            f"- `{candidate.name}`: `{candidate.conditions}` | "
            f"`hit={candidate.hit_rate:.4f}` `val_hit={candidate.val_hit_rate:.4f}` "
            f"`n={candidate.n}` `val_n={candidate.val_n}` "
            f"`tickers={candidate.ticker_count}` `val_tickers={candidate.val_ticker_count}`"
        )
        lines.append(f"  {candidate.rationale}")
    lines.append("")
    lines.append("## Combo Rate Backdrop")
    lines.append(f"- Day-base green10 rate in saved same-day study: `{float(combo_rates.get('base_rate') or 0.0):.4f}`")
    for item in list(combo_rates.get("results") or [])[:7]:
        lines.append(
            f"- `{item['combo']}` -> `hit={float(item.get('hit_rate') or 0.0):.4f}` "
            f"`lift={float(item.get('lift_vs_day_base') or 0.0):.2f}x` "
            f"`selected={int(item.get('selected') or 0)}`"
        )
    lines.append("")
    lines.append("## Recommendation")
    lines.extend([f"- {line}" for line in _recommendation_text(feed_candidates)])
    lines.append("")
    lines.append("## Bottom Line")
    lines.append(
        "- The repeated shape is not ticker-specific. The most reusable pre-run pattern is a short red flush or down-close sequence, usually closing weak in range, then either a MACD up-cross reclaim or a high-velocity oversold flush."
    )
    lines.append(
        "- The best initial feed should be bullish-only and stack reclaim plus flush conditions instead of hunting one ticker or one time-of-day window."
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Summarize green10 pre-run logic from saved workbook and research outputs.")
    parser.add_argument("--workbook", type=Path, default=DEFAULT_WORKBOOK)
    parser.add_argument("--study-summary", type=Path, default=DEFAULT_STUDY_SUMMARY)
    parser.add_argument("--combo-rates", type=Path, default=DEFAULT_COMBO_RATES)
    parser.add_argument("--signal-slate", type=Path, default=DEFAULT_SIGNAL_SLATE)
    parser.add_argument("--report-out", type=Path, default=DEFAULT_REPORT)
    parser.add_argument("--json-out", type=Path, default=DEFAULT_JSON)
    args = parser.parse_args()

    workbook_df = _parse_workbook(args.workbook)
    study_summary = _read_json(args.study_summary)
    combo_rates = _read_json(args.combo_rates)
    signal_slate = _read_json(args.signal_slate)

    workbook_summary = _workbook_summary(workbook_df)
    token_weights = _condition_token_weights(study_summary, signal_slate)
    feed_candidates = _build_feed_candidates(signal_slate)

    payload = {
        "generated_at": datetime.now().isoformat(),
        "workbook_summary": workbook_summary,
        "study_meta": study_summary.get("meta") or {},
        "median_setup_state": study_summary.get("median_setup_state") or {},
        "top_conditions": list(study_summary.get("top_conditions") or []),
        "top_signatures": list(study_summary.get("top_signatures") or []),
        "combo_rates": combo_rates,
        "condition_token_weights": token_weights,
        "feed_candidates": [candidate.to_dict() for candidate in feed_candidates],
        "recommendation": _recommendation_text(feed_candidates),
    }

    markdown = _render_markdown(
        workbook_summary=workbook_summary,
        study_summary=study_summary,
        combo_rates=combo_rates,
        token_weights=token_weights,
        feed_candidates=feed_candidates,
    )

    args.report_out.write_text(markdown, encoding="utf-8")
    args.json_out.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    print(f"wrote_report={args.report_out}")
    print(f"wrote_json={args.json_out}")
    print(f"burst_rows={workbook_summary['burst_rows']}")
    print(f"ticker_count={workbook_summary['ticker_count']}")
    print(f"feed_candidates={len(feed_candidates)}")


if __name__ == "__main__":
    main()
