from __future__ import annotations

import argparse
import ast
import csv
import html
import json
import re
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from reportlab.lib import colors
from reportlab.lib.pagesizes import LETTER, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    HRFlowable,
    LongTable,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


REPO_ROOT = Path(__file__).resolve().parents[1]
API_ROOT = REPO_ROOT / "fudstop4" / "apis"
ATTRIBUTES_ROOT = REPO_ROOT / "attributes"
REPORT_TZ = ZoneInfo("America/Chicago")
DEFAULT_PDF = REPO_ROOT / "output" / "pdf" / "fudstop_api_attribute_inventory_report.pdf"
DEFAULT_JSON = REPO_ROOT / "output" / "reports" / "fudstop_api_attribute_inventory_report.json"
DEFAULT_CSV = REPO_ROOT / "output" / "reports" / "fudstop_api_attribute_inventory_fields.csv"
DEFAULT_SUMMARY_CSV = REPO_ROOT / "output" / "reports" / "fudstop_api_attribute_inventory_providers.csv"

COPY_MARKERS = (" - Copy.py", " copy.py", "_copy.py")
STRUCTURED_FRAME_ATTRS = {"as_dataframe", "df", "applications_as_dataframe", "wallets_dataframe"}
INTERNAL_ATTRS = {
    "data_dict",
    "as_dataframe",
    "df",
    "wallets_dataframe",
    "applications_as_dataframe",
    "headers",
    "token",
    "base_url",
    "endpoints",
    "pool",
    "conn",
    "connection",
    "session",
    "client",
    "api_key",
    "latest_post_id",
    "response",
    "responses",
    "url",
    "urls",
    "params",
    "cookies",
    "raw_data",
    "_schema_lock",
    "_conn",
    "_pool",
    "auth_headers",
    "payload",
    "json",
    "text",
    "content",
    "chat_memory",
    "database",
    "connection_string",
    "db",
}

MARKET_PROVIDERS = {
    "all_options",
    "alphaquery",
    "alphavantage",
    "blotter",
    "cme",
    "coinbase",
    "coin_compare",
    "coin_marketcap",
    "datagov",
    "datalink",
    "diptrader",
    "earningshub",
    "earnings_whisper",
    "fed_print",
    "federal_register",
    "finra",
    "fred",
    "kalshi",
    "moomoo",
    "nasdaq",
    "newyork_fed",
    "occ",
    "ofr",
    "oic",
    "ortex",
    "polygonio",
    "prebid",
    "sec",
    "stocksera_",
    "tradier",
    "tradytics",
    "treasury",
    "webull",
    "whale",
    "y_finance",
}

LEGAL_REG_PROVIDERS = {
    "caselaw",
    "casetext",
    "cfr",
    "ezsec",
    "fastcase",
    "federal_register",
    "fed_print",
    "legal_codes",
    "transparencyusa",
    "vlex",
    "xml",
    "sec",
}

SOCIAL_CONTENT_PROVIDERS = {
    "discord_",
    "reddit",
    "rss",
    "rss_feeds",
    "misc",
    "rapid",
    "udio",
    "youtube",
    "gpts",
    "gmail",
}

INTERNAL_UTILITY_PROVIDERS = {
    "_asyncpg",
    "_datetime",
    "_file",
    "_fudstop",
    "_openai",
    "_pandas",
    "_pdf",
    "_researchtx",
    "_selenium",
    "_ta",
    "master",
}

CATEGORY_ORDER = [
    "price_quote",
    "flow_liquidity",
    "options_derivatives",
    "technical",
    "fundamentals_tokenomics",
    "macro_rates",
    "crypto_market",
    "news_social_sentiment",
    "regulatory_legal",
    "entity_keys",
    "temporal",
    "presentation_media",
    "other_metadata",
]

CATEGORY_LABELS = {
    "price_quote": "Price & Quote",
    "flow_liquidity": "Flow & Liquidity",
    "options_derivatives": "Options & Derivatives",
    "technical": "Technical Indicators",
    "fundamentals_tokenomics": "Fundamentals & Tokenomics",
    "macro_rates": "Macro & Rates",
    "crypto_market": "Crypto Market",
    "news_social_sentiment": "News & Social Sentiment",
    "regulatory_legal": "Regulatory & Legal",
    "entity_keys": "Entity Keys",
    "temporal": "Temporal",
    "presentation_media": "Presentation & Media",
    "other_metadata": "Other Metadata",
}

ROLE_LABELS = {
    "direct_metric": "Direct metric",
    "state_metric": "State metric",
    "dimension": "Dimension",
    "event_dimension": "Event context",
    "presentation": "Presentation",
}

ROLE_ORDER = {
    "direct_metric": 0,
    "state_metric": 1,
    "event_dimension": 2,
    "dimension": 3,
    "presentation": 4,
}


def intfmt(value: int | float) -> str:
    return f"{int(round(float(value))):,}"


def chunked(items: list[Any], size: int) -> list[list[Any]]:
    return [items[idx: idx + size] for idx in range(0, len(items), size)]


def is_copy_file(path: Path) -> bool:
    lowered = path.name.lower()
    return any(marker.lower() in lowered for marker in COPY_MARKERS)


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="latin-1")


def str_from_node(node: ast.AST) -> str | None:
    return node.value if isinstance(node, ast.Constant) and isinstance(node.value, str) else None


def list_of_strings(node: ast.AST) -> list[str]:
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        return [value for elt in node.elts if (value := str_from_node(elt)) is not None]
    return []


def dict_string_keys(node: ast.AST) -> list[str]:
    if isinstance(node, ast.Dict):
        return [value for key in node.keys if (value := str_from_node(key)) is not None]
    return []


def camel_to_snake(name: str) -> str:
    clean = re.sub(r"[^0-9a-zA-Z]+", "_", name)
    clean = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", clean)
    clean = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", clean)
    clean = clean.replace("__", "_").strip("_").lower()
    replacements = {
        "asksize": "ask_size",
        "bidsize": "bid_size",
        "quotetime": "quote_time",
        "changepercent": "change_percent",
        "openinterest": "open_interest",
        "callput": "call_put",
        "theoprice": "theo_price",
        "forwardprice": "forward_price",
        "marketcap": "market_cap",
        "holdercount": "holder_count",
        "priceusd": "price_usd",
        "volume24h": "volume_24h",
        "pricechange24h": "price_change_24h",
        "publishat": "publish_at",
        "poolcreatetime": "pool_create_time",
        "latestsignaltime": "latest_signal_time",
        "firstsignaltime": "first_signal_time",
    }
    return replacements.get(clean, clean)


def tokenise(name: str) -> list[str]:
    stepped = re.sub(r"([0-9])([a-zA-Z])", r"\1_\2", name)
    stepped = re.sub(r"([a-zA-Z])([0-9])", r"\1_\2", stepped)
    return [token for token in stepped.split("_") if token]


def provider_group(provider: str) -> str:
    if provider in MARKET_PROVIDERS:
        return "market"
    if provider in LEGAL_REG_PROVIDERS:
        return "legal_reg"
    if provider in SOCIAL_CONTENT_PROVIDERS:
        return "social_content"
    if provider in INTERNAL_UTILITY_PROVIDERS:
        return "internal_utility"
    return "other"


def is_presentation_field(name: str) -> bool:
    tokens = set(tokenise(name))
    presentation_suffixes = (
        "_string",
        "_html",
        "_url",
        "_link",
        "_image",
        "_img",
        "_icon",
        "_logo",
        "_color",
        "_text",
        "_name",
        "_title",
        "_description",
        "_desc",
    )
    if name.endswith(presentation_suffixes):
        return True
    return bool(tokens & {"html", "url", "link", "image", "img", "icon", "logo", "thumbnail", "banner", "avatar"})


def classify_field(name: str) -> str:
    tokens = tokenise(name)
    token_set = set(tokens)
    if token_set & {"ticker", "symbol", "slug", "cusip", "isin", "cik", "figi", "lei", "uuid"} or name.endswith("_id") or name == "id":
        return "entity_keys"
    if token_set & {"date", "time", "timestamp", "ts", "expiry", "expiration", "maturity", "quarter", "year", "month", "day", "session"} or name.endswith("_at") or name.startswith("created_") or name.startswith("updated_"):
        return "temporal"
    if is_presentation_field(name):
        return "presentation_media"
    if (
        token_set & {"call", "put", "option", "strike", "expiry", "expiration", "dte", "skew", "gex", "iv", "gamma", "delta", "theta", "vega", "rho"}
        or "ivx" in name
        or "ivr" in name
        or "ivp" in name
        or "greek" in name
    ):
        return "options_derivatives"
    if token_set & {"rsi", "macd", "stoch", "atr", "cci", "adx", "mfi", "trix", "roc", "sma", "ema", "wma", "bollinger", "bb", "rvol", "vwap", "td9", "td"} or name.startswith(("macd_", "rsi_", "td9_")):
        return "technical"
    if token_set & {"bid", "ask", "last", "mark", "open", "high", "low", "close", "mid", "price", "quote", "nav"} or name.endswith("_price") or name.startswith("price_"):
        return "price_quote"
    if token_set & {"volume", "flow", "liquidity", "turnover", "shares", "contracts", "borrow", "short", "premium", "premiums", "notional", "trade", "trades", "oi", "quantity", "size"} or name.endswith("_volume"):
        return "flow_liquidity"
    if token_set & {"revenue", "eps", "income", "sales", "ebit", "ebitda", "margin", "cash", "debt", "asset", "assets", "liabilities", "equity", "book", "capex", "dividend", "yield", "holding", "holdings", "holders", "supply", "valuation"} or "market_cap" in name:
        return "fundamentals_tokenomics"
    if token_set & {"treasury", "fed", "cpi", "ppi", "inflation", "gdp", "repo", "auction", "jobless", "claims", "rate", "rates", "yield"}:
        return "macro_rates"
    if token_set & {"filing", "sec", "edgar", "document", "form", "case", "court", "judge", "docket", "rule", "register", "agency", "citation", "legal", "opinion"}:
        return "regulatory_legal"
    if token_set & {"news", "headline", "summary", "comment", "message", "post", "reddit", "channel", "forum", "subreddit", "author", "vote", "votes", "mention", "mentions", "sentiment", "bullish", "bearish"}:
        return "news_social_sentiment"
    if token_set & {"coin", "token", "crypto", "blockchain", "dex", "cex", "perpetual", "futures", "wallet"}:
        return "crypto_market"
    return "other_metadata"


def metric_bucket(name: str) -> str:
    category = classify_field(name)
    tokens = set(tokenise(name))
    if category in {
        "price_quote",
        "flow_liquidity",
        "options_derivatives",
        "technical",
        "fundamentals_tokenomics",
        "macro_rates",
        "crypto_market",
    }:
        return "presentation" if is_presentation_field(name) else "direct_metric"
    if category in {"news_social_sentiment", "regulatory_legal"}:
        if tokens & {"score", "rank", "sentiment", "votes", "vote", "mention", "mentions", "count", "rating", "grade", "bullish", "bearish"}:
            return "state_metric"
        return "event_dimension"
    if category in {"entity_keys", "temporal"}:
        return "dimension"
    if category == "presentation_media":
        return "presentation"
    if tokens & {"score", "rank", "count", "ratio", "percent", "pct", "change", "value", "amount", "level"}:
        return "direct_metric"
    return "dimension"


def nice_role(role: str) -> str:
    return ROLE_LABELS.get(role, role.replace("_", " ").title())


def nice_category(category: str) -> str:
    return CATEGORY_LABELS.get(category, category.replace("_", " ").title())


def scope_label(groups: set[str]) -> str:
    if not groups:
        return "other"
    if len(groups) == 1:
        return next(iter(groups)).replace("_", "/")
    return "mixed"


def sample_providers(providers: list[str], limit: int = 6) -> str:
    if len(providers) <= limit:
        return ", ".join(providers)
    return f"{', '.join(providers[:limit])} +{len(providers) - limit} more"


def extract_surface_records() -> dict[str, Any]:
    active_records: list[dict[str, Any]] = []
    copy_records: list[dict[str, Any]] = []
    all_provider_dirs = sorted(path.name for path in API_ROOT.iterdir() if path.is_dir() and path.name != "__pycache__")

    for path in sorted(API_ROOT.rglob("*.py")):
        if "__pycache__" in path.parts:
            continue
        rel = path.relative_to(API_ROOT)
        provider = rel.parts[0]
        source = read_text(path)
        tree = ast.parse(source)

        for node in tree.body:
            if not isinstance(node, ast.ClassDef):
                continue

            self_fields: set[str] = set()
            data_dict_keys: set[str] = set()
            attr_list_keys: set[str] = set()
            local_data_dict_keys: set[str] = set()
            has_df = False
            path_hint = ("models" in rel.parts) or rel.name.endswith("_models.py") or rel.name == "models.py"

            for sub in ast.walk(node):
                if not isinstance(sub, (ast.Assign, ast.AnnAssign)):
                    continue
                targets = sub.targets if isinstance(sub, ast.Assign) else [sub.target]
                value = sub.value
                for target in targets:
                    if isinstance(target, ast.Attribute) and isinstance(target.value, ast.Name) and target.value.id == "self":
                        attr_name = target.attr
                        if attr_name == "data_dict":
                            data_dict_keys.update(dict_string_keys(value))
                        elif attr_name in STRUCTURED_FRAME_ATTRS:
                            has_df = True
                        elif attr_name.endswith("attributes") or attr_name.endswith("_attributes"):
                            attr_list_keys.update(list_of_strings(value))
                        elif attr_name not in INTERNAL_ATTRS and not attr_name.startswith("_"):
                            self_fields.add(attr_name)
                    elif isinstance(target, ast.Name) and target.id == "data_dict":
                        local_data_dict_keys.update(dict_string_keys(value))

            model_like = bool(data_dict_keys or local_data_dict_keys or has_df or attr_list_keys or path_hint)
            surface = set(data_dict_keys) | set(local_data_dict_keys) | set(attr_list_keys)
            if not surface and model_like and len(self_fields) >= 3:
                surface |= self_fields
            if not surface:
                continue

            record = {
                "provider": provider,
                "file": str(rel),
                "class_name": node.name,
                "fields_exact": sorted(surface),
                "fields_canonical": sorted({camel_to_snake(field) for field in surface if field}),
                "is_copy": is_copy_file(path),
            }
            if record["is_copy"]:
                copy_records.append(record)
            else:
                active_records.append(record)

    providers_with_surface = sorted({record["provider"] for record in active_records})
    providers_without_surface = sorted(set(all_provider_dirs) - set(providers_with_surface))

    return {
        "active_records": active_records,
        "copy_records": copy_records,
        "all_provider_dirs": all_provider_dirs,
        "providers_with_surface": providers_with_surface,
        "providers_without_surface": providers_without_surface,
    }


def aggregate_inventory(scan: dict[str, Any]) -> dict[str, Any]:
    active_records = scan["active_records"]
    copy_records = scan["copy_records"]

    field_map: dict[str, dict[str, Any]] = {}
    provider_field_map: dict[str, set[str]] = defaultdict(set)

    for record in active_records:
        provider = record["provider"]
        provider_field_map[provider].update(record["fields_canonical"])
        for field in record["fields_canonical"]:
            entry = field_map.setdefault(
                field,
                {
                    "attribute": field,
                    "providers": set(),
                    "files": set(),
                    "classes": set(),
                    "provider_groups": set(),
                },
            )
            entry["providers"].add(provider)
            entry["files"].add(record["file"])
            entry["classes"].add(record["class_name"])
            entry["provider_groups"].add(provider_group(provider))

    field_rows: list[dict[str, Any]] = []
    for field, entry in sorted(field_map.items()):
        category = classify_field(field)
        role = metric_bucket(field)
        groups = sorted(entry["provider_groups"])
        providers = sorted(entry["providers"])
        market_provider_count = sum(1 for provider in providers if provider in MARKET_PROVIDERS)
        engineerable = market_provider_count > 0 and role in {"direct_metric", "state_metric"}
        field_rows.append(
            {
                "attribute": field,
                "category": category,
                "category_label": nice_category(category),
                "role": role,
                "role_label": nice_role(role),
                "engineerable": engineerable,
                "provider_groups": groups,
                "scope": scope_label(set(groups)),
                "provider_count": len(providers),
                "market_provider_count": market_provider_count,
                "providers": providers,
                "provider_sample": sample_providers(providers),
                "file_count": len(entry["files"]),
                "class_count": len(entry["classes"]),
            }
        )

    field_rows.sort(
        key=lambda row: (
            CATEGORY_ORDER.index(row["category"]) if row["category"] in CATEGORY_ORDER else len(CATEGORY_ORDER),
            ROLE_ORDER.get(row["role"], 99),
            not row["engineerable"],
            row["attribute"],
        )
    )

    provider_rows = []
    for provider, fields in provider_field_map.items():
        group = provider_group(provider)
        metric_fields = sum(1 for field in fields if metric_bucket(field) == "direct_metric")
        state_fields = sum(1 for field in fields if metric_bucket(field) == "state_metric")
        provider_rows.append(
            {
                "provider": provider,
                "group": group,
                "total_fields": len(fields),
                "metric_fields": metric_fields,
                "state_fields": state_fields,
                "dimension_or_presentation_fields": len(fields) - metric_fields - state_fields,
            }
        )
    provider_rows.sort(key=lambda row: (-row["total_fields"], row["provider"]))

    copy_field_count = len({field for record in copy_records for field in record["fields_canonical"]})

    historical_snapshot_fields = 0
    if ATTRIBUTES_ROOT.exists():
        keys: set[str] = set()
        for path in ATTRIBUTES_ROOT.glob("*.json"):
            try:
                payload = json.loads(read_text(path))
            except json.JSONDecodeError:
                continue
            if isinstance(payload, dict):
                keys.update(payload.keys())
        historical_snapshot_fields = len(keys)

    category_counts = Counter(row["category"] for row in field_rows)
    market_rows = [row for row in field_rows if "market" in row["provider_groups"]]
    role_counts_market = Counter(row["role"] for row in market_rows)
    engineerable_rows = [row for row in market_rows if row["engineerable"]]
    engineerable_category_counts = Counter(row["category"] for row in engineerable_rows)

    summary = {
        "providers_total": len(scan["all_provider_dirs"]),
        "providers_with_structured_surface": len(scan["providers_with_surface"]),
        "providers_without_structured_surface": len(scan["providers_without_surface"]),
        "active_files_with_surface": len({record["file"] for record in active_records}),
        "active_classes_with_surface": len({(record["file"], record["class_name"]) for record in active_records}),
        "active_canonical_fields": len(field_rows),
        "market_canonical_fields": len(market_rows),
        "legal_reg_fields": sum(1 for row in field_rows if "legal_reg" in row["provider_groups"]),
        "social_content_fields": sum(1 for row in field_rows if "social_content" in row["provider_groups"]),
        "internal_utility_fields": sum(1 for row in field_rows if "internal_utility" in row["provider_groups"]),
        "copy_only_canonical_fields": copy_field_count,
        "historical_attributes_snapshot_fields": historical_snapshot_fields,
        "market_direct_metric_fields": sum(1 for row in engineerable_rows if row["role"] == "direct_metric"),
        "market_state_metric_fields": sum(1 for row in engineerable_rows if row["role"] == "state_metric"),
        "market_engineerable_fields": len(engineerable_rows),
        "market_dimension_fields": role_counts_market["dimension"],
        "market_event_dimension_fields": role_counts_market["event_dimension"],
        "market_presentation_fields": role_counts_market["presentation"],
        "first_wave_engineerable_total": len(engineerable_rows) * 3,
    }

    return {
        "summary": summary,
        "field_rows": field_rows,
        "provider_rows": provider_rows,
        "category_counts": dict(category_counts),
        "market_category_counts": dict(Counter(row["category"] for row in market_rows)),
        "engineerable_category_counts": dict(engineerable_category_counts),
        "providers_without_surface": scan["providers_without_surface"],
    }


def write_csvs(report: dict[str, Any], fields_csv: Path, provider_csv: Path) -> None:
    fields_csv.parent.mkdir(parents=True, exist_ok=True)
    with fields_csv.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(
            [
                "attribute",
                "category",
                "role",
                "engineerable",
                "scope",
                "provider_count",
                "market_provider_count",
                "provider_groups",
                "providers",
                "provider_sample",
                "file_count",
                "class_count",
            ]
        )
        for row in report["field_rows"]:
            writer.writerow(
                [
                    row["attribute"],
                    row["category"],
                    row["role"],
                    "yes" if row["engineerable"] else "no",
                    row["scope"],
                    row["provider_count"],
                    row["market_provider_count"],
                    ",".join(row["provider_groups"]),
                    ",".join(row["providers"]),
                    row["provider_sample"],
                    row["file_count"],
                    row["class_count"],
                ]
            )

    with provider_csv.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["provider", "group", "total_fields", "metric_fields", "state_fields", "dimension_or_presentation_fields"])
        for row in report["provider_rows"]:
            writer.writerow(
                [
                    row["provider"],
                    row["group"],
                    row["total_fields"],
                    row["metric_fields"],
                    row["state_fields"],
                    row["dimension_or_presentation_fields"],
                ]
            )


def write_json(report: dict[str, Any], output_json: Path, generated_at: str) -> None:
    output_json.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "generated_at": generated_at,
        "summary": report["summary"],
        "category_counts": report["category_counts"],
        "market_category_counts": report["market_category_counts"],
        "engineerable_category_counts": report["engineerable_category_counts"],
        "providers_without_structured_surface": report["providers_without_surface"],
        "providers": report["provider_rows"],
        "fields": report["field_rows"],
    }
    output_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def build_styles() -> dict[str, ParagraphStyle]:
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="HeroTitle",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=22,
            leading=24,
            textColor=colors.white,
            spaceAfter=4,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Body",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=9.4,
            leading=12.0,
            spaceAfter=6,
            textColor=colors.HexColor("#243B53"),
        )
    )
    styles.add(
        ParagraphStyle(
            name="Small",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=8.0,
            leading=10.0,
            textColor=colors.HexColor("#334E68"),
        )
    )
    styles.add(
        ParagraphStyle(
            name="Tiny",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=7.0,
            leading=8.3,
            textColor=colors.HexColor("#334E68"),
        )
    )
    return styles


def safe_paragraph(text: str, style: ParagraphStyle) -> Paragraph:
    return Paragraph(html.escape(text), style)


def table_style(header_bg: colors.Color = colors.HexColor("#0B3954"), font_size: float = 8.0) -> TableStyle:
    return TableStyle(
        [
            ("BACKGROUND", (0, 0), (-1, 0), header_bg),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
            ("FONTSIZE", (0, 0), (-1, -1), font_size),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#A7B1BC")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F5F8FB")]),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]
    )


def banner(text: str, width: float, bg: str = "#0B3954") -> Table:
    tbl = Table([[text]], colWidths=[width], rowHeights=[0.3 * inch])
    tbl.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor(bg)),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.white),
                ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 10.5),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    return tbl


def paragraph_table(rows: list[list[Any]], col_widths: list[float], header_bg: str, font_size: float = 8.1) -> LongTable:
    table = LongTable(rows, colWidths=col_widths, repeatRows=1)
    table.setStyle(table_style(colors.HexColor(header_bg), font_size=font_size))
    return table


def build_pdf(report: dict[str, Any], output_pdf: Path, report_date: str, generated_at: str) -> None:
    output_pdf.parent.mkdir(parents=True, exist_ok=True)

    styles = build_styles()
    page_size = landscape(LETTER)
    page_width, page_height = page_size
    margin = 0.45 * inch
    content_width = page_width - (margin * 2)

    doc = SimpleDocTemplate(
        str(output_pdf),
        pagesize=page_size,
        leftMargin=margin,
        rightMargin=margin,
        topMargin=0.52 * inch,
        bottomMargin=0.52 * inch,
        title="FUDSTOP API Attribute Inventory",
        author="Codex",
    )

    def header_footer(canvas, pdf_doc) -> None:
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor("#0B3954"))
        canvas.setLineWidth(1.8)
        canvas.line(margin, page_height - 0.28 * inch, page_width - margin, page_height - 0.28 * inch)
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#486581"))
        canvas.drawString(margin, 0.23 * inch, "FUDSTOP API Attribute Inventory")
        canvas.drawRightString(page_width - margin, 0.23 * inch, f"Page {pdf_doc.page}")
        canvas.drawRightString(page_width - margin, page_height - 0.24 * inch, report_date)
        canvas.restoreState()

    summary = report["summary"]
    provider_rows = report["provider_rows"]
    field_rows = report["field_rows"]

    story: list[Any] = []

    hero = Table(
        [[Paragraph("<font color='white'><b>FUDSTOP API Attribute Inventory</b></font>", styles["HeroTitle"])]],
        colWidths=[content_width],
        rowHeights=[0.62 * inch],
    )
    hero.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#102A43")),
                ("LEFTPADDING", (0, 0), (-1, -1), 14),
                ("TOPPADDING", (0, 0), (-1, -1), 10),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
            ]
        )
    )
    story.append(hero)
    story.append(Spacer(1, 8))
    story.append(Paragraph(f"Report Date: <b>{report_date}</b>", styles["Body"]))
    story.append(
        Paragraph(
            "This report scans the active structured model surface under <b>fudstop4/apis</b>, deduplicates canonical field names, "
            "categorizes the full attribute inventory, and flags the subset that is directly engineerable into market metrics today.",
            styles["Body"],
        )
    )
    story.append(
        Paragraph(
            f"Generated from live code on {generated_at}. Legacy copy files are excluded from the main total and counted separately.",
            styles["Small"],
        )
    )
    story.append(HRFlowable(width="100%", thickness=1.0, color=colors.HexColor("#9FB3C8"), spaceBefore=2, spaceAfter=8))

    story.append(banner("1) Coverage Snapshot", content_width, "#1F7A8C"))
    story.append(Spacer(1, 6))
    summary_cards = Table(
        [
            ["Structured Fields", "Market Fields", "Engineerable Primitives", "First-Wave Metric Families"],
            [
                intfmt(summary["active_canonical_fields"]),
                intfmt(summary["market_canonical_fields"]),
                intfmt(summary["market_engineerable_fields"]),
                intfmt(summary["first_wave_engineerable_total"]),
            ],
        ],
        colWidths=[2.3 * inch, 2.15 * inch, 2.45 * inch, 2.75 * inch],
    )
    summary_cards.setStyle(table_style(colors.HexColor("#2C5282"), font_size=8.8))
    story.append(summary_cards)
    story.append(Spacer(1, 7))

    cov_rows = [
        ["Metric", "Observed Value"],
        ["Provider folders scanned", intfmt(summary["providers_total"])],
        ["Providers with structured surface", intfmt(summary["providers_with_structured_surface"])],
        ["Providers without structured surface", intfmt(summary["providers_without_structured_surface"])],
        ["Active files with surface", intfmt(summary["active_files_with_surface"])],
        ["Active classes with surface", intfmt(summary["active_classes_with_surface"])],
        ["Canonical attributes in active surface", intfmt(summary["active_canonical_fields"])],
        ["Canonical market-facing attributes", intfmt(summary["market_canonical_fields"])],
        ["Copy-file-only canonical attributes", intfmt(summary["copy_only_canonical_fields"])],
        ["Historical /attributes snapshot", intfmt(summary["historical_attributes_snapshot_fields"])],
    ]
    story.append(paragraph_table(cov_rows, [3.35 * inch, 2.1 * inch], "#0B3954"))
    story.append(Spacer(1, 8))

    story.append(banner("2) Engineering Capacity", content_width, "#2F855A"))
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            "Engineerable primitives are market-surface attributes whose canonical role is either <b>Direct metric</b> or "
            "<b>State metric</b>. The first-wave total multiplies those primitives across three immediately usable metric families: "
            "level, change regime, and relative ranking.",
            styles["Body"],
        )
    )

    eng_rows = [
        ["Metric Primitive Class", "Count"],
        ["Direct market metrics", intfmt(summary["market_direct_metric_fields"])],
        ["State / sentiment metrics", intfmt(summary["market_state_metric_fields"])],
        ["Dimension fields", intfmt(summary["market_dimension_fields"])],
        ["Event-context fields", intfmt(summary["market_event_dimension_fields"])],
        ["Presentation-only fields", intfmt(summary["market_presentation_fields"])],
        ["Engineerable primitive total", intfmt(summary["market_engineerable_fields"])],
        ["First-wave engineerable metric families", intfmt(summary["first_wave_engineerable_total"])],
    ]
    story.append(paragraph_table(eng_rows, [3.35 * inch, 2.1 * inch], "#276749"))
    story.append(Spacer(1, 8))

    category_rows = [["Category", "All Fields", "Market Fields", "Engineerable"]]
    for category in CATEGORY_ORDER:
        category_rows.append(
            [
                nice_category(category),
                intfmt(report["category_counts"].get(category, 0)),
                intfmt(report["market_category_counts"].get(category, 0)),
                intfmt(report["engineerable_category_counts"].get(category, 0)),
            ]
        )
    story.append(paragraph_table(category_rows, [2.7 * inch, 1.2 * inch, 1.2 * inch, 1.2 * inch], "#22543D"))

    story.append(PageBreak())
    story.append(banner("3) Provider Concentration", content_width, "#7B341E"))
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            "The inventory is top-heavy. Webull, OCC, All Options, Whale, Polygon, and New York Fed account for the largest share of structured fields and metric-bearing surface area.",
            styles["Body"],
        )
    )

    top_provider_rows = [["Provider", "Group", "Fields", "Direct Metrics", "State Metrics"]]
    for row in provider_rows[:20]:
        top_provider_rows.append(
            [
                row["provider"],
                row["group"].replace("_", "/"),
                intfmt(row["total_fields"]),
                intfmt(row["metric_fields"]),
                intfmt(row["state_fields"]),
            ]
        )
    story.append(paragraph_table(top_provider_rows, [2.0 * inch, 1.5 * inch, 1.1 * inch, 1.3 * inch, 1.3 * inch], "#7B341E"))
    story.append(Spacer(1, 8))

    if report["providers_without_surface"]:
        gap_rows = [["Providers Without Structured Surface", "Group"]]
        for provider in report["providers_without_surface"]:
            gap_rows.append([provider, provider_group(provider).replace("_", "/")])
        story.append(paragraph_table(gap_rows, [3.0 * inch, 1.7 * inch], "#9C4221"))

    story.append(PageBreak())
    story.append(banner("4) Full Attribute Inventory", content_width, "#0B3954"))
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            "Each appendix section below lists the canonical attribute, its semantic role, whether it is presently engineerable into a market metric family, "
            "its scope, and a provider sample showing where the field exists in the active API model surface.",
            styles["Body"],
        )
    )

    category_map: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in field_rows:
        category_map[row["category"]].append(row)

    for idx, category in enumerate(CATEGORY_ORDER, start=1):
        rows = category_map.get(category, [])
        if not rows:
            continue
        engineerable_count = sum(1 for row in rows if row["engineerable"])
        story.append(Spacer(1, 6))
        story.append(
            banner(
                f"4.{idx} {nice_category(category)} ({intfmt(len(rows))} attributes, {intfmt(engineerable_count)} engineerable)",
                content_width,
                "#102A43" if engineerable_count else "#334E68",
            )
        )
        story.append(Spacer(1, 4))

        table_rows: list[list[Any]] = [
            [
                safe_paragraph("Attribute", styles["Tiny"]),
                safe_paragraph("Role", styles["Tiny"]),
                safe_paragraph("Eng.", styles["Tiny"]),
                safe_paragraph("Scope", styles["Tiny"]),
                safe_paragraph("Provider Sample", styles["Tiny"]),
            ]
        ]
        for row in rows:
            table_rows.append(
                [
                    safe_paragraph(row["attribute"], styles["Tiny"]),
                    safe_paragraph(row["role_label"], styles["Tiny"]),
                    safe_paragraph("Yes" if row["engineerable"] else "No", styles["Tiny"]),
                    safe_paragraph(row["scope"], styles["Tiny"]),
                    safe_paragraph(row["provider_sample"], styles["Tiny"]),
                ]
            )

        for chunk_index, row_chunk in enumerate(chunked(table_rows[1:], 95)):
            if chunk_index:
                story.append(Spacer(1, 4))
            story.append(
                paragraph_table(
                    [table_rows[0], *row_chunk],
                    [2.55 * inch, 1.35 * inch, 0.55 * inch, 0.85 * inch, 4.45 * inch],
                    "#0B3954",
                    font_size=7.0,
                )
            )
            story.append(Spacer(1, 6))

    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate a PDF attribute inventory from fudstop4/apis.")
    parser.add_argument("--pdf", type=Path, default=DEFAULT_PDF, help="Output PDF path.")
    parser.add_argument("--json", type=Path, default=DEFAULT_JSON, help="Output JSON inventory path.")
    parser.add_argument("--csv", type=Path, default=DEFAULT_CSV, help="Output CSV field inventory path.")
    parser.add_argument("--provider-csv", type=Path, default=DEFAULT_SUMMARY_CSV, help="Output provider summary CSV path.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    scan = extract_surface_records()
    report = aggregate_inventory(scan)
    now_local = datetime.now(REPORT_TZ)
    generated_at = now_local.strftime("%Y-%m-%d %H:%M:%S America/Chicago")
    report_date = now_local.strftime("%Y-%m-%d")

    write_json(report, args.json, generated_at)
    write_csvs(report, args.csv, args.provider_csv)
    build_pdf(report, args.pdf, report_date, generated_at)

    print(
        json.dumps(
            {
                "pdf": str(args.pdf),
                "json": str(args.json),
                "csv": str(args.csv),
                "provider_csv": str(args.provider_csv),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
