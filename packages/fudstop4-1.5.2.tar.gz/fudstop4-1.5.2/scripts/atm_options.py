import sys
import asyncio
import time
from datetime import datetime
from pathlib import Path
import pandas as pd
from discord_webhook import AsyncDiscordWebhook, DiscordEmbed
from tabulate import tabulate

# Make sure project directory is in path
project_dir = str(Path(__file__).resolve().parents[1])
if project_dir not in sys.path:
    sys.path.append(project_dir)

from fudstop4._markets.list_sets.ticker_lists import most_active_tickers
from imports import *
from UTILS.confluence import score_options_flow


import asyncio
import pandas as pd
from itertools import islice

BATCH_SIZE = 5
DELAY_SECONDS = 15  # Delay between each full batch cycle
SCAN_TABLE_NAME = "atm_options_scan_metrics"
MIN_PULSE_VOLUME_DELTA = 75.0
# Fix timezone-aware timestamps that break asyncpg
def sanitize_timestamps(df, columns):
    for col in columns:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')
            df[col] = df[col].apply(lambda x: x.to_pydatetime().replace(tzinfo=None) if pd.notnull(x) else None)


def chunked(iterable, size):
    """Yield successive chunks of size `size` from iterable."""
    it = iter(iterable)
    while True:
        batch = list(islice(it, size))
        if not batch:
            break
        yield batch


def _safe_float(value):
    try:
        numeric = float(value)
    except Exception:
        return 0.0
    return numeric if pd.notnull(numeric) else 0.0


async def fetch_previous_scan(ticker: str):
    safe_ticker = str(ticker or "").replace("'", "''").upper()
    if not safe_ticker:
        return {}
    query = f"""
        SELECT *
        FROM {SCAN_TABLE_NAME}
        WHERE ticker = '{safe_ticker}'
        ORDER BY scan_timestamp DESC NULLS LAST, insertion_timestamp DESC NULLS LAST
        LIMIT 1
    """
    try:
        rows = await db.fetch(query)
    except Exception:
        return {}
    return rows[0] if rows else {}


def build_scan_metrics(
    *,
    ticker: str,
    call_volume: float,
    put_volume: float,
    call_oi: float,
    put_oi: float,
    call_contract_count: int,
    put_contract_count: int,
    previous: dict | None,
):
    previous = previous or {}
    prev_call_volume = _safe_float(previous.get("call_volume"))
    prev_put_volume = _safe_float(previous.get("put_volume"))
    prev_call_oi = _safe_float(previous.get("call_oi"))
    prev_put_oi = _safe_float(previous.get("put_oi"))

    call_volume_delta = max(0.0, call_volume - prev_call_volume)
    put_volume_delta = max(0.0, put_volume - prev_put_volume)
    call_oi_delta = max(0.0, call_oi - prev_call_oi)
    put_oi_delta = max(0.0, put_oi - prev_put_oi)
    net_volume_delta = call_volume_delta - put_volume_delta
    net_oi_delta = call_oi_delta - put_oi_delta
    has_prior_scan = bool(previous)

    if has_prior_scan and max(call_volume_delta, put_volume_delta, call_oi_delta, put_oi_delta) >= MIN_PULSE_VOLUME_DELTA:
        pulse_score = score_options_flow(
            call_volume=call_volume_delta,
            put_volume=put_volume_delta,
            call_oi=call_oi_delta,
            put_oi=put_oi_delta,
            label="pulse",
        )
        pulse_signal = pulse_score.signal
        pulse_points = int(pulse_score.points)
        pulse_reason = pulse_score.reason
        if pulse_signal == "bullish" and call_volume_delta >= 2500:
            pulse_points += 2
        elif pulse_signal == "bullish" and call_volume_delta >= 750:
            pulse_points += 1
        elif pulse_signal == "bearish" and put_volume_delta >= 2500:
            pulse_points -= 2
        elif pulse_signal == "bearish" and put_volume_delta >= 750:
            pulse_points -= 1
        if pulse_points > 0:
            pulse_signal = "bullish"
        elif pulse_points < 0:
            pulse_signal = "bearish"
        else:
            pulse_signal = "neutral"
    elif not has_prior_scan:
        pulse_signal = "neutral"
        pulse_points = 0
        pulse_reason = "Initial ATM scan established."
    else:
        pulse_signal = "neutral"
        pulse_points = 0
        pulse_reason = "No meaningful fresh ATM call/put pulse versus the prior scan."

    dominant_side = "call" if net_volume_delta > 0 else ("put" if net_volume_delta < 0 else "balanced")
    if has_prior_scan and pulse_signal in {"bullish", "bearish"}:
        leading_text = f"calls +{int(round(call_volume_delta))}" if pulse_signal == "bullish" else f"puts +{int(round(put_volume_delta))}"
        opposing_text = f"puts +{int(round(put_volume_delta))}" if pulse_signal == "bullish" else f"calls +{int(round(call_volume_delta))}"
        pulse_reason = f"{leading_text} vs {opposing_text} since last ATM scan; {pulse_reason}"

    return {
        "ticker": str(ticker or "").upper(),
        "scan_timestamp": datetime.now(),
        "call_volume": call_volume,
        "put_volume": put_volume,
        "call_oi": call_oi,
        "put_oi": put_oi,
        "call_contract_count": int(call_contract_count),
        "put_contract_count": int(put_contract_count),
        "call_volume_delta": call_volume_delta,
        "put_volume_delta": put_volume_delta,
        "net_volume_delta": net_volume_delta,
        "call_oi_delta": call_oi_delta,
        "put_oi_delta": put_oi_delta,
        "net_oi_delta": net_oi_delta,
        "dominant_side": dominant_side,
        "pulse_signal": pulse_signal,
        "pulse_points": pulse_points,
        "pulse_reason": pulse_reason,
    }

async def atm_options(ticker: str) -> None:
    """
    Fetch at-the-money options for a single ticker and upsert them into
    the ``atm_options`` table.  Assumes an active database connection.
    """
    try:
        # Note: The ticker is interpolated directly here; if user input is possible,
        # parameterize this query to avoid SQL injection.
        query = f"""
        SELECT wo.*
        FROM wb_opts wo
        JOIN multi_quote mq ON wo.ticker = mq.ticker
        WHERE wo.ticker = '{ticker}'
          AND wo.strike BETWEEN mq.close * 0.96 AND mq.close * 1.04
          AND wo.expiry >= CURRENT_DATE
        ORDER BY ABS(wo.strike - mq.close) ASC;
        """
        results = await db.fetch(query)
        if not results:
            print(f"[{ticker}] No ATM options found.")
            return
        df = pd.DataFrame(
            results, columns=await db.get_table_columns("wb_opts")
        )
        # Drop unused metadata columns
        df = df.drop(
            columns=["insertion_timestamp", "trade_time"],
            errors="ignore",
        )
        # Normalize expiry column to native dates
        if "expiry" in df.columns:
            df["expiry"] = pd.to_datetime(df["expiry"], errors="coerce").dt.date
        # Drop rows lacking required identifiers
        df = df.dropna(subset=["expiry", "option_id"])
        if df.empty:
            return
        call_mask = df["call_put"].astype(str).str.lower() == "call"
        put_mask = df["call_put"].astype(str).str.lower() == "put"
        call_volume = pd.to_numeric(df.loc[call_mask, "volume"], errors="coerce").fillna(0).sum()
        put_volume = pd.to_numeric(df.loc[put_mask, "volume"], errors="coerce").fillna(0).sum()
        call_oi = pd.to_numeric(df.loc[call_mask, "oi"], errors="coerce").fillna(0).sum()
        put_oi = pd.to_numeric(df.loc[put_mask, "oi"], errors="coerce").fillna(0).sum()
        previous_scan = await fetch_previous_scan(ticker)

        flow_score = score_options_flow(
            call_volume=call_volume,
            put_volume=put_volume,
            call_oi=call_oi,
            put_oi=put_oi,
            label="atm",
        )
        for col, value in flow_score.to_columns("atm_flow").items():
            df[col] = value

        await db.batch_upsert_dataframe(
            df,
            table_name="atm_options",
            unique_columns=["option_id"],
        )
        scan_metrics = build_scan_metrics(
            ticker=ticker,
            call_volume=float(call_volume),
            put_volume=float(put_volume),
            call_oi=float(call_oi),
            put_oi=float(put_oi),
            call_contract_count=int(call_mask.sum()),
            put_contract_count=int(put_mask.sum()),
            previous=previous_scan,
        )
        await db.batch_upsert_dataframe(
            pd.DataFrame([scan_metrics]),
            table_name=SCAN_TABLE_NAME,
            unique_columns=["ticker", "scan_timestamp"],
        )
        print(f"[{ticker}] Upserted {len(df)} ATM options.")
    except Exception as e:
        print(f"[!] Error in atm_options({ticker}): {e}")

async def run_atm_options() -> None:
    """
    Continuously process ATM options for the most active tickers in batches.
    Establishes a single database connection and sleeps between full cycles
    to avoid overwhelming the database and the API.
    """
    await db.connect()
    try:
        while True:
            for batch in chunked(most_active_tickers, BATCH_SIZE):
                print(f"Processing batch: {batch}")
                tasks = [atm_options(t) for t in batch]
                await asyncio.gather(*tasks)
            # Sleep after processing all tickers
            await asyncio.sleep(DELAY_SECONDS)
    finally:
        await db.disconnect()


if __name__ == "__main__":
    asyncio.run(run_atm_options())
