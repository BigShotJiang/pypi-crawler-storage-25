#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import re
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Sequence
from zoneinfo import ZoneInfo

import pandas as pd
import psycopg2

from search_m1_spawnmove_diverse_ca_metrics import (
    BOOLEAN_FIELDS,
    DEFAULT_BASE_EVENTS,
    DEFAULT_DB_HOST,
    DEFAULT_DB_NAME,
    DEFAULT_DB_PASSWORD,
    DEFAULT_DB_PORT,
    DEFAULT_MODERN_END,
    DEFAULT_MODERN_START,
    DEFAULT_OUTPUT_DIR,
    DEFAULT_PROMOTED,
    DEFAULT_DB_USER,
    NUMERIC_FIELDS,
    SPECIAL_BOOL_EXPRESSIONS,
    _build_clause_specs,
    _canonical_sql,
    _chrono_cuts,
    _coerce_bool_series,
    _load_base_events,
    _modern_slice,
    _safe_slug,
    _score_subset,
)


TRUTHY = {"true", "t", "1", "yes", "y"}
FALSY = {"false", "f", "0", "no", "n"}
MARKET_TZ = ZoneInfo("America/New_York")
COMPARISON_RE = re.compile(
    r"^(?P<field>[A-Za-z_][A-Za-z0-9_]*)\s*(?P<op><=|>=|!=|==|=|<|>)\s*(?P<value>.+?)\s*$"
)


@dataclass(frozen=True)
class ParsedCondition:
    field: str
    op: str
    value: Any
    raw: str
    expr: str
    fn: Callable[[pd.DataFrame], pd.Series]


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate an ad hoc m1 spawn-move condition stack and optionally "
            "search additive clauses on top of that base."
        )
    )
    parser.add_argument("--base-events", default=DEFAULT_BASE_EVENTS)
    parser.add_argument("--promoted-csv", default=DEFAULT_PROMOTED)
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--host", default=DEFAULT_DB_HOST)
    parser.add_argument("--port", type=int, default=DEFAULT_DB_PORT)
    parser.add_argument("--database", default=DEFAULT_DB_NAME)
    parser.add_argument("--user", default=DEFAULT_DB_USER)
    parser.add_argument("--password", default=DEFAULT_DB_PASSWORD)
    parser.add_argument("--modern-start", default=DEFAULT_MODERN_START)
    parser.add_argument("--modern-end", default=DEFAULT_MODERN_END)
    parser.add_argument("--condition", action="append", default=[], help="Single condition line. Repeat as needed.")
    parser.add_argument("--conditions-file", default="", help="Path to a text file with one condition per line.")
    parser.add_argument(
        "--stdin",
        action="store_true",
        help="Read condition lines from stdin. This is also used automatically when stdin is piped.",
    )
    parser.add_argument("--expand-k", type=int, default=2, help="Maximum number of extra clauses to add on top of the base.")
    parser.add_argument("--top-clause-pool", type=int, default=18, help="Top single clauses to use as the expansion pool.")
    parser.add_argument("--top-results", type=int, default=20, help="Maximum passing expansions to print.")
    parser.add_argument("--min-oos", type=int, default=25)
    parser.add_argument("--min-oos-precision", type=float, default=0.85)
    parser.add_argument("--min-validation", type=float, default=0.80)
    parser.add_argument("--min-holdout", type=float, default=0.85)
    parser.add_argument("--min-unique-tickers", type=int, default=10)
    parser.add_argument("--max-top-share", type=float, default=0.35)
    parser.add_argument(
        "--output-prefix",
        default="",
        help=(
            "Optional output prefix. When set, the script writes "
            "<prefix>.json and <prefix>_extensions.csv."
        ),
    )
    return parser.parse_args()


def _read_condition_lines(args: argparse.Namespace) -> List[str]:
    lines: List[str] = []
    lines.extend(args.condition or [])
    if args.conditions_file:
        path = Path(args.conditions_file)
        lines.extend(path.read_text(encoding="utf-8").splitlines())
    if args.stdin or (not lines and not sys.stdin.isatty()):
        lines.extend(sys.stdin.read().splitlines())
    cleaned = [
        line.strip()
        for line in lines
        if line.strip() and not line.strip().startswith("#")
    ]
    if not cleaned:
        raise ValueError("no conditions supplied; use --condition, --conditions-file, or pipe stdin")
    return cleaned


def _epoch_bounds(start_date: str, end_date: str) -> tuple[int, int]:
    start_dt = datetime.fromisoformat(start_date).replace(tzinfo=MARKET_TZ)
    end_dt = (datetime.fromisoformat(end_date) + timedelta(days=1)).replace(tzinfo=MARKET_TZ)
    return int(start_dt.timestamp()), int(end_dt.timestamp())


def _enrich_from_ca_fast(
    base_events: pd.DataFrame,
    args: argparse.Namespace,
    *,
    start_epoch: int,
    end_epoch: int,
) -> pd.DataFrame:
    tickers = sorted({str(value).strip().upper() for value in base_events["ticker"].tolist() if str(value).strip()})
    timespans = sorted({str(value).strip().lower() for value in base_events["timespan"].tolist() if str(value).strip()})
    conn = psycopg2.connect(
        host=args.host,
        port=args.port,
        dbname=args.database,
        user=args.user,
        password=args.password,
    )
    try:
        with conn, conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    UPPER(BTRIM(c.ticker)) AS ticker,
                    LOWER(COALESCE(c.timespan, '')) AS timespan,
                    c.ts::bigint AS ts_epoch,
                    c.date_et,
                    c.time_et,
                    c.session,
                    c.o,
                    c.c,
                    c.h,
                    c.l,
                    c.log_return,
                    c.upper_wick,
                    c.lower_wick,
                    c.close_vwap_diff_pct,
                    c.gap_pct,
                    c.is_gap,
                    c.gap_filled,
                    c.gap_unfilled,
                    c.is_time_gap,
                    c.hl_range_pct,
                    c.body_pct,
                    c.wick_ratio,
                    c.true_range_pct,
                    c.oc_pct,
                    c.change_pct,
                    c.is_inside_bar,
                    c.macd_line,
                    c.macd_signal,
                    c.macd_hist_slope,
                    c.macd_hist_slope3,
                    c.macd_imminent_bull,
                    c.macd_imminent_bear,
                    c.tsi,
                    c.tsi_signal,
                    c.di_plus,
                    c.di_minus,
                    c.macd_bull,
                    c.macd_bear,
                    c.tsi_bull,
                    c.tsi_bear,
                    c.momentum_confirm_bull,
                    c.momentum_confirm_bear
                FROM ca c
                WHERE c.ts::bigint >= %s
                  AND c.ts::bigint < %s
                  AND LOWER(COALESCE(c.timespan, '')) = ANY(%s)
                  AND UPPER(BTRIM(c.ticker)) = ANY(%s)
                """,
                (int(start_epoch), int(end_epoch), timespans, tickers),
            )
            rows = cur.fetchall()
            cols = [desc.name for desc in cur.description]
    finally:
        conn.close()
    extra = pd.DataFrame(rows, columns=cols)
    merged = base_events.merge(extra, on=["ticker", "timespan", "ts_epoch"], how="left", validate="many_to_one")
    merged["macd_line_signal_spread"] = merged["macd_line"] - merged["macd_signal"]
    merged["tsi_signal_spread"] = merged["tsi"] - merged["tsi_signal"]
    merged["di_spread"] = merged["di_plus"] - merged["di_minus"]
    merged["stoch_gap"] = merged["stoch_rsi_k"] - merged["stoch_rsi_d"]
    range_span = (merged["h"] - merged["l"]).replace(0, pd.NA)
    merged["upper_wick_pct"] = merged["upper_wick"] / range_span
    merged["lower_wick_pct"] = merged["lower_wick"] / range_span
    merged["close_pos_in_range"] = (merged["c"] - merged["l"]) / range_span
    gap_text = merged.get("gap_dir", pd.Series(index=merged.index, dtype="object")).astype(str).str.strip().str.lower()
    merged["gap_up"] = gap_text.eq("up") | (merged["gap_pct"].fillna(0.0) > 0)
    merged["gap_down"] = gap_text.eq("down") | (merged["gap_pct"].fillna(0.0) < 0)
    time_text = merged["time_et"].astype(str).str.strip()
    time_parsed = pd.to_datetime(time_text, format="%H:%M:%S", errors="coerce")
    fallback = time_parsed.isna()
    if fallback.any():
        time_parsed.loc[fallback] = pd.to_datetime(time_text.loc[fallback], format="%H:%M", errors="coerce")
    minute_of_day = (time_parsed.dt.hour * 60 + time_parsed.dt.minute).astype("float")
    session_text = merged["session"].astype(str).str.strip().str.lower()
    merged["session_regular"] = session_text.eq("regular")
    merged["session_premarket"] = session_text.eq("premarket")
    merged["session_afterhours"] = session_text.isin(["afterhours", "postmarket"])
    merged["open_15m"] = minute_of_day.between(570, 584)
    merged["open_30m"] = minute_of_day.between(570, 599)
    merged["open_60m"] = minute_of_day.between(570, 629)
    merged["midday_lull"] = minute_of_day.between(690, 809)
    merged["power_hour"] = minute_of_day.between(900, 959)
    merged["close_30m"] = minute_of_day.between(930, 959)
    date_parsed = pd.to_datetime(merged["date_et"], errors="coerce")
    weekday = date_parsed.dt.dayofweek
    merged["monday"] = weekday.eq(0)
    merged["friday"] = weekday.eq(4)
    return merged


def _parse_scalar(raw_value: str) -> Any:
    text = str(raw_value or "").strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in {"'", '"'}:
        text = text[1:-1]
    lowered = text.lower()
    if lowered in TRUTHY:
        return True
    if lowered in FALSY:
        return False
    try:
        return float(text)
    except ValueError:
        return text


def _format_literal(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return "'" + value.replace("'", "''") + "'"
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return f"{value:g}" if isinstance(value, float) else str(value)


def _build_bool_expr(field: str, value: bool) -> str:
    base = SPECIAL_BOOL_EXPRESSIONS.get(field, f"{field} = true")
    return base if value else f"NOT ({base})"


def _make_series_fn(field: str, op: str, value: Any) -> Callable[[pd.DataFrame], pd.Series]:
    def _numeric_compare(df: pd.DataFrame) -> pd.Series:
        series = pd.to_numeric(df[field], errors="coerce")
        if op == "<=":
            return series.notna() & (series <= value)
        if op == ">=":
            return series.notna() & (series >= value)
        if op == "<":
            return series.notna() & (series < value)
        if op == ">":
            return series.notna() & (series > value)
        if op in ("=", "=="):
            return series.notna() & (series == value)
        if op == "!=":
            return series.notna() & (series != value)
        raise ValueError(f"unsupported numeric operator: {op}")

    def _bool_compare(df: pd.DataFrame) -> pd.Series:
        series = _coerce_bool_series(df[field])
        if op in ("=", "=="):
            return series.eq(value).fillna(False)
        if op == "!=":
            return series.ne(value).fillna(False)
        raise ValueError(f"boolean field {field} only supports = and !=")

    def _string_compare(df: pd.DataFrame) -> pd.Series:
        series = df[field].astype(str).str.strip().str.lower()
        target = str(value).strip().lower()
        if op in ("=", "=="):
            return series.eq(target)
        if op == "!=":
            return series.ne(target)
        raise ValueError(f"string field {field} only supports = and !=")

    if isinstance(value, bool):
        return _bool_compare
    if isinstance(value, (int, float)):
        return _numeric_compare
    return _string_compare


def _parse_condition_line(line: str) -> ParsedCondition:
    raw = str(line or "").strip()
    match = COMPARISON_RE.match(raw)
    if match:
        field = match.group("field")
        op = match.group("op")
        value = _parse_scalar(match.group("value"))
    else:
        field = raw
        op = "="
        value = True
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", field):
        raise ValueError(f"invalid field in condition: {raw}")
    if isinstance(value, bool):
        expr = _build_bool_expr(field, value) if op in ("=", "==") else f"NOT ({_build_bool_expr(field, value)})"
    else:
        expr = f"{field} {op} {_format_literal(value)}"
    return ParsedCondition(
        field=field,
        op=op,
        value=value,
        raw=raw,
        expr=expr,
        fn=_make_series_fn(field, op, value),
    )


def _validate_conditions(df: pd.DataFrame, conditions: Sequence[ParsedCondition]) -> None:
    missing = sorted({cond.field for cond in conditions if cond.field not in df.columns})
    if missing:
        raise KeyError(f"unknown fields in condition set: {', '.join(missing)}")


def _evaluate_conditions(df: pd.DataFrame, conditions: Sequence[ParsedCondition]) -> pd.Series:
    mask = pd.Series(True, index=df.index)
    for cond in conditions:
        mask &= cond.fn(df).fillna(False)
    return mask


def _support_hash(index: pd.Index) -> str:
    values = index.to_numpy(dtype="int64", copy=False)
    return hashlib.md5(values.tobytes()).hexdigest()


def _candidate_key(base_conditions: Sequence[ParsedCondition], extras: Sequence[str]) -> str:
    base_slug = "_".join(_safe_slug(cond.raw) for cond in base_conditions)
    extra_slug = "_".join(_safe_slug(value) for value in extras)
    digest = hashlib.md5(("||".join(cond.raw for cond in base_conditions) + "||" + "||".join(extras)).encode("utf-8")).hexdigest()[:6]
    return f"adhoc_spawnmove_{base_slug[:32]}_{extra_slug[:40]}_{digest}"


def _passing_score(
    scored: Dict[str, object],
    *,
    min_oos: int,
    min_oos_precision: float,
    min_validation: float,
    min_holdout: float,
    min_unique_tickers: int,
    max_top_share: float,
) -> bool:
    return bool(
        scored["oos_n"] >= min_oos
        and scored["oos_hit"] >= min_oos_precision
        and scored["valid_hit"] >= min_validation
        and scored["hold_hit"] >= min_holdout
        and scored["unique_tickers"] >= min_unique_tickers
        and scored["top_share"] <= max_top_share
    )


def _score_frame(
    subset: pd.DataFrame,
    *,
    cut1: int,
    cut2: int,
    predicate: str,
    condition_lines: Sequence[str],
) -> Dict[str, object]:
    scored = _score_subset(subset, cut1, cut2)
    scored.update(
        {
            "predicate": predicate,
            "canonical": _canonical_sql(predicate),
            "condition_lines": list(condition_lines),
        }
    )
    return scored


def _find_additive_extensions(
    modern: pd.DataFrame,
    *,
    base_conditions: Sequence[ParsedCondition],
    cut1: int,
    cut2: int,
    args: argparse.Namespace,
) -> List[Dict[str, object]]:
    base_mask = _evaluate_conditions(modern, base_conditions)
    base_subset = modern.loc[base_mask].copy()
    if len(base_subset) < args.min_oos:
        return []
    used_fields = {cond.field for cond in base_conditions}
    clause_specs = _build_clause_specs(base_subset, excluded_fields=used_fields)
    support_seen: Dict[str, Dict[str, object]] = {}

    for clause in clause_specs:
        clause_mask = clause.fn(base_subset)
        selectivity = float(clause_mask.mean()) if len(clause_mask) else 0.0
        if selectivity <= 0.05 or selectivity >= 0.95:
            continue
        subset = base_subset.loc[clause_mask].copy()
        if len(subset) < args.min_oos:
            continue
        scored = _score_frame(
            subset,
            cut1=cut1,
            cut2=cut2,
            predicate=" AND ".join([cond.expr for cond in base_conditions] + [clause.expr]),
            condition_lines=[cond.raw for cond in base_conditions] + [clause.label],
        )
        scored.update(
            {
                "extra_fields": clause.field,
                "extra_labels": clause.label,
                "extra_clause_count": 1,
                "rule_id": _candidate_key(base_conditions, [clause.label]),
            }
        )
        support_seen[_support_hash(subset.index)] = scored

    single_rows = sorted(
        support_seen.values(),
        key=lambda item: (item["oos_n"], item["oos_hit"], item["wilson"]),
        reverse=True,
    )
    clause_lookup = {spec.label: spec for spec in clause_specs}
    clause_pool = single_rows[: args.top_clause_pool]

    for extra_k in range(2, max(2, args.expand_k) + 1):
        for combo in itertools.combinations(clause_pool, extra_k):
            combo_labels = [str(item["extra_labels"]) for item in combo]
            combo_specs = [clause_lookup[label] for label in combo_labels if label in clause_lookup]
            if len(combo_specs) != extra_k:
                continue
            combo_fields = [spec.field for spec in combo_specs]
            if len(set(combo_fields)) != len(combo_fields):
                continue
            combo_mask = pd.Series(True, index=base_subset.index)
            for spec in combo_specs:
                combo_mask &= spec.fn(base_subset)
            selectivity = float(combo_mask.mean()) if len(combo_mask) else 0.0
            if selectivity <= 0.05 or selectivity >= 0.95:
                continue
            subset = base_subset.loc[combo_mask].copy()
            if len(subset) < args.min_oos:
                continue
            predicates = [cond.expr for cond in base_conditions] + [spec.expr for spec in combo_specs]
            labels = [cond.raw for cond in base_conditions] + [spec.label for spec in combo_specs]
            scored = _score_frame(
                subset,
                cut1=cut1,
                cut2=cut2,
                predicate=" AND ".join(predicates),
                condition_lines=labels,
            )
            scored.update(
                {
                    "extra_fields": "|".join(sorted(combo_fields)),
                    "extra_labels": "|".join(spec.label for spec in combo_specs),
                    "extra_clause_count": extra_k,
                    "rule_id": _candidate_key(base_conditions, [spec.label for spec in combo_specs]),
                }
            )
            existing = support_seen.get(_support_hash(subset.index))
            if existing is None or (
                scored["oos_n"],
                scored["oos_hit"],
                scored["wilson"],
            ) > (
                existing["oos_n"],
                existing["oos_hit"],
                existing["wilson"],
            ):
                support_seen[_support_hash(subset.index)] = scored

    deduped: Dict[str, Dict[str, object]] = {}
    for row in support_seen.values():
        canonical = str(row["canonical"])
        existing = deduped.get(canonical)
        if existing is None or (
            row["oos_n"],
            row["oos_hit"],
            row["wilson"],
        ) > (
            existing["oos_n"],
            existing["oos_hit"],
            existing["wilson"],
        ):
            deduped[canonical] = row
    ordered = sorted(
        deduped.values(),
        key=lambda item: (item["oos_n"], item["oos_hit"], item["wilson"]),
        reverse=True,
    )
    return ordered


def _write_outputs(prefix: Path, base_result: Dict[str, object], extensions: Sequence[Dict[str, object]]) -> None:
    prefix.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "base_result": base_result,
        "extensions": list(extensions),
    }
    prefix.with_suffix(".json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    rows = pd.DataFrame(extensions)
    rows.to_csv(prefix.parent / f"{prefix.name}_extensions.csv", index=False)


def _print_score(title: str, scored: Dict[str, object], passed: bool) -> None:
    print(title)
    print(f"  predicate: {scored['predicate']}")
    print(
        "  oos={oos_n} hit={oos_hit:.4f} valid={valid_hit:.4f} hold={hold_hit:.4f} "
        "train_n={train_n} valid_n={valid_n} hold_n={hold_n} tickers={unique_tickers} top_share={top_share:.4f} pass_85={passed}".format(
            passed=str(passed).lower(),
            **scored,
        )
    )


def main() -> None:
    args = _parse_args()
    condition_lines = _read_condition_lines(args)
    parsed_conditions = [_parse_condition_line(line) for line in condition_lines]

    base_events = _load_base_events(Path(args.base_events))
    start_epoch, end_epoch = _epoch_bounds(args.modern_start, args.modern_end)
    base_events = base_events.loc[
        (base_events["ts_epoch"] >= start_epoch) & (base_events["ts_epoch"] < end_epoch)
    ].copy()
    if base_events.empty:
        raise ValueError("base events slice is empty after the modern date filter")
    enriched = _enrich_from_ca_fast(
        base_events,
        args,
        start_epoch=start_epoch,
        end_epoch=end_epoch,
    )
    modern = _modern_slice(enriched, args.modern_start, args.modern_end)
    modern["success"] = modern["best_ret"].fillna(0.0) >= 0.01
    _validate_conditions(modern, parsed_conditions)

    cut1, cut2 = _chrono_cuts(modern)
    base_mask = _evaluate_conditions(modern, parsed_conditions)
    base_subset = modern.loc[base_mask].copy()
    if base_subset.empty:
        raise ValueError("base condition set matched zero rows in the modern slice")

    base_result = _score_frame(
        base_subset,
        cut1=cut1,
        cut2=cut2,
        predicate=" AND ".join(cond.expr for cond in parsed_conditions),
        condition_lines=[cond.raw for cond in parsed_conditions],
    )
    base_result["row_count"] = int(len(base_subset))
    base_pass = _passing_score(
        base_result,
        min_oos=args.min_oos,
        min_oos_precision=args.min_oos_precision,
        min_validation=args.min_validation,
        min_holdout=args.min_holdout,
        min_unique_tickers=args.min_unique_tickers,
        max_top_share=args.max_top_share,
    )

    extensions = _find_additive_extensions(
        modern,
        base_conditions=parsed_conditions,
        cut1=cut1,
        cut2=cut2,
        args=args,
    )
    passing_extensions = [
        row
        for row in extensions
        if _passing_score(
            row,
            min_oos=args.min_oos,
            min_oos_precision=args.min_oos_precision,
            min_validation=args.min_validation,
            min_holdout=args.min_holdout,
            min_unique_tickers=args.min_unique_tickers,
            max_top_share=args.max_top_share,
        )
    ]

    print(f"Loaded modern slice rows: {len(modern)}")
    print(f"Base subset rows: {len(base_subset)}")
    _print_score("Base condition stack", base_result, base_pass)
    print()
    print(f"Passing additive extensions: {len(passing_extensions)}")
    for idx, row in enumerate(passing_extensions[: args.top_results], 1):
        print(
            f"{idx}. extras={row['extra_labels']} | "
            f"oos={row['oos_n']} hit={row['oos_hit']:.4f} valid={row['valid_hit']:.4f} "
            f"hold={row['hold_hit']:.4f} tickers={row['unique_tickers']} top_share={row['top_share']:.4f}"
        )
        print(f"   predicate: {row['predicate']}")

    if args.output_prefix:
        prefix = Path(args.output_prefix)
        _write_outputs(prefix, base_result, passing_extensions)
        print()
        print(f"Wrote outputs: {prefix.with_suffix('.json')} and {prefix.parent / (prefix.name + '_extensions.csv')}")


if __name__ == "__main__":
    main()
