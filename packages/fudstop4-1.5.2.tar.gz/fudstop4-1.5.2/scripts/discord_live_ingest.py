#!/usr/bin/env python3
"""
Continuously ingest live Discord room activity into discord_data and discord_messages.

This is additive to the existing site/bot layer:
- reads guild/channels/messages with the bot token
- normalizes payloads into explicit model classes
- upserts through PolygonOptions only
"""

from __future__ import annotations

import asyncio
import datetime
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import aiohttp
import pandas as pd
from dotenv import dotenv_values, load_dotenv

REPO_ROOT = Path(__file__).resolve().parents[1]
project_dir = str(REPO_ROOT)
if project_dir not in sys.path:
    sys.path.append(project_dir)

from fudstop4.apis.polygonio.polygon_options import PolygonOptions

for env_path in (
    REPO_ROOT / ".env",
    REPO_ROOT / "stock_market_site" / ".env",
    REPO_ROOT / "stock_market_site" / "app" / ".env",
):
    if env_path.exists():
        load_dotenv(env_path, override=False)

DISCORD_GUILD_ID = int(os.getenv("DISCORD_GUILD_ID", "1457091273243758614") or 1457091273243758614)
POLL_SECONDS = int(os.getenv("DISCORD_INGEST_POLL_SECONDS", "60") or 60)
CHANNEL_SAMPLE_SIZE = int(os.getenv("DISCORD_INGEST_CHANNEL_SAMPLE", "0") or 0)
MESSAGE_LIMIT = int(os.getenv("DISCORD_INGEST_MESSAGE_LIMIT", "3") or 3)
MESSAGE_UNIQUE_COLUMNS = ["channel", "content"]
REGISTRY_PATH = REPO_ROOT / "data" / "discord_confluence_registry.json"

db = PolygonOptions(database="fudstop3")


def bot_tokens() -> List[str]:
    values: List[str] = []
    for env_path in (
        REPO_ROOT / ".env",
        REPO_ROOT / "stock_market_site" / ".env",
        REPO_ROOT / "stock_market_site" / "app" / ".env",
    ):
        if not env_path.exists():
            continue
        env_values = dotenv_values(env_path)
        for key in ("BOT_TOKEN", "STOCK_MARKET_SENTINEL", "DISCORD_BOT_TOKEN", "AI"):
            token = str(env_values.get(key) or "").strip()
            if token and token not in values:
                values.append(token)
    for key in ("BOT_TOKEN", "STOCK_MARKET_SENTINEL", "DISCORD_BOT_TOKEN"):
        token = str(os.getenv(key) or "").strip()
        if token and token not in values:
            values.append(token)
    ai_token = str(os.getenv("AI") or "").strip()
    if ai_token and ai_token not in values:
        values.append(ai_token)
    return values


def snowflake_datetime(value: Any) -> Optional[datetime.datetime]:
    text = str(value or "").strip()
    if not text.isdigit():
        return None
    snowflake = int(text)
    if snowflake <= 0:
        return None
    discord_epoch_ms = 1420070400000
    timestamp_ms = (snowflake >> 22) + discord_epoch_ms
    try:
        return datetime.datetime.fromtimestamp(timestamp_ms / 1000, tz=datetime.timezone.utc)
    except (OSError, OverflowError, ValueError):
        return None


def parse_timestamp(value: Any) -> Optional[datetime.datetime]:
    if isinstance(value, datetime.datetime):
        return value if value.tzinfo else value.replace(tzinfo=datetime.timezone.utc)
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=datetime.timezone.utc)


def safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value).strip())
    except (TypeError, ValueError, AttributeError):
        return default


def trim_text(value: Any, limit: int = 220) -> str:
    text = " ".join(str(value or "").split())
    if len(text) <= limit:
        return text
    return f"{text[: max(0, limit - 3)].rstrip()}..."


def channel_type_key(value: Any) -> str:
    type_value = safe_int(getattr(value, "value", value), -1)
    if type_value in (0, 5):
        return "text"
    if type_value in (10, 11, 12):
        return "thread"
    if type_value in (15, 16):
        return "forum"
    if type_value == 4:
        return "category"
    return "other"


def message_preview(message: Dict[str, Any]) -> str:
    content = trim_text(message.get("content") or "", 240)
    if content:
        return content
    attachments = message.get("attachments") or []
    if isinstance(attachments, list) and attachments:
        label = "attachment" if len(attachments) == 1 else "attachments"
        return f"{len(attachments)} {label} shared"
    embeds = message.get("embeds") or []
    if isinstance(embeds, list) and embeds:
        first = embeds[0] if isinstance(embeds[0], dict) else {}
        return trim_text(first.get("title") or first.get("description") or "Embedded update", 240)
    return "New Discord activity"


class DiscordGuildSnapshot:
    def __init__(self, data: List[Dict[str, Any]]):
        self.guild_id = [safe_int(item.get("guild_id")) for item in data]
        self.guild_name = [str(item.get("guild_name") or "").strip() or "FUDSTOP Discord" for item in data]
        self.last_seen = [
            parse_timestamp(item.get("last_seen")) or datetime.datetime.now(datetime.timezone.utc)
            for item in data
        ]
        self.data_dict = {
            "guild_id": self.guild_id,
            "guild_name": self.guild_name,
            "last_seen": self.last_seen,
        }
        self.as_dataframe = pd.DataFrame(self.data_dict)


class DiscordMessages:
    def __init__(self, data: List[Dict[str, Any]]):
        self.message_id = [safe_int(item.get("message_id")) for item in data]
        self.message_author_id = [safe_int(item.get("message_author_id")) for item in data]
        self.channel_id = [safe_int(item.get("channel_id")) for item in data]
        self.channel = [str(item.get("channel") or "").strip() or "signals" for item in data]
        self.category = [str(item.get("category") or "").strip() or "Signals" for item in data]
        self.category_id = [safe_int(item.get("category_id")) for item in data]
        self.message_author = [str(item.get("message_author") or "").strip() or "FUDSTOP" for item in data]
        self.content = [trim_text(item.get("content") or "", 240) or "New Discord activity" for item in data]
        self.data_dict = {
            "message_id": self.message_id,
            "message_author_id": self.message_author_id,
            "channel_id": self.channel_id,
            "channel": self.channel,
            "category": self.category,
            "category_id": self.category_id,
            "message_author": self.message_author,
            "content": self.content,
        }
        self.as_dataframe = pd.DataFrame(self.data_dict)


async def fetch_discord_json(session: aiohttp.ClientSession, path: str) -> Any:
    tokens = bot_tokens()
    if not tokens:
        return None
    url = f"https://discord.com/api/v10{path}"
    for token in tokens:
        try:
            async with session.get(url, headers={"Authorization": f"Bot {token}"}) as response:
                if response.status == 200:
                    return await response.json()
                if response.status in {401, 403}:
                    continue
                if response.status == 404:
                    return None
        except Exception:
            continue
    return None


def shape_channels(raw_channels: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    categories: Dict[str, str] = {}

    for item in raw_channels or []:
        channel_id = safe_int(item.get("id"))
        if channel_id <= 0:
            continue
        type_key = channel_type_key(item.get("type"))
        record = {
            "id": channel_id,
            "name": str(item.get("name") or "").strip() or "unnamed-channel",
            "type_key": type_key,
            "parent_id": safe_int(item.get("parent_id")),
            "position": safe_int(item.get("position")),
            "topic": trim_text(item.get("topic") or "", 160),
            "last_message_id": safe_int(item.get("last_message_id")),
        }
        if type_key == "category":
            categories[str(channel_id)] = record["name"]
        records.append(record)

    for record in records:
        record["category"] = categories.get(str(record.get("parent_id") or ""), "Signals")
        record["category_id"] = safe_int(record.get("parent_id"))

    return records


def registry_thread_channels() -> List[Dict[str, Any]]:
    try:
        payload = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    except Exception:
        return []
    boards = payload.get("boards") if isinstance(payload, dict) else {}
    if not isinstance(boards, dict):
        return []

    rows: List[Dict[str, Any]] = []
    seen_ids: set[int] = set()
    for board in boards.values():
        if not isinstance(board, dict):
            continue
        parent_id = safe_int(board.get("forum_channel_id"))
        category = (
            str(board.get("family_label") or "").strip()
            or str(board.get("category_name") or "").strip()
            or "Signals"
        )
        for meta, default_name, default_topic in (
            (
                board.get("live_thread") if isinstance(board.get("live_thread"), dict) else {},
                "live-feed",
                "Live sync thread",
            ),
            (
                board.get("confluence_tracker") if isinstance(board.get("confluence_tracker"), dict) else {},
                "confluence-tracker",
                str(board.get("confluence_label") or "").strip() or "Confluence tracker",
            ),
        ):
            channel_id = safe_int((meta or {}).get("id"))
            if channel_id <= 0 or channel_id in seen_ids:
                continue
            seen_ids.add(channel_id)
            rows.append(
                {
                    "id": channel_id,
                    "name": str((meta or {}).get("name") or default_name).strip() or default_name,
                    "type_key": "thread",
                    "parent_id": parent_id,
                    "position": 0,
                    "topic": trim_text((meta or {}).get("label") or default_topic, 160),
                    "last_message_id": 0,
                    "category": category,
                    "category_id": parent_id,
                }
            )
    return rows


async def fetch_channel_messages(
    session: aiohttp.ClientSession,
    channel: Dict[str, Any],
) -> List[Dict[str, Any]]:
    channel_id = safe_int(channel.get("id"))
    if channel_id <= 0:
        return []
    payload = await fetch_discord_json(session, f"/channels/{channel_id}/messages?limit={max(1, min(MESSAGE_LIMIT, 10))}")
    if not isinstance(payload, list):
        return []

    rows: List[Dict[str, Any]] = []
    for message in payload:
        message_id = safe_int(message.get("id"))
        if message_id <= 0:
            continue
        author = message.get("author") or {}
        author_name = (
            str(author.get("global_name") or "").strip()
            or str(author.get("username") or "").strip()
            or "FUDSTOP"
        )
        rows.append(
            {
                "message_id": message_id,
                "channel_id": channel_id,
                "channel": channel.get("name"),
                "category": channel.get("category"),
                "category_id": safe_int(channel.get("category_id")),
                "message_author": author_name,
                "message_author_id": safe_int(author.get("id")),
                "content": message_preview(message),
            }
        )
    return rows


async def ingest_once() -> Dict[str, int]:
    timeout = aiohttp.ClientTimeout(total=20)
    connector = aiohttp.TCPConnector(limit=32, ssl=False)
    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        guild_payload = await fetch_discord_json(session, f"/guilds/{DISCORD_GUILD_ID}")
        channels_payload = await fetch_discord_json(session, f"/guilds/{DISCORD_GUILD_ID}/channels")

        guild_name = str((guild_payload or {}).get("name") or "FUDSTOP Discord").strip() or "FUDSTOP Discord"
        channels = shape_channels(channels_payload if isinstance(channels_payload, list) else [])
        existing_channel_ids = {safe_int(channel.get("id")) for channel in channels}
        for thread_channel in registry_thread_channels():
            channel_id = safe_int(thread_channel.get("id"))
            if channel_id <= 0 or channel_id in existing_channel_ids:
                continue
            channels.append(thread_channel)
            existing_channel_ids.add(channel_id)
        visible_channels = [channel for channel in channels if channel.get("type_key") != "category"]
        text_channels = [channel for channel in visible_channels if channel.get("type_key") in {"text", "forum", "thread"}]

        snapshot = DiscordGuildSnapshot(
            [
                {
                    "guild_id": DISCORD_GUILD_ID,
                    "guild_name": guild_name,
                    "channel_count": len(visible_channels),
                    "category_count": len([channel for channel in channels if channel.get("type_key") == "category"]),
                    "text_channel_count": len(text_channels),
                    "last_seen": datetime.datetime.now(datetime.timezone.utc),
                }
            ]
        )
        await db.batch_upsert_dataframe(snapshot.as_dataframe, table_name="discord_data", unique_columns=["guild_id"])

        ranked_channels = sorted(
            text_channels,
            key=lambda channel: (
                snowflake_datetime(channel.get("last_message_id"))
                or datetime.datetime.min.replace(tzinfo=datetime.timezone.utc)
            ),
            reverse=True,
        )
        if CHANNEL_SAMPLE_SIZE > 0:
            focus_channels = ranked_channels[:CHANNEL_SAMPLE_SIZE]
        else:
            focus_channels = ranked_channels

        message_batches = await asyncio.gather(
            *[fetch_channel_messages(session, channel) for channel in focus_channels],
            return_exceptions=True,
        )
        rows: List[Dict[str, Any]] = []
        for batch in message_batches:
            if isinstance(batch, Exception):
                continue
            rows.extend(batch)

        if rows:
            messages = DiscordMessages(rows)
            message_df = (
                messages.as_dataframe
                .sort_values(["channel", "content", "message_id"])
                .drop_duplicates(subset=MESSAGE_UNIQUE_COLUMNS, keep="last")
                .reset_index(drop=True)
            )
            # Match the existing live-site table constraint instead of forcing a new schema path.
            await db.batch_upsert_dataframe(
                message_df,
                table_name="discord_messages",
                unique_columns=MESSAGE_UNIQUE_COLUMNS,
            )

        return {
            "channels": len(visible_channels),
            "focus_channels": len(focus_channels),
            "messages": len(rows),
        }


async def main() -> None:
    if not bot_tokens():
        raise RuntimeError("Discord bot token not found in environment.")

    await db.connect()
    try:
        while True:
            started = time.monotonic()
            try:
                result = await ingest_once()
                print(
                    "[discord_live_ingest] "
                    f"channels={result['channels']} focus={result['focus_channels']} messages={result['messages']}"
                )
            except Exception as exc:
                print(f"[discord_live_ingest] run failed: {exc}")
            elapsed = time.monotonic() - started
            await asyncio.sleep(max(5, POLL_SECONDS - elapsed))
    finally:
        await db.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
