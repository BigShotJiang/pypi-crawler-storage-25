
import sys
import os
from pathlib import Path
project_dir = str(Path(__file__).resolve().parents[1])
if project_dir not in sys.path:
    sys.path.append(project_dir)
import asyncio
import numpy as np
from dotenv import load_dotenv
from polars import datetime
load_dotenv()
from UTILS.helpers import generate_webull_headers
import aiohttp
from datetime import datetime, timezone, timedelta
from fudstop4.apis.webull.webull_trading import WebullTrading
from fudstop4.apis.polygonio.polygon_options import PolygonOptions
opts = PolygonOptions()
from fudstop4._markets.list_sets.ticker_lists import most_active_tickers
import pandas as pd
trading = WebullTrading()
from UTILS.confluence import score_options_flow

class CallPutProfiles:
    def __init__(self, ticker, callPutProfiles):

        self.ticker = ticker
        self.strikes = [i.get('strikes') for i in callPutProfiles]
        self.calls = [i.get('calls') for i in callPutProfiles]
        self.calls_ratio = [i.get('callsRatio') for i in callPutProfiles]
        self.puts = [i.get('puts') for i in callPutProfiles]
        self.puts_ratio = [i.get('putsRatio') for i in callPutProfiles]
        self.total_volume = [i.get('totalVolume') for i in callPutProfiles]


        self.data_dict = { 
            'strike': self.strikes,
            'calls': self.calls,
            'calls_ratio': self.calls_ratio,
            'puts': self.puts,
            'puts_ratio': self.puts_ratio,
            'total_volume': self.total_volume,
        }

        self.as_dataframe = pd.DataFrame(self.data_dict)
        self.as_dataframe['ticker'] = self.ticker


def clamp_int32(value) -> int:
    try:
        numeric = int(round(float(value)))
    except (TypeError, ValueError):
        return 0
    return max(min(numeric, 2_147_483_647), -2_147_483_648)


def summarize_cp_profile_row(
    ticker: str,
    calls: float,
    puts: float,
    call_volume: float,
    put_volume: float,
    total_volume: float,
    total_oi: float,
    strike,
    last_timestamp,
) -> pd.DataFrame:
    calls_ratio = (calls / total_oi) if total_oi else 0.0
    puts_ratio = (puts / total_oi) if total_oi else 0.0
    cp_diff = calls - puts
    denom = abs(calls) + abs(puts)
    cp_skew = (cp_diff / denom) if denom else np.nan
    flow_score = score_options_flow(
        call_volume=float(call_volume),
        put_volume=float(put_volume),
        call_oi=float(calls),
        put_oi=float(puts),
        label="cp_profile",
    )
    payload = {
        "ticker": [ticker],
        "strikes": [str(strike) if strike is not None else ""],
        "strike": [str(strike) if strike is not None else ""],
        "calls": [clamp_int32(calls)],
        "callsRatio": [calls_ratio],
        "calls_ratio": [calls_ratio],
        "puts": [clamp_int32(puts)],
        "putsRatio": [puts_ratio],
        "puts_ratio": [puts_ratio],
        "totalVolume": [clamp_int32(total_volume)],
        "total_volume": [clamp_int32(total_volume)],
        "total_oi": [clamp_int32(total_oi)],
        "last_timestamp": [last_timestamp],
        "cp_diff": [clamp_int32(cp_diff)],
        "cp_skew": [cp_skew],
        "cp_dominant_side": [
            "call" if cp_diff > 0 else "put" if cp_diff < 0 else "neutral"
        ],
    }
    df = pd.DataFrame(payload)
    for col, value in flow_score.to_columns("cp_flow").items():
        df[col] = value
    return df


async def build_local_cp_profiles(ticker: str) -> pd.DataFrame:
    query = f"""
        SELECT strike, call_put, oi, volume, insertion_timestamp
        FROM wb_opts
        WHERE ticker = '{ticker}'
          AND expiry >= CURRENT_DATE
    """
    rows = await opts.fetch(query)
    if not rows:
        return pd.DataFrame()

    df = pd.DataFrame([dict(row) for row in rows])
    if df.empty:
        return df

    df["strike"] = pd.to_numeric(df["strike"], errors="coerce")
    df["oi"] = pd.to_numeric(df["oi"], errors="coerce").fillna(0)
    df["volume"] = pd.to_numeric(df["volume"], errors="coerce").fillna(0)
    df["call_put"] = df["call_put"].astype(str).str.lower()
    df = df.dropna(subset=["strike"])
    if df.empty:
        return pd.DataFrame()

    grouped = (
        df.groupby(["strike", "call_put"], as_index=False)[["oi", "volume"]]
        .sum()
    )
    pivot = grouped.pivot(index="strike", columns="call_put", values="oi").fillna(0)
    volume_pivot = grouped.pivot(index="strike", columns="call_put", values="volume").fillna(0)

    calls = pivot.get("call", pd.Series(0, index=pivot.index))
    puts = pivot.get("put", pd.Series(0, index=pivot.index))
    call_volume = volume_pivot.get("call", pd.Series(0, index=volume_pivot.index))
    put_volume = volume_pivot.get("put", pd.Series(0, index=volume_pivot.index))

    total_oi = float(calls.sum() + puts.sum())
    last_ts = pd.to_datetime(df["insertion_timestamp"], errors="coerce").max()
    total_volume = float(call_volume.sum() + put_volume.sum())
    dominant_volume = (call_volume + put_volume)
    dominant_strike = dominant_volume.idxmax() if not dominant_volume.empty else None
    return summarize_cp_profile_row(
        ticker=ticker,
        calls=float(calls.sum()),
        puts=float(puts.sum()),
        call_volume=float(call_volume.sum()),
        put_volume=float(put_volume.sum()),
        total_volume=total_volume,
        total_oi=total_oi,
        strike=dominant_strike,
        last_timestamp=last_ts,
    )

async def main(ticker):
    ticker_id = trading.ticker_to_id_map.get(ticker)
    if ticker_id is None:
        return
    url = f"https://quotes-gw.webullfintech.com/api/statistic/option/queryCallPutRatio?supportBroker=8&tickerId={ticker_id}&count=1000"

    async with aiohttp.ClientSession(
        headers=generate_webull_headers(access_token=os.environ.get("ACCESS_TOKEN"))
    ) as session:
        try:
            async with session.get(url) as resp:
                if resp.status != 200:
                    print(f"[option_stats] {ticker} skipped: status={resp.status}")
                    cp_profiles = await build_local_cp_profiles(ticker)
                    if not cp_profiles.empty:
                        await opts.batch_upsert_dataframe(cp_profiles, 'cp_profiles', unique_columns=['ticker'])
                    return
                data = await resp.json(content_type=None)
        except Exception as exc:
            print(f"[option_stats] {ticker} request failed: {exc}")
            cp_profiles = await build_local_cp_profiles(ticker)
            if not cp_profiles.empty:
                await opts.batch_upsert_dataframe(cp_profiles, 'cp_profiles', unique_columns=['ticker'])
            return

    lastTimestamp = data.get('lastTimestamp')
    if lastTimestamp is None:
        cp_profiles = await build_local_cp_profiles(ticker)
        if not cp_profiles.empty:
            await opts.batch_upsert_dataframe(cp_profiles, 'cp_profiles', unique_columns=['ticker'])
        return

    lastTimestamp = datetime.fromtimestamp(lastTimestamp / 1000, tz=timezone.utc)
    eastern_offset = timedelta(hours=-4)
    lastTimestamp = (lastTimestamp + eastern_offset).strftime("%Y-%m-%d %H:%M:%S")

    callPutFlow = data.get('callPutFlow') or {}
    callPutProfiles = data.get('callPutProfiles') or []
    if not callPutProfiles:
        cp_profiles = await build_local_cp_profiles(ticker)
        if not cp_profiles.empty:
            await opts.batch_upsert_dataframe(cp_profiles, 'cp_profiles', unique_columns=['ticker', 'strike'])
        return

    totalVolume = callPutFlow.get('totalVolume', None)
    totalOpenInterest = callPutFlow.get('totalOpenInterest', None)
    callAsk = callPutFlow.get('callAsk', None)
    putAsk = callPutFlow.get('putAsk', None)
    callBid = callPutFlow.get('callBid', None)
    putBid = callPutFlow.get('putBid', None)
    callNeutral = callPutFlow.get('callNeutral', None)
    putNeutral = callPutFlow.get('putNeutral', None)
    callTotalVolume = callPutFlow.get('callTotalVolume', None)
    putTotalVolume = callPutFlow.get('putTotalVolume', None)
    callAskRatio = callPutFlow.get('callAskRatio', None)
    putAskRatio = callPutFlow.get('putAskRatio', None)
    callBidRatio = callPutFlow.get('callBidRatio', None)
    putBidRatio = callPutFlow.get('putBidRatio', None)
    callNeutralRatio = callPutFlow.get('callNeutralRatio', None)
    putNeutralRatio = callPutFlow.get('putNeutralRatio', None)

    cp_profiles = CallPutProfiles(ticker=ticker, callPutProfiles=callPutProfiles).as_dataframe
    cp_profiles['total_oi'] = totalOpenInterest
    cp_profiles['last_timestamp'] = lastTimestamp
    cp_profiles['call_ask'] = callAsk
    cp_profiles['put_ask'] = putAsk
    cp_profiles['call_bid'] = callBid
    cp_profiles['put_bid'] = putBid
    cp_profiles['call_neutral'] = callNeutral
    cp_profiles['put_neutral'] = putNeutral
    cp_profiles['call_total_volume'] = callTotalVolume
    cp_profiles['put_total_volume'] = putTotalVolume
    cp_profiles['call_ask_ratio'] = callAskRatio
    cp_profiles['put_ask_ratio'] = putAskRatio
    cp_profiles['call_bid_ratio'] = callBidRatio
    cp_profiles['put_bid_ratio'] = putBidRatio
    cp_profiles['call_neutral_ratio'] = callNeutralRatio
    cp_profiles['put_neutral_ratio'] = putNeutralRatio
    cp_profiles['total_volume'] = totalVolume
    cp_profiles['ticker'] = ticker
    cp_profiles["calls"] = pd.to_numeric(cp_profiles["calls"], errors="coerce")
    cp_profiles["puts"] = pd.to_numeric(cp_profiles["puts"], errors="coerce")
    cp_profiles["cp_diff"] = cp_profiles["calls"].fillna(0) - cp_profiles["puts"].fillna(0)
    _den = cp_profiles["calls"].abs().fillna(0) + cp_profiles["puts"].abs().fillna(0)
    cp_profiles["cp_skew"] = np.where(_den > 0, cp_profiles["cp_diff"] / _den, np.nan)
    cp_profiles["cp_dominant_side"] = np.where(
        cp_profiles["cp_diff"] > 0, "call",
        np.where(cp_profiles["cp_diff"] < 0, "put", "neutral")
    )

    flow_score = score_options_flow(
        call_volume=callTotalVolume or 0,
        put_volume=putTotalVolume or 0,
        call_oi=cp_profiles["calls"].sum(skipna=True),
        put_oi=cp_profiles["puts"].sum(skipna=True),
        label="cp_profile",
    )
    for col, value in flow_score.to_columns("cp_flow").items():
        cp_profiles[col] = value

    calls_sum = float(cp_profiles["calls"].sum(skipna=True))
    puts_sum = float(cp_profiles["puts"].sum(skipna=True))
    total_volume_sum = float(cp_profiles["total_volume"].sum(skipna=True))
    dominant_strike = None
    if not cp_profiles.empty and "total_volume" in cp_profiles.columns:
        idx = cp_profiles["total_volume"].astype(float).idxmax()
        if pd.notnull(idx):
            dominant_strike = cp_profiles.loc[idx, "strike"]
    summary_df = summarize_cp_profile_row(
        ticker=ticker,
        calls=calls_sum,
        puts=puts_sum,
        call_volume=float(callTotalVolume or 0),
        put_volume=float(putTotalVolume or 0),
        total_volume=total_volume_sum,
        total_oi=float(totalOpenInterest or 0),
        strike=dominant_strike,
        last_timestamp=lastTimestamp,
    )
    summary_df["call_ask"] = callAsk
    summary_df["put_ask"] = putAsk
    summary_df["call_bid"] = callBid
    summary_df["put_bid"] = putBid
    summary_df["call_neutral"] = callNeutral
    summary_df["put_neutral"] = putNeutral
    summary_df["call_total_volume"] = callTotalVolume
    summary_df["put_total_volume"] = putTotalVolume
    summary_df["call_ask_ratio"] = callAskRatio
    summary_df["put_ask_ratio"] = putAskRatio
    summary_df["call_bid_ratio"] = callBidRatio
    summary_df["put_bid_ratio"] = putBidRatio
    summary_df["call_neutral_ratio"] = callNeutralRatio
    summary_df["put_neutral_ratio"] = putNeutralRatio
    await opts.batch_upsert_dataframe(summary_df, 'cp_profiles', unique_columns=['ticker'])

async def run_main():
    await opts.connect()
    while True:
        # Batch the tickers into chunks of 5
        for i in range(0, len(most_active_tickers), 5):
            batch = most_active_tickers[i:i+5]

            # Run up to 5 concurrently
            tasks = [asyncio.create_task(main(ticker=t)) for t in batch]
            await asyncio.gather(*tasks, return_exceptions=True)

        # optional: small sleep between cycles
        await asyncio.sleep(30)  # prevent hammering the API or CPU


if __name__ == "__main__":
    asyncio.run(run_main())
