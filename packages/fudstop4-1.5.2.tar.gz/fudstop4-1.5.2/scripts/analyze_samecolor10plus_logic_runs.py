from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timedelta
from itertools import combinations
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

import pandas as pd

from search_consecutive_color_prerun_patterns import (
    add_derived_columns,
    build_condition_specs,
    db_connect,
    load_env_defaults,
    parse_date,
    resolve_tickers,
    wilson_lower_bound,
)


MARKET_TZ = ZoneInfo("America/New_York")
REPO_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = REPO_ROOT / "LOGIC_RUNS"
RUN_DATE = datetime.now(tz=MARKET_TZ).strftime("%Y%m%d")
DEFAULT_START_DATE = "2025-12-01"
DEFAULT_END_DATE = "2026-04-14"
DEFAULT_BASE_TIMESPAN = "m1"
DEFAULT_UNIVERSE = "most_active"
DEFAULT_MIN_RUN = 10
DEFAULT_LEAD_START = 1
DEFAULT_LEAD_END = 3
DEFAULT_VAL_DAYS = 8
DEFAULT_MIN_N = 100
DEFAULT_MIN_VAL_N = 20
DEFAULT_MIN_TICKERS = 10
DEFAULT_MIN_VAL_TICKERS = 3

BULL_FOCUS = [
    "candle_red",
    "prev_bar_red",
    "prev3_red_ge_2",
    "red_streak_ge_2",
    "red_streak_ge_3",
    "close_pos_lo",
    "bb_lower",
    "full_below_lower",
    "vwap_down_10bp",
    "vwap_cross_up",
    "cmo_le_n20",
    "stoch_le_10",
    "mfi_le_20",
    "ema_stack_bull",
    "rvol_ge_1_50",
    "volume_confirm",
    "bb_width_ge_0_05",
    "gap_down",
]

BEAR_FOCUS = [
    "candle_green",
    "prev_bar_green",
    "prev3_green_ge_2",
    "green_streak_ge_2",
    "green_streak_ge_3",
    "close_pos_hi",
    "bb_upper",
    "full_above_upper",
    "vwap_up_10bp",
    "vwap_cross_dn",
    "cmo_ge_20",
    "stoch_ge_90",
    "mfi_ge_80",
    "ema_stack_bear",
    "rvol_ge_1_50",
    "volume_confirm",
    "bb_width_ge_0_05",
    "gap_up",
]


@dataclass(frozen=True)
class MetricRow:
    conditions: str
    n: int
    ticker_count: int
    hit: float
    lift: float
    train_n: int
    train_hit: float
    val_n: int
    val_ticker_count: int
    val_hit: float
    val_lift: float
    wilson_lb: float
    val_wilson_lb: float
    avg_run_len: float
    avg_lead: float
    lead_counts: dict[str, int]

    def to_dict(self) -> dict[str, Any]:
        return {
            "conditions": self.conditions,
            "n": self.n,
            "ticker_count": self.ticker_count,
            "hit": round(self.hit, 4),
            "lift": round(self.lift, 2),
            "train_n": self.train_n,
            "train_hit": round(self.train_hit, 4),
            "val_n": self.val_n,
            "val_ticker_count": self.val_ticker_count,
            "val_hit": round(self.val_hit, 4),
            "val_lift": round(self.val_lift, 2),
            "wilson_lb": round(self.wilson_lb, 4),
            "val_wilson_lb": round(self.val_wilson_lb, 4),
            "avg_run_len": round(self.avg_run_len, 2),
            "avg_lead": round(self.avg_lead, 2),
            "lead_counts": self.lead_counts,
        }


def sql_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def et_epoch(day: datetime.date, hour: int = 0, minute: int = 0) -> int:
    return int(datetime(day.year, day.month, day.day, hour, minute, tzinfo=MARKET_TZ).timestamp())


def fetch_m1_frame(
    *,
    tickers: list[str],
    start_date: str,
    end_date: str,
) -> pd.DataFrame:
    start_epoch = et_epoch(parse_date(start_date))
    end_epoch = et_epoch(parse_date(end_date) + timedelta(days=1))
    def build_query(chunk: list[str]) -> str:
        ticker_sql = ""
        if chunk:
            ticker_sql = f"\n          AND UPPER(BTRIM(ticker)) IN ({', '.join(sql_quote(value) for value in chunk)})"
        return f"""
            SELECT
                UPPER(BTRIM(ticker)) AS ticker,
                ts::bigint AS ts_epoch,
                date_et,
                time_et,
                timespan,
                o,
                c,
                h,
                l,
                v,
                prev_close,
                change_pct,
                candle_green,
                candle_red,
                body_pct,
                hl_range_pct,
                upper_wick,
                lower_wick,
                wick_ratio,
                oc_pct,
                gap_pct,
                is_gap,
                is_inside_bar,
                rsi,
                td_buy_count,
                td_sell_count,
                macd_cross_up,
                macd_cross_dn,
                bb_width,
                bb_close_outside_lower,
                bb_close_outside_upper,
                candle_completely_below_lower,
                candle_completely_above_upper,
                rvol,
                atr_pct,
                chop,
                vwap_dist_pct,
                vwap_cross_up,
                vwap_cross_dn,
                stoch_rsi_k,
                stoch_rsi_d,
                mfi,
                cmo,
                roc,
                trix,
                ultimate_osc,
                adx,
                trend_regime,
                volume_confirm,
                squeeze_off,
                adx_strong,
                di_bull,
                di_bear,
                macd_bull,
                macd_bear,
                tsi_bull,
                tsi_bear,
                ema_stack_bull,
                ema_stack_bear,
                momentum_confirm_bull,
                momentum_confirm_bear
            FROM ca
            WHERE timespan = 'm1'
              AND session = 'regular'
              AND bb_width IS NOT NULL
              AND ts::bigint >= {int(start_epoch)}
              AND ts::bigint < {int(end_epoch)}
              {ticker_sql}
        """
    conn = db_connect(load_env_defaults())
    try:
        frames: list[pd.DataFrame] = []
        chunk_size = 10
        ticker_chunks = [tickers[idx : idx + chunk_size] for idx in range(0, len(tickers), chunk_size)] or [[]]
        for chunk_idx, chunk in enumerate(ticker_chunks, start=1):
            print(f"fetch chunk {chunk_idx}/{len(ticker_chunks)} ({len(chunk)} tickers)", flush=True)
            frames.append(pd.read_sql_query(build_query(chunk), conn))
    finally:
        conn.close()
    frame = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
    if frame.empty:
        return frame
    frame = frame.sort_values(["ticker", "ts_epoch"]).drop_duplicates(["ticker", "ts_epoch"], keep="last")
    return frame.reset_index(drop=True)


def format_et(ts_epoch: int) -> str:
    return datetime.fromtimestamp(int(ts_epoch), tz=MARKET_TZ).strftime("%Y/%m/%d %H:%M:%S")


def extract_same_color_runs(frame: pd.DataFrame, min_run: int) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for (ticker, date_value), group in frame.groupby(["ticker", "date_et"], sort=False):
        ordered = group.sort_values("ts_epoch").reset_index(drop=True)
        current_side: str | None = None
        start_idx = 0
        prev_ts: int | None = None
        for idx, item in ordered.iterrows():
            side = "bull" if bool(item.get("candle_green")) else "bear" if bool(item.get("candle_red")) else None
            ts_epoch = int(item["ts_epoch"])
            contiguous = (
                current_side is not None
                and side == current_side
                and prev_ts is not None
                and (ts_epoch - prev_ts) == 60
            )
            if current_side is None:
                if side is not None:
                    current_side = side
                    start_idx = idx
            elif not contiguous:
                run = ordered.iloc[start_idx:idx]
                if current_side is not None and len(run) >= min_run:
                    rows.append(
                        {
                            "ticker": ticker,
                            "date_et": str(date_value),
                            "direction": current_side,
                            "run_length": int(len(run)),
                            "run_start_et": format_et(int(run.iloc[0]["ts_epoch"])),
                            "run_end_et": format_et(int(run.iloc[-1]["ts_epoch"])),
                            "run_start_epoch": int(run.iloc[0]["ts_epoch"]),
                            "run_end_epoch": int(run.iloc[-1]["ts_epoch"]),
                        }
                    )
                current_side = side
                start_idx = idx
            prev_ts = ts_epoch
        if current_side is not None:
            run = ordered.iloc[start_idx:]
            if len(run) >= min_run:
                rows.append(
                    {
                        "ticker": ticker,
                        "date_et": str(date_value),
                        "direction": current_side,
                        "run_length": int(len(run)),
                        "run_start_et": format_et(int(run.iloc[0]["ts_epoch"])),
                        "run_end_et": format_et(int(run.iloc[-1]["ts_epoch"])),
                        "run_start_epoch": int(run.iloc[0]["ts_epoch"]),
                        "run_end_epoch": int(run.iloc[-1]["ts_epoch"]),
                    }
                )
    if not rows:
        return pd.DataFrame(
            columns=[
                "ticker",
                "date_et",
                "direction",
                "run_length",
                "run_start_et",
                "run_end_et",
                "run_start_epoch",
                "run_end_epoch",
            ]
        )
    return pd.DataFrame(rows).sort_values(["run_start_epoch", "ticker"]).reset_index(drop=True)


def annotate_prerun_hits(
    frame: pd.DataFrame,
    *,
    min_run: int,
    lead_start: int,
    lead_end: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    df = frame.copy()
    defaults: dict[str, Any] = {
        "bull_hit": False,
        "bear_hit": False,
        "bull_lead": 0,
        "bear_lead": 0,
        "bull_run_len": 0,
        "bear_run_len": 0,
    }
    for key, value in defaults.items():
        df[key] = value
    runs: list[dict[str, Any]] = []
    for (ticker, date_value), group in df.groupby(["ticker", "date_et"], sort=False):
        ordered = group.sort_values("ts_epoch").reset_index()
        current_side: str | None = None
        start_idx = 0
        prev_ts: int | None = None

        def finalize(end_exclusive: int) -> None:
            nonlocal current_side, start_idx
            if current_side is None:
                return
            run = ordered.iloc[start_idx:end_exclusive]
            if len(run) < min_run:
                return
            runs.append(
                {
                    "ticker": ticker,
                    "date_et": str(date_value),
                    "direction": current_side,
                    "run_length": int(len(run)),
                    "run_start_et": format_et(int(run.iloc[0]["ts_epoch"])),
                    "run_end_et": format_et(int(run.iloc[-1]["ts_epoch"])),
                    "run_start_epoch": int(run.iloc[0]["ts_epoch"]),
                    "run_end_epoch": int(run.iloc[-1]["ts_epoch"]),
                }
            )
            prefix = "bull" if current_side == "bull" else "bear"
            for lead in range(lead_start, lead_end + 1):
                signal_idx = start_idx - lead
                if signal_idx < 0:
                    continue
                frame_index = int(ordered.iloc[signal_idx]["index"])
                current_lead = int(df.at[frame_index, f"{prefix}_lead"])
                if current_lead and current_lead <= lead:
                    continue
                df.at[frame_index, f"{prefix}_hit"] = True
                df.at[frame_index, f"{prefix}_lead"] = int(lead)
                df.at[frame_index, f"{prefix}_run_len"] = int(len(run))

        for idx, item in ordered.iterrows():
            side = "bull" if bool(item.get("candle_green")) else "bear" if bool(item.get("candle_red")) else None
            ts_epoch = int(item["ts_epoch"])
            contiguous = (
                current_side is not None
                and side == current_side
                and prev_ts is not None
                and (ts_epoch - prev_ts) == 60
            )
            if current_side is None:
                if side is not None:
                    current_side = side
                    start_idx = idx
            elif not contiguous:
                finalize(idx)
                current_side = side
                start_idx = idx
            prev_ts = ts_epoch
        finalize(len(ordered))
    run_frame = pd.DataFrame(runs)
    if run_frame.empty:
        run_frame = pd.DataFrame(
            columns=[
                "ticker",
                "date_et",
                "direction",
                "run_length",
                "run_start_et",
                "run_end_et",
                "run_start_epoch",
                "run_end_epoch",
            ]
        )
    else:
        run_frame = run_frame.sort_values(["run_start_epoch", "ticker"]).reset_index(drop=True)
    return df, run_frame


def build_event_summary(runs: pd.DataFrame, direction: str) -> dict[str, Any]:
    side_runs = runs.loc[runs["direction"] == direction].copy()
    if side_runs.empty:
        return {
            "direction": direction,
            "run_count": 0,
            "ticker_count": 0,
            "avg_run_len": 0.0,
            "max_run_len": 0,
            "range_start_et": "",
            "range_end_et": "",
            "top_tickers": [],
            "top_dates": [],
        }
    top_tickers = [
        {"ticker": str(ticker), "count": int(count)}
        for ticker, count in side_runs["ticker"].value_counts().head(10).items()
    ]
    top_dates = [
        {"date_et": str(date_value), "count": int(count)}
        for date_value, count in side_runs["date_et"].astype(str).value_counts().head(10).items()
    ]
    return {
        "direction": direction,
        "run_count": int(len(side_runs)),
        "ticker_count": int(side_runs["ticker"].nunique()),
        "avg_run_len": round(float(side_runs["run_length"].mean()), 2),
        "max_run_len": int(side_runs["run_length"].max()),
        "range_start_et": str(side_runs["run_start_et"].min()),
        "range_end_et": str(side_runs["run_end_et"].max()),
        "top_tickers": top_tickers,
        "top_dates": top_dates,
    }


def select_focus_specs(frame: pd.DataFrame, side: str, focus_names: list[str]) -> list[Any]:
    spec_lookup = {
        spec.name: spec
        for spec in build_condition_specs(frame, side, context_prefixes=[], logical_core_only=True)
    }
    return [spec_lookup[name] for name in focus_names if name in spec_lookup]


def build_metric_row(
    *,
    frame: pd.DataFrame,
    target: pd.Series,
    base_hit: float,
    train_mask: pd.Series,
    val_mask: pd.Series,
    mask: pd.Series,
    label: str,
) -> MetricRow | None:
    n_total = int(mask.sum())
    if n_total < DEFAULT_MIN_N:
        return None
    tickers = frame["ticker"].astype(str)
    ticker_count = int(tickers[mask].nunique())
    if ticker_count < DEFAULT_MIN_TICKERS:
        return None
    train_n = int((mask & train_mask).sum())
    val_n = int((mask & val_mask).sum())
    if train_n <= 0 or val_n < DEFAULT_MIN_VAL_N:
        return None
    val_ticker_count = int(tickers[mask & val_mask].nunique())
    if val_ticker_count < DEFAULT_MIN_VAL_TICKERS:
        return None
    hit_count = int((mask & target).sum())
    train_hit_count = int((mask & train_mask & target).sum())
    val_hit_count = int((mask & val_mask & target).sum())
    hit = hit_count / float(n_total) if n_total else 0.0
    train_hit = train_hit_count / float(train_n) if train_n else 0.0
    val_hit = val_hit_count / float(val_n) if val_n else 0.0
    success_mask = mask & target
    run_lengths = pd.to_numeric(
        frame.loc[success_mask, "bull_run_len" if "bull" in str(target.name) else "bear_run_len"],
        errors="coerce",
    ).fillna(0.0)
    leads = pd.to_numeric(
        frame.loc[success_mask, "bull_lead" if "bull" in str(target.name) else "bear_lead"],
        errors="coerce",
    ).fillna(0)
    lead_counts = {
        str(int(lead)): int(count)
        for lead, count in leads.value_counts().sort_index().items()
        if int(lead) > 0
    }
    return MetricRow(
        conditions=label,
        n=n_total,
        ticker_count=ticker_count,
        hit=hit,
        lift=(hit / base_hit) if base_hit > 0 else 0.0,
        train_n=train_n,
        train_hit=train_hit,
        val_n=val_n,
        val_ticker_count=val_ticker_count,
        val_hit=val_hit,
        val_lift=(val_hit / base_hit) if base_hit > 0 else 0.0,
        wilson_lb=wilson_lower_bound(hit_count, n_total),
        val_wilson_lb=wilson_lower_bound(val_hit_count, val_n),
        avg_run_len=float(run_lengths.mean()) if not run_lengths.empty else 0.0,
        avg_lead=float(leads.mean()) if not leads.empty else 0.0,
        lead_counts=lead_counts,
    )


def evaluate_focus_metrics(frame: pd.DataFrame, side: str, focus_names: list[str]) -> dict[str, Any]:
    target = frame[f"{side}_hit"].fillna(False).astype(bool)
    target.name = f"{side}_hit"
    base_hit = float(target.mean()) if len(target) else 0.0
    unique_dates = sorted(str(value) for value in frame["date_et"].dropna().unique().tolist())
    val_dates = unique_dates[-min(DEFAULT_VAL_DAYS, max(len(unique_dates), 1)) :]
    date_values = frame["date_et"].astype(str)
    train_mask = ~date_values.isin(val_dates)
    val_mask = date_values.isin(val_dates)
    focus_specs = select_focus_specs(frame, side, focus_names)

    singles: list[MetricRow] = []
    pairs: list[MetricRow] = []
    for spec in focus_specs:
        row = build_metric_row(
            frame=frame,
            target=target,
            base_hit=base_hit,
            train_mask=train_mask,
            val_mask=val_mask,
            mask=pd.Series(spec.mask, index=frame.index, dtype=bool),
            label=spec.name,
        )
        if row is not None:
            singles.append(row)

    for left, right in combinations(focus_specs, 2):
        if left.family == right.family:
            continue
        pair_mask = pd.Series(left.mask & right.mask, index=frame.index, dtype=bool)
        row = build_metric_row(
            frame=frame,
            target=target,
            base_hit=base_hit,
            train_mask=train_mask,
            val_mask=val_mask,
            mask=pair_mask,
            label=f"{left.name} AND {right.name}",
        )
        if row is not None:
            pairs.append(row)

    singles.sort(
        key=lambda item: (item.lift, item.hit, item.wilson_lb, item.n),
        reverse=True,
    )
    pairs.sort(
        key=lambda item: (item.val_hit, item.hit, item.val_wilson_lb, item.wilson_lb, item.ticker_count, item.n),
        reverse=True,
    )
    return {
        "base_hit": round(base_hit, 4),
        "validation_dates": val_dates,
        "top_singles": [item.to_dict() for item in singles[:12]],
        "top_pairs": [item.to_dict() for item in pairs[:15]],
    }


def render_summary(report: dict[str, Any]) -> str:
    bull_events = report["event_summary"]["bull"]
    bear_events = report["event_summary"]["bear"]
    bull_study = report["study"]["bull"]
    bear_study = report["study"]["bear"]
    lines: list[str] = []
    lines.append("# Same-Color 10+ Pre-Run Analysis")
    lines.append("")
    lines.append("## Contract")
    lines.append(f"- Window: `{report['window']['start_date']}` to `{report['window']['end_date']}` inclusive")
    lines.append("- Base timespan: `m1` regular session")
    lines.append("- Universe: `most_active`")
    lines.append("- Burst definition: `10+` consecutive candles of the same color with 60-second continuity")
    lines.append("- Signal contract: evaluate bars `1-3` candles before a future `10+` same-color run starts")
    lines.append("- Move floor: none beyond the color-run contract")
    lines.append("")
    lines.append("## Event Set")
    lines.append(
        f"- Bull runs: `{bull_events['run_count']}` across `{bull_events['ticker_count']}` tickers "
        f"| avg run `{bull_events['avg_run_len']}` | max run `{bull_events['max_run_len']}`"
    )
    lines.append(
        f"- Bear runs: `{bear_events['run_count']}` across `{bear_events['ticker_count']}` tickers "
        f"| avg run `{bear_events['avg_run_len']}` | max run `{bear_events['max_run_len']}`"
    )
    lines.append(
        f"- Bull range ET: `{bull_events['range_start_et']}` to `{bull_events['range_end_et']}`"
    )
    lines.append(
        f"- Bear range ET: `{bear_events['range_start_et']}` to `{bear_events['range_end_et']}`"
    )
    lines.append("")
    lines.append("Top bull-run tickers:")
    for item in bull_events["top_tickers"][:10]:
        lines.append(f"- `{item['ticker']}` -> `{item['count']}` runs")
    lines.append("")
    lines.append("Top bear-run tickers:")
    for item in bear_events["top_tickers"][:10]:
        lines.append(f"- `{item['ticker']}` -> `{item['count']}` runs")
    lines.append("")
    lines.append("## Base Rates")
    lines.append(f"- Bull future-10+ hit rate: `{bull_study['base_hit']}`")
    lines.append(f"- Bear future-10+ hit rate: `{bear_study['base_hit']}`")
    lines.append("")
    lines.append("## Bull Repeated Traits")
    for item in bull_study["top_singles"]:
        lines.append(
            f"- `{item['conditions']}` -> `hit={item['hit']:.4f}` `lift={item['lift']:.2f}x` "
            f"`n={item['n']}` `val={item['val_hit']:.4f}`"
        )
    lines.append("")
    lines.append("## Bull Feed Stacks")
    for item in bull_study["top_pairs"][:8]:
        lines.append(
            f"- `{item['conditions']}` -> `hit={item['hit']:.4f}` `val={item['val_hit']:.4f}` "
            f"`n={item['n']}` `tickers={item['ticker_count']}` `avg_run={item['avg_run_len']:.2f}`"
        )
    lines.append("")
    lines.append("## Bear Repeated Traits")
    for item in bear_study["top_singles"]:
        lines.append(
            f"- `{item['conditions']}` -> `hit={item['hit']:.4f}` `lift={item['lift']:.2f}x` "
            f"`n={item['n']}` `val={item['val_hit']:.4f}`"
        )
    lines.append("")
    lines.append("## Bear Feed Stacks")
    for item in bear_study["top_pairs"][:8]:
        lines.append(
            f"- `{item['conditions']}` -> `hit={item['hit']:.4f}` `val={item['val_hit']:.4f}` "
            f"`n={item['n']}` `tickers={item['ticker_count']}` `avg_run={item['avg_run_len']:.2f}`"
        )
    lines.append("")
    lines.append("## Bottom Line")
    lines.append(
        "- Bull 10+ bursts cluster around short red pressure or weak-close setups, especially when downside extension is present and the tape is ready to reclaim."
    )
    lines.append(
        "- Bear 10+ bursts cluster around short green pressure or high-close extension, especially when upside extension is present and the tape is ready to roll over."
    )
    lines.append(
        "- The reusable feed shape is symmetric: pressure streak plus extension, then a directional reclaim/rollover trigger. No ticker-specific logic is needed."
    )
    lines.append("")
    return "\n".join(lines)


def main() -> None:
    tickers = resolve_tickers("", DEFAULT_UNIVERSE)
    print(f"loading m1 rows for {len(tickers)} tickers", flush=True)
    base = fetch_m1_frame(
        tickers=tickers,
        start_date=DEFAULT_START_DATE,
        end_date=DEFAULT_END_DATE,
    )
    if base.empty:
        raise SystemExit("No m1 rows returned for same-color analysis.")
    print(f"loaded {len(base)} deduped rows", flush=True)
    enriched = add_derived_columns(base)
    print("derived columns ready", flush=True)
    outcomes, runs = annotate_prerun_hits(
        enriched,
        min_run=DEFAULT_MIN_RUN,
        lead_start=DEFAULT_LEAD_START,
        lead_end=DEFAULT_LEAD_END,
    )
    print("pre-run hits ready", flush=True)
    print(f"extracted {len(runs)} same-color runs", flush=True)
    bull_summary = build_event_summary(runs, "bull")
    bear_summary = build_event_summary(runs, "bear")
    print("event summaries ready", flush=True)
    bull_study = evaluate_focus_metrics(outcomes, "bull", BULL_FOCUS)
    print("bull metrics ready", flush=True)
    bear_study = evaluate_focus_metrics(outcomes, "bear", BEAR_FOCUS)
    print("bear metrics ready", flush=True)

    report = {
        "window": {
            "start_date": DEFAULT_START_DATE,
            "end_date": DEFAULT_END_DATE,
            "base_timespan": DEFAULT_BASE_TIMESPAN,
            "universe": DEFAULT_UNIVERSE,
            "min_run": DEFAULT_MIN_RUN,
            "lead_start": DEFAULT_LEAD_START,
            "lead_end": DEFAULT_LEAD_END,
        },
        "event_summary": {
            "bull": bull_summary,
            "bear": bear_summary,
        },
        "study": {
            "bull": bull_study,
            "bear": bear_study,
        },
    }

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    runs_path = OUTPUT_DIR / f"SAMECOLOR10PLUS_BURST_RUNS_{RUN_DATE}.csv"
    report_path = OUTPUT_DIR / f"SAMECOLOR10PLUS_PRERUN_ANALYSIS_{RUN_DATE}.md"
    json_path = OUTPUT_DIR / f"SAMECOLOR10PLUS_PRERUN_ANALYSIS_{RUN_DATE}.json"
    runs.to_csv(runs_path, index=False)
    json_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    report_path.write_text(render_summary(report), encoding="utf-8")
    print(report_path)
    print(json_path)
    print(runs_path)


if __name__ == "__main__":
    main()
