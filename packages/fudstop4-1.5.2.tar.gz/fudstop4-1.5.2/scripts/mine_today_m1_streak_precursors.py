#!/usr/bin/env python3
from __future__ import annotations

import argparse
import itertools
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Sequence

import pandas as pd

from fudstop4.apis.polygonio.polygon_options import PolygonOptions
from fudstop4._markets.list_sets.ticker_lists import most_active_tickers


NUMERIC_FIELDS: List[str] = [
    "change_pct",
    "hl_range_pct",
    "body_pct",
    "wick_ratio",
    "oc_pct",
    "true_range_pct",
    "gap_pct",
    "rsi",
    "td_buy_count",
    "td_sell_count",
    "macd_line",
    "macd_signal",
    "macd_hist",
    "macd_hist_slope",
    "macd_hist_slope3",
    "bb_width",
    "rvol",
    "atr_pct",
    "chop",
    "vwap_dist_pct",
    "stoch_rsi_k",
    "stoch_rsi_d",
    "mfi",
    "cmo",
    "roc",
    "trix",
    "ultimate_osc",
    "keltner_width",
    "sdc_width",
    "tsi",
    "tsi_signal",
    "adx",
    "di_plus",
    "di_minus",
]

BOOLEAN_FIELDS: List[str] = [
    "is_gap",
    "gap_filled",
    "gap_unfilled",
    "is_inside_bar",
    "macd_cross_up",
    "macd_cross_dn",
    "macd_imminent_bull",
    "macd_imminent_bear",
    "bb_close_outside_lower",
    "bb_close_outside_upper",
    "candle_completely_below_lower",
    "candle_completely_above_upper",
    "vwap_cross_up",
    "vwap_cross_dn",
    "trend_regime",
    "volume_confirm",
    "squeeze_on",
    "squeeze_off",
    "candle_green",
    "candle_red",
    "adx_strong",
    "di_bull",
    "di_bear",
    "macd_bull",
    "macd_bear",
    "tsi_bull",
    "tsi_bear",
    "momentum_confirm_bull",
    "momentum_confirm_bear",
    "ema_stack_bull",
    "ema_stack_bear",
]

BASE_COLUMNS: List[str] = [
    "ticker",
    "timespan",
    "ts",
    "date_et",
    "time_et",
    "session",
    "candle_dir",
]

QUERY_COLUMNS: List[str] = list(dict.fromkeys(BASE_COLUMNS + NUMERIC_FIELDS + BOOLEAN_FIELDS))


@dataclass(frozen=True)
class ClauseSpec:
    field: str
    label: str
    expr: str
    fn: Callable[[pd.DataFrame], pd.Series]


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Mine fresh m1 pre-run precursor conditions from today's 6+ streaks "
            "and backtest them historically against ca."
        )
    )
    parser.add_argument("--start-date", default="2025-12-01")
    parser.add_argument("--end-date", default="")
    parser.add_argument("--today-date", default="")
    parser.add_argument("--run-length", type=int, default=6)
    parser.add_argument("--combo-k", type=int, default=2)
    parser.add_argument("--top-singles", type=int, default=18)
    parser.add_argument("--top-results", type=int, default=20)
    parser.add_argument("--min-oos", type=int, default=25)
    parser.add_argument("--min-oos-hit", type=float, default=0.85)
    parser.add_argument("--min-validation-hit", type=float, default=0.80)
    parser.add_argument("--min-holdout-hit", type=float, default=0.85)
    parser.add_argument("--min-unique-tickers", type=int, default=10)
    parser.add_argument("--max-top-share", type=float, default=0.35)
    parser.add_argument("--output-dir", default="burst_discovery_output")
    parser.add_argument(
        "--universe",
        choices=("most_active", "all"),
        default="most_active",
    )
    return parser.parse_args()


def _query_sql(start_date: str, end_date: str, universe: str) -> str:
    selected = ",\n        ".join(QUERY_COLUMNS)
    end_filter = f"AND date_et <= '{end_date}'" if end_date else ""
    ticker_filter = ""
    if universe == "most_active":
        quoted = ", ".join("'" + str(ticker).replace("'", "''").upper() + "'" for ticker in most_active_tickers)
        ticker_filter = f"\n  AND UPPER(BTRIM(ticker)) IN ({quoted})"
    return f"""
SELECT
        {selected}
FROM ca
WHERE timespan = 'm1'
  AND date_et >= '{start_date}'
  {end_filter}
  {ticker_filter}
  AND candle_dir IS NOT NULL
ORDER BY ticker, ts::bigint
""".strip()


async def _fetch_frame(start_date: str, end_date: str, universe: str) -> pd.DataFrame:
    db = PolygonOptions()
    rows = await db.fetch(_query_sql(start_date, end_date, universe))
    frame = pd.DataFrame([dict(row) for row in rows])
    if frame.empty:
        return frame
    frame["ts_epoch"] = pd.to_numeric(frame["ts"], errors="coerce").astype("Int64")
    frame = frame.dropna(subset=["ts_epoch"]).copy()
    frame["ts_epoch"] = frame["ts_epoch"].astype("int64")
    frame["ticker"] = frame["ticker"].astype(str).str.upper().str.strip()
    frame["timespan"] = frame["timespan"].astype(str).str.lower().str.strip()
    frame["date_et"] = frame["date_et"].astype(str).str.strip()
    frame["time_et"] = frame["time_et"].astype(str).str.strip()
    frame["session"] = frame["session"].astype(str).str.strip().str.lower()
    frame["candle_dir"] = pd.to_numeric(frame["candle_dir"], errors="coerce").fillna(0).astype(int)
    for field in NUMERIC_FIELDS:
        if field in frame.columns:
            frame[field] = pd.to_numeric(frame[field], errors="coerce")
    for field in BOOLEAN_FIELDS:
        if field in frame.columns:
            frame[field] = frame[field].astype("boolean")
    return frame


def _label_pre_run_events(frame: pd.DataFrame, run_length: int) -> pd.DataFrame:
    df = frame.sort_values(["ticker", "ts_epoch"]).copy()
    df["bull_run6"] = False
    df["bear_run6"] = False
    for offset in range(1, run_length + 1):
        df[f"next_dir_{offset}"] = df.groupby("ticker")["candle_dir"].shift(-offset)
        df[f"next_ts_{offset}"] = df.groupby("ticker")["ts_epoch"].shift(-offset)
    bull_mask = pd.Series(True, index=df.index)
    bear_mask = pd.Series(True, index=df.index)
    base_ts = df["ts_epoch"]
    for offset in range(1, run_length + 1):
        expected_ts = base_ts + (60 * offset)
        bull_mask &= df[f"next_dir_{offset}"].eq(1) & df[f"next_ts_{offset}"].eq(expected_ts)
        bear_mask &= df[f"next_dir_{offset}"].eq(-1) & df[f"next_ts_{offset}"].eq(expected_ts)
    df["bull_run6"] = bull_mask.fillna(False)
    df["bear_run6"] = bear_mask.fillna(False)
    drop_cols = [f"next_dir_{offset}" for offset in range(1, run_length + 1)] + [
        f"next_ts_{offset}" for offset in range(1, run_length + 1)
    ]
    return df.drop(columns=drop_cols)


def _chrono_cuts(df: pd.DataFrame) -> tuple[int, int]:
    unique_ts = sorted(df["ts_epoch"].unique().tolist())
    if len(unique_ts) < 12:
        raise ValueError("not enough timestamps for chrono split")
    cut1 = unique_ts[int(len(unique_ts) * 0.50)]
    cut2 = unique_ts[int(len(unique_ts) * 0.75)]
    return cut1, cut2


def _wilson_lower_bound(wins: int, total: int, z: float = 1.96) -> float:
    if total <= 0:
        return 0.0
    phat = wins / total
    denom = 1.0 + (z * z) / total
    centre = phat + (z * z) / (2.0 * total)
    margin = z * ((phat * (1.0 - phat) + (z * z) / (4.0 * total)) / total) ** 0.5
    return (centre - margin) / denom


def _score_subset(subset: pd.DataFrame, cut1: int, cut2: int, success_col: str) -> Dict[str, Any]:
    train = subset.loc[subset["ts_epoch"] < cut1]
    valid = subset.loc[(subset["ts_epoch"] >= cut1) & (subset["ts_epoch"] < cut2)]
    hold = subset.loc[subset["ts_epoch"] >= cut2]
    train_n = int(len(train))
    valid_n = int(len(valid))
    hold_n = int(len(hold))
    train_wins = int(train[success_col].sum())
    valid_wins = int(valid[success_col].sum())
    hold_wins = int(hold[success_col].sum())
    oos_n = valid_n + hold_n
    oos_wins = valid_wins + hold_wins
    ticker_counts = subset.loc[subset["ts_epoch"] >= cut1, "ticker"].value_counts()
    top_share = (float(ticker_counts.iloc[0]) / oos_n) if oos_n and not ticker_counts.empty else 0.0
    return {
        "train_n": train_n,
        "train_hit": (train_wins / train_n) if train_n else 0.0,
        "valid_n": valid_n,
        "valid_hit": (valid_wins / valid_n) if valid_n else 0.0,
        "hold_n": hold_n,
        "hold_hit": (hold_wins / hold_n) if hold_n else 0.0,
        "oos_n": oos_n,
        "oos_wins": oos_wins,
        "oos_hit": (oos_wins / oos_n) if oos_n else 0.0,
        "wilson": _wilson_lower_bound(oos_wins, oos_n),
        "unique_tickers": int(ticker_counts.shape[0]),
        "top_share": top_share,
    }


def _passes_bar(score: Dict[str, Any], args: argparse.Namespace) -> bool:
    return bool(
        score["oos_n"] >= args.min_oos
        and score["oos_hit"] >= args.min_oos_hit
        and score["valid_hit"] >= args.min_validation_hit
        and score["hold_hit"] >= args.min_holdout_hit
        and score["unique_tickers"] >= args.min_unique_tickers
        and score["top_share"] <= args.max_top_share
    )


def _numeric_clause_specs(today_positive: pd.DataFrame, frame: pd.DataFrame, field: str) -> List[ClauseSpec]:
    specs: List[ClauseSpec] = []
    if field not in frame.columns:
        return specs
    source = pd.to_numeric(today_positive[field], errors="coerce").dropna()
    base = pd.to_numeric(frame[field], errors="coerce")
    if source.empty or base.notna().mean() < 0.50:
        return specs
    thresholds = sorted(
        {
            round(float(source.quantile(q)), 6)
            for q in (0.20, 0.35, 0.50, 0.65, 0.80)
            if not source.empty
        }
    )
    for threshold in thresholds:
        specs.append(
            ClauseSpec(
                field=field,
                label=f"{field}>={threshold:g}",
                expr=f"{field} >= {threshold:.6g}",
                fn=lambda df, f=field, v=threshold: pd.to_numeric(df[f], errors="coerce").notna()
                & (pd.to_numeric(df[f], errors="coerce") >= v),
            )
        )
        specs.append(
            ClauseSpec(
                field=field,
                label=f"{field}<={threshold:g}",
                expr=f"{field} <= {threshold:.6g}",
                fn=lambda df, f=field, v=threshold: pd.to_numeric(df[f], errors="coerce").notna()
                & (pd.to_numeric(df[f], errors="coerce") <= v),
            )
        )
    return specs


def _boolean_clause_specs(today_positive: pd.DataFrame, frame: pd.DataFrame, field: str) -> List[ClauseSpec]:
    specs: List[ClauseSpec] = []
    if field not in frame.columns:
        return specs
    positive_rate = float(today_positive[field].fillna(False).astype(bool).mean())
    overall_rate = float(frame[field].fillna(False).astype(bool).mean())
    if positive_rate < 0.20:
        return specs
    if positive_rate <= overall_rate:
        return specs
    specs.append(
        ClauseSpec(
            field=field,
            label=field,
            expr=f"{field} = true",
            fn=lambda df, f=field: df[f].fillna(False).astype(bool),
        )
    )
    return specs


def _build_candidate_pool(today_positive: pd.DataFrame, frame: pd.DataFrame) -> List[ClauseSpec]:
    specs: List[ClauseSpec] = []
    for field in NUMERIC_FIELDS:
        specs.extend(_numeric_clause_specs(today_positive, frame, field))
    for field in BOOLEAN_FIELDS:
        specs.extend(_boolean_clause_specs(today_positive, frame, field))
    deduped: Dict[str, ClauseSpec] = {}
    for spec in specs:
        deduped.setdefault(spec.label, spec)
    return list(deduped.values())


def _rank_single_clauses(
    frame: pd.DataFrame,
    today_positive: pd.DataFrame,
    success_col: str,
    args: argparse.Namespace,
) -> List[Dict[str, Any]]:
    cut1, cut2 = _chrono_cuts(frame)
    results: List[Dict[str, Any]] = []
    for spec in _build_candidate_pool(today_positive, frame):
        mask = spec.fn(frame).fillna(False)
        subset = frame.loc[mask].copy()
        if len(subset) < args.min_oos:
            continue
        today_hits = int(spec.fn(today_positive).fillna(False).sum())
        if today_hits <= 0:
            continue
        score = _score_subset(subset, cut1, cut2, success_col)
        score.update(
            {
                "predicate": spec.expr,
                "label": spec.label,
                "field": spec.field,
                "today_hits": today_hits,
                "today_total": int(len(today_positive)),
            }
        )
        results.append(score)
    results.sort(
        key=lambda item: (
            _passes_bar(item, args),
            item["today_hits"],
            item["oos_hit"],
            item["oos_n"],
            item["wilson"],
        ),
        reverse=True,
    )
    return results


def _rank_combos(
    frame: pd.DataFrame,
    today_positive: pd.DataFrame,
    success_col: str,
    singles: Sequence[Dict[str, Any]],
    args: argparse.Namespace,
) -> List[Dict[str, Any]]:
    cut1, cut2 = _chrono_cuts(frame)
    lookup = {item["label"]: item for item in singles}
    specs_by_label = {spec.label: spec for spec in _build_candidate_pool(today_positive, frame)}
    results: List[Dict[str, Any]] = []
    top_labels = [str(item["label"]) for item in singles[: args.top_singles] if str(item.get("label")) in specs_by_label]
    for combo_size in range(2, max(2, args.combo_k) + 1):
        for labels in itertools.combinations(top_labels, combo_size):
            combo_specs = [specs_by_label[label] for label in labels]
            if len({spec.field for spec in combo_specs}) != len(combo_specs):
                continue
            mask = pd.Series(True, index=frame.index)
            today_mask = pd.Series(True, index=today_positive.index)
            for spec in combo_specs:
                mask &= spec.fn(frame).fillna(False)
                today_mask &= spec.fn(today_positive).fillna(False)
            subset = frame.loc[mask].copy()
            if len(subset) < args.min_oos:
                continue
            today_hits = int(today_mask.sum())
            if today_hits <= 0:
                continue
            score = _score_subset(subset, cut1, cut2, success_col)
            score.update(
                {
                    "predicate": " AND ".join(spec.expr for spec in combo_specs),
                    "label": " + ".join(labels),
                    "field": "|".join(sorted({spec.field for spec in combo_specs})),
                    "today_hits": today_hits,
                    "today_total": int(len(today_positive)),
                }
            )
            results.append(score)
    results.sort(
        key=lambda item: (
            _passes_bar(item, args),
            item["today_hits"],
            item["oos_hit"],
            item["oos_n"],
            item["wilson"],
        ),
        reverse=True,
    )
    return results


def _today_precursor_rows(frame: pd.DataFrame, today_date: str, success_col: str) -> pd.DataFrame:
    return frame.loc[(frame["date_et"] == today_date) & frame[success_col]].copy()


def _serialize_top(rows: Sequence[Dict[str, Any]], top_n: int) -> List[Dict[str, Any]]:
    keep = [
        "predicate",
        "label",
        "field",
        "today_hits",
        "today_total",
        "oos_n",
        "oos_hit",
        "valid_n",
        "valid_hit",
        "hold_n",
        "hold_hit",
        "unique_tickers",
        "top_share",
        "wilson",
        "train_n",
        "train_hit",
    ]
    out: List[Dict[str, Any]] = []
    for item in rows[:top_n]:
        out.append({key: item.get(key) for key in keep})
    return out


def _write_outputs(
    output_dir: Path,
    today_date: str,
    payload: Dict[str, Any],
    today_events: pd.DataFrame,
    winners: Dict[str, pd.DataFrame],
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = f"m1_streak6_precursor_mining_{today_date}"
    (output_dir / f"{stem}.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    today_events.to_csv(output_dir / f"{stem}_today_precursors.csv", index=False)
    for side, frame in winners.items():
        frame.to_csv(output_dir / f"{stem}_{side}_winners.csv", index=False)


async def main_async() -> None:
    args = _parse_args()
    frame = await _fetch_frame(args.start_date, args.end_date, args.universe)
    if frame.empty:
        raise ValueError("query returned no m1 ca rows")
    labeled = _label_pre_run_events(frame, args.run_length)
    today_date = args.today_date or str(labeled["date_et"].max())

    winners: Dict[str, pd.DataFrame] = {}
    payload: Dict[str, Any] = {
        "today_date": today_date,
        "run_length": args.run_length,
        "history_start": str(labeled["date_et"].min()),
        "history_end": str(labeled["date_et"].max()),
        "row_count": int(len(labeled)),
        "universe": args.universe,
        "today_precursor_counts": {},
        "survivors": {},
    }
    today_event_frames: List[pd.DataFrame] = []

    for side, success_col in (("bull", "bull_run6"), ("bear", "bear_run6")):
        today_positive = _today_precursor_rows(labeled, today_date, success_col)
        payload["today_precursor_counts"][side] = int(len(today_positive))
        if today_positive.empty:
            winners[side] = pd.DataFrame()
            payload["survivors"][side] = {"singles": [], "combos": []}
            continue
        single_ranked = _rank_single_clauses(labeled, today_positive, success_col, args)
        combo_ranked = _rank_combos(labeled, today_positive, success_col, single_ranked, args)
        single_survivors = [row for row in single_ranked if _passes_bar(row, args)]
        combo_survivors = [row for row in combo_ranked if _passes_bar(row, args)]
        payload["survivors"][side] = {
            "singles": _serialize_top(single_survivors, args.top_results),
            "combos": _serialize_top(combo_survivors, args.top_results),
            "top_ranked_singles": _serialize_top(single_ranked, args.top_results),
            "top_ranked_combos": _serialize_top(combo_ranked, args.top_results),
        }
        winner_rows = single_survivors + combo_survivors
        winners[side] = pd.DataFrame(winner_rows)
        tagged = today_positive.copy()
        tagged["side"] = side
        today_event_frames.append(tagged)

    today_events = pd.concat(today_event_frames, ignore_index=True) if today_event_frames else pd.DataFrame()
    _write_outputs(Path(args.output_dir), today_date, payload, today_events, winners)

    print(f"TODAY_DATE={today_date}")
    print(f"ROW_COUNT={len(labeled)}")
    print(f"BULL_TODAY_PRECURSORS={payload['today_precursor_counts'].get('bull', 0)}")
    print(f"BEAR_TODAY_PRECURSORS={payload['today_precursor_counts'].get('bear', 0)}")
    print(f"BULL_SURVIVOR_SINGLES={len(payload['survivors']['bull']['singles'])}")
    print(f"BULL_SURVIVOR_COMBOS={len(payload['survivors']['bull']['combos'])}")
    print(f"BEAR_SURVIVOR_SINGLES={len(payload['survivors']['bear']['singles'])}")
    print(f"BEAR_SURVIVOR_COMBOS={len(payload['survivors']['bear']['combos'])}")


def main() -> None:
    import asyncio

    asyncio.run(main_async())


if __name__ == "__main__":
    main()
