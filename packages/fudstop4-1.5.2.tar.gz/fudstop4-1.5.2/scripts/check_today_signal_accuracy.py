#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import psycopg2
import requests


DEFAULT_DB_HOST = os.environ.get("DB_HOST", "localhost")
DEFAULT_DB_PORT = int(os.environ.get("DB_PORT", "5432"))
DEFAULT_DB_NAME = os.environ.get("DB_NAME", "fudstop3")
DEFAULT_DB_USER = os.environ.get("DB_USER", "chuck")
DEFAULT_DB_PASSWORD = os.environ.get("DB_PASSWORD", "fud")
DEFAULT_BASE_URL = os.environ.get("FUDSTOP_SITE_URL", "https://fudstop.io").rstrip("/")


def _parse_dt(value: Any) -> Optional[datetime]:
    if not value:
        return None
    text = str(value).strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = f"{text[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _epoch(value: Any) -> Optional[int]:
    parsed = _parse_dt(value)
    if not parsed:
        return None
    return int(parsed.timestamp())


def _fetch_json(url: str) -> Dict[str, Any]:
    response = requests.get(url, timeout=60)
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected payload from {url}: {type(payload)!r}")
    return payload


def _score_hit(
    conn,
    *,
    ticker: str,
    timespan: str,
    tone: str,
    anchor_epoch: int,
    future_bars: int,
    target_pct: float,
) -> Dict[str, Any]:
    with conn.cursor() as cur:
        cur.execute(
            """
            with ordered as (
                select
                    ticker,
                    timespan,
                    ts::bigint as ts_epoch,
                    c::double precision as c,
                    h::double precision as h,
                    l::double precision as l,
                    row_number() over (order by ts::bigint) as rn
                from public.ca
                where ticker = %s
                  and timespan = %s
                  and ts::bigint between %s and %s
            ),
            anchor as (
                select *
                from ordered
                where ts_epoch >= %s
                order by ts_epoch
                limit 1
            ),
            future as (
                select o.*
                from ordered o
                join anchor a on true
                where o.rn > a.rn
                  and o.rn <= a.rn + %s
            )
            select
                a.ts_epoch,
                a.c,
                count(f.*)::int as observed_future_bars,
                max(f.h) as max_high,
                min(f.l) as min_low,
                max(f.c) as max_close,
                min(f.c) as min_close
            from anchor a
            left join future f on true
            group by a.ts_epoch, a.c
            """,
            (
                ticker,
                timespan,
                anchor_epoch - 86400,
                anchor_epoch + 86400,
                anchor_epoch,
                future_bars,
            ),
        )
        row = cur.fetchone()
    if not row:
        return {
            "status": "missing_anchor",
            "observed_future_bars": 0,
            "success": None,
            "move_pct": None,
        }
    anchor_ts_epoch, entry_close, observed, max_high, min_low, max_close, min_close = row
    if entry_close in (None, 0):
        return {
            "status": "bad_anchor_price",
            "anchor_ts_epoch": anchor_ts_epoch,
            "observed_future_bars": int(observed or 0),
            "success": None,
            "move_pct": None,
        }
    is_complete = int(observed or 0) >= future_bars
    is_bullish = str(tone or "").strip().lower() == "bullish"
    if is_bullish:
        best_price = float(max_high) if max_high is not None else float(entry_close)
        move_pct = ((best_price / float(entry_close)) - 1.0) * 100.0
    else:
        best_price = float(min_low) if min_low is not None else float(entry_close)
        move_pct = (1.0 - (best_price / float(entry_close))) * 100.0
    success = move_pct + 1e-9 >= target_pct if is_complete else None
    return {
        "status": "complete" if is_complete else "pending",
        "anchor_ts_epoch": int(anchor_ts_epoch),
        "entry_close": round(float(entry_close), 6),
        "observed_future_bars": int(observed or 0),
        "future_bars_required": future_bars,
        "target_pct": target_pct,
        "move_pct": round(move_pct, 4),
        "success": success,
        "max_high": round(float(max_high), 6) if max_high is not None else None,
        "min_low": round(float(min_low), 6) if min_low is not None else None,
        "max_close": round(float(max_close), 6) if max_close is not None else None,
        "min_close": round(float(min_close), 6) if min_close is not None else None,
    }


def _iter_endpoint_hits(payload: Dict[str, Any], source: str) -> Iterable[Dict[str, Any]]:
    for hit in payload.get("hits") or []:
        if not isinstance(hit, dict):
            continue
        anchor_field = "first_hit" if source == "rev" else "first_signal"
        anchor_value = hit.get(anchor_field) or hit.get("first_signal") or hit.get("first_hit")
        anchor_epoch = _epoch(anchor_value)
        ticker = str(hit.get("ticker") or "").strip().upper()
        timespan = str(hit.get("timespan") or "m1").strip()
        tone = str(hit.get("tone") or "").strip().lower()
        if not ticker or not timespan or not tone or anchor_epoch is None:
            continue
        yield {
            "source": source,
            "ticker": ticker,
            "timespan": timespan,
            "tone": tone,
            "anchor_field": anchor_field,
            "anchor_time": anchor_value,
            "anchor_epoch": anchor_epoch,
            "endpoint_hit_rate": hit.get("hit_rate"),
            "endpoint_sample_size": hit.get("sample_size"),
            "stack_count": hit.get("stack_count"),
            "hit_rows": hit.get("hit_rows"),
            "signal_rows": hit.get("signal_rows"),
            "condition_summary": hit.get("condition_summary"),
            "backend_confirmed": hit.get("confirmed"),
        }


def _summarize(scored: List[Dict[str, Any]]) -> Dict[str, Any]:
    completed = [item for item in scored if (item.get("score") or {}).get("status") == "complete"]
    pending = [item for item in scored if (item.get("score") or {}).get("status") == "pending"]
    missing = [item for item in scored if (item.get("score") or {}).get("status") not in {"complete", "pending"}]
    wins = [item for item in completed if (item.get("score") or {}).get("success") is True]
    losses = [item for item in completed if (item.get("score") or {}).get("success") is False]
    by_source: Dict[str, Dict[str, Any]] = {}
    for item in scored:
        source = str(item.get("source") or "unknown")
        bucket = by_source.setdefault(
            source,
            {"total": 0, "completed": 0, "wins": 0, "losses": 0, "pending": 0, "missing": 0},
        )
        bucket["total"] += 1
        status = (item.get("score") or {}).get("status")
        if status == "complete":
            bucket["completed"] += 1
            if (item.get("score") or {}).get("success") is True:
                bucket["wins"] += 1
            elif (item.get("score") or {}).get("success") is False:
                bucket["losses"] += 1
        elif status == "pending":
            bucket["pending"] += 1
        else:
            bucket["missing"] += 1
    for bucket in by_source.values():
        bucket["accuracy_pct"] = round(100.0 * bucket["wins"] / bucket["completed"], 2) if bucket["completed"] else None
    return {
        "total_groups": len(scored),
        "completed_groups": len(completed),
        "successful_groups": len(wins),
        "failed_groups": len(losses),
        "pending_groups": len(pending),
        "missing_groups": len(missing),
        "accuracy_pct": round(100.0 * len(wins) / len(completed), 2) if completed else None,
        "by_source": by_source,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Check today's live REV/MOM signal accuracy against ca forward bars.")
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    parser.add_argument("--future-bars", type=int, default=15)
    parser.add_argument("--target-pct", type=float, default=1.0)
    parser.add_argument("--limit", type=int, default=200)
    parser.add_argument("--universe", default="all")
    parser.add_argument("--output", default="")
    parser.add_argument("--host", default=DEFAULT_DB_HOST)
    parser.add_argument("--port", type=int, default=DEFAULT_DB_PORT)
    parser.add_argument("--database", default=DEFAULT_DB_NAME)
    parser.add_argument("--user", default=DEFAULT_DB_USER)
    parser.add_argument("--password", default=DEFAULT_DB_PASSWORD)
    args = parser.parse_args()

    base_url = str(args.base_url).rstrip("/")
    rev_payload = _fetch_json(
        f"{base_url}/api/site/rev-hit-log?universe={args.universe}&limit={args.limit}&force_refresh=true"
    )
    mom_payload = _fetch_json(
        f"{base_url}/api/site/mom-hit-log?universe={args.universe}&limit={args.limit}&force_refresh=true"
    )
    hits = list(_iter_endpoint_hits(rev_payload, "rev")) + list(_iter_endpoint_hits(mom_payload, "mom"))

    conn = psycopg2.connect(
        host=args.host,
        port=args.port,
        dbname=args.database,
        user=args.user,
        password=args.password,
    )
    try:
        scored = []
        for hit in hits:
            score = _score_hit(
                conn,
                ticker=hit["ticker"],
                timespan=hit["timespan"],
                tone=hit["tone"],
                anchor_epoch=hit["anchor_epoch"],
                future_bars=args.future_bars,
                target_pct=args.target_pct,
            )
            scored.append({**hit, "score": score})
    finally:
        conn.close()

    result = {
        "run_id": f"today_signal_accuracy_{rev_payload.get('date') or datetime.now(timezone.utc).date().isoformat()}",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "site_base_url": base_url,
        "database": args.database,
        "table": "public.ca",
        "success_definition": f"first grouped alert reaches {args.target_pct:.2f}% directional high/low excursion within next {args.future_bars} {args.future_bars and 'bars'}",
        "rev_endpoint_summary": {
            "status": rev_payload.get("status"),
            "date": rev_payload.get("date"),
            "count": rev_payload.get("count"),
            "ticker_count": rev_payload.get("ticker_count"),
            "timespan_counts": rev_payload.get("timespan_counts"),
            "library": rev_payload.get("library"),
        },
        "mom_endpoint_summary": {
            "status": mom_payload.get("status"),
            "date": mom_payload.get("date"),
            "count": mom_payload.get("count"),
            "confirmed_count": mom_payload.get("confirmed_count"),
            "ticker_count": mom_payload.get("ticker_count"),
            "timespan_counts": mom_payload.get("timespan_counts"),
            "library": mom_payload.get("library"),
        },
        "summary": _summarize(scored),
        "scored_hits": scored,
    }

    output = Path(args.output) if args.output else Path("experiments") / f"today_signal_accuracy_{rev_payload.get('date')}.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"output": str(output), **result["summary"]}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
