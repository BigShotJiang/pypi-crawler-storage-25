from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


ROOT = Path(__file__).resolve().parents[1]
RUNS_ROOT = ROOT / "runs" / "ca_historical_reversal_research"
SITE_DATA_DIR = ROOT / "stock_market_site" / "app" / "data"
PROMOTION_DATE = "2026-03-19"
PROMOTION_DIR = RUNS_ROOT / f"consecutive_move_live_promotion_{PROMOTION_DATE}"
PROMOTED_FILENAME = "rev_promoted_consecutive_move_mixed.json"
WATCHLIST_FILENAME = "rev_live_watchlist_consecutive_move_mixed.json"
WATCHLIST_CAP_PER_SLOT = 12
SAFE_EVENT_PROFILES = {"canonical", "no_macd_gate"}
MACD_STATE_NAMES = {
    1: "diverging_bull",
    2: "diverging_bear",
    3: "arching_bull",
    4: "arching_bear",
    5: "converging_bull",
    6: "converging_bear",
    7: "imminent_bull_cross",
    8: "imminent_bear_cross",
}
FIELD_ALIASES = {
    "td_buy_count": "td_buy",
    "td_sell_count": "td_sell",
    "vwap_dist_pct": "vwap_dist",
    "candle_completely_above_upper": "candle_above_band",
    "candle_completely_below_lower": "candle_below_band",
}
SOURCE_RUNS = (
    "lower_tf_immediate_run15_trigger50bp_canonical_default_k5",
    "lower_tf_immediate_run15_trigger50bp_no_macd_default_k5",
    "lower_tf_immediate_run15_trigger50bp_canonical_burst_k5",
    "lower_tf_immediate_run15_trigger50bp_no_macd_burst_k5",
    "htf_immediate_run15_trigger50bp_canonical_burst_k5",
    "htf_immediate_run15_trigger50bp_no_macd_burst_k5",
    "lower_tf_immediate_run15_hold100bp_canonical_default_k5",
    "lower_tf_immediate_run15_hold100bp_no_macd_default_k5",
    "lower_tf_immediate_run15_hold100bp_no_macd_alt_k5",
    "lower_tf_immediate_run13_no_macd_hit100_min20_k5",
    "immediate_run13_m1_burst_deep_min20_k4",
    "immediate_run13_m5_m15_m30_burst_deep_min20_k4",
    "immediate_run13_default_min20_all",
    "immediate_run13_htf_no_macd_min20_k4",
)
NUMERIC_EXPR_RE = re.compile(r"^\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*(<=|>=|=)\s*([-+]?\d+(?:\.\d+)?)\s*$")
BOOL_EXPR_RE = re.compile(r"^\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(true|false)\s*$", re.IGNORECASE)
IN_EXPR_RE = re.compile(r"^\s*([a-zA-Z_][a-zA-Z0-9_]*)\s+IN\s*\(([^)]+)\)\s*$", re.IGNORECASE)


@dataclass(frozen=True)
class SourceMetadata:
    run_name: str
    event_profile: str
    condition_profile: str
    outcome_profile: str
    trigger_window_min: int
    trigger_window_max: int
    run_window_min: int
    run_window_max: int
    trigger_min_move: float
    contract_priority: int
    contract_key: str
    contract_label: str


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _format_number(value: Any) -> str:
    try:
        numeric = float(value)
    except (TypeError, ValueError):
        return str(value)
    if numeric.is_integer():
        return str(int(numeric))
    return format(numeric, ".10g")


def _slugify(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", str(value or "").strip().lower()).strip("_")
    return slug or "spec"


def _field_label(field: str) -> str:
    return FIELD_ALIASES.get(field, field)


def _condition_label(condition: Tuple[str, str, Any]) -> str:
    field, operator, expected = condition
    if field == "macd_state_code" and operator == "eqnum":
        return f"state={MACD_STATE_NAMES.get(int(float(expected)), int(float(expected)))}"
    if field == "macd_state_code" and operator == "innum":
        values = ",".join(str(int(float(item))) for item in expected)
        return f"state in {{{values}}}"
    if operator == "truthy":
        return _field_label(field)
    if operator == "gte":
        return f"{_field_label(field)}>={_format_number(expected)}"
    if operator == "lte":
        return f"{_field_label(field)}<={_format_number(expected)}"
    if operator == "eqnum":
        return f"{_field_label(field)}={_format_number(expected)}"
    return f"{_field_label(field)}={expected}"


def _contract_details(metadata: Dict[str, Any]) -> Tuple[int, str, str]:
    trigger_window_max = int(metadata.get("trigger_window_max") or 0)
    trigger_min_move = float(metadata.get("trigger_min_move") or 0.0)
    if trigger_window_max == 5 and trigger_min_move >= 0.005 and trigger_min_move < 0.01:
        return (
            0,
            "trigger50bp_hold100",
            "trigger begins within candles 1-5 with >=0.50% directional move, then every close in candles 10-15 still holds >=1.00%",
        )
    if trigger_window_max == 5 and trigger_min_move >= 0.01:
        return (
            1,
            "trigger100bp_hold100",
            "trigger begins within candles 1-5 with >=1.00% directional move, then every close in candles 10-15 still holds >=1.00%",
        )
    return (
        2,
        "immediate_run13",
        "trigger begins within candles 1-3, then every close in candles 10-15 still holds >=1.00%",
    )


def _load_source_metadata(run_name: str) -> Optional[SourceMetadata]:
    run_dir = RUNS_ROOT / run_name
    meta_path = run_dir / "run_metadata.json"
    if not meta_path.exists():
        return None
    payload = _read_json(meta_path)
    if not isinstance(payload, list) or not payload:
        return None
    raw = payload[0]
    event_profile = str(raw.get("event_profile") or "").strip()
    outcome_profile = str(raw.get("outcome_profile") or "").strip()
    if event_profile not in SAFE_EVENT_PROFILES or outcome_profile != "immediate_run":
        return None
    contract_priority, contract_key, contract_label = _contract_details(raw)
    return SourceMetadata(
        run_name=run_name,
        event_profile=event_profile,
        condition_profile=str(raw.get("condition_profile") or "").strip(),
        outcome_profile=outcome_profile,
        trigger_window_min=int(raw.get("trigger_window_min") or 0),
        trigger_window_max=int(raw.get("trigger_window_max") or 0),
        run_window_min=int(raw.get("run_window_min") or 0),
        run_window_max=int(raw.get("run_window_max") or 0),
        trigger_min_move=float(raw.get("trigger_min_move") or 0.0),
        contract_priority=contract_priority,
        contract_key=contract_key,
        contract_label=contract_label,
    )


def _parse_condition_expr(expr: str) -> Tuple[str, str, Any]:
    raw = str(expr or "").strip()
    match = IN_EXPR_RE.match(raw)
    if match:
        field = match.group(1)
        values = [float(chunk.strip()) for chunk in match.group(2).split(",") if chunk.strip()]
        return (field, "innum", values)
    match = BOOL_EXPR_RE.match(raw)
    if match:
        return (match.group(1), "truthy", match.group(2).strip().lower() == "true")
    match = NUMERIC_EXPR_RE.match(raw)
    if match:
        field = match.group(1)
        operator = match.group(2)
        value = float(match.group(3))
        if operator == ">=":
            return (field, "gte", value)
        if operator == "<=":
            return (field, "lte", value)
        return (field, "eqnum", value)
    raise ValueError(f"unsupported condition expression: {raw}")


def _base_conditions(side: str, event_profile: str) -> List[Tuple[str, str, Any]]:
    if side == "bull":
        base = [("rsi", "lte", 30.0), ("td_buy_count", "gte", 8.0)]
        if event_profile == "canonical":
            base.append(("macd_state_code", "innum", [4.0, 6.0, 7.0]))
        return base
    base = [("rsi", "gte", 70.0), ("td_sell_count", "gte", 8.0)]
    if event_profile == "canonical":
        base.append(("macd_state_code", "innum", [3.0, 5.0, 8.0]))
    return base


def _condition_sort_key(condition: Tuple[str, str, Any]) -> Tuple[str, str, str]:
    field, operator, expected = condition
    return field, operator, json.dumps(expected, sort_keys=True)


def _append_or_replace(
    conditions: List[Tuple[str, str, Any]],
    condition: Tuple[str, str, Any],
) -> None:
    field, operator, expected = condition
    for index, (prior_field, prior_operator, prior_expected) in enumerate(list(conditions)):
        if prior_field != field:
            continue
        if operator == "gte" and prior_operator == "gte":
            if float(prior_expected) >= float(expected):
                return
            conditions[index] = condition
            return
        if operator == "lte" and prior_operator == "lte":
            if float(prior_expected) <= float(expected):
                return
            conditions[index] = condition
            return
        if operator == "truthy" and prior_operator == "truthy":
            return
        if operator == "eqnum":
            if prior_operator == "eqnum" and float(prior_expected) == float(expected):
                return
            if prior_operator == "innum" and float(expected) in {float(item) for item in prior_expected}:
                conditions[index] = condition
                return
            if prior_operator in {"gte", "lte"}:
                conditions[index] = condition
                return
        if operator == "innum":
            if prior_operator == "eqnum" and float(prior_expected) in {float(item) for item in expected}:
                return
            if prior_operator == "innum":
                intersection = sorted(
                    {
                        float(item)
                        for item in prior_expected
                        if float(item) in {float(value) for value in expected}
                    }
                )
                if not intersection:
                    return
                conditions[index] = (field, "innum", intersection)
                return
    conditions.append(condition)


def _normalize_conditions(conditions: Iterable[Tuple[str, str, Any]]) -> List[Tuple[str, str, Any]]:
    normalized: List[Tuple[str, str, Any]] = []
    for condition in conditions:
        _append_or_replace(normalized, condition)
    return sorted(normalized, key=_condition_sort_key)


def _condition_identity(conditions: Sequence[Tuple[str, str, Any]]) -> Tuple[Tuple[str, str, str], ...]:
    return tuple(
        (field, operator, json.dumps(expected, sort_keys=True))
        for field, operator, expected in sorted(conditions, key=_condition_sort_key)
    )


def _build_spec(
    row: Dict[str, Any],
    source: SourceMetadata,
) -> Dict[str, Any]:
    side = str(row.get("side") or "").strip().lower()
    tone = "bullish" if side == "bull" else "bearish"
    overlay_conditions = [_parse_condition_expr(expr) for expr in row.get("conditions") or []]
    full_conditions = _normalize_conditions([*_base_conditions(side, source.event_profile), *overlay_conditions])
    condition_summary = " AND ".join(_condition_label(condition) for condition in full_conditions)
    key = "_".join(
        [
            "consecutive",
            source.contract_key,
            str(row.get("timespan") or "").strip(),
            side,
            _slugify(condition_summary),
        ]
    )
    return {
        "key": key,
        "timespan": str(row.get("timespan") or "").strip(),
        "tone": tone,
        "label": "Consecutive-move reversal edge",
        "full_label": f"{str(row.get('timespan') or '').strip()} {tone} consecutive-move edge",
        "hit_rate": round(float(row.get("hit_100bp") or 0.0), 4),
        "sample_size": int(row.get("n") or 0),
        "target_pct": 1.0,
        "condition_summary": condition_summary,
        "why_it_matters": (
            "Validated on ca for an 85%+ chance of a consecutive 1.00% move. "
            f"Contract: {source.contract_label}. Event base: {source.event_profile}."
        ),
        "conditions": [[field, operator, expected] for field, operator, expected in full_conditions],
        "source_file": str((RUNS_ROOT / source.run_name / "candidate_findings_85.json").as_posix()),
        "source_run": source.run_name,
        "event_profile": source.event_profile,
        "condition_profile": source.condition_profile,
        "contract_key": source.contract_key,
        "contract_priority": source.contract_priority,
        "trigger_window_min": source.trigger_window_min,
        "trigger_window_max": source.trigger_window_max,
        "run_window_min": source.run_window_min,
        "run_window_max": source.run_window_max,
        "trigger_min_move": round(source.trigger_min_move, 4),
        "condition_count": len(full_conditions),
        "_identity": _condition_identity(full_conditions),
    }


def _load_candidate_specs() -> List[Dict[str, Any]]:
    merged: Dict[Tuple[Tuple[str, str, str], ...], Dict[str, Any]] = {}
    for run_name in SOURCE_RUNS:
        metadata = _load_source_metadata(run_name)
        if metadata is None:
            continue
        findings_path = RUNS_ROOT / run_name / "candidate_findings_85.json"
        if not findings_path.exists():
            continue
        rows = _read_json(findings_path)
        if not isinstance(rows, list):
            continue
        for row in rows:
            if not isinstance(row, dict):
                continue
            spec = _build_spec(row, metadata)
            prior = merged.get(spec["_identity"])
            sort_key = (
                spec["contract_priority"],
                -float(spec["hit_rate"]),
                -int(spec["sample_size"]),
                int(spec["condition_count"]),
                str(spec["source_run"]),
            )
            if prior is None:
                merged[spec["_identity"]] = spec
                continue
            prior_key = (
                prior["contract_priority"],
                -float(prior["hit_rate"]),
                -int(prior["sample_size"]),
                int(prior["condition_count"]),
                str(prior["source_run"]),
            )
            if sort_key < prior_key:
                merged[spec["_identity"]] = spec
    return list(merged.values())


def _slot_sort_key(spec: Dict[str, Any]) -> Tuple[int, float, int, int, str]:
    return (
        int(spec["contract_priority"]),
        -float(spec["hit_rate"]),
        -int(spec["sample_size"]),
        int(spec["condition_count"]),
        str(spec["condition_summary"]),
    )


def _trim_for_output(spec: Dict[str, Any], *, slot_rank: int) -> Dict[str, Any]:
    payload = dict(spec)
    payload["slot_rank"] = slot_rank
    payload.pop("_identity", None)
    payload.pop("condition_count", None)
    return payload


def _build_output_sets(specs: Sequence[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    promoted: List[Dict[str, Any]] = []
    watchlist: List[Dict[str, Any]] = []
    grouped: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    for spec in specs:
        key = (str(spec["timespan"]), str(spec["tone"]))
        grouped.setdefault(key, []).append(spec)
    promoted_identities = set()
    for key in sorted(grouped):
        ordered = sorted(grouped[key], key=_slot_sort_key)
        if not ordered:
            continue
        promoted.append(_trim_for_output(ordered[0], slot_rank=1))
        promoted_identities.add(ordered[0]["_identity"])
        slot_rank = 2
        for spec in ordered:
            if spec["_identity"] in promoted_identities:
                continue
            if slot_rank > WATCHLIST_CAP_PER_SLOT + 1:
                break
            watchlist.append(_trim_for_output(spec, slot_rank=slot_rank))
            slot_rank += 1
    promoted.sort(key=lambda item: (str(item["timespan"]), str(item["tone"]), item["slot_rank"]))
    watchlist.sort(key=lambda item: (str(item["timespan"]), str(item["tone"]), item["slot_rank"]))
    return promoted, watchlist


def _write_json(path: Path, payload: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(list(payload), indent=2), encoding="utf-8")


def _write_summary(
    path: Path,
    *,
    promoted: Sequence[Dict[str, Any]],
    watchlist: Sequence[Dict[str, Any]],
) -> None:
    lines = [
        "# REV Consecutive-Move Promotion",
        "",
        f"- Generated: `{datetime.now(timezone.utc).isoformat()}`",
        f"- Source runs: `{len(SOURCE_RUNS)}`",
        "- Contract target: `85%+ chance of a consecutive 1.00% move`",
        "- Preferred live contract: `trigger in candles 1-5 with >=0.50% move, then every close in candles 10-15 still holds >=1.00%`",
        "- Fallback contracts: `trigger100bp_hold100`, `immediate_run13`",
        f"- Promoted slots: `{len(promoted)}`",
        f"- Watchlist entries: `{len(watchlist)}`",
        "",
        "## Promoted Leaders",
        "",
    ]
    for item in promoted:
        lines.append(
            f"- `{item['timespan']} {item['tone']}` `{item['condition_summary']}`"
            f" | `hit100={item['hit_rate']:.4f}` | `n={item['sample_size']}`"
            f" | `{item['contract_key']}`"
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    specs = _load_candidate_specs()
    promoted, watchlist = _build_output_sets(specs)
    promoted_path = PROMOTION_DIR / PROMOTED_FILENAME
    watchlist_path = PROMOTION_DIR / WATCHLIST_FILENAME
    site_promoted_path = SITE_DATA_DIR / PROMOTED_FILENAME
    site_watchlist_path = SITE_DATA_DIR / WATCHLIST_FILENAME
    summary_path = PROMOTION_DIR / "promotion_summary.md"

    _write_json(promoted_path, promoted)
    _write_json(watchlist_path, watchlist)
    _write_json(site_promoted_path, promoted)
    _write_json(site_watchlist_path, watchlist)
    _write_summary(summary_path, promoted=promoted, watchlist=watchlist)

    print(f"wrote_promoted={promoted_path}")
    print(f"wrote_watchlist={watchlist_path}")
    print(f"wrote_site_promoted={site_promoted_path}")
    print(f"wrote_site_watchlist={site_watchlist_path}")
    print(f"wrote_summary={summary_path}")


if __name__ == "__main__":
    main()
