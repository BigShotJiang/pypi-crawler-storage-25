from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    HRFlowable,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


def money(value: float) -> str:
    return f"${value:,.0f}"


def pct(value: float) -> str:
    return f"{value * 100:.1f}%"


def intfmt(value: float | int) -> str:
    return f"{int(round(float(value))):,}"


def table_style(header_bg: colors.Color = colors.HexColor("#0B3954")) -> TableStyle:
    return TableStyle(
        [
            ("BACKGROUND", (0, 0), (-1, 0), header_bg),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
            ("FONTSIZE", (0, 0), (-1, -1), 8.8),
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#A7B1BC")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F5F8FB")]),
            ("LEFTPADDING", (0, 0), (-1, -1), 5),
            ("RIGHTPADDING", (0, 0), (-1, -1), 5),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]
    )


def section_banner(text: str) -> Table:
    t = Table([[text]], colWidths=[7.0 * inch], rowHeights=[0.32 * inch])
    t.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#0B3954")),
                ("TEXTCOLOR", (0, 0), (-1, -1), colors.white),
                ("FONTNAME", (0, 0), (-1, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 11),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]
        )
    )
    return t


def build_report(data: dict[str, Any], output: Path, report_date: str) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)

    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="TitleLarge",
            parent=styles["Title"],
            fontName="Helvetica-Bold",
            fontSize=24,
            textColor=colors.white,
            spaceAfter=4,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Body",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=10,
            leading=13.5,
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Small",
            parent=styles["BodyText"],
            fontName="Helvetica",
            fontSize=8.6,
            leading=11,
            textColor=colors.HexColor("#334E68"),
        )
    )

    doc = SimpleDocTemplate(
        str(output),
        pagesize=LETTER,
        leftMargin=0.65 * inch,
        rightMargin=0.65 * inch,
        topMargin=0.72 * inch,
        bottomMargin=0.7 * inch,
        title="FUDSTOP Deep Assessment Report",
        author="Codex",
    )

    def header_footer(canvas, _doc):
        canvas.saveState()
        canvas.setStrokeColor(colors.HexColor("#0B3954"))
        canvas.setLineWidth(2)
        canvas.line(0.65 * inch, 10.78 * inch, 7.85 * inch, 10.78 * inch)
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#486581"))
        canvas.drawString(0.65 * inch, 0.45 * inch, "FUDSTOP Deep Endpoint and Valuation Assessment")
        canvas.drawRightString(7.85 * inch, 0.45 * inch, f"Page {_doc.page}")
        canvas.drawRightString(7.85 * inch, 10.75 * inch, report_date)
        canvas.restoreState()

    snap = data["snapshot"]
    val = data["valuation"]
    method_counts = data["method_counts"]
    top_segments = data["top_path_segments"]
    top_route_files = data["top_route_files"]
    top_complex = data["top_complex_endpoints"]
    option_stats = snap.get("endpoint_option_stats", {})

    story: list[Any] = []

    hero = Table(
        [[Paragraph("<font color='white'><b>FUDSTOP Deep Assessment Report</b></font>", styles["TitleLarge"])]],
        colWidths=[7.0 * inch],
        rowHeights=[0.72 * inch],
    )
    hero.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#102A43")),
                ("LEFTPADDING", (0, 0), (-1, -1), 14),
                ("TOPPADDING", (0, 0), (-1, -1), 12),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )
    story.append(hero)
    story.append(Spacer(1, 8))
    story.append(Paragraph(f"Report Date: <b>{report_date}</b>", styles["Body"]))
    story.append(
        Paragraph(
            "This assessment includes full endpoint inventory coverage, route-option complexity, monetization surface scan, "
            "data-ingestion depth, and a reconciled valuation model.",
            styles["Body"],
        )
    )
    story.append(HRFlowable(width="100%", thickness=1.0, color=colors.HexColor("#9FB3C8"), spaceBefore=2, spaceAfter=8))

    story.append(section_banner("1) Executive Valuation"))
    story.append(Spacer(1, 6))
    cards = Table(
        [
            ["Final Range", "Central Value", "Suggested Ask Band", "Monetization Readiness"],
            [
                f"{money(val['final_range_low'])} - {money(val['final_range_high'])}",
                money(val["reconciled_mid"]),
                f"{money(val['ask_band_low'])} - {money(val['ask_band_high'])}",
                pct(snap["readiness_score"]),
            ],
        ],
        colWidths=[1.9 * inch, 1.45 * inch, 2.0 * inch, 1.65 * inch],
    )
    cards.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D9E2EC")),
                ("BACKGROUND", (0, 1), (-1, 1), colors.HexColor("#F7FBFF")),
                ("GRID", (0, 0), (-1, -1), 0.6, colors.HexColor("#9FB3C8")),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTNAME", (0, 1), (-1, -1), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 9.2),
                ("FONTSIZE", (0, 1), (-1, -1), 10.2),
            ]
        )
    )
    story.append(cards)
    story.append(Spacer(1, 8))
    story.append(
        Paragraph(
            f"Replacement anchor (as-is): {money(val['replacement_range_low'])} to {money(val['replacement_range_high'])}. "
            f"Commercialized expected value: {money(val['commercialized_expected'])}. "
            f"Strategic mid premium: {money(val['strategic_mid'])}.",
            styles["Body"],
        )
    )

    story.append(section_banner("2) Coverage Snapshot"))
    story.append(Spacer(1, 6))
    coverage_rows = [
        ["Metric", "Value"],
        ["Python files", intfmt(snap["python_files"])],
        ["Python LOC", intfmt(snap["python_lines_total"])],
        ["Public API domains", intfmt(snap["api_domains_public_count"])],
        ["Unique table targets", intfmt(snap["unique_table_targets"])],
        ["Upsert call sites", intfmt(snap["upsert_calls"])],
        ["Frontend templates", intfmt(snap["templates_html_count"])],
        ["Static JS files", intfmt(snap["static_js_count"])],
        ["Static CSS files", intfmt(snap["static_css_count"])],
        ["Total endpoints inventoried", intfmt(snap["endpoint_count_total"])],
        ["Monetization endpoints", intfmt(snap["endpoint_monetization_count"])],
        ["Avg endpoint complexity", f"{snap['endpoint_avg_complexity']:.2f}"],
    ]
    coverage_table = Table(coverage_rows, colWidths=[3.65 * inch, 2.65 * inch])
    coverage_table.setStyle(table_style())
    story.append(coverage_table)
    story.append(Spacer(1, 8))

    options_rows = [
        ["Endpoint Option Surface", "Value"],
        ["Endpoints with query options", intfmt(option_stats.get("with_query", 0))],
        ["Endpoints with path params", intfmt(option_stats.get("with_path", 0))],
        ["Endpoints with form inputs", intfmt(option_stats.get("with_form", 0))],
        ["Endpoints with request body", intfmt(option_stats.get("with_body", 0))],
        ["Endpoints with dependencies", intfmt(option_stats.get("with_depends", 0))],
        ["Total required params", intfmt(option_stats.get("required_params_total", 0))],
        ["Total optional params", intfmt(option_stats.get("optional_params_total", 0))],
        ["Avg params/endpoint", f"{option_stats.get('avg_params_per_endpoint', 0):.2f}"],
        ["P95 complexity", f"{option_stats.get('p95_complexity', 0):.2f}"],
        ["Max complexity", f"{option_stats.get('max_complexity', 0):.2f}"],
    ]
    options_table = Table(options_rows, colWidths=[3.65 * inch, 2.65 * inch])
    options_table.setStyle(table_style(colors.HexColor("#1F7A8C")))
    story.append(options_table)

    story.append(PageBreak())
    story.append(section_banner("3) Endpoint Universe"))
    story.append(Spacer(1, 6))
    method_rows = [["Method", "Count"]] + [[k, intfmt(v)] for k, v in sorted(method_counts.items(), key=lambda kv: kv[1], reverse=True)]
    method_table = Table(method_rows, colWidths=[1.8 * inch, 1.3 * inch])
    method_table.setStyle(table_style())
    story.append(method_table)
    story.append(Spacer(1, 8))

    seg_rows = [["Top Path Segment", "Endpoints"]] + [[seg, intfmt(cnt)] for seg, cnt in top_segments[:15]]
    seg_table = Table(seg_rows, colWidths=[3.65 * inch, 2.65 * inch])
    seg_table.setStyle(table_style())
    story.append(seg_table)
    story.append(Spacer(1, 8))

    file_rows = [["Top Route File", "Endpoints"]] + [[f, intfmt(c)] for f, c in top_route_files[:15]]
    file_table = Table(file_rows, colWidths=[4.8 * inch, 1.5 * inch])
    file_table.setStyle(table_style())
    story.append(file_table)

    story.append(PageBreak())
    story.append(section_banner("4) Endpoint Complexity and Options"))
    story.append(Spacer(1, 6))
    story.append(
        Paragraph(
            "Complexity score weights route options: total params + body/form/path/query/depends weights. "
            "Higher scores generally indicate richer endpoint options and integration complexity.",
            styles["Body"],
        )
    )
    cx_rows = [["Score", "Method", "Path", "File:Line", "Params"]]
    for e in top_complex[:20]:
        method_value = e.get("methods", "")
        method_label = ",".join(method_value) if isinstance(method_value, list) else str(method_value)
        score = (
            e.get("params_total", 0)
            + 2 * e.get("params_body", 0)
            + 1.5 * e.get("params_form", 0)
            + 1.2 * e.get("params_query", 0)
            + 1.2 * e.get("params_path", 0)
            + 2 * e.get("params_depends", 0)
        )
        cx_rows.append(
            [
                f"{score:.1f}",
                method_label,
                e.get("full_path", ""),
                f"{e.get('file','')}:{e.get('line',0)}",
                intfmt(e.get("params_total", 0)),
            ]
        )
    cx_table = Table(cx_rows, colWidths=[0.55 * inch, 0.65 * inch, 2.35 * inch, 2.6 * inch, 0.6 * inch])
    cx_table.setStyle(table_style())
    story.append(cx_table)

    story.append(PageBreak())
    story.append(section_banner("5) Monetization Ease Assessment"))
    story.append(Spacer(1, 6))
    ease_rows = [
        ["Signal", "Evidence"],
        ["Billing and checkout surface", f"{intfmt(snap['endpoint_monetization_count'])} monetization endpoints"],
        ["Frontend conversion surface", f"{intfmt(snap['templates_html_count'])} templates + {intfmt(snap['static_js_count'])} JS + {intfmt(snap['static_css_count'])} CSS"],
        ["Data product depth", f"{intfmt(snap['api_domains_public_count'])} API domains + {intfmt(snap['unique_table_targets'])} table targets"],
        ["Operational ingestion", f"{intfmt(snap['upsert_calls'])} upsert call sites"],
        ["Overall readiness score", pct(snap["readiness_score"])],
    ]
    ease_table = Table(ease_rows, colWidths=[2.9 * inch, 3.4 * inch])
    ease_table.setStyle(table_style())
    story.append(ease_table)
    story.append(Spacer(1, 8))

    go_live_rows = [
        ["Window", "Practical Monetization Milestones"],
        ["Week 1", "Launch one paid tier, stripe/webhook smoke tests, API key provisioning, checkout QA."],
        ["Week 2", "Publish endpoint docs + examples, add usage metering, onboard 3-5 pilot users."],
        ["Days 30-60", "Tighten retention loops, expand alerts/signals packaging, enterprise pilot outreach."],
    ]
    gl_table = Table(go_live_rows, colWidths=[1.1 * inch, 5.2 * inch])
    gl_table.setStyle(table_style())
    story.append(gl_table)

    story.append(section_banner("6) Deductions and Caveats"))
    story.append(Spacer(1, 6))
    for line in [
        "No premium assigned for verified customer contracts unless provided.",
        "Data licensing rights must support commercial resale for highest valuation capture.",
        "Operational QA, security hardening, and documentation quality still affect close price.",
        "This assessment is analytical guidance, not legal/tax/investment advice.",
    ]:
        story.append(Paragraph(f"- {line}", styles["Body"]))

    story.append(Spacer(1, 8))
    story.append(section_banner("7) Artifacts Produced"))
    story.append(Spacer(1, 6))
    artifacts = [
        r"Full endpoint inventory CSV: c:\code\fudstop\output\reports\endpoint_inventory_full.csv",
        r"Monetization endpoint CSV: c:\code\fudstop\output\reports\endpoint_inventory_monetization.csv",
        r"Deep assessment JSON: c:\code\fudstop\tmp\pdfs\repo_deep_assessment_v1.json",
    ]
    for a in artifacts:
        story.append(Paragraph(f"- {a}", styles["Small"]))

    story.append(Spacer(1, 8))
    story.append(
        Paragraph(
            "Prepared from static analysis of repository code and route decorators. "
            "All counts are reproducible from included scripts and JSON artifacts.",
            styles["Small"],
        )
    )

    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate deep valuation/endpoint assessment PDF.")
    parser.add_argument(
        "--input",
        type=Path,
        default=Path(r"c:\code\fudstop\tmp\pdfs\repo_deep_assessment_v2.json"),
        help="Input deep assessment JSON.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(r"c:\code\fudstop\output\pdf\FUDSTOP_Deep_Assessment_Report_v2_2026-03-03.pdf"),
        help="Output PDF path.",
    )
    parser.add_argument(
        "--report-date",
        type=str,
        default=datetime.now().strftime("%B %d, %Y"),
        help="Report date label.",
    )
    args = parser.parse_args()

    data = json.loads(args.input.read_text(encoding="utf-8"))
    build_report(data, args.output, args.report_date)
    print(str(args.output))


if __name__ == "__main__":
    main()
