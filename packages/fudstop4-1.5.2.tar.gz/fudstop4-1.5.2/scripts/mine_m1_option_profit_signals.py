#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd

import mine_m1_sustained_option_signals as base


DEFAULT_START_DATE = "2026-01-02"
DEFAULT_END_DATE = "2026-03-12"
DEFAULT_VAL_DAYS = 10
DEFAULT_MIN_N = 20
DEFAULT_TARGET_HIT = 0.85
DEFAULT_TRIGGER_PCT = 0.03
DEFAULT_TARGET_PCT = 0.05
DEFAULT_HOLD_PCT = 0.02
DEFAULT_MAX_ADVERSE_PCT = 0.05
DEFAULT_MOMENTUM_PCT = 0.08
DEFAULT_TARGET_WINDOW = "1_5"
DEFAULT_HOLD_BAR = 3
DEFAULT_MIN_ENTRY_PRICE = 0.20
DEFAULT_MIN_ENTRY_VOLUME = 0
DEFAULT_BASE_PROFILE = "reversal"


def parse_tickers(raw: str) -> list[str]:
    values = [value.strip().upper() for value in str(raw or "").split(",") if value.strip()]
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return ordered


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Mine 1-minute historical CA signal families using actual option_candles returns "
            "instead of raw underlying-percent outcomes."
        )
    )
    parser.add_argument("--host", default="")
    parser.add_argument("--port", type=int, default=5432)
    parser.add_argument("--user", default="")
    parser.add_argument("--password", default="")
    parser.add_argument("--database", default="")
    parser.add_argument("--start-date", default=DEFAULT_START_DATE)
    parser.add_argument("--end-date", default=DEFAULT_END_DATE)
    parser.add_argument("--val-days", type=int, default=DEFAULT_VAL_DAYS)
    parser.add_argument("--min-n", type=int, default=DEFAULT_MIN_N)
    parser.add_argument("--min-val-n", type=int, default=6)
    parser.add_argument("--target-hit", type=float, default=DEFAULT_TARGET_HIT)
    parser.add_argument("--seed-hit", type=float, default=0.62)
    parser.add_argument("--val-floor", type=float, default=0.70)
    parser.add_argument("--trigger-pct", type=float, default=DEFAULT_TRIGGER_PCT)
    parser.add_argument("--target-pct", type=float, default=DEFAULT_TARGET_PCT)
    parser.add_argument("--hold-pct", type=float, default=DEFAULT_HOLD_PCT)
    parser.add_argument("--max-adverse-pct", type=float, default=DEFAULT_MAX_ADVERSE_PCT)
    parser.add_argument("--momentum-pct", type=float, default=DEFAULT_MOMENTUM_PCT)
    parser.add_argument("--target-window", choices=("1_5", "1_10"), default=DEFAULT_TARGET_WINDOW)
    parser.add_argument("--hold-bar", type=int, choices=(3, 5), default=DEFAULT_HOLD_BAR)
    parser.add_argument("--min-entry-price", type=float, default=DEFAULT_MIN_ENTRY_PRICE)
    parser.add_argument("--min-entry-volume", type=int, default=DEFAULT_MIN_ENTRY_VOLUME)
    parser.add_argument("--tickers", default="")
    parser.add_argument("--base-profile", choices=("reversal", "reclaim", "continuation", "expansion"), default=DEFAULT_BASE_PROFILE)
    parser.add_argument("--max-k", type=int, default=4)
    parser.add_argument("--top-seeds", type=int, default=80)
    parser.add_argument("--top-per-depth", type=int, default=60)
    parser.add_argument("--top-final", type=int, default=30)
    parser.add_argument("--min-trigger12-rate", type=float, default=0.0)
    parser.add_argument("--min-trigger1-rate", type=float, default=0.0)
    parser.add_argument("--min-sustain75-rate", type=float, default=0.0)
    parser.add_argument("--min-avg-best-ret", type=float, default=0.0)
    parser.add_argument("--min-avg-hold5-ret", type=float, default=0.0)
    parser.add_argument("--min-wilson-lb", type=float, default=0.0)
    parser.add_argument("--min-val-wilson-lb", type=float, default=0.0)
    parser.add_argument("--min-tickers", type=int, default=0)
    parser.add_argument("--min-val-tickers", type=int, default=0)
    parser.add_argument("--output-dir", default="")
    return parser.parse_args()


def build_option_metric_query(
    *,
    start_dt: datetime,
    end_dt: datetime,
    min_entry_price: float,
    min_entry_volume: int,
    tickers: list[str],
) -> str:
    ticker_clause = ""
    if tickers:
        joined = ", ".join("'" + ticker.replace("'", "''") + "'" for ticker in tickers)
        ticker_clause = f" AND ticker IN ({joined})"
    return f"""
WITH option_base AS (
    SELECT
        ticker,
        option_id,
        call_put,
        strike,
        expiry,
        ts,
        EXTRACT(EPOCH FROM (ts AT TIME ZONE 'America/New_York'))::bigint AS ts_epoch,
        c AS opt_c,
        h AS opt_h,
        l AS opt_l,
        v AS opt_v,
        lead(h, 1) OVER w AS h1,
        lead(h, 2) OVER w AS h2,
        lead(h, 3) OVER w AS h3,
        lead(c, 3) OVER w AS c3,
        lead(c, 5) OVER w AS c5,
        max(h) OVER w_1_5 AS max_h_1_5,
        max(h) OVER w_1_10 AS max_h_1_10,
        min(l) OVER w_1_3 AS min_l_1_3,
        count(*) OVER w_1_5 AS n_1_5,
        count(*) OVER w_1_10 AS n_1_10,
        count(*) OVER w_1_3 AS n_1_3
    FROM option_candles
    WHERE timespan = '1m'
      AND ts >= TIMESTAMP '{start_dt.strftime("%Y-%m-%d %H:%M:%S")}'
      AND ts < TIMESTAMP '{(end_dt + timedelta(minutes=10)).strftime("%Y-%m-%d %H:%M:%S")}'
      {ticker_clause}
    WINDOW
        w AS (PARTITION BY option_id ORDER BY ts),
        w_1_3 AS (PARTITION BY option_id ORDER BY ts ROWS BETWEEN 1 FOLLOWING AND 3 FOLLOWING),
        w_1_5 AS (PARTITION BY option_id ORDER BY ts ROWS BETWEEN 1 FOLLOWING AND 5 FOLLOWING),
        w_1_10 AS (PARTITION BY option_id ORDER BY ts ROWS BETWEEN 1 FOLLOWING AND 10 FOLLOWING)
)
SELECT
    ticker,
    ts_epoch,
    call_put,
    option_id,
    strike,
    expiry,
    opt_c,
    COALESCE(opt_v, 0) AS opt_v,
    (expiry - ts::date) AS dte,
    CASE WHEN h1 IS NOT NULL AND opt_c > 0 THEN h1 / opt_c - 1.0 END AS trigger1_ret,
    CASE WHEN COALESCE(GREATEST(h1, h2), h1, h2) IS NOT NULL AND opt_c > 0
         THEN COALESCE(GREATEST(h1, h2), h1, h2) / opt_c - 1.0 END AS trigger12_ret,
    CASE WHEN COALESCE(GREATEST(h1, h2, h3), h1, h2, h3) IS NOT NULL AND opt_c > 0
         THEN COALESCE(GREATEST(h1, h2, h3), h1, h2, h3) / opt_c - 1.0 END AS trigger13_ret,
    CASE WHEN max_h_1_5 IS NOT NULL AND opt_c > 0 THEN max_h_1_5 / opt_c - 1.0 END AS best_ret_1_5,
    CASE WHEN max_h_1_10 IS NOT NULL AND opt_c > 0 THEN max_h_1_10 / opt_c - 1.0 END AS best_ret_1_10,
    CASE WHEN c3 IS NOT NULL AND opt_c > 0 THEN c3 / opt_c - 1.0 END AS hold_ret_3,
    CASE WHEN c5 IS NOT NULL AND opt_c > 0 THEN c5 / opt_c - 1.0 END AS hold_ret_5,
    CASE WHEN min_l_1_3 IS NOT NULL AND opt_c > 0 THEN min_l_1_3 / opt_c - 1.0 END AS adverse_ret_1_3
FROM option_base
WHERE opt_c >= {float(min_entry_price)}
  AND COALESCE(opt_v, 0) >= {int(min_entry_volume)}
  AND n_1_3 = 3
  AND n_1_5 = 5
  AND n_1_10 = 10
ORDER BY ticker, ts_epoch, call_put, dte, strike
""".strip()


def load_option_metrics(
    conn,
    *,
    start_dt: datetime,
    end_dt: datetime,
    min_entry_price: float,
    min_entry_volume: int,
    tickers: list[str],
) -> tuple[pd.DataFrame, str]:
    query = build_option_metric_query(
        start_dt=start_dt,
        end_dt=end_dt,
        min_entry_price=min_entry_price,
        min_entry_volume=min_entry_volume,
        tickers=tickers,
    )
    df = pd.read_sql_query(query, conn)
    return df, query


def attach_nearest_option_metrics(history: pd.DataFrame, option_metrics: pd.DataFrame) -> pd.DataFrame:
    if history.empty:
        return history.copy()
    if option_metrics.empty:
        out = history.copy()
        for prefix in ("bull", "bear"):
            out[f"{prefix}_option_id"] = np.nan
            out[f"{prefix}_strike"] = np.nan
            out[f"{prefix}_expiry"] = None
            out[f"{prefix}_dte"] = np.nan
            out[f"{prefix}_entry_price"] = np.nan
            out[f"{prefix}_entry_volume"] = np.nan
            out[f"{prefix}_trigger1_ret"] = np.nan
            out[f"{prefix}_trigger12_ret"] = np.nan
            out[f"{prefix}_trigger13_ret"] = np.nan
            out[f"{prefix}_best_ret_1_5"] = np.nan
            out[f"{prefix}_best_ret_1_10"] = np.nan
            out[f"{prefix}_hold_ret_3"] = np.nan
            out[f"{prefix}_hold_ret_5"] = np.nan
            out[f"{prefix}_adverse_ret_1_3"] = np.nan
        return out

    option_metrics = option_metrics.copy()
    option_metrics["ticker"] = option_metrics["ticker"].astype(str)
    option_metrics["ts_epoch"] = pd.to_numeric(option_metrics["ts_epoch"], errors="coerce").fillna(0).astype("int64")
    option_metrics["strike"] = pd.to_numeric(option_metrics["strike"], errors="coerce")
    option_metrics["dte"] = pd.to_numeric(option_metrics["dte"], errors="coerce")

    numeric_cols = [
        "option_id",
        "strike",
        "dte",
        "opt_c",
        "opt_v",
        "trigger1_ret",
        "trigger12_ret",
        "trigger13_ret",
        "best_ret_1_5",
        "best_ret_1_10",
        "hold_ret_3",
        "hold_ret_5",
        "adverse_ret_1_3",
    ]
    for col in numeric_cols:
        option_metrics[col] = pd.to_numeric(option_metrics[col], errors="coerce")

    lookup: dict[tuple[str, int, str], dict[str, np.ndarray]] = {}
    for (ticker, ts_epoch, call_put), group in option_metrics.groupby(["ticker", "ts_epoch", "call_put"], sort=False):
        clean = group.loc[group["dte"].notna() & (group["dte"] >= 0) & group["strike"].notna()].copy()
        if clean.empty:
            continue
        min_dte = float(clean["dte"].min())
        nearest = clean.loc[clean["dte"] == min_dte].copy()
        if nearest.empty:
            continue
        lookup[(str(ticker), int(ts_epoch), str(call_put))] = {
            "option_id": nearest["option_id"].to_numpy(dtype="float64"),
            "strike": nearest["strike"].to_numpy(dtype="float64"),
            "expiry": nearest["expiry"].to_numpy(dtype=object),
            "dte": nearest["dte"].to_numpy(dtype="float64"),
            "entry_price": nearest["opt_c"].to_numpy(dtype="float64"),
            "entry_volume": nearest["opt_v"].to_numpy(dtype="float64"),
            "trigger1_ret": nearest["trigger1_ret"].to_numpy(dtype="float64"),
            "trigger12_ret": nearest["trigger12_ret"].to_numpy(dtype="float64"),
            "trigger13_ret": nearest["trigger13_ret"].to_numpy(dtype="float64"),
            "best_ret_1_5": nearest["best_ret_1_5"].to_numpy(dtype="float64"),
            "best_ret_1_10": nearest["best_ret_1_10"].to_numpy(dtype="float64"),
            "hold_ret_3": nearest["hold_ret_3"].to_numpy(dtype="float64"),
            "hold_ret_5": nearest["hold_ret_5"].to_numpy(dtype="float64"),
            "adverse_ret_1_3": nearest["adverse_ret_1_3"].to_numpy(dtype="float64"),
        }

    out = history.copy()
    n_rows = len(out)
    template_float = lambda: np.full(n_rows, np.nan, dtype="float64")
    template_obj = lambda: np.full(n_rows, None, dtype=object)

    assigned: dict[str, np.ndarray] = {}
    for prefix in ("bull", "bear"):
        assigned[f"{prefix}_option_id"] = template_float()
        assigned[f"{prefix}_strike"] = template_float()
        assigned[f"{prefix}_expiry"] = template_obj()
        assigned[f"{prefix}_dte"] = template_float()
        assigned[f"{prefix}_entry_price"] = template_float()
        assigned[f"{prefix}_entry_volume"] = template_float()
        assigned[f"{prefix}_trigger1_ret"] = template_float()
        assigned[f"{prefix}_trigger12_ret"] = template_float()
        assigned[f"{prefix}_trigger13_ret"] = template_float()
        assigned[f"{prefix}_best_ret_1_5"] = template_float()
        assigned[f"{prefix}_best_ret_1_10"] = template_float()
        assigned[f"{prefix}_hold_ret_3"] = template_float()
        assigned[f"{prefix}_hold_ret_5"] = template_float()
        assigned[f"{prefix}_adverse_ret_1_3"] = template_float()

    for idx, row in enumerate(out[["ticker", "ts_epoch", "c"]].itertuples(index=False, name=None)):
        ticker, ts_epoch, underlying_close = str(row[0]), int(row[1]), float(row[2] or 0.0)
        if not np.isfinite(underlying_close):
            continue
        for prefix, call_put in (("bull", "call"), ("bear", "put")):
            bucket = lookup.get((ticker, ts_epoch, call_put))
            if not bucket:
                continue
            strike_array = bucket["strike"]
            if strike_array.size == 0:
                continue
            nearest_idx = int(np.abs(strike_array - underlying_close).argmin())
            assigned[f"{prefix}_option_id"][idx] = bucket["option_id"][nearest_idx]
            assigned[f"{prefix}_strike"][idx] = bucket["strike"][nearest_idx]
            assigned[f"{prefix}_expiry"][idx] = bucket["expiry"][nearest_idx]
            assigned[f"{prefix}_dte"][idx] = bucket["dte"][nearest_idx]
            assigned[f"{prefix}_entry_price"][idx] = bucket["entry_price"][nearest_idx]
            assigned[f"{prefix}_entry_volume"][idx] = bucket["entry_volume"][nearest_idx]
            assigned[f"{prefix}_trigger1_ret"][idx] = bucket["trigger1_ret"][nearest_idx]
            assigned[f"{prefix}_trigger12_ret"][idx] = bucket["trigger12_ret"][nearest_idx]
            assigned[f"{prefix}_trigger13_ret"][idx] = bucket["trigger13_ret"][nearest_idx]
            assigned[f"{prefix}_best_ret_1_5"][idx] = bucket["best_ret_1_5"][nearest_idx]
            assigned[f"{prefix}_best_ret_1_10"][idx] = bucket["best_ret_1_10"][nearest_idx]
            assigned[f"{prefix}_hold_ret_3"][idx] = bucket["hold_ret_3"][nearest_idx]
            assigned[f"{prefix}_hold_ret_5"][idx] = bucket["hold_ret_5"][nearest_idx]
            assigned[f"{prefix}_adverse_ret_1_3"][idx] = bucket["adverse_ret_1_3"][nearest_idx]

    for col, values in assigned.items():
        out[col] = values
    return out


def define_option_outcomes(
    df: pd.DataFrame,
    *,
    trigger_pct: float,
    target_pct: float,
    hold_pct: float,
    max_adverse_pct: float,
    momentum_pct: float,
    target_window: str,
    hold_bar: int,
) -> pd.DataFrame:
    out = df.copy()
    bull_target_col = "bull_best_ret_1_5" if target_window == "1_5" else "bull_best_ret_1_10"
    bear_target_col = "bear_best_ret_1_5" if target_window == "1_5" else "bear_best_ret_1_10"
    bull_hold_col = "bull_hold_ret_3" if hold_bar == 3 else "bull_hold_ret_5"
    bear_hold_col = "bear_hold_ret_3" if hold_bar == 3 else "bear_hold_ret_5"

    out["bull_success"] = (
        out["bull_trigger13_ret"].ge(trigger_pct).fillna(False)
        & out[bull_target_col].ge(target_pct).fillna(False)
        & out[bull_hold_col].ge(hold_pct).fillna(False)
        & out["bull_adverse_ret_1_3"].ge(-max_adverse_pct).fillna(False)
    )
    out["bear_success"] = (
        out["bear_trigger13_ret"].ge(trigger_pct).fillna(False)
        & out[bear_target_col].ge(target_pct).fillna(False)
        & out[bear_hold_col].ge(hold_pct).fillna(False)
        & out["bear_adverse_ret_1_3"].ge(-max_adverse_pct).fillna(False)
    )
    out["bull_trigger1"] = out["bull_trigger1_ret"].ge(trigger_pct).fillna(False)
    out["bull_trigger12"] = out["bull_trigger12_ret"].ge(trigger_pct).fillna(False)
    out["bear_trigger1"] = out["bear_trigger1_ret"].ge(trigger_pct).fillna(False)
    out["bear_trigger12"] = out["bear_trigger12_ret"].ge(trigger_pct).fillna(False)
    out["bull_hit75"] = out["bull_best_ret_1_10"].ge(momentum_pct).fillna(False)
    out["bear_hit75"] = out["bear_best_ret_1_10"].ge(momentum_pct).fillna(False)
    out["best_up_ret_1_10"] = out["bull_best_ret_1_10"]
    out["best_down_ret_1_10"] = out["bear_best_ret_1_10"]
    out["hold_up_ret_5"] = out["bull_hold_ret_5"] if hold_bar == 5 else out["bull_hold_ret_3"]
    out["hold_down_ret_5"] = out["bear_hold_ret_5"] if hold_bar == 5 else out["bear_hold_ret_3"]
    out["adverse_bull_ret_1_3"] = out["bull_adverse_ret_1_3"]
    out["adverse_bear_ret_1_3"] = out["bear_adverse_ret_1_3"]
    return out


def build_summary(
    *,
    args: argparse.Namespace,
    split_date: date,
    total_rows: int,
    scorable_rows: int,
    bullish_base_count: int,
    bearish_base_count: int,
    bullish_base_rate: float,
    bearish_base_rate: float,
    bullish_results,
    bearish_results,
) -> str:
    lines = [
        f"# M1 Option-Tape Signal Mining - {args.end_date}",
        "",
        "- Scope: `public.ca` + real `option_candles`, `m1`, `regular` session, nearest-DTE nearest-strike call/put chosen at the signal bar.",
        f"- Base profile: `{args.base_profile}`",
        (
            f"- Option contract: trigger `{args.trigger_pct:.2%}` within bars `+1` to `+3`, "
            f"target `{args.target_pct:.2%}` in `{args.target_window.replace('_', ' to +')}`, "
            f"hold `{args.hold_pct:.2%}` at bar `+{args.hold_bar}`, "
            f"max adverse `{args.max_adverse_pct:.2%}` in bars `+1` to `+3`, "
            f"momentum bar `{args.momentum_pct:.2%}` in bars `+1` to `+10`."
        ),
        f"- Option entry floor: price `>= {args.min_entry_price:.2f}`, volume `>= {args.min_entry_volume}`.",
        f"- Validation split: rows dated `{split_date.isoformat()}` and later are holdout validation.",
        f"- Search bar: `overall hit >= {args.target_hit:.0%}`, `n >= {args.min_n}`, `val n >= {args.min_val_n}`.",
        "",
        "## Base Universe",
        "",
        f"- Total enriched `ca` rows loaded: `{total_rows}`",
        f"- Rows with scorable option tape on at least one side: `{scorable_rows}`",
        f"- Bullish base rows: `{bullish_base_count}` | base hit `{bullish_base_rate:.2%}`",
        f"- Bearish base rows: `{bearish_base_count}` | base hit `{bearish_base_rate:.2%}`",
        "",
        "## Top Bullish Families",
        "",
    ]
    if bullish_results:
        for result in bullish_results:
            lines.append(
                f"- `{' AND '.join(result.labels)}` | `n={result.count}` | hit `{result.success_rate:.2%}` | "
                f"train `{result.train_success_rate:.2%}` | val `{result.val_success_rate:.2%}` | "
                f"trigger12 `{result.trigger12_rate:.2%}` | avg best `{result.avg_best_ret:.2%}` | hold `{result.avg_hold5_ret:.2%}`"
            )
    else:
        lines.append("- No bullish families cleared the configured bar.")
    lines.extend(["", "## Top Bearish Families", ""])
    if bearish_results:
        for result in bearish_results:
            lines.append(
                f"- `{' AND '.join(result.labels)}` | `n={result.count}` | hit `{result.success_rate:.2%}` | "
                f"train `{result.train_success_rate:.2%}` | val `{result.val_success_rate:.2%}` | "
                f"trigger12 `{result.trigger12_rate:.2%}` | avg best `{result.avg_best_ret:.2%}` | hold `{result.avg_hold5_ret:.2%}`"
            )
    else:
        lines.append("- No bearish families cleared the configured bar.")
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    env_defaults = base.load_env_defaults()
    start_date = base.parse_date(args.start_date)
    end_date = base.parse_date(args.end_date)
    split_date = end_date - timedelta(days=max(1, int(args.val_days)))
    tickers = parse_tickers(args.tickers)
    output_dir = (
        Path(args.output_dir)
        if str(args.output_dir or "").strip()
        else base.DEFAULT_OUTPUT_ROOT
        / (
            "m1_option_tape_run_"
            f"{end_date.isoformat()}_trigger{int(round(args.trigger_pct * 100))}"
            f"_target{int(round(args.target_pct * 100))}"
            f"_hold{int(round(args.hold_pct * 100))}"
        )
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    start_epoch = base.et_epoch(start_date, 0, 0)
    end_epoch = base.et_epoch(end_date + timedelta(days=1), 0, 0)
    start_dt = datetime(start_date.year, start_date.month, start_date.day, 0, 0)
    end_dt = datetime((end_date + timedelta(days=1)).year, (end_date + timedelta(days=1)).month, (end_date + timedelta(days=1)).day, 0, 0)

    conn = base.db_connect(args, env_defaults)
    try:
        history, base_query = base.load_history(conn, start_epoch=start_epoch, end_epoch=end_epoch)
        option_metrics, option_query = load_option_metrics(
            conn,
            start_dt=start_dt,
            end_dt=end_dt,
            min_entry_price=float(args.min_entry_price),
            min_entry_volume=int(args.min_entry_volume),
            tickers=tickers,
        )
    finally:
        conn.close()

    history = base.add_group_features(history)
    if tickers:
        history = history.loc[history["ticker"].isin(tickers)].copy()
    merged = attach_nearest_option_metrics(history, option_metrics)
    merged = define_option_outcomes(
        merged,
        trigger_pct=float(args.trigger_pct),
        target_pct=float(args.target_pct),
        hold_pct=float(args.hold_pct),
        max_adverse_pct=float(args.max_adverse_pct),
        momentum_pct=float(args.momentum_pct),
        target_window=str(args.target_window),
        hold_bar=int(args.hold_bar),
    )
    merged["is_val"] = merged["date_dt"] >= split_date

    bullish_base = base.build_base_mask(merged, "bullish", args.base_profile)
    bearish_base = base.build_base_mask(merged, "bearish", args.base_profile)
    bullish_df = merged.loc[bullish_base & merged["bull_option_id"].notna()].copy().reset_index(drop=True)
    bearish_df = merged.loc[bearish_base & merged["bear_option_id"].notna()].copy().reset_index(drop=True)

    bullish_results = base.search_side(
        bullish_df,
        side="bullish",
        specs=base.build_specs("bullish"),
        min_n=int(args.min_n),
        min_val_n=int(args.min_val_n),
        seed_hit=float(args.seed_hit),
        val_floor=float(args.val_floor),
        target_hit=float(args.target_hit),
        max_k=int(args.max_k),
        top_seeds=int(args.top_seeds),
        top_per_depth=int(args.top_per_depth),
        top_final=int(args.top_final),
        min_trigger12_rate=float(args.min_trigger12_rate),
        min_trigger1_rate=float(args.min_trigger1_rate),
        min_sustain75_rate=float(args.min_sustain75_rate),
        min_avg_best_ret=float(args.min_avg_best_ret),
        min_avg_hold5_ret=float(args.min_avg_hold5_ret),
        min_wilson_lb=float(args.min_wilson_lb),
        min_val_wilson_lb=float(args.min_val_wilson_lb),
        min_tickers=int(args.min_tickers),
        min_val_tickers=int(args.min_val_tickers),
    )
    bearish_results = base.search_side(
        bearish_df,
        side="bearish",
        specs=base.build_specs("bearish"),
        min_n=int(args.min_n),
        min_val_n=int(args.min_val_n),
        seed_hit=float(args.seed_hit),
        val_floor=float(args.val_floor),
        target_hit=float(args.target_hit),
        max_k=int(args.max_k),
        top_seeds=int(args.top_seeds),
        top_per_depth=int(args.top_per_depth),
        top_final=int(args.top_final),
        min_trigger12_rate=float(args.min_trigger12_rate),
        min_trigger1_rate=float(args.min_trigger1_rate),
        min_sustain75_rate=float(args.min_sustain75_rate),
        min_avg_best_ret=float(args.min_avg_best_ret),
        min_avg_hold5_ret=float(args.min_avg_hold5_ret),
        min_wilson_lb=float(args.min_wilson_lb),
        min_val_wilson_lb=float(args.min_val_wilson_lb),
        min_tickers=int(args.min_tickers),
        min_val_tickers=int(args.min_val_tickers),
    )

    run_metadata = {
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "split_date": split_date.isoformat(),
        "trigger_pct": float(args.trigger_pct),
        "target_pct": float(args.target_pct),
        "hold_pct": float(args.hold_pct),
        "max_adverse_pct": float(args.max_adverse_pct),
        "momentum_pct": float(args.momentum_pct),
        "target_window": str(args.target_window),
        "hold_bar": int(args.hold_bar),
        "base_profile": str(args.base_profile),
        "tickers": tickers,
        "min_entry_price": float(args.min_entry_price),
        "min_entry_volume": int(args.min_entry_volume),
        "min_n": int(args.min_n),
        "min_val_n": int(args.min_val_n),
        "target_hit": float(args.target_hit),
        "seed_hit": float(args.seed_hit),
        "val_floor": float(args.val_floor),
        "min_trigger12_rate": float(args.min_trigger12_rate),
        "min_trigger1_rate": float(args.min_trigger1_rate),
        "min_sustain75_rate": float(args.min_sustain75_rate),
        "min_avg_best_ret": float(args.min_avg_best_ret),
        "min_avg_hold5_ret": float(args.min_avg_hold5_ret),
        "min_wilson_lb": float(args.min_wilson_lb),
        "min_val_wilson_lb": float(args.min_val_wilson_lb),
        "min_tickers": int(args.min_tickers),
        "min_val_tickers": int(args.min_val_tickers),
        "max_k": int(args.max_k),
        "top_seeds": int(args.top_seeds),
        "top_per_depth": int(args.top_per_depth),
        "top_final": int(args.top_final),
        "total_rows": int(len(merged)),
        "scorable_rows": int((merged["bull_option_id"].notna() | merged["bear_option_id"].notna()).sum()),
        "bullish_base_count": int(len(bullish_df)),
        "bearish_base_count": int(len(bearish_df)),
        "bullish_base_hit": float(bullish_df["bull_success"].mean()) if len(bullish_df) else 0.0,
        "bearish_base_hit": float(bearish_df["bear_success"].mean()) if len(bearish_df) else 0.0,
    }

    summary = build_summary(
        args=args,
        split_date=split_date,
        total_rows=int(len(merged)),
        scorable_rows=int((merged["bull_option_id"].notna() | merged["bear_option_id"].notna()).sum()),
        bullish_base_count=int(len(bullish_df)),
        bearish_base_count=int(len(bearish_df)),
        bullish_base_rate=float(bullish_df["bull_success"].mean()) if len(bullish_df) else 0.0,
        bearish_base_rate=float(bearish_df["bear_success"].mean()) if len(bearish_df) else 0.0,
        bullish_results=bullish_results,
        bearish_results=bearish_results,
    )

    (output_dir / "run_metadata.json").write_text(json.dumps(run_metadata, indent=2), encoding="utf-8")
    (output_dir / "base_query.sql").write_text(base_query + "\n", encoding="utf-8")
    (output_dir / "option_metric_query.sql").write_text(option_query + "\n", encoding="utf-8")
    (output_dir / "summary.md").write_text(summary, encoding="utf-8")
    base.write_dataframe(output_dir / "bullish_findings.csv", bullish_results)
    base.write_dataframe(output_dir / "bearish_findings.csv", bearish_results)

    print(summary)
    print(f"Artifacts written to {output_dir}")


if __name__ == "__main__":
    main()
