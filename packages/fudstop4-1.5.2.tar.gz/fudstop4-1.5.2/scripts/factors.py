import asyncio
import os
import sys
from datetime import datetime, time as dtime
from pathlib import Path

import aiohttp
import pandas as pd
import pytz
from more_itertools import chunked

project_dir = str(Path(__file__).resolve().parents[1])
if project_dir not in sys.path:
    sys.path.append(project_dir)

from imports import *  # noqa: F401,F403
from fudstop4._markets.list_sets.ticker_lists import most_active_tickers
from fudstop4.apis.helpers import generate_webull_headers


def _log(message: str) -> None:
    try:
        print(message)
    except OSError:
        pass


TIMESPAN_MAP = {
    "m1": "1min",
    "m5": "5min",
    "m15": "15min",
    "m20": "20min",
    "m30": "30min",
    "m60": "1h",
    "m120": "2h",
    "m240": "4h",
    "w": "week",
    "d": "day",
    "m": "month",
}
TIMESPANS = ["m1", "m5", "m15", "m20", "m30", "m60", "m120", "m240"]
EST = pytz.timezone("US/Eastern")


async def factors(ticker: str, timespan: str = "m1") -> None:
    ticker_id = wbt.ticker_to_id_map.get(ticker)
    if not ticker_id:
        return

    url = (
        "https://quotes-gw.webullfintech.com/api/quote/charts/query-mini"
        f"?type={timespan}&count=800&restorationType=1&loadFactor=1"
        f"&extendTrading=1&tickerId={ticker_id}"
    )

    try:
        async with aiohttp.ClientSession(
            headers=generate_webull_headers(access_token=os.environ.get("ACCESS_TOKEN"))
        ) as session:
            async with session.get(url) as resp:
                payload = await resp.json(content_type=None)
                if resp.status != 200:
                    _log(f"[factors] {ticker} {timespan} request failed: status={resp.status}")
                    return
                factors_payload = [item.get("factors", []) for item in payload]
                flat_factors = [item for sublist in factors_payload for item in sublist]
                if not flat_factors:
                    return

                effective_dates = [
                    datetime.utcfromtimestamp(item.get("effectiveDate")).strftime("%Y-%m-%d")
                    if item.get("effectiveDate") is not None
                    else None
                    for item in flat_factors
                ]
                df = pd.DataFrame(
                    {
                        "dates": effective_dates,
                        "factor_price_pre": [item.get("factorPricePre") for item in flat_factors],
                        "factor_price_post": [item.get("factorPricePost") for item in flat_factors],
                        "factor_volume_pre": [item.get("factorVolumePre") for item in flat_factors],
                        "factor_volume_post": [item.get("factorVolumePost") for item in flat_factors],
                    }
                )
                df["timespan"] = TIMESPAN_MAP.get(timespan)
                df["ticker"] = ticker
                df = df[::-1]
                await db.batch_upsert_dataframe(
                    df,
                    table_name="factors",
                    unique_columns=["ticker", "timespan"],
                )
    except Exception as exc:
        _log(f"[factors] {ticker} {timespan}: {exc}")


def within_market_hours() -> bool:
    now = datetime.now(EST).time()
    return dtime(9, 30) <= now <= dtime(16, 0)


async def run_factors():
    await db.connect()
    while True:
        if not within_market_hours():
            _log("[factors] Outside market hours. Sleeping 1 hour.")
            await asyncio.sleep(60 * 60)
            continue

        _log("[factors] Within market hours. Running tasks.")
        tasks = [factors(ticker, timespan) for ticker in most_active_tickers for timespan in TIMESPANS]
        for batch in chunked(tasks, 7):
            await asyncio.gather(*batch, return_exceptions=True)
            _log(f"[factors] Completed batch of {len(batch)} tasks.")
        _log("[factors] All batches complete for this run. Sleeping until next run.")
        await asyncio.sleep(60 * 60)


if __name__ == "__main__":
    asyncio.run(run_factors())
