#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import html
import json
import os
import re
import subprocess
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, time, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
REPO_ROOT = ROOT.parent
STATUS_DIR = REPO_ROOT / "tmp" / "all_scripts_status"
STATUS_JSON_PATH = STATUS_DIR / "status.json"
STATUS_HTML_PATH = STATUS_DIR / "index.html"

repo_root_str = str(REPO_ROOT)
if repo_root_str not in sys.path:
    sys.path.append(repo_root_str)

from fudstop4.apis.polygonio.polygon_options import PolygonOptions

BATCH_PATH = REPO_ROOT / "ALL SCRIPTS.bat"
TIMESTAMP_PRIORITY = (
    "insertion_timestamp",
    "updated_at",
    "last_heartbeat",
    "changed_at",
    "observed_at",
    "price_5m_ts",
    "event_date",
    "release_time",
)

MANUAL_TABLES: Dict[str, List[str]] = {
    "ca_live_ingest": ["ca", "ca_live"],
    "ipos": ["ipos_upcoming", "ipos_filing"],
    "rise_fall": [
        "rise_1d",
        "rise_5d",
        "rise_5min",
        "rise_premarket",
        "rise_aftermarket",
        "rise_52w",
        "rise_3m",
        "rise_1m",
        "fall_1d",
        "fall_5d",
        "fall_5min",
        "fall_premarket",
        "fall_aftermarket",
        "fall_52w",
        "fall_3m",
        "fall_1m",
    ],
    "iv_skew_new": ["iv_skew"],
    "rsi_conditions_new": ["rsi_conditions"],
    "macd_conditions_new": ["macd_consensus"],
    "cap_img": [],
}

MANUAL_NOTES: Dict[str, str] = {
    "active": "Polls only during regular market hours.",
    "ca_live_ingest": "Maintains the live ca and ca_live candle snapshot used by the homepage nexus.",
    "cap_img": "Discord relay only. Reads capital_flow/capital_flow_images and does not write its own table.",
    "iv_skew_new": "Maintains iv_skew via raw SQL MERGE/fallback path.",
    "rsi_conditions_new": "Maintains rsi_conditions via raw SQL MERGE/fallback path.",
    "macd_conditions_new": "Maintains macd_consensus via raw SQL MERGE/fallback path.",
    "gaps": "gap_signals is conditional and may stay empty when no fresh gap setups qualify.",
    "option_stats": "Falls back to wb_opts aggregation when Webull call/put ratio is unavailable.",
    "option_trades": "Falls back to Polygon option trade snapshots when Webull deal feeds are empty.",
    "options_query": "Falls back to filtered wb_opts rows when Webull screener blocks the request.",
    "options_vol_anal": "Signal-only surge tables update only when Webull returns volume-analysis payloads and thresholds are met.",
}

MARKET_HOURS_ONLY_MODULES = {
    "active",
    "alerts",
    "all_options",
    "atm_vol_anal",
    "multi_quote_new",
    "rise_fall",
    "technical_events",
    "vol_anal",
    "volume_summary",
}
OPTIONAL_SIGNAL_TABLES = {
    "buy_contracts",
    "gap_signals",
    "neut_contracts",
    "sell_contracts",
}
EASTERN = ZoneInfo("America/New_York")

MANUAL_FRESHNESS_SECONDS: Dict[str, int] = {
    "active": 900,
    "alerts": 1800,
    "all_options": 900,
    "analysts": 86400,
    "atm_options": 300,
    "atm_vol_anal": 1800,
    "balance_sheet": 604800,
    "capital_flow": 3600,
    "ca_live_ingest": 300,
    "cash_flow": 604800,
    "cost_distribution": 7200,
    "crypto": 3600,
    "earnings": 86400,
    "etf_holdings": 86400,
    "events": 86400,
    "factors": 86400,
    "finra_shorts": 86400,
    "gaps": 1800,
    "gex": 600,
    "high_dividends": 86400,
    "historic_ivx": 600,
    "income_statement": 604800,
    "info": 86400,
    "institutions": 86400,
    "ipos": 86400,
    "itm_dollars": 1800,
    "iv_skew_new": 600,
    "macd_conditions_new": 300,
    "multi_quote_new": 300,
    "news": 900,
    "oi_outliers_new": 1800,
    "option_stats": 1800,
    "option_trades": 900,
    "options_charts": 1800,
    "options_monitor": 600,
    "options_query": 1800,
    "options_vol_anal": 1800,
    "overnight": 86400,
    "plays": 900,
    "rise_fall": 900,
    "rsi_conditions_new": 300,
    "short_interest": 86400,
    "stock_monitor": 1800,
    "technical_events": 180,
    "ticker_bonds": 86400,
    "top_followed": 86400,
    "us_bonds": 86400,
    "vol_anal": 1800,
    "volume_summary": 900,
    "yf_earnings_estimate": 86400,
    "yf_insider_roster_holdings": 86400,
    "yf_insiders": 86400,
    "yf_mfholders": 86400,
    "yf_news": 86400,
    "yf_pt": 86400,
}


@dataclass
class TableStatus:
    table: str
    exists: bool
    row_count: int
    timestamp_column: str
    last_updated: str
    age_seconds: Optional[int]
    freshness_seconds: int
    is_fresh: bool
    error: str = ""


@dataclass
class ModuleStatus:
    module: str
    mode: str
    process_running: bool
    process_id: int
    command_line: str
    freshness_seconds: int
    tables: List[str] = field(default_factory=list)
    table_statuses: List[TableStatus] = field(default_factory=list)
    note: str = ""
    state: str = "unknown"


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def now_local_naive() -> datetime:
    return datetime.now()


def isoformat(value: Optional[datetime]) -> str:
    if value is None:
        return ""
    if value.tzinfo is None:
        return value.isoformat(sep=" ")
    return value.astimezone(timezone.utc).isoformat()


def is_regular_market_hours(reference_now: Optional[datetime] = None) -> bool:
    current = reference_now or now_utc()
    est_now = current.astimezone(EASTERN)
    return time(9, 30) <= est_now.time() <= time(16, 0)


def load_batch_modules() -> List[str]:
    text = BATCH_PATH.read_text(encoding="utf-8", errors="ignore")
    match = re.search(r"set scripts=(.+)", text)
    if not match:
        return []
    modules = [part.strip() for part in match.group(1).strip().split() if part.strip()]
    return modules


def extract_literal_tables(script_path: Path) -> List[str]:
    if not script_path.exists():
        return []
    text = script_path.read_text(encoding="utf-8", errors="ignore")
    tables: List[str] = []
    for pattern in (
        r'table_name\s*=\s*[frbu]*[\"\']([^\"\']+)[\"\']',
        r'batch_upsert_dataframe\([^\n]+,[^\n]*[\"\']([A-Za-z0-9_]+)[\"\']\s*,\s*unique_columns',
    ):
        for match in re.finditer(pattern, text):
            candidate = str(match.group(1) or "").strip()
            if candidate and "{" not in candidate and candidate not in tables:
                tables.append(candidate)
    return tables


def classify_mode(script_path: Path) -> str:
    if not script_path.exists():
        return "missing"
    text = script_path.read_text(encoding="utf-8", errors="ignore")
    if "while True" in text:
        return "loop"
    if "asyncio.sleep" in text:
        return "scheduled"
    return "one_shot"


def module_tables(module: str, script_path: Path) -> List[str]:
    if module in MANUAL_TABLES:
        return list(MANUAL_TABLES[module])
    return extract_literal_tables(script_path)


def module_freshness(module: str) -> int:
    return int(MANUAL_FRESHNESS_SECONDS.get(module, 86400))


def module_note(module: str) -> str:
    return MANUAL_NOTES.get(module, "")


def load_python_processes() -> List[dict]:
    command = (
        "Get-CimInstance Win32_Process | "
        "Where-Object { $_.Name -match 'python' } | "
        "Select-Object ProcessId, CommandLine | ConvertTo-Json -Depth 3"
    )
    result = subprocess.run(
        ["powershell", "-NoProfile", "-Command", command],
        capture_output=True,
        text=True,
        check=False,
        cwd=str(REPO_ROOT),
    )
    text = (result.stdout or "").strip()
    if not text:
        return []
    try:
        payload = json.loads(text)
    except Exception:
        return []
    if isinstance(payload, dict):
        return [payload]
    if isinstance(payload, list):
        return payload
    return []


def module_process(module: str, processes: Iterable[dict]) -> tuple[bool, int, str]:
    for process in processes:
        command_line = str(process.get("CommandLine") or "")
        if not command_line:
            continue
        if f"scripts\\{module}.py" in command_line or f"scripts/{module}.py" in command_line:
            return True, int(process.get("ProcessId") or 0), command_line
        if re.search(rf"(^|\s)-m\s+{re.escape(module)}(\s|$)", command_line):
            return True, int(process.get("ProcessId") or 0), command_line
    return False, 0, ""


async def table_columns(db: PolygonOptions, table_name: str) -> List[str]:
    rows = await db.fetch(
        """
        SELECT column_name
        FROM information_schema.columns
        WHERE table_schema = 'public' AND table_name = $1
        ORDER BY ordinal_position
        """,
        table_name,
    )
    return [str(row["column_name"]) for row in rows or []]


def choose_timestamp_column(columns: List[str]) -> str:
    for candidate in TIMESTAMP_PRIORITY:
        if candidate in columns:
            return candidate
    for column in columns:
        if column.endswith("_timestamp") or column.endswith("_at"):
            return column
    return ""


async def fetch_table_status(
    db: PolygonOptions,
    table: str,
    freshness_seconds: int,
) -> TableStatus:
    try:
        exists = await db.table_exists(table)
        if not exists:
            return TableStatus(
                table=table,
                exists=False,
                row_count=0,
                timestamp_column="",
                last_updated="",
                age_seconds=None,
                freshness_seconds=freshness_seconds,
                is_fresh=False,
                error="table_missing",
            )

        columns = await table_columns(db, table)
        row_count = int(await db.fetchval(f"SELECT COUNT(*) FROM {table}") or 0)
        candidate_columns = [column for column in TIMESTAMP_PRIORITY if column in columns]
        candidate_columns.extend(
            [column for column in columns if (column.endswith("_timestamp") or column.endswith("_at")) and column not in candidate_columns]
        )
        ts_col = ""
        max_value = None
        for candidate in candidate_columns:
            max_candidate = await db.fetchval(f'SELECT MAX("{candidate}") FROM {table}')
            if max_candidate is not None:
                ts_col = candidate
                max_value = max_candidate
                break
        if not ts_col:
            ts_col = choose_timestamp_column(columns)
        if not ts_col:
            return TableStatus(
                table=table,
                exists=True,
                row_count=row_count,
                timestamp_column="",
                last_updated="",
                age_seconds=None,
                freshness_seconds=freshness_seconds,
                is_fresh=row_count > 0,
                error="no_timestamp_column",
            )

        if max_value is None:
            max_value = await db.fetchval(f'SELECT MAX("{ts_col}") FROM {table}')
        parsed: Optional[datetime]
        if isinstance(max_value, datetime):
            parsed = max_value
        elif max_value is None:
            parsed = None
        else:
            text = str(max_value).replace("Z", "+00:00")
            try:
                parsed = datetime.fromisoformat(text)
            except Exception:
                parsed = None

        age_seconds = None
        is_fresh = False
        if parsed is not None:
            if parsed.tzinfo is None:
                age_seconds = int((now_local_naive() - parsed).total_seconds())
            else:
                age_seconds = int((now_utc() - parsed.astimezone(timezone.utc)).total_seconds())
            age_seconds = max(0, age_seconds)
            is_fresh = age_seconds <= freshness_seconds

        return TableStatus(
            table=table,
            exists=True,
            row_count=row_count,
            timestamp_column=ts_col,
            last_updated=isoformat(parsed),
            age_seconds=age_seconds,
            freshness_seconds=freshness_seconds,
            is_fresh=is_fresh,
        )
    except Exception as exc:
        return TableStatus(
            table=table,
            exists=False,
            row_count=0,
            timestamp_column="",
            last_updated="",
            age_seconds=None,
            freshness_seconds=freshness_seconds,
            is_fresh=False,
            error=str(exc),
        )


def classify_state(module_status: ModuleStatus) -> str:
    if not module_status.tables:
        return "running" if module_status.process_running else "no_db_target"
    if not module_status.table_statuses:
        return "unknown"
    if any(table.error for table in module_status.table_statuses):
        return "error"
    if all(table.is_fresh for table in module_status.table_statuses):
        return "fresh" if module_status.process_running else "fresh_not_running"
    required_tables = [table for table in module_status.table_statuses if table.table not in OPTIONAL_SIGNAL_TABLES]
    optional_tables = [table for table in module_status.table_statuses if table.table in OPTIONAL_SIGNAL_TABLES]
    if required_tables and all(table.is_fresh for table in required_tables):
        if optional_tables and any(not table.is_fresh for table in optional_tables):
            return "fresh_optional" if module_status.process_running else "fresh_optional_not_running"
    if (
        module_status.module in MARKET_HOURS_ONLY_MODULES
        and module_status.process_running
        and not is_regular_market_hours()
        and all(table.exists and table.row_count > 0 for table in module_status.table_statuses)
    ):
        return "idle_after_hours"
    if (
        optional_tables
        and not required_tables
        and module_status.process_running
    ):
        return "signal_idle"
    return "stale" if module_status.process_running else "stale_not_running"


def age_label(age_seconds: Optional[int]) -> str:
    if age_seconds is None:
        return "n/a"
    if age_seconds < 0:
        ahead = abs(age_seconds)
        if ahead < 60:
            return f"future {ahead}s"
        if ahead < 3600:
            return f"future {ahead // 60}m"
        if ahead < 86400:
            return f"future {ahead // 3600}h"
        return f"future {ahead // 86400}d"
    if age_seconds < 60:
        return f"{age_seconds}s"
    if age_seconds < 3600:
        return f"{age_seconds // 60}m"
    if age_seconds < 86400:
        return f"{age_seconds // 3600}h"
    return f"{age_seconds // 86400}d"


def render_html(modules: List[ModuleStatus], generated_at: str) -> str:
    total = len(modules)
    fresh = sum(
        1
        for module in modules
        if module.state in {
            "fresh",
            "fresh_not_running",
            "fresh_optional",
            "fresh_optional_not_running",
            "idle_after_hours",
            "signal_idle",
        }
    )
    stale = sum(1 for module in modules if "stale" in module.state)
    errors = sum(1 for module in modules if module.state == "error")
    running = sum(1 for module in modules if module.process_running)

    rows: List[str] = []
    for module in modules:
        table_lines = []
        for table in module.table_statuses:
            status_class = "ok" if table.is_fresh else "stale"
            error_suffix = f" | {html.escape(table.error)}" if table.error else ""
            table_lines.append(
                f'<div class="table-pill {status_class}">'
                f"<strong>{html.escape(table.table)}</strong>"
                f" | rows {table.row_count}"
                f" | last {html.escape(table.last_updated or 'n/a')}"
                f" | age {html.escape(age_label(table.age_seconds))}"
                f"{error_suffix}"
                f"</div>"
            )
        if not table_lines:
            table_lines.append('<div class="table-pill neutral">No DB table target</div>')

        row_class = module.state.replace("_", "-")
        process_text = f"PID {module.process_id}" if module.process_running else "not running"
        rows.append(
            "<tr class=\"%s\">"
            "<td><code>%s</code><div class=\"note\">%s</div></td>"
            "<td>%s</td>"
            "<td>%s</td>"
            "<td>%s</td>"
            "<td>%s</td>"
            "<td>%s</td>"
            "</tr>"
            % (
                html.escape(row_class),
                html.escape(module.module),
                html.escape(module.note),
                html.escape(module.state),
                html.escape(module.mode),
                html.escape(process_text),
                html.escape(str(module.freshness_seconds)),
                "".join(table_lines),
            )
        )

    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="refresh" content="30">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ALL SCRIPTS Status</title>
  <style>
    :root {{
      --bg: #07111f;
      --panel: #0f1e33;
      --panel-2: #12263f;
      --text: #e8f0ff;
      --muted: #89a0c2;
      --ok: #22c55e;
      --warn: #f59e0b;
      --bad: #ef4444;
      --line: #223657;
      --cyan: #38bdf8;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      font-family: Consolas, "SFMono-Regular", monospace;
      background: radial-gradient(circle at top, #102447 0%, var(--bg) 55%);
      color: var(--text);
    }}
    .wrap {{
      max-width: 1600px;
      margin: 0 auto;
      padding: 24px;
    }}
    .hero {{
      background: linear-gradient(145deg, rgba(56,189,248,.12), rgba(15,30,51,.95));
      border: 1px solid rgba(56,189,248,.25);
      border-radius: 18px;
      padding: 20px 22px;
      margin-bottom: 18px;
      box-shadow: 0 20px 60px rgba(0,0,0,.28);
    }}
    h1 {{
      margin: 0 0 8px;
      font-size: 28px;
    }}
    .sub {{
      color: var(--muted);
      font-size: 13px;
    }}
    .cards {{
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 12px;
      margin: 16px 0 22px;
    }}
    .card {{
      background: rgba(15,30,51,.92);
      border: 1px solid var(--line);
      border-radius: 16px;
      padding: 16px;
    }}
    .card .label {{
      color: var(--muted);
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: .08em;
    }}
    .card .value {{
      font-size: 28px;
      margin-top: 8px;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      background: rgba(15,30,51,.9);
      border: 1px solid var(--line);
      border-radius: 18px;
      overflow: hidden;
    }}
    th, td {{
      vertical-align: top;
      text-align: left;
      padding: 14px 12px;
      border-bottom: 1px solid rgba(34,54,87,.7);
      font-size: 13px;
    }}
    th {{
      color: var(--cyan);
      background: rgba(7,17,31,.85);
      text-transform: uppercase;
      letter-spacing: .08em;
      font-size: 11px;
    }}
    tr.fresh td, tr.fresh-not-running td, tr.fresh-optional td, tr.fresh-optional-not-running td,
    tr.idle-after-hours td, tr.signal-idle td {{ background: rgba(34,197,94,.05); }}
    tr.stale td, tr.stale-not-running td {{ background: rgba(245,158,11,.06); }}
    tr.error td {{ background: rgba(239,68,68,.08); }}
    .note {{
      color: var(--muted);
      margin-top: 8px;
      line-height: 1.4;
    }}
    .table-pill {{
      border: 1px solid var(--line);
      border-radius: 12px;
      padding: 8px 10px;
      margin-bottom: 8px;
      background: var(--panel-2);
      line-height: 1.5;
    }}
    .table-pill.ok {{ border-color: rgba(34,197,94,.45); }}
    .table-pill.stale {{ border-color: rgba(245,158,11,.45); }}
    .table-pill.neutral {{ border-color: rgba(137,160,194,.3); color: var(--muted); }}
    @media (max-width: 1100px) {{
      .cards {{ grid-template-columns: repeat(2, minmax(0, 1fr)); }}
    }}
    @media (max-width: 720px) {{
      .wrap {{ padding: 14px; }}
      .cards {{ grid-template-columns: 1fr; }}
      table, thead, tbody, th, td, tr {{ display: block; }}
      thead {{ display: none; }}
      td {{ border-bottom: 1px solid var(--line); }}
    }}
  </style>
</head>
<body>
  <div class="wrap">
    <section class="hero">
      <h1>ALL SCRIPTS Status</h1>
      <div class="sub">Batch source: {html.escape(str(BATCH_PATH))}</div>
      <div class="sub">Generated: {html.escape(generated_at)}</div>
      <div class="sub">Report path: {html.escape(str(STATUS_HTML_PATH))}</div>
    </section>
    <section class="cards">
      <div class="card"><div class="label">Modules</div><div class="value">{total}</div></div>
      <div class="card"><div class="label">Running</div><div class="value">{running}</div></div>
      <div class="card"><div class="label">Fresh</div><div class="value">{fresh}</div></div>
      <div class="card"><div class="label">Stale / Error</div><div class="value">{stale + errors}</div></div>
    </section>
    <table>
      <thead>
        <tr>
          <th>Module</th>
          <th>State</th>
          <th>Mode</th>
          <th>Process</th>
          <th>Freshness Sec</th>
          <th>Table Status</th>
        </tr>
      </thead>
      <tbody>
        {"".join(rows)}
      </tbody>
    </table>
  </div>
</body>
</html>"""


async def build_status() -> Dict[str, Any]:
    modules = load_batch_modules()
    processes = load_python_processes()
    db = PolygonOptions()
    await db.connect()
    try:
        statuses: List[ModuleStatus] = []
        for module in modules:
            script_path = ROOT / f"{module}.py"
            running, pid, command_line = module_process(module, processes)
            freshness_seconds = module_freshness(module)
            tables = module_tables(module, script_path)
            table_statuses: List[TableStatus] = []
            for table in tables:
                table_statuses.append(
                    await fetch_table_status(
                        db,
                        table,
                        freshness_seconds,
                    )
                )
            status = ModuleStatus(
                module=module,
                mode=classify_mode(script_path),
                process_running=running,
                process_id=pid,
                command_line=command_line,
                freshness_seconds=freshness_seconds,
                tables=tables,
                table_statuses=table_statuses,
                note=module_note(module),
            )
            status.state = classify_state(status)
            statuses.append(status)

        generated_at = isoformat(now_utc())
        payload = {
            "generated_at": generated_at,
            "batch_path": str(BATCH_PATH),
            "html_path": str(STATUS_HTML_PATH),
            "modules": [
                {
                    **asdict(module),
                    "table_statuses": [asdict(table) for table in module.table_statuses],
                }
                for module in statuses
            ],
        }
        return payload
    finally:
        await db.disconnect()


def write_status_files(payload: Dict[str, Any]) -> None:
    STATUS_DIR.mkdir(parents=True, exist_ok=True)
    STATUS_JSON_PATH.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    modules = []
    for module_payload in payload.get("modules", []):
        tables = [TableStatus(**table_payload) for table_payload in module_payload.get("table_statuses", [])]
        module = ModuleStatus(
            module=module_payload["module"],
            mode=module_payload["mode"],
            process_running=module_payload["process_running"],
            process_id=module_payload["process_id"],
            command_line=module_payload["command_line"],
            freshness_seconds=module_payload["freshness_seconds"],
            tables=list(module_payload.get("tables", [])),
            table_statuses=tables,
            note=module_payload.get("note", ""),
            state=module_payload.get("state", "unknown"),
        )
        modules.append(module)
    STATUS_HTML_PATH.write_text(render_html(modules, str(payload.get("generated_at") or "")), encoding="utf-8")


async def run_loop(interval_seconds: int) -> None:
    while True:
        payload = await build_status()
        write_status_files(payload)
        await asyncio.sleep(max(15, int(interval_seconds)))


async def async_main(args: argparse.Namespace) -> None:
    if args.loop:
        await run_loop(args.interval)
        return
    payload = await build_status()
    write_status_files(payload)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render ALL SCRIPTS batch status into JSON and HTML.")
    parser.add_argument("--loop", action="store_true", help="Refresh the report continuously.")
    parser.add_argument("--interval", type=int, default=60, help="Refresh interval in seconds when --loop is used.")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    asyncio.run(async_main(args))


if __name__ == "__main__":
    main()
