import asyncio
import os
import sys
from pathlib import Path

import pandas as pd
import requests

project_dir = str(Path(__file__).resolve().parents[1])
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

from fudstop4.apis.helpers import generate_webull_headers
from fudstop4.apis.polygonio.polygon_options import PolygonOptions
from fudstop4.apis.webull.trade_models.stock_quote import MultiQuote
from fudstop4.apis.webull.webull_crypto import WebullCrypto

opts = PolygonOptions()
crypto = WebullCrypto()


def chunks(items, size):
    for index in range(0, len(items), size):
        yield items[index : index + size]


async def fetch_chart_data_batch(ticker_ids):
    loop = asyncio.get_running_loop()
    ticker_ids_str = ",".join(str(ticker_id) for ticker_id in ticker_ids)
    url = (
        "https://quotes-gw.webullfintech.com/api/bgw/quote/realtime"
        f"?ids={ticker_ids_str}&includeSecu=1&delay=0&more=1"
    )
    headers = generate_webull_headers(access_token=os.environ.get("ACCESS_TOKEN"))
    try:
        response = await loop.run_in_executor(
            None,
            lambda: requests.get(url, headers=headers, timeout=20),
        )
    except requests.RequestException:
        return
    if response.status_code != 200:
        return
    try:
        payload = response.json()
    except requests.exceptions.JSONDecodeError:
        return
    data = MultiQuote(payload).as_dataframe
    if data is None or data.empty:
        return
    data["ticker_id"] = data["ticker_id"].astype(int)
    data = data.rename(columns={"symbol": "ticker"})
    data["ticker"] = data["ticker"].str.replace(r"USD$", "", regex=True)
    await opts.batch_upsert_dataframe(data, table_name="crypto", unique_columns=["ticker_id"])


async def main():
    await opts.connect()
    while True:
        items = list(crypto.coin_to_id_map.items())
        tasks = []
        for batch in chunks(items, 50):
            _tickers, ticker_ids = zip(*batch)
            tasks.append(fetch_chart_data_batch(ticker_ids))
        await asyncio.gather(*tasks, return_exceptions=True)
        await asyncio.sleep(30)


if __name__ == "__main__":
    asyncio.run(main())
