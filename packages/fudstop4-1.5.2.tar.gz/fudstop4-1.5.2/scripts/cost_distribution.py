import asyncio
import logging
import os
import sys
from datetime import datetime, time
from pathlib import Path

import pandas as pd
import pytz
from discord_webhook import AsyncDiscordWebhook, DiscordEmbed
from dotenv import load_dotenv

project_dir = str(Path(__file__).resolve().parents[1])
if project_dir not in sys.path:
    sys.path.append(project_dir)

from MODELS.candles import Candles
from UTILS.confluence import score_cost_distribution
from UTILS.discord_targets import split_discord_webhook_target
from UTILS.ticker_dicts import ticker_hooks_dict, tickers_dict
from fudstop4._markets.list_sets.dicts import hex_color_dict
from fudstop4._markets.list_sets.ticker_lists import most_active_nonetf
from fudstop4.apis.polygonio.polygon_options import PolygonOptions
from fudstop4.apis.webull.webull_trading import WebullTrading

load_dotenv()
cost_hook = os.environ.get("cost_distribution")
logging.getLogger("discord_webhook.async_webhook").setLevel(logging.CRITICAL)
DEAD_WEBHOOKS: set[str] = set()

opts = PolygonOptions()
trading = WebullTrading()
candles = Candles()

BATCH_SIZE = 5
EST = pytz.timezone("US/Eastern")
RUN_INTERVAL_SECONDS = 60 * 30
SLEEP_SECONDS = 60


def chunked(iterable, n):
    for i in range(0, len(iterable), n):
        yield iterable[i : i + n]


def within_market_hours(now: datetime) -> bool:
    current_time = now.time()
    return time(9, 30) <= current_time <= time(16, 0)


async def send_embed(raw_target: str, embed: DiscordEmbed, fallback_thread_id: str = "") -> None:
    webhook_url, thread_id = split_discord_webhook_target(
        raw_target,
        fallback_thread_id=fallback_thread_id,
    )
    if not webhook_url:
        return
    if webhook_url in DEAD_WEBHOOKS:
        return

    webhook_kwargs = {"url": webhook_url}
    if thread_id:
        webhook_kwargs["thread_id"] = thread_id

    hook = AsyncDiscordWebhook(**webhook_kwargs)
    hook.add_embed(embed)
    response = await hook.execute()
    if response.status_code == 404:
        DEAD_WEBHOOKS.add(webhook_url)
    elif response.status_code not in (200, 204):
        print(f"[cost_distribution] Discord post returned status {response.status_code}")


async def fetch(ticker: str) -> None:
    try:
        cost_dict = await trading.new_cost_dist(
            symbol=ticker,
            start_date=trading.eight_days_ago,
            end_date=trading.today,
        )
        if cost_dict is None or not hasattr(cost_dict, "as_dataframe"):
            print(f"[cost_distribution] Skipping {ticker}: no cost distribution payload")
            return

        df = cost_dict.as_dataframe
        if df is None or df.empty or "profit_ratio" not in df.columns:
            print(f"[cost_distribution] Skipping {ticker}: empty cost distribution frame")
            return

        profit_ratio = float(df["profit_ratio"].to_list()[0] or 0.0)
        score = score_cost_distribution(profit_ratio)

        if abs(score.points) >= 2:
            color = (
                hex_color_dict.get("green")
                if score.signal == "bullish"
                else hex_color_dict.get("red")
            )
            embed = DiscordEmbed(
                title=f"Cost Distribution Alert - {ticker}",
                description=(
                    f"```py\n{ticker} shows {profit_ratio:.1f}% of holders in profit "
                    f"({score.signal.upper()} short-term tilt).```\nReason: {score.reason}"
                ),
                color=color,
            )
            embed.add_embed_field(
                name="Players profiting:",
                value=f"> **{profit_ratio:.1f}%**",
            )
            embed.set_footer(text=f"cost_dist,{ticker},{score.signal}")
            embed.set_timestamp()

            await send_embed(cost_hook, embed)
            await send_embed(
                ticker_hooks_dict.get(ticker, ""),
                embed,
                fallback_thread_id=str(tickers_dict.get(ticker, "")),
            )

        df_result = pd.DataFrame(
            {
                "ticker": [ticker],
                "cost_sentiment": [score.signal],
                "profit_ratio": [profit_ratio],
                "cost_signal": [score.signal],
                "cost_points": [score.points],
                "cost_reason": [score.reason],
                "confluence_score": [score.points],
            }
        )
        await opts.batch_upsert_dataframe(
            df_result,
            table_name="cost_distribution",
            unique_columns=["ticker", "cost_sentiment"],
        )
    except Exception as e:
        print(f"[!] Error fetching for {ticker}: {e}")


async def main():
    await opts.connect()
    last_run_at = None
    try:
        while True:
            now = datetime.now(EST)
            ready_to_run = last_run_at is None or (now - last_run_at).total_seconds() >= RUN_INTERVAL_SECONDS

            if within_market_hours(now) and ready_to_run:
                print(
                    f"[*] Starting cost dist run at "
                    f"{now.strftime('%I:%M:%S %p EST')}"
                )
                processed: set[str] = set()
                for batch in chunked(most_active_nonetf, BATCH_SIZE):
                    batch_to_run = [ticker for ticker in batch if ticker not in processed]
                    if not batch_to_run:
                        continue

                    tasks = [fetch(ticker) for ticker in batch_to_run]
                    await asyncio.gather(*tasks)
                    processed.update(batch_to_run)
                    print(f"[+] Processed batch: {batch_to_run}")

                last_run_at = now
                print("[OK] Cost distribution run complete.")
            else:
                if not within_market_hours(now):
                    print(f"[!] Outside market hours - {now.strftime('%I:%M:%S %p EST')}")
                else:
                    print("[!] Cost distribution waiting for next interval.")

            await asyncio.sleep(SLEEP_SECONDS)
    finally:
        await opts.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
