from __future__ import annotations

import argparse
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Sequence

import requests
from dotenv import load_dotenv

from feeds.discord_routes import (
    DEFAULT_DISCORD_CATEGORY_NAME,
    DEFAULT_DISCORD_GUILD_ID,
    FeedDiscordRoute,
    iter_routes,
    registry_path,
    write_env_export,
)


load_dotenv()

DISCORD_API_BASE = "https://discord.com/api/v9"


class FeedDiscordProvisioner:
    def __init__(self, auth_token: str, *, dry_run: bool = False):
        token = str(auth_token or "").strip()
        if not token:
            raise ValueError("Missing Discord auth token.")

        self.dry_run = bool(dry_run)
        self.session = requests.Session()
        self.session.headers.update(
            {
                "authority": "discord.com",
                "method": "POST",
                "path": "/api/v9/science",
                "scheme": "https",
                "Accept": "*/*",
                "Content-Type": "application/json",
                "Accept-Encoding": "gzip, deflate, br",
                "Accept-Language": "en-US,en;q=0.9",
                "Authorization": token,
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/120.0.0.0 Safari/537.36"
                ),
            }
        )

    def _request(
        self,
        method: str,
        path: str,
        *,
        expected: Sequence[int] = (200, 201, 204),
        json_payload: Dict[str, Any] | None = None,
    ) -> Any:
        url = f"{DISCORD_API_BASE}{path}"
        if self.dry_run:
            print(f"[dry-run] {method} {url}")
            if json_payload is not None:
                print(f"[dry-run] payload={json.dumps(json_payload, ensure_ascii=True)}")
            return {}

        while True:
            resp = self.session.request(method, url, json=json_payload, timeout=30)
            if resp.status_code == 429:
                retry_after = 1.25
                try:
                    retry_after = float(resp.json().get("retry_after", retry_after))
                except Exception:
                    pass
                time.sleep(max(0.25, retry_after))
                continue
            if resp.status_code not in expected:
                raise RuntimeError(f"{method} {path} failed ({resp.status_code}): {resp.text[:800]}")
            if resp.status_code == 204 or not resp.content:
                return {}
            return resp.json()

    def guild_channels(self, guild_id: str) -> List[Dict[str, Any]]:
        data = self._request("GET", f"/guilds/{guild_id}/channels")
        return data if isinstance(data, list) else []

    def guild_webhooks(self, guild_id: str) -> List[Dict[str, Any]]:
        data = self._request("GET", f"/guilds/{guild_id}/webhooks")
        return data if isinstance(data, list) else []

    def ensure_category(self, guild_id: str, name: str) -> Dict[str, Any]:
        for channel in self.guild_channels(guild_id):
            if int(channel.get("type") or -1) != 4:
                continue
            if str(channel.get("name") or "").strip().lower() == name.strip().lower():
                return channel

        payload = {"name": name, "type": 4}
        created = self._request("POST", f"/guilds/{guild_id}/channels", expected=(200, 201), json_payload=payload)
        if self.dry_run and not created.get("id"):
            created["id"] = f"dry-category-{name}"
        print(f"[create] category {name} -> {created.get('id')}")
        return created

    def ensure_text_channel(
        self,
        guild_id: str,
        *,
        parent_id: str,
        route: FeedDiscordRoute,
    ) -> Dict[str, Any]:
        existing: Dict[str, Any] | None = None
        for channel in self.guild_channels(guild_id):
            if int(channel.get("type") or -1) != 0:
                continue
            if str(channel.get("parent_id") or "") != str(parent_id):
                continue
            if str(channel.get("name") or "").strip().lower() == route.channel_name.lower():
                existing = channel
                break

        if existing is None:
            payload = {
                "name": route.channel_name,
                "type": 0,
                "topic": route.topic,
                "parent_id": str(parent_id),
            }
            created = self._request(
                "POST",
                f"/guilds/{guild_id}/channels",
                expected=(200, 201),
                json_payload=payload,
            )
            if self.dry_run and not created.get("id"):
                created["id"] = f"dry-channel-{route.channel_name}"
            print(f"[create] channel {route.channel_name} -> {created.get('id')}")
            return created

        updates: Dict[str, Any] = {}
        if str(existing.get("topic") or "") != route.topic:
            updates["topic"] = route.topic
        if str(existing.get("parent_id") or "") != str(parent_id):
            updates["parent_id"] = str(parent_id)
        if updates:
            existing = self._request(
                "PATCH",
                f"/channels/{existing['id']}",
                expected=(200,),
                json_payload=updates,
            )
            print(f"[update] channel {route.channel_name} topic/parent synced")
        return existing

    def ensure_webhook(self, guild_id: str, *, channel_id: str, route: FeedDiscordRoute) -> Dict[str, Any]:
        for hook in self.guild_webhooks(guild_id):
            if str(hook.get("channel_id") or "") != str(channel_id):
                continue
            if str(hook.get("name") or "").strip().lower() != route.webhook_name.lower():
                continue
            return hook

        if self.dry_run:
            created = {
                "id": f"dry-webhook-{route.route_id}",
                "channel_id": channel_id,
                "name": route.webhook_name,
                "url": f"https://discord.com/api/webhooks/dry-{route.route_id}/token",
            }
            print(f"[create] webhook {route.webhook_name} -> {created.get('id')}")
            return created

        created = self._request(
            "POST",
            f"/channels/{channel_id}/webhooks",
            expected=(200, 201),
            json_payload={"name": route.webhook_name},
        )
        if not isinstance(created, dict):
            raise RuntimeError(f"Webhook creation returned unexpected payload for {route.route_id}")
        print(f"[create] webhook {route.webhook_name} -> {created.get('id')}")
        return created

    def provision(
        self,
        *,
        guild_id: str,
        category_name: str,
    ) -> Dict[str, Any]:
        category = self.ensure_category(guild_id, category_name)
        category_id = str(category.get("id") or "")
        if not category_id:
            raise RuntimeError(f"Could not resolve category ID for {category_name}")

        routes_payload: Dict[str, Dict[str, Any]] = {}
        for route in iter_routes():
            channel = self.ensure_text_channel(guild_id, parent_id=category_id, route=route)
            channel_id = str(channel.get("id") or "")
            if not channel_id:
                raise RuntimeError(f"Could not resolve channel ID for {route.route_id}")

            webhook = self.ensure_webhook(guild_id, channel_id=channel_id, route=route)
            webhook_url = str(webhook.get("url") or "").strip()
            if not webhook_url:
                raise RuntimeError(f"Webhook URL missing for {route.route_id}")

            routes_payload[route.route_id] = {
                "route_id": route.route_id,
                "script_path": route.script_path,
                "display_name": route.display_name,
                "channel_name": route.channel_name,
                "channel_id": channel_id,
                "category_name": category_name,
                "category_id": category_id,
                "topic": route.topic,
                "webhook_env": route.webhook_env,
                "webhook_name": route.webhook_name,
                "webhook_id": str(webhook.get("id") or ""),
                "webhook_url": webhook_url,
                "fallback_envs": list(route.fallback_envs),
            }

        return {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "guild_id": str(guild_id),
            "category_name": category_name,
            "category_id": category_id,
            "route_count": len(routes_payload),
            "routes": routes_payload,
        }


def resolve_auth_token() -> str:
    for key in ("STOCK_MARKET_SENTINEL", "DISCORD_BOT_TOKEN", "BOT_TOKEN"):
        value = str(os.getenv(key, "") or "").strip()
        if value:
            return value if value.startswith("Bot ") else f"Bot {value}"
    raise RuntimeError("Set DISCORD_BOT_TOKEN, BOT_TOKEN, or STOCK_MARKET_SENTINEL before provisioning feed webhooks.")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Provision Discord channels/webhooks for feed scripts.")
    parser.add_argument("--guild-id", default=os.getenv("DISCORD_GUILD_ID", DEFAULT_DISCORD_GUILD_ID))
    parser.add_argument("--category-name", default=os.getenv("FEED_DISCORD_CATEGORY_NAME", DEFAULT_DISCORD_CATEGORY_NAME))
    parser.add_argument("--registry-path", default=str(registry_path()))
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    auth_token = resolve_auth_token()
    provisioner = FeedDiscordProvisioner(auth_token, dry_run=bool(args.dry_run))
    registry = provisioner.provision(
        guild_id=str(args.guild_id),
        category_name=str(args.category_name),
    )

    output_path = Path(args.registry_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(registry, indent=2), encoding="utf-8")
    env_path = write_env_export(registry)

    print(f"[done] registry -> {output_path}")
    print(f"[done] env export -> {env_path}")
    for route_id, route_payload in sorted(registry["routes"].items()):
        print(
            f"[route] {route_id} | channel={route_payload['channel_name']} | "
            f"env={route_payload['webhook_env']} | webhook_id={route_payload['webhook_id']}"
        )


if __name__ == "__main__":
    main()
