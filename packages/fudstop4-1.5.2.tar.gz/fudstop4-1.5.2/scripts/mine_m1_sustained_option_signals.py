#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import psycopg2
from psycopg2.extensions import connection as PgConnection
from zoneinfo import ZoneInfo


MARKET_TZ = ZoneInfo("America/New_York")
DEFAULT_OUTPUT_ROOT = Path("runs/ca_historical_reversal_research")
DEFAULT_START_DATE = "2026-01-02"
DEFAULT_END_DATE = "2026-03-24"
DEFAULT_VAL_DAYS = 10
DEFAULT_MIN_N = 20
DEFAULT_TARGET_HIT = 0.85
DEFAULT_TRIGGER_BP = 0.0025
DEFAULT_SUSTAIN_BP = 0.0050
DEFAULT_HOLD_BP = 0.0015
DEFAULT_MAX_ADVERSE_BP = 0.0030
DEFAULT_MIN_TRIGGER12_RATE = 0.0
DEFAULT_MIN_TRIGGER1_RATE = 0.0
DEFAULT_MIN_SUSTAIN75_RATE = 0.0
DEFAULT_MIN_AVG_BEST_RET = 0.0
DEFAULT_MIN_AVG_HOLD5_RET = 0.0
DEFAULT_MIN_WILSON_LB = 0.0
DEFAULT_MIN_VAL_WILSON_LB = 0.0
DEFAULT_MIN_TICKERS = 0
DEFAULT_MIN_VAL_TICKERS = 0
DEFAULT_TRIGGER_WINDOW = 3
DEFAULT_SUSTAIN_WINDOW = "5_10"
DEFAULT_HOLD_BAR = 5
DEFAULT_BASE_PROFILE = "reversal"


@dataclass(frozen=True)
class ConditionSpec:
    label: str
    expr: str
    required: Sequence[str]
    fn: Callable[[pd.DataFrame], pd.Series]


@dataclass
class SearchResult:
    side: str
    labels: Tuple[str, ...]
    exprs: Tuple[str, ...]
    count: int
    train_count: int
    val_count: int
    ticker_count: int
    val_ticker_count: int
    success_rate: float
    train_success_rate: float
    val_success_rate: float
    wilson_lb: float
    train_wilson_lb: float
    val_wilson_lb: float
    trigger12_rate: float
    trigger1_rate: float
    sustain75_rate: float
    avg_best_ret: float
    avg_hold5_ret: float
    avg_adverse_ret: float
    mask: np.ndarray
    indices: Tuple[int, ...]

    def as_dict(self) -> Dict[str, object]:
        return {
            "side": self.side,
            "conditions": list(self.labels),
            "exprs": list(self.exprs),
            "count": self.count,
            "train_count": self.train_count,
            "val_count": self.val_count,
            "ticker_count": self.ticker_count,
            "val_ticker_count": self.val_ticker_count,
            "success_rate": self.success_rate,
            "train_success_rate": self.train_success_rate,
            "val_success_rate": self.val_success_rate,
            "wilson_lb": self.wilson_lb,
            "train_wilson_lb": self.train_wilson_lb,
            "val_wilson_lb": self.val_wilson_lb,
            "trigger12_rate": self.trigger12_rate,
            "trigger1_rate": self.trigger1_rate,
            "sustain75_rate": self.sustain75_rate,
            "avg_best_ret": self.avg_best_ret,
            "avg_hold5_ret": self.avg_hold5_ret,
            "avg_adverse_ret": self.avg_adverse_ret,
        }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Mine 1-minute historical signal families that trigger quickly and sustain enough "
            "underlying movement to be plausible for immediate options profit."
        )
    )
    parser.add_argument("--host", default="")
    parser.add_argument("--port", type=int, default=5432)
    parser.add_argument("--user", default="")
    parser.add_argument("--password", default="")
    parser.add_argument("--database", default="")
    parser.add_argument("--start-date", default=DEFAULT_START_DATE)
    parser.add_argument("--end-date", default=DEFAULT_END_DATE)
    parser.add_argument("--val-days", type=int, default=DEFAULT_VAL_DAYS)
    parser.add_argument("--min-n", type=int, default=DEFAULT_MIN_N)
    parser.add_argument("--min-val-n", type=int, default=6)
    parser.add_argument("--target-hit", type=float, default=DEFAULT_TARGET_HIT)
    parser.add_argument("--seed-hit", type=float, default=0.62)
    parser.add_argument("--val-floor", type=float, default=0.70)
    parser.add_argument("--trigger-bp", type=float, default=DEFAULT_TRIGGER_BP)
    parser.add_argument("--sustain-bp", type=float, default=DEFAULT_SUSTAIN_BP)
    parser.add_argument("--hold-bp", type=float, default=DEFAULT_HOLD_BP)
    parser.add_argument("--max-adverse-bp", type=float, default=DEFAULT_MAX_ADVERSE_BP)
    parser.add_argument("--min-trigger12-rate", type=float, default=DEFAULT_MIN_TRIGGER12_RATE)
    parser.add_argument("--min-trigger1-rate", type=float, default=DEFAULT_MIN_TRIGGER1_RATE)
    parser.add_argument("--min-sustain75-rate", type=float, default=DEFAULT_MIN_SUSTAIN75_RATE)
    parser.add_argument("--min-avg-best-ret", type=float, default=DEFAULT_MIN_AVG_BEST_RET)
    parser.add_argument("--min-avg-hold5-ret", type=float, default=DEFAULT_MIN_AVG_HOLD5_RET)
    parser.add_argument("--min-wilson-lb", type=float, default=DEFAULT_MIN_WILSON_LB)
    parser.add_argument("--min-val-wilson-lb", type=float, default=DEFAULT_MIN_VAL_WILSON_LB)
    parser.add_argument("--min-tickers", type=int, default=DEFAULT_MIN_TICKERS)
    parser.add_argument("--min-val-tickers", type=int, default=DEFAULT_MIN_VAL_TICKERS)
    parser.add_argument("--trigger-window", type=int, choices=(2, 3), default=DEFAULT_TRIGGER_WINDOW)
    parser.add_argument("--sustain-window", choices=("1_5", "5_10"), default=DEFAULT_SUSTAIN_WINDOW)
    parser.add_argument("--hold-bar", type=int, choices=(3, 5), default=DEFAULT_HOLD_BAR)
    parser.add_argument(
        "--base-profile",
        choices=("reversal", "reclaim", "continuation", "expansion", "friday_arm", "friday_confirm"),
        default=DEFAULT_BASE_PROFILE,
    )
    parser.add_argument("--max-k", type=int, default=4)
    parser.add_argument("--top-seeds", type=int, default=80)
    parser.add_argument("--top-per-depth", type=int, default=60)
    parser.add_argument("--top-final", type=int, default=30)
    parser.add_argument("--output-dir", default="")
    return parser.parse_args()


def load_env_defaults() -> Dict[str, str]:
    env_path = Path("stock_market_site/app/.env")
    values: Dict[str, str] = {}
    if not env_path.exists():
        return values
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def with_env_default(value: str, fallback: str) -> str:
    text = str(value or "").strip()
    return text if text else fallback


def parse_date(raw: str) -> date:
    return datetime.strptime(str(raw or "").strip(), "%Y-%m-%d").date()


def et_epoch(day: date, hour: int, minute: int = 0) -> int:
    return int(datetime(day.year, day.month, day.day, hour, minute, tzinfo=MARKET_TZ).timestamp())


def db_connect(args: argparse.Namespace, env_defaults: Dict[str, str]) -> PgConnection:
    return psycopg2.connect(
        host=with_env_default(args.host, env_defaults.get("DB_HOST", "localhost")),
        port=int(args.port or env_defaults.get("DB_PORT", "5432")),
        user=with_env_default(args.user, env_defaults.get("DB_USER", "chuck")),
        password=with_env_default(args.password, env_defaults.get("DB_PASSWORD", "fud")),
        dbname=with_env_default(args.database, env_defaults.get("DB_NAME", "fudstop3")),
    )


def build_base_query(*, start_epoch: int, end_epoch: int) -> str:
    return f"""
WITH base AS (
    SELECT
        ticker,
        ts::bigint AS ts_epoch,
        date_et,
        time_et,
        o,
        c,
        h,
        l,
        v,
        candle_color,
        candle_green,
        candle_red,
        hl_range_pct,
        body_pct,
        upper_wick,
        lower_wick,
        wick_ratio,
        oc_pct,
        gap_pct,
        is_gap,
        is_inside_bar,
        rsi,
        td_buy_count,
        td_sell_count,
        macd_hist,
        macd_hist_slope,
        macd_hist_slope3,
        bb_width,
        bb_close_outside_lower,
        bb_close_outside_upper,
        candle_completely_below_lower,
        candle_completely_above_upper,
        rvol,
        atr_pct,
        chop,
        vwap_dist_pct,
        vwap_cross_up,
        vwap_cross_dn,
        stoch_rsi_k,
        mfi,
        cmo,
        roc,
        trix,
        ultimate_osc,
        trend_regime,
        volume_confirm,
        squeeze_off,
        adx,
        adx_strong,
        di_bull,
        di_bear,
        ema_stack_bull,
        ema_stack_bear,
        macd_cross_up,
        macd_cross_dn,
        tsi_cross_up,
        tsi_cross_dn,
        momentum_confirm_bull,
        momentum_confirm_bear,
        lead(h, 1) OVER w AS h1,
        lead(h, 2) OVER w AS h2,
        lead(h, 3) OVER w AS h3,
        lead(l, 1) OVER w AS l1,
        lead(l, 2) OVER w AS l2,
        lead(l, 3) OVER w AS l3,
        lead(c, 1) OVER w AS c1,
        lead(c, 2) OVER w AS c2,
        lead(c, 3) OVER w AS c3,
        lead(c, 4) OVER w AS c4,
        lead(c, 5) OVER w AS c5,
        lead(c, 10) OVER w AS c10,
        max(h) OVER w_1_5 AS max_h_1_5,
        min(l) OVER w_1_5 AS min_l_1_5,
        max(h) OVER w_1_10 AS max_h_1_10,
        min(l) OVER w_1_10 AS min_l_1_10,
        max(h) OVER w_5_10 AS max_h_5_10,
        min(l) OVER w_5_10 AS min_l_5_10,
        count(*) OVER w_1_5 AS n_1_5,
        count(*) OVER w_1_10 AS n_1_10,
        count(*) OVER w_5_10 AS n_5_10
    FROM ca
    WHERE timespan = 'm1'
      AND session = 'regular'
      AND bb_width IS NOT NULL
      AND ts::bigint >= {int(start_epoch)}
      AND ts::bigint < {int(end_epoch)}
    WINDOW
        w AS (PARTITION BY ticker ORDER BY ts::bigint),
        w_1_5 AS (PARTITION BY ticker ORDER BY ts::bigint ROWS BETWEEN 1 FOLLOWING AND 5 FOLLOWING),
        w_1_10 AS (PARTITION BY ticker ORDER BY ts::bigint ROWS BETWEEN 1 FOLLOWING AND 10 FOLLOWING),
        w_5_10 AS (PARTITION BY ticker ORDER BY ts::bigint ROWS BETWEEN 5 FOLLOWING AND 10 FOLLOWING)
)
SELECT *
FROM base
WHERE n_1_10 = 10
  AND n_1_5 = 5
  AND n_5_10 = 6
  AND c5 IS NOT NULL
ORDER BY ticker, ts_epoch
""".strip()


def load_history(conn: PgConnection, *, start_epoch: int, end_epoch: int) -> tuple[pd.DataFrame, str]:
    query = build_base_query(start_epoch=start_epoch, end_epoch=end_epoch)
    df = pd.read_sql_query(query, conn)
    return df, query


def streak_lengths(mask: np.ndarray) -> np.ndarray:
    out = np.zeros(len(mask), dtype=np.int16)
    run = 0
    for idx, flag in enumerate(mask):
        if flag:
            run += 1
        else:
            run = 0
        out[idx] = run
    return out


def add_group_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    numeric_float_cols = [
        "o",
        "c",
        "h",
        "l",
        "v",
        "hl_range_pct",
        "body_pct",
        "upper_wick",
        "lower_wick",
        "wick_ratio",
        "oc_pct",
        "gap_pct",
        "rsi",
        "macd_hist",
        "macd_hist_slope",
        "macd_hist_slope3",
        "bb_width",
        "rvol",
        "atr_pct",
        "chop",
        "vwap_dist_pct",
        "stoch_rsi_k",
        "mfi",
        "cmo",
        "roc",
        "trix",
        "ultimate_osc",
        "adx",
        "h1",
        "h2",
        "h3",
        "l1",
        "l2",
        "l3",
        "c1",
        "c2",
        "c3",
        "c4",
        "c5",
        "c10",
        "max_h_1_5",
        "min_l_1_5",
        "max_h_1_10",
        "min_l_1_10",
        "max_h_5_10",
        "min_l_5_10",
    ]
    numeric_int_cols = ["ts_epoch", "td_buy_count", "td_sell_count", "n_1_5", "n_1_10", "n_5_10"]
    bool_cols = [
        "candle_green",
        "candle_red",
        "is_gap",
        "is_inside_bar",
        "bb_close_outside_lower",
        "bb_close_outside_upper",
        "candle_completely_below_lower",
        "candle_completely_above_upper",
        "vwap_cross_up",
        "vwap_cross_dn",
        "trend_regime",
        "volume_confirm",
        "squeeze_off",
        "adx_strong",
        "di_bull",
        "di_bear",
        "ema_stack_bull",
        "ema_stack_bear",
        "macd_cross_up",
        "macd_cross_dn",
        "tsi_cross_up",
        "tsi_cross_dn",
        "momentum_confirm_bull",
        "momentum_confirm_bear",
    ]
    for col in numeric_float_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").astype("float32")
    for col in numeric_int_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype("int32")
    for col in bool_cols:
        if col in df.columns:
            df[col] = df[col].fillna(False).astype(bool)

    range_denom = (df["h"] - df["l"]).replace(0, np.nan)
    df["close_pos_in_range"] = ((df["c"] - df["l"]) / range_denom).astype("float32")
    df["upper_wick_pct"] = (df["upper_wick"] / df["o"].replace(0, np.nan)).astype("float32")
    df["lower_wick_pct"] = (df["lower_wick"] / df["o"].replace(0, np.nan)).astype("float32")
    df["abs_vwap_dist_pct"] = df["vwap_dist_pct"].abs().astype("float32")
    df["abs_gap_pct"] = df["gap_pct"].abs().astype("float32")
    df["gap_up"] = df["is_gap"] & df["gap_pct"].gt(0).fillna(False)
    df["gap_down"] = df["is_gap"] & df["gap_pct"].lt(0).fillna(False)
    df["body_to_range"] = (df["body_pct"] / df["hl_range_pct"].replace(0, np.nan)).astype("float32")
    df["upper_wick_to_body"] = (df["upper_wick_pct"] / df["body_pct"].replace(0, np.nan)).astype("float32")
    df["lower_wick_to_body"] = (df["lower_wick_pct"] / df["body_pct"].replace(0, np.nan)).astype("float32")
    df["macd_hist_positive"] = df["macd_hist"].gt(0).fillna(False)
    df["macd_hist_negative"] = df["macd_hist"].lt(0).fillna(False)
    df["macd_bull_accel"] = (
        df["macd_hist"].gt(0).fillna(False)
        & df["macd_hist_slope"].gt(0).fillna(False)
        & df["macd_hist_slope3"].gt(0).fillna(False)
    )
    df["macd_bear_accel"] = (
        df["macd_hist"].lt(0).fillna(False)
        & df["macd_hist_slope"].lt(0).fillna(False)
        & df["macd_hist_slope3"].lt(0).fillna(False)
    )
    df["cross_stack_bull"] = df["vwap_cross_up"] & (df["macd_cross_up"] | df["tsi_cross_up"] | df["di_bull"])
    df["cross_stack_bear"] = df["vwap_cross_dn"] & (df["macd_cross_dn"] | df["tsi_cross_dn"] | df["di_bear"])

    df["bar1_up_ret"] = (df["h1"] / df["c"].replace(0, np.nan) - 1.0).astype("float32")
    df["bar2_up_ret"] = (df[["h1", "h2"]].max(axis=1) / df["c"].replace(0, np.nan) - 1.0).astype("float32")
    df["bar3_up_ret"] = (df[["h1", "h2", "h3"]].max(axis=1) / df["c"].replace(0, np.nan) - 1.0).astype("float32")
    df["bar1_down_ret"] = (df["c"] / df["l1"].replace(0, np.nan) - 1.0).astype("float32")
    df["bar2_down_ret"] = (df["c"] / df[["l1", "l2"]].min(axis=1).replace(0, np.nan) - 1.0).astype("float32")
    df["bar3_down_ret"] = (df["c"] / df[["l1", "l2", "l3"]].min(axis=1).replace(0, np.nan) - 1.0).astype("float32")
    df["best_up_ret_1_10"] = (df["max_h_1_10"] / df["c"].replace(0, np.nan) - 1.0).astype("float32")
    df["best_down_ret_1_10"] = (df["c"] / df["min_l_1_10"].replace(0, np.nan) - 1.0).astype("float32")
    df["sustain_up_ret_5_10"] = (df["max_h_5_10"] / df["c"].replace(0, np.nan) - 1.0).astype("float32")
    df["sustain_down_ret_5_10"] = (df["c"] / df["min_l_5_10"].replace(0, np.nan) - 1.0).astype("float32")
    df["hold_up_ret_5"] = (df["c5"] / df["c"].replace(0, np.nan) - 1.0).astype("float32")
    df["hold_down_ret_5"] = (df["c"] / df["c5"].replace(0, np.nan) - 1.0).astype("float32")
    df["adverse_bull_ret_1_3"] = (df["l1"] / df["c"].replace(0, np.nan) - 1.0).astype("float32")
    df["adverse_bear_ret_1_3"] = (df["h1"] / df["c"].replace(0, np.nan) - 1.0).astype("float32")

    df["ts_dt"] = pd.to_datetime(df["ts_epoch"], unit="s", utc=True).dt.tz_convert(MARKET_TZ)
    df["date_dt"] = df["ts_dt"].dt.date
    minute_of_day = (df["ts_dt"].dt.hour * 60 + df["ts_dt"].dt.minute).astype("int16")
    df["minute_of_day"] = minute_of_day
    df["tod_opening"] = minute_of_day <= 10 * 60 + 30
    df["tod_first_hour"] = minute_of_day <= 10 * 60 + 30
    df["tod_midday"] = (minute_of_day >= 11 * 60 + 30) & (minute_of_day <= 13 * 60 + 30)
    df["tod_lunch"] = (minute_of_day >= 11 * 60 + 30) & (minute_of_day <= 13 * 60 + 0)
    df["tod_power_hour"] = minute_of_day >= 15 * 60
    df["tod_afternoon"] = minute_of_day >= 14 * 60

    frames: List[pd.DataFrame] = []
    for _, group in df.groupby("ticker", sort=False):
        part = group.copy()
        red = part["candle_red"].to_numpy(dtype=bool)
        green = part["candle_green"].to_numpy(dtype=bool)
        close_change = part["c"].diff().to_numpy()
        volume_change = part["v"].diff().to_numpy()
        range_change = part["hl_range_pct"].diff().to_numpy()

        part["red_streak"] = streak_lengths(red)
        part["green_streak"] = streak_lengths(green)
        part["down_close_streak"] = streak_lengths(np.nan_to_num(close_change, nan=0.0) < 0)
        part["up_close_streak"] = streak_lengths(np.nan_to_num(close_change, nan=0.0) > 0)
        part["vol_up_streak"] = streak_lengths(np.nan_to_num(volume_change, nan=0.0) > 0)
        part["vol_down_streak"] = streak_lengths(np.nan_to_num(volume_change, nan=0.0) < 0)
        part["range_expand_streak"] = streak_lengths(np.nan_to_num(range_change, nan=0.0) > 0)

        prev3_vol = part["v"].shift(1).rolling(3, min_periods=3).mean()
        prev3_range = part["hl_range_pct"].shift(1).rolling(3, min_periods=3).mean()
        prev3_body = part["body_pct"].shift(1).rolling(3, min_periods=3).mean()
        prev5_low = part["l"].shift(1).rolling(5, min_periods=5).min()
        prev5_close_min = part["c"].shift(1).rolling(5, min_periods=5).min()
        prev5_red = part["candle_red"].shift(1).rolling(5, min_periods=5).sum()
        prev5_green = part["candle_green"].shift(1).rolling(5, min_periods=5).sum()
        part["vol_ratio_prev3"] = (part["v"] / prev3_vol.replace(0, np.nan)).astype("float32")
        part["range_ratio_prev3"] = (part["hl_range_pct"] / prev3_range.replace(0, np.nan)).astype("float32")
        part["body_ratio_prev3"] = (part["body_pct"] / prev3_body.replace(0, np.nan)).astype("float32")
        part["prev_red_streak"] = part["red_streak"].shift(1).fillna(0).astype("int16")
        part["prev_green_streak"] = part["green_streak"].shift(1).fillna(0).astype("int16")
        part["prev_down_close_streak"] = part["down_close_streak"].shift(1).fillna(0).astype("int16")
        part["prev_up_close_streak"] = part["up_close_streak"].shift(1).fillna(0).astype("int16")
        part["prev_vol_down_streak"] = part["vol_down_streak"].shift(1).fillna(0).astype("int16")
        part["prev_vol_up_streak"] = part["vol_up_streak"].shift(1).fillna(0).astype("int16")
        part["at_prev5_low"] = part["c"].le(prev5_low).fillna(False)
        part["below_prev5_close_min"] = part["c"].le(prev5_close_min).fillna(False)
        part["prev5_red_count"] = prev5_red.fillna(0).astype("int16")
        part["prev5_green_count"] = prev5_green.fillna(0).astype("int16")
        frames.append(part)

    out = pd.concat(frames, ignore_index=True)
    out["flush_then_green"] = out["candle_green"] & (out["prev_red_streak"] >= 3)
    out["flush_then_red"] = out["candle_red"] & (out["prev_green_streak"] >= 3)
    out["deep_below_vwap"] = out["vwap_dist_pct"] <= -0.01
    out["deep_above_vwap"] = out["vwap_dist_pct"] >= 0.01
    out["volume_reaccel"] = out["vol_ratio_prev3"].ge(1.2).fillna(False) & out["vol_up_streak"].ge(2).fillna(False)
    out["volume_fade"] = out["vol_down_streak"].ge(2).fillna(False)
    out["reclaim_green_strong"] = (
        out["candle_green"]
        & out["close_pos_in_range"].ge(0.80).fillna(False)
        & out["body_pct"].ge(0.05).fillna(False)
        & out["upper_wick_pct"].le(0.03).fillna(False)
    )
    out["reclaim_green_extreme"] = (
        out["candle_green"]
        & out["close_pos_in_range"].ge(0.90).fillna(False)
        & out["body_pct"].ge(0.08).fillna(False)
        & out["upper_wick_pct"].le(0.02).fillna(False)
    )
    out["flush_red_body"] = (
        out["candle_red"]
        & out["close_pos_in_range"].le(0.20).fillna(False)
        & out["body_pct"].ge(0.08).fillna(False)
    )
    out["flush_green_body"] = (
        out["candle_green"]
        & out["close_pos_in_range"].ge(0.80).fillna(False)
        & out["body_pct"].ge(0.08).fillna(False)
    )
    out["hammer_like"] = (
        out["lower_wick_pct"].ge(0.05).fillna(False)
        & out["upper_wick_pct"].le(0.02).fillna(False)
        & out["close_pos_in_range"].ge(0.60).fillna(False)
    )
    out["shooting_star_like"] = (
        out["upper_wick_pct"].ge(0.05).fillna(False)
        & out["lower_wick_pct"].le(0.02).fillna(False)
        & out["close_pos_in_range"].le(0.40).fillna(False)
    )
    out["doji_large"] = (
        out["body_pct"].le(0.02).fillna(False)
        & out["hl_range_pct"].ge(0.20).fillna(False)
    )
    out["marubozu_green"] = (
        out["candle_green"]
        & out["body_to_range"].ge(0.70).fillna(False)
        & out["close_pos_in_range"].ge(0.90).fillna(False)
    )
    out["marubozu_red"] = (
        out["candle_red"]
        & out["body_to_range"].ge(0.70).fillna(False)
        & out["close_pos_in_range"].le(0.10).fillna(False)
    )

    out["friday_arm_bull_current"] = (
        (
            out["rsi"].le(30).fillna(False)
            & out["td_buy_count"].ge(10).fillna(False)
            & out["rvol"].ge(2.0).fillna(False)
            & out["trend_regime"]
            & out["mfi"].le(20).fillna(False)
            & out["stoch_rsi_k"].le(20).fillna(False)
            & out["macd_hist"].lt(0).fillna(False)
        )
        | (
            out["rsi"].le(30).fillna(False)
            & out["td_buy_count"].ge(8).fillna(False)
            & out["rvol"].ge(1.5).fillna(False)
            & out["mfi"].le(20).fillna(False)
            & out["macd_hist"].lt(0).fillna(False)
        )
        | (
            out["rsi"].le(25).fillna(False)
            & out["td_buy_count"].ge(10).fillna(False)
            & out["rvol"].ge(1.5).fillna(False)
            & out["macd_hist"].lt(0).fillna(False)
        )
        | (
            out["rsi"].le(30).fillna(False)
            & out["td_buy_count"].ge(8).fillna(False)
            & out["rvol"].ge(2.0).fillna(False)
            & out["stoch_rsi_k"].le(20).fillna(False)
            & out["trend_regime"]
            & out["macd_hist"].lt(0).fillna(False)
        )
        | (
            out["rsi"].le(30).fillna(False)
            & out["td_buy_count"].ge(8).fillna(False)
            & out["rvol"].ge(2.0).fillna(False)
            & out["stoch_rsi_k"].le(10).fillna(False)
            & out["macd_hist"].lt(0).fillna(False)
        )
    )
    out["friday_arm_bear_current"] = (
        out["rsi"].ge(75).fillna(False)
        & out["td_sell_count"].ge(8).fillna(False)
        & out["rvol"].ge(1.5).fillna(False)
        & out["roc"].ge(1.0).fillna(False)
        & out["macd_hist"].gt(0).fillna(False)
    )

    confirm_frames: List[pd.DataFrame] = []
    for _, group in out.groupby("ticker", sort=False):
        part = group.copy()
        part["recent_friday_arm_bull_15"] = (
            part["friday_arm_bull_current"].shift(1).rolling(15, min_periods=1).max().fillna(0).astype(bool)
        )
        part["recent_friday_arm_bear_15"] = (
            part["friday_arm_bear_current"].shift(1).rolling(15, min_periods=1).max().fillna(0).astype(bool)
        )
        confirm_frames.append(part)
    out = pd.concat(confirm_frames, ignore_index=True)
    return out


def build_base_mask(df: pd.DataFrame, side: str, profile: str) -> pd.Series:
    vol_ok = (
        df["atr_pct"].ge(0.002).fillna(False)
        | df["hl_range_pct"].ge(0.18).fillna(False)
        | df["bb_width"].ge(0.02).fillna(False)
        | df["rvol"].ge(1.2).fillna(False)
    )
    profile_key = str(profile or "reversal").strip().lower()
    if profile_key == "reversal":
        if side == "bullish":
            context = (
                df["rsi"].le(40).fillna(False)
                | df["td_buy_count"].ge(6).fillna(False)
                | df["stoch_rsi_k"].le(20).fillna(False)
                | df["mfi"].le(25).fillna(False)
                | df["vwap_dist_pct"].le(-0.005).fillna(False)
                | df["bb_close_outside_lower"]
                | df["candle_completely_below_lower"]
                | df["prev_red_streak"].ge(3).fillna(False)
                | df["prev_down_close_streak"].ge(3).fillna(False)
            )
            return context & vol_ok
        context = (
            df["rsi"].ge(60).fillna(False)
            | df["td_sell_count"].ge(6).fillna(False)
            | df["stoch_rsi_k"].ge(80).fillna(False)
            | df["mfi"].ge(75).fillna(False)
            | df["vwap_dist_pct"].ge(0.005).fillna(False)
            | df["bb_close_outside_upper"]
            | df["candle_completely_above_upper"]
            | df["prev_green_streak"].ge(3).fillna(False)
            | df["prev_up_close_streak"].ge(3).fillna(False)
        )
        return context & vol_ok

    if profile_key == "reclaim":
        if side == "bullish":
            return (
                vol_ok
                & df["candle_green"]
                & df["close_pos_in_range"].ge(0.65).fillna(False)
                & (
                    df["prev_red_streak"].ge(2).fillna(False)
                    | df["prev_down_close_streak"].ge(2).fillna(False)
                    | df["vwap_dist_pct"].le(-0.003).fillna(False)
                    | df["cmo"].le(-20).fillna(False)
                    | df["td_buy_count"].ge(6).fillna(False)
                )
            )
        return (
            vol_ok
            & df["candle_red"]
            & df["close_pos_in_range"].le(0.35).fillna(False)
            & (
                df["prev_green_streak"].ge(2).fillna(False)
                | df["prev_up_close_streak"].ge(2).fillna(False)
                | df["vwap_dist_pct"].ge(0.003).fillna(False)
                | df["cmo"].ge(20).fillna(False)
                | df["td_sell_count"].ge(6).fillna(False)
            )
        )

    if profile_key == "continuation":
        if side == "bullish":
            impulse = (
                df["candle_green"]
                & df["close_pos_in_range"].ge(0.80).fillna(False)
                & (
                    df["body_pct"].ge(0.05).fillna(False)
                    | df["marubozu_green"]
                    | df["reclaim_green_strong"]
                )
            )
            participation = (
                df["volume_confirm"]
                | df["vol_ratio_prev3"].ge(1.2).fillna(False)
                | df["rvol"].ge(1.2).fillna(False)
            )
            context = (
                df["prev_red_streak"].ge(2).fillna(False)
                | df["prev_down_close_streak"].ge(2).fillna(False)
                | df["vwap_dist_pct"].le(-0.002).fillna(False)
                | df["roc"].le(-0.5).fillna(False)
                | df["cmo"].le(-10).fillna(False)
            )
            return vol_ok & impulse & participation & context
        impulse = (
            df["candle_red"]
            & df["close_pos_in_range"].le(0.20).fillna(False)
            & (
                df["body_pct"].ge(0.05).fillna(False)
                | df["marubozu_red"]
                | df["flush_red_body"]
            )
        )
        participation = (
            df["volume_confirm"]
            | df["vol_ratio_prev3"].ge(1.2).fillna(False)
            | df["rvol"].ge(1.2).fillna(False)
        )
        context = (
            df["prev_green_streak"].ge(2).fillna(False)
            | df["prev_up_close_streak"].ge(2).fillna(False)
            | df["vwap_dist_pct"].ge(0.002).fillna(False)
            | df["roc"].ge(0.5).fillna(False)
            | df["cmo"].ge(10).fillna(False)
        )
        return vol_ok & impulse & participation & context

    if profile_key == "expansion":
        if side == "bullish":
            return (
                vol_ok
                & (
                    df["bb_width"].ge(0.05).fillna(False)
                    | df["atr_pct"].ge(0.005).fillna(False)
                    | df["hl_range_pct"].ge(0.35).fillna(False)
                )
                & (
                    df["vwap_dist_pct"].le(-0.01).fillna(False)
                    | df["mfi"].le(15).fillna(False)
                    | df["stoch_rsi_k"].le(10).fillna(False)
                    | df["td_buy_count"].ge(8).fillna(False)
                )
            )
        return (
            vol_ok
            & (
                df["bb_width"].ge(0.05).fillna(False)
                | df["atr_pct"].ge(0.005).fillna(False)
                | df["hl_range_pct"].ge(0.35).fillna(False)
            )
            & (
                df["vwap_dist_pct"].ge(0.01).fillna(False)
                | df["mfi"].ge(85).fillna(False)
                | df["stoch_rsi_k"].ge(90).fillna(False)
                | df["td_sell_count"].ge(8).fillna(False)
            )
        )

    if profile_key == "friday_arm":
        if side == "bullish":
            return df["friday_arm_bull_current"].fillna(False)
        return df["friday_arm_bear_current"].fillna(False)

    if profile_key == "friday_confirm":
        if side == "bullish":
            return df["recent_friday_arm_bull_15"].fillna(False) & ~df["friday_arm_bull_current"].fillna(False)
        return df["recent_friday_arm_bear_15"].fillna(False) & ~df["friday_arm_bear_current"].fillna(False)

    raise ValueError(f"Unsupported base profile: {profile}")


def define_outcomes(
    df: pd.DataFrame,
    *,
    trigger_bp: float,
    sustain_bp: float,
    hold_bp: float,
    max_adverse_bp: float,
    trigger_window: int,
    sustain_window: str,
    hold_bar: int,
) -> pd.DataFrame:
    out = df.copy()
    out["best_up_ret_1_5"] = (out["max_h_1_5"] / out["c"].replace(0, np.nan) - 1.0).astype("float32")
    out["best_down_ret_1_5"] = (out["c"] / out["min_l_1_5"].replace(0, np.nan) - 1.0).astype("float32")
    out["hold_up_ret_3"] = (out["c3"] / out["c"].replace(0, np.nan) - 1.0).astype("float32")
    out["hold_down_ret_3"] = (out["c"] / out["c3"].replace(0, np.nan) - 1.0).astype("float32")
    bull_trigger_col = "bar2_up_ret" if trigger_window == 2 else "bar3_up_ret"
    bear_trigger_col = "bar2_down_ret" if trigger_window == 2 else "bar3_down_ret"
    bull_sustain_col = "best_up_ret_1_5" if sustain_window == "1_5" else "sustain_up_ret_5_10"
    bear_sustain_col = "best_down_ret_1_5" if sustain_window == "1_5" else "sustain_down_ret_5_10"
    bull_hold_col = "hold_up_ret_3" if hold_bar == 3 else "hold_up_ret_5"
    bear_hold_col = "hold_down_ret_3" if hold_bar == 3 else "hold_down_ret_5"
    out["bull_success"] = (
        out[bull_trigger_col].ge(trigger_bp).fillna(False)
        & out[bull_sustain_col].ge(sustain_bp).fillna(False)
        & out[bull_hold_col].ge(hold_bp).fillna(False)
        & out["adverse_bull_ret_1_3"].ge(-max_adverse_bp).fillna(False)
    )
    out["bear_success"] = (
        out[bear_trigger_col].ge(trigger_bp).fillna(False)
        & out[bear_sustain_col].ge(sustain_bp).fillna(False)
        & out[bear_hold_col].ge(hold_bp).fillna(False)
        & out["adverse_bear_ret_1_3"].le(max_adverse_bp).fillna(False)
    )
    out["bull_trigger1"] = out["bar1_up_ret"].ge(trigger_bp).fillna(False)
    out["bull_trigger12"] = out["bar2_up_ret"].ge(trigger_bp).fillna(False)
    out["bear_trigger1"] = out["bar1_down_ret"].ge(trigger_bp).fillna(False)
    out["bear_trigger12"] = out["bar2_down_ret"].ge(trigger_bp).fillna(False)
    out["bull_hit75"] = out["best_up_ret_1_10"].ge(0.0075).fillna(False)
    out["bear_hit75"] = out["best_down_ret_1_10"].ge(0.0075).fillna(False)
    return out


def _mask_ge(series: pd.Series, threshold: float) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").ge(threshold).fillna(False)


def _mask_le(series: pd.Series, threshold: float) -> pd.Series:
    return pd.to_numeric(series, errors="coerce").le(threshold).fillna(False)


def _mask_bool(series: pd.Series) -> pd.Series:
    return series.fillna(False).astype(bool)


def _mask_between(series: pd.Series, low: float, high: float) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    return numeric.ge(low).fillna(False) & numeric.le(high).fillna(False)


def _wilson_lb(p_hat: float, n: int, z: float = 1.96) -> float:
    if n <= 0:
        return 0.0
    denom = 1.0 + (z * z) / n
    center = p_hat + (z * z) / (2 * n)
    margin = z * math.sqrt(((p_hat * (1.0 - p_hat)) + (z * z) / (4 * n)) / n)
    return max(0.0, (center - margin) / denom)


def build_specs(side: str) -> List[ConditionSpec]:
    common: List[ConditionSpec] = [
        ConditionSpec("atr_pct>=0.003", "atr_pct >= 0.003", ("atr_pct",), lambda d: _mask_ge(d["atr_pct"], 0.003)),
        ConditionSpec("atr_pct>=0.005", "atr_pct >= 0.005", ("atr_pct",), lambda d: _mask_ge(d["atr_pct"], 0.005)),
        ConditionSpec("atr_pct>=0.006", "atr_pct >= 0.006", ("atr_pct",), lambda d: _mask_ge(d["atr_pct"], 0.006)),
        ConditionSpec("bb_width>=0.03", "bb_width >= 0.03", ("bb_width",), lambda d: _mask_ge(d["bb_width"], 0.03)),
        ConditionSpec("bb_width>=0.05", "bb_width >= 0.05", ("bb_width",), lambda d: _mask_ge(d["bb_width"], 0.05)),
        ConditionSpec("bb_width>=0.07", "bb_width >= 0.07", ("bb_width",), lambda d: _mask_ge(d["bb_width"], 0.07)),
        ConditionSpec("bb_width>=0.09", "bb_width >= 0.09", ("bb_width",), lambda d: _mask_ge(d["bb_width"], 0.09)),
        ConditionSpec("rvol>=1.5", "rvol >= 1.5", ("rvol",), lambda d: _mask_ge(d["rvol"], 1.5)),
        ConditionSpec("rvol>=2.0", "rvol >= 2.0", ("rvol",), lambda d: _mask_ge(d["rvol"], 2.0)),
        ConditionSpec("rvol>=2.5", "rvol >= 2.5", ("rvol",), lambda d: _mask_ge(d["rvol"], 2.5)),
        ConditionSpec("rvol>=3.0", "rvol >= 3.0", ("rvol",), lambda d: _mask_ge(d["rvol"], 3.0)),
        ConditionSpec("rvol<=2.0", "rvol <= 2.0", ("rvol",), lambda d: _mask_le(d["rvol"], 2.0)),
        ConditionSpec("rvol<=1.5", "rvol <= 1.5", ("rvol",), lambda d: _mask_le(d["rvol"], 1.5)),
        ConditionSpec("rvol_1.0_2.5", "rvol between 1.0 and 2.5", ("rvol",), lambda d: _mask_between(d["rvol"], 1.0, 2.5)),
        ConditionSpec("volume_confirm", "volume_confirm = true", ("volume_confirm",), lambda d: _mask_bool(d["volume_confirm"])),
        ConditionSpec("close_pos<=0.35", "close_pos_in_range <= 0.35", ("close_pos_in_range",), lambda d: _mask_le(d["close_pos_in_range"], 0.35)),
        ConditionSpec("close_pos<=0.25", "close_pos_in_range <= 0.25", ("close_pos_in_range",), lambda d: _mask_le(d["close_pos_in_range"], 0.25)),
        ConditionSpec("close_pos<=0.15", "close_pos_in_range <= 0.15", ("close_pos_in_range",), lambda d: _mask_le(d["close_pos_in_range"], 0.15)),
        ConditionSpec("close_pos>=0.65", "close_pos_in_range >= 0.65", ("close_pos_in_range",), lambda d: _mask_ge(d["close_pos_in_range"], 0.65)),
        ConditionSpec("close_pos>=0.80", "close_pos_in_range >= 0.80", ("close_pos_in_range",), lambda d: _mask_ge(d["close_pos_in_range"], 0.80)),
        ConditionSpec("close_pos>=0.90", "close_pos_in_range >= 0.90", ("close_pos_in_range",), lambda d: _mask_ge(d["close_pos_in_range"], 0.90)),
        ConditionSpec("body_pct>=0.03", "body_pct >= 0.03", ("body_pct",), lambda d: _mask_ge(d["body_pct"], 0.03)),
        ConditionSpec("body_pct>=0.05", "body_pct >= 0.05", ("body_pct",), lambda d: _mask_ge(d["body_pct"], 0.05)),
        ConditionSpec("body_pct>=0.08", "body_pct >= 0.08", ("body_pct",), lambda d: _mask_ge(d["body_pct"], 0.08)),
        ConditionSpec("body_pct>=0.10", "body_pct >= 0.10", ("body_pct",), lambda d: _mask_ge(d["body_pct"], 0.10)),
        ConditionSpec("body_pct>=0.12", "body_pct >= 0.12", ("body_pct",), lambda d: _mask_ge(d["body_pct"], 0.12)),
        ConditionSpec("body_pct<=0.03", "body_pct <= 0.03", ("body_pct",), lambda d: _mask_le(d["body_pct"], 0.03)),
        ConditionSpec("hl_range_pct>=0.20", "hl_range_pct >= 0.20", ("hl_range_pct",), lambda d: _mask_ge(d["hl_range_pct"], 0.20)),
        ConditionSpec("hl_range_pct>=0.35", "hl_range_pct >= 0.35", ("hl_range_pct",), lambda d: _mask_ge(d["hl_range_pct"], 0.35)),
        ConditionSpec("hl_range_pct>=0.50", "hl_range_pct >= 0.50", ("hl_range_pct",), lambda d: _mask_ge(d["hl_range_pct"], 0.50)),
        ConditionSpec("hl_range_pct>=0.70", "hl_range_pct >= 0.70", ("hl_range_pct",), lambda d: _mask_ge(d["hl_range_pct"], 0.70)),
        ConditionSpec("body_to_range>=0.35", "body_to_range >= 0.35", ("body_to_range",), lambda d: _mask_ge(d["body_to_range"], 0.35)),
        ConditionSpec("body_to_range>=0.55", "body_to_range >= 0.55", ("body_to_range",), lambda d: _mask_ge(d["body_to_range"], 0.55)),
        ConditionSpec("body_to_range>=0.70", "body_to_range >= 0.70", ("body_to_range",), lambda d: _mask_ge(d["body_to_range"], 0.70)),
        ConditionSpec("range_ratio_prev3>=1.2", "range_ratio_prev3 >= 1.2", ("range_ratio_prev3",), lambda d: _mask_ge(d["range_ratio_prev3"], 1.2)),
        ConditionSpec("range_ratio_prev3>=1.5", "range_ratio_prev3 >= 1.5", ("range_ratio_prev3",), lambda d: _mask_ge(d["range_ratio_prev3"], 1.5)),
        ConditionSpec("range_ratio_prev3>=2.0", "range_ratio_prev3 >= 2.0", ("range_ratio_prev3",), lambda d: _mask_ge(d["range_ratio_prev3"], 2.0)),
        ConditionSpec("body_ratio_prev3>=1.2", "body_ratio_prev3 >= 1.2", ("body_ratio_prev3",), lambda d: _mask_ge(d["body_ratio_prev3"], 1.2)),
        ConditionSpec("body_ratio_prev3>=1.5", "body_ratio_prev3 >= 1.5", ("body_ratio_prev3",), lambda d: _mask_ge(d["body_ratio_prev3"], 1.5)),
        ConditionSpec("body_ratio_prev3>=2.0", "body_ratio_prev3 >= 2.0", ("body_ratio_prev3",), lambda d: _mask_ge(d["body_ratio_prev3"], 2.0)),
        ConditionSpec("body_ratio_prev3>=3.0", "body_ratio_prev3 >= 3.0", ("body_ratio_prev3",), lambda d: _mask_ge(d["body_ratio_prev3"], 3.0)),
        ConditionSpec("vol_ratio_prev3>=1.2", "vol_ratio_prev3 >= 1.2", ("vol_ratio_prev3",), lambda d: _mask_ge(d["vol_ratio_prev3"], 1.2)),
        ConditionSpec("vol_ratio_prev3>=1.5", "vol_ratio_prev3 >= 1.5", ("vol_ratio_prev3",), lambda d: _mask_ge(d["vol_ratio_prev3"], 1.5)),
        ConditionSpec("vol_ratio_prev3>=2.0", "vol_ratio_prev3 >= 2.0", ("vol_ratio_prev3",), lambda d: _mask_ge(d["vol_ratio_prev3"], 2.0)),
        ConditionSpec("vol_ratio_prev3>=3.0", "vol_ratio_prev3 >= 3.0", ("vol_ratio_prev3",), lambda d: _mask_ge(d["vol_ratio_prev3"], 3.0)),
        ConditionSpec("vol_ratio_prev3<=1.5", "vol_ratio_prev3 <= 1.5", ("vol_ratio_prev3",), lambda d: _mask_le(d["vol_ratio_prev3"], 1.5)),
        ConditionSpec("vol_ratio_0.8_1.8", "vol_ratio_prev3 between 0.8 and 1.8", ("vol_ratio_prev3",), lambda d: _mask_between(d["vol_ratio_prev3"], 0.8, 1.8)),
        ConditionSpec("red_streak>=3", "red_streak >= 3", ("red_streak",), lambda d: _mask_ge(d["red_streak"], 3)),
        ConditionSpec("green_streak>=3", "green_streak >= 3", ("green_streak",), lambda d: _mask_ge(d["green_streak"], 3)),
        ConditionSpec("prev_red_streak>=3", "prev_red_streak >= 3", ("prev_red_streak",), lambda d: _mask_ge(d["prev_red_streak"], 3)),
        ConditionSpec("prev_green_streak>=3", "prev_green_streak >= 3", ("prev_green_streak",), lambda d: _mask_ge(d["prev_green_streak"], 3)),
        ConditionSpec("prev5_red_count>=3", "prev5_red_count >= 3", ("prev5_red_count",), lambda d: _mask_ge(d["prev5_red_count"], 3)),
        ConditionSpec("prev5_red_count>=4", "prev5_red_count >= 4", ("prev5_red_count",), lambda d: _mask_ge(d["prev5_red_count"], 4)),
        ConditionSpec("prev5_green_count>=3", "prev5_green_count >= 3", ("prev5_green_count",), lambda d: _mask_ge(d["prev5_green_count"], 3)),
        ConditionSpec("at_prev5_low", "close <= prior 5-bar low", ("at_prev5_low",), lambda d: _mask_bool(d["at_prev5_low"])),
        ConditionSpec("below_prev5_close_min", "close <= prior 5-bar close min", ("below_prev5_close_min",), lambda d: _mask_bool(d["below_prev5_close_min"])),
        ConditionSpec("prev_down_close_streak>=3", "prev_down_close_streak >= 3", ("prev_down_close_streak",), lambda d: _mask_ge(d["prev_down_close_streak"], 3)),
        ConditionSpec("prev_up_close_streak>=3", "prev_up_close_streak >= 3", ("prev_up_close_streak",), lambda d: _mask_ge(d["prev_up_close_streak"], 3)),
        ConditionSpec("prev_vol_down_streak>=2", "prev_vol_down_streak >= 2", ("prev_vol_down_streak",), lambda d: _mask_ge(d["prev_vol_down_streak"], 2)),
        ConditionSpec("prev_vol_up_streak>=2", "prev_vol_up_streak >= 2", ("prev_vol_up_streak",), lambda d: _mask_ge(d["prev_vol_up_streak"], 2)),
        ConditionSpec("vol_up_streak>=2", "vol_up_streak >= 2", ("vol_up_streak",), lambda d: _mask_ge(d["vol_up_streak"], 2)),
        ConditionSpec("vol_down_streak>=2", "vol_down_streak >= 2", ("vol_down_streak",), lambda d: _mask_ge(d["vol_down_streak"], 2)),
        ConditionSpec("tod_opening", "tod_opening = true", ("tod_opening",), lambda d: _mask_bool(d["tod_opening"])),
        ConditionSpec("tod_midday", "tod_midday = true", ("tod_midday",), lambda d: _mask_bool(d["tod_midday"])),
        ConditionSpec("tod_afternoon", "tod_afternoon = true", ("tod_afternoon",), lambda d: _mask_bool(d["tod_afternoon"])),
        ConditionSpec("is_gap", "is_gap = true", ("is_gap",), lambda d: _mask_bool(d["is_gap"])),
        ConditionSpec("gap_up", "gap_pct > 0 AND is_gap = true", ("gap_up",), lambda d: _mask_bool(d["gap_up"])),
        ConditionSpec("gap_down", "gap_pct < 0 AND is_gap = true", ("gap_down",), lambda d: _mask_bool(d["gap_down"])),
        ConditionSpec("abs_gap_pct>=0.10", "abs_gap_pct >= 0.10", ("abs_gap_pct",), lambda d: _mask_ge(d["abs_gap_pct"], 0.10)),
        ConditionSpec("abs_gap_pct>=0.25", "abs_gap_pct >= 0.25", ("abs_gap_pct",), lambda d: _mask_ge(d["abs_gap_pct"], 0.25)),
        ConditionSpec("abs_gap_pct>=0.50", "abs_gap_pct >= 0.50", ("abs_gap_pct",), lambda d: _mask_ge(d["abs_gap_pct"], 0.50)),
        ConditionSpec("chop<=45", "chop <= 45", ("chop",), lambda d: _mask_le(d["chop"], 45)),
        ConditionSpec("chop<=38", "chop <= 38", ("chop",), lambda d: _mask_le(d["chop"], 38)),
        ConditionSpec("adx>=20", "adx >= 20", ("adx",), lambda d: _mask_ge(d["adx"], 20)),
        ConditionSpec("adx>=25", "adx >= 25", ("adx",), lambda d: _mask_ge(d["adx"], 25)),
        ConditionSpec("adx_strong", "adx_strong = true", ("adx_strong",), lambda d: _mask_bool(d["adx_strong"])),
        ConditionSpec("trend_regime", "trend_regime = true", ("trend_regime",), lambda d: _mask_bool(d["trend_regime"])),
        ConditionSpec("squeeze_off", "squeeze_off = true", ("squeeze_off",), lambda d: _mask_bool(d["squeeze_off"])),
        ConditionSpec("volume_reaccel", "volume_reaccel = true", ("volume_reaccel",), lambda d: _mask_bool(d["volume_reaccel"])),
        ConditionSpec("volume_fade", "volume_fade = true", ("volume_fade",), lambda d: _mask_bool(d["volume_fade"])),
        ConditionSpec("doji_large", "doji_large = true", ("doji_large",), lambda d: _mask_bool(d["doji_large"])),
        ConditionSpec("is_inside_bar", "is_inside_bar = true", ("is_inside_bar",), lambda d: _mask_bool(d["is_inside_bar"])),
        ConditionSpec("tod_first_hour", "minute_of_day <= 10:30", ("tod_first_hour",), lambda d: _mask_bool(d["tod_first_hour"])),
        ConditionSpec("tod_lunch", "11:30 <= minute_of_day <= 13:00", ("tod_lunch",), lambda d: _mask_bool(d["tod_lunch"])),
        ConditionSpec("tod_power_hour", "minute_of_day >= 15:00", ("tod_power_hour",), lambda d: _mask_bool(d["tod_power_hour"])),
        ConditionSpec("range_expand_streak>=2", "range_expand_streak >= 2", ("range_expand_streak",), lambda d: _mask_ge(d["range_expand_streak"], 2)),
        ConditionSpec("range_expand_streak>=3", "range_expand_streak >= 3", ("range_expand_streak",), lambda d: _mask_ge(d["range_expand_streak"], 3)),
    ]

    if side == "bullish":
        return common + [
            ConditionSpec("rsi<=35", "rsi <= 35", ("rsi",), lambda d: _mask_le(d["rsi"], 35)),
            ConditionSpec("rsi<=28", "rsi <= 28", ("rsi",), lambda d: _mask_le(d["rsi"], 28)),
            ConditionSpec("rsi<=24", "rsi <= 24", ("rsi",), lambda d: _mask_le(d["rsi"], 24)),
            ConditionSpec("rsi<=20", "rsi <= 20", ("rsi",), lambda d: _mask_le(d["rsi"], 20)),
            ConditionSpec("td_buy>=8", "td_buy_count >= 8", ("td_buy_count",), lambda d: _mask_ge(d["td_buy_count"], 8)),
            ConditionSpec("td_buy>=10", "td_buy_count >= 10", ("td_buy_count",), lambda d: _mask_ge(d["td_buy_count"], 10)),
            ConditionSpec("td_buy>=13", "td_buy_count >= 13", ("td_buy_count",), lambda d: _mask_ge(d["td_buy_count"], 13)),
            ConditionSpec("td_buy>=15", "td_buy_count >= 15", ("td_buy_count",), lambda d: _mask_ge(d["td_buy_count"], 15)),
            ConditionSpec("stoch<=2", "stoch_rsi_k <= 2", ("stoch_rsi_k",), lambda d: _mask_le(d["stoch_rsi_k"], 2)),
            ConditionSpec("stoch<=1", "stoch_rsi_k <= 1", ("stoch_rsi_k",), lambda d: _mask_le(d["stoch_rsi_k"], 1)),
            ConditionSpec("stoch<=5", "stoch_rsi_k <= 5", ("stoch_rsi_k",), lambda d: _mask_le(d["stoch_rsi_k"], 5)),
            ConditionSpec("stoch<=10", "stoch_rsi_k <= 10", ("stoch_rsi_k",), lambda d: _mask_le(d["stoch_rsi_k"], 10)),
            ConditionSpec("stoch<=20", "stoch_rsi_k <= 20", ("stoch_rsi_k",), lambda d: _mask_le(d["stoch_rsi_k"], 20)),
            ConditionSpec("mfi<=5", "mfi <= 5", ("mfi",), lambda d: _mask_le(d["mfi"], 5)),
            ConditionSpec("mfi<=15", "mfi <= 15", ("mfi",), lambda d: _mask_le(d["mfi"], 15)),
            ConditionSpec("mfi<=10", "mfi <= 10", ("mfi",), lambda d: _mask_le(d["mfi"], 10)),
            ConditionSpec("mfi<=20", "mfi <= 20", ("mfi",), lambda d: _mask_le(d["mfi"], 20)),
            ConditionSpec("cmo<=-60", "cmo <= -60", ("cmo",), lambda d: _mask_le(d["cmo"], -60)),
            ConditionSpec("cmo<=-50", "cmo <= -50", ("cmo",), lambda d: _mask_le(d["cmo"], -50)),
            ConditionSpec("cmo<=-40", "cmo <= -40", ("cmo",), lambda d: _mask_le(d["cmo"], -40)),
            ConditionSpec("roc<=-2.0", "roc <= -2.0", ("roc",), lambda d: _mask_le(d["roc"], -2.0)),
            ConditionSpec("roc<=-1.0", "roc <= -1.0", ("roc",), lambda d: _mask_le(d["roc"], -1.0)),
            ConditionSpec("roc<=-1.5", "roc <= -1.5", ("roc",), lambda d: _mask_le(d["roc"], -1.5)),
            ConditionSpec("trix<=-0.10", "trix <= -0.10", ("trix",), lambda d: _mask_le(d["trix"], -0.10)),
            ConditionSpec("trix<=-0.05", "trix <= -0.05", ("trix",), lambda d: _mask_le(d["trix"], -0.05)),
            ConditionSpec("trix<=-0.08", "trix <= -0.08", ("trix",), lambda d: _mask_le(d["trix"], -0.08)),
            ConditionSpec("vwap<=-0.015", "vwap_dist_pct <= -0.015", ("vwap_dist_pct",), lambda d: _mask_le(d["vwap_dist_pct"], -0.015)),
            ConditionSpec("vwap<=-0.020", "vwap_dist_pct <= -0.020", ("vwap_dist_pct",), lambda d: _mask_le(d["vwap_dist_pct"], -0.020)),
            ConditionSpec("vwap<=-0.006", "vwap_dist_pct <= -0.006", ("vwap_dist_pct",), lambda d: _mask_le(d["vwap_dist_pct"], -0.006)),
            ConditionSpec("vwap<=-0.010", "vwap_dist_pct <= -0.010", ("vwap_dist_pct",), lambda d: _mask_le(d["vwap_dist_pct"], -0.010)),
            ConditionSpec("ultimate<=30", "ultimate_osc <= 30", ("ultimate_osc",), lambda d: _mask_le(d["ultimate_osc"], 30)),
            ConditionSpec("ultimate<=20", "ultimate_osc <= 20", ("ultimate_osc",), lambda d: _mask_le(d["ultimate_osc"], 20)),
            ConditionSpec("macd_hist_negative", "macd_hist < 0", ("macd_hist_negative",), lambda d: _mask_bool(d["macd_hist_negative"])),
            ConditionSpec("macd_bull_accel", "macd_hist > 0 AND slopes > 0", ("macd_bull_accel",), lambda d: _mask_bool(d["macd_bull_accel"])),
            ConditionSpec("lower_wick_pct>=0.05", "lower_wick_pct >= 0.05", ("lower_wick_pct",), lambda d: _mask_ge(d["lower_wick_pct"], 0.05)),
            ConditionSpec("lower_wick_pct>=0.10", "lower_wick_pct >= 0.10", ("lower_wick_pct",), lambda d: _mask_ge(d["lower_wick_pct"], 0.10)),
            ConditionSpec("lower_wick_pct>=0.15", "lower_wick_pct >= 0.15", ("lower_wick_pct",), lambda d: _mask_ge(d["lower_wick_pct"], 0.15)),
            ConditionSpec("wick_ratio<=0.75", "wick_ratio <= 0.75", ("wick_ratio",), lambda d: _mask_le(d["wick_ratio"], 0.75)),
            ConditionSpec("wick_ratio<=0.40", "wick_ratio <= 0.40", ("wick_ratio",), lambda d: _mask_le(d["wick_ratio"], 0.40)),
            ConditionSpec("lower_wick_to_body>=1.5", "lower_wick_to_body >= 1.5", ("lower_wick_to_body",), lambda d: _mask_ge(d["lower_wick_to_body"], 1.5)),
            ConditionSpec("lower_wick_to_body>=2.0", "lower_wick_to_body >= 2.0", ("lower_wick_to_body",), lambda d: _mask_ge(d["lower_wick_to_body"], 2.0)),
            ConditionSpec("bb_outside_lower", "bb_close_outside_lower = true", ("bb_close_outside_lower",), lambda d: _mask_bool(d["bb_close_outside_lower"])),
            ConditionSpec("below_lower_band", "candle_completely_below_lower = true", ("candle_completely_below_lower",), lambda d: _mask_bool(d["candle_completely_below_lower"])),
            ConditionSpec("flush_then_green", "candle_green = true AND prev_red_streak >= 3", ("flush_then_green",), lambda d: _mask_bool(d["flush_then_green"])),
            ConditionSpec("reclaim_green_strong", "reclaim_green_strong = true", ("reclaim_green_strong",), lambda d: _mask_bool(d["reclaim_green_strong"])),
            ConditionSpec("reclaim_green_extreme", "reclaim_green_extreme = true", ("reclaim_green_extreme",), lambda d: _mask_bool(d["reclaim_green_extreme"])),
            ConditionSpec("flush_red_body", "flush_red_body = true", ("flush_red_body",), lambda d: _mask_bool(d["flush_red_body"])),
            ConditionSpec("hammer_like", "hammer_like = true", ("hammer_like",), lambda d: _mask_bool(d["hammer_like"])),
            ConditionSpec("marubozu_green", "marubozu_green = true", ("marubozu_green",), lambda d: _mask_bool(d["marubozu_green"])),
            ConditionSpec("candle_red", "candle_red = true", ("candle_red",), lambda d: _mask_bool(d["candle_red"])),
            ConditionSpec("candle_green", "candle_green = true", ("candle_green",), lambda d: _mask_bool(d["candle_green"])),
            ConditionSpec("vwap_cross_up", "vwap_cross_up = true", ("vwap_cross_up",), lambda d: _mask_bool(d["vwap_cross_up"])),
            ConditionSpec("macd_cross_up", "macd_cross_up = true", ("macd_cross_up",), lambda d: _mask_bool(d["macd_cross_up"])),
            ConditionSpec("tsi_cross_up", "tsi_cross_up = true", ("tsi_cross_up",), lambda d: _mask_bool(d["tsi_cross_up"])),
            ConditionSpec("cross_stack_bull", "vwap_cross_up AND one bull cross/DI", ("cross_stack_bull",), lambda d: _mask_bool(d["cross_stack_bull"])),
            ConditionSpec("di_bull", "di_bull = true", ("di_bull",), lambda d: _mask_bool(d["di_bull"])),
            ConditionSpec("ema_stack_bull", "ema_stack_bull = true", ("ema_stack_bull",), lambda d: _mask_bool(d["ema_stack_bull"])),
            ConditionSpec("momentum_confirm_bull", "momentum_confirm_bull = true", ("momentum_confirm_bull",), lambda d: _mask_bool(d["momentum_confirm_bull"])),
        ]

    return common + [
        ConditionSpec("rsi>=72", "rsi >= 72", ("rsi",), lambda d: _mask_ge(d["rsi"], 72)),
        ConditionSpec("rsi>=80", "rsi >= 80", ("rsi",), lambda d: _mask_ge(d["rsi"], 80)),
        ConditionSpec("rsi>=85", "rsi >= 85", ("rsi",), lambda d: _mask_ge(d["rsi"], 85)),
        ConditionSpec("td_sell>=8", "td_sell_count >= 8", ("td_sell_count",), lambda d: _mask_ge(d["td_sell_count"], 8)),
        ConditionSpec("td_sell>=10", "td_sell_count >= 10", ("td_sell_count",), lambda d: _mask_ge(d["td_sell_count"], 10)),
        ConditionSpec("td_sell>=13", "td_sell_count >= 13", ("td_sell_count",), lambda d: _mask_ge(d["td_sell_count"], 13)),
        ConditionSpec("td_sell>=15", "td_sell_count >= 15", ("td_sell_count",), lambda d: _mask_ge(d["td_sell_count"], 15)),
        ConditionSpec("stoch>=80", "stoch_rsi_k >= 80", ("stoch_rsi_k",), lambda d: _mask_ge(d["stoch_rsi_k"], 80)),
        ConditionSpec("stoch>=90", "stoch_rsi_k >= 90", ("stoch_rsi_k",), lambda d: _mask_ge(d["stoch_rsi_k"], 90)),
        ConditionSpec("stoch>=95", "stoch_rsi_k >= 95", ("stoch_rsi_k",), lambda d: _mask_ge(d["stoch_rsi_k"], 95)),
        ConditionSpec("mfi>=80", "mfi >= 80", ("mfi",), lambda d: _mask_ge(d["mfi"], 80)),
        ConditionSpec("mfi>=90", "mfi >= 90", ("mfi",), lambda d: _mask_ge(d["mfi"], 90)),
        ConditionSpec("mfi>=85", "mfi >= 85", ("mfi",), lambda d: _mask_ge(d["mfi"], 85)),
        ConditionSpec("mfi>=95", "mfi >= 95", ("mfi",), lambda d: _mask_ge(d["mfi"], 95)),
        ConditionSpec("cmo>=60", "cmo >= 60", ("cmo",), lambda d: _mask_ge(d["cmo"], 60)),
        ConditionSpec("cmo>=50", "cmo >= 50", ("cmo",), lambda d: _mask_ge(d["cmo"], 50)),
        ConditionSpec("cmo>=40", "cmo >= 40", ("cmo",), lambda d: _mask_ge(d["cmo"], 40)),
        ConditionSpec("roc>=2.0", "roc >= 2.0", ("roc",), lambda d: _mask_ge(d["roc"], 2.0)),
        ConditionSpec("roc>=1.0", "roc >= 1.0", ("roc",), lambda d: _mask_ge(d["roc"], 1.0)),
        ConditionSpec("roc>=1.5", "roc >= 1.5", ("roc",), lambda d: _mask_ge(d["roc"], 1.5)),
        ConditionSpec("trix>=0.10", "trix >= 0.10", ("trix",), lambda d: _mask_ge(d["trix"], 0.10)),
        ConditionSpec("trix>=0.05", "trix >= 0.05", ("trix",), lambda d: _mask_ge(d["trix"], 0.05)),
        ConditionSpec("trix>=0.08", "trix >= 0.08", ("trix",), lambda d: _mask_ge(d["trix"], 0.08)),
        ConditionSpec("vwap>=0.015", "vwap_dist_pct >= 0.015", ("vwap_dist_pct",), lambda d: _mask_ge(d["vwap_dist_pct"], 0.015)),
        ConditionSpec("vwap>=0.020", "vwap_dist_pct >= 0.020", ("vwap_dist_pct",), lambda d: _mask_ge(d["vwap_dist_pct"], 0.020)),
        ConditionSpec("vwap>=0.006", "vwap_dist_pct >= 0.006", ("vwap_dist_pct",), lambda d: _mask_ge(d["vwap_dist_pct"], 0.006)),
        ConditionSpec("vwap>=0.010", "vwap_dist_pct >= 0.010", ("vwap_dist_pct",), lambda d: _mask_ge(d["vwap_dist_pct"], 0.010)),
        ConditionSpec("ultimate>=70", "ultimate_osc >= 70", ("ultimate_osc",), lambda d: _mask_ge(d["ultimate_osc"], 70)),
        ConditionSpec("ultimate>=80", "ultimate_osc >= 80", ("ultimate_osc",), lambda d: _mask_ge(d["ultimate_osc"], 80)),
        ConditionSpec("macd_hist_positive", "macd_hist > 0", ("macd_hist_positive",), lambda d: _mask_bool(d["macd_hist_positive"])),
        ConditionSpec("macd_bear_accel", "macd_hist < 0 AND slopes < 0", ("macd_bear_accel",), lambda d: _mask_bool(d["macd_bear_accel"])),
        ConditionSpec("upper_wick_pct>=0.05", "upper_wick_pct >= 0.05", ("upper_wick_pct",), lambda d: _mask_ge(d["upper_wick_pct"], 0.05)),
        ConditionSpec("upper_wick_pct>=0.10", "upper_wick_pct >= 0.10", ("upper_wick_pct",), lambda d: _mask_ge(d["upper_wick_pct"], 0.10)),
        ConditionSpec("upper_wick_pct>=0.15", "upper_wick_pct >= 0.15", ("upper_wick_pct",), lambda d: _mask_ge(d["upper_wick_pct"], 0.15)),
        ConditionSpec("wick_ratio>=1.5", "wick_ratio >= 1.5", ("wick_ratio",), lambda d: _mask_ge(d["wick_ratio"], 1.5)),
        ConditionSpec("wick_ratio>=2.5", "wick_ratio >= 2.5", ("wick_ratio",), lambda d: _mask_ge(d["wick_ratio"], 2.5)),
        ConditionSpec("upper_wick_to_body>=1.5", "upper_wick_to_body >= 1.5", ("upper_wick_to_body",), lambda d: _mask_ge(d["upper_wick_to_body"], 1.5)),
        ConditionSpec("upper_wick_to_body>=2.0", "upper_wick_to_body >= 2.0", ("upper_wick_to_body",), lambda d: _mask_ge(d["upper_wick_to_body"], 2.0)),
        ConditionSpec("bb_outside_upper", "bb_close_outside_upper = true", ("bb_close_outside_upper",), lambda d: _mask_bool(d["bb_close_outside_upper"])),
        ConditionSpec("above_upper_band", "candle_completely_above_upper = true", ("candle_completely_above_upper",), lambda d: _mask_bool(d["candle_completely_above_upper"])),
        ConditionSpec("flush_then_red", "candle_red = true AND prev_green_streak >= 3", ("flush_then_red",), lambda d: _mask_bool(d["flush_then_red"])),
        ConditionSpec("flush_green_body", "flush_green_body = true", ("flush_green_body",), lambda d: _mask_bool(d["flush_green_body"])),
        ConditionSpec("shooting_star_like", "shooting_star_like = true", ("shooting_star_like",), lambda d: _mask_bool(d["shooting_star_like"])),
        ConditionSpec("marubozu_red", "marubozu_red = true", ("marubozu_red",), lambda d: _mask_bool(d["marubozu_red"])),
        ConditionSpec("candle_red", "candle_red = true", ("candle_red",), lambda d: _mask_bool(d["candle_red"])),
        ConditionSpec("candle_green", "candle_green = true", ("candle_green",), lambda d: _mask_bool(d["candle_green"])),
        ConditionSpec("vwap_cross_dn", "vwap_cross_dn = true", ("vwap_cross_dn",), lambda d: _mask_bool(d["vwap_cross_dn"])),
        ConditionSpec("macd_cross_dn", "macd_cross_dn = true", ("macd_cross_dn",), lambda d: _mask_bool(d["macd_cross_dn"])),
        ConditionSpec("tsi_cross_dn", "tsi_cross_dn = true", ("tsi_cross_dn",), lambda d: _mask_bool(d["tsi_cross_dn"])),
        ConditionSpec("cross_stack_bear", "vwap_cross_dn AND one bear cross/DI", ("cross_stack_bear",), lambda d: _mask_bool(d["cross_stack_bear"])),
        ConditionSpec("di_bear", "di_bear = true", ("di_bear",), lambda d: _mask_bool(d["di_bear"])),
        ConditionSpec("ema_stack_bear", "ema_stack_bear = true", ("ema_stack_bear",), lambda d: _mask_bool(d["ema_stack_bear"])),
        ConditionSpec("momentum_confirm_bear", "momentum_confirm_bear = true", ("momentum_confirm_bear",), lambda d: _mask_bool(d["momentum_confirm_bear"])),
    ]


def evaluate_mask(
    side_df: pd.DataFrame,
    *,
    side: str,
    mask: np.ndarray,
    labels: Tuple[str, ...],
    exprs: Tuple[str, ...],
    indices: Tuple[int, ...],
    min_n: int,
    min_val_n: int,
    min_trigger12_rate: float,
    min_trigger1_rate: float,
    min_sustain75_rate: float,
    min_avg_best_ret: float,
    min_avg_hold5_ret: float,
    min_wilson_lb: float,
    min_val_wilson_lb: float,
    min_tickers: int,
    min_val_tickers: int,
) -> Optional[SearchResult]:
    count = int(mask.sum())
    if count < min_n:
        return None
    success_col = "bull_success" if side == "bullish" else "bear_success"
    trigger12_col = "bull_trigger12" if side == "bullish" else "bear_trigger12"
    trigger1_col = "bull_trigger1" if side == "bullish" else "bear_trigger1"
    hit75_col = "bull_hit75" if side == "bullish" else "bear_hit75"
    best_col = "best_up_ret_1_10" if side == "bullish" else "best_down_ret_1_10"
    hold_col = "hold_up_ret_5" if side == "bullish" else "hold_down_ret_5"
    adverse_col = "adverse_bull_ret_1_3" if side == "bullish" else "adverse_bear_ret_1_3"

    subset = side_df.loc[mask]
    train = subset.loc[~subset["is_val"]]
    val = subset.loc[subset["is_val"]]
    if len(train) < max(min_n // 2, 8) or len(val) < min_val_n:
        return None
    ticker_count = int(subset["ticker"].nunique()) if "ticker" in subset.columns else 0
    val_ticker_count = int(val["ticker"].nunique()) if "ticker" in val.columns else 0
    if ticker_count < int(min_tickers or 0):
        return None
    if val_ticker_count < int(min_val_tickers or 0):
        return None

    success_rate = float(subset[success_col].mean())
    train_success_rate = float(train[success_col].mean())
    val_success_rate = float(val[success_col].mean())
    wilson_lb = _wilson_lb(success_rate, int(len(subset)))
    train_wilson_lb = _wilson_lb(train_success_rate, int(len(train)))
    val_wilson_lb = _wilson_lb(val_success_rate, int(len(val)))

    result = SearchResult(
        side=side,
        labels=labels,
        exprs=exprs,
        count=count,
        train_count=int(len(train)),
        val_count=int(len(val)),
        ticker_count=ticker_count,
        val_ticker_count=val_ticker_count,
        success_rate=success_rate,
        train_success_rate=train_success_rate,
        val_success_rate=val_success_rate,
        wilson_lb=wilson_lb,
        train_wilson_lb=train_wilson_lb,
        val_wilson_lb=val_wilson_lb,
        trigger12_rate=float(subset[trigger12_col].mean()),
        trigger1_rate=float(subset[trigger1_col].mean()),
        sustain75_rate=float(subset[hit75_col].mean()),
        avg_best_ret=float(subset[best_col].mean()),
        avg_hold5_ret=float(subset[hold_col].mean()),
        avg_adverse_ret=float(subset[adverse_col].mean()),
        mask=mask,
        indices=indices,
    )
    if result.trigger12_rate < min_trigger12_rate:
        return None
    if result.trigger1_rate < min_trigger1_rate:
        return None
    if result.sustain75_rate < min_sustain75_rate:
        return None
    if result.avg_best_ret < min_avg_best_ret:
        return None
    if result.avg_hold5_ret < min_avg_hold5_ret:
        return None
    if result.wilson_lb < min_wilson_lb:
        return None
    if result.val_wilson_lb < min_val_wilson_lb:
        return None
    return result


def result_sort_key(result: SearchResult) -> tuple:
    return (
        -result.val_wilson_lb,
        -result.val_success_rate,
        -result.wilson_lb,
        -result.success_rate,
        -result.trigger12_rate,
        -result.avg_best_ret,
        -result.avg_hold5_ret,
        -result.count,
        len(result.labels),
        " AND ".join(result.labels),
    )


def dedupe_results(results: Iterable[SearchResult], *, top_final: int) -> List[SearchResult]:
    seen: set[Tuple[str, int, Tuple[str, ...]]] = set()
    ordered: List[SearchResult] = []
    for result in sorted(results, key=result_sort_key):
        key = (result.side, result.count, result.labels)
        if key in seen:
            continue
        seen.add(key)
        ordered.append(result)
        if len(ordered) >= top_final:
            break
    return ordered


def search_side(
    side_df: pd.DataFrame,
    *,
    side: str,
    specs: Sequence[ConditionSpec],
    min_n: int,
    min_val_n: int,
    seed_hit: float,
    val_floor: float,
    target_hit: float,
    max_k: int,
    top_seeds: int,
    top_per_depth: int,
    top_final: int,
    min_trigger12_rate: float,
    min_trigger1_rate: float,
    min_sustain75_rate: float,
    min_avg_best_ret: float,
    min_avg_hold5_ret: float,
    min_wilson_lb: float,
    min_val_wilson_lb: float,
    min_tickers: int,
    min_val_tickers: int,
) -> List[SearchResult]:
    prepared: List[tuple[int, ConditionSpec, np.ndarray]] = []
    for idx, spec in enumerate(specs):
        if not set(spec.required).issubset(side_df.columns):
            continue
        mask = spec.fn(side_df).fillna(False).to_numpy(dtype=bool)
        prepared.append((idx, spec, mask))

    seed_results: List[SearchResult] = []
    for idx, spec, mask in prepared:
        result = evaluate_mask(
            side_df,
            side=side,
            mask=mask,
            labels=(spec.label,),
            exprs=(spec.expr,),
            indices=(idx,),
            min_n=min_n,
            min_val_n=min_val_n,
            min_trigger12_rate=min_trigger12_rate,
            min_trigger1_rate=min_trigger1_rate,
            min_sustain75_rate=min_sustain75_rate,
            min_avg_best_ret=min_avg_best_ret,
            min_avg_hold5_ret=min_avg_hold5_ret,
            min_wilson_lb=min_wilson_lb,
            min_val_wilson_lb=min_val_wilson_lb,
            min_tickers=min_tickers,
            min_val_tickers=min_val_tickers,
        )
        if result is None:
            continue
        if result.train_success_rate < seed_hit or result.val_success_rate < val_floor:
            continue
        seed_results.append(result)

    seed_results.sort(key=result_sort_key)
    current_layer = seed_results[: max(1, top_seeds)]
    all_results: List[SearchResult] = [result for result in current_layer if result.success_rate >= target_hit]

    for _depth in range(2, max_k + 1):
        next_layer: List[SearchResult] = []
        for parent in current_layer:
            parent_mask = parent.mask
            last_idx = parent.indices[-1]
            for idx, spec, mask in prepared:
                if idx <= last_idx or idx in parent.indices:
                    continue
                combined_mask = parent_mask & mask
                result = evaluate_mask(
                    side_df,
                    side=side,
                    mask=combined_mask,
                    labels=parent.labels + (spec.label,),
                    exprs=parent.exprs + (spec.expr,),
                    indices=parent.indices + (idx,),
                    min_n=min_n,
                    min_val_n=min_val_n,
                    min_trigger12_rate=min_trigger12_rate,
                    min_trigger1_rate=min_trigger1_rate,
                    min_sustain75_rate=min_sustain75_rate,
                    min_avg_best_ret=min_avg_best_ret,
                    min_avg_hold5_ret=min_avg_hold5_ret,
                    min_wilson_lb=min_wilson_lb,
                    min_val_wilson_lb=min_val_wilson_lb,
                    min_tickers=min_tickers,
                    min_val_tickers=min_val_tickers,
                )
                if result is None:
                    continue
                if result.train_success_rate < seed_hit or result.val_success_rate < val_floor:
                    continue
                next_layer.append(result)
                if result.success_rate >= target_hit:
                    all_results.append(result)
        if not next_layer:
            break
        next_layer.sort(key=result_sort_key)
        current_layer = next_layer[: max(1, top_per_depth)]

    return dedupe_results(all_results, top_final=top_final)


def write_dataframe(path: Path, rows: Sequence[SearchResult]) -> None:
    if rows:
        pd.DataFrame([row.as_dict() for row in rows]).to_csv(path, index=False)
        return
    pd.DataFrame(
        columns=[
            "side",
            "conditions",
            "exprs",
            "count",
            "train_count",
            "val_count",
            "ticker_count",
            "val_ticker_count",
            "success_rate",
            "train_success_rate",
            "val_success_rate",
            "wilson_lb",
            "train_wilson_lb",
            "val_wilson_lb",
            "trigger12_rate",
            "trigger1_rate",
            "sustain75_rate",
            "avg_best_ret",
            "avg_hold5_ret",
            "avg_adverse_ret",
        ]
    ).to_csv(path, index=False)


def build_summary(
    *,
    args: argparse.Namespace,
    split_date: date,
    total_rows: int,
    bullish_base_count: int,
    bearish_base_count: int,
    bullish_base_rate: float,
    bearish_base_rate: float,
    bullish_results: Sequence[SearchResult],
    bearish_results: Sequence[SearchResult],
) -> str:
    lines = [
        f"# M1 Sustained Option-Run Signal Mining - {args.end_date}",
        "",
        "- Scope: `public.ca`, `m1`, `regular` session, enriched rows with full indicator coverage.",
        f"- Base profile: `{args.base_profile}`",
        "- Goal: immediate directional move plus sustained underlying follow-through that is plausible for immediate options profit.",
        (
            f"- Outcome contract: trigger `{args.trigger_bp:.2%}` within bars `+1` to `+{args.trigger_window}`, "
            f"sustain `{args.sustain_bp:.2%}` in bars `+{args.sustain_window.replace('_', ' to +')}`, "
            f"hold `{args.hold_bp:.2%}` at bar `+{args.hold_bar}`, "
            f"max adverse in bar `+1` capped at `{args.max_adverse_bp:.2%}`."
        ),
        f"- Validation split: rows dated `{split_date.isoformat()}` and later are holdout validation.",
        f"- Search bar: `overall hit >= {args.target_hit:.0%}`, `n >= {args.min_n}`, `val n >= {args.min_val_n}`.",
        (
            f"- Momentum bar: `trigger12 >= {args.min_trigger12_rate:.0%}`, "
            f"`trigger1 >= {args.min_trigger1_rate:.0%}`, "
            f"`sustain75 >= {args.min_sustain75_rate:.0%}`, "
            f"`avg best >= {args.min_avg_best_ret:.2%}`, "
            f"`hold5 >= {args.min_avg_hold5_ret:.2%}`."
        ),
        "",
        "## Base Universe",
        "",
        f"- Total enriched rows loaded: `{total_rows}`",
        f"- Bullish broad-reversal rows: `{bullish_base_count}` | base hit `{bullish_base_rate:.2%}`",
        f"- Bearish broad-reversal rows: `{bearish_base_count}` | base hit `{bearish_base_rate:.2%}`",
        "",
        "## Top Bullish Families",
        "",
    ]
    if bullish_results:
        for result in bullish_results:
            lines.append(
                f"- `{' AND '.join(result.labels)}` | `n={result.count}` | hit `{result.success_rate:.2%}` | "
                f"train `{result.train_success_rate:.2%}` | val `{result.val_success_rate:.2%}` | "
                f"val wilson `{result.val_wilson_lb:.2%}` | "
                f"trigger12 `{result.trigger12_rate:.2%}` | avg best `{result.avg_best_ret:.2%}` | hold5 `{result.avg_hold5_ret:.2%}`"
            )
    else:
        lines.append("- No bullish families cleared the configured bar.")
    lines.extend(["", "## Top Bearish Families", ""])
    if bearish_results:
        for result in bearish_results:
            lines.append(
                f"- `{' AND '.join(result.labels)}` | `n={result.count}` | hit `{result.success_rate:.2%}` | "
                f"train `{result.train_success_rate:.2%}` | val `{result.val_success_rate:.2%}` | "
                f"val wilson `{result.val_wilson_lb:.2%}` | "
                f"trigger12 `{result.trigger12_rate:.2%}` | avg best `{result.avg_best_ret:.2%}` | hold5 `{result.avg_hold5_ret:.2%}`"
            )
    else:
        lines.append("- No bearish families cleared the configured bar.")
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    env_defaults = load_env_defaults()
    start_date = parse_date(args.start_date)
    end_date = parse_date(args.end_date)
    split_date = end_date - timedelta(days=max(1, int(args.val_days)))
    output_dir = (
        Path(args.output_dir)
        if str(args.output_dir or "").strip()
        else DEFAULT_OUTPUT_ROOT
        / (
            "m1_sustained_option_run_"
            f"{end_date.isoformat()}_trigger{int(round(args.trigger_bp * 10000))}"
            f"_sustain{int(round(args.sustain_bp * 10000))}"
            f"_hold{int(round(args.hold_bp * 10000))}"
        )
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    start_epoch = et_epoch(start_date, 0, 0)
    end_epoch = et_epoch(end_date + timedelta(days=1), 0, 0)

    conn = db_connect(args, env_defaults)
    try:
        history, base_query = load_history(conn, start_epoch=start_epoch, end_epoch=end_epoch)
    finally:
        conn.close()

    history = add_group_features(history)
    history = define_outcomes(
        history,
        trigger_bp=float(args.trigger_bp),
        sustain_bp=float(args.sustain_bp),
        hold_bp=float(args.hold_bp),
        max_adverse_bp=float(args.max_adverse_bp),
        trigger_window=int(args.trigger_window),
        sustain_window=str(args.sustain_window),
        hold_bar=int(args.hold_bar),
    )
    history["is_val"] = history["date_dt"] >= split_date

    bullish_base = build_base_mask(history, "bullish", args.base_profile)
    bearish_base = build_base_mask(history, "bearish", args.base_profile)
    bullish_df = history.loc[bullish_base].copy().reset_index(drop=True)
    bearish_df = history.loc[bearish_base].copy().reset_index(drop=True)

    bullish_results = search_side(
        bullish_df,
        side="bullish",
        specs=build_specs("bullish"),
        min_n=int(args.min_n),
        min_val_n=int(args.min_val_n),
        seed_hit=float(args.seed_hit),
        val_floor=float(args.val_floor),
        target_hit=float(args.target_hit),
        max_k=int(args.max_k),
        top_seeds=int(args.top_seeds),
        top_per_depth=int(args.top_per_depth),
        top_final=int(args.top_final),
        min_trigger12_rate=float(args.min_trigger12_rate),
        min_trigger1_rate=float(args.min_trigger1_rate),
        min_sustain75_rate=float(args.min_sustain75_rate),
        min_avg_best_ret=float(args.min_avg_best_ret),
        min_avg_hold5_ret=float(args.min_avg_hold5_ret),
        min_wilson_lb=float(args.min_wilson_lb),
        min_val_wilson_lb=float(args.min_val_wilson_lb),
        min_tickers=int(args.min_tickers),
        min_val_tickers=int(args.min_val_tickers),
    )
    bearish_results = search_side(
        bearish_df,
        side="bearish",
        specs=build_specs("bearish"),
        min_n=int(args.min_n),
        min_val_n=int(args.min_val_n),
        seed_hit=float(args.seed_hit),
        val_floor=float(args.val_floor),
        target_hit=float(args.target_hit),
        max_k=int(args.max_k),
        top_seeds=int(args.top_seeds),
        top_per_depth=int(args.top_per_depth),
        top_final=int(args.top_final),
        min_trigger12_rate=float(args.min_trigger12_rate),
        min_trigger1_rate=float(args.min_trigger1_rate),
        min_sustain75_rate=float(args.min_sustain75_rate),
        min_avg_best_ret=float(args.min_avg_best_ret),
        min_avg_hold5_ret=float(args.min_avg_hold5_ret),
        min_wilson_lb=float(args.min_wilson_lb),
        min_val_wilson_lb=float(args.min_val_wilson_lb),
        min_tickers=int(args.min_tickers),
        min_val_tickers=int(args.min_val_tickers),
    )

    run_metadata = {
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "split_date": split_date.isoformat(),
        "trigger_bp": float(args.trigger_bp),
        "sustain_bp": float(args.sustain_bp),
        "hold_bp": float(args.hold_bp),
        "max_adverse_bp": float(args.max_adverse_bp),
        "trigger_window": int(args.trigger_window),
        "sustain_window": str(args.sustain_window),
        "hold_bar": int(args.hold_bar),
        "base_profile": str(args.base_profile),
        "min_n": int(args.min_n),
        "min_val_n": int(args.min_val_n),
        "target_hit": float(args.target_hit),
        "seed_hit": float(args.seed_hit),
        "val_floor": float(args.val_floor),
        "max_k": int(args.max_k),
        "top_seeds": int(args.top_seeds),
        "top_per_depth": int(args.top_per_depth),
        "top_final": int(args.top_final),
        "min_trigger12_rate": float(args.min_trigger12_rate),
        "min_trigger1_rate": float(args.min_trigger1_rate),
        "min_sustain75_rate": float(args.min_sustain75_rate),
        "min_avg_best_ret": float(args.min_avg_best_ret),
        "min_avg_hold5_ret": float(args.min_avg_hold5_ret),
        "min_wilson_lb": float(args.min_wilson_lb),
        "min_val_wilson_lb": float(args.min_val_wilson_lb),
        "min_tickers": int(args.min_tickers),
        "min_val_tickers": int(args.min_val_tickers),
        "total_rows": int(len(history)),
        "bullish_base_count": int(len(bullish_df)),
        "bearish_base_count": int(len(bearish_df)),
        "bullish_base_hit": float(bullish_df["bull_success"].mean()) if len(bullish_df) else 0.0,
        "bearish_base_hit": float(bearish_df["bear_success"].mean()) if len(bearish_df) else 0.0,
    }

    summary = build_summary(
        args=args,
        split_date=split_date,
        total_rows=int(len(history)),
        bullish_base_count=int(len(bullish_df)),
        bearish_base_count=int(len(bearish_df)),
        bullish_base_rate=float(bullish_df["bull_success"].mean()) if len(bullish_df) else 0.0,
        bearish_base_rate=float(bearish_df["bear_success"].mean()) if len(bearish_df) else 0.0,
        bullish_results=bullish_results,
        bearish_results=bearish_results,
    )

    (output_dir / "run_metadata.json").write_text(json.dumps(run_metadata, indent=2), encoding="utf-8")
    (output_dir / "base_query.sql").write_text(base_query + "\n", encoding="utf-8")
    (output_dir / "summary.md").write_text(summary, encoding="utf-8")
    write_dataframe(output_dir / "bullish_findings.csv", bullish_results)
    write_dataframe(output_dir / "bearish_findings.csv", bearish_results)

    print(summary)
    print(f"Artifacts written to {output_dir}")


if __name__ == "__main__":
    main()
