#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Sequence

import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier, _tree

from scripts.mine_today_m1_streak_precursors import (
    BOOLEAN_FIELDS,
    NUMERIC_FIELDS,
    _chrono_cuts,
    _fetch_frame,
    _label_pre_run_events,
    _score_subset,
)


FEATURE_FIELDS: List[str] = NUMERIC_FIELDS + BOOLEAN_FIELDS


@dataclass(frozen=True)
class RulePath:
    clauses: tuple[str, ...]
    mask: pd.Series


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Discover pre-burst m1 indicator mixes from decision-tree paths and backtest them."
    )
    parser.add_argument("--start-date", default="2026-04-01")
    parser.add_argument("--end-date", default="")
    parser.add_argument("--today-date", default="")
    parser.add_argument("--run-lengths", default="6,8,10")
    parser.add_argument("--universe", choices=("most_active", "all"), default="most_active")
    parser.add_argument("--top-results", type=int, default=20)
    parser.add_argument("--min-oos", type=int, default=20)
    parser.add_argument("--min-oos-hit", type=float, default=0.85)
    parser.add_argument("--min-validation-hit", type=float, default=0.80)
    parser.add_argument("--min-holdout-hit", type=float, default=0.85)
    parser.add_argument("--min-unique-tickers", type=int, default=8)
    parser.add_argument("--max-top-share", type=float, default=0.35)
    parser.add_argument("--output-dir", default="burst_discovery_output")
    return parser.parse_args()


def _passes_bar(score: Dict[str, Any], args: argparse.Namespace) -> bool:
    return bool(
        score["oos_n"] >= args.min_oos
        and score["oos_hit"] >= args.min_oos_hit
        and score["valid_hit"] >= args.min_validation_hit
        and score["hold_hit"] >= args.min_holdout_hit
        and score["unique_tickers"] >= args.min_unique_tickers
        and score["top_share"] <= args.max_top_share
    )


def _prepare_features(frame: pd.DataFrame) -> pd.DataFrame:
    data = frame.copy()
    for field in NUMERIC_FIELDS:
        if field in data.columns:
            data[field] = pd.to_numeric(data[field], errors="coerce")
            median = float(data[field].median()) if data[field].notna().any() else 0.0
            data[field] = data[field].fillna(median)
    for field in BOOLEAN_FIELDS:
        if field in data.columns:
            data[field] = data[field].fillna(False).astype(int)
    return data


def _extract_rule_paths(
    tree: DecisionTreeClassifier,
    feature_names: Sequence[str],
    frame: pd.DataFrame,
    positive_class_index: int,
) -> List[RulePath]:
    estimator = tree.tree_
    paths: List[RulePath] = []

    def walk(node: int, clauses: List[str], mask: pd.Series) -> None:
        left = estimator.children_left[node]
        right = estimator.children_right[node]
        if left == _tree.TREE_LEAF and right == _tree.TREE_LEAF:
            values = estimator.value[node][0]
            total = float(values.sum())
            positives = float(values[positive_class_index]) if positive_class_index < len(values) else 0.0
            if total <= 0 or positives <= 0:
                return
            paths.append(RulePath(tuple(clauses), mask.copy()))
            return

        feature_index = estimator.feature[node]
        threshold = float(estimator.threshold[node])
        feature = str(feature_names[feature_index])

        if feature in BOOLEAN_FIELDS:
            left_expr = f"{feature} = false"
            right_expr = f"{feature} = true"
            left_mask = mask & frame[feature].fillna(0).astype(int).le(threshold)
            right_mask = mask & frame[feature].fillna(0).astype(int).gt(threshold)
        else:
            left_expr = f"{feature} <= {threshold:.6g}"
            right_expr = f"{feature} > {threshold:.6g}"
            left_mask = mask & frame[feature].le(threshold)
            right_mask = mask & frame[feature].gt(threshold)

        walk(left, clauses + [left_expr], left_mask)
        walk(right, clauses + [right_expr], right_mask)

    walk(0, [], pd.Series(True, index=frame.index))
    return paths


def _rank_rules(
    frame: pd.DataFrame,
    today_date: str,
    success_col: str,
    feature_frame: pd.DataFrame,
    args: argparse.Namespace,
) -> List[Dict[str, Any]]:
    cut1, cut2 = _chrono_cuts(frame)
    train_mask = frame["ts_epoch"] < cut1
    y_train = frame.loc[train_mask, success_col].astype(int)
    x_train = feature_frame.loc[train_mask, FEATURE_FIELDS]
    if int(y_train.sum()) <= 0:
        return []

    today_positive = frame.loc[(frame["date_et"] == today_date) & frame[success_col]].copy()
    results: List[Dict[str, Any]] = []
    seen: set[str] = set()

    model_grid = [
        {"max_depth": 3, "min_samples_leaf": 25},
        {"max_depth": 4, "min_samples_leaf": 20},
        {"max_depth": 5, "min_samples_leaf": 15},
    ]
    for params in model_grid:
        model = DecisionTreeClassifier(
            criterion="entropy",
            class_weight="balanced",
            random_state=42,
            **params,
        )
        model.fit(x_train, y_train)
        paths = _extract_rule_paths(model, FEATURE_FIELDS, feature_frame, positive_class_index=1)
        for path in paths:
            predicate = " AND ".join(path.clauses)
            if not predicate or predicate in seen:
                continue
            seen.add(predicate)
            subset = frame.loc[path.mask].copy()
            if len(subset) < args.min_oos:
                continue
            today_hits = int(path.mask.loc[today_positive.index].sum()) if not today_positive.empty else 0
            score = _score_subset(subset, cut1, cut2, success_col)
            score.update(
                {
                    "predicate": predicate,
                    "today_hits": today_hits,
                    "today_total": int(len(today_positive)),
                    "depth": params["max_depth"],
                    "min_samples_leaf": params["min_samples_leaf"],
                }
            )
            results.append(score)

    results.sort(
        key=lambda item: (
            _passes_bar(item, args),
            item["today_hits"],
            item["oos_hit"],
            item["oos_n"],
            item["wilson"],
        ),
        reverse=True,
    )
    return results


def _serialize_top(rows: Sequence[Dict[str, Any]], top_n: int) -> List[Dict[str, Any]]:
    keys = [
        "predicate",
        "today_hits",
        "today_total",
        "oos_n",
        "oos_hit",
        "valid_n",
        "valid_hit",
        "hold_n",
        "hold_hit",
        "unique_tickers",
        "top_share",
        "wilson",
        "train_n",
        "train_hit",
        "depth",
        "min_samples_leaf",
    ]
    return [{key: row.get(key) for key in keys} for row in rows[:top_n]]


def _parse_run_lengths(raw: str) -> List[int]:
    values = []
    for part in str(raw or "").split(","):
        part = part.strip()
        if not part:
            continue
        values.append(int(part))
    return values or [6]


async def main_async() -> None:
    args = _parse_args()
    frame = await _fetch_frame(args.start_date, args.end_date, args.universe)
    if frame.empty:
        raise ValueError("query returned no m1 ca rows")
    today_date = args.today_date or str(frame["date_et"].max())

    output: Dict[str, Any] = {
        "today_date": today_date,
        "history_start": str(frame["date_et"].min()),
        "history_end": str(frame["date_et"].max()),
        "universe": args.universe,
        "row_count": int(len(frame)),
        "run_lengths": {},
    }

    for run_length in _parse_run_lengths(args.run_lengths):
        labeled = _label_pre_run_events(frame, run_length)
        feature_frame = _prepare_features(labeled[FEATURE_FIELDS].copy())
        run_payload: Dict[str, Any] = {}
        for side, success_col in (("bull", "bull_run6"), ("bear", "bear_run6")):
            ranked = _rank_rules(labeled, today_date, success_col, feature_frame, args)
            survivors = [row for row in ranked if _passes_bar(row, args)]
            run_payload[side] = {
                "today_hits": int(labeled.loc[(labeled["date_et"] == today_date) & labeled[success_col]].shape[0]),
                "survivors": _serialize_top(survivors, args.top_results),
                "top_ranked": _serialize_top(ranked, args.top_results),
            }
        output["run_lengths"][str(run_length)] = run_payload

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"m1_streak_tree_rules_{today_date}.json"
    out_path.write_text(json.dumps(output, indent=2), encoding="utf-8")

    print(f"WROTE={out_path}")
    for run_length, run_payload in output["run_lengths"].items():
        print(
            f"RUN_LENGTH={run_length} "
            f"BULL_SURVIVORS={len(run_payload['bull']['survivors'])} "
            f"BEAR_SURVIVORS={len(run_payload['bear']['survivors'])}"
        )


def main() -> None:
    import asyncio

    asyncio.run(main_async())


if __name__ == "__main__":
    main()
