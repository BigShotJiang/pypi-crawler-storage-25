#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import gzip
import json
import math
import os
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from itertools import combinations
from pathlib import Path
from typing import Callable, Dict, Iterable, Iterator, List, Sequence, Tuple

import numpy as np
import pandas as pd
import psycopg2
from psycopg2.extensions import connection as PgConnection
from zoneinfo import ZoneInfo


MARKET_TZ = ZoneInfo("America/New_York")
ROOT = Path(__file__).resolve().parents[1]
OUTPUT_ROOT = ROOT / "runs" / "ca_historical_research"
DEFAULT_END_DATE = datetime.now(MARKET_TZ).date().isoformat()


@dataclass(frozen=True)
class ConditionSpec:
    label: str
    clause: str
    fn: Callable[[pd.DataFrame], pd.Series]


@dataclass
class ComboStats:
    n: int = 0
    hits: int = 0
    recent_n: int = 0
    recent_hits: int = 0
    hit50: int = 0
    hit100: int = 0
    hit150: int = 0
    best_ret_sum: float = 0.0
    best_ret_count: int = 0

    def update(
        self,
        *,
        mask: np.ndarray,
        labels: np.ndarray,
        recent_mask: np.ndarray,
        best_rets: np.ndarray,
    ) -> None:
        matched = int(mask.sum())
        if matched <= 0:
            return
        self.n += matched
        self.hits += int((mask & labels).sum())
        recent_combo = mask & recent_mask
        self.recent_n += int(recent_combo.sum())
        self.recent_hits += int((recent_combo & labels).sum())

        finite_best = mask & np.isfinite(best_rets)
        if int(finite_best.sum()) <= 0:
            return
        values = best_rets[finite_best]
        self.best_ret_sum += float(np.nansum(values))
        self.best_ret_count += int(len(values))
        self.hit50 += int(np.sum(values >= 0.005))
        self.hit100 += int(np.sum(values >= 0.01))
        self.hit150 += int(np.sum(values >= 0.015))


def _load_env_defaults() -> Dict[str, str]:
    env_path = ROOT / "stock_market_site" / "app" / ".env"
    values: Dict[str, str] = {}
    if not env_path.exists():
        return values
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


ENV_DEFAULTS = _load_env_defaults()


def _env_default(key: str, fallback: str) -> str:
    repo_value = str(ENV_DEFAULTS.get(key) or "").strip()
    if repo_value:
        return repo_value
    env_value = str(os.environ.get(key) or "").strip()
    if key == "DB_NAME" and env_value.lower() == "database":
        return fallback
    return env_value or fallback


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Build a market-wide exact-burst signal frame from ca and scan "
            "condition combinations for 6+ same-color bursts starting within "
            "the next N bars."
        )
    )
    parser.add_argument("--host", default=_env_default("DB_HOST", "localhost"))
    parser.add_argument("--port", type=int, default=int(_env_default("DB_PORT", "5432")))
    parser.add_argument("--user", default=_env_default("DB_USER", "chuck"))
    parser.add_argument("--password", default=_env_default("DB_PASSWORD", "fud"))
    parser.add_argument("--database", default=_env_default("DB_NAME", "fudstop3"))
    parser.add_argument("--timespans", default="m1")
    parser.add_argument("--sides", default="bull,bear")
    parser.add_argument("--start-date", default="", help="YYYY-MM-DD or blank for full available history.")
    parser.add_argument("--end-date", default=DEFAULT_END_DATE)
    parser.add_argument("--min-run-length", type=int, default=6)
    parser.add_argument("--min-trigger-bars", type=int, default=1)
    parser.add_argument("--trigger-bars", type=int, default=6)
    parser.add_argument("--best-window", type=int, default=15)
    parser.add_argument("--max-k", type=int, default=4)
    parser.add_argument("--base-conditions", default="")
    parser.add_argument("--max-extra-k", type=int, default=2)
    parser.add_argument("--beam-width", type=int, default=28)
    parser.add_argument("--candidate-pool", type=int, default=42)
    parser.add_argument("--min-n", type=int, default=20)
    parser.add_argument("--min-hit-rate", type=float, default=0.85)
    parser.add_argument("--recent-days", type=int, default=21)
    parser.add_argument("--chunksize", type=int, default=250000)
    parser.add_argument("--cache-only", action="store_true")
    parser.add_argument("--reuse-cache", action="store_true")
    parser.add_argument("--output-dir", default="")
    return parser.parse_args()


def _parse_timespans(raw: str) -> List[str]:
    values = [value.strip().lower() for value in str(raw or "").split(",") if value.strip()]
    return values or ["m1"]


def _parse_sides(raw: str) -> List[str]:
    values = [value.strip().lower() for value in str(raw or "").split(",") if value.strip()]
    ordered = [side for side in ("bull", "bear") if side in values]
    return ordered or ["bull", "bear"]


def _parse_condition_labels(raw: str) -> List[str]:
    return [value.strip() for value in str(raw or "").split(",") if value.strip()]


def _sql_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _slugify(value: str) -> str:
    cleaned = "".join(ch.lower() if ch.isalnum() else "_" for ch in str(value or "").strip())
    while "__" in cleaned:
        cleaned = cleaned.replace("__", "_")
    return cleaned.strip("_") or "scan"


def _db_connect(args: argparse.Namespace) -> PgConnection:
    return psycopg2.connect(
        host=args.host,
        port=int(args.port),
        user=args.user,
        password=args.password,
        dbname=args.database,
        connect_timeout=15,
    )


def _date_to_epoch(day: date) -> int:
    return int(datetime.combine(day, time.min, tzinfo=MARKET_TZ).timestamp())


def _resolve_bounds(conn: PgConnection, *, timespans: Sequence[str], start_date: str, end_date: str) -> tuple[int, int, str, str]:
    end_day = date.fromisoformat(end_date)
    end_epoch = _date_to_epoch(end_day + timedelta(days=1))
    if str(start_date or "").strip():
        start_day = date.fromisoformat(start_date)
        return _date_to_epoch(start_day), end_epoch, start_day.isoformat(), end_day.isoformat()

    quoted_timespans = ", ".join(_sql_quote(value) for value in timespans)
    query = f"""
SELECT
    MIN(ts::bigint) AS min_ts,
    MAX(ts::bigint) AS max_ts
FROM ca
WHERE LOWER(COALESCE(timespan, '')) IN ({quoted_timespans})
  AND session = 'regular'
  AND bb_width IS NOT NULL
""".strip()
    cur = conn.cursor()
    cur.execute(query)
    row = cur.fetchone()
    cur.close()
    if not row or row[0] is None:
        raise RuntimeError("No ca rows found for the requested timespans.")
    min_ts = int(row[0])
    start_day = datetime.fromtimestamp(min_ts, tz=MARKET_TZ).date()
    return _date_to_epoch(start_day), end_epoch, start_day.isoformat(), end_day.isoformat()


def _build_signal_frame_query(
    *,
    timespans: Sequence[str],
    start_epoch: int,
    end_epoch: int,
    min_run_length: int,
    min_trigger_bars: int,
    trigger_bars: int,
    best_window: int,
) -> str:
    quoted_timespans = ", ".join(_sql_quote(value) for value in timespans)
    trigger_start = int(min_trigger_bars)
    trigger_end = int(trigger_bars)
    if trigger_start < 1:
        raise ValueError("min_trigger_bars must be at least 1.")
    if trigger_end < trigger_start:
        raise ValueError("trigger_bars must be greater than or equal to min_trigger_bars.")
    forward_bars = int(trigger_bars) + int(min_run_length) - 1
    return f"""
WITH base AS (
    SELECT
        UPPER(BTRIM(ticker)) AS ticker,
        LOWER(COALESCE(timespan, '')) AS timespan,
        ts::bigint AS ts_epoch,
        lag(ts::bigint, 1) OVER w AS pre_ts_epoch_lag1,
        o AS pre_o,
        c AS pre_c,
        h AS pre_h,
        l AS pre_l,
        v AS pre_v,
        change_pct AS pre_change_pct,
        hl_range_pct AS pre_hl_range_pct,
        body AS pre_body_abs,
        body_pct AS pre_body_pct,
        wick_ratio AS pre_wick_ratio,
        oc_pct AS pre_oc_pct,
        true_range_pct AS pre_true_range_pct,
        gap_pct AS pre_gap_pct,
        is_gap AS pre_is_gap,
        gap_dir_code AS pre_gap_dir_code,
        candle_green AS pre_candle_green,
        candle_red AS pre_candle_red,
        rsi AS pre_rsi,
        td_buy_count AS pre_td_buy_count,
        td_sell_count AS pre_td_sell_count,
        macd_hist AS pre_macd_hist,
        lag(macd_hist, 1) OVER w AS pre_macd_hist_lag1,
        lag(macd_hist, 2) OVER w AS pre_macd_hist_lag2,
        lag(macd_hist, 3) OVER w AS pre_macd_hist_lag3,
        bb_width AS pre_bb_width,
        bb_close_outside_lower AS pre_bb_close_outside_lower,
        bb_close_outside_upper AS pre_bb_close_outside_upper,
        candle_completely_below_lower AS pre_candle_completely_below_lower,
        candle_completely_above_upper AS pre_candle_completely_above_upper,
        rvol AS pre_rvol,
        atr_pct AS pre_atr_pct,
        chop AS pre_chop,
        vwap_dist_pct AS pre_vwap_dist_pct,
        close_vwap_diff_pct AS pre_close_vwap_diff_pct,
        vwap_cross_up AS pre_vwap_cross_up,
        vwap_cross_dn AS pre_vwap_cross_dn,
        stoch_rsi_k AS pre_stoch_rsi_k,
        stoch_rsi_d AS pre_stoch_rsi_d,
        mfi AS pre_mfi,
        cmo AS pre_cmo,
        roc AS pre_roc,
        trix AS pre_trix,
        tsi AS pre_tsi,
        tsi_signal AS pre_tsi_signal,
        tsi_cross_up AS pre_tsi_cross_up,
        tsi_cross_dn AS pre_tsi_cross_dn,
        ultimate_osc AS pre_ultimate_osc,
        keltner_width AS pre_keltner_width,
        sdc_width AS pre_sdc_width,
        trend_regime AS pre_trend_regime,
        squeeze_on AS pre_squeeze_on,
        volume_confirm AS pre_volume_confirm,
        squeeze_off AS pre_squeeze_off,
        macd_imminent_bull AS pre_macd_imminent_bull,
        macd_imminent_bear AS pre_macd_imminent_bear,
        adx AS pre_adx,
        adx_strong AS pre_adx_strong,
        di_bull AS pre_di_bull,
        di_bear AS pre_di_bear,
        ema_stack_bull AS pre_ema_stack_bull,
        ema_stack_bear AS pre_ema_stack_bear,
        momentum_confirm_bull AS pre_momentum_confirm_bull,
        momentum_confirm_bear AS pre_momentum_confirm_bear,
        macd_cross_up AS pre_macd_cross_up,
        macd_cross_dn AS pre_macd_cross_dn,
        avg(v) OVER w_prev3 AS pre_avg_v_prev3,
        avg(body_pct) OVER w_prev3 AS pre_avg_body_prev3,
        avg(hl_range_pct) OVER w_prev3 AS pre_avg_range_prev3,
        sum(CASE WHEN candle_red THEN 1 ELSE 0 END) OVER w_prev5 AS pre_prev5_red_count,
        sum(CASE WHEN candle_green THEN 1 ELSE 0 END) OVER w_prev5 AS pre_prev5_green_count,
        lag(c, 1) OVER w AS pre_c_prev1,
        CASE
            WHEN to_char(to_timestamp(ts::bigint) AT TIME ZONE 'America/New_York', 'HH24:MI') >= '09:30'
             AND to_char(to_timestamp(ts::bigint) AT TIME ZONE 'America/New_York', 'HH24:MI') < '09:45'
            THEN TRUE ELSE FALSE
        END AS tod_opening_15,
        CASE
            WHEN to_char(to_timestamp(ts::bigint) AT TIME ZONE 'America/New_York', 'HH24:MI') >= '09:30'
             AND to_char(to_timestamp(ts::bigint) AT TIME ZONE 'America/New_York', 'HH24:MI') < '10:30'
            THEN TRUE ELSE FALSE
        END AS tod_first_hour,
        CASE
            WHEN to_char(to_timestamp(ts::bigint) AT TIME ZONE 'America/New_York', 'HH24:MI') >= '11:30'
             AND to_char(to_timestamp(ts::bigint) AT TIME ZONE 'America/New_York', 'HH24:MI') < '13:30'
            THEN TRUE ELSE FALSE
        END AS tod_lunch,
        CASE
            WHEN to_char(to_timestamp(ts::bigint) AT TIME ZONE 'America/New_York', 'HH24:MI') >= '15:00'
             AND to_char(to_timestamp(ts::bigint) AT TIME ZONE 'America/New_York', 'HH24:MI') <= '15:59'
            THEN TRUE ELSE FALSE
        END AS tod_power_hour
    FROM ca
    WHERE LOWER(COALESCE(timespan, '')) IN ({quoted_timespans})
      AND session = 'regular'
      AND bb_width IS NOT NULL
      AND ts::bigint >= {int(start_epoch)}
      AND ts::bigint < {int(end_epoch)}
    WINDOW
      w AS (PARTITION BY UPPER(BTRIM(ticker)), LOWER(COALESCE(timespan, '')) ORDER BY ts::bigint),
      w_prev3 AS (PARTITION BY UPPER(BTRIM(ticker)), LOWER(COALESCE(timespan, '')) ORDER BY ts::bigint ROWS BETWEEN 3 PRECEDING AND 1 PRECEDING),
      w_prev5 AS (PARTITION BY UPPER(BTRIM(ticker)), LOWER(COALESCE(timespan, '')) ORDER BY ts::bigint ROWS BETWEEN 4 PRECEDING AND CURRENT ROW)
),
dirs AS (
    SELECT
        *,
        CASE
            WHEN pre_candle_green THEN 1
            WHEN pre_candle_red THEN -1
            ELSE 0
        END AS color,
        CASE
            WHEN pre_c_prev1 IS NULL OR pre_c IS NULL THEN 0
            WHEN pre_c > pre_c_prev1 THEN 1
            WHEN pre_c < pre_c_prev1 THEN -1
            ELSE 0
        END AS close_dir
    FROM base
),
group_flags AS (
    SELECT
        *,
        lag(color, 1, 0) OVER w AS prev_color,
        lag(close_dir, 1, 0) OVER w AS prev_close_dir,
        CASE
            WHEN pre_ts_epoch_lag1 IS NULL THEN 0
            ELSE ts_epoch - pre_ts_epoch_lag1
        END AS prev_gap_seconds
    FROM dirs
    WINDOW w AS (PARTITION BY ticker, timespan ORDER BY ts_epoch)
),
run_groups AS (
    SELECT
        *,
        sum(
            CASE
                WHEN color = 0 OR prev_color <> color OR prev_gap_seconds > 60 THEN 1
                ELSE 0
            END
        ) OVER w AS color_group_id,
        sum(
            CASE
                WHEN close_dir = 0 OR prev_close_dir <> close_dir OR prev_gap_seconds > 60 THEN 1
                ELSE 0
            END
        ) OVER w AS close_group_id
    FROM group_flags
    WINDOW w AS (PARTITION BY ticker, timespan ORDER BY ts_epoch)
),
streaks AS (
    SELECT
        *,
        count(*) OVER (PARTITION BY ticker, timespan, color_group_id) AS color_run_len,
        row_number() OVER (PARTITION BY ticker, timespan, color_group_id ORDER BY ts_epoch) AS color_run_pos,
        CASE
            WHEN color = 1 THEN row_number() OVER (PARTITION BY ticker, timespan, color_group_id ORDER BY ts_epoch)
            ELSE 0
        END AS pre_green_streak,
        CASE
            WHEN color = -1 THEN row_number() OVER (PARTITION BY ticker, timespan, color_group_id ORDER BY ts_epoch)
            ELSE 0
        END AS pre_red_streak,
        CASE
            WHEN close_dir = 1 THEN row_number() OVER (PARTITION BY ticker, timespan, close_group_id ORDER BY ts_epoch)
            ELSE 0
        END AS pre_up_close_streak,
        CASE
            WHEN close_dir = -1 THEN row_number() OVER (PARTITION BY ticker, timespan, close_group_id ORDER BY ts_epoch)
            ELSE 0
        END AS pre_down_close_streak,
        CASE
            WHEN pre_h IS NOT NULL AND pre_l IS NOT NULL AND pre_c IS NOT NULL AND pre_h > pre_l
            THEN LEAST(1.0, GREATEST(0.0, (pre_c - pre_l) / NULLIF(pre_h - pre_l, 0)))
            ELSE 0.5
        END AS pre_close_pos_in_range,
        CASE
            WHEN pre_avg_v_prev3 IS NOT NULL AND pre_avg_v_prev3 > 0 AND pre_v IS NOT NULL
            THEN pre_v / pre_avg_v_prev3
            ELSE NULL
        END AS pre_vol_ratio_prev3
    FROM run_groups
),
signal_frame AS (
    SELECT
        *,
        CASE
            WHEN color = 1 AND color_run_pos = 1 AND color_run_len >= {int(min_run_length)} THEN 1
            ELSE 0
        END AS bull_run{int(min_run_length)}_start,
        CASE
            WHEN color = -1 AND color_run_pos = 1 AND color_run_len >= {int(min_run_length)} THEN 1
            ELSE 0
        END AS bear_run{int(min_run_length)}_start,
        max(CASE WHEN color = 1 AND color_run_pos = 1 AND color_run_len >= {int(min_run_length)} THEN 1 ELSE 0 END)
            OVER (PARTITION BY ticker, timespan ORDER BY ts_epoch ROWS BETWEEN {trigger_start} FOLLOWING AND {trigger_end} FOLLOWING) AS bull_exact{int(min_run_length)},
        max(CASE WHEN color = -1 AND color_run_pos = 1 AND color_run_len >= {int(min_run_length)} THEN 1 ELSE 0 END)
            OVER (PARTITION BY ticker, timespan ORDER BY ts_epoch ROWS BETWEEN {trigger_start} FOLLOWING AND {trigger_end} FOLLOWING) AS bear_exact{int(min_run_length)},
        max(pre_h) OVER (PARTITION BY ticker, timespan ORDER BY ts_epoch ROWS BETWEEN 1 FOLLOWING AND {int(best_window)} FOLLOWING) AS future_max_h,
        min(pre_l) OVER (PARTITION BY ticker, timespan ORDER BY ts_epoch ROWS BETWEEN 1 FOLLOWING AND {int(best_window)} FOLLOWING) AS future_min_l,
        count(*) OVER (PARTITION BY ticker, timespan ORDER BY ts_epoch ROWS BETWEEN 1 FOLLOWING AND {int(forward_bars)} FOLLOWING) AS future_count_exact,
        count(*) OVER (PARTITION BY ticker, timespan ORDER BY ts_epoch ROWS BETWEEN 1 FOLLOWING AND {int(best_window)} FOLLOWING) AS future_count_best
    FROM streaks
)
SELECT
    ticker,
    timespan,
    ts_epoch,
    pre_o,
    pre_c,
    pre_h,
    pre_l,
    pre_v,
    pre_change_pct,
    pre_hl_range_pct,
    pre_body_abs,
    pre_body_pct,
    pre_wick_ratio,
    pre_oc_pct,
    pre_true_range_pct,
    pre_gap_pct,
    pre_is_gap,
    pre_gap_dir_code,
    pre_candle_green,
    pre_candle_red,
    pre_rsi,
    pre_td_buy_count,
    pre_td_sell_count,
    pre_macd_hist,
    pre_macd_hist_lag1,
    pre_macd_hist_lag2,
    pre_macd_hist_lag3,
    pre_bb_width,
    pre_bb_close_outside_lower,
    pre_bb_close_outside_upper,
    pre_candle_completely_below_lower,
    pre_candle_completely_above_upper,
    pre_rvol,
    pre_atr_pct,
    pre_chop,
    pre_vwap_dist_pct,
    pre_close_vwap_diff_pct,
    pre_vwap_cross_up,
    pre_vwap_cross_dn,
    pre_stoch_rsi_k,
    pre_stoch_rsi_d,
    pre_mfi,
    pre_cmo,
    pre_roc,
    pre_trix,
    pre_tsi,
    pre_tsi_signal,
    pre_tsi_cross_up,
    pre_tsi_cross_dn,
    pre_ultimate_osc,
    pre_keltner_width,
    pre_sdc_width,
    pre_trend_regime,
    pre_squeeze_on,
    pre_volume_confirm,
    pre_squeeze_off,
    pre_macd_imminent_bull,
    pre_macd_imminent_bear,
    pre_adx,
    pre_adx_strong,
    pre_di_bull,
    pre_di_bear,
    pre_ema_stack_bull,
    pre_ema_stack_bear,
    pre_momentum_confirm_bull,
    pre_momentum_confirm_bear,
    pre_macd_cross_up,
    pre_macd_cross_dn,
    pre_green_streak,
    pre_red_streak,
    pre_up_close_streak,
    pre_down_close_streak,
    pre_prev5_red_count,
    pre_prev5_green_count,
    pre_close_pos_in_range,
    pre_vol_ratio_prev3,
    pre_avg_body_prev3,
    pre_avg_range_prev3,
    tod_opening_15,
    tod_first_hour,
    tod_lunch,
    tod_power_hour,
    bull_run{int(min_run_length)}_start AS bull_run_start,
    bear_run{int(min_run_length)}_start AS bear_run_start,
    COALESCE(bull_exact{int(min_run_length)}, 0) AS bull_exact,
    COALESCE(bear_exact{int(min_run_length)}, 0) AS bear_exact,
    CASE
        WHEN pre_c IS NOT NULL AND pre_c > 0 AND future_max_h IS NOT NULL
        THEN (future_max_h / pre_c) - 1.0
        ELSE NULL
    END AS bull_best_ret,
    CASE
        WHEN pre_c IS NOT NULL AND pre_c > 0 AND future_min_l IS NOT NULL AND future_min_l > 0
        THEN (pre_c / future_min_l) - 1.0
        ELSE NULL
    END AS bear_best_ret
FROM signal_frame
WHERE future_count_exact = {int(forward_bars)}
ORDER BY timespan, ticker, ts_epoch
""".strip()


def _export_signal_frame(conn: PgConnection, *, query: str, cache_path: Path, chunksize: int) -> int:
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    total_rows = 0
    with gzip.open(cache_path, "wt", encoding="utf-8", newline="") as handle:
        cur = conn.cursor(name="ca_exact_burst_signal_frame")
        cur.itersize = int(chunksize)
        cur.execute(query)
        writer = csv.writer(handle)
        wrote_header = False
        while True:
            rows = cur.fetchmany(int(chunksize))
            if not rows:
                break
            if not wrote_header:
                headers = [desc[0] for desc in (cur.description or ())]
                if not headers:
                    raise RuntimeError("Signal-frame query returned rows but no cursor description.")
                writer.writerow(headers)
                wrote_header = True
            writer.writerows(rows)
            total_rows += len(rows)
        cur.close()
        if not wrote_header:
            headers = [desc[0] for desc in (cur.description or ())]
            if headers:
                writer.writerow(headers)
    return total_rows


def _derive_macd_state_from_rows(df: pd.DataFrame) -> pd.Series:
    lag3 = pd.to_numeric(df["pre_macd_hist_lag3"], errors="coerce").to_numpy(dtype=float)
    lag2 = pd.to_numeric(df["pre_macd_hist_lag2"], errors="coerce").to_numpy(dtype=float)
    lag1 = pd.to_numeric(df["pre_macd_hist_lag1"], errors="coerce").to_numpy(dtype=float)
    cur = pd.to_numeric(df["pre_macd_hist"], errors="coerce").to_numpy(dtype=float)
    out = np.zeros(len(df), dtype=np.int8)
    valid = np.isfinite(lag3) & np.isfinite(lag2) & np.isfinite(lag1) & np.isfinite(cur)
    if not np.any(valid):
        return pd.Series(out, index=df.index)
    diffs1 = lag2 - lag3
    diffs2 = lag1 - lag2
    diffs3 = cur - lag1
    avg_abs = (np.abs(diffs1) + np.abs(diffs2) + np.abs(diffs3)) / 3.0 + 1e-9
    cur_delta = diffs3

    zeroish = valid & (np.abs(cur) < (avg_abs * 0.5)) & (np.abs(cur_delta) < (avg_abs * 0.2))
    out[zeroish & (cur < 0)] = 7
    out[zeroish & (cur >= 0)] = 8

    mask = valid & ~zeroish & (cur > 0) & (cur_delta > (avg_abs * 0.8))
    out[mask] = 1
    mask = valid & ~zeroish & (cur < 0) & (cur_delta < -(avg_abs * 0.8))
    out[mask] = 2
    mask = valid & ~zeroish & (cur > 0) & (cur_delta < -(avg_abs * 0.8))
    out[mask] = 3
    mask = valid & ~zeroish & (cur < 0) & (cur_delta > (avg_abs * 0.8))
    out[mask] = 4
    mask = valid & ~zeroish & (cur > 0) & (out == 0)
    out[mask] = 5
    mask = valid & ~zeroish & (cur < 0) & (out == 0)
    out[mask] = 6
    return pd.Series(out, index=df.index)


def _normalize_chunk(df: pd.DataFrame) -> pd.DataFrame:
    bool_cols = [
        "pre_is_gap",
        "pre_candle_green",
        "pre_candle_red",
        "pre_bb_close_outside_lower",
        "pre_bb_close_outside_upper",
        "pre_candle_completely_below_lower",
        "pre_candle_completely_above_upper",
        "pre_vwap_cross_up",
        "pre_vwap_cross_dn",
        "pre_tsi_cross_up",
        "pre_tsi_cross_dn",
        "pre_trend_regime",
        "pre_squeeze_on",
        "pre_volume_confirm",
        "pre_squeeze_off",
        "pre_macd_imminent_bull",
        "pre_macd_imminent_bear",
        "pre_adx_strong",
        "pre_di_bull",
        "pre_di_bear",
        "pre_ema_stack_bull",
        "pre_ema_stack_bear",
        "pre_momentum_confirm_bull",
        "pre_momentum_confirm_bear",
        "pre_macd_cross_up",
        "pre_macd_cross_dn",
        "tod_opening_15",
        "tod_first_hour",
        "tod_lunch",
        "tod_power_hour",
        "bull_run_start",
        "bear_run_start",
        "bull_exact",
        "bear_exact",
    ]
    num_cols = [
        "ts_epoch",
        "pre_o",
        "pre_c",
        "pre_h",
        "pre_l",
        "pre_v",
        "pre_change_pct",
        "pre_hl_range_pct",
        "pre_body_abs",
        "pre_body_pct",
        "pre_wick_ratio",
        "pre_oc_pct",
        "pre_true_range_pct",
        "pre_gap_pct",
        "pre_gap_dir_code",
        "pre_rsi",
        "pre_td_buy_count",
        "pre_td_sell_count",
        "pre_macd_hist",
        "pre_macd_hist_lag1",
        "pre_macd_hist_lag2",
        "pre_macd_hist_lag3",
        "pre_bb_width",
        "pre_rvol",
        "pre_atr_pct",
        "pre_chop",
        "pre_vwap_dist_pct",
        "pre_close_vwap_diff_pct",
        "pre_stoch_rsi_k",
        "pre_stoch_rsi_d",
        "pre_mfi",
        "pre_cmo",
        "pre_roc",
        "pre_trix",
        "pre_tsi",
        "pre_tsi_signal",
        "pre_ultimate_osc",
        "pre_keltner_width",
        "pre_sdc_width",
        "pre_adx",
        "pre_green_streak",
        "pre_red_streak",
        "pre_up_close_streak",
        "pre_down_close_streak",
        "pre_prev5_red_count",
        "pre_prev5_green_count",
        "pre_close_pos_in_range",
        "pre_vol_ratio_prev3",
        "pre_avg_body_prev3",
        "pre_avg_range_prev3",
        "bull_best_ret",
        "bear_best_ret",
    ]
    for col in num_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    for col in bool_cols:
        if col in df.columns:
            df[col] = (
                df[col]
                .astype(str)
                .str.strip()
                .str.lower()
                .isin({"t", "true", "1", "y", "yes"})
            )
    if "pre_tsi" in df.columns and "pre_tsi_signal" in df.columns:
        df["pre_tsi_spread"] = (
            pd.to_numeric(df["pre_tsi"], errors="coerce")
            - pd.to_numeric(df["pre_tsi_signal"], errors="coerce")
        )
    df["pre_macd_state_code"] = _derive_macd_state_from_rows(df)
    return df


def _bool_condition(label: str, column: str) -> ConditionSpec:
    return ConditionSpec(label=label, clause=column, fn=lambda df, col=column: df[col].fillna(False).astype(bool))


def _ge_condition(label: str, column: str, threshold: float) -> ConditionSpec:
    return ConditionSpec(
        label=label,
        clause=f"{column} >= {threshold}",
        fn=lambda df, col=column, thr=threshold: pd.to_numeric(df[col], errors="coerce") >= thr,
    )


def _le_condition(label: str, column: str, threshold: float) -> ConditionSpec:
    return ConditionSpec(
        label=label,
        clause=f"{column} <= {threshold}",
        fn=lambda df, col=column, thr=threshold: pd.to_numeric(df[col], errors="coerce") <= thr,
    )


def _eq_condition(label: str, column: str, value: int) -> ConditionSpec:
    return ConditionSpec(
        label=label,
        clause=f"{column} = {value}",
        fn=lambda df, col=column, val=value: pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int) == val,
    )


def _build_condition_specs() -> List[ConditionSpec]:
    specs = [
        _bool_condition("tod_opening_15", "tod_opening_15"),
        _bool_condition("tod_first_hour", "tod_first_hour"),
        _bool_condition("tod_lunch", "tod_lunch"),
        _bool_condition("tod_power_hour", "tod_power_hour"),
        _bool_condition("pre_candle_green", "pre_candle_green"),
        _bool_condition("pre_candle_red", "pre_candle_red"),
        _bool_condition("pre_is_gap", "pre_is_gap"),
        _bool_condition("pre_bb_close_outside_lower", "pre_bb_close_outside_lower"),
        _bool_condition("pre_bb_close_outside_upper", "pre_bb_close_outside_upper"),
        _bool_condition("pre_candle_completely_below_lower", "pre_candle_completely_below_lower"),
        _bool_condition("pre_candle_completely_above_upper", "pre_candle_completely_above_upper"),
        _bool_condition("pre_vwap_cross_up", "pre_vwap_cross_up"),
        _bool_condition("pre_vwap_cross_dn", "pre_vwap_cross_dn"),
        _bool_condition("pre_tsi_cross_up", "pre_tsi_cross_up"),
        _bool_condition("pre_tsi_cross_dn", "pre_tsi_cross_dn"),
        _bool_condition("pre_volume_confirm", "pre_volume_confirm"),
        _bool_condition("pre_trend_regime", "pre_trend_regime"),
        _bool_condition("pre_squeeze_on", "pre_squeeze_on"),
        _bool_condition("pre_squeeze_off", "pre_squeeze_off"),
        _bool_condition("pre_macd_imminent_bull", "pre_macd_imminent_bull"),
        _bool_condition("pre_macd_imminent_bear", "pre_macd_imminent_bear"),
        _bool_condition("pre_adx_strong", "pre_adx_strong"),
        _bool_condition("pre_di_bull", "pre_di_bull"),
        _bool_condition("pre_di_bear", "pre_di_bear"),
        _bool_condition("pre_ema_stack_bull", "pre_ema_stack_bull"),
        _bool_condition("pre_ema_stack_bear", "pre_ema_stack_bear"),
        _bool_condition("pre_momentum_confirm_bull", "pre_momentum_confirm_bull"),
        _bool_condition("pre_momentum_confirm_bear", "pre_momentum_confirm_bear"),
        _bool_condition("pre_macd_cross_up", "pre_macd_cross_up"),
        _bool_condition("pre_macd_cross_dn", "pre_macd_cross_dn"),
        _ge_condition("pre_body_pct>=0.02", "pre_body_pct", 0.02),
        _ge_condition("pre_body_pct>=0.04", "pre_body_pct", 0.04),
        _ge_condition("pre_body_pct>=0.06", "pre_body_pct", 0.06),
        _ge_condition("pre_hl_range_pct>=0.15", "pre_hl_range_pct", 0.15),
        _ge_condition("pre_hl_range_pct>=0.20", "pre_hl_range_pct", 0.20),
        _ge_condition("pre_true_range_pct>=0.20", "pre_true_range_pct", 0.20),
        _ge_condition("pre_bb_width>=0.03", "pre_bb_width", 0.03),
        _ge_condition("pre_bb_width>=0.05", "pre_bb_width", 0.05),
        _ge_condition("pre_bb_width>=0.07", "pre_bb_width", 0.07),
        _le_condition("pre_bb_width<=0.015", "pre_bb_width", 0.015),
        _le_condition("pre_bb_width<=0.01", "pre_bb_width", 0.01),
        _ge_condition("pre_rvol>=1.2", "pre_rvol", 1.2),
        _ge_condition("pre_rvol>=1.5", "pre_rvol", 1.5),
        _ge_condition("pre_rvol>=2.0", "pre_rvol", 2.0),
        _le_condition("pre_rvol<=1.0", "pre_rvol", 1.0),
        _ge_condition("pre_vol_ratio_prev3>=1.2", "pre_vol_ratio_prev3", 1.2),
        _ge_condition("pre_vol_ratio_prev3>=1.5", "pre_vol_ratio_prev3", 1.5),
        _ge_condition("pre_atr_pct>=0.003", "pre_atr_pct", 0.003),
        _ge_condition("pre_atr_pct>=0.005", "pre_atr_pct", 0.005),
        _ge_condition("pre_atr_pct>=0.006", "pre_atr_pct", 0.006),
        _le_condition("pre_atr_pct<=0.0025", "pre_atr_pct", 0.0025),
        _le_condition("pre_atr_pct<=0.002", "pre_atr_pct", 0.0020),
        _le_condition("pre_keltner_width<=0.002", "pre_keltner_width", 0.002),
        _le_condition("pre_keltner_width<=0.004", "pre_keltner_width", 0.004),
        _ge_condition("pre_keltner_width>=0.01", "pre_keltner_width", 0.01),
        _ge_condition("pre_keltner_width>=0.015", "pre_keltner_width", 0.015),
        _le_condition("pre_sdc_width<=0.002", "pre_sdc_width", 0.002),
        _le_condition("pre_sdc_width<=0.004", "pre_sdc_width", 0.004),
        _ge_condition("pre_sdc_width>=0.008", "pre_sdc_width", 0.008),
        _ge_condition("pre_sdc_width>=0.01", "pre_sdc_width", 0.01),
        _ge_condition("pre_sdc_width>=0.012", "pre_sdc_width", 0.012),
        _le_condition("pre_chop<=45", "pre_chop", 45.0),
        _le_condition("pre_chop<=38", "pre_chop", 38.0),
        _ge_condition("pre_adx>=20", "pre_adx", 20.0),
        _ge_condition("pre_adx>=25", "pre_adx", 25.0),
        _ge_condition("pre_adx>=30", "pre_adx", 30.0),
        _le_condition("pre_close_pos<=0.20", "pre_close_pos_in_range", 0.20),
        _le_condition("pre_close_pos<=0.35", "pre_close_pos_in_range", 0.35),
        _ge_condition("pre_close_pos>=0.65", "pre_close_pos_in_range", 0.65),
        _ge_condition("pre_close_pos>=0.80", "pre_close_pos_in_range", 0.80),
        _le_condition("pre_rsi<=35", "pre_rsi", 35.0),
        _le_condition("pre_rsi<=30", "pre_rsi", 30.0),
        _le_condition("pre_rsi<=25", "pre_rsi", 25.0),
        _ge_condition("pre_rsi>=65", "pre_rsi", 65.0),
        _ge_condition("pre_rsi>=70", "pre_rsi", 70.0),
        _ge_condition("pre_rsi>=75", "pre_rsi", 75.0),
        _ge_condition("pre_td_buy>=8", "pre_td_buy_count", 8),
        _ge_condition("pre_td_buy>=9", "pre_td_buy_count", 9),
        _ge_condition("pre_td_buy>=10", "pre_td_buy_count", 10),
        _ge_condition("pre_td_buy>=12", "pre_td_buy_count", 12),
        _ge_condition("pre_td_buy>=13", "pre_td_buy_count", 13),
        _ge_condition("pre_td_sell>=8", "pre_td_sell_count", 8),
        _ge_condition("pre_td_sell>=9", "pre_td_sell_count", 9),
        _ge_condition("pre_td_sell>=10", "pre_td_sell_count", 10),
        _ge_condition("pre_td_sell>=12", "pre_td_sell_count", 12),
        _ge_condition("pre_td_sell>=13", "pre_td_sell_count", 13),
        _ge_condition("pre_red_streak>=2", "pre_red_streak", 2),
        _ge_condition("pre_red_streak>=3", "pre_red_streak", 3),
        _ge_condition("pre_red_streak>=4", "pre_red_streak", 4),
        _ge_condition("pre_red_streak>=5", "pre_red_streak", 5),
        _ge_condition("pre_green_streak>=2", "pre_green_streak", 2),
        _ge_condition("pre_green_streak>=3", "pre_green_streak", 3),
        _ge_condition("pre_green_streak>=4", "pre_green_streak", 4),
        _ge_condition("pre_green_streak>=5", "pre_green_streak", 5),
        _ge_condition("pre_down_close_streak>=2", "pre_down_close_streak", 2),
        _ge_condition("pre_down_close_streak>=3", "pre_down_close_streak", 3),
        _ge_condition("pre_up_close_streak>=2", "pre_up_close_streak", 2),
        _ge_condition("pre_up_close_streak>=3", "pre_up_close_streak", 3),
        _ge_condition("pre_prev5_red_count>=3", "pre_prev5_red_count", 3),
        _ge_condition("pre_prev5_red_count>=4", "pre_prev5_red_count", 4),
        _ge_condition("pre_prev5_green_count>=3", "pre_prev5_green_count", 3),
        _ge_condition("pre_prev5_green_count>=4", "pre_prev5_green_count", 4),
        _eq_condition("pre_state=diverging_bull", "pre_macd_state_code", 1),
        _eq_condition("pre_state=diverging_bear", "pre_macd_state_code", 2),
        _eq_condition("pre_state=arching_bull", "pre_macd_state_code", 3),
        _eq_condition("pre_state=arching_bear", "pre_macd_state_code", 4),
        _eq_condition("pre_state=converging_bull", "pre_macd_state_code", 5),
        _eq_condition("pre_state=converging_bear", "pre_macd_state_code", 6),
        _eq_condition("pre_state=zero_bear", "pre_macd_state_code", 7),
        _eq_condition("pre_state=zero_bull", "pre_macd_state_code", 8),
        _le_condition("pre_vwap_dist<=-0.005", "pre_vwap_dist_pct", -0.005),
        _le_condition("pre_vwap_dist<=-0.01", "pre_vwap_dist_pct", -0.01),
        _le_condition("pre_vwap_dist<=-0.015", "pre_vwap_dist_pct", -0.015),
        _le_condition("pre_vwap_dist<=-0.02", "pre_vwap_dist_pct", -0.02),
        _ge_condition("pre_vwap_dist>=0.005", "pre_vwap_dist_pct", 0.005),
        _ge_condition("pre_vwap_dist>=0.01", "pre_vwap_dist_pct", 0.01),
        _ge_condition("pre_vwap_dist>=0.015", "pre_vwap_dist_pct", 0.015),
        _ge_condition("pre_vwap_dist>=0.02", "pre_vwap_dist_pct", 0.02),
        _le_condition("pre_close_vwap_diff<=-0.15", "pre_close_vwap_diff_pct", -0.15),
        _le_condition("pre_close_vwap_diff<=-0.25", "pre_close_vwap_diff_pct", -0.25),
        _le_condition("pre_close_vwap_diff<=-0.35", "pre_close_vwap_diff_pct", -0.35),
        _ge_condition("pre_close_vwap_diff>=0.15", "pre_close_vwap_diff_pct", 0.15),
        _ge_condition("pre_close_vwap_diff>=0.25", "pre_close_vwap_diff_pct", 0.25),
        _ge_condition("pre_close_vwap_diff>=0.35", "pre_close_vwap_diff_pct", 0.35),
        _le_condition("pre_stoch<=20", "pre_stoch_rsi_k", 20.0),
        _le_condition("pre_stoch<=10", "pre_stoch_rsi_k", 10.0),
        _le_condition("pre_stoch<=5", "pre_stoch_rsi_k", 5.0),
        _ge_condition("pre_stoch>=80", "pre_stoch_rsi_k", 80.0),
        _ge_condition("pre_stoch>=90", "pre_stoch_rsi_k", 90.0),
        _ge_condition("pre_mfi>=80", "pre_mfi", 80.0),
        _ge_condition("pre_mfi>=85", "pre_mfi", 85.0),
        _le_condition("pre_mfi<=20", "pre_mfi", 20.0),
        _le_condition("pre_mfi<=15", "pre_mfi", 15.0),
        _ge_condition("pre_cmo>=40", "pre_cmo", 40.0),
        _ge_condition("pre_cmo>=50", "pre_cmo", 50.0),
        _le_condition("pre_cmo<=-40", "pre_cmo", -40.0),
        _le_condition("pre_cmo<=-50", "pre_cmo", -50.0),
        _ge_condition("pre_roc>=1", "pre_roc", 1.0),
        _ge_condition("pre_roc>=2", "pre_roc", 2.0),
        _le_condition("pre_roc<=-1", "pre_roc", -1.0),
        _le_condition("pre_roc<=-2", "pre_roc", -2.0),
        _ge_condition("pre_trix>=0.05", "pre_trix", 0.05),
        _ge_condition("pre_trix>=0.07", "pre_trix", 0.07),
        _le_condition("pre_trix<=-0.05", "pre_trix", -0.05),
        _le_condition("pre_trix<=-0.07", "pre_trix", -0.07),
        _ge_condition("pre_tsi>=25", "pre_tsi", 25.0),
        _ge_condition("pre_tsi>=40", "pre_tsi", 40.0),
        _le_condition("pre_tsi<=-25", "pre_tsi", -25.0),
        _le_condition("pre_tsi<=-40", "pre_tsi", -40.0),
        _ge_condition("pre_tsi_signal>=25", "pre_tsi_signal", 25.0),
        _ge_condition("pre_tsi_signal>=40", "pre_tsi_signal", 40.0),
        _le_condition("pre_tsi_signal<=-25", "pre_tsi_signal", -25.0),
        _le_condition("pre_tsi_signal<=-40", "pre_tsi_signal", -40.0),
        _ge_condition("pre_tsi_spread>=5", "pre_tsi_spread", 5.0),
        _ge_condition("pre_tsi_spread>=10", "pre_tsi_spread", 10.0),
        _le_condition("pre_tsi_spread<=-5", "pre_tsi_spread", -5.0),
        _le_condition("pre_tsi_spread<=-10", "pre_tsi_spread", -10.0),
        _ge_condition("pre_ultosc>=70", "pre_ultimate_osc", 70.0),
        _ge_condition("pre_ultosc>=75", "pre_ultimate_osc", 75.0),
        _le_condition("pre_ultosc<=30", "pre_ultimate_osc", 30.0),
        _le_condition("pre_ultosc<=25", "pre_ultimate_osc", 25.0),
        _ge_condition("pre_gap_pct>=0.5", "pre_gap_pct", 0.5),
        _le_condition("pre_gap_pct<=-0.5", "pre_gap_pct", -0.5),
        _ge_condition("pre_avg_body_prev3>=0.03", "pre_avg_body_prev3", 0.03),
        _ge_condition("pre_avg_range_prev3>=0.20", "pre_avg_range_prev3", 0.20),
        ConditionSpec(
            label="pre_cross_stack_bull",
            clause="(pre_vwap_cross_up AND (pre_macd_cross_up OR pre_tsi_cross_up OR pre_di_bull))",
            fn=lambda df: (
                df["pre_vwap_cross_up"].fillna(False).astype(bool)
                & (
                    df["pre_macd_cross_up"].fillna(False).astype(bool)
                    | df["pre_tsi_cross_up"].fillna(False).astype(bool)
                    | df["pre_di_bull"].fillna(False).astype(bool)
                )
            ),
        ),
        ConditionSpec(
            label="pre_cross_stack_bear",
            clause="(pre_vwap_cross_dn AND (pre_macd_cross_dn OR pre_tsi_cross_dn OR pre_di_bear))",
            fn=lambda df: (
                df["pre_vwap_cross_dn"].fillna(False).astype(bool)
                & (
                    df["pre_macd_cross_dn"].fillna(False).astype(bool)
                    | df["pre_tsi_cross_dn"].fillna(False).astype(bool)
                    | df["pre_di_bear"].fillna(False).astype(bool)
                )
            ),
        ),
        ConditionSpec(
            label="pre_compression_profile",
            clause="(pre_squeeze_on AND pre_bb_width <= 0.015 AND pre_keltner_width <= 0.004 AND pre_sdc_width <= 0.004)",
            fn=lambda df: (
                df["pre_squeeze_on"].fillna(False).astype(bool)
                & (pd.to_numeric(df["pre_bb_width"], errors="coerce") <= 0.015)
                & (pd.to_numeric(df["pre_keltner_width"], errors="coerce") <= 0.004)
                & (pd.to_numeric(df["pre_sdc_width"], errors="coerce") <= 0.004)
            ),
        ),
    ]
    return specs


def _iter_signal_chunks(cache_path: Path, chunksize: int) -> Iterator[pd.DataFrame]:
    for chunk in pd.read_csv(
        cache_path,
        compression="gzip",
        chunksize=int(chunksize),
        low_memory=False,
    ):
        yield _normalize_chunk(chunk)


def _evaluate_candidates(
    *,
    cache_path: Path,
    specs_by_label: Dict[str, ConditionSpec],
    combos: Sequence[tuple[str, ...]],
    side: str,
    recent_start_epoch: int,
    chunksize: int,
) -> tuple[Dict[tuple[str, ...], ComboStats], int, int]:
    stats_map: Dict[tuple[str, ...], ComboStats] = {tuple(combo): ComboStats() for combo in combos}
    total_rows = 0
    total_hits = 0
    success_col = "bull_exact" if side == "bull" else "bear_exact"
    best_col = "bull_best_ret" if side == "bull" else "bear_best_ret"

    for chunk in _iter_signal_chunks(cache_path, chunksize):
        labels = chunk[success_col].fillna(False).to_numpy(dtype=bool)
        best_rets = pd.to_numeric(chunk[best_col], errors="coerce").to_numpy(dtype=float)
        recent_mask = pd.to_numeric(chunk["ts_epoch"], errors="coerce").fillna(0).to_numpy(dtype=np.int64) >= int(recent_start_epoch)
        total_rows += int(len(chunk))
        total_hits += int(labels.sum())

        mask_map: Dict[str, np.ndarray] = {}
        for label, spec in specs_by_label.items():
            mask_map[label] = spec.fn(chunk).fillna(False).to_numpy(dtype=bool)

        for combo in combos:
            combo_mask = mask_map[combo[0]].copy()
            for label in combo[1:]:
                combo_mask &= mask_map[label]
            stats_map[combo].update(mask=combo_mask, labels=labels, recent_mask=recent_mask, best_rets=best_rets)
    return stats_map, total_rows, total_hits


def _stats_to_row(
    *,
    side: str,
    combo: tuple[str, ...],
    stats: ComboStats,
    base_rate: float,
    recent_base_rate: float,
    clause_map: Dict[str, str],
) -> Dict[str, object]:
    hit_rate = (stats.hits / float(stats.n)) if stats.n else 0.0
    recent_hit_rate = (stats.recent_hits / float(stats.recent_n)) if stats.recent_n else 0.0
    avg_best_ret = (stats.best_ret_sum / float(stats.best_ret_count)) if stats.best_ret_count else None
    return {
        "side": side,
        "conditions": " AND ".join(combo),
        "where_clause": " AND ".join(clause_map[label] for label in combo),
        "k": len(combo),
        "n": stats.n,
        "hits_exact6": stats.hits,
        "hit_rate_exact6": round(hit_rate, 4),
        "lift_exact6": round((hit_rate / base_rate), 4) if base_rate > 0 else None,
        "recent_n": stats.recent_n,
        "recent_hits_exact6": stats.recent_hits,
        "recent_hit_rate_exact6": round(recent_hit_rate, 4),
        "recent_lift_exact6": round((recent_hit_rate / recent_base_rate), 4) if recent_base_rate > 0 and stats.recent_n else None,
        "hit50": round((stats.hit50 / float(stats.best_ret_count)), 4) if stats.best_ret_count else 0.0,
        "hit100": round((stats.hit100 / float(stats.best_ret_count)), 4) if stats.best_ret_count else 0.0,
        "hit150": round((stats.hit150 / float(stats.best_ret_count)), 4) if stats.best_ret_count else 0.0,
        "avg_best_ret": round(avg_best_ret, 4) if avg_best_ret is not None and math.isfinite(avg_best_ret) else None,
    }


def _score_row(row: Dict[str, object]) -> tuple[float, float, int, float]:
    return (
        float(row.get("hit_rate_exact6") or 0.0),
        float(row.get("recent_hit_rate_exact6") or 0.0),
        int(row.get("n") or 0),
        float(row.get("hit100") or 0.0),
    )


def _select_survivors(
    rows: Sequence[Dict[str, object]],
    *,
    beam_width: int,
    candidate_pool: int,
    min_n: int,
) -> tuple[List[tuple[str, ...]], List[Dict[str, object]]]:
    filtered = [row for row in rows if int(row.get("n") or 0) >= int(min_n)]
    filtered.sort(key=_score_row, reverse=True)
    pool = filtered[: max(int(candidate_pool), int(beam_width))]
    survivors = [
        tuple(str(part).strip() for part in str(row["conditions"]).split(" AND ") if str(part).strip())
        for row in pool[: int(beam_width)]
    ]
    return survivors, pool


def _generate_extensions(prev_level: Sequence[tuple[str, ...]], labels: Sequence[str]) -> List[tuple[str, ...]]:
    label_pos = {label: idx for idx, label in enumerate(labels)}
    out: set[tuple[str, ...]] = set()
    for combo in prev_level:
        if not combo:
            continue
        last_pos = label_pos[combo[-1]]
        used = set(combo)
        for next_label in labels[last_pos + 1 :]:
            if next_label in used:
                continue
            out.add(tuple([*combo, next_label]))
    return sorted(out)


def _build_validation_queries(
    *,
    query: str,
    rows: Sequence[Dict[str, object]],
    limit: int,
) -> str:
    blocks: List[str] = []
    for idx, row in enumerate(rows[:limit], start=1):
        side = str(row["side"])
        success_col = "bull_exact" if side == "bull" else "bear_exact"
        best_col = "bull_best_ret" if side == "bull" else "bear_best_ret"
        blocks.append(
            "\n".join(
                [
                    f"-- Candidate {idx}: {side} | {row['conditions']}",
                    "WITH signal_frame AS (",
                    query,
                    ")",
                    "SELECT",
                    "    COUNT(*) AS n,",
                    f"    AVG(CASE WHEN {success_col} THEN 1.0 ELSE 0.0 END) AS hit_rate_exact6,",
                    f"    AVG(CASE WHEN {best_col} >= 0.005 THEN 1.0 ELSE 0.0 END) AS hit50,",
                    f"    AVG(CASE WHEN {best_col} >= 0.010 THEN 1.0 ELSE 0.0 END) AS hit100,",
                    f"    AVG(CASE WHEN {best_col} >= 0.015 THEN 1.0 ELSE 0.0 END) AS hit150,",
                    f"    AVG({best_col}) AS avg_best_ret",
                    "FROM signal_frame",
                    f"WHERE {row['where_clause']};",
                    "",
                ]
            )
        )
    return "\n".join(blocks).strip() + "\n"


def _build_leadin_query(*, query: str, limit_per_side: int = 5000) -> str:
    return "\n".join(
        [
            "WITH signal_frame AS (",
            query,
            "),",
            "bull_events AS (",
            "    SELECT ticker, timespan, ts_epoch AS burst_ts_epoch, 'bull'::text AS side",
            "    FROM signal_frame",
            "    WHERE bull_run_start",
            f"    LIMIT {int(limit_per_side)}",
            "),",
            "bear_events AS (",
            "    SELECT ticker, timespan, ts_epoch AS burst_ts_epoch, 'bear'::text AS side",
            "    FROM signal_frame",
            "    WHERE bear_run_start",
            f"    LIMIT {int(limit_per_side)}",
            "),",
            "events AS (",
            "    SELECT * FROM bull_events",
            "    UNION ALL",
            "    SELECT * FROM bear_events",
            ")",
            "SELECT",
            "    e.side,",
            "    e.ticker,",
            "    e.timespan,",
            "    e.burst_ts_epoch,",
            "    lead_rows.lead_offset,",
            "    lead_rows.ts_epoch AS lead_ts_epoch,",
            "    lead_rows.pre_c,",
            "    lead_rows.pre_rsi,",
            "    lead_rows.pre_td_buy_count,",
            "    lead_rows.pre_td_sell_count,",
            "    lead_rows.pre_bb_width,",
            "    lead_rows.pre_rvol,",
            "    lead_rows.pre_atr_pct,",
            "    lead_rows.pre_vwap_dist_pct,",
            "    lead_rows.pre_stoch_rsi_k,",
            "    lead_rows.pre_mfi,",
            "    lead_rows.pre_cmo,",
            "    lead_rows.pre_roc,",
            "    lead_rows.pre_trix,",
            "    lead_rows.pre_ultimate_osc,",
            "    lead_rows.pre_green_streak,",
            "    lead_rows.pre_red_streak,",
            "    lead_rows.pre_up_close_streak,",
            "    lead_rows.pre_down_close_streak,",
            "    lead_rows.pre_prev5_red_count,",
            "    lead_rows.pre_prev5_green_count,",
            "    lead_rows.pre_macd_state_code",
            "FROM events e",
            "JOIN LATERAL (",
            "    SELECT",
            "        ROW_NUMBER() OVER (ORDER BY sf.ts_epoch DESC) AS lead_offset,",
            "        sf.*",
            "    FROM signal_frame sf",
            "    WHERE sf.ticker = e.ticker",
            "      AND sf.timespan = e.timespan",
            "      AND sf.ts_epoch < e.burst_ts_epoch",
            "    ORDER BY sf.ts_epoch DESC",
            "    LIMIT 6",
            ") AS lead_rows ON TRUE",
            "ORDER BY e.side, e.ticker, e.timespan, e.burst_ts_epoch, lead_rows.lead_offset;",
            "",
        ]
    )


def _compute_base_rates(
    *,
    cache_path: Path,
    side: str,
    recent_start_epoch: int,
    chunksize: int,
) -> Dict[str, float]:
    success_col = "bull_exact" if side == "bull" else "bear_exact"
    total_rows = 0
    total_hits = 0
    recent_rows = 0
    recent_hits = 0
    for chunk in _iter_signal_chunks(cache_path, int(chunksize)):
        labels = chunk[success_col].fillna(False).to_numpy(dtype=bool)
        recent_mask = (
            pd.to_numeric(chunk["ts_epoch"], errors="coerce")
            .fillna(0)
            .to_numpy(dtype=np.int64)
            >= int(recent_start_epoch)
        )
        total_rows += int(len(chunk))
        total_hits += int(labels.sum())
        recent_rows += int(recent_mask.sum())
        recent_hits += int((labels & recent_mask).sum())
    return {
        "rows": float(total_rows),
        "hits": float(total_hits),
        "hit_rate": (total_hits / float(total_rows)) if total_rows else 0.0,
        "recent_rows": float(recent_rows),
        "recent_hits": float(recent_hits),
        "recent_hit_rate": (recent_hits / float(recent_rows)) if recent_rows else 0.0,
    }


def _write_summary(
    *,
    output_dir: Path,
    args: argparse.Namespace,
    resolved_start: str,
    resolved_end: str,
    cache_rows: int,
    base_rows: Dict[str, Dict[str, float]],
    top_rows: Dict[str, List[Dict[str, object]]],
    pass_rows: List[Dict[str, object]],
) -> None:
    sides = _parse_sides(args.sides)
    base_conditions = _parse_condition_labels(args.base_conditions)
    threshold_pct = int(round(float(args.min_hit_rate) * 100))
    threshold_label = f"{threshold_pct}%+ Candidates"
    lines: List[str] = [
        "# Exact Burst Combo Scan",
        "",
        f"- Source table: `public.ca`",
        f"- Scope: `{', '.join(_parse_timespans(args.timespans))}`, `session = regular`, `bb_width IS NOT NULL`, market-wide.",
        f"- Historical range used: `{resolved_start}` through `{resolved_end}`",
        f"- Exact burst definition: first candle in a `{int(args.min_run_length)}+` same-color run.",
        f"- Predictive contract: signal row, then a burst start arrives in bars `{int(args.min_trigger_bars)}` through `{int(args.trigger_bars)}`.",
        f"- Cached signal rows: `{cache_rows}`",
        f"- Search depth: `1..{int(args.max_k)}` with beam width `{int(args.beam_width)}` and candidate pool `{int(args.candidate_pool)}`.",
        "",
    ]
    if base_conditions:
        lines.extend(
            [
                f"- Anchored base conditions: `{', '.join(base_conditions)}`",
                f"- Max extra conditions: `{int(args.max_extra_k)}`",
                "",
            ]
        )
    for side in sides:
        base = base_rows[side]
        lines.append(
            f"- Base `{side}` rate: `n={int(base['rows'])}` `hits={int(base['hits'])}` `exact6={float(base['hit_rate']):.4f}` "
            f"`recent_exact6={float(base['recent_hit_rate']):.4f}`"
        )
    lines.append("")

    if pass_rows:
        lines.append(f"## {threshold_label}")
        lines.append("")
        for row in pass_rows[:16]:
            lines.append(
                f"- `{row['side']}` `{row['conditions']}`: `n={row['n']}` "
                f"`exact6={row['hit_rate_exact6']}` `recent={row['recent_hit_rate_exact6']}` "
                f"`hit100={row['hit100']}` `avg_best={row['avg_best_ret']}`"
            )
        lines.append("")
    else:
        lines.extend(
            [
                f"## {threshold_label}",
                "",
                f"- No candidate in this pass cleared the `{threshold_pct}%` exact-burst bar.",
                "",
            ]
        )

    for side in sides:
        lines.append(f"## Best {side.capitalize()} Candidates")
        lines.append("")
        rows = top_rows.get(side, [])[:12]
        if not rows:
            lines.append("- No candidates were evaluated.")
            lines.append("")
            continue
        for row in rows:
            lines.append(
                f"- `{row['conditions']}`: `n={row['n']}` `exact6={row['hit_rate_exact6']}` "
                f"`recent={row['recent_hit_rate_exact6']}` `hit50={row['hit50']}` "
                f"`hit100={row['hit100']}` `avg_best={row['avg_best_ret']}`"
            )
        lines.append("")

    (output_dir / "summary.md").write_text("\n".join(lines).strip() + "\n", encoding="utf-8")


def main() -> None:
    args = _parse_args()
    timespans = _parse_timespans(args.timespans)
    sides = _parse_sides(args.sides)
    base_conditions = _parse_condition_labels(args.base_conditions)
    timestamp = datetime.now(MARKET_TZ).strftime("%Y-%m-%d")
    start_slug = _slugify(args.start_date or "auto")
    end_slug = _slugify(args.end_date)
    anchor_suffix = ""
    if base_conditions:
        anchor_suffix = f"_base_{_slugify('_'.join(base_conditions[:2]))}_x{int(args.max_extra_k)}"
    run_name = (
        f"exact_burst_combo_scan_{'_'.join(timespans)}_"
        f"run{int(args.min_run_length)}_lead{int(args.min_trigger_bars)}_{int(args.trigger_bars)}_"
        f"k{int(args.max_k)}_{start_slug}_{end_slug}{anchor_suffix}_{timestamp}"
    )
    output_dir = Path(args.output_dir) if str(args.output_dir or "").strip() else OUTPUT_ROOT / run_name
    output_dir.mkdir(parents=True, exist_ok=True)

    conn = _db_connect(args)
    try:
        start_epoch, end_epoch, resolved_start, resolved_end = _resolve_bounds(
            conn,
            timespans=timespans,
            start_date=args.start_date,
            end_date=args.end_date,
        )
        signal_query = _build_signal_frame_query(
            timespans=timespans,
            start_epoch=start_epoch,
            end_epoch=end_epoch,
            min_run_length=int(args.min_run_length),
            min_trigger_bars=int(args.min_trigger_bars),
            trigger_bars=int(args.trigger_bars),
            best_window=int(args.best_window),
        )
        (output_dir / "event_universe.sql").write_text(signal_query + "\n", encoding="utf-8")

        cache_path = output_dir / "signal_frame.csv.gz"
        if not args.reuse_cache or not cache_path.exists():
            cache_rows = _export_signal_frame(
                conn,
                query=signal_query,
                cache_path=cache_path,
                chunksize=int(args.chunksize),
            )
        else:
            cache_rows = max(sum(1 for _ in gzip.open(cache_path, "rt", encoding="utf-8")) - 1, 0)
    finally:
        conn.close()

    condition_specs = _build_condition_specs()
    condition_catalog = [{"label": spec.label, "clause": spec.clause} for spec in condition_specs]
    (output_dir / "condition_catalog.json").write_text(json.dumps(condition_catalog, indent=2), encoding="utf-8")
    spec_labels = [spec["label"] for spec in condition_catalog]
    missing_base = [label for label in base_conditions if label not in spec_labels]
    if missing_base:
        raise ValueError(f"Unknown base conditions: {', '.join(missing_base)}")
    (output_dir / "leadin_query.sql").write_text(_build_leadin_query(query=signal_query), encoding="utf-8")

    if args.cache_only:
        metadata = {
            "timespans": timespans,
            "sides": sides,
            "resolved_start": resolved_start,
            "resolved_end": resolved_end,
            "cache_rows": int(cache_rows),
            "cache_path": str(cache_path),
            "base_conditions": base_conditions,
        }
        (output_dir / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        print(f"cached {cache_rows} rows to {cache_path}")
        return

    recent_start_epoch = _date_to_epoch(date.fromisoformat(resolved_end) - timedelta(days=max(1, int(args.recent_days) - 1)))
    label_order = [spec.label for spec in condition_specs]
    clause_map = {spec.label: spec.clause for spec in condition_specs}
    specs_by_label = {spec.label: spec for spec in condition_specs}

    all_rows: Dict[str, List[Dict[str, object]]] = {side: [] for side in sides}
    top_rows: Dict[str, List[Dict[str, object]]] = {side: [] for side in sides}
    base_rows: Dict[str, Dict[str, float]] = {}

    for side in sides:
        base_row_stats = _compute_base_rates(
            cache_path=cache_path,
            side=side,
            recent_start_epoch=recent_start_epoch,
            chunksize=int(args.chunksize),
        )
        base_rate = float(base_row_stats["hit_rate"])
        recent_base_rate = float(base_row_stats["recent_hit_rate"])
        base_rows[side] = base_row_stats

        if base_conditions:
            initial_combos = [tuple(base_conditions)]
            max_depth = max(0, int(args.max_extra_k))
        else:
            initial_combos = [(label,) for label in label_order]
            max_depth = int(args.max_k) - 1

        initial_stats, _, _ = _evaluate_candidates(
            cache_path=cache_path,
            specs_by_label=specs_by_label,
            combos=initial_combos,
            side=side,
            recent_start_epoch=recent_start_epoch,
            chunksize=int(args.chunksize),
        )
        level_rows = [
            _stats_to_row(
                side=side,
                combo=combo,
                stats=stats,
                base_rate=base_rate,
                recent_base_rate=recent_base_rate,
                clause_map=clause_map,
            )
            for combo, stats in initial_stats.items()
        ]
        level_rows.sort(key=_score_row, reverse=True)
        all_rows[side].extend(level_rows)
        survivors, pool = _select_survivors(
            level_rows,
            beam_width=int(args.beam_width),
            candidate_pool=int(args.candidate_pool),
            min_n=int(args.min_n),
        )
        top_rows[side].extend(pool)
        prev_level = survivors

        for _ in range(max_depth):
            combos = _generate_extensions(prev_level, label_order)
            if not combos:
                break
            combo_stats, _, _ = _evaluate_candidates(
                cache_path=cache_path,
                specs_by_label=specs_by_label,
                combos=combos,
                side=side,
                recent_start_epoch=recent_start_epoch,
                chunksize=int(args.chunksize),
            )
            level_rows = [
                _stats_to_row(
                    side=side,
                    combo=combo,
                    stats=stats,
                    base_rate=base_rate,
                    recent_base_rate=recent_base_rate,
                    clause_map=clause_map,
                )
                for combo, stats in combo_stats.items()
            ]
            level_rows.sort(key=_score_row, reverse=True)
            all_rows[side].extend(level_rows)
            survivors, pool = _select_survivors(
                level_rows,
                beam_width=int(args.beam_width),
                candidate_pool=int(args.candidate_pool),
                min_n=int(args.min_n),
            )
            top_rows[side].extend(pool)
            prev_level = survivors

        dedup_top: Dict[str, Dict[str, object]] = {}
        for row in top_rows[side]:
            key = str(row["conditions"])
            prior = dedup_top.get(key)
            if prior is None or _score_row(row) > _score_row(prior):
                dedup_top[key] = row
        ranked = list(dedup_top.values())
        ranked.sort(key=_score_row, reverse=True)
        top_rows[side] = ranked

        side_rows = pd.DataFrame(all_rows[side])
        side_rows.to_csv(output_dir / f"top_candidates_{side}.csv", index=False)
        (output_dir / f"top_candidates_{side}.json").write_text(json.dumps(top_rows[side][:50], indent=2), encoding="utf-8")

    combined_rows = [row for side in sides for row in all_rows[side]]
    combined_rows.sort(key=_score_row, reverse=True)
    filtered_combined_rows = [row for row in combined_rows if int(row.get("n") or 0) >= int(args.min_n)]
    pd.DataFrame(filtered_combined_rows).to_csv(output_dir / "top_candidates.csv", index=False)
    (output_dir / "top_candidates.json").write_text(
        json.dumps(filtered_combined_rows[:200], indent=2),
        encoding="utf-8",
    )

    pass_rows = [
        row
        for row in filtered_combined_rows
        if float(row.get("hit_rate_exact6") or 0.0) >= float(args.min_hit_rate)
    ]
    pass85_rows = [
        row
        for row in filtered_combined_rows
        if float(row.get("hit_rate_exact6") or 0.0) >= 0.85
    ]
    pd.DataFrame(pass_rows).to_csv(output_dir / "candidates_passing_threshold.csv", index=False)
    (output_dir / "candidates_passing_threshold.json").write_text(
        json.dumps(pass_rows[:200], indent=2),
        encoding="utf-8",
    )
    pd.DataFrame(pass85_rows).to_csv(output_dir / "candidates_pass85.csv", index=False)
    (output_dir / "candidates_pass85.json").write_text(json.dumps(pass85_rows[:200], indent=2), encoding="utf-8")

    validation_sql = _build_validation_queries(query=signal_query, rows=filtered_combined_rows, limit=24)
    (output_dir / "candidate_validation_queries.sql").write_text(validation_sql, encoding="utf-8")

    metadata = {
        "timespans": timespans,
        "sides": sides,
        "resolved_start": resolved_start,
        "resolved_end": resolved_end,
        "min_run_length": int(args.min_run_length),
        "min_trigger_bars": int(args.min_trigger_bars),
        "trigger_bars": int(args.trigger_bars),
        "best_window": int(args.best_window),
        "max_k": int(args.max_k),
        "base_conditions": base_conditions,
        "max_extra_k": int(args.max_extra_k),
        "beam_width": int(args.beam_width),
        "candidate_pool": int(args.candidate_pool),
        "min_n": int(args.min_n),
        "min_hit_rate": float(args.min_hit_rate),
        "recent_days": int(args.recent_days),
        "cache_rows": int(cache_rows),
        "pass_count": int(len(pass_rows)),
        "pass_threshold": float(args.min_hit_rate),
        "pass85_count": int(len(pass85_rows)),
        "base_rows": base_rows,
    }
    (output_dir / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    _write_summary(
        output_dir=output_dir,
        args=args,
        resolved_start=resolved_start,
        resolved_end=resolved_end,
        cache_rows=int(cache_rows),
        base_rows=base_rows,
        top_rows=top_rows,
        pass_rows=pass_rows,
    )

    print(f"wrote {output_dir}")


if __name__ == "__main__":
    main()
