import asyncio
import math
import os
import sys
from pathlib import Path

import aiohttp
from fudstop4._markets.list_sets.ticker_lists import most_active_nonetf
from fudstop4.apis.helpers import generate_webull_headers

project_dir = str(Path(__file__).resolve().parents[1])
if project_dir not in sys.path:
    sys.path.append(project_dir)

from imports import *  # noqa: F401,F403
from _webull.models.financials import BalanceSheet


def _log(message: str) -> None:
    try:
        print(message)
    except OSError:
        pass


async def balance_sheet(
    ticker: str,
    session: aiohttp.ClientSession,
    limit: str = "11",
) -> None:
    ticker_id = wbt.ticker_to_id_map.get(ticker)
    if not ticker_id:
        return

    url = (
        "https://quotes-gw.webullfintech.com/api/information/financial/balancesheet"
        f"?tickerId={ticker_id}&type=102&fiscalPeriod=1,2,3,4&limit={limit}"
    )
    try:
        async with session.get(url) as resp:
            payload = await resp.json(content_type=None)
            if resp.status != 200:
                _log(f"[balance_sheet] {ticker} request failed: status={resp.status}")
                return
            data = payload.get("data")
            if not data:
                return
            sheet = BalanceSheet(data)
            df = sheet.as_dataframe
            df["ticker"] = ticker
            await db.batch_upsert_dataframe(
                df,
                table_name="balance_sheet",
                unique_columns=["ticker", "fiscal_year", "fiscal_period"],
            )
    except Exception as exc:
        _log(f"[balance_sheet] {ticker}: {exc}")


BATCH_SIZE = 7
RUNS_PER_DAY = 2
PERIOD = 86400 // RUNS_PER_DAY


async def run_balance_sheet() -> None:
    tickers = most_active_nonetf
    await db.connect()
    try:
        while True:
            _log("[balance_sheet] Starting balance sheet run.")
            async with aiohttp.ClientSession(
                headers=generate_webull_headers(access_token=os.environ.get("ACCESS_TOKEN"))
            ) as session:
                for index in range(0, len(tickers), BATCH_SIZE):
                    batch = tickers[index:index + BATCH_SIZE]
                    tasks = [balance_sheet(ticker, session) for ticker in batch]
                    await asyncio.gather(*tasks, return_exceptions=True)
                    _log(
                        f"[balance_sheet] Completed batch {index // BATCH_SIZE + 1} "
                        f"of {math.ceil(len(tickers) / BATCH_SIZE)}"
                    )
            _log(f"[balance_sheet] All batches done. Sleeping for {PERIOD / 3600:.2f} hours.")
            await asyncio.sleep(PERIOD)
    finally:
        await db.disconnect()


if __name__ == "__main__":
    asyncio.run(run_balance_sheet())
