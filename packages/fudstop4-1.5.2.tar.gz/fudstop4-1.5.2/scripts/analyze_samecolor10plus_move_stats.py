from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from analyze_samecolor10plus_from_saved_runs import RUNS_CSV, fetch_run_day_frame
from analyze_samecolor10plus_logic_runs import OUTPUT_DIR, RUN_DATE
from search_consecutive_color_prerun_patterns import add_derived_columns, build_condition_specs


ROW_CACHE = OUTPUT_DIR / f"SAMECOLOR10PLUS_MATCHEDDAY_ROWS_{RUN_DATE}.pkl"
ENRICHED_CACHE = OUTPUT_DIR / f"SAMECOLOR10PLUS_MATCHEDDAY_ENRICHED_{RUN_DATE}.pkl"
SOURCE_REPORT = OUTPUT_DIR / f"SAMECOLOR10PLUS_MATCHEDDAY_PRERUN_ANALYSIS_{RUN_DATE}.json"
JSON_OUT = OUTPUT_DIR / f"SAMECOLOR10PLUS_MOVE_STATS_{RUN_DATE}.json"
MD_OUT = OUTPUT_DIR / f"SAMECOLOR10PLUS_MOVE_STATS_{RUN_DATE}.md"

WINDOWS = [5, 10, 15]
THRESHOLDS = [0.001, 0.002, 0.003, 0.005, 0.01]
THRESHOLD_LABELS = {
    0.001: "10bp",
    0.002: "20bp",
    0.003: "30bp",
    0.005: "50bp",
    0.01: "100bp",
}


def load_top_pairs(report_path: Path) -> dict[str, list[str]]:
    data = json.loads(report_path.read_text(encoding="utf-8"))
    return {
        "bull": [str(item["conditions"]) for item in data["study"]["bull"]["top_pairs"][:8]],
        "bear": [str(item["conditions"]) for item in data["study"]["bear"]["top_pairs"][:8]],
    }


def load_enriched_frame() -> pd.DataFrame:
    if ENRICHED_CACHE.exists():
        print(f"loading enriched cache {ENRICHED_CACHE.name}", flush=True)
        return pd.read_pickle(ENRICHED_CACHE)
    if ROW_CACHE.exists():
        print(f"loading row cache {ROW_CACHE.name}", flush=True)
        base = pd.read_pickle(ROW_CACHE)
    else:
        runs = pd.read_csv(RUNS_CSV)
        print(f"fetching matched-day rows for {len(runs)} runs", flush=True)
        base = fetch_run_day_frame(runs)
        ROW_CACHE.write_bytes(b"")
        base.to_pickle(ROW_CACHE)
    enriched = add_derived_columns(base)
    enriched.to_pickle(ENRICHED_CACHE)
    return enriched


def compute_future_excursions(frame: pd.DataFrame) -> pd.DataFrame:
    df = frame.copy()
    for window in WINDOWS:
        df[f"bull_best_{window}"] = np.nan
        df[f"bear_best_{window}"] = np.nan

    for (_, _), group_index in df.groupby(["ticker", "date_et"], sort=False).groups.items():
        idxs = list(group_index)
        highs = pd.to_numeric(df.loc[idxs, "h"], errors="coerce").to_numpy(dtype=float)
        lows = pd.to_numeric(df.loc[idxs, "l"], errors="coerce").to_numpy(dtype=float)
        closes = pd.to_numeric(df.loc[idxs, "c"], errors="coerce").to_numpy(dtype=float)
        size = len(idxs)
        for window in WINDOWS:
            bull = np.full(size, np.nan, dtype=float)
            bear = np.full(size, np.nan, dtype=float)
            if size > window:
                high_windows = np.lib.stride_tricks.sliding_window_view(highs[1:], window_shape=window)
                low_windows = np.lib.stride_tricks.sliding_window_view(lows[1:], window_shape=window)
                future_max = high_windows.max(axis=1)
                future_min = low_windows.min(axis=1)
                base_close = closes[: len(future_max)]
                valid = base_close > 0
                bull_vals = np.full(len(future_max), np.nan, dtype=float)
                bear_vals = np.full(len(future_max), np.nan, dtype=float)
                bull_vals[valid] = (future_max[valid] / base_close[valid]) - 1.0
                bear_vals[valid] = 1.0 - (future_min[valid] / base_close[valid])
                bull[: len(future_max)] = bull_vals
                bear[: len(future_max)] = bear_vals
            df.loc[idxs, f"bull_best_{window}"] = bull
            df.loc[idxs, f"bear_best_{window}"] = bear
    return df


def build_spec_lookup(frame: pd.DataFrame, side: str) -> dict[str, Any]:
    return {
        spec.name: spec
        for spec in build_condition_specs(frame, side, context_prefixes=[], logical_core_only=True)
    }


def mask_for_conditions(frame: pd.DataFrame, side: str, condition_string: str, lookup: dict[str, Any]) -> pd.Series:
    parts = [part.strip() for part in str(condition_string).split(" AND ") if part.strip()]
    mask = pd.Series(True, index=frame.index, dtype=bool)
    for part in parts:
        spec = lookup.get(part)
        if spec is None:
            raise KeyError(f"Missing condition spec: {part}")
        mask &= pd.Series(spec.mask, index=frame.index, dtype=bool)
    return mask


def evaluate_combo(
    frame: pd.DataFrame,
    side: str,
    condition_string: str,
    lookup: dict[str, Any],
    val_dates: list[str],
) -> dict[str, Any]:
    mask = mask_for_conditions(frame, side, condition_string, lookup)
    date_values = frame["date_et"].astype(str)
    val_mask = date_values.isin(val_dates)
    train_mask = ~val_mask
    result: dict[str, Any] = {
        "conditions": condition_string,
        "n": int(mask.sum()),
        "ticker_count": int(frame.loc[mask, "ticker"].astype(str).nunique()),
        "val_n": int((mask & val_mask).sum()),
        "val_ticker_count": int(frame.loc[mask & val_mask, "ticker"].astype(str).nunique()),
    }
    for window in WINDOWS:
        series = pd.to_numeric(frame.loc[:, f"{side}_best_{window}"], errors="coerce")
        for threshold in THRESHOLDS:
            label = THRESHOLD_LABELS[threshold]
            hits = series >= threshold
            overall = float(hits[mask].mean()) if int(mask.sum()) else 0.0
            train = float(hits[mask & train_mask].mean()) if int((mask & train_mask).sum()) else 0.0
            val = float(hits[mask & val_mask].mean()) if int((mask & val_mask).sum()) else 0.0
            result[f"w{window}_{label}"] = round(overall, 4)
            result[f"w{window}_{label}_train"] = round(train, 4)
            result[f"w{window}_{label}_val"] = round(val, 4)
        result[f"w{window}_avg_move"] = round(float(series[mask].mean()) if int(mask.sum()) else 0.0, 4)
    return result


def summarize_85(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    qualified: list[dict[str, Any]] = []
    for item in results:
        for window in WINDOWS:
            for threshold in THRESHOLDS:
                label = THRESHOLD_LABELS[threshold]
                overall = float(item[f"w{window}_{label}"])
                val = float(item[f"w{window}_{label}_val"])
                if overall >= 0.85 or val >= 0.85:
                    qualified.append(
                        {
                            "conditions": item["conditions"],
                            "window": window,
                            "threshold": label,
                            "overall_hit": overall,
                            "val_hit": val,
                            "n": int(item["n"]),
                            "val_n": int(item["val_n"]),
                        }
                    )
    qualified.sort(
        key=lambda row: (row["val_hit"], row["overall_hit"], row["val_n"], row["n"]),
        reverse=True,
    )
    return qualified


def render_markdown(report: dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append("# Same-Color 10+ Move Probability Analysis")
    lines.append("")
    lines.append("Assumption:")
    lines.append("- Bull combos are scored for future upside excursion.")
    lines.append("- Bear combos are scored for future downside excursion.")
    lines.append("- Move metric is best excursion within the next `5`, `10`, and `15` bars.")
    lines.append("- Thresholds tested: `10bp`, `20bp`, `30bp`, `50bp`, `100bp`.")
    lines.append("- Validation window is the last `8` trading days in the matched-day sample.")
    lines.append("")
    for side in ("bull", "bear"):
        lines.append(f"## {side.title()} Combos")
        qualified = report[side]["qualified_85"]
        if qualified:
            lines.append("- `85%+` hits found:")
            for item in qualified:
                lines.append(
                    f"- `{item['conditions']}` -> `{item['threshold']}` in `{item['window']}` bars | "
                    f"`overall={item['overall_hit']:.4f}` `val={item['val_hit']:.4f}` "
                    f"`n={item['n']}` `val_n={item['val_n']}`"
                )
        else:
            lines.append("- No tested combo cleared `85%` on either overall or validation hit rate at `10bp+` through `100bp` within `5`, `10`, or `15` bars.")
        lines.append("")
        lines.append("Top combos by strongest validation move hit:")
        for row in report[side]["results"][:6]:
            best_key = max(
                (
                    (window, threshold, row[f"w{window}_{THRESHOLD_LABELS[threshold]}_val"])
                    for window in WINDOWS
                    for threshold in THRESHOLDS
                ),
                key=lambda item: item[2],
            )
            window, threshold, val_hit = best_key
            label = THRESHOLD_LABELS[threshold]
            lines.append(
                f"- `{row['conditions']}` -> best validation hit `{val_hit:.4f}` at `{label}` in `{window}` bars "
                f"| `n={row['n']}` `val_n={row['val_n']}`"
            )
        lines.append("")
    return "\n".join(lines) + "\n"


def main() -> None:
    if not RUNS_CSV.exists():
        raise SystemExit(f"Missing run csv: {RUNS_CSV}")
    if not SOURCE_REPORT.exists():
        raise SystemExit(f"Missing source report: {SOURCE_REPORT}")

    source_pairs = load_top_pairs(SOURCE_REPORT)
    frame = load_enriched_frame()
    frame = compute_future_excursions(frame)
    unique_dates = sorted(str(value) for value in frame["date_et"].dropna().unique().tolist())
    val_dates = unique_dates[-min(8, len(unique_dates)) :]

    report: dict[str, Any] = {
        "assumption": {
            "directional": True,
            "windows": WINDOWS,
            "thresholds_bp": [int(threshold * 10000) for threshold in THRESHOLDS],
            "validation_dates": val_dates,
        }
    }

    for side in ("bull", "bear"):
        lookup = build_spec_lookup(frame, side)
        results = [
            evaluate_combo(frame, side, condition_string, lookup, val_dates)
            for condition_string in source_pairs[side]
        ]
        results.sort(
            key=lambda item: max(
                item[f"w{window}_{THRESHOLD_LABELS[threshold]}_val"]
                for window in WINDOWS
                for threshold in THRESHOLDS
            ),
            reverse=True,
        )
        report[side] = {
            "results": results,
            "qualified_85": summarize_85(results),
        }

    JSON_OUT.write_text(json.dumps(report, indent=2), encoding="utf-8")
    MD_OUT.write_text(render_markdown(report), encoding="utf-8")
    print(MD_OUT)
    print(JSON_OUT)


if __name__ == "__main__":
    main()
