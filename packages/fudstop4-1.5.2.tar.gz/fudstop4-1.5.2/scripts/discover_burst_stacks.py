#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Iterable, Iterator, List, Tuple

import pandas as pd
import psycopg2
from psycopg2.extensions import connection as PgConnection
from zoneinfo import ZoneInfo


MARKET_TZ = ZoneInfo("America/New_York")
ROOT = Path(__file__).resolve().parents[1]
SQL_PATH = ROOT / "scripts" / "fudstop_burst_discovery.sql"
OUTPUT_ROOT = ROOT / "burst_discovery_output"
DEFAULT_CHUNK_DAYS = 5
DEFAULT_LOOKBACK_DAYS = 1
DEFAULT_LOOKAHEAD_SECONDS = 300


@dataclass(frozen=True)
class ChunkWindow:
    chunk_index: int
    start_date: str
    end_date: str
    core_start_epoch: int
    core_end_epoch: int
    lookback_start_epoch: int
    lookahead_end_epoch: int


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Chunked m1 burst-discovery artifact generator for public.ca. "
            "Writes 5-day burst-run and labeled-event chunks plus baseline summaries."
        )
    )
    parser.add_argument("--start-date", default="")
    parser.add_argument("--end-date", default="")
    parser.add_argument("--chunk-days", type=int, default=DEFAULT_CHUNK_DAYS)
    parser.add_argument("--lookback-days", type=int, default=DEFAULT_LOOKBACK_DAYS)
    parser.add_argument("--lookahead-seconds", type=int, default=DEFAULT_LOOKAHEAD_SECONDS)
    parser.add_argument("--max-chunks", type=int, default=0)
    parser.add_argument("--output-root", default=str(OUTPUT_ROOT))
    parser.add_argument(
        "--no-resume",
        action="store_false",
        dest="resume",
        help="Regenerate chunk files even when matching outputs already exist.",
    )
    parser.set_defaults(resume=True)
    return parser.parse_args()


def load_env_defaults() -> Dict[str, str]:
    env_path = ROOT / "stock_market_site" / "app" / ".env"
    values: Dict[str, str] = {}
    if not env_path.exists():
        return values
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def db_connect(env_defaults: Dict[str, str]) -> PgConnection:
    return psycopg2.connect(
        host=env_defaults.get("DB_HOST", "localhost"),
        port=int(env_defaults.get("DB_PORT", "5432")),
        user=env_defaults.get("DB_USER", "chuck"),
        password=env_defaults.get("DB_PASSWORD", "fud"),
        dbname=env_defaults.get("DB_NAME", "fudstop3"),
        connect_timeout=5,
    )


def et_epoch(day: date, hour: int = 0, minute: int = 0, second: int = 0) -> int:
    return int(datetime(day.year, day.month, day.day, hour, minute, second, tzinfo=MARKET_TZ).timestamp())


def parse_date(raw: str) -> date:
    return datetime.strptime(str(raw or "").strip(), "%Y-%m-%d").date()


def load_sql_sections(sql_path: Path) -> Dict[str, str]:
    sections: Dict[str, List[str]] = {}
    current_name: str | None = None
    for raw_line in sql_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.rstrip("\n")
        if line.startswith("-- name:"):
            current_name = line.split(":", 1)[1].strip()
            sections[current_name] = []
            continue
        if current_name is not None:
            sections[current_name].append(line)
    return {name: "\n".join(lines).strip() for name, lines in sections.items() if lines}


def inventory_columns(conn: PgConnection) -> List[Dict[str, str]]:
    query = """
    SELECT
        column_name,
        data_type
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'ca'
    ORDER BY ordinal_position
    """.strip()
    with conn.cursor() as cur:
        cur.execute(query)
        rows = cur.fetchall()
    return [{"column_name": str(row[0]), "data_type": str(row[1])} for row in rows]


def resolve_date_range(conn: PgConnection, *, start_date: str, end_date: str) -> Tuple[date, date, int]:
    query = """
    SELECT
        MIN(date_et)::text,
        MAX(date_et)::text,
        COUNT(*)::bigint
    FROM public.ca
    WHERE LOWER(COALESCE(timespan, '')) = 'm1'
    """.strip()
    with conn.cursor() as cur:
        cur.execute(query)
        row = cur.fetchone()
    if not row or not row[0] or not row[1]:
        raise RuntimeError("No public.ca rows found for timespan='m1'.")
    min_day = parse_date(str(row[0]))
    max_day = parse_date(str(row[1]))
    total_rows = int(row[2] or 0)
    resolved_start = parse_date(start_date) if str(start_date or "").strip() else min_day
    resolved_end = parse_date(end_date) if str(end_date or "").strip() else max_day
    if resolved_end < resolved_start:
        raise ValueError("end-date must be on or after start-date.")
    return resolved_start, resolved_end, total_rows


def iter_chunk_windows(
    *,
    start_day: date,
    end_day: date,
    chunk_days: int,
    lookback_days: int,
    lookahead_seconds: int,
    max_chunks: int,
) -> Iterator[ChunkWindow]:
    chunk_index = 0
    cursor = start_day
    while cursor <= end_day:
        chunk_index += 1
        next_day = min(cursor + timedelta(days=chunk_days), end_day + timedelta(days=1))
        core_start_epoch = et_epoch(cursor)
        core_end_epoch = et_epoch(next_day)
        lookback_start_epoch = et_epoch(cursor - timedelta(days=lookback_days))
        lookahead_end_epoch = core_end_epoch + int(lookahead_seconds)
        yield ChunkWindow(
            chunk_index=chunk_index,
            start_date=cursor.isoformat(),
            end_date=(next_day - timedelta(days=1)).isoformat(),
            core_start_epoch=core_start_epoch,
            core_end_epoch=core_end_epoch,
            lookback_start_epoch=lookback_start_epoch,
            lookahead_end_epoch=lookahead_end_epoch,
        )
        if max_chunks and chunk_index >= int(max_chunks):
            break
        cursor = next_day


def render_query(template: str, window: ChunkWindow) -> str:
    return template.format(
        LOOKBACK_START_EPOCH=int(window.lookback_start_epoch),
        LOOKAHEAD_END_EPOCH=int(window.lookahead_end_epoch),
        CORE_START_EPOCH=int(window.core_start_epoch),
        CORE_END_EPOCH=int(window.core_end_epoch),
    )


def write_frame(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, compression="gzip")


def chunk_file_name(prefix: str, window: ChunkWindow) -> str:
    return f"{prefix}_{window.chunk_index:04d}_{window.start_date}_{window.end_date}.csv.gz"


def compute_baseline_counts(frame: pd.DataFrame) -> Dict[str, int]:
    out = {
        "rows": int(len(frame)),
        "bullish_start_next_3m_hits": 0,
        "bullish_start_next_5m_hits": 0,
        "bearish_start_next_3m_hits": 0,
        "bearish_start_next_5m_hits": 0,
        "unique_tickers": 0,
    }
    if frame.empty:
        return out
    for column in (
        "bullish_start_next_3m",
        "bullish_start_next_5m",
        "bearish_start_next_3m",
        "bearish_start_next_5m",
    ):
        if column in frame.columns:
            out[f"{column}_hits"] = int(frame[column].fillna(False).astype(bool).sum())
    if "ticker" in frame.columns:
        out["unique_tickers"] = int(frame["ticker"].astype(str).nunique())
    return out


def baseline_rates_from_totals(baseline_totals: Dict[str, int]) -> Dict[str, float | int]:
    rows = int(baseline_totals["rows"])
    return {
        "rows": rows,
        "burst_rows": int(baseline_totals["burst_rows"]),
        "bullish_start_next_3m_rate": (
            baseline_totals["bullish_start_next_3m_hits"] / float(rows)
            if rows
            else 0.0
        ),
        "bullish_start_next_5m_rate": (
            baseline_totals["bullish_start_next_5m_hits"] / float(rows)
            if rows
            else 0.0
        ),
        "bearish_start_next_3m_rate": (
            baseline_totals["bearish_start_next_3m_hits"] / float(rows)
            if rows
            else 0.0
        ),
        "bearish_start_next_5m_rate": (
            baseline_totals["bearish_start_next_5m_hits"] / float(rows)
            if rows
            else 0.0
        ),
    }


def write_progress_files(
    *,
    output_root: Path,
    manifest: List[Dict[str, object]],
    baseline_totals: Dict[str, int],
    run_metadata: Dict[str, object],
) -> None:
    baseline_rates = baseline_rates_from_totals(baseline_totals)
    (output_root / "chunk_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (output_root / "baseline_rates.json").write_text(json.dumps(baseline_rates, indent=2), encoding="utf-8")
    (output_root / "chunk_run_metadata.json").write_text(json.dumps(run_metadata, indent=2), encoding="utf-8")


def main() -> None:
    args = parse_args()
    output_root = Path(args.output_root).resolve()
    burst_dir = output_root / "burst_runs"
    events_dir = output_root / "labeled_events"
    output_root.mkdir(parents=True, exist_ok=True)
    burst_dir.mkdir(parents=True, exist_ok=True)
    events_dir.mkdir(parents=True, exist_ok=True)

    sql_sections = load_sql_sections(SQL_PATH)
    if "burst_runs" not in sql_sections or "labeled_events" not in sql_sections:
        raise RuntimeError("fudstop_burst_discovery.sql must define both 'burst_runs' and 'labeled_events' sections.")

    env_defaults = load_env_defaults()
    conn = db_connect(env_defaults)
    try:
        column_inventory = inventory_columns(conn)
        (output_root / "schema_inventory.json").write_text(json.dumps(column_inventory, indent=2), encoding="utf-8")

        start_day, end_day, total_m1_rows = resolve_date_range(
            conn,
            start_date=str(args.start_date or ""),
            end_date=str(args.end_date or ""),
        )
        manifest: List[Dict[str, object]] = []
        baseline_totals = {
            "rows": 0,
            "bullish_start_next_3m_hits": 0,
            "bullish_start_next_5m_hits": 0,
            "bearish_start_next_3m_hits": 0,
            "bearish_start_next_5m_hits": 0,
            "burst_rows": 0,
        }
        run_metadata = {
            "source_table": "public.ca",
            "timespan": "m1",
            "chunk_days": int(args.chunk_days),
            "lookback_days": int(args.lookback_days),
            "lookahead_seconds": int(args.lookahead_seconds),
            "resolved_start": start_day.isoformat(),
            "resolved_end": end_day.isoformat(),
            "total_m1_rows": int(total_m1_rows),
            "processed_chunks": 0,
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        }

        for window in iter_chunk_windows(
            start_day=start_day,
            end_day=end_day,
            chunk_days=int(args.chunk_days),
            lookback_days=int(args.lookback_days),
            lookahead_seconds=int(args.lookahead_seconds),
            max_chunks=int(args.max_chunks),
        ):
            burst_path = burst_dir / chunk_file_name("burst_runs", window)
            events_path = events_dir / chunk_file_name("labeled_events", window)
            source = "reused"
            if bool(args.resume) and burst_path.exists() and events_path.exists():
                burst_frame = pd.read_csv(burst_path, compression="gzip", low_memory=False)
                events_frame = pd.read_csv(events_path, compression="gzip", low_memory=False)
            else:
                burst_query = render_query(sql_sections["burst_runs"], window)
                events_query = render_query(sql_sections["labeled_events"], window)
                chunk_conn = db_connect(env_defaults)
                try:
                    with chunk_conn.cursor() as cur:
                        cur.execute("SET statement_timeout TO '30min'")
                    burst_frame = pd.read_sql_query(burst_query, chunk_conn)
                    events_frame = pd.read_sql_query(events_query, chunk_conn)
                finally:
                    chunk_conn.close()
                write_frame(burst_frame, burst_path)
                write_frame(events_frame, events_path)
                source = "generated"

            chunk_baselines = compute_baseline_counts(events_frame)
            baseline_totals["rows"] += int(chunk_baselines["rows"])
            baseline_totals["bullish_start_next_3m_hits"] += int(chunk_baselines["bullish_start_next_3m_hits"])
            baseline_totals["bullish_start_next_5m_hits"] += int(chunk_baselines["bullish_start_next_5m_hits"])
            baseline_totals["bearish_start_next_3m_hits"] += int(chunk_baselines["bearish_start_next_3m_hits"])
            baseline_totals["bearish_start_next_5m_hits"] += int(chunk_baselines["bearish_start_next_5m_hits"])
            baseline_totals["burst_rows"] += int(len(burst_frame))

            manifest.append(
                {
                    **asdict(window),
                    "burst_file": str(burst_path),
                    "event_file": str(events_path),
                    "source": source,
                    "burst_rows": int(len(burst_frame)),
                    "event_rows": int(len(events_frame)),
                    "baseline_counts": chunk_baselines,
                }
            )
            run_metadata["processed_chunks"] = len(manifest)
            run_metadata["generated_at_utc"] = datetime.now(timezone.utc).isoformat()
            write_progress_files(
                output_root=output_root,
                manifest=manifest,
                baseline_totals=baseline_totals,
                run_metadata=run_metadata,
            )
            print(
                json.dumps(
                    {
                        "chunk_index": window.chunk_index,
                        "start_date": window.start_date,
                        "end_date": window.end_date,
                        "source": source,
                        "burst_rows": int(len(burst_frame)),
                        "event_rows": int(len(events_frame)),
                        "baseline_rows": int(baseline_totals["rows"]),
                    }
                ),
                flush=True,
            )

        baseline_rates = baseline_rates_from_totals(baseline_totals)
        print(json.dumps({"run_metadata": run_metadata, "baseline_rates": baseline_rates}, indent=2), flush=True)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
