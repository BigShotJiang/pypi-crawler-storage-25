from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple


PROMOTED_OUTPUT_FILENAME = "rev_promoted_spawn_move_marketwide_m1_live.json"
WATCHLIST_OUTPUT_FILENAME = "rev_live_watchlist_spawn_move_marketwide_m1_live.json"

CONTRACT_NAME = "spawn_move_trigger1_5_target100bp"
STATUS_NAME = "promotable_spawn_move_market_rule"

TIMESPAN_LABELS = {
    "m1": "1m",
    "m5": "5m",
    "m15": "15m",
    "m30": "30m",
    "m60": "1h",
    "m120": "2h",
    "m240": "4h",
    "d1": "1d",
    "w1": "1w",
    "mo1": "1mo",
    "mth1": "1mo",
}

TIME_WINDOW_FIELDS = {
    ("09:30:00", "09:45:00"): "tod_opening_15",
    ("09:30:00", "10:00:00"): "tod_opening_30",
    ("09:30:00", "10:30:00"): "tod_first_hour",
}

COMPARISON_PATTERN = re.compile(r"^(?P<field>[a-zA-Z0-9_]+)\s*(?P<op>>=|<=|=|>|<)\s*(?P<value>.+)$")
NUMERIC_PATTERN = re.compile(r"^-?\d+(?:\.\d+)?$")


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Translate promoted spawn-move market-wide REV rules into site-consumable JSON specs."
    )
    parser.add_argument(
        "--promoted-csv",
        default="burst_discovery_output/promotable_market_rules.csv",
        help="Path to the promoted spawn-move CSV.",
    )
    parser.add_argument(
        "--data-dir",
        default="stock_market_site/app/data",
        help="Directory where site REV JSON files should be written.",
    )
    return parser.parse_args()


def _normalize_timespan(value: Any) -> str:
    normalized = str(value or "").strip().lower()
    if normalized == "1m":
        return "m1"
    if normalized == "1mo":
        return "mo1"
    return normalized


def _timespan_label(value: Any) -> str:
    normalized = _normalize_timespan(value)
    return TIMESPAN_LABELS.get(normalized, normalized or "1m")


def _to_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _to_int(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _strip_quotes(value: str) -> str:
    stripped = value.strip()
    if len(stripped) >= 2 and stripped[0] == stripped[-1] and stripped[0] in {"'", '"'}:
        return stripped[1:-1]
    return stripped


def _parse_sql_value(raw_value: str) -> Any:
    stripped = _strip_quotes(raw_value)
    lowered = stripped.lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if NUMERIC_PATTERN.match(stripped):
        return float(stripped)
    return stripped


def _predicate_to_conditions(sql_predicate: str) -> List[Tuple[str, str, Any]]:
    raw_parts = [part.strip() for part in str(sql_predicate or "").split(" AND ") if part.strip()]
    conditions: List[Tuple[str, str, Any]] = []
    index = 0
    while index < len(raw_parts):
        part = raw_parts[index]
        comparison = COMPARISON_PATTERN.match(part)
        if comparison:
            field = comparison.group("field").strip().lower()
            operator = comparison.group("op").strip()
            raw_value = comparison.group("value").strip()
            parsed_value = _parse_sql_value(raw_value)

            if field == "timespan":
                index += 1
                continue

            if field == "time_et":
                if index + 1 >= len(raw_parts):
                    raise ValueError(f"incomplete time_et window in predicate: {sql_predicate}")
                next_part = raw_parts[index + 1]
                next_comparison = COMPARISON_PATTERN.match(next_part)
                if not next_comparison or next_comparison.group("field").strip().lower() != "time_et":
                    raise ValueError(f"unsupported time_et window in predicate: {sql_predicate}")
                if operator not in {">=", ">"} or next_comparison.group("op").strip() not in {"<=", "<"}:
                    raise ValueError(f"unsupported time_et operators in predicate: {sql_predicate}")
                window_start = _strip_quotes(raw_value)
                window_end = _strip_quotes(next_comparison.group("value").strip())
                day_segment_field = TIME_WINDOW_FIELDS.get((window_start, window_end))
                if not day_segment_field:
                    raise ValueError(f"unsupported time_et window {window_start}..{window_end}")
                conditions.append((day_segment_field, "truthy", True))
                index += 2
                continue

            if operator == "=":
                if isinstance(parsed_value, bool):
                    conditions.append((field, "truthy", parsed_value))
                elif isinstance(parsed_value, float):
                    conditions.append((field, "eqnum", parsed_value))
                else:
                    conditions.append((field, "eq", parsed_value))
            elif operator == ">=":
                conditions.append((field, "gte", _to_float(parsed_value)))
            elif operator == "<=":
                conditions.append((field, "lte", _to_float(parsed_value)))
            else:
                raise ValueError(f"unsupported operator {operator} in predicate: {sql_predicate}")
            index += 1
            continue

        bare_field = part.strip().lower()
        if not bare_field:
            index += 1
            continue
        conditions.append((bare_field, "truthy", True))
        index += 1
    return conditions


def _condition_summary(sql_predicate: str) -> str:
    predicate = str(sql_predicate or "").strip()
    if not predicate:
        return ""
    if predicate.lower().startswith("timespan = 'm1' and "):
        return predicate[len("timespan = 'm1' AND ") :]
    return predicate


def _build_spec(row: Dict[str, Any], slot_rank: int) -> Dict[str, Any]:
    timespan = _normalize_timespan(row.get("timespan") or "m1") or "m1"
    tone = "bullish" if str(row.get("direction") or "").strip().lower() == "bull" else "bearish"
    hit_rate = round(_to_float(row.get("oos_precision"), 0.0), 4)
    sample_size = _to_int(row.get("oos_signal_count"), 0)
    condition_summary = _condition_summary(str(row.get("sql_predicate") or ""))
    notes = str(row.get("notes") or "").strip()
    date_range = str(row.get("date_range") or "").strip()
    why_it_matters = (
        "Validated on ca under the market-wide m1 spawn-move contract: trigger begins within candles 1-5 with at least "
        "0.50% directional move, then the best excursion in candles 10-15 must still reach 1.00%. "
        f"OOS precision {hit_rate * 100:.2f}% across {sample_size} signals"
    )
    if date_range:
        why_it_matters = f"{why_it_matters} on {date_range}."
    else:
        why_it_matters = f"{why_it_matters}."
    if notes:
        why_it_matters = f"{why_it_matters} {notes}"
    return {
        "key": str(row.get("rule_id") or "").strip(),
        "timespan": timespan,
        "tone": tone,
        "label": "Spawn-move reversal edge",
        "full_label": f"{_timespan_label(timespan)} {tone} spawn-move reversal edge",
        "hit_rate": hit_rate,
        "sample_size": sample_size,
        "target_pct": 1.0,
        "condition_summary": condition_summary,
        "why_it_matters": why_it_matters,
        "conditions": _predicate_to_conditions(condition_summary),
        "event_groups": [],
        "source_file": "burst_discovery_output/promotable_market_rules.csv",
        "slot_rank": slot_rank,
        "contract": str(row.get("contract") or "").strip(),
        "wilson_lower_bound": round(_to_float(row.get("wilson_lower_bound"), 0.0), 4),
    }


def _load_promoted_rows(promoted_csv: Path) -> List[Dict[str, Any]]:
    with promoted_csv.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    filtered = [
        row
        for row in rows
        if str(row.get("contract") or "").strip() == CONTRACT_NAME
        and str(row.get("status") or "").strip() == STATUS_NAME
        and _normalize_timespan(row.get("timespan")) == "m1"
    ]
    filtered.sort(
        key=lambda row: (
            -_to_int(row.get("oos_signal_count"), 0),
            -_to_float(row.get("oos_precision"), 0.0),
            str(row.get("rule_id") or ""),
        )
    )
    return filtered


def _write_specs(path: Path, specs: Sequence[Dict[str, Any]]) -> None:
    path.write_text(json.dumps(list(specs), indent=2), encoding="utf-8")


def sync_site_spawnmove_rev_specs(promoted_csv: Path | str, data_dir: Path | str) -> Dict[str, Any]:
    promoted_path = Path(promoted_csv)
    output_dir = Path(data_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    rows = _load_promoted_rows(promoted_path)
    specs = [_build_spec(row, slot_rank=index) for index, row in enumerate(rows, start=1)]

    promoted_output = output_dir / PROMOTED_OUTPUT_FILENAME
    watchlist_output = output_dir / WATCHLIST_OUTPUT_FILENAME
    _write_specs(promoted_output, specs)
    _write_specs(watchlist_output, specs)

    return {
        "count": len(specs),
        "promoted_output": str(promoted_output),
        "watchlist_output": str(watchlist_output),
    }


def main() -> None:
    args = _parse_args()
    summary = sync_site_spawnmove_rev_specs(args.promoted_csv, args.data_dir)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
