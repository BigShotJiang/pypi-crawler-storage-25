#!/usr/bin/env python3
"""
Launch and supervise the continuously updated FUDSTOP live stack.

- daemon specs: keep the script alive, restart on exit
- interval specs: rerun a one-shot script on a fixed cadence
"""

from __future__ import annotations

import asyncio
import datetime
import json
import os
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Tuple

ROOT = Path(__file__).resolve().parent
REPO_ROOT = ROOT.parent
LOG_DIR = REPO_ROOT / "tmp" / "live_stack_supervisor"
STATUS_PATH = LOG_DIR / "status.json"
PYTHON_BIN = os.getenv("LIVE_STACK_PYTHON") or sys.executable

repo_root_str = str(REPO_ROOT)
if repo_root_str not in sys.path:
    sys.path.append(repo_root_str)

from fudstop4.apis.polygonio.polygon_options import PolygonOptions


@dataclass(frozen=True)
class ProcessSpec:
    name: str
    script: str
    mode: str = "daemon"  # daemon | interval
    interval_seconds: int = 0
    args: Tuple[str, ...] = field(default_factory=tuple)
    env: Dict[str, str] = field(default_factory=dict)
    table_name: str = ""
    freshness_seconds: int = 300


SPECS: List[ProcessSpec] = [
    ProcessSpec("discord_live_ingest", "discord_live_ingest.py", table_name="discord_messages", freshness_seconds=120),
    ProcessSpec(
        "discord_confluence_forums",
        "discord_confluence_forums.py",
        mode="interval",
        interval_seconds=300,
        args=("--sync-only", "--limit", "5"),
    ),
    ProcessSpec(
        "multi_quote",
        "multi_quote_new.py",
        env={"HTTP_PORT": "9314", "HTTP_HOST": "127.0.0.1"},
        table_name="multi_quote",
        freshness_seconds=300,
    ),
    ProcessSpec("technical_events", "technical_events.py", table_name="technical_events", freshness_seconds=180),
    ProcessSpec("news", "news.py", table_name="ai_news", freshness_seconds=900),
    ProcessSpec("cost_distribution", "cost_distribution.py", table_name="cost_distribution", freshness_seconds=7200),
    ProcessSpec("volume_summary", "volume_summary.py", table_name="volume_summary", freshness_seconds=900),
    ProcessSpec("crypto_candles", "crypto_candles.py", table_name="crypto_candles", freshness_seconds=300),
    ProcessSpec("active", "active.py", table_name="active", freshness_seconds=900),
    ProcessSpec("all_options", "all_options.py", table_name="wb_opts", freshness_seconds=900),
    ProcessSpec("atm_options", "atm_options.py", table_name="atm_options", freshness_seconds=300),
    ProcessSpec("analysts", "analysts.py", table_name="analysts", freshness_seconds=86400),
    ProcessSpec("info", "info.py", table_name="info", freshness_seconds=86400),
    ProcessSpec("stock_monitor", "stock_monitor.py", table_name="stock_monitor", freshness_seconds=1800),
    ProcessSpec("options_monitor", "options_monitor.py", table_name="options_monitor", freshness_seconds=600),
    ProcessSpec("historic_ivx", "historic_ivx.py", table_name="historic_ivx", freshness_seconds=600),
    ProcessSpec("gex", "gex.py", table_name="gex", freshness_seconds=600),
    ProcessSpec("top_followed", "top_followed.py", table_name="top_followed", freshness_seconds=86400),
    ProcessSpec("us_bonds", "us_bonds.py", table_name="us_bonds", freshness_seconds=86400),
    ProcessSpec("live_rules_scanner", "live_rules_scanner.py"),
    ProcessSpec(
        "macd_synthesis",
        "macd_synthesis.py",
        mode="interval",
        interval_seconds=300,
        table_name="macd_synthesis",
        freshness_seconds=900,
    ),
    ProcessSpec(
        "confluence_master",
        "confluence_master.py",
        mode="interval",
        interval_seconds=300,
        table_name="confluence_master",
        freshness_seconds=900,
    ),
]

STATE: Dict[str, Dict[str, object]] = {}
TABLE_DB = PolygonOptions(database="fudstop3")


def now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def merged_env(spec: ProcessSpec) -> Dict[str, str]:
    env = os.environ.copy()
    env.setdefault("PYTHONUNBUFFERED", "1")
    for key, value in spec.env.items():
        env[str(key)] = str(value)
    return env


def find_existing_pid(spec: ProcessSpec) -> int:
    script_name = Path(spec.script).name
    module_name = Path(spec.script).stem
    escaped_script_name = script_name.replace(".", "\\.")
    command = (
        "Get-CimInstance Win32_Process | Where-Object { "
        "$_.Name -match 'python' -and ("
        f"$_.CommandLine -match '{escaped_script_name}' -or "
        f"$_.CommandLine -match ' -m {module_name}\\b'"
        ") } | Select-Object -ExpandProperty ProcessId"
    )
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", command],
            capture_output=True,
            text=True,
            check=False,
            cwd=str(REPO_ROOT),
        )
    except Exception:
        return 0
    for line in result.stdout.splitlines():
        text = line.strip()
        if text.isdigit():
            return int(text)
    return 0


async def write_status_snapshot() -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    STATUS_PATH.write_text(json.dumps({"updated_at": now_iso(), "processes": STATE}, indent=2), encoding="utf-8")


def stale_state(last_inserted_at: object, freshness_seconds: int) -> Dict[str, object]:
    if not isinstance(last_inserted_at, datetime.datetime):
        return {"table_status": "missing", "table_age_seconds": None}
    now = datetime.datetime.now()
    age_seconds = max(0, int((now - last_inserted_at).total_seconds()))
    return {
        "table_status": "fresh" if age_seconds <= max(30, freshness_seconds) else "stale",
        "table_age_seconds": age_seconds,
    }


async def refresh_table_statuses() -> None:
    specs = [spec for spec in SPECS if spec.table_name]
    if not specs:
        return

    await TABLE_DB.connect()
    try:
        for spec in specs:
            STATE.setdefault(spec.name, {})
            try:
                table_count = await TABLE_DB.fetchval(f"SELECT COUNT(*) FROM {spec.table_name}")
                last_inserted_at = await TABLE_DB.fetchval(
                    f"SELECT MAX(insertion_timestamp) FROM {spec.table_name}"
                )
                STATE[spec.name].update(
                    {
                        "table_name": spec.table_name,
                        "table_count": int(table_count or 0),
                        "table_last_inserted_at": last_inserted_at.isoformat(sep=" ") if last_inserted_at else None,
                        "table_checked_at": now_iso(),
                        **stale_state(last_inserted_at, spec.freshness_seconds),
                    }
                )
            except Exception as exc:
                STATE[spec.name].update(
                    {
                        "table_name": spec.table_name,
                        "table_checked_at": now_iso(),
                        "table_status": "error",
                        "table_error": str(exc),
                    }
                )
    finally:
        await TABLE_DB.disconnect()


async def status_loop() -> None:
    last_table_refresh = 0.0
    while True:
        now_ts = asyncio.get_running_loop().time()
        if now_ts - last_table_refresh >= 30:
            await refresh_table_statuses()
            last_table_refresh = now_ts
        await write_status_snapshot()
        await asyncio.sleep(15)


async def spawn_process(spec: ProcessSpec):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_handle = open(LOG_DIR / f"{spec.name}.log", "ab")
    process = await asyncio.create_subprocess_exec(
        PYTHON_BIN,
        str(ROOT / spec.script),
        *spec.args,
        cwd=str(REPO_ROOT),
        env=merged_env(spec),
        stdout=log_handle,
        stderr=asyncio.subprocess.STDOUT,
    )
    STATE.setdefault(spec.name, {})
    STATE[spec.name].update(
        {
            "pid": process.pid,
            "mode": spec.mode,
            "script": spec.script,
            "started_at": now_iso(),
            "status": "running",
            "restarts": int(STATE[spec.name].get("restarts", 0)),
        }
    )
    print(f"[live_stack_supervisor] started {spec.name} pid={process.pid}")
    return process, log_handle


async def run_daemon(spec: ProcessSpec) -> None:
    backoff_seconds = 5
    while True:
        external_pid = find_existing_pid(spec)
        if external_pid:
            STATE.setdefault(spec.name, {})
            STATE[spec.name].update(
                {
                    "pid": external_pid,
                    "mode": spec.mode,
                    "script": spec.script,
                    "status": "external",
                    "checked_at": now_iso(),
                }
            )
            await asyncio.sleep(30)
            continue
        process, log_handle = await spawn_process(spec)
        return_code = await process.wait()
        log_handle.close()
        restarts = int(STATE[spec.name].get("restarts", 0)) + 1
        STATE[spec.name].update(
            {
                "status": "stopped",
                "last_exit_code": return_code,
                "last_stopped_at": now_iso(),
                "restarts": restarts,
            }
        )
        print(f"[live_stack_supervisor] {spec.name} exited rc={return_code}; restarting in {backoff_seconds}s")
        await asyncio.sleep(backoff_seconds)


async def run_interval(spec: ProcessSpec) -> None:
    wait_seconds = max(30, int(spec.interval_seconds or 300))
    while True:
        external_pid = find_existing_pid(spec)
        if external_pid:
            STATE.setdefault(spec.name, {})
            STATE[spec.name].update(
                {
                    "pid": external_pid,
                    "mode": spec.mode,
                    "script": spec.script,
                    "status": "external",
                    "checked_at": now_iso(),
                    "next_run_at": (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=wait_seconds)).isoformat(),
                }
            )
            await asyncio.sleep(wait_seconds)
            continue
        process, log_handle = await spawn_process(spec)
        return_code = await process.wait()
        log_handle.close()
        runs = int(STATE[spec.name].get("runs", 0)) + 1
        STATE[spec.name].update(
            {
                "status": "sleeping",
                "last_exit_code": return_code,
                "last_stopped_at": now_iso(),
                "runs": runs,
                "next_run_at": (datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(seconds=wait_seconds)).isoformat(),
            }
        )
        print(f"[live_stack_supervisor] {spec.name} completed rc={return_code}; next run in {wait_seconds}s")
        await asyncio.sleep(wait_seconds)


async def main() -> None:
    tasks = [asyncio.create_task(status_loop())]
    for spec in SPECS:
        runner = run_daemon if spec.mode == "daemon" else run_interval
        tasks.append(asyncio.create_task(runner(spec)))
    try:
        await asyncio.gather(*tasks)
    finally:
        await write_status_snapshot()


if __name__ == "__main__":
    asyncio.run(main())
