import asyncio
import sys
from datetime import datetime
from pathlib import Path

import pandas as pd

project_dir = str(Path(__file__).resolve().parents[1])
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

from fudstop4.apis.occ.occ_sdk import occSDK
from fudstop4.apis.polygonio.polygon_options import PolygonOptions
from fudstop4._markets.list_sets.ticker_lists import most_active_tickers

occ = occSDK()
db = PolygonOptions()
SLEEP_SECONDS = 300
MAX_CONCURRENT_TASKS = 8
sem = asyncio.Semaphore(MAX_CONCURRENT_TASKS)


def _log(message: str) -> None:
    try:
        print(message)
    except OSError:
        pass


async def stock_info(ticker):
    async with sem:
        try:
            info = await occ.stock_info(ticker)
            if info is None or not hasattr(info, "as_dataframe"):
                return

            df = info.as_dataframe
            date_columns = [
                "latest_dividend_date",
                "latest_split_date",
                "latest_earnings_date",
                "estimate_earnings_date",
                "next_earning_day",
                "dividend_date",
            ]

            for col in date_columns:
                if col in df.columns:
                    df[col] = pd.to_datetime(df[col], errors="coerce").dt.date

            await db.batch_upsert_dataframe(
                df,
                table_name="info",
                unique_columns=["ticker"],
            )
            _log(f"[info] Updated: {ticker} at {datetime.now().strftime('%H:%M:%S')}")
        except Exception as exc:
            _log(f"[info] Error for {ticker}: {exc}")


async def main_loop():
    await db.connect()
    try:
        while True:
            try:
                tasks = [stock_info(ticker) for ticker in most_active_tickers]
                await asyncio.gather(*tasks, return_exceptions=True)
            except Exception as exc:
                _log(f"[info] Main loop error: {exc}")
            _log(f"[info] Sleeping for {SLEEP_SECONDS // 60} minutes...")
            await asyncio.sleep(SLEEP_SECONDS)
    finally:
        await db.disconnect()


if __name__ == "__main__":
    asyncio.run(main_loop())
