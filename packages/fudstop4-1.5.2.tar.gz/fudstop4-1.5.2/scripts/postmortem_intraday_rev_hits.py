#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import io
import json
import os
import subprocess
from collections import defaultdict
from dataclasses import dataclass
from datetime import date, datetime, time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence
from zoneinfo import ZoneInfo

from fudstop4._markets.list_sets.ticker_lists import most_active_tickers


DEFAULT_PSQL_PATH = r"C:\Program Files\PostgreSQL\17\bin\psql.exe"
MARKET_TIMEZONE = ZoneInfo("America/New_York")
DEFAULT_SPEC_FILE = Path("stock_market_site/app/data/rev_promoted_consecutive_move_mixed.json")
DEFAULT_OUTPUT_DIR = Path("runs/ca_historical_reversal_research")
DEFAULT_TIMESPANS = ("m1", "m5", "m15", "m30")
BOOL_FIELDS = {
    "volume_confirm",
    "trend_regime",
    "bb_close_outside_lower",
    "bb_close_outside_upper",
    "candle_green",
    "candle_red",
    "candle_completely_above_upper",
    "candle_completely_below_lower",
    "vwap_cross_up",
    "vwap_cross_dn",
}
INT_FIELDS = {"td_buy_count", "td_sell_count"}


@dataclass
class HitRecord:
    ticker: str
    timespan: str
    tone: str
    first_idx: int
    first_row: Dict[str, Any]
    specs: List[Dict[str, Any]]
    best_spec: Dict[str, Any]
    hit_rows: int


def env_default(name: str, fallback: str, *, invalid_values: Sequence[str] = ()) -> str:
    raw = os.environ.get(name)
    text = str(raw or "").strip()
    if not text:
        return fallback
    if text.lower() in {value.strip().lower() for value in invalid_values if str(value).strip()}:
        return fallback
    return text


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Replay intraday REV hit records for a trading day and score resolved outcomes.",
    )
    parser.add_argument("--host", default=env_default("DB_HOST", "localhost"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("DB_PORT", "5432")))
    parser.add_argument("--user", default=env_default("DB_USER", "chuck"))
    parser.add_argument("--password", default=os.environ.get("DB_PASSWORD", "fud"))
    parser.add_argument("--database", default=env_default("DB_NAME", "fudstop3", invalid_values=("database",)))
    parser.add_argument("--psql-path", default=os.environ.get("PSQL_PATH", DEFAULT_PSQL_PATH))
    parser.add_argument("--spec-file", default=str(DEFAULT_SPEC_FILE))
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument("--timespans", default=",".join(DEFAULT_TIMESPANS))
    parser.add_argument("--date", default="")
    parser.add_argument("--universe", choices=("most_active", "all"), default="most_active")
    parser.add_argument("--tickers", default="")
    return parser.parse_args()


def parse_date(raw: str) -> date:
    text = str(raw or "").strip()
    if not text:
        return datetime.now(MARKET_TIMEZONE).date()
    return datetime.strptime(text, "%Y-%m-%d").date()


def parse_timespans(raw: str) -> List[str]:
    values = [value.strip().lower() for value in str(raw or "").split(",") if value.strip()]
    return values or list(DEFAULT_TIMESPANS)


def parse_tickers(raw: str, universe: str) -> Optional[List[str]]:
    values = [value.strip().upper() for value in str(raw or "").split(",") if value.strip()]
    if values:
        seen = set()
        ordered: List[str] = []
        for value in values:
            if value in seen:
                continue
            seen.add(value)
            ordered.append(value)
        return ordered
    if universe == "most_active":
        seen = set()
        ordered = []
        for value in most_active_tickers:
            ticker = str(value or "").strip().upper()
            if not ticker or ticker in seen:
                continue
            seen.add(ticker)
            ordered.append(ticker)
        return ordered
    return None


def market_bounds(market_date: date) -> tuple[int, int]:
    start = datetime.combine(market_date, time(9, 30), tzinfo=MARKET_TIMEZONE)
    end = datetime.combine(market_date, time(16, 0), tzinfo=MARKET_TIMEZONE)
    return int(start.timestamp()), int(end.timestamp())


def run_psql_copy_csv(
    query: str,
    *,
    psql_path: str,
    host: str,
    port: int,
    user: str,
    password: str,
    database: str,
) -> List[Dict[str, str]]:
    env = os.environ.copy()
    env["PGPASSWORD"] = password
    result = subprocess.run(
        [psql_path, "-h", host, "-p", str(port), "-U", user, "-d", database, "-Atc", query],
        capture_output=True,
        text=True,
        env=env,
        check=True,
    )
    return list(csv.DictReader(io.StringIO(result.stdout)))


def run_psql_lines(
    query: str,
    *,
    psql_path: str,
    host: str,
    port: int,
    user: str,
    password: str,
    database: str,
) -> List[str]:
    env = os.environ.copy()
    env["PGPASSWORD"] = password
    result = subprocess.run(
        [psql_path, "-h", host, "-p", str(port), "-U", user, "-d", database, "-Atc", query],
        capture_output=True,
        text=True,
        env=env,
        check=True,
    )
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def sql_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def to_float(value: Any) -> Optional[float]:
    if value in (None, "", "None", "nan", "NaN"):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def to_int(value: Any) -> int:
    if value in (None, "", "None", "nan", "NaN"):
        return 0
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def to_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value or "").strip().lower() in {"true", "t", "1", "yes", "y"}


def infer_macd_state_code(row: Dict[str, Any]) -> Optional[int]:
    macd_hist = to_float(row.get("macd_hist"))
    macd_hist_slope = to_float(row.get("macd_hist_slope"))
    macd_hist_slope3 = to_float(row.get("macd_hist_slope3"))
    if macd_hist is None or macd_hist_slope is None:
        return None
    pace_seed = abs(macd_hist_slope3) / 3.0 if macd_hist_slope3 not in (None, 0.0) else abs(macd_hist_slope)
    avg_delta = max(abs(macd_hist_slope), abs(pace_seed), 1e-9)
    if abs(macd_hist) < (avg_delta * 0.5) and abs(macd_hist_slope) < (avg_delta * 0.2):
        return 7 if macd_hist < 0 else 8
    if macd_hist > 0 and macd_hist_slope > (avg_delta * 0.8):
        return 1
    if macd_hist < 0 and macd_hist_slope < -(avg_delta * 0.8):
        return 2
    if macd_hist > 0 and macd_hist_slope < -(avg_delta * 0.8):
        return 3
    if macd_hist < 0 and macd_hist_slope > (avg_delta * 0.8):
        return 4
    return 5 if macd_hist > 0 else 6


def match_condition(row: Dict[str, Any], condition: Sequence[Any]) -> bool:
    field, operator, target = condition
    value = row.get(field)
    if operator == "truthy":
        return bool(value) is bool(target)
    if value is None:
        return False
    if operator == "gte":
        return float(value) >= float(target)
    if operator == "lte":
        return float(value) <= float(target)
    if operator == "eqnum":
        return int(value) == int(target)
    if operator == "innum":
        targets = {int(item) for item in target}
        return int(value) in targets
    raise ValueError(f"unsupported operator: {operator}")


def load_specs(spec_file: Path, timespans: Sequence[str]) -> List[Dict[str, Any]]:
    raw_specs = json.loads(spec_file.read_text(encoding="utf-8"))
    allowed = {str(value or "").strip().lower() for value in timespans}
    return [
        dict(spec)
        for spec in raw_specs
        if str(spec.get("timespan") or "").strip().lower() in allowed
    ]


def required_fields(specs: Sequence[Dict[str, Any]]) -> List[str]:
    fields = {"ticker", "timespan", "ts", "o", "h", "l", "c", "macd_hist", "macd_hist_slope", "macd_hist_slope3"}
    for spec in specs:
        for condition in spec.get("conditions") or []:
            field = str(condition[0] or "").strip()
            if field and field != "macd_state_code":
                fields.add(field)
    return sorted(fields)


def fetch_available_columns(args: argparse.Namespace, fields: Sequence[str]) -> set[str]:
    field_sql = ", ".join(sql_quote(field) for field in fields)
    query = (
        "SELECT column_name FROM information_schema.columns "
        "WHERE table_schema='public' AND table_name='ca' "
        f"AND column_name IN ({field_sql}) ORDER BY column_name"
    )
    return set(
        run_psql_lines(
            query,
            psql_path=args.psql_path,
            host=args.host,
            port=args.port,
            user=args.user,
            password=args.password,
            database=args.database,
        ),
    )


def fetch_rows(
    args: argparse.Namespace,
    fields: Sequence[str],
    tickers: Optional[Sequence[str]],
    timespans: Sequence[str],
    market_date: date,
) -> List[Dict[str, Any]]:
    start_epoch, end_epoch = market_bounds(market_date)
    select_fields = ", ".join(fields)
    ticker_filter = ""
    if tickers:
        ticker_filter = " AND ticker IN (" + ", ".join(sql_quote(ticker) for ticker in tickers) + ")"
    timespan_filter = ", ".join(sql_quote(timespan) for timespan in timespans)
    query = f"""
COPY (
  SELECT {select_fields},
         ts::bigint AS ts_epoch,
         to_char(to_timestamp(ts::bigint) AT TIME ZONE 'America/New_York', 'YYYY-MM-DD HH24:MI:SS') AS ts_et
  FROM public.ca
  WHERE timespan IN ({timespan_filter})
    AND ts::bigint BETWEEN {start_epoch} AND {end_epoch}
    {ticker_filter}
  ORDER BY UPPER(ticker), LOWER(timespan), ts::bigint
) TO STDOUT WITH CSV HEADER
""".strip()
    raw_rows = run_psql_copy_csv(
        query,
        psql_path=args.psql_path,
        host=args.host,
        port=args.port,
        user=args.user,
        password=args.password,
        database=args.database,
    )
    parsed: List[Dict[str, Any]] = []
    for raw in raw_rows:
        row: Dict[str, Any] = {
            "ticker": str(raw.get("ticker") or "").strip().upper(),
            "timespan": str(raw.get("timespan") or "").strip().lower(),
            "ts_epoch": to_int(raw.get("ts_epoch")),
            "ts_et": str(raw.get("ts_et") or "").strip(),
        }
        for field in fields:
            if field in {"ticker", "timespan", "ts"}:
                continue
            value = raw.get(field)
            if field in INT_FIELDS:
                row[field] = to_int(value)
            elif field in BOOL_FIELDS:
                row[field] = to_bool(value)
            else:
                row[field] = to_float(value)
        row["macd_state_code"] = infer_macd_state_code(row)
        parsed.append(row)
    return parsed


def group_rows(rows: Iterable[Dict[str, Any]]) -> Dict[tuple[str, str], List[Dict[str, Any]]]:
    grouped: Dict[tuple[str, str], List[Dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[(str(row.get("ticker") or ""), str(row.get("timespan") or ""))].append(row)
    return grouped


def build_hit_records(
    specs: Sequence[Dict[str, Any]],
    grouped_rows: Dict[tuple[str, str], List[Dict[str, Any]]],
) -> List[HitRecord]:
    records: Dict[tuple[str, str, str], HitRecord] = {}
    for spec in specs:
        timespan = str(spec.get("timespan") or "").strip().lower()
        tone = str(spec.get("tone") or "neutral").strip().lower() or "neutral"
        for (ticker, row_timespan), rows in grouped_rows.items():
            if row_timespan != timespan:
                continue
            for idx, row in enumerate(rows):
                if not all(match_condition(row, condition) for condition in (spec.get("conditions") or ())):
                    continue
                key = (ticker, timespan, tone)
                record = records.get(key)
                if record is None:
                    records[key] = HitRecord(
                        ticker=ticker,
                        timespan=timespan,
                        tone=tone,
                        first_idx=idx,
                        first_row=row,
                        specs=[dict(spec)],
                        best_spec=dict(spec),
                        hit_rows=1,
                    )
                    continue
                record.hit_rows += 1
                record.specs.append(dict(spec))
                current_best = record.best_spec
                spec_hit_rate = to_float(spec.get("hit_rate")) or 0.0
                best_hit_rate = to_float(current_best.get("hit_rate")) or 0.0
                spec_sample = to_int(spec.get("sample_size"))
                best_sample = to_int(current_best.get("sample_size"))
                if spec_hit_rate > best_hit_rate or (spec_hit_rate == best_hit_rate and spec_sample > best_sample):
                    record.best_spec = dict(spec)
    return list(records.values())


def score_record(record: HitRecord, rows: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    spec = record.best_spec
    trigger_window_min = max(1, to_int(spec.get("trigger_window_min")) or 1)
    trigger_window_max = max(trigger_window_min, to_int(spec.get("trigger_window_max")) or 3)
    run_window_min = max(trigger_window_max + 1, to_int(spec.get("run_window_min")) or 10)
    run_window_max = max(run_window_min, to_int(spec.get("run_window_max")) or 15)
    trigger_rows = rows[record.first_idx + trigger_window_min:record.first_idx + trigger_window_max + 1]
    run_rows = rows[record.first_idx + run_window_min:record.first_idx + run_window_max + 1]
    payload: Dict[str, Any] = {
        "ticker": record.ticker,
        "timespan": record.timespan,
        "tone": record.tone,
        "first_hit": record.first_row.get("ts_et"),
        "lead_key": str(spec.get("key") or "").strip(),
        "stack_count": len({str(item.get("key") or "").strip() for item in record.specs if str(item.get("key") or "").strip()}),
        "hit_rows": record.hit_rows,
        "sample_size": to_int(spec.get("sample_size")),
        "hit_rate": to_float(spec.get("hit_rate")) or 0.0,
        "target_pct": to_float(spec.get("target_pct")) or 0.0,
        "condition_summary": str(spec.get("condition_summary") or "").strip(),
    }
    if len(trigger_rows) != (trigger_window_max - trigger_window_min + 1) or len(run_rows) != (run_window_max - run_window_min + 1):
        payload["status"] = "unresolved"
        return payload
    close_value = to_float(record.first_row.get("c"))
    if close_value in (None, 0.0):
        payload["status"] = "unresolved"
        return payload
    trigger_floor = to_float(spec.get("trigger_min_move")) or 0.0
    target_pct = to_float(spec.get("target_pct")) or 0.0
    if record.tone == "bullish":
        trigger_close = max(to_float(row.get("c")) or 0.0 for row in trigger_rows)
        hold_close = min(to_float(row.get("c")) or 0.0 for row in run_rows)
        trigger_ret = (trigger_close / close_value) - 1.0
        hold_ret = (hold_close / close_value) - 1.0
    else:
        trigger_candidates = [to_float(row.get("c")) for row in trigger_rows if to_float(row.get("c")) not in (None, 0.0)]
        hold_candidates = [to_float(row.get("c")) for row in run_rows if to_float(row.get("c")) not in (None, 0.0)]
        if not trigger_candidates or not hold_candidates:
            payload["status"] = "unresolved"
            return payload
        trigger_ret = (close_value / min(trigger_candidates)) - 1.0
        hold_ret = (close_value / max(hold_candidates)) - 1.0
    payload["status"] = "resolved"
    payload["trigger_ret"] = trigger_ret
    payload["hold_ret"] = hold_ret
    payload["success"] = bool(trigger_ret >= trigger_floor and hold_ret >= target_pct)
    for field in (
        "atr_pct",
        "rvol",
        "rsi",
        "td_buy_count",
        "td_sell_count",
        "trend_regime",
        "roc",
        "bb_width",
        "vwap_dist_pct",
        "stoch_rsi_k",
        "trix",
        "volume_confirm",
        "bb_close_outside_lower",
        "chop",
        "ultimate_osc",
    ):
        payload[field] = record.first_row.get(field)
    return payload


def summarize_by_key(items: Sequence[Dict[str, Any]], key_name: str) -> List[Dict[str, Any]]:
    buckets: Dict[str, Dict[str, Any]] = {}
    for item in items:
        key = str(item.get(key_name) or "").strip()
        if not key:
            continue
        bucket = buckets.setdefault(key, {"key": key, "count": 0, "wins": 0, "losses": 0, "hold_sum": 0.0})
        bucket["count"] += 1
        success = bool(item.get("success"))
        bucket["wins"] += int(success)
        bucket["losses"] += int(not success)
        bucket["hold_sum"] += to_float(item.get("hold_ret")) or 0.0
    summary = []
    for bucket in buckets.values():
        count = int(bucket["count"])
        summary.append(
            {
                "key": bucket["key"],
                "count": count,
                "wins": int(bucket["wins"]),
                "losses": int(bucket["losses"]),
                "win_rate": (bucket["wins"] / count) if count else 0.0,
                "avg_hold_ret": (bucket["hold_sum"] / count) if count else 0.0,
            }
        )
    return sorted(summary, key=lambda item: (-item["count"], item["key"]))


def tighter_filter_counts(losers: Sequence[Dict[str, Any]]) -> Dict[str, Dict[str, int]]:
    bearish = [item for item in losers if str(item.get("tone") or "") == "bearish" and str(item.get("timespan") or "") == "m1"]
    bullish = [item for item in losers if str(item.get("tone") or "") == "bullish" and str(item.get("timespan") or "") == "m1"]

    def count(items: Sequence[Dict[str, Any]], fn) -> int:
        return sum(1 for item in items if fn(item))

    return {
        "m1_bearish": {
            "total": len(bearish),
            "bb_width_gte_0_07": count(bearish, lambda item: (to_float(item.get("bb_width")) or -1.0) >= 0.07),
            "vwap_dist_gte_0_015": count(bearish, lambda item: (to_float(item.get("vwap_dist_pct")) or -1.0) >= 0.015),
            "trix_gte_0_08": count(bearish, lambda item: (to_float(item.get("trix")) or -1.0) >= 0.08),
            "bb_width_vwap_gate": count(
                bearish,
                lambda item: (to_float(item.get("bb_width")) or -1.0) >= 0.07 and (to_float(item.get("vwap_dist_pct")) or -1.0) >= 0.015,
            ),
            "bb_width_trix_vwap_gate": count(
                bearish,
                lambda item: (
                    (to_float(item.get("bb_width")) or -1.0) >= 0.07
                    and (to_float(item.get("trix")) or -1.0) >= 0.08
                    and (to_float(item.get("vwap_dist_pct")) or -1.0) >= 0.015
                ),
            ),
        },
        "m1_bullish": {
            "total": len(bullish),
            "atr_pct_gte_0_005": count(bullish, lambda item: (to_float(item.get("atr_pct")) or -1.0) >= 0.005),
            "stoch_lte_5": count(bullish, lambda item: (to_float(item.get("stoch_rsi_k")) or 999.0) <= 5.0),
            "vwap_dist_lte_neg0_01": count(bullish, lambda item: (to_float(item.get("vwap_dist_pct")) or 999.0) <= -0.01),
            "atr_stoch_gate": count(
                bullish,
                lambda item: (to_float(item.get("atr_pct")) or -1.0) >= 0.005 and (to_float(item.get("stoch_rsi_k")) or 999.0) <= 5.0,
            ),
            "atr_stoch_vwap_gate": count(
                bullish,
                lambda item: (
                    (to_float(item.get("atr_pct")) or -1.0) >= 0.005
                    and (to_float(item.get("stoch_rsi_k")) or 999.0) <= 5.0
                    and (to_float(item.get("vwap_dist_pct")) or 999.0) <= -0.01
                ),
            ),
        },
    }


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    headers = sorted({key for row in rows for key in row.keys()})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def build_markdown(
    *,
    market_date: date,
    resolved: Sequence[Dict[str, Any]],
    unresolved: Sequence[Dict[str, Any]],
    by_timespan_tone: Sequence[Dict[str, Any]],
    by_spec: Sequence[Dict[str, Any]],
    filter_counts: Dict[str, Dict[str, int]],
) -> str:
    lines = [
        f"# Intraday REV Postmortem - {market_date.isoformat()}",
        "",
        f"- Resolved recorded hits: `{len(resolved)}`",
        f"- Unresolved near-close hits: `{len(unresolved)}`",
        "",
        "## Resolved Summary",
        "",
    ]
    if by_timespan_tone:
        for item in by_timespan_tone:
            lines.append(
                f"- `{item['key']}`: `n={item['count']}` | wins `{item['wins']}` | losses `{item['losses']}` | win rate `{item['win_rate']:.2%}` | avg hold `{item['avg_hold_ret']:.3%}`"
            )
    else:
        lines.append("- No resolved hits.")
    lines.extend(["", "## Lead Specs", ""])
    if by_spec:
        for item in by_spec:
            lines.append(
                f"- `{item['key']}`: `n={item['count']}` | wins `{item['wins']}` | losses `{item['losses']}` | win rate `{item['win_rate']:.2%}` | avg hold `{item['avg_hold_ret']:.3%}`"
            )
    else:
        lines.append("- No resolved hits.")
    lines.extend(["", "## m1 Filter Postmortem", ""])
    bear = filter_counts.get("m1_bearish", {})
    bull = filter_counts.get("m1_bullish", {})
    lines.append(
        f"- `m1 bearish losers`: `{bear.get('total', 0)}` total | `bb_width>=0.07` `{bear.get('bb_width_gte_0_07', 0)}` | `vwap_dist>=0.015` `{bear.get('vwap_dist_gte_0_015', 0)}` | `trix>=0.08` `{bear.get('trix_gte_0_08', 0)}` | combined `bb_width+trix+vwap` `{bear.get('bb_width_trix_vwap_gate', 0)}`"
    )
    lines.append(
        f"- `m1 bullish losers`: `{bull.get('total', 0)}` total | `atr_pct>=0.005` `{bull.get('atr_pct_gte_0_005', 0)}` | `stoch<=5` `{bull.get('stoch_lte_5', 0)}` | `vwap_dist<=-0.01` `{bull.get('vwap_dist_lte_neg0_01', 0)}` | combined `atr+stoch+vwap` `{bull.get('atr_stoch_vwap_gate', 0)}`"
    )
    lines.extend(
        [
            "",
            "## Suggested Adjustment",
            "",
            "- Demote the live `m1` consecutive REV family from the active scanner until a new minute-level contract is revalidated.",
            "- Keep the fast 5-10 minute move work on the dedicated `BURST/MOM` lane instead of forcing burst-style filters into the consecutive REV contract.",
            "- Keep the post-close alert builders disabled after `4:00 PM ET` so the scanners stop once the regular session is over.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    market_date = parse_date(args.date)
    timespans = parse_timespans(args.timespans)
    tickers = parse_tickers(args.tickers, args.universe)
    spec_file = Path(args.spec_file)
    specs = load_specs(spec_file, timespans)
    if not specs:
        raise SystemExit(f"no specs loaded from {spec_file}")

    fields = required_fields(specs)
    available_columns = fetch_available_columns(args, fields)
    selected_fields = [field for field in fields if field in available_columns and field != "ts"]
    rows = fetch_rows(args, selected_fields, tickers, timespans, market_date)
    grouped = group_rows(rows)
    records = build_hit_records(specs, grouped)

    resolved: List[Dict[str, Any]] = []
    unresolved: List[Dict[str, Any]] = []
    for record in records:
        key = (record.ticker, record.timespan)
        scored = score_record(record, grouped.get(key, ()))
        if scored.get("status") == "resolved":
            resolved.append(scored)
        else:
            unresolved.append(scored)

    by_timespan_tone = summarize_by_key(
        [
            {
                "key": f"{item.get('timespan')} {item.get('tone')}",
                "success": item.get("success"),
                "hold_ret": item.get("hold_ret"),
            }
            for item in resolved
        ],
        "key",
    )
    by_spec = summarize_by_key(resolved, "lead_key")
    filter_counts = tighter_filter_counts([item for item in resolved if not item.get("success")])

    out_dir = Path(args.output_dir) / f"intraday_rev_postmortem_{market_date.isoformat()}"
    out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(out_dir / "resolved_hits.csv", resolved)
    write_csv(out_dir / "unresolved_hits.csv", unresolved)
    summary = {
        "date": market_date.isoformat(),
        "spec_file": str(spec_file),
        "timespans": timespans,
        "resolved_count": len(resolved),
        "unresolved_count": len(unresolved),
        "by_timespan_tone": by_timespan_tone,
        "by_spec": by_spec,
        "filter_counts": filter_counts,
    }
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (out_dir / "summary.md").write_text(
        build_markdown(
            market_date=market_date,
            resolved=resolved,
            unresolved=unresolved,
            by_timespan_tone=by_timespan_tone,
            by_spec=by_spec,
            filter_counts=filter_counts,
        ),
        encoding="utf-8",
    )
    print(f"wrote {out_dir}")


if __name__ == "__main__":
    main()
