#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import aiohttp
import numpy as np
import pandas as pd
from dotenv import load_dotenv


def _bootstrap_repo_path() -> Path:
    here = Path(__file__).resolve()
    for candidate in [here.parent, *here.parents]:
        if (candidate / "MODELS").is_dir() and (candidate / "fudstop4").is_dir():
            root = candidate
            break
    else:
        root = here.parents[1]

    root_str = str(root)
    if root_str in sys.path:
        sys.path.remove(root_str)
    sys.path.insert(0, root_str)
    return root


PROJECT_ROOT = _bootstrap_repo_path()

from fudstop4.apis.helpers import generate_webull_headers
from fudstop4.apis._ta.ta_sdk import FudstopTA
from fudstop4.apis.polygonio.polygon_options import PolygonOptions
from fudstop4.apis.webull.webull_trading import WebullTrading
from fudstop4._markets.list_sets.ticker_lists import most_active_tickers

from scripts.ca_indicator_enrich import _add_macd_curvature_features
from scripts.ca_live_ingest import (
    DB_BATCH_SIZE,
    ET,
    REQUEST_TIMEOUT_S,
    _cast_text_cols,
    _get_json_with_retries,
    _parse_webull_rows,
    _poll_interval_for_timespan,
    _restore_ts_text,
    _seed_count_for_timespan,
    _timespan_to_seconds,
    add_all_ta_indicators,
    compute_local_metrics,
    ensure_table_has_columns,
    _ensure_ts_datetime_for_ta,
)


QUERY_MINI_URL = "https://quotes-gw.webullfintech.com/api/quote/charts/query-mini"


def _parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(
        description="Historical m1 backfill for public.ca with full indicator enrichment."
    )
    ap.add_argument("--schema", default=os.getenv("CA_BACKFILL_SCHEMA", "public"))
    ap.add_argument("--table", default=os.getenv("CA_BACKFILL_TABLE", "ca"))
    ap.add_argument("--timespan", default=os.getenv("CA_BACKFILL_TIMESPAN", "m1"))
    ap.add_argument("--start-date", default=os.getenv("CA_BACKFILL_START_DATE", "2025-12-01"))
    ap.add_argument("--end-ts", type=int, default=int(os.getenv("CA_BACKFILL_END_TS", "0") or "0"))
    ap.add_argument("--warmup-bars", type=int, default=int(os.getenv("CA_BACKFILL_WARMUP_BARS", "600")))
    ap.add_argument("--page-count", type=int, default=int(os.getenv("CA_BACKFILL_PAGE_COUNT", "1000")))
    ap.add_argument("--max-pages-per-ticker", type=int, default=int(os.getenv("CA_BACKFILL_MAX_PAGES", "0")))
    ap.add_argument("--extend-trading", type=int, choices=[0, 1], default=int(os.getenv("CA_BACKFILL_EXTEND_TRADING", "1")))
    ap.add_argument("--concurrency", type=int, default=int(os.getenv("CA_BACKFILL_CONCURRENCY", "4")))
    ap.add_argument("--batch-size", type=int, default=int(os.getenv("CA_BACKFILL_BATCH_SIZE", str(DB_BATCH_SIZE))))
    ap.add_argument("--use-most-active", action="store_true")
    ap.add_argument("--tickers", default=os.getenv("CA_BACKFILL_TICKERS", ""))
    ap.add_argument("--max-tickers", type=int, default=int(os.getenv("CA_BACKFILL_MAX_TICKERS", "0")))
    ap.add_argument("--artifacts-dir", default=os.getenv("CA_BACKFILL_ARTIFACTS_DIR", ""))
    ap.add_argument("--write", action="store_true")
    return ap.parse_args()


def _parse_tickers(raw: str) -> List[str]:
    return [t.strip().upper() for t in str(raw or "").split(",") if t.strip()]


def _date_to_epoch(date_value: str) -> int:
    dt = datetime.fromisoformat(str(date_value))
    localized = dt.replace(tzinfo=ET)
    return int(localized.timestamp())


def _epoch_to_et_string(epoch_value: int) -> str:
    return datetime.fromtimestamp(int(epoch_value), tz=ET).strftime("%Y-%m-%d %H:%M:%S %Z")


def _artifact_dir(args: argparse.Namespace) -> Path:
    if args.artifacts_dir:
        return Path(args.artifacts_dir)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return (
        PROJECT_ROOT
        / "runs"
        / "ca_historical_reversal_research"
        / f"automation_2026-04-10_m1_backfill_{stamp}"
    )


def _headers_factory(access_token: str):
    return lambda: generate_webull_headers(access_token=access_token)


def _query_mini_url(*, ticker_id: int, timespan: str, count: int, anchor_ts: int, extend_trading: int) -> str:
    return (
        f"{QUERY_MINI_URL}"
        f"?type={timespan}"
        f"&count={int(count)}"
        f"&timestamp={int(anchor_ts)}"
        f"&restorationType=1"
        f"&tickerId={int(ticker_id)}"
        f"&hasMore=true"
        f"&loadFactor=1"
        f"&extendTrading={int(extend_trading)}"
    )


@dataclass
class BackfillResult:
    ticker: str
    ticker_id: int
    request_pages: int
    fetched_rows: int
    written_rows: int
    min_ts: Optional[int]
    max_ts: Optional[int]
    status: str
    error: str = ""


async def _fetch_ticker_rows(
    session: aiohttp.ClientSession,
    *,
    ticker: str,
    ticker_id: int,
    timespan: str,
    start_ts: int,
    end_ts: int,
    page_count: int,
    max_pages_per_ticker: int,
    extend_trading: int,
    access_token: str,
) -> pd.DataFrame:
    anchor_ts = int(end_ts)
    frames: List[pd.DataFrame] = []
    pages = 0
    last_oldest = None
    headers_factory = _headers_factory(access_token)

    while True:
        pages += 1
        payload = await _get_json_with_retries(
            session,
            _query_mini_url(
                ticker_id=ticker_id,
                timespan=timespan,
                count=page_count,
                anchor_ts=anchor_ts,
                extend_trading=extend_trading,
            ),
            headers_factory=headers_factory,
        )
        rows = payload[0].get("data") if isinstance(payload, list) and payload and isinstance(payload[0], dict) else []
        if not rows:
            break

        df_page = _parse_webull_rows(rows, ticker=ticker, ticker_id=ticker_id, timespan=timespan)
        if df_page.empty:
            break

        ts_num = pd.to_numeric(df_page["ts"], errors="coerce").fillna(0).astype("int64")
        oldest = int(ts_num.min())
        newest = int(ts_num.max())

        df_page = df_page[(ts_num >= start_ts) & (ts_num <= end_ts)].copy()
        if not df_page.empty:
            frames.append(df_page)

        if oldest <= start_ts:
            break
        if last_oldest is not None and oldest >= last_oldest:
            break
        if max_pages_per_ticker > 0 and pages >= max_pages_per_ticker:
            break
        if newest <= start_ts:
            break

        last_oldest = oldest
        anchor_ts = oldest - 60

    if not frames:
        return pd.DataFrame()

    df = pd.concat(frames, ignore_index=True, copy=False)
    df = df.drop_duplicates(subset=["ts"], keep="last")
    df["ts"] = pd.to_numeric(df["ts"], errors="coerce").astype("int64")
    df = df[(df["ts"] >= start_ts) & (df["ts"] <= end_ts)].copy()
    df = df.sort_values("ts", kind="mergesort").reset_index(drop=True)
    return df


def _finalize_for_ca(df: pd.DataFrame, *, table_columns: Iterable[str]) -> pd.DataFrame:
    out = df.copy()
    out = _add_macd_curvature_features(out)
    out["insertion_timestamp"] = datetime.now()
    if "gap_status" in out.columns:
        out["gap_status"] = out["gap_status"].fillna("")

    bool_columns = [
        "is_gap",
        "gap_filled",
        "gap_unfilled",
        "is_inside_bar",
        "macd_cross_up",
        "macd_cross_dn",
        "macd_imminent_bull",
        "macd_imminent_bear",
        "bb_close_outside_lower",
        "bb_close_outside_upper",
        "candle_completely_below_lower",
        "candle_completely_above_upper",
        "vwap_cross_up",
        "vwap_cross_dn",
        "tsi_cross_up",
        "tsi_cross_dn",
        "trend_regime",
        "volume_confirm",
        "squeeze_on",
        "squeeze_off",
        "candle_green",
        "candle_red",
        "adx_strong",
        "di_bull",
        "di_bear",
        "macd_bull",
        "macd_bear",
        "tsi_bull",
        "tsi_bear",
        "momentum_confirm_bull",
        "momentum_confirm_bear",
        "ema_stack_bull",
        "ema_stack_bear",
    ]
    for col in bool_columns:
        if col in out.columns:
            out[col] = out[col].fillna(False).astype(bool)

    out = _cast_text_cols(
        out,
        cols=[
            "ts",
            "prev_ts",
            "ticker",
            "timespan",
            "candle_color",
            "gap_dir",
            "gap_status",
            "date_et",
            "time_et",
            "session",
            "delta_s",
            "missing_intervals",
            "is_time_gap",
        ],
    )

    keep_cols = [c for c in table_columns if c in out.columns]
    return out[keep_cols].copy()


async def _process_ticker(
    session: aiohttp.ClientSession,
    db: PolygonOptions,
    *,
    ticker: str,
    ticker_id: int,
    args: argparse.Namespace,
    start_ts: int,
    end_ts: int,
    warmup_start_ts: int,
    table_columns: List[str],
    ta: FudstopTA,
) -> BackfillResult:
    try:
        raw = await _fetch_ticker_rows(
            session,
            ticker=ticker,
            ticker_id=ticker_id,
            timespan=args.timespan,
            start_ts=warmup_start_ts,
            end_ts=end_ts,
            page_count=min(int(args.page_count), 1000),
            max_pages_per_ticker=int(args.max_pages_per_ticker),
            extend_trading=int(args.extend_trading),
            access_token=os.environ["ACCESS_TOKEN"],
        )
        if raw.empty:
            return BackfillResult(
                ticker=ticker,
                ticker_id=ticker_id,
                request_pages=0,
                fetched_rows=0,
                written_rows=0,
                min_ts=None,
                max_ts=None,
                status="no_rows",
            )

        request_pages = int(np.ceil(len(raw) / max(1, min(int(args.page_count), 1000))))
        raw = raw.sort_values("ts", kind="mergesort").reset_index(drop=True)

        interval_s = _timespan_to_seconds(args.timespan)
        enriched = compute_local_metrics(raw, interval_s=interval_s)
        enriched = _ensure_ts_datetime_for_ta(enriched)
        enriched = add_all_ta_indicators(enriched, ta=ta)
        enriched = _restore_ts_text(enriched)
        enriched["timespan"] = args.timespan

        ts_num = pd.to_numeric(enriched["ts"], errors="coerce").astype("int64")
        enriched = enriched[(ts_num >= start_ts) & (ts_num <= end_ts)].copy()
        if enriched.empty:
            return BackfillResult(
                ticker=ticker,
                ticker_id=ticker_id,
                request_pages=request_pages,
                fetched_rows=int(len(raw)),
                written_rows=0,
                min_ts=None,
                max_ts=None,
                status="warmup_only",
            )

        out = _finalize_for_ca(enriched, table_columns=table_columns)
        if out.empty:
            return BackfillResult(
                ticker=ticker,
                ticker_id=ticker_id,
                request_pages=request_pages,
                fetched_rows=int(len(raw)),
                written_rows=0,
                min_ts=None,
                max_ts=None,
                status="no_output",
            )

        if args.write:
            await ensure_table_has_columns(db, args.table, out)
            await db.batch_upsert_dataframe(
                out,
                table_name=args.table,
                unique_columns=["ticker", "timespan", "ts"],
                batch_size=int(args.batch_size),
                on_conflict_update=True,
            )

        min_ts = int(pd.to_numeric(out["ts"], errors="coerce").min())
        max_ts = int(pd.to_numeric(out["ts"], errors="coerce").max())
        return BackfillResult(
            ticker=ticker,
            ticker_id=ticker_id,
            request_pages=request_pages,
            fetched_rows=int(len(raw)),
            written_rows=int(len(out)),
            min_ts=min_ts,
            max_ts=max_ts,
            status="ok",
        )
    except Exception as exc:
        return BackfillResult(
            ticker=ticker,
            ticker_id=ticker_id,
            request_pages=0,
            fetched_rows=0,
            written_rows=0,
            min_ts=None,
            max_ts=None,
            status="error",
            error=repr(exc),
        )


async def main() -> None:
    args = _parse_args()
    load_dotenv(PROJECT_ROOT / ".env")

    access_token = os.environ.get("ACCESS_TOKEN")
    if not access_token:
        raise RuntimeError("ACCESS_TOKEN missing")

    end_ts = int(args.end_ts or time.time())
    start_ts = _date_to_epoch(args.start_date)
    warmup_start_ts = start_ts - int(args.warmup_bars) * _timespan_to_seconds(args.timespan)
    artifacts_dir = _artifact_dir(args)
    artifacts_dir.mkdir(parents=True, exist_ok=True)

    tickers = _parse_tickers(args.tickers)
    if args.use_most_active or not tickers:
        tickers = list(most_active_tickers)
    if args.max_tickers and args.max_tickers > 0:
        tickers = tickers[: int(args.max_tickers)]

    trading = WebullTrading()
    ticker_to_id = getattr(trading, "ticker_to_id_map", {}) or {}
    resolved: List[tuple[str, int]] = []
    unresolved: List[str] = []
    for ticker in tickers:
        ticker_id = ticker_to_id.get(ticker)
        if ticker_id:
            resolved.append((ticker, int(ticker_id)))
        else:
            unresolved.append(ticker)

    db = PolygonOptions()
    await db.connect()
    table_columns = await db.get_table_columns(args.table)

    timeout = aiohttp.ClientTimeout(total=REQUEST_TIMEOUT_S)
    connector = aiohttp.TCPConnector(
        limit=max(20, int(args.concurrency) * 4),
        limit_per_host=max(10, int(args.concurrency) * 2),
        ttl_dns_cache=300,
        enable_cleanup_closed=True,
    )

    results: List[BackfillResult] = []
    sem = asyncio.Semaphore(max(1, int(args.concurrency)))
    ta = FudstopTA()

    async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:
        async def run_one(ticker: str, ticker_id: int) -> None:
            async with sem:
                result = await _process_ticker(
                    session,
                    db,
                    ticker=ticker,
                    ticker_id=ticker_id,
                    args=args,
                    start_ts=start_ts,
                    end_ts=end_ts,
                    warmup_start_ts=warmup_start_ts,
                    table_columns=table_columns,
                    ta=ta,
                )
                results.append(result)
                print(
                    f"[{result.status}] {ticker} rows={result.written_rows} "
                    f"pages={result.request_pages} err={result.error[:120]}"
                )

        await asyncio.gather(*[run_one(ticker, ticker_id) for ticker, ticker_id in resolved])

    await db.disconnect()

    rows = [asdict(r) for r in sorted(results, key=lambda item: item.ticker)]
    pd.DataFrame(rows).to_csv(artifacts_dir / "ticker_results.csv", index=False)

    summary = {
        "run_time_et": datetime.now(tz=ET).strftime("%Y-%m-%d %H:%M:%S %Z"),
        "table": args.table,
        "timespan": args.timespan,
        "start_ts": start_ts,
        "start_et": _epoch_to_et_string(start_ts),
        "end_ts": end_ts,
        "end_et": _epoch_to_et_string(end_ts),
        "warmup_start_ts": warmup_start_ts,
        "warmup_start_et": _epoch_to_et_string(warmup_start_ts),
        "extend_trading": int(args.extend_trading),
        "write": bool(args.write),
        "requested_tickers": len(tickers),
        "resolved_tickers": len(resolved),
        "unresolved_tickers": unresolved,
        "ok_tickers": sum(1 for r in results if r.status == "ok"),
        "error_tickers": [r.ticker for r in results if r.status == "error"],
        "total_written_rows": int(sum(r.written_rows for r in results)),
        "total_fetched_rows": int(sum(r.fetched_rows for r in results)),
        "results_csv": str(artifacts_dir / "ticker_results.csv"),
    }
    (artifacts_dir / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (artifacts_dir / "summary.md").write_text(
        "\n".join(
            [
                "# m1 Historical Backfill",
                "",
                f"- Run time: {summary['run_time_et']}",
                f"- Table: `{args.table}`",
                f"- Window: `{summary['start_et']}` through `{summary['end_et']}`",
                f"- Warmup start: `{summary['warmup_start_et']}`",
                f"- Extend trading: `{int(args.extend_trading)}`",
                f"- Requested tickers: `{summary['requested_tickers']}`",
                f"- Resolved tickers: `{summary['resolved_tickers']}`",
                f"- OK tickers: `{summary['ok_tickers']}`",
                f"- Total written rows: `{summary['total_written_rows']}`",
                f"- Total fetched rows: `{summary['total_fetched_rows']}`",
                f"- Unresolved tickers: `{', '.join(unresolved) if unresolved else 'none'}`",
                f"- Error tickers: `{', '.join(summary['error_tickers']) if summary['error_tickers'] else 'none'}`",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
