#!/usr/bin/env python3
from __future__ import annotations

import argparse
import io
import itertools
import json
import os
import subprocess
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Sequence
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from fudstop4._markets.list_sets.ticker_lists import most_active_tickers


DEFAULT_PSQL_PATH = r"C:\Program Files\PostgreSQL\17\bin\psql.exe"
DEFAULT_TIMESPANS = ("m1", "m5", "m15", "m30")
MARKET_TZ = ZoneInfo("America/New_York")
ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class ConditionSpec:
    label: str
    fn: Callable[[pd.DataFrame], pd.Series]


def _load_env_defaults() -> Dict[str, str]:
    env_path = ROOT / "stock_market_site" / "app" / ".env"
    values: Dict[str, str] = {}
    if not env_path.exists():
        return values
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


ENV_DEFAULTS = _load_env_defaults()


def _env_default(key: str, fallback: str) -> str:
    repo_value = str(ENV_DEFAULTS.get(key) or "").strip()
    if repo_value:
        return repo_value
    env_value = str(os.environ.get(key) or "").strip()
    if key == "DB_NAME" and env_value.lower() == "database":
        return fallback
    return env_value or fallback


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Scan ca for condition combinations on the bar immediately before a "
            "7+/8+ same-color momentum burst."
        ),
    )
    parser.add_argument("--host", default=_env_default("DB_HOST", "localhost"))
    parser.add_argument("--port", type=int, default=int(_env_default("DB_PORT", "5432")))
    parser.add_argument("--user", default=_env_default("DB_USER", "chuck"))
    parser.add_argument("--password", default=_env_default("DB_PASSWORD", "fud"))
    parser.add_argument("--database", default=_env_default("DB_NAME", "fudstop3"))
    parser.add_argument("--psql-path", default=_env_default("PSQL_PATH", DEFAULT_PSQL_PATH))
    parser.add_argument("--start-date", default="2025-12-01")
    parser.add_argument("--end-date", default="2026-03-26")
    parser.add_argument("--timespans", default=",".join(DEFAULT_TIMESPANS))
    parser.add_argument("--min-run-length", type=int, default=8)
    parser.add_argument("--min-n", type=int, default=15)
    parser.add_argument("--hit-threshold", type=float, default=0.85)
    parser.add_argument("--max-k", type=int, default=4)
    parser.add_argument(
        "--sides",
        default="bull,bear",
        help="Comma-separated sides to scan: bull, bear.",
    )
    parser.add_argument(
        "--signal-mode",
        default="pre_run",
        choices=("pre_run", "run_start", "in_burst"),
        help="Whether the signal is the bar before the burst, the first burst bar itself, or a bar inside the burst.",
    )
    parser.add_argument(
        "--base-conditions",
        default="",
        help="Comma-separated condition labels to anchor an extension scan on.",
    )
    parser.add_argument(
        "--max-extra-k",
        type=int,
        default=2,
        help="Maximum number of extra conditions to add on top of --base-conditions.",
    )
    parser.add_argument(
        "--seed-label",
        default="",
        help="Optional short label for an anchored extension scan.",
    )
    parser.add_argument("--output-dir", default="runs/ca_historical_reversal_research")
    return parser.parse_args()


def _parse_timespans(raw: str) -> List[str]:
    values = [value.strip().lower() for value in str(raw or "").split(",") if value.strip()]
    return values or list(DEFAULT_TIMESPANS)


def _parse_sides(raw: str) -> List[str]:
    values = [value.strip().lower() for value in str(raw or "").split(",") if value.strip()]
    ordered = [side for side in ("bull", "bear") if side in values]
    return ordered or ["bull", "bear"]


def _parse_condition_labels(raw: str) -> List[str]:
    return [value.strip() for value in str(raw or "").split(",") if value.strip()]


def _timespan_slug(timespans: Sequence[str]) -> str:
    cleaned = [str(value).strip().lower() for value in timespans if str(value).strip()]
    return "_".join(cleaned) if cleaned else "all"


def _slugify(value: str) -> str:
    cleaned = "".join(ch.lower() if ch.isalnum() else "_" for ch in str(value or "").strip())
    while "__" in cleaned:
        cleaned = cleaned.replace("__", "_")
    return cleaned.strip("_") or "scan"


def _sql_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _date_to_epoch_bounds(start_date: str, end_date: str) -> tuple[int, int]:
    start_day = date.fromisoformat(start_date)
    end_day = date.fromisoformat(end_date) + timedelta(days=1)
    start_dt = datetime.combine(start_day, time.min, tzinfo=MARKET_TZ)
    end_dt = datetime.combine(end_day, time.min, tzinfo=MARKET_TZ)
    return int(start_dt.timestamp()), int(end_dt.timestamp())


def _build_query(
    *,
    start_epoch: int,
    end_epoch: int,
    timespans: Sequence[str],
    tickers: Sequence[str],
) -> str:
    quoted_timespans = ", ".join(_sql_quote(value) for value in timespans)
    quoted_tickers = ", ".join(_sql_quote(value.upper()) for value in tickers)
    return f"""
SELECT
    UPPER(BTRIM(ticker)) AS ticker,
    LOWER(COALESCE(timespan, '')) AS timespan,
    ts::bigint AS ts_epoch,
    to_timestamp(ts::bigint) AT TIME ZONE 'America/New_York' AS ts_et,
    o,
    c,
    h,
    l,
    v,
    candle_green,
    candle_red,
    body_pct,
    hl_range_pct,
    upper_wick,
    lower_wick,
    rsi,
    td_buy_count,
    td_sell_count,
    macd_hist,
    bb_width,
    bb_close_outside_lower,
    bb_close_outside_upper,
    candle_completely_below_lower,
    candle_completely_above_upper,
    rvol,
    atr_pct,
    chop,
    vwap_dist_pct,
    stoch_rsi_k,
    stoch_rsi_d,
    mfi,
    cmo,
    roc,
    trix,
    ultimate_osc,
    trend_regime,
    volume_confirm,
    squeeze_off,
    vwap_cross_up,
    vwap_cross_dn,
    adx,
    adx_strong
FROM ca
WHERE LOWER(COALESCE(timespan, '')) IN ({quoted_timespans})
  AND ts::bigint >= {int(start_epoch)}
  AND ts::bigint < {int(end_epoch)}
  AND bb_width IS NOT NULL
  AND macd_hist IS NOT NULL
  AND rsi IS NOT NULL
  AND td_buy_count IS NOT NULL
  AND td_sell_count IS NOT NULL
  AND UPPER(BTRIM(ticker)) IN ({quoted_tickers})
ORDER BY LOWER(COALESCE(timespan, '')), UPPER(BTRIM(ticker)), ts::bigint
""".strip()


def _run_copy_query(
    *,
    psql_path: str,
    host: str,
    port: int,
    user: str,
    password: str,
    database: str,
    query: str,
) -> pd.DataFrame:
    cmd = [
        psql_path,
        "-h",
        host,
        "-p",
        str(port),
        "-U",
        user,
        "-d",
        database,
        "-v",
        "ON_ERROR_STOP=1",
        "-c",
        f"\\copy ({query}) TO STDOUT WITH CSV HEADER",
    ]
    env = os.environ.copy()
    env["PGPASSWORD"] = password
    result = subprocess.run(
        cmd,
        check=True,
        capture_output=True,
        text=True,
        env=env,
    )
    return pd.read_csv(io.StringIO(result.stdout))


def _coerce_frame(df: pd.DataFrame) -> pd.DataFrame:
    bool_cols = [
        "candle_green",
        "candle_red",
        "bb_close_outside_lower",
        "bb_close_outside_upper",
        "candle_completely_below_lower",
        "candle_completely_above_upper",
        "trend_regime",
        "volume_confirm",
        "squeeze_off",
        "vwap_cross_up",
        "vwap_cross_dn",
        "adx_strong",
    ]
    num_cols = [
        "ts_epoch",
        "o",
        "c",
        "h",
        "l",
        "v",
        "body_pct",
        "hl_range_pct",
        "upper_wick",
        "lower_wick",
        "rsi",
        "td_buy_count",
        "td_sell_count",
        "macd_hist",
        "bb_width",
        "rvol",
        "atr_pct",
        "chop",
        "vwap_dist_pct",
        "stoch_rsi_k",
        "stoch_rsi_d",
        "mfi",
        "cmo",
        "roc",
        "trix",
        "ultimate_osc",
        "adx",
    ]
    for col in num_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    for col in bool_cols:
        df[col] = (
            df[col]
            .astype(str)
            .str.strip()
            .str.lower()
            .isin({"t", "true", "1", "y", "yes"})
        )
    df["ticker"] = df["ticker"].astype(str).str.upper().str.strip()
    df["timespan"] = df["timespan"].astype(str).str.lower().str.strip()
    df = df.sort_values(["timespan", "ticker", "ts_epoch"]).reset_index(drop=True)
    return df


def _derive_macd_state(macd_hist: np.ndarray) -> np.ndarray:
    n = len(macd_hist)
    out = np.zeros(n, dtype=np.int8)
    for idx in range(3, n):
        lag3 = macd_hist[idx - 3]
        lag2 = macd_hist[idx - 2]
        lag1 = macd_hist[idx - 1]
        cur = macd_hist[idx]
        if not np.isfinite(lag3) or not np.isfinite(lag2) or not np.isfinite(lag1) or not np.isfinite(cur):
            continue
        diffs = np.array([lag2 - lag3, lag1 - lag2, cur - lag1], dtype=float)
        avg_abs = (np.abs(diffs).sum() / 3.0) + 1e-9
        cur_delta = cur - lag1
        if abs(cur) < (avg_abs * 0.5) and abs(cur_delta) < (avg_abs * 0.2):
            out[idx] = 7 if cur < 0 else 8
        elif cur > 0 and cur_delta > (avg_abs * 0.8):
            out[idx] = 1
        elif cur < 0 and cur_delta < -(avg_abs * 0.8):
            out[idx] = 2
        elif cur > 0 and cur_delta < -(avg_abs * 0.8):
            out[idx] = 3
        elif cur < 0 and cur_delta > (avg_abs * 0.8):
            out[idx] = 4
        elif cur > 0:
            out[idx] = 5
        else:
            out[idx] = 6
    return out


def _rolling_color_counts(colors: np.ndarray, target: int, window: int) -> np.ndarray:
    vals = (colors == target).astype(np.int16)
    out = np.zeros(len(colors), dtype=np.int16)
    running = 0
    for idx, value in enumerate(vals):
        running += int(value)
        if idx >= window:
            running -= int(vals[idx - window])
        out[idx] = running
    return out


def _compute_signal_frame(df: pd.DataFrame, min_run_length: int, signal_mode: str) -> pd.DataFrame:
    signal_rows: List[pd.DataFrame] = []
    for (_, _), group in df.groupby(["timespan", "ticker"], sort=False):
        if len(group) <= min_run_length:
            continue
        local = group.copy()
        colors = np.zeros(len(local), dtype=np.int8)
        colors[local["candle_green"].to_numpy(dtype=bool)] = 1
        colors[local["candle_red"].to_numpy(dtype=bool)] = -1

        run_len = np.zeros(len(local), dtype=np.int16)
        if colors[-1] != 0:
            run_len[-1] = 1
        for idx in range(len(local) - 2, -1, -1):
            if colors[idx] != 0 and colors[idx] == colors[idx + 1]:
                run_len[idx] = np.int16(run_len[idx + 1] + 1)
            elif colors[idx] != 0:
                run_len[idx] = 1

        green_streak = np.zeros(len(local), dtype=np.int16)
        red_streak = np.zeros(len(local), dtype=np.int16)
        up_close_streak = np.zeros(len(local), dtype=np.int16)
        down_close_streak = np.zeros(len(local), dtype=np.int16)
        close_vals = local["c"].to_numpy(dtype=float)
        for idx in range(len(local)):
            if colors[idx] == 1:
                green_streak[idx] = np.int16((green_streak[idx - 1] if idx else 0) + 1)
            if colors[idx] == -1:
                red_streak[idx] = np.int16((red_streak[idx - 1] if idx else 0) + 1)
            if idx == 0 or not np.isfinite(close_vals[idx]) or not np.isfinite(close_vals[idx - 1]):
                continue
            if close_vals[idx] > close_vals[idx - 1]:
                up_close_streak[idx] = np.int16((up_close_streak[idx - 1] if idx else 0) + 1)
            elif close_vals[idx] < close_vals[idx - 1]:
                down_close_streak[idx] = np.int16((down_close_streak[idx - 1] if idx else 0) + 1)

        macd_state = _derive_macd_state(local["macd_hist"].to_numpy(dtype=float))
        prev5_red_count = _rolling_color_counts(colors, -1, 5)
        prev5_green_count = _rolling_color_counts(colors, 1, 5)

        high_vals = local["h"].to_numpy(dtype=float)
        low_vals = local["l"].to_numpy(dtype=float)
        range_vals = high_vals - low_vals
        close_pos = np.full(len(local), 0.5, dtype=float)
        valid_range_mask = np.isfinite(range_vals) & (range_vals > 0)
        np.divide(
            close_vals - low_vals,
            range_vals,
            out=close_pos,
            where=valid_range_mask,
        )
        close_pos = np.clip(close_pos, 0.0, 1.0)

        valid_mask = np.zeros(len(local), dtype=bool)
        bull_success = np.zeros(len(local), dtype=bool)
        bear_success = np.zeros(len(local), dtype=bool)
        bull_best_ret = np.full(len(local), np.nan, dtype=float)
        bear_best_ret = np.full(len(local), np.nan, dtype=float)
        bull_run_len = np.zeros(len(local), dtype=np.int16)
        bear_run_len = np.zeros(len(local), dtype=np.int16)

        for idx in range(len(local)):
            if signal_mode == "pre_run":
                start_idx = idx + 1
                end_idx = start_idx + min_run_length
            elif signal_mode == "run_start":
                start_idx = idx + 1
                end_idx = idx + min_run_length
            else:
                current_green = int(green_streak[idx])
                current_red = int(red_streak[idx])
                needed = 0
                if colors[idx] == 1 and 0 < current_green < min_run_length:
                    needed = min_run_length - current_green
                elif colors[idx] == -1 and 0 < current_red < min_run_length:
                    needed = min_run_length - current_red
                if needed <= 0:
                    continue
                start_idx = idx + 1
                end_idx = idx + 1 + needed
            if end_idx > len(local):
                continue
            if not np.isfinite(close_vals[idx]) or close_vals[idx] == 0:
                continue
            valid_mask[idx] = True
            future_high = np.nanmax(high_vals[start_idx:end_idx])
            future_low = np.nanmin(low_vals[start_idx:end_idx])
            if np.isfinite(future_high):
                bull_best_ret[idx] = (future_high / close_vals[idx]) - 1.0
            if np.isfinite(future_low) and future_low != 0:
                bear_best_ret[idx] = (close_vals[idx] / future_low) - 1.0
            if signal_mode == "pre_run":
                next_idx = idx + 1
                if colors[next_idx] == 1 and run_len[next_idx] >= min_run_length:
                    bull_success[idx] = True
                    bull_run_len[idx] = run_len[next_idx]
                if colors[next_idx] == -1 and run_len[next_idx] >= min_run_length:
                    bear_success[idx] = True
                    bear_run_len[idx] = run_len[next_idx]
            elif signal_mode == "run_start":
                if colors[idx] == 1 and run_len[idx] >= min_run_length:
                    bull_success[idx] = True
                    bull_run_len[idx] = run_len[idx]
                if colors[idx] == -1 and run_len[idx] >= min_run_length:
                    bear_success[idx] = True
                    bear_run_len[idx] = run_len[idx]
            else:
                current_green = int(green_streak[idx])
                current_red = int(red_streak[idx])
                if colors[idx] == 1 and 0 < current_green < min_run_length:
                    required_remaining = min_run_length - current_green + 1
                    if run_len[idx] >= required_remaining:
                        bull_success[idx] = True
                        bull_run_len[idx] = run_len[idx] + current_green - 1
                if colors[idx] == -1 and 0 < current_red < min_run_length:
                    required_remaining = min_run_length - current_red + 1
                    if run_len[idx] >= required_remaining:
                        bear_success[idx] = True
                        bear_run_len[idx] = run_len[idx] + current_red - 1

        local["pre_close_pos"] = close_pos
        local["pre_red_streak"] = red_streak
        local["pre_green_streak"] = green_streak
        local["pre_down_close_streak"] = down_close_streak
        local["pre_up_close_streak"] = up_close_streak
        local["pre_prev5_red_count"] = prev5_red_count
        local["pre_prev5_green_count"] = prev5_green_count
        local["pre_macd_state_code"] = macd_state
        local["valid_signal_row"] = valid_mask
        local["bull_success"] = bull_success
        local["bear_success"] = bear_success
        local["bull_best_ret"] = bull_best_ret
        local["bear_best_ret"] = bear_best_ret
        local["bull_run_len"] = bull_run_len
        local["bear_run_len"] = bear_run_len
        signal_rows.append(local.loc[local["valid_signal_row"]].copy())

    if not signal_rows:
        return df.iloc[0:0].copy()

    out = pd.concat(signal_rows, ignore_index=True)
    out["pre_body_pct"] = pd.to_numeric(out["body_pct"], errors="coerce")
    out["pre_candle_red"] = out["candle_red"].fillna(False).astype(bool)
    out["pre_candle_green"] = out["candle_green"].fillna(False).astype(bool)
    out["pre_bb_close_outside_lower"] = out["bb_close_outside_lower"].fillna(False).astype(bool)
    out["pre_bb_close_outside_upper"] = out["bb_close_outside_upper"].fillna(False).astype(bool)
    out["pre_candle_completely_below_lower"] = out["candle_completely_below_lower"].fillna(False).astype(bool)
    out["pre_candle_completely_above_upper"] = out["candle_completely_above_upper"].fillna(False).astype(bool)
    out["pre_volume_confirm"] = out["volume_confirm"].fillna(False).astype(bool)
    out["pre_trend_regime"] = out["trend_regime"].fillna(False).astype(bool)
    out["pre_squeeze_off"] = out["squeeze_off"].fillna(False).astype(bool)
    out["pre_vwap_cross_up"] = out["vwap_cross_up"].fillna(False).astype(bool)
    out["pre_vwap_cross_dn"] = out["vwap_cross_dn"].fillna(False).astype(bool)
    out["pre_adx_strong"] = out["adx_strong"].fillna(False).astype(bool)
    return out


def _bool_condition(label: str, column: str) -> ConditionSpec:
    return ConditionSpec(label, lambda df, col=column: df[col].fillna(False).astype(bool))


def _ge_condition(label: str, column: str, threshold: float) -> ConditionSpec:
    return ConditionSpec(label, lambda df, col=column, thr=threshold: pd.to_numeric(df[col], errors="coerce") >= thr)


def _le_condition(label: str, column: str, threshold: float) -> ConditionSpec:
    return ConditionSpec(label, lambda df, col=column, thr=threshold: pd.to_numeric(df[col], errors="coerce") <= thr)


def _eq_condition(label: str, column: str, value: int) -> ConditionSpec:
    return ConditionSpec(label, lambda df, col=column, val=value: pd.to_numeric(df[col], errors="coerce").fillna(0).astype(int) == val)


def _build_condition_specs(
    side: str,
    signal_mode: str,
    *,
    include_exact_run_labels: bool = False,
) -> List[ConditionSpec]:
    common = [
        _ge_condition("pre_body_pct>=0.03", "pre_body_pct", 0.03),
        _ge_condition("pre_body_pct>=0.05", "pre_body_pct", 0.05),
        _ge_condition("pre_bb_width>=0.05", "bb_width", 0.05),
        _ge_condition("pre_atr_pct>=0.006", "atr_pct", 0.006),
        _ge_condition("pre_rvol>=1.5", "rvol", 1.5),
        _le_condition("pre_chop<=45", "chop", 45.0),
        _ge_condition("pre_adx>=25", "adx", 25.0),
        _bool_condition("pre_volume_confirm", "pre_volume_confirm"),
        _bool_condition("pre_squeeze_off", "pre_squeeze_off"),
        _bool_condition("pre_trend_regime", "pre_trend_regime"),
    ]
    if signal_mode == "in_burst":
        if side == "bull":
            side_specs = [
                _bool_condition("pre_candle_green", "pre_candle_green"),
                _ge_condition("pre_close_pos>=0.65", "pre_close_pos", 0.65),
                _ge_condition("pre_close_pos>=0.80", "pre_close_pos", 0.80),
                _ge_condition("pre_rsi>=70", "rsi", 70.0),
                _ge_condition("pre_rsi>=75", "rsi", 75.0),
                _ge_condition("pre_td_sell>=8", "td_sell_count", 8.0),
                _ge_condition("pre_td_sell>=10", "td_sell_count", 10.0),
                _ge_condition("pre_green_streak>=2", "pre_green_streak", 2),
                _ge_condition("pre_green_streak>=3", "pre_green_streak", 3),
                _ge_condition("pre_green_streak>=4", "pre_green_streak", 4),
                _ge_condition("pre_green_streak>=5", "pre_green_streak", 5),
                _ge_condition("pre_green_streak>=6", "pre_green_streak", 6),
                _ge_condition("pre_green_streak>=7", "pre_green_streak", 7),
                _ge_condition("pre_up_close_streak>=2", "pre_up_close_streak", 2),
                _ge_condition("pre_prev5_green_count>=4", "pre_prev5_green_count", 4),
                _eq_condition("pre_state=diverging_bull", "pre_macd_state_code", 1),
                _eq_condition("pre_state=arching_bull", "pre_macd_state_code", 3),
                _eq_condition("pre_state=converging_bull", "pre_macd_state_code", 5),
                _ge_condition("pre_vwap_dist>=0.01", "vwap_dist_pct", 0.01),
                _ge_condition("pre_stoch_rsi_k>=80", "stoch_rsi_k", 80.0),
                _ge_condition("pre_mfi>=80", "mfi", 80.0),
                _ge_condition("pre_cmo>=40", "cmo", 40.0),
                _ge_condition("pre_trix>=0.05", "trix", 0.05),
                _ge_condition("pre_ultimate_osc>=70", "ultimate_osc", 70.0),
                _bool_condition("pre_bb_close_outside_upper", "pre_bb_close_outside_upper"),
                _bool_condition("pre_candle_completely_above_upper", "pre_candle_completely_above_upper"),
                _bool_condition("pre_vwap_cross_up", "pre_vwap_cross_up"),
            ]
            if include_exact_run_labels:
                side_specs.extend(
                    [
                        _eq_condition("pre_green_streak=5", "pre_green_streak", 5),
                        _eq_condition("pre_green_streak=6", "pre_green_streak", 6),
                        _eq_condition("pre_green_streak=7", "pre_green_streak", 7),
                    ]
                )
        else:
            side_specs = [
                _bool_condition("pre_candle_red", "pre_candle_red"),
                _le_condition("pre_close_pos<=0.35", "pre_close_pos", 0.35),
                _le_condition("pre_close_pos<=0.20", "pre_close_pos", 0.20),
                _le_condition("pre_rsi<=30", "rsi", 30.0),
                _le_condition("pre_rsi<=25", "rsi", 25.0),
                _ge_condition("pre_td_buy>=8", "td_buy_count", 8.0),
                _ge_condition("pre_td_buy>=10", "td_buy_count", 10.0),
                _ge_condition("pre_red_streak>=2", "pre_red_streak", 2),
                _ge_condition("pre_red_streak>=3", "pre_red_streak", 3),
                _ge_condition("pre_red_streak>=4", "pre_red_streak", 4),
                _ge_condition("pre_red_streak>=5", "pre_red_streak", 5),
                _ge_condition("pre_red_streak>=6", "pre_red_streak", 6),
                _ge_condition("pre_red_streak>=7", "pre_red_streak", 7),
                _ge_condition("pre_down_close_streak>=2", "pre_down_close_streak", 2),
                _ge_condition("pre_prev5_red_count>=4", "pre_prev5_red_count", 4),
                _eq_condition("pre_state=diverging_bear", "pre_macd_state_code", 2),
                _eq_condition("pre_state=arching_bear", "pre_macd_state_code", 4),
                _eq_condition("pre_state=converging_bear", "pre_macd_state_code", 6),
                _le_condition("pre_vwap_dist<=-0.01", "vwap_dist_pct", -0.01),
                _le_condition("pre_stoch_rsi_k<=20", "stoch_rsi_k", 20.0),
                _le_condition("pre_mfi<=20", "mfi", 20.0),
                _le_condition("pre_cmo<=-40", "cmo", -40.0),
                _le_condition("pre_trix<=-0.05", "trix", -0.05),
                _le_condition("pre_ultimate_osc<=30", "ultimate_osc", 30.0),
                _bool_condition("pre_bb_close_outside_lower", "pre_bb_close_outside_lower"),
                _bool_condition("pre_candle_completely_below_lower", "pre_candle_completely_below_lower"),
                _bool_condition("pre_vwap_cross_dn", "pre_vwap_cross_dn"),
            ]
            if include_exact_run_labels:
                side_specs.extend(
                    [
                        _eq_condition("pre_red_streak=5", "pre_red_streak", 5),
                        _eq_condition("pre_red_streak=6", "pre_red_streak", 6),
                        _eq_condition("pre_red_streak=7", "pre_red_streak", 7),
                    ]
                )
        return common + side_specs

    if side == "bull":
        side_specs = [
            _bool_condition("pre_candle_red", "pre_candle_red"),
            _le_condition("pre_close_pos<=0.35", "pre_close_pos", 0.35),
            _le_condition("pre_close_pos<=0.20", "pre_close_pos", 0.20),
            _le_condition("pre_rsi<=30", "rsi", 30.0),
            _le_condition("pre_rsi<=25", "rsi", 25.0),
            _ge_condition("pre_td_buy>=8", "td_buy_count", 8.0),
            _ge_condition("pre_td_buy>=10", "td_buy_count", 10.0),
            _ge_condition("pre_red_streak>=2", "pre_red_streak", 2),
            _ge_condition("pre_red_streak>=3", "pre_red_streak", 3),
            _ge_condition("pre_down_close_streak>=2", "pre_down_close_streak", 2),
            _ge_condition("pre_prev5_red_count>=4", "pre_prev5_red_count", 4),
            _eq_condition("pre_state=diverging_bear", "pre_macd_state_code", 2),
            _eq_condition("pre_state=arching_bear", "pre_macd_state_code", 4),
            _eq_condition("pre_state=converging_bear", "pre_macd_state_code", 6),
            _le_condition("pre_vwap_dist<=-0.01", "vwap_dist_pct", -0.01),
            _le_condition("pre_stoch_rsi_k<=20", "stoch_rsi_k", 20.0),
            _le_condition("pre_mfi<=20", "mfi", 20.0),
            _le_condition("pre_cmo<=-40", "cmo", -40.0),
            _le_condition("pre_trix<=-0.05", "trix", -0.05),
            _le_condition("pre_ultimate_osc<=30", "ultimate_osc", 30.0),
            _bool_condition("pre_bb_close_outside_lower", "pre_bb_close_outside_lower"),
            _bool_condition("pre_candle_completely_below_lower", "pre_candle_completely_below_lower"),
        ]
    else:
        side_specs = [
            _bool_condition("pre_candle_green", "pre_candle_green"),
            _ge_condition("pre_close_pos>=0.65", "pre_close_pos", 0.65),
            _ge_condition("pre_close_pos>=0.80", "pre_close_pos", 0.80),
            _ge_condition("pre_rsi>=70", "rsi", 70.0),
            _ge_condition("pre_rsi>=75", "rsi", 75.0),
            _ge_condition("pre_td_sell>=8", "td_sell_count", 8.0),
            _ge_condition("pre_td_sell>=10", "td_sell_count", 10.0),
            _ge_condition("pre_green_streak>=2", "pre_green_streak", 2),
            _ge_condition("pre_green_streak>=3", "pre_green_streak", 3),
            _ge_condition("pre_up_close_streak>=2", "pre_up_close_streak", 2),
            _ge_condition("pre_prev5_green_count>=4", "pre_prev5_green_count", 4),
            _eq_condition("pre_state=diverging_bull", "pre_macd_state_code", 1),
            _eq_condition("pre_state=arching_bull", "pre_macd_state_code", 3),
            _eq_condition("pre_state=converging_bull", "pre_macd_state_code", 5),
            _ge_condition("pre_vwap_dist>=0.01", "vwap_dist_pct", 0.01),
            _ge_condition("pre_stoch_rsi_k>=80", "stoch_rsi_k", 80.0),
            _ge_condition("pre_mfi>=80", "mfi", 80.0),
            _ge_condition("pre_cmo>=40", "cmo", 40.0),
            _ge_condition("pre_trix>=0.05", "trix", 0.05),
            _ge_condition("pre_ultimate_osc>=70", "ultimate_osc", 70.0),
            _bool_condition("pre_bb_close_outside_upper", "pre_bb_close_outside_upper"),
            _bool_condition("pre_candle_completely_above_upper", "pre_candle_completely_above_upper"),
        ]
    return common + side_specs


def _score_mask(
    *,
    bucket: pd.DataFrame,
    labels: np.ndarray,
    best_rets: np.ndarray,
    combo_mask: np.ndarray,
    side: str,
    timespan: str,
    min_run_length: int,
    base_rate: float,
    total_k: int,
    extra_k: int,
    conditions: Sequence[str],
    hit_threshold: float,
    min_n: int,
    scan_kind: str,
    base_conditions: Sequence[str] | None = None,
    added_conditions: Sequence[str] | None = None,
    base_row: Dict[str, object] | None = None,
) -> Dict[str, object] | None:
    n = int(combo_mask.sum())
    if n <= 0:
        return None
    hits = int((labels & combo_mask).sum())
    hit_rate = hits / n if n else 0.0
    matched_best = best_rets[combo_mask]
    matched_best = matched_best[np.isfinite(matched_best)]
    avg_best_ret = float(np.mean(matched_best)) if len(matched_best) else float("nan")
    hit_50bp = float(np.mean(matched_best >= 0.005)) if len(matched_best) else 0.0
    hit_100bp = float(np.mean(matched_best >= 0.01)) if len(matched_best) else 0.0
    hit_150bp = float(np.mean(matched_best >= 0.015)) if len(matched_best) else 0.0
    matched_run_len = pd.to_numeric(
        bucket.loc[combo_mask, "bull_run_len" if side == "bull" else "bear_run_len"],
        errors="coerce",
    ).to_numpy(dtype=float)
    matched_run_len = matched_run_len[np.isfinite(matched_run_len) & (matched_run_len > 0)]
    avg_run_len = float(np.mean(matched_run_len)) if len(matched_run_len) else float("nan")
    row: Dict[str, object] = {
        "timespan": timespan,
        "tone": "green" if side == "bull" else "red",
        "min_run_length": int(min_run_length),
        "n": n,
        "hits": hits,
        "hit_rate": round(hit_rate, 4),
        "base_rate": round(base_rate, 4),
        "lift": round(hit_rate / base_rate, 4) if base_rate > 0 else None,
        "hit_50bp": round(hit_50bp, 4),
        "hit_100bp": round(hit_100bp, 4),
        "hit_150bp": round(hit_150bp, 4),
        "avg_best_ret": round(avg_best_ret, 4) if np.isfinite(avg_best_ret) else None,
        "avg_run_len": round(avg_run_len, 2) if np.isfinite(avg_run_len) else None,
        "conditions": " AND ".join(conditions),
        "k": int(total_k),
        "extra_k": int(extra_k),
        "scan_kind": str(scan_kind or "full"),
        "passed_threshold": bool(n >= min_n and hit_rate >= hit_threshold),
    }
    if base_conditions:
        row["base_conditions"] = " AND ".join(base_conditions)
        row["added_conditions"] = " AND ".join(added_conditions or ())
    if base_row:
        base_n = int(base_row.get("n") or 0)
        base_hits = int(base_row.get("hits") or 0)
        base_hit_rate = float(base_row.get("hit_rate") or 0.0)
        row["base_n"] = base_n
        row["base_hits"] = base_hits
        row["base_hit_rate"] = round(base_hit_rate, 4)
        row["delta_n"] = n - base_n
        row["delta_hits"] = hits - base_hits
        row["delta_hit_rate"] = round(hit_rate - base_hit_rate, 4)
    return row


def _scan_bucket(
    df: pd.DataFrame,
    *,
    side: str,
    timespan: str,
    signal_mode: str,
    min_n: int,
    hit_threshold: float,
    max_k: int,
    min_run_length: int,
    base_conditions: Sequence[str] | None = None,
    max_extra_k: int = 2,
) -> List[Dict[str, object]]:
    success_col = "bull_success" if side == "bull" else "bear_success"
    best_ret_col = "bull_best_ret" if side == "bull" else "bear_best_ret"
    bucket = df.loc[df["timespan"] == timespan].copy()
    if bucket.empty:
        return []

    labels = bucket[success_col].fillna(False).to_numpy(dtype=bool)
    best_rets = pd.to_numeric(bucket[best_ret_col], errors="coerce").to_numpy(dtype=float)
    base_rate = float(labels.mean()) if len(labels) else 0.0

    requested_base_conditions = [str(value).strip() for value in list(base_conditions or ()) if str(value).strip()]
    spec_masks: List[tuple[str, np.ndarray]] = []
    for spec in _build_condition_specs(
        side,
        signal_mode,
        include_exact_run_labels=bool(requested_base_conditions),
    ):
        mask = spec.fn(bucket).fillna(False).to_numpy(dtype=bool)
        if int(mask.sum()) >= min_n or spec.label in requested_base_conditions:
            spec_masks.append((spec.label, mask))
    spec_mask_map = {label: mask for label, mask in spec_masks}

    findings: List[Dict[str, object]] = []
    seen_keys: set[tuple[int, int, tuple[str, ...], str]] = set()

    if requested_base_conditions:
        missing = [label for label in requested_base_conditions if label not in spec_mask_map]
        if missing:
            return []
        base_mask = np.ones(len(bucket), dtype=bool)
        for label in requested_base_conditions:
            base_mask &= spec_mask_map[label]
        base_row = _score_mask(
            bucket=bucket,
            labels=labels,
            best_rets=best_rets,
            combo_mask=base_mask,
            side=side,
            timespan=timespan,
            min_run_length=min_run_length,
            base_rate=base_rate,
            total_k=len(requested_base_conditions),
            extra_k=0,
            conditions=requested_base_conditions,
            hit_threshold=hit_threshold,
            min_n=min_n,
            scan_kind="base",
            base_conditions=requested_base_conditions,
            added_conditions=(),
        )
        if base_row is None:
            return []
        findings.append(base_row)
        seen_keys.add(
            (
                int(base_row["n"]),
                int(base_row["hits"]),
                tuple(requested_base_conditions),
                "base",
            )
        )
        extension_pool = [
            (label, mask)
            for label, mask in spec_masks
            if label not in set(requested_base_conditions)
        ]
        safe_max_extra_k = max(1, int(max_extra_k or 1))
        for extra_k in range(1, safe_max_extra_k + 1):
            for combo in itertools.combinations(extension_pool, extra_k):
                combo_mask = base_mask.copy()
                for _, mask in combo:
                    combo_mask &= mask
                row = _score_mask(
                    bucket=bucket,
                    labels=labels,
                    best_rets=best_rets,
                    combo_mask=combo_mask,
                    side=side,
                    timespan=timespan,
                    min_run_length=min_run_length,
                    base_rate=base_rate,
                    total_k=len(requested_base_conditions) + extra_k,
                    extra_k=extra_k,
                    conditions=[*requested_base_conditions, *(label for label, _ in combo)],
                    hit_threshold=hit_threshold,
                    min_n=min_n,
                    scan_kind="extension",
                    base_conditions=requested_base_conditions,
                    added_conditions=[label for label, _ in combo],
                    base_row=base_row,
                )
                if row is None or int(row["n"]) < min_n:
                    continue
                if (
                    int(row.get("delta_n") or 0) == 0
                    and int(row.get("delta_hits") or 0) == 0
                ):
                    continue
                combo_labels = tuple(label for label, _ in combo)
                dedupe_key = (int(row["n"]), int(row["hits"]), combo_labels, "extension")
                if dedupe_key in seen_keys:
                    continue
                seen_keys.add(dedupe_key)
                findings.append(row)
    else:
        for k in range(1, max_k + 1):
            for combo in itertools.combinations(spec_masks, k):
                combo_mask = combo[0][1].copy()
                for _, mask in combo[1:]:
                    combo_mask &= mask
                row = _score_mask(
                    bucket=bucket,
                    labels=labels,
                    best_rets=best_rets,
                    combo_mask=combo_mask,
                    side=side,
                    timespan=timespan,
                    min_run_length=min_run_length,
                    base_rate=base_rate,
                    total_k=k,
                    extra_k=k,
                    conditions=[label for label, _ in combo],
                    hit_threshold=hit_threshold,
                    min_n=min_n,
                    scan_kind="full",
                )
                if row is None or int(row["n"]) < min_n:
                    continue
                combo_labels = tuple(label for label, _ in combo)
                dedupe_key = (int(row["n"]), int(row["hits"]), combo_labels, "full")
                if dedupe_key in seen_keys:
                    continue
                seen_keys.add(dedupe_key)
                findings.append(row)
    findings.sort(
        key=lambda row: (
            -float(row["hit_rate"]),
            -float(row.get("delta_hit_rate") or 0.0),
            -int(row["n"]),
            -float(row["hit_100bp"]),
            int(row.get("extra_k") or row["k"]),
            str(row["conditions"]),
        )
    )
    return findings


def _write_summary(
    out_dir: Path,
    *,
    metadata: Dict[str, object],
    findings: List[Dict[str, object]],
    top_candidates: List[Dict[str, object]],
    signal_frame: pd.DataFrame,
) -> None:
    by_bucket: Dict[tuple[str, str], List[Dict[str, object]]] = {}
    for row in top_candidates:
        by_bucket.setdefault((str(row["timespan"]), str(row["tone"])), []).append(row)

    lines: List[str] = [
        "# Consecutive-Color Momentum Combo Scan",
        "",
        f"- Source: `public.ca` via `psql COPY`",
        f"- Start date: `{metadata['start_date']}`",
        f"- End date: `{metadata['end_date']}`",
        f"- Timespans: `{', '.join(metadata['timespans'])}`",
        f"- Sides: `{', '.join(metadata['sides'])}`",
        f"- Universe: `{metadata['universe']}`",
        f"- Minimum run length: `{metadata['min_run_length']}`",
        f"- Signal mode: `{metadata['signal_mode']}`",
        f"- Candidate threshold: `hit_rate >= {metadata['hit_threshold']:.2f}` with `n >= {metadata['min_n']}`",
        f"- Signal rows scanned: `{metadata['signal_rows']}`",
        f"- Raw enriched rows: `{metadata['raw_rows']}`",
        "",
    ]
    if metadata.get("base_conditions"):
        lines.extend(
            [
                f"- Base conditions: `{metadata['base_conditions']}`",
                f"- Max extra conditions: `{metadata['max_extra_k']}`",
                "",
            ]
        )
    for (timespan, tone), rows in sorted(by_bucket.items()):
        lines.append(f"## {timespan} {tone}")
        lines.append("")
        top_rows = rows[:8]
        if not top_rows:
            lines.append("- No candidates cleared the threshold.")
            lines.append("")
            continue
        for row in top_rows:
            delta_text = ""
            if row.get("scan_kind") == "extension":
                delta_text = (
                    f" `delta_hit={row.get('delta_hit_rate')}`"
                    f" `delta_n={row.get('delta_n')}`"
                )
            if row.get("scan_kind") == "base":
                delta_text = " `BASE`"
            lines.append(
                "- "
                f"`{row['conditions']}`: "
                f"`n={row['n']}` `hit={row['hit_rate']}` `hit50={row['hit_50bp']}` "
                f"`hit100={row['hit_100bp']}` `avg={row['avg_best_ret']}` `avg_run={row['avg_run_len']}`"
                + delta_text
                + (" `PASS`" if row.get("passed_threshold") else "")
            )
        lines.append("")

    if findings:
        top_global = findings[:12]
        lines.append("## Best Overall")
        lines.append("")
        for row in top_global:
            delta_text = ""
            if row.get("scan_kind") == "extension":
                delta_text = f" `delta_hit={row.get('delta_hit_rate')}`"
            if row.get("scan_kind") == "base":
                delta_text = " `BASE`"
            lines.append(
                "- "
                f"`{row['timespan']} {row['tone']}` "
                f"`{row['conditions']}`: "
                f"`n={row['n']}` `hit={row['hit_rate']}` `hit100={row['hit_100bp']}`"
                + delta_text
            )
        lines.append("")

    summary_path = out_dir / "summary.md"
    summary_path.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")


def main() -> None:
    args = _parse_args()
    timespans = _parse_timespans(args.timespans)
    sides = _parse_sides(args.sides)
    base_conditions = _parse_condition_labels(args.base_conditions)
    tickers = sorted({str(ticker).strip().upper() for ticker in most_active_tickers if str(ticker).strip()})
    start_epoch, end_epoch = _date_to_epoch_bounds(args.start_date, args.end_date)
    query = _build_query(
        start_epoch=start_epoch,
        end_epoch=end_epoch,
        timespans=timespans,
        tickers=tickers,
    )

    timestamp = datetime.now(MARKET_TZ).strftime("%Y-%m-%d")
    run_suffix = ""
    if base_conditions:
        seed_label = _slugify(args.seed_label or "_".join(base_conditions[:2]))
        run_suffix = f"_seed_{seed_label}_x{max(1, int(args.max_extra_k or 1))}"
    run_name = (
        f"consecutive_color_combo_scan_{args.signal_mode}_"
        f"{_timespan_slug(timespans)}_"
        f"streak{args.min_run_length}_"
        f"n{args.min_n}_"
        f"h{int(round(args.hit_threshold * 100))}{run_suffix}_{timestamp}"
    )
    out_dir = Path(args.output_dir) / run_name
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "event_universe.sql").write_text(query + "\n", encoding="utf-8")
    condition_catalog = {
        side: [spec.label for spec in _build_condition_specs(
            side,
            args.signal_mode,
            include_exact_run_labels=bool(base_conditions),
        )]
        for side in sides
    }
    (out_dir / "condition_catalog.json").write_text(
        json.dumps(condition_catalog, indent=2),
        encoding="utf-8",
    )

    raw_df = _run_copy_query(
        psql_path=args.psql_path,
        host=args.host,
        port=args.port,
        user=args.user,
        password=args.password,
        database=args.database,
        query=query,
    )
    raw_df = _coerce_frame(raw_df)
    signal_frame = _compute_signal_frame(raw_df, args.min_run_length, args.signal_mode)
    signal_csv = out_dir / "signal_rows.csv"
    signal_frame.to_csv(signal_csv, index=False)

    all_rows: List[Dict[str, object]] = []
    for timespan in timespans:
        for side in sides:
            all_rows.extend(
                _scan_bucket(
                    signal_frame,
                    side=side,
                    timespan=timespan,
                    signal_mode=args.signal_mode,
                    min_n=args.min_n,
                    hit_threshold=args.hit_threshold,
                    max_k=args.max_k,
                    min_run_length=args.min_run_length,
                    base_conditions=base_conditions,
                    max_extra_k=max(1, int(args.max_extra_k or 1)),
                )
            )

    findings = [row for row in all_rows if row.get("passed_threshold")]
    top_candidates: List[Dict[str, object]] = []
    by_bucket: Dict[tuple[str, str], List[Dict[str, object]]] = {}
    for row in all_rows:
        by_bucket.setdefault((str(row["timespan"]), str(row["tone"])), []).append(row)
    for rows in by_bucket.values():
        top_candidates.extend(rows[:25])

    findings_df = pd.DataFrame(findings)
    findings_path = out_dir / "candidate_findings_85.csv"
    if findings_df.empty:
        findings_df = pd.DataFrame(
            columns=[
                "timespan",
                "tone",
                "min_run_length",
                "n",
                "hits",
                "hit_rate",
                "base_rate",
                "lift",
                "hit_50bp",
                "hit_100bp",
                "hit_150bp",
                "avg_best_ret",
                "avg_run_len",
                "conditions",
                "k",
                "extra_k",
                "scan_kind",
                "base_conditions",
                "added_conditions",
                "base_n",
                "base_hits",
                "base_hit_rate",
                "delta_n",
                "delta_hits",
                "delta_hit_rate",
            ]
        )
    findings_df.to_csv(findings_path, index=False)
    (out_dir / "candidate_findings_85.json").write_text(
        json.dumps(findings, indent=2),
        encoding="utf-8",
    )
    pd.DataFrame(top_candidates).to_csv(out_dir / "top_candidates.csv", index=False)
    (out_dir / "top_candidates.json").write_text(
        json.dumps(top_candidates, indent=2),
        encoding="utf-8",
    )

    metadata = {
        "generated_at_et": datetime.now(MARKET_TZ).isoformat(),
        "start_date": args.start_date,
        "end_date": args.end_date,
        "timespans": timespans,
        "sides": sides,
        "universe": "most_active",
        "tickers": tickers,
        "min_run_length": int(args.min_run_length),
        "signal_mode": args.signal_mode,
        "min_n": int(args.min_n),
        "hit_threshold": float(args.hit_threshold),
        "max_k": int(args.max_k),
        "base_conditions": " AND ".join(base_conditions),
        "max_extra_k": int(max(1, int(args.max_extra_k or 1))) if base_conditions else 0,
        "seed_label": str(args.seed_label or "").strip(),
        "raw_rows": int(len(raw_df)),
        "signal_rows": int(len(signal_frame)),
        "candidates": int(len(findings)),
        "top_candidates_saved": int(len(top_candidates)),
        "all_combos_scored": int(len(all_rows)),
    }
    (out_dir / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    _write_summary(
        out_dir,
        metadata=metadata,
        findings=findings,
        top_candidates=top_candidates,
        signal_frame=signal_frame,
    )

    print(json.dumps({"output_dir": str(out_dir), **metadata}, indent=2))


if __name__ == "__main__":
    main()
