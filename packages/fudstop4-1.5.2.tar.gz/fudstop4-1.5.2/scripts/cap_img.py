import asyncio
import logging
import sys
from pathlib import Path
project_dir = str(Path(__file__).resolve().parents[1])
if project_dir not in sys.path:
    sys.path.append(project_dir)
import io
from PIL import Image
from datetime import datetime
from discord_webhook import AsyncDiscordWebhook, DiscordEmbed
from UTILS.discord_targets import split_discord_webhook_target
from UTILS.ticker_dicts import ticker_hooks_dict, tickers_dict
from imports import *
from fudstop4._markets.list_sets.ticker_lists import most_active_tickers

logging.getLogger("discord_webhook.async_webhook").setLevel(logging.CRITICAL)
DEAD_WEBHOOKS: set[str] = set()

# Load image from DB and return PIL.Image
async def get_cap_flow_img(ticker: str, date: str):
    parsed_date = datetime.strptime(date, "%Y%m%d").date()
    query = """
        SELECT image FROM capital_flow_images
        WHERE ticker = $1 AND date = $2
        LIMIT 1
    """
    rows = await db.fetch(query, ticker, parsed_date)
    row = rows[0] if rows else None

    if row is None:
        print(f"[ERROR] No image found for {ticker} on {date}")
        return None

    image_bytes = row['image']
    image = Image.open(io.BytesIO(image_bytes))
    return image  # Return PIL image

# Main function to fetch date, get image, and post to Discord
from more_itertools import chunked 
async def main(ticker):
    try:
        query = """
            SELECT latest FROM capital_flow
            WHERE ticker = $1
            ORDER BY insertion_timestamp DESC LIMIT 1
        """
        results = await db.fetch(query, ticker)
        if not results:
            print(f"[cap_img] No capital_flow rows found for {ticker}")
            return
        date = str(results[0]["latest"] or "").strip()
        if not date:
            print(f"[cap_img] Missing latest date for {ticker}")
            return

        image = await get_cap_flow_img(ticker, date=date)
        if image is None:
            return

        # Convert image to PNG bytes
        buf = io.BytesIO()
        image.save(buf, format='PNG')
        buf.seek(0)
        image_bytes = buf.read()

        # Send to Discord
        hook_url, thread_id = split_discord_webhook_target(
            ticker_hooks_dict.get(ticker),
            fallback_thread_id=tickers_dict.get(ticker),
        )
        if not hook_url:
            print(f"[cap_img] Skipping Discord post for {ticker}: invalid webhook target")
            return
        if hook_url in DEAD_WEBHOOKS:
            return
        webhook_kwargs = {"url": hook_url}
        if thread_id:
            webhook_kwargs["thread_id"] = thread_id
        webhook = AsyncDiscordWebhook(**webhook_kwargs)
        webhook.add_file(image_bytes, filename='flow.png')

        embed = DiscordEmbed(
            title=f"Capital Flow Chart: {ticker}",
            description=f"Latest data as of **{date}**",
            color='03b2f8'
        )
        embed.set_image(url='attachment://flow.png')

        webhook.add_embed(embed)
        response = await webhook.execute()
        if response.status_code == 404:
            DEAD_WEBHOOKS.add(hook_url)
            print(f"[cap_img] Skipping stale webhook for {ticker}")
        elif response.status_code not in (200, 204):
            print(f"[cap_img] Discord post for {ticker} returned status {response.status_code}")
    except Exception as e:
        print(e)
async def run_main():
    """
    Entry point for posting capital flow images.  A single database
    connection is opened and reused for the duration of the run.  The
    function iterates through batches of tickers and dispatches tasks to
    send images to Discord.  A short sleep between batches helps to
    prevent hitting rate limits on the Discord webhook API.
    """
    batch_size = 7
    await db.connect()
    try:
        for batch in chunked(most_active_tickers, batch_size):
            tasks = [main(ticker) for ticker in batch]
            await asyncio.gather(*tasks)
            # optional cooldown to avoid hitting Discord API limits
            await asyncio.sleep(2)
    finally:
        # Always disconnect from the database when finished
        await db.disconnect()

if __name__ == "__main__":
    asyncio.run(run_main())
