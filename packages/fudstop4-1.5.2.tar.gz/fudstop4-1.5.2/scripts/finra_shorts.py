import asyncio
import sys
from datetime import datetime, timedelta
from pathlib import Path

import aiohttp
import pandas as pd
from fudstop4.apis.polygonio.polygon_options import PolygonOptions

project_dir = str(Path(__file__).resolve().parents[1])
if project_dir not in sys.path:
    sys.path.append(project_dir)

opts = PolygonOptions()


def _log(message: str) -> None:
    try:
        print(message)
    except OSError:
        pass


async def download_finra_data(date: str, session: aiohttp.ClientSession) -> str | None:
    url = f"https://cdn.finra.org/equity/regsho/daily/CNMSshvol{date}.txt"
    try:
        async with session.get(url) as resp:
            if resp.status == 200:
                return await resp.text()
            _log(f"Failed to download data for {date} (status {resp.status})")
            return None
    except Exception as exc:
        _log(f"Error downloading data for {date}: {exc}")
        return None


def parse_finra_data(raw_data: str):
    from io import StringIO

    return pd.read_csv(StringIO(raw_data), sep="|")


async def fetch_finra_data(start_date: str, end_date: str, session: aiohttp.ClientSession) -> pd.DataFrame | None:
    current_date = datetime.strptime(start_date, "%Y%m%d")
    end_date_dt = datetime.strptime(end_date, "%Y%m%d") if isinstance(end_date, str) else end_date

    date_strings = []
    while current_date <= end_date_dt:
        date_strings.append(current_date.strftime("%Y%m%d"))
        current_date += timedelta(days=1)

    raw_results = await asyncio.gather(*[download_finra_data(date, session) for date in date_strings])
    frames = [parse_finra_data(raw) for raw in raw_results if raw]
    if not frames:
        _log("No data fetched for the given date range.")
        return None
    return pd.concat(frames, ignore_index=True)


async def main() -> None:
    await opts.connect()
    try:
        async with aiohttp.ClientSession() as session:
            while True:
                today = datetime.today().strftime("%Y%m%d")
                prior_date = (datetime.today() - timedelta(days=30)).strftime("%Y%m%d")
                final_df = await fetch_finra_data(prior_date, today, session)
                if final_df is not None:
                    final_df = final_df.rename(
                        columns={
                            "Date": "date",
                            "Symbol": "ticker",
                            "ShortVolume": "short_volume",
                            "TotalVolume": "total_volume",
                            "Market": "market",
                            "ShortExemptVolume": "short_exempt_volume",
                        }
                    )
                    await opts.batch_upsert_dataframe(
                        final_df,
                        table_name="finra_shorts",
                        unique_columns=["ticker", "date"],
                    )
                    _log(
                        f"[finra_shorts] Upserted {len(final_df)} FINRA short volume records "
                        f"for {prior_date}-{today}"
                    )
                await asyncio.sleep(600)
    finally:
        await opts.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
