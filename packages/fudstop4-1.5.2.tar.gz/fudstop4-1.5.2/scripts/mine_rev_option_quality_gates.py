#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import itertools
import json
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple


DEFAULT_SCORED_CSV = Path(
    "runs/ca_historical_reversal_research/rev_option_profit_replay_2026-03-03_2026-03-12/scored_hits.csv"
)
DEFAULT_OUTPUT_DIR = Path(
    "runs/ca_historical_reversal_research/rev_live_quality_gate_expansion_2026-03-19"
)

NUMERIC_FIELDS = (
    "atr_pct",
    "bb_width",
    "best_return",
    "roc",
    "rsi",
    "rvol",
    "stoch_rsi_k",
    "td_buy_count",
    "td_sell_count",
    "trix",
    "ultimate_osc",
    "vwap_dist_pct",
)
BOOL_FIELDS = ("success", "trend_regime", "volume_confirm")

Condition = Tuple[str, str, Any]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Mine incremental REV live-quality gates from scored option-profit replay CSV output.",
    )
    parser.add_argument("--scored-csv", default=str(DEFAULT_SCORED_CSV))
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR))
    parser.add_argument("--top", type=int, default=20)
    return parser.parse_args()


def to_float(value: Any) -> Optional[float]:
    if value in (None, "", "None", "nan", "NaN"):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def to_bool(value: Any) -> bool:
    return str(value or "").strip().lower() in {"true", "t", "1", "yes", "y"}


def load_rows(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open("r", encoding="utf-8", newline="") as handle:
        for raw in csv.DictReader(handle):
            row = dict(raw)
            for field in NUMERIC_FIELDS:
                row[field] = to_float(raw.get(field))
            for field in BOOL_FIELDS:
                row[field] = to_bool(raw.get(field))
            rows.append(row)
    return rows


def current_live_gate(row: Dict[str, Any]) -> bool:
    tone = str(row.get("tone") or "").strip().lower()
    if tone == "bullish":
        return (
            row.get("rvol") is not None
            and float(row["rvol"]) <= 2.3
            and row.get("stoch_rsi_k") is not None
            and float(row["stoch_rsi_k"]) >= 10.0
            and row.get("trix") is not None
            and float(row["trix"]) <= -0.02
        )
    if tone == "bearish":
        if row.get("td_sell_count") is not None and float(row["td_sell_count"]) >= 18.0:
            return True
        return (
            row.get("rsi") is not None
            and float(row["rsi"]) >= 90.0
            and row.get("vwap_dist_pct") is not None
            and float(row["vwap_dist_pct"]) >= 0.0065
            and row.get("bb_width") is not None
            and float(row["bb_width"]) >= 0.015
        )
    return False


def recommended_expansion_gate(row: Dict[str, Any]) -> bool:
    tone = str(row.get("tone") or "").strip().lower()
    if current_live_gate(row):
        return True
    if tone == "bullish":
        return (
            row.get("rsi") is not None
            and float(row["rsi"]) <= 22.0
            and row.get("rvol") is not None
            and float(row["rvol"]) <= 2.3
            and row.get("ultimate_osc") is not None
            and float(row["ultimate_osc"]) <= 32.0
        )
    if tone == "bearish":
        return (
            row.get("rvol") is not None
            and float(row["rvol"]) >= 2.0
            and row.get("trix") is not None
            and float(row["trix"]) >= 0.07
            and row.get("roc") is not None
            and float(row["roc"]) >= 1.5
        )
    return False


def summarize(rows: Sequence[Dict[str, Any]], predicate: Optional[Callable[[Dict[str, Any]], bool]] = None) -> Dict[str, Any]:
    selected = [row for row in rows if predicate is None or predicate(row)]
    count = len(selected)
    wins = sum(1 for row in selected if row.get("success"))
    avg_best_return = (
        sum(float(row.get("best_return") or 0.0) for row in selected) / count if count else 0.0
    )
    return {
        "count": count,
        "wins": wins,
        "hit_rate": (wins / count) if count else 0.0,
        "avg_best_return": avg_best_return,
    }


def match_condition(row: Dict[str, Any], condition: Condition) -> bool:
    field, operator, target = condition
    value = row.get(field)
    if value is None:
        return False
    if operator == "gte":
        return float(value) >= float(target)
    if operator == "lte":
        return float(value) <= float(target)
    if operator == "eq":
        return value == target
    raise ValueError(f"unsupported operator: {operator}")


def format_condition(condition: Condition) -> str:
    field, operator, target = condition
    if operator == "gte":
        return f"{field}>={target}"
    if operator == "lte":
        return f"{field}<={target}"
    return f"{field}={target}"


def search_incremental_clauses(
    rows: Sequence[Dict[str, Any]],
    *,
    candidates: Sequence[Condition],
    max_terms: int = 3,
    min_count: int = 5,
    min_hit_rate: float = 0.30,
    top: int = 20,
) -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []
    for width in range(1, max_terms + 1):
        for combo in itertools.combinations(candidates, width):
            subset = [row for row in rows if all(match_condition(row, condition) for condition in combo)]
            summary = summarize(subset)
            if summary["count"] < min_count or summary["hit_rate"] < min_hit_rate:
                continue
            results.append({
                "conditions": [format_condition(item) for item in combo],
                "count": summary["count"],
                "wins": summary["wins"],
                "hit_rate": summary["hit_rate"],
                "avg_best_return": summary["avg_best_return"],
            })
    results.sort(
        key=lambda item: (
            -float(item["hit_rate"]),
            -int(item["count"]),
            -float(item["avg_best_return"]),
            len(item["conditions"]),
            " AND ".join(item["conditions"]),
        )
    )
    return results[:top]


def build_markdown(
    *,
    baseline: Dict[str, Dict[str, Any]],
    expanded: Dict[str, Dict[str, Any]],
    bullish_results: Sequence[Dict[str, Any]],
    bearish_results: Sequence[Dict[str, Any]],
) -> str:
    lines: List[str] = [
        "# REV Live Quality Gate Expansion - 2026-03-19",
        "",
        "- Scope: `m1` scored REV hits from the actual options replay in `rev_option_profit_replay_2026-03-03_2026-03-12/scored_hits.csv`.",
        "- Outcome target: `+8%` best ATM option return inside `10` minutes.",
        "- Search method: mine additional clause pockets only on the rows that the current live gate excludes.",
        "",
        "## Recommended Expansion",
        "",
        "- `bullish`: `rsi<=22 AND rvol<=2.3 AND ultimate_osc<=32`",
        "- `bearish`: `rvol>=2.0 AND trix>=0.07 AND roc>=1.5`",
        "",
        "## Combined Effect",
        "",
        f"- Current live gate: `n={baseline['all']['count']}` | wins `{baseline['all']['wins']}` | hit `{baseline['all']['hit_rate']:.2%}` | avg best `{baseline['all']['avg_best_return']:.2%}`",
        f"- Expanded live gate: `n={expanded['all']['count']}` | wins `{expanded['all']['wins']}` | hit `{expanded['all']['hit_rate']:.2%}` | avg best `{expanded['all']['avg_best_return']:.2%}`",
        "",
        f"- Current bullish kept: `n={baseline['bullish']['count']}` | wins `{baseline['bullish']['wins']}` | hit `{baseline['bullish']['hit_rate']:.2%}`",
        f"- Expanded bullish kept: `n={expanded['bullish']['count']}` | wins `{expanded['bullish']['wins']}` | hit `{expanded['bullish']['hit_rate']:.2%}`",
        f"- Current bearish kept: `n={baseline['bearish']['count']}` | wins `{baseline['bearish']['wins']}` | hit `{baseline['bearish']['hit_rate']:.2%}`",
        f"- Expanded bearish kept: `n={expanded['bearish']['count']}` | wins `{expanded['bearish']['wins']}` | hit `{expanded['bearish']['hit_rate']:.2%}`",
        "",
        "## Top Incremental Bullish Clauses",
        "",
    ]
    if bullish_results:
        for item in bullish_results:
            lines.append(
                f"- `{' AND '.join(item['conditions'])}` | `n={item['count']}` | wins `{item['wins']}` | hit `{item['hit_rate']:.2%}` | avg best `{item['avg_best_return']:.2%}`"
            )
    else:
        lines.append("- No bullish incremental clauses cleared the search bar.")
    lines.extend(["", "## Top Incremental Bearish Clauses", ""])
    if bearish_results:
        for item in bearish_results:
            lines.append(
                f"- `{' AND '.join(item['conditions'])}` | `n={item['count']}` | wins `{item['wins']}` | hit `{item['hit_rate']:.2%}` | avg best `{item['avg_best_return']:.2%}`"
            )
    else:
        lines.append("- No bearish incremental clauses cleared the search bar.")
    lines.extend(
        [
            "",
            "## Note",
            "",
            "- A smaller bearish lower-RVOL extreme pocket (`rsi>=85 AND rvol<=2.0 AND roc>=1.5`) also showed promise, but the sample was too thin for the main live promotion.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    scored_path = Path(args.scored_csv)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    rows = load_rows(scored_path)
    bullish_rows = [row for row in rows if str(row.get("tone") or "").strip().lower() == "bullish"]
    bearish_rows = [row for row in rows if str(row.get("tone") or "").strip().lower() == "bearish"]
    bullish_remainder = [row for row in bullish_rows if not current_live_gate(row)]
    bearish_remainder = [row for row in bearish_rows if not current_live_gate(row)]

    bullish_candidates: Tuple[Condition, ...] = (
        ("rsi", "lte", 22.0),
        ("rsi", "lte", 24.0),
        ("rsi", "lte", 25.0),
        ("rvol", "lte", 2.3),
        ("rvol", "lte", 2.5),
        ("rvol", "lte", 3.0),
        ("td_buy_count", "gte", 12.0),
        ("td_buy_count", "gte", 13.0),
        ("td_buy_count", "gte", 15.0),
        ("ultimate_osc", "lte", 32.0),
        ("ultimate_osc", "lte", 30.0),
        ("ultimate_osc", "lte", 25.0),
        ("stoch_rsi_k", "gte", 10.0),
        ("trix", "lte", -0.02),
        ("vwap_dist_pct", "lte", -0.008),
    )
    bearish_candidates: Tuple[Condition, ...] = (
        ("rvol", "gte", 2.0),
        ("rvol", "gte", 2.5),
        ("rvol", "lte", 3.5),
        ("trix", "gte", 0.07),
        ("trix", "gte", 0.05),
        ("roc", "gte", 1.5),
        ("roc", "gte", 2.0),
        ("bb_width", "gte", 0.03),
        ("vwap_dist_pct", "gte", 0.015),
        ("td_sell_count", "gte", 12.0),
        ("rsi", "gte", 85.0),
        ("rsi", "gte", 88.0),
        ("stoch_rsi_k", "gte", 90.0),
        ("ultimate_osc", "gte", 75.0),
    )

    bullish_results = search_incremental_clauses(
        bullish_remainder,
        candidates=bullish_candidates,
        top=max(1, int(args.top)),
    )
    bearish_results = search_incremental_clauses(
        bearish_remainder,
        candidates=bearish_candidates,
        top=max(1, int(args.top)),
    )

    baseline = {
        "bullish": summarize(bullish_rows, current_live_gate),
        "bearish": summarize(bearish_rows, current_live_gate),
        "all": summarize(rows, current_live_gate),
    }
    expanded = {
        "bullish": summarize(bullish_rows, recommended_expansion_gate),
        "bearish": summarize(bearish_rows, recommended_expansion_gate),
        "all": summarize(rows, recommended_expansion_gate),
    }

    payload = {
        "scored_csv": str(scored_path),
        "baseline": baseline,
        "expanded": expanded,
        "top_incremental_bullish": bullish_results,
        "top_incremental_bearish": bearish_results,
    }
    (output_dir / "summary.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    (output_dir / "summary.md").write_text(
        build_markdown(
            baseline=baseline,
            expanded=expanded,
            bullish_results=bullish_results,
            bearish_results=bearish_results,
        ),
        encoding="utf-8",
    )
    print(f"wrote {output_dir}")


if __name__ == "__main__":
    main()
