#!/usr/bin/env python3
from __future__ import annotations

import asyncio
import datetime
import json
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

ROOT = Path(__file__).resolve().parent
REPO_ROOT = ROOT.parent
LOG_DIR = REPO_ROOT / "tmp" / "feed_loop_supervisor"
STATUS_PATH = LOG_DIR / "status.json"
PYTHON_BIN = os.getenv("FEED_STACK_PYTHON") or sys.executable

repo_root_str = str(REPO_ROOT)
if repo_root_str not in sys.path:
    sys.path.append(repo_root_str)

from feeds.discord_routes import iter_routes


@dataclass(frozen=True)
class FeedSpec:
    name: str
    script_path: str


def _feed_specs() -> List[FeedSpec]:
    seen: set[str] = set()
    specs: List[FeedSpec] = []
    for route in iter_routes():
        script_path = str(route.script_path).replace("\\", "/").strip()
        if not script_path or script_path in seen:
            continue
        seen.add(script_path)
        specs.append(FeedSpec(name=Path(script_path).stem, script_path=script_path))
    specs.sort(key=lambda spec: spec.name)
    return specs


SPECS = _feed_specs()
STATE: Dict[str, Dict[str, object]] = {}


def now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def merged_env() -> Dict[str, str]:
    env = os.environ.copy()
    env.setdefault("PYTHONUNBUFFERED", "1")
    return env


def find_existing_pid(spec: FeedSpec) -> int:
    script_name = Path(spec.script_path).name.replace(".", "\\.")
    command = (
        "Get-CimInstance Win32_Process | Where-Object { "
        "$_.Name -match 'python' -and "
        f"$_.CommandLine -match '{script_name}'"
        "} | Select-Object -ExpandProperty ProcessId"
    )
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", command],
            capture_output=True,
            text=True,
            check=False,
            cwd=str(REPO_ROOT),
        )
    except Exception:
        return 0
    for line in result.stdout.splitlines():
        text = line.strip()
        if text.isdigit():
            return int(text)
    return 0


async def write_status_snapshot() -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    STATUS_PATH.write_text(json.dumps({"updated_at": now_iso(), "processes": STATE}, indent=2), encoding="utf-8")


async def status_loop() -> None:
    while True:
        await write_status_snapshot()
        await asyncio.sleep(15)


async def spawn_process(spec: FeedSpec):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_handle = open(LOG_DIR / f"{spec.name}.log", "ab")
    process = await asyncio.create_subprocess_exec(
        PYTHON_BIN,
        str(REPO_ROOT / spec.script_path),
        cwd=str(REPO_ROOT),
        env=merged_env(),
        stdout=log_handle,
        stderr=asyncio.subprocess.STDOUT,
    )
    STATE.setdefault(spec.name, {})
    STATE[spec.name].update(
        {
            "pid": process.pid,
            "script": spec.script_path,
            "status": "running",
            "started_at": now_iso(),
            "restarts": int(STATE[spec.name].get("restarts", 0)),
        }
    )
    print(f"[feed_loop_supervisor] started {spec.name} pid={process.pid}")
    return process, log_handle


async def run_daemon(spec: FeedSpec) -> None:
    backoff_seconds = 5
    while True:
        external_pid = find_existing_pid(spec)
        if external_pid:
            STATE.setdefault(spec.name, {})
            STATE[spec.name].update(
                {
                    "pid": external_pid,
                    "script": spec.script_path,
                    "status": "external",
                    "checked_at": now_iso(),
                }
            )
            await asyncio.sleep(30)
            continue

        process, log_handle = await spawn_process(spec)
        return_code = await process.wait()
        log_handle.close()
        restarts = int(STATE[spec.name].get("restarts", 0)) + 1
        STATE[spec.name].update(
            {
                "status": "stopped",
                "last_exit_code": return_code,
                "last_stopped_at": now_iso(),
                "restarts": restarts,
            }
        )
        print(f"[feed_loop_supervisor] {spec.name} exited rc={return_code}; restarting in {backoff_seconds}s")
        await asyncio.sleep(backoff_seconds)


async def main() -> None:
    tasks = [asyncio.create_task(status_loop())]
    for spec in SPECS:
        tasks.append(asyncio.create_task(run_daemon(spec)))
    try:
        await asyncio.gather(*tasks)
    finally:
        await write_status_snapshot()


if __name__ == "__main__":
    asyncio.run(main())
