#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Sequence

import pandas as pd

import mine_m1_option_profit_signals as opt
import mine_m1_sustained_option_signals as base


DEFAULT_START_DATE = "2025-12-01"
DEFAULT_END_DATE = "2026-04-07"
DEFAULT_OUTPUT_ROOT = Path("runs/ca_historical_reversal_research")


def parse_tickers(raw: str) -> list[str]:
    values = [value.strip().upper() for value in str(raw or "").split(",") if value.strip()]
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        ordered.append(value)
    return ordered


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Mine multi-timeframe m1 option-profit signal families using m5/m15 context "
            "and real option_candles outcomes."
        )
    )
    parser.add_argument("--host", default="")
    parser.add_argument("--port", type=int, default=5432)
    parser.add_argument("--user", default="")
    parser.add_argument("--password", default="")
    parser.add_argument("--database", default="")
    parser.add_argument("--start-date", default=DEFAULT_START_DATE)
    parser.add_argument("--end-date", default=DEFAULT_END_DATE)
    parser.add_argument("--val-days", type=int, default=20)
    parser.add_argument("--min-n", type=int, default=20)
    parser.add_argument("--min-val-n", type=int, default=8)
    parser.add_argument("--target-hit", type=float, default=0.60)
    parser.add_argument("--seed-hit", type=float, default=0.55)
    parser.add_argument("--val-floor", type=float, default=0.55)
    parser.add_argument("--trigger-pct", type=float, default=0.03)
    parser.add_argument("--target-pct", type=float, default=0.05)
    parser.add_argument("--hold-pct", type=float, default=0.02)
    parser.add_argument("--max-adverse-pct", type=float, default=0.05)
    parser.add_argument("--momentum-pct", type=float, default=0.08)
    parser.add_argument("--target-window", choices=("1_5", "1_10"), default="1_5")
    parser.add_argument("--hold-bar", type=int, choices=(3, 5), default=3)
    parser.add_argument("--min-entry-price", type=float, default=0.20)
    parser.add_argument("--min-entry-volume", type=int, default=0)
    parser.add_argument("--tickers", default="")
    parser.add_argument(
        "--base-profile",
        choices=("reversal", "reclaim", "continuation", "expansion"),
        default="reclaim",
    )
    parser.add_argument("--max-k", type=int, default=4)
    parser.add_argument("--top-seeds", type=int, default=100)
    parser.add_argument("--top-per-depth", type=int, default=70)
    parser.add_argument("--top-final", type=int, default=30)
    parser.add_argument("--min-trigger12-rate", type=float, default=0.60)
    parser.add_argument("--min-trigger1-rate", type=float, default=0.0)
    parser.add_argument("--min-sustain75-rate", type=float, default=0.0)
    parser.add_argument("--min-avg-best-ret", type=float, default=0.08)
    parser.add_argument("--min-avg-hold5-ret", type=float, default=0.02)
    parser.add_argument("--min-wilson-lb", type=float, default=0.40)
    parser.add_argument("--min-val-wilson-lb", type=float, default=0.30)
    parser.add_argument("--min-tickers", type=int, default=10)
    parser.add_argument("--min-val-tickers", type=int, default=5)
    parser.add_argument("--output-dir", default="")
    return parser.parse_args()


def parse_date(raw: str) -> date:
    return datetime.strptime(str(raw or "").strip(), "%Y-%m-%d").date()


def build_context_query(*, start_epoch: int, end_epoch: int, timespan: str) -> str:
    return f"""
SELECT
    ticker,
    date_et,
    ts::bigint AS ts_epoch,
    timespan,
    trend_regime,
    volume_confirm,
    squeeze_off,
    vwap_dist_pct,
    trix,
    rsi,
    td_buy_count,
    td_sell_count,
    ema_stack_bull,
    ema_stack_bear,
    mfi,
    stoch_rsi_k,
    cmo,
    bb_close_outside_lower,
    bb_close_outside_upper,
    candle_completely_below_lower,
    candle_completely_above_upper,
    rvol,
    atr_pct,
    chop
FROM ca
WHERE timespan = '{str(timespan).replace("'", "''")}'
  AND session = 'regular'
  AND bb_width IS NOT NULL
  AND ts::bigint >= {int(start_epoch)}
  AND ts::bigint < {int(end_epoch)}
ORDER BY ticker, date_et, ts::bigint
""".strip()


def load_context(conn, *, start_epoch: int, end_epoch: int, timespan: str) -> pd.DataFrame:
    query = build_context_query(start_epoch=start_epoch, end_epoch=end_epoch, timespan=timespan)
    df = pd.read_sql_query(query, conn)
    if df.empty:
        return df
    df["ts_epoch"] = pd.to_numeric(df["ts_epoch"], errors="coerce").fillna(0).astype("int64")
    return df.sort_values(["ticker", "date_et", "ts_epoch"]).reset_index(drop=True)


def merge_context(base_df: pd.DataFrame, context_df: pd.DataFrame, prefix: str) -> pd.DataFrame:
    if base_df.empty or context_df.empty:
        return base_df
    left = base_df.copy()
    right = context_df.copy()
    left["ticker"] = left["ticker"].astype(str)
    right["ticker"] = right["ticker"].astype(str)
    left["ts_epoch"] = pd.to_numeric(left["ts_epoch"], errors="coerce").fillna(0).astype("int64")
    right["ts_epoch"] = pd.to_numeric(right["ts_epoch"], errors="coerce").fillna(0).astype("int64")
    keep = [column for column in context_df.columns if column not in {"timespan", "date_et"}]
    renamed = right[keep].rename(
        columns={column: f"{prefix}_{column}" for column in keep if column not in {"ticker", "ts_epoch"}}
    )
    merged_parts: list[pd.DataFrame] = []
    right_groups = {
        str(ticker): part.sort_values("ts_epoch").reset_index(drop=True)
        for ticker, part in renamed.groupby("ticker", sort=False)
    }
    for ticker, left_part in left.groupby("ticker", sort=False):
        sorted_left = left_part.sort_values("ts_epoch").reset_index(drop=True)
        right_part = right_groups.get(str(ticker))
        if right_part is None or right_part.empty:
            merged_parts.append(sorted_left)
            continue
        right_payload = right_part.drop(columns=["ticker"], errors="ignore")
        merged_parts.append(
            pd.merge_asof(
                sorted_left,
                right_payload,
                on="ts_epoch",
                direction="backward",
                allow_exact_matches=True,
            )
        )
    return pd.concat(merged_parts, ignore_index=True) if merged_parts else left


def _mask_bool(df: pd.DataFrame, column: str) -> pd.Series:
    return df[column].fillna(False).astype(bool) if column in df.columns else pd.Series(False, index=df.index, dtype=bool)


def _mask_ge(df: pd.DataFrame, column: str, threshold: float) -> pd.Series:
    if column not in df.columns:
        return pd.Series(False, index=df.index, dtype=bool)
    return pd.to_numeric(df[column], errors="coerce").ge(threshold).fillna(False)


def _mask_le(df: pd.DataFrame, column: str, threshold: float) -> pd.Series:
    if column not in df.columns:
        return pd.Series(False, index=df.index, dtype=bool)
    return pd.to_numeric(df[column], errors="coerce").le(threshold).fillna(False)


def build_context_specs(side: str) -> list[base.ConditionSpec]:
    specs: list[base.ConditionSpec] = [
        base.ConditionSpec("m5_trend_on", "m5 trend_regime = true", ("m5_trend_regime",), lambda d: _mask_bool(d, "m5_trend_regime")),
        base.ConditionSpec("m5_volume_confirm", "m5 volume_confirm = true", ("m5_volume_confirm",), lambda d: _mask_bool(d, "m5_volume_confirm")),
        base.ConditionSpec("m5_squeeze_off", "m5 squeeze_off = true", ("m5_squeeze_off",), lambda d: _mask_bool(d, "m5_squeeze_off")),
        base.ConditionSpec("m5_vwap<=-0.005", "m5_vwap_dist_pct <= -0.005", ("m5_vwap_dist_pct",), lambda d: _mask_le(d, "m5_vwap_dist_pct", -0.005)),
        base.ConditionSpec("m5_vwap<=-0.010", "m5_vwap_dist_pct <= -0.010", ("m5_vwap_dist_pct",), lambda d: _mask_le(d, "m5_vwap_dist_pct", -0.010)),
        base.ConditionSpec("m5_vwap>=0.005", "m5_vwap_dist_pct >= 0.005", ("m5_vwap_dist_pct",), lambda d: _mask_ge(d, "m5_vwap_dist_pct", 0.005)),
        base.ConditionSpec("m5_vwap>=0.010", "m5_vwap_dist_pct >= 0.010", ("m5_vwap_dist_pct",), lambda d: _mask_ge(d, "m5_vwap_dist_pct", 0.010)),
        base.ConditionSpec("m5_trix_neg", "m5_trix <= 0", ("m5_trix",), lambda d: _mask_le(d, "m5_trix", 0.0)),
        base.ConditionSpec("m5_trix_pos", "m5_trix >= 0", ("m5_trix",), lambda d: _mask_ge(d, "m5_trix", 0.0)),
        base.ConditionSpec("m5_rsi<=40", "m5_rsi <= 40", ("m5_rsi",), lambda d: _mask_le(d, "m5_rsi", 40.0)),
        base.ConditionSpec("m5_rsi<=45", "m5_rsi <= 45", ("m5_rsi",), lambda d: _mask_le(d, "m5_rsi", 45.0)),
        base.ConditionSpec("m5_rsi>=55", "m5_rsi >= 55", ("m5_rsi",), lambda d: _mask_ge(d, "m5_rsi", 55.0)),
        base.ConditionSpec("m5_rsi>=60", "m5_rsi >= 60", ("m5_rsi",), lambda d: _mask_ge(d, "m5_rsi", 60.0)),
        base.ConditionSpec("m5_td_buy>=5", "m5_td_buy_count >= 5", ("m5_td_buy_count",), lambda d: _mask_ge(d, "m5_td_buy_count", 5)),
        base.ConditionSpec("m5_td_sell>=5", "m5_td_sell_count >= 5", ("m5_td_sell_count",), lambda d: _mask_ge(d, "m5_td_sell_count", 5)),
        base.ConditionSpec("m5_ema_stack_bull", "m5_ema_stack_bull = true", ("m5_ema_stack_bull",), lambda d: _mask_bool(d, "m5_ema_stack_bull")),
        base.ConditionSpec("m5_ema_stack_bear", "m5_ema_stack_bear = true", ("m5_ema_stack_bear",), lambda d: _mask_bool(d, "m5_ema_stack_bear")),
        base.ConditionSpec("m5_mfi<=20", "m5_mfi <= 20", ("m5_mfi",), lambda d: _mask_le(d, "m5_mfi", 20.0)),
        base.ConditionSpec("m5_mfi>=80", "m5_mfi >= 80", ("m5_mfi",), lambda d: _mask_ge(d, "m5_mfi", 80.0)),
        base.ConditionSpec("m15_trend_on", "m15 trend_regime = true", ("m15_trend_regime",), lambda d: _mask_bool(d, "m15_trend_regime")),
        base.ConditionSpec("m15_volume_confirm", "m15 volume_confirm = true", ("m15_volume_confirm",), lambda d: _mask_bool(d, "m15_volume_confirm")),
        base.ConditionSpec("m15_squeeze_off", "m15 squeeze_off = true", ("m15_squeeze_off",), lambda d: _mask_bool(d, "m15_squeeze_off")),
        base.ConditionSpec("m15_vwap<=-0.005", "m15_vwap_dist_pct <= -0.005", ("m15_vwap_dist_pct",), lambda d: _mask_le(d, "m15_vwap_dist_pct", -0.005)),
        base.ConditionSpec("m15_vwap<=-0.010", "m15_vwap_dist_pct <= -0.010", ("m15_vwap_dist_pct",), lambda d: _mask_le(d, "m15_vwap_dist_pct", -0.010)),
        base.ConditionSpec("m15_vwap>=0.005", "m15_vwap_dist_pct >= 0.005", ("m15_vwap_dist_pct",), lambda d: _mask_ge(d, "m15_vwap_dist_pct", 0.005)),
        base.ConditionSpec("m15_vwap>=0.010", "m15_vwap_dist_pct >= 0.010", ("m15_vwap_dist_pct",), lambda d: _mask_ge(d, "m15_vwap_dist_pct", 0.010)),
        base.ConditionSpec("m15_trix_neg", "m15_trix <= 0", ("m15_trix",), lambda d: _mask_le(d, "m15_trix", 0.0)),
        base.ConditionSpec("m15_trix_pos", "m15_trix >= 0", ("m15_trix",), lambda d: _mask_ge(d, "m15_trix", 0.0)),
        base.ConditionSpec("m15_rsi<=40", "m15_rsi <= 40", ("m15_rsi",), lambda d: _mask_le(d, "m15_rsi", 40.0)),
        base.ConditionSpec("m15_rsi<=45", "m15_rsi <= 45", ("m15_rsi",), lambda d: _mask_le(d, "m15_rsi", 45.0)),
        base.ConditionSpec("m15_rsi>=55", "m15_rsi >= 55", ("m15_rsi",), lambda d: _mask_ge(d, "m15_rsi", 55.0)),
        base.ConditionSpec("m15_rsi>=60", "m15_rsi >= 60", ("m15_rsi",), lambda d: _mask_ge(d, "m15_rsi", 60.0)),
        base.ConditionSpec("m15_ema_stack_bull", "m15_ema_stack_bull = true", ("m15_ema_stack_bull",), lambda d: _mask_bool(d, "m15_ema_stack_bull")),
        base.ConditionSpec("m15_ema_stack_bear", "m15_ema_stack_bear = true", ("m15_ema_stack_bear",), lambda d: _mask_bool(d, "m15_ema_stack_bear")),
        base.ConditionSpec("m15_mfi<=20", "m15_mfi <= 20", ("m15_mfi",), lambda d: _mask_le(d, "m15_mfi", 20.0)),
        base.ConditionSpec("m15_mfi>=80", "m15_mfi >= 80", ("m15_mfi",), lambda d: _mask_ge(d, "m15_mfi", 80.0)),
    ]
    if side == "bullish":
        specs.extend(
            [
                base.ConditionSpec("m5_bb_lower", "m5_bb_close_outside_lower = true", ("m5_bb_close_outside_lower",), lambda d: _mask_bool(d, "m5_bb_close_outside_lower")),
                base.ConditionSpec("m5_full_below_lower", "m5_candle_completely_below_lower = true", ("m5_candle_completely_below_lower",), lambda d: _mask_bool(d, "m5_candle_completely_below_lower")),
                base.ConditionSpec("m15_bb_lower", "m15_bb_close_outside_lower = true", ("m15_bb_close_outside_lower",), lambda d: _mask_bool(d, "m15_bb_close_outside_lower")),
                base.ConditionSpec("m15_full_below_lower", "m15_candle_completely_below_lower = true", ("m15_candle_completely_below_lower",), lambda d: _mask_bool(d, "m15_candle_completely_below_lower")),
            ]
        )
    else:
        specs.extend(
            [
                base.ConditionSpec("m5_bb_upper", "m5_bb_close_outside_upper = true", ("m5_bb_close_outside_upper",), lambda d: _mask_bool(d, "m5_bb_close_outside_upper")),
                base.ConditionSpec("m5_full_above_upper", "m5_candle_completely_above_upper = true", ("m5_candle_completely_above_upper",), lambda d: _mask_bool(d, "m5_candle_completely_above_upper")),
                base.ConditionSpec("m15_bb_upper", "m15_bb_close_outside_upper = true", ("m15_bb_close_outside_upper",), lambda d: _mask_bool(d, "m15_bb_close_outside_upper")),
                base.ConditionSpec("m15_full_above_upper", "m15_candle_completely_above_upper = true", ("m15_candle_completely_above_upper",), lambda d: _mask_bool(d, "m15_candle_completely_above_upper")),
            ]
        )
    return specs


def build_summary(
    *,
    args: argparse.Namespace,
    split_date: date,
    total_rows: int,
    scorable_rows: int,
    bullish_base_count: int,
    bearish_base_count: int,
    bullish_base_rate: float,
    bearish_base_rate: float,
    bullish_results: Sequence[base.SearchResult],
    bearish_results: Sequence[base.SearchResult],
) -> str:
    lines = [
        f"# M1 Multi-Timeframe Option-Context Signal Mining - {args.end_date}",
        "",
        "- Scope: `public.ca` `m1` rows with merged `m5/m15` context plus real `option_candles` outcomes.",
        f"- Base profile: `{args.base_profile}`",
        (
            f"- Option contract: trigger `{args.trigger_pct:.2%}` within bars `+1` to `+3`, "
            f"target `{args.target_pct:.2%}` in `{args.target_window.replace('_', ' to +')}`, "
            f"hold `{args.hold_pct:.2%}` at bar `+{args.hold_bar}`, "
            f"max adverse `{args.max_adverse_pct:.2%}` in bars `+1` to `+3`, "
            f"momentum bar `{args.momentum_pct:.2%}` in bars `+1` to `+10`."
        ),
        f"- Validation split: rows dated `{split_date.isoformat()}` and later are holdout validation.",
        (
            f"- Search bar: `overall hit >= {args.target_hit:.0%}`, `n >= {args.min_n}`, `val n >= {args.min_val_n}`, "
            f"`tickers >= {args.min_tickers}`, `val tickers >= {args.min_val_tickers}`, "
            f"`wilson >= {args.min_wilson_lb:.2f}`, `val wilson >= {args.min_val_wilson_lb:.2f}`."
        ),
        "",
        "## Base Universe",
        "",
        f"- Total enriched `m1` rows loaded: `{total_rows}`",
        f"- Rows with scorable option tape on at least one side: `{scorable_rows}`",
        f"- Bullish base rows: `{bullish_base_count}` | base hit `{bullish_base_rate:.2%}`",
        f"- Bearish base rows: `{bearish_base_count}` | base hit `{bearish_base_rate:.2%}`",
        "",
        "## Top Bullish Families",
        "",
    ]
    if bullish_results:
        for result in bullish_results:
            lines.append(
                f"- `{' AND '.join(result.labels)}` | `n={result.count}` | tickers `{result.ticker_count}` | "
                f"hit `{result.success_rate:.2%}` | val `{result.val_success_rate:.2%}` | "
                f"wilson `{result.wilson_lb:.2%}` | val wilson `{result.val_wilson_lb:.2%}` | "
                f"trigger12 `{result.trigger12_rate:.2%}` | avg best `{result.avg_best_ret:.2%}` | hold `{result.avg_hold5_ret:.2%}`"
            )
    else:
        lines.append("- No bullish families cleared the configured bar.")
    lines.extend(["", "## Top Bearish Families", ""])
    if bearish_results:
        for result in bearish_results:
            lines.append(
                f"- `{' AND '.join(result.labels)}` | `n={result.count}` | tickers `{result.ticker_count}` | "
                f"hit `{result.success_rate:.2%}` | val `{result.val_success_rate:.2%}` | "
                f"wilson `{result.wilson_lb:.2%}` | val wilson `{result.val_wilson_lb:.2%}` | "
                f"trigger12 `{result.trigger12_rate:.2%}` | avg best `{result.avg_best_ret:.2%}` | hold `{result.avg_hold5_ret:.2%}`"
            )
    else:
        lines.append("- No bearish families cleared the configured bar.")
    return "\n".join(lines) + "\n"


def main() -> None:
    args = parse_args()
    env_defaults = base.load_env_defaults()
    start_date = parse_date(args.start_date)
    end_date = parse_date(args.end_date)
    split_date = end_date - timedelta(days=max(1, int(args.val_days)))
    tickers = parse_tickers(args.tickers)
    output_dir = (
        Path(args.output_dir)
        if str(args.output_dir or "").strip()
        else DEFAULT_OUTPUT_ROOT / f"m1_mtf_option_context_{args.base_profile}_{end_date.isoformat()}"
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    start_epoch = base.et_epoch(start_date, 0, 0)
    end_epoch = base.et_epoch(end_date + timedelta(days=1), 0, 0)
    start_dt = datetime(start_date.year, start_date.month, start_date.day, 0, 0)
    end_dt = datetime((end_date + timedelta(days=1)).year, (end_date + timedelta(days=1)).month, (end_date + timedelta(days=1)).day, 0, 0)

    conn = base.db_connect(args, env_defaults)
    try:
        history, base_query = base.load_history(conn, start_epoch=start_epoch, end_epoch=end_epoch)
        m5 = load_context(conn, start_epoch=start_epoch, end_epoch=end_epoch, timespan="m5")
        m15 = load_context(conn, start_epoch=start_epoch, end_epoch=end_epoch, timespan="m15")
        option_metrics, option_query = opt.load_option_metrics(
            conn,
            start_dt=start_dt,
            end_dt=end_dt,
            min_entry_price=float(args.min_entry_price),
            min_entry_volume=int(args.min_entry_volume),
            tickers=tickers,
        )
    finally:
        conn.close()

    history = base.add_group_features(history)
    history = merge_context(merge_context(history, m5, "m5"), m15, "m15")
    if tickers:
        ticker_set = {ticker.upper() for ticker in tickers}
        history = history.loc[history["ticker"].astype(str).str.upper().isin(ticker_set)].copy()
    merged = opt.attach_nearest_option_metrics(history, option_metrics)
    merged = opt.define_option_outcomes(
        merged,
        trigger_pct=float(args.trigger_pct),
        target_pct=float(args.target_pct),
        hold_pct=float(args.hold_pct),
        max_adverse_pct=float(args.max_adverse_pct),
        momentum_pct=float(args.momentum_pct),
        target_window=str(args.target_window),
        hold_bar=int(args.hold_bar),
    )
    merged["is_val"] = merged["date_dt"] >= split_date

    bullish_base = base.build_base_mask(merged, "bullish", args.base_profile)
    bearish_base = base.build_base_mask(merged, "bearish", args.base_profile)
    bullish_df = merged.loc[bullish_base & merged["bull_option_id"].notna()].copy().reset_index(drop=True)
    bearish_df = merged.loc[bearish_base & merged["bear_option_id"].notna()].copy().reset_index(drop=True)

    bullish_specs = list(base.build_specs("bullish")) + build_context_specs("bullish")
    bearish_specs = list(base.build_specs("bearish")) + build_context_specs("bearish")

    bullish_results = base.search_side(
        bullish_df,
        side="bullish",
        specs=bullish_specs,
        min_n=int(args.min_n),
        min_val_n=int(args.min_val_n),
        seed_hit=float(args.seed_hit),
        val_floor=float(args.val_floor),
        target_hit=float(args.target_hit),
        max_k=int(args.max_k),
        top_seeds=int(args.top_seeds),
        top_per_depth=int(args.top_per_depth),
        top_final=int(args.top_final),
        min_trigger12_rate=float(args.min_trigger12_rate),
        min_trigger1_rate=float(args.min_trigger1_rate),
        min_sustain75_rate=float(args.min_sustain75_rate),
        min_avg_best_ret=float(args.min_avg_best_ret),
        min_avg_hold5_ret=float(args.min_avg_hold5_ret),
        min_wilson_lb=float(args.min_wilson_lb),
        min_val_wilson_lb=float(args.min_val_wilson_lb),
        min_tickers=int(args.min_tickers),
        min_val_tickers=int(args.min_val_tickers),
    )
    bearish_results = base.search_side(
        bearish_df,
        side="bearish",
        specs=bearish_specs,
        min_n=int(args.min_n),
        min_val_n=int(args.min_val_n),
        seed_hit=float(args.seed_hit),
        val_floor=float(args.val_floor),
        target_hit=float(args.target_hit),
        max_k=int(args.max_k),
        top_seeds=int(args.top_seeds),
        top_per_depth=int(args.top_per_depth),
        top_final=int(args.top_final),
        min_trigger12_rate=float(args.min_trigger12_rate),
        min_trigger1_rate=float(args.min_trigger1_rate),
        min_sustain75_rate=float(args.min_sustain75_rate),
        min_avg_best_ret=float(args.min_avg_best_ret),
        min_avg_hold5_ret=float(args.min_avg_hold5_ret),
        min_wilson_lb=float(args.min_wilson_lb),
        min_val_wilson_lb=float(args.min_val_wilson_lb),
        min_tickers=int(args.min_tickers),
        min_val_tickers=int(args.min_val_tickers),
    )

    run_metadata = {
        "start_date": start_date.isoformat(),
        "end_date": end_date.isoformat(),
        "split_date": split_date.isoformat(),
        "base_profile": str(args.base_profile),
        "trigger_pct": float(args.trigger_pct),
        "target_pct": float(args.target_pct),
        "hold_pct": float(args.hold_pct),
        "max_adverse_pct": float(args.max_adverse_pct),
        "momentum_pct": float(args.momentum_pct),
        "target_window": str(args.target_window),
        "hold_bar": int(args.hold_bar),
        "tickers": tickers,
        "min_entry_price": float(args.min_entry_price),
        "min_entry_volume": int(args.min_entry_volume),
        "min_n": int(args.min_n),
        "min_val_n": int(args.min_val_n),
        "target_hit": float(args.target_hit),
        "seed_hit": float(args.seed_hit),
        "val_floor": float(args.val_floor),
        "min_trigger12_rate": float(args.min_trigger12_rate),
        "min_trigger1_rate": float(args.min_trigger1_rate),
        "min_sustain75_rate": float(args.min_sustain75_rate),
        "min_avg_best_ret": float(args.min_avg_best_ret),
        "min_avg_hold5_ret": float(args.min_avg_hold5_ret),
        "min_wilson_lb": float(args.min_wilson_lb),
        "min_val_wilson_lb": float(args.min_val_wilson_lb),
        "min_tickers": int(args.min_tickers),
        "min_val_tickers": int(args.min_val_tickers),
        "max_k": int(args.max_k),
        "top_seeds": int(args.top_seeds),
        "top_per_depth": int(args.top_per_depth),
        "top_final": int(args.top_final),
        "total_rows": int(len(merged)),
        "scorable_rows": int((merged["bull_option_id"].notna() | merged["bear_option_id"].notna()).sum()),
        "bullish_base_count": int(len(bullish_df)),
        "bearish_base_count": int(len(bearish_df)),
        "bullish_base_hit": float(bullish_df["bull_success"].mean()) if len(bullish_df) else 0.0,
        "bearish_base_hit": float(bearish_df["bear_success"].mean()) if len(bearish_df) else 0.0,
    }

    summary = build_summary(
        args=args,
        split_date=split_date,
        total_rows=int(len(merged)),
        scorable_rows=int((merged["bull_option_id"].notna() | merged["bear_option_id"].notna()).sum()),
        bullish_base_count=int(len(bullish_df)),
        bearish_base_count=int(len(bearish_df)),
        bullish_base_rate=float(bullish_df["bull_success"].mean()) if len(bullish_df) else 0.0,
        bearish_base_rate=float(bearish_df["bear_success"].mean()) if len(bearish_df) else 0.0,
        bullish_results=bullish_results,
        bearish_results=bearish_results,
    )

    (output_dir / "run_metadata.json").write_text(json.dumps(run_metadata, indent=2), encoding="utf-8")
    (output_dir / "base_query.sql").write_text(base_query + "\n", encoding="utf-8")
    (output_dir / "option_metric_query.sql").write_text(option_query + "\n", encoding="utf-8")
    (output_dir / "m5_query.sql").write_text(build_context_query(start_epoch=start_epoch, end_epoch=end_epoch, timespan="m5") + "\n", encoding="utf-8")
    (output_dir / "m15_query.sql").write_text(build_context_query(start_epoch=start_epoch, end_epoch=end_epoch, timespan="m15") + "\n", encoding="utf-8")
    (output_dir / "summary.md").write_text(summary, encoding="utf-8")
    base.write_dataframe(output_dir / "bullish_findings.csv", bullish_results)
    base.write_dataframe(output_dir / "bearish_findings.csv", bearish_results)

    print(summary)
    print(f"Artifacts written to {output_dir}")


if __name__ == "__main__":
    main()
