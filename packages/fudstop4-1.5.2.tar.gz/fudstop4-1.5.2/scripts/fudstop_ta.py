from fudstop4.apis._ta.ta_sdk import (
    FudstopTA as _FudstopTA,
    _ema_njit,
    _true_range_numba,
    _wilder_smooth_njit,
)


def _true_range(high, low, close):
    return _true_range_numba(high, low, close)


def _wilder_smooth(values, window):
    return _wilder_smooth_njit(values, window)


_FudstopTA._true_range = staticmethod(_true_range)
_FudstopTA._wilder_smooth = staticmethod(_wilder_smooth)
_FudstopTA.ema_njit = staticmethod(_ema_njit)

FudstopTA = _FudstopTA

__all__ = ["FudstopTA"]
