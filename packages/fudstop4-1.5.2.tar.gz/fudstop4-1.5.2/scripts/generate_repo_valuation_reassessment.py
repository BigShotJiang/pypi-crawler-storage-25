from __future__ import annotations

import argparse
import asyncio
import ast
import importlib.util
import json
import os
import subprocess
import sys
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from fudstop4.apis.polygonio.polygon_options import PolygonOptions


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_METRICS_PATH = REPO_ROOT / "tmp" / "pdfs" / "repo_valuation_metrics_v3.json"
DEFAULT_CATALOG_PATH = REPO_ROOT / "output" / "reports" / "marketing_product_catalog_498.json"
DEFAULT_LEGACY_SCRIPT_PATH = REPO_ROOT / "scripts" / "generate_repo_valuation_report.py"
DEFAULT_WEBHOOK_ROUTES_PATH = REPO_ROOT / "stock_market_site" / "app" / "routes" / "webhookroutes.py"
DEFAULT_OUTPUT_JSON = REPO_ROOT / "output" / "reports" / "fudstop_valuation_reassessment.json"
DEFAULT_OUTPUT_MD = REPO_ROOT / "output" / "reports" / "fudstop_valuation_reassessment.md"
DEFAULT_INTERNAL_EMAILS = ("chuckdustin12@gmail.com",)
LIVE_STATUSES = {"active", "trialing", "paid"}
TRACTION_MULTIPLES = {"low": 1.5, "mid": 2.25, "high": 3.0}
RISK_HAIRCUT = 0.20


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def money(value: float) -> str:
    return f"${value:,.2f}"


def round_money(value: float) -> float:
    return round(float(value), 2)


def env_db_config(database: str) -> dict[str, Any]:
    return {
        "host": os.environ.get("DB_HOST", "localhost"),
        "port": int(os.environ.get("DB_PORT", "5432")),
        "user": os.environ.get("DB_USER", "chuck"),
        "password": os.environ.get("DB_PASSWORD", "fud"),
        "database": database or os.environ.get("DB_NAME", "fudstop3"),
    }


def ensure_jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return ensure_jsonable(asdict(value))
    if isinstance(value, dict):
        return {str(key): ensure_jsonable(val) for key, val in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [ensure_jsonable(item) for item in value]
    if isinstance(value, datetime):
        return value.isoformat()
    if hasattr(value, "quantize") or value.__class__.__name__ == "Decimal":
        return round_money(value)
    return value


def load_json(path: Path) -> dict[str, Any] | list[Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_legacy_module(script_path: Path):
    spec = importlib.util.spec_from_file_location("fudstop_legacy_valuation", script_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load legacy valuation script: {script_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def resolve_ast_literal(node: ast.AST | None, symbols: dict[str, Any]) -> Any:
    if node is None:
        return None
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name):
        return symbols.get(node.id)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        value = resolve_ast_literal(node.operand, symbols)
        if isinstance(value, (int, float)):
            return -value
    return None


def parse_webhook_feed_prices(route_path: Path) -> dict[str, float]:
    tree = ast.parse(route_path.read_text(encoding="utf-8"), filename=str(route_path))
    symbols: dict[str, Any] = {}

    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    resolved = resolve_ast_literal(node.value, symbols)
                    if resolved is not None:
                        symbols[target.id] = resolved
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            resolved = resolve_ast_literal(node.value, symbols)
            if resolved is not None:
                symbols[node.target.id] = resolved

    feed_prices: dict[str, float] = {}
    for node in tree.body:
        value_node: ast.AST | None = None
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "WEBHOOK_FEEDS":
                    value_node = node.value
                    break
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id == "WEBHOOK_FEEDS":
            value_node = node.value

        if not isinstance(value_node, ast.List):
            continue

        for item in value_node.elts:
            if not isinstance(item, ast.Call):
                continue
            if not isinstance(item.func, ast.Name) or item.func.id != "WebhookFeed":
                continue
            kwargs = {kw.arg: resolve_ast_literal(kw.value, symbols) for kw in item.keywords if kw.arg}
            feed_id = kwargs.get("feed_id")
            price = kwargs.get("price_usd_month")
            if isinstance(feed_id, str) and isinstance(price, (int, float)):
                feed_prices[feed_id] = float(price)
        break

    if not feed_prices:
        raise RuntimeError(f"Unable to parse webhook feed pricing from {route_path}")
    return feed_prices


def catalog_stats(catalog_path: Path) -> dict[str, Any]:
    items = load_json(catalog_path)
    if not isinstance(items, list):
        raise RuntimeError(f"Catalog file did not contain a list: {catalog_path}")

    active_items = [item for item in items if isinstance(item, dict) and item.get("active")]
    monthly_prices = [float(item.get("monthly_price_usd") or 0.0) for item in active_items]
    setup_fees = [float(item.get("setup_fee_usd") or 0.0) for item in active_items]
    categories = sorted({str(item.get("category") or "Unknown") for item in active_items})

    if not active_items or not monthly_prices:
        raise RuntimeError(f"No active catalog items found in {catalog_path}")

    sorted_monthly = sorted(monthly_prices)
    midpoint_index = len(sorted_monthly) // 2
    return {
        "active_skus": len(active_items),
        "category_count": len(categories),
        "categories": categories,
        "monthly_price_min": round_money(min(monthly_prices)),
        "monthly_price_max": round_money(max(monthly_prices)),
        "monthly_price_avg": round_money(sum(monthly_prices) / len(monthly_prices)),
        "monthly_price_median_like": round_money(sorted_monthly[midpoint_index]),
        "setup_fee_avg": round_money(sum(setup_fees) / len(setup_fees)),
    }


def is_archival_path(path: Path) -> bool:
    lowered_parts = [part.lower() for part in path.parts]
    return any("old" in part for part in lowered_parts)


def tracked_app_files(repo_root: Path) -> list[Path]:
    result = subprocess.run(
        ["git", "ls-files", "stock_market_site/app", "stock_market_site/templates"],
        cwd=repo_root,
        check=True,
        capture_output=True,
        text=True,
    )
    files: list[Path] = []
    for raw in result.stdout.splitlines():
        stripped = raw.strip()
        if not stripped:
            continue
        path = repo_root / stripped
        if path.is_file() and not is_archival_path(path):
            files.append(path)
    return files


def scan_operational_risk(repo_root: Path) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    total_markers = 0
    scanned_files = tracked_app_files(repo_root)

    for path in scanned_files:
        marker_lines: list[dict[str, Any]] = []
        with path.open("r", encoding="utf-8", errors="ignore") as handle:
            for line_no, line in enumerate(handle, start=1):
                stripped = line.lstrip()
                if stripped.startswith("<<<<<<<") or stripped.startswith("=======") or stripped.startswith(">>>>>>>"):
                    marker_lines.append({"line": line_no, "marker": stripped.strip()})
        if marker_lines:
            total_markers += len(marker_lines)
            findings.append(
                {
                    "path": str(path.relative_to(repo_root)),
                    "marker_count": len(marker_lines),
                    "markers": marker_lines[:12],
                }
            )

    return {
        "scanned_file_count": len(scanned_files),
        "conflict_file_count": len(findings),
        "marker_count": total_markers,
        "haircut_applied": bool(findings),
        "haircut_rate": RISK_HAIRCUT if findings else 0.0,
        "findings": findings,
    }


def mask_email(value: str | None) -> str:
    if not value or "@" not in value:
        return value or ""
    local, domain = value.split("@", 1)
    if len(local) <= 2:
        masked_local = local[:1] + "*"
    else:
        masked_local = local[:1] + ("*" * max(1, len(local) - 2)) + local[-1:]
    return f"{masked_local}@{domain}"


def is_live_subscription(row: dict[str, Any], now_utc: datetime) -> bool:
    status = str(row.get("status") or "").strip().lower()
    if status in LIVE_STATUSES:
        return True

    subscription_id = str(row.get("stripe_subscription_id") or "").strip()
    period_end = row.get("current_period_end")
    if subscription_id and isinstance(period_end, datetime):
        compare_dt = period_end if period_end.tzinfo else period_end.replace(tzinfo=timezone.utc)
        return compare_dt > now_utc
    return False


async def load_live_snapshot(
    db_name: str,
    internal_emails: set[str],
    webhook_feed_prices: dict[str, float],
) -> dict[str, Any]:
    db = PolygonOptions(**env_db_config(db_name))
    await db.connect()
    try:
        now_utc = datetime.now(timezone.utc)

        members_overview_rows = await db.fetch_new(
            """
            SELECT
                COUNT(*) AS total_members,
                COUNT(*) FILTER (WHERE COALESCE(subscription_active, FALSE)) AS active_members_flagged,
                COUNT(*) FILTER (WHERE verified IS TRUE) AS verified_members,
                COUNT(*) FILTER (WHERE COALESCE(subscription_tier, '') <> '') AS tiered_members
            FROM members
            """
        )
        member_tier_rows = await db.fetch_new(
            """
            SELECT COALESCE(subscription_tier, '(blank)') AS subscription_tier, COUNT(*) AS count
            FROM members
            GROUP BY 1
            ORDER BY count DESC, subscription_tier
            """
        )
        webhook_rows = await db.fetch_new(
            """
            SELECT
                id,
                feed_id,
                email,
                status,
                price_usd_month,
                stripe_session_id,
                stripe_subscription_id,
                stripe_customer_id,
                current_period_end,
                created_at,
                updated_at,
                source,
                custom_order_uid,
                attribute_filters_json
            FROM webhook_subscriptions
            ORDER BY created_at DESC NULLS LAST, id DESC
            """
        )
    finally:
        await db.close()

    members_overview = ensure_jsonable(dict(members_overview_rows[0])) if members_overview_rows else {}
    member_tiers = [ensure_jsonable(dict(row)) for row in member_tier_rows]

    normalized_rows: list[dict[str, Any]] = []
    missing_price_backfills = 0
    raw_active_like_count = 0
    internal_live_like_count = 0
    external_live_like_count = 0
    pending_count = 0
    pending_live_count = 0

    for raw in webhook_rows:
        row = dict(raw)
        email = str(row.get("email") or "").strip().lower()
        status = str(row.get("status") or "").strip().lower()
        price = row.get("price_usd_month")
        filled_price = float(price) if price is not None else webhook_feed_prices.get(str(row.get("feed_id") or "").strip())
        if price is None and filled_price is not None:
            missing_price_backfills += 1

        live_revenue = is_live_subscription(row, now_utc)
        is_internal = email in internal_emails

        if status in LIVE_STATUSES or (
            str(row.get("stripe_subscription_id") or "").strip()
            and isinstance(row.get("current_period_end"), datetime)
            and ((row["current_period_end"] if row["current_period_end"].tzinfo else row["current_period_end"].replace(tzinfo=timezone.utc)) > now_utc)
        ):
            raw_active_like_count += 1
        if live_revenue and is_internal:
            internal_live_like_count += 1
        if live_revenue and not is_internal:
            external_live_like_count += 1
        if status == "pending":
            pending_count += 1
            if live_revenue:
                pending_live_count += 1

        normalized_rows.append(
            {
                "id": row.get("id"),
                "feed_id": row.get("feed_id"),
                "email": mask_email(row.get("email")),
                "status": row.get("status"),
                "source": row.get("source"),
                "is_internal": is_internal,
                "is_live_revenue": live_revenue,
                "filled_price_usd_month": round_money(filled_price or 0.0) if filled_price is not None else None,
                "stripe_session_id_present": bool(row.get("stripe_session_id")),
                "stripe_subscription_id_present": bool(row.get("stripe_subscription_id")),
                "current_period_end": ensure_jsonable(row.get("current_period_end")),
                "created_at": ensure_jsonable(row.get("created_at")),
                "updated_at": ensure_jsonable(row.get("updated_at")),
            }
        )

    external_live_rows = [row for row in normalized_rows if row["is_live_revenue"] and not row["is_internal"]]
    external_live_emails = sorted({row["email"] for row in external_live_rows if row["email"]})
    external_mrr = round_money(sum(float(row["filled_price_usd_month"] or 0.0) for row in external_live_rows))
    external_arr = round_money(external_mrr * 12.0)

    return {
        "members": {
            "overview": members_overview,
            "tiers": member_tiers,
        },
        "webhook_subscriptions": {
            "row_count": len(normalized_rows),
            "raw_active_like_count": raw_active_like_count,
            "internal_live_like_count": internal_live_like_count,
            "external_live_like_count": external_live_like_count,
            "external_customer_count": len(external_live_emails),
            "external_customer_emails_masked": external_live_emails,
            "external_mrr": external_mrr,
            "external_arr": external_arr,
            "pending_count": pending_count,
            "pending_live_count": pending_live_count,
            "missing_price_backfills": missing_price_backfills,
            "rows": normalized_rows,
        },
    }


def build_validations(
    legacy_baseline: dict[str, Any],
    live_snapshot: dict[str, Any],
    operational_risk: dict[str, Any],
    revised: dict[str, Any],
) -> dict[str, Any]:
    subscriptions = live_snapshot["webhook_subscriptions"]
    internal_live_like_count = int(subscriptions["internal_live_like_count"])
    pending_count = int(subscriptions["pending_count"])
    pending_live_count = int(subscriptions["pending_live_count"])

    def status_for(condition: bool, message: str, na: bool = False) -> dict[str, Any]:
        return {
            "status": "not_applicable" if na else ("passed" if condition else "failed"),
            "message": message,
        }

    return {
        "legacy_baseline_loaded": status_for(
            float(legacy_baseline["midpoint"]) > 0,
            "Legacy repo valuation baseline loaded and produced a positive midpoint.",
        ),
        "internal_rows_excluded_from_traction": status_for(
            int(subscriptions["external_live_like_count"]) == 0 if internal_live_like_count else True,
            "Internal live-like rows were excluded from external customer traction.",
            na=internal_live_like_count == 0,
        ),
        "missing_prices_backfilled": status_for(
            int(subscriptions["missing_price_backfills"]) > 0,
            "Missing subscription prices were backfilled from the webhook feed map.",
            na=int(subscriptions["missing_price_backfills"]) == 0,
        ),
        "pending_rows_excluded_from_revenue": status_for(
            pending_live_count == 0,
            "Pending rows did not contribute to live revenue.",
            na=pending_count == 0,
        ),
        "merge_markers_trigger_haircut": status_for(
            (operational_risk["conflict_file_count"] > 0 and revised["haircut_applied"])
            or (operational_risk["conflict_file_count"] == 0 and not revised["haircut_applied"]),
            "Operational-risk scan and haircut application were consistent.",
        ),
        "report_sections_present": status_for(
            legacy_baseline.get("midpoint") is not None
            and live_snapshot.get("webhook_subscriptions") is not None
            and operational_risk.get("findings") is not None
            and revised.get("legacy_baseline") is not None
            and revised.get("traction") is not None
            and revised.get("valuation") is not None
            and revised.get("ask_band") is not None,
            "Reassessment output includes all required sections.",
        ),
    }


def build_revised_valuation(
    legacy_models: dict[str, Any],
    live_snapshot: dict[str, Any],
    operational_risk: dict[str, Any],
) -> dict[str, Any]:
    replacement = legacy_models["replacement_scenarios"]
    strategic = legacy_models["strategic"]
    legacy_recon = legacy_models["reconciliation"]
    haircut_rate = operational_risk["haircut_rate"]
    multiplier = 1.0 - haircut_rate

    adjusted_replacement = {
        "low": round_money(replacement[0].as_is_value * multiplier),
        "mid": round_money(replacement[1].as_is_value * multiplier),
        "high": round_money(replacement[2].as_is_value * multiplier),
    }
    adjusted_strategic = {
        "low": round_money(strategic["premium_low"] * multiplier),
        "mid": round_money(strategic["premium_mid"] * multiplier),
        "high": round_money(strategic["premium_high"] * multiplier),
    }

    arr = float(live_snapshot["webhook_subscriptions"]["external_arr"])
    traction = {
        "arr": round_money(arr),
        "low": round_money(arr * TRACTION_MULTIPLES["low"]),
        "mid": round_money(arr * TRACTION_MULTIPLES["mid"]),
        "high": round_money(arr * TRACTION_MULTIPLES["high"]),
    }

    valuation = {
        "low": round_money((0.70 * adjusted_replacement["low"]) + (0.20 * adjusted_strategic["low"]) + (0.10 * traction["low"])),
        "mid": round_money((0.70 * adjusted_replacement["mid"]) + (0.20 * adjusted_strategic["mid"]) + (0.10 * traction["mid"])),
        "high": round_money((0.70 * adjusted_replacement["high"]) + (0.20 * adjusted_strategic["high"]) + (0.10 * traction["high"])),
    }
    ask_band = {
        "low": round_money(valuation["mid"] * 0.90),
        "high": round_money(valuation["mid"] * 1.20),
    }

    return {
        "haircut_applied": bool(haircut_rate),
        "haircut_rate": haircut_rate,
        "legacy_baseline": {
            "midpoint": round_money(legacy_recon["as_is_mid"]),
            "ask_low": round_money(legacy_recon["suggested_ask_low"]),
            "ask_high": round_money(legacy_recon["suggested_ask_high"]),
        },
        "adjusted_replacement": adjusted_replacement,
        "adjusted_strategic": adjusted_strategic,
        "traction": traction,
        "valuation": valuation,
        "ask_band": ask_band,
        "narrative": "codebase-rich, commercialization-thin",
    }


def markdown_table(headers: list[str], rows: list[list[str]]) -> str:
    header_line = "| " + " | ".join(headers) + " |"
    divider = "| " + " | ".join(["---"] * len(headers)) + " |"
    body = "\n".join("| " + " | ".join(row) + " |" for row in rows)
    return "\n".join([header_line, divider, body]).strip()


def render_markdown_report(payload: dict[str, Any]) -> str:
    legacy = payload["legacy_baseline"]
    live_snapshot = payload["live_snapshot"]
    subscriptions = live_snapshot["webhook_subscriptions"]
    catalog = payload["catalog"]
    risk = payload["operational_risk"]
    revised = payload["revised_valuation"]
    validation = payload["validation_checks"]

    summary_rows = [
        ["Legacy midpoint", money(legacy["midpoint"])],
        ["Legacy ask band", f"{money(legacy['ask_low'])} to {money(legacy['ask_high'])}"],
        ["Strict external MRR", money(subscriptions["external_mrr"])],
        ["Strict external ARR", money(subscriptions["external_arr"])],
        ["Revised midpoint", money(revised["valuation"]["mid"])],
        ["Revised ask band", f"{money(revised['ask_band']['low'])} to {money(revised['ask_band']['high'])}"],
    ]
    value_rows = [
        ["Low", money(revised["adjusted_replacement"]["low"]), money(revised["adjusted_strategic"]["low"]), money(revised["traction"]["low"]), money(revised["valuation"]["low"])],
        ["Mid", money(revised["adjusted_replacement"]["mid"]), money(revised["adjusted_strategic"]["mid"]), money(revised["traction"]["mid"]), money(revised["valuation"]["mid"])],
        ["High", money(revised["adjusted_replacement"]["high"]), money(revised["adjusted_strategic"]["high"]), money(revised["traction"]["high"]), money(revised["valuation"]["high"])],
    ]
    validation_rows = [[name, details["status"], details["message"]] for name, details in validation.items()]
    risk_files = risk["findings"][:8]

    lines = [
        "# FUDSTOP Valuation Reassessment",
        "",
        f"Generated: {payload['generated_at']}",
        "",
        "## Executive Summary",
        "",
        revised["narrative"] + ".",
        "",
        markdown_table(["Metric", "Value"], summary_rows),
        "",
        "## Live Traction Snapshot",
        "",
        f"- Members in table: {live_snapshot['members']['overview'].get('total_members', 0)}",
        f"- Verified members: {live_snapshot['members']['overview'].get('verified_members', 0)}",
        f"- Member rows flagged active: {live_snapshot['members']['overview'].get('active_members_flagged', 0)}",
        f"- Webhook subscription rows: {subscriptions['row_count']}",
        f"- Raw live-like webhook rows: {subscriptions['raw_active_like_count']}",
        f"- Internal live-like rows excluded: {subscriptions['internal_live_like_count']}",
        f"- External live-like webhook rows: {subscriptions['external_live_like_count']}",
        f"- Distinct external customers: {subscriptions['external_customer_count']}",
        f"- Missing subscription prices backfilled: {subscriptions['missing_price_backfills']}",
        "",
        "## Product Surface",
        "",
        f"- Active catalog SKUs: {catalog['active_skus']}",
        f"- Catalog categories: {catalog['category_count']}",
        f"- Average monthly price: {money(catalog['monthly_price_avg'])}",
        f"- Median-like monthly price: {money(catalog['monthly_price_median_like'])}",
        f"- Price range: {money(catalog['monthly_price_min'])} to {money(catalog['monthly_price_max'])}",
        f"- Average setup fee: {money(catalog['setup_fee_avg'])}",
        "",
        "## Operational Risk",
        "",
        f"- Tracked app/template files scanned: {risk['scanned_file_count']}",
        f"- Conflict files found: {risk['conflict_file_count']}",
        f"- Merge markers found: {risk['marker_count']}",
        f"- Haircut applied: {'yes' if revised['haircut_applied'] else 'no'} ({int(revised['haircut_rate'] * 100)}%)",
        "",
    ]

    if risk_files:
        lines.extend(
            [
                "### Conflict Files",
                "",
                *[f"- `{item['path']}` ({item['marker_count']} markers)" for item in risk_files],
                "",
            ]
        )

    lines.extend(
        [
            "## Revised Valuation",
            "",
            markdown_table(
                ["Scenario", "Adjusted Replacement", "Adjusted Strategic", "Traction", "Final Value"],
                value_rows,
            ),
            "",
            "## Validation Checks",
            "",
            markdown_table(["Check", "Status", "Detail"], validation_rows),
            "",
            "## Assumptions",
            "",
            "- Founder/internal rows are excluded from customer traction by default email exclusions.",
            "- Pending webhook rows do not count toward revenue.",
            "- Member-table subscription flags are informational only unless matched by live paid subscription evidence.",
            "- Merge markers in tracked non-archival app files trigger a 20% haircut on replacement and strategic components.",
            "- The legacy repo valuation model remains the baseline reference, unchanged.",
            "",
        ]
    )
    return "\n".join(lines).strip() + "\n"


async def build_reassessment(args: argparse.Namespace) -> dict[str, Any]:
    load_dotenv(REPO_ROOT / ".env", override=False)
    load_dotenv(REPO_ROOT / "stock_market_site" / ".env", override=True)
    load_dotenv(REPO_ROOT / "stock_market_site" / "app" / ".env", override=True)

    legacy_module = load_legacy_module(args.legacy_script)
    metrics = legacy_module.load_metrics(args.metrics)
    legacy_models = legacy_module.compute_models(metrics)
    legacy_recon = legacy_models["reconciliation"]
    legacy_baseline = {
        "midpoint": round_money(legacy_recon["as_is_mid"]),
        "ask_low": round_money(legacy_recon["suggested_ask_low"]),
        "ask_high": round_money(legacy_recon["suggested_ask_high"]),
        "replacement_scenarios": ensure_jsonable([asdict(item) for item in legacy_models["replacement_scenarios"]]),
        "revenue_scenarios": ensure_jsonable([asdict(item) for item in legacy_models["revenue_scenarios"]]),
        "strategic": ensure_jsonable(legacy_models["strategic"]),
        "frontend_effort": ensure_jsonable(legacy_models["frontend_effort"]),
        "weighted_commercialized_mid": round_money(legacy_models["weighted_commercialized_mid"]),
        "income_option_value": round_money(legacy_models["income_option_value"]),
        "monetization_readiness_score": round(float(legacy_models["monetization_readiness_score"]), 4),
    }

    webhook_feed_prices = parse_webhook_feed_prices(args.webhook_routes)
    live_snapshot = await load_live_snapshot(args.database, set(email.lower() for email in args.internal_email), webhook_feed_prices)
    operational_risk = scan_operational_risk(REPO_ROOT)
    catalog = catalog_stats(args.catalog)
    revised_valuation = build_revised_valuation(legacy_models, live_snapshot, operational_risk)
    validation_checks = build_validations(legacy_baseline, live_snapshot, operational_risk, revised_valuation)

    return {
        "generated_at": utc_now_iso(),
        "report_date": args.report_date,
        "inputs": {
            "metrics_path": str(args.metrics),
            "catalog_path": str(args.catalog),
            "legacy_script_path": str(args.legacy_script),
            "webhook_routes_path": str(args.webhook_routes),
            "database": args.database,
            "internal_email_exclusions": list(args.internal_email),
        },
        "legacy_baseline": legacy_baseline,
        "catalog": catalog,
        "live_snapshot": live_snapshot,
        "operational_risk": operational_risk,
        "revised_valuation": revised_valuation,
        "validation_checks": validation_checks,
    }


def write_outputs(payload: dict[str, Any], output_json: Path, output_md: Path) -> None:
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(ensure_jsonable(payload), indent=2), encoding="utf-8")
    output_md.write_text(render_markdown_report(ensure_jsonable(payload)), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate a traction-weighted valuation reassessment for FUDSTOP.")
    parser.add_argument("--metrics", type=Path, default=DEFAULT_METRICS_PATH)
    parser.add_argument("--catalog", type=Path, default=DEFAULT_CATALOG_PATH)
    parser.add_argument("--legacy-script", type=Path, default=DEFAULT_LEGACY_SCRIPT_PATH)
    parser.add_argument("--webhook-routes", type=Path, default=DEFAULT_WEBHOOK_ROUTES_PATH)
    parser.add_argument("--output-json", type=Path, default=DEFAULT_OUTPUT_JSON)
    parser.add_argument("--output-md", type=Path, default=DEFAULT_OUTPUT_MD)
    parser.add_argument("--database", type=str, default="fudstop3")
    parser.add_argument(
        "--internal-email",
        action="append",
        default=list(DEFAULT_INTERNAL_EMAILS),
        help="Email addresses to exclude from customer traction. Can be passed more than once.",
    )
    parser.add_argument("--report-date", type=str, default=datetime.now().strftime("%B %d, %Y"))
    return parser.parse_args()


async def async_main() -> None:
    args = parse_args()
    payload = await build_reassessment(args)
    write_outputs(payload, args.output_json, args.output_md)
    print(str(args.output_json))
    print(str(args.output_md))


def main() -> None:
    asyncio.run(async_main())


if __name__ == "__main__":
    main()
