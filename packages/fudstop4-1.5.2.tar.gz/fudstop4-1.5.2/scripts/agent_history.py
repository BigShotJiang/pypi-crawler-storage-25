from __future__ import annotations

import argparse
import json
import subprocess
import sys
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo


BASE_DIR = Path(__file__).resolve().parents[1]
HISTORY_DIR = BASE_DIR / "tmp" / "agent_history"
HISTORY_FILE = HISTORY_DIR / "history.jsonl"
CURRENT_JSON_FILE = HISTORY_DIR / "current.json"
CURRENT_MD_FILE = HISTORY_DIR / "current.md"
TIMEZONE_ET = ZoneInfo("America/New_York")


@dataclass
class HistoryEntry:
    entry_id: str
    created_at_et: str
    created_at_utc: str
    branch: str
    cwd: str
    task: str
    summary: str
    status: str
    tags: list[str]
    files: list[str]
    open_items: list[str]
    next_steps: list[str]
    notes: str


def _now_et() -> datetime:
    return datetime.now(TIMEZONE_ET).replace(microsecond=0)


def _now_utc() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


def _git_branch() -> str:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            check=True,
        )
        branch = result.stdout.strip()
        return branch or "unknown"
    except Exception:
        return "unknown"


def _dedupe(values: list[str] | None) -> list[str]:
    if not values:
        return []
    seen: set[str] = set()
    ordered: list[str] = []
    for value in values:
        item = value.strip()
        if not item or item in seen:
            continue
        seen.add(item)
        ordered.append(item)
    return ordered


def _ensure_store() -> None:
    HISTORY_DIR.mkdir(parents=True, exist_ok=True)
    if not HISTORY_FILE.exists():
        HISTORY_FILE.write_text("", encoding="utf-8")


def _read_entries() -> list[dict[str, Any]]:
    if not HISTORY_FILE.exists():
        return []
    entries: list[dict[str, Any]] = []
    for raw_line in HISTORY_FILE.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line:
            continue
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return entries


def _format_entry_markdown(entry: dict[str, Any]) -> str:
    lines = [
        "# Current Work Context",
        "",
        f"- Updated: `{entry['created_at_et']}`",
        f"- Status: `{entry['status']}`",
        f"- Branch: `{entry['branch']}`",
        f"- Task: `{entry['task']}`",
        "",
        "## Summary",
        entry["summary"],
        "",
    ]
    if entry.get("tags"):
        lines.extend(
            [
                "## Tags",
                ", ".join(entry["tags"]),
                "",
            ]
        )
    if entry.get("files"):
        lines.append("## Files")
        lines.extend(f"- `{item}`" for item in entry["files"])
        lines.append("")
    if entry.get("open_items"):
        lines.append("## Open Items")
        lines.extend(f"- {item}" for item in entry["open_items"])
        lines.append("")
    if entry.get("next_steps"):
        lines.append("## Next Steps")
        lines.extend(f"- {item}" for item in entry["next_steps"])
        lines.append("")
    if entry.get("notes"):
        lines.extend(
            [
                "## Notes",
                entry["notes"],
                "",
            ]
        )
    return "\n".join(lines).rstrip() + "\n"


def _format_entry_text(entry: dict[str, Any]) -> str:
    lines = [
        f"[{entry['created_at_et']}] {entry['status']} | {entry['task']}",
        f"Branch: {entry['branch']}",
        f"Summary: {entry['summary']}",
    ]
    if entry.get("tags"):
        lines.append(f"Tags: {', '.join(entry['tags'])}")
    if entry.get("files"):
        lines.append(f"Files: {', '.join(entry['files'])}")
    if entry.get("open_items"):
        lines.append("Open items:")
        lines.extend(f"  - {item}" for item in entry["open_items"])
    if entry.get("next_steps"):
        lines.append("Next steps:")
        lines.extend(f"  - {item}" for item in entry["next_steps"])
    if entry.get("notes"):
        lines.append(f"Notes: {entry['notes']}")
    return "\n".join(lines)


def _build_entry(args: argparse.Namespace) -> HistoryEntry:
    now_et = _now_et()
    now_utc = _now_utc()
    return HistoryEntry(
        entry_id=f"{now_utc.strftime('%Y%m%dT%H%M%SZ')}-{uuid.uuid4().hex[:8]}",
        created_at_et=now_et.isoformat(),
        created_at_utc=now_utc.isoformat(),
        branch=_git_branch(),
        cwd=str(BASE_DIR),
        task=args.task.strip(),
        summary=args.summary.strip(),
        status=args.status,
        tags=_dedupe(args.tag),
        files=_dedupe(args.file),
        open_items=_dedupe(args.open_item),
        next_steps=_dedupe(args.next_step),
        notes=(args.notes or "").strip(),
    )


def save_entry(args: argparse.Namespace) -> int:
    _ensure_store()
    entry = asdict(_build_entry(args))
    with HISTORY_FILE.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=True) + "\n")
    CURRENT_JSON_FILE.write_text(json.dumps(entry, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    CURRENT_MD_FILE.write_text(_format_entry_markdown(entry), encoding="utf-8")
    print(_format_entry_text(entry))
    return 0


def latest_entry(args: argparse.Namespace) -> int:
    entries = _read_entries()
    if not entries:
        print("No history entries found.", file=sys.stderr)
        return 1
    entry = entries[-1]
    if args.output == "json":
        print(json.dumps(entry, indent=2, ensure_ascii=True))
    else:
        print(_format_entry_text(entry))
    return 0


def list_entries(args: argparse.Namespace) -> int:
    entries = _read_entries()
    if not entries:
        print("No history entries found.", file=sys.stderr)
        return 1
    limit = max(args.limit, 1)
    chosen = entries[-limit:]
    if args.output == "json":
        print(json.dumps(chosen, indent=2, ensure_ascii=True))
        return 0
    for index, entry in enumerate(reversed(chosen), start=1):
        print(f"{index}. {_format_entry_text(entry)}")
        if index != len(chosen):
            print("")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Persist and review current agent work context for the FUDSTOP workspace.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    save_parser = subparsers.add_parser("save", help="Append a new history entry and update the current snapshot.")
    save_parser.add_argument("--task", required=True, help="Short task title.")
    save_parser.add_argument("--summary", required=True, help="Short current-state summary.")
    save_parser.add_argument(
        "--status",
        choices=["active", "blocked", "done"],
        default="active",
        help="Current task status.",
    )
    save_parser.add_argument("--tag", action="append", help="Tag to attach to the history entry.")
    save_parser.add_argument("--file", action="append", help="Workspace file related to the task.")
    save_parser.add_argument("--open-item", action="append", help="Unresolved item to remember.")
    save_parser.add_argument("--next-step", action="append", help="Likely next action.")
    save_parser.add_argument("--notes", help="Optional extra note.")
    save_parser.set_defaults(func=save_entry)

    latest_parser = subparsers.add_parser("latest", help="Print the latest saved history entry.")
    latest_parser.add_argument("--output", choices=["text", "json"], default="text")
    latest_parser.set_defaults(func=latest_entry)

    list_parser = subparsers.add_parser("list", help="Print recent history entries.")
    list_parser.add_argument("--limit", type=int, default=5)
    list_parser.add_argument("--output", choices=["text", "json"], default="text")
    list_parser.set_defaults(func=list_entries)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
