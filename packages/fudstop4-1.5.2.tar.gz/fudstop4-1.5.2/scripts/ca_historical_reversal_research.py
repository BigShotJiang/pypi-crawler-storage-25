#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import io
import itertools
import json
import math
import os
import statistics
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Sequence


DEFAULT_PSQL_PATH = r"C:\Program Files\PostgreSQL\17\bin\psql.exe"
DEFAULT_TIMESPANS = ("m1", "m5", "m15", "m30", "m60", "m120", "m240", "d1", "w1", "mth1")
DEFAULT_CONDITION_PROFILE = "default"
DEFAULT_EVENT_PROFILE = "canonical"
DEFAULT_WINDOW_PROFILE = "fixed"
DEFAULT_THRESHOLD_METRIC = "hit_30bp"
DEFAULT_OUTCOME_PROFILE = "best_excursion"
DEFAULT_TRIGGER_WINDOW_MIN = 1
DEFAULT_TRIGGER_WINDOW_MAX = 2
DEFAULT_RUN_WINDOW_MIN = 10
DEFAULT_RUN_WINDOW_MAX = 15
DEFAULT_TRIGGER_MIN_MOVE = 0.0
DEFAULT_MIN_BURST_STREAK = 0
TIMESPAN_WINDOW_RULES: Dict[str, tuple[int, int]] = {
    "m1": (5, 10),
    "m5": (5, 10),
    "m15": (5, 10),
    "m30": (5, 10),
    "m60": (4, 7),
    "m120": (4, 7),
    "m240": (4, 7),
    "d1": (1, 4),
    "w1": (1, 4),
    "mth1": (1, 4),
    "mo1": (1, 4),
}
MACD_STATE_NAMES = {
    1: "diverging_bull",
    2: "diverging_bear",
    3: "arching_bull",
    4: "arching_bear",
    5: "converging_bull",
    6: "converging_bear",
    7: "imminent_bull_cross",
    8: "imminent_bear_cross",
}


@dataclass(frozen=True)
class ConditionSpec:
    label: str
    expr: str
    fn: Callable[[Dict[str, object]], bool]


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Backtest historical reversal candidates from public.ca using read-only psql exports.",
    )
    parser.add_argument("--host", default=os.environ.get("DB_HOST", "localhost"))
    parser.add_argument("--port", type=int, default=int(os.environ.get("DB_PORT", "5432")))
    parser.add_argument("--user", default=os.environ.get("DB_USER", "chuck"))
    parser.add_argument("--password", default=os.environ.get("DB_PASSWORD", "fud"))
    parser.add_argument("--database", default=os.environ.get("DB_NAME", "fudstop3"))
    parser.add_argument("--psql-path", default=os.environ.get("PSQL_PATH", DEFAULT_PSQL_PATH))
    parser.add_argument("--timespans", default=",".join(DEFAULT_TIMESPANS))
    parser.add_argument("--window-min", type=int, default=5)
    parser.add_argument("--window-max", type=int, default=10)
    parser.add_argument("--target-30bp", type=float, default=0.003)
    parser.add_argument("--target-50bp", type=float, default=0.005)
    parser.add_argument("--target-100bp", type=float, default=0.010)
    parser.add_argument("--min-n", type=int, default=25)
    parser.add_argument("--hit-threshold", type=float, default=0.85)
    parser.add_argument(
        "--threshold-metric",
        default=DEFAULT_THRESHOLD_METRIC,
        choices=("hit_30bp", "hit_50bp", "hit_100bp"),
    )
    parser.add_argument("--max-k", type=int, default=3)
    parser.add_argument("--condition-profile", default=DEFAULT_CONDITION_PROFILE)
    parser.add_argument(
        "--outcome-profile",
        default=DEFAULT_OUTCOME_PROFILE,
        choices=("best_excursion", "immediate_run", "spawn_move"),
    )
    parser.add_argument(
        "--event-profile",
        default=DEFAULT_EVENT_PROFILE,
        choices=("canonical", "no_macd_gate", "expanded_burst"),
    )
    parser.add_argument(
        "--timespan-window-profile",
        default=DEFAULT_WINDOW_PROFILE,
        choices=("fixed", "scaled_significant"),
    )
    parser.add_argument("--trigger-window-min", type=int, default=DEFAULT_TRIGGER_WINDOW_MIN)
    parser.add_argument("--trigger-window-max", type=int, default=DEFAULT_TRIGGER_WINDOW_MAX)
    parser.add_argument("--run-window-min", type=int, default=DEFAULT_RUN_WINDOW_MIN)
    parser.add_argument("--run-window-max", type=int, default=DEFAULT_RUN_WINDOW_MAX)
    parser.add_argument("--trigger-min-move", type=float, default=DEFAULT_TRIGGER_MIN_MOVE)
    parser.add_argument("--min-burst-streak", type=int, default=DEFAULT_MIN_BURST_STREAK)
    parser.add_argument("--output-dir", default="runs/ca_historical_reversal_research")
    return parser.parse_args()


def _parse_timespans(raw: str) -> List[str]:
    values = [value.strip() for value in str(raw or "").split(",") if value.strip()]
    return values or list(DEFAULT_TIMESPANS)


def _sql_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _format_numeric_literal(value: float) -> str:
    return format(float(value), ".10g")


def _timespan_windows(
    timespans: Sequence[str],
    *,
    window_min: int,
    window_max: int,
    profile: str,
) -> List[tuple[List[str], int, int]]:
    if window_max < window_min:
        raise ValueError("window_max must be greater than or equal to window_min")
    if not timespans:
        raise ValueError("at least one timespan is required")
    if profile == "fixed":
        return [(list(timespans), int(window_min), int(window_max))]
    if profile != "scaled_significant":
        raise ValueError(f"unsupported timespan window profile: {profile}")
    grouped: Dict[tuple[int, int], List[str]] = {}
    for timespan in timespans:
        bounds = TIMESPAN_WINDOW_RULES.get(str(timespan), (int(window_min), int(window_max)))
        grouped.setdefault(bounds, []).append(str(timespan))
    ordered_groups: List[tuple[List[str], int, int]] = []
    for bounds, bucket in grouped.items():
        ordered_bucket = [timespan for timespan in timespans if timespan in bucket]
        ordered_groups.append((ordered_bucket, bounds[0], bounds[1]))
    ordered_groups.sort(key=lambda item: (item[1], item[2], item[0]))
    return ordered_groups


def _window_profile_label(
    timespans: Sequence[str],
    *,
    window_min: int,
    window_max: int,
    profile: str,
) -> str:
    groups = _timespan_windows(
        timespans,
        window_min=window_min,
        window_max=window_max,
        profile=profile,
    )
    if len(groups) == 1 and profile == "fixed":
        return f"candles {window_min}-{window_max} forward"
    return " | ".join(
        f"{'/'.join(bucket)}={group_min}-{group_max}"
        for bucket, group_min, group_max in groups
    )


def _outcome_profile_label(args: argparse.Namespace) -> str:
    if args.outcome_profile == "immediate_run":
        label = (
            f"trigger {args.trigger_window_min}-{args.trigger_window_max} candles"
            f" | sustained {args.run_window_min}-{args.run_window_max} candle closes"
        )
        if args.trigger_min_move > 0:
            label += f" | trigger move >= {args.trigger_min_move:.2%}"
        return label
    if args.outcome_profile == "spawn_move":
        label = (
            f"trigger {args.trigger_window_min}-{args.trigger_window_max} candles"
            f" | best excursion {args.run_window_min}-{args.run_window_max} candles"
        )
        if args.trigger_min_move > 0:
            label += f" | trigger move >= {args.trigger_min_move:.2%}"
        return label
    return _window_profile_label(
        _parse_timespans(args.timespans),
        window_min=args.window_min,
        window_max=args.window_max,
        profile=args.timespan_window_profile,
    )


def _build_group_event_query(
    timespans: Sequence[str],
    window_min: int,
    window_max: int,
    *,
    event_profile: str = DEFAULT_EVENT_PROFILE,
    outcome_profile: str = DEFAULT_OUTCOME_PROFILE,
    trigger_window_min: int = DEFAULT_TRIGGER_WINDOW_MIN,
    trigger_window_max: int = DEFAULT_TRIGGER_WINDOW_MAX,
    run_window_min: int = DEFAULT_RUN_WINDOW_MIN,
    run_window_max: int = DEFAULT_RUN_WINDOW_MAX,
    trigger_min_move: float = DEFAULT_TRIGGER_MIN_MOVE,
    min_burst_streak: int = DEFAULT_MIN_BURST_STREAK,
) -> str:
    if window_max < window_min:
        raise ValueError("window_max must be greater than or equal to window_min")
    if not timespans:
        raise ValueError("at least one timespan is required")
    quoted_timespans = ", ".join(_sql_quote(value) for value in timespans)
    expected_forward_rows = window_max - window_min + 1
    expected_trigger_rows = trigger_window_max - trigger_window_min + 1
    expected_run_rows = run_window_max - run_window_min + 1
    if event_profile == "canonical":
        bull_where = """
        WHERE rsi <= 30
          AND td_buy_count >= 8
          AND macd_state_code IN (4, 6, 7)
""".rstrip()
        bear_where = """
        WHERE rsi >= 70
          AND td_sell_count >= 8
          AND macd_state_code IN (3, 5, 8)
""".rstrip()
    elif event_profile == "no_macd_gate":
        bull_where = """
        WHERE rsi <= 30
          AND td_buy_count >= 8
""".rstrip()
        bear_where = """
        WHERE rsi >= 70
          AND td_sell_count >= 8
""".rstrip()
    elif event_profile == "expanded_burst":
        bull_where = """
        WHERE (
                (rsi <= 30 AND td_buy_count >= 8)
             OR (rsi <= 24 AND macd_state_code IN (2, 4, 6, 7))
             OR (rsi <= 20 AND vwap_dist_pct <= -0.01 AND trix <= -0.05)
              )
""".rstrip()
        bear_where = """
        WHERE (
                (rsi >= 70 AND td_sell_count >= 8)
             OR (rsi >= 76 AND macd_state_code IN (1, 3, 5, 8))
             OR (rsi >= 80 AND vwap_dist_pct >= 0.01 AND trix >= 0.05)
              )
""".rstrip()
    else:
        raise ValueError(f"unsupported event profile: {event_profile}")
    if outcome_profile not in {"best_excursion", "immediate_run", "spawn_move"}:
        raise ValueError(f"unsupported outcome profile: {outcome_profile}")
    if trigger_window_max < trigger_window_min:
        raise ValueError("trigger_window_max must be greater than or equal to trigger_window_min")
    if run_window_max < run_window_min:
        raise ValueError("run_window_max must be greater than or equal to run_window_min")
    if trigger_min_move < 0:
        raise ValueError("trigger_min_move must be greater than or equal to 0")
    if min_burst_streak < 0:
        raise ValueError("min_burst_streak must be greater than or equal to 0")
    if outcome_profile in {"immediate_run", "spawn_move"}:
        if trigger_window_min < 1:
            raise ValueError("trigger_window_min must be at least 1")
        if run_window_min <= trigger_window_max:
            raise ValueError("run_window_min must be greater than trigger_window_max")
        outcome_ordered = f"""
            max(c) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN {trigger_window_min} FOLLOWING AND {trigger_window_max} FOLLOWING
            ) AS max_c_trigger_fwd,
            min(c) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN {trigger_window_min} FOLLOWING AND {trigger_window_max} FOLLOWING
            ) AS min_c_trigger_fwd,
            count(*) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN {trigger_window_min} FOLLOWING AND {trigger_window_max} FOLLOWING
            ) AS n_trigger_fwd,
            max(h) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN {run_window_min} FOLLOWING AND {run_window_max} FOLLOWING
            ) AS max_h_run_fwd,
            min(l) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN {run_window_min} FOLLOWING AND {run_window_max} FOLLOWING
            ) AS min_l_run_fwd,
            max(c) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN {run_window_min} FOLLOWING AND {run_window_max} FOLLOWING
            ) AS max_c_run_fwd,
            min(c) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN {run_window_min} FOLLOWING AND {run_window_max} FOLLOWING
            ) AS min_c_run_fwd,
            count(*) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN {run_window_min} FOLLOWING AND {run_window_max} FOLLOWING
            ) AS n_run_fwd
""".rstrip()
        if outcome_profile == "immediate_run":
            outcome_scored = """
            (max_c_trigger_fwd / NULLIF(c, 0) - 1.0) AS trigger_up_ret,
            (c / NULLIF(min_c_trigger_fwd, 0) - 1.0) AS trigger_down_ret,
            CASE
                WHEN max_c_trigger_fwd IS NOT NULL AND max_c_trigger_fwd > c
                THEN (min_c_run_fwd / NULLIF(c, 0) - 1.0)
                ELSE NULL
            END AS best_up_ret,
            CASE
                WHEN min_c_trigger_fwd IS NOT NULL AND min_c_trigger_fwd < c
                THEN (c / NULLIF(max_c_run_fwd, 0) - 1.0)
                ELSE NULL
            END AS best_down_ret
""".rstrip()
        else:
            outcome_scored = """
            (max_c_trigger_fwd / NULLIF(c, 0) - 1.0) AS trigger_up_ret,
            (c / NULLIF(min_c_trigger_fwd, 0) - 1.0) AS trigger_down_ret,
            CASE
                WHEN max_c_trigger_fwd IS NOT NULL AND max_c_trigger_fwd > c
                THEN (max_h_run_fwd / NULLIF(c, 0) - 1.0)
                ELSE NULL
            END AS best_up_ret,
            CASE
                WHEN min_c_trigger_fwd IS NOT NULL AND min_c_trigger_fwd < c
                THEN (c / NULLIF(min_l_run_fwd, 0) - 1.0)
                ELSE NULL
            END AS best_down_ret
""".rstrip()
        outcome_scored_where = f"""
        WHERE n_trigger_fwd = {expected_trigger_rows}
          AND n_run_fwd = {expected_run_rows}
          AND c IS NOT NULL
          AND c <> 0
""".rstrip()
        bull_where = bull_where + (
            f"\n  AND trigger_up_ret >= {_format_numeric_literal(trigger_min_move)}"
            if trigger_min_move > 0
            else ""
        )
        bear_where = bear_where + (
            f"\n  AND trigger_down_ret >= {_format_numeric_literal(trigger_min_move)}"
            if trigger_min_move > 0
            else ""
        )
    else:
        outcome_ordered = f"""
            max(h) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN {window_min} FOLLOWING AND {window_max} FOLLOWING
            ) AS max_h_fwd,
            min(l) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN {window_min} FOLLOWING AND {window_max} FOLLOWING
            ) AS min_l_fwd,
            count(*) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN {window_min} FOLLOWING AND {window_max} FOLLOWING
            ) AS n_fwd
""".rstrip()
        outcome_scored = """
            NULL::double precision AS trigger_up_ret,
            NULL::double precision AS trigger_down_ret,
            (max_h_fwd / NULLIF(c, 0) - 1.0) AS best_up_ret,
            (c / NULLIF(min_l_fwd, 0) - 1.0) AS best_down_ret
""".rstrip()
        outcome_scored_where = f"""
        WHERE n_fwd = {expected_forward_rows}
          AND c IS NOT NULL
          AND c <> 0
""".rstrip()
    if min_burst_streak > 0:
        bull_where = bull_where + f"\n  AND greatest(red_streak, prev_red_streak) >= {int(min_burst_streak)}"
        bear_where = bear_where + f"\n  AND greatest(green_streak, prev_green_streak) >= {int(min_burst_streak)}"
    return f"""
SELECT * FROM (
    WITH ordered AS (
        SELECT
            ticker,
            timespan,
            ts::bigint AS ts_epoch,
            c,
            h,
            l,
            rsi,
            td_buy_count,
            td_sell_count,
            macd_hist,
            macd_cross_up,
            macd_cross_dn,
            bb_width,
            bb_close_outside_lower,
            bb_close_outside_upper,
            candle_completely_below_lower,
            candle_completely_above_upper,
            rvol,
            atr_pct,
            chop,
            vwap_dist_pct,
            vwap_cross_up,
            vwap_cross_dn,
            stoch_rsi_k,
            stoch_rsi_d,
            mfi,
            cmo,
            roc,
            trix,
            ultimate_osc,
            keltner_width,
            sdc_width,
            tsi_cross_up,
            tsi_cross_dn,
            adx,
            trend_regime,
            volume_confirm,
            squeeze_on,
            squeeze_off,
            candle_green,
            candle_red,
            sum(CASE WHEN candle_green THEN 0 ELSE 1 END) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
            ) AS green_break_group,
            sum(CASE WHEN candle_red THEN 0 ELSE 1 END) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts::bigint
                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
            ) AS red_break_group,
            adx_strong,
            di_bull,
            di_bear,
            ema_stack_bull,
            ema_stack_bear,
            lag(macd_hist, 3) OVER (PARTITION BY ticker, timespan ORDER BY ts::bigint) AS macd_hist_lag3,
            lag(macd_hist, 2) OVER (PARTITION BY ticker, timespan ORDER BY ts::bigint) AS macd_hist_lag2,
            lag(macd_hist, 1) OVER (PARTITION BY ticker, timespan ORDER BY ts::bigint) AS macd_hist_lag1,
            {outcome_ordered}
        FROM ca
        WHERE timespan IN ({quoted_timespans})
          AND bb_width IS NOT NULL
          AND macd_hist IS NOT NULL
          AND rsi IS NOT NULL
          AND td_buy_count IS NOT NULL
          AND td_sell_count IS NOT NULL
    ),
    streaked AS (
        SELECT
            *,
            CASE
                WHEN candle_green THEN sum(CASE WHEN candle_green THEN 1 ELSE 0 END) OVER (
                    PARTITION BY ticker, timespan, green_break_group
                    ORDER BY ts_epoch
                    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                )
                ELSE 0
            END AS green_streak,
            CASE
                WHEN candle_red THEN sum(CASE WHEN candle_red THEN 1 ELSE 0 END) OVER (
                    PARTITION BY ticker, timespan, red_break_group
                    ORDER BY ts_epoch
                    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                )
                ELSE 0
            END AS red_streak
        FROM ordered
    ),
    scored AS (
        SELECT
            *,
            lag(green_streak, 1, 0) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts_epoch
            ) AS prev_green_streak,
            lag(red_streak, 1, 0) OVER (
                PARTITION BY ticker, timespan
                ORDER BY ts_epoch
            ) AS prev_red_streak,
            CASE
                WHEN macd_hist_lag3 IS NULL
                  OR macd_hist_lag2 IS NULL
                  OR macd_hist_lag1 IS NULL
                  OR macd_hist IS NULL
                THEN 0
                ELSE (
                    CASE
                        WHEN abs(macd_hist) < (((abs(macd_hist_lag2 - macd_hist_lag3) + abs(macd_hist_lag1 - macd_hist_lag2) + abs(macd_hist - macd_hist_lag1)) / 3.0) + 1e-9) * 0.5
                         AND abs(macd_hist - macd_hist_lag1) < ((((abs(macd_hist_lag2 - macd_hist_lag3) + abs(macd_hist_lag1 - macd_hist_lag2) + abs(macd_hist - macd_hist_lag1)) / 3.0) + 1e-9) * 0.2)
                        THEN CASE WHEN macd_hist < 0 THEN 7 ELSE 8 END
                        WHEN macd_hist > 0 AND (macd_hist - macd_hist_lag1) > ((((abs(macd_hist_lag2 - macd_hist_lag3) + abs(macd_hist_lag1 - macd_hist_lag2) + abs(macd_hist - macd_hist_lag1)) / 3.0) + 1e-9) * 0.8) THEN 1
                        WHEN macd_hist < 0 AND (macd_hist - macd_hist_lag1) < -((((abs(macd_hist_lag2 - macd_hist_lag3) + abs(macd_hist_lag1 - macd_hist_lag2) + abs(macd_hist - macd_hist_lag1)) / 3.0) + 1e-9) * 0.8) THEN 2
                        WHEN macd_hist > 0 AND (macd_hist - macd_hist_lag1) < -((((abs(macd_hist_lag2 - macd_hist_lag3) + abs(macd_hist_lag1 - macd_hist_lag2) + abs(macd_hist - macd_hist_lag1)) / 3.0) + 1e-9) * 0.8) THEN 3
                        WHEN macd_hist < 0 AND (macd_hist - macd_hist_lag1) > ((((abs(macd_hist_lag2 - macd_hist_lag3) + abs(macd_hist_lag1 - macd_hist_lag2) + abs(macd_hist - macd_hist_lag1)) / 3.0) + 1e-9) * 0.8) THEN 4
                        WHEN macd_hist > 0 THEN 5
                        ELSE 6
                    END
                )
            END AS macd_state_code,
            {outcome_scored}
        FROM streaked
{outcome_scored_where}
    ),
    events AS (
        SELECT
            ticker,
            timespan,
            ts_epoch,
            'bull'::text AS side,
            macd_state_code,
            rsi,
            td_buy_count,
            td_sell_count,
            best_up_ret AS best_ret,
            trigger_up_ret,
            trigger_down_ret,
            best_up_ret,
            best_down_ret,
            bb_width,
            bb_close_outside_lower,
            bb_close_outside_upper,
            candle_completely_below_lower,
            candle_completely_above_upper,
            rvol,
            atr_pct,
            chop,
            vwap_dist_pct,
            vwap_cross_up,
            vwap_cross_dn,
            stoch_rsi_k,
            stoch_rsi_d,
            mfi,
            cmo,
            roc,
            trix,
            ultimate_osc,
            keltner_width,
            sdc_width,
            tsi_cross_up,
            tsi_cross_dn,
            adx,
            trend_regime,
            volume_confirm,
            squeeze_on,
            squeeze_off,
            candle_green,
            candle_red,
            green_streak,
            red_streak,
            prev_green_streak,
            prev_red_streak,
            greatest(red_streak, prev_red_streak) AS burst_streak,
            adx_strong,
            di_bull,
            di_bear,
            ema_stack_bull,
            ema_stack_bear,
            macd_cross_up,
            macd_cross_dn
        FROM scored
{bull_where}
        UNION ALL
        SELECT
            ticker,
            timespan,
            ts_epoch,
            'bear'::text AS side,
            macd_state_code,
            rsi,
            td_buy_count,
            td_sell_count,
            best_down_ret AS best_ret,
            trigger_up_ret,
            trigger_down_ret,
            best_up_ret,
            best_down_ret,
            bb_width,
            bb_close_outside_lower,
            bb_close_outside_upper,
            candle_completely_below_lower,
            candle_completely_above_upper,
            rvol,
            atr_pct,
            chop,
            vwap_dist_pct,
            vwap_cross_up,
            vwap_cross_dn,
            stoch_rsi_k,
            stoch_rsi_d,
            mfi,
            cmo,
            roc,
            trix,
            ultimate_osc,
            keltner_width,
            sdc_width,
            tsi_cross_up,
            tsi_cross_dn,
            adx,
            trend_regime,
            volume_confirm,
            squeeze_on,
            squeeze_off,
            candle_green,
            candle_red,
            green_streak,
            red_streak,
            prev_green_streak,
            prev_red_streak,
            greatest(green_streak, prev_green_streak) AS burst_streak,
            adx_strong,
            di_bull,
            di_bear,
            ema_stack_bull,
            ema_stack_bear,
            macd_cross_up,
            macd_cross_dn
        FROM scored
{bear_where}
    )
    SELECT
        ticker,
        timespan,
        ts_epoch,
        side,
        macd_state_code,
        CASE macd_state_code
            WHEN 1 THEN 'diverging_bull'
            WHEN 2 THEN 'diverging_bear'
            WHEN 3 THEN 'arching_bull'
            WHEN 4 THEN 'arching_bear'
            WHEN 5 THEN 'converging_bull'
            WHEN 6 THEN 'converging_bear'
            WHEN 7 THEN 'imminent_bull_cross'
            WHEN 8 THEN 'imminent_bear_cross'
            ELSE 'unknown'
        END AS macd_state,
        rsi,
        td_buy_count,
        td_sell_count,
        best_ret,
        trigger_up_ret,
        trigger_down_ret,
        best_up_ret,
        best_down_ret,
        bb_width,
        bb_close_outside_lower,
        bb_close_outside_upper,
        candle_completely_below_lower,
        candle_completely_above_upper,
        rvol,
        atr_pct,
        chop,
        vwap_dist_pct,
        vwap_cross_up,
        vwap_cross_dn,
        stoch_rsi_k,
        stoch_rsi_d,
        mfi,
        cmo,
        roc,
        trix,
        ultimate_osc,
        keltner_width,
        sdc_width,
        tsi_cross_up,
        tsi_cross_dn,
        adx,
        trend_regime,
        volume_confirm,
        squeeze_on,
        squeeze_off,
        candle_green,
        candle_red,
        green_streak,
        red_streak,
        prev_green_streak,
        prev_red_streak,
        burst_streak,
        adx_strong,
        di_bull,
        di_bear,
        ema_stack_bull,
        ema_stack_bear,
        macd_cross_up,
        macd_cross_dn
    FROM events
) AS grouped_events
""".strip()


def _build_event_query(
    timespans: Sequence[str],
    window_min: int,
    window_max: int,
    *,
    event_profile: str = DEFAULT_EVENT_PROFILE,
    timespan_window_profile: str = DEFAULT_WINDOW_PROFILE,
    outcome_profile: str = DEFAULT_OUTCOME_PROFILE,
    trigger_window_min: int = DEFAULT_TRIGGER_WINDOW_MIN,
    trigger_window_max: int = DEFAULT_TRIGGER_WINDOW_MAX,
    run_window_min: int = DEFAULT_RUN_WINDOW_MIN,
    run_window_max: int = DEFAULT_RUN_WINDOW_MAX,
    trigger_min_move: float = DEFAULT_TRIGGER_MIN_MOVE,
    min_burst_streak: int = DEFAULT_MIN_BURST_STREAK,
    include_order_by: bool = True,
) -> str:
    groups = _timespan_windows(
        timespans,
        window_min=window_min,
        window_max=window_max,
        profile=timespan_window_profile,
    )
    order_clause = "\nORDER BY timespan, side, ts_epoch, ticker" if include_order_by else ""
    fragments = [
        _build_group_event_query(
            group_timespans,
            group_window_min,
            group_window_max,
            event_profile=event_profile,
            outcome_profile=outcome_profile,
            trigger_window_min=trigger_window_min,
            trigger_window_max=trigger_window_max,
            run_window_min=run_window_min,
            run_window_max=run_window_max,
            trigger_min_move=trigger_min_move,
            min_burst_streak=min_burst_streak,
        )
        for group_timespans, group_window_min, group_window_max in groups
    ]
    return (
        "WITH events AS (\n"
        + "\nUNION ALL\n".join(fragments)
        + "\n)\nSELECT * FROM events"
        + order_clause
        + "\n"
    )


def _run_copy_query(args: argparse.Namespace, sql: str) -> List[Dict[str, str]]:
    command = [
        args.psql_path,
        "-h",
        args.host,
        "-p",
        str(args.port),
        "-U",
        args.user,
        "-d",
        args.database,
        "-v",
        "ON_ERROR_STOP=1",
        "-P",
        "pager=off",
        "-c",
        f"COPY ({sql}) TO STDOUT WITH CSV HEADER",
    ]
    env = os.environ.copy()
    env["PGPASSWORD"] = args.password
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        env=env,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "psql export failed")
    reader = csv.DictReader(io.StringIO(result.stdout))
    return [dict(row) for row in reader]


def _to_float(value: object, default: float = 0.0) -> float:
    try:
        if value in (None, "", "None"):
            return default
        return float(value)
    except Exception:
        return default


def _to_int(value: object, default: int = 0) -> int:
    try:
        if value in (None, "", "None"):
            return default
        return int(float(value))
    except Exception:
        return default


def _to_bool(value: object) -> bool:
    text = str(value or "").strip().lower()
    return text in {"true", "t", "1", "yes", "y"}


def _normalize_rows(raw_rows: Sequence[Dict[str, str]]) -> List[Dict[str, object]]:
    rows: List[Dict[str, object]] = []
    float_fields = {
        "rsi",
        "best_ret",
        "trigger_up_ret",
        "trigger_down_ret",
        "best_up_ret",
        "best_down_ret",
        "bb_width",
        "rvol",
        "atr_pct",
        "chop",
        "vwap_dist_pct",
        "stoch_rsi_k",
        "stoch_rsi_d",
        "mfi",
        "cmo",
        "roc",
        "trix",
        "ultimate_osc",
        "keltner_width",
        "sdc_width",
        "adx",
    }
    int_fields = {
        "ts_epoch",
        "td_buy_count",
        "td_sell_count",
        "macd_state_code",
        "green_streak",
        "red_streak",
        "prev_green_streak",
        "prev_red_streak",
        "burst_streak",
    }
    bool_fields = {
        "bb_close_outside_lower",
        "bb_close_outside_upper",
        "candle_completely_below_lower",
        "candle_completely_above_upper",
        "vwap_cross_up",
        "vwap_cross_dn",
        "tsi_cross_up",
        "tsi_cross_dn",
        "trend_regime",
        "volume_confirm",
        "squeeze_on",
        "squeeze_off",
        "candle_green",
        "candle_red",
        "adx_strong",
        "di_bull",
        "di_bear",
        "ema_stack_bull",
        "ema_stack_bear",
        "macd_cross_up",
        "macd_cross_dn",
    }
    for raw in raw_rows:
        row: Dict[str, object] = {}
        for key, value in raw.items():
            if key in float_fields:
                row[key] = _to_float(value, float("nan"))
            elif key in int_fields:
                row[key] = _to_int(value, 0)
            elif key in bool_fields:
                row[key] = _to_bool(value)
            else:
                row[key] = value
        rows.append(row)
    return rows


def _finite(value: object) -> bool:
    try:
        return math.isfinite(float(value))
    except Exception:
        return False


def _mask_ge(field: str, threshold: float) -> Callable[[Dict[str, object]], bool]:
    return lambda row: _finite(row.get(field)) and float(row.get(field)) >= threshold


def _mask_le(field: str, threshold: float) -> Callable[[Dict[str, object]], bool]:
    return lambda row: _finite(row.get(field)) and float(row.get(field)) <= threshold


def _mask_bool(field: str) -> Callable[[Dict[str, object]], bool]:
    return lambda row: bool(row.get(field))


def _mask_state(code: int) -> Callable[[Dict[str, object]], bool]:
    return lambda row: int(row.get("macd_state_code") or 0) == int(code)


def _dedupe_specs(specs: Sequence[ConditionSpec]) -> List[ConditionSpec]:
    seen: set[str] = set()
    deduped: List[ConditionSpec] = []
    for spec in specs:
        if spec.label in seen:
            continue
        seen.add(spec.label)
        deduped.append(spec)
    return deduped


def _build_condition_specs(side: str, profile: str = DEFAULT_CONDITION_PROFILE) -> List[ConditionSpec]:
    common = [
        ConditionSpec("bb_width>=0.03", "bb_width >= 0.03", _mask_ge("bb_width", 0.03)),
        ConditionSpec("bb_width>=0.05", "bb_width >= 0.05", _mask_ge("bb_width", 0.05)),
        ConditionSpec("atr_pct>=0.003", "atr_pct >= 0.003", _mask_ge("atr_pct", 0.003)),
        ConditionSpec("atr_pct>=0.006", "atr_pct >= 0.006", _mask_ge("atr_pct", 0.006)),
        ConditionSpec("rvol>=1.5", "rvol >= 1.5", _mask_ge("rvol", 1.5)),
        ConditionSpec("rvol>=2.0", "rvol >= 2.0", _mask_ge("rvol", 2.0)),
        ConditionSpec("volume_confirm", "volume_confirm = true", _mask_bool("volume_confirm")),
        ConditionSpec("adx>=25", "adx >= 25", _mask_ge("adx", 25.0)),
        ConditionSpec("adx_strong", "adx_strong = true", _mask_bool("adx_strong")),
        ConditionSpec("trend_regime", "trend_regime = true", _mask_bool("trend_regime")),
        ConditionSpec("squeeze_off", "squeeze_off = true", _mask_bool("squeeze_off")),
        ConditionSpec("chop<=45", "chop <= 45", _mask_le("chop", 45.0)),
        ConditionSpec("chop>=60", "chop >= 60", _mask_ge("chop", 60.0)),
    ]
    if side == "bull":
        side_specs = [
            ConditionSpec("state=arching_bear", "macd_state_code = 4", _mask_state(4)),
            ConditionSpec("state=converging_bear", "macd_state_code = 6", _mask_state(6)),
            ConditionSpec("state=imminent_bull_cross", "macd_state_code = 7", _mask_state(7)),
            ConditionSpec("rsi<=25", "rsi <= 25", _mask_le("rsi", 25.0)),
            ConditionSpec("rsi<=20", "rsi <= 20", _mask_le("rsi", 20.0)),
            ConditionSpec("td_buy>=10", "td_buy_count >= 10", _mask_ge("td_buy_count", 10.0)),
            ConditionSpec("td_buy>=13", "td_buy_count >= 13", _mask_ge("td_buy_count", 13.0)),
            ConditionSpec("stoch_rsi_k<=20", "stoch_rsi_k <= 20", _mask_le("stoch_rsi_k", 20.0)),
            ConditionSpec("stoch_rsi_k<=10", "stoch_rsi_k <= 10", _mask_le("stoch_rsi_k", 10.0)),
            ConditionSpec("mfi<=20", "mfi <= 20", _mask_le("mfi", 20.0)),
            ConditionSpec("mfi<=10", "mfi <= 10", _mask_le("mfi", 10.0)),
            ConditionSpec("cmo<=-40", "cmo <= -40", _mask_le("cmo", -40.0)),
            ConditionSpec("roc<=-1", "roc <= -1", _mask_le("roc", -1.0)),
            ConditionSpec("trix<=-0.1", "trix <= -0.1", _mask_le("trix", -0.1)),
            ConditionSpec("ultimate_osc<=30", "ultimate_osc <= 30", _mask_le("ultimate_osc", 30.0)),
            ConditionSpec("vwap_dist<=-0.01", "vwap_dist_pct <= -0.01", _mask_le("vwap_dist_pct", -0.01)),
            ConditionSpec("vwap_cross_up", "vwap_cross_up = true", _mask_bool("vwap_cross_up")),
            ConditionSpec("bb_close_outside_lower", "bb_close_outside_lower = true", _mask_bool("bb_close_outside_lower")),
            ConditionSpec("candle_below_band", "candle_completely_below_lower = true", _mask_bool("candle_completely_below_lower")),
            ConditionSpec("tsi_cross_up", "tsi_cross_up = true", _mask_bool("tsi_cross_up")),
            ConditionSpec("di_bull", "di_bull = true", _mask_bool("di_bull")),
            ConditionSpec("ema_stack_bull", "ema_stack_bull = true", _mask_bool("ema_stack_bull")),
            ConditionSpec("candle_green", "candle_green = true", _mask_bool("candle_green")),
        ]
    else:
        side_specs = [
        ConditionSpec("state=arching_bull", "macd_state_code = 3", _mask_state(3)),
        ConditionSpec("state=converging_bull", "macd_state_code = 5", _mask_state(5)),
        ConditionSpec("state=imminent_bear_cross", "macd_state_code = 8", _mask_state(8)),
        ConditionSpec("rsi>=75", "rsi >= 75", _mask_ge("rsi", 75.0)),
        ConditionSpec("rsi>=80", "rsi >= 80", _mask_ge("rsi", 80.0)),
        ConditionSpec("td_sell>=10", "td_sell_count >= 10", _mask_ge("td_sell_count", 10.0)),
        ConditionSpec("td_sell>=13", "td_sell_count >= 13", _mask_ge("td_sell_count", 13.0)),
        ConditionSpec("stoch_rsi_k>=80", "stoch_rsi_k >= 80", _mask_ge("stoch_rsi_k", 80.0)),
        ConditionSpec("stoch_rsi_k>=90", "stoch_rsi_k >= 90", _mask_ge("stoch_rsi_k", 90.0)),
        ConditionSpec("mfi>=80", "mfi >= 80", _mask_ge("mfi", 80.0)),
        ConditionSpec("mfi>=90", "mfi >= 90", _mask_ge("mfi", 90.0)),
        ConditionSpec("cmo>=40", "cmo >= 40", _mask_ge("cmo", 40.0)),
        ConditionSpec("roc>=1", "roc >= 1", _mask_ge("roc", 1.0)),
        ConditionSpec("trix>=0.1", "trix >= 0.1", _mask_ge("trix", 0.1)),
        ConditionSpec("ultimate_osc>=70", "ultimate_osc >= 70", _mask_ge("ultimate_osc", 70.0)),
        ConditionSpec("vwap_dist>=0.01", "vwap_dist_pct >= 0.01", _mask_ge("vwap_dist_pct", 0.01)),
        ConditionSpec("vwap_cross_dn", "vwap_cross_dn = true", _mask_bool("vwap_cross_dn")),
        ConditionSpec("bb_close_outside_upper", "bb_close_outside_upper = true", _mask_bool("bb_close_outside_upper")),
        ConditionSpec("candle_above_band", "candle_completely_above_upper = true", _mask_bool("candle_completely_above_upper")),
        ConditionSpec("tsi_cross_dn", "tsi_cross_dn = true", _mask_bool("tsi_cross_dn")),
        ConditionSpec("di_bear", "di_bear = true", _mask_bool("di_bear")),
        ConditionSpec("ema_stack_bear", "ema_stack_bear = true", _mask_bool("ema_stack_bear")),
        ConditionSpec("candle_red", "candle_red = true", _mask_bool("candle_red")),
        ]

    if profile == "default":
        return common + side_specs

    if profile == "m1_hit100":
        targeted_common = [
            ConditionSpec("bb_width>=0.03", "bb_width >= 0.03", _mask_ge("bb_width", 0.03)),
            ConditionSpec("bb_width>=0.05", "bb_width >= 0.05", _mask_ge("bb_width", 0.05)),
            ConditionSpec("bb_width>=0.07", "bb_width >= 0.07", _mask_ge("bb_width", 0.07)),
            ConditionSpec("bb_width>=0.09", "bb_width >= 0.09", _mask_ge("bb_width", 0.09)),
            ConditionSpec("atr_pct>=0.003", "atr_pct >= 0.003", _mask_ge("atr_pct", 0.003)),
            ConditionSpec("atr_pct>=0.006", "atr_pct >= 0.006", _mask_ge("atr_pct", 0.006)),
            ConditionSpec("atr_pct>=0.008", "atr_pct >= 0.008", _mask_ge("atr_pct", 0.008)),
            ConditionSpec("atr_pct>=0.010", "atr_pct >= 0.010", _mask_ge("atr_pct", 0.010)),
            ConditionSpec("trend_regime", "trend_regime = true", _mask_bool("trend_regime")),
            ConditionSpec("volume_confirm", "volume_confirm = true", _mask_bool("volume_confirm")),
            ConditionSpec("chop<=45", "chop <= 45", _mask_le("chop", 45.0)),
        ]
        if side == "bull":
            targeted_side_specs = [
                ConditionSpec("state=arching_bear", "macd_state_code = 4", _mask_state(4)),
                ConditionSpec("state=converging_bear", "macd_state_code = 6", _mask_state(6)),
                ConditionSpec("rsi<=18", "rsi <= 18", _mask_le("rsi", 18.0)),
                ConditionSpec("rsi<=15", "rsi <= 15", _mask_le("rsi", 15.0)),
                ConditionSpec("td_buy>=10", "td_buy_count >= 10", _mask_ge("td_buy_count", 10.0)),
                ConditionSpec("td_buy>=13", "td_buy_count >= 13", _mask_ge("td_buy_count", 13.0)),
                ConditionSpec("stoch_rsi_k<=20", "stoch_rsi_k <= 20", _mask_le("stoch_rsi_k", 20.0)),
                ConditionSpec("stoch_rsi_k<=15", "stoch_rsi_k <= 15", _mask_le("stoch_rsi_k", 15.0)),
                ConditionSpec("stoch_rsi_k<=5", "stoch_rsi_k <= 5", _mask_le("stoch_rsi_k", 5.0)),
                ConditionSpec("mfi<=10", "mfi <= 10", _mask_le("mfi", 10.0)),
                ConditionSpec("mfi<=15", "mfi <= 15", _mask_le("mfi", 15.0)),
                ConditionSpec("mfi<=5", "mfi <= 5", _mask_le("mfi", 5.0)),
                ConditionSpec("cmo<=-40", "cmo <= -40", _mask_le("cmo", -40.0)),
                ConditionSpec("cmo<=-50", "cmo <= -50", _mask_le("cmo", -50.0)),
                ConditionSpec("roc<=-1", "roc <= -1", _mask_le("roc", -1.0)),
                ConditionSpec("roc<=-2", "roc <= -2", _mask_le("roc", -2.0)),
                ConditionSpec("trix<=-0.03", "trix <= -0.03", _mask_le("trix", -0.03)),
                ConditionSpec("trix<=-0.05", "trix <= -0.05", _mask_le("trix", -0.05)),
                ConditionSpec("trix<=-0.07", "trix <= -0.07", _mask_le("trix", -0.07)),
                ConditionSpec("trix<=-0.1", "trix <= -0.1", _mask_le("trix", -0.1)),
                ConditionSpec("ultimate_osc<=25", "ultimate_osc <= 25", _mask_le("ultimate_osc", 25.0)),
                ConditionSpec("ultimate_osc<=30", "ultimate_osc <= 30", _mask_le("ultimate_osc", 30.0)),
                ConditionSpec("vwap_dist<=-0.01", "vwap_dist_pct <= -0.01", _mask_le("vwap_dist_pct", -0.01)),
                ConditionSpec("vwap_dist<=-0.015", "vwap_dist_pct <= -0.015", _mask_le("vwap_dist_pct", -0.015)),
                ConditionSpec("vwap_dist<=-0.02", "vwap_dist_pct <= -0.02", _mask_le("vwap_dist_pct", -0.02)),
                ConditionSpec("candle_green", "candle_green = true", _mask_bool("candle_green")),
            ]
        else:
            targeted_side_specs = [
                ConditionSpec("state=arching_bull", "macd_state_code = 3", _mask_state(3)),
                ConditionSpec("state=converging_bull", "macd_state_code = 5", _mask_state(5)),
                ConditionSpec("rsi>=80", "rsi >= 80", _mask_ge("rsi", 80.0)),
                ConditionSpec("rsi>=85", "rsi >= 85", _mask_ge("rsi", 85.0)),
                ConditionSpec("rsi>=90", "rsi >= 90", _mask_ge("rsi", 90.0)),
                ConditionSpec("td_sell>=10", "td_sell_count >= 10", _mask_ge("td_sell_count", 10.0)),
                ConditionSpec("td_sell>=13", "td_sell_count >= 13", _mask_ge("td_sell_count", 13.0)),
                ConditionSpec("stoch_rsi_k>=80", "stoch_rsi_k >= 80", _mask_ge("stoch_rsi_k", 80.0)),
                ConditionSpec("stoch_rsi_k>=90", "stoch_rsi_k >= 90", _mask_ge("stoch_rsi_k", 90.0)),
                ConditionSpec("stoch_rsi_k>=95", "stoch_rsi_k >= 95", _mask_ge("stoch_rsi_k", 95.0)),
                ConditionSpec("stoch_rsi_k>=99", "stoch_rsi_k >= 99", _mask_ge("stoch_rsi_k", 99.0)),
                ConditionSpec("mfi>=80", "mfi >= 80", _mask_ge("mfi", 80.0)),
                ConditionSpec("mfi>=90", "mfi >= 90", _mask_ge("mfi", 90.0)),
                ConditionSpec("mfi>=85", "mfi >= 85", _mask_ge("mfi", 85.0)),
                ConditionSpec("mfi>=95", "mfi >= 95", _mask_ge("mfi", 95.0)),
                ConditionSpec("cmo>=40", "cmo >= 40", _mask_ge("cmo", 40.0)),
                ConditionSpec("cmo>=50", "cmo >= 50", _mask_ge("cmo", 50.0)),
                ConditionSpec("roc>=1", "roc >= 1", _mask_ge("roc", 1.0)),
                ConditionSpec("roc>=1.5", "roc >= 1.5", _mask_ge("roc", 1.5)),
                ConditionSpec("roc>=2", "roc >= 2", _mask_ge("roc", 2.0)),
                ConditionSpec("trix>=0.07", "trix >= 0.07", _mask_ge("trix", 0.07)),
                ConditionSpec("trix>=0.08", "trix >= 0.08", _mask_ge("trix", 0.08)),
                ConditionSpec("trix>=0.1", "trix >= 0.1", _mask_ge("trix", 0.1)),
                ConditionSpec("trix>=0.05", "trix >= 0.05", _mask_ge("trix", 0.05)),
                ConditionSpec("trix>=0.15", "trix >= 0.15", _mask_ge("trix", 0.15)),
                ConditionSpec("ultimate_osc>=70", "ultimate_osc >= 70", _mask_ge("ultimate_osc", 70.0)),
                ConditionSpec("ultimate_osc>=75", "ultimate_osc >= 75", _mask_ge("ultimate_osc", 75.0)),
                ConditionSpec("ultimate_osc>=80", "ultimate_osc >= 80", _mask_ge("ultimate_osc", 80.0)),
                ConditionSpec("vwap_dist>=0.01", "vwap_dist_pct >= 0.01", _mask_ge("vwap_dist_pct", 0.01)),
                ConditionSpec("vwap_dist>=0.015", "vwap_dist_pct >= 0.015", _mask_ge("vwap_dist_pct", 0.015)),
                ConditionSpec("vwap_dist>=0.02", "vwap_dist_pct >= 0.02", _mask_ge("vwap_dist_pct", 0.02)),
                ConditionSpec("candle_red", "candle_red = true", _mask_bool("candle_red")),
        ]
        return _dedupe_specs(targeted_common + targeted_side_specs)

    if profile == "m1_hit100_alt":
        targeted_common = [
            ConditionSpec("bb_width>=0.05", "bb_width >= 0.05", _mask_ge("bb_width", 0.05)),
            ConditionSpec("bb_width>=0.07", "bb_width >= 0.07", _mask_ge("bb_width", 0.07)),
            ConditionSpec("atr_pct>=0.006", "atr_pct >= 0.006", _mask_ge("atr_pct", 0.006)),
            ConditionSpec("atr_pct>=0.008", "atr_pct >= 0.008", _mask_ge("atr_pct", 0.008)),
            ConditionSpec("rvol>=1.5", "rvol >= 1.5", _mask_ge("rvol", 1.5)),
            ConditionSpec("rvol>=2.0", "rvol >= 2.0", _mask_ge("rvol", 2.0)),
            ConditionSpec("rvol>=2.5", "rvol >= 2.5", _mask_ge("rvol", 2.5)),
            ConditionSpec("volume_confirm", "volume_confirm = true", _mask_bool("volume_confirm")),
            ConditionSpec("trend_regime", "trend_regime = true", _mask_bool("trend_regime")),
            ConditionSpec("adx>=25", "adx >= 25", _mask_ge("adx", 25.0)),
            ConditionSpec("adx>=30", "adx >= 30", _mask_ge("adx", 30.0)),
            ConditionSpec("adx_strong", "adx_strong = true", _mask_bool("adx_strong")),
            ConditionSpec("chop<=45", "chop <= 45", _mask_le("chop", 45.0)),
        ]
        if side == "bull":
            targeted_side_specs = [
                ConditionSpec("state=converging_bear", "macd_state_code = 6", _mask_state(6)),
                ConditionSpec("state=arching_bear", "macd_state_code = 4", _mask_state(4)),
                ConditionSpec("td_buy>=10", "td_buy_count >= 10", _mask_ge("td_buy_count", 10.0)),
                ConditionSpec("td_buy>=13", "td_buy_count >= 13", _mask_ge("td_buy_count", 13.0)),
                ConditionSpec("rsi<=20", "rsi <= 20", _mask_le("rsi", 20.0)),
                ConditionSpec("rsi<=15", "rsi <= 15", _mask_le("rsi", 15.0)),
                ConditionSpec("stoch_rsi_k<=20", "stoch_rsi_k <= 20", _mask_le("stoch_rsi_k", 20.0)),
                ConditionSpec("stoch_rsi_k<=10", "stoch_rsi_k <= 10", _mask_le("stoch_rsi_k", 10.0)),
                ConditionSpec("mfi<=10", "mfi <= 10", _mask_le("mfi", 10.0)),
                ConditionSpec("mfi<=5", "mfi <= 5", _mask_le("mfi", 5.0)),
                ConditionSpec("cmo<=-40", "cmo <= -40", _mask_le("cmo", -40.0)),
                ConditionSpec("cmo<=-50", "cmo <= -50", _mask_le("cmo", -50.0)),
                ConditionSpec("trix<=-0.05", "trix <= -0.05", _mask_le("trix", -0.05)),
                ConditionSpec("trix<=-0.1", "trix <= -0.1", _mask_le("trix", -0.1)),
                ConditionSpec("ultimate_osc<=30", "ultimate_osc <= 30", _mask_le("ultimate_osc", 30.0)),
                ConditionSpec("ultimate_osc<=25", "ultimate_osc <= 25", _mask_le("ultimate_osc", 25.0)),
                ConditionSpec("vwap_dist<=-0.01", "vwap_dist_pct <= -0.01", _mask_le("vwap_dist_pct", -0.01)),
                ConditionSpec("vwap_dist<=-0.015", "vwap_dist_pct <= -0.015", _mask_le("vwap_dist_pct", -0.015)),
                ConditionSpec("vwap_dist<=-0.02", "vwap_dist_pct <= -0.02", _mask_le("vwap_dist_pct", -0.02)),
                ConditionSpec("candle_green", "candle_green = true", _mask_bool("candle_green")),
            ]
        else:
            targeted_side_specs = [
                ConditionSpec("state=arching_bull", "macd_state_code = 3", _mask_state(3)),
                ConditionSpec("state=converging_bull", "macd_state_code = 5", _mask_state(5)),
                ConditionSpec("td_sell>=10", "td_sell_count >= 10", _mask_ge("td_sell_count", 10.0)),
                ConditionSpec("td_sell>=13", "td_sell_count >= 13", _mask_ge("td_sell_count", 13.0)),
                ConditionSpec("rsi>=80", "rsi >= 80", _mask_ge("rsi", 80.0)),
                ConditionSpec("rsi>=85", "rsi >= 85", _mask_ge("rsi", 85.0)),
                ConditionSpec("stoch_rsi_k>=80", "stoch_rsi_k >= 80", _mask_ge("stoch_rsi_k", 80.0)),
                ConditionSpec("stoch_rsi_k>=90", "stoch_rsi_k >= 90", _mask_ge("stoch_rsi_k", 90.0)),
                ConditionSpec("mfi>=85", "mfi >= 85", _mask_ge("mfi", 85.0)),
                ConditionSpec("mfi>=95", "mfi >= 95", _mask_ge("mfi", 95.0)),
                ConditionSpec("cmo>=40", "cmo >= 40", _mask_ge("cmo", 40.0)),
                ConditionSpec("cmo>=50", "cmo >= 50", _mask_ge("cmo", 50.0)),
                ConditionSpec("trix>=0.05", "trix >= 0.05", _mask_ge("trix", 0.05)),
                ConditionSpec("trix>=0.1", "trix >= 0.1", _mask_ge("trix", 0.1)),
                ConditionSpec("ultimate_osc>=70", "ultimate_osc >= 70", _mask_ge("ultimate_osc", 70.0)),
                ConditionSpec("ultimate_osc>=75", "ultimate_osc >= 75", _mask_ge("ultimate_osc", 75.0)),
                ConditionSpec("vwap_dist>=0.01", "vwap_dist_pct >= 0.01", _mask_ge("vwap_dist_pct", 0.01)),
                ConditionSpec("vwap_dist>=0.015", "vwap_dist_pct >= 0.015", _mask_ge("vwap_dist_pct", 0.015)),
                ConditionSpec("vwap_dist>=0.02", "vwap_dist_pct >= 0.02", _mask_ge("vwap_dist_pct", 0.02)),
                ConditionSpec("candle_red", "candle_red = true", _mask_bool("candle_red")),
            ]
        return _dedupe_specs(targeted_common + targeted_side_specs)

    if profile == "m1_burst_deep":
        targeted_common = [
            ConditionSpec("bb_width>=0.05", "bb_width >= 0.05", _mask_ge("bb_width", 0.05)),
            ConditionSpec("bb_width>=0.07", "bb_width >= 0.07", _mask_ge("bb_width", 0.07)),
            ConditionSpec("bb_width>=0.09", "bb_width >= 0.09", _mask_ge("bb_width", 0.09)),
            ConditionSpec("atr_pct>=0.004", "atr_pct >= 0.004", _mask_ge("atr_pct", 0.004)),
            ConditionSpec("atr_pct>=0.005", "atr_pct >= 0.005", _mask_ge("atr_pct", 0.005)),
            ConditionSpec("atr_pct>=0.006", "atr_pct >= 0.006", _mask_ge("atr_pct", 0.006)),
            ConditionSpec("atr_pct>=0.008", "atr_pct >= 0.008", _mask_ge("atr_pct", 0.008)),
            ConditionSpec("atr_pct>=0.010", "atr_pct >= 0.010", _mask_ge("atr_pct", 0.010)),
            ConditionSpec("rvol>=1.5", "rvol >= 1.5", _mask_ge("rvol", 1.5)),
            ConditionSpec("rvol>=2.0", "rvol >= 2.0", _mask_ge("rvol", 2.0)),
            ConditionSpec("rvol>=2.5", "rvol >= 2.5", _mask_ge("rvol", 2.5)),
            ConditionSpec("volume_confirm", "volume_confirm = true", _mask_bool("volume_confirm")),
            ConditionSpec("adx>=25", "adx >= 25", _mask_ge("adx", 25.0)),
            ConditionSpec("adx>=30", "adx >= 30", _mask_ge("adx", 30.0)),
            ConditionSpec("adx>=35", "adx >= 35", _mask_ge("adx", 35.0)),
            ConditionSpec("adx_strong", "adx_strong = true", _mask_bool("adx_strong")),
            ConditionSpec("trend_regime", "trend_regime = true", _mask_bool("trend_regime")),
            ConditionSpec("squeeze_off", "squeeze_off = true", _mask_bool("squeeze_off")),
            ConditionSpec("chop<=45", "chop <= 45", _mask_le("chop", 45.0)),
            ConditionSpec("chop<=40", "chop <= 40", _mask_le("chop", 40.0)),
            ConditionSpec("sdc_width>=0.008", "sdc_width >= 0.008", _mask_ge("sdc_width", 0.008)),
            ConditionSpec("sdc_width>=0.01", "sdc_width >= 0.01", _mask_ge("sdc_width", 0.01)),
            ConditionSpec("sdc_width>=0.012", "sdc_width >= 0.012", _mask_ge("sdc_width", 0.012)),
        ]
        if side == "bull":
            targeted_side_specs = [
                ConditionSpec("state=diverging_bear", "macd_state_code = 2", _mask_state(2)),
                ConditionSpec("state=arching_bear", "macd_state_code = 4", _mask_state(4)),
                ConditionSpec("state=converging_bear", "macd_state_code = 6", _mask_state(6)),
                ConditionSpec("state=imminent_bull_cross", "macd_state_code = 7", _mask_state(7)),
                ConditionSpec("rsi<=25", "rsi <= 25", _mask_le("rsi", 25.0)),
                ConditionSpec("rsi<=20", "rsi <= 20", _mask_le("rsi", 20.0)),
                ConditionSpec("rsi<=18", "rsi <= 18", _mask_le("rsi", 18.0)),
                ConditionSpec("rsi<=15", "rsi <= 15", _mask_le("rsi", 15.0)),
                ConditionSpec("td_buy>=10", "td_buy_count >= 10", _mask_ge("td_buy_count", 10.0)),
                ConditionSpec("td_buy>=13", "td_buy_count >= 13", _mask_ge("td_buy_count", 13.0)),
                ConditionSpec("stoch_rsi_k<=20", "stoch_rsi_k <= 20", _mask_le("stoch_rsi_k", 20.0)),
                ConditionSpec("stoch_rsi_k<=15", "stoch_rsi_k <= 15", _mask_le("stoch_rsi_k", 15.0)),
                ConditionSpec("stoch_rsi_k<=10", "stoch_rsi_k <= 10", _mask_le("stoch_rsi_k", 10.0)),
                ConditionSpec("stoch_rsi_k<=5", "stoch_rsi_k <= 5", _mask_le("stoch_rsi_k", 5.0)),
                ConditionSpec("mfi<=15", "mfi <= 15", _mask_le("mfi", 15.0)),
                ConditionSpec("mfi<=10", "mfi <= 10", _mask_le("mfi", 10.0)),
                ConditionSpec("mfi<=5", "mfi <= 5", _mask_le("mfi", 5.0)),
                ConditionSpec("cmo<=-40", "cmo <= -40", _mask_le("cmo", -40.0)),
                ConditionSpec("cmo<=-50", "cmo <= -50", _mask_le("cmo", -50.0)),
                ConditionSpec("cmo<=-60", "cmo <= -60", _mask_le("cmo", -60.0)),
                ConditionSpec("roc<=-1", "roc <= -1", _mask_le("roc", -1.0)),
                ConditionSpec("roc<=-1.5", "roc <= -1.5", _mask_le("roc", -1.5)),
                ConditionSpec("roc<=-2", "roc <= -2", _mask_le("roc", -2.0)),
                ConditionSpec("trix<=-0.05", "trix <= -0.05", _mask_le("trix", -0.05)),
                ConditionSpec("trix<=-0.07", "trix <= -0.07", _mask_le("trix", -0.07)),
                ConditionSpec("trix<=-0.1", "trix <= -0.1", _mask_le("trix", -0.1)),
                ConditionSpec("trix<=-0.15", "trix <= -0.15", _mask_le("trix", -0.15)),
                ConditionSpec("ultimate_osc<=30", "ultimate_osc <= 30", _mask_le("ultimate_osc", 30.0)),
                ConditionSpec("ultimate_osc<=25", "ultimate_osc <= 25", _mask_le("ultimate_osc", 25.0)),
                ConditionSpec("vwap_dist<=-0.01", "vwap_dist_pct <= -0.01", _mask_le("vwap_dist_pct", -0.01)),
                ConditionSpec("vwap_dist<=-0.0125", "vwap_dist_pct <= -0.0125", _mask_le("vwap_dist_pct", -0.0125)),
                ConditionSpec("vwap_dist<=-0.015", "vwap_dist_pct <= -0.015", _mask_le("vwap_dist_pct", -0.015)),
                ConditionSpec("vwap_dist<=-0.02", "vwap_dist_pct <= -0.02", _mask_le("vwap_dist_pct", -0.02)),
                ConditionSpec("vwap_cross_up", "vwap_cross_up = true", _mask_bool("vwap_cross_up")),
                ConditionSpec("bb_close_outside_lower", "bb_close_outside_lower = true", _mask_bool("bb_close_outside_lower")),
                ConditionSpec("candle_below_band", "candle_completely_below_lower = true", _mask_bool("candle_completely_below_lower")),
                ConditionSpec("tsi_cross_up", "tsi_cross_up = true", _mask_bool("tsi_cross_up")),
                ConditionSpec("di_bull", "di_bull = true", _mask_bool("di_bull")),
                ConditionSpec("ema_stack_bull", "ema_stack_bull = true", _mask_bool("ema_stack_bull")),
                ConditionSpec("candle_green", "candle_green = true", _mask_bool("candle_green")),
            ]
        else:
            targeted_side_specs = [
                ConditionSpec("state=diverging_bull", "macd_state_code = 1", _mask_state(1)),
                ConditionSpec("state=arching_bull", "macd_state_code = 3", _mask_state(3)),
                ConditionSpec("state=converging_bull", "macd_state_code = 5", _mask_state(5)),
                ConditionSpec("state=imminent_bear_cross", "macd_state_code = 8", _mask_state(8)),
                ConditionSpec("rsi>=75", "rsi >= 75", _mask_ge("rsi", 75.0)),
                ConditionSpec("rsi>=80", "rsi >= 80", _mask_ge("rsi", 80.0)),
                ConditionSpec("rsi>=85", "rsi >= 85", _mask_ge("rsi", 85.0)),
                ConditionSpec("rsi>=90", "rsi >= 90", _mask_ge("rsi", 90.0)),
                ConditionSpec("td_sell>=10", "td_sell_count >= 10", _mask_ge("td_sell_count", 10.0)),
                ConditionSpec("td_sell>=13", "td_sell_count >= 13", _mask_ge("td_sell_count", 13.0)),
                ConditionSpec("stoch_rsi_k>=80", "stoch_rsi_k >= 80", _mask_ge("stoch_rsi_k", 80.0)),
                ConditionSpec("stoch_rsi_k>=90", "stoch_rsi_k >= 90", _mask_ge("stoch_rsi_k", 90.0)),
                ConditionSpec("stoch_rsi_k>=95", "stoch_rsi_k >= 95", _mask_ge("stoch_rsi_k", 95.0)),
                ConditionSpec("stoch_rsi_k>=99", "stoch_rsi_k >= 99", _mask_ge("stoch_rsi_k", 99.0)),
                ConditionSpec("mfi>=80", "mfi >= 80", _mask_ge("mfi", 80.0)),
                ConditionSpec("mfi>=85", "mfi >= 85", _mask_ge("mfi", 85.0)),
                ConditionSpec("mfi>=90", "mfi >= 90", _mask_ge("mfi", 90.0)),
                ConditionSpec("mfi>=95", "mfi >= 95", _mask_ge("mfi", 95.0)),
                ConditionSpec("cmo>=40", "cmo >= 40", _mask_ge("cmo", 40.0)),
                ConditionSpec("cmo>=50", "cmo >= 50", _mask_ge("cmo", 50.0)),
                ConditionSpec("roc>=1", "roc >= 1", _mask_ge("roc", 1.0)),
                ConditionSpec("roc>=1.5", "roc >= 1.5", _mask_ge("roc", 1.5)),
                ConditionSpec("roc>=2", "roc >= 2", _mask_ge("roc", 2.0)),
                ConditionSpec("trix>=0.05", "trix >= 0.05", _mask_ge("trix", 0.05)),
                ConditionSpec("trix>=0.07", "trix >= 0.07", _mask_ge("trix", 0.07)),
                ConditionSpec("trix>=0.08", "trix >= 0.08", _mask_ge("trix", 0.08)),
                ConditionSpec("trix>=0.1", "trix >= 0.1", _mask_ge("trix", 0.1)),
                ConditionSpec("trix>=0.15", "trix >= 0.15", _mask_ge("trix", 0.15)),
                ConditionSpec("ultimate_osc>=70", "ultimate_osc >= 70", _mask_ge("ultimate_osc", 70.0)),
                ConditionSpec("ultimate_osc>=75", "ultimate_osc >= 75", _mask_ge("ultimate_osc", 75.0)),
                ConditionSpec("ultimate_osc>=80", "ultimate_osc >= 80", _mask_ge("ultimate_osc", 80.0)),
                ConditionSpec("vwap_dist>=0.01", "vwap_dist_pct >= 0.01", _mask_ge("vwap_dist_pct", 0.01)),
                ConditionSpec("vwap_dist>=0.015", "vwap_dist_pct >= 0.015", _mask_ge("vwap_dist_pct", 0.015)),
                ConditionSpec("vwap_dist>=0.02", "vwap_dist_pct >= 0.02", _mask_ge("vwap_dist_pct", 0.02)),
                ConditionSpec("vwap_cross_dn", "vwap_cross_dn = true", _mask_bool("vwap_cross_dn")),
                ConditionSpec("bb_close_outside_upper", "bb_close_outside_upper = true", _mask_bool("bb_close_outside_upper")),
                ConditionSpec("candle_above_band", "candle_completely_above_upper = true", _mask_bool("candle_completely_above_upper")),
                ConditionSpec("tsi_cross_dn", "tsi_cross_dn = true", _mask_bool("tsi_cross_dn")),
                ConditionSpec("di_bear", "di_bear = true", _mask_bool("di_bear")),
                ConditionSpec("ema_stack_bear", "ema_stack_bear = true", _mask_bool("ema_stack_bear")),
                ConditionSpec("candle_red", "candle_red = true", _mask_bool("candle_red")),
            ]
        return _dedupe_specs(targeted_common + targeted_side_specs)

    raise ValueError(f"unsupported condition profile: {profile}")


def _quantile(values: Sequence[float], q: float) -> float:
    if not values:
        return float("nan")
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    position = max(0.0, min(1.0, q)) * (len(ordered) - 1)
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return ordered[lower]
    weight = position - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def _metric_value(row: Dict[str, object], metric: str) -> float:
    return float(row.get(metric) or 0.0)


def _scan_candidates(
    rows: Sequence[Dict[str, object]],
    side: str,
    timespan: str,
    *,
    condition_profile: str,
    min_n: int,
    hit_threshold: float,
    threshold_metric: str,
    target_30bp: float,
    target_50bp: float,
    target_100bp: float,
    max_k: int,
) -> List[Dict[str, object]]:
    if not rows:
        return []
    specs = _build_condition_specs(side, condition_profile)
    row_returns = [float(row["best_ret"]) for row in rows if _finite(row.get("best_ret"))]
    if not row_returns:
        return []
    indexed_rows = [row for row in rows if _finite(row.get("best_ret"))]
    returns = [float(row["best_ret"]) for row in indexed_rows]
    spec_sets: List[tuple[ConditionSpec, set[int]]] = []
    all_indices = set(range(len(indexed_rows)))
    for spec in specs:
        matched = {idx for idx, row in enumerate(indexed_rows) if spec.fn(row)}
        if len(matched) >= min_n:
            spec_sets.append((spec, matched))
    findings: List[Dict[str, object]] = []
    for k in range(1, max_k + 1):
        for combo in itertools.combinations(spec_sets, k):
            matched = set.intersection(*(entry[1] for entry in combo)) if combo else set(all_indices)
            n = len(matched)
            if n < min_n:
                continue
            sample = [returns[idx] for idx in matched]
            hit_30bp = sum(1 for value in sample if value >= target_30bp) / n
            hit_50bp = sum(1 for value in sample if value >= target_50bp) / n
            hit_100bp = sum(1 for value in sample if value >= target_100bp) / n
            threshold_value = {
                "hit_30bp": hit_30bp,
                "hit_50bp": hit_50bp,
                "hit_100bp": hit_100bp,
            }.get(threshold_metric, hit_30bp)
            if threshold_value < hit_threshold:
                continue
            labels = [entry[0].label for entry in combo]
            exprs = [entry[0].expr for entry in combo]
            findings.append(
                {
                    "timespan": timespan,
                    "side": side,
                    "label": " AND ".join(labels),
                    "conditions": exprs,
                    "n": n,
                    "hit_30bp": round(hit_30bp, 4),
                    "hit_50bp": round(hit_50bp, 4),
                    "hit_100bp": round(hit_100bp, 4),
                    "avg_best_ret": round(statistics.fmean(sample), 4),
                    "p25_best_ret": round(_quantile(sample, 0.25), 4),
                    "p50_best_ret": round(_quantile(sample, 0.50), 4),
                    "p75_best_ret": round(_quantile(sample, 0.75), 4),
                }
            )
    findings.sort(
        key=lambda item: (
            -_metric_value(item, threshold_metric),
            -float(item["hit_100bp"]),
            -float(item["hit_50bp"]),
            -float(item["avg_best_ret"]),
            -int(item["n"]),
            str(item["label"]),
        )
    )
    return findings


def _build_state_summary(
    rows: Sequence[Dict[str, object]],
    *,
    min_n: int,
    threshold_metric: str,
    target_30bp: float,
    target_50bp: float,
    target_100bp: float,
) -> List[Dict[str, object]]:
    buckets: Dict[tuple[str, str, int], List[float]] = {}
    for row in rows:
        if not _finite(row.get("best_ret")):
            continue
        key = (
            str(row.get("timespan") or ""),
            str(row.get("side") or ""),
            int(row.get("macd_state_code") or 0),
        )
        buckets.setdefault(key, []).append(float(row["best_ret"]))
    summary: List[Dict[str, object]] = []
    for (timespan, side, code), sample in sorted(buckets.items()):
        n = len(sample)
        if n < min_n:
            continue
        summary.append(
            {
                "timespan": timespan,
                "side": side,
                "macd_state_code": code,
                "macd_state": MACD_STATE_NAMES.get(code, "unknown"),
                "n": n,
                "hit_30bp": round(sum(1 for value in sample if value >= target_30bp) / n, 4),
                "hit_50bp": round(sum(1 for value in sample if value >= target_50bp) / n, 4),
                "hit_100bp": round(sum(1 for value in sample if value >= target_100bp) / n, 4),
                "avg_best_ret": round(statistics.fmean(sample), 4),
                "p25_best_ret": round(_quantile(sample, 0.25), 4),
            }
        )
    summary.sort(
        key=lambda item: (
            -_metric_value(item, threshold_metric),
            -float(item["hit_100bp"]),
            -int(item["n"]),
            str(item["timespan"]),
            str(item["side"]),
        )
    )
    return summary


def _prune_redundant_findings(
    rows: Sequence[Dict[str, object]],
    *,
    threshold_metric: str,
) -> List[Dict[str, object]]:
    kept: List[Dict[str, object]] = []
    ordered = sorted(
        rows,
        key=lambda item: (
            str(item.get("timespan") or ""),
            str(item.get("side") or ""),
            len(item.get("conditions") or []),
            -_metric_value(item, threshold_metric),
            -float(item.get("hit_100bp") or 0.0),
            -float(item.get("hit_50bp") or 0.0),
            -float(item.get("avg_best_ret") or 0.0),
            -int(item.get("n") or 0),
            str(item.get("label") or ""),
        ),
    )
    for row in ordered:
        row_conditions = list(row.get("conditions") or [])
        row_condition_set = set(str(item) for item in row_conditions)
        duplicate = False
        for prior in kept:
            if str(prior.get("timespan") or "") != str(row.get("timespan") or ""):
                continue
            if str(prior.get("side") or "") != str(row.get("side") or ""):
                continue
            prior_condition_set = set(str(item) for item in (prior.get("conditions") or []))
            if not prior_condition_set.issubset(row_condition_set):
                continue
            metrics_match = (
                int(prior.get("n") or 0) == int(row.get("n") or 0)
                and abs(float(prior.get("hit_30bp") or 0.0) - float(row.get("hit_30bp") or 0.0)) < 1e-9
                and abs(float(prior.get("hit_50bp") or 0.0) - float(row.get("hit_50bp") or 0.0)) < 1e-9
                and abs(float(prior.get("hit_100bp") or 0.0) - float(row.get("hit_100bp") or 0.0)) < 1e-9
                and abs(float(prior.get("avg_best_ret") or 0.0) - float(row.get("avg_best_ret") or 0.0)) < 1e-9
            )
            if metrics_match:
                duplicate = True
                break
        if not duplicate:
            kept.append(row)
    kept.sort(
        key=lambda item: (
            -_metric_value(item, threshold_metric),
            -float(item["hit_100bp"]),
            -float(item["hit_50bp"]),
            -float(item["avg_best_ret"]),
            -int(item["n"]),
            len(item.get("conditions") or []),
            str(item["timespan"]),
            str(item["side"]),
            str(item["label"]),
        )
    )
    return kept


def _build_candidate_predicate(row: Dict[str, object]) -> str:
    clauses = [
        f"timespan = {_sql_quote(str(row.get('timespan') or ''))}",
        f"side = {_sql_quote(str(row.get('side') or ''))}",
    ]
    clauses.extend(str(item) for item in (row.get("conditions") or []))
    return "\n  AND ".join(clauses)


def _build_aggregate_validation_query(
    row: Dict[str, object],
    *,
    base_query: str,
    target_30bp: float,
    target_50bp: float,
    target_100bp: float,
) -> str:
    predicate = _build_candidate_predicate(row)
    return (
        "WITH events AS (\n"
        f"{base_query}\n"
        ")\n"
        "SELECT\n"
        f"    {_sql_quote(str(row.get('timespan') or ''))}::text AS timespan,\n"
        f"    {_sql_quote(str(row.get('side') or ''))}::text AS side,\n"
        f"    {_sql_quote(str(row.get('label') or ''))}::text AS setup_label,\n"
        "    count(*) AS n,\n"
        f"    round(avg(CASE WHEN best_ret >= {_format_numeric_literal(target_30bp)} THEN 1.0 ELSE 0.0 END)::numeric, 4) AS hit_30bp,\n"
        f"    round(avg(CASE WHEN best_ret >= {_format_numeric_literal(target_50bp)} THEN 1.0 ELSE 0.0 END)::numeric, 4) AS hit_50bp,\n"
        f"    round(avg(CASE WHEN best_ret >= {_format_numeric_literal(target_100bp)} THEN 1.0 ELSE 0.0 END)::numeric, 4) AS hit_100bp,\n"
        "    round(avg(best_ret)::numeric, 4) AS avg_best_ret,\n"
        "    round(percentile_cont(0.25) WITHIN GROUP (ORDER BY best_ret)::numeric, 4) AS p25_best_ret,\n"
        "    round(percentile_cont(0.50) WITHIN GROUP (ORDER BY best_ret)::numeric, 4) AS p50_best_ret,\n"
        "    round(percentile_cont(0.75) WITHIN GROUP (ORDER BY best_ret)::numeric, 4) AS p75_best_ret\n"
        "FROM events\n"
        f"WHERE {predicate};\n"
    )


def _build_detail_validation_query(
    row: Dict[str, object],
    *,
    base_query: str,
    limit: int = 250,
) -> str:
    predicate = _build_candidate_predicate(row)
    return (
        "WITH events AS (\n"
        f"{base_query}\n"
        ")\n"
        "SELECT\n"
        "    ticker,\n"
        "    timespan,\n"
        "    side,\n"
        "    ts_epoch,\n"
        "    macd_state,\n"
        "    best_ret,\n"
        "    trigger_up_ret,\n"
        "    trigger_down_ret,\n"
        "    best_up_ret,\n"
        "    best_down_ret,\n"
        "    rsi,\n"
        "    td_buy_count,\n"
        "    td_sell_count,\n"
        "    bb_width,\n"
        "    atr_pct,\n"
        "    rvol,\n"
        "    vwap_dist_pct,\n"
        "    stoch_rsi_k,\n"
        "    stoch_rsi_d,\n"
        "    mfi,\n"
        "    cmo,\n"
        "    roc,\n"
        "    trix,\n"
        "    ultimate_osc,\n"
        "    adx,\n"
        "    trend_regime,\n"
        "    volume_confirm,\n"
        "    squeeze_off,\n"
        "    bb_close_outside_lower,\n"
        "    bb_close_outside_upper,\n"
        "    candle_completely_below_lower,\n"
        "    candle_completely_above_upper,\n"
        "    candle_green,\n"
        "    candle_red,\n"
        "    green_streak,\n"
        "    red_streak,\n"
        "    prev_green_streak,\n"
        "    prev_red_streak,\n"
        "    burst_streak,\n"
        "    vwap_cross_up,\n"
        "    vwap_cross_dn\n"
        "FROM events\n"
        f"WHERE {predicate}\n"
        "ORDER BY ts_epoch DESC, ticker\n"
        f"LIMIT {int(limit)};\n"
    )


def _build_validation_template(
    *,
    base_query: str,
    target_30bp: float,
    target_50bp: float,
    target_100bp: float,
) -> str:
    return (
        "-- Replace {{TIMESPAN}}, {{SIDE}}, and {{PREDICATE}} to validate any setup from this run.\n"
        "WITH events AS (\n"
        f"{base_query}\n"
        ")\n"
        "SELECT\n"
        "    count(*) AS n,\n"
        f"    round(avg(CASE WHEN best_ret >= {_format_numeric_literal(target_30bp)} THEN 1.0 ELSE 0.0 END)::numeric, 4) AS hit_30bp,\n"
        f"    round(avg(CASE WHEN best_ret >= {_format_numeric_literal(target_50bp)} THEN 1.0 ELSE 0.0 END)::numeric, 4) AS hit_50bp,\n"
        f"    round(avg(CASE WHEN best_ret >= {_format_numeric_literal(target_100bp)} THEN 1.0 ELSE 0.0 END)::numeric, 4) AS hit_100bp,\n"
        "    round(avg(best_ret)::numeric, 4) AS avg_best_ret\n"
        "FROM events\n"
        "WHERE timespan = '{{TIMESPAN}}'\n"
        "  AND side = '{{SIDE}}'\n"
        "  AND {{PREDICATE}};\n"
    )


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _write_csv(path: Path, rows: Sequence[Dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            payload = dict(row)
            if "conditions" in payload and isinstance(payload["conditions"], list):
                payload["conditions"] = " | ".join(str(item) for item in payload["conditions"])
            writer.writerow(payload)


def _write_json(path: Path, rows: Sequence[Dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(list(rows), handle, indent=2)


def _write_validation_artifacts(
    output_dir: Path,
    *,
    findings: Sequence[Dict[str, object]],
    base_query: str,
    args: argparse.Namespace,
) -> None:
    universe_sql_path = output_dir / "event_universe.sql"
    template_sql_path = output_dir / "validation_query_template.sql"
    validation_sql_path = output_dir / "candidate_validation_queries.sql"
    query_manifest_json_path = output_dir / "candidate_query_manifest.json"
    run_metadata_path = output_dir / "run_metadata.json"

    base_query = base_query.strip()
    _write_text(universe_sql_path, base_query + ";\n")
    _write_text(
        template_sql_path,
        _build_validation_template(
            base_query=base_query,
            target_30bp=args.target_30bp,
            target_50bp=args.target_50bp,
            target_100bp=args.target_100bp,
        ),
    )

    sql_blocks: List[str] = [
        "-- Validation queries for candidate findings in this run.",
        "-- Each section includes one aggregate check and one locator query.",
        "",
    ]
    manifest_rows: List[Dict[str, object]] = []
    for index, row in enumerate(findings, start=1):
        aggregate_query = _build_aggregate_validation_query(
            row,
            base_query=base_query,
            target_30bp=args.target_30bp,
            target_50bp=args.target_50bp,
            target_100bp=args.target_100bp,
        )
        detail_query = _build_detail_validation_query(
            row,
            base_query=base_query,
        )
        sql_blocks.extend(
            [
                f"-- Candidate {index}: {row.get('timespan')} {row.get('side')} | {row.get('label')}",
                aggregate_query.strip(),
                "",
                detail_query.strip(),
                "",
            ]
        )
        manifest_row = dict(row)
        manifest_row["predicate_sql"] = _build_candidate_predicate(row)
        manifest_row["aggregate_query_sql"] = aggregate_query
        manifest_row["detail_query_sql"] = detail_query
        manifest_rows.append(manifest_row)

    _write_text(validation_sql_path, "\n".join(sql_blocks).rstrip() + "\n")
    _write_json(query_manifest_json_path, manifest_rows)
    _write_json(
        run_metadata_path,
        [
            {
                "generated_at_utc": datetime.now(timezone.utc).isoformat(),
                "timespans": _parse_timespans(args.timespans),
                "window_min": args.window_min,
                "window_max": args.window_max,
                "timespan_window_profile": args.timespan_window_profile,
                "timespan_window_groups": [
                    {
                        "timespans": bucket,
                        "window_min": group_min,
                        "window_max": group_max,
                    }
                    for bucket, group_min, group_max in _timespan_windows(
                        _parse_timespans(args.timespans),
                        window_min=args.window_min,
                        window_max=args.window_max,
                        profile=args.timespan_window_profile,
                    )
                ],
                "target_30bp": args.target_30bp,
                "target_50bp": args.target_50bp,
                "target_100bp": args.target_100bp,
                "outcome_profile": args.outcome_profile,
                "trigger_window_min": args.trigger_window_min,
                "trigger_window_max": args.trigger_window_max,
                "run_window_min": args.run_window_min,
                "run_window_max": args.run_window_max,
                "trigger_min_move": args.trigger_min_move,
                "min_burst_streak": args.min_burst_streak,
                "min_n": args.min_n,
                "hit_threshold": args.hit_threshold,
                "threshold_metric": args.threshold_metric,
                "max_k": args.max_k,
                "event_profile": args.event_profile,
                "condition_profile": args.condition_profile,
            }
        ],
    )


def _write_markdown_summary(
    path: Path,
    *,
    rows: Sequence[Dict[str, object]],
    state_summary: Sequence[Dict[str, object]],
    raw_event_count: int,
    args: argparse.Namespace,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Historical Reversal Research",
        "",
        f"- Source: `public.ca` via `psql COPY`",
        f"- Timespans: {', '.join(_parse_timespans(args.timespans))}",
        f"- Window profile: `{args.timespan_window_profile}`",
        f"- Outcome profile: `{args.outcome_profile}`",
        f"- Windows: {_outcome_profile_label(args)}",
        f"- Filter: indicator-enriched rows only (`bb_width IS NOT NULL`)",
        f"- Event profile: `{args.event_profile}`",
        f"- Condition profile: `{args.condition_profile}`",
        f"- Trigger move floor: `{args.trigger_min_move:.2%}`" if args.outcome_profile == "immediate_run" else None,
        f"- Burst-streak gate: `{args.min_burst_streak}` same-color candles into the signal" if args.min_burst_streak > 0 else None,
        f"- Candidate threshold: `{args.threshold_metric} >= {args.hit_threshold:.2f}` with `n >= {args.min_n}`",
        f"- Exported reversal events: {raw_event_count}",
        f"- Validation SQL: `event_universe.sql`, `validation_query_template.sql`, `candidate_validation_queries.sql`",
        "",
        "## Best MACD-State Baselines",
        "",
    ]
    lines = [line for line in lines if line is not None]
    for row in state_summary[:20]:
        lines.append(
            f"- `{row['timespan']} {row['side']} {row['macd_state']}`: "
            f"`n={row['n']}` `hit30={row['hit_30bp']}` `hit50={row['hit_50bp']}` "
            f"`hit100={row['hit_100bp']}` `avg={row['avg_best_ret']}`"
        )
    lines.append("")
    lines.append("## 85%+ Candidates")
    lines.append("")
    if not rows:
        lines.append("- No candidates cleared the threshold.")
    else:
        for row in rows[:50]:
            lines.append(
                f"- `{row['timespan']} {row['side']}` `{row['label']}`: "
                f"`n={row['n']}` `hit30={row['hit_30bp']}` `hit50={row['hit_50bp']}` "
                f"`hit100={row['hit_100bp']}` `avg={row['avg_best_ret']}`"
            )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = _parse_args()
    timespans = _parse_timespans(args.timespans)
    output_dir = Path(args.output_dir)
    raw_query = _build_event_query(
        timespans,
        args.window_min,
        args.window_max,
        event_profile=args.event_profile,
        timespan_window_profile=args.timespan_window_profile,
        outcome_profile=args.outcome_profile,
        trigger_window_min=args.trigger_window_min,
        trigger_window_max=args.trigger_window_max,
        run_window_min=args.run_window_min,
        run_window_max=args.run_window_max,
        trigger_min_move=args.trigger_min_move,
        min_burst_streak=args.min_burst_streak,
        include_order_by=True,
    )
    base_query = _build_event_query(
        timespans,
        args.window_min,
        args.window_max,
        event_profile=args.event_profile,
        timespan_window_profile=args.timespan_window_profile,
        outcome_profile=args.outcome_profile,
        trigger_window_min=args.trigger_window_min,
        trigger_window_max=args.trigger_window_max,
        run_window_min=args.run_window_min,
        run_window_max=args.run_window_max,
        trigger_min_move=args.trigger_min_move,
        min_burst_streak=args.min_burst_streak,
        include_order_by=False,
    )
    raw_rows = _run_copy_query(args, raw_query)
    normalized_rows = _normalize_rows(raw_rows)

    state_summary = _build_state_summary(
        normalized_rows,
        min_n=args.min_n,
        threshold_metric=args.threshold_metric,
        target_30bp=args.target_30bp,
        target_50bp=args.target_50bp,
        target_100bp=args.target_100bp,
    )

    findings: List[Dict[str, object]] = []
    for timespan in timespans:
        for side in ("bull", "bear"):
            subset = [
                row
                for row in normalized_rows
                if str(row.get("timespan") or "") == timespan
                and str(row.get("side") or "") == side
            ]
            findings.extend(
                _scan_candidates(
                    subset,
                    side,
                    timespan,
                    condition_profile=args.condition_profile,
                    min_n=args.min_n,
                    hit_threshold=args.hit_threshold,
                    threshold_metric=args.threshold_metric,
                    target_30bp=args.target_30bp,
                    target_50bp=args.target_50bp,
                    target_100bp=args.target_100bp,
                    max_k=args.max_k,
                )
            )

    findings.sort(
        key=lambda item: (
            -_metric_value(item, args.threshold_metric),
            -float(item["hit_100bp"]),
            -float(item["hit_50bp"]),
            -float(item["avg_best_ret"]),
            -int(item["n"]),
            str(item["timespan"]),
            str(item["side"]),
            str(item["label"]),
        )
    )
    findings = _prune_redundant_findings(findings, threshold_metric=args.threshold_metric)

    raw_events_path = output_dir / "base_events_enriched.csv"
    state_csv_path = output_dir / "state_reversal_rates.csv"
    state_json_path = output_dir / "state_reversal_rates.json"
    findings_csv_path = output_dir / "candidate_findings_85.csv"
    findings_json_path = output_dir / "candidate_findings_85.json"
    summary_path = output_dir / "findings_summary.md"

    _write_csv(raw_events_path, normalized_rows)
    _write_csv(state_csv_path, state_summary)
    _write_json(state_json_path, state_summary)
    _write_csv(findings_csv_path, findings)
    _write_json(findings_json_path, findings)
    _write_validation_artifacts(
        output_dir,
        findings=findings,
        base_query=base_query,
        args=args,
    )
    _write_markdown_summary(
        summary_path,
        rows=findings,
        state_summary=state_summary,
        raw_event_count=len(normalized_rows),
        args=args,
    )

    print(f"wrote_raw_events={raw_events_path}")
    print(f"wrote_state_csv={state_csv_path}")
    print(f"wrote_state_json={state_json_path}")
    print(f"wrote_findings_csv={findings_csv_path}")
    print(f"wrote_findings_json={findings_json_path}")
    print(f"wrote_event_universe_sql={output_dir / 'event_universe.sql'}")
    print(f"wrote_validation_template_sql={output_dir / 'validation_query_template.sql'}")
    print(f"wrote_validation_queries_sql={output_dir / 'candidate_validation_queries.sql'}")
    print(f"wrote_query_manifest_json={output_dir / 'candidate_query_manifest.json'}")
    print(f"wrote_run_metadata_json={output_dir / 'run_metadata.json'}")
    print(f"wrote_summary_md={summary_path}")


if __name__ == "__main__":
    main()
