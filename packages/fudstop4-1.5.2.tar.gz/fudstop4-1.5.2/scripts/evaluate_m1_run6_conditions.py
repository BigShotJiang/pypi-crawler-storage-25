#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Sequence

import pandas as pd


DEFAULT_SIGNAL_ROWS = (
    r"runs/run6_m1_pre_run_scan/"
    r"consecutive_color_combo_scan_pre_run_m1_streak6_n15_h85_2026-04-20/"
    r"signal_rows.csv"
)
DEFAULT_OUTPUT_DIR = r"burst_discovery_output"
TRUTHY = {"true", "t", "1", "yes", "y"}
FALSY = {"false", "f", "0", "no", "n"}
COMPARISON_RE = re.compile(
    r"^(?P<field>[A-Za-z_][A-Za-z0-9_]*)\s*(?P<op><=|>=|!=|==|=|<|>)\s*(?P<value>.+?)\s*$"
)

NUMERIC_FIELDS = [
    "o",
    "c",
    "h",
    "l",
    "v",
    "body_pct",
    "hl_range_pct",
    "upper_wick",
    "lower_wick",
    "rsi",
    "td_buy_count",
    "td_sell_count",
    "macd_hist",
    "bb_width",
    "rvol",
    "atr_pct",
    "chop",
    "vwap_dist_pct",
    "stoch_rsi_k",
    "stoch_rsi_d",
    "mfi",
    "cmo",
    "roc",
    "trix",
    "ultimate_osc",
    "adx",
    "pre_close_pos",
    "pre_red_streak",
    "pre_green_streak",
    "pre_down_close_streak",
    "pre_up_close_streak",
    "pre_prev5_red_count",
    "pre_prev5_green_count",
    "pre_macd_state_code",
    "pre_body_pct",
    "bull_best_ret",
    "bear_best_ret",
    "bull_run_len",
    "bear_run_len",
]

BOOLEAN_FIELDS = [
    "candle_green",
    "candle_red",
    "bb_close_outside_lower",
    "bb_close_outside_upper",
    "candle_completely_below_lower",
    "candle_completely_above_upper",
    "trend_regime",
    "volume_confirm",
    "squeeze_off",
    "vwap_cross_up",
    "vwap_cross_dn",
    "adx_strong",
    "pre_candle_red",
    "pre_candle_green",
    "pre_bb_close_outside_lower",
    "pre_bb_close_outside_upper",
    "pre_candle_completely_below_lower",
    "pre_candle_completely_above_upper",
    "pre_volume_confirm",
    "pre_trend_regime",
    "pre_squeeze_off",
    "pre_vwap_cross_up",
    "pre_vwap_cross_dn",
    "pre_adx_strong",
]

BASE_REQUIRED_COLUMNS = ["ticker", "timespan", "ts_epoch", "bull_success", "bear_success"]


@dataclass(frozen=True)
class ParsedCondition:
    field: str
    op: str
    value: Any
    raw: str
    expr: str
    fn: Callable[[pd.DataFrame], pd.Series]


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate ad hoc m1 pre-run condition stacks against the saved "
            "run6 signal universe and search additive clauses."
        )
    )
    parser.add_argument("--signal-rows-csv", default=DEFAULT_SIGNAL_ROWS)
    parser.add_argument("--side", choices=("bull", "bear"), default="bull")
    parser.add_argument("--condition", action="append", default=[])
    parser.add_argument("--conditions-file", default="")
    parser.add_argument("--stdin", action="store_true")
    parser.add_argument("--expand-k", type=int, default=2)
    parser.add_argument("--top-clause-pool", type=int, default=18)
    parser.add_argument("--top-results", type=int, default=20)
    parser.add_argument("--min-oos", type=int, default=25)
    parser.add_argument("--min-oos-precision", type=float, default=0.85)
    parser.add_argument("--min-validation", type=float, default=0.80)
    parser.add_argument("--min-holdout", type=float, default=0.85)
    parser.add_argument("--min-unique-tickers", type=int, default=10)
    parser.add_argument("--max-top-share", type=float, default=0.35)
    parser.add_argument("--output-prefix", default="")
    return parser.parse_args()


def _read_condition_lines(args: argparse.Namespace) -> List[str]:
    lines: List[str] = []
    lines.extend(args.condition or [])
    if args.conditions_file:
        lines.extend(Path(args.conditions_file).read_text(encoding="utf-8").splitlines())
    if args.stdin or (not lines and not sys.stdin.isatty()):
        lines.extend(sys.stdin.read().splitlines())
    cleaned = [line.strip() for line in lines if line.strip() and not line.strip().startswith("#")]
    if not cleaned:
        raise ValueError("no conditions supplied; use --condition, --conditions-file, or pipe stdin")
    return cleaned


def _parse_scalar(raw_value: str) -> Any:
    text = str(raw_value or "").strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in {"'", '"'}:
        text = text[1:-1]
    lowered = text.lower()
    if lowered in TRUTHY:
        return True
    if lowered in FALSY:
        return False
    try:
        return float(text)
    except ValueError:
        return text


def _format_literal(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return "'" + value.replace("'", "''") + "'"
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return f"{value:g}" if isinstance(value, float) else str(value)


def _coerce_bool_series(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.astype("boolean")
    if pd.api.types.is_numeric_dtype(series):
        out = pd.Series(pd.NA, index=series.index, dtype="boolean")
        valid = series.notna()
        out.loc[valid] = series.loc[valid] != 0
        return out
    text = series.astype(str).str.strip().str.lower()
    out = pd.Series(pd.NA, index=series.index, dtype="boolean")
    out.loc[text.isin(TRUTHY)] = True
    out.loc[text.isin(FALSY | {"", "none", "nan", "<na>"})] = False
    return out


def _make_series_fn(field: str, op: str, value: Any) -> Callable[[pd.DataFrame], pd.Series]:
    def _numeric_compare(df: pd.DataFrame) -> pd.Series:
        series = pd.to_numeric(df[field], errors="coerce")
        if op == "<=":
            return series.notna() & (series <= value)
        if op == ">=":
            return series.notna() & (series >= value)
        if op == "<":
            return series.notna() & (series < value)
        if op == ">":
            return series.notna() & (series > value)
        if op in ("=", "=="):
            return series.notna() & (series == value)
        if op == "!=":
            return series.notna() & (series != value)
        raise ValueError(f"unsupported numeric operator: {op}")

    def _bool_compare(df: pd.DataFrame) -> pd.Series:
        series = _coerce_bool_series(df[field])
        if op in ("=", "=="):
            return series.eq(value).fillna(False)
        if op == "!=":
            return series.ne(value).fillna(False)
        raise ValueError(f"boolean field {field} only supports = and !=")

    def _string_compare(df: pd.DataFrame) -> pd.Series:
        series = df[field].astype(str).str.strip().str.lower()
        target = str(value).strip().lower()
        if op in ("=", "=="):
            return series.eq(target)
        if op == "!=":
            return series.ne(target)
        raise ValueError(f"string field {field} only supports = and !=")

    if isinstance(value, bool):
        return _bool_compare
    if isinstance(value, (int, float)):
        return _numeric_compare
    return _string_compare


def _parse_condition_line(line: str) -> ParsedCondition:
    raw = str(line or "").strip()
    match = COMPARISON_RE.match(raw)
    if match:
        field = match.group("field")
        op = match.group("op")
        value = _parse_scalar(match.group("value"))
    else:
        field = raw
        op = "="
        value = True
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", field):
        raise ValueError(f"invalid field in condition: {raw}")
    expr = f"{field} {op} {_format_literal(value)}" if not isinstance(value, bool) else (
        f"{field} = {'true' if value else 'false'}" if op in ('=','==') else f"{field} != {'true' if value else 'false'}"
    )
    return ParsedCondition(
        field=field,
        op=op,
        value=value,
        raw=raw,
        expr=expr,
        fn=_make_series_fn(field, op, value),
    )


def _safe_slug(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "_", value).strip("_").lower()
    return slug[:48] or "rule"


def _canonical_sql(predicate: str) -> str:
    clauses = [part.strip() for part in str(predicate).split("AND") if part.strip()]
    return " AND ".join(sorted(clauses))


def _wilson_lower_bound(wins: int, total: int, z: float = 1.96) -> float:
    if total <= 0:
        return 0.0
    phat = wins / total
    denom = 1.0 + (z * z) / total
    centre = phat + (z * z) / (2.0 * total)
    margin = z * ((phat * (1.0 - phat) + (z * z) / (4.0 * total)) / total) ** 0.5
    return (centre - margin) / denom


def _chrono_cuts(df: pd.DataFrame) -> tuple[int, int]:
    unique_ts = sorted(df["ts_epoch"].unique().tolist())
    if len(unique_ts) < 12:
        raise ValueError("not enough timestamps for chrono split")
    cut1 = unique_ts[int(len(unique_ts) * 0.50)]
    cut2 = unique_ts[int(len(unique_ts) * 0.75)]
    return cut1, cut2


def _score_subset(subset: pd.DataFrame, cut1: int, cut2: int, success_col: str) -> Dict[str, object]:
    train = subset.loc[subset["ts_epoch"] < cut1]
    valid = subset.loc[(subset["ts_epoch"] >= cut1) & (subset["ts_epoch"] < cut2)]
    hold = subset.loc[subset["ts_epoch"] >= cut2]
    train_n = int(len(train))
    valid_n = int(len(valid))
    hold_n = int(len(hold))
    train_wins = int(train[success_col].sum())
    valid_wins = int(valid[success_col].sum())
    hold_wins = int(hold[success_col].sum())
    oos_n = valid_n + hold_n
    oos_wins = valid_wins + hold_wins
    oos_precision = (oos_wins / oos_n) if oos_n else 0.0
    ticker_counts = subset.loc[subset["ts_epoch"] >= cut1, "ticker"].value_counts()
    top_share = (float(ticker_counts.iloc[0]) / oos_n) if oos_n and not ticker_counts.empty else 0.0
    return {
        "train_n": train_n,
        "train_hit": (train_wins / train_n) if train_n else 0.0,
        "valid_n": valid_n,
        "valid_hit": (valid_wins / valid_n) if valid_n else 0.0,
        "hold_n": hold_n,
        "hold_hit": (hold_wins / hold_n) if hold_n else 0.0,
        "oos_n": oos_n,
        "oos_wins": oos_wins,
        "oos_hit": oos_precision,
        "wilson": _wilson_lower_bound(oos_wins, oos_n),
        "unique_tickers": int(ticker_counts.shape[0]),
        "top_share": top_share,
    }


def _support_hash(index: pd.Index) -> str:
    values = index.to_numpy(dtype="int64", copy=False)
    return hashlib.md5(values.tobytes()).hexdigest()


def _candidate_key(side: str, base_conditions: Sequence[ParsedCondition], extras: Sequence[str]) -> str:
    base_slug = "_".join(_safe_slug(cond.raw) for cond in base_conditions)
    extra_slug = "_".join(_safe_slug(value) for value in extras)
    digest = hashlib.md5((side + "||" + "||".join(cond.raw for cond in base_conditions) + "||" + "||".join(extras)).encode("utf-8")).hexdigest()[:6]
    return f"run6_{side}_{base_slug[:32]}_{extra_slug[:40]}_{digest}"


def _parse_csv_columns(path: Path) -> List[str]:
    frame = pd.read_csv(path, nrows=0)
    return list(frame.columns)


def _load_signal_rows(path: Path, usecols: Sequence[str]) -> pd.DataFrame:
    df = pd.read_csv(path, usecols=list(dict.fromkeys(usecols)), low_memory=False)
    for col in BASE_REQUIRED_COLUMNS:
        if col in df.columns and col != "ticker" and col != "timespan":
            df[col] = pd.to_numeric(df[col], errors="coerce")
    for col in NUMERIC_FIELDS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    for col in BOOLEAN_FIELDS + ["bull_success", "bear_success"]:
        if col in df.columns:
            df[col] = _coerce_bool_series(df[col]).fillna(False).astype(bool)
    if "ticker" in df.columns:
        df["ticker"] = df["ticker"].astype(str).str.upper().str.strip()
    if "timespan" in df.columns:
        df["timespan"] = df["timespan"].astype(str).str.lower().str.strip()
    return df


def _evaluate_conditions(df: pd.DataFrame, conditions: Sequence[ParsedCondition]) -> pd.Series:
    mask = pd.Series(True, index=df.index)
    for cond in conditions:
        mask &= cond.fn(df).fillna(False)
    return mask


def _build_clause_specs(df: pd.DataFrame, excluded_fields: set[str] | None = None) -> List[tuple[str, str, str, Callable[[pd.DataFrame], pd.Series]]]:
    excluded_fields = excluded_fields or set()
    specs: List[tuple[str, str, str, Callable[[pd.DataFrame], pd.Series]]] = []
    for field in NUMERIC_FIELDS:
        if field in excluded_fields or field not in df.columns:
            continue
        series = pd.to_numeric(df[field], errors="coerce")
        if series.notna().mean() < 0.45:
            continue
        quantiles = []
        for q in (0.2, 0.3, 0.7, 0.8):
            value = float(series.quantile(q))
            if pd.isna(value):
                continue
            quantiles.append(round(value, 6))
        for value in sorted(set(quantiles)):
            specs.append(
                (
                    field,
                    f"{field}>={value:g}",
                    f"{field} >= {value:.6g}",
                    lambda frame, f=field, v=value: pd.to_numeric(frame[f], errors='coerce').notna() & (pd.to_numeric(frame[f], errors='coerce') >= v),
                )
            )
            specs.append(
                (
                    field,
                    f"{field}<={value:g}",
                    f"{field} <= {value:.6g}",
                    lambda frame, f=field, v=value: pd.to_numeric(frame[f], errors='coerce').notna() & (pd.to_numeric(frame[f], errors='coerce') <= v),
                )
            )
    for field in BOOLEAN_FIELDS:
        if field in excluded_fields or field not in df.columns:
            continue
        bool_series = _coerce_bool_series(df[field])
        true_count = int(bool_series.fillna(False).sum())
        if true_count < 25:
            continue
        specs.append(
            (
                field,
                field,
                f"{field} = true",
                lambda frame, f=field: _coerce_bool_series(frame[f]).fillna(False),
            )
        )
    deduped: Dict[str, tuple[str, str, str, Callable[[pd.DataFrame], pd.Series]]] = {}
    for spec in specs:
        deduped.setdefault(spec[1], spec)
    return list(deduped.values())


def _passing_score(scored: Dict[str, object], args: argparse.Namespace) -> bool:
    return bool(
        scored["oos_n"] >= args.min_oos
        and scored["oos_hit"] >= args.min_oos_precision
        and scored["valid_hit"] >= args.min_validation
        and scored["hold_hit"] >= args.min_holdout
        and scored["unique_tickers"] >= args.min_unique_tickers
        and scored["top_share"] <= args.max_top_share
    )


def _write_outputs(prefix: Path, base_result: Dict[str, object], extensions: Sequence[Dict[str, object]]) -> None:
    prefix.parent.mkdir(parents=True, exist_ok=True)
    payload = {"base_result": base_result, "extensions": list(extensions)}
    prefix.with_suffix(".json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    pd.DataFrame(extensions).to_csv(prefix.parent / f"{prefix.name}_extensions.csv", index=False)


def main() -> None:
    args = _parse_args()
    lines = _read_condition_lines(args)
    conditions = [_parse_condition_line(line) for line in lines]
    path = Path(args.signal_rows_csv)
    available_columns = set(_parse_csv_columns(path))

    missing = sorted({cond.field for cond in conditions if cond.field not in available_columns})
    if missing:
        raise KeyError(f"unknown fields in signal rows: {', '.join(missing)}")

    candidate_fields = [field for field in NUMERIC_FIELDS + BOOLEAN_FIELDS if field in available_columns]
    usecols = BASE_REQUIRED_COLUMNS + candidate_fields + [cond.field for cond in conditions]
    df = _load_signal_rows(path, usecols)
    df = df.loc[df["timespan"] == "m1"].copy()
    if df.empty:
        raise ValueError("m1 signal rows are empty")

    success_col = "bull_success" if args.side == "bull" else "bear_success"
    cut1, cut2 = _chrono_cuts(df)
    base_mask = _evaluate_conditions(df, conditions)
    base_subset = df.loc[base_mask].copy()
    if base_subset.empty:
        raise ValueError("base condition set matched zero signal rows")

    base_result = _score_subset(base_subset, cut1, cut2, success_col)
    base_result.update(
        {
            "predicate": " AND ".join(cond.expr for cond in conditions),
            "condition_lines": [cond.raw for cond in conditions],
            "row_count": int(len(base_subset)),
            "side": args.side,
        }
    )
    base_pass = _passing_score(base_result, args)

    used_fields = {cond.field for cond in conditions}
    clause_specs = _build_clause_specs(base_subset, excluded_fields=used_fields)
    support_seen: Dict[str, Dict[str, object]] = {}

    for field, label, expr, fn in clause_specs:
        clause_mask = fn(base_subset)
        selectivity = float(clause_mask.mean()) if len(clause_mask) else 0.0
        if selectivity <= 0.05 or selectivity >= 0.95:
            continue
        subset = base_subset.loc[clause_mask].copy()
        if len(subset) < args.min_oos:
            continue
        scored = _score_subset(subset, cut1, cut2, success_col)
        scored.update(
            {
                "predicate": " AND ".join([cond.expr for cond in conditions] + [expr]),
                "canonical": _canonical_sql(" AND ".join([cond.expr for cond in conditions] + [expr])),
                "extra_fields": field,
                "extra_labels": label,
                "extra_clause_count": 1,
                "rule_id": _candidate_key(args.side, conditions, [label]),
            }
        )
        support_seen[_support_hash(subset.index)] = scored

    top_singles = sorted(
        support_seen.values(),
        key=lambda item: (item["oos_n"], item["oos_hit"], item["wilson"]),
        reverse=True,
    )[: args.top_clause_pool]
    clause_lookup = {label: (field, label, expr, fn) for field, label, expr, fn in clause_specs}

    for extra_k in range(2, max(2, args.expand_k) + 1):
        for combo in itertools.combinations(top_singles, extra_k):
            combo_labels = [str(item["extra_labels"]) for item in combo]
            combo_specs = [clause_lookup[label] for label in combo_labels if label in clause_lookup]
            if len(combo_specs) != extra_k:
                continue
            combo_fields = [spec[0] for spec in combo_specs]
            if len(set(combo_fields)) != len(combo_fields):
                continue
            combo_mask = pd.Series(True, index=base_subset.index)
            for _, _, _, fn in combo_specs:
                combo_mask &= fn(base_subset)
            selectivity = float(combo_mask.mean()) if len(combo_mask) else 0.0
            if selectivity <= 0.05 or selectivity >= 0.95:
                continue
            subset = base_subset.loc[combo_mask].copy()
            if len(subset) < args.min_oos:
                continue
            predicates = [cond.expr for cond in conditions] + [spec[2] for spec in combo_specs]
            scored = _score_subset(subset, cut1, cut2, success_col)
            scored.update(
                {
                    "predicate": " AND ".join(predicates),
                    "canonical": _canonical_sql(" AND ".join(predicates)),
                    "extra_fields": "|".join(sorted(combo_fields)),
                    "extra_labels": "|".join(spec[1] for spec in combo_specs),
                    "extra_clause_count": extra_k,
                    "rule_id": _candidate_key(args.side, conditions, [spec[1] for spec in combo_specs]),
                }
            )
            existing = support_seen.get(_support_hash(subset.index))
            if existing is None or (
                scored["oos_n"],
                scored["oos_hit"],
                scored["wilson"],
            ) > (
                existing["oos_n"],
                existing["oos_hit"],
                existing["wilson"],
            ):
                support_seen[_support_hash(subset.index)] = scored

    deduped: Dict[str, Dict[str, object]] = {}
    for row in support_seen.values():
        canonical = str(row["canonical"])
        existing = deduped.get(canonical)
        if existing is None or (
            row["oos_n"],
            row["oos_hit"],
            row["wilson"],
        ) > (
            existing["oos_n"],
            existing["oos_hit"],
            existing["wilson"],
        ):
            deduped[canonical] = row
    passing = [
        row
        for row in sorted(
            deduped.values(),
            key=lambda item: (item["oos_n"], item["oos_hit"], item["wilson"]),
            reverse=True,
        )
        if _passing_score(row, args)
    ]

    print(f"Loaded m1 signal rows: {len(df)}")
    print(f"Base subset rows: {len(base_subset)}")
    print("Base condition stack")
    print(f"  predicate: {base_result['predicate']}")
    print(
        "  oos={oos_n} hit={oos_hit:.4f} valid={valid_hit:.4f} hold={hold_hit:.4f} "
        "train_n={train_n} valid_n={valid_n} hold_n={hold_n} tickers={unique_tickers} "
        "top_share={top_share:.4f} pass_85={passed}".format(
            passed=str(base_pass).lower(),
            **base_result,
        )
    )
    print()
    print(f"Passing additive extensions: {len(passing)}")
    for idx, row in enumerate(passing[: args.top_results], 1):
        print(
            f"{idx}. extras={row['extra_labels']} | "
            f"oos={row['oos_n']} hit={row['oos_hit']:.4f} valid={row['valid_hit']:.4f} "
            f"hold={row['hold_hit']:.4f} tickers={row['unique_tickers']} top_share={row['top_share']:.4f}"
        )
        print(f"   predicate: {row['predicate']}")

    if args.output_prefix:
        prefix = Path(args.output_prefix)
        _write_outputs(prefix, base_result, passing)
        print()
        print(f"Wrote outputs: {prefix.with_suffix('.json')} and {prefix.parent / (prefix.name + '_extensions.csv')}")


if __name__ == "__main__":
    main()
