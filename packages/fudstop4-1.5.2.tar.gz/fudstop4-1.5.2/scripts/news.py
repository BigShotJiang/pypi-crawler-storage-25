#!/usr/bin/env python3
"""
Compute the total in-the-money (ITM) dollar value for options on a list of tickers.

This version adds structured logging, CLI flags for batch size and sleep duration,
and optional one-shot execution for testing. Database connections are managed
at the process level so individual computations remain side-effect free.
"""
import json
import argparse
import asyncio
import logging
import sys
from pathlib import Path
import os
import time
import aiohttp
import pandas as pd

project_dir = str(Path(__file__).resolve().parents[1])
if project_dir not in sys.path:
    sys.path.append(project_dir)
from dotenv import load_dotenv
load_dotenv()
from fudstop4.apis.webull.webull_trading import WebullTrading
from fudstop4.apis.webull.trade_models.ai_news import AINews
from fudstop4.apis.polygonio.polygon_options import PolygonOptions
from fudstop4._markets.list_sets.ticker_lists import most_active_tickers
from fudstop4.apis.helpers import generate_webull_headers

db = PolygonOptions()


wbt = WebullTrading()




CONCURRENCY = 10            # overall max concurrent requests
BATCH_SIZE = 5              # tickers per batch
UPDATE_INTERVAL = 300       # 5 minutes

def normalize_related_tickers_col(df: pd.DataFrame) -> pd.DataFrame:
    if "related_tickers" not in df.columns:
        return df

    df["related_tickers"] = df["related_tickers"].apply(
        lambda x: ",".join(
            (i.get("ticker") or i.get("symbol") or str(i)) if isinstance(i, dict) else str(i)
            for i in x
        ) if isinstance(x, (list, tuple)) else (json.dumps(x) if isinstance(x, dict) else x)
    )
    return df

def chunked(seq, size):
    for i in range(0, len(seq), size):
        yield seq[i:i + size]

async def fetch_and_upsert_news(ticker: str, semaphore: asyncio.Semaphore):
    async with semaphore:
        try:
            ticker_id = wbt.ticker_to_id_map.get(ticker)
            if not ticker_id:
                print(f"[ai_news] {ticker} skipped: missing Webull ticker id")
                return 0

            endpoint = (
                "https://nacomm.webullfintech.com/api/information/news/"
                f"tickerNewses/v9?tickerId={ticker_id}&pageSize=1&showAiNews=true"
            )
            headers = generate_webull_headers(access_token=os.environ.get("ACCESS_TOKEN"))
            async with aiohttp.ClientSession(headers=headers) as session:
                async with session.get(endpoint) as resp:
                    if resp.status == 403:
                        print(f"[ai_news] {ticker} skipped: Webull returned 403")
                        return 0
                    if resp.content_type != "application/json":
                        print(
                            f"[ai_news] {ticker} skipped: unexpected content-type "
                            f"{resp.content_type!r} (status={resp.status})"
                        )
                        return 0
                    data = await resp.json()
            if not isinstance(data, list):
                print(f"[ai_news] {ticker} skipped: unexpected payload type {type(data).__name__}")
                return 0

            news = AINews(data)

            df = news.as_dataframe
            if df is None or df.empty:
                return 0

            df = df.reset_index(drop=True)
            df = normalize_related_tickers_col(df)
            df["ticker"] = ticker

            await db.batch_upsert_dataframe(df, table_name="ai_news", unique_columns=["ticker"])
            return len(df)

        except Exception as e:
            # keep loop alive even if one ticker fails
            print(f"[ai_news] {ticker} failed: {e}")
            return 0

async def run_ai_news_loop():
    await db.connect()
    semaphore = asyncio.Semaphore(CONCURRENCY)

    while True:
        start = time.monotonic()

        tickers = list(most_active_tickers)
        total_rows = 0

        # run in batches of 5
        for batch in chunked(tickers, BATCH_SIZE):
            tasks = [fetch_and_upsert_news(t, semaphore) for t in batch]
            results = await asyncio.gather(*tasks, return_exceptions=False)
            total_rows += sum(results)

            # tiny pause between batches to be polite (optional)
            await asyncio.sleep(0.25)

        elapsed = time.monotonic() - start
        sleep_for = max(0, UPDATE_INTERVAL - elapsed)
        print(f"[ai_news] done: {len(tickers)} tickers, {total_rows} row(s), elapsed={elapsed:.2f}s, sleep={sleep_for:.2f}s")

        await asyncio.sleep(sleep_for)

if __name__ == "__main__":
    asyncio.run(run_ai_news_loop())
