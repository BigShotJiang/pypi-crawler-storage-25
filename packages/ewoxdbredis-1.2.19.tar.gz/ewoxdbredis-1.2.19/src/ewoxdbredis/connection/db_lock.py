from typing import Optional, Union
import redis
from redis.asyncio.lock import Lock


class DBLock:
    def __init__(
        self,
        redis: Union[redis.RedisCluster, redis.Redis],
        name: str,
        timeout: int = 30,
        blocking: bool = False,
        blocking_timeout: Optional[float] = None,
    ) -> None:
        self._redis = redis
        self._name = name
        self._timeout = timeout
        self._blocking = blocking
        self._blocking_timeout = blocking_timeout
        self._lock: Optional[Lock] = None
        self._acquired = False


    async def __aenter__(self) -> "DBLock":
        print(f"Attempting to acquire lock: {self._name}")
        self._lock = self._redis.lock(
            self._name,
            timeout=self._timeout,
            blocking=self._blocking,
            blocking_timeout=self._blocking_timeout,
        )
        self._acquired = await self._lock.acquire()
        print(f"Lock {self._name} acquired: {self._acquired}")

        return self


    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self._lock and self._acquired:
            try:
                await self._lock.release()
            except Exception:
                # lock may already have expired
                print(f"Failed to release lock {self._name}, it may have already expired.")
                pass