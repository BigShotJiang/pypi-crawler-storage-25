from pptx.chart.data import CategoryChartData, XyChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_DATA_LABEL_POSITION, XL_LEGEND_POSITION, XL_TICK_LABEL_POSITION
from pptx.util import Pt

from deckbridge.renderers.common.style_resolver import (
    resolve_chart_theme,
    resolve_series_color,
    resolve_series_dash,
    resolve_series_width,
)
from deckbridge.renderers.pptx.utils import PPTX_DASH_MAP, _validate_xy_numeric, hex_to_rgb255


class PPTXChartBuilder:
    def build_chart_data(self, spec):
        """
        Build chart type + data (no styling here)
        """
        chart_data = self._build_chart_data(spec)
        chart_type = self._map_chart_type(spec.chart_type)

        return chart_type, chart_data

    def apply_chart_style(self, chart, theme, layout_name, block, value_axis_override):
        """
        Apply theme-driven styling to a chart object
        """
        chart_theme = resolve_chart_theme(theme, layout_name, block.style_overrides)

        self._single_series_bar_chart(chart)
        self._set_chart_title(chart, chart_theme, block)
        self._set_chart_subtitle(chart, chart_theme, block)
        self._set_axis_title(chart, chart_theme, "value_axis", block.value_axis_title)
        self._set_axis_title(chart, chart_theme, "category_axis", block.category_axis_title)
        self._apply_legend_style(chart, chart_theme)
        self._turn_gridlines_off(chart)
        self._category_tick_label_low(chart)
        self._apply_axis_style(chart, chart_theme, block, value_axis_override)
        self._set_data_labels(chart, chart_theme, block)
        self._set_series_colors(chart, chart_theme, block)
        self._set_series_dashes(chart, chart_theme, block)
        self._set_series_line_width(chart, chart_theme, block)
        self._no_lines_scatter_chart(chart)

    def _build_chart_data(self, spec):
        if spec.chart_type == "scatter":
            chart_data = XyChartData()

            x_values = list(spec.data[spec.x])

            for s in spec.series:
                y_values = list(spec.data[s["column"]])
                _validate_xy_numeric(x_values, y_values, spec.x, s["column"])
                series = chart_data.add_series(s["name"])

                for x, y in zip(x_values, y_values):
                    series.add_data_point(x, y)
        else:
            chart_data = CategoryChartData()

            categories = list(spec.data[spec.x])
            chart_data.categories = categories

            for s in spec.series:
                values = list(spec.data[s["column"]])
                chart_data.add_series(s["name"], values)

        return chart_data

    def _map_chart_type(self, chart_type):
        mapping = {
            "line": XL_CHART_TYPE.LINE,
            "bar": XL_CHART_TYPE.COLUMN_CLUSTERED,
            "area_stacked": XL_CHART_TYPE.AREA_STACKED,
            "area_stacked_100": XL_CHART_TYPE.AREA_STACKED_100,
            "bar_stacked": XL_CHART_TYPE.BAR_STACKED,
            "column_stacked": XL_CHART_TYPE.COLUMN_STACKED,
            "scatter": XL_CHART_TYPE.XY_SCATTER_SMOOTH,
        }

        if chart_type not in mapping:
            raise ValueError(f"Unsupported chart type: {chart_type}")

        return mapping[chart_type]

    def _single_series_bar_chart(self, chart):
        if chart.chart_type == self._map_chart_type("bar") and len(chart.plots[0].series) == 1:
            chart.plots[0].vary_by_categories = False

    def _no_lines_scatter_chart(self, chart):
        if chart.chart_type == self._map_chart_type("scatter"):
            for s in chart.series:
                s.format.line.visible = False
                s.format.line.fill.background()

    def _set_chart_title(self, chart, chart_theme, block):
        if chart_theme["chart_title"]["has_title"]:
            chart.has_title = True
            chart_title = chart.chart_title.text_frame.paragraphs[0]
            chart_title.text = block.chart_title
            chart_title.font.size = Pt(chart_theme["chart_title"]["font_size"])
            chart_title.font.bold = chart_theme["chart_title"]["bold"]
            chart_title.font.italic = chart_theme["chart_title"]["italic"]
            chart_title.font.underline = chart_theme["chart_title"]["underline"]
        else:
            chart.has_title = False

    def _set_chart_subtitle(self, chart, chart_theme, block):
        if chart_theme["chart_title"]["has_title"] and chart_theme["chart_subtitle"]["has_title"]:
            chart.chart_title.text_frame.add_paragraph()
            chart_subtitle = chart.chart_title.text_frame.paragraphs[1]
            chart_subtitle.text = block.chart_subtitle
            for run in chart_subtitle.runs:
                run.font.size = Pt(chart_theme["chart_subtitle"]["font_size"])
                run.font.bold = chart_theme["chart_subtitle"]["bold"]
                run.font.italic = chart_theme["chart_subtitle"]["italic"]
                run.font.underline = chart_theme["chart_subtitle"]["underline"]

    def _set_axis_title(self, chart, chart_theme, axis, axis_title):
        axis_theme = chart_theme.get(axis, {})

        if axis == "value_axis":
            axis_obj = chart.value_axis
        elif axis == "category_axis":
            axis_obj = chart.category_axis

        axis_obj.has_title = axis_theme["has_title"]
        if axis_theme["has_title"] and axis_title:
            axis_obj.axis_title.text_frame.text = axis_title

            for paragraph in axis_obj.axis_title.text_frame.paragraphs:
                paragraph.font.size = Pt(axis_theme["font_size"])
                paragraph.font.bold = axis_theme["bold"]
                paragraph.font.italic = axis_theme["italic"]
                paragraph.font.underline = axis_theme["underline"]
        else:
            axis_obj.has_title = False

        axis_obj.tick_labels.font.size = Pt(axis_theme["font_size"])

    def _apply_legend_style(self, chart, chart_theme):
        legend_theme = chart_theme.get("legend", {})

        chart.has_legend = legend_theme["visible"]
        if not legend_theme["visible"]:
            return

        chart.legend.include_in_layout = False

        if "position" in legend_theme:
            position_map = {
                "BOTTOM": XL_LEGEND_POSITION.BOTTOM,
                "RIGHT": XL_LEGEND_POSITION.RIGHT,
                "LEFT": XL_LEGEND_POSITION.LEFT,
                "TOP": XL_LEGEND_POSITION.TOP,
            }

            chart.legend.position = position_map.get(legend_theme["position"], XL_LEGEND_POSITION.BOTTOM)

        if "font_size" in legend_theme:
            chart.legend.font.size = Pt(legend_theme["font_size"])

    def _turn_gridlines_off(self, chart):
        chart.value_axis.has_major_gridlines = False

    def _category_tick_label_low(self, chart):
        chart.category_axis.tick_label_position = XL_TICK_LABEL_POSITION.LOW

    def _apply_axis_style(self, chart, chart_theme, block, value_axis_override):
        spec = block.chart
        axis = chart.value_axis

        if spec.value_axis_range or value_axis_override:
            value_axis_range = spec.value_axis_range
            value_axis_range = value_axis_override if value_axis_override else value_axis_range
            axis_min = value_axis_range[0]
            axis_max = value_axis_range[1]
            axis.minimum_scale = axis_min
            axis.maximum_scale = axis_max

            chart.value_axis_major_unit = (axis_max - axis_min) / 4

        if spec.value_axis_tick_format:
            chart.value_axis.tick_labels.number_format = spec.value_axis_tick_format

    def _set_data_labels(self, chart, chart_theme, block):
        data_labels_theme = chart_theme.get("data_labels", {})

        spec = block.chart
        if block.chart.show_data_labels:
            position_map = {
                "OUTSIDE_END": XL_DATA_LABEL_POSITION.OUTSIDE_END,
            }

            for s in chart.series:
                s.data_labels.show_value = True
                s.data_labels.font.size = Pt(data_labels_theme["font_size"])
                s.data_labels.font.bold = data_labels_theme["bold"]
                s.data_labels.font.italic = data_labels_theme["italic"]
                s.data_labels.font.underline = data_labels_theme["underline"]
                s.data_labels.position = position_map[data_labels_theme["position"]]
                if spec.value_axis_tick_format:
                    s.data_labels.number_format = spec.value_axis_tick_format

    def _set_series_colors(self, chart, chart_theme, block):
        spec = block.chart

        for i, s in enumerate(chart.series):
            color = resolve_series_color(
                spec.series[i],
                i,
                chart_theme,
            )

            if hasattr(s, "invert_if_negative"):
                s.invert_if_negative = False

            s.format.fill.solid()
            s.format.fill.fore_color.rgb = hex_to_rgb255(color)
            s.format.line.fill.solid()
            s.format.line.color.rgb = hex_to_rgb255(color)

            if chart.chart_type == self._map_chart_type("scatter"):
                s.marker.style = 8  # automatic / circle depending on PPT

                s.marker.format.fill.solid()
                s.marker.format.fill.fore_color.rgb = hex_to_rgb255(color)

                s.marker.format.line.color.rgb = hex_to_rgb255(color)

    def _set_series_dashes(self, chart, chart_theme, block):
        spec = block.chart

        if spec.chart_type == "line":
            for i, s in enumerate(chart.series):
                dash = resolve_series_dash(spec.series[i], chart_theme)
                s.format.line.dash_style = PPTX_DASH_MAP[dash]

    def _set_series_line_width(self, chart, chart_theme, block):
        spec = block.chart

        if spec.chart_type == "line":
            for i, s in enumerate(chart.series):
                s.format.line.width = Pt(resolve_series_width(spec.series[i], chart_theme))
