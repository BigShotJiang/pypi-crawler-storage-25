from pptx.util import Inches, Pt

from deckbridge.renderers.common.style_resolver import resolve_text_style
from deckbridge.renderers.gslides.utils import GSLIDES_ALIGN_MAP, GSLIDES_VERTICAL_ALIGN_MAP, hex_to_slides_rgb, inches_to_emu
from deckbridge.renderers.pptx.utils import PPTX_ALIGN_MAP, PPTX_VERTICAL_ALIGN_MAP, hex_to_rgb255
from deckbridge.themes.default import THEME


def resolve_text_content(slide, slot_key, slot):
    content_type = slot.get("content_type")

    if content_type == "chart_title":
        block = slide["content"].get(slot["source"])
        if not block:
            return None, None

        style_overrides = block.style_overrides

        title = block.chart_title
        subtitle = getattr(block, "chart_subtitle", None)

        lines = []

        if title:
            lines.append(
                {
                    "text": title + ("\n" if subtitle else ""),
                    "style_key": "chart_title",
                }
            )

        if subtitle:
            lines.append(
                {
                    "text": subtitle,
                    "style_key": "chart_subtitle",
                }
            )

        return (lines, style_overrides) if lines else (None, None)

    return slide.get(slot_key), None


def render_text_slot(ctx, slot, text, slot_key, style_overrides):
    if not text:
        return

    if ctx.backend == "pptx":
        _render_text_pptx(ctx, slot, text, slot_key, style_overrides)

    elif ctx.backend == "gslides":
        _render_text_gslides(ctx, slot, text, slot_key, style_overrides)

    else:
        raise ValueError(f"Unsupported backend: {ctx.backend}")


def _render_text_pptx(ctx, slot, text, slot_key, style_overrides):
    textbox = ctx.slide_obj.shapes.add_textbox(
        Inches(slot["x"]),
        Inches(slot["y"]),
        Inches(slot["w"]),
        Inches(slot["h"]),
    )

    tf = textbox.text_frame
    tf.clear()

    base_style = resolve_text_style(slot_key, slot, ctx.theme, ctx.layout_spec.name, style_overrides)
    tf.vertical_anchor = PPTX_VERTICAL_ALIGN_MAP[base_style.get("vertical_align", "TOP")]

    p = tf.paragraphs[0]

    lines = text if isinstance(text, list) else [{"text": text, "style_key": slot_key}]

    for line in lines:
        run = p.add_run()
        run.text = line["text"]

        style = resolve_text_style(line["style_key"], {"style_key": line["style_key"]}, ctx.theme, ctx.layout_spec.name, style_overrides)

        run.font.size = Pt(style["font_size"])
        run.font.bold = style["bold"]
        run.font.italic = style["italic"]
        run.font.underline = style["underline"]
        run.font.color.rgb = hex_to_rgb255(style["font_color"])

    # alignment applies at paragraph level
    p.alignment = PPTX_ALIGN_MAP[base_style["align"]]


def _render_text_gslides(ctx, slot, text, slot_key, style_overrides):
    object_id = f"{slot_key}_{ctx.page_id}"

    requests = []

    lines = text if isinstance(text, list) else [{"text": text, "style_key": slot_key}]

    # -----------------------
    # Build full text + ranges
    # -----------------------
    full_text = ""
    ranges = []

    cursor = 0

    for line in lines:
        line_text = line["text"]
        start = cursor
        end = cursor + len(line_text)

        ranges.append((start, end, line["style_key"]))
        full_text += line_text
        cursor = end

    # -----------------------
    # Create box
    # -----------------------
    requests.append(
        {
            "createShape": {
                "objectId": object_id,
                "shapeType": "TEXT_BOX",
                "elementProperties": {
                    "pageObjectId": ctx.page_id,
                    "size": {
                        "height": {"magnitude": inches_to_emu(slot["h"]), "unit": "EMU"},
                        "width": {"magnitude": inches_to_emu(slot["w"]), "unit": "EMU"},
                    },
                    "transform": {
                        "scaleX": 1,
                        "scaleY": 1,
                        "translateX": inches_to_emu(slot["x"]),
                        "translateY": inches_to_emu(slot["y"]),
                        "unit": "EMU",
                    },
                },
            }
        }
    )

    # -----------------------
    # Insert full text
    # -----------------------
    requests.append(
        {
            "insertText": {
                "objectId": object_id,
                "text": full_text,
            }
        }
    )

    # -----------------------
    # Apply styles per range
    # -----------------------
    for start, end, style_key in ranges:
        style = resolve_text_style(style_key, {"style_key": style_key}, ctx.theme, ctx.layout_spec.name, style_overrides)

        api_style = {
            "fontSize": {"magnitude": style["font_size"], "unit": "PT"},
            "foregroundColor": {"opaqueColor": {"rgbColor": hex_to_slides_rgb(style["font_color"])}},
            "bold": style["bold"],
            "italic": style["italic"],
            "underline": style["underline"],
        }

        requests.append(
            {
                "updateTextStyle": {
                    "objectId": object_id,
                    "textRange": {
                        "type": "FIXED_RANGE",
                        "startIndex": start,
                        "endIndex": end,
                    },
                    "style": api_style,
                    "fields": ",".join(api_style.keys()),
                }
            }
        )

    # -----------------------
    # Alignment (whole paragraph)
    # -----------------------
    base_style = resolve_text_style(slot_key, slot, ctx.theme, ctx.layout_spec.name, style_overrides)

    requests.append(
        {
            "updateParagraphStyle": {
                "objectId": object_id,
                "textRange": {"type": "ALL"},
                "style": {"alignment": GSLIDES_ALIGN_MAP[base_style["align"]]},
                "fields": "alignment",
            }
        }
    )

    vertical_align = base_style.get("vertical_align", "TOP")

    requests.append(
        {
            "updateShapeProperties": {
                "objectId": object_id,
                "shapeProperties": {
                    "contentAlignment": GSLIDES_VERTICAL_ALIGN_MAP[vertical_align],
                },
                "fields": "contentAlignment",
            }
        }
    )

    ctx.add_create_text_requests(requests)
