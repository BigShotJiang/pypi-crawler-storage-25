from deckbridge.renderers.common.axis_resolver import resolve_shared_axis_ranges
from deckbridge.renderers.common.legend_renderer import render_color_legend, render_dash_legend
from deckbridge.renderers.common.text_renderer import render_text_slot, resolve_text_content


def render_slots(ctx, slide):
    slots = ctx.layout_spec.slots

    for slot_key, slot in slots.items():
        slot_type = slot.get("type")

        # -----------------------
        # Resolve content
        # -----------------------
        if slot_type == "chart":
            block = slide["content"].get(slot_key)
            _render_chart(ctx, slot, block, slot_key, slide)

        elif slot_type == "text":
            text, style_overrides = resolve_text_content(slide, slot_key, slot)
            _render_text(ctx, slot, text, slot_key, style_overrides)

        elif slot_type == "color_legend":
            render_color_legend(ctx, slot_key, slot, slide)

        elif slot_type == "dash_legend":
            render_dash_legend(ctx, slot_key, slot, slide)


def _render_chart(ctx, slot, block, slot_key, slide):
    if not block:
        return

    shared_axis = resolve_shared_axis_ranges(slide)
    ctx.chart_compiler.compile(ctx, slot, block, slot_key, shared_axis)


def _render_text(ctx, slot, text, slot_key, style_overrides=None):
    render_text_slot(ctx, slot, text, slot_key, style_overrides)
