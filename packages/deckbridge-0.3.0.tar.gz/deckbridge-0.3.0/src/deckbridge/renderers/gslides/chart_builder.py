from deckbridge.renderers.common.style_resolver import resolve_series_color, resolve_series_dash, resolve_series_width
from deckbridge.renderers.gslides.utils import GSHEETS_CHART_DASH_MAP, GSLIDES_ALIGN_MAP

from ...deck.blocks import ChartBlock
from ...deck.specs import ChartSpec
from .utils import GSHEETS_CHART_STACKING_MAP, GSHEETS_CHART_TYPE_MAP, hex_to_slides_rgb, inches_to_pixels


class SheetsChartBuilder:
    def __init__(self, sheets_service, spreadsheet_id):
        self.sheets = sheets_service
        self.spreadsheet_id = spreadsheet_id

    def create_chart(self, chart_id, sheet_id, spec: ChartSpec, block: ChartBlock, position: dict):

        requests = [
            {
                "addChart": {
                    "chart": {
                        "chartId": chart_id,
                        "spec": self._build_chart_spec(sheet_id, spec, block),
                        "position": {
                            "overlayPosition": {
                                "anchorCell": {
                                    "sheetId": sheet_id,
                                    "rowIndex": 1,
                                    "columnIndex": 5,
                                },
                                "offsetXPixels": 0,
                                "offsetYPixels": 0,
                                "widthPixels": inches_to_pixels(position["w"]),
                                "heightPixels": inches_to_pixels(position["h"]),
                            }
                        },
                    }
                }
            }
        ]

        return requests

    def apply_chart_style(self, sheet_id, chart_id, block: ChartBlock, chart_theme: dict, value_axis_override):

        # chart title
        api_spec = self._build_chart_spec(sheet_id, block.chart, block)
        if chart_theme["chart_title"]["has_title"]:
            api_spec["title"] = block.chart_title
            api_spec["titleTextFormat"] = {
                "fontSize": chart_theme["chart_title"]["font_size"],
                "bold": chart_theme["chart_title"]["bold"],
                "italic": chart_theme["chart_title"]["italic"],
            }
            api_spec["titleTextPosition"] = {"horizontalAlignment": GSLIDES_ALIGN_MAP[chart_theme["chart_title"]["align"]]}

            if chart_theme["chart_subtitle"]["has_title"]:
                api_spec["subtitle"] = block.chart_subtitle
                api_spec["subtitleTextFormat"] = {
                    "fontSize": chart_theme["chart_subtitle"]["font_size"],
                    "bold": chart_theme["chart_subtitle"]["bold"],
                    "italic": chart_theme["chart_subtitle"]["italic"],
                }
                api_spec["subtitleTextPosition"] = {"horizontalAlignment": GSLIDES_ALIGN_MAP[chart_theme["chart_subtitle"]["align"]]}

        # axes
        value_axis_theme = chart_theme.get("value_axis", {})
        category_axis_theme = chart_theme.get("category_axis", {})

        value_axis = {
            "title": block.value_axis_title,
            "position": "LEFT_AXIS",
            "format": {
                "fontSize": value_axis_theme["font_size"],
                "bold": value_axis_theme["bold"],
                "italic": value_axis_theme["italic"],
            },
        }
        if block.chart.value_axis_range or value_axis_override:
            value_axis_range = block.chart.value_axis_range
            value_axis_range = value_axis_override if value_axis_override else value_axis_range
            if value_axis_range is not None:
                value_axis["viewWindowOptions"] = {
                    "viewWindowMin": value_axis_range[0],
                    "viewWindowMax": value_axis_range[1],
                }
        category_axis = {
            "title": block.category_axis_title,
            "position": "BOTTOM_AXIS",
            "format": {
                "fontSize": category_axis_theme["font_size"],
                "bold": category_axis_theme["bold"],
                "italic": category_axis_theme["italic"],
            },
        }
        api_spec["basicChart"]["axis"] = [
            value_axis,
            category_axis,
        ]

        # legend
        legend_theme = chart_theme.get("legend", {})
        if not legend_theme["visible"]:
            api_spec["basicChart"]["legendPosition"] = "NO_LEGEND"
        else:
            api_spec["basicChart"]["legendPosition"] = legend_theme["position"] + "_LEGEND"

        # data labels
        if block.chart.show_data_labels:
            data_labels_theme = chart_theme.get("data_labels", {})
            for i, s in enumerate(block.chart.series):
                api_spec["basicChart"]["series"][i]["dataLabel"] = {
                    "type": "DATA",
                    "placement": data_labels_theme["position"],
                    "textFormat": {
                        "fontSize": data_labels_theme["font_size"],
                        "bold": data_labels_theme["bold"],
                        "italic": data_labels_theme["italic"],
                    },
                }

        # series colors, dashes
        for i, s in enumerate(block.chart.series):
            color = resolve_series_color(block.chart.series[i], i, chart_theme)
            api_spec["basicChart"]["series"][i]["color"] = hex_to_slides_rgb(color)
            if block.chart.chart_type == "line":
                api_spec["basicChart"]["series"][i]["lineStyle"] = {
                    "type": GSHEETS_CHART_DASH_MAP[resolve_series_dash(block.chart.series[i], chart_theme)],
                    "width": resolve_series_width(block.chart.series[i], chart_theme),
                }

        requests = [
            {
                "updateChartSpec": {
                    "chartId": chart_id,
                    "spec": api_spec,
                }
            }
        ]

        return requests

    def _build_chart_spec(self, sheet_id, spec: ChartSpec, block: ChartBlock):

        series = []

        for i, s in enumerate(spec.series):
            series.append(
                {
                    "series": {
                        "sourceRange": {
                            "sources": [
                                {
                                    "sheetId": sheet_id,
                                    "startRowIndex": 0,
                                    "endRowIndex": len(spec.data) + 1,
                                    "startColumnIndex": i + 1,  # assuming x is col 0
                                    "endColumnIndex": i + 2,
                                }
                            ]
                        }
                    },
                    "targetAxis": "BOTTOM_AXIS" if spec.chart_type == "bar_stacked" else "LEFT_AXIS",
                }
            )

        api_spec = {
            "title": None,
            "basicChart": {
                "chartType": GSHEETS_CHART_TYPE_MAP[spec.chart_type],
                "legendPosition": "BOTTOM_LEGEND",
                "headerCount": 1,
                "axis": [
                    {
                        "position": "BOTTOM_AXIS",
                        "title": block.category_axis_title,
                    },
                    {
                        "position": "LEFT_AXIS",
                        "title": block.value_axis_title,
                    },
                ],
                "domains": [
                    {
                        "domain": {
                            "sourceRange": {
                                "sources": [
                                    {
                                        "sheetId": sheet_id,
                                        "startRowIndex": 0,
                                        "endRowIndex": len(spec.data) + 1,
                                        "startColumnIndex": 0,
                                        "endColumnIndex": 1,
                                    }
                                ]
                            }
                        }
                    }
                ],
                "series": series,
            },
        }
        if GSHEETS_CHART_STACKING_MAP[spec.chart_type] != "NOT_STACKED":
            api_spec["basicChart"]["stackedType"] = GSHEETS_CHART_STACKING_MAP[spec.chart_type]

        return api_spec
