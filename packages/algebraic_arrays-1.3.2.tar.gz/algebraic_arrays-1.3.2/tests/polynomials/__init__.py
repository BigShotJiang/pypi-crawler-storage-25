"""Tests for polynomial implementations."""
