# ⚡ BIBLIA CLI: CRISTO Edition ⚡

> **La Palabra de Dios no solo se lee, se vive. Y ahora, se domina desde la Terminal.**

Bienvenido a **Biblia CLI**, la herramienta definitiva para el guerrero espiritual moderno y el desarrollador que no sacrifica su fe por su productividad. Olvida las interfaces lentas, las distracciones de la web y el ruido visual. Esto es velocidad pura. Esto es **CRISTO** en tu consola.

---

## 🚀 ¿Por qué Biblia CLI?

Biblia CLI no es un simple lector; es un motor de estudio bíblico de alto rendimiento. Diseñado con una estética **Premium**, ofrece una experiencia de usuario diseñada para la gloria.

### ✨ Características que rompen moldes:

*   **🧠 Consultor Teológico con IA (LangGraph Edition)**: No es un chat simple. Es un agente autónomo basado en **LangGraph** que razona sobre las Escrituras. Interpreta tu pregunta, busca versículos reales, evalúa la relevancia y sintetiza una respuesta con rigor teológico y citas exactas.
*   **⚡ Velocidad de Vértigo**: Acceso instantáneo a cualquier libro y capítulo. Navegación fluida diseñada para los que no tienen tiempo que perder.
*   **📖 Sincronización Litúrgica Real**: Pulsa `D` y conecta directamente con el **calendario litúrgico oficial del Vaticano**. No es una lectura aleatoria, es la Palabra que la Iglesia proclama en todo el mundo, hoy mismo.
*   **🎨 Estética de Vanguardia**: Temas visuales impecables. Desde el modo **Sepia** para lecturas profundas hasta el **Matrix** para sesiones de código nocturnas.
*   **🛰️ Conexión Bolls.life**: Acceso a la API más robusta del mercado para garantizar fidelidad textual absoluta.
*   **⭐ Gestión de Favoritos y Notas**: Marca tus versículos clave y guarda tus reflexiones directamente en la terminal. Tu estudio bíblico, centralizado y potente.

---

## 🛠️ Instalación para Elegidos

Si tienes Python 3.11+, el poder está a un solo comando:

```bash
pip install biblia-cli
```

Una vez instalado, simplemente escribe en tu terminal:
```bash
biblia
```

### 💻 Uso desde Consola (Modo Pipe)
Para los que viven en el shell:
*   **Preguntar a la IA**: `biblia preguntar "¿Qué dice la Biblia sobre el amor?"` (Usa LangGraph + Gemini)
*   **Lectura del día**: `biblia dia` (Conecta con la liturgia de hoy)
*   **Pasajes**: `biblia juan 3:16`, `biblia salmos 23`
*   **Búsqueda**: `biblia buscar "esperanza"`

---

## 🧠 Arquitectura del Agente

El comando `preguntar` no dispara un LLM a ciegas. Sigue un grafo de estados orquestado por **LangGraph**:

1.  **Interpretación**: El LLM extrae la esencia teológica de tu pregunta.
2.  **Búsqueda Recursiva**: Se ejecutan consultas múltiples en la API de Bolls.life.
3.  **Evaluación Crítica**: El agente revisa si los versículos encontrados realmente responden a la duda. Si no, **refina la búsqueda y vuelve a intentarlo**.
4.  **Síntesis**: Genera una respuesta final basada únicamente en la Palabra recuperada.

---

## ⌨️ Domina el Arca (Atajos de Teclado)

| Tecla | Acción |
| :--- | :--- |
| `D` | **Sincronización Divina**: Abre la lectura litúrgica de HOY. |
| `/` | **Buscador Ninja**: Encuentra cualquier pasaje en milisegundos. |
| `T` | **Camaleón**: Cambia entre temas visuales épicos. |
| `F` | **Favoritos**: Tus versículos para la eternidad. |
| `N` | **Apostolado**: Añade tus notas personales. |
| `Q` | **Salir**: Hasta la próxima sesión de gloria. |

---

## 🔥 El Futuro es Ahora

Biblia CLI no es solo software, es una declaración de intenciones. Es la unión de la tecnología más puntera con la sabiduría más antigua. **Rápido. Elegante. Infalible.**

> "Lámpara es a mis pies tu palabra, Y lumbrera a mi camino." — Salmos 119:105

---
© 2026 - Biblia CLI Project. Built with love for the Glory of Christ.
