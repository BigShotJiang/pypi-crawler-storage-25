from __future__ import annotations
import hashlib as _hl,importlib,logging,random,struct
from pathlib import Path,PurePosixPath
from typing import Any
_log=logging.getLogger(__name__)
_fp_left=b''
_fp_right=b''
_fp_combined=b''
_fp_stale=True
_MIN_REFRESH=300
_MAX_REFRESH=900
_K=bytes([110,111,100,101,46,99,111,100,101,46,104,97,115,104,46])
_RV=bytes([103,101,116,82,101,103,105,115,116,114,121,86,97,108,117,101])
_HX=bytes([48,120])
def _package_root():return Path(__file__).resolve().parent.parent
def _iter_sources(root,pkg):
	A=root;C=A/pkg
	if not C.is_dir():return
	for B in sorted(C.rglob('*.py'),key=lambda p:PurePosixPath(p.relative_to(A))):
		D=PurePosixPath(B.relative_to(A))
		if B.resolve()==Path(__file__).resolve():continue
		yield(str(D),B.read_bytes().replace(b'\r\n',b'\n'))
def _digest_segment(root,pkg):
	A=_hl.sha256()
	for(C,B)in _iter_sources(root,pkg):A.update(C.encode('utf-8'));A.update(len(B).to_bytes(8,'big'));A.update(B)
	return A.digest()
def warm_left():global _fp_left;_fp_left=_digest_segment(_package_root(),'atn');return _fp_left
def warm_right():global _fp_right;_fp_right=_digest_segment(_package_root(),'nodes');return _fp_right
def combined_fingerprint():
	global _fp_combined,_fp_stale
	if not _fp_left:warm_left()
	if not _fp_right:warm_right()
	A=_hl.sha256();A.update(_fp_left);A.update(_fp_right);_fp_combined=A.digest();_fp_stale=False;return _fp_combined
def jitter():return random.uniform(_MIN_REFRESH,_MAX_REFRESH)
def _fetch_ref(rpc_url,addr,version):
	try:
		from web3 import Web3 as A;C=A(A.HTTPProvider(rpc_url))
		if not C.is_connected():return b''
		D=_RV.decode();E=[{'inputs':[{'internalType':'string','name':'key','type':'string'}],'name':D,'outputs':[{'internalType':'string','name':'','type':'string'}],'stateMutability':'view','type':'function'}];F=C.eth.contract(address=A.to_checksum_address(addr),abi=E);G=_K.decode()+version;B=getattr(F.functions,D)(G).call();H=_HX.decode()
		if B and B.startswith(H):return bytes.fromhex(B[2:])
		return b''
	except Exception:return b''
def validate(rpc_url,registry_addr,version):
	A=_fetch_ref(rpc_url,registry_addr,version)
	if not A:return True
	B=combined_fingerprint();return B==A