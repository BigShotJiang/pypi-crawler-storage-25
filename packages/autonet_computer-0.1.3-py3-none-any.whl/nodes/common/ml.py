"""
Machine Learning Module for Autonet

Implements real PyTorch training for federated learning with:
- SimpleNet: Small CNN for MNIST (2 conv + 2 fc layers)
- CUDA acceleration when available
- Weight delta computation for FedAvg aggregation
- Blob store integration for model storage
"""

import logging
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import datasets, transforms
from typing import Dict, Any, Optional, Tuple
import io
import json
import time

logger = logging.getLogger(__name__)


class SimpleNet(nn.Module):
    """
    Small CNN for MNIST classification.

    Architecture:
    - Conv2d(1, 16, 3x3) + ReLU + MaxPool2d(2x2)
    - Conv2d(16, 32, 3x3) + ReLU + MaxPool2d(2x2)
    - Flatten
    - Linear(32*5*5, 64) + ReLU
    - Linear(64, 10)

    Total parameters: ~11K
    """

    def __init__(self):
        super(SimpleNet, self).__init__()
        # Convolutional layers
        self.conv1 = nn.Conv2d(1, 16, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, padding=1)

        # Fully connected layers
        # After 2 MaxPool2d(2x2): 28x28 -> 14x14 -> 7x7
        # But with padding, it's 28x28 -> 14x14 -> 7x7
        # However, let's calculate: 28->14->7, but conv keeps same size
        # Actually: (28+2*1-3+1)/1+1 = 28, pool -> 14, conv -> 14, pool -> 7
        # Wait: conv(28, pad=1, k=3) = 28, pool(28, k=2) = 14
        #       conv(14, pad=1, k=3) = 14, pool(14, k=2) = 7
        # So: 32 * 7 * 7 = 1568
        self.fc1 = nn.Linear(32 * 7 * 7, 64)
        self.fc2 = nn.Linear(64, 10)

    def forward(self, x):
        # Conv block 1
        x = F.relu(self.conv1(x))
        x = F.max_pool2d(x, 2)

        # Conv block 2
        x = F.relu(self.conv2(x))
        x = F.max_pool2d(x, 2)

        # Flatten
        x = x.view(-1, 32 * 7 * 7)

        # FC layers
        x = F.relu(self.fc1(x))
        x = self.fc2(x)

        return F.log_softmax(x, dim=1)


def get_device() -> torch.device:
    """Get the best available device (CUDA > CPU)."""
    if torch.cuda.is_available():
        device = torch.device("cuda")
        logger.info(f"Using CUDA device: {torch.cuda.get_device_name(0)}")
    else:
        device = torch.device("cpu")
        logger.info("Using CPU device")
    return device


def count_parameters(model: nn.Module) -> int:
    """Count the number of trainable parameters in a model."""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def get_mnist_data(
    train: bool = True,
    data_dir: str = "./data",
    batch_size: int = 32,
    num_samples: Optional[int] = None,
) -> torch.utils.data.DataLoader:
    """
    Load MNIST dataset with standard transformations.

    Args:
        train: Whether to load training or test data
        data_dir: Directory to store/load MNIST data
        batch_size: Batch size for DataLoader
        num_samples: Limit to first N samples (for fast demo training)

    Returns:
        DataLoader for MNIST data
    """
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))  # MNIST mean and std
    ])

    dataset = datasets.MNIST(
        data_dir,
        train=train,
        download=True,
        transform=transform
    )

    # Limit dataset size for faster training
    if num_samples is not None:
        dataset = torch.utils.data.Subset(dataset, range(min(num_samples, len(dataset))))

    dataloader = torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=train,
        num_workers=0,  # Windows compatibility
    )

    return dataloader


def train_on_task(
    task_spec: Dict[str, Any],
    ground_truth: Optional[Dict[str, Any]] = None,
    global_model_cid: Optional[str] = None,
    store = None,
    epochs: int = 1,
    batch_size: int = 32,
    learning_rate: float = 0.01,
    num_samples: int = 500,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Train a model on a task and return weight delta for FedAvg.

    This performs real federated learning:
    1. Load global model (or initialize fresh)
    2. Train on local data subset
    3. Compute weight delta (new_weights - old_weights)
    4. Return delta for aggregation

    Args:
        task_spec: Task specification (contains training config)
        ground_truth: Ground truth data (optional, for verification)
        global_model_cid: CID of global model weights (None = fresh model)
        store: BlobStore for loading/saving weights
        epochs: Number of training epochs (keep low for speed)
        batch_size: Training batch size
        learning_rate: Learning rate for SGD
        num_samples: Number of samples to train on (subset of MNIST)

    Returns:
        (weight_delta_dict, metrics_dict)
    """
    device = get_device()
    start_time = time.time()

    # Initialize model
    model = SimpleNet().to(device)
    num_params = count_parameters(model)
    logger.info(f"Model initialized with {num_params:,} parameters")

    # Load global model weights if available
    initial_state_dict = None
    if global_model_cid and store:
        try:
            initial_state_dict = load_weights(global_model_cid, store)
            if initial_state_dict:
                model.load_state_dict(initial_state_dict)
                logger.info(f"Loaded global model from {global_model_cid}")
        except Exception as e:
            logger.warning(f"Could not load global model: {e}")

    # Save initial weights for delta computation (on same device as model)
    if initial_state_dict is None:
        initial_state_dict = {k: v.clone() for k, v in model.state_dict().items()}
    else:
        # Ensure initial weights are on the same device as the model
        initial_state_dict = {k: v.to(device) for k, v in initial_state_dict.items()}

    # Get training data (subset of MNIST for fast training)
    try:
        train_loader = get_mnist_data(
            train=True,
            batch_size=batch_size,
            num_samples=num_samples
        )
        logger.info(f"Loaded {len(train_loader.dataset)} training samples")
    except Exception as e:
        logger.error(f"Failed to load MNIST data: {e}")
        # Return mock result on failure
        return _mock_training_result(task_spec)

    # Train model
    optimizer = optim.SGD(model.parameters(), lr=learning_rate, momentum=0.9)
    criterion = nn.NLLLoss()

    model.train()
    total_loss = 0.0
    correct = 0
    total = 0

    for epoch in range(epochs):
        epoch_loss = 0.0
        epoch_correct = 0
        epoch_total = 0

        for batch_idx, (data, target) in enumerate(train_loader):
            data, target = data.to(device), target.to(device)

            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()
            pred = output.argmax(dim=1, keepdim=True)
            epoch_correct += pred.eq(target.view_as(pred)).sum().item()
            epoch_total += target.size(0)

        epoch_accuracy = epoch_correct / epoch_total
        epoch_avg_loss = epoch_loss / len(train_loader)
        total_loss += epoch_avg_loss
        correct += epoch_correct
        total += epoch_total

        logger.info(f"Epoch {epoch+1}/{epochs}: Loss={epoch_avg_loss:.4f}, Accuracy={epoch_accuracy:.4f}")

    training_time = time.time() - start_time

    # Compute weight delta (for FedAvg)
    final_state_dict = model.state_dict()
    weight_delta = {}
    for key in final_state_dict:
        weight_delta[key] = (final_state_dict[key] - initial_state_dict[key]).cpu().numpy().tolist()

    # Compute metrics
    metrics = {
        "loss": total_loss / epochs,
        "accuracy": correct / total,
        "training_time": training_time,
        "epochs": epochs,
        "num_samples": len(train_loader.dataset),
        "num_parameters": num_params,
        "device": str(device),
    }

    logger.info(f"Training completed in {training_time:.2f}s: Loss={metrics['loss']:.4f}, Accuracy={metrics['accuracy']:.4f}")

    return weight_delta, metrics


def _mock_training_result(task_spec: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Fallback mock training result if real training fails."""
    task_id = task_spec.get("task_id", 0)
    return {
        "task_id": task_id,
        "model_weights": f"mock_weights_task_{task_id}",
    }, {
        "loss": 0.15,
        "accuracy": 0.92,
        "training_time": 0.1,
        "epochs": 1,
        "num_samples": 500,
        "mock": True,
    }


def load_weights_into_model(model: torch.nn.Module, weights_data: dict) -> torch.nn.Module:
    """
    Load serialized weights into a PyTorch model for inference.

    Args:
        model: An uninitialized model instance (e.g., SimpleNet())
        weights_data: Dict from blob store containing "weights" key
                      with {layer_name: list_of_values} format

    Returns:
        The model with loaded weights, set to eval mode
    """
    weights = weights_data.get("weights", weights_data.get("weight_delta", {}))
    state_dict = {}
    for key, values in weights.items():
        state_dict[key] = torch.tensor(values)
    model.load_state_dict(state_dict)
    model.eval()
    logger.info(f"Loaded weights into model ({len(state_dict)} layers)")
    return model


def save_weights(state_dict: Dict[str, torch.Tensor], store) -> Optional[str]:
    """
    Save model weights to blob store.

    Args:
        state_dict: PyTorch state_dict (model weights)
        store: BlobStore instance

    Returns:
        Content hash of saved weights, or None on failure
    """
    try:
        # Convert tensors to lists for JSON serialization
        serializable_dict = {}
        for key, tensor in state_dict.items():
            serializable_dict[key] = tensor.cpu().numpy().tolist()

        # Save to blob store
        cid = store.add_json({
            "weights": serializable_dict,
            "format": "pytorch_state_dict",
        })

        logger.info(f"Saved weights to blob store: {cid}")
        return cid

    except Exception as e:
        logger.error(f"Failed to save weights: {e}")
        return None


def load_weights(cid: str, store) -> Optional[Dict[str, torch.Tensor]]:
    """
    Load model weights from blob store.

    Args:
        cid: Content hash of weights
        store: BlobStore instance

    Returns:
        PyTorch state_dict, or None on failure
    """
    try:
        # Load from blob store
        data = store.get_json(cid)
        if not data:
            logger.error(f"Failed to load weights from blob store: {cid}")
            return None

        # Convert lists back to tensors
        state_dict = {}
        weights = data.get("weights", {})
        for key, value in weights.items():
            state_dict[key] = torch.tensor(value)

        logger.info(f"Loaded weights from blob store: {cid}")
        return state_dict

    except Exception as e:
        logger.error(f"Failed to load weights: {e}")
        return None


# =============================================================================
# JEPA Self-Supervised Training
# =============================================================================

def train_jepa_on_task(
    task_spec: Dict[str, Any],
    global_model_cid: Optional[str] = None,
    store = None,
    epochs: int = 1,
    batch_size: int = 32,
    learning_rate: float = 0.001,
    num_samples: int = 500,
    image_size: int = 32,  # Smaller for CIFAR-10/MNIST
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Train a JEPA model on unlabeled images and return weight delta.

    JEPA (Joint Embedding Predictive Architecture) performs self-supervised
    learning by predicting masked patch embeddings. No labels required.

    This integrates with Autonet's Absolute Zero loop:
    - Ground truth = Target encoder embeddings on validation data
    - Verification = Embedding distance (cosine similarity)
    - Aggregation = Standard FedAvg on context encoder weights

    Args:
        task_spec: Task specification (contains JEPA config)
        global_model_cid: CID of global JEPA model to continue from
        store: BlobStore instance
        epochs: Number of training epochs
        batch_size: Batch size for training
        learning_rate: Learning rate
        num_samples: Number of samples to train on
        image_size: Image size (32 for CIFAR, 224 for ImageNet)

    Returns:
        (weight_delta, metrics) compatible with FedAvg aggregation
    """
    start_time = time.time()
    device = "cuda" if torch.cuda.is_available() else "cpu"

    try:
        from .jepa import JEPA, JEPAConfig, JEPATrainer

        # Configure JEPA for the image size
        config = JEPAConfig(
            image_size=image_size,
            patch_size=4 if image_size <= 32 else 16,  # Smaller patches for small images
            embed_dim=192 if image_size <= 32 else 384,  # Smaller model for efficiency
            num_heads=3 if image_size <= 32 else 6,
            encoder_depth=6 if image_size <= 32 else 12,
            predictor_depth=3 if image_size <= 32 else 6,
            predictor_embed_dim=96 if image_size <= 32 else 192,
        )

        # Initialize trainer
        trainer = JEPATrainer(config=config, device=device)

        # Load global model if available
        if global_model_cid and store:
            try:
                global_weights = load_weights(global_model_cid, store)
                if global_weights:
                    trainer.load_weights(global_weights)
                    logger.info(f"Loaded JEPA global model: {global_model_cid[:20]}...")
            except Exception as e:
                logger.warning(f"Failed to load global JEPA model: {e}")

        # Store initial weights for delta computation
        initial_weights = {k: v.clone() for k, v in trainer.model.state_dict().items()}

        # Load training data (use CIFAR-10 for demonstration)
        from torchvision import datasets, transforms
        transform = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,)) if image_size <= 32 else
            transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
        ])

        # Try CIFAR-10 for small images, ImageNet subset otherwise
        try:
            if image_size <= 32:
                dataset = datasets.CIFAR10(
                    root='./data', train=True, download=True, transform=transform
                )
            else:
                # For larger images, use FakeData for demo
                dataset = datasets.FakeData(
                    size=num_samples,
                    image_size=(3, image_size, image_size),
                    transform=transforms.ToTensor(),
                )
        except Exception:
            # Fallback to synthetic data
            dataset = datasets.FakeData(
                size=num_samples,
                image_size=(3, image_size, image_size),
                transform=transforms.ToTensor(),
            )

        # Subset for training
        indices = torch.randperm(len(dataset))[:num_samples]
        subset = torch.utils.data.Subset(dataset, indices.tolist())
        train_loader = torch.utils.data.DataLoader(
            subset, batch_size=batch_size, shuffle=True, num_workers=0
        )

        # Optimizer
        optimizer = torch.optim.AdamW(
            [
                {'params': trainer.model.context_encoder.parameters()},
                {'params': trainer.model.predictor.parameters()},
            ],
            lr=learning_rate,
            weight_decay=0.05,
        )

        # Training loop
        total_loss = 0.0
        total_cosine_sim = 0.0
        num_batches = 0

        for epoch in range(epochs):
            epoch_loss = 0.0
            epoch_cosine_sim = 0.0
            epoch_batches = 0

            for batch in train_loader:
                # Handle both (images, labels) and just images
                images = batch[0] if isinstance(batch, (list, tuple)) else batch
                images = images.to(device)

                # JEPA training step
                metrics = trainer.train_step(images, optimizer)

                epoch_loss += metrics['loss']
                epoch_cosine_sim += metrics['cosine_similarity']
                epoch_batches += 1

            avg_loss = epoch_loss / max(1, epoch_batches)
            avg_cosine = epoch_cosine_sim / max(1, epoch_batches)
            total_loss += avg_loss
            total_cosine_sim += avg_cosine
            num_batches += epoch_batches

            logger.info(
                f"JEPA Epoch {epoch+1}/{epochs}: "
                f"Loss={avg_loss:.4f}, Cosine Sim={avg_cosine:.4f}"
            )

        training_time = time.time() - start_time

        # Compute weight delta (for FedAvg)
        final_weights = trainer.model.state_dict()
        weight_delta = {}
        for key in final_weights:
            # Only include context encoder and predictor (not target encoder)
            if 'target_encoder' not in key:
                delta = final_weights[key] - initial_weights[key]
                weight_delta[key] = delta.cpu().numpy().tolist()

        # Compute verification metrics
        trainer.model.eval()
        with torch.no_grad():
            # Sample validation batch
            val_batch = next(iter(train_loader))
            val_images = val_batch[0] if isinstance(val_batch, (list, tuple)) else val_batch
            val_images = val_images.to(device)

            val_metrics = trainer.evaluate(val_images)

        metrics = {
            "loss": total_loss / max(1, epochs),
            "cosine_similarity": total_cosine_sim / max(1, epochs),
            "embedding_energy": val_metrics['embedding_energy'],
            "l2_distance": val_metrics['l2_distance'],
            "training_time": training_time,
            "epochs": epochs,
            "num_samples": num_samples,
            "architecture": "jepa",
            "self_supervised": True,
        }

        logger.info(
            f"JEPA training complete: Loss={metrics['loss']:.4f}, "
            f"Cosine Sim={metrics['cosine_similarity']:.4f}"
        )

        return weight_delta, metrics

    except Exception as e:
        logger.error(f"JEPA training failed: {e}")
        # Fallback to mock result
        return _mock_jepa_result(task_spec)


def _mock_jepa_result(task_spec: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Fallback mock JEPA training result."""
    task_id = task_spec.get("task_id", 0)
    return {
        "task_id": task_id,
        "model_type": "jepa",
        "mock": True,
    }, {
        "loss": 0.15,
        "cosine_similarity": 0.75,
        "embedding_energy": 0.08,
        "l2_distance": 0.05,
        "training_time": 0.1,
        "epochs": 1,
        "num_samples": 500,
        "architecture": "jepa",
        "self_supervised": True,
        "mock": True,
    }


def train_vljepa_on_task(
    task_spec: Dict[str, Any],
    global_model_cid: Optional[str] = None,
    store=None,
    text_data_source=None,
    visual_data_source=None,
    epochs: int = 1,
    learning_rate: float = 1e-3,
    modalities: Optional[list] = None,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Unified training function for text, visual, or multimodal JEPA.

    Supports three modality configurations:
    - text-only: trains TextJEPA on agent framework conversations/executions
    - visual-only: trains JEPA on screen capture / browser frames
    - multimodal: trains VL-JEPA on paired text+visual data

    Integrates with Autonet's Absolute Zero loop:
    - Weight deltas compatible with FedAvg aggregation
    - Metrics compatible with Yuma consensus verification
    - Same commit-reveal pipeline regardless of modality

    Args:
        task_spec: Task specification (may contain modality config)
        global_model_cid: CID of global model to continue from
        store: BlobStore instance
        text_data_source: TextTrainingDataSource (or iterable yielding
            {token_ids, attention_mask} dicts)
        visual_data_source: Iterable yielding image tensors (B, C, H, W)
        epochs: Number of training epochs
        learning_rate: Learning rate
        modalities: List of active modalities, e.g. ["text"], ["visual"],
            ["text", "visual"]. Auto-detected from data sources if None.

    Returns:
        (weight_delta, metrics) compatible with FedAvg aggregation
    """
    start_time = time.time()
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # Determine modalities
    if modalities is None:
        modalities = []
        if text_data_source is not None:
            modalities.append("text")
        if visual_data_source is not None:
            modalities.append("visual")
    if not modalities:
        modalities = task_spec.get("modalities", ["text"])

    has_text = "text" in modalities
    has_visual = "visual" in modalities

    try:
        # -----------------------------------------------------------
        # TEXT-ONLY: Use TextJEPA
        # -----------------------------------------------------------
        if has_text and not has_visual:
            from .text_jepa import TextJEPA, TextJEPAConfig, TextJEPATrainer

            config = TextJEPAConfig(
                vocab_size=task_spec.get("vocab_size", 260),
                max_seq_length=task_spec.get("max_seq_length", 2048),
                embed_dim=task_spec.get("embed_dim", 384),
                num_heads=task_spec.get("num_heads", 6),
                encoder_depth=task_spec.get("encoder_depth", 6),
                predictor_depth=task_spec.get("predictor_depth", 3),
                predictor_embed_dim=task_spec.get("predictor_embed_dim", 192),
            )

            trainer = TextJEPATrainer(config, device=device)

            if global_model_cid and store:
                try:
                    global_weights = load_weights(global_model_cid, store)
                    if global_weights:
                        trainer.load_weights(global_weights)
                        logger.info("Loaded global TextJEPA model: %s...", global_model_cid[:20])
                except Exception as e:
                    logger.warning("Failed to load global TextJEPA model: %s", e)

            initial_weights = {k: v.clone() for k, v in trainer.model.state_dict().items()}

            optimizer = torch.optim.AdamW(
                [
                    {"params": trainer.model.context_encoder.parameters()},
                    {"params": trainer.model.predictor.parameters()},
                ],
                lr=learning_rate,
                weight_decay=0.05,
            )

            total_loss = 0.0
            total_cosine = 0.0
            num_batches = 0

            for epoch in range(epochs):
                if hasattr(text_data_source, "reload"):
                    text_data_source.reload()

                for batch in text_data_source:
                    metrics = trainer.train_step(batch, optimizer)
                    total_loss += metrics["loss"]
                    total_cosine += metrics["cosine_similarity"]
                    num_batches += 1

                if num_batches > 0:
                    logger.info(
                        "TextJEPA Epoch %d/%d: Loss=%.4f, CosSim=%.4f",
                        epoch + 1, epochs,
                        total_loss / num_batches,
                        total_cosine / num_batches,
                    )

            training_time = time.time() - start_time

            # Weight delta (exclude target encoder)
            final_weights = trainer.model.state_dict()
            weight_delta = {}
            for key in final_weights:
                if "target_encoder" not in key:
                    delta = final_weights[key] - initial_weights[key]
                    weight_delta[key] = delta.cpu().numpy().tolist()

            # Validation metrics
            val_metrics = {}
            if num_batches > 0:
                trainer.model.eval()
                try:
                    val_batch = next(iter(text_data_source))
                    val_metrics = trainer.evaluate(val_batch)
                except StopIteration:
                    pass

            result_metrics = {
                "loss": total_loss / max(1, num_batches),
                "cosine_similarity": total_cosine / max(1, num_batches),
                "embedding_energy": val_metrics.get("embedding_energy", 0.0),
                "l2_distance": val_metrics.get("l2_distance", 0.0),
                "training_time": training_time,
                "epochs": epochs,
                "num_batches": num_batches,
                "architecture": "text_jepa",
                "modalities": ["text"],
                "self_supervised": True,
            }

            return weight_delta, result_metrics

        # -----------------------------------------------------------
        # VISUAL-ONLY: Use existing JEPA (vision)
        # -----------------------------------------------------------
        elif has_visual and not has_text:
            from .jepa import JEPA, JEPAConfig, JEPATrainer

            image_size = task_spec.get("image_size", 224)
            config = JEPAConfig(
                image_size=image_size,
                patch_size=task_spec.get("patch_size", 4 if image_size <= 32 else 16),
                embed_dim=task_spec.get("embed_dim", 192 if image_size <= 32 else 384),
                num_heads=task_spec.get("num_heads", 3 if image_size <= 32 else 6),
                encoder_depth=task_spec.get("encoder_depth", 6 if image_size <= 32 else 12),
                predictor_depth=task_spec.get("predictor_depth", 3 if image_size <= 32 else 6),
                predictor_embed_dim=task_spec.get("predictor_embed_dim", 96 if image_size <= 32 else 192),
            )

            trainer = JEPATrainer(config=config, device=device)

            if global_model_cid and store:
                try:
                    global_weights = load_weights(global_model_cid, store)
                    if global_weights:
                        trainer.load_weights(global_weights)
                        logger.info("Loaded global JEPA model: %s...", global_model_cid[:20])
                except Exception as e:
                    logger.warning("Failed to load global JEPA model: %s", e)

            initial_weights = {k: v.clone() for k, v in trainer.model.state_dict().items()}

            optimizer = torch.optim.AdamW(
                [
                    {"params": trainer.model.context_encoder.parameters()},
                    {"params": trainer.model.predictor.parameters()},
                ],
                lr=learning_rate,
                weight_decay=0.05,
            )

            total_loss = 0.0
            total_cosine = 0.0
            num_batches = 0

            for epoch in range(epochs):
                for batch in visual_data_source:
                    images = batch[0] if isinstance(batch, (list, tuple)) else batch
                    images = images.to(device)
                    metrics = trainer.train_step(images, optimizer)
                    total_loss += metrics["loss"]
                    total_cosine += metrics["cosine_similarity"]
                    num_batches += 1

                if num_batches > 0:
                    logger.info(
                        "JEPA (visual) Epoch %d/%d: Loss=%.4f, CosSim=%.4f",
                        epoch + 1, epochs,
                        total_loss / num_batches,
                        total_cosine / num_batches,
                    )

            training_time = time.time() - start_time

            final_weights = trainer.model.state_dict()
            weight_delta = {}
            for key in final_weights:
                if "target_encoder" not in key:
                    delta = final_weights[key] - initial_weights[key]
                    weight_delta[key] = delta.cpu().numpy().tolist()

            result_metrics = {
                "loss": total_loss / max(1, num_batches),
                "cosine_similarity": total_cosine / max(1, num_batches),
                "training_time": training_time,
                "epochs": epochs,
                "num_batches": num_batches,
                "architecture": "jepa",
                "modalities": ["visual"],
                "self_supervised": True,
            }

            return weight_delta, result_metrics

        # -----------------------------------------------------------
        # MULTIMODAL: Use VL-JEPA
        # -----------------------------------------------------------
        else:
            from .vl_jepa import VLJEPA, VLJEPAConfig

            image_size = task_spec.get("image_size", 224)
            config = VLJEPAConfig(
                image_size=image_size,
                patch_size=task_spec.get("patch_size", 16),
                embed_dim=task_spec.get("embed_dim", 384),
                num_heads=task_spec.get("num_heads", 6),
                encoder_depth=task_spec.get("encoder_depth", 12),
                vocab_size=task_spec.get("vocab_size", 260),
                max_seq_length=task_spec.get("max_seq_length", 512),
                text_encoder_depth=task_spec.get("text_encoder_depth", 6),
                fusion_depth=task_spec.get("fusion_depth", 6),
            )

            model = VLJEPA(config).to(device)

            if global_model_cid and store:
                try:
                    global_weights = load_weights(global_model_cid, store)
                    if global_weights:
                        state = {}
                        for key, value in global_weights.items():
                            state[key] = torch.tensor(value) if isinstance(value, list) else value
                        model.load_state_dict(state, strict=False)
                        logger.info("Loaded global VL-JEPA model: %s...", global_model_cid[:20])
                except Exception as e:
                    logger.warning("Failed to load global VL-JEPA model: %s", e)

            initial_weights = {k: v.clone() for k, v in model.state_dict().items()}

            # Optimize all trainable components (not target encoder, not decoder)
            trainable_params = [
                {"params": model.visual_encoder.parameters()},
                {"params": model.text_encoder.parameters()},
                {"params": model.cross_modal_fusion.parameters()},
                {"params": model.semantic_predictor.parameters()},
            ]
            optimizer = torch.optim.AdamW(
                trainable_params,
                lr=learning_rate,
                weight_decay=0.05,
            )

            total_loss = 0.0
            num_batches = 0

            # Interleave text and visual batches
            text_iter = iter(text_data_source) if text_data_source else iter([])
            visual_iter = iter(visual_data_source) if visual_data_source else iter([])

            for epoch in range(epochs):
                if hasattr(text_data_source, "reload") and text_data_source is not None:
                    text_data_source.reload()
                text_iter = iter(text_data_source) if text_data_source else iter([])
                visual_iter = iter(visual_data_source) if visual_data_source else iter([])

                # Train on paired batches until both exhausted
                text_done = text_data_source is None
                visual_done = visual_data_source is None

                while not (text_done and visual_done):
                    # Get text batch
                    token_ids = None
                    attention_mask = None
                    try:
                        text_batch = next(text_iter)
                        token_ids = text_batch["token_ids"].to(device)
                        attention_mask = text_batch["attention_mask"].to(device)
                    except StopIteration:
                        text_done = True

                    # Get visual batch
                    images = None
                    try:
                        vis_batch = next(visual_iter)
                        images = vis_batch[0] if isinstance(vis_batch, (list, tuple)) else vis_batch
                        images = images.to(device)
                    except StopIteration:
                        visual_done = True

                    if token_ids is None and images is None:
                        break

                    B = token_ids.shape[0] if token_ids is not None else images.shape[0]

                    # Fill in missing modality with zeros
                    if token_ids is None:
                        S = config.max_seq_length
                        token_ids = torch.zeros(B, S, dtype=torch.long, device=device)
                        attention_mask = torch.zeros(B, S, dtype=torch.bool, device=device)
                    if images is None:
                        images = torch.zeros(B, 3, image_size, image_size, device=device)

                    # Match batch sizes (take minimum)
                    min_B = min(token_ids.shape[0], images.shape[0])
                    token_ids = token_ids[:min_B]
                    attention_mask = attention_mask[:min_B]
                    images = images[:min_B]

                    # VL-JEPA self-supervised loss
                    model.train()
                    outputs = model.self_supervised_loss(images, token_ids, attention_mask)
                    loss = outputs["loss"]

                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()
                    model.update_target_encoder()

                    total_loss += loss.item()
                    num_batches += 1

                if num_batches > 0:
                    logger.info(
                        "VL-JEPA Epoch %d/%d: Loss=%.4f",
                        epoch + 1, epochs,
                        total_loss / num_batches,
                    )

            training_time = time.time() - start_time

            # Weight delta (exclude target encoder and decoder — decoder is local)
            final_weights = model.state_dict()
            weight_delta = {}
            for key in final_weights:
                if "target_encoder" not in key and "text_decoder" not in key:
                    delta = final_weights[key] - initial_weights[key]
                    weight_delta[key] = delta.cpu().numpy().tolist()

            result_metrics = {
                "loss": total_loss / max(1, num_batches),
                "training_time": training_time,
                "epochs": epochs,
                "num_batches": num_batches,
                "architecture": "vl_jepa",
                "modalities": modalities,
                "self_supervised": True,
            }

            return weight_delta, result_metrics

    except Exception as e:
        logger.error("VL-JEPA training failed: %s", e)
        return _mock_jepa_result(task_spec)


def verify_jepa_solution(
    solver_weights: Dict[str, Any],
    target_encoder_weights: Dict[str, Any],
    validation_images: torch.Tensor,
    config: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Verify a JEPA solution against the target encoder (ground truth).

    In JEPA, verification compares embeddings produced by the solver's model
    against the target encoder's embeddings. This is the Absolute Zero
    verification adapted for self-supervised learning.

    Args:
        solver_weights: Weights from the solver's trained model
        target_encoder_weights: Ground truth target encoder weights (from proposer)
        validation_images: Validation images for embedding comparison
        config: JEPA configuration

    Returns:
        Dict with verification metrics (embedding distance, cosine similarity, pass/fail)
    """
    device = "cuda" if torch.cuda.is_available() else "cpu"

    try:
        from .jepa import JEPA, JEPAConfig

        # Create config matching training function's logic
        config = config or {}
        image_size = config.get('image_size', 32)

        # Derive config parameters based on image size (matching train_jepa_on_task)
        jepa_config = JEPAConfig(
            image_size=image_size,
            patch_size=config.get('patch_size', 4 if image_size <= 32 else 16),
            embed_dim=config.get('embed_dim', 192 if image_size <= 32 else 384),
            num_heads=config.get('num_heads', 3 if image_size <= 32 else 6),
            encoder_depth=config.get('encoder_depth', 6 if image_size <= 32 else 12),
            predictor_depth=config.get('predictor_depth', 3 if image_size <= 32 else 6),
            predictor_embed_dim=config.get('predictor_embed_dim', 96 if image_size <= 32 else 192),
        )

        # Solver's model
        solver_model = JEPA(jepa_config).to(device)
        solver_state = {}
        for key, value in solver_weights.items():
            if isinstance(value, list):
                solver_state[key] = torch.tensor(value)
            else:
                solver_state[key] = value
        solver_model.load_state_dict(solver_state, strict=False)

        # Target encoder (ground truth)
        target_model = JEPA(jepa_config).to(device)
        target_state = {}
        for key, value in target_encoder_weights.items():
            if isinstance(value, list):
                target_state[key] = torch.tensor(value)
            else:
                target_state[key] = value
        target_model.target_encoder.load_state_dict(target_state, strict=False)

        # Compare embeddings on validation data
        solver_model.eval()
        target_model.eval()

        with torch.no_grad():
            validation_images = validation_images.to(device)

            # Get embeddings from both models
            solver_embeddings = solver_model.encode(validation_images)
            target_embeddings = target_model.encode(validation_images)

            # Compute similarity metrics
            cosine_sim = nn.functional.cosine_similarity(
                solver_embeddings.mean(dim=1),
                target_embeddings.mean(dim=1),
                dim=-1
            ).mean().item()

            l2_distance = nn.functional.mse_loss(
                solver_embeddings, target_embeddings
            ).item()

        # Verification thresholds (can be configured per task)
        min_cosine_sim = 0.5
        max_l2_distance = 1.0

        is_correct = cosine_sim >= min_cosine_sim and l2_distance <= max_l2_distance

        return {
            "is_correct": is_correct,
            "cosine_similarity": cosine_sim,
            "l2_distance": l2_distance,
            "score": cosine_sim * 100,  # 0-100 score
            "verification_type": "jepa_embedding",
        }

    except Exception as e:
        logger.error(f"JEPA verification failed: {e}")
        return {
            "is_correct": False,
            "error": str(e),
            "verification_type": "jepa_embedding",
        }


def aggregate_weight_deltas(
    deltas: list,
    weights: Optional[list] = None,
) -> Dict[str, torch.Tensor]:
    """
    Aggregate weight deltas using FedAvg algorithm.

    FedAvg: weighted_avg = sum(weight_i * delta_i) / sum(weights)

    Args:
        deltas: List of weight delta dicts (from train_on_task)
        weights: Optional list of weights for each delta (e.g., num_samples)
                 If None, simple average is used

    Returns:
        Aggregated weight delta dict
    """
    if not deltas:
        return {}

    # Use uniform weights if not provided
    if weights is None:
        weights = [1.0] * len(deltas)

    # Normalize weights
    total_weight = sum(weights)
    normalized_weights = [w / total_weight for w in weights]

    # Aggregate deltas
    aggregated = {}
    for key in deltas[0].keys():
        # Convert to tensors and aggregate
        tensors = [torch.tensor(delta[key]) * w for delta, w in zip(deltas, normalized_weights)]
        aggregated[key] = sum(tensors)

    logger.info(f"Aggregated {len(deltas)} weight deltas with weights {weights}")
    return aggregated


def apply_weight_delta(
    base_state_dict: Dict[str, torch.Tensor],
    delta: Dict[str, torch.Tensor],
) -> Dict[str, torch.Tensor]:
    """
    Apply weight delta to base model weights.

    Args:
        base_state_dict: Base model state_dict
        delta: Weight delta to apply

    Returns:
        Updated state_dict
    """
    updated = {}
    for key in base_state_dict:
        if key in delta:
            updated[key] = base_state_dict[key] + delta[key]
        else:
            updated[key] = base_state_dict[key]

    return updated


def evaluate_model(
    model_cid: str,
    store,
    num_samples: int = 1000,
) -> Dict[str, float]:
    """
    Test a model on MNIST test set.

    Args:
        model_cid: CID of model weights
        store: BlobStore instance
        num_samples: Number of test samples

    Returns:
        Dict with test metrics
    """
    device = get_device()

    # Load model
    model = SimpleNet().to(device)
    state_dict = load_weights(model_cid, store)
    if state_dict:
        model.load_state_dict(state_dict)
    else:
        logger.warning("Could not load model weights, testing with random weights")

    # Load test data
    test_loader = get_mnist_data(
        train=False,
        batch_size=32,
        num_samples=num_samples
    )

    # Test model
    model.eval()
    test_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss += F.nll_loss(output, target, reduction='sum').item()
            pred = output.argmax(dim=1, keepdim=True)
            correct += pred.eq(target.view_as(pred)).sum().item()
            total += target.size(0)

    test_loss /= total
    accuracy = correct / total

    metrics = {
        "test_loss": test_loss,
        "test_accuracy": accuracy,
        "num_samples": total,
    }

    logger.info(f"Test results: Loss={test_loss:.4f}, Accuracy={accuracy:.4f}")
    return metrics


if __name__ == "__main__":
    """Quick test of ML module."""
    logging.basicConfig(level=logging.INFO)

    from blob_store import BlobStore

    print("=== Testing ML Module ===")

    # Initialize blob store
    store = BlobStore()

    # Test model creation
    print("\n1. Creating SimpleNet...")
    model = SimpleNet()
    num_params = count_parameters(model)
    print(f"   Model has {num_params:,} parameters")

    # Test training
    print("\n2. Training on MNIST subset...")
    task_spec = {"task_id": 1, "epochs": 1}
    weight_delta, metrics = train_on_task(
        task_spec=task_spec,
        store=store,
        epochs=1,
        num_samples=100,  # Very small for quick test
    )
    print(f"   Training metrics: {metrics}")

    # Test saving/loading
    print("\n3. Testing blob store save/load...")
    test_model = SimpleNet()
    state_dict = test_model.state_dict()
    cid = save_weights(state_dict, store)
    print(f"   Saved to blob store: {cid}")

    loaded = load_weights(cid, store)
    if loaded:
        print(f"   Loaded successfully, {len(loaded)} keys")

    print("\n=== ML Module Test Complete ===")
