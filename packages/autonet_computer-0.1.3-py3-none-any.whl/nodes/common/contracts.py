"""
Contract Registry for Autonet Nodes

Loads contract ABIs from Hardhat artifacts and provides typed contract
accessors for all Autonet contracts. This is the bridge between Python
nodes and on-chain state.
"""

import json
import logging
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

from .blockchain import BlockchainInterface, TransactionResult

logger = logging.getLogger(__name__)

# Default path to Hardhat artifacts (relative to project root)
DEFAULT_ARTIFACTS_DIR = os.path.join(
    os.path.dirname(__file__), "..", "..", "artifacts", "contracts"
)
DEFAULT_ADDRESSES_FILE = os.path.join(
    os.path.dirname(__file__), "..", "..", "deployment-addresses.json"
)

# Contract name -> artifact path mapping
CONTRACT_ARTIFACTS = {
    "ATNToken": "tokens/ATNToken.sol/ATNToken.json",
    "ParticipantStaking": "core/ParticipantStaking.sol/ParticipantStaking.json",
    "ModelShardRegistry": "core/ModelShardRegistry.sol/ModelShardRegistry.json",
    "TaskContract": "core/TaskContract.sol/TaskContract.json",
    "ResultsRewards": "core/ResultsRewards.sol/ResultsRewards.json",
    "ForcedErrorRegistry": "core/ForcedErrorRegistry.sol/ForcedErrorRegistry.json",
    "AnchorBridge": "rollup/AnchorBridge.sol/AnchorBridge.json",
    "DisputeManager": "rollup/DisputeManager.sol/DisputeManager.json",
    "AutonetDAO": "governance/AutonetDAO.sol/AutonetDAO.json",
    "EvolutionProposal": "governance/EvolutionProposal.sol/EvolutionProposal.json",
    "RPB": "core/RPB.sol/RPB.json",
    "RPBFactory": "core/RPBFactory.sol/RPBFactory.json",
}


@dataclass
class ContractHandle:
    """A handle to a deployed contract with its ABI and address."""
    name: str
    address: str
    abi: list
    web3_contract: Any = None


class ContractRegistry:
    """
    Registry of all deployed Autonet contracts.

    Loads ABIs from Hardhat artifacts and addresses from deployment-addresses.json.
    Provides high-level methods for common contract interactions with retry logic.
    """

    def __init__(
        self,
        blockchain: BlockchainInterface,
        artifacts_dir: Optional[str] = None,
        addresses_file: Optional[str] = None,
        addresses: Optional[Dict[str, str]] = None,
    ):
        self.blockchain = blockchain
        self.artifacts_dir = artifacts_dir or DEFAULT_ARTIFACTS_DIR
        self.addresses_file = addresses_file or DEFAULT_ADDRESSES_FILE
        self.contracts: Dict[str, ContractHandle] = {}
        self._abis: Dict[str, list] = {}
        self._event_block_cursors: Dict[str, int] = {}  # per-(contract,event) block tracker

        # Load ABIs
        self._load_abis()

        # Load addresses (from dict or file)
        if addresses:
            self._register_addresses(addresses)
        else:
            self._load_addresses_from_file()

    def _load_abis(self):
        """Load all contract ABIs from Hardhat artifacts."""
        for name, rel_path in CONTRACT_ARTIFACTS.items():
            artifact_path = os.path.join(self.artifacts_dir, rel_path)
            if os.path.exists(artifact_path):
                with open(artifact_path, "r") as f:
                    artifact = json.load(f)
                    self._abis[name] = artifact["abi"]
                    logger.debug(f"Loaded ABI for {name}")
            else:
                logger.warning(f"Artifact not found for {name}: {artifact_path}")

    def _load_addresses_from_file(self):
        """Load deployed contract addresses from deployment-addresses.json."""
        if not os.path.exists(self.addresses_file):
            logger.warning(f"Addresses file not found: {self.addresses_file}")
            return

        with open(self.addresses_file, "r") as f:
            data = json.load(f)

        self._register_addresses(data)

    def _register_addresses(self, addresses: Dict[str, str]):
        """Register contract addresses from a dict."""
        for name, abi in self._abis.items():
            if name in addresses and addresses[name]:
                addr = addresses[name]
                handle = ContractHandle(name=name, address=addr, abi=abi)

                # Create web3 contract instance if connected
                if self.blockchain.web3:
                    handle.web3_contract = self.blockchain.web3.eth.contract(
                        address=self.blockchain.web3.to_checksum_address(addr),
                        abi=abi,
                    )

                self.contracts[name] = handle
                logger.info(f"Registered {name} at {addr}")

    def get(self, name: str) -> Optional[ContractHandle]:
        """Get a contract handle by name."""
        return self.contracts.get(name)

    def call(self, contract_name: str, function_name: str, *args) -> Any:
        """Call a read-only contract function."""
        handle = self.contracts.get(contract_name)
        if not handle:
            raise ValueError(f"Contract not registered: {contract_name}")

        return self.blockchain.call_contract(
            handle.address, handle.abi, function_name, *args
        )

    def send(
        self,
        contract_name: str,
        function_name: str,
        *args,
        gas_limit: int = 500000,
        retries: int = 3,
        retry_delay: float = 2.0,
    ) -> TransactionResult:
        """Send a transaction with retry logic."""
        handle = self.contracts.get(contract_name)
        if not handle:
            return TransactionResult(
                success=False, error=f"Contract not registered: {contract_name}"
            )

        for attempt in range(retries):
            result = self.blockchain.send_transaction(
                handle.address, handle.abi, function_name, *args,
                gas_limit=gas_limit,
            )
            if result.success:
                logger.info(
                    f"TX {contract_name}.{function_name} succeeded: {result.tx_hash}"
                )
                return result

            logger.warning(
                f"TX {contract_name}.{function_name} failed (attempt {attempt + 1}/{retries}): {result.error}"
            )
            if attempt < retries - 1:
                time.sleep(retry_delay * (attempt + 1))

        return result

    def get_events(
        self,
        contract_name: str,
        event_name: str,
        from_block: int = 0,
        to_block: str = "latest",
    ) -> list:
        """Get events from a contract."""
        handle = self.contracts.get(contract_name)
        if not handle:
            return []

        return self.blockchain.get_events(
            handle.address, handle.abi, event_name, from_block, to_block
        )

    def get_new_events(
        self, contract_name: str, event_name: str
    ) -> list:
        """Get events since last scan. Each (contract, event) pair has its own cursor."""
        current_block = self.blockchain.get_block_number()
        cursor_key = f"{contract_name}:{event_name}"
        last_block = self._event_block_cursors.get(cursor_key, 0)
        events = self.get_events(
            contract_name, event_name,
            from_block=last_block + 1,
            to_block=current_block,
        )
        self._event_block_cursors[cursor_key] = current_block
        return events

    # =========================================================================
    # High-level typed accessors for common operations
    # =========================================================================

    # --- Staking ---

    def stake(self, role: int, amount: int) -> TransactionResult:
        """Stake ATN for a role. Role: 1=PROPOSER, 2=SOLVER, 3=COORDINATOR, 4=AGGREGATOR, 5=VALIDATOR."""
        return self.send("ParticipantStaking", "stake", role, amount)

    def is_active_participant(self, address: str, role: int) -> bool:
        """Check if address is an active participant with the given role."""
        try:
            return self.call("ParticipantStaking", "isActiveParticipant", address, role)
        except Exception:
            return False

    def get_stake(self, address: str) -> Optional[Dict]:
        """Get stake info for an address."""
        try:
            return self.call("ParticipantStaking", "getStake", address)
        except Exception:
            return None

    # --- Tasks ---

    def propose_task(
        self,
        rpb_address: str,
        spec_hash: bytes,
        ground_truth_hash: bytes,
        learnability_reward: int,
        solver_reward: int,
    ) -> TransactionResult:
        """Propose a new task."""
        return self.send(
            "TaskContract", "proposeTask",
            rpb_address, spec_hash, ground_truth_hash,
            learnability_reward, solver_reward,
            gas_limit=800000,
        )

    def commit_solution(self, task_id: int, solution_hash: bytes, charter_cid: bytes = b'\x00' * 32) -> TransactionResult:
        """Commit a solution hash and charter CID for a task."""
        return self.send("TaskContract", "commitSolution", task_id, solution_hash, charter_cid)

    def get_submission(self, task_id: int, solver: str) -> dict:
        """Get a solver's submission for a task."""
        try:
            result = self.call("TaskContract", "getSubmission", task_id, solver)
            return {
                "solutionHash": result[0],
                "charterCid": result[1],
                "solver": result[2],
                "submissionBlock": result[3],
                "score": result[4],
            }
        except Exception:
            return {}

    def submit_checkpoint(
        self,
        task_id: int,
        step_number: int,
        weights_hash: bytes,
        data_indices_hash: bytes,
        random_seed: bytes,
    ) -> TransactionResult:
        """Submit a training checkpoint."""
        return self.send(
            "TaskContract", "submitCheckpoint",
            task_id, step_number, weights_hash, data_indices_hash, random_seed,
        )

    def get_task(self, task_id: int) -> Optional[Dict]:
        """Get task proposal data."""
        try:
            return self.call("TaskContract", "getTaskProposal", task_id)
        except Exception:
            return None

    def get_next_task_id(self) -> int:
        """Get the next task ID (to know how many tasks exist)."""
        try:
            return self.call("TaskContract", "nextTaskId")
        except Exception:
            return 0

    # --- Reveals ---

    def reveal_ground_truth(self, task_id: int, cid: str) -> TransactionResult:
        """Reveal ground truth for a task."""
        return self.send("ResultsRewards", "revealGroundTruth", task_id, cid)

    def reveal_solution(self, task_id: int, cid: str) -> TransactionResult:
        """Reveal solution for a task."""
        return self.send("ResultsRewards", "revealSolution", task_id, cid)

    # --- Voting ---

    def submit_vote(
        self,
        task_id: int,
        solver: str,
        is_correct: bool,
        score: int,
        alignment_score: int,
        report_cid: str,
    ) -> TransactionResult:
        """Submit a coordinator vote with correctness and alignment scores."""
        return self.send(
            "ResultsRewards", "submitVote",
            task_id, solver, is_correct, score, alignment_score, report_cid,
        )

    def finalize_voting(self, task_id: int, solver: str) -> TransactionResult:
        """Finalize voting for a task/solver pair."""
        return self.send("ResultsRewards", "finalizeVoting", task_id, solver, gas_limit=1000000)

    def is_voting_open(self, task_id: int, solver: str) -> bool:
        """Check if voting is still open."""
        try:
            return self.call("ResultsRewards", "isVotingOpen", task_id, solver)
        except Exception:
            return False

    def get_vote_count(self, task_id: int, solver: str) -> int:
        """Get vote count for a task/solver."""
        try:
            return self.call("ResultsRewards", "getVoteCount", task_id, solver)
        except Exception:
            return 0

    # --- Forced Errors ---

    def report_forced_error(self, task_id: int, solution_hash: bytes) -> TransactionResult:
        """Report catching a forced error."""
        return self.send("ForcedErrorRegistry", "reportForcedError", task_id, solution_hash)

    def is_task_forced_error(self, task_id: int) -> bool:
        """Check if a task is a forced error."""
        try:
            return self.call("ForcedErrorRegistry", "isTaskForcedError", task_id)
        except Exception:
            return False

    # --- RPB Model ---

    def set_mature_model(
        self, weights_cid: str, price: int
    ) -> TransactionResult:
        """Set the mature model on the RPB."""
        return self.send("RPB", "setMatureModel", weights_cid, price)

    # --- ATN Token ---

    def approve_atn(self, spender: str, amount: int) -> TransactionResult:
        """Approve ATN spending."""
        return self.send("ATNToken", "approve", spender, amount)

    # =========================================================================
    # Governance & Economic Layer (Autonet.sol on Jurisdiction chain)
    # =========================================================================

    # --- Service Registration ---

    def register_service(
        self, service_id: bytes, project_contract: str, codebase_hash: str
    ) -> TransactionResult:
        """Register a general service with the Autonet economic layer."""
        return self.send(
            "AutonetEconomy", "registerService",
            service_id, project_contract, codebase_hash,
        )

    def activate_service(self, service_id: bytes) -> TransactionResult:
        """Activate a registered service (admin only)."""
        return self.send("AutonetEconomy", "activateService", service_id)

    def get_service(self, service_id: bytes) -> Optional[Dict]:
        """Get service info by ID."""
        try:
            result = self.call("AutonetEconomy", "getService", service_id)
            if result:
                return {
                    "projectContract": result[0],
                    "serviceEndpoint": result[1],
                    "codebaseHash": result[2],
                    "serviceType": result[3],
                    "isActive": result[4],
                    "totalUsageUnits": result[5],
                    "totalRewards": result[6],
                }
            return None
        except Exception:
            return None

    # --- Usage Attestation ---

    def attest_usage(self, service_id: bytes, units: int) -> TransactionResult:
        """Attest usage for a service in the current epoch."""
        return self.send("AutonetEconomy", "attestUsage", service_id, units)

    # --- Epoch Management ---

    def start_epoch(self, budget: int) -> TransactionResult:
        """Start a new epoch with the given ATN budget (admin only)."""
        return self.send("AutonetEconomy", "startEpoch", budget, gas_limit=800000)

    def finalize_epoch(self) -> TransactionResult:
        """Finalize the current epoch and distribute rewards (admin only)."""
        return self.send("AutonetEconomy", "finalizeCurrentEpoch", gas_limit=1500000)

    def get_current_epoch(self) -> int:
        """Get the current epoch number."""
        try:
            return self.call("AutonetEconomy", "currentEpoch")
        except Exception:
            return 0

    def get_epoch_stats(self, epoch_id: int) -> Optional[Dict]:
        """Get stats for an epoch."""
        try:
            result = self.call("AutonetEconomy", "getEpochStats", epoch_id)
            if result:
                return {
                    "totalUsage": result[0],
                    "budget": result[1],
                    "finalized": result[2],
                    "finalizedAt": result[3],
                }
            return None
        except Exception:
            return None

    # --- Reward Claiming ---

    def claim_participant_reward(
        self, service_id: bytes, epoch_id: int
    ) -> TransactionResult:
        """Claim participant reward for attested usage in a finalized epoch."""
        return self.send(
            "AutonetEconomy", "claimParticipantReward",
            service_id, epoch_id,
        )

    def get_attester_usage(
        self, epoch_id: int, service_id: bytes, attester: str
    ) -> int:
        """Get attester's usage for a given epoch and service."""
        try:
            return self.call(
                "AutonetEconomy", "getAttesterUsage",
                epoch_id, service_id, attester,
            )
        except Exception:
            return 0

    # --- Emission Configuration ---

    def configure_emission(
        self, initial_budget: int, decay_rate_bps: int, epoch_duration: int
    ) -> TransactionResult:
        """Configure emission decay and enable auto-epoch (admin only)."""
        return self.send(
            "AutonetEconomy", "configureEmission",
            initial_budget, decay_rate_bps, epoch_duration,
        )

    def advance_epoch(self) -> TransactionResult:
        """Advance to next epoch (permissionless, requires duration elapsed)."""
        return self.send("AutonetEconomy", "advanceEpoch", gas_limit=1500000)

    # --- Reputation Claiming (RepToken) ---

    def claim_reputation(self) -> TransactionResult:
        """Claim reputation tokens based on economic activity."""
        return self.send("RepToken", "claimReputationFromEconomy")

    # --- Capability Scorecard ---

    def update_capability_score(
        self, module_id: bytes, score: int
    ) -> TransactionResult:
        """Report a capability score for a training module."""
        return self.send(
            "CapabilityScorecard", "updateScore",
            module_id, score,
        )

    def get_capability_scorecard(self) -> Optional[Dict]:
        """Fetch the full capability scorecard (modules, scores, multipliers)."""
        try:
            result = self.call("CapabilityScorecard", "getScorecard")
            if result:
                modules = []
                ids, scores, targets, multipliers = result
                for i in range(len(ids)):
                    modules.append({
                        "id": ids[i],
                        "score": scores[i],
                        "target": targets[i],
                        "multiplier": multipliers[i],
                    })
                return {"modules": modules}
            return None
        except Exception:
            return None

    def get_reward_multiplier(self, module_id: bytes) -> int:
        """Get the current reward multiplier for a module (10000 = 1x)."""
        try:
            return self.call(
                "CapabilityScorecard", "getRewardMultiplier", module_id
            )
        except Exception:
            return 10000  # 1x default

    # --- Evolution Proposals (EvolutionProposal.sol) ---

    def submit_evolution_proposal(
        self, content_cid: str, stake_amount: int
    ) -> TransactionResult:
        """Submit an evolution proposal with ATN stake."""
        return self.send(
            "EvolutionProposal", "submitProposal",
            content_cid, stake_amount,
        )

    def begin_proposal_evaluation(self, proposal_id: int) -> TransactionResult:
        """Begin RPB evaluation of a proposal (admin)."""
        return self.send("EvolutionProposal", "beginEvaluation", proposal_id)

    def submit_rpb_evaluation(
        self,
        proposal_id: int,
        approve: bool,
        confidence: int,
        reason_cid: str,
    ) -> TransactionResult:
        """Submit an RPB evaluation for a proposal."""
        return self.send(
            "EvolutionProposal", "submitEvaluation",
            proposal_id, approve, confidence, reason_cid,
        )

    def resolve_proposal_evaluation(self, proposal_id: int) -> TransactionResult:
        """Resolve RPB evaluation (permissionless after quorum + period)."""
        return self.send("EvolutionProposal", "resolveEvaluation", proposal_id)

    def adopt_proposal(self, proposal_id: int) -> TransactionResult:
        """Adopt a proposal after successful trial (admin)."""
        return self.send("EvolutionProposal", "adoptProposal", proposal_id)

    def reject_proposal(self, proposal_id: int) -> TransactionResult:
        """Reject a proposal (admin)."""
        return self.send("EvolutionProposal", "rejectProposal", proposal_id)

    def get_evolution_proposal(self, proposal_id: int) -> Optional[Dict]:
        """Get evolution proposal details."""
        try:
            result = self.call("EvolutionProposal", "getProposal", proposal_id)
            if result:
                return {
                    "proposer": result[0],
                    "contentCid": result[1],
                    "stakeAmount": result[2],
                    "status": result[3],
                    "createdAt": result[4],
                    "trialBudget": result[5],
                    "evaluationCount": result[6],
                    "evaluationScore": result[7],
                    "daoProposalId": result[8],
                }
            return None
        except Exception:
            return None

    def get_evolution_proposal_count(self) -> int:
        """Get total number of evolution proposals."""
        try:
            return self.call("EvolutionProposal", "getProposalCount")
        except Exception:
            return 0

    def get_rpb_evaluations(self, proposal_id: int) -> Optional[Dict]:
        """Get RPB evaluations for a proposal."""
        try:
            result = self.call("EvolutionProposal", "getEvaluations", proposal_id)
            if result:
                evals = []
                addrs, approvals, confidences, cids = result
                for i in range(len(addrs)):
                    evals.append({
                        "evaluator": addrs[i],
                        "approve": approvals[i],
                        "confidence": confidences[i],
                        "reasonCid": cids[i],
                    })
                return {"evaluations": evals}
            return None
        except Exception:
            return None

    def get_current_rpb_prompt(self) -> Optional[str]:
        """Get the current RPB constitutional prompt CID."""
        try:
            return self.call("EvolutionProposal", "getCurrentPromptCid")
        except Exception:
            return None

    def get_rpb_prompt_version(self, version: int) -> Optional[str]:
        """Get a specific version of the RPB prompt."""
        try:
            return self.call("EvolutionProposal", "getPromptVersion", version)
        except Exception:
            return None

    # --- DAO Governance (AutonetDAO) ---

    def propose_governance(
        self, description: str, calldata_hash: bytes
    ) -> TransactionResult:
        """Submit a governance proposal."""
        return self.send("AutonetDAO", "propose", description, calldata_hash)

    def cast_governance_vote(
        self, proposal_id: int, support: bool
    ) -> TransactionResult:
        """Cast a vote on a governance proposal."""
        return self.send("AutonetDAO", "castVote", proposal_id, support)

    def execute_proposal(
        self, proposal_id: int, target: str, data: bytes
    ) -> TransactionResult:
        """Execute a passed governance proposal."""
        return self.send(
            "AutonetDAO", "execute", proposal_id, target, data,
            gas_limit=1000000,
        )

    def get_proposal_state(self, proposal_id: int) -> Optional[int]:
        """Get the state of a governance proposal (enum index)."""
        try:
            return self.call("AutonetDAO", "getProposalState", proposal_id)
        except Exception:
            return None

    # --- Heartbeat ---

    def emit_heartbeat(self) -> TransactionResult:
        """Emit a governance heartbeat (admin/DAO only)."""
        return self.send("AutonetDAO", "emitHeartbeat")

    def get_atn_balance(self, address: str) -> int:
        """Get ATN balance."""
        try:
            return self.call("ATNToken", "balanceOf", address)
        except Exception:
            return 0

    # =========================================================================
    # Consensus-as-Truth (MM-Zero) operations
    # =========================================================================

    def propose_consensus_task(
        self,
        rpb_address: str,
        spec_hash: bytes,
        difficulty_target: tuple,
        learnability_reward: int,
        solver_reward: int,
    ) -> TransactionResult:
        """Propose a consensus-mode task (no ground truth).

        Args:
            difficulty_target: Tuple of (minSolvability, maxSolvability, peakSolvability) in BPS.
        """
        return self.send(
            "TaskContract", "proposeConsensusTask",
            rpb_address, spec_hash, difficulty_target,
            learnability_reward, solver_reward,
            gas_limit=800000,
        )

    def submit_rollout(
        self,
        task_id: int,
        answer_hash: bytes,
        solution_hash: bytes,
        confidence: int,
    ) -> TransactionResult:
        """Submit a solver rollout for a consensus-mode task."""
        return self.send(
            "TaskContract", "submitRollout",
            task_id, answer_hash, solution_hash, confidence,
        )

    def get_rollouts(self, task_id: int) -> list:
        """Get all rollouts for a task."""
        try:
            return self.call("TaskContract", "getRollouts", task_id)
        except Exception:
            return []

    def get_rollout_count(self, task_id: int) -> int:
        """Get rollout count for a task."""
        try:
            return self.call("TaskContract", "getRolloutCount", task_id)
        except Exception:
            return 0

    def get_difficulty_target(self, task_id: int) -> Optional[tuple]:
        """Get difficulty target for a consensus task."""
        try:
            return self.call("TaskContract", "getDifficultyTarget", task_id)
        except Exception:
            return None

    def is_rollout_collection_complete(self, task_id: int) -> bool:
        """Check if rollout collection is complete."""
        try:
            return self.call("TaskContract", "isRolloutCollectionComplete", task_id)
        except Exception:
            return False

    def finalize_consensus_task(self, task_id: int) -> TransactionResult:
        """Finalize a consensus-mode task (compute majority vote, distribute rewards)."""
        return self.send(
            "ResultsRewards", "finalizeConsensusTask",
            task_id,
            gas_limit=1500000,
        )

    # --- ResultsRewards ---

    def get_revealed_solution(self, task_id: int, solver: str) -> Optional[str]:
        """Get the revealed solution CID for a task/solver pair."""
        try:
            cid = self.call("ResultsRewards", "revealedSolutions", task_id, solver)
            return cid if cid else None
        except Exception:
            return None

    # --- RPB Model ---

    def get_mature_model(self) -> Optional[str]:
        """Get the current mature model from the RPB."""
        try:
            result = self.call("RPB", "getMatureModel")
            # Returns (weightsCid, price) tuple
            if result and len(result) >= 1:
                cid = result[0] if isinstance(result, (list, tuple)) else result
                return cid if cid else None
            return None
        except Exception:
            return None
