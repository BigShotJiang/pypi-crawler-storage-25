"""tests/unit/test_retrieval.py — Pure helpers in the recall pipeline.

The full ``RecallPipeline`` is exercised by integration tests. This file
covers the small pure functions that live in retrieval.py.
"""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import UUID

from gnokee.retrieval import (
    _approx_tokens,
    _format_excerpt_with_date,
    _query_wants_recency,
    _sort_by_recency,
)
from gnokee.storage.metadata import EpisodeMetadataRow


def test_format_excerpt_with_date_prepends_iso_date() -> None:
    valid_at = datetime(2024, 2, 1, 9, 0, tzinfo=timezone.utc)
    out = _format_excerpt_with_date("Started Lisinopril 10 mg PO daily.", valid_at)
    assert out == "[2024-02-01] Started Lisinopril 10 mg PO daily."


def test_format_excerpt_with_date_passes_through_when_none() -> None:
    out = _format_excerpt_with_date("Some text.", None)
    assert out == "Some text."


def test_format_excerpt_uses_date_part_only_not_time() -> None:
    """`valid_at` carries time-of-day; prefix must only carry the date."""
    valid_at = datetime(2024, 9, 20, 14, 37, 5, tzinfo=timezone.utc)
    out = _format_excerpt_with_date("Started Losartan 50 mg PO daily.", valid_at)
    assert out.startswith("[2024-09-20] ")
    assert "14:37" not in out
    assert "20T" not in out


def test_format_excerpt_preserves_inner_text_verbatim() -> None:
    """Prefix only — no rewriting of the inner text."""
    text = "Discontinued Lisinopril 20 mg today; cough x 6 weeks."
    valid_at = datetime(2024, 9, 15, tzinfo=timezone.utc)
    out = _format_excerpt_with_date(text, valid_at)
    assert text in out


def test_approx_tokens_minimum_one() -> None:
    """Empty / very short strings still cost at least one token."""
    assert _approx_tokens("") == 1
    assert _approx_tokens("a") == 1
    assert _approx_tokens("abcd") == 1
    assert _approx_tokens("a" * 8) == 2


# ---------------------------------------------------------------------------
# _query_wants_recency
# ---------------------------------------------------------------------------


def test_query_wants_recency_currently() -> None:
    assert _query_wants_recency("What medication am I currently on?") is True
    assert _query_wants_recency("What am I taking now?") is True
    assert _query_wants_recency("What's my latest BP reading?") is True
    assert _query_wants_recency("Active prescriptions?") is True


def test_query_wants_recency_negative() -> None:
    assert _query_wants_recency("When did I start Lisinopril?") is False
    assert _query_wants_recency("What was my dose in May 2024?") is False
    assert _query_wants_recency("") is False
    # "current" matches "current dose"; OK — same semantic as "currently"
    assert _query_wants_recency("Tell me about my history") is False


# ---------------------------------------------------------------------------
# _sort_by_recency
# ---------------------------------------------------------------------------


def _meta(uuid: UUID, valid_at: datetime) -> EpisodeMetadataRow:
    return EpisodeMetadataRow(
        tenant_id="t",
        episode_uuid=uuid,
        valid_at=valid_at,
        valid_until=None,
        asserted_at=valid_at,
        asserted_until=None,
        superseded_by=None,
        sensitive="default",
        language=None,
        our_id=None,
    )


def test_sort_by_recency_orders_newest_first() -> None:
    u1, u2, u3 = UUID(int=1), UUID(int=2), UUID(int=3)
    lookup = {
        u1: _meta(u1, datetime(2024, 1, 1, tzinfo=timezone.utc)),
        u2: _meta(u2, datetime(2025, 6, 1, tzinfo=timezone.utc)),
        u3: _meta(u3, datetime(2024, 9, 1, tzinfo=timezone.utc)),
    }
    out = _sort_by_recency([u1, u2, u3], lookup)
    assert out == [u2, u3, u1]


def test_sort_by_recency_episodes_without_metadata_go_last() -> None:
    u1, u2, u3 = UUID(int=1), UUID(int=2), UUID(int=3)
    lookup = {u1: _meta(u1, datetime(2024, 1, 1, tzinfo=timezone.utc))}
    out = _sort_by_recency([u2, u1, u3], lookup)
    # u1 (only with metadata) wins; u2/u3 fall to the tail at sentinel min.
    assert out[0] == u1


def test_sort_by_recency_preserves_input_when_all_missing() -> None:
    u1, u2 = UUID(int=1), UUID(int=2)
    out = _sort_by_recency([u1, u2], {})
    # All sentinel-tied → stable sort preserves input order.
    assert out == [u1, u2]
