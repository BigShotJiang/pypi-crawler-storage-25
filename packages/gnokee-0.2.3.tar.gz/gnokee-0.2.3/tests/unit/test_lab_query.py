"""tests/unit/test_lab_query.py — LabQueryPipeline orchestrator (ADR-0009)."""

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import Any
from uuid import uuid4

import pytest

from gnokee.errors import ValidationError
from gnokee.lab_query import LabQueryPipeline, lab_query
from gnokee.storage.lab import LabRecordRow


def _utc(year: int = 2024, month: int = 1, day: int = 1) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


class StubLabStore:
    """Captures call args and returns canned data."""

    def __init__(self) -> None:
        self.last_call: dict[str, Any] = {}
        self.row = LabRecordRow(
            tenant_id="t1",
            episode_uuid=uuid4(),
            analyte="Potassium",
            value_numeric=Decimal("4.2"),
            value_text=None,
            unit="mmol/L",
            ref_range_low=Decimal("3.5"),
            ref_range_high=Decimal("5.0"),
            abnormal_flag=None,
            valid_at=_utc(2024, 4, 1),
            asserted_at=_utc(2024, 4, 3),
        )
        self.abnormal_rows: list[LabRecordRow] = [
            LabRecordRow(
                tenant_id="t1",
                episode_uuid=uuid4(),
                analyte="Magnesium",
                value_numeric=Decimal("1.4"),
                value_text=None,
                unit="mg/dL",
                ref_range_low=Decimal("1.7"),
                ref_range_high=Decimal("2.2"),
                abnormal_flag="L",
                valid_at=_utc(2024, 4, 10),
                asserted_at=_utc(2024, 4, 12),
            ),
        ]

    async def latest(self, **kwargs: Any) -> LabRecordRow | None:
        self.last_call = {"method": "latest", **kwargs}
        return self.row

    async def history(self, **kwargs: Any) -> list[LabRecordRow]:
        self.last_call = {"method": "history", **kwargs}
        return [self.row]

    async def aggregate(self, **kwargs: Any) -> Decimal | None:
        self.last_call = {"method": "aggregate", **kwargs}
        return Decimal("3.4")

    async def abnormal(self, **kwargs: Any) -> list[LabRecordRow]:
        self.last_call = {"method": "abnormal", **kwargs}
        return list(self.abnormal_rows)


@pytest.mark.asyncio
async def test_latest_returns_one_row() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    response = await lab_query(
        pipeline=pipeline,
        tenant_id="t1",
        analyte="Potassium",
        op="latest",
    )
    assert response.op == "latest"
    assert len(response.rows) == 1
    assert response.count == 1
    assert response.rows[0].value_numeric == Decimal("4.2")


@pytest.mark.asyncio
async def test_history_passes_range() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    since = _utc(2024, 1, 1)
    until = _utc(2025, 1, 1)
    response = await lab_query(
        pipeline=pipeline,
        tenant_id="t1",
        analyte="Potassium",
        op="history",
        since=since,
        until=until,
    )
    assert response.op == "history"
    assert response.count == 1
    assert store.last_call["since"] == since
    assert store.last_call["until"] == until


@pytest.mark.asyncio
async def test_aggregate_returns_scalar() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    response = await lab_query(
        pipeline=pipeline,
        tenant_id="t1",
        analyte="Potassium",
        op="min",
    )
    assert response.op == "min"
    assert response.scalar == Decimal("3.4")
    assert response.rows == []


@pytest.mark.asyncio
async def test_count_op_populates_count_field() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    response = await lab_query(
        pipeline=pipeline,
        tenant_id="t1",
        analyte="Potassium",
        op="count",
    )
    assert response.op == "count"
    assert response.count == 3  # int(Decimal("3.4"))


@pytest.mark.asyncio
async def test_rejects_empty_tenant() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    with pytest.raises(ValidationError):
        await lab_query(pipeline=pipeline, tenant_id="", analyte="K", op="latest")


@pytest.mark.asyncio
async def test_rejects_inverted_range() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    with pytest.raises(ValidationError):
        await lab_query(
            pipeline=pipeline,
            tenant_id="t1",
            analyte="K",
            op="history",
            since=_utc(2025, 1, 1),
            until=_utc(2024, 1, 1),
        )


@pytest.mark.asyncio
async def test_history_caps_limit() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    await lab_query(
        pipeline=pipeline,
        tenant_id="t1",
        analyte="K",
        op="history",
        limit=10_000,
    )
    assert store.last_call["limit"] == 500  # MAX_HISTORY_LIMIT


@pytest.mark.asyncio
async def test_abnormal_returns_rows_with_flag_set() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    response = await lab_query(
        pipeline=pipeline,
        tenant_id="t1",
        analyte=None,
        op="abnormal",
        since=_utc(2024, 4, 1),
        until=_utc(2024, 7, 1),
    )
    assert response.op == "abnormal"
    assert response.count == 1
    assert response.rows[0].abnormal_flag == "L"
    assert response.rows[0].analyte == "Magnesium"
    assert store.last_call["method"] == "abnormal"
    assert store.last_call["analyte"] is None
    assert store.last_call["since"] == _utc(2024, 4, 1)
    assert store.last_call["until"] == _utc(2024, 7, 1)


@pytest.mark.asyncio
async def test_abnormal_passes_analyte_filter_when_supplied() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    await lab_query(
        pipeline=pipeline,
        tenant_id="t1",
        analyte="Magnesium",
        op="abnormal",
    )
    assert store.last_call["method"] == "abnormal"
    assert store.last_call["analyte"] == "Magnesium"


@pytest.mark.asyncio
async def test_non_abnormal_op_still_requires_analyte() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    with pytest.raises(ValidationError):
        await lab_query(
            pipeline=pipeline,
            tenant_id="t1",
            analyte=None,
            op="latest",
        )


@pytest.mark.asyncio
async def test_abnormal_caps_limit() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    await lab_query(
        pipeline=pipeline,
        tenant_id="t1",
        analyte=None,
        op="abnormal",
        limit=10_000,
    )
    assert store.last_call["limit"] == 500  # MAX_HISTORY_LIMIT


@pytest.mark.asyncio
async def test_abnormal_rejects_inverted_range() -> None:
    store = StubLabStore()
    pipeline = LabQueryPipeline(lab=store)  # type: ignore[arg-type]
    with pytest.raises(ValidationError):
        await lab_query(
            pipeline=pipeline,
            tenant_id="t1",
            analyte=None,
            op="abnormal",
            since=_utc(2025, 1, 1),
            until=_utc(2024, 1, 1),
        )
