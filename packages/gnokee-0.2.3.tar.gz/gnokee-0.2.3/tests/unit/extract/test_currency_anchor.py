"""tests/unit/extract/test_currency_anchor.py — Bold-currency anchor rule.

Covers gnokee #6: extracts numeric totals from bold list-items and bold
declarative currency lines that the pipe-table rule cannot reach.
"""

from __future__ import annotations

from gnokee.extract import augment_for_extraction
from gnokee.extract.rules.currency_anchor import MAX_PER_DOC, extract


def test_bold_list_item_total_under_heading() -> None:
    content = (
        "## Actual spend to date (as of 20.04.2026)\n"
        "- Generator: 339.85 (19.02.2026)\n"
        "- Labor (work): 3,633.61\n"
        "- **Total spent: 14,225.45**\n"
    )
    out = extract(content)
    joined = "\n".join(out)
    assert "14,225.45" in joined
    assert "Actual spend to date" in joined
    assert "Total spent" in joined


def test_bold_declarative_currency_under_heading() -> None:
    content = "## Renovation — actuals\n**€14,225 spent through 20.04.2026.** Floors, kitchen install ahead.\n"
    out = extract(content)
    joined = "\n".join(out)
    assert "€14,225" in joined
    assert "Renovation — actuals" in joined


def test_bold_inline_dollar_with_amount() -> None:
    content = "## Capital\n**$5m raised in seed round.** Closing 2025-Q4.\n"
    out = extract(content)
    joined = "\n".join(out)
    assert "$5m" in joined
    assert "Capital" in joined


def test_both_shapes_in_same_document() -> None:
    content = (
        "## Spend summary\n"
        "- **Subtotal: 1,200.00**\n"
        "- **Tax: 240.00**\n"
        "\n"
        "## Year totals\n"
        "**€1,440 spent in Q1 2026.**\n"
    )
    out = extract(content)
    joined = "\n".join(out)
    assert "1,200.00" in joined
    assert "240.00" in joined
    assert "€1,440" in joined


def test_no_heading_uses_blank_anchor() -> None:
    content = "**Total spent: 999.99**\n"
    out = extract(content)
    assert any("999.99" in s for s in out)


def test_document_title_h1_prepended_when_present() -> None:
    """First H1 anchors derived sentence to a likely-extracted entity."""
    content = "# Sofia Apartment\n## Renovation — actuals\n**€14,225 spent through 20.04.2026.**\n"
    out = extract(content)
    joined = "\n".join(out)
    assert joined.startswith("Sofia Apartment:") or "Sofia Apartment:" in joined
    assert "€14,225" in joined
    assert "Renovation — actuals" in joined


def test_document_title_only_when_no_section() -> None:
    """If only an H1 is present, omit section qualifier."""
    content = "# Project Acme\n**Budget: $50k allocated.**\n"
    out = extract(content)
    joined = "\n".join(out)
    assert "Project Acme:" in joined
    assert "$50k" in joined
    assert "(" not in joined  # no parenthesised section


def test_plain_currency_not_in_bold_does_not_fire() -> None:
    content = "## Notes\nGenerator cost was 339.85 EUR.\nWe spent €100 last week on lunch.\n"
    out = extract(content)
    assert out == []


def test_bold_without_currency_or_total_keyword_does_not_fire() -> None:
    content = "## Notes\n**Important caveat:** review all items twice.\n- **Done already.**\n"
    out = extract(content)
    assert out == []


def test_pipe_table_rows_skipped() -> None:
    """table_amount rule owns pipe tables; this rule must not double-fire."""
    content = "## Spend\n| Item   | Cost   |\n| ------ | ------ |\n| eu     | €100   |\n"
    out = extract(content)
    assert out == []


def test_caps_at_max_per_doc() -> None:
    body_lines = "\n".join(f"- **Total run-{i}: {i}.00**" for i in range(MAX_PER_DOC + 5))
    content = f"## H\n{body_lines}\n"
    out = extract(content)
    assert len(out) <= MAX_PER_DOC


def test_dedupes_identical_emit() -> None:
    content = "## H\n- **Total spent: 14,225.45**\n- **Total spent: 14,225.45**\n"
    out = extract(content)
    assert len(out) == 1


def test_empty_content_returns_empty() -> None:
    assert extract("") == []


def test_augment_includes_currency_anchor_output() -> None:
    """Top-level pipeline wires the rule and emits derived sentences."""
    content = "## Renovation — actuals\n**€14,225 spent through 20.04.2026.** Floors ahead.\n"
    out = augment_for_extraction(content)
    assert content in out
    assert "Derived facts:" in out
    assert "€14,225" in out[len(content) :]
