"""tests/unit/extract/test_lab_parser.py — Markdown lab-panel parser (ADR-0009)."""

from __future__ import annotations

from decimal import Decimal

from gnokee.extract.clinical.lab_parser import parse_labs


def test_parses_basic_panel_lines() -> None:
    content = (
        "Lab panel — drawn 2024-01-15.\n\n"
        "Basic Metabolic Panel:\n"
        "- Sodium: 140 mmol/L (ref: 135-145)\n"
        "- Potassium: 4.2 mmol/L (ref: 3.5-5.0)\n"
        "- Glucose (fasting): 92 mg/dL (ref: 70-99)\n"
    )
    rows = parse_labs(content)
    by_analyte = {r.analyte: r for r in rows}
    assert "Sodium" in by_analyte
    assert by_analyte["Sodium"].value_numeric == Decimal("140")
    assert by_analyte["Sodium"].unit == "mmol/L"
    assert by_analyte["Sodium"].ref_range_low == Decimal("135")
    assert by_analyte["Sodium"].ref_range_high == Decimal("145")
    assert by_analyte["Sodium"].abnormal_flag is None


def test_low_flag() -> None:
    content = "- Potassium: 3.4 mmol/L (ref: 3.5-5.0) — slightly LOW\n"
    rows = parse_labs(content)
    assert len(rows) == 1
    assert rows[0].abnormal_flag == "L"


def test_critical_flag_takes_priority() -> None:
    content = "- Potassium: 2.8 mmol/L (ref: 3.5-5.0) **LOW — critical**\n"
    rows = parse_labs(content)
    assert len(rows) == 1
    assert rows[0].abnormal_flag == "C"


def test_high_flag() -> None:
    content = "- Creatinine: 1.4 mg/dL (ref: 0.6-1.2) — HIGH\n"
    rows = parse_labs(content)
    assert rows[0].abnormal_flag == "H"


def test_percent_unit_and_no_ref() -> None:
    content = "- Hematocrit: 42.1 % (ref: 39-50)\n"
    rows = parse_labs(content)
    assert rows[0].unit == "%"
    assert rows[0].ref_range_low == Decimal("39")


def test_decimal_value() -> None:
    content = "- Hemoglobin: 14.2 g/dL (ref: 13.5-17.5)\n"
    rows = parse_labs(content)
    assert rows[0].value_numeric == Decimal("14.2")
    assert rows[0].unit == "g/dL"
    assert rows[0].ref_range_low == Decimal("13.5")


def test_dedupe_within_panel() -> None:
    content = "- Sodium: 140 mmol/L\n- Sodium: 140 mmol/L\n"
    rows = parse_labs(content)
    assert len(rows) == 1


def test_empty_content() -> None:
    assert parse_labs("") == []


def test_non_lab_content_returns_empty() -> None:
    assert parse_labs("Patient feels well today. No new symptoms.") == []


def test_multiple_panels_in_one_episode() -> None:
    content = (
        "BMP:\n- Sodium: 140 mmol/L (ref: 135-145)\n- Potassium: 4.2 mmol/L (ref: 3.5-5.0)\n\n"
        "CBC:\n- Hemoglobin: 14.0 g/dL (ref: 13.5-17.5)\n- WBC: 6.8 ×10^9/L (ref: 4.0-11.0)\n"  # noqa: RUF001
    )
    rows = parse_labs(content)
    analytes = {r.analyte for r in rows}
    assert {"Sodium", "Potassium", "Hemoglobin", "WBC"}.issubset(analytes)
