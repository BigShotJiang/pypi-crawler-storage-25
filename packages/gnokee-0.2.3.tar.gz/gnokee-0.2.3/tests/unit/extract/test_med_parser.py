"""tests/unit/extract/test_med_parser.py — Medication-event parser (ADR-0010)."""

from __future__ import annotations

from decimal import Decimal

from gnokee.extract.clinical.med_parser import parse_meds


def test_started_with_dose() -> None:
    rows = parse_meds("Started Lisinopril 10 mg PO daily for stage-1 hypertension.")
    assert len(rows) == 1
    r = rows[0]
    assert r.drug_name == "Lisinopril"
    assert r.dose_value == Decimal("10")
    assert r.dose_unit == "mg"
    assert r.event_kind == "start"
    assert r.route == "PO"
    assert r.frequency == "daily"


def test_stopped() -> None:
    rows = parse_meds("Discontinued Lisinopril 20 mg today.")
    assert len(rows) == 1
    assert rows[0].event_kind == "stop"
    assert rows[0].dose_value == Decimal("20")


def test_dose_increase() -> None:
    rows = parse_meds("Increased Lisinopril from 10 mg to 20 mg PO daily.")
    assert len(rows) == 1
    assert rows[0].event_kind == "increase"
    assert rows[0].dose_value == Decimal("20")
    assert rows[0].dose_unit == "mg"


def test_dose_decrease() -> None:
    rows = parse_meds("Decreased Furosemide from 40 mg to 20 mg daily.")
    assert len(rows) == 1
    assert rows[0].event_kind == "decrease"
    assert rows[0].dose_value == Decimal("20")


def test_allergy() -> None:
    rows = parse_meds("Allergy documented: Penicillin — moderate reaction.")
    assert len(rows) == 1
    assert rows[0].drug_name == "Penicillin"
    assert rows[0].event_kind == "allergy"
    assert rows[0].dose_value is None


def test_two_word_drug_name() -> None:
    rows = parse_meds("Started Potassium Chloride 20 mEq PO daily.")
    assert len(rows) == 1
    assert rows[0].drug_name == "Potassium Chloride"
    assert rows[0].dose_unit == "mEq"


def test_multi_sentence_episode() -> None:
    content = "Started Lisinopril 10 mg PO daily for hypertension. Counselled on cough and angioedema warning signs."
    rows = parse_meds(content)
    assert len(rows) == 1
    assert rows[0].drug_name == "Lisinopril"


def test_empty_content() -> None:
    assert parse_meds("") == []


def test_non_med_content_returns_empty() -> None:
    assert parse_meds("Patient feels well, no complaints today.") == []


def test_dedupe_same_event() -> None:
    content = "Started Lisinopril 10 mg PO daily.\nStarted Lisinopril 10 mg PO daily."
    rows = parse_meds(content)
    assert len(rows) == 1
