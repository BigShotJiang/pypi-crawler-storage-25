"""tests/unit/extract/test_preprocessor.py — Deterministic preprocessor rules.

Covers issues #2 (numbered identifiers), #3 (ranked priority), #4 (table currency
amounts). Pure-input → pure-output; no LLM, no IO.
"""

from __future__ import annotations

from gnokee.extract import augment_for_extraction
from gnokee.extract.rules.identifier import extract as extract_identifiers
from gnokee.extract.rules.med_event import extract as extract_med_events
from gnokee.extract.rules.ranked_list import extract as extract_ranked
from gnokee.extract.rules.table_amount import extract as extract_table_amounts

# ---------------------------------------------------------------------------
# Rule 1 — Identifier (issue #2)
# ---------------------------------------------------------------------------


def test_identifier_adr_under_heading() -> None:
    content = "## ADR-025: Maintenance daemon cadence\nWe will run synthesis nightly at 02:00 UTC.\n"
    out = extract_identifiers(content)
    assert any("ADR-025" in s for s in out)
    assert any("Maintenance daemon cadence" in s for s in out)
    assert any("synthesis nightly at 02:00 UTC" in s for s in out)


def test_identifier_all_supported_shapes() -> None:
    content = "# Notes\nADR-006 says X. Q1 says Y. P1.3 says Z. RFC-7807 says W.\n"
    out = extract_identifiers(content)
    joined = "\n".join(out)
    assert "ADR-006" in joined
    assert "Q1" in joined
    assert "P1.3" in joined
    assert "RFC-7807" in joined


def test_identifier_dedupes_repeats() -> None:
    content = "# H\nADR-025 is great. ADR-025 again. ADR-025 once more.\n"
    out = extract_identifiers(content)
    adr_lines = [s for s in out if "ADR-025" in s]
    assert len(adr_lines) == 1


def test_identifier_caps_at_twenty() -> None:
    body = "# H\n" + "\n".join(f"ADR-{i:03d} mention." for i in range(1, 31))
    out = extract_identifiers(body)
    assert len(out) <= 20


def test_identifier_no_false_positive_on_lone_letters() -> None:
    content = "# H\nQ alone is not an identifier. ADR alone neither.\n"
    out = extract_identifiers(content)
    assert out == []


def test_identifier_uses_blank_heading_when_none() -> None:
    content = "ADR-001 stands alone.\n"
    out = extract_identifiers(content)
    assert any("ADR-001" in s for s in out)


# ---------------------------------------------------------------------------
# Rule 2 — Ranked list (issue #3)
# ---------------------------------------------------------------------------


def test_ranked_three_item_ordered_list() -> None:
    content = "## Open questions for v0.1\n1. Q1 graphiti spike\n2. Q2 cross-lingual recall\n3. Q3 retrieval shape\n"
    out = extract_ranked(content)
    joined = "\n".join(out)
    assert "top item" in joined.lower()
    assert "Q1 graphiti spike" in joined
    assert "second item" in joined.lower()
    assert "Q2 cross-lingual recall" in joined


def test_ranked_p_prefix_priority() -> None:
    content = "## Triage\nP0: ship the gate today.\nP1: write a runbook.\n"
    out = extract_ranked(content)
    joined = "\n".join(out)
    assert "P0 priority" in joined
    assert "ship the gate today" in joined
    assert "P1 priority" in joined


def test_ranked_top_of_stack_phrase() -> None:
    content = "## Open questions for v0.1\nTop of stack: validate before writing real code → Q1.\n"
    out = extract_ranked(content)
    joined = "\n".join(out)
    assert "Top of stack" in joined
    assert "Open questions for v0.1" in joined
    assert "Q1" in joined


def test_ranked_empty_list_emits_nothing() -> None:
    content = "## H\nJust prose, no list, no priorities.\n"
    out = extract_ranked(content)
    assert out == []


def test_ranked_caps_at_three_items_per_list() -> None:
    content = "## H\n" + "\n".join(f"{i}. item-{i}" for i in range(1, 11))
    out = extract_ranked(content)
    list_item_lines = [s for s in out if "item under" in s.lower()]
    assert len(list_item_lines) <= 3


# ---------------------------------------------------------------------------
# Rule 3 — Table amount (issue #4)
# ---------------------------------------------------------------------------


def test_table_amount_sofia_renovation() -> None:
    content = (
        "## Sofia Apartment / Finance\n"
        "\n"
        "| Category   | Vendor   | Amount    | As of      |\n"
        "| ---------- | -------- | --------- | ---------- |\n"
        "| renovation | Foo Ltd. | €14,225   | 2026-04-20 |\n"
    )
    out = extract_table_amounts(content)
    joined = "\n".join(out)
    assert "renovation" in joined
    assert "€14,225" in joined
    assert "Sofia Apartment / Finance" in joined


def test_table_amount_multi_currency() -> None:
    content = (
        "## Spend\n"
        "| Item   | Cost   |\n"
        "| ------ | ------ |\n"
        "| eu     | €100   |\n"
        "| us     | $200   |\n"
        "| uk     | £300   |\n"
    )
    out = extract_table_amounts(content)
    joined = "\n".join(out)
    assert "€100" in joined
    assert "$200" in joined
    assert "£300" in joined


def test_table_amount_suffix_k_and_m() -> None:
    content = "## Capital\n| Item  | Amount  |\n| ----- | ------- |\n| seed  | €500k   |\n| raise | $5m     |\n"
    out = extract_table_amounts(content)
    joined = "\n".join(out)
    assert "€500k" in joined
    assert "$5m" in joined


def test_table_amount_table_without_currency_emits_nothing() -> None:
    content = "## Plan\n| Item  | Owner |\n| ----- | ----- |\n| ship  | alice |\n"
    out = extract_table_amounts(content)
    assert out == []


def test_table_amount_malformed_row_does_not_crash() -> None:
    content = "## Wonky\n| Item | Amount |\n| ---- | ------ |\n| broken row no pipe at end\n| ok   | €5     |\n"
    out = extract_table_amounts(content)
    joined = "\n".join(out)
    assert "€5" in joined


# ---------------------------------------------------------------------------
# Rule 5 — Med event (ADR-0010 cheap mitigation; Q8 meds)
# ---------------------------------------------------------------------------


def test_med_event_started_drug_with_dose() -> None:
    content = "Started Lisinopril 10 mg PO daily for stage-1 hypertension."
    out = extract_med_events(content)
    assert "Lisinopril 10 mg was started." in out


def test_med_event_two_word_drug_name() -> None:
    content = "Started Potassium Chloride 20 mEq PO daily supplementation."
    out = extract_med_events(content)
    assert "Potassium Chloride 20 mEq was started." in out


def test_med_event_discontinued() -> None:
    content = "Discontinued Lisinopril 20 mg today."
    out = extract_med_events(content)
    assert "Lisinopril 20 mg was discontinued." in out


def test_med_event_added() -> None:
    content = "Added Furosemide 20 mg PO daily for residual hypertension."
    out = extract_med_events(content)
    assert "Furosemide 20 mg was added." in out


def test_med_event_dose_change_with_from_to() -> None:
    content = "Increased Lisinopril from 10 mg to 20 mg PO daily."
    out = extract_med_events(content)
    assert "Lisinopril dose changed from 10 mg to 20 mg." in out


def test_med_event_dose_change_to_only() -> None:
    content = "Increased Losartan to 100 mg PO daily."
    out = extract_med_events(content)
    assert "Losartan dose changed to 100 mg." in out


def test_med_event_allergy_documented() -> None:
    content = "Allergy documented: Penicillin — moderate reaction within 2 hours of amoxicillin."
    out = extract_med_events(content)
    assert "Penicillin allergy documented." in out


def test_med_event_multi_sentence_episode() -> None:
    content = (
        "Started Lisinopril 10 mg PO daily for stage-1 hypertension. "
        "Office BP today 142/91. Counselled on cough and angioedema."
    )
    out = extract_med_events(content)
    assert "Lisinopril 10 mg was started." in out
    # Office BP / Counselled sentences must NOT produce derived facts.
    assert all("Office" not in s and "Counselled" not in s for s in out)


def test_med_event_dedupes_repeats() -> None:
    content = "Started Lisinopril 10 mg. Started Lisinopril 10 mg."
    out = extract_med_events(content)
    assert out.count("Lisinopril 10 mg was started.") == 1


def test_med_event_no_match_returns_empty() -> None:
    content = "Patient counselled on diet and exercise. Recheck in 4 weeks."
    out = extract_med_events(content)
    assert out == []


def test_med_event_empty_content_returns_empty() -> None:
    assert extract_med_events("") == []


# ---------------------------------------------------------------------------
# augment_for_extraction (top-level)
# ---------------------------------------------------------------------------


def test_augment_empty_content_returns_unchanged() -> None:
    out = augment_for_extraction("")
    assert out == ""


def test_augment_no_signal_returns_unchanged() -> None:
    plain = "# Notes\nJust some prose with nothing to lift.\n"
    out = augment_for_extraction(plain)
    assert out == plain


def test_augment_kitchen_sink_fires_all_rules() -> None:
    content = (
        "## Open questions for v0.1\n"
        "Top of stack: validate Q1 first.\n"
        "1. Q1 graphiti spike\n"
        "\n"
        "## Sofia Apartment / Finance\n"
        "| Category   | Amount  |\n"
        "| ---------- | ------- |\n"
        "| renovation | €14,225 |\n"
        "\n"
        "ADR-025 covers maintenance.\n"
    )
    out = augment_for_extraction(content)
    assert content in out
    assert "Derived facts:" in out
    assert "ADR-025" in out
    assert "Q1" in out
    assert "€14,225" in out


def test_augment_format_has_separator_and_bullets() -> None:
    content = "# H\nADR-007 mentioned.\n"
    out = augment_for_extraction(content)
    assert content in out
    tail = out[len(content) :]
    assert "---" in tail
    assert "Derived facts:" in tail
    assert "- " in tail


def test_augment_rule_failure_does_not_break_others(monkeypatch) -> None:
    """If one rule raises, augment still returns content + facts from other rules."""
    import gnokee.extract.preprocessor as preprocessor

    def boom(_: str) -> list[str]:
        raise RuntimeError("rule died")

    monkeypatch.setattr(preprocessor, "_extract_identifiers", boom)
    content = "## H\n1. only item\n"
    out = augment_for_extraction(content)
    assert content in out
    # ranked rule must still have produced something
    assert "only item" in out
