"""tests/unit/test_excerpts.py — Currency / med excerpt helpers.

Pure-input → pure-output; no IO, no LLM. Verifies the recall-side body
excerpt extractor that surfaces verbatim numbers / drug names / dates
that graphiti's edge-fact LLM otherwise summarises away.

Currency path: gnokee #7. Med path: ADR-0010 cheap mitigation for Q8.
"""

from __future__ import annotations

from gnokee.excerpts import find_currency_excerpt, find_med_excerpt, query_wants_excerpt

# ---------------------------------------------------------------------------
# query_wants_excerpt
# ---------------------------------------------------------------------------


def test_query_with_currency_symbol_wants_excerpt() -> None:
    assert query_wants_excerpt("How much have I spent in €?") is True
    assert query_wants_excerpt("Total cost: $5k") is True


def test_query_with_amount_keyword_wants_excerpt() -> None:
    assert query_wants_excerpt("How much have I spent on renovation?") is True
    assert query_wants_excerpt("What is the project budget so far") is True
    assert query_wants_excerpt("Show me the total cost") is True
    assert query_wants_excerpt("List my outstanding payments") is True


def test_query_without_amount_signal_does_not_want_excerpt() -> None:
    assert query_wants_excerpt("What does ADR-025 decide?") is False
    assert query_wants_excerpt("Who is responsible for kitchen install") is False
    assert query_wants_excerpt("") is False


def test_query_amount_keyword_substring_does_not_match_inside_word() -> None:
    """`spending` should match (root `spend`); `accosted` should NOT match `cost`."""
    assert query_wants_excerpt("Tell me about spending limits") is True
    assert query_wants_excerpt("Was anyone accosted in the lobby?") is False


# ---------------------------------------------------------------------------
# find_currency_excerpt
# ---------------------------------------------------------------------------


def test_excerpt_bold_declarative_currency_line() -> None:
    content = (
        "# Project Acme\n## Renovation status\n**€12,345 spent through 2026-04-20.** Floors and HVAC still ahead.\n"
    )
    out = find_currency_excerpt(content, max_chars=200)
    assert out is not None
    assert "€12,345" in out
    # heading context attached
    assert "Renovation status" in out


def test_excerpt_list_item_bold_total() -> None:
    content = "# Project Acme\n## Spend ledger\n- Vendor A subtotal: 100.00\n- **Total: 12,345.67**\n"
    out = find_currency_excerpt(content, max_chars=200)
    assert out is not None
    # First amount-keyword + digit line wins; that is the "subtotal" row.
    assert "100.00" in out or "12,345.67" in out
    assert "Spend ledger" in out


def test_excerpt_returns_first_match_only() -> None:
    content = "# H\n**€1,000 spent in Q1.** prose\n**€2,000 spent in Q2.** more prose\n"
    out = find_currency_excerpt(content, max_chars=400)
    assert out is not None
    assert "€1,000" in out
    # second match still allowed to appear in the same window if it fits
    # but the function must at minimum surface the first hit


def test_excerpt_returns_none_when_no_amount() -> None:
    content = "# Notes\nProse with vendors and dates but no amounts.\n"
    assert find_currency_excerpt(content, max_chars=200) is None


def test_excerpt_returns_none_for_empty_content() -> None:
    assert find_currency_excerpt("", max_chars=200) is None


def test_excerpt_respects_max_chars_cap() -> None:
    content = (
        "## Long heading that goes on and on and on and on about a project\n"
        "**€42,000 was the total invoice " + "x" * 500 + ".**\n"
    )
    out = find_currency_excerpt(content, max_chars=120)
    assert out is not None
    assert len(out) <= 120
    assert "€42,000" in out  # the amount itself is still present


def test_excerpt_includes_heading_when_present_in_window() -> None:
    content = "## Q2 spend\n**€2,400 total.**\n"
    out = find_currency_excerpt(content, max_chars=200)
    assert out is not None
    assert "Q2 spend" in out
    assert "€2,400" in out


def test_excerpt_skips_non_amount_currency_mentions() -> None:
    """A line mentioning currency without a digit should not match."""
    content = "# H\nWe priced this in EUR for stability.\n"
    assert find_currency_excerpt(content, max_chars=200) is None


# ---------------------------------------------------------------------------
# query_wants_excerpt — med token path (ADR-0010 cheap mitigation)
# ---------------------------------------------------------------------------


def test_query_med_keyword_wants_excerpt() -> None:
    assert query_wants_excerpt("What medications am I taking?") is True
    assert query_wants_excerpt("What dose of Lisinopril was I on?") is True
    assert query_wants_excerpt("Am I allergic to anything?") is True
    assert query_wants_excerpt("Was I prescribed antibiotics?") is True
    assert query_wants_excerpt("Why was I on potassium supplementation?") is True


def test_query_med_dose_unit_wants_excerpt() -> None:
    assert query_wants_excerpt("Was I on 20 mg of something for BP?") is True
    assert query_wants_excerpt("Did I take 100 mcg of vitamin?") is True


def test_query_unrelated_does_not_match_med() -> None:
    assert query_wants_excerpt("What did I do today?") is False
    assert query_wants_excerpt("Who attended the meeting?") is False


# ---------------------------------------------------------------------------
# find_med_excerpt
# ---------------------------------------------------------------------------


def test_med_excerpt_started_drug_with_dose() -> None:
    content = "Started Lisinopril 10 mg PO daily for stage-1 hypertension. Office BP today 142/91.\n"
    out = find_med_excerpt(content, max_chars=200)
    assert out is not None
    assert "Lisinopril" in out
    assert "10 mg" in out


def test_med_excerpt_discontinued_drug() -> None:
    content = "Discontinued Lisinopril 20 mg today. Patient reported persistent dry cough x 6 weeks.\n"
    out = find_med_excerpt(content, max_chars=300)
    assert out is not None
    assert "Lisinopril" in out
    assert "20 mg" in out


def test_med_excerpt_allergy_documented() -> None:
    content = (
        "Allergy documented: Penicillin — moderate reaction within 2 hours of amoxicillin, confirmed 2023-08-01.\n"
    )
    out = find_med_excerpt(content, max_chars=300)
    assert out is not None
    assert "Penicillin" in out
    assert "Allergy" in out


def test_med_excerpt_two_word_drug_name() -> None:
    content = "Started Potassium Chloride 20 mEq PO daily supplementation due to hypokalemia.\n"
    out = find_med_excerpt(content, max_chars=300)
    assert out is not None
    assert "Potassium Chloride" in out
    assert "20 mEq" in out


def test_med_excerpt_dose_change_increase() -> None:
    content = "Increased Lisinopril from 10 mg to 20 mg PO daily. Office BP 138/86 still above goal.\n"
    out = find_med_excerpt(content, max_chars=300)
    assert out is not None
    assert "10 mg" in out
    assert "20 mg" in out


def test_med_excerpt_returns_none_for_non_med_content() -> None:
    content = "# Project notes\nDiscussed timeline. Vendor email pending.\n"
    assert find_med_excerpt(content, max_chars=200) is None


def test_med_excerpt_returns_none_for_empty() -> None:
    assert find_med_excerpt("", max_chars=200) is None


def test_med_excerpt_includes_heading_anchor() -> None:
    content = "## Medications\nStarted Furosemide 20 mg PO daily.\n"
    out = find_med_excerpt(content, max_chars=300)
    assert out is not None
    assert "Medications" in out
    assert "Furosemide" in out


def test_med_excerpt_respects_max_chars_cap() -> None:
    long_tail = "x" * 500
    content = f"Started Lisinopril 10 mg PO daily for stage-1 hypertension {long_tail}.\n"
    out = find_med_excerpt(content, max_chars=80)
    assert out is not None
    assert len(out) <= 80
    assert "Lisinopril" in out  # drug still visible
