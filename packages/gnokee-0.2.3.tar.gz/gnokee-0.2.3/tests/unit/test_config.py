"""tests/unit/test_config.py — Settings env-binding tests."""

from __future__ import annotations

import pytest

from gnokee.config import Settings, utc_now


def test_settings_loads_pg_dsn(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GNOKEE_PG_DSN", "postgresql://u:p@h:5432/d")
    monkeypatch.setenv("GNOKEE_NEO4J_URI", "bolt://x:7687")
    monkeypatch.setenv("GNOKEE_NEO4J_PASSWORD", "secret")
    monkeypatch.setenv("GNOKEE_TEI_URL", "http://tei")
    s = Settings(_env_file=None)  # type: ignore[call-arg]
    assert s.pg_dsn == "postgresql://u:p@h:5432/d"
    assert s.neo4j_uri == "bolt://x:7687"
    assert s.tei_url == "http://tei"


def test_settings_defaults(monkeypatch: pytest.MonkeyPatch) -> None:
    # Wipe any GNOKEE_* leak from a parent .env so spec defaults are observed.
    for var in [
        "GNOKEE_EMBED_MODEL",
        "GNOKEE_LLM_MODEL",
        "GNOKEE_TENANT_DEFAULT",
        "GNOKEE_MCP_HTTP",
    ]:
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("GNOKEE_PG_DSN", "postgresql://u:p@h:5432/d")
    monkeypatch.setenv("GNOKEE_NEO4J_URI", "bolt://x:7687")
    monkeypatch.setenv("GNOKEE_NEO4J_PASSWORD", "secret")
    monkeypatch.setenv("GNOKEE_TEI_URL", "http://tei")
    s = Settings(_env_file=None)  # type: ignore[call-arg]
    assert s.embed_model == "bge-m3"
    assert s.llm_model == "gpt-4o-mini"
    assert s.tenant_default == "default"
    assert s.mcp_http is False


def test_settings_dsn_assembled_from_parts(monkeypatch: pytest.MonkeyPatch) -> None:
    """When `GNOKEE_PG_DSN` is unset, Settings should build it from parts."""
    for var in [
        "GNOKEE_PG_DSN",
        "GNOKEE_TEI_URL",
    ]:
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("GNOKEE_PG_USER", "u")
    monkeypatch.setenv("GNOKEE_PG_PASSWORD", "p")
    monkeypatch.setenv("GNOKEE_PG_DB", "d")
    monkeypatch.setenv("GNOKEE_PG_PORT", "5555")
    monkeypatch.setenv("GNOKEE_PG_HOST", "h")
    monkeypatch.setenv("GNOKEE_TEI_PORT", "8090")
    s = Settings(_env_file=None)  # type: ignore[call-arg]
    assert s.pg_dsn == "postgresql://u:p@h:5555/d"
    assert s.tei_url == "http://localhost:8090"


def test_utc_now_is_aware() -> None:
    n = utc_now()
    assert n.tzinfo is not None
    assert n.utcoffset() is not None
