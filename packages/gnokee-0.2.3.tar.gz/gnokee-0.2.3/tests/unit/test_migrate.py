"""tests/unit/test_migrate.py — Migration discovery + ordering."""

from __future__ import annotations

from pathlib import Path

from gnokee.storage.migrate import discover_migrations


def test_discover_migrations_returns_sorted_files() -> None:
    here = Path(__file__).parent.parent.parent / "src" / "gnokee" / "storage" / "migrations"
    migrations = discover_migrations(here)
    assert len(migrations) == 8
    names = [m.name for m in migrations]
    assert names == [
        "0001_episode_metadata.sql",
        "0002_content_embedding.sql",
        "0003_fact_contradiction.sql",
        "0004_index_pinning.sql",
        "0005_episode_our_id.sql",
        "0006_lab_record.sql",
        "0007_med_record.sql",
        "0008_supersession_partial_indexes.sql",
    ]


def test_discover_migrations_ignores_non_sql_files(tmp_path: Path) -> None:
    (tmp_path / "0001_first.sql").write_text("-- ok")
    (tmp_path / "README.md").write_text("# ignore me")
    (tmp_path / ".hidden").write_text("ignore me too")
    migrations = discover_migrations(tmp_path)
    assert [m.name for m in migrations] == ["0001_first.sql"]


def test_discover_migrations_orders_lexicographically(tmp_path: Path) -> None:
    (tmp_path / "0010_tenth.sql").write_text("-- 10")
    (tmp_path / "0002_second.sql").write_text("-- 2")
    (tmp_path / "0001_first.sql").write_text("-- 1")
    migrations = discover_migrations(tmp_path)
    assert [m.name for m in migrations] == [
        "0001_first.sql",
        "0002_second.sql",
        "0010_tenth.sql",
    ]
