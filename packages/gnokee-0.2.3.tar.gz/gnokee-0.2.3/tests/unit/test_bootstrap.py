"""tests/unit/test_bootstrap.py — Bootstrap pre-flight validation."""

from __future__ import annotations

import pytest

from gnokee.bootstrap import _require_llm_credentials
from gnokee.config import Settings
from gnokee.errors import ValidationError


def _make_settings(monkeypatch: pytest.MonkeyPatch, **overrides: str) -> Settings:
    """Return a Settings instance with deterministic env."""
    for var in [
        "GNOKEE_OPENAI_API_KEY",
        "GNOKEE_LLM_API_KEY",
        "GNOKEE_OPENAI_BASE_URL",
        "GNOKEE_LLM_BASE_URL",
        "GNOKEE_PG_DSN",
        "GNOKEE_TEI_URL",
        "GNOKEE_EMBED_BASE_URL",
    ]:
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv("GNOKEE_PG_DSN", "postgresql://u:p@h:5432/d")
    monkeypatch.setenv("GNOKEE_TEI_URL", "http://tei")
    for k, v in overrides.items():
        monkeypatch.setenv(k, v)
    return Settings(_env_file=None)  # type: ignore[call-arg]


def test_refuse_boot_when_openai_cloud_with_empty_key(monkeypatch: pytest.MonkeyPatch) -> None:
    s = _make_settings(monkeypatch, GNOKEE_OPENAI_BASE_URL="https://api.openai.com/v1")
    with pytest.raises(ValidationError, match="GNOKEE_OPENAI_API_KEY"):
        _require_llm_credentials(s)


def test_refuse_boot_with_default_base_url_and_empty_key(monkeypatch: pytest.MonkeyPatch) -> None:
    """Default `openai_base_url` is api.openai.com/v1; empty key must fail."""
    s = _make_settings(monkeypatch)
    assert s.openai_base_url.endswith("api.openai.com/v1")
    assert s.openai_api_key == ""
    with pytest.raises(ValidationError):
        _require_llm_credentials(s)


def test_allow_self_hosted_endpoint_with_empty_key(monkeypatch: pytest.MonkeyPatch) -> None:
    """Self-hosted (litellm / ollama / vllm) ships without a key — fine."""
    s = _make_settings(
        monkeypatch,
        GNOKEE_OPENAI_BASE_URL="http://localhost:11434/v1",
    )
    _require_llm_credentials(s)  # does not raise


def test_allow_openai_cloud_with_key(monkeypatch: pytest.MonkeyPatch) -> None:
    s = _make_settings(
        monkeypatch,
        GNOKEE_OPENAI_BASE_URL="https://api.openai.com/v1",
        GNOKEE_OPENAI_API_KEY="sk-test-real-key",
    )
    _require_llm_credentials(s)  # does not raise


def test_refuse_boot_handles_trailing_slash(monkeypatch: pytest.MonkeyPatch) -> None:
    s = _make_settings(monkeypatch, GNOKEE_OPENAI_BASE_URL="https://api.openai.com/v1/")
    with pytest.raises(ValidationError):
        _require_llm_credentials(s)
