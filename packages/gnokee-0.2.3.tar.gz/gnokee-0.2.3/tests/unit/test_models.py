"""tests/unit/test_models.py — Pydantic v0.1 contract tests."""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import UUID, uuid4

import pytest
from pydantic import ValidationError as PydanticValidationError

from gnokee.models import (
    ContradictionRef,
    EpisodeIn,
    FactProvenance,
    FactStatement,
    IngestReceipt,
    RecallResponse,
)


def _utc(year: int = 2026) -> datetime:
    return datetime(year, 1, 1, 0, 0, 0, tzinfo=timezone.utc)


def test_episode_in_minimal() -> None:
    e = EpisodeIn(tenant_id="t", content="hello", valid_at=_utc())
    assert e.tenant_id == "t"
    assert e.sensitive == "private"


def test_episode_in_rejects_naive_datetime() -> None:
    with pytest.raises(PydanticValidationError):
        EpisodeIn(tenant_id="t", content="x", valid_at=datetime(2026, 1, 1))


def test_episode_in_rejects_empty_tenant() -> None:
    with pytest.raises(PydanticValidationError):
        EpisodeIn(tenant_id="", content="x", valid_at=_utc())


def test_episode_in_rejects_extra_fields() -> None:
    with pytest.raises(PydanticValidationError):
        EpisodeIn(tenant_id="t", content="x", valid_at=_utc(), bogus=1)  # type: ignore[call-arg]


def test_episode_in_our_id_defaults_none() -> None:
    e = EpisodeIn(tenant_id="t", content="x", valid_at=_utc())
    assert e.our_id is None


def test_episode_in_accepts_our_id() -> None:
    e = EpisodeIn(tenant_id="t", content="x", valid_at=_utc(), our_id="email:abc@example.com:msg-1")
    assert e.our_id == "email:abc@example.com:msg-1"


def test_episode_in_rejects_empty_our_id() -> None:
    with pytest.raises(PydanticValidationError):
        EpisodeIn(tenant_id="t", content="x", valid_at=_utc(), our_id="")


def test_episode_in_rejects_whitespace_only_our_id() -> None:
    with pytest.raises(PydanticValidationError):
        EpisodeIn(tenant_id="t", content="x", valid_at=_utc(), our_id="   ")


def test_fact_statement_naive_rejected() -> None:
    with pytest.raises(PydanticValidationError):
        FactStatement(
            text="x",
            fact_uuid=uuid4(),
            episode_uuid=uuid4(),
            valid_at=datetime(2026, 1, 1),
            asserted_at=_utc(),
        )


def test_recall_response_defaults() -> None:
    r = RecallResponse()
    assert r.facts == []
    assert r.truncated is False
    assert r.candidate_count == 0


def test_ingest_receipt_basic() -> None:
    rec = IngestReceipt(episode_uuid=uuid4(), asserted_at=_utc())
    assert rec.created_fact_uuids == []
    assert rec.contradicts == []
    assert rec.replayed is False


def test_ingest_receipt_replayed_true() -> None:
    rec = IngestReceipt(episode_uuid=uuid4(), asserted_at=_utc(), replayed=True)
    assert rec.replayed is True


def test_contradiction_ref_frozen() -> None:
    c = ContradictionRef(
        fact_uuid=uuid4(),
        verdict="update",
        summary="x",
        valid_at=_utc(),
    )
    with pytest.raises(PydanticValidationError):
        c.summary = "y"  # type: ignore[misc]


def test_fact_provenance_shape() -> None:
    fp = FactProvenance(
        fact_uuid=uuid4(),
        fact_text="x",
        episode_uuid=uuid4(),
        episode_content="body",
        valid_at=_utc(),
        asserted_at=_utc(),
        sensitive="private",
    )
    assert fp.sensitive == "private"
    assert fp.valid_until is None


# ---------------------------------------------------------------------------
# EpisodeIn.corrects (v0.2.1 — supersession-aware ingest)
# ---------------------------------------------------------------------------


def test_episode_in_corrects_default_is_none() -> None:
    ep = EpisodeIn(tenant_id="t", content="hi", valid_at=_utc())
    assert ep.corrects is None


def test_episode_in_corrects_accepts_uuid() -> None:
    u = UUID("11111111-1111-1111-1111-111111111111")
    ep = EpisodeIn(tenant_id="t", content="hi", valid_at=_utc(), corrects=u)
    assert ep.corrects == u


def test_episode_in_corrects_rejects_non_uuid_string() -> None:
    with pytest.raises(PydanticValidationError):
        EpisodeIn(
            tenant_id="t",
            content="hi",
            valid_at=_utc(),
            corrects="not-a-uuid",  # type: ignore[arg-type]
        )


def test_episode_in_extra_forbid_unaffected_after_corrects() -> None:
    """Existing extra='forbid' still rejects unknown fields."""
    with pytest.raises(PydanticValidationError):
        EpisodeIn(  # type: ignore[call-arg]
            tenant_id="t",
            content="hi",
            valid_at=_utc(),
            unknown_field="x",
        )
