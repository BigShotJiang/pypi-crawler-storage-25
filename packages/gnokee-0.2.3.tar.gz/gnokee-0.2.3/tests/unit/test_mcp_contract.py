"""tests/unit/test_mcp_contract.py — M1 gate: MCP tool surface against in-memory stubs.

Exercises all three tools end-to-end against duck-typed pipelines.
Asserts response shape matches spec §6 + §5 (Q3 shape).
"""

from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace
from typing import Any
from uuid import UUID, uuid4

import pytest
from mcp.server.fastmcp.tools.tool_manager import ToolManager

from gnokee.lab_query import LabQueryResponse, LabRowOut
from gnokee.mcp import build_server
from gnokee.med_query import MedQueryResponse, MedRowOut
from gnokee.models import (
    ContradictionRef,
    FactProvenance,
    FactStatement,
    IngestReceipt,
    RecallResponse,
)


def _utc(year: int = 2026, month: int = 1, day: int = 1) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


class StubIngestPipeline:
    """Duck-types `gnokee.ingest.IngestPipeline` for contract tests."""

    def __init__(self) -> None:
        self.calls: list[Any] = []

    async def ingest(self, episode):  # type: ignore[no-untyped-def]
        self.calls.append(episode)
        ep_uuid = uuid4()
        fact_uuid = uuid4()
        return IngestReceipt(
            episode_uuid=ep_uuid,
            asserted_at=episode.asserted_at or _utc(2026, 5, 8),
            created_fact_uuids=[fact_uuid],
            contradicts=[
                ContradictionRef(
                    fact_uuid=uuid4(),
                    verdict="update",
                    summary="prior fact: lives in Berlin (2019)",
                    valid_at=_utc(2019, 6, 1),
                ),
            ],
        )


class StubRecallPipeline:
    """Duck-types `gnokee.retrieval.RecallPipeline`."""

    def __init__(self) -> None:
        self.fact_uuid = uuid4()
        self.episode_uuid = uuid4()

    async def recall(self, **kwargs: Any) -> RecallResponse:
        return RecallResponse(
            facts=[
                FactStatement(
                    text="Alice lives in Berlin.",
                    fact_uuid=self.fact_uuid,
                    episode_uuid=self.episode_uuid,
                    valid_at=_utc(2019, 6, 1),
                    asserted_at=_utc(2026, 5, 8),
                    contradicts=[],
                )
            ],
            truncated=False,
            candidate_count=1,
        )

    async def fact_provenance(self, *, tenant_id: str, fact_uuid: UUID) -> FactProvenance:
        return FactProvenance(
            fact_uuid=fact_uuid,
            fact_text="Alice lives in Berlin.",
            episode_uuid=self.episode_uuid,
            episode_content="Alice moved to Berlin in June 2019.",
            valid_at=_utc(2019, 6, 1),
            asserted_at=_utc(2026, 5, 8),
            sensitive="public",
        )


class StubLabQueryPipeline:
    """Duck-types `gnokee.lab_query.LabQueryPipeline`."""

    def __init__(self) -> None:
        self.episode_uuid = uuid4()

    async def query(self, **kwargs: Any) -> LabQueryResponse:
        from decimal import Decimal

        op = kwargs["op"]
        if op == "latest":
            row = LabRowOut(
                episode_uuid=self.episode_uuid,
                analyte=kwargs["analyte"],
                value_numeric=Decimal("4.2"),
                value_text=None,
                unit="mmol/L",
                ref_range_low=Decimal("3.5"),
                ref_range_high=Decimal("5.0"),
                abnormal_flag=None,
                valid_at=_utc(2024, 4, 1),
                asserted_at=_utc(2024, 4, 3),
            )
            return LabQueryResponse(op=op, rows=[row], count=1)
        if op == "history":
            return LabQueryResponse(op=op, rows=[], count=0)
        # min/max/avg/count
        return LabQueryResponse(op=op, scalar=Decimal("3.4"), count=1 if op == "count" else 0)


class StubMedQueryPipeline:
    """Duck-types `gnokee.med_query.MedQueryPipeline`."""

    def __init__(self) -> None:
        self.episode_uuid = uuid4()

    async def query(self, **kwargs: Any) -> MedQueryResponse:
        from decimal import Decimal

        op = kwargs["op"]
        if op == "active":
            row = MedRowOut(
                episode_uuid=self.episode_uuid,
                drug_name="Lisinopril",
                drug_class="ACE inhibitor",
                dose_value=Decimal("20"),
                dose_unit="mg",
                frequency="daily",
                route="PO",
                event_kind="increase",
                reason=None,
                valid_at=_utc(2024, 6, 15),
                asserted_at=_utc(2024, 6, 15),
            )
            return MedQueryResponse(op=op, rows=[row], count=1)
        return MedQueryResponse(op=op, rows=[], count=0)


def _stub_app() -> SimpleNamespace:
    return SimpleNamespace(
        ingest=StubIngestPipeline(),
        recall=StubRecallPipeline(),
        lab_query=StubLabQueryPipeline(),
        med_query=StubMedQueryPipeline(),
    )


def _tool_manager(server: Any) -> ToolManager:
    return server._tool_manager


@pytest.mark.asyncio
async def test_ingest_tool_round_trip() -> None:
    app = _stub_app()
    server = build_server(app)  # type: ignore[arg-type]
    tools = {t.name for t in _tool_manager(server).list_tools()}
    assert tools == {
        "gnokee_ingest_episode",
        "gnokee_recall",
        "gnokee_fact_provenance",
        "gnokee_lab_query",
        "gnokee_med_query",
    }

    result = await _tool_manager(server).call_tool(
        "gnokee_ingest_episode",
        arguments={
            "tenant_id": "t1",
            "content": "Alice moved to Berlin.",
            "valid_at": "2019-06-01T00:00:00Z",
            "asserted_at": None,
            "sensitive": "public",
        },
    )
    assert "episode_uuid" in result
    assert "asserted_at" in result
    assert isinstance(result["created_fact_uuids"], list)
    assert isinstance(result["contradicts"], list)
    assert result["contradicts"][0]["verdict"] == "update"


@pytest.mark.asyncio
async def test_recall_tool_round_trip() -> None:
    app = _stub_app()
    server = build_server(app)  # type: ignore[arg-type]
    result = await _tool_manager(server).call_tool(
        "gnokee_recall",
        arguments={
            "tenant_id": "t1",
            "text": "where does Alice live?",
            "as_of": None,
            "valid_at": None,
            "max_tokens": 200,
            "top_k": 10,
        },
    )
    assert result["truncated"] is False
    assert result["candidate_count"] == 1
    assert len(result["facts"]) == 1
    fact = result["facts"][0]
    assert fact["text"] == "Alice lives in Berlin."
    UUID(fact["fact_uuid"])
    UUID(fact["episode_uuid"])


@pytest.mark.asyncio
async def test_fact_provenance_tool_round_trip() -> None:
    app = _stub_app()
    server = build_server(app)  # type: ignore[arg-type]
    fact_uuid = str(uuid4())
    result = await _tool_manager(server).call_tool(
        "gnokee_fact_provenance",
        arguments={
            "tenant_id": "t1",
            "fact_uuid": fact_uuid,
        },
    )
    assert result["fact_uuid"] == fact_uuid
    assert result["episode_content"] == "Alice moved to Berlin in June 2019."
    assert result["sensitive"] == "public"


@pytest.mark.asyncio
async def test_lab_query_tool_round_trip() -> None:
    app = _stub_app()
    server = build_server(app)  # type: ignore[arg-type]
    result = await _tool_manager(server).call_tool(
        "gnokee_lab_query",
        arguments={
            "tenant_id": "t1",
            "analyte": "Potassium",
            "op": "latest",
            "as_of": None,
            "valid_at": None,
        },
    )
    assert result["op"] == "latest"
    assert result["count"] == 1
    assert len(result["rows"]) == 1
    row = result["rows"][0]
    assert row["analyte"] == "Potassium"
    assert row["value_numeric"] == "4.2"
    assert row["unit"] == "mmol/L"
    UUID(row["episode_uuid"])


@pytest.mark.asyncio
async def test_lab_query_aggregate_returns_scalar() -> None:
    app = _stub_app()
    server = build_server(app)  # type: ignore[arg-type]
    result = await _tool_manager(server).call_tool(
        "gnokee_lab_query",
        arguments={
            "tenant_id": "t1",
            "analyte": "Potassium",
            "op": "min",
        },
    )
    assert result["op"] == "min"
    assert result["scalar"] == "3.4"
    assert result["rows"] == []


@pytest.mark.asyncio
async def test_med_query_tool_round_trip() -> None:
    app = _stub_app()
    server = build_server(app)  # type: ignore[arg-type]
    result = await _tool_manager(server).call_tool(
        "gnokee_med_query",
        arguments={
            "tenant_id": "t1",
            "op": "active",
        },
    )
    assert result["op"] == "active"
    assert result["count"] == 1
    assert len(result["rows"]) == 1
    row = result["rows"][0]
    assert row["drug_name"] == "Lisinopril"
    assert row["dose_value"] == "20"
    assert row["dose_unit"] == "mg"
    assert row["event_kind"] == "increase"


@pytest.mark.asyncio
async def test_ingest_tool_descriptions_present_for_listing() -> None:
    app = _stub_app()
    server = build_server(app)  # type: ignore[arg-type]
    tools = _tool_manager(server).list_tools()
    by_name = {t.name: t for t in tools}
    for name in (
        "gnokee_ingest_episode",
        "gnokee_recall",
        "gnokee_fact_provenance",
        "gnokee_lab_query",
        "gnokee_med_query",
    ):
        assert by_name[name].description, f"{name} missing description"
        assert len(by_name[name].description) > 80
