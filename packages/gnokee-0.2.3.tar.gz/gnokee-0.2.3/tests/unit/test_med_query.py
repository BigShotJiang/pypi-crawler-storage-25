"""tests/unit/test_med_query.py — MedQueryPipeline orchestrator (ADR-0010)."""

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import Any
from uuid import uuid4

import pytest

from gnokee.errors import ValidationError
from gnokee.med_query import MedQueryPipeline, med_query
from gnokee.storage.med import MedRecordRow


def _utc(year: int = 2024, month: int = 1, day: int = 1) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


def _row(drug: str = "Lisinopril", kind: str = "start") -> MedRecordRow:
    return MedRecordRow(
        tenant_id="t1",
        episode_uuid=uuid4(),
        drug_name=drug,
        event_kind=kind,
        valid_at=_utc(2024, 2, 1),
        asserted_at=_utc(2024, 2, 1),
        dose_value=Decimal("10"),
        dose_unit="mg",
        frequency="daily",
        route="PO",
    )


class StubMedStore:
    def __init__(self) -> None:
        self.last_call: dict[str, Any] = {}

    async def active(self, **kwargs: Any) -> list[MedRecordRow]:
        self.last_call = {"method": "active", **kwargs}
        return [_row("Lisinopril", "start"), _row("Furosemide", "start")]

    async def history(self, **kwargs: Any) -> list[MedRecordRow]:
        self.last_call = {"method": "history", **kwargs}
        return [_row(kwargs["drug_name"], "start")]

    async def by_event_kind(self, **kwargs: Any) -> list[MedRecordRow]:
        self.last_call = {"method": "by_event_kind", **kwargs}
        return [_row("Penicillin", kwargs["event_kind"])]


@pytest.mark.asyncio
async def test_active_returns_one_per_drug() -> None:
    store = StubMedStore()
    pipeline = MedQueryPipeline(med=store)  # type: ignore[arg-type]
    response = await med_query(pipeline=pipeline, tenant_id="t1", op="active")
    assert response.op == "active"
    assert response.count == 2
    drugs = {r.drug_name for r in response.rows}
    assert drugs == {"Lisinopril", "Furosemide"}


@pytest.mark.asyncio
async def test_history_requires_drug_name() -> None:
    store = StubMedStore()
    pipeline = MedQueryPipeline(med=store)  # type: ignore[arg-type]
    with pytest.raises(ValidationError):
        await med_query(pipeline=pipeline, tenant_id="t1", op="history")


@pytest.mark.asyncio
async def test_history_passes_drug_and_range() -> None:
    store = StubMedStore()
    pipeline = MedQueryPipeline(med=store)  # type: ignore[arg-type]
    since = _utc(2024, 1, 1)
    until = _utc(2025, 1, 1)
    response = await med_query(
        pipeline=pipeline,
        tenant_id="t1",
        op="history",
        drug_name="Lisinopril",
        since=since,
        until=until,
    )
    assert response.op == "history"
    assert response.count == 1
    assert store.last_call["drug_name"] == "Lisinopril"
    assert store.last_call["since"] == since
    assert store.last_call["until"] == until


@pytest.mark.asyncio
async def test_allergies_op_maps_to_event_kind() -> None:
    store = StubMedStore()
    pipeline = MedQueryPipeline(med=store)  # type: ignore[arg-type]
    response = await med_query(pipeline=pipeline, tenant_id="t1", op="allergies")
    assert response.op == "allergies"
    assert response.count == 1
    assert store.last_call["event_kind"] == "allergy"


@pytest.mark.asyncio
async def test_switches_op_maps_to_event_kind() -> None:
    store = StubMedStore()
    pipeline = MedQueryPipeline(med=store)  # type: ignore[arg-type]
    response = await med_query(pipeline=pipeline, tenant_id="t1", op="switches")
    assert response.op == "switches"
    assert store.last_call["event_kind"] == "switch"


@pytest.mark.asyncio
async def test_rejects_empty_tenant() -> None:
    store = StubMedStore()
    pipeline = MedQueryPipeline(med=store)  # type: ignore[arg-type]
    with pytest.raises(ValidationError):
        await med_query(pipeline=pipeline, tenant_id="", op="active")


@pytest.mark.asyncio
async def test_rejects_inverted_range() -> None:
    store = StubMedStore()
    pipeline = MedQueryPipeline(med=store)  # type: ignore[arg-type]
    with pytest.raises(ValidationError):
        await med_query(
            pipeline=pipeline,
            tenant_id="t1",
            op="history",
            drug_name="Lisinopril",
            since=_utc(2025, 1, 1),
            until=_utc(2024, 1, 1),
        )


@pytest.mark.asyncio
async def test_rejects_unknown_op() -> None:
    store = StubMedStore()
    pipeline = MedQueryPipeline(med=store)  # type: ignore[arg-type]
    with pytest.raises(ValidationError):
        await med_query(pipeline=pipeline, tenant_id="t1", op="nope")  # type: ignore[arg-type]
