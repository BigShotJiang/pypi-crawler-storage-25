"""tests/unit/test_errors.py — Exception hierarchy tests."""

from __future__ import annotations

from uuid import UUID

import pytest

from gnokee.errors import (
    CorrectsAxisInversionError,
    CorrectsChainError,
    CorrectsCrossTenantError,
    CorrectsError,
    EmbeddingsUnavailable,
    EpisodeNotFoundError,
    GnokeeError,
    GraphStoreError,
    LLMUnavailable,
    NotImplementedYet,
    ValidationError,
    VectorStoreError,
)


@pytest.mark.parametrize(
    "exc_cls",
    [
        ValidationError,
        EmbeddingsUnavailable,
        GraphStoreError,
        VectorStoreError,
        LLMUnavailable,
        NotImplementedYet,
    ],
)
def test_subclass_of_gnokee_error(exc_cls: type[Exception]) -> None:
    assert issubclass(exc_cls, GnokeeError)


def test_exceptions_carry_message() -> None:
    e = ValidationError("bad input")
    assert str(e) == "bad input"


def test_corrects_error_subclasses_vector_store_error() -> None:
    assert issubclass(CorrectsError, VectorStoreError)


def test_episode_not_found_carries_uuid_attribute() -> None:
    u = UUID("00000000-0000-0000-0000-000000000001")
    exc = EpisodeNotFoundError(u)
    assert exc.episode_uuid == u
    assert str(u) in str(exc)


@pytest.mark.parametrize(
    "exc_cls",
    [
        EpisodeNotFoundError,
        CorrectsCrossTenantError,
        CorrectsAxisInversionError,
        CorrectsChainError,
    ],
)
def test_each_corrects_subclass_inherits_corrects_error(
    exc_cls: type[Exception],
) -> None:
    assert issubclass(exc_cls, CorrectsError)
    assert issubclass(exc_cls, VectorStoreError)


def test_axis_and_chain_are_distinct_classes() -> None:
    """Cycle/depth must not be conflated with tx-time inversion."""
    assert CorrectsChainError is not CorrectsAxisInversionError
    assert not issubclass(CorrectsChainError, CorrectsAxisInversionError)
    assert not issubclass(CorrectsAxisInversionError, CorrectsChainError)
