"""tests/integration/test_ingest_recall.py — M2/M3 gate: ingest + recall round-trip.

Requires real Graphiti → real LLM (entity extraction). Gated on
GNOKEE_OPENAI_API_KEY presence so contributors can run unit tests
without an API key.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone

import pytest

from gnokee.bootstrap import App
from gnokee.ingest import ingest_episode
from gnokee.retrieval import fact_provenance, recall

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not (os.environ.get("GNOKEE_OPENAI_API_KEY") or os.environ.get("GNOKEE_LLM_API_KEY")),
        reason="needs OpenAI-compatible LLM credentials for Graphiti entity extraction",
    ),
]


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


@pytest.mark.asyncio
async def test_ingest_then_recall_returns_facts(app: App, fresh_tenant: str) -> None:
    receipt = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Alice moved to Berlin in June 2019 to start a new job at Stripe.",
        valid_at=_utc(2019, 6, 1),
        sensitive="public",
    )
    assert receipt.episode_uuid
    assert receipt.asserted_at.tzinfo is not None
    # Graphiti extraction should produce ≥1 EntityEdge.
    assert len(receipt.created_fact_uuids) >= 1

    response = await recall(
        pipeline=app.recall,
        tenant_id=fresh_tenant,
        text="where did Alice move?",
    )
    assert response.candidate_count >= 1
    assert len(response.facts) >= 1
    fact = response.facts[0]
    assert fact.fact_uuid in receipt.created_fact_uuids
    assert fact.episode_uuid == receipt.episode_uuid


@pytest.mark.asyncio
async def test_recall_respects_world_time(app: App, fresh_tenant: str) -> None:
    """`valid_at` lower bound: query before the episode's valid_at returns nothing."""
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Alice started taking metoprolol 25mg BID.",
        valid_at=_utc(2024, 6, 1),
        sensitive="clinical",
    )
    too_early = await recall(
        pipeline=app.recall,
        tenant_id=fresh_tenant,
        text="metoprolol",
        valid_at=_utc(2023, 1, 1),
    )
    assert too_early.candidate_count == 0

    visible = await recall(
        pipeline=app.recall,
        tenant_id=fresh_tenant,
        text="metoprolol",
        valid_at=_utc(2025, 1, 1),
    )
    assert visible.candidate_count >= 1


@pytest.mark.asyncio
async def test_tenant_isolation(app: App) -> None:
    tenant_a = "iso-a"
    tenant_b = "iso-b"
    # Clean any prior runs.
    async with app.pool.acquire() as conn:
        await conn.execute(
            "DELETE FROM episode_metadata WHERE tenant_id IN ($1, $2)",
            tenant_a,
            tenant_b,
        )

    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=tenant_a,
        content="Customer Bob's preferred database is Postgres.",
        valid_at=_utc(2024, 1, 1),
        sensitive="private",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=tenant_b,
        content="Customer Carol's preferred database is DuckDB.",
        valid_at=_utc(2024, 1, 1),
        sensitive="private",
    )

    a_response = await recall(
        pipeline=app.recall,
        tenant_id=tenant_a,
        text="preferred database",
    )
    b_response = await recall(
        pipeline=app.recall,
        tenant_id=tenant_b,
        text="preferred database",
    )
    a_text = " ".join(f.text.lower() for f in a_response.facts)
    b_text = " ".join(f.text.lower() for f in b_response.facts)
    assert "duckdb" not in a_text, f"tenant A leak: {a_text}"
    assert "postgres" not in b_text, f"tenant B leak: {b_text}"


@pytest.mark.asyncio
async def test_fact_provenance_returns_episode_body(app: App, fresh_tenant: str) -> None:
    """Lazy-fetch full episode body via fact_uuid handle.

    Re-tries up to N ingests so we get at least one EntityEdge — Graphiti's
    extractor occasionally drops edges with unresolved source entities.
    """
    body_template = "Alice runs ETL pipelines on Postgres for project Atlas since 2023."
    receipt = None
    for _n in range(3):
        receipt = await ingest_episode(
            pipeline=app.ingest,
            tenant_id=fresh_tenant,
            content=body_template,
            valid_at=_utc(2023, 9, 1),
            sensitive="public",
        )
        if receipt.created_fact_uuids:
            break
    assert receipt is not None
    if not receipt.created_fact_uuids:
        pytest.skip("Graphiti extractor produced no edges across 3 attempts; LLM-driven flake")
    fact_uuid = receipt.created_fact_uuids[0]
    prov = await fact_provenance(
        pipeline=app.recall,
        tenant_id=fresh_tenant,
        fact_uuid=fact_uuid,
    )
    assert prov is not None
    assert prov.episode_uuid == receipt.episode_uuid
    assert "postgres" in prov.episode_content.lower()
    assert prov.sensitive == "public"
