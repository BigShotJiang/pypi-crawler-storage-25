"""tests/integration/test_supersession_partial_indexes.py — issue #17.

Verifies the partial indexes from migration `0008_supersession_partial_indexes.sql`
exist after migrate-up and that the supersede_matching UPDATE plan can
use them when the planner is otherwise indifferent (forced via
`SET enable_seqscan = off`).
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from uuid import uuid4

import asyncpg
import pytest

from gnokee.storage.lab import LabRecordRow, LabStore
from gnokee.storage.med import MedRecordRow, MedStore
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore

pytestmark = [pytest.mark.integration, pytest.mark.asyncio]


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


async def test_lab_record_open_partial_index_exists(pg_pool: asyncpg.Pool) -> None:
    async with pg_pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT indexname, indexdef
              FROM pg_indexes
             WHERE schemaname = 'public'
               AND tablename = 'lab_record'
               AND indexname = 'lab_record_open_idx'
            """,
        )
    assert row is not None, "migration 0008 did not create lab_record_open_idx"
    indexdef = row["indexdef"].lower()
    assert "where (asserted_until is null)" in indexdef
    assert "tenant_id" in indexdef
    assert "episode_uuid" in indexdef
    assert "analyte" in indexdef
    assert "valid_at" in indexdef


async def test_med_record_open_partial_index_exists(pg_pool: asyncpg.Pool) -> None:
    async with pg_pool.acquire() as conn:
        row = await conn.fetchrow(
            """
            SELECT indexname, indexdef
              FROM pg_indexes
             WHERE schemaname = 'public'
               AND tablename = 'med_record'
               AND indexname = 'med_record_open_idx'
            """,
        )
    assert row is not None, "migration 0008 did not create med_record_open_idx"
    indexdef = row["indexdef"].lower()
    assert "where (asserted_until is null)" in indexdef
    assert "tenant_id" in indexdef
    assert "episode_uuid" in indexdef
    assert "drug_name" in indexdef
    assert "event_kind" in indexdef
    assert "valid_at" in indexdef


async def _seed_episode(
    *,
    pg_pool: asyncpg.Pool,
    tenant_id: str,
    asserted_at: datetime,
) -> EpisodeMetadataRow:
    row = EpisodeMetadataRow(
        tenant_id=tenant_id,
        episode_uuid=uuid4(),
        valid_at=_utc(2024, 4, 10),
        valid_until=None,
        asserted_at=asserted_at,
        asserted_until=None,
        superseded_by=None,
        sensitive="clinical",
        language="en",
        our_id=None,
    )
    md = MetadataStore(pg_pool)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant_id)
        await md.write(conn=conn, row=row)
    return row


async def test_lab_supersede_plan_uses_partial_index(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    """Plan uses `lab_record_open_idx` once competing indexes are
    suppressed. On tiny test fixtures the planner otherwise picks
    `idx_lab_record_asserted_at` purely on cardinality; this test
    proves the partial index is correctly defined and usable for the
    supersede UPDATE shape (the production perf win materialises as
    the closed:open ratio grows). Competitor indexes are dropped
    inside the test transaction and rolled back, so the schema is
    untouched after the test.
    """
    tenant = fresh_tenant
    ep = await _seed_episode(pg_pool=pg_pool, tenant_id=tenant, asserted_at=_utc(2024, 4, 12))
    lab = LabStore(pg_pool)
    rows = [
        LabRecordRow(
            tenant_id=tenant,
            episode_uuid=ep.episode_uuid,
            analyte=name,
            value_numeric=Decimal("4.0"),
            value_text=None,
            unit="mmol/L",
            ref_range_low=Decimal("3.5"),
            ref_range_high=Decimal("5.0"),
            abnormal_flag=None,
            valid_at=_utc(2024, 4, 10),
            asserted_at=_utc(2024, 4, 12),
        )
        for name in ("Potassium", "Magnesium", "Sodium")
    ]
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        async with conn.transaction():
            await lab.write_rows(conn=conn, rows=rows)

    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        tx = conn.transaction()
        await tx.start()
        try:
            await conn.execute("SET LOCAL enable_seqscan = off")
            await conn.execute("DROP INDEX IF EXISTS idx_lab_record_asserted_at")
            await conn.execute("DROP INDEX IF EXISTS idx_lab_record_tenant_analyte_valid")
            await conn.execute("DROP INDEX IF EXISTS idx_lab_record_tenant_analyte_value")
            await conn.execute("ALTER TABLE lab_record DROP CONSTRAINT lab_record_pkey")
            plan_rows = await conn.fetch(
                """
                EXPLAIN
                UPDATE lab_record
                   SET asserted_until = $5
                  FROM unnest($3::text[], $4::timestamptz[]) AS k(analyte, valid_at)
                 WHERE lab_record.tenant_id      = $1
                   AND lab_record.episode_uuid   = $2
                   AND lab_record.asserted_until IS NULL
                   AND (lab_record.valid_until IS NULL
                        OR lab_record.valid_until > $5)
                   AND lab_record.analyte        = k.analyte
                   AND lab_record.valid_at       = k.valid_at
                """,
                tenant,
                ep.episode_uuid,
                ["Potassium"],
                [_utc(2024, 4, 10)],
                _utc(2024, 4, 25),
            )
        finally:
            await tx.rollback()
    plan_text = "\n".join(r[0] for r in plan_rows).lower()
    assert "lab_record_open_idx" in plan_text, f"partial index not used; plan was:\n{plan_text}"


async def test_med_supersede_plan_uses_partial_index(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    tenant = fresh_tenant
    ep = await _seed_episode(pg_pool=pg_pool, tenant_id=tenant, asserted_at=_utc(2024, 6, 1))
    med = MedStore(pg_pool)
    rows = [
        MedRecordRow(
            tenant_id=tenant,
            episode_uuid=ep.episode_uuid,
            drug_name="Lisinopril",
            rxnorm_code=None,
            drug_class="ACE inhibitor",
            dose_value=Decimal("10"),
            dose_unit="mg",
            frequency="daily",
            route="PO",
            event_kind="start",
            reason=None,
            valid_at=_utc(2024, 6, 1),
            asserted_at=_utc(2024, 6, 1),
        ),
    ]
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        async with conn.transaction():
            await med.write_rows(conn=conn, rows=rows)

    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        tx = conn.transaction()
        await tx.start()
        try:
            await conn.execute("SET LOCAL enable_seqscan = off")
            await conn.execute("DROP INDEX IF EXISTS idx_med_record_asserted_at")
            await conn.execute("DROP INDEX IF EXISTS idx_med_record_tenant_drug_valid")
            await conn.execute("DROP INDEX IF EXISTS idx_med_record_tenant_class_valid")
            await conn.execute("DROP INDEX IF EXISTS idx_med_record_allergies")
            await conn.execute("ALTER TABLE med_record DROP CONSTRAINT med_record_pkey")
            plan_rows = await conn.fetch(
                """
                EXPLAIN
                UPDATE med_record
                   SET asserted_until = $6
                  FROM unnest($3::text[], $4::text[], $5::timestamptz[])
                       AS k(drug_name, event_kind, valid_at)
                 WHERE med_record.tenant_id      = $1
                   AND med_record.episode_uuid   = $2
                   AND med_record.asserted_until IS NULL
                   AND (med_record.valid_until IS NULL
                        OR med_record.valid_until > $6)
                   AND med_record.drug_name      = k.drug_name
                   AND med_record.event_kind     = k.event_kind
                   AND med_record.valid_at       = k.valid_at
                """,
                tenant,
                ep.episode_uuid,
                ["Lisinopril"],
                ["start"],
                [_utc(2024, 6, 1)],
                _utc(2024, 7, 1) + timedelta(0),
            )
        finally:
            await tx.rollback()
    plan_text = "\n".join(r[0] for r in plan_rows).lower()
    assert "med_record_open_idx" in plan_text, f"partial index not used; plan was:\n{plan_text}"
