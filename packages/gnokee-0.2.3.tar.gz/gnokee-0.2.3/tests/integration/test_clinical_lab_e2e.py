"""tests/integration/test_clinical_lab_e2e.py — v0.2 lab path against real Postgres.

Exercises the full ADR-0009 surface end-to-end:
  - ingest a markdown lab panel → `lab_parser` → `lab_record` rows
    written inside the Stage 6 txn alongside `episode_metadata` +
    `content_embedding`
  - `gnokee_lab_query` typed reads (latest / history / min / max /
    avg / count) honour both bi-temporal half-pairs and return the
    parsed numerics intact.

Distinct from the unit tests (`tests/unit/test_lab_query.py`,
`tests/unit/extract/test_lab_parser.py`), which run against stubs.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from decimal import Decimal

import pytest

from gnokee.bootstrap import App
from gnokee.ingest import ingest_episode
from gnokee.lab_query import lab_query

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not (os.environ.get("GNOKEE_OPENAI_API_KEY") or os.environ.get("GNOKEE_LLM_API_KEY")),
        reason="needs OpenAI-compatible LLM credentials for Graphiti entity extraction",
    ),
]


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 8, 0, 0, tzinfo=timezone.utc)


_PANEL_APRIL = """\
Lab panel — drawn 2024-04-10, reported 2024-04-12.

Basic Metabolic Panel:
- Sodium: 139 mmol/L (ref: 135-145)
- Potassium: 2.8 mmol/L (ref: 3.5-5.0) **LOW — critical**
- Creatinine: 1.0 mg/dL (ref: 0.6-1.2)
"""

_PANEL_MAY = """\
Lab panel — drawn 2024-05-15, reported 2024-05-17.

Basic Metabolic Panel:
- Sodium: 141 mmol/L (ref: 135-145)
- Potassium: 4.1 mmol/L (ref: 3.5-5.0)
- Creatinine: 0.9 mg/dL (ref: 0.6-1.2)
"""


@pytest.mark.asyncio
async def test_ingest_writes_lab_record_rows(app: App, fresh_tenant: str) -> None:
    receipt = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        sensitive="clinical",
    )
    assert receipt.episode_uuid

    async with app.pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT analyte, value_numeric, unit, abnormal_flag,
                   ref_range_low, ref_range_high
              FROM lab_record
             WHERE tenant_id = $1
             ORDER BY analyte
            """,
            fresh_tenant,
        )

    by_analyte = {r["analyte"]: r for r in rows}
    assert {"Sodium", "Potassium", "Creatinine"}.issubset(by_analyte.keys())
    k = by_analyte["Potassium"]
    assert k["value_numeric"] == Decimal("2.8")
    assert k["unit"] == "mmol/L"
    assert k["abnormal_flag"] == "C"
    assert k["ref_range_low"] == Decimal("3.5")
    assert k["ref_range_high"] == Decimal("5.0")


@pytest.mark.asyncio
async def test_lab_query_latest_returns_recent_visible_row(
    app: App,
    fresh_tenant: str,
) -> None:
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_MAY,
        valid_at=_utc(2024, 5, 15),
        sensitive="clinical",
    )

    response = await lab_query(
        pipeline=app.lab_query,
        tenant_id=fresh_tenant,
        analyte="Potassium",
        op="latest",
    )
    assert response.op == "latest"
    assert response.count == 1
    row = response.rows[0]
    assert row.value_numeric == Decimal("4.1")  # May supersedes April by valid_at
    assert row.unit == "mmol/L"


@pytest.mark.asyncio
async def test_lab_query_history_returns_ascending_range(
    app: App,
    fresh_tenant: str,
) -> None:
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_MAY,
        valid_at=_utc(2024, 5, 15),
        sensitive="clinical",
    )

    response = await lab_query(
        pipeline=app.lab_query,
        tenant_id=fresh_tenant,
        analyte="Potassium",
        op="history",
    )
    assert response.count == 2
    assert [r.value_numeric for r in response.rows] == [
        Decimal("2.8"),
        Decimal("4.1"),
    ]


@pytest.mark.asyncio
async def test_lab_query_aggregates(app: App, fresh_tenant: str) -> None:
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_MAY,
        valid_at=_utc(2024, 5, 15),
        sensitive="clinical",
    )

    minimum = await lab_query(
        pipeline=app.lab_query,
        tenant_id=fresh_tenant,
        analyte="Potassium",
        op="min",
    )
    maximum = await lab_query(
        pipeline=app.lab_query,
        tenant_id=fresh_tenant,
        analyte="Potassium",
        op="max",
    )
    count = await lab_query(
        pipeline=app.lab_query,
        tenant_id=fresh_tenant,
        analyte="Potassium",
        op="count",
    )

    assert minimum.scalar == Decimal("2.8")
    assert maximum.scalar == Decimal("4.1")
    assert count.count == 2


@pytest.mark.asyncio
async def test_lab_query_abnormal_returns_flagged_rows_only(
    app: App,
    fresh_tenant: str,
) -> None:
    # April panel has Potassium 2.8 LOW critical; May panel has all normals.
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_MAY,
        valid_at=_utc(2024, 5, 15),
        sensitive="clinical",
    )

    response = await lab_query(
        pipeline=app.lab_query,
        tenant_id=fresh_tenant,
        analyte=None,
        op="abnormal",
        since=_utc(2024, 1, 1),
        until=datetime(2025, 1, 1, 0, 0, 0, tzinfo=timezone.utc),
    )
    assert response.op == "abnormal"
    assert response.count >= 1
    assert all(r.abnormal_flag is not None for r in response.rows)
    flagged_potassium = [r for r in response.rows if r.analyte == "Potassium"]
    assert flagged_potassium, "Potassium 2.8 should surface as abnormal"
    assert flagged_potassium[0].value_numeric == Decimal("2.8")


@pytest.mark.asyncio
async def test_lab_query_abnormal_with_analyte_filter(
    app: App,
    fresh_tenant: str,
) -> None:
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        sensitive="clinical",
    )

    response = await lab_query(
        pipeline=app.lab_query,
        tenant_id=fresh_tenant,
        analyte="Sodium",
        op="abnormal",
    )
    # Sodium 139 mmol/L within range — no abnormal rows expected.
    assert response.count == 0


@pytest.mark.asyncio
async def test_lab_query_tenant_isolation(app: App, fresh_tenant: str) -> None:
    other_tenant = f"{fresh_tenant}-other"
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        sensitive="clinical",
    )
    response = await lab_query(
        pipeline=app.lab_query,
        tenant_id=other_tenant,
        analyte="Potassium",
        op="latest",
    )
    assert response.rows == []
