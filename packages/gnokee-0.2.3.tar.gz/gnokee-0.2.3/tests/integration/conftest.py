"""tests/integration/conftest.py — Shared integration fixtures.

Fixtures here assume `make up` has already run (or CI started compose).
They do NOT manage container lifecycle.
"""

from __future__ import annotations

import os
import uuid
from collections.abc import AsyncGenerator

import asyncpg
import httpx
import pytest
import pytest_asyncio
from neo4j import AsyncDriver, AsyncGraphDatabase

from gnokee.bootstrap import App, build_app, shutdown_app
from gnokee.config import Settings
from gnokee.storage.migrate import apply as apply_migrations


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    """Tag every test in tests/integration/ with the `integration` marker."""
    for item in items:
        if "tests/integration" in str(item.fspath):
            item.add_marker(pytest.mark.integration)


def _seed_env_defaults() -> None:
    os.environ.setdefault(
        "GNOKEE_PG_DSN",
        "postgresql://gnokee:gnokee@localhost:5432/gnokee",
    )
    os.environ.setdefault("GNOKEE_NEO4J_URI", "bolt://localhost:7687")
    os.environ.setdefault("GNOKEE_NEO4J_USER", "neo4j")
    os.environ.setdefault("GNOKEE_NEO4J_PASSWORD", "gnokee-dev-password")
    os.environ.setdefault("GNOKEE_TEI_URL", "http://localhost:8080")


@pytest.fixture(scope="session")
def settings() -> Settings:
    _seed_env_defaults()
    return Settings()  # type: ignore[call-arg]


@pytest_asyncio.fixture(scope="session")
async def pg_pool(settings: Settings) -> AsyncGenerator[asyncpg.Pool, None]:
    await apply_migrations(settings.pg_dsn)
    pool = await asyncpg.create_pool(settings.pg_dsn, min_size=1, max_size=4)
    assert pool is not None
    try:
        yield pool
    finally:
        await pool.close()


@pytest_asyncio.fixture(scope="session")
async def neo4j_driver(settings: Settings) -> AsyncGenerator[AsyncDriver, None]:
    driver = AsyncGraphDatabase.driver(
        settings.neo4j_uri,
        auth=(settings.neo4j_user, settings.neo4j_password),
    )
    try:
        yield driver
    finally:
        await driver.close()


@pytest.fixture(scope="session")
def tei_url(settings: Settings) -> str:
    return settings.tei_url


@pytest_asyncio.fixture
async def tei_client(tei_url: str) -> AsyncGenerator[httpx.AsyncClient, None]:
    async with httpx.AsyncClient(base_url=tei_url, timeout=120.0) as client:
        yield client


@pytest_asyncio.fixture
async def app(settings: Settings) -> AsyncGenerator[App, None]:
    instance = await build_app(settings, bootstrap_indices=True)
    try:
        yield instance
    finally:
        await shutdown_app(instance)


@pytest.fixture
def fresh_tenant() -> str:
    """One-off tenant id per test for isolation."""
    return f"t-{uuid.uuid4().hex[:8]}"
