"""tests/unit/test_med_supersede.py — MedStore.supersede_matching unit tests."""

from __future__ import annotations

import os
from collections.abc import AsyncGenerator
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from uuid import uuid4

import asyncpg
import pytest
import pytest_asyncio

from gnokee.storage.med import MedRecordRow, MedStore
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore
from gnokee.storage.migrate import apply as apply_migrations

pytestmark = pytest.mark.asyncio


@pytest_asyncio.fixture(scope="module")
async def pool() -> AsyncGenerator[asyncpg.Pool, None]:
    dsn = os.environ.get(
        "GNOKEE_PG_DSN",
        "postgresql://gnokee:gnokee@localhost:5432/gnokee",
    )
    await apply_migrations(dsn)
    p = await asyncpg.create_pool(dsn, min_size=1, max_size=2)
    assert p is not None
    try:
        yield p
    finally:
        await p.close()


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


@pytest_asyncio.fixture
async def fresh_tenant() -> str:
    return f"unit-med-supersede-{uuid4().hex[:12]}"


async def _seed_episode(
    *,
    pg_pool: asyncpg.Pool,
    tenant_id: str,
    asserted_at: datetime,
) -> EpisodeMetadataRow:
    row = EpisodeMetadataRow(
        tenant_id=tenant_id,
        episode_uuid=uuid4(),
        valid_at=_utc(2024, 6, 15),
        valid_until=None,
        asserted_at=asserted_at,
        asserted_until=None,
        superseded_by=None,
        sensitive="clinical",
        language="en",
        our_id=None,
    )
    md = MetadataStore(pg_pool)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant_id)
        await md.write(conn=conn, row=row)
    return row


async def test_supersede_matching_closes_named_drug_event(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    tenant = fresh_tenant
    asserted_a = _utc(2024, 6, 15)
    asserted_b = _utc(2024, 6, 20)
    ep = await _seed_episode(pg_pool=pg_pool, tenant_id=tenant, asserted_at=asserted_a)
    med = MedStore(pg_pool)
    rows = [
        MedRecordRow(
            tenant_id=tenant,
            episode_uuid=ep.episode_uuid,
            drug_name="Lisinopril",
            event_kind="start",
            valid_at=_utc(2024, 6, 15),
            asserted_at=asserted_a,
            dose_value=Decimal("10"),
            dose_unit="mg",
        ),
        MedRecordRow(
            tenant_id=tenant,
            episode_uuid=ep.episode_uuid,
            drug_name="Aspirin",
            event_kind="start",
            valid_at=_utc(2024, 6, 15),
            asserted_at=asserted_a,
            dose_value=Decimal("81"),
            dose_unit="mg",
        ),
    ]
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        async with conn.transaction():
            await med.write_rows(conn=conn, rows=rows)
        async with conn.transaction():
            updated = await med.supersede_matching(
                conn=conn,
                tenant_id=tenant,
                episode_uuid=ep.episode_uuid,
                keys=[("Lisinopril", "start", _utc(2024, 6, 15))],
                asserted_until=asserted_b,
            )
    assert updated == 1

    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        records = await conn.fetch(
            "SELECT drug_name, asserted_until FROM med_record WHERE tenant_id = $1 ORDER BY drug_name",
            tenant,
        )
    state = {r["drug_name"]: r["asserted_until"] for r in records}
    assert state["Lisinopril"] == asserted_b
    assert state["Aspirin"] is None


async def test_supersede_matching_empty_keys_returns_zero(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    tenant = fresh_tenant
    asserted = _utc(2024, 6, 15)
    ep = await _seed_episode(pg_pool=pg_pool, tenant_id=tenant, asserted_at=asserted)
    med = MedStore(pg_pool)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        async with conn.transaction():
            updated = await med.supersede_matching(
                conn=conn,
                tenant_id=tenant,
                episode_uuid=ep.episode_uuid,
                keys=[],
                asserted_until=asserted + timedelta(days=1),
            )
    assert updated == 0
