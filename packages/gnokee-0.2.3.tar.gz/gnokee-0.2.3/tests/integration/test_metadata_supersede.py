"""tests/unit/test_metadata_supersede.py — MetadataStore.supersede chain-walk + validation."""

from __future__ import annotations

import os
from collections.abc import AsyncGenerator
from datetime import datetime, timedelta, timezone
from uuid import UUID, uuid4

import asyncpg
import pytest
import pytest_asyncio

from gnokee.errors import (
    CorrectsAxisInversionError,
    CorrectsChainError,
    CorrectsCrossTenantError,
    EpisodeNotFoundError,
)
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore
from gnokee.storage.migrate import apply as apply_migrations

pytestmark = pytest.mark.asyncio


@pytest_asyncio.fixture(scope="module")
async def pool() -> AsyncGenerator[asyncpg.Pool, None]:
    dsn = os.environ.get(
        "GNOKEE_PG_DSN",
        "postgresql://gnokee:gnokee@localhost:5432/gnokee",
    )
    await apply_migrations(dsn)
    p = await asyncpg.create_pool(dsn, min_size=1, max_size=2)
    assert p is not None
    try:
        yield p
    finally:
        await p.close()


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


@pytest_asyncio.fixture
async def fresh_tenant() -> str:
    return f"unit-metadata-supersede-{uuid4().hex[:12]}"


async def _insert(
    pg_pool: asyncpg.Pool,
    *,
    tenant_id: str,
    asserted_at: datetime,
) -> UUID:
    row = EpisodeMetadataRow(
        tenant_id=tenant_id,
        episode_uuid=uuid4(),
        valid_at=_utc(2024, 4, 10),
        valid_until=None,
        asserted_at=asserted_at,
        asserted_until=None,
        superseded_by=None,
        sensitive="clinical",
        language="en",
        our_id=None,
    )
    md = MetadataStore(pg_pool)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant_id)
        await md.write(conn=conn, row=row)
    return row.episode_uuid


async def test_episode_not_found(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    md = MetadataStore(pg_pool)
    bogus = uuid4()
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", fresh_tenant)
        async with conn.transaction():
            with pytest.raises(EpisodeNotFoundError):
                await md.supersede(
                    conn=conn,
                    tenant_id=fresh_tenant,
                    corrected_episode_uuid=bogus,
                    new_episode_uuid=uuid4(),
                    asserted_until=_utc(2024, 5, 1),
                )


async def test_cross_tenant_rejected(pg_pool: asyncpg.Pool) -> None:
    tenant_a = f"unit-md-a-{uuid4().hex[:8]}"
    tenant_b = f"unit-md-b-{uuid4().hex[:8]}"
    a_uuid = await _insert(pg_pool, tenant_id=tenant_a, asserted_at=_utc(2024, 4, 12))
    md = MetadataStore(pg_pool)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant_b)
        async with conn.transaction():
            with pytest.raises(CorrectsCrossTenantError):
                await md.supersede(
                    conn=conn,
                    tenant_id=tenant_b,
                    corrected_episode_uuid=a_uuid,
                    new_episode_uuid=uuid4(),
                    asserted_until=_utc(2024, 5, 1),
                )


async def test_axis_inversion(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    a = await _insert(pg_pool, tenant_id=fresh_tenant, asserted_at=_utc(2024, 4, 25))
    md = MetadataStore(pg_pool)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", fresh_tenant)
        async with conn.transaction():
            with pytest.raises(CorrectsAxisInversionError):
                await md.supersede(
                    conn=conn,
                    tenant_id=fresh_tenant,
                    corrected_episode_uuid=a,
                    new_episode_uuid=uuid4(),
                    asserted_until=_utc(2024, 4, 12),
                )


async def test_happy_path_closes_metadata(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    a = await _insert(pg_pool, tenant_id=fresh_tenant, asserted_at=_utc(2024, 4, 12))
    new_uuid = uuid4()
    asserted_until = _utc(2024, 4, 25)
    md = MetadataStore(pg_pool)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", fresh_tenant)
        async with conn.transaction():
            head = await md.supersede(
                conn=conn,
                tenant_id=fresh_tenant,
                corrected_episode_uuid=a,
                new_episode_uuid=new_uuid,
                asserted_until=asserted_until,
            )
    assert head.episode_uuid == a

    refetched = await md.get(tenant_id=fresh_tenant, episode_uuid=a)
    assert refetched is not None
    assert refetched.asserted_until == asserted_until
    assert refetched.superseded_by == new_uuid


async def test_chain_walk_to_head(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    """If caller names A but the chain is A -> B, supersede walks to B."""
    a = await _insert(pg_pool, tenant_id=fresh_tenant, asserted_at=_utc(2024, 4, 12))
    b = await _insert(pg_pool, tenant_id=fresh_tenant, asserted_at=_utc(2024, 4, 25))
    md = MetadataStore(pg_pool)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", fresh_tenant)
        async with conn.transaction():
            await md.supersede(
                conn=conn,
                tenant_id=fresh_tenant,
                corrected_episode_uuid=a,
                new_episode_uuid=b,
                asserted_until=_utc(2024, 4, 25),
            )

    c_uuid = uuid4()
    c_asserted = _utc(2024, 5, 10)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", fresh_tenant)
        async with conn.transaction():
            head = await md.supersede(
                conn=conn,
                tenant_id=fresh_tenant,
                corrected_episode_uuid=a,
                new_episode_uuid=c_uuid,
                asserted_until=c_asserted,
            )
    assert head.episode_uuid == b

    a_after = await md.get(tenant_id=fresh_tenant, episode_uuid=a)
    b_after = await md.get(tenant_id=fresh_tenant, episode_uuid=b)
    assert a_after is not None and b_after is not None
    assert a_after.asserted_until == _utc(2024, 4, 25)
    assert a_after.superseded_by == b
    assert b_after.asserted_until == c_asserted
    assert b_after.superseded_by == c_uuid


async def test_chain_depth_exceeded_raises(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    """Build a >32-hop chain (synthetic via direct SQL to bypass axis guard)."""
    md = MetadataStore(pg_pool)
    uuids: list[UUID] = []
    for i in range(34):
        u = await _insert(
            pg_pool,
            tenant_id=fresh_tenant,
            asserted_at=_utc(2024, 1, 1) + timedelta(days=i),
        )
        uuids.append(u)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", fresh_tenant)
        for i in range(33):
            await conn.execute(
                "UPDATE episode_metadata SET asserted_until = $1, "
                "superseded_by = $2 WHERE tenant_id = $3 AND episode_uuid = $4",
                _utc(2024, 1, 1) + timedelta(days=i + 1),
                uuids[i + 1],
                fresh_tenant,
                uuids[i],
            )
        async with conn.transaction():
            with pytest.raises(CorrectsChainError):
                await md.supersede(
                    conn=conn,
                    tenant_id=fresh_tenant,
                    corrected_episode_uuid=uuids[0],
                    new_episode_uuid=uuid4(),
                    asserted_until=_utc(2025, 1, 1),
                )
