"""tests/integration/test_preprocessor_recall.py — v0.1.1 smoke gates.

End-to-end coverage of the extraction preprocessor (issues #2/#3/#4):
ingest a fixture, recall a query that targets the lifted signal, assert
the answer appears in the recalled facts.

LLM-driven so quarantined under the existing flake pattern: skip-on-zero-
edges with retry budget, just like ``test_ingest_recall.py``. Hard
verification of preprocessor correctness lives in the unit tests.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone

import pytest

from gnokee.bootstrap import App
from gnokee.ingest import ingest_episode
from gnokee.retrieval import fact_provenance, recall

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not (os.environ.get("GNOKEE_OPENAI_API_KEY") or os.environ.get("GNOKEE_LLM_API_KEY")),
        reason="needs OpenAI-compatible LLM credentials for Graphiti entity extraction",
    ),
]


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


async def _ingest_until_edges(app: App, tenant: str, content: str, valid_at: datetime):
    """Retry ingest a few times to absorb Graphiti's known LLM-flake."""
    receipt = None
    for _n in range(3):
        receipt = await ingest_episode(
            pipeline=app.ingest,
            tenant_id=tenant,
            content=content,
            valid_at=valid_at,
            sensitive="public",
        )
        if receipt.created_fact_uuids:
            return receipt
    return receipt


@pytest.mark.asyncio
async def test_adr_identifier_recall(app: App, fresh_tenant: str) -> None:
    """Issue #2: ADR-NNN reference must be surfaceable via recall."""
    content = (
        "## ADR-025: Maintenance daemon cadence\nADR-025 decides that gnokee runs synthesis nightly at 02:00 UTC.\n"
    )
    receipt = await _ingest_until_edges(app, fresh_tenant, content, _utc(2026, 4, 1))
    assert receipt is not None
    if not receipt.created_fact_uuids:
        pytest.skip("Graphiti extractor produced no edges across 3 attempts; LLM-driven flake")

    response = await recall(
        pipeline=app.recall,
        tenant_id=fresh_tenant,
        text="What does ADR-025 decide?",
    )
    fact_text = " ".join(f.text for f in response.facts)
    assert "ADR-025" in fact_text or "025" in fact_text, f"ADR-025 not surfaced; recalled facts: {fact_text!r}"


@pytest.mark.asyncio
async def test_top_of_stack_recall(app: App, fresh_tenant: str) -> None:
    """Issue #3: ranked-list priority must be surfaceable via recall."""
    content = (
        "## Open questions for v0.1\n"
        "Top of stack: validate before writing real code → Q1.\n"
        "1. Q1 graphiti spike\n"
        "2. Q2 cross-lingual recall\n"
        "3. Q3 retrieval shape\n"
    )
    receipt = await _ingest_until_edges(app, fresh_tenant, content, _utc(2026, 4, 1))
    assert receipt is not None
    if not receipt.created_fact_uuids:
        pytest.skip("Graphiti extractor produced no edges across 3 attempts; LLM-driven flake")

    response = await recall(
        pipeline=app.recall,
        tenant_id=fresh_tenant,
        text="What is the top open question for v0.1?",
    )
    fact_text = " ".join(f.text.lower() for f in response.facts)
    assert "q1" in fact_text or "top" in fact_text or "graphiti spike" in fact_text, (
        f"top-of-stack signal not surfaced; recalled: {fact_text!r}"
    )


@pytest.mark.asyncio
async def test_currency_amount_recall(app: App, fresh_tenant: str) -> None:
    """Issue #4: markdown-table currency cells must be surfaceable via recall."""
    content = (
        "## Sofia Apartment / Finance\n"
        "\n"
        "| Category   | Vendor   | Amount  | As of      |\n"
        "| ---------- | -------- | ------- | ---------- |\n"
        "| renovation | Foo Ltd. | €14,225 | 2026-04-20 |\n"
    )
    receipt = await _ingest_until_edges(app, fresh_tenant, content, _utc(2026, 4, 20))
    assert receipt is not None
    if not receipt.created_fact_uuids:
        pytest.skip("Graphiti extractor produced no edges across 3 attempts; LLM-driven flake")

    response = await recall(
        pipeline=app.recall,
        tenant_id=fresh_tenant,
        text="How much was spent on the Sofia renovation?",
    )
    fact_text = " ".join(f.text for f in response.facts)
    assert "14,225" in fact_text or "14225" in fact_text or "€" in fact_text, (
        f"renovation amount not surfaced; recalled: {fact_text!r}"
    )


@pytest.mark.asyncio
async def test_provenance_returns_original_body(app: App, fresh_tenant: str) -> None:
    """Stage 4b invariant: Episodic.content must be original markdown,
    NOT the augmented body the preprocessor passed to graphiti.
    """
    content = "## ADR-007: Some decision\nADR-007 says we will use bge-m3 for embeddings.\n"
    receipt = await _ingest_until_edges(app, fresh_tenant, content, _utc(2026, 4, 1))
    assert receipt is not None
    if not receipt.created_fact_uuids:
        pytest.skip("Graphiti extractor produced no edges across 3 attempts; LLM-driven flake")

    fact_uuid = receipt.created_fact_uuids[0]
    prov = await fact_provenance(
        pipeline=app.recall,
        tenant_id=fresh_tenant,
        fact_uuid=fact_uuid,
    )
    assert prov is not None
    assert prov.episode_content == content, (
        "Episode content should be the original markdown after preprocessor "
        "round-trip; preprocessor metadata should not leak into provenance."
    )
    assert "Derived facts:" not in prov.episode_content
