"""tests/integration/test_recall_supersession_hints.py — issue #19.

Verifies the supersession-hint surfacing path on `gnokee_recall`. When
an episode is cosine-relevant AND has been superseded at the caller's
`as_of`, it must be:

- excluded from `facts[]` and `excerpts[]` (clinical safety — stale
  narrative must not surface as current);
- surfaced in `supersession_hints[]` with the chain head so the agent
  knows where to follow up via typed reads.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone

import pytest

from gnokee.bootstrap import App
from gnokee.ingest import ingest_episode
from gnokee.retrieval import recall

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not (os.environ.get("GNOKEE_OPENAI_API_KEY") or os.environ.get("GNOKEE_LLM_API_KEY")),
        reason="needs OpenAI-compatible LLM credentials for Graphiti entity extraction",
    ),
]


def _utc(year: int, month: int, day: int, hour: int = 12) -> datetime:
    return datetime(year, month, day, hour, 0, 0, tzinfo=timezone.utc)


_PANEL_APRIL = """\
Lab panel — drawn 2024-04-10, reported 2024-04-12.

Basic Metabolic Panel:
- Potassium: 2.8 mmol/L (ref: 3.5-5.0) **LOW — critical**
- Magnesium: 1.4 mg/dL (ref: 1.7-2.4) **LOW**
"""

_PANEL_APRIL_CORRECTION = """\
CORRECTION — Lab panel from 2024-04-10
Potassium result was reported incorrectly due to instrument calibration drift.

- Potassium: 3.6 mmol/L (ref: 3.5-5.0) — within range
"""


@pytest.mark.asyncio
async def test_recall_emits_hint_for_superseded_episode(
    app: App,
    fresh_tenant: str,
) -> None:
    receipt_orig = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    receipt_corr = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_orig.episode_uuid,
    )

    response = await recall(
        pipeline=app.recall,
        tenant_id=fresh_tenant,
        text="critical hypokalemia April 2024 potassium panel",
        max_tokens=400,
        top_k=10,
    )

    # Hint must surface the superseded original with the correction as head.
    hints_by_superseded = {h.superseded_uuid: h for h in response.supersession_hints}
    assert receipt_orig.episode_uuid in hints_by_superseded, (
        f"superseded episode {receipt_orig.episode_uuid} not surfaced in hints; "
        f"got hints={list(hints_by_superseded.keys())}"
    )
    hint = hints_by_superseded[receipt_orig.episode_uuid]
    assert hint.current_head_uuid == receipt_corr.episode_uuid
    assert hint.superseded_at == _utc(2024, 4, 25)

    # Clinical-safety: original "critical" narrative must NOT appear in
    # facts/excerpts at default `as_of=now`.
    fact_episode_uuids = {f.episode_uuid for f in response.facts}
    excerpt_episode_uuids = {e.episode_uuid for e in response.excerpts}
    assert receipt_orig.episode_uuid not in fact_episode_uuids
    assert receipt_orig.episode_uuid not in excerpt_episode_uuids


@pytest.mark.asyncio
async def test_recall_no_hint_when_as_of_pre_correction(
    app: App,
    fresh_tenant: str,
) -> None:
    """Pinning `as_of` before the correction asserted_at keeps the
    original episode visible — no hint should be emitted because the
    episode is the live head at that pin.
    """
    receipt_orig = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_orig.episode_uuid,
    )

    response = await recall(
        pipeline=app.recall,
        tenant_id=fresh_tenant,
        text="critical hypokalemia April 2024 potassium panel",
        as_of=_utc(2024, 4, 20),
        valid_at=_utc(2024, 4, 20),
        max_tokens=400,
        top_k=10,
    )

    # No hint: original is open at as_of=2024-04-20 (before correction
    # asserted_at=2024-04-25), so it surfaces as a fact, not a hint.
    assert response.supersession_hints == []


@pytest.mark.asyncio
async def test_recall_with_no_supersession_emits_no_hints(
    app: App,
    fresh_tenant: str,
) -> None:
    """Backwards-compat sanity: a corpus with no `corrects:` returns an
    empty `supersession_hints[]`.
    """
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    response = await recall(
        pipeline=app.recall,
        tenant_id=fresh_tenant,
        text="critical hypokalemia April 2024 potassium panel",
        max_tokens=400,
        top_k=10,
    )
    assert response.supersession_hints == []
