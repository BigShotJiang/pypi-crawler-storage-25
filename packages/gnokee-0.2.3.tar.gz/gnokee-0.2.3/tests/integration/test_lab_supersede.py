"""tests/integration/test_lab_supersede.py — LabStore.supersede_matching against real Postgres."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from uuid import uuid4

import asyncpg
import pytest

from gnokee.storage.lab import LabRecordRow, LabStore
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore

pytestmark = [pytest.mark.integration, pytest.mark.asyncio]


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


async def _seed_episode(
    *,
    pg_pool: asyncpg.Pool,
    tenant_id: str,
    asserted_at: datetime,
) -> EpisodeMetadataRow:
    row = EpisodeMetadataRow(
        tenant_id=tenant_id,
        episode_uuid=uuid4(),
        valid_at=_utc(2024, 4, 10),
        valid_until=None,
        asserted_at=asserted_at,
        asserted_until=None,
        superseded_by=None,
        sensitive="clinical",
        language="en",
        our_id=None,
    )
    md = MetadataStore(pg_pool)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant_id)
        await md.write(conn=conn, row=row)
    return row


async def test_supersede_matching_closes_named_keys(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    """Per-row match: K closes, Mg untouched."""
    tenant = fresh_tenant
    asserted_a = _utc(2024, 4, 12)
    asserted_b = _utc(2024, 4, 25)
    ep_a = await _seed_episode(pg_pool=pg_pool, tenant_id=tenant, asserted_at=asserted_a)

    lab = LabStore(pg_pool)
    rows = [
        LabRecordRow(
            tenant_id=tenant,
            episode_uuid=ep_a.episode_uuid,
            analyte="Potassium",
            value_numeric=Decimal("2.8"),
            value_text=None,
            unit="mmol/L",
            ref_range_low=Decimal("3.5"),
            ref_range_high=Decimal("5.0"),
            abnormal_flag="L",
            valid_at=_utc(2024, 4, 10),
            asserted_at=asserted_a,
        ),
        LabRecordRow(
            tenant_id=tenant,
            episode_uuid=ep_a.episode_uuid,
            analyte="Magnesium",
            value_numeric=Decimal("1.5"),
            value_text=None,
            unit="mg/dL",
            ref_range_low=Decimal("1.7"),
            ref_range_high=Decimal("2.4"),
            abnormal_flag="L",
            valid_at=_utc(2024, 4, 10),
            asserted_at=asserted_a,
        ),
    ]
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        async with conn.transaction():
            await lab.write_rows(conn=conn, rows=rows)

    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        async with conn.transaction():
            updated = await lab.supersede_matching(
                conn=conn,
                tenant_id=tenant,
                episode_uuid=ep_a.episode_uuid,
                keys=[("Potassium", _utc(2024, 4, 10))],
                asserted_until=asserted_b,
            )
    assert updated == 1

    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        records = await conn.fetch(
            "SELECT analyte, asserted_until FROM lab_record WHERE tenant_id = $1 ORDER BY analyte",
            tenant,
        )
    state = {r["analyte"]: r["asserted_until"] for r in records}
    assert state["Potassium"] == asserted_b
    assert state["Magnesium"] is None


async def test_supersede_matching_returns_zero_when_no_match(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    """Caller compares count vs len(keys); method itself returns 0 silently."""
    tenant = fresh_tenant
    asserted = _utc(2024, 4, 12)
    ep = await _seed_episode(pg_pool=pg_pool, tenant_id=tenant, asserted_at=asserted)
    lab = LabStore(pg_pool)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        async with conn.transaction():
            updated = await lab.supersede_matching(
                conn=conn,
                tenant_id=tenant,
                episode_uuid=ep.episode_uuid,
                keys=[("Nonexistent", _utc(2024, 4, 10))],
                asserted_until=asserted + timedelta(days=1),
            )
    assert updated == 0


async def test_supersede_matching_empty_keys_returns_zero(pg_pool: asyncpg.Pool, fresh_tenant: str) -> None:
    tenant = fresh_tenant
    asserted = _utc(2024, 4, 12)
    ep = await _seed_episode(pg_pool=pg_pool, tenant_id=tenant, asserted_at=asserted)
    lab = LabStore(pg_pool)
    async with pg_pool.acquire() as conn:
        await conn.execute("SELECT set_config('app.current_tenant', $1, true)", tenant)
        async with conn.transaction():
            updated = await lab.supersede_matching(
                conn=conn,
                tenant_id=tenant,
                episode_uuid=ep.episode_uuid,
                keys=[],
                asserted_until=asserted + timedelta(days=1),
            )
    assert updated == 0
