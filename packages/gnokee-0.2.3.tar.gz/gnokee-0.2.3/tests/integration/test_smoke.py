"""tests/integration/test_smoke.py — M0 gate: prove the stack is reachable."""

from __future__ import annotations

import asyncpg
import httpx
import pytest
from neo4j import AsyncDriver

pytestmark = pytest.mark.integration


@pytest.mark.asyncio
async def test_postgres_reachable_and_migrations_applied(pg_pool: asyncpg.Pool) -> None:
    async with pg_pool.acquire() as conn:
        rows = await conn.fetch("SELECT name FROM gnokee_schema_migrations ORDER BY name")
    names = [r["name"] for r in rows]
    assert names == [
        "0001_episode_metadata.sql",
        "0002_content_embedding.sql",
        "0003_fact_contradiction.sql",
        "0004_index_pinning.sql",
        "0005_episode_our_id.sql",
        "0006_lab_record.sql",
        "0007_med_record.sql",
    ]


@pytest.mark.asyncio
async def test_pgvector_extension_present(pg_pool: asyncpg.Pool) -> None:
    async with pg_pool.acquire() as conn:
        ext = await conn.fetchval("SELECT extname FROM pg_extension WHERE extname = 'vector'")
    assert ext == "vector"


@pytest.mark.asyncio
async def test_neo4j_reachable(neo4j_driver: AsyncDriver) -> None:
    async with neo4j_driver.session() as session:
        result = await session.run("RETURN 1 AS one")
        record = await result.single()
        assert record is not None
        assert record["one"] == 1


@pytest.mark.asyncio
async def test_tei_returns_embedding(tei_client: httpx.AsyncClient) -> None:
    response = await tei_client.post("/embed", json={"inputs": "hello"})
    response.raise_for_status()
    payload = response.json()
    assert isinstance(payload, list)
    assert len(payload) == 1
    assert len(payload[0]) == 1024
