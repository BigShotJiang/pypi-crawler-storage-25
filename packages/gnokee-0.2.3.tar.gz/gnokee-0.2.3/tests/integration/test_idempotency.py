"""tests/integration/test_idempotency.py — v0.1.1 gate: `our_id` replay semantics.

Re-fetched email/calendar/notes payloads must not produce duplicate Graphiti
episodes. Same ``(tenant_id, our_id)`` twice → same ``episode_uuid``, second
call returns ``replayed=True`` and skips Graphiti, vector write, and
contradiction detection.
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime, timezone

import asyncpg
import pytest

from gnokee.bootstrap import App
from gnokee.ingest import ingest_episode

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not (os.environ.get("GNOKEE_OPENAI_API_KEY") or os.environ.get("GNOKEE_LLM_API_KEY")),
        reason="needs OpenAI-compatible LLM credentials for Graphiti entity extraction",
    ),
]


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 12, 0, 0, tzinfo=timezone.utc)


@pytest.mark.asyncio
async def test_same_our_id_twice_returns_replay(app: App, fresh_tenant: str) -> None:
    our_id = "email:msg-test-1@example.com"
    first = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Alice moved to Berlin in June 2019.",
        valid_at=_utc(2019, 6, 1),
        our_id=our_id,
        sensitive="public",
    )
    assert first.replayed is False

    second = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Different body — should be ignored on replay.",
        valid_at=_utc(2020, 1, 1),
        our_id=our_id,
        sensitive="public",
    )
    assert second.replayed is True
    assert second.episode_uuid == first.episode_uuid
    assert second.asserted_at == first.asserted_at
    assert second.created_fact_uuids == []
    assert second.contradicts == []


@pytest.mark.asyncio
async def test_different_our_id_creates_two_episodes(app: App, fresh_tenant: str) -> None:
    body = "Alice runs ETL pipelines on Postgres for project Atlas since 2023."
    first = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=body,
        valid_at=_utc(2023, 9, 1),
        our_id="email:msg-A",
        sensitive="public",
    )
    second = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=body,
        valid_at=_utc(2023, 9, 1),
        our_id="email:msg-B",
        sensitive="public",
    )
    assert first.replayed is False
    assert second.replayed is False
    assert first.episode_uuid != second.episode_uuid


@pytest.mark.asyncio
async def test_no_our_id_keeps_legacy_behavior(app: App, fresh_tenant: str) -> None:
    """Without `our_id` two ingests of the same content remain distinct."""
    body = "Alice moved to Berlin in June 2019."
    first = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=body,
        valid_at=_utc(2019, 6, 1),
        sensitive="public",
    )
    second = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=body,
        valid_at=_utc(2019, 6, 1),
        sensitive="public",
    )
    assert first.replayed is False
    assert second.replayed is False
    assert first.episode_uuid != second.episode_uuid


@pytest.mark.asyncio
async def test_our_id_persists_to_episode_metadata(
    app: App,
    fresh_tenant: str,
    pg_pool: asyncpg.Pool,
) -> None:
    our_id = "calendar:event-42"
    receipt = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Alice has a dentist appointment on 2024-03-15.",
        valid_at=_utc(2024, 3, 15),
        our_id=our_id,
        sensitive="private",
    )
    async with pg_pool.acquire() as conn:
        stored = await conn.fetchval(
            "SELECT our_id FROM episode_metadata WHERE tenant_id = $1 AND episode_uuid = $2",
            fresh_tenant,
            receipt.episode_uuid,
        )
    assert stored == our_id


@pytest.mark.asyncio
async def test_concurrent_same_our_id_one_wins(app: App, fresh_tenant: str) -> None:
    """Race: two concurrent ingests with the same key → one inserts, one replays."""
    our_id = "email:msg-race-1"
    body = "Alice moved to Berlin in June 2019."
    valid_at = _utc(2019, 6, 1)

    receipts = await asyncio.gather(
        ingest_episode(
            pipeline=app.ingest,
            tenant_id=fresh_tenant,
            content=body,
            valid_at=valid_at,
            our_id=our_id,
            sensitive="public",
        ),
        ingest_episode(
            pipeline=app.ingest,
            tenant_id=fresh_tenant,
            content=body,
            valid_at=valid_at,
            our_id=our_id,
            sensitive="public",
        ),
    )
    # Exactly one winner — both end up pointing at the same episode_uuid.
    winners = [r for r in receipts if r.replayed is False]
    replays = [r for r in receipts if r.replayed is True]
    assert len(winners) == 1
    assert len(replays) == 1
    assert winners[0].episode_uuid == replays[0].episode_uuid
