"""tests/integration/test_clinical_med_e2e.py — v0.2 med path against real Postgres.

Exercises the full ADR-0010 surface end-to-end:
  - ingest med-event prose → `med_parser` → `med_record` rows written
    inside the Stage 6 txn alongside `episode_metadata` +
    `content_embedding`
  - `gnokee_med_query` typed reads (active / history / allergies /
    switches) honour both bi-temporal half-pairs.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from decimal import Decimal

import pytest

from gnokee.bootstrap import App
from gnokee.ingest import ingest_episode
from gnokee.med_query import med_query

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not (os.environ.get("GNOKEE_OPENAI_API_KEY") or os.environ.get("GNOKEE_LLM_API_KEY")),
        reason="needs OpenAI-compatible LLM credentials for Graphiti entity extraction",
    ),
]


def _utc(year: int, month: int, day: int) -> datetime:
    return datetime(year, month, day, 9, 0, 0, tzinfo=timezone.utc)


@pytest.mark.asyncio
async def test_ingest_writes_med_record_rows(app: App, fresh_tenant: str) -> None:
    receipt = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Started Lisinopril 10 mg PO daily for stage-1 hypertension.",
        valid_at=_utc(2024, 2, 1),
        sensitive="clinical",
    )
    assert receipt.episode_uuid

    async with app.pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT drug_name, dose_value, dose_unit, frequency, route,
                   event_kind
              FROM med_record
             WHERE tenant_id = $1
            """,
            fresh_tenant,
        )

    assert len(rows) == 1
    r = rows[0]
    assert r["drug_name"] == "Lisinopril"
    assert r["dose_value"] == Decimal("10")
    assert r["dose_unit"] == "mg"
    assert r["frequency"] == "daily"
    assert r["route"] == "PO"
    assert r["event_kind"] == "start"


@pytest.mark.asyncio
async def test_med_query_active_excludes_stop(app: App, fresh_tenant: str) -> None:
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Started Lisinopril 10 mg PO daily.",
        valid_at=_utc(2024, 2, 1),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Started Furosemide 20 mg PO daily.",
        valid_at=_utc(2024, 3, 1),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Discontinued Lisinopril 10 mg today.",
        valid_at=_utc(2024, 4, 1),
        sensitive="clinical",
    )

    response = await med_query(
        pipeline=app.med_query,
        tenant_id=fresh_tenant,
        op="active",
    )
    drugs = {r.drug_name for r in response.rows}
    assert drugs == {"Furosemide"}  # Lisinopril was stopped


@pytest.mark.asyncio
async def test_med_query_history_returns_drug_timeline(
    app: App,
    fresh_tenant: str,
) -> None:
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Started Lisinopril 10 mg PO daily.",
        valid_at=_utc(2024, 2, 1),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Increased Lisinopril from 10 mg to 20 mg PO daily.",
        valid_at=_utc(2024, 6, 15),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Discontinued Lisinopril 20 mg today.",
        valid_at=_utc(2024, 9, 15),
        sensitive="clinical",
    )

    response = await med_query(
        pipeline=app.med_query,
        tenant_id=fresh_tenant,
        op="history",
        drug_name="Lisinopril",
    )
    kinds = [r.event_kind for r in response.rows]
    assert kinds == ["start", "increase", "stop"]
    assert response.rows[1].dose_value == Decimal("20")


@pytest.mark.asyncio
async def test_med_query_allergies(app: App, fresh_tenant: str) -> None:
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Allergy documented: Penicillin — moderate reaction.",
        valid_at=_utc(2023, 8, 1),
        sensitive="clinical",
    )
    response = await med_query(
        pipeline=app.med_query,
        tenant_id=fresh_tenant,
        op="allergies",
    )
    assert response.count == 1
    assert response.rows[0].drug_name == "Penicillin"
    assert response.rows[0].event_kind == "allergy"


@pytest.mark.asyncio
async def test_med_query_active_at_historical_pin(
    app: App,
    fresh_tenant: str,
) -> None:
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Started Lisinopril 10 mg PO daily.",
        valid_at=_utc(2024, 2, 1),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Discontinued Lisinopril 10 mg today.",
        valid_at=_utc(2024, 4, 1),
        sensitive="clinical",
    )

    # World-time pinned to March (between start and stop).
    response = await med_query(
        pipeline=app.med_query,
        tenant_id=fresh_tenant,
        op="active",
        valid_at=_utc(2024, 3, 1),
    )
    drugs = {r.drug_name for r in response.rows}
    assert drugs == {"Lisinopril"}


@pytest.mark.asyncio
async def test_med_query_tenant_isolation(app: App, fresh_tenant: str) -> None:
    other = f"{fresh_tenant}-other"
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content="Started Lisinopril 10 mg PO daily.",
        valid_at=_utc(2024, 2, 1),
        sensitive="clinical",
    )
    response = await med_query(
        pipeline=app.med_query,
        tenant_id=other,
        op="active",
    )
    assert response.rows == []
