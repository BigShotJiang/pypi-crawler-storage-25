"""tests/integration/test_supersession_e2e.py — v0.2.1 corrects: signal.

End-to-end supersession against real Postgres + Neo4j + TEI:
- lab + med row-level supersession
- episode_metadata supersession (asserted_until + superseded_by)
- aggregation respects supersession (Q7 q_k_lowest_2024 named bug)
- cross-tenant rejection
- chain-walk from stale target
- pure-narrative correction (no parsed rows)
- idempotent replay (Stage 1b short-circuit)
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from decimal import Decimal
from uuid import UUID, uuid4

import pytest

from gnokee.bootstrap import App
from gnokee.errors import (
    CorrectsAxisInversionError,
    CorrectsCrossTenantError,
    EpisodeNotFoundError,
)
from gnokee.ingest import ingest_episode
from gnokee.lab_query import lab_query

pytestmark = [
    pytest.mark.integration,
    pytest.mark.skipif(
        not (os.environ.get("GNOKEE_OPENAI_API_KEY") or os.environ.get("GNOKEE_LLM_API_KEY")),
        reason="needs OpenAI-compatible LLM credentials for Graphiti entity extraction",
    ),
]


def _utc(year: int, month: int, day: int, hour: int = 12) -> datetime:
    return datetime(year, month, day, hour, 0, 0, tzinfo=timezone.utc)


_PANEL_APRIL = """\
Lab panel — drawn 2024-04-10, reported 2024-04-12.

Basic Metabolic Panel:
- Potassium: 2.8 mmol/L (ref: 3.5-5.0) **LOW — critical**
- Magnesium: 1.4 mg/dL (ref: 1.7-2.4) **LOW**
"""

_PANEL_APRIL_CORRECTION_K_ONLY = """\
CORRECTION — Lab panel from 2024-04-10
The Potassium result was reported incorrectly due to instrument calibration drift.

- Potassium: 3.6 mmol/L (ref: 3.5-5.0) — within range
"""

_PANEL_MARCH = """\
Lab panel — drawn 2024-03-15, reported 2024-03-15.

Basic Metabolic Panel:
- Potassium: 3.2 mmol/L (ref: 3.5-5.0) — borderline low
"""

_MED_LISINOPRIL_10 = """\
Started Lisinopril 10 mg PO daily on 2024-06-15 for mild hypertension.
"""

_MED_LISINOPRIL_20_CORRECTION = """\
CORRECTION — the Lisinopril start dose was 20 mg, not 10 mg. Increased
documentation only; clinical course unchanged.

Started Lisinopril 20 mg PO daily on 2024-06-15.
"""


# ---------- Lab cases ----------


@pytest.mark.asyncio
async def test_lab_happy_path_per_row_supersession(app: App, fresh_tenant: str) -> None:
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    async with app.pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT analyte, episode_uuid, asserted_until "
            "FROM lab_record WHERE tenant_id = $1 ORDER BY analyte, asserted_at",
            fresh_tenant,
        )
    by_key = {(r["analyte"], r["episode_uuid"]): r["asserted_until"] for r in rows}
    assert by_key[("Potassium", receipt_a.episode_uuid)] == receipt_b.asserted_at
    assert by_key[("Magnesium", receipt_a.episode_uuid)] is None
    assert by_key[("Potassium", receipt_b.episode_uuid)] is None


@pytest.mark.asyncio
async def test_episode_metadata_supersession(app: App, fresh_tenant: str) -> None:
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    async with app.pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT asserted_until, superseded_by FROM episode_metadata WHERE tenant_id = $1 AND episode_uuid = $2",
            fresh_tenant,
            receipt_a.episode_uuid,
        )
    assert row is not None
    assert row["asserted_until"] == receipt_b.asserted_at
    assert row["superseded_by"] == receipt_b.episode_uuid


@pytest.mark.asyncio
async def test_aggregation_respects_supersession(app: App, fresh_tenant: str) -> None:
    """The named v0.2.1 bug: MIN(value_numeric) skips the superseded 2.8."""
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_MARCH,
        valid_at=_utc(2024, 3, 15),
        asserted_at=_utc(2024, 3, 15),
        sensitive="clinical",
    )
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    response = await lab_query(
        pipeline=app.lab_query,
        tenant_id=fresh_tenant,
        analyte="Potassium",
        op="min",
        since=_utc(2024, 1, 1),
        until=_utc(2025, 1, 1),
        as_of=_utc(2024, 12, 31),
        valid_at=_utc(2024, 12, 31),
    )
    # March's 3.2 wins; April's 2.8 is superseded by 3.6.
    assert response.scalar == Decimal("3.2"), f"expected 3.2 (March), got: {response.scalar}"


# ---------- Med cases ----------


@pytest.mark.asyncio
async def test_med_happy_path_per_row_supersession(app: App, fresh_tenant: str) -> None:
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_MED_LISINOPRIL_10,
        valid_at=_utc(2024, 6, 15),
        asserted_at=_utc(2024, 6, 15),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_MED_LISINOPRIL_20_CORRECTION,
        valid_at=_utc(2024, 6, 15),
        asserted_at=_utc(2024, 6, 20),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    async with app.pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT episode_uuid, drug_name, event_kind, dose_value, "
            "asserted_until FROM med_record WHERE tenant_id = $1 "
            "ORDER BY asserted_at",
            fresh_tenant,
        )
    a_rows = [r for r in rows if r["episode_uuid"] == receipt_a.episode_uuid]
    b_rows = [r for r in rows if r["episode_uuid"] == receipt_b.episode_uuid]
    assert a_rows and a_rows[0]["asserted_until"] == receipt_b.asserted_at
    assert b_rows and b_rows[0]["asserted_until"] is None


# ---------- Validation cases ----------


@pytest.mark.asyncio
async def test_cross_tenant_rejected(app: App) -> None:
    tenant_a = f"e2e-supersede-a-{uuid4().hex[:8]}"
    tenant_b = f"e2e-supersede-b-{uuid4().hex[:8]}"
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=tenant_a,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    with pytest.raises(CorrectsCrossTenantError):
        await ingest_episode(
            pipeline=app.ingest,
            tenant_id=tenant_b,
            content=_PANEL_APRIL_CORRECTION_K_ONLY,
            valid_at=_utc(2024, 4, 10),
            asserted_at=_utc(2024, 4, 25),
            sensitive="clinical",
            corrects=receipt_a.episode_uuid,
        )


@pytest.mark.asyncio
async def test_episode_not_found(app: App, fresh_tenant: str) -> None:
    with pytest.raises(EpisodeNotFoundError):
        await ingest_episode(
            pipeline=app.ingest,
            tenant_id=fresh_tenant,
            content=_PANEL_APRIL_CORRECTION_K_ONLY,
            valid_at=_utc(2024, 4, 10),
            asserted_at=_utc(2024, 4, 25),
            sensitive="clinical",
            corrects=UUID("00000000-0000-0000-0000-000000000000"),
        )


@pytest.mark.asyncio
async def test_axis_inversion(app: App, fresh_tenant: str) -> None:
    receipt = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
    )
    with pytest.raises(CorrectsAxisInversionError):
        await ingest_episode(
            pipeline=app.ingest,
            tenant_id=fresh_tenant,
            content=_PANEL_APRIL_CORRECTION_K_ONLY,
            valid_at=_utc(2024, 4, 10),
            asserted_at=_utc(2024, 4, 12),
            sensitive="clinical",
            corrects=receipt.episode_uuid,
        )


# ---------- Chain + edge cases ----------


@pytest.mark.asyncio
async def test_chained_correction(app: App, fresh_tenant: str) -> None:
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    panel_april_re_correction = (
        "CORRECTION 2 — Lab panel from 2024-04-10\n- Potassium: 3.4 mmol/L (ref: 3.5-5.0) — slightly below\n"
    )
    receipt_c = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=panel_april_re_correction,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 5, 5),
        sensitive="clinical",
        corrects=receipt_b.episode_uuid,
    )
    async with app.pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT episode_uuid, asserted_until, superseded_by FROM episode_metadata WHERE tenant_id = $1",
            fresh_tenant,
        )
    by_uuid = {r["episode_uuid"]: r for r in rows}
    assert by_uuid[receipt_a.episode_uuid]["asserted_until"] == receipt_b.asserted_at
    assert by_uuid[receipt_a.episode_uuid]["superseded_by"] == receipt_b.episode_uuid
    assert by_uuid[receipt_b.episode_uuid]["asserted_until"] == receipt_c.asserted_at
    assert by_uuid[receipt_b.episode_uuid]["superseded_by"] == receipt_c.episode_uuid
    assert by_uuid[receipt_c.episode_uuid]["asserted_until"] is None


@pytest.mark.asyncio
async def test_empty_new_rows_with_corrects(app: App, fresh_tenant: str) -> None:
    """Pure-narrative correction body — episode_metadata closes; no row UPDATEs."""
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=(
            "Note attached to the 2024-04-10 panel: instrument calibration "
            "review found drift. Caller should disregard the panel pending "
            "re-test. No values restated."
        ),
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    async with app.pool.acquire() as conn:
        meta = await conn.fetchrow(
            "SELECT asserted_until, superseded_by FROM episode_metadata WHERE tenant_id = $1 AND episode_uuid = $2",
            fresh_tenant,
            receipt_a.episode_uuid,
        )
        labs = await conn.fetch(
            "SELECT asserted_until FROM lab_record WHERE tenant_id = $1 AND episode_uuid = $2",
            fresh_tenant,
            receipt_a.episode_uuid,
        )
    assert meta is not None
    assert meta["asserted_until"] == receipt_b.asserted_at
    assert meta["superseded_by"] == receipt_b.episode_uuid
    for r in labs:
        assert r["asserted_until"] is None


@pytest.mark.asyncio
async def test_idempotent_replay_with_corrects(app: App, fresh_tenant: str) -> None:
    """Stage 1b short-circuit: same our_id + same corrects -> replayed."""
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    first = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
        our_id="april-correction",
    )
    second = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
        our_id="april-correction",
    )
    assert second.replayed is True
    assert second.episode_uuid == first.episode_uuid
    async with app.pool.acquire() as conn:
        a_meta = await conn.fetchrow(
            "SELECT asserted_until, superseded_by FROM episode_metadata WHERE tenant_id = $1 AND episode_uuid = $2",
            fresh_tenant,
            receipt_a.episode_uuid,
        )
    assert a_meta is not None
    assert a_meta["asserted_until"] == first.asserted_at
    assert a_meta["superseded_by"] == first.episode_uuid


@pytest.mark.asyncio
async def test_chain_walk_from_stale_target(app: App, fresh_tenant: str) -> None:
    """A -> B already; ingest C with corrects=A; B is what closes."""
    receipt_a = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 12),
        sensitive="clinical",
    )
    receipt_b = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=_PANEL_APRIL_CORRECTION_K_ONLY,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 4, 25),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,
    )
    re_correction = "CORRECTION 2 — Lab panel from 2024-04-10\n- Potassium: 3.4 mmol/L (ref: 3.5-5.0)\n"
    receipt_c = await ingest_episode(
        pipeline=app.ingest,
        tenant_id=fresh_tenant,
        content=re_correction,
        valid_at=_utc(2024, 4, 10),
        asserted_at=_utc(2024, 5, 5),
        sensitive="clinical",
        corrects=receipt_a.episode_uuid,  # caller named the original
    )
    async with app.pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT episode_uuid, asserted_until, superseded_by FROM episode_metadata WHERE tenant_id = $1",
            fresh_tenant,
        )
    by_uuid = {r["episode_uuid"]: r for r in rows}
    assert by_uuid[receipt_a.episode_uuid]["asserted_until"] == receipt_b.asserted_at
    assert by_uuid[receipt_a.episode_uuid]["superseded_by"] == receipt_b.episode_uuid
    assert by_uuid[receipt_b.episode_uuid]["asserted_until"] == receipt_c.asserted_at
    assert by_uuid[receipt_b.episode_uuid]["superseded_by"] == receipt_c.episode_uuid
    assert by_uuid[receipt_c.episode_uuid]["asserted_until"] is None
