# Architecture

> Source-of-truth document for the gnokee memory layer. Mirrors the
> design originally drafted in Notion (`01 — Architecture`); from first
> commit forward, **this file** is canonical. Notion mirrors are
> discoverability surfaces only.

## Layered model

```text
┌─────────────────────────────────────────────────────────┐
│  Adapters (thin shims)                                  │
│  files / md-vault / api-push / rss / email / pulse-sdk  │
└────────────────┬────────────────────────────────────────┘
                  ↓ ingest_episode
┌─────────────────────────────────────────────────────────┐
│  gnokee core (the product)                              │
│    • ingestion: parse, normalize, classify, embed       │
│    • bi-temporal store, supersession, contradiction     │
│    • retrieval: semantic + BM25 + graph + temporal      │
│    • forgetting: tombstones + crypto erasure            │
│    • maintenance: dedupe, lint, synthesize              │
│    • MCP server (token-efficient)                       │
└────────────────┬────────────────────────────────────────┘
                  ↓
┌─────────────────────────────────────────────────────────┐
│  Backends (pluggable)                                   │
│  Graphiti (temporal KG) + Postgres + pgvector           │
│  Embeddings: bge-m3 via TEI / Ollama / OpenAI           │
└─────────────────────────────────────────────────────────┘
```

Top and bottom are commodity. The middle is where gnokee's IP lives.

## Service inventory (v0.1)

| Service       | Language               | Role                                                                          |
|---------------|------------------------|-------------------------------------------------------------------------------|
| `gnokee`      | Python 3.10+           | Single binary or compose stack: ingestion, retrieval, MCP, scheduler. Wraps Graphiti. |
| `gnokee-tei`  | Rust (HuggingFace TEI) | Embedding service, bge-m3 by default. Optional — consumer may bring own.      |
| `graphiti`    | (library)              | Bi-temporal KG primitive. Consumed in-process.                                |

v0.1 ships as `docker-compose.yml` (Postgres+pgvector + Neo4j + optional TEI).

## License boundary

**gnokee code is Apache 2.0.** Storage backends are external dependencies
that consumers run themselves; gnokee does not redistribute them.

| Layer | License | Provided by |
|---|---|---|
| `gnokee` Python package + container | Apache 2.0 | gnokeelabs (this repo) |
| `gnokee-tei` (optional) | Apache 2.0 | gnokeelabs (HuggingFace TEI as base) |
| Postgres + pgvector | PostgreSQL License | upstream / consumer-deployed |
| Neo4j Community server | GPLv3 | upstream / consumer-deployed |
| Graphiti library (Python dep) | Apache 2.0 | getzep/graphiti |
| bge-m3 weights | MIT | BAAI |

This is the same model pgvector users already accept for Postgres:
the application layer is permissively licensed; the storage layer is
whatever the consumer deploys, possibly under copyleft. Consumers
who need a strictly-permissive stack today can substitute Postgres
+ pgvector for the graph layer (with reduced functionality —
ADR-0005 documents the trade-off space).

## Core contracts

The shapes below live in [`src/gnokee/models.py`](../src/gnokee/models.py).

### Ingestion (`gnokee.ingest_episode(...)`)

- `tenant_id` — mandatory; `"default"` for single-user
- `content` xor `encrypted_body` — gnokee never holds keys when encrypted
- `valid_time_start` / `valid_time_end` — when the fact was true in the world
- `observed_time` — when the consumer learned of it (defaults to ingest time)
- `entity_type_hints` — advisory; Graphiti decides actual typing
- `sensitive` ∈ `public | private | clinical`
- `language` — ISO 639-1; auto-detect when null

### Retrieval (`gnokee.query(...)`)

- `as_of` — bi-temporal: "what did the system know on this date?"
- `valid_at` — bi-temporal: "facts true on this date?"
- `surface_contradictions=True` — return conflicting facts alongside primary
- `max_tokens=500` — response budget; ranker honors this
- Returns natural-language fact statements + lazy provenance + contradiction refs (not full bodies)

## Bi-temporal model

Every fact has two clocks:

- **valid time** — when the fact was true in the world
- **transaction time** — when the system learned of it

Queries can pin either or both. Supersession is **explicit and additive**:
fact A is never deleted when fact B replaces it; A's `transaction_time_end`
is set, A's `superseded_by = B.id`, B's `supersedes = A.id`. Time-travel
queries still find A.

## Contradiction handling

Contradictions are **detected at ingest, surfaced at retrieval, not auto-resolved**.

When a new episode produces fact F, gnokee searches for high-similarity
existing facts within the same entity context, asks an LLM whether each
candidate is `unrelated | refinement | update | contradiction`, and stores
the verdict as a graph edge. Retrieval returns F together with any live
`contradicts` edges. The MCP tool description nudges the consuming LLM to
reconcile (preferring more recent / higher confidence) **or** surface to
the user. gnokee never picks a winner.

## Forgetting

Three modes:

1. **Soft supersession** — `transaction_time_end` set; time-travel queries
   still find the old fact. Default for "I changed my mind" / "world changed".
2. **Hard delete with tombstone propagation** — vector index, graph,
   derived summaries all touched. Returns a `ForgetReceipt` enumerating
   affected artifacts.
3. **Cryptographic erasure** — destroy the per-fact DEK in the consumer's
   KMS; ciphertext becomes unreadable. Used when backups can't be selectively
   rewritten (clinical GDPR).

**gnokee never holds keys, never decrypts.** Per-tenant DEKs reference
consumer KMS (e.g. OpenBao for Omur). The `gnokee` name encodes this:
"no key" = arch invariant.

## Multi-tenancy

- `tenant_id` on every table, every API call, every MCP tool call
- Postgres RLS enforced via `set_config('app.current_tenant', ...)` GUC,
  set by gnokee's request middleware
- Per-tenant key envelope (`EncryptedBody.key_id` references consumer KMS)
- Tenant deletion cascades through facts, episodes, embeddings, derived
  summaries, tombstones

## Backend choices (v0.1)

- **Graph store:** Neo4j Community (Graphiti default). v0.1 *and* v0.2.
  Per [ADR-0005](adr/0005-graph-backend-tradeoff.md): FalkorDB
  dropped on SSPL grounds; Kùzu archived; Apache AGE deferred (5–7
  person-weeks realistic effort, blockers on vector cosine and
  fulltext). Re-open the decision when on-prem-non-GPL distribution
  or ops-consolidation triggers it.
- **Vector store:** pgvector. Postgres is already present for facts; one
  fewer service. **Stores per-episode `content_embedding`** keyed by
  `(tenant_id, episode_uuid)` — gnokee writes this alongside every
  `Graphiti.add_episode` call. See ADR-0004.
- **Embeddings:** bge-m3 via HuggingFace TEI, single instance, GPU-optional.
  Ollama embeddings as dev fallback. Q2 spike validated cross-lingual
  retrieval at 100% top-1 over en/ru/bg/he via direct cosine on
  full-episode content; this is the v0.1 retrieval primitive.
- **LLM (entity extraction + maintenance synthesis):** consumer-supplied via
  OpenAI-compatible endpoint. gnokee doesn't host LLMs.

## Retrieval path (v0.1, per ADR-0004)

`gnokee.query(...)` does **not** call `Graphiti.search_()`. Instead:

1. Embed the user query via the configured bge-m3 endpoint
2. Cypher narrows the candidate set: `MATCH (ep:Episodic)
   WHERE ep.group_id = $tenant AND <bi-temporal filters>` —
   `valid_at` ≤ as-of, optional `asserted_at` ≤ tx-as-of
   (gnokee-managed via `episode_metadata`, not Graphiti's `created_at`)
3. Fetch candidate `content_embedding`s from pgvector, rank by cosine
4. Join Graphiti's edge facts (supersession, contradictions) onto the
   top-K episodes for surfacing

Graphiti's `COMBINED_HYBRID_SEARCH_RRF` and the `SearchFilters` API
are **not** on the v0.1 hot path. The Q2 spike showed they rank
structurally rather than by query relevance at our corpus shape
(many short single-fact episodes).

## Out of scope for v0.1

- Federation between gnokee instances
- Real-time streaming retrieval
- UI of any kind
- Auth provider (consumer handles)
- Workflow orchestration (consumer handles)
- Document parsing pipeline (consumer hands episodes pre-parsed)
- Multi-modal beyond text (images, audio — v2)
- Federated learning, homomorphic encryption, ZK proofs (not in scope)

## Pre-implementation gates

Before any v0.1 feature work, the spikes in `docs/adr/` must resolve:

- ADR-0001: Graphiti's bi-temporal model fits the two consumer corpora.
  **Resolved 2026-05-08:** Accepted as storage primitive (Q1 v2.1).
- ADR-0004: gnokee owns retrieval; Graphiti is the storage primitive.
  **Resolved 2026-05-08:** Q2 direct-cosine baseline = 100% top-1
  cross-lingual on the same corpus where Graphiti's combined search
  scored 25%. Per-episode content embedding in pgvector + Cypher-side
  bi-temporal filter is the v0.1 retrieval primitive.
- (further ADRs added as decisions land)
