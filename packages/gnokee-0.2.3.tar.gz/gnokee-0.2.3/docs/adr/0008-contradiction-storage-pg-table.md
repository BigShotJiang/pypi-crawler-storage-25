# ADR-0008: Contradiction storage in `fact_contradiction` Postgres table

- **Status:** Accepted
- **Date:** 2026-05-08
- **Decider:** Vadim Yuzi
- **Context:** v0.1 specialist sweep on `docs/specs/v0.1.md`

## Context

The Q4 spike validated that gpt-4o-mini classifies fact pairs into
`unrelated | refinement | update | contradiction` with ~80% recall.
The original v0.1 spec stored each verdict as a CONTRADICTS edge in
Graphiti. The graphiti-specialist review on commit 4190708 surfaced
that this is not representable in Neo4j: Graphiti models facts as
`(EntityNode)-[EntityEdge: RELATES_TO]->(EntityNode)`, and Neo4j does
not allow a relationship to be the source or target of another
relationship.

## Decision

Store contradictions in a Postgres table:

```sql
CREATE TABLE fact_contradiction (
    tenant_id          TEXT        NOT NULL,
    fact_uuid_a        UUID        NOT NULL,
    fact_uuid_b        UUID        NOT NULL,
    verdict            TEXT        NOT NULL,
    detected_at        TIMESTAMPTZ NOT NULL,
    summary_a          TEXT        NOT NULL,
    summary_b          TEXT        NOT NULL,
    PRIMARY KEY (tenant_id, fact_uuid_a, fact_uuid_b)
);
```

`fact_uuid_a` and `fact_uuid_b` reference Graphiti `EntityEdge.uuid`
values. They are not pg foreign keys — Neo4j is the source of truth
for fact existence.

## Rationale

- Faithful to Neo4j's model: edges connect nodes, not other edges.
- Avoids inventing synthetic Entity nodes ("Contradiction_<uuid>")
  which would pollute Graphiti's entity graph and confuse the
  extractor.
- pg already owns `episode_metadata` and `content_embedding`. Adding
  one more table preserves the "Graphiti for graph storage; pg for
  retrieval-side metadata" boundary established in ADR-0004.
- `(tenant_id, fact_uuid_a, fact_uuid_b)` PK gives O(1) lookup and
  easy `UNION ALL` for stage 5 contradiction join in retrieval.

## Consequences

- Contradiction detection writes pg, not Neo4j. ADR-0004 reserves pg
  for retrieval-side metadata; this is consistent.
- Stage 7 of ingest (Q4 contradiction pipeline) does cosine search via
  raw Cypher against Neo4j's vector index on `EntityEdge.fact_embedding`,
  then writes the verdict to pg. The cosine search is a *read* against
  Neo4j; the write is to pg. Boundary preserved.
- Cross-tenant isolation enforced at `WHERE tenant_id = $tenant`.
- v0.2 supersession write paths must add a temporal filter to the
  retrieval-side join (`exclude contradictions where either fact has
  asserted_until <= $as_of`). Tracked in spec §5 stage 5.

## Alternatives considered

- **Edge property `contradicts: list[uuid]` on each EntityEdge.** Works
  but no relationship between counterpart edges is queryable
  symmetrically without two reads. Cypher must scan all edges to find
  contradictions involving a target uuid. Worse for retrieval.
- **Synthetic Entity nodes per contradiction.** Pollutes the entity
  graph, breaks the assumption that EntityNodes are real-world things.
  Confuses Graphiti's deduplication.

## Revisit triggers

- A future Graphiti version supports edge-of-edge relationships
  (unlikely; would need a Neo4j model change).
- Cross-tenant federated retrieval where a single SQL view across
  tenants is needed — a graph-side representation may simplify it.
