# ADR-0004: gnokee owns retrieval; Graphiti is the storage primitive

**Status:** Accepted
**Date:** 2026-05-08
**Refs:** ADR-0001 (build on Graphiti), Q1 spike `evals/spike_q1_graphiti/`,
Q2 spike `evals/spike_q2_multilingual/`

## Context

ADR-0001 accepted Graphiti as gnokee's bi-temporal knowledge-graph
primitive. The Q1 v2.1 spike landed at 12/12 capability passes using
`COMBINED_HYBRID_SEARCH_RRF` and a node-mention Cypher post-step. The
Q2 spike was scoped to validate bge-m3 cross-lingually through that
same retrieval path.

Q2 produced two findings that ADR-0001's framing did not anticipate:

1. **bge-m3 cross-lingual retrieval works** — proven by a separate
   harness (`evals/spike_q2_multilingual/direct_cosine.py`) that
   embeds episode content directly and ranks by cosine. **16/16
   probes rank target at position 1, controls 4/4 valid, cross
   top-3 = 100%.**

2. **Graphiti's retrieval API does not rank by query relevance at the
   corpus sizes gnokee will see.** Through `COMBINED_HYBRID_SEARCH_RRF`,
   the same 12-episode / 16-probe corpus scored **25% cross top-3**;
   every query returned the same fixed episode ordering regardless of
   query language or content. With distractors, single-entity episodes
   were systematically buried below multi-entity episodes.

Re-reading the Q1 v2.1 verdict in this light: the 12/12 ADOPT was
*recall-only* — every expected episode appeared *somewhere* in a
14–20 item returned list, but the rank distribution was structural
noise, not query-driven ranking.

## Root cause

Graphiti's `EpisodicNode` schema has no content-level embedding. Only:

- `name_embedding` on `EntityNode` (vector over the **entity name**,
  often a single short token like `гриппа` or `Тел Авив`)
- `fact_embedding` on `EntityEdge` (vector over LLM-extracted relation
  text, sparse for short factual notes)

`EpisodeSearchConfig` in `COMBINED_HYBRID_SEARCH_RRF` uses **BM25 only**
on episodes — there is no episode-content vector path. So short
single-fact episodes have no high-fidelity vector signal to ride into
top-K, and structural attributes (entity count, entity-name string
length, BM25 tokenization quirks) dominate the result order.

This is fine for Graphiti's documented use case (LongMemEval-style
conversational memory with reasonably long episodes that produce
multiple entities) and incompatible with gnokee's design target
(personal corpus + clinical observations, where individual episodes
are short factual notes).

## Decision

**Split storage and retrieval responsibilities:**

1. **Graphiti remains the bi-temporal storage primitive.** gnokee
   continues to call `client.add_episode(...)` with `reference_time` and
   `group_id`. Graphiti's `EpisodicNode.valid_at`, supersession via
   `expired_at` / `invalid_at` on edges, the entity-resolution graph,
   and the LLM extraction pipeline are still load-bearing for the
   *data model* gnokee promises (bi-temporal facts, contradiction
   surfacing, supersession with audit trail).

2. **gnokee owns the retrieval path.** `gnokee.query(...)` does not
   call `client.search()` or `client.search_()`. It executes a small
   Cypher query against the Graphiti-managed Neo4j store, embeds the
   user's query via bge-m3, and ranks `EpisodicNode`s by cosine
   similarity against a gnokee-managed `content_embedding`.

3. **Per-episode content embedding lives in pgvector**, **not in
   Graphiti**. gnokee writes `(tenant_id, episode_uuid, embedding)`
   into Postgres at ingest time, alongside the Graphiti `add_episode`
   call. This avoids forking Graphiti's schema and keeps the retrieval
   path independent of Graphiti version bumps. (Q5 — graph-store
   choice — is unaffected; pgvector was already in the v0.1 stack per
   `docs/architecture.md`.)

4. **Retrieval surface unchanged.** `gnokee.query()` still accepts
   `as_of`, `valid_at`, `surface_contradictions`, and `max_tokens` as
   declared in `docs/architecture.md`. Bi-temporal filters apply via
   gnokee-side Cypher constraints on `EpisodicNode.valid_at` (and the
   gnokee-managed `asserted_at` axis from ADR-0001 caveat 2), not via
   Graphiti's `SearchFilters`.

5. **Graphiti's edge facts are supplementary metadata, not primary
   retrieval.** gnokee may surface them in retrieval results
   (e.g. supersession chains, contradictions) but does not depend on
   `EntityEdge.fact_embedding` to find the right episode.

## Consequences

**Positive:**

- Decouples retrieval quality from Graphiti's release cadence — the
  gnokee retrieval layer evolves independently
- Lifts the structural "entity count dominates ranking" gap exposed
  by Q2 (bge-m3 direct cosine is already 100% on the same corpus)
- Restores the cross-lingual property the architecture promised —
  bge-m3 ranks correctly across en/ru/bg/he at the content level
- Keeps Graphiti's storage value (bi-temporal, audit trail,
  contradictions) without inheriting its retrieval limits

**Negative:**

- Two embedding indices (Graphiti's entity/edge embeddings inside
  Neo4j; gnokee's content embeddings in pgvector) — two write paths
  to keep coherent at ingest, two to clean up at forget
- Re-embedding cost when bge-m3 is replaced (gnokee owns the migration
  vs piggybacking on a Graphiti version bump)
- Slight schema duplication: episode UUID stored in both Neo4j and
  pgvector; tombstones must propagate to both

**Mitigations:**

- The two-index coupling is contained inside `gnokee.ingest_episode`
  and `gnokee.forget` — single transaction boundary
- pgvector and Neo4j are both already required by v0.1
  (`docker-compose.yml`), no new infrastructure
- `gnokee.adapters.graphiti` (planned in v0.1) wraps the
  `add_episode` + `pgvector.upsert` pair so retrieval and ingestion
  coupling stays in one place

## Spike-derived design constraints

Carried forward from the Q1 v2.1 caveats and the Q2 findings:

- **`asserted_at` separate from Graphiti's `created_at`.** Graphiti's
  `created_at = ingest time`, not "when the source asserted this
  fact". gnokee tracks `asserted_at` on `EpisodicNode` via
  `episode_metadata`; transaction-time queries filter on `asserted_at`
  (gnokee-side Cypher), not `created_at`.
- **Time filters apply at the episode level.** Graphiti's
  `SearchFilters` (`valid_at` / `invalid_at` on edges) is bypassed.
  gnokee filters `EpisodicNode.valid_at` directly in the retrieval
  Cypher query before computing cosine over candidates.
- **Edge-extraction loss is acceptable.** Q2 confirmed that bge-m3
  cosine on episode content recovers all 4 facts the Graphiti
  extractor missed at edge level. gnokee's primary retrieval path
  doesn't need edges to surface; edges remain useful for
  contradiction surfacing and supersession-chain walks.

## Open questions

These are *not* blockers for v0.1 retrieval but are flagged for
later resolution:

- **Auto-translation at ingest.** Graphiti's `gpt-4o-mini` extractor
  translates non-Latin episodes into English at edge extraction
  (Q2 Hebrew F4 became "Neovim", "LazyVim", "Helix" entities in
  English). For gnokee retrieval this doesn't matter — content is
  preserved verbatim on `EpisodicNode.content` and embedded in its
  source language. But for *contradiction detection across languages*
  (which uses LLM-extracted facts), translation may erase nuance.
  Track separately under Q9 (contradiction handling eval).
- **Cross-encoder rerank in v0.2+.** gnokee retrieval ships in v0.1
  as bge-m3 cosine + bi-temporal filter. Cross-encoder rerank
  (mxbai-rerank-large or jina-reranker-v2) is a v0.2 candidate once
  there is real user query data to evaluate against.
- **Episode embedding granularity.** Q2 used full-content embedding
  per episode. For longer episodes (>512 tokens), chunked embedding
  with within-episode pooling may be needed. Defer until corpus
  surfaces episodes that exceed bge-m3's effective context.

## Decision artifact

The Q2 direct-cosine harness (`evals/spike_q2_multilingual/direct_cosine.py`)
becomes the **template for the v0.1 retrieval implementation**:

  ```text
  embed query (bge-m3)
    → Cypher: MATCH (ep:Episodic) WHERE ep.group_id = $tenant
              AND <bi-temporal filters on ep.valid_at, ep.metadata.asserted_at>
              RETURN ep.uuid, ep.content_embedding_id
    → fetch embeddings from pgvector for the candidate set
    → cosine rank → top-K
    → join supplementary edge facts / contradictions for surfacing
  ```

The full implementation lands in `src/gnokee/retrieval/` as part of
v0.1.
