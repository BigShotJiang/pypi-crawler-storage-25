# ADR-0005: Graph backend trade-off space — Neo4j v0.1 and v0.2

**Status:** Accepted
**Date:** 2026-05-08
**Refs:** ADR-0001 (build on Graphiti), ADR-0004 (gnokee owns retrieval),
AGENTS.md "Currently-open decisions" (Q5)

## Context

ADR-0001 accepted Graphiti as the bi-temporal storage primitive.
ADR-0004 reassigned retrieval to gnokee. AGENTS.md still listed Q5
(Neo4j vs FalkorDB) as an open decision, with FalkorDB tentatively
positioned for a v0.2 swap.

Two pieces of research on 2026-05-08 changed the picture and forced a
re-decision:

1. **FalkorDB is SSPL v1**, not Apache 2.0. Verified directly from
   the upstream `LICENSE` file. SSPL §13 forces source disclosure for
   anyone offering FalkorDB-backed services to third parties. This
   maps directly onto Omur's planned multi-tenant SaaS deployment of
   gnokee. The v0.2 FalkorDB plan is not a license-compatible plan.

2. **Kùzu is archived** as of 2025-10-10 (verified via the GitHub
   API: `archived: true`). Even though graphiti-core 0.29 ships a
   `kuzu_driver.py`, the upstream project is dead and the driver is
   on a dead-end backend.

The question therefore widened: is there *any* graph backend worth
swapping to in v0.2 — and if so, what is the actual engineering cost?

## Research summary

Of the four backends with an in-tree Graphiti driver:

| Backend | License | Status |
|---|---|---|
| Neo4j Community | GPLv3 server / Apache 2.0 driver | Active, canonical, regression bar for every Graphiti release |
| FalkorDB | **SSPL v1** | Active, but license-incompatible with gnokee/Omur SaaS plans |
| Kùzu | MIT, **archived 2025-10-10** | Dead-end |
| AWS Neptune | Proprietary SaaS | Locked to AWS |

Of the candidates without a Graphiti driver, Apache AGE is the only
strong fit (Apache 2.0, Postgres extension — would collapse Postgres
+ pgvector + graph into one container). Other candidates rejected:

- **Memgraph** — BSL 1.1; SaaS-hostile clauses
- **TerminusDB** — Apache 2.0 but WOQL-only, leaves Graphiti
- **XTDB v2** — MPL-2.0 with native bi-temporal storage, but
  "burn the bridges" scope (rebuild Graphiti's entity-extraction
  pipeline from scratch); JVM runtime
- **CozoDB** — MPL-2.0, embedded, time-travel via validity param,
  but bus-factor of one and slowing 2025
- **SurrealDB** — BSL 1.1 core; bespoke query language; AI-memory
  marketing-heavy without code substance
- **AgensGraph** — Apache 2.0 but dormant fork of Postgres
- **JanusGraph** — Gremlin not Cypher; declining activity
- **DuckPGQ** — read-only graph matching, can't be primary store
- **NebulaGraph** — Apache 2.0 distributed, overkill for personal scale

## Effort: AGE driver vs staying on Neo4j

A focused engineering audit (Apache AGE Cypher coverage vs the
features Graphiti emits) lands the AGE driver at **5–7 person-weeks
realistic**, with two structural complications:

1. **Vector cosine.** AGE has no native cosine. The driver must
   intercept vector-search queries and rewrite them as a Cypher-then-SQL
   CTE that joins back to pgvector. AGE issue #1121 (first-class
   pgvector integration) is still a proposal, no PR. Until that lands,
   the workaround is a shadow-table sync between AGE writes and a
   pgvector mirror — moving parts.

2. **Fulltext.** AGE has no fulltext extension. The driver must
   intercept `CALL db.index.fulltext.queryNodes(...)` and rewrite
   against Postgres `tsvector` + `GIN` indexes. Doable but every
   Graphiti upstream change to the fulltext path becomes a merge
   conflict.

Plus the in-tree-driver expectation. graphiti-core ships its
alternative drivers in-tree (`graphiti_core/driver/`); there is no
plug-in entry point. An out-of-tree AGE driver lives in a fork until
upstream accepts a PR — graphiti issue #1095 (Dec 2025) is the
existing tracking issue and has no PR yet.

**Cost of staying on Neo4j:** near zero. Reference driver, every
Graphiti release regression-tested against it, mature ops surface,
pgvector already in the v0.1 stack so adding Neo4j is just one more
stateful service (~512MB–2GB RAM, separate backup, separate auth)
that gnokee already accepts.

**Break-even for the AGE swap:** the 5–7-week build plus the
ongoing translation tax on every Graphiti upstream release pays back
only if at least two of these hold:

1. gnokee is forced to ship single-binary on-prem under terms
   incompatible with Neo4j Community's GPLv3 server license
2. operational headcount cannot run two stateful services and
   consolidation eliminates a real role-shaped cost
3. gnokee plans to use Postgres-native features (RLS, logical
   replication, pg_partman) directly on graph data, not just on
   facts/embeddings tables

None of these are on the v0.1 or v0.2 roadmap.

## Decision

**Neo4j Community for v0.1 and v0.2.** Drop FalkorDB from the v0.2
plan (SSPL kills it). Defer AGE evaluation until at least one
break-even condition becomes concretely scheduled.

The "Apache 2.0 stack" goal is partially compromised regardless of
backend choice — Neo4j Community is GPLv3 at the server, Postgres is
PostgreSQL License (permissive but its own thing), pgvector is
PostgreSQL License. **gnokee code is Apache 2.0; storage backends
are external dependencies that consumers bring themselves**, same
model as pgvector users for Postgres. `docs/architecture.md`
captures this boundary explicitly.

## Re-evaluation triggers

Re-open this decision when any of the following becomes true:

- gnokee commits to a single-binary on-prem distribution requiring
  non-GPL terms — AGE moves up the priority list immediately
- AGE issue #1121 (first-class pgvector integration) lands and
  ships in an Apache AGE release — the realistic effort drops
  meaningfully (probably 3–4 person-weeks)
- A community Graphiti AGE driver appears upstream — gnokee adopts
  rather than authors
- Omur SaaS hits scaling cliffs that Neo4j Community can't address
  and a license-compatible swap is worth the migration cost
- Cozo recovers active development OR XTDB v3 ships an HTTP-only
  binary that doesn't require JVM ops — re-examines the
  "burn the bridges" path

## Footnote: the upstream contributions opportunity

If gnokee does eventually invest in an AGE driver, it would be
genuinely useful upstream — graphiti-core has had an open issue
(#1095) since December 2025 with no PR. Authoring the driver makes
gnokee a notable upstream contributor and keeps the v0.2 swap
coupled to graphiti-core's release cadence rather than a fork.
But this is opportunity, not obligation; ADR-0005 does not commit
to it.
