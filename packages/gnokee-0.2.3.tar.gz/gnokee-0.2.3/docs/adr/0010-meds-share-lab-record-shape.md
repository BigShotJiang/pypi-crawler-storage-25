# ADR-0010: Medication history shares the structured-clinical-data shape from ADR-0009

- **Status:** Accepted
- **Date:** 2026-05-09
- **Decider:** Vadim Yuzi
- **Context:** Q8 spike — `evals/spike_q8_med_supersession/`. Sibling
  validation to Q7 / ADR-0009 against the v0.1.1 stack.

## Context

Q8 ran a 12-episode synthetic medication timeline (start / dose-change /
stop / switch / allergy events spanning Aug 2023 – Jan 2025) through the
v0.1.1 recall pipeline (preprocessor + recall + currency-anchor +
excerpts), with 15 query patterns covering single-event dates,
time-pinned dose, current-state, drug-class history, side-effect
attribution, allergy recall, cross-domain (diuretic↔supplement) link,
all-active-meds-at-time-pin, and dose-change event detection.

The hypothesis going in: meds should fare better than labs (Q7) because
the load-bearing facts are noun-verb-object — "patient takes Lisinopril
20 mg daily" — not numeric measurements. graphiti's edge-fact extractor
preserves drug names and clinical narrative; it strips numbers.

## Result

| Verdict | Count | Examples |
|---|---|---|
| `pass` | 8 / 15 (53.3 %) | time-pinned dose post-change, after-stop status, why-stopped (cough), allergies, cross-domain link (furosemide → KCl), iron-supplementation resolved, active meds at time pin, dose-change presence |
| `partial` | 6 | start dates ("2024-02-01") and dose numerals ("10 mg", "100") absent from response despite right episode |
| `fail` | 1 | latest 2025 dose-change episode missed by cosine ranking on "current BP med" |
| `error` | 0 | — |

Headline: **53.3 % → ADOPT_WITH_GAPS** per the spike's
`>=80 / >=50 / <50` threshold.

The failure pattern is consistent with Q7: episode retrieval works
(every partial surfaced the right episode), but specific dates
(`2024-02-01`, `2024-09-20`, `2024-10-25`) and dose numerals (`10 mg`,
`100`) are dropped from `r.fact` text by the edge-fact LLM. Less
catastrophic than labs because the *narrative* — "patient stopped
Lisinopril due to cough" — does survive, and an Omur agent can call
`gnokee_fact_provenance(fact_uuid)` to recover the date / dose from the
original episode body. But that round-trip is unsafe to require for
every dose query in a clinical surface — the agent has to *know* it
needs to ask.

## Decision

**Medication history shares the structured-clinical-data direction
from ADR-0009.** The same `lab_record` table pattern extends to a
sibling `med_record` table, populated by the same parser-pipeline,
queried by a sibling `gnokee_med_query` MCP tool. Schema is intentionally
parallel so the two clinical domains share parser, ingest, and query
infrastructure.

```sql
CREATE TABLE med_record (
    tenant_id        TEXT        NOT NULL,
    episode_uuid     UUID        NOT NULL,
    drug_name        TEXT        NOT NULL,         -- "Lisinopril"
    rxnorm_code      TEXT        NULL,              -- when available
    drug_class       TEXT        NULL,              -- "ACE inhibitor"
    dose_value       NUMERIC     NULL,
    dose_unit        TEXT        NULL,              -- "mg"
    frequency        TEXT        NULL,              -- "daily", "BID"
    route            TEXT        NULL,              -- "PO", "IV"
    event_kind       TEXT        NOT NULL,          -- "start" | "increase" |
                                                    -- "decrease" | "stop"  |
                                                    -- "switch" | "allergy" |
                                                    -- "documented"
    reason           TEXT        NULL,              -- "cough", "anemia resolved"
    valid_at         TIMESTAMPTZ NOT NULL,          -- when the event happened
    valid_until      TIMESTAMPTZ NULL,              -- next event supersedes
    asserted_at      TIMESTAMPTZ NOT NULL,          -- when documented
    asserted_until   TIMESTAMPTZ NULL,
    PRIMARY KEY (tenant_id, episode_uuid, drug_name, event_kind, valid_at)
);
```

Bi-temporal half-pairs match `episode_metadata` and `lab_record`
(ADR-0009). Population priority unchanged from ADR-0009:

1. **Structured ingest** (FHIR `MedicationStatement` / `MedicationRequest`).
2. **Deterministic parser** — `gnokee.extract.rules.med_parser` extends
   the preprocessor pipeline to recognise "Started X mg PO daily" /
   "Increased X from N to M mg" / "Discontinued X" shapes and emit
   `med_record` rows alongside `Derived facts:`.
3. **LLM-extracted** — only for free-form prose; consumer's endpoint.

`gnokee_med_query` exposes typed reads:
`current(tenant, drug?, drug_class?)`,
`history(tenant, drug, range?)`,
`active_at(tenant, valid_at)`,
`allergies(tenant)`,
`switches(tenant, drug?)`. Mirrors `gnokee_lab_query` shape.

`RecallResponse` gains a `med_rows[]` field next to `lab_rows[]` for
the consumer-facing recall path; backwards compatible (empty when
no med terms).

## Why not adopt-as-is at 53.3 %

The threshold says `ADOPT_WITH_GAPS` — gaps documented; ship as-is
plus a typed gap-filler. Two narrower mitigations exist short of the
table:

- **Preprocessor extension.** Add a `med_event` rule alongside
  `currency_anchor` that lifts dates and doses into derived sentences
  ("Lisinopril dose increased from 10 mg to 20 mg on 2024-06-15").
  Cheap. Probably moves the headline to ~70 %. Doesn't fix the
  current-state ranking miss (episode #1 — `q_current_bp_med` — failed
  for cosine reasons, not extraction).
- **Recall-side excerpts on med queries.** Extend `gnokee.excerpts`'s
  `query_wants_excerpt` heuristic to also fire on med-keyword tokens
  (`took`, `stopped`, `dose`, `mg`, drug-name lexicon). Lifts dates
  and doses verbatim into the response, same way amount-bearing
  excerpts do today.

Both are cheap and v0.1.x-scoped; neither replaces the structured table
for typed reads ("active meds at 2024-07-01" — graphiti recall returns
the right episodes but cannot answer "is there one canonical row per
drug"). v0.2 ships the typed table; v0.1.x can land the preprocessor
extension and the excerpt heuristic if the ADR-0009 implementation
slips.

## Consequences

- **Schema:** `med_record` lands alongside `lab_record` in the same
  v0.2 migration; their parsers are siblings under
  `gnokee.extract.rules.clinical.*`.
- **MCP surface:** `gnokee_med_query` lands with `gnokee_lab_query`.
  Tool-listing token budget rises; mitigated by the
  `mcp-tool-designer` agent's compact-description discipline.
- **Cross-domain queries** (Q7's `q_furosemide_lab_link`, Q8's
  `q_furosemide_kcl_link`) work today *because* the narrative survives
  graphiti's extraction. The structured tables strengthen the typed
  half; the cross-domain answer still threads narrative through
  `gnokee_recall`.
- **Out of scope for v0.1.x.** Same as ADR-0009. Implementation lands
  before clinical Omur tag-cut.

## Status notes

- **Schema landed:** migration `0007_med_record.sql` (commit on
  2026-05-09). Sibling to `lab_record` from ADR-0009.
- **Write path landed:** PR #9 — deterministic prose parser
  `extract/clinical/med_parser.py` writes `med_record` rows inside
  Stage 6 of the ingest txn. Distinct from the existing
  `extract/rules/med_event.py` preprocessor, which keeps emitting
  derived sentences for graphiti's narrative half.
- **Read path landed:** PR #11 (`feat(mcp): gnokee_med_query — typed
  medication-history reads (ADR-0010)`) — `med_query.py` orchestrator
  + `gnokee_med_query` MCP tool with `active | history | allergies |
  switches` ops. `active` uses `DISTINCT ON drug_name` latest visible
  event excluding stop / allergy. Both bi-temporal half-pairs
  mandatory.
- **v0.2 re-spike (2026-05-09, fresh tenant `spike-q8-v0_2`):**
  pass = **15/15 (100 %) → ADOPT**, up from v0.1.1's
  **8/15 (53.3 %) ADOPT_WITH_GAPS**. Crosses the 80 % adopt threshold
  with no remaining failures or partials. (Initial v0.2 run scored
  14/15; the lone partial `q_lisinopril_dose_at_2024_10_01` resolved
  once `event_kind` was rendered in human form (`stop` →
  `discontinued`) so `value_substring="discontin"` matches.)
- Spike artefacts: `evals/spike_q8_med_supersession/`. Re-runnable
  per README.
- ADR-0009 not amended — this ADR extends the same direction to a
  parallel domain rather than revising the lab decision.
- Q9 (wearable throughput) remains open. Wearables are a *cost*
  problem (millions of events/year), not a *summarisation* problem
  like Q7 / Q8 — the off-ramp will look different.
- **v0.2.1 supersession-aware ingest landed** (commit on 2026-05-09).
  Same `EpisodeIn.corrects` boundary applies to `med_record`; key
  granularity is `(drug_name, event_kind, valid_at)`. Q8 re-spike
  (fresh tenant `spike-q8-v0_2_1c`) extends to **16 queries** with the
  new `q_metoprolol_dose_corrected` exercising the corrects: signal
  end-to-end (synthetic Metoprolol start at 25 mg corrected to 50 mg).
  Pass = **16/16 (100 %)**. Verdict stays ADOPT. Confirms med-side
  parity with the lab-side fix.
  Methodology note: the synthetic correction targets a drug NOT in
  the existing 12-episode corpus (Metoprolol), keeping it orthogonal
  to all dose-pinned queries on Lisinopril / Furosemide / Losartan /
  KCl / iron. An earlier attempt that corrected the Lisinopril start
  dose regressed two pre-existing queries because their value
  expectations (10 mg) clashed with the corrected dose (20 mg) —
  documenting the trap so future spikes pick orthogonal drugs.
