# Eval methodology

> Placeholder. Full methodology lands as part of the v0.1 spec.

## Why this matters

Per Notion `10 — Open Questions / Backlog` Q9: gnokee's credibility is
**published eval numbers**, not feature lists. Mem0 reports 91.6 on
LoCoMo / 93.4 on LongMemEval; we will benchmark against those plus
gnokee-specific corpus tasks.

## Target dimensions

- **Temporal queries** — "what did I think about X in March?"
- **Contradiction handling** — % of conflicts surfaced honestly vs silently picked
- **Multilingual retrieval** — cross-language F1 on a held-out set (English,
  Russian, Bulgarian, Hebrew at minimum — Vadim writes in those four)
- **Token efficiency** — mean tokens per query vs answer quality
- **Forgetting completeness** — does `forget(X)` actually remove X from all
  retrievable surfaces?

## Datasets

To be defined. Likely shape:

- Synthetic personal corpus (devops notes, journal, finance, IDE preferences)
- Redacted Omur-shaped health data (lab corrections, medication changes,
  retroactive diagnoses)
- LoCoMo + LongMemEval for comparability with Mem0 / Graphiti / others
  (don't optimize for these — they're conversation-memory; gnokee is
  corpus-memory)

## Reproducibility

Each release tag must include:

- The eval scripts that produced the headline numbers (in `evals/`)
- The dataset version or generation seed
- The hardware profile + exact dependency versions

## Comparison candidates

Run the same eval set against:

- Graphiti alone (validates that gnokee adds value over the primitive)
- Mem0
- basic-memory
- mcp-memory-service (doobidoo)

Report deltas, not absolute numbers, when honest comparisons require
different feature sets.
