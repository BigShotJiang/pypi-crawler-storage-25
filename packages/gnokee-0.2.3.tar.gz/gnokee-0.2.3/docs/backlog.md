# gnokee backlog

Living index of post-v0.2.1 work. Each item links to its tracking GitHub issue. Items get promoted from this doc to a release scope (v0.2.x maintenance, v0.3, etc.) as they pick up momentum.

Source of truth is the GitHub issue. This doc is the table of contents.

## v0.2.x — maintenance

| # | Title | Driver | Effort |
|---|---|---|---|
| [#17](https://github.com/gnokeelabs/gnokee/issues/17) | Partial index on `lab_record`/`med_record` for supersession perf | Pure perf win as supersession ratio grows; non-load-bearing for correctness | S — 1 migration + EXPLAIN check |
| [#18](https://github.com/gnokeelabs/gnokee/issues/18) | `gnokee_lab_query` — abnormal-flag filter op | Reclaims `q_electrolyte_abnormal_q2` PARTIAL→FAIL regression introduced by v0.2.1 supersession on the recall path | S — new op or arg + harness re-spike |
| [#19](https://github.com/gnokeelabs/gnokee/issues/19) | `gnokee_recall` visibility on supersession-closed episodes | Decide A (leave + document), B (mixed visibility), or C (chain-walked recall). Footgun surfaced by Q7 v0.2.1 re-spike | M — design call + impl |

## v0.3 — release scope

| # | Title | Driver |
|---|---|---|
| [#16](https://github.com/gnokeelabs/gnokee/issues/16) | Lite ingest mode + integration patterns doc + eval-delta gate | Omur Phase-0 telemetry path: `add_episode` LLM extraction dominates ≥80 % of latency at high cadence |
| [#22](https://github.com/gnokeelabs/gnokee/issues/22) | `encrypted_body` branch — wire DEK + KMS pathway | v0.1 deferred via `NotImplementedYet`; clinical Omur consumers need it before phase-1 ship |

## Distribution

| # | Title | Driver |
|---|---|---|
| [#20](https://github.com/gnokeelabs/gnokee/issues/20) | First PyPI publish | Currently only `0.0.0` placeholder; v0.1/v0.2 tags ship via GH only. Decide cadence + workflow before first publish |

## Tooling / cosmetic

| # | Title | Driver |
|---|---|---|
| [#21](https://github.com/gnokeelabs/gnokee/issues/21) | Spike harness env-var alignment (`GNOKEE_SPIKE_SKIP_INGEST=1`) | Q1–Q8 use `argparse --skip-ingest`; template prescribes env-var. Cosmetic, low priority |

## How to add an item

1. Open a GitHub issue with a 1-line title and a short body covering: problem / decision / acceptance.
2. Label with the target release (`v0.2.x`, `v0.3`, etc.) and a category (`enhancement`, `documentation`, etc.).
3. Add a row to the appropriate table above. Keep the description column to one driver-sentence — the issue carries the detail.

## Closed since v0.2.1 ship

- Issue #15 — `chore(release): v0.2.0 typed clinical reads` — landed.
- Issues #2 / #3 / #4 / #5 / #6 / #7 / #8 — v0.1.1 extraction-quality work, all closed before v0.2.0.

ADRs that surface implicit backlog items but are not yet tracked as issues:
- ADR-0011 (wearables off-ramp) — depends on consumer TimescaleDB integration; not gnokee work.
- ADR-0008 (contradiction storage) — Q4 closed; orthogonal to supersession.
