# AGENTS.md

Conventions for Claude Code (and any other agent) working on this repository.

## Project identity

- **Name:** `gnokee` (was working name `Veda`; rebranded 2026-05-07).
- **Purpose:** memory infrastructure for personal AI — bi-temporal facts, contradiction surfacing, autonomous maintenance, verifiable forgetting. MCP-native.
- **Two-customer test:** must comfortably serve both Omur (managed health-AI SaaS) and personal-AI agents. If only one is happy, design is wrong.

## Source of truth

Notion design pages were the source of truth pre-implementation. As of first commit, **this repo is canonical**:

- `docs/architecture.md` supersedes Notion 01 — Architecture
- `docs/adr/*.md` capture decisions (one file per decision)
- `docs/specs/*.md` capture feature specs
- `docs/evals/*.md` capture eval methodology + results

When updating Notion vs the repo: updates land in the repo first; Notion mirrors only as a discoverability surface.

## Stack

- **Python 3.10+** (pyproject.toml min — relax later if Graphiti requires)
- **Build:** hatchling (`pyproject.toml`)
- **Lint:** ruff
- **Type-check:** mypy (strict on `src/gnokee/`)
- **Test:** pytest
- **Format:** ruff format (no separate black)
- **Compose stack:** Postgres+pgvector, Neo4j (Graphiti default), HuggingFace TEI for bge-m3 embeddings

## Naming

- Container images: `gnokeelabs/<name>:<tag>`
- Python modules: `gnokee.<area>` (e.g. `gnokee.ingest`, `gnokee.retrieval`)
- MCP tools: `gnokee_<verb>` (e.g. `gnokee_query`, `gnokee_ingest_episode`, `gnokee_forget`)
- Env vars: `GNOKEE_<NAME>` (e.g. `GNOKEE_DB_URL`, `GNOKEE_TENANT_DEFAULT`)

## Hard "do not" list

- Do **not** add UI, chat shells, or front-end code (gnokee is headless)
- Do **not** vendor an LLM (consumer supplies via OpenAI-compatible endpoint)
- Do **not** add federation, ActivityPub, ATProto, IPFS, or Solid into core (separate adapter repo if ever)
- Do **not** auto-resolve contradictions (surface to LLM, never pick a winner)
- Do **not** delete superseded facts (use tombstones / supersession with audit trail)
- Do **not** hold encryption keys (consumer KMS owns DEKs; arch invariant — "no key" pun)

## Pre-v0.1 priority

Per *10 Open Questions* on Notion:

1. ~~**Q1 Graphiti spike** (`evals/spike_q1_graphiti/`)~~ — **done 2026-05-08, ADOPT as storage primitive**, see [ADR-0001](docs/adr/0001-build-on-graphiti.md).
2. ~~**Q2 multilingual eval** (bge-m3 cross-lingual)~~ — **done 2026-05-08, ADOPT bge-m3 (100% top-1 via direct cosine); retrieval reassigned to gnokee**, see [ADR-0004](docs/adr/0004-gnokee-owns-retrieval.md).
3. ~~**Q3 MCP token-efficiency benchmark** (`evals/spike_q3_token_efficiency/`)~~ — **done 2026-05-08, ADOPT gnokee shape**: 59.7% token reduction at 91.7% top-3 recall (Graphiti-raw was 50% recall at 321 mean tokens vs gnokee 91.7% at 129).
4. **v0.1 implementation** — next

All three pre-v0.1 spikes resolved 2026-05-08. The trio jointly
produced one architectural pivot — Graphiti is the bi-temporal
**storage** primitive; gnokee owns **retrieval** via per-episode
bge-m3 embeddings in pgvector + Cypher-side bi-temporal filters
(ADR-0004) — and one validated response-shape (compact natural-language
fact statements with lazy provenance handles, per
`docs/architecture.md` Retrieval contract). v0.1 implementation can
begin.

## Workflow

- Branch per feature; one feature per PR
- PR title format: `<area>: <imperative description>` (e.g. `ingest: validate language tag against ISO 639-1`)
- Every PR includes test changes (or explicit `no-test-needed:` rationale in description)
- Eval-suite changes require a results delta posted in PR description

## Commit message style

- Conventional Commits subjects: `feat(area): ...`, `fix(area): ...`, `docs: ...`, `chore: ...`
- Body explains *why* (not what — diff shows what)
- Reference Notion entries when ported (e.g. `Refs Notion: 01 Architecture § Multi-tenancy`)

## Currently-open decisions

- ~~Q5 graph store: Neo4j vs FalkorDB~~ — **resolved 2026-05-08, see [ADR-0005](docs/adr/0005-graph-backend-tradeoff.md)**: Neo4j Community for v0.1 *and* v0.2. FalkorDB dropped on SSPL grounds (license-incompatible with Omur SaaS plans). Kùzu archived 2025-10-10. Apache AGE evaluated at 5–7 person-weeks realistic effort with structural blockers on vector cosine + fulltext; deferred until on-prem-non-GPL or ops-consolidation triggers materialise.
- Q6 embeddings deployment: TEI default, Ollama dev fallback
- v0.1 packaging: single binary vs compose-stack (compose first, single-binary later)

When you encounter ambiguity in scope, prefer the *smallest* change that closes the immediate need; record open questions in `docs/adr/` rather than guessing.

## Subagent routing

gnokee ships a project-specific crew under `.claude/agents/`. `gnokee-reviewer` is the **lead reviewer / front door** — it skims the diff, flags AGENTS.md-level invariants, and routes domain-specific concerns to specialists. **Cap: max 2 specialists per PR**; beyond that, `gnokee-reviewer` integrates findings itself rather than producing N disjoint reviews. Specialists do not chain — they flag-and-stop.

| PR scope / path / pattern | Specialist |
|---|---|
| General PR review (always) | `gnokee-reviewer` (lead) |
| Cypher syntax (any `execute_query` or `.cypher`) | `cypher-reviewer` |
| graphiti-core API (`add_episode`, `search_`, `SearchFilters`, recipes, `LLMConfig`) | `graphiti-specialist` |
| Neo4j ops (docker-compose, neo4j.conf, vector-index DDL, plan analysis) | `neo4j-ops-specialist` |
| Postgres / pgvector (migrations, RLS, schema, autovacuum, encrypted-body) | `postgres-pgvector-specialist` |
| Ingest path (`src/gnokee/ingest/**`, `add_episode` callsite, boundary validation) | `ingest-pipeline-specialist` |
| Prompts (extraction / contradiction / synthesis templates) | `prompt-specialist` |
| Embedding model / dim / Q6 parity / re-embed migration | `embedding-specialist` |
| New `gnokee_*` MCP tool surface | `mcp-tool-designer` |
| Bi-temporal logic (`valid_at`, `asserted_at`, `created_at`, supersession, time-travel) | `bi-temporal-auditor` (additive — layered on top of path-triggered specialist, still under cap) |
| New eval spike under `evals/spike_q*/` | `eval-spike-author` (sole reviewer; methodology PRs don't need cross-stack review) |

ADR-only PRs (`docs/adr/*.md` with no code) bypass routing — main thread reviews directly.
