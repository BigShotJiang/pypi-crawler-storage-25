# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.3] — 2026-05-09

First PyPI publish (closes #20). Restructures install UX so naked
`pip install gnokee` works and the wheel ships without duplicate
migration files. No retrieval / ingest behaviour changes; no new
migrations.

### Added

- **`.github/workflows/pypi-publish.yml`** — Trusted Publishing
  (OIDC) workflow that builds sdist + wheel on `v*` tag pushes,
  guards against duplicate-entry regressions in the wheel, and
  uploads to PyPI (or TestPyPI via `workflow_dispatch`) without a
  stored API token.

### Changed

- **`[core]` extras → mandatory `dependencies`.** `gnokee/__init__.py`
  eagerly imports `ingest` + `retrieval`, both of which need
  `asyncpg` / `graphiti-core` / `neo4j` / `pgvector` / `httpx` /
  `openai` / `structlog` / `langdetect`. Naked `pip install gnokee`
  used to `ImportError` on first import; it now works. The `[core]`
  extra is retained as a no-op alias so existing `pip install
  gnokee[core]` invocations keep working without surprise.
- **`gnokee.__version__` now reads from `importlib.metadata`** so it
  stays in sync with `pyproject.toml` automatically. Was hardcoded
  to `"0.1.0"` since v0.1, drifting silently across every release.
- **README install line** drops the `[core]` extra (now redundant);
  recommended dev install becomes `pip install -e ".[mcp,dev]"`.

### Fixed

- **Wheel no longer ships duplicate migration SQL files.** The
  `tool.hatch.build.targets.wheel.force-include` directive was
  redundant with `packages = ["src/gnokee"]` and caused each
  `0001…0008_*.sql` to appear twice in the wheel zip (eight
  `UserWarning: Duplicate name` warnings on every build, ~12 KB
  unnecessary payload). The new pypi-publish workflow has a
  regression guard step that fails CI on any future duplicate.

## [0.2.2] — 2026-05-09

Maintenance bundle closing the three named v0.2.1 footguns plus a CI
hardening pass. Q7 lifts to **11/15 (73.3 %)** via a new typed
`op=abnormal`. Recall now surfaces a `supersession_hints[]` discovery
field instead of either hiding superseded episodes silently or
surfacing their stale narratives unsafely. Storage gains partial
indexes on the open subset of `lab_record` / `med_record` so
supersede UPDATEs scale with the open-subset cardinality, not the
full PK. Net: backwards-compatible — no v0.2.1 contract changes; one
new migration (`0008_supersession_partial_indexes.sql`).

### Added

- **`gnokee_lab_query` `op=abnormal`** (issue #18). Returns visible
  `lab_record` rows whose `abnormal_flag` is set within an optional
  `(since, until]` window. `analyte` is optional for this op so
  callers can ask "which electrolytes were abnormal?" without naming
  every analyte upfront; when supplied, it acts as a narrowing
  filter. Both bi-temporal half-pairs apply identically to the other
  read paths so retroactive corrections honour `as_of` / `valid_at`.
- **`gnokee_recall.supersession_hints[]`** (issue #19, ADR-0009 status
  note). When cosine ranks a superseded episode in the top-K, recall
  now emits a `SupersessionHint(superseded_uuid, current_head_uuid,
  superseded_at)` instead of surfacing the stale narrative. Closes
  the v0.2.1 footgun where row-level data on unrelated analytes
  remained open while episode-level supersession hid the original
  panel from default recall. Decision: Option A+ (clinical-safe —
  stale narrative never surfaces; agent follows up via
  `gnokee_lab_query` / `gnokee_med_query` typed reads, or pins
  `as_of` pre-correction). Hint cap = 5 per recall;
  `RecallResponse.supersession_hints` defaults to empty list
  (backwards compatible).
- **`MetadataStore.chain_head_at(tenant, start_uuid, as_of)`** —
  read-only chain-walk used by retrieval to resolve hints to their
  current head. Bounded depth = 32 (matches `supersede`).

### Changed

- **`gnokee_lab_query.analyte` is now optional** at the typed-pipeline
  surface (`str | None`). It remains required for every op except
  `abnormal`. The validator raises `ValidationError("analyte is
  required")` for any other op when missing.

### Performance

- **Partial indexes on the open subset of `lab_record` / `med_record`**
  (issue #17, migration `0008_supersession_partial_indexes.sql`). New
  `lab_record_open_idx` and `med_record_open_idx` cover only rows
  where `asserted_until IS NULL` so `LabStore.supersede_matching` /
  `MedStore.supersede_matching` walk an index whose size is bounded by
  the open-subset cardinality instead of the full PK. Read paths
  (`latest`, `history`, `aggregate`, `abnormal`) are unaffected by
  design — they need closed-but-tx-time-valid rows for pre-correction
  `as_of` pins. Pure perf win; non-load-bearing for v0.2.1
  correctness (the PK still satisfies the UPDATE if the planner
  prefers it for any reason). Apply with `make migrate`.

### Evals

- Q7 re-spike on the v0.2.2 stack (`spike-q7` tenant,
  `--skip-ingest`) lifts headline pass = **11/15 (73.3 %)** (was
  10/15 / 66.7 % at v0.2.1 ship). `q_electrolyte_abnormal_q2` flips
  PARTIAL → **PASS** via the new typed `abnormal` op. Verdict stays
  ADOPT_WITH_GAPS.
- Q8 re-spike unchanged (16/16 — already at ADOPT ceiling at v0.2.1).

### CI / tooling

- **Dependabot** (PR #26) — weekly Monday updates for `pip` (root
  pyproject), `github-actions`, and `docker` (compose image tags).
  Eval-spike `requirements.txt` files deliberately excluded (frozen-
  in-time records per AGENTS.md spike workflow).
- **`pip-audit` CI job** (PR #26) — scans `pyproject.toml`-declared
  deps against the PyPI advisory DB on every push and PR. Currently
  green ("No known vulnerabilities found").
- **`gitleaks` CI job** (PR #26) — server-side secret-scan backup
  for the local pre-commit hook. Pinned to v8.21.2 to match
  `.pre-commit-config.yaml`.

### Migration

```sh
make migrate   # applies 0008_supersession_partial_indexes.sql
```

No application-code changes required for upgraders.

## [0.2.1] — 2026-05-09

Supersession-aware ingest. The named v0.2.0 follow-up gap closes:
correction episodes now propagate `asserted_until` to prior
`lab_record` + `med_record` rows and to `episode_metadata`. Q7's
`q_k_lowest_2024` flips from FAIL to PASS (typed `min` aggregation
now skips superseded values).

### Added

- **`EpisodeIn.corrects: UUID | None`** boundary signal. When set,
  declares this episode supersedes a prior one. Same-tenant only;
  corrected episode must exist; new `asserted_at` must be greater
  than the corrected episode's. Chain-walk follows `superseded_by`
  to the current head when the caller named a stale target.
- **3 new storage primitives.** `MetadataStore.supersede`
  (validates + walks the chain via `SELECT … FOR UPDATE` per hop;
  depth bound 32 raises `CorrectsChainError`),
  `LabStore.supersede_matching` (per-row `(analyte, valid_at)`
  UPDATE), `MedStore.supersede_matching` (per-row
  `(drug_name, event_kind, valid_at)` UPDATE). All parameterised on
  `tenant_id` + the chain-walk-resolved head's `episode_uuid`.
- **4 new typed errors:** `CorrectsError` (base) +
  `EpisodeNotFoundError`, `CorrectsCrossTenantError`,
  `CorrectsAxisInversionError`, `CorrectsChainError`. All subclass
  `VectorStoreError`, so the existing Stage 6 compensate path rolls
  back the Graphiti episode.
- **Module-level `ingest_episode(...)` helper** gains
  `corrects: UUID | None = None`. Backwards-compatible.
- **Stage 6 wiring.** Supersession runs inside the existing
  single-txn block, between the `metadata.write` insert (which
  guards `_OurIdRaceLost`) and the `vector.write_embedding` insert.
  On row-level partial-key UPDATE (count < `len(keys)`), Stage 6
  logs a `WARNING` — surfaces parser drift on `valid_at` rounding
  rather than a silent zero-match.
- **11-case integration suite** at
  `tests/integration/test_supersession_e2e.py`: lab + med happy
  paths, episode-metadata supersession, aggregation respects
  supersession (Q7's named bug), cross-tenant rejection, episode
  not found, axis inversion, chained correction, empty new rows
  with corrects, idempotent replay, chain-walk from stale target.

### Fixed

- **Q7 `q_k_lowest_2024`** — typed `MIN(value_numeric)` over
  Potassium 2024 now returns 3.2 mmol/L (March, open) instead of
  2.8 mmol/L (April, superseded). Q7 verdict stays ADOPT_WITH_GAPS
  (10/15) — the fix is offset by a designed-correct regression on
  `q_electrolyte_abnormal_q2`: episode-metadata supersession hides
  the original April panel from default `gnokee_recall`, breaking
  a query that expected both the original (Mg LOW) and the
  correction. The agent should query `gnokee_lab_query` typed
  surface for abnormal-flag filtering, or pin `as_of` pre-correction.

### Spike harness

- Q7 + Q8 `ingest_corpus` helpers gain `corrects:` plumbing — read
  an optional `corrects: <our_id>` from corpus entries and resolve
  to the runtime `episode_uuid` via the harness's growing
  `our_id → episode_uuid` map. Corpus entries referencing
  `corrects:` MUST appear after their target in file order.
- Fresh re-spike tenants `spike-q7-v0_2_1` and `spike-q8-v0_2_1c`
  — re-running against the v0.2.0 tenants would short-circuit on
  `our_id` idempotency and skip Stage 6 entirely.
- Q8 extends to 16 queries: new `q_metoprolol_dose_corrected`
  exercises the corrects: signal on med-side via a synthetic
  Metoprolol start (25 mg) + correction (50 mg). Picked an
  orthogonal drug to avoid clashing with existing Lisinopril
  dose-pinned queries. Q8 re-spike: **16/16 (100 %)**, verdict
  stays ADOPT.

### Known limitations

- **Graphiti edge supersession is NOT auto-run.** Narrative
  corrections continue to flow through ADR-0008 contradiction
  surfacing. ADR-0009 boundary holds: graphiti owns prose, gnokee
  owns the typed half. Correcting an episode does not retract its
  edges from the graph.
- **Episode-metadata supersession hides original episodes from
  `gnokee_recall`** even when their unrelated rows (e.g. Mg LOW
  on a panel where only K was corrected) remain row-level open.
  Designed-correct per the bi-temporal model, but biases recall
  away from row-level data on superseded episodes. Workaround: use
  `gnokee_lab_query` / `gnokee_med_query` for typed reads, or pin
  `as_of` pre-correction for narrative recall.
- **Encrypted-body branch is unaffected** — `corrects` is
  metadata, orthogonal to the body shape. Encrypted-body remains
  `NotImplementedYet` per v0.1 guard.

## [0.2.0] — 2026-05-09

Typed clinical-data reads land — first net-new MCP surface since v0.1.
Closes the v0.1.x carry-over from ADR-0009 (Q7 labs OFF-RAMP at 13.3 %)
and ADR-0010 (Q8 meds ADOPT_WITH_GAPS at 53.3 %): structured Postgres
siblings to graphiti's narrative half preserve the numerics the
edge-fact LLM was stripping. Q7 lifts to 66.7 % (ADOPT_WITH_GAPS); Q8
lifts to **100 %** (ADOPT) once `event_kind` is rendered in human
form. Purely additive — no v0.1 contract changes.

### Added

- **`gnokee_lab_query` MCP tool** (ADR-0009) — typed reads against the
  new `lab_record` table. Ops: `latest | history | min | max | avg |
  count` over `(tenant, analyte, date_range)`. Returns parsed
  `value_numeric` / `unit` / `ref_range_*` / `abnormal_flag` plus the
  `episode_uuid` provenance handle. Both bi-temporal half-pairs
  mandatory.
- **`gnokee_med_query` MCP tool** (ADR-0010) — sibling typed reads
  over `med_record`. Ops: `active | history | allergies | switches`.
  `active` returns one row per drug whose latest visible event isn't
  `stop` / `allergy`; pin `valid_at` for historical "active on …".
- **`gnokee.extract.clinical.{lab_parser,med_parser}`** — pure-Python
  deterministic parsers. Lab: bullet-line panel shape (`- Analyte:
  value unit (ref: low-high)`). Med: sentence-boundary med-event
  shapes (`Started X N mg`, `Increased X from N to M mg`,
  `Discontinued X`, `Allergy documented: X`). Never raise; empty
  parse → no rows.
- **Stage 6 ingest writes lab + med rows** — `IngestPipeline.ingest()`
  Stage 6 now writes `lab_record` + `med_record` rows inside the same
  Postgres txn as `episode_metadata` + `content_embedding`, so
  retroactive corrections stay atomic with the narrative episode.
- **`gnokee.{lab_query,med_query}` orchestrators** — sit between the
  MCP layer and the storage adapters; clean tach boundary (mcp does
  not reach into `gnokee.storage.*` directly).
- **Integration tests** — `tests/integration/test_clinical_lab_e2e.py`
  + `tests/integration/test_clinical_med_e2e.py`. 11 tests covering
  ingest writes, all typed-read ops, valid_at-pinned active, tenant
  isolation, against real Postgres + Neo4j + TEI.
- **Re-spike harnesses** — Q7 + Q8 `queries.yaml` gained per-query
  `typed: {tool, op, args}` blocks; spike `run.py` merges typed
  responses into `value_substring` grading. Recall path stays as
  v0.1.1 baseline reference, typed calls are additive.
- **Docs** — new `docs/specs/v0.2.md` captures the additive surface;
  ADR-0009 / ADR-0010 status notes amended with v0.2 headline +
  remaining-gap inventory; README tools-surfaced list expanded.
- **noggin sister repo** — bumped 0.0.1 → 0.0.2 with prompt guidance
  teaching the agent when to reach for the typed clinical tools.

### Known limitations

- **Supersession-aware ingest is incomplete.** A correction episode
  writes a new `lab_record` row but does not set `asserted_until` on
  the prior row — visible `MIN(value_numeric)` therefore still
  includes superseded values. Tracked as v0.2.1 candidate; needs an
  explicit `corrects: episode_uuid` signal from the caller per
  ADR-0009.
- **Q7 5/15 still partial** (cross-domain narrative, count→episode
  backfill, multi-analyte abnormal filter, narrative-only correction
  audit). Documented in ADR-0009 status notes.

## [0.1.2] — 2026-05-09

Cheap-path recall improvements and v0.2 schema groundwork. Q8 (med
supersession) lifts from 53.3 % → 73.3 % (ADOPT_WITH_GAPS) on the same
graph just from recall-side changes. v0.2 implementation follows under
ADR-0009 + ADR-0010.

### Added

- **`med_event` preprocessor rule** (`src/gnokee/extract/rules/med_event.py`)
  — fifth deterministic rule lifting `Started X N mg` / `Increased X
  from N to M mg` / `Discontinued X` / `Allergy documented: X` shapes
  into short SVO derived sentences so graphiti's edge-fact extractor
  preserves the drug-name + dose tuple. ADR-0010 cheap-path piece.
- **Med-aware excerpt path** (`src/gnokee/excerpts.py`) —
  `query_wants_excerpt` now fires on med tokens (`medication / dose /
  allergic / mg / mcg / mEq / drug-class names`); new `find_med_excerpt`
  surfaces verbatim Episodic.content med-event lines as a sibling to
  `find_currency_excerpt`. Body-side finders are English-aware for
  v0.1.x; non-EN bodies fall back to facts and v0.2 typed reads.
- **Date prefix on excerpts** — every `Excerpt.text` is prepended with
  `[YYYY-MM-DD]` from the episode `valid_at`, so date-asking variants
  ("when was the renovation invoice?") can quote the date even when
  the body says "today". Inner `max_chars` adjusts so total stays ≤
  `DEFAULT_EXCERPT_CHARS`.
- **Recency rerank** (stage 3c) — when the query carries a temporal-
  current marker (`currently / now / today / latest / current / active /
  am i on / am i taking`), the cosine top-K is sorted by `valid_at` desc
  before fact fetch, so "what am I currently on?" picks the most recent
  semantically-near episode instead of the highest cosine match.
  English markers only; non-EN time-pin reads land in v0.2 typed
  `med_record` / `lab_record`. Unit-tested via `_query_wants_recency` +
  `_sort_by_recency`.
- **`lab_record` schema** (`migrations/0006_lab_record.sql`) — Postgres
  table per ADR-0009. Stores parsed analyte / value_numeric / unit /
  ref_range / abnormal_flag with bi-temporal half-pairs matching
  `episode_metadata`. ON DELETE CASCADE so tenant forgetting is clean.
  Indexes for time-pin / range / supersession reads.
- **`med_record` schema** (`migrations/0007_med_record.sql`) — sibling
  Postgres table per ADR-0010 with drug_name / drug_class / dose /
  event_kind. Partial indexes for drug-class history (NOT NULL) and
  allergy lookups (`event_kind = 'allergy'`).

### Fixed

- **`bootstrap.py` silent-leak footgun** —
  `build_app(settings)` now refuses to boot when `openai_base_url`
  targets `api.openai.com/v1` AND `openai_api_key` is empty. Previously
  fell back to `api_key="unused"` and 401'd mid-ingest on every
  graphiti extraction call. Self-hosted endpoints (litellm / ollama /
  vllm OpenAI-compat) keep working with no key.
- **Q7 / Q8 spike harness `--skip-ingest`** — both referenced a
  nonexistent `app.metadata._pool`; corrected to `app.pool` so
  re-grading against an existing tenant works without re-ingest cost.

### Validation

- 117 / 117 unit tests green (10 new for retrieval helpers, 11 new for
  med excerpts, 11 new for `med_event`, 5 new for bootstrap pre-flight).
- 22 integration tests against the live compose stack (smoke updated
  for migrations 0006 + 0007).
- Q8 spike re-grade against `spike-q8` tenant: **53.3 % → 73.3 %**
  (`ADOPT_WITH_GAPS`). Q7 spike unchanged at 13.3 % `OFF-RAMP` (typed
  `lab_record` table is the right v0.2 fix, not the cheap path).
- Downstream noggin real-corpus suite: 6 / 7 (one likely-flaky LLM-
  variance test on a query with no recall-path-affecting keywords).

## [0.1.1] — 2026-05-08

Patch release focused on extraction quality on real-corpus shapes that
the v0.1 surface left under-served. Spec gates from v0.1 stay green;
no public-API breakage.

### Added

- **Pre-extraction preprocessor** (`src/gnokee/extract/`) — a deterministic
  pass that augments the body sent to graphiti's edge-fact extractor with
  derived sentences for shapes the LLM tends to drop. Three rules ship:
  `identifier` (numbered references such as ADR-025, Q1, P1.3), `ranked_list`
  (top-of-stack / P-prefix / ordered-list priority), and `table_amount`
  (pipe-table currency rows). Closes #2 / #3 / #4.
- **`currency_anchor` rule** — fourth preprocessor rule covering the two
  non-pipe-table shapes the original `table_amount` rule cannot reach:
  bold list-item totals (`- **Total spent: 14,225.45**`) and bold
  declarative currency lines (`**€14,225 spent through 20.04.2026.**`).
  Pairs the amount with the document's first H1 so derived sentences
  read like `Sofia Apartment: €14,225 spent through 20.04.2026
  (Renovation — actuals).`. Closes #6 (layer 2 piece).
- **`gnokee_recall` body excerpts** — `RecallResponse.excerpts[]` now
  surfaces verbatim `Episodic.content` lines containing currency or
  amount-keyword digits when the query is amount-bearing. Recall reserves
  ~⅓ of `max_tokens` for the excerpt slice so the LLM-summarised fact
  list cannot crowd out the verbatim numerics. Tool description nudges
  the agent to quote excerpts when answering numeric questions.
  Closes #7. New leaf module `gnokee.excerpts` (pure helpers).
- **`Excerpt` model** on the public surface
  (`src/gnokee/models.py`) and serialised by the `gnokee_recall` MCP tool.
- **`GraphitiStore.fetch_episode_contents`** — batch episode-body fetch
  in one Cypher round-trip, used by the recall excerpt stage.
- **`our_id` idempotency** on `EpisodeIn` — re-ingest with the same
  `(tenant_id, our_id)` returns the existing receipt and skips graphiti
  extraction, vector write, and contradiction detection.

### Changed

- **Currency pattern** in both ingest- and recall-side scanners now
  matches the EU-suffix shape (`1,000 €`) in addition to the prefix
  form (`€1,000`).
- **TEI embeddings** — client-side batch chunking + `truncate=true`
  makes the embedder resilient to long inputs without surfacing
  413/max-token errors at ingest time.

### Validation

- 79/79 unit tests green (12 new for excerpts, 13 new for
  `currency_anchor`).
- 21/21 integration tests against the live compose stack.
- Downstream noggin real-corpus suite goes from 4/4 → 7/7 passing
  (the three previously known recall gaps from #2 / #3 / #4 are now
  promoted to tests and pass).

## [0.1.0] — 2026-05-08

Initial release. Spec frozen, gates green.

### Added

- Ingest pipeline (`src/gnokee/ingest.py`): tenant-validated ingress,
  `valid_at` / `asserted_at` half-pair invariants, content-embedding
  via TEI, graphiti `add_episode` extraction, contradiction detection.
- Recall pipeline (`src/gnokee/retrieval.py`): six-stage recall with
  bi-temporal filtering, pgvector rerank, Cypher fact fetch, Q3
  response shaping (~125 median tokens, 67 % win vs graphiti raw).
- Q4 contradiction surface — `unrelated | refinement | update |
  contradiction` 4-label classifier; persisted as symmetric edges in
  Postgres `fact_contradiction`; surfaced on recall, never auto-resolved.
- MCP server (`src/gnokee/mcp.py`): `gnokee_ingest_episode`,
  `gnokee_recall`, `gnokee_fact_provenance`. stdio transport.
- Postgres schema (Alembic migrations): `episode_metadata`,
  `content_embedding` (1024-dim bge-m3, HNSW), `fact_contradiction`,
  RLS gated on `app.current_tenant` GUC.
- Neo4j 5 Community via graphiti-core 0.29; gnokee-managed HNSW
  indexes on `name_embedding` + `fact_embedding`.
- Docker compose for the v0.1 stack (`gnokee-postgres`, `gnokee-neo4j`,
  `gnokee-tei`); arm64 platform pin for TEI on Apple Silicon (Rosetta).
- Eval spikes Q1–Q5 under `evals/` validating the v0.1 architecture.

[0.1.2]: https://github.com/gnokeelabs/gnokee/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/gnokeelabs/gnokee/compare/v0.1...v0.1.1
[0.1.0]: https://github.com/gnokeelabs/gnokee/releases/tag/v0.1
