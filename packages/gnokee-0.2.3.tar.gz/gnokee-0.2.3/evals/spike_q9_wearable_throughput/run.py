"""evals/spike_q9_wearable_throughput/run.py — measure per-episode cost
of ingesting wearable-shape data through the gnokee v0.1.1 stack.

Decision criterion (README):
    < $5 / user / year   → ADOPT_AS_IS
    $5 – $50             → BATCH_AND_SUMMARISE
    > $50                → HARD_OFF_RAMP

Methodology
-----------
1. Monkey-patch ``httpx.AsyncClient.send`` to count HTTP calls per
   host. graphiti's LLM and embed traffic both flow through httpx.
2. Run ``gnokee.ingest_episode`` for each corpus entry; record
   wall-clock and the per-host call count delta.
3. Group results by `shape` (raw / hourly / daily) and project to the
   volume ceilings declared in the README.

Run:
    cd evals/spike_q9_wearable_throughput
    docker compose --profile embeddings --project-directory ../.. up -d gnokee-postgres gnokee-neo4j tei
    set -a && source ../../.env && set +a
    ../../.venv/bin/python run.py
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import json
import sys
import time
from collections import defaultdict
from collections.abc import Iterator
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import httpx

from gnokee import ingest_episode
from gnokee.bootstrap import build_app, shutdown_app
from gnokee.config import Settings

HERE = Path(__file__).parent
CORPUS_PATH = HERE / "corpus.jsonl"
RESULTS_DIR = HERE / "results"
TENANT_ID = "spike-q9"

# Volume ceilings per metric per user per year — see README.
VOLUME_CEILINGS = {
    "raw": 525_000,
    "hourly": 8_760,
    "daily": 365,
}

# Conservative midpoint LLM cost. gpt-4o-mini at typical extraction-call
# token shapes (~500 in / ~200 out) is roughly $0.0001 per call; bump to
# $0.0002 to pad for entity-dedup secondary calls and longer episodes.
COST_PER_LLM_CALL = 0.0002

# How many distinct wearable metrics a typical Omur user pipes in.
METRICS_PER_USER = 5

# LLM endpoint host hints; everything else is treated as embed/db chatter.
LLM_HOST_PATTERNS = ("openai", "anthropic", "litellm")
EMBED_HOST_PATTERNS = ("11434", "8080", "tei")  # ollama / TEI


_HTTP_COUNTER: dict[str, int] = defaultdict(int)
_original_send = httpx.AsyncClient.send


async def _counting_send(self: httpx.AsyncClient, request: httpx.Request, *args: Any, **kwargs: Any) -> httpx.Response:
    host = urlparse(str(request.url)).hostname or "unknown"
    _HTTP_COUNTER[host] += 1
    return await _original_send(self, request, *args, **kwargs)


httpx.AsyncClient.send = _counting_send  # type: ignore[method-assign]


def _classify_host(host: str) -> str:
    if any(p in host for p in LLM_HOST_PATTERNS):
        return "llm"
    if any(p in host for p in EMBED_HOST_PATTERNS):
        return "embed"
    return "other"


def _parse_iso(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def load_corpus(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


@contextlib.contextmanager
def reset_counter() -> Iterator[dict[str, int]]:
    snapshot_before = dict(_HTTP_COUNTER)
    _HTTP_COUNTER.clear()
    try:
        yield _HTTP_COUNTER
    finally:
        # Merge back into the global so we have a session-wide tally too.
        for k, v in dict(_HTTP_COUNTER).items():
            snapshot_before[k] = snapshot_before.get(k, 0) + v
        _HTTP_COUNTER.clear()
        _HTTP_COUNTER.update(snapshot_before)


async def measure(app: Any, ep: dict[str, Any]) -> dict[str, Any]:
    valid_at = _parse_iso(ep["valid_time_start"])
    with reset_counter() as counter:
        start = time.perf_counter()
        try:
            receipt = await ingest_episode(
                pipeline=app.ingest,
                tenant_id=TENANT_ID,
                content=ep["content"],
                valid_at=valid_at,
                our_id=f"q9-spike:{ep['id']}",
                sensitive="clinical",
            )
            elapsed = time.perf_counter() - start
            host_calls = dict(counter)
            classified: dict[str, int] = defaultdict(int)
            for h, n in host_calls.items():
                classified[_classify_host(h)] += n
            return {
                "id": ep["id"],
                "shape": ep["shape"],
                "metric": ep["metric"],
                "elapsed_s": round(elapsed, 3),
                "http_calls_total": sum(host_calls.values()),
                "llm_calls": classified.get("llm", 0),
                "embed_calls": classified.get("embed", 0),
                "other_calls": classified.get("other", 0),
                "replayed": receipt.replayed,
                "by_host": host_calls,
            }
        except Exception as exc:
            return {
                "id": ep["id"],
                "shape": ep["shape"],
                "metric": ep["metric"],
                "error": f"{type(exc).__name__}: {exc}",
            }


def aggregate(measurements: list[dict[str, Any]]) -> dict[str, Any]:
    by_shape: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for m in measurements:
        if "error" in m:
            continue
        by_shape[m["shape"]].append(m)

    out: dict[str, Any] = {}
    for shape, rows in by_shape.items():
        if not rows:
            continue
        n = len(rows)
        avg_llm = sum(r["llm_calls"] for r in rows) / n
        avg_embed = sum(r["embed_calls"] for r in rows) / n
        avg_elapsed = sum(r["elapsed_s"] for r in rows) / n
        cost_per_episode = avg_llm * COST_PER_LLM_CALL
        ceiling = VOLUME_CEILINGS.get(shape, 0)
        per_metric_per_user_per_year = ceiling * cost_per_episode
        per_user_per_year = per_metric_per_user_per_year * METRICS_PER_USER
        out[shape] = {
            "n": n,
            "avg_llm_calls": round(avg_llm, 2),
            "avg_embed_calls": round(avg_embed, 2),
            "avg_elapsed_s": round(avg_elapsed, 3),
            "cost_per_episode_usd": round(cost_per_episode, 6),
            "ceiling_episodes_per_metric_per_year": ceiling,
            "metrics_per_user_assumption": METRICS_PER_USER,
            "projected_usd_per_metric_per_user_per_year": round(per_metric_per_user_per_year, 2),
            "projected_usd_per_user_per_year": round(per_user_per_year, 2),
        }
    return out


def grade(by_shape: dict[str, Any]) -> str:
    raw = by_shape.get("raw", {}).get("projected_usd_per_user_per_year", 0)
    hourly = by_shape.get("hourly", {}).get("projected_usd_per_user_per_year", 0)
    if raw < 5:
        return "ADOPT_AS_IS"
    if raw < 50:
        return "BATCH_AND_SUMMARISE"
    if hourly < 50:
        return "BATCH_AND_SUMMARISE"
    return "HARD_OFF_RAMP"


async def amain() -> int:
    settings = Settings()
    app = await build_app(settings)
    try:
        corpus = load_corpus(CORPUS_PATH)
        print(f"-- corpus: {len(corpus)} episodes across shapes")
        measurements: list[dict[str, Any]] = []
        for ep in corpus:
            m = await measure(app, ep)
            tag = (
                f"err={m['error']}"
                if "error" in m
                else f"{m['elapsed_s']}s llm={m['llm_calls']} embed={m['embed_calls']} replayed={m['replayed']}"
            )
            print(f"  [{m['shape']:6}] {m['id']:35} {tag}")
            measurements.append(m)

        by_shape = aggregate(measurements)
        verdict = grade(by_shape)

        print("\n-- summary --")
        for shape, s in by_shape.items():
            print(
                f"  {shape:6} n={s['n']} avg_llm={s['avg_llm_calls']} "
                f"avg_embed={s['avg_embed_calls']} latency={s['avg_elapsed_s']}s "
                f"cost/ep=${s['cost_per_episode_usd']} → ${s['projected_usd_per_user_per_year']}/user/year"
            )
        print(f"  verdict: {verdict}")

        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        out_path = RESULTS_DIR / f"{stamp}.json"
        out_path.write_text(
            json.dumps(
                {
                    "spike": "q9_wearable_throughput",
                    "tenant_id": TENANT_ID,
                    "cost_per_llm_call_usd": COST_PER_LLM_CALL,
                    "metrics_per_user_assumption": METRICS_PER_USER,
                    "by_shape": by_shape,
                    "verdict": verdict,
                    "measurements": measurements,
                },
                indent=2,
            )
        )
        print(f"-- wrote {out_path}")
        return 0 if verdict != "HARD_OFF_RAMP" else 1
    finally:
        await shutdown_app(app)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.parse_args()
    return asyncio.run(amain())


if __name__ == "__main__":
    sys.exit(main())
