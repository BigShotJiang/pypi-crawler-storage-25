"""evals/spike_q8_med_supersession/run.py — measure gnokee fit on med supersession.

Uses gnokee's recall pipeline. When a query carries a `typed:` block
(v0.2+), the harness ALSO calls the named typed tool
(`gnokee_med_query`) and merges its response into the fact text used
for `value_substring` grading. This isolates the v0.2 typed-store lift
from the v0.1.1 narrative-only baseline.

Decision criterion (README):
    pass% >= 80   → ADOPT for clinical labs
    50% <= < 80%  → ADOPT_WITH_GAPS
    < 50%         → OFF-RAMP

Run:
    cd evals/spike_q8_med_supersession
    docker compose --project-directory ../.. up -d gnokee-postgres gnokee-neo4j gnokee-tei
    set -a && source ../../.env && set +a
    ../../.venv/bin/python run.py
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import UUID

import yaml

from gnokee import IngestReceipt, ingest_episode
from gnokee.bootstrap import build_app, shutdown_app
from gnokee.config import Settings
from gnokee.med_query import med_query

HERE = Path(__file__).parent
CORPUS_PATH = HERE / "corpus.jsonl"
QUERIES_PATH = HERE / "queries.yaml"
RESULTS_DIR = HERE / "results"
TENANT_ID = "spike-q8-v0_2_1c"


@dataclass
class QuerySpec:
    id: str
    pattern: str
    query: str
    expects: list[str]
    axes: str
    notes: str
    as_of: str | None = None
    valid_at: str | None = None
    value_substring: str | None = None
    typed: dict[str, Any] | None = None  # v0.2+: {tool, op, args}


@dataclass
class QueryResult:
    spec: QuerySpec
    returned_episode_ids: list[str] = field(default_factory=list)
    fact_texts: list[str] = field(default_factory=list)
    excerpt_texts: list[str] = field(default_factory=list)
    typed_texts: list[str] = field(default_factory=list)
    value_substring_found: bool = False
    verdict: str = "fail"  # pass | partial | fail | error
    error: str | None = None


def _parse_iso(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def load_episodes(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def load_queries(path: Path) -> list[QuerySpec]:
    raw = yaml.safe_load(path.read_text())
    return [QuerySpec(**entry) for entry in raw["queries"]]


async def ingest_corpus(app: Any, episodes: list[dict[str, Any]]) -> dict[UUID, str]:
    """Ingest every episode; return mapping {episode_uuid: our_id}.

    Supports `corrects: <our_id>` references between corpus entries.
    Entries with `corrects` MUST appear AFTER their target in
    corpus.jsonl (sequential ingest in file order).
    """
    uuid_to_ours: dict[UUID, str] = {}
    our_id_to_uuid: dict[str, UUID] = {}
    for ep in episodes:
        valid_at = _parse_iso(ep["valid_time_start"])
        asserted_at = _parse_iso(ep["observed_time"]) if ep.get("observed_time") else None
        corrects_uuid: UUID | None = None
        corrects_ref = ep.get("corrects")
        if corrects_ref:
            target = our_id_to_uuid.get(f"q8-spike:{corrects_ref}")
            if target is None:
                raise RuntimeError(
                    f"corpus entry {ep['id']} corrects {corrects_ref!r} "
                    f"but target not yet ingested (fix corpus ordering)"
                )
            corrects_uuid = target
        receipt: IngestReceipt = await ingest_episode(
            pipeline=app.ingest,
            tenant_id=TENANT_ID,
            content=ep["content"],
            valid_at=valid_at,
            asserted_at=asserted_at,
            our_id=f"q8-spike:{ep['id']}",
            sensitive="clinical",  # medications are PHI-adjacent
            corrects=corrects_uuid,
        )
        uuid_to_ours[receipt.episode_uuid] = ep["id"]
        our_id_to_uuid[f"q8-spike:{ep['id']}"] = receipt.episode_uuid
        replayed = " (replayed)" if receipt.replayed else ""
        suffix = f" corrects={corrects_ref}" if corrects_ref else ""
        print(f"  ingested {ep['id']} → {receipt.episode_uuid}{replayed}{suffix}")
    return uuid_to_ours


async def fetch_uuid_to_ours(app: Any, episodes: list[dict[str, Any]]) -> dict[UUID, str]:
    """When --skip-ingest, recover the mapping from `episode_metadata.our_id`."""
    rows = await _our_ids_lookup(app.pool, [f"q8-spike:{ep['id']}" for ep in episodes])
    return {row[1]: row[0].split(":", 1)[1] for row in rows}


async def _our_ids_lookup(pool: Any, our_ids: list[str]) -> list[tuple[str, UUID]]:
    async with pool.acquire() as conn:
        await conn.execute(
            "SELECT set_config('app.current_tenant', $1, true)",
            TENANT_ID,
        )
        rows = await conn.fetch(
            "SELECT our_id, episode_uuid FROM episode_metadata WHERE tenant_id = $1 AND our_id = ANY($2::text[])",
            TENANT_ID,
            our_ids,
        )
    return [(r["our_id"], r["episode_uuid"]) for r in rows]


async def run_query(app: Any, spec: QuerySpec, uuid_to_ours: dict[UUID, str]) -> QueryResult:
    result = QueryResult(spec=spec)
    try:
        as_of = _parse_iso(spec.as_of) if spec.as_of else None
        valid_at = _parse_iso(spec.valid_at) if spec.valid_at else None
        response = await app.recall.recall(
            tenant_id=TENANT_ID,
            text=spec.query,
            as_of=as_of,
            valid_at=valid_at,
            max_tokens=400,
            top_k=10,
        )
        seen_uuids = {f.episode_uuid for f in response.facts} | {e.episode_uuid for e in response.excerpts}
        result.returned_episode_ids = [uuid_to_ours[u] for u in seen_uuids if u in uuid_to_ours]
        result.fact_texts = [f.text for f in response.facts]
        result.excerpt_texts = [e.text for e in response.excerpts]

        if spec.typed is not None:
            typed_texts, typed_uuids = await _run_typed(
                app=app,
                spec=spec,
                as_of=as_of,
                valid_at=valid_at,
            )
            result.typed_texts = typed_texts
            for u in typed_uuids:
                if u in uuid_to_ours and uuid_to_ours[u] not in result.returned_episode_ids:
                    result.returned_episode_ids.append(uuid_to_ours[u])

        joined = "\n".join(result.fact_texts + result.excerpt_texts + result.typed_texts)
        if spec.value_substring:
            result.value_substring_found = spec.value_substring.lower() in joined.lower()
        else:
            result.value_substring_found = True  # not asserted

        expected = set(spec.expects)
        returned = set(result.returned_episode_ids)
        all_expected_returned = expected.issubset(returned)
        any_expected_returned = bool(expected & returned)

        if all_expected_returned and result.value_substring_found:
            result.verdict = "pass"
        elif any_expected_returned and result.value_substring_found:
            result.verdict = "partial"
        elif any_expected_returned:
            result.verdict = "partial"
        else:
            result.verdict = "fail"
    except Exception as exc:
        result.verdict = "error"
        result.error = f"{type(exc).__name__}: {exc}"
    return result


async def _run_typed(
    *,
    app: Any,
    spec: QuerySpec,
    as_of: datetime | None,
    valid_at: datetime | None,
) -> tuple[list[str], list[UUID]]:
    """Run the typed med_query call declared in the query's `typed:` block."""
    assert spec.typed is not None
    tool = spec.typed.get("tool")
    op = spec.typed.get("op")
    args = dict(spec.typed.get("args") or {})
    if tool != "gnokee_med_query":
        return [], []
    drug_name = args.get("drug_name")
    since = _parse_iso(args["since"]) if args.get("since") else None
    until = _parse_iso(args["until"]) if args.get("until") else None
    response = await med_query(
        pipeline=app.med_query,
        tenant_id=TENANT_ID,
        op=op,
        drug_name=drug_name if isinstance(drug_name, str) else None,
        since=since,
        until=until,
        as_of=as_of,
        valid_at=valid_at,
        limit=int(args.get("limit", 50)),
    )
    texts: list[str] = []
    uuids: list[UUID] = []
    for r in response.rows:
        dose = ""
        if r.dose_value is not None:
            dose = f" {r.dose_value} {r.dose_unit or ''}".rstrip()
        reason = f" — {r.reason}" if r.reason else ""
        kind = _EVENT_KIND_HUMAN.get(r.event_kind, r.event_kind)
        texts.append(
            f"[{r.valid_at.date().isoformat()}] {r.drug_name}{dose} ({kind}){reason}".strip(),
        )
        uuids.append(r.episode_uuid)
    return texts, uuids


_EVENT_KIND_HUMAN: dict[str, str] = {
    "start": "started",
    "increase": "increased",
    "decrease": "decreased",
    "stop": "discontinued",
    "switch": "switched",
    "allergy": "allergy",
    "documented": "documented",
}


def grade(results: list[QueryResult]) -> dict[str, Any]:
    counts = {"pass": 0, "partial": 0, "fail": 0, "error": 0}
    for r in results:
        counts[r.verdict] = counts.get(r.verdict, 0) + 1
    total = len(results)
    pass_pct = (counts["pass"] / total) * 100 if total else 0.0
    if pass_pct >= 80:
        verdict = "ADOPT"
    elif pass_pct >= 50:
        verdict = "ADOPT_WITH_GAPS"
    else:
        verdict = "OFF-RAMP"
    return {
        "total": total,
        "pass": counts["pass"],
        "partial": counts["partial"],
        "fail": counts["fail"],
        "error": counts["error"],
        "pass_pct": round(pass_pct, 1),
        "verdict": verdict,
    }


async def amain(skip_ingest: bool) -> int:
    settings = Settings()
    app = await build_app(settings)
    try:
        episodes = load_episodes(CORPUS_PATH)
        queries = load_queries(QUERIES_PATH)

        if skip_ingest:
            print("-- skipping ingest; recovering UUID map from episode_metadata --")
            uuid_to_ours = await fetch_uuid_to_ours(app, episodes)
        else:
            print(f"-- ingesting {len(episodes)} lab panels into tenant {TENANT_ID!r} --")
            uuid_to_ours = await ingest_corpus(app, episodes)

        print(f"-- running {len(queries)} queries --")
        results: list[QueryResult] = []
        for spec in queries:
            r = await run_query(app, spec, uuid_to_ours)
            print(f"  [{r.verdict.upper():7}] {spec.id} — {spec.pattern}")
            if r.verdict in ("partial", "fail") and r.error is None:
                missing = sorted(set(spec.expects) - set(r.returned_episode_ids))
                if missing:
                    print(f"    missing: {missing}")
                if spec.value_substring and not r.value_substring_found:
                    print(f"    value_substring not found: {spec.value_substring!r}")
            if r.error:
                print(f"    error: {r.error}")
            results.append(r)

        summary = grade(results)
        print(
            f"\n-- summary -- pass={summary['pass']}/{summary['total']} "
            f"({summary['pass_pct']}%) partial={summary['partial']} "
            f"fail={summary['fail']} error={summary['error']} → {summary['verdict']}"
        )

        RESULTS_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        out_path = RESULTS_DIR / f"{stamp}.json"
        out_path.write_text(
            json.dumps(
                {
                    "spike": "q8_med_supersession",
                    "tenant_id": TENANT_ID,
                    "summary": summary,
                    "queries": [
                        {
                            "id": r.spec.id,
                            "pattern": r.spec.pattern,
                            "query": r.spec.query,
                            "expects": r.spec.expects,
                            "axes": r.spec.axes,
                            "as_of": r.spec.as_of,
                            "valid_at": r.spec.valid_at,
                            "value_substring": r.spec.value_substring,
                            "verdict": r.verdict,
                            "returned_episode_ids": r.returned_episode_ids,
                            "fact_texts": r.fact_texts,
                            "excerpt_texts": r.excerpt_texts,
                            "typed_texts": r.typed_texts,
                            "typed": r.spec.typed,
                            "value_substring_found": r.value_substring_found,
                            "error": r.error,
                        }
                        for r in results
                    ],
                },
                indent=2,
            )
        )
        print(f"-- wrote {out_path} --")
        return 0 if summary["verdict"] != "OFF-RAMP" else 1
    finally:
        await shutdown_app(app)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument(
        "--skip-ingest",
        action="store_true",
        help="Skip ingest; grade against the already-ingested corpus.",
    )
    args = parser.parse_args()
    return asyncio.run(amain(skip_ingest=args.skip_ingest))


if __name__ == "__main__":
    sys.exit(main())
