# Spike Q8 — Medication supersession on the gnokee v0.1.1 stack

> Sibling of Q7 (`evals/spike_q7_lab_results/`). Q7 found that
> graphiti's edge-fact LLM strips numerics, killing structured-value
> recall on labs. Q8 asks whether the *same* stack handles medication
> events — a shape that is noun-verb-object first and numeric second
> ("patient takes Lisinopril 10 mg daily") — and whether the
> bi-temporal supersession axis from ADR-0004 holds when the user
> changes dose / switches drug / stops medication.

## Goal

Validate that gnokee v0.1.1 handles the medication-history query
patterns Omur needs across:

- **Start** events ("started Lisinopril 10 mg 2024-03-01")
- **Dose change** events ("increased to 20 mg 2024-06-15")
- **Stop** events ("stopped 2024-09-15 due to cough")
- **Switch** events ("switched to Losartan 50 mg 2024-09-20")
- **Allergies** ("penicillin reaction documented 2023-08-01")
- **Cross-domain** ("furosemide and the April hypokalemia")

against 15 query patterns covering time-pinned dose, current-state,
full history, allergies, side-effect linkage.

## Decision criterion

| % of expected query patterns that pass | Outcome |
|---|---|
| ≥ 80 % | **Adopt for medication history** — gnokee v0.1.1 is sufficient; ship as-is |
| 50 % – 80 % | **Adopt with documented gap-fillers** (likely a structured `med_record` table mirroring ADR-0009's `lab_record`, but smaller scope) |
| < 50 % | **Off-ramp** — extend ADR-0009's structured-clinical-data direction to meds |

A query passes when **all expected episode IDs** appear in the recall
set **and** the response (facts + excerpts) contains the answer's
load-bearing token (drug name, dose, date, etc.). Partial overlap =
`partial`, fail for the headline.

## Methodology

Identical to Q7 — uses gnokee's recall pipeline directly via
`gnokee.recall`. `tenant_id = "spike-q8"` so it does not touch the Q7
or vadim corpora. Corpus reuses the Q7 patient timeline so the
furosemide-hypokalemia cross-domain query (`q_furosemide_lab_link`)
can compare answer quality with and without lab structure.

## Hypothesis

Meds are easier than labs. The fact "patient takes Lisinopril 10 mg
daily from 2024-03-01" is naturally a triple
(`patient` — `takes_at_dose` — `Lisinopril@10mg`). graphiti's
extractor preserves the drug name and the date even when it
summarises away dose-numerics elsewhere; noun-verb-object structure
survives where number-with-unit doesn't.

Risks:
- Dose changes look like contradictions ("Lisinopril 10 mg" vs
  "Lisinopril 20 mg"). gnokee's Q4 contradiction surface may flag
  these as `update`. That is **the right answer** when dosed at the
  edge level — the spike grades it as pass when the contradiction
  carries the new dose, not when the old one wins outright.
- "Stop" events are absence — graphiti may not extract a fact "no
  longer takes Lisinopril after 2024-09-15". gnokee's
  `valid_until` half-pair must carry that signal.

## What this does NOT cover

- **Drug interactions** ("ACE inhibitor + ARB contraindication"). Out
  of scope — that's reasoning, not recall.
- **Refill / adherence patterns**. Time-series, similar to wearables
  (Q9), not a recall problem.
- **Dose unit normalisation** (mg ↔ µg ↔ mEq). Out of scope.

## Cost & time

- **Ingest**: ~12 episodes × graphiti `add_episode` ≈ $0.10 with
  `gpt-4o-mini`.
- **Recall**: 15 queries, no LLM — embed + Cypher + pgvector only.
- **Wall**: ~3–4 min ingest, ~30 s recall.

## Run

```bash
cd evals/spike_q8_med_supersession
docker compose --profile embeddings --project-directory ../.. up -d gnokee-postgres gnokee-neo4j tei
set -a && source ../../.env && set +a
../../.venv/bin/python run.py [--skip-ingest]
```
