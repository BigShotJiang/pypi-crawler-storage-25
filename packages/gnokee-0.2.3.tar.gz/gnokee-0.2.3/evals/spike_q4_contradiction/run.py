"""evals/spike_q4_contradiction/run.py — contradiction-handling smoke test.

For each labeled pair from pairs.yaml, prompts gpt-4o-mini to classify
the relationship between two facts as one of:

    unrelated | refinement | update | contradiction

per docs/architecture.md "Contradiction handling" section. Reports
classification accuracy against the labeled set.

Run from this directory:

    python3 -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python run.py

Reads:
    pairs.yaml                              labeled pairs
    ../spike_q1_graphiti/episodes.jsonl     fact contents

exports: HERE | PAIRS_PATH | EPISODES_PATH | RESULTS_DIR | VALID_LABELS | ACCURACY_THRESHOLD | SYSTEM_PROMPT | classify(client, model, fact_a, fact_b) | main()
used_by: none
rules:   none
agent:   codedna-cli (no-llm) | codedna-cli | 2026-05-08 | codedna-cli | initial CodeDNA annotation pass
message: 
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from openai import OpenAI

HERE = Path(__file__).parent
PAIRS_PATH = HERE / "pairs.yaml"
EPISODES_PATH = HERE.parent / "spike_q1_graphiti" / "episodes.jsonl"
RESULTS_DIR = HERE / "results"

VALID_LABELS = {"unrelated", "refinement", "update", "contradiction"}
ACCURACY_THRESHOLD = 0.80


SYSTEM_PROMPT = """You are a fact-relationship classifier for a memory system.

Classify the relationship between two facts (A and B) as exactly ONE word from this set:

  unrelated     - different topics; no semantic overlap
  refinement    - same fact, B adds detail or precision
  update        - world-state changed: A was true, then B replaced it
  contradiction - A and B make incompatible claims about the same point in time

Respond with ONLY the single classification word, lowercase, no punctuation,
no explanation.
"""


def _env(key: str, default: str | None = None) -> str | None:
    value = os.environ.get(key, default)
    if value is None or value == "":
        return None
    return value


def _llm_client() -> OpenAI:
    api_key = _env("GNOKEE_LLM_API_KEY") or _env("OPENAI_API_KEY")
    base_url = _env("GNOKEE_LLM_BASE_URL")
    return OpenAI(api_key=api_key or "ollama", base_url=base_url)


def classify(client: OpenAI, model: str, fact_a: str, fact_b: str) -> str:
    user = f"Fact A: {fact_a}\n\nFact B: {fact_b}"
    resp = client.chat.completions.create(
        model=model,
        temperature=0,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user},
        ],
    )
    raw = (resp.choices[0].message.content or "").strip().lower()
    # Defensive: strip punctuation, take first token.
    raw = raw.split()[0].rstrip(".,;:!?") if raw else ""
    return raw


def main() -> int:
    load_dotenv(HERE.parent.parent / ".env")
    model = _env("GNOKEE_LLM_MODEL", "gpt-4o-mini") or "gpt-4o-mini"

    episodes = {
        json.loads(line)["id"]: json.loads(line)
        for line in EPISODES_PATH.read_text().splitlines()
        if line.strip()
    }
    pairs = yaml.safe_load(PAIRS_PATH.read_text())["pairs"]
    print(f"loaded {len(episodes)} episodes, {len(pairs)} labeled pairs")
    print(f"classifier: {model}")

    client = _llm_client()

    per_pair: list[dict[str, Any]] = []
    for p in pairs:
        a = episodes[p["a_id"]]["content"]
        b = episodes[p["b_id"]]["content"]
        verdict = classify(client, model, a, b)
        valid = verdict in VALID_LABELS
        correct = valid and verdict == p["label"]
        mark = "OK " if correct else ("?? " if not valid else "X  ")
        print(f"  {mark} {p['id']:35s} expected={p['label']:14s} got={verdict}")
        per_pair.append(
            {
                "id": p["id"],
                "a_id": p["a_id"],
                "b_id": p["b_id"],
                "label": p["label"],
                "verdict": verdict,
                "valid_word": valid,
                "correct": correct,
                "notes": p["notes"],
            }
        )

    n = len(per_pair)
    correct = sum(1 for r in per_pair if r["correct"])
    accuracy = correct / n if n else 0.0
    decision = "ADOPT" if accuracy >= ACCURACY_THRESHOLD else "REJECT"

    summary = {
        "model": model,
        "pairs": n,
        "correct": correct,
        "accuracy": round(accuracy, 4),
        "threshold": ACCURACY_THRESHOLD,
        "decision": decision,
    }

    RESULTS_DIR.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out = RESULTS_DIR / f"{stamp}.json"
    out.write_text(json.dumps({"summary": summary, "per_pair": per_pair}, indent=2, ensure_ascii=False))

    print()
    print(f"accuracy: {correct}/{n} = {accuracy*100:.1f}%  decision: {decision}")
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
