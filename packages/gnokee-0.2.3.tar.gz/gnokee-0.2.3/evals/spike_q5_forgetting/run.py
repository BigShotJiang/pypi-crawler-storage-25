"""evals/spike_q5_forgetting/run.py — forgetting smoke test.

For each forget probe, asserts that:

  1. The target episode is retrievable BEFORE the forget operation
     (cosine top-3 against the gnokee-side content-embedding map)
  2. forget(e_X) propagates correctly to BOTH retrieval surfaces
     (gnokee in-memory map AND Graphiti-managed Neo4j) within a
     single Cypher transaction
  3. The target is NOT retrievable AFTER the forget operation
     (cosine never surfaces it)

Run from this directory:

    python3 -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python run.py

Reads:
    ../spike_q1_graphiti/episodes.jsonl     fact contents

Note: the Q1 spike corpus is expected to be present in Neo4j under
group_id="spike". If it isn't, this spike will rebuild it from the
episodes file (full ingest, ~5-10 min on OpenAI). After the run,
the Q1 corpus is restored to a freshly-ingested state via the same
ingest path so subsequent spikes (Q3, etc.) see a consistent corpus.

exports: HERE | EPISODES_PATH | RESULTS_DIR | GROUP_ID | TOP_K | PROBES | make_graphiti() | cosine(a, b) | neighborhood_counts(client, our_id) | forget_episode(client, our_id) | cosine_top_k(query_text, embeddings, embed_url, embed_model, top_k) | reingest_full_corpus(client, episodes) | amain() | main()
used_by: none
rules:   none
agent:   codedna-cli (no-llm) | codedna-cli | 2026-05-08 | codedna-cli | initial CodeDNA annotation pass
message: 
"""

from __future__ import annotations

import asyncio
import json
import math
import os
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from graphiti_core import Graphiti
from graphiti_core.cross_encoder.openai_reranker_client import OpenAIRerankerClient
from graphiti_core.embedder import OpenAIEmbedder, OpenAIEmbedderConfig
from graphiti_core.llm_client import LLMConfig, OpenAIClient
from graphiti_core.nodes import EpisodeType

HERE = Path(__file__).parent
EPISODES_PATH = HERE.parent / "spike_q1_graphiti" / "episodes.jsonl"
RESULTS_DIR = HERE / "results"

GROUP_ID = "spike"
TOP_K = 3

PROBES = [
    {
        "id": "probe_01_potassium",
        "forget": "e_005",
        "query": "What was my potassium reading on 2024-04-10?",
    },
    {
        "id": "probe_02_database",
        "forget": "e_002",
        "query": "What database does the project use?",
    },
]


def _env(key: str, default: str | None = None) -> str | None:
    value = os.environ.get(key, default)
    if value is None or value == "":
        return None
    return value


def _require(key: str) -> str:
    value = _env(key)
    if value is None:
        raise SystemExit(f"missing required env var: {key}")
    return value


def _llm_config() -> LLMConfig:
    return LLMConfig(
        api_key=_env("GNOKEE_LLM_API_KEY") or _env("OPENAI_API_KEY") or "ollama",
        model=_env("GNOKEE_LLM_MODEL", "gpt-4o-mini"),
        base_url=_env("GNOKEE_LLM_BASE_URL"),
        small_model=_env("GNOKEE_LLM_SMALL_MODEL"),
        temperature=float(_env("GNOKEE_LLM_TEMPERATURE", "0") or "0"),
    )


def make_graphiti() -> Graphiti:
    return Graphiti(
        uri=_require("GNOKEE_NEO4J_URI"),
        user=_require("GNOKEE_NEO4J_USER"),
        password=_require("GNOKEE_NEO4J_PASSWORD"),
        llm_client=OpenAIClient(config=_llm_config()),
        embedder=OpenAIEmbedder(
            config=OpenAIEmbedderConfig(
                embedding_model=_env("GNOKEE_EMBED_MODEL", "text-embedding-3-small"),
                embedding_dim=int(_env("GNOKEE_EMBED_DIM", "1024") or "1024"),
                api_key=_env("GNOKEE_EMBED_API_KEY") or _env("OPENAI_API_KEY") or "ollama",
                base_url=_env("GNOKEE_EMBED_BASE_URL"),
            )
        ),
        cross_encoder=OpenAIRerankerClient(config=_llm_config()),
    )


def _embed_via_ollama(text: str, base_url: str, model: str) -> list[float]:
    body = json.dumps({"model": model, "prompt": text}).encode()
    req = urllib.request.Request(
        f"{base_url.rstrip('/')}/api/embeddings",
        data=body,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read())["embedding"]


def cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


async def neighborhood_counts(client: Graphiti, our_id: str) -> dict[str, int]:
    """Pre/post Neo4j footprint for the target episode's neighborhood."""
    cypher = """
    OPTIONAL MATCH (ep:Episodic {name: $our_id, group_id: $group_id})
    OPTIONAL MATCH (ep)-[m:MENTIONS]->(e:Entity)
    WITH ep, count(DISTINCT m) AS mentions, collect(DISTINCT e.uuid) AS entity_uuids
    OPTIONAL MATCH ()-[r:RELATES_TO {group_id: $group_id}]->()
    WHERE ep IS NOT NULL AND ep.uuid IN r.episodes
    RETURN
      CASE WHEN ep IS NULL THEN 0 ELSE 1 END AS episodic_present,
      mentions AS mentions_count,
      size(entity_uuids) AS distinct_entities,
      count(DISTINCT r) AS relates_referencing
    """
    records, _, _ = await client.driver.execute_query(
        cypher, our_id=our_id, group_id=GROUP_ID
    )
    if not records:
        return {
            "episodic_present": 0,
            "mentions_count": 0,
            "distinct_entities": 0,
            "relates_referencing": 0,
        }
    rec = records[0]
    return {
        "episodic_present": rec["episodic_present"],
        "mentions_count": rec["mentions_count"],
        "distinct_entities": rec["distinct_entities"],
        "relates_referencing": rec["relates_referencing"],
    }


async def forget_episode(client: Graphiti, our_id: str) -> dict[str, int]:
    """Hard-delete an episode from Neo4j and return a ForgetReceipt-shaped dict.

    Cascade rules:
      - DETACH DELETE the Episodic node (drops all MENTIONS edges)
      - For each Entity that this episode was the only source of mentions
        for, DETACH DELETE the orphan
      - For each RELATES_TO edge where this episode was the only entry in
        `episodes`, DETACH DELETE the orphan edge
    """
    receipt = {"episodic_deleted": 0, "orphan_entities": 0, "orphan_relates_to": 0}

    # Step 1: capture episode UUID before deletion (for relates_to cleanup).
    rec_q = """
    MATCH (ep:Episodic {name: $our_id, group_id: $group_id})
    RETURN ep.uuid AS uuid
    """
    records, _, _ = await client.driver.execute_query(
        rec_q, our_id=our_id, group_id=GROUP_ID
    )
    if not records:
        return receipt
    target_uuid = records[0]["uuid"]

    # Step 2: collect entities mentioned only by this episode.
    orphan_q = """
    MATCH (ep:Episodic {name: $our_id, group_id: $group_id})-[:MENTIONS]->(e:Entity)
    WITH e
    WHERE COUNT { (e)<-[:MENTIONS]-(:Episodic) } = 1
    RETURN collect(DISTINCT e.uuid) AS uuids
    """
    records, _, _ = await client.driver.execute_query(
        orphan_q, our_id=our_id, group_id=GROUP_ID
    )
    orphan_entity_uuids = records[0]["uuids"] if records else []

    # Step 3: delete the episodic node (cascades MENTIONS via DETACH).
    del_q = "MATCH (ep:Episodic {name: $our_id, group_id: $group_id}) DETACH DELETE ep RETURN 1 AS ok"
    records, _, _ = await client.driver.execute_query(
        del_q, our_id=our_id, group_id=GROUP_ID
    )
    receipt["episodic_deleted"] = len(records)

    # Step 4: clean up orphan entities.
    if orphan_entity_uuids:
        cleanup_q = "MATCH (e:Entity) WHERE e.uuid IN $uuids DETACH DELETE e"
        await client.driver.execute_query(cleanup_q, uuids=orphan_entity_uuids)
        receipt["orphan_entities"] = len(orphan_entity_uuids)

    # Step 5: orphan RELATES_TO edges that referenced only this episode.
    rel_cleanup = """
    MATCH ()-[r:RELATES_TO {group_id: $group_id}]->()
    WHERE r.episodes = [$target_uuid]
    DELETE r
    RETURN count(r) AS deleted
    """
    records, _, _ = await client.driver.execute_query(
        rel_cleanup, target_uuid=target_uuid, group_id=GROUP_ID
    )
    receipt["orphan_relates_to"] = records[0]["deleted"] if records else 0

    return receipt


def cosine_top_k(
    query_text: str,
    embeddings: dict[str, list[float]],
    embed_url: str,
    embed_model: str,
    top_k: int,
) -> list[tuple[float, str]]:
    q = _embed_via_ollama(query_text, embed_url, embed_model)
    scored = sorted(((cosine(q, vec), our_id) for our_id, vec in embeddings.items()), reverse=True)
    return scored[:top_k]


async def reingest_full_corpus(
    client: Graphiti, episodes: list[dict[str, Any]]
) -> None:
    """Re-ingest the full Q1 corpus end-of-spike to leave a clean state."""
    print("re-ingesting full Q1 corpus to restore post-test state...")
    for ep in episodes:
        valid_time = datetime.fromisoformat(ep["valid_time_start"].replace("Z", "+00:00"))
        await client.add_episode(
            name=ep["id"],
            episode_body=ep["content"],
            source_description=ep["source"],
            reference_time=valid_time,
            source=EpisodeType.text,
            group_id=GROUP_ID,
        )


async def amain() -> int:
    load_dotenv(HERE.parent.parent / ".env")

    embed_base = _env("GNOKEE_EMBED_BASE_URL", "http://localhost:11434/v1") or ""
    if embed_base.rstrip("/").endswith("/v1"):
        embed_base = embed_base.rstrip("/")[: -len("/v1")]
    embed_model = _env("GNOKEE_EMBED_MODEL", "bge-m3") or "bge-m3"

    episodes = [
        json.loads(line)
        for line in EPISODES_PATH.read_text().splitlines()
        if line.strip()
    ]
    print(f"loaded {len(episodes)} episodes")
    print(f"embedder: {embed_model} @ {embed_base}")

    client = make_graphiti()

    # Embed the gnokee side once. Keyed by episode our_id.
    print("embedding episodes for gnokee retrieval map...")
    embeddings: dict[str, list[float]] = {
        ep["id"]: _embed_via_ollama(ep["content"], embed_base, embed_model) for ep in episodes
    }

    per_probe: list[dict[str, Any]] = []
    try:
        for probe in PROBES:
            target = probe["forget"]
            print(f"\n--- {probe['id']} (forget={target}) ---")

            # Pre-forget retrievability check
            pre_top = cosine_top_k(probe["query"], embeddings, embed_base, embed_model, TOP_K)
            pre_top_ids = [our_id for _, our_id in pre_top]
            pre_hit = target in pre_top_ids
            print(f"  pre-forget top-{TOP_K}: {pre_top_ids}")
            if not pre_hit:
                print(f"  PROBE INVALID: {target} not in pre-forget top-{TOP_K}")

            # Pre-forget Neo4j footprint
            pre_counts = await neighborhood_counts(client, target)
            print(f"  pre-forget neo4j: {pre_counts}")

            # Forget: drop from gnokee map + cascade in Neo4j
            embeddings.pop(target, None)
            receipt = await forget_episode(client, target)
            print(f"  receipt: {receipt}")

            # Post-forget Neo4j footprint
            post_counts = await neighborhood_counts(client, target)
            print(f"  post-forget neo4j: {post_counts}")

            # Post-forget retrievability check (rank against full corpus minus target)
            post_top = cosine_top_k(probe["query"], embeddings, embed_base, embed_model, TOP_K)
            post_top_ids = [our_id for _, our_id in post_top]
            post_absent = target not in post_top_ids
            print(f"  post-forget top-{TOP_K}: {post_top_ids}")

            valid_probe = pre_hit
            cascade_ok = (
                pre_counts["episodic_present"] >= 1
                and post_counts["episodic_present"] == 0
                and receipt["episodic_deleted"] >= 1
            )
            retrieval_ok = post_absent

            per_probe.append(
                {
                    "id": probe["id"],
                    "target": target,
                    "query": probe["query"],
                    "pre_top_k": pre_top_ids,
                    "post_top_k": post_top_ids,
                    "pre_neo4j": pre_counts,
                    "post_neo4j": post_counts,
                    "receipt": receipt,
                    "valid_probe": valid_probe,
                    "cascade_ok": cascade_ok,
                    "retrieval_ok": retrieval_ok,
                    "all_ok": valid_probe and cascade_ok and retrieval_ok,
                }
            )

        n = len(per_probe)
        successful = sum(1 for r in per_probe if r["all_ok"])
        decision = "ADOPT" if successful == n else "REJECT"

        summary = {
            "probes": n,
            "successful": successful,
            "decision": decision,
        }

        # Restore the corpus state (Q1 spike still uses these episodes).
        await reingest_full_corpus(client, [ep for ep in episodes if ep["id"] in {p["forget"] for p in PROBES}])
    finally:
        await client.close()

    RESULTS_DIR.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out = RESULTS_DIR / f"{stamp}.json"
    out.write_text(
        json.dumps({"summary": summary, "per_probe": per_probe}, indent=2, ensure_ascii=False)
    )

    print()
    print(f"successful: {successful}/{len(per_probe)}  decision: {decision}")
    print(f"wrote {out}")
    return 0


def main() -> int:
    return asyncio.run(amain())


if __name__ == "__main__":
    sys.exit(main())
