"""evals/spike_q6_tei_ollama_parity/run.py — measure TEI vs Ollama bge-m3 drift.

Closes the open question pinned in v0.1_landed memory: are vectors written
under one runtime safely queryable under the other?

For each text in corpus.jsonl, embed under TEI (port 8080, native /embed)
and Ollama (port 11434, OpenAI-compat /v1/embeddings). Compute per-text
cosine similarity, plus retrieval stability over queries.yaml.

Run:
    docker start gnokee-tei
    python run.py [--tei-url URL] [--ollama-url URL]
"""

from __future__ import annotations

import argparse
import asyncio
import json
import math
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from gnokee.embeddings import TEIClient

HERE = Path(__file__).parent
CORPUS_PATH = HERE / "corpus.jsonl"
QUERIES_PATH = HERE / "queries.yaml"
RESULTS_DIR = HERE / "results"

DEFAULT_TEI_URL = "http://localhost:8080"
DEFAULT_OLLAMA_URL = "http://localhost:11434/v1"


def cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b, strict=True))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


@dataclass
class TextRecord:
    id: str
    lang: str
    shape: str
    text: str


def load_corpus(path: Path) -> list[TextRecord]:
    return [TextRecord(**json.loads(line)) for line in path.read_text().splitlines() if line.strip()]


def load_queries(path: Path) -> list[dict[str, Any]]:
    return list(yaml.safe_load(path.read_text())["queries"])


async def embed_all(client: TEIClient, texts: list[str]) -> tuple[list[list[float]], float]:
    start = time.perf_counter()
    vectors = await client.embed(texts)
    elapsed = time.perf_counter() - start
    return vectors, elapsed


def nearest_top_k(query_vec: list[float], matrix: list[list[float]], k: int = 3) -> list[int]:
    sims = [(i, cosine(query_vec, v)) for i, v in enumerate(matrix)]
    sims.sort(key=lambda t: t[1], reverse=True)
    return [i for i, _ in sims[:k]]


def percentile(values: list[float], pct: float) -> float:
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    idx = round((pct / 100.0) * (len(sorted_vals) - 1))
    return sorted_vals[idx]


def grade(mean_cos: float, top3_overlap_pct: float) -> str:
    if mean_cos >= 0.99:
        runtime_verdict = "interchangeable"
    elif mean_cos >= 0.95:
        runtime_verdict = "documented_drift"
    else:
        runtime_verdict = "non_interchangeable"
    if top3_overlap_pct < 80 and runtime_verdict == "documented_drift":
        runtime_verdict = "non_interchangeable"  # secondary criterion forces stricter
    return runtime_verdict


async def amain(tei_url: str, ollama_url: str) -> int:
    print(f"-- TEI:    {tei_url}")
    print(f"-- Ollama: {ollama_url}")

    corpus = load_corpus(CORPUS_PATH)
    queries = load_queries(QUERIES_PATH)
    print(f"-- corpus: {len(corpus)} texts; {len(queries)} queries")

    tei = TEIClient(tei_url)  # native /embed shape
    ollama = TEIClient(ollama_url, model="bge-m3", api_key="ollama")  # /v1/embeddings shape

    corpus_texts = [r.text for r in corpus]
    query_texts = [q["query"] for q in queries]

    print("-- embedding corpus on TEI…")
    tei_corpus_vecs, tei_corpus_t = await embed_all(tei, corpus_texts)
    print("-- embedding corpus on Ollama…")
    ollama_corpus_vecs, ollama_corpus_t = await embed_all(ollama, corpus_texts)
    print("-- embedding queries on TEI…")
    tei_query_vecs, _ = await embed_all(tei, query_texts)
    print("-- embedding queries on Ollama…")
    ollama_query_vecs, _ = await embed_all(ollama, query_texts)

    # Per-text drift
    per_text: list[dict[str, Any]] = []
    for i, rec in enumerate(corpus):
        c = cosine(tei_corpus_vecs[i], ollama_corpus_vecs[i])
        per_text.append({"id": rec.id, "lang": rec.lang, "shape": rec.shape, "cosine": c})

    cos_values = [r["cosine"] for r in per_text]
    drift = {
        "mean": sum(cos_values) / len(cos_values),
        "median": percentile(cos_values, 50),
        "min": min(cos_values),
        "p10": percentile(cos_values, 10),
        "max": max(cos_values),
    }

    # By language slice
    by_lang: dict[str, list[float]] = {}
    by_shape: dict[str, list[float]] = {}
    for r in per_text:
        by_lang.setdefault(r["lang"], []).append(r["cosine"])
        by_shape.setdefault(r["shape"], []).append(r["cosine"])
    by_lang_summary = {k: sum(v) / len(v) for k, v in by_lang.items()}
    by_shape_summary = {k: sum(v) / len(v) for k, v in by_shape.items()}

    # Retrieval stability
    per_query: list[dict[str, Any]] = []
    overlap_total = 0.0
    for i, q in enumerate(queries):
        tei_top3 = set(nearest_top_k(tei_query_vecs[i], tei_corpus_vecs, 3))
        ollama_top3 = set(nearest_top_k(ollama_query_vecs[i], ollama_corpus_vecs, 3))
        overlap = len(tei_top3 & ollama_top3) / 3.0
        overlap_total += overlap
        per_query.append(
            {
                "id": q["id"],
                "query": q["query"],
                "tei_top3_ids": [corpus[j].id for j in tei_top3],
                "ollama_top3_ids": [corpus[j].id for j in ollama_top3],
                "overlap": overlap,
            }
        )
    top3_overlap_pct = (overlap_total / len(queries)) * 100

    # Throughput (corpus pass only — apples to apples)
    throughput = {
        "tei_corpus_sec": tei_corpus_t,
        "tei_corpus_per_sec": len(corpus) / tei_corpus_t if tei_corpus_t else 0,
        "ollama_corpus_sec": ollama_corpus_t,
        "ollama_corpus_per_sec": len(corpus) / ollama_corpus_t if ollama_corpus_t else 0,
        "ollama_speedup_x": (tei_corpus_t / ollama_corpus_t) if ollama_corpus_t else 0.0,
    }

    verdict = grade(drift["mean"], top3_overlap_pct)

    summary = {
        "drift": drift,
        "by_lang_mean": by_lang_summary,
        "by_shape_mean": by_shape_summary,
        "top3_overlap_pct": top3_overlap_pct,
        "throughput": throughput,
        "verdict": verdict,
    }

    print(
        f"\n-- summary --\n"
        f"  mean cosine: {drift['mean']:.4f}\n"
        f"  median:      {drift['median']:.4f}\n"
        f"  min:         {drift['min']:.4f}\n"
        f"  p10:         {drift['p10']:.4f}\n"
        f"  max:         {drift['max']:.4f}\n"
        f"  by lang:     {by_lang_summary}\n"
        f"  by shape:    {by_shape_summary}\n"
        f"  top-3 overlap: {top3_overlap_pct:.1f}%\n"
        f"  TEI:    {throughput['tei_corpus_per_sec']:.1f} embed/s\n"
        f"  Ollama: {throughput['ollama_corpus_per_sec']:.1f} embed/s\n"
        f"  Ollama speedup: {throughput['ollama_speedup_x']:.2f}x\n"
        f"  verdict:     {verdict}"
    )

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_path = RESULTS_DIR / f"{stamp}.json"
    out_path.write_text(
        json.dumps(
            {
                "spike": "q6_tei_ollama_parity",
                "tei_url": tei_url,
                "ollama_url": ollama_url,
                "summary": summary,
                "per_text": per_text,
                "per_query": per_query,
            },
            indent=2,
        )
    )
    print(f"-- wrote {out_path}")
    return 0 if verdict != "non_interchangeable" else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--tei-url", default=DEFAULT_TEI_URL)
    parser.add_argument("--ollama-url", default=DEFAULT_OLLAMA_URL)
    args = parser.parse_args()
    return asyncio.run(amain(args.tei_url, args.ollama_url))


if __name__ == "__main__":
    sys.exit(main())
