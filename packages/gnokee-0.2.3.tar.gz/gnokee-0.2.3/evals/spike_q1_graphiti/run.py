"""evals/spike_q1_graphiti/run.py — verify Graphiti 0.29 handles gnokee's expected query patterns.

Wired against ``graphiti-core>=0.29``. Runs against:

  - Neo4j 5.x community (Graphiti's default backend)
  - An OpenAI-compatible LLM endpoint (OpenAI cloud, Ollama, etc.)
  - An OpenAI-compatible embeddings endpoint (defaults to OpenAI;
    set GNOKEE_EMBED_BASE_URL=http://localhost:11434/v1 + bge-m3 for Ollama)

Run from this directory:

    docker compose --project-directory ../.. up -d neo4j
    python3 -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    cp ../../.env.example .env       # then edit
    python run.py

The decision criterion (from `docs/adr/0001-build-on-graphiti.md`):

    pass% >= 80   → ADOPT
    50% <= < 80%  → ADOPT_WITH_GAPS
    < 50%         → REJECT

exports: HERE | EPISODES_PATH | QUERIES_PATH | RESULTS_DIR | GROUP_ID | class QuerySpec | class QueryResult | make_llm_client() | make_cross_encoder() | make_embedder() | make_graphiti() | load_episodes(path) | load_queries(path) | ingest_corpus(client, episodes) | build_search_filters(spec) | ask_graphiti(client, spec, uuid_to_ours) | grade(spec, returned) | amain() | main()
used_by: none
rules:   none
agent:   codedna-cli (no-llm) | codedna-cli | 2026-05-08 | codedna-cli | initial CodeDNA annotation pass
message: 
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from graphiti_core import Graphiti
from graphiti_core.cross_encoder.openai_reranker_client import OpenAIRerankerClient
from graphiti_core.embedder import OpenAIEmbedder, OpenAIEmbedderConfig
from graphiti_core.llm_client import LLMConfig, OpenAIClient
from graphiti_core.nodes import EpisodeType
from graphiti_core.search.search_config_recipes import COMBINED_HYBRID_SEARCH_RRF
from graphiti_core.search.search_filters import (
    ComparisonOperator,
    DateFilter,
    SearchFilters,
)

HERE = Path(__file__).parent
EPISODES_PATH = HERE / "episodes.jsonl"
QUERIES_PATH = HERE / "queries.yaml"
RESULTS_DIR = HERE / "results"

GROUP_ID = "spike"  # one tenant for the spike corpus


# ---------------------------------------------------------------------------
# Data shapes
# ---------------------------------------------------------------------------


@dataclass
class QuerySpec:
    id: str
    pattern: str
    query: str
    expects: list[str]
    axes: str
    notes: str
    as_of: str | None = None
    tx_as_of: str | None = None


@dataclass
class QueryResult:
    spec: QuerySpec
    returned_episode_ids: list[str] = field(default_factory=list)
    edge_count: int = 0
    bi_temporal_attempted: bool = False
    response_token_estimate: int = 0
    verdict: str = "fail"  # pass | partial | fail | error
    error: str | None = None


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------


def _env(key: str, default: str | None = None) -> str | None:
    value = os.environ.get(key, default)
    if value is None or value == "":
        return None
    return value


def _require(key: str) -> str:
    value = _env(key)
    if value is None:
        raise SystemExit(f"missing required env var: {key}")
    return value


def _llm_config() -> LLMConfig:
    return LLMConfig(
        api_key=_env("GNOKEE_LLM_API_KEY") or _env("OPENAI_API_KEY") or "ollama",
        model=_env("GNOKEE_LLM_MODEL", "gpt-4o-mini"),
        base_url=_env("GNOKEE_LLM_BASE_URL"),
        small_model=_env("GNOKEE_LLM_SMALL_MODEL"),
        temperature=float(_env("GNOKEE_LLM_TEMPERATURE", "0") or "0"),
    )


def make_llm_client() -> OpenAIClient:
    # OpenAIClient uses OpenAI's /v1/responses API (structured-output-native).
    # When swapping to a non-OpenAI provider, switch to OpenAIGenericClient
    # (which uses /v1/chat/completions) — see commit history for the wiring.
    return OpenAIClient(config=_llm_config())


def make_cross_encoder() -> OpenAIRerankerClient:
    # Graphiti's default cross_encoder is OpenAI cloud; for Ollama we
    # reuse the LLM config so the reranker hits the same local endpoint.
    return OpenAIRerankerClient(config=_llm_config())


def make_embedder() -> OpenAIEmbedder:
    config = OpenAIEmbedderConfig(
        embedding_model=_env("GNOKEE_EMBED_MODEL", "text-embedding-3-small"),
        embedding_dim=int(_env("GNOKEE_EMBED_DIM", "1024") or "1024"),
        api_key=_env("GNOKEE_EMBED_API_KEY") or _env("OPENAI_API_KEY") or "ollama",
        base_url=_env("GNOKEE_EMBED_BASE_URL"),
    )
    return OpenAIEmbedder(config=config)


def make_graphiti() -> Graphiti:
    return Graphiti(
        uri=_require("GNOKEE_NEO4J_URI"),
        user=_require("GNOKEE_NEO4J_USER"),
        password=_require("GNOKEE_NEO4J_PASSWORD"),
        llm_client=make_llm_client(),
        embedder=make_embedder(),
        cross_encoder=make_cross_encoder(),
    )


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------


def load_episodes(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def load_queries(path: Path) -> list[QuerySpec]:
    raw = yaml.safe_load(path.read_text())
    return [QuerySpec(**entry) for entry in raw["queries"]]


# ---------------------------------------------------------------------------
# Spike operations
# ---------------------------------------------------------------------------


async def ingest_corpus(client: Graphiti, episodes: list[dict[str, Any]]) -> dict[str, str]:
    """Ingest all episodes; return mapping {graphiti_episode_uuid: our_id}."""
    uuid_to_ours: dict[str, str] = {}
    for ep in episodes:
        valid_time = datetime.fromisoformat(ep["valid_time_start"].replace("Z", "+00:00"))
        result = await client.add_episode(
            name=ep["id"],
            episode_body=ep["content"],
            source_description=ep["source"],
            reference_time=valid_time,
            source=EpisodeType.text,
            group_id=GROUP_ID,
        )
        episode_uuid = getattr(result, "episode", None)
        if episode_uuid is not None:
            episode_uuid = getattr(episode_uuid, "uuid", episode_uuid)
        if isinstance(episode_uuid, str):
            uuid_to_ours[episode_uuid] = ep["id"]
        else:
            # fallback: linear lookup later via name
            uuid_to_ours[ep["id"]] = ep["id"]
    return uuid_to_ours


def _parse_iso(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def build_search_filters(spec: QuerySpec) -> tuple[SearchFilters | None, bool]:
    """Build a SearchFilters from per-query bi-temporal anchors.

    `as_of` (valid time) constrains:
        valid_at <= as_of  AND  (invalid_at > as_of  OR  invalid_at IS NULL)
    `tx_as_of` (transaction time) constrains:
        created_at <= tx_as_of
    """
    valid_at: list[list[DateFilter]] | None = None
    invalid_at: list[list[DateFilter]] | None = None
    created_at: list[list[DateFilter]] | None = None
    attempted = False

    if spec.as_of:
        as_of_dt = _parse_iso(spec.as_of)
        valid_at = [[DateFilter(date=as_of_dt, comparison_operator=ComparisonOperator.less_than_equal)]]
        invalid_at = [
            [DateFilter(comparison_operator=ComparisonOperator.is_null)],
            [DateFilter(date=as_of_dt, comparison_operator=ComparisonOperator.greater_than)],
        ]
        attempted = True

    if spec.tx_as_of:
        tx_dt = _parse_iso(spec.tx_as_of)
        created_at = [[DateFilter(date=tx_dt, comparison_operator=ComparisonOperator.less_than_equal)]]
        attempted = True

    if not attempted:
        return None, False
    return (
        SearchFilters(valid_at=valid_at, invalid_at=invalid_at, created_at=created_at),
        True,
    )


async def ask_graphiti(
    client: Graphiti,
    spec: QuerySpec,
    uuid_to_ours: dict[str, str],
) -> QueryResult:
    search_filter, attempted = build_search_filters(spec)
    try:
        results = await client.search_(
            query=spec.query,
            config=COMBINED_HYBRID_SEARCH_RRF,
            group_ids=[GROUP_ID],
            search_filter=search_filter,
        )
    except Exception as exc:
        return QueryResult(spec=spec, verdict="error", error=f"{type(exc).__name__}: {exc}")

    edges = getattr(results, "edges", []) or []
    nodes = getattr(results, "nodes", []) or []

    seen_ids: list[str] = []
    seen_set: set[str] = set()
    token_estimate = 0

    def _emit(our_id: str) -> None:
        if our_id not in seen_set:
            seen_set.add(our_id)
            seen_ids.append(our_id)

    for edge in edges:
        for ep_uuid in getattr(edge, "episodes", []) or []:
            _emit(uuid_to_ours.get(ep_uuid, ep_uuid))
        fact_text = getattr(edge, "fact", "") or ""
        token_estimate += max(1, len(fact_text) // 4)  # rough chars/token

    # Resolve node mentions to episodes (Entity has no `.episodes` field;
    # use MENTIONS relation to walk Episodic -> Entity backwards).
    node_uuids = [getattr(n, "uuid", None) for n in nodes if getattr(n, "uuid", None)]
    if node_uuids:
        cypher_records, _, _ = await client.driver.execute_query(
            """
            MATCH (ep:Episodic)-[:MENTIONS]->(n:Entity)
            WHERE n.uuid IN $node_uuids AND ep.group_id = $group_id
            RETURN DISTINCT ep.name AS our_id
            """,
            node_uuids=node_uuids,
            group_id=GROUP_ID,
        )
        for rec in cypher_records:
            our_id = rec["our_id"]
            if our_id:
                _emit(our_id)

    return QueryResult(
        spec=spec,
        returned_episode_ids=seen_ids,
        edge_count=len(edges),
        bi_temporal_attempted=attempted,
        response_token_estimate=token_estimate,
        verdict=grade(spec, seen_ids),
    )


def grade(spec: QuerySpec, returned: list[str]) -> str:
    expected = set(spec.expects)
    got = set(returned)
    if not expected:
        return "fail"
    if expected.issubset(got):
        return "pass"
    if got & expected:
        return "partial"
    return "fail"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


async def amain() -> int:
    load_dotenv(HERE.parent.parent / ".env")
    episodes = load_episodes(EPISODES_PATH)
    queries = load_queries(QUERIES_PATH)
    print(f"loaded {len(episodes)} episodes, {len(queries)} queries")

    client = make_graphiti()
    try:
        print("building indices and constraints...")
        await client.build_indices_and_constraints()

        print(f"ingesting {len(episodes)} episodes...")
        uuid_to_ours = await ingest_corpus(client, episodes)
        print(f"ingest done; {len(uuid_to_ours)} mappings recorded")

        print(f"running {len(queries)} queries...")
        results: list[QueryResult] = []
        for q in queries:
            print(f"  - {q.id}: {q.query!r}")
            results.append(await ask_graphiti(client, q, uuid_to_ours))
    finally:
        await client.close()

    counts = {"pass": 0, "partial": 0, "fail": 0, "error": 0}
    for r in results:
        counts[r.verdict] += 1

    headline_pct = 100.0 * counts["pass"] / max(len(results), 1)
    if headline_pct >= 80:
        decision = "ADOPT"
    elif headline_pct >= 50:
        decision = "ADOPT_WITH_GAPS"
    else:
        decision = "REJECT"

    RESULTS_DIR.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out = RESULTS_DIR / f"{stamp}.json"
    out.write_text(
        json.dumps(
            {
                "graphiti_version": "0.29",
                "harness_version": "v2",
                "counts": counts,
                "headline_pass_pct": headline_pct,
                "decision": decision,
                "results": [
                    {
                        "id": r.spec.id,
                        "pattern": r.spec.pattern,
                        "verdict": r.verdict,
                        "expected": r.spec.expects,
                        "returned": r.returned_episode_ids,
                        "edge_count": r.edge_count,
                        "tokens": r.response_token_estimate,
                        "bi_temporal_attempted": r.bi_temporal_attempted,
                        "error": r.error,
                    }
                    for r in results
                ],
            },
            indent=2,
        )
    )
    print(f"summary: {counts}, headline pass% = {headline_pct:.1f}, decision = {decision}")
    print(f"wrote {out}")
    return 0


def main() -> int:
    return asyncio.run(amain())


if __name__ == "__main__":
    sys.exit(main())
