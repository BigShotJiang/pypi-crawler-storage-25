"""evals/spike_q2_multilingual/run.py — verify bge-m3 cross-lingual retrieval through Graphiti.

Cloned from the Q1 v2.1 harness; the only material differences are:

  - 16 probes (4 same-language controls + 12 cross-lingual) over a
    4-episode corpus where each fact is stored in exactly one language
  - grade by **top-3 hit rate** rather than expected-subset, since the
    spike is a ranking question (does the LLM-facing top-K window
    contain the cross-lingual hit?)
  - decision criterion is in `docs/evals/methodology.md` and this
    spike's README — ≥80% top-3 over the 12 cross-lingual probes is
    ADOPT; controls must be 4/4 or the run is invalid

Run from this directory:

    docker compose --project-directory ../.. up -d neo4j
    python3 -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    cp ../../.env.example ../../.env       # then edit
    python run.py

exports: NODE_VECTOR_ONLY | _SEARCH_MODE | _SEARCH_LIMIT | _BASE_CONFIG | SEARCH_CONFIG | HERE | EPISODES_PATH | QUERIES_PATH | RESULTS_DIR | GROUP_ID | TOP_K | ADOPT_THRESHOLD | ADOPT_WITH_GAPS_THRESHOLD | class ProbeSpec | class ProbeResult | make_llm_client() | make_cross_encoder() | make_embedder() | make_graphiti() | load_episodes(path) | (+5 more)
used_by: none
rules:   none
agent:   codedna-cli (no-llm) | codedna-cli | 2026-05-08 | codedna-cli | initial CodeDNA annotation pass
message: 
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from graphiti_core import Graphiti
from graphiti_core.cross_encoder.openai_reranker_client import OpenAIRerankerClient
from graphiti_core.embedder import OpenAIEmbedder, OpenAIEmbedderConfig
from graphiti_core.llm_client import LLMConfig, OpenAIClient
from graphiti_core.nodes import EpisodeType
from graphiti_core.search.search_config import NodeReranker, NodeSearchConfig, NodeSearchMethod, SearchConfig
from graphiti_core.search.search_config_recipes import (
    COMBINED_HYBRID_SEARCH_RRF,
    NODE_HYBRID_SEARCH_RRF,
)
from graphiti_core.search.search_filters import SearchFilters

# Vector-only node search (no BM25). Used to isolate BM25 tokenization
# effects on non-Latin scripts when GNOKEE_SPIKE_SEARCH_MODE=vector.
NODE_VECTOR_ONLY = SearchConfig(
    node_config=NodeSearchConfig(
        search_methods=[NodeSearchMethod.cosine_similarity],
        reranker=NodeReranker.rrf,
    )
)

_SEARCH_MODE = os.environ.get("GNOKEE_SPIKE_SEARCH_MODE", "combined")
_SEARCH_LIMIT = int(os.environ.get("GNOKEE_SPIKE_SEARCH_LIMIT", "0") or "0")

_BASE_CONFIG = {
    "combined": COMBINED_HYBRID_SEARCH_RRF,
    "node_hybrid": NODE_HYBRID_SEARCH_RRF,
    "vector": NODE_VECTOR_ONLY,
}.get(_SEARCH_MODE, COMBINED_HYBRID_SEARCH_RRF)

SEARCH_CONFIG = (
    _BASE_CONFIG.model_copy(update={"limit": _SEARCH_LIMIT})
    if _SEARCH_LIMIT > 0
    else _BASE_CONFIG
)

HERE = Path(__file__).parent
EPISODES_PATH = HERE / "episodes.jsonl"
QUERIES_PATH = HERE / "queries.yaml"
RESULTS_DIR = HERE / "results"

GROUP_ID = "spike_q2"  # separate from Q1 so both volumes can co-exist
TOP_K = 3              # top-3 hit-rate decision criterion

ADOPT_THRESHOLD = 0.80
ADOPT_WITH_GAPS_THRESHOLD = 0.50


# ---------------------------------------------------------------------------
# Data shapes
# ---------------------------------------------------------------------------


@dataclass
class ProbeSpec:
    id: str
    query_lang: str
    target_lang: str
    target_fact: str
    query: str
    expects: str
    probe_type: str
    notes: str


@dataclass
class ProbeResult:
    spec: ProbeSpec
    returned_episode_ids: list[str] = field(default_factory=list)
    edge_count: int = 0
    node_count: int = 0
    top_k_hit: bool = False
    rank: int | None = None
    error: str | None = None


# ---------------------------------------------------------------------------
# Config helpers (same shape as Q1)
# ---------------------------------------------------------------------------


def _env(key: str, default: str | None = None) -> str | None:
    value = os.environ.get(key, default)
    if value is None or value == "":
        return None
    return value


def _require(key: str) -> str:
    value = _env(key)
    if value is None:
        raise SystemExit(f"missing required env var: {key}")
    return value


def _llm_config() -> LLMConfig:
    return LLMConfig(
        api_key=_env("GNOKEE_LLM_API_KEY") or _env("OPENAI_API_KEY") or "ollama",
        model=_env("GNOKEE_LLM_MODEL", "gpt-4o-mini"),
        base_url=_env("GNOKEE_LLM_BASE_URL"),
        small_model=_env("GNOKEE_LLM_SMALL_MODEL"),
        temperature=float(_env("GNOKEE_LLM_TEMPERATURE", "0") or "0"),
    )


def make_llm_client() -> OpenAIClient:
    return OpenAIClient(config=_llm_config())


def make_cross_encoder() -> OpenAIRerankerClient:
    return OpenAIRerankerClient(config=_llm_config())


def make_embedder() -> OpenAIEmbedder:
    config = OpenAIEmbedderConfig(
        embedding_model=_env("GNOKEE_EMBED_MODEL", "text-embedding-3-small"),
        embedding_dim=int(_env("GNOKEE_EMBED_DIM", "1024") or "1024"),
        api_key=_env("GNOKEE_EMBED_API_KEY") or _env("OPENAI_API_KEY") or "ollama",
        base_url=_env("GNOKEE_EMBED_BASE_URL"),
    )
    return OpenAIEmbedder(config=config)


def make_graphiti() -> Graphiti:
    return Graphiti(
        uri=_require("GNOKEE_NEO4J_URI"),
        user=_require("GNOKEE_NEO4J_USER"),
        password=_require("GNOKEE_NEO4J_PASSWORD"),
        llm_client=make_llm_client(),
        embedder=make_embedder(),
        cross_encoder=make_cross_encoder(),
    )


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------


def load_episodes(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def load_probes(path: Path) -> list[ProbeSpec]:
    raw = yaml.safe_load(path.read_text())
    return [ProbeSpec(**entry) for entry in raw["queries"]]


# ---------------------------------------------------------------------------
# Spike operations
# ---------------------------------------------------------------------------


async def ingest_corpus(client: Graphiti, episodes: list[dict[str, Any]]) -> dict[str, str]:
    uuid_to_ours: dict[str, str] = {}
    for ep in episodes:
        valid_time = datetime.fromisoformat(ep["valid_time_start"].replace("Z", "+00:00"))
        result = await client.add_episode(
            name=ep["id"],
            episode_body=ep["content"],
            source_description=ep["source"],
            reference_time=valid_time,
            source=EpisodeType.text,
            group_id=GROUP_ID,
        )
        episode_uuid = getattr(result, "episode", None)
        if episode_uuid is not None:
            episode_uuid = getattr(episode_uuid, "uuid", episode_uuid)
        if isinstance(episode_uuid, str):
            uuid_to_ours[episode_uuid] = ep["id"]
        else:
            uuid_to_ours[ep["id"]] = ep["id"]
    return uuid_to_ours


async def ask_graphiti(
    client: Graphiti,
    spec: ProbeSpec,
    uuid_to_ours: dict[str, str],
) -> ProbeResult:
    try:
        results = await client.search_(
            query=spec.query,
            config=SEARCH_CONFIG,
            group_ids=[GROUP_ID],
            search_filter=SearchFilters(),
        )
    except Exception as exc:
        return ProbeResult(spec=spec, error=f"{type(exc).__name__}: {exc}")

    edges = getattr(results, "edges", []) or []
    nodes = getattr(results, "nodes", []) or []

    seen_ids: list[str] = []
    seen_set: set[str] = set()

    def _emit(our_id: str) -> None:
        if our_id not in seen_set:
            seen_set.add(our_id)
            seen_ids.append(our_id)

    for edge in edges:
        for ep_uuid in getattr(edge, "episodes", []) or []:
            _emit(uuid_to_ours.get(ep_uuid, ep_uuid))

    node_uuids = [getattr(n, "uuid", None) for n in nodes if getattr(n, "uuid", None)]
    if node_uuids:
        cypher_records, _, _ = await client.driver.execute_query(
            """
            MATCH (ep:Episodic)-[:MENTIONS]->(n:Entity)
            WHERE n.uuid IN $node_uuids AND ep.group_id = $group_id
            RETURN DISTINCT ep.name AS our_id
            """,
            node_uuids=node_uuids,
            group_id=GROUP_ID,
        )
        for rec in cypher_records:
            our_id = rec["our_id"]
            if our_id:
                _emit(our_id)

    rank: int | None = None
    for i, ep_id in enumerate(seen_ids):
        if ep_id == spec.expects:
            rank = i + 1
            break

    top_k_hit = rank is not None and rank <= TOP_K

    return ProbeResult(
        spec=spec,
        returned_episode_ids=seen_ids,
        edge_count=len(edges),
        node_count=len(nodes),
        top_k_hit=top_k_hit,
        rank=rank,
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def _summarize(results: list[ProbeResult]) -> dict[str, Any]:
    controls = [r for r in results if r.spec.probe_type == "control"]
    cross = [r for r in results if r.spec.probe_type == "cross"]
    control_hits = sum(1 for r in controls if r.top_k_hit)
    cross_hits = sum(1 for r in cross if r.top_k_hit)
    cross_top_k_rate = cross_hits / max(len(cross), 1)
    controls_valid = control_hits == len(controls)

    if not controls_valid:
        decision = "INVALID_CONTROLS_FAILED"
    elif cross_top_k_rate >= ADOPT_THRESHOLD:
        decision = "ADOPT"
    elif cross_top_k_rate >= ADOPT_WITH_GAPS_THRESHOLD:
        decision = "ADOPT_WITH_GAPS"
    else:
        decision = "REJECT"

    return {
        "controls_total": len(controls),
        "controls_hits": control_hits,
        "controls_valid": controls_valid,
        "cross_total": len(cross),
        "cross_hits": cross_hits,
        "cross_top_k_rate": round(cross_top_k_rate, 4),
        "top_k": TOP_K,
        "decision": decision,
    }


async def amain() -> int:
    load_dotenv(HERE.parent.parent / ".env")
    episodes = load_episodes(EPISODES_PATH)
    probes = load_probes(QUERIES_PATH)
    print(f"loaded {len(episodes)} episodes, {len(probes)} probes")

    client = make_graphiti()
    try:
        print("building indices and constraints...")
        await client.build_indices_and_constraints()

        if _env("GNOKEE_SPIKE_SKIP_INGEST") == "1":
            uuid_to_ours = {}
            records, _, _ = await client.driver.execute_query(
                "MATCH (ep:Episodic) WHERE ep.group_id = $g RETURN ep.uuid AS uuid, ep.name AS our_id",
                g=GROUP_ID,
            )
            for rec in records:
                uuid_to_ours[rec["uuid"]] = rec["our_id"]
            print(f"skipping ingest (GNOKEE_SPIKE_SKIP_INGEST=1); {len(uuid_to_ours)} mappings rebuilt from Neo4j")
        else:
            print(f"ingesting {len(episodes)} episodes...")
            uuid_to_ours = await ingest_corpus(client, episodes)
            print(f"ingest done; {len(uuid_to_ours)} mappings recorded")

        print(f"running {len(probes)} probes...")
        results: list[ProbeResult] = []
        for p in probes:
            print(f"  - {p.id} ({p.query_lang}->{p.target_lang}, {p.probe_type}): {p.query!r}")
            results.append(await ask_graphiti(client, p, uuid_to_ours))
    finally:
        await client.close()

    summary = _summarize(results)

    RESULTS_DIR.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out = RESULTS_DIR / f"{stamp}.json"
    out.write_text(
        json.dumps(
            {
                "graphiti_version": "0.29",
                "harness_version": "q2_v1",
                "embed_model": _env("GNOKEE_EMBED_MODEL", "text-embedding-3-small"),
                "summary": summary,
                "results": [
                    {
                        "id": r.spec.id,
                        "query_lang": r.spec.query_lang,
                        "target_lang": r.spec.target_lang,
                        "target_fact": r.spec.target_fact,
                        "probe_type": r.spec.probe_type,
                        "expected": r.spec.expects,
                        "returned": r.returned_episode_ids,
                        "rank": r.rank,
                        "top_k_hit": r.top_k_hit,
                        "edge_count": r.edge_count,
                        "node_count": r.node_count,
                        "error": r.error,
                    }
                    for r in results
                ],
            },
            indent=2,
            ensure_ascii=False,
        )
    )

    print()
    print(f"controls: {summary['controls_hits']}/{summary['controls_total']} (valid={summary['controls_valid']})")
    print(
        f"cross-lingual top-{TOP_K}: {summary['cross_hits']}/{summary['cross_total']}"
        f" = {summary['cross_top_k_rate']*100:.1f}%"
    )
    print(f"decision: {summary['decision']}")
    print(f"wrote {out}")
    return 0


def main() -> int:
    return asyncio.run(amain())


if __name__ == "__main__":
    sys.exit(main())
