"""evals/spike_q2_multilingual/direct_cosine.py — bypasses Graphiti entirely.

Embeds each episode's full content and each probe query directly via the
same Ollama bge-m3 endpoint Graphiti was configured to use, then ranks
by cosine similarity. Same probe schema and same top-3 hit-rate
criterion as run.py, so the two harnesses produce comparable headline
numbers and the delta isolates Graphiti's retrieval pipeline as the
variable.

exports: HERE | EPISODES_PATH | QUERIES_PATH | RESULTS_DIR | TOP_K | ADOPT_THRESHOLD | ADOPT_WITH_GAPS_THRESHOLD | embed(text, model, base_url) | cosine(a, b) | main()
used_by: none
rules:   none
agent:   codedna-cli (no-llm) | codedna-cli | 2026-05-08 | codedna-cli | initial CodeDNA annotation pass
message: 
"""

from __future__ import annotations

import json
import math
import os
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv

HERE = Path(__file__).parent
EPISODES_PATH = HERE / "episodes.jsonl"
QUERIES_PATH = HERE / "queries.yaml"
RESULTS_DIR = HERE / "results"

TOP_K = 3
ADOPT_THRESHOLD = 0.80
ADOPT_WITH_GAPS_THRESHOLD = 0.50


def _env(key: str, default: str | None = None) -> str | None:
    value = os.environ.get(key, default)
    if value is None or value == "":
        return None
    return value


def embed(text: str, model: str, base_url: str) -> list[float]:
    body = json.dumps({"model": model, "prompt": text}).encode()
    req = urllib.request.Request(
        f"{base_url.rstrip('/')}/api/embeddings",
        data=body,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read())["embedding"]


def cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


def main() -> int:
    load_dotenv(HERE.parent.parent / ".env")

    base_url = _env("GNOKEE_EMBED_BASE_URL", "http://localhost:11434/v1") or ""
    # The Ollama-native /api/embeddings endpoint, not the OpenAI shim:
    if base_url.rstrip("/").endswith("/v1"):
        base_url = base_url.rstrip("/")[: -len("/v1")]
    model = _env("GNOKEE_EMBED_MODEL", "bge-m3") or "bge-m3"

    episodes = [json.loads(line) for line in EPISODES_PATH.read_text().splitlines() if line.strip()]
    probes = yaml.safe_load(QUERIES_PATH.read_text())["queries"]
    print(f"loaded {len(episodes)} episodes, {len(probes)} probes")
    print(f"embedder: {model} @ {base_url}")

    print("embedding episodes...")
    ep_embeddings: dict[str, list[float]] = {}
    for ep in episodes:
        ep_embeddings[ep["id"]] = embed(ep["content"], model, base_url)

    print("running probes...")
    results: list[dict[str, Any]] = []
    for p in probes:
        q_embedding = embed(p["query"], model, base_url)
        scored = sorted(
            ((cosine(q_embedding, ep_embeddings[ep["id"]]), ep["id"]) for ep in episodes),
            reverse=True,
        )
        ranked_ids = [ep_id for _, ep_id in scored]
        rank: int | None = None
        for i, ep_id in enumerate(ranked_ids, 1):
            if ep_id == p["expects"]:
                rank = i
                break
        top_k_hit = rank is not None and rank <= TOP_K
        results.append(
            {
                "id": p["id"],
                "query_lang": p["query_lang"],
                "target_lang": p["target_lang"],
                "target_fact": p["target_fact"],
                "probe_type": p["probe_type"],
                "expected": p["expects"],
                "ranked": ranked_ids,
                "scores": [round(s, 4) for s, _ in scored],
                "rank": rank,
                "top_k_hit": top_k_hit,
            }
        )
        mark = "OK " if top_k_hit else "X  "
        print(f"  {mark} {p['id']:10s} {p['probe_type']:7s} rank={rank}")

    controls = [r for r in results if r["probe_type"] == "control"]
    cross = [r for r in results if r["probe_type"] == "cross"]
    control_hits = sum(1 for r in controls if r["top_k_hit"])
    cross_hits = sum(1 for r in cross if r["top_k_hit"])
    cross_rate = cross_hits / max(len(cross), 1)
    controls_valid = control_hits == len(controls)

    if not controls_valid:
        decision = "INVALID_CONTROLS_FAILED"
    elif cross_rate >= ADOPT_THRESHOLD:
        decision = "ADOPT"
    elif cross_rate >= ADOPT_WITH_GAPS_THRESHOLD:
        decision = "ADOPT_WITH_GAPS"
    else:
        decision = "REJECT"

    summary = {
        "controls_total": len(controls),
        "controls_hits": control_hits,
        "controls_valid": controls_valid,
        "cross_total": len(cross),
        "cross_hits": cross_hits,
        "cross_top_k_rate": round(cross_rate, 4),
        "top_k": TOP_K,
        "decision": decision,
    }

    RESULTS_DIR.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out = RESULTS_DIR / f"direct_{stamp}.json"
    out.write_text(
        json.dumps(
            {
                "harness_version": "direct_cosine_v1",
                "embed_model": model,
                "embed_base_url": base_url,
                "summary": summary,
                "results": results,
            },
            indent=2,
            ensure_ascii=False,
        )
    )

    print()
    print(f"controls: {control_hits}/{len(controls)} (valid={controls_valid})")
    print(f"cross-lingual top-{TOP_K}: {cross_hits}/{len(cross)} = {cross_rate*100:.1f}%")
    print(f"decision: {decision}")
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
