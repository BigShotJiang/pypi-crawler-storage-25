"""evals/spike_q3_token_efficiency/run.py — MCP token-efficiency.

A/B two response shapes on the Q1 corpus + Q1 query set:

  - Mode A `graphiti_raw`: Graphiti `client.search_()` with
    COMBINED_HYBRID_SEARCH_RRF, top-3 edges dumped with full per-edge
    metadata (the naive MCP-passthrough baseline)
  - Mode B `gnokee`: bge-m3 cosine over per-episode content, top-3
    episodes rendered as natural-language statements with lazy
    provenance handles (the v0.1 design per ADR-0004)

Reuses the Q1 corpus already in Neo4j under group_id=spike, so this
spike does not re-ingest. Run from this directory:

    python3 -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python run.py

Reads:
  ../spike_q1_graphiti/queries.yaml
  ../spike_q1_graphiti/episodes.jsonl

exports: HERE | Q1_DIR | EPISODES_PATH | QUERIES_PATH | RESULTS_DIR | GROUP_ID | TOP_K | TOKEN_REDUCTION_THRESHOLD | RECALL_THRESHOLD | ENCODER | make_graphiti() | cosine(a, b) | class QuerySpec | build_search_filters(spec) | render_graphiti_raw(edges, top_k) | graphiti_raw_response(client, spec, top_k, uuid_to_ours) | render_gnokee(spec, ranked_episodes, top_k) | gnokee_response(spec, episodes, embed_url, embed_model, top_k, ep_embeddings) | count_tokens(text) | grade_recall(returned_top_k, expected) | (+2 more)
used_by: none
rules:   none
agent:   codedna-cli (no-llm) | codedna-cli | 2026-05-08 | codedna-cli | initial CodeDNA annotation pass
message: 
"""

from __future__ import annotations

import asyncio
import json
import math
import os
import statistics
import sys
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import tiktoken
import yaml
from dotenv import load_dotenv
from graphiti_core import Graphiti
from graphiti_core.cross_encoder.openai_reranker_client import OpenAIRerankerClient
from graphiti_core.embedder import OpenAIEmbedder, OpenAIEmbedderConfig
from graphiti_core.llm_client import LLMConfig, OpenAIClient
from graphiti_core.search.search_config_recipes import COMBINED_HYBRID_SEARCH_RRF
from graphiti_core.search.search_filters import (
    ComparisonOperator,
    DateFilter,
    SearchFilters,
)

HERE = Path(__file__).parent
Q1_DIR = HERE.parent / "spike_q1_graphiti"
EPISODES_PATH = Q1_DIR / "episodes.jsonl"
QUERIES_PATH = Q1_DIR / "queries.yaml"
RESULTS_DIR = HERE / "results"

GROUP_ID = "spike"   # the Q1 corpus group_id; data already in Neo4j
TOP_K = 3
TOKEN_REDUCTION_THRESHOLD = 0.30
RECALL_THRESHOLD = 0.80

# tiktoken cl100k_base — the encoding shared by gpt-4 family and the
# closest portable proxy for "what an MCP-attached LLM will see".
ENCODER = tiktoken.get_encoding("cl100k_base")


# ---------------------------------------------------------------------------
# Config helpers (same shape as Q1/Q2)
# ---------------------------------------------------------------------------


def _env(key: str, default: str | None = None) -> str | None:
    value = os.environ.get(key, default)
    if value is None or value == "":
        return None
    return value


def _require(key: str) -> str:
    value = _env(key)
    if value is None:
        raise SystemExit(f"missing required env var: {key}")
    return value


def _llm_config() -> LLMConfig:
    return LLMConfig(
        api_key=_env("GNOKEE_LLM_API_KEY") or _env("OPENAI_API_KEY") or "ollama",
        model=_env("GNOKEE_LLM_MODEL", "gpt-4o-mini"),
        base_url=_env("GNOKEE_LLM_BASE_URL"),
        small_model=_env("GNOKEE_LLM_SMALL_MODEL"),
        temperature=float(_env("GNOKEE_LLM_TEMPERATURE", "0") or "0"),
    )


def make_graphiti() -> Graphiti:
    return Graphiti(
        uri=_require("GNOKEE_NEO4J_URI"),
        user=_require("GNOKEE_NEO4J_USER"),
        password=_require("GNOKEE_NEO4J_PASSWORD"),
        llm_client=OpenAIClient(config=_llm_config()),
        embedder=OpenAIEmbedder(
            config=OpenAIEmbedderConfig(
                embedding_model=_env("GNOKEE_EMBED_MODEL", "text-embedding-3-small"),
                embedding_dim=int(_env("GNOKEE_EMBED_DIM", "1024") or "1024"),
                api_key=_env("GNOKEE_EMBED_API_KEY") or _env("OPENAI_API_KEY") or "ollama",
                base_url=_env("GNOKEE_EMBED_BASE_URL"),
            )
        ),
        cross_encoder=OpenAIRerankerClient(config=_llm_config()),
    )


# ---------------------------------------------------------------------------
# bge-m3 direct cosine (Q2 primitive, repurposed for Mode B)
# ---------------------------------------------------------------------------


def _embed_via_ollama(text: str, base_url: str, model: str) -> list[float]:
    body = json.dumps({"model": model, "prompt": text}).encode()
    req = urllib.request.Request(
        f"{base_url.rstrip('/')}/api/embeddings",
        data=body,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        return json.loads(resp.read())["embedding"]


def cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    return dot / (na * nb) if na and nb else 0.0


# ---------------------------------------------------------------------------
# Loaders + filter logic copied from Q1 v2.1
# ---------------------------------------------------------------------------


@dataclass
class QuerySpec:
    id: str
    pattern: str
    query: str
    expects: list[str]
    axes: str
    notes: str
    as_of: str | None = None
    tx_as_of: str | None = None


def _parse_iso(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def build_search_filters(spec: QuerySpec) -> SearchFilters | None:
    valid_at: list[list[DateFilter]] | None = None
    invalid_at: list[list[DateFilter]] | None = None
    created_at: list[list[DateFilter]] | None = None
    attempted = False
    if spec.as_of:
        as_of_dt = _parse_iso(spec.as_of)
        valid_at = [[DateFilter(date=as_of_dt, comparison_operator=ComparisonOperator.less_than_equal)]]
        invalid_at = [
            [DateFilter(comparison_operator=ComparisonOperator.is_null)],
            [DateFilter(date=as_of_dt, comparison_operator=ComparisonOperator.greater_than)],
        ]
        attempted = True
    if spec.tx_as_of:
        tx_dt = _parse_iso(spec.tx_as_of)
        created_at = [[DateFilter(date=tx_dt, comparison_operator=ComparisonOperator.less_than_equal)]]
        attempted = True
    if not attempted:
        return None
    return SearchFilters(valid_at=valid_at, invalid_at=invalid_at, created_at=created_at)


# ---------------------------------------------------------------------------
# Mode A — graphiti_raw response
# ---------------------------------------------------------------------------


def render_graphiti_raw(edges: list[Any], top_k: int) -> str:
    lines: list[str] = []
    for edge in edges[:top_k]:
        lines.append(f"Edge {getattr(edge, 'uuid', '?')}:")
        lines.append(f"  Fact: {getattr(edge, 'fact', '') or ''}")
        valid_at = getattr(edge, "valid_at", None)
        invalid_at = getattr(edge, "invalid_at", None)
        lines.append(f"  Valid at: {valid_at if valid_at else 'null'}")
        lines.append(f"  Invalid at: {invalid_at if invalid_at else 'null'}")
        ep_uuids = getattr(edge, "episodes", []) or []
        lines.append(f"  Episodes: {', '.join(str(u) for u in ep_uuids) or 'none'}")
    return "\n".join(lines)


async def graphiti_raw_response(
    client: Graphiti,
    spec: QuerySpec,
    top_k: int,
    uuid_to_ours: dict[str, str],
) -> tuple[str, list[str]]:
    """Returns (rendered_text, top_k_episode_ids_for_recall_grading)."""
    results = await client.search_(
        query=spec.query,
        config=COMBINED_HYBRID_SEARCH_RRF,
        group_ids=[GROUP_ID],
        search_filter=build_search_filters(spec),
    )
    edges = getattr(results, "edges", []) or []
    nodes = getattr(results, "nodes", []) or []

    # Recall: same node-mention Cypher resolution Q1 v2.1 used, so the
    # recall comparison is apples-to-apples against the Q1 ADOPT verdict.
    seen: list[str] = []
    seen_set: set[str] = set()
    for edge in edges:
        for ep_uuid in getattr(edge, "episodes", []) or []:
            our_id = uuid_to_ours.get(ep_uuid, ep_uuid)
            if our_id not in seen_set:
                seen_set.add(our_id)
                seen.append(our_id)
    node_uuids = [getattr(n, "uuid", None) for n in nodes if getattr(n, "uuid", None)]
    if node_uuids:
        records, _, _ = await client.driver.execute_query(
            """
            MATCH (ep:Episodic)-[:MENTIONS]->(n:Entity)
            WHERE n.uuid IN $node_uuids AND ep.group_id = $group_id
            RETURN DISTINCT ep.name AS our_id
            """,
            node_uuids=node_uuids,
            group_id=GROUP_ID,
        )
        for rec in records:
            our_id = rec["our_id"]
            if our_id and our_id not in seen_set:
                seen_set.add(our_id)
                seen.append(our_id)
    return render_graphiti_raw(edges, top_k), seen[:top_k]


# ---------------------------------------------------------------------------
# Mode B — gnokee response (bge-m3 direct cosine + compact format)
# ---------------------------------------------------------------------------


def _first_sentence(text: str, max_chars: int = 200) -> str:
    text = text.strip().replace("\n", " ")
    for sep in [". ", "; ", "! ", "? "]:
        if sep in text:
            head = text.split(sep, 1)[0]
            if 20 <= len(head) <= max_chars:
                return head + sep.strip()
    return text[:max_chars].rstrip()


def render_gnokee(
    spec: QuerySpec,
    ranked_episodes: list[dict[str, Any]],
    top_k: int,
) -> str:
    lines: list[str] = []
    for i, ep in enumerate(ranked_episodes[:top_k], 1):
        statement = _first_sentence(ep["content"])
        valid_at = ep.get("valid_time_start", "")
        date_part = valid_at[:10] if valid_at else "unknown"
        lines.append(f"{i}. {statement} [ep:{ep['id']}, valid_at:{date_part}]")
    return "\n".join(lines)


def gnokee_response(
    spec: QuerySpec,
    episodes: list[dict[str, Any]],
    embed_url: str,
    embed_model: str,
    top_k: int,
    ep_embeddings: dict[str, list[float]],
) -> tuple[str, list[str]]:
    q_embedding = _embed_via_ollama(spec.query, embed_url, embed_model)
    scored = sorted(
        ((cosine(q_embedding, ep_embeddings[ep["id"]]), ep) for ep in episodes),
        key=lambda x: x[0],
        reverse=True,
    )
    top = [ep for _, ep in scored[:top_k]]
    return render_gnokee(spec, top, top_k), [ep["id"] for ep in top]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def count_tokens(text: str) -> int:
    return len(ENCODER.encode(text))


def grade_recall(returned_top_k: list[str], expected: list[str]) -> bool:
    return any(e in returned_top_k for e in expected)


async def amain() -> int:
    load_dotenv(HERE.parent.parent / ".env")
    episodes = [
        json.loads(line) for line in EPISODES_PATH.read_text().splitlines() if line.strip()
    ]
    raw = yaml.safe_load(QUERIES_PATH.read_text())
    queries = [QuerySpec(**entry) for entry in raw["queries"]]
    print(f"loaded {len(episodes)} episodes, {len(queries)} queries (from Q1 corpus)")

    # Resolve Ollama base url for the direct-cosine path.
    embed_base = _env("GNOKEE_EMBED_BASE_URL", "http://localhost:11434/v1") or ""
    if embed_base.rstrip("/").endswith("/v1"):
        embed_base = embed_base.rstrip("/")[: -len("/v1")]
    embed_model = _env("GNOKEE_EMBED_MODEL", "bge-m3") or "bge-m3"
    print(f"embedder: {embed_model} @ {embed_base}")

    print("embedding episodes for Mode B...")
    ep_embeddings = {ep["id"]: _embed_via_ollama(ep["content"], embed_base, embed_model) for ep in episodes}

    client = make_graphiti()

    # Build uuid_to_ours from existing Neo4j data so we don't re-ingest.
    uuid_to_ours: dict[str, str] = {}
    records, _, _ = await client.driver.execute_query(
        "MATCH (ep:Episodic) WHERE ep.group_id = $g RETURN ep.uuid AS uuid, ep.name AS our_id",
        g=GROUP_ID,
    )
    for rec in records:
        uuid_to_ours[rec["uuid"]] = rec["our_id"]
    print(f"loaded {len(uuid_to_ours)} episode UUID mappings from Neo4j ({GROUP_ID})")
    if not uuid_to_ours:
        print(f"ERROR: no episodes in Neo4j under group_id={GROUP_ID}; run Q1 spike first to populate.")
        await client.close()
        return 1

    per_query: list[dict[str, Any]] = []
    try:
        for spec in queries:
            print(f"  - {spec.id}: {spec.query!r}")
            graphiti_text, graphiti_top = await graphiti_raw_response(
                client, spec, TOP_K, uuid_to_ours
            )
            gnokee_text, gnokee_top = gnokee_response(
                spec, episodes, embed_base, embed_model, TOP_K, ep_embeddings
            )
            per_query.append(
                {
                    "id": spec.id,
                    "query": spec.query,
                    "expected": spec.expects,
                    "graphiti_raw": {
                        "tokens": count_tokens(graphiti_text),
                        "top_k_ids": graphiti_top,
                        "recall_hit": grade_recall(graphiti_top, spec.expects),
                        "response": graphiti_text,
                    },
                    "gnokee": {
                        "tokens": count_tokens(gnokee_text),
                        "top_k_ids": gnokee_top,
                        "recall_hit": grade_recall(gnokee_top, spec.expects),
                        "response": gnokee_text,
                    },
                }
            )
    finally:
        await client.close()

    n = len(per_query)
    g_tokens = [r["graphiti_raw"]["tokens"] for r in per_query]
    n_tokens = [r["gnokee"]["tokens"] for r in per_query]
    g_recall = sum(1 for r in per_query if r["graphiti_raw"]["recall_hit"]) / n
    n_recall = sum(1 for r in per_query if r["gnokee"]["recall_hit"]) / n

    g_mean = statistics.mean(g_tokens)
    n_mean = statistics.mean(n_tokens)
    reduction = 1.0 - (n_mean / g_mean) if g_mean else 0.0

    summary = {
        "queries": n,
        "graphiti_raw": {
            "mean_tokens": round(g_mean, 2),
            "median_tokens": statistics.median(g_tokens),
            "max_tokens": max(g_tokens),
            "top_k_recall": round(g_recall, 4),
        },
        "gnokee": {
            "mean_tokens": round(n_mean, 2),
            "median_tokens": statistics.median(n_tokens),
            "max_tokens": max(n_tokens),
            "top_k_recall": round(n_recall, 4),
        },
        "token_reduction_pct": round(reduction * 100, 2),
        "top_k": TOP_K,
        "thresholds": {
            "min_token_reduction": TOKEN_REDUCTION_THRESHOLD,
            "min_recall": RECALL_THRESHOLD,
        },
    }
    if reduction >= TOKEN_REDUCTION_THRESHOLD and n_recall >= RECALL_THRESHOLD:
        summary["decision"] = "ADOPT"
    elif n_recall < RECALL_THRESHOLD:
        summary["decision"] = "REJECT_RECALL_FAILED"
    else:
        summary["decision"] = "REJECT_INSUFFICIENT_REDUCTION"

    RESULTS_DIR.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out = RESULTS_DIR / f"{stamp}.json"
    out.write_text(json.dumps({"summary": summary, "per_query": per_query}, indent=2, ensure_ascii=False))

    print()
    print(f"graphiti_raw: mean={g_mean:.0f} tok, recall@{TOP_K}={g_recall*100:.1f}%")
    print(f"gnokee:       mean={n_mean:.0f} tok, recall@{TOP_K}={n_recall*100:.1f}%")
    print(f"reduction: {reduction*100:.1f}%  decision: {summary['decision']}")
    print(f"wrote {out}")
    return 0


def main() -> int:
    return asyncio.run(amain())


if __name__ == "__main__":
    sys.exit(main())
