"""src/gnokee/__init__.py — memory infrastructure for personal AI.

Bi-temporal facts, honest contradictions, autonomous maintenance,
verifiable forgetting. MCP-native, multi-tenant, multilingual.

v0.1 — minimum viable surface. See `docs/specs/v0.1.md`.

exports: ingest_episode | recall | fact_provenance | EpisodeIn | IngestReceipt | RecallResponse | FactStatement | FactProvenance | ContradictionRef
used_by: external consumers
rules:   public surface only here; impl lives under submodules
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

from gnokee.ingest import ingest_episode
from gnokee.models import (
    ContradictionRef,
    EncryptedBody,
    EpisodeIn,
    FactProvenance,
    FactStatement,
    IngestReceipt,
    RecallResponse,
    Sensitivity,
)
from gnokee.retrieval import fact_provenance, recall

try:
    __version__ = _pkg_version("gnokee")
except PackageNotFoundError:
    # Editable install before metadata is built; only happens during a
    # fresh dev clone before the first `pip install -e .`.
    __version__ = "0+unknown"

__all__ = [
    "ContradictionRef",
    "EncryptedBody",
    "EpisodeIn",
    "FactProvenance",
    "FactStatement",
    "IngestReceipt",
    "RecallResponse",
    "Sensitivity",
    "__version__",
    "fact_provenance",
    "ingest_episode",
    "recall",
]
