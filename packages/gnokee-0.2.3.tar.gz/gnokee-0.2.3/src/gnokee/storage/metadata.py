"""src/gnokee/storage/metadata.py — episode_metadata adapter (gnokee tx-time axis).

Owns `asserted_at` ≠ Graphiti's `created_at` semantically (per ADR-0004 +
bi-temporal-auditor). Python layer resolves `asserted_at` defaults; this
module never calls `now()` itself.

exports: class MetadataStore | EpisodeMetadataRow
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py
rules:   tenant_id on every read+write; tz-aware UTC; never SQL DEFAULT now() on asserted_at
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

import asyncpg

from gnokee.errors import VectorStoreError
from gnokee.models import Sensitivity


@dataclass(frozen=True)
class EpisodeMetadataRow:
    tenant_id: str
    episode_uuid: UUID
    valid_at: datetime
    valid_until: datetime | None
    asserted_at: datetime
    asserted_until: datetime | None
    superseded_by: UUID | None
    sensitive: Sensitivity
    language: str | None
    our_id: str | None = None


class MetadataStore:
    """Async wrapper around `episode_metadata`."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def write(
        self,
        *,
        conn: asyncpg.Connection,
        row: EpisodeMetadataRow,
    ) -> bool:
        """Insert metadata row. Returns True iff a new row landed.

        ``ON CONFLICT DO NOTHING`` (bare target) absorbs both the
        ``(tenant_id, episode_uuid)`` PK collision (self-idempotency on
        replayed pipeline runs) and the partial unique index on
        ``(tenant_id, our_id)`` (idempotency on consumer-supplied keys).
        Returning ``False`` signals the caller that the row was already
        present and that downstream side-effects (vector write, Graphiti
        episode) need compensation.
        """
        try:
            result = await conn.fetchrow(
                """
                INSERT INTO episode_metadata (
                    tenant_id, episode_uuid, valid_at, valid_until,
                    asserted_at, asserted_until, superseded_by,
                    sensitive, language, our_id
                ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
                ON CONFLICT DO NOTHING
                RETURNING episode_uuid
                """,
                row.tenant_id,
                row.episode_uuid,
                row.valid_at,
                row.valid_until,
                row.asserted_at,
                row.asserted_until,
                row.superseded_by,
                row.sensitive,
                row.language,
                row.our_id,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.write failed: {exc}") from exc
        return result is not None

    async def filter_visible(
        self,
        *,
        tenant_id: str,
        candidate_uuids: list[UUID],
        as_of: datetime,
        valid_at: datetime,
    ) -> list[UUID]:
        """Apply gnokee bi-temporal predicates on the episode side.

        - source-tx-time half-pair: `asserted_at <= as_of AND (asserted_until IS NULL OR asserted_until > as_of)`
        - episode-level world-time upper bound: `valid_until IS NULL OR valid_until > valid_at`
        Both required; bi-temporal-auditor surfaces partial halves.
        """
        if not candidate_uuids:
            return []
        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT episode_uuid
                      FROM episode_metadata
                     WHERE tenant_id = $1
                       AND episode_uuid = ANY($2::uuid[])
                       AND asserted_at <= $3
                       AND (asserted_until IS NULL OR asserted_until > $3)
                       AND (valid_until    IS NULL OR valid_until    > $4)
                    """,
                    tenant_id,
                    candidate_uuids,
                    as_of,
                    valid_at,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.filter_visible failed: {exc}") from exc
        return [r["episode_uuid"] for r in rows]

    async def get(
        self,
        *,
        tenant_id: str,
        episode_uuid: UUID,
    ) -> EpisodeMetadataRow | None:
        try:
            async with self._pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT tenant_id, episode_uuid, valid_at, valid_until,
                           asserted_at, asserted_until, superseded_by,
                           sensitive, language, our_id
                      FROM episode_metadata
                     WHERE tenant_id = $1 AND episode_uuid = $2
                    """,
                    tenant_id,
                    episode_uuid,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.get failed: {exc}") from exc
        if row is None:
            return None
        return _row_to_dc(row)

    async def get_by_our_id(
        self,
        *,
        tenant_id: str,
        our_id: str,
    ) -> EpisodeMetadataRow | None:
        """Lookup an episode by consumer-supplied (tenant_id, our_id) key.

        Used by the ingest pipeline to short-circuit on idempotent re-ingest.
        Returns ``None`` when no episode has been recorded against the key yet.
        """
        try:
            async with self._pool.acquire() as conn:
                row = await conn.fetchrow(
                    """
                    SELECT tenant_id, episode_uuid, valid_at, valid_until,
                           asserted_at, asserted_until, superseded_by,
                           sensitive, language, our_id
                      FROM episode_metadata
                     WHERE tenant_id = $1 AND our_id = $2
                    """,
                    tenant_id,
                    our_id,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.get_by_our_id failed: {exc}") from exc
        if row is None:
            return None
        return _row_to_dc(row)

    _CHAIN_DEPTH_LIMIT = 32

    async def chain_head_at(
        self,
        *,
        tenant_id: str,
        start_uuid: UUID,
        as_of: datetime,
    ) -> EpisodeMetadataRow | None:
        """Walk `superseded_by` from `start_uuid` to the chain's head as
        of `as_of`. Read-only, no FOR UPDATE — used by retrieval to
        resolve supersession hints (issue #19) where contention with the
        write path is undesirable.

        Returns the row that is open at `as_of` (asserted_at <= as_of
        AND (asserted_until IS NULL OR asserted_until > as_of)), or the
        last row in the chain when every episode in the chain is closed
        at `as_of` (rare; e.g. a redaction chain). Returns ``None`` when
        the starting episode does not exist or belongs to a different
        tenant.

        Bounded depth: chains > 32 hops raise ``CorrectsChainError``
        (defensive; matches the write-side bound on
        :py:meth:`supersede`).
        """
        from gnokee.errors import CorrectsChainError

        current_uuid = start_uuid
        last_row: asyncpg.Record | None = None
        try:
            async with self._pool.acquire() as conn:
                for _ in range(self._CHAIN_DEPTH_LIMIT):
                    row = await conn.fetchrow(
                        """
                        SELECT tenant_id, episode_uuid, valid_at, valid_until,
                               asserted_at, asserted_until, superseded_by,
                               sensitive, language, our_id
                          FROM episode_metadata
                         WHERE tenant_id = $1 AND episode_uuid = $2
                        """,
                        tenant_id,
                        current_uuid,
                    )
                    if row is None:
                        return None if last_row is None else _row_to_dc(last_row)
                    last_row = row
                    open_at_as_of = row["asserted_at"] <= as_of and (
                        row["asserted_until"] is None or row["asserted_until"] > as_of
                    )
                    if open_at_as_of:
                        return _row_to_dc(row)
                    next_uuid = row["superseded_by"]
                    if next_uuid is None:
                        return _row_to_dc(row)
                    current_uuid = next_uuid
                else:
                    raise CorrectsChainError(
                        f"chain_head_at: superseded_by chain exceeded "
                        f"{self._CHAIN_DEPTH_LIMIT} hops starting at "
                        f"{start_uuid}"
                    )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.chain_head_at failed: {exc}") from exc

    async def supersede(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        corrected_episode_uuid: UUID,
        new_episode_uuid: UUID,
        asserted_until: datetime,
    ) -> EpisodeMetadataRow:
        """Close ``episode_metadata`` for the corrected episode (v0.2.1).

        Validates: same tenant, episode exists, asserted_at axis (new
        > corrected). If the named episode is already superseded, walks
        ``superseded_by`` chain to current head and supersedes the head
        instead. Each hop SELECT uses ``FOR UPDATE`` so concurrent
        ``corrects:`` requests against the same chain serialize
        correctly under READ COMMITTED.

        Bounded depth: chains > 32 hops raise ``CorrectsChainError``
        (defensive against cycles).

        Returns the head ``EpisodeMetadataRow`` (the row that was
        UPDATEd). Caller passes ``head.episode_uuid`` to
        :py:meth:`gnokee.storage.lab.LabStore.supersede_matching` /
        :py:meth:`gnokee.storage.med.MedStore.supersede_matching` so
        row-level supersession lands on the same row that has open
        visible state.
        """
        # Local import: gnokee.errors imports models for Sensitivity
        # (transitively) — keep top-level imports minimal.
        from gnokee.errors import (
            CorrectsAxisInversionError,
            CorrectsChainError,
            CorrectsCrossTenantError,
            EpisodeNotFoundError,
        )

        current_uuid = corrected_episode_uuid
        head_row: asyncpg.Record | None = None
        try:
            for _ in range(self._CHAIN_DEPTH_LIMIT):
                row = await conn.fetchrow(
                    """
                    SELECT tenant_id, episode_uuid, valid_at, valid_until,
                           asserted_at, asserted_until, superseded_by,
                           sensitive, language, our_id
                      FROM episode_metadata
                     WHERE episode_uuid = $1
                       FOR UPDATE
                    """,
                    current_uuid,
                )
                if row is None:
                    raise EpisodeNotFoundError(current_uuid)
                if row["tenant_id"] != tenant_id:
                    raise CorrectsCrossTenantError(
                        f"corrects: episode {current_uuid} belongs to tenant {row['tenant_id']!r}, not {tenant_id!r}"
                    )
                if row["asserted_until"] is None:
                    head_row = row
                    break
                next_uuid = row["superseded_by"]
                if next_uuid is None:
                    # Closed but not pointing forward — historical
                    # data quirk. Treat as the chain head.
                    head_row = row
                    break
                current_uuid = next_uuid
            else:
                raise CorrectsChainError(
                    f"corrects: superseded_by chain exceeded "
                    f"{self._CHAIN_DEPTH_LIMIT} hops starting at "
                    f"{corrected_episode_uuid}"
                )

            assert head_row is not None  # narrowed by loop above
            if asserted_until <= head_row["asserted_at"]:
                raise CorrectsAxisInversionError(
                    f"corrects: new asserted_at={asserted_until.isoformat()} "
                    f"<= corrected.asserted_at="
                    f"{head_row['asserted_at'].isoformat()} "
                    f"(head episode={head_row['episode_uuid']})"
                )
            await conn.execute(
                """
                UPDATE episode_metadata
                   SET asserted_until = $3,
                       superseded_by  = $4
                 WHERE tenant_id    = $1
                   AND episode_uuid = $2
                   AND asserted_until IS NULL
                """,
                tenant_id,
                head_row["episode_uuid"],
                asserted_until,
                new_episode_uuid,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"metadata.supersede failed: {exc}") from exc
        return _row_to_dc(head_row)


def _row_to_dc(row: asyncpg.Record) -> EpisodeMetadataRow:
    return EpisodeMetadataRow(
        tenant_id=row["tenant_id"],
        episode_uuid=row["episode_uuid"],
        valid_at=row["valid_at"],
        valid_until=row["valid_until"],
        asserted_at=row["asserted_at"],
        asserted_until=row["asserted_until"],
        superseded_by=row["superseded_by"],
        sensitive=row["sensitive"],
        language=row["language"],
        our_id=row["our_id"],
    )
