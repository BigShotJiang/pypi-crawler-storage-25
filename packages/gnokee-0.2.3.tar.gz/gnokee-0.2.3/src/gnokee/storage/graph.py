"""src/gnokee/storage/graph.py — Graphiti / Neo4j adapter.

Wraps `graphiti-core` 0.29 + raw Cypher for stages 2a, 4, contradiction
cosine, and provenance fetch. `group_id = tenant_id` on every call.

exports: class GraphitiStore | EpisodeCandidate | FactRow | ProvenanceRow | bootstrap_indices
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py | src/gnokee/contradiction.py
rules:   tenant_id → group_id; raw Cypher only for what graphiti-core does not cover; v0.1 ADR-0004 exception is fact-embedding cosine (vector lives on Graphiti edge)
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any
from uuid import UUID

from graphiti_core import Graphiti
from graphiti_core.cross_encoder.client import CrossEncoderClient
from graphiti_core.embedder.client import EmbedderClient
from graphiti_core.graphiti import AddEpisodeResults
from graphiti_core.llm_client.client import LLMClient
from graphiti_core.nodes import EpisodeType

from gnokee.errors import GraphStoreError


@dataclass(frozen=True)
class EpisodeCandidate:
    """Stage 2a output: episodes whose `valid_at <= world_time`."""

    episode_uuid: UUID


@dataclass(frozen=True)
class FactRow:
    """Stage 4 output: a fact (EntityEdge) tied to a candidate episode."""

    fact_uuid: UUID
    text: str
    valid_at: datetime
    episode_uuid: UUID


@dataclass(frozen=True)
class ProvenanceRow:
    """Output of `fetch_provenance`: full episode body + EntityEdge attrs."""

    fact_uuid: UUID
    fact_text: str
    fact_valid_at: datetime
    episode_uuid: UUID
    episode_content: str


@dataclass(frozen=True)
class CosineCandidate:
    """Output of `cosine_search_facts` (Q4 contradiction stage)."""

    fact_uuid: UUID
    fact_text: str
    valid_at: datetime
    score: float


class GraphitiStore:
    """Thin async wrapper over `Graphiti`.

    Construct with an already-initialised `Graphiti` instance — the v0.1 path
    builds it from `Settings` in `gnokee.config`.
    """

    def __init__(self, graphiti: Graphiti) -> None:
        self._g = graphiti

    @property
    def graphiti(self) -> Graphiti:
        return self._g

    async def add_episode(
        self,
        *,
        tenant_id: str,
        name: str,
        content: str,
        reference_time: datetime,
        source_description: str = "gnokee.ingest",
        entity_type_hints: list[str] | None = None,
    ) -> AddEpisodeResults:
        """Wrap `graphiti.add_episode`. Always passes `group_id=tenant_id`.

        `reference_time` MUST be `valid_at` per ADR-0004 — never `now()`.
        Per AGENTS.md `entity_type_hints` is advisory; not threaded into
        Graphiti's extractor in v0.1.
        """
        try:
            return await self._g.add_episode(
                name=name,
                episode_body=content,
                source_description=source_description,
                reference_time=reference_time,
                source=EpisodeType.text,
                group_id=tenant_id,
            )
        except Exception as exc:  # graphiti raises a heterogenous mix
            raise GraphStoreError(f"add_episode failed: {exc}") from exc

    async def remove_episode(self, episode_uuid: UUID) -> None:
        try:
            await self._g.remove_episode(str(episode_uuid))
        except Exception as exc:
            raise GraphStoreError(f"remove_episode failed: {exc}") from exc

    async def overwrite_episode_content(
        self,
        *,
        tenant_id: str,
        episode_uuid: UUID,
        content: str,
    ) -> None:
        """Replace ``Episodic.content`` after a preprocessor-augmented
        ``add_episode``. Tenant predicate prevents cross-tenant write.

        Used by the v0.1.1 preprocessor (issues #2/#3/#4) so provenance
        returns the original markdown rather than the augmented body.
        """
        cypher = """
        MATCH (ep:Episodic {uuid: $uuid, group_id: $tenant})
        SET ep.content = $content
        """
        try:
            await self._g.driver.execute_query(
                cypher,
                uuid=str(episode_uuid),
                tenant=tenant_id,
                content=content,
            )
        except Exception as exc:
            raise GraphStoreError(
                f"overwrite_episode_content failed: {exc}",
            ) from exc

    async def list_candidate_episodes(
        self,
        *,
        tenant_id: str,
        valid_at: datetime,
        candidate_pool: int,
    ) -> list[EpisodeCandidate]:
        """Stage 2a: episodes whose world-time lower bound is satisfied.

        `EpisodicNode` has no `invalid_at` — half-pair only on the lower
        bound here. Upper bound + asserted-axis live in `MetadataStore`.
        """
        cypher = """
        MATCH (ep:Episodic)
        WHERE ep.group_id = $tenant
          AND ep.valid_at <= $valid_at
        RETURN ep.uuid AS uuid, ep.valid_at AS valid_at
        ORDER BY ep.valid_at DESC, ep.uuid
        LIMIT $limit
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                tenant=tenant_id,
                valid_at=valid_at,
                limit=candidate_pool,
            )
        except Exception as exc:
            raise GraphStoreError(f"list_candidate_episodes failed: {exc}") from exc
        return [EpisodeCandidate(episode_uuid=UUID(r["uuid"])) for r in records]

    async def fetch_facts_for_episodes(
        self,
        *,
        tenant_id: str,
        episode_uuids: list[UUID],
        valid_at: datetime,
    ) -> list[FactRow]:
        """Stage 4: edge half-pair `r.invalid_at IS NULL OR r.invalid_at > X`.

        Undirected `RELATES_TO` so the mentioned entity is matched on either side.
        Tenant predicate on every node + edge to prevent cross-tenant leakage.
        """
        if not episode_uuids:
            return []
        cypher = """
        MATCH (ep:Episodic)-[:MENTIONS]->(n:Entity)-[r:RELATES_TO]-(m:Entity)
        WHERE ep.uuid IN $episode_uuids
          AND ep.group_id = $tenant
          AND n.group_id  = $tenant
          AND m.group_id  = $tenant
          AND r.group_id  = $tenant
          AND (r.valid_at IS NULL OR r.valid_at <= $valid_at)
          AND (r.invalid_at IS NULL OR r.invalid_at > $valid_at)
        RETURN DISTINCT r.uuid AS fact_uuid,
                        r.fact AS fact_text,
                        r.valid_at AS valid_at,
                        ep.uuid AS episode_uuid
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                episode_uuids=[str(u) for u in episode_uuids],
                tenant=tenant_id,
                valid_at=valid_at,
            )
        except Exception as exc:
            raise GraphStoreError(f"fetch_facts_for_episodes failed: {exc}") from exc
        out: list[FactRow] = []
        for r in records:
            v = r["valid_at"]
            if v is None:
                continue
            out.append(
                FactRow(
                    fact_uuid=UUID(r["fact_uuid"]),
                    text=r["fact_text"],
                    valid_at=_to_datetime(v),
                    episode_uuid=UUID(r["episode_uuid"]),
                )
            )
        return out

    async def fact_valid_at_lookup(
        self,
        *,
        tenant_id: str,
        fact_uuids: list[UUID],
    ) -> dict[UUID, datetime]:
        """For contradiction surfacing: each counterpart's `r.valid_at` lookup
        keyed by edge uuid.

        v0.1: lookup is for *display* only (`ContradictionRef.valid_at` so the
        consuming LLM can apply a recency heuristic). It is intentionally NOT
        gated by `valid_at`/`invalid_at` half-pairs — a superseded counterpart
        is still meaningful context to surface.
        """
        if not fact_uuids:
            return {}
        cypher = """
        MATCH ()-[r:RELATES_TO]-()
        WHERE r.group_id = $tenant
          AND r.uuid IN $uuids
        RETURN DISTINCT r.uuid AS uuid, r.valid_at AS valid_at
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                tenant=tenant_id,
                uuids=[str(u) for u in fact_uuids],
            )
        except Exception as exc:
            raise GraphStoreError(f"fact_valid_at_lookup failed: {exc}") from exc
        out: dict[UUID, datetime] = {}
        for r in records:
            v = r["valid_at"]
            if v is None:
                continue
            out[UUID(r["uuid"])] = _to_datetime(v)
        return out

    async def fetch_provenance(
        self,
        *,
        tenant_id: str,
        fact_uuid: UUID,
    ) -> ProvenanceRow | None:
        """For `gnokee_fact_provenance`: full episode body + edge attrs."""
        cypher = """
        MATCH (ep:Episodic)-[:MENTIONS]->(n:Entity)-[r:RELATES_TO]-(m:Entity)
        WHERE r.uuid     = $fact_uuid
          AND r.group_id = $tenant
          AND ep.group_id = $tenant
        RETURN r.uuid AS fact_uuid,
               r.fact AS fact_text,
               r.valid_at AS fact_valid_at,
               ep.uuid AS episode_uuid,
               ep.content AS episode_content
        LIMIT 1
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                fact_uuid=str(fact_uuid),
                tenant=tenant_id,
            )
        except Exception as exc:
            raise GraphStoreError(f"fetch_provenance failed: {exc}") from exc
        if not records:
            return None
        r = records[0]
        return ProvenanceRow(
            fact_uuid=UUID(r["fact_uuid"]),
            fact_text=r["fact_text"],
            fact_valid_at=_to_datetime(r["fact_valid_at"]),
            episode_uuid=UUID(r["episode_uuid"]),
            episode_content=r["episode_content"] or "",
        )

    async def fetch_episode_contents(
        self,
        *,
        tenant_id: str,
        episode_uuids: list[UUID],
    ) -> dict[UUID, str]:
        """Batch-fetch ``Episodic.content`` for a list of UUIDs in one Cypher.

        Used by the recall path's currency-excerpt stage so it can scan
        the verbatim body for amount-bearing lines without running a
        round-trip per episode (gnokee #7).
        """
        if not episode_uuids:
            return {}
        cypher = """
        MATCH (ep:Episodic)
        WHERE ep.group_id = $tenant AND ep.uuid IN $uuids
        RETURN ep.uuid AS episode_uuid, ep.content AS episode_content
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                tenant=tenant_id,
                uuids=[str(u) for u in episode_uuids],
            )
        except Exception as exc:
            raise GraphStoreError(f"fetch_episode_contents failed: {exc}") from exc
        out: dict[UUID, str] = {}
        for r in records:
            try:
                uuid_value = UUID(r["episode_uuid"])
            except (ValueError, TypeError):
                continue
            out[uuid_value] = r["episode_content"] or ""
        return out

    async def cosine_search_facts(
        self,
        *,
        tenant_id: str,
        embedding: list[float],
        top_k: int,
        threshold: float,
        exclude_fact_uuid: UUID | None = None,
    ) -> list[CosineCandidate]:
        """Q4 contradiction stage: cosine over `EntityEdge.fact_embedding`.

        Direct vector-index query (ADR-0004 deliberate exception — the
        target embedding lives on the Graphiti edge, not pgvector).
        """
        cypher = """
        CALL db.index.vector.queryRelationships('entity_edge_fact_embedding', $top_k, $embedding)
        YIELD relationship AS r, score
        WHERE r.group_id = $tenant
          AND ($exclude IS NULL OR r.uuid <> $exclude)
          AND score >= $threshold
        RETURN r.uuid AS uuid, r.fact AS fact_text, r.valid_at AS valid_at, score
        """
        try:
            records, _, _ = await self._g.driver.execute_query(
                cypher,
                top_k=top_k,
                embedding=embedding,
                tenant=tenant_id,
                exclude=str(exclude_fact_uuid) if exclude_fact_uuid else None,
                threshold=threshold,
            )
        except Exception as exc:
            raise GraphStoreError(f"cosine_search_facts failed: {exc}") from exc
        out: list[CosineCandidate] = []
        for r in records:
            v = r["valid_at"]
            if v is None:
                continue
            out.append(
                CosineCandidate(
                    fact_uuid=UUID(r["uuid"]),
                    fact_text=r["fact_text"],
                    valid_at=_to_datetime(v),
                    score=float(r["score"]),
                )
            )
        return out

    async def bootstrap_indices(self) -> None:
        """Run Graphiti's bootstrap + add gnokee-specific indexes.

        Notes:
        - Graphiti's `build_indices_and_constraints()` creates range + fulltext
          indices only. Vector indexes (HNSW) are NOT created by graphiti-core
          0.29 — gnokee creates them here. The 1024-dim vector size locks to
          bge-m3 per Q2 + ADR-0004.
        - `episodic_valid_at` is gnokee-specific (stage 2a candidate narrow).
        """
        try:
            await self._g.build_indices_and_constraints()
            await self._g.driver.execute_query(
                "CREATE INDEX episodic_valid_at IF NOT EXISTS FOR (e:Episodic) ON (e.valid_at)",
            )
            await self._g.driver.execute_query(
                """
                CREATE VECTOR INDEX entity_edge_fact_embedding IF NOT EXISTS
                FOR ()-[r:RELATES_TO]-() ON r.fact_embedding
                OPTIONS {indexConfig: {`vector.dimensions`: 1024, `vector.similarity_function`: 'cosine'}}
                """,
            )
            await self._g.driver.execute_query(
                """
                CREATE VECTOR INDEX entity_name_embedding IF NOT EXISTS
                FOR (n:Entity) ON n.name_embedding
                OPTIONS {indexConfig: {`vector.dimensions`: 1024, `vector.similarity_function`: 'cosine'}}
                """,
            )
        except Exception as exc:
            raise GraphStoreError(f"bootstrap_indices failed: {exc}") from exc


def _to_datetime(value: Any) -> datetime:
    """Coerce Neo4j temporal types or ISO strings to a Python datetime."""
    if isinstance(value, datetime):
        return value
    # neo4j.time.DateTime
    if hasattr(value, "to_native"):
        result = value.to_native()
        if isinstance(result, datetime):
            return result
    if isinstance(value, str):
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    raise GraphStoreError(f"cannot coerce {type(value)} to datetime")


__all__ = [
    "CosineCandidate",
    "CrossEncoderClient",
    "EmbedderClient",
    "EpisodeCandidate",
    "FactRow",
    "GraphitiStore",
    "LLMClient",
    "ProvenanceRow",
]
