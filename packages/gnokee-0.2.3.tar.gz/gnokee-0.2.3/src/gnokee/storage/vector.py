"""src/gnokee/storage/vector.py — pgvector adapter for content_embedding.

Per ADR-0004: gnokee owns content embeddings in pg, keyed by
(tenant_id, episode_uuid). 1024-dim cosine vectors (bge-m3 per Q2).

exports: class PgVectorStore
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py
rules:   tenant_id on every read+write; no business logic
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

from uuid import UUID

import asyncpg

from gnokee.errors import VectorStoreError


def _vector_literal(vec: list[float]) -> str:
    """Render a Python float list as the pgvector text literal `[v1,v2,...]`.

    Used so the connection does not need pgvector codec registration on every
    pool acquire — fits asyncpg-only path for v0.1.
    """
    return "[" + ",".join(repr(float(x)) for x in vec) + "]"


class PgVectorStore:
    """Async wrapper around the `content_embedding` table."""

    def __init__(self, pool: asyncpg.Pool) -> None:
        self._pool = pool

    async def write_embedding(
        self,
        *,
        conn: asyncpg.Connection,
        tenant_id: str,
        episode_uuid: UUID,
        embedding: list[float],
        model: str = "bge-m3",
    ) -> None:
        """INSERT into content_embedding. Caller controls the transaction."""
        try:
            await conn.execute(
                """
                INSERT INTO content_embedding (tenant_id, episode_uuid, embedding, model)
                VALUES ($1, $2, $3::vector, $4)
                ON CONFLICT (tenant_id, episode_uuid) DO UPDATE
                  SET embedding = EXCLUDED.embedding, model = EXCLUDED.model
                """,
                tenant_id,
                episode_uuid,
                _vector_literal(embedding),
                model,
            )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"write_embedding failed: {exc}") from exc

    async def search_embeddings(
        self,
        *,
        tenant_id: str,
        episode_uuids: list[UUID],
        query_vector: list[float],
        top_k: int,
    ) -> list[UUID]:
        """Cosine ANN over a candidate set, scoped to tenant. Returns ranked uuids."""
        if not episode_uuids:
            return []
        try:
            async with self._pool.acquire() as conn:
                rows = await conn.fetch(
                    """
                    SELECT episode_uuid
                      FROM content_embedding
                     WHERE tenant_id = $1
                       AND episode_uuid = ANY($2::uuid[])
                  ORDER BY embedding <=> $3::vector ASC
                     LIMIT $4
                    """,
                    tenant_id,
                    episode_uuids,
                    _vector_literal(query_vector),
                    top_k,
                )
        except asyncpg.PostgresError as exc:
            raise VectorStoreError(f"search_embeddings failed: {exc}") from exc
        return [r["episode_uuid"] for r in rows]


__all__ = ["PgVectorStore"]
