"""src/gnokee/models.py — Pydantic v2 contracts for the gnokee v0.1 surface.

These shapes are the public contract for ingest, recall, and provenance.
External consumers (Omur, personal stacks) develop against them; breaking
a model = breaking the API.

All datetime fields require tz-aware UTC. Naive datetimes are rejected at
the Pydantic boundary as a defence-in-depth check.

exports: class EpisodeIn | class IngestReceipt | class FactStatement | class ContradictionRef | class Excerpt | class SupersessionHint | class RecallResponse | class FactProvenance | class EncryptedBody | Sensitivity
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py | src/gnokee/mcp.py
rules:   pure data + validators only; no I/O; UTC-only datetimes
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

Sensitivity = Literal["public", "private", "clinical"]
"""Per-fact sensitivity tag. Drives retrieval gating; see ``docs/architecture.md``."""

Verdict = Literal["refinement", "update", "contradiction"]
"""Q4 contradiction verdicts that get persisted (`unrelated` is dropped)."""


def _require_utc(value: datetime) -> datetime:
    """Reject naive AND non-UTC tz-aware datetimes at the model boundary.

    Spec §3 invariant: "All gnokee `datetime` values are tz-aware UTC."
    Silent coercion would mask axis-assignment bugs; reject hard.
    """
    if value.tzinfo is None:
        raise ValueError("datetime must be timezone-aware (UTC)")
    if value.utcoffset() != timedelta(0):
        raise ValueError(f"datetime must be UTC; got utcoffset={value.utcoffset()}")
    return value


class EncryptedBody(BaseModel):
    """Pre-encrypted episode body. v0.1 rejects this with NotImplementedYet.

    Reserved for v0.2+ when consumer-supplied DEK + KMS pathways land.
    """

    model_config = ConfigDict(frozen=True)

    ciphertext: bytes
    nonce: bytes
    key_id: str = Field(
        description="References a DEK in the consumer's KMS (e.g. OpenBao for Omur).",
    )


class EpisodeIn(BaseModel):
    """Input shape for `gnokee.ingest_episode(...)` and `gnokee_ingest_episode` MCP tool."""

    model_config = ConfigDict(extra="forbid")

    tenant_id: str = Field(min_length=1)
    content: str | None = Field(default=None)
    encrypted_body: EncryptedBody | None = Field(default=None)
    valid_at: datetime
    valid_until: datetime | None = None
    asserted_at: datetime | None = Field(
        default=None,
        description="When the consumer learned of this fact. Defaults to now(UTC) at the API boundary.",
    )
    our_id: str | None = Field(
        default=None,
        description=(
            "Consumer-supplied stable id, unique per (tenant_id, our_id). When set, re-ingest "
            "with the same key returns the existing episode (replayed=True) and skips Graphiti "
            "extraction, vector write, and contradiction detection."
        ),
    )
    entity_type_hints: list[str] | None = Field(default=None)
    sensitive: Sensitivity = "private"
    language: str | None = Field(
        default=None,
        description="ISO 639-1; auto-detect when null.",
    )
    corrects: UUID | None = Field(
        default=None,
        description=(
            "When set, declares this episode supersedes a prior one. "
            "Same-tenant only; corrected episode must exist in "
            "episode_metadata; new asserted_at must be > "
            "corrected.asserted_at. Closes matching lab_record + "
            "med_record rows from the corrected episode and sets "
            "episode_metadata.asserted_until + superseded_by. "
            "Caller-asserted only — no heuristic detection. Graphiti "
            "edges are NOT auto-superseded; narrative corrections flow "
            "through ADR-0008 contradiction surfacing."
        ),
    )

    @field_validator("valid_at", "valid_until", "asserted_at")
    @classmethod
    def _utc_only(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        return _require_utc(value)

    @field_validator("our_id")
    @classmethod
    def _our_id_non_empty(cls, value: str | None) -> str | None:
        if value is None:
            return None
        if not value.strip():
            raise ValueError("our_id must be a non-empty string when set")
        return value


class ContradictionRef(BaseModel):
    """Pointer to the OTHER side of a contradiction surfaced at ingest or recall."""

    model_config = ConfigDict(frozen=True)

    fact_uuid: UUID
    verdict: Verdict
    summary: str
    valid_at: datetime

    @field_validator("valid_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class FactStatement(BaseModel):
    """A single fact as returned from `gnokee.recall(...)`.

    `text` is a compact natural-language fact statement (Q3-validated shape).
    `fact_uuid` is the lazy provenance handle — call `gnokee_fact_provenance`
    to fetch the full episode body and metadata.
    """

    text: str
    fact_uuid: UUID
    episode_uuid: UUID
    valid_at: datetime
    asserted_at: datetime
    confidence: float | None = None
    contradicts: list[ContradictionRef] = Field(default_factory=list)

    @field_validator("valid_at", "asserted_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class Excerpt(BaseModel):
    """Verbatim ``Episodic.content`` excerpt around a currency / amount line.

    Surfaced on recall when the query references currency or amount-keyword
    tokens and graphiti's edge-fact LLM has summarised the digits away
    from ``FactStatement.text``. Carries the raw line so the agent can
    quote it back to the user. See ``gnokee.excerpts`` for the extractor.
    """

    model_config = ConfigDict(frozen=True)

    episode_uuid: UUID
    text: str = Field(min_length=1)


class SupersessionHint(BaseModel):
    """Issue #19 hint surfacing.

    Emitted by `gnokee.recall(...)` when an episode is cosine-relevant
    AND has been superseded at the caller's `as_of` (so it is correctly
    hidden from the narrative facts/excerpts), but its row-level
    `lab_record` / `med_record` data may still be open. Lets the agent
    discover the gap without surfacing a stale narrative on the hot
    path. Resolution: call `gnokee_lab_query` / `gnokee_med_query` for
    the typed reads, or pin `as_of` pre-correction to read the original
    panel narrative.
    """

    model_config = ConfigDict(frozen=True)

    superseded_uuid: UUID = Field(
        description="Episode that ranked top-K on cosine but was hidden by supersession.",
    )
    current_head_uuid: UUID = Field(
        description=(
            "Chain head of the supersession chain at the caller's `as_of`. "
            "Equal to `superseded_uuid` when the episode was closed without a "
            "named replacement (rare; e.g. a redaction)."
        ),
    )
    superseded_at: datetime = Field(
        description="`asserted_until` of the hidden episode (when the correction landed).",
    )

    @field_validator("superseded_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class RecallResponse(BaseModel):
    """Output of `gnokee.recall(...)`. Q3-validated shape."""

    facts: list[FactStatement] = Field(default_factory=list)
    truncated: bool = False
    candidate_count: int = 0
    excerpts: list[Excerpt] = Field(default_factory=list)
    supersession_hints: list[SupersessionHint] = Field(default_factory=list)


class IngestReceipt(BaseModel):
    """Receipt returned from `gnokee.ingest_episode(...)`."""

    episode_uuid: UUID
    asserted_at: datetime
    created_fact_uuids: list[UUID] = Field(default_factory=list)
    contradicts: list[ContradictionRef] = Field(default_factory=list)
    replayed: bool = Field(
        default=False,
        description=(
            "True iff this call was an idempotent re-ingest matched on (tenant_id, our_id). "
            "When True, no new Graphiti episode was created; created_fact_uuids and contradicts "
            "are empty even if the original ingest produced facts."
        ),
    )

    @field_validator("asserted_at")
    @classmethod
    def _utc_only(cls, value: datetime) -> datetime:
        return _require_utc(value)


class FactProvenance(BaseModel):
    """Output of `gnokee.fact_provenance(...)` — full episode body, lazy fetch."""

    fact_uuid: UUID
    fact_text: str
    episode_uuid: UUID
    episode_content: str
    valid_at: datetime
    valid_until: datetime | None = None
    asserted_at: datetime
    asserted_until: datetime | None = None
    language: str | None = None
    sensitive: Sensitivity

    @field_validator("valid_at", "valid_until", "asserted_at", "asserted_until")
    @classmethod
    def _utc_only(cls, value: datetime | None) -> datetime | None:
        if value is None:
            return None
        return _require_utc(value)
