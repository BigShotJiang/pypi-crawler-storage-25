"""src/gnokee/ingest.py — Episode ingest pipeline (spec §4 stages 1–8).

Stages:
  1 validate    — Pydantic on EpisodeIn; reject encrypted_body; reject naive datetimes
  2 lang detect — langdetect when None
  3 embed       — TEI 1024-dim
  4 graphiti    — add_episode, group_id=tenant_id, reference_time=valid_at
  5 resolve     — asserted_at default = now(UTC) at API boundary
  6 pg writes   — episode_metadata + content_embedding + clinical rows in one txn
  7 contradict  — Q4 pipeline writes fact_contradiction; degraded-tolerant
  8 receipt     — IngestReceipt(episode_uuid, asserted_at, created_fact_uuids, contradicts)

Stage 6 also runs the deterministic clinical parsers (ADR-0009 lab_record,
ADR-0010 med_record) inside the same transaction so retroactive corrections
land atomically with the narrative episode. Parsers are pure / never raise;
empty parse = empty rows = no insert.

Cross-store atomicity:
  step 4 first, step 6 second; on step 6 failure → Graphiti.remove_episode

exports: ingest_episode | IngestPipeline
used_by: src/gnokee/__init__.py | src/gnokee/mcp.py | src/gnokee/demo.py
rules:   tenant_id mandatory; UTC-aware datetimes; idempotency on (tenant_id, episode_uuid)
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0009/0010
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Protocol
from uuid import UUID

import asyncpg
import langdetect
from pydantic import ValidationError as PydanticValidationError

from gnokee.config import utc_now
from gnokee.contradiction import detect_for_facts
from gnokee.embeddings import TEIClient
from gnokee.errors import (
    EmbeddingsUnavailable,
    GnokeeError,
    GraphStoreError,
    NotImplementedYet,
    ValidationError,
    VectorStoreError,
)
from gnokee.extract import augment_for_extraction
from gnokee.extract.clinical import LabRow, MedRow, parse_labs, parse_meds
from gnokee.llm import OpenAIClient
from gnokee.models import ContradictionRef, EpisodeIn, IngestReceipt, Sensitivity
from gnokee.storage.contradictions import ContradictionStore
from gnokee.storage.graph import GraphitiStore
from gnokee.storage.lab import LabRecordRow, LabStore
from gnokee.storage.med import MedRecordRow, MedStore
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore
from gnokee.storage.vector import PgVectorStore

log = logging.getLogger(__name__)


class _ContradictionStageProto(Protocol):
    async def run(
        self,
        *,
        tenant_id: str,
        new_facts: list[tuple[UUID, str, datetime, list[float]]],
        detected_at: datetime,
    ) -> list[ContradictionRef]: ...


@dataclass
class IngestPipeline:
    """Bundles real-store dependencies. One instance per process."""

    pool: asyncpg.Pool
    graph: GraphitiStore
    vector: PgVectorStore
    metadata: MetadataStore
    contradictions: ContradictionStore
    lab: LabStore
    med: MedStore
    embeddings: TEIClient
    llm: OpenAIClient | None = None
    contradiction_enabled: bool = True

    async def ingest(self, episode: EpisodeIn) -> IngestReceipt:
        # Stage 1: validate
        if episode.encrypted_body is not None:
            raise NotImplementedYet("encrypted_body is deferred to v0.2+")
        if episode.content is None:
            raise ValidationError("EpisodeIn.content is required in v0.1 (encrypted_body deferred)")
        content = episode.content

        # Stage 1b: idempotency short-circuit. SELECT before doing any
        # expensive work (embedding, Graphiti extraction). Race-on-INSERT
        # is handled below at Stage 6.
        if episode.our_id is not None:
            existing = await self.metadata.get_by_our_id(
                tenant_id=episode.tenant_id,
                our_id=episode.our_id,
            )
            if existing is not None:
                return IngestReceipt(
                    episode_uuid=existing.episode_uuid,
                    asserted_at=existing.asserted_at,
                    created_fact_uuids=[],
                    contradicts=[],
                    replayed=True,
                )

        # Stage 2: classify language
        language = episode.language
        if language is None:
            try:
                language = langdetect.detect(content)
            except langdetect.LangDetectException:
                language = "en"
        # Spec demands ISO 639-1: 2 chars.
        if len(language) > 2:
            language = language[:2]

        # Stage 3: embed content
        try:
            vector = await self.embeddings.embed_one(content)
        except EmbeddingsUnavailable:
            raise

        # Stage 4: graphiti add_episode
        # Run preprocessor (v0.1.1 issues #2/#3/#4): augmented body lifts
        # numbered identifiers, ranked-list priority, and table currency
        # amounts that vanilla extraction drops. Original `content` is
        # restored on Episodic.content below so provenance stays clean.
        episode_name = _episode_name_from_content(content)
        augmented = augment_for_extraction(content)
        try:
            result = await self.graph.add_episode(
                tenant_id=episode.tenant_id,
                name=episode_name,
                content=augmented,
                reference_time=episode.valid_at,
                source_description="gnokee.ingest",
            )
        except GraphStoreError:
            raise

        if result.episode.uuid is None:
            raise GraphStoreError("Graphiti add_episode returned episode without uuid")
        episode_uuid = UUID(result.episode.uuid)
        created_fact_uuids = [UUID(e.uuid) for e in result.edges if e.uuid is not None]

        # Stage 4b: restore original body on Episodic.content if augmented.
        if augmented != content:
            try:
                await self.graph.overwrite_episode_content(
                    tenant_id=episode.tenant_id,
                    episode_uuid=episode_uuid,
                    content=content,
                )
            except GraphStoreError as exc:
                # Augmentation succeeded; provenance restore failed. Best-effort
                # compensate the whole episode rather than leaving augmented
                # body visible via fact_provenance.
                await _compensate(self.graph, episode_uuid, exc)
                raise

        # Stage 5: resolve defaults
        asserted_at = episode.asserted_at or utc_now()

        row = EpisodeMetadataRow(
            tenant_id=episode.tenant_id,
            episode_uuid=episode_uuid,
            valid_at=episode.valid_at,
            valid_until=episode.valid_until,
            asserted_at=asserted_at,
            asserted_until=None,
            superseded_by=None,
            sensitive=episode.sensitive,
            language=language,
            our_id=episode.our_id,
        )

        # Stage 6: pg writes (single txn). Compensate on failure.
        # `metadata.write` returns False when the row was absorbed by
        # ON CONFLICT — which, given a fresh episode_uuid, can only mean
        # the partial unique on (tenant_id, our_id) tripped (race with a
        # concurrent caller). Treat as idempotent replay.
        race_winner_uuid: UUID | None = None
        race_winner_asserted_at: datetime | None = None
        try:
            async with self.pool.acquire() as conn:
                async with conn.transaction():
                    inserted = await self.metadata.write(conn=conn, row=row)
                    if not inserted:
                        # Race lost: another caller already inserted for our our_id.
                        # Roll back this txn, recover the winner outside.
                        raise _OurIdRaceLost()

                    # v0.2.1: supersede prior episode + matching rows
                    # when `corrects` is set. Runs inside the same txn
                    # as the new-row inserts so a downstream insert
                    # failure rolls the supersession back atomically.
                    # metadata.supersede validates same-tenant + exists
                    # + axis and walks the `superseded_by` chain to the
                    # current head; row-level supersession then targets
                    # the head's UUID, NOT the caller-supplied corrects
                    # (which may be stale).
                    head: EpisodeMetadataRow | None = None
                    if episode.corrects is not None:
                        head = await self.metadata.supersede(
                            conn=conn,
                            tenant_id=episode.tenant_id,
                            corrected_episode_uuid=episode.corrects,
                            new_episode_uuid=episode_uuid,
                            asserted_until=asserted_at,
                        )

                    await self.vector.write_embedding(
                        conn=conn,
                        tenant_id=episode.tenant_id,
                        episode_uuid=episode_uuid,
                        embedding=vector,
                    )
                    lab_rows = _build_lab_rows(
                        parse_labs(content),
                        tenant_id=episode.tenant_id,
                        episode_uuid=episode_uuid,
                        valid_at=episode.valid_at,
                        asserted_at=asserted_at,
                    )
                    if head is not None and lab_rows:
                        updated = await self.lab.supersede_matching(
                            conn=conn,
                            tenant_id=episode.tenant_id,
                            episode_uuid=head.episode_uuid,
                            keys=[(r.analyte, r.valid_at) for r in lab_rows],
                            asserted_until=asserted_at,
                        )
                        if updated < len(lab_rows):
                            log.warning(
                                "lab.supersede_matching: matched %d of %d keys "
                                "(parser drift on valid_at?) tenant=%s "
                                "head=%s new=%s",
                                updated,
                                len(lab_rows),
                                episode.tenant_id,
                                head.episode_uuid,
                                episode_uuid,
                            )
                    if lab_rows:
                        await self.lab.write_rows(conn=conn, rows=lab_rows)
                    med_rows = _build_med_rows(
                        parse_meds(content),
                        tenant_id=episode.tenant_id,
                        episode_uuid=episode_uuid,
                        valid_at=episode.valid_at,
                        asserted_at=asserted_at,
                    )
                    if head is not None and med_rows:
                        updated = await self.med.supersede_matching(
                            conn=conn,
                            tenant_id=episode.tenant_id,
                            episode_uuid=head.episode_uuid,
                            keys=[(r.drug_name, r.event_kind, r.valid_at) for r in med_rows],
                            asserted_until=asserted_at,
                        )
                        if updated < len(med_rows):
                            log.warning(
                                "med.supersede_matching: matched %d of %d keys "
                                "(parser drift on valid_at?) tenant=%s "
                                "head=%s new=%s",
                                updated,
                                len(med_rows),
                                episode.tenant_id,
                                head.episode_uuid,
                                episode_uuid,
                            )
                    if med_rows:
                        await self.med.write_rows(conn=conn, rows=med_rows)
        except _OurIdRaceLost:
            assert episode.our_id is not None  # guarded by Stage 1b path
            winner = await self.metadata.get_by_our_id(
                tenant_id=episode.tenant_id,
                our_id=episode.our_id,
            )
            if winner is None:
                raise VectorStoreError(
                    "race lost on (tenant_id, our_id) but winner row vanished",
                ) from None
            race_winner_uuid = winner.episode_uuid
            race_winner_asserted_at = winner.asserted_at
            # Compensate the orphaned Graphiti episode we created at Stage 4.
            await _compensate(self.graph, episode_uuid, _OurIdRaceLost())
        except VectorStoreError as exc:
            await _compensate(self.graph, episode_uuid, exc)
            raise
        except Exception as exc:  # pragma: no cover
            await _compensate(self.graph, episode_uuid, exc)
            raise VectorStoreError(f"pg writes failed: {exc}") from exc

        if race_winner_uuid is not None and race_winner_asserted_at is not None:
            return IngestReceipt(
                episode_uuid=race_winner_uuid,
                asserted_at=race_winner_asserted_at,
                created_fact_uuids=[],
                contradicts=[],
                replayed=True,
            )

        # Stage 7: contradiction detection (degraded-tolerant).
        contradicts: list[ContradictionRef] = []
        if self.contradiction_enabled and self.llm is not None and result.edges:
            new_facts: list[tuple[UUID, str, datetime, list[float]]] = []
            for edge in result.edges:
                if edge.fact_embedding is None:
                    continue
                edge_valid = edge.valid_at or episode.valid_at
                new_facts.append(
                    (
                        UUID(edge.uuid),
                        edge.fact,
                        edge_valid,
                        list(edge.fact_embedding),
                    )
                )
            if new_facts:
                detection = await detect_for_facts(
                    tenant_id=episode.tenant_id,
                    new_facts=new_facts,
                    store=self.graph,
                    contradictions=self.contradictions,
                    llm=self.llm,
                    detected_at=utc_now(),
                )
                contradicts = detection.contradicts

        # Stage 8: return receipt
        return IngestReceipt(
            episode_uuid=episode_uuid,
            asserted_at=asserted_at,
            created_fact_uuids=created_fact_uuids,
            contradicts=contradicts,
        )


class _OurIdRaceLost(Exception):
    """Internal sentinel: lost the race on the partial unique (tenant_id, our_id) index."""


async def _compensate(graph: GraphitiStore, episode_uuid: UUID, original: Exception) -> None:
    """Best-effort `Graphiti.remove_episode` on partial-failure."""
    try:
        await graph.remove_episode(episode_uuid)
        log.warning("compensated by removing episode %s after failure: %s", episode_uuid, original)
    except GraphStoreError as comp_exc:
        log.error(
            "compensation FAILED for %s; orphan episode in Graphiti. original=%s comp=%s",
            episode_uuid,
            original,
            comp_exc,
        )


def _build_lab_rows(
    parsed: list[LabRow],
    *,
    tenant_id: str,
    episode_uuid: UUID,
    valid_at: datetime,
    asserted_at: datetime,
) -> list[LabRecordRow]:
    return [
        LabRecordRow(
            tenant_id=tenant_id,
            episode_uuid=episode_uuid,
            analyte=p.analyte,
            value_numeric=p.value_numeric,
            value_text=p.value_text,
            unit=p.unit,
            ref_range_low=p.ref_range_low,
            ref_range_high=p.ref_range_high,
            abnormal_flag=p.abnormal_flag,
            valid_at=valid_at,
            asserted_at=asserted_at,
        )
        for p in parsed
    ]


def _build_med_rows(
    parsed: list[MedRow],
    *,
    tenant_id: str,
    episode_uuid: UUID,
    valid_at: datetime,
    asserted_at: datetime,
) -> list[MedRecordRow]:
    return [
        MedRecordRow(
            tenant_id=tenant_id,
            episode_uuid=episode_uuid,
            drug_name=p.drug_name,
            event_kind=p.event_kind,
            valid_at=valid_at,
            asserted_at=asserted_at,
            dose_value=p.dose_value,
            dose_unit=p.dose_unit,
            frequency=p.frequency,
            route=p.route,
            reason=p.reason,
        )
        for p in parsed
    ]


def _episode_name_from_content(content: str, *, limit: int = 80) -> str:
    """Stable name for Graphiti's `name` field (NOT used for retrieval — episode_uuid is)."""
    head = content.strip().splitlines()[0] if content.strip() else "episode"
    if len(head) <= limit:
        return head
    return head[: limit - 1].rstrip() + "…"


# Public API alias kept module-level so external `gnokee.ingest_episode(...)` works.
async def ingest_episode(
    *,
    pipeline: IngestPipeline,
    tenant_id: str,
    content: str | None = None,
    encrypted_body: object | None = None,
    valid_at: datetime,
    valid_until: datetime | None = None,
    asserted_at: datetime | None = None,
    our_id: str | None = None,
    corrects: UUID | None = None,
    entity_type_hints: list[str] | None = None,
    sensitive: Sensitivity = "private",
    language: str | None = None,
) -> IngestReceipt:
    """Public coroutine. Constructs `EpisodeIn` and dispatches to the pipeline."""
    try:
        episode = EpisodeIn(
            tenant_id=tenant_id,
            content=content,
            encrypted_body=encrypted_body,  # type: ignore[arg-type]
            valid_at=valid_at,
            valid_until=valid_until,
            asserted_at=asserted_at,
            our_id=our_id,
            corrects=corrects,
            entity_type_hints=entity_type_hints,
            sensitive=sensitive,
            language=language,
        )
    except PydanticValidationError as exc:
        raise ValidationError(str(exc)) from exc
    try:
        return await pipeline.ingest(episode)
    except GnokeeError:
        raise


__all__ = ["IngestPipeline", "ingest_episode"]
