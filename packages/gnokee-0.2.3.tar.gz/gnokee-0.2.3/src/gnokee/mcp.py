"""src/gnokee/mcp.py — FastMCP server. Tools:

  - gnokee_ingest_episode
  - gnokee_recall
  - gnokee_fact_provenance
  - gnokee_lab_query   (v0.2 / ADR-0009 — typed clinical-lab reads)
  - gnokee_med_query   (v0.2 / ADR-0010 — typed medication-history reads)

Tool descriptions per spec §6 (token-budgeted, fit MCP listing). All
datetime parameters accept ISO-8601 strings (Z or +HH:MM); MCP layer
resolves null → datetime.now(UTC) BEFORE calling the Python API.

exports: build_server | _cli_main
used_by: external MCP clients
rules:   never let `None` flow into storage; tenant_id mandatory; v0.1 unauthenticated
agent:   claude-opus-4-7 | 2026-05-09 | v0.2 ADR-0009
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime
from typing import Annotated, Any, Literal
from uuid import UUID

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from gnokee.bootstrap import App, build_app, shutdown_app
from gnokee.config import Settings, utc_now
from gnokee.errors import GnokeeError, ValidationError
from gnokee.ingest import ingest_episode
from gnokee.lab_query import DEFAULT_HISTORY_LIMIT, lab_query
from gnokee.med_query import DEFAULT_HISTORY_LIMIT as MED_HISTORY_LIMIT
from gnokee.med_query import med_query
from gnokee.retrieval import fact_provenance, recall

log = logging.getLogger(__name__)


def _parse_datetime(value: str | None) -> datetime | None:
    if value is None:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _require_datetime(value: str | None) -> datetime:
    parsed = _parse_datetime(value)
    return parsed if parsed is not None else utc_now()


def build_server(app: App) -> FastMCP:
    server = FastMCP(name="gnokee", instructions="bi-temporal memory infrastructure for personal AI")

    @server.tool(
        name="gnokee_ingest_episode",
        description=(
            "Store a new fact, event, or observation in bi-temporal memory. Call this whenever "
            "the user states something worth remembering, or when an external source delivers a "
            "new fact-bearing payload. `valid_at` = when the fact was true in the world (not the "
            "ingestion time); `asserted_at` = when you learned of it (defaults to now). Pass "
            "`our_id` (a stable consumer-supplied key, e.g. `email:msg-id`) to make ingest "
            "idempotent — re-ingest with the same key returns the existing episode with "
            "`replayed=true` instead of creating a duplicate. Returns the episode UUID, the UUIDs "
            "of any facts created, and any contradictions detected against existing facts; "
            "gnokee never auto-resolves — surface contradictions to the user."
        ),
    )
    async def gnokee_ingest_episode(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        content: Annotated[str, Field(description="Episode body (cleartext).")],
        valid_at: Annotated[
            str,
            Field(description="ISO-8601 UTC. When the fact was true in the world (NOT ingestion time)."),
        ],
        valid_until: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Optional world-time upper bound."),
        ] = None,
        asserted_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. When the consumer learned of it. Defaults to now."),
        ] = None,
        our_id: Annotated[
            str | None,
            Field(
                default=None,
                description=(
                    "Stable consumer-supplied id (e.g. `email:<message-id>`). Same key + tenant = "
                    "idempotent replay; response sets `replayed=true`."
                ),
            ),
        ] = None,
        sensitive: Annotated[
            Literal["public", "private", "clinical"],
            Field(default="private", description="Sensitivity tag. Drives retrieval gating."),
        ] = "private",
        language: Annotated[
            str | None,
            Field(default=None, description="ISO 639-1; auto-detect when null."),
        ] = None,
    ) -> dict[str, Any]:  # tool body
        receipt = await ingest_episode(
            pipeline=app.ingest,
            tenant_id=tenant_id,
            content=content,
            valid_at=_require_datetime(valid_at),
            valid_until=_parse_datetime(valid_until),
            asserted_at=_require_datetime(asserted_at),
            our_id=our_id,
            sensitive=sensitive,
            language=language,
        )
        return {
            "episode_uuid": str(receipt.episode_uuid),
            "asserted_at": receipt.asserted_at.isoformat(),
            "created_fact_uuids": [str(u) for u in receipt.created_fact_uuids],
            "contradicts": [
                {
                    "fact_uuid": str(c.fact_uuid),
                    "verdict": c.verdict,
                    "summary": c.summary,
                    "valid_at": c.valid_at.isoformat(),
                }
                for c in receipt.contradicts
            ],
            "replayed": receipt.replayed,
        }

    @server.tool(
        name="gnokee_recall",
        description=(
            "Retrieve facts from bi-temporal memory. Call this before answering questions about "
            "past user state, prior decisions, or stored knowledge. `valid_at` pins world-time "
            "(default: now); `as_of` pins source-time (default: now). For most queries leave both "
            "unset. Returns natural-language fact statements with provenance handles (UUIDs); fetch "
            "full episode bodies via `gnokee_fact_provenance(fact_uuid)` when a fact is contested or "
            "carries an `update` verdict and you need the original source text. If "
            "`surface_contradictions`, conflicting facts are returned alongside primaries with a "
            "`verdict` (`refinement`/`update`/`contradiction`) and the conflicting fact's "
            "`valid_at` — do not auto-pick a winner. When the query references currency or amount "
            "keywords (`spent`, `cost`, `budget`, `€`, `$`, …), the response also includes an "
            "`excerpts[]` list with verbatim ``Episodic.content`` lines that carry the digits the "
            "fact-extraction step may have summarised away — quote those when answering numeric questions. "
            "When a cosine-relevant episode has been superseded (closed via `corrects:`) at the "
            "caller's `as_of`, it is hidden from `facts[]` and `excerpts[]` and instead surfaced "
            "in `supersession_hints[]` with the chain head — call `gnokee_lab_query` / "
            "`gnokee_med_query` for typed reads against still-open row-level data, or pin `as_of` "
            "pre-correction to recall the original narrative."
        ),
    )
    async def gnokee_recall(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        text: Annotated[str, Field(description="Natural-language query.")],
        as_of: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC source-time pin. Defaults to now."),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC world-time pin. Defaults to now."),
        ] = None,
        surface_contradictions: Annotated[
            bool,
            Field(default=True, description="If true, attach contradicts[] to each FactStatement."),
        ] = True,
        max_tokens: Annotated[
            int,
            Field(default=200, description="Response token budget. Truncates fact list when reached."),
        ] = 200,
        top_k: Annotated[
            int,
            Field(default=10, description="Cosine top-K candidates to consider."),
        ] = 10,
    ) -> dict[str, Any]:  # tool body
        response = await recall(
            pipeline=app.recall,
            tenant_id=tenant_id,
            text=text,
            as_of=_require_datetime(as_of),
            valid_at=_require_datetime(valid_at),
            surface_contradictions=surface_contradictions,
            max_tokens=max_tokens,
            top_k=top_k,
        )
        return {
            "facts": [
                {
                    "text": f.text,
                    "fact_uuid": str(f.fact_uuid),
                    "episode_uuid": str(f.episode_uuid),
                    "valid_at": f.valid_at.isoformat(),
                    "asserted_at": f.asserted_at.isoformat(),
                    "confidence": f.confidence,
                    "contradicts": [
                        {
                            "fact_uuid": str(c.fact_uuid),
                            "verdict": c.verdict,
                            "summary": c.summary,
                            "valid_at": c.valid_at.isoformat(),
                        }
                        for c in f.contradicts
                    ],
                }
                for f in response.facts
            ],
            "truncated": response.truncated,
            "candidate_count": response.candidate_count,
            "excerpts": [
                {
                    "episode_uuid": str(e.episode_uuid),
                    "text": e.text,
                }
                for e in response.excerpts
            ],
            "supersession_hints": [
                {
                    "superseded_uuid": str(h.superseded_uuid),
                    "current_head_uuid": str(h.current_head_uuid),
                    "superseded_at": h.superseded_at.isoformat(),
                }
                for h in response.supersession_hints
            ],
        }

    @server.tool(
        name="gnokee_fact_provenance",
        description=(
            "Fetch the full episode body and metadata behind a `fact_uuid` returned by "
            "`gnokee_recall` or `gnokee_ingest_episode`. Call when a fact is contested, carries an "
            "`update`/`contradiction` verdict, or its source text is needed for the user-facing answer."
        ),
    )
    async def gnokee_fact_provenance(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        fact_uuid: Annotated[str, Field(description="UUID returned in a FactStatement or IngestReceipt.")],
    ) -> dict[str, Any] | None:
        try:
            parsed_uuid = UUID(fact_uuid)
        except ValueError as exc:
            raise ValidationError(f"fact_uuid is not a valid UUID: {fact_uuid!r}") from exc
        prov = await fact_provenance(
            pipeline=app.recall,
            tenant_id=tenant_id,
            fact_uuid=parsed_uuid,
        )
        if prov is None:
            return None
        return {
            "fact_uuid": str(prov.fact_uuid),
            "fact_text": prov.fact_text,
            "episode_uuid": str(prov.episode_uuid),
            "episode_content": prov.episode_content,
            "valid_at": prov.valid_at.isoformat(),
            "valid_until": prov.valid_until.isoformat() if prov.valid_until else None,
            "asserted_at": prov.asserted_at.isoformat(),
            "asserted_until": prov.asserted_until.isoformat() if prov.asserted_until else None,
            "language": prov.language,
            "sensitive": prov.sensitive,
        }

    @server.tool(
        name="gnokee_lab_query",
        description=(
            "Typed clinical-lab read against `lab_record` (ADR-0009). Use when the "
            "user asks for a numeric analyte value, trend, or aggregate that "
            "`gnokee_recall`'s narrative facts strip away (potassium on a date, "
            "min K+ in 2024, history of hemoglobin). `op=latest` returns the most "
            "recent visible row; `op=history` returns rows ascending by `valid_at`; "
            "`op=min`/`max`/`avg`/`count` return a numeric scalar over rows whose "
            "`value_numeric` is non-null; `op=abnormal` returns rows whose "
            "`abnormal_flag` is set (high/low/critical) within the date range — "
            "use this when the question is 'which analytes were abnormal?' rather "
            "than naming an analyte upfront. Both bi-temporal half-pairs apply: "
            "`as_of` pins source-tx-time (default: now — post-correction view); "
            "`valid_at` pins world-time (default: now). `since`/`until` are world-"
            "time bounds on the analyte sample (`valid_at`). `analyte` is required "
            "for every op except `abnormal`, where it is optional and acts as a "
            "narrowing filter when supplied. Returns rows with "
            "value/unit/ref-range/abnormal-flag and the `episode_uuid` provenance "
            "handle — fetch the original panel body via `gnokee_fact_provenance`."
        ),
    )
    async def gnokee_lab_query(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        op: Annotated[
            Literal["latest", "history", "min", "max", "avg", "count", "abnormal"],
            Field(description="latest|history|min|max|avg|count|abnormal."),
        ],
        analyte: Annotated[
            str | None,
            Field(
                default=None,
                description=(
                    'Analyte name, e.g. "Potassium", "Hemoglobin". Required for '
                    "every op except `abnormal` (where it acts as an optional "
                    "narrowing filter)."
                ),
            ),
        ] = None,
        since: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Lower-bound on sample valid_at (inclusive)."),
        ] = None,
        until: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Upper-bound on sample valid_at (exclusive)."),
        ] = None,
        as_of: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC source-time pin. Defaults to now."),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC world-time pin. Defaults to now."),
        ] = None,
        limit: Annotated[
            int,
            Field(default=DEFAULT_HISTORY_LIMIT, description="Row cap for op=history. Ignored for scalar ops."),
        ] = DEFAULT_HISTORY_LIMIT,
    ) -> dict[str, Any]:  # tool body
        response = await lab_query(
            pipeline=app.lab_query,
            tenant_id=tenant_id,
            analyte=analyte,
            op=op,
            since=_parse_datetime(since),
            until=_parse_datetime(until),
            as_of=_require_datetime(as_of),
            valid_at=_require_datetime(valid_at),
            limit=limit,
        )
        return {
            "op": response.op,
            "rows": [
                {
                    "episode_uuid": str(r.episode_uuid),
                    "analyte": r.analyte,
                    "value_numeric": str(r.value_numeric) if r.value_numeric is not None else None,
                    "value_text": r.value_text,
                    "unit": r.unit,
                    "ref_range_low": str(r.ref_range_low) if r.ref_range_low is not None else None,
                    "ref_range_high": str(r.ref_range_high) if r.ref_range_high is not None else None,
                    "abnormal_flag": r.abnormal_flag,
                    "valid_at": r.valid_at.isoformat(),
                    "asserted_at": r.asserted_at.isoformat(),
                }
                for r in response.rows
            ],
            "scalar": str(response.scalar) if response.scalar is not None else None,
            "count": response.count,
        }

    @server.tool(
        name="gnokee_med_query",
        description=(
            "Typed medication-history read against `med_record` (ADR-0010). Use "
            "when the user asks for current meds, dose history, allergy list, or "
            "ACE→ARB-style switches that `gnokee_recall`'s narrative facts may "
            "preserve drug names for but strip dates and dose numerals from. "
            "`op=active` returns one row per drug whose latest visible event is "
            "not a stop/allergy (defaults to current state — pass `valid_at` to "
            "pin a different world-time, e.g. 'meds active on 2024-07-01'); "
            "`op=history` returns all events for `drug_name` ascending by "
            "`valid_at`, optionally bounded by `since`/`until`; `op=allergies` "
            "returns all allergy rows for the tenant; `op=switches` returns "
            "drug-switch events. Both bi-temporal half-pairs apply: `as_of` pins "
            "source-tx-time (default: now); `valid_at` pins world-time (default: "
            "now). Each row carries the `episode_uuid` provenance handle — fetch "
            "the original prose via `gnokee_fact_provenance`."
        ),
    )
    async def gnokee_med_query(
        tenant_id: Annotated[str, Field(description="Memory partition. Mandatory.")],
        op: Annotated[
            Literal["active", "history", "allergies", "switches"],
            Field(description="active|history|allergies|switches."),
        ],
        drug_name: Annotated[
            str | None,
            Field(default=None, description="Drug name. Required for op=history; optional filter for op=active."),
        ] = None,
        since: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Lower-bound on event valid_at (inclusive)."),
        ] = None,
        until: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC. Upper-bound on event valid_at (exclusive)."),
        ] = None,
        as_of: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC source-time pin. Defaults to now."),
        ] = None,
        valid_at: Annotated[
            str | None,
            Field(default=None, description="ISO-8601 UTC world-time pin. Defaults to now."),
        ] = None,
        limit: Annotated[
            int,
            Field(default=MED_HISTORY_LIMIT, description="Row cap. Ignored for op=active (one per drug)."),
        ] = MED_HISTORY_LIMIT,
    ) -> dict[str, Any]:  # tool body
        response = await med_query(
            pipeline=app.med_query,
            tenant_id=tenant_id,
            op=op,
            drug_name=drug_name,
            since=_parse_datetime(since),
            until=_parse_datetime(until),
            as_of=_require_datetime(as_of),
            valid_at=_require_datetime(valid_at),
            limit=limit,
        )
        return {
            "op": response.op,
            "rows": [
                {
                    "episode_uuid": str(r.episode_uuid),
                    "drug_name": r.drug_name,
                    "drug_class": r.drug_class,
                    "dose_value": str(r.dose_value) if r.dose_value is not None else None,
                    "dose_unit": r.dose_unit,
                    "frequency": r.frequency,
                    "route": r.route,
                    "event_kind": r.event_kind,
                    "reason": r.reason,
                    "valid_at": r.valid_at.isoformat(),
                    "asserted_at": r.asserted_at.isoformat(),
                }
                for r in response.rows
            ],
            "count": response.count,
        }

    return server


async def _async_main() -> None:
    settings = Settings()
    app = await build_app(settings)
    server = build_server(app)
    transport: Literal["stdio", "streamable-http"] = "streamable-http" if settings.mcp_http else "stdio"
    try:
        if transport == "streamable-http":
            await server.run_streamable_http_async()
        else:
            await server.run_stdio_async()
    finally:
        await shutdown_app(app)


def _cli_main() -> None:
    from gnokee.logging import configure as configure_logging

    configure_logging(os.environ.get("GNOKEE_LOG_LEVEL", "info"))
    try:
        asyncio.run(_async_main())
    except (GnokeeError, KeyboardInterrupt) as exc:
        log.error("gnokee mcp exit: %s", exc)


__all__ = ["_cli_main", "build_server"]


if __name__ == "__main__":
    _cli_main()
