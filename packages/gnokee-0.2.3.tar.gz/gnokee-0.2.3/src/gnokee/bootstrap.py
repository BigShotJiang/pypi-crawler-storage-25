"""src/gnokee/bootstrap.py — Wire Settings → Graphiti, asyncpg pool, pipelines.

Single construction site for the v0.1 process. MCP server, demo script,
and integration tests all call `build_app(settings)` to get a ready
`App` with shared connection state.

exports: class App | build_app | shutdown_app
used_by: src/gnokee/mcp.py | src/gnokee/demo.py | tests/integration/*
rules:   one Graphiti per process; pool size is conservative (4); TEI = embed only
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import asyncpg
from graphiti_core import Graphiti
from graphiti_core.cross_encoder.openai_reranker_client import OpenAIRerankerClient
from graphiti_core.embedder.client import EmbedderClient, EmbedderConfig
from graphiti_core.llm_client.config import LLMConfig
from graphiti_core.llm_client.openai_client import OpenAIClient as GraphitiOpenAIClient
from openai import AsyncOpenAI

from gnokee.config import Settings
from gnokee.embeddings import EMBED_DIM, TEIClient
from gnokee.errors import EmbeddingsUnavailable, ValidationError
from gnokee.ingest import IngestPipeline
from gnokee.lab_query import LabQueryPipeline
from gnokee.llm import OpenAIClient
from gnokee.med_query import MedQueryPipeline
from gnokee.retrieval import RecallPipeline
from gnokee.storage.contradictions import ContradictionStore
from gnokee.storage.graph import GraphitiStore
from gnokee.storage.lab import LabStore
from gnokee.storage.med import MedStore
from gnokee.storage.metadata import MetadataStore
from gnokee.storage.vector import PgVectorStore

log = logging.getLogger(__name__)


class TEIEmbedder(EmbedderClient):
    """Adapter so Graphiti's embedder interface uses our TEI client."""

    def __init__(self, tei: TEIClient) -> None:
        self._tei = tei
        self.config = EmbedderConfig(embedding_dim=EMBED_DIM)

    async def create(  # type: ignore[override]
        self,
        input_data: str | list[str],
    ) -> list[float]:
        """Per Graphiti's `EmbedderClient.create` contract: returns a single vector.

        Reject multi-element list inputs loudly — silent truncation would drop
        embeddings for entity names beyond the first one. Batch callers must
        use `create_batch`.
        """
        if isinstance(input_data, str):
            return await self._tei.embed_one(input_data)
        if isinstance(input_data, list):
            if not input_data:
                return []
            if not isinstance(input_data[0], str):
                raise EmbeddingsUnavailable("TEIEmbedder.create only supports str / list[str]")
            if len(input_data) > 1:
                raise EmbeddingsUnavailable(
                    f"TEIEmbedder.create received list of {len(input_data)}; use create_batch for multi-text",
                )
            return await self._tei.embed_one(input_data[0])
        raise EmbeddingsUnavailable("TEIEmbedder.create only supports str / list[str]")

    async def create_batch(self, input_data_list: list[str]) -> list[list[float]]:
        if not input_data_list:
            return []
        return await self._tei.embed(input_data_list)


@dataclass
class App:
    settings: Settings
    pool: asyncpg.Pool
    graphiti: Graphiti
    graph_store: GraphitiStore
    vector_store: PgVectorStore
    metadata_store: MetadataStore
    contradiction_store: ContradictionStore
    lab_store: LabStore
    med_store: MedStore
    tei: TEIClient
    llm: OpenAIClient | None
    ingest: IngestPipeline = field(init=False)
    recall: RecallPipeline = field(init=False)
    lab_query: LabQueryPipeline = field(init=False)
    med_query: MedQueryPipeline = field(init=False)

    def __post_init__(self) -> None:
        self.ingest = IngestPipeline(
            pool=self.pool,
            graph=self.graph_store,
            vector=self.vector_store,
            metadata=self.metadata_store,
            contradictions=self.contradiction_store,
            lab=self.lab_store,
            med=self.med_store,
            embeddings=self.tei,
            llm=self.llm,
            contradiction_enabled=self.llm is not None,
        )
        self.recall = RecallPipeline(
            graph=self.graph_store,
            vector=self.vector_store,
            metadata=self.metadata_store,
            contradictions=self.contradiction_store,
            embeddings=self.tei,
        )
        self.lab_query = LabQueryPipeline(lab=self.lab_store)
        self.med_query = MedQueryPipeline(med=self.med_store)


def _require_llm_credentials(settings: Settings) -> None:
    """Refuse to boot when api.openai.com is the target with no API key.

    The default ``openai_base_url`` is ``api.openai.com/v1``. Without a key
    the ``or "unused"`` fallback below would silently construct an
    ``AsyncOpenAI`` that 401s on every graphiti extraction call mid-ingest.
    Self-hosted shapes (litellm / ollama / vllm) keep working because they
    point ``base_url`` somewhere else.
    """
    base = settings.openai_base_url.rstrip("/").lower()
    targets_openai_cloud = base.endswith("api.openai.com/v1") or base.endswith("api.openai.com")
    if targets_openai_cloud and not settings.openai_api_key:
        raise ValidationError(
            "GNOKEE_OPENAI_API_KEY is empty but GNOKEE_OPENAI_BASE_URL targets "
            "api.openai.com. Set the key or point base_url at a self-hosted "
            "endpoint (litellm / ollama / vllm OpenAI-compat)."
        )


async def build_app(settings: Settings, *, bootstrap_indices: bool = True) -> App:
    """Construct shared connections + pipelines."""
    assert settings.pg_dsn is not None  # resolved by Settings.model_validator
    assert settings.embed_base_url is not None
    _require_llm_credentials(settings)
    pool = await asyncpg.create_pool(
        settings.pg_dsn,
        min_size=1,
        max_size=4,
    )
    if pool is None:  # pragma: no cover
        raise RuntimeError("asyncpg.create_pool returned None")

    tei = TEIClient(
        settings.embed_base_url,
        model=settings.embed_model,
        api_key=settings.embed_api_key,
    )
    embedder = TEIEmbedder(tei)
    llm_config = LLMConfig(
        api_key=settings.openai_api_key or "unused",
        base_url=settings.openai_base_url,
        model=settings.llm_model,
        temperature=0,
    )
    openai_async = AsyncOpenAI(
        base_url=settings.openai_base_url,
        api_key=settings.openai_api_key or "unused",
    )
    graphiti_llm = GraphitiOpenAIClient(config=llm_config, client=openai_async)
    graphiti_reranker = OpenAIRerankerClient(config=llm_config, client=openai_async)

    graphiti = Graphiti(
        uri=settings.neo4j_uri,
        user=settings.neo4j_user,
        password=settings.neo4j_password,
        embedder=embedder,
        llm_client=graphiti_llm,
        cross_encoder=graphiti_reranker,
    )
    graph_store = GraphitiStore(graphiti)
    if bootstrap_indices:
        await graph_store.bootstrap_indices()

    vector_store = PgVectorStore(pool)
    metadata_store = MetadataStore(pool)
    contradiction_store = ContradictionStore(pool)
    lab_store = LabStore(pool)
    med_store = MedStore(pool)

    llm: OpenAIClient | None = None
    if settings.openai_api_key:
        llm = OpenAIClient(
            base_url=settings.openai_base_url,
            api_key=settings.openai_api_key,
            model=settings.llm_model,
        )

    return App(
        settings=settings,
        pool=pool,
        graphiti=graphiti,
        graph_store=graph_store,
        vector_store=vector_store,
        metadata_store=metadata_store,
        contradiction_store=contradiction_store,
        lab_store=lab_store,
        med_store=med_store,
        tei=tei,
        llm=llm,
    )


async def shutdown_app(app: App) -> None:
    try:
        await app.graphiti.close()  # type: ignore[no-untyped-call]
    except Exception:  # pragma: no cover
        log.exception("graphiti close failed")
    try:
        await app.pool.close()
    except Exception:  # pragma: no cover
        log.exception("pool close failed")


__all__ = ["App", "TEIEmbedder", "build_app", "shutdown_app"]
