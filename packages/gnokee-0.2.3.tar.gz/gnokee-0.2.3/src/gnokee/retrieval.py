"""src/gnokee/retrieval.py — Recall pipeline (spec §5 stages 1–6).

Stages:
  1 embed query                — TEI 1024-dim
  2a Cypher narrow (Neo4j)     — ep.valid_at <= valid_at; ORDER BY ep.uuid; LIMIT pool
  2b pg join                   — episode_metadata bi-temporal half-pairs (asserted + valid_until)
  3 pgvector rerank            — cosine over content_embedding within survivors
  4 fact fetch (Cypher batch)  — MENTIONS → RELATES_TO undirected; r.invalid_at half-pair
  5 contradictions             — symmetric UNION over fact_contradiction; valid_at backfill
  6 shape response             — Q3-validated FactStatement list; max_tokens budget

`gnokee_fact_provenance` lives here too — full episode body fetch.

exports: recall | fact_provenance | RecallPipeline
used_by: src/gnokee/__init__.py | src/gnokee/mcp.py | src/gnokee/demo.py
rules:   tenant_id on every read; both bi-temporal half-pairs mandatory; lazy provenance
agent:   claude-opus-4-7 | 2026-05-08 | v0.1 spec
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from uuid import UUID

from gnokee.config import utc_now
from gnokee.embeddings import TEIClient
from gnokee.errors import GnokeeError, ValidationError
from gnokee.excerpts import find_currency_excerpt, find_med_excerpt, query_wants_excerpt
from gnokee.models import (
    ContradictionRef,
    Excerpt,
    FactProvenance,
    FactStatement,
    RecallResponse,
    SupersessionHint,
)
from gnokee.storage.contradictions import ContradictionStore
from gnokee.storage.graph import GraphitiStore
from gnokee.storage.metadata import EpisodeMetadataRow, MetadataStore
from gnokee.storage.vector import PgVectorStore

log = logging.getLogger(__name__)

DEFAULT_CANDIDATE_POOL = 200
DEFAULT_TOP_K = 10
DEFAULT_MAX_TOKENS = 200
DEFAULT_EXCERPT_CHARS = 200
DEFAULT_EXCERPT_MAX_COUNT = 3
DEFAULT_SUPERSESSION_HINT_CAP = 5
_DATE_PREFIX_LEN = len("[YYYY-MM-DD] ")

# Temporal-current intent markers — when present, reorder the cosine
# top-K by ``valid_at`` desc so "what am I currently on" picks the most
# recent semantically-near episode rather than the highest cosine match.
# English-only for now; non-EN handled by v0.2 typed reads (ADR-0010).
_RECENCY_QUERY_PATTERN = re.compile(
    r"\b(currently|now|today|recently|latest|current|active|"
    r"these days|right now|at the moment|am i on|am i taking)\b",
    re.IGNORECASE,
)


@dataclass
class RecallPipeline:
    graph: GraphitiStore
    vector: PgVectorStore
    metadata: MetadataStore
    contradictions: ContradictionStore
    embeddings: TEIClient

    async def recall(
        self,
        *,
        tenant_id: str,
        text: str,
        as_of: datetime | None = None,
        valid_at: datetime | None = None,
        surface_contradictions: bool = True,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        top_k: int = DEFAULT_TOP_K,
    ) -> RecallResponse:
        if not tenant_id:
            raise ValidationError("tenant_id required")
        as_of_eff = _ensure_utc(as_of) or utc_now()
        valid_eff = _ensure_utc(valid_at) or utc_now()

        # Stage 1: embed
        q_vec = await self.embeddings.embed_one(text)

        # Stage 2a: Neo4j candidate narrow
        candidates = await self.graph.list_candidate_episodes(
            tenant_id=tenant_id,
            valid_at=valid_eff,
            candidate_pool=DEFAULT_CANDIDATE_POOL,
        )
        candidate_count = len(candidates)
        if not candidates:
            return RecallResponse(facts=[], truncated=False, candidate_count=0)

        # Stage 2b: pg bi-temporal join
        candidate_uuids = [c.episode_uuid for c in candidates]
        survivors = await self.metadata.filter_visible(
            tenant_id=tenant_id,
            candidate_uuids=candidate_uuids,
            as_of=as_of_eff,
            valid_at=valid_eff,
        )

        # Stage 3: pgvector rerank — cosine over the FULL candidate set
        # (visible + closed) so we can detect closed-but-relevant
        # episodes for issue #19 supersession-hint surfacing. Stage 3.5
        # below partitions the result; the visible-only path is
        # otherwise unchanged.
        ranked_all = await self.vector.search_embeddings(
            tenant_id=tenant_id,
            episode_uuids=candidate_uuids,
            query_vector=q_vec,
            top_k=top_k,
        )
        if not ranked_all:
            return RecallResponse(facts=[], truncated=False, candidate_count=candidate_count)

        # Stage 3.5: partition into visible (→ facts) + closed (→ hints).
        # Visible-only set is what the rest of the pipeline sees.
        visible_set = set(survivors)
        ranked = [u for u in ranked_all if u in visible_set]
        hidden_top_k = [u for u in ranked_all if u not in visible_set]

        supersession_hints: list[SupersessionHint] = []
        for hidden_uuid in hidden_top_k[:DEFAULT_SUPERSESSION_HINT_CAP]:
            head = await self.metadata.chain_head_at(
                tenant_id=tenant_id,
                start_uuid=hidden_uuid,
                as_of=as_of_eff,
            )
            superseded_meta = await self.metadata.get(
                tenant_id=tenant_id,
                episode_uuid=hidden_uuid,
            )
            if superseded_meta is None or superseded_meta.asserted_until is None:
                # Episode disappeared mid-recall (rare) or never had a
                # supersession close — skip rather than emit a malformed hint.
                continue
            head_uuid = head.episode_uuid if head is not None else hidden_uuid
            supersession_hints.append(
                SupersessionHint(
                    superseded_uuid=hidden_uuid,
                    current_head_uuid=head_uuid,
                    superseded_at=superseded_meta.asserted_until,
                )
            )

        if not ranked:
            return RecallResponse(
                facts=[],
                truncated=False,
                candidate_count=candidate_count,
                supersession_hints=supersession_hints,
            )

        # Stage 3b — fetch metadata per ranked episode. Done before stage 4
        # so the optional recency re-sort below has valid_at on hand;
        # FactStatement.asserted_at and the excerpt date-prefix both also
        # read from this map.
        metadata_lookup: dict[UUID, EpisodeMetadataRow] = {}
        for ep_uuid in ranked:
            row = await self.metadata.get(tenant_id=tenant_id, episode_uuid=ep_uuid)
            if row is not None:
                metadata_lookup[ep_uuid] = row

        # Stage 3c — optional recency rerank for "currently / now / what am
        # I on" queries. Sort the cosine top-K by ``valid_at`` desc so the
        # most recent semantically-near episode wins. Cosine has already
        # narrowed the candidate set; recency picks among the survivors.
        if _query_wants_recency(text):
            ranked = _sort_by_recency(ranked, metadata_lookup)

        # Stage 4: fact fetch (single Cypher)
        fact_rows = await self.graph.fetch_facts_for_episodes(
            tenant_id=tenant_id,
            episode_uuids=ranked,
            valid_at=valid_eff,
        )
        if not fact_rows:
            return RecallResponse(
                facts=[],
                truncated=False,
                candidate_count=candidate_count,
                supersession_hints=supersession_hints,
            )

        # Reorder by ranked-episode order (cosine, or recency-reranked).
        rank_index = {u: i for i, u in enumerate(ranked)}
        fact_rows.sort(key=lambda r: rank_index.get(r.episode_uuid, 1_000_000))

        # Stage 5: contradictions (optional)
        contradiction_map: dict[UUID, list[ContradictionRef]] = {}
        if surface_contradictions:
            counterparts = await self.contradictions.lookup_counterparts(
                tenant_id=tenant_id,
                fact_uuids=[r.fact_uuid for r in fact_rows],
            )
            counterpart_uuids = {c.fact_uuid for cs in counterparts.values() for c in cs}
            valid_at_lookup = await self.graph.fact_valid_at_lookup(
                tenant_id=tenant_id,
                fact_uuids=list(counterpart_uuids),
            )
            for src, cs in counterparts.items():
                refs: list[ContradictionRef] = []
                for c in cs:
                    refs.append(
                        ContradictionRef(
                            fact_uuid=c.fact_uuid,
                            verdict=c.verdict,
                            summary=c.summary,
                            valid_at=valid_at_lookup.get(c.fact_uuid, valid_eff),
                        )
                    )
                contradiction_map[src] = refs

        # Stage 6: shape response under max_tokens budget
        # Excerpts only fire when the query carries an explicit signal
        # (currency / amount / med-keyword / dose-unit). Non-signal queries
        # get the full max_tokens for facts — universal top-1 was tried and
        # regressed real-corpus noggin tests (license / name-history) by
        # crowding the fact list. Q8 drug-name-only date queries lose the
        # date prefix as a result; v0.2 typed med_record (ADR-0010) handles
        # those with a typed read instead.
        wants_excerpt = query_wants_excerpt(text)
        excerpt_budget = max_tokens // 3 if wants_excerpt else 0
        fact_budget = max_tokens - excerpt_budget

        facts: list[FactStatement] = []
        truncated = False
        running_tokens = 0
        for r in fact_rows:
            meta = metadata_lookup.get(r.episode_uuid)
            asserted = meta.asserted_at if meta is not None else None
            if asserted is None:
                # An episode that survived stage 2b must have a metadata row.
                # Skip rather than silently substitute as_of_eff (would conflate
                # query tx-time with the source's asserted_at).
                log.warning(
                    "fact %s skipped: episode %s passed filter_visible but no metadata row",
                    r.fact_uuid,
                    r.episode_uuid,
                )
                continue
            stmt = FactStatement(
                text=r.text,
                fact_uuid=r.fact_uuid,
                episode_uuid=r.episode_uuid,
                valid_at=r.valid_at,
                asserted_at=asserted,
                contradicts=contradiction_map.get(r.fact_uuid, []),
            )
            estimated = _approx_tokens(stmt.text)
            if running_tokens + estimated > fact_budget and facts:
                truncated = True
                break
            running_tokens += estimated
            facts.append(stmt)

        # Stage 6b: verbatim body excerpts (gnokee #7 + ADR-0010 cheap path).
        # When the query mentions an amount or a med-history token,
        # ``FactStatement.text`` (LLM-summarised) often drops the digits
        # / drug names / dates. Pull verbatim lines from the surviving
        # episodes' ``Episodic.content`` so the agent can quote them.
        # Excerpts get their own slice of ``max_tokens`` so the fact list
        # cannot crowd them out. Currency hit wins over med-event hit on
        # the same line; either-or per episode. Each excerpt is prefixed
        # with ``[YYYY-MM-DD]`` from the episode ``valid_at`` so date-
        # asking variants ("when was the renovation invoice?") can quote
        # the date the body says "today" about.
        excerpts: list[Excerpt] = []
        if wants_excerpt and ranked:
            episode_contents = await self.graph.fetch_episode_contents(
                tenant_id=tenant_id,
                episode_uuids=ranked[:DEFAULT_EXCERPT_MAX_COUNT],
            )
            excerpt_running = 0
            for ep_uuid in ranked[:DEFAULT_EXCERPT_MAX_COUNT]:
                content_body = episode_contents.get(ep_uuid)
                if not content_body:
                    continue
                meta = metadata_lookup.get(ep_uuid)
                valid_at_for_ep = meta.valid_at if meta is not None else None
                inner_max = (
                    max(0, DEFAULT_EXCERPT_CHARS - _DATE_PREFIX_LEN) if valid_at_for_ep else DEFAULT_EXCERPT_CHARS
                )
                excerpt_text = find_currency_excerpt(content_body, max_chars=inner_max)
                if not excerpt_text:
                    excerpt_text = find_med_excerpt(content_body, max_chars=inner_max)
                if not excerpt_text:
                    continue
                excerpt_text = _format_excerpt_with_date(excerpt_text, valid_at_for_ep)
                cost = _approx_tokens(excerpt_text)
                # Always emit at least one excerpt when found; cap subsequent
                # ones at the reserved excerpt budget.
                if excerpts and excerpt_running + cost > excerpt_budget:
                    truncated = True
                    break
                excerpt_running += cost
                excerpts.append(Excerpt(episode_uuid=ep_uuid, text=excerpt_text))
            running_tokens += excerpt_running

        return RecallResponse(
            facts=facts,
            truncated=truncated,
            candidate_count=candidate_count,
            excerpts=excerpts,
            supersession_hints=supersession_hints,
        )

    async def fact_provenance(
        self,
        *,
        tenant_id: str,
        fact_uuid: UUID,
    ) -> FactProvenance | None:
        prov = await self.graph.fetch_provenance(tenant_id=tenant_id, fact_uuid=fact_uuid)
        if prov is None:
            return None
        meta = await self.metadata.get(tenant_id=tenant_id, episode_uuid=prov.episode_uuid)
        if meta is None:
            return None
        return FactProvenance(
            fact_uuid=prov.fact_uuid,
            fact_text=prov.fact_text,
            episode_uuid=prov.episode_uuid,
            episode_content=prov.episode_content,
            valid_at=meta.valid_at,
            valid_until=meta.valid_until,
            asserted_at=meta.asserted_at,
            asserted_until=meta.asserted_until,
            language=meta.language,
            sensitive=meta.sensitive,
        )


def _approx_tokens(text: str) -> int:
    """Rough token estimate. ~4 chars/token English; conservative."""
    return max(1, len(text) // 4)


def _query_wants_recency(query: str) -> bool:
    """True when the query asks about the current / latest state.

    Triggers a stage-3c recency rerank so the cosine top-K is sorted by
    ``valid_at`` desc, pushing the most recent semantically-near episode
    to the front. English markers only for now — non-EN time-pin
    reads land in v0.2 typed `med_record` (ADR-0010) and `lab_record`
    (ADR-0009).
    """
    if not query:
        return False
    return bool(_RECENCY_QUERY_PATTERN.search(query))


def _sort_by_recency(
    ranked: list[UUID],
    metadata_lookup: dict[UUID, EpisodeMetadataRow],
) -> list[UUID]:
    """Sort ``ranked`` by episode ``valid_at`` desc; episodes without
    metadata go last (preserved relative cosine order at the tail).
    """
    sentinel_min = datetime.min.replace(tzinfo=timezone.utc)

    def key(u: UUID) -> datetime:
        meta = metadata_lookup.get(u)
        return meta.valid_at if meta is not None else sentinel_min

    return sorted(ranked, key=key, reverse=True)


def _format_excerpt_with_date(text: str, valid_at: datetime | None) -> str:
    """Prepend ``[YYYY-MM-DD]`` from episode ``valid_at`` to an excerpt.

    Date queries ("when did I start X?") fail when the body says "today"
    — the date lives only in the bi-temporal ``valid_at`` column. The
    prefix surfaces it on the verbatim recall response so an agent can
    quote "[2024-02-01]" alongside "Started Lisinopril 10 mg ...".

    No-op when ``valid_at`` is ``None`` (e.g. pre-migration episode).
    """
    if valid_at is None:
        return text
    return f"[{valid_at.date().isoformat()}] {text}"


def _ensure_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        raise ValidationError("recall datetimes must be tz-aware UTC")
    return value


# Public coroutine wrappers — `pipeline` is the construction site.
async def recall(
    *,
    pipeline: RecallPipeline,
    tenant_id: str,
    text: str,
    as_of: datetime | None = None,
    valid_at: datetime | None = None,
    surface_contradictions: bool = True,
    max_tokens: int = DEFAULT_MAX_TOKENS,
    top_k: int = DEFAULT_TOP_K,
) -> RecallResponse:
    try:
        return await pipeline.recall(
            tenant_id=tenant_id,
            text=text,
            as_of=as_of,
            valid_at=valid_at,
            surface_contradictions=surface_contradictions,
            max_tokens=max_tokens,
            top_k=top_k,
        )
    except GnokeeError:
        raise


async def fact_provenance(
    *,
    pipeline: RecallPipeline,
    tenant_id: str,
    fact_uuid: UUID,
) -> FactProvenance | None:
    return await pipeline.fact_provenance(tenant_id=tenant_id, fact_uuid=fact_uuid)


fact_provenance.__module__ = __name__
recall.__module__ = __name__


__all__ = ["RecallPipeline", "fact_provenance", "recall"]
