"""src/gnokee/errors.py — Typed exception hierarchy.

exports: class GnokeeError | class ValidationError | class EmbeddingsUnavailable | class GraphStoreError | class VectorStoreError | class LLMUnavailable | class NotImplementedYet | class CorrectsError | class EpisodeNotFoundError | class CorrectsCrossTenantError | class CorrectsAxisInversionError | class CorrectsChainError
used_by: src/gnokee/ingest.py | src/gnokee/retrieval.py | src/gnokee/storage/* | src/gnokee/embeddings.py | src/gnokee/llm.py | src/gnokee/contradiction.py | src/gnokee/mcp.py
rules:   raise typed; never bare Exception in src/gnokee
agent:   claude-opus-4-7 | 2026-05-09 | v0.2.1 ADR-0009/0010 corrects: signal
"""

from __future__ import annotations

from uuid import UUID


class GnokeeError(Exception):
    """Base class for all gnokee-raised exceptions."""


class ValidationError(GnokeeError):
    """Bad input (e.g. naive datetime, missing tenant_id)."""


class EmbeddingsUnavailable(GnokeeError):
    """TEI / embedding endpoint is unreachable or returning errors."""


class GraphStoreError(GnokeeError):
    """Graphiti / Neo4j fault during read or write."""


class VectorStoreError(GnokeeError):
    """Postgres / pgvector fault during read or write."""


class LLMUnavailable(GnokeeError):
    """OpenAI-compatible LLM endpoint is unreachable; ingest may degrade."""


class NotImplementedYet(GnokeeError):
    """Feature is on the v0.2+ roadmap; not yet wired in v0.1."""


class CorrectsError(VectorStoreError):
    """Base for ``EpisodeIn.corrects:`` validation failures (Stage 6 txn-scope).

    Subclasses derive from ``VectorStoreError`` so the existing
    ``IngestPipeline.ingest`` compensate path catches them and rolls
    back the Graphiti episode created at Stage 4.
    """


class EpisodeNotFoundError(CorrectsError):
    """Raised when ``corrects`` targets an episode_uuid not in episode_metadata."""

    def __init__(self, episode_uuid: UUID) -> None:
        super().__init__(f"corrects: episode {episode_uuid} not found")
        self.episode_uuid = episode_uuid


class CorrectsCrossTenantError(CorrectsError):
    """Raised when ``corrects`` targets a different tenant_id."""


class CorrectsAxisInversionError(CorrectsError):
    """Raised when new asserted_at <= corrected.asserted_at.

    Bi-temporal axis integrity: a correction is always learned-later
    in tx-time than the row it corrects.
    """


class CorrectsChainError(CorrectsError):
    """Raised when ``superseded_by`` walk exceeds bounded depth.

    Distinct from ``CorrectsAxisInversionError`` — cycle / runaway
    chain is a structural invariant, not a tx-time inversion. Callers
    and log parsers must be able to tell them apart.
    """
