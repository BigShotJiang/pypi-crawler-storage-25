"""MACD Momentum Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_macd
from ..types import SignalAction


class MACDStrategy(Strategy):
    """MACD Momentum Strategy.
    
    Buy when MACD line crosses above signal line.
    Sell when MACD line crosses below signal line.
    """
    
    name = "macd"
    default_params = {
        'fast': 12,
        'slow': 26,
        'signal': 9,
    }
    
    def init(self, df: pd.DataFrame) -> None:
        """Calculate MACD."""
        fast = self.params['fast']
        slow = self.params['slow']
        signal = self.params['signal']
        
        self._macd_line, self._signal_line, self._histogram = calculate_macd(
            df, fast=fast, slow=slow, signal=signal
        )
        
        self._indicators = {
            'macd': round(self._macd_line.iloc[-1], 4) if not pd.isna(self._macd_line.iloc[-1]) else None,
            'signal': round(self._signal_line.iloc[-1], 4) if not pd.isna(self._signal_line.iloc[-1]) else None,
            'histogram': round(self._histogram.iloc[-1], 4) if not pd.isna(self._histogram.iloc[-1]) else None,
        }
    
    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on MACD crossover."""
        if len(self._macd_line) < 2 or len(self._signal_line) < 2:
            return 'HOLD'
        
        # Current values
        macd_current = self._macd_line.iloc[-1]
        signal_current = self._signal_line.iloc[-1]
        
        # Previous values
        macd_prev = self._macd_line.iloc[-2]
        signal_prev = self._signal_line.iloc[-2]
        
        # Check for valid values
        if pd.isna(macd_current) or pd.isna(signal_current) or pd.isna(macd_prev) or pd.isna(signal_prev):
            return 'HOLD'
        
        # Buy: MACD crosses above signal line
        if macd_prev <= signal_prev and macd_current > signal_current:
            return 'BUY'
        
        # Sell: MACD crosses below signal line
        if macd_prev >= signal_prev and macd_current < signal_current:
            return 'SELL'
        
        return 'HOLD'
    
    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on histogram strength."""
        if action == 'HOLD':
            return 0.5
        
        hist_current = self._histogram.iloc[-1]
        current_price = df['close'].iloc[-1]
        
        # Normalize histogram by price
        hist_normalized = abs(hist_current) / current_price
        
        # Base confidence + bonus for stronger histogram
        confidence = 0.6 + min(hist_normalized * 100, 0.3)
        return round(min(confidence, 0.95), 2)
    
    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        macd_val = indicators.get('macd')
        signal_val = indicators.get('signal')
        hist_val = indicators.get('histogram')
        
        if action == 'HOLD':
            return f"MACD ({macd_val}) aligned with Signal ({signal_val}), no crossover"
        
        direction = "above" if action == "BUY" else "below"
        return (
            f"MACD({self.params['fast']},{self.params['slow']}) Crossover: "
            f"MACD={macd_val} crossed {direction} Signal={signal_val}, Hist={hist_val}"
        )
