"""Pivot Points Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_pivot_points
from ..types import SignalAction


class PivotStrategy(Strategy):
    """Pivot Points Breakout Strategy.
    
    Buy when price breaks above R1 (first resistance).
    Sell when price breaks below S1 (first support).
    """
    
    name = "pivot"
    default_params = {
        'pivot_type': 'standard',  # 'standard', 'fibonacci', 'woodie'
    }
    
    def init(self, df: pd.DataFrame) -> None:
        """Calculate Pivot Points."""
        pivot_type = self.params['pivot_type']
        
        self._pivot, self._r1, self._r2, self._r3, self._s1, self._s2, self._s3 = \
            calculate_pivot_points(df, pivot_type)
        
        self._indicators = {
            'pivot': round(self._pivot, 2) if not pd.isna(self._pivot) else None,
            'r1': round(self._r1, 2) if not pd.isna(self._r1) else None,
            'r2': round(self._r2, 2) if not pd.isna(self._r2) else None,
            'r3': round(self._r3, 2) if not pd.isna(self._r3) else None,
            's1': round(self._s1, 2) if not pd.isna(self._s1) else None,
            's2': round(self._s2, 2) if not pd.isna(self._s2) else None,
            's3': round(self._s3, 2) if not pd.isna(self._s3) else None,
        }
    
    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on Pivot Points breakout."""
        if len(df) < 2:
            return 'HOLD'
        
        current_price = df['close'].iloc[-1]
        prev_price = df['close'].iloc[-2]
        
        if pd.isna(current_price) or pd.isna(prev_price):
            return 'HOLD'
        
        r1 = self._r1
        s1 = self._s1
        
        if pd.isna(r1) or pd.isna(s1):
            return 'HOLD'
        
        # Buy: price breaks above R1
        if prev_price <= r1 and current_price > r1:
            return 'BUY'
        
        # Sell: price breaks below S1
        if prev_price >= s1 and current_price < s1:
            return 'SELL'
        
        return 'HOLD'
    
    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on distance from pivot."""
        if action == 'HOLD':
            return 0.5
        
        current_price = df['close'].iloc[-1]
        
        if action == 'BUY':
            # Distance above R1
            distance = (current_price - self._r1) / self._r1
        else:
            # Distance below S1
            distance = (self._s1 - current_price) / self._s1
        
        confidence = 0.6 + min(distance * 10, 0.35)
        return round(min(confidence, 0.95), 2)
    
    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        pivot = indicators.get('pivot')
        r1 = indicators.get('r1')
        s1 = indicators.get('s1')
        
        if action == 'BUY':
            return f"Pivot breakout: price crossed above R1({r1}), pivot={pivot}"
        elif action == 'SELL':
            return f"Pivot breakout: price crossed below S1({s1}), pivot={pivot}"
        else:
            return f"Pivot: {pivot}, R1: {r1}, S1: {s1}"
