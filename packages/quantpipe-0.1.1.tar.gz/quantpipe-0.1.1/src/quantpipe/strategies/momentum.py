"""Momentum Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_rsi, calculate_sma
from ..types import SignalAction


class MomentumStrategy(Strategy):
    """Momentum Strategy.

    Buy when RSI shows oversold AND price momentum is positive.
    Sell when RSI shows overbought OR momentum weakens.
    """

    name = "momentum"
    default_params = {
        'rsi_period': 14,
        'rsi_oversold': 30,
        'rsi_overbought': 70,
        'momentum_period': 10,
        'momentum_threshold': 0.0,
    }

    def init(self, df: pd.DataFrame) -> None:
        """Calculate RSI and momentum indicators."""
        rsi_period = self.params['rsi_period']
        momentum_period = self.params['momentum_period']

        self._rsi = calculate_rsi(df, rsi_period)

        momentum = df['close'].pct_change(periods=momentum_period)
        self._momentum = momentum

        self._indicators = {
            'rsi': round(self._rsi.iloc[-1], 2) if not pd.isna(self._rsi.iloc[-1]) else None,
            'momentum': round(self._momentum.iloc[-1], 4) if not pd.isna(self._momentum.iloc[-1]) else None,
            'rsi_oversold': self.params['rsi_oversold'],
            'rsi_overbought': self.params['rsi_overbought'],
        }

    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on RSI and momentum."""
        if len(self._rsi) < 1 or len(self._momentum) < 1:
            return 'HOLD'

        current_rsi = self._rsi.iloc[-1]
        current_momentum = self._momentum.iloc[-1]

        if pd.isna(current_rsi) or pd.isna(current_momentum):
            return 'HOLD'

        rsi_oversold = self.params['rsi_oversold']
        rsi_overbought = self.params['rsi_overbought']
        momentum_threshold = self.params['momentum_threshold']

        if current_rsi <= rsi_oversold and current_momentum > momentum_threshold:
            return 'BUY'

        if current_rsi >= rsi_overbought or current_momentum < momentum_threshold:
            return 'SELL'

        return 'HOLD'

    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on RSI extreme and momentum strength."""
        if action == 'HOLD':
            return 0.5

        current_rsi = self._rsi.iloc[-1]
        current_momentum = self._momentum.iloc[-1]

        rsi_oversold = self.params['rsi_oversold']
        rsi_overbought = self.params['rsi_overbought']

        if action == 'BUY':
            rsi_distance = (rsi_oversold - current_rsi) / rsi_oversold
            momentum_strength = min(abs(current_momentum) * 10, 1.0)
            confidence = 0.6 + (rsi_distance * 0.2) + (momentum_strength * 0.15)
        else:
            rsi_distance = (current_rsi - rsi_overbought) / (100 - rsi_overbought)
            momentum_weakness = min(abs(current_momentum) * 5, 0.3)
            confidence = 0.6 + (rsi_distance * 0.2) + momentum_weakness

        return round(min(confidence, 0.95), 2)

    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        rsi_val = indicators.get('rsi')
        momentum_val = indicators.get('momentum')
        rsi_oversold = indicators.get('rsi_oversold')
        rsi_overbought = indicators.get('rsi_overbought')

        if action == 'BUY':
            return (
                f"Momentum BUY: RSI ({rsi_val}) <= {rsi_oversold} oversold, "
                f"momentum ({momentum_val:.2%}) > 0"
            )
        elif action == 'SELL':
            if rsi_val >= rsi_overbought:
                return f"Momentum SELL: RSI ({rsi_val}) >= {rsi_overbought} overbought"
            else:
                return f"Momentum SELL: Momentum ({momentum_val:.2%}) < 0"
        else:
            return f"HOLD: RSI ({rsi_val}) neutral, momentum ({momentum_val:.2%})"
