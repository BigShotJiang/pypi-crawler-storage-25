"""Built-in strategies for QuantPipe."""

from .ma_cross import MACrossStrategy
from .rsi import RSIStrategy
from .macd import MACDStrategy
from .momentum import MomentumStrategy
from .mean_reversion import MeanReversionStrategy
from .breakout import BreakoutStrategy
from .supertrend import SupertrendStrategy
from .stochastic import StochasticStrategy
from .adx import ADXStrategy
from .vwap import VWAPStrategy
from .pivot import PivotStrategy
from .bollinger import BollingerStrategy

STRATEGIES = {
    'ma_cross': MACrossStrategy,
    'rsi': RSIStrategy,
    'macd': MACDStrategy,
    'momentum': MomentumStrategy,
    'mean_reversion': MeanReversionStrategy,
    'breakout': BreakoutStrategy,
    'supertrend': SupertrendStrategy,
    'stochastic': StochasticStrategy,
    'adx': ADXStrategy,
    'vwap': VWAPStrategy,
    'pivot': PivotStrategy,
    'bollinger': BollingerStrategy,
}

__all__ = [
    'MACrossStrategy',
    'RSIStrategy',
    'MACDStrategy',
    'MomentumStrategy',
    'MeanReversionStrategy',
    'BreakoutStrategy',
    'SupertrendStrategy',
    'StochasticStrategy',
    'ADXStrategy',
    'VWAPStrategy',
    'PivotStrategy',
    'BollingerStrategy',
    'STRATEGIES',
]
