"""Breakout Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_atr
from ..types import SignalAction


class BreakoutStrategy(Strategy):
    """Breakout Strategy.

    Buy when price breaks above recent high with sufficient momentum.
    Sell when price breaks below recent low or volatility expands.
    """

    name = "breakout"
    default_params = {
        'lookback_period': 20,
        'atr_period': 14,
        'atr_multiplier': 2.0,
        'volume_confirm': True,
        'volume_threshold': 1.5,
    }

    def init(self, df: pd.DataFrame) -> None:
        """Calculate breakout indicators."""
        lookback = self.params['lookback_period']
        atr_period = self.params['atr_period']

        self._highs = df['high']
        self._lows = df['low']
        self._closes = df['close']
        self._volumes = df.get('volume', pd.Series([1] * len(df)))

        rolling_high = df['high'].rolling(window=lookback, min_periods=lookback).max()
        rolling_low = df['low'].rolling(window=lookback, min_periods=lookback).min()
        self._rolling_high = rolling_high.shift(1)
        self._rolling_low = rolling_low.shift(1)

        self._atr = calculate_atr(df, atr_period)

        avg_volume = self._volumes.rolling(window=lookback, min_periods=lookback).mean()
        self._avg_volume = avg_volume

        current_price = df['close'].iloc[-1]
        current_high = df['high'].iloc[-1]
        current_low = df['low'].iloc[-1]
        atr_val = self._atr.iloc[-1]

        self._indicators = {
            'rolling_high': round(self._rolling_high.iloc[-1], 2) if not pd.isna(self._rolling_high.iloc[-1]) else None,
            'rolling_low': round(self._rolling_low.iloc[-1], 2) if not pd.isna(self._rolling_low.iloc[-1]) else None,
            'atr': round(atr_val, 4) if not pd.isna(atr_val) else None,
            'breakout_distance': round((current_price - self._rolling_high.iloc[-1]) / atr_val, 2)
                if not pd.isna(atr_val) and not pd.isna(self._rolling_high.iloc[-1]) and atr_val > 0
                else 0,
        }

    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on breakout conditions."""
        if len(self._rolling_high) < 1 or len(self._rolling_low) < 1:
            return 'HOLD'

        current_price = df['close'].iloc[-1]
        current_high = df['high'].iloc[-1]
        current_low = df['low'].iloc[-1]
        atr_val = self._atr.iloc[-1]

        rolling_high = self._rolling_high.iloc[-1]
        rolling_low = self._rolling_low.iloc[-1]

        if pd.isna(rolling_high) or pd.isna(rolling_low) or pd.isna(atr_val):
            return 'HOLD'

        atr_mult = self.params['atr_multiplier']
        volume_confirm = self.params.get('volume_confirm', True)
        vol_threshold = self.params.get('volume_threshold', 1.5)

        current_volume = self._volumes.iloc[-1] if 'volume' in df else 1
        avg_volume = self._avg_volume.iloc[-1] if not pd.isna(self._avg_volume.iloc[-1]) else 1

        volume_satisfied = True
        if volume_confirm and avg_volume > 0:
            volume_satisfied = current_volume >= avg_volume * vol_threshold

        if current_high > rolling_high and volume_satisfied:
            return 'BUY'

        stop_distance = atr_mult * atr_val
        implied_stop = rolling_low - stop_distance

        if current_low < rolling_low or (current_price < implied_stop and self.params.get('adaptive_stop', False)):
            return 'SELL'

        return 'HOLD'

    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on breakout strength."""
        if action == 'HOLD':
            return 0.5

        current_price = df['close'].iloc[-1]
        rolling_high = self._rolling_high.iloc[-1]
        atr_val = self._atr.iloc[-1]

        if pd.isna(rolling_high) or pd.isna(atr_val) or atr_val == 0:
            return 0.6

        breakout_pct = (current_price - rolling_high) / rolling_high if rolling_high > 0 else 0
        atr_ratio = breakout_pct / atr_val if atr_val > 0 else 0

        if action == 'BUY':
            breakout_strength = min(abs(breakout_pct) * 50, 0.25)
            volume_boost = 0.1 if self.params.get('volume_confirm', True) else 0
            confidence = 0.6 + breakout_strength + volume_boost
        else:
            confidence = 0.65

        return round(min(confidence, 0.95), 2)

    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        rolling_high = indicators.get('rolling_high')
        rolling_low = indicators.get('rolling_low')
        atr = indicators.get('atr')
        breakout_dist = indicators.get('breakout_distance', 0)

        if action == 'BUY':
            return (
                f"Breakout BUY: Price broke above {lookback_period}-period high ({rolling_high:.2f}), "
                f"distance = {breakout_dist:.1f}x ATR"
            ).format(lookback_period=self.params['lookback_period'])
        elif action == 'SELL':
            return f"Breakout SELL: Price fell below {self.params['lookback_period']}-period low ({rolling_low:.2f})"
        else:
            return f"HOLD: No breakout signal (high={rolling_high}, low={rolling_low})"
