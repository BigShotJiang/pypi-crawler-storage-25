"""VWAP (Volume Weighted Average Price) Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_vwap
from ..types import SignalAction


class VWAPStrategy(Strategy):
    """VWAP Mean Reversion Strategy.
    
    Buy when price crosses above VWAP.
    Sell when price crosses below VWAP.
    """
    
    name = "vwap"
    default_params = {
        'max_deviation': 0.02,  # 2% max deviation for signals
    }
    
    def init(self, df: pd.DataFrame) -> None:
        """Calculate VWAP."""
        self._vwap = calculate_vwap(df)
        
        current_vwap = self._vwap.iloc[-1] if len(self._vwap) > 0 else None
        current_price = df['close'].iloc[-1] if len(df) > 0 else None
        
        self._indicators = {
            'vwap': round(current_vwap, 2) if not pd.isna(current_vwap) else None,
            'price': current_price,
        }
        
        if current_vwap and current_price and not pd.isna(current_vwap):
            deviation = (current_price - current_vwap) / current_vwap
            self._indicators['deviation_pct'] = round(deviation * 100, 2)
    
    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on VWAP crossover."""
        if len(self._vwap) < 2:
            return 'HOLD'
        
        current_price = df['close'].iloc[-1]
        current_vwap = self._vwap.iloc[-1]
        prev_price = df['close'].iloc[-2]
        prev_vwap = self._vwap.iloc[-2]
        
        if pd.isna(current_price) or pd.isna(current_vwap) or pd.isna(prev_price) or pd.isna(prev_vwap):
            return 'HOLD'
        
        max_deviation = self.params['max_deviation']
        
        # Buy: price crosses above VWAP
        if prev_price <= prev_vwap and current_price > current_vwap:
            return 'BUY'
        
        # Sell: price crosses below VWAP
        if prev_price >= prev_vwap and current_price < current_vwap:
            return 'SELL'
        
        # Optional: extreme deviation signals
        deviation = abs(current_price - current_vwap) / current_vwap
        if deviation > max_deviation:
            # Price has deviated too far from VWAP
            if current_price < current_vwap:
                return 'BUY'  # Price below VWAP, expect reversion
            else:
                return 'SELL'  # Price above VWAP, expect reversion
        
        return 'HOLD'
    
    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on deviation from VWAP."""
        if action == 'HOLD':
            return 0.5
        
        current_price = df['close'].iloc[-1]
        current_vwap = self._vwap.iloc[-1]
        
        if pd.isna(current_price) or pd.isna(current_vwap) or current_vwap == 0:
            return 0.5
        
        deviation = abs(current_price - current_vwap) / current_vwap
        max_deviation = self.params['max_deviation']
        
        # Higher confidence when deviation is larger (reversion trade)
        normalized_dev = min(deviation / max_deviation, 1.0)
        confidence = 0.6 + normalized_dev * 0.35
        return round(min(confidence, 0.95), 2)
    
    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        vwap = indicators.get('vwap')
        price = indicators.get('price')
        deviation = indicators.get('deviation_pct', 0)
        
        if action == 'BUY':
            return f"VWAP crossover: price({price}) crossed above VWAP({vwap}), deviation={deviation}%"
        elif action == 'SELL':
            return f"VWAP crossover: price({price}) crossed below VWAP({vwap}), deviation={deviation}%"
        else:
            return f"VWAP: {vwap}, Price: {price}, Deviation: {deviation}%"
