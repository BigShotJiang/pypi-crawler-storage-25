"""RSI Mean Reversion Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_rsi
from ..types import SignalAction


class RSIStrategy(Strategy):
    """RSI Mean Reversion Strategy.
    
    Buy when RSI < oversold (default 30).
    Sell when RSI > overbought (default 70).
    """
    
    name = "rsi"
    default_params = {
        'period': 14,
        'oversold': 30,
        'overbought': 70,
    }
    
    def init(self, df: pd.DataFrame) -> None:
        """Calculate RSI."""
        period = self.params['period']
        self._rsi = calculate_rsi(df, period)
        
        self._indicators = {
            'rsi': round(self._rsi.iloc[-1], 2) if not pd.isna(self._rsi.iloc[-1]) else None,
            'oversold': self.params['oversold'],
            'overbought': self.params['overbought'],
        }
    
    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on RSI levels."""
        if len(self._rsi) < 1:
            return 'HOLD'
        
        current_rsi = self._rsi.iloc[-1]
        
        if pd.isna(current_rsi):
            return 'HOLD'
        
        oversold = self.params['oversold']
        overbought = self.params['overbought']
        
        # Simple threshold-based signals
        if current_rsi <= oversold:
            return 'BUY'
        if current_rsi >= overbought:
            return 'SELL'
        
        return 'HOLD'
    
    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on RSI distance from neutral (50)."""
        if action == 'HOLD':
            return 0.5
        
        current_rsi = self._rsi.iloc[-1]
        
        # Distance from 50 (neutral)
        distance = abs(current_rsi - 50) / 50  # 0 to 1
        
        # Higher confidence when RSI is more extreme
        confidence = 0.5 + (distance * 0.4)
        return round(min(confidence, 0.95), 2)
    
    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        rsi_val = indicators.get('rsi')
        oversold = indicators.get('oversold')
        overbought = indicators.get('overbought')
        
        if action == 'HOLD':
            return f"RSI ({rsi_val}) within neutral zone ({oversold}-{overbought})"
        elif action == 'BUY':
            return f"RSI ({rsi_val}) below oversold level ({oversold}) - potential reversal up"
        else:  # SELL
            return f"RSI ({rsi_val}) above overbought level ({overbought}) - potential reversal down"
