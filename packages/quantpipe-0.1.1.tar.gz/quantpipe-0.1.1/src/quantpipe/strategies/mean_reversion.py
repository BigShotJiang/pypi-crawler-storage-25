"""Mean Reversion Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_bollinger_bands
from ..types import SignalAction


class MeanReversionStrategy(Strategy):
    """Mean Reversion Strategy.

    Buy when price touches lower Bollinger Band (oversold).
    Sell when price touches upper Bollinger Band (overbought).
    """

    name = "mean_reversion"
    default_params = {
        'bb_period': 20,
        'bb_std': 2.0,
        'exit_on_middle': True,
    }

    def init(self, df: pd.DataFrame) -> None:
        """Calculate Bollinger Bands."""
        bb_period = self.params['bb_period']
        bb_std = self.params['bb_std']

        upper, middle, lower = calculate_bollinger_bands(df, bb_period, bb_std)
        self._upper = upper
        self._middle = middle
        self._lower = lower

        current_price = df['close'].iloc[-1]
        self._indicators = {
            'upper': round(self._upper.iloc[-1], 2) if not pd.isna(self._upper.iloc[-1]) else None,
            'middle': round(self._middle.iloc[-1], 2) if not pd.isna(self._middle.iloc[-1]) else None,
            'lower': round(self._lower.iloc[-1], 2) if not pd.isna(self._lower.iloc[-1]) else None,
            'bb_percent': round((current_price - self._lower.iloc[-1]) / (self._upper.iloc[-1] - self._lower.iloc[-1]), 2)
                if not pd.isna(self._upper.iloc[-1]) and not pd.isna(self._lower.iloc[-1]) and self._upper.iloc[-1] != self._lower.iloc[-1]
                else 0.5,
        }

    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on Bollinger Bands."""
        if len(self._upper) < 1 or len(self._lower) < 1:
            return 'HOLD'

        current_price = df['close'].iloc[-1]
        upper = self._upper.iloc[-1]
        lower = self._lower.iloc[-1]
        middle = self._middle.iloc[-1]

        if pd.isna(upper) or pd.isna(lower) or pd.isna(middle):
            return 'HOLD'

        bb_width = upper - lower
        if bb_width == 0:
            return 'HOLD'

        tolerance = bb_width * 0.01

        if current_price <= lower + tolerance:
            return 'BUY'

        if current_price >= upper - tolerance:
            return 'SELL'

        if self.params.get('exit_on_middle', True):
            if abs(current_price - middle) < tolerance:
                return 'SELL'

        return 'HOLD'

    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on Bollinger Band position."""
        if action == 'HOLD':
            return 0.5

        current_price = df['close'].iloc[-1]
        upper = self._upper.iloc[-1]
        lower = self._lower.iloc[-1]
        middle = self._middle.iloc[-1]

        bb_width = upper - lower
        if bb_width == 0:
            return 0.5

        bb_percent = (current_price - lower) / bb_width

        if action == 'BUY':
            distance_from_lower = bb_percent
            confidence = 0.6 + (distance_from_lower * 0.3)
        else:
            distance_from_upper = 1 - bb_percent
            confidence = 0.6 + (distance_from_upper * 0.3)

        return round(min(confidence, 0.95), 2)

    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        upper = indicators.get('upper')
        middle = indicators.get('middle')
        lower = indicators.get('lower')
        bb_pct = indicators.get('bb_percent', 0.5)

        if action == 'BUY':
            return (
                f"Mean Reversion BUY: Price at lower BB ({lower:.2f}), "
                f"BB% = {bb_pct:.0%}"
            )
        elif action == 'SELL':
            return (
                f"Mean Reversion SELL: Price at upper BB ({upper:.2f}), "
                f"BB% = {bb_pct:.0%}"
            )
        else:
            return f"HOLD: Price near middle BB ({middle:.2f})"
