"""Stochastic Oscillator Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_stochastic
from ..types import SignalAction


class StochasticStrategy(Strategy):
    """Stochastic Oscillator Strategy.
    
    Buy when %K crosses above %D in oversold territory.
    Sell when %K crosses below %D in overbought territory.
    """
    
    name = "stochastic"
    default_params = {
        'k_period': 14,
        'd_period': 3,
        'oversold': 20,
        'overbought': 80,
    }
    
    def init(self, df: pd.DataFrame) -> None:
        """Calculate Stochastic."""
        k_period = self.params['k_period']
        d_period = self.params['d_period']
        
        self._k, self._d = calculate_stochastic(df, k_period, d_period)
        
        current_k = self._k.iloc[-1] if len(self._k) > 0 else None
        current_d = self._d.iloc[-1] if len(self._d) > 0 else None
        
        self._indicators = {
            'k': round(current_k, 2) if not pd.isna(current_k) else None,
            'd': round(current_d, 2) if not pd.isna(current_d) else None,
            'oversold': self.params['oversold'],
            'overbought': self.params['overbought'],
        }
    
    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on Stochastic crossover."""
        if len(self._k) < 2 or len(self._d) < 2:
            return 'HOLD'
        
        k_current = self._k.iloc[-1]
        d_current = self._d.iloc[-1]
        k_prev = self._k.iloc[-2]
        d_prev = self._d.iloc[-2]
        
        if pd.isna(k_current) or pd.isna(d_current) or pd.isna(k_prev) or pd.isna(d_prev):
            return 'HOLD'
        
        oversold = self.params['oversold']
        overbought = self.params['overbought']
        
        # %K crosses above %D in oversold zone
        if k_prev <= d_prev and k_current > d_current and k_current < oversold:
            return 'BUY'
        
        # %K crosses below %D in overbought zone
        if k_prev >= d_prev and k_current < d_current and k_current > overbought:
            return 'SELL'
        
        return 'HOLD'
    
    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on Stochastic position."""
        if action == 'HOLD':
            return 0.5
        
        k_current = self._k.iloc[-1]
        oversold = self.params['oversold']
        overbought = self.params['overbought']
        
        if action == 'BUY':
            # Deeper in oversold = higher confidence
            distance = (oversold - k_current) / oversold
            confidence = 0.6 + min(distance * 0.4, 0.3)
        else:  # SELL
            # Deeper in overbought = higher confidence
            distance = (k_current - overbought) / (100 - overbought)
            confidence = 0.6 + min(distance * 0.4, 0.3)
        
        return round(min(confidence, 0.95), 2)
    
    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        k = indicators.get('k')
        d = indicators.get('d')
        oversold = indicators.get('oversold')
        overbought = indicators.get('overbought')
        
        if action == 'BUY':
            return f"Stochastic crossover: K({k}) crossed above D({d}) in oversold zone (<{oversold})"
        elif action == 'SELL':
            return f"Stochastic crossover: K({k}) crossed below D({d}) in overbought zone (>{overbought})"
        else:
            return f"Stochastic: K({k}), D({d})"
