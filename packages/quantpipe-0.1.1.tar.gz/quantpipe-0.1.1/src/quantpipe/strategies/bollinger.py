"""Bollinger Bands Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_bollinger_bands
from ..types import SignalAction


class BollingerStrategy(Strategy):
    """Bollinger Bands Mean Reversion Strategy.
    
    Buy when price touches lower band (oversold).
    Sell when price touches upper band (overbought).
    """
    
    name = "bollinger"
    default_params = {
        'period': 20,
        'std': 2.0,
        'mode': 'bands',  # 'bands' (reversion) or 'bands_breakout' (trend)
    }
    
    def init(self, df: pd.DataFrame) -> None:
        """Calculate Bollinger Bands."""
        period = self.params['period']
        std = self.params['std']
        
        self._upper, self._middle, self._lower = calculate_bollinger_bands(df, period, std)
        
        current_upper = self._upper.iloc[-1] if len(self._upper) > 0 else None
        current_middle = self._middle.iloc[-1] if len(self._middle) > 0 else None
        current_lower = self._lower.iloc[-1] if len(self._lower) > 0 else None
        current_price = df['close'].iloc[-1] if len(df) > 0 else None
        
        self._indicators = {
            'upper': round(current_upper, 2) if not pd.isna(current_upper) else None,
            'middle': round(current_middle, 2) if not pd.isna(current_middle) else None,
            'lower': round(current_lower, 2) if not pd.isna(current_lower) else None,
            'bandwidth': round(current_upper - current_lower, 2) if not pd.isna(current_upper) and not pd.isna(current_lower) else None,
        }
        
        if current_price and current_lower and not pd.isna(current_lower):
            pct_b = (current_price - current_lower) / (current_upper - current_lower) if current_upper != current_lower else 0.5
            self._indicators['pct_b'] = round(pct_b, 2)
    
    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on Bollinger Bands."""
        if len(self._upper) < 1 or len(df) < 1:
            return 'HOLD'
        
        current_price = df['close'].iloc[-1]
        current_upper = self._upper.iloc[-1]
        current_middle = self._middle.iloc[-1]
        current_lower = self._lower.iloc[-1]
        
        if pd.isna(current_price) or pd.isna(current_upper) or pd.isna(current_lower):
            return 'HOLD'
        
        mode = self.params.get('mode', 'bands')
        
        if mode == 'bands':
            # Mean reversion mode
            # Buy: price at or below lower band (oversold)
            if current_price <= current_lower:
                return 'BUY'
            
            # Sell: price at or above upper band (overbought)
            if current_price >= current_upper:
                return 'SELL'
        else:
            # Breakout mode
            prev_price = df['close'].iloc[-2] if len(df) >= 2 else None
            if prev_price is not None:
                # Buy: price breaks above upper band
                if prev_price <= current_upper and current_price > current_upper:
                    return 'BUY'
                # Sell: price breaks below lower band
                if prev_price >= current_lower and current_price < current_lower:
                    return 'SELL'
        
        return 'HOLD'
    
    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on %B position."""
        if action == 'HOLD':
            return 0.5
        
        current_price = df['close'].iloc[-1]
        current_upper = self._upper.iloc[-1]
        current_lower = self._lower.iloc[-1]
        
        if pd.isna(current_price) or pd.isna(current_upper) or pd.isna(current_lower) or current_upper == current_lower:
            return 0.5
        
        pct_b = (current_price - current_lower) / (current_upper - current_lower)
        
        if action == 'BUY':
            # How far below the lower band (or how extreme the oversold)
            distance = abs(min(pct_b, 0))  # At or below lower band
            confidence = 0.6 + min(abs(distance) * 5, 0.35)
        else:  # SELL
            # How far above the upper band (or how extreme the overbought)
            distance = max(pct_b - 1, 0)  # At or above upper band
            confidence = 0.6 + min(distance * 5, 0.35)
        
        return round(min(confidence, 0.95), 2)
    
    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        upper = indicators.get('upper')
        middle = indicators.get('middle')
        lower = indicators.get('lower')
        pct_b = indicators.get('pct_b')
        mode = self.params.get('mode', 'bands')
        
        if action == 'BUY':
            return f"Bollinger Bands: price touched lower band({lower}) - oversold, %B={pct_b:.2f}"
        elif action == 'SELL':
            return f"Bollinger Bands: price touched upper band({upper}) - overbought, %B={pct_b:.2f}"
        else:
            return f"Bollinger Bands: upper={upper}, middle={middle}, lower={lower}, %B={pct_b}"
