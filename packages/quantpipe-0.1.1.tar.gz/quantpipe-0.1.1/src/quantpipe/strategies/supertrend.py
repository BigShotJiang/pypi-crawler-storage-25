"""Supertrend Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_supertrend
from ..types import SignalAction


class SupertrendStrategy(Strategy):
    """Supertrend Strategy.
    
    Buy when price crosses above supertrend (uptrend confirmation).
    Sell when price crosses below supertrend (downtrend confirmation).
    """
    
    name = "supertrend"
    default_params = {
        'period': 10,
        'multiplier': 3.0,
    }
    
    def init(self, df: pd.DataFrame) -> None:
        """Calculate Supertrend."""
        period = self.params['period']
        multiplier = self.params['multiplier']
        
        self._supertrend, self._direction = calculate_supertrend(df, period, multiplier)
        
        current_direction = self._direction.iloc[-1] if len(self._direction) > 0 else 0
        current_supertrend = self._supertrend.iloc[-1] if len(self._supertrend) > 0 else None
        
        self._indicators = {
            'supertrend': round(current_supertrend, 2) if not pd.isna(current_supertrend) else None,
            'direction': int(current_direction),
            'trend': 'uptrend' if current_direction == 1 else 'downtrend',
        }
    
    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on Supertrend direction change."""
        if len(self._direction) < 2:
            return 'HOLD'
        
        current_direction = self._direction.iloc[-1]
        prev_direction = self._direction.iloc[-2]
        current_supertrend = self._supertrend.iloc[-1]
        
        if pd.isna(current_direction) or pd.isna(prev_direction) or pd.isna(current_supertrend):
            return 'HOLD'
        
        # Buy: direction changes from -1 to 1 (downtrend to uptrend)
        if prev_direction == -1 and current_direction == 1:
            return 'BUY'
        
        # Sell: direction changes from 1 to -1 (uptrend to downtrend)
        if prev_direction == 1 and current_direction == -1:
            return 'SELL'
        
        return 'HOLD'
    
    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on trend strength."""
        if action == 'HOLD':
            return 0.5
        
        current_supertrend = self._supertrend.iloc[-1]
        current_price = df['close'].iloc[-1]
        
        if pd.isna(current_supertrend):
            return 0.5
        
        # Distance from supertrend as percentage of price
        distance = abs(current_price - current_supertrend) / current_price
        
        # Higher confidence when price is further from supertrend
        confidence = 0.6 + min(distance * 10, 0.3)
        return round(min(confidence, 0.95), 2)
    
    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        direction = indicators.get('trend', 'unknown')
        supertrend = indicators.get('supertrend')
        
        if action == 'BUY':
            return f"Supertrend reversal: trend changed to uptrend, supertrend={supertrend}"
        elif action == 'SELL':
            return f"Supertrend reversal: trend changed to downtrend, supertrend={supertrend}"
        else:
            return f"Supertrend ({direction}): {supertrend}"
