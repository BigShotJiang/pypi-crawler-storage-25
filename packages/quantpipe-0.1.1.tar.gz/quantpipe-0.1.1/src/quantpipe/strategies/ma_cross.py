"""Moving Average Crossover Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_sma, calculate_ema
from ..types import SignalAction


class MACrossStrategy(Strategy):
    """Moving Average Crossover Strategy.
    
    Buy when fast MA crosses above slow MA.
    Sell when fast MA crosses below slow MA.
    """
    
    name = "ma_cross"
    default_params = {
        'fast': 10,
        'slow': 30,
        'ma_type': 'sma',  # 'sma' or 'ema'
    }
    
    def init(self, df: pd.DataFrame) -> None:
        """Calculate moving averages."""
        fast_period = self.params['fast']
        slow_period = self.params['slow']
        ma_type = self.params.get('ma_type', 'sma')
        
        if ma_type == 'ema':
            self._fast_ma = calculate_ema(df, fast_period)
            self._slow_ma = calculate_ema(df, slow_period)
        else:
            self._fast_ma = calculate_sma(df, fast_period)
            self._slow_ma = calculate_sma(df, slow_period)
        
        self._indicators = {
            'fastMa': round(self._fast_ma.iloc[-1], 2) if not pd.isna(self._fast_ma.iloc[-1]) else None,
            'slowMa': round(self._slow_ma.iloc[-1], 2) if not pd.isna(self._slow_ma.iloc[-1]) else None,
        }
    
    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on MA crossover."""
        if len(self._fast_ma) < 2 or len(self._slow_ma) < 2:
            return 'HOLD'
        
        # Current values
        fast_current = self._fast_ma.iloc[-1]
        slow_current = self._slow_ma.iloc[-1]
        
        # Previous values
        fast_prev = self._fast_ma.iloc[-2]
        slow_prev = self._slow_ma.iloc[-2]
        
        # Check for valid values
        if pd.isna(fast_current) or pd.isna(slow_current) or pd.isna(fast_prev) or pd.isna(slow_prev):
            return 'HOLD'
        
        # Crossover detection
        # Buy: fast crosses above slow
        if fast_prev <= slow_prev and fast_current > slow_current:
            return 'BUY'
        
        # Sell: fast crosses below slow
        if fast_prev >= slow_prev and fast_current < slow_current:
            return 'SELL'
        
        return 'HOLD'
    
    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on MA separation."""
        if action == 'HOLD':
            return 0.5
        
        fast_current = self._fast_ma.iloc[-1]
        slow_current = self._slow_ma.iloc[-1]
        current_price = df['close'].iloc[-1]
        
        # Calculate percentage distance between MAs
        ma_diff = abs(fast_current - slow_current) / current_price
        
        # Base confidence + bonus for larger separation
        confidence = 0.6 + min(ma_diff * 10, 0.3)
        return round(min(confidence, 0.95), 2)
    
    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        if action == 'HOLD':
            return f"No crossover detected. Fast MA ({indicators.get('fastMa')}) vs Slow MA ({indicators.get('slowMa')})"
        
        ma_type = self.params.get('ma_type', 'sma').upper()
        direction = "above" if action == "BUY" else "below"
        return (
            f"{ma_type} Crossover: Fast({self.params['fast']})={indicators.get('fastMa')} "
            f"crossed {direction} Slow({self.params['slow']})={indicators.get('slowMa')}"
        )
