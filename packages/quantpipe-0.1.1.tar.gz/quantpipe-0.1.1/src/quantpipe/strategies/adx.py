"""ADX (Average Directional Index) Strategy."""

from typing import Dict, Any
import pandas as pd

from ..core.strategy import Strategy
from ..core.indicators import calculate_adx
from ..types import SignalAction


class ADXStrategy(Strategy):
    """ADX Trend Strength Strategy.
    
    Buy when ADX shows strong trend (+DI > -DI).
    Sell when ADX shows weak trend or -DI > +DI.
    """
    
    name = "adx"
    default_params = {
        'period': 14,
        'adx_threshold': 25,
    }
    
    def init(self, df: pd.DataFrame) -> None:
        """Calculate ADX and directional indicators."""
        period = self.params['period']
        
        self._adx, self._plus_di, self._minus_di = calculate_adx(df, period)
        
        current_adx = self._adx.iloc[-1] if len(self._adx) > 0 else None
        current_plus = self._plus_di.iloc[-1] if len(self._plus_di) > 0 else None
        current_minus = self._minus_di.iloc[-1] if len(self._minus_di) > 0 else None
        
        self._indicators = {
            'adx': round(current_adx, 2) if not pd.isna(current_adx) else None,
            'plus_di': round(current_plus, 2) if not pd.isna(current_plus) else None,
            'minus_di': round(current_minus, 2) if not pd.isna(current_minus) else None,
            'adx_threshold': self.params['adx_threshold'],
        }
    
    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal based on ADX and DI crossover."""
        if len(self._adx) < 2:
            return 'HOLD'
        
        adx_current = self._adx.iloc[-1]
        plus_current = self._plus_di.iloc[-1]
        minus_current = self._minus_di.iloc[-1]
        
        plus_prev = self._plus_di.iloc[-2]
        minus_prev = self._minus_di.iloc[-2]
        
        if pd.isna(adx_current) or pd.isna(plus_current) or pd.isna(minus_current):
            return 'HOLD'
        
        adx_threshold = self.params['adx_threshold']
        
        # Buy: ADX above threshold and +DI crosses above -DI
        if adx_current > adx_threshold:
            if plus_prev <= minus_prev and plus_current > minus_current:
                return 'BUY'
            # Also buy if +DI > -DI and ADX increasing (strong uptrend)
            adx_prev = self._adx.iloc[-2]
            if pd.notna(adx_prev) and plus_current > minus_current and adx_current > adx_prev:
                return 'BUY'
        
        # Sell: ADX above threshold and -DI crosses above +DI
        if adx_current > adx_threshold:
            if plus_prev >= minus_prev and plus_current < minus_current:
                return 'SELL'
        
        return 'HOLD'
    
    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate confidence based on ADX value."""
        if action == 'HOLD':
            return 0.5
        
        adx_current = self._adx.iloc[-1]
        adx_threshold = self.params['adx_threshold']
        
        if pd.isna(adx_current):
            return 0.5
        
        # Higher ADX = stronger trend = higher confidence
        normalized_adx = min(adx_current / 50, 1.0)  # Cap at 50 for max confidence
        confidence = 0.6 + normalized_adx * 0.35
        return round(min(confidence, 0.95), 2)
    
    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate reason for the signal."""
        adx = indicators.get('adx')
        plus_di = indicators.get('plus_di')
        minus_di = indicators.get('minus_di')
        threshold = indicators.get('adx_threshold')
        
        if action == 'BUY':
            return f"ADX trend signal: ADX({adx}) > {threshold}, +DI({plus_di}) > -DI({minus_di}) - strong uptrend"
        elif action == 'SELL':
            return f"ADX trend signal: ADX({adx}) > {threshold}, -DI({minus_di}) > +DI({plus_di}) - strong downtrend"
        else:
            return f"ADX({adx}), +DI({plus_di}), -DI({minus_di})"
