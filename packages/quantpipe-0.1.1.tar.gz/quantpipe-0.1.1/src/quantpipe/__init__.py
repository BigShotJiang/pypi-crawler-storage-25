"""QuantPipe - Quantitative trading toolkit for LLM AI."""

__version__ = "0.1.0"
