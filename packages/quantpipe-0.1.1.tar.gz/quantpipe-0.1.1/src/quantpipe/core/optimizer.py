"""Parameter optimization core logic for QuantPipe."""

from __future__ import annotations

import itertools
import math
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


def parse_param_range(param_str: str) -> Tuple[str, List[Any]]:
    """
    Parse parameter range string like 'fast=10-50' or 'period=5,10,20'.

    Args:
        param_str: Parameter specification string

    Returns:
        Tuple of (param_name, list_of_values)
    """
    if "=" not in param_str:
        raise ValueError(f"Invalid param format: {param_str}. Use key=range or key=val1,val2,...")

    key, values_str = param_str.split("=", 1)
    key = key.strip()

    if "-" in values_str and "," not in values_str:
        parts = values_str.split("-")
        if len(parts) == 2:
            try:
                start, end = float(parts[0]), float(parts[1])
                if start == int(start) and end == int(end):
                    values = list(range(int(start), int(end) + 1))
                else:
                    step = (end - start) / 10
                    values = [start + i * step for i in range(11)]
                    values = [round(v, 2) for v in values]
            except ValueError:
                values = [v.strip() for v in values_str.split("-")]
        else:
            values = [v.strip() for v in values_str.split("-")]
    else:
        value_parts = values_str.split(",")
        values = []
        for v in value_parts:
            v = v.strip()
            try:
                if "." in v:
                    values.append(float(v))
                else:
                    values.append(int(v))
            except ValueError:
                values.append(v)

    return key, values


def grid_search(
    strategy_class,
    param_ranges: Dict[str, List[Any]],
    df: pd.DataFrame,
    metric: str = "sharpe",
) -> List[Dict[str, Any]]:
    """
    Perform grid search over parameter combinations.

    Args:
        strategy_class: Strategy class to optimize
        param_ranges: Dictionary mapping parameter names to value lists
        df: OHLCV DataFrame
        metric: Optimization metric ('sharpe', 'total', 'calmar')

    Returns:
        List of result dictionaries sorted by metric
    """
    results = []

    param_names = list(param_ranges.keys())
    param_value_lists = [param_ranges[name] for name in param_names]

    for combo in itertools.product(*param_value_lists):
        params = dict(zip(param_names, combo))

        try:
            strategy = strategy_class(params=params)
            result = _evaluate_strategy(strategy, df, metric)
            result["params"] = params
            results.append(result)
        except Exception:
            continue

    results.sort(key=lambda x: x.get(metric, -999), reverse=True)
    return results


def bayesian_optimize(
    objective_fn: Callable,
    param_space: Dict[str, Tuple[Any, Any, Any]],
    n_trials: int = 100,
    metric: str = "sharpe",
) -> List[Dict[str, Any]]:
    """
    Perform Bayesian optimization over parameter space.

    Args:
        objective_fn: Function that takes params dict and returns metric value
        param_space: Dict mapping param names to (min, max, type) tuples
        n_trials: Number of trials
        metric: Metric name for results

    Returns:
        List of result dictionaries sorted by metric
    """
    try:
        from skopt import gp_minimize
        from skopt.space import Real, Integer
    except ImportError:
        return _fallback_random_search(objective_fn, param_space, n_trials, metric)

    dimensions = []
    for name, (low, high, ptype) in param_space.items():
        if ptype == "int":
            dimensions.append(Integer(low, high, name=name))
        else:
            dimensions.append(Real(low, high, name=name))

    def objective(params_list):
        params = dict(zip([d.name for d in dimensions], params_list))
        for name, (low, high, ptype) in param_space.items():
            if ptype == "int":
                params[name] = int(params[name])
        return -objective_fn(params)

    result = gp_minimize(objective, dimensions, n_calls=n_trials, random_state=42, verbose=False)

    results = []
    for i, (params, val) in enumerate(zip(result.x, result.func_vals)):
        params_dict = dict(zip([d.name for d in dimensions], params))
        for name, (low, high, ptype) in param_space.items():
            if ptype == "int":
                params_dict[name] = int(params_dict[name])
        results.append({
            "params": params_dict,
            metric: -val,
            "trial": i + 1,
        })

    results.sort(key=lambda x: x.get(metric, -999), reverse=True)
    return results


def _fallback_random_search(
    objective_fn: Callable,
    param_space: Dict[str, Tuple[Any, Any, Any]],
    n_trials: int,
    metric: str,
) -> List[Dict[str, Any]]:
    """Fallback random search when scikit-opt is not available."""
    import random

    results = []
    for i in range(n_trials):
        params = {}
        for name, (low, high, ptype) in param_space.items():
            if ptype == "int":
                params[name] = random.randint(int(low), int(high))
            else:
                params[name] = random.uniform(low, high)

        try:
            score = objective_fn(params)
            results.append({
                "params": params,
                metric: score,
                "trial": i + 1,
            })
        except Exception:
            continue

    results.sort(key=lambda x: x.get(metric, -999), reverse=True)
    return results


def _evaluate_strategy(strategy, df: pd.DataFrame, metric: str) -> Dict[str, Any]:
    """Evaluate a strategy on data and return metrics."""
    from ..core.backtest import BacktestEngine

    try:
        engine = BacktestEngine(strategy, df)
        metrics = engine.run()

        total_return = metrics.get("total_return", 0)
        sharpe = metrics.get("sharpe_ratio", 0)
        max_dd = metrics.get("max_drawdown", 1)
        calmar = total_return / max_dd if max_dd != 0 else 0
        win_rate = metrics.get("win_rate", 0)

        metric_value = {
            "sharpe": sharpe,
            "total": total_return,
            "calmar": calmar,
            "win_rate": win_rate,
        }.get(metric, sharpe)

        return {
            "total_return": total_return,
            "sharpe_ratio": sharpe,
            "max_drawdown": max_dd,
            "calmar_ratio": calmar,
            "win_rate": win_rate,
            "total_trades": metrics.get("total_trades", 0),
            metric: metric_value,
        }
    except Exception:
        return {
            "total_return": -999,
            "sharpe_ratio": -999,
            "max_drawdown": 1,
            "calmar_ratio": -999,
            "win_rate": 0,
            "total_trades": 0,
            metric: -999,
        }


def parameter_sensitivity(
    results: List[Dict[str, Any]],
    param_name: str,
) -> Dict[str, float]:
    """
    Calculate parameter sensitivity (impact on metric).

    Args:
        results: Grid search results
        param_name: Parameter to analyze

    Returns:
        Dictionary with sensitivity metrics
    """
    if not results:
        return {}

    values = []
    for r in results:
        if "params" in r and param_name in r["params"]:
            values.append((r["params"][param_name], r.get("sharpe", 0)))

    if len(values) < 2:
        return {}

    param_vals = [v[0] for v in values]
    metric_vals = [v[1] for v in values]

    if all(isinstance(v, (int, float)) for v in param_vals):
        corr = np.corrcoef(param_vals, metric_vals)[0, 1]
    else:
        unique_vals = list(set(param_vals))
        avg_metrics = {}
        for pv, mv in zip(param_vals, metric_vals):
            if pv not in avg_metrics:
                avg_metrics[pv] = []
            avg_metrics[pv].append(mv)

        for k in avg_metrics:
            avg_metrics[k] = sum(avg_metrics[k]) / len(avg_metrics[k])

        variance = np.var(list(avg_metrics.values())) if len(avg_metrics) > 1 else 0
        corr = math.sqrt(variance) if not np.isnan(variance) else 0

    return {
        "parameter": param_name,
        "correlation": round(corr, 4) if not np.isnan(corr) else 0,
        "best_value": results[0]["params"].get(param_name) if results else None,
        "range_tested": (min(param_vals), max(param_vals)) if param_vals else None,
    }
