"""Core modules for QuantPipe."""

from .adapter import (
    adapt_data, detect_data_format, DataFormat, MarketType,
    get_supported_formats, get_market_types, get_formats_by_market_type,
    get_market_type
)
from .data import load_data, prepare_data, detect_data_type
from .strategy import Strategy
from .backtest import BacktestEngine

__all__ = [
    'adapt_data',
    'detect_data_format',
    'DataFormat',
    'MarketType',
    'get_supported_formats',
    'get_market_types',
    'get_formats_by_market_type',
    'get_market_type',
    'load_data',
    'prepare_data',
    'detect_data_type',
    'Strategy',
    'BacktestEngine',
]
