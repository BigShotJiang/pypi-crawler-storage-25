"""Universal data adapter with auto-detection for multiple exchanges and data sources."""

import json
import sys
from typing import Union, List, Dict, Any, Optional, Callable
from datetime import datetime
from enum import Enum

import pandas as pd
import numpy as np


class MarketType(Enum):
    """Market type classification for data sources."""
    EXCHANGE = "exchange"           # Centralized exchanges (Binance, Coinbase, etc.)
    PREDICTION_MARKET = "prediction_market"  # Prediction markets (Polymarket, Augur, Gnosis, etc.)
    DEX = "dex"                     # Decentralized exchanges (Uniswap, SushiSwap, etc.)
    ORACLE = "oracle"               # Price oracles (Chainlink, etc.)
    GENERIC = "generic"             # Generic/unknown data sources
    UNKNOWN = "unknown"


class DataFormat(Enum):
    """Supported data formats."""
    # Exchange formats
    BINANCE_OHLCV = "binance_ohlcv"
    BINANCE_TICKERS = "binance_tickers"
    BINANCE_TICKER = "binance_ticker"
    
    # Prediction market formats
    POLYMARKET_PRICE_HISTORY = "polymarket_price_history"
    POLYMARKET_MARKET = "polymarket_market"
    POLYMARKET_ORDERBOOK = "polymarket_orderbook"
    
    # Generic formats
    GENERIC_OHLCV = "generic_ohlcv"
    GENERIC_PRICE_HISTORY = "generic_price_history"
    
    # Oracle formats
    CHAINLINK_PRICE = "chainlink_price"
    
    # DEX formats
    UNISWAP_CANDLES = "uniswap_candles"
    
    UNKNOWN = "unknown"


# Market type mapping for each data format
FORMAT_MARKET_TYPES = {
    DataFormat.BINANCE_OHLCV: MarketType.EXCHANGE,
    DataFormat.BINANCE_TICKERS: MarketType.EXCHANGE,
    DataFormat.BINANCE_TICKER: MarketType.EXCHANGE,
    DataFormat.POLYMARKET_PRICE_HISTORY: MarketType.PREDICTION_MARKET,
    DataFormat.POLYMARKET_MARKET: MarketType.PREDICTION_MARKET,
    DataFormat.POLYMARKET_ORDERBOOK: MarketType.PREDICTION_MARKET,
    DataFormat.GENERIC_OHLCV: MarketType.GENERIC,
    DataFormat.GENERIC_PRICE_HISTORY: MarketType.GENERIC,
    DataFormat.CHAINLINK_PRICE: MarketType.ORACLE,
    DataFormat.UNISWAP_CANDLES: MarketType.DEX,
    DataFormat.UNKNOWN: MarketType.UNKNOWN,
}


def get_market_type(data_format: DataFormat) -> MarketType:
    """Get the market type for a data format."""
    return FORMAT_MARKET_TYPES.get(data_format, MarketType.UNKNOWN)

# Field mapping configurations for each format
FORMAT_SCHEMAS = {
    DataFormat.BINANCE_OHLCV: {
        "detectors": ["candles"],
        "candles_path": "candles",
        "fields": {
            "timestamp": {"index": 0, "type": "timestamp_ms"},
            "open": {"index": 1, "type": "float"},
            "high": {"index": 2, "type": "float"},
            "low": {"index": 3, "type": "float"},
            "close": {"index": 4, "type": "float"},
            "volume": {"index": 5, "type": "float"},
        },
        "symbol_extractor": lambda d: _extract_symbol_from_message(d.get("message", "")),
    },
    # Multi-ticker: root must include a non-empty "tickers" list (see detect_data_format).
    DataFormat.BINANCE_TICKERS: {
        "detectors": ["tickers"],
        "candles_path": None,
        "is_tickers": True,
        "fields": {
            "symbol": {"key": "symbol", "type": "string"},
            "last": {"key": "last", "type": "float"},
            "bid": {"key": "bid", "type": "float"},
            "ask": {"key": "ask", "type": "float"},
            "high": {"key": "high", "type": "float"},
            "low": {"key": "low", "type": "float"},
            "volume": {"key": "volume", "type": "float"},
            "quote_volume": {"key": "quoteVolume", "type": "float"},
        },
    },
    # Single ticker: top-level symbol + last (Seamflux fetchTicker-style), no tickers array.
    DataFormat.BINANCE_TICKER: {
        "detectors": ["symbol", "last"],
        "candles_path": None,
        "is_tickers": True,
        "fields": {
            "symbol": {"key": "symbol", "type": "string"},
            "last": {"key": "last", "type": "float"},
            "bid": {"key": "bid", "type": "float"},
            "ask": {"key": "ask", "type": "float"},
            "high": {"key": "high", "type": "float"},
            "low": {"key": "low", "type": "float"},
            "volume": {"key": "volume", "type": "float"},
            "quote_volume": {"key": "quoteVolume", "type": "float"},
        },
    },
    DataFormat.POLYMARKET_PRICE_HISTORY: {
        "detectors": ["history"],
        "candles_path": "history",
        "fields": {
            "timestamp": {"key": "t", "type": "timestamp_sec"},
            "price": {"key": "p", "type": "float"},
        },
        "needs_ohlcv_synthesis": True,
        "synthesis_interval": "5min",  # Default interval for OHLCV synthesis
        "symbol_extractor": lambda d: _extract_polymarket_symbol(d),
    },
    DataFormat.POLYMARKET_MARKET: {
        "detectors": ["outcomePrices", "clobTokenIds", "question"],
        "is_market_snapshot": True,
        "fields": {
            "question": {"key": "question", "type": "string"},
            "outcome_prices": {"key": "outcomePrices", "type": "list"},
            "volume": {"key": "volumeNum", "type": "float"},
            "liquidity": {"key": "liquidityNum", "type": "float"},
        },
    },
    DataFormat.GENERIC_OHLCV: {
        "detectors": ["data", "open", "high", "low", "close"],
        "candles_path": "data",
        "fields": {
            "timestamp": {"key": "time", "type": "timestamp_ms"},
            "open": {"key": "open", "type": "float"},
            "high": {"key": "high", "type": "float"},
            "low": {"key": "low", "type": "float"},
            "close": {"key": "close", "type": "float"},
            "volume": {"key": "volume", "type": "float"},
        },
    },
    DataFormat.GENERIC_PRICE_HISTORY: {
        "detectors": ["prices", "timestamp", "price"],
        "candles_path": "prices",
        "fields": {
            "timestamp": {"key": "timestamp", "type": "timestamp_ms"},
            "price": {"key": "price", "type": "float"},
        },
        "needs_ohlcv_synthesis": True,
        "synthesis_interval": "1h",
    },
    DataFormat.UNISWAP_CANDLES: {
        "detectors": ["poolDayData", "date", "liquidity"],
        "candles_path": "poolDayData",
        "fields": {
            "timestamp": {"key": "date", "type": "timestamp_sec"},
            "open": {"key": "open", "type": "float"},
            "high": {"key": "high", "type": "float"},
            "low": {"key": "low", "type": "float"},
            "close": {"key": "close", "type": "float"},
            "volume": {"key": "volumeUSD", "type": "float"},
        },
    },
}


def _extract_symbol_from_message(message: str) -> Optional[str]:
    """Extract symbol from seamflux message."""
    if not message:
        return None
    parts = message.split()
    for i, part in enumerate(parts):
        if part == "for" and i + 1 < len(parts):
            return parts[i + 1]
    return None


def _extract_polymarket_symbol(data: Dict) -> Optional[str]:
    """Extract symbol from Polymarket data."""
    # Try to get from message
    message = data.get("message", "")
    symbol = _extract_symbol_from_message(message)
    if symbol:
        return symbol
    
    # Try to get from question
    question = data.get("question", "")
    if question:
        # Create a slug from question
        return question.lower().replace(" ", "-")[:50]
    
    # Try to get from market data
    if "id" in data:
        return data["id"]
    
    return None


def detect_data_format(data: Dict[str, Any]) -> DataFormat:
    """
    Auto-detect data format based on content.
    
    Detection priority:
    1. Check for specific format signatures
    2. Score each format based on field matches
    3. Return best match
    """
    if not isinstance(data, dict):
        return DataFormat.UNKNOWN
    
    data_keys = set(data.keys())

    # Prefer multi-ticker when a non-empty Binance-style list is present (avoids misclassifying as single ticker).
    tickers_raw = data.get("tickers")
    if isinstance(tickers_raw, list) and len(tickers_raw) > 0:
        return DataFormat.BINANCE_TICKERS
    
    # Score each format
    scores = {}
    for fmt, schema in FORMAT_SCHEMAS.items():
        # Multi-ticker format only when list has rows (empty [] should fall through to single-ticker, etc.)
        if fmt == DataFormat.BINANCE_TICKERS:
            tr = data.get("tickers")
            if not (isinstance(tr, list) and len(tr) > 0):
                continue
        detectors = set(schema.get("detectors", []))
        if detectors:
            # Calculate match score
            matches = len(detectors & data_keys)
            if matches > 0:
                scores[fmt] = matches / len(detectors)
    
    if not scores:
        return DataFormat.UNKNOWN
    
    # Return format with highest score
    best_format = max(scores, key=scores.get)
    
    # Only accept if score is good enough
    if scores[best_format] >= 0.5:
        return best_format
    
    return DataFormat.UNKNOWN


def _convert_value(value: Any, type_hint: str) -> Any:
    """Convert value to target type."""
    if value is None:
        return None
    
    try:
        if type_hint == "float":
            return float(value)
        elif type_hint == "int":
            return int(float(value))
        elif type_hint == "string":
            return str(value)
        elif type_hint == "timestamp_ms":
            ts = int(float(value))
            return pd.to_datetime(ts, unit='ms')
        elif type_hint == "timestamp_sec":
            ts = int(float(value))
            return pd.to_datetime(ts, unit='s')
        elif type_hint == "list":
            return list(value) if isinstance(value, (list, tuple)) else [value]
        else:
            return value
    except (ValueError, TypeError):
        return None


def _synthesize_ohlcv_from_prices(
    df: pd.DataFrame, 
    price_col: str = "price",
    timestamp_col: str = "timestamp",
    interval: str = "5min"
) -> pd.DataFrame:
    """
    Synthesize OHLCV data from price history.
    
    Polymarket and other sources may only provide price points.
    We resample them into OHLCV candles.
    """
    if timestamp_col in df.columns and df.index.name != timestamp_col:
        df = df.set_index(timestamp_col)
    
    # Ensure sorted
    df = df.sort_index()
    
    # Resample to OHLCV
    resampled = df[price_col].resample(interval).ohlc()
    
    # Add volume (count of trades in interval)
    resampled['volume'] = df[price_col].resample(interval).count()
    
    # Rename to standard OHLCV format
    resampled.columns = ['open', 'high', 'low', 'close', 'volume']
    
    # Drop empty intervals
    resampled = resampled.dropna()
    
    return resampled


def parse_binance_ohlcv(data: Dict[str, Any]) -> tuple[pd.DataFrame, Dict[str, Any]]:
    """Parse Binance OHLCV format."""
    candles = data.get("candles", [])
    
    if not candles:
        raise ValueError("No candles data found")
    
    df = pd.DataFrame(candles, columns=[
        'timestamp', 'open', 'high', 'low', 'close', 'volume',
        'close_time', 'quote_volume', 'trades', 'taker_buy_volume',
        'taker_buy_quote_volume', 'ignore'
    ])
    
    # Convert types
    for col in ['open', 'high', 'low', 'close', 'volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    df.set_index('timestamp', inplace=True)
    
    symbol = _extract_symbol_from_message(data.get("message", ""))
    
    metadata = {
        'type': 'ohlcv',
        'format': DataFormat.BINANCE_OHLCV.value,
        'market_type': get_market_type(DataFormat.BINANCE_OHLCV).value,
        'symbol': symbol,
        'bars': len(df),
        'start': df.index[0].isoformat() if len(df) > 0 else None,
        'end': df.index[-1].isoformat() if len(df) > 0 else None,
    }
    
    return df, metadata


def parse_binance_tickers(data: Dict[str, Any]) -> tuple[pd.DataFrame, Dict[str, Any]]:
    """Parse Binance tickers format."""
    tickers = data.get("tickers", [])
    
    if not tickers:
        raise ValueError("No tickers data found")
    
    df = pd.DataFrame(tickers)
    
    # Convert numeric columns
    numeric_cols = ['last', 'bid', 'ask', 'high', 'low', 'volume', 'quoteVolume']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')

    # Strategies and backtest expect a close column
    if 'last' in df.columns and 'close' not in df.columns:
        df['close'] = df['last']
    
    metadata = {
        'type': 'tickers',
        'format': DataFormat.BINANCE_TICKERS.value,
        'market_type': get_market_type(DataFormat.BINANCE_TICKERS).value,
        'count': len(df),
        'symbols': df['symbol'].tolist() if 'symbol' in df.columns else [],
    }
    
    return df, metadata


def parse_binance_single_ticker(data: Dict[str, Any]) -> tuple[pd.DataFrame, Dict[str, Any]]:
    """Parse single Binance / exchange ticker (top-level symbol, last, optional book fields)."""
    symbol = data.get("symbol")
    last = data.get("last")
    if symbol is None or last is None:
        raise ValueError("Single ticker data requires 'symbol' and 'last'")

    row = {
        "symbol": symbol,
        "last": last,
        "bid": data.get("bid"),
        "ask": data.get("ask"),
        "high": data.get("high"),
        "low": data.get("low"),
        "volume": data.get("volume"),
        "quoteVolume": data.get("quoteVolume"),
    }
    df = pd.DataFrame([row])

    numeric_cols = ["last", "bid", "ask", "high", "low", "volume", "quoteVolume"]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    if "last" in df.columns and "close" not in df.columns:
        df["close"] = df["last"]

    msg_symbol = _extract_symbol_from_message(data.get("message", ""))
    metadata = {
        "type": "ticker",
        "format": DataFormat.BINANCE_TICKER.value,
        "market_type": get_market_type(DataFormat.BINANCE_TICKER).value,
        "count": 1,
        "symbol": symbol or msg_symbol,
        "symbols": [symbol] if symbol else [],
    }

    return df, metadata


def parse_polymarket_price_history(data: Dict[str, Any]) -> tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Parse Polymarket price history and synthesize OHLCV.
    
    Polymarket provides: [{t: timestamp, p: price}, ...]
    We convert to OHLCV for strategy compatibility.
    """
    history = data.get("history", [])
    
    if not history:
        raise ValueError("No price history found")
    
    # Parse to DataFrame
    records = []
    for point in history:
        records.append({
            'timestamp': pd.to_datetime(point['t'], unit='s'),
            'price': float(point['p']),
        })
    
    df_prices = pd.DataFrame(records)
    df_prices.set_index('timestamp', inplace=True)
    df_prices = df_prices.sort_index()
    
    # Synthesize OHLCV (use 1 hour intervals by default)
    # Auto-detect interval based on data density
    if len(df_prices) >= 2:
        avg_interval = (df_prices.index[-1] - df_prices.index[0]).total_seconds() / (len(df_prices) - 1)
        if avg_interval < 300:  # Less than 5 min
            interval = '1min'
        elif avg_interval < 1800:  # Less than 30 min
            interval = '5min'
        elif avg_interval < 7200:  # Less than 2 hours
            interval = '1h'
        else:
            interval = '1d'
    else:
        interval = '1h'
    
    df_ohlcv = _synthesize_ohlcv_from_prices(df_prices, interval=interval)
    
    symbol = _extract_polymarket_symbol(data)
    time_range = data.get("timeRange", {})
    
    metadata = {
        'type': 'ohlcv',
        'format': DataFormat.POLYMARKET_PRICE_HISTORY.value,
        'market_type': get_market_type(DataFormat.POLYMARKET_PRICE_HISTORY).value,
        'symbol': symbol,
        'bars': len(df_ohlcv),
        'start': df_ohlcv.index[0].isoformat() if len(df_ohlcv) > 0 else None,
        'end': df_ohlcv.index[-1].isoformat() if len(df_ohlcv) > 0 else None,
        'synthesized': True,
        'original_points': len(df_prices),
        'interval': interval,
        'timeRange': time_range,
    }
    
    return df_ohlcv, metadata


def parse_polymarket_market(data: Dict[str, Any]) -> tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Parse Polymarket market snapshot.
    
    Returns a single-row DataFrame with current market state.
    """
    outcomes = data.get("outcomes", [])
    outcome_prices = data.get("outcomePrices", [])
    
    # Create a single-row DataFrame
    def _safe_float(v: Any) -> Optional[float]:
        if v is None:
            return None
        try:
            return float(v)
        except (TypeError, ValueError):
            return None

    first_price = outcome_prices[0] if outcome_prices else None
    row = {
        'symbol': data.get("slug") or data.get("id"),
        'question': data.get("question"),
        'close': _safe_float(first_price),
        'volume': data.get("volumeNum"),
        'liquidity': data.get("liquidityNum"),
    }
    
    df = pd.DataFrame([row])
    
    metadata = {
        'type': 'market_snapshot',
        'format': DataFormat.POLYMARKET_MARKET.value,
        'market_type': get_market_type(DataFormat.POLYMARKET_MARKET).value,
        'symbol': row['symbol'],
        'question': row['question'],
        'outcomes': outcomes,
        'outcomePrices': outcome_prices,
    }
    
    return df, metadata


def parse_generic_ohlcv(data: Dict[str, Any]) -> tuple[pd.DataFrame, Dict[str, Any]]:
    """Parse generic OHLCV format."""
    candles = data.get("data", [])
    
    if not candles:
        raise ValueError("No data found")
    
    df = pd.DataFrame(candles)
    
    # Standard column mapping
    column_map = {
        'time': 'timestamp',
        'Time': 'timestamp',
        'TIME': 'timestamp',
    }
    df = df.rename(columns=column_map)
    
    # Convert timestamp
    if 'timestamp' in df.columns:
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms', errors='coerce')
        df.set_index('timestamp', inplace=True)
    
    # Convert numeric
    for col in ['open', 'high', 'low', 'close', 'volume']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    metadata = {
        'type': 'ohlcv',
        'format': DataFormat.GENERIC_OHLCV.value,
        'market_type': get_market_type(DataFormat.GENERIC_OHLCV).value,
        'bars': len(df),
        'start': df.index[0].isoformat() if len(df) > 0 else None,
        'end': df.index[-1].isoformat() if len(df) > 0 else None,
    }
    
    return df, metadata


def parse_generic_price_history(data: Dict[str, Any]) -> tuple[pd.DataFrame, Dict[str, Any]]:
    """Parse generic price history and synthesize OHLCV."""
    prices = data.get("prices", [])
    
    if not prices:
        raise ValueError("No prices found")
    
    df = pd.DataFrame(prices)
    
    # Convert timestamp
    if 'timestamp' in df.columns:
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms', errors='coerce')
        df.set_index('timestamp', inplace=True)
    
    # Convert price
    if 'price' in df.columns:
        df['price'] = pd.to_numeric(df['price'], errors='coerce')
    
    df = df.sort_index()
    
    # Synthesize OHLCV
    df_ohlcv = _synthesize_ohlcv_from_prices(df, interval='1h')
    
    metadata = {
        'type': 'ohlcv',
        'format': DataFormat.GENERIC_PRICE_HISTORY.value,
        'market_type': get_market_type(DataFormat.GENERIC_PRICE_HISTORY).value,
        'bars': len(df_ohlcv),
        'synthesized': True,
        'original_points': len(df),
        'start': df_ohlcv.index[0].isoformat() if len(df_ohlcv) > 0 else None,
        'end': df_ohlcv.index[-1].isoformat() if len(df_ohlcv) > 0 else None,
    }
    
    return df_ohlcv, metadata


def parse_uniswap_candles(data: Dict[str, Any]) -> tuple[pd.DataFrame, Dict[str, Any]]:
    """Parse Uniswap/TheGraph pool day data."""
    pool_data = data.get("poolDayData", [])
    
    if not pool_data:
        raise ValueError("No pool data found")
    
    df = pd.DataFrame(pool_data)
    
    # Convert types
    df['date'] = pd.to_datetime(df['date'], unit='s', errors='coerce')
    df.set_index('date', inplace=True)
    
    for col in ['open', 'high', 'low', 'close', 'volumeUSD']:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    # Rename volume
    if 'volumeUSD' in df.columns:
        df['volume'] = df['volumeUSD']
    
    metadata = {
        'type': 'ohlcv',
        'format': DataFormat.UNISWAP_CANDLES.value,
        'market_type': get_market_type(DataFormat.UNISWAP_CANDLES).value,
        'bars': len(df),
        'start': df.index[0].isoformat() if len(df) > 0 else None,
        'end': df.index[-1].isoformat() if len(df) > 0 else None,
    }
    
    return df, metadata


# Parser registry
PARSERS = {
    DataFormat.BINANCE_OHLCV: parse_binance_ohlcv,
    DataFormat.BINANCE_TICKERS: parse_binance_tickers,
    DataFormat.BINANCE_TICKER: parse_binance_single_ticker,
    DataFormat.POLYMARKET_PRICE_HISTORY: parse_polymarket_price_history,
    DataFormat.POLYMARKET_MARKET: parse_polymarket_market,
    DataFormat.GENERIC_OHLCV: parse_generic_ohlcv,
    DataFormat.GENERIC_PRICE_HISTORY: parse_generic_price_history,
    DataFormat.UNISWAP_CANDLES: parse_uniswap_candles,
}


def adapt_data(data: Dict[str, Any]) -> tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Main entry point: auto-detect format and parse data.
    
    Returns:
        (DataFrame, metadata)
    """
    fmt = detect_data_format(data)
    
    if fmt == DataFormat.UNKNOWN:
        raise ValueError(f"Unknown data format. Keys: {list(data.keys())}")
    
    parser = PARSERS.get(fmt)
    if not parser:
        raise ValueError(f"No parser available for format: {fmt.value}")
    
    return parser(data)


def get_supported_formats() -> List[str]:
    """Get list of supported format names."""
    return [fmt.value for fmt in DataFormat if fmt != DataFormat.UNKNOWN]


def get_formats_by_market_type(market_type: Union[str, MarketType]) -> List[DataFormat]:
    """Get all data formats for a specific market type."""
    if isinstance(market_type, str):
        market_type = MarketType(market_type)
    return [fmt for fmt, mt in FORMAT_MARKET_TYPES.items() if mt == market_type and fmt != DataFormat.UNKNOWN]


def describe_format(fmt_name: str) -> Optional[Dict[str, Any]]:
    """Get description of a data format."""
    try:
        fmt = DataFormat(fmt_name)
        schema = FORMAT_SCHEMAS.get(fmt, {})
        return {
            'name': fmt.value,
            'market_type': get_market_type(fmt).value,
            'detectors': schema.get('detectors', []),
            'supports_ohlcv': not schema.get('is_tickers') and not schema.get('is_market_snapshot'),
        }
    except ValueError:
        return None


def get_market_types() -> List[str]:
    """Get list of all market type values."""
    return [mt.value for mt in MarketType if mt != MarketType.UNKNOWN]
