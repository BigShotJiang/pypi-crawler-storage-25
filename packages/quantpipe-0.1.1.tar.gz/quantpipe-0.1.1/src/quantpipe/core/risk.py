"""Risk management core logic for QuantPipe."""

from __future__ import annotations

import math
from typing import Optional, Sequence


def position_sizing(
    capital: float,
    risk_per_trade: float,
    entry_price: float,
    stop_loss: float,
) -> dict:
    """
    Calculate recommended position size based on risk parameters.

    Args:
        capital: Total trading capital
        risk_per_trade: Risk percentage per trade (e.g., 0.02 for 2%)
        entry_price: Entry price for the position
        stop_loss: Stop-loss price

    Returns:
        Dictionary with position size and related metrics
    """
    if entry_price <= 0 or stop_loss <= 0 or capital <= 0:
        return {
            "position_size": 0.0,
            "shares": 0,
            "dollar_risk": 0.0,
            "risk_reward_ratio": None,
        }

    risk_amount = capital * risk_per_trade
    price_risk = abs(entry_price - stop_loss)

    if price_risk == 0:
        return {
            "position_size": 0.0,
            "shares": 0,
            "dollar_risk": 0.0,
            "risk_reward_ratio": None,
        }

    if stop_loss < entry_price:
        risk_per_share = entry_price - stop_loss
    else:
        risk_per_share = stop_loss - entry_price

    shares = risk_amount / risk_per_share
    actual_position_value = shares * entry_price
    leverage = actual_position_value / capital if capital > 0 else 0

    return {
        "position_size": actual_position_value,
        "shares": math.floor(shares),
        "dollar_risk": risk_amount,
        "risk_per_share": risk_per_share,
        "leverage": round(leverage, 2),
    }


def calculate_var(
    returns: Sequence[float],
    confidence: float = 0.95,
) -> float:
    """
    Calculate Value at Risk (VaR) from a sequence of returns.

    Args:
        returns: Sequence of return values (e.g., [0.02, -0.01, 0.03])
        confidence: Confidence level (e.g., 0.95 for 95%)

    Returns:
        VaR as a positive number representing potential loss
    """
    if not returns:
        return 0.0

    sorted_returns = sorted(returns)
    n = len(sorted_returns)
    idx = int((1 - confidence) * n)

    if idx >= n:
        idx = n - 1
    if idx < 0:
        idx = 0

    var = abs(sorted_returns[idx])
    return round(var, 6)


def calculate_cvar(
    returns: Sequence[float],
    confidence: float = 0.95,
) -> float:
    """
    Calculate Conditional Value at Risk (CVaR / Expected Shortfall).

    Args:
        returns: Sequence of return values
        confidence: Confidence level

    Returns:
        CVaR as a positive number representing expected loss in worst cases
    """
    if not returns:
        return 0.0

    sorted_returns = sorted(returns)
    n = len(sorted_returns)
    var_idx = int((1 - confidence) * n)

    if var_idx >= n:
        var_idx = n - 1
    if var_idx < 0:
        var_idx = 0

    tail_losses = [abs(r) for r in sorted_returns[:var_idx + 1]]
    if not tail_losses:
        return 0.0

    cvar = sum(tail_losses) / len(tail_losses)
    return round(cvar, 6)


def kelly_criterion(
    win_rate: float,
    avg_win: float,
    avg_loss: float,
) -> float:
    """
    Calculate Kelly Criterion for optimal bet sizing.

    Args:
        win_rate: Win probability (0 to 1)
        avg_win: Average winning amount
        avg_loss: Average losing amount (positive number)

    Returns:
        Optimal position size as fraction of capital (0 to 1)
    """
    if avg_loss <= 0 or win_rate <= 0 or win_rate >= 1:
        return 0.0

    win_loss_ratio = avg_win / avg_loss
    kelly = (win_rate * win_loss_ratio - (1 - win_rate)) / win_loss_ratio

    return max(0.0, min(kelly, 1.0))


def calculate_risk_reward(
    entry_price: float,
    target_price: float,
    stop_loss: float,
) -> Optional[float]:
    """
    Calculate risk-reward ratio.

    Args:
        entry_price: Position entry price
        target_price: Profit target price
        stop_loss: Stop-loss price

    Returns:
        Risk-reward ratio or None if calculation is not possible
    """
    risk = abs(entry_price - stop_loss)
    reward = abs(target_price - entry_price)

    if risk == 0:
        return None

    return round(reward / risk, 2)


def ruin_probability(
    win_rate: float,
    risk_reward: float,
    num_trades: int,
) -> float:
    """
    Estimate probability of ruin using simplified model.

    Args:
        win_rate: Win probability (0 to 1)
        risk_reward: Risk-reward ratio
        num_trades: Number of trades to simulate

    Returns:
        Estimated probability of losing all capital
    """
    if win_rate <= 0 or risk_reward <= 0:
        return 1.0
    if win_rate >= 1:
        return 0.0  # 100% win rate means no ruin possible

    p = win_rate
    q = 1 - win_rate
    b = risk_reward

    if b == 1:
        if p <= q:
            return 1.0
        ratio = q / p
        return ratio ** num_trades

    log_base = p * (1 + b) + q
    if log_base <= 0:
        return 1.0

    try:
        log_qp = math.log(q / p)
        log_b = math.log(b)
        if log_qp == 0 or log_b == 0:
            return 1.0

        exponent = log_qp / log_b
        if exponent <= 0:
            return 1.0

        ruin = ((q / p) ** exponent) / ((1 + b) ** exponent)
        return max(0.0, min(ruin, 1.0))
    except (ValueError, ZeroDivisionError):
        return 1.0


def calculate_atr_position_size(
    capital: float,
    risk_per_trade: float,
    entry_price: float,
    atr: float,
    atr_multiplier: float = 2.0,
) -> dict:
    """
    Calculate position size using ATR-based stop loss.

    Args:
        capital: Total trading capital
        risk_per_trade: Risk percentage per trade
        entry_price: Entry price
        atr: Average True Range value
        atr_multiplier: Multiplier for ATR stop distance (default 2.0)

    Returns:
        Dictionary with position size and stop-loss price
    """
    risk_amount = capital * risk_per_trade
    stop_distance = atr * atr_multiplier

    if stop_distance == 0:
        return {
            "position_size": 0.0,
            "shares": 0,
            "dollar_risk": risk_amount,
            "stop_loss": None,
            "atr_multiplier": atr_multiplier,
        }

    shares = risk_amount / stop_distance
    position_value = shares * entry_price

    return {
        "position_size": position_value,
        "shares": math.floor(shares),
        "dollar_risk": risk_amount,
        "stop_loss": round(entry_price - stop_distance, 4),
        "atr_multiplier": atr_multiplier,
        "stop_distance": round(stop_distance, 4),
    }
