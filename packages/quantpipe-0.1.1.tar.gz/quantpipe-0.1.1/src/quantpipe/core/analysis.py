"""Analysis functions for QuantPipe: Monte Carlo, Walk-forward, Regime Detection."""

from __future__ import annotations

import random
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


def monte_carlo_simulation(
    trades_pnl: List[float],
    n_simulations: int = 1000,
    initial_capital: float = 10000.0,
    seed: Optional[int] = None,
) -> Dict[str, Any]:
    """Run Monte Carlo simulation on trade PnL sequence.
    
    Randomly samples trade returns to generate distribution of possible outcomes.
    
    Args:
        trades_pnl: List of trade PnL values (as decimals, e.g., 0.05 for 5%)
        n_simulations: Number of simulation runs
        initial_capital: Starting capital
        seed: Random seed for reproducibility
    
    Returns:
        Dictionary with simulation statistics
    """
    if seed is not None:
        random.seed(seed)
        np.random.seed(seed)
    
    if not trades_pnl:
        return {
            'n_simulations': n_simulations,
            'n_trades': 0,
            'final_equity': {'mean': initial_capital, 'median': initial_capital, 'std': 0},
            'max_drawdown': {'mean': 0, 'median': 0, 'std': 0},
            'ruin_probability': 0,
            'percentiles': {'10': initial_capital, '50': initial_capital, '90': initial_capital},
        }
    
    n_trades = len(trades_pnl)
    trades_arr = np.array(trades_pnl)
    
    final_equities = []
    max_drawdowns = []
    ruin_count = 0
    
    for _ in range(n_simulations):
        # Shuffle trades to simulate different order
        shuffled = trades_arr.copy()
        random.shuffle(shuffled)
        
        # Simulate equity curve
        equity = initial_capital
        equity_curve = [equity]
        peak = equity
        
        for pnl_pct in shuffled:
            equity *= (1 + pnl_pct)
            equity_curve.append(equity)
            if equity > peak:
                peak = equity
            else:
                dd = (peak - equity) / peak
                peak = equity
        
        final_equities.append(equity)
        
        # Calculate max drawdown for this simulation
        eq_series = np.array(equity_curve)
        running_max = np.maximum.accumulate(eq_series)
        drawdowns = (running_max - eq_series) / running_max
        max_drawdowns.append(np.max(drawdowns))
        
        if equity < initial_capital * 0.5:
            ruin_count += 1
    
    final_equities = np.array(final_equities)
    max_drawdowns = np.array(max_drawdowns)
    
    return {
        'n_simulations': n_simulations,
        'n_trades': n_trades,
        'initial_capital': initial_capital,
        'final_equity': {
            'mean': round(float(np.mean(final_equities)), 2),
            'median': round(float(np.median(final_equities)), 2),
            'std': round(float(np.std(final_equities)), 2),
            'min': round(float(np.min(final_equities)), 2),
            'max': round(float(np.max(final_equities)), 2),
        },
        'max_drawdown': {
            'mean': round(float(np.mean(max_drawdowns)), 4),
            'median': round(float(np.median(max_drawdowns)), 4),
            'std': round(float(np.std(max_drawdowns)), 4),
        },
        'ruin_probability': round(ruin_count / n_simulations, 4),
        'percentiles': {
            '10': round(float(np.percentile(final_equities, 10)), 2),
            '25': round(float(np.percentile(final_equities, 25)), 2),
            '50': round(float(np.percentile(final_equities, 50)), 2),
            '75': round(float(np.percentile(final_equities, 75)), 2),
            '90': round(float(np.percentile(final_equities, 90)), 2),
        },
    }


def walk_forward_analysis(
    strategy_class,
    df: pd.DataFrame,
    train_ratio: float = 0.7,
    step: int = 30,
    metric: str = 'sharpe_ratio',
) -> Dict[str, Any]:
    """Perform walk-forward analysis with rolling window optimization.
    
    Splits data into training and testing windows, optimizes on training,
    validates on testing. Repeats with rolling windows.
    
    Args:
        strategy_class: Strategy class to analyze
        df: OHLCV DataFrame
        train_ratio: Ratio of data for training (0.0 to 1.0)
        step: Number of bars to step forward each iteration
        metric: Metric to compare ('sharpe_ratio', 'total_return', 'win_rate')
    
    Returns:
        Dictionary with walk-forward results
    """
    n = len(df)
    window_size = max(100, int(n * 0.3))  # At least 30% or 100 bars
    train_size = int(window_size * train_ratio)
    
    if n < window_size * 2:
        return {
            'error': 'Insufficient data for walk-forward analysis',
            'min_required': window_size * 2,
            'available': n,
        }
    
    results = []
    in_sample_metrics = []
    out_sample_metrics = []
    
    i = 0
    fold = 0
    
    while i + window_size < n:
        train_end = i + train_size
        test_end = min(i + window_size, n)
        
        train_df = df.iloc[i:train_end]
        test_df = df.iloc[train_end:test_end]
        
        if len(test_df) < 30:
            break
        
        # Get parameter ranges for optimization
        default_params = strategy_class.default_params
        param_ranges = {}
        
        for param_name, default_value in default_params.items():
            if isinstance(default_value, int):
                param_ranges[param_name] = list(range(max(2, default_value - 5), default_value + 10))
            elif isinstance(default_value, float):
                param_ranges[param_name] = [default_value * 0.8, default_value, default_value * 1.2]
        
        # Grid search on training data
        best_metric = float('-inf')
        best_params = default_params.copy()
        
        from ..strategies import STRATEGIES
        import itertools
        
        param_names = list(param_ranges.keys())
        param_values = [param_ranges[name] for name in param_names]
        
        for combo in itertools.product(*param_values):
            params = dict(zip(param_names, combo))
            try:
                from .backtest import BacktestEngine
                strategy = strategy_class(params=params)
                engine = BacktestEngine(strategy, train_df)
                metrics = engine.run()
                
                metric_value = metrics.get(metric, 0)
                if metric_value > best_metric:
                    best_metric = metric_value
                    best_params = params
            except Exception:
                continue
        
        # Evaluate best params on training (in-sample)
        in_sample_strategy = strategy_class(params=best_params)
        in_sample_engine = BacktestEngine(in_sample_strategy, train_df)
        in_sample_metrics_dict = in_sample_engine.run()
        in_sample = in_sample_metrics_dict.get(metric, 0)
        
        # Evaluate best params on test (out-of-sample)
        out_sample_strategy = strategy_class(params=best_params)
        out_sample_engine = BacktestEngine(out_sample_strategy, test_df)
        out_sample_metrics_dict = out_sample_engine.run()
        out_sample = out_sample_metrics_dict.get(metric, 0)
        
        results.append({
            'fold': fold,
            'train_start': train_df.index[0].isoformat() if len(train_df) > 0 else None,
            'train_end': train_df.index[-1].isoformat() if len(train_df) > 0 else None,
            'test_start': test_df.index[0].isoformat() if len(test_df) > 0 else None,
            'test_end': test_df.index[-1].isoformat() if len(test_df) > 0 else None,
            'best_params': best_params,
            'in_sample': round(in_sample, 4),
            'out_sample': round(out_sample, 4),
            'train_trades': in_sample_metrics_dict.get('total_trades', 0),
            'test_trades': out_sample_metrics_dict.get('total_trades', 0),
        })
        
        in_sample_metrics.append(in_sample)
        out_sample_metrics.append(out_sample)
        
        i += step
        fold += 1
    
    if not results:
        return {'error': 'No valid walk-forward windows'}
    
    return {
        'n_folds': len(results),
        'window_size': window_size,
        'train_size': train_size,
        'step': step,
        'metric': metric,
        'in_sample': {
            'mean': round(np.mean(in_sample_metrics), 4),
            'std': round(np.std(in_sample_metrics), 4),
        },
        'out_sample': {
            'mean': round(np.mean(out_sample_metrics), 4),
            'std': round(np.std(out_sample_metrics), 4),
        },
        'sample_decay': round(np.mean(in_sample_metrics) - np.mean(out_sample_metrics), 4),
        'roll_rate': round(np.mean(out_sample_metrics) / np.mean(in_sample_metrics) if np.mean(in_sample_metrics) != 0 else 0, 4),
        'folds': results,
    }


def detect_regime(
    prices: pd.Series,
    lookback: int = 50,
    volatility_threshold: float = 0.5,
) -> Dict[str, Any]:
    """Detect market regime (bull, bear, or sideways).
    
    Uses a combination of trend direction and volatility to classify regimes.
    
    Args:
        prices: Series of prices
        lookback: Number of bars to use for regime detection
        volatility_threshold: Threshold for volatility classification (relative to average)
    
    Returns:
        Dictionary with regime classification
    """
    if len(prices) < lookback:
        lookback = max(10, len(prices) // 2)
    
    recent = prices.iloc[-lookback:]
    
    # Calculate returns
    returns = recent.pct_change().dropna()
    
    if len(returns) < 5:
        return {
            'regime': 'unknown',
            'trend': 0,
            'volatility': 0,
            'confidence': 0,
            'lookback': lookback,
        }
    
    # Trend: using linear regression slope
    x = np.arange(len(returns))
    y = returns.values
    slope = np.polyfit(x, y, 1)[0]
    
    # Annualized trend (assuming 252 trading days)
    annualized_trend = slope * 252
    
    # Volatility: annualized standard deviation
    volatility = returns.std() * np.sqrt(252)
    
    # Classify trend
    if annualized_trend > 0.1:  # > 10% annual
        trend_direction = 'bull'
        trend_score = 1
    elif annualized_trend < -0.1:  # < -10% annual
        trend_direction = 'bear'
        trend_score = -1
    else:
        trend_direction = 'sideways'
        trend_score = 0
    
    # Classify volatility
    avg_volatility = prices.pct_change().std() * np.sqrt(252)
    vol_ratio = volatility / avg_volatility if avg_volatility > 0 else 1
    
    if vol_ratio > volatility_threshold:
        vol_class = 'high'
    elif vol_ratio < 1 / volatility_threshold:
        vol_class = 'low'
    else:
        vol_class = 'normal'
    
    # Combined regime
    if trend_direction == 'bull' and vol_class == 'high':
        regime = 'bull_high_vol'
    elif trend_direction == 'bull' and vol_class in ('normal', 'low'):
        regime = 'bull_low_vol'
    elif trend_direction == 'bear' and vol_class == 'high':
        regime = 'bear_high_vol'
    elif trend_direction == 'bear' and vol_class in ('normal', 'low'):
        regime = 'bear_low_vol'
    elif trend_direction == 'sideways' and vol_class == 'high':
        regime = 'sideways_high_vol'
    else:
        regime = 'sideways'
    
    # Confidence based on consistency of trend
    positive_returns = (returns > 0).sum() / len(returns)
    
    return {
        'regime': regime,
        'trend': trend_direction,
        'trend_score': round(trend_score, 2),
        'annualized_trend_pct': round(annualized_trend * 100, 2),
        'volatility': vol_class,
        'volatility_ratio': round(vol_ratio, 2),
        'trend_consistency': round(positive_returns, 2),
        'confidence': round(min(abs(slope) * 100 + positive_returns * 20, 1.0), 2),
        'lookback': lookback,
    }
