"""Strategy base class for QuantPipe."""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from dataclasses import dataclass

import pandas as pd

from ..types import Signal, SignalAction


@dataclass
class StrategyParams:
    """Base strategy parameters."""
    pass


class Strategy(ABC):
    """Base strategy class."""
    
    name: str = "base"
    default_params: Dict[str, Any] = {}
    
    def __init__(self, params: Optional[Dict[str, Any]] = None):
        """Initialize strategy with parameters."""
        self.params = {**self.default_params, **(params or {})}
        self._indicators: Dict[str, Any] = {}
    
    def init(self, df: pd.DataFrame) -> None:
        """Initialize strategy with data. Calculate indicators here."""
        pass
    
    @abstractmethod
    def next(self, df: pd.DataFrame) -> SignalAction:
        """Generate signal for the latest data point."""
        pass
    
    def get_indicators(self) -> Dict[str, Any]:
        """Get current indicator values."""
        return self._indicators
    
    def generate_signal(self, df: pd.DataFrame, metadata: Dict[str, Any]) -> Signal:
        """Generate full signal with metadata."""
        # Always re-initialize to ensure indicators match current data
        self._indicators = {}
        self.init(df)
        
        action = self.next(df)
        
        # Get current price
        current_price = float(df['close'].iloc[-1])
        
        # Get indicators
        indicators = self.get_indicators()
        
        # Calculate confidence (can be overridden by subclasses)
        confidence = self._calculate_confidence(df, action)
        
        # Generate reason
        reason = self._generate_reason(action, indicators)
        
        # Calculate timestamps
        from datetime import datetime, timedelta
        now = datetime.utcnow()
        
        # Calculate TTL based on data frequency
        if len(df) >= 2:
            time_diff = (df.index[-1] - df.index[-2]).total_seconds()
            ttl_seconds = max(time_diff * 2, 60)
        else:
            ttl_seconds = 3600
        
        valid_until = now + timedelta(seconds=ttl_seconds)
        
        return Signal(
            action=action,
            price=current_price,
            confidence=confidence,
            reason=reason,
            indicators=indicators,
            params=self.params.copy(),
            timestamp=now.isoformat() + 'Z',
            valid_until=valid_until.isoformat() + 'Z'
        )
    
    def _calculate_confidence(self, df: pd.DataFrame, action: SignalAction) -> float:
        """Calculate signal confidence (0-1)."""
        return 0.5  # Base implementation
    
    def _generate_reason(self, action: SignalAction, indicators: Dict[str, Any]) -> str:
        """Generate human-readable reason for the signal."""
        return f"{self.name} generated {action} signal"
    
    @classmethod
    def get_param_schema(cls) -> Dict[str, Any]:
        """Get parameter schema for CLI."""
        return {
            name: {"default": value, "type": type(value).__name__}
            for name, value in cls.default_params.items()
        }
