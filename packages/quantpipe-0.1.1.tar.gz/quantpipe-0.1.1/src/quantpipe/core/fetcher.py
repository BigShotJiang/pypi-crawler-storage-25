"""Market data fetcher core logic for QuantPipe."""

from __future__ import annotations

import json
import time
from typing import Any, Dict, List, Literal, Optional

import pandas as pd
import requests

EXCHANGE = Literal["binance", "coinbase", "kraken"]


def fetch_ohlcv(
    exchange: EXCHANGE,
    symbol: str,
    interval: str = "1h",
    start: Optional[str] = None,
    end: Optional[str] = None,
    limit: int = 1000,
) -> pd.DataFrame:
    """
    Fetch OHLCV data from exchange.

    Args:
        exchange: Exchange name (binance, coinbase, kraken)
        symbol: Trading pair symbol (e.g., BTC/USDT or BTCUSDT)
        interval: Candle interval (1m, 5m, 1h, 1d)
        start: Start time in ISO-8601 format
        end: End time in ISO-8601 format
        limit: Max number of candles to fetch

    Returns:
        DataFrame with OHLCV data
    """
    if exchange == "binance":
        return _fetch_binance(symbol, interval, start, end, limit)
    elif exchange == "coinbase":
        return _fetch_coinbase(symbol, interval, start, end, limit)
    elif exchange == "kraken":
        return _fetch_kraken(symbol, interval, start, end, limit)
    else:
        raise ValueError(f"Unsupported exchange: {exchange}")


def _fetch_binance(
    symbol: str,
    interval: str,
    start: Optional[str],
    end: Optional[str],
    limit: int,
) -> pd.DataFrame:
    """Fetch OHLCV from Binance."""
    symbol = symbol.replace("/", "")

    interval_map = {
        "1m": "1m", "5m": "5m", "15m": "15m", "30m": "30m",
        "1h": "1h", "4h": "4h", "6h": "6h", "12h": "12h", "1d": "1d",
    }
    binance_interval = interval_map.get(interval, "1h")

    params: Dict[str, Any] = {
        "symbol": symbol,
        "interval": binance_interval,
        "limit": min(limit, 1000),
    }

    if start:
        params["startTime"] = _parse_timestamp(start)
    if end:
        params["endTime"] = _parse_timestamp(end)

    url = "https://api.binance.com/api/v3/klines"

    rows = []
    while len(rows) < limit:
        fetch_limit = min(limit - len(rows), 1000)
        params["limit"] = fetch_limit

        response = _make_request(url, params)
        if not response:
            break

        rows.extend(response)

        if len(response) < fetch_limit:
            break

        last_time = int(response[-1][0])
        params["startTime"] = last_time + 1

        if len(rows) >= limit:
            break

    return _parse_binance_response(rows)


def _fetch_coinbase(
    symbol: str,
    interval: str,
    start: Optional[str],
    end: Optional[str],
    limit: int,
) -> pd.DataFrame:
    """Fetch OHLCV from Coinbase."""
    granularity_map = {
        "1m": 60, "5m": 300, "15m": 900, "30m": 1800,
        "1h": 3600, "4h": 14400, "1d": 86400,
    }
    granularity = granularity_map.get(interval, 3600)

    params: Dict[str, Any] = {
        "product_id": symbol.replace("/", "-"),
        "granularity": granularity,
    }

    if start:
        params["start"] = start
    if end:
        params["end"] = end

    url = "https://api.exchange.coinbase.com/products"

    candles = _make_request(f"{url}/{symbol.replace('/', '-')}/candles", params)
    if not candles:
        return pd.DataFrame(columns=["timestamp", "open", "high", "low", "close", "volume"])

    rows = [[c[0], c[3], c[2], c[1], c[4], c[5]] for c in candles]
    return _parse_binance_response(rows)


def _fetch_kraken(
    symbol: str,
    interval: str,
    start: Optional[str],
    end: Optional[str],
    limit: int,
) -> pd.DataFrame:
    """Fetch OHLCV from Kraken."""
    interval_map = {
        "1m": 1, "5m": 5, "15m": 15, "30m": 30,
        "1h": 60, "4h": 240, "1d": 1440,
    }
    kraken_interval = interval_map.get(interval, 60)

    params: Dict[str, Any] = {
        "pair": symbol.replace("/", "").replace("BTC", "XBT"),
        "interval": kraken_interval,
    }

    if start:
        params["since"] = _parse_timestamp(start)
    if end:
        params["until"] = _parse_timestamp(end)

    url = "https://api.kraken.com/0/public/OHLC"
    response = _make_request(url, params)

    if not response or "error" in response and response["error"]:
        return pd.DataFrame(columns=["timestamp", "open", "high", "low", "close", "volume"])

    pair_name = list(response.get("result", {}).keys())[0]
    candles = response["result"].get(pair_name, [])

    rows = [[int(c[0]), float(c[1]), float(c[3]), float(c[2]), float(c[4]), float(c[6])]
            for c in candles]

    return _parse_binance_response(rows)


def _make_request(url: str, params: Dict[str, Any], retries: int = 3) -> Any:
    """Make HTTP request with retries."""
    for attempt in range(retries):
        try:
            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            if attempt < retries - 1:
                time.sleep(1 * (attempt + 1))
            else:
                raise RuntimeError(f"Request failed: {e}")
    return None


def _parse_timestamp(ts: str) -> int:
    """Parse timestamp to milliseconds."""
    from datetime import datetime, timezone

    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        return int(dt.timestamp() * 1000)
    except ValueError:
        return int(float(ts) * 1000)


def _parse_binance_response(rows: List[List[Any]]) -> pd.DataFrame:
    """Parse Binance-style OHLCV response into DataFrame."""
    if not rows:
        return pd.DataFrame(columns=["timestamp", "open", "high", "low", "close", "volume"])

    df = pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume", "close_time", "quote_volume", "trades", "taker_buy_base", "taker_buy_quote", "ignore"])

    df["timestamp"] = pd.to_numeric(df["timestamp"], errors="coerce")
    df["open"] = pd.to_numeric(df["open"], errors="coerce")
    df["high"] = pd.to_numeric(df["high"], errors="coerce")
    df["low"] = pd.to_numeric(df["low"], errors="coerce")
    df["close"] = pd.to_numeric(df["close"], errors="coerce")
    df["volume"] = pd.to_numeric(df["volume"], errors="coerce")

    df = df[["timestamp", "open", "high", "low", "close", "volume"]]

    return df


def ohlcv_to_dict(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Convert OHLCV DataFrame to list of dictionaries."""
    records = df.to_dict(orient="records")
    for r in records:
        if "timestamp" in r:
            r["timestamp"] = int(r["timestamp"])
    return records


def ohlcv_to_json_output(df: pd.DataFrame, symbol: str, exchange: str, interval: str) -> Dict[str, Any]:
    """Format OHLCV DataFrame as seamflux-compatible JSON output."""
    candles = ohlcv_to_dict(df)

    return {
        "schemaVersion": 1,
        "tool": "quantpipe",
        "command": "fetch",
        "ok": True,
        "data": {
            "symbol": symbol,
            "exchange": exchange,
            "interval": interval,
            "bars": len(df),
            "candles": candles,
        },
    }
