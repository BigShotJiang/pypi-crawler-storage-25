"""Portfolio analysis core logic for QuantPipe."""

from __future__ import annotations

import math
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def calculate_portfolio_metrics(
    trades_list: List[pd.DataFrame],
    weights: Optional[List[float]] = None,
    risk_free: float = 0.02,
) -> dict:
    """
    Calculate combined portfolio metrics from multiple strategy trades.

    Args:
        trades_list: List of DataFrames with trade data (must have 'pnl_pct' or 'pnl' column)
        weights: Optional weights for each strategy (must sum to 1.0)
        risk_free: Risk-free rate for Sharpe ratio calculation (default: 0.02)

    Returns:
        Dictionary with portfolio-level metrics
    """
    if not trades_list:
        return {}

    n = len(trades_list)
    if weights is None:
        weights = [1.0 / n] * n
    elif len(weights) != n:
        raise ValueError("Number of weights must match number of trades")

    total_weight = sum(weights)
    if abs(total_weight - 1.0) > 0.001:
        weights = [w / total_weight for w in weights]

    combined_returns = _calculate_weighted_returns(trades_list, weights)

    total_return = sum(
        _total_return_from_trades(df) * w
        for df, w in zip(trades_list, weights)
    )

    annual_return = _annualized_return(combined_returns)
    sharpe = sharpe_ratio(combined_returns, risk_free)
    sortino = sortino_ratio(combined_returns, risk_free)
    max_dd = max_drawdown(combined_returns)
    calmar = calmar_ratio(annual_return, max_dd)

    return {
        "total_return": round(total_return, 6),
        "annualized_return": round(annual_return, 6),
        "sharpe_ratio": round(sharpe, 4),
        "sortino_ratio": round(sortino, 4),
        "max_drawdown": round(max_dd, 6),
        "calmar_ratio": round(calmar, 4),
        "weights": weights,
    }


def _calculate_weighted_returns(
    trades_list: List[pd.DataFrame],
    weights: List[float],
) -> List[float]:
    """Calculate weighted combined returns from all trades."""
    all_returns: List[List[float]] = []

    for df in trades_list:
        if "pnl_pct" in df.columns:
            returns = df["pnl_pct"].dropna().tolist()
        elif "pnl" in df.columns:
            returns = df["pnl"].dropna().tolist()
        else:
            returns = []
        all_returns.append(returns)

    max_len = max(len(r) for r in all_returns) if all_returns else 0
    if max_len == 0:
        return []

    weighted = []
    for i in range(max_len):
        combined = 0.0
        for returns, weight in zip(all_returns, weights):
            if i < len(returns):
                combined += returns[i] * weight
        weighted.append(combined)

    return weighted


def correlation_matrix(trades_list: List[pd.DataFrame]) -> Tuple[pd.DataFrame, List[str]]:
    """
    Calculate correlation matrix between strategies.

    Args:
        trades_list: List of DataFrames with trade data

    Returns:
        Tuple of (correlation DataFrame, strategy names list)
    """
    if not trades_list:
        return pd.DataFrame(), []

    strategy_names = [f"strategy_{i+1}" for i in range(len(trades_list))]
    returns_dict: Dict[str, List[float]] = {name: [] for name in strategy_names}

    max_len = 0
    for df, name in zip(trades_list, strategy_names):
        if "pnl_pct" in df.columns:
            returns_dict[name] = df["pnl_pct"].dropna().tolist()
        elif "pnl" in df.columns:
            returns_dict[name] = df["pnl"].dropna().tolist()
        else:
            returns_dict[name] = []
        max_len = max(max_len, len(returns_dict[name]))

    for name in strategy_names:
        if len(returns_dict[name]) < max_len:
            returns_dict[name] = returns_dict[name] + [0.0] * (max_len - len(returns_dict[name]))

    returns_df = pd.DataFrame(returns_dict)
    corr_matrix = returns_df.corr()

    return corr_matrix, strategy_names


def sharpe_ratio(returns: Sequence[float], risk_free: float = 0.02) -> float:
    """
    Calculate Sharpe ratio from returns.

    Args:
        returns: Sequence of return values
        risk_free: Annual risk-free rate (default: 0.02)

    Returns:
        Sharpe ratio
    """
    if not returns:
        return 0.0

    returns_arr = np.array(returns)
    excess_returns = returns_arr - risk_free / 252

    std = np.std(excess_returns)
    if std == 0:
        return 0.0

    mean_excess = np.mean(excess_returns)
    sharpe = mean_excess / std * math.sqrt(252)

    return float(sharpe)


def sortino_ratio(returns: Sequence[float], risk_free: float = 0.02) -> float:
    """
    Calculate Sortino ratio (uses downside deviation).

    Args:
        returns: Sequence of return values
        risk_free: Annual risk-free rate (default: 0.02)

    Returns:
        Sortino ratio
    """
    if not returns:
        return 0.0

    returns_arr = np.array(returns)
    excess_returns = returns_arr - risk_free / 252

    downside_returns = excess_returns[excess_returns < 0]
    if len(downside_returns) == 0:
        return 0.0

    downside_std = np.std(downside_returns)
    if downside_std == 0:
        return 0.0

    mean_excess = np.mean(excess_returns)
    sortino = mean_excess / downside_std * math.sqrt(252)

    return float(sortino)


def max_drawdown(equity_curve: Sequence[float]) -> float:
    """
    Calculate maximum drawdown from equity curve.

    Args:
        equity_curve: Sequence of equity values

    Returns:
        Maximum drawdown as positive number (e.g., 0.20 for 20% drawdown)
    """
    if not equity_curve:
        return 0.0

    equity_arr = np.array(equity_curve)
    running_max = np.maximum.accumulate(equity_arr)
    drawdowns = (running_max - equity_arr) / running_max

    return float(np.max(drawdowns))


def calmar_ratio(annual_return: float, max_drawdown: float) -> float:
    """
    Calculate Calmar ratio (annual return / max drawdown).

    Args:
        annual_return: Annualized return
        max_drawdown: Maximum drawdown (positive number)

    Returns:
        Calmar ratio
    """
    if max_drawdown == 0:
        return 0.0

    return annual_return / max_drawdown


def _total_return_from_trades(df: pd.DataFrame) -> float:
    """Calculate total return from trades DataFrame."""
    if "pnl_pct" in df.columns:
        return float(df["pnl_pct"].sum())
    elif "pnl" in df.columns:
        return float(df["pnl"].sum())
    return 0.0


def _annualized_return(returns: Sequence[float], periods_per_year: int = 252) -> float:
    """Calculate annualized return from returns."""
    if not returns:
        return 0.0

    cumulative = 1.0
    for r in returns:
        cumulative *= (1 + r)

    n = len(returns)
    years = n / periods_per_year
    if years == 0:
        return 0.0

    annualized = cumulative ** (1 / years) - 1
    return float(annualized)


def strategy_contribution(
    trades_list: List[pd.DataFrame],
    weights: List[float],
) -> List[dict]:
    """
    Calculate individual strategy contribution to portfolio.

    Args:
        trades_list: List of DataFrames with trade data
        weights: Weights for each strategy

    Returns:
        List of contribution dictionaries
    """
    contributions = []

    for i, (df, weight) in enumerate(zip(trades_list, weights)):
        total_ret = _total_return_from_trades(df)
        wins = 0
        losses = 0
        total_trades = 0

        if "pnl_pct" in df.columns:
            total_trades = len(df)
            wins = len(df[df["pnl_pct"] > 0])
            losses = len(df[df["pnl_pct"] < 0])
        elif "pnl" in df.columns:
            total_trades = len(df)
            wins = len(df[df["pnl"] > 0])
            losses = len(df[df["pnl"] < 0])

        contributions.append({
            "strategy": f"strategy_{i+1}",
            "weight": weight,
            "total_return": round(total_ret, 6),
            "total_trades": total_trades,
            "wins": wins,
            "losses": losses,
            "win_rate": round(wins / total_trades, 4) if total_trades > 0 else 0.0,
            "contribution": round(total_ret * weight, 6),
        })

    return contributions
