"""Backtesting engine for QuantPipe."""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass
from datetime import datetime

import pandas as pd
import numpy as np

from .strategy import Strategy


@dataclass
class Trade:
    """Single trade record."""
    entry_time: datetime
    exit_time: datetime
    entry_price: float
    exit_price: float
    side: str  # 'LONG' or 'SHORT'
    size: float
    pnl: float
    pnl_pct: float


class BacktestEngine:
    """Backtesting engine supporting both LONG and SHORT positions."""
    
    def __init__(
        self,
        strategy: Strategy,
        df: pd.DataFrame,
        initial_capital: float = 10000.0,
        commission: float = 0.001,  # 0.1%
        slippage: float = 0.0,  # 0.0005 for 0.05% slippage
        spread: float = 0.0,  # 0.0002 for 0.02% spread (half on each side)
    ):
        self.strategy = strategy
        self.df = df.copy()
        self.initial_capital = initial_capital
        self.commission = commission
        self.slippage = slippage
        self.spread = spread
        
        self.trades: List[Trade] = []
        self.equity_curve: List[float] = []
        self.signals: List[str] = []
        
        self._position: Optional[str] = None  # 'LONG', 'SHORT', or None
        self._entry_price: float = 0.0
        self._entry_idx: int = 0
        self._current_capital: float = initial_capital
    
    def _apply_slippage(self, price: float, side: str, is_entry: bool) -> float:
        """Apply slippage and spread to a price.
        
        Args:
            price: Base price
            side: 'LONG' or 'SHORT'
            is_entry: True if this is entry, False if exit
        
        Returns:
            Price adjusted for slippage and spread
        """
        total_cost = self.slippage + self.spread
        
        if total_cost == 0:
            return price
        
        if side == 'LONG':
            if is_entry:
                # Buying LONG: pay more (slippage up)
                return price * (1 + total_cost)
            else:
                # Selling LONG: get less (slippage down)
                return price * (1 - total_cost)
        else:  # SHORT
            if is_entry:
                # Selling SHORT: get less (slippage down)
                return price * (1 - total_cost)
            else:
                # Buying to cover SHORT: pay more (slippage up)
                return price * (1 + total_cost)
    
    def run(self) -> Dict[str, Any]:
        """Run backtest."""
        equity_history = [self.initial_capital]
        
        # Iterate through data
        for i in range(1, len(self.df)):
            current_df = self.df.iloc[:i+1]
            current_price = float(self.df['close'].iloc[i])
            current_time = self.df.index[i]
            
            # Get signal
            # Re-initialize indicators on the rolling window so strategy logic uses
            # information available up to the current bar (no look-ahead bias).
            self.strategy.init(current_df)
            signal = self.strategy.next(current_df)
            self.signals.append(signal)
            
            # Execute signal with bidirectional support
            if signal == 'BUY':
                self._handle_buy(current_price, current_time, i)
            elif signal == 'SELL':
                self._handle_sell(current_price, current_time, i)
            
            # Calculate current equity (mark-to-market)
            current_equity = self._calculate_equity(current_price)
            equity_history.append(current_equity)

        # Close any open position at the final bar (common backtest convention).
        if self._position is not None and len(self.df) > 0:
            last_price = float(self.df["close"].iloc[-1])
            last_time = self.df.index[-1]
            last_idx = len(self.df) - 1
            # Apply slippage on exit
            exit_price = self._apply_slippage(last_price, self._position, is_entry=False)
            self._close_position(exit_price, last_time, last_idx)
            # After closing, equity equals realized capital.
            equity_history[-1] = self._current_capital
        
        self.equity_curve = equity_history
        return self._calculate_metrics()
    
    def _handle_buy(self, current_price: float, current_time: datetime, current_idx: int) -> None:
        """Handle BUY signal: open LONG or close SHORT."""
        if self._position is None:
            # Open long position - apply slippage on entry
            entry_price = self._apply_slippage(current_price, 'LONG', is_entry=True)
            self._position = 'LONG'
            self._entry_price = entry_price
            self._entry_idx = current_idx
            
        elif self._position == 'SHORT':
            # Close short position (buy to cover) - apply slippage on exit
            exit_price = self._apply_slippage(current_price, 'SHORT', is_entry=False)
            self._close_position(exit_price, current_time, current_idx)
    
    def _handle_sell(self, current_price: float, current_time: datetime, current_idx: int) -> None:
        """Handle SELL signal: open SHORT or close LONG."""
        if self._position is None:
            # Open short position - apply slippage on entry
            entry_price = self._apply_slippage(current_price, 'SHORT', is_entry=True)
            self._position = 'SHORT'
            self._entry_price = entry_price
            self._entry_idx = current_idx
            
        elif self._position == 'LONG':
            # Close long position - apply slippage on exit
            exit_price = self._apply_slippage(current_price, 'LONG', is_entry=False)
            self._close_position(exit_price, current_time, current_idx)
    
    def _close_position(self, current_price: float, current_time: datetime, current_idx: int) -> None:
        """Close current position and record trade."""
        # Calculate PnL
        if self._position == 'LONG':
            pnl = current_price - self._entry_price
            pnl_pct = pnl / self._entry_price
        else:  # SHORT
            pnl = self._entry_price - current_price
            pnl_pct = pnl / self._entry_price
        
        # Apply commission (entry + exit)
        trade_value = self._current_capital
        commission_cost = trade_value * self.commission * 2
        
        # Update capital
        trade_pnl = self._current_capital * pnl_pct
        self._current_capital += trade_pnl - commission_cost
        
        trade = Trade(
            entry_time=self.df.index[self._entry_idx],
            exit_time=current_time,
            entry_price=self._entry_price,
            exit_price=current_price,
            side=self._position,
            size=self._current_capital / current_price,
            pnl=trade_pnl - commission_cost,
            pnl_pct=pnl_pct - (self.commission * 2)
        )
        self.trades.append(trade)
        
        self._position = None
        self._entry_price = 0.0
    
    def _calculate_equity(self, current_price: float) -> float:
        """Calculate current equity including unrealized PnL."""
        if self._position is None:
            return self._current_capital
        
        if self._position == 'LONG':
            unrealized_pnl = (current_price - self._entry_price) / self._entry_price
        else:  # SHORT
            unrealized_pnl = (self._entry_price - current_price) / self._entry_price
        
        return self._current_capital * (1 + unrealized_pnl)
    
    def _calculate_metrics(self) -> Dict[str, Any]:
        """Calculate performance metrics."""
        if not self.trades:
            return {
                'total_trades': 0,
                'winning_trades': 0,
                'losing_trades': 0,
                'long_trades': 0,
                'short_trades': 0,
                'win_rate': 0.0,
                'total_return': 0.0,
                'max_drawdown': 0.0,
                'sharpe_ratio': 0.0,
                'profit_factor': None,
            }
        
        # Basic metrics
        total_trades = len(self.trades)
        winning_trades = sum(1 for t in self.trades if t.pnl > 0)
        losing_trades = total_trades - winning_trades
        long_trades = sum(1 for t in self.trades if t.side == 'LONG')
        short_trades = sum(1 for t in self.trades if t.side == 'SHORT')
        win_rate = winning_trades / total_trades if total_trades > 0 else 0
        
        # Returns
        final_equity = self.equity_curve[-1]
        total_return = (final_equity - self.initial_capital) / self.initial_capital
        
        # Calculate period for annualization
        days = (self.df.index[-1] - self.df.index[0]).days
        if days > 0:
            annualized_return = (1 + total_return) ** (365 / days) - 1
        else:
            annualized_return = 0
        
        # Max drawdown
        equity_series = pd.Series(self.equity_curve)
        rolling_max = equity_series.expanding().max()
        drawdown = (equity_series - rolling_max) / rolling_max
        max_drawdown = drawdown.min()
        
        # Sharpe ratio (simplified, assuming risk-free rate = 0)
        if len(self.equity_curve) > 1:
            returns = pd.Series(self.equity_curve).pct_change().dropna()
            if returns.std() > 0:
                sharpe_ratio = (returns.mean() / returns.std()) * np.sqrt(252)
            else:
                sharpe_ratio = 0
        else:
            sharpe_ratio = 0
        
        # Profit factor (None when no losing trades — JSON-safe, avoids inf)
        gross_profit = sum(t.pnl for t in self.trades if t.pnl > 0)
        gross_loss = abs(sum(t.pnl for t in self.trades if t.pnl < 0))
        if gross_loss > 0:
            profit_factor = gross_profit / gross_loss
        else:
            profit_factor = None
        
        return {
            'total_trades': total_trades,
            'winning_trades': winning_trades,
            'losing_trades': losing_trades,
            'long_trades': long_trades,
            'short_trades': short_trades,
            'win_rate': round(win_rate, 4),
            'total_return': round(total_return, 4),
            'annualized_return': round(annualized_return, 4),
            'max_drawdown': round(max_drawdown, 4),
            'sharpe_ratio': round(sharpe_ratio, 4),
            'profit_factor': round(profit_factor, 4) if profit_factor is not None else None,
        }
