"""Pipeline JSON envelope (rule.md §4) and stdout emission."""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from typing import Any, Dict, Optional

SCHEMA_VERSION = 1
TOOL_NAME = "quantpipe"


def unwrap_upstream_json(data: Any) -> Any:
    """
    If stdin/file looks like a seamflux-style wrapper, unwrap once.

    Recognizes top-level ``{"result": {<dict>}}`` and returns the inner dict.

    Also promotes ``{"data": [<row>, ...]}`` where rows contain OHLCV-like
    fields into the top level so ``detect_data_format`` can identify the format
    (score >= 0.5 requires matching all detector keys at the top level).
    """
    if isinstance(data, dict):
        inner = data.get("result")
        if isinstance(inner, dict):
            return inner

    if isinstance(data, dict):
        inner_list = data.get("data")
        if isinstance(inner_list, list) and len(inner_list) > 0:
            first = inner_list[0]
            if isinstance(first, dict):
                row_keys = set(first.keys())
                ohlcv_keys = {"open", "high", "low", "close", "volume", "timestamp", "time", "price"}
                if row_keys & ohlcv_keys:
                    promoted = dict(data)
                    first_row = dict(first)
                    for k in ("open", "high", "low", "close", "volume", "timestamp", "time"):
                        if k in first_row:
                            promoted[k] = first_row[k]
                    return promoted
    return data


def success_envelope(
    command: str,
    data: Optional[Dict[str, Any]] = None,
    *,
    run_id: Optional[str] = None,
    artifacts: Optional[Dict[str, str]] = None,
    meta: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a successful pipeline summary object (rule.md §4.1)."""
    out: Dict[str, Any] = {
        "schemaVersion": SCHEMA_VERSION,
        "tool": TOOL_NAME,
        "command": command,
        "ok": True,
    }
    if data is not None:
        out["data"] = data
    if run_id is not None:
        out["runId"] = run_id
    if artifacts:
        out["artifacts"] = artifacts
    if meta:
        out["meta"] = meta
    return out


def failure_envelope(
    command: str,
    code: str,
    message: str,
) -> Dict[str, Any]:
    """Build a failure pipeline summary object (rule.md §4.2)."""
    return {
        "schemaVersion": SCHEMA_VERSION,
        "tool": TOOL_NAME,
        "command": command,
        "ok": False,
        "error": {"code": code, "message": message},
    }


def emit_json_line(payload: Dict[str, Any], *, pretty: bool) -> None:
    """
    Write JSON to stdout only.

    With ``pretty=False`` (default for ``--json``), emit a single line for ``jq``/parsers.
    """
    if pretty:
        text = json.dumps(payload, indent=2, default=str) + "\n"
    else:
        text = json.dumps(payload, separators=(",", ":"), default=str) + "\n"
    sys.stdout.write(text)


def utc_now_iso() -> str:
    """ISO-8601 timestamp with Z suffix."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
