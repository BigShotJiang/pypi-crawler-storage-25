"""Technical indicators for QuantPipe (pure pandas implementation)."""

import pandas as pd
import numpy as np


def calculate_sma(df: pd.DataFrame, period: int = 20) -> pd.Series:
    """Calculate Simple Moving Average."""
    return df['close'].rolling(window=period, min_periods=period).mean()


def calculate_ema(df: pd.DataFrame, period: int = 20) -> pd.Series:
    """Calculate Exponential Moving Average."""
    return df['close'].ewm(span=period, adjust=False, min_periods=period).mean()


def calculate_rsi(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Calculate Relative Strength Index."""
    delta = df['close'].diff()
    
    # Separate gains and losses
    gain = delta.where(delta > 0, 0)
    loss = (-delta.where(delta < 0, 0))
    
    # Calculate average gain and loss
    avg_gain = gain.rolling(window=period, min_periods=period).mean()
    avg_loss = loss.rolling(window=period, min_periods=period).mean()
    
    # Calculate RS and RSI (avoid division by zero)
    rs = avg_gain / avg_loss.replace(0, float('inf'))
    rsi = 100 - (100 / (1 + rs))
    
    return rsi


def calculate_macd(df: pd.DataFrame, fast: int = 12, slow: int = 26, signal: int = 9) -> tuple:
    """Calculate MACD.
    
    Returns:
        (macd_line, signal_line, histogram)
    """
    # Calculate EMAs
    ema_fast = df['close'].ewm(span=fast, adjust=False, min_periods=fast).mean()
    ema_slow = df['close'].ewm(span=slow, adjust=False, min_periods=slow).mean()
    
    # MACD line
    macd_line = ema_fast - ema_slow
    
    # Signal line
    signal_line = macd_line.ewm(span=signal, adjust=False, min_periods=signal).mean()
    
    # Histogram
    histogram = macd_line - signal_line
    
    return macd_line, signal_line, histogram


def calculate_bollinger_bands(df: pd.DataFrame, period: int = 20, std: float = 2.0) -> tuple:
    """Calculate Bollinger Bands.
    
    Returns:
        (upper, middle, lower)
    """
    middle = df['close'].rolling(window=period, min_periods=period).mean()
    rolling_std = df['close'].rolling(window=period, min_periods=period).std()
    
    upper = middle + (rolling_std * std)
    lower = middle - (rolling_std * std)
    
    return upper, middle, lower


def calculate_atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Calculate Average True Range."""
    high = df['high']
    low = df['low']
    close = df['close']
    
    # Calculate True Range
    tr1 = high - low
    tr2 = abs(high - close.shift(1))
    tr3 = abs(low - close.shift(1))
    
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    
    # Calculate ATR
    atr = tr.rolling(window=period, min_periods=period).mean()
    
    return atr


def calculate_supertrend(df: pd.DataFrame, period: int = 10, multiplier: float = 3.0) -> tuple:
    """Calculate Supertrend indicator.
    
    Returns:
        (supertrend, direction) where direction is 1 for uptrend, -1 for downtrend
    """
    high = df['high']
    low = df['low']
    close = df['close']
    
    # Calculate ATR
    tr1 = high - low
    tr2 = abs(high - close.shift(1))
    tr3 = abs(low - close.shift(1))
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    atr = tr.rolling(window=period, min_periods=period).mean()
    
    # Calculate upper and lower bands
    hl2 = (high + low) / 2
    upper_band = hl2 + (multiplier * atr)
    lower_band = hl2 - (multiplier * atr)
    
    # Initialize supertrend and direction
    supertrend = pd.Series(index=df.index, dtype=float)
    direction = pd.Series(index=df.index, dtype=int)
    
    for i in range(len(df)):
        if i == 0:
            supertrend.iloc[i] = upper_band.iloc[i]
            direction.iloc[i] = 1
        else:
            prev_close = close.iloc[i - 1]
            curr_close = close.iloc[i]
            prev_supertrend = supertrend.iloc[i - 1]
            prev_direction = direction.iloc[i - 1]
            
            # Update bands
            curr_upper = upper_band.iloc[i]
            curr_lower = lower_band.iloc[i]
            
            # Calculate new supertrend
            if prev_direction == 1:  # Uptrend
                if curr_close < prev_supertrend:
                    supertrend.iloc[i] = curr_upper
                    direction.iloc[i] = -1
                else:
                    supertrend.iloc[i] = max(prev_supertrend, curr_lower)
                    direction.iloc[i] = 1
            else:  # Downtrend
                if curr_close > prev_supertrend:
                    supertrend.iloc[i] = curr_lower
                    direction.iloc[i] = 1
                else:
                    supertrend.iloc[i] = min(prev_supertrend, curr_upper)
                    direction.iloc[i] = -1
    
    return supertrend, direction


def calculate_stochastic(
    df: pd.DataFrame, 
    k_period: int = 14, 
    d_period: int = 3
) -> tuple:
    """Calculate Stochastic Oscillator.
    
    Returns:
        (k, d) where k is %K line and d is %D line (SMA of k)
    """
    low_min = df['low'].rolling(window=k_period, min_periods=k_period).min()
    high_max = df['high'].rolling(window=k_period, min_periods=k_period).max()
    
    # %K
    k = 100 * (df['close'] - low_min) / (high_max - low_min)
    k = k.fillna(50)
    
    # %D (SMA of %K)
    d = k.rolling(window=d_period, min_periods=d_period).mean()
    
    return k, d


def calculate_adx(df: pd.DataFrame, period: int = 14) -> tuple:
    """Calculate Average Directional Index (ADX).
    
    Returns:
        (adx, plus_di, minus_di) - ADX line and directional indicators
    """
    high = df['high']
    low = df['low']
    close = df['close']
    
    # True Range
    tr1 = high - low
    tr2 = abs(high - close.shift(1))
    tr3 = abs(low - close.shift(1))
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    
    # Directional Movement
    high_diff = high.diff()
    low_diff = -low.diff()
    
    plus_dm = high_diff.where((high_diff > low_diff) & (high_diff > 0), 0.0)
    minus_dm = low_diff.where((low_diff > high_diff) & (low_diff > 0), 0.0)
    
    # Smoothed averages
    atr = tr.rolling(window=period, min_periods=period).mean()
    plus_dm_smooth = plus_dm.rolling(window=period, min_periods=period).mean()
    minus_dm_smooth = minus_dm.rolling(window=period, min_periods=period).mean()
    
    # Directional Indicators
    plus_di = 100 * plus_dm_smooth / atr
    minus_di = 100 * minus_dm_smooth / atr
    
    # DX
    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
    dx = dx.fillna(0)
    
    # ADX (smoothed DX)
    adx = dx.rolling(window=period, min_periods=period).mean()
    
    return adx, plus_di, minus_di


def calculate_vwap(df: pd.DataFrame) -> pd.Series:
    """Calculate Volume Weighted Average Price.
    
    Returns:
        VWAP series
    """
    typical_price = (df['high'] + df['low'] + df['close']) / 3
    volume = df['volume'] if 'volume' in df.columns else pd.Series(1, index=df.index)
    
    cumulative_tp_vol = (typical_price * volume).cumsum()
    cumulative_vol = volume.cumsum()
    
    vwap = cumulative_tp_vol / cumulative_vol
    return vwap


def calculate_pivot_points(
    df: pd.DataFrame, 
    pivot_type: str = 'standard'
) -> tuple:
    """Calculate Pivot Points and support/resistance levels.
    
    Args:
        df: DataFrame with high, low, close columns
        pivot_type: 'standard', 'fibonacci', or 'woodie'
    
    Returns:
        (pivot, r1, r2, r3, s1, s2, s3)
    """
    high = df['high']
    low = df['low']
    close = df['close']
    
    if pivot_type == 'woodie':
        pivot = (high.iloc[-1] + low.iloc[-1] + 2 * close.iloc[-1]) / 4
    elif pivot_type == 'fibonacci':
        pivot = (high.iloc[-1] + low.iloc[-1] + close.iloc[-1]) / 3
    else:  # standard
        pivot = (high.iloc[-1] + low.iloc[-1] + close.iloc[-1]) / 3
    
    r1 = 2 * pivot - low.iloc[-1]
    s1 = 2 * pivot - high.iloc[-1]
    
    r2 = pivot + (high.iloc[-1] - low.iloc[-1])
    s2 = pivot - (high.iloc[-1] - low.iloc[-1])
    
    r3 = high.iloc[-1] + 2 * (pivot - low.iloc[-1])
    s3 = low.iloc[-1] - 2 * (high.iloc[-1] - pivot)
    
    return pivot, r1, r2, r3, s1, s2, s3
