"""Data parsing and loading for QuantPipe.

This module provides unified data loading with auto-detection for multiple formats.
Supports Binance, Polymarket, Uniswap, and generic formats.
"""

import json
import sys
from typing import Union, List, Dict, Any, Optional, TextIO
from datetime import datetime, timedelta

import pandas as pd

from .adapter import adapt_data, detect_data_format, DataFormat, MarketType, get_formats_by_market_type
from .pipeline_json import unwrap_upstream_json


def load_data(source: Union[str, TextIO]) -> Dict[str, Any]:
    """Load data from file or stdin."""
    if source == '-' or source is sys.stdin:
        data = json.load(sys.stdin)
    elif isinstance(source, str):
        with open(source, 'r', encoding='utf-8') as f:
            data = json.load(f)
    else:
        data = json.load(source)

    if isinstance(data, dict):
        data = unwrap_upstream_json(data)
    return data


def prepare_data(data: Dict[str, Any]) -> tuple[pd.DataFrame, Dict[str, Any]]:
    """
    Prepare data for analysis with auto-format detection.
    
    Automatically detects and converts from:
    - Binance OHLCV (seamflux format)
    - Binance Tickers
    - Polymarket Price History
    - Polymarket Market data
    - Uniswap/Subgraph data
    - Generic OHLCV formats
    
    Returns:
        (DataFrame with OHLCV columns, metadata)
    """
    if not isinstance(data, dict):
        raise TypeError("prepare_data expects a dict")
    data = unwrap_upstream_json(data)
    if not isinstance(data, dict):
        raise TypeError("After unwrapping, data must be a dict")
    return adapt_data(data)


def detect_data_type(data: Dict[str, Any]) -> str:
    """
    Detect data type - backward compatible wrapper.
    
    Returns: 'ohlcv', 'tickers', 'ticker', or 'market_snapshot'
    """
    fmt = detect_data_format(data)
    
    # Map new formats to legacy type names
    type_mapping = {
        DataFormat.BINANCE_OHLCV: 'ohlcv',
        DataFormat.BINANCE_TICKERS: 'tickers',
        DataFormat.BINANCE_TICKER: 'ticker',
        DataFormat.POLYMARKET_PRICE_HISTORY: 'ohlcv',
        DataFormat.POLYMARKET_MARKET: 'market_snapshot',
        DataFormat.GENERIC_OHLCV: 'ohlcv',
        DataFormat.GENERIC_PRICE_HISTORY: 'ohlcv',
        DataFormat.UNISWAP_CANDLES: 'ohlcv',
    }
    
    return type_mapping.get(fmt, 'unknown')


# Legacy functions kept for backward compatibility
def parse_ohlcv_candles(candles: List[List[Any]]) -> pd.DataFrame:
    """Parse OHLCV candles - backward compatible."""
    df = pd.DataFrame(candles, columns=[
        'timestamp', 'open', 'high', 'low', 'close', 'volume',
        'close_time', 'quote_volume', 'trades', 'taker_buy_volume',
        'taker_buy_quote_volume', 'ignore'
    ])
    
    numeric_cols = ['open', 'high', 'low', 'close', 'volume']
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
    df.set_index('timestamp', inplace=True)
    
    return df


def parse_tickers(tickers: List[Dict[str, Any]]) -> pd.DataFrame:
    """Parse tickers - backward compatible."""
    df = pd.DataFrame(tickers)
    
    numeric_cols = ['last', 'bid', 'ask', 'high', 'low', 'volume', 'quoteVolume']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    return df


def _extract_symbol_from_message(message: str) -> Optional[str]:
    """Extract symbol from seamflux message."""
    if not message:
        return None
    parts = message.split()
    for i, part in enumerate(parts):
        if part == 'for' and i + 1 < len(parts):
            return parts[i + 1]
    return None


def calculate_signal_ttl(df: pd.DataFrame, default_seconds: int = 3600) -> int:
    """Calculate signal TTL based on data frequency."""
    if len(df) < 2:
        return default_seconds
    
    # Calculate average time delta between rows
    time_diff = df.index.to_series().diff().dropna()
    if len(time_diff) == 0:
        return default_seconds
    
    avg_interval = time_diff.median().total_seconds()
    return int(avg_interval * 2)  # 2x the interval
