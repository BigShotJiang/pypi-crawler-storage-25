#!/usr/bin/env python3
"""CLI entry point for QuantPipe."""

import click

from .cli_exit import EXIT_CODE_HELP
from .commands.backtest import backtest_command
from .commands.signal import signal_command
from .commands.scan import scan_command
from .commands.paper import paper_command
from .commands.risk import risk_command
from .commands.portfolio import portfolio_command
from .commands.export import export_command
from .commands.fetch import fetch_command
from .commands.optimize import optimize_command
from .commands.analyze import analyze_command


@click.group(epilog=EXIT_CODE_HELP)
@click.version_option(version='0.1.0', prog_name='quantpipe')
def cli():
    """QuantPipe - Quantitative trading toolkit for LLM AI.

    Designed to work seamlessly with seamflux CLI for market data via Unix pipes.

    Auto-detects data formats: Binance, Polymarket, Uniswap, generic OHLCV.

    Examples:
        # Generate signal from Binance (--pipe: raw JSON on stdout for quantpipe --stdin)
        seamflux invoke binance fetchOhlcv --pipe -p symbol=BTC/USDT -p interval=1h -p limit=100 | quantpipe signal --strategy ma_cross --stdin

        # Generate signal from Polymarket
        seamflux invoke polymarket getPriceHistory --pipe -p market=<token_id> -p interval=1h | quantpipe signal --strategy rsi --stdin

        # Run backtest
        quantpipe backtest --data btc_history.json --strategy rsi --json

        # Scan multiple symbols
        seamflux invoke binance fetchTickers --pipe -p marketType=spot -p symbols=BTCUSDT,ETHUSDT | quantpipe scan --strategy ma_cross --filter-signal BUY

        # Paper trading with Polymarket
        quantpipe paper --exec "seamflux invoke polymarket getMarket --pipe -p slug=<market_slug>" --strategy ma_cross

        # Risk management
        quantpipe risk --capital 10000 --risk-per-trade 0.02 --entry-price 50 --stop-loss 48

        # Portfolio analysis
        quantpipe portfolio --trades strategy_a/trades.csv --trades strategy_b/trades.csv --json

        # Fetch market data from exchange
        quantpipe fetch --exchange binance --symbol BTC/USDT --interval 1h --limit 100

        # Parameter optimization
        quantpipe optimize --strategy ma_cross --params fast=5-20 --params slow=10-50 --data data.json

        # Export backtest results
        quantpipe export --runs backtest_001 --output results.csv --format csv

        # Monte Carlo simulation
        quantpipe analyze --trades runs/backtest/trades.csv --method monte-carlo --iterations 1000 --json

        # Walk-forward analysis
        quantpipe analyze --data btc_history.json --strategy ma_cross --method walk-forward --json

        # Regime detection
        quantpipe analyze --data btc_history.json --method regime --json
    """
    pass


# Register commands
cli.add_command(backtest_command)
cli.add_command(signal_command)
cli.add_command(scan_command)
cli.add_command(paper_command)
cli.add_command(risk_command)
cli.add_command(portfolio_command)
cli.add_command(export_command)
cli.add_command(fetch_command)
cli.add_command(optimize_command)
cli.add_command(analyze_command)


if __name__ == '__main__':
    cli()
