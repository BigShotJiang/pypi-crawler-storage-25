"""Type definitions for QuantPipe."""

from typing import TypedDict, Literal, Optional, List, Dict, Any
from dataclasses import dataclass

# Signal types
SignalAction = Literal["BUY", "SELL", "HOLD"]
SignalType = Literal["ENTRY", "EXIT", "ADJUST"]

# Market types
MarketTypeLiteral = Literal["exchange", "prediction_market", "dex", "oracle", "generic", "unknown"]


@dataclass
class Signal:
    """Trading signal."""
    action: SignalAction
    price: float
    confidence: float
    reason: str
    indicators: Dict[str, Any]
    params: Dict[str, Any]
    timestamp: str
    valid_until: str


@dataclass
class OHLCV:
    """OHLCV candle data."""
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    close_time: Optional[int] = None


@dataclass
class Ticker:
    """Ticker data."""
    symbol: str
    last: float
    bid: float
    ask: float
    high: float
    low: float
    volume: float
    quote_volume: float
    change: float
    change_percent: float
    timestamp: int


@dataclass
class BacktestResult:
    """Backtest result."""
    total_return: float
    annualized_return: float
    max_drawdown: float
    sharpe_ratio: float
    win_rate: float
    profit_factor: float
    total_trades: int
    winning_trades: int
    losing_trades: int


class SeamfluxOHLCVOutput(TypedDict):
    """Seamflux OHLCV output format."""
    message: str
    candles: List[List[Any]]


class SeamfluxTickerOutput(TypedDict):
    """Seamflux ticker output format."""
    message: str
    tickers: List[Dict[str, Any]]


class SeamfluxSingleTickerOutput(TypedDict):
    """Seamflux single ticker output format."""
    message: str
    symbol: str
    last: float


class DataMetadata(TypedDict, total=False):
    """Data metadata structure."""
    type: str
    format: str
    market_type: MarketTypeLiteral
    symbol: Optional[str]
    bars: Optional[int]
    count: Optional[int]
    start: Optional[str]
    end: Optional[str]
    synthesized: Optional[bool]
    original_points: Optional[int]
    interval: Optional[str]
    symbols: Optional[List[str]]
    question: Optional[str]
    outcomes: Optional[List[str]]
    outcomePrices: Optional[List[float]]
