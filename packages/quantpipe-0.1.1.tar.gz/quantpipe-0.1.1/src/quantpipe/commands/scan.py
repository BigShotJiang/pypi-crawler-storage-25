"""Scan command for QuantPipe."""

import json
import logging
import os
import sys
from datetime import datetime
from typing import Optional

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.adapter import detect_data_format, get_market_type
from ..core.data import detect_data_type, parse_tickers, prepare_data
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from ..strategies import STRATEGIES
from .io_util import QuantpipeCliError, configure_verbose, load_cli_input_dict

log = logging.getLogger(__name__)


def _parse_strategy_params(params: tuple) -> dict:
    strategy_params = {}
    for param in params:
        if "=" not in param:
            raise QuantpipeCliError(EXIT_GENERAL, f"Invalid param format '{param}'. Use key=value", "INVALID_PARAM")
        key, value = param.split("=", 1)
        try:
            if "." in value:
                value = float(value)
            else:
                value = int(value)
        except ValueError:
            pass
        strategy_params[key] = value
    return strategy_params


@click.command(name="scan")
@click.option("--data", "-d", "data_path", type=str, default=None, help="Data file path (JSON)")
@click.option("--input", "-i", "input_path", type=str, default=None, help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from stdin")
@click.option("--strategy", "-s", required=True, help="Strategy name")
@click.option("--param", "params", multiple=True, help="Strategy parameters (key=value)")
@click.option(
    "--filter-signal", type=click.Choice(["BUY", "SELL", "HOLD"]), help="Filter by signal type"
)
@click.option(
    "--sort-by",
    type=click.Choice(["confidence", "price", "symbol"]),
    default="confidence",
    help="Sort results by",
)
@click.option(
    "--limit",
    type=int,
    default=500,
    help="Max results after sort (default 500). Use 0 for no limit.",
)
@click.option("--json", "output_json", is_flag=True, help="Machine-readable JSON envelope on stdout")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON (not for pipes)")
@click.option("--verbose", "-v", is_flag=True, help="Debug logs on stderr")
@click.option("--dry-run", is_flag=True, help="Validate input and strategy only; no per-row signals")
@click.option(
    "--output-dir",
    type=click.Path(file_okay=False, dir_okay=True, writable=True, path_type=str),
    default=None,
    help="Write full scan JSON to scan.json under this directory",
)
def scan_command(
    data_path: Optional[str],
    input_path: Optional[str],
    use_stdin: bool,
    strategy: str,
    params: tuple,
    filter_signal: Optional[str],
    sort_by: str,
    limit: int,
    output_json: bool,
    pretty: bool,
    verbose: bool,
    dry_run: bool,
    output_dir: Optional[str],
):
    """
    Scan multiple symbols and generate signals.

    Supports Binance tickers, Polymarket markets, and other multi-symbol formats.
    """
    configure_verbose(verbose)
    command = "scan"
    path = input_path or data_path

    try:
        strategy_params = _parse_strategy_params(params)
    except QuantpipeCliError as e:
        click.echo(e.message, err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
        sys.exit(e.exit_code)

    try:
        input_data = load_cli_input_dict(use_stdin=use_stdin, path=path)
    except QuantpipeCliError as e:
        click.echo(e.message, err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
        sys.exit(e.exit_code)

    fmt = detect_data_format(input_data)
    market_type = get_market_type(fmt).value if fmt else "unknown"
    data_type = detect_data_type(input_data)

    if strategy not in STRATEGIES:
        msg = f"Unknown strategy '{strategy}'. Available: {', '.join(STRATEGIES.keys())}"
        click.echo(f"Error: {msg}", err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, "INVALID_INPUT", msg), pretty=pretty)
        sys.exit(EXIT_GENERAL)

    StrategyClass = STRATEGIES[strategy]
    started = utc_now_iso()

    if dry_run:
        data_body = {
            "dryRun": True,
            "strategy": strategy,
            "market_type": market_type,
            "dataType": data_type,
        }
        if output_json or pretty:
            emit_json_line(
                success_envelope(command, data_body, meta={"startedAt": started, "finishedAt": utc_now_iso()}),
                pretty=pretty,
            )
        else:
            click.echo("\nDry run OK")
            click.echo(f"Strategy: {strategy}, data type: {data_type}, market: {market_type}")
        return

    results = []
    total_scanned = 0

    if data_type in ("tickers", "ticker"):
        if data_type == "tickers":
            df = parse_tickers(input_data["tickers"])
        else:
            try:
                df, _ = prepare_data(input_data)
            except Exception as e:
                click.echo(f"Error preparing data: {e}", err=True)
                if output_json or pretty:
                    emit_json_line(failure_envelope(command, "INVALID_INPUT", str(e)), pretty=pretty)
                sys.exit(EXIT_SCHEMA)

        total_scanned = len(df)

        for _, row in df.iterrows():
            symbol = row.get("symbol")
            if not symbol:
                continue

            ticker_df = pd.DataFrame([row])
            if "last" in ticker_df.columns and "close" not in ticker_df.columns:
                ticker_df["close"] = ticker_df["last"]

            metadata = {
                "type": "ticker",
                "symbol": symbol,
                "market_type": market_type,
            }

            strat = StrategyClass(params=strategy_params)
            try:
                signal = strat.generate_signal(ticker_df, metadata)

                if filter_signal and signal.action != filter_signal:
                    continue

                results.append(
                    {
                        "symbol": symbol,
                        "signal": signal.action,
                        "price": signal.price,
                        "confidence": signal.confidence,
                        "indicators": signal.indicators,
                    }
                )
            except Exception:
                continue

    elif data_type == "ohlcv":
        try:
            df, metadata = prepare_data(input_data)
        except Exception as e:
            click.echo(f"Error preparing data: {e}", err=True)
            if output_json or pretty:
                emit_json_line(failure_envelope(command, "INVALID_INPUT", str(e)), pretty=pretty)
            sys.exit(EXIT_SCHEMA)
        total_scanned = 1

        strat = StrategyClass(params=strategy_params)
        signal = strat.generate_signal(df, metadata)

        if not filter_signal or signal.action == filter_signal:
            results = [
                {
                    "symbol": metadata.get("symbol", "unknown"),
                    "signal": signal.action,
                    "price": signal.price,
                    "confidence": signal.confidence,
                    "indicators": signal.indicators,
                }
            ]
        else:
            results = []

    elif data_type == "market_snapshot":
        try:
            df, metadata = prepare_data(input_data)
        except Exception as e:
            click.echo(f"Error preparing data: {e}", err=True)
            if output_json or pretty:
                emit_json_line(failure_envelope(command, "INVALID_INPUT", str(e)), pretty=pretty)
            sys.exit(EXIT_SCHEMA)
        total_scanned = 1

        strat = StrategyClass(params=strategy_params)
        try:
            signal = strat.generate_signal(df, metadata)
        except Exception as e:
            click.echo(f"Error: Could not generate signal for market snapshot: {e}", err=True)
            if output_json or pretty:
                emit_json_line(failure_envelope(command, "INVALID_INPUT", str(e)), pretty=pretty)
            sys.exit(EXIT_SCHEMA)

        label = metadata.get("symbol") or metadata.get("question") or "unknown"
        if not filter_signal or signal.action == filter_signal:
            results = [
                {
                    "symbol": label,
                    "signal": signal.action,
                    "price": signal.price,
                    "confidence": signal.confidence,
                    "indicators": signal.indicators,
                }
            ]
        else:
            results = []
    else:
        msg = f"Unsupported data type for scan: {data_type}"
        click.echo(f"Error: {msg}", err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, "INVALID_INPUT", msg), pretty=pretty)
        sys.exit(EXIT_SCHEMA)

    if sort_by == "confidence":
        results.sort(key=lambda x: x["confidence"], reverse=True)
    elif sort_by == "price":
        results.sort(key=lambda x: x["price"], reverse=True)
    elif sort_by == "symbol":
        results.sort(key=lambda x: x["symbol"])

    effective_limit = None if limit == 0 else limit
    results_full = list(results)
    if effective_limit is not None:
        results = results[:effective_limit]

    summary = {"BUY": 0, "SELL": 0, "HOLD": 0}
    for r in results:
        summary[r["signal"]] = summary.get(r["signal"], 0) + 1

    file_summary = {"BUY": 0, "SELL": 0, "HOLD": 0}
    for r in results_full:
        file_summary[r["signal"]] = file_summary.get(r["signal"], 0) + 1

    ts = datetime.utcnow().isoformat() + "Z"
    file_payload = {
        "timestamp": ts,
        "strategy": strategy,
        "market_type": market_type,
        "scan": {
            "totalScanned": total_scanned,
            "signals": results_full,
            "summary": file_summary,
            "limit": effective_limit,
        },
    }

    artifacts: dict = {}
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        out_file = os.path.join(output_dir, "scan.json")
        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(file_payload, f, indent=2, default=str)
        artifacts["scan"] = out_file
        log.debug("Wrote %s", out_file)

    truncated = effective_limit is not None and len(results_full) > len(results)
    data_body = {
        "timestamp": ts,
        "strategy": strategy,
        "market_type": market_type,
        "scan": {
            "totalScanned": total_scanned,
            "summary": summary,
            "returned": len(results),
            "limit": effective_limit,
            "truncated": truncated,
        },
    }
    if not output_dir:
        data_body["scan"]["signals"] = results
    finished = utc_now_iso()

    if output_json or pretty:
        rel_artifacts = None
        if artifacts:
            cwd = os.getcwd()
            rel_artifacts = {}
            for k, p in artifacts.items():
                try:
                    rel_artifacts[k] = os.path.relpath(p, cwd)
                except ValueError:
                    rel_artifacts[k] = p
        emit_json_line(
            success_envelope(
                command,
                data_body,
                artifacts=rel_artifacts,
                meta={"startedAt": started, "finishedAt": finished},
            ),
            pretty=pretty,
        )
    else:
        click.echo(f"\nScan Results: {strategy}")
        click.echo(f"Market Type: {market_type}")
        click.echo(f"Total scanned: {total_scanned}")
        click.echo(f"Signals (shown): BUY={summary['BUY']}, SELL={summary['SELL']}, HOLD={summary['HOLD']}")
        if truncated:
            click.echo(f"(Results capped at {effective_limit}; use --limit 0 for all or --output-dir for full JSON)")
        click.echo("")
        for r in results:
            click.echo(f"  {r['symbol']}: {r['signal']} @ {r['price']} (confidence: {r['confidence']:.2%})")
