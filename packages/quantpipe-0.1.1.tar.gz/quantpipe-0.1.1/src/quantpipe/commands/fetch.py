"""Market data fetch command for QuantPipe."""

from __future__ import annotations

import json
import logging
import sys
from typing import Optional

import click

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.fetcher import fetch_ohlcv, ohlcv_to_dict, ohlcv_to_json_output
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from .io_util import QuantpipeCliError, configure_verbose

log = logging.getLogger(__name__)


@click.command(name="fetch")
@click.option("--exchange", "-e", required=True,
              type=click.Choice(["binance", "coinbase", "kraken"]),
              help="Exchange name")
@click.option("--symbol", "-s", required=True, help="Trading pair (e.g., BTC/USDT)")
@click.option("--interval", "-i", default="1h",
              type=click.Choice(["1m", "5m", "15m", "30m", "1h", "4h", "6h", "12h", "1d"]),
              help="Candle interval (default: 1h)")
@click.option("--start", type=str, help="Start time (ISO-8601)")
@click.option("--end", type=str, help="End time (ISO-8601)")
@click.option("--limit", type=int, default=1000, help="Max candles to fetch (default: 1000)")
@click.option("--output", "-o", "output_path", type=click.Path(), help="Output file path (JSON)")
@click.option("--json", "output_json", is_flag=True, help="Machine-readable JSON envelope on stdout")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON (not for pipes)")
@click.option("--verbose", "-v", is_flag=True, help="Debug logs on stderr")
def fetch_command(
    exchange: str,
    symbol: str,
    interval: str,
    start: Optional[str],
    end: Optional[str],
    limit: int,
    output_path: Optional[str],
    output_json: bool,
    pretty: bool,
    verbose: bool,
):
    """Fetch historical OHLCV data from exchanges.

    Examples:
        # Fetch BTC/USDT hourly candles from Binance
        quantpipe fetch --exchange binance --symbol BTC/USDT --interval 1h --limit 100

        # Fetch with time range and save to file
        quantpipe fetch -e binance -s ETH/USDT -i 4h --start 2024-01-01 --end 2024-03-01 -o data.json

        # Fetch and pipe to signal command
        quantpipe fetch -e binance -s BTC/USDT -i 1h | quantpipe signal --strategy rsi --stdin
    """
    configure_verbose(verbose)
    command = "fetch"

    try:
        if limit <= 0 or limit > 10000:
            raise QuantpipeCliError(
                EXIT_GENERAL,
                "Limit must be between 1 and 10000",
                "INVALID_PARAM",
            )

        started = utc_now_iso()

        df = fetch_ohlcv(
            exchange=exchange,
            symbol=symbol,
            interval=interval,
            start=start,
            end=end,
            limit=limit,
        )

        if df.empty:
            raise QuantpipeCliError(
                EXIT_SCHEMA,
                f"No data returned for {symbol} on {exchange}",
                "NO_DATA",
            )

        candles = ohlcv_to_dict(df)

        if output_path:
            output_data = ohlcv_to_json_output(df, symbol, exchange, interval)
            with open(output_path, "w", encoding="utf-8") as f:
                if pretty:
                    json.dump(output_data, f, indent=2, default=str)
                else:
                    json.dump(output_data, f, default=str)
            log.debug(f"Wrote {len(candles)} candles to {output_path}")

        if output_json or pretty:
            output_data = {
                "exchange": exchange,
                "symbol": symbol,
                "interval": interval,
                "bars": len(df),
                "candles": candles,
            }
            emit_json_line(
                success_envelope(
                    command,
                    output_data,
                    artifacts={"data": output_path} if output_path else None,
                    meta={"startedAt": started, "finishedAt": utc_now_iso()},
                ),
                pretty=pretty,
            )
        else:
            click.echo(f"Fetched {len(candles)} candles for {symbol} from {exchange}")
            click.echo(f"Symbol: {symbol}")
            click.echo(f"Exchange: {exchange}")
            click.echo(f"Interval: {interval}")
            if output_path:
                click.echo(f"Output: {output_path}")

    except QuantpipeCliError as e:
        click.echo(e.message, err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
        sys.exit(e.exit_code)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, "INTERNAL_ERROR", str(e)), pretty=pretty)
        sys.exit(EXIT_GENERAL)
