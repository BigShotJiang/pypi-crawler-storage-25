"""Analyze command for QuantPipe - Monte Carlo, Walk-forward, Regime Detection."""

import json
import logging
import os
import sys
from typing import Optional

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.analysis import detect_regime, monte_carlo_simulation, walk_forward_analysis
from ..core.backtest import BacktestEngine
from ..core.data import prepare_data
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from ..strategies import STRATEGIES
from .io_util import QuantpipeCliError, configure_verbose, load_cli_input_dict

log = logging.getLogger(__name__)


def _parse_strategy_params(params: tuple) -> dict:
    strategy_params = {}
    for param in params:
        if "=" not in param:
            raise QuantpipeCliError(EXIT_GENERAL, f"Invalid param format '{param}'. Use key=value", "INVALID_PARAM")
        key, value = param.split("=", 1)
        try:
            if "." in value:
                value = float(value)
            else:
                value = int(value)
        except ValueError:
            pass
        strategy_params[key] = value
    return strategy_params


def _load_trades_from_csv(trades_path: str) -> list:
    """Load trades from CSV file and return list of pnl_pct values."""
    df = pd.read_csv(trades_path)
    if 'pnl_pct' in df.columns:
        return df['pnl_pct'].dropna().tolist()
    elif 'pnl' in df.columns:
        # Convert absolute PnL to percentage based on some assumption
        return df['pnl'].dropna().tolist()
    return []


@click.command(name="analyze")
@click.option("--run-dir", "run_dir", type=str, default=None, help="Backtest run directory with trades.csv")
@click.option("--trades", "trades_path", type=str, default=None, help="Path to trades.csv file")
@click.option("--data", "-d", "data_path", type=str, default=None, help="Data file path for regime detection")
@click.option("--input", "-i", "input_path", type=str, default=None, help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from stdin")
@click.option("--method", "-m", required=True,
              type=click.Choice(['monte-carlo', 'walk-forward', 'regime'], case_sensitive=False),
              help="Analysis method")
@click.option("--strategy", "-s", default=None, help="Strategy name (for walk-forward)")
@click.option("--param", "params", multiple=True, help="Strategy parameters (key=value)")
@click.option("--iterations", "-n", type=int, default=1000, help="Number of Monte Carlo iterations")
@click.option("--train-ratio", type=float, default=0.7, help="Training data ratio for walk-forward (0.0-1.0)")
@click.option("--step", type=int, default=30, help="Step size for walk-forward window")
@click.option("--metric", default='sharpe_ratio',
              type=click.Choice(['sharpe_ratio', 'total_return', 'win_rate']),
              help="Metric for walk-forward optimization")
@click.option("--initial-capital", type=float, default=10000.0, help="Initial capital for Monte Carlo")
@click.option("--lookback", type=int, default=50, help="Lookback period for regime detection")
@click.option("--json", "output_json", is_flag=True, help="Machine-readable JSON envelope on stdout")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON (not for pipes)")
@click.option("--verbose", "-v", is_flag=True, help="Debug logs on stderr")
def analyze_command(
    run_dir: Optional[str],
    trades_path: Optional[str],
    data_path: Optional[str],
    input_path: Optional[str],
    use_stdin: bool,
    method: str,
    strategy: Optional[str],
    params: tuple,
    iterations: int,
    train_ratio: float,
    step: int,
    metric: str,
    initial_capital: float,
    lookback: int,
    output_json: bool,
    pretty: bool,
    verbose: bool,
):
    """Advanced analysis: Monte Carlo simulation, walk-forward optimization, regime detection.
    
    Examples:
        # Monte Carlo simulation from trades.csv
        quantpipe analyze --trades runs/backtest/trades.csv --method monte-carlo --iterations 1000 --json
        
        # Walk-forward analysis
        quantpipe analyze --data btc_history.json --strategy ma_cross --method walk-forward --json
        
        # Regime detection
        quantpipe analyze --data btc_history.json --method regime --json
    """
    configure_verbose(verbose)
    command = "analyze"
    path = input_path or data_path

    started = utc_now_iso()

    try:
        if method == 'monte-carlo':
            # Load trades from CSV
            if not trades_path and not run_dir:
                raise QuantpipeCliError(EXIT_GENERAL,
                    "Either --trades or --run-dir required for Monte Carlo", "MISSING_INPUT")
            
            if run_dir:
                trades_path = os.path.join(run_dir, "trades.csv")
            
            if not os.path.exists(trades_path):
                raise QuantpipeCliError(EXIT_GENERAL,
                    f"Trades file not found: {trades_path}", "FILE_NOT_FOUND")
            
            trades_pnl = _load_trades_from_csv(trades_path)
            
            if not trades_pnl:
                raise QuantpipeCliError(EXIT_GENERAL,
                    "No trades found in file", "NO_DATA")
            
            result = monte_carlo_simulation(
                trades_pnl=trades_pnl,
                n_simulations=iterations,
                initial_capital=initial_capital,
            )
            
            data_body = {
                "method": "monte-carlo",
                "iterations": iterations,
                "trades_file": trades_path,
                "result": result,
            }
            
        elif method == 'walk-forward':
            # Walk-forward analysis
            if not strategy:
                raise QuantpipeCliError(EXIT_GENERAL,
                    "--strategy required for walk-forward analysis", "MISSING_STRATEGY")
            
            if strategy not in STRATEGIES:
                raise QuantpipeCliError(EXIT_GENERAL,
                    f"Unknown strategy '{strategy}'. Available: {', '.join(STRATEGIES.keys())}", "INVALID_STRATEGY")
            
            strategy_params = _parse_strategy_params(params)
            
            input_data = load_cli_input_dict(use_stdin=use_stdin, path=path)
            df, metadata = prepare_data(input_data)
            
            StrategyClass = STRATEGIES[strategy]
            
            result = walk_forward_analysis(
                strategy_class=StrategyClass,
                df=df,
                train_ratio=train_ratio,
                step=step,
                metric=metric,
            )
            
            data_body = {
                "method": "walk-forward",
                "strategy": strategy,
                "strategy_params": strategy_params,
                "train_ratio": train_ratio,
                "step": step,
                "metric": metric,
                "source": {
                    "symbol": metadata.get("symbol"),
                    "market_type": metadata.get("market_type"),
                    "bars": len(df),
                },
                "result": result,
            }
            
        elif method == 'regime':
            # Regime detection
            input_data = load_cli_input_dict(use_stdin=use_stdin, path=path)
            df, metadata = prepare_data(input_data)
            
            if 'close' not in df.columns:
                raise QuantpipeCliError(EXIT_GENERAL,
                    "Data must contain 'close' price for regime detection", "INVALID_DATA")
            
            result = detect_regime(
                prices=df['close'],
                lookback=lookback,
            )
            
            data_body = {
                "method": "regime",
                "lookback": lookback,
                "source": {
                    "symbol": metadata.get("symbol"),
                    "market_type": metadata.get("market_type"),
                    "bars": len(df),
                },
                "result": result,
            }
        
        else:
            raise QuantpipeCliError(EXIT_GENERAL, f"Unknown method: {method}", "INVALID_METHOD")
        
    except QuantpipeCliError as e:
        click.echo(e.message, err=True)
        if output_json:
            emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
        sys.exit(e.exit_code)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        if output_json:
            emit_json_line(failure_envelope(command, "ANALYSIS_ERROR", str(e)), pretty=pretty)
        sys.exit(EXIT_GENERAL)
    
    finished = utc_now_iso()
    
    if output_json or pretty:
        emit_json_line(
            success_envelope(
                command,
                data_body,
                meta={"startedAt": started, "finishedAt": finished},
            ),
            pretty=pretty,
        )
    else:
        # Human-readable output
        click.echo(f"\nAnalysis: {method.upper()}")
        click.echo("=" * 50)
        
        if method == 'monte-carlo':
            r = data_body['result']
            click.echo(f"Simulations: {r['n_simulations']}")
            click.echo(f"Trades: {r['n_trades']}")
            click.echo(f"\nFinal Equity:")
            click.echo(f"  Mean: ${r['final_equity']['mean']:,.2f}")
            click.echo(f"  Median: ${r['final_equity']['median']:,.2f}")
            click.echo(f"  Std Dev: ${r['final_equity']['std']:,.2f}")
            click.echo(f"  Min: ${r['final_equity']['min']:,.2f}")
            click.echo(f"  Max: ${r['final_equity']['max']:,.2f}")
            click.echo(f"\nMax Drawdown:")
            click.echo(f"  Mean: {r['max_drawdown']['mean']:.2%}")
            click.echo(f"  Median: {r['max_drawdown']['median']:.2%}")
            click.echo(f"\nRuin Probability: {r['ruin_probability']:.2%}")
            click.echo(f"\nPercentiles:")
            for p, v in r['percentiles'].items():
                click.echo(f"  {p}%: ${v:,.2f}")
                
        elif method == 'walk-forward':
            r = data_body['result']
            if 'error' in r:
                click.echo(f"Error: {r['error']}")
            else:
                click.echo(f"Strategy: {data_body['strategy']}")
                click.echo(f"Folds: {r['n_folds']}")
                click.echo(f"\nIn-Sample ({r['metric']}):")
                click.echo(f"  Mean: {r['in_sample']['mean']:.4f}")
                click.echo(f"  Std: {r['in_sample']['std']:.4f}")
                click.echo(f"\nOut-of-Sample ({r['metric']}):")
                click.echo(f"  Mean: {r['out_sample']['mean']:.4f}")
                click.echo(f"  Std: {r['out_sample']['std']:.4f}")
                click.echo(f"\nSample Decay: {r['sample_decay']:.4f}")
                click.echo(f"Roll Rate: {r['roll_rate']:.2%}")
                
        elif method == 'regime':
            r = data_body['result']
            click.echo(f"Regime: {r['regime']}")
            click.echo(f"Trend: {r['trend']} (score: {r['trend_score']})")
            click.echo(f"Annualized Trend: {r['annualized_trend_pct']:.2f}%")
            click.echo(f"Volatility: {r['volatility']} (ratio: {r['volatility_ratio']})")
            click.echo(f"Trend Consistency: {r['trend_consistency']:.2%}")
            click.echo(f"Confidence: {r['confidence']:.2%}")
