"""Portfolio analysis command for QuantPipe."""

from __future__ import annotations

import json
import logging
import os
import sys
from typing import Any, Dict, List, Optional

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from ..core.portfolio import (
    calculate_portfolio_metrics,
    correlation_matrix,
    strategy_contribution,
)
from .io_util import QuantpipeCliError, configure_verbose

log = logging.getLogger(__name__)


def _parse_weights(weights_str: Optional[str]) -> Optional[List[float]]:
    """Parse weights string like 'strategy1=0.4,strategy2=0.6'."""
    if not weights_str:
        return None

    weights_dict: Dict[str, float] = {}
    pairs = weights_str.split(",")
    for pair in pairs:
        if "=" not in pair:
            raise QuantpipeCliError(
                EXIT_GENERAL,
                f"Invalid weight format '{pair}'. Use key=value, e.g., strategy1=0.4",
                "INVALID_PARAM",
            )
        key, value = pair.split("=", 1)
        try:
            weights_dict[key.strip()] = float(value.strip())
        except ValueError:
            raise QuantpipeCliError(
                EXIT_GENERAL,
                f"Invalid weight value '{value}'. Must be a number.",
                "INVALID_PARAM",
            )

    weights = list(weights_dict.values())
    total = sum(weights)
    if abs(total - 1.0) > 0.01:
        raise QuantpipeCliError(
            EXIT_GENERAL,
            f"Weights must sum to 1.0, got {total}",
            "INVALID_PARAM",
        )

    return weights


def _load_trades_file(path: str) -> pd.DataFrame:
    """Load trades from CSV or JSON file."""
    if not os.path.exists(path):
        raise QuantpipeCliError(EXIT_GENERAL, f"File not found: {path}", "FILE_NOT_FOUND")

    try:
        if path.endswith(".json"):
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return pd.DataFrame(data)
            if isinstance(data, dict) and "trades" in data:
                return pd.DataFrame(data["trades"])
            return pd.DataFrame(data)
        else:
            return pd.read_csv(path)
    except Exception as e:
        raise QuantpipeCliError(EXIT_GENERAL, f"Failed to load trades: {e}", "IO_ERROR")


def _load_runs_dir(runs_path: str) -> List[pd.DataFrame]:
    """Load all trades from a runs directory."""
    trades_list = []

    if not os.path.isdir(runs_path):
        raise QuantpipeCliError(EXIT_GENERAL, f"Not a directory: {runs_path}", "INVALID_INPUT")

    for entry in os.listdir(runs_path):
        entry_path = os.path.join(runs_path, entry)
        if os.path.isdir(entry_path):
            trades_file = os.path.join(entry_path, "trades.csv")
            if os.path.exists(trades_file):
                try:
                    df = pd.read_csv(trades_file)
                    if "pnl_pct" in df.columns or "pnl" in df.columns:
                        trades_list.append(df)
                except Exception:
                    pass

    return trades_list


@click.command(name="portfolio")
@click.option("--trades", "-t", "trades_files", multiple=True, type=click.Path(exists=True),
              help="Trades files (CSV or JSON). Accepts multiple inputs.")
@click.option("--runs", "-r", "runs_dirs", multiple=True, type=click.Path(exists=True),
              help="runs/ directories containing trades.csv")
@click.option("--weights", "-w", "weights_str", type=str,
              help="Weight distribution, e.g.: s1=0.4,s2=0.6")
@click.option("--risk-free", type=float, default=0.02, help="Risk-free rate (default: 0.02)")
@click.option("--json", "output_json", is_flag=True, help="Machine-readable JSON envelope on stdout")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON (not for pipes)")
@click.option("--verbose", "-v", is_flag=True, help="Debug logs on stderr")
def portfolio_command(
    trades_files: tuple,
    runs_dirs: tuple,
    weights_str: Optional[str],
    risk_free: float,
    output_json: bool,
    pretty: bool,
    verbose: bool,
):
    """Portfolio analysis: combine multiple strategy trades, calculate correlation, Sharpe ratio.

    Examples:
        # Analyze multiple trades files with equal weights
        quantpipe portfolio --trades strategy_a/trades.csv --trades strategy_b/trades.csv --json

        # With custom weights
        quantpipe portfolio --trades a.csv --trades b.csv --weights a=0.6,b=0.4

        # Analyze all runs in a directory
        quantpipe portfolio --runs runs/ --risk-free 0.03
    """
    configure_verbose(verbose)
    command = "portfolio"

    try:
        trades_list: List[pd.DataFrame] = []

        for tf in trades_files:
            df = _load_trades_file(tf)
            if "pnl_pct" not in df.columns and "pnl" not in df.columns:
                raise QuantpipeCliError(
                    EXIT_SCHEMA,
                    f"Trades file '{tf}' missing 'pnl_pct' or 'pnl' column",
                    "INVALID_INPUT",
                )
            trades_list.append(df)

        for rd in runs_dirs:
            loaded = _load_runs_dir(rd)
            trades_list.extend(loaded)

        if not trades_list:
            raise QuantpipeCliError(
                EXIT_GENERAL,
                "No valid trades data found. Use --trades or --runs to provide trade data.",
                "NO_INPUT",
            )

        weights = _parse_weights(weights_str)

        started = utc_now_iso()
        metrics = calculate_portfolio_metrics(trades_list, weights, risk_free)
        contributions = strategy_contribution(trades_list, weights or [1.0/len(trades_list)] * len(trades_list))
        corr_df, strategy_names = correlation_matrix(trades_list)

        corr_list = []
        if not corr_df.empty:
            corr_list = corr_df.values.tolist()

        result: Dict[str, Any] = {
            "num_strategies": len(trades_list),
            "risk_free": risk_free,
            "metrics": metrics,
            "contributions": contributions,
            "correlation_matrix": corr_list,
            "strategy_names": strategy_names,
        }

        if output_json or pretty:
            emit_json_line(
                success_envelope(
                    command,
                    result,
                    meta={"startedAt": started, "finishedAt": utc_now_iso()},
                ),
                pretty=pretty,
            )
        else:
            click.echo(f"\nPortfolio Analysis")
            click.echo(f"=================")
            click.echo(f"Strategies: {len(trades_list)}")
            click.echo(f"Risk-free rate: {risk_free:.2%}")
            click.echo(f"")

            m = metrics
            click.echo(f"Portfolio Metrics:")
            click.echo(f"  Total Return: {m.get('total_return', 0):.2%}")
            click.echo(f"  Annualized Return: {m.get('annualized_return', 0):.2%}")
            click.echo(f"  Sharpe Ratio: {m.get('sharpe_ratio', 0):.2f}")
            click.echo(f"  Sortino Ratio: {m.get('sortino_ratio', 0):.2f}")
            click.echo(f"  Max Drawdown: {m.get('max_drawdown', 0):.2%}")
            click.echo(f"  Calmar Ratio: {m.get('calmar_ratio', 0):.2f}")
            click.echo(f"")

            click.echo(f"Strategy Contributions:")
            for c in contributions:
                click.echo(f"  {c['strategy']}: {c['total_return']:.2%} (weight: {c['weight']:.2f}, "
                          f"trades: {c['total_trades']}, win rate: {c['win_rate']:.1%})")
            click.echo(f"")

            if corr_list:
                click.echo(f"Correlation Matrix:")
                header = "        " + "  ".join(f"{n[:8]:>8}" for n in strategy_names)
                click.echo(header)
                for i, row in enumerate(corr_list):
                    row_str = "  ".join(f"{v:>8.2f}" for v in row)
                    click.echo(f"{strategy_names[i][:8]:>8}  {row_str}")

    except QuantpipeCliError as e:
        click.echo(e.message, err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
        sys.exit(e.exit_code)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, "INTERNAL_ERROR", str(e)), pretty=pretty)
        sys.exit(EXIT_GENERAL)
