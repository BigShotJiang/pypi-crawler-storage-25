"""Signal command for QuantPipe."""

import json
import logging
import os
import sys
from typing import Optional

import click

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.data import prepare_data
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from ..strategies import STRATEGIES
from .io_util import QuantpipeCliError, configure_verbose, load_cli_input_dict

log = logging.getLogger(__name__)


def _parse_strategy_params(params: tuple) -> dict:
    strategy_params = {}
    for param in params:
        if "=" not in param:
            raise QuantpipeCliError(EXIT_GENERAL, f"Invalid param format '{param}'. Use key=value", "INVALID_PARAM")
        key, value = param.split("=", 1)
        try:
            if "." in value:
                value = float(value)
            else:
                value = int(value)
        except ValueError:
            pass
        strategy_params[key] = value
    return strategy_params


@click.command(name="signal")
@click.option("--data", "-d", "data_path", type=str, default=None, help="Data file path (JSON)")
@click.option("--input", "-i", "input_path", type=str, default=None, help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from stdin")
@click.option("--strategy", "-s", required=True, help="Strategy name")
@click.option("--param", "params", multiple=True, help="Strategy parameters (key=value)")
@click.option("--json", "output_json", is_flag=True, help="Machine-readable JSON envelope on stdout")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON (not for pipes)")
@click.option("--verbose", "-v", is_flag=True, help="Debug logs on stderr")
@click.option("--dry-run", is_flag=True, help="Validate input and strategy only; no signal computation")
@click.option(
    "--output-dir",
    type=click.Path(file_okay=False, dir_okay=True, writable=True, path_type=str),
    default=None,
    help="Write full signal payload JSON to signal.json under this directory",
)
def signal_command(
    data_path: Optional[str],
    input_path: Optional[str],
    use_stdin: bool,
    strategy: str,
    params: tuple,
    output_json: bool,
    pretty: bool,
    verbose: bool,
    dry_run: bool,
    output_dir: Optional[str],
):
    """
    Generate trading signal from data.

    Auto-detects data format: Binance, Polymarket, Uniswap, or generic OHLCV.
    """
    configure_verbose(verbose)
    path = input_path or data_path
    command = "signal"

    try:
        strategy_params = _parse_strategy_params(params)
    except QuantpipeCliError as e:
        click.echo(e.message, err=True)
        if output_json:
            emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
        sys.exit(e.exit_code)

    try:
        input_data = load_cli_input_dict(use_stdin=use_stdin, path=path)
    except QuantpipeCliError as e:
        click.echo(e.message, err=True)
        if output_json:
            emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
        sys.exit(e.exit_code)

    try:
        df, metadata = prepare_data(input_data)
    except Exception as e:
        click.echo(f"Error preparing data: {e}", err=True)
        if output_json:
            emit_json_line(
                failure_envelope(command, "INVALID_INPUT", str(e)),
                pretty=pretty,
            )
        sys.exit(EXIT_SCHEMA)

    if strategy not in STRATEGIES:
        msg = f"Unknown strategy '{strategy}'. Available: {', '.join(STRATEGIES.keys())}"
        click.echo(f"Error: {msg}", err=True)
        if output_json:
            emit_json_line(failure_envelope(command, "INVALID_INPUT", msg), pretty=pretty)
        sys.exit(EXIT_GENERAL)

    StrategyClass = STRATEGIES[strategy]
    strat = StrategyClass(params=strategy_params)

    started = utc_now_iso()
    artifacts: dict = {}

    if dry_run:
        data_body = {
            "dryRun": True,
            "source": {
                "format": metadata.get("format", "unknown"),
                "market_type": metadata.get("market_type", "unknown"),
                "type": metadata.get("type", "unknown"),
                "symbol": metadata.get("symbol"),
                "bars": len(df),
            },
            "strategy": {"name": strategy, "params": strat.params},
        }
        if output_json or pretty:
            emit_json_line(
                success_envelope(
                    command,
                    data_body,
                    meta={"startedAt": started, "finishedAt": utc_now_iso()},
                ),
                pretty=pretty,
            )
        else:
            click.echo("\nDry run OK")
            click.echo(f"Strategy: {strategy} {strat.params}")
            click.echo(f"Format: {metadata.get('format')}, bars: {len(df)}")
        return

    try:
        signal = strat.generate_signal(df, metadata)
    except Exception as e:
        click.echo(f"Error generating signal: {e}", err=True)
        if output_json:
            emit_json_line(failure_envelope(command, "INVALID_INPUT", str(e)), pretty=pretty)
        sys.exit(EXIT_GENERAL)

    data_body = {
        "timestamp": signal.timestamp,
        "validUntil": signal.valid_until,
        "source": {
            "format": metadata.get("format", "unknown"),
            "market_type": metadata.get("market_type", "unknown"),
            "type": metadata.get("type", "unknown"),
            "symbol": metadata.get("symbol"),
            "bars": metadata.get("bars"),
        },
        "strategy": {"name": strategy, "params": signal.params},
        "signal": {
            "action": signal.action,
            "confidence": signal.confidence,
            "price": signal.price,
            "reason": signal.reason,
        },
        "indicators": signal.indicators,
        "metadata": {
            "synthesized": metadata.get("synthesized", False),
            "interval": metadata.get("interval"),
        },
    }

    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        out_file = os.path.join(output_dir, "signal.json")
        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(data_body, f, indent=2, default=str)
        artifacts["signal"] = out_file
        log.debug("Wrote %s", out_file)

    finished = utc_now_iso()
    if output_json or pretty:
        env = success_envelope(
            command,
            data_body,
            artifacts=artifacts or None,
            meta={"startedAt": started, "finishedAt": finished},
        )
        emit_json_line(env, pretty=pretty)
    else:
        click.echo(f"\nSignal: {signal.action}")
        click.echo(f"Source: {metadata.get('format', 'unknown')}")
        click.echo(f"Market Type: {metadata.get('market_type', 'unknown')}")
        click.echo(f"Symbol: {metadata.get('symbol', 'N/A')}")
        click.echo(f"Price: {signal.price}")
        click.echo(f"Confidence: {signal.confidence:.2%}")
        click.echo(f"Reason: {signal.reason}")
        if metadata.get("synthesized"):
            click.echo(f"Note: OHLCV synthesized from {metadata.get('original_points')} price points")
        click.echo(f"Valid until: {signal.valid_until}")
