"""Risk management command for QuantPipe."""

from __future__ import annotations

import logging
import sys
from typing import Optional, Sequence

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from ..core.risk import (
    calculate_atr_position_size,
    calculate_cvar,
    calculate_risk_reward,
    calculate_var,
    kelly_criterion,
    position_sizing,
    ruin_probability,
)
from .io_util import QuantpipeCliError, configure_verbose, load_cli_input_dict

log = logging.getLogger(__name__)


def _parse_trades_from_input(input_data) -> Optional[pd.DataFrame]:
    """Extract trades DataFrame from input data."""
    if input_data is None:
        return None

    if isinstance(input_data, dict):
        if "trades" in input_data and isinstance(input_data["trades"], list):
            df = pd.DataFrame(input_data["trades"])
            if "pnl_pct" in df.columns or "pnl" in df.columns:
                return df
        if "data" in input_data and isinstance(input_data["data"], dict):
            return _parse_trades_from_input(input_data["data"])

    return None


def _calculate_trade_stats(pnl_returns: Sequence[float]) -> dict:
    """Calculate risk metrics from trade P&L returns."""
    if not pnl_returns:
        return {}

    return {
        "var_95": calculate_var(pnl_returns, 0.95),
        "var_99": calculate_var(pnl_returns, 0.99),
        "cvar_95": calculate_cvar(pnl_returns, 0.95),
        "cvar_99": calculate_cvar(pnl_returns, 0.99),
    }


@click.command(name="risk")
@click.option("--capital", "-c", type=float, required=True, help="Total capital")
@click.option("--risk-per-trade", type=float, default=0.02, help="Risk per trade percentage (default: 0.02)")
@click.option("--entry-price", "-e", type=float, help="Entry price")
@click.option("--stop-loss", "-s", type=float, help="Stop-loss price")
@click.option("--target-price", "-t", type=float, help="Profit target price")
@click.option("--volatility", type=float, help="Volatility (ATR) for ATR-based stop calculation")
@click.option("--atr-multiplier", type=float, default=2.0, help="ATR multiplier for stop distance (default: 2.0)")
@click.option("--data", "-d", "data_path", type=str, default=None, help="Data file path (JSON) for trade history")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read trade history from stdin")
@click.option("--json", "output_json", is_flag=True, help="Machine-readable JSON envelope on stdout")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON (not for pipes)")
@click.option("--verbose", "-v", is_flag=True, help="Debug logs on stderr")
def risk_command(
    capital: float,
    risk_per_trade: float,
    entry_price: Optional[float],
    stop_loss: Optional[float],
    target_price: Optional[float],
    volatility: Optional[float],
    atr_multiplier: float,
    data_path: Optional[str],
    use_stdin: bool,
    output_json: bool,
    pretty: bool,
    verbose: bool,
):
    """Risk management: calculate position sizing, VaR, stop-loss, and risk metrics.

    Examples:
        # Position sizing with fixed stop-loss
        quantpipe risk --capital 10000 --risk-per-trade 0.02 --entry-price 50 --stop-loss 48

        # Position sizing with ATR-based stop
        quantpipe risk --capital 10000 --risk-per-trade 0.02 --entry-price 50 --volatility 1.5

        # Risk analysis from trade history
        quantpipe risk --capital 10000 --data runs/backtest/trades.csv --json
    """
    configure_verbose(verbose)
    command = "risk"

    try:
        if capital <= 0:
            raise QuantpipeCliError(EXIT_GENERAL, "Capital must be positive", "INVALID_PARAM")

        if risk_per_trade <= 0 or risk_per_trade > 1:
            raise QuantpipeCliError(EXIT_GENERAL, "Risk per trade must be between 0 and 1", "INVALID_PARAM")

        input_data = None
        if use_stdin or data_path:
            input_data = load_cli_input_dict(use_stdin=use_stdin, path=data_path)

        trades_df = _parse_trades_from_input(input_data)

        result: dict = {
            "capital": capital,
            "risk_per_trade": risk_per_trade,
            "risk_amount": capital * risk_per_trade,
        }

        if entry_price is not None and stop_loss is not None:
            pos = position_sizing(capital, risk_per_trade, entry_price, stop_loss)
            result["position"] = pos

            if target_price is not None:
                rr = calculate_risk_reward(entry_price, target_price, stop_loss)
                result["risk_reward_ratio"] = rr

        elif entry_price is not None and volatility is not None:
            pos = calculate_atr_position_size(
                capital, risk_per_trade, entry_price, volatility, atr_multiplier
            )
            result["position"] = pos
            result["atr_based_stop"] = True

        if trades_df is not None:
            pnl_col = "pnl_pct" if "pnl_pct" in trades_df.columns else "pnl"
            if pnl_col in trades_df.columns:
                returns = trades_df[pnl_col].dropna().tolist()
                result["trade_stats"] = _calculate_trade_stats(returns)

                if len(returns) > 0:
                    wins = [r for r in returns if r > 0]
                    losses = [r for r in returns if r < 0]
                    if wins and losses:
                        avg_win = sum(wins) / len(wins)
                        avg_loss = abs(sum(losses) / len(losses))
                        win_rate = len(wins) / len(returns)
                        result["kelly_fraction"] = kelly_criterion(win_rate, avg_win, avg_loss)
                        result["ruin_probability"] = ruin_probability(
                            win_rate, avg_win / avg_loss if avg_loss > 0 else 1, len(returns)
                        )

        started = utc_now_iso()

        if output_json or pretty:
            emit_json_line(
                success_envelope(
                    command,
                    result,
                    meta={"startedAt": started, "finishedAt": utc_now_iso()},
                ),
                pretty=pretty,
            )
        else:
            click.echo(f"\nRisk Analysis")
            click.echo(f"=============")
            click.echo(f"Capital: ${capital:,.2f}")
            click.echo(f"Risk per trade: {risk_per_trade:.2%} (${capital * risk_per_trade:,.2f})")
            click.echo(f"")

            if "position" in result:
                pos = result["position"]
                click.echo(f"Position Sizing:")
                click.echo(f"  Shares: {pos.get('shares', 0):,}")
                click.echo(f"  Position value: ${pos.get('position_size', 0):,.2f}")
                click.echo(f"  Dollar risk: ${pos.get('dollar_risk', 0):,.2f}")
                if "risk_per_share" in pos:
                    click.echo(f"  Risk per share: ${pos['risk_per_share']:.4f}")
                if "stop_loss" in pos and pos["stop_loss"]:
                    click.echo(f"  Stop-loss: ${pos['stop_loss']:.4f}")
                if "leverage" in pos:
                    click.echo(f"  Leverage: {pos['leverage']:.2f}x")
                click.echo(f"")

            if result.get("risk_reward_ratio") is not None:
                click.echo(f"Risk-Reward Ratio: {result['risk_reward_ratio']:.2f}")
                click.echo(f"")

            if "trade_stats" in result:
                stats = result["trade_stats"]
                click.echo(f"Trade History Risk Metrics:")
                click.echo(f"  VaR (95%): {stats.get('var_95', 0):.2%}")
                click.echo(f"  VaR (99%): {stats.get('var_99', 0):.2%}")
                click.echo(f"  CVaR (95%): {stats.get('cvar_95', 0):.2%}")
                click.echo(f"  CVaR (99%): {stats.get('cvar_99', 0):.2%}")
                click.echo(f"")

            if result.get("kelly_fraction") is not None:
                click.echo(f"Kelly Criterion: {result['kelly_fraction']:.2%}")
            if result.get("ruin_probability") is not None:
                click.echo(f"Ruin Probability: {result['ruin_probability']:.2%}")

    except QuantpipeCliError as e:
        click.echo(e.message, err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
        sys.exit(e.exit_code)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, "INTERNAL_ERROR", str(e)), pretty=pretty)
        sys.exit(EXIT_GENERAL)
