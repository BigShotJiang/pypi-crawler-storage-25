"""Shared CLI input loading and logging setup."""

from __future__ import annotations

import json
import logging
import sys
from typing import Any, Dict, Optional

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.pipeline_json import unwrap_upstream_json


class QuantpipeCliError(Exception):
    """Raised for predictable CLI failures (carry exit code for rule.md)."""

    def __init__(self, exit_code: int, message: str, error_code: str = "ERROR") -> None:
        self.exit_code = exit_code
        self.message = message
        self.error_code = error_code
        super().__init__(message)


def configure_verbose(verbose: bool) -> None:
    """Route debug logs to stderr; avoid polluting stdout JSON."""
    if verbose:
        logging.basicConfig(
            level=logging.DEBUG,
            format="%(levelname)s %(message)s",
            stream=sys.stderr,
            force=True,
        )
    else:
        logging.basicConfig(level=logging.WARNING, stream=sys.stderr, force=True)


def load_cli_input_dict(*, use_stdin: bool, path: Optional[str]) -> Dict[str, Any]:
    """
    Load JSON object from stdin or file; unwrap seamflux ``{"result": {...}}`` once.
    """
    try:
        if use_stdin or path is None:
            raw: Any = json.load(sys.stdin)
        else:
            with open(path, "r", encoding="utf-8") as f:
                raw = json.load(f)
    except FileNotFoundError as e:
        raise QuantpipeCliError(EXIT_GENERAL, str(e), "IO_ERROR") from e
    except json.JSONDecodeError as e:
        raise QuantpipeCliError(EXIT_SCHEMA, f"Invalid JSON: {e}", "INVALID_JSON") from e
    except OSError as e:
        raise QuantpipeCliError(EXIT_GENERAL, f"I/O error: {e}", "IO_ERROR") from e

    # Bare list (e.g. raw OHLCV array): wrap as {data: [...]} so adapt_data handles it.
    if isinstance(raw, list):
        return {"data": raw}

    if not isinstance(raw, dict):
        raise QuantpipeCliError(EXIT_SCHEMA, "Top-level JSON must be an object or array", "INVALID_INPUT")

    unwrapped = unwrap_upstream_json(raw)
    if not isinstance(unwrapped, dict):
        raise QuantpipeCliError(EXIT_SCHEMA, "Unwrapped payload must be an object", "INVALID_INPUT")
    return unwrapped
