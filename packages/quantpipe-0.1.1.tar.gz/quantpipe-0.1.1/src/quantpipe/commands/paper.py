"""Paper trading command for QuantPipe."""

import json
import logging
import os
import shlex
import subprocess
import sys
import time
from datetime import datetime
from typing import Optional

import click

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA, EXIT_UPSTREAM
from ..core.data import prepare_data
from ..core.pipeline_json import (
    emit_json_line,
    failure_envelope,
    success_envelope,
    unwrap_upstream_json,
    utc_now_iso,
)
from ..strategies import STRATEGIES
from .io_util import QuantpipeCliError, configure_verbose, load_cli_input_dict

log = logging.getLogger(__name__)


def _parse_strategy_params(params: tuple) -> dict:
    strategy_params = {}
    for param in params:
        if "=" not in param:
            raise QuantpipeCliError(EXIT_GENERAL, f"Invalid param format '{param}'. Use key=value", "INVALID_PARAM")
        key, value = param.split("=", 1)
        try:
            if "." in value:
                value = float(value)
            else:
                value = int(value)
        except ValueError:
            pass
        strategy_params[key] = value
    return strategy_params


def _emit_paper_line(
    *,
    command: str,
    result: dict,
    output_json: bool,
    pretty: bool,
    human: bool,
) -> None:
    if "error" in result:
        if output_json or pretty:
            emit_json_line(
                failure_envelope(command, "INVALID_INPUT", str(result["error"])),
                pretty=pretty,
            )
        elif human:
            click.echo(f"Error: {result['error']}", err=True)
        return

    if output_json or pretty:
        emit_json_line(success_envelope(command, result), pretty=pretty)
    elif human:
        sig = result["signal"]
        pos_change = "->" if result["paperTrading"]["positionChanged"] else "(no change)"
        prev = result["paperTrading"]["previousPosition"] or "FLAT"
        curr = result["paperTrading"]["currentPosition"] or "FLAT"
        click.echo(
            f"[{result['timestamp']}] {sig['action']} @ {sig['price']} | Position: {prev} {pos_change} {curr}"
        )


@click.command(name="paper")
@click.option("--data", "-d", "data_path", type=str, default=None, help="Data file path (JSON)")
@click.option("--input", "-i", "input_path", type=str, default=None, help="Alias for --data")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from stdin continuously")
@click.option(
    "--exec",
    "exec_cmd",
    type=str,
    help="Shell-style command line split into argv (no shell); e.g. seamflux invoke binance fetchOhlcv --pipe -p symbol=BTC/USDT -p interval=5m -p limit=50",
)
@click.option("--interval", type=int, default=60, help="Polling interval in seconds (when using --exec)")
@click.option(
    "--exec-timeout",
    type=int,
    default=120,
    help="Timeout in seconds for each --exec invocation",
)
@click.option("--once", is_flag=True, help="Run once and exit")
@click.option("--strategy", "-s", required=True, help="Strategy name")
@click.option("--param", "params", multiple=True, help="Strategy parameters (key=value)")
@click.option("--json", "output_json", is_flag=True, help="Machine-readable JSON (NDJSON when streaming)")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON (not for pipes)")
@click.option("--verbose", "-v", is_flag=True, help="Debug logs on stderr")
@click.option(
    "--dry-run",
    is_flag=True,
    help="Validate strategy and --exec argv parsing only (no subprocess, no stdin read)",
)
def paper_command(
    data_path: Optional[str],
    input_path: Optional[str],
    use_stdin: bool,
    exec_cmd: Optional[str],
    interval: int,
    exec_timeout: int,
    once: bool,
    strategy: str,
    params: tuple,
    output_json: bool,
    pretty: bool,
    verbose: bool,
    dry_run: bool,
):
    """Paper trading - simulate trading with real-time signals (supports LONG and SHORT)."""
    configure_verbose(verbose)
    command = "paper"
    path = input_path or data_path

    try:
        strategy_params = _parse_strategy_params(params)
    except QuantpipeCliError as e:
        click.echo(e.message, err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
        sys.exit(e.exit_code)

    if strategy not in STRATEGIES:
        msg = f"Unknown strategy '{strategy}'. Available: {', '.join(STRATEGIES.keys())}"
        click.echo(f"Error: {msg}", err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, "INVALID_INPUT", msg), pretty=pretty)
        sys.exit(EXIT_GENERAL)

    StrategyClass = STRATEGIES[strategy]

    if dry_run:
        if exec_cmd:
            try:
                args = shlex.split(exec_cmd, posix=os.name != "nt")
            except ValueError as e:
                click.echo(f"Invalid --exec: {e}", err=True)
                if output_json or pretty:
                    emit_json_line(failure_envelope(command, "INVALID_INPUT", str(e)), pretty=pretty)
                sys.exit(EXIT_GENERAL)
            if not args:
                click.echo("Error: --exec parsed to empty argv", err=True)
                sys.exit(EXIT_GENERAL)
            log.debug("Dry run: exec argv=%s", args)
        started = utc_now_iso()
        body = {
            "dryRun": True,
            "strategy": strategy,
            "execArgv": shlex.split(exec_cmd, posix=os.name != "nt") if exec_cmd else None,
        }
        if output_json or pretty:
            emit_json_line(
                success_envelope(command, body, meta={"startedAt": started, "finishedAt": utc_now_iso()}),
                pretty=pretty,
            )
        else:
            click.echo("\nDry run OK")
            click.echo(f"Strategy: {strategy}")
            if exec_cmd:
                click.echo(f"Exec argv: {body['execArgv']}")
        return

    session_start = datetime.utcnow()
    signals_generated = 0
    current_position: Optional[str] = None

    def process_signal(input_data: dict) -> dict:
        nonlocal current_position, signals_generated

        try:
            df, metadata = prepare_data(input_data)
        except Exception as e:
            return {"error": str(e)}

        strat = StrategyClass(params=strategy_params)

        try:
            signal = strat.generate_signal(df, metadata)
        except Exception as e:
            return {"error": str(e)}

        signals_generated += 1

        position_changed = False
        previous_position = current_position

        if signal.action == "BUY":
            if current_position is None:
                current_position = "LONG"
                position_changed = True
            elif current_position == "SHORT":
                current_position = None
                position_changed = True

        elif signal.action == "SELL":
            if current_position is None:
                current_position = "SHORT"
                position_changed = True
            elif current_position == "LONG":
                current_position = None
                position_changed = True

        return {
            "timestamp": signal.timestamp,
            "mode": "paper",
            "session": {
                "startedAt": session_start.isoformat() + "Z",
                "signalsGenerated": signals_generated,
            },
            "source": {
                "symbol": metadata.get("symbol"),
                "type": metadata.get("type"),
            },
            "strategy": {
                "name": strategy,
                "params": signal.params,
            },
            "signal": {
                "action": signal.action,
                "price": signal.price,
                "confidence": signal.confidence,
                "reason": signal.reason,
            },
            "paperTrading": {
                "previousPosition": previous_position,
                "currentPosition": current_position,
                "positionChanged": position_changed,
            },
        }

    if once:
        try:
            input_data = load_cli_input_dict(use_stdin=use_stdin, path=path)
        except QuantpipeCliError as e:
            click.echo(e.message, err=True)
            if output_json or pretty:
                emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
            sys.exit(e.exit_code)

        result = process_signal(input_data)
        human = not (output_json or pretty)
        if "error" in result:
            _emit_paper_line(command=command, result=result, output_json=output_json, pretty=pretty, human=human)
            sys.exit(EXIT_GENERAL)
        _emit_paper_line(command=command, result=result, output_json=output_json, pretty=pretty, human=human)

    elif exec_cmd:
        try:
            args = shlex.split(exec_cmd, posix=os.name != "nt")
        except ValueError as e:
            click.echo(f"Invalid --exec: {e}", err=True)
            if output_json or pretty:
                emit_json_line(failure_envelope(command, "INVALID_INPUT", str(e)), pretty=pretty)
            sys.exit(EXIT_GENERAL)
        if not args:
            click.echo("Error: --exec parsed to empty argv", err=True)
            sys.exit(EXIT_GENERAL)

        try:
            while True:
                try:
                    completed = subprocess.run(
                        args,
                        capture_output=True,
                        text=True,
                        timeout=exec_timeout,
                        shell=False,
                    )
                except subprocess.TimeoutExpired:
                    msg = f"--exec timed out after {exec_timeout}s"
                    click.echo(msg, err=True)
                    if output_json or pretty:
                        emit_json_line(failure_envelope(command, "UPSTREAM_TIMEOUT", msg), pretty=pretty)
                    sys.exit(EXIT_UPSTREAM)
                except FileNotFoundError:
                    msg = f"Executable not found: {args[0]}"
                    click.echo(msg, err=True)
                    if output_json or pretty:
                        emit_json_line(failure_envelope(command, "UPSTREAM_UNAVAILABLE", msg), pretty=pretty)
                    sys.exit(EXIT_UPSTREAM)

                if completed.returncode != 0:
                    err_tail = (completed.stderr or completed.stdout or "").strip()[:500]
                    msg = f"Command failed (exit {completed.returncode}): {err_tail}"
                    click.echo(msg, err=True)
                    if output_json or pretty:
                        emit_json_line(
                            failure_envelope(command, "UPSTREAM_ERROR", msg),
                            pretty=pretty,
                        )
                    sys.exit(EXIT_UPSTREAM)

                try:
                    input_data = json.loads(completed.stdout)
                except json.JSONDecodeError as e:
                    click.echo(f"Invalid JSON from command: {e}", err=True)
                    if output_json or pretty:
                        emit_json_line(failure_envelope(command, "INVALID_JSON", str(e)), pretty=pretty)
                    sys.exit(EXIT_SCHEMA)

                if isinstance(input_data, dict):
                    input_data = unwrap_upstream_json(input_data)
                if not isinstance(input_data, dict):
                    msg = "Command output must be a JSON object"
                    click.echo(msg, err=True)
                    if output_json or pretty:
                        emit_json_line(failure_envelope(command, "INVALID_INPUT", msg), pretty=pretty)
                    sys.exit(EXIT_SCHEMA)

                result = process_signal(input_data)
                human = not (output_json or pretty)
                _emit_paper_line(command=command, result=result, output_json=output_json, pretty=pretty, human=human)

                time.sleep(interval)

        except KeyboardInterrupt:
            click.echo("\nPaper trading stopped.", err=True)

    elif use_stdin:
        try:
            buffer = ""
            for line in sys.stdin:
                buffer += line
                try:
                    input_data = json.loads(buffer)
                    buffer = ""
                except json.JSONDecodeError:
                    continue

                if isinstance(input_data, dict):
                    input_data = unwrap_upstream_json(input_data)
                if not isinstance(input_data, dict):
                    click.echo("Skipping non-object JSON", err=True)
                    continue

                result = process_signal(input_data)
                human = not (output_json or pretty)
                _emit_paper_line(command=command, result=result, output_json=output_json, pretty=pretty, human=human)

        except KeyboardInterrupt:
            click.echo("\nPaper trading stopped.", err=True)

    else:
        if path:
            try:
                input_data = load_cli_input_dict(use_stdin=False, path=path)
            except QuantpipeCliError as e:
                click.echo(e.message, err=True)
                if output_json or pretty:
                    emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
                sys.exit(e.exit_code)

            result = process_signal(input_data)
            human = not (output_json or pretty)
            if "error" in result:
                _emit_paper_line(command=command, result=result, output_json=output_json, pretty=pretty, human=human)
                sys.exit(EXIT_GENERAL)
            _emit_paper_line(command=command, result=result, output_json=output_json, pretty=pretty, human=human)
        else:
            click.echo("Error: Must provide --data/--input, --stdin, --exec, or --once", err=True)
            sys.exit(EXIT_GENERAL)
