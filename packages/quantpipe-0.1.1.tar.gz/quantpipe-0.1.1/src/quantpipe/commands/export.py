"""Export command for QuantPipe."""

from __future__ import annotations

import json
import logging
import os
import sys
from typing import Any, Dict, List, Optional

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from .io_util import QuantpipeCliError, configure_verbose

log = logging.getLogger(__name__)


def _find_runs(run_id: Optional[str]) -> List[str]:
    """Find run directories matching run_id or all runs."""
    runs = []

    if run_id:
        path = os.path.join(os.getcwd(), "runs", run_id)
        if os.path.isdir(path):
            runs.append(path)
    else:
        runs_dir = os.path.join(os.getcwd(), "runs")
        if os.path.isdir(runs_dir):
            for entry in os.listdir(runs_dir):
                entry_path = os.path.join(runs_dir, entry)
                if os.path.isdir(entry_path):
                    runs.append(entry_path)

    return sorted(runs)


def _load_run_data(run_path: str, includes: List[str]) -> Dict[str, Any]:
    """Load data from a single run directory."""
    data: Dict[str, Any] = {"run_id": os.path.basename(run_path)}

    summary_path = os.path.join(run_path, "summary.json")
    if "summary" in includes and os.path.exists(summary_path):
        try:
            with open(summary_path, "r", encoding="utf-8") as f:
                data["summary"] = json.load(f)
        except Exception:
            pass

    trades_path = os.path.join(run_path, "trades.csv")
    if "trades" in includes and os.path.exists(trades_path):
        try:
            data["trades"] = pd.read_csv(trades_path).to_dict(orient="records")
        except Exception:
            pass

    equity_path = os.path.join(run_path, "equity.csv")
    if "equity" in includes and os.path.exists(equity_path):
        try:
            data["equity"] = pd.read_csv(equity_path).to_dict(orient="records")
        except Exception:
            pass

    manifest_path = os.path.join(run_path, "manifest.json")
    if os.path.exists(manifest_path):
        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                data["manifest"] = json.load(f)
        except Exception:
            pass

    return data


def _export_to_csv(runs: List[str], includes: List[str], output_path: str) -> None:
    """Export runs data to CSV."""
    all_data = []

    for run_path in runs:
        data = _load_run_data(run_path, includes)
        run_id = data.get("run_id", "unknown")

        if "trades" in data and isinstance(data["trades"], list):
            for trade in data["trades"]:
                trade["run_id"] = run_id
                all_data.append(trade)

    if all_data:
        df = pd.DataFrame(all_data)
        df.to_csv(output_path, index=False)
    else:
        pd.DataFrame().to_csv(output_path, index=False)


def _export_to_json(runs: List[str], includes: List[str], output_path: str) -> None:
    """Export runs data to JSON."""
    result = {
        "schemaVersion": 1,
        "tool": "quantpipe",
        "command": "export",
        "runs": [_load_run_data(run_path, includes) for run_path in runs],
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, default=str)


def _export_to_parquet(runs: List[str], includes: List[str], output_path: str) -> None:
    """Export runs data to Parquet."""
    all_data = []

    for run_path in runs:
        data = _load_run_data(run_path, includes)
        run_id = data.get("run_id", "unknown")

        if "trades" in data and isinstance(data["trades"], list):
            for trade in data["trades"]:
                trade["run_id"] = run_id
                all_data.append(trade)

    if all_data:
        df = pd.DataFrame(all_data)
        df.to_parquet(output_path, index=False)
    else:
        pd.DataFrame().to_parquet(output_path, index=False)


@click.command(name="export")
@click.option("--runs", "-r", "run_id", type=str, default=None,
              help="runs/ directory or specific run id to export")
@click.option("--output", "-o", "output_path", type=click.Path(), required=True,
              help="Output file path")
@click.option("--format", "-f", "output_format", type=click.Choice(["csv", "json", "parquet"]),
              default="csv", help="Output format (default: csv)")
@click.option("--include", "includes", multiple=True,
              type=click.Choice(["trades", "equity", "summary"]),
              default=["trades", "equity", "summary"],
              help="Data to include (default: all)")
@click.option("--json", "output_json", is_flag=True, help="Machine-readable JSON envelope on stdout")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON (not for pipes)")
@click.option("--verbose", "-v", is_flag=True, help="Debug logs on stderr")
def export_command(
    run_id: Optional[str],
    output_path: str,
    output_format: str,
    includes: tuple,
    output_json: bool,
    pretty: bool,
    verbose: bool,
):
    """Export backtest runs to CSV, JSON, or Parquet format.

    Examples:
        # Export all runs to CSV
        quantpipe export --output results.csv --format csv

        # Export specific run to JSON
        quantpipe export --runs backtest_001 --output result.json --format json

        # Export only trades to parquet
        quantpipe export --runs run123 --output trades.parquet --include trades --format parquet
    """
    configure_verbose(verbose)
    command = "export"

    try:
        include_list = list(includes) if includes else ["trades", "equity", "summary"]

        if not output_path:
            raise QuantpipeCliError(EXIT_GENERAL, "Output path is required", "INVALID_PARAM")

        runs_found = _find_runs(run_id)

        if not runs_found:
            if output_format == "json":
                result = {
                    "schemaVersion": 1,
                    "tool": "quantpipe",
                    "command": "export",
                    "ok": True,
                    "runs": [],
                    "message": "No runs found",
                }
                with open(output_path, "w", encoding="utf-8") as f:
                    json.dump(result, f, indent=2, default=str)
            else:
                if output_format == "parquet":
                    pd.DataFrame().to_parquet(output_path, index=False)
                else:
                    pd.DataFrame().to_csv(output_path, index=False)

            started = utc_now_iso()
            if output_json or pretty:
                emit_json_line(
                    success_envelope(
                        command,
                        {"runs_found": 0, "output": output_path, "format": output_format},
                        meta={"startedAt": started, "finishedAt": utc_now_iso()},
                    ),
                    pretty=pretty,
                )
            else:
                click.echo(f"No runs found.")
            return

        started = utc_now_iso()

        if output_format == "csv":
            _export_to_csv(runs_found, include_list, output_path)
        elif output_format == "json":
            _export_to_json(runs_found, include_list, output_path)
        elif output_format == "parquet":
            _export_to_parquet(runs_found, include_list, output_path)

        if output_json or pretty:
            emit_json_line(
                success_envelope(
                    command,
                    {
                        "runs_found": len(runs_found),
                        "output": output_path,
                        "format": output_format,
                        "included": include_list,
                    },
                    meta={"startedAt": started, "finishedAt": utc_now_iso()},
                ),
                pretty=pretty,
            )
        else:
            click.echo(f"Exported {len(runs_found)} runs to {output_path}")

    except QuantpipeCliError as e:
        click.echo(e.message, err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
        sys.exit(e.exit_code)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, "INTERNAL_ERROR", str(e)), pretty=pretty)
        sys.exit(EXIT_GENERAL)
