"""Parameter optimization command for QuantPipe."""

from __future__ import annotations

import logging
import sys
from typing import Any, Dict, List, Optional

import click
import pandas as pd

from ..cli_exit import EXIT_GENERAL, EXIT_SCHEMA
from ..core.data import prepare_data
from ..core.optimizer import (
    bayesian_optimize,
    grid_search,
    parameter_sensitivity,
    parse_param_range,
)
from ..core.pipeline_json import emit_json_line, failure_envelope, success_envelope, utc_now_iso
from ..strategies import STRATEGIES
from .io_util import QuantpipeCliError, configure_verbose, load_cli_input_dict

log = logging.getLogger(__name__)


def _parse_strategy_params(params: tuple) -> dict:
    """Parse strategy parameter key=value pairs."""
    strategy_params = {}
    for param in params:
        if "=" not in param:
            raise QuantpipeCliError(
                EXIT_GENERAL,
                f"Invalid param format '{param}'. Use key=value",
                "INVALID_PARAM",
            )
        key, value = param.split("=", 1)
        try:
            if "." in value:
                value = float(value)
            else:
                value = int(value)
        except ValueError:
            pass
        strategy_params[key] = value
    return strategy_params


def _parse_param_ranges(param_ranges: tuple) -> Dict[str, List[Any]]:
    """Parse parameter ranges."""
    ranges = {}
    for pr in param_ranges:
        try:
            key, values = parse_param_range(pr)
            ranges[key] = values
        except ValueError as e:
            raise QuantpipeCliError(EXIT_GENERAL, str(e), "INVALID_PARAM")
    return ranges


def _validate_param_ranges(
    strategy_class,
    param_ranges: Dict[str, List[Any]],
) -> None:
    """Validate that parameter ranges are compatible with strategy."""
    default_params = getattr(strategy_class, "default_params", {})
    valid_keys = set(default_params.keys())

    for key in param_ranges.keys():
        if key not in valid_keys:
            raise QuantpipeCliError(
                EXIT_GENERAL,
                f"Unknown parameter '{key}'. Valid params for {strategy_class.name}: {', '.join(valid_keys)}",
                "INVALID_PARAM",
            )


@click.command(name="optimize")
@click.option("--strategy", "-s", required=True, help="Strategy name")
@click.option("--params", "-p", "param_ranges", multiple=True,
              help="Parameter ranges, e.g.: fast=10-50 or period=14,20,30")
@click.option("--data", "-d", "data_path", type=str, default=None, help="Data file path (JSON)")
@click.option("--stdin", "use_stdin", is_flag=True, help="Read data from stdin")
@click.option("--method", type=click.Choice(["grid", "bayesian"]), default="grid",
              help="Optimization method (default: grid)")
@click.option("--metric", type=click.Choice(["sharpe", "total", "calmar"]), default="sharpe",
              help="Optimization metric (default: sharpe)")
@click.option("--trials", type=int, default=100,
              help="Max trials for Bayesian optimization (default: 100)")
@click.option("--top", type=int, default=5, help="Number of top results to show (default: 5)")
@click.option("--json", "output_json", is_flag=True, help="Machine-readable JSON envelope on stdout")
@click.option("--pretty", is_flag=True, help="Pretty-print JSON (not for pipes)")
@click.option("--verbose", "-v", is_flag=True, help="Debug logs on stderr")
def optimize_command(
    strategy: str,
    param_ranges: tuple,
    data_path: Optional[str],
    use_stdin: bool,
    method: str,
    metric: str,
    trials: int,
    top: int,
    output_json: bool,
    pretty: bool,
    verbose: bool,
):
    """Parameter optimization: grid search or Bayesian optimization for strategy parameters.

    Examples:
        # Grid search for MA crossover
        quantpipe optimize --strategy ma_cross --params fast=5-20 --params slow=10-50 --data data.json

        # Bayesian optimization with custom metric
        quantpipe optimize -s rsi --params period=5-30 --method bayesian --metric sharpe --trials 50

        # From pipeline
        seamflux invoke binance fetchOhlcv | quantpipe optimize -s macd --params fast=5-15 --params slow=20-50
    """
    configure_verbose(verbose)
    command = "optimize"

    try:
        if strategy not in STRATEGIES:
            raise QuantpipeCliError(
                EXIT_GENERAL,
                f"Unknown strategy '{strategy}'. Available: {', '.join(STRATEGIES.keys())}",
                "INVALID_INPUT",
            )

        if not param_ranges:
            raise QuantpipeCliError(
                EXIT_GENERAL,
                "At least one --params range is required",
                "INVALID_PARAM",
            )

        StrategyClass = STRATEGIES[strategy]
        ranges = _parse_param_ranges(param_ranges)
        _validate_param_ranges(StrategyClass, ranges)

        try:
            input_data = load_cli_input_dict(use_stdin=use_stdin, path=data_path)
        except QuantpipeCliError as e:
            raise e

        try:
            df, metadata = prepare_data(input_data)
        except Exception as e:
            raise QuantpipeCliError(EXIT_SCHEMA, f"Error preparing data: {e}", "INVALID_INPUT")

        if len(df) < 50:
            raise QuantpipeCliError(
                EXIT_GENERAL,
                f"Insufficient data: {len(df)} bars. Need at least 50.",
                "INSUFFICIENT_DATA",
            )

        started = utc_now_iso()

        if method == "grid":
            results = grid_search(StrategyClass, ranges, df, metric)
        else:
            param_space = {}
            for key, values in ranges.items():
                if all(isinstance(v, int) for v in values):
                    param_space[key] = (min(values), max(values), "int")
                else:
                    param_space[key] = (min(values), max(values), "float")

            def objective_fn(params):
                strat = StrategyClass(params=params)
                from ..core.backtest import BacktestEngine
                engine = BacktestEngine(strat, df)
                m = engine.run()
                return m.get("sharpe_ratio", 0)

            results = bayesian_optimize(objective_fn, param_space, trials, metric)

        if not results:
            raise QuantpipeCliError(
                EXIT_GENERAL,
                "Optimization produced no results",
                "NO_RESULTS",
            )

        top_results = results[:min(top, len(results))]
        best = results[0]

        sensitivities = []
        for param_name in ranges.keys():
            sens = parameter_sensitivity(results, param_name)
            if sens:
                sensitivities.append(sens)

        data_body = {
            "strategy": strategy,
            "method": method,
            "metric": metric,
            "total_trials": len(results),
            "best": {
                "params": best.get("params", {}),
                "metrics": {
                    "total_return": best.get("total_return"),
                    "sharpe_ratio": best.get("sharpe_ratio"),
                    "max_drawdown": best.get("max_drawdown"),
                    "calmar_ratio": best.get("calmar_ratio"),
                    "win_rate": best.get("win_rate"),
                    "total_trades": best.get("total_trades"),
                },
            },
            "top_results": [
                {
                    "params": r.get("params", {}),
                    metric: r.get(metric),
                    "sharpe_ratio": r.get("sharpe_ratio"),
                    "total_return": r.get("total_return"),
                }
                for r in top_results
            ],
            "sensitivities": sensitivities,
        }

        finished = utc_now_iso()

        if output_json or pretty:
            emit_json_line(
                success_envelope(
                    command,
                    data_body,
                    meta={"startedAt": started, "finishedAt": finished},
                ),
                pretty=pretty,
            )
        else:
            click.echo(f"\nOptimization Results")
            click.echo(f"====================")
            click.echo(f"Strategy: {strategy}")
            click.echo(f"Method: {method}")
            click.echo(f"Metric: {metric}")
            click.echo(f"Total trials: {len(results)}")
            click.echo(f"")
            click.echo(f"Best Parameters:")
            for k, v in best.get("params", {}).items():
                click.echo(f"  {k}: {v}")
            click.echo(f"")
            click.echo(f"Best Metrics:")
            click.echo(f"  {metric}: {best.get(metric, 0):.4f}")
            click.echo(f"  Sharpe: {best.get('sharpe_ratio', 0):.4f}")
            click.echo(f"  Total Return: {best.get('total_return', 0):.2%}")
            click.echo(f"  Max Drawdown: {best.get('max_drawdown', 0):.2%}")
            click.echo(f"  Win Rate: {best.get('win_rate', 0):.2%}")
            click.echo(f"")
            click.echo(f"Top {len(top_results)} Results:")
            for i, r in enumerate(top_results):
                click.echo(f"  #{i+1}: {r.get('params', {})} -> {metric}={r.get(metric, 0):.4f}")

    except QuantpipeCliError as e:
        click.echo(e.message, err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, e.error_code, e.message), pretty=pretty)
        sys.exit(e.exit_code)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        if output_json or pretty:
            emit_json_line(failure_envelope(command, "INTERNAL_ERROR", str(e)), pretty=pretty)
        sys.exit(EXIT_GENERAL)
