import io
import unittest
from unittest.mock import patch


from quantpipe.core.data import load_data


class TestLoadData(unittest.TestCase):
    def test_load_data_accepts_textio(self) -> None:
        buf = io.StringIO('{"a": 1}')
        self.assertEqual(load_data(buf), {"a": 1})

    def test_load_data_dash_reads_stdin(self) -> None:
        with patch("sys.stdin", io.StringIO('{"x": 2}')):
            self.assertEqual(load_data("-"), {"x": 2})


if __name__ == "__main__":
    unittest.main()

