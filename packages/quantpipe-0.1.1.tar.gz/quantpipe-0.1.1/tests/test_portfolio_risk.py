"""Tests for portfolio and risk modules."""

import sys
from pathlib import Path

import pandas as pd
import numpy as np
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from quantpipe.core.portfolio import (
    calculate_portfolio_metrics,
    correlation_matrix,
    sharpe_ratio,
    sortino_ratio,
    max_drawdown,
    calmar_ratio,
)
from quantpipe.core.risk import (
    position_sizing,
    calculate_var,
    calculate_cvar,
    kelly_criterion,
    calculate_risk_reward,
    ruin_probability,
)


class TestPortfolioMetrics(unittest.TestCase):
    """Tests for portfolio calculation functions."""

    def test_calculate_portfolio_metrics_empty(self):
        """Test with empty trades list."""
        result = calculate_portfolio_metrics([])
        self.assertEqual(result, {})

    def test_calculate_portfolio_metrics_single_strategy(self):
        """Test with single strategy."""
        trades = [pd.DataFrame({"pnl_pct": [0.01, -0.005, 0.02, 0.015]})]
        result = calculate_portfolio_metrics(trades)
        
        self.assertIn("total_return", result)
        self.assertIn("sharpe_ratio", result)
        self.assertIn("max_drawdown", result)

    def test_calculate_portfolio_metrics_multiple_strategies(self):
        """Test with multiple strategies and weights."""
        trades = [
            pd.DataFrame({"pnl_pct": [0.01, 0.02, 0.015]}),
            pd.DataFrame({"pnl_pct": [-0.005, 0.01, 0.008]}),
        ]
        weights = [0.6, 0.4]
        result = calculate_portfolio_metrics(trades, weights=weights)
        
        self.assertIn("weights", result)
        self.assertAlmostEqual(sum(result["weights"]), 1.0, places=5)

    def test_calculate_portfolio_metrics_weights_normalization(self):
        """Test that weights are normalized."""
        trades = [
            pd.DataFrame({"pnl_pct": [0.01]}),
            pd.DataFrame({"pnl_pct": [0.02]}),
        ]
        weights = [30, 70]  # Sum to 100
        result = calculate_portfolio_metrics(trades, weights=weights)
        
        total = sum(result["weights"])
        self.assertAlmostEqual(total, 1.0, places=5)


class TestCorrelationMatrix(unittest.TestCase):
    """Tests for correlation matrix calculation."""

    def test_correlation_matrix_empty(self):
        """Test with empty trades list."""
        corr, names = correlation_matrix([])
        self.assertTrue(corr.empty)
        self.assertEqual(names, [])

    def test_correlation_matrix_single_strategy(self):
        """Test with single strategy."""
        trades = [pd.DataFrame({"pnl_pct": [0.01, 0.02, 0.015]})]
        corr, names = correlation_matrix(trades)
        
        self.assertEqual(len(names), 1)

    def test_correlation_matrix_two_strategies(self):
        """Test with two strategies."""
        trades = [
            pd.DataFrame({"pnl_pct": [0.01, 0.02, 0.015, 0.01]}),
            pd.DataFrame({"pnl_pct": [0.015, 0.01, 0.02, 0.008]}),
        ]
        corr, names = correlation_matrix(trades)
        
        self.assertEqual(len(names), 2)
        self.assertEqual(corr.shape, (2, 2))


class TestRiskMetrics(unittest.TestCase):
    """Tests for risk metric functions."""

    def test_sharpe_ratio_empty(self):
        """Test Sharpe ratio with empty returns."""
        result = sharpe_ratio([])
        self.assertEqual(result, 0.0)

    def test_sharpe_ratio_calculation(self):
        """Test Sharpe ratio calculation."""
        returns = [0.01, 0.02, -0.005, 0.015, 0.01]
        result = sharpe_ratio(returns)
        self.assertIsInstance(result, float)

    def test_sharpe_ratio_zero_std(self):
        """Test Sharpe ratio with zero standard deviation."""
        returns = [0.01, 0.01, 0.01, 0.01]
        result = sharpe_ratio(returns)
        self.assertEqual(result, 0.0)

    def test_sortino_ratio_empty(self):
        """Test Sortino ratio with empty returns."""
        result = sortino_ratio([])
        self.assertEqual(result, 0.0)

    def test_sortino_ratio_calculation(self):
        """Test Sortino ratio calculation."""
        returns = [0.01, 0.02, -0.005, 0.015, 0.01]
        result = sortino_ratio(returns)
        self.assertIsInstance(result, float)

    def test_sortino_ratio_no_downside(self):
        """Test Sortino ratio when no downside returns."""
        returns = [0.01, 0.02, 0.015, 0.01]
        result = sortino_ratio(returns)
        self.assertEqual(result, 0.0)

    def test_max_drawdown_empty(self):
        """Test max drawdown with empty equity curve."""
        result = max_drawdown([])
        self.assertEqual(result, 0.0)

    def test_max_drawdown_increasing(self):
        """Test max drawdown with constantly increasing equity."""
        equity = [100, 110, 120, 130, 140]
        result = max_drawdown(equity)
        self.assertEqual(result, 0.0)

    def test_max_drawdown_with_drawdown(self):
        """Test max drawdown calculation."""
        equity = [100, 110, 120, 100, 110, 90]
        result = max_drawdown(equity)
        self.assertGreater(result, 0.0)

    def test_calmar_ratio_zero_drawdown(self):
        """Test Calmar ratio with zero drawdown."""
        result = calmar_ratio(0.15, 0.0)
        self.assertEqual(result, 0.0)

    def test_calmar_ratio_normal(self):
        """Test Calmar ratio normal case."""
        result = calmar_ratio(0.20, 0.10)
        self.assertEqual(result, 2.0)


class TestPositionSizing(unittest.TestCase):
    """Tests for position sizing functions."""

    def test_position_sizing_zero_capital(self):
        """Test with zero capital."""
        result = position_sizing(0, 0.02, 100, 95)
        self.assertEqual(result["position_size"], 0.0)
        self.assertEqual(result["shares"], 0)

    def test_position_sizing_zero_risk(self):
        """Test with zero risk per trade."""
        result = position_sizing(10000, 0, 100, 95)
        self.assertEqual(result["position_size"], 0.0)

    def test_position_sizing_zero_price_risk(self):
        """Test when entry equals stop loss."""
        result = position_sizing(10000, 0.02, 100, 100)
        self.assertEqual(result["position_size"], 0.0)

    def test_position_sizing_normal(self):
        """Test normal position sizing."""
        result = position_sizing(10000, 0.02, 100, 95)
        
        self.assertGreater(result["position_size"], 0)
        self.assertGreater(result["shares"], 0)
        self.assertEqual(result["dollar_risk"], 200)

    def test_position_sizing_leverage(self):
        """Test leverage calculation."""
        result = position_sizing(10000, 0.02, 100, 95)
        self.assertIn("leverage", result)


class TestVaRandCVaR(unittest.TestCase):
    """Tests for VaR and CVaR functions."""

    def test_var_empty(self):
        """Test VaR with empty returns."""
        result = calculate_var([])
        self.assertEqual(result, 0.0)

    def test_var_calculation(self):
        """Test VaR calculation."""
        returns = [-0.01, 0.02, -0.015, 0.01, -0.02]
        result = calculate_var(returns, confidence=0.95)
        self.assertGreater(result, 0.0)

    def test_var_confidence_levels(self):
        """Test VaR at different confidence levels."""
        returns = [-0.01, -0.02, -0.03, -0.04, 0.01, 0.02]
        var_95 = calculate_var(returns, confidence=0.95)
        var_99 = calculate_var(returns, confidence=0.99)
        
        self.assertGreaterEqual(var_99, var_95)

    def test_cvar_empty(self):
        """Test CVaR with empty returns."""
        result = calculate_cvar([])
        self.assertEqual(result, 0.0)

    def test_cvar_calculation(self):
        """Test CVaR calculation."""
        returns = [-0.01, 0.02, -0.015, 0.01, -0.02]
        result = calculate_cvar(returns, confidence=0.95)
        self.assertGreater(result, 0.0)


class TestKellyCriterion(unittest.TestCase):
    """Tests for Kelly Criterion."""

    def test_kelly_zero_loss(self):
        """Test Kelly with zero average loss."""
        result = kelly_criterion(0.6, 100, 0)
        self.assertEqual(result, 0.0)

    def test_kelly_invalid_win_rate(self):
        """Test Kelly with invalid win rate."""
        result = kelly_criterion(0, 100, 50)
        self.assertEqual(result, 0.0)
        result = kelly_criterion(1, 100, 50)
        self.assertEqual(result, 0.0)

    def test_kelly_calculation(self):
        """Test Kelly calculation."""
        result = kelly_criterion(0.6, 100, 50)
        self.assertGreater(result, 0.0)
        self.assertLessEqual(result, 1.0)


class TestRiskReward(unittest.TestCase):
    """Tests for risk-reward ratio."""

    def test_risk_reward_zero_risk(self):
        """Test risk-reward with zero risk."""
        result = calculate_risk_reward(100, 110, 100)
        self.assertIsNone(result)

    def test_risk_reward_calculation(self):
        """Test risk-reward calculation."""
        result = calculate_risk_reward(100, 120, 90)
        self.assertEqual(result, 2.0)  # reward=20, risk=10


class TestRuinProbability(unittest.TestCase):
    """Tests for ruin probability."""

    def test_ruin_invalid_params(self):
        """Test ruin probability with invalid params."""
        result = ruin_probability(0, 2.0, 100)
        self.assertEqual(result, 1.0)
        result = ruin_probability(0.5, 0, 100)
        self.assertEqual(result, 1.0)

    def test_ruin_probability_trivial(self):
        """Test ruin probability with trivial edge case."""
        result = ruin_probability(1.0, 2.0, 100)  # 100% win rate
        self.assertEqual(result, 0.0)

    def test_ruin_probability_calculation(self):
        """Test ruin probability calculation."""
        result = ruin_probability(0.55, 2.0, 100)
        self.assertGreaterEqual(result, 0.0)
        self.assertLessEqual(result, 1.0)


if __name__ == "__main__":
    unittest.main()
