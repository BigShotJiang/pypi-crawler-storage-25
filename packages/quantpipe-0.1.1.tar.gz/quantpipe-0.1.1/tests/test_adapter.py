"""Regression tests for quantpipe data adapter (run: python -m pytest tests/ or unittest)."""

import sys
from pathlib import Path

import unittest

# src layout
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from quantpipe.core.adapter import detect_data_format, adapt_data, DataFormat  # noqa: E402


class TestBinanceTickerFormats(unittest.TestCase):
    def test_single_ticker_detect_and_close_column(self):
        single = {"message": "x", "symbol": "BTCUSDT", "last": 50000.0}
        self.assertEqual(detect_data_format(single), DataFormat.BINANCE_TICKER)
        df, meta = adapt_data(single)
        self.assertEqual(len(df), 1)
        self.assertIn("close", df.columns)
        self.assertEqual(meta["format"], "binance_ticker")

    def test_multi_ticker_early_detect(self):
        multi = {"tickers": [{"symbol": "A", "last": 1}, {"symbol": "B", "last": 2}]}
        self.assertEqual(detect_data_format(multi), DataFormat.BINANCE_TICKERS)

    def test_empty_tickers_falls_back_to_single_ticker(self):
        edge = {"tickers": [], "symbol": "X", "last": 1.0}
        self.assertEqual(detect_data_format(edge), DataFormat.BINANCE_TICKER)


class TestProfitFactorJSONSafe(unittest.TestCase):
    def test_no_trades_profit_factor_none(self):
        import json
        import pandas as pd
        from quantpipe.core.backtest import BacktestEngine
        from quantpipe.strategies.ma_cross import MACrossStrategy

        idx = pd.date_range("2024-01-01", periods=40, freq="h")
        df = pd.DataFrame({"close": [100.0] * 40}, index=idx)
        m = BacktestEngine(MACrossStrategy(), df).run()
        self.assertEqual(m["total_trades"], 0)
        self.assertIsNone(m["profit_factor"])
        json.dumps(m)  # no Infinity

    def test_backtest_metrics_json_serializable(self):
        import json
        import pandas as pd
        from quantpipe.core.backtest import BacktestEngine
        from quantpipe.strategies.ma_cross import MACrossStrategy

        idx = pd.date_range("2024-01-01", periods=60, freq="h")
        df = pd.DataFrame({"close": [100.0 + (i % 5) for i in range(60)]}, index=idx)
        m = BacktestEngine(MACrossStrategy({"fast": 3, "slow": 8}), df).run()
        json.dumps(m)
        pf = m.get("profit_factor")
        if pf is not None:
            self.assertFalse(pf == float("inf"))


if __name__ == "__main__":
    unittest.main()
