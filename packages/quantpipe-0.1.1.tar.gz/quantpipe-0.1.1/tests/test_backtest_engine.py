import unittest
from datetime import datetime, timedelta

import pandas as pd

from quantpipe.core.backtest import BacktestEngine
from quantpipe.strategies.ma_cross import MACrossStrategy


class TestBacktestEngine(unittest.TestCase):
    def test_ma_cross_generates_trades_on_synthetic_series(self) -> None:
        # Construct a price series that rises then falls to force a crossover.
        closes = [1, 2, 3, 4, 5, 4, 3, 2, 1, 2, 3, 4, 5]
        start = datetime(2026, 1, 1)
        idx = [start + timedelta(hours=i) for i in range(len(closes))]
        df = pd.DataFrame({"close": closes}, index=pd.DatetimeIndex(idx))

        strat = MACrossStrategy({"fast": 2, "slow": 3, "ma_type": "sma"})
        engine = BacktestEngine(strat, df, initial_capital=10000.0, commission=0.0)
        metrics = engine.run()

        self.assertGreaterEqual(metrics["total_trades"], 1)
        self.assertGreaterEqual(len(engine.trades), 1)


if __name__ == "__main__":
    unittest.main()

