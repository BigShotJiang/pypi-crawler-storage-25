"""Tests for pipeline JSON envelope and seamflux unwrap."""

import json
import sys
from pathlib import Path

import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from quantpipe.core.pipeline_json import (  # noqa: E402
    SCHEMA_VERSION,
    TOOL_NAME,
    unwrap_upstream_json,
    success_envelope,
    failure_envelope,
    emit_json_line,
)


class TestUnwrapUpstreamJson(unittest.TestCase):
    def test_unwrap_result_dict(self):
        inner = {"candles": [], "message": "x"}
        wrapped = {"result": inner, "meta": 1}
        self.assertIs(unwrap_upstream_json(wrapped), inner)

    def test_no_unwrap_when_result_not_dict(self):
        wrapped = {"result": [1, 2]}
        self.assertEqual(unwrap_upstream_json(wrapped), wrapped)

    def test_plain_payload_unchanged(self):
        p = {"symbol": "BTC", "last": 1}
        self.assertEqual(unwrap_upstream_json(p), p)


class TestEnvelopes(unittest.TestCase):
    def test_success_envelope_shape(self):
        e = success_envelope("backtest", {"performance": {}}, run_id="r1", artifacts={"summary": "a.json"})
        self.assertEqual(e["schemaVersion"], SCHEMA_VERSION)
        self.assertEqual(e["tool"], TOOL_NAME)
        self.assertEqual(e["command"], "backtest")
        self.assertTrue(e["ok"])
        self.assertEqual(e["data"]["performance"], {})
        self.assertEqual(e["runId"], "r1")
        self.assertEqual(e["artifacts"]["summary"], "a.json")

    def test_failure_envelope_shape(self):
        e = failure_envelope("signal", "INVALID_INPUT", "bad")
        self.assertEqual(e["schemaVersion"], SCHEMA_VERSION)
        self.assertFalse(e["ok"])
        self.assertEqual(e["error"]["code"], "INVALID_INPUT")
        self.assertEqual(e["error"]["message"], "bad")

    def test_emit_json_line_single_line_when_not_pretty(self):
        import io
        out = io.StringIO()
        old = sys.stdout
        try:
            sys.stdout = out
            emit_json_line(success_envelope("x", {"a": 1}), pretty=False)
        finally:
            sys.stdout = old
        text = out.getvalue()
        self.assertTrue(text.endswith("\n"))
        self.assertEqual(text.count("\n"), 1)
        obj = json.loads(text.strip())
        self.assertTrue(obj["ok"])


class TestPrepareDataUnwrapsSeamflux(unittest.TestCase):
    def test_prepare_data_unwraps_result_wrapper(self):
        from quantpipe.core.data import prepare_data

        inner = {
            "message": "Fetched candles for BTC/USDT",
            "candles": [
                [1704067200000, 100.0, 110.0, 90.0, 105.0, 1000.0, 0, 0, 0, 0, 0, 0],
                [1704070800000, 105.0, 115.0, 95.0, 108.0, 1200.0, 0, 0, 0, 0, 0, 0],
            ],
        }
        wrapped = {"result": inner, "ok": True}
        df, meta = prepare_data(wrapped)
        self.assertGreater(len(df), 0)
        self.assertEqual(meta.get("format"), "binance_ohlcv")


if __name__ == "__main__":
    unittest.main()
