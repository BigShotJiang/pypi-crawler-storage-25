from skiller.interfaces.cli.main import main

if __name__ == "__main__":
    raise SystemExit(main())
