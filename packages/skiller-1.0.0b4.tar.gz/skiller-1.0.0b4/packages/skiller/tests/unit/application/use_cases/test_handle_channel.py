import pytest

from skiller.application.use_cases.ingress.handle_channel import HandleChannelUseCase
from skiller.domain.wait.match_type import MatchType
from skiller.domain.wait.source_type import SourceType

pytestmark = pytest.mark.unit


class _FakeStore:
    def __init__(self, *, receipt_is_new: bool = True) -> None:
        self.receipt_is_new = receipt_is_new
        self.created_external_events: list[dict[str, object]] = []
        self.receipts: list[dict[str, object]] = []
        self.waits = [{"run_id": "run-1"}]

    def register_external_receipt(
        self,
        dedup_key: str,
        source_type: SourceType,
        source_name: str,
        match_type: MatchType,
        match_key: str,
        payload: dict[str, object],
    ) -> bool:
        self.receipts.append(
            {
                "dedup_key": dedup_key,
                "source_type": source_type,
                "source_name": source_name,
                "match_type": match_type,
                "match_key": match_key,
                "payload": payload,
            }
        )
        return self.receipt_is_new

    def create_external_event(
        self,
        *,
        source_type: SourceType,
        source_name: str,
        match_type: MatchType,
        match_key: str,
        payload: dict[str, object],
        run_id: str | None = None,
        step_id: str | None = None,
        external_id: str | None = None,
        dedup_key: str | None = None,
    ) -> str:
        self.created_external_events.append(
            {
                "source_type": source_type,
                "source_name": source_name,
                "match_type": match_type,
                "match_key": match_key,
                "run_id": run_id,
                "step_id": step_id,
                "external_id": external_id,
                "dedup_key": dedup_key,
                "payload": payload,
            }
        )
        return "channel-1"

    def find_matching_waits(
        self,
        *,
        source_type: SourceType,
        source_name: str,
        match_type: MatchType,
        match_key: str,
    ) -> list[dict[str, object]]:
        _ = (source_type, source_name, match_type, match_key)
        return self.waits


def test_handle_channel_persists_external_event_and_returns_matching_runs() -> None:
    store = _FakeStore()
    use_case = HandleChannelUseCase(external_event_store=store, wait_store=store)

    result = use_case.execute(
        "whatsapp",
        "172584771580071@lid",
        {"text": "hola"},
        external_id="msg-1",
        dedup_key="dedup-1",
    )

    assert result.accepted is True
    assert result.duplicate is False
    assert result.run_ids == ["run-1"]
    assert result.event_id == "channel-1"
    assert store.created_external_events == [
        {
            "source_type": SourceType.CHANNEL,
            "source_name": "whatsapp",
            "match_type": MatchType.CHANNEL_KEY,
            "match_key": "172584771580071@lid",
            "run_id": None,
            "step_id": None,
            "external_id": "msg-1",
            "dedup_key": "dedup-1",
            "payload": {"text": "hola"},
        }
    ]


def test_handle_channel_selects_only_first_matching_run() -> None:
    store = _FakeStore()
    store.waits = [{"run_id": "run-1"}, {"run_id": "run-2"}]
    use_case = HandleChannelUseCase(external_event_store=store, wait_store=store)

    result = use_case.execute(
        "whatsapp",
        "172584771580071@lid",
        {"text": "hola"},
        external_id="msg-1",
        dedup_key="dedup-1",
    )

    assert result.run_ids == ["run-1"]


def test_handle_channel_does_not_resume_wait_for_stale_message_timestamp() -> None:
    store = _FakeStore()
    store.waits = [{"run_id": "run-1", "created_at": "2026-04-20 17:58:17"}]
    use_case = HandleChannelUseCase(external_event_store=store, wait_store=store)

    result = use_case.execute(
        "whatsapp",
        "172584771580071@lid",
        {
            "text": "hola",
            "timestamp": 1775388655,
        },
        external_id="msg-demo-1",
        dedup_key="dedup-demo-1",
    )

    assert result.accepted is True
    assert result.duplicate is False
    assert result.run_ids == []
    assert result.event_id is None
    assert store.created_external_events == []


def test_handle_channel_resumes_wait_for_fresh_message_timestamp() -> None:
    store = _FakeStore()
    store.waits = [{"run_id": "run-1", "created_at": "2026-04-20 17:58:17"}]
    use_case = HandleChannelUseCase(external_event_store=store, wait_store=store)

    result = use_case.execute(
        "whatsapp",
        "172584771580071@lid",
        {
            "text": "hola",
            "timestamp": 1900000000,
        },
        external_id="msg-demo-2",
        dedup_key="dedup-demo-2",
    )

    assert result.accepted is True
    assert result.duplicate is False
    assert result.run_ids == ["run-1"]
    assert result.event_id == "channel-1"
    assert store.created_external_events == [
        {
            "source_type": SourceType.CHANNEL,
            "source_name": "whatsapp",
            "match_type": MatchType.CHANNEL_KEY,
            "match_key": "172584771580071@lid",
            "run_id": None,
            "step_id": None,
            "external_id": "msg-demo-2",
            "dedup_key": "dedup-demo-2",
            "payload": {
                "text": "hola",
                "timestamp": 1900000000,
            },
        }
    ]
