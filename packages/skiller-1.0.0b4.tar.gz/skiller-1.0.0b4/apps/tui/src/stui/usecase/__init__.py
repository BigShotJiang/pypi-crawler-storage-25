"""TUI presentation use cases."""

