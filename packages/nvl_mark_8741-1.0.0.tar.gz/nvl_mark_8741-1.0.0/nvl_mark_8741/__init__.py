"""App Discovery Vent"""
__version__ = "1.0.0"
