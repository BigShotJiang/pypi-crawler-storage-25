# SDLC Agent Roster

> "1 prompt to rule them all" không scale. Mỗi vai trò trong SDLC cần persona,
> kiến thức và tool set riêng.

## Hierarchy

```
                     ┌──────────────────┐
                     │   ORCHESTRATOR   │  reads state.json, picks next agent
                     └────────┬─────────┘
                              │
   ┌──────────┬──────────┬────┴──────┬──────────┬──────────┐
   ▼          ▼          ▼           ▼          ▼          ▼
┌──────┐  ┌────────┐  ┌──────┐   ┌──────┐  ┌──────┐  ┌────────┐
│ PH 1 │  │ PH 2   │  │ PH 3 │   │ PH 4 │  │ PH 5 │  │  GATE  │
│  PM  │  │ Arch + │  │ Dev  │   │  QA  │  │ SRE  │  │(human  │
│      │  │ UX     │  │      │   │      │  │      │  │ or MAD)│
└──┬───┘  └────┬───┘  └──┬───┘   └──┬───┘  └──┬───┘  └────────┘
   │           │         │          │         │
   ▼           ▼         ▼          ▼         ▼
┌──────────────────────────────────────────────────┐
│  CROSS-CUTTING (called from any phase)           │
│  • security-reviewer   • test-author             │
│  • code-reviewer       • doc-keeper              │
│  • clarification-triager                         │
└──────────────────────────────────────────────────┘
```

## Agent catalog

### Orchestrator

| Agent | File | Trigger |
|---|---|---|
| **orchestrator** | `orchestrator.md` | Mọi turn — đọc `state.json`, chọn agent tiếp theo |

### Phase specialists

| Agent | File | Phase / sub-track | Persona | Tools |
|---|---|---|---|---|
| **pm-agent** | `phase-1-pm.md` | 1 — Planning | Senior PM/BA | Read, Write, Edit, Glob |
| **architect-agent** | `phase-2-architect.md` | 2 — Architecture | Staff/Principal Eng | Read, Write, Edit, Glob, Bash (mermaid, openapi lint) |
| **ux-designer** | `cross/ux-designer.md` | 2 — UI/UX sub-track | Senior Product Designer | Read, Write, Edit, Glob |
| **developer-agent** | `phase-3-developer.md` | 3 — Development (TDD green) | Senior SWE | Read, Write, Edit, Bash (tests/lint), Grep |
| **qa-engineer** | `phase-4-qa.md` | 4 — Testing | Senior QA Engineer | Read, Write, Edit, Bash (E2E, perf) |
| **sre-agent** | `phase-5-sre.md` | 5 — Deploy & Monitor | SRE/DevOps Lead | Read, Write, Edit, Bash (CI, SLOs) |

### Cross-cutting (invoked from any phase)

| Agent | File | When to invoke |
|---|---|---|
| **security-reviewer** | `cross/security-reviewer.md` | Bất kỳ lúc nào touch auth/crypto/payment/PII/IAM/secrets |
| **test-author** | `cross/test-author.md` | Phase 3 stage `write-tests` (TDD red — viết test trước khi có code) |
| **code-reviewer** | `cross/code-reviewer.md` | Phase 3 stage `review` (sau khi tests pass và code đã viết, trước khi mở PR) |
| **doc-keeper** | `cross/doc-keeper.md` | Sau mỗi commit — update README/ADR/changelog |
| **clarification-triager** | `cross/clarification-triager.md` | Khi orchestrator detect ambiguity hoặc conflict |

## Phase 3 task lifecycle (sequential TDD)

```
pending ──► write-tests ──► write-code ──► review ──► done
   │            │              │             │
test-author  developer-     code-reviewer  (PR open;
             agent          (or security-  human merge)
                            reviewer if
                            sensitive)
```

Stage được engine detect tự động từ filesystem + `gh pr view`. Mỗi subagent
chạy trong **fresh context** — không leak state giữa các stage.

## Hand-off protocol

1. **Caller** chuẩn bị **brief** (xem `_brief-template.md`):
   - Mục tiêu cụ thể
   - File / state liên quan
   - Constraints
   - Definition of "done" cho turn này
2. **Callee** đọc brief + `state.json` + relevant files
3. **Callee** trả về **report**:
   - Files changed
   - Evidence ngắn gọn (path + lý do)
   - Open questions (nếu có)
   - Next agent suggested
4. Caller verify (`sdlc scan`) trước khi tiếp tục

## Mapping sang từng AI tool

| Tool | Cách invoke specialist |
|---|---|
| **Claude Code** | Subagent files trong `.claude/agents/` (auto-detected); gọi qua Task tool hoặc `/sdlc-next` |
| **Claude Desktop / API** | Copy paste prompt từ `agents/<name>.md` làm system prompt |
| **Cursor** | Mention file trong chat: `@agents/phase-1-pm.md` |
| **Codex CLI** | `codex --instructions agents/<name>.md ...` hoặc reference trong `AGENTS.md` |
| **Aider** | `/load agents/<name>.md` hoặc add vào `read:` config |
| **GitHub Copilot Chat** | `.github/prompts/sdlc-*.prompt.md` (auto-generated từ shared source) |
| **OpenAI Agent SDK** | Mỗi file = 1 Agent definition (system prompt + tools) |

## Quick start

```bash
# Xem agent nào nên gọi tiếp + brief đã chuẩn bị
sdlc dispatch

# Chạy autopilot (stop on gate / clarification / high-risk)
sdlc auto-step                # one iteration; lặp tới khi action=stop|done

# YOLO mode cho prototype: AI tự ký gate (clearly marked, dễ revert)
sdlc auto-mad-step
```

## Anti-patterns

- ❌ Gộp tất cả vào 1 prompt khổng lồ — context dilution, output quality giảm
- ❌ Để orchestrator code thay vì gọi `developer-agent` — mất specialization
- ❌ Skip `security-reviewer` cho code "nhỏ" — incidents thường từ 1-line bugs
- ❌ Agent tự ký gate — **human-only** EXCEPT trong `/sdlc-auto-mad`
  (MAD MODE, opt-in cho prototype/hackathon, auto-sign mark
  `approved_by: ai-mad-mode`)
- ❌ 2 agents edit cùng 1 file song song — orchestrator phải sequence
- ❌ Chạy Phase 3 mà không qua `test-author` trước — vi phạm sequential TDD

## Dashboard auto-refresh contract

Mọi phase agent (1–5) và 3 cross agents (`clarification-triager`,
`doc-keeper`, `ux-designer`) chứa block **"Auto-refresh dashboard
(CRITICAL)"** ở đầu file. Block yêu cầu agent chạy
`sdlc scan 2>/dev/null || python3 automation/sdlc_engine.py` ngay sau **mỗi**
lần ghi vào path phase-owned:

- `01-Planning/**`
- `02-Design/**`
- `03-Development/**`
- `04-Testing-Deploy/**`
- `automation/clarifications/**`
- `automation/signoffs/**`
- `automation/.tasks.json`

Đây là cách duy nhất để dashboard reflect progress live trên mọi AI tool
(Claude, Copilot, Cursor, Gemini) — không phụ thuộc slash command hay hook
hệ thống.

Khi sửa block này, đổi đồng thời nội dung ở **cả 4 vị trí**:

- `agents/`
- `.claude/agents/`
- `src/sdlc_framework/scaffold/agents/`
- `src/sdlc_framework/scaffold/.claude/agents/`

Audit drift bằng:

```bash
grep -rcl "Auto-refresh dashboard (CRITICAL"
# kỳ vọng: 32 matches
```
