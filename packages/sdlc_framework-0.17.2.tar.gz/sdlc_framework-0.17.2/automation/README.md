# Automation — Auto-Detect SDLC Engine

Folder này biến SDLC framework từ "templates + checklist tay" thành **hệ thống tự cập nhật**.

## 3 phần

| File | Vai trò |
|---|---|
| `rules.json` | Declarative DoD rules — mỗi item có 1+ check (file_exists, regex, glob...) |
| `sdlc_engine.py` | Scan engine — đọc rules, scan repo, ghi `state.json` |
| `AGENT-LOOP.md` | Spec để AI agents (Claude/Codex/...) tự chạy SDLC, biết khi nào dừng để hỏi user |

## Quick start

```bash
# One-shot scan (in tóm tắt + ghi state.json)
python3 automation/sdlc_engine.py --print

# Watch mode — re-scan mỗi 3 giây, dashboard auto-update theo
python3 automation/sdlc_engine.py --watch

# Hoặc dùng wrapper script:
bash scripts/sdlc-scan.sh
bash scripts/sdlc-watch.sh
```

Sau đó mở `dashboard/index.html` — không cần tick tay nữa.

## Cơ chế detect

Engine evaluate mỗi DoD item bằng các check type:

| Check | Ý nghĩa |
|---|---|
| `file_exists` | Path cụ thể tồn tại |
| `file_glob_min_count` | Số file match glob ≥ N |
| `file_contains_all` | File match glob có chứa tất cả patterns |
| `file_contains_any` | File match glob chứa ≥ 1 trong các patterns |
| `regex_min_count` | Số match regex trong file ≥ N |
| `no_unfilled_template` | File còn ≤ N placeholder `{{...}}` (đã được fill) |
| `signoff` | Có file `signoffs/<id>.yaml` với `approved: true` |
| `state_field` | Field trong state.json (CI / external system push vào) |

## Cấu trúc state.json

```json
{
  "generated_at": "2026-04-30T10:00:00Z",
  "git": { "branch": "main", "head": "abc1234", "last_commit": "..." },
  "overall_pct": 67,
  "total_done": 16,
  "total_all": 24,
  "phases_done": 2,
  "phases": [
    {
      "id": 1, "name": "Planning", "pct": 100, "complete": true,
      "items": [
        {
          "id": "prd-exists",
          "label": "PRD đã được khởi tạo",
          "done": true,
          "checks": [{"rule": {...}, "ok": true, "msg": "..."}]
        }
      ]
    }
  ],
  "gates": [{"id":"phase1-prd","approved":false,...}],
  "clarifications": [{"file":"...","title":"..."}]
}
```

Dashboard fetch file này (auto-refresh) và render.

## Khi nào agent dừng để hỏi user

Có **4 loại trigger** (chi tiết trong `AGENT-LOOP.md`):

1. 🔍 **Ambiguity** — không đủ thông tin → tạo `clarifications/<NNN>-<slug>.md`
2. ⚔️ **Conflict** — 2 nguồn mâu thuẫn → cũng tạo clarification
3. 🚪 **Gate** — cần approval → user tạo `signoffs/<gate>.yaml`
4. 🛑 **High-risk** — auth/crypto/payment/migrations → STOP

## Resolve clarifications

```bash
# AI tạo:
automation/clarifications/001-nfr-targets.md  (STATUS: open)

# User mở file, sửa STATUS: resolved + RESOLUTION: <answer>
# Lần scan tiếp theo, agent thấy đã resolved → tiếp tục.
```

## Approve gates

```bash
# Tạo file YAML đơn giản:
cat > automation/signoffs/phase1-prd.yaml <<'EOF'
id: phase1-prd
approved: true
approved_at: 2026-04-30
approvers:
  - { name: "Lam", role: sponsor }
EOF

# Re-scan:
python3 automation/sdlc_engine.py --print
# Phase 1 sẽ flip sang complete.
```

## Customize rules cho project của anh

Edit `rules.json`:
- Thêm phase mới (id 5+) hoặc item mới
- Đổi glob path nếu repo dùng layout khác
- Thêm check type mới (sửa `sdlc_engine.py` thêm function `check_<type>`)

## CI integration (optional)

Trong GitHub Actions:
```yaml
- name: SDLC scan
  run: python3 automation/sdlc_engine.py --print
- name: Push CI status into state
  run: |
    jq '.external.ci_last_status = "success"' automation/state.json > /tmp/s.json
    mv /tmp/s.json automation/state.json
```
Như vậy item `ci-green` trong rules sẽ tự pass.
