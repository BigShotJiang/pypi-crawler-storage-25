# Phase 2 — Design & Architecture

> **Mục tiêu**: Quyết định *how* — kiến trúc, API, data, UI/UX — trước khi code 1 dòng.

## Deliverables

| # | File | Owner |
|---|------|-------|
| 1 | `templates/01-Architecture.md` | Eng Lead |
| 2 | `templates/02-API-Spec.md` (OpenAPI) | Backend Lead |
| 3 | `templates/03-DB-Schema.md` | Data Eng |
| 4 | `templates/04-UI-UX-Spec.md` | Designer |
| 5 | `templates/05-ADR.md` (Architecture Decision Record) | Eng Lead |
| 6 | `templates/06-Threat-Model.md` | Security |

## Definition of Done — Phase 2

- [ ] Architecture diagram (C4 Level 1+2) reviewed
- [ ] API spec passes OpenAPI lint (Spectral)
- [ ] DB schema reviewed by data eng + DBA
- [ ] UI mockups approved by stakeholder
- [ ] ADRs logged for every non-obvious decision
- [ ] Threat model identifies STRIDE categories with mitigations
- [ ] AI tools updated với context mới (cập nhật `ai-tools/claude/CLAUDE.md`)

## Quy trình
```
PRD → Architecture spike → Tech RFC → Design review → Sign-off → Phase 3
```
