# Phase 3 — Development & Code Review

> **Mục tiêu**: Code chất lượng cao, an toàn, có thể bảo trì — bất kể human hay AI viết.

## Deliverables

| # | File | Owner |
|---|------|-------|
| 1 | `standards/coding-standards.md` | Eng Lead |
| 2 | `standards/git-workflow.md` | Eng Lead |
| 3 | `standards/error-handling.md` | Backend Lead |
| 4 | `standards/security-checklist.md` | Security |
| 5 | `templates/PR-Template.md` | Eng Lead |
| 6 | `templates/Code-Review-Checklist.md` | Eng Lead |
| 7 | `templates/Definition-of-Done.md` | Team |

## Definition of Done — Phase 3 (per PR)

- [ ] Tests written (unit + integration) — coverage delta ≥ 0%
- [ ] Lint + format clean
- [ ] Security scan (Semgrep / CodeQL) clean
- [ ] No secrets / no PII in logs
- [ ] Docs updated (README, OpenAPI, ADR if needed)
- [ ] Reviewed by ≥ 1 human (security-sensitive: ≥ 2)
- [ ] AI-generated code annotated and reviewed line-by-line
- [ ] Backwards-compatible OR migration plan documented
- [ ] Feature flag wraps risky paths
- [ ] Observability: logs, metrics, traces in place

## AI-Assisted Development Policy

1. **Always disclose**: PR description must say which AI tool generated which parts.
2. **Never trust blindly**: Treat AI output as a junior dev's first draft.
3. **Security-sensitive code** (auth, crypto, payments, IAM) requires human-only review.
4. **License hygiene**: Reject snippets that look copy-pasted from copyleft sources.
5. **Test first**: Ask AI to write tests *before* impl when possible.

See `../ai-tools/` for tool-specific configs (Claude, Copilot, Cursor, Codex, Aider).
