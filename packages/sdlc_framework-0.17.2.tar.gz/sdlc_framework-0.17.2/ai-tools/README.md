# AI Tools — Multi-Assistant SDLC

> Mỗi tool có file config riêng, nhưng đều **trỏ về cùng 1 nguồn sự thật**: SDLC standards trong project.
> Mục tiêu: bất kể bạn dùng Claude, Copilot, Cursor, Codex, Aider… tất cả đều hành xử nhất quán.

## Tool ↔ File mapping

| Tool | Config file | Cách load |
|---|---|---|
| **Claude (Code / Desktop / API)** | `claude/CLAUDE.md` → symlink `/CLAUDE.md` | Auto-loaded từ root |
| **GitHub Copilot** | `github-copilot/copilot-instructions.md` → `.github/copilot-instructions.md` | VS Code: Settings → Copilot → custom instructions |
| **Cursor** | `cursor/.cursorrules` → root | Cursor đọc tự động |
| **Codex CLI / OpenAI agent** | `codex/AGENTS.md` → root | OpenAI agent SDK reads `AGENTS.md` |
| **Aider** | `aider/.aider.conf.yml` + `CONVENTIONS.md` | `aider --config` |
| **Continue.dev** | `cursor/.cursorrules` (compatible) hoặc `.continue/config.json` | Continue extension |
| **Windsurf / Cody / others** | Reuse `cursor/.cursorrules` hoặc `claude/CLAUDE.md` | Most read project-root instructions |
| **Shared prompts** | `shared-prompts/*.md` | Copy-paste khi cần |

## Setup nhanh
Chạy script:
```bash
bash scripts/setup-ai-configs.sh
```
Script sẽ symlink/copy file đến nơi mỗi tool expect.

## Triết lý chung

1. **Single source of truth**: tất cả configs đều reference same SDLC docs (PRD, standards, checklists).
2. **Disclose**: mọi PR phải nói tool nào đã generate phần nào.
3. **Verify**: AI = junior dev. Output luôn cần human review (đặc biệt security-sensitive).
4. **Tests-first**: prefer prompts dạng "viết test trước, rồi mới impl".
5. **Small steps**: yêu cầu AI làm từng bước nhỏ thay vì 1 cú lớn.
