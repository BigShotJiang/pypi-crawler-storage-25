"""Per-command handlers for the ``sdlc`` CLI.

Historical context: the CLI grew to ~2000 lines as 31 handlers in a
single ``cli.py``. The biggest, most self-contained handlers
(migrations, adopt, auto-step) live here in their own modules. The
small handlers stay in ``cli.py`` next to ``main()`` and the
``COMMANDS`` table for discoverability.

Each module exports a single ``run(argv)`` function (or a small set
of helpers) that ``cli.py`` wires into the dispatcher.
"""
