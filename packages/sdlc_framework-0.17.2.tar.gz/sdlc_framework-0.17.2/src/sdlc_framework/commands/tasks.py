"""Phase 3 task management — `sdlc tasks <bootstrap|list|new|rm>`.

Extracted from cli.py during the I2 phase 2 split. The dispatch handlers
(`auto-step`, `auto-mad-step`) now import this directly via
``commands.tasks.cmd_tasks`` to drop the late-import pattern that used
to reach back into cli.py.

Bootstrap consults `02-Design/*Code-Structure*.md` (Phase 2 deliverable
``code-structure-mapped``) to resolve each user-story's container and
emit globs rooted at ``src/<container>/<module>*`` instead of falling
back to the legacy ``src/<slug>/**`` layout. Without that file, the
legacy behavior is kept and a warning is printed so the user knows
they are shipping with un-architected folder layout.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
from pathlib import Path

import yaml


# ---------------------------------------------------------------------------
# Code-Structure parsing — bridges Phase 2 architecture to Phase 3 task globs
# ---------------------------------------------------------------------------


def _normalize_container_key(name: str) -> str:
    """Container names are matched loosely so 'App shell' == 'app-shell' == 'app shell'."""
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")


def _parse_code_structure(target: Path) -> tuple[dict[str, str], dict[str, tuple[str, str]]] | None:
    """Read ``02-Design/*Code-Structure*.md`` and return the mappings.

    Returns ``(containers, story_map)`` where:

    - ``containers`` maps a normalized container key (e.g. ``"scene"``,
      ``"app-shell"``) to its folder (``"src/scene"``, ``"src/app"``).
      Folder paths are normalized: trailing slash stripped, leading
      ``./`` removed, but ``src/`` prefix is kept verbatim.
    - ``story_map`` maps a US-ID (uppercase, e.g. ``"US-001"``) to a
      tuple ``(container_name_raw, module_hint)``. ``module_hint`` is
      empty string when the row's "Module hint" column is blank.

    Returns ``None`` when no Code-Structure file is found. Files inside
    a ``templates/`` directory are excluded — those are scaffold copies,
    not the project's actual mapping.
    """
    design_dir = target / "02-Design"
    if not design_dir.exists():
        return None
    candidates = [
        p for p in design_dir.glob("*Code-Structure*.md")
        if "templates" not in p.parts
    ]
    if not candidates:
        return None
    text = candidates[0].read_text(encoding="utf-8", errors="replace")

    containers: dict[str, str] = {}
    # Match table rows whose 2nd column is a folder path. Allow the path
    # to be wrapped in backticks per markdown table convention.
    for m in re.finditer(
        r"^\|\s*([^|]+?)\s*\|\s*`?(src/[^`|\s]+)`?\s*\|", text, re.MULTILINE
    ):
        cname_raw = m.group(1).strip()
        folder = m.group(2).strip().rstrip("/")
        # Skip header / separator rows.
        if cname_raw.lower().startswith(("container", "---", "user story")):
            continue
        containers[_normalize_container_key(cname_raw)] = folder

    story_map: dict[str, tuple[str, str]] = {}
    # Story → container row: | US-NNN | title | container | module |.
    # The module column is optional (may be blank or wrapped in backticks).
    for m in re.finditer(
        r"^\|\s*(US-\d+)\s*\|\s*[^|]*\|\s*([^|]+?)\s*\|\s*`?([^`|]*?)`?\s*\|",
        text, re.MULTILINE | re.IGNORECASE,
    ):
        us_id = m.group(1).upper()
        container = m.group(2).strip()
        module_hint = m.group(3).strip()
        # Don't capture the header row even if it slips through.
        if container.lower().startswith("primary container"):
            continue
        story_map[us_id] = (container, module_hint)

    return containers, story_map


def _resolve_globs_from_code_structure(
    slug: str,
    story_title: str,
    parsed: tuple[dict[str, str], dict[str, tuple[str, str]]] | None,
) -> tuple[str, str, str]:
    """Decide ``(code_glob, test_glob, container_field)`` for a story.

    Falls back to the legacy ``src/<slug>/**`` layout when:
    - ``parsed`` is None (no Code-Structure file), or
    - the story has no ``US-NNN`` token in its title, or
    - the story's US-ID is not present in the Code-Structure §2 table, or
    - the resolved container has no folder mapping in §1.

    ``container_field`` is empty for fallbacks so the caller can omit the
    yaml key entirely (avoids stamping a guess as a fact).
    """
    legacy_code = f"src/{slug}/**/*.{{ts,tsx,js,jsx,py,go}}"
    legacy_test = f"src/{slug}/**/*.{{test,spec,_test}}.{{ts,tsx,js,jsx,py,go}}"
    if parsed is None:
        return legacy_code, legacy_test, ""

    containers, story_map = parsed
    m = re.search(r"US-\d+", story_title, re.IGNORECASE)
    if not m:
        return legacy_code, legacy_test, ""
    us_id = m.group(0).upper()
    entry = story_map.get(us_id)
    if not entry:
        return legacy_code, legacy_test, ""
    container_raw, module_hint = entry
    folder = containers.get(_normalize_container_key(container_raw))
    if not folder:
        return legacy_code, legacy_test, ""

    # Module hint drives the file pattern so two stories sharing a
    # container don't collide on globs. Fall back to lowercase US-ID
    # prefix when the hint column is blank.
    pattern = module_hint.strip() or us_id.lower()
    code_glob = f"{folder}/{pattern}*.{{ts,tsx,js,jsx,py,go}}"
    test_glob = f"{folder}/{pattern}*.{{test,spec,_test}}.{{ts,tsx,js,jsx,py,go}}"
    return code_glob, test_glob, container_raw


def cmd_tasks(argv: list[str]) -> int:
    """sdlc tasks <action> — manage Phase 3 task definitions and serial lock.

    Actions:
        list / new / rm / bootstrap   — task definition management
        activate <id> / active        — Phase 3 serial lock control
        unlock / force-merge <id>     — lock rollback / mad-mode escape hatch
    """
    # Lock subcommands have their own argument parsing (need to support
    # `--i-accept-the-risk` flag). Dispatch them before the strict argparse.
    if argv and argv[0] in ("activate", "active", "unlock", "force-merge"):
        from sdlc_framework.commands.tasks_lock import (
            cmd_activate, cmd_active, cmd_unlock, cmd_force_merge,
        )
        return {
            "activate": cmd_activate,
            "active": cmd_active,
            "unlock": cmd_unlock,
            "force-merge": cmd_force_merge,
        }[argv[0]](argv[1:])

    parser = argparse.ArgumentParser(prog="sdlc tasks")
    sub = parser.add_subparsers(dest="action", required=True)

    sub.add_parser("list")
    p_new = sub.add_parser("new")
    p_new.add_argument("task_id")
    p_new.add_argument("--label", default=None)
    p_new.add_argument("--code-glob", default=None)
    p_new.add_argument("--test-glob", default=None)
    p_new.add_argument("--pr-branch", default=None)
    p_new.add_argument("--priority", default="medium")
    p_rm = sub.add_parser("rm")
    p_rm.add_argument("task_id")
    p_boot = sub.add_parser("bootstrap")
    p_boot.add_argument("--story-file", default=None,
                        help="User stories file (default: 01-Planning/02-User-Stories.md)")

    args = parser.parse_args(argv)
    target = Path.cwd()
    tasks_dir = target / "automation" / "tasks"

    if args.action == "list":
        from sdlc_framework.tasks_loader import load_tasks, detect_stage
        tasks = load_tasks(target)
        if not tasks:
            print("[sdlc tasks] no tasks declared yet. Run `sdlc tasks bootstrap` or `sdlc tasks new <id>`.")
            return 0
        for t in tasks:
            stage = detect_stage(t, target)
            print(f"  · {t['id']:30s} {stage:14s} priority={t.get('priority','medium'):6s} {t.get('label','')}")
        return 0

    if args.action == "new":
        tasks_dir.mkdir(parents=True, exist_ok=True)
        f = tasks_dir / f"{args.task_id}.yaml"
        if f.exists():
            print(f"[sdlc tasks] task {args.task_id} already exists at {f}")
            return 1
        ts = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        code_glob = args.code_glob or f"src/{args.task_id}/**/*.{{ts,py,go}}"
        test_glob = args.test_glob or f"src/{args.task_id}/**/*.{{test,spec,_test}}.{{ts,py,go}}"
        body = (
            f"id: {args.task_id}\n"
            f'label: "{args.label or args.task_id}"\n'
            f"priority: {args.priority}\n"
            f'code_glob: "{code_glob}"\n'
            f'test_glob: "{test_glob}"\n'
        )
        if args.pr_branch:
            body += f"pr_branch: {args.pr_branch}\n"
        body += f"created_at: {ts}\ncreated_by: {_git_user_name()}\n"
        f.write_text(body, encoding="utf-8")
        print(f"[sdlc tasks] created {f.relative_to(target)}")
        return 0

    if args.action == "rm":
        f = tasks_dir / f"{args.task_id}.yaml"
        if not f.exists():
            print(f"[sdlc tasks] task {args.task_id} not found")
            return 1
        f.unlink()
        print(f"[sdlc tasks] removed {f.relative_to(target)}")
        return 0

    if args.action == "bootstrap":
        story_file = Path(args.story_file) if args.story_file else (target / "01-Planning" / "02-User-Stories.md")
        if not story_file.exists():
            print(f"[sdlc tasks bootstrap] {story_file} not found. Pass --story-file=<path> or draft user stories first.")
            return 1
        text = story_file.read_text(encoding="utf-8")
        stories = re.findall(r"^##\s+(?:Story|US|User Story)\s*:?\s*(.+)$", text, re.MULTILINE)
        if not stories:
            print(f"[sdlc tasks bootstrap] no `## Story: <title>` headings found in {story_file}")
            return 1

        parsed = _parse_code_structure(target)
        if parsed is None:
            print(
                "[sdlc tasks bootstrap] WARNING: 02-Design/*Code-Structure*.md "
                "not found. Falling back to legacy `src/<slug>/**` folder layout. "
                "This produces parallel `src/us-*` islands instead of "
                "architecture-aligned code. Run Phase 2 `code-structure-mapped` "
                "first for proper structure (see "
                "02-Design/templates/00-Code-Structure.md)."
            )

        tasks_dir.mkdir(parents=True, exist_ok=True)
        ts = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        created = 0
        unmapped: list[str] = []
        for s in stories:
            slug = re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:60] or "feature"
            f = tasks_dir / f"{slug}.yaml"
            if f.exists():
                print(f"  [skip] {f.name} already exists")
                continue
            code_glob, test_glob, container = _resolve_globs_from_code_structure(
                slug, s, parsed,
            )
            if parsed is not None and not container:
                # Code-Structure exists but this story isn't mapped — surface
                # so the user can fix it before Phase 3 starts shipping code.
                unmapped.append(slug)
            body = (
                f"id: {slug}\n"
                f'label: "{s.strip()}"\n'
                f"story: {story_file.relative_to(target).as_posix()}\n"
            )
            if container:
                body += f"container: {container}\n"
            body += (
                f"priority: medium\n"
                f'code_glob: "{code_glob}"\n'
                f'test_glob: "{test_glob}"\n'
                f"created_at: {ts}\n"
                f"created_by: bootstrap\n"
            )
            f.write_text(body, encoding="utf-8")
            created += 1
            print(f"  [ok] {f.relative_to(target)}")
        if unmapped:
            print(
                f"[sdlc tasks bootstrap] WARNING: {len(unmapped)} task(s) had "
                f"no entry in 02-Design/*Code-Structure*.md §2 — fell back to "
                f"slug-based globs: {', '.join(unmapped)}. Add their rows to "
                f"the user-story → container map and re-run bootstrap (or "
                f"edit the task yaml directly)."
            )
        print(f"[sdlc tasks bootstrap] created {created} task(s).")
        return 0

    return 2


