"""Schema migrations between SDLC framework major versions.

These two handlers are large and self-contained — moved out of cli.py
during the I2 split to keep the dispatcher thin. Each is invoked via
``sdlc migrate-v2`` / ``sdlc migrate-v3``.

Both are idempotent: re-running on an already-migrated project is a
no-op. Both back up the old ``automation/rules.json`` before writing
the new schema.
"""
from __future__ import annotations

import argparse
import json
from importlib import resources
from pathlib import Path


# v0.6 → v0.7 (1 → 2): 4 → 5 phase model.
def cmd_migrate_v2(argv: list[str]) -> int:
    """Migrate a project on framework v0.6.x to the v2 phase model (5 phases).

    Steps:
      1. Back up automation/rules.json → automation/rules.json.v1.bak
      2. Replace rules.json with bundled v2 rules
      3. Rename automation/signoffs/phase4-prod.yaml → phase5-prod.yaml (preserve approval)
      4. Bump project.yaml.schema_version 1 → 2
      5. Optionally bootstrap automation/tasks/ from user stories

    Idempotent: re-running on an already-migrated project is a no-op.
    """
    parser = argparse.ArgumentParser(prog="sdlc migrate-v2")
    parser.add_argument("--auto", action="store_true",
                        help="Non-interactive — apply all migration steps without prompts.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print what would change, write nothing.")
    args = parser.parse_args(argv)

    target = Path.cwd()
    rules_path = target / "automation" / "rules.json"
    if not rules_path.exists():
        print("[sdlc migrate-v2] automation/rules.json not found. Is this an SDLC project?")
        return 1

    rules = json.loads(rules_path.read_text(encoding="utf-8"))
    schema_version = rules.get("schema_version") or 1

    if schema_version >= 2:
        print(f"[sdlc migrate-v2] schema_version is already {schema_version}. Nothing to do.")
        return 0

    print(f"[sdlc migrate-v2] migrating from schema_version {schema_version} → 2")
    print()

    # Plan changes.
    changes: list[tuple[str, str]] = []
    bak_path = target / "automation" / "rules.json.v1.bak"
    if not bak_path.exists():
        changes.append(("backup", "copy automation/rules.json → automation/rules.json.v1.bak"))
    changes.append(("replace", "replace automation/rules.json with v2 5-phase schema"))

    old_signoff = target / "automation" / "signoffs" / "phase4-prod.yaml"
    new_signoff = target / "automation" / "signoffs" / "phase5-prod.yaml"
    if old_signoff.exists() and not new_signoff.exists():
        changes.append(("rename", "rename automation/signoffs/phase4-prod.yaml → phase5-prod.yaml"))

    project_yaml = target / "project.yaml"
    if project_yaml.exists():
        text = project_yaml.read_text(encoding="utf-8")
        if "schema_version" not in text:
            changes.append(("project-version", "add `schema_version: 2` to project.yaml"))
        elif "schema_version: 1" in text or "schema_version:1" in text:
            changes.append(("project-version", "bump project.yaml schema_version 1 → 2"))

    user_stories = target / "01-Planning" / "02-User-Stories.md"
    tasks_dir = target / "automation" / "tasks"
    if user_stories.exists() and not tasks_dir.exists():
        changes.append(("bootstrap", "bootstrap automation/tasks/ from user stories"))

    print(f"[sdlc migrate-v2] {len(changes)} change(s) planned:")
    for kind, desc in changes:
        print(f"  · [{kind}] {desc}")
    print()

    if args.dry_run:
        print("[sdlc migrate-v2] --dry-run — no files written.")
        return 0

    if not args.auto:
        try:
            ans = input("Apply? [Y/n] ").strip().lower()
        except EOFError:
            ans = "y"
        if ans and ans not in ("y", "yes"):
            print("[sdlc migrate-v2] cancelled.")
            return 0

    # Apply.
    for kind, _desc in changes:
        if kind == "backup":
            bak_path.write_text(rules_path.read_text(encoding="utf-8"), encoding="utf-8")
            print(f"  [ok] backed up to {bak_path.relative_to(target)}")
        elif kind == "replace":
            pkg_rules = resources.files("sdlc_framework").joinpath("scaffold").joinpath("automation").joinpath("rules.json")
            with resources.as_file(pkg_rules) as real_path:
                rules_path.write_text(real_path.read_text(encoding="utf-8"), encoding="utf-8")
            print("  [ok] replaced rules.json with v2")
        elif kind == "rename":
            old_signoff.rename(new_signoff)
            print("  [ok] renamed signoff to phase5-prod.yaml")
        elif kind == "project-version":
            text = project_yaml.read_text(encoding="utf-8")
            if "schema_version: 1" in text:
                text = text.replace("schema_version: 1", "schema_version: 2", 1)
            elif "schema_version:1" in text:
                text = text.replace("schema_version:1", "schema_version: 2", 1)
            elif "schema_version" not in text:
                text = "schema_version: 2\n" + text
            project_yaml.write_text(text, encoding="utf-8")
            print("  [ok] project.yaml schema_version → 2")
        elif kind == "bootstrap":
            from sdlc_framework.commands.tasks import cmd_tasks
            rc = cmd_tasks(["bootstrap"])
            if rc == 0:
                print("  [ok] bootstrapped tasks from user stories")
            else:
                print(f"  [warn] tasks bootstrap returned {rc} — you can run `sdlc tasks bootstrap` later")

    print()
    print("[sdlc migrate-v2] done. Run `sdlc scan --print` to see your new phase model.")
    print("[sdlc migrate-v2] backup at automation/rules.json.v1.bak (delete when comfortable).")
    return 0


# v0.7/v0.8 → v0.9 ID rename map. Values from the v3 design spec.
MIGRATE_V3_ID_RENAMES: dict[str, str] = {
    # Phase 1
    "prd-exists": "prd-drafted",
    "user-stories-with-ac": "user-stories",
    "nfr-quantified": "nfr-targets",
    "stakeholder-raci": "stakeholder-map",
    "risks-mitigated": "risks-identified",
    "phase1-prd-signoff": "phase1-signoff",
    # Phase 2
    "architecture-doc": "system-architecture",
    "api-spec": "api-contract",
    "db-schema": "database-schema",
    "adr-logged": "architecture-decisions",
    "threat-model": "security-threat-model",
    "ui-spec": "screen-designs",
    "accessibility": "accessibility-checklist",
    "phase2-design-signoff": "phase2-signoff",
    # Phase 3 setup (ai-disclosure-policy is dropped — its check folded into pr-template-configured)
    "coding-standards": "coding-standards-published",
    "git-workflow": "git-workflow-documented",
    "pr-template": "pr-template-configured",
    "security-checklist": "security-checklist-available",
    "ai-tool-configs": "ai-tool-configs-generated",
    "tdd-coverage": "tdd-coverage-active",
    # Phase 4
    "test-plan-written": "test-plan-published",
    "e2e-suite-present": "end-to-end-test-suite",
    "integration-tests": "integration-test-suite",
    "smoke-tests": "smoke-test-suite",
    "regression-baseline": "regression-test-baseline",
    # Phase 5
    "ci-pipeline": "ci-pipeline-configured",
    "ci-green": "ci-pipeline-green",
    "deploy-runbook-written": "deployment-runbook-ready",
    "slo-monitoring": "slo-targets-defined",
    "incident-response": "incident-response-ready",
    "observability-dashboard": "observability-wired",
    "prod-deploy-signoff": "phase5-signoff",
}

MIGRATE_V3_SIGNOFF_RENAMES: dict[str, str] = {
    "phase1-prd.yaml": "phase1-signoff.yaml",
    "phase2-design.yaml": "phase2-signoff.yaml",
    "prod-deploy-signoff.yaml": "phase5-signoff.yaml",
    "phase5-prod.yaml": "phase5-signoff.yaml",
}


def cmd_migrate_v3(argv: list[str]) -> int:
    """Migrate a project on framework v0.7/v0.8 to the v3 phase model.

    Steps:
      1. Back up automation/rules.json → automation/rules.json.v2.bak
      2. Replace rules.json with bundled v3 rules
      3. Rename keys in automation/.verifications.json (preserves verify history)
      4. Rename signoff filenames in automation/signoffs/
      5. Bump project.yaml.schema_version 2 → 3

    Idempotent: re-running on an already-migrated project is a no-op.
    """
    parser = argparse.ArgumentParser(prog="sdlc migrate-v3")
    parser.add_argument("--auto", action="store_true",
                        help="Non-interactive — apply all migration steps without prompts.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print what would change, write nothing.")
    args = parser.parse_args(argv)

    target = Path.cwd()
    rules_path = target / "automation" / "rules.json"
    if not rules_path.exists():
        print("[sdlc migrate-v3] automation/rules.json not found. Is this an SDLC project?")
        return 1

    rules = json.loads(rules_path.read_text(encoding="utf-8"))
    schema_version = rules.get("schema_version") or 1

    if schema_version >= 3:
        print(f"[sdlc migrate-v3] schema_version is already {schema_version}. Nothing to do.")
        return 0

    print(f"[sdlc migrate-v3] migrating from schema_version {schema_version} → 3")
    print()

    # Plan changes.
    changes: list[tuple[str, str]] = []
    bak_path = target / "automation" / "rules.json.v2.bak"
    if not bak_path.exists():
        changes.append(("backup", "copy automation/rules.json → automation/rules.json.v2.bak"))
    changes.append(("replace", "replace automation/rules.json with v3 schema (renamed + reordered)"))

    verifications = target / "automation" / ".verifications.json"
    if verifications.exists():
        try:
            vdata = json.loads(verifications.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            vdata = {}
        rename_count = sum(1 for k in vdata if k in MIGRATE_V3_ID_RENAMES)
        if rename_count > 0:
            changes.append(("verify-keys",
                            f"rename {rename_count} key(s) in .verifications.json (preserves history)"))

    signoffs_dir = target / "automation" / "signoffs"
    if signoffs_dir.exists():
        for old_name, new_name in MIGRATE_V3_SIGNOFF_RENAMES.items():
            old = signoffs_dir / old_name
            new = signoffs_dir / new_name
            if old.exists() and not new.exists():
                changes.append(("signoff-rename",
                                f"rename automation/signoffs/{old_name} → {new_name}"))

    project_yaml = target / "project.yaml"
    if project_yaml.exists():
        text = project_yaml.read_text(encoding="utf-8")
        if "schema_version: 2" in text or "schema_version:2" in text:
            changes.append(("project-version", "bump project.yaml schema_version 2 → 3"))
        elif "schema_version" not in text:
            changes.append(("project-version", "add `schema_version: 3` to project.yaml"))

    print(f"[sdlc migrate-v3] {len(changes)} change(s) planned:")
    for kind, desc in changes:
        print(f"  · [{kind}] {desc}")
    print()

    if args.dry_run:
        print("[sdlc migrate-v3] --dry-run — no files written.")
        return 0

    if not args.auto:
        try:
            ans = input("Apply? [Y/n] ").strip().lower()
        except EOFError:
            ans = "y"
        if ans and ans not in ("y", "yes"):
            print("[sdlc migrate-v3] cancelled.")
            return 0

    # Apply.
    for kind, _desc in changes:
        if kind == "backup":
            bak_path.write_text(rules_path.read_text(encoding="utf-8"), encoding="utf-8")
            print(f"  [ok] backed up to {bak_path.relative_to(target)}")
        elif kind == "replace":
            pkg_rules = resources.files("sdlc_framework").joinpath("scaffold").joinpath("automation").joinpath("rules.json")
            with resources.as_file(pkg_rules) as real_path:
                rules_path.write_text(real_path.read_text(encoding="utf-8"), encoding="utf-8")
            print("  [ok] replaced rules.json with v3")
        elif kind == "verify-keys":
            vdata = json.loads(verifications.read_text(encoding="utf-8"))
            renamed: dict = {}
            for key, value in vdata.items():
                new_key = MIGRATE_V3_ID_RENAMES.get(key, key)
                renamed[new_key] = value
            verifications.write_text(json.dumps(renamed, indent=2), encoding="utf-8")
            print("  [ok] renamed verification keys")
        elif kind == "signoff-rename":
            for old_name, new_name in MIGRATE_V3_SIGNOFF_RENAMES.items():
                old = signoffs_dir / old_name
                new = signoffs_dir / new_name
                if old.exists() and not new.exists():
                    old.rename(new)
                    print(f"  [ok] renamed signoff {old_name} → {new_name}")
        elif kind == "project-version":
            text = project_yaml.read_text(encoding="utf-8")
            if "schema_version: 2" in text:
                text = text.replace("schema_version: 2", "schema_version: 3", 1)
            elif "schema_version:2" in text:
                text = text.replace("schema_version:2", "schema_version: 3", 1)
            elif "schema_version" not in text:
                text = "schema_version: 3\n" + text
            project_yaml.write_text(text, encoding="utf-8")
            print("  [ok] project.yaml schema_version → 3")

    print()
    print("[sdlc migrate-v3] done. Run `sdlc scan --print` to see your new phase model.")
    print("[sdlc migrate-v3] backup at automation/rules.json.v2.bak (delete when comfortable).")
    return 0
