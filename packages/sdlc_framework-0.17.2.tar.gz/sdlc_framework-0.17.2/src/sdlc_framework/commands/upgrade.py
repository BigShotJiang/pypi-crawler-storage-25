"""``sdlc upgrade`` — sync scaffold updates into an existing project.

When the user runs ``pip install --upgrade sdlc-framework``, runtime
logic (engine, dispatch, agents) updates automatically. But scaffold
files copied at ``sdlc init`` time — ``automation/rules.json``, agent
prompts, AI-tool docs, design templates — are frozen in the project
since the day it was first scaffolded. This command walks the upgraded
package's scaffold tree and brings the project into sync without
clobbering user customizations.

Behavior:

- **Missing files** (in scaffold, not in project) → copy.
- **In-sync files** (identical content) → no-op.
- **Out-of-sync files** (project differs from scaffold) → report,
  do NOT overwrite. The user reviews the diff and either accepts the
  new scaffold (``--force``) or keeps their customizations.
- ``automation/rules.json`` gets a **structural merge**: missing engine
  items are inserted at the correct position; user-added items are
  preserved.
- ``--dry-run`` makes zero writes — useful for previewing upgrades.

User-owned files (state.json, tasks/, clarifications/, signoffs/, the
project's actual PRD/architecture/code) are **not in the scaffold tree**
and are therefore never even considered by this walk. The command
trusts the scaffold tree as the authoritative source of "what the
framework owns".
"""
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path


def cmd_upgrade(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="sdlc upgrade",
        description="Sync scaffold updates from the installed framework into this project.",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Show what would change; make no writes.",
    )
    parser.add_argument(
        "--force", action="store_true",
        help="Overwrite project files that differ from scaffold (DANGEROUS — "
             "loses user customizations).",
    )
    parser.add_argument(
        "--scaffold", default=None,
        help="(advanced/testing) Override the scaffold root path; defaults "
             "to the installed sdlc_framework package's scaffold/.",
    )
    parser.add_argument(
        "--add-tool", action="append", default=[],
        help="Render slash command surface for an additional AI tool "
             "(cursor|copilot|cline|windsurf|continue). Repeatable.",
    )
    parser.add_argument(
        "--target", default=None,
        help="(testing) Override target dir; defaults to cwd.",
    )
    args = parser.parse_args(argv)

    target = Path(args.target) if args.target else Path.cwd()
    scaffold = Path(args.scaffold) if args.scaffold else _default_scaffold()
    if not scaffold.exists():
        print(f"[sdlc upgrade] scaffold not found at {scaffold}")
        return 1

    added: list[Path] = []
    in_sync: list[Path] = []
    out_of_sync: list[Path] = []
    rules_summary = ""

    for src in sorted(scaffold.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(scaffold)

        # rules.json is engine-critical and structured — handle via JSON
        # merge, not byte-equality.
        if rel == Path("automation/rules.json"):
            rules_summary = _merge_rules(
                src, target / rel, dry_run=args.dry_run,
            )
            continue

        dst = target / rel
        if not dst.exists():
            added.append(rel)
            if not args.dry_run:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
            continue

        if dst.read_bytes() == src.read_bytes():
            in_sync.append(rel)
        else:
            out_of_sync.append(rel)
            if args.force and not args.dry_run:
                shutil.copy2(src, dst)

    # ------------------------------------------------------------------
    # Summary report
    # ------------------------------------------------------------------
    print(f"[sdlc upgrade] target: {target}")
    print(f"[sdlc upgrade] scaffold: {scaffold}")
    print()
    print(f"  Added: {len(added)} file(s) (new since project was initialized)")
    for f in added:
        print(f"    + {f.as_posix()}")
    print(f"  In sync: {len(in_sync)} file(s)")
    if out_of_sync:
        verb = "Overwritten (--force)" if args.force else "Out of sync"
        print(f"  {verb}: {len(out_of_sync)} file(s)")
        for f in out_of_sync:
            print(f"    ! {f.as_posix()}")
        if not args.force:
            print(
                "    → these files differ from scaffold. Review with "
                "`diff <project> <scaffold>`, then either edit manually "
                "or re-run with --force to overwrite (loses your edits)."
            )
    if rules_summary:
        print(f"  automation/rules.json: {rules_summary}")

    # ------------------------------------------------------------------
    # Per-tool slash command surfaces (Cursor / Copilot / Cline / Windsurf
    # / Continue). Auto-detect existing surfaces; add explicitly-requested
    # tools via --add-tool. Idempotent: safe_write refuses to clobber
    # user-edited files.
    # ------------------------------------------------------------------
    tools = sorted(set(detect_tool_surfaces(target)) | set(args.add_tool))
    if tools and not args.dry_run:
        from sdlc_framework.scaffold_gen import core as scaffold_gen
        for t in tools:
            try:
                written = scaffold_gen.render_for_tool(
                    t, scaffold_root=scaffold, out_root=target,
                )
                print(f"  scaffold-gen [{t}]: rendered {len(written)} file(s)")
            except ValueError as e:
                print(f"  scaffold-gen [{t}]: {e}")
    elif tools and args.dry_run:
        print(f"  [dry-run] would render scaffold for: {', '.join(tools)}")

    if args.dry_run:
        print()
        print("  [dry-run] — no files were changed.")
    return 0


def detect_tool_surfaces(target: Path) -> list[str]:
    """Return list of AI tools whose slash command surface exists in target."""
    detected: list[str] = []
    if (target / ".cursor").exists():
        detected.append("cursor")
    if (target / ".github" / "prompts").exists() or \
       (target / ".github" / "agents").exists():
        detected.append("copilot")
    if (target / ".cline").exists() or (target / ".clinerules").exists():
        detected.append("cline")
    if (target / ".windsurf").exists() or (target / ".windsurfrules").exists():
        detected.append("windsurf")
    if (target / ".continue").exists():
        detected.append("continue")
    return detected


def _default_scaffold() -> Path:
    """Locate the scaffold dir packaged with the installed framework."""
    import sdlc_framework
    return Path(sdlc_framework.__file__).resolve().parent / "scaffold"


def _merge_rules(src_path: Path, dst_path: Path, *, dry_run: bool) -> str:
    """Structurally merge ``rules.json`` — additive only.

    - Whole missing phases are appended.
    - Within a phase, missing items are inserted at the position implied
      by the scaffold's ordering: each missing item lands after the most
      recent of its scaffold-predecessors that already exists in the
      project (or at the front of the list if none exists).
    - Items already present in the project are NEVER touched. User-added
      items (not in scaffold) survive untouched.
    - On invalid JSON in either side, we bail out with a diagnostic
      string so the user can fix it manually rather than us guessing.

    Returns a one-line human-readable summary suitable for the report.
    """
    if not dst_path.exists():
        if not dry_run:
            dst_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_path, dst_path)
        return "copied (was missing in project)"

    try:
        src = json.loads(src_path.read_text(encoding="utf-8"))
        dst = json.loads(dst_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        return f"skipped (invalid JSON: {e}); inspect the file manually"

    added: list[str] = []
    src_phases = src.get("phases", []) or []
    dst_phases_by_id = {p.get("id"): p for p in (dst.get("phases", []) or [])}

    for src_phase in src_phases:
        pid = src_phase.get("id")
        if pid is None:
            continue
        if pid not in dst_phases_by_id:
            dst.setdefault("phases", []).append(src_phase)
            dst_phases_by_id[pid] = src_phase
            added.append(f"phase-{pid}")
            continue

        dst_phase = dst_phases_by_id[pid]
        dst_items = dst_phase.setdefault("items", [])
        existing_ids = {it.get("id") for it in dst_items}
        src_items = src_phase.get("items", []) or []

        for i, src_it in enumerate(src_items):
            iid = src_it.get("id")
            if iid is None or iid in existing_ids:
                continue
            insert_at = _find_insert_position(src_items, i, dst_items, existing_ids)
            dst_items.insert(insert_at, src_it)
            existing_ids.add(iid)
            added.append(iid)

    if not added:
        return "in sync"
    if not dry_run:
        dst_path.write_text(
            json.dumps(dst, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    return f"merged {len(added)} item(s): {', '.join(added)}"


def _find_insert_position(
    src_items: list[dict],
    src_index: int,
    dst_items: list[dict],
    existing_ids: set,
) -> int:
    """Where to insert ``src_items[src_index]`` into ``dst_items``.

    Walk backwards through scaffold predecessors; the first one already
    present in the project gives us the anchor. We insert immediately
    after it. If no predecessor matches, prepend.
    """
    for j in range(src_index - 1, -1, -1):
        prev_id = src_items[j].get("id")
        if prev_id in existing_ids:
            for k, dst_it in enumerate(dst_items):
                if dst_it.get("id") == prev_id:
                    return k + 1
            break
    return 0
