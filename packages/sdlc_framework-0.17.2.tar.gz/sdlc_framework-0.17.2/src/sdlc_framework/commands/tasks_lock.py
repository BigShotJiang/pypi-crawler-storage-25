"""Phase 3 lock subcommands: activate, active, unlock, force-merge.

Mutates ``automation/state.json`` only via the documented CLI surface.
Subagents should NEVER edit state.json directly; use these commands.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from sdlc_framework.tasks_loader import _utcnow_iso, load_tasks


def _state_path(target: Path) -> Path:
    return target / "automation" / "state.json"


def _load_state(target: Path) -> dict:
    p = _state_path(target)
    if not p.exists():
        return {
            "schema_version": 3,
            "phase3": {"active_feature_id": None, "lock_acquired_at": None},
        }
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        data = {}
    data.setdefault("schema_version", 3)
    data.setdefault("phase3", {"active_feature_id": None, "lock_acquired_at": None})
    return data


def _save_state(target: Path, state: dict) -> None:
    p = _state_path(target)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(state, indent=2), encoding="utf-8")


def _resolve_group_id(target: Path, ident: str) -> str | None:
    """Map a task id or feature_id to a group id (feature_id or task.id)."""
    for t in load_tasks(target):
        if t.get("id") == ident:
            return t.get("feature_id") or t["id"]
        if t.get("feature_id") == ident:
            return ident
    return None


def cmd_activate(argv: list[str]) -> int:
    if not argv:
        print("usage: sdlc tasks activate <id|feature_id>", file=sys.stderr)
        return 2
    ident = argv[0]
    target = Path.cwd()
    gid = _resolve_group_id(target, ident)
    if gid is None:
        print(
            f"[sdlc tasks activate] unknown task or feature_id: {ident}",
            file=sys.stderr,
        )
        return 1
    state = _load_state(target)
    state["phase3"]["active_feature_id"] = gid
    state["phase3"]["lock_acquired_at"] = _utcnow_iso()
    _save_state(target, state)
    print(f"[sdlc tasks activate] active group: {gid}")
    return 0


def cmd_active(argv: list[str]) -> int:  # noqa: ARG001
    state = _load_state(Path.cwd())
    p3 = state.get("phase3", {})
    aid = p3.get("active_feature_id")
    if aid is None:
        print("(no active group — engine will pick on next scan)")
    else:
        print(f"active: {aid}  (since {p3.get('lock_acquired_at')})")
    return 0


def cmd_unlock(argv: list[str]) -> int:  # noqa: ARG001
    target = Path.cwd()
    state = _load_state(target)
    state["phase3"]["active_feature_id"] = None
    state["phase3"]["lock_acquired_at"] = None
    _save_state(target, state)
    print("[sdlc tasks unlock] cleared active group")
    return 0


def cmd_force_merge(argv: list[str]) -> int:
    if "--i-accept-the-risk" not in argv:
        print(
            "[sdlc tasks force-merge] refusing without explicit "
            "`--i-accept-the-risk` flag (this bypasses code-reviewer verdict)",
            file=sys.stderr,
        )
        return 2
    ident = next((a for a in argv if not a.startswith("--")), None)
    if ident is None:
        print(
            "usage: sdlc tasks force-merge <task-id> --i-accept-the-risk",
            file=sys.stderr,
        )
        return 2
    from sdlc_framework import gh_ops
    target = Path.cwd()
    gid = _resolve_group_id(target, ident)
    branch = f"feature/{gid or ident}"
    ok, err = gh_ops.squash_merge(
        pr_ref=branch,
        subject=f"chore: force-merge {ident} via sdlc tasks force-merge",
        target=target,
    )
    if not ok:
        print(f"[sdlc tasks force-merge] failed: {err}", file=sys.stderr)
        return 1
    state = _load_state(target)
    state["phase3"]["active_feature_id"] = None
    state["phase3"]["lock_acquired_at"] = None
    _save_state(target, state)
    print(f"[sdlc tasks force-merge] merged {branch}")
    return 0
