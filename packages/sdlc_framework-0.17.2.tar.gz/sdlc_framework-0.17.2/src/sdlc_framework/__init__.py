"""SDLC Framework — local-only multi-AI SDLC tooling."""
from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("sdlc-framework")
except PackageNotFoundError:
    # Editable install before metadata is available, or running from a
    # checkout without `pip install -e .`. Fall back to a sentinel that
    # makes the missing-install case obvious.
    __version__ = "0.0.0+unknown"
