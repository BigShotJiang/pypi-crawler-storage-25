"""Parse code-reviewer verdict blocks from review markdown files.

Schema (last block in the file wins):

    <!-- sdlc:review-verdict
    verdict: PASS    # or BLOCK
    critical: 0
    high: 2
    medium: 5
    low: 3
    -->

Missing or malformed → fail-safe to BLOCK + unparseable=True.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

_BLOCK_RE = re.compile(
    r"<!--\s*sdlc:review-verdict\s*(.*?)-->",
    re.DOTALL,
)
_VALID_VERDICTS = ("PASS", "BLOCK")


@dataclass(frozen=True)
class Verdict:
    verdict: str
    critical: int
    high: int
    medium: int
    low: int
    unparseable: bool = False

    @property
    def is_pass(self) -> bool:
        return self.verdict == "PASS" and not self.unparseable

    @property
    def is_block(self) -> bool:
        return self.verdict == "BLOCK" or self.unparseable


def _block_fail() -> Verdict:
    return Verdict("BLOCK", 0, 0, 0, 0, unparseable=True)


def parse_verdict(text: str) -> Verdict:
    matches = _BLOCK_RE.findall(text or "")
    if not matches:
        return _block_fail()
    body = matches[-1]
    fields: dict[str, str] = {}
    for line in body.splitlines():
        line = line.strip()
        if not line or ":" not in line:
            continue
        key, _, val = line.partition(":")
        fields[key.strip()] = val.strip()
    verdict = fields.get("verdict", "")
    if verdict not in _VALID_VERDICTS:
        return _block_fail()
    try:
        counts = {
            k: int(fields[k]) for k in ("critical", "high", "medium", "low")
        }
    except (KeyError, ValueError):
        return _block_fail()
    if any(v < 0 for v in counts.values()):
        return _block_fail()
    return Verdict(verdict=verdict, **counts)
