"""Continue renderer — .continue/prompts/ subset (Tier 3, prompt-only)."""
from __future__ import annotations

from pathlib import Path

from .. import core, manifest
from .. import _frontmatter as fm
from .._write import safe_write

TOOL = "continue"

GUIDED_TPL = """\
This Continue prompt is read-only. Continue cannot exec terminal commands
from chat. To run **{cli_cmd}**, open your terminal and run:

```bash
{cli_cmd}
```

Then return to the chat with the output.

For the full SDLC autopilot loop (`/sdlc-auto-mad`), use Claude Code,
Cursor, or GitHub Copilot — those tools have native bash exec + subagent
dispatch and can drive the loop end-to-end.
"""


def render(*, scaffold_root: Path, out_root: Path) -> list[Path]:
    written: list[Path] = []
    out_dir = out_root / ".continue" / "prompts"
    out_dir.mkdir(parents=True, exist_ok=True)

    for name in manifest.commands_for_tool(TOOL):
        meta, _body = core.load_canonical_command(name, scaffold_root=scaffold_root)
        cli_cmd = name.replace("sdlc-", "sdlc ", 1)
        out_meta = {"description": meta.get("description", "")}
        guided = GUIDED_TPL.format(cli_cmd=cli_cmd)
        text = fm.emit_with_marker(
            meta=out_meta, body=guided,
            canonical_rel=f".claude/commands/{name}.md",
        )
        path = out_dir / f"{name}.md"
        if safe_write(path, text):
            written.append(path)
    return written
