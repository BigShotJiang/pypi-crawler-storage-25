"""GitHub Copilot renderer — .github/prompts/ + .github/agents/."""
from __future__ import annotations

import re
from pathlib import Path

from .. import core, manifest
from .. import _frontmatter as fm
from .._write import safe_write

TOOL = "copilot"

DEFAULT_TOOLS = ["agent", "search/codebase", "edit", "shell"]


def render(*, scaffold_root: Path, out_root: Path) -> list[Path]:
    written: list[Path] = []
    prompts_dir = out_root / ".github" / "prompts"
    agents_dir = out_root / ".github" / "agents"
    prompts_dir.mkdir(parents=True, exist_ok=True)
    agents_dir.mkdir(parents=True, exist_ok=True)

    for name in manifest.commands_for_tool(TOOL):
        meta, body = core.load_canonical_command(name, scaffold_root=scaffold_root)
        out_meta = {
            "description": meta.get("description", ""),
            "agent": "agent",
            "tools": list(DEFAULT_TOOLS),
        }
        text = fm.emit_with_marker(
            meta=out_meta, body=_rewrite(body),
            canonical_rel=f".claude/commands/{name}.md",
        )
        path = prompts_dir / f"{name}.prompt.md"
        if safe_write(path, text):
            written.append(path)

    for name in manifest.agents_for_tool(TOOL):
        meta, body = core.load_canonical_agent(name, scaffold_root=scaffold_root)
        out_meta = {
            "description": meta.get("description", _first_line(body)),
            "agent": "agent",
            "tools": list(DEFAULT_TOOLS),
        }
        text = fm.emit_with_marker(
            meta=out_meta, body=body,
            canonical_rel=f"agents/{name}.md",
        )
        path = agents_dir / f"{name}.agent.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        if safe_write(path, text):
            written.append(path)
    return written


def _rewrite(body: str) -> str:
    return re.sub(
        r"Use the (\S+) subagent",
        r"Hand off to the \1 subagent (via handoffs:)",
        body,
    )


def _first_line(body: str) -> str:
    for line in body.splitlines():
        s = line.strip().lstrip("#").strip()
        if s:
            return s[:120]
    return ""
