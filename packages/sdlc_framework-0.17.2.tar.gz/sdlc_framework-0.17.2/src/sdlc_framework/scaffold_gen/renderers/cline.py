"""Cline renderer — .cline/workflows/ + .clinerules warning."""
from __future__ import annotations

import re
from pathlib import Path

from .. import core, manifest
from .. import _frontmatter as fm
from .._write import safe_write

TOOL = "cline"

WARNING_BLOCK = """
<!-- scaffold-gen:tier2-warning:start -->
## SDLC Tier 2 — fresh-context-per-subagent NOT supported

Phase 3 stages (test-author -> developer-agent -> code-reviewer) execute
inside the same Cline agent session. Cline does not have named subagent
dispatch. Each `sdlc-*` workflow explicitly instructs you to re-read
`agents/<role>.md` per stage and adopt that role fresh, but discipline
is by-prompt, not process-isolated.

For strict TDD isolation, use Claude Code, Cursor, or GitHub Copilot.
<!-- scaffold-gen:tier2-warning:end -->
"""

ROLE_SWITCH_PREAMBLE = """\
> **ROLE SWITCH (Tier 2):** Before each stage, re-read the role spec at
> `agents/<role>.md` and adopt that role fresh. Do not retain context
> from the previous stage. Cline does not provide process-level subagent
> isolation - discipline is by-prompt.

"""


def render(*, scaffold_root: Path, out_root: Path) -> list[Path]:
    written: list[Path] = []
    wf_dir = out_root / ".cline" / "workflows"
    wf_dir.mkdir(parents=True, exist_ok=True)

    for name in manifest.commands_for_tool(TOOL):
        meta, body = core.load_canonical_command(name, scaffold_root=scaffold_root)
        out_meta = {"description": meta.get("description", "")}
        rewritten = _rewrite(body)
        out_body = ROLE_SWITCH_PREAMBLE + rewritten
        text = fm.emit_with_marker(
            meta=out_meta, body=out_body,
            canonical_rel=f".claude/commands/{name}.md",
        )
        path = wf_dir / f"{name}.md"
        if safe_write(path, text):
            written.append(path)

    rules = out_root / ".clinerules"
    existing = rules.read_text() if rules.exists() else ""
    if "scaffold-gen:tier2-warning:start" not in existing:
        rules.write_text(existing + WARNING_BLOCK)
        written.append(rules)
    return written


def _rewrite(body: str) -> str:
    return re.sub(
        r"Use the (\S+) subagent",
        r"Adopt the **\1** role (read `agents/<role>.md` for the spec)",
        body,
    )
