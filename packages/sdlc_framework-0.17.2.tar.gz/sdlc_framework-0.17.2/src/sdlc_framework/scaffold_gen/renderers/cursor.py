"""Cursor renderer — .cursor/commands/ + .cursor/agents/."""
from __future__ import annotations

import re
from pathlib import Path

from .. import core, manifest
from .. import _frontmatter as fm
from .._write import safe_write

TOOL = "cursor"


def render(*, scaffold_root: Path, out_root: Path) -> list[Path]:
    written: list[Path] = []
    cmd_dir = out_root / ".cursor" / "commands"
    agent_dir = out_root / ".cursor" / "agents"
    cmd_dir.mkdir(parents=True, exist_ok=True)
    agent_dir.mkdir(parents=True, exist_ok=True)

    for name in manifest.commands_for_tool(TOOL):
        meta, body = core.load_canonical_command(name, scaffold_root=scaffold_root)
        out_meta = {
            "name": name,
            "description": meta.get("description", ""),
        }
        out_body = _rewrite(body)
        text = fm.emit_with_marker(
            meta=out_meta, body=out_body,
            canonical_rel=f".claude/commands/{name}.md",
        )
        path = cmd_dir / f"{name}.md"
        if safe_write(path, text):
            written.append(path)

    for name in manifest.agents_for_tool(TOOL):
        meta, body = core.load_canonical_agent(name, scaffold_root=scaffold_root)
        out_meta = {
            "name": Path(name).name,
            "description": meta.get("description", _first_line(body)),
        }
        text = fm.emit_with_marker(
            meta=out_meta, body=body,
            canonical_rel=f"agents/{name}.md",
        )
        path = agent_dir / f"{name}.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        if safe_write(path, text):
            written.append(path)

    return written


def _rewrite(body: str) -> str:
    return re.sub(
        r"Use the (\S+) subagent",
        r"Switch to @\1 agent",
        body,
    )


def _first_line(body: str) -> str:
    for line in body.splitlines():
        s = line.strip().lstrip("#").strip()
        if s:
            return s[:120]
    return ""
