"""Ship matrix: which slash commands / agents go to which tool.

Single source of truth for tier classification. Renderers query this
to decide what to emit. Tests assert the matrix matches the spec
(docs/superpowers/specs/2026-05-02-multi-tool-slash-command-parity-design.md).
"""
from __future__ import annotations

CANONICAL_COMMANDS: tuple[str, ...] = (
    "sdlc-init", "sdlc-start", "sdlc-adopt",
    "sdlc-scan", "sdlc-resume", "sdlc-next",
    "sdlc-verify", "sdlc-tasks", "sdlc-replan",
    "sdlc-dispatch", "sdlc-dashboard",
    "sdlc-auto", "sdlc-auto-mad",
)

CANONICAL_AGENTS: tuple[str, ...] = (
    "phase-1-pm", "phase-2-architect", "phase-3-developer",
    "phase-4-qa", "phase-5-sre", "orchestrator",
    "cross/test-author", "cross/code-reviewer",
    "cross/security-reviewer", "cross/doc-keeper",
    "cross/clarification-triager", "cross/ux-designer",
)

_TIER_1_2_TOOLS = ("cursor", "copilot", "cline", "windsurf")

_CONTINUE_SUBSET = (
    "sdlc-next", "sdlc-resume", "sdlc-scan",
    "sdlc-tasks", "sdlc-verify",
)


def commands_for_tool(tool: str) -> tuple[str, ...]:
    if tool in _TIER_1_2_TOOLS:
        return CANONICAL_COMMANDS
    if tool == "continue":
        return _CONTINUE_SUBSET
    raise ValueError(f"unknown tool: {tool}")


def agents_for_tool(tool: str) -> tuple[str, ...]:
    """Only Tier 1 ships agents (named subagent dispatch)."""
    if tool in ("cursor", "copilot"):
        return CANONICAL_AGENTS
    if tool in ("cline", "windsurf", "continue"):
        return ()
    raise ValueError(f"unknown tool: {tool}")


def tier_for_tool(tool: str) -> int:
    return {
        "claude": 1, "cursor": 1, "copilot": 1,
        "cline": 2, "windsurf": 2,
        "continue": 3,
        "aider": 4, "codex": 4,
    }[tool]
