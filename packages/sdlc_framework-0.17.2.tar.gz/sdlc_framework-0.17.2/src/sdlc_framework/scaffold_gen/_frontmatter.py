"""Minimal YAML frontmatter — just enough for our scaffold needs.

We only support flat scalar keys (string/int/bool) and list-of-strings.
Avoids adding PyYAML as a dep for the framework's own scaffolding code.
"""
from __future__ import annotations

import re

_FENCE = "---"
_MARKER_TPL = "<!-- generated-from: {} -->"


def parse(text: str) -> tuple[dict, str]:
    if not text.startswith(_FENCE + "\n"):
        return {}, text
    end = text.find("\n" + _FENCE + "\n", len(_FENCE) + 1)
    if end == -1:
        return {}, text
    block = text[len(_FENCE) + 1 : end]
    body = text[end + len(_FENCE) + 2 :]
    meta: dict = {}
    cur_key: str | None = None
    for line in block.splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        if line.startswith(" ") or line.startswith("\t"):
            stripped = line.strip()
            if stripped.startswith("- ") and cur_key is not None:
                meta.setdefault(cur_key, []).append(_unquote(stripped[2:]))
            continue
        m = re.match(r"^([A-Za-z_-][\w-]*):\s*(.*)$", line)
        if not m:
            continue
        key, val = m.group(1), m.group(2).strip()
        cur_key = key
        if val == "":
            meta[key] = []
        else:
            meta[key] = _coerce(_unquote(val))
    return meta, body


def emit(meta: dict, body: str) -> str:
    if not meta:
        return body
    lines = [_FENCE]
    for k, v in meta.items():
        if isinstance(v, list):
            lines.append(f"{k}:")
            for item in v:
                lines.append(f"  - {_quote_if_needed(str(item))}")
        elif isinstance(v, bool):
            lines.append(f"{k}: {str(v).lower()}")
        else:
            lines.append(f"{k}: {_quote_if_needed(str(v))}")
    lines.append(_FENCE)
    lines.append("")
    return "\n".join(lines) + body


def emit_with_marker(*, meta: dict, body: str, canonical_rel: str) -> str:
    marker = _MARKER_TPL.format(canonical_rel)
    return emit(meta, marker + "\n\n" + body)


def _unquote(s: str) -> str:
    if len(s) >= 2 and s[0] == s[-1] and s[0] in ("'", '"'):
        return s[1:-1]
    return s


def _quote_if_needed(s: str) -> str:
    if any(c in s for c in (":", "#", "<", ">", '"')) or s.strip() != s:
        return '"' + s.replace('"', '\\"') + '"'
    return s


def _coerce(v: str):
    if v == "true":
        return True
    if v == "false":
        return False
    if v.isdigit():
        return int(v)
    return v
