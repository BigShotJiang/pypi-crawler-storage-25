"""Thin wrappers around `gh` CLI for PR creation and merge.

Pure subprocess calls; no state mutation. Callers map failures to stop
reasons (`pr_open_failed` / `merge_failed`).
"""
from __future__ import annotations

import subprocess
from pathlib import Path


def open_pr(*, branch: str, base: str, target: Path,
            draft: bool = False) -> str | None:
    """Run `gh pr create --fill`. Returns PR URL on success, None on failure."""
    cmd = ["gh", "pr", "create", "--base", base, "--head", branch, "--fill"]
    if draft:
        cmd.append("--draft")
    try:
        r = subprocess.run(cmd, cwd=str(target), capture_output=True, text=True)
    except FileNotFoundError:
        return None
    if r.returncode != 0:
        return None
    url = (r.stdout or "").strip().splitlines()
    return url[-1] if url else None


def squash_merge(*, pr_ref: str, subject: str, target: Path) -> tuple[bool, str]:
    """Run `gh pr merge --squash --delete-branch`. Returns (ok, stderr)."""
    cmd = [
        "gh", "pr", "merge", pr_ref,
        "--squash", "--delete-branch",
        "--subject", subject,
    ]
    try:
        r = subprocess.run(cmd, cwd=str(target), capture_output=True, text=True)
    except FileNotFoundError:
        return False, "gh CLI not installed"
    if r.returncode != 0:
        return False, (r.stderr or "").strip()
    return True, ""
