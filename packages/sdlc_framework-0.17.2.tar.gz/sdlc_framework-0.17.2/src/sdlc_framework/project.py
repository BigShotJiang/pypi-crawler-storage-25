"""Project context — the canonical bag of paths that the engine, CLI, and
loaders work against.

Before this module existed the engine carried four mutable module-level
globals (``ROOT``, ``RULES_PATH``, ``STATE_PATH``, ``DASHBOARD_STATE``)
which were reassigned via ``engine.set_root()``. That worked but
prevented running multiple projects in one Python process and forced
tests to save / restore globals around every fixture.

This module introduces a ``Project`` dataclass that owns the path map.
The engine still keeps its globals around as a backward-compat shim
(see :func:`engine.set_root`) so existing call sites do not have to
change in lockstep with this introduction.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Project:
    """Bag of paths and config rooted at a single project directory.

    ``Project`` instances are immutable. To "switch" projects, build a
    new instance — do not mutate fields. Use ``from_cwd()`` or
    ``from_path()`` to construct.

    Frozen on purpose: every consumer reads paths off this object, and
    accidentally mutating ``root`` mid-scan would silently corrupt the
    state.json that gets written.
    """

    root: Path

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------

    @classmethod
    def from_cwd(cls) -> Project:
        """Project rooted at the current working directory."""
        return cls(root=Path.cwd().resolve())

    @classmethod
    def from_path(cls, p: Path | str) -> Project:
        """Project rooted at the given path (resolved to absolute)."""
        return cls(root=Path(p).resolve())

    # ------------------------------------------------------------------
    # Derived path map. Properties (not fields) so they are computed
    # off ``root`` and stay consistent if the dataclass is reconstructed.
    # ------------------------------------------------------------------

    @property
    def automation_dir(self) -> Path:
        return self.root / "automation"

    @property
    def dashboard_dir(self) -> Path:
        return self.root / "dashboard"

    @property
    def rules_path(self) -> Path:
        return self.automation_dir / "rules.json"

    @property
    def state_path(self) -> Path:
        return self.automation_dir / "state.json"

    @property
    def dashboard_state_path(self) -> Path:
        return self.dashboard_dir / "state.json"

    @property
    def signoffs_dir(self) -> Path:
        return self.automation_dir / "signoffs"

    @property
    def clarifications_dir(self) -> Path:
        return self.automation_dir / "clarifications"

    @property
    def tasks_dir(self) -> Path:
        return self.automation_dir / "tasks"

    @property
    def project_yaml(self) -> Path:
        return self.root / "project.yaml"

    @property
    def context_bundle_path(self) -> Path:
        return self.automation_dir / ".context-bundle.md"

    @property
    def dashboard_context_bundle_path(self) -> Path:
        return self.dashboard_dir / ".context-bundle.md"

    @property
    def context_pins_path(self) -> Path:
        return self.automation_dir / "CONTEXT-PINS.md"

    # ------------------------------------------------------------------
    # Engine globals integration — apply this project's paths to the
    # engine module so legacy code that still reads engine.ROOT / etc.
    # sees the right values.
    # ------------------------------------------------------------------

    def activate(self) -> None:
        """Sync this project's paths onto the engine module-level globals.

        Existing code reading ``engine.ROOT`` / ``engine.STATE_PATH`` etc.
        continues to work after this call. New code should accept a
        ``Project`` parameter directly and call into pure functions.

        Note: this also stores ``self`` as ``engine.CURRENT_PROJECT_CTX``
        so callers can recover the live ``Project`` after ``set_root``.
        ``engine._ACTIVE_PROJECT`` is a *different* variable used for
        project.yaml configuration dicts; we do not touch it.
        """
        from sdlc_framework import engine
        engine.ROOT = self.root
        engine.RULES_PATH = self.rules_path
        engine.STATE_PATH = self.state_path
        engine.DASHBOARD_STATE = self.dashboard_state_path
        engine.CURRENT_PROJECT_CTX = self
