"""Auto-generated project memory bundle for sub-agents.

The bundle is a small markdown summary that orchestrators / sub-agents
read INSTEAD of full upstream artifacts when they only need orientation.

Public functions:
- ``build_bundle(state, root) -> str`` — full bundle markdown.
- ``role_slice(state, role, root) -> str`` — role-tailored subset for
  embedding in agent briefs.

Both functions are pure: no filesystem writes, no engine mutations.
"""
from __future__ import annotations

from pathlib import Path
import datetime as dt
import re

# Hard cap on the bundle file size in bytes. Anything larger is truncated
# with a marker so we never blow up an agent's context budget.
BUNDLE_HARD_CAP = 12_000

# Section-level extraction limits. Keep the bundle compact — agents fall
# back to upstream artifacts when they need more detail.
PRD_GOALS_MAX_BULLETS = 3
BULLET_MAX_CHARS = 200
ADR_MAX_ENTRIES = 8
RECENT_RUNS_MAX = 3
OPEN_CLARIFICATIONS_MAX = 5
PENDING_GATES_MAX = 5

# Map agent role (Claude name OR shared name) to the ordered list of
# sections to include in its brief slice. Roles not listed get a minimal
# default of project + active_item.
ROLE_SECTIONS: dict[str, list[str]] = {
    # PM family
    "pm-agent":              ["project", "goals", "open_clarifications"],
    "phase-1-pm":            ["project", "goals", "open_clarifications"],
    "clarification-triager": ["project", "goals", "open_clarifications"],
    # Architect / UX
    "architect-agent":       ["project", "goals", "tech_decisions", "pending_gates"],
    "phase-2-architect":     ["project", "goals", "tech_decisions", "pending_gates"],
    "ux-designer":           ["project", "goals", "tech_decisions", "pending_gates"],
    # Developer (incl. Phase 3 stage agents). ``code_structure`` is the
    # bridge from Phase 2 architecture to the agent's actual filesystem
    # decisions — without it Phase 3 reproduces the "code-soup" defect
    # that motivated the 0.16.0 series.
    "developer-agent":       ["project", "tech_decisions", "code_structure", "active_item", "pins"],
    "phase-3-developer":     ["project", "tech_decisions", "code_structure", "active_item", "pins"],
    "test-author":           ["project", "tech_decisions", "code_structure", "active_item", "pins"],
    "code-reviewer":         ["project", "tech_decisions", "code_structure", "active_item", "pins"],
    "security-reviewer":     ["project", "tech_decisions", "code_structure", "active_item", "pins"],
    # QA / SRE
    "qa-engineer":           ["project", "tech_decisions", "recent_runs", "pins"],
    "phase-4-qa":            ["project", "tech_decisions", "recent_runs", "pins"],
    "sre-agent":             ["project", "tech_decisions", "recent_runs", "pins"],
    "phase-5-sre":           ["project", "tech_decisions", "recent_runs", "pins"],
    # Doc keeper
    "doc-keeper":            ["project", "tech_decisions", "recent_runs"],
    # Orchestrator — sees the high-level state to make routing decisions
    "orchestrator":          ["project", "active_item", "open_clarifications", "pending_gates", "recent_runs"],
}

# Approximate cap for role slices (~600 tokens ≈ 2400 chars).
ROLE_SLICE_CHAR_CAP = 2400


# ---------------------------------------------------------------------------
# Section builders. Each takes (state, root) and returns a markdown string.
# Sections always include their own ``## Heading`` so the caller can
# concatenate freely.
# ---------------------------------------------------------------------------


def _project_section(state: dict, root: Path) -> str:
    proj = state.get("project") or {}
    name = proj.get("name") or "<unnamed>"
    langs = proj.get("languages") or []
    fws = proj.get("frameworks") or []
    stack = ", ".join(list(langs) + list(fws)) or "<not detected>"
    phases = state.get("phases") or []
    cur = next((p for p in phases if not p.get("complete")), None)
    if cur:
        phase_str = f"Phase {cur.get('id')} ({cur.get('pct', 0)}%)"
    else:
        phase_str = "all phases done"
    return (
        "## Project\n"
        f"- Name: {name}\n"
        f"- Stack: {stack}\n"
        f"- Phase: {phase_str}\n"
    )


def _goals_section(state: dict, root: Path) -> str:
    prd = root / "01-Planning" / "PRD.md"
    if not prd.exists():
        return "## Goals\n<NOT YET DRAFTED>\n"
    try:
        text = prd.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return "## Goals\n<unreadable PRD>\n"
    m = re.search(
        r"^##\s+Goals\b.*?\n(.*?)(?=^##\s+|\Z)",
        text, re.MULTILINE | re.DOTALL,
    )
    if not m:
        return "## Goals\n<no Goals section in PRD>\n"
    body = m.group(1)
    bullets = re.findall(r"^[-*]\s+(.+)$", body, re.MULTILINE)[:PRD_GOALS_MAX_BULLETS]
    if not bullets:
        return "## Goals\n<empty>\n"
    out = "## Goals (from PRD §Goals)\n"
    for b in bullets:
        out += f"- {b.strip()[:BULLET_MAX_CHARS]}\n"
    return out


def _tech_decisions_section(state: dict, root: Path) -> str:
    adr_dir = root / "02-Design"
    if not adr_dir.exists():
        return "## Tech decisions\n<NO ADRs YET>\n"
    adrs = sorted(
        adr_dir.glob("ADR-*.md"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if not adrs:
        return "## Tech decisions\n<NO ADRs YET>\n"
    out = "## Tech decisions (from ADRs)\n"
    for adr in adrs[:ADR_MAX_ENTRIES]:
        try:
            text = adr.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        m = re.search(r"^#\s+(.+)$", text, re.MULTILINE)
        title = (m.group(1).strip() if m else adr.stem)[:BULLET_MAX_CHARS]
        out += f"- {adr.stem}: {title}\n"
    return out


def _active_item_section(state: dict, root: Path) -> str:
    for ph in state.get("phases") or []:
        if ph.get("complete"):
            continue
        for it in ph.get("items") or []:
            if not it.get("done"):
                stage_part = f" (stage {it.get('stage')})" if it.get("stage") else ""
                return (
                    "## Active item\n"
                    f"- `{it.get('id')}` — {it.get('label', it.get('id'))}{stage_part}\n"
                )
    return "## Active item\n<all done>\n"


def _recent_runs_section(state: dict, root: Path) -> str:
    # NOTE: assumes engine writes agent_runs newest-first.
    # See engine._record_agent_run which prepends.
    runs = (state.get("agent_runs") or [])[:RECENT_RUNS_MAX]
    if not runs:
        return "## Recent agent runs\n<no runs yet>\n"
    out = "## Recent agent runs\n"
    for r in runs:
        agent = r.get("agent", "?")
        item = r.get("item_id", "?")
        status = r.get("status", "?")
        ts = r.get("ts", "?")
        out += f"- {agent} / {item} / {status} / {ts}\n"
    return out


def _open_clarifications_section(state: dict, root: Path) -> str:
    clar = state.get("clarifications") or []
    if not clar:
        return "## Open clarifications\n<none>\n"
    out = "## Open clarifications\n"
    for c in clar[:OPEN_CLARIFICATIONS_MAX]:
        path = c.get("file") or c.get("title") or "?"
        title = c.get("title") or "?"
        out += f"- `{path}`: {title}\n"
    return out


def _pending_gates_section(state: dict, root: Path) -> str:
    gates = [g for g in (state.get("gates") or []) if not g.get("approved")]
    if not gates:
        return "## Pending gates\n<none>\n"
    out = "## Pending gates\n"
    for g in gates[:PENDING_GATES_MAX]:
        gid = g.get("id", "?")
        approvers = ", ".join(g.get("approvers_required") or []) or "<unspecified>"
        out += f"- `{gid}`: approvers required: {approvers}\n"
    return out


def _code_structure_section(state: dict, root: Path) -> str:
    """Surface the Phase 2 ``Code-Structure`` map to code-writing agents.

    Without this section, developer-agent / test-author / code-reviewer /
    security-reviewer have no architectural anchor for *where* code should
    live or *which imports are legal* — and they fall back to inventing a
    folder layout from the task's ``code_glob`` alone.

    Behavior:
    - Reads ``02-Design/*Code-Structure*.md`` (excluding any in
      ``templates/``).
    - Returns the §"Container → folder map" table verbatim and a trimmed
      view of any §"Dependency rules" content (or §3) that follows.
    - Returns empty string when no Code-Structure file is present so
      pre-Fix-#1 projects do not see noise in their slice.
    """
    design = root / "02-Design"
    if not design.exists():
        return ""
    candidates = [
        p for p in design.glob("*Code-Structure*.md")
        if "templates" not in p.parts
    ]
    if not candidates:
        return ""
    try:
        text = candidates[0].read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""

    parts = ["## Code structure (from 02-Design/Code-Structure.md)"]

    # §1 container → folder map. Capture the heading + the markdown table
    # immediately under it. The regex stops at the next ``##`` heading so
    # we don't accidentally swallow §2 (the user-story map) which is for
    # bootstrap, not for the agent.
    container_match = re.search(
        r"^##\s+1\..*?Container.*?$\s*(.*?)(?=^##\s+|\Z)",
        text, re.MULTILINE | re.DOTALL,
    )
    if container_match:
        body = container_match.group(1).strip()
        # Cap at ~800 chars — enough for a 6-row table, leaves slice budget
        # for the dependency rules below.
        if len(body) > 800:
            body = body[:800].rstrip() + "\n[...]"
        parts.append("### Container → folder map\n" + body)

    # §3 dependency rules (or any heading containing "Dependency").
    deps_match = re.search(
        r"^##\s+\d*\.?\s*Dependency.*?$\s*(.*?)(?=^##\s+|\Z)",
        text, re.MULTILINE | re.DOTALL,
    )
    if deps_match:
        body = deps_match.group(1).strip()
        if len(body) > 500:
            body = body[:500].rstrip() + "\n[...]"
        parts.append("### Dependency rules\n" + body)

    if len(parts) == 1:
        # File exists but neither section parsed — better to omit than
        # ship a heading with no body.
        return ""
    return "\n\n".join(parts) + "\n"


def _pins_section(state: dict, root: Path) -> str:
    pin_file = root / "automation" / "CONTEXT-PINS.md"
    if not pin_file.exists():
        return ""
    try:
        body = pin_file.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return ""
    if not body:
        return ""
    return "## User pins\n" + body + "\n"


_SECTION_BUILDERS = {
    "project":             _project_section,
    "goals":               _goals_section,
    "tech_decisions":      _tech_decisions_section,
    "active_item":         _active_item_section,
    "recent_runs":         _recent_runs_section,
    "open_clarifications": _open_clarifications_section,
    "pending_gates":       _pending_gates_section,
    "code_structure":      _code_structure_section,
    "pins":                _pins_section,
}


def build_bundle(state: dict, root: Path) -> str:
    """Render the full project context bundle as markdown."""
    ts = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    header = (
        "# Project context bundle\n"
        f"> Auto-generated by `sdlc scan` on {ts}. DO NOT edit by hand.\n"
        "> User-curated facts live in `automation/CONTEXT-PINS.md` and are merged below.\n\n"
    )
    section_order = [
        "project",
        "goals",
        "tech_decisions",
        "active_item",
        "recent_runs",
        "open_clarifications",
        "pending_gates",
    ]
    parts = [header]
    for name in section_order:
        chunk = _SECTION_BUILDERS[name](state, root)
        parts.append(chunk.rstrip() + "\n\n")
    pins = _pins_section(state, root)
    if pins:
        parts.append(pins.rstrip() + "\n")
    bundle = "".join(parts).rstrip() + "\n"
    if len(bundle.encode("utf-8")) > BUNDLE_HARD_CAP:
        bundle = (
            bundle[: BUNDLE_HARD_CAP - 200].rstrip()
            + "\n\n[... bundle truncated to fit hard cap; see source files]\n"
        )
    return bundle


def role_slice(state: dict, role: str, root: Path) -> str:
    """Return a role-tailored subset of the bundle for brief embedding.

    Falls back to ``["project", "active_item"]`` when ``role`` is unknown.
    """
    sections = ROLE_SECTIONS.get(role, ["project", "active_item"])
    parts = []
    for name in sections:
        builder = _SECTION_BUILDERS.get(name)
        if not builder:
            continue
        chunk = builder(state, root)
        if chunk:
            parts.append(chunk.rstrip())
    out = "\n\n".join(parts).strip()
    if len(out) > ROLE_SLICE_CHAR_CAP:
        out = out[: ROLE_SLICE_CHAR_CAP - 50].rstrip() + "\n[... slice truncated]"
    return out


def write_bundle_files(state: dict, root: Path) -> None:
    """Render the bundle and write to both canonical paths.

    Mirrors the dual-write pattern used for state.json so the dashboard host
    and the engine see identical content.
    """
    bundle = build_bundle(state, root)
    targets = [
        root / "automation" / ".context-bundle.md",
        root / "dashboard" / ".context-bundle.md",
    ]
    for path in targets:
        path.parent.mkdir(parents=True, exist_ok=True)
        # Atomic-ish write: tmp + rename keeps watchers from reading partials.
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(bundle, encoding="utf-8")
        tmp.replace(path)
