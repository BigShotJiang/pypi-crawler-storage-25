#!/bin/bash
# gh-issue.sh — file a GitHub Issue for a clarification or pending gate.
#
# Usage:
#   scripts/gh-issue.sh --clarification <path-to-clarification.md>
#   scripts/gh-issue.sh --gate <gate-id>
#
# Behaviour:
#   - Idempotent: if issue_url: already present in the file, exits 0 without calling gh.
#   - If gh CLI missing or not authenticated, logs a warning and exits 0 (observability rule).
#   - Misuse (missing flag value) exits 2.

set -u
PATH="${PATH}:/usr/bin:/bin:/usr/sbin:/sbin"

usage() {
  echo "usage: $0 --clarification <file> | --gate <gate-id>" >&2
  exit 2
}

MODE=""
ARG=""
case "${1:-}" in
  --clarification) MODE=clarification; ARG="${2:-}" ;;
  --gate)          MODE=gate;          ARG="${2:-}" ;;
  *) usage ;;
esac
[ -z "$ARG" ] && usage

ROOT="${SDLC_LOG_ROOT:-}"
if [ -z "$ROOT" ]; then ROOT="$(cd "$(dirname "$0")/.." && pwd)"; fi
cd "$ROOT" || { echo "[gh-issue] WARN: cannot cd $ROOT" >&2; exit 0; }

warn() { echo "[gh-issue] $*" >&2; }

if ! command -v gh >/dev/null 2>&1; then
  warn "gh CLI not installed; install: https://cli.github.com/"
  exit 0
fi

if ! gh auth status >/dev/null 2>&1; then
  warn "gh not authenticated; run 'gh auth login'"
  exit 0
fi

write_url_into() {
  # Append "issue_url: <url>" after the first H1 in the file; atomic rewrite.
  local file="$1"; local url="$2"
  local tmp="$file.tmp.$$"
  awk -v url="$url" '
    BEGIN { written=0 }
    /^# / && !written { print; print "issue_url: " url; written=1; next }
    { print }
    END { if (!written) print "issue_url: " url }
  ' "$file" > "$tmp" && mv "$tmp" "$file"
}

case "$MODE" in
  clarification)
    file="$ARG"
    if [ ! -f "$file" ]; then warn "file not found: $file"; exit 0; fi
    if grep -q '^issue_url:' "$file"; then
      url="$(grep -m1 '^issue_url:' "$file" | sed 's/^issue_url:[[:space:]]*//')"
      echo "[gh-issue] existing: $url" >&2
      exit 0
    fi
    title="$(grep -m1 '^# ' "$file" | sed 's/^# //')"
    [ -z "$title" ] && title="SDLC clarification: $(basename "$file")"
    body="$(cat "$file")"$'\n\n---\nFiled from SDLC framework. See '"$file"
    url="$(gh issue create \
      --title "$title" \
      --body "$body" \
      --label sdlc-framework \
      --label sdlc-clarification 2>/dev/null | tail -n1)"
    if [ -z "$url" ]; then warn "gh issue create failed"; exit 0; fi
    write_url_into "$file" "$url"
    echo "[gh-issue] created: $url"
    ;;
  gate)
    gid="$ARG"
    state="$ROOT/automation/state.json"
    if [ ! -f "$state" ]; then warn "no state.json; run engine first"; exit 0; fi
    label="$(python3 -c "
import json,sys
s=json.load(open('$state'))
g=next((g for g in s.get('gates',[]) if g.get('id')=='$gid'),None)
print(g.get('label','') if g else '')
")"
    instruction="$(python3 -c "
import json
s=json.load(open('$state'))
g=next((g for g in s.get('gates',[]) if g.get('id')=='$gid'),None)
print(g.get('instruction','') if g else '')
")"
    approvers="$(python3 -c "
import json
s=json.load(open('$state'))
g=next((g for g in s.get('gates',[]) if g.get('id')=='$gid'),None)
print(', '.join(g.get('approvers_required',[])) if g else '')
")"
    [ -z "$label" ] && { warn "gate $gid not found in state.json"; exit 0; }
    signoff="$ROOT/automation/signoffs/$gid.yaml"
    if [ -f "$signoff" ] && grep -q '^issue_url:' "$signoff"; then
      url="$(grep -m1 '^issue_url:' "$signoff" | sed 's/^issue_url:[[:space:]]*//')"
      echo "[gh-issue] existing: $url" >&2
      exit 0
    fi
    title="🔒 Gate pending: $label"
    body="$(printf '%s\n\n%s\n\nApprovers required: %s\n\nApprove by writing approved: true to automation/signoffs/%s.yaml' \
      "$instruction" "Filed from SDLC framework." "$approvers" "$gid")"
    url="$(gh issue create \
      --title "$title" \
      --body "$body" \
      --label sdlc-framework \
      --label sdlc-gate 2>/dev/null | tail -n1)"
    if [ -z "$url" ]; then warn "gh issue create failed"; exit 0; fi
    if [ ! -f "$signoff" ]; then
      mkdir -p "$(dirname "$signoff")"
      printf 'gate_id: %s\napproved: false\nissue_url: %s\n' "$gid" "$url" > "$signoff"
    else
      printf 'issue_url: %s\n' "$url" >> "$signoff"
    fi
    echo "[gh-issue] created: $url"
    ;;
esac

exit 0
