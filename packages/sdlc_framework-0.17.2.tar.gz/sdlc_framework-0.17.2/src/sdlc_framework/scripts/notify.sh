#!/bin/bash
# notify.sh — fire a desktop notification and append a structured log line.
#
# Usage:
#   scripts/notify.sh <kind> <id> <title> <body>
#
# kind ∈ {clarification, gate, info}
#
# Behaviour:
#   - macOS (Darwin)  → osascript display notification (sound on gate)
#   - Linux + notify-send → notify-send -u critical|normal
#   - else            → silent fallback (log line still written)
#   - Always appends ts<TAB>kind<TAB>id<TAB>title<TAB>body to automation/notifications.log
#   - Self-trims to 50 lines (flock-guarded if available)
#   - Exits 0 on production paths; exit 2 only on misuse.
#
# Env overrides:
#   SDLC_LOG_ROOT       — repo root (tests use this to redirect)
#   SDLC_FORCE_PLATFORM — Darwin | Linux | other (tests use this to bypass uname)

set -u

# Ensure system tool PATH so that callers can constrain PATH to a stub dir
# (e.g. for tests) without breaking core utilities like wc/tail/mv/date.
PATH="${PATH}:/usr/bin:/bin:/usr/sbin:/sbin"

KIND="${1:-}"; ID="${2:-}"; TITLE="${3:-}"; BODY="${4:-}"
if [ -z "$KIND" ] || [ -z "$ID" ] || [ -z "$TITLE" ] || [ -z "$BODY" ]; then
  echo "usage: $0 <kind> <id> <title> <body>" >&2
  exit 2
fi

ROOT="${SDLC_LOG_ROOT:-}"
if [ -z "$ROOT" ]; then
  ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fi
LOG="$ROOT/automation/notifications.log"
LOCK="$ROOT/automation/.notify.lock"

warn() { echo "[notify] WARN: $*" >&2; }

mkdir -p "$(dirname "$LOG")" 2>/dev/null || warn "cannot create log dir"

PLATFORM="${SDLC_FORCE_PLATFORM:-$(uname -s 2>/dev/null || echo unknown)}"

case "$PLATFORM" in
  Darwin)
    if command -v osascript >/dev/null 2>&1; then
      ESC_TITLE=${TITLE//\"/\\\"}
      ESC_BODY=${BODY//\"/\\\"}
      ESC_KIND=${KIND//\"/\\\"}
      if [ "$KIND" = "gate" ]; then
        osascript -e "display notification \"$ESC_BODY\" with title \"$ESC_TITLE\" subtitle \"$ESC_KIND\" sound name \"default\"" \
          >/dev/null 2>&1 || warn "osascript failed"
      else
        osascript -e "display notification \"$ESC_BODY\" with title \"$ESC_TITLE\" subtitle \"$ESC_KIND\"" \
          >/dev/null 2>&1 || warn "osascript failed"
      fi
    fi
    ;;
  Linux)
    if command -v notify-send >/dev/null 2>&1; then
      URGENCY=normal
      if [ "$KIND" = "gate" ]; then URGENCY=critical; fi
      notify-send --app-name=SDLC -u "$URGENCY" "$TITLE" "$BODY" >/dev/null 2>&1 || warn "notify-send failed"
    fi
    ;;
  *) ;;  # silent fallback
esac

NOW="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
LINE=$(printf '%s\t%s\t%s\t%s\t%s\n' "$NOW" "$KIND" "$ID" "$TITLE" "$BODY")
printf '%s\n' "$LINE" >> "$LOG" 2>/dev/null || { warn "cannot append to $LOG"; exit 0; }

prune() {
  LINES=$(wc -l < "$LOG" 2>/dev/null | tr -d ' ' || echo 0)
  if [ "${LINES:-0}" -gt 50 ]; then
    tail -n 50 "$LOG" > "$LOG.tmp" 2>/dev/null && mv "$LOG.tmp" "$LOG" 2>/dev/null || warn "prune failed"
  fi
}

if command -v flock >/dev/null 2>&1; then
  ( flock -x 9 || { warn "flock failed"; exit 0; }; prune ) 9>"$LOCK"
else
  prune
fi

exit 0
