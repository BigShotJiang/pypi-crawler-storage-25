#!/usr/bin/env bash
# build-ai-configs.sh
# Generates AI tool configs from shared sources.
#
# Source files:
#   ai-tools/shared-prompts/_header-<tool>.md    per-tool header
#   ai-tools/shared-prompts/standards.md         shared body
#
# Output (each prefixed with AUTO-GENERATED comment):
#   ai-tools/claude/CLAUDE.md
#   ai-tools/cursor/.cursorrules
#   ai-tools/github-copilot/copilot-instructions.md
#   ai-tools/codex/AGENTS.md
#   ai-tools/aider/CONVENTIONS.md
#   ai-tools/windsurf/.windsurfrules
#   ai-tools/cline/.clinerules
#   ai-tools/continue/.continuerules
#
# Idempotent: re-running with no source change produces no diff.

set -euo pipefail

ROOT="${SDLC_LOG_ROOT:-}"
if [ -z "$ROOT" ]; then ROOT="$(cd "$(dirname "$0")/.." && pwd)"; fi
SP="$ROOT/ai-tools/shared-prompts"

generate() {
  local tool="$1"
  local out_path="$2"
  local header="$SP/_header-${tool}.md"
  local body="$SP/standards.md"

  if [ ! -f "$body" ]; then
    echo "ERR: missing $body" >&2
    exit 1
  fi
  if [ ! -f "$header" ]; then
    echo "  [skip] $tool: $header not present yet"
    return 0
  fi

  mkdir -p "$(dirname "$out_path")"
  {
    echo "<!-- AUTO-GENERATED FROM ai-tools/shared-prompts/. DO NOT EDIT DIRECTLY. -->"
    echo "<!-- To change: edit _header-${tool}.md or standards.md, then run scripts/build-ai-configs.sh -->"
    echo
    cat "$header"
    echo
    cat "$body"
  } > "$out_path"
  echo "  [ok] $out_path"
}

echo "==> Generating AI tool configs from $SP"
generate claude    "$ROOT/ai-tools/claude/CLAUDE.md"
generate cursor    "$ROOT/ai-tools/cursor/.cursorrules"
generate copilot   "$ROOT/ai-tools/github-copilot/copilot-instructions.md"
generate codex     "$ROOT/ai-tools/codex/AGENTS.md"
generate aider     "$ROOT/ai-tools/aider/CONVENTIONS.md"
generate windsurf  "$ROOT/ai-tools/windsurf/.windsurfrules"
generate cline     "$ROOT/ai-tools/cline/.clinerules"
generate continue  "$ROOT/ai-tools/continue/.continuerules"
echo "==> Done."
