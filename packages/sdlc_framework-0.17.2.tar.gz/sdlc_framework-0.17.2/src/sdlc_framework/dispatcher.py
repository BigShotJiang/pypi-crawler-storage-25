"""
SDLC Dispatcher.

Reads automation/state.json and prints which agent to invoke next, plus
a ready-to-paste brief for that agent.

Usage:
    sdlc dispatch            # human-readable
    sdlc dispatch --json     # machine-readable
    sdlc dispatch --brief    # also writes brief file under agents/_briefs/
"""

from __future__ import annotations
import argparse
import datetime as dt
import json
import sys
from pathlib import Path


def _root() -> Path:
    return Path.cwd()


def _state_path() -> Path:
    return _root() / "automation" / "state.json"


def _briefs_dir() -> Path:
    return _root() / "agents" / "_briefs"


PHASE_AGENT = {1: "pm-agent", 2: "architect-agent", 3: "developer-agent", 4: "sre-agent"}


def load_state() -> dict:
    p = _state_path()
    if not p.exists():
        print("ERROR: automation/state.json not found. Run: sdlc scan", file=sys.stderr)
        sys.exit(1)
    return json.loads(p.read_text())


def build_brief(decision: dict, state: dict) -> str:
    if decision["action"] != "invoke":
        return ""
    ph = decision["phase"]
    item_id = decision["item_id"]
    item_label = decision["item_label"]

    # Find the full item dict in state for the failing-check messages
    item_full: dict = {}
    for p in state.get("phases", []):
        if p.get("id") == ph:
            for it in p.get("items", []):
                if it.get("id") == item_id:
                    item_full = it
                    break
            break

    fail_msgs = [c["msg"] for c in item_full.get("checks", []) if not c["ok"]]
    inputs_by_phase = {
        1: ["01-Planning/templates/", "(any filled artifacts in 01-Planning/)"],
        2: ["01-Planning/PRD.md (if exists)", "01-Planning/Requirements*.md", "02-Design/templates/"],
        3: ["02-Design/", "03-Development/standards/", "(neighbor files in src/)"],
        4: ["02-Design/01-Architecture.md", "04-Testing-Deploy/templates/"],
    }
    parallel = decision.get("parallel_agents") or []
    parallel_line = (
        f"\n## Parallel cross-agents (suggested)\n" + "\n".join(f"- `{a}`" for a in parallel) + "\n"
        if parallel else ""
    )
    return f"""# Agent Brief — {decision['agent']} / {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}

## Context
- Phase: {ph}
- Pending DoD item: `{item_id}` — {item_label}
- Why blocked: {'; '.join(fail_msgs) if fail_msgs else '(no failure msg)'}
- State snapshot: `automation/state.json` (overall {state['overall_pct']}%)

## Task
Satisfy DoD item `{item_id}` per rule in `automation/rules.json`. Specifically:
**{item_label}**.
{parallel_line}
## Inputs to read first
{chr(10).join(f"- `{p}`" for p in inputs_by_phase[ph])}
- `automation/rules.json` → block matching this item id
- `agents/{['phase-1-pm','phase-2-architect','phase-3-developer','phase-4-sre'][ph-1]}.md` (your full spec)

## Hard constraints
- Don't leave `{{{{...}}}}` placeholders.
- Don't edit anything outside the deliverable for this item.
- Stop if you hit any AGENT-LOOP STOP trigger (ambiguity / conflict / gate / high-risk).

## Done criteria
- Deliverable file written (NOT into `templates/`).
- Run: `sdlc scan --print` → item flips `done: true`.
- Conventional Commit message ready.

## Hand-off
- Notify orchestrator with: files_changed, evidence (1-line per file), verified=yes/no, open_questions, next_agent.
"""


def fmt_human(decision: dict, state: dict) -> str:
    out = []
    out.append("=" * 60)
    out.append(f"SDLC Dispatch — {dt.datetime.now(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}")
    out.append(f"Overall: {state['overall_pct']}%  ({state['total_done']}/{state['total_all']})")
    out.append("=" * 60)
    out.append(f"Action:  {decision['action'].upper()}")
    out.append(f"Reason:  {decision['reason']}")
    out.append(f"Agent:   {decision['agent']}")

    parallel = decision.get("parallel_agents") or []
    if parallel:
        out.append(f"Parallel: {', '.join(parallel)}")

    blocked = decision.get("blocked_by")
    if blocked:
        bits = []
        if blocked.get("phase") is not None: bits.append(f"phase {blocked['phase']}")
        if blocked.get("gate"): bits.append(f"gate {blocked['gate']}")
        if blocked.get("clarification"): bits.append(f"{blocked['clarification']} clarif")
        if blocked.get("high_risk_item"): bits.append(f"high-risk {blocked['high_risk_item']}")
        out.append(f"Blocked: {', '.join(bits)}")

    if decision["action"] == "invoke":
        item_id = decision.get("item_id")
        out.append("")
        out.append(f"Item:    {item_id} — {decision.get('item_label')}")
        # Find full item for check msgs
        for p in state.get("phases", []):
            if p.get("id") == decision.get("phase"):
                for it in p.get("items", []):
                    if it.get("id") == item_id:
                        out.append("Why fail:")
                        for c in it.get("checks", []):
                            mark = "✓" if c["ok"] else "✗"
                            out.append(f"  {mark} {c['msg']}")
                        break
        out.append("")
        out.append("Invocation hints:")
        out.append(f"  Claude Code:   /agents → pick {decision['agent']}, paste brief below")
        out.append(f"                 OR ask Claude: 'use the {decision['agent']} subagent to ...'")
        out.append(f"  Cursor:        @ paste content of agents/{decision['agent']}.md as system, then send brief")
        out.append(f"  Codex CLI:     codex --instructions agents/{decision['agent']}.md")
        out.append(f"  Aider:         /load agents/{decision['agent']}.md && /paste brief")
    elif decision["action"] == "stop_for_gate":
        g = decision.get("gate") or {}
        out.append("")
        out.append(f"Gate id:      {g.get('id')}")
        out.append(f"Approvers:    {', '.join(g.get('approvers_required', []))}")
        out.append(f"Instruction:  {g.get('instruction')}")
    elif decision["action"] == "ask_user":
        clarifs = state.get("clarifications") or []
        if clarifs:
            out.append("")
            out.append("Open clarifications:")
            for c in clarifs:
                out.append(f"  ? {c.get('title','?')}  ({c.get('file','?')})")
    elif decision["action"] == "done":
        out.append("\n🎉  All phases complete. Nothing to dispatch.")
    return "\n".join(out)


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="sdlc dispatch")
    p.add_argument("--json", action="store_true")
    p.add_argument("--brief", action="store_true", help="also save brief to agents/_briefs/")
    args = p.parse_args(argv)

    state = load_state()
    decision = state.get("next_dispatch") or {
        "action": "done", "agent": None, "reason": "no next_dispatch",
        "parallel_agents": [], "blocked_by": None,
    }

    if args.json:
        print(json.dumps(decision, indent=2, ensure_ascii=False))
        return 0

    print(fmt_human(decision, state))

    if args.brief and decision["action"] == "invoke":
        briefs = _briefs_dir()
        briefs.mkdir(parents=True, exist_ok=True)
        ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d-%H%M%S")
        brief_path = briefs / f"{ts}-{decision['agent']}-{decision['item_id']}.md"
        brief_path.write_text(build_brief(decision, state))
        print(f"\nBrief saved: {brief_path.relative_to(_root())}")
    elif decision["action"] == "invoke":
        print("\n--- BRIEF (paste to specialist) ---\n")
        print(build_brief(decision, state))

    return 0
