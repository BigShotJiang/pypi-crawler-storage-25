# Product Requirements Document — {{PROJECT_NAME}}

| Field | Value |
|---|---|
| **Version** | 0.1 |
| **Author** | {{AUTHOR}} |
| **Last updated** | {{YYYY-MM-DD}} |
| **Status** | Draft / In Review / Approved |
| **Sponsor** | {{EXEC_SPONSOR}} |

---

## 1. TL;DR
> 3–5 câu: vấn đề là gì, ta giải quyết ra sao, tại sao bây giờ.

## 2. Problem Statement
- **Who** is affected?
- **What** is the pain?
- **Where / when** does it happen?
- **Why** does it matter (business impact, $$$ at stake)?
- **Evidence** (data, interviews, support tickets):

## 3. Goals & Non-Goals

### 3.1 Goals (in scope)
1. ...
2. ...

### 3.2 Non-Goals (out of scope, reduce ambiguity)
1. ...
2. ...

## 4. Target Users / Personas
| Persona | Primary need | Frequency of use |
|---|---|---|
| ... | ... | ... |

## 5. Success Metrics (North Star + guardrails)
| Metric | Type | Baseline | Target | Source |
|---|---|---|---|---|
| Activation rate | NSM | 22% | 35% | Mixpanel |
| p95 latency | Guardrail | n/a | < 300ms | Datadog |

## 6. Solution Overview
> Mô tả cao tầng — KHÔNG phải design chi tiết (đó là Phase 2).

## 7. Functional Requirements (numbered, testable)
- **FR-001**: System MUST allow user to ...
- **FR-002**: System SHOULD ...

## 8. Non-Functional Requirements
| Category | Requirement |
|---|---|
| Performance | p95 < 300ms; throughput ≥ 1k rps |
| Availability | 99.9% / month |
| Security | OWASP ASVS Level 2; SOC2 controls |
| Privacy | GDPR-compliant; data retention ≤ 90d |
| Accessibility | WCAG 2.1 AA |
| Localization | EN, VI |

## 9. Constraints & Assumptions
- Constraint: ...
- Assumption: ...

## 10. Dependencies
- Internal: ...
- External: ...

## 11. Risks (top 5 — full register in `05-Risk-Register.md`)
| # | Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| 1 | ... | H/M/L | H/M/L | ... |

## 12. Timeline (high-level — detailed in roadmap)
| Milestone | Date | Owner |
|---|---|---|
| PRD approved | YYYY-MM-DD | PM |
| Design done | YYYY-MM-DD | Lead Eng |
| Beta launch | YYYY-MM-DD | PM |
| GA | YYYY-MM-DD | PM |

## 13. Open Questions
- [ ] Q1: ...
- [ ] Q2: ...

## 14. Appendix
- Research links
- Competitor analysis
- Mockups (link Figma)

---
**Sign-offs**
- [ ] Product Sponsor
- [ ] Eng Lead
- [ ] Design Lead
- [ ] QA Lead
- [ ] Security
