# Stakeholder Map & RACI — {{PROJECT_NAME}}

## RACI Matrix
> **R**esponsible (does the work) · **A**ccountable (final decision, only ONE) · **C**onsulted (input) · **I**nformed (kept in loop)

| Activity / Decision | Sponsor | PM | Eng Lead | Dev Team | QA | Design | Security | Ops |
|---|---|---|---|---|---|---|---|---|
| Approve PRD | A | R | C | I | C | C | C | I |
| Architecture decisions | I | C | A/R | C | I | C | C | C |
| Implementation | I | I | A | R | C | I | I | I |
| QA strategy | I | C | C | C | A/R | I | C | I |
| Security review | I | C | C | I | I | I | A/R | C |
| Production release | A | R | C | C | C | I | C | C |
| Incident response | I | I | A | R | C | I | C | R |

## Communication Plan

| Audience | Channel | Cadence | Owner |
|---|---|---|---|
| Exec sponsor | Email digest | Weekly Fri | PM |
| Core team | Standup | Daily 9:30 | Scrum Master |
| Cross-team deps | Slack #proj-{{name}} | Async, response < 4h | PM |
| All-hands update | Slack #all-eng | Bi-weekly | PM |
| Post-launch metrics | Dashboard + email | Weekly | PM |

## Stakeholder Register
| Name | Role | Influence | Interest | Strategy |
|---|---|---|---|---|
| {{Name}} | Exec Sponsor | High | High | Manage closely (weekly 1:1) |
| {{Name}} | Customer Lead | Med | High | Keep informed (bi-weekly demo) |
| {{Name}} | Legal | Low | Med | Consult on compliance |
