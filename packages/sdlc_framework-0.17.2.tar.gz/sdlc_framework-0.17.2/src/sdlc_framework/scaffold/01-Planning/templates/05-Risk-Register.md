# Risk Register — {{PROJECT_NAME}}

> Cập nhật **weekly**. Risk score = Likelihood × Impact (1–5 scale).

| ID | Risk | Category | Likelihood (1-5) | Impact (1-5) | Score | Mitigation | Contingency | Owner | Status |
|---|---|---|---|---|---|---|---|---|---|
| R-001 | Third-party API rate-limit blocks launch | Tech | 3 | 4 | 12 | Cache layer + fallback | Switch to alt vendor | Eng Lead | Open |
| R-002 | Key dev on PTO during code freeze | People | 2 | 3 | 6 | Knowledge-share sessions, docs | Pair-rotation | PM | Mitigated |
| R-003 | Compliance audit before GA | Legal | 2 | 5 | 10 | Pre-audit by external firm | Delay 2 weeks | Sponsor | Open |
| R-004 | AI tool generates non-compliant code | Tech/Quality | 3 | 3 | 9 | Mandatory human review for security-sensitive paths; lint rules | Roll back via Git | Eng Lead | Open |

## Risk Categories
- Tech (architecture, deps, perf)
- People (team capacity, skills)
- Process (estimation, scope creep)
- External (vendor, market, regulation)
- Security (data breach, compliance)

## Heatmap (visual)
```
Impact ↑
   5 |       R-003 |          |
   4 |       R-001 |          |
   3 | R-002       | R-004    |
   2 |             |          |
   1 |             |          |
     +------+------+------+------+
       1     2     3     4     5  → Likelihood
```

## Review cadence
- Weekly: PM updates
- Bi-weekly: Eng Lead reviews tech risks
- Monthly: Sponsor sign-off
