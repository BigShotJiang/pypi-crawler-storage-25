# Requirements Specification — {{PROJECT_NAME}}

> Đây là tài liệu **chi tiết hơn PRD** — dùng cho QA & dev để validate.

## 1. Functional Requirements

### 1.1 User Authentication
| ID | Requirement | Priority | Source | Test ref |
|---|---|---|---|---|
| FR-AUTH-001 | System MUST support OAuth2 (Google, MS) | P0 | PRD §7 | TC-AUTH-* |
| FR-AUTH-002 | System MUST enforce MFA for admin role | P0 | Security | TC-AUTH-* |
| FR-AUTH-003 | Sessions MUST expire after 30 min idle | P1 | Security | TC-AUTH-* |

### 1.2 {{Module 2}}
| ID | Requirement | Priority | Source | Test ref |
|---|---|---|---|---|
| FR-XXX-001 | ... | ... | ... | ... |

## 2. Non-Functional Requirements

### 2.1 Performance
- NFR-PERF-001: API p95 latency < 300ms under 1k rps load
- NFR-PERF-002: Page load TTI < 2s on 4G
- NFR-PERF-003: DB query p99 < 50ms

### 2.2 Scalability
- NFR-SCAL-001: Horizontal scale to 10x baseline within 5 min
- NFR-SCAL-002: Support 100k concurrent connections

### 2.3 Security
- NFR-SEC-001: OWASP ASVS Level 2 compliance
- NFR-SEC-002: All data at rest encrypted (AES-256)
- NFR-SEC-003: TLS 1.3 in transit
- NFR-SEC-004: Audit log for all admin actions, retained 1y

### 2.4 Reliability
- NFR-REL-001: 99.9% monthly availability
- NFR-REL-002: RTO ≤ 1h, RPO ≤ 5min
- NFR-REL-003: Graceful degradation if downstream unavailable

### 2.5 Observability
- NFR-OBS-001: Structured JSON logs with trace_id
- NFR-OBS-002: RED metrics (Rate, Errors, Duration) per endpoint
- NFR-OBS-003: Alert on SLO burn rate > 2x

### 2.6 Maintainability
- NFR-MAINT-001: Unit test coverage ≥ 80% for business logic
- NFR-MAINT-002: All public APIs documented (OpenAPI)
- NFR-MAINT-003: Cyclomatic complexity ≤ 10 per function

### 2.7 Compliance
- NFR-COMP-001: GDPR — right to erasure within 30d
- NFR-COMP-002: SOC2 Type II controls
- NFR-COMP-003: Data residency: {{region}}

## 3. Interface Requirements
- UI: WCAG 2.1 AA
- API: REST + OpenAPI 3.1, versioned `/v1/...`
- Events: AsyncAPI 2.6

## 4. Data Requirements
- Retention: hot 90d, warm 1y, cold 7y
- Backup: daily, 30d retention
- PII fields: see `02-Design/templates/03-DB-Schema.md` (column `pii_class`)

## 5. Traceability Matrix
| FR/NFR ID | PRD section | User Story | Test case |
|---|---|---|---|
| FR-AUTH-001 | §7 | US-005 | TC-AUTH-001..005 |
