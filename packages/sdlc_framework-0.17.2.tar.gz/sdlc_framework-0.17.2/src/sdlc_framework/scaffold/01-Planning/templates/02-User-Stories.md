# User Stories — {{PROJECT_NAME}}

> Format: **As a** [persona], **I want** [capability], **so that** [benefit].
> Mỗi story phải INVEST: Independent, Negotiable, Valuable, Estimable, Small, Testable.

## Story Map (high-level)

```
Epic: {{EPIC_NAME}}
 ├── Theme A
 │    ├── US-001
 │    └── US-002
 └── Theme B
      ├── US-003
      └── US-004
```

---

## US-001 — {{Short title}}

| | |
|---|---|
| **Epic** | {{Epic name}} |
| **Priority** | P0 / P1 / P2 |
| **Estimate** | {{story points or t-shirt size}} |
| **Owner** | {{name}} |

### Story
**As a** {{persona}},
**I want** {{capability}},
**so that** {{benefit}}.

### Acceptance Criteria (Given / When / Then)
- [ ] **Scenario 1 — happy path**
  - Given ...
  - When ...
  - Then ...
- [ ] **Scenario 2 — edge case (empty input)**
  - Given ...
  - When ...
  - Then ...
- [ ] **Scenario 3 — error path**
  - Given ...
  - When ...
  - Then ... (must show user-friendly error)

### Out of scope
- ...

### Dependencies
- Blocked by: US-XXX
- Blocks: US-YYY

### Notes for AI Coding Assistant
> Hint dành cho Claude/Copilot/Cursor khi implement:
- Reuse existing component `<X>` instead of creating new one.
- API contract: see `../02-Design/templates/02-API-Spec.md#endpoint-name`.
- Error handling pattern: follow `03-Development/standards/error-handling.md`.

---

## US-002 — ...

(repeat block above)
