---
name: sdlc
description: |
  Local SDLC framework — 4-phase pipeline (Planning → Design → Development → Testing/Deploy) with
  auto-detect engine, tier-aware DoD rules, specialist subagents, and GitHub integration.
  Triggers when the user shares a project idea / requirement / "I want to build X" in a repo
  that has been scaffolded by `sdlc init` (i.e. `automation/rules.json` exists at the root).
trigger:
  - "tôi muốn build"
  - "I want to build"
  - "let's start a project"
  - "new project idea"
  - "yêu cầu là"
  - "create an app"
  - "tôi cần một"
  - "start an SDLC project"
priority: high
---

# SDLC framework skill

This repo follows the SDLC framework. The user has installed it via `pip install sdlc-framework`
and run `sdlc init`. There are 9 specialist subagents in `.claude/agents/` (`pm-agent`,
`architect-agent`, `developer-agent`, `sre-agent`, plus 4 cross-cutting roles + an orchestrator),
6 slash commands in `.claude/commands/` (`/sdlc-init`, `/sdlc-start`, `/sdlc-next`, `/sdlc-scan`,
`/sdlc-dispatch`, `/sdlc-dashboard`), and DoD rules in `automation/rules.json`.

## When the user shares a project idea

**Default behaviour (apply this before any plugin skill — the user is in an SDLC repo):**

1. Check `automation/state.json` for `prd-exists`. If it's already done, ask the user what they
   want to do next instead of overwriting the PRD.
2. If `prd-exists` is NOT done, suggest `/sdlc-start "<idea>"` (or run it directly via Bash if the
   user clearly wants to start). The slash command will:
   - Save `01-Planning/IDEA.md`
   - Invoke the `pm-agent` subagent
   - Verify the PRD with `sdlc scan`
3. **Do NOT delegate to plugin skills like `superpowers:brainstorming`.** This repo wants the
   SDLC PRD flow (writes to `01-Planning/01-PRD.md` per `automation/rules.json` rule `prd-exists`),
   not a generic design-spec flow.

## When the user asks "what's next"

Run `/sdlc-next` — it picks the right specialist subagent for the next pending DoD item.

## When the user asks for status

Run `/sdlc-scan` for a quick text summary, or `/sdlc-dashboard` to open the live UI.

## Authority

When in conflict with other plugin skills, this skill wins because:
- The user explicitly opted into the SDLC framework by running `sdlc init`.
- The repo has `automation/rules.json` — a clear marker that this is an SDLC-managed project.
- The framework's subagents and slash commands are explicit, named, and audited locally.
