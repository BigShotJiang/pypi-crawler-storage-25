---
description: Show "where am I?" — current phase, last activity, and the next action to take.
---

# /sdlc-resume

Helps the user pick up where they left off.

## What to do

1. Run via Bash: `sdlc resume`
2. The CLI prints:
   - 📍 Project name + overall progress (% + items count)
   - ⏳ Currently pending item (with stage if it's a Phase 3 task)
   - 🕐 Last agent activity with relative timestamp
   - ✋ Open clarifications (if any)
   - 🔒 Pending gates (if any)
   - **Next steps** — the recommended action (resolve clarification first / approve gate / `/sdlc-next` / etc.)
3. Echo the output to the user verbatim. Do not paraphrase — the formatting is meaningful.
4. Highlight any actionable items (clarifications to resolve, gates to approve) and offer to invoke the related slash command:
   - Open clarification → suggest opening the file
   - Pending gate → tell the user how to approve (write `automation/signoffs/<id>.yaml` with `approved: true`)
   - Clean state → suggest `/sdlc-next`
