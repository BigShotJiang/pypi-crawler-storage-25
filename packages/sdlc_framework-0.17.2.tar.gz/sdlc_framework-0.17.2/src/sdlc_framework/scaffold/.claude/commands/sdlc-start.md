---
description: Save the user's project idea, invoke pm-agent to draft the PRD, then automatically chain into autopilot through Phase 1.
argument-hint: "<your idea — e.g. mobile task app for 5-person team>"
---

# /sdlc-start

Begin a new SDLC project from the user's idea, then run on autopilot until a STOP condition.

## What to do

1. **Persist the idea.** Run via Bash: `sdlc start "<the idea>"` — this writes `01-Planning/IDEA.md`.
2. **Draft the PRD.** Use the `pm-agent` subagent (read `.claude/agents/pm-agent.md`). Pass the idea explicitly. The pm-agent reads `01-Planning/templates/01-PRD.md` and `automation/rules.json` (item `prd-exists`) for structure + required evidence. After writing `01-Planning/01-PRD.md`, append the verify marker `<!-- sdlc:verified-by: <git-user-name> <iso-date> -->` at the bottom (or the user can run `sdlc verify prd-exists` later).
3. **Do not delegate to plugin skills** like `superpowers:brainstorming`. The user wants the SDLC PRD flow. The `pm-agent` subagent is authoritative.
4. **Refresh state.** Run: `sdlc scan --print | head -10` and confirm `prd-exists` flipped to ✓ (drafted state).
5. **Chain into autopilot.** Now run the same loop as `/sdlc-auto`:
   - Run `sdlc auto-step`. Parse the JSON.
   - If `action: "invoke"` → use the named subagent, write the deliverable, loop.
   - If `action: "stop"` → print the stop reason + user action, exit.
   - If `action: "done"` → celebrate.
   - Defensive cap: max 20 loop iterations per session.

## STOP triggers

If the idea is too vague to fill required PRD sections, the pm-agent should write a clarification file under `automation/clarifications/` with `STATUS: open` and stop. Tell the user what info is missing — do not invent.

After the PRD, the autopilot will pause for the user to verify (`sdlc verify prd-exists`). That's the first natural stop.

## Why chain into autopilot?

The user explicitly asked the framework to start. Pausing after each artifact for `/sdlc-next` adds friction. Autopilot maximises automation: the loop drives Phase 1 through to its first real STOP (verify needed, gate, clarification, high-risk, or done).
