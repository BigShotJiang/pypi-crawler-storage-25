---
description: Autopilot — auto-run through pending DoD items, dispatching the right subagent for each, until a STOP condition (verify / gate / clarification / high-risk / review-pending / done).
---

# /sdlc-auto

Drive the SDLC framework forward without manual `/sdlc-next` between every item.

## How it works

This command runs a loop. Each iteration:

1. Run via Bash: `sdlc auto-step` — returns JSON describing the next action.
2. Parse the JSON. Three possible actions:

   ### `action: "invoke"`
   - Fields: `agent`, `phase`, `item_id`, `item_label`, `stage` (for tasks), `instruction`, `brief_context`
   - Use the named `<agent>` subagent (read `.claude/agents/<agent>.md`).
   - Build the brief by **prepending** `brief_context` (a role-tailored slice of `automation/.context-bundle.md` ≤ ~600 tokens) to `instruction`. Tell the subagent: "the snippet below is pre-loaded context — read it first, do NOT re-read upstream artifacts unless you need detail beyond it".
   - Wait for the subagent to finish writing its deliverable.
   - **Loop back to step 1.**

   ### `action: "stop"`
   - Fields: `stop_reason`, `phase`, `item_id`, `user_action`
   - Print a clear message to the user with the stop reason and what they must do:
     ```
     ⏸️  Autopilot paused — <stop_reason>
     <user_action>
     ```
   - Common stop reasons:
     - `verify_needed` — Phase 1/2/4 artifact drafted, awaiting `sdlc verify <id>`
     - `gate` — Phase signoff yaml needed
     - `clarification` — open clarification file must be resolved
     - `high_risk` — auth/crypto/payment/secrets/migrations need explicit user OK
     - `review_pending` — Phase 3 task PR open, waiting for human merge
     - `tasks_empty` — Phase 3 reached but no tasks bootstrapped and inline `sdlc tasks bootstrap` could not produce any (user must draft `01-Planning/02-User-Stories.md` then run bootstrap manually)
   - **Exit the loop.** The user re-runs `/sdlc-auto` after taking the action.

   ### `action: "done"`
   - All five phases complete.
   - Celebrate: 🎉 All phases complete.
   - **Exit the loop.**

## Safety rules

- **Run `sdlc auto-step` between every subagent invocation.** Don't trust your own state — re-scan after each step.
- **Never skip a `stop` action.** If the JSON says stop, exit the loop immediately. Don't try to work around the stop reason.
- **Don't loop more than 20 iterations** in a single session even if no stop fires (defensive limit).
- **Don't dispatch a subagent without first running `auto-step`.** The subagent name in the JSON is computed from current state.

## Single-step alternative

If the user wants tighter control, they can run `/sdlc-next` instead — that's the single-step version that picks the next item but doesn't loop.

## Example trace

```
> /sdlc-auto

[loop 1]
  Run: sdlc auto-step
  Got: { action: "invoke", agent: "pm-agent", item_id: "user-stories-with-ac", ... }
  Use the pm-agent subagent → drafts 01-Planning/02-User-Stories.md, appends verify marker

[loop 2]
  Run: sdlc auto-step
  Got: { action: "stop", stop_reason: "verify_needed", item_id: "user-stories-with-ac", ... }

  Output to user:
    ⏸️  Autopilot paused — verify_needed
    Artifact `user-stories-with-ac` is drafted but awaits your verify.
    Review the file then run `sdlc verify user-stories-with-ac`. Then re-run `/sdlc-auto`.
```
