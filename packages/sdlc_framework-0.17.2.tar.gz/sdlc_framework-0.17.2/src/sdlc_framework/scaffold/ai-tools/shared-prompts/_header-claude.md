<!-- Tool: Claude Code / Claude Desktop / Claude Agent SDK. Output path: CLAUDE.md -->
# CLAUDE.md — Project Context for Claude

> File này được Claude Code, Claude Desktop, và Claude Agent SDK auto-load làm context cho mọi conversation trong repo này. Giữ ngắn gọn, link đi nơi khác cho chi tiết.

## Project name
{{PROJECT_NAME}}

## What this project is
1–2 câu mô tả product/system. Ví dụ:
> Backend service powering [X] for [users]. REST API + async workers, deployed on Kubernetes.

## Tech stack
- Languages: TypeScript (Node 20), Python 3.12
- Frameworks: NestJS / FastAPI
- Storage: PostgreSQL 15, Redis 7, S3
- Infra: AWS, Terraform, Kubernetes
- CI: GitHub Actions

## Repository map
```
01-Planning/         # PRD, user stories, requirements
02-Design/           # Architecture, API spec, DB schema, ADRs
03-Development/      # Coding standards, git workflow, security checklist
04-Testing-Deploy/   # Test plan, CI/CD, runbooks, SLOs
ai-tools/            # AI tool configs (this folder)
dashboard/           # SDLC progress dashboard
src/                 # Application code
tests/               # Tests
```

## Standards Claude MUST follow
- Coding: `03-Development/standards/coding-standards.md`
- Errors: `03-Development/standards/error-handling.md`
- Git: `03-Development/standards/git-workflow.md`
- Security: `03-Development/standards/security-checklist.md`
- API conventions: `02-Design/templates/02-API-Spec.md`
- DB conventions: `02-Design/templates/03-DB-Schema.md`

## How Claude should work in this repo

### When in autonomous / agent mode
**MUST follow `automation/AGENT-LOOP.md` strictly.** That file defines:
- Read `automation/state.json` first to know current SDLC progress
- Pick next pending DoD item from `automation/rules.json`
- STOP and create `automation/clarifications/<NNN>-<slug>.md` if ambiguity / conflict
- STOP if item has a gate — user creates `automation/signoffs/<gate>.yaml` to approve
- After every change run `python3 automation/sdlc_engine.py` to refresh state

### Before coding
1. Read the relevant SDLC docs (PRD, design, standards) — don't guess.
2. Restate the task in 1 paragraph; flag ambiguities as `<NEEDS-CLARIFICATION>`.
3. Propose a small step plan; wait for approval before big changes.

### While coding
- Make **minimal, reviewable diffs** — one logical change per turn.
- Tests first when feasible (TDD-lite).
- Match existing patterns in the repo (read neighbors before writing new).
- No new dependencies without justification + license check.
- No secrets, no PII in logs, no `console.log` in committed code.

### Communication
- Be concise; lead with the answer.
- When uncertain, say so.
- Quote file paths with line numbers (`src/foo.ts:42`).
- Don't apologize repeatedly — fix and move on.

### After coding
- Show diff summary.
- Run lint + tests (or tell user how).
- Update relevant docs (README, OpenAPI, ADR).

## Forbidden
- Direct edits to `main` branch — always feature branch + PR
- Mass refactor without ADR
- Skipping security checklist for auth/crypto/payments code
- Deleting tests to make CI green
- Hallucinating APIs / imports / types

## Slash-command shortcuts (suggested)
- `/spec` → use template `01-Planning/templates/01-PRD.md`
- `/api` → use template `02-Design/templates/02-API-Spec.md`
- `/adr` → use template `02-Design/templates/05-ADR.md`
- `/review` → run checklist `03-Development/templates/Code-Review-Checklist.md`
- `/runbook` → use template `04-Testing-Deploy/runbooks/incident-template.md`

## Memory hints
- User is a Project Manager with dev background; prefers concise replies.
- This repo is the SDLC framework itself — when adding new templates, follow the existing 4-phase structure.
