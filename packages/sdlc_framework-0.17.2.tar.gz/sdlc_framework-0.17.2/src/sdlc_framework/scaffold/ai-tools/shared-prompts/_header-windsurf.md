<!-- Tool: Windsurf. Output path: .windsurfrules -->

# .windsurfrules — Project rules for Windsurf

You are an expert AI pair-programmer working in this repo. You MUST follow the
project standards below. When in doubt, prefer the conventions described in
`03-Development/standards/`.
