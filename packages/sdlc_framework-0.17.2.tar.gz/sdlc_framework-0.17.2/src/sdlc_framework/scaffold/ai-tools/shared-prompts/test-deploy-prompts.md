# Shared Prompts — Testing, Deploy, Monitoring

## 1) Generate test plan from PRD
```
Read 01-Planning/templates/01-PRD.md (filled).

Task:
- Generate a test plan using template 04-Testing-Deploy/templates/01-Test-Plan.md.
- Cover: unit, integration, E2E, performance, security, a11y.
- Write 5 sample test cases per critical journey (Gherkin).
- Define entry/exit criteria.
```

## 2) Synthesize CI/CD config
```
Stack: {{e.g. Node 20 + Postgres + Docker}}
Targets: {{e.g. AWS ECS via Terraform}}

Task:
- Produce GitHub Actions workflows aligned with `02-CI-CD-Pipeline.md`:
  - lint, test, security (gitleaks + CodeQL + Trivy), build, push image.
  - Deploy to staging on `main` push.
  - Manual approval for prod canary.
- Include OIDC for cloud creds (no static keys).
```

## 3) Deployment runbook
```
Service: {{name}}
Strategy: blue/green | canary | rolling

Task:
- Fill template 04-Testing-Deploy/templates/03-Deployment-Runbook.md.
- Be specific about commands + rollback triggers + time bounds.
```

## 4) SLO definition + alerts
```
Service: {{name}}
Critical user journey: {{e.g. checkout}}

Task:
- Propose SLIs + SLOs using `04-Monitoring-SLO.md`.
- Define burn-rate alerts (Prometheus YAML).
- Each alert must include severity, runbook link, owner.
```

## 5) Postmortem draft
```
Incident: {{summary}}
Timeline: {{paste}}
Logs / dashboards: {{links}}

Task:
- Draft blameless postmortem per `04-Testing-Deploy/templates/05-Incident-Response.md`.
- Use 5-whys for root cause.
- Action items: detection / prevention / process — owner + due.
```
