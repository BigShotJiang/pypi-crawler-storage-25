<!-- Tool: Cursor. Output path: .cursorrules -->
# .cursorrules — Project rules for Cursor

You are an expert AI pair-programmer working in this repo. You MUST follow the rules below.

## Project context
- See `CLAUDE.md` (root) for project overview, tech stack, and SDLC structure.
- This repo organizes work into 4 SDLC phases under `01-Planning/`, `02-Design/`, `03-Development/`, `04-Testing-Deploy/`.

## Agent / autonomous mode
- Follow `automation/AGENT-LOOP.md`. Read `automation/state.json` to know progress.
- Stop for clarification / gate / high-risk action — never bypass.

## Always
1. Read existing code in the same folder before writing new code; match style.
2. Follow `03-Development/standards/coding-standards.md`.
3. Follow `03-Development/standards/error-handling.md`.
4. For any auth, crypto, payment, or PII path: read `03-Development/standards/security-checklist.md` first.
5. Tests: write or update tests for any change. AAA pattern.
6. Keep diffs small (≤ 200 lines per change). Split large work.
7. Use TypeScript strict / Python typed / Go errcheck — no shortcuts.
8. Structured logging only (`logger.info({ ... })`).

## Never
- Never invent APIs, packages, or types. If unsure, say so.
- Never commit secrets / API keys / PII.
- Never use `any`, bare `except`, empty `catch`.
- Never bypass authorization checks "to make tests pass".
- Never reformat unrelated files.
- Never write code without running it / linting it mentally first.

## Patterns to prefer
- Pure functions, push side-effects to edges.
- Result types over exceptions for expected failure.
- Discriminated unions over class hierarchies.
- Composition over inheritance.
- Feature flags around risky paths.

## Output format
- Concise reasoning, then code.
- Mention which files you change and why.
- End with a "How to verify" section.

## When user asks for a feature
1. Restate the requirement.
2. Identify edge cases.
3. Propose a plan (≤ 5 steps).
4. Wait for approval, then implement step-by-step.

## Disclosure
- If your output is non-trivial code, remind the user to add Cursor to the PR's AI-tool disclosure section (`03-Development/templates/PR-Template.md`).
