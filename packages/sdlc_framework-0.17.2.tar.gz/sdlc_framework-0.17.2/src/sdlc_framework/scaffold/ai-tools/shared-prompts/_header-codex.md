<!-- Tool: OpenAI Codex / agent. Output path: AGENTS.md -->
# AGENTS.md — Codex / OpenAI Agent guidelines

> File này được OpenAI Codex CLI và Agent SDK auto-detect ở project root.
> Cung cấp context, ràng buộc, và workflow cho agentic coding.

## Project
{{PROJECT_NAME}} — chi tiết trong `CLAUDE.md` (root).

## Agent's mission
Help complete tasks in this codebase while strictly adhering to SDLC standards under `01-Planning/`, `02-Design/`, `03-Development/`, `04-Testing-Deploy/`.

## Autonomous loop
**MUST** follow `automation/AGENT-LOOP.md`:
- Refresh state with `python3 automation/sdlc_engine.py` before each turn.
- Read `automation/state.json` to find next pending item.
- STOP triggers (do not bypass): ambiguity, conflict, gate, high-risk path (auth/crypto/payment/migrations/secrets).
- Surface ambiguities by creating `automation/clarifications/<NNN>-<slug>.md`.
- Never write to `automation/signoffs/` — that's user-only.

## Workflow rules
1. **Plan before act.** Output a plan (≤ 5 steps) and wait for approval if not in autonomous mode.
2. **Small steps.** One logical change per turn. Show diff after each.
3. **Verify.** Run tests / lint after edits. If failing, fix before declaring done.
4. **Disclose.** PRs must list which agent generated which parts.

## Hard rules
- No secret commits. Run `gitleaks detect --no-git` before staging.
- No new top-level deps without justification.
- No edits to `main` directly.
- Auth / crypto / payment changes: STOP and surface to human reviewer.

## Toolbox preferences
- Prefer `rg` over `grep`, `fd` over `find`.
- Prefer `gh` CLI for GitHub ops.
- Prefer `make` targets if `Makefile` exists.

## File reading priority (when context-limited)
1. `CLAUDE.md`
2. `03-Development/standards/coding-standards.md`
3. Files in the directory you're editing
4. Tests for the file you're editing
5. Top-level `README.md`

## Output style
- Lead with the answer.
- Cite paths as `src/foo.ts:42`.
- Diffs in unified format.
- Ask before running destructive commands.

## SDLC slash commands (Tier 4 — terminal only)

Codex has no custom slash command surface. Run SDLC commands directly in a terminal:

- `sdlc auto-mad-step` — autopilot one iteration
- `sdlc tasks list` — Phase 3 tasks
- `sdlc next` / `sdlc resume` / `sdlc scan --print`
- `sdlc verify <item>` — mark artifact verified

For tools with first-class slash commands (Cursor, GitHub Copilot, Cline, Windsurf, Continue), the framework ships per-tool surfaces under `.cursor/`, `.github/prompts/`, etc.

## Done criteria
A task is "done" only when:
- [ ] Code compiles / runs
- [ ] Tests pass
- [ ] Lint clean
- [ ] Docs updated if behavior changed
- [ ] You've left a one-line summary
