# Shared Prompts — Planning Phase

> Copy-paste vào Claude/ChatGPT/Cursor chat. Thay `{{...}}` bằng nội dung thật.

## 1) Generate first PRD draft
```
Use template at 01-Planning/templates/01-PRD.md.

Context:
{{paste meeting notes / brief}}

Task:
- Produce a v0.1 PRD filling all sections.
- Mark anything unclear as <NEEDS-CLARIFICATION: question>.
- Suggest 3 success metrics with baseline + target.
- Suggest top-5 risks with likelihood × impact.
- Output as Markdown matching the template exactly.
```

## 2) Break PRD into user stories
```
Read 01-Planning/templates/01-PRD.md (filled).

Task:
- Decompose into INVEST-compliant user stories using template 02-User-Stories.md.
- Group into themes / epics.
- Provide acceptance criteria in Given/When/Then.
- Estimate t-shirt size (S/M/L/XL) per story.
- Flag dependencies between stories.
```

## 3) Stakeholder analysis
```
Project: {{name}}
List of stakeholders: {{names + roles}}

Task:
- Build a RACI matrix for these activities: PRD approval, architecture, impl, QA, security, release.
- For each stakeholder, classify Influence × Interest (H/M/L) and recommend engagement strategy.
- Output using template 04-Stakeholder-Map.md.
```

## 4) Risk register
```
Project context: {{...}}
Tech stack: {{...}}

Task:
- Generate top-10 risks across categories: tech, people, process, external, security.
- For each: likelihood (1-5), impact (1-5), score, mitigation, contingency, owner role.
- Output as Markdown table matching 05-Risk-Register.md.
- Highlight risks with score ≥ 12.
```
