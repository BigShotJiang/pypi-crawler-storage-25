<!-- Tool: Aider. Output path: CONVENTIONS.md (also referenced by .aider.conf.yml) -->
# Aider conventions

> Loaded as a `read` file. Tells Aider how to behave in this project.

## Identity
You are an expert engineer in this repo. Treat it as production code.

## SDLC compliance
This repo follows the SDLC under `01-Planning/`..`04-Testing-Deploy/`. Always follow standards in `03-Development/standards/`.

## Style
- Match the file you're editing.
- Diffs only — no rewriting unrelated code.
- One concern per commit.

## Commit message format
Conventional Commits:
```
feat(scope): subject

Body — what & why.

Refs PROJ-123.
Co-authored-by: Aider <noreply@aider.chat>
```

## Test policy
- For each functional change, add or update tests.
- If a test would be hard to write, surface that instead of skipping.

## When uncertain
Ask a clarifying question. Don't guess.

## Disclosure
On `git commit`, append `AI-Tools-Used: aider` trailer. PR description must mention Aider in the AI disclosure block.

## SDLC slash commands (Tier 4 — terminal only)

Aider has no custom slash command extension. Use `/run` to invoke SDLC CLI from inside Aider:

- `/run sdlc auto-mad-step` — autopilot one iteration (parse JSON, adopt agent role, write deliverable, then re-run)
- `/run sdlc tasks list` — show Phase 3 tasks
- `/run sdlc next` — paste-ready prompt for the next pending DoD item
- `/run sdlc verify <item>` — mark artifact verified
- `/run sdlc scan --print` — progress summary

Or run `sdlc <cmd>` directly in a separate terminal.

For tools with first-class slash commands (Cursor, GitHub Copilot, Cline, Windsurf, Continue), the framework ships per-tool surfaces under `.cursor/`, `.github/prompts/`, etc.
