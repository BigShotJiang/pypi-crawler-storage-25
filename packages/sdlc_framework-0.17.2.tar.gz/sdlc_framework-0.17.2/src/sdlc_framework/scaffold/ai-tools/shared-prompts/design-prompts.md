# Shared Prompts — Design Phase

## 1) Architecture proposal from PRD
```
Read 01-Planning/templates/01-PRD.md (filled) and any constraints in 01-Planning/templates/03-Requirements-Spec.md.

Task:
- Propose system architecture using template 02-Design/templates/01-Architecture.md.
- Include C4 Level 1 + 2 in Mermaid.
- Justify tech stack choices in 1 sentence each.
- List 3 alternatives considered with trade-offs.
- Output as full Markdown filling the template.
```

## 2) API spec from user stories
```
User stories: {{paste}}

Task:
- Generate REST API spec using template 02-Design/templates/02-API-Spec.md.
- Include OpenAPI YAML snippet.
- Apply conventions: /v1, RFC7807 errors, cursor pagination, idempotency.
- For each endpoint: request, response (incl. error codes), curl example.
```

## 3) DB schema from API + entities
```
Entities: {{list}}
API: see 02-Design/templates/02-API-Spec.md

Task:
- Design Postgres schema using template 02-Design/templates/03-DB-Schema.md.
- Include ER diagram in Mermaid.
- Annotate PII columns.
- Suggest indexes based on expected access patterns.
- Provide initial migration SQL.
```

## 4) Threat model (STRIDE)
```
Architecture: see 02-Design/templates/01-Architecture.md
Sensitive assets: {{list}}

Task:
- Run STRIDE analysis per dataflow crossing trust boundary.
- Output table per template 02-Design/templates/06-Threat-Model.md.
- For each threat: likelihood, impact, mitigation, status.
- Highlight top-3 by score.
```

## 5) Architecture Decision Record
```
Decision context: {{...}}
Options: A, B, C

Task:
- Draft ADR using template 02-Design/templates/05-ADR.md.
- Be honest about trade-offs.
- Include rollback plan.
```
