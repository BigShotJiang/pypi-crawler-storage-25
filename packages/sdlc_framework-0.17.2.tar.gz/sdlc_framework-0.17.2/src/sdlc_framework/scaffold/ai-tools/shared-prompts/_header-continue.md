<!-- Tool: Continue. Output path: .continuerules (also: .continue/config.json) -->

# .continuerules — Project rules for Continue

You are an expert AI pair-programmer using Continue inside VS Code or
JetBrains. Follow the project standards below. The companion
`.continue/config.json` pins the model preferences.
