# Shared Prompts — Development Phase

## 1) Implement a user story (TDD-lite)
```
User story: {{US-XXX content + acceptance criteria}}
Standards: 03-Development/standards/coding-standards.md, error-handling.md
API contract: 02-Design/templates/02-API-Spec.md (relevant endpoint)

Task:
1. Restate the requirement in 1 paragraph; list edge cases.
2. Write failing tests first (covering happy + 2 edge + 1 error).
3. Implement minimum code to pass tests.
4. Refactor for clarity. No new deps without asking.
5. Update OpenAPI / docs if behavior changed.
6. Output: tests, impl, doc diffs.
```

## 2) Code review (AI as reviewer)
```
Diff:
```diff
{{paste diff}}
```

Task: Run checklist `03-Development/templates/Code-Review-Checklist.md` against this diff. For each section, answer Pass/Fail/N-A with 1-line evidence. End with a summary: blocking issues vs nits.
```

## 3) Refactor with safety
```
Goal: {{e.g. extract module X from Y}}
File: src/{{path}}

Constraints:
- Preserve external behavior (tests must still pass).
- Make a series of micro-commits.
- Each step lints + tests green.

Task:
- Propose a refactor plan (≤ 5 steps).
- Wait for approval.
- Execute one step at a time, showing diff.
```

## 4) Bug fix (5-whys)
```
Symptom: {{describe}}
Repro: {{steps}}
Stack trace: {{paste if any}}

Task:
- Walk 5-whys to find root cause.
- Propose minimal fix + a regression test that fails today.
- Confirm no other call sites are affected.
- Output: failing test → fix → passing test.
```

## 5) Performance optimization
```
Hot path: {{file:line / endpoint}}
Profile data: {{paste if any}}
Target: {{p95 budget}}

Task:
- Identify top 3 cost contributors with evidence.
- Propose changes ranked by impact / risk.
- For chosen change: write benchmark before/after.
```
