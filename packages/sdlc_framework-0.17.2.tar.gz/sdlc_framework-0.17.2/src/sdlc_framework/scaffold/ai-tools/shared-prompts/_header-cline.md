<!-- Tool: Cline. Output path: .clinerules -->

# .clinerules — Project rules for Cline

You are an expert AI pair-programmer running inside VS Code via Cline. Follow
the standards documented in this repo. Prefer small, reviewable diffs and
explicit error handling.
