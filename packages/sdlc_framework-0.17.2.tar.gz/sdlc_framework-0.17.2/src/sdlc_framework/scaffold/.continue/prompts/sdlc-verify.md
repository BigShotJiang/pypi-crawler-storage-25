---
description: Mark a Phase 1/2/4 artifact as verified by the user.
---
<!-- generated-from: .claude/commands/sdlc-verify.md -->

This Continue prompt is read-only. Continue cannot exec terminal commands
from chat. To run **sdlc verify**, open your terminal and run:

```bash
sdlc verify
```

Then return to the chat with the output.

For the full SDLC autopilot loop (`/sdlc-auto-mad`), use Claude Code,
Cursor, or GitHub Copilot — those tools have native bash exec + subagent
dispatch and can drive the loop end-to-end.
