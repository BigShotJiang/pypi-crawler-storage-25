---
description: Manage Phase 3 task definitions (bootstrap from user stories, list, create, remove).
---
<!-- generated-from: .claude/commands/sdlc-tasks.md -->

This Continue prompt is read-only. Continue cannot exec terminal commands
from chat. To run **sdlc tasks**, open your terminal and run:

```bash
sdlc tasks
```

Then return to the chat with the output.

For the full SDLC autopilot loop (`/sdlc-auto-mad`), use Claude Code,
Cursor, or GitHub Copilot — those tools have native bash exec + subagent
dispatch and can drive the loop end-to-end.
