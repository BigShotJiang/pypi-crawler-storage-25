---
description: "Show \"where am I?\" — current phase, last activity, and the next action to take."
---
<!-- generated-from: .claude/commands/sdlc-resume.md -->

This Continue prompt is read-only. Continue cannot exec terminal commands
from chat. To run **sdlc resume**, open your terminal and run:

```bash
sdlc resume
```

Then return to the chat with the output.

For the full SDLC autopilot loop (`/sdlc-auto-mad`), use Claude Code,
Cursor, or GitHub Copilot — those tools have native bash exec + subagent
dispatch and can drive the loop end-to-end.
