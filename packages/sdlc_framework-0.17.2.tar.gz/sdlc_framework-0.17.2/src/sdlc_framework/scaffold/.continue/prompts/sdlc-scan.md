---
description: Run the SDLC engine and report DoD progress.
---
<!-- generated-from: .claude/commands/sdlc-scan.md -->

This Continue prompt is read-only. Continue cannot exec terminal commands
from chat. To run **sdlc scan**, open your terminal and run:

```bash
sdlc scan
```

Then return to the chat with the output.

For the full SDLC autopilot loop (`/sdlc-auto-mad`), use Claude Code,
Cursor, or GitHub Copilot — those tools have native bash exec + subagent
dispatch and can drive the loop end-to-end.
