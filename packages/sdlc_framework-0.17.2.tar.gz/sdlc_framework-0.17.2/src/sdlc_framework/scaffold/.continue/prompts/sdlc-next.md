---
description: Pick up the next pending DoD item and invoke the right subagent automatically.
---
<!-- generated-from: .claude/commands/sdlc-next.md -->

This Continue prompt is read-only. Continue cannot exec terminal commands
from chat. To run **sdlc next**, open your terminal and run:

```bash
sdlc next
```

Then return to the chat with the output.

For the full SDLC autopilot loop (`/sdlc-auto-mad`), use Claude Code,
Cursor, or GitHub Copilot — those tools have native bash exec + subagent
dispatch and can drive the loop end-to-end.
