---
description: Pick up the next pending DoD item and invoke the right subagent automatically.
---
<!-- generated-from: .claude/commands/sdlc-next.md -->

> **ROLE SWITCH (Tier 2):** Before each stage, re-read the role spec at
> `agents/<role>.md` and adopt that role fresh. Do not retain context
> from the previous stage. Cline does not provide process-level subagent
> isolation - discipline is by-prompt.


# /sdlc-next

Find the next pending SDLC item and run the matching specialist subagent.

## What to do

1. **Discover the next item.** Run via Bash: `sdlc next --json` and parse the JSON output. Fields:
   - `phase` — 1..4
   - `item_id` — the rule id (e.g. `user-stories-with-ac`)
   - `item_label` — human label
   - `agent` — `pm-agent` / `architect-agent` / `developer-agent` / `sre-agent`
   - `role_file` — path to the role spec (e.g. `agents/phase-1-pm.md`)
   - `brief_context` — a role-tailored slice of `automation/.context-bundle.md` (≤ ~600 tokens). Pre-loaded orientation so the subagent does not need to re-read upstream artifacts.
2. **If the JSON action is "done":** congratulate the user and stop. The framework reports all phases complete.
3. **Otherwise, invoke the named subagent.** Adopt the **`<agent>`** role (read `agents/<role>.md` for the spec) and ask it to satisfy `<item_id>` per `automation/rules.json`. **Prepend `brief_context` to the prompt** so the subagent has pre-loaded facts; tell it to read those first and only fall back to upstream files when the snippet is insufficient. The subagent reads its own role spec and the rule's required evidence as needed.
4. **Do not delegate to plugin skills.** The named subagent is authoritative.
5. **Verify.** After the subagent finishes, Bash: `sdlc scan --print | head -10` and report whether the item flipped to ✓.
6. **Continue.** Tell the user `/sdlc-next` again to pick up the next item, or `/sdlc-dashboard` to see a visual overview.

## STOP triggers

If the item maps to a gate (`gate` key set in rule), do NOT invoke an agent — instead tell the user the gate id and the approvers needed, and that they must write `automation/signoffs/<id>.yaml` with `approved: true`.

If the item touches a high-risk path (auth/crypto/payment/secrets/migrations), surface that to the user and ask explicit confirmation before the subagent proceeds.
