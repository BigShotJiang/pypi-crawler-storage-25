---
description: Run the SDLC engine and report DoD progress.
---
<!-- generated-from: .claude/commands/sdlc-scan.md -->

> **ROLE SWITCH (Tier 2):** Before each stage, re-read the role spec at
> `agents/<role>.md` and adopt that role fresh. Do not retain context
> from the previous stage. Cline does not provide process-level subagent
> isolation - discipline is by-prompt.


# /sdlc-scan

Refresh the engine state and summarize progress.

## What to do

1. Run via Bash: `sdlc scan --print`
2. Parse the output (overall %, per-phase %, per-item ✓/✗ with failure messages).
3. Summarize for the user:
   - Overall %
   - Phases completed vs total
   - Top 3 pending items (with the failure reason inline so the user knows what's missing)
4. If clarifications are open, list them and remind the user they need attention.
5. If gates are pending, list each one with the approvers needed.
6. Suggest one of:
   - `/sdlc-next` if there's pending work the framework can dispatch
   - "Resolve clarification at automation/clarifications/<file>.md" if any are open
   - "Approve gate by writing automation/signoffs/<id>.yaml" if any are pending

Keep the summary short — under 10 bullet points.
