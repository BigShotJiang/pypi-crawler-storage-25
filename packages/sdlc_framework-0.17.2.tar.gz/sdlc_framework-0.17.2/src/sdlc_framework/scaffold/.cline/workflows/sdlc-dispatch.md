---
description: Show the engine's full dispatch decision (primary agent, parallel agents, blocked_by).
---
<!-- generated-from: .claude/commands/sdlc-dispatch.md -->

> **ROLE SWITCH (Tier 2):** Before each stage, re-read the role spec at
> `agents/<role>.md` and adopt that role fresh. Do not retain context
> from the previous stage. Cline does not provide process-level subagent
> isolation - discipline is by-prompt.


# /sdlc-dispatch

Inspect what the smart dispatcher recommends right now.

## What to do

1. Run via Bash: `sdlc dispatch --json`
2. Parse the JSON. Important fields:
   - `action` — `invoke` / `stop_for_gate` / `stop_for_user` / `ask_user` / `done`
   - `agent` — the primary agent
   - `parallel_agents` — cross-cutting agents to invoke in parallel (may be empty)
   - `blocked_by` — `null` or `{phase, gate, clarification, high_risk_item}`
3. Translate to plain language:
   - If `action == "invoke"`: "Run `/sdlc-next` — the framework wants `<agent>` to work on `<item_id>`."
   - If `parallel_agents` non-empty: "After the primary agent finishes, also invoke these in parallel: `<list>`."
   - If `action == "stop_for_gate"`: "Phase <N> is blocked by gate `<id>`. Approvers needed: <list>. Write `automation/signoffs/<id>.yaml` with `approved: true`."
   - If `blocked_by.clarification`: "Resolve the open clarification(s) first."
   - If `action == "done"`: "All phases complete. 🎉"

## When to use this vs `/sdlc-next`

- `/sdlc-next` is the **action** command — picks up the next item AND runs the subagent.
- `/sdlc-dispatch` is the **inspection** command — shows what would happen, without doing it.
