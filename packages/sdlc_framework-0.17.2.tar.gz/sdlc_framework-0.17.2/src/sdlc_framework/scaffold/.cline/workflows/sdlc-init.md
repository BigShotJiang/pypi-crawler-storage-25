---
description: Scaffold an SDLC project (auto-detects stack from package.json / pyproject.toml / go.mod).
---
<!-- generated-from: .claude/commands/sdlc-init.md -->

> **ROLE SWITCH (Tier 2):** Before each stage, re-read the role spec at
> `agents/<role>.md` and adopt that role fresh. Do not retain context
> from the previous stage. Cline does not provide process-level subagent
> isolation - discipline is by-prompt.


# /sdlc-init

Run the SDLC framework scaffold against the current working directory.

## What to do

1. Run via Bash: `sdlc init`
2. If the user passed an argument like `--stack=node` or `--force`, append it.
3. Read the command output verbatim and report:
   - Auto-detected stack (or "no stack detected").
   - Number of files copied vs skipped.
   - Whether `.github/workflows/ci.yml` was wired.
4. If 0 files were copied AND `--force` was not used, suggest:
   - "Looks already initialized. Run `/sdlc-scan` to check progress, or `/sdlc-init --force` to overwrite."
5. Otherwise, suggest the next step:
   - "Try `/sdlc-start \"<your idea>\"` to begin Phase 1."

## Notes

- The `sdlc` CLI is the engine; this slash command is a thin wrapper.
- The scaffold is non-destructive: existing files are skipped unless `--force`.
