---
description: Mark downstream DoD items dirty after a major change (requirements, UI/UX, tech stack, scale).
---
<!-- generated-from: .claude/commands/sdlc-replan.md -->

> **ROLE SWITCH (Tier 2):** Before each stage, re-read the role spec at
> `agents/<role>.md` and adopt that role fresh. Do not retain context
> from the previous stage. Cline does not provide process-level subagent
> isolation - discipline is by-prompt.


# /sdlc-replan

Capture a major mid-project change and force re-doing affected items.

## What to do

1. Run via Bash: `sdlc replan` with whatever flags the user passed (or interactively).
2. The CLI is interactive when no `--scope` is given — it asks the user to pick one of:
   - `requirements` — functional requirements / user stories changed
   - `ui-ux` — UI/UX scope or screens changed
   - `tech-stack` — language / framework / runtime changed
   - `scale-nfr` — RPS / latency / SLO targets changed
   - `custom` — user lists item ids manually
   - `clear` — drop all dirty markers (after the work is redone)
3. After the user picks a scope, the CLI:
   - Marks downstream items dirty in `automation/.replan.json`
   - Writes an audit clarification under `automation/clarifications/replan-<ts>.md`
   - Forces the engine to show those items as ✗ until `sdlc replan --clear`
4. Suggest next steps:
   - "Run `/sdlc-scan` to see the new state."
   - "When you've re-done the work, run `/sdlc-replan --clear` to drop the markers."

## Non-interactive

If the user provides `--scope` and `--reason`, pass them through directly and skip the prompt.
