---
name: sdlc-tasks
description: Manage Phase 3 task definitions (bootstrap from user stories, list, create, remove).
---
<!-- generated-from: .claude/commands/sdlc-tasks.md -->


# /sdlc-tasks

Manage Phase 3 task YAML files under `automation/tasks/`.

## Sub-commands

### `bootstrap`

Auto-generate one task per user story:

```
sdlc tasks bootstrap
```

Parses `01-Planning/02-User-Stories.md` for `## Story:` headings (or alternates `## US:`, `## User Story:`). One YAML file per story under `automation/tasks/<slug>.yaml`. Each task starts at stage `write-tests` once activated (or `pending` while queued behind the Phase 3 serial lock).

### `list`

Print all tasks with current stage and priority:

```
sdlc tasks list
```

### `new <id>`

Manually create a task:

```
sdlc tasks new feature-billing --label="Billing — Stripe integration" --priority=high
```

Flags: `--label`, `--code-glob`, `--test-glob`, `--pr-branch`, `--priority` (high|medium|low).

### `rm <id>`

Delete a task:

```
sdlc tasks rm feature-billing
```

## What to do

1. Run via Bash: `sdlc tasks <subcommand> [args]`.
2. Read the output and report to the user.
3. After `bootstrap` or `new`, suggest `/sdlc-next` to begin work on the highest-priority pending task.
