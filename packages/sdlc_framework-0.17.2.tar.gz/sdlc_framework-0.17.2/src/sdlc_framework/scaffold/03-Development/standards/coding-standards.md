# Coding Standards

> Áp dụng cho tất cả code (human + AI). Vi phạm = block PR.

## Universal Principles

1. **Readability beats cleverness** — code is read 10× more than written.
2. **Boring is good** — prefer well-known patterns over novel ones.
3. **Small functions** — ≤ 30 lines, single responsibility, explicit return type.
4. **Pure where possible** — push side-effects to the edges (functional core, imperative shell).
5. **Fail fast, log clear** — early returns; structured errors with context.
6. **YAGNI** — no speculative abstraction.
7. **Comments explain *why*, not *what*** — the code shows what.

## Naming
- Variables: `snake_case` (Python) / `camelCase` (JS/TS, Go vars)
- Constants: `UPPER_SNAKE`
- Types/Classes: `PascalCase`
- Files: kebab-case for components, snake_case for utils
- Booleans: `is_*`, `has_*`, `can_*`, `should_*`
- Functions: verb-first (`fetch_user`, not `user_data`)

## Function rules
- Max 4 params. More → object/struct.
- No flag arguments (`do(true)` is unclear) → split into 2 functions.
- One level of abstraction per function.
- Pure functions where possible — return values, don't mutate.

## Error handling

### TypeScript / JavaScript
```ts
// ✅ Good — typed errors, explicit handling
type Result<T, E> = { ok: true; value: T } | { ok: false; error: E };

async function fetchUser(id: string): Promise<Result<User, NotFoundError | NetworkError>> {
  // ...
}

// ❌ Bad — swallowing errors
try { await doThing(); } catch {}

// ❌ Bad — generic catch with no context
catch (e) { logger.error(e); }
```

### Python
```python
# ✅ Good — specific exceptions, context preserved
class UserNotFound(Exception): ...

def get_user(uid: str) -> User:
    row = db.fetchone("SELECT * FROM users WHERE id = %s", (uid,))
    if not row:
        raise UserNotFound(f"user_id={uid}")
    return User.from_row(row)

# ❌ Bad — bare except
try: ...
except: ...
```

### Go
```go
// ✅ Good — wrap with context
if err != nil {
    return fmt.Errorf("fetch user %s: %w", id, err)
}
```

## Logging
- **Structured JSON only** — no string concat
- Required fields: `level`, `msg`, `trace_id`, `span_id`, `service`, `env`
- **Never log**: passwords, tokens, full PII (hash or last-4 only)
- Log levels:
  - `debug`: dev only
  - `info`: state transitions
  - `warn`: handled anomaly
  - `error`: ops should investigate
  - `fatal`: process will exit

## Imports / Modules
- No circular deps (enforce via lint rule)
- Layer order: stdlib → third-party → internal → local — sorted within each
- No barrel files re-exporting unrelated stuff

## Testing
- AAA pattern: Arrange / Act / Assert
- One behavior per test
- Use real fakes over mocks where feasible
- Property-based tests for parsers/serializers
- Coverage ≥ 80% on business logic; 100% on auth/billing/crypto

## Performance
- Profile before optimizing
- Allocate outside loops
- Stream large responses (don't buffer)
- N+1 queries → use joins or DataLoader

## Concurrency
- Pass context (timeout/cancel) all the way down
- Goroutines / async tasks must have an exit path
- Shared state → mutex or actor; no naked maps
- No `Thread.sleep` in tests — use clocks/fakes

## Security (see also `security-checklist.md`)
- Input validation at boundary (zod / pydantic / validator)
- Output encoding for context (HTML/SQL/Shell)
- Use parameterized queries always
- Rate limit + auth on every endpoint
- Secrets via env / vault, never in code

## Language-specific quick rules

### TypeScript
- `strict: true` in `tsconfig`
- No `any` (use `unknown` then narrow)
- Discriminated unions over class hierarchies
- `readonly` by default

### Python
- `mypy --strict`
- `ruff` for lint+format
- Dataclasses / pydantic for DTOs
- f-strings, no `%` or `.format`

### Go
- `golangci-lint` enabled rules: errcheck, gosec, gofmt, govet, staticcheck
- Errors are values — wrap, don't `panic`

### Java / Kotlin
- Null-safety strict
- Records / data classes for DTOs
- No reflection unless framework-required
