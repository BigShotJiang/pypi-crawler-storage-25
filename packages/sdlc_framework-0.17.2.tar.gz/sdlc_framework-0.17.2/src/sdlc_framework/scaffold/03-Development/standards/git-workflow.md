# Git Workflow

## Branching model — **Trunk-based** (recommended)

```
main (always deployable)
  ├── feat/<ticket>-short-desc
  ├── fix/<ticket>-short-desc
  ├── chore/<area>
  └── release/<vMAJOR.MINOR>      (only if hotfix train needed)
```

- Short-lived feature branches (≤ 3 days)
- Merge to `main` via PR + green CI
- Use **feature flags** for incomplete work — don't long-live a branch

## Commit messages — **Conventional Commits**
```
<type>(<scope>): <imperative subject>

<body>

<footer>
```

Examples:
```
feat(auth): add OAuth2 PKCE flow

Implements RFC 7636 to prevent code interception on public clients.
Refs PROJ-123.

BREAKING CHANGE: /v1/auth/token now requires code_verifier.
```

Types: `feat | fix | docs | style | refactor | perf | test | build | ci | chore | revert`

## Pull Request rules
- Title = squashed-merge message (Conventional)
- Description fills `templates/PR-Template.md`
- ≤ 400 lines diff (split if larger)
- Required reviewers:
  - 1 codeowner
  - +1 if security-sensitive
- All conversations resolved before merge
- CI green (lint, test, build, security scan)

## Tagging & releases
- Tags: `vMAJOR.MINOR.PATCH` (SemVer)
- Auto-generated changelog (release-please / semantic-release)
- Release notes link to relevant ADRs and tickets

## Hotfix flow
```
main → cherry-pick into release/X.Y → tag X.Y.Z+1 → deploy → backport notes
```

## Forbidden
- Force-push on `main` (protected)
- Committing secrets — use `.gitignore` + pre-commit `gitleaks`
- Large binaries — use Git LFS or external storage
- Merge commits in feature branches — rebase or squash

## Pre-commit hooks (recommended)
- `pre-commit` framework with: gitleaks, ruff/eslint, prettier/black, conventional-commit, end-of-file-fixer

## AI-assisted commits
- AI may *draft* commit messages, but author = human pushing.
- If AI generated significant code, add trailer:
  ```
  Co-authored-by: Claude <noreply@anthropic.com>
  AI-Tools-Used: claude, copilot
  ```
