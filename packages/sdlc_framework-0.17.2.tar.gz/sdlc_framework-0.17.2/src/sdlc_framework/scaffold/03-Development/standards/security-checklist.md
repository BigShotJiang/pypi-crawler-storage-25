# Secure-Coding Checklist

> Per PR. Block merge if any item below fails.

## Input handling
- [ ] All inputs validated at boundary (type + range + format)
- [ ] Allowlist over denylist
- [ ] Max length enforced on every string field
- [ ] File uploads: type sniff (not just extension), size cap, virus scan, store outside web root
- [ ] No SSRF — outbound URLs validated against allowlist; block private CIDRs

## Output handling
- [ ] HTML: contextual escaping (templating engine in autoescape mode)
- [ ] SQL: parameterized queries only — no string concat
- [ ] Shell / OS: no shell-out with user input; if unavoidable, use `execve`-style arg arrays
- [ ] LDAP / XML / JSON path: escape per context
- [ ] Set `Content-Type` explicitly

## AuthN / AuthZ
- [ ] All endpoints require auth unless explicitly public
- [ ] AuthZ check next to data access (not only at gateway)
- [ ] No IDOR — check ownership / tenancy on every read
- [ ] Sessions: short-lived, rotated on privilege change
- [ ] MFA enforced for admin

## Crypto
- [ ] No homemade crypto
- [ ] Vetted libs only (libsodium, BoringSSL via SDK, etc.)
- [ ] Random: CSPRNG (`secrets`, `crypto.randomBytes`)
- [ ] Passwords: argon2id (or bcrypt cost ≥ 12)
- [ ] JWT alg pinned to RS256/EdDSA (never `none`)

## Secrets
- [ ] No secrets in code, env files, or logs
- [ ] Secrets via vault; rotated ≤ 90d
- [ ] `gitleaks` clean in CI

## Headers (web)
- [ ] CSP (`default-src 'self'`)
- [ ] HSTS (`max-age=31536000; includeSubDomains; preload`)
- [ ] `X-Content-Type-Options: nosniff`
- [ ] `Referrer-Policy: strict-origin-when-cross-origin`
- [ ] `Permissions-Policy` minimized
- [ ] CORS: explicit origins, no `*` for credentialed

## Cookies
- [ ] `HttpOnly`, `Secure`, `SameSite=Lax|Strict`
- [ ] Session cookie name not default

## CSRF
- [ ] State-changing requests require token (double-submit cookie or origin check)

## Rate limit & abuse
- [ ] Per-user + per-IP limits
- [ ] Brute-force protection on auth endpoints (lockout / captcha)

## Dependencies
- [ ] `npm audit` / `pip-audit` / `gosec` clean
- [ ] No deps from unverified sources
- [ ] Lockfiles committed
- [ ] Renovate/Dependabot enabled

## Logging / privacy
- [ ] No PII / secrets in logs
- [ ] Audit log for admin and security-sensitive actions
- [ ] Logs retained per policy

## Testing
- [ ] AuthZ tests (positive + negative)
- [ ] Fuzz / property tests on parsers
- [ ] DAST in CI (ZAP baseline)
- [ ] SAST (Semgrep / CodeQL)

## AI-specific
- [ ] LLM input sanitized; system prompts not exposed
- [ ] Prompt injection considered
- [ ] AI outputs validated before exec/SQL/HTML
- [ ] Tool calls logged with trace_id

## Incident readiness
- [ ] Runbook in `04-Testing-Deploy/runbooks/`
- [ ] On-call rotation aware of new endpoint
- [ ] SLOs defined
