# Error Handling Standard

## Principles
1. **Errors are part of the API** — type them.
2. **Fail fast at boundary, recover deep inside**.
3. **Never swallow** — log or propagate, never both silently.
4. **User-facing errors are plain English + actionable**.
5. **Internal errors carry context** — what, where, trace_id.

## Error categories
| Category | HTTP | When | User sees |
|---|---|---|---|
| Validation | 400 | Bad input | Specific field + fix |
| Auth | 401 | No/invalid token | "Please sign in" |
| Forbidden | 403 | No permission | "You don't have access" |
| Not found | 404 | Resource gone | "We couldn't find this" |
| Conflict | 409 | Concurrent change | "Someone else just updated this" |
| Rate limit | 429 | Too many requests | "Slow down — try again in N seconds" |
| Server error | 500 | Bug / dep failure | "Something went wrong on our side" |
| Service unavailable | 503 | Maintenance / overload | "Try again shortly" |

## Wire format (RFC 7807)
```json
{
  "type": "https://api.example.com/errors/validation",
  "title": "Validation failed",
  "status": 400,
  "detail": "email: must be a valid address",
  "instance": "/v1/users",
  "trace_id": "01HX..."
}
```

## Retry policy

| Error | Retryable? | Strategy |
|---|---|---|
| 408, 429, 502, 503, 504 | Yes | Exponential backoff + jitter, max 3 |
| 5xx with idempotency key | Yes | Same key, max 3 |
| 5xx without idempotency key (POST) | **No** | Surface to user |
| 4xx (other) | No | Surface immediately |

## Circuit breaker
Wrap external calls:
- Closed → half-open after 30s of N failures
- Half-open → 1 trial; success closes, failure opens again
- Open → fail fast with cached/fallback response

## Logging on error
```python
logger.error(
    "payment_charge_failed",
    extra={
        "trace_id": ctx.trace_id,
        "user_id": user.id,
        "order_id": order.id,
        "vendor": "stripe",
        "vendor_code": err.code,
    },
)
```
- **Never** log card numbers, passwords, full tokens.
- Stack traces: yes for 5xx, no for expected 4xx.

## User-facing copy (microcopy)
- Don't blame the user — say what to do next
- ❌ "Invalid input"
- ✅ "Email looks off — make sure it includes @ and a domain"

## Anti-patterns
- `catch (e) {}` — empty catch
- `throw new Error(e.message)` — loses original stack
- Returning `null` for errors — use Result type
- Generic `Exception` everywhere — be specific
