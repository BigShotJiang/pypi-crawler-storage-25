# Definition of Done (DoD)

> Một story chỉ được "Done" khi tất cả mục dưới ✅. Không thoả → "In Review" hoặc "In Progress".

## Per User Story
- [ ] Acceptance criteria met (Given/When/Then)
- [ ] Code merged to `main`
- [ ] Unit + integration tests passing
- [ ] Code reviewed by ≥ 1 codeowner
- [ ] Lint + format + security scan clean
- [ ] Docs updated (user-facing + technical)
- [ ] Translations updated (if applicable)
- [ ] Demoed in standup / show-and-tell
- [ ] PM signed off

## Per Sprint
- [ ] All committed stories meet story-level DoD
- [ ] Sprint goal demonstrated
- [ ] Retro held + actions logged
- [ ] Velocity / metrics updated in dashboard
- [ ] Carryover documented with reason

## Per Release
- [ ] All DoD-Sprint items
- [ ] Release notes drafted
- [ ] Smoke tests on staging green
- [ ] Performance benchmark within budget
- [ ] Security review (scoped to changes)
- [ ] Rollback plan rehearsed
- [ ] On-call briefed
- [ ] Customer comms prepared (if user-impacting)

## Per Phase Gate (SDLC)
- [ ] Phase deliverables in this folder all signed off
- [ ] Dashboard shows phase = 100%
- [ ] Next phase entry criteria met
