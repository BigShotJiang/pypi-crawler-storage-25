# Pull Request

## Summary
> 1–3 sentences: what, why.

## Changes
- ...
- ...

## Linked tickets
- Closes #
- Refs PROJ-

## Type
- [ ] feat
- [ ] fix
- [ ] refactor
- [ ] perf
- [ ] docs
- [ ] test
- [ ] chore

## Screenshots / videos (UI changes)
| Before | After |
|---|---|
|  |  |

## How to test
1. ...
2. ...

## Definition of Done
- [ ] Tests written & passing locally
- [ ] Lint / format clean
- [ ] Docs updated (README, OpenAPI, ADR if applicable)
- [ ] Backwards-compatible OR migration documented
- [ ] Feature flag wraps risky paths
- [ ] Observability (logs / metrics / traces) added
- [ ] Security checklist reviewed (`03-Development/standards/security-checklist.md`)
- [ ] Performance impact considered

## AI tool disclosure
> Required by SDLC policy. Be honest — this is for traceability, not judgement.

| Tool | Used? | What it generated |
|---|---|---|
| Claude | yes/no | e.g. unit tests, scaffolding |
| GitHub Copilot | yes/no | inline completions in `src/foo.ts` |
| Cursor | yes/no | refactor in `src/bar.ts` |
| Codex / others | yes/no | ... |

- [ ] AI-generated code reviewed line-by-line
- [ ] No security-sensitive logic written by AI without 2nd human review

## Rollout / Rollback
- Rollout: feature flag `ff_xxx` → 1% → 10% → 100%
- Rollback: toggle flag off, no DB rollback needed (or describe migration revert)

## Risk assessment
- Blast radius: ...
- Affected users: ...
- Data migration: yes/no — describe

## Follow-ups
- [ ] Issue # for ...
