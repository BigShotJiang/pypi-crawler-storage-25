# Code Review Checklist

> Reviewer prints/keeps this open. Pin in IDE. ~10 min per 200 lines.

## Correctness
- [ ] Solves the stated problem (matches PRD/ticket)
- [ ] Edge cases covered (empty, null, max, min, concurrent, retry)
- [ ] No off-by-one / boundary bugs
- [ ] Errors handled per `error-handling.md`

## Design
- [ ] Right level of abstraction — not over- or under-engineered
- [ ] No duplicated logic — DRY where it matters, WET where coincidental
- [ ] Naming clear — would a new joiner understand?
- [ ] Cohesive modules — single responsibility

## Tests
- [ ] New code has tests
- [ ] Tests fail without the change (verify by removing impl)
- [ ] Cover happy + edge + error paths
- [ ] No flaky timing assumptions
- [ ] No hidden coupling between tests

## Security
- [ ] No secrets / PII in code or logs
- [ ] Input validated, output encoded
- [ ] AuthZ checks present
- [ ] Run `security-checklist.md` mentally

## Performance
- [ ] No accidental N+1
- [ ] No quadratic loop on user-controlled size
- [ ] Streaming for large payloads
- [ ] Bounded retries / timeouts

## Observability
- [ ] Logs at right level, structured
- [ ] Metrics exposed (or follow service convention)
- [ ] Traces propagate `trace_id`
- [ ] Errors actionable for on-call

## Backwards compatibility
- [ ] API changes additive OR `/v2` introduced
- [ ] DB migrations reversible
- [ ] Feature flag for risky path
- [ ] Old client still works during rollout

## Docs
- [ ] README / runbook updated if behavior changed
- [ ] ADR added for non-obvious decisions
- [ ] OpenAPI / proto updated

## AI-generated code (extra scrutiny)
- [ ] Disclosure present in PR description
- [ ] Code makes sense (not "looks plausible but does X wrong")
- [ ] No phantom imports / hallucinated APIs
- [ ] License / attribution clean
- [ ] Same security & test bar as human code

## Review etiquette
- Comment **on the code, not the author**
- Distinguish blocking vs nit (`nit:` prefix)
- Suggest with code blocks where useful
- Approve or request changes — don't leave PRs in limbo
