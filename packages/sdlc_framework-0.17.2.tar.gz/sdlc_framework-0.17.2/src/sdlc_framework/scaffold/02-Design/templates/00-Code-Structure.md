# Code Structure — {{PROJECT_NAME}}

> Maps the **containers / responsibilities** declared in `01-Architecture.md` to **concrete folders under `src/`**. This file is consumed by `sdlc tasks bootstrap` to assign each Phase 3 task's `code_glob`. **Without this file, bootstrap falls back to a per-user-story slug folder layout, which produces a "code-soup" project.**

## 1. Container → folder map

> One row per container from `01-Architecture.md` §"C4 Level 2 — Containers". Folder paths are relative to repo root. Each folder owns a single layer of responsibility — keep them cohesive.

| Container (from Architecture) | Folder | Owns | Imports allowed from |
|---|---|---|---|
| App shell                     | `src/app/`         | Routing, layout, top-level wiring                | scene, state, a11y, lib |
| 3D scene runtime              | `src/scene/`       | Meshes, shaders, camera, R3F components          | lib, domain |
| State                         | `src/state/`       | Reducers, selectors, URL ↔ storage sync          | domain |
| A11y layer                    | `src/a11y/`        | Hidden DOM mirror, focus management              | state, domain |
| Domain                        | `src/domain/`      | Pure data — body slugs, planet metadata, types   | (none — leaf) |
| Lib                           | `src/lib/`         | Cross-cutting utilities (no business logic)      | (none — leaf) |
| Tests (integration + e2e)     | `tests/`           | Cross-container tests                            | n/a |

> **Replace the example rows above** with the actual containers from your `01-Architecture.md`. Delete this note before verifying.

## 2. User story → container map

> Drives `sdlc tasks bootstrap`. Each row tells bootstrap which folder a story's code should land in. A single story may touch multiple containers — list the **primary** one (where its main module lives); secondary touch-points are still allowed inside the task's globs.

| User story ID | Title (short)                             | Primary container | Module hint                |
|---|---|---|---|
| US-001 | Watch animated solar system               | scene             | `solar-scene.tsx`          |
| US-002 | Open planet detail                        | state             | `panel-reducer.ts`         |
| US-003 | Reduced motion preference                 | a11y              | `motion-policy.ts`         |
| US-004 | Share planet deep-link                    | state             | `planet-query.ts`          |

> **Replace these example rows** with rows generated from `01-Planning/02-User-Stories.md`. Bootstrap matches by US ID prefix.

## 3. Dependency rules

State the import direction explicitly so reviewers and `code-reviewer` agent can flag violations.

- `app/` may import from `scene/`, `state/`, `a11y/`, `lib/`, `domain/`.
- `scene/` may import from `lib/`, `domain/`. May NOT import from `app/`, `state/`, `a11y/`.
- `state/` may import from `domain/`. May NOT import from `app/`, `scene/`, `a11y/`, `lib/`.
- `a11y/` may import from `state/`, `domain/`. May NOT import from `scene/`, `app/`.
- `domain/`, `lib/` are leaves — no internal imports between containers.

> Adjust the rules to match your architecture. The point is: **state them**, so violations are detectable.

## 4. Test colocation

| Test type | Location | Run by |
|---|---|---|
| Unit | colocated `<module>.spec.ts` next to source | Phase 3 task `write-tests` stage |
| Integration | `tests/integration/` | Phase 4 `integration-tests` |
| E2E | `tests/e2e/` | Phase 4 `e2e-tests` |
| Smoke | `tests/smoke/` | Phase 5 deploy gate |

## 5. Naming conventions

- Folders: kebab-case, singular (`scene/`, not `scenes/`).
- Files: kebab-case, suffix by responsibility (`*-reducer.ts`, `*-policy.ts`, `*-scene.tsx`).
- Tests: same name + `.spec.<ext>` colocated with the source they test.
- Type-only files: `*.d.ts` at the container root (`scene.d.ts`).

---

**Verify checklist** — tick each before adding the verify marker:

- [ ] Every container in `01-Architecture.md` C4 L2 has a row in §1.
- [ ] Every user story in `01-Planning/02-User-Stories.md` has a row in §2.
- [ ] Dependency rules in §3 match the layering implied by the architecture.
- [ ] No two containers share the same folder.
- [ ] Folder names are lowercase kebab-case (no spaces, no PascalCase).

<!-- sdlc:verified-by: <name> <iso-date> -->
