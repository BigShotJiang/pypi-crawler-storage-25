# API Specification — {{PROJECT_NAME}}

> **Source of truth**: `openapi.yaml` (generated/edited side-by-side with this doc).
> Lint với Spectral `@stoplight/spectral-cli lint openapi.yaml` trước khi merge.

## Conventions

| Topic | Rule |
|---|---|
| Versioning | URL path: `/v1/...`. Breaking change → `/v2/...` |
| Auth | `Authorization: Bearer <jwt>` |
| Content-Type | `application/json; charset=utf-8` |
| Errors | RFC 7807 Problem+JSON |
| Pagination | Cursor: `?cursor=...&limit=` (max 100) |
| Idempotency | `Idempotency-Key: <uuid>` on POST/PATCH |
| Timestamps | ISO 8601 UTC: `2026-04-30T10:00:00Z` |
| IDs | ULID (sortable, opaque) |
| Rate limit | Headers `X-RateLimit-*` + `Retry-After` |

## Standard Error Shape (Problem+JSON)
```json
{
  "type": "https://api.example.com/errors/validation",
  "title": "Validation failed",
  "status": 400,
  "detail": "Field 'email' is required",
  "instance": "/v1/users",
  "trace_id": "01HX..."
}
```

## Endpoint Template

### `POST /v1/{{resource}}`
**Description**: ...

**Request body**
```json
{
  "name": "string",
  "email": "user@example.com"
}
```

**Responses**
| Code | Meaning | Body |
|---|---|---|
| 201 | Created | `Resource` |
| 400 | Validation error | `Problem` |
| 401 | Unauthorized | `Problem` |
| 409 | Conflict (duplicate) | `Problem` |
| 429 | Rate limited | `Problem` + `Retry-After` |

**Headers (response)**
- `Location: /v1/{{resource}}/{id}`
- `X-RateLimit-Remaining: 99`

**Curl**
```bash
curl -X POST https://api.example.com/v1/{{resource}} \
  -H "Authorization: Bearer $TOKEN" \
  -H "Idempotency-Key: $(uuidgen)" \
  -d '{"name":"Alice","email":"alice@example.com"}'
```

---

## OpenAPI snippet (paste into `openapi.yaml`)

```yaml
openapi: 3.1.0
info:
  title: {{PROJECT_NAME}} API
  version: 1.0.0
servers:
  - url: https://api.example.com/v1
components:
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
  schemas:
    Problem:
      type: object
      required: [type, title, status]
      properties:
        type: { type: string, format: uri }
        title: { type: string }
        status: { type: integer }
        detail: { type: string }
        instance: { type: string }
        trace_id: { type: string }
security:
  - bearerAuth: []
```

## Webhooks (if any)
| Event | Payload schema | Retry policy |
|---|---|---|
| `resource.created` | `ResourceCreated` | exp backoff, 5 attempts |
