# System Architecture — {{PROJECT_NAME}}

## 1. Context (C4 Level 1)
> Hệ thống của ta tương tác với *ai* và *gì* bên ngoài.

```mermaid
C4Context
  Person(user, "End User")
  System(sys, "Our System", "Core product")
  System_Ext(idp, "Identity Provider", "OAuth2")
  System_Ext(pay, "Payments", "Stripe")
  Rel(user, sys, "Uses")
  Rel(sys, idp, "Authenticates via")
  Rel(sys, pay, "Charges via")
```

## 2. Container View (C4 Level 2)

```mermaid
flowchart LR
  subgraph Client
    Web[Web SPA]
    Mobile[Mobile App]
  end
  subgraph Edge
    GW[API Gateway]
  end
  subgraph Services
    Auth[Auth Service]
    Core[Core Service]
    Worker[Async Worker]
  end
  subgraph Data
    PG[(Postgres)]
    Redis[(Redis)]
    S3[(Object Store)]
  end
  Web --> GW --> Auth & Core
  Core --> PG & Redis
  Worker --> PG & S3
  Core -.publish.-> Worker
```

## 3. Tech Stack
| Layer | Choice | Rationale |
|---|---|---|
| Frontend | React + TypeScript + Vite | Team expertise, ecosystem |
| Backend | Node.js (NestJS) / Python (FastAPI) / Go | TBD per ADR-001 |
| DB | PostgreSQL 15 | ACID, JSONB |
| Cache | Redis 7 | Pub/sub + caching |
| Queue | RabbitMQ / SQS | Decoupling |
| Object store | S3-compatible | Files, exports |
| Observability | OpenTelemetry → Datadog | Vendor-neutral |
| CI/CD | GitHub Actions | Native to repo |
| IaC | Terraform | Multi-cloud |

## 4. Cross-cutting Concerns
- **Authentication**: OAuth2 + JWT (rotating, 15min access / 7d refresh)
- **Authorization**: RBAC + ABAC for fine-grained
- **Logging**: Structured JSON, `trace_id` propagated via W3C Trace Context
- **Errors**: RFC 7807 Problem Details
- **Rate limit**: Token bucket per user + per IP
- **Idempotency**: `Idempotency-Key` header on POST/PATCH

## 5. Data Flow (key journey)
```mermaid
sequenceDiagram
  participant U as User
  participant W as Web
  participant G as Gateway
  participant C as Core
  participant Q as Queue
  participant Wk as Worker
  U->>W: Click "Submit"
  W->>G: POST /v1/jobs
  G->>C: forward (auth'd)
  C->>C: validate + persist
  C->>Q: publish JobCreated
  C-->>W: 202 Accepted {jobId}
  Q->>Wk: deliver
  Wk->>Wk: process
  Wk-->>W: SSE/WebSocket update
```

## 6. Deployment Topology
- **Environments**: dev → staging → prod (+ ephemeral preview per PR)
- **Regions**: primary `ap-southeast-1`, DR `ap-southeast-2`
- **Multi-AZ**: yes (3 AZs)
- **Blue/Green** for stateful migrations

## 7. Capacity Planning
| Metric | Baseline | Peak | Strategy |
|---|---|---|---|
| RPS | 200 | 2,000 (10×) | HPA on CPU + queue depth |
| DB connections | 50 | 200 | PgBouncer pool |
| Storage growth | 10 GB/mo | 100 GB/mo | Lifecycle to cold tier @ 90d |

## 8. Open Architecture Questions
- [ ] Q: Sync vs async for `X` flow?
- [ ] Q: Single DB vs split per service?

## 9. References
- ADRs: `02-Design/templates/05-ADR.md`
- Threat model: `02-Design/templates/06-Threat-Model.md`
