# Database Schema — {{PROJECT_NAME}}

## Conventions

| Topic | Rule |
|---|---|
| Engine | PostgreSQL 15 |
| Naming | `snake_case`, plural tables (`users`, `orders`) |
| PK | `id BIGSERIAL` or `id ULID` (text) |
| Timestamps | `created_at`, `updated_at` (timestamptz, default now) |
| Soft delete | `deleted_at timestamptz NULL` |
| Tenancy | `tenant_id` on every multi-tenant row |
| FK | `ON DELETE` always specified — no implicit `NO ACTION` |
| Migrations | sqitch / Flyway / Alembic — one PR = one migration |
| PII tagging | column comment `pii=true` for SAR/erasure tooling |

## ER Diagram (logical)

```mermaid
erDiagram
  users ||--o{ orders : places
  orders ||--|{ order_items : contains
  products ||--o{ order_items : "ordered as"
  users {
    bigint id PK
    text email UK
    text name
    timestamptz created_at
    timestamptz deleted_at
  }
  orders {
    bigint id PK
    bigint user_id FK
    numeric total_cents
    text status
    timestamptz created_at
  }
  products {
    bigint id PK
    text sku UK
    text name
    numeric price_cents
  }
  order_items {
    bigint id PK
    bigint order_id FK
    bigint product_id FK
    int quantity
    numeric unit_price_cents
  }
```

## Tables

### `users`
| Column | Type | Constraints | PII | Notes |
|---|---|---|---|---|
| id | bigserial | PK | | |
| email | citext | UNIQUE NOT NULL | yes | Lowercase via citext |
| name | text | NOT NULL | yes | |
| password_hash | text | NULL | yes | argon2id |
| role | text | NOT NULL DEFAULT 'user' | | enum-ish; consider table |
| created_at | timestamptz | NOT NULL DEFAULT now() | | |
| updated_at | timestamptz | NOT NULL DEFAULT now() | | trigger |
| deleted_at | timestamptz | NULL | | soft-delete |

**Indexes**
- `users_email_lower_idx` UNIQUE on `(lower(email))` (handled by citext)
- `users_created_at_idx` on `created_at` (ad-hoc reporting)

### `orders`
> ...

## Migration policy
- **Always backward-compatible**: add column → backfill → switch reads → drop old.
- **Never** `DROP COLUMN` in same release that stops writing to it.
- **Locks**: long migrations use `CREATE INDEX CONCURRENTLY`, batched updates.
- **Review**: every migration reviewed by data eng + DBA.

## Data retention
| Table | Hot | Warm | Cold | Erasure trigger |
|---|---|---|---|---|
| users | active | n/a | n/a | GDPR SAR |
| audit_log | 90d | 1y | 7y | n/a (legal hold) |
| sessions | 30d | n/a | n/a | logout / expiry |

## Backup & DR
- Daily logical backup (pg_dump) → S3, 30d retention
- WAL archiving + PITR, 7d window
- Quarterly restore drill
