# ADR-{{NNNN}}: {{Short title}}

| Field | Value |
|---|---|
| **Status** | Proposed / Accepted / Superseded by ADR-XXXX / Deprecated |
| **Date** | YYYY-MM-DD |
| **Deciders** | {{names}} |
| **Tags** | architecture / data / security / ... |

## Context
> Bối cảnh, ràng buộc, áp lực dẫn đến quyết định này. Không phán xét — chỉ mô tả thực trạng.

## Options Considered

### Option A — {{Name}}
- **Pros**: ...
- **Cons**: ...
- **Cost**: ...

### Option B — {{Name}}
- **Pros**: ...
- **Cons**: ...
- **Cost**: ...

### Option C — Do nothing
- **Pros**: zero risk now
- **Cons**: pain compounds

## Decision
> **Chọn Option X** vì ...

## Consequences

### Positive
- ...

### Negative / Trade-offs
- ...

### Neutral / Future-proofing
- ...

## Rollback Plan
> Nếu sai, undo như thế nào? Có cần migration ngược không?

## References
- Related ADRs: ADR-0003, ADR-0007
- RFC links, prototypes, benchmarks
