# Threat Model — {{PROJECT_NAME}}

> Method: **STRIDE per dataflow**. Update mỗi khi có change đáng kể đến trust boundary.

## 1. System Decomposition
- Components: see `01-Architecture.md` §2
- Trust boundaries: Internet ↔ Edge, Edge ↔ Services, Services ↔ Data

## 2. Assets & Sensitivity
| Asset | Type | Sensitivity | Owner |
|---|---|---|---|
| User PII | Data | High (GDPR) | Privacy |
| Auth tokens | Secret | Critical | Security |
| Payment data | Data | Critical (PCI) | Security |
| Audit logs | Data | High (legal) | Compliance |

## 3. STRIDE Threats

| ID | Component | Threat (S/T/R/I/D/E) | Description | Likelihood | Impact | Mitigation | Status |
|---|---|---|---|---|---|---|---|
| T-001 | API GW | **S**poofing | Token theft via XSS | M | H | HttpOnly cookies, CSP, short-lived JWT | Done |
| T-002 | Core | **T**ampering | Mass-assignment via JSON | H | M | Strict DTO whitelist | Done |
| T-003 | Worker | **R**epudiation | No audit on async actions | M | M | Append-only log w/ trace_id | Open |
| T-004 | DB | **I**nformation disclosure | Misconfigured backup ACL | L | H | KMS-encrypted, IAM least-priv | Done |
| T-005 | API GW | **D**oS | Unbounded query param | M | M | Rate limit + WAF | Done |
| T-006 | Auth | **E**oP | JWT alg=none accepted | L | C | Lock to RS256 in lib config | Done |

## 4. Cryptography Inventory
| Use | Algo | Key length | Rotation |
|---|---|---|---|
| TLS | TLS 1.3 | n/a | auto via cert manager |
| Data at rest | AES-256-GCM | 256 | 1y |
| Password | argon2id | n/a | n/a |
| JWT | RS256 | 2048 | 90d |

## 5. Secret Management
- Vault: AWS Secrets Manager / HashiCorp Vault
- No secrets in env files committed
- Rotation: automated via lambda + IAM

## 6. Open Issues
- [ ] Pen-test scheduled before GA
- [ ] DAST in CI (OWASP ZAP)
- [ ] SAST: Semgrep ruleset enabled

## 7. Compliance Mapping
| Control | Standard | Evidence |
|---|---|---|
| AC-2 | SOC2 | IAM policy review |
| A.9.4 | ISO 27001 | Access control SOP |
| Art. 32 | GDPR | Encryption + DPA |
