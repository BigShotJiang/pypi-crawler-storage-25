# UI / UX Specification — {{PROJECT_NAME}}

## 1. Design Principles
- Clarity > cleverness
- Mobile-first, responsive at 360 / 768 / 1280 / 1920
- Accessibility WCAG 2.1 AA non-negotiable
- Performance budget: TTI < 2s, CLS < 0.1, INP < 200ms

## 2. Design Tokens (single source of truth)
```json
{
  "color": {
    "brand": { "500": "#0E5BE6", "700": "#0944B4" },
    "neutral": { "50": "#F8FAFC", "900": "#0F172A" },
    "semantic": { "success": "#0E9F6E", "warn": "#D97706", "error": "#DC2626" }
  },
  "space": { "xs": 4, "sm": 8, "md": 16, "lg": 24, "xl": 32 },
  "radius": { "sm": 4, "md": 8, "lg": 16, "full": 9999 },
  "font": {
    "family": { "sans": "Inter, system-ui", "mono": "JetBrains Mono" },
    "size": { "xs": 12, "sm": 14, "md": 16, "lg": 20, "xl": 28 }
  }
}
```

## 3. Component Inventory
| Component | States | A11y notes | Storybook link |
|---|---|---|---|
| Button | default/hover/active/disabled/loading | `aria-busy` when loading | ... |
| Input | default/focus/error/disabled | `aria-invalid`, `aria-describedby` | ... |
| Modal | open/closed | trap focus, ESC closes, return focus | ... |
| Toast | info/success/warn/error | `role="status"` polite | ... |

## 4. Key Flows (with wireframes)

### Flow A — User onboarding
```
[Landing] → [Signup form] → [Email verify] → [Welcome tour] → [Dashboard]
```
- Mockup: `../diagrams/flow-onboarding.png`
- Empty states: ...
- Error states: ...
- Loading skeletons: ...

## 5. Responsive Behavior
| Breakpoint | Layout |
|---|---|
| ≤ 640 | single column, bottom nav |
| 641–1024 | two-column, top nav |
| ≥ 1025 | three-column with sidebar |

## 6. Accessibility Checklist
- [ ] Color contrast ≥ 4.5:1 (text), 3:1 (UI components)
- [ ] All interactive elements keyboard-reachable
- [ ] Visible focus ring (`outline: 2px solid var(--brand-500)`)
- [ ] Form labels programmatically associated
- [ ] Error messages identified by `aria-describedby`
- [ ] Skip-to-content link
- [ ] No reliance on color alone
- [ ] Animations respect `prefers-reduced-motion`
- [ ] Test with screen reader (NVDA / VoiceOver)
- [ ] Lighthouse a11y score ≥ 95

## 7. Copy / Microcopy Guidelines
- Voice: friendly, direct, no jargon
- Button labels: verbs ("Save changes", not "OK")
- Errors: explain *what* + *how to fix*

## 8. Localization
- ICU MessageFormat
- Pseudo-locale test (`xx-XX`) for layout overflow
- RTL support if `ar`/`he` in scope

## 9. Handoff Artifacts
- Figma: {{link}}
- Tokens export: `tokens.json`
- Icon library: `assets/icons/*.svg`
