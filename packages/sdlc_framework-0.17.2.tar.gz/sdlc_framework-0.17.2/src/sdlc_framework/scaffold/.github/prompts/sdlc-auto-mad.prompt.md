---
description: MAD MODE autopilot — auto-signs phase gates and auto-verifies artifacts. Stops only on clarifications, high-risk paths, errors, or PR review. NOT for production.
agent: agent
tools:
  - agent
  - search/codebase
  - edit
  - shell
---
<!-- generated-from: .claude/commands/sdlc-auto-mad.md -->


# /sdlc-auto-mad

⚠️  **MAD MODE — opt-in YOLO autopilot.** AI auto-signs phase signoffs and auto-verifies drafted artifacts. Use for prototypes, hackathons, throwaway projects. **Do NOT use** when you actually want a human in the loop on Phase 1/2/4 signoffs.

## How it differs from `/sdlc-auto`

| Stop reason       | `/sdlc-auto` | `/sdlc-auto-mad`                     |
| ----------------- | ------------ | ------------------------------------ |
| `verify_needed`   | stop         | **auto-verify** (marker: `ai-mad-mode`) |
| `gate`            | stop         | **auto-sign** (yaml: `approved_by: ai-mad-mode`) |
| `clarification`   | stop         | stop (kept — agent cannot infer intent) |
| `high_risk`       | stop         | stop (kept — auth/crypto/payment policy) |
| `review_pending`  | stop         | stop (PR is external dep) |
| `tasks_empty`     | bootstrap or stop | bootstrap or stop (same) |

Auto-signed yaml files clearly identify themselves as AI-generated and include an `unsign_command` for trivial revert.

## How it works

This command runs a loop. Each iteration:

1. Run via Bash: `sdlc auto-mad-step` — returns JSON describing the next action.
2. Parse the JSON. Possible actions:

   ### `action: "invoke"`
   - Same fields as `/sdlc-auto`: `agent`, `phase`, `item_id`, `item_label`, `stage`, `instruction`, `brief_context`.
   - Plus `auto_actions_taken`: list of `{kind, item_id|gate_id, at}` for any auto-signoffs / auto-verifications applied this iteration. **Print these to the user before invoking the agent** so they see what was just auto-handled.
   - Use the named `<agent>` subagent. Prepend `brief_context` to the prompt as pre-loaded orientation. Wait for the deliverable. **Loop back to step 1.**

   ### `action: "stop"`
   - Possible `stop_reason` values:
     - `clarification` — open clarification must be resolved
     - `high_risk` — auth/crypto/payment/secrets/migrations need explicit OK
     - `review_pending` — Phase 3 task PR open, waiting for human merge
     - `tasks_empty` — Phase 3 reached without tasks; user must draft `01-Planning/02-User-Stories.md` then `sdlc tasks bootstrap`
     - `auto_mad_cap` — safety cap hit (20 auto-actions in one call without producing real work — should never happen unless state is malformed)
     - `no_project` — `sdlc init` first
   - Print `auto_actions_taken` (if non-empty) so the user sees what got auto-handled before the stop.
   - Print the stop reason + `user_action`. Exit loop.

   ### `action: "done"`
   - All five phases complete. Print `auto_actions_taken` summary. Celebrate.

## Safety rules

- **Run `sdlc auto-mad-step` between every subagent invocation.** Re-scan after each step.
- **Never skip a `stop`.** Even in mad mode, clarifications and high-risk are real.
- **Defensive cap: max 20 outer-loop iterations** in a single session (separate from the inner auto-action cap inside `auto-mad-step`).
- **Surface auto-actions to the user every iteration.** They are why mad mode is faster — but also where mistakes accumulate.

## Reverting auto-signoffs

Every auto-signoff yaml lists its own `unsign_command`. To revert ALL ai-mad-mode signoffs in one shot:

```
grep -l "approved_by: ai-mad-mode" automation/signoffs/*.yaml | xargs rm
```

Then re-run `sdlc scan` — the engine will re-flag the gates as pending.

## Single-step alternative

`sdlc auto-mad-step` is the one-shot version (no loop). Use for tighter inspection.
