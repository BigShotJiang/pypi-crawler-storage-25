---
description: Retrofit SDLC framework on an existing running project (auto-detect existing PRDs, designs, code, runbooks).
agent: agent
tools:
  - agent
  - search/codebase
  - edit
  - shell
---
<!-- generated-from: .claude/commands/sdlc-adopt.md -->


# /sdlc-adopt

For a project that already has code, designs, or runbooks — onboard SDLC without redoing prior work.

## What to do

1. Run via Bash: `sdlc adopt` (passes any `--auto` or `--dry-run` flags through).
2. The CLI scans the repo for existing assets:
   - PRDs / requirements (`docs/PRD.md`, `docs/requirements.md`)
   - Architecture docs (`docs/ARCHITECTURE.md`, OpenAPI specs)
   - User stories
   - Source files + test files (TDD ratio computed)
   - CI workflows (`.github/workflows/`)
   - Runbooks, SLO docs, incident response docs
3. Interactively asks the user, per phase: "Are these artifacts complete and approved?"
4. On `y`, the CLI:
   - Creates symlinks (or copies on Windows) into the canonical SDLC paths (e.g. `01-Planning/01-PRD.md → ../docs/PRD.md`)
   - Auto-verifies via `sdlc verify <item-id> --auto` (marker says `imported-from-existing`)
5. For Phase 3 development, asks how to treat existing code:
   - **Legacy mode** (recommended): adds `legacy_code_globs: ["src/**"]` to `project.yaml` so existing code is grandfathered (no TDD enforcement); only new tasks under `automation/tasks/` go through TDD
   - **Skip mode**: manage tasks manually
6. After completion:
   - Suggest `/sdlc-resume` to see the starting point
   - Suggest `/sdlc-next` to begin work on the next pending item

## Idempotency

`sdlc adopt` is idempotent — running it twice does not duplicate symlinks or verifications.

## When NOT to use

- Brand-new project with no code yet → use `/sdlc-init` or `sdlc setup` instead
- Project already on framework v0.6.x → use `/sdlc-migrate-v2` to upgrade schema
