---
description: Mark a Phase 1/2/4 artifact as verified by the user.
agent: agent
tools:
  - agent
  - search/codebase
  - edit
  - shell
---
<!-- generated-from: .claude/commands/sdlc-verify.md -->


# /sdlc-verify

Mark an artifact as verified after the user has reviewed it.

## What to do

1. Run via Bash: `sdlc verify <item-id>` (the argument is the DoD item id, e.g. `prd-exists`).
2. Pass `--name=<who>` if the user gave a specific name; otherwise the CLI defaults to `git config user.name`.
3. Read the CLI output:
   - On success: an `<!-- sdlc:verified-by: ... -->` marker is appended to all files matching the rule's glob.
   - On "no files match" or "item id not in rules.json": surface the error to the user.
4. Suggest the next step:
   - "Run `/sdlc-scan` to see your updated phase progress."
   - Or `/sdlc-next` if there are still pending items.

## When to use

- Phase 1: `prd-exists`, `user-stories-with-ac`, `nfr-quantified`, `stakeholder-raci`, `risks-mitigated`
- Phase 2: `architecture-doc`, `api-spec`, `db-schema`, `adr-logged`, `threat-model`, `ui-spec`, `wireframes`, `design-system`, `accessibility`
- Phase 4: `test-plan-written`, `load-test-results`
- Phase 5 (selected): `deploy-runbook-written`, `slo-monitoring`, `incident-response`

Setup items in Phase 3 do NOT use the verify mechanism (they're file-existence checks).
