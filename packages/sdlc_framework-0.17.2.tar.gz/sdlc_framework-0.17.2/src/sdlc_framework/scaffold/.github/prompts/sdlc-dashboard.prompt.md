---
description: Open the SDLC dashboard in a browser.
agent: agent
tools:
  - agent
  - search/codebase
  - edit
  - shell
---
<!-- generated-from: .claude/commands/sdlc-dashboard.md -->


# /sdlc-dashboard

Serve the bundled dashboard HTML on localhost.

## What to do

1. Run via Bash, in background: `sdlc dashboard --port 8765 &`
   - Note: this starts a long-running HTTP server. Use background execution so the chat is not blocked.
2. Tell the user: "Dashboard is now serving at http://localhost:8765/dashboard/. Open it in your browser. Run `/sdlc-scan` periodically to refresh state."
3. Do NOT auto-open the browser unless the user asks.
4. To stop the server later, the user runs Bash: `pkill -f 'sdlc.*dashboard'` (mention this only if asked).

## Pre-requisite

If `automation/state.json` doesn't exist yet, the dashboard will be empty. Suggest `/sdlc-scan` first to populate it.
