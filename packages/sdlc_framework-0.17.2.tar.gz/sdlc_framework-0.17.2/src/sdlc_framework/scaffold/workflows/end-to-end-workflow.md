# End-to-End SDLC Workflow

> Quy trình mặc định khi áp dụng framework này vào 1 dự án mới hoặc 1 feature lớn.

## 0) Kickoff (1–2 ngày)
- [ ] Sponsor xác nhận scope & ngân sách
- [ ] PM tạo project channel (Slack/Teams) + Jira/Linear project
- [ ] Copy SDLC framework vào repo, chạy `setup-ai-configs.sh`
- [ ] Replace `{{PROJECT_NAME}}` everywhere

## 1) Phase 1 — Planning (3–7 ngày)
1. Discovery: 3–5 user interviews, dữ liệu hiện trạng
2. Draft PRD (`01-Planning/templates/01-PRD.md`) — có thể dùng prompt `ai-tools/shared-prompts/planning-prompts.md` để generate v0.1
3. Stakeholder review (RACI: PRD = Sponsor accountable)
4. Decompose → User Stories với AC
5. Risk register init
6. **Gate**: PRD signed off → vào Phase 2

## 2) Phase 2 — Design (5–10 ngày)
1. Architect spike + RFC
2. Tech stack ADR (`02-Design/templates/05-ADR.md`)
3. API spec (OpenAPI source-of-truth)
4. DB schema review with data eng
5. UI/UX mockups (Figma) → UI Spec
6. Threat model STRIDE
7. **Gate**: Design review approved → vào Phase 3

## 3) Phase 3 — Development (sprints)
- Sprint = 1–2 weeks
- Mỗi sprint:
  - Planning: pull stories từ backlog, capacity đã trừ PTO/meeting
  - Daily standup
  - PRs theo template, CI gate, ≥ 1 reviewer (2 nếu security-sensitive)
  - AI tool disclosure bắt buộc trong PR
  - Demo + retro cuối sprint
- **Continuous gate**: trunk always deployable

## 4) Phase 4 — Testing & Deploy
- QA chạy test plan trên staging
- Performance + security gates phải xanh trước canary
- Deploy theo runbook: canary 1% → 10% → 50% → 100%
- Monitor SLO 30 min sau khi 100%
- Auto-rollback nếu burn rate > 14×

## 5) Post-launch
- Tuần 1: daily check-in dashboards
- Tuần 2–4: weekly metrics review
- Sau 30 ngày: retro + decide kill / iterate / scale

## RACI gọn cho cả flow
| Phase | A (1 người) | R | C | I |
|---|---|---|---|---|
| Planning | Sponsor | PM | Lead Eng, Design, QA, Sec | Team |
| Design | Eng Lead | Architect | PM, Sec, Data | Team |
| Dev | Eng Lead | Devs | QA, Design | PM |
| Test/Deploy | SRE Lead | DevOps + QA | Eng Lead, Security | Sponsor |

## Dùng AI ở mỗi phase

| Phase | Best AI prompts |
|---|---|
| 1 | `ai-tools/shared-prompts/planning-prompts.md` |
| 2 | `ai-tools/shared-prompts/design-prompts.md` |
| 3 | `ai-tools/shared-prompts/dev-prompts.md` |
| 4 | `ai-tools/shared-prompts/test-deploy-prompts.md` |

## Anti-patterns
- Nhảy thẳng Phase 3 mà không có Phase 1+2 → tech debt + rework
- AI generate code mà không review human → bug + license risk
- Gộp 10 features vào 1 PR → khó review, khó rollback
- Đo phase Done bằng "code merged" thay vì DoD đầy đủ
