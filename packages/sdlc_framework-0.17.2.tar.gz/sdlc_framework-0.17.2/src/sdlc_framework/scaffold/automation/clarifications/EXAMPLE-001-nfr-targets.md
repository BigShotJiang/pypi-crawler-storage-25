# [EXAMPLE] Cần SLO targets cụ thể cho NFR

> Đây là FILE MẪU. Khi agent thật sự cần hỏi sẽ tạo file mới `001-...md`.
> Khi đã hiểu format, có thể xoá file này.

STATUS: open
**Phase**: 1
**DoD item**: nfr-quantified
**Created by**: claude-agent
**Created at**: 2026-04-30T10:00:00Z

## Why I'm asking
PRD chỉ nói "high performance" mà không có số. Tôi không thể tự đặt SLO mà không biết:
- User-facing hay internal?
- Budget infra dành cho project là bao nhiêu?
- Đây có phải là replacement của hệ thống cũ (có baseline) không?

## Options I considered
- **Option A** (recommended) — Team default
  - p95 latency < 300ms
  - 99.9% monthly uptime
  - Throughput baseline 200 rps, scale tới 2k rps
  - Phù hợp với hầu hết user-facing API
- **Option B** — Tighter (premium tier)
  - p95 < 150ms, 99.95% uptime
  - Trade-off: infra cost ~2× option A
- **Option C** — Looser (non-critical / batch)
  - p95 < 500ms, 99.5% uptime

## What I need from user
1. Chọn A / B / C, hoặc
2. Cung cấp số cụ thể của riêng anh

## How to resolve
Edit file này:
1. Đổi `STATUS: open` → `STATUS: resolved`
2. Thêm dòng `RESOLUTION: A` (hoặc B/C/custom)
3. (optional) thêm note giải thích
