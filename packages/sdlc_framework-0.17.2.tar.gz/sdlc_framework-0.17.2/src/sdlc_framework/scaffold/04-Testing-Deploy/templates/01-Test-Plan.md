# Test Plan — {{PROJECT_NAME}} / {{RELEASE}}

## 1. Scope
- In: ...
- Out: ...

## 2. Test Strategy
| Layer | Tooling | Coverage target |
|---|---|---|
| Unit | jest / pytest / go test | ≥ 80% biz logic |
| Component | RTL / pytest | UI states, hooks |
| Contract | Pact / Schemathesis | All public endpoints |
| Integration | testcontainers | DB + queue + service |
| E2E | Playwright / Cypress | Critical journeys |
| Performance | k6 / Locust | p95 latency, throughput |
| Security | ZAP / Semgrep / CodeQL | OWASP Top 10 |
| Accessibility | axe-core | WCAG 2.1 AA |
| Chaos | Chaos Mesh / Gremlin | Resilience scenarios |

## 3. Environments
| Env | Purpose | Data | Access |
|---|---|---|---|
| dev | Inner loop | synthetic | devs |
| staging | Pre-prod gate | masked prod-like | QA + devs |
| canary | 1% prod | real | SRE only |
| prod | Live | real | restricted |

## 4. Test Cases (high-level — full list in test-mgmt tool)
| ID | Title | Priority | Type | Status |
|---|---|---|---|---|
| TC-AUTH-001 | OAuth2 happy path | P0 | E2E | |
| TC-AUTH-002 | Expired token refresh | P0 | Integration | |
| TC-PERF-001 | 1k RPS sustained 30 min | P1 | Perf | |

## 5. Performance criteria
- p95 < 300 ms @ 1k rps
- Error rate < 0.1%
- Memory steady under 24h soak

## 6. Entry / Exit criteria
**Entry**
- All P0 features feature-flagged ON in staging
- Test data prepared

**Exit**
- 0 P0/P1 bugs open
- ≥ 95% pass rate
- Sign-off from QA Lead, PM, Eng Lead

## 7. Risks & Mitigations
- Risk: flaky E2E → quarantine + fix in 1 sprint
- Risk: load env != prod → use prod-shape data, scaled-down infra

## 8. Reporting
- Daily test run summary in #qa channel
- Burndown of bugs in dashboard
