# CI / CD Pipeline

## Stages

```mermaid
flowchart LR
  PR[PR opened] --> L[Lint + Format]
  L --> U[Unit tests]
  U --> SAST[SAST + Secrets scan]
  SAST --> B[Build + Container scan]
  B --> IT[Integration tests]
  IT --> CT[Contract tests]
  CT --> PRV[Preview env deploy]
  PRV --> Review[Human review]
  Review --> Merge[Merge to main]
  Merge --> Stg[Deploy staging]
  Stg --> E2E[E2E + Smoke]
  E2E --> Perf[Perf gate]
  Perf --> Canary[Canary 1%]
  Canary --> Prog[Progressive 10/50/100]
  Prog --> Mon[Auto-monitor SLO]
  Mon -. burn .-> RB[Auto-rollback]
```

## GitHub Actions example (`.github/workflows/ci.yml`)

```yaml
name: CI
on:
  pull_request:
  push:
    branches: [main]
permissions:
  contents: read
  security-events: write
jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20', cache: 'npm' }
      - run: npm ci
      - run: npm run lint
      - run: npm run format:check
  test:
    needs: lint
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20', cache: 'npm' }
      - run: npm ci
      - run: npm test -- --coverage
      - uses: codecov/codecov-action@v4
  security:
    needs: lint
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: gitleaks/gitleaks-action@v2
      - uses: github/codeql-action/init@v3
        with: { languages: 'javascript' }
      - uses: github/codeql-action/analyze@v3
  build:
    needs: [test, security]
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: docker/setup-buildx-action@v3
      - uses: docker/build-push-action@v6
        with:
          push: false
          tags: app:${{ github.sha }}
      - uses: aquasecurity/trivy-action@master
        with: { image-ref: 'app:${{ github.sha }}', exit-code: '1', severity: 'CRITICAL,HIGH' }
```

## Required checks for merge
- lint, test, security, build, contract, integration

## Branch protection rules
- Require PR
- Require codeowners review
- Require status checks (above) green
- No force-push, no bypass

## Promotion model
| From | To | Trigger | Approver |
|---|---|---|---|
| PR | Preview | merge | auto |
| main | staging | merge | auto |
| staging | canary | scheduled / manual | release captain |
| canary | prod | SLO green ≥ 30 min | auto |

## Secrets management
- GitHub Environments → secrets per env
- OIDC to cloud (no long-lived keys)
- Reviewer required for `prod` env
