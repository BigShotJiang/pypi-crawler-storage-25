# Monitoring & SLOs — {{SERVICE_NAME}}

## SLI / SLO / SLA

| SLI | Definition | SLO | Window | Owner |
|---|---|---|---|---|
| Availability | (good / total) HTTP 2xx-3xx + 4xx (excl 5xx) | 99.9% | 30d rolling | SRE |
| Latency | p95 < 300 ms | 99% of requests | 30d rolling | SRE |
| Correctness | Job success rate | 99.5% | 30d rolling | Eng Lead |
| Freshness | Data lag < 5 min | 99% of time | 7d | Data Eng |

Error budget = 1 − SLO. Burn rate alerts:
- 14.4× (1h budget burn in 5min) → page
- 6× (1h budget burn in 1h) → ticket
- 3× (24h budget burn in 24h) → review

## Dashboards

### RED (per service)
- **R**ate: requests / sec
- **E**rrors: error rate
- **D**uration: p50/p95/p99

### USE (per host/container)
- **U**tilization: CPU, mem, disk, net
- **S**aturation: queue depth, runqueue
- **E**rrors: kernel, NIC, disk

### Business KPIs
- Signups, MAU, conversion, revenue (per project)

## Tracing
- OpenTelemetry SDK
- Sample 10% by default; 100% on errors
- W3C `traceparent` propagated through all hops

## Logs
- Structured JSON
- Required fields: `time`, `level`, `msg`, `service`, `env`, `trace_id`, `span_id`, `user_id` (if auth'd)
- Centralized: Loki / ELK / Datadog
- Retention: 30d hot, 1y cold

## Alerts (examples)
```yaml
- alert: HighErrorRate
  expr: sum(rate(http_requests_total{status=~"5.."}[5m])) / sum(rate(http_requests_total[5m])) > 0.01
  for: 5m
  labels: { severity: page }
  annotations:
    summary: "Error rate > 1% on {{ $labels.service }}"
    runbook: "https://runbooks/highErrorRate"
```

Each alert MUST have:
- Severity (page / ticket / info)
- Runbook link
- Owner team
- Mute window for known maintenance

## On-call
- Rotation: weekly, follow-the-sun
- Tools: PagerDuty / Opsgenie
- Response: ack < 5min, mitigate < 30min
- Handoff doc daily 9am
