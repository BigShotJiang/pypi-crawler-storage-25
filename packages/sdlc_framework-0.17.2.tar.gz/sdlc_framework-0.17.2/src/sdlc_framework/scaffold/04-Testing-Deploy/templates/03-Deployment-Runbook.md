# Deployment Runbook — {{SERVICE_NAME}}

## Purpose
Steps to safely deploy `{{service}}` to {{env}}, plus rollback.

## Prerequisites
- [ ] PR merged to `main`
- [ ] CI green
- [ ] Staging soak ≥ 30 min, no SLO burn
- [ ] On-call notified in #ops
- [ ] Feature flags configured

## Deployment steps

### 1. Pre-deploy
1. Announce in `#deploys`: "Deploying {{service}} v{{version}} — eta 20m"
2. Check current SLO dashboards — green?
3. Verify no ongoing incident

### 2. Deploy (canary)
```bash
# Tag
git tag -a v1.4.0 -m "release v1.4.0"
git push origin v1.4.0

# Trigger pipeline
gh workflow run deploy.yml -f env=canary -f version=v1.4.0
```

### 3. Validate canary (15 min)
- Error rate ≤ baseline + 0.1%
- p95 latency within budget
- No new alerts

### 4. Progressive rollout
- 10% → wait 10m → check
- 50% → wait 10m → check
- 100% → monitor 30m

### 5. Post-deploy
- Update changelog
- Close release ticket
- Demo if user-facing change

## Rollback

### When to rollback (any of):
- Error rate > 2× baseline
- p95 > budget for 5 min
- SLO burn rate > 14×
- New PagerDuty alert

### How
```bash
# Option A: rollback via flag (preferred — fast)
flags toggle ff_new_thing off

# Option B: redeploy previous tag
gh workflow run deploy.yml -f env=prod -f version=v1.3.9 -f rollback=true
```

DB migrations:
- Forward-only — never auto-revert.
- If migration is the cause: app rollback first, then forward-fix.

## Smoke tests post-deploy
- [ ] `/health` 200
- [ ] Login flow works
- [ ] Critical journey (payment / submit / etc.) works
- [ ] Logs flowing
- [ ] Metrics ingesting

## Communication
- Internal: `#ops`, `#announcements`
- External: status page if user-impacting
- Customer success briefed for major UI changes

## Sign-offs
| Role | Name | Time |
|---|---|---|
| Release captain | | |
| On-call | | |
| QA | | |
