# Incident Response Process

## Severity matrix

| Sev | Definition | Response | Comms |
|---|---|---|---|
| SEV-1 | Major outage / data loss / security breach | Page on-call, war room within 10 min | Status page, exec, customers |
| SEV-2 | Significant degradation, partial outage | Page on-call, investigate within 30 min | Status page if user-facing |
| SEV-3 | Minor degradation, workaround exists | Ticket, fix within 1 business day | Internal |
| SEV-4 | Bug / non-impacting | Backlog | None |

## Roles during incident
- **Incident Commander (IC)**: drives, decides, comms — not hands-on debugging
- **Operations**: hands on keyboard
- **Communications**: status page, exec updates
- **Scribe**: timeline in shared doc

## Flow
```
Detect → Acknowledge → Assemble → Mitigate → Communicate → Resolve → Postmortem
```

1. **Detect**: alert / customer / internal
2. **Acknowledge**: ack page; declare incident in `#incidents`
3. **Assemble**: IC opens war room (Zoom + Slack thread)
4. **Mitigate** (priority over fix): rollback, flag off, scale, failover
5. **Communicate**: status page within 15 min for SEV-1/2
6. **Resolve**: confirm metrics back to baseline
7. **Postmortem**: blameless, within 5 business days

## Status page templates

**Investigating**
> We're investigating reports of [symptom]. Started [time UTC]. Updates in 30 min.

**Identified**
> We've identified the cause: [short]. Working on mitigation.

**Monitoring**
> Mitigation deployed. Monitoring for stability.

**Resolved**
> Issue resolved at [time]. Postmortem to follow.

## Postmortem template (blameless)

```markdown
# Postmortem — {{title}}
- Date: YYYY-MM-DD
- Duration: HH:MM (start → resolved)
- Severity: SEV-X
- Authors: ...

## Summary
1–2 sentence executive summary.

## Impact
- Users affected: ...
- Revenue: ...
- Data: ...

## Timeline (UTC)
- HH:MM — alert fired
- HH:MM — IC assembled
- HH:MM — mitigation deployed
- HH:MM — resolved

## Root cause
What broke and why. Prefer "5 whys".

## What went well
- ...

## What went badly
- ...

## Action items (own + due date)
| Item | Owner | Due | Type |
|---|---|---|---|
| Add alert for X | @alice | 2026-05-15 | Detection |
| Refactor Y | @bob | 2026-06-01 | Prevention |
```
