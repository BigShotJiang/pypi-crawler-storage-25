# Runbook — {{ALERT_NAME}}

> Open this within 30s of being paged. Calm. Focus.

## Symptom
What you'll see in the alert / dashboard.

## First-5-minutes checklist
- [ ] Acknowledge page
- [ ] Open dashboard: {{link}}
- [ ] Check recent deploys: `gh release list -L 3`
- [ ] Check status of upstream deps: {{links}}
- [ ] Declare incident if user-facing

## Common causes & quick mitigations

### Cause A: recent deploy
**Mitigate**: rollback or feature-flag off.
```bash
flags toggle ff_xxx off
# or
gh workflow run rollback.yml -f service={{svc}} -f to=v1.3.9
```

### Cause B: upstream dependency degraded
**Mitigate**: enable circuit breaker / cached fallback.

### Cause C: traffic spike
**Mitigate**: scale up; rate-limit if abuse suspected.

## Diagnostic queries
```sql
-- top slow endpoints last 15m
SELECT route, p95(duration_ms)
FROM http_requests WHERE time > now() - INTERVAL '15 minutes'
GROUP BY route ORDER BY 2 DESC LIMIT 10;
```

```bash
# tail error logs
kubectl logs -n prod -l app={{svc}} --tail=200 | grep ERROR
```

## Escalation
- Tier 2: {{team}} via PagerDuty
- Vendor: support email + ticket # template

## After resolution
- Update incident channel
- Schedule postmortem (SEV-1/2)
- File action items in tracker
