# Phase 4 — Testing, Deploy & Monitoring

> **Mục tiêu**: Đảm bảo code chạy đúng trong production và team biết khi nào nó *không* đúng.

## Deliverables

| # | File | Owner |
|---|------|-------|
| 1 | `templates/01-Test-Plan.md` | QA Lead |
| 2 | `templates/02-CI-CD-Pipeline.md` | DevOps |
| 3 | `templates/03-Deployment-Runbook.md` | DevOps |
| 4 | `templates/04-Monitoring-SLO.md` | SRE |
| 5 | `templates/05-Incident-Response.md` | SRE |
| 6 | `runbooks/incident-template.md` | On-call |

## Definition of Done — Phase 4

- [ ] Test plan executed; pass-rate ≥ 95%, no P0/P1 open
- [ ] CI green (lint, unit, integration, security, build)
- [ ] Deployment runbook validated in staging
- [ ] SLOs defined + alerts wired
- [ ] Dashboards live (RED + USE)
- [ ] On-call rotation aware of new service
- [ ] Postmortem template ready

## Test Pyramid
```
        🔺  E2E (5%)
      🔺🔺   Integration (15%)
    🔺🔺🔺   Component / Contract (30%)
  🔺🔺🔺🔺🔺 Unit (50%)
```
