# Phase 1 — Planning & Requirements

> **Mục tiêu**: Biến idea thô thành tài liệu rõ ràng để team (gồm cả AI agents) hiểu *làm gì* và *tại sao*.

## Deliverables của Phase này

| # | File | Mục đích | Owner |
|---|------|---------|-------|
| 1 | `templates/01-PRD.md` | Product Requirements Document | PM |
| 2 | `templates/02-User-Stories.md` | User stories + acceptance criteria | PM/BA |
| 3 | `templates/03-Requirements-Spec.md` | Functional + non-functional requirements | BA |
| 4 | `templates/04-Stakeholder-Map.md` | RACI + comms plan | PM |
| 5 | `templates/05-Risk-Register.md` | Risk identification & mitigation | PM |

## Quy trình đề xuất

```
Idea → Discovery → PRD draft → Stakeholder review → Sign-off → Phase 2
```

## Definition of Done — Phase 1

- [ ] PRD đã được approve bởi product sponsor
- [ ] User stories có acceptance criteria rõ ràng (Given/When/Then)
- [ ] Non-functional requirements định lượng được (vd: p95 < 200ms)
- [ ] Stakeholder map xác định rõ RACI
- [ ] Top-5 risks có mitigation plan
- [ ] Tất cả AI tools đọc được context từ `ai-tools/` folder

## AI Assist trong Phase này

Khi viết PRD/User Stories, dùng prompts trong `../ai-tools/shared-prompts/planning-prompts.md`. Ví dụ:

```
Use template at 01-Planning/templates/01-PRD.md.
Context: <paste meeting notes>
Task: Generate first PRD draft. Flag anything ambiguous as <NEEDS-CLARIFICATION>.
```
