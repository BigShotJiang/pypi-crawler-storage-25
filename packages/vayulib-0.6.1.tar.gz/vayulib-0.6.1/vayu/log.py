"""Library logger.

Vayu uses a named `"vayu"` logger (`L`) with a `NullHandler` attached so that
importing the library has no effect on the root logger or global logging config.
Applications are expected to configure handlers/levels themselves. For parity
with the previous stdout-with-timezone behavior, call `configure()` at startup.
"""

import datetime
import logging
import os
import sys
from typing import IO, Optional
from zoneinfo import ZoneInfo


L = logging.getLogger("vayu")
L.addHandler(logging.NullHandler())


def _rss_gib():
    try:
        with open(f"/proc/{os.getpid()}/statm") as f:
            return int(f.read().split()[1]) * os.sysconf("SC_PAGE_SIZE") / (1 << 30)
    except OSError:
        import psutil

        return psutil.Process().memory_info().rss / (1 << 30)


def mem(msg, *args, level=logging.INFO, **kwargs):
    L.log(level, f"{msg} [mem: {_rss_gib():.1f} GiB]", *args, **kwargs)


L.i = L.info
L.d = L.debug
L.e = L.error
L.w = L.warning
L.c = L.critical
L.mem = mem


def configure(
    level: Optional[str] = None,
    tz: Optional[str] = None,
    stream: IO = sys.stdout,
    fmt: str = "[%(asctime)s] %(levelname)s> %(message)s",
) -> None:
    """Configure the vayu logger with a stdout handler and timezone-aware timestamps.

    Off by default so that importing the library does not mutate global logging
    state. Call once at application startup to opt in.

    Args:
        level: log level (default: env var LOG_LEVEL, else "INFO").
        tz: IANA timezone for timestamps (default: env var TZ, else "UTC").
        stream: handler output stream.
        fmt: log record format.
    """
    level = (level or os.getenv("LOG_LEVEL", "INFO")).upper()
    zone = ZoneInfo(tz or os.getenv("TZ", "UTC"))

    class _TzFormatter(logging.Formatter):
        def formatTime(self, record, datefmt=None):
            return (
                datetime.datetime.fromtimestamp(record.created, datetime.timezone.utc)
                .replace(microsecond=0)
                .astimezone(zone)
                .isoformat(sep="T")
            )

    for existing in list(L.handlers):
        if not isinstance(existing, logging.NullHandler):
            L.removeHandler(existing)

    handler = logging.StreamHandler(stream)
    handler.setFormatter(_TzFormatter(fmt))
    L.addHandler(handler)
    L.setLevel(level)
    L.propagate = False
    logging.getLogger("asyncio").setLevel(logging.WARNING)
