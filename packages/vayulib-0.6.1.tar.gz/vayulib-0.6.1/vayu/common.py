import asyncio
import datetime as dt
import random
import time
from functools import wraps
from logging import Logger
from typing import Callable, Dict, Iterable, Tuple, Type, Union


def camel_or_space_to_snake(s):
    s = s.replace(" ", "_")
    return "".join(["_" + c.lower() if c.isupper() else c for c in s]).lstrip("_")


_ExcType = Type[Exception]


class retry:  # noqa
    """Retry calling the decorated function using an exponential backoff. Asyncio compatible."""

    def __init__(
        self,
        exception_to_check: Union[_ExcType, Tuple[_ExcType]],
        tries: int = 4,
        delay: float = 1,
        backoff: float = 2,
        logger: Logger = None,
    ):
        """
        Args:
            exception_to_check: the exception to check. Maybe a tuple of exceptions to check.
            tries: number of times to try (not retry) before giving up
            delay: initial delay between retries in seconds
            backoff: backoff multiplier e.g. value of 2 will double the delay for each retry
            logger: logger to use. If None, print.
        """
        self._tries = tries
        self._delay = delay
        self._backoff = backoff
        self._ignore_exc_types = exception_to_check
        self._log_fn = logger.warning if logger else print

    def __call__(self, fn):
        is_async = asyncio.iscoroutinefunction(fn)
        if not is_async:

            @wraps(fn)
            def decorated(*a, **k):
                last_exception = None
                delay = self._delay
                for attempt in range(self._tries):
                    try:  # noqa
                        return fn(*a, **k)
                    except self._ignore_exc_types as e:
                        last_exception = e
                        msg = f"Error {e.__class__.__name__}: retrying {fn.__name__} - in {delay}s - attempt {attempt + 1}/{self._tries}"
                        self._log_fn(msg)
                    time.sleep(delay)
                    delay *= self._backoff
                if last_exception is not None:
                    raise last_exception

            return decorated

        else:

            @wraps(fn)
            async def decorated(*a, **k):
                last_exception = None
                delay = self._delay
                for attempt in range(self._tries):
                    try:  # noqa
                        return await fn(*a, **k)
                    except self._ignore_exc_types as e:
                        last_exception = e
                        msg = f"{str(e.__class__.__name__)}: retrying {fn.__name__} - in {delay}s - attempt {attempt + 1}/{self._tries}"
                        self._log_fn(msg)
                    await asyncio.sleep(delay)
                    delay *= self._backoff
                if last_exception is not None:
                    raise last_exception

            return decorated


JitterT = Union[float, int, dt.timedelta]


def add_jitter(n: JitterT, jitter_percentage: int = 20) -> JitterT:
    """Add jitter to seconds."""
    return n * (1 + random.randint(-jitter_percentage, jitter_percentage) / 100)


def group(iterable: Iterable, key: Callable) -> Dict:
    """Group elements of an iterable by a key function."""
    groups = {}
    for item in iterable:
        k = key(item)
        if k not in groups:
            groups[k] = []
        groups[k].append(item)
    return groups
