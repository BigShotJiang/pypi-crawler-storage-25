import datetime as dt
from dataclasses import dataclass, replace
from operator import attrgetter
from typing import Sequence, Union


Comparable = Union[None, dt.date, dt.datetime, int, float]


@dataclass
class Interval:
    """A closed interval ``[start, end]`` with union / intersection / containment algebra.

    Works on any comparable type — ``int``, ``float``, ``date``, ``datetime``.
    Subclasses (e.g. ``TimeWindow``) flow through operators automatically because
    the dunder methods use ``self.__class__``.

    Single-point intervals (``start == end``) are allowed so that touching
    endpoints like ``[1, 3] & [3, 5]`` produce ``[3, 3]`` instead of raising.

    Attributes:
        start: Lower bound (inclusive).
        end: Upper bound (inclusive).
    """

    start: Comparable
    end: Comparable

    def intersects(self, other: "Interval") -> bool:
        """Return True if this interval and ``other`` share at least one point."""
        return self.start <= other.end and other.start <= self.end

    def intersection(self, other: "Interval") -> "Interval":
        """Return the overlapping sub-interval, or raise if there's no overlap.

        Raises:
            ValueError: If the intervals don't overlap.
        """
        if not self.intersects(other):
            raise ValueError("No intersection possible")

        return replace(self, start=max(self.start, other.start), end=min(self.end, other.end))

    @classmethod
    def union(cls, intervals: Sequence["Interval"], allow_gaps: bool = False) -> "Interval":
        """Return the smallest interval that contains all inputs.

        Args:
            intervals: One or more intervals to union.
            allow_gaps: If False (the default), raise ``ValueError`` when the
                inputs don't collectively touch or overlap. If True, return the
                bounding envelope even when gaps exist.

        Raises:
            AssertionError: If ``intervals`` is empty.
            ValueError: If ``allow_gaps`` is False and there is a gap between
                two inputs.
        """
        # TODO: Fix this: should have a signature same as intersection.
        if len(intervals) == 0:
            raise AssertionError("Length of intervals should at least be 1")
        if len(intervals) == 1:
            return intervals[0]

        intervals = sorted(intervals, key=attrgetter("start"))
        if not allow_gaps:
            for i in range(len(intervals) - 1):
                first = intervals[i]
                second = intervals[i + 1]
                if first.end < second.start:
                    raise ValueError(f"Gaps not supported in interval union")

        return cls(start=intervals[0].start, end=intervals[-1].end)

    @property
    def range(self) -> Comparable:
        """The span of the interval (``end - start``)."""
        return self.end - self.start

    def _validate(self):
        # Allow start == end so that touching-endpoint intersections (e.g. [1,3] & [3,5])
        # produce a valid single-point interval instead of crashing.
        assert self.start <= self.end, "start value should be less than or equal to end"

    def __post_init__(self):
        self._validate()

    def __or__(self, other) -> "Interval":
        return self.__class__.union([self, other])

    def __and__(self, other) -> "Interval":
        return self.intersection(other)

    def __sub__(self, other: Comparable) -> "Interval":
        return self.__class__(start=self.start - other, end=self.end - other)

    def __add__(self, other: Comparable) -> "Interval":
        return self.__class__(start=self.start + other, end=self.end + other)

    def __mul__(self, other) -> "Interval":
        return self.__class__(start=self.start * other, end=self.end * other)

    def __contains__(self, item: Union[Comparable, "Interval"]):
        if isinstance(item, Interval):
            return item.start in self and item.end in self
        return self.start <= item <= self.end

    def __str__(self):
        return f"[{self.start} — {self.end}]"
