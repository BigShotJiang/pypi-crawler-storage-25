"""Vayu: async-first utilities for caching, time, parallelism, and pandas.

The base install keeps dependencies light. Pandas/plotly/numpy-backed helpers
live under `vayu.pandas_utils`, `vayu.plotly_utils`, and `vayu.statistics` and
require the `vayulib[data]` extra.
"""

from vayu.common import (
    add_jitter,
    camel_or_space_to_snake,
    group,
    retry,
)
from vayu.interval import Interval
from vayu.time_utils import (
    TimeWindow,
    epoch_time,
    from_timestamp,
    from_z_string,
    local_datetime,
    max_time,
    min_time,
    time_now,
    timeit,
    to_human_readable_time,
    ts_ms,
    utc_datetime,
)
from vayu.cache import (
    Cache,
    CacheMissError,
    FileCache,
    Jsoner,
    MemoryCache,
    Pickler,
    Serializer,
    mem_cache,
    mem_cached,
)
from vayu.log import L, configure as configure_logging

__all__ = [
    "Cache",
    "CacheMissError",
    "FileCache",
    "Interval",
    "Jsoner",
    "L",
    "MemoryCache",
    "Pickler",
    "Serializer",
    "TimeWindow",
    "add_jitter",
    "camel_or_space_to_snake",
    "configure_logging",
    "epoch_time",
    "from_timestamp",
    "from_z_string",
    "group",
    "install_pandas_extensions",
    "local_datetime",
    "max_time",
    "mem_cache",
    "mem_cached",
    "min_time",
    "retry",
    "time_now",
    "timeit",
    "to_human_readable_time",
    "ts_ms",
    "utc_datetime",
]


def install_pandas_extensions() -> None:
    """Attach `select` convenience methods to `pandas.DataFrame` and `pandas.Series`.

    Opt-in because it monkey-patches pandas globally. Call once at application
    startup if you want `df.select(...)` and `series.select(...)`. Requires the
    `vayulib[data]` extra.
    """
    import pandas as pd

    from vayu.pandas_utils import select_frame, select_series

    if not hasattr(pd.DataFrame, "select"):
        pd.DataFrame.select = select_frame
    if not hasattr(pd.Series, "select"):
        pd.Series.select = select_series
