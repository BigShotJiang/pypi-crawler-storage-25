"""
This package has been renamed to kanbaroo.

Install kanbaroo instead: pip install kanbaroo
"""

import warnings

warnings.warn(
    "The 'kanberoo' package has been renamed to 'kanbaroo'. "
    "Please update your installation: pip install kanbaroo",
    DeprecationWarning,
    stacklevel=2,
)

__version__ = "0.2.2"
