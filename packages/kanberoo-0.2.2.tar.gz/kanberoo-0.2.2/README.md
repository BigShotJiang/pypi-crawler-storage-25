# `kanberoo` has been renamed

This package has been renamed to [`kanbaroo`](https://pypi.org/project/kanbaroo/). The name is a portmanteau of `kangaroo` + `kanban`; the middle letter should have been `a` from the start.

## What to install

```
pip install kanbaroo
```

Or, for the full experience (API, CLI, TUI, MCP, web UI):

```
pip install 'kanbaroo[all]'
```

## Compatibility

This `kanberoo` package remains on PyPI as a version-`0.2.2` compatibility stub that transitively installs `kanbaroo==0.2.2`. `pip install kanberoo` still works; the canonical name going forward is `kanbaroo`. Please update your requirements files and scripts.

## Links

- New package: https://pypi.org/project/kanbaroo/
- GitHub: https://github.com/areese801/kanbaroo
