# coding=utf-8
from __future__ import annotations

from typing import Annotated, Optional

from pydantic import BaseModel, ConfigDict, Field

from turbo_agent_core.schema.basic import ModelParameters
from turbo_agent_core.schema.utils.tools import builtin_tool, get_builtin_tool_registry


class DemoToolOutput(BaseModel):
    model_config = ConfigDict(extra="allow")

    ok: bool = Field(description="是否执行成功。")
    config: Optional[ModelParameters] = Field(default=None, description="解析后的模型参数配置。")


def test_builtin_tool_schema_supports_nested_descriptions():
    registry = get_builtin_tool_registry()
    registry.clear()

    @builtin_tool(name="demo_schema_tool", space_name="test", project_name_id="schema")
    def demo_schema_tool(
        model_parameters: Annotated[Optional[ModelParameters], Field(description="模型调用参数。")]=None,
    ) -> DemoToolOutput:
        return DemoToolOutput(ok=True, config=model_parameters)

    tool = registry.get_tool_def("demo_schema_tool", belong_to_project_id="test/schema")

    assert tool is not None
    assert tool.input_schema["properties"]["model_parameters"]["description"] == "模型调用参数。"
    assert tool.input_schema["properties"]["model_parameters"]["properties"]["temperature"]["description"]
    assert tool.input[0].parameters is not None
    assert any(parameter.name == "temperature" for parameter in tool.input[0].parameters)
    assert tool.output_schema["properties"]["ok"]["description"] == "是否执行成功。"
    assert tool.output_schema["properties"]["config"]["properties"]["top_p"]["description"]
