from __future__ import annotations

from typing import List, Optional, Set, Union, Literal

from datetime import datetime

from pydantic import BaseModel, Field

from turbo_agent_core.schema.enums import AgentMode, RefType, ModelType

class BasicRef(BaseModel):
    id: str
    type: RefType
    name: Optional[str] = None
    name_en: Optional[str] = None
    space: Optional[str] = None
    belong_to_project_path: Optional[str] = None
    create_time: Optional[datetime] = None
    update_time: Optional[datetime] = None
    version: Optional[str] = None
    description: Optional[str] = None
    avatar_url: Optional[str] = None

class PlatformRef(BasicRef):
    type: RefType = RefType.Platform

class AuthMethodRef(BasicRef):
    type: RefType = RefType.AuthMethod

class SecretRef(BasicRef):
    type: RefType = RefType.Secret

class ModelRef(BasicRef):
    type: RefType = RefType.Model
    model_type: ModelType = ModelType.LargeLanguageModel

class ModelInstanceRef(BasicRef):
    type: RefType = RefType.ModelInstance
    model_ref: Optional[ModelRef] = None
    version_tag: Optional[str] = None
    is_active: Optional[bool] = None

class EndpointRef(BasicRef):
    type: RefType = RefType.Endpoint


class KnowledgeResourceRef(BasicRef):
    type: RefType = RefType.KnowledgeResource

class ToolCallRecordRef(BasicRef):
    type: RefType = RefType.ActionRecords

class AssistantConversationRef(BasicRef):
    type: RefType = RefType.Conversation

class WorksetRef(BasicRef):
    type: RefType = RefType.Workset

class AgentRef(BasicRef):
    type: RefType = RefType.Agent

class ToolRef(BasicRef):
    type: RefType = RefType.Tool

class CharacterRef(BasicRef):
    type: RefType = RefType.Character

class BusinessSettingRef(BasicRef):
    type: RefType = RefType.BusinessSetting


class JobExecutorRef(BasicRef):
    """Job 执行者引用（Agent）"""
    type: Literal[RefType.Agent, RefType.Tool, RefType.Character] = RefType.Agent
    # -------- 默认智能体配置（仅当 executor_ref 为 None 时有效）--------
    agent_mode: AgentMode = Field(
        default=AgentMode.QA_MODE,
        description="智能体执行模式（权限等级：qa/assistant/autonomous/admin）"
    )
