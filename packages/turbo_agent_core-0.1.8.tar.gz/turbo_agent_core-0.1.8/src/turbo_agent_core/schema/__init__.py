from turbo_agent_core.schema.enums import (
	JSON,
	LLMPromptMode,
	ModelType,
	WebProtocol,
	ToolOutputParseFormat,
	KnowledgeType,
	FileType,
	ResourceStatus,
	AuthType,
	KeyLocation,
	RefreshPeriod,
	RequestMethod,
    JobType,
    JobTaskStatus,
    TaskExecutionMode,
    TaskLabelDimension,
    AgentMode,
	ConversationMode,
    TaskAction,
)

from turbo_agent_core.schema.basic import Endpoint, Parameter, ModelSeries
from turbo_agent_core.schema.external import (
    Platform, AuthMethod, Secret,
    McpServerSpec, McpResourceDescriptor, McpTransport,
)
from turbo_agent_core.schema.resources import BusinessSetting, KnowledgeResource
from turbo_agent_core.schema.jobs import Job, TaskSpec
from turbo_agent_core.schema.refs import (
	KnowledgeResourceRef,
	AssistantConversationRef,
	ToolCallRecordRef,
	JobExecutorRef,
    WorksetRef
)
from turbo_agent_core.schema.states import (
	Message,
	Conversation,
	JobTask,
	MessageContent,
	MessageContentItem,
	MessageKnowledgeResourceContent,
)
from turbo_agent_core.schema.agents import (
    Agent, Character, Tool, 
    APITool, LLMTool, AgentTool,
    FrontendTool, BuiltinTool, MCPTool,
)
from turbo_agent_core.schema.brief_agent import (
	LLMModelBrief,
	AgentBrief,
	CharacterBrief,
	ToolBrief,
)
from turbo_agent_core.schema.detail_agent import (
	LLMModelDetail,
	AgentDetail,
	CharacterDetail,
	ToolDetail,
)
from turbo_agent_core.schema.resources import Workset
from turbo_agent_core.schema.utils.tools import (
    BuiltinToolRegistry,
    BuiltinToolRegistration,
	BuiltinToolExecutionContext,
	BuiltinToolSet,
	BuiltinToolRouter,
    MCPToolAuthHelper,
    get_builtin_tool_registry,
	builtin_tool,
	builtin_tool_provider,
    create_builtin_toolset,
    register_builtin_tool,
	register_builtin_tool_provider,
	create_builtin_tool_router,
    create_builtin_tool_def,
)

# 兼容别名：历史上部分代码使用 JobExecutor，这里映射到 JobExecutorRef。
JobExecutor = JobExecutorRef

__all__ = [
	# common
	"JSON",
    "Parameter",
	"LLMPromptMode",
	"ModelType",
	"WebProtocol",
	"ToolOutputParseFormat",
	"KnowledgeType",
	"FileType",
	"ResourceStatus",
	"AuthType",
	"KeyLocation",
	"RefreshPeriod",
	"RequestMethod",
	# resources
	"Endpoint",
    "ModelSeries",
	"Platform",
	"AuthMethod",
	"ToolPromptTemplate",
	"BusinessSetting",
	"KnowledgeResource",
	"Secret",
    # mcp
    "McpServerSpec",
    "McpResourceDescriptor",
    "McpTransport",
	# refs
	"AgentRef",
	"ModelRef",
	"ToolRef",
	"CharacterRef",
	"CharacterVersionRef",
	"ToolVersionRef",
	"PlatformRef",
	"KnowledgeResourceRef",
	"AssistantConversation",
	"Message",
	"MessageContent",
	"MessageContentItem",
	"MessageKnowledgeResourceContent",
    "ToolCallRecordRef",
	# core entities
	"Model",
	"ModelInstance",
	"Tool",
	"ToolVersion",
	"Character",
	"CharacterVersion",
	"Agent",
	"Workset",
	"WorksetWithConversation",
	"WorksetWithToolCallRecord",
	"WorksetWithKnowledgeResource",
	"WorksetWithAssistant",
    # tool variants
    "APITool",
    "LLMTool",
    "AgentTool",
    "FrontendTool",
    "BuiltinTool",
    "MCPTool",
	# brief/detail
	"AgentBrief",
	"LLMModelBrief",
	"CharacterBrief",
	"ToolBrief",
	"LLMModelDetail",
	"AgentDetail",
	"CharacterDetail",
	"ToolDetail",
    # builtin tool utilities
    "BuiltinToolRegistry",
    "BuiltinToolRegistration",
	"BuiltinToolExecutionContext",
	"BuiltinToolSet",
	"BuiltinToolRouter",
    "MCPToolAuthHelper",
    "get_builtin_tool_registry",
	"builtin_tool",
	"builtin_tool_provider",
    "create_builtin_toolset",
    "register_builtin_tool",
	"register_builtin_tool_provider",
	"create_builtin_tool_router",
    "create_builtin_tool_def",
    # job
    "JobType",
    "JobTaskStatus",
    "TaskExecutionMode",
    "TaskLabelDimension",
    "AgentMode",
	"ConversationMode",
    "TaskAction",
    "Job",
    "JobExecutor",
    "TaskSpec",
    "JobTask",
]

