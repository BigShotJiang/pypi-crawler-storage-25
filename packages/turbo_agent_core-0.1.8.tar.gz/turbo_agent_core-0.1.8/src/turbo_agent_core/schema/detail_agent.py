from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from turbo_agent_core.schema.basic import DetailTurboEntity, ModelParameters, Parameter, JSON
from turbo_agent_core.schema.refs import AgentRef, CharacterRef, ModelRef, ToolRef, SecretRef, ModelInstanceRef, EndpointRef,BusinessSettingRef
from turbo_agent_core.schema.resources import BusinessSetting
from turbo_agent_core.schema.enums import ModelType, ModelApiProvider

class ModelInstanceDetail(BaseModel):
    id: str = Field(description="模型实例 ID。")
    label: str = Field(description="模型实例显示名称。")
    space_name: str = Field(description="所属空间英文名。")
    project_name_id: Optional[str] = Field(default=None, description="所属项目英文名。")
    series_name: str = Field(description="模型系列英文名。")
    model_name: str = Field(description="模型名称。")
    version: Optional[str] = Field(default=None, description="模型实例版本号。")
    description: str = Field(description="模型实例描述。")
    request_model_id: str = Field(description="实际调用时使用的模型 ID。")
    is_active: bool = Field(description="该模型实例是否启用。")
    provider: ModelApiProvider = Field(default=ModelApiProvider.openai, description="模型服务提供商。")
    endpoint: Optional[EndpointRef] = Field(default=None, description="模型实例关联的端点引用。")
    token_cost_input: Optional[float] = Field(default=None, description="输入 token 单价。")
    token_cost_output: Optional[float] = Field(default=None, description="输出 token 单价。")
    concurrent_limit: Optional[int] = Field(default=None, description="并发限制。")
    rpm_limit: Optional[int] = Field(default=None, description="每分钟请求数限制。")
    tpm_limit: Optional[int] = Field(default=None, description="每分钟 token 数限制。")
    request_params: Optional[Dict[str, Any]] = Field(default=None, description="附加请求参数。")

class LLMModelDetail(DetailTurboEntity):
    """大模型编辑态详情。"""

    model_type: ModelType = Field(default=ModelType.LargeLanguageModel, description="模型类型。")
    thinking_model: bool = Field(default=False, description="是否为支持推理模式的模型。")
    series_name: str = Field(description="模型系列英文名。")
    source_urls: List[str] = Field(default_factory=list, description="模型来源地址列表。")
    default_parameters: ModelParameters = Field(default_factory=ModelParameters, description="模型默认参数配置。")
    instances: List[ModelInstanceRef] = Field(default_factory=list, description="该模型关联的实例引用列表。")


class AgentDetail(DetailTurboEntity):
    """智能体编辑态详情。"""

    version_tag: Optional[str] = Field(default=None, description="当前智能体版本标签。")
    description: Optional[str] = Field(default=None, description="智能体详细描述。")
    avatar_url: Optional[str] = Field(default=None, description="智能体头像地址。")
    has_memory: bool = Field(default=False, description="是否启用长期记忆。")
    expose_inner_thought: bool = Field(default=True, description="是否暴露内部思考过程。")

    model: Optional[ModelRef] = Field(default=None, description="绑定的大模型引用。")
    model_parameters: Optional[ModelParameters] = Field(default=None, description="运行时模型参数配置。")
    setting: Optional[BusinessSettingRef] = Field(default=None, description="业务设置引用。")

    tools: List[ToolRef] = Field(default_factory=list, description="绑定的工具引用列表。")
    characters: List[CharacterRef] = Field(default_factory=list, description="关联的角色引用列表。")
    assistant_agents: List[AgentRef] = Field(default_factory=list, description="辅助智能体引用列表。")
    secrets: List[SecretRef] = Field(default_factory=list, description="可用凭据引用列表。")


class ToolDetail(DetailTurboEntity):
    """工具编辑态详情。"""

    version_tag: Optional[str] = Field(default=None, description="当前工具版本标签。")
    description: Optional[str] = Field(default=None, description="工具详细描述。")
    avatar_url: Optional[str] = Field(default=None, description="工具头像地址。")
    tool_type: Optional[str] = Field(default=None, description="工具类型标识。")

    input: List[Parameter] = Field(default_factory=list, description="工具输入参数定义列表。")
    output: List[Parameter] = Field(default_factory=list, description="工具输出参数定义列表。")
    # 自动派生或显式指定的 JSON Schema（若外部直接提供则不覆盖）
    input_schema: JSON = Field(default_factory=dict, description="工具输入 JSON Schema。")
    output_schema: JSON = Field(default_factory=dict, description="工具输出 JSON Schema。")

    model: Optional[ModelRef] = Field(default=None, description="绑定的大模型引用。")
    model_parameters: Optional[ModelParameters] = Field(default=None, description="工具运行时模型参数。")
    setting: Optional[BusinessSettingRef] = Field(default=None, description="业务设置引用。")

    backend_agent: Optional[AgentRef] = Field(default=None, description="作为工具执行后端的智能体引用。")
    backend_character: Optional[CharacterRef] = Field(default=None, description="作为工具执行后端的角色引用。")


class CharacterDetail(DetailTurboEntity):
    """角色编辑态详情。"""

    version_tag: Optional[str] = Field(default=None, description="当前角色版本标签。")
    description: Optional[str] = Field(default=None, description="角色详细描述。")
    avatar_url: Optional[str] = Field(default=None, description="角色头像地址。")
    expose_inner_thought: bool = Field(default=True, description="是否暴露角色内部思考过程。")

    model: Optional[ModelRef] = Field(default=None, description="绑定的大模型引用。")
    model_parameters: Optional[ModelParameters] = Field(default=None, description="角色运行时模型参数。")
    setting: Optional[BusinessSettingRef] = Field(default=None, description="业务设置引用。")

    tools: List[ToolRef] = Field(default_factory=list, description="绑定的工具引用列表。")
