from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field
from turbo_agent_core.schema.basic import BriefTurboEntity
from turbo_agent_core.schema.refs import CharacterRef, ModelRef, ToolRef, PlatformRef, SecretRef
from turbo_agent_core.schema.enums import ModelType, ModelApiProvider
 

class ModelInstanceBrief(BaseModel):
    id: str = Field(description="模型实例 ID。")
    label: str = Field(description="模型实例显示名称。")
    space_name: str = Field(description="所属空间英文名。")
    series_name: str = Field(description="模型系列英文名。")
    model_name: str = Field(description="模型名称。")
    version: Optional[str] = Field(default=None, description="模型实例版本号。")
    description: str = Field(description="模型实例摘要描述。")
    is_active: bool = Field(description="当前是否启用。")
    provider: ModelApiProvider = Field(default=ModelApiProvider.openai, description="模型服务提供商。")


class LLMModelBrief(BriefTurboEntity):
    """大模型卡片信息。"""

    model_type: ModelType = Field(default=ModelType.LargeLanguageModel, description="模型类型。")
    thinking_model:bool = Field(default=False, description="是否为支持推理模式的模型。")
    series_name: str = Field(description="模型系列英文名。")


class ToolBrief(BriefTurboEntity):
    """工具卡片信息。"""

    version_tag: Optional[str] = Field(default=None, description="当前默认版本标签。")
    platform: Optional[PlatformRef] = Field(default=None, description="所属平台引用。")


class CharacterBrief(BriefTurboEntity):
    """角色卡片信息。"""

    version_tag: Optional[str] = Field(default=None, description="当前默认版本标签。")
    model: Optional[ModelRef] = Field(default=None, description="绑定的大模型引用。")
    tools: List[ToolRef] = Field(default_factory=list, description="绑定的工具引用列表。")


class AgentBrief(BriefTurboEntity):
    """智能体卡片信息。"""

    model: Optional[ModelRef] = Field(default=None, description="绑定的大模型引用。")
    act_as_characters: List[CharacterRef] = Field(default_factory=list, description="可扮演的角色引用列表。")
    tools: List[ToolRef] = Field(default_factory=list, description="绑定的工具引用列表。")
    secrets: List[SecretRef] = Field(default_factory=list, description="可用凭据引用列表。")
