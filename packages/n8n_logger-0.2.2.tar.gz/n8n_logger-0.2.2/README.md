# n8n-logger

Logger Python com integração nativa com n8n.

## Instalação

```bash
pip install n8n-logger

requires-python = ">=3.7"
