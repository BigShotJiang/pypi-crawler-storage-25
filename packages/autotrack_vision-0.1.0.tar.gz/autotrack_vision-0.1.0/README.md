# AutoTrack Vision 👁️

A professional Python library for handling AI text extraction, cloud notifications, and transaction auditing in vehicle management systems.

## Installation

```bash
pip install autotrack-vision
```

## Quick Start

### 1. AI Text Extraction
```python
from autotrack_vision import VisionScanner

scanner = VisionScanner()
with open("invoice.jpg", "rb") as f:
    lines = scanner.scan_bytes(f.read())
    print(lines)
```

### 2. SNS Notifications
```python
from autotrack_vision import NotifyManager

notifier = NotifyManager(topic_arn="arn:aws:sns:us-east-1:xxxx:topic")
notifier.send_notification("Service is complete!")
```

## Requirements
- `boto3`
- AWS Credentials configured via Environment Variables or IAM Role.
