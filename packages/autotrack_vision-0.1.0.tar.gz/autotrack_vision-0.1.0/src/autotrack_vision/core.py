import boto3
from typing import List, Optional

class VisionScanner:
    """Helper for Amazon Textract OCR processing."""
    
    def __init__(self, session: Optional[boto3.Session] = None):
        self.client = (session or boto3.Session()).client('textract', region_name='us-east-1')

    def scan_bytes(self, image_bytes: bytes) -> List[str]:
        """Extracts text lines from image bytes."""
        response = self.client.detect_document_text(Document={'Bytes': image_bytes})
        return [item["Text"] for item in response.get("Blocks", []) if item["BlockType"] == "LINE"]

class NotifyManager:
    """Helper for Amazon SNS notifications."""

    def __init__(self, topic_arn: str, session: Optional[boto3.Session] = None):
        self.client = (session or boto3.Session()).client('sns', region_name='us-east-1')
        self.topic_arn = topic_arn

    def send_notification(self, message: str, subject: str = "AutoTrack Update"):
        """Publishes a message to the configured SNS topic."""
        return self.client.publish(
            TopicArn=self.topic_arn,
            Message=message,
            Subject=subject
        )

class AuditLogger:
    """Helper for DynamoDB transaction logging."""

    def __init__(self, table_name: str, session: Optional[boto3.Session] = None):
        dyn = (session or boto3.Session()).resource('dynamodb', region_name='us-east-1')
        self.table = dyn.Table(table_name)

    def log_event(self, item: dict):
        """Writes an audit entry to DynamoDB."""
        return self.table.put_item(Item=item)
