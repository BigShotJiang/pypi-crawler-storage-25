# t2json

`t2json` is a command-line tool that fetches detailed song credits from Tidal and exports them to Kid3-compatible JSON.

## Features

- Fetch credits from a track URL or track ID
- Fetch credits from album and playlist links
- Search by song name from the CLI
- Match local audio files and folders through ISRC tags
- Export structured JSON for Kid3 import
- Interactive terminal UI with settings, progress, and results
- Optional Last.fm genre lookup

## Installation

```bash
pip install t2json
```

## Quick start

```bash
t2json
```

You can also run it directly with a source:

```bash
t2json "song name"
t2json "https://tidal.com/browse/track/123456"
t2json "C:/Music/Album Folder"
```

## Output

The tool exports song metadata and credits to JSON, including fields such as:

- Title
- Artist
- Album Artist
- Album
- Date
- Genre
- ISRC
- Composer
- Lyricist
- Producer
- Mixing and mastering credits

## Notes

`t2json` fetches metadata only. It does not download or distribute audio.

This project is intended for personal and educational use. It is not affiliated with or endorsed by Tidal.

## Links

- GitHub: https://github.com/chetanbansode/t2json
- PyPI: https://pypi.org/project/t2json/
