import typer
from .signup import singup_app
from .login import login_app
from .logout import logout_app
from .whoami import whoami_app
from .serve import serve_app
from .module.resolve import resolve_module_app  
from .module.workload import workload_module_app


app = typer.Typer()
app.add_typer(login_app)
app.add_typer(logout_app)
app.add_typer(singup_app)
app.add_typer(whoami_app)
app.add_typer(serve_app)
app.add_typer(resolve_module_app, name="module")
app.add_typer(workload_module_app, name="module")