import os
import sys
import typer
import keyring
import importlib
from typing import Literal
from modulith import Modulith
from typing import Annotated, Optional
from modulith.utils.tunnels import start_tunnel
from modulith.server import create_fastapi_server
from modulith.mns.guest_signup import guest_signup
from modulith.mns.module.register import register_module
from modulith.utils.connections import wait_for_connection


def load_module(module_ref: str):
    variable_name = None
    if ":" in module_ref:
        module_ref, variable_name = module_ref.split(":")
    
    # Add the current working directory to sys.path if it's not already there
    if os.getcwd() not in sys.path:
        sys.path.insert(0, os.getcwd())
    
    mod = importlib.import_module(module_ref)
    if variable_name is None:
        for name in ("module", "app", "service", "tool"):
            if hasattr(mod, name):
                variable_name = name
                break

    if variable_name is None:
        raise ValueError(f"Module reference '{module_ref}' does not specify a variable name and no default variable ('module', 'app', 'service', or 'tool') was found. Please specify the variable name explicitly, e.g. '{module_ref}:variable_name'.")

    module = getattr(mod, variable_name)
    if isinstance(module, Modulith):
        return module
    
    raise ValueError(f"Module '{module_ref}' is not an instance of Modulith.")


serve_app = typer.Typer()
@serve_app.command("serve")
def serve_command(
    module_path: Annotated[
        str,
        typer.Argument(
            ...,
            help="Python module path, e.g. 'calculator.module'",
        ),
    ],
    port: Annotated[
        int,
        typer.Option("--port", help="Port to bind the server to."),
    ] = 8000,
    host: Annotated[
        str,
        typer.Option("--host", help="Host to bind the server to. Use 'localhost' for tunnel providers to work properly."),
    ] = "localhost",
    tunnel: Annotated[
        Optional[Literal["instatunnel", "cloudflare", "ngrok", "any"]],
        typer.Option("--tunnel", help="Tunnel provider to use for public exposure. Options: 'instatunnel', 'cloudflare', 'ngrok', 'any'. If not specified, the server will not be exposed publicly."),
    ] = "any",
    public: Annotated[
        bool,
        typer.Option("--public", help="Expose the module publicly."),
    ] = False,
    burst_limit: Annotated[
        Optional[int],
        typer.Option("--burst-limit", help="Maximum number of concurrent requests allowed for public access."),
    ] = None,
    rate_limit: Annotated[
        Optional[int],
        typer.Option("--rate-limit", help="Maximum number of requests per minute allowed for public access."),
    ] = None,
    max_queue_size: Annotated[
        int,
        typer.Option("--max-queue-size", help="Maximum number of requests to queue when the server is under heavy load. Requests beyond this limit will be rejected with a 503 error."),
    ] = 10000,
    num_workers: Annotated[
        Optional[int],
        typer.Option("--num-workers", help="Number of worker processes to handle requests. If not specified, it will default to the number of CPU cores."),
    ] = None,
    timeout: Annotated[
        Optional[float],
        typer.Option("--timeout", help="Maximum time in seconds to allow a request to be processed before timing out. If not specified, there will be no timeout."),
    ] = None,
    logging_path: Annotated[
        str,
        typer.Option("--logging-path", help="Path to the log file for the server. Logs will be rotated daily."),
    ] = "logs/server.log",
    auth_token: Annotated[
        Optional[str],
        typer.Option("--auth-token", help="Your authentication token. If not provided, a token will be generated and displayed in the console."),
    ] = None,
    no_tunnel: Annotated[
        bool,
        typer.Option("--no-tunnel", help="Do not establish a tunnel even if the --tunnel option is specified. This is useful for testing the server without exposing it publicly."),
    ] = False,
    skip_registration: Annotated[
        bool,
        typer.Option("--skip-registration", help="Skip registering the module to the Modulith Network Service."),
    ] = False,
):
    module: Modulith = load_module(module_path)

    local_url = f"http://{host}:{port}"
    thread = create_fastapi_server(
        module=module,
        host=host,
        port=port,
        auth_token=auth_token,
        public=public,
        burst_limit=burst_limit,
        rate_limit=rate_limit,
        max_queue_size=max_queue_size,
        num_workers=num_workers,
        timeout=timeout,
        logging_path=logging_path,
    )
    # Wait for server to be up
    if not wait_for_connection(local_url):
        raise RuntimeError(f"❌ Failed to start server at port {port}")
    
    public_url = None
    repository = None
    if not no_tunnel:
        typer.echo("🚀 Establishing tunnel...")
        tunnel_instance = start_tunnel(local_port=port, provider=tunnel)
        public_url = tunnel_instance.public_url
        
    guest_token = None
    if not skip_registration and public_url:
        typer.echo("🚀 Authenticating...")
        auth_token = auth_token or os.environ.get("MODULITH_API_TOKEN") or keyring.get_password("modulith", "api_key")
        if auth_token is None:
            auth_token = guest_signup()
            guest_token = auth_token

        typer.echo("🚀 Registering module...")
        repository = register_module(modulename=module.name, public_url=public_url, public=public, token=auth_token)

    if guest_token:
         typer.echo()
         typer.echo(f"🔑 Your authentication token: {guest_token}")

    typer.echo()
    typer.echo(f"🌐 Module '{module.name}' is live:")
    if repository:
        typer.echo(f"- Repository: {repository}")
    if public_url:
        typer.echo(f"- Public URL: {public_url}")
    typer.echo(f"- Local URL: {local_url}")
    typer.echo()

    typer.echo("⚙️ Capabilities:")
    for name, capability in module.capabilities.items():
        typer.echo(f"- {name}{capability.signature}")
    typer.echo()

    if public and (burst_limit or rate_limit):
        typer.echo("⚡ Public access limits:")
        if rate_limit:
            typer.echo(f"- Rate limit: {rate_limit} requests per minute")
        if burst_limit:
            typer.echo(f"- Burst limit: {burst_limit} concurrent requests")
        typer.echo()

    typer.echo("🛑 Press Ctrl+C to stop")

    try:
        while thread.is_alive():
            thread.join(timeout=1)
    except KeyboardInterrupt:
        print("🛑 Shutting down...")
        if tunnel_instance:
            tunnel_instance.stop()
        # TODO: deregister model from MNS
        # print("✅ Shutdown complete")