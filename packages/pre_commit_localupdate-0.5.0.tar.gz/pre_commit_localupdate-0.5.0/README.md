# pre-commit-localupdate

A CLI tool to automatically update dependencies in `pre-commit-config.yml` files. It specifically targets `additional_dependencies` within local hooks to ensure your tooling stays up-to-date. It also adds version to unversioned packages and pins exact version of loosely defined ones. You can also pin a specific package to an older version by adding a `# freeze` comment.

## Installation

```shell
pip install pre-commit-localupdate
```

## Usage

To check and update the `additional_dependencies` in your `.pre-commit-config.yaml` file, simply run:

```shell
pre-commit-localupdate
```

All options:

```text
usage: pre-commit-localupdate [-h] [--debug] [--dry-run] [-c PRE-COMMIT-CONFIG] [--timeout TIMEOUT]
                              [--indent-mapping INDENT_MAPPING] [--indent-sequence INDENT_SEQUENCE]
                              [--indent-offset INDENT_OFFSET] [--line-width LINE_WIDTH] [--version]

Automatically update additional dependencies within local hooks in a pre-commit config file.

options:
  -h, --help                         show this help message and exit
  --debug                            enable debug logging (default: False)
  --dry-run                          dry run mode. Do not update the file and exit with a non-zero code if the
                                     configuration file require an update. (default: False)
  -c, --config PRE-COMMIT-CONFIG     pre-commit config file path (default: .pre-commit-config.yaml)
  --timeout TIMEOUT                  connection timeout in seconds (default: 10)
  --indent-mapping INDENT_MAPPING    YAML indentation for mappings (default: 2)
  --indent-sequence INDENT_SEQUENCE  YAML indentation for sequences (default: 4)
  --indent-offset INDENT_OFFSET      YAML indentation offset (default: 2)
  --line-width LINE_WIDTH            maximum line width (default: 80)
  --version                          show program's version number and exit
```

## Example

Given a `.pre-commit-config.yaml` with the following content:

```yaml
# File header is preserved. If there is no document start marker (---), it won't be added
---
repos:
  # External hooks won't be touched. Use 'pre-commit autoupdate' command to update them
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v2.3.0
    hooks:
      - id: end-of-file-fixer
      - id: trailing-whitespace

  - repo: local
    hooks:
      # All comment are preserved
      - id: black
        name: black
        description: "Length of strings is automatically adjusted based on the value of --line-width"
        entry: black
        language: python
        minimum_pre_commit_version: 2.9.2
        require_serial: true
        types_or: [python, pyi]
        additional_dependencies:
          # Loose version definitions are pinned to an exact version
          - "black>=25.1.0"
          # Updates can be prevented by adding a 'freeze' comment to them as:
          - "white==0.1.0"  # freeze

      - id: julia-format
        name: format julia code
        description: Unicodeテキストは保持されます。
        language: julia
        types: [julia]
        entry: tools/formatter.jl
        additional_dependencies:
          # Double/single quoting style is preserved and version is added to packages with no version definition
          - 'JuliaFormatter'

      - id: mdbook-lint
        name: mdbook-lint
        description: rust package to lint markdown
        entry: mdbook-lint lint --fix
        language: rust
        types: [markdown]
        # Updating packages defined in flow style is also supported
        additional_dependencies: ["cli:mdbook-lint"]
```

Running `pre-commit-localupdate` will update the file to (hypothetical latest versions):

```yaml
# File header is preserved. If there is no document start marker (---), it won't be added
---
repos:
  # External hooks won't be touched. Use 'pre-commit autoupdate' command to update them
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v2.3.0
    hooks:
      - id: end-of-file-fixer
      - id: trailing-whitespace

  - repo: local
    hooks:
      # All comment are preserved
      - id: black
        name: black
        description: "Length of strings is automatically adjusted based on the value
          of --line-width"
        entry: black
        language: python
        minimum_pre_commit_version: 2.9.2
        require_serial: true
        types_or: [python, pyi]
        additional_dependencies:
          # Loose version definitions are pinned to an exact version
          - "black==26.1.0"
          # Updates can be prevented by adding a 'freeze' comment to them as:
          - "white==0.1.0"  # freeze

      - id: julia-format
        name: format julia code
        description: Unicodeテキストは保持されます。
        language: julia
        types: [julia]
        entry: tools/formatter.jl
        additional_dependencies:
          # Double/single quoting style is preserved and version is added to packages with no version definition
          - 'JuliaFormatter@2.3.0'

      - id: mdbook-lint
        name: mdbook-lint
        description: rust package to lint markdown
        entry: mdbook-lint lint --fix
        language: rust
        types: [markdown]
        # Updating packages defined in flow style is also supported
        additional_dependencies: ["cli:mdbook-lint:0.14.2"]
```

## Supported Languages

Following local hook languages are currently supported:

- Go (golang)
- Julia
- Node.js (node)
- Python
- Rust

## Formatting

Significant effort has been made to ensure `pre-commit-localupdate` maintains the original style and preserves comments in pre-commit configuration files. However, since the current version of the underlying library does not perfectly preserve the original YAML file format after processing, `pre-commit-localupdate` automatically folds long string values (like descriptions) and enforces block indentation by default when updating files to enhance readability. Both behaviors can be adjusted using command-line parameters.

## Requirements

- `packaging`
- `requests`
- `ruamel.yaml`

## License

- Copyright 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics (MPP)

All rights reserved.
This software may be modified and distributed under the terms of the GNU Lesser General Public License (LGPL). See the `LICENSE` file for details.
