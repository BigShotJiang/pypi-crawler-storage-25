# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import argparse
from pathlib import Path

from pre_commit_localupdate import __version__


def parse_args() -> argparse.Namespace:
    """Parse command line arguments.

    Returns:
        argparse.Namespace: Parsed arguments.
    """
    parser = argparse.ArgumentParser(
        description="Automatically update additional dependencies within local hooks in a pre-commit config file.",
        formatter_class=lambda prog: argparse.ArgumentDefaultsHelpFormatter(
            prog, max_help_position=40, width=120
        ),
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="enable debug logging",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="dry run mode. Do not update the file and exit with a non-zero code if the configuration file require an update.",
    )
    parser.add_argument(
        "-c",
        "--config",
        type=Path,
        help="pre-commit config file path",
        default=".pre-commit-config.yaml",
        metavar="PRE-COMMIT-CONFIG",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        help="connection timeout in seconds",
        default=10,
    )
    parser.add_argument(
        "--indent-mapping",
        type=int,
        help="YAML indentation for mappings",
        default=2,
    )
    parser.add_argument(
        "--indent-sequence",
        type=int,
        help="YAML indentation for sequences",
        default=4,
    )
    parser.add_argument(
        "--indent-offset",
        type=int,
        help="YAML indentation offset",
        default=2,
    )
    parser.add_argument(
        "--line-width",
        type=int,
        help="maximum line width",
        default=80,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"pre-commit-localupdate {__version__}",
    )
    return parser.parse_args()
