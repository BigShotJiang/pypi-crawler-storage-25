# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging
import re
from pathlib import Path

from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedSeq
from ruamel.yaml.error import YAMLError

from pre_commit_localupdate.error import PreCommitLocalUpdateError
from pre_commit_localupdate.io import YAMLFormat, load_config_file, save_config_file
from pre_commit_localupdate.packages import SUPPORTED_PACKAGES


def update_additional_dependencies(
    file_path: Path,
    connection_timeout: int,
    yaml_format: YAMLFormat,
    *,
    dry_run: bool = False,
) -> bool:
    """Reads the pre-commit configuration file, identifies outdated packages
    in local hooks, and updates them directly in the file.

    Preserves structure, quote styles, the document start marker (---),
    and comments preceding it.

    Args:
        file_path (Path): Path to the pre-commit configuration file.
        connection_timeout (int): Connection timeout in seconds.
        yaml_format (YAMLFormat): YAML file formatting parameters
        dry_run (bool): Do not update the pre-commit configuration file.

    Returns:
        bool: True if the dependencies needed updating, False otherwise.

    Raises:
        PreCommitLocalUpdateError: Error in parsing or updating pre-commit hooks

    """
    header_lines, yaml_content = load_config_file(file_path)

    logging.debug("Parsing YAML content...")

    yaml = YAML()
    yaml.preserve_quotes = True
    yaml.indent(
        mapping=yaml_format.indent_mapping,
        sequence=yaml_format.indent_sequence,
        offset=yaml_format.indent_offset,
    )
    yaml.default_flow_style = False
    yaml.width = yaml_format.line_width
    yaml.explicit_start = False
    yaml.allow_unicode = True
    try:
        config = yaml.load(yaml_content)
    except YAMLError as exc:
        raise PreCommitLocalUpdateError("Failed to parse YAML content.") from exc

    if config is None:
        raise PreCommitLocalUpdateError(
            "Configuration file is empty or could not be parsed.",
        )

    update_required = False
    FREEZE_PATTERN = re.compile(r"^#\s*freeze(\s|$)")

    if "repos" in config:
        logging.debug("Scanning repositories for local hooks")
        for repo in config.get("repos", []):
            if repo.get("repo") != "local":
                continue

            hooks = repo.get("hooks", [])
            for hook in hooks:
                hook_id = hook.get("id")
                logging.debug("Processing hook with ID: %s", hook_id)

                if hook.get("language") not in SUPPORTED_PACKAGES:
                    continue

                deps_list = hook.get("additional_dependencies")

                if not deps_list:
                    continue

                package_type = SUPPORTED_PACKAGES[hook.get("language")]

                for i, dep_str in enumerate(deps_list):

                    comment = None
                    if isinstance(deps_list, CommentedSeq):
                        comment = deps_list.ca.items.get(i, [None, None])[0]

                    if comment and hasattr(comment, "value"):
                        comment_text = comment.value.strip().lower()
                        if FREEZE_PATTERN.match(comment_text):
                            logging.debug("Skipping frozen dependency: %s", dep_str)
                            continue

                    logging.debug("Checking dependency: %s", dep_str)
                    clean_dep_str = dep_str.strip().strip('"').strip("'")
                    package = package_type.from_specification(clean_dep_str)
                    if not package:
                        logging.warning(
                            "Unsupported package specification: %s", dep_str
                        )
                        continue

                    package.fetch_latest_version(connection_timeout)
                    if not package.latest_version_specification():
                        continue

                    if (
                        package.latest_version_specification()
                        != package.original_version_specification()
                    ):
                        logging.debug(
                            "%s needs updating to %s",
                            package.original_version_specification(),
                            package.latest_version_specification(),
                        )
                        hook["additional_dependencies"][
                            i
                        ] = package.latest_version_specification()

                        update_required = True
                    else:
                        logging.debug(
                            "%s is already correctly defined and up to date (%s).",
                            package.name,
                            package.original_version_specification(),
                        )
    else:
        raise PreCommitLocalUpdateError("Failed to parse pre-commit hooks!")

    if update_required:
        if not dry_run:
            save_config_file(file_path, config, header_lines, yaml)
        return True

    return False
