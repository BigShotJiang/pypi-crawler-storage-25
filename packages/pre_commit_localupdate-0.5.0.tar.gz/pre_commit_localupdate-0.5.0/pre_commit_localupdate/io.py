# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import io
import logging
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path

from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap

from pre_commit_localupdate.error import PreCommitLocalUpdateError


@dataclass(frozen=True)
class YAMLFormat:
    """Configuration for YAML file formatting parameters.

    Attributes:
        indent_mapping (int): YAML indentation for mappings
        indent_sequence (int): YAML indentation for sequences
        indent_offset (int): YAML indentation offset
        line_width (int): maximum line width

    """

    indent_mapping: int
    indent_sequence: int
    indent_offset: int
    line_width: int


def load_config_file(file_path: Path) -> tuple[list[str], str]:
    """Reads pre-commit configuration file and returns its header lines and content.

    Args:
        file_path (Path): Path to config file

    Returns:
        tuple[list[str], str]: Header lines, config file content

    Raises:
        PreCommitLocalUpdateError: Error in reading config file
    """
    logging.debug("Reading configuration file: %s", file_path)

    try:
        file_content = file_path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise PreCommitLocalUpdateError(f"File not found: {file_path}") from exc
    except OSError as exc:
        raise PreCommitLocalUpdateError(
            f"IOError while reading file {file_path}"
        ) from exc

    raw_lines = file_content.splitlines(keepends=True)

    content_start_index = 0
    for i, line in enumerate(raw_lines):
        stripped = line.strip()
        if stripped == "---":
            logging.debug("YAML marker found.")
            content_start_index = i + 1
            break
        if stripped and not stripped.startswith("#"):
            content_start_index = i
            break

    header_lines = raw_lines[:content_start_index]
    content = "".join(raw_lines[content_start_index:])

    return header_lines, content


def save_config_file(
    file_path: Path,
    config: CommentedMap,
    header_lines: list[str],
    yaml_dumper: YAML,
) -> None:
    """Writes pre-commit configuration file.

    Args:
        file_path (Path): Path to config file
        config (CommentedMap): Config file content
        header_lines (list[str]): File header lines
        yaml_dumper (YAML): YAML dumper

    Raises:
        PreCommitLocalUpdateError: Error in writing config file
    """

    logging.debug("Writing modifications to disk...")
    stream = io.StringIO()
    yaml_dumper.dump(config, stream)
    modified_body = stream.getvalue()
    final_content = "".join(header_lines) + modified_body

    temp_file_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=file_path.parent,
            delete=False,
        ) as temp_file:
            temp_file.write(final_content)
            os.fsync(temp_file.fileno())
            temp_file_path = temp_file.name

        os.replace(temp_file_path, file_path)
        logging.info("Successfully updated %s", file_path)

    except OSError as exc:
        if temp_file_path and os.path.exists(temp_file_path):
            os.unlink(temp_file_path)
        raise PreCommitLocalUpdateError(
            f"IOError while writing to file {file_path}"
        ) from exc
