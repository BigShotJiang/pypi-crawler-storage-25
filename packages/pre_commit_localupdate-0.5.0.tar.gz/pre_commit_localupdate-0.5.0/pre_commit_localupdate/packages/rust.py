# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging
import re
from dataclasses import dataclass

import requests

from .package import PackageBase

CRATES_API_URL = "https://crates.io/api/v1/crates/{package_name}"


@dataclass
class RustPackage(PackageBase):
    """Represents a Rust package.

    Attributes:
        cli (bool): Package is a CLI tool.
    """

    cli: bool = False

    @classmethod
    def from_specification(cls, spec: str) -> "RustPackage" | None:
        """Parse a package specification string into a Package object.

        Supported formats:
        - `package`
        - `package:1.2.3`
        - `cli:package:1.2.3`

        Args:
            spec (str): The package specification string (without quotations).

        Returns:
            "RustPackage" | None: A Package instance if parsing succeeds, otherwise None.

        """
        match = re.match(
            r"^(?:(?P<cli>cli):)?(?P<name>[a-zA-Z0-9_-]+)(?::(?P<version>[^:]+))?$",
            spec,
        )
        if not match:
            return None

        name = match.group("name")
        version = match.group("version")
        cli = bool(match.group("cli"))

        raw_spec = f":{version}" if version else None

        return cls(name=name, raw_spec=raw_spec, cli=cli)

    def fetch_latest_version(self, connection_timeout: int) -> None:
        """Fetch the latest version of a package from crates.io.

        Args:
            connection_timeout (int): Connection timeout in seconds.
        """
        logging.debug("Fetching latest version for %s", self.name)
        try:
            url = CRATES_API_URL.format(package_name=self.name)
            response = requests.get(url, timeout=connection_timeout)
            response.raise_for_status()
            data = response.json()
            latest_version = data.get("crate", {}).get("max_version")
            if isinstance(latest_version, str):
                self.latest_version = latest_version

        except requests.exceptions.RequestException as exc:
            logging.warning("Could not fetch latest version for %s: %s", self.name, exc)
        except (KeyError, ValueError) as exc:
            logging.warning("Could not parse response for %s: %s", self.name, exc)

    def latest_version_specification(self) -> str | None:
        """Version specification of package pinned to the latest version.

        Returns:
            str | None: The latest version specification string if found, otherwise None.

        """
        if not self.latest_version:
            return None
        if self.cli:
            return f"cli:{self.name}:{self.latest_version}"
        else:
            return f"{self.name}:{self.latest_version}"
