# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging

import requests
from packaging.requirements import InvalidRequirement, Requirement

from .package import PackageBase

PYPI_API_URL = "https://pypi.org/pypi/{package_name}/json"


class PyPackage(PackageBase):
    """Represents a Python package."""

    @classmethod
    def from_specification(cls, spec: str) -> "PyPackage" | None:
        """Parse a package specification string into a Package object.

        Supported formats (and other specifications in PEP 508):
        - `package`
        - `package==1.2.3`
        - `package>=1.2.3`

        Args:
            spec (str): The package specification string (without quotations).

        Returns:
            "PyPackage" | None: A Package instance if parsing succeeds, otherwise None.

        """

        try:
            requirement = Requirement(spec)
        except InvalidRequirement:
            return None

        name = requirement.name
        raw_spec = str(requirement.specifier) if requirement.specifier else None

        return cls(
            name=name,
            raw_spec=raw_spec,
        )

    def fetch_latest_version(self, connection_timeout: int) -> None:
        """Fetch the latest version of a package from PyPI.

        Args:
            connection_timeout (int): Connection timeout in seconds.

        """
        logging.debug("Fetching latest version for %s", self.name)
        try:
            url = PYPI_API_URL.format(package_name=self.name)
            response = requests.get(url, timeout=connection_timeout)
            response.raise_for_status()
            data = response.json()
            latest_version = data.get("info", {}).get("version")
            if isinstance(latest_version, str):
                self.latest_version = latest_version

        except requests.exceptions.RequestException as exc:
            logging.warning("Could not fetch latest version for %s: %s", self.name, exc)
        except (KeyError, ValueError) as exc:
            logging.warning("Could not parse response for %s: %s", self.name, exc)

    def latest_version_specification(self) -> str | None:
        """Version specification of package pinned to the latest version.

        Returns:
            str | None: The latest version specification string if found, otherwise None.

        """
        if not self.latest_version:
            return None

        return f"{self.name}=={self.latest_version}"
