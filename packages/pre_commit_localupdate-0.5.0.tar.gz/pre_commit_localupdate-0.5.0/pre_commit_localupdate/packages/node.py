# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging
import re

import requests

from .package import PackageBase

NPM_API_URL = "https://registry.npmjs.org/{package_name}"


class NodePackage(PackageBase):
    """Represents a Node.js package."""

    @classmethod
    def from_specification(cls, spec: str) -> "NodePackage" | None:
        """Parse a package specification string into a NodePackage object.

        Supported formats:
        - `package`
        - `package@1.2.3`
        - `package@>=1.2.3`
        - `@scope/name@^1.2.3`

        Args:
            spec (str): The package specification string (without quotations).

        Returns:
            "NodePackage" | None: A NodePackage instance if parsing succeeds, otherwise None.

        """

        if not spec:
            return None

        # (@scope/name|name)(@version)?
        match = re.match(r"^(?P<name>(?:@[^/]+\/)?[^@]+?)(?:@(?P<spec>.*))?$", spec)
        if not match:
            return None

        name = match.group("name")
        raw_spec = match.group("spec")

        if not name:
            return None

        return cls(
            name=name,
            raw_spec=raw_spec,
        )

    def fetch_latest_version(self, connection_timeout: int) -> None:
        """Fetch the latest version of a package from the npm registry.

        Args:
            connection_timeout (int): Connection timeout in seconds.
        """
        try:
            url = NPM_API_URL.format(package_name=self.name)
            response = requests.get(url, timeout=connection_timeout)
            response.raise_for_status()
            data = response.json()

            latest_version = data.get("dist-tags", {}).get("latest")
            if isinstance(latest_version, str):
                self.latest_version = latest_version

        except requests.exceptions.RequestException as exc:
            logging.warning("Could not fetch latest version for %s: %s", self.name, exc)
        except (KeyError, ValueError) as exc:
            logging.warning("Could not parse response for %s: %s", self.name, exc)

    def latest_version_specification(self) -> str | None:
        """Version specification of package pinned to the latest version.

        Returns:
            str | None: The latest version specification string if found, otherwise None.

        """
        if not self.latest_version:
            return None

        return f"{self.name}@{self.latest_version}"
