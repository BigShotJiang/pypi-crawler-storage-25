# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging
import re

import requests

from .package import PackageBase

# Go Proxy API endpoints
GO_PKG_LATEST_VERSION_API_URL = "https://proxy.golang.org/{package_path}/@latest"


class GoPackage(PackageBase):
    """Represents a Go module."""

    @classmethod
    def from_specification(cls, spec: str) -> "GoPackage" | None:
        """Parse a Go module specification string into a Package object.

        Supported formats:
        - `mvdan.cc/sh` (Module path only)
        - `mvdan.cc/sh@v1.3.0` (Module path with specific version)
        - `mvdan.cc/sh/v3` (Module path with major version suffix)
        - `mvdan.cc/sh/v3@v3.10.0` (Major suffix with version)
        - `mvdan.cc/sh/v3/cmd/shfmt` (Submodule)
        - `mvdan.cc/sh/v3/cmd/shfmt@v3.10.0` (Submodule with version)

        Args:
            spec (str): The package specification string (without quotations).

        Returns:
            "GoPackage" | None: A Package instance if parsing succeeds, otherwise None.
        """

        match = re.match(r"^([a-zA-Z0-9._/-]+)(@.+)?$", spec)

        if not match:
            return None

        name = match.group(1)
        raw_spec = match.group(2)

        return cls(
            name=name,
            raw_spec=raw_spec,
        )

    @staticmethod
    def _resolve_module_path(package_path: str) -> str:
        """
        Resolve a submodule path to a module path.

        If the path contains a major version suffix (e.g., /v2, /v3) followed by
        additional path segments, it trims the path at the suffix.

        Args:
            package_path (str): The full submodule path.

        Returns:
            str: The resolved module path.
        """

        match = re.search(r"/v([2-9]|[1-9][0-9]+)(?=/)", package_path)

        if match:
            return package_path[: match.end()]

        return package_path

    def fetch_latest_version(self, connection_timeout: int) -> None:
        """Fetch the latest version of a Go module from proxy.golang.org.

        Args:
            connection_timeout (int): Connection timeout in seconds.
        """
        package_path = self._resolve_module_path(self.name)
        logging.debug("Fetching latest version for %s", package_path)
        try:
            url = GO_PKG_LATEST_VERSION_API_URL.format(package_path=package_path)

            response = requests.get(url, timeout=connection_timeout)
            response.raise_for_status()

            data = response.json()
            latest_version = data.get("Version")

            if isinstance(latest_version, str):
                self.latest_version = latest_version

        except requests.exceptions.RequestException as exc:
            logging.warning(
                "Could not fetch latest version for %s: %s", package_path, exc
            )
        except (KeyError, ValueError) as exc:
            logging.warning("Could not parse response for %s: %s", package_path, exc)

    def latest_version_specification(self) -> str | None:
        """Version specification of package pinned to the latest version.

        Returns:
            str | None: The latest version specification string if found, otherwise None.
        """
        if not self.latest_version:
            return None

        return f"{self.name}@{self.latest_version}"
