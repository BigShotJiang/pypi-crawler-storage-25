# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class PackageBase(ABC):
    """Abstract base class defining the interface for all package types.

    Attributes:
        name (str): The name of the package (e.g., 'requests').
        raw_spec (str | None): The original version specifier string (e.g., '==1.2.3', '^1.2.3', '>=1.2.3', '@1.2.3').
        latest_version (str | None): Latest version number without operators (e.g., '1.2.3').

    """

    name: str
    raw_spec: str | None
    latest_version: str | None = None

    @classmethod
    @abstractmethod
    def from_specification(
        cls,
        spec_string: str,
    ) -> "PackageBase" | None:
        """Parse a package specification string into a Package object.

        Args:
            spec_string (str): The package specification string (without quotations).

        Returns:
            "PackageBase" | None: A Package instance if parsing succeeds, otherwise None.
        """

    @abstractmethod
    def fetch_latest_version(self, connection_timeout: int) -> None:
        """Get latest package version and set self.latest_version

        Args:
            connection_timeout (int): Connection timeout in seconds.
        """

    @abstractmethod
    def latest_version_specification(self) -> str | None:
        """Version specification of package pinned to the latest version.

        Returns:
            str | None: The latest version specification string if found, otherwise None.
        """

    def original_version_specification(self) -> str | None:
        """Version specification of package as originally defined.

        Returns:
            str | None: The version specification string.

        """
        if self.raw_spec:
            return f"{self.name}{self.raw_spec}"
        return f"{self.name}"
