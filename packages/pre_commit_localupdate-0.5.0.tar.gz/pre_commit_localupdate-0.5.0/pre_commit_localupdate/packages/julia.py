# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging
import re
import tomllib
from dataclasses import dataclass

import requests
from packaging.version import InvalidVersion, Version

from .package import PackageBase

# Julia General Registry Source
JULIA_PKG_API_URL = "https://raw.githubusercontent.com/JuliaRegistries/General/refs/heads/master/{package_name_first_letter}/{package_name}/Versions.toml"


@dataclass
class JuliaPackage(PackageBase):
    """Represents a Julia package.

    Attributes:
        uuid (str): Package UUID [not validated]
    """

    uuid: str = ""

    @classmethod
    def from_specification(cls, spec: str) -> "JuliaPackage" | None:
        """Parse a package specification string into a Package object.

        Supported formats:
        - `package`
        - `package@1.2.3`
        - `package=2edaba10-b0f1-5616-af89-8c11ac63239a`
        - `package=2edaba10-b0f1-5616-af89-8c11ac63239a@1.2`

        Args:
            spec (str): The package specification string (without quotations).

        Returns:
            "JuliaPackage" | None: A Package instance if parsing succeeds, otherwise None.

        """

        pattern = re.compile(
            r"^(?P<name>[a-zA-Z0-9_]+)"
            r"(?:=(?P<uuid>[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}))?"
            r"(?:@(?P<version>[a-zA-Z0-9._+,-]+))?$"
        )

        match = pattern.match(spec)

        if not match:
            return None

        name = match.group("name")
        uuid = match.group("uuid")
        version = match.group("version")

        raw_spec = None
        if uuid:
            raw_spec = f"={uuid}@{version}" if version else f"={uuid}"
        elif version:
            raw_spec = f"@{version}"

        return cls(
            name=name,
            raw_spec=raw_spec,
            uuid=uuid,
        )

    def fetch_latest_version(self, connection_timeout: int) -> None:
        """Fetch the latest version of a package from the Julia General Registry.

        Args:
            connection_timeout (int): Connection timeout in seconds.
        """
        logging.debug("Fetching latest version for %s", self.name)
        try:
            url = JULIA_PKG_API_URL.format(
                package_name=self.name, package_name_first_letter=self.name[0]
            )
            response = requests.get(url, timeout=connection_timeout)
            response.raise_for_status()

            data = tomllib.loads(response.text)

            versions = list(data.keys())
            if versions:
                versions.sort(key=lambda v: Version(v), reverse=True)
                self.latest_version = versions[0]

        except requests.exceptions.RequestException as exc:
            logging.warning("Could not fetch latest version for %s: %s", self.name, exc)
        except (KeyError, ValueError, tomllib.TOMLDecodeError, InvalidVersion) as exc:
            logging.warning("Could not parse response for %s: %s", self.name, exc)

    def latest_version_specification(self) -> str | None:
        """Version specification of package pinned to the latest version.

        Returns:
            str | None: The latest version specification string if found, otherwise None.
            Format: PackageName@version

        """
        if not self.latest_version:
            return None
        if self.uuid:
            return f"{self.name}={self.uuid}@{self.latest_version}"
        return f"{self.name}@{self.latest_version}"
