import asyncio
import traceback
from datetime import timedelta
from .auth import auth
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from functools import wraps
from .caspian_config import get_files_index
from typing import Optional, Any, Union
import inspect
import os
import json
import hmac
import dataclasses
from datetime import datetime, date
import time
from collections import defaultdict
import re
import math
from .streaming import SSE

RPC_REGISTRY = {}
RPC_META = {}

CORS_ALLOWED_ORIGINS = os.getenv('CORS_ALLOWED_ORIGINS', '').split(
    ',') if os.getenv('CORS_ALLOWED_ORIGINS') else None
IS_PRODUCTION = os.getenv('APP_ENV') == 'production'
_PUBLIC_BASE_URL_ENV_NAMES = (
    'APP_BASE_URL',
    'PUBLIC_BASE_URL',
    'SITE_URL',
)
_ALLOWED_FORWARDED_SCHEMES = {'http', 'https', 'ws', 'wss'}

# ==== GLOBAL DEFAULTS FROM .ENV ====
RATE_LIMIT_DEFAULT = os.getenv('RATE_LIMIT_DEFAULT', '200/minute')
RATE_LIMIT_RPC = os.getenv('RATE_LIMIT_RPC', '60/minute')
RATE_LIMIT_AUTH = os.getenv('RATE_LIMIT_AUTH', '60/minute')

limiter = Limiter(key_func=get_remote_address,
                  default_limits=[RATE_LIMIT_DEFAULT])

# ==== RATE LIMITER LOGIC ====


class RPCRateLimiter:
    MAX_BUCKETS = int(os.getenv('RATE_LIMIT_MAX_BUCKETS', '10000'))
    CLEANUP_INTERVAL_SECONDS = int(
        os.getenv('RATE_LIMIT_CLEANUP_INTERVAL', '60'))

    def __init__(self):
        self._storage = defaultdict(lambda: defaultdict(list))
        self._last_cleanup = 0.0

    def _parse_window(self, period_str: str) -> int:
        period_str = period_str.lower().strip()
        if period_str in ['second', 'sec', 's']:
            return 1
        if period_str in ['minute', 'min', 'm']:
            return 60
        if period_str in ['hour', 'h']:
            return 3600
        if period_str in ['day', 'd']:
            return 86400

        match = re.match(r'(\d+)\s*([a-zA-Z]+)', period_str)
        if match:
            value, unit = match.groups()
            value = int(value)
            if unit.startswith('d'):
                return value * 86400
            if unit.startswith('h'):
                return value * 3600
            if unit.startswith('m'):
                return value * 60
            if unit.startswith('s'):
                return value
        return 60

    def _cleanup(self, now: float, window_seconds: int) -> None:
        if now - self._last_cleanup < self.CLEANUP_INTERVAL_SECONDS:
            return

        self._last_cleanup = now
        window_start = now - window_seconds
        bucket_count = 0

        for func_key in list(self._storage.keys()):
            ip_map = self._storage[func_key]
            for ip in list(ip_map.keys()):
                valid_history = [t for t in ip_map[ip] if t > window_start]
                if valid_history:
                    ip_map[ip] = valid_history
                    bucket_count += 1
                else:
                    del ip_map[ip]

            if not ip_map:
                del self._storage[func_key]

        if bucket_count <= self.MAX_BUCKETS:
            return

        overflow = bucket_count - self.MAX_BUCKETS
        for func_key in list(self._storage.keys()):
            ip_map = self._storage[func_key]
            for ip in list(ip_map.keys()):
                del ip_map[ip]
                overflow -= 1
                if overflow <= 0:
                    break
            if not ip_map:
                del self._storage[func_key]
            if overflow <= 0:
                break

    def check(self, func_key: str, ip: str, limit_str: str) -> tuple[bool, float]:
        if not limit_str:
            return True, 0.0
        try:
            parts = limit_str.split('/')
            if len(parts) != 2:
                return True, 0.0

            limit_count = int(parts[0])
            window_seconds = self._parse_window(parts[1])

            now = time.time()
            window_start = now - window_seconds
            self._cleanup(now, window_seconds)

            user_history = self._storage[func_key][ip]
            valid_history = [t for t in user_history if t > window_start]

            if len(valid_history) >= limit_count:
                self._storage[func_key][ip] = valid_history
                oldest_request_time = valid_history[0]
                next_slot_time = oldest_request_time + window_seconds
                wait_time = max(1.0, next_slot_time - now)
                return False, wait_time

            valid_history.append(now)
            self._storage[func_key][ip] = valid_history
            return True, 0.0

        except Exception as e:
            print(f"[RateLimit] Error: {e}")
            return True, 0.0


rpc_limiter = RPCRateLimiter()

# ==== SERIALIZATION ====


def _serialize_result(obj: Any) -> Any:
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, (list, tuple)):
        return [_serialize_result(item) for item in obj]
    if isinstance(obj, dict):
        return {k: _serialize_result(v) for k, v in obj.items()}
    to_dict = getattr(obj, 'to_dict', None)
    if callable(to_dict):
        return _serialize_result(to_dict())
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {k: _serialize_result(v) for k, v in dataclasses.asdict(obj).items()}
    model_dump = getattr(obj, 'model_dump', None)
    if callable(model_dump):
        return model_dump()
    obj_dict = getattr(obj, '__dict__', None)
    if obj_dict is not None:
        return {k: _serialize_result(v) for k, v in obj_dict.items()}
    return str(obj)


def _filepath_to_route(filepath: str) -> Optional[str]:
    files_index = get_files_index()
    filepath = filepath.replace('\\', '/')

    for route_entry in files_index.routes:
        if route_entry.fs_dir:
            pattern = f'/src/app/{route_entry.fs_dir}/index.py'
            if filepath.endswith(pattern) or pattern in filepath:
                return route_entry.url_path

    if filepath.endswith('/src/app/index.py'):
        return '/'

    return None

# ==== DECORATOR ====


def rpc(require_auth: bool = False,
        allowed_roles: Optional[list[str]] = None,
        limits: Optional[Union[str, list[str]]] = None):
    """
    Decorator for RPC functions.

    Behavior:
    - If defined in a Page (index.py), it is scoped to that page's URL.
    - If defined in a Component, it is registered Globally (by function name).

    Rate Limit Hierarchy:
    1. Explicit 'limits' arg passed to decorator (e.g. "20/1h")
    2. If require_auth=True -> RATE_LIMIT_AUTH from .env
    3. Default -> RATE_LIMIT_RPC from .env
    """

    def decorator(func):
        frame = inspect.stack()[1]
        filepath = frame.filename
        route = _filepath_to_route(filepath)

        final_limits = []
        if limits:
            if isinstance(limits, str):
                final_limits = [limits]
            else:
                final_limits = limits
        else:
            if require_auth and RATE_LIMIT_AUTH:
                final_limits = [RATE_LIMIT_AUTH]
            elif RATE_LIMIT_RPC:
                final_limits = [RATE_LIMIT_RPC]

        if route is not None:
            key = f"{route}:{func.__name__}"
            rpc_route_meta = route
        else:
            key = func.__name__
            rpc_route_meta = "__GLOBAL__"

        RPC_REGISTRY[key] = func
        RPC_META[key] = {
            'require_auth': require_auth,
            'allowed_roles': allowed_roles or [],
            'limits': final_limits,
            'route': rpc_route_meta
        }

        @wraps(func)
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper
    return decorator

# ==== VALIDATION HELPERS ====


def _normalize_origin_value(value: str) -> str:
    return (value or '').strip().rstrip('/')


def _optional_env(name: str) -> str:
    value = os.getenv(name)
    if value is None:
        return ''
    return value.strip()


def _public_base_url_override() -> str:
    for env_name in _PUBLIC_BASE_URL_ENV_NAMES:
        base_url = _normalize_origin_value(_optional_env(env_name))
        if base_url:
            return base_url
    return ''


def _first_header_value(raw_value: str) -> str:
    if not raw_value:
        return ''
    return raw_value.split(',', 1)[0].strip()


def _strip_optional_quotes(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] == '"':
        return value[1:-1]
    return value


def _parse_forwarded_header(raw_value: str) -> dict[str, str]:
    first_value = _first_header_value(raw_value)
    if not first_value:
        return {}

    forwarded_values: dict[str, str] = {}
    for item in first_value.split(';'):
        key, separator, value = item.partition('=')
        if not separator:
            continue
        normalized_key = key.strip().lower()
        normalized_value = _strip_optional_quotes(value.strip())
        if normalized_key and normalized_value:
            forwarded_values[normalized_key] = normalized_value
    return forwarded_values


def _default_port_for_scheme(scheme: str) -> Optional[int]:
    if scheme in {'https', 'wss'}:
        return 443
    if scheme in {'http', 'ws'}:
        return 80
    return None


def _host_includes_port(host: str) -> bool:
    if not host:
        return False
    if host.startswith('['):
        return ']:' in host
    return host.count(':') == 1


def _host_with_forwarded_port(host: str, port: str, scheme: str) -> str:
    normalized_host = host.strip()
    normalized_port = port.strip()
    if not normalized_host or not normalized_port.isdigit() or _host_includes_port(normalized_host):
        return normalized_host

    default_port = _default_port_for_scheme(scheme)
    if default_port is not None and int(normalized_port) == default_port:
        return normalized_host

    return f'{normalized_host}:{normalized_port}'


def _forwarded_origin(request: Request) -> str:
    forwarded_values = _parse_forwarded_header(
        request.headers.get('forwarded', '')
    )
    forwarded_scheme = _normalize_origin_value(
        _first_header_value(request.headers.get('x-forwarded-proto', ''))
    ).lower()
    if forwarded_scheme not in _ALLOWED_FORWARDED_SCHEMES:
        forwarded_scheme = _normalize_origin_value(
            forwarded_values.get('proto', '')
        ).lower()

    if forwarded_scheme not in _ALLOWED_FORWARDED_SCHEMES:
        forwarded_scheme = _normalize_origin_value(
            str(request.url.scheme)).lower() or 'http'

    forwarded_host = _first_header_value(
        request.headers.get('x-forwarded-host', '')
    ).strip() or forwarded_values.get('host', '').strip()
    if not forwarded_host:
        return ''

    forwarded_port = _first_header_value(
        request.headers.get('x-forwarded-port', ''))
    return _normalize_origin_value(
        f"{forwarded_scheme}://{_host_with_forwarded_port(forwarded_host, forwarded_port, forwarded_scheme)}"
    )


def _allowed_request_origins(request: Request) -> set[str]:
    allowed_origins = {
        origin
        for origin in (
            _normalize_origin_value(str(request.base_url)),
            _public_base_url_override(),
            _forwarded_origin(request),
        )
        if origin
    }

    if CORS_ALLOWED_ORIGINS:
        allowed_origins.update(
            _normalize_origin_value(origin)
            for origin in CORS_ALLOWED_ORIGINS
            if _normalize_origin_value(origin)
        )

    return allowed_origins


def _validate_origin(request: Request) -> Optional[JSONResponse]:
    origin = _normalize_origin_value(request.headers.get('Origin', ''))
    if not origin:
        return None
    if not IS_PRODUCTION:
        if origin.startswith(('http://localhost:', 'http://127.0.0.1:')):
            return None
    if origin not in _allowed_request_origins(request):
        return JSONResponse({'error': 'Invalid origin'}, status_code=403)
    return None


def _validate_csrf(request: Request, session: dict) -> Optional[JSONResponse]:
    csrf_header = request.headers.get('X-CSRF-Token')
    session_token = session.get('csrf_token')
    if not csrf_header or not session_token:
        return JSONResponse({'error': 'Missing CSRF token'}, status_code=403)
    if not hmac.compare_digest(csrf_header, session_token):
        return JSONResponse({'error': 'Invalid CSRF token'}, status_code=403)
    return None


def _validate_content_type(request: Request) -> Optional[JSONResponse]:
    content_type = request.headers.get('content-type', '')
    if not content_type.startswith(('application/json', 'multipart/form-data')):
        content_length = request.headers.get('content-length')
        if content_length and int(content_length) > 0:
            return JSONResponse({'error': 'Invalid content type'}, status_code=415)
    return None


def _normalize_route_path(route: str) -> str:
    return ('/' + route.strip('/')).rstrip('/') or '/'


def _split_route_segments(route: str) -> list[str]:
    normalized = _normalize_route_path(route)
    if normalized == '/':
        return []
    return normalized.strip('/').split('/')


def _is_optional_catch_all_segment(segment: str) -> bool:
    return segment.startswith('[[...') and segment.endswith(']]') and len(segment) > 7


def _is_catch_all_segment(segment: str) -> bool:
    return segment.startswith('[...') and segment.endswith(']') and len(segment) > 5


def _is_dynamic_segment(segment: str) -> bool:
    if _is_optional_catch_all_segment(segment) or _is_catch_all_segment(segment):
        return False
    return segment.startswith('[') and segment.endswith(']') and len(segment) > 2


def _is_fastapi_path_segment(segment: str) -> bool:
    return segment.startswith('{') and segment.endswith('}') and segment.endswith(':path}')


def _is_fastapi_dynamic_segment(segment: str) -> bool:
    return segment.startswith('{') and segment.endswith('}') and len(segment) > 2


def _route_pattern_to_regex(route_pattern: str) -> re.Pattern:
    normalized = _normalize_route_path(route_pattern)
    if normalized == '/':
        return re.compile(r'^/$')

    regex_parts = ['^']
    for segment in _split_route_segments(normalized):
        if _is_optional_catch_all_segment(segment):
            regex_parts.append(r'(?:/.*)?')
        elif _is_catch_all_segment(segment) or _is_fastapi_path_segment(segment):
            regex_parts.append(r'/.+')
        elif _is_dynamic_segment(segment) or _is_fastapi_dynamic_segment(segment):
            regex_parts.append(r'/[^/]+')
        else:
            regex_parts.append('/' + re.escape(segment))

    regex_parts.append('$')
    return re.compile(''.join(regex_parts))


def _route_pattern_matches_request(route_pattern: str, request_path: str) -> bool:
    normalized_pattern = _normalize_route_path(route_pattern)
    normalized_request = _normalize_route_path(request_path)

    if normalized_pattern == normalized_request:
        return True

    return bool(_route_pattern_to_regex(normalized_pattern).fullmatch(normalized_request))


def _route_specificity(route_pattern: str) -> tuple[int, int, int, int]:
    static_count = 0
    dynamic_count = 0
    catch_all_count = 0

    for segment in _split_route_segments(route_pattern):
        if _is_optional_catch_all_segment(segment) or _is_catch_all_segment(segment) or _is_fastapi_path_segment(segment):
            catch_all_count += 1
        elif _is_dynamic_segment(segment) or _is_fastapi_dynamic_segment(segment):
            dynamic_count += 1
        else:
            static_count += 1

    return (static_count, -catch_all_count, -dynamic_count, len(_split_route_segments(route_pattern)))


def _get_registry_key(route: str, func_name: str) -> Optional[str]:
    route = _normalize_route_path(route)
    key = f"{route}:{func_name}"
    if key in RPC_REGISTRY:
        return key

    best_key = None
    best_score = None
    scoped_suffix = f":{func_name}"

    for candidate_key in RPC_REGISTRY:
        if not candidate_key.endswith(scoped_suffix):
            continue

        candidate_route = candidate_key[:-len(scoped_suffix)]
        if not _route_pattern_matches_request(candidate_route, route):
            continue

        score = _route_specificity(candidate_route)
        if best_score is None or score > best_score:
            best_key = candidate_key
            best_score = score

    if best_key is not None:
        return best_key

    if func_name in RPC_REGISTRY:
        return func_name
    return None

# ==== MAIN RPC HANDLER ====


async def _handle_rpc_request(request: Request, session: dict) -> Response:
    func_name = request.headers.get('X-PP-Function')
    if not func_name:
        return JSONResponse({'error': 'Missing function name'}, status_code=400)

    route = request.url.path.rstrip('/') or '/'
    registry_key = _get_registry_key(route, func_name)
    if not registry_key:
        return JSONResponse({'error': 'Function not found'}, status_code=404)

    if error := _validate_origin(request):
        return error
    if error := _validate_content_type(request):
        return error
    if error := _validate_csrf(request, session):
        return error

    meta = RPC_META.get(registry_key, {})

    if meta.get('require_auth') and not auth.is_authenticated():
        return JSONResponse({'error': 'Authentication required'}, status_code=401)

    allowed_roles = meta.get('allowed_roles', [])
    if allowed_roles:
        user = auth.get_payload()
        if not auth.check_role(user, allowed_roles):
            return JSONResponse({'error': 'Permission denied'}, status_code=403)

    # Rate Limits
    rpc_limits = meta.get('limits', [])
    if rpc_limits:
        client_ip = request.client.host if request.client else "unknown"
        for limit_rule in rpc_limits:
            is_allowed, wait_seconds = rpc_limiter.check(
                registry_key, client_ip, limit_rule)
            if not is_allowed:
                return JSONResponse({
                    'error': f'Rate limit exceeded. Try again in {math.ceil(wait_seconds)} seconds.'
                }, status_code=429)

    # Input Parsing
    content_type = request.headers.get('content-type', '')
    if content_type.startswith('multipart/form-data'):
        form = await request.form()
        data: dict[str, Any] = {}
        for key in form:
            value = form[key]
            if isinstance(value, str):
                try:
                    data[key] = json.loads(value)
                except (json.JSONDecodeError, TypeError):
                    data[key] = value
            else:
                data[key] = value
    else:
        try:
            data = await request.json()
        except:
            data = {}

    # Execute
    try:
        func_to_call = RPC_REGISTRY[registry_key]

        if inspect.iscoroutinefunction(func_to_call):
            result = await func_to_call(**data)
        else:
            result = await asyncio.to_thread(func_to_call, **data)

        # 1. Handle Explicit Response Objects (Standard or Streaming)
        if isinstance(result, Response):
            location = result.headers.get("Location")
            status = result.status_code
            if location and 300 <= status < 400:
                resp = JSONResponse({"result": None})
                resp.headers["X-PP-Redirect"] = location
                resp.headers["X-PP-Redirect-Status"] = str(status)
                return resp
            return result

        # 2. Handle Auto-Streaming (Async Generators)
        # If the user used 'yield' in an async function, it returns an AsyncGenerator.
        if inspect.isasyncgen(result) or inspect.isgenerator(result):
            return SSE(result)

        # 3. Default JSON Response
        return JSONResponse(_serialize_result(result))

    except PermissionError as e:
        return JSONResponse({'error': str(e)}, status_code=403)
    except ValueError as e:
        return JSONResponse({'error': str(e)}, status_code=400)
    except Exception as e:
        print(f"[RPC Error] {registry_key}: {e}")
        traceback.print_exc()
        return JSONResponse({'error': 'Internal server error'}, status_code=500)


async def rpc_middleware(request: Request, call_next):
    if request.headers.get('X-PP-RPC') == 'true' and request.method == 'POST':
        session = dict(request.session) if hasattr(request, 'session') else {}
        return await _handle_rpc_request(request, session)

    response = await call_next(request)
    return response


def register_rpc_routes(app: FastAPI):
    app.state.limiter = limiter

    @app.exception_handler(RateLimitExceeded)
    async def rate_limit_handler(request: Request, exc: RateLimitExceeded):
        return JSONResponse({'error': 'Rate limit exceeded.'}, status_code=429)
