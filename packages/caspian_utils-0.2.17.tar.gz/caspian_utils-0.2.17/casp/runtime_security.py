import mimetypes
import os
from pathlib import Path
from typing import Optional

from fastapi import Response
from fastapi.responses import FileResponse

INSECURE_SESSION_SECRET_VALUES = {"", "change-me", "changeme"}


def resolve_safe_public_path(base_dir: str | Path, relative_path: str) -> Optional[Path]:
    base_path = Path(base_dir).resolve()
    try:
        candidate = (base_path / relative_path).resolve()
        candidate.relative_to(base_path)
    except (OSError, RuntimeError, ValueError):
        return None

    if not candidate.is_file():
        return None

    return candidate


def public_file_response(
    base_dir: str | Path,
    relative_path: str,
    *,
    media_type: Optional[str] = None,
) -> Response:
    file_path = resolve_safe_public_path(base_dir, relative_path)
    if file_path is None:
        return Response(status_code=404)

    resolved_media_type = media_type
    if resolved_media_type is None:
        resolved_media_type, _ = mimetypes.guess_type(str(file_path))

    return FileResponse(
        file_path,
        media_type=resolved_media_type or "application/octet-stream",
    )


def client_error_message(exc: Exception, *, is_production: bool) -> str:
    return str(exc) if not is_production else "An unexpected error occurred."


def get_session_secret(*, is_production: bool) -> str:
    session_secret = (os.getenv("AUTH_SECRET") or "").strip()
    if session_secret and session_secret.lower() not in INSECURE_SESSION_SECRET_VALUES:
        return session_secret

    if not is_production:
        return "change-me"

    raise RuntimeError(
        "AUTH_SECRET must be set to a non-default value when APP_ENV=production."
    )


def build_security_headers(*, is_production: bool) -> dict[str, str]:
    headers = {
        "permissions-policy": "camera=(), geolocation=(), microphone=(), payment=(), usb=()",
        "referrer-policy": "strict-origin-when-cross-origin",
        "x-content-type-options": "nosniff",
        "x-frame-options": "SAMEORIGIN",
    }
    if is_production:
        headers["strict-transport-security"] = "max-age=31536000; includeSubDomains"
    return headers
