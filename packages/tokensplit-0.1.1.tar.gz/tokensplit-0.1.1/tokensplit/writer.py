"""
tokensplit/writer.py — Token-Separated Values writer.

File format
-----------
  Line 1  : the delimiter string followed by a newline
  Line 2+ : rows of values, each value separated by the delimiter,
            each row terminated by  <delimiter><newline>

            Example with delimiter  /---/ :

                /---/
                hello/---/world/---/
                foo/---/bar/---/baz/---/

Safety
------
Two kinds of collision are detected and rejected with a ValueError:

  1. A value *contains* the delimiter  ("hel/---/lo" with delim "/---/")
  2. A value's suffix + delimiter prefix would create a new delimiter when
     written adjacently  (value "aa" + delim "aaa" = "aaaaa" which embeds
     "aaa").

In both cases the caller should choose a different delimiter.
"""

from typing import List


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _validate_value(value: str, delimiter: str):
    """
    Raise ValueError if writing *value* followed by *delimiter* would
    produce a byte sequence that embeds the delimiter at an unexpected position.

    Two checks:
      1. value itself contains the delimiter string.
      2. (value + delimiter) contains the delimiter *before* the intended
         boundary at index len(value), meaning the suffix of value and the
         prefix of delimiter combine to form a spurious delimiter earlier.
    """
    if delimiter in value:
        raise ValueError(
            f"Value {value!r} contains the delimiter {delimiter!r}. "
            "Choose a different delimiter or sanitise your data first."
        )
    combined = value + delimiter
    idx = combined.find(delimiter)
    if idx < len(value):
        raise ValueError(
            f"Value {value!r} ends with a prefix of the delimiter "
            f"{delimiter!r}, creating an ambiguous sequence when written. "
            "Choose a different delimiter."
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class ToksWriter:
    """
    Write rows to a .toks file.

    Usage
    -----
        with open("data.toks", "w") as f:
            writer = ToksWriter(f, delimiter="/---/")
            writer.writerow(["hello", "world"])
            writer.writerow(["foo", "bar", "baz"])

    The delimiter is written automatically to line 1 on construction.
    """

    def __init__(self, file_obj, delimiter: str):
        if not delimiter:
            raise ValueError("Delimiter must not be empty.")
        if "\n" in delimiter:
            raise ValueError("Delimiter must not contain a newline character.")
        self.delimiter: str = delimiter
        self._file = file_obj
        # Write the delimiter as the very first line.
        file_obj.write(delimiter + "\n")

    def writerow(self, row: List[str]):
        """
        Write a single row of values.

        Raises ValueError if any value would corrupt the file (see module
        docstring for details).
        """
        for value in row:
            _validate_value(str(value), self.delimiter)
        self._file.write(self.delimiter.join(str(v) for v in row))
        self._file.write(self.delimiter + "\n")

    def writerows(self, rows: List[List[str]]):
        """Write multiple rows at once."""
        for row in rows:
            self.writerow(row)


def write(filepath: str, rows: List[List[str]], delimiter: str):
    """
    Convenience function — write all rows to a .toks file in one call.

        tokensplit.write("data.toks", [["a", "b"], ["c", "d"]], delimiter="/---/")
    """
    with open(filepath, "w", encoding="utf-8", newline="") as f:
        writer = ToksWriter(f, delimiter=delimiter)
        writer.writerows(rows)
