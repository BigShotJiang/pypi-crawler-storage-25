"""
tokensplit/reader.py — Token-Separated Values reader.

File format
-----------
  Line 1  : the delimiter string (e.g.  /---/  or  ,,,)
  Line 2+ : rows of values, each value separated by the delimiter string,
            each row terminated by  <delimiter><newline>

            Example with delimiter  /---/ :

                /---/
                hello/---/world/---/
                foo/---/bar/---/baz/---/

Reading algorithm — sliding window, O(n) time, O(d) extra space
---------------------------------------------------------------
We read the post-header content as a single string, then scan it with a
two-pointer window of exactly len(delimiter) characters.

  end   advances one character per iteration.
  start marks the beginning of the current token.
  window_start = end - d  is the left edge of the current d-wide window.

When the window matches the delimiter we:
  1. Emit  text[start : end-d]  as the next value.
  2. Set   start = end  (skip past the delimiter).
  3. If content[start] == newline -> row terminator; close row, skip newline.

Because we move forward-only and slice once per delimiter hit, total work is
O(n) in file size.  Partial-overlap cases (delimiter="ab", value="aab") are
handled naturally by the character-at-a-time slide.
"""

from typing import Iterator, List


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _read_delimiter(file_obj) -> str:
    """Read line 1 and return the delimiter (without its trailing newline)."""
    line = file_obj.readline()
    if not line:
        raise ValueError("File is empty — cannot read delimiter from first line.")
    if line.endswith("\n"):
        line = line[:-1]
    if not line:
        raise ValueError("Delimiter string on line 1 must not be empty.")
    return line


def _parse(content: str, delimiter: str) -> List[List[str]]:
    """
    Parse *content* (everything after the delimiter line) into a list of rows.

    Row terminator  : <delimiter><newline>
    Value separator : <delimiter>  (followed by more values on the same row)
    """
    d = len(delimiter)
    n = len(content)
    rows: List[List[str]] = []
    current_row: List[str] = []

    start = 0   # start of the current token
    end = d     # right edge of the sliding window (exclusive)

    if n < d:
        # Content shorter than one delimiter — nothing to split.
        if content:
            current_row.append(content)
            rows.append(current_row)
        return rows

    while end <= n:
        if content[end - d : end] == delimiter:
            # Emit the token that ends just before this window.
            current_row.append(content[start : end - d])
            start = end  # jump past the delimiter

            # Peek: is the next character a newline (row terminator)?
            if start < n and content[start] == "\n":
                rows.append(current_row)
                current_row = []
                start += 1  # consume the newline

            end = start + d  # position window at start of next potential match
        else:
            end += 1

    # Flush anything not closed by a row-end delimiter (e.g. file with no final newline).
    tail = content[start:]
    if tail or current_row:
        current_row.append(tail)
        rows.append(current_row)

    return rows


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class ToksReader:
    """
    Read a .toks file row by row.

    Usage
    -----
        with open("data.toks") as f:
            reader = ToksReader(f)
            for row in reader:
                print(row)          # ['val1', 'val2', ...]

    The delimiter is read automatically from line 1 of the file.
    Inspect it via  reader.delimiter  after construction.
    """

    def __init__(self, file_obj):
        self.delimiter: str = _read_delimiter(file_obj)
        self._rows: List[List[str]] = _parse(file_obj.read(), self.delimiter)

    def __iter__(self) -> Iterator[List[str]]:
        return iter(self._rows)


def read(filepath: str) -> List[List[str]]:
    """
    Convenience function — read an entire .toks file and return all rows.

        rows = tokensplit.read("data.toks")

    Returns a list of rows; each row is a list of string values.
    """
    with open(filepath, "r", encoding="utf-8", newline="") as f:
        reader = ToksReader(f)
        return list(reader)
