"""
tests/test_tokensplit.py — tests for the tokensplit package.

Run with:  python -m pytest tests/
"""

import io
import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from tokensplit.reader import ToksReader, read
from tokensplit.writer import ToksWriter, write


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def roundtrip(rows, delimiter):
    """Write rows to an in-memory buffer, read them back, return result."""
    buf = io.StringIO()
    ToksWriter(buf, delimiter).writerows(rows)
    buf.seek(0)
    return list(ToksReader(buf))


# ---------------------------------------------------------------------------
# Basic round-trip tests
# ---------------------------------------------------------------------------

class TestRoundTrip:
    def test_simple_three_char_delimiter(self):
        rows = [["hello", "world"], ["foo", "bar", "baz"]]
        assert roundtrip(rows, ",,,") == rows

    def test_slash_delimiter(self):
        rows = [["alpha", "beta"], ["gamma", "delta", "epsilon"]]
        assert roundtrip(rows, "/---/") == rows

    def test_single_char_delimiter(self):
        rows = [["a", "b", "c"], ["d", "e"]]
        assert roundtrip(rows, "|") == rows

    def test_long_delimiter(self):
        rows = [["x", "y"], ["z"]]
        assert roundtrip(rows, "<<SPLIT>>") == rows

    def test_single_row_single_value(self):
        rows = [["only"]]
        assert roundtrip(rows, "/---/") == rows

    def test_empty_values(self):
        rows = [["", "b", ""], ["", ""]]
        assert roundtrip(rows, "/---/") == rows

    def test_numeric_strings(self):
        rows = [["1", "2", "3"], ["100", "200"]]
        assert roundtrip(rows, "|||") == rows

    def test_whitespace_values(self):
        rows = [["  leading", "trailing  ", " both "]]
        assert roundtrip(rows, "/---/") == rows

    def test_newlines_inside_values(self):
        # Newlines inside a value are preserved; rows end on <delim><newline>
        rows = [["line1\nline2", "normal"]]
        assert roundtrip(rows, "/---/") == rows

    def test_many_rows(self):
        rows = [[str(i), str(i * 2)] for i in range(200)]
        assert roundtrip(rows, "---") == rows


# ---------------------------------------------------------------------------
# Delimiter detection edge cases
# ---------------------------------------------------------------------------

class TestDelimiterEdgeCases:
    def test_value_starts_with_partial_delimiter(self):
        # Value starts with part of the delimiter — must not be split early.
        rows = [["/--hello", "world"]]       # delimiter is /---/
        assert roundtrip(rows, "/---/") == rows

    def test_value_ends_with_safe_partial_delimiter(self):
        # "hello/--" ends with "/--" (3 chars).  Delimiter is "/---/" (5 chars).
        # "hello/--" + "/---/" = "hello/---/" which has "/---/" exactly at the
        # intended boundary — safe to write.
        rows = [["hello/--", "world"]]
        assert roundtrip(rows, "/---/") == rows


# ---------------------------------------------------------------------------
# Writer safety / validation
# ---------------------------------------------------------------------------

class TestWriterValidation:
    def test_value_contains_delimiter_raises(self):
        buf = io.StringIO()
        writer = ToksWriter(buf, "/---/")
        with pytest.raises(ValueError, match="delimiter"):
            writer.writerow(["safe", "un/---/safe"])

    def test_adjacency_collision_raises(self):
        # "aa" + "aaa" = "aaaaa" which embeds "aaa" before the intended split.
        buf = io.StringIO()
        writer = ToksWriter(buf, "aaa")
        with pytest.raises(ValueError):
            writer.writerow(["aa", "b"])

    def test_empty_delimiter_raises(self):
        with pytest.raises(ValueError, match="empty"):
            ToksWriter(io.StringIO(), "")

    def test_delimiter_with_newline_raises(self):
        with pytest.raises(ValueError, match="newline"):
            ToksWriter(io.StringIO(), "/--\n/")


# ---------------------------------------------------------------------------
# Reader validation
# ---------------------------------------------------------------------------

class TestReaderValidation:
    def test_empty_file_raises(self):
        with pytest.raises(ValueError, match="empty"):
            ToksReader(io.StringIO(""))


# ---------------------------------------------------------------------------
# File I/O convenience functions
# ---------------------------------------------------------------------------

class TestFileIO:
    def test_write_and_read_file(self, tmp_path):
        path = str(tmp_path / "data.toks")
        rows = [["name", "age"], ["Alice", "30"], ["Bob", "25"]]
        write(path, rows, delimiter="/---/")
        assert read(path) == rows

    def test_file_first_line_is_delimiter(self, tmp_path):
        path = str(tmp_path / "data.toks")
        write(path, [["a", "b"]], delimiter="###")
        with open(path) as f:
            first_line = f.readline().rstrip("\n")
        assert first_line == "###"

    def test_delimiter_accessible_on_reader(self, tmp_path):
        path = str(tmp_path / "data.toks")
        write(path, [["x"]], delimiter="::::")
        with open(path) as f:
            reader = ToksReader(f)
            assert reader.delimiter == "::::"


# ---------------------------------------------------------------------------
# Streaming / large data
# ---------------------------------------------------------------------------

class TestStreaming:
    def test_fifty_rows(self):
        rows = [[f"r{i}c0", f"r{i}c1"] for i in range(50)]
        result = roundtrip(rows, ",,,")
        assert len(result) == 50
        assert result[0] == ["r0c0", "r0c1"]
        assert result[49] == ["r49c0", "r49c1"]
