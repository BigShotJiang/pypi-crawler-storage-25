from collections.abc import Callable
from dataclasses import dataclass

from funfedi_parsing_test_cases.types import Environment

from .defaults import default_activity_maker, default_object_maker


class InvalidTestCaseException(Exception): ...


@dataclass
class ActivityTestCase:
    """Activity test case"""

    activity: dict
    object_id: str


@dataclass
class ActivityTestCaseMaker:
    """Creates an Activity test case"""

    object_maker: Callable[[Environment], dict] = default_object_maker
    activity_maker: Callable[[Environment, dict], dict] = default_activity_maker

    def activity_and_object(self, environment: Environment) -> tuple[dict, dict]:
        obj = self.object_maker(environment)
        activity = self.activity_maker(environment, obj)
        return activity, obj

    def to_send(self, environment: Environment) -> ActivityTestCase:
        #
        # Might want to return object_id instead of activity, as it is what is used
        # to lookup later
        #
        # Also activity might be a lie as one might have an activity in an activity
        #
        activity, obj = self.activity_and_object(environment)

        object_id = obj.get("id")
        if not isinstance(object_id, str):
            raise InvalidTestCaseException(
                "Only test cases where the object has an id are supported"
            )

        return ActivityTestCase(activity, object_id)
