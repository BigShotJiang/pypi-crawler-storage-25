import datetime

from bovine.utils import now_isoformat
from funfedi_parsing_test_cases.types import Environment


def default_object_maker(environment: Environment) -> dict:
    """
    ```python
    >>> from funfedi_parsing_test_cases.testing import default_env
    >>> default_object_maker(default_env)
    {'@context': ['https://www.w3.org/ns/activitystreams'],
        'attributedTo': 'http://host.test/some/actor',
        'content': 'text',
        'id': '...
        'published': '...
        'to': ['https://www.w3.org/ns/activitystreams#Public', 'http://other.test/some/actor'],
        'cc': [],
        'tag': [{'type': 'Mention', 'href': 'http://other.test/some/actor'}],
        'type': 'Note'}

    ```
    """
    return {
        "@context": [
            "https://www.w3.org/ns/activitystreams",
        ],
        "attributedTo": environment.sending_actor,
        "content": "text",
        "id": environment.id_maker(),
        "published": now_isoformat(),
        "to": [
            "https://www.w3.org/ns/activitystreams#Public",
            environment.receiving_actor,
        ],
        "cc": [],
        "tag": [{"type": "Mention", "href": environment.receiving_actor}],
        "type": "Note",
    }


def default_event_maker(environment: Environment) -> dict:
    """
    ```python
    >>> from funfedi_parsing_test_cases.testing import default_env
    >>> default_event_maker(default_env)
    {'@context': ['https://www.w3.org/ns/activitystreams'],
        'attributedTo': 'http://host.test/some/actor',
        'content': 'event content',
        'name': 'my event',
        'id': '...
        'published': '...
        'to': ['https://www.w3.org/ns/activitystreams#Public', 'http://other.test/some/actor'],
        'cc': [],
        'type': 'Event',
        'startTime': '...
        'endTime': '...
        'location': {'type': 'VirtualLocation', 'url': 'http://localhost'}}

    ```
    """

    return {
        "@context": [
            "https://www.w3.org/ns/activitystreams",
        ],
        "attributedTo": environment.sending_actor,
        "content": "event content",
        "name": "my event",
        "id": environment.id_maker(),
        "published": now_isoformat(),
        "to": [
            "https://www.w3.org/ns/activitystreams#Public",
            environment.receiving_actor,
        ],
        "cc": [],
        "type": "Event",
        "startTime": (datetime.datetime.now() + datetime.timedelta(days=4)).isoformat(),
        "endTime": (
            datetime.datetime.now() + datetime.timedelta(days=4, hours=3)
        ).isoformat(),
        "location": {"type": "VirtualLocation", "url": "http://localhost"},
    }


def default_activity_maker(environment: Environment, obj: dict) -> dict:
    """
    ```python
    >>> from funfedi_parsing_test_cases.testing import default_env
    >>> obj = default_object_maker(default_env)
    >>> default_activity_maker(default_env, obj)
    {'@context': ['https://www.w3.org/ns/activitystreams'],
        'actor': 'http://host.test/some/actor',
        'id': '...
        'object': ...
        'published': '...
        'to': ['https://www.w3.org/ns/activitystreams#Public', 'http://other.test/some/actor'],
        'cc': [],
        'type': 'Create'}

    ```
    """
    return {
        "@context": [
            "https://www.w3.org/ns/activitystreams",
        ],
        "actor": environment.sending_actor,
        "id": environment.id_maker("activities"),
        "object": obj,
        "published": now_isoformat(),
        "to": [
            "https://www.w3.org/ns/activitystreams#Public",
            environment.receiving_actor,
        ],
        "cc": [],
        "type": "Create",
    }
