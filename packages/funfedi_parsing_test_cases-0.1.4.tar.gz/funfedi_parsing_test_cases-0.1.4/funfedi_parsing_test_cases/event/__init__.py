from funfedi_parsing_test_cases.suite import SubSuite
from funfedi_parsing_test_cases.types import Environment, Case
from funfedi_parsing_test_cases.cases import (
    ActivityTestCaseMaker,
    default_event_maker,
)


def with_tag(tag_content: dict):
    def maker(environment: Environment):
        event = default_event_maker(environment)
        event["tag"] = [tag_content]
        return event

    return ActivityTestCaseMaker(object_maker=maker)


def no_location():
    def maker(environment: Environment):
        event = default_event_maker(environment)
        del event["location"]
        return event

    return ActivityTestCaseMaker(object_maker=maker)


base_event_cases = [
    Case(name="default", maker=ActivityTestCaseMaker()),
    Case(name="with hashtag", maker=with_tag({"type": "Hashtag", "name": "#tag"})),
    Case(
        name="with mention",
        maker=with_tag(
            {"type": "Mention", "name": "@someone", "href": "http://host.test/someone"}
        ),
    ),
    Case(name="no location", maker=no_location()),
]

base_event_test_suite = SubSuite("Some events", "events", base_event_cases)
