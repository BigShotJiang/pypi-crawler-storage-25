from .types import Case, Environment
from .suite import Suite, SubSuite
from .activity import (
    activity_context_suite,
    create_suite,
    announce_suite,
    addressing_suite,
)
from .event import base_event_test_suite

__all__ = ["activity_suite", "Case", "Environment", "Suite", "SubSuite"]


activity_suite = Suite(
    [create_suite, activity_context_suite, announce_suite, addressing_suite]
)
"""Contains the activity test suite"""

event_suite = Suite([base_event_test_suite])
"""Contains the test suite for events"""
