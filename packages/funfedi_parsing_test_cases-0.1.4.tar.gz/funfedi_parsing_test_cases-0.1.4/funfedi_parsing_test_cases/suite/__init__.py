from dataclasses import dataclass
from funfedi_parsing_test_cases.types import Case

from .validators import validate

__all__ = ["Suite", "SubSuite"]


@dataclass
class SubSuite:
    """Represents a particular set of thematic tests"""

    title: str
    short_name: str
    tests: list[Case]


class Suite:
    """Represents the set of all tests"""

    tests: dict[str, list[Case]]
    test_map: dict[str, dict[str, Case]]
    titles: dict[str, str]
    sub_suites: list[SubSuite]

    def __init__(self, tests: list[SubSuite]):
        """Constructs the suite"""
        self.sub_suites = tests
        self.tests = {
            sub_suite.short_name: [validate(x) for x in sub_suite.tests]
            for sub_suite in tests
        }
        self.titles = {sub_suite.short_name: sub_suite.title for sub_suite in tests}
        self.test_map = {
            name: {test_case.name: test_case for test_case in cases}
            for name, cases in self.tests.items()
        }

    def retrieve(self, name: str, test_name: str) -> Case:
        """Fora suite name and test_name gets the case"""
        return self.test_map[name][test_name]

    @property
    def names(self) -> list[tuple[str, str]]:
        """Gets the names of all tests"""
        name_map = [
            [(name, case.name) for case in cases] for name, cases in self.tests.items()
        ]

        return sum(name_map, [])
