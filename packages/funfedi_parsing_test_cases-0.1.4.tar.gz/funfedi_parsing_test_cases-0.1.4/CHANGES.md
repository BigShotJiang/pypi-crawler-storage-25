# Changes

## 0.1.4

* Add basic test cases for events [inputs#143](https://codeberg.org/funfedidev/fediverse-pasture-inputs/issues/143)
* Make default makers explicit in docs
* Add 'default_event_maker'

## 0.1.3

* Improve docs [parsing#2](https://codeberg.org/funfedidev/funfedi_parsing_test_cases/issues/2)

## 0.1.2

Initial public release
