# Copyright Jonathan Hartley 2013. BSD 3-Clause license, see LICENSE file.
from .initialise import init, deinit, reinit, colorama_text, just_fix_windows_console

def coloreasy_print(text, foreground=None, background=None, style=None, end="\n"):
    '''
    Print text in color using coloreasyprint styles.
    Example: coloreasy_print("Hello", foreground=Fore.RED, style=Style.BRIGHT)
    '''
    result = ""
    if foreground:
        result += foreground
    if background:
        result += background
    if style:
        result += style
    result += text + Style.RESET_ALL
    print(result, end=end)

from .ansi import Fore, Back, Style, Cursor
from .ansitowin32 import AnsiToWin32

__version__ = '0.4.7dev1'

