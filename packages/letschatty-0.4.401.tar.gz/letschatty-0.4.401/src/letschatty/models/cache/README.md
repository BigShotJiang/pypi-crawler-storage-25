# Cache layer

This folder defines the cache abstraction and the two concrete implementations shipped with the package.

## Why this exists

Services used to keep a local in-memory dict of assets and refresh them via a background thread. That made the package stateful and impossible to scale horizontally (each process had its own copy of the data). The cache layer replaces that: services hold no local state and instead read from a shared external cache (Redis in production, nothing in tests).

## Files

| File | Purpose |
|------|---------|
| `cache_protocol.py` | The abstract interface (Python `Protocol`) |
| `no_cache.py` | Noop implementation — default when no cache is injected |
| `redis_connection.py` | Singleton wrapper around `redis.asyncio` |
| `redis_cache.py` | Concrete `CacheProtocol` implementation backed by Redis |

---

## CacheProtocol

```python
class CacheProtocol(Protocol):
    async def get(self, key: str) -> Optional[str]: ...
    async def set(self, key: str, value: str, ttl: Optional[int] = None) -> None: ...
    async def delete(self, key: str) -> None: ...
    async def delete_many(self, keys: List[str]) -> None: ...
    async def get_many(self, keys: List[str]) -> List[Optional[str]]: ...
```

- Values are always **strings** (JSON-serialized Pydantic models or lists of dicts).
- `ttl` is in **seconds**. `None` means no expiry.
- It is a structural `Protocol` — any class with these async methods satisfies it without inheriting from anything.
- It is `@runtime_checkable` so you can use `isinstance(obj, CacheProtocol)` in tests.

---

## NoCache

Used when no cache is injected. Every method is a coroutine that does nothing or returns `None`/empty. This means:

- Tests run without Redis.
- Services that genuinely don't need caching (e.g. `ChatService`, `ChainOfThoughtService`) can omit the cache param and get safe noop behaviour.

---

## RedisConnection

Singleton wrapper around `redis.asyncio`. Mirrors how `MongoConnection` wraps Motor.

```python
# First call — creates the client
RedisConnection(url="redis://my-host:6379", password="secret")

# Any subsequent call — returns the same instance
RedisConnection()
```

Falls back to env vars if params are not passed:

| Env var | Default |
|---------|---------|
| `REDIS_URL` | `redis://localhost:6379` |
| `REDIS_PASSWORD` | *(none)* |

The underlying client is `redis.asyncio.Redis` with `decode_responses=True` (returns `str`, not `bytes`) and optional `hiredis` parser for speed.

**Health check:**
```python
ok = await RedisConnection().ping()
```

**Shutdown** (call at app teardown):
```python
await RedisConnection().close()
```

---

## RedisCache

Concrete `CacheProtocol` implementation. Takes a `RedisConnection` and delegates to its client.

```python
redis_conn = RedisConnection(url=..., password=...)
cache = RedisCache(redis_conn)
```

Pass this into any service:

```python
from letschatty.models.cache import RedisCache, RedisConnection
from letschatty.services.chatty_assets.services.product_service import ProductService
from letschatty.models.data_base.mongo_connection import MongoConnection

cache = RedisCache(RedisConnection())
service = ProductService(connection=MongoConnection(), cache=cache)
```

---

## Implementing your own cache

Any class that satisfies the five async methods is a valid `CacheProtocol`. No inheritance needed.

```python
class MemoryCache:
    def __init__(self): self._store = {}
    async def get(self, key): return self._store.get(key)
    async def set(self, key, value, ttl=None): self._store[key] = value
    async def delete(self, key): self._store.pop(key, None)
    async def delete_many(self, keys):
        for k in keys: self._store.pop(k, None)
    async def get_many(self, keys): return [self._store.get(k) for k in keys]
```

This is useful for integration tests that need deterministic cache behaviour without a Redis container.

---

## Cache key scheme

Keys are set by `base_container_with_collection.py`:

| Pattern | What it caches | Invalidated when |
|---------|---------------|-----------------|
| `{collection}:item:{id}` | Single full serialized model (JSON string) | insert, update, delete, partial_update, push_message |
| `{collection}:previews:{company_id}` | All preview dicts for a company (JSON array of raw dicts) | insert, update, delete; or partial_update with `invalidate_previews=True` |
| `{collection}:all:{company_id}` | All full models for a company (JSON array) | same as previews |

`{collection}` is the MongoDB collection name (e.g. `products`, `tags`).

All three keys are invalidated together via `cache.delete_many([item_key, previews_key, all_key])` on full writes. Partial writes (chat-specific) only invalidate the item key unless the caller explicitly requests preview invalidation.

### What is NOT cached

**Chats** — too large, too frequently written. `ChatService` uses `NoCache` by default. Inbox/preview queries for chats go directly to MongoDB with filters and sort — Redis is not involved.
