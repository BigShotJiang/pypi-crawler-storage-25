# data_base layer

This folder owns everything related to MongoDB connectivity and the async CRUD abstraction all collections build on.

## Files

| File | Purpose |
|------|---------|
| `mongo_connection.py` | Singleton Motor client wrapper |
| `collection_interface.py` | Async CRUD base class for all MongoDB collections |

---

## MongoConnection

Singleton wrapper around `motor.motor_asyncio.AsyncIOMotorClient`. Motor is the async MongoDB driver — it speaks the MongoDB wire protocol without blocking the event loop.

### Why a singleton?

Motor maintains a connection pool internally. Creating multiple `AsyncIOMotorClient` instances wastes connections and memory. The singleton ensures one pool is shared across the entire process.

### Setup

```python
# First call — creates the Motor client and connection pool
MongoConnection(
    uri_base="mongodb+srv",
    username="myuser",
    password="mypass",
    instance="cluster0.abcde"
)

# Any subsequent call anywhere in the codebase — returns the same instance
MongoConnection()
```

Falls back to env vars when params are not passed:

| Env var | Maps to |
|---------|---------|
| `MONGO_USERNAME` | `username` |
| `MONGO_PASSWORD` | `password` |
| `MONGO_URI_BASE` | `uri_base` (e.g. `mongodb+srv`) |
| `MONGO_INSTANCE_COMPONENT` | `instance` (e.g. `cluster0.abcde.mongodb.net`) |

**Health check** (async):
```python
ok = await MongoConnection().ping()
```

**Shutdown** (sync, called automatically at process exit via `atexit`):
```python
MongoConnection().close()
```

### Motor vs PyMongo

| | PyMongo | Motor |
|-|---------|-------|
| I/O model | Blocking (threads) | Non-blocking (asyncio) |
| Client class | `MongoClient` | `AsyncIOMotorClient` |
| Collection ops | Synchronous | `await`able |
| FastAPI / asyncio compatible | No | Yes |

Motor is a thin async wrapper around PyMongo's C driver. It bundles PyMongo — you do not need to install PyMongo separately.

---

## ChattyAssetCollectionInterface

Generic base class for all MongoDB collection wrappers. Type parameters: `T` is the full Pydantic model, `P` is the lightweight preview model.

```
ChattyAssetCollectionInterface[Product, ProductPreview]
  └── ProductCollection          # knows collection name, create_instance()
       └── ProductService        # adds caching + events
```

### Methods

All methods are `async def` and return fully-typed Pydantic models:

| Method | MongoDB operation | Notes |
|--------|------------------|-------|
| `get_by_id(doc_id)` | `find_one({"_id": ObjectId(doc_id)})` | Raises `NotFoundError` if missing |
| `insert(item)` | `insert_one(item.model_dump())` | |
| `update(item)` | `update_one({"_id": id}, {"$set": full_doc})` | Full document replacement |
| `partial_update(doc_id, fields)` | `update_one({"_id": id}, {"$set": fields + updated_at})` | Only the given fields; never touches others |
| `delete(id, deletion_type)` | Logical: `$set {deleted_at}`; Physical: `delete_one` | |
| `get_docs(company_id, query, limit)` | `find(filter).to_list(None)` | |
| `get_preview_docs(projection, company_id)` | `find({...}, projection).to_list(None)` | Skips malformed docs with a warning |
| `get_projection_by_query(query, projection)` | `find(query, projection).to_list(None)` | Returns raw dicts |
| `get_by_query(query)` | `find(query).to_list(None)` | |

### `partial_update` vs `update`

Use `partial_update` when you know exactly which fields changed and don't want to load or replace the full document. This is the correct approach for any high-frequency or large-document write:

```python
# Only sets these two fields + updated_at. Messages, flow_states, etc. are untouched.
await collection.partial_update(chat_id, {"area": "WITH_AGENT", "agent_id": agent_id})
```

Use `update` for small static assets where a full replacement is fine and simpler.

### Chat-specific methods (in `ChatCollection`)

`ChatCollection` extends the base with two methods that require chat-specific MongoDB operators:

| Method | MongoDB operation | Why not on base class |
|--------|------------------|----------------------|
| `push_message(chat_id, message)` | `$push: {messages: msg_doc}` + `$set: {updated_at}` | `$push` appends without loading the array |
| `update_message_status(chat_id, message_id, status)` | `$set: {messages.$.status}` with positional filter | Positional operator `$` is message-array-specific |

### How to subclass

```python
from letschatty.models.data_base.collection_interface import ChattyAssetCollectionInterface
from letschatty.models.data_base.mongo_connection import MongoConnection

class WidgetCollection(ChattyAssetCollectionInterface[Widget, WidgetPreview]):
    def __init__(self, connection: MongoConnection):
        super().__init__(
            database="my_db",
            collection="widgets",
            connection=connection,
            type=Widget,
            preview_type=WidgetPreview,
        )

    def create_instance(self, data: dict) -> Widget:
        return Widget(**data)
```

`create_instance` is the only abstract method. It converts a raw MongoDB dict into a typed model. Use a factory if the model requires complex construction logic.

### Direct Motor access

If you need a query not covered by the base methods, use `self.collection` directly — it is an `AsyncIOMotorCollection`:

```python
async def get_by_sku(self, sku: str) -> Widget:
    doc = await self.collection.find_one({"sku": sku})
    if not doc:
        raise NotFoundError(f"Widget with sku {sku} not found")
    return self.create_instance(doc)
```

Use `self.collection` (the Motor collection). There is no `self.async_collection`.
