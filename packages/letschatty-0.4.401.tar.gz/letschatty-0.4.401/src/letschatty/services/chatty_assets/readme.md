# chatty_assets — Async Asset Services

This folder is the main service layer for all "company assets" — products, tags, users, flows, fast answers, AI agents, chats, etc. It provides async CRUD with cache-aside reads.

## Folder layout

```
chatty_assets/
├── base_container_with_collection.py   # Core: cache-aside logic, all read/write/partial-update methods
├── asset_service.py                    # Generic typed service (wraps base_container_with_collection)
├── assets_collections.py               # Read-only singleton for microservices
├── collections/                        # One file per asset type — knows collection name + factory
│   ├── chat_collection.py              # Chat-specific: push_message, update_message_status
│   ├── product_collection.py
│   ├── fast_answer_collection.py
│   └── ...
└── services/                           # One file per asset type — adds events + type safety
    ├── chat_service.py                 # Chat persistence: push_message, update_message_status
    ├── product_service.py
    ├── fast_answer_service.py
    └── ...
```

---

## Class hierarchy

```
ChattyAssetContainerWithCollection[T, P]   ← base_container_with_collection.py
  └── AssetService[T, P]                   ← asset_service.py
       └── ChatService                     ← services/chat_service.py  (+ push_message, update_message_status)
       └── ProductService                  ← services/product_service.py
       └── FastAnswerService
       └── ... (one per asset type)
```

`ChattyAssetCollectionInterface[T]` (in `models/data_base/`) is composed into every service:

```
ChatService
  └── ChatCollection(AssetCollection[Chat, None])
       └── ChattyAssetCollectionInterface  ← actual Motor calls + partial_update, push_message, update_message_status
```

---

## How reads work (cache-aside)

```
service.get_by_id("abc123")
  1. cache.get("products:item:abc123")
       → hit:  json.loads → model_validate → return Product
       → miss: continue
  2. Motor → MongoDB find_one({"_id": ObjectId("abc123")})
  3. cache.set("products:item:abc123", json, ttl=300)
  4. return Product
```

**Use `get_all_previews(company_id)` for list endpoints** — it returns raw dicts and has no Pydantic deserialization cost on cache hits. Use `get_all(company_id)` only when business logic needs full model instances.

**Never call `get_preview_by_id` in a loop.** That method no longer exists. The correct pattern:
```python
# one Redis hit + one json.loads
all_previews = await products.get_all_previews(company_id)
preview_map = {p['_id']: p for p in all_previews}   # O(1) from here

# O(1) per lookup — no repeated cache hits
for product in chat.products:
    preview = preview_map.get(product.asset_id)
```

---

## How writes work

### Full-document write (for static assets)

```
service.insert(new_product, ctx)
  1. Motor → MongoDB insert_one(...)
  2. cache.delete_many([item_key, previews_key, all_key])

service.update(id, updated_product, ctx)
  1. get_by_id(id)  ← reads current doc (cache or DB)
  2. existing.update(new_item)  ← merges fields in memory
  3. Motor → MongoDB update_one({"_id": id}, {"$set": full_doc})
  4. cache.delete_many([item_key, previews_key, all_key])
```

### Partial write (for Chat — avoids loading/replacing full document)

```
chat_service.partial_update(chat_id, {"area": "WITH_AGENT", "agent_id": "..."}, ctx)
  → Motor → update_one({"_id": id}, {"$set": fields + updated_at})
  → cache.delete_many([item_key])                   # always
  → cache.delete_many([previews_key, all_key])      # only if invalidate_previews=True + company_id passed

chat_service.push_message(chat_id, message, ctx)
  → Motor → update_one({...}, {"$push": {"messages": msg_doc}})
  → cache.delete(item_key)

chat_service.update_message_status(chat_id, message_id, status, ctx)
  → Motor → update_one({"messages.id": msg_id}, {"$set": {"messages.$.status": ...}})
  → cache.delete(item_key)
```

Cache keys: `{collection}:item:{id}`, `{collection}:previews:{company_id}`, `{collection}:all:{company_id}`.

---

## Chat vs. static assets

Chats are fundamentally different from static assets:

| | Static assets (tags, products, etc.) | Chat |
|--|--|--|
| Write frequency | Rare | Every message (~seconds) |
| Document size | Small | Large (hundreds of messages) |
| MongoDB write | Full `$set` of whole doc | Targeted: `$push`, `$set` on one field |
| Item cache | Yes — full doc cached with TTL | No — `NoCache` default |
| List cache | `previews` key cached per company | Never — inbox queries go direct to MongoDB with filters |
| Pagination | In-memory slice of cached list | MongoDB query with filters + sort |

The static `ChatService` in `services/chat/chat_service.py` is **pure business logic** — all `@staticmethod`, no DB. Apply it in memory, then use the targeted persistence methods.

---

## CacheConfig

Controls TTLs. Defaults to 5 minutes for both items and preview lists.

```python
from letschatty.services.chatty_assets.base_container_with_collection import CacheConfig

config = CacheConfig(
    cache_ttl=60 * 10,          # 10 min for individual items
    preview_cache_ttl=60 * 2,   # 2 min for preview lists
)
service = ProductService(connection=mongo, cache=redis_cache, cache_config=config)
```

---

## AssetService

`AssetService[T, P]` is the generic base every concrete service subclasses. It:
- Accepts a pre-configured `AssetCollection` (knows the collection name, model type, and factory)
- Accepts an optional `CacheProtocol` (defaults to `NoCache`)
- Inherits all async methods from `ChattyAssetContainerWithCollection`

Concrete services add only:
- **Event config** — class-level `asset_type_enum`, `event_type_created`, etc. for automatic event emission
- **Extra methods** — if the asset needs queries beyond the base CRUD

```python
class FastAnswerService(AssetService[ChattyFastAnswer, ChattyAssetPreview]):
    asset_type_enum = CompanyAssetType.FAST_ANSWERS
    event_type_created = EventType.FAST_ANSWER_CREATED
    event_type_updated = EventType.FAST_ANSWER_UPDATED
    event_type_deleted = EventType.FAST_ANSWER_DELETED

    def __init__(self, connection: MongoConnection, cache_config=None):
        collection = FastAnswerCollection(connection)
        super().__init__(collection=collection, cache_config=cache_config)
```

---

## AssetsCollections (read-only, for microservices)

A singleton that gives any microservice read access to all asset types without instantiating individual services.

```python
from letschatty.services.chatty_assets.assets_collections import AssetsCollections

assets = AssetsCollections(MongoConnection())

product = await assets.products.get_by_id("abc123")
tag     = await assets.tags.get_by_id("def456")
```

No caching, no events — raw Motor reads. Use this when you only need to look things up.

---

## Adding a new asset type

Use the `/new-asset-service` slash command to generate all boilerplate automatically.

Manual steps:

**1. Model** — `models/company/assets/<name>.py`
```python
class Widget(CompanyAssetModel):
    sku: str
    price: float

class WidgetPreview(ChattyAssetPreview):
    sku: str

    @classmethod
    def get_projection(cls) -> dict:
        return {"_id": 1, "name": 1, "company_id": 1, "sku": 1, "deleted_at": 1}
```

**2. Collection** — `services/chatty_assets/collections/widget_collection.py`
```python
class WidgetCollection(AssetCollection[Widget, WidgetPreview]):
    def __init__(self, connection: MongoConnection):
        super().__init__(
            collection="widgets",
            asset_type=Widget,
            connection=connection,
            create_instance_method=lambda d: Widget(**d),
            preview_type=WidgetPreview,
        )
```

**3. Service** — `services/chatty_assets/services/widget_service.py`
```python
class WidgetService(AssetService[Widget, WidgetPreview]):
    asset_type_enum = CompanyAssetType.WIDGETS
    event_type_created = EventType.WIDGET_CREATED
    event_type_updated = EventType.WIDGET_UPDATED
    event_type_deleted = EventType.WIDGET_DELETED

    def __init__(self, connection: MongoConnection, cache_config=None):
        super().__init__(collection=WidgetCollection(connection), cache_config=cache_config)
```

**4. Register** — add to `collections/__init__.py` and `assets_collections.py`

---

## What was removed

| Removed | Why |
|---------|-----|
| `base_container.py` (`ChattyAssetBaseContainer`) | Sync + threading — replaced by async `ChattyAssetContainerWithCollection` |
| `get_preview_by_id(id, company_id)` on the base class | O(n) scan of all previews to find one item — catastrophic when called in a loop |
| `threading.Thread` background refresh | Stateful, breaks horizontal scaling |
| `self.items: Dict` / `self.preview_items: List` | Local in-memory state |
| `update_previews_thread()`, `load_from_db_thread()` | Threading-era refresh methods |
