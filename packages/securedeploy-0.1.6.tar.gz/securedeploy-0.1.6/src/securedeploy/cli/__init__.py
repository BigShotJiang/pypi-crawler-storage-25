"""Command-line interface (Click). Import submodules to register commands on ``cli``."""

from __future__ import annotations

from securedeploy.cli.app import cli

# Side-effect: attach commands and groups to ``cli``.
from securedeploy.cli import commands as _commands  # noqa: F401

__all__ = ["cli"]
