from __future__ import annotations

import logging

_LOG_LEVELS: dict[str, int] = {
    "warning": logging.WARNING,
    "debug": logging.DEBUG,
    "info": logging.INFO,
}

CLI_LOG_LEVEL_CHOICES: tuple[str, ...] = tuple(_LOG_LEVELS)


def configure_cli_logging(level_name: str) -> None:
    level = _LOG_LEVELS[level_name.lower()]
    logging.basicConfig(level=level)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
