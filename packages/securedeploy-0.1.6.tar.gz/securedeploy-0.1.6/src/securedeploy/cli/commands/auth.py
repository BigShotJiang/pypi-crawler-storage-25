from __future__ import annotations

import click

from securedeploy.cli.app import cli
from securedeploy.cli.decorators import handle_errors
from securedeploy.cli.output import echo_cli_result


@cli.group()
def auth() -> None:
    """Authenticate with SecureDeploy."""


@auth.command("login")
@click.pass_context
@handle_errors
def auth_login(ctx: click.Context) -> None:
    ctx.obj.auth.login(
        verification_callback=lambda uri: click.echo(
            f"Please go to this URL to authorize: {uri}"
        )
    )
    click.echo("Login successful")


@cli.command("login")
@click.pass_context
@handle_errors
def login_cmd(ctx: click.Context) -> None:
    """Alias for `securedeploy auth login`."""
    ctx.invoke(auth_login)


@auth.command("refresh-token")
@click.pass_context
@handle_errors
def auth_refresh_token(ctx: click.Context) -> None:
    """Exchange the stored refresh token for new tokens."""
    ctx.obj.auth.refresh_token()
    echo_cli_result(ctx, ctx.obj.whoami())
