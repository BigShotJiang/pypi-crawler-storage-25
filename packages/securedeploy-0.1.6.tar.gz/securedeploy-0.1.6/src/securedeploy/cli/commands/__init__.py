"""Click command modules (import for side effects: register commands on ``cli``)."""

from __future__ import annotations

from . import applications as _applications  # noqa: F401
from . import auth as _auth  # noqa: F401
from . import defaults as _defaults  # noqa: F401
from . import init as _init  # noqa: F401
from . import misc as _misc  # noqa: F401
from . import skill as _skill  # noqa: F401
from . import workspaces as _workspaces  # noqa: F401
