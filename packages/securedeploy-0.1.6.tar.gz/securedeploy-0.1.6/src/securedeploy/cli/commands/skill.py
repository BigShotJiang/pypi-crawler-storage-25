from __future__ import annotations

from pathlib import Path

import click
import httpx

from securedeploy.cli.app import cli
from securedeploy.cli.decorators import handle_errors
from securedeploy.cli.output import echo_cli_result
from securedeploy.client.errors import CliError

_SKILL_SOURCE_URL = "https://www.securedeploy.org/SKILL.md"
_SUPPORTED_SKILL_TARGETS = (
    "claude-code",
    "claude",
    "cursor",
    "codex",
    "gemini",
    "google",
    "openclaw",
)


def _skill_dest_path(base_path: Path) -> Path:
    return base_path / ".agents" / "skills" / "securedeploy" / "SKILL.md"


def _target_skill_dirs(base_path: Path) -> dict[str, Path]:
    return {
        "claude": base_path / ".claude" / "skills",
        "claude-code": base_path / ".claude" / "skills",
        "cursor": base_path / ".cursor" / "skills",
        "codex": base_path / ".codex" / "skills",
        "google": base_path / ".gemini" / "skills",
        "gemini": base_path / ".gemini" / "skills",
        "openclaw": base_path / ".openclaw" / "skills",
    }


@cli.group("skill")
def skill_group() -> None:
    """Manage SecureDeploy skills."""


@skill_group.command("install")
@click.argument(
    "target", type=click.Choice(_SUPPORTED_SKILL_TARGETS, case_sensitive=False)
)
@click.option(
    "--project",
    is_flag=True,
    default=False,
    help="Install under current directory instead of home directory.",
)
@click.pass_context
@handle_errors
def install_skill_cmd(ctx: click.Context, target: str, project: bool) -> None:
    """Install SecureDeploy skill file under ~/.agents/skills/securedeploy and symlink to target agent."""
    target = target.lower()
    base_path = Path.cwd() if project else Path.home()
    skill_dest_path = _skill_dest_path(base_path)
    target_skill_dirs = _target_skill_dirs(base_path)

    try:
        response = httpx.get(_SKILL_SOURCE_URL, follow_redirects=True, timeout=30.0)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        raise CliError(
            f"Failed to download skill file: {exc}",
            error="upstream_unreachable",
        ) from exc

    skill_dest_path.parent.mkdir(parents=True, exist_ok=True)
    skill_dest_path.write_text(response.text, encoding="utf-8")
    target_skill_dir = target_skill_dirs[target]
    target_skill_dir.mkdir(parents=True, exist_ok=True)
    symlink_path = target_skill_dir / "securedeploy"

    if symlink_path.exists() or symlink_path.is_symlink():
        if symlink_path.is_dir() and not symlink_path.is_symlink():
            raise CliError(
                f"Cannot create symlink at {symlink_path}: directory already exists."
            )
        symlink_path.unlink()
    symlink_path.symlink_to(skill_dest_path.parent)

    echo_cli_result(
        ctx,
        {
            "target": target,
            "source": _SKILL_SOURCE_URL,
            "installed_to": str(skill_dest_path),
            "symlink_to": str(symlink_path),
            "project": project,
        },
    )
