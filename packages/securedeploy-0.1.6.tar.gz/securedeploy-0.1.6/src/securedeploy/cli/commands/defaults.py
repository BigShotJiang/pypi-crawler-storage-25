from __future__ import annotations

import click

from securedeploy.cli.app import cli
from securedeploy.cli.decorators import handle_errors
from securedeploy.cli.output import echo_cli_result


@cli.group()
def defaults() -> None:
    """Show configured defaults."""


@defaults.command("list")
@click.pass_context
@handle_errors
def defaults_list(ctx: click.Context) -> None:
    echo_cli_result(ctx, ctx.obj.defaults.list())
