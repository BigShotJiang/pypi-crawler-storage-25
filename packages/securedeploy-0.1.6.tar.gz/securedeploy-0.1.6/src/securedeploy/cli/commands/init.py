from __future__ import annotations

import click

from securedeploy import SecureDeploy
from securedeploy.cli.app import cli
from securedeploy.cli.decorators import handle_errors
from securedeploy.cli.output import echo_cli_result
from securedeploy.cli.prompts import (
    ensure_logged_in,
    pick_application_slug,
    pick_workspace_slug,
    prompt_create_application,
    prompt_create_workspace,
)
from securedeploy.client.errors import CliError


@cli.command("init")
@click.pass_context
@handle_errors
def init_cmd(ctx: click.Context) -> None:
    """Interactive setup: log in, default workspace, default application."""
    sd: SecureDeploy = ctx.obj
    click.echo(click.style("SecureDeploy setup", fg="cyan", bold=True))
    user = ensure_logged_in(sd)
    ident = user.get("email") or user.get("id") or "your account"
    click.echo(f"Signed in as {ident}.")
    workspaces = sd.workspaces.list()
    if not workspaces:
        if not click.confirm("No workspaces yet. Create one?", default=True):
            raise CliError(
                "Create a workspace to continue (securedeploy workspaces create).",
                error="cli_usage",
                exit_code=2,
            )
        ws_slug = prompt_create_workspace(sd)
    else:
        ws_slug = pick_workspace_slug(sd, workspaces)
    sd.workspaces.set_default(ws_slug)
    apps = sd.applications.list(workspace=ws_slug)
    if not apps:
        if not click.confirm(
            "No applications in this workspace. Create one?", default=True
        ):
            raise CliError(
                "Create an application to continue (securedeploy applications create).",
                error="cli_usage",
                exit_code=2,
            )
        app_slug = prompt_create_application(sd, ws_slug)
    else:
        app_slug = pick_application_slug(sd, ws_slug, apps)
    sd.applications.set_default(app_slug, workspace=ws_slug)
    click.echo(
        click.style("Setup complete. Configured defaults:", fg="green", bold=True)
    )
    echo_cli_result(ctx, sd.defaults.list())
