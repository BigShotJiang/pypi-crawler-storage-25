from __future__ import annotations

from typing import Optional

import click

from securedeploy.cli.app import cli
from securedeploy.cli.decorators import handle_errors
from securedeploy.cli.option_helps import (
    _ACCESS_EMAIL_OPTION_HELP,
    _ACCESS_WITH_WORKSPACE_OPTION_HELP,
    _WORKSPACE_SLUG_OPTION_HELP,
)
from securedeploy.cli.output import echo_cli_result
from securedeploy.client.application_access import (
    access_target_is_valid,
    normalize_access_email,
)
from securedeploy.client.errors import CliError


@cli.group()
def applications() -> None:
    """Manage applications."""


@applications.command("list")
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.pass_context
@handle_errors
def applications_list(ctx: click.Context, workspace: Optional[str]) -> None:
    echo_cli_result(ctx, ctx.obj.applications.list(workspace=workspace))


@applications.command("get")
@click.argument("slug", required=False)
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.pass_context
@handle_errors
def applications_get(
    ctx: click.Context, slug: Optional[str], workspace: Optional[str]
) -> None:
    app = ctx.obj.applications.get(slug, workspace=workspace)
    echo_cli_result(ctx, app.data)


@applications.command("create")
@click.option("--name", default=None, help="Application display name.")
@click.option("--slug", required=True, help="Application slug.")
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.pass_context
@handle_errors
def applications_create(
    ctx: click.Context,
    name: Optional[str],
    slug: str,
    workspace: Optional[str],
) -> None:
    app = ctx.obj.applications.create(name=name, slug=slug, workspace=workspace)
    echo_cli_result(ctx, app.data)


@applications.command("set-default")
@click.argument("slug")
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.pass_context
@handle_errors
def applications_set_default(
    ctx: click.Context, slug: str, workspace: Optional[str]
) -> None:
    ctx.obj.applications.set_default(slug, workspace=workspace)
    click.echo(f"Default application set to {slug!r}")


def _require_access_target(email: Optional[str], with_workspace: bool) -> None:
    if not access_target_is_valid(email=email, with_workspace=with_workspace):
        raise CliError(
            "Specify exactly one of --email or --with-workspace.",
            error="cli_usage",
            exit_code=2,
        )


@applications.group("access")
def applications_access() -> None:
    """Grant, list, or revoke application access."""


@applications_access.command("grant")
@click.argument("slug", required=False)
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.option("--email", default=None, help=_ACCESS_EMAIL_OPTION_HELP)
@click.option(
    "--with-workspace",
    is_flag=True,
    default=False,
    help=_ACCESS_WITH_WORKSPACE_OPTION_HELP,
)
@click.pass_context
@handle_errors
def applications_access_grant(
    ctx: click.Context,
    slug: Optional[str],
    workspace: Optional[str],
    email: Optional[str],
    with_workspace: bool,
) -> None:
    email = normalize_access_email(email)
    _require_access_target(email, with_workspace)
    echo_cli_result(
        ctx,
        ctx.obj.applications.access.grant(
            slug,
            workspace=workspace,
            email=email,
            with_workspace=with_workspace,
        ),
    )


@applications_access.command("list")
@click.argument("slug", required=False)
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.pass_context
@handle_errors
def applications_access_list(
    ctx: click.Context, slug: Optional[str], workspace: Optional[str]
) -> None:
    echo_cli_result(
        ctx,
        ctx.obj.applications.access.list(slug, workspace=workspace),
    )


@applications_access.command("revoke")
@click.argument("slug", required=False)
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.option("--email", default=None, help=_ACCESS_EMAIL_OPTION_HELP)
@click.option(
    "--with-workspace",
    is_flag=True,
    default=False,
    help=_ACCESS_WITH_WORKSPACE_OPTION_HELP,
)
@click.pass_context
@handle_errors
def applications_access_revoke(
    ctx: click.Context,
    slug: Optional[str],
    workspace: Optional[str],
    email: Optional[str],
    with_workspace: bool,
) -> None:
    email = normalize_access_email(email)
    _require_access_target(email, with_workspace)
    echo_cli_result(
        ctx,
        ctx.obj.applications.access.revoke(
            slug,
            workspace=workspace,
            email=email,
            with_workspace=with_workspace,
        ),
    )
