from __future__ import annotations

from pathlib import Path
from typing import Optional

import click

from securedeploy.cli.app import cli
from securedeploy.cli.decorators import handle_errors
from securedeploy.cli.option_helps import (
    _APPLICATION_SLUG_OPTION_HELP,
    _WORKSPACE_SLUG_OPTION_HELP,
)
from securedeploy.cli.output import echo_cli_result
from securedeploy.cli.upload_paths import (
    _URL_PATH_OPTION_HELP,
    upload_cli_url_path_for_file,
)
from securedeploy.client.errors import CliError
from securedeploy.config.paths import config_file


@cli.command("config")
def config_cmd() -> None:
    """Print path to the config file."""
    click.echo(str(config_file()))


@cli.command("whoami")
@click.pass_context
@handle_errors
def whoami_cmd(ctx: click.Context) -> None:
    echo_cli_result(ctx, ctx.obj.whoami())


@cli.command("upload")
@click.option("--file", type=click.Path(path_type=Path), default=None)
@click.option("--path", type=click.Path(path_type=Path), default=None)
@click.option("--url-path", default=None, help=_URL_PATH_OPTION_HELP)
@click.option("--application", default=None, help=_APPLICATION_SLUG_OPTION_HELP)
@click.option("--workspace", default=None, help=_WORKSPACE_SLUG_OPTION_HELP)
@click.option(
    "--dry",
    is_flag=True,
    default=False,
    help="With --path only: list files and URL paths without uploading.",
)
@click.pass_context
@handle_errors
def upload_cmd(
    ctx: click.Context,
    file: Optional[Path],
    path: Optional[Path],
    url_path: Optional[str],
    application: Optional[str],
    workspace: Optional[str],
    dry: bool,
) -> None:
    if (file is None) == (path is None):
        raise CliError(
            "Specify exactly one of --file or --path.",
            error="cli_usage",
            exit_code=2,
        )
    if dry and file is not None:
        raise CliError(
            "--dry is only supported with --path.",
            error="cli_usage",
            exit_code=2,
        )
    if file is not None:
        url_p = upload_cli_url_path_for_file(file, url_path) if url_path else None
        echo_cli_result(
            ctx,
            ctx.obj.upload.file(
                file, application=application, workspace=workspace, url_path=url_p
            ),
        )
    else:
        echo_cli_result(
            ctx,
            ctx.obj.upload.path(
                path,
                application=application,
                workspace=workspace,
                url_path=url_path,
                dry=dry,
            ),
        )
