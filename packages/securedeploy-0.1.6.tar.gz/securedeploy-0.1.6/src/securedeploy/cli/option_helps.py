from __future__ import annotations

_WORKSPACE_SLUG_OPTION_HELP = "Workspace slug (default: config)."
_APPLICATION_SLUG_OPTION_HELP = "Application slug (default: config)."
_ACCESS_EMAIL_OPTION_HELP = "User email to grant or revoke access for."
_ACCESS_WITH_WORKSPACE_OPTION_HELP = (
    "Grant or revoke access for all members of the application's workspace "
    "(not the same as --workspace, which selects which workspace the app is in)."
)
