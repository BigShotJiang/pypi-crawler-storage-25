from __future__ import annotations

from typing import Any

import click

from securedeploy import SecureDeploy
from securedeploy.client.errors import CliAbort, CliError
from securedeploy.client.schemas import ApplicationResource, WorkspaceResource
from securedeploy.config import ConfigError


def _slug_from_item(item: WorkspaceResource | ApplicationResource) -> str:
    s = item.get("slug")
    return str(s) if s else ""


def ensure_logged_in(sd: SecureDeploy) -> dict[str, Any]:
    try:
        return sd.whoami()
    except ConfigError:
        if not click.confirm(
            "You are not logged in. Start device login now?", default=True
        ):
            raise CliAbort()
        sd.auth.login(
            verification_callback=lambda uri: click.echo(
                f"Please go to this URL to authorize: {uri}"
            )
        )
        return sd.whoami()


def prompt_create_workspace(sd: SecureDeploy) -> str:
    while True:
        slug = click.prompt("Workspace slug", default="", show_default=False).strip()
        if not slug:
            click.echo("Workspace slug is required.")
            continue
        name = (
            click.prompt(
                "Workspace display name (optional, press Enter to skip)",
                default="",
                show_default=False,
            ).strip()
            or None
        )
        ws = sd.workspaces.create(slug=slug, name=name)
        click.echo(f"Created workspace {ws.slug!r}.")
        return ws.slug


def pick_workspace_slug(sd: SecureDeploy, workspaces: list[WorkspaceResource]) -> str:
    if len(workspaces) == 1:
        slug = _slug_from_item(workspaces[0])
        if not slug:
            raise CliError("Workspace has no slug in API response.")
        click.echo(f"Using workspace {slug!r}.")
        return slug
    click.echo("Workspaces:")
    by_num: dict[str, str] = {}
    slugs: set[str] = set()
    for i, ws in enumerate(workspaces, start=1):
        slug = _slug_from_item(ws)
        if not slug:
            continue
        slugs.add(slug)
        by_num[str(i)] = slug
        disp = ws.get("name") or ""
        extra = f" — {disp}" if disp else ""
        click.echo(f"  {i}. {slug}{extra}")
    while True:
        raw = click.prompt("Default workspace (number or slug)", type=str).strip()
        if raw in by_num:
            return by_num[raw]
        if raw in slugs:
            return raw
        click.echo("Invalid choice: enter a list number or a workspace slug.")


def prompt_create_application(sd: SecureDeploy, workspace_slug: str) -> str:
    while True:
        name = (
            click.prompt(
                "Application display name", default="", show_default=False
            ).strip()
            or None
        )
        slug = (
            click.prompt(
                "Application slug (leave empty to auto-generate)",
                default="",
                show_default=False,
            ).strip()
            or None
        )
        if not name and not slug:
            if not click.confirm(
                "Create with auto-generated name and slug?", default=True
            ):
                continue
        app = sd.applications.create(slug=slug, name=name, workspace=workspace_slug)
        click.echo(f"Created application {app.slug!r}.")
        return app.slug


def pick_application_slug(
    sd: SecureDeploy, workspace_slug: str, apps: list[ApplicationResource]
) -> str:
    if len(apps) == 1:
        slug = _slug_from_item(apps[0])
        if not slug:
            raise CliError("Application has no slug in API response.")
        click.echo(f"Using application {slug!r}.")
        return slug
    click.echo("Applications in this workspace:")
    by_num: dict[str, str] = {}
    slugs: set[str] = set()
    for i, app in enumerate(apps, start=1):
        slug = _slug_from_item(app)
        if not slug:
            continue
        slugs.add(slug)
        by_num[str(i)] = slug
        disp = app.get("name") or ""
        extra = f" — {disp}" if disp else ""
        click.echo(f"  {i}. {slug}{extra}")
    while True:
        raw = click.prompt("Default application (number or slug)", type=str).strip()
        if raw in by_num:
            return by_num[raw]
        if raw in slugs:
            return raw
        click.echo("Invalid choice: enter a list number or an application slug.")
