from __future__ import annotations

from pathlib import Path

from securedeploy.client.errors import CliError

_URL_PATH_OPTION_HELP = (
    "Path under the app host URL (after the domain). "
    "With --file: full path including file name (extension must match the file). "
    "With --path: prefix added before each file's path relative to that directory."
)


def upload_cli_url_path_for_file(file: Path, url_path: str) -> str:
    up = url_path.strip()
    if not up:
        raise CliError(
            "--url-path must not be empty.",
            error="cli_usage",
            exit_code=2,
        )
    normalized = up.replace("\\", "/").lstrip("/")
    if normalized.startswith(".."):
        raise CliError(
            "--url-path must not start with '..'.",
            error="cli_usage",
            exit_code=2,
        )
    if "/.." in normalized:
        raise CliError(
            "--url-path must not contain '/..' (parent directory segments).",
            error="cli_usage",
            exit_code=2,
        )
    if normalized.endswith("/"):
        raise CliError(
            "--url-path must not be a directory path (remove trailing '/').",
            error="cli_usage",
            exit_code=2,
        )
    base = Path(normalized).name
    if not base or base in (".", ".."):
        raise CliError(
            "--url-path must include a file name.",
            error="cli_usage",
            exit_code=2,
        )
    ext_file = file.suffix.lower()
    ext_url = Path(normalized).suffix.lower()
    if ext_file != ext_url:
        raise CliError(
            f"--url-path extension must match the file: expected {ext_file!r}, "
            f"got {ext_url!r}.",
            error="cli_usage",
            exit_code=2,
        )
    return normalized
