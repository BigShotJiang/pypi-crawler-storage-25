from __future__ import annotations

import json
from typing import Any

import click

from securedeploy.client.errors import SecureDeployError


def _use_json_output(ctx: click.Context) -> bool:
    return ctx.find_root().meta.get("output_format", "text") == "json"


def _cli_error_payload(exc: BaseException) -> dict[str, Any]:
    if isinstance(exc, SecureDeployError):
        return exc.to_dict()
    return {"error": type(exc).__name__, "description": str(exc)}


def echo_cli_error(ctx: click.Context, exc: BaseException) -> None:
    """Print an error in the same shape as CLI output (text table or JSON) on stderr."""
    data = _cli_error_payload(exc)
    if _use_json_output(ctx):
        click.echo(json.dumps(data, indent=2), err=True)
    else:
        order = (
            "error",
            "description",
            "method",
            "url",
            "status_code",
            "request_content_type",
            "request_body",
            "response_content_type",
            "response_body",
        )
        rows: list[tuple[str, str]] = []
        for key in order:
            if key in data:
                rows.append((key, _format_cell(data[key])))
        for key, value in data.items():
            if key not in order:
                rows.append((key, _format_cell(value)))
        _echo_kv_table(rows, err=True)


def echo_json(data: object) -> None:
    if data is None:
        return
    click.echo(json.dumps(data, indent=2))


def _format_cell(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, separators=(",", ":"))
    return str(value)


def _echo_kv_table(rows: list[tuple[str, str]], *, err: bool = False) -> None:
    if not rows:
        click.echo("(empty)", err=err)
        return
    key_w = max(len(k) for k, _ in rows)
    key_w = max(key_w, len("Field"))
    sep = "  "
    click.echo(f"{'Field'.ljust(key_w)}{sep}Value", err=err)
    click.echo(f"{'-' * key_w}{sep}{'-' * len('Value')}", err=err)
    pad = " " * key_w
    for k, v in rows:
        lines = v.splitlines() or [""]
        click.echo(f"{k.ljust(key_w)}{sep}{lines[0]}", err=err)
        for line in lines[1:]:
            click.echo(f"{pad}{sep}{line}", err=err)


def _echo_human_table(data: object) -> None:
    if data is None:
        return
    if isinstance(data, dict):
        rows = [(str(k), _format_cell(v)) for k, v in data.items()]
        _echo_kv_table(rows)
        return
    if isinstance(data, list):
        if not data:
            click.echo("(empty list)")
            return
        for i, item in enumerate(data, start=1):
            click.echo(f"[{i}]")
            if isinstance(item, dict):
                rows = [(str(k), _format_cell(v)) for k, v in item.items()]
                _echo_kv_table(rows)
            else:
                _echo_kv_table([("value", _format_cell(item))])
            if i < len(data):
                click.echo()
        return
    click.echo(_format_cell(data))


def echo_cli_result(ctx: click.Context, data: object) -> None:
    if data is None:
        return
    if _use_json_output(ctx):
        echo_json(data)
    else:
        _echo_human_table(data)
