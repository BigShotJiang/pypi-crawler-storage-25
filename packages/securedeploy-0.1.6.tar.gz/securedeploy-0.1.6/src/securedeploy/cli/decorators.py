from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Any

import click

from securedeploy.cli.output import echo_cli_error
from securedeploy.client.errors import (
    CliAbort,
    ClientStateError,
    CliError,
    SecureDeployError,
)


def handle_errors(f: Callable[..., Any]) -> Callable[..., Any]:
    @functools.wraps(f)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        ctx = click.get_current_context(silent=True)
        try:
            return f(*args, **kwargs)
        except CliAbort:
            raise click.Abort() from None
        except CliError as exc:
            if ctx is not None:
                echo_cli_error(ctx, exc)
                ctx.exit(exc.exit_code)
            raise
        except SecureDeployError as exc:
            if ctx is not None:
                echo_cli_error(ctx, exc)
                ctx.exit(1)
            raise
        except click.Abort:
            raise
        except click.UsageError as exc:
            if ctx is not None:
                echo_cli_error(ctx, exc)
                ctx.exit(2)
            raise
        # TODO: Log exc with traceback when debugging CLI failures (without duplicating user-facing output).
        except Exception as exc:
            if ctx is not None:
                echo_cli_error(ctx, exc)
                ctx.exit(1)
            if isinstance(exc, SecureDeployError):
                raise
            raise ClientStateError(
                error="unexpected_error", description=str(exc)
            ) from exc

    return wrapper
