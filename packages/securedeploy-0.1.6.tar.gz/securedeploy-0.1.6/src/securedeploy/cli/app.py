from __future__ import annotations

import click

from securedeploy import SecureDeploy
from securedeploy.cli.logger import CLI_LOG_LEVEL_CHOICES, configure_cli_logging


@click.group()
@click.option(
    "--dev",
    is_flag=True,
    help="Use local dev URLs.",
)
@click.option(
    "--output",
    type=click.Choice(["text", "json"], case_sensitive=False),
    default="text",
    show_default=True,
    help="Structured command output format.",
)
@click.option(
    "--log-level",
    type=click.Choice(CLI_LOG_LEVEL_CHOICES, case_sensitive=False),
    default="warning",
    show_default=True,
    help="Python logging level for library diagnostics.",
)
@click.version_option(package_name="securedeploy")
@click.pass_context
def cli(ctx: click.Context, dev: bool, output: str, log_level: str) -> None:
    configure_cli_logging(log_level)

    ctx.meta["output_format"] = output
    ctx.obj = SecureDeploy(env="development" if dev else "production")
