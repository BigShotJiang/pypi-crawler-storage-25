from __future__ import annotations

import codecs
import logging
import mimetypes
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional, Union

import httpx
from charset_normalizer import from_path

from securedeploy.client.errors import ValidationError
from securedeploy.client.http import _send_authenticated_api

if TYPE_CHECKING:
    from securedeploy.client.core import SecureDeploy

logger = logging.getLogger(__name__)

_MAX_UPLOAD_FILE_BYTES = 10 * 1024 * 1024

_UPLOAD_INCLUDE_EXTENSIONS: frozenset[str] = frozenset(
    {
        # HTML / Markup
        ".html",
        ".htm",
        ".xhtml",
        ".shtml",
        # CSS
        ".css",
        # JavaScript
        ".js",
        ".mjs",
        ".cjs",
        ".map",
        ".wasm",
        # Fonts
        ".woff",
        ".woff2",
        ".ttf",
        ".otf",
        # Images
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".webp",
        ".avif",
        ".svg",
        ".ico",
        ".apng",
        # Video
        ".mp4",
        ".webm",
        ".ogv",
        # Audio
        ".mp3",
        ".ogg",
        ".wav",
        ".aac",
        ".opus",
        ".m4a",
        # Data
        ".json",
        ".xml",
        ".csv",
        ".rss",
        ".atom",
        # Manifests
        ".webmanifest",
        # Plain Text
        ".txt",
        ".md",
    }
)

_UPLOAD_IGNORE_FILENAMES: frozenset[str] = frozenset(
    {
        ".git-credentials",
        ".htpasswd",
        ".lesshst",
        ".mysql_history",
        ".netrc",
        ".npmrc",
        ".pgpass",
        ".psql_history",
        ".pypirc",
        ".rediscli_history",
        ".sqlite_history",
        "credentials.json",
        "google-services.json",
        "googleservice-info.plist",
        "id_dsa",
        "id_ecdsa",
        "id_ed25519",
        "id_rsa",
        "local.settings.json",
        "pscredentials.xml",
        "secrets.json",
        "webhook.secret",
    }
)

_UPLOAD_IGNORE_EXTENSIONS: frozenset[str] = frozenset(
    {
        ".der",
        ".jks",
        ".kdbx",
        ".key",
        ".keystore",
        ".ovpn",
        ".p12",
        ".p8",
        ".pem",
        ".pfx",
    }
)

_UPLOAD_IGNORE_DIRECTORIES: frozenset[str] = frozenset(
    {
        ".bzr",
        ".git",
        ".gradle",
        ".hg",
        ".idea",
        ".mypy_cache",
        ".nox",
        ".pytest_cache",
        ".ruff_cache",
        ".svn",
        ".tox",
        ".venv",
        ".vscode",
        "__pycache__",
        "bower_components",
        "node_modules",
        "venv",
    }
)


def _guess_content_type(file_path: Path) -> str:
    try:
        encoding = codecs.lookup(from_path(file_path).best().encoding.lower()).name
        mime_type = mimetypes.guess_type(file_path)[0]
        return f"{mime_type}; charset={encoding}"
    except Exception:
        return "application/octet-stream"


def upload_ignore_reason(file_path: Path) -> Optional[str]:
    name_lower = file_path.name.lower()
    if file_path.suffix.lower() not in _UPLOAD_INCLUDE_EXTENSIONS:
        return f"unsupported extension {file_path.suffix!r}"
    for ancestor in file_path.parents:
        if ancestor.name and ancestor.name.lower() in _UPLOAD_IGNORE_DIRECTORIES:
            return "sensitive directory"
    if name_lower == ".env" or name_lower.startswith(".env."):
        return "sensitive env file (.env*)"
    if name_lower == "credentials" and file_path.parent.name.lower() == ".aws":
        return "AWS credentials file"
    if name_lower in _UPLOAD_IGNORE_FILENAMES:
        return "sensitive filename"
    if file_path.suffix.lower() in _UPLOAD_IGNORE_EXTENSIONS:
        return f"sensitive extension {file_path.suffix!r}"
    return None


class _Upload:
    def __init__(self, client: SecureDeploy) -> None:
        self._client = client

    def file(
        self,
        path: Union[str, Path],
        *,
        application: Optional[str] = None,
        workspace: Optional[str] = None,
        url_path: Optional[str] = None,
    ) -> Any:
        p = Path(path)
        if not p.is_file():
            raise ValidationError(
                f"{p} is not an existing file", error="upload_path_not_file"
            )
        try:
            file_size = p.stat().st_size
        except OSError as e:
            raise ValidationError(
                f"cannot stat {p}: {e}", error="upload_path_stat_error"
            ) from e
        if file_size > _MAX_UPLOAD_FILE_BYTES:
            raise ValidationError(
                f"{p}: file size {file_size} bytes exceeds 10MiB limit",
                error="upload_file_too_large",
            )
        ws = workspace or self._client._default_workspace_slug()
        app = application or self._client._default_application_slug()
        upload_path = f"/v1/workspaces/{ws}/applications/{app}/upload"

        def _post_upload(reauth: bool = True) -> Any:
            def do_request(
                client: httpx.Client, url: str, headers: dict[str, str]
            ) -> httpx.Response:
                with p.open("rb") as f:
                    parts: list[tuple[str, Any]] = []
                    if url_path is not None:
                        parts.append(("url_path", (None, url_path)))
                    parts.append(("file", (p.name, f, _guess_content_type(p))))
                    return client.post(url, headers=headers, files=parts)

            return _send_authenticated_api(
                api_base_url=self._client._config.api_base_url,
                path=upload_path,
                method="POST",
                auth=self._client.auth,
                bearer_token=self._client._config.get_access_token(),
                timeout=120.0,
                do_request=do_request,
                retry=(lambda: _post_upload(False)) if reauth else None,
            )

        return _post_upload()

    def path(
        self,
        dir_path: Union[str, Path],
        *,
        application: Optional[str] = None,
        workspace: Optional[str] = None,
        url_path: Optional[str] = None,
        dry: bool = False,
    ) -> list[Any]:
        root = Path(dir_path)
        if not root.is_dir():
            raise ValidationError(
                f"{root} is not an existing directory",
                error="upload_path_not_directory",
            )
        prefix = (url_path or "").strip().replace("\\", "/").strip("/")
        results: list[Any] = []
        for file_path in root.rglob("*"):
            if not file_path.is_file():
                continue
            skip_reason = upload_ignore_reason(file_path)
            if skip_reason is not None:
                logger.info(f"Skipped {file_path}: {skip_reason}")
                continue
            try:
                size = file_path.stat().st_size
            except OSError as e:
                logger.warning(f"Skipped {file_path}: cannot read file metadata ({e})")
                continue
            if size > _MAX_UPLOAD_FILE_BYTES:
                logger.warning(
                    f"Skipped {file_path}: exceeds 10MiB limit "
                    f"({size} bytes > {_MAX_UPLOAD_FILE_BYTES} bytes)"
                )
                continue
            rel = file_path.relative_to(root).as_posix()
            dest = f"{prefix}/{rel}" if prefix else rel
            if dry:
                results.append(
                    {
                        "file_path": str(file_path),
                        "url_path": dest,
                        "content_type": _guess_content_type(file_path),
                    },
                )
            else:
                results.append(
                    self.file(
                        file_path,
                        application=application,
                        workspace=workspace,
                        url_path=dest,
                    )
                )
        return results
