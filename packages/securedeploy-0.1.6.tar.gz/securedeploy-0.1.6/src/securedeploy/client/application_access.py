from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from securedeploy.client.errors import ValidationError

if TYPE_CHECKING:
    from securedeploy.client.core import SecureDeploy


def normalize_access_email(email: Optional[str]) -> Optional[str]:
    if email is None:
        return None
    stripped = email.strip()
    return stripped if stripped else None


def access_target_is_valid(*, email: Optional[str], with_workspace: bool) -> bool:
    return bool(email) != with_workspace


def _access_target_body(
    *,
    email: Optional[str],
    with_workspace: bool,
) -> dict[str, Any]:
    email = normalize_access_email(email)
    if not access_target_is_valid(email=email, with_workspace=with_workspace):
        raise ValidationError(
            "Specify exactly one of email= or with_workspace=True.",
            error="missing_access_target",
        )
    if email:
        return {"email": email}
    return {"with_workspace": True}


class _Access:
    def __init__(self, client: SecureDeploy) -> None:
        self._client = client

    def _resolve(
        self, slug: Optional[str], workspace: Optional[str]
    ) -> tuple[str, str]:
        if slug is None:
            app_slug = self._client._default_application_slug()
            ws = (
                self._client._default_application_workspace_slug()
                or self._client._default_workspace_slug()
            )
        else:
            app_slug = slug.strip()
            if not app_slug:
                raise ValidationError(
                    "Application slug must be non-empty.",
                    error="missing_slug",
                )
            ws = workspace or self._client._default_workspace_slug()
        return ws, app_slug

    def _path(self, workspace_slug: str, application_slug: str) -> str:
        return f"/v1/workspaces/{workspace_slug}/applications/{application_slug}/access"

    def grant(
        self,
        slug: Optional[str] = None,
        *,
        workspace: Optional[str] = None,
        email: Optional[str] = None,
        with_workspace: bool = False,
    ) -> Any:
        ws, app_slug = self._resolve(slug, workspace)
        body = _access_target_body(email=email, with_workspace=with_workspace)
        return self._client._request("POST", self._path(ws, app_slug), json=body)

    def list(
        self,
        slug: Optional[str] = None,
        *,
        workspace: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        ws, app_slug = self._resolve(slug, workspace)
        return self._client._request("GET", self._path(ws, app_slug))

    def revoke(
        self,
        slug: Optional[str] = None,
        *,
        workspace: Optional[str] = None,
        email: Optional[str] = None,
        with_workspace: bool = False,
    ) -> Any:
        ws, app_slug = self._resolve(slug, workspace)
        body = _access_target_body(email=email, with_workspace=with_workspace)
        return self._client._request("DELETE", self._path(ws, app_slug), json=body)


class _ScopedAccess:
    def __init__(self, client: SecureDeploy, workspace_slug: str) -> None:
        self._client = client
        self._workspace = workspace_slug

    def grant(
        self,
        slug: Optional[str] = None,
        *,
        email: Optional[str] = None,
        with_workspace: bool = False,
    ) -> Any:
        return self._client.applications.access.grant(
            slug,
            workspace=self._workspace,
            email=email,
            with_workspace=with_workspace,
        )

    def list(self, slug: Optional[str] = None) -> list[dict[str, Any]]:
        return self._client.applications.access.list(slug, workspace=self._workspace)

    def revoke(
        self,
        slug: Optional[str] = None,
        *,
        email: Optional[str] = None,
        with_workspace: bool = False,
    ) -> Any:
        return self._client.applications.access.revoke(
            slug,
            workspace=self._workspace,
            email=email,
            with_workspace=with_workspace,
        )
