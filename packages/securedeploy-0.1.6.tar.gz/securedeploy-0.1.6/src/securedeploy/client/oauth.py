from __future__ import annotations

import time
from typing import Any

import httpx

from securedeploy.client.errors import SecureDeployError
from securedeploy.config import Config


class OAuthFailure(SecureDeployError):
    def __init__(
        self,
        description: str,
        *,
        error: str = "oauth_failure",
    ) -> None:
        super().__init__(error=error, description=description)


class OAuthTokenExpired(SecureDeployError):
    def __init__(
        self,
        description: str = "Token expired: Please login again.",
    ) -> None:
        super().__init__(
            error="oauth_token_expired",
            description=description,
        )


class OAuth:
    def __init__(self, cfg: Config) -> None:
        self._cfg = cfg
        self.client_id = self._cfg.oauth_client_id
        base = self._cfg.auth_base_url.rstrip("/")
        self.device_code_endpoint = f"{base}/device/code"
        self.token_endpoint = f"{base}/token"
        self.interval = 5

    def create_device_code(self) -> dict[str, Any]:
        response = httpx.post(
            self.device_code_endpoint,
            data={"client_id": self.client_id, "scope": "openid profile email"},
            headers={
                "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
            },
        )
        if response.status_code != 200:
            raise OAuthFailure(
                f"Failed to create device code: {response.text}",
                error="oauth_device_code_failed",
            )
        payload: dict[str, Any] = response.json()
        self.interval = payload.get("interval", 5)
        self.device_code = payload.get("device_code")
        self.user_code = payload.get("user_code")
        self.expires_in = payload.get("expires_in")
        self.verification_uri = payload.get("verification_uri")
        return payload

    def poll_for_token(self) -> dict[str, Any]:
        # TODO: Bound poll duration; guard response.json() (non-JSON / empty bodies) with OAuthFailure.
        while True:
            response = httpx.post(
                self.token_endpoint,
                data={
                    "client_id": self.client_id,
                    "device_code": self.device_code,
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                },
                headers={
                    "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
                },
            )
            response_json = response.json()
            if response.status_code == 200:
                return response_json
            elif response.status_code == 400:
                if response_json.get("error") == "authorization_pending":
                    time.sleep(self.interval)
                elif response_json.get("error") == "slow_down":
                    self.interval *= 2
                    time.sleep(self.interval)
                elif response_json.get("error") == "expired_token":
                    raise OAuthTokenExpired("Token expired: Please login again.")
                else:
                    raise OAuthFailure(
                        f"Failed to poll for token: {response.text}",
                        error="oauth_token_poll_failed",
                    )
            else:
                raise OAuthFailure(
                    f"Failed to poll for token: {response.text}",
                    error="oauth_token_poll_failed",
                )

    def refresh_access_token(self) -> dict[str, Any]:
        response = httpx.post(
            self.token_endpoint,
            data={
                "client_id": self.client_id,
                "grant_type": "refresh_token",
                "refresh_token": self._cfg.get_refresh_token(),
            },
            headers={
                "Content-Type": "application/x-www-form-urlencoded; charset=utf-8"
            },
        )
        if response.status_code != 200:
            raise OAuthFailure(
                f"Failed to refresh access token: {response.text}",
                error="oauth_refresh_failed",
            )
        return response.json()
