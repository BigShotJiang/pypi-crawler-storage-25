from __future__ import annotations

import logging
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from json import dumps
from typing import Any, Optional, Protocol

import httpx
from httpx import ConnectError, RequestNotRead, TimeoutException

from securedeploy.client.errors import (
    HttpResponseError,
    ResourceNotFoundError,
    UnauthorizedError,
    UpstreamConnectError,
    UpstreamTimeoutError,
)

logger = logging.getLogger(__name__)

_UPSTREAM_REQUEST_USER_MESSAGE = (
    "Please check your connection and try again. \n\n"
    "If the problem persists, please contact support at support@securedeploy.org. \n"
    "Please include the following information in your support request: \n"
    "Error details: {details}."
)


class _SupportsTokenRefresh(Protocol):
    def refresh_token(self) -> None: ...


@contextmanager
def upstream_request_guard() -> Iterator[None]:
    try:
        yield
    except ConnectError as e:
        raise UpstreamConnectError(
            "Upstream API is not reachable; \n"
            + _UPSTREAM_REQUEST_USER_MESSAGE.format(details=e)
        ) from e
    except TimeoutException as e:
        raise UpstreamTimeoutError(
            "Upstream API has timed out; \n"
            + _UPSTREAM_REQUEST_USER_MESSAGE.format(details=e)
        ) from e


def _request_body_text(req: httpx.Request) -> str:
    try:
        data = req.content
    except RequestNotRead:
        return "<multipart or streaming request body not captured>"
    if not data:
        return ""
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("utf-8", errors="replace")


def _response_body_text(r: httpx.Response) -> str:
    ct = r.headers.get("content-type", "").lower()
    if r.content and "json" in ct:
        try:
            return dumps(r.json(), indent=2)
        except ValueError:
            return r.text
    return r.text


def _http_api_error_fields(r: httpx.Response) -> dict[str, Any]:
    req = r.request
    resp_ct = r.headers.get("content-type")
    return {
        "url": str(req.url),
        "method": req.method,
        "request_content_type": req.headers.get("content-type"),
        "request_body": _request_body_text(req),
        "status_code": r.status_code,
        "response_content_type": resp_ct if resp_ct is not None else None,
        "response_body": _response_body_text(r),
    }


def _send_authenticated_api(
    *,
    api_base_url: str,
    path: str,
    method: str,
    auth: _SupportsTokenRefresh,
    bearer_token: str,
    timeout: float,
    do_request: Callable[[httpx.Client, str, dict[str, str]], httpx.Response],
    retry: Optional[Callable[[], Any]] = None,
) -> Any:
    """URL + Bearer, upstream guard, httpx client, JSON body or mapped API errors."""
    url = f"{api_base_url.rstrip('/')}{path}"
    headers = {"Authorization": f"Bearer {bearer_token}"}
    with upstream_request_guard(), httpx.Client(timeout=timeout) as client:
        r = do_request(client, url, headers)
    if r.status_code >= 400:
        return _handle_api_error_response(r, method, path, auth, retry)
    if not r.content:
        return None
    return r.json()


def _handle_api_error_response(
    r: httpx.Response,
    method: str,
    path: str,
    auth: _SupportsTokenRefresh,
    retry: Optional[Callable[[], Any]],
) -> Any:
    fields = _http_api_error_fields(r)
    if r.status_code == 404:
        raise ResourceNotFoundError(**fields)
    if r.status_code == 401:
        if retry is None:
            raise UnauthorizedError(**fields)
        logger.info("Refreshing access token")
        auth.refresh_token()
        return retry()
    raise HttpResponseError(**fields)
