from __future__ import annotations

from collections.abc import Callable
from typing import Any, Literal, Optional, Union

from securedeploy.client.applications import _Applications
from securedeploy.client.auth import _Auth
from securedeploy.client.defaults import _Defaults
from securedeploy.client.errors import ClientStateError
from securedeploy.client.http import _send_authenticated_api
from securedeploy.client.upload import _Upload
from securedeploy.client.workspaces import _Workspaces
from securedeploy.config import Config
from securedeploy.config.document import (
    APPLICATION,
    APPLICATION_WORKSPACE,
    WORKSPACE,
    profile_default,
)
from securedeploy.config.toml_io import save_mapping


class SecureDeploy:
    """Client for the securedeploy.org API; mirrors CLI command groups."""

    def __init__(
        self, env: Literal["development", "production"] = "production"
    ) -> None:
        if env == "development":
            self._config = Config(
                api_base_url="https://api.securedeploy.dev",
                auth_base_url="https://auth.securedeploy.dev",
            )
        else:
            self._config = Config()
        self.auth = _Auth(self)
        self.workspaces = _Workspaces(self)
        self.applications = _Applications(self)
        self.defaults = _Defaults(self)
        self.upload = _Upload(self)

    def whoami(self) -> dict[str, Any]:
        # TODO: Replace dict[str, Any] with a TypedDict or small model (align with Application/Workspace).
        users = self._request("GET", "/v1/users")
        if not users:
            raise ClientStateError(
                error="user_details_not_found",
                description="Failed to get user details",
            )
        return users[0]

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, Any]] = None,
        reauth: bool = True,
    ) -> Any:
        retry: Optional[Callable[[], Any]] = (
            (
                lambda: self._request(
                    method, path, json=json, params=params, reauth=False
                )
            )
            if reauth
            else None
        )
        return _send_authenticated_api(
            api_base_url=self._config.api_base_url,
            path=path,
            method=method,
            auth=self.auth,
            bearer_token=self._config.get_access_token(),
            timeout=60.0,
            do_request=lambda c, url, h: c.request(
                method, url, headers=h, json=json, params=params
            ),
            retry=retry,
        )

    def _save_config(self) -> None:
        save_mapping(self._config.config_file, self._config.config)

    def _default_workspace_slug(self) -> str:
        slug = profile_default(self._config.config).get(WORKSPACE)
        if not slug:
            raise ClientStateError(
                error="no_default_workspace",
                description="No default workspace; set one or pass workspace=",
            )
        elif not isinstance(slug, str):
            raise ClientStateError(
                error="no_default_workspace",
                description="No default workspace; set one or pass workspace=",
            )
        elif slug.strip() == "":
            raise ClientStateError(
                error="no_default_workspace",
                description="No default workspace; set one or pass workspace=",
            )
        else:
            return slug.strip()

    def _default_application_slug(self) -> str:
        slug = profile_default(self._config.config).get(APPLICATION)
        if not slug:
            raise ClientStateError(
                error="no_default_application",
                description="No default application; set one or pass application=",
            )
        elif not isinstance(slug, str):
            raise ClientStateError(
                error="no_default_application",
                description="No default application; set one or pass application=",
            )
        elif slug.strip() == "":
            raise ClientStateError(
                error="no_default_application",
                description="No default application; set one or pass application=",
            )
        else:
            return slug.strip()

    def _default_application_workspace_slug(self) -> Union[str, None]:
        slug = profile_default(self._config.config).get(APPLICATION_WORKSPACE)
        if not slug:
            return None
        elif not isinstance(slug, str):
            return None
        elif slug.strip() == "":
            return None
        else:
            return slug.strip()
