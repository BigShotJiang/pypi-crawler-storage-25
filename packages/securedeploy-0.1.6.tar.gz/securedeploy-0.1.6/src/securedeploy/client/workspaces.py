from __future__ import annotations

from typing import TYPE_CHECKING, Any, Optional

from securedeploy.client.applications import _ScopedApplications
from securedeploy.client.errors import InvalidApiResponseError, ValidationError
from securedeploy.client.schemas import (
    WorkspaceResource,
    as_workspace_resource,
    coerce_workspace_list,
)
from securedeploy.config.document import WORKSPACE, profile_default

if TYPE_CHECKING:
    from securedeploy.client.core import SecureDeploy


class _Workspaces:
    def __init__(self, client: SecureDeploy) -> None:
        self._client = client

    def list(self) -> list[WorkspaceResource]:
        raw = self._client._request("GET", "/v1/workspaces")
        return coerce_workspace_list(raw)

    def get(self, slug: str) -> Workspace:
        data = self._client._request("GET", f"/v1/workspaces/{slug}")
        payload = data if isinstance(data, dict) else {}
        return Workspace(self._client, slug, payload)

    def get_default(self) -> Workspace:
        slug = self._client._default_workspace_slug()
        return self.get(slug)

    def set_default(self, slug: str) -> None:
        self.get(slug)
        profile_default(self._client._config.config)[WORKSPACE] = slug
        self._client._save_config()

    def create(
        self,
        *,
        slug: str,
        name: Optional[str] = None,
    ) -> Workspace:
        ws_slug = slug.strip()
        if not ws_slug:
            raise ValidationError(
                "workspaces.create requires a non-empty slug",
                error="missing_slug",
            )
        body: dict[str, Any] = {"slug": ws_slug}
        if name is not None:
            n = name.strip()
            if n:
                body["name"] = n
        data = self._client._request("POST", "/v1/workspaces", json=body)
        if not isinstance(data, dict):
            raise InvalidApiResponseError(
                "Unexpected API response for workspace create"
            )
        ws_slug = str(data.get("slug") or ws_slug or "")
        if not ws_slug:
            raise InvalidApiResponseError("API did not return a workspace slug")
        return Workspace(self._client, ws_slug, data)


class Workspace:
    # TODO: Field accessors duplicate Application; extract a small shared resource-view helper.

    def __init__(self, client: SecureDeploy, slug: str, data: dict[str, Any]) -> None:
        self._client = client
        self.slug = slug
        self._data = as_workspace_resource(data if isinstance(data, dict) else {})

    @property
    def data(self) -> WorkspaceResource:
        return self._data

    @property
    def id(self) -> str | None:
        v = self._data.get("id")
        return str(v) if v is not None else None

    @property
    def created_at(self) -> str | None:
        v = self._data.get("created_at")
        return str(v) if v is not None else None

    @property
    def updated_at(self) -> str | None:
        v = self._data.get("updated_at")
        return str(v) if v is not None else None

    @property
    def created_by(self) -> str | None:
        v = self._data.get("created_by")
        return str(v) if v is not None else None

    @property
    def name(self) -> str | None:
        if "name" not in self._data:
            return None
        v = self._data["name"]
        return None if v is None else str(v)

    @property
    def auth_domain(self) -> str | None:
        if "auth_domain" not in self._data:
            return None
        v = self._data["auth_domain"]
        return None if v is None else str(v)

    @property
    def applications(self) -> _ScopedApplications:
        return _ScopedApplications(self._client, self.slug)
