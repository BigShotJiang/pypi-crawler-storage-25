"""Workspace API resource shape (JSON: UUIDs and datetimes are strings)."""

from __future__ import annotations

from typing import Any, TypedDict, cast


class _WorkspaceCore(TypedDict):
    id: str
    created_at: str
    updated_at: str
    created_by: str
    slug: str


class _WorkspaceOptional(TypedDict, total=False):
    name: str | None
    auth_domain: str | None


class WorkspaceResource(_WorkspaceCore, _WorkspaceOptional):
    """Workspace object as returned by the API."""


def as_workspace_resource(data: dict[str, Any]) -> WorkspaceResource:
    return cast(WorkspaceResource, data)


def coerce_workspace_list(raw: Any) -> list[WorkspaceResource]:
    if not isinstance(raw, list):
        return []
    return [as_workspace_resource(x) for x in raw if isinstance(x, dict)]
