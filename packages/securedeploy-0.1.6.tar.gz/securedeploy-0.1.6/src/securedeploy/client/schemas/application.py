"""Application API resource shape (JSON: UUIDs and datetimes are strings)."""

from __future__ import annotations

from typing import Any, TypedDict, cast


class _ApplicationCore(TypedDict):
    id: str
    type: str
    created_at: str
    updated_at: str
    created_by: str
    slug: str


class _ApplicationOptional(TypedDict, total=False):
    name: str | None


class ApplicationResource(_ApplicationCore, _ApplicationOptional):
    """Application object as returned by the API."""


def as_application_resource(data: dict[str, Any]) -> ApplicationResource:
    return cast(ApplicationResource, data)


def coerce_application_list(raw: Any) -> list[ApplicationResource]:
    if not isinstance(raw, list):
        return []
    return [as_application_resource(x) for x in raw if isinstance(x, dict)]
