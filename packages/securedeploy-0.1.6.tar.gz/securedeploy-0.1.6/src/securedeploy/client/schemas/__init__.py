"""Typed API resource schemas (JSON payloads)."""

from securedeploy.client.schemas.application import (
    ApplicationResource,
    as_application_resource,
    coerce_application_list,
)
from securedeploy.client.schemas.workspace import (
    WorkspaceResource,
    as_workspace_resource,
    coerce_workspace_list,
)

__all__ = [
    "ApplicationResource",
    "WorkspaceResource",
    "as_application_resource",
    "as_workspace_resource",
    "coerce_application_list",
    "coerce_workspace_list",
]
