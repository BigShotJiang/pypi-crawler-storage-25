from __future__ import annotations

import logging
import webbrowser
from typing import TYPE_CHECKING, Callable, Optional

from securedeploy.client.oauth import OAuth, OAuthFailure

if TYPE_CHECKING:
    from securedeploy.client.core import SecureDeploy

logger = logging.getLogger(__name__)


class _Auth:
    def __init__(self, client: SecureDeploy) -> None:
        self._client = client

    def login(self, verification_callback: Optional[Callable] = None) -> None:
        oauth = OAuth(self._client._config)
        response = oauth.create_device_code()
        verification_uri = response.get("verification_uri")
        if verification_uri:
            logger.info(f"Please go to this URL to authorize:\n{verification_uri}")
            if verification_callback:
                verification_callback(verification_uri)
            webbrowser.open(str(verification_uri))
        tokens = oauth.poll_for_token()
        access_token = tokens.get("access_token")
        refresh_token = tokens.get("refresh_token")
        if not isinstance(access_token, str) or not isinstance(refresh_token, str):
            raise OAuthFailure(
                "Login response missing access_token or refresh_token",
                error="oauth_token_invalid",
            )
        self._client._config.set_tokens(access_token, refresh_token)

    def refresh_token(self) -> None:
        oauth = OAuth(self._client._config)
        tokens = oauth.refresh_access_token()
        access_token = tokens.get("access_token")
        refresh_token = tokens.get("refresh_token")
        if not isinstance(access_token, str) or not isinstance(refresh_token, str):
            raise OAuthFailure(
                "Refresh response missing access_token or refresh_token",
                error="oauth_token_invalid",
            )
        self._client._config.set_tokens(access_token, refresh_token)
