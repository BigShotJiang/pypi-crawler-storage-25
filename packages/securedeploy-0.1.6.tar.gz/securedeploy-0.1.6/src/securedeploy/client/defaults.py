from __future__ import annotations

from typing import TYPE_CHECKING, Any

from securedeploy.config.document import (
    APPLICATION,
    APPLICATION_WORKSPACE,
    WORKSPACE,
    profile_default,
)

if TYPE_CHECKING:
    from securedeploy.client.core import SecureDeploy


class _Defaults:
    def __init__(self, client: SecureDeploy) -> None:
        self._client = client

    def list(self) -> dict[str, Any]:
        prof = profile_default(self._client._config.config)
        return {
            "workspace": prof.get(WORKSPACE),
            "application": prof.get(APPLICATION),
            "application_workspace": prof.get(APPLICATION_WORKSPACE),
        }
