from __future__ import annotations

import os
from typing import Any, Optional

from securedeploy.config.document import (
    ACCESS_TOKEN,
    REFRESH_TOKEN,
    StoredConfigView,
    session_default,
)
from securedeploy.config.errors import ConfigError
from securedeploy.config.paths import config_file, ensure_config_file
from securedeploy.config.toml_io import load_mapping, save_mapping

__all__ = ["Config", "ConfigError"]


class Config:
    """Runtime URLs + on-disk TOML state (tokens and CLI defaults)."""

    def __init__(
        self,
        *,
        api_base_url: Optional[str] = None,
        auth_base_url: Optional[str] = None,
    ) -> None:
        self.api_base_url = api_base_url or "https://api.securedeploy.org"
        self.auth_base_url = auth_base_url or "https://auth.securedeploy.org"
        self.oauth_client_id = os.getenv(
            "SECUREDEPLOY_OAUTH_CLIENT_ID", "27r2dr2ei9vagomf4096gcsdf5"
        )
        self.config_file = config_file()
        ensure_config_file(self.config_file)
        self._data: dict[str, Any] = {}
        self._view = StoredConfigView(self._data)
        self.reload_config()

    @property
    def config(self) -> dict[str, Any]:
        return self._data

    def get_access_token(self) -> str:
        return self._view.require_access_token()

    def get_refresh_token(self) -> str:
        return self._view.require_refresh_token()

    def set_tokens(self, access_token: str, refresh_token: str) -> None:
        sd = session_default(self._data)
        sd[ACCESS_TOKEN] = access_token
        sd[REFRESH_TOKEN] = refresh_token
        save_mapping(self.config_file, self._data)
        self.reload_config()

    def reload_config(self) -> None:
        self._data = load_mapping(self.config_file)
        self._view = StoredConfigView(self._data)
