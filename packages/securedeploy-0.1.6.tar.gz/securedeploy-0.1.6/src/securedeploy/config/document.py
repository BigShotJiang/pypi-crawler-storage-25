from __future__ import annotations

from typing import Any

from securedeploy.config.errors import ConfigError

# --- TOML layout: [session.default] ---
ACCESS_TOKEN = "access_token"
REFRESH_TOKEN = "refresh_token"

# --- TOML layout: [profile.default] ---
WORKSPACE = "workspace"
APPLICATION = "application"
APPLICATION_WORKSPACE = "application_workspace"


def _nested_table(root: dict[str, Any], key: str) -> dict[str, Any]:
    cur = root.setdefault(key, {})
    if not isinstance(cur, dict):
        cur = {}
        root[key] = cur
    return cur


def session_default(root: dict[str, Any]) -> dict[str, Any]:
    """Mutable ``[session.default]`` table (tokens)."""
    return _nested_table(_nested_table(root, "session"), "default")


def profile_default(root: dict[str, Any]) -> dict[str, Any]:
    """Mutable ``[profile.default]`` table (default workspace / application)."""
    return _nested_table(_nested_table(root, "profile"), "default")


class StoredConfigView:
    """Typed read helpers for ``session.default``; root may be mutated."""

    __slots__ = ("_data",)

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data

    @property
    def mapping(self) -> dict[str, Any]:
        return self._data

    def require_access_token(self) -> str:
        access_token = session_default(self._data).get(ACCESS_TOKEN)
        if not access_token:
            raise ConfigError(
                "No access token found",
                error="no_access_token",
            )
        return str(access_token)

    def require_refresh_token(self) -> str:
        refresh_token = session_default(self._data).get(REFRESH_TOKEN)
        if not refresh_token:
            raise ConfigError(
                "No refresh token found",
                error="no_refresh_token",
            )
        return str(refresh_token)
