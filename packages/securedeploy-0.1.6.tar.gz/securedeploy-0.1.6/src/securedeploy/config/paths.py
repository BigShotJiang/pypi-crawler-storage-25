from pathlib import Path

import click


def config_dir() -> Path:
    return Path(click.get_app_dir("securedeploy"))


def config_file() -> Path:
    return config_dir() / "config.toml"


def ensure_config_file(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.touch(exist_ok=True)
