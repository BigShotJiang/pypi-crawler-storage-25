from securedeploy.client.errors import SecureDeployError


class ConfigError(SecureDeployError):
    def __init__(self, description: str, *, error: str = "config_error") -> None:
        super().__init__(error=error, description=description)
