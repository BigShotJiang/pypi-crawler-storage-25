from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import tomli_w

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib


def load_mapping(path: Path) -> dict[str, Any]:
    content = path.read_text(encoding="utf-8").strip()
    return tomllib.loads(content) if content else {}


def save_mapping(path: Path, data: dict[str, Any]) -> None:
    path.write_text(tomli_w.dumps(data), encoding="utf-8")
