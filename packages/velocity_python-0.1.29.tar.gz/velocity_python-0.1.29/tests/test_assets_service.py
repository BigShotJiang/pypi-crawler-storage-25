from velocity.aws.assets import (
    backfill_asset_records,
    build_asset_key,
    build_backfill_asset_data,
    find_existing_asset,
    list_assets,
    normalize_asset_record,
    upload_image_asset,
)


class FakeRow:
    def __init__(self, data):
        self._data = dict(data)

    def to_dict(self):
        return dict(self._data)


class FakeResult:
    def __init__(self, rows):
        self._rows = rows

    def all(self):
        return [dict(row) for row in self._rows]


class FakeTable:
    def __init__(self, rows=None):
        self.rows = [dict(row) for row in (rows or [])]
        self.last_select = None

    def find(self, where):
        for row in self.rows:
            if all(row.get(key) == value for key, value in where.items()):
                return FakeRow(row)
        return None

    def select(self, where=None, orderby=None, start=None, qty=None):
        self.last_select = {
            "where": where,
            "orderby": orderby,
            "start": start,
            "qty": qty,
        }
        filtered = self.rows
        if where:
            filtered = [row for row in filtered if _matches(row, where)]
        return FakeResult(filtered)

    def upsert(self, data, where):
        existing = self.find(where)
        if existing:
            row = existing.to_dict()
            row.update(data)
            for index, current in enumerate(self.rows):
                if all(current.get(key) == value for key, value in where.items()):
                    self.rows[index] = row
                    break
            return 1
        row = dict(data)
        row.setdefault("sys_id", f"asset-{len(self.rows) + 1}")
        self.rows.append(row)
        return 1


class FakeTx:
    def __init__(self, rows=None):
        self.images = FakeTable(rows)

    def table(self, name):
        assert name == "images"
        return self.images


def test_build_asset_key_sanitizes_path_and_preserves_scope():
    key = build_asset_key(
        client="ACME Org",
        campaign="Spring Gala",
        filename="../Hero/Banner Final.PNG",
        bucket="donate.resources",
    )

    assert key == "//donate.resources/acme-org/spring-gala/hero/banner final.png"


def test_build_asset_key_allows_bucket_root_uploads_without_client_scope():
    key = build_asset_key(
        client=None,
        campaign=None,
        filename="../Profile Image.PNG",
        bucket="donate.resources",
    )

    assert key == "//donate.resources/profile image.png"


def test_normalize_asset_record_maps_existing_images_row():
    asset = normalize_asset_record(
        {
            "sys_id": "img-1",
            "bucket": "donate.resources",
            "key": "client/logo.png",
            "public": True,
            "hash": "abc",
            "width": "320",
            "height": 120,
        }
    )

    assert asset.asset_id == "img-1"
    assert asset.public_url == "https://donate.resources.s3.amazonaws.com/client/logo.png"
    assert asset.width == 320
    assert asset.height == 120


def test_find_existing_asset_prefers_hash_bucket_and_client_scope():
    tx = FakeTx(
        [
            {
                "sys_id": "img-1",
                "bucket": "donate.resources",
                "client": "client-a",
                "hash": "same-hash",
                "key": "client-a/logo.png",
                "url": "https://donate.resources.s3.amazonaws.com/client-a/logo.png",
                "public": True,
            }
        ]
    )

    asset = find_existing_asset(
        tx,
        file_hash="same-hash",
        bucket="donate.resources",
        client="client-a",
    )

    assert asset is not None
    assert asset.asset_id == "img-1"


def test_upload_image_asset_deduplicates_before_uploader_runs():
    raw = b"hello world"
    tx = FakeTx(
        [
            {
                "sys_id": "img-1",
                "bucket": "donate.resources",
                "client": "client-a",
                "hash": "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9",
                "key": "client-a/logo.png",
                "url": "https://donate.resources.s3.amazonaws.com/client-a/logo.png",
                "public": True,
            }
        ]
    )
    calls = []

    def uploader(*args, **kwargs):
        calls.append((args, kwargs))
        raise AssertionError("uploader should not be called when dedupe hits")

    result = upload_image_asset(
        tx,
        source={"data": "data:image/png;base64,aGVsbG8gd29ybGQ=", "file": {"path": "logo.png"}},
        client="client-a",
        bucket="donate.resources",
        uploader=uploader,
    )

    assert calls == []
    assert result.deduplicated is True
    assert result.uploaded is False
    assert result.asset.asset_id == "img-1"


def test_upload_image_asset_persists_uploaded_row_and_returns_normalized_asset():
    tx = FakeTx()

    def uploader(source, **kwargs):
        assert kwargs["key"] == "//donate.resources/client-a/logo.png"
        return {
            "bucket": "donate.resources",
            "key": "client-a/logo.png",
            "url": "https://donate.resources.s3.amazonaws.com/client-a/logo.png",
            "public": True,
            "hash": "new-hash",
            "client": "client-a",
            "name": "logo.png",
        }

    result = upload_image_asset(
        tx,
        source={"data": "data:image/png;base64,aGVsbG8=", "file": {"path": "logo.png"}},
        client="client-a",
        bucket="donate.resources",
        uploader=uploader,
    )

    assert result.uploaded is True
    assert result.deduplicated is False
    assert result.asset.key == "client-a/logo.png"
    assert tx.images.rows[0]["key"] == "client-a/logo.png"


def test_upload_image_asset_supports_clientless_admin_scope():
    tx = FakeTx()

    def uploader(source, **kwargs):
        assert kwargs["key"] == "//donate.resources/profile-image.png"
        return {
            "bucket": "donate.resources",
            "key": "profile-image.png",
            "url": "https://donate.resources.s3.amazonaws.com/profile-image.png",
            "public": True,
            "hash": "admin-hash",
            "name": "profile-image.png",
        }

    result = upload_image_asset(
        tx,
        source={"data": "data:image/png;base64,aGVsbG8=", "file": {"path": "profile-image.png"}},
        client=None,
        bucket="donate.resources",
        uploader=uploader,
    )

    assert result.uploaded is True
    assert result.asset.key == "profile-image.png"
    assert tx.images.rows[0]["key"] == "profile-image.png"


def test_list_assets_applies_thumbnail_filter_and_normalizes_rows():
    tx = FakeTx(
        [
            {
                "sys_id": "img-1",
                "bucket": "donate.resources",
                "client": "client-a",
                "key": "client-a/logo.png",
                "url": "https://donate.resources.s3.amazonaws.com/client-a/logo.png",
                "public": True,
            }
        ]
    )

    assets = list_assets(tx, client="client-a", qty=20)

    assert len(assets) == 1
    assert tx.images.last_select["where"] == {"client": "client-a", "!%key": "%-thumb%"}


def test_build_backfill_asset_data_uses_object_summary_and_metadata():
    row = build_backfill_asset_data(
        "donate.resources",
        {"Key": "client-a/banner.png", "Size": 321, "ETag": '"etag-1"'},
        head_info={"Metadata": {"hash": "sha256-1", "width": "600", "height": "300"}},
    )

    assert row["bucket"] == "donate.resources"
    assert row["key"] == "client-a/banner.png"
    assert row["hash"] == "sha256-1"
    assert row["width"] == 600
    assert row["height"] == 300


def test_backfill_asset_records_skips_existing_and_thumbnail_objects():
    tx = FakeTx(
        [
            {
                "sys_id": "img-1",
                "bucket": "donate.resources",
                "key": "client-a/existing.png",
                "url": "https://donate.resources.s3.amazonaws.com/client-a/existing.png",
                "public": True,
            }
        ]
    )
    objects = [
        {"Key": "client-a/existing.png", "Size": 10, "ETag": '"a"'},
        {"Key": "client-a/new.png", "Size": 11, "ETag": '"b"'},
        {"Key": "client-a/new-thumb.png", "Size": 12, "ETag": '"c"'},
    ]

    inserted, summary = backfill_asset_records(
        tx,
        bucket="donate.resources",
        objects=objects,
    )

    assert len(inserted) == 1
    assert inserted[0].key == "client-a/new.png"
    assert summary.scanned == 3
    assert summary.inserted == 1
    assert summary.skipped_existing == 1
    assert summary.skipped_unsupported == 1


def _matches(row, where):
    for key, value in where.items():
        if key == "!%key":
            assert value == "%-thumb%"
            if "-thumb" in row.get("key", ""):
                return False
            continue
        if key == "%key":
            needle = value.strip("%")
            if needle not in row.get("key", ""):
                return False
            continue
        if row.get(key) != value:
            return False
    return True