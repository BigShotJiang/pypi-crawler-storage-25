from types import SimpleNamespace

import pytest

from velocity.payment.base_adapter import ProcessorError
from velocity.payment.stripe_adapter import StripeAdapter


class FakeSelectResult:
    def __init__(self, row):
        self._row = row

    def one(self):
        return self._row


class FakePaymentProfilesTable:
    def __init__(self, row=None):
        self.row = row
        self.select_calls = []

    def select(self, **kwargs):
        self.select_calls.append(kwargs)
        return FakeSelectResult(self.row)


class FakeTx:
    def __init__(self, row=None):
        self.payment_profiles = FakePaymentProfilesTable(row=row)

    def table(self, table_name):
        assert table_name == "payment_profiles"
        return self.payment_profiles


@pytest.fixture
def adapter():
    return StripeAdapter({"api_key": "sk_test_123", "environment": "test"})


def test_get_or_create_customer_profile_returns_existing_customer(adapter):
    tx = FakeTx(row={"customer_profile_id": "cus_existing"})

    result = adapter.get_or_create_customer_profile(
        tx, {"email_address": "ada@example.com"}
    )

    assert result == {"customer_profile_id": "cus_existing", "created": False}


def test_get_or_create_customer_profile_creates_customer_when_missing(adapter, monkeypatch):
    tx = FakeTx(row=None)
    captured = {}

    def fake_create(**kwargs):
        captured.update(kwargs)
        return SimpleNamespace(id="cus_new")

    monkeypatch.setattr("velocity.payment.stripe_adapter.stripe.Customer.create", fake_create)

    result = adapter.get_or_create_customer_profile(
        tx,
        {
            "email_address": "ada@example.com",
            "first_name": "Ada",
            "last_name": "Lovelace",
        },
    )

    assert result["customer_profile_id"] == "cus_new"
    assert result["created"] is True
    assert captured["email"] == "ada@example.com"
    assert captured["name"] == "Ada Lovelace"


def test_attach_payment_method_attaches_and_sets_default(adapter, monkeypatch):
    retrieved = SimpleNamespace(id="pm_123", customer=None)
    attached = SimpleNamespace(id="pm_123", customer="cus_123")
    customer_modify_calls = []

    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.retrieve",
        lambda payment_method_id, **kwargs: retrieved,
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.attach",
        lambda payment_method_id, customer, **kwargs: attached,
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.Customer.modify",
        lambda customer_id, **kwargs: customer_modify_calls.append((customer_id, kwargs)),
    )

    result = adapter.attach_payment_method(
        tx=None,
        customer_profile_id="cus_123",
        payment_method_id="pm_123",
        payment_data={"email_address": "ada@example.com", "name": "Ada Lovelace"},
    )

    assert result["payment_profile_id"] == "pm_123"
    assert result["customer_profile_id"] == "cus_123"
    assert customer_modify_calls[0][0] == "cus_123"
    assert customer_modify_calls[0][1]["invoice_settings"]["default_payment_method"] == "pm_123"


def test_attach_payment_method_raises_when_attached_to_other_customer(adapter, monkeypatch):
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.retrieve",
        lambda payment_method_id, **kwargs: SimpleNamespace(
            id="pm_123", customer="cus_other"
        ),
    )

    with pytest.raises(ProcessorError, match="already attached"):
        adapter.attach_payment_method(None, "cus_123", "pm_123")


def test_detach_payment_method_detaches_when_customer_present(adapter, monkeypatch):
    detached = SimpleNamespace(id="pm_123", customer=None)
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.retrieve",
        lambda payment_method_id, **kwargs: SimpleNamespace(
            id="pm_123", customer="cus_123"
        ),
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.detach",
        lambda payment_method_id, **kwargs: detached,
    )

    result = adapter.detach_payment_method(None, "pm_123")

    assert result["detached"] is True
    assert result["payment_profile_id"] == "pm_123"


def test_delete_customer_profile_returns_deleted_result(adapter, monkeypatch):
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.Customer.delete",
        lambda customer_profile_id, **kwargs: SimpleNamespace(deleted=True),
    )

    result = adapter.delete_customer_profile(None, "cus_123")

    assert result["deleted"] is True
    assert result["customer_profile_id"] == "cus_123"


def test_charge_stored_payment_method_requires_customer_profile(adapter):
    with pytest.raises(ProcessorError, match="customer_profile_id"):
        adapter.charge_stored_payment_method(
            None,
            {
                "amount": 1050,
                "payment_method": "pm_123",
                "processor_account_id": "acct_123",
            },
        )


def test_charge_stored_payment_method_returns_success_payload(adapter, monkeypatch):
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentIntent.create",
        lambda **kwargs: SimpleNamespace(
            id="pi_123",
            latest_charge="ch_123",
            status="succeeded",
            amount=1050,
            currency="usd",
            application_fee_amount=210,
        ),
    )

    result = adapter.charge_stored_payment_method(
        None,
        {
            "amount": 1050,
            "payment_method": "pm_123",
            "customer_profile_id": "cus_123",
            "processor_account_id": "acct_123",
            "revenue_split_percentage": 20,
            "client_id": "client_1",
        },
    )

    assert result["success"] is True
    assert result["processor_transaction_id"] == "pi_123"
    assert result["processor_charge_id"] == "ch_123"
    assert result["platform_fee"] == 210


def test_authorize_payment_upserts_payment_intent_mirror(adapter, monkeypatch):
    mirrored = []

    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentIntent.create",
        lambda **kwargs: SimpleNamespace(
            id="pi_123",
            latest_charge=None,
            status="requires_capture",
            amount=1050,
            amount_received=0,
            amount_captured=0,
            currency="usd",
            created=1710000000,
            description="Donation",
            customer="cus_123",
            metadata={"client_id": "client_1"},
            charges=SimpleNamespace(data=[]),
        ),
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.upsert_stripe_payment_intent_record",
        lambda tx, payment_intent, source=None: mirrored.append(
            (payment_intent.id, source)
        ),
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.upsert_stripe_charge_record",
        lambda tx, charge, source=None: mirrored.append((charge.id, source)),
    )

    result = adapter.authorize_payment(
        None,
        {
            "amount": 1050,
            "payment_method": "pm_123",
            "processor_account_id": "acct_123",
            "revenue_split_percentage": 20,
            "client_id": "client_1",
        },
    )

    assert result["status"] == "authorized"
    assert mirrored == [
        ("pi_123", "api:stripe_adapter.authorize_payment"),
    ]


def test_attach_payment_method_upserts_stripe_payment_method_mirror(adapter, monkeypatch):
    mirrored = []
    retrieved = SimpleNamespace(
        id="pm_123",
        customer=None,
        type="card",
        card=SimpleNamespace(brand="visa", last4="4242", exp_month=6, exp_year=2030),
        billing_details=SimpleNamespace(name="Ada Lovelace", email="ada@example.com"),
        metadata={},
    )
    attached = SimpleNamespace(
        id="pm_123",
        customer="cus_123",
        type="card",
        card=SimpleNamespace(brand="visa", last4="4242", exp_month=6, exp_year=2030),
        billing_details=SimpleNamespace(name="Ada Lovelace", email="ada@example.com"),
        metadata={},
    )

    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.retrieve",
        lambda payment_method_id, **kwargs: retrieved,
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.PaymentMethod.attach",
        lambda payment_method_id, customer, **kwargs: attached,
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.Customer.modify",
        lambda customer_id, **kwargs: None,
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.upsert_stripe_customer_record",
        lambda tx, customer, source=None: None,
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.upsert_stripe_payment_method_record",
        lambda tx, payment_method, **kwargs: mirrored.append((payment_method.id, kwargs)),
    )

    adapter.attach_payment_method(
        None,
        "cus_123",
        "pm_123",
        {"email_address": "ada@example.com", "name": "Ada Lovelace", "set_default": True},
    )

    assert mirrored == [
        (
            "pm_123",
            {
                "customer_id": "cus_123",
                "email_address": "ada@example.com",
                "is_default": True,
                "detached": False,
                "source": "api:stripe_adapter.attach_payment_method",
            },
        )
    ]


def test_create_account_upserts_account_mirror_before_business_sync(adapter, monkeypatch):
    mirrored = []
    synced = []

    class FakeTable:
        def new(self):
            return {}

    class FakeTx:
        def table(self, table_name):
            assert table_name == "client_onboarding_checklists"
            return FakeTable()

    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.stripe.Account.create",
        lambda **kwargs: SimpleNamespace(
            id="acct_123",
            charges_enabled=False,
            payouts_enabled=False,
            details_submitted=False,
            capabilities=SimpleNamespace(card_payments="active", transfers="active"),
            requirements=SimpleNamespace(
                currently_due=[], eventually_due=[], past_due=[], disabled_reason=None
            ),
            metadata={"client_id": "99"},
        ),
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.upsert_stripe_account_record",
        lambda tx, account, **kwargs: mirrored.append((account.id, kwargs)),
    )
    monkeypatch.setattr(
        "velocity.payment.stripe_adapter.sync_client_payment_account_from_stripe_account",
        lambda tx, account, **kwargs: synced.append((account.id, kwargs)),
    )

    result = adapter.create_account(
        FakeTx(),
        {
            "client_id": 99,
            "business_name": "Ada Academy",
            "email": "ada@example.com",
        },
    )

    assert result["processor_account_id"] == "acct_123"
    assert mirrored == [
        (
            "acct_123",
            {
                "client_id": 99,
                "source": "api:stripe_adapter.create_account",
            },
        )
    ]
    assert synced == [
        (
            "acct_123",
            {
                "client_id": 99,
            },
        )
    ]