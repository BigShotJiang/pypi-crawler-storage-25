from types import SimpleNamespace

from velocity.payment.braintree_adapter import BraintreeAdapter


class FakeChecklistTable:
    def __init__(self):
        self.upserts = []

    def upsert(self, payload, key):
        self.upserts.append((payload, key))


class FakeTx:
    def __init__(self):
        self.checklists = FakeChecklistTable()

    def table(self, table_name):
        assert table_name == "client_onboarding_checklists"
        return self.checklists


def build_adapter():
    return BraintreeAdapter(
        {
            "merchant_id": "merchant",
            "public_key": "public",
            "private_key": "private",
            "environment": "sandbox",
        }
    )


def test_charge_stored_payment_method_success(monkeypatch):
    adapter = build_adapter()
    captured = {}

    def fake_sale(params):
        captured.update(params)
        return SimpleNamespace(
            is_success=True,
            transaction=SimpleNamespace(
                id="txn_123",
                amount="10.50",
                status="submitted_for_settlement",
                currency_iso_code="USD",
                processor_authorization_code="auth_123",
            ),
        )

    monkeypatch.setattr(adapter.gateway.transaction, "sale", fake_sale)

    result = adapter.charge_stored_payment_method(
        None,
        {
            "amount": 1050,
            "payment_method": "token_123",
            "descriptor": {"name": "CARINGCENT"},
            "metadata": {"client_id": "client_1", "campaign_id": "CAMP"},
        },
    )

    assert result["success"] is True
    assert result["processor_transaction_id"] == "txn_123"
    assert result["processor_charge_id"] == "txn_123"
    assert captured["payment_method_token"] == "token_123"
    assert captured["amount"] == "10.50"
    assert captured["descriptor"] == {"name": "CARINGCENT"}
    assert captured["custom_fields"]["client_id"] == "client_1"


def test_charge_stored_payment_method_failure_uses_processor_response(monkeypatch):
    adapter = build_adapter()

    def fake_sale(params):
        return SimpleNamespace(
            is_success=False,
            message="generic error",
            transaction=SimpleNamespace(processor_response_text="declined"),
            errors=SimpleNamespace(deep_errors=[]),
        )

    monkeypatch.setattr(adapter.gateway.transaction, "sale", fake_sale)

    result = adapter.charge_stored_payment_method(
        None,
        {
            "amount": 1050,
            "payment_method": "token_123",
        },
    )

    assert result["success"] is False
    assert result["error_message"] == "declined"


def test_create_account_upserts_braintree_mirror_before_canonical_sync(monkeypatch):
    adapter = build_adapter()
    tx = FakeTx()
    calls = []

    monkeypatch.setattr(
        adapter.gateway.merchant_account,
        "create",
        lambda payload: SimpleNamespace(
            is_success=True,
            merchant_account=SimpleNamespace(
                id="ma_123",
                status="active",
                decline_reason=None,
                master_merchant_account=SimpleNamespace(id="master_123"),
            ),
        ),
        raising=False,
    )
    monkeypatch.setattr(
        "velocity.payment.braintree_adapter.upsert_braintree_merchant_account_record",
        lambda tx, merchant_account, source=None: calls.append(
            ("mirror", merchant_account.id, source)
        ),
    )
    monkeypatch.setattr(
        "velocity.payment.braintree_adapter.sync_client_payment_account_from_braintree_merchant_account",
        lambda tx, merchant_account, client_id=None: calls.append(
            ("sync", merchant_account.id, client_id)
        ),
    )

    result = adapter.create_account(
        tx,
        {
            "client_id": 44,
            "email": "ops@example.com",
            "business_name": "CaringCent School",
        },
    )

    assert result["processor_account_id"] == "ma_123"
    assert calls == [
        ("mirror", "ma_123", "api:braintree_adapter.create_account"),
        ("sync", "ma_123", 44),
    ]
    assert tx.checklists.upserts


def test_charge_stored_payment_method_upserts_braintree_transaction_mirror(
    monkeypatch,
):
    adapter = build_adapter()
    mirrored = []

    monkeypatch.setattr(
        adapter.gateway.transaction,
        "sale",
        lambda params: SimpleNamespace(
            is_success=True,
            transaction=SimpleNamespace(
                id="txn_123",
                amount="10.50",
                status="submitted_for_settlement",
                currency_iso_code="USD",
                processor_authorization_code="auth_123",
            ),
        ),
    )
    monkeypatch.setattr(
        "velocity.payment.braintree_adapter.upsert_braintree_transaction_record",
        lambda tx, transaction, source=None: mirrored.append((transaction.id, source)),
    )

    result = adapter.charge_stored_payment_method(
        None,
        {
            "amount": 1050,
            "payment_method": "token_123",
        },
    )

    assert result["success"] is True
    assert mirrored == [
        ("txn_123", "api:braintree_adapter.charge_stored_payment_method")
    ]