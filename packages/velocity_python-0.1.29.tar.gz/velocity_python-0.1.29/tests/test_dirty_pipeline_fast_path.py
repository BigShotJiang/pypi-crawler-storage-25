import unittest
import importlib.util
from pathlib import Path


MODULE_PATH = (
    Path(__file__).resolve().parents[1]
    / "src"
    / "velocity"
    / "aws"
    / "handlers"
    / "mixins"
    / "data_service.py"
)
MODULE_SPEC = importlib.util.spec_from_file_location("test_data_service_module", MODULE_PATH)
DATA_SERVICE_MODULE = importlib.util.module_from_spec(MODULE_SPEC)
assert MODULE_SPEC and MODULE_SPEC.loader
MODULE_SPEC.loader.exec_module(DATA_SERVICE_MODULE)
DataServiceMixin = DATA_SERVICE_MODULE.DataServiceMixin


class FakeRow:
    def __init__(self, data=None):
        self.data = dict(data or {})
        self.update_calls = []

    def update(self, payload):
        self.update_calls.append(dict(payload))
        self.data.update(payload)

    def to_dict(self):
        return dict(self.data)


class FakeTable:
    def __init__(self, row):
        self.row = row

    def get(self, sys_id):
        return self.row


class FakeTx:
    def __init__(self, row):
        self._table = FakeTable(row)

    def table(self, name):
        return self._table


class FakeContext:
    def __init__(self, feature_flags=None):
        self.feature_flags = feature_flags or {}
        self.enqueued = []

    def get_feature_flags(self, tx):
        return dict(self.feature_flags)

    def enqueue_dirty(self, table, sys_id):
        self.enqueued.append((table, sys_id))


class DirtyHookMixin(DataServiceMixin):
    def __init__(self, hook_tables=None):
        self.hook_tables = set(hook_tables or [])

    def _has_rwx_hook(self, table, hook_name):
        return hook_name == "on_dirty" and table in self.hook_tables


class TestDirtyPipelineFastPath(unittest.TestCase):
    def test_enqueues_hook_bearing_tables(self):
        row = FakeRow({"sys_id": 42, "name": "before"})
        tx = FakeTx(row)
        context = FakeContext()
        service = DirtyHookMixin(hook_tables={"form_builder_template"})

        result = service.write_hook(
            tx,
            "form_builder_template",
            42,
            {"name": "after"},
            context,
        )

        self.assertEqual([("form_builder_template", 42)], context.enqueued)
        self.assertEqual("after", result["name"])
        self.assertNotIn({"sys_dirty": False}, row.update_calls)

    def test_clears_hookless_tables_inline(self):
        row = FakeRow({"sys_id": 7, "name": "before", "sys_dirty": True})
        tx = FakeTx(row)
        context = FakeContext()
        service = DirtyHookMixin()

        result = service.write_hook(tx, "plain_table", 7, {"name": "after"}, context)

        self.assertEqual([], context.enqueued)
        self.assertEqual({"sys_dirty": False}, row.update_calls[-1])
        self.assertFalse(result["sys_dirty"])

    def test_skips_opted_out_tables(self):
        row = FakeRow({"sys_id": 9, "name": "before", "sys_dirty": True})
        tx = FakeTx(row)
        context = FakeContext(
            feature_flags={"dirty_pipeline_excluded_tables": "plain_table\nother_table"}
        )
        service = DirtyHookMixin(hook_tables={"plain_table"})

        result = service.write_hook(tx, "plain_table", 9, {"name": "after"}, context)

        self.assertEqual([], context.enqueued)
        self.assertEqual([{"name": "after"}], row.update_calls)
        self.assertTrue(result["sys_dirty"])


if __name__ == "__main__":
    unittest.main()