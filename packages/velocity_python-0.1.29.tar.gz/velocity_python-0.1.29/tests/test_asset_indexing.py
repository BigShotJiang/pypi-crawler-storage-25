from velocity.aws.assets.indexing import load_asset_usages, resolve_asset_id_for_reference
from velocity.aws.assets.references import AssetReference


class FakeRow:
    def __init__(self, data):
        self._data = dict(data)

    def to_dict(self):
        return dict(self._data)


class FakeResult:
    def __init__(self, rows):
        self._rows = [dict(row) for row in rows]

    def as_dict(self):
        return self

    def all(self):
        return [dict(row) for row in self._rows]


class FakeImagesTable:
    def __init__(self):
        self.calls = []
        self._columns = {"key"}

    def exists(self):
        return True

    def column(self, name):
        table = self

        class FakeColumn:
            def exists(self_nonlocal):
                return name in table._columns

        return FakeColumn()

    def find(self, where):
        self.calls.append(dict(where))
        if where == {"key": "folder/banner.png"}:
            return FakeRow({"sys_id": "img-123"})
        if where == {"url": "https://example.com/banner.png"}:
            raise AssertionError("url lookup should be skipped when the column is absent")
        return None


class FakeUsageIndexTable:
    def exists(self):
        return False

    def select(self, where=None):
        raise AssertionError("select should be skipped when asset_usage_index is missing")


class FakeTx:
    def __init__(self, *, image_table_exists=True, image_columns=None, usage_index_exists=False):
        self.images = FakeImagesTable()
        self.images._exists = image_table_exists
        self.images._columns = set(image_columns or {"key"})
        self.usage_index = FakeUsageIndexTable()
        self.usage_index._exists = usage_index_exists

    def table(self, name):
        if name == "images":
            class ImagesTableProxy(FakeImagesTable):
                pass

            proxy = self.images
            proxy.exists = lambda: proxy._exists
            return proxy
        if name == "asset_usage_index":
            proxy = self.usage_index
            proxy.exists = lambda: proxy._exists
            return proxy
        raise AssertionError(f"Unexpected table request: {name}")


def test_load_asset_usages_returns_empty_when_usage_table_missing():
    tx = FakeTx()

    usages = load_asset_usages(tx, source_table="form_builder_template", source_sys_id="2680")

    assert usages == []


def test_resolve_asset_id_skips_url_lookup_when_images_url_column_missing():
    tx = FakeTx(image_columns={"key"})
    reference = AssetReference(
        asset_id=None,
        url="https://example.com/banner.png",
        storage_key="folder/banner.png",
        source_field="main_image_url",
        source_field_type="image-widget",
        raw_value="https://example.com/banner.png",
    )

    asset_id = resolve_asset_id_for_reference(tx, reference)

    assert asset_id == "img-123"
    assert tx.images.calls == [{"key": "folder/banner.png"}]