import pytest

from velocity.payment.authorizenet_adapter import AuthorizeNetAdapter


class FakeSelectResult:
    def __init__(self, row):
        self._row = row

    def one(self):
        return self._row


class FakePaymentProfilesTable:
    def __init__(self, row=None):
        self.row = row

    def select(self, **kwargs):
        return FakeSelectResult(self.row)


class FakeTx:
    def __init__(self, row=None):
        self.payment_profiles = FakePaymentProfilesTable(row=row)

    def table(self, table_name):
        assert table_name == "payment_profiles"
        return self.payment_profiles


@pytest.fixture
def adapter():
    return AuthorizeNetAdapter(
        {
            "api_login_id": "login",
            "api_transaction_key": "key",
            "endpoint": "https://apitest.authorize.net/xml/v1/request.api",
        }
    )


def test_create_account_upserts_authorize_mirror_before_canonical_sync(adapter, monkeypatch):
    calls = []

    monkeypatch.setattr(
        "velocity.payment.authorizenet_adapter.upsert_authorize_account_record",
        lambda tx, account, source=None: calls.append(
            ("mirror", account["processor_account_id"], source)
        ),
    )
    monkeypatch.setattr(
        "velocity.payment.authorizenet_adapter.sync_client_payment_account_from_authorize_account",
        lambda tx, account, client_id=None: calls.append(
            ("sync", account["processor_account_id"], client_id)
        ),
    )

    result = adapter.create_account(None, {"client_id": 77})

    assert result["processor_account_id"] == "an_77"
    assert calls == [
        ("mirror", "an_77", "api:authorizenet_adapter.create_account"),
        ("sync", "an_77", 77),
    ]


def test_attach_payment_method_upserts_authorize_payment_profile_mirror(
    adapter, monkeypatch
):
    mirrored = []

    monkeypatch.setattr(
        adapter,
        "_execute",
        lambda controller: {"customerPaymentProfileId": "pay_123"},
    )
    monkeypatch.setattr(
        "velocity.payment.authorizenet_adapter.upsert_authorize_payment_profile_record",
        lambda tx, payment_profile, source=None: mirrored.append(
            (payment_profile, source)
        ),
    )

    result = adapter.attach_payment_method(
        None,
        "123",
        "unused",
        {
            "card_number": "4111111111111111",
            "expiration_date": "2030-12",
            "first_name": "Ada",
            "last_name": "Lovelace",
            "set_default": True,
        },
    )

    assert result["payment_profile_id"] == "pay_123"
    assert mirrored == [
        (
            {
                "customer_profile_id": "123",
                "payment_profile_id": "pay_123",
                "last4": "1111",
                "expiration_date": "2030-12",
                "billing_first_name": "Ada",
                "billing_last_name": "Lovelace",
                "billing_address": None,
                "billing_city": None,
                "billing_state": None,
                "billing_zip": None,
                "is_default": True,
                "metadata": {},
            },
            "api:authorizenet_adapter.attach_payment_method",
        )
    ]


def test_authorize_payment_upserts_authorize_transaction_mirror(adapter, monkeypatch):
    mirrored = []

    monkeypatch.setattr(
        adapter,
        "_execute",
        lambda controller: {
            "transactionResponse": {
                "responseCode": "1",
                "transId": "txn_123",
                "authCode": "AUTH123",
            }
        },
    )
    monkeypatch.setattr(
        "velocity.payment.authorizenet_adapter.upsert_authorize_transaction_record",
        lambda tx, transaction, source=None: mirrored.append((transaction, source)),
    )

    result = adapter.authorize_payment(
        None,
        {
            "amount": 1050,
            "payment_method": "456",
            "customer_profile_id": "123",
            "client_id": 77,
            "description": "Campaign X",
            "customer_email": "ada@example.com",
        },
    )

    assert result["status"] == "authorized"
    assert mirrored == [
        (
            {
                "processor_transaction_id": "txn_123",
                "amount": 10.5,
                "status": "authorized",
                "reason_for_transaction": "Campaign X",
                "remote_authcode": "AUTH123",
                "remote_responsecode": 1,
                "supported_id": 77,
                "supported_name": "Campaign X",
                "email_address": "ada@example.com",
                "raw_payload": {
                    "transactionResponse": {
                        "responseCode": "1",
                        "transId": "txn_123",
                        "authCode": "AUTH123",
                    }
                },
            },
            "api:authorizenet_adapter.authorize_payment",
        )
    ]