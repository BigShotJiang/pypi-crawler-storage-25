from velocity.aws.assets import (
    build_asset_usages,
    extract_asset_references_from_html,
    extract_asset_references_from_record,
    extract_asset_references_from_value,
    reconcile_asset_usages,
)


def test_extract_asset_references_from_html_prefers_asset_id_and_dedupes():
    html = """
    <div>
        <img data-asset-id="asset-123" src="https://cdn.example.com/alpha.png" />
        <img data-asset-id="asset-123" src="https://cdn.example.com/alpha.png" />
    </div>
    """

    references = extract_asset_references_from_html(html, source_field="html_template")

    assert len(references) == 1
    assert references[0].asset_id == "asset-123"
    assert references[0].source_field == "html_template"
    assert references[0].source_field_type == "html"


def test_extract_asset_references_from_html_uses_media_url_when_asset_id_missing():
    html = (
        '<img src="https://bucket.s3.amazonaws.com/path/to/banner.png" alt="Banner" />'
    )

    references = extract_asset_references_from_html(html, source_field="receipt_html")

    assert len(references) == 1
    assert references[0].asset_id is None
    assert references[0].url == "https://bucket.s3.amazonaws.com/path/to/banner.png"
    assert references[0].storage_key == "path/to/banner.png"


def test_extract_asset_references_from_value_supports_nested_widget_payloads():
    value = {
        "image": {
            "assetId": "asset-456",
            "url": "https://cdn.example.com/example.png",
            "storageKey": "assets/example.png",
        }
    }

    references = extract_asset_references_from_value(
        value,
        source_field="hero_image",
    )

    assert len(references) == 1
    assert references[0].asset_id == "asset-456"
    assert references[0].storage_key == "assets/example.png"
    assert references[0].source_field_type == "image-widget"


def test_extract_asset_references_from_value_supports_direct_asset_id_strings():
    references = extract_asset_references_from_value(
        "asset-789",
        source_field="logo",
    )

    assert len(references) == 1
    assert references[0].asset_id == "asset-789"
    assert references[0].url is None


def test_extract_asset_references_from_record_keeps_distinct_field_usages():
    record = {
        "html_template": '<img data-asset-id="asset-123" src="https://cdn.example.com/a.png" />',
        "hero_image": {"assetId": "asset-123", "url": "https://cdn.example.com/a.png"},
        "footer_image": "https://bucket.s3.us-east-1.amazonaws.com/public/footer.png",
    }

    references = extract_asset_references_from_record(
        record,
        html_fields=["html_template"],
        image_fields=["hero_image", "footer_image"],
    )

    assert len(references) == 3
    by_field = {reference.source_field: reference for reference in references}
    assert by_field["html_template"].asset_id == "asset-123"
    assert by_field["hero_image"].asset_id == "asset-123"
    assert by_field["footer_image"].storage_key == "public/footer.png"


def test_build_asset_usages_dedupes_to_one_row_per_asset_per_field():
    references = extract_asset_references_from_html(
        '<img data-asset-id="asset-123" src="https://cdn.example.com/a.png" />'
        '<img data-asset-id="asset-123" src="https://cdn.example.com/a.png" />',
        source_field="html_template",
    )

    usages = build_asset_usages(
        references,
        source_table="form_builder_template",
        source_sys_id="row-1",
    )

    assert len(usages) == 1
    assert usages[0].asset_id == "asset-123"
    assert usages[0].source_field == "html_template"
    assert usages[0].source_field_type == "html"


def test_build_asset_usages_can_resolve_url_only_references():
    references = extract_asset_references_from_value(
        "https://bucket.s3.amazonaws.com/path/to/banner.png",
        source_field="hero_image",
    )

    usages = build_asset_usages(
        references,
        source_table="form_builder_template",
        source_sys_id="row-2",
        asset_id_resolver=lambda reference: "asset-from-url"
        if reference.storage_key == "path/to/banner.png"
        else None,
    )

    assert len(usages) == 1
    assert usages[0].asset_id == "asset-from-url"
    assert usages[0].asset_storage_key_snapshot == "path/to/banner.png"


def test_reconcile_asset_usages_is_idempotent_and_field_scoped():
    desired = build_asset_usages(
        extract_asset_references_from_record(
            {
                "html_template": '<img data-asset-id="asset-123" src="https://cdn.example.com/a.png" />',
                "hero_image": {"assetId": "asset-123", "url": "https://cdn.example.com/a.png"},
            },
            html_fields=["html_template"],
            image_fields=["hero_image"],
        ),
        source_table="form_builder_template",
        source_sys_id="row-3",
    )
    existing = [
        usage for usage in desired if usage.source_field == "html_template"
    ]

    reconciliation = reconcile_asset_usages(existing, desired)

    assert [usage.source_field for usage in reconciliation.to_create] == ["hero_image"]
    assert [usage.source_field for usage in reconciliation.to_refresh] == ["html_template"]
    assert reconciliation.to_delete == []


def test_reconcile_asset_usages_deletes_stale_rows():
    existing = build_asset_usages(
        extract_asset_references_from_record(
            {"footer_image": {"assetId": "asset-999", "url": "https://cdn.example.com/footer.png"}},
            image_fields=["footer_image"],
        ),
        source_table="form_builder_template",
        source_sys_id="row-4",
    )

    reconciliation = reconcile_asset_usages(existing, desired=[])

    assert reconciliation.to_create == []
    assert reconciliation.to_refresh == []
    assert [usage.asset_id for usage in reconciliation.to_delete] == ["asset-999"]