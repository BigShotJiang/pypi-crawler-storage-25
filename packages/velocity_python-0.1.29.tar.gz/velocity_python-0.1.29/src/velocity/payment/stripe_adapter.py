"""
Stripe Connect Payment Processor Adapter

Implements the PaymentProcessorAdapter interface for Stripe Connect with Express accounts.

Key Features:
- Express Connected Accounts for client schools
- Destination charges with application_fee_amount for revenue splits
- Two-phase authorization (manual capture)
- Stripe-managed pricing (zero platform fees)
- AccountLinks for hosted onboarding
"""

import stripe
from typing import Dict, Any, Optional
from datetime import datetime, timezone, timedelta
from .base_adapter import PaymentProcessorAdapter, ProcessorError
from .stripe_mirror import (
    sync_client_payment_account_from_stripe_account,
    upsert_stripe_account_record,
    upsert_stripe_charge_record,
    upsert_stripe_customer_record,
    upsert_stripe_payment_intent_record,
    upsert_stripe_payment_method_record,
    upsert_stripe_refund_record,
)


class StripeAdapter(PaymentProcessorAdapter):
    """
    Stripe Connect adapter for payment processing.

    Uses Express accounts with destination charges to handle revenue splits.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize Stripe adapter with API credentials.

        Args:
            config: Dictionary containing:
                - api_key: Stripe secret key (required)
                - publishable_key: Stripe publishable key (optional, for client-side)
                - webhook_secret: Webhook signing secret (optional)
                - environment: 'test' or 'live' (default: 'test')
        """
        super().__init__(config)

        # Store API key per-instance instead of setting global stripe.api_key
        self._api_key = config.get("api_key")
        if not self._api_key:
            raise ValueError("Stripe API key is required in config")

        self.publishable_key = config.get("publishable_key")
        self.webhook_secret = config.get("webhook_secret")
        self.environment = config.get("environment", "test")
        self.platform = config.get("platform")

    # ========================================================================
    # ACCOUNT MANAGEMENT
    # ========================================================================

    def get_or_create_customer_profile(
        self, tx, customer_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Get an existing Stripe customer or create one for vaulted payment methods."""
        try:
            email_address = customer_data["email_address"]
            existing = (
                tx.table("payment_profiles")
                .select(
                    columns=["customer_profile_id"],
                    where={"email_address": email_address, "src": "ST"},
                    orderby="is_default desc, sys_id desc",
                )
                .one()
            )
            if existing and existing.get("customer_profile_id"):
                return {
                    "customer_profile_id": existing["customer_profile_id"],
                    "created": False,
                }

            full_name = customer_data.get("name") or " ".join(
                part
                for part in [
                    customer_data.get("first_name"),
                    customer_data.get("last_name"),
                ]
                if part
            ).strip()

            customer_metadata = {
                "email_address": email_address,
                **(customer_data.get("metadata") or {}),
            }
            if self.platform:
                customer_metadata["platform"] = str(self.platform)

            customer = stripe.Customer.create(
                email=email_address,
                name=full_name or email_address,
                metadata=customer_metadata,
                api_key=self._api_key,
            )
            upsert_stripe_customer_record(
                tx,
                customer,
                source="api:stripe_adapter.get_or_create_customer_profile",
            )
            return {
                "customer_profile_id": customer.id,
                "created": True,
                "customer": customer,
            }
        except stripe.error.StripeError as e:
            raise ProcessorError(
                processor="stripe",
                error_code=e.code or "unknown",
                error_message=str(e),
                metadata={"email_address": customer_data.get("email_address")},
            )

    def attach_payment_method(
        self,
        tx,
        customer_profile_id: str,
        payment_method_id: str,
        payment_data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Attach a Stripe payment method to a customer and optionally make it default."""
        payment_data = payment_data or {}
        try:
            payment_method = stripe.PaymentMethod.retrieve(payment_method_id, api_key=self._api_key)
            attached_customer = getattr(payment_method, "customer", None)
            if attached_customer and str(attached_customer) != str(customer_profile_id):
                raise ProcessorError(
                    processor="stripe",
                    error_code="payment_method_attached_elsewhere",
                    error_message="This payment method is already attached to another Stripe customer.",
                )

            if not attached_customer:
                payment_method = stripe.PaymentMethod.attach(
                    payment_method_id, customer=customer_profile_id, api_key=self._api_key
                )

            if payment_data.get("set_default", True):
                stripe.Customer.modify(
                    customer_profile_id,
                    email=payment_data.get("email_address"),
                    name=payment_data.get("name") or payment_data.get("email_address"),
                    invoice_settings={"default_payment_method": payment_method.id},
                    api_key=self._api_key,
                )

            upsert_stripe_customer_record(
                tx,
                {
                    "id": customer_profile_id,
                    "email": payment_data.get("email_address"),
                    "name": payment_data.get("name") or payment_data.get("email_address"),
                    "metadata": {
                        "default_payment_method": payment_method.id,
                    },
                },
                source="api:stripe_adapter.attach_payment_method",
            )
            upsert_stripe_payment_method_record(
                tx,
                payment_method,
                customer_id=customer_profile_id,
                email_address=payment_data.get("email_address"),
                is_default=payment_data.get("set_default", True),
                detached=False,
                source="api:stripe_adapter.attach_payment_method",
            )

            return {
                "customer_profile_id": customer_profile_id,
                "payment_profile_id": payment_method.id,
                "payment_method": payment_method,
            }
        except ProcessorError:
            raise
        except stripe.error.StripeError as e:
            raise ProcessorError(
                processor="stripe",
                error_code=e.code or "unknown",
                error_message=str(e),
                metadata={
                    "customer_profile_id": customer_profile_id,
                    "payment_method_id": payment_method_id,
                },
            )

    def detach_payment_method(
        self, tx, payment_method_id: str, payment_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Detach a Stripe payment method from any attached customer."""
        try:
            payment_method = stripe.PaymentMethod.retrieve(payment_method_id, api_key=self._api_key)
            if getattr(payment_method, "customer", None):
                payment_method = stripe.PaymentMethod.detach(payment_method_id, api_key=self._api_key)
            upsert_stripe_payment_method_record(
                tx,
                payment_method,
                detached=True,
                source="api:stripe_adapter.detach_payment_method",
            )
            return {
                "payment_profile_id": payment_method_id,
                "detached": True,
                "payment_method": payment_method,
            }
        except stripe.error.StripeError as e:
            raise ProcessorError(
                processor="stripe",
                error_code=e.code or "unknown",
                error_message=str(e),
                metadata={"payment_method_id": payment_method_id},
            )

    def delete_customer_profile(self, tx, customer_profile_id: str) -> Dict[str, Any]:
        """Delete a Stripe vaulted customer."""
        try:
            result = stripe.Customer.delete(customer_profile_id, api_key=self._api_key)
            upsert_stripe_customer_record(
                tx,
                {
                    "id": customer_profile_id,
                    "metadata": {"deleted": bool(getattr(result, "deleted", False))},
                },
                source="api:stripe_adapter.delete_customer_profile",
            )
            return {
                "customer_profile_id": customer_profile_id,
                "deleted": bool(getattr(result, "deleted", False)),
                "customer": result,
            }
        except stripe.error.StripeError as e:
            raise ProcessorError(
                processor="stripe",
                error_code=e.code or "unknown",
                error_message=str(e),
                metadata={"customer_profile_id": customer_profile_id},
            )

    def create_account(self, tx, client_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a Stripe Express Connected Account for a client school.

        Express accounts provide:
        - Simplified onboarding via Stripe-hosted flow
        - Lighter dashboard for schools
        - Platform handles disputes
        """
        try:
            # Extract client data
            client_id = client_data["client_id"]
            business_name = client_data.get(
                "business_name", client_data.get("school_name")
            )
            email = client_data["email"]

            # Create Express account
            account_metadata = {
                "client_id": str(client_id),
                "environment": self.environment,
            }
            if self.platform:
                account_metadata["platform"] = str(self.platform)

            account = stripe.Account.create(
                type="express",  # Express account type
                country="US",
                email=email,
                capabilities={
                    "card_payments": {"requested": True},
                    "transfers": {"requested": True},
                },
                business_type="company",
                company={
                    "name": business_name,
                },
                business_profile={
                    "mcc": "8299",  # Schools and Educational Services
                    "url": client_data.get("website_url"),
                },
                metadata=account_metadata,
                api_key=self._api_key,
            )

            upsert_stripe_account_record(
                tx,
                account,
                client_id=client_id,
                source="api:stripe_adapter.create_account",
            )
            sync_client_payment_account_from_stripe_account(
                tx,
                account,
                client_id=client_id,
            )

            # Store in client_payment_accounts table
            # Create initial onboarding checklist
            checklist = tx.table("client_onboarding_checklists").new()
            checklist["client_id"] = client_id
            checklist["processor_type"] = "stripe"
            checklist["processor_account_id"] = account.id
            checklist["checklist_state"] = self._generate_initial_checklist()
            checklist["current_step"] = 0
            checklist["completed"] = False

            # Mark first step as complete (account created)
            state = checklist["checklist_state"]
            state["items"]["stripe_account_created"]["completed"] = True
            state["items"]["stripe_account_created"]["completed_at"] = datetime.now(
                timezone.utc
            ).isoformat()
            checklist["checklist_state"] = state

            return {
                "processor_account_id": account.id,
                "status": "pending",
                "requires_onboarding": True,
                "onboarding_url": None,  # Generated separately via create_onboarding_link
                "charges_enabled": account.charges_enabled,
                "payouts_enabled": account.payouts_enabled,
                "metadata": {
                    "account_type": "express",
                    "capabilities": account.capabilities,
                    "requirements": account.requirements,
                },
            }

        except stripe.error.StripeError as e:
            raise ProcessorError(
                processor="stripe",
                error_code=e.code or "unknown",
                error_message=str(e),
                metadata={"client_id": client_data.get("client_id")},
            )

    def get_account_status(self, tx, processor_account_id: str) -> Dict[str, Any]:
        """
        Retrieve current status of a Stripe Connected Account.
        """
        try:
            account = stripe.Account.retrieve(processor_account_id, api_key=self._api_key)

            client_id = None
            payment_account = tx.table("client_payment_accounts").find(
                {
                    "processor_account_id": processor_account_id,
                    "processor_type": "stripe",
                }
            )
            if payment_account:
                client_id = payment_account.get("client_id")

            upsert_stripe_account_record(
                tx,
                account,
                client_id=client_id,
                source="api:stripe_adapter.get_account_status",
            )
            sync_client_payment_account_from_stripe_account(
                tx,
                account,
                client_id=client_id,
            )

            return {
                "account_id": account.id,
                "status": self._determine_account_status(account),
                "charges_enabled": account.charges_enabled,
                "payouts_enabled": account.payouts_enabled,
                "requirements_due": account.requirements.currently_due or [],
                "requirements_past_due": account.requirements.past_due or [],
                "requirements_deadline": account.requirements.current_deadline,
                "verification_status": self._get_verification_status(account),
                "metadata": {
                    "details_submitted": account.details_submitted,
                    "disabled_reason": account.requirements.disabled_reason,
                    "capabilities": account.capabilities,
                },
            }

        except stripe.error.StripeError as e:
            raise ProcessorError(
                processor="stripe",
                error_code=e.code or "unknown",
                error_message=str(e),
                metadata={"account_id": processor_account_id},
            )

    def create_onboarding_link(
        self, tx, processor_account_id: str, return_url: str, refresh_url: str
    ) -> str:
        """
        Generate Stripe AccountLink for hosted Express onboarding flow.

        The generated URL redirects the user to Stripe's hosted onboarding,
        which collects all required business and identity information.
        """
        try:
            account_link = stripe.AccountLink.create(
                account=processor_account_id,
                refresh_url=refresh_url,
                return_url=return_url,
                type="account_onboarding",
                api_key=self._api_key,
            )

            return account_link.url

        except stripe.error.StripeError as e:
            raise ProcessorError(
                processor="stripe",
                error_code=e.code or "unknown",
                error_message=str(e),
                metadata={"account_id": processor_account_id},
            )

    # ========================================================================
    # PAYMENT AUTHORIZATION (PRE-AUTH)
    # ========================================================================

    def authorize_payment(self, tx, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Pre-authorize a payment using Stripe PaymentIntent with manual capture.

        Uses destination charges with application_fee_amount for revenue split.
        """
        try:
            # Extract payment data
            amount_cents = payment_data["amount"]
            currency = payment_data.get("currency", "usd")
            payment_method = payment_data["payment_method"]
            processor_account_id = payment_data["processor_account_id"]
            revenue_split_percentage = payment_data["revenue_split_percentage"]
            capture_method = payment_data.get("capture_method", "manual")

            # Calculate platform fee
            platform_fee_cents = self.calculate_platform_fee(
                amount_cents, revenue_split_percentage
            )

            # Create PaymentIntent
            payment_metadata = {
                "client_id": str(payment_data.get("client_id")),
                "form_sys_id": str(payment_data.get("form_sys_id", "")),
                "customer_email": payment_data.get("customer_email")
                or payment_data.get("donor_email"),
                "customer_name": payment_data.get("customer_name")
                or payment_data.get("donor_name"),
                "environment": self.environment,
            }
            if self.platform:
                payment_metadata["platform"] = str(self.platform)

            payment_intent = stripe.PaymentIntent.create(
                amount=amount_cents,
                currency=currency,
                payment_method=payment_method,
                payment_method_types=["card"],
                capture_method=capture_method,
                confirm=True,  # Confirm immediately (authorize)
                application_fee_amount=platform_fee_cents,  # Platform fee
                transfer_data={
                    "destination": processor_account_id,  # Client's account
                },
                metadata=payment_metadata,
                api_key=self._api_key,
            )
            charge = self._mirror_payment_intent_artifacts(
                tx,
                payment_intent,
                source="api:stripe_adapter.authorize_payment",
            )

            # Calculate expiration (Stripe holds for 7 days for manual capture)
            expires_at = datetime.now(timezone.utc) + timedelta(days=7)

            # Determine status based on capture method
            if capture_method == "automatic":
                status = "captured" if payment_intent.status == "succeeded" else "failed"
            else:
                status = "authorized" if payment_intent.status == "requires_capture" else "failed"

            return {
                "processor_transaction_id": payment_intent.id,
                "status": status,
                "amount": payment_intent.amount,
                "currency": payment_intent.currency,
                "authorization_code": payment_intent.id,  # Stripe uses PaymentIntent ID
                "expires_at": expires_at,
                "error_message": None,
                "metadata": {
                    "payment_intent": payment_intent,
                    "charge": charge,
                    "platform_fee": platform_fee_cents,
                    "client_amount": amount_cents - platform_fee_cents,
                },
            }

        except stripe.error.StripeError as e:
            return {
                "processor_transaction_id": None,
                "status": "failed",
                "amount": payment_data.get("amount"),
                "currency": payment_data.get("currency", "usd"),
                "authorization_code": None,
                "expires_at": None,
                "error_message": str(e),
                "metadata": {
                    "error_code": e.code,
                    "error_type": type(e).__name__,
                },
            }

    def charge_stored_payment_method(self, tx, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        """Charge a stored Stripe PaymentMethod using an off-session PaymentIntent."""
        try:
            amount_cents = payment_data["amount"]
            currency = payment_data.get("currency", "usd")
            payment_method = payment_data["payment_method"]
            customer_profile_id = payment_data.get("customer_profile_id")
            processor_account_id = payment_data.get("processor_account_id")
            revenue_split_percentage = payment_data.get("revenue_split_percentage", 0)

            if not customer_profile_id:
                raise ProcessorError(
                    processor="stripe",
                    error_code="missing_customer_profile",
                    error_message="Stored Stripe charges require a customer_profile_id.",
                )
            if not processor_account_id:
                raise ProcessorError(
                    processor="stripe",
                    error_code="missing_processor_account",
                    error_message="Stripe processor account is not configured for this client.",
                )

            platform_fee_cents = self.calculate_platform_fee(
                amount_cents, revenue_split_percentage
            )

            payment_metadata = {
                "client_id": str(payment_data.get("client_id")),
                "customer_email": payment_data.get("customer_email")
                or payment_data.get("donor_email"),
                "customer_name": payment_data.get("customer_name")
                or payment_data.get("donor_name"),
                "environment": self.environment,
                **(payment_data.get("metadata") or {}),
            }
            if self.platform:
                payment_metadata["platform"] = str(self.platform)

            payment_intent = stripe.PaymentIntent.create(
                amount=amount_cents,
                currency=currency,
                customer=customer_profile_id,
                payment_method=payment_method,
                confirm=True,
                off_session=True,
                application_fee_amount=platform_fee_cents,
                transfer_data={"destination": processor_account_id},
                description=payment_data.get("description"),
                metadata=payment_metadata,
                api_key=self._api_key,
            )
            charge = self._mirror_payment_intent_artifacts(
                tx,
                payment_intent,
                source="api:stripe_adapter.charge_stored_payment_method",
            )

            charge_id = getattr(payment_intent, "latest_charge", None)
            return {
                "processor_transaction_id": payment_intent.id,
                "processor_charge_id": getattr(charge, "id", None) or charge_id,
                "status": payment_intent.status,
                "success": payment_intent.status == "succeeded",
                "amount": payment_intent.amount,
                "currency": payment_intent.currency,
                "authorization_code": payment_intent.id,
                "platform_fee": payment_intent.application_fee_amount or platform_fee_cents,
                "client_amount": payment_intent.amount - (payment_intent.application_fee_amount or platform_fee_cents),
                "error_message": None,
                "metadata": {
                    "payment_intent": payment_intent,
                    "charge": charge,
                },
            }

        except ProcessorError:
            raise
        except stripe.error.StripeError as e:
            return {
                "processor_transaction_id": None,
                "processor_charge_id": None,
                "status": "failed",
                "success": False,
                "amount": payment_data.get("amount"),
                "currency": payment_data.get("currency", "usd"),
                "authorization_code": None,
                "platform_fee": 0,
                "client_amount": 0,
                "error_message": str(e),
                "metadata": {
                    "error_code": e.code,
                    "error_type": type(e).__name__,
                },
            }

    # ========================================================================
    # PAYMENT CAPTURE
    # ========================================================================

    def capture_payment(
        self, tx, processor_transaction_id: str, amount: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Capture a previously authorized PaymentIntent.

        This finalizes the payment and transfers funds according to the
        destination charge configuration (with application fee).
        """
        try:
            # Capture the PaymentIntent
            if amount:
                payment_intent = stripe.PaymentIntent.capture(
                    processor_transaction_id, amount_to_capture=amount, api_key=self._api_key
                )
            else:
                payment_intent = stripe.PaymentIntent.capture(processor_transaction_id, api_key=self._api_key)

            charge = self._mirror_payment_intent_artifacts(
                tx,
                payment_intent,
                source="api:stripe_adapter.capture_payment",
            )
            charge_id = getattr(charge, "id", None)

            # Calculate amounts
            amount_captured = payment_intent.amount_captured
            platform_fee = payment_intent.application_fee_amount or 0
            client_amount = amount_captured - platform_fee

            return {
                "processor_transaction_id": payment_intent.id,
                "processor_charge_id": charge_id,
                "status": (
                    "captured" if payment_intent.status == "succeeded" else "failed"
                ),
                "amount_captured": amount_captured,
                "platform_fee": platform_fee,
                "client_amount": client_amount,
                "captured_at": datetime.now(timezone.utc),
                "error_message": None,
                "metadata": {
                    "payment_intent": payment_intent,
                    "charge": charge,
                },
            }

        except stripe.error.StripeError as e:
            raise ProcessorError(
                processor="stripe",
                error_code=e.code or "unknown",
                error_message=str(e),
                metadata={"payment_intent_id": processor_transaction_id},
            )

    def cancel_payment(
        self, tx, processor_transaction_id: str, reason: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Cancel a previously authorized PaymentIntent before capture.

        This releases the hold on the donor's card without charging them.
        """
        try:
            payment_intent = stripe.PaymentIntent.cancel(
                processor_transaction_id, cancellation_reason=reason, api_key=self._api_key
            )
            self._mirror_payment_intent_artifacts(
                tx,
                payment_intent,
                source="api:stripe_adapter.cancel_payment",
            )

            return {
                "processor_transaction_id": payment_intent.id,
                "status": (
                    "cancelled" if payment_intent.status == "canceled" else "failed"
                ),
                "cancelled_at": datetime.now(timezone.utc),
                "reason": reason,
                "error_message": None,
            }

        except stripe.error.StripeError as e:
            raise ProcessorError(
                processor="stripe",
                error_code=e.code or "unknown",
                error_message=str(e),
                metadata={"payment_intent_id": processor_transaction_id},
            )

    # ========================================================================
    # REFUNDS
    # ========================================================================

    def refund_payment(
        self,
        tx,
        processor_charge_id: str,
        amount: Optional[int] = None,
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Refund a captured payment (full or partial).

        Stripe automatically handles reversing the application fee proportionally.
        """
        try:
            refund_params: Dict[str, Any] = {
                "charge": processor_charge_id,
            }

            if amount:
                refund_params["amount"] = amount

            if reason:
                refund_params["reason"] = reason

            refund = stripe.Refund.create(**refund_params, api_key=self._api_key)

            # Calculate proportional fee refund
            original_charge = stripe.Charge.retrieve(processor_charge_id, api_key=self._api_key)
            upsert_stripe_charge_record(
                tx,
                original_charge,
                source="api:stripe_adapter.refund_payment",
            )
            upsert_stripe_refund_record(
                tx,
                refund,
                charge_id=processor_charge_id,
                source="api:stripe_adapter.refund_payment",
            )
            original_amount = original_charge.amount
            original_fee = original_charge.application_fee_amount or 0

            if amount:
                # Partial refund - calculate proportional fee
                platform_fee_refunded = int((amount / original_amount) * original_fee)
            else:
                # Full refund
                platform_fee_refunded = original_fee

            return {
                "refund_id": refund.id,
                "status": refund.status,
                "amount_refunded": refund.amount,
                "platform_fee_refunded": platform_fee_refunded,
                "refunded_at": datetime.fromtimestamp(refund.created, tz=timezone.utc),
                "reason": reason,
                "error_message": None,
            }

        except stripe.error.StripeError as e:
            raise ProcessorError(
                processor="stripe",
                error_code=e.code or "unknown",
                error_message=str(e),
                metadata={"charge_id": processor_charge_id},
            )

    # ========================================================================
    # UTILITY METHODS
    # ========================================================================

    def validate_configuration(self) -> bool:
        """
        Validate that Stripe configuration is complete.
        """
        if not self._api_key:
            return False

        try:
            # Test API key by retrieving account
            stripe.Account.retrieve(api_key=self._api_key)
            return True
        except stripe.error.StripeError:
            return False

    def _mirror_payment_intent_artifacts(
        self, tx, payment_intent, *, source: str
    ):
        upsert_stripe_payment_intent_record(tx, payment_intent, source=source)
        charge = None
        charges = getattr(getattr(payment_intent, "charges", None), "data", None) or []
        if charges:
            charge = charges[0]
        else:
            latest_charge_id = getattr(payment_intent, "latest_charge", None)
            if latest_charge_id:
                try:
                    charge = stripe.Charge.retrieve(latest_charge_id, api_key=self._api_key)
                except stripe.error.StripeError:
                    charge = None
        if charge:
            upsert_stripe_charge_record(tx, charge, source=source)
        return charge

    def _determine_account_status(self, account) -> str:
        """
        Determine human-readable account status from Stripe Account object.
        """
        if account.charges_enabled and account.payouts_enabled:
            return "active"
        elif len(account.requirements.past_due or []) > 0:
            return "restricted"
        elif len(account.requirements.currently_due or []) > 0:
            return "pending"
        elif account.requirements.disabled_reason:
            return "disabled"
        else:
            return "pending"

    def _get_verification_status(self, account) -> str:
        """
        Get identity verification status from Stripe Account.
        """
        # Check if identity verification is in requirements
        currently_due = account.requirements.currently_due or []
        eventually_due = account.requirements.eventually_due or []

        identity_fields = [
            "individual.verification.document",
            "individual.verification.additional_document",
            "representative.verification.document",
        ]

        if any(field in currently_due for field in identity_fields):
            return "required"
        elif any(field in eventually_due for field in identity_fields):
            return "eventually_required"
        else:
            return "verified"

    def _generate_initial_checklist(self) -> Dict[str, Any]:
        """
        Generate initial onboarding checklist for Stripe Express accounts.
        """
        return {
            "version": "1.0",
            "processor": "stripe",
            "items": {
                "stripe_account_created": {
                    "title": "Stripe Account Created",
                    "description": "Connect your school to Stripe payment processing",
                    "required": True,
                    "completed": False,
                    "order": 1,
                },
                "business_details_submitted": {
                    "title": "Business Details Submitted",
                    "description": "Provide your school's business information to Stripe",
                    "required": True,
                    "completed": False,
                    "order": 2,
                    "external_step": True,  # Requires Stripe-hosted flow
                },
                "bank_account_connected": {
                    "title": "Bank Account Connected",
                    "description": "Link your school's bank account for payouts",
                    "required": True,
                    "completed": False,
                    "order": 3,
                    "external_step": True,
                },
                "identity_verification": {
                    "title": "Identity Verification",
                    "description": "Verify authorized representative identity",
                    "required": True,
                    "completed": False,
                    "order": 4,
                    "external_step": True,
                },
                "test_payment": {
                    "title": "Test Payment",
                    "description": "Process a test donation to verify setup",
                    "required": False,
                    "completed": False,
                    "order": 5,
                },
                "revenue_split_configured": {
                    "title": "Revenue Split Configured",
                    "description": "Review and confirm payment split settings",
                    "required": True,
                    "completed": False,
                    "order": 6,
                },
            },
        }
