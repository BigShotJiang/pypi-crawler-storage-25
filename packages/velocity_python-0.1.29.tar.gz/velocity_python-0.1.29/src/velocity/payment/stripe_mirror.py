import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional


def _get_value(data: Any, key: str, default: Any = None) -> Any:
    if isinstance(data, dict):
        return data.get(key, default)
    return getattr(data, key, default)


def _to_jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _to_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_to_jsonable(item) for item in value]
    if hasattr(value, "to_dict"):
        return _to_jsonable(value.to_dict())
    if hasattr(value, "__dict__"):
        return {
            str(key): _to_jsonable(item)
            for key, item in vars(value).items()
            if not str(key).startswith("_")
        }
    return str(value)


def _json_dumps(value: Any) -> Optional[str]:
    if value is None:
        return None
    return json.dumps(_to_jsonable(value), default=str)


def _table(tx, table_name: str):
    if tx is None:
        return None
    try:
        table = tx.table(table_name)
    except Exception:
        return None
    try:
        if hasattr(table, "exists") and not table.exists():
            return None
    except Exception:
        pass
    return table


def _upsert(tx, table_name: str, payload: Dict[str, Any], key: Dict[str, Any]):
    table = _table(tx, table_name)
    if not table:
        return None
    table.upsert(payload, key)
    return payload


def determine_stripe_account_status(account: Any) -> str:
    requirements = _get_value(account, "requirements") or {}
    currently_due = _get_value(requirements, "currently_due") or []
    past_due = _get_value(requirements, "past_due") or []
    disabled_reason = _get_value(requirements, "disabled_reason")
    if _get_value(account, "charges_enabled") and _get_value(account, "payouts_enabled"):
        return "active"
    if past_due:
        return "restricted"
    if disabled_reason:
        return "disabled"
    if currently_due:
        return "pending"
    return "pending"


def build_customer_updates_from_stripe_account(account: Any) -> Dict[str, Any]:
    business_profile = _get_value(account, "business_profile") or {}
    company = _get_value(account, "company") or {}
    address = _get_value(company, "address") or {}
    street = _get_value(address, "line1")
    street2 = _get_value(address, "line2")
    if street2:
        street = f"{street} {street2}".strip() if street else str(street2).strip()
    return {
        "organization_name": _get_value(company, "name")
        or _get_value(business_profile, "name"),
        "ein": _get_value(company, "tax_id"),
        "primary_phone": _get_value(business_profile, "support_phone"),
        "primary_email": _get_value(business_profile, "support_email")
        or _get_value(account, "email"),
        "website": _get_value(business_profile, "url"),
        "street_address": street,
        "city": _get_value(address, "city"),
        "state": _get_value(address, "state"),
        "zip_code": _get_value(address, "postal_code"),
    }


def sync_customer_from_stripe_account(tx, account: Any, client_id: Any):
    if not client_id:
        return None
    table = _table(tx, "customers")
    if not table:
        return None
    row = table.find({"client_id": client_id})
    if not row:
        return None
    updates = build_customer_updates_from_stripe_account(account)
    for key, value in updates.items():
        row[key] = value
    return row


def upsert_stripe_customer_record(
    tx, customer: Any, *, source: str = "api:stripe"
) -> Optional[Dict[str, Any]]:
    stripe_id = _get_value(customer, "id")
    if not stripe_id:
        return None
    payload = {
        "stripe_id": stripe_id,
        "email": _get_value(customer, "email"),
        "name": _get_value(customer, "name"),
        "description": _get_value(customer, "description"),
        "phone": _get_value(customer, "phone"),
        "created_at": _get_value(customer, "created"),
        "metadata": _json_dumps(_get_value(customer, "metadata") or {}),
        "sys_modified_by": source,
        "sys_dirty": True,
    }
    return _upsert(tx, "stripe_customers", payload, {"stripe_id": stripe_id})


def upsert_stripe_payment_intent_record(
    tx, payment_intent: Any, *, source: str = "api:stripe"
) -> Optional[Dict[str, Any]]:
    stripe_id = _get_value(payment_intent, "id")
    if not stripe_id:
        return None
    payload = {
        "stripe_id": stripe_id,
        "amount": _get_value(payment_intent, "amount_received")
        or _get_value(payment_intent, "amount_captured")
        or _get_value(payment_intent, "amount"),
        "currency": _get_value(payment_intent, "currency"),
        "created_at": _get_value(payment_intent, "created"),
        "status": _get_value(payment_intent, "status"),
        "description": _get_value(payment_intent, "description"),
        "customer_id": _get_value(payment_intent, "customer"),
        "metadata": _json_dumps(_get_value(payment_intent, "metadata") or {}),
        "last_payment_error": _json_dumps(
            _get_value(payment_intent, "last_payment_error") or {}
        ),
        "cancellation_reason": _get_value(payment_intent, "cancellation_reason"),
        "sys_modified_by": source,
        "sys_dirty": True,
    }
    return _upsert(tx, "stripe_payment_intents", payload, {"stripe_id": stripe_id})


def upsert_stripe_charge_record(
    tx, charge: Any, *, source: str = "api:stripe"
) -> Optional[Dict[str, Any]]:
    stripe_id = _get_value(charge, "id")
    if not stripe_id:
        return None
    payload = {
        "stripe_id": stripe_id,
        "amount": _get_value(charge, "amount"),
        "currency": _get_value(charge, "currency"),
        "status": _get_value(charge, "status"),
        "customer_id": _get_value(charge, "customer"),
        "payment_intent_id": _get_value(charge, "payment_intent"),
        "description": _get_value(charge, "description"),
        "receipt_email": _get_value(charge, "receipt_email"),
        "receipt_url": _get_value(charge, "receipt_url"),
        "created_at": _get_value(charge, "created"),
        "failure_code": _get_value(charge, "failure_code"),
        "failure_message": _get_value(charge, "failure_message"),
        "outcome": _json_dumps(_get_value(charge, "outcome") or {}),
        "amount_refunded": _get_value(charge, "amount_refunded"),
        "refunded": _get_value(charge, "refunded"),
        "sys_modified_by": source,
        "sys_dirty": True,
    }
    return _upsert(tx, "stripe_charges", payload, {"stripe_id": stripe_id})


def upsert_stripe_refund_record(
    tx, refund: Any, *, charge_id: Optional[str] = None, source: str = "api:stripe"
) -> Optional[Dict[str, Any]]:
    stripe_id = _get_value(refund, "id")
    if not stripe_id:
        return None
    payload = {
        "stripe_id": stripe_id,
        "charge_id": charge_id or _get_value(refund, "charge"),
        "amount": _get_value(refund, "amount"),
        "currency": _get_value(refund, "currency"),
        "reason": _get_value(refund, "reason"),
        "status": _get_value(refund, "status"),
        "created_at": _get_value(refund, "created"),
        "sys_modified_by": source,
        "sys_dirty": True,
    }
    return _upsert(tx, "stripe_refunds", payload, {"stripe_id": stripe_id})


def upsert_stripe_account_record(
    tx, account: Any, *, client_id: Any = None, source: str = "api:stripe"
) -> Optional[Dict[str, Any]]:
    stripe_id = _get_value(account, "id")
    if not stripe_id:
        return None
    payload = {
        "stripe_id": stripe_id,
        "client_id": client_id,
        "email": _get_value(account, "email"),
        "country": _get_value(account, "country"),
        "account_type": _get_value(account, "type"),
        "business_type": _get_value(account, "business_type"),
        "charges_enabled": _get_value(account, "charges_enabled"),
        "payouts_enabled": _get_value(account, "payouts_enabled"),
        "details_submitted": _get_value(account, "details_submitted"),
        "account_status": determine_stripe_account_status(account),
        "capabilities": _to_jsonable(_get_value(account, "capabilities") or {}),
        "requirements": _to_jsonable(_get_value(account, "requirements") or {}),
        "business_profile": _to_jsonable(
            _get_value(account, "business_profile") or {}
        ),
        "company": _to_jsonable(_get_value(account, "company") or {}),
        "individual": _to_jsonable(_get_value(account, "individual") or {}),
        "metadata": _to_jsonable(_get_value(account, "metadata") or {}),
        "created_at": _get_value(account, "created"),
        "raw_payload": _to_jsonable(account),
        "sys_modified_by": source,
        "sys_dirty": True,
    }
    return _upsert(tx, "stripe_accounts", payload, {"stripe_id": stripe_id})


def sync_client_payment_account_from_stripe_account(tx, account: Any, *, client_id: Any):
    if not client_id:
        return None
    payload = {
        "client_id": client_id,
        "processor_type": "stripe",
        "processor_account_id": _get_value(account, "id"),
        "account_status": determine_stripe_account_status(account),
        "capabilities": _to_jsonable(_get_value(account, "capabilities") or {}),
        "configuration": {
            "requirements": _to_jsonable(_get_value(account, "requirements") or {}),
            "details_submitted": _get_value(account, "details_submitted"),
        },
        "metadata": _to_jsonable(_get_value(account, "metadata") or {}),
        "onboarding_complete": bool(
            _get_value(account, "charges_enabled")
            and _get_value(account, "payouts_enabled")
            and _get_value(account, "details_submitted")
        ),
        "charges_enabled": _get_value(account, "charges_enabled"),
        "payouts_enabled": _get_value(account, "payouts_enabled"),
        "details_submitted": _get_value(account, "details_submitted"),
        "requirements_data": _to_jsonable(_get_value(account, "requirements") or {}),
        "updated_at": datetime.now(timezone.utc),
    }
    return _upsert(
        tx,
        "client_payment_accounts",
        payload,
        {"client_id": client_id, "processor_type": "stripe"},
    )


def upsert_stripe_payment_method_record(
    tx,
    payment_method: Any,
    *,
    customer_id: Optional[str] = None,
    email_address: Optional[str] = None,
    is_default: Optional[bool] = None,
    detached: Optional[bool] = None,
    source: str = "api:stripe",
) -> Optional[Dict[str, Any]]:
    stripe_id = _get_value(payment_method, "id")
    if not stripe_id:
        return None
    billing_details = _get_value(payment_method, "billing_details") or {}
    address = _get_value(billing_details, "address") or {}
    card = _get_value(payment_method, "card") or {}
    payload = {
        "stripe_id": stripe_id,
        "customer_id": customer_id or _get_value(payment_method, "customer"),
        "payment_method_type": _get_value(payment_method, "type"),
        "card_brand": _get_value(card, "brand"),
        "card_last4": _get_value(card, "last4"),
        "card_exp_month": _get_value(card, "exp_month"),
        "card_exp_year": _get_value(card, "exp_year"),
        "billing_name": _get_value(billing_details, "name"),
        "billing_email": _get_value(billing_details, "email") or email_address,
        "billing_phone": _get_value(billing_details, "phone"),
        "billing_address": _to_jsonable(address),
        "metadata": _to_jsonable(_get_value(payment_method, "metadata") or {}),
        "is_default": is_default,
        "detached": detached,
        "created_at": _get_value(payment_method, "created"),
        "raw_payload": _to_jsonable(payment_method),
        "sys_modified_by": source,
        "sys_dirty": True,
    }
    return _upsert(tx, "stripe_payment_methods", payload, {"stripe_id": stripe_id})