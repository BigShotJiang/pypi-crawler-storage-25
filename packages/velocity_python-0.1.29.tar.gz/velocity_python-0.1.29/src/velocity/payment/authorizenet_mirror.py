import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional


def _get_value(data: Any, key: str, default: Any = None) -> Any:
    if isinstance(data, dict):
        return data.get(key, default)
    return getattr(data, key, default)


def _to_jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _to_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_to_jsonable(item) for item in value]
    if hasattr(value, "__dict__"):
        return {
            str(key): _to_jsonable(item)
            for key, item in vars(value).items()
            if not str(key).startswith("_")
        }
    return str(value)


def _json_dumps(value: Any) -> Optional[str]:
    if value is None:
        return None
    return json.dumps(_to_jsonable(value), default=str)


def _table(tx, table_name: str):
    if tx is None:
        return None
    try:
        table = tx.table(table_name)
    except Exception:
        return None
    try:
        if hasattr(table, "exists") and not table.exists():
            return None
    except Exception:
        pass
    return table


def _upsert(tx, table_name: str, payload: Dict[str, Any], key: Dict[str, Any]):
    table = _table(tx, table_name)
    if not table:
        return None
    table.upsert(payload, key)
    return payload


def _now() -> datetime:
    return datetime.now(timezone.utc)


def upsert_authorize_account_record(
    tx, account: Dict[str, Any], *, source: str = "api:authorizenet"
) -> Optional[Dict[str, Any]]:
    processor_account_id = _get_value(account, "processor_account_id") or _get_value(
        account, "account_id"
    )
    if not processor_account_id:
        return None
    payload = {
        "processor_account_id": processor_account_id,
        "client_id": _get_value(account, "client_id"),
        "account_status": _get_value(account, "status"),
        "charges_enabled": _get_value(account, "charges_enabled"),
        "payouts_enabled": _get_value(account, "payouts_enabled"),
        "verification_status": _get_value(account, "verification_status"),
        "metadata": _to_jsonable(_get_value(account, "metadata") or {}),
        "raw_payload": _to_jsonable(account),
        "sys_modified_by": source,
        "sys_dirty": True,
    }
    return _upsert(
        tx,
        "authorize_accounts",
        payload,
        {"processor_account_id": processor_account_id},
    )


def sync_client_payment_account_from_authorize_account(
    tx, account: Dict[str, Any], *, client_id: Any
):
    if not client_id:
        return None
    processor_account_id = _get_value(account, "processor_account_id") or _get_value(
        account, "account_id"
    )
    if not processor_account_id:
        return None

    payload = {
        "client_id": client_id,
        "processor_type": "authorize_net",
        "processor_account_id": processor_account_id,
        "account_status": _get_value(account, "status") or "active",
        "capabilities": {
            "card_payments": True,
            "manual_settlement": True,
        },
        "configuration": {
            "verification_status": _get_value(account, "verification_status"),
        },
        "metadata": _to_jsonable(_get_value(account, "metadata") or {}),
        "onboarding_complete": True,
        "charges_enabled": True,
        "payouts_enabled": False,
        "details_submitted": True,
    }
    return _upsert(
        tx,
        "client_payment_accounts",
        payload,
        {"client_id": client_id, "processor_type": "authorize_net"},
    )


def upsert_authorize_customer_profile_record(
    tx, customer_profile: Dict[str, Any], *, source: str = "api:authorizenet"
) -> Optional[Dict[str, Any]]:
    customer_profile_id = _get_value(customer_profile, "customer_profile_id") or _get_value(
        customer_profile, "id"
    )
    if not customer_profile_id:
        return None
    payload = {
        "customer_profile_id": customer_profile_id,
        "email_address": _get_value(customer_profile, "email_address")
        or _get_value(customer_profile, "email"),
        "description": _get_value(customer_profile, "description"),
        "deleted": bool(_get_value(customer_profile, "deleted")),
        "metadata": _to_jsonable(_get_value(customer_profile, "metadata") or {}),
        "raw_payload": _to_jsonable(customer_profile),
        "lastupdateddate": _now(),
        "sys_modified_by": source,
        "sys_dirty": True,
    }
    return _upsert(
        tx,
        "authorize_customer_profiles",
        payload,
        {"customer_profile_id": customer_profile_id},
    )


def upsert_authorize_payment_profile_record(
    tx, payment_profile: Dict[str, Any], *, source: str = "api:authorizenet"
) -> Optional[Dict[str, Any]]:
    payment_profile_id = _get_value(payment_profile, "payment_profile_id") or _get_value(
        payment_profile, "id"
    )
    if not payment_profile_id:
        return None
    payload = {
        "payment_profile_id": payment_profile_id,
        "customer_profile_id": _get_value(payment_profile, "customer_profile_id"),
        "last4": _get_value(payment_profile, "last4"),
        "expiration_date": _get_value(payment_profile, "expiration_date"),
        "billing_first_name": _get_value(payment_profile, "billing_first_name"),
        "billing_last_name": _get_value(payment_profile, "billing_last_name"),
        "billing_address": _get_value(payment_profile, "billing_address"),
        "billing_city": _get_value(payment_profile, "billing_city"),
        "billing_state": _get_value(payment_profile, "billing_state"),
        "billing_zip": _get_value(payment_profile, "billing_zip"),
        "is_default": _get_value(payment_profile, "is_default"),
        "detached": bool(_get_value(payment_profile, "detached")),
        "metadata": _to_jsonable(_get_value(payment_profile, "metadata") or {}),
        "raw_payload": _to_jsonable(payment_profile),
        "lastupdateddate": _now(),
        "sys_modified_by": source,
        "sys_dirty": True,
    }
    return _upsert(
        tx,
        "authorize_payment_profiles",
        payload,
        {"payment_profile_id": payment_profile_id},
    )


def upsert_authorize_transaction_record(
    tx, transaction: Dict[str, Any], *, source: str = "api:authorizenet"
) -> Optional[Dict[str, Any]]:
    remote_transid = _get_value(transaction, "remote_transid") or _get_value(
        transaction, "processor_transaction_id"
    )
    if not remote_transid:
        return None
    payload = {
        "remote_transid": remote_transid,
        "amount": _get_value(transaction, "amount"),
        "status": _get_value(transaction, "status"),
        "lastupdateddate": _now(),
        "createddate": _get_value(transaction, "createddate") or _now(),
        "reason_for_transaction": _get_value(transaction, "reason_for_transaction"),
        "remote_authcode": _get_value(transaction, "remote_authcode"),
        "remote_responsecode": _get_value(transaction, "remote_responsecode"),
        "supported_id": _get_value(transaction, "supported_id"),
        "supported_name": _get_value(transaction, "supported_name"),
        "email_address": _get_value(transaction, "email_address"),
        "reconcile_response": _json_dumps(_get_value(transaction, "raw_payload") or transaction),
    }
    return _upsert(tx, "authorize_transactions", payload, {"remote_transid": remote_transid})