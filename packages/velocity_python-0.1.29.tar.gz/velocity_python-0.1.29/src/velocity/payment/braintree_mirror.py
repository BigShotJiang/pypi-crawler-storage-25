import json
from datetime import datetime, timezone
from typing import Any, Dict, Optional


SUCCESS_STATUSES = {
    "authorized",
    "submitted_for_settlement",
    "settling",
    "settled",
    "settlement_pending",
    "settlement_confirmed",
}


def _get_value(data: Any, key: str, default: Any = None) -> Any:
    if isinstance(data, dict):
        return data.get(key, default)
    return getattr(data, key, default)


def _to_jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _to_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_to_jsonable(item) for item in value]
    if hasattr(value, "__dict__"):
        return {
            str(key): _to_jsonable(item)
            for key, item in vars(value).items()
            if not str(key).startswith("_")
        }
    return str(value)


def _json_dumps(value: Any) -> Optional[str]:
    if value is None:
        return None
    return json.dumps(_to_jsonable(value), default=str)


def _table(tx, table_name: str):
    if tx is None:
        return None
    try:
        table = tx.table(table_name)
    except Exception:
        return None
    try:
        if hasattr(table, "exists") and not table.exists():
            return None
    except Exception:
        pass
    return table


def _upsert(tx, table_name: str, payload: Dict[str, Any], key: Dict[str, Any]):
    table = _table(tx, table_name)
    if not table:
        return None
    table.upsert(payload, key)
    return payload


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _status_is_payment_ok(status: Any) -> bool:
    return str(status or "").lower() in SUCCESS_STATUSES


def upsert_braintree_transaction_record(
    tx,
    transaction: Any,
    *,
    source: str = "api:braintree",
) -> Optional[Dict[str, Any]]:
    braintree_id = _get_value(transaction, "id")
    if not braintree_id:
        return None

    status = _get_value(transaction, "status")
    amount = _get_value(transaction, "amount")
    custom_fields = _get_value(transaction, "custom_fields") or {}
    credit_card_details = _get_value(transaction, "credit_card_details") or {}
    paypal_details = _get_value(transaction, "paypal_details") or {}
    customer_details = _get_value(transaction, "customer_details") or {}
    billing_details = _get_value(transaction, "billing_details") or {}

    payload = {
        "braintree_id": braintree_id,
        "status": status,
        "amount": amount,
        "amount_attempted": amount,
        "authorized_amount": amount if _status_is_payment_ok(status) else 0,
        "payment_ok": _status_is_payment_ok(status),
        "processor_authorization_code": _get_value(
            transaction, "processor_authorization_code"
        ),
        "processor_response_code": _get_value(transaction, "processor_response_code"),
        "processor_response_text": _get_value(transaction, "processor_response_text"),
        "graphql_id": _get_value(transaction, "graphql_id"),
        "card_last_4": _get_value(credit_card_details, "last_4")
        or _get_value(paypal_details, "payer_email"),
        "card_type": _get_value(credit_card_details, "card_type")
        or _get_value(transaction, "payment_instrument_type"),
        "card_expiration_month": _get_value(credit_card_details, "expiration_month"),
        "card_expiration_year": _get_value(credit_card_details, "expiration_year"),
        "card_customer_location": _get_value(
            credit_card_details, "customer_location"
        ),
        "card_image_url": _get_value(credit_card_details, "image_url"),
        "avs_postal_code_response_code": _get_value(
            transaction, "avs_postal_code_response_code"
        ),
        "avs_street_address_response_code": _get_value(
            transaction, "avs_street_address_response_code"
        ),
        "cvv_response_code": _get_value(transaction, "cvv_response_code"),
        "first_name": _get_value(customer_details, "first_name"),
        "last_name": _get_value(customer_details, "last_name"),
        "email_address": (
            str(_get_value(customer_details, "email") or "").lower() or None
        ),
        "street_address": _get_value(billing_details, "street_address"),
        "postal_code": _get_value(billing_details, "postal_code"),
        "client_id": custom_fields.get("client_id"),
        "campaign": custom_fields.get("campaign_id"),
        "reason_for_transaction": custom_fields.get("tx_reason"),
        "special_instructions": custom_fields.get("special_instructions"),
        "effective_month": custom_fields.get("effective_month"),
        "effective_year": custom_fields.get("effective_year"),
        "lastupdateddate": _now(),
        "date_last_updated": _now(),
        "createddate": _now(),
        "raw_response": _json_dumps(transaction),
        "update_source": source,
    }
    return _upsert(tx, "braintree_transaction", payload, {"braintree_id": braintree_id})


def upsert_braintree_merchant_account_record(
    tx,
    merchant_account: Any,
    *,
    source: str = "api:braintree",
) -> Optional[Dict[str, Any]]:
    merchant_account_id = _get_value(merchant_account, "id")
    if not merchant_account_id:
        return None

    payload = {
        "src": "BT",
        "src_id": merchant_account_id,
        "status": _get_value(merchant_account, "status"),
        "decline_reason": _get_value(merchant_account, "decline_reason"),
        "raw_payload": _json_dumps(merchant_account),
        "update_source": source,
    }
    return _upsert(
        tx,
        "braintree_merchant_accounts",
        payload,
        {"src": "BT", "src_id": merchant_account_id},
    )


def sync_client_payment_account_from_braintree_merchant_account(
    tx, merchant_account: Any, *, client_id: Any
):
    if not client_id:
        return None
    merchant_account_id = _get_value(merchant_account, "id")
    if not merchant_account_id:
        return None

    status = str(_get_value(merchant_account, "status") or "pending").lower()
    is_active = status == "active"
    payload = {
        "client_id": client_id,
        "processor_type": "braintree",
        "processor_account_id": merchant_account_id,
        "account_status": status,
        "capabilities": {
            "card_payments": is_active,
            "manual_settlement": True,
        },
        "configuration": {
            "decline_reason": _get_value(merchant_account, "decline_reason"),
        },
        "metadata": {
            "account_type": "sub_merchant",
            "master_merchant_id": _get_value(merchant_account, "master_merchant_account", {}).get("id")
            if isinstance(_get_value(merchant_account, "master_merchant_account"), dict)
            else _get_value(_get_value(merchant_account, "master_merchant_account"), "id"),
        },
        "onboarding_complete": is_active,
        "charges_enabled": is_active,
        "payouts_enabled": False,
        "details_submitted": True,
    }
    return _upsert(
        tx,
        "client_payment_accounts",
        payload,
        {"client_id": client_id, "processor_type": "braintree"},
    )