import importlib as _importlib
import os

DEBUG = (os.environ.get("ENV") != "production") or (os.environ.get("DEBUG") == "Y")


# This is helpful for running HTTPS clients on lambda.
if os.path.exists("/opt/python/ca-certificates.crt"):
    os.environ["REQUESTS_CA_BUNDLE"] = "/opt/python/ca-certificates.crt"


class AWS(object):
    # Get AWS EC2 Instance ID. Must run this from the EC2 instance itself to get the ID
    @staticmethod
    def instance_id(cls):
        import requests
        response = requests.get("http://169.254.169.254/latest/meta-data/instance-id")
        instance_id = response.text
        return instance_id


# Lazy-load heavy modules (boto3-dependent) on first access
_LAZY_ATTRS = {
    "AmplifyProject": "velocity.aws.amplify",
    "BackendDeploymentConfig": "velocity.aws.amplify_build",
    "build_environment_variables": "velocity.aws.amplify_build",
    "get_amplify_app_id_and_branch": "velocity.aws.amplify_build",
    "initialize_build_environment": "velocity.aws.amplify_build",
    "run_backend_deployment": "velocity.aws.amplify_build",
    "update_lambda_layers_to_latest": "velocity.aws.amplify_build",
    # S3 utilities
    "generate_presigned_get": "velocity.aws.s3",
    "generate_presigned_put": "velocity.aws.s3",
    "list_client_files": "velocity.aws.s3",
    "normalize_client_prefix": "velocity.aws.s3",
    "CLIENT_FILES_BUCKET": "velocity.aws.s3",
    "PUBLIC_ASSETS_BUCKET": "velocity.aws.s3",
    "BACKOFFICE_BUCKET": "velocity.aws.s3",
    "PRIVATE_BUCKETS": "velocity.aws.s3",
    "ALLOWED_UPLOAD_BUCKETS": "velocity.aws.s3",
    # Asset helpers
    "AssetReference": "velocity.aws.assets",
    "AssetUsage": "velocity.aws.assets",
    "AssetUsageReconciliation": "velocity.aws.assets",
    "AssetBackfillSummary": "velocity.aws.assets",
    "AssetRecord": "velocity.aws.assets",
    "AssetUploadResult": "velocity.aws.assets",
    "backfill_asset_records": "velocity.aws.assets",
    "build_asset_key": "velocity.aws.assets",
    "build_asset_usages": "velocity.aws.assets",
    "build_backfill_asset_data": "velocity.aws.assets",
    "find_existing_asset": "velocity.aws.assets",
    "extract_asset_references_from_html": "velocity.aws.assets",
    "extract_asset_references_from_record": "velocity.aws.assets",
    "extract_asset_references_from_value": "velocity.aws.assets",
    "iter_s3_objects": "velocity.aws.assets",
    "list_assets": "velocity.aws.assets",
    "normalize_asset_record": "velocity.aws.assets",
    "reconcile_asset_usages": "velocity.aws.assets",
    "upload_image_asset": "velocity.aws.assets",
}


def __getattr__(name: str):
    if name in _LAZY_ATTRS:
        module = _importlib.import_module(_LAZY_ATTRS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "AmplifyProject",
    "AWS",
    "BackendDeploymentConfig",
    "build_environment_variables",
    "get_amplify_app_id_and_branch",
    "initialize_build_environment",
    "run_backend_deployment",
    "update_lambda_layers_to_latest",
    # S3 utilities
    "generate_presigned_get",
    "generate_presigned_put",
    "list_client_files",
    "normalize_client_prefix",
    "CLIENT_FILES_BUCKET",
    "PUBLIC_ASSETS_BUCKET",
    "BACKOFFICE_BUCKET",
    "PRIVATE_BUCKETS",
    "ALLOWED_UPLOAD_BUCKETS",
    "AssetBackfillSummary",
    "AssetReference",
    "AssetRecord",
    "AssetUploadResult",
    "AssetUsage",
    "AssetUsageReconciliation",
    "backfill_asset_records",
    "build_asset_key",
    "build_asset_usages",
    "build_backfill_asset_data",
    "extract_asset_references_from_html",
    "extract_asset_references_from_record",
    "extract_asset_references_from_value",
    "find_existing_asset",
    "iter_s3_objects",
    "list_assets",
    "normalize_asset_record",
    "reconcile_asset_usages",
    "upload_image_asset",
]
