from __future__ import annotations

import re
from typing import Callable

from velocity.aws.assets.indexing import reconcile_form_builder_template_asset_usages


DirtyHook = Callable[[object, str, object, object, object], None]
_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _process_form_builder_template_dirty(tx, table, sys_id, row, context):
    reconcile_form_builder_template_asset_usages(tx, row)


_DIRTY_HOOKS: dict[str, DirtyHook] = {
    "form_builder_template": _process_form_builder_template_dirty,
}


def has_dirty_hook(table: str) -> bool:
    return table in _DIRTY_HOOKS


def run_dirty_hook(tx, table: str, sys_id, row, context) -> bool:
    hook = _DIRTY_HOOKS.get(table)
    if not hook:
        return False
    hook(tx, table, sys_id, row, context)
    return True


def get_excluded_tables(tx, context) -> set[str]:
    flags = {}
    if hasattr(context, "get_feature_flags"):
        flags = context.get_feature_flags(tx) or {}
    elif hasattr(context, "_get_feature_flag_cache"):
        flags = context._get_feature_flag_cache(tx) or {}

    raw_value = flags.get("dirty_pipeline_excluded_tables")
    if not raw_value:
        return set()

    return {
        line.strip()
        for line in str(raw_value).splitlines()
        if line and line.strip()
    }


def list_tables_with_sys_dirty(tx, *, schema: str = "public") -> list[str]:
    sql = """
        SELECT table_name
        FROM information_schema.columns
        WHERE table_schema = %s
          AND column_name = 'sys_dirty'
        ORDER BY table_name
    """
    return [
        str(row["table_name"])
        for row in tx.execute(sql, [schema]).as_dict().all()
        if row.get("table_name")
    ]


def select_stale_dirty_sys_ids(
    tx,
    table: str,
    *,
    limit: int = 500,
    stale_minutes: int = 5,
) -> list[str]:
    table_name = quote_identifier(table)
    stale_minutes = int(stale_minutes)
    limit = int(limit)
    sql = f"""
        SELECT sys_id
        FROM {table_name}
        WHERE sys_dirty = TRUE
          AND sys_modified < NOW() - INTERVAL '{stale_minutes} minutes'
        FOR UPDATE SKIP LOCKED
        LIMIT %s
    """
    return [
        str(row["sys_id"])
        for row in tx.execute(sql, [limit]).as_dict().all()
        if row.get("sys_id") is not None
    ]


def clear_stale_dirty_rows(
    tx,
    table: str,
    *,
    limit: int = 500,
    stale_minutes: int = 5,
) -> int:
    sys_ids = select_stale_dirty_sys_ids(
        tx,
        table,
        limit=limit,
        stale_minutes=stale_minutes,
    )
    if not sys_ids:
        return 0

    table_name = quote_identifier(table)
    placeholders = ", ".join(["%s"] * len(sys_ids))
    sql = f"UPDATE {table_name} SET sys_dirty = FALSE WHERE sys_id IN ({placeholders})"
    tx.execute(sql, sys_ids)
    return len(sys_ids)


def quote_identifier(identifier: str) -> str:
    if not isinstance(identifier, str) or not _IDENTIFIER_RE.match(identifier):
        raise ValueError(f"Invalid SQL identifier: {identifier!r}")
    return f'"{identifier}"'