"""
DataServiceMixin - Generic CRUD operations for Lambda handlers.

Provides standard database operations that can be mixed into any Lambda handler
that uses velocity.db for database access.
"""

import base64
import csv
import datetime
import importlib
import json
import logging
import re
import xml.etree.ElementTree as ET
from io import BytesIO, StringIO

from velocity.aws import dirty_pipeline
from velocity.misc import export

logger = logging.getLogger(__name__)


class DataServiceMixin:
    """
    Mixin providing generic CRUD operations for Lambda handlers.

    This mixin assumes:
    - Handler uses velocity.db engine with @engine.transaction decorator
    - Handler has a context object with payload() and response() methods
    - Database tables follow standard conventions (sys_id primary key)

    Usage:
        from velocity.aws.handlers.mixins import DataServiceMixin

        @engine.transaction
        class HttpEventHandler(DataServiceMixin, LambdaHandler):
            def __init__(self, aws_event, aws_context):
                super().__init__(aws_event, aws_context)

    Override read_hook, write_hook, etc. methods to add custom business logic.
    """

    # PostgreSQL type mappings for frontend display
    _pg_types = {
        "bool": "string",
        "char": "string",
        "int2": "string",
        "int4": "string",
        "int8": "string",
        "text": "string",
        "numeric": "number",
        "float4": "number",
        "float8": "number",
        "varchar": "string",
        "date": "string",
        "time": "string",
        "timestamp": "string",
    }

    def _get_field_type(self, column_info):
        """Convert database column type to frontend display type"""
        return (
            "string"
            if column_info["name"] in ["id", "sys_id"]
            else self._pg_types.get(column_info["type_name"], "string")
        )

    def _call_rwx_hook(self, hook_name, table, *args, **kwargs):
        """
        Call a table-specific RWX hook if it exists.

        This method tries to load a hook from the rwx package and call it.
        If the hook doesn't exist, execution continues silently.

        Args:
            hook_name: Name of the hook (e.g., 'before_write', 'after_read')
            table: Table name (used to load table-specific module)
            *args: Arguments to pass to the hook
            **kwargs: Keyword arguments to pass to the hook
        """

        try:
            m = importlib.import_module(f".{table}", "rwx")
            if hasattr(m, hook_name):
                getattr(m, hook_name)(*args, **kwargs)
        except ImportError:
            # rwx package not available, continue without hooks
            pass

    def _get_rwx_module(self, table):
        try:
            return importlib.import_module(f".{table}", "rwx")
        except ImportError:
            return None

    def _has_rwx_hook(self, table, hook_name):
        module = self._get_rwx_module(table)
        return bool(module and hasattr(module, hook_name))

    def _get_dirty_pipeline_excluded_tables(self, tx, context):
        return dirty_pipeline.get_excluded_tables(tx, context)

    def _has_dirty_hook(self, table):
        return dirty_pipeline.has_dirty_hook(table) or self._has_rwx_hook(table, "on_dirty")

    # ========== Hook Methods (Override These) ==========

    def read_hook(self, tx, table, sys_id, context):
        row = {}
        if not sys_id:
            raise Exception("An object id was not provided for read operation")
        if sys_id == "@new":
            row = {}
            self._call_rwx_hook("on_new", "common", tx, table, row, context)
            self._call_rwx_hook("on_new", table, tx, table, row, context)
            return row
        sys_id = int(sys_id)
        self._call_rwx_hook("before_read", "common", tx, table, sys_id, context)
        self._call_rwx_hook("before_read", table, tx, table, sys_id, context)
        row = tx.table(table).find(sys_id)
        row = row.to_dict() if row else {}
        self._call_rwx_hook("after_read", "common", tx, table, sys_id, row, context)
        self._call_rwx_hook("after_read", table, tx, table, sys_id, row, context)
        return row

    def find_hook(self, tx, table, where, context):
        row = {}
        if not where:
            raise Exception(
                "An query predicate was not provided for this read operation"
            )
        self._call_rwx_hook("before_find", "common", tx, table, where, context)
        self._call_rwx_hook("before_find", table, tx, table, where, context)
        row = tx.table(table).find(where)
        self._call_rwx_hook("after_find", "common", tx, table, where, row, context)
        self._call_rwx_hook("after_find", table, tx, table, where, row, context)
        if row:
            row = row.to_dict()
        return row

    def write_hook(self, tx, table, sys_id, incoming, context):
        row = {}
        incoming.pop("sys_id", None)
        if sys_id == "@new":
            self._call_rwx_hook(
                "before_new", "common", tx, table, sys_id, incoming, context
            )
            self._call_rwx_hook(
                "before_new", table, tx, table, sys_id, incoming, context
            )
            row = tx.table(table).new()
            sys_id = row["sys_id"]
            self._call_rwx_hook("after_new", "common", tx, table, sys_id, row, context)
            self._call_rwx_hook("after_new", table, tx, table, sys_id, row, context)
        elif sys_id:
            sys_id = int(sys_id)
        else:
            raise Exception("Object sys_id was not supplied on write operation.")
        self._call_rwx_hook(
            "before_write", "common", tx, table, sys_id, incoming, context
        )
        self._call_rwx_hook("before_write", table, tx, table, sys_id, incoming, context)
        if not row:
            row = tx.table(table).get(sys_id)
        row.update(incoming)
        self._call_rwx_hook("after_write", "common", tx, table, sys_id, row, context)
        self._call_rwx_hook("after_write", table, tx, table, sys_id, row, context)

        if incoming.get("sys_dirty") is not False:
            excluded_tables = self._get_dirty_pipeline_excluded_tables(tx, context)
            if table not in excluded_tables:
                if self._has_dirty_hook(table):
                    if hasattr(context, "enqueue_dirty"):
                        context.enqueue_dirty(table, sys_id)
                else:
                    row.update({"sys_dirty": False})

        return row.to_dict()

    def query_hook(self, tx, table, payload, context):
        self._call_rwx_hook("before_query", "common", tx, table, payload, context)
        self._call_rwx_hook("before_query", table, tx, table, payload, context)
        params = payload.get("params", {})
        result_format = payload.get("result_format")

        # Clear any previous swallowed-error details so we only report errors
        # related to this query.
        if hasattr(tx, "_last_return_default_error"):
            tx._last_return_default_error = None

        obj = payload["obj"]

        def _normalize_identifier(identifier: str):
            if identifier is None:
                return None
            identifier = str(identifier).strip()
            if not identifier:
                return None
            if identifier[0] == identifier[-1] and identifier[0] in {'"', "'"}:
                identifier = identifier[1:-1]
            return identifier

        def _extract_requested_column_names(columns_spec):
            if not columns_spec:
                return []
            if isinstance(columns_spec, str):
                columns_spec = [columns_spec]
            if not isinstance(columns_spec, (list, tuple)):
                return []

            requested = []
            simple_identifier = re.compile(
                r"^([A-Za-z_][A-Za-z0-9_]*)(\\.([A-Za-z_][A-Za-z0-9_]*))?$"
            )

            for col in columns_spec:
                if not isinstance(col, str):
                    continue

                raw = col.strip()
                if not raw or raw == "*":
                    continue

                # If this looks like an expression (functions, casts, aliases, etc.),
                # skip strict validation and let the DB error (which we will surface).
                lowered = raw.lower()
                if (
                    "(" in raw
                    or ")" in raw
                    or " over " in lowered
                    or "::" in raw
                    or " as " in lowered
                    or "+" in raw
                    or "-" in raw
                    or "/" in raw
                    or "*" in raw
                    or "||" in raw
                ):
                    continue

                # Allow simple identifiers, optionally qualified (table.column).
                match = simple_identifier.match(raw)
                if not match:
                    continue

                colname = match.group(3) or match.group(1)
                colname = _normalize_identifier(colname)
                if colname:
                    requested.append(colname)

            return requested

        def _inject_row_number_expression(params_dict):
            """Rewrite plain `row_number` requests into a computed column.

            Some UIs/metadata request a `row_number` column for display. We do
            not want `row_number` to be persisted on tables/views, so if the
            request includes `row_number` as a simple identifier, replace it
            with a window-function expression that aliases to `row_number`.
            """

            columns_spec = params_dict.get("columns")
            if not columns_spec:
                return
            if isinstance(columns_spec, str):
                columns_spec = [columns_spec]
            if not isinstance(columns_spec, list):
                return

            # If an explicit row_number expression is already present, do nothing.
            for col in columns_spec:
                if isinstance(col, str) and "row_number(" in col.lower():
                    return

            needs_row_number = any(
                isinstance(col, str) and col.strip().lower() == "row_number"
                for col in columns_spec
            )
            if not needs_row_number:
                return

            # Choose an order-by column for deterministic numbering.
            orderby = params_dict.get("orderby")
            order_col = None
            order_dir = None
            if isinstance(orderby, str) and orderby.strip():
                first = orderby.split(",", 1)[0].strip()
                parts = [p for p in first.split() if p]
                if parts:
                    candidate = parts[0]
                    # allow qualified identifiers (table.col)
                    candidate = candidate.split(".")[-1]
                    candidate = _normalize_identifier(candidate)
                    if candidate and re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", candidate):
                        order_col = candidate
                if len(parts) > 1 and parts[1].lower() in ("asc", "desc"):
                    order_dir = parts[1].lower()

            if not order_col:
                available = [c for c in tx.table(obj).sys_columns()]
                lowered = {c.lower(): c for c in available}
                order_col = lowered.get("sys_id") or lowered.get("sys_created")
                if not order_col and available:
                    order_col = available[0]
                if order_col:
                    order_col = _normalize_identifier(order_col)

            if not order_col:
                return

            if order_dir:
                expr = f"row_number() over (order by {order_col} {order_dir}) as row_number"
            else:
                expr = f"row_number() over (order by {order_col}) as row_number"

            params_dict["columns"] = [expr if (isinstance(col, str) and col.strip().lower() == "row_number") else col for col in columns_spec]

        # Optional: detect missing columns before running the query.
        _inject_row_number_expression(params)
        requested_cols = _extract_requested_column_names(params.get("columns"))
        if requested_cols:
            available_cols = {c.lower() for c in tx.table(obj).sys_columns()}
            missing = sorted(
                {c for c in requested_cols if c.lower() not in available_cols},
                key=lambda v: v.lower(),
            )
            if missing:
                message = (
                    f"Query failed for '{obj}': requested columns not present in the database: "
                    + ", ".join(missing)
                )
                context.response().toast(message, "error")
                error_payload = {
                    "type": "missing-columns",
                    "message": message,
                    "missing": missing,
                }
                _file_export_formats_early = {"excel", "csv", "tsv", "json", "jsonl", "xml", "html", "markdown", "xlsx", "parquet", "ods"}
                if result_format in _file_export_formats_early:
                    return {
                        "headers": payload.get("headers", []),
                        "rows": [],
                        "error": error_payload,
                    }
                return {
                    "rows": [],
                    "config": {
                        "lastFetch": datetime.datetime.now(),
                        "query": None,
                        "format": result_format,
                        "error": error_payload,
                    },
                }

        result = tx.table(obj).select(**params)

        swallowed_error = getattr(tx, "_last_return_default_error", None)
        if swallowed_error:
            tx._last_return_default_error = None

        _file_export_formats = {"excel", "csv", "tsv", "json", "jsonl", "xml", "html", "markdown", "xlsx", "parquet", "ods"}

        if result_format in _file_export_formats:
            data = {
                "headers": payload.get(
                    "headers", [x.replace("_", " ").title() for x in result.headers]
                ),
                "rows": result.as_list().all(),
            }
        else:
            data = {
                "rows": result.all(),
                "config": {
                    "lastFetch": datetime.datetime.now(),
                    "query": result.sql,
                    "format": result_format,
                },
            }

        # If the DB call failed but was swallowed (return_default), surface a reason.
        # Common symptoms are empty rows + null SQL.
        if swallowed_error and result_format in _file_export_formats:
            error_message = swallowed_error.get("message") or "Unknown database error"
            context.response().toast(
                f"Query failed for '{obj}': {error_message.splitlines()[0]}",
                "error",
            )
            data["error"] = {"type": "db-error", **swallowed_error}
        elif swallowed_error and isinstance(data, dict) and data.get("config") is not None:
            error_message = swallowed_error.get("message") or "Unknown database error"
            context.response().toast(
                f"Query failed for '{obj}': {error_message.splitlines()[0]}",
                "error",
            )
            data["config"].update(
                {
                    "query": data["config"].get("query") or None,
                    "error": {
                        "type": "db-error",
                        **swallowed_error,
                    },
                }
            )
        if payload.get("count"):
            data["count"] = tx.table(payload["obj"]).count(
                where=params.get("where", None)
            )
        if payload.get("headers"):
            data["columns"] = [
                {
                    "field": x["name"],
                    "headerName": x["name"].replace("_", " ").title(),
                    "type": self._get_field_type(x),
                }
                for x in result.columns.values()
            ]
        self._call_rwx_hook("after_query", "common", tx, table, data, payload, context)
        self._call_rwx_hook("after_query", table, tx, table, data, payload, context)
        return data

    def delete_hook(self, tx, table, sys_id, context):
        if sys_id:
            sys_id = int(sys_id)
            self._call_rwx_hook("before_delete", "common", tx, table, sys_id, context)
            self._call_rwx_hook("before_delete", table, tx, table, sys_id, context)
            row = tx.table(table).find(sys_id)
            if row:
                row.clear()
            self._call_rwx_hook("after_delete", "common", tx, table, sys_id, context)
            self._call_rwx_hook("after_delete", table, tx, table, sys_id, context)

    # ========== CRUD Action Methods ==========

    def OnActionReadObject(self, tx, context):
        payload = context.payload()

        # Validate required parameters
        if "tableName" not in payload:
            raise ValueError("Missing required parameter 'tableName' in payload")
        if "object" not in payload:
            raise ValueError("Missing required parameter 'object' in payload")

        table_name = payload["tableName"]
        obj = payload["object"]

        if not table_name:
            raise ValueError("Parameter 'tableName' cannot be empty")
        if not obj:
            raise ValueError("Parameter 'object' cannot be empty")

        row = self.read_hook(
            tx,
            table_name,
            obj.get("sys_id"),
            context,
        )

        context.response().set_body(
            {
                "object": row,
                "lastFetch": datetime.datetime.now(),
            }
        )
        if row:
            context.response().load_object(row)
        else:
            message = f"Object {obj.get('sys_id')} was not found in the database. You may create it as a new object."
            context.response().toast(message, "warning")

    def OnActionFindObject(self, tx, context):
        payload = context.payload()

        # Validate required parameters
        if "tableName" not in payload:
            raise ValueError("Missing required parameter 'tableName' in payload")
        if "query" not in payload:
            raise ValueError("Missing required parameter 'query' in payload")

        table_name = payload["tableName"]
        query = payload["query"]

        if not table_name:
            raise ValueError("Parameter 'tableName' cannot be empty")
        if not query or "where" not in query:
            raise ValueError("Parameter 'query' must contain 'where' clause")

        row = self.find_hook(
            tx,
            table_name,
            query["where"],
            context,
        )
        context.response().set_body(
            {
                "object": row,
                "lastFetch": datetime.datetime.now(),
            }
        )
        context.response().load_object(row)

    def OnActionWriteObject(self, tx, context):
        payload = context.payload()

        # Validate required parameters
        if "tableName" not in payload:
            raise ValueError("Missing required parameter 'tableName' in payload")
        if "object" not in payload:
            raise ValueError("Missing required parameter 'object' in payload")

        table_name = payload["tableName"]
        obj = payload["object"]

        if not table_name:
            raise ValueError("Parameter 'tableName' cannot be empty")
        if not obj or not isinstance(obj, dict):
            raise ValueError("Parameter 'object' must be a non-empty dictionary")

        # Ensure the object has at least some data
        incoming = obj.copy()
        if not any(value is not None for value in incoming.values()):
            raise ValueError("Parameter 'object' cannot contain only None values")

        logger.debug(
            "Writing to table",
            extra={
                "table_name": table_name,
                "sys_id": incoming.get("sys_id"),
                "object_keys": list(incoming.keys()),
            },
        )

        try:
            row = self.write_hook(
                tx,
                table_name,
                incoming.get("sys_id"),
                incoming,
                context,
            )

            if not row:
                logger.warning(
                    "write_hook returned empty row",
                    extra={"table_name": table_name},
                )
                row = {}

            context.response().set_body(
                {
                    "object": row,
                    "lastFetch": datetime.datetime.now(),
                }
            )
            logger.debug(
                "Successfully wrote to table",
                extra={"table_name": table_name},
            )

        except Exception as e:
            logger.error(
                "Error in OnActionWriteObject",
                extra={
                    "exception": str(e),
                    "table_name": table_name,
                    "incoming_keys": list(incoming.keys()),
                },
            )
            raise
        context.response().load_object(row)

    # Query a table for rows. If the requested result format is excel, then return the
    # data as a downloadedable excel file. If the requested result format is raw,
    # then return the data as rows for the application front end to handle as it wishes.
    # Otherwise, return the data as a dataset to be populated into a datatable,
    # and load the data into 'store.repo' as such.
    # @param self
    # @param tx
    # @param args
    # @param postdata
    # @param response
    #
    # Payload parameters

    # ---------------------------------------------------------------------------
    # Export format helpers
    # ---------------------------------------------------------------------------

    @staticmethod
    def _safe_xml_tag(name):
        """Sanitise a column name so it is a valid XML element name."""
        tag = re.sub(r"[^a-zA-Z0-9_.-]", "_", str(name))
        if tag and tag[0].isdigit():
            tag = "_" + tag
        return tag or "_col"

    @classmethod
    def _build_export_buffer(cls, result_format, headers, rows, filename_base):
        """
        Build a (bytes_buffer, filename, mime_type) tuple for the given
        result_format.  Returns None if the format is not handled here.
        """
        if result_format == "csv":
            buf = StringIO()
            writer = csv.writer(buf)
            writer.writerow(headers)
            writer.writerows(rows)
            return buf.getvalue().encode("utf-8"), f"{filename_base}.csv", "text/csv"

        if result_format == "tsv":
            buf = StringIO()
            writer = csv.writer(buf, delimiter="\t")
            writer.writerow(headers)
            writer.writerows(rows)
            return buf.getvalue().encode("utf-8"), f"{filename_base}.tsv", "text/tab-separated-values"

        if result_format == "json":
            data = [dict(zip(headers, row)) for row in rows]
            return json.dumps(data, default=str).encode("utf-8"), f"{filename_base}.json", "application/json"

        if result_format == "jsonl":
            lines = [json.dumps(dict(zip(headers, row)), default=str) for row in rows]
            return "\n".join(lines).encode("utf-8"), f"{filename_base}.jsonl", "application/x-ndjson"

        if result_format == "xml":
            root = ET.Element("rows")
            for row in rows:
                row_el = ET.SubElement(root, "row")
                for header, value in zip(headers, row):
                    col_el = ET.SubElement(row_el, cls._safe_xml_tag(header))
                    col_el.text = "" if value is None else str(value)
            xml_bytes = ET.tostring(root, encoding="unicode").encode("utf-8")
            return xml_bytes, f"{filename_base}.xml", "application/xml"

        if result_format == "html":
            th_cells = "".join(f"<th>{h}</th>" for h in headers)
            tr_rows = "".join(
                "<tr>" + "".join(f"<td>{'' if v is None else str(v)}</td>" for v in row) + "</tr>"
                for row in rows
            )
            html = (
                f"<!DOCTYPE html><html><head><meta charset='utf-8'></head>"
                f"<body><table border='1'><thead><tr>{th_cells}</tr></thead>"
                f"<tbody>{tr_rows}</tbody></table></body></html>"
            )
            return html.encode("utf-8"), f"{filename_base}.html", "text/html"

        if result_format == "markdown":
            header_row = "| " + " | ".join(str(h) for h in headers) + " |"
            separator = "| " + " | ".join("---" for _ in headers) + " |"
            data_rows = [
                "| " + " | ".join("" if v is None else str(v) for v in row) + " |"
                for row in rows
            ]
            md = "\n".join([header_row, separator] + data_rows)
            return md.encode("utf-8"), f"{filename_base}.md", "text/markdown"

        if result_format == "xlsx":
            try:
                from openpyxl import Workbook
            except ImportError:
                raise ImportError("openpyxl is required for xlsx export (install velocity-python[excel])")
            wb = Workbook()
            ws = wb.active
            ws.append(list(headers))
            for row in rows:
                ws.append(list(row))
            buf = BytesIO()
            wb.save(buf)
            return (
                buf.getvalue(),
                f"{filename_base}.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

        if result_format == "parquet":
            try:
                import pyarrow as pa
                import pyarrow.parquet as pq
            except ImportError:
                raise ImportError("pyarrow is required for parquet export (install velocity-python[parquet])")
            table = pa.table({h: [row[i] for row in rows] for i, h in enumerate(headers)})
            buf = BytesIO()
            pq.write_table(table, buf)
            return buf.getvalue(), f"{filename_base}.parquet", "application/octet-stream"

        if result_format == "ods":
            try:
                from odf.opendocument import OpenDocumentSpreadsheet
                from odf.table import Table, TableRow, TableCell
                from odf.text import P
            except ImportError:
                raise ImportError("odfpy is required for ods export (install velocity-python[ods])")
            doc = OpenDocumentSpreadsheet()
            sheet = Table(name="Sheet1")
            doc.spreadsheet.addElement(sheet)
            header_row_el = TableRow()
            for h in headers:
                cell = TableCell()
                cell.addElement(P(text=str(h)))
                header_row_el.addElement(cell)
            sheet.addElement(header_row_el)
            for row in rows:
                tr = TableRow()
                for v in row:
                    cell = TableCell()
                    cell.addElement(P(text="" if v is None else str(v)))
                    tr.addElement(cell)
                sheet.addElement(tr)
            buf = BytesIO()
            doc.save(buf)
            return (
                buf.getvalue(),
                f"{filename_base}.ods",
                "application/vnd.oasis.opendocument.spreadsheet",
            )

        return None

    # ---------------------------------------------------------------------------

    def OnActionQuery(self, tx, context):
        payload = context.payload()

        # Validate required parameters
        if "obj" not in payload:
            raise ValueError("Missing required parameter 'obj' in payload")

        table = payload["obj"]
        if not table:
            raise ValueError("Parameter 'obj' cannot be empty")

        result_format = payload.get("result_format")
        data = self.query_hook(tx, table, payload, context)

        if result_format == "excel":
            filebuffer = BytesIO()
            export.create_spreadsheet(data["headers"], data["rows"], filebuffer)
            context.response().file_download(
                {
                    "filename": payload.get("filename", "temp_file.xls"),
                    "data": base64.b64encode(filebuffer.getvalue()).decode(),
                }
            )
            return

        if result_format in ("csv", "tsv", "json", "jsonl", "xml", "html", "markdown", "xlsx", "parquet", "ods"):
            filename_base = payload.get("filename_base") or table
            built = self._build_export_buffer(result_format, data.get("headers", []), data.get("rows", []), filename_base)
            if built is not None:
                file_bytes, filename, _mime = built
                context.response().file_download(
                    {
                        "filename": filename,
                        "data": base64.b64encode(file_bytes).decode(),
                    }
                )
                return

        if result_format == "raw":
            context.response().set_body(data)
        else:
            context.response().set_table(
                {payload.get("datatable", payload.get("obj")): data}
            )

    def OnActionDeleteObject(self, tx, context):
        payload = context.payload()

        # Validate required parameters
        if "tableName" not in payload:
            raise ValueError("Missing required parameter 'tableName' in payload")

        table_name = payload["tableName"]
        if not table_name:
            raise ValueError("Parameter 'tableName' cannot be empty")
        deleteList = []
        if "deleteList" in payload:
            deleteList.extend(payload.get("deleteList"))
        if "object" in payload:
            obj = payload["object"]
            if obj and obj.get("sys_id"):
                deleteList.append(obj.get("sys_id"))

        for sys_id in deleteList:
            self.delete_hook(tx, table_name, sys_id, context)

        if not deleteList:
            context.response().toast("No items were selected.", "warning")

    def OnActionGetTables(self, tx, context):
        """Get list of all tables in the database."""
        context.response().set_body({"tables": tx.tables()})

    def OnActionUpdateRows(self, tx, context):
        """
        Update multiple rows with the same data.

        Payload:
            table: str - Table name
            updateData: dict - Data to update
            updateRows: list - List of sys_id values to update
        """
        payload = context.payload()

        # Validate required parameters
        required_fields = ["updateData", "updateRows", "table"]
        for field in required_fields:
            if field not in payload:
                raise ValueError(f"Missing required parameter '{field}' in payload")

        data = payload["updateData"]
        rows = payload["updateRows"]
        table = payload["table"]

        if not table:
            raise ValueError("Parameter 'table' cannot be empty")
        if not rows:
            raise ValueError("Parameter 'updateRows' cannot be empty")

        t = tx.table(table)
        count = t.update(data, {"sys_id": rows})
        context.response().toast(f"Updated {count} item(s).", "success")

    def OnActionQueryDirect(self, tx, context):
        """
        Query table directly with velocity.db parameters.

        Payload:
            obj: str - Table name
            params: dict - Direct velocity.db select parameters
            result_format: str - 'excel', 'raw', or 'datatable' (default)
            count: bool - Include total count
            headers: bool - Include column metadata
        """
        payload = context.payload()

        # Validate required parameters
        if "obj" not in payload:
            raise ValueError("Missing required parameter 'obj' in payload")

        table_name = payload["obj"]
        if not table_name:
            raise ValueError("Parameter 'obj' cannot be empty")

        params = payload.get("params", {})

        if payload.get("result_format") == "excel":
            result = tx.table(table_name).select(**params)
            headers = payload.get(
                "headers", [x.replace("_", " ").title() for x in result.headers]
            )
            rows = result.as_list().all()
            filebuffer = BytesIO()
            export.create_spreadsheet(headers, rows, filebuffer)
            context.response().file_download(
                {
                    "filename": payload.get("filename", "temp_file.xls"),
                    "data": base64.b64encode(filebuffer.getvalue()).decode(),
                }
            )
            return

        result = tx.table(table_name).select(**params)
        data = {
            "rows": result.all(),
            "config": {
                "lastFetch": datetime.datetime.now(),
                "query": result.sql,
                "format": payload.get("result_format"),
            },
        }

        if payload.get("count"):
            data["count"] = tx.table(table_name).count(where=params.get("where", None))

        if payload.get("headers"):
            data["columns"] = [
                {
                    "field": x["name"],
                    "headerName": x["name"].replace("_", " ").title(),
                    "type": self._get_field_type(x),
                }
                for x in result.columns.values()
            ]

        if payload.get("result_format") == "raw":
            context.response().set_body(data)
        else:
            context.response().set_table(
                {payload.get("datatable", payload.get("obj")): data}
            )

    def OnActionGetTableSchema(self, tx, context):
        """
        Get table schema from information_schema.

        Payload:
            tableName: str - Name of the table
        """
        payload = context.payload()

        # Validate required parameters
        if "tableName" not in payload:
            raise ValueError("Missing required parameter 'tableName' in payload")

        table_name = payload["tableName"]
        if not table_name:
            raise ValueError("Parameter 'tableName' cannot be empty")

        try:
            # Query information_schema to get table schema
            schema_query = """
                SELECT
                    column_name,
                    data_type,
                    is_nullable,
                    column_default,
                    character_maximum_length,
                    numeric_precision,
                    numeric_scale,
                    ordinal_position
                FROM information_schema.columns
                WHERE table_name = %s
                    AND table_schema = 'public'
                ORDER BY ordinal_position
            """

            schema_data = tx.execute(schema_query, [table_name])

            if not schema_data:
                raise ValueError(
                    f"Table '{table_name}' not found or has no accessible columns"
                )

            context.response().set_table(
                {
                    table_name: {
                        "schema": schema_data.all(),
                    }
                }
            )

        except Exception as e:
            if hasattr(self, "log"):
                self.log(
                    f"Error retrieving schema for table {table_name}: {str(e)}",
                    "OnActionGetTableSchema",
                )
            raise Exception(f"Failed to retrieve table schema: {str(e)}")
