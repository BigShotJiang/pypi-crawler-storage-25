"""
SSM-backed configuration with environment-variable fallback.

Opt-in: set ``VELOCITY_SSM_ENABLED=true`` in your Amplify environment variables
(pushed via ``bootstrap.py secrets``).

When enabled, ``getenv(key)`` reads from SSM at::

    /{ProjectName}/{ENV}/{key}

and falls back to ``os.environ`` on a miss or any error.  Results are cached
for the process lifetime so SSM is called at most once per key per Lambda
cold start.

When **not** enabled (the default), ``getenv`` is a thin wrapper around
``os.environ.get`` with zero extra overhead — preserving full backward
compatibility for projects that don't use SSM (e.g. caringcent).
"""

from __future__ import annotations

import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)

# Per-process cache: key → value (str) or sentinel _MISS.
_MISS = object()
_cache: dict[str, object] = {}

# Lazily evaluated once per process.
_SSM_ENABLED: bool | None = None


def _is_enabled() -> bool:
    global _SSM_ENABLED
    if _SSM_ENABLED is None:
        _SSM_ENABLED = os.environ.get('VELOCITY_SSM_ENABLED', '').lower() in ('1', 'true', 'yes')
    return _SSM_ENABLED


def _ssm_prefix() -> str | None:
    """Return '/{ProjectName}/{ENV}' or None if either var is missing."""
    project = os.environ.get('ProjectName')
    env = os.environ.get('ENV')
    if project and env:
        return f'/{project}/{env}'
    return None


def _fetch(key: str) -> str | None:
    """Single SSM GetParameter call; returns value or None on any failure."""
    prefix = _ssm_prefix()
    if prefix is None:
        return None
    param_name = f'{prefix}/{key}'
    try:
        import boto3
        ssm = boto3.client('ssm', region_name=os.environ.get('REGION', 'us-east-1'))
        resp = ssm.get_parameter(Name=param_name, WithDecryption=True)
        return resp['Parameter']['Value']
    except Exception as exc:
        logger.debug('SSM miss for %s: %s', param_name, exc)
        return None


def getenv(key: str, default: Optional[str] = None) -> Optional[str]:
    """
    Read a config value, checking SSM before ``os.environ``.

    SSM is only consulted when ``VELOCITY_SSM_ENABLED=true`` is set in the
    Lambda environment *and* both ``ProjectName`` and ``ENV`` are present.
    All other cases fall straight through to ``os.environ``.

    Results are cached per process so SSM is queried at most once per key
    per Lambda cold start.
    """
    if _is_enabled():
        if key not in _cache:
            value = _fetch(key)
            _cache[key] = value if value is not None else _MISS
        cached = _cache[key]
        if cached is not _MISS:
            return cached  # type: ignore[return-value]

    return os.environ.get(key, default)


def clear_cache() -> None:
    """Clear the SSM cache (useful in tests)."""
    _cache.clear()
    global _SSM_ENABLED
    _SSM_ENABLED = None
