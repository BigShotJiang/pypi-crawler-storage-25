from __future__ import annotations

from typing import Any, Mapping

from velocity.aws.assets.references import AssetReference, extract_asset_references_from_record
from velocity.aws.assets.usage_index import (
    AssetUsage,
    AssetUsageReconciliation,
    build_asset_usages,
    reconcile_asset_usages,
)


FORM_BUILDER_TEMPLATE_HTML_FIELDS = (
    "body_message_text",
    "form_instructions",
    "confirmation_body_text",
    "receipt_body_text",
    "rally_receipt_body_text",
    "pii_instructions",
    "metric_section_instructions",
    "donation_section_instructions",
    *tuple(f"donation_{index}_html" for index in range(1, 10)),
)

FORM_BUILDER_TEMPLATE_IMAGE_FIELDS = (
    "receipt_header_image",
    "secure_image_url",
    "header_banner_image_url",
    "background_image_url",
    "main_image_url",
    "body_header_url",
    "spot_image",
    "confirmation_header_image",
    "confirmation_body_image",
    *tuple(f"donation_{index}_image" for index in range(1, 10)),
    *tuple(f"metric_{index}_image" for index in range(1, 10)),
)


def reconcile_form_builder_template_asset_usages(
    tx,
    row: Mapping[str, Any] | Any,
    *,
    html_fields=FORM_BUILDER_TEMPLATE_HTML_FIELDS,
    image_fields=FORM_BUILDER_TEMPLATE_IMAGE_FIELDS,
    last_indexed_by: str = "velocity.aws.dirty_pipeline",
) -> AssetUsageReconciliation:
    source_row = _row_to_dict(row)
    source_sys_id = _as_string(source_row.get("sys_id"))
    if not source_sys_id:
        raise ValueError("form_builder_template row must include sys_id")

    references = extract_asset_references_from_record(
        source_row,
        html_fields=html_fields,
        image_fields=image_fields,
    )
    desired = build_asset_usages(
        references,
        source_table="form_builder_template",
        source_sys_id=source_sys_id,
        source_record_label=_build_source_record_label(source_row),
        last_source_modified=_as_string(source_row.get("sys_modified")),
        last_indexed_by=last_indexed_by,
        asset_id_resolver=lambda reference: resolve_asset_id_for_reference(tx, reference),
    )
    existing = load_asset_usages(
        tx,
        source_table="form_builder_template",
        source_sys_id=source_sys_id,
    )
    reconciliation = reconcile_asset_usages(existing, desired)
    apply_asset_usage_reconciliation(tx, reconciliation)
    return reconciliation


def load_asset_usages(tx, *, source_table: str, source_sys_id: str) -> list[AssetUsage]:
    usage_index = tx.table("asset_usage_index")
    if not usage_index.exists():
        return []

    rows = usage_index.select(
        where={
            "source_table": source_table,
            "source_sys_id": source_sys_id,
        }
    ).all()
    return [_row_to_asset_usage(row) for row in rows]


def apply_asset_usage_reconciliation(tx, reconciliation: AssetUsageReconciliation) -> None:
    table = tx.table("asset_usage_index")
    if not table.exists():
        return

    for usage in reconciliation.to_create + reconciliation.to_refresh:
        row = _asset_usage_to_row(usage)
        table.upsert(
            row,
            {
                "asset_id": row["asset_id"],
                "source_table": row["source_table"],
                "source_sys_id": row["source_sys_id"],
                "source_field": row["source_field"],
            },
        )

    for usage in reconciliation.to_delete:
        table.delete(
            where={
                "asset_id": usage.asset_id,
                "source_table": usage.source_table,
                "source_sys_id": usage.source_sys_id,
                "source_field": usage.source_field,
            }
        )


def resolve_asset_id_for_reference(tx, reference: AssetReference) -> str | None:
    if reference.asset_id:
        return reference.asset_id

    images = tx.table("images")
    if not images.exists():
        return None

    for candidate_key in _candidate_storage_keys(reference.storage_key):
        row = images.find({"key": candidate_key})
        asset_id = _extract_sys_id(row)
        if asset_id:
            return asset_id

    if reference.url and images.column("url").exists():
        row = images.find({"url": reference.url})
        asset_id = _extract_sys_id(row)
        if asset_id:
            return asset_id

    return None


def _candidate_storage_keys(storage_key: str | None) -> list[str]:
    if not storage_key:
        return []

    raw_value = storage_key.strip()
    normalized_value = raw_value.lstrip("/")
    candidates = [
        raw_value,
        normalized_value,
        f"/{normalized_value}",
        f"//{normalized_value}",
    ]
    deduped: list[str] = []
    for candidate in candidates:
        if candidate and candidate not in deduped:
            deduped.append(candidate)
    return deduped


def _row_to_asset_usage(row: Mapping[str, Any] | Any) -> AssetUsage:
    data = _row_to_dict(row)
    return AssetUsage(
        asset_id=_as_string(data.get("asset_id")) or "",
        source_table=_as_string(data.get("source_table")) or "",
        source_sys_id=_as_string(data.get("source_sys_id")) or "",
        source_field=_as_string(data.get("source_field")) or "",
        source_field_type=_as_string(data.get("source_field_type")) or "",
        asset_reference_value=_as_string(data.get("asset_reference_value")),
        asset_storage_key_snapshot=_as_string(data.get("asset_storage_key_snapshot")),
        asset_public_url_snapshot=_as_string(data.get("asset_public_url_snapshot")),
        source_record_label=_as_string(data.get("source_record_label")),
        last_source_modified=_as_string(data.get("last_source_modified")),
        last_indexed_by=_as_string(data.get("last_indexed_by")),
    )


def _asset_usage_to_row(usage: AssetUsage) -> dict[str, Any]:
    return {
        "asset_id": usage.asset_id,
        "source_table": usage.source_table,
        "source_sys_id": usage.source_sys_id,
        "source_field": usage.source_field,
        "source_field_type": usage.source_field_type,
        "asset_reference_value": usage.asset_reference_value,
        "asset_storage_key_snapshot": usage.asset_storage_key_snapshot,
        "asset_public_url_snapshot": usage.asset_public_url_snapshot,
        "source_record_label": usage.source_record_label,
        "last_source_modified": usage.last_source_modified,
        "last_indexed_by": usage.last_indexed_by,
    }


def _build_source_record_label(row: Mapping[str, Any]) -> str | None:
    for key in ("description", "page_title", "campaign"):
        label = _as_string(row.get(key))
        if label:
            return label

    client = _as_string(row.get("client"))
    campaign = _as_string(row.get("campaign"))
    if client and campaign:
        return f"{client} - {campaign}"
    return client or campaign


def _extract_sys_id(row: Mapping[str, Any] | Any) -> str | None:
    data = _row_to_dict(row)
    return _as_string(data.get("sys_id"))


def _row_to_dict(row: Mapping[str, Any] | Any) -> dict[str, Any]:
    if row is None:
        return {}
    if hasattr(row, "to_dict"):
        return row.to_dict()
    if isinstance(row, Mapping):
        return dict(row)
    raise TypeError(f"Unsupported row type: {type(row)!r}")


def _as_string(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None