from __future__ import annotations

import base64
from dataclasses import asdict, dataclass
import hashlib
import io
import os
from typing import Any, Callable, Mapping


Uploader = Callable[..., dict[str, Any]]


@dataclass(frozen=True)
class AssetRecord:
    asset_id: str | None
    bucket: str
    key: str
    url: str
    public_url: str
    public: bool
    client: str | None = None
    hash: str | None = None
    type: str | None = None
    format: str | None = None
    name: str | None = None
    filesize: int | None = None
    width: int | None = None
    height: int | None = None
    thumbnail_key: str | None = None
    is_animated: bool | None = None
    etag: str | None = None

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["sys_id"] = self.asset_id
        return data


@dataclass(frozen=True)
class AssetUploadResult:
    asset: AssetRecord
    uploaded: bool
    deduplicated: bool


def build_asset_key(
    *,
    client: str | None,
    filename: str,
    bucket: str,
    campaign: str | None = None,
) -> str:
    destination_parts = []
    if client:
        destination_parts.append(_sanitize_destination_part(client))
    if campaign:
        destination_parts.append(_sanitize_destination_part(campaign))
    destination_parts.append(_sanitize_relative_path(filename))
    destination = "/".join(part for part in destination_parts if part).lower()
    return f"//{bucket}/{destination}"


def normalize_asset_record(row: Mapping[str, Any]) -> AssetRecord:
    bucket = str(row.get("bucket") or "")
    key = str(row.get("key") or "")
    url = str(row.get("url") or _build_public_url(bucket, key))
    public_url = _build_public_url(bucket, key)
    return AssetRecord(
        asset_id=_as_string(row.get("sys_id")),
        bucket=bucket,
        key=key,
        url=url,
        public_url=public_url,
        public=bool(row.get("public")),
        client=_as_string(row.get("client")),
        hash=_as_string(row.get("hash")),
        type=_as_string(row.get("type")),
        format=_as_string(row.get("format")),
        name=_as_string(row.get("name")),
        filesize=_as_int(row.get("filesize") or row.get("size")),
        width=_as_int(row.get("width")),
        height=_as_int(row.get("height")),
        thumbnail_key=_as_string(row.get("thumbnail_key")),
        is_animated=_as_bool_or_none(row.get("is_animated")),
        etag=_as_string(row.get("etag")),
    )


def list_assets(
    tx,
    *,
    client: str | None = None,
    bucket: str | None = None,
    search: str | None = None,
    start: int | None = None,
    qty: int | None = None,
    include_thumbnails: bool = False,
    orderby: str = "client, key",
) -> list[AssetRecord]:
    where: dict[str, Any] = {}
    if client:
        where["client"] = client
    if bucket:
        where["bucket"] = bucket
    if not include_thumbnails:
        where["!%key"] = "%-thumb%"
    if search:
        where["%key"] = f"%{search}%"
    rows = tx.table("images").select(
        where=where or None,
        orderby=orderby,
        start=start,
        qty=qty,
    ).all()
    return [normalize_asset_record(row) for row in rows]


def find_existing_asset(
    tx,
    *,
    file_hash: str,
    bucket: str | None = None,
    client: str | None = None,
) -> AssetRecord | None:
    if not file_hash:
        return None
    where: dict[str, Any] = {"hash": file_hash}
    if bucket:
        where["bucket"] = bucket
    if client:
        where["client"] = client
    row = tx.table("images").find(where)
    if not row:
        return None
    return normalize_asset_record(row.to_dict())


def upload_image_asset(
    tx,
    *,
    source: Any,
    client: str | None,
    bucket: str,
    uploader: Uploader,
    campaign: str | None = None,
    force_new: bool = False,
    public: bool = True,
    is_image: bool = True,
    original_filename: str | None = None,
) -> AssetUploadResult:
    normalized_filename = original_filename or _extract_original_filename(source)
    file_hash = calculate_source_hash(source)
    if not force_new and file_hash:
        existing = find_existing_asset(
            tx,
            file_hash=file_hash,
            bucket=bucket,
            client=client,
        )
        if existing:
            return AssetUploadResult(
                asset=existing,
                uploaded=False,
                deduplicated=True,
            )

    key = build_asset_key(
        client=client,
        campaign=campaign,
        filename=normalized_filename,
        bucket=bucket,
    )
    uploaded_data = uploader(
        source,
        key=key,
        original_filename=normalized_filename,
        public=public,
        is_image=is_image,
    )
    tx.table("images").upsert(uploaded_data, {"key": uploaded_data["key"]})
    row = tx.table("images").find({"key": uploaded_data["key"]})
    asset = normalize_asset_record(row.to_dict() if row else uploaded_data)
    return AssetUploadResult(asset=asset, uploaded=True, deduplicated=False)


def calculate_source_hash(source: Any) -> str | None:
    raw = _read_source_bytes(source)
    if raw is None:
        return None
    return hashlib.sha256(raw).hexdigest()


def _read_source_bytes(source: Any) -> bytes | None:
    if source is None:
        return None
    if isinstance(source, bytes):
        return source
    if isinstance(source, str):
        return source.encode("utf-8")
    if hasattr(source, "read"):
        original_position = None
        if hasattr(source, "tell"):
            try:
                original_position = source.tell()
            except Exception:
                original_position = None
        raw = source.read()
        if original_position is not None and hasattr(source, "seek"):
            source.seek(original_position)
        if isinstance(raw, str):
            return raw.encode("utf-8")
        return raw
    if isinstance(source, Mapping):
        if "data" in source and isinstance(source["data"], str):
            return _decode_data_url(source["data"])
        if "file" in source and isinstance(source["file"], Mapping) and "data" in source["file"]:
            return _decode_data_url(source["file"]["data"])
    if hasattr(source, "data") and isinstance(source.data, str):
        return _decode_data_url(source.data)
    return None


def _decode_data_url(value: str) -> bytes:
    if "," in value:
        value = value.split(",", 1)[1]
    return base64.b64decode(value)


def _extract_original_filename(source: Any) -> str:
    if isinstance(source, Mapping):
        file_info = source.get("file")
        if isinstance(file_info, Mapping) and file_info.get("path"):
            return str(file_info["path"])
        if source.get("filename"):
            return str(source["filename"])
    if hasattr(source, "name") and source.name:
        return str(source.name)
    raise ValueError("Unable to determine original filename for asset upload")


def _sanitize_destination_part(value: str) -> str:
    return _sanitize_relative_path(value).replace("/", "-").replace(" ", "-")


def _sanitize_relative_path(path: str) -> str:
    path = (path or "").strip().lstrip("./").replace("\\", "/")
    parts = [segment for segment in path.split("/") if segment and segment not in {".", ".."}]
    return "/".join(parts)


def _build_public_url(bucket: str, key: str) -> str:
    return f"https://s3.amazonaws.com/{bucket}/{key}"


def _as_string(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _as_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _as_bool_or_none(value: Any) -> bool | None:
    if value is None:
        return None
    return bool(value)