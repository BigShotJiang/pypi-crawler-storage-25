from __future__ import annotations

from dataclasses import dataclass
import os
from typing import Any, Callable, Iterable, Mapping

from velocity.aws.assets.service import AssetRecord, normalize_asset_record
from velocity.aws.s3 import PRIVATE_BUCKETS


HeadLoader = Callable[[str, str], Mapping[str, Any] | None]


@dataclass(frozen=True)
class AssetBackfillSummary:
    scanned: int
    inserted: int
    skipped_existing: int
    skipped_unsupported: int


def iter_s3_objects(
    bucket: str,
    *,
    prefix: str = "",
    s3_client=None,
) -> Iterable[dict[str, Any]]:
    if s3_client is None:
        import boto3

        s3_client = boto3.client("s3")
    paginator = s3_client.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
        for row in page.get("Contents", []):
            yield row


def build_backfill_asset_data(
    bucket: str,
    object_info: Mapping[str, Any],
    *,
    head_info: Mapping[str, Any] | None = None,
) -> dict[str, Any] | None:
    key = str(object_info.get("Key") or "").strip()
    if not key or _is_thumbnail_key(key) or key.endswith("/"):
        return None
    metadata = dict((head_info or {}).get("Metadata") or {})
    filename = os.path.basename(key)
    file_ext = os.path.splitext(filename)[1][1:].lower() or None
    row = {
        "bucket": bucket,
        "key": key,
        "url": f"https://s3.amazonaws.com/{bucket}/{key}",
        "public": bucket not in PRIVATE_BUCKETS,
        "name": filename,
        "type": file_ext,
        "etag": _clean_etag(object_info.get("ETag") or (head_info or {}).get("ETag")),
        "filesize": _coerce_int(object_info.get("Size") or (head_info or {}).get("ContentLength")),
        "hash": metadata.get("hash"),
        "thumbnail_key": metadata.get("thumbnail_key"),
        "client": None if key.startswith("site/uploads") else key.split("/", 1)[0],
    }
    row.update(_copy_if_present(metadata, ["format", "width", "height", "is_animated"]))
    return row


def backfill_asset_records(
    tx,
    *,
    bucket: str,
    objects: Iterable[Mapping[str, Any]],
    head_loader: HeadLoader | None = None,
) -> tuple[list[AssetRecord], AssetBackfillSummary]:
    inserted_assets: list[AssetRecord] = []
    scanned = 0
    inserted = 0
    skipped_existing = 0
    skipped_unsupported = 0

    for object_info in objects:
        scanned += 1
        key = str(object_info.get("Key") or "").strip()
        if not key or _is_thumbnail_key(key) or key.endswith("/"):
            skipped_unsupported += 1
            continue
        if tx.table("images").find({"key": key}):
            skipped_existing += 1
            continue
        head_info = head_loader(bucket, key) if head_loader else None
        row = build_backfill_asset_data(bucket, object_info, head_info=head_info)
        if not row:
            skipped_unsupported += 1
            continue
        tx.table("images").upsert(row, {"key": row["key"]})
        inserted += 1
        stored = tx.table("images").find({"key": row["key"]})
        inserted_assets.append(normalize_asset_record(stored.to_dict() if stored else row))

    return inserted_assets, AssetBackfillSummary(
        scanned=scanned,
        inserted=inserted,
        skipped_existing=skipped_existing,
        skipped_unsupported=skipped_unsupported,
    )


def _is_thumbnail_key(key: str) -> bool:
    stem, ext = os.path.splitext(key)
    return stem.endswith("-thumb") and ext.lower() == ".png"


def _clean_etag(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip().strip('"')
    return text or None


def _coerce_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _copy_if_present(source: Mapping[str, Any], keys: list[str]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key in keys:
        if key not in source:
            continue
        value = source[key]
        if key in {"width", "height"}:
            result[key] = _coerce_int(value)
        elif key == "is_animated":
            result[key] = str(value).lower() in {"1", "true", "yes", "y"}
        else:
            result[key] = value
    return result