from __future__ import annotations

from dataclasses import dataclass
from html.parser import HTMLParser
import re
from typing import Any, Iterable, Mapping
from urllib.parse import urlparse


_MEDIA_TAGS = {"img", "source", "video", "audio"}
_ASSET_ID_KEYS = ("asset_id", "assetId", "id")
_URL_KEYS = ("url", "src", "href", "public_url", "publicUrl", "signed_url", "signedUrl")
_STORAGE_KEY_KEYS = ("storage_key", "storageKey", "key", "s3_key", "s3Key")
_NESTED_VALUE_KEYS = ("asset", "image", "media", "value")
_HTML_ASSET_ID_ATTRS = ("data-asset-id", "asset-id", "data-asset")
_HTML_URL_ATTRS = ("src", "href", "data-src")
_S3_HOST_RE = re.compile(r"(^|\.)s3[.-][a-z0-9-]+\.amazonaws\.com$|(^|\.)s3\.amazonaws\.com$")


@dataclass(frozen=True)
class AssetReference:
    asset_id: str | None = None
    url: str | None = None
    storage_key: str | None = None
    source_field: str | None = None
    source_field_type: str | None = None
    raw_value: str | None = None

    def dedupe_key(self) -> tuple[str | None, str | None, str | None, str | None, str | None]:
        return (
            self.source_field_type,
            self.source_field,
            self.asset_id,
            self.storage_key,
            self.url,
        )


class _AssetReferenceHtmlParser(HTMLParser):
    def __init__(self, source_field: str | None):
        super().__init__(convert_charrefs=True)
        self._source_field = source_field
        self.references: list[AssetReference] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attr_map = {name: value for name, value in attrs if value}
        if tag not in _MEDIA_TAGS and not any(key in attr_map for key in _HTML_ASSET_ID_ATTRS):
            return
        reference = _reference_from_mapping(
            attr_map,
            source_field=self._source_field,
            source_field_type="html",
            asset_id_keys=_HTML_ASSET_ID_ATTRS,
            url_keys=_HTML_URL_ATTRS,
            storage_key_keys=(),
        )
        if reference:
            self.references.append(reference)


def extract_asset_references_from_html(
    html: str | None,
    *,
    source_field: str | None = None,
) -> list[AssetReference]:
    if not html:
        return []
    parser = _AssetReferenceHtmlParser(source_field)
    parser.feed(html)
    parser.close()
    return _dedupe_references(parser.references)


def extract_asset_references_from_value(
    value: Any,
    *,
    source_field: str | None = None,
    source_field_type: str = "image-widget",
) -> list[AssetReference]:
    references = _extract_references_from_value(
        value,
        source_field=source_field,
        source_field_type=source_field_type,
    )
    return _dedupe_references(references)


def extract_asset_references_from_record(
    record: Mapping[str, Any],
    *,
    html_fields: Iterable[str] = (),
    image_fields: Iterable[str] = (),
) -> list[AssetReference]:
    references: list[AssetReference] = []
    for field_name in html_fields:
        references.extend(
            extract_asset_references_from_html(
                record.get(field_name),
                source_field=field_name,
            )
        )
    for field_name in image_fields:
        references.extend(
            extract_asset_references_from_value(
                record.get(field_name),
                source_field=field_name,
                source_field_type="image-widget",
            )
        )
    return _dedupe_references(references)


def _extract_references_from_value(
    value: Any,
    *,
    source_field: str | None,
    source_field_type: str,
) -> list[AssetReference]:
    if value is None:
        return []
    if isinstance(value, Mapping):
        reference = _reference_from_mapping(
            value,
            source_field=source_field,
            source_field_type=source_field_type,
            asset_id_keys=_ASSET_ID_KEYS,
            url_keys=_URL_KEYS,
            storage_key_keys=_STORAGE_KEY_KEYS,
        )
        if reference:
            return [reference]
        references: list[AssetReference] = []
        for key in _NESTED_VALUE_KEYS:
            if key in value:
                references.extend(
                    _extract_references_from_value(
                        value[key],
                        source_field=source_field,
                        source_field_type=source_field_type,
                    )
                )
        return references
    if isinstance(value, (list, tuple, set)):
        references: list[AssetReference] = []
        for item in value:
            references.extend(
                _extract_references_from_value(
                    item,
                    source_field=source_field,
                    source_field_type=source_field_type,
                )
            )
        return references
    if isinstance(value, str):
        reference = _reference_from_scalar(
            value,
            source_field=source_field,
            source_field_type=source_field_type,
        )
        return [reference] if reference else []
    return []


def _reference_from_mapping(
    value: Mapping[str, Any],
    *,
    source_field: str | None,
    source_field_type: str,
    asset_id_keys: Iterable[str],
    url_keys: Iterable[str],
    storage_key_keys: Iterable[str],
) -> AssetReference | None:
    asset_id = _first_string(value, asset_id_keys)
    url = _normalize_url(_first_string(value, url_keys))
    storage_key = _normalize_storage_key(_first_string(value, storage_key_keys))
    if not storage_key and url:
        storage_key = _storage_key_from_url(url)
    if not any((asset_id, url, storage_key)):
        return None
    raw_value = asset_id or url or storage_key
    return AssetReference(
        asset_id=asset_id,
        url=url,
        storage_key=storage_key,
        source_field=source_field,
        source_field_type=source_field_type,
        raw_value=raw_value,
    )


def _reference_from_scalar(
    value: str,
    *,
    source_field: str | None,
    source_field_type: str,
) -> AssetReference | None:
    raw_value = (value or "").strip()
    if not raw_value:
        return None
    url = _normalize_url(raw_value)
    asset_id = None if url else raw_value
    storage_key = _storage_key_from_url(url) if url else None
    return AssetReference(
        asset_id=asset_id,
        url=url,
        storage_key=storage_key,
        source_field=source_field,
        source_field_type=source_field_type,
        raw_value=raw_value,
    )


def _dedupe_references(references: Iterable[AssetReference]) -> list[AssetReference]:
    seen: set[tuple[str | None, str | None, str | None, str | None, str | None]] = set()
    deduped: list[AssetReference] = []
    for reference in references:
        key = reference.dedupe_key()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(reference)
    return deduped


def _first_string(value: Mapping[str, Any], keys: Iterable[str]) -> str | None:
    for key in keys:
        candidate = value.get(key)
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()
    return None


def _normalize_url(value: str | None) -> str | None:
    if not value:
        return None
    parsed = urlparse(value)
    if parsed.scheme in {"http", "https", "s3"}:
        return value.strip()
    return None


def _normalize_storage_key(value: str | None) -> str | None:
    if not value:
        return None
    return value.strip().lstrip("/") or None


def _storage_key_from_url(url: str | None) -> str | None:
    if not url:
        return None
    parsed = urlparse(url)
    if parsed.scheme == "s3":
        return parsed.path.lstrip("/") or None
    if parsed.scheme not in {"http", "https"}:
        return None
    host = parsed.netloc.lower()
    if _S3_HOST_RE.search(host):
        path = parsed.path.lstrip("/")
        if host.startswith("s3.") or host == "s3.amazonaws.com":
            parts = path.split("/", 1)
            return parts[1] if len(parts) == 2 else None
        return path or None
    return None