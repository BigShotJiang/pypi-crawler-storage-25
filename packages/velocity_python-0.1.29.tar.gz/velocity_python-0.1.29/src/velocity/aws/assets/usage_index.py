from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable

from velocity.aws.assets.references import AssetReference


AssetIdResolver = Callable[[AssetReference], str | None]


@dataclass(frozen=True)
class AssetUsage:
    asset_id: str
    source_table: str
    source_sys_id: str
    source_field: str
    source_field_type: str
    asset_reference_value: str | None = None
    asset_storage_key_snapshot: str | None = None
    asset_public_url_snapshot: str | None = None
    source_record_label: str | None = None
    last_source_modified: str | None = None
    last_indexed_by: str | None = None

    def identity_key(self) -> tuple[str, str, str, str]:
        return (
            self.asset_id,
            self.source_table,
            self.source_sys_id,
            self.source_field,
        )


@dataclass(frozen=True)
class AssetUsageReconciliation:
    to_create: list[AssetUsage]
    to_refresh: list[AssetUsage]
    to_delete: list[AssetUsage]


def build_asset_usages(
    references: Iterable[AssetReference],
    *,
    source_table: str,
    source_sys_id: str,
    source_record_label: str | None = None,
    last_source_modified: str | None = None,
    last_indexed_by: str | None = None,
    asset_id_resolver: AssetIdResolver | None = None,
) -> list[AssetUsage]:
    usages: list[AssetUsage] = []
    for reference in references:
        usage = _build_asset_usage(
            reference,
            source_table=source_table,
            source_sys_id=source_sys_id,
            source_record_label=source_record_label,
            last_source_modified=last_source_modified,
            last_indexed_by=last_indexed_by,
            asset_id_resolver=asset_id_resolver,
        )
        if usage:
            usages.append(usage)
    return _dedupe_usages(usages)


def reconcile_asset_usages(
    existing: Iterable[AssetUsage],
    desired: Iterable[AssetUsage],
) -> AssetUsageReconciliation:
    existing_map = {usage.identity_key(): usage for usage in existing}
    desired_map = {usage.identity_key(): usage for usage in desired}

    to_create = [desired_map[key] for key in desired_map.keys() - existing_map.keys()]
    to_refresh = [desired_map[key] for key in desired_map.keys() & existing_map.keys()]
    to_delete = [existing_map[key] for key in existing_map.keys() - desired_map.keys()]

    return AssetUsageReconciliation(
        to_create=sorted(to_create, key=_usage_sort_key),
        to_refresh=sorted(to_refresh, key=_usage_sort_key),
        to_delete=sorted(to_delete, key=_usage_sort_key),
    )


def _build_asset_usage(
    reference: AssetReference,
    *,
    source_table: str,
    source_sys_id: str,
    source_record_label: str | None,
    last_source_modified: str | None,
    last_indexed_by: str | None,
    asset_id_resolver: AssetIdResolver | None,
) -> AssetUsage | None:
    asset_id = reference.asset_id
    if not asset_id and asset_id_resolver:
        asset_id = asset_id_resolver(reference)
    if not asset_id:
        return None
    if not reference.source_field or not reference.source_field_type:
        raise ValueError("AssetReference must include source_field and source_field_type")
    return AssetUsage(
        asset_id=asset_id,
        source_table=source_table,
        source_sys_id=source_sys_id,
        source_field=reference.source_field,
        source_field_type=reference.source_field_type,
        asset_reference_value=reference.raw_value,
        asset_storage_key_snapshot=reference.storage_key,
        asset_public_url_snapshot=reference.url,
        source_record_label=source_record_label,
        last_source_modified=last_source_modified,
        last_indexed_by=last_indexed_by,
    )


def _dedupe_usages(usages: Iterable[AssetUsage]) -> list[AssetUsage]:
    usage_map = {usage.identity_key(): usage for usage in usages}
    return sorted(usage_map.values(), key=_usage_sort_key)


def _usage_sort_key(usage: AssetUsage) -> tuple[str, str, str, str]:
    return usage.identity_key()