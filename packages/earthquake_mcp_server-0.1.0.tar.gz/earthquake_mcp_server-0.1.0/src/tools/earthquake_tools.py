"""
MCP-Tools fuer Erdbeben-Daten (USGS Earthquake Catalog API).
Alle Daten sind Open Data, kein API-Key erforderlich.
"""

from datetime import datetime, timedelta
from typing import Optional
from ..clients.usgs_client import fetch_earthquakes, fetch_earthquake_count, parse_earthquake_feature


async def tool_get_recent_earthquakes(
    hours: int = 24,
    min_magnitude: float = 2.5,
    limit: int = 20,
) -> dict:
    """
    Aktuelle Erdbeben der letzten N Stunden abrufen.

    Args:
        hours: Zeitraum in Stunden (Standard: 24, max: 168)
        min_magnitude: Minimale Magnitude (Standard: 2.5)
        limit: Maximale Anzahl Ergebnisse (Standard: 20, max: 100)

    Returns:
        Liste der aktuellen Erdbeben mit Ort, Magnitude, Tiefe und Zeitstempel
    """
    hours = min(max(1, hours), 168)  # 1 Stunde bis 7 Tage
    starttime = (datetime.utcnow() - timedelta(hours=hours)).strftime("%Y-%m-%dT%H:%M:%S")

    data = await fetch_earthquakes(
        starttime=starttime,
        minmagnitude=min_magnitude,
        limit=limit,
        orderby="time",
    )

    features = data.get("features", [])
    earthquakes = [parse_earthquake_feature(f) for f in features]

    return {
        "query": {
            "hours": hours,
            "min_magnitude": min_magnitude,
            "limit": limit,
        },
        "total_found": data.get("metadata", {}).get("count", len(features)),
        "earthquakes": earthquakes,
    }


async def tool_search_earthquakes(
    start_date: str,
    end_date: Optional[str] = None,
    min_magnitude: Optional[float] = None,
    max_magnitude: Optional[float] = None,
    region: Optional[str] = None,
    limit: int = 20,
) -> dict:
    """
    Erdbeben nach Datum und Magnitude suchen.

    Args:
        start_date: Startdatum (Format: YYYY-MM-DD)
        end_date: Enddatum (Format: YYYY-MM-DD, Standard: heute)
        min_magnitude: Minimale Magnitude
        max_magnitude: Maximale Magnitude
        region: Beschreibungstext zur Region (fuer die Ausgabe, nicht API-Filter)
        limit: Maximale Anzahl Ergebnisse (Standard: 20, max: 100)

    Returns:
        Gefilterte Erdbeben-Liste
    """
    data = await fetch_earthquakes(
        starttime=f"{start_date}T00:00:00",
        endtime=f"{end_date}T23:59:59" if end_date else None,
        minmagnitude=min_magnitude,
        maxmagnitude=max_magnitude,
        limit=limit,
        orderby="time",
    )

    features = data.get("features", [])
    earthquakes = [parse_earthquake_feature(f) for f in features]

    return {
        "query": {
            "start_date": start_date,
            "end_date": end_date or "heute",
            "min_magnitude": min_magnitude,
            "max_magnitude": max_magnitude,
            "region": region,
        },
        "total_found": data.get("metadata", {}).get("count", len(features)),
        "earthquakes": earthquakes,
    }


async def tool_get_significant_earthquakes(
    days: int = 30,
    min_magnitude: float = 5.0,
    limit: int = 20,
) -> dict:
    """
    Bedeutende/starke Erdbeben der letzten N Tage abrufen.

    Args:
        days: Zeitraum in Tagen (Standard: 30, max: 365)
        min_magnitude: Minimale Magnitude (Standard: 5.0)
        limit: Maximale Anzahl Ergebnisse (Standard: 20, max: 100)

    Returns:
        Liste der bedeutenden Erdbeben sortiert nach Magnitude
    """
    days = min(max(1, days), 365)
    starttime = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%S")

    data = await fetch_earthquakes(
        starttime=starttime,
        minmagnitude=min_magnitude,
        limit=limit,
        orderby="magnitude",
    )

    features = data.get("features", [])
    earthquakes = [parse_earthquake_feature(f) for f in features]

    # Tsunami-Warnungen hervorheben
    with_tsunami = [e for e in earthquakes if e.get("tsunami_warning")]
    with_alert = [e for e in earthquakes if e.get("alert_level") in ("yellow", "orange", "red")]

    return {
        "query": {
            "days": days,
            "min_magnitude": min_magnitude,
        },
        "total_found": data.get("metadata", {}).get("count", len(features)),
        "tsunami_warnings": len(with_tsunami),
        "with_alert": len(with_alert),
        "earthquakes": earthquakes,
    }


async def tool_earthquakes_near_location(
    latitude: float,
    longitude: float,
    radius_km: float = 200,
    days: int = 30,
    min_magnitude: float = 2.0,
    limit: int = 20,
) -> dict:
    """
    Erdbeben in der Naehe eines Ortes (Koordinaten) abrufen.

    Args:
        latitude: Breitengrad (-90 bis 90)
        longitude: Laengengrad (-180 bis 180)
        radius_km: Suchradius in Kilometern (Standard: 200 km)
        days: Zeitraum in Tagen (Standard: 30)
        min_magnitude: Minimale Magnitude (Standard: 2.0)
        limit: Maximale Anzahl Ergebnisse (Standard: 20, max: 100)

    Returns:
        Erdbeben in der Naehe des angegebenen Punktes
    """
    days = min(max(1, days), 365)
    starttime = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%S")

    data = await fetch_earthquakes(
        starttime=starttime,
        latitude=latitude,
        longitude=longitude,
        maxradiuskm=radius_km,
        minmagnitude=min_magnitude,
        limit=limit,
        orderby="time",
    )

    features = data.get("features", [])
    earthquakes = [parse_earthquake_feature(f) for f in features]

    return {
        "query": {
            "center": {"latitude": latitude, "longitude": longitude},
            "radius_km": radius_km,
            "days": days,
            "min_magnitude": min_magnitude,
        },
        "total_found": data.get("metadata", {}).get("count", len(features)),
        "earthquakes": earthquakes,
    }


async def tool_get_seismic_summary() -> dict:
    """
    Seismische Zusammenfassung der letzten 24 Stunden abrufen.
    Zeigt Aktivitaetsniveaus nach Magnitudenklasse.

    Returns:
        Statistik-Uebersicht der globalen seismischen Aktivitaet
    """
    starttime = (datetime.utcnow() - timedelta(hours=24)).strftime("%Y-%m-%dT%H:%M:%S")

    # Parallele Abfragen fuer verschiedene Magnitudenklassen
    all_quakes_data = await fetch_earthquakes(starttime=starttime, minmagnitude=1.0, limit=100)
    all_quakes = [parse_earthquake_feature(f) for f in all_quakes_data.get("features", [])]

    # Einteilung nach Magnitudenklassen
    micro = [q for q in all_quakes if q["magnitude"] and q["magnitude"] < 2.0]
    minor = [q for q in all_quakes if q["magnitude"] and 2.0 <= q["magnitude"] < 3.0]
    light = [q for q in all_quakes if q["magnitude"] and 3.0 <= q["magnitude"] < 4.0]
    moderate = [q for q in all_quakes if q["magnitude"] and 4.0 <= q["magnitude"] < 5.0]
    strong = [q for q in all_quakes if q["magnitude"] and 5.0 <= q["magnitude"] < 6.0]
    major = [q for q in all_quakes if q["magnitude"] and q["magnitude"] >= 6.0]

    # Staerekste Ereignis
    strongest = max(all_quakes, key=lambda x: x["magnitude"] or 0) if all_quakes else None

    return {
        "period": "Letzte 24 Stunden (UTC)",
        "generated_at": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
        "activity_summary": {
            "micro_M1_2": len(micro),
            "minor_M2_3": len(minor),
            "light_M3_4": len(light),
            "moderate_M4_5": len(moderate),
            "strong_M5_6": len(strong),
            "major_M6plus": len(major),
            "total": len(all_quakes),
        },
        "strongest_event": strongest,
        "tsunami_warnings": sum(1 for q in all_quakes if q.get("tsunami_warning")),
        "with_felt_reports": sum(1 for q in all_quakes if q.get("felt_reports")),
        "activity_level": _calculate_activity_level(len(major), len(strong)),
    }


async def tool_get_earthquake_count(
    start_date: str,
    end_date: Optional[str] = None,
    min_magnitude: Optional[float] = None,
) -> dict:
    """
    Anzahl der Erdbeben fuer einen Zeitraum abrufen.

    Args:
        start_date: Startdatum (Format: YYYY-MM-DD)
        end_date: Enddatum (Format: YYYY-MM-DD)
        min_magnitude: Minimale Magnitude

    Returns:
        Anzahl der Erdbeben im angegebenen Zeitraum
    """
    data = await fetch_earthquake_count(
        starttime=f"{start_date}T00:00:00",
        endtime=f"{end_date}T23:59:59" if end_date else None,
        minmagnitude=min_magnitude,
    )

    return {
        "query": {
            "start_date": start_date,
            "end_date": end_date or "heute",
            "min_magnitude": min_magnitude,
        },
        "count": data.get("count", 0),
        "max_allowed": data.get("maxAllowed", 20000),
    }


async def tool_get_largest_earthquakes(
    years: int = 1,
    limit: int = 10,
) -> dict:
    """
    Die groessten Erdbeben der letzten Jahre abrufen.

    Args:
        years: Zeitraum in Jahren (Standard: 1, max: 10)
        limit: Anzahl der Ergebnisse (Standard: 10, max: 50)

    Returns:
        Liste der groessten Erdbeben sortiert nach Magnitude (absteigend)
    """
    years = min(max(1, years), 10)
    limit = min(limit, 50)
    starttime = (datetime.utcnow() - timedelta(days=years * 365)).strftime("%Y-%m-%dT%H:%M:%S")

    data = await fetch_earthquakes(
        starttime=starttime,
        minmagnitude=5.0,
        limit=limit,
        orderby="magnitude",
    )

    features = data.get("features", [])
    earthquakes = [parse_earthquake_feature(f) for f in features]

    return {
        "query": {"years": years, "limit": limit},
        "total_found": data.get("metadata", {}).get("count", len(features)),
        "top_earthquakes": earthquakes,
    }


async def tool_get_magnitude_info() -> dict:
    """
    Erklaerung der Richter-Skala und Magnitudenklassen abrufen.
    Bildungsinhalt zur Interpretation von Erdbebenstaerken.

    Returns:
        Erklaerung der Magnitudenklassen und ihrer Auswirkungen
    """
    return {
        "scale": "Moment Magnitude Scale (Mw) -- moderne Nachfolge der Richter-Skala",
        "magnitude_classes": [
            {
                "class": "Mikro",
                "range": "< 2.0",
                "frequency": "~8.000 pro Tag weltweit",
                "effects": "Nicht spuerbar, nur von Seismographen erkannt",
            },
            {
                "class": "Minor (Gering)",
                "range": "2.0 - 3.9",
                "frequency": "~1.000 pro Tag",
                "effects": "Kaum spuerbar, keine Schaeden",
            },
            {
                "class": "Light (Leicht)",
                "range": "4.0 - 4.9",
                "frequency": "~6.200 pro Jahr",
                "effects": "Spuerbar, leichte Schaeden an instabilen Gebaeuden",
            },
            {
                "class": "Moderate (Maessig)",
                "range": "5.0 - 5.9",
                "frequency": "~800 pro Jahr",
                "effects": "Deutlich spuerbar, moderate Schaeden in dicht besiedelten Gebieten",
            },
            {
                "class": "Strong (Stark)",
                "range": "6.0 - 6.9",
                "frequency": "~120 pro Jahr",
                "effects": "Schwere Schaeden in grossen Gebieten, 10-fach staerker als M5",
            },
            {
                "class": "Major (Stark)",
                "range": "7.0 - 7.9",
                "frequency": "~18 pro Jahr",
                "effects": "Massive Schaeden ueber grosse Gebiete, Tsunami moeglich",
            },
            {
                "class": "Great (Sehr stark)",
                "range": "8.0+",
                "frequency": "~1 pro Jahr",
                "effects": "Verheerend, kann ganze Regionen zerstoeren",
            },
        ],
        "data_source": "USGS Earthquake Hazards Program",
        "api_url": "https://earthquake.usgs.gov/fdsnws/event/1/",
        "note": "Logarithmische Skala: jede Stufe = 10x staerkere Bodenbewegung",
    }


def _calculate_activity_level(major_count: int, strong_count: int) -> str:
    """Berechnet das seismische Aktivitaetsniveau."""
    if major_count >= 2:
        return "SEHR HOCH (M6+ Ereignisse)"
    elif major_count >= 1:
        return "HOCH (M6+ Ereignis)"
    elif strong_count >= 5:
        return "ERHOHT (mehrere M5+ Ereignisse)"
    elif strong_count >= 1:
        return "MODERAT (M5+ Ereignis)"
    else:
        return "NORMAL (keine starken Erdbeben)"
