"""
USGS Earthquake Catalog API Client.
Dokumentation: https://earthquake.usgs.gov/fdsnws/event/1/
Kein API-Key noetig, vollstaendig Open Data.
"""

import httpx
from datetime import datetime, timedelta
from typing import Optional

# Basis-URL des USGS FDSN Web Service
USGS_BASE_URL = "https://earthquake.usgs.gov/fdsnws/event/1"

# Standard-Timeout fuer API-Requests
TIMEOUT = 30.0


async def fetch_earthquakes(
    starttime: Optional[str] = None,
    endtime: Optional[str] = None,
    minmagnitude: Optional[float] = None,
    maxmagnitude: Optional[float] = None,
    minlatitude: Optional[float] = None,
    maxlatitude: Optional[float] = None,
    minlongitude: Optional[float] = None,
    maxlongitude: Optional[float] = None,
    latitude: Optional[float] = None,
    longitude: Optional[float] = None,
    maxradiuskm: Optional[float] = None,
    limit: int = 20,
    orderby: str = "time",
) -> dict:
    """Erdbeben aus dem USGS Catalog abrufen."""
    # Standard: letzte 24 Stunden falls kein Zeitraum angegeben
    if not starttime:
        starttime = (datetime.utcnow() - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%S")

    params = {
        "format": "geojson",
        "starttime": starttime,
        "limit": min(limit, 100),
        "orderby": orderby,
    }

    # Optionale Parameter hinzufuegen
    if endtime:
        params["endtime"] = endtime
    if minmagnitude is not None:
        params["minmagnitude"] = minmagnitude
    if maxmagnitude is not None:
        params["maxmagnitude"] = maxmagnitude
    if minlatitude is not None:
        params["minlatitude"] = minlatitude
    if maxlatitude is not None:
        params["maxlatitude"] = maxlatitude
    if minlongitude is not None:
        params["minlongitude"] = minlongitude
    if maxlongitude is not None:
        params["maxlongitude"] = maxlongitude
    if latitude is not None and longitude is not None:
        params["latitude"] = latitude
        params["longitude"] = longitude
        if maxradiuskm:
            params["maxradiuskm"] = maxradiuskm

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        response = await client.get(f"{USGS_BASE_URL}/query", params=params)
        response.raise_for_status()
        return response.json()


async def fetch_earthquake_count(
    starttime: Optional[str] = None,
    endtime: Optional[str] = None,
    minmagnitude: Optional[float] = None,
) -> dict:
    """Anzahl der Erdbeben fuer einen Zeitraum abrufen."""
    if not starttime:
        starttime = (datetime.utcnow() - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%S")

    params = {
        "format": "geojson",
        "starttime": starttime,
    }
    if endtime:
        params["endtime"] = endtime
    if minmagnitude is not None:
        params["minmagnitude"] = minmagnitude

    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        response = await client.get(f"{USGS_BASE_URL}/count", params=params)
        response.raise_for_status()
        return response.json()


def parse_earthquake_feature(feature: dict) -> dict:
    """GeoJSON Feature in ein lesbares Dict umwandeln."""
    props = feature.get("properties", {})
    geo = feature.get("geometry", {})
    coords = geo.get("coordinates", [None, None, None])

    return {
        "id": feature.get("id", ""),
        "magnitude": props.get("mag"),
        "magnitude_type": props.get("magType", ""),
        "place": props.get("place", "Unbekannt"),
        "time_utc": datetime.utcfromtimestamp(props["time"] / 1000).strftime("%Y-%m-%d %H:%M:%S UTC")
        if props.get("time")
        else "Unbekannt",
        "depth_km": coords[2] if coords[2] is not None else "Unbekannt",
        "latitude": coords[1],
        "longitude": coords[0],
        "status": props.get("status", ""),
        "felt_reports": props.get("felt"),
        "alert_level": props.get("alert"),
        "tsunami_warning": bool(props.get("tsunami", 0)),
        "significance": props.get("sig", 0),
        "url": props.get("url", ""),
        "detail_url": props.get("detail", ""),
        "type": props.get("type", "earthquake"),
        "updated_utc": datetime.utcfromtimestamp(props["updated"] / 1000).strftime("%Y-%m-%d %H:%M:%S UTC")
        if props.get("updated")
        else "Unbekannt",
    }
