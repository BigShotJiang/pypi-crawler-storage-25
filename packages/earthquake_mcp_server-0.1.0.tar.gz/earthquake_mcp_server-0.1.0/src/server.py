"""
Earthquake MCP Server -- Echtzeit-Erdbebendaten via USGS Earthquake Catalog API.
Kein API-Key noetig. Alle Daten sind Open Data.
"""

from fastmcp import FastMCP
from .tools.earthquake_tools import (
    tool_get_recent_earthquakes,
    tool_search_earthquakes,
    tool_get_significant_earthquakes,
    tool_earthquakes_near_location,
    tool_get_seismic_summary,
    tool_get_earthquake_count,
    tool_get_largest_earthquakes,
    tool_get_magnitude_info,
)

# FastMCP Server-Instanz
mcp = FastMCP(
    name="earthquake-mcp-server",
    instructions=(
        "Provides real-time earthquake data and seismic monitoring via the USGS Earthquake Catalog API. "
        "No API key required. Data includes earthquake magnitude, location, depth, tsunami warnings, "
        "felt reports, and alert levels. Use this to monitor seismic activity, research historical "
        "earthquakes, or get safety information about earthquake hazards."
    ),
)

# Tools registrieren
mcp.tool()(tool_get_recent_earthquakes)
mcp.tool()(tool_search_earthquakes)
mcp.tool()(tool_get_significant_earthquakes)
mcp.tool()(tool_earthquakes_near_location)
mcp.tool()(tool_get_seismic_summary)
mcp.tool()(tool_get_earthquake_count)
mcp.tool()(tool_get_largest_earthquakes)
mcp.tool()(tool_get_magnitude_info)


def main():
    """Einstiegspunkt fuer den MCP-Server."""
    mcp.run()


if __name__ == "__main__":
    main()
