# earthquake-mcp-server

[![PyPI version](https://badge.fury.io/py/earthquake-mcp-server.svg)](https://badge.fury.io/py/earthquake-mcp-server)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

Real-time earthquake data and seismic monitoring for AI agents via the **USGS Earthquake Catalog API**. No API key required — all data is open and free.

## Features

- **Real-time data** from the USGS Earthquake Hazards Program
- **No API key needed** — fully open data
- **Global coverage** — all earthquakes worldwide
- Tsunami warnings, felt reports, and PAGER alert levels
- Magnitude filtering, date ranges, and radius search
- Historical data going back decades

## Tools

| Tool | Description |
|------|-------------|
| `tool_get_recent_earthquakes` | Recent earthquakes (last N hours), filtered by magnitude |
| `tool_search_earthquakes` | Search by date range and magnitude |
| `tool_get_significant_earthquakes` | Major earthquakes (M5.0+) sorted by magnitude |
| `tool_earthquakes_near_location` | Earthquakes within a radius of lat/lon coordinates |
| `tool_get_seismic_summary` | 24h global seismic activity summary with statistics |
| `tool_get_earthquake_count` | Count earthquakes in a time range |
| `tool_get_largest_earthquakes` | Top N largest earthquakes in the last N years |
| `tool_get_magnitude_info` | Educational: Moment Magnitude Scale explained |

## Installation

```bash
pip install earthquake-mcp-server
```

## Usage with Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "earthquake": {
      "command": "earthquake-mcp-server"
    }
  }
}
```

## Example Queries

- "Show me all earthquakes in the last 24 hours with magnitude 4.0+"
- "Were there any significant earthquakes near Japan this week?"
- "What is the seismic activity summary for today?"
- "Find earthquakes near coordinates 35.6°N, 139.7°E (Tokyo) in the last 30 days"
- "What are the 10 largest earthquakes in the last year?"
- "How strong was the strongest earthquake this month?"

## Data Source

All data comes from the [USGS Earthquake Catalog API](https://earthquake.usgs.gov/fdsnws/event/1/), maintained by the U.S. Geological Survey. Data is real-time and updated continuously.

## License

MIT License — see [LICENSE](LICENSE)

## Related MCP Servers

- [space-mcp-server](https://github.com/AiAgentKarl/space-mcp-server) — NASA space data
- [climate-risk-mcp-server](https://github.com/AiAgentKarl/climate-risk-mcp-server) — Climate & ESG data
- [geospatial-mcp-server](https://github.com/AiAgentKarl/geospatial-mcp-server) — OpenStreetMap & geospatial tools
