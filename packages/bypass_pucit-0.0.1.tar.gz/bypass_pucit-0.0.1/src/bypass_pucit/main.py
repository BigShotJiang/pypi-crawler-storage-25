import sys
from pathlib import Path


if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from bypass_pucit.cli import main as cli_main
else:
    from .cli import main as cli_main


def main(argv=None):
    return cli_main(argv)


if __name__ == "__main__":
    raise SystemExit(main())
