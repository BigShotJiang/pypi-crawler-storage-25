(function () {
  function $(id) {
    return document.getElementById(id);
  }

  var TAB_ACTIVE =
    "rounded-lg border border-sky-500/60 bg-sky-500/15 px-4 py-2 text-sm font-semibold text-sky-200 shadow-sm transition hover:bg-sky-500/25";
  var TAB_IDLE =
    "rounded-lg border border-slate-700 bg-slate-900/50 px-4 py-2 text-sm font-medium text-slate-300 transition hover:border-slate-600 hover:bg-slate-800/60";

  function setTabPanels(active) {
    var tabs = ["references", "codespace", "practice"];
    tabs.forEach(function (name) {
      var panel = $("panel-" + name);
      var btn = $("tab-" + name);
      if (!panel || !btn) return;
      var isOn = name === active;
      panel.hidden = !isOn;
      btn.setAttribute("aria-selected", isOn ? "true" : "false");
      btn.tabIndex = isOn ? 0 : -1;
      btn.className = isOn ? TAB_ACTIVE : TAB_IDLE;
    });
  }

  function initTabs() {
    ["references", "codespace", "practice"].forEach(function (name) {
      var btn = $("tab-" + name);
      if (!btn) return;
      btn.addEventListener("click", function () {
        setTabPanels(name);
      });
    });
  }

  function formatRunResult(result) {
    var parts = [];
    if (result.stdout) parts.push(result.stdout);
    if (result.stderr) {
      parts.push(
        (parts.length ? "\n--- stderr ---\n" : "") + result.stderr
      );
    }
    if (!parts.length && !result.ok) {
      parts.push("(no output)");
    }
    return parts.join("");
  }

  function initCodespace() {
    var btn = $("codespace-run");
    var out = $("codespace-output");
    var ta = $("codespace-editor");
    if (!btn || !out || !ta) return;

    btn.addEventListener("click", async function () {
      out.textContent = "Running…";
      btn.disabled = true;
      var result = await window.splRunCode(ta.value || "");
      btn.disabled = false;
      out.textContent = formatRunResult(result);
      if (!result.ok) {
        out.textContent +=
          "\n(exit code " + String(result.exitCode) + ")";
      }
    });
  }

  function pickRandomProblem(excludeId) {
    var list = window.SPL_PRACTICE;
    if (!list || !list.length) return null;
    var pool = list.filter(function (p) {
      return !excludeId || p.id !== excludeId;
    });
    if (!pool.length) pool = list;
    return pool[Math.floor(Math.random() * pool.length)];
  }

  var practiceState = {
    current: null,
    done: true,
  };

  function setPracticeButtons() {
    var runBtn = $("practice-run");
    var giveBtn = $("practice-giveup");
    var nextBtn = $("practice-next");
    var editor = $("practice-editor");
    if (!runBtn || !giveBtn || !nextBtn || !editor) return;

    var locked = practiceState.done;
    runBtn.disabled = locked;
    giveBtn.disabled = locked;
    editor.disabled = locked;
    nextBtn.disabled = !locked;
  }

  function renderPractice() {
    var titleEl = $("practice-title");
    var promptEl = $("practice-prompt");
    var editor = $("practice-editor");
    var statusEl = $("practice-status");
    var solEl = $("practice-solution");
    var outEl = $("practice-output");

    if (!titleEl || !promptEl || !editor) return;

    var p = practiceState.current;
    if (!p) {
      titleEl.textContent = "No problems loaded";
      promptEl.innerHTML = "";
      return;
    }

    titleEl.textContent = p.title;
    promptEl.innerHTML = p.prompt;
    if (statusEl) statusEl.textContent = "";
    if (solEl) {
      solEl.classList.add("hidden");
      var pre = solEl.querySelector("pre");
      if (pre) pre.textContent = "";
    }
    if (outEl) outEl.textContent = "";
    setPracticeButtons();
  }

  function resetPracticeEditor(editor, problem) {
    var s =
      problem && problem.starter != null ? String(problem.starter) : "";
    editor.value = "";
    editor.value = s;
  }

  function loadRandomPractice() {
    var prevId = practiceState.current && practiceState.current.id;
    practiceState.current = pickRandomProblem(prevId);
    practiceState.done = false;
    var editor = $("practice-editor");
    if (editor && practiceState.current) {
      resetPracticeEditor(editor, practiceState.current);
    }
    renderPractice();
  }

  function initPractice() {
    var runBtn = $("practice-run");
    var giveBtn = $("practice-giveup");
    var nextBtn = $("practice-next");
    var editor = $("practice-editor");
    var statusEl = $("practice-status");
    var solEl = $("practice-solution");
    var solPre = solEl && solEl.querySelector("pre");
    var outEl = $("practice-output");

    if (!runBtn || !giveBtn || !nextBtn || !editor || !statusEl || !solEl || !solPre || !outEl) {
      return;
    }

    runBtn.addEventListener("click", async function () {
      if (practiceState.done || !practiceState.current) return;
      var p = practiceState.current;
      outEl.textContent =
        "Running 100 trials (20 fixed edge-case seeds + 80 random) on the server — may take ~25–45 seconds…";
      statusEl.textContent = "";
      runBtn.disabled = true;
      var check = await window.splPracticeCheck(p.id, editor.value || "");
      runBtn.disabled = false;

      if (!check) {
        outEl.textContent = "Unknown error.";
        statusEl.textContent = "Could not grade this run.";
        statusEl.className = "mt-2 text-sm text-amber-400/95";
        return;
      }

      if (check.passed === true) {
        outEl.textContent =
          "All " +
          String(check.testsRun || 100) +
          " trials passed (" +
          String(check.seededTrials != null ? check.seededTrials : 20) +
          " edge-case seeds + " +
          String(check.randomTrials != null ? check.randomTrials : 80) +
          " random). Output matched the reference every time.";
        statusEl.textContent = "Correct! Click “Next problem” to continue.";
        statusEl.className = "mt-2 text-sm text-emerald-400/95";
        practiceState.done = true;
        setPracticeButtons();
        return;
      }

      if (check.failedAt == null && check.error) {
        outEl.textContent = check.error;
        statusEl.textContent = "Could not grade this run.";
        statusEl.className = "mt-2 text-sm text-amber-400/95";
        return;
      }

      var lines = [];
      lines.push(
        "Failed at trial " +
          String(check.failedAt || "?") +
          " of " +
          String(check.testsRun || "?") +
          " (" +
          String(check.phase || "unknown") +
          ")."
      );
      if (check.detail) lines.push(check.detail);
      if (check.stdout) lines.push("--- your stdout (last failing run) ---\n" + check.stdout);
      if (check.expectedSample != null && check.gotSample != null) {
        lines.push(
          "--- reference output (sample) ---\n" + check.expectedSample
        );
        lines.push("--- your output (sample) ---\n" + check.gotSample);
      }
      outEl.textContent = lines.join("\n\n");
      statusEl.textContent =
        "Not yet — fix your program or use Give up to see the reference solution.";
      statusEl.className = "mt-2 text-sm text-slate-400";
    });

    giveBtn.addEventListener("click", function () {
      if (practiceState.done || !practiceState.current) return;
      solPre.textContent = practiceState.current.solution;
      solEl.classList.remove("hidden");
      statusEl.textContent =
        "Solution shown. Click “Next problem” when you are ready.";
      statusEl.className = "mt-2 text-sm text-sky-400/95";
      practiceState.done = true;
      setPracticeButtons();
    });

    nextBtn.addEventListener("click", function () {
      loadRandomPractice();
    });

    loadRandomPractice();
  }

  window.splPyodideStatus = function (msg) {
    var pc = $("panel-codespace");
    var pp = $("panel-practice");
    if (pc && !pc.hidden) {
      var out = $("codespace-output");
      if (out) out.textContent = msg || "";
      return;
    }
    if (pp && !pp.hidden) {
      var st = $("practice-status");
      if (st) st.textContent = msg || "";
    }
  };

  initTabs();
  initCodespace();
  initPractice();
})();
