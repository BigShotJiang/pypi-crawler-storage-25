(function () {
  /**
   * Grading: server runs 100 trials — 20 fixed edge-case seeds + 80 random
   * (see spl_practice_judge.py). Stdin problems use user.ask.
   */
  window.SPL_PRACTICE = [
    {
      id: "multiply",
      title: "Multiply",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set each trial (including edge cases like zeros). Print <code class=\"text-emerald-300\">math.multiply(a, b)</code>.",
      starter: "print.number(math.multiply(a, b));",
      solution: "print.number(math.multiply(a, b));",
    },
    {
      id: "add42",
      title: "Add two numbers",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set each trial. Print <code class=\"text-emerald-300\">math.add(a, b)</code>.",
      starter: "print.number(math.add(a, b));",
      solution: "print.number(math.add(a, b));",
    },
    {
      id: "loop123",
      title: "Count to three",
      prompt:
        "Use <code class=\"text-emerald-300\">test.forLoop</code> from 1 to 3 and print <code class=\"text-sky-300\">i</code> each time (lines <code class=\"text-slate-400\">1.0</code> … <code class=\"text-slate-400\">3.0</code>).",
      starter: "test.forLoop(1, 3, i):\nend;",
      solution:
        "test.forLoop(1, 3, i):\n    print.number(i);\nend;",
    },
    {
      id: "concat-ab",
      title: "Concatenate",
      prompt:
        "Each trial sets <code class=\"text-sky-300\">c1</code> and <code class=\"text-sky-300\">c2</code> (single letters). Print their concatenation with <code class=\"text-emerald-300\">string.concatenate</code>.",
      starter: "",
      solution: "print.string(string.concatenate(c1, c2));",
    },
    {
      id: "fn-double",
      title: "Double function",
      prompt:
        "Define <code class=\"text-sky-300\">double(x)</code> that doubles its argument. The grader appends <code class=\"text-emerald-300\">print.number(function.double(…))</code> with a random argument (including 0 and negatives).",
      starter: "functionDefine.double(x):\nend;",
      solution:
        "functionDefine.double(x):\n    return.number(math.multiply(x, 2));\nend;",
    },
    {
      id: "mod",
      title: "Modulo",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set each trial. Print <code class=\"text-emerald-300\">math.mod(a, b)</code> (includes <code class=\"text-slate-400\">a = 0</code> cases).",
      starter: "",
      solution: "print.number(math.mod(a, b));",
    },
    {
      id: "subtract99",
      title: "Subtract",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set with <code class=\"text-slate-400\">a ≥ b</code>. Print <code class=\"text-emerald-300\">math.subtract(a, b)</code>.",
      starter: "",
      solution: "print.number(math.subtract(a, b));",
    },
    {
      id: "square36",
      title: "Square",
      prompt:
        "Variable <code class=\"text-sky-300\">n</code> is set each trial. Print <code class=\"text-emerald-300\">n * n</code> via <code class=\"text-emerald-300\">math.multiply(n, n)</code>.",
      starter: "",
      solution: "print.number(math.multiply(n, n));",
    },
    {
      id: "list-first",
      title: "First in list",
      prompt:
        "Each trial builds <code class=\"text-sky-300\">nums</code> with three integers (including zeros). Print the first element with <code class=\"text-emerald-300\">list.get</code>.",
      starter: "",
      solution: "print.number(list.get(0, nums));",
    },
    {
      id: "uppercase",
      title: "Uppercase",
      prompt:
        "Variable <code class=\"text-sky-300\">s</code> holds a string each trial. Print <code class=\"text-emerald-300\">string.uppercase(s)</code>.",
      starter: "",
      solution: "print.string(string.uppercase(s));",
    },
    {
      id: "strlen",
      title: "String length",
      prompt:
        "Variable <code class=\"text-sky-300\">s</code> is set each trial (including empty). Print <code class=\"text-emerald-300\">string.length(s)</code>.",
      starter: "",
      solution: "print.number(string.length(s));",
    },
    {
      id: "reverse",
      title: "Reverse string",
      prompt:
        "Variable <code class=\"text-sky-300\">s</code> is set each trial. Print <code class=\"text-emerald-300\">string.reverse(s)</code>.",
      starter: "",
      solution: "print.string(string.reverse(s));",
    },
    {
      id: "is-even",
      title: "Even test",
      prompt:
        "Variable <code class=\"text-sky-300\">n</code> is always an even integer (including 0). If <code class=\"text-emerald-300\">test.isEven(n)</code>, print <code class=\"text-emerald-300\">even</code>.",
      starter: "",
      solution:
        "test.ifTrue(test.isEven(n)):\n    print.string(\"even\");\nend;",
    },
    {
      id: "divide",
      title: "Integer division",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set so <code class=\"text-emerald-300\">a</code> divides evenly by <code class=\"text-emerald-300\">b</code> (including <code class=\"text-slate-400\">a = 0</code>). Print <code class=\"text-emerald-300\">math.div(a, b)</code>.",
      starter: "",
      solution: "print.number(math.div(a, b));",
    },
    {
      id: "floor",
      title: "Floor",
      prompt:
        "Variable <code class=\"text-sky-300\">x</code> holds a fractional number each trial (including negatives). Print <code class=\"text-emerald-300\">math.floor(x)</code>.",
      starter: "",
      solution: "print.number(math.floor(x));",
    },
    {
      id: "ask-double",
      title: "Double stdin",
      prompt:
        "Read one integer with <code class=\"text-emerald-300\">string.convertInt(user.ask(\"\"))</code> into <code class=\"text-sky-300\">n</code>, then print <code class=\"text-emerald-300\">n * 2</code> (use <code class=\"text-emerald-300\">math.multiply(n, 2)</code>). Stdin supplies one line per run (large values and negatives included).",
      starter:
        'n.setVar(string.convertInt(user.ask("")));\nprint.number(math.multiply(n, 2));',
      solution:
        'n.setVar(string.convertInt(user.ask("")));\nprint.number(math.multiply(n, 2));',
    },
    {
      id: "ask-sum2",
      title: "Sum two inputs",
      prompt:
        "Read two integers from two <code class=\"text-emerald-300\">user.ask</code> calls (use <code class=\"text-emerald-300\">string.convertInt</code>), store in <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code>, print <code class=\"text-emerald-300\">math.add(a, b)</code>. Input is two lines per trial.",
      starter:
        'a.setVar(string.convertInt(user.ask("")));\n' +
        'b.setVar(string.convertInt(user.ask("")));\n' +
        "print.number(math.add(a, b));",
      solution:
        'a.setVar(string.convertInt(user.ask("")));\n' +
        'b.setVar(string.convertInt(user.ask("")));\n' +
        "print.number(math.add(a, b));",
    },
    {
      id: "ask-max",
      title: "Max of two inputs",
      prompt:
        "Read two integers from stdin (two lines). Print the larger using <code class=\"text-emerald-300\">test.ifTrue</code> / <code class=\"text-emerald-300\">test.else</code> and <code class=\"text-emerald-300\">test.isGreater</code> (ties can print either value; reference prints <code class=\"text-sky-300\">b</code> when equal).",
      starter:
        'a.setVar(string.convertInt(user.ask("")));\n' +
        'b.setVar(string.convertInt(user.ask("")));\n' +
        "test.ifTrue(test.isGreater(a, b)):\n    print.number(a);\nend;\n" +
        "test.else():\n    print.number(b);\nend;",
      solution:
        'a.setVar(string.convertInt(user.ask("")));\n' +
        'b.setVar(string.convertInt(user.ask("")));\n' +
        "test.ifTrue(test.isGreater(a, b)):\n    print.number(a);\nend;\n" +
        "test.else():\n    print.number(b);\nend;",
    },
    {
      id: "ask-hello",
      title: "Hello name (stdin)",
      prompt:
        "Read one line with <code class=\"text-emerald-300\">user.ask(\"\")</code> into <code class=\"text-sky-300\">name</code>, then print <code class=\"text-emerald-300\">string.concatenate(\"Hello, \", name)</code>. Empty lines are tested.",
      starter:
        'name.setVar(user.ask(""));\nprint.string(string.concatenate("Hello, ", name));',
      solution:
        'name.setVar(user.ask(""));\nprint.string(string.concatenate("Hello, ", name));',
    },
    {
      id: "ask-square",
      title: "Square stdin",
      prompt:
        "Read one integer from stdin, then print its square with <code class=\"text-emerald-300\">math.multiply(n, n)</code>.",
      starter:
        'n.setVar(string.convertInt(user.ask("")));\nprint.number(math.multiply(n, n));',
      solution:
        'n.setVar(string.convertInt(user.ask("")));\nprint.number(math.multiply(n, n));',
    },
    {
      id: "gcd-euclid",
      title: "Euclidean GCD",
      prompt:
        "Classic algorithm: <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set each trial. Repeatedly replace <code class=\"text-emerald-300\">(a, b)</code> with <code class=\"text-emerald-300\">(b, a mod b)</code> while <code class=\"text-emerald-300\">b &gt; 0</code>, then print <code class=\"text-emerald-300\">a</code>. Use <code class=\"text-emerald-300\">test.while</code> and <code class=\"text-emerald-300\">math.mod</code>.",
      starter:
        "test.while(test.isGreater(b, 0)):\nend;\nprint.number(a);",
      solution:
        "test.while(test.isGreater(b, 0)):\n    r.setVar(math.mod(a, b));\n    a.setVar(b);\n    b.setVar(r);\nend;\nprint.number(a);",
    },
    {
      id: "sum-range",
      title: "Sum 1…n",
      prompt:
        "Variable <code class=\"text-sky-300\">n</code> is set each trial (<code class=\"text-slate-400\">n ≥ 1</code>). Compute <code class=\"text-emerald-300\">1 + 2 + … + n</code> with <code class=\"text-emerald-300\">test.forLoop</code> and an accumulator.",
      starter:
        "sumv.setVar(0);\ntest.forLoop(1, n, i):\nend;\nprint.number(sumv);",
      solution:
        "sumv.setVar(0);\ntest.forLoop(1, n, i):\n    sumv.setVar(math.add(sumv, i));\nend;\nprint.number(sumv);",
    },
    {
      id: "factorial",
      title: "Factorial",
      prompt:
        "Variable <code class=\"text-sky-300\">n</code> is set (<code class=\"text-slate-400\">0 ≤ n ≤ 10</code>). Print <code class=\"text-emerald-300\">n!</code>: product <code class=\"text-emerald-300\">1 × 2 × … × n</code> (with <code class=\"text-emerald-300\">0! = 1</code>).",
      starter:
        "acc.setVar(1);\ntest.forLoop(1, n, i):\nend;\nprint.number(acc);",
      solution:
        "acc.setVar(1);\ntest.forLoop(1, n, i):\n    acc.setVar(math.multiply(acc, i));\nend;\nprint.number(acc);",
    },
    {
      id: "fibonacci",
      title: "Fibonacci number",
      prompt:
        "Variable <code class=\"text-sky-300\">n</code> is set (<code class=\"text-slate-400\">0 ≤ n ≤ 20</code>). Print <code class=\"text-emerald-300\">F(n)</code> with <code class=\"text-emerald-300\">F(0)=0</code>, <code class=\"text-emerald-300\">F(1)=1</code>, <code class=\"text-emerald-300\">F(n)=F(n−1)+F(n−2)</code>. Handle <code class=\"text-emerald-300\">n=0</code> and <code class=\"text-emerald-300\">n=1</code> separately; for <code class=\"text-emerald-300\">n ≥ 2</code> iterate from <code class=\"text-emerald-300\">2</code> to <code class=\"text-emerald-300\">n</code>.",
      starter:
        "test.ifTrue(test.isEqual(n, 0)):\n    print.number(0);\nend;\n",
      solution:
        "test.ifTrue(test.isEqual(n, 0)):\n    print.number(0);\nend;\ntest.else():\n    test.ifTrue(test.isEqual(n, 1)):\n        print.number(1);\n    end;\n    test.else():\n        a.setVar(0); b.setVar(1);\n        test.forLoop(2, n, i):\n            c.setVar(math.add(a, b));\n            a.setVar(b);\n            b.setVar(c);\n        end;\n        print.number(b);\n    end;\nend;",
    },
    {
      id: "digit-sum",
      title: "Sum of decimal digits",
      prompt:
        "Variable <code class=\"text-sky-300\">n</code> is a non‑negative integer. Repeatedly add <code class=\"text-emerald-300\">n mod 10</code> and set <code class=\"text-emerald-300\">n ← floor(n / 10)</code> until <code class=\"text-emerald-300\">n</code> is 0. Print the digit sum.",
      starter:
        "sumd.setVar(0);\ntest.while(test.isGreater(n, 0)):\nend;\nprint.number(sumd);",
      solution:
        "sumd.setVar(0);\ntest.while(test.isGreater(n, 0)):\n    sumd.setVar(math.add(sumd, math.mod(n, 10)));\n    n.setVar(math.floor(math.div(n, 10)));\nend;\nprint.number(sumd);",
    },
    {
      id: "int-power",
      title: "Integer power",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set (<code class=\"text-emerald-300\">b</code> is a non‑negative exponent). Print <code class=\"text-emerald-300\">a<sup>b</sup></code> by multiplying <code class=\"text-emerald-300\">b</code> times (use <code class=\"text-emerald-300\">1</code> when <code class=\"text-emerald-300\">b=0</code>).",
      starter:
        "acc.setVar(1);\ntest.forLoop(1, b, i):\nend;\nprint.number(acc);",
      solution:
        "acc.setVar(1);\ntest.forLoop(1, b, i):\n    acc.setVar(math.multiply(acc, a));\nend;\nprint.number(acc);",
    },
    {
      id: "abs-diff",
      title: "Absolute difference",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> are set. Print <code class=\"text-emerald-300\">|a − b|</code> using <code class=\"text-emerald-300\">test.ifTrue</code> / <code class=\"text-emerald-300\">test.else</code> and <code class=\"text-emerald-300\">math.subtract</code> (no <code class=\"text-emerald-300\">abs</code> builtin).",
      starter: "",
      solution:
        "test.ifTrue(test.isGreater(a, b)):\n    print.number(math.subtract(a, b));\nend;\ntest.else():\n    print.number(math.subtract(b, a));\nend;",
    },
    {
      id: "min-two",
      title: "Minimum of two",
      prompt:
        "Print the smaller of <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code> using only comparisons and branches.",
      starter: "",
      solution:
        "test.ifTrue(test.isGreater(a, b)):\n    print.number(b);\nend;\ntest.else():\n    print.number(a);\nend;",
    },
    {
      id: "max-two",
      title: "Maximum of two",
      prompt:
        "Print the larger of <code class=\"text-sky-300\">a</code> and <code class=\"text-sky-300\">b</code>.",
      starter: "",
      solution:
        "test.ifTrue(test.isGreater(a, b)):\n    print.number(a);\nend;\ntest.else():\n    print.number(b);\nend;",
    },
    {
      id: "parity",
      title: "Odd or even",
      prompt:
        "Variable <code class=\"text-sky-300\">n</code> is any integer. Print the string <code class=\"text-emerald-300\">even</code> or <code class=\"text-emerald-300\">odd</code> using <code class=\"text-emerald-300\">test.isEven</code>.",
      starter: "",
      solution:
        "test.ifTrue(test.isEven(n)):\n    print.string(\"even\");\nend;\ntest.else():\n    print.string(\"odd\");\nend;",
    },
    {
      id: "list-search",
      title: "Find in list",
      prompt:
        "A three‑element list <code class=\"text-sky-300\">nums</code> and a target <code class=\"text-sky-300\">t</code> are set. Print <code class=\"text-emerald-300\">1</code> if <code class=\"text-emerald-300\">t</code> equals any element, else <code class=\"text-emerald-300\">0</code>.",
      starter:
        "found.setVar(0);\nprint.number(found);",
      solution:
        "found.setVar(0);\ntest.ifTrue(test.isEqual(list.get(0, nums), t)):\n    found.setVar(1);\nend;\ntest.else():\n    test.ifTrue(test.isEqual(list.get(1, nums), t)):\n        found.setVar(1);\n    end;\n    test.else():\n        test.ifTrue(test.isEqual(list.get(2, nums), t)):\n            found.setVar(1);\n        end;\n    end;\nend;\nprint.number(found);",
    },
    {
      id: "sum-list",
      title: "Sum of three list elements",
      prompt:
        "List <code class=\"text-sky-300\">nums</code> has length 3. Print the sum of all elements.",
      starter: "",
      solution:
        "print.number(math.add(math.add(list.get(0, nums), list.get(1, nums)), list.get(2, nums)));",
    },
    {
      id: "product-list",
      title: "Product of three list elements",
      prompt:
        "Print the product of the three integers in <code class=\"text-sky-300\">nums</code>.",
      starter: "",
      solution:
        "print.number(math.multiply(math.multiply(list.get(0, nums), list.get(1, nums)), list.get(2, nums)));",
    },
    {
      id: "mod-add",
      title: "Sum then modulo",
      prompt:
        "Variables <code class=\"text-sky-300\">a</code>, <code class=\"text-sky-300\">b</code>, and positive <code class=\"text-sky-300\">m</code> are set. Print <code class=\"text-emerald-300\">(a + b) mod m</code>. Use a temporary variable for <code class=\"text-emerald-300\">a + b</code> (nested calls in <code class=\"text-emerald-300\">math.mod</code> are not accepted by the parser).",
      starter:
        "s.setVar(math.add(a, b));\nprint.number(math.mod(s, m));",
      solution:
        "s.setVar(math.add(a, b));\nprint.number(math.mod(s, m));",
    },
    {
      id: "count-lines",
      title: "Counting lines",
      prompt:
        "Variable <code class=\"text-sky-300\">n</code> is set (<code class=\"text-slate-400\">n ≥ 1</code>). Print <code class=\"text-emerald-300\">1</code>, then <code class=\"text-emerald-300\">2</code>, … up to <code class=\"text-emerald-300\">n</code>, one number per line (same pattern as the loop‑123 exercise).",
      starter:
        "test.forLoop(1, n, i):\nend;",
      solution:
        "test.forLoop(1, n, i):\n    print.number(i);\nend;",
    },
  ];
})();
