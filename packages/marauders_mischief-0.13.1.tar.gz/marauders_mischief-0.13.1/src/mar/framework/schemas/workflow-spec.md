# mar-workflow — Development Session Framework (v13.1)

Custom AI-native development workflow for this project. Two-level decomposition (session → phases → stages), contract-shaped plans, fresh-context review + functional tester at Stage 5, 3-way iterate-able gates, plan.md as single source of truth.

**v3 addition (carried)**: Stage 2a's research step expands into multi-role meta-research. For L/XL sessions, the kind axis (`greenfield`, `new-feature`, `refactor`, `bug`, `infra-ops`) selects a roster of 2–6 role-research agents that run in parallel before the meta-plan is drafted. A mid-research briefing gate surfaces tensions and open questions; iterate triggers targeted round-2 dispatches; final synthesis feeds the meta-plan flow.

**v4 addition (carried)**: Stage 2a's plan step expands into a strategist → author → skeptic flow. The strategist picks a decomposition strategy from a named catalogue (tracer-bullet / risk-first / value-first / user-journey / integration-by-integration / spike-then-build) and surfaces alternatives. The author writes the plan against that strategy. The skeptic adversarially reviews in fresh context with a verdict + categorized comments; up to 2 internal refine rounds before the user-facing meta-plan gate fires. The gate offers 4 options: approve, iterate (in place), revise (back up to meta-research with a note), redirect (full reset with a new direction). `/mar:replan` is deprecated; `/mar:redirect` replaces it.

**v5 addition (carried)**: Stage 1 (phase research) gets a 5-section structured output schema and a hypothesis-driven prompt — `research-agent` surfaces options, distills external API docs, finds reference patterns, carries inherited constraints, names open unknowns. The line between research and planning is enforced: research surfaces, phase-plan-agent decides. For L/XL phases or `deep` guidance, an optional `phase-research-skeptic-agent` runs a 1-round adversarial review. The phase research gate gets a 4-option menu (approve / iterate / revise meta-plan / reject) and fires in more modes — `normal` mode now gates L/XL phase research, not just `interactive`. `/mar:revise` extends to be valid at the phase research gate, routing to meta-plan iteration.

**v7 addition (carried)**: Stage 3 (Execute) gets step-decomposition. The phase plan declares N build steps (sub-todos) in a new `## Build steps` section, populated by `phase-plan-author-agent` in alignment with the chosen Implementation strategy. Each step is dispatched to a fresh `execute-step-agent` (renamed from `execute-agent`) — bounded context per step, lossless state passed forward via structured `step-N-summary.md` files. `/mar:ship` orchestrates: dispatch → optional `Verify` command check → retry on fail (cap 3) → advance. The motivating problem is long-running execute agents accumulating context until working state degrades; per-step fresh dispatch keeps every agent's context small. New always-on safeguard: `execute-step-wall hit` (a single step's internal iteration cap exhausted). `phase-plan-skeptic-agent` gains 6 checks on Build steps quality (populated, sized, ordered to strategy, scope ⊆ plan §Scope, output state concrete, AI strategies declare Verify). No new commands, no gate changes — only the engine of execute changes.

**v13.1 patch**: `/mar:ship` now creates the phase's feature branch automatically. Previously, `create-phase-pr.sh` (v12) correctly refused to open a PR from the default branch — but nothing in the orchestrator created the phase branch first, so on a fresh first-run the user would hit a guaranteed failure at Stage 2.2. v13.1 adds a branch precondition to Step 1: if HEAD is on the default branch (`main`/`master`), fetch + pull + `git checkout -b phase/<current_phase>`. If HEAD is already on the expected `phase/<id>` (retry case), continue. If HEAD is on some unrelated branch (commonly: a prior merged phase branch in L/XL sessions), refuse with a recovery hint. Step 5 (between-phase handling) is extended for `streamlined`/`autonomous` modes to checkout the default branch + pull before invoking `/mar:plan` for the next phase, so the next `/mar:ship` lands cleanly on case (b) and creates the new phase branch. No new agents, no new scripts; one orchestrator precondition + one transition step.

**v13 addition**: `retrospect-agent` is redesigned around a clear separation of audiences. Previously, retrospect appended findings to a framework-shared `ops/workflow/test-findings.md` file — but that file was the maintainer's personal scratchpad shipped into every user's repo. v13 removes that artifact entirely. Retrospect now writes a structured **per-session** `sessions/archive/<id>/retrospect.md` with three sections (`## Wins`, `## Session findings`, `## Framework findings`) and emits a clearly-delimited **"ready to file" block in chat output** containing framework-level findings formatted as GitHub Issue titles + bodies, targeted at `sindreespeland/marauders-mischief`. The maintainer copies the entries they want into real issues; external users can ignore the block. **No automation**, no telemetry, no phone-home — manual paste keeps the maintainer in the triage loop. Severity taxonomy is action-oriented: `must-fix-next-version` / `worth-fixing` / `monitor` / `idea` (replaces the borrowed-from-review `blocker/should-fix/nit/idea`). Findings carry structured fields: theme (which stage or cross-cutting concern), autonomy_impact (`autonomous-critical` / `autonomous-relevant` / `interactive-only-ux` / `not-mode-dependent`), cost estimate (`prompt-tweak` / `orchestrator-edit` / `new-agent` / `worktree-redesign` / `spec-only`), recurrence (`first-seen` / `seen-2x` / `seen-3x+`). Recurrence promotes severity automatically. New `## Wins` section captures what proved load-bearing this session — so future hardening doesn't accidentally undo it. Required-reading list refreshed for v7-v12 artifacts (build-steps, test-plan, test-results, simplify-report, deviations, pr-body). v12+ sessions also audit PR state (`gh pr view --json reviews,comments,statusCheckRollup,mergeCommit`) since retrospect runs post-archive — reading the PR doesn't affect the session. No new agents, no new commands, no gate changes.

**v12 addition**: PR-native flow lands. Stage 2.2 of `/mar:ship` now opens a draft PR via `create-phase-pr.sh` after build steps complete and before the test stage runs — every phase = one PR. The PR body is a derived view of `plan.md` (generated by `derive-pr-body.py`, regenerated on every `/mar:iterate plan` and synced via `gh pr edit`). Stage 5's `review-agent` and `tester-agent` flip from `mode: local` to `mode: pr`: they write to session `.md` files as the **canonical source of truth** AND post a human-visible mirror to the PR (inline `gh pr review` for review-agent, summary `gh pr comment` for tester-agent). Comments are one-way — agents do not read PR comments back; refine reads only from session sources (`review-comments.md`, `tester-report.md`, optional user-created `user-comments.md`). All four refine loops (build, verify, Stage 5 review, Stage 5 tester) push the branch to origin only on clean round advance (not on intermediate checkpoint commits) to keep CI noise down. The squash merge moves to `/mar:approve integrate`: orchestrator runs `gh pr merge --squash` with integrate-agent's composed commit message, after pre-checking `mergeStateStatus == CLEAN`. `integrate-agent` no longer pushes or creates PRs — it composes the commit story only. Autonomous mode auto-runs the equivalent of `/mar:approve integrate` at the integrate stage; the previous `integrate.md` autonomous flow that created the PR is removed (PR was already opened at Stage 2.2, by Stage 8 it just needs merging). New always-on safeguard: `gh-pr-failure hit` fires on any non-zero `gh` PR command (`pr create`, `pr edit`, `pr review`, `pr comment`, `pr merge`) or related `git push`. Two new scripts: `create-phase-pr.sh` and `derive-pr-body.py`. One new template: `pr-body.md.template`. No new agents. The previous Step-1/Step-2 split for `gh pr create` (deferred since v0.4) is now folded into v12 as the live path; legacy `mode: local` for review/tester remains for sessions that lack a `pr:` frontmatter (pre-v12 or scratch-service).

**v11 addition**: `verify-agent` gets route-based failure classification, mechanical pre-checks, and structured evidence. Verify still does plan-vs-reality adherence and still returns a binary `pass | fail` verdict — what changes is what happens on `fail`. Previously every verify-fail bounced to refine-agent; under v10's protected surfaces, some failures (a declared test that was never built, a scope violation, an unchecked manual step) can't actually be fixed by refine and would burn a cycle escalating via `replan-needed`. v11 has verify classify each failure with a `route`: `refine` (missing production code → existing refine path), `replan` (scope drift, declared test not built, deviation scope-creep, plan unverifiable → escalate immediately), or `user` (unresolved `[QUESTION]` in autonomous mode, unchecked manual step → escalate for human action). Orchestrator dispatches by route: pure-refine sets bounce to refine (v10 wrapper applies); any non-refine route fires the new `verify-escalation hit` safeguard instead. Verify also runs 5 mechanical pre-checks via Bash before reasoning (diff-vs-scope, `[QUESTION]` count, manual-step boxes, deviations triage, plan-quality preconditions) — any pre-check fail is automatically a verify-fail with the route already determined. Evidence format is now structured (`git-diff:<path>:<line-range>` | `test-report.md#<kind>:<test_id>` | `simplify-report.md#<section>` | `manual-check:<who>:<when>`) — prose-only "looks good" claims are not allowed. Effort bumped `medium` → `high`. No new agents, no new commands, no gate changes.

**v10 addition**: `refine-agent` hardens against silent contract weakening and silent codebase degradation. Two changes:

1. **Protected surfaces.** Refine cannot write to `tests/**`, fixture data, snapshot baselines, or `evals/**`. The PreToolUse scope hook (`check-scope.py`) enforces the block during refine dispatches, gated by a per-session `.refine-active` flag file the orchestrator touches before dispatching refine and removes after. If a fix requires changing a protected surface, refine returns `replan-needed` with a citation (Test matrix row, runner output classification, or scenario name) — the user (or, in autonomous mode, the new safeguard) decides whether the contract should change. The previous "(also test files if test asserts the wrong thing)" carve-out is removed. Execute-step's initial test writes are unaffected because the flag isn't set during execute.
2. **Checkpoint + revert on regression.** The orchestrator makes a checkpoint commit before every refine dispatch (build loop, verify loop, Stage 5 review loop, Stage 5 tester loop). After the post-refine consumer re-dispatch, the orchestrator compares the new failure set to the prior one. If a failure appears that wasn't in the prior round → regression → `git reset --hard <checkpoint>~1` → fires the new always-on safeguard `refine-regression-wall hit`. Failure-set identifiers per loop: build uses `(kind, test_id)` tuples; verify uses fail-item names; review uses `[blocker]+[must-fix]` count; tester uses failing-scenario names.

New always-on safeguards: `refine-regression-wall hit` (regression detected) and `refine-protected surface write attempt` (hook denied a contract-surface write during refine). Both fire in every autonomy mode including `autonomous`.

No new agents, no new commands, no gate changes. Edits land in `refine-agent.md`, `check-scope.py`, `/mar:ship`.

**v9 addition**: Stage 4.5 (Simplify) gets the author + skeptic pattern, dynamic conventions, targeted re-test, and revert-on-regression. `simplify-agent` is renamed to `simplify-author-agent`. Conventions are no longer baked into the agent's prompt — they're extracted at runtime from root + nested `CLAUDE.md`, `.brain/STACK.md`, and the plan's `## Approach` `[DECIDED]` marks. A new `## Code conventions` section ships in `CLAUDE.md.j2` carrying the previous default rule set; users edit/extend/delete in place. A new `simplify-skeptic-agent` (xhigh, fresh context) reviews the author's diff against the protected-surface list, the cited conventions (must actually appear in the cited source), the deletion-safety check (live callers grepped), and the `re_test_kinds` correctness. 1 internal refine round; if round 2 still has blockers, the orchestrator reverts the simplify checkpoint commit and advances to verify — refine-agent is **not** dispatched on simplify failures because simplify is a polish pass, not a contract gate. The author returns a structured `re_test_kinds` list based on touched paths (code → `[unit, agent-flow]`, prompts → `[eval, agent-flow]`, frontend → `[browser]`, perf hot path → `[perf, unit]`, comments-only → `[]`); `/mar:ship` dispatches only those runners in a targeted wave. Same revert-and-advance behavior if any kind regresses. The protected-surface list is broadened beyond `tests/**` to include `prompts/**`, `evals/**`, `*.jsonl`/`*.csv` fixtures, snapshot baselines, benchmark scripts, and any file referenced in plan `## Tester scenarios`.

**v8 addition (carried)**: Stage 4 (Test) gets multi-kind decomposition. The single `test-agent` is replaced by a **strategist + per-kind specialist runners** flow. `test-strategist-agent` (dual-mode: `plan` / `aggregate`) first reads plan + build-steps and writes `test-plan.md` declaring which test kinds apply (`unit`, `eval`, `agent-flow`, `browser`, `perf`). `/mar:ship` then dispatches the applicable per-kind runners — `test-runner-unit`, `test-runner-eval`, `test-runner-agent-flow`, `test-runner-browser`, `test-runner-perf` — **in parallel** (wave-1 dispatch, one Task call per runner in a single message). Each runner has its own operational knowledge embedded in its prompt (no Skills or plugins) — eval handles promptfoo/deepeval/inspect-ai/judge models, browser manages dev-server lifecycle with trap-on-EXIT teardown, perf reports distributions not single numbers, etc. Each runner writes its own per-kind report under `phases/<id>/test-results/<kind>-report.md` with a `## Fix targets` section. Strategist then dispatches in `aggregate` mode to write a unified `test-report.md` carrying the binary verdict. `refine-agent` becomes **target-aware**: it reads the strategist's per-kind fix-target globs (eval → prompts first, browser → frontend first, etc.) before patching, so a prompt-quality failure doesn't get "fixed" by editing production code. The motivating problem is the v7 `test-agent` had no plan for non-traditional test kinds (UI, agentic flows, evals), and refine-agent had no target awareness when failures spanned code vs. prompts. The old `test-agent` is removed. No new commands, no gate changes — only the engine of test changes.

**v6 addition (carried)**: Stage 2c (phase planning) gets the strategist-author-skeptic pattern at per-phase grain. `phase-plan-agent` is renamed to `phase-plan-author-agent` (3 modes: draft/refine/iterate) and consumes the v0.5 5-section research properly — picks libraries from research's landscape, uses external API surface to inform contracts, adapts research's reference patterns, carries inherited constraints, passes open unknowns through as `[QUESTION]` marks. A new `phase-plan-skeptic-agent` runs adversarial fresh-context review with verdict + categorized comments; up to 2 internal refine rounds before the user-facing phase plan gate fires. The implementation strategy catalogue gains 3 AI-native entries (`eval-first`, `prompt-first`, `tool-by-tool`); plan.md.template gains 3 optional sections for AI/agentic phases (LLM/Model decisions, Eval matrix, Prompt design). The phase plan gate gets a 5-option menu (approve / iterate / revise research / revise meta-plan / reject). `/mar:revise` extends further: at phase plan gate, target can be `research` (back up to phase research) or `meta-plan` (back up further).

**Rollout state**: Step 1 (agent-only execution against the local repo) is live. **Step 2 PR-native flow is partly live as of v12**: `gh pr create --draft` at Stage 2.2, review-agent / tester-agent posting comments via `gh pr review` and `gh pr comment`, hard-block on `gh` failures via `gh-pr-failure hit`, and `gh pr merge --squash` at `/mar:approve integrate`. Worktree-per-phase remains deferred — phases share the working tree and run sequentially.

---

## 1. Quick start

```
/mar:session-start "<one-line goal>"            # interactive picker — size, kind, guidance, autonomy
                                                 # accepts: --kind <kind> and --roles <comma-list> in $ARGUMENTS
/mar:plan                                        # dispatches the current sub-stage; pauses at the current gate
                                                 # for L/XL: meta-research → meta-plan → issue-scaffolding → phase-plan
/mar:approve meta-research | /mar:iterate meta-research "<note>" | /mar:reject meta-research   (L/XL only)
/mar:approve plan | /mar:iterate plan "<note>" | /mar:reject plan
/mar:ship                                        # execute → test → refine → simplify → re-test → verify → review + tester
/mar:integrate                                   # commit story + .brain/ writeback proposals
/mar:approve integrate                           # apply writebacks + commit
/mar:session-archive
```

The user touches the keyboard between gates. `autonomous` mode auto-passes every gate; only safeguards interrupt.

---

## 2. Core concepts

Three nouns:

- **Session** — one initiative end-to-end. E.g. "add voice transcription to MVP." Lives in `sessions/active/<id>/` until archived.
- **Phase** — a chunk of a session, with its own deep research → plan → execute → test → refine → simplify → verify → review/tester cycle. L/XL sessions have multiple phases; S/M sessions collapse to one implicit phase.
- **Stage** — a step within a phase (research, plan, execute, test, refine, simplify, verify, review, tester, integrate). Each stage runs as a fresh-context sub-agent dispatched via the Task tool.

**plan.md is canonical.** The phase plan is the single source of truth for the phase. Issue body and PR body are *derived views* — never hand-edited. Any plan revision triggers regeneration of derived views.

---

## 3. Size-adaptive flow

| Size | Typical scope | Meta layer | Phases | Stages per phase |
|---|---|---|---|---|
| **S**  | Bug fix or isolated refactor (~½ day) | — | 1 | plan → execute → test → verify → review + tester |
| **M**  | Feature in one service (1–2 days) | — | 1 | full cycle |
| **L**  | Cross-cutting feature or new subsystem (2–5 days) | yes | 2–4 | full cycle per phase |
| **XL** | New service or major rewrite (>1 week) | yes | 4+ | full cycle per phase + between-phase compaction |

For trivially small edits (typo, config tweak, <30 min), don't open a session — edit directly and commit. The framework would add more cost than value.

---

## 4. Stage 2 split (planning)

For L/XL sessions, the planning pipeline runs **meta-research** before Stage 2a, then the three Stage 2 sub-stages, each with its own gate:

- **Meta-research** (L/XL only, v3). Multi-role research: a roster of agents (selected by the session's `kind`) runs in parallel, skeptic-agent reviews after, orchestrator-agent writes `briefing-N.md`. Mid-research gate fires; user can approve, iterate (round N+1), or reject. On approve, orchestrator writes `synthesis.md`. Gate: 3-way.
- **2a — Meta-plan** (L/XL only, v4). Strategist picks a decomposition strategy from the catalogue and writes `meta-plan-strategy.md` with alternatives. Author writes `meta-plan.md` against the strategy. Skeptic reviews in fresh context (verdict + categorized comments). Up to 2 internal refine rounds. User-facing gate offers 4 options (approve / iterate / revise / redirect — no `reject` line item; revise covers backing-up-with-direction, reject is still callable but not advertised here). No issues created.
- **2b — Issue scaffolding**. Generate proposed issue bodies from meta-plan. Step 1: written to `proposed-issue-bodies.md` for review. Step 2: `gh issue create` per phase, with hard-block on failure. Gate: 3-way.
- **2c — Phase plan** (per-phase, just-in-time). Phase-plan-agent writes `plan.md`; orchestrator runs `derive-issue-body.py` to regenerate `issue-body.md`. Hard-block if derivation fails. Gate: 3-way.

`/mar:plan` advances whichever sub-stage is current.

S/M sessions skip meta-research, 2a, and 2b; only 2c runs.

---

## 5. 3-way gates

Every gate accepts approve / reject; most also accept iterate:

- **approve** — advance to next stage.
- **iterate** — apply free-text direction *without* losing position. Re-runs the current stage's agent(s) with the direction; for `plan` iterate, also re-derives `issue-body.md`. For `meta-research` iterate, runs a targeted round N+1 only against the roles flagged in the briefing. The plan and the issue must agree before iterate completes.
- **reject** — discard the artifact (renamed `<file>.rejected-<ts>` or for meta-research the whole `meta-research/` dir) and back up to the prior stage.

Gates: `research`, `meta-research` (v3), `meta-plan`, `issue-scaffolding`, `plan`, `integrate`.

`issue-scaffolding` is **not directly iterable** — issue bodies are derived views, so adjustments route through the source: phase-1's body comes from its plan (`/mar:iterate plan`), later phases' stub bodies come from the meta-plan (`/mar:iterate meta-plan`). Approve/reject still apply.

`meta-research` iterate has a soft cap: 2 rounds is the design target, 3 with explicit user override. Round 4+ surfaces a hint suggesting reject (fresh path) or approve (lock current framing).

`meta-plan` (v4) is the only gate with **4 advertised options** instead of the standard 3: `approve` / `iterate` / **`revise`** / **`redirect`**. The `reject` command still works and renames artifacts with `.rejected-<ts>`, but it isn't surfaced in the gate's printed menu — the design philosophy is that by the time a user reaches the meta-plan gate they've invested in framing, and abandonment is not a routine outcome. Use `/mar:redirect` to pivot the session and `/mar:stop` to genuinely abandon.

`meta-plan` has an internal skeptic refine loop (cap: 2 rounds before the user gate fires). If round 2 still verdicts `request-changes`, the **`plan-review-wall hit`** safeguard fires regardless of autonomy mode.

`/mar:iterate` is distinct from `/mar:continue` (re-runs a stage as-is) and `/mar:replan` (full reset).

---

## 6. Autonomy matrix

| Mode | Mid-research gate (v3, meta) | Phase research gate (v5) | Plan gate | Between-phase | Merge | Integrate |
|---|---|---|---|---|---|---|
| `interactive` | gate | gate | gate | ack | user | gate |
| `normal` | gate | gate for L/XL or skeptic-flagged issues | gate | ack | user | gate |
| `streamlined` | auto if 0 tensions / 0 open questions, else gate | auto-pass if skeptic approves (or was skipped); gate if skeptic flagged issues | gate | — auto | — auto | gate |
| `autonomous` | — auto (synthesis must contain 0 `[QUESTION]`s) | — auto (skeptic blocker → `phase-research-wall hit` safeguard) | — auto | — auto | — auto | — auto (no writebacks) |

**Autonomous mode contract.** After `/mar:session-start`, the user provides no further input until the session completes. All approval gates auto-pass. The only thing that interrupts is a stuck-state safeguard firing.

**Always-on safeguards** (every mode, including autonomous):
- manual-step block
- scope violation
- secret-file write
- **refine-protected surface write attempt** (v10) — `check-scope.py` denied a write to a contract surface (tests, fixtures, snapshots, eval data) during a refine dispatch. Refine must return `replan-needed` with citation; if it retries, the safeguard fires.
- **refine-regression-wall hit** (v10) — a refine round introduced a failure not present before refine ran. Orchestrator reverts to the pre-refine checkpoint and surfaces the regressed identifiers + loop name (build / verify / Stage 5 review / Stage 5 tester).
- **verify-escalation hit** (v11) — verify-agent returned failures classified `route: replan` or `route: user`. Orchestrator does NOT dispatch refine; surfaces the escalation with citation so the user (or, in autonomous mode, this safeguard) takes plan-level or human action.
- **gh-pr-failure hit** (v12) — any `gh` PR command returned non-zero: `create-phase-pr.sh` at Stage 2.2, `git push` on clean-round advance, `gh pr edit` (during `/mar:iterate plan`), `gh pr review` / `gh pr comment` (Stage 5 PR-mode posts), `gh pr ready` (before merge), or `gh pr merge` (at `/mar:approve integrate`). Orchestrator surfaces the gh stderr verbatim with a remediation hint where recognizable (auth, PAT scope, merge conflict). Stops.
- **review-wall hit** — review-agent ↔ refine-agent loop hit its 3-round cap
- **tester-fail after cap** — tester-agent ↔ refine-agent loop hit its 2-round cap
- **phase-research-wall hit** (v5) — phase-research-skeptic-agent flagged a `[blocker]` and research-agent's 1-round refine didn't address it convincingly
- **phase-plan-review-wall hit** (v6) — phase-plan-skeptic-agent round 2 still verdicts `request-changes` after author refine
- **execute-step-wall hit** (v7) — a single build step's internal iteration cap (3) was exhausted (verify command kept failing after re-dispatch). Surfaces step index + failed verify output.
- `[QUESTION]` present on `synthesis.md` in autonomous mode (mid-research auto-pass requires zero unresolved questions)
- `[QUESTION]` present on plan in autonomous mode
- **gh failure** (Step 2) — hard block on issue/PR create or edit failure
- `derive-issue-body.py` failure (Step 1)

---

## 7. Stage 5 — review + tester (the big v2 addition)

After pre-PR verify passes, the orchestrator dispatches **two agents in parallel**:

- **review-agent** (Opus 4.7 xhigh, fresh-context) — quality review. Reads diff + plan.md + deviations.md. Posts categorized comments. Every comment carries one of `[blocker]` / `[must-fix]` / `[nit]` / `[idea]`. Verdict: `approve` or `request-changes`.
- **tester-agent** (Opus 4.7 high, fresh-context) — functional / behavior validation. Runs the feature against realistic scenarios from plan §"Tester scenarios" (CLI invocations, library consumers, eval scripts, dev-server smoke). Verdict: `pass` or `fail`.

**Aggregation**:
- Both clear → integrate gate.
- Either flags issues → refine-agent reads new comments and patches; round counter increments after refine checkpoint; re-dispatch review + tester.

**Round caps** (hardcoded): 3 review rounds, 2 tester rounds. Beyond cap → review-wall / tester-fail-cap safeguard fires.

Refine-agent may mark a comment `won't fix — <reason>`; that comment is final unless the user re-flags it.

**Step 1 (current)**: review-agent and tester-agent run in **local-file mode** — output goes to `phases/<id>/review-comments.md` and `phases/<id>/tester-report.md`. No GitHub interaction.

**Step 2 (deferred)**: same agents post via `gh pr review` and `gh pr comment` against the draft PR. User can comment on the PR; refine-agent picks up user comments at next checkpoint.

---

## 8. Plan v2 schema

Sections (full template at `ops/workflow/templates/plan.md.template`):

- **Contract** — public API, inputs/outputs, invariants, idempotency, error semantics
- **Non-functional** — perf / reliability / security / observability
- **Definition of Done** — checklist (template defaults + project `CLAUDE.md` inheritance)
- **Scope** — files in / files out (read by `check-scope.py` PreToolUse hook)
- **Approach** — design decisions only, no pseudo-code; uses `[DECIDED]` / `[ASSUMED]` / `[QUESTION]` marks
- **Test matrix** — every row has a command and a measurable acceptance
- **Tester scenarios** — concrete invocations for tester-agent at Stage 5
- **Success criteria** — each cites a Test matrix row
- **Risks** — with mitigations
- **Manual steps** — declared upfront
- **Size**, **Commit preview**

Approach explicitly forbids pseudo-code. Phase-plan-agent's prompt enforces this.

---

## 9. Agent roster

All agents are **Opus 4.7**. Thinking spectrum: `medium / high / xhigh / max`. No Sonnet, no `low`.

| Agent | Effort | Role |
|---|---|---|
| research-agent | high | phase-level research (v5): hypothesis-driven, 5-section structured output (library landscape / external API surface / reference patterns / inherited constraints / open unknowns). Surfaces options; does not decide. |
| **phase-research-skeptic-agent** | **xhigh** | optional adversarial review of phase research; verdict + categorized comments (v5) |
| **phase-plan-author-agent** | **xhigh** | writes phase plan against the v0.5 research; supports `draft` / `refine` / `iterate` modes; picks implementation strategy from 10-entry catalogue (7 traditional + 3 AI-native) (v6 — renamed from `phase-plan-agent`) |
| **phase-plan-skeptic-agent** | **xhigh** | adversarial fresh-context review of phase plan; verdict + `[blocker]`/`[must-fix]`/`[nit]` comments; 5 conditional AI-aware checks (v6) |
| **product-research-agent** | high | meta-research role: JTBD framing (v3) |
| **domain-research-agent** | high | meta-research role: codebase surfaces (extension) or stack proposal (greenfield) (v3) |
| **prior-art-research-agent** | high | meta-research role: 2–3 reference patterns from outside the repo (v3) |
| **ux-research-agent** | high | meta-research role: interaction shape — surface, primary flows, affordances (v3) |
| **ops-research-agent** | high | meta-research role: deploy / observability / on-call footprint (v3) |
| **skeptic-research-agent** | high | meta-research role: 3 failure modes + top assumptions; runs after the parallel wave (v3) |
| **meta-research-orchestrator-agent** | **xhigh** | reads role outputs → writes `briefing-N.md` / `synthesis.md` (v3) |
| **meta-plan-strategist-agent** | high | picks a decomposition strategy from the catalogue, writes `meta-plan-strategy.md` with alternatives (v4) |
| **meta-plan-author-agent** | max | writes `meta-plan.md` against the chosen strategy (renamed from `meta-plan-agent`); supports `draft` / `refine` / `iterate` modes (v4) |
| **meta-plan-skeptic-agent** | xhigh | adversarial fresh-context review of the meta-plan; verdict + `[blocker]`/`[must-fix]`/`[nit]` comments (v4) |
| **execute-step-agent** | **xhigh** | implements ONE build step per fresh-context dispatch. Reads plan + prior step summaries + own step description. Emits structured step-N-summary.md. Bounded context — never accumulates state across steps. (v7 — renamed from `execute-agent`) |
| **test-strategist-agent** | **xhigh** | v8 Stage 4 dispatcher. `plan` mode: reads plan + build-steps + diff, writes `test-plan.md` declaring which test kinds apply with per-kind invocation blocks and fix-target globs. `aggregate` mode: reads per-kind runner reports, writes unified `test-report.md` with binary verdict. |
| **test-runner-unit** | medium | v8 specialist for deterministic command-line tests: unit, types, lint. Runs declared command, parses output, fails on non-zero or threshold breach. |
| **test-runner-eval** | high | v8 specialist for LLM eval sets: accuracy / faithfulness / latency / cost against thresholds. Knows promptfoo, deepeval, inspect-ai, judge-model patterns. Fix-targets default to prompts, not code. |
| **test-runner-agent-flow** | high | v8 specialist for agentic flow tests: multi-turn conversation validation + tool-use validation + adversarial scenarios. LLM-as-judge for soft acceptance; deterministic tool-call inspection. |
| **test-runner-browser** | high | v8 specialist for UI end-to-end + visual regression (playwright, cypress). Owns dev-server lifecycle: start, wait for ready, run tests, trap-on-EXIT teardown. Fix-targets default to frontend. |
| **test-runner-perf** | medium | v8 specialist for performance benchmarks. Knows pytest-benchmark, locust, k6. Reports p50/p95/p99 distributions across multiple runs, not single numbers. Fix-targets favor algorithm code over config. |
| refine-agent | high | target-aware (v8) + hardened (v10): reads test-plan.md's per-kind fix-target globs before patching; cannot write to contract surfaces (tests, fixtures, snapshots, evals) — hook-enforced via `.refine-active` flag. Contract-surface fixes escalate via `replan-needed` with citation. Also handles PR-style review/tester comments at Stage 5. |
| **simplify-author-agent** | **high** | v9 cleanup author (renamed from `simplify-agent`). Reads conventions dynamically from root + nested `CLAUDE.md`, `.brain/STACK.md`, plan `## Approach` `[DECIDED]` marks — no hardcoded rule list. Checkpoint commit before edits. Returns structured `re_test_kinds` for targeted re-test. Honors broadened protected-surface list (tests, prompts, evals, snapshots, benchmarks). |
| **simplify-skeptic-agent** | **xhigh** | v9 adversarial review of the author's diff. Verdict + `[blocker]` / `[must-fix]` / `[nit]` comments. Checks: protected surfaces untouched; cited conventions actually appear in cited source; deletions verified dead via grep; `re_test_kinds` correct for what was touched. 1 refine round, then revert on persistent blockers. |
| verify-agent | **high** | pre-PR adherence (binary pass/fail) + route-based failure classification (v11). Runs 5 mechanical pre-checks (diff vs scope, `[QUESTION]` count, manual-step boxes, deviations triage, plan-quality) before reasoning. Each failure carries `route: refine | replan | user` so the orchestrator dispatches the right consumer instead of burning refine cycles on non-refinable issues. Structured evidence format only — no prose-only adherence claims. |
| review-agent | xhigh | quality review on PR. v12: `mode: pr` is live — writes `review-comments.md` (session source of truth) AND posts one `gh pr review` per round bundling inline comments + verdict. Does NOT read PR comments back. |
| tester-agent | high | functional / eval validation. v12: `mode: pr` is live — writes `tester-report.md` (session source of truth) AND posts a summary `gh pr comment`. |
| integrate-agent | medium | commit story composition + `.brain/` writeback proposals (v12: does NOT push, create PRs, or merge; the squash merge happens at `/mar:approve integrate` via `gh pr merge --squash`). |
| retrospect-agent | xhigh | post-archive audit (v13). Writes `sessions/archive/<id>/retrospect.md` (per-session: wins / session findings / framework findings). Emits chat-output "ready to file" block formatted as GitHub Issue bodies for `sindreespeland/marauders-mischief` — maintainer triages manually. No framework-shared file. |

Every stage = fresh sub-agent invocation via Task tool. No agent inherits another's conversation. Only the orchestrator (the running `/mar:*` slash command) persists across stages, and it compacts at phase boundaries (mandatory for L/XL).

### Meta-research role roster by kind (v3)

`/mar:session-start` derives the active roster from the session's `kind`:

| Kind | Roster |
|---|---|
| `greenfield` | product, domain, prior-art, ux, ops, skeptic |
| `new-feature` | product, domain, prior-art, ux, skeptic |
| `refactor` | domain, prior-art, skeptic |
| `bug` | domain, skeptic |
| `infra-ops` | domain, ops, prior-art, skeptic |

`--roles <comma-list>` overrides the preset. `skeptic` is always included; if omitted it is appended automatically.

---

## 10. Multi-project parallelism

The framework supports multiple Claude Code instances in parallel:

- **Different repos, parallel CC instances** — each repo has its own `sessions/active/`, own `.claude/`, own scope hook, own `$CLAUDE_PROJECT_DIR`. No shared state.
- **Same repo, multiple CC windows** — per-window pointer at `.claude/sessions/pointer-<CLAUDE_CODE_SSE_PORT>` keys session state by CC instance. `current-session.sh` / `set-session.sh` / `check-scope.py` all resolve via the per-window key.

**Step 2** adds: per-repo `gh` auth handled via the user's normal credential setup.

---

## 11. Project organization

Sessions run **repo-wide**. The plan's `## Scope` section declares which files a phase touches; the PreToolUse scope hook (`ops/workflow/scripts/check-scope.py`) enforces those paths per phase.

- **No session-level "service" binding.** The v0.1–v0.3 service axis was carried over from a different repo setup and was removed in v0.4. Scope fencing happens per phase, via the plan, not per session.
- **GitHub integration is single-repo.** `create-phase-issues.sh` reads the repo root's `origin` remote and creates issues there. The repo where `mar init` ran is the repo where issues land.
- **`/mar:session-start` does not** create GitHub repos, set up remotes, or run `gh auth login`. Repo-level setup (git init, `gh auth login`, `git remote add origin`) is the user's responsibility before `/mar:plan` reaches Stage 2b.
- **Multiple parallel sessions** in the same repo are allowed; each lives in its own `sessions/active/<id>/` directory and is keyed by the per-window `$CLAUDE_CODE_SSE_PORT` pointer.

---

## 12. Repo layout

```
ops/workflow/
  README.md                    # this file
  WORKFLOW-V2-DRAFT.md         # design spec
  templates/
    session.md.template
    meta-plan.md.template
    plan.md.template            # v2 schema
    issue-body.md.template      # derived from plan.md (Step 1 local; Step 2 = GitHub issue body)
    review-comments.md.template # review-agent output (local mode)
    tester-report.md.template   # tester-agent output (local mode)
    deviations.md.template      # execute-step-agent's structured deviation log
    step-summary.md.template    # v7 — structured handoff between build steps
    test-plan.md.template       # v8 — test-strategist (plan mode) output
    test-report.md.template     # v8 — test-strategist (aggregate mode) output
    simplify-report.md.template # v9 — author edits + skeptic review + re_test_kinds
    verification.md.template    # narrowed: pass/fail adherence + DoD evidence
    phase-summary.md.template
    integration.md.template
  scripts/
    current-session.sh          # resolves the per-window session pointer
    set-session.sh              # writes the per-window session pointer
    check-scope.py              # PreToolUse hook for scope enforcement
    derive-issue-body.py        # plan.md → issue-body.md (canonical → derived view)

.claude/
  agents/                       # agent definitions
  commands/mar/                 # slash command definitions

sessions/
  active/<session-id>/          # current sessions
    session.md
    meta-research/              # L/XL only, v3 multi-role meta-research
      round-1/
        product.md              # only roles in active roster
        domain.md
        prior-art.md
        ux.md
        ops.md
        skeptic.md
      briefing-1.md             # orchestrator: convergences / tensions / open questions
      human-direction-1.md      # user's direction at the gate (only if iterated)
      round-2/                  # only if iterated; only re-run roles
        <role>.md
      briefing-2.md             # only if round 2 ran
      synthesis.md              # final, feeds the Stage 2a strategist
    meta-plan.md                # L/XL only — canonical plan (v4 schema)
    meta-plan-strategy.md       # L/XL only, v4 — strategist's pick + alternatives
    meta-plan-review.md         # L/XL only, v4 — skeptic's round-1 verdict + comments
    meta-plan-review-2.md       # L/XL only, v4 — only if refine round 2 ran
    meta-plan-revisions.md      # L/XL only, v4 — author's responses to skeptic comments
    proposed-issue-bodies.md    # L/XL only, after Stage 2b
    phases/<phase-id>/
      research.md
      plan.md                   # canonical
      issue-body.md             # derived from plan.md
      progress.md               # gitignored
      build-steps/              # v7 — per-step summary files
        step-1-summary.md
        step-2-summary.md
        ...
      deviations.md             # tracked — execute-step-agent's deviation log (cross-step rollup)
      test-plan.md              # v8 — test-strategist (plan mode): which kinds apply + fix-target globs
      test-results/             # v8 — per-kind runner reports
        unit-report.md          # only kinds the strategist declared applicable
        eval-report.md
        agent-flow-report.md
        browser-report.md
        perf-report.md
      test-report.md            # v8 — test-strategist (aggregate mode): unified verdict over per-kind reports
      simplify-report.md
      verification.md
      review-comments.md        # Step 1 local mode
      tester-report.md          # Step 1 local mode
      summary.md
    INTEGRATION.md
    SUMMARY.md                  # written at archive time
  archive/<session-id>/         # archived sessions (immutable)
```

**Gitignore**: `sessions/active/*/phases/*/progress.md` (noisy), `.claude/sessions/pointer-*`, `.claude/.current-session`.

---

## 13. Plan marks — `[DECIDED] / [ASSUMED] / [QUESTION]`

Plan-agent tags every non-trivial decision in the Approach section:

- **`[DECIDED]`** — committed direction, defensible from research + `.brain/`.
- **`[ASSUMED]`** — reasonable default, flagged for user review.
- **`[QUESTION]`** — narrow, specific question only the user can answer.

Guidance modes set the `[QUESTION]` budget:
- `light` — 0–2 `[QUESTION]`s (bias `[ASSUMED]`)
- `normal` — 2–4
- `deep` — 4–8

In **autonomous** mode, every `[QUESTION]` must be resolved to `[ASSUMED]` with explicit fallback (or the feature dropped). The plan gate refuses to advance if any `[QUESTION]` remains.

---

## 14. Iterate semantics

`/mar:iterate <gate> "<direction>"` — apply free-text direction at an open gate without losing position.

Routing:
- "Research deeper on X" — research-agent runs again, **appends** to research.md (raw notes preserved). plan-agent then re-derives plan.md from updated research.
- "Adjust plan: <change>" — plan-agent regenerates plan.md applying direction.
- "Wrong scope" — equivalent to reject.

After plan regeneration: `derive-issue-body.py` runs automatically. **Hard-block on failure** — the plan and issue body must agree, or we don't move (Step 1 hard-block; Step 2 extends to `gh issue edit`).

---

## 15. What stays from v1

- Size-adaptive flow.
- Two-level decomposition: session → phases → stages.
- `[DECIDED]` / `[ASSUMED]` / `[QUESTION]` plan marks.
- Guidance modes (light / normal / deep).
- Autonomy modes (interactive / normal / streamlined / autonomous).
- Artifact-as-memory principle — compaction is lossless.
- Fresh-context verification (now split: pre-PR verify for adherence, review-agent for quality).
- PreToolUse scope hook (`ops/workflow/scripts/check-scope.py`, using `$CLAUDE_PROJECT_DIR`).
- Per-window session pointer keyed by `$CLAUDE_CODE_SSE_PORT`.
- Knowledge pipeline (`ops/memory/`) integration at integrate only.
- `retrospect-agent` (v13: writes per-session `sessions/archive/<id>/retrospect.md`; framework feedback flows to the maintainer via chat-output paste-ready issue bodies, not a shared file).

---

## 16. What's live, what's deferred

**Live (v0.1 → v0.4):**
- All agents and templates for v4 workflow.
- Plan v4 schema (Acceptance demo, Decomposition strategy, Alternatives considered).
- 3-way gates + the v4 meta-plan gate's 4-option menu (approve / iterate / revise / redirect).
- `/mar:iterate` with `derive-issue-body.py` re-derivation.
- Stage 2 split (meta-research → 2a → 2b → 2c per phase).
- review-agent + tester-agent at Stage 5 in local-file mode.
- **v0.4: `gh issue create` per phase** — Stage 2b runs `create-phase-issues.sh` on approve, using the repo's `origin` remote. Pre-flights `gh auth status`, `gh repo view`, `permissions.push` probe; hard-blocks on any failure with a remediation message.

**Deferred (post-v0.4):**
- ~~`gh pr create --draft` at Stage 4 (issue creation works; PR creation does not yet).~~ → Live as of v12 (`create-phase-pr.sh` at Stage 2.2 of `/mar:ship`).
- ~~review-agent / tester-agent posting comments to the draft PR at Stage 5 (Stage 5 still runs in local-file mode).~~ → Live as of v12 (`mode: pr`).
- ~~Squash merge with the plan's commit preview at integrate (commit is local; user merges manually).~~ → Live as of v12 (`gh pr merge --squash` at `/mar:approve integrate`).
- Worktree-per-phase (phases share the working tree today). **Still deferred.**
- `gh issue edit` for live re-derivation when the plan iterates after issues exist. **Still deferred.**
- Mark PR `ready for review` automatically at Stage 5 verdict-clear (today: `gh pr ready` fires only at `/mar:approve integrate`, just before the merge). **Deferred to v0.13 polish.**
- CI-status enforcement as a hard merge-block (today: review-agent waits for CI but `/mar:approve integrate` only checks `mergeStateStatus`, not CI verdict directly). **Deferred to v0.13.**

---

## 17. Command surface

### Session lifecycle
- `/mar:session-start` — interactive picker (size / kind / guidance / autonomy), scaffolds `sessions/active/<id>/`. Accepts `--kind <value>` and `--roles <comma-list>` in $ARGUMENTS to skip the kind picker or override the roster preset.
- `/mar:session-resume [id]` — load session.
- `/mar:session-list` — show active sessions.
- `/mar:session-archive [id]` — move to `sessions/archive/`.
- `/mar:stop` — hard halt.
- `/mar:status` — current state, compact.
- `/mar:retrospect <id> [focus]` — fresh-context post-archive audit. Writes `sessions/archive/<id>/retrospect.md` (per-session: wins + session findings + framework findings). Emits chat-output "ready to file" block of framework findings as GitHub Issue bodies for the maintainer (`sindreespeland/marauders-mischief`). Does not modify the archive other than the new retrospect.md.

### Stage / sub-stage drivers
- `/mar:plan` — advance the current planning sub-stage (2a / 2b / 2c). Pauses at the current gate.
- `/mar:ship` — build loop + Stage 5. Pauses at integrate gate.
- `/mar:integrate` — produce INTEGRATION.md. Pauses at integrate gate.

### Gate actions
- `/mar:approve <gate>` — advance. Valid gates: `research`, `meta-research`, `meta-plan`, `issue-scaffolding`, `plan`, `integrate`.
- `/mar:iterate <gate> "<direction>"` — refine without losing position. Valid gates: `research`, `meta-research`, `meta-plan`, `plan`, `integrate` (issue-scaffolding is not iterable).
- `/mar:revise <target> "<note>"` (v4 / v5 / v6) — back up with a note. Valid at **three** gates: (a) from the meta-plan gate, target=`meta-plan`, backs up to meta-research; (b) from the phase research gate (v5), target=`meta-plan`, backs up to meta-plan iteration; (c) from the phase plan gate (v6), target ∈ {`research`, `meta-plan`} — `research` backs up to phase research, `meta-plan` backs up further. Target names the gate being backed up *to*; the current gate is detected from session state.
- `/mar:redirect "<new direction>"` (v4) — pivot the session: discard plan + research, prepend the new direction to `session.md`'s `## Why`, restart from meta-research round 1. Preserves session id, kind, roles, size, guidance, autonomy, and `.brain/` references. Valid at meta-research and meta-plan gates only (would orphan issues after Stage 2b).
- `/mar:reject <gate>` — discard the gate's artifact and revert to the prior stage. Still works at meta-plan but is not shown in the v4 gate menu (use `/mar:redirect` for pivots, `/mar:stop` to genuinely abandon).
- `/mar:replan` (deprecated v0.3, removed v0.4) — prints a migration hint pointing at `/mar:redirect`. No destructive action.

### Adjustments
- `/mar:continue <stage> "<note>"` — re-run a stage with an extra note (no gate change).
- `/mar:replan [meta]` — discard current plan + research, restart.

---

## 18. Artifacts as memory

State lives in files, not context:
- `session.md` — top-level state, timeline.
- `meta-plan.md`, `meta-research.md` — session-level (L/XL).
- `phases/<id>/{research, plan, deviations, test-report, simplify-report, verification, review-comments, tester-report, summary}.md` — phase-level.
- `INTEGRATION.md` — final commit story + `.brain/` writeback proposals.
- `SUMMARY.md` — written at archive.

Compaction is lossless because every state is reconstructible from disk. Between-phase compaction (mandatory for L/XL) summarizes the completed phase into a paragraph and drops the rest.

Per-stage compaction within a phase is unnecessary — every stage is already a fresh sub-agent.

---

## 19. Rollback

Framework rollback is fully contained in the directories `mar init` writes:
- `.claude/agents/`
- `.claude/commands/mar/`
- `ops/workflow/`
- `ops/memory/`

Reverting those four locations restores the prior `mar` version. The `.mm/lockfile.json` records SHA256 of every shipped file so drift can be detected.
