#!/usr/bin/env bash
# Open a draft PR for the current phase, in the GitHub repo this repo's
# `origin` remote points at (v12).
#
# Per durable workflow policy:
#   - PRs are session output (mirrors of session .md state for human visibility).
#   - PRs live in the repo's own GitHub origin remote.
#   - Hard-block on any gh failure (auth, repo missing, push denied,
#     pr create denied).
#
# Resolution flow:
#   1. Pre-flight: gh auth status. Refuse if not authenticated.
#   2. Resolve <owner>/<repo> from `git remote get-url origin` at the repo root.
#   3. Pre-flight: gh repo view <owner>/<repo> confirms existence + access.
#   4. Generate pr-body.md via derive-pr-body.py (canonical: plan.md → body).
#   5. Push the current branch to origin.
#   6. gh pr create --draft --title "..." --body-file phases/<id>/pr-body.md.
#   7. Record pr_number + pr_url on the phase's plan.md frontmatter and on
#      session.md's `prs:` field (keyed by phase_id).
#
# The PR is opened against the repo's default branch (typically main).
#
# Stdlib bash + gh + python3 (for frontmatter editing). No deps.
#
# Usage: create-phase-pr.sh --session <session-id> --phase <phase-id>
#        create-phase-pr.sh --session <session-id> --phase <phase-id> --dry-run
set -euo pipefail

SESSION_ID=""
PHASE_ID=""
DRY_RUN=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --session) SESSION_ID="$2"; shift 2 ;;
    --phase)   PHASE_ID="$2";   shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done

if [[ -z "$SESSION_ID" || -z "$PHASE_ID" ]]; then
  echo "create-phase-pr: --session <id> and --phase <id> required" >&2
  exit 2
fi

ROOT="$(git rev-parse --show-toplevel)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SESSION_DIR="$ROOT/sessions/active/$SESSION_ID"
SESSION_MD="$SESSION_DIR/session.md"
PHASE_DIR="$SESSION_DIR/phases/$PHASE_ID"
PLAN_PATH="$PHASE_DIR/plan.md"
PR_BODY_PATH="$PHASE_DIR/pr-body.md"

if [[ ! -f "$SESSION_MD" ]]; then
  echo "create-phase-pr: session.md not found at $SESSION_MD" >&2
  exit 1
fi
if [[ ! -f "$PLAN_PATH" ]]; then
  echo "create-phase-pr: plan.md not found at $PLAN_PATH — run /mar:plan first" >&2
  exit 1
fi

# --- Resolve owner/repo from origin -----------------------------------------

REMOTE_URL="$(git -C "$ROOT" remote get-url origin 2>/dev/null || true)"
if [[ -z "$REMOTE_URL" ]]; then
  echo "create-phase-pr: repo at $ROOT has no 'origin' remote configured" >&2
  echo "  → fix: git remote add origin git@github.com:<owner>/<repo>.git" >&2
  exit 1
fi

OWNER_REPO="$(echo "$REMOTE_URL" | sed -E 's#.*github\.com[:/]([^/]+/[^/]+)(\.git)?/?$#\1#' | sed -E 's#\.git$##')"
if [[ -z "$OWNER_REPO" || "$OWNER_REPO" == "$REMOTE_URL" ]]; then
  echo "create-phase-pr: could not parse owner/repo from remote: $REMOTE_URL" >&2
  exit 1
fi

# --- Pre-flight: gh auth + repo access --------------------------------------

if ! gh auth status >/dev/null 2>&1; then
  echo "create-phase-pr: gh is not authenticated" >&2
  echo "  → fix: gh auth login" >&2
  exit 1
fi

if ! gh repo view "$OWNER_REPO" >/dev/null 2>&1; then
  echo "create-phase-pr: cannot access $OWNER_REPO with current gh auth" >&2
  exit 1
fi

# --- Derive PR body from plan ------------------------------------------------

# The PR body is a derived view of plan.md, regenerated on every plan iterate.
# Use the SCRIPT_DIR sibling derive-pr-body.py (lives in the same scripts/workflow/ dir).
if ! python3 "$SCRIPT_DIR/derive-pr-body.py" --session "$SESSION_ID" --phase "$PHASE_ID"; then
  echo "create-phase-pr: derive-pr-body.py failed" >&2
  exit 1
fi

if [[ ! -f "$PR_BODY_PATH" ]]; then
  echo "create-phase-pr: pr-body.md not produced by derive-pr-body.py" >&2
  exit 1
fi

# --- Determine PR title -----------------------------------------------------

# Title format: "[<phase-id>] <one-line summary>"
# Read the first non-comment line in pr-body.md's ## Summary section.
TITLE_SUMMARY="$(awk '
  /^## Summary$/ { in_summary=1; next }
  in_summary && /^## / { exit }
  in_summary && NF { print; exit }
' "$PR_BODY_PATH")"

if [[ -z "$TITLE_SUMMARY" ]]; then
  TITLE_SUMMARY="$PHASE_ID"
fi

PR_TITLE="[${PHASE_ID}] ${TITLE_SUMMARY}"

# --- Push current branch to origin ------------------------------------------

BRANCH="$(git -C "$ROOT" rev-parse --abbrev-ref HEAD)"
DEFAULT_BRANCH="$(gh repo view "$OWNER_REPO" --json defaultBranchRef -q .defaultBranchRef.name 2>/dev/null || echo main)"

if [[ "$BRANCH" == "$DEFAULT_BRANCH" ]]; then
  echo "create-phase-pr: refusing to open PR from default branch '$DEFAULT_BRANCH'" >&2
  echo "  → switch to a feature branch first (e.g. git checkout -b phase/<id>)" >&2
  exit 1
fi

if [[ "$DRY_RUN" -eq 1 ]]; then
  echo "[dry-run] would push: $BRANCH → origin"
  echo "[dry-run] would create draft PR in $OWNER_REPO:"
  echo "  title: $PR_TITLE"
  echo "  body-file: $PR_BODY_PATH"
  echo "  base: $DEFAULT_BRANCH"
  exit 0
fi

echo "pushing branch '$BRANCH' to origin..."
if ! git -C "$ROOT" push -u origin "$BRANCH" 2>&1; then
  echo "create-phase-pr: git push failed" >&2
  exit 1
fi

# --- Create draft PR ---------------------------------------------------------

echo "creating draft PR in $OWNER_REPO..."
if ! PR_URL="$(gh pr create -R "$OWNER_REPO" \
                 --draft \
                 --base "$DEFAULT_BRANCH" \
                 --head "$BRANCH" \
                 --title "$PR_TITLE" \
                 --body-file "$PR_BODY_PATH" 2>&1)"; then
  echo "create-phase-pr: gh pr create failed:" >&2
  echo "$PR_URL" >&2
  if echo "$PR_URL" | grep -qiE '403|not.*accessible|resource.*not.*accessible'; then
    echo "  → fine-grained PAT likely lacks Pull requests:Write on $OWNER_REPO" >&2
    echo "  → fix: https://github.com/settings/personal-access-tokens" >&2
  fi
  exit 1
fi

# Extract PR number from URL
PR_NUM="$(echo "$PR_URL" | sed -E 's#.*/pull/([0-9]+).*#\1#')"
if [[ -z "$PR_NUM" || "$PR_NUM" == "$PR_URL" ]]; then
  echo "create-phase-pr: created but could not parse PR number from: $PR_URL" >&2
  exit 1
fi

echo "  → PR #$PR_NUM ($PR_URL)"

# --- Record on plan.md frontmatter ------------------------------------------

python3 - <<PY "$PLAN_PATH" "$PR_NUM" "$PR_URL"
import sys, re, pathlib
p = pathlib.Path(sys.argv[1])
num, url = sys.argv[2], sys.argv[3]
text = p.read_text()
m = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
if not m:
    sys.exit(0)
fm = m.group(1)
def upsert(fm, key, value):
    pat = rf"^{re.escape(key)}:\s*.*$"
    if re.search(pat, fm, re.MULTILINE):
        return re.sub(pat, f"{key}: {value}", fm, flags=re.MULTILINE)
    return fm + f"\n{key}: {value}"
fm = upsert(fm, "pr", num)
fm = upsert(fm, "pr_url", url)
new_text = f"---\n{fm}\n---\n" + text[m.end():]
p.write_text(new_text)
PY

# --- Record on session.md ---------------------------------------------------

# session.md gets a `prs:` field keyed by phase_id, like `issues:`.
python3 - <<PY "$SESSION_MD" "$PHASE_ID" "$PR_NUM" "$OWNER_REPO"
import sys, re, pathlib
p = pathlib.Path(sys.argv[1])
phase_id, pr_num, repo = sys.argv[2], sys.argv[3], sys.argv[4]
text = p.read_text()
m = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
if not m:
    sys.exit(0)
fm = m.group(1)
def upsert(fm, key, value):
    pat = rf"^{re.escape(key)}:\s*.*$"
    if re.search(pat, fm, re.MULTILINE):
        return re.sub(pat, f"{key}: {value}", fm, flags=re.MULTILINE)
    return fm + f"\n{key}: {value}"

# Build the new prs: line. Format: "phase-1=#42, phase-2=#43".
prs_match = re.search(r"^prs:\s*(.*)$", fm, re.MULTILINE)
existing = prs_match.group(1).strip() if prs_match else ""
entries = {}
if existing:
    for part in existing.split(","):
        part = part.strip()
        if not part or "=" not in part:
            continue
        k, v = part.split("=", 1)
        entries[k.strip()] = v.strip()
entries[phase_id] = f"#{pr_num}"
new_prs = ", ".join(f"{k}={v}" for k, v in entries.items())

fm = upsert(fm, "prs_repo", repo)
fm = upsert(fm, "prs", new_prs)
new_text = f"---\n{fm}\n---\n" + text[m.end():]
p.write_text(new_text)
PY

echo
echo "draft PR opened: #$PR_NUM in $OWNER_REPO"
echo "session.md updated: prs entry for $PHASE_ID=#$PR_NUM"
