"""
PreToolUse scope-enforcement hook for the workflow framework.

Reads the active session/phase plan and blocks Edit/Write/MultiEdit on paths
outside the declared Scope or inside the explicit WILL-NOT-TOUCH boundary.

Fail-open: if the hook cannot confidently determine scope (no active session,
missing files, unparseable plan, unexpected errors), it allows the tool call
and logs a warning to stderr. The honor system in agent prompts is the
backstop; this hook catches drift, not edge cases.

Stale-lock defenses (also fail-open):
  - If session.md `status:` is paused / archived / complete: fall open.
    The /mar:stop command sets status:paused; this honors it.
  - If session.md `last_activity:` is older than STALE_HOURS hours: fall
    open with a stderr warning. A session idle that long is almost certainly
    orphaned (e.g. user closed Claude Code without /mar:stop yesterday).

Stdlib only — no deps. Invoked per-tool-call, so it must be fast.
"""

import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
LEGACY_POINTER = ROOT / ".claude" / ".current-session"
PER_WINDOW_DIR = ROOT / ".claude" / "sessions"
SESSIONS_DIR = ROOT / "sessions" / "active"

# Sessions with no activity in this window are treated as stale and the hook
# falls open. The /mar:session-resume command refreshes last_activity, so
# active work re-arms enforcement.
STALE_HOURS = 2

# Statuses that mean "no scope enforcement needed" — the user/framework has
# explicitly stepped out of scope-enforced execution.
INACTIVE_STATUSES = {"paused", "archived", "complete", "completed", "stopped"}


def resolve_session_id() -> str | None:
    """Mirror ops/workflow/scripts/current-session.sh resolution order.

    1. $MAR_SESSION_ID override
    2. .claude/sessions/pointer-<CLAUDE_CODE_SSE_PORT> (per-window)
    3. .claude/.current-session (legacy fallback)
    Returns None when no pointer exists (fail-open caller should allow).
    """
    override = os.environ.get("MAR_SESSION_ID", "").strip()
    if override:
        return override

    sse_port = os.environ.get("CLAUDE_CODE_SSE_PORT", "").strip()
    if sse_port:
        per_window = PER_WINDOW_DIR / f"pointer-{sse_port}"
        if per_window.exists():
            try:
                return per_window.read_text().strip() or None
            except OSError:
                pass

    if LEGACY_POINTER.exists():
        try:
            return LEGACY_POINTER.read_text().strip() or None
        except OSError:
            pass

    return None

# Always-allow: session bookkeeping writes have to succeed regardless of plan.
ALWAYS_ALLOW = [
    "sessions/**",
]

# Protected surfaces during refine dispatch (v10).
#
# refine-agent patches code in response to test/verify/review/tester failures.
# It must NOT modify the contract surfaces — tests, fixture data, snapshot
# baselines, eval datasets, and any path the plan cites as a tester scenario.
# Patching the contract to make a failing test pass silently weakens the
# contract; this is the failure mode this list closes.
#
# Enforced only when `<session>/.refine-active` exists. The /mar:ship
# orchestrator touches this flag before dispatching refine and removes it
# after refine returns, so the list applies during refine dispatches and
# nowhere else. Execute-step's initial test/fixture writes are unaffected
# because the flag isn't set during execute.
#
# If refine genuinely needs a protected-surface change, the contract is wrong
# — that's `replan-needed` with citation, not a silent edit.
REFINE_PROTECTED_SURFACES = [
    "tests/**",
    "**/__snapshots__/**",
    "**/*.snap",
    "**/*.snapshot",
    "evals/**",
    # Common fixture-data globs. Production code may also live in *.json files,
    # so only paths under fixtures/ or test data trees are blocked here.
    "tests/fixtures/**",
    "**/fixtures/**/*.jsonl",
    "**/fixtures/**/*.csv",
    "**/fixtures/**/*.json",
]


def emit_allow() -> None:
    sys.exit(0)


def emit_deny(reason: str) -> None:
    out = {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": reason,
        }
    }
    print(json.dumps(out))
    sys.exit(0)


def warn(msg: str) -> None:
    print(f"[check-scope] {msg}", file=sys.stderr)


def glob_to_regex(pattern: str) -> str:
    parts = []
    i = 0
    while i < len(pattern):
        c = pattern[i]
        if c == "*":
            if i + 1 < len(pattern) and pattern[i + 1] == "*":
                if i + 2 < len(pattern) and pattern[i + 2] == "/":
                    parts.append("(?:.*/)?")
                    i += 3
                else:
                    parts.append(".*")
                    i += 2
            else:
                parts.append("[^/]*")
                i += 1
        elif c == "?":
            parts.append("[^/]")
            i += 1
        else:
            parts.append(re.escape(c))
            i += 1
    return "^" + "".join(parts) + "$"


def glob_match(path: str, pattern: str) -> bool:
    pattern = pattern.strip().lstrip("./")
    path = path.lstrip("./")
    if path == pattern:
        return True
    if pattern.endswith("/"):
        prefix = pattern.rstrip("/")
        return path == prefix or path.startswith(prefix + "/")
    if "*" not in pattern and "?" not in pattern:
        return path == pattern or path.startswith(pattern + "/")
    return bool(re.match(glob_to_regex(pattern), path))


def extract_frontmatter_field(session_text: str, field: str) -> str | None:
    """Generic frontmatter field reader. Returns stripped value or None."""
    m = re.search(rf"^{re.escape(field)}:\s*(.+?)\s*$", session_text, re.MULTILINE)
    if not m:
        return None
    raw = m.group(1).strip().strip('"\'')
    if raw in ("", "null", "none", "-", "~"):
        return None
    return raw


def is_session_inactive(session_text: str) -> bool:
    """True when the session's status field marks it as not-currently-enforced."""
    status = extract_frontmatter_field(session_text, "status")
    if status is None:
        return False
    return status.lower() in INACTIVE_STATUSES


def is_session_stale(session_text: str, max_hours: float = STALE_HOURS) -> bool:
    """True when last_activity is older than max_hours hours.

    Tolerant of multiple ISO-8601 forms (with/without offset). On parse error,
    returns False (don't auto-fall-open on garbled timestamps — let the caller
    enforce). This is a *secondary* defense; the primary is is_session_inactive.
    """
    last = extract_frontmatter_field(session_text, "last_activity")
    if last is None:
        return False
    try:
        # Python <3.11 datetime.fromisoformat doesn't take 'Z'; normalise.
        normalised = last.replace("Z", "+00:00")
        dt = datetime.fromisoformat(normalised)
        if dt.tzinfo is None:
            # Treat naive timestamps as local time.
            dt = dt.astimezone()
    except (ValueError, TypeError):
        return False

    now = datetime.now(timezone.utc).astimezone()
    return now - dt > timedelta(hours=max_hours)


def extract_scope(plan_text: str) -> tuple[list[str], list[str]]:
    """Parse the `## Scope` section into (allow, deny) pattern lists.

    Recognizes the plan.md.template shape: bullets holding backtick-wrapped
    paths, with the deny list introduced by a "WILL NOT" line.
    """
    lines = plan_text.splitlines()
    scope_start = None
    for i, line in enumerate(lines):
        if re.match(r"^##\s+Scope\s*$", line, re.IGNORECASE):
            scope_start = i
            break
    if scope_start is None:
        return [], []

    scope_end = len(lines)
    for i in range(scope_start + 1, len(lines)):
        if re.match(r"^##\s", lines[i]):
            scope_end = i
            break

    allow: list[str] = []
    deny: list[str] = []
    mode = "allow"
    bullet_re = re.compile(r"^\s*[-*]\s+`([^`]+)`")
    for line in lines[scope_start:scope_end]:
        if "WILL NOT" in line.upper():
            mode = "deny"
            continue
        m = bullet_re.match(line)
        if not m:
            continue
        path = m.group(1).strip()
        # Skip unsubstituted template placeholders or angle-bracket stubs.
        if "{{" in path or path.startswith("<") or path.endswith(">"):
            continue
        (allow if mode == "allow" else deny).append(path)
    return allow, deny


def target_rel_path(tool_input: dict) -> str | None:
    raw = tool_input.get("file_path") or tool_input.get("filePath")
    if not raw:
        return None
    p = Path(raw)
    if p.is_absolute():
        try:
            return str(p.resolve().relative_to(ROOT))
        except ValueError:
            return None
    return str(p)


def load_input() -> dict:
    try:
        return json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return {}


def main() -> None:
    data = load_input()
    tool = data.get("tool_name", "")
    if tool not in ("Edit", "Write", "MultiEdit"):
        emit_allow()

    tool_input = data.get("tool_input") or {}
    rel = target_rel_path(tool_input)
    if rel is None:
        emit_allow()

    for pattern in ALWAYS_ALLOW:
        if glob_match(rel, pattern):
            emit_allow()

    session_id = resolve_session_id()
    if not session_id:
        emit_allow()

    session_dir = SESSIONS_DIR / session_id
    session_md = session_dir / "session.md"
    if not session_md.exists():
        warn(f"session.md missing for '{session_id}'")
        emit_allow()

    try:
        session_text = session_md.read_text()
    except OSError as e:
        warn(f"could not read session.md: {e}")
        emit_allow()

    # Stale-lock defense 1: explicit `status: paused / archived / complete`.
    # The /mar:stop command sets status:paused — honor it.
    if is_session_inactive(session_text):
        emit_allow()

    # Stale-lock defense 2: last_activity older than STALE_HOURS hours.
    # Catches the "user closed Claude Code without /mar:stop" case from
    # yesterday or longer ago.
    if is_session_stale(session_text):
        warn(
            f"session '{session_id}' last_activity > {STALE_HOURS}h ago — "
            f"treating as stale and falling open. Run /mar:session-resume "
            f"or /mar:stop to make session state explicit."
        )
        emit_allow()

    # Refine protected surfaces (v10): when the orchestrator has flagged a
    # refine dispatch in progress, block writes to contract-surface paths
    # (tests, fixtures, snapshots, evals). The flag file is created by
    # /mar:ship before each refine Task dispatch and removed after refine
    # returns; see ops/workflow/README.md §v10 addition.
    refine_active_flag = session_dir / ".refine-active"
    if refine_active_flag.exists():
        for pattern in REFINE_PROTECTED_SURFACES:
            if glob_match(rel, pattern):
                emit_deny(
                    f"Refine protected surface: '{rel}' matches refine's "
                    f"contract-protected glob '{pattern}'. Refine cannot "
                    f"silently modify tests, fixtures, snapshots, or eval "
                    f"data — those are the contract. Return replan-needed "
                    f"with a citation (Test matrix row, runner output, or "
                    f"scenario name) so the user can decide whether the "
                    f"contract should change."
                )

    phase_match = re.search(
        r"^current_phase:\s*(.+?)\s*$", session_text, re.MULTILINE
    )
    if not phase_match:
        emit_allow()
    current_phase = phase_match.group(1).strip().strip('"\'')
    if current_phase in ("", "null", "none", "-", "~"):
        emit_allow()

    plan_path = session_dir / "phases" / current_phase / "plan.md"
    if not plan_path.exists():
        emit_allow()

    try:
        plan_text = plan_path.read_text()
    except OSError as e:
        warn(f"could not read plan.md: {e}")
        emit_allow()

    allow_patterns, deny_patterns = extract_scope(plan_text)

    for pattern in deny_patterns:
        if glob_match(rel, pattern):
            emit_deny(
                f"Scope violation: '{rel}' matches WILL-NOT-TOUCH rule "
                f"'{pattern}' in phase '{current_phase}'. Stop and return "
                f"replan-needed to the caller rather than retrying."
            )

    if not allow_patterns:
        warn(
            f"plan.md has no parseable scope patterns for phase "
            f"'{current_phase}' — allowing write to '{rel}'"
        )
        emit_allow()

    for pattern in allow_patterns:
        if glob_match(rel, pattern):
            emit_allow()

    patterns_display = ", ".join(allow_patterns[:5])
    if len(allow_patterns) > 5:
        patterns_display += f", ... (+{len(allow_patterns) - 5} more)"
    emit_deny(
        f"Scope violation: '{rel}' is outside phase '{current_phase}' declared "
        f"scope ({patterns_display}). If this path is legitimately needed, "
        f"return replan-needed to the caller — do not retry with a different tool."
    )


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception as e:
        warn(f"hook crashed, failing open: {e!r}")
        emit_allow()
