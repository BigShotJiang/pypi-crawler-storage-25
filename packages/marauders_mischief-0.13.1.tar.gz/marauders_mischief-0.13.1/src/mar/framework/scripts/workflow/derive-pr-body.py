#!/usr/bin/env python3
"""
Derive pr-body.md from a phase plan (v12).

plan.md is the canonical contract. The GitHub PR body is a derived view of it
— same principle as issue-body.md (see derive-issue-body.py). This script
generates the PR body and writes it to phases/<id>/pr-body.md. The orchestrator
hands the file to `gh pr create --body-file ...` and `gh pr edit --body-file
...` (on iterate).

The PR body is shorter than the issue body — issues hold the full contract;
PRs hold the user-visible "what's in this PR" summary. Reviewers click through
to the issue or the plan for the full contract.

Sections produced:
  - one-line summary (from plan §Summary if present, else first sentence of
    §Contract)
  - Test plan checklist (from plan §Tester scenarios)
  - Closes #<issue> (read from phases/<id>/plan.md frontmatter `issue:` field,
    populated by create-phase-issues.sh at Stage 2b)
  - Link back to plan.md and the issue

plan.md is canonical. This script never edits plan.md.

Stdlib only.
"""

import argparse
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SESSIONS = ROOT / "sessions" / "active"
TEMPLATE = ROOT / "ops" / "workflow" / "templates" / "pr-body.md.template"


def read_section(plan_text: str, heading: str) -> str:
    """Return the verbatim content of a `## <heading>` section. "" if absent."""
    lines = plan_text.splitlines()
    pattern = re.compile(rf"^##\s+{re.escape(heading)}\s*$")
    start = None
    for i, line in enumerate(lines):
        if pattern.match(line):
            start = i + 1
            break
    if start is None:
        return ""
    end = len(lines)
    for j in range(start, len(lines)):
        if re.match(r"^##\s+", lines[j]):
            end = j
            break
    return "\n".join(lines[start:end]).strip()


def extract_frontmatter(plan_text: str) -> dict[str, str]:
    m = re.match(r"^---\n(.*?)\n---", plan_text, re.DOTALL)
    if not m:
        return {}
    out: dict[str, str] = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            out[k.strip()] = v.strip()
    return out


def summary_line(plan_text: str) -> str:
    """One-line summary for the top of the PR body.

    Preference order:
      1. plan §Summary (verbatim if it's already one line)
      2. First sentence of §Contract
      3. Fallback: "Phase <id>"
    """
    summary_section = read_section(plan_text, "Summary")
    if summary_section:
        first_line = summary_section.splitlines()[0].strip()
        if first_line:
            return first_line
    contract = read_section(plan_text, "Contract")
    if contract:
        # First sentence: split on '. ', take first.
        first_sentence = re.split(r"(?<=[.!?])\s+", contract, maxsplit=1)[0].strip()
        if first_sentence:
            return first_sentence
    return ""


def test_plan_checklist(plan_text: str) -> str:
    """Render the Tester scenarios section as a checklist.

    Plan template stores tester scenarios as bulleted list. We convert to
    GitHub-style checkboxes so reviewers can tick them off during manual
    verification.
    """
    scenarios = read_section(plan_text, "Tester scenarios")
    if not scenarios:
        return "_No tester scenarios declared in plan._"

    out: list[str] = []
    for line in scenarios.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        # Convert "- <text>" / "* <text>" to "- [ ] <text>"; pass through
        # already-checked items and non-bullet text.
        m = re.match(r"^[-*]\s+(.+)$", stripped)
        if m:
            out.append(f"- [ ] {m.group(1)}")
        elif re.match(r"^- \[[ x]\]", stripped):
            out.append(stripped)
        else:
            out.append(stripped)
    return "\n".join(out) if out else "_No tester scenarios declared in plan._"


def closes_line(plan_text: str) -> str:
    """Return `Closes #<n>` when the phase plan's frontmatter carries an issue.

    Frontmatter `issue:` field is set by create-phase-issues.sh at Stage 2b.
    If absent (e.g. session predates auto-issue flow or scratch service),
    return empty string — integrate-agent can still merge without it.
    """
    fm = extract_frontmatter(plan_text)
    issue = fm.get("issue", "").strip()
    if not issue:
        return ""
    # Strip a leading '#' if someone wrote `issue: #42`.
    issue = issue.lstrip("#")
    if not issue.isdigit():
        return ""
    return f"Closes #{issue}"


def derive(session_id: str, phase_id: str) -> Path:
    phase_dir = SESSIONS / session_id / "phases" / phase_id
    plan_path = phase_dir / "plan.md"
    if not plan_path.exists():
        sys.exit(f"plan.md not found at {plan_path}")
    if not TEMPLATE.exists():
        sys.exit(f"pr-body template not found at {TEMPLATE}")

    plan_text = plan_path.read_text()
    template_text = TEMPLATE.read_text()

    summary = summary_line(plan_text) or "_(no summary in plan.md)_"
    test_plan = test_plan_checklist(plan_text)
    closes = closes_line(plan_text) or "_No linked issue._"
    size = read_section(plan_text, "Size").strip() or "—"

    rendered = (
        template_text
        .replace("{{SESSION_ID}}", session_id)
        .replace("{{PHASE_ID}}", phase_id)
        .replace("{{SIZE}}", size)
        .replace("{{SUMMARY_LINE}}", summary)
        .replace("{{TEST_PLAN_CHECKLIST}}", test_plan)
        .replace("{{CLOSES_LINE}}", closes)
    )

    out = phase_dir / "pr-body.md"
    out.write_text(rendered)
    return out


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Derive pr-body.md from plan.md (v12)."
    )
    ap.add_argument("--session", required=True, help="Session id")
    ap.add_argument("--phase", required=True, help="Phase id (e.g. phase-1)")
    args = ap.parse_args()

    out = derive(args.session, args.phase)
    rel = out.relative_to(ROOT) if out.is_absolute() else out
    print(f"derived: {rel}")


if __name__ == "__main__":
    main()
