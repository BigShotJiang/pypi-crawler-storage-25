#!/usr/bin/env python3
"""
Pre-execute credentials gate for the workflow framework.

Reads the session's meta-plan.md `## Credentials` block (or session.md fallback
for S/M sessions without a meta-plan), verifies that each declared credential
is *present* in its declared location, and exits non-zero with a structured
list of missing credentials when any are absent.

Hard requirement (per durable workflow policy):
  - The script verifies *presence by name* only (grep-style). It NEVER reads,
    logs, or otherwise exposes the secret VALUE. Agents must not see secret
    material; this script is the boundary.
  - Roster is session-level (not per-phase). All session credentials are
    checked at once, before the first execute stage.

Credentials block schema (in meta-plan.md or session.md):

    ## Credentials

    - name: ANTHROPIC_API_KEY
      scope: global
      location: ~/.config/mar/credentials.env
      setup: Get from https://console.anthropic.com/settings/keys

    - name: TELEGRAM_BOT_TOKEN
      scope: project
      location: .env
      setup: /newbot via @BotFather; one bot per project

`scope`:
  - `global`  — reusable across projects. Looked up in this order:
                1. process env (`os.environ`)
                2. ~/.config/mar/credentials.env (key=value lines)
                3. shell rc files (~/.bashrc, ~/.zshrc) — name presence only
  - `project` — per-project. Looked up in `location` (default: `.env` at the
                repo root, gitignored). Legacy `<service>` placeholders in
                location strings are treated as a no-op (substituted to empty
                string) for backward compatibility with v0.3-era plans.

`location` is informational for `global` scope (the script searches the
documented order above). For `project` scope it is authoritative.

Output:
  - Exit 0 with `all credentials present` on stdout when nothing is missing.
  - Exit 1 with structured JSON on stdout when any are missing:
      {
        "missing": [
          {"name": "TELEGRAM_BOT_TOKEN", "scope": "project",
           "location": "services/myapp-test/.env",
           "setup": "..."},
          ...
        ]
      }
    Caller (orchestrator) parses this and surfaces via AskUserQuestion.

Usage:
  check-credentials.py --session <session-id>
  check-credentials.py --session <session-id> --json   # always JSON output
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SESSIONS = ROOT / "sessions" / "active"
GLOBAL_CRED_FILE = Path.home() / ".config" / "mar" / "credentials.env"
SHELL_RC_FILES = [
    Path.home() / ".bashrc",
    Path.home() / ".zshrc",
    Path.home() / ".profile",
]


def read_session_md(session_id: str) -> tuple[str, dict[str, str]]:
    p = SESSIONS / session_id / "session.md"
    if not p.exists():
        sys.exit(f"check-credentials: session.md not found at {p}")
    text = p.read_text()
    m = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
    fm: dict[str, str] = {}
    if m:
        for line in m.group(1).splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                fm[k.strip()] = v.strip().strip('"').strip("'")
    return text, fm


def find_credentials_block(session_id: str) -> str:
    """Return the §Credentials section from meta-plan.md, or session.md fallback.

    For L/XL sessions, meta-plan-agent populates the block. For S/M sessions
    without a meta-plan, the user (or session-start) may put it directly in
    session.md.
    """
    meta = SESSIONS / session_id / "meta-plan.md"
    candidates = [meta, SESSIONS / session_id / "session.md"]
    for path in candidates:
        if not path.exists():
            continue
        text = path.read_text()
        m = re.search(
            r"^##\s+Credentials\s*\n(.*?)(?=^##\s|\Z)",
            text,
            re.DOTALL | re.MULTILINE,
        )
        if m:
            return m.group(1)
    return ""


def parse_credentials_block(block: str) -> list[dict[str, str]]:
    """Parse the YAML-ish bullet list inside §Credentials.

    Each entry is a `- name: KEY` bullet followed by indented `key: value`
    lines until the next `-` bullet. We don't pull a real YAML parser to keep
    stdlib-only.
    """
    creds: list[dict[str, str]] = []
    current: dict[str, str] | None = None

    for raw in block.splitlines():
        line = raw.rstrip()
        if not line.strip():
            continue
        # New entry?
        m = re.match(r"^\s*-\s*name:\s*(.+?)\s*$", line)
        if m:
            if current and "name" in current:
                creds.append(current)
            current = {"name": m.group(1).strip().strip('"').strip("'")}
            continue
        if current is None:
            continue
        # Continuation field: `  key: value`
        m = re.match(r"^\s+([a-zA-Z_]+):\s*(.+?)\s*$", line)
        if m:
            current[m.group(1).strip()] = m.group(2).strip().strip('"').strip("'")

    if current and "name" in current:
        creds.append(current)

    return creds


def expand_location(loc: str) -> Path:
    # Legacy <service> / {{SERVICE}} placeholders from v0.3-era plans are
    # collapsed to empty string (the framework no longer carries a service
    # axis). Plans written under v0.4+ should use `.env` directly.
    loc = loc.replace("services/<service>/", "").replace("<service>/", "")
    loc = loc.replace("services/{{SERVICE}}/", "").replace("{{SERVICE}}/", "")
    loc = loc.replace("<service>", "").replace("{{SERVICE}}", "")
    if not loc:
        loc = ".env"
    p = Path(loc).expanduser()
    if not p.is_absolute():
        p = ROOT / p
    return p


def env_file_has_key(path: Path, key: str) -> bool:
    """Return True if `path` contains a non-comment line `KEY=...`.

    Never reads or returns the value — only the key's presence is checked.
    """
    if not path.exists():
        return False
    try:
        for raw in path.read_text().splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            # Strip optional `export ` prefix and KEY=VALUE form
            if line.startswith("export "):
                line = line[len("export "):].lstrip()
            if "=" not in line:
                continue
            k = line.split("=", 1)[0].strip()
            if k == key:
                return True
    except OSError:
        return False
    return False


def shell_rc_has_export(key: str) -> bool:
    """Look in ~/.bashrc / ~/.zshrc / ~/.profile for an `export KEY=...` line.

    Only key-name presence is checked.
    """
    for rc in SHELL_RC_FILES:
        if env_file_has_key(rc, key):
            return True
    return False


def is_global_present(name: str) -> bool:
    """Three-way check: process env, global cred file, shell rc files."""
    if os.environ.get(name):
        return True
    if env_file_has_key(GLOBAL_CRED_FILE, name):
        return True
    if shell_rc_has_export(name):
        return True
    return False


def is_project_present(name: str, location: Path) -> bool:
    return env_file_has_key(location, name)


def check_one(cred: dict[str, str]) -> tuple[bool, dict[str, str]]:
    """Return (present, descriptor)."""
    name = cred.get("name", "")
    scope = cred.get("scope", "global").lower()
    location_str = cred.get("location", "")
    setup = cred.get("setup", "")

    if not name:
        return True, {}

    if scope == "global":
        present = is_global_present(name)
        loc_display = location_str or "~/.config/mar/credentials.env or env/shell rc"
    elif scope == "project":
        if not location_str:
            location_str = ".env"
        loc_path = expand_location(location_str)
        present = is_project_present(name, loc_path)
        loc_display = (
            str(loc_path.relative_to(ROOT))
            if loc_path.is_relative_to(ROOT)
            else str(loc_path)
        )
    else:
        # Unknown scope — treat as not-present so the user notices.
        present = False
        loc_display = f"<unknown scope '{scope}'>"

    return present, {
        "name": name,
        "scope": scope,
        "location": loc_display,
        "setup": setup,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Pre-execute credentials gate.")
    ap.add_argument("--session", required=True)
    ap.add_argument("--json", action="store_true", help="Always output JSON")
    args = ap.parse_args()

    read_session_md(args.session)  # validates session exists

    block = find_credentials_block(args.session)
    if not block:
        # No credentials declared — gate trivially passes.
        if args.json:
            print(json.dumps({"missing": [], "all_present": True}))
        else:
            print("no credentials declared in meta-plan/session.md — gate trivially passes")
        return 0

    creds = parse_credentials_block(block)
    if not creds:
        if args.json:
            print(json.dumps({"missing": [], "all_present": True}))
        else:
            print("no credentials parsed from §Credentials block — gate trivially passes")
        return 0

    missing: list[dict[str, str]] = []
    present: list[dict[str, str]] = []
    for c in creds:
        ok, desc = check_one(c)
        if not desc:
            continue
        (present if ok else missing).append(desc)

    if args.json or missing:
        out = {
            "all_present": not missing,
            "missing": missing,
            "present": [{"name": p["name"], "scope": p["scope"]} for p in present],
        }
        print(json.dumps(out, indent=2))
        return 0 if not missing else 1

    print(f"all {len(present)} credentials present")
    return 0


if __name__ == "__main__":
    sys.exit(main())
