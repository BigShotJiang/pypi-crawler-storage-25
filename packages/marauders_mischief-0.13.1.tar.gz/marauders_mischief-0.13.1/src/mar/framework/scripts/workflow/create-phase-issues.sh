#!/usr/bin/env bash
# Create one GitHub issue per phase in the session's meta-plan, in the
# GitHub repo this repo's `origin` remote points at.
#
# Per durable workflow policy:
#   - Issues are session input; PRs are session output.
#   - Issues live in the repo's own GitHub origin remote.
#   - Hard-block on any failure (gh auth, repo missing, issue:write denied).
#
# Resolution flow:
#   1. Pre-flight: `gh auth status`. Refuse if not authenticated.
#   2. Resolve <owner>/<repo> from `git remote get-url origin` at the repo root.
#   3. Pre-flight: `gh repo view <owner>/<repo>` confirms existence + access.
#   4. Pre-flight: probe issue:write via permissions.push; surface PAT scope
#      errors with a clear remediation message.
#   5. For each phase listed in proposed-issue-bodies.md:
#        - Generate per-phase title (from "## phase-N — slug" header)
#        - Use the phase's body section as `--body-file` for `gh issue create`
#        - Append the resulting issue number to session.md (`issues:` field) and
#          to the phase's plan.md frontmatter (`issue:`).
#
# Stdlib bash + gh + python3 (for plan.md frontmatter editing). No deps.
#
# Usage: create-phase-issues.sh --session <session-id>
#        create-phase-issues.sh --session <session-id> --dry-run
set -euo pipefail

SESSION_ID=""
DRY_RUN=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --session) SESSION_ID="$2"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    *) echo "unknown arg: $1" >&2; exit 2 ;;
  esac
done

if [[ -z "$SESSION_ID" ]]; then
  echo "create-phase-issues: --session <id> required" >&2
  exit 2
fi

ROOT="$(git rev-parse --show-toplevel)"
SESSION_DIR="$ROOT/sessions/active/$SESSION_ID"
SESSION_MD="$SESSION_DIR/session.md"
PROPOSED="$SESSION_DIR/proposed-issue-bodies.md"

if [[ ! -f "$SESSION_MD" ]]; then
  echo "create-phase-issues: session.md not found at $SESSION_MD" >&2
  exit 1
fi
if [[ ! -f "$PROPOSED" ]]; then
  echo "create-phase-issues: proposed-issue-bodies.md not found — run /mar:plan to scaffold" >&2
  exit 1
fi

# --- Resolve owner/repo from the repo root's origin remote ------------------

REMOTE_URL="$(git -C "$ROOT" remote get-url origin 2>/dev/null || true)"
if [[ -z "$REMOTE_URL" ]]; then
  echo "create-phase-issues: repo at $ROOT has no 'origin' remote configured" >&2
  echo "  → fix: git remote add origin git@github.com:<owner>/<repo>.git" >&2
  exit 1
fi

# Parse owner/repo from either git@github.com:owner/repo.git or https://github.com/owner/repo(.git)
OWNER_REPO="$(echo "$REMOTE_URL" | sed -E 's#.*github\.com[:/]([^/]+/[^/]+)(\.git)?/?$#\1#' | sed -E 's#\.git$##')"
if [[ -z "$OWNER_REPO" || "$OWNER_REPO" == "$REMOTE_URL" ]]; then
  echo "create-phase-issues: could not parse owner/repo from remote: $REMOTE_URL" >&2
  echo "  → expected git@github.com:<owner>/<repo>.git or https://github.com/<owner>/<repo>(.git)" >&2
  exit 1
fi

# --- Pre-flight: gh auth + repo + write scope -------------------------------

if ! gh auth status >/dev/null 2>&1; then
  echo "create-phase-issues: gh is not authenticated" >&2
  echo "  → fix: gh auth login" >&2
  exit 1
fi

if ! gh repo view "$OWNER_REPO" >/dev/null 2>&1; then
  echo "create-phase-issues: cannot access $OWNER_REPO with current gh auth" >&2
  echo "  → if private: confirm token has access; if fine-grained PAT, add the repo to its allowlist" >&2
  exit 1
fi

# Probe issue:write scope. Listing issues only requires read; the real write
# probe happens at issue creation. Surface the most common failure mode early.
ISSUE_PROBE="$(gh api "repos/$OWNER_REPO" -q .permissions.push 2>/dev/null || echo "false")"
# `permissions.push` proxies write-ish access; not perfect but catches the
# "fine-grained PAT with read-only Issues scope" case fairly well.

# --- Iterate phases ----------------------------------------------------------

# Parse proposed-issue-bodies.md: split on `^## phase-N — <slug>` headers.
# Each section becomes one issue with title "[<phase-id>] <slug>" and body
# the section's content.

PHASE_BODIES_DIR="$(mktemp -d)"
trap 'rm -rf "$PHASE_BODIES_DIR"' EXIT

awk -v out="$PHASE_BODIES_DIR" '
  /^## phase-[0-9]+ — / {
    if (current != "") {
      close(out "/" current ".md")
    }
    sub(/^## /, "", $0)
    header=$0
    split(header, parts, " — ")
    current=parts[1]
    title=parts[2]
    print current "\t" title > out "/_index.tsv"
    next
  }
  /^---\s*$/ { next }   # divider lines between phases
  current != "" {
    print > out "/" current ".md"
  }
' "$PROPOSED"

if [[ ! -f "$PHASE_BODIES_DIR/_index.tsv" ]]; then
  echo "create-phase-issues: no '## phase-N — <slug>' headers found in $PROPOSED" >&2
  exit 1
fi

ISSUES_LINE=""

while IFS=$'\t' read -r PHASE_ID PHASE_TITLE; do
  TITLE="[${PHASE_ID}] ${PHASE_TITLE}"
  BODY_FILE="$PHASE_BODIES_DIR/${PHASE_ID}.md"

  if [[ ! -f "$BODY_FILE" ]]; then
    echo "create-phase-issues: body for $PHASE_ID missing — proposed-issue-bodies.md malformed?" >&2
    exit 1
  fi

  if [[ "$DRY_RUN" -eq 1 ]]; then
    echo "[dry-run] would create: $OWNER_REPO  title=\"$TITLE\"  body-file=$BODY_FILE"
    continue
  fi

  echo "creating issue in $OWNER_REPO: $TITLE"
  if ! ISSUE_URL="$(gh issue create -R "$OWNER_REPO" \
                     --title "$TITLE" \
                     --body-file "$BODY_FILE" 2>&1)"; then
    echo "create-phase-issues: gh issue create failed for $PHASE_ID:" >&2
    echo "$ISSUE_URL" >&2
    if echo "$ISSUE_URL" | grep -qiE '403|not.*accessible|resource.*not.*accessible'; then
      echo "  → fine-grained PAT likely lacks Issues:Write on $OWNER_REPO" >&2
      echo "  → fix: https://github.com/settings/personal-access-tokens — add repo + grant Issues:Write" >&2
    fi
    exit 1
  fi

  # Extract issue number from URL
  ISSUE_NUM="$(echo "$ISSUE_URL" | sed -E 's#.*/issues/([0-9]+).*#\1#')"
  if [[ -z "$ISSUE_NUM" || "$ISSUE_NUM" == "$ISSUE_URL" ]]; then
    echo "create-phase-issues: created but could not parse issue number from: $ISSUE_URL" >&2
    exit 1
  fi

  echo "  → issue #$ISSUE_NUM ($ISSUE_URL)"

  # Append to phase's plan.md frontmatter (if plan exists)
  PLAN_PATH="$SESSION_DIR/phases/$PHASE_ID/plan.md"
  if [[ -f "$PLAN_PATH" ]]; then
    python3 - <<PY "$PLAN_PATH" "$ISSUE_NUM" "$ISSUE_URL"
import sys, re, pathlib
p = pathlib.Path(sys.argv[1])
num, url = sys.argv[2], sys.argv[3]
text = p.read_text()
m = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
if not m:
    sys.exit(0)
fm = m.group(1)
if re.search(r"^issue:\s*", fm, re.MULTILINE):
    fm = re.sub(r"^issue:.*$", f"issue: {num}", fm, flags=re.MULTILINE)
    fm = re.sub(r"^issue_url:.*$", f"issue_url: {url}", fm, flags=re.MULTILINE)
    if not re.search(r"^issue_url:", fm, re.MULTILINE):
        fm += f"\nissue_url: {url}"
else:
    fm += f"\nissue: {num}\nissue_url: {url}"
new_text = f"---\n{fm}\n---\n" + text[m.end():]
p.write_text(new_text)
PY
  fi

  ISSUES_LINE="${ISSUES_LINE:+$ISSUES_LINE, }${PHASE_ID}=#${ISSUE_NUM}"
done < "$PHASE_BODIES_DIR/_index.tsv"

if [[ "$DRY_RUN" -eq 1 ]]; then
  echo "[dry-run] no issues created."
  exit 0
fi

# --- Record on session.md ---------------------------------------------------

# Add `issues:` line to frontmatter (overwrite if present).
python3 - <<PY "$SESSION_MD" "$ISSUES_LINE" "$OWNER_REPO"
import sys, re, pathlib
p = pathlib.Path(sys.argv[1])
issues = sys.argv[2]
repo = sys.argv[3]
text = p.read_text()
m = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
if not m:
    sys.exit(0)
fm = m.group(1)
def upsert(fm, key, value):
    pat = rf"^{re.escape(key)}:\s*.*$"
    if re.search(pat, fm, re.MULTILINE):
        return re.sub(pat, f"{key}: {value}", fm, flags=re.MULTILINE)
    return fm + f"\n{key}: {value}"
fm = upsert(fm, "issues_repo", repo)
fm = upsert(fm, "issues", issues)
new_text = f"---\n{fm}\n---\n" + text[m.end():]
p.write_text(new_text)
PY

echo
echo "all phase issues created in $OWNER_REPO"
echo "session.md updated: issues=$ISSUES_LINE"
