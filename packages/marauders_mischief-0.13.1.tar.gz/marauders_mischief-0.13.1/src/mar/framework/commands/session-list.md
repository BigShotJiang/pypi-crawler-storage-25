---
description: List all active and recently archived sessions.
---

Show active and recent sessions.

## Active

Glob `sessions/active/*/session.md`. For each, read frontmatter and output:

```
<session-id>
  size: <size> | kind: <kind>
  status: <status>
  current: <phase>/<stage>
  started: <date>
  last activity: <date>
```

## Recently archived (last 5)

Glob `sessions/archive/*/session.md`. Read frontmatter. Sort by `last_activity` descending. Take top 5.

```
<session-id>  (archived)
  final size: <size> | kind: <kind>
  ended: <date>
```

## Pointer

Run `bash ops/workflow/scripts/current-session.sh`. On success, show "Current pointer (this window): <id>". On failure, show "No current session pointer in this window." Also list any other per-window pointers (`ls .claude/sessions/pointer-*`) as "Other windows: <count>" so the user sees parallel sessions in sibling CC windows.

Keep output compact. Skim-friendly, not verbose.
