---
description: Audit an archived session (v13). Writes per-session retrospect.md to the session archive; emits framework feedback in chat as paste-ready GitHub Issue bodies.
---

Run a fresh-context post-archive audit. Arguments: $ARGUMENTS (session id, required; optional audit-focus paragraph after).

Usage:
- `/mar:retrospect 2026-04-22-note-indexer-initial-build`
- `/mar:retrospect 2026-04-22-note-indexer-initial-build "focus on between-phase handoffs and artifact consumption"`

## Where retrospect output lives (v13)

The agent does NOT write to any framework-shared file. There is no longer a `test-findings.md`. Two outputs instead:

1. **Per-session file:** `sessions/archive/<id>/retrospect.md` — structured findings with three sections (`## Wins`, `## Session findings`, `## Framework findings`). Lives inside the session archive (already user-private). Useful for the user's own reflection plus a record they can revisit.
2. **Chat-output "ready to file" block:** framework-level findings formatted as GitHub Issue titles + bodies, targeted at `sindreespeland/marauders-mischief`. The framework maintainer copies the entries they want into real issues. External users can ignore the block.

## Step 1 — Parse and validate

1. Extract `<session_id>` (first whitespace-delimited token of `$ARGUMENTS`). Error if missing:
   > Usage: `/mar:retrospect <archived-session-id> [optional-focus-paragraph]`. Run `/mar:session-list` to see archived ids.

2. Extract `<audit_focus>` (rest of `$ARGUMENTS` after the first token). May be empty.

3. Verify `sessions/archive/<session_id>/session.md` exists. If not:
   - Check `sessions/active/<session_id>/session.md` — if there, refuse: "Session is still active. Archive it first with `/mar:session-archive <id>`, then retrospect."
   - Otherwise: "No archived session with id `<session_id>`. Run `/mar:session-list` to see archived sessions."

4. Check whether `sessions/archive/<session_id>/retrospect.md` already exists. If yes, warn:
   > Session `<session_id>` was already retrospected (file exists at sessions/archive/<id>/retrospect.md). Re-run anyway? (yes/no)
   Wait for confirmation. On re-run, the agent overwrites the file with a fresh audit.

## Step 2 — Print breadcrumb

```
[retrospect: <session_id> | stage: → dispatch retrospect-agent]
```

## Step 3 — Dispatch retrospect-agent

Dispatch via Task:
- `subagent_type: retrospect-agent`
- inputs: `session_id` (the argument), `audit_focus` (may be empty).

Agent reads: full archive dir, `ops/workflow/README.md`, all `.claude/commands/mar/*.md`, all `.claude/agents/*.md`, git log/diff scoped to the session, and (if applicable) PR state via `gh pr view`.

Agent writes: `sessions/archive/<session_id>/retrospect.md` with `## Wins`, `## Session findings`, `## Framework findings`, and `## Methodology notes` sections.

## Step 4 — Surface output to user

Show the agent's return verbatim. The agent's chat output is in two parts:

**Part A — Summary** (under 200 words). Finding counts by severity, top 2-3 highlights, the artifact path.

**Part B — Ready-to-file block.** This is the framework feedback channel. It's clearly delimited so users can recognize the boundary:

```
─── FRAMEWORK FEEDBACK (for sindreespeland/marauders-mischief maintainer) ───

[paste-ready GitHub Issue bodies for each framework finding]

─── END FRAMEWORK FEEDBACK ───
```

**For the framework maintainer (`sindreespeland`):** scan the block, copy the entries you want to act on into issues at https://github.com/sindreespeland/marauders-mischief/issues. No automation — manual paste keeps you in the triage loop.

**For external users:** the block is informational. You can ignore it entirely — those findings aren't actionable for your project. Your value is in the per-session `retrospect.md` (session findings + wins).

## Rules

- Do not re-run on an already-audited session without explicit confirmation — retrospect is an expensive agent call.
- Do not modify session archive other than writing `retrospect.md` — other files are immutable.
- Do not write to `.brain/`, `research/`, or any framework-shared location. There is no `ops/workflow/test-findings.md` (removed in v13).
- Retrospect does not gate, approve, or reject anything. It only produces findings.
- Do not automate `gh issue create` against the framework repo — external users won't have auth for `sindreespeland/marauders-mischief`, and the maintainer prefers manual triage.
