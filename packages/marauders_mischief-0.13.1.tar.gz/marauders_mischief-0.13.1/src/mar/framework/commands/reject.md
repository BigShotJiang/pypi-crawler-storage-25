---
description: Reject a gate. Reverts to the prior stage. Usage — /mar:reject <gate>
---

Reject a gate. Arguments: `$ARGUMENTS` (gate name — `research` | `meta-research` | `meta-plan` | `issue-scaffolding` | `plan` | `integrate`).

Reject = discard the artifact and back up to the prior stage. Use `/mar:iterate <gate> "<direction>"` instead if you want to *adjust* without discarding.

## Step 1 — Resolve session

Run `bash ops/workflow/scripts/current-session.sh` to resolve id, then read session.md. Error if the script exits non-zero.

## Step 2 — Confirm intent

Ask user (free-text):

> Reject `<gate>`? This will:
> - `research`: move research artifact aside and re-run research from scratch (interactive prompts for new direction)
> - `meta-research`: move the entire `meta-research/` dir aside (all rounds, all briefings, all human-direction files) and reset to pre-research state. Use when the framing is fundamentally wrong, not just incomplete — use `/mar:iterate meta-research` for refinement.
> - `meta-plan`: discard meta-plan.md and return to meta-research stage
> - `issue-scaffolding`: discard proposed-issue-bodies.md and return to meta-plan stage
> - `plan`: discard the current phase's plan.md (and its derived issue-body.md) and return to research stage for that phase
> - `integrate`: discard INTEGRATION.md and return to verify stage; allows /mar:replan or `/mar:continue` actions
>
> Confirm? (yes/no)

If user wants to refine without discarding, point them at `/mar:iterate <gate> "<direction>"` and stop.

## Step 3 — Act

### research

1. Rename research artifact (`meta-research.md` at meta level, or `phases/<id>/research.md` at phase level) to `<name>.rejected-<timestamp>`.
2. Update session.md: `current_stage: research`, `status: in-progress`.
3. Log timeline.
4. Tell user to run `/mar:plan` again to restart research.

### meta-research

1. Move the entire directory: `meta-research/` → `meta-research.rejected-<timestamp>/`. The whole rounds + briefings + human-direction trail moves together.
2. Update session.md: `current_stage: meta-research`, `status: in-progress`. (Same stage name; the rejected dir is gone and the next `/mar:plan` will start fresh round 1.)
3. Log timeline: `<ts> meta-research rejected (rounds discarded)`.
4. Suggest: "Run /mar:plan to restart meta-research from round 1."

### meta-plan

1. Move the plan + all sidecars in one timestamp sweep (use the same `<ts>`):
   - `meta-plan.md` → `meta-plan.md.rejected-<ts>`
   - `meta-plan-strategy.md` → `meta-plan-strategy.md.rejected-<ts>`
   - `meta-plan-review.md` (if exists) → `meta-plan-review.md.rejected-<ts>`
   - `meta-plan-review-2.md` (if exists) → `meta-plan-review-2.md.rejected-<ts>`
   - `meta-plan-revisions.md` (if exists) → `meta-plan-revisions.md.rejected-<ts>`
2. Update session.md: `current_stage: meta-research`, `status: in-progress`. (The next /mar:plan will re-run Stage 2a from the strategist — synthesis is reused unless meta-research itself is also rejected.)
3. Log timeline: `<ts> meta-plan rejected (plan + strategy + reviews archived)`.

### issue-scaffolding

1. Move `proposed-issue-bodies.md` → `proposed-issue-bodies.md.rejected-<timestamp>`.
2. Update session.md: `current_stage: meta-plan`, `status: awaiting-approval`. The meta-plan re-opens its gate so the user can iterate the meta-plan if the issue scaffolding revealed a problem.
3. Log timeline.

### plan (phase-plan, Stage 2c)

1. Move the plan + all sidecars in one timestamp sweep (use the same `<ts>`):
   - `plan.md` → `plan.md.rejected-<ts>`
   - `plan-review.md` (if exists) → `plan-review.md.rejected-<ts>`
   - `plan-review-2.md` (if exists) → `plan-review-2.md.rejected-<ts>`
   - `plan-revisions.md` (if exists) → `plan-revisions.md.rejected-<ts>`
   - `issue-body.md` → `issue-body.md.rejected-<ts>` (derived view; rejecting plan.md invalidates it)
2. Update session.md: `current_stage: research`, `status: in-progress`. (The next /mar:plan will re-run Stage 2c from the author — research is reused unless research is also rejected.)
3. Log timeline: `<ts> plan rejected (plan + review + issue-body archived)`.

### integrate

1. Rename `INTEGRATION.md` → `INTEGRATION.md.rejected-<timestamp>`.
2. Update session.md: `current_stage: verify`, `status: in-progress`.
3. Suggest `/mar:replan` or `/mar:continue verify "<note>"`.

## Step 4 — Report

State what happened and what to do next.

## Rules

- Never delete artifacts; always rename with `.rejected-<timestamp>` suffix.
- Rejecting a phase's plan also discards the derived issue-body.md — the two must always agree, so reject takes both.
- After reject, the orchestrator does not auto-advance — user decides the next step.
- If the user wanted to refine rather than discard, point them at `/mar:iterate`.
