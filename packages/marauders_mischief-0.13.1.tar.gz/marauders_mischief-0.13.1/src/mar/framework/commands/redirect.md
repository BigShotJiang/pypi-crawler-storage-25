---
description: Pivot the session. Discards plan + research, prepends a new direction to session.md, restarts from meta-research round 1. Preserves session id and .brain links. Replaces /mar:replan. Usage — /mar:redirect "<new direction>"
---

Pivot the session in a new direction without abandoning it. The session id, `.brain/` ties, and configuration (autonomy / size / kind / roles / guidance) all stay; only the research + plan are discarded and the goal description is rewritten.

This replaces `/mar:replan` (deprecated for one minor version, then removed).

Arguments: `$ARGUMENTS` — optional `<new direction>` text. If omitted, behaves like the old `/mar:replan` (full reset, no new direction prepended).

## Valid scope

`/mar:redirect` is valid at:
- The **meta-research gate** — if early review of the briefing reveals the session itself is mis-framed.
- The **meta-plan gate** — if the plan reveals the session itself is mis-framed.

It is **not valid** after Stage 2b (issue scaffolding has run). Once issues exist, redirecting would orphan them. To end such a session, use `/mar:stop` and start a new one.

If invoked from any other gate, error: "/mar:redirect is only valid at meta-research or meta-plan gates. After Stage 2b, redirect would orphan created issues — use /mar:stop and /mar:session-start a new session instead."

## Step 1 — Parse

Strip surrounding quotes from `$ARGUMENTS` to recover `<new direction>` (may be empty).

## Step 2 — Resolve session and validate gate

Run `bash ops/workflow/scripts/current-session.sh` to resolve id; read `sessions/active/<id>/session.md`. Error if no session.

Validate `current_stage` is one of:
- `meta-research` (briefing gate is open)
- `meta-plan`

For any other stage, refuse with the message above.

## Step 3 — Confirm with the user

This is destructive. Confirm before acting:

> Redirect session `<id>`?
>
> This will:
> - Move `meta-research/` → `meta-research.rejected-<ts>/` (all rounds, briefings, syntheses, human-direction files)
> - Move `meta-plan.md` and its sidecars → `<file>.rejected-<ts>` (if they exist)
> - Update session.md's `## Why` block: prepend the new direction (if provided) under `### Current direction (<ts>)`; move existing description under `### Previous direction (<original-ts>)`
> - Reset `current_stage: meta-research`, `status: in-progress`
> - Preserve: session id, kind, roles, size, guidance, autonomy, service, timeline, started timestamp, `.brain/` references
>
> New direction: `<new direction or "none — full reset, no new direction">`
>
> Confirm? (yes/no)

If the user replies anything other than `yes`, abort with no changes.

## Step 4 — Archive meta-research and meta-plan artifacts

In one timestamp sweep (same `<ts>` for grouping):
- `mv meta-research meta-research.rejected-<ts>` (entire directory)
- `mv meta-plan.md meta-plan.md.rejected-<ts>` (if exists)
- `mv meta-plan-strategy.md meta-plan-strategy.md.rejected-<ts>` (if exists)
- `mv meta-plan-review.md meta-plan-review.md.rejected-<ts>` (if exists)
- `mv meta-plan-review-2.md meta-plan-review-2.md.rejected-<ts>` (if exists)
- `mv meta-plan-revisions.md meta-plan-revisions.md.rejected-<ts>` (if exists)
- For non-existent files, no-op.

Use the framework's standard rename (do not delete — audit trail).

## Step 5 — Rewrite session.md's `## Why` block

Read the existing `## Why` block. Identify the original `started:` timestamp from session.md frontmatter (call it `T0`).

Rewrite the block:

```markdown
## Why

### Current direction (<now-ts>)

<new direction text — if empty, write "<full reset, no new direction provided>">

### Previous direction (T0)

<the existing ## Why block content, preserved verbatim>
```

If the existing `## Why` already has a `### Previous direction` block (i.e. this is a second redirect), preserve all previous entries — append the now-previous current as another `### Previous direction (<previous-current-ts>)` block. The most recent direction is always at the top under `### Current direction`.

## Step 6 — Reset session state

Update session.md frontmatter:
- `current_stage: meta-research`
- `status: in-progress`
- `current_phase: null` (if it was set)
- `last_activity: <now-ts>`

Append timeline entry: `<ts> redirected — <new direction or "full reset">`.

## Step 7 — Report

Print a single-block summary:

```
Session redirected: <id>
  Previous direction archived under ### Previous direction (T0)
  Current direction: <new direction or "full reset, no new direction">
  Artifacts archived with suffix .rejected-<ts>
  current_stage: meta-research → run /mar:plan to begin fresh meta-research

Preserved: kind, roles, size, guidance, autonomy, service, .brain references
```

## Rules

- **Never deletes.** Artifacts always renamed with `.rejected-<ts>` (matching reject.md / revise.md conventions).
- **Session id stays.** Tags, .brain references, retrospect targets continue to work.
- **Configuration stays.** kind, roles, size, guidance, autonomy, service — none of these are invalidated by a direction change.
- **Goal slug stays.** The frontmatter `goal:` slug is not updated. If the new direction implies a dramatically different goal, the user can edit session.md manually — but the framework treats redirect as a framing pivot, not a rename.
- **Empty redirect is allowed.** `/mar:redirect` (no argument) is the closest equivalent to the old `/mar:replan` — discard plan + research, no new direction, restart from scratch.
- **After redirect, the next /mar:plan starts meta-research round 1.** Same flow as a brand-new L/XL session.

## Hard rules

- If `current_stage` is past `meta-plan` (i.e. `issue-scaffolding`, `plan`, `execute`, etc.), refuse — issues may already exist.
- The session.md `## Why` rewrite MUST preserve the previous direction (audit trail). The frontmatter `started:` timestamp stays at the original session start, not the redirect time.
