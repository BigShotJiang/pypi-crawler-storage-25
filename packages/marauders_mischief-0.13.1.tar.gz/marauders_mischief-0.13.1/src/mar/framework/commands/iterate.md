---
description: Apply free-text direction to a gate without losing position. Auto-regenerates plan + derived issue-body. Usage — /mar:iterate <gate> "<direction>"
---

Apply a directional adjustment at a gate. Distinct from `/mar:continue` (re-runs a stage as-is) and `/mar:replan` (discards and restarts). Iterate refines in place.

Arguments: `$ARGUMENTS` — expected format `<gate> "<direction>"`. Examples:

- `/mar:iterate research "go deeper on the OpenAI Whisper streaming API limits"`
- `/mar:iterate plan "tighten the error-handling story — surface to user, don't retry"`
- `/mar:iterate meta-plan "split phase 2 into separate ingestion + indexing phases"`

## Step 1 — Parse

Split into `<gate>` (first token) and `<direction>` (rest, trim quotes).

Valid gates: `research`, `meta-research`, `meta-plan`, `plan`, `integrate`.

**Note**: `issue-scaffolding` (Stage 2b) is *not* directly iterable. To adjust proposed issue bodies, iterate the source: phase 1's body comes from phase 1's plan (use `/mar:iterate plan`); later phases' stub bodies come from the meta-plan (use `/mar:iterate meta-plan`). The body is always a view of something canonical.

If parsing fails or gate is invalid, error with usage and stop.

## Step 2 — Resolve session

Run `bash ops/workflow/scripts/current-session.sh` to resolve id, then read `sessions/active/<id>/session.md`. Error if no session.

## Step 3 — Validate gate state

The session must be currently sitting at the named gate (status `awaiting-approval`, `current_stage` matches). Iterate is only valid at an open gate — it doesn't restart a closed one (use `/mar:replan` for that).

If the session isn't paused at this gate, refuse:
> Cannot iterate `<gate>` — session is at stage `<current_stage>`, status `<status>`. Use `/mar:continue <stage> "<note>"` to add direction to a running stage, or `/mar:replan` to discard the current artifact and restart.

## Step 4 — Route the direction

Each gate routes differently. The principle is the same: regenerate the canonical artifact (plan.md / meta-plan.md / INTEGRATION.md), then re-derive any downstream views.

### `research`

User wants more or different research before approving the plan.

1. Print breadcrumb: `[session: <id> | stage: research → iterate (round <n+1>)]`.
2. Dispatch `research-agent` with:
   - level: matches what was originally produced (`meta` or `phase`)
   - inputs: session_id, (phase_id if phase level), goal, scope_hint
   - **`additional_direction: <direction>`** — agent **appends** to existing research.md (does not overwrite raw findings).
3. After research-agent returns, re-dispatch `plan-agent` (`meta-plan-agent` or `phase-plan-author-agent` to match level) — it must regenerate plan.md from the updated research.
4. **Re-derive issue-body** if a phase plan was regenerated:
   ```bash
   python3 ops/workflow/scripts/derive-issue-body.py --session <id> --phase <phase-id>
   ```
   On non-zero exit → **halt** with the script's stderr verbatim. Do not advance.
5. Update session.md timeline: `<ts> iterate research — <direction>`. Reset `status: awaiting-approval`, hold at plan gate.
6. Show the standard plan-gate message (see `/mar:plan` Step 7).

### `meta-research`

User wants more or different perspectives before the meta-plan is drafted. Iterate triggers a **round 2** of role-research, targeted to the roles named in `briefing-N.md`'s "Roles that need a round 2" section (or all active roles if direction is broad).

1. Print breadcrumb: `[session: <id> | stage: meta-research → iterate (round <n+1>)]`.
2. Determine current round `N` from existing `meta-research/briefing-<N>.md`. New round = `N+1`.
3. Capture the user's direction:
   - Write `meta-research/human-direction-<N>.md` with the verbatim `<direction>` string and a timestamp. This preserves the audit trail and feeds `final-synthesis` later.
4. Decide which roles to re-dispatch:
   - Default: roles listed under "Roles that need a round 2" in `briefing-<N>.md`.
   - If direction explicitly names roles (e.g. "deeper on prior-art"), use those.
   - Skeptic always re-runs in round 2 (it reads whatever changed).
5. Dispatch the chosen roles **in parallel** (except skeptic) via Task:
   - For each role-agent in the parallel wave: pass `round=<N+1>`, `additional_direction=<direction>`, `prior_output_path=meta-research/round-<N>/<role>.md`.
   - Each writes to `meta-research/round-<N+1>/<role>.md`.
6. After the parallel wave completes, dispatch `skeptic-research-agent` with `round=<N+1>` and `other_role_outputs` pointing at the new round files (plus prior-round files for roles that didn't re-run).
7. Dispatch `meta-research-orchestrator-agent` via Task:
   - `mode: briefing`, `round=<N+1>`, `roles` (from session.md)
   - Writes `meta-research/briefing-<N+1>.md`.
8. **Iterate cap check**: if `N+1 > 3`, surface a hint to the user: "This is iterate #3 on the meta-research gate. Consider `/mar:reject meta-research` for a fresh path, or `/mar:approve meta-research` to lock in current framing." Do not auto-block — the cap from the workflow spec is 2 standard + 1 with override; the hint covers the override case.
9. Update session.md timeline: `<ts> iterate meta-research — <direction> (round=<N+1>)`. Reset `status: awaiting-approval`, hold at meta-research gate.
10. Show the standard meta-research-gate message (see `/mar:plan` Step 7).

### `meta-plan`

User wants to adjust the plan. In v4, iterate runs the **author in iterate mode** with the user's direction, then re-runs the **skeptic** (fresh round 1) since the plan has changed. The skeptic counter resets — `/mar:iterate meta-plan` starts a new internal review loop, not a continuation of any prior one.

1. Print breadcrumb: `[session: <id> | stage: meta-plan → iterate]`.
2. **Archive stale skeptic artifacts.** Move (if present) to `.iterated-<ts>`:
   - `meta-plan-review.md` → `meta-plan-review.md.iterated-<ts>`
   - `meta-plan-review-2.md` → `meta-plan-review-2.md.iterated-<ts>`
   - `meta-plan-revisions.md` → `meta-plan-revisions.md.iterated-<ts>`
   These will be regenerated by the new skeptic round. Use a single `<ts>` for the sweep.
3. Dispatch `meta-plan-author-agent` via Task:
   - inputs: `session_id`, `goal`, `size`, `guidance`, `synthesis_path`, `strategy_path`, `mode: iterate`
   - **`additional_direction: <direction>`**
4. If the author returns `{"strategy_change_requested": true, "requested_strategy": "<name>"}`:
   - Re-dispatch `meta-plan-strategist-agent` with `additional_direction: <direction>` so the strategist rewrites `meta-plan-strategy.md` for the requested strategy.
   - Re-dispatch the author in `draft` mode against the new strategy.
   - Continue to step 5.
5. Dispatch `meta-plan-skeptic-agent` via Task (round 1, fresh):
   - inputs: `session_id`, `plan_path`, `synthesis_path`, `strategy_path`, `round: 1`
   - output: new `meta-plan-review.md`.
6. Read the verdict from `meta-plan-review.md`:
   - `verdict: approve` → continue to step 7 (fire gate).
   - `verdict: request-changes` → re-enter the internal refine loop (Step 6.2a.4 in `/mar:plan`). The user has effectively kicked off a fresh internal review.
7. **Step 2 (deferred — GitHub)**: if any phase issues already exist, regenerate their issue bodies via `derive-issue-body.py` per phase and `gh issue edit` per phase. In Step 1 (no GitHub), if any phase plans exist as files, re-derive their `issue-body.md`.
8. Update session.md timeline: `<ts> iterate meta-plan — <direction>` (and any strategy-change notes). Hold at meta-plan gate.
9. Show the 4-option meta-plan gate menu (see `/mar:plan` Step 7 for 2a).

### `plan`

User wants to adjust the current phase plan. In v6, iterate runs the **author in iterate mode** with the user's direction, then re-runs the **skeptic** (fresh round 1) since the plan changed. The skeptic counter resets — `/mar:iterate plan` starts a new internal review loop, not a continuation of any prior one.

1. Print breadcrumb: `[session: <id> | phase: <phase-id> | stage: plan → iterate]`.
2. **Archive stale skeptic artifacts.** Move (if present) to `.iterated-<ts>`:
   - `plan-review.md` → `plan-review.md.iterated-<ts>`
   - `plan-review-2.md` → `plan-review-2.md.iterated-<ts>`
   - `plan-revisions.md` → `plan-revisions.md.iterated-<ts>`
   Use a single `<ts>` for the sweep.
3. Dispatch `phase-plan-author-agent` via Task:
   - inputs: `session_id`, `phase_id`, `goal`, `size`, `guidance`, `research_path`, `meta_plan_path` (if exists), `mode: iterate`
   - **`additional_direction: <direction>`**
4. If the author returns `{"strategy_change_requested": true, "requested_strategy": "<name>"}`:
   - Re-dispatch `phase-plan-author-agent` with `mode: draft` and the new strategy direction baked into `additional_direction`.
5. Dispatch `phase-plan-skeptic-agent` round 1 (fresh):
   - inputs: `session_id`, `phase_id`, `plan_path`, `research_path`, `meta_plan_path`, `round: 1`
   - output: new `plan-review.md`
6. Read the verdict:
   - `verdict: approve` → continue to step 7 (re-derive + fire gate).
   - `verdict: request-changes` → re-enter the internal refine loop (Step 6.2c.3 in `/mar:plan`).
7. **Re-derive issue-body** — mandatory:
   ```bash
   python3 ops/workflow/scripts/derive-issue-body.py --session <id> --phase <phase-id>
   ```
   On non-zero exit → **halt** with stderr verbatim. The plan and the issue must agree.
8. **Re-derive pr-body and sync PR** (v12) — mandatory if a PR has been opened for this phase. Check `phases/<phase-id>/plan.md` frontmatter for a `pr:` field. If present:
   ```bash
   python3 ops/workflow/scripts/derive-pr-body.py --session <id> --phase <phase-id>
   gh pr edit <pr_number> --body-file sessions/active/<id>/phases/<phase-id>/pr-body.md
   ```
   On non-zero exit from either step → **halt**, fire `gh-pr-failure hit` safeguard, surface stderr verbatim. The plan and the PR body must agree. If no `pr:` field on plan frontmatter (PR not yet opened — iterate happens at the plan gate before Stage 2.2), skip silently.
9. Update session.md timeline: `<ts> iterate plan — <direction>`. Hold at plan gate.
10. Show the 5-option phase plan gate menu (see `/mar:plan` Step 7 for 2c).

### `integrate`

User wants to adjust the integration story (commit message, writeback proposals).

1. Print breadcrumb: `[session: <id> | stage: integrate → iterate]`.
2. Dispatch `integrate-agent` with:
   - inputs: session_id (and the same context integrate normally gets)
   - **`additional_direction: <direction>`**
3. Agent regenerates `INTEGRATION.md`.
4. Hold at integrate gate.
5. Show the standard integrate-gate message.

## Step 5 — Hold and report

Across every gate, the iterate flow ends at the same gate it started at — never advances. The user sees the regenerated artifact and decides:

- `/mar:approve <gate>` — accept and advance.
- `/mar:iterate <gate> "<more direction>"` — refine again.
- `/mar:reject <gate>` — discard and revert to prior stage.
- `/mar:replan` — full restart of planning for the current scope.

## Hard rules

- Iterate **never** skips a gate. After iterate, the same gate is open again until the user approves.
- If `derive-issue-body.py`, `derive-pr-body.py`, or any `gh` command (issue edit / pr edit) fails, the iterate command **hard-blocks** and fires `gh-pr-failure hit` (v12) for the gh failures. The plan, the issue, and the PR body must all agree, or we don't move. Surface the error verbatim and stop.
- Iterate **never hand-edits** issue-body.md, the GitHub issue body, pr-body.md, or the GitHub PR body. Those are derived. Iterate regenerates plan.md (or meta-plan.md / INTEGRATION.md) and re-runs the derivation pipeline.
- Iterate respects the same scope hook as execute — the agent cannot drift outside plan scope.

## Rules

- `/mar:iterate` is the refinement tool with new direction. `/mar:continue` is the refinement tool *without* new direction (re-runs as-is). `/mar:replan` is the reset tool (discards artifacts).
- For research iterate: appended raw findings preserve the audit trail. Plan re-derivation guarantees the plan reflects current state, not stale notes.
- An iterate count > 3 on the same gate without approval is a smell — surface a hint: "This is iterate #4 on the plan gate. Consider `/mar:reject plan` to take a fresh path, or check whether the underlying goal needs revisiting."
