---
description: Run integrate-agent to compose the commit story and propose .brain/ writebacks. Pauses for /mar:approve integrate (which performs the squash merge).
---

Run the integration stage for the current session.

## What integrate does (and does NOT)

integrate-agent **composes** the final commit story and proposes `.brain/` writebacks. It does NOT push, create the PR, or merge. The PR was already opened at Stage 2.2 in `/mar:ship` (v12); the merge happens at `/mar:approve integrate` via `gh pr merge --squash`. This separation matches the approval pattern across all four autonomy modes — autonomous just auto-runs the approve step.

## Step 1 — Preconditions

1. Run `bash ops/workflow/scripts/current-session.sh`. Error if it exits non-zero.
2. Read session.md. Error if `current_stage` ≠ `integrate` OR if there's no verified phase.
3. Verify each phase has a `summary.md` and `verification.md`. Error if any missing — direct user to /mar:ship first.

## Step 2 — Dispatch

Dispatch `integrate-agent` via Task:
- inputs: session_id, service_type (`scratch` | `real`)
- agent reads: session.md, meta-plan.md (if exists), every phase summary + verification, current git diff, the PR number from the phase's plan.md frontmatter (for the `Closes #<issue>` reference)
- agent writes: `INTEGRATION.md` — composed commit message (subject + body). For autonomous sessions, the agent must NOT include `.brain/` writebacks (they are skipped entirely).

## Step 3 — Pause for approval (all modes)

After integrate-agent returns, the session sits at the integrate gate waiting for `/mar:approve integrate` to fire the squash merge.

### `interactive` / `normal` / `streamlined` — gate (pause)

Read and show the produced INTEGRATION.md inline (not just a path). User must review the commit message and any writeback proposals before approving.

Report and pause:

```
Integration artifact: sessions/active/<id>/INTEGRATION.md
PR: #<pr_number> (<pr_url>) — currently draft

Commit message preview:
  <first line>

Writebacks proposed: <count>
  <target-file>: <short>
  <target-file>: <short>

Review the file, then:
  /mar:approve integrate    → squash-merge PR + apply approved writebacks
  /mar:iterate integrate "<note>"  → re-run integrate-agent with direction
  /mar:reject integrate     → discard INTEGRATION.md and return to verify stage
```

Update session.md: `status: awaiting-approval`, `last_activity: now`. Stop.

### `autonomous` — auto-approve

Log timeline: `<ts> autonomous auto-approving integrate`. Inline-dispatch `/mar:approve integrate`'s integrate-gate logic (see `approve.md` → `integrate` action). The merge fires automatically; `.brain/` writebacks are not applied (per v2 spec).

Same hard-blocks apply: `mergeStateStatus` must be `CLEAN`; any `gh` failure fires `gh-pr-failure hit` and stops.

Report on success:
```
[session: <id> | stage: integrate (autonomous complete)]
PR #<pr> squash-merged: <merge-commit-sha>
Next: /mar:session-archive to close.
```

## Rules

- integrate-agent never merges, never pushes, never creates PRs. It composes only.
- The merge fires at `/mar:approve integrate` (orchestrated by `approve.md`), not here.
- Never write to `.brain/` during autonomous integrate. Human-curated only.
- Never bundle multiple sessions into one commit. One session → one PR per phase → one squash-merged commit per phase.
