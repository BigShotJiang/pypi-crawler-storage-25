---
description: Pass a gate (research | meta-plan | issue-scaffolding | plan | integrate). Usage — /mar:approve <gate>
---

Pass a gate. Arguments: `$ARGUMENTS` (gate name).

Valid gates: `research`, `meta-research`, `meta-plan`, `issue-scaffolding`, `plan`, `integrate`.

Each gate is **3-way** in v2/v3: approve (this command) / iterate (`/mar:iterate <gate> "<direction>"`) / reject (`/mar:reject <gate>`).

## Step 1 — Resolve session and validate

Run `bash ops/workflow/scripts/current-session.sh` to resolve id, then read session.md.

- `research` → status must be `awaiting-approval`, current_stage `research-review`. Phase-level research gate (interactive mode only).
- `meta-research` → status `awaiting-approval`, current_stage `meta-research`, `meta-research/briefing-<N>.md` must exist. L/XL only (v3 mid-research gate).
- `meta-plan` → status `awaiting-approval`, current_stage `meta-plan` (a.k.a. Stage 2a output gate).
- `issue-scaffolding` → status `awaiting-approval`, current_stage `issue-scaffolding` (a.k.a. Stage 2b). Only valid for L/XL sessions.
- `plan` → status `awaiting-approval`, current_stage `plan` (a.k.a. Stage 2c, phase plan).
- `integrate` → status `awaiting-approval`, current_stage `integrate`, INTEGRATION.md must exist.

If preconditions fail, error stating which condition was not met.

## Step 2 — Act by gate

### research

1. Update session.md: `status: in-progress`, advance `current_stage` to `plan` (the planning sub-stage that follows research at this level). Timeline: `<ts> research approved`.
2. Re-enter `/mar:plan`'s Step 6 (run plan-agent — `meta-plan-author-agent` for meta level, `phase-plan-author-agent` for phase level). Do NOT re-run research.
3. Report: "Research approved. Running plan-agent next."

### meta-research (v3 mid-research gate — L/XL only)

The user has reviewed the latest `briefing-N.md` and is approving the meta-research stage as complete. The next step is **final synthesis**, then meta-plan-agent.

1. Determine the active round `N` from `meta-research/briefing-<N>.md` (the most recent).
2. Dispatch `meta-research-orchestrator-agent` via Task:
   - `mode: final-synthesis`
   - `session_id`, `goal`, `kind`, `roles` (from session.md)
   - `human_direction_paths`: any `meta-research/human-direction-*.md` files on disk
3. Verify `meta-research/synthesis.md` exists after the agent returns. If missing, halt with an error — do not advance.
4. **Autonomous-mode safeguard**: parse `synthesis.md` for `[QUESTION]` marks. If any remain unresolved AND the session's `autonomy` is `autonomous`, halt with the unresolved-question safeguard message. (In interactive/normal/streamlined, this approve is the user's explicit "ship it" — questions can survive into meta-plan as `[QUESTION]` marks there.)
5. Update session.md: `status: in-progress`, advance `current_stage` to `meta-plan`. Timeline: `<ts> meta-research approved (synthesis written, rounds=<N>)`.
6. Report: "Meta-research approved. Synthesis at `meta-research/synthesis.md`. Run /mar:plan to draft the meta-plan."

### meta-plan (Stage 2a — L/XL only)

1. Update session.md: `status: in-progress`, advance `current_stage` to `issue-scaffolding`. Timeline: `<ts> meta-plan approved`.
2. The next `/mar:plan` invocation will run Stage 2b (orchestrator derives proposed issue bodies).
3. Report: "Meta-plan approved. Run /mar:plan to proceed to issue scaffolding (Stage 2b)."

### issue-scaffolding (Stage 2b — L/XL only)

1. Update session.md: `status: in-progress`, advance `current_stage` to `plan` (Stage 2c — phase plan for phase 1, or whichever current_phase is set to). Timeline: `<ts> issue-scaffolding approved (Step 1 local preview)`.
2. **Step 1 (current)**: this is a sanity-check approval; no real GitHub issues are created yet. The `proposed-issue-bodies.md` file is recorded as approved.
3. **Step 2 (deferred)**: this approve will trigger `gh issue create` per phase. **Hard-block on any gh failure** — do not advance until issues exist.
4. Set `current_phase: phase-1` (or first phase from meta-plan) if not already set.
5. The next `/mar:plan` runs Stage 2c for the current phase.
6. Report: "Issue scaffolding approved. Run /mar:plan to draft the phase plan."

### plan (Stage 2c — phase plan)

1. Mark plan's `## Definition of Done` as user-approved (any unticked items get a session-timeline note: "User force-approved plan with N unchecked DoD items").
2. Update session.md: `status: in-progress`, advance `current_stage` to `execute`. Timeline: `<ts> plan approved (phase=<id>)`.
3. Report: "Plan approved. Run /mar:ship to execute."

### integrate (v12 — PR-native squash merge)

1. Read INTEGRATION.md. It carries the composed commit message and (non-autonomous only) the proposed `.brain/` writebacks. integrate-agent does NOT merge — `/mar:approve integrate` does.
2. For each proposed `.brain/` writeback, ask the user per-entry (via AskUserQuestion) — accept / reject / edit. Apply accepted entries per CLAUDE.md writeback protocol. (Autonomous sessions never produce writebacks, so this step is no-op for them.)
3. Read the phase's `pr` number from `phases/<current_phase>/plan.md` frontmatter. This was populated at Stage 2.2 by `create-phase-pr.sh`. If `pr:` is missing (older session that pre-dates v12, or scratch-service session without a PR), fall back to the legacy local-commit path described in §Legacy fallback below.
4. **Pre-flight the merge:**
   ```bash
   gh pr view <pr> --json mergeStateStatus,state,mergeable -q '"\(.state) \(.mergeable) \(.mergeStateStatus)"'
   ```
   - Required: `state == OPEN`, `mergeable == MERGEABLE`, `mergeStateStatus == CLEAN`.
   - If `mergeStateStatus` is `BEHIND`, `DIRTY`, or `UNSTABLE`: surface to user with the specific status and remediation hint (rebase, resolve conflicts, wait for CI). Fire `gh-pr-failure hit` safeguard. Stop.
   - If `mergeable == CONFLICTING`: same — stop, do not attempt merge.
5. **Mark PR ready for review** (so it's not a draft when the merge fires):
   ```bash
   gh pr ready <pr>
   ```
   Hard-block on failure → `gh-pr-failure hit`.
6. **Squash merge** with the composed commit story from INTEGRATION.md. Parse INTEGRATION.md for the `## Commit message` section; the first line is the subject, the rest is the body.
   ```bash
   gh pr merge <pr> --squash \
     --subject "<commit subject from INTEGRATION.md>" \
     --body-file <(<extracted commit body>)
   ```
   Alternatively, use `--body "<inlined body>"` if shell heredoc is cleaner. Hard-block on failure → `gh-pr-failure hit`.
7. Update `session.md`: `status: integrated`. Update the phase's `plan.md` frontmatter `pr_state: merged`.
8. Offer to archive: "Session integrated. PR #<pr> squash-merged. Archive now with /mar:session-archive?"

#### Legacy fallback (no PR exists for this phase)

If the phase has no `pr:` frontmatter (pre-v12 session, or service_type=`scratch` without a PR), fall back to the Step-1-local commit:
- Stage plan-scoped files + session artifacts (never `sessions/active/*/phases/*/progress.md` — gitignored).
- Commit locally with the message from INTEGRATION.md.
- Tell the user: "Committed locally. Open and merge the PR manually if you want one — `/mar:approve integrate` skips the merge when no PR is registered on the phase."

#### Autonomous mode

Autonomous skips the user-facing writeback approval (no writebacks proposed) and runs steps 3–8 inline. Same hard-blocks. Same `gh-pr-failure hit` semantics.

## Rules

- Never merge a PR without the user having seen INTEGRATION.md. If `/mar:approve integrate` is run too fast (no INTEGRATION.md generated yet), show it first and confirm.
- The squash merge fires only after `mergeStateStatus: CLEAN` is confirmed. Don't override.
- Push to remote happens via the PR's existing branch (already pushed during build); `/mar:approve integrate` itself does not run `git push` — it triggers `gh pr merge`, which handles the merge server-side.
- If a writeback entry targets `.brain/PEOPLE.md`, refuse — that file is gitignored.
- Approve never bypasses scope hooks or always-on safeguards.
