---
description: Run research + plan for the current session's current sub-stage. v3 expands Stage 2a with multi-role meta-research before meta-plan. Pauses at the current gate.
---

Run the planning pipeline for the current session. Optional free-text direction can be passed inline: `/mar:plan "<extra direction for research>"`.

In v3, L/XL planning runs through:
- **Meta-research** (multi-role, parallel) → briefing → gate
- **Stage 2a** — meta-plan (consumes the synthesis)
- **Stage 2b** — issue scaffolding
- **Stage 2c** — phase plan (per phase)

Each step has its own 3-way gate (approve / iterate / reject). `/mar:plan` advances whichever sub-stage is current. The user typically runs `/mar:plan` multiple times across an L/XL session as they pass each gate.

S/M sessions skip meta-research, 2a, and 2b entirely — they go straight to 2c.

## Step 1 — Resolve current session

Run `bash ops/workflow/scripts/current-session.sh` to resolve the session id. If it exits non-zero, error: "No current session. Use /mar:session-start or /mar:session-resume."

Read `sessions/active/<id>/session.md`.

## Step 2 — Decide which sub-stage is current

Based on `size` and the artifacts on disk:

| Size | synthesis.md | meta-plan.md | proposed-issue-bodies.md | current phase plan.md | Sub-stage to run |
|---|---|---|---|---|---|
| S / M | n/a | n/a | n/a | absent | **2c** (phase plan, single phase `01-main`) |
| S / M | n/a | n/a | n/a | exists, gate not approved | hold at 2c gate |
| L / XL | absent | — | — | — | **meta-research** (multi-role; round 1 or briefing) |
| L / XL | exists | absent | — | — | **2a** (meta-plan) |
| L / XL | exists | exists | absent | — | **2b** (issue scaffolding) |
| L / XL | exists | exists | exists | absent for current phase | **2c** (phase plan) |
| L / XL | exists | exists | exists | exists, gate approved, more phases pending | **2c** (next phase's plan) |

If a gate is currently `awaiting-approval`, `/mar:plan` reports the gate state and tells the user to approve / iterate / reject. It does not advance.

The meta-research sub-stage has its own internal artifact sequence; see Step 4a for the within-stage decision tree.

## Step 3 — Collect extra direction (pre-research input)

This step fires for sub-stages that run research first (meta-research at L/XL; phase research at 2c). For 2a, 2b, and 2c-after-research (which are derivations or planning), skip to Step 6.

Collect any user-supplied extra direction to feed into the research agents. Precedence:

1. **$ARGUMENTS** (if present) — use as-is.
2. **Interactive prompt** — fires only when `autonomy: interactive` AND no $ARGUMENTS:
   > Research is about to run for `<level>: <phase-id-or-"meta">`. Any direction beyond what's in `session.md`? Reply with a short paragraph, or `skip` to proceed with no extra direction.
3. **`normal` / `streamlined` / `autonomous`** — no prompt. Proceed with none unless $ARGUMENTS was passed.

Store as `pre_research_direction`.

## Step 4a — Run meta-research (L/XL only)

Within meta-research there's an internal sequence. Determine where we are by inspecting artifacts under `sessions/active/<id>/meta-research/`:

| meta-research/ state | Action |
|---|---|
| absent | Dispatch round 1 (parallel role-agents → skeptic → orchestrator briefing). |
| `round-1/` exists, `briefing-1.md` missing | Dispatch the orchestrator in briefing mode for round 1 (the parallel wave already ran). |
| `briefing-N.md` exists, no `human-direction-N.md`, no `round-N+1/` | At the gate — see Step 4a.gate. |
| `human-direction-N.md` exists, `round-N+1/` missing | Iterate already accepted; round N+1 is owed. Handled by `/mar:iterate meta-research`, not by `/mar:plan`. Refuse and surface that hint. |
| `synthesis.md` exists | Meta-research is done. Skip to Step 6 (Stage 2a). |

Print breadcrumb:
```
[session: <id> | size: <size> | kind: <kind> | autonomy: <mode> | stage: → meta-research (round 1)]
```

### Step 4a.1 — Round 1 dispatch

Read `roles:` from session.md (comma-separated list set at session-start). Split into the active roster.

**Wave 1 (parallel):** for every role in the roster **except `skeptic`**, dispatch the corresponding agent via Task in a single message (multiple Task calls in one assistant turn → parallel execution):

| Role string | Agent name |
|---|---|
| `product` | `product-research-agent` |
| `domain` | `domain-research-agent` |
| `prior-art` | `prior-art-research-agent` |
| `ux` | `ux-research-agent` |
| `ops` | `ops-research-agent` |

Common inputs to every wave-1 agent: `session_id`, `goal` (from session.md), `kind`, `round: 1`, `pre_research_direction` (if any, passed as `additional_direction`).

Wait for all wave-1 tasks to complete. Each must have written `meta-research/round-1/<role>.md`.

**Wave 2 (skeptic only):** dispatch `skeptic-research-agent` via Task with:
- `session_id`, `goal`, `kind`, `round: 1`
- `other_role_outputs`: the paths of all wave-1 outputs.

Verify `meta-research/round-1/skeptic.md` exists.

### Step 4a.2 — Orchestrator briefing (round 1)

Dispatch `meta-research-orchestrator-agent` via Task:
- `mode: briefing`
- `round: 1`
- `session_id`, `goal`, `kind`, `roles` (the active roster)

Verify `meta-research/briefing-1.md` exists.

### Step 4a.gate — Mid-research gate

Branch by autonomy:

- **`interactive` / `normal`**: gate fires unconditionally.
- **`streamlined`**: read `briefing-N.md`. If both the `## Tensions` and `## Open questions for the human` sections are empty (or contain only `<none>`), auto-pass: dispatch the orchestrator in `final-synthesis` mode immediately, then advance current_stage to `meta-plan`. Otherwise fire the gate.
- **`autonomous`**: auto-pass. Dispatch the orchestrator in `final-synthesis` mode. Parse `synthesis.md` — if any `[QUESTION]` marks remain, halt with the unresolved-question safeguard. Otherwise advance current_stage to `meta-plan`.

When the gate fires, update session.md: `current_stage: meta-research`, `status: awaiting-approval`. Show:

```
[session: <id> | stage: meta-research → gate (round <N>)]
Briefing ready: meta-research/briefing-<N>.md

Roles read: <comma-list>
Convergences: <count>
Tensions: <count>
Open questions: <count>
Roles flagged for round 2: <comma-list, or "none">

Options:
  /mar:approve meta-research                    → run final synthesis and advance to meta-plan
  /mar:iterate meta-research "<direction>"      → run round <N+1> with direction (targets flagged roles)
  /mar:reject meta-research                     → discard all rounds, restart from scratch
```

Stop here. The user's next action drives the flow.

## Step 4b — Run phase research (2c only)

Print breadcrumb:
```
[session: <id> | size: <size> | autonomy: <mode> | stage: → research (phase)]
```

### Step 4b.1 — Dispatch research-agent

Dispatch `research-agent` via Task:
- inputs: `session_id`, `phase_id` (resolve current phase from meta-plan or default `phase-01-main`), `phase_goal`, `kind` (from session.md), `pre_research_direction`
- output: `sessions/active/<id>/phases/<phase_id>/research.md` (5-section structured schema per v5)

Verify the output file has all 5 sections populated. If section 1 (Library landscape) is empty for greenfield work, surface a warning — the agent likely under-researched.

### Step 4b.2 — Optional skeptic pass

The skeptic runs when **size ∈ {L, XL}** OR **guidance == `deep`**. Otherwise skip to Step 5.

Dispatch `phase-research-skeptic-agent` via Task:
- inputs: `session_id`, `phase_id`, `research_path`, `meta_plan_path` = `sessions/active/<id>/meta-plan.md`, `synthesis_path` = `sessions/active/<id>/meta-research/synthesis.md` (omit if absent for S/M sessions)
- output: `sessions/active/<id>/phases/<phase_id>/research-skeptic.md`

Read the verdict from frontmatter:
- `verdict: approve` → continue to Step 5.
- `verdict: request-changes` → run Step 4b.3 (refine).

### Step 4b.3 — Research refine (cap: 1 round)

Re-dispatch `research-agent`:
- inputs: same as Step 4b.1 PLUS `additional_direction` = concatenated `[blocker]` + `[must-fix]` comments from `research-skeptic.md`
- effect: rewrites `research.md` addressing the comments

After the refine pass, **do NOT re-run the skeptic.** Cap is 1 refine round — research has less margin than a plan.

If research-agent marks any `[blocker]` as `won't fix — <reason>` in the refined research.md and the reason is unconvincing, the **`phase-research-wall hit`** safeguard fires (regardless of autonomy mode). Surface the unresolved blockers to the user and halt.

Continue to Step 5.

## Step 5 — Phase research review gate

Fires based on autonomy and skeptic state:

| Mode | Gate fires when |
|---|---|
| `interactive` | always |
| `normal` | size ∈ {L, XL}, OR skeptic flagged any `[blocker]`/`[must-fix]` |
| `streamlined` | skeptic flagged any `[blocker]`/`[must-fix]` (gate auto-passes if skeptic approved or was skipped) |
| `autonomous` | never (skeptic blocker → safeguard halts at Step 4b.3) |

When the gate fires:

```
[session: <id> | phase: <phase-id> | stage: research → gate]
Research ready: phases/<phase-id>/research.md
  Library options surfaced: <N>
  External APIs distilled: <K>
  Reference patterns: <M>
  Inherited constraints: <C>
  Open unknowns: <O>
  Skeptic: <pass | revisions-applied (1 round) | skipped (size=<S|M> or guidance≠deep)>

What now?
  /mar:approve research                  → proceed to phase plan (Stage 2c)
  /mar:iterate research "<note>"         → tweak research in place (re-runs research-agent with the note)
  /mar:revise meta-plan "<note>"         → back up: this phase's scope from meta-plan needs adjusting
  /mar:reject research                   → discard research, restart fresh (no direction)
```

Update session.md: `current_stage: research-review`, `status: awaiting-approval`. Hold here.

## Step 6 — Run the planning sub-stage

Print breadcrumb:
```
[session: <id> | size: <size> | autonomy: <mode> | stage: → <2a|2b|2c>]
```

### Stage 2a — Meta-plan (v4: strategist → author → skeptic)

Stage 2a has an internal state machine — strategist proposes a decomposition strategy, author writes the plan, skeptic reviews, author refines if needed (capped at 2 skeptic rounds), then the meta-plan gate fires to the user. Determine where you are by artifacts on disk:

| meta-plan files | Action |
|---|---|
| `synthesis.md` exists, `meta-plan-strategy.md` missing | Run **strategist** (Step 6.2a.1) |
| `meta-plan-strategy.md` exists, `meta-plan.md` missing | Run **author** in `draft` mode (Step 6.2a.2) |
| `meta-plan.md` exists, `meta-plan-review.md` missing | Run **skeptic** round 1 (Step 6.2a.3) |
| `meta-plan-review.md` verdict `approve` | Fire meta-plan gate (Step 7) |
| `meta-plan-review.md` verdict `request-changes`, `meta-plan-revisions.md` missing or pre-round-1 | Run **author** in `refine` mode (Step 6.2a.4) |
| `meta-plan-revisions.md` updated, `meta-plan-review-2.md` missing | Run **skeptic** round 2 |
| `meta-plan-review-2.md` verdict `approve` | Fire meta-plan gate (Step 7) |
| `meta-plan-review-2.md` verdict `request-changes` | **Safeguard fires: `plan-review-wall hit`** — halt and surface to user, regardless of autonomy mode |

**No issues are opened in 2a.** That's 2b's job. Stage 2a produces `meta-plan.md` with phase IDs as local labels (`phase-1`, `phase-2`, ...), plus the sidecar files (`meta-plan-strategy.md`, `meta-plan-review.md`, optionally `meta-plan-revisions.md` and `meta-plan-review-2.md`).

#### Step 6.2a.1 — Strategist

Dispatch `meta-plan-strategist-agent` via Task:
- inputs: `session_id`, `goal`, `kind` (from session.md), `size`, `synthesis_path` = `sessions/active/<id>/meta-research/synthesis.md`
- output: `sessions/active/<id>/meta-plan-strategy.md`

Verify the file exists and contains a strategy name from the catalogue (`tracer-bullet` | `risk-first` | `value-first` | `user-journey` | `integration-by-integration` | `spike-then-build`). On parse failure, halt.

Continue immediately to Step 6.2a.2 (no user gate between strategy and draft — the user can iterate the whole plan if the strategy is wrong).

#### Step 6.2a.2 — Author (draft mode)

Dispatch `meta-plan-author-agent` via Task:
- inputs: `session_id`, `goal`, `size`, `guidance`, `synthesis_path`, `strategy_path` = `meta-plan-strategy.md`, `mode: draft`
- output: `sessions/active/<id>/meta-plan.md`

Verify the file exists with all v4 sections populated (Acceptance demo, Decomposition strategy, Alternatives considered, plus the v3 sections). Continue to Step 6.2a.3.

#### Step 6.2a.3 — Skeptic (round 1)

Dispatch `meta-plan-skeptic-agent` via Task:
- inputs: `session_id`, `plan_path` = `meta-plan.md`, `synthesis_path`, `strategy_path`, `round: 1`
- output: `sessions/active/<id>/meta-plan-review.md`

Read the verdict from the file's frontmatter:
- `verdict: approve` → continue to Step 7 (fire meta-plan gate).
- `verdict: request-changes` → continue to Step 6.2a.4.

#### Step 6.2a.4 — Author (refine mode)

Dispatch `meta-plan-author-agent` via Task:
- inputs: `session_id`, `goal`, `size`, `guidance`, `synthesis_path`, `strategy_path`, `mode: refine`, `review_path` = `meta-plan-review.md`
- effect: patches `meta-plan.md` in place; appends to `meta-plan-revisions.md`.

Verify `meta-plan-revisions.md` exists with one entry per round-1 comment. Then dispatch skeptic round 2:
- `meta-plan-skeptic-agent` with `round: 2`, `prior_review_path` = `meta-plan-review.md`, `revisions_path` = `meta-plan-revisions.md`.
- output: `sessions/active/<id>/meta-plan-review-2.md`.

Read the round-2 verdict:
- `verdict: approve` → continue to Step 7.
- `verdict: request-changes` → fire the `plan-review-wall hit` safeguard. Halt regardless of autonomy mode. Surface to the user: "Skeptic round 2 still request-changes. Round cap (2) hit. Options: /mar:approve meta-plan (force-pass), /mar:iterate meta-plan \"<note>\" (your turn to direct), /mar:revise meta-plan \"<note>\" (back up to meta-research), /mar:redirect \"<new direction>\" (full reset)."

The refine loop is internal; user-initiated `/mar:iterate meta-plan` resets the round counter (see iterate.md).

### Stage 2b — Issue scaffolding

This stage doesn't dispatch an agent. The orchestrator itself derives proposed issue bodies from the meta-plan, then creates real GitHub issues in the current repo via `gh`.

For each phase in meta-plan:
1. Generate a stub issue body using `ops/workflow/templates/issue-body.md.template`. Phase 1 may get fuller content if its phase-plan-author-agent has already run; stubs otherwise.
2. Concatenate all stub bodies into one preview file: `sessions/active/<id>/proposed-issue-bodies.md`. Each body separated by a `---` divider with its phase ID as section header.

**Issue creation — branch by autonomy:**

- `interactive` / `normal` / `streamlined`: write `proposed-issue-bodies.md`, pause at the 2b gate so the user can review. On `/mar:approve issue-scaffolding`, the orchestrator runs:
  ```bash
  bash ops/workflow/scripts/create-phase-issues.sh --session <id>
  ```
  Hard-block on non-zero exit. The script handles `gh auth status`, repo existence, fine-grained-PAT scope errors, and records issue numbers back into `session.md` (`issues:` field) and each `phases/<phase-id>/plan.md` frontmatter (`issue:` + `issue_url:`).

- `autonomous`: skip the preview gate. Write `proposed-issue-bodies.md` AND immediately run `create-phase-issues.sh`. Same hard-block on failure. Log the issue numbers in `session.md` timeline.

**No more "preview-only forever" mode.** The script always runs; the only difference is whether it runs immediately (autonomous) or on user approval (interactive).

### Stage 2c — Phase plan (v6: author → skeptic)

Stage 2c has an internal state machine — author drafts the plan, skeptic adversarially reviews, author refines if needed (capped at 2 skeptic rounds), then the phase plan gate fires to the user. Determine where you are by artifacts on disk:

| Phase-plan files | Action |
|---|---|
| `research.md` exists, `plan.md` missing | Run **author** in `draft` mode (Step 6.2c.1) |
| `plan.md` exists, `plan-review.md` missing | Run **skeptic** round 1 (Step 6.2c.2) |
| `plan-review.md` verdict `approve` | Run derive-issue-body, then fire phase plan gate (Step 6.2c.4) |
| `plan-review.md` verdict `request-changes`, `plan-revisions.md` missing or pre-round-1 | Run **author** in `refine` mode (Step 6.2c.3) |
| `plan-revisions.md` updated, `plan-review-2.md` missing | Run **skeptic** round 2 |
| `plan-review-2.md` verdict `approve` | Run derive-issue-body, then fire phase plan gate (Step 6.2c.4) |
| `plan-review-2.md` verdict `request-changes` | **Safeguard fires: `phase-plan-review-wall hit`** — halt regardless of autonomy mode |

Stage 2c produces `plan.md` (canonical) plus sidecar files: `plan-review.md`, optionally `plan-review-2.md`, optionally `plan-revisions.md`, and `issue-body.md` (derived).

#### Step 6.2c.1 — Author (draft mode)

Dispatch `phase-plan-author-agent` via Task:
- inputs: `session_id`, `phase_id`, `goal`, `size`, `guidance`, `research_path` = `phases/<id>/research.md`, `meta_plan_path` = `meta-plan.md` (if L/XL), `mode: draft`
- output: `sessions/active/<session_id>/phases/<phase_id>/plan.md`

Verify the file exists with all v6 sections populated (Implementation strategy, Library decisions, plus the carried-over v2 sections). Continue to Step 6.2c.2.

#### Step 6.2c.2 — Skeptic (round 1)

Dispatch `phase-plan-skeptic-agent` via Task:
- inputs: `session_id`, `phase_id`, `plan_path`, `research_path`, `meta_plan_path` (if applicable), `round: 1`
- output: `sessions/active/<session_id>/phases/<phase_id>/plan-review.md`

Read the verdict from frontmatter:
- `verdict: approve` → continue to Step 6.2c.4.
- `verdict: request-changes` → continue to Step 6.2c.3.

#### Step 6.2c.3 — Author (refine mode)

Dispatch `phase-plan-author-agent` via Task:
- inputs: same as draft, plus `mode: refine`, `review_path` = `plan-review.md`
- effect: patches `plan.md` in place; appends to `plan-revisions.md`.

Then dispatch skeptic round 2:
- `phase-plan-skeptic-agent` with `round: 2`, `prior_review_path` = `plan-review.md`, `revisions_path` = `plan-revisions.md`
- output: `plan-review-2.md`

Read the round-2 verdict:
- `verdict: approve` → continue to Step 6.2c.4.
- `verdict: request-changes` → fire **`phase-plan-review-wall hit`** safeguard. Halt regardless of autonomy mode. Surface to user: "Skeptic round 2 still request-changes. Round cap (2) hit. Options: /mar:approve plan (force-pass), /mar:iterate plan \"<note>\" (your turn to direct), /mar:revise research \"<note>\" (back up to research), /mar:revise meta-plan \"<note>\" (back up further)."

#### Step 6.2c.4 — Derive issue body

```bash
python3 ops/workflow/scripts/derive-issue-body.py --session <id> --phase <phase-id>
```

**Hard-block on non-zero exit.** Surface stderr verbatim and stop. plan.md and the derived view must agree.

Log: `<ts> derived issue-body for <phase_id>`.

The internal refine loop is hidden from the user; user-initiated `/mar:iterate plan` resets the skeptic counter (see iterate.md).

## Step 7 — Sub-stage gate (branch by autonomy)

Read the artifact produced. Branch on `session.md` `autonomy`:

### `interactive` / `normal` / `streamlined` — gate (pause)

Show a concise summary with breadcrumb header:

```
[session: <id> | size: <size> | autonomy: <mode> | stage: <2a|2b|2c> → gate]
Artifact ready: <path>

<stage-specific summary lines>

Approve, iterate, or reject:
  /mar:approve <meta-plan|issue-scaffolding|plan>            → pass the gate
  /mar:iterate <meta-plan|issue-scaffolding|plan> "<note>"   → refine in place
  /mar:reject <meta-plan|issue-scaffolding|plan>             → revert to prior stage
  /mar:replan                                                → full re-plan
```

Stage-specific summary lines:
- 2a: `Strategy: <name>` | `Alternatives: <a>, <b>` | `Phases: <N>` | `Skeptic verdict: <pass | revisions-applied (round <N>)>` | `Open [QUESTION]s: <K>`
- 2b: `Phases scaffolded: <N>` | `Issues will be created in <owner/repo> on /mar:approve issue-scaffolding`
- 2c: `Strategy: <name>` | `Library picks: <N>` | `Skeptic verdict: <pass | revisions-applied (round <N>)>` | `Scope: <N files>` | `DoD items: <count>` | `[QUESTION]s: <K>` | `Test matrix rows: <count>` | `Eval matrix rows: <count or "n/a">`

For 2a specifically, replace the standard "approve / iterate / reject" options block with the **4-option meta-plan gate menu**:

```
What now?
  /mar:approve meta-plan                  → advance to issue scaffolding (Stage 2b)
  /mar:iterate meta-plan "<note>"         → tweak the plan in place (resets skeptic counter)
  /mar:revise meta-plan "<note>"          → back up: re-research with note, then re-plan
  /mar:redirect "<new direction>"         → reset: discard plan + research, restart with new direction
```

For 2c specifically, replace the standard options block with the **5-option phase plan gate menu**:

```
What now?
  /mar:approve plan                       → proceed to execute (Stage 3)
  /mar:iterate plan "<note>"              → tweak the plan in place (resets skeptic counter)
  /mar:revise research "<note>"           → back up: research was thin / missed X
  /mar:revise meta-plan "<note>"          → back up further: this phase's scope from meta-plan is wrong
  /mar:reject plan                        → discard plan, return to research (no direction)
```

(For 2b, the standard `approve / iterate / reject` options apply.)

Update `session.md`: `current_stage: <2a|2b|2c>`, `status: awaiting-approval`, `last_activity: now`. Stop.

### `autonomous` — skip gate, continue the pipeline

No pause. Log in session.md timeline: `<ts> autonomous auto-approved <stage>` and `last_activity: now`. Then continue inline:

- After meta-research → next loop iteration runs 2a meta-plan (still no pause). The autonomous-mode meta-research auto-pass already ran final-synthesis at Step 4a.gate; the synthesis must contain zero `[QUESTION]` marks or the safeguard fires.
- After 2a → next loop iteration runs 2b (still no pause).
- After 2b → next loop iteration runs 2c (still no pause).
- After 2c → dispatch `/mar:ship`'s pipeline for this phase (execute → test → refine → simplify → re-test → verify → review/tester → integrate).
- After integrate completes for a phase, if more phases remain: loop back to Step 4b for the next phase (2c only — meta-research, 2a, and 2b are session-level, done once).
- After the final phase integrates: stop.

Always-on safeguards still fire even in autonomous (manual step, scope violation, review-wall, tester-fail-cap, unresolved `[QUESTION]` on synthesis or plan, derive-issue-body.py failure, secret write).

## Rules

- `interactive` / `normal` / `streamlined`: each sub-stage gate is hard. Do not run subsequent sub-stages or execute.
- `autonomous`: may chain through 2a → 2b → 2c → ship inline. Always-on safeguards still apply.
- Do not write to `.brain/` or `research/`.
- If any stage returns replan-needed or paused, surface to the user and stop regardless of autonomy.
- The 3-way gate (approve / iterate / reject) is the standard surface across all gates. Always show all three options to the user.
