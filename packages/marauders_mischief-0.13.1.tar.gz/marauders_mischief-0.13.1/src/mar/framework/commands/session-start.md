---
description: Start a new development session. Interactive — picks size, kind, guidance, autonomy via AskUserQuestion.
---

You are starting a new development session. The goal is: $ARGUMENTS

## Step 0 — Parse optional flags out of $ARGUMENTS

Before treating $ARGUMENTS as the goal, parse two optional flags from anywhere in the string:

- `--kind <value>` — pre-selects the Kind answer (Step 1, Question 2). Valid values: `greenfield`, `new-feature`, `refactor`, `bug`, `infra-ops`. If invalid, error and stop.
- `--roles <comma-list>` — overrides the role roster derived from `kind`. Comma-separated names from: `product`, `domain`, `prior-art`, `ux`, `ops`, `skeptic`. Must include at least `skeptic` (skeptic always runs). Unknown role names error out.

After parsing, strip the flag and its value from $ARGUMENTS. Treat whatever remains as the goal text.

If `--kind` was passed: skip Question 2 in Step 1; use the passed value.
If `--roles` was passed: skip the kind→roles mapping and use the passed list.

## Step 1 — Collect configuration via AskUserQuestion

Do NOT ask via free-text. Use the AskUserQuestion tool with the questions below (batched in parallel where the options are independent).

### Question 1 — Size

- Options:
  - `S` — bug fix or isolated refactor (~½ day)
  - `M` — feature in one service (1–2 days)
  - `L` — cross-cutting or new subsystem (2–5 days)
  - `XL` — new service or major rewrite (>1 week)
- When in doubt, size down — upgrading via `/mar:redirect` mid-session is cheaper than paying meta-plan overhead on work that turns out small.
- For trivially small edits (typo, config tweak, <30 min), don't open a session at all — edit directly and commit.

### Question 2 — Kind (skip if `--kind` was passed in Step 0)

Determines which role-research agents run in Stage 2a (L/XL only). Has no behavioral effect on S/M sessions, but is still stored on the session for reference.

- Options (4 shown; `infra-ops` available via Other):
  - `new-feature` — extension of existing functionality
  - `greenfield` — new application or subsystem (no codebase yet, or near-empty)
  - `refactor` — internal restructure with no user-visible behavior change
  - `bug` — fix existing broken behavior
- Also via Other: `infra-ops` — deploy / observability / on-call work.

### Step 1b — Derive the role roster from Kind

After Question 2 (or from `--kind` in Step 0), compute the roster used at Stage 2a:

| Kind | Roles |
|---|---|
| `greenfield` | `product, domain, prior-art, ux, ops, skeptic` |
| `new-feature` | `product, domain, prior-art, ux, skeptic` |
| `refactor` | `domain, prior-art, skeptic` |
| `bug` | `domain, skeptic` |
| `infra-ops` | `domain, ops, prior-art, skeptic` |

If `--roles` was passed in Step 0, use that list verbatim instead.

Skeptic is mandatory in every roster — if a `--roles` override omits it, append `skeptic` automatically and log a one-line note to the session timeline.

Store the resulting roster as a comma-separated string (no spaces) for `{{ROLES}}` in the session.md template.

### Question 3 — Guidance mode

- Options:
  - `light` — few questions, more assumptions
  - `normal` — balanced
  - `deep` — more questions for uncertain terrain

### Question 4 — Autonomy

Controls which gates pause for human input across the whole loop. See `ops/workflow/README.md` for the full gate matrix.

- Options:
  - `interactive` — pauses at: phase-level research review, meta-research briefing (L/XL), meta-plan, each phase-plan, between phases (L/XL), integrate. Maximum hand-holding.
  - `normal` — pauses at: meta-research briefing (L/XL), meta-plan, each phase-plan, between phases (L/XL), integrate.
  - `streamlined` — pauses at: meta-research briefing (L/XL — only if briefing has tensions or open questions), meta-plan, each phase-plan, integrate. No between-phase ack.
  - `autonomous` — fully hands-off after this command. Auto-passes meta-research, meta-plan, every phase-plan, integrate. Only stops on always-on safeguards (manual step, scope violation, review-wall, tester-fail-cap, unresolved `[QUESTION]` on synthesis or plan, secret-file write).

## Step 2 — Collect session description (required, all modes)

Prompt the user with plain text (NOT AskUserQuestion):

> One paragraph (3–5 sentences). The research agents work from this — say
> enough so they don't have to guess, but stop before you start designing.
>
> Cover:
>   • Outcome — what does success look like for the user?
>   • Drivers — what's pushing this now (deadline, complaint, opportunity)?
>   • Constraint or non-goal — one thing this work must (not) do.
>
> Skip anything that's already in .brain/CONTEXT.md. Skip implementation
> ideas — the agents will surface those.
>
> This is your only direct input in autonomous mode. In other modes you
> can /mar:redirect with a sharpened version if the first pass goes sideways.

Requirements:
- Non-empty. If empty or `skip`, re-prompt: "Required. A goal slug is not enough context for the research agents — add 3–5 sentences covering outcome, drivers, and one constraint."
- No upper bound — but if the user goes past ~12 sentences, gently nudge: "This is more than the research agents need. Consider trimming — anything design-shaped will land in the meta-plan stage."

Store the reply verbatim for use in Step 4 (substituted as `{{DESCRIPTION}}`).

## Step 3 — Create session

1. Compute session id: `YYYY-MM-DD-<goal-slug>` where goal-slug is a 2–4-word kebab from the goal.
2. If a session with the same id exists under `sessions/active/`, suffix `-2`, `-3`, etc. until the id is unique. (Multiple parallel sessions in the same repo are fine — each lives in its own dir and is keyed by per-window pointer.)
3. Create dir: `sessions/active/<session-id>/`
4. Read `ops/workflow/templates/session.md.template`. Substitute placeholders:
   - `{{SESSION_ID}}` — computed id
   - `{{GOAL}}` — goal slug (≤80 chars summary of $ARGUMENTS)
   - `{{SIZE}}` — from Question 1
   - `{{KIND}}` — from Question 2 or `--kind`
   - `{{ROLES}}` — comma-separated roster derived in Step 1b (e.g. `product,domain,prior-art,ux,ops,skeptic`)
   - `{{GUIDANCE}}` — from Question 3
   - `{{AUTONOMY}}` — from Question 4
   - `{{STARTED}}` — current timestamp ISO8601
   - `{{DESCRIPTION}}` — the paragraph from Step 2

   Write to `sessions/active/<session-id>/session.md`.
5. Create `phases/` subdir.
6. Run `bash ops/workflow/scripts/set-session.sh <session-id>` to write the per-window pointer (keyed by `$CLAUDE_CODE_SSE_PORT`). Lets parallel CC windows each drive their own session.

## Step 4 — Report

Output:
```
Session created: <session-id>
  size: <size>
  kind: <kind>
  roles: <comma-list> (Stage 2a roster — L/XL only)
  guidance: <mode>
  autonomy: <interactive|normal|streamlined|autonomous>

Next: /mar:plan
```

Do not proceed past `/mar:session-start`. The user runs `/mar:plan` next.

## Rules

- Do NOT prompt for budget — v2 dropped budget tracking.
- Sessions run repo-wide. The plan's Scope section + scope hook fences edits to plan-declared paths; no session-level "service" binding.
- Do NOT create GitHub repos or git submodules. Repo-level setup (git init, gh auth, origin remote) is the user's responsibility.
- Multiple active sessions in the same repo are allowed — each has its own dir and per-window pointer. Don't refuse to start because another session is active.
- Do NOT refuse `autonomous` mode based on repo state — autonomous mode works against local files in v0.1+, and against the repo's gh origin in v0.4+.
