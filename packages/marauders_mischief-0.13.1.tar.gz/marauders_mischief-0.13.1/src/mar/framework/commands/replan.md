---
description: Deprecated. Use /mar:redirect instead. Prints a hint and stops without destructive action.
---

`/mar:replan` is **deprecated** as of v0.3.0. Use `/mar:redirect` instead.

Why the rename: the new command name describes the user intent ("redirect the session") rather than an implementation detail ("re-plan"). It also accepts an optional new-direction argument that the old `/mar:replan` could not handle cleanly.

## Action

Do **not** perform any destructive operation. Print the migration hint and stop:

```
/mar:replan is deprecated in v0.3+. Use:

  /mar:redirect                       → full reset, no new direction
                                        (closest equivalent to the old /mar:replan)
  /mar:redirect "<new direction>"     → reset and pivot with a new framing
  /mar:revise meta-plan "<note>"      → back up to meta-research without resetting
                                        (use this if you only want to add direction
                                        to research, not abandon the framing)

/mar:replan will be removed in v0.4.
```

## Rules

- **No destructive action.** Do not move, rename, or rewrite any session artifact.
- **No silent fallthrough.** Do not automatically invoke `/mar:redirect` on the user's behalf — they should issue the command explicitly to confirm intent.

## Removal timeline

- v0.3.x — this deprecation hint
- v0.4.0 — file removed from the framework manifest
