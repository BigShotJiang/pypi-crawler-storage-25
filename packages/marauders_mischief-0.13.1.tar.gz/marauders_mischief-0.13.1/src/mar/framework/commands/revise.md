---
description: Back up with a note. Valid at meta-plan, phase-research, and phase-plan gates. Target is the gate to back up TO. Usage — /mar:revise <target> "<note>"
---

Back up one stage with a note. The middle option between `/mar:iterate <gate>` (refine in place) and `/mar:reject <gate>` (discard, no direction).

Three valid contexts (v0.6):

1. **From the meta-plan gate** (v0.3) → target = `meta-plan` (the gate you're at when "backing up to meta-research"). Backs up to meta-research with the note, kicks off a targeted round N+1 of role-research.
2. **From the phase research gate** (v0.5) → target = `meta-plan`. Backs up to meta-plan iteration with the note. Use when this phase's scope from meta-plan turns out wrong.
3. **From the phase plan gate** (v0.6) → target = `research` OR `meta-plan`. `research` backs up to phase research (research was thin); `meta-plan` backs up further (phase scope from meta-plan was wrong).

Argument shape: `<target> "<note>"`. Target names the gate you're backing up **to**. The current gate (where you invoke the command) is detected from session state.

Examples:
- At meta-plan gate: `/mar:revise meta-plan "the auth concern is overblown, drop it"` — backs up to meta-research.
- At phase research gate: `/mar:revise meta-plan "phase 2 should also include the validation module"` — backs up to meta-plan iterate.
- At phase plan gate, target=research: `/mar:revise research "research missed how the streaming API handles backpressure"` — backs up to phase research.
- At phase plan gate, target=meta-plan: `/mar:revise meta-plan "phase 2's scope was too narrow — should also include error reporting"` — backs up to meta-plan iterate.

## Step 1 — Parse

Split into `<target>` (must be `meta-plan` or `research`) and `<note>` (rest, trim quotes). If `<note>` is empty, error: "Revise requires a note — what's the direction? Use /mar:reject if you want no direction."

If `<target>` is anything other than `meta-plan` or `research`, error: "Valid revise targets: `meta-plan` or `research`. Specify your back-up destination, not your current location."

## Step 2 — Resolve session and detect current gate

Run `bash ops/workflow/scripts/current-session.sh` to resolve id, then read `sessions/active/<id>/session.md`. Error if no session.

Detect the current gate + validate the target:

| current_stage | status | Valid targets | Mode |
|---|---|---|---|
| `meta-plan` | `awaiting-approval` | `meta-plan` only | **Mode A: meta-plan-gate revise** (Step 3a) |
| `research-review` | `awaiting-approval` | `meta-plan` only | **Mode B: phase-research-gate revise** (Step 3b) |
| `plan` | `awaiting-approval` | `meta-plan` OR `research` | **Mode C: phase-plan-gate revise** (Step 3c) |
| anything else | any | none | refuse: "/mar:revise is only valid at the meta-plan, phase research, or phase plan gates." |

If the target is incompatible with the current gate (e.g. `research` at the meta-plan gate), refuse with the matrix above.

## Step 3a — Meta-plan-gate revise (v0.3 behavior)

Used when the user is reviewing a drafted meta-plan and wants to back up to meta-research.

Archive the meta-plan + sidecars (one timestamp sweep, same `<ts>` for grouping):
- `sessions/active/<id>/meta-plan.md` → `meta-plan.md.rejected-<ts>`
- `sessions/active/<id>/meta-plan-strategy.md` → `meta-plan-strategy.md.rejected-<ts>`
- `sessions/active/<id>/meta-plan-review.md` → `meta-plan-review.md.rejected-<ts>`
- `sessions/active/<id>/meta-plan-review-2.md` (if exists) → `meta-plan-review-2.md.rejected-<ts>`
- `sessions/active/<id>/meta-plan-revisions.md` (if exists) → `meta-plan-revisions.md.rejected-<ts>`

### Step 4 — Determine the meta-research round to kick off (Mode A continued)

Read `sessions/active/<id>/meta-research/`. Find the highest existing `briefing-<N>.md`. The new round will be `N+1`.

Write the user's note to `meta-research/human-direction-<N>.md` (note: this is keyed by the *current* round number, matching the existing iterate convention — it's the direction the user gave *after* reviewing round N's briefing).

## Step 5 — Decide which roles to re-dispatch

Read `meta-research/briefing-<N>.md` for its "Roles that need a round 2" section. If `<note>` explicitly names roles (e.g. "deeper on prior-art and ops"), use those names. Otherwise use the briefing's flagged list.

Skeptic always re-runs in any subsequent round.

If no roles are flagged AND `<note>` doesn't name any, default to re-running all roles in the active roster (from session.md's `roles:` field) — the user's note is broad enough to warrant a full re-run.

## Step 6 — Dispatch round N+1

This mirrors `/mar:iterate meta-research`'s round-N+1 dispatch (see iterate.md). In one assistant turn, dispatch the chosen non-skeptic roles in parallel via Task:

For each role-agent: pass `round: N+1`, `additional_direction: <note>`, `prior_output_path: meta-research/round-<N>/<role>.md` if a prior output exists.

After the parallel wave completes, dispatch `skeptic-research-agent` with `round: N+1`, `additional_direction: <note>`, and `other_role_outputs` pointing at the new round files (plus prior-round files for roles that didn't re-run).

Finally dispatch `meta-research-orchestrator-agent` with `mode: briefing`, `round: N+1` → writes `meta-research/briefing-<N+1>.md`.

## Step 7 — Update session state and surface the gate

Update session.md:
- `current_stage: meta-research`
- `status: awaiting-approval`
- timeline: `<ts> revise meta-plan — <note> (round=<N+1>)`

Surface the mid-research gate (same format as `/mar:plan` Step 4a.gate). The user can:
- `/mar:approve meta-research` → orchestrator runs final-synthesis; user must then run `/mar:plan` to draft the new meta-plan (via the strategist → author → skeptic flow).
- `/mar:iterate meta-research "<dir>"` → another round.
- `/mar:reject meta-research` → discards all rounds, restart from scratch (the original meta-plan is already archived from Step 3).

Iterate cap is shared with `/mar:iterate meta-research` — round 4+ triggers the soft hint.

End of Mode A flow.

## Step 3b — Phase-research-gate revise (v0.5 behavior)

Used when the user is reviewing a drafted phase research document and wants to back up to meta-plan iteration. The motivation is "this phase's scope from meta-plan turns out wrong."

Read the current phase id from session.md (`current_phase` field). Then:

1. **Archive the current phase's research** (and skeptic output if present):
   - `sessions/active/<id>/phases/<current_phase>/research.md` → `research.md.rejected-<ts>`
   - `sessions/active/<id>/phases/<current_phase>/research-skeptic.md` (if exists) → `research-skeptic.md.rejected-<ts>`
2. **Run the meta-plan-gate revise flow internally** — invoke the same logic as `/mar:iterate meta-plan "<note>"`:
   - Set `current_stage: meta-plan`, `status: in-progress` on session.md (temporarily — gate will set it back to `awaiting-approval`).
   - Archive existing meta-plan sidecars to `.iterated-<ts>` (matching `/mar:iterate meta-plan` semantics — they're stale once a new author pass runs).
   - Dispatch `meta-plan-author-agent` with `mode: iterate`, `additional_direction: <note>`.
   - Dispatch `meta-plan-skeptic-agent` round 1 against the updated plan.
   - If skeptic verdict is `request-changes`, enter the internal refine loop (per `/mar:plan` Step 6.2a.4); else fire the meta-plan gate.
3. **Log timeline**: `<ts> revise from phase-research (phase=<id>) — <note>`.

After the meta-plan gate approves (whenever the user gets there), the next `/mar:plan` invocation re-enters phase research for the current phase. If the meta-plan iterate rescoped phases (e.g. merged this one into another), the user adjusts `current_phase` to match before re-entering — or the orchestrator detects rescope and surfaces the change.

End of Mode B flow.

## Step 3c — Phase-plan-gate revise (v0.6 behavior)

Used when the user is reviewing a drafted phase plan and wants to back up either to phase research (target=`research`) or to meta-plan iteration (target=`meta-plan`).

Read the current phase id from session.md (`current_phase` field). Then branch on target:

### Target = `research` (back up to phase research)

The plan is thin because research was thin. Re-research with the note.

1. **Archive the current phase's plan + sidecars** (one timestamp sweep):
   - `phases/<current_phase>/plan.md` → `plan.md.rejected-<ts>`
   - `phases/<current_phase>/plan-review.md` (if exists) → `.rejected-<ts>`
   - `phases/<current_phase>/plan-review-2.md` (if exists) → `.rejected-<ts>`
   - `phases/<current_phase>/plan-revisions.md` (if exists) → `.rejected-<ts>`
   - `phases/<current_phase>/issue-body.md` → `.rejected-<ts>`
2. **Run the iterate-research flow internally** — invoke the same logic as `/mar:iterate research "<note>"`:
   - Dispatch `research-agent` in iterate mode with `additional_direction: <note>`.
   - The agent re-runs research with the note, rewrites `research.md`.
   - If the session is L/XL or guidance=deep, also re-run `phase-research-skeptic-agent` (round 1).
3. Set `current_stage: research-review`, `status: awaiting-approval`. The phase research gate fires next (per `/mar:plan` Step 5).
4. **Log timeline**: `<ts> revise from phase-plan (target=research, phase=<id>) — <note>`.

After the user approves the new research, the next `/mar:plan` invocation re-enters Stage 2c with the refreshed research.

### Target = `meta-plan` (back up to meta-plan iteration)

The phase scope from meta-plan was wrong. Back up further.

1. **Archive the current phase's plan + sidecars + research** (one timestamp sweep):
   - All of the above (plan + sidecars + issue-body)
   - Plus `phases/<current_phase>/research.md` → `research.md.rejected-<ts>`
   - Plus `phases/<current_phase>/research-skeptic.md` (if exists) → `.rejected-<ts>`
2. **Run the iterate-meta-plan flow internally** — same as Mode B's Step 3b:
   - Set `current_stage: meta-plan`, `status: in-progress`.
   - Archive meta-plan sidecars to `.iterated-<ts>`.
   - Dispatch `meta-plan-author-agent` with `mode: iterate`, `additional_direction: <note>`.
   - Dispatch `meta-plan-skeptic-agent` round 1 against the updated plan.
   - If skeptic verdict is `request-changes`, enter the internal refine loop; else fire the meta-plan gate.
3. **Log timeline**: `<ts> revise from phase-plan (target=meta-plan, phase=<id>) — <note>`.

After the meta-plan gate approves, the next `/mar:plan` invocation re-enters the affected phase from research onward.

End of Mode C flow.

## Rules

- Revise is valid at **three** gates: meta-plan, phase research, phase plan. From any other location, refuse with a clear pointer to `/mar:iterate <gate>` or `/mar:reject <gate>`.
- Revise **always** preserves the original artifacts as `.rejected-<ts>` (the artifact at the current gate, abandoned) or `.iterated-<ts>` (the artifact at the back-up target, re-iterated).
- Revise does NOT change session.md's `## Why` block in any mode — the goal hasn't changed, only the framing. (For goal changes, use `/mar:redirect`.)
- Mode A's iterate-cap soft hint applies (round 4+ surfaces the suggestion).
- Mode B and Mode C do not cap independently — they route through `/mar:iterate` on their target gate, which has its own internal skeptic refine cap.

## Hard rules

- Mode A: meta-plan + sidecars MUST be archived before round dispatch.
- Mode A: `human-direction-<N>.md` MUST be written before role-agents dispatch.
- Mode B: phase research MUST be archived before re-entering meta-plan flow — otherwise the next `/mar:plan` would skip research at this phase.
- Mode B: the user is on the meta-plan gate after this command completes.
- Mode C (target=research): plan + sidecars + issue-body MUST be archived before re-entering research flow.
- Mode C (target=meta-plan): plan + sidecars + issue-body + research + research-skeptic MUST all be archived before re-entering meta-plan flow.
