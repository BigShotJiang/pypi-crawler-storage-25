---
description: Run execute → test → refine → simplify → re-test → pre-PR verify → review-agent + tester-agent (Stage 5). Pauses at integrate gate.
---

Kick off the v2 build pipeline for the current phase. Sequential build loop, then parallel review + tester at Stage 5. Step 1 runs review-agent and tester-agent in **local-file mode** — they write to artifact files, not GitHub. Step 2 swaps the backend to PR comments.

## Refine wrapper pattern (v10)

Every refine dispatch in this orchestrator — the build loop after test-fail, the verify loop after verify-fail, and both Stage 5 loops (review and tester) — follows the same wrapper. The pattern closes two failure modes: silent contract weakening (refine edits a test instead of code) and silent codebase degradation (a fix breaks something that was passing).

For each refine dispatch:

1. **Set the refine flag.** Create `sessions/active/<id>/.refine-active` (empty file). This activates `check-scope.py`'s protected-surface block — tests, fixtures, snapshots, and eval data are denied to writes during refine. The flag is per-session, not per-phase, because the hook resolves the active session via the per-window pointer.
2. **Make a checkpoint commit** before refine edits:
   ```bash
   git add -A && git commit -m "chore(refine): checkpoint round=<N> phase=<phase-id> loop=<build|review|tester>"
   ```
   Save the resulting commit sha as `<checkpoint_sha>`.
3. **Save the prior failure set** (see "Regression detection" below).
4. **Dispatch refine-agent via Task** with the standard inputs for that loop.
5. **Clear the refine flag.** Remove `sessions/active/<id>/.refine-active`. Do this in both success and failure paths — never leave the flag stuck on.
6. **Re-dispatch the consumer** (test runners for build, review-agent for review loop, tester-agent for tester loop).
7. **Compare the new failure set to the prior one:**
   - Empty new set (clean) → advance out of the loop. **Push on clean** (see step 8).
   - New set is a subset of the prior set (partial progress, no new failures) → continue to round N+1 if under the cap.
   - Any failure appears in the new set that wasn't in the prior set → **regression**:
     ```bash
     git reset --hard <checkpoint_sha>~1
     ```
     Fire `refine-regression-wall hit` safeguard. Stop the /mar:ship run with a message that names the loop, the round, and the regressed failures.

8. **Push on clean** (v12). When the round advances out cleanly (no failures), push the branch to update the PR so CI runs against the new state:
   ```bash
   git push origin HEAD
   ```
   - Only push on clean-advance, never on a regression revert (the revert leaves the branch where origin already is, no push needed).
   - Hard-block on `git push` failure → fire `gh-pr-failure hit` safeguard.
   - This keeps the PR's commit list to one push per refine round, not one per checkpoint, so CI noise stays low.
   - If no PR has been opened yet for this phase (e.g. early in the build loop or pre-Stage-2.2), skip silently.

### Regression detection per loop

| Loop | Failure-set identifier |
|---|---|
| Build (test) | Set of `(kind, test_id)` tuples parsed from each per-kind runner's report. |
| Verify | Set of fail-item identifiers (rule/check names) parsed from verification.md's `## Fails` section. |
| Review (Stage 5) | Count of `[blocker]` + `[must-fix]` comments in review-comments.md. Regression = new count > prior count. |
| Tester (Stage 5) | Set of failing scenario names parsed from tester-report.md. |

If a report is malformed and the identifier set can't be extracted, conservatively treat the round as non-regressing and let the existing round-cap safeguards (`review-wall hit`, `tester-fail-cap`) catch divergence. Don't block on parse errors.

### Why this is orchestrator-only

Refine itself doesn't know about checkpoints. The orchestrator owns the safety belt — same separation as verify (orchestrator runs the verify command, not the agent). Checkpoint commits stay in history through Stage 5 and get squashed at integrate.

## Step 1 — Preconditions

1. Run `bash ops/workflow/scripts/current-session.sh`. Error if it exits non-zero.
2. Read session.md. Error if `status` ≠ one of {`in-progress`, `awaiting-approval`}.
3. Read the current phase's plan.md. Error if plan gate not passed (timeline contains `<ts> plan approved` or equivalent).
4. Confirm `phases/<id>/issue-body.md` exists (derived at plan gate). If missing, error: "issue body not derived — run /mar:plan to regenerate".
5. **Credentials gate** (hard-blocking, session-level):
   ```bash
   python3 ops/workflow/scripts/check-credentials.py --session <id> --json
   ```
   - Exit 0: all declared credentials present. Continue to Step 2.
   - Exit 1: parse the JSON `missing` array. For each missing credential, surface via `AskUserQuestion`:
     ```
     Missing: <NAME> (scope=<global|project>)
       location: <path>
       setup:    <one-liner from meta-plan>

     Options:
       I've set it now — re-check
       Abort the session
     ```
     Loop until either all-present (continue) or user aborts (`status: paused`, `last_activity: now`, stop).
   - The script verifies presence-by-name only, never reads values. If the session has `## Credentials` set to `none`, the gate trivially passes.

6. **Branch precondition** (v0.13.1, hard-blocking). Each phase = one branch + one PR; the orchestrator handles the branch so the user doesn't have to switch manually.

   Determine three values:
   - `DEFAULT_BRANCH` — `gh repo view --json defaultBranchRef -q .defaultBranchRef.name` if `gh` is available and `origin` is set; otherwise fall back to `main`.
   - `PHASE_BRANCH` — `phase/<current_phase>`, where `<current_phase>` is read from session.md frontmatter `current_phase:`.
   - `CURRENT` — `git rev-parse --abbrev-ref HEAD`.

   Three cases:

   a. **`CURRENT == PHASE_BRANCH`** → continue. The branch already exists from a prior `/mar:ship` run for this phase (e.g. a paused safeguard that the user resolved).

   b. **`CURRENT == DEFAULT_BRANCH`** → create the phase branch and switch:
      ```bash
      # If origin exists, sync local default branch with remote first.
      git fetch origin "$DEFAULT_BRANCH" 2>/dev/null || true
      git pull --ff-only origin "$DEFAULT_BRANCH" 2>/dev/null || true

      # Create and switch. Dirty working tree follows the checkout.
      git checkout -b "$PHASE_BRANCH"
      ```
      Continue.

   c. **`CURRENT` is some other branch** (not `PHASE_BRANCH`, not `DEFAULT_BRANCH`) → refuse and stop:
      ```
      [ship: branch precondition failed]
      Expected branch '<PHASE_BRANCH>' or '<DEFAULT_BRANCH>', currently on '<CURRENT>'.

      Most likely cause: prior phase's branch is still checked out after merge.
      Recover with:
        git checkout <DEFAULT_BRANCH> && git pull --ff-only
        /mar:ship
      ```
      Update `session.md`: `status: paused`, `last_activity: now`. Stop. (Not an `awaiting-approval` state — the user just needs to switch branches and re-invoke.)

   **L/XL between-phase note:** after phase N merges via `/mar:approve integrate`, the local working copy is still on the (merged) `phase/<N>` branch — the merge happened server-side. For phase N+1, the user (or the autonomous orchestrator at Step 5) must `git checkout <default> && git pull` before invoking `/mar:plan` for the next phase. Otherwise case (c) will fire when `/mar:ship` runs. See Step 5 for the autonomous-mode handling.

If any precondition fails, state the reason and stop.

## Step 2 — Build loop (per-step execute, then sequential build stages)

For sizes S / M / L / XL, the build loop runs:

1. **Step-by-step execute** (v7) — one fresh `execute-step-agent` dispatch per declared build step.
2. **Sequential build stages** — test → refine → simplify → re-test → pre-PR verify. Each is a fresh sub-agent.

### Step 2.1 — Per-step execute (v7)

Read `phases/<phase-id>/plan.md` and parse its `## Build steps` section. You'll get N step descriptions.

For each step in order (step_index from 1 to N):

```
iteration = 0
CAP = 3

while iteration < CAP:
  Print breadcrumb:
    [session: <id> | phase: <phase-id> | step <N>/<total>: <step name> | iteration <iteration+1>]

  Update session.md: current_stage: execute, last_activity: now.

  Dispatch execute-step-agent via Task with:
    - session_id, phase_id, plan_path
    - step_index (this loop's value)
    - step_description (the plan's "### Step N" block, verbatim)
    - prior_summaries = [build-steps/step-1-summary.md, ..., build-steps/step-(N-1)-summary.md]
    - failure_context (only on iteration > 0 — see below)

  Wait for the agent to return.

  Read the agent's return status:
    - status: paused (manual step) → surface, stop the whole /mar:ship run
    - status: replan-needed → surface options (see "Replan-needed handling" below), stop
    - status: complete → continue to verify check

  Verify check:
    Parse the step description for an optional "Verify:" line.
    If absent: break (advance to next step).
    If present:
      Run the declared verify command via Bash.
      Parse acceptance criterion against output.
      If pass:
        Append "## Verify result" → "pass" + output snippet to step-N-summary.md.
        break (advance to next step).
      If fail:
        iteration += 1
        if iteration == CAP:
          Fire `execute-step-wall hit` safeguard. See "Safeguards" at bottom.
          Stop the /mar:ship run.
        else:
          Construct failure_context with:
            - prior step-N-summary.md path
            - verify command + output (truncated to ~50 lines)
            - one-line "what didn't pass"
          Continue the while loop (re-dispatch execute-step-agent with failure_context).
```

After all N steps complete (the for-loop exits without an early-stop), advance to Step 2.2.

#### Replan-needed handling (mid-step)

If any step returns `status: replan-needed`, halt the build loop and surface:

```
[session: <id> | phase: <phase-id> | step <N>: replan-needed]
The execute-step-agent flagged that the build steps may be wrong.
Step <N>'s reason: <agent's reason>
Proposed delta: <agent's proposed-delta>

Options:
  /mar:iterate plan "<note about what's wrong>"
       → back up to plan gate; phase-plan-author re-decomposes Build steps
  /mar:revise research "<note>"
       → back up further if research missed context
  /mar:revise meta-plan "<note>"
       → back up further still if phase scope from meta-plan was wrong
  /mar:reject plan
       → discard plan, start over
```

Update session.md: `current_stage: plan`, `status: awaiting-approval`. Do NOT continue to Step 2.2.

### Step 2.2 — PR opens (v12)

After all build steps complete and before the test stage runs, open a draft PR for the phase. This makes the PR exist before review/tester run at Stage 5, so they can post inline comments against a real PR; it also gives CI a chance to run during build/refine cycles.

1. Print breadcrumb: `[session: <id> | phase: <phase-id> | stage: execute → pr-open]`.
2. Confirm current branch is NOT the repo's default branch (the script also enforces this; this is an early-exit pre-check).
3. Run:
   ```bash
   bash ops/workflow/scripts/workflow/create-phase-pr.sh \
     --session <session-id> --phase <phase-id>
   ```
4. **Hard-block on any non-zero exit.** Surface the script's stderr verbatim. Common failure modes the script itself surfaces:
   - `gh` not authenticated → user runs `gh auth login`
   - Origin remote missing or wrong → user fixes git remote
   - PR creation denied (PAT scope) → user fixes token
   - Current branch is the default branch → user creates a feature branch first
5. On success, the script writes `pr` and `pr_url` to the phase's `plan.md` frontmatter and updates `session.md`'s `prs:` field. Read `pr` from `plan.md` frontmatter to use as `pr_number` in downstream Stage 5 dispatches.

This step runs **once per phase** at the start of the build loop. It is NOT re-run on refine cycles; refine pushes new commits to the existing PR via push-on-clean-round (see "Push policy" below).

### Step 2.3 — Sequential build stages (test → refine → simplify → verify)

After all build steps complete and the PR is open, run the build stages. The **test stage is v8 multi-kind**: test-strategist plans which test kinds apply, dispatches per-kind specialist runners in parallel, then aggregates verdicts.

| Stage | Agent(s) | When |
|---|---|---|
| test-plan | test-strategist (plan mode) | always |
| test-run | per-kind runners (parallel wave) | always, after test-plan |
| test-aggregate | test-strategist (aggregate mode) | always, after wave returns |
| refine | refine-agent | only if aggregate verdict = fail (≤2 cycles) |
| simplify-author | simplify-author-agent | size ≥ M |
| simplify-skeptic | simplify-skeptic-agent | always after author (≤1 refine round) |
| simplify-retest | per-kind runners (targeted wave) | only if author's `re_test_kinds` is non-empty |
| pre-PR verify | verify-agent | always |

For each stage:
1. Print breadcrumb:
   ```
   [session: <id> | phase: <phase-id> | stage: <prev> → <stage>]
   ```
2. Update `session.md`: `current_stage: <stage>`, `last_activity: now`.
3. Dispatch the agent(s) with `session_id`, `phase_id`, `plan_path`, plus stage-specific paths. Include `phases/<phase-id>/build-steps/` as input so the agent can see what each step delivered.

#### test-plan stage

Dispatch `test-strategist-agent` in **plan mode**:
- inputs: session_id, phase_id, plan_path, build_steps_dir, mode=`plan`
- output: `phases/<phase-id>/test-plan.md`

When complete, parse `test-plan.md`'s `## Kinds applicable` section to enumerate the kinds the strategist declared. Each applicable kind has its own `### Kind: <name>` block — these become the inputs to the per-kind runners.

If no kinds are applicable (rare — strategist declared everything `n/a`) → log `[session: <id> | phase: <phase-id> | test-plan: no kinds applicable]`, write a trivial pass aggregate, skip to simplify/verify.

#### test-run stage (wave-1 parallel dispatch)

In a **single message**, dispatch ALL applicable runners in parallel via multiple Task tool calls:

| Kind declared in test-plan | Runner agent |
|---|---|
| `unit` (includes types, lint) | `test-runner-unit` |
| `eval` | `test-runner-eval` |
| `agent-flow` | `test-runner-agent-flow` |
| `browser` | `test-runner-browser` |
| `perf` | `test-runner-perf` |

Each runner gets: session_id, phase_id, plan_path, test_plan_path, plus `prior_failure_context` on retry.

Wait for the full wave to return. Collect each runner's return value (`{status, kind, verdict, failure_count, fix_targets, report_path}`).

If any runner returns `status: paused` (missing dep, port collision, browser tooling not installed, etc.):
- Surface the pause reason + install/setup hint to user.
- Stop the /mar:ship run with `status: paused` in session.md. The user resolves the dep, then resumes.

#### test-aggregate stage

Dispatch `test-strategist-agent` in **aggregate mode**:
- inputs: session_id, phase_id, plan_path, test_plan_path, mode=`aggregate`, per-kind report paths from the wave
- output: `phases/<phase-id>/test-report.md`

Read the aggregate's verdict:
- `pass` → advance to simplify (size ≥ M) or pre-PR verify
- `fail` → dispatch refine-agent

#### Refine on test-fail (v10 wrapper)

Apply the v10 refine wrapper (see "Refine wrapper pattern" above):

1. **Set flag:** `touch sessions/active/<id>/.refine-active`.
2. **Checkpoint:** `git add -A && git commit -m "chore(refine): checkpoint round=<N> phase=<phase-id> loop=build"`. Save sha as `<checkpoint_sha>`.
3. **Save prior failure set:** parse `test-report.md` per-kind, collect `(kind, test_id)` tuples into `prior_failures`.
4. **Dispatch refine-agent:**
   - inputs: session_id, phase_id, plan_path, round=N, sources=[test_report_path, test_plan_path]
   - The strategist's `test-plan.md` carries per-kind fix-target globs; refine reads them before patching. Per-kind runner reports also carry their own fix-target suggestions.
5. **Clear flag:** `rm sessions/active/<id>/.refine-active` (always, even if refine errored).
6. Handle refine return:
   - `replan-needed` → surface, stop. If `protected_surface_escalation` is populated, include the citation in the surfaced message.
   - `complete` → continue to re-test.
7. **Re-dispatch test stage** (test-plan → test-run → test-aggregate).
8. **Compare:** parse the new `test-report.md`, collect `new_failures`. If any `(kind, test_id)` in `new_failures` is not in `prior_failures` → regression:
   ```bash
   git reset --hard <checkpoint_sha>~1
   ```
   Fire `refine-regression-wall hit` safeguard with:
   ```
   [session: <id> | phase: <phase-id> | refine-regression-wall hit (build loop round <N>)]
   Refine introduced new failures not present in the prior round. Reverted to pre-refine checkpoint.
   Regressed failures: <list of (kind, test_id) tuples>
   Original failures (still open): <list>
   Recommended: /mar:iterate plan "<note>" if contract was wrong, or manual inspection.
   ```
   Update `session.md`: `status: stuck-refine-regression`. Stop.

Cap: **2 refine cycles** in the build loop.

If 2 cycles exhausted with verdict still `fail` (no regression, but stuck):
- Pause with `{reason: stuck, recommend: replan}`.
- Surface to user with the most recent test-report.md + the kinds still failing.

#### Simplify stage (v9 — author + skeptic + targeted re-test + revert-on-regression)

Only runs when phase size ≥ M (S/M sessions skip simplify and go straight to pre-PR verify).

##### simplify-author (round 1)

Dispatch `simplify-author-agent`:
- inputs: session_id, phase_id, plan_path, test_plan_path
- author creates a checkpoint commit (`chore(simplify): checkpoint pre-edit phase=<phase-id>`) BEFORE any edits.
- output: `phases/<phase-id>/simplify-report.md` + applied edits in the working tree

Read return value: `{status, checkpoint_sha, applied_count, flagged_count, re_test_kinds, surfaces_untouched_count, report_path}`.

If `applied_count == 0`: skip skeptic + re-test, advance to pre-PR verify.

##### simplify-skeptic (round 1)

Dispatch `simplify-skeptic-agent`:
- inputs: session_id, phase_id, plan_path, test_plan_path, simplify_report_path, checkpoint_sha
- skeptic appends a `## Skeptic review (round 1)` section to `simplify-report.md`.

Read return value: `{verdict, blocker_count, must_fix_count, nit_count}`.

- `verdict: approve` → advance to simplify-retest (or pre-PR verify if `re_test_kinds: []`).
- `verdict: request-changes` → dispatch simplify-author round 2.

##### simplify-author (round 2 — only if skeptic round 1 = request-changes)

Re-dispatch `simplify-author-agent` with the skeptic's comments:
- inputs: same as round 1, plus `prior_skeptic_comments_path = simplify-report.md`
- author addresses `[blocker]` and `[must-fix]` comments. Reuses the same `checkpoint_sha` (does `git reset --soft <sha>` and re-edits).

Then re-dispatch `simplify-skeptic-agent` (round 2).

- `verdict: approve` → advance to simplify-retest.
- `verdict: request-changes` after round 2 → **revert and skip simplify entirely**:
  ```bash
  git reset --hard <checkpoint_sha>~1
  ```
  Append `simplify: rejected-by-skeptic (round 2 still has blockers)` to `phases/<phase-id>/summary.md`. Advance to pre-PR verify. Do not bounce to refine — simplify is a polish pass, not a contract gate.

##### simplify-retest (targeted)

If author returned `re_test_kinds: []` → skip this step. Advance to pre-PR verify.

Otherwise, dispatch ONLY the per-kind runners named in `re_test_kinds`, in parallel (single message, multiple Task calls). Same wave-1 pattern as the main test stage:

```
For each kind in re_test_kinds:
  dispatch test-runner-<kind> with session_id, phase_id, plan_path, test_plan_path
```

Wait for the wave. Read each runner's `{verdict, failure_count, fix_targets, report_path}`.

- All runners `verdict: pass` → advance to pre-PR verify.
- Any runner `verdict: fail` → **revert simplify and skip**:
  ```bash
  git reset --hard <checkpoint_sha>~1
  ```
  Append `simplify: skipped-due-to-regression (kind=<failing-kind>)` to `phases/<phase-id>/summary.md`. Advance to pre-PR verify. **Do not dispatch refine-agent on simplify's re-test failures** — refine patches forward; the right move is to drop simplify's diff and continue with the pre-simplify state.

#### Verify stage (v11 — route-based dispatch)

Dispatch `verify-agent` with `autonomy_mode` passed in alongside the standard inputs.

Verify (v11) returns a `verdict` plus, on fail, a `routes_present` summary indicating which kinds of failures it found:

- `status: paused` (manual step) → surface, stop.
- `verdict: pass` → advance to Stage 5.
- `verdict: fail` → inspect `routes_present` and dispatch accordingly (see below).

##### Routing on verify-fail

The verify-fail handler chooses **one** of three paths based on `routes_present`:

**Path A — only `refine` route present** (all failures fixable by patching `src/**`):

Apply the v10 refine wrapper (same as before; nothing changes here):

1. **Set flag:** `touch sessions/active/<id>/.refine-active`.
2. **Checkpoint:** `git add -A && git commit -m "chore(refine): checkpoint round=<N> phase=<phase-id> loop=verify"`. Save sha as `<checkpoint_sha>`.
3. **Save prior failure set:** parse verification.md `## Failures (consolidated)` into a set of `(section, reason)` tuples.
4. **Dispatch refine-agent** with sources=[verification_path], round=N.
5. **Clear flag:** `rm sessions/active/<id>/.refine-active`.
6. Handle refine return (replan-needed → surface and stop; complete → continue).
7. **Re-dispatch verify-agent.**
8. **Compare** new verification.md failures to prior. Any new `(section, reason)` not in prior → regression → `git reset --hard <checkpoint_sha>~1` → fire `refine-regression-wall hit` (loop=verify) → stop.

Cap: **2 refine cycles** in the verify loop.

If 2 cycles exhausted with verdict still `fail` (no regression, but stuck): pause with `{reason: stuck, recommend: replan}`. Surface to user.

**Path B — any `replan` route present** (scope violation, declared test not built, plan-quality issue, deviation scope-creep, etc.):

Refine cannot fix these. Do not dispatch refine. Instead:

- Fire `verify-escalation hit` safeguard.
- Surface to user:
  ```
  [session: <id> | phase: <phase-id> | verify-escalation hit (route=replan)]
  verify-agent found <N> failures that require plan-level intervention (not patchable by refine).
  <list each failure with section, reason, what_missing, evidence>
  Recommended:
    /mar:iterate plan "<note>"          — adjust plan and rebuild
    /mar:revise research "<note>"       — back up further if research missed context
    /mar:replan                         — discard plan and start over
  ```
- Update `session.md`: `status: stuck-verify-replan`. Stop.

**Path C — any `user` route present** (unresolved `[QUESTION]` in autonomous mode, unchecked manual steps):

Refine cannot fix these either; they need human action. Do not dispatch refine. Instead:

- Fire `verify-escalation hit` safeguard.
- Surface to user:
  ```
  [session: <id> | phase: <phase-id> | verify-escalation hit (route=user)]
  verify-agent found <N> failures that require user action.
  <list each failure with section, reason, quoted item>
  Resolve the items above (answer questions in plan, complete manual steps, ...), then:
    /mar:continue ship                  — re-enter at verify
  ```
- Update `session.md`: `status: stuck-verify-user`. Stop.

**Mixed routes:** if both `replan` and `user` are present, Path C takes precedence (human action must come first). If both `refine` and `replan`/`user`, the non-refine routes take precedence (don't waste a refine cycle when escalation is required regardless).

##### Why route-based dispatch matters

In autonomous mode, the old "verify-fail → refine" path could spin a refine cycle on something refine can't fix (e.g., a declared test that was never built — now hook-blocked under v10). The route classification lets the orchestrator escalate immediately when refine isn't the right consumer, instead of waiting for refine to escalate via `replan-needed`.

## Step 3 — Stage 5: review-agent + tester-agent (parallel, iterative)

Once pre-PR verify passes, dispatch review-agent and tester-agent **in parallel** (single message, two Task tool calls). Both run in **PR mode** (v12) — they write to session `.md` files as source of truth AND post to the actual PR for human visibility.

```
[session: <id> | phase: <phase-id> | stage: verify → review+tester (round 1)]
```

### Dispatch (round N)

Read `pr` from `phases/<phase-id>/plan.md` frontmatter (populated at Step 2.2).

- **review-agent**:
  - inputs: session_id, phase_id, plan_path, deviations_path, mode=`pr`, pr_number=`<pr>`, round=N
  - output: `phases/<id>/review-comments.md` (session source of truth, new round overwrites prior — round N+1 references prior comments by reading the prior file before overwriting) AND inline PR comments via `gh pr review` (one PR review per round, encapsulating all inline comments + verdict)
- **tester-agent**:
  - inputs: session_id, phase_id, plan_path, mode=`pr`, pr_number=`<pr>`, round=N
  - output: `phases/<id>/tester-report.md` (session source of truth) AND a summary `gh pr comment` linking back to the session report

**Separation of concerns (v12):**
- Session `.md` files are the **canonical** source — refine reads from them, retrospect audits from them.
- PR comments are **one-way human-visible mirrors** — agents do NOT read PR comments back. The framework does not poll `gh pr comments` for user input.
- If the user wants to give input mid-loop, the explicit mechanisms remain: `/mar:iterate plan "<note>"`, `/mar:continue ship "<note>"`, or creating `phases/<id>/user-comments.md` (refine consumes it).

### Aggregation

When both return:

- review verdict = `approve` AND tester verdict = `pass` → advance to Step 4 (integrate gate).
- review verdict = `request-changes` OR tester verdict = `fail` → dispatch refine-agent (Step 3a).

### Step 3a — Refine within Stage 5 (v10 wrapper)

Print breadcrumb:
```
[session: <id> | phase: <phase-id> | stage: review+tester → refine (round N)]
```

Apply the v10 refine wrapper. Stage 5 has two concurrent failure surfaces (review + tester), so the regression check is the union: a new `[blocker]+[must-fix]` review comment OR a new failing tester scenario counts as regression.

1. **Set flag:** `touch sessions/active/<id>/.refine-active`.
2. **Checkpoint:** `git add -A && git commit -m "chore(refine): checkpoint round=<N> phase=<phase-id> loop=stage5"`. Save sha as `<checkpoint_sha>`.
3. **Save prior failure sets:**
   - `prior_review_count` = count of `[blocker]` + `[must-fix]` lines in current review-comments.md.
   - `prior_tester_scenarios` = set of failing scenario names parsed from current tester-report.md.
4. **Dispatch refine-agent:**
   - inputs: session_id, phase_id, plan_path, round=N
   - sources (whichever produced new comments this round):
     - review_comments_path (if review request-changes)
     - tester_report_path (if tester fail)
     - user_comments_path (optional — see "User intervention" below)
5. **Clear flag:** `rm sessions/active/<id>/.refine-active`.
6. Handle refine return:
   - `replan-needed` → surface, stop. Include `protected_surface_escalation` citation if present.
   - `complete` → continue.
7. **Re-dispatch review-agent and tester-agent in parallel** (round N+1).
8. **Compare:**
   - `new_review_count` = count of `[blocker]` + `[must-fix]` in new review-comments.md.
   - `new_tester_scenarios` = set of failing scenarios in new tester-report.md.
   - **Regression** if either:
     - `new_review_count > prior_review_count` (review got worse), OR
     - Any name in `new_tester_scenarios` is not in `prior_tester_scenarios` (tester regressed).
   - On regression:
     ```bash
     git reset --hard <checkpoint_sha>~1
     ```
     Fire `refine-regression-wall hit`:
     ```
     [session: <id> | phase: <phase-id> | refine-regression-wall hit (Stage 5 round <N>)]
     Refine introduced new issues not present in the prior round. Reverted to pre-refine checkpoint.
     Review delta: <prior_review_count> → <new_review_count>
     Tester regressions: <new_tester_scenarios - prior_tester_scenarios>
     Recommended: inspect review-comments.md and tester-report.md, then /mar:iterate plan if contract was wrong.
     ```
     Update `session.md`: `status: stuck-refine-regression`. Stop.

When refine + re-dispatch + comparison passes without regression:
- Increment round counter.
- Loop continues per the round caps below.

### Round caps (hardcoded)

- Review loop cap: **3 rounds**.
- Tester loop cap: **2 rounds**.

If caps exhausted with status still not clear → pause with summary:
```
[session: <id> | phase: <phase-id> | review-wall hit (round 3) | tester-wall hit (round N)]
Stage 5 did not converge. Outstanding:
  review: <K> [blocker]/[must-fix] open
  tester: <M> failures open
Surface to user. Recommended actions:
  - Inspect review-comments.md and tester-report.md.
  - /mar:iterate plan "<adjustment>" if the contract was wrong.
  - /mar:replan if scope/approach needs to change.
  - Manual edits + /mar:continue ship to re-enter at Step 3.
```

Update `session.md`: `status: stuck-review-wall` or `stuck-tester-wall`. Stop.

### User intervention (optional)

If a `phases/<id>/user-comments.md` file exists at start of a refine round, refine-agent reads it as an additional source. The user creates this file freely — no command needed. Refine treats user comments same as agent comments. After refine consumes them, archive the file: `mv user-comments.md user-comments.consumed-<ts>.md`.

## Step 4 — Integrate gate (branch by autonomy)

Once Stage 5 clears (review approve + tester pass), advance to integrate.

Update `session.md`: `current_stage: integrate`, `last_activity: now`.

### `interactive` / `normal` / `streamlined` — gate (pause)

Set `status: awaiting-approval`. Report:

```
[session: <id> | phase: <phase-id> | stage: review+tester → integrate (gate)]
Phase <phase-id> Stage 5 clear.
  pr: #<n> (draft) <pr_url>
  verify: pass
  review: approve (round <n>, <comments_count_total> comments resolved)
  tester: pass (round <n>, <scenarios_count> scenarios)

Next:
  /mar:integrate                            → run integrate-agent (commit story composition + .brain/ writeback proposals)
  /mar:iterate plan "<note>"                → adjust plan and rebuild (regenerates issue-body AND pr-body)
  /mar:replan                               → discard plan and start over

The merge itself happens at /mar:approve integrate (v12) — gh pr merge --squash
with integrate-agent's composed commit message. The PR stays draft until then.
```

Stop.

### `autonomous` — skip gate, continue

Log timeline: `<ts> autonomous auto-dispatching integrate`. Inline-dispatch `/mar:integrate`'s pipeline.

`/mar:integrate` produces INTEGRATION.md (commit story composition). Autonomous skips `.brain/` writebacks (per v2 spec).

After integrate-agent returns, autonomous mode also runs the equivalent of `/mar:approve integrate`'s merge logic (see `approve.md` → `integrate` action): `gh pr merge --squash` with the composed commit message. Pre-check `mergeStateStatus` must be `CLEAN`; on any failure, fire `gh-pr-failure hit` safeguard and stop.

## Step 5 — Between-phase handling (L/XL only)

After integrate completes for a phase, if more phases remain, branch on `autonomy`:
- `interactive` / `normal`: stop and report: `Phase complete. Next phase: <id>. Run /mar:plan to proceed. (You're still on the merged 'phase/<prev-id>' branch; run 'git checkout <default> && git pull' first.)`.
- `streamlined` / `autonomous`: **branch reset** (v0.13.1) — orchestrator runs:
  ```bash
  git checkout <DEFAULT_BRANCH>
  git pull --ff-only origin <DEFAULT_BRANCH>
  ```
  Then between-phase compaction (orchestrator main thread compacts, retains meta-plan + last phase's summary). Then auto-run `/mar:plan` for the next phase. The next `/mar:ship` will then hit case (b) of the branch precondition and create `phase/<next-id>` cleanly. No ack pause.

After the final phase integrates: stop. Report session summary.

## Always-on safeguards (every mode)

These pause regardless of autonomy:
- Manual step unmet
- Scope violation (PreToolUse hook fired)
- **Refine-protected surface write attempt** (v10) — refine tried to write to a contract surface (tests, fixtures, snapshots, eval data); the hook denied it. Refine should return `replan-needed` with citation; if it retries, surface and stop.
- Test-fail after refine loop exhausted (build loop)
- Replan requested
- **execute-step-wall hit** (v7) — a single step's internal iteration cap (3) was exhausted. Surfaces step number + failed verify command output.
- **Review-wall** (Stage 5 review cap exhausted)
- **Tester-fail-cap** (Stage 5 tester cap exhausted)
- **refine-regression-wall hit** (v10) — a refine round introduced a failure that was not present before refine ran. Orchestrator reverts to the pre-refine checkpoint and surfaces the regression details. Fires in any of the four refine loops (build, verify, Stage 5 review, Stage 5 tester).
- **verify-escalation hit** (v11) — verify-agent returned failures that route to `replan` or `user` (not refinable). Orchestrator does NOT dispatch refine; instead it surfaces the escalation with the failure details so the user (or, in autonomous mode, this safeguard) takes plan-level or human action.
- **gh-pr-failure hit** (v12) — any `gh` PR operation returned non-zero: `create-phase-pr.sh` at Stage 2.2, `git push` on clean-round, `gh pr edit` (during plan iterate), `gh pr review` / `gh pr comment` (Stage 5 PR-mode posts), or `gh pr merge` (at integrate). Always fires; the script/orchestrator surfaces the gh stderr verbatim plus a remediation hint where one is recognizable.
- Unresolved `[QUESTION]` on plan in autonomous mode
- Secret-file write attempt
- `derive-issue-body.py` failure (if iterate-plan happens mid-ship)

## Rules

- Stop conditions in every mode: see "Always-on safeguards" above.
- `interactive` / `normal` / `streamlined`: never commit from `/mar:ship` — commit happens via `/mar:integrate` → `/mar:approve integrate`.
- `autonomous`: `/mar:ship` auto-dispatches integrate at Step 4 — but Step 1 autonomous does NOT push or open a PR (Step 2 adds that).
- Keep the main session context lean — workers carry the heavy context.
- Compact between phases for L/XL (mandatory).
- Stage 5 round counters increment only after a refine checkpoint, not on each agent dispatch.
