"""Adapter for the Claude Code harness.

Claude Code reads:
- Subagents from `.claude/agents/*.md`
- Slash commands from `.claude/commands/<namespace>/*.md`
- Settings (hooks, permissions, env) from `.claude/settings.json`

This adapter validates that manifest targets land within those conventions
and provides merge strategies for `.claude/settings.json` (where mar owns
its hook entries) and `.gitignore` (where mar appends its known entries).
"""

from __future__ import annotations

import json
from typing import Any

from mar.adapters.base import Adapter, MergeStrategy


class ClaudeSettingsMerge(MergeStrategy):
    """Merge mar's hook entries into .claude/settings.json.

    Mar tags each entry it owns with the sentinel key `_mar` (value is the
    mar version that installed it). On merge:

    - Top-level keys mar owns (`$schema`, `hooks`) come from the framework.
    - Top-level keys mar doesn't own (`permissions`, `env`, `allowedTools`,
      anything else) are kept verbatim from the existing file.
    - Within `hooks`, each hook array is reconciled: previously-mar-tagged
      entries are stripped, user-added entries are kept, fresh mar-tagged
      entries from the framework are appended.

    The result is idempotent: re-merging with the same framework content
    yields the same output.
    """

    MAR_KEY = "_mar"
    FRAMEWORK_OWNED_TOP_LEVEL_KEYS: frozenset[str] = frozenset({"$schema", "hooks"})

    def merge(
        self,
        existing: str | None,
        framework: str,
        context: dict[str, Any],
    ) -> str:
        existing_data: dict[str, Any] = json.loads(existing) if existing else {}
        framework_data: dict[str, Any] = json.loads(framework)

        merged: dict[str, Any] = {}

        # Top-level keys not owned by mar pass through from existing
        for key, value in existing_data.items():
            if key not in self.FRAMEWORK_OWNED_TOP_LEVEL_KEYS:
                merged[key] = value

        # mar-owned top-level keys come from framework, except hooks which
        # require per-array reconciliation to preserve user-added entries.
        for key, value in framework_data.items():
            if key == "hooks":
                merged["hooks"] = self._merge_hooks(
                    existing_data.get("hooks", {}), value
                )
            elif key in self.FRAMEWORK_OWNED_TOP_LEVEL_KEYS:
                merged[key] = value

        return json.dumps(merged, indent=2) + "\n"

    def _merge_hooks(
        self,
        existing_hooks: dict[str, Any],
        framework_hooks: dict[str, Any],
    ) -> dict[str, Any]:
        """Reconcile each hook array independently.

        Iteration order is deterministic: framework keys first (preserving the
        spec's intentional hook order), then any user-only keys after in their
        existing-dict order. Avoids `set(...)` iteration which is sensitive to
        PYTHONHASHSEED and produces different output across runs.
        """
        ordered_keys: list[str] = list(framework_hooks)
        for k in existing_hooks:
            if k not in framework_hooks:
                ordered_keys.append(k)

        result: dict[str, list[Any]] = {}
        for hook_name in ordered_keys:
            user_entries = [
                e
                for e in existing_hooks.get(hook_name, [])
                if not self._is_mar_owned(e)
            ]
            framework_entries = list(framework_hooks.get(hook_name, []))
            combined = user_entries + framework_entries
            if combined:
                result[hook_name] = combined
        return result

    def _is_mar_owned(self, entry: Any) -> bool:
        return isinstance(entry, dict) and self.MAR_KEY in entry

    def extract_owned(self, content: str) -> str | None:
        try:
            data = json.loads(content)
        except json.JSONDecodeError:
            return None

        owned_hooks: dict[str, list[Any]] = {}
        for hook_name, entries in data.get("hooks", {}).items():
            mar_entries = [e for e in entries if self._is_mar_owned(e)]
            if mar_entries:
                owned_hooks[hook_name] = mar_entries

        if not owned_hooks:
            return None
        return json.dumps({"hooks": owned_hooks}, indent=2, sort_keys=True)


class GitignoreAppendMerge(MergeStrategy):
    """Append mar's known entries to .gitignore inside a managed block.

    The managed block is delimited by sentinel comments so mar can replace
    it cleanly on `mar update` without disturbing user-added entries.
    """

    MAR_MARKER_BEGIN = "# >>> mar managed >>>"
    MAR_MARKER_END = "# <<< mar managed <<<"

    def merge(
        self,
        existing: str | None,
        framework: str,
        context: dict[str, Any],
    ) -> str:
        existing_lines = (existing or "").splitlines()
        cleaned = self._strip_managed_block(existing_lines)

        framework_lines = framework.strip().splitlines()
        block = [self.MAR_MARKER_BEGIN, *framework_lines, self.MAR_MARKER_END]

        if cleaned and cleaned[-1] != "":
            cleaned.append("")
        result = cleaned + block

        return "\n".join(result).rstrip() + "\n"

    def extract_owned(self, content: str) -> str | None:
        lines = content.splitlines()
        try:
            start = lines.index(self.MAR_MARKER_BEGIN)
            end = lines.index(self.MAR_MARKER_END)
        except ValueError:
            return None
        return "\n".join(lines[start + 1 : end])

    def _strip_managed_block(self, lines: list[str]) -> list[str]:
        result: list[str] = []
        inside = False
        for line in lines:
            if line == self.MAR_MARKER_BEGIN:
                inside = True
                if result and result[-1] == "":
                    result.pop()
                continue
            if line == self.MAR_MARKER_END:
                inside = False
                continue
            if not inside:
                result.append(line)
        return result


class ClaudeCodeAdapter(Adapter):
    """Install layout for Claude Code."""

    name = "claude"

    #: Directory prefixes (trailing slash) where framework files may land.
    ALLOWED_DIR_PREFIXES: tuple[str, ...] = (
        ".claude/",
        ".brain/",
        ".mm/",
        "ops/",
        "research/",
        "sessions/",
    )

    #: Specific top-level files framework targets are allowed to write.
    ALLOWED_FILES: frozenset[str] = frozenset({"CLAUDE.md", ".gitignore"})

    def validate_target(self, target: str) -> None:
        if target in self.ALLOWED_FILES:
            return
        if any(target.startswith(prefix) for prefix in self.ALLOWED_DIR_PREFIXES):
            return
        raise ValueError(
            f"target {target!r} is not within an allowed path for the Claude Code adapter; "
            f"allowed: {sorted(self.ALLOWED_FILES)} or under "
            f"{list(self.ALLOWED_DIR_PREFIXES)}"
        )

    def merge_strategies(self) -> dict[str, MergeStrategy]:
        return {
            "claude_settings": ClaudeSettingsMerge(),
            "gitignore_append": GitignoreAppendMerge(),
        }
