import ssl
from enum import Enum
from gl_connectors_tools.tools import BaseTool as BaseTool
from pydantic import BaseModel
from typing import Any, Callable, Literal

class HttpMethod(str, Enum):
    """HTTP methods supported by the REST API tool."""
    GET = 'GET'
    POST = 'POST'
    PUT = 'PUT'
    PATCH = 'PATCH'
    DELETE = 'DELETE'
    HEAD = 'HEAD'
    OPTIONS = 'OPTIONS'

class ParameterLocation(str, Enum):
    """Location of API parameters."""
    PATH = 'path'
    QUERY = 'query'
    HEADER = 'header'
    COOKIE = 'cookie'
    BODY = 'body'

class ApiParameter(BaseModel):
    """Represents an API parameter with its metadata."""
    name: str
    py_name: str
    location: ParameterLocation
    required: bool
    description: str
    param_type: str
    default: Any

class RestApiEndpoint(BaseModel):
    """Defines a REST API endpoint configuration."""
    base_url: str
    path: str
    method: HttpMethod

class AuthConfig(BaseModel):
    """Authentication configuration for the REST API."""
    auth_type: Literal['none', 'bearer', 'api_key', 'basic']
    token: str | None
    api_key_header: str
    username: str | None
    password: str | None

class RestApiTool(BaseTool):
    '''A generic tool that interacts with REST APIs.

    Generates request params and body, handles authentication, and makes HTTP
    requests to REST API endpoints.

    Example:
        ```python
        from gl_connectors_tools.predefined import RestApiTool, RestApiEndpoint, ApiParameter
        from gl_connectors_tools.adapters import to_gllm_tool, to_langchain_tool

        # Define the endpoint
        endpoint = RestApiEndpoint(
            base_url="https://api.example.com",
            path="/users/{user_id}",
            method="GET"
        )

        # Define parameters
        parameters = [
            ApiParameter(
                name="user_id",
                py_name="user_id",
                location="path",
                required=True,
                description="The user\'s ID",
                param_type="string"
            ),
            ApiParameter(
                name="include_details",
                py_name="include_details",
                location="query",
                required=False,
                description="Include extra details",
                param_type="boolean"
            )
        ]

        tool = RestApiTool(
            name="get_user",
            description="Get user information by ID",
            endpoint=endpoint,
            parameters=parameters
        )

        # Use directly
        result = tool.run(user_id="123", include_details=True)

        # Convert to GLLM Core
        gllm_tool = to_gllm_tool(tool)

        # Convert to LangChain
        lc_tool = to_langchain_tool(tool)
        ```
    '''
    name: str
    description: str
    input_schema: type[BaseModel] | None
    def __init__(self, name: str, description: str, endpoint: RestApiEndpoint | dict[str, Any], parameters: list[ApiParameter] | list[dict[str, Any]] | None = None, *, auth_config: AuthConfig | dict[str, Any] | None = None, default_headers: dict[str, str] | None = None, ssl_verify: bool | str | ssl.SSLContext | None = None, timeout: float = 30.0, header_provider: Callable[[], dict[str, str]] | None = None) -> None:
        """Initialize the RestApiTool.

        Args:
            name: The name of the tool.
            description: The description of the tool.
            endpoint: The REST API endpoint configuration.
            parameters: List of API parameters.
            auth_config: Authentication configuration.
            default_headers: Default headers for all requests.
            ssl_verify: SSL verification setting.
            timeout: Request timeout in seconds.
            header_provider: Callable that provides dynamic headers.
        """
    @classmethod
    def from_openapi_operation(cls, operation: dict[str, Any], endpoint: dict[str, Any], *, auth_config: AuthConfig | dict[str, Any] | None = None, **kwargs: Any) -> RestApiTool:
        """Create a RestApiTool from an OpenAPI operation spec.

        Args:
            operation: OpenAPI operation object.
            endpoint: Endpoint information (base_url, path, method).
            auth_config: Authentication configuration.
            **kwargs: Additional arguments passed to the constructor.

        Returns:
            A configured RestApiTool instance.
        """
    def run(self, **kwargs: Any) -> dict[str, Any]:
        """Execute the REST API call synchronously.

        Args:
            **kwargs: Arguments matching the API parameters.

        Returns:
            The API response as a dictionary.
        """
    async def arun(self, **kwargs: Any) -> dict[str, Any]:
        """Execute the REST API call asynchronously.

        Args:
            **kwargs: Arguments matching the API parameters.

        Returns:
            The API response as a dictionary.
        """
    def set_auth(self, auth_config: AuthConfig | dict[str, Any]) -> None:
        """Update the authentication configuration.

        Args:
            auth_config: New authentication configuration.
        """
    def set_default_headers(self, headers: dict[str, str]) -> None:
        """Set default headers for all requests.

        Args:
            headers: Dictionary of headers.
        """
