from gl_connectors_tools.tools import BaseTool as BaseTool
from pydantic import BaseModel
from typing import Any, Callable

class FunctionTool(BaseTool):
    '''A tool that wraps a user-defined Python function.

    Automatically extracts name, description, and input schema from the function
    signature and docstring. Supports both sync and async functions.

    Example:
        ```python
        from gl_connectors_tools.predefined import FunctionTool
        from gl_connectors_tools.adapters import to_gllm_tool, to_langchain_tool

        def greet(name: str, greeting: str = "Hello") -> str:
            """Greet someone.

    Args:
                name: The person\'s name.
                greeting: The greeting to use.

    Returns:
                A greeting message.
            """
            return f"{greeting}, {name}!"

        tool = FunctionTool(greet)

        # Use directly
        result = tool.run(name="Alice")

        # Convert to GLLM Core
        gllm_tool = to_gllm_tool(tool)

        # Convert to LangChain
        lc_tool = to_langchain_tool(tool)
        ```
    '''
    name: str
    description: str
    input_schema: type[BaseModel] | None
    def __init__(self, func: Callable[..., Any], *, name: str | None = None, description: str | None = None) -> None:
        """Initialize the FunctionTool.

        Args:
            func: The function to wrap.
            name: Optional custom name. Defaults to the function's __name__.
            description: Optional custom description. Defaults to the function's docstring.
        """
    def run(self, **kwargs: Any) -> Any:
        """Execute the wrapped function synchronously.

        Args:
            **kwargs: Arguments to pass to the wrapped function.

        Returns:
            The result of the function execution.
        """
    async def arun(self, **kwargs: Any) -> Any:
        """Execute the wrapped function asynchronously.

        Supports both sync and async wrapped functions.

        Args:
            **kwargs: Arguments to pass to the wrapped function.

        Returns:
            The result of the function execution.
        """
