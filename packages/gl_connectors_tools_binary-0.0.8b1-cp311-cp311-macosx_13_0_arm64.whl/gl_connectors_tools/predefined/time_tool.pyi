from gl_connectors_tools.tools import BaseTool as BaseTool
from pydantic import BaseModel

FORMAT_STRING: str
DEFAULT_TIMEZONE: str

class TimeToolInput(BaseModel):
    """Input schema for the TimeTool."""
    datetime_format: str
    timezone: str | None

class TimeTool(BaseTool):
    '''Tool to get the current time.

    Example:
        ```python
        from gl_connectors_tools.predefined import TimeTool
        from gl_connectors_tools.adapters import to_gllm_tool, to_langchain_tool

        tool = TimeTool()

        # Use directly
        result = tool.run(timezone="Asia/Jakarta")

        # Convert to GLLM Core
        gllm_tool = to_gllm_tool(tool)

        # Convert to LangChain
        lc_tool = to_langchain_tool(tool)
        ```
    '''
    name: str
    description: str
    input_schema: type[BaseModel]
    def run(self, datetime_format: str = ..., timezone: str | None = ...) -> str:
        """Get current time formatted according to the specified format and timezone.

        Args:
            datetime_format: Format string for datetime (default: ISO format).
            timezone: Timezone string (default: UTC+7).

        Returns:
            Formatted datetime string.
        """
