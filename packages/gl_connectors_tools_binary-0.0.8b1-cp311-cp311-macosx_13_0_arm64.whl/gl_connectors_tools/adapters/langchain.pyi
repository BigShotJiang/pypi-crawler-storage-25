from _typeshed import Incomplete
from gl_connectors_tools.tools.base import BaseTool as BaseTool
from langchain_core.tools import BaseTool as LCBaseTool, StructuredTool
from typing import Any

def to_langchain_tool(tool: BaseTool) -> StructuredTool:
    '''Convert an SDK BaseTool to a LangChain StructuredTool.

    Args:
        tool: The SDK tool to convert.

    Returns:
        A LangChain StructuredTool instance.

    Example:
        ```python
        from gl_connectors_tools.tools import BaseTool
        from gl_connectors_tools.adapters import to_langchain_tool

        class MyTool(BaseTool):
            name = "my_tool"
            description = "Does something"
            input_schema = MyInput

            def run(self, **kwargs):
                return "result"

        lc_tool = to_langchain_tool(MyTool())
        ```
    '''
def to_langchain_tools(tools: list['BaseTool']) -> list['StructuredTool']:
    """Convert multiple SDK BaseTools to LangChain StructuredTools.

    Args:
        tools: List of SDK tools to convert.

    Returns:
        List of LangChain StructuredTool instances.
    """
def from_langchain_tool(langchain_tool: LCBaseTool | StructuredTool) -> BaseTool:
    '''Convert a LangChain tool to an SDK BaseTool.

    This creates a new SDK tool that wraps the LangChain tool\'s functionality.

    Args:
        langchain_tool: The LangChain BaseTool or StructuredTool to convert.

    Returns:
        An SDK BaseTool instance.

    Example:
        ```python
        from langchain_core.tools import StructuredTool
        from gl_connectors_tools.adapters import from_langchain_tool

        # Existing LangChain tool
        lc_tool = StructuredTool.from_function(
            func=lambda x: f"Hello {x}",
            name="greet",
            description="Greets someone"
        )

        # Convert to SDK tool
        sdk_tool = from_langchain_tool(lc_tool)
        ```
    '''
def from_langchain_tools(langchain_tools: list[LCBaseTool | StructuredTool]) -> list['BaseTool']:
    """Convert multiple LangChain tools to SDK BaseTools.

    Args:
        langchain_tools: List of LangChain tools to convert.

    Returns:
        List of SDK BaseTool instances.
    """

class LangChainToolWrapper:
    '''Wrapper that adapts an existing LangChain BaseTool to SDK BaseTool interface.

    Use this for migrating existing LangChain tools to the SDK without rewriting.
    For new tools, prefer inheriting from SDK\'s BaseTool directly.

    Example:
        ```python
        from langchain_core.tools import BaseTool as LCBaseTool
        from gl_connectors_tools.adapters.langchain import LangChainToolWrapper

        # Existing LangChain tool
        class OldTool(LCBaseTool):
            name = "old_tool"
            description = "Legacy tool"
            args_schema = OldInput

            def _run(self, **kwargs):
                return "result"

        # Wrap it for SDK compatibility
        sdk_tool = LangChainToolWrapper(OldTool())
        ```
    '''
    name: str
    description: str
    input_schema: Incomplete
    def __init__(self, langchain_tool: Any) -> None:
        """Initialize wrapper with a LangChain tool.

        Args:
            langchain_tool: The LangChain BaseTool instance to wrap.
        """
    def run(self, **kwargs: Any) -> Any:
        """Execute the wrapped tool synchronously."""
    async def arun(self, **kwargs: Any) -> Any:
        """Execute the wrapped tool asynchronously."""
