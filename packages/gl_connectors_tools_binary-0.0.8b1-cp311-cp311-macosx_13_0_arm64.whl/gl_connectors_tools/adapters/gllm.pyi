from gl_connectors_tools.tools.base import BaseTool as BaseTool
from gllm_core.schema.tool import Tool as GllmTool

def to_gllm_tool(tool: BaseTool) -> GllmTool:
    '''Convert an SDK BaseTool to a GLLM Core Tool.

    Args:
        tool: The SDK tool to convert.

    Returns:
        A GLLM Core Tool instance ready for inference.

    Example:
        ```python
        from gl_connectors_tools.tools import BaseTool
        from gl_connectors_tools.adapters import to_gllm_tool

        class MyTool(BaseTool):
            name = "my_tool"
            description = "Does something"
            input_schema = MyInput

            def run(self, **kwargs):
                return "result"

        gllm_tool = to_gllm_tool(MyTool())
        ```
    '''
def to_gllm_tools(tools: list['BaseTool']) -> list['GllmTool']:
    """Convert multiple SDK BaseTools to GLLM Core Tools.

    Args:
        tools: List of SDK tools to convert.

    Returns:
        List of GLLM Core Tool instances.
    """
def from_gllm_tool(gllm_tool: GllmTool) -> BaseTool:
    '''Convert a GLLM Core Tool to an SDK BaseTool.

    This creates a new SDK tool that wraps the GLLM Core tool\'s functionality.

    Args:
        gllm_tool: The GLLM Core Tool to convert.

    Returns:
        An SDK BaseTool instance.

    Example:
        ```python
        from gllm_core.schema.tool import Tool as GllmTool
        from gl_connectors_tools.adapters import from_gllm_tool

        # Existing GLLM tool
        gllm_tool = GllmTool(
            name="greet",
            description="Greets someone",
            input_schema=MyInput,
            func=lambda name: f"Hello {name}"
        )

        # Convert to SDK tool
        sdk_tool = from_gllm_tool(gllm_tool)
        ```
    '''
def from_gllm_tools(gllm_tools: list['GllmTool']) -> list['BaseTool']:
    """Convert multiple GLLM Core Tools to SDK BaseTools.

    Args:
        gllm_tools: List of GLLM Core tools to convert.

    Returns:
        List of SDK BaseTool instances.
    """
