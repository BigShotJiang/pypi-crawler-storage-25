from gl_connectors_tools.tools.base import BaseTool as BaseTool
from google.genai.types import FunctionDeclaration
from typing import Any, Callable

def to_adk_function(tool: BaseTool) -> tuple[Any, Callable[..., Any]]:
    '''Convert an SDK BaseTool to a Google ADK FunctionDeclaration and callable.

    Args:
        tool: The SDK tool to convert.

    Returns:
        A tuple of (FunctionDeclaration, callable) for use with ADK.

    Example:
        ```python
        from gl_connectors_tools.tools import BaseTool
        from gl_connectors_tools.adapters import to_adk_function

        class MyTool(BaseTool):
            name = "my_tool"
            description = "Does something"
            input_schema = MyInput

            def run(self, **kwargs):
                return "result"

        func_decl, callable_fn = to_adk_function(MyTool())
        ```
    '''
def to_adk_functions(tools: list['BaseTool']) -> list[tuple[Any, Callable[..., Any]]]:
    """Convert multiple SDK BaseTools to ADK FunctionDeclarations.

    Args:
        tools: List of SDK tools to convert.

    Returns:
        List of (FunctionDeclaration, callable) tuples.
    """
def from_adk_function(function_declaration: FunctionDeclaration, func: Callable[..., Any]) -> BaseTool:
    '''Convert a Google ADK FunctionDeclaration and callable to an SDK BaseTool.

    Note: ADK FunctionDeclarations only contain metadata, not the actual callable.
    You must provide the callable function separately.

    Args:
        function_declaration: The ADK FunctionDeclaration containing metadata.
        func: The callable function that implements the tool logic.

    Returns:
        An SDK BaseTool instance.

    Example:
        ```python
        from google.genai.types import FunctionDeclaration
        from gl_connectors_tools.adapters import from_adk_function

        # Existing ADK function declaration
        func_decl = FunctionDeclaration(
            name="greet",
            description="Greets someone",
            parameters={
                "type": "object",
                "properties": {
                    "name": {"type": "string"}
                }
            }
        )

        def greet_impl(name: str) -> str:
            return f"Hello {name}"

        # Convert to SDK tool
        sdk_tool = from_adk_function(func_decl, greet_impl)
        ```
    '''
def from_adk_functions(function_declarations: list[tuple['FunctionDeclaration', Callable[..., Any]]]) -> list['BaseTool']:
    """Convert multiple ADK FunctionDeclarations to SDK BaseTools.

    Args:
        function_declarations: List of (FunctionDeclaration, callable) tuples.

    Returns:
        List of SDK BaseTool instances.
    """
