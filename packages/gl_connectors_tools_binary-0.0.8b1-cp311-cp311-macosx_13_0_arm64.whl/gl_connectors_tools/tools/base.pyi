from abc import ABC
from pydantic import BaseModel as BaseModel
from typing import Any

class BaseTool(ABC):
    '''Framework-agnostic base class for all SDK tools.

    This is the core abstraction that decouples tool implementations from specific
    frameworks. Tools inherit from this class and implement the `run` (or `_run`)
    method. Adapters then convert SDK tools to framework-specific formats.

    Supports both SDK naming and LangChain naming for zero-change migration:
        - `input_schema` or `args_schema` for input schema
        - `run` or `_run` for sync execution
        - `arun` or `_arun` for async execution

    Attributes:
        name: Unique identifier for the tool.
        description: Human-readable description of what the tool does.
        input_schema: Pydantic model defining the expected input parameters.
            Also accepts `args_schema` for LangChain compatibility.

    Example (SDK style):
        ```python
        from pydantic import BaseModel, Field
        from gl_connectors_tools.tools import BaseTool

        class GreetInput(BaseModel):
            name: str = Field(description="Name to greet")

        class GreetTool(BaseTool):
            name = "greet"
            description = "Greets a person by name"
            input_schema = GreetInput

            def run(self, name: str) -> str:
                return f"Hello, {name}!"
        ```

    Example (LangChain style - zero-change migration):
        ```python
        from pydantic import BaseModel, Field
        from gl_connectors_tools.tools import BaseTool  # Just change this import!

        class GreetInput(BaseModel):
            name: str = Field(description="Name to greet")

        class GreetTool(BaseTool):
            name = "greet"
            description = "Greets a person by name"
            args_schema = GreetInput  # LangChain naming works!

            def _run(self, name: str) -> str:  # LangChain naming works!
                return f"Hello, {name}!"
        ```
    '''
    name: str
    description: str
    input_schema: type[BaseModel] | None
    args_schema: type[BaseModel] | None
    def get_input_schema(self) -> type[BaseModel]:
        """Get the input schema, supporting both SDK and LangChain naming.

        Returns:
            The Pydantic model for input validation.

        Raises:
            ValueError: If neither input_schema nor args_schema is defined.
        """
    def run(self, **kwargs: Any) -> Any:
        """Execute the tool synchronously.

        Override this method OR `_run` for LangChain compatibility.

        Args:
            **kwargs: Input parameters matching the input_schema definition.

        Returns:
            The result of the tool execution.
        """
    async def arun(self, **kwargs: Any) -> Any:
        """Execute the tool asynchronously.

        Override this method OR `_arun` for LangChain compatibility.
        By default, this delegates to the synchronous execution.

        Args:
            **kwargs: Input parameters matching the input_schema definition.

        Returns:
            The result of the tool execution.
        """
    def validate_input(self, **kwargs: Any) -> BaseModel:
        """Validate input against the input_schema.

        Args:
            **kwargs: Input parameters to validate.

        Returns:
            Validated Pydantic model instance.

        Raises:
            ValidationError: If input doesn't match the schema.
        """
