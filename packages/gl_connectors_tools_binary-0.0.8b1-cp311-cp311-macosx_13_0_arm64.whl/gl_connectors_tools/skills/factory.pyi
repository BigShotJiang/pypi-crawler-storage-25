from _typeshed import Incomplete
from gl_connectors_tools.skills.sources.clawhub_source import ClawHubSource as ClawHubSource
from gl_connectors_tools.skills.sources.github_source import GitHubSource as GitHubSource
from gl_connectors_tools.skills.sources.skill_source import SkillSource as SkillSource
from pathlib import Path
from typing import Any, Generator

class SkillRequest:
    '''Awaitable skill installation request.

    Represents a pending skill installation that can be:

    1. **Awaited directly** for immediate execution (single installation)
    2. **Passed to create_multiple()** for batch execution (multiple installations)

    Important:
        Do NOT instantiate this class directly. Use factory methods:

        - :meth:`SkillFactory.from_github` for GitHub sources
        - :meth:`SkillFactory.create_skill` for custom sources

    Attributes:
        source_type: The SkillSource subclass to use for fetching.
        source: Source identifier (URL, repo path, etc.).
        destination: List of installation target paths.
        zipped: Whether to zip the installed skill.
        construct_params: Constructor parameters for the source instance.
        kwargs: Additional keyword arguments passed to fetch().

    Example:
        .. code-block:: python

            # Single installation - await the request
            paths = await SkillFactory.from_github("owner/repo", ["/dest"])
            print(f"Installed to: {paths}")

            # Batch installation - pass requests, await the batch
            results = await SkillFactory.create_multiple(
                SkillFactory.from_github("owner/repo", ["/dest"], directory="skill1"),
                SkillFactory.from_github("owner/repo", ["/dest"], directory="skill2"),
            )
            # results[0] = paths for skill1, results[1] = paths for skill2
    '''
    source_type: Incomplete
    source: Incomplete
    destination: Incomplete
    zipped: Incomplete
    name: Incomplete
    overwrite: Incomplete
    construct_params: Incomplete
    kwargs: Incomplete
    def __init__(self, source_type: type[SkillSource], source: str, destination: list[str], zipped: bool = False, name: str | None = None, overwrite: bool = False, construct_params: dict[str, Any] | None = None, kwargs: dict[str, Any] | None = None) -> None:
        """Initialize a skill request.

        Note:
            Use :meth:`SkillFactory.from_github` or :meth:`SkillFactory.create_skill`
            instead of instantiating directly.

        Args:
            source_type: SkillSource subclass for fetching the skill.
            source: Source identifier (URL, repo path, etc.).
            destination: List of installation target paths.
            zipped: Whether to zip the installed skill. Defaults to False.
            name: Custom installation folder name. Defaults to None.
            overwrite: Whether to overwrite existing files. Defaults to False.
            construct_params: Constructor parameters for source_type. Defaults to None.
            kwargs: Additional keyword arguments for fetch(). Defaults to None.
        """
    def __await__(self) -> Generator[Any, None, list[Path]]:
        '''Make SkillRequest awaitable for direct execution.

        When awaited, executes the skill installation and returns the
        installed paths.

        Returns:
            Generator yielding list[Path] of installed skill paths.

        Example:
            .. code-block:: python

                paths = await SkillFactory.from_github("owner/repo", [dest])
        '''

class SkillResult:
    """Result of a single skill installation within a batch.

    Attributes:
        request: The original SkillRequest.
        paths: Installed paths if successful, None if failed.
        error: The exception if failed, None if successful.
    """
    request: Incomplete
    paths: Incomplete
    error: Incomplete
    def __init__(self, request: SkillRequest, paths: list[Path] | None = None, error: BaseException | None = None) -> None: ...
    @property
    def ok(self) -> bool:
        """Whether this skill installed successfully."""

class BatchResult:
    '''Result of a batch skill installation via :meth:`SkillFactory.create_multiple`.

    Provides access to per-request results, with convenience properties to
    separate successes from failures.

    Example:
        .. code-block:: python

            result = await SkillFactory.create_multiple(req1, req2, req3)

            for r in result.succeeded:
                print(f"Installed {r.request.source} to {r.paths}")

            for r in result.failed:
                print(f"Failed {r.request.source}: {r.error}")
    '''
    def __init__(self, results: list[SkillResult]) -> None: ...
    @property
    def succeeded(self) -> list[SkillResult]:
        """Results for skills that installed successfully."""
    @property
    def failed(self) -> list[SkillResult]:
        """Results for skills that failed to install."""
    @property
    def has_failures(self) -> bool:
        """Whether any skill in the batch failed."""
    def __iter__(self):
        """Iterate over all results in request order."""
    def __len__(self) -> int: ...

class SkillFactory:
    '''Factory for creating and installing skills.

    Provides methods to create skill installation requests from various sources.
    All methods return awaitable :class:`SkillRequest` objects.

    Usage Patterns:
        **Single Installation** - Await the factory method directly:

        .. code-block:: python

            paths = await SkillFactory.from_github("owner/repo", [dest])

        **Batch Installation** - Pass requests to create_multiple(), then await:

        .. code-block:: python

            result = await SkillFactory.create_multiple(
                SkillFactory.from_github("owner/repo", [dest], directory="skill1"),
                SkillFactory.from_github("owner/repo", [dest], directory="skill2"),
            )

            for r in result.succeeded:
                print(f"Installed to {r.paths}")

            for r in result.failed:
                print(f"Failed: {r.error}")

    Important:
        When using ``create_multiple()``, do NOT await individual requests.
        Pass the unawaited :class:`SkillRequest` objects directly.
    '''
    @classmethod
    def create_skill(cls, source_type: type[SkillSource], source: str, destination: list[str], *, zipped: bool = False, name: str | None = None, overwrite: bool = False, construct_params_: dict[str, Any] | None = None, **kwargs) -> SkillRequest:
        '''Create a skill installation request from a custom source type.

        Returns an awaitable :class:`SkillRequest`. Use this for custom
        SkillSource implementations. For GitHub, use :meth:`from_github`.

        Args:
            source_type: SkillSource subclass to use for fetching.
            source: Source identifier or URL.
            destination: List of installation target paths.
            zipped: Whether to zip the installed skill. Defaults to False.
            name: Custom installation folder name. Defaults to None.
            overwrite: Whether to overwrite existing files. Defaults to False.
            construct_params_: Constructor parameters for source_type. Defaults to None.
            **kwargs: Additional source-specific options passed to fetch().

        Returns:
            Awaitable request object. Await for single install, or pass to
            :meth:`create_multiple` for batch install.

        Example:
            .. code-block:: python

                from my_sources import CustomSource

                # Single installation
                paths = await SkillFactory.create_skill(
                    CustomSource,
                    "my-skill-id",
                    ["/path/to/dest"],
                )

                # Batch installation
                await SkillFactory.create_multiple(
                    SkillFactory.create_skill(CustomSource, "skill1", [dest]),
                    SkillFactory.create_skill(CustomSource, "skill2", [dest]),
                )
        '''
    @classmethod
    def from_github(cls, source: str, destination: list[str], zipped: bool = False, name: str | None = None, overwrite: bool = False, **kwargs) -> SkillRequest:
        '''Create a skill installation request from GitHub.

        Returns an awaitable :class:`SkillRequest` for installing a skill
        from a GitHub repository.

        Args:
            source: GitHub source. Supports multiple formats:

                - Short form: ``"owner/repo"``
                - With ref: ``"owner/repo@branch"``
                - Full URL: ``"https://github.com/owner/repo"``
                - SSH: ``"git@github.com:owner/repo.git"``

            destination: List of installation target paths.
            zipped: Whether to zip the installed skill. Defaults to False.
            name: Custom installation folder name. Defaults to None.
            overwrite: Whether to overwrite existing files. Defaults to False.
            **kwargs: Additional GitHub-specific options:

                - ``directory`` (str): Subdirectory within the repo.
                - ``rev`` (str): Git ref (branch, tag, commit SHA).
                - ``token`` (str): GitHub personal access token.

        Returns:
            Awaitable request object. Await for single install, or pass to
            :meth:`create_multiple` for batch install.

        Example:
            .. code-block:: python

                dest = "/path/to/skills"

                # Single installation - await directly
                paths = await SkillFactory.from_github(
                    "anthropics/skills",
                    [dest],
                    directory="skills/code-review",
                )

                # Batch installation - don\'t await individual requests
                results = await SkillFactory.create_multiple(
                    SkillFactory.from_github("anthropics/skills", [dest], directory="skills/art"),
                    SkillFactory.from_github("anthropics/skills", [dest], directory="skills/brand"),
                )
        '''
    @classmethod
    def from_clawhub(cls, source: str, destination: list[str], zipped: bool = False, name: str | None = None, overwrite: bool = False, **kwargs) -> SkillRequest:
        '''Create a skill installation request from ClawHub.

        Returns an awaitable :class:`SkillRequest` for installing a skill
        from a ClawHub registry (public or self-hosted).

        Warning:
            ClawHub is a community registry with user-generated content.
            A security scan check is performed before installation. Skills
            that fail the scan raise :class:`SkillSecurityException` by default.

            ClawHub skills may use OpenClaw-specific features that are not
            supported by non-OpenClaw agents. A compatibility warning is
            emitted at install time.

        Args:
            source: ClawHub source. Supports:

                - Slug: ``"self-improving-agent"``
                - Full URL: ``"https://clawhub.ai/pskoett/self-improving-agent"``

            destination: List of installation target paths.
            zipped: Whether to zip the installed skill. Defaults to False.
            name: Custom installation folder name. Defaults to None.
            overwrite: Whether to overwrite existing files. Defaults to False.
            **kwargs: Additional ClawHub-specific options:

                - ``api_base`` (str): ClawHub API base URL. Defaults to
                  public ClawHub. Override for self-hosted instances.
                - ``ignore_scan`` (bool): If True, warn instead of raising
                  when security scan finds issues. Defaults to False.

        Returns:
            Awaitable request object. Await for single install, or pass to
            :meth:`create_multiple` for batch install.

        Example:
            .. code-block:: python

                dest = "/path/to/skills"

                # Install from public ClawHub
                paths = await SkillFactory.from_clawhub(
                    "self-improving-agent",
                    [dest],
                )

                # Install from full URL
                paths = await SkillFactory.from_clawhub(
                    "https://clawhub.ai/pskoett/self-improving-agent",
                    [dest],
                )

                # Self-hosted instance
                paths = await SkillFactory.from_clawhub(
                    "my-skill",
                    [dest],
                    api_base="https://my-instance.convex.site",
                )

                # Ignore security scan failures (still warns)
                paths = await SkillFactory.from_clawhub(
                    "experimental-skill",
                    [dest],
                    ignore_scan=True,
                )
        '''
    @classmethod
    def create_multiple(cls, *requests: SkillRequest) -> _MultipleSkillRequest:
        '''Batch multiple skill installation requests for parallel execution.

        Validates all requests upfront, then executes them in parallel when
        awaited. Every request runs to completion — a failure in one does not
        cancel or affect the others.

        Returns a :class:`BatchResult` with per-request outcomes. Failures are
        logged as errors as they are collected, and a summary line is logged
        at the end.

        Important:
            Do NOT await individual requests before passing them here.
            Pass the unawaited :class:`SkillRequest` objects directly.

        Args:
            *requests: Unawaited SkillRequest objects from :meth:`from_github`,
                :meth:`create_skill`, etc.

        Returns:
            Awaitable that yields a :class:`BatchResult` containing per-request
            :class:`SkillResult` objects in the same order as the input.

        Raises:
            TypeError: If any argument is not a SkillRequest. This catches
                common mistakes like passing strings or awaited results.
            ValueError: If any request has missing or invalid fields
                (empty source, empty destination, invalid source_type).

        Example:
            .. code-block:: python

                dest = "/path/to/skills"

                result = await SkillFactory.create_multiple(
                    SkillFactory.from_github("owner/repo", [dest], directory="skill1"),
                    SkillFactory.from_github("owner/repo", [dest], directory="skill2"),
                )

                for r in result.succeeded:
                    print(f"Installed {r.request.source} to {r.paths}")

                for r in result.failed:
                    print(f"Failed {r.request.source}: {r.error}")
        '''

class _MultipleSkillRequest:
    """Internal awaitable for batch skill requests.

    This class is returned by :meth:`SkillFactory.create_multiple` and
    executes all requests in parallel when awaited. Every request runs to
    completion regardless of whether others fail.

    Note:
        This is an internal class. Users should not instantiate it directly.
    """
    def __init__(self, requests: list[SkillRequest]) -> None:
        """Initialize with validated requests.

        Args:
            requests: List of validated SkillRequest objects.
        """
    def __await__(self) -> Generator[Any, None, BatchResult]:
        """Execute all requests in parallel when awaited.

        Returns:
            Generator yielding BatchResult with per-request outcomes.
        """
