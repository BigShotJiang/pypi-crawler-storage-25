class SkillException(Exception):
    """Base exception for skill-related errors."""
class SkillSourceException(SkillException):
    """Exception raised for skill source errors."""
class SkillNotFoundException(SkillSourceException):
    """Exception raised when a skill is not found."""
class InvalidSkillException(SkillException):
    """Exception raised when a skill is invalid.

    This is typically raised when we can't detect SKILL.md in
    the linked source.
    """
class SkillInstallationException(SkillException):
    """Exception raised when a skill fails to install.

    Typically this is raised when the installation is a failure
    due to filesystem issues.
    """
class SkillSecurityException(SkillException):
    """Exception raised when a skill fails security checks.

    This is raised when a ClawHub skill has been flagged by security
    scanning (malware, suspicious content, etc.) and the caller has
    not opted into ignoring scan results.
    """
