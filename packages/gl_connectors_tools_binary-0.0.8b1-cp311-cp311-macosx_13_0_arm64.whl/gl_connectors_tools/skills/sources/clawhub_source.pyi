from gl_connectors_tools.skills.exceptions.exception import SkillException as SkillException, SkillInstallationException as SkillInstallationException, SkillNotFoundException as SkillNotFoundException, SkillSecurityException as SkillSecurityException
from gl_connectors_tools.skills.sources.skill_source import SkillSource as SkillSource

class ClawHubSource(SkillSource):
    """Fetch skills from a ClawHub registry.

    ClawHub is a community skill registry (UGC). Skills are downloaded as ZIP
    archives via the ClawHub V1 HTTP API. Security scan results are checked
    before installation by default.

    The public ClawHub frontend at ``https://clawhub.ai`` is a Vercel
    deployment that rewrites ``/api/*`` to the Convex site URL (see
    ``vercel.json``). However, the Vercel proxy layer applies aggressive
    rate limiting that can cause 429 errors even on moderate usage. For
    this reason, the SDK defaults directly to the Convex site URL
    (``https://wry-manatee-359.convex.site``), which serves the same
    ``/api/v1/*`` routes with only Convex-level rate limiting.

    Note: the Convex **site** URL (``.convex.site``) is distinct from
    the Convex **cloud** URL (``.convex.cloud``). The cloud URL serves
    the Convex RPC protocol (``/api/query``, ``/api/action``) used by
    the frontend SDK and cannot be used for REST API calls.

    Args:
        api_base: ClawHub API base URL. Defaults to the public ClawHub
            Convex site (``https://wry-manatee-359.convex.site``).
    """
    DEFAULT_API_BASE: str
    DOWNLOAD_TIMEOUT_SECONDS: int
    HTTP_NOT_FOUND: int
    HTTP_FORBIDDEN: int
    HTTP_LOCKED: int
    HTTP_GONE: int
    def __init__(self, api_base: str | None = None) -> None:
        """Initialize ClawHubSource.

        Args:
            api_base: ClawHub API base URL. Defaults to public ClawHub.
        """
    async def preflight_validate(self, source: str, **kwargs) -> None:
        """Check skill exists on ClawHub and passes security scanning.

        Always emits a UGC warning and a compatibility warning. Checks the
        skill's security scan status and raises ``SkillSecurityException``
        by default if issues are found. Pass ``ignore_scan=True`` to
        downgrade security failures to warnings.

        Args:
            source: ClawHub source (slug or URL).
            **kwargs: Options including:
                - ``ignore_scan`` (bool): Warn instead of raising on scan failures.

        Raises:
            SkillNotFoundException: If the skill does not exist.
            SkillSecurityException: If security scan fails and ignore_scan is False.
            SkillInstallationException: If the API request fails unexpectedly.
        """
