from gl_connectors_tools.skills.exceptions.exception import InvalidSkillException as InvalidSkillException, SkillException as SkillException, SkillInstallationException as SkillInstallationException, SkillNotFoundException as SkillNotFoundException
from gl_connectors_tools.skills.sources.skill_source import SkillSource as SkillSource

class GitHubSource(SkillSource):
    """Fetch skills stored in GitHub repositories."""
    API_BASE: str
    HOST: str
    RAW_HOST: str
    MIN_OWNER_REPO_PARTS: int
    MIN_RAW_PARTS: int
    RAW_DIR_START: int
    MIN_TREE_PARTS: int
    TREE_DIR_START: int
    HTTP_NOT_FOUND: int
    async def preflight_validate(self, source: str, **kwargs) -> None:
        """Fail fast if the GitHub source does not expose a valid SKILL.md.

        Args:
            source (str): The GitHub source string.
            **kwargs: Extra options such as ``rev``, ``directory``, and ``token``.

        Raises:
            SkillNotFoundException: If the source cannot be resolved.
            InvalidSkillException: If SKILL.md is missing or empty.
            SkillInstallationException: If the validation request fails.
        """
