import abc
from abc import ABC
from gl_connectors_tools.skills.exceptions.exception import InvalidSkillException as InvalidSkillException, SkillInstallationException as SkillInstallationException
from pathlib import Path

class SkillSource(ABC, metaclass=abc.ABCMeta):
    """This class serves as the base class for all skill sources.

    It provides a common interface for fetching skills from different sources.
    """
    async def fetch(self, source: str, paths: list[str], zipped: bool = False, name: str | None = None, overwrite: bool = False, **kwargs):
        """Fetch a skill from the source.

        Args:
            source (str): The source of the skill.
            paths (list[str]): Where to install the skill (requires filesystem access).
            zipped (bool): Whether to zip the installed skill.
            name (str | None): Custom installation folder name.
            overwrite (bool): Whether to overwrite existing files.
            **kwargs: Additional keyword arguments.

        Raises:
            SkillNotFoundException: If the skill is not found.
            InvalidSkillException: If the skill is invalid.
            SkillInstallationException: If the skill fails to install.
        """
    def validate_skill(self, path: Path):
        """Detects SKILL.md within the path and ensure it's not an empty file.

        Args:
            path (Path): The path of the skill directory.
        """
    async def preflight_validate(self, source: str, **kwargs) -> None:
        """Optionally validate a source before downloading.

        Args:
            source (str): The source string provided by the user.
            **kwargs: Source-specific options (e.g., rev, directory, token).

        Raises:
            SkillNotFoundException: If the source is not found.
            InvalidSkillException: If the source is not a valid skill.
            SkillInstallationException: If the validation fails unexpectedly.
        """
