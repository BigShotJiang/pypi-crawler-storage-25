"""
Context Budget Stress Test Agent

Agent de test pour vérifier que le système de budget de contexte fonctionne
quand un tool call retourne un résultat énorme qui explose le scratchpad.

Scénario de test :
1. Envoyer "Génère un gros texte" → l'agent appelle generate_huge_text()
2. Le tool retourne ~300k tokens → le scratchpad explose
3. Le BudgetAwareFunctionAgent.take_step() doit détecter le dépassement
4. Le ScratchpadCompressor doit compresser le scratchpad
5. L'agent doit pouvoir continuer à répondre

Usage:
    uv run python examples/agent_context_budget_test.py

L'agent démarre sur http://localhost:8100
"""

import os
from typing import Any

from agent_framework.implementations import LlamaIndexAgent


class ContextBudgetTestAgent(LlamaIndexAgent):
    """Agent de test pour le budget de contexte avec tool calls énormes."""

    def __init__(self) -> None:
        super().__init__(
            agent_id="context_budget_test_v1",
            name="Context Budget Test Agent",
            description="Agent de test pour vérifier la compression du scratchpad.",
        )

    async def configure_session(self, session_configuration: dict[str, Any]) -> None:
        """Capture session context."""
        await super().configure_session(session_configuration)

    def get_agent_prompt(self) -> str:
        return (
            "Tu es un agent de test. Quand l'utilisateur demande de générer "
            "du texte, utilise le tool generate_huge_text. "
            "Après avoir reçu le résultat, fais un résumé court de ce que "
            "tu as reçu et dis combien de caractères ça faisait environ."
        )

    def get_agent_tools(self) -> list[callable]:
        def generate_huge_text(size_kb: int = 800) -> str:
            """Génère un texte volumineux pour tester les limites du contexte.

            Args:
                size_kb: Taille approximative en KB du texte à générer (défaut: 800).

            Returns:
                Un texte très long simulant un document volumineux.
            """
            # ~4 chars par token en moyenne, 1 token ≈ 4 bytes
            # 800 KB ≈ 200k tokens → dépasse largement un context de 272k avec le reste
            chunk = (
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit. "
                "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. "
                "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris. "
                "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum. "
                "Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia. "
            )
            target_chars = size_kb * 1024
            repetitions = target_chars // len(chunk) + 1
            result = ""
            for i in range(repetitions):
                result += f"[Section {i+1}] {chunk}\n"
                if len(result) >= target_chars:
                    break
            return result[:target_chars]

        def small_tool() -> str:
            """Un petit tool pour vérifier que l'agent fonctionne après compression."""
            return "OK - petit tool fonctionne correctement après compression."

        return [generate_huge_text, small_tool]


def main() -> None:
    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY not set")
        return

    from agent_framework import create_basic_agent_server

    port = int(os.getenv("AGENT_PORT", "8100"))

    print("=" * 60)
    print("🧪 Context Budget Stress Test Agent")
    print("=" * 60)
    print(f"📊 Model: {os.getenv('DEFAULT_MODEL', 'gpt-5.4-mini')}")
    print(f"🔧 Tools: generate_huge_text, small_tool")
    print(f"🌐 Server: http://localhost:{port}")
    print(f"🎨 UI: http://localhost:{port}/ui")
    print("=" * 60)
    print()
    print("📋 Test:")
    print('   1. Envoie "Génère un gros texte de 800kb"')
    print("   2. Regarde les logs pour voir la compression du scratchpad")
    print('   3. Envoie "Utilise le small_tool" pour vérifier que ça marche après')
    print("=" * 60)

    create_basic_agent_server(
        agent_class=ContextBudgetTestAgent,
        host="0.0.0.0",
        port=port,
        reload=False,
    )


if __name__ == "__main__":
    main()
