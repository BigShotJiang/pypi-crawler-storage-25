"""
WebFetchTool — fetches the text content of an HTTP/HTTPS URL.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any
from urllib.parse import urlparse

from agent_framework.core.agent_interface import TechnicalDetails
from agent_framework.tools.activity_callback import ActivityCallback, make_activity_part
from agent_framework.tools.base import AgentTool


logger = logging.getLogger(__name__)

_SOURCE = "WebFetchTool"
_ICON = "🌐"
_TIMEOUT = 30


class WebFetchTool(AgentTool):
    """Fetches the textual content of an HTTP/HTTPS URL."""

    def __init__(self, activity_callback: ActivityCallback | None = None) -> None:
        """Initialize WebFetchTool.

        Args:
            activity_callback: Optional callback to emit ActivityOutputPart events.
        """
        super().__init__()
        self._activity_callback = activity_callback

    def get_tool_function(self) -> Callable[..., Any]:
        """Return the web_fetch callable."""

        def web_fetch(url: str, max_length: int | None = None) -> str:
            """Fetch the text content of a web page.

            Args:
                url: HTTP/HTTPS URL to fetch.
                max_length: Maximum number of characters to return (optional).

            Returns:
                Extracted text content. All errors are returned as strings.
            """
            try:
                import httpx
                from bs4 import BeautifulSoup
            except ImportError as exc:
                return f"[error] Missing dependency: {exc}"

            parsed = urlparse(url)
            if parsed.scheme not in ("http", "https"):
                return f"[error] Invalid URL scheme: {url}"

            if self._activity_callback:
                self._activity_callback(
                    make_activity_part(
                        activity_type="web_fetch",
                        source=_SOURCE,
                        content=f"Fetching: {url}",
                        display_info={"icon": _ICON, "url": url},
                    )
                )

            try:
                response = httpx.get(url, timeout=_TIMEOUT, follow_redirects=True)
                if response.status_code >= 400:
                    msg = f"[error] HTTP {response.status_code}: {url}"
                    _emit_result(self._activity_callback, url, msg, response.status_code)
                    return msg

                soup = BeautifulSoup(response.text, "html.parser")
                for tag in soup(["script", "style"]):
                    tag.decompose()
                text = soup.get_text(separator="\n", strip=True)

                if max_length is not None:
                    text = text[:max_length]

                _emit_result(self._activity_callback, url, text, response.status_code)
                return text

            except httpx.TimeoutException:
                msg = f"[timeout] Request timed out: {url}"
                _emit_result(self._activity_callback, url, msg, None)
                return msg

            except Exception as exc:
                logger.exception("Unexpected error in web_fetch")
                msg = f"[error] {exc}"
                _emit_result(self._activity_callback, url, msg, None)
                return msg

        return web_fetch

    def get_tool_info(self) -> dict[str, Any]:
        return {
            "name": self.__class__.__name__,
            "description": "Fetch text content from an HTTP/HTTPS URL",
            "requires_file_storage": False,
            "requires_user_context": False,
        }


def _emit_result(
    callback: ActivityCallback | None,
    url: str,
    content: str,
    http_status: int | None,
) -> None:
    if callback is None:
        return
    ts = make_activity_part("web_fetch", _SOURCE).timestamp
    callback(
        make_activity_part(
            activity_type="web_fetch",
            source=_SOURCE,
            content=content[:500] if content else "(empty)",
            display_info={"icon": _ICON, "url": url},
            technical_details=TechnicalDetails(
                function_name="web_fetch",
                arguments={"url": url},
                raw_result=content,
                execution_time_ms=0,
                timestamp=ts,
                status="success" if (http_status is not None and http_status < 400) else "error",
                error_message=content if "[error]" in content or "[timeout]" in content else None,
            ),
        )
    )


__all__ = ["WebFetchTool"]
