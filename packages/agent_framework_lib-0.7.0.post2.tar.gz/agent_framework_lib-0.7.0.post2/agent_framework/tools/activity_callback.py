"""
ActivityCallback — lightweight callback type for tool activity emission.
"""

from collections.abc import Callable
from datetime import datetime, timezone
from typing import Any

from agent_framework.core.agent_interface import ActivityOutputPart, TechnicalDetails


ActivityCallback = Callable[[ActivityOutputPart], None]


def make_activity_part(
    activity_type: str,
    source: str,
    content: str | None = None,
    display_info: dict[str, Any] | None = None,
    technical_details: TechnicalDetails | None = None,
) -> ActivityOutputPart:
    """Build an ActivityOutputPart with an automatic UTC timestamp.

    Args:
        activity_type: Type identifier (e.g. "shell_execution", "web_fetch").
        source: Name of the emitting component.
        content: Optional user-friendly description.
        display_info: Optional dict with UI metadata (icon, labels, …).
        technical_details: Optional structured technical data for ES storage.

    Returns:
        A fully populated ActivityOutputPart.
    """
    return ActivityOutputPart(
        activity_type=activity_type,
        source=source,
        content=content,
        timestamp=datetime.now(timezone.utc).isoformat(),
        display_info=display_info,
        technical_details=technical_details,
    )


__all__ = [
    "ActivityCallback",
    "make_activity_part",
]
