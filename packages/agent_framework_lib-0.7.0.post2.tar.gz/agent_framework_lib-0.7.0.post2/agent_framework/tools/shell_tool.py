"""
ShellTool — executes shell commands and returns combined stdout/stderr.
"""

from __future__ import annotations

import logging
import os
import subprocess
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from agent_framework.core.agent_interface import TechnicalDetails
from agent_framework.tools.activity_callback import ActivityCallback, make_activity_part
from agent_framework.tools.base import AgentTool


logger = logging.getLogger(__name__)

_SOURCE = "ShellTool"
_ICON = "🐚"


class ShellTool(AgentTool):
    """Executes shell commands and returns combined stdout/stderr output."""

    def __init__(
        self,
        default_timeout: int = 30,
        activity_callback: ActivityCallback | None = None,
    ) -> None:
        """Initialize ShellTool.

        Args:
            default_timeout: Default timeout in seconds for command execution.
            activity_callback: Optional callback to emit ActivityOutputPart events.
        """
        super().__init__()
        self._default_timeout = default_timeout
        self._activity_callback = activity_callback

    def _build_env(self) -> dict[str, str]:
        """Build environment variables for subprocess, injecting session context.

        Passes AGENT_USER_ID, AGENT_SESSION_ID, AGENT_HOST, and AGENT_PORT
        so that skill scripts (e.g. register_to_storage.py) can access the
        current session context and call the server API without the LLM
        needing to know or pass these values.
        """
        env = os.environ.copy()
        if self.current_user_id:
            env["AGENT_USER_ID"] = self.current_user_id
        if self.current_session_id:
            env["AGENT_SESSION_ID"] = self.current_session_id
        # Ensure server connection info is available
        env.setdefault("AGENT_HOST", "localhost")
        env.setdefault("AGENT_PORT", "8203")
        return env

    def get_tool_function(self) -> Callable[..., Any]:
        """Return the shell_exec callable."""

        def shell_exec(
            command: str,
            workdir: str | None = None,
            timeout: int | None = None,
        ) -> str:
            """Execute a shell command and return its output.

            Args:
                command: Shell command to execute.
                workdir: Working directory (optional).
                timeout: Timeout in seconds (default: configured at init).

            Returns:
                Combined stdout + stderr. Non-zero exit codes are appended.
                All errors are returned as strings, never raised.
            """
            effective_timeout = timeout if timeout is not None else self._default_timeout

            if workdir is not None:
                wd = Path(workdir)
                if not wd.exists():
                    return f"[error] Working directory not found: {workdir}"

            if self._activity_callback:
                self._activity_callback(
                    make_activity_part(
                        activity_type="shell_execution",
                        source=_SOURCE,
                        content=f"Running: {command}",
                        display_info={"icon": _ICON, "command": command},
                    )
                )

            env = self._build_env()

            start_ms = time.monotonic()
            try:
                result = subprocess.run(
                    command,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=effective_timeout,
                    cwd=workdir,
                    env=env,
                )
                duration_ms = int((time.monotonic() - start_ms) * 1000)
                output_parts: list[str] = []
                if result.stdout:
                    output_parts.append(result.stdout)
                if result.stderr:
                    output_parts.append(result.stderr)
                output = "".join(output_parts)
                if result.returncode != 0:
                    output += f"\n[exit code: {result.returncode}]"

                if self._activity_callback:
                    self._activity_callback(
                        make_activity_part(
                            activity_type="shell_execution",
                            source=_SOURCE,
                            content=output[:500] if output else "(no output)",
                            display_info={"icon": _ICON, "command": command},
                            technical_details=TechnicalDetails(
                                function_name="shell_exec",
                                arguments={"command": command, "workdir": workdir},
                                raw_result=output,
                                execution_time_ms=duration_ms,
                                timestamp=make_activity_part(
                                    "shell_execution", _SOURCE
                                ).timestamp,
                                status="success" if result.returncode == 0 else "error",
                                error_message=(
                                    f"exit code {result.returncode}"
                                    if result.returncode != 0
                                    else None
                                ),
                            ),
                        )
                    )
                return output

            except subprocess.TimeoutExpired:
                duration_ms = int((time.monotonic() - start_ms) * 1000)
                msg = f"[timeout] Command timed out after {effective_timeout}s"
                if self._activity_callback:
                    self._activity_callback(
                        make_activity_part(
                            activity_type="shell_execution",
                            source=_SOURCE,
                            content=msg,
                            display_info={"icon": _ICON, "command": command},
                            technical_details=TechnicalDetails(
                                function_name="shell_exec",
                                arguments={"command": command, "workdir": workdir},
                                raw_result=msg,
                                execution_time_ms=duration_ms,
                                timestamp=make_activity_part(
                                    "shell_execution", _SOURCE
                                ).timestamp,
                                status="error",
                                error_message=msg,
                            ),
                        )
                    )
                return msg

            except Exception as exc:
                logger.exception("Unexpected error in shell_exec")
                return f"[error] {exc}"

        return shell_exec

    def get_tool_info(self) -> dict[str, Any]:
        return {
            "name": self.__class__.__name__,
            "description": "Execute shell commands and return stdout/stderr",
            "requires_file_storage": False,
            "requires_user_context": False,
        }


__all__ = ["ShellTool"]
