"""Budget-aware function agent for tool loop budget enforcement.

Subclasses LlamaIndex's FunctionAgent to intercept take_step() and
verify context budget before each LLM call, compressing the scratchpad
when usage approaches the context window limit.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, List, Optional, Sequence

from llama_index.core.agent.workflow import FunctionAgent
from llama_index.core.agent.workflow.workflow_events import AgentOutput
from llama_index.core.bridge.pydantic import Field, PrivateAttr
from llama_index.core.llms import ChatMessage, MessageRole
from llama_index.core.memory import BaseMemory
from llama_index.core.tools import AsyncBaseTool
from llama_index.core.workflow import Context

from agent_framework.core.knowledge_state import ToolCallSignature
from agent_framework.core.loop_detector import LoopDetector
from agent_framework.core.scratchpad_compressor import MAX_MESSAGE_CONTENT_CHARS

if TYPE_CHECKING:
    from agent_framework.core.context_budget import ContextBudgetManager
    from agent_framework.core.scratchpad_compressor import ScratchpadCompressor
    from agent_framework.monitoring.token_counter import TokenCounter

logger = logging.getLogger(__name__)

MAX_ITERATIONS: int = 25
WARNING_THRESHOLD: int = 20
_ITERATION_WARNING_MARKER = "[Avertissement système]"


class BudgetAwareFunctionAgent(FunctionAgent):
    """FunctionAgent avec vérification du budget avant chaque appel LLM."""

    _budget_manager: Any = PrivateAttr(default=None)
    _token_counter: Any = PrivateAttr(default=None)
    _scratchpad_compressor: Any = PrivateAttr(default=None)
    _max_iterations_stored: int = PrivateAttr(default=MAX_ITERATIONS)
    _dedup_registry: dict = PrivateAttr(default_factory=dict)
    _loop_detector: Any = PrivateAttr(default=None)
    _forced_conclusion_active: bool = PrivateAttr(default=False)
    _forced_conclusion_attempts: int = PrivateAttr(default=0)

    MAX_FORCED_CONCLUSION_ATTEMPTS: int = 2

    def __init__(
        self,
        *args: Any,
        budget_manager: ContextBudgetManager | None = None,
        token_counter: TokenCounter | None = None,
        scratchpad_compressor: ScratchpadCompressor | None = None,
        max_iterations: int = MAX_ITERATIONS,
        **kwargs: Any,
    ) -> None:
        super().__init__(*args, max_iterations=max_iterations, **kwargs)
        self._budget_manager = budget_manager
        self._token_counter = token_counter
        self._scratchpad_compressor = scratchpad_compressor
        self._max_iterations_stored = max_iterations
        self._loop_detector = LoopDetector()

    @property
    def max_iterations(self) -> int:
        """Nombre maximum d'itérations autorisées."""
        return self._max_iterations_stored

    async def take_step(
        self,
        ctx: Context,
        llm_input: List[ChatMessage],
        tools: Sequence[AsyncBaseTool],
        memory: BaseMemory,
    ) -> AgentOutput:
        """Vérifie le budget et compresse le scratchpad avant l'appel LLM."""
        # Inject iteration warning and set limit flag
        try:
            num_iterations: int = await ctx.store.get("num_iterations", default=0)
            if WARNING_THRESHOLD <= num_iterations < self.max_iterations:
                llm_input = self._inject_iteration_warning(llm_input, num_iterations)
            if num_iterations >= self.max_iterations - 1:
                await ctx.store.set("iteration_limit_reached", True)
        except Exception:
            logger.debug("Could not read num_iterations from ctx.store", exc_info=True)

        if self._budget_manager and self._token_counter and self._scratchpad_compressor:
            scratchpad: List[ChatMessage] = await ctx.store.get(
                self.scratchpad_key, default=[]
            )

            # Loop detection before budget check
            loop_result = self._loop_detector.detect(scratchpad)

            llm_input_tokens = self._count_total_tokens(llm_input, [])
            scratchpad_tokens = self._count_total_tokens([], scratchpad)
            sacred_zone_tokens = self._budget_manager._sacred_zone_tokens
            context_window = self._budget_manager.context_window

            # Le total RÉEL envoyé à l'API = sacred_zone + llm_input + scratchpad.
            # LlamaIndex injecte le system prompt et les tool definitions automatiquement.
            # Le multiplicateur pour les tool definitions est déjà appliqué dans
            # set_sacred_zone() du ContextBudgetManager.
            total_tokens = sacred_zone_tokens + llm_input_tokens + scratchpad_tokens

            if context_window > 0:
                usage_percent = total_tokens / context_window * 100
            else:
                usage_percent = 0.0

            # Forced conclusion: loop detected + high usage
            if loop_result.is_loop and usage_percent >= 80:
                if not self._forced_conclusion_active:
                    self._forced_conclusion_active = True
                    self._forced_conclusion_attempts = 0

                self._forced_conclusion_attempts += 1

                if self._forced_conclusion_attempts > self.MAX_FORCED_CONCLUSION_ATTEMPTS:
                    dup_sigs = [
                        f"{sig.tool_name}({sig.args_hash[:12]})"
                        for sig, _ in loop_result.duplicate_signatures
                    ]
                    logger.error(
                        "Forced conclusion failed after %d attempts: "
                        "iterations=%d, duplicate_signatures=%s, usage=%.1f%%",
                        self.MAX_FORCED_CONCLUSION_ATTEMPTS,
                        len(scratchpad),
                        dup_sigs,
                        usage_percent,
                    )
                    knowledge_text = self._scratchpad_compressor.knowledge_state.to_structured_text()
                    error_text = (
                        "L'agent n'a pas pu conclure après plusieurs tentatives.\n\n"
                        "Voici les connaissances acquises :\n"
                        + knowledge_text
                    )
                    return AgentOutput(
                        response=ChatMessage(
                            role=MessageRole.ASSISTANT, content=error_text
                        ),
                        tool_calls=[],
                        raw=None,
                        current_agent_name=self.name,
                    )

                llm_input = self._inject_forced_conclusion(llm_input)

            # Ignore tool calls while forced conclusion is active
            if self._forced_conclusion_active:
                tools = []

            logger.info(
                "Tool loop budget: %d/%d tokens (%.1f%%), "
                "sacred=%d, llm_input=%d, scratchpad=%d (%d entries)",
                total_tokens,
                context_window,
                usage_percent,
                sacred_zone_tokens,
                llm_input_tokens,
                scratchpad_tokens,
                len(scratchpad),
            )

            if usage_percent >= 60:
                logger.warning(
                    "Tool loop context usage at %.1f%%", usage_percent
                )

            # Seuil à 80% : laisse une marge de 20% pour l'écart résiduel
            # de tokenisation entre tiktoken et le tokenizer du provider.
            if usage_percent >= 80:
                logger.warning(
                    "Compressing scratchpad: usage %.1f%% >= 80%% threshold",
                    usage_percent,
                )

                # Boucle de compression : re-vérifier après chaque passe
                # car la première compression peut ne pas suffire (ex: blocks
                # non aplatis, écart de tokenisation).
                max_compression_passes = 3
                for compression_pass in range(max_compression_passes):
                    compressed_scratchpad = await self._scratchpad_compressor.compress(
                        scratchpad=scratchpad,
                        llm_input=llm_input,
                        context_window=context_window,
                        sacred_zone_tokens=sacred_zone_tokens,
                        model_name=getattr(self.llm, "model", None),
                    )
                    await ctx.store.set(self.scratchpad_key, compressed_scratchpad)

                    # Recalculer le total après compression
                    new_scratchpad_tokens = self._count_total_tokens([], compressed_scratchpad)
                    new_total = sacred_zone_tokens + llm_input_tokens + new_scratchpad_tokens
                    new_usage = new_total / context_window * 100 if context_window > 0 else 0.0

                    logger.info(
                        "Post-compression pass %d: %d/%d tokens (%.1f%%), scratchpad=%d",
                        compression_pass + 1,
                        new_total,
                        context_window,
                        new_usage,
                        new_scratchpad_tokens,
                    )

                    if new_usage < 80:
                        break

                    # Préparer la prochaine passe avec le scratchpad compressé
                    scratchpad = compressed_scratchpad

                    if compression_pass == max_compression_passes - 1:
                        logger.error(
                            "Scratchpad still at %.1f%% after %d compression passes",
                            new_usage,
                            max_compression_passes,
                        )

        # Garde-fou caractères bruts : même après compression en tokens,
        # un message peut dépasser la limite API (10M chars). On tronque
        # chaque message du scratchpad qui dépasse avant l'appel LLM.
        if self._scratchpad_compressor:
            scratchpad = await ctx.store.get(self.scratchpad_key, default=[])
            patched = False
            for i, msg in enumerate(scratchpad):
                content = msg.content or ""
                if len(content) > MAX_MESSAGE_CONTENT_CHARS:
                    from agent_framework.core.scratchpad_compressor import ScratchpadCompressor
                    scratchpad[i] = ChatMessage(
                        role=msg.role,
                        content=ScratchpadCompressor._enforce_char_limit(content),
                        additional_kwargs=msg.additional_kwargs,
                    )
                    patched = True
            if patched:
                await ctx.store.set(self.scratchpad_key, scratchpad)

        return await super().take_step(ctx, llm_input, tools, memory)

    def _inject_iteration_warning(
        self, llm_input: list[ChatMessage], num_iterations: int
    ) -> list[ChatMessage]:
        """Injecte un avertissement d'itération si absent, de façon idempotente.

        Retourne llm_input inchangé si num_iterations < WARNING_THRESHOLD.
        Injecte exactement un avertissement SYSTEM si num_iterations >= WARNING_THRESHOLD.
        Idempotent : n'injecte pas si un avertissement est déjà présent.

        Args:
            llm_input: Messages d'entrée pour le LLM.
            num_iterations: Nombre d'itérations effectuées.

        Returns:
            Liste de messages avec ou sans avertissement.
        """
        if num_iterations < WARNING_THRESHOLD:
            return llm_input
        # Idempotence : ne pas injecter si déjà présent
        for msg in llm_input:
            if msg.role == MessageRole.SYSTEM and _ITERATION_WARNING_MARKER in (msg.content or ""):
                return llm_input
        remaining = self.max_iterations - num_iterations
        warning = ChatMessage(
            role=MessageRole.SYSTEM,
            content=(
                f"{_ITERATION_WARNING_MARKER}\n"
                f"Tu as effectué {num_iterations} itérations sur {self.max_iterations} autorisées. "
                f"Il te reste {remaining} itération(s). "
                "Commence à conclure et fournis une réponse finale à l'utilisateur."
            ),
        )
        return list(llm_input) + [warning]

    def _count_total_tokens(
        self,
        llm_input: List[ChatMessage],
        scratchpad: List[ChatMessage],
    ) -> int:
        """Compte le total de tokens de llm_input + scratchpad.

        Utilise _count_message_tokens du budget manager si disponible
        pour compter tous les blocks (ToolCallBlock, ToolResultBlock, etc.)
        et pas seulement les TextBlock via .content.

        Args:
            llm_input: Messages d'historique envoyés au LLM.
            scratchpad: Messages du scratchpad de la boucle d'outils.

        Returns:
            Nombre total de tokens.
        """
        total = 0
        for msg in [*llm_input, *scratchpad]:
            if self._budget_manager and hasattr(self._budget_manager, '_count_message_tokens'):
                total += self._budget_manager._count_message_tokens(msg)
            else:
                total += self._token_counter.count_tokens(msg.content or "").count
        return total

    def _check_deduplication(self, tool_name: str, tool_kwargs: dict) -> str | None:
        """Check if a tool call has already been executed and return cached result.

        Computes the ToolCallSignature for the given tool call and looks it up
        in the deduplication registry. If found, logs an INFO message and
        returns the cached result string.

        Args:
            tool_name: Name of the tool being called.
            tool_kwargs: Arguments dictionary for the tool call.

        Returns:
            The cached result string if the signature exists, None otherwise.
        """
        signature = ToolCallSignature.from_tool_call(tool_name, tool_kwargs)
        cached = self._dedup_registry.get(signature)
        if cached is not None:
            logger.info(
                "Deduplicated tool call: tool='%s' signature='%s', returning cached result",
                tool_name,
                signature.args_hash[:12],
            )
            return cached
        return None

    def _inject_forced_conclusion(
        self, llm_input: list[ChatMessage]
    ) -> list[ChatMessage]:
        """Inject a forced conclusion SYSTEM message with accumulated knowledge.

        Args:
            llm_input: Current LLM input messages.

        Returns:
            Updated message list with the forced conclusion appended.
        """
        knowledge_state = self._scratchpad_compressor.knowledge_state
        conclusion_msg = ChatMessage(
            role=MessageRole.SYSTEM,
            content=(
                "[Conclusion forcée]\n\n"
                "Une boucle d'outils a été détectée. Tu DOIS conclure immédiatement.\n"
                "N'appelle AUCUN outil supplémentaire.\n\n"
                "Voici les connaissances acquises :\n"
                + knowledge_state.to_structured_text()
                + "\n\nUtilise ces informations pour formuler ta réponse finale."
            ),
        )
        return list(llm_input) + [conclusion_msg]

    def reset_for_new_query(self) -> None:
        """Reset the deduplication registry and forced conclusion state for a new user query."""
        self._dedup_registry.clear()
        self._forced_conclusion_active = False
        self._forced_conclusion_attempts = 0
