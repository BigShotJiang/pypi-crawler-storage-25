"""A2A Task data models."""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


logger = logging.getLogger(__name__)


class TaskStatus(str, Enum):
    """A2A task lifecycle states."""
    SUBMITTED = "submitted"
    WORKING = "working"
    INPUT_REQUIRED = "input-required"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"
    REJECTED = "rejected"

    @property
    def is_terminal(self) -> bool:
        return self in _TERMINAL_STATES


_TERMINAL_STATES = frozenset({
    TaskStatus.COMPLETED,
    TaskStatus.FAILED,
    TaskStatus.CANCELED,
    TaskStatus.REJECTED,
})


@dataclass
class A2ATask:
    """Lightweight mapping entry in the Task Store.

    Links an A2A task_id to a framework session_id + message_id.
    The actual conversational content lives in the session store.
    """
    id: str
    context_id: str
    session_id: str
    message_id: str
    agent_id: str
    status: TaskStatus = TaskStatus.SUBMITTED
    status_message: dict[str, Any] | None = None
    artifact_refs: list[dict[str, Any]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a plain dict for storage."""
        return {
            "id": self.id,
            "context_id": self.context_id,
            "session_id": self.session_id,
            "message_id": self.message_id,
            "agent_id": self.agent_id,
            "status": self.status.value,
            "status_message": self.status_message,
            "artifact_refs": self.artifact_refs,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "A2ATask":
        """Deserialize from a plain dict."""
        created_at = data.get("created_at")
        updated_at = data.get("updated_at")

        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at)
        elif not isinstance(created_at, datetime):
            created_at = datetime.now(timezone.utc)

        if isinstance(updated_at, str):
            updated_at = datetime.fromisoformat(updated_at)
        elif not isinstance(updated_at, datetime):
            updated_at = datetime.now(timezone.utc)

        return cls(
            id=data["id"],
            context_id=data["context_id"],
            session_id=data["session_id"],
            message_id=data["message_id"],
            agent_id=data["agent_id"],
            status=TaskStatus(data.get("status", "submitted")),
            status_message=data.get("status_message"),
            artifact_refs=data.get("artifact_refs", []),
            metadata=data.get("metadata", {}),
            created_at=created_at,
            updated_at=updated_at,
        )
