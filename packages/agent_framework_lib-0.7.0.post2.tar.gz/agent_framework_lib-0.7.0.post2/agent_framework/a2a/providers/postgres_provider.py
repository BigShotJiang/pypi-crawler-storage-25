"""PostgreSQL implementation of A2ATaskProvider."""

import json
import logging
from datetime import datetime, timezone, timedelta

try:
    import asyncpg  # noqa: F401 — availability check
except ImportError:
    raise ImportError(
        "asyncpg is required for PostgresTaskProvider. "
        "Install with: uv add asyncpg"
    )

import asyncpg

from ..base import (
    A2ATaskProvider,
    TaskNotCancelableError,
    TaskNotFoundError,
    TaskTerminalStateError,
)
from ..models import A2ATask, TaskStatus


logger = logging.getLogger(__name__)

CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS {table} (
    id VARCHAR(36) PRIMARY KEY,
    context_id VARCHAR(36) NOT NULL,
    session_id VARCHAR(255) NOT NULL,
    message_id VARCHAR(255) NOT NULL,
    agent_id VARCHAR(255) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'submitted',
    status_message JSONB,
    artifact_refs JSONB DEFAULT '[]'::jsonb,
    metadata JSONB DEFAULT '{{}}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
"""

CREATE_INDEXES_SQL = """
CREATE INDEX IF NOT EXISTS idx_{safe}_context ON {table}(context_id);
CREATE INDEX IF NOT EXISTS idx_{safe}_status ON {table}(status);
CREATE INDEX IF NOT EXISTS idx_{safe}_agent ON {table}(agent_id);
CREATE INDEX IF NOT EXISTS idx_{safe}_session ON {table}(session_id);
"""


class PostgresTaskProvider(A2ATaskProvider):
    """Stores A2A tasks in a PostgreSQL table."""

    def __init__(
        self,
        connection_string: str,
        table_name: str = "a2a_tasks",
    ):
        """
        Args:
            connection_string: PostgreSQL DSN.
            table_name: Table name for tasks.
        """
        self._dsn = connection_string
        self._table = table_name
        # Sanitized name for index naming (replace hyphens/dots)
        self._safe_table = table_name.replace("-", "_").replace(".", "_")
        self._pool: asyncpg.Pool | None = None
        self._initialized = False

    @property
    def is_initialized(self) -> bool:
        return self._initialized

    async def initialize(self) -> bool:
        try:
            self._pool = await asyncpg.create_pool(self._dsn, min_size=1, max_size=5)
            async with self._pool.acquire() as conn:
                await conn.execute(CREATE_TABLE_SQL.format(table=self._table))
                await conn.execute(
                    CREATE_INDEXES_SQL.format(table=self._table, safe=self._safe_table)
                )
            self._initialized = True
            logger.info(f"PostgreSQL A2A task provider initialized (table={self._table})")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize PG task provider: {e}")
            return False

    async def create_task(
        self,
        task_id: str,
        context_id: str,
        session_id: str,
        message_id: str,
        agent_id: str,
        metadata: dict | None = None,
    ) -> A2ATask:
        now = datetime.now(timezone.utc)
        task = A2ATask(
            id=task_id,
            context_id=context_id,
            session_id=session_id,
            message_id=message_id,
            agent_id=agent_id,
            metadata=metadata or {},
            created_at=now,
            updated_at=now,
        )
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                INSERT INTO {self._table}
                    (id, context_id, session_id, message_id, agent_id,
                     status, status_message, artifact_refs, metadata,
                     created_at, updated_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
                """,
                task.id,
                task.context_id,
                task.session_id,
                task.message_id,
                task.agent_id,
                task.status.value,
                json.dumps(task.status_message),
                json.dumps(task.artifact_refs),
                json.dumps(task.metadata),
                task.created_at,
                task.updated_at,
            )
        logger.debug(f"Created A2A task {task_id} in PG")
        return task

    def _row_to_task(self, row: asyncpg.Record) -> A2ATask:
        """Convert a DB row to an A2ATask."""
        status_message = row["status_message"]
        if isinstance(status_message, str):
            status_message = json.loads(status_message)

        artifact_refs = row["artifact_refs"]
        if isinstance(artifact_refs, str):
            artifact_refs = json.loads(artifact_refs)

        meta = row["metadata"]
        if isinstance(meta, str):
            meta = json.loads(meta)

        return A2ATask(
            id=row["id"],
            context_id=row["context_id"],
            session_id=row["session_id"],
            message_id=row["message_id"],
            agent_id=row["agent_id"],
            status=TaskStatus(row["status"]),
            status_message=status_message,
            artifact_refs=artifact_refs or [],
            metadata=meta or {},
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    async def get_task(self, task_id: str) -> A2ATask | None:
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                f"SELECT * FROM {self._table} WHERE id = $1", task_id
            )
        if row is None:
            return None
        return self._row_to_task(row)

    async def update_status(
        self,
        task_id: str,
        state: str,
        status_message: dict | None = None,
    ) -> A2ATask:
        task = await self.get_task(task_id)
        if task is None:
            raise TaskNotFoundError(task_id)
        if task.status.is_terminal:
            raise TaskTerminalStateError(task_id, task.status.value)

        now = datetime.now(timezone.utc)
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                UPDATE {self._table}
                SET status = $1, status_message = $2, updated_at = $3
                WHERE id = $4
                """,
                state,
                json.dumps(status_message),
                now,
                task_id,
            )
        task.status = TaskStatus(state)
        task.status_message = status_message
        task.updated_at = now
        return task

    async def add_artifact_ref(
        self,
        task_id: str,
        artifact_id: str,
        name: str,
        parts_summary: list[dict],
    ) -> A2ATask:
        task = await self.get_task(task_id)
        if task is None:
            raise TaskNotFoundError(task_id)

        ref = {"artifact_id": artifact_id, "name": name, "parts_summary": parts_summary}
        task.artifact_refs.append(ref)
        now = datetime.now(timezone.utc)

        async with self._pool.acquire() as conn:
            await conn.execute(
                f"""
                UPDATE {self._table}
                SET artifact_refs = $1, updated_at = $2
                WHERE id = $3
                """,
                json.dumps(task.artifact_refs),
                now,
                task_id,
            )
        task.updated_at = now
        return task

    async def list_tasks(
        self,
        context_id: str | None = None,
        state: str | None = None,
        agent_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[A2ATask]:
        conditions: list[str] = []
        params: list = []
        idx = 1

        if context_id:
            conditions.append(f"context_id = ${idx}")
            params.append(context_id)
            idx += 1
        if state:
            conditions.append(f"status = ${idx}")
            params.append(state)
            idx += 1
        if agent_id:
            conditions.append(f"agent_id = ${idx}")
            params.append(agent_id)
            idx += 1

        where = f"WHERE {' AND '.join(conditions)}" if conditions else ""
        params.extend([limit, offset])

        query = (
            f"SELECT * FROM {self._table} {where} "
            f"ORDER BY created_at DESC LIMIT ${idx} OFFSET ${idx + 1}"
        )

        async with self._pool.acquire() as conn:
            rows = await conn.fetch(query, *params)
        return [self._row_to_task(r) for r in rows]

    async def cancel_task(self, task_id: str) -> A2ATask:
        task = await self.get_task(task_id)
        if task is None:
            raise TaskNotFoundError(task_id)
        if task.status.is_terminal:
            raise TaskNotCancelableError(task_id, task.status.value)

        return await self.update_status(task_id, TaskStatus.CANCELED.value)

    async def cleanup_expired(self, ttl_hours: int = 24) -> int:
        cutoff = datetime.now(timezone.utc) - timedelta(hours=ttl_hours)
        terminal = [s.value for s in TaskStatus if s.is_terminal]
        placeholders = ", ".join(f"${i+2}" for i in range(len(terminal)))

        async with self._pool.acquire() as conn:
            result = await conn.execute(
                f"""
                DELETE FROM {self._table}
                WHERE status IN ({placeholders})
                  AND updated_at < $1
                """,
                cutoff,
                *terminal,
            )
        # asyncpg returns "DELETE N"
        deleted = int(result.split()[-1]) if result else 0
        logger.info(f"Cleaned up {deleted} expired A2A tasks (TTL={ttl_hours}h)")
        return deleted

    async def close(self) -> None:
        if self._pool:
            await self._pool.close()
            self._pool = None
