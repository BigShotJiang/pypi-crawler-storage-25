"""Aggregates skills from multiple sources into a list for the A2A Agent Card."""

from __future__ import annotations

import logging
import re
from typing import Any


logger = logging.getLogger(__name__)

_STOP_WORDS = frozenset({
    "the", "and", "for", "with", "from", "that", "this", "are", "was",
    "will", "can", "has", "have", "been", "not", "but", "all", "any",
    "each", "more", "also", "into", "over", "such", "than", "its",
    "about", "between", "through", "during", "before", "after",
})


class AgentCardSkillBuilder:
    """Aggregates skills from 3 levels into a list for the Agent Card."""

    MAX_FRAMEWORK_DESC_LENGTH = 500
    DEFAULT_FRAMEWORK_DESCRIPTION = (
        "Built-in framework capabilities including conversation management, "
        "skill orchestration, and session handling"
    )

    def build_skills(self, agent_instance: Any) -> list[dict]:
        """Collects skills from all sources and returns deduplicated list.

        Args:
            agent_instance: Agent providing skill information via duck typing.

        Returns:
            List of skill dicts ready for the Agent Card.
        """
        skills: list[dict] = []

        skills.extend(self._build_custom_skills(agent_instance))
        skills.extend(self._build_framework_skill(agent_instance))
        skills.extend(self._build_mcp_skills(agent_instance))
        skills.extend(self._build_tool_skills(agent_instance))

        skills = self._ensure_unique_ids(skills)
        skills = self._ensure_fallback(skills)

        return skills

    def _build_custom_skills(self, agent_instance: Any) -> list[dict]:
        """Level 1: custom skills with idempotent `custom-` ID prefixing."""
        try:
            raw_skills = agent_instance.get_a2a_skills()
        except Exception:
            logger.warning("Failed to retrieve custom A2A skills")
            return []

        result = []
        for skill in raw_skills:
            skill = dict(skill)
            skill_id = skill.get("id", "")
            if not skill_id.startswith("custom-"):
                skill["id"] = f"custom-{skill_id}"

            if not skill.get("tags"):
                name = skill.get("name", "")
                description = skill.get("description", "")
                skill["tags"] = self._extract_tags_from_text(name, description)

            result.append(skill)
        return result

    def _build_framework_skill(self, agent_instance: Any) -> list[dict]:
        """Level 2: single grouped `framework-capabilities` skill."""
        try:
            if not hasattr(agent_instance, "skill_registry"):
                return [self._make_default_framework_skill()]

            framework_skills = agent_instance.skill_registry.list_all()
            if not framework_skills:
                return [self._make_default_framework_skill()]

            names = [s.name for s in framework_skills]
            descriptions = [s.description for s in framework_skills]
            joined = "; ".join(descriptions)
            description = self._truncate_description(joined, len(framework_skills))

            return [{
                "id": "framework-capabilities",
                "name": "Framework Capabilities",
                "description": description,
                "tags": names,
            }]
        except Exception:
            logger.warning("Failed to build framework skill from registry")
            return [self._make_default_framework_skill()]

    def _build_mcp_skills(self, agent_instance: Any) -> list[dict]:
        """Level 3a: one skill per MCP server key."""
        try:
            mcp_params = agent_instance.get_mcp_server_params()
        except Exception:
            logger.warning("Failed to retrieve MCP server params")
            return []

        if not mcp_params:
            return []

        result = []
        for server_key in mcp_params:
            result.append({
                "id": f"mcp-{server_key}",
                "name": f"MCP: {server_key}",
                "description": f"MCP server: {server_key}",
                "tags": ["mcp", server_key],
            })
        return result

    def _build_tool_skills(self, agent_instance: Any) -> list[dict]:
        """Level 3b: one skill per agent tool."""
        try:
            agent_tools = agent_instance.get_agent_tools()
        except Exception:
            logger.warning("Failed to retrieve agent tools")
            return []

        result = []
        for tool in agent_tools:
            try:
                tool_name = (
                    getattr(tool, "__name__", None)
                    or getattr(tool, "name", None)
                    or str(tool)
                )
                result.append({
                    "id": f"tool-{tool_name}",
                    "name": tool_name,
                    "description": f"Tool: {tool_name}",
                    "tags": ["tool", tool_name],
                })
            except Exception:
                logger.warning("Failed to build skill for tool %s", tool)
        return result

    def _ensure_unique_ids(self, skills: list[dict]) -> list[dict]:
        """Deduplicates IDs by appending `-2`, `-3`, etc. to collisions."""
        seen: dict[str, int] = {}
        result = []
        for skill in skills:
            skill_id = skill.get("id", "")
            if skill_id not in seen:
                seen[skill_id] = 1
                result.append(skill)
            else:
                seen[skill_id] += 1
                new_skill = dict(skill)
                new_skill["id"] = f"{skill_id}-{seen[skill_id]}"
                result.append(new_skill)
        return result

    def _ensure_fallback(self, skills: list[dict]) -> list[dict]:
        """Adds `framework-capabilities` if no skills exist."""
        if not skills:
            return [self._make_default_framework_skill()]
        return skills

    def _extract_tags_from_text(self, name: str, description: str) -> list[str]:
        """Extracts tags from name and description text.

        Args:
            name: Skill name.
            description: Skill description.

        Returns:
            List of lowercase, deduplicated tags (max 10).
        """
        text = f"{name} {description}"
        tokens = re.split(r"[\s\-]+", text)
        seen: set[str] = set()
        tags: list[str] = []
        for token in tokens:
            word = token.strip().lower()
            if len(word) < 3:
                continue
            if word in _STOP_WORDS:
                continue
            if word in seen:
                continue
            seen.add(word)
            tags.append(word)
            if len(tags) >= 10:
                break
        return tags

    def _truncate_description(
        self, description: str, total_skills: int = 0
    ) -> str:
        """Truncates description to MAX_FRAMEWORK_DESC_LENGTH with suffix.

        Args:
            description: Raw joined description.
            total_skills: Total number of skills contributing to the description.

        Returns:
            Truncated description if needed, otherwise original.
        """
        if len(description) <= self.MAX_FRAMEWORK_DESC_LENGTH:
            return description

        # Count how many skill descriptions fit before the truncation point
        parts = description.split("; ")
        included = 0
        length = 0
        for i, part in enumerate(parts):
            addition = len(part) + (2 if i > 0 else 0)  # "; " separator
            if length + addition > 497:
                break
            length += addition
            included += 1

        remaining = total_skills - included
        suffix = f" (+{remaining} more)"

        # Truncate at 497 chars and add "..." then suffix
        truncated = description[:497] + "..."
        candidate = truncated + suffix

        # Ensure total doesn't exceed limit
        if len(candidate) > self.MAX_FRAMEWORK_DESC_LENGTH:
            available = self.MAX_FRAMEWORK_DESC_LENGTH - len("...") - len(suffix)
            truncated = description[:available] + "..."
            candidate = truncated + suffix

        return candidate

    def _make_default_framework_skill(self) -> dict:
        """Creates the default framework-capabilities skill."""
        return {
            "id": "framework-capabilities",
            "name": "Framework Capabilities",
            "description": self.DEFAULT_FRAMEWORK_DESCRIPTION,
            "tags": ["framework"],
        }
