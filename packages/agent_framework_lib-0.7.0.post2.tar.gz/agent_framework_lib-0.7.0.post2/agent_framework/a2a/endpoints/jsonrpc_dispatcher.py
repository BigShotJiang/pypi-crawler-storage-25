"""JSON-RPC 2.0 dispatcher for A2A protocol requests."""

import json
import logging
from typing import Any

from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import ValidationError

from .models_jsonrpc import (
    INTERNAL_ERROR,
    INVALID_PARAMS,
    INVALID_REQUEST,
    METHOD_NOT_FOUND,
    PARSE_ERROR,
    JSONRPCError,
    JSONRPCRequest,
    JSONRPCResponse,
    MessageSendParams,
    TaskCancelParams,
    TaskGetParams,
)

logger = logging.getLogger(__name__)


class JSONRPCDispatcher:
    """Dispatches JSON-RPC 2.0 requests to the appropriate A2A handler."""

    def __init__(self, translation_layer):
        """
        Args:
            translation_layer: A2ATranslationLayer instance for handling methods.
        """
        self._translation_layer = translation_layer

    async def dispatch(self, raw_body: bytes, app_state: Any) -> JSONResponse | StreamingResponse:
        """Parse and dispatch a JSON-RPC request.

        Args:
            raw_body: Raw HTTP body bytes.
            app_state: FastAPI app.state for context.

        Returns:
            JSONResponse for sync methods, StreamingResponse for message/stream.
        """
        request_id = None
        try:
            data = json.loads(raw_body)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return self._error_response(None, PARSE_ERROR, "Parse error")

        request_id = data.get("id") if isinstance(data, dict) else None

        try:
            request = JSONRPCRequest(**data)
        except (ValidationError, TypeError):
            return self._error_response(request_id, INVALID_REQUEST, "Invalid request")

        request_id = request.id

        return await self._route_method(request)

    async def _route_method(self, request: JSONRPCRequest) -> JSONResponse | StreamingResponse:
        """Route to the appropriate translation layer method.

        Args:
            request: Validated JSON-RPC request.

        Returns:
            Response from the handler.
        """
        method = request.method
        params = request.params or {}
        request_id = request.id

        try:
            if method == "message/send":
                try:
                    send_params = MessageSendParams(**params)
                except ValidationError as e:
                    return self._error_response(request_id, INVALID_PARAMS, "Invalid params", {"details": str(e)})
                result = await self._translation_layer.handle_message_send(send_params, request_id)
                return self._success_response(request_id, result)

            elif method == "message/stream":
                try:
                    stream_params = MessageSendParams(**params)
                except ValidationError as e:
                    return self._error_response(request_id, INVALID_PARAMS, "Invalid params", {"details": str(e)})
                generator = await self._translation_layer.handle_message_stream(stream_params, request_id)
                return StreamingResponse(generator, media_type="text/event-stream")

            elif method == "tasks/get":
                try:
                    get_params = TaskGetParams(**params)
                except ValidationError as e:
                    return self._error_response(request_id, INVALID_PARAMS, "Invalid params", {"details": str(e)})
                result = await self._translation_layer.handle_tasks_get(get_params, request_id)
                return self._success_response(request_id, result)

            elif method == "tasks/cancel":
                try:
                    cancel_params = TaskCancelParams(**params)
                except ValidationError as e:
                    return self._error_response(request_id, INVALID_PARAMS, "Invalid params", {"details": str(e)})
                result = await self._translation_layer.handle_tasks_cancel(cancel_params, request_id)
                return self._success_response(request_id, result)

            else:
                return self._error_response(request_id, METHOD_NOT_FOUND, "Method not found")

        except Exception:
            logger.exception("Internal error during JSON-RPC dispatch")
            return self._error_response(request_id, INTERNAL_ERROR, "Internal error")

    def _success_response(self, request_id: str | int | None, result: dict) -> JSONResponse:
        """Build a JSON-RPC success response."""
        resp = JSONRPCResponse(id=request_id, result=result)
        return JSONResponse(content=resp.model_dump())

    def _error_response(
        self,
        request_id: str | int | None,
        code: int,
        message: str,
        data: dict | None = None,
    ) -> JSONResponse:
        """Build a JSON-RPC error response."""
        error = JSONRPCError(code=code, message=message, data=data)
        resp = JSONRPCResponse(id=request_id, error=error)
        return JSONResponse(content=resp.model_dump())
