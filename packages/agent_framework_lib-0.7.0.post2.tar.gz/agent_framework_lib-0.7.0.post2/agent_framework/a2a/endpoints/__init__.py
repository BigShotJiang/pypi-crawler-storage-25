"""A2A Endpoints sub-module.

Provides JSON-RPC models, dispatcher, translation layer, SSE wrapper,
Agent Card builder, and FastAPI router for A2A protocol support.
"""

__all__ = [
    # JSON-RPC models
    "JSONRPCRequest",
    "JSONRPCResponse",
    "JSONRPCError",
    "A2AMessage",
    "A2APart",
    "MessageSendParams",
    "TaskGetParams",
    "TaskCancelParams",
    "A2ATaskResult",
    "A2ATaskStatus",
    "A2AArtifact",
    "TaskStatusUpdateEvent",
    "TaskArtifactUpdateEvent",
    "AgentCard",
    "AgentProvider",
    "AgentCapabilities",
    "AgentSkill",
    "A2AConfigRequest",
    # Error code constants
    "PARSE_ERROR",
    "INVALID_REQUEST",
    "METHOD_NOT_FOUND",
    "INVALID_PARAMS",
    "INTERNAL_ERROR",
    "TASK_NOT_FOUND",
    "TASK_NOT_CANCELABLE",
]

from .models_jsonrpc import (
    INTERNAL_ERROR,
    INVALID_PARAMS,
    INVALID_REQUEST,
    METHOD_NOT_FOUND,
    PARSE_ERROR,
    TASK_NOT_CANCELABLE,
    TASK_NOT_FOUND,
    A2AArtifact,
    A2AConfigRequest,
    A2AMessage,
    A2APart,
    A2ATaskResult,
    A2ATaskStatus,
    AgentCapabilities,
    AgentCard,
    AgentProvider,
    AgentSkill,
    JSONRPCError,
    JSONRPCRequest,
    JSONRPCResponse,
    MessageSendParams,
    TaskArtifactUpdateEvent,
    TaskCancelParams,
    TaskGetParams,
    TaskStatusUpdateEvent,
)
