"""Translation layer between A2A JSON-RPC protocol and the internal framework pipeline."""

from __future__ import annotations

import logging
import uuid
from collections.abc import AsyncGenerator
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

from ..base import TaskNotCancelableError, TaskNotFoundError
from ..models import A2ATask, TaskStatus
from .models_jsonrpc import (
    INTERNAL_ERROR,
    TASK_NOT_CANCELABLE,
    TASK_NOT_FOUND,
    A2AArtifact,
    A2AMessage,
    A2APart,
    A2ATaskResult,
    A2ATaskStatus,
    MessageSendParams,
    TaskCancelParams,
    TaskGetParams,
)

if TYPE_CHECKING:
    from ..base import A2ATaskProvider
    from .sse_wrapper import SSEWrapperA2A

logger = logging.getLogger(__name__)


class A2ATranslationLayer:
    """Orchestrates translation between A2A protocol and the internal framework pipeline."""

    def __init__(
        self,
        agent_instance: Any,
        task_provider: A2ATaskProvider,
        session_storage: Any,
        sse_wrapper: SSEWrapperA2A | None = None,
    ):
        """
        Args:
            agent_instance: The agent to call for message processing.
            task_provider: A2ATaskProvider for task lifecycle management.
            session_storage: Session storage for history retrieval.
            sse_wrapper: SSEWrapperA2A instance (optional, wired later).
        """
        self._agent = agent_instance
        self._task_provider = task_provider
        self._session_storage = session_storage
        self._sse_wrapper = sse_wrapper

    @staticmethod
    def extract_text(parts: list) -> str:
        """Extract and concatenate text from A2A Parts.

        Args:
            parts: List of A2APart objects or dicts with a 'text' field.

        Returns:
            Space-joined text from all parts containing text.
        """
        texts = []
        for part in parts:
            if hasattr(part, "text") and part.text:
                texts.append(part.text)
            elif isinstance(part, dict) and part.get("text"):
                texts.append(part["text"])
        return " ".join(texts)

    def _resolve_context(self, context_id: str | None) -> tuple[str, bool]:
        """Resolve contextId to session_id.

        Args:
            context_id: A2A context identifier, or None to create a new one.

        Returns:
            Tuple of (session_id, is_new). contextId maps 1:1 to session_id.
        """
        if context_id:
            return context_id, False
        new_id = str(uuid.uuid4())
        return new_id, True

    async def handle_message_send(self, params: MessageSendParams, request_id: Any) -> dict:
        """Process a synchronous message/send request.

        Calls the agent pipeline, consumes the full stream, and returns
        a completed A2A task with aggregated artifacts.

        Args:
            params: Validated message/send parameters.
            request_id: JSON-RPC request id for correlation.

        Returns:
            A2ATaskResult as a dict.

        Raises:
            TaskNotFoundError: If the task disappears mid-processing.
        """
        from ...core.agent_interface import StructuredAgentInput, TextInputPart

        text = self.extract_text(params.message.parts)
        context_id_param = getattr(params.configuration, "contextId", None) if params.configuration else None
        session_id, _is_new = self._resolve_context(context_id_param)
        context_id = session_id

        task_id = str(uuid.uuid4())
        agent_id = getattr(self._agent, "agent_id", "unknown")

        task: A2ATask | None = None
        try:
            task = await self._task_provider.create_task(
                task_id=task_id,
                context_id=context_id,
                session_id=session_id,
                message_id=str(uuid.uuid4()),
                agent_id=agent_id,
            )
            await self._task_provider.update_status(task_id, TaskStatus.WORKING.value)

            agent_input = StructuredAgentInput(
                query=text,
                parts=[TextInputPart(text=text)],
            )

            aggregated_text = await self._consume_stream(session_id, agent_input)

            artifact_id = str(uuid.uuid4())
            artifact = A2AArtifact(
                artifactId=artifact_id,
                name="response",
                parts=[A2APart(kind="text", text=aggregated_text)],
            )

            await self._task_provider.add_artifact_ref(
                task_id=task_id,
                artifact_id=artifact_id,
                name="response",
                parts_summary=[{"kind": "text", "text_length": len(aggregated_text)}],
            )
            await self._task_provider.update_status(task_id, TaskStatus.COMPLETED.value)

            result = A2ATaskResult(
                id=task_id,
                contextId=context_id,
                status=A2ATaskStatus(
                    state="completed",
                    timestamp=datetime.now(timezone.utc).isoformat(),
                ),
                artifacts=[artifact],
            )
            return result.model_dump()

        except Exception:
            logger.exception("Error during message/send processing")
            if task is not None:
                try:
                    await self._task_provider.update_status(task_id, TaskStatus.FAILED.value)
                except Exception:
                    logger.warning("Failed to update task status to failed", exc_info=True)
            raise

    async def _consume_stream(self, session_id: str, agent_input: Any) -> str:
        """Consume the agent's streaming response and aggregate text chunks.

        Args:
            session_id: Framework session id.
            agent_input: StructuredAgentInput for the agent.

        Returns:
            Aggregated text from all stream chunks.
        """
        chunks: list[str] = []
        async for output in self._agent.handle_message_stream(session_id, agent_input):
            if output.parts:
                for part in output.parts:
                    part_type = getattr(part, "type", None)
                    if part_type in ("text_output_stream", "text_output"):
                        text = getattr(part, "text", "") or ""
                        # Strip the streaming marker prefix
                        if text.startswith("__STREAM_CHUNK__"):
                            text = text[len("__STREAM_CHUNK__"):]
                        if text:
                            chunks.append(text)
            if output.response_text:
                chunks.append(output.response_text)
        return "".join(chunks)

    async def handle_message_stream(
        self, params: MessageSendParams, request_id: Any
    ) -> AsyncGenerator[str, None]:
        """Process a streaming message/stream request.

        Sets up the task, calls the agent pipeline, and delegates to the
        SSE wrapper for event translation.

        Args:
            params: Validated message/send parameters.
            request_id: JSON-RPC request id for correlation.

        Returns:
            Async generator yielding SSE-formatted strings.
        """
        from ...core.agent_interface import StructuredAgentInput, TextInputPart

        text = self.extract_text(params.message.parts)
        context_id_param = getattr(params.configuration, "contextId", None) if params.configuration else None
        session_id, _is_new = self._resolve_context(context_id_param)
        context_id = session_id

        task_id = str(uuid.uuid4())
        agent_id = getattr(self._agent, "agent_id", "unknown")

        await self._task_provider.create_task(
            task_id=task_id,
            context_id=context_id,
            session_id=session_id,
            message_id=str(uuid.uuid4()),
            agent_id=agent_id,
        )
        await self._task_provider.update_status(task_id, TaskStatus.WORKING.value)

        agent_input = StructuredAgentInput(
            query=text,
            parts=[TextInputPart(text=text)],
        )

        internal_stream = self._agent.handle_message_stream(session_id, agent_input)

        if self._sse_wrapper is not None:
            async for event in self._sse_wrapper.wrap_stream(
                internal_stream, task_id, context_id, request_id
            ):
                yield event
        else:
            # Fallback: consume stream and yield a single completed event
            aggregated = await self._consume_stream_from_generator(internal_stream)
            await self._task_provider.update_status(task_id, TaskStatus.COMPLETED.value)
            result = A2ATaskResult(
                id=task_id,
                contextId=context_id,
                status=A2ATaskStatus(
                    state="completed",
                    timestamp=datetime.now(timezone.utc).isoformat(),
                ),
                artifacts=[
                    A2AArtifact(
                        artifactId=str(uuid.uuid4()),
                        name="response",
                        parts=[A2APart(kind="text", text=aggregated)],
                    )
                ],
            )
            import json
            yield f"data: {json.dumps(result.model_dump())}\n\n"

    async def _consume_stream_from_generator(self, stream: AsyncGenerator) -> str:
        """Consume an already-created async generator and aggregate text.

        Args:
            stream: Async generator of StructuredAgentOutput.

        Returns:
            Aggregated text.
        """
        chunks: list[str] = []
        async for output in stream:
            if output.parts:
                for part in output.parts:
                    part_type = getattr(part, "type", None)
                    if part_type in ("text_output_stream", "text_output"):
                        text = getattr(part, "text", "") or ""
                        if text.startswith("__STREAM_CHUNK__"):
                            text = text[len("__STREAM_CHUNK__"):]
                        if text:
                            chunks.append(text)
            if output.response_text:
                chunks.append(output.response_text)
        return "".join(chunks)

    async def handle_tasks_get(self, params: TaskGetParams, request_id: Any) -> dict:
        """Retrieve a task from the Task Store.

        Args:
            params: Validated tasks/get parameters.
            request_id: JSON-RPC request id for correlation.

        Returns:
            A2ATaskResult as a dict.

        Raises:
            TaskNotFoundError: If the task does not exist.
        """
        task = await self._task_provider.get_task(params.id)
        if task is None:
            raise TaskNotFoundError(params.id)

        artifacts = self._build_artifacts_from_task(task)

        history: list[A2AMessage] | None = None
        if params.historyLength and params.historyLength > 0:
            history = await self._get_history(task.session_id, params.historyLength)

        result = A2ATaskResult(
            id=task.id,
            contextId=task.context_id,
            status=A2ATaskStatus(
                state=task.status.value,
                timestamp=task.updated_at.isoformat() if task.updated_at else None,
                message=A2AMessage(
                    role="agent",
                    parts=[A2APart(kind="text", text=task.status_message.get("text", ""))],
                ) if task.status_message and task.status_message.get("text") else None,
            ),
            artifacts=artifacts if artifacts else None,
            history=history,
        )
        return result.model_dump()

    def _build_artifacts_from_task(self, task: A2ATask) -> list[A2AArtifact]:
        """Build A2A artifacts from task artifact_refs.

        Args:
            task: The A2ATask with artifact references.

        Returns:
            List of A2AArtifact objects.
        """
        artifacts = []
        for ref in task.artifact_refs:
            artifact = A2AArtifact(
                artifactId=ref.get("artifact_id", str(uuid.uuid4())),
                name=ref.get("name"),
                parts=[A2APart(kind="text", text=ref.get("text", ""))],
            )
            artifacts.append(artifact)
        return artifacts

    async def _get_history(self, session_id: str, history_length: int) -> list[A2AMessage]:
        """Retrieve the last N messages from session history.

        Args:
            session_id: Framework session id.
            history_length: Maximum number of messages to return.

        Returns:
            List of A2AMessage objects.
        """
        messages: list[A2AMessage] = []
        try:
            if self._session_storage is None:
                return messages

            # Try common session storage interface patterns
            history = None
            if hasattr(self._session_storage, "get_session_history"):
                history = await self._session_storage.get_session_history(session_id)
            elif hasattr(self._session_storage, "get_history"):
                history = await self._session_storage.get_history(session_id)

            if not history:
                return messages

            # Take the last N entries
            recent = history[-history_length:] if len(history) > history_length else history

            for entry in recent:
                role = entry.get("role", "user") if isinstance(entry, dict) else "user"
                a2a_role = "agent" if role in ("assistant", "agent") else "user"
                text = ""
                if isinstance(entry, dict):
                    text = entry.get("content", "") or entry.get("text", "") or ""
                messages.append(
                    A2AMessage(
                        role=a2a_role,
                        parts=[A2APart(kind="text", text=str(text))],
                    )
                )
        except Exception:
            logger.warning("Failed to retrieve session history", exc_info=True)

        return messages

    async def handle_tasks_cancel(self, params: TaskCancelParams, request_id: Any) -> dict:
        """Cancel a task via the Task Store.

        Args:
            params: Validated tasks/cancel parameters.
            request_id: JSON-RPC request id for correlation.

        Returns:
            A2ATaskResult as a dict.

        Raises:
            TaskNotFoundError: If the task does not exist.
            TaskNotCancelableError: If the task is in a terminal state.
        """
        task = await self._task_provider.cancel_task(params.id)

        result = A2ATaskResult(
            id=task.id,
            contextId=task.context_id,
            status=A2ATaskStatus(
                state=task.status.value,
                timestamp=task.updated_at.isoformat() if task.updated_at else None,
            ),
        )
        return result.model_dump()
