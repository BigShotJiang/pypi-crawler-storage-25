"""Pydantic v2 models for JSON-RPC 2.0 A2A protocol."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel

# JSON-RPC 2.0 standard error codes
PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603

# A2A-specific error codes
TASK_NOT_FOUND = -32001
TASK_NOT_CANCELABLE = -32002


class JSONRPCRequest(BaseModel):
    """Incoming JSON-RPC 2.0 request."""

    jsonrpc: Literal["2.0"]
    id: str | int | None = None
    method: str
    params: dict[str, Any] | None = None


class JSONRPCError(BaseModel):
    """JSON-RPC 2.0 error object."""

    code: int
    message: str
    data: dict[str, Any] | None = None


class JSONRPCResponse(BaseModel):
    """JSON-RPC 2.0 response."""

    jsonrpc: Literal["2.0"] = "2.0"
    id: str | int | None = None
    result: dict[str, Any] | None = None
    error: JSONRPCError | None = None


class A2APart(BaseModel):
    """Content part within an A2A message."""

    kind: Literal["text", "file", "data"]
    text: str | None = None


class A2AMessage(BaseModel):
    """A2A protocol message."""

    role: Literal["user", "agent"]
    parts: list[A2APart]
    messageId: str | None = None


class MessageConfiguration(BaseModel):
    """Optional configuration for message/send and message/stream."""

    acceptedOutputModes: list[str] | None = None
    historyLength: int | None = None
    blocking: bool | None = None


class MessageSendParams(BaseModel):
    """Parameters for message/send and message/stream methods."""

    message: A2AMessage
    configuration: MessageConfiguration | None = None


class TaskGetParams(BaseModel):
    """Parameters for tasks/get method."""

    id: str
    historyLength: int | None = None


class TaskCancelParams(BaseModel):
    """Parameters for tasks/cancel method."""

    id: str


class A2ATaskStatus(BaseModel):
    """Status of an A2A task."""

    state: str
    timestamp: str | None = None
    message: A2AMessage | None = None


class A2AArtifact(BaseModel):
    """Output artifact produced by an agent."""

    artifactId: str
    name: str | None = None
    parts: list[A2APart]
    append: bool | None = None


class A2ATaskResult(BaseModel):
    """Complete A2A task with status and artifacts."""

    id: str
    contextId: str
    status: A2ATaskStatus
    artifacts: list[A2AArtifact] | None = None
    history: list[A2AMessage] | None = None


class TaskStatusUpdateEvent(BaseModel):
    """SSE event for task status changes."""

    id: str
    contextId: str
    status: A2ATaskStatus


class TaskArtifactUpdateEvent(BaseModel):
    """SSE event for new or appended artifacts."""

    id: str
    contextId: str
    artifact: A2AArtifact


class AgentProvider(BaseModel):
    """Organization providing the agent."""

    organization: str
    url: str | None = None


class AgentCapabilities(BaseModel):
    """Declared capabilities of an agent."""

    streaming: bool = True
    pushNotifications: bool = False
    stateTransitionHistory: bool = True


class AgentSkill(BaseModel):
    """A skill exposed by the agent."""

    id: str
    name: str
    description: str
    tags: list[str] = []
    examples: list[str] = []


class AgentCard(BaseModel):
    """Agent discovery document served at /.well-known/agent.json."""

    name: str
    description: str
    url: str
    version: str
    protocolVersion: Literal["1.0"] = "1.0"
    provider: AgentProvider | None = None
    capabilities: AgentCapabilities
    defaultInputModes: list[str] = ["text"]
    defaultOutputModes: list[str] = ["text"]
    skills: list[AgentSkill] = []


class A2AConfigRequest(BaseModel):
    """Body for POST /a2a/config endpoint."""

    url: str
