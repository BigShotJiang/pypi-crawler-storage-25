"""Translates internal framework SSE events into A2A-compliant SSE events."""

import json
import logging
import uuid
from collections.abc import AsyncGenerator
from datetime import datetime, timezone
from typing import Any

from .models_jsonrpc import (
    A2AArtifact,
    A2AMessage,
    A2APart,
    A2ATaskStatus,
    TaskArtifactUpdateEvent,
    TaskStatusUpdateEvent,
)

logger = logging.getLogger(__name__)


class SSEWrapperA2A:
    """Translates internal framework SSE events into A2A-compliant SSE events."""

    async def wrap_stream(
        self,
        internal_stream: AsyncGenerator,
        task_id: str,
        context_id: str,
        request_id: Any,
    ) -> AsyncGenerator[str, None]:
        """Wrap an internal agent stream into A2A SSE events.

        Args:
            internal_stream: Async generator of StructuredAgentOutput.
            task_id: A2A task identifier.
            context_id: A2A context identifier.
            request_id: JSON-RPC request id for correlation.

        Yields:
            SSE-formatted strings (data: {json}\\n\\n).
        """
        is_first_chunk = True

        yield self._format_sse(
            request_id, self._status_event(task_id, context_id, "working")
        )

        try:
            async for output in internal_stream:
                if output.parts:
                    for part in output.parts:
                        part_type = getattr(part, "type", None)

                        if part_type in ("text_output_stream", "text_output"):
                            text = getattr(part, "text", "") or ""

                            # Skip activity markers and emit status event
                            if text.startswith("__STREAM_ACTIVITY__"):
                                activity_text = text[len("__STREAM_ACTIVITY__"):]
                                yield self._format_sse(
                                    request_id,
                                    self._status_event(
                                        task_id, context_id, "working", activity_text
                                    ),
                                )
                                continue

                            # Strip chunk marker prefix
                            if text.startswith("__STREAM_CHUNK__"):
                                text = text[len("__STREAM_CHUNK__"):]

                            if text:
                                append = not is_first_chunk
                                yield self._format_sse(
                                    request_id,
                                    self._artifact_event(
                                        task_id, context_id, text, append
                                    ),
                                )
                                is_first_chunk = False

                        elif part_type == "activity":
                            activity_type = getattr(part, "activity_type", "")
                            content = getattr(part, "content", "") or activity_type
                            yield self._format_sse(
                                request_id,
                                self._status_event(
                                    task_id, context_id, "working", content
                                ),
                            )

            yield self._format_sse(
                request_id, self._status_event(task_id, context_id, "completed")
            )

        except Exception as e:
            logger.exception("Error during SSE streaming")
            error_msg = f"Internal error: {e}"
            yield self._format_sse(
                request_id,
                self._status_event(task_id, context_id, "failed", error_msg),
            )

    def _status_event(
        self,
        task_id: str,
        context_id: str,
        state: str,
        message_text: str | None = None,
    ) -> dict:
        """Build a TaskStatusUpdateEvent dict."""
        status = A2ATaskStatus(
            state=state,
            timestamp=datetime.now(timezone.utc).isoformat(),
        )
        if message_text:
            status.message = A2AMessage(
                role="agent",
                parts=[A2APart(kind="text", text=message_text)],
            )
        event = TaskStatusUpdateEvent(
            id=task_id,
            contextId=context_id,
            status=status,
        )
        return event.model_dump()

    def _artifact_event(
        self,
        task_id: str,
        context_id: str,
        text: str,
        append: bool,
    ) -> dict:
        """Build a TaskArtifactUpdateEvent dict."""
        artifact = A2AArtifact(
            artifactId=str(uuid.uuid4()),
            name="response",
            parts=[A2APart(kind="text", text=text)],
            append=append,
        )
        event = TaskArtifactUpdateEvent(
            id=task_id,
            contextId=context_id,
            artifact=artifact,
        )
        return event.model_dump()

    def _format_sse(self, request_id: Any, result: dict) -> str:
        """Format a result as an SSE data line with JSON-RPC 2.0 wrapper."""
        payload = {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": result,
        }
        return f"data: {json.dumps(payload)}\n\n"
