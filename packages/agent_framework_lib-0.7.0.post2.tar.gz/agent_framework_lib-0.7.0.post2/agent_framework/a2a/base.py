"""Abstract interface for A2A Task Store providers."""

import logging
from abc import ABC, abstractmethod

from .models import A2ATask


logger = logging.getLogger(__name__)


class A2ATaskProviderError(Exception):
    """Base exception for task provider errors."""
    def __init__(self, message: str, code: int = -32603):
        super().__init__(message)
        self.code = code


class TaskNotFoundError(A2ATaskProviderError):
    """Raised when a task ID is not found."""
    def __init__(self, task_id: str):
        super().__init__(f"Task not found: {task_id}", code=-32001)
        self.task_id = task_id


class TaskNotCancelableError(A2ATaskProviderError):
    """Raised when trying to cancel a task in a terminal state."""
    def __init__(self, task_id: str, current_state: str):
        super().__init__(
            f"Task {task_id} is in terminal state '{current_state}' and cannot be canceled",
            code=-32002,
        )
        self.task_id = task_id
        self.current_state = current_state


class TaskTerminalStateError(A2ATaskProviderError):
    """Raised when trying to update a task already in a terminal state."""
    def __init__(self, task_id: str, current_state: str):
        super().__init__(
            f"Task {task_id} is in terminal state '{current_state}' and cannot be modified",
            code=-32002,
        )
        self.task_id = task_id
        self.current_state = current_state


class A2ATaskProvider(ABC):
    """Abstract interface for A2A task storage.

    The provider stores only the mapping task ↔ session and the A2A status.
    Conversational content stays in the existing framework session store.
    """

    @abstractmethod
    async def initialize(self) -> bool:
        """Initialize the provider (create index/table if needed).

        Returns:
            True if initialization succeeded.
        """
        ...

    @abstractmethod
    async def create_task(
        self,
        task_id: str,
        context_id: str,
        session_id: str,
        message_id: str,
        agent_id: str,
        metadata: dict | None = None,
    ) -> A2ATask:
        """Create a new task entry.

        Args:
            task_id: Unique task identifier (UUID).
            context_id: A2A context (maps to session_id).
            session_id: Framework session ID.
            message_id: Framework message ID that triggered this task.
            agent_id: Agent identifier.
            metadata: Optional extra metadata.

        Returns:
            The created A2ATask.
        """
        ...

    @abstractmethod
    async def get_task(self, task_id: str) -> A2ATask | None:
        """Retrieve a task by ID.

        Returns:
            The task, or None if not found.
        """
        ...

    @abstractmethod
    async def update_status(
        self,
        task_id: str,
        state: str,
        status_message: dict | None = None,
    ) -> A2ATask:
        """Update the status of a task.

        Args:
            task_id: Task to update.
            state: New state value.
            status_message: Optional status message dict.

        Returns:
            The updated task.

        Raises:
            TaskNotFoundError: If the task does not exist.
            TaskTerminalStateError: If the task is already in a terminal state.
        """
        ...

    @abstractmethod
    async def add_artifact_ref(
        self,
        task_id: str,
        artifact_id: str,
        name: str,
        parts_summary: list[dict],
    ) -> A2ATask:
        """Add an artifact reference to a task.

        Args:
            task_id: Task to update.
            artifact_id: Unique artifact identifier.
            name: Human-readable artifact name.
            parts_summary: Summary of artifact parts (not full content).

        Returns:
            The updated task.

        Raises:
            TaskNotFoundError: If the task does not exist.
        """
        ...

    @abstractmethod
    async def list_tasks(
        self,
        context_id: str | None = None,
        state: str | None = None,
        agent_id: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[A2ATask]:
        """List tasks with optional filters.

        Args:
            context_id: Filter by context.
            state: Filter by state.
            agent_id: Filter by agent.
            limit: Max results.
            offset: Pagination offset.

        Returns:
            List of matching tasks.
        """
        ...

    @abstractmethod
    async def cancel_task(self, task_id: str) -> A2ATask:
        """Cancel a task.

        Only non-terminal tasks can be canceled.

        Returns:
            The updated task with status 'canceled'.

        Raises:
            TaskNotFoundError: If the task does not exist.
            TaskNotCancelableError: If the task is in a terminal state.
        """
        ...

    @abstractmethod
    async def cleanup_expired(self, ttl_hours: int = 24) -> int:
        """Remove terminal tasks older than the TTL.

        Args:
            ttl_hours: Hours after which terminal tasks are deleted.

        Returns:
            Number of tasks deleted.
        """
        ...

    async def close(self) -> None:
        """Release resources. Override if needed."""
        pass

    @property
    @abstractmethod
    def is_initialized(self) -> bool:
        """Whether the provider has been initialized."""
        ...
