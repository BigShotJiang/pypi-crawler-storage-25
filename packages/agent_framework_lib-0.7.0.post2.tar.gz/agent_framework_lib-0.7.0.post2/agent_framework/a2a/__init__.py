"""
A2A (Agent-to-Agent) Protocol Module.

Provides A2A protocol support for the Agent Framework:
- Task Store with pluggable providers (Elasticsearch, PostgreSQL)
- A2A Task lifecycle management (submitted → working → completed/failed/canceled)

The Task Store is a lightweight mapping layer: it links A2A task IDs
to existing framework sessions, without duplicating conversational content.
"""

from .models import A2ATask, TaskStatus
from .base import A2ATaskProvider
from .providers import (
    ElasticsearchTaskProvider,
    PostgresTaskProvider,
    ELASTICSEARCH_PROVIDER_AVAILABLE,
    POSTGRES_PROVIDER_AVAILABLE,
)

__all__ = [
    "A2ATask",
    "TaskStatus",
    "A2ATaskProvider",
    "ElasticsearchTaskProvider",
    "PostgresTaskProvider",
    "ELASTICSEARCH_PROVIDER_AVAILABLE",
    "POSTGRES_PROVIDER_AVAILABLE",
    "endpoints",
]

from . import endpoints

__version__ = "0.1.0"
