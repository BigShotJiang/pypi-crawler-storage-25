"""
User Personalization Module.

Analyzes user interaction history from Graphiti to detect preferences
(response style, preferred formats, topic interests, model preferences)
and applies them to agent session configuration.

Components:
    - UserPersonalizationAnalyzer: Heuristic analysis of past interactions
    - PreferenceApplicator: Applies detected preferences to agent config
"""

from __future__ import annotations

import logging
import re
from collections import Counter
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Pattern definitions for heuristic detection
# ---------------------------------------------------------------------------

# Concise style indicators (FR + EN)
_CONCISE_PATTERNS: list[re.Pattern] = [
    re.compile(r"\br[ée]sum[ée]\b", re.IGNORECASE),
    re.compile(r"\bbref\b", re.IGNORECASE),
    re.compile(r"\bcourt\b", re.IGNORECASE),
    re.compile(r"\bpr[ée]cis\b", re.IGNORECASE),
    re.compile(r"\btrop long\b", re.IGNORECASE),
    re.compile(r"\bquick\b", re.IGNORECASE),
    re.compile(r"\bsummary\b", re.IGNORECASE),
    re.compile(r"\bbrief\b", re.IGNORECASE),
    re.compile(r"\bshort\b", re.IGNORECASE),
    re.compile(r"\bconcise\b", re.IGNORECASE),
]

# Detailed style indicators (FR + EN)
_DETAILED_PATTERNS: list[re.Pattern] = [
    re.compile(r"\ben d[ée]tail\b", re.IGNORECASE),
    re.compile(r"\bexplique\b", re.IGNORECASE),
    re.compile(r"\bapprofondi", re.IGNORECASE),
    re.compile(r"\bcomprendre\b", re.IGNORECASE),
    re.compile(r"\btous les aspects\b", re.IGNORECASE),
    re.compile(r"\bpourquoi\b", re.IGNORECASE),
    re.compile(r"\bdetail\b", re.IGNORECASE),
    re.compile(r"\bexplain\b", re.IGNORECASE),
    re.compile(r"\bcomprehensive\b", re.IGNORECASE),
    re.compile(r"\bin depth\b", re.IGNORECASE),
    re.compile(r"\bwith examples\b", re.IGNORECASE),
]

# Format indicators
_FORMAT_PATTERNS: dict[str, list[re.Pattern]] = {
    "table": [
        re.compile(r"\btableau\b", re.IGNORECASE),
        re.compile(r"\btable\b", re.IGNORECASE),
    ],
    "chart": [
        re.compile(r"\bgraphique\b", re.IGNORECASE),
        re.compile(r"\bchart\b", re.IGNORECASE),
        re.compile(r"\bvisualis", re.IGNORECASE),
        re.compile(r"\bvisualiz", re.IGNORECASE),
    ],
}

# Topic indicators
_TOPIC_PATTERNS: dict[str, list[re.Pattern]] = {
    "sql": [
        re.compile(r"\bsql\b", re.IGNORECASE),
        re.compile(r"\brequ[êe]te\b", re.IGNORECASE),
        re.compile(r"\bquery\b", re.IGNORECASE),
        re.compile(r"\bdatabase\b", re.IGNORECASE),
        re.compile(r"\bselect\b", re.IGNORECASE),
    ],
    "analytics": [
        re.compile(r"\bm[ée]trique", re.IGNORECASE),
        re.compile(r"\banalyse\b", re.IGNORECASE),
        re.compile(r"\bkpi\b", re.IGNORECASE),
        re.compile(r"\bdashboard\b", re.IGNORECASE),
        re.compile(r"\bmetric", re.IGNORECASE),
    ],
}


def _count_pattern_matches(text: str, patterns: list[re.Pattern]) -> int:
    """Count how many patterns match in the given text."""
    return sum(1 for p in patterns if p.search(text))


def _default_preferences() -> dict[str, Any]:
    """Return a default preferences dict with no detected preferences."""
    return {
        "response_style": "balanced",
        "response_style_confidence": 0.0,
        "preferred_model": None,
        "model_confidence": 0.0,
        "preferred_formats": [],
        "format_confidence": 0.0,
        "topic_interests": [],
        "overall_confidence": 0.0,
        "total_interactions": 0,
    }

def _is_non_default(key: str, value: Any, defaults: dict[str, Any]) -> bool:
    """Determine if a preference value is non-default for a given attribute.

    Args:
        key: The preference attribute name.
        value: The value to check.
        defaults: The default preferences dict.

    Returns:
        True if the value differs from the default for this key.
    """
    default_val = defaults.get(key)
    if value is None and default_val is None:
        return False
    if isinstance(default_val, list):
        return len(value) > 0 if isinstance(value, list) else value != default_val
    if isinstance(default_val, float) and default_val == 0.0:
        return isinstance(value, (int, float)) and value > 0.0
    return value != default_val


def _build_source_description(scope: str) -> str:
    """Return the source_description string for a given scope.

    Args:
        scope: Either ``"global"`` or an agent_id.

    Returns:
        A string in the format ``"native_user_preferences:scope={scope}"``.
    """
    return f"native_user_preferences:scope={scope}"


# Attributes that participate in the merge (excluding computed fields)
_MERGEABLE_KEYS: list[str] = [
    "response_style",
    "response_style_confidence",
    "preferred_model",
    "model_confidence",
    "preferred_formats",
    "format_confidence",
    "topic_interests",
]


def merge_preferences(
    global_prefs: dict[str, Any],
    agent_prefs: dict[str, Any],
    default_prefs: dict[str, Any],
) -> dict[str, Any]:
    """Merge preferences with priority: agent > global > default.

    For each mergeable attribute the agent-specific value is used when it is
    non-default, otherwise the global value is used when it is non-default,
    otherwise the default value is used.

    The returned dict contains a ``scope_origin`` mapping that records, for
    each attribute, whether the effective value came from the agent
    (``agent_id``), ``"global"``, or ``"default"``.

    Args:
        global_prefs: Detected global preferences.
        agent_prefs: Detected agent-specific preferences.
        default_prefs: Default values from ``_default_preferences()``.

    Returns:
        Merged dict with an additional ``scope_origin`` field.
    """
    result = dict(default_prefs)
    scope_origin: dict[str, str] = {}

    # Determine the agent scope label from agent_prefs metadata if available,
    # otherwise fall back to "agent".
    agent_scope_label = agent_prefs.get("_scope_label", "agent")

    for key in _MERGEABLE_KEYS:
        agent_val = agent_prefs.get(key, default_prefs.get(key))
        global_val = global_prefs.get(key, default_prefs.get(key))

        if _is_non_default(key, agent_val, default_prefs):
            result[key] = agent_val
            scope_origin[key] = agent_scope_label
        elif _is_non_default(key, global_val, default_prefs):
            result[key] = global_val
            scope_origin[key] = "global"
        else:
            result[key] = default_prefs.get(key)
            scope_origin[key] = "default"

    # Recompute overall_confidence and total_interactions from merged values
    confidences = [
        result.get("response_style_confidence", 0.0),
        result.get("model_confidence", 0.0),
        result.get("format_confidence", 0.0),
    ]
    non_zero = [c for c in confidences if c > 0]
    result["overall_confidence"] = sum(non_zero) / len(non_zero) if non_zero else 0.0

    # total_interactions: take the max of both scopes
    result["total_interactions"] = max(
        global_prefs.get("total_interactions", 0),
        agent_prefs.get("total_interactions", 0),
        default_prefs.get("total_interactions", 0),
    )

    result["scope_origin"] = scope_origin
    return result



# ---------------------------------------------------------------------------
# UserPersonalizationAnalyzer
# ---------------------------------------------------------------------------


class UserPersonalizationAnalyzer:
    """Analyze user interaction history to detect preferences.

    Uses heuristic pattern matching on past messages retrieved from
    Graphiti via the provider's ``recall()`` method.
    """

    def __init__(self, provider: Any) -> None:
        self._provider = provider

    async def analyze_user_preferences(
        self,
        user_id: str,
        agent_id: str,
        min_interactions: int = 5,
    ) -> dict[str, Any]:
        """Analyze past interactions and return scoped, merged preferences.

        Performs two recall() calls:
        1. Global preferences (scope=global)
        2. Agent-specific preferences (scope=agent_id)

        Merges according to priority: agent > global > default.
        Adds scope_origin for each attribute.

        Signature unchanged — backward compatible.

        Args:
            user_id: The user whose history to analyze.
            agent_id: Agent context for the recall query.
            min_interactions: Minimum interactions required before
                making confident predictions.

        Returns:
            A dict with keys: response_style, response_style_confidence,
            preferred_model, model_confidence, preferred_formats,
            format_confidence, topic_interests, overall_confidence,
            total_interactions, scope_origin.
        """
        try:
            # 1. Recall global preferences — queries in both FR and EN to match stored facts
            global_context = await self._provider.recall(
                user_id=user_id,
                agent_id=agent_id,
                query="préférences style réponse concise détaillée utilisateur",
                limit=100,
            )
            global_facts = global_context.facts if global_context else []

            # 2. Recall agent-specific preferences
            agent_context = await self._provider.recall(
                user_id=user_id,
                agent_id=agent_id,
                query=f"préférences format sujet style {agent_id}",
                limit=100,
            )
            agent_facts = agent_context.facts if agent_context else []

            logger.debug(
                "Personalization recall: global_facts=%d, agent_facts=%d",
                len(global_facts),
                len(agent_facts),
            )
            for f in (global_facts + agent_facts)[:5]:
                logger.debug("  fact content: %r", f.content)
        except Exception as e:
            logger.warning("Failed to recall interactions for personalization: %s", e)
            return _default_preferences()

        # 3. Analyze each set of facts independently
        global_prefs = self._analyze_facts(global_facts, min_interactions)
        agent_prefs = self._analyze_facts(agent_facts, min_interactions)
        agent_prefs["_scope_label"] = agent_id

        # 4. Merge with priority: agent > global > default
        defaults = _default_preferences()
        return merge_preferences(global_prefs, agent_prefs, defaults)


    def _analyze_facts(
        self,
        facts: list[Any],
        min_interactions: int,
    ) -> dict[str, Any]:
        """Run heuristic analysis on a list of facts and return preferences.

        This is a pure computation method (no I/O) extracted from
        ``analyze_user_preferences`` so it can be reused for both
        global and agent-scoped fact sets.

        Args:
            facts: List of ``MemoryFact`` objects to analyze.
            min_interactions: Minimum number of facts required before
                making confident predictions.

        Returns:
            A preferences dict with the same structure as
            ``_default_preferences()``.
        """
        total = len(facts)
        prefs = _default_preferences()
        prefs["total_interactions"] = total

        if total < min_interactions:
            return prefs

        # Collect all message contents
        messages = [f.content for f in facts if f.content]

        # --- Response style detection ---
        concise_score = 0
        detailed_score = 0
        for msg in messages:
            concise_score += _count_pattern_matches(msg, _CONCISE_PATTERNS)
            detailed_score += _count_pattern_matches(msg, _DETAILED_PATTERNS)

        total_style_hits = concise_score + detailed_score
        if total_style_hits > 0:
            if concise_score > detailed_score:
                prefs["response_style"] = "concise"
                prefs["response_style_confidence"] = concise_score / total_style_hits
            elif detailed_score > concise_score:
                prefs["response_style"] = "detailed"
                prefs["response_style_confidence"] = detailed_score / total_style_hits
            else:
                prefs["response_style"] = "balanced"
                prefs["response_style_confidence"] = 0.5

        # --- Model preference detection ---
        model_counts: Counter[str] = Counter()
        for f in facts:
            if f.metadata and isinstance(f.metadata, dict):
                model = f.metadata.get("model_used")
                if model:
                    model_counts[model] += 1

        if model_counts:
            top_model, top_count = model_counts.most_common(1)[0]
            prefs["preferred_model"] = top_model
            prefs["model_confidence"] = top_count / total
        else:
            prefs["preferred_model"] = None
            prefs["model_confidence"] = 0.0

        # --- Format preference detection ---
        format_counts: Counter[str] = Counter()
        for msg in messages:
            for fmt, patterns in _FORMAT_PATTERNS.items():
                if _count_pattern_matches(msg, patterns) > 0:
                    format_counts[fmt] += 1

        if format_counts:
            prefs["preferred_formats"] = [
                fmt for fmt, _ in format_counts.most_common()
            ]
            top_fmt_count = format_counts.most_common(1)[0][1]
            prefs["format_confidence"] = top_fmt_count / total
        else:
            prefs["preferred_formats"] = []
            prefs["format_confidence"] = 0.0

        # --- Topic interest detection ---
        topic_counts: Counter[str] = Counter()
        for msg in messages:
            for topic, patterns in _TOPIC_PATTERNS.items():
                if _count_pattern_matches(msg, patterns) > 0:
                    topic_counts[topic] += 1

        prefs["topic_interests"] = [
            topic for topic, _ in topic_counts.most_common()
        ]

        # --- Overall confidence ---
        confidences = [
            prefs["response_style_confidence"],
            prefs["model_confidence"],
            prefs["format_confidence"],
        ]
        non_zero = [c for c in confidences if c > 0]
        prefs["overall_confidence"] = (
            sum(non_zero) / len(non_zero) if non_zero else 0.0
        )

        return prefs

    async def store_scoped_preferences(
        self,
        user_id: str,
        preferences: dict[str, Any],
        scope: str,
    ) -> bool:
        """Store preferences with a given scope via add_structured_data.

        Args:
            user_id: User identifier.
            preferences: Preferences dict to store.
            scope: ``"global"`` or a specific agent_id.

        Returns:
            True if stored successfully.
        """
        try:
            source_desc = _build_source_description(scope)
            return await self._provider.add_structured_data(
                user_id=user_id,
                data=preferences,
                source_description=source_desc,
            )
        except Exception as e:
            logger.warning("Failed to store scoped preferences (scope=%s): %s", scope, e)
            return False



# ---------------------------------------------------------------------------
# PreferenceApplicator
# ---------------------------------------------------------------------------

# Style instruction templates
_STYLE_INSTRUCTIONS: dict[str, str] = {
    "concise": (
        "[User Preference] This user prefers concise, brief responses. "
        "Keep answers short and to the point. Avoid unnecessary elaboration."
    ),
    "detailed": (
        "[User Preference] This user prefers detailed, comprehensive responses. "
        "Provide thorough explanations with examples when relevant."
    ),
}


class PreferenceApplicator:
    """Apply detected preferences to an agent session configuration."""

    @staticmethod
    def apply_to_config(
        base_config: dict[str, Any],
        preferences: dict[str, Any],
        min_confidence: float = 0.3,
    ) -> dict[str, Any]:
        """Enrich *base_config* with user *preferences*.

        Args:
            base_config: The original session config (system_prompt, model_name, …).
            preferences: Output of ``UserPersonalizationAnalyzer.analyze_user_preferences``.
            min_confidence: Minimum confidence threshold to apply a preference.

        Returns:
            A new config dict with preferences applied and a ``native_user_preferences`` key.
        """
        config = dict(base_config)
        scope_origin = preferences.get("scope_origin", {})

        # --- Apply response style ---
        style = preferences.get("response_style", "balanced")
        style_conf = preferences.get("response_style_confidence", 0.0)

        if style in _STYLE_INSTRUCTIONS and style_conf >= min_confidence:
            prompt = config.get("system_prompt", "")
            instruction = _STYLE_INSTRUCTIONS[style]

            # Add scope mention if scope_origin is available
            style_scope = scope_origin.get("response_style")
            if style_scope and style_scope != "default":
                if style_scope == "global":
                    instruction += " (source: global user preference)"
                else:
                    instruction += f" (source: preference for agent {style_scope})"

            config["system_prompt"] = instruction.strip() + "\n\n" + prompt

        # --- Apply model preference ---
        model = preferences.get("preferred_model")
        model_conf = preferences.get("model_confidence", 0.0)

        if model and model_conf >= min_confidence:
            config["model_name"] = model

        # --- Store preferences in config for downstream use ---
        config["native_user_preferences"] = dict(preferences)

        return config
