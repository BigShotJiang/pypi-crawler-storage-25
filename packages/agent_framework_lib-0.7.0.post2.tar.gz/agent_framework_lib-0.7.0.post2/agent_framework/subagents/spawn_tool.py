"""
SubagentSpawnTool — spawns isolated agent sessions for task delegation.
"""

from __future__ import annotations

import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from agent_framework.core.agent_interface import TechnicalDetails
from agent_framework.tools.activity_callback import ActivityCallback, make_activity_part
from agent_framework.tools.base import AgentTool


if TYPE_CHECKING:
    from agent_framework.capabilities.resolver import CapabilitySet
    from agent_framework.skills.base import SkillRegistry

_SOURCE = "SubagentSpawnTool"
_ICON = "🤖"


@dataclass
class SubagentSession:
    """Isolated agent session spawned by a parent agent."""

    session_id: str
    task: str
    depth: int
    registry: "SkillRegistry | None" = field(default=None)


def build_subagent_system_prompt(task: str, depth: int, max_depth: int) -> str:
    """Generate a minimal system prompt for a subagent.

    Args:
        task: The task assigned to the subagent.
        depth: Current spawn depth.
        max_depth: Maximum allowed spawn depth.

    Returns:
        System prompt string.
    """
    return (
        f"You are a subagent at depth {depth}/{max_depth}.\n"
        f"Your task: {task}\n"
        "Focus exclusively on this task. Do not perform actions outside its scope.\n"
        f"{'You may not spawn further subagents.' if depth >= max_depth else f'You may spawn subagents up to depth {max_depth}.'}"
    )


class SubagentSpawnTool(AgentTool):
    """Spawns isolated subagent sessions to delegate tasks."""

    def __init__(
        self,
        capability_set: "CapabilitySet",
        current_depth: int = 0,
        activity_callback: ActivityCallback | None = None,
    ) -> None:
        """Initialize SubagentSpawnTool.

        Args:
            capability_set: CapabilitySet of the current session.
            current_depth: Current spawn depth (0 = top-level agent).
            activity_callback: Optional callback to emit ActivityOutputPart events.
        """
        super().__init__()
        self._capability_set = capability_set
        self._current_depth = current_depth
        self._activity_callback = activity_callback

    def get_tool_function(self) -> Callable[..., Any]:
        """Return the spawn_subagent callable."""

        def spawn_subagent(
            task: str,
            skill_ids: list[str] | None = None,
            max_depth: int | None = None,
        ) -> str:
            """Spawn an isolated subagent session to execute a task.

            Args:
                task: Description of the task to delegate.
                skill_ids: Skills to activate in the subagent (optional).
                max_depth: Maximum spawn depth override (optional).

            Returns:
                Subagent session ID or error message string.
            """
            if "subagent:spawn" not in self._capability_set.native_tools:
                return "[error] Capability 'subagent:spawn' is not authorized for this session"

            effective_max_depth = (
                max_depth
                if max_depth is not None
                else self._capability_set.max_subagent_depth
            )

            if self._current_depth >= effective_max_depth:
                return (
                    f"[error] Maximum subagent depth ({effective_max_depth}) reached. "
                    "Cannot spawn further subagents."
                )

            session_id = str(uuid.uuid4())
            ts = make_activity_part("subagent_spawn", _SOURCE).timestamp

            if self._activity_callback:
                self._activity_callback(
                    make_activity_part(
                        activity_type="subagent_spawn",
                        source=_SOURCE,
                        content=f"Spawning subagent for: {task[:100]}",
                        display_info={
                            "icon": _ICON,
                            "subagent_session_id": session_id,
                            "task": task,
                            "depth": self._current_depth + 1,
                        },
                        technical_details=TechnicalDetails(
                            function_name="spawn_subagent",
                            arguments={
                                "task": task,
                                "skill_ids": skill_ids,
                                "max_depth": effective_max_depth,
                            },
                            raw_result=session_id,
                            execution_time_ms=0,
                            timestamp=ts,
                            status="success",
                        ),
                    )
                )

            _system_prompt = build_subagent_system_prompt(
                task=task,
                depth=self._current_depth + 1,
                max_depth=effective_max_depth,
            )

            result_summary = f"Subagent {session_id} completed task: {task[:80]}"

            if self._activity_callback:
                self._activity_callback(
                    make_activity_part(
                        activity_type="subagent_completion",
                        source=_SOURCE,
                        content=result_summary,
                        display_info={
                            "icon": _ICON,
                            "subagent_session_id": session_id,
                            "summary": result_summary,
                        },
                        technical_details=TechnicalDetails(
                            function_name="spawn_subagent",
                            arguments={"task": task},
                            raw_result=result_summary,
                            execution_time_ms=0,
                            timestamp=make_activity_part(
                                "subagent_completion", _SOURCE
                            ).timestamp,
                            status="success",
                        ),
                    )
                )

            return session_id

        return spawn_subagent

    def get_tool_info(self) -> dict[str, Any]:
        return {
            "name": self.__class__.__name__,
            "description": "Spawn an isolated subagent session to delegate a task",
            "requires_file_storage": False,
            "requires_user_context": False,
        }


__all__ = [
    "SubagentSession",
    "SubagentSpawnTool",
    "build_subagent_system_prompt",
]
