# Configuration Guide

## Table of Contents

- [Overview](#overview)
- [API Keys](#api-keys)
- [Model Configuration](#model-configuration)
- [Multi-Model Routing](#multi-model-routing)
- [Session Storage](#session-storage)
- [File Storage](#file-storage)
- [S3 Presigned URLs](#s3-presigned-urls)
- [GCP Cloud Storage](#gcp-cloud-storage)
- [File Routing](#file-routing)
- [Authentication](#authentication)
- [Elasticsearch Integration](#elasticsearch-integration)
- [Elasticsearch Advanced](#elasticsearch-advanced)
- [Metrics & Observability](#metrics--observability)
- [OpenTelemetry](#opentelemetry)
- [Monitoring](#monitoring)
- [Content Processing](#content-processing)
- [A2A (Agent-to-Agent)](#a2a-agent-to-agent)
- [Memory (Memori + Graphiti)](#memory-memori--graphiti)
- [Helper Agent](#helper-agent)
- [Session Titles](#session-titles)
- [Advanced Options](#advanced-options)
- [Deployment Scenarios](#deployment-scenarios)
- [Environment Variables Reference](#environment-variables-reference)

## Overview

The Agent Framework is configured through environment variables, typically set in a `.env` file. Copy `.env.example` to `.env` and configure the values for your deployment.

### Configuration Priority

1. Environment variables (highest priority)
2. `.env` file
3. Default values (lowest priority)

### Quick Start

Minimal configuration for development:

```bash
# .env
OPENAI_API_KEY=sk-your-key-here
DEFAULT_MODEL=gpt-5.4-mini
SESSION_STORAGE_TYPE=memory
REQUIRE_AUTH=false
```

## API Keys

### OPENAI_API_KEY

- **Type**: string
- **Required**: Conditional (required if using OpenAI models)
- **Default**: None
- **Description**: API key for OpenAI services. Get your key from https://platform.openai.com/api-keys

**Example:**
```bash
OPENAI_API_KEY=sk-proj-abc123...
```

### ANTHROPIC_API_KEY

- **Type**: string
- **Required**: Conditional (required if using Anthropic models)
- **Default**: None
- **Description**: API key for Anthropic Claude models. Get your key from https://console.anthropic.com/

**Example:**
```bash
ANTHROPIC_API_KEY=sk-ant-api03-abc123...
```

### GEMINI_API_KEY

- **Type**: string
- **Required**: Conditional (required if using Google Gemini models)
- **Default**: None
- **Description**: API key for Google Gemini models. Get your key from https://makersuite.google.com/app/apikey

**Example:**
```bash
GEMINI_API_KEY=AIzaSyAbc123...
```

## Model Configuration

### DEFAULT_MODEL

- **Type**: string
- **Required**: No
- **Default**: `gpt-5.4-mini`
- **Description**: Default model to use when no model is specified in agent configuration. The framework automatically detects the provider from the model name.

**Supported Models:**

**OpenAI:**
- `gpt-5.2` - GPT-5.2 (latest flagship)
- `gpt-5` - GPT-5
- `gpt-5.4-mini` - Smaller, fast
- `gpt-5.4-nano` - Ultra-lightweight, cost-efficient
- `o1` - O1

**Anthropic (Claude 4 Family - Latest):**
- `claude-opus-4-6` - Claude Opus 4.6 (most powerful, adaptive thinking, 1M context beta, released February 2026)
- `claude-opus-4-5-20251101` - Claude Opus 4.5
- `claude-opus-4-1-20250514` - Claude Opus 4.1 (incremental update to Opus 4)
- `claude-sonnet-4-6` - Claude Sonnet 4.6 (latest Sonnet, balanced performance)
- `claude-haiku-4-5-20251001` - Claude Haiku 4.5 (fastest, most cost-efficient)

**Anthropic (Claude 3 Family - Previous Generation):**
- `claude-3-7-sonnet-20250219` - Claude 3.7 Sonnet
- `claude-3-5-sonnet-20241022` - Claude 3.5 Sonnet
- `claude-3-5-haiku-20241022` - Claude 3.5 Haiku

**Google Gemini (Gemini 3 Family - Latest):**
- `gemini-3-pro-preview` - Gemini 3 Pro (most intelligent, state-of-the-art reasoning)
- `gemini-3-deep-think` - Gemini 3 Deep Think (advanced reasoning mode)

**Google Gemini (Gemini 2.5 Family):**
- `gemini-2.5-pro` - Gemini 2.5 Pro (powerful with adaptive thinking)
- `gemini-2.5-flash` - Gemini 2.5 Flash (fast, well-rounded capabilities)
- `gemini-2.5-flash-lite` - Gemini 2.5 Flash-Lite (optimized for cost-efficiency)

**Google Gemini (Gemini 2.0 Family):**
- `gemini-2.0-flash` - Gemini 2.0 Flash (1M token context window)
- `gemini-2.0-flash-thinking` - Gemini 2.0 Flash Thinking (shows reasoning process)

**Example:**
```bash
DEFAULT_MODEL=gpt-5.4-mini
# or
DEFAULT_MODEL=claude-sonnet-4-6
# or
DEFAULT_MODEL=gemini-3-pro-preview
```

### FALLBACK_PROVIDER

- **Type**: string (enum: `openai`, `anthropic`, `gemini`)
- **Required**: No
- **Default**: `openai`
- **Description**: Provider to use when the model name doesn't clearly indicate a provider. Used as a fallback when automatic detection fails.

**Example:**
```bash
FALLBACK_PROVIDER=openai
```

### Provider-Specific Settings

#### OpenAI Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `OPENAI_DEFAULT_TEMPERATURE` | float (0.0-2.0) | `0.7` | Default temperature for OpenAI models |
| `OPENAI_DEFAULT_TIMEOUT` | integer (seconds) | `120` | Timeout for OpenAI API requests |
| `OPENAI_DEFAULT_MAX_RETRIES` | integer | `3` | Maximum retry attempts for failed requests |
| `OPENAI_API_MODEL` | string | Value of `DEFAULT_MODEL` | Override model for OpenAI requests |
| `OPENAI_MODELS` | string (comma-separated) | Internal default list | Override the list of known OpenAI models |

**Example:**
```bash
OPENAI_DEFAULT_TEMPERATURE=0.7
OPENAI_DEFAULT_TIMEOUT=120
OPENAI_DEFAULT_MAX_RETRIES=3
OPENAI_MODELS=gpt-5,gpt-5.4-mini,o1
```

#### Anthropic Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `ANTHROPIC_DEFAULT_TEMPERATURE` | float (0.0-1.0) | `0.7` | Default temperature for Anthropic models |
| `ANTHROPIC_DEFAULT_TIMEOUT` | integer (seconds) | `120` | Timeout for Anthropic API requests |
| `ANTHROPIC_DEFAULT_MAX_RETRIES` | integer | `3` | Maximum retry attempts for failed requests |
| `ANTHROPIC_DEFAULT_MAX_TOKENS` | integer | `32768` | Maximum output tokens for Anthropic models |
| `ANTHROPIC_MODELS` | string (comma-separated) | Internal default list | Override the list of known Anthropic models |

**Example:**
```bash
ANTHROPIC_DEFAULT_TEMPERATURE=0.7
ANTHROPIC_DEFAULT_TIMEOUT=120
ANTHROPIC_DEFAULT_MAX_RETRIES=3
ANTHROPIC_DEFAULT_MAX_TOKENS=32768
ANTHROPIC_MODELS=claude-sonnet-4-6,claude-opus-4-6
```

#### Gemini Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `GEMINI_DEFAULT_TEMPERATURE` | float (0.0-2.0) | `0.7` | Default temperature for Gemini models |
| `GEMINI_DEFAULT_TIMEOUT` | integer (seconds) | `120` | Timeout for Gemini API requests |
| `GEMINI_DEFAULT_MAX_RETRIES` | integer | `3` | Maximum retry attempts for failed requests |
| `GEMINI_MODELS` | string (comma-separated) | Internal default list | Override the list of known Gemini models |

**Example:**
```bash
GEMINI_DEFAULT_TEMPERATURE=0.7
GEMINI_DEFAULT_TIMEOUT=120
GEMINI_DEFAULT_MAX_RETRIES=3
GEMINI_MODELS=gemini-3-pro-preview,gemini-2.5-flash
```

### Model Selection Behavior

The framework uses the following logic to select a model:

1. **Agent Configuration**: If the agent specifies a model in its configuration, use that model
2. **Session Configuration**: If the session was initialized with a model, use that model
3. **DEFAULT_MODEL**: Use the default model from environment variables
4. **Provider Detection**: Automatically detect provider from model name:
   - Models starting with `gpt-` or `o1` → OpenAI
   - Models starting with `claude-` → Anthropic
   - Models starting with `gemini-` → Google Gemini
5. **Fallback**: If provider cannot be determined, use `FALLBACK_PROVIDER`

### Runtime Model Switching

Models can be changed at runtime through:

1. **Session Initialization**: Specify model in session configuration
2. **Agent Configuration API**: Update agent configuration via `/config/agents/{agent_id}`
3. **Elasticsearch Configuration**: Store and version agent configurations

## Multi-Model Routing

The framework includes an intelligent model router that automatically selects the appropriate model tier based on query complexity.

### DEFAULT_MODEL_MODE

- **Type**: string (enum: `auto`, `light`, `standard`, `advanced`)
- **Required**: No
- **Default**: `auto`
- **Description**: Default routing mode. In `auto` mode, the router classifies query complexity and selects the appropriate tier. Other modes force a specific tier.

**Example:**
```bash
DEFAULT_MODEL_MODE=auto
```

### AUTO_CLASSIFIER_MODEL

- **Type**: string
- **Required**: No
- **Default**: `gpt-4o-mini`
- **Description**: Model used to classify query complexity when `DEFAULT_MODEL_MODE=auto`. Should be a fast, inexpensive model.

**Example:**
```bash
AUTO_CLASSIFIER_MODEL=gpt-4o-mini
```

### Tier Preferences

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `PREFERRED_LIGHT_MODELS` | string (comma-separated) | Internal default list | Models for simple queries (greetings, basic Q&A) |
| `PREFERRED_STANDARD_MODELS` | string (comma-separated) | Internal default list | Models for moderate complexity queries |
| `PREFERRED_ADVANCED_MODELS` | string (comma-separated) | Internal default list | Models for complex reasoning, coding, analysis |

**Example:**
```bash
PREFERRED_LIGHT_MODELS=gpt-5.4-mini,gemini-2.5-flash-lite
PREFERRED_STANDARD_MODELS=claude-sonnet-4-20250522,gemini-2.5-flash
PREFERRED_ADVANCED_MODELS=claude-opus-4-6,gemini-3-pro-preview,gpt-5
```

## Session Storage

### SESSION_STORAGE_TYPE

- **Type**: string (enum: `memory`, `mongodb`, `elasticsearch`)
- **Required**: No
- **Default**: `memory`
- **Description**: Backend for session persistence.

**Options:**
- `memory`: In-memory storage (development only, data lost on restart)
- `mongodb`: MongoDB persistent storage (recommended for production)
- `elasticsearch`: Elasticsearch storage (advanced features, observability)

**Example:**
```bash
SESSION_STORAGE_TYPE=mongodb
```

### MongoDB Configuration

Used when `SESSION_STORAGE_TYPE=mongodb`.

#### MONGODB_CONNECTION_STRING

- **Type**: string (MongoDB connection URI)
- **Required**: Yes (when using MongoDB)
- **Default**: `mongodb://localhost:27017`
- **Description**: MongoDB connection string.

**Examples:**
```bash
# Local MongoDB
MONGODB_CONNECTION_STRING=mongodb://localhost:27017

# MongoDB with authentication
MONGODB_CONNECTION_STRING=mongodb://username:password@localhost:27017

# MongoDB Atlas
MONGODB_CONNECTION_STRING=mongodb+srv://username:password@cluster.mongodb.net/database
```

#### MONGODB_DATABASE_NAME

- **Type**: string
- **Required**: No
- **Default**: `agent_sessions_db`
- **Description**: Database name for session storage.

**Example:**
```bash
MONGODB_DATABASE_NAME=agent_sessions_db
```

### Elasticsearch Session Configuration

Used when `SESSION_STORAGE_TYPE=elasticsearch`.

#### ELASTICSEARCH_ENABLED

- **Type**: boolean
- **Required**: No
- **Default**: `false`
- **Description**: Enable Elasticsearch integration for advanced features.

**Example:**
```bash
ELASTICSEARCH_ENABLED=true
```

#### ELASTICSEARCH_URL

- **Type**: string (URL)
- **Required**: Yes (when Elasticsearch enabled)
- **Default**: `http://localhost:9200`
- **Description**: Elasticsearch cluster URL.

**Examples:**
```bash
# Local Elasticsearch
ELASTICSEARCH_URL=http://localhost:9200

# Elasticsearch Cloud
ELASTICSEARCH_URL=https://my-deployment.es.us-central1.gcp.cloud.es.io:9243
```

#### ELASTICSEARCH_USERNAME

- **Type**: string
- **Required**: Conditional (required for authenticated Elasticsearch)
- **Default**: None
- **Description**: Username for Elasticsearch authentication.

#### ELASTICSEARCH_PASSWORD

- **Type**: string
- **Required**: Conditional (required for authenticated Elasticsearch)
- **Default**: None
- **Description**: Password for Elasticsearch authentication.

#### ELASTICSEARCH_API_KEY

- **Type**: string
- **Required**: Conditional (alternative to username/password)
- **Default**: None
- **Description**: API key for Elasticsearch authentication.

#### ELASTICSEARCH_VERIFY_CERTS

- **Type**: boolean
- **Required**: No
- **Default**: `true`
- **Description**: Verify SSL certificates for Elasticsearch connections.

#### ELASTICSEARCH_CA_CERTS

- **Type**: string (file path)
- **Required**: No
- **Default**: None
- **Description**: Path to CA certificate file for SSL verification.

## File Storage

### LOCAL_STORAGE_PATH

- **Type**: string (directory path)
- **Required**: No
- **Default**: `./file_storage`
- **Description**: Directory path for local file storage.

**Example:**
```bash
LOCAL_STORAGE_PATH=./file_storage
```

### S3 Configuration

#### AWS_S3_BUCKET

- **Type**: string
- **Required**: Conditional (required for S3 storage)
- **Default**: None
- **Description**: S3 bucket name for file storage.

#### AWS_REGION

- **Type**: string
- **Required**: Conditional (required for S3 storage)
- **Default**: `us-east-1`
- **Description**: AWS region for S3 bucket.

#### AWS_ACCESS_KEY_ID

- **Type**: string
- **Required**: Conditional (required for S3 with explicit credentials)
- **Default**: None (uses AWS credential chain)
- **Description**: AWS access key ID. If not provided, uses default AWS credential chain (consumed by `boto3`, not read directly by the framework).

#### AWS_SECRET_ACCESS_KEY

- **Type**: string
- **Required**: Conditional (required for S3 with explicit credentials)
- **Default**: None (uses AWS credential chain)
- **Description**: AWS secret access key (consumed by `boto3`, not read directly by the framework).

#### S3_AS_DEFAULT

- **Type**: boolean
- **Required**: No
- **Default**: `false`
- **Description**: Use S3 as the default file storage backend instead of local storage.

#### S3_FILE_PREFIX

- **Type**: string
- **Required**: No
- **Default**: `agent-files/`
- **Description**: Key prefix for all files stored in S3.

**Example:**
```bash
AWS_S3_BUCKET=my-agent-files
AWS_REGION=us-east-1
S3_AS_DEFAULT=true
S3_FILE_PREFIX=agent-files/
```

### MinIO Configuration

#### MINIO_ENDPOINT

- **Type**: string (URL)
- **Required**: Conditional (required for MinIO storage)
- **Default**: None
- **Description**: MinIO server endpoint.

#### MINIO_ACCESS_KEY

- **Type**: string
- **Required**: Conditional (required for MinIO storage)
- **Default**: None
- **Description**: MinIO access key.

#### MINIO_SECRET_KEY

- **Type**: string
- **Required**: Conditional (required for MinIO storage)
- **Default**: None
- **Description**: MinIO secret key.

#### MINIO_BUCKET

- **Type**: string
- **Required**: Conditional (required for MinIO storage)
- **Default**: `agent-files`
- **Description**: MinIO bucket name for file storage.

#### MINIO_SECURE

- **Type**: boolean
- **Required**: No
- **Default**: `true`
- **Description**: Use HTTPS for MinIO connections.

#### MINIO_FILE_PREFIX

- **Type**: string
- **Required**: No
- **Default**: `agent-files/`
- **Description**: Key prefix for all files stored in MinIO.

#### MINIO_AS_DEFAULT

- **Type**: boolean
- **Required**: No
- **Default**: `false`
- **Description**: Use MinIO as the default file storage backend.

**Example:**
```bash
MINIO_ENDPOINT=localhost:9000
MINIO_ACCESS_KEY=minioadmin
MINIO_SECRET_KEY=minioadmin
MINIO_BUCKET=agent-files
MINIO_SECURE=true
MINIO_AS_DEFAULT=false
```

## S3 Presigned URLs

The framework supports three URL modes for S3/MinIO file access. These settings apply to both S3 and MinIO backends.

### S3_URL_MODE

- **Type**: string (enum: `api`, `presigned`, `public`)
- **Required**: No
- **Default**: `api`
- **Description**: URL generation mode for file downloads and views.
  - `api`: Returns API-proxied URLs (`/files/{file_id}/download`). Files are served through the framework's API.
  - `presigned`: Returns temporary presigned S3/MinIO URLs with direct access.
  - `public`: Returns public S3/MinIO URLs (requires public bucket configuration).

### S3_MAX_PRESIGNED_URL_EXPIRATION

- **Type**: integer (seconds)
- **Required**: No
- **Default**: `86400` (24 hours)
- **Description**: Maximum allowed expiration time for presigned URLs. Requests for longer expirations are capped to this value.

### S3_DEFAULT_PRESIGNED_URL_EXPIRATION

- **Type**: integer (seconds)
- **Required**: No
- **Default**: `3600` (1 hour)
- **Description**: Default expiration time for presigned URLs when no specific expiration is requested.

### API_BASE_URL

- **Type**: string
- **Required**: No
- **Default**: `""` (relative URLs)
- **Description**: Base URL for API mode URLs (e.g., `https://agent.example.com`). When empty, relative URLs are generated.

**Example:**
```bash
S3_URL_MODE=presigned
S3_MAX_PRESIGNED_URL_EXPIRATION=86400
S3_DEFAULT_PRESIGNED_URL_EXPIRATION=3600
API_BASE_URL=https://agent.example.com
```

## GCP Cloud Storage

### GCP_STORAGE_BUCKET

- **Type**: string
- **Required**: Conditional (required for GCP storage)
- **Default**: None
- **Description**: GCP Cloud Storage bucket name.

### GCP_PROJECT_ID

- **Type**: string
- **Required**: No
- **Default**: None
- **Description**: GCP project ID. If not provided, uses the default project from credentials.

### GCP_FILE_PREFIX

- **Type**: string
- **Required**: No
- **Default**: `agent-files/`
- **Description**: Key prefix for all files stored in GCP.

### GCP_AS_DEFAULT

- **Type**: boolean
- **Required**: No
- **Default**: `false`
- **Description**: Use GCP as the default file storage backend.

### GOOGLE_APPLICATION_CREDENTIALS

- **Type**: string (file path)
- **Required**: Conditional (required for GCP with explicit credentials)
- **Default**: None
- **Description**: Path to GCP service account JSON key file.

**Example:**
```bash
GCP_STORAGE_BUCKET=my-agent-bucket
GCP_PROJECT_ID=my-gcp-project
GCP_FILE_PREFIX=agent-files/
GCP_AS_DEFAULT=true
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
```

## File Routing

The framework routes files to different storage backends based on MIME type. Each variable accepts a backend name (`local`, `s3`, `minio`, `gcp`).

### User Upload Routing

| Variable | Default | Description |
|----------|---------|-------------|
| `IMAGE_STORAGE_BACKEND` | effective default | Backend for uploaded images (`image/*`) |
| `VIDEO_STORAGE_BACKEND` | effective default | Backend for uploaded videos (`video/*`) |
| `PDF_STORAGE_BACKEND` | effective default | Backend for uploaded PDFs (`application/pdf`) |
| `TEXT_STORAGE_BACKEND` | effective default | Backend for uploaded text files (`text/*`) |

### AI-Generated Content Routing

| Variable | Default | Description |
|----------|---------|-------------|
| `AI_TEXT_STORAGE_BACKEND` | effective default | Backend for AI-generated text |
| `AI_HTML_STORAGE_BACKEND` | effective default | Backend for AI-generated HTML |
| `AI_CHART_STORAGE_BACKEND` | `s3` if available | Backend for AI-generated charts |
| `AI_CODE_STORAGE_BACKEND` | effective default | Backend for AI-generated code |
| `AI_DATA_STORAGE_BACKEND` | effective default | Backend for AI-generated data |
| `AI_IMAGE_STORAGE_BACKEND` | `s3` if available | Backend for AI-generated images |
| `AI_MARKDOWN_STORAGE_BACKEND` | effective default | Backend for AI-generated Markdown |
| `AI_JSON_STORAGE_BACKEND` | effective default | Backend for AI-generated JSON |
| `AI_CSV_STORAGE_BACKEND` | effective default | Backend for AI-generated CSV |
| `AI_YAML_STORAGE_BACKEND` | effective default | Backend for AI-generated YAML |
| `AI_XML_STORAGE_BACKEND` | effective default | Backend for AI-generated XML |
| `AI_CONTENT_STORAGE_BACKEND` | effective default | Fallback backend for any AI-generated content type not explicitly configured |

> The "effective default" is determined by: `s3` if `S3_AS_DEFAULT=true`, `minio` if `MINIO_AS_DEFAULT=true`, otherwise `local`.

### FILE_ROUTING_RULES

- **Type**: string (comma-separated rules)
- **Required**: No
- **Default**: None
- **Description**: Custom routing rules in format `mime_prefix:backend`. Overrides default routing.

**Example:**
```bash
FILE_ROUTING_RULES=image/:s3,video/:minio,application/pdf:local,ai-generated/chart:s3
```

## Authentication

### REQUIRE_AUTH

- **Type**: boolean
- **Required**: No
- **Default**: `false`
- **Description**: Enable authentication for all API endpoints. When `false`, all endpoints are publicly accessible.

### Basic Authentication

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `BASIC_AUTH_USERNAME` | string | `admin` | Username for HTTP Basic Authentication |
| `BASIC_AUTH_PASSWORD` | string | `password` | Password for HTTP Basic Authentication |

### API Key Authentication

#### API_KEYS

- **Type**: string (comma-separated list)
- **Required**: No
- **Default**: Empty
- **Description**: Comma-separated list of valid API keys for Bearer token or X-API-Key header authentication.

**Usage:**
```bash
# Bearer token
curl -H "Authorization: Bearer sk-abc123def456" http://localhost:8000/metadata

# X-API-Key header
curl -H "X-API-Key: sk-abc123def456" http://localhost:8000/metadata
```

### ADMIN_PASSWORD

- **Type**: string
- **Required**: No
- **Default**: `admin123`
- **Description**: Password for admin-only endpoints (secondary authentication layer).

### Authentication Methods

The framework supports three authentication methods (when `REQUIRE_AUTH=true`):

1. **Basic Authentication**: Username and password
2. **Bearer Token**: API key in Authorization header
3. **X-API-Key Header**: API key in custom header

## Elasticsearch Integration

Elasticsearch provides advanced features for the Agent Framework:

1. **Session Storage**: Persistent session storage with search capabilities
2. **Configuration Management**: Store and version agent configurations
3. **Observability**: Log agent interactions and performance metrics
4. **Circuit Breaker**: Automatic failover when Elasticsearch is unavailable

### Core Configuration

See [Elasticsearch Session Configuration](#elasticsearch-session-configuration) above for `ELASTICSEARCH_ENABLED`, `ELASTICSEARCH_URL`, `ELASTICSEARCH_USERNAME`, `ELASTICSEARCH_PASSWORD`, `ELASTICSEARCH_API_KEY`, `ELASTICSEARCH_VERIFY_CERTS`, and `ELASTICSEARCH_CA_CERTS`.

## Elasticsearch Advanced

### Connection Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `ELASTICSEARCH_TIMEOUT` | integer (seconds) | `30` | Request timeout for Elasticsearch operations |
| `ELASTICSEARCH_MAX_RETRIES` | integer | `3` | Maximum retry attempts for failed requests |
| `ELASTICSEARCH_RETRY_ON_TIMEOUT` | boolean | `true` | Retry requests that time out |

### Index Configuration

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `ELASTICSEARCH_SESSION_INDEX_PREFIX` | string | `agent-sessions` | Prefix for session storage indices |
| `ELASTICSEARCH_CONFIG_INDEX` | string | `agent-configs` | Index for agent configuration storage |
| `ELASTICSEARCH_ADMIN_CONFIG_INDEX` | string | `agent-admin-config` | Index for admin configuration storage |
| `ELASTICSEARCH_FILES_INDEX` | string | `agent-files-metadata` | Index for file metadata storage |

### Configuration Cache

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `ELASTICSEARCH_CONFIG_CACHE_TTL` | integer (seconds) | `300` | Time-to-live for cached configurations |
| `ELASTICSEARCH_CONFIG_CACHE_MAX_SIZE` | integer | `100` | Maximum number of cached configurations |

### Logging

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `ELASTICSEARCH_LOG_INDEX_PATTERN` | string | `agent-logs-{date}` | Index pattern for application logs |
| `ELASTICSEARCH_LOG_BATCH_SIZE` | integer | `100` | Number of log entries to batch before sending |
| `ELASTICSEARCH_LOG_FLUSH_INTERVAL` | float (seconds) | `5.0` | Seconds between automatic log flushes |
| `ELASTICSEARCH_FALLBACK_TO_FILE` | boolean | `true` | Fall back to file logging when ES is unavailable |
| `ELASTICSEARCH_FALLBACK_LOG_FILE` | string | `logs/elasticsearch_fallback.log` | File path for fallback logging |

### Circuit Breaker

The circuit breaker protects the application when Elasticsearch is unavailable.

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `ELASTICSEARCH_CIRCUIT_BREAKER_THRESHOLD` | integer | `5` | Consecutive failures before opening the circuit |
| `ELASTICSEARCH_CIRCUIT_BREAKER_TIMEOUT` | integer (seconds) | `30` | Base recovery timeout before retrying |
| `ELASTICSEARCH_CIRCUIT_BREAKER_MAX_TIMEOUT` | integer (seconds) | `300` | Maximum recovery timeout (exponential backoff cap) |
| `ELASTICSEARCH_CIRCUIT_BREAKER_HEALTH_CHECK_INTERVAL` | integer (seconds) | `15` | Interval between health checks in half-open state |

**Example:**
```bash
ELASTICSEARCH_TIMEOUT=30
ELASTICSEARCH_MAX_RETRIES=3
ELASTICSEARCH_SESSION_INDEX_PREFIX=agent-sessions
ELASTICSEARCH_CONFIG_INDEX=agent-configs
ELASTICSEARCH_CIRCUIT_BREAKER_THRESHOLD=5
ELASTICSEARCH_CIRCUIT_BREAKER_TIMEOUT=30
```

## Metrics & Observability

The framework provides comprehensive metrics collection for LLM calls and API requests.

### Unified Metrics Configuration

#### METRICS_ENABLED

- **Type**: boolean
- **Required**: No
- **Default**: `true`
- **Description**: Master switch for all metrics collection (LLM metrics and API timing).

#### METRICS_ES_LOGGING_ENABLED

- **Type**: boolean
- **Required**: No
- **Default**: `false`
- **Description**: Enable direct Elasticsearch logging for Kibana dashboards. When enabled, metrics are logged to both OTel (for Prometheus/Grafana) and Elasticsearch indices (for Kibana).

**Indices created:**
- `{prefix}-{date}` - Unified metrics (API timing, LLM metrics, span timings)

#### METRICS_INDEX_PREFIX

- **Type**: string
- **Required**: No
- **Default**: `agent-metrics`
- **Description**: Base prefix for all metrics Elasticsearch indices. Creates indices like `{prefix}-{date}`.

#### METRICS_BATCH_SIZE

- **Type**: integer
- **Required**: No
- **Default**: `50`
- **Description**: Number of metrics to batch before sending to Elasticsearch.

#### METRICS_FLUSH_INTERVAL

- **Type**: float (seconds)
- **Required**: No
- **Default**: `5.0`
- **Description**: Seconds between automatic flushes of metrics buffer to Elasticsearch.

#### UNIFIED_METRICS_ENABLED

- **Type**: boolean
- **Required**: No
- **Default**: `true`
- **Description**: Enable the unified metrics aggregator that consolidates all metric types into a single index.

#### METRICS_MAX_BUFFER_SIZE

- **Type**: integer
- **Required**: No
- **Default**: `1000`
- **Description**: Maximum buffer size for metrics (circular buffer). When the buffer is full, oldest metrics are dropped.

**Example:**
```bash
METRICS_ENABLED=true
METRICS_ES_LOGGING_ENABLED=true
METRICS_INDEX_PREFIX=agent-metrics
METRICS_BATCH_SIZE=50
METRICS_FLUSH_INTERVAL=5.0
UNIFIED_METRICS_ENABLED=true
METRICS_MAX_BUFFER_SIZE=1000
```

### LLM Metrics Collected

- **Token counts**: input_tokens, output_tokens, thinking_tokens, total_tokens
- **Timing**: duration_ms, time_to_first_token_ms, tokens_per_second
- **Context**: model_name, session_id, agent_id, api_request_id
- **Tool calls**: tool_call_count, tool_call_duration_ms

### API Timing Metrics Collected

- **Total timing**: total_api_duration_ms, time_to_first_chunk_ms
- **Phase breakdown**: preprocessing_duration_ms, llm_duration_ms, postprocessing_duration_ms
- **Analysis**: llm_percentage (% of time in LLM), overhead_ms
- **Context**: endpoint, method, session_id, user_id, is_streaming

## OpenTelemetry

The framework integrates with OpenTelemetry for distributed tracing, metrics export, and log forwarding.

### OTEL_ENABLED

- **Type**: boolean
- **Required**: No
- **Default**: `true`
- **Description**: Enable OpenTelemetry instrumentation. When enabled, traces, metrics, and logs are exported via OTLP.

### OTEL_SERVICE_NAME

- **Type**: string
- **Required**: No
- **Default**: `agent_framework`
- **Description**: Service name reported in OTel traces and metrics.

### OTEL_SERVICE_VERSION

- **Type**: string
- **Required**: No
- **Default**: `1.0.0`
- **Description**: Service version reported in OTel resource attributes.

### OTEL_ENVIRONMENT

- **Type**: string
- **Required**: No
- **Default**: `development`
- **Description**: Environment name (e.g., `development`, `staging`, `production`).

### OTEL_EXPORTER_OTLP_ENDPOINT

- **Type**: string (URL)
- **Required**: No
- **Default**: None
- **Description**: OTLP collector endpoint URL (e.g., `http://otel-collector:4317` for gRPC, `http://otel-collector:4318` for HTTP).

### OTEL_EXPORTER_OTLP_PROTOCOL

- **Type**: string (enum: `grpc`, `http`)
- **Required**: No
- **Default**: `grpc`
- **Description**: Protocol for OTLP export.

### OTEL_METRICS_EXPORTER

- **Type**: string (enum: `otlp`, `prometheus`, `none`)
- **Required**: No
- **Default**: `otlp`
- **Description**: Metrics exporter type.

### OTEL_LOGS_EXPORTER

- **Type**: string (enum: `otlp`, `none`)
- **Required**: No
- **Default**: `otlp`
- **Description**: Logs exporter type.

**Example:**
```bash
OTEL_ENABLED=true
OTEL_SERVICE_NAME=my-agent
OTEL_SERVICE_VERSION=1.0.0
OTEL_ENVIRONMENT=production
OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317
OTEL_EXPORTER_OTLP_PROTOCOL=grpc
OTEL_METRICS_EXPORTER=otlp
OTEL_LOGS_EXPORTER=otlp
```

## Monitoring

Additional monitoring switches for fine-grained control over observability features.

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `RESOURCE_METRICS_ENABLED` | boolean | `true` | Collect CPU and memory metrics via psutil |
| `API_TIMING_ENABLED` | boolean | `true` | Enable API request timing middleware |
| `LLM_AUTO_INSTRUMENTATION_ENABLED` | boolean | None (auto-detected) | Enable LLM auto-instrumentation via Traceloop. When not set, enabled automatically if the `traceloop-sdk` package is installed |
| `ENABLE_LLM_METRICS` | boolean | `true` | Enable LLM call metrics collection in LlamaIndex agents |

**Example:**
```bash
RESOURCE_METRICS_ENABLED=true
API_TIMING_ENABLED=true
ENABLE_LLM_METRICS=true
```

## Content Processing

The framework includes content processing pipelines for rich content validation and Markdown conversion.

### Rich Content Validation

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `RICH_CONTENT_VALIDATION_ENABLED` | boolean | `true` | Master switch for rich content validation (Mermaid, charts, tables) |
| `MERMAID_VALIDATION_ENABLED` | boolean | `true` | Enable Mermaid diagram syntax validation |
| `CHART_VALIDATION_ENABLED` | boolean | `true` | Enable Chart.js content validation |
| `TABLE_VALIDATION_ENABLED` | boolean | `true` | Enable table content validation |
| `RICH_CONTENT_AUTO_REPAIR` | boolean | `true` | Automatically attempt to repair invalid rich content |

### Markdown Conversion

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `MAX_MARKDOWN_FILE_SIZE_MB` | integer (MB) | `50` | Maximum file size for Markdown conversion |
| `MARKDOWN_CONVERSION_TIMEOUT_SECONDS` | integer (seconds) | `300` | Timeout for Markdown conversion operations |
| `ENABLE_PARTIAL_CONVERSION` | boolean | `true` | Allow partial conversion when full conversion fails |

**Example:**
```bash
RICH_CONTENT_VALIDATION_ENABLED=true
MERMAID_VALIDATION_ENABLED=true
CHART_VALIDATION_ENABLED=true
TABLE_VALIDATION_ENABLED=true
RICH_CONTENT_AUTO_REPAIR=true
MAX_MARKDOWN_FILE_SIZE_MB=50
MARKDOWN_CONVERSION_TIMEOUT_SECONDS=300
```

## A2A (Agent-to-Agent)

The A2A module enables inter-agent communication via the JSON-RPC protocol. See [A2A Guide](./A2A_GUIDE.md) for full documentation.

### A2A_ENABLED

- **Type**: boolean
- **Required**: No
- **Default**: `false`
- **Description**: Enable A2A endpoints (`/a2a`). When disabled, A2A routes return 404.

### A2A_PUBLIC_URL

- **Type**: string (URL)
- **Required**: No
- **Default**: None
- **Description**: Public URL for the agent's A2A endpoint, used in the Agent Card. If not set, the Agent Card uses the server's detected URL.

### A2A Task Store Provider

The A2A module requires a task store to persist task state. The provider is **auto-detected** at startup in the following order:

1. **Elasticsearch** — used if `ELASTICSEARCH_ENABLED=true` and the `elasticsearch` extra is installed.
2. **PostgreSQL** — used if the `asyncpg` package is installed (via the `postgresql` extra). The `PostgresTaskProvider` receives its connection string programmatically (no dedicated env var).

If neither provider is available, A2A endpoints are disabled even when `A2A_ENABLED=true`.

> There is no `A2A_TASK_STORE_PROVIDER` env var — provider selection is automatic based on available dependencies and configuration.

**Example:**
```bash
A2A_ENABLED=true
A2A_PUBLIC_URL=https://my-agent.example.com

# Task store uses Elasticsearch when ES is enabled:
ELASTICSEARCH_ENABLED=true
ELASTICSEARCH_URL=http://localhost:9200

# Or falls back to PostgreSQL if asyncpg is installed
```

## Memory (Memori + Graphiti)

The framework supports two memory providers that can be used individually or in a hybrid configuration.

### Provider Selection

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `MEMORY_PRIMARY_PROVIDER` | string (`memori`, `graphiti`, `none`) | `none` | Primary memory provider |
| `MEMORY_SECONDARY_PROVIDER` | string (`memori`, `graphiti`) or None | None | Optional secondary provider for hybrid memory |

### Behavior Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `MEMORY_AUTO_STORE` | boolean | `true` | Automatically store all interactions for fact extraction |
| `MEMORY_MAX_CONTEXT_FACTS` | integer | `20` | Maximum facts to inject into prompt context |

### Passive Injection

Passive injection automatically retrieves relevant memory context before each message.

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `MEMORY_PASSIVE_INJECTION` | boolean | `true` | Enable automatic context injection |
| `MEMORY_PASSIVE_MAX_FACTS` | integer | `10` | Maximum facts to inject in passive mode |
| `MEMORY_PASSIVE_MIN_CONFIDENCE` | float | `0.5` | Minimum relevance score for passive injection |
| `MEMORY_PASSIVE_PRIMARY_ONLY` | boolean | `true` | Only query primary provider for passive injection (faster) |

### Async Storage

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `MEMORY_ASYNC_STORE` | boolean | `true` | Store interactions asynchronously (fire-and-forget) |
| `MEMORY_ASYNC_MAX_CONCURRENT` | integer | `10` | Maximum concurrent background store operations |
| `MEMORY_ASYNC_TIMEOUT` | float (seconds) | `40.0` | Timeout for pending tasks on shutdown |

### Memori Configuration

Memori provides SQL-native memory storage with automatic fact extraction.

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `MEMORI_DATABASE_URL` | string (SQLAlchemy URL) | `sqlite:///agent_memory.db` | Database URL (sqlite, postgresql, mysql) |
| `MEMORI_API_KEY` | string | None | Optional API key for Memori Advanced Augmentation |

### Graphiti Configuration

Graphiti provides temporal knowledge graph storage. Supports Neo4j or FalkorDB as backend.

#### Graph Database Selection

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `GRAPHITI_USE_FALKORDB` | boolean | `false` | Use FalkorDB instead of Neo4j (lighter weight) |

#### Neo4j Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `NEO4J_URI` | string | `bolt://localhost:7687` | Neo4j connection URI |
| `NEO4J_USER` | string | `neo4j` | Neo4j username |
| `NEO4J_PASSWORD` | string | `password` | Neo4j password |
| `NEO4J_DATABASE` | string | `neo4j` | Neo4j database name |

#### FalkorDB Settings

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `FALKORDB_HOST` | string | `localhost` | FalkorDB host |
| `FALKORDB_PORT` | integer | `6379` | FalkorDB port |
| `FALKORDB_PASSWORD` | string | None | FalkorDB password (optional) |

#### Graphiti LLM & Embedding

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `GRAPHITI_LLM_MODEL` | string | `gpt-4o-mini` | LLM model for graph construction and entity extraction |
| `GRAPHITI_EMBEDDING_MODEL` | string | `text-embedding-3-small` | Embedding model for semantic search |
| `GRAPHITI_EMBEDDING_DIM` | integer | `1536` | Embedding dimension |

#### Graphiti Environment

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `GRAPHITI_ENVIRONMENT` | string | `dev` | Environment prefix for group_id isolation (`dev`, `prod`, `preprod`) |
| `GRAPHITI_SKIP_INDEX_CREATION` | boolean | `false` | Skip index/constraint creation during initialization |

**Example (Memori simple):**
```bash
MEMORY_PRIMARY_PROVIDER=memori
MEMORI_DATABASE_URL=postgresql://localhost/memory
MEMORY_PASSIVE_INJECTION=true
```

**Example (Graphiti with FalkorDB):**
```bash
MEMORY_PRIMARY_PROVIDER=graphiti
GRAPHITI_USE_FALKORDB=true
FALKORDB_HOST=localhost
FALKORDB_PORT=6379
```

**Example (Hybrid):**
```bash
MEMORY_PRIMARY_PROVIDER=memori
MEMORY_SECONDARY_PROVIDER=graphiti
MEMORI_DATABASE_URL=sqlite:///agent_memory.db
GRAPHITI_USE_FALKORDB=true
MEMORY_PASSIVE_INJECTION=true
MEMORY_PASSIVE_PRIMARY_ONLY=true
```

## Helper Agent

The built-in helper agent provides framework documentation assistance.

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `HELPER_AGENT_MODEL` | string | None (auto-detected) | Override the LLM model used by the helper agent |
| `HELPER_AGENT_MEMORY_DB` | string (SQLAlchemy URL) | `sqlite:///helper_agent_memory.db` | Database URL for helper agent memory |
| `HELPER_AGENT_USER_ID` | string | None | Fixed user ID for helper agent operations (overrides per-request user) |

**Example:**
```bash
HELPER_AGENT_MODEL=gpt-5.4-mini
HELPER_AGENT_MEMORY_DB=sqlite:///helper_agent_memory.db
HELPER_AGENT_USER_ID=system
```

## Session Titles

The framework can automatically generate session titles from conversation content.

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `AUTO_GENERATE_SESSION_TITLES` | boolean | `true` | Enable automatic session title generation |
| `SESSION_TITLE_MODEL` | string | `gpt-4o-mini` | LLM model for title generation |
| `SESSION_TITLE_MAX_TOKENS` | integer | `30` | Maximum tokens for generated titles |
| `SESSION_TITLE_TEMPERATURE` | float | `0.3` | Temperature for title generation |

**Example:**
```bash
AUTO_GENERATE_SESSION_TITLES=true
SESSION_TITLE_MODEL=gpt-4o-mini
SESSION_TITLE_MAX_TOKENS=30
SESSION_TITLE_TEMPERATURE=0.3
```

## Advanced Options

### Server Configuration

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `AGENT_PORT` | integer | `8000` | Port for the FastAPI server |
| `AGENT_HOST` | string | `0.0.0.0` | Host address for the FastAPI server |
| `AGENT_RELOAD` | boolean | `true` | Enable auto-reload for development |
| `LOG_LEVEL` | string (`DEBUG`, `INFO`, `WARNING`, `ERROR`, `CRITICAL`) | `INFO` | Logging level |
| `AGENT_TYPE` | string | Agent class name | Identifier for the agent type in sessions and messages |

### Agent Loading

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `AGENT_CLASS_PATH` | string (`module:ClassName`) | None | Python module path and class name for the agent (recommended) |
| `AGENT_MODULE` | string | `agent` | Python module name (fallback when `AGENT_CLASS_PATH` not set) |
| `AGENT_CLASS` | string | `PersonalAssistantAgent` | Class name within the module (fallback when `AGENT_CLASS_PATH` not set) |

### Feature Toggles

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `AGENT_FRAMEWORK_SKIP_AUTO_SETUP` | boolean | `false` | Skip automatic post-install setup (Playwright, Deno) on import |
| `ENABLE_SKILLS` | boolean | `true` | Enable the skills auto-loading system |
| `PERSONALIZATION_ENABLED` | boolean | `true` | Enable user preference personalization via memory |
| `ENABLE_MULTIMODAL_ANALYSIS` | boolean | `false` | Enable multimodal analysis capabilities (image, video) |

**Example:**
```bash
AGENT_PORT=8000
AGENT_HOST=0.0.0.0
AGENT_RELOAD=false
LOG_LEVEL=INFO
AGENT_CLASS_PATH=examples.simple_agent:CalculatorAgent
ENABLE_SKILLS=true
PERSONALIZATION_ENABLED=true
```

## Deployment Scenarios

### Development Setup

Minimal configuration for local development:

```bash
# .env
OPENAI_API_KEY=sk-your-key-here
DEFAULT_MODEL=gpt-5.4-mini
SESSION_STORAGE_TYPE=memory
REQUIRE_AUTH=false
LOG_LEVEL=DEBUG
```

### Production with MongoDB

Recommended configuration for production:

```bash
# .env
# API Keys
OPENAI_API_KEY=sk-your-production-key
ANTHROPIC_API_KEY=sk-ant-your-key
GEMINI_API_KEY=your-gemini-key

# Model Configuration
DEFAULT_MODEL=claude-sonnet-4-6
FALLBACK_PROVIDER=anthropic

# Session Storage
SESSION_STORAGE_TYPE=mongodb
MONGODB_CONNECTION_STRING=mongodb+srv://user:pass@cluster.mongodb.net/db
MONGODB_DATABASE_NAME=agent_sessions_db

# File Storage
S3_AS_DEFAULT=true
AWS_S3_BUCKET=my-production-bucket
AWS_REGION=us-east-1

# Authentication
REQUIRE_AUTH=true
BASIC_AUTH_USERNAME=admin
BASIC_AUTH_PASSWORD=your-secure-password
API_KEYS=sk-key1,sk-key2,sk-key3
ADMIN_PASSWORD=your-admin-password

# Server
AGENT_PORT=8000
AGENT_HOST=0.0.0.0
AGENT_RELOAD=false
LOG_LEVEL=INFO
```

### Production with Elasticsearch

Advanced configuration with Elasticsearch:

```bash
# .env
# API Keys
OPENAI_API_KEY=sk-your-production-key
ANTHROPIC_API_KEY=sk-ant-your-key
GEMINI_API_KEY=your-gemini-key

# Model Configuration
DEFAULT_MODEL=gemini-3-pro-preview

# Session Storage
SESSION_STORAGE_TYPE=elasticsearch
ELASTICSEARCH_ENABLED=true
ELASTICSEARCH_URL=https://my-deployment.es.cloud.es.io:9243
ELASTICSEARCH_USERNAME=elastic
ELASTICSEARCH_PASSWORD=your-es-password
ELASTICSEARCH_VERIFY_CERTS=true

# File Storage
S3_AS_DEFAULT=true
AWS_S3_BUCKET=my-production-bucket
AWS_REGION=us-east-1

# Authentication
REQUIRE_AUTH=true
API_KEYS=sk-key1,sk-key2
ADMIN_PASSWORD=your-admin-password

# Server
AGENT_PORT=8000
LOG_LEVEL=INFO
```

### Production with Kibana Dashboards

Configuration for Kibana metrics visualization:

```bash
# .env
# API Keys
OPENAI_API_KEY=sk-your-production-key
ANTHROPIC_API_KEY=sk-ant-your-key

# Model Configuration
DEFAULT_MODEL=claude-sonnet-4-6

# Session Storage
SESSION_STORAGE_TYPE=elasticsearch
ELASTICSEARCH_ENABLED=true
ELASTICSEARCH_URL=http://elasticsearch:9200

# Enable direct ES metrics logging for Kibana
METRICS_ES_LOGGING_ENABLED=true
METRICS_ENABLED=true

# OpenTelemetry (for Grafana/Prometheus)
OTEL_ENABLED=true
OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317
OTEL_SERVICE_NAME=agent_framework

# Authentication
REQUIRE_AUTH=true
API_KEYS=sk-key1,sk-key2

# Server
AGENT_PORT=8000
LOG_LEVEL=INFO
```

This configuration enables:
- **Kibana**: Metrics in `agent-metrics-*` indices
- **Grafana**: Metrics via Prometheus (scraped from OTel Collector)
- **Jaeger**: Traces via OTel Collector

### Production with A2A and Memory

Full-featured configuration with A2A and hybrid memory:

```bash
# .env
# API Keys
OPENAI_API_KEY=sk-your-key
ANTHROPIC_API_KEY=sk-ant-your-key

# Model Configuration
DEFAULT_MODEL=claude-sonnet-4-6
DEFAULT_MODEL_MODE=auto
AUTO_CLASSIFIER_MODEL=gpt-4o-mini

# A2A
A2A_ENABLED=true
A2A_PUBLIC_URL=https://my-agent.example.com

# Memory (Hybrid: Memori + Graphiti)
MEMORY_PRIMARY_PROVIDER=memori
MEMORY_SECONDARY_PROVIDER=graphiti
MEMORI_DATABASE_URL=postgresql://localhost/memory
GRAPHITI_USE_FALKORDB=true
FALKORDB_HOST=localhost
MEMORY_PASSIVE_INJECTION=true

# Session Storage
SESSION_STORAGE_TYPE=elasticsearch
ELASTICSEARCH_ENABLED=true
ELASTICSEARCH_URL=http://elasticsearch:9200

# Server
AGENT_PORT=8000
LOG_LEVEL=INFO
REQUIRE_AUTH=true
API_KEYS=sk-key1,sk-key2
```

## Troubleshooting

### Common Configuration Errors

#### "No API key configured"
**Cause:** Missing or invalid API key for the selected model provider.
**Solution:** Set the appropriate API key environment variable (`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, or `GEMINI_API_KEY`).

#### "Session storage not available"
**Cause:** Session storage backend failed to initialize.
**Solution:**
- For MongoDB: Verify `MONGODB_CONNECTION_STRING` is correct and MongoDB is running
- For Elasticsearch: Verify `ELASTICSEARCH_URL` and credentials are correct

#### "Authentication required"
**Cause:** `REQUIRE_AUTH=true` but no valid credentials provided.
**Solution:** Provide credentials using Basic Auth, Bearer token, or X-API-Key header.

#### "Elasticsearch service is unavailable"
**Cause:** Elasticsearch is down or unreachable.
**Solution:**
- Check Elasticsearch is running
- Verify `ELASTICSEARCH_URL` is correct
- Check network connectivity
- Circuit breaker will automatically fail over to default configuration

## Environment Variables Reference

Quick reference table of all environment variables:

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| **API Keys** | | | |
| `OPENAI_API_KEY` | string | None | OpenAI API key |
| `ANTHROPIC_API_KEY` | string | None | Anthropic API key |
| `GEMINI_API_KEY` | string | None | Google Gemini API key |
| **Model Configuration** | | | |
| `DEFAULT_MODEL` | string | `gpt-5.4-mini` | Default LLM model |
| `FALLBACK_PROVIDER` | string | `openai` | Fallback provider |
| `OPENAI_DEFAULT_TEMPERATURE` | float | `0.7` | OpenAI temperature |
| `OPENAI_DEFAULT_TIMEOUT` | integer | `120` | OpenAI timeout (seconds) |
| `OPENAI_DEFAULT_MAX_RETRIES` | integer | `3` | OpenAI max retries |
| `OPENAI_API_MODEL` | string | `DEFAULT_MODEL` | Override OpenAI model |
| `OPENAI_MODELS` | string | Internal list | Override known OpenAI models |
| `ANTHROPIC_DEFAULT_TEMPERATURE` | float | `0.7` | Anthropic temperature |
| `ANTHROPIC_DEFAULT_TIMEOUT` | integer | `120` | Anthropic timeout (seconds) |
| `ANTHROPIC_DEFAULT_MAX_RETRIES` | integer | `3` | Anthropic max retries |
| `ANTHROPIC_DEFAULT_MAX_TOKENS` | integer | `32768` | Anthropic max output tokens |
| `ANTHROPIC_MODELS` | string | Internal list | Override known Anthropic models |
| `GEMINI_DEFAULT_TEMPERATURE` | float | `0.7` | Gemini temperature |
| `GEMINI_DEFAULT_TIMEOUT` | integer | `120` | Gemini timeout (seconds) |
| `GEMINI_DEFAULT_MAX_RETRIES` | integer | `3` | Gemini max retries |
| `GEMINI_MODELS` | string | Internal list | Override known Gemini models |
| **Multi-Model Routing** | | | |
| `DEFAULT_MODEL_MODE` | string | `auto` | Routing mode (auto/light/standard/advanced) |
| `AUTO_CLASSIFIER_MODEL` | string | `gpt-4o-mini` | Model for complexity classification |
| `PREFERRED_LIGHT_MODELS` | string | Internal list | Light tier model preferences |
| `PREFERRED_STANDARD_MODELS` | string | Internal list | Standard tier model preferences |
| `PREFERRED_ADVANCED_MODELS` | string | Internal list | Advanced tier model preferences |
| **Session Storage** | | | |
| `SESSION_STORAGE_TYPE` | string | `memory` | Session storage backend |
| `MONGODB_CONNECTION_STRING` | string | `mongodb://localhost:27017` | MongoDB connection URI |
| `MONGODB_DATABASE_NAME` | string | `agent_sessions_db` | MongoDB database name |
| **Elasticsearch Core** | | | |
| `ELASTICSEARCH_ENABLED` | boolean | `false` | Enable Elasticsearch |
| `ELASTICSEARCH_URL` | string | `http://localhost:9200` | Elasticsearch URL |
| `ELASTICSEARCH_USERNAME` | string | None | Elasticsearch username |
| `ELASTICSEARCH_PASSWORD` | string | None | Elasticsearch password |
| `ELASTICSEARCH_API_KEY` | string | None | Elasticsearch API key |
| `ELASTICSEARCH_VERIFY_CERTS` | boolean | `true` | Verify SSL certificates |
| `ELASTICSEARCH_CA_CERTS` | string | None | CA certificate file path |
| **Elasticsearch Advanced** | | | |
| `ELASTICSEARCH_TIMEOUT` | integer | `30` | Request timeout (seconds) |
| `ELASTICSEARCH_MAX_RETRIES` | integer | `3` | Max retries |
| `ELASTICSEARCH_RETRY_ON_TIMEOUT` | boolean | `true` | Retry on timeout |
| `ELASTICSEARCH_SESSION_INDEX_PREFIX` | string | `agent-sessions` | Session index prefix |
| `ELASTICSEARCH_CONFIG_INDEX` | string | `agent-configs` | Config index name |
| `ELASTICSEARCH_CONFIG_CACHE_TTL` | integer | `300` | Config cache TTL (seconds) |
| `ELASTICSEARCH_CONFIG_CACHE_MAX_SIZE` | integer | `100` | Config cache max size |
| `ELASTICSEARCH_ADMIN_CONFIG_INDEX` | string | `agent-admin-config` | Admin config index |
| `ELASTICSEARCH_FILES_INDEX` | string | `agent-files-metadata` | Files metadata index |
| `ELASTICSEARCH_LOG_INDEX_PATTERN` | string | `agent-logs-{date}` | Log index pattern |
| `ELASTICSEARCH_LOG_BATCH_SIZE` | integer | `100` | Log batch size |
| `ELASTICSEARCH_LOG_FLUSH_INTERVAL` | float | `5.0` | Log flush interval (seconds) |
| `ELASTICSEARCH_FALLBACK_TO_FILE` | boolean | `true` | Fall back to file logging |
| `ELASTICSEARCH_FALLBACK_LOG_FILE` | string | `logs/elasticsearch_fallback.log` | Fallback log file |
| `ELASTICSEARCH_CIRCUIT_BREAKER_THRESHOLD` | integer | `5` | Circuit breaker failure threshold |
| `ELASTICSEARCH_CIRCUIT_BREAKER_TIMEOUT` | integer | `30` | Circuit breaker base timeout (seconds) |
| `ELASTICSEARCH_CIRCUIT_BREAKER_MAX_TIMEOUT` | integer | `300` | Circuit breaker max timeout (seconds) |
| `ELASTICSEARCH_CIRCUIT_BREAKER_HEALTH_CHECK_INTERVAL` | integer | `15` | Health check interval (seconds) |
| **File Storage** | | | |
| `LOCAL_STORAGE_PATH` | string | `./file_storage` | Local file storage path |
| `AWS_S3_BUCKET` | string | None | S3 bucket name |
| `AWS_REGION` | string | `us-east-1` | AWS region |
| `AWS_ACCESS_KEY_ID` | string | None | AWS access key (consumed by boto3) |
| `AWS_SECRET_ACCESS_KEY` | string | None | AWS secret key (consumed by boto3) |
| `S3_AS_DEFAULT` | boolean | `false` | Use S3 as default storage |
| `S3_FILE_PREFIX` | string | `agent-files/` | S3 key prefix |
| `S3_URL_MODE` | string | `api` | URL mode (api/presigned/public) |
| `S3_MAX_PRESIGNED_URL_EXPIRATION` | integer | `86400` | Max presigned URL expiration (seconds) |
| `S3_DEFAULT_PRESIGNED_URL_EXPIRATION` | integer | `3600` | Default presigned URL expiration (seconds) |
| `API_BASE_URL` | string | `""` | Base URL for API mode URLs |
| `MINIO_ENDPOINT` | string | None | MinIO endpoint |
| `MINIO_ACCESS_KEY` | string | None | MinIO access key |
| `MINIO_SECRET_KEY` | string | None | MinIO secret key |
| `MINIO_BUCKET` | string | `agent-files` | MinIO bucket name |
| `MINIO_SECURE` | boolean | `true` | Use HTTPS for MinIO |
| `MINIO_FILE_PREFIX` | string | `agent-files/` | MinIO key prefix |
| `MINIO_AS_DEFAULT` | boolean | `false` | Use MinIO as default storage |
| `GCP_STORAGE_BUCKET` | string | None | GCP bucket name |
| `GCP_PROJECT_ID` | string | None | GCP project ID |
| `GCP_FILE_PREFIX` | string | `agent-files/` | GCP key prefix |
| `GCP_AS_DEFAULT` | boolean | `false` | Use GCP as default storage |
| `GOOGLE_APPLICATION_CREDENTIALS` | string | None | GCP credentials file path |
| **File Routing** | | | |
| `IMAGE_STORAGE_BACKEND` | string | effective default | Backend for images |
| `VIDEO_STORAGE_BACKEND` | string | effective default | Backend for videos |
| `PDF_STORAGE_BACKEND` | string | effective default | Backend for PDFs |
| `TEXT_STORAGE_BACKEND` | string | effective default | Backend for text files |
| `AI_TEXT_STORAGE_BACKEND` | string | effective default | Backend for AI text |
| `AI_HTML_STORAGE_BACKEND` | string | effective default | Backend for AI HTML |
| `AI_CHART_STORAGE_BACKEND` | string | `s3` if available | Backend for AI charts |
| `AI_CODE_STORAGE_BACKEND` | string | effective default | Backend for AI code |
| `AI_DATA_STORAGE_BACKEND` | string | effective default | Backend for AI data |
| `AI_IMAGE_STORAGE_BACKEND` | string | `s3` if available | Backend for AI images |
| `AI_MARKDOWN_STORAGE_BACKEND` | string | effective default | Backend for AI Markdown |
| `AI_JSON_STORAGE_BACKEND` | string | effective default | Backend for AI JSON |
| `AI_CSV_STORAGE_BACKEND` | string | effective default | Backend for AI CSV |
| `AI_YAML_STORAGE_BACKEND` | string | effective default | Backend for AI YAML |
| `AI_XML_STORAGE_BACKEND` | string | effective default | Backend for AI XML |
| `AI_CONTENT_STORAGE_BACKEND` | string | effective default | Fallback backend for AI content |
| `FILE_ROUTING_RULES` | string | None | Custom routing rules |
| **Authentication** | | | |
| `REQUIRE_AUTH` | boolean | `false` | Enable authentication |
| `BASIC_AUTH_USERNAME` | string | `admin` | Basic auth username |
| `BASIC_AUTH_PASSWORD` | string | `password` | Basic auth password |
| `API_KEYS` | string | Empty | Comma-separated API keys |
| `ADMIN_PASSWORD` | string | `admin123` | Admin password |
| **Metrics & Observability** | | | |
| `METRICS_ENABLED` | boolean | `true` | Master switch for all metrics |
| `METRICS_ES_LOGGING_ENABLED` | boolean | `false` | Enable direct ES logging for Kibana |
| `METRICS_INDEX_PREFIX` | string | `agent-metrics` | Base prefix for metrics indices |
| `METRICS_BATCH_SIZE` | integer | `50` | Batch size for ES bulk operations |
| `METRICS_FLUSH_INTERVAL` | float | `5.0` | Flush interval (seconds) |
| `UNIFIED_METRICS_ENABLED` | boolean | `true` | Enable unified metrics aggregator |
| `METRICS_MAX_BUFFER_SIZE` | integer | `1000` | Max metrics buffer size |
| **OpenTelemetry** | | | |
| `OTEL_ENABLED` | boolean | `true` | Enable OpenTelemetry |
| `OTEL_SERVICE_NAME` | string | `agent_framework` | OTel service name |
| `OTEL_SERVICE_VERSION` | string | `1.0.0` | OTel service version |
| `OTEL_ENVIRONMENT` | string | `development` | OTel environment |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | string | None | OTLP endpoint URL |
| `OTEL_EXPORTER_OTLP_PROTOCOL` | string | `grpc` | OTLP protocol |
| `OTEL_METRICS_EXPORTER` | string | `otlp` | Metrics exporter type |
| `OTEL_LOGS_EXPORTER` | string | `otlp` | Logs exporter type |
| **Monitoring** | | | |
| `RESOURCE_METRICS_ENABLED` | boolean | `true` | CPU/memory metrics collection |
| `API_TIMING_ENABLED` | boolean | `true` | API timing middleware |
| `LLM_AUTO_INSTRUMENTATION_ENABLED` | boolean | None (auto) | LLM auto-instrumentation |
| `ENABLE_LLM_METRICS` | boolean | `true` | LLM call metrics |
| **Content Processing** | | | |
| `RICH_CONTENT_VALIDATION_ENABLED` | boolean | `true` | Rich content validation master switch |
| `MERMAID_VALIDATION_ENABLED` | boolean | `true` | Mermaid diagram validation |
| `CHART_VALIDATION_ENABLED` | boolean | `true` | Chart.js content validation |
| `TABLE_VALIDATION_ENABLED` | boolean | `true` | Table content validation |
| `RICH_CONTENT_AUTO_REPAIR` | boolean | `true` | Auto-repair invalid rich content |
| `MAX_MARKDOWN_FILE_SIZE_MB` | integer | `50` | Max Markdown file size (MB) |
| `MARKDOWN_CONVERSION_TIMEOUT_SECONDS` | integer | `300` | Markdown conversion timeout (seconds) |
| `ENABLE_PARTIAL_CONVERSION` | boolean | `true` | Allow partial Markdown conversion |
| **A2A** | | | |
| `A2A_ENABLED` | boolean | `false` | Enable A2A endpoints |
| `A2A_PUBLIC_URL` | string | None | Public URL for Agent Card |
| **Memory** | | | |
| `MEMORY_PRIMARY_PROVIDER` | string | `none` | Primary memory provider |
| `MEMORY_SECONDARY_PROVIDER` | string | None | Secondary memory provider |
| `MEMORY_AUTO_STORE` | boolean | `true` | Auto-store interactions |
| `MEMORY_MAX_CONTEXT_FACTS` | integer | `20` | Max context facts |
| `MEMORY_PASSIVE_INJECTION` | boolean | `true` | Enable passive injection |
| `MEMORY_PASSIVE_MAX_FACTS` | integer | `10` | Max passive injection facts |
| `MEMORY_PASSIVE_MIN_CONFIDENCE` | float | `0.5` | Min confidence for injection |
| `MEMORY_PASSIVE_PRIMARY_ONLY` | boolean | `true` | Primary-only passive injection |
| `MEMORY_ASYNC_STORE` | boolean | `true` | Async storage |
| `MEMORY_ASYNC_MAX_CONCURRENT` | integer | `10` | Max concurrent async stores |
| `MEMORY_ASYNC_TIMEOUT` | float | `40.0` | Async shutdown timeout (seconds) |
| `MEMORI_DATABASE_URL` | string | `sqlite:///agent_memory.db` | Memori database URL |
| `MEMORI_API_KEY` | string | None | Memori API key |
| `GRAPHITI_USE_FALKORDB` | boolean | `false` | Use FalkorDB instead of Neo4j |
| `NEO4J_URI` | string | `bolt://localhost:7687` | Neo4j URI |
| `NEO4J_USER` | string | `neo4j` | Neo4j username |
| `NEO4J_PASSWORD` | string | `password` | Neo4j password |
| `NEO4J_DATABASE` | string | `neo4j` | Neo4j database |
| `FALKORDB_HOST` | string | `localhost` | FalkorDB host |
| `FALKORDB_PORT` | integer | `6379` | FalkorDB port |
| `FALKORDB_PASSWORD` | string | None | FalkorDB password |
| `GRAPHITI_LLM_MODEL` | string | `gpt-4o-mini` | Graphiti LLM model |
| `GRAPHITI_EMBEDDING_MODEL` | string | `text-embedding-3-small` | Graphiti embedding model |
| `GRAPHITI_EMBEDDING_DIM` | integer | `1536` | Embedding dimension |
| `GRAPHITI_ENVIRONMENT` | string | `dev` | Graphiti environment prefix |
| `GRAPHITI_SKIP_INDEX_CREATION` | boolean | `false` | Skip index creation |
| **Helper Agent** | | | |
| `HELPER_AGENT_MODEL` | string | None (auto) | Helper agent LLM model |
| `HELPER_AGENT_MEMORY_DB` | string | `sqlite:///helper_agent_memory.db` | Helper agent memory DB |
| `HELPER_AGENT_USER_ID` | string | None | Fixed helper agent user ID |
| **Session Titles** | | | |
| `AUTO_GENERATE_SESSION_TITLES` | boolean | `true` | Auto-generate session titles |
| `SESSION_TITLE_MODEL` | string | `gpt-4o-mini` | Title generation model |
| `SESSION_TITLE_MAX_TOKENS` | integer | `30` | Max tokens for titles |
| `SESSION_TITLE_TEMPERATURE` | float | `0.3` | Title generation temperature |
| **Server** | | | |
| `AGENT_PORT` | integer | `8000` | Server port |
| `AGENT_HOST` | string | `0.0.0.0` | Server host |
| `AGENT_RELOAD` | boolean | `true` | Auto-reload (dev) |
| `LOG_LEVEL` | string | `INFO` | Logging level |
| `AGENT_TYPE` | string | Class name | Agent type identifier |
| `AGENT_CLASS_PATH` | string | None | Agent module:class path |
| `AGENT_MODULE` | string | `agent` | Agent module (fallback) |
| `AGENT_CLASS` | string | `PersonalAssistantAgent` | Agent class (fallback) |
| **Feature Toggles** | | | |
| `AGENT_FRAMEWORK_SKIP_AUTO_SETUP` | boolean | `false` | Skip auto-setup on import |
| `ENABLE_SKILLS` | boolean | `true` | Enable skills system |
| `PERSONALIZATION_ENABLED` | boolean | `true` | Enable personalization |
| `ENABLE_MULTIMODAL_ANALYSIS` | boolean | `false` | Enable multimodal analysis |
