"""
MarkdownSkillLoader — loads SKILL.md files into Skill objects.

A SKILL.md file is a Markdown document with a YAML frontmatter block:

    ---
    name: my-skill
    description: "Does something useful"
    metadata:
      config:
        emoji: "🔧"
        primaryEnv: MY_API_KEY
        requires:
          bins: [curl]
          env: [MY_API_KEY]
    ---

    ## Instructions
    ...
"""

from __future__ import annotations

import logging
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from agent_framework.skills.base import Skill, SkillMetadata


logger = logging.getLogger(__name__)


@dataclass
class SkillConfig:
    """Config metadata block inside a SKILL.md frontmatter."""

    emoji: str | None = None
    primary_env: str | None = None
    requires_bins: list[str] = field(default_factory=list)
    requires_env: list[str] = field(default_factory=list)
    install: list[dict[str, Any]] = field(default_factory=list)
    trigger_patterns: list[str] = field(default_factory=list)
    entrypoint: str | None = None
    runtime: str | None = None

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, SkillConfig):
            return NotImplemented
        return (
            self.emoji == other.emoji
            and self.primary_env == other.primary_env
            and self.requires_bins == other.requires_bins
            and self.requires_env == other.requires_env
            and self.install == other.install
            and self.trigger_patterns == other.trigger_patterns
            and self.entrypoint == other.entrypoint
            and self.runtime == other.runtime
        )


@dataclass
class SkillFrontmatterMeta:
    """metadata block inside a SKILL.md frontmatter."""

    config: SkillConfig = field(default_factory=SkillConfig)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, SkillFrontmatterMeta):
            return NotImplemented
        return self.config == other.config


@dataclass
class SkillFrontmatter:
    """Parsed representation of a SKILL.md frontmatter block."""

    name: str
    description: str
    homepage: str | None = None
    display_name: str | None = None
    metadata: SkillFrontmatterMeta = field(default_factory=SkillFrontmatterMeta)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, SkillFrontmatter):
            return NotImplemented
        return (
            self.name == other.name
            and self.description == other.description
            and self.homepage == other.homepage
            and self.display_name == other.display_name
            and self.metadata == other.metadata
        )

    def to_yaml(self) -> str:
        """Serialize to a YAML string suitable for reinsertion at the top of a SKILL.md."""
        data: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
        }
        if self.homepage is not None:
            data["homepage"] = self.homepage
        if self.display_name is not None:
            data["display_name"] = self.display_name

        cfg = self.metadata.config
        config_dict: dict[str, Any] = {}
        if cfg.emoji is not None:
            config_dict["emoji"] = cfg.emoji
        if cfg.primary_env is not None:
            config_dict["primaryEnv"] = cfg.primary_env
        if cfg.requires_bins or cfg.requires_env:
            config_dict["requires"] = {}
            if cfg.requires_bins:
                config_dict["requires"]["bins"] = cfg.requires_bins
            if cfg.requires_env:
                config_dict["requires"]["env"] = cfg.requires_env
        if cfg.install:
            config_dict["install"] = cfg.install
        if cfg.trigger_patterns:
            config_dict["trigger_patterns"] = cfg.trigger_patterns
        if cfg.entrypoint is not None:
            config_dict["entrypoint"] = cfg.entrypoint
        if cfg.runtime is not None:
            config_dict["runtime"] = cfg.runtime

        if config_dict:
            data["metadata"] = {"config": config_dict}

        return yaml.dump(data, allow_unicode=True, default_flow_style=False, sort_keys=False)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SkillFrontmatter":
        """Deserialize from a dict produced by yaml.safe_load."""
        name = data.get("name", "")
        description = data.get("description", "")
        homepage = data.get("homepage")
        display_name = data.get("display_name")

        meta_raw = data.get("metadata") or {}
        cfg_raw = meta_raw.get("config") or {}
        requires_raw = cfg_raw.get("requires") or {}

        cfg = SkillConfig(
            emoji=cfg_raw.get("emoji"),
            primary_env=cfg_raw.get("primaryEnv"),
            requires_bins=list(requires_raw.get("bins") or []),
            requires_env=list(requires_raw.get("env") or []),
            install=list(cfg_raw.get("install") or []),
            trigger_patterns=list(cfg_raw.get("trigger_patterns") or []),
            entrypoint=cfg_raw.get("entrypoint"),
            runtime=cfg_raw.get("runtime"),
        )
        meta = SkillFrontmatterMeta(config=cfg)
        return cls(name=name, description=description, homepage=homepage, display_name=display_name, metadata=meta)


class MarkdownSkillLoader:
    """Loads SKILL.md files and converts them into Skill objects."""

    def load_from_file(self, skill_md_path: Path) -> Skill:
        """Parse a SKILL.md file and return a Skill.

        Args:
            skill_md_path: Path to the SKILL.md file.

        Returns:
            A Skill instance ready to be registered in a SkillRegistry.

        Raises:
            ValueError: If the frontmatter is missing, invalid YAML, or 'name' is absent.
        """
        content = skill_md_path.read_text(encoding="utf-8")
        frontmatter_dict, body = self._parse_frontmatter(content)
        return self._build_skill(frontmatter_dict, body, skill_md_path)

    def load_from_dir(self, skills_dir: Path) -> list[Skill]:
        """Load all SKILL.md files found in a directory (non-recursive).

        Args:
            skills_dir: Directory to scan for SKILL.md files.

        Returns:
            List of successfully loaded Skill objects.

        Raises:
            ValueError: If the directory does not exist.
        """
        if not skills_dir.exists() or not skills_dir.is_dir():
            raise ValueError(f"Skills directory not found: {skills_dir}")

        skills: list[Skill] = []
        for skill_file in sorted(skills_dir.rglob("SKILL.md")):
            try:
                skill = self.load_from_file(skill_file)
                skills.append(skill)
            except Exception as exc:
                logger.warning(
                    "Skipping invalid SKILL.md at %s: %s", skill_file, exc
                )
        return skills

    def _parse_frontmatter(self, content: str) -> tuple[dict[str, Any], str]:
        """Split YAML frontmatter from Markdown body.

        Args:
            content: Raw file content.

        Returns:
            Tuple of (frontmatter_dict, markdown_body).

        Raises:
            ValueError: If the YAML block is syntactically invalid or missing.
        """
        if not content.startswith("---"):
            return {}, content

        end = content.find("\n---", 3)
        if end == -1:
            raise ValueError("Frontmatter block is not closed (missing closing '---')")

        yaml_block = content[3:end].strip()
        body = content[end + 4:].lstrip("\n")

        try:
            parsed = yaml.safe_load(yaml_block)
        except yaml.YAMLError as exc:
            raise ValueError(f"Invalid YAML frontmatter: {exc}") from exc

        if not isinstance(parsed, dict):
            raise ValueError("Frontmatter must be a YAML mapping")

        return parsed, body

    def _build_skill(
        self, frontmatter: dict[str, Any], body: str, source_path: Path
    ) -> Skill:
        """Construct a Skill from parsed frontmatter and Markdown body.

        Args:
            frontmatter: Parsed YAML dict.
            body: Markdown body text.
            source_path: Original file path (used for error messages).

        Returns:
            A Skill instance.

        Raises:
            ValueError: If 'name' is absent from the frontmatter.
        """
        name = frontmatter.get("name")
        if not name:
            raise ValueError(
                f"SKILL.md at {source_path} is missing required 'name' field"
            )

        description = frontmatter.get("description", "")
        meta_raw = frontmatter.get("metadata") or {}
        cfg_raw = meta_raw.get("config") or {}
        requires_raw = cfg_raw.get("requires") or {}

        requires_bins: list[str] = list(requires_raw.get("bins") or [])
        requires_env: list[str] = list(requires_raw.get("env") or [])
        emoji: str | None = cfg_raw.get("emoji")
        trigger_patterns: list[str] = list(cfg_raw.get("trigger_patterns") or [])

        for binary in requires_bins:
            if shutil.which(binary) is None:
                logger.warning(
                    "Skill '%s' requires binary '%s' which was not found in PATH",
                    name,
                    binary,
                )

        skill_metadata = SkillMetadata(
            name=name,
            description=description,
            requires_bins=requires_bins,
            requires_env=requires_env,
            trigger_patterns=trigger_patterns,
        )

        entrypoint: str | None = cfg_raw.get("entrypoint")
        runtime: str | None = cfg_raw.get("runtime")

        skill = Skill(metadata=skill_metadata, instructions=body)
        if emoji:
            skill.display_icon = emoji
        if entrypoint is not None:
            skill.config["entrypoint"] = entrypoint
        if runtime is not None:
            skill.config["runtime"] = runtime

        # Store the skill directory for runtime path resolution
        skill.config["skill_dir"] = str(source_path.parent.resolve())

        display_name: str | None = frontmatter.get("display_name")
        if display_name:
            skill.display_name = display_name

        return skill


__all__ = [
    "SkillConfig",
    "SkillFrontmatter",
    "SkillFrontmatterMeta",
    "MarkdownSkillLoader",
]
