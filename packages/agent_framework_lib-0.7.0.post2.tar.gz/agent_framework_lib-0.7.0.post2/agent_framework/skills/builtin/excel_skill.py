"""
Excel Skill - spreadsheet generation capability.

Wraps CreateExcelTool with instructions for generating .xlsx files.
"""

from ..base import Skill, SkillCategory, SkillMetadata
from ...tools.excel_tools import CreateExcelTool


EXCEL_INSTRUCTIONS = """
## Excel Spreadsheet Generation

Use the `create_excel_file` tool to generate `.xlsx` spreadsheet files.

### Tool Parameters

- `filename` (str): Target filename, e.g. `"report.xlsx"`
- `sheets` (list): One or more sheet definitions. Each sheet has:
  - `name` (str): Sheet tab name
  - `headers` (list[str]): Column header labels
  - `rows` (list[list]): Data rows — each row is a list of cell values
  - `bold_header` (bool, optional): Apply bold formatting to the header row (default: `false`)

### Example

```json
{
  "filename": "sales_report.xlsx",
  "sheets": [
    {
      "name": "Q1 Sales",
      "headers": ["Month", "Revenue", "Units"],
      "rows": [
        ["January", 12500, 250],
        ["February", 15000, 300],
        ["March", 11000, 220]
      ],
      "bold_header": true
    },
    {
      "name": "Summary",
      "headers": ["Metric", "Value"],
      "rows": [
        ["Total Revenue", 38500],
        ["Total Units", 770]
      ]
    }
  ]
}
```

### Notes

- Multiple sheets are supported in a single call.
- Row length does not need to match header count — short rows leave trailing cells empty.
- Requires `openpyxl` to be installed (`uv add openpyxl`).
"""


def create_excel_skill() -> Skill:
    """
    Create the Excel spreadsheet generation skill.

    Returns:
        Skill instance for Excel file generation.
    """
    skill = Skill(
        metadata=SkillMetadata(
            name="excel",
            description="Generate .xlsx Excel spreadsheet files with multiple sheets and formatting.",
            trigger_patterns=["excel", "spreadsheet", "xlsx", "tableau"],
            category=SkillCategory.DOCUMENT,
            version="1.0.0",
        ),
        instructions=EXCEL_INSTRUCTIONS,
        tools=[CreateExcelTool()],
        dependencies=[],
        config={},
    )
    skill._display_name = "Génération de fichiers Excel"
    skill._display_icon = "📊"
    return skill


__all__ = ["create_excel_skill", "EXCEL_INSTRUCTIONS"]
