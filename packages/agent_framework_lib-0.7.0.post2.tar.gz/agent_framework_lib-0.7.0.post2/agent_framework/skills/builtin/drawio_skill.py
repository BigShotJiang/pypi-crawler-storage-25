"""
Draw.io Skill - diagram generation capability.

Wraps CreateDrawioTool with instructions for generating .drawio XML files.
"""

from ..base import Skill, SkillCategory, SkillMetadata
from ...tools.drawio_tools import CreateDrawioTool


DRAWIO_INSTRUCTIONS = """
## Draw.io Diagram Generation

Use the `create_drawio_file` tool to generate `.drawio` diagram files that open in Draw.io or diagrams.net.

### Tool Parameters

- `filename` (str): Target filename, e.g. `"architecture.drawio"`
- `title` (str): Diagram page title
- `nodes` (list): Shape/element definitions. Each node has:
  - `id` (str): Unique identifier (used by edges)
  - `label` (str): Display text inside the shape
  - `shape` (str, optional): One of `rectangle`, `rounded`, `ellipse`, `diamond`, `parallelogram` (default: `rectangle`)
  - `x` (int, optional): X position in pixels
  - `y` (int, optional): Y position in pixels
- `edges` (list): Connection definitions. Each edge has:
  - `source` (str): Source node `id`
  - `target` (str): Target node `id`
  - `label` (str, optional): Label displayed on the edge

### Supported Shapes

| Shape | Description |
|---|---|
| `rectangle` | Standard rectangle (default) |
| `rounded` | Rectangle with rounded corners |
| `ellipse` | Oval / circle |
| `diamond` | Diamond / decision shape |
| `parallelogram` | Parallelogram (input/output) |

### Example — Flowchart

```json
{
  "filename": "order_flow.drawio",
  "title": "Order Processing Flow",
  "nodes": [
    {"id": "start", "label": "Start", "shape": "ellipse", "x": 100, "y": 50},
    {"id": "check", "label": "Check Stock?", "shape": "diamond", "x": 100, "y": 180},
    {"id": "ship", "label": "Ship Order", "shape": "rectangle", "x": 50, "y": 320},
    {"id": "notify", "label": "Notify Customer", "shape": "rounded", "x": 200, "y": 320},
    {"id": "end", "label": "End", "shape": "ellipse", "x": 125, "y": 460}
  ],
  "edges": [
    {"source": "start", "target": "check"},
    {"source": "check", "target": "ship", "label": "In Stock"},
    {"source": "check", "target": "notify", "label": "Out of Stock"},
    {"source": "ship", "target": "end"},
    {"source": "notify", "target": "end"}
  ]
}
```

### Notes

- All edge `source` and `target` values must match an existing node `id`.
- Requires `drawpyo` to be installed (`uv add drawpyo`).
- Generated files open directly in Draw.io (https://app.diagrams.net) or diagrams.net.
"""


def create_drawio_skill() -> Skill:
    """
    Create the Draw.io diagram generation skill.

    Returns:
        Skill instance for Draw.io file generation.
    """
    skill = Skill(
        metadata=SkillMetadata(
            name="drawio",
            description="Generate .drawio diagram files for flowcharts, architecture diagrams, and more.",
            trigger_patterns=["drawio", "diagram", "flowchart", "architecture diagram", "draw.io"],
            category=SkillCategory.VISUALIZATION,
            version="1.0.0",
        ),
        instructions=DRAWIO_INSTRUCTIONS,
        tools=[CreateDrawioTool()],
        dependencies=[],
        config={},
    )
    skill._display_name = "Génération de diagrammes Draw.io"
    skill._display_icon = "🗂️"
    return skill


__all__ = ["create_drawio_skill", "DRAWIO_INSTRUCTIONS"]
