#!/usr/bin/env python3
"""Standalone CLI script for rendering Chart.js configurations as PNG images.

Reads a Chart.js JSON configuration from stdin and uses Playwright to render
the chart in a headless browser, then saves a screenshot as a PNG file.
Outputs a JSON result on stdout.
"""
import argparse
import json
import os
import sys

# Default rendering parameters
RENDER_SIZE = 1600
DEVICE_SCALE = 2
CHART_JS_CDN = "https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"
MIN_WIDTH = 1200
MIN_HEIGHT = 900
RENDER_WAIT_MS = 1500


def _build_html(chart_config: dict, background_color: str = "white") -> str:
    """Build an HTML page embedding Chart.js with the given configuration.

    Args:
        chart_config: Parsed Chart.js configuration dictionary.
        background_color: CSS background color for the page.

    Returns:
        Complete HTML string ready for Playwright rendering.
    """
    return f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <script src="{CHART_JS_CDN}"></script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ margin: 0; padding: 0; background-color: {background_color}; }}
        #chartContainer {{ display: inline-block; background-color: {background_color}; }}
        #chartWrapper {{ width: {RENDER_SIZE}px; height: {RENDER_SIZE}px; position: relative; }}
    </style>
</head>
<body>
    <div id="chartContainer">
        <div id="chartWrapper">
            <canvas id="myChart"></canvas>
        </div>
    </div>
    <script>
        const ctx = document.getElementById('myChart');
        const config = {json.dumps(chart_config)};
        if (!config.options) {{ config.options = {{}}; }}
        config.options.responsive = true;
        config.options.maintainAspectRatio = true;
        new Chart(ctx, config);
    </script>
</body>
</html>"""


async def render_chart(chart_config: dict, filename: str, output_dir: str) -> str:
    """Render a Chart.js configuration as a PNG image using Playwright.

    Args:
        chart_config: Parsed Chart.js configuration dictionary with at least
                      'type' and 'data' keys.
        filename: Target filename for the PNG file.
        output_dir: Directory where the file will be written.

    Returns:
        Absolute path to the created PNG file.

    Raises:
        ValueError: If filename is empty or chart_config is missing required fields.
        ImportError: If playwright is not installed.
        RuntimeError: If browser rendering fails.
    """
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        raise ImportError(
            "Playwright is not installed. Install it with:\n"
            "  uv add playwright\n"
            "  playwright install chromium"
        )

    if not filename or not filename.strip():
        raise ValueError("Filename cannot be empty")

    if "type" not in chart_config:
        raise ValueError("chart_config must include a 'type' field")
    if "data" not in chart_config:
        raise ValueError("chart_config must include a 'data' field")

    # Unwrap if the config was wrapped by a validator
    if (
        isinstance(chart_config, dict)
        and chart_config.get("type") == "chartjs"
        and "chartConfig" in chart_config
    ):
        chart_config = chart_config["chartConfig"]

    html_content = _build_html(chart_config)

    async with async_playwright() as p:
        browser = await p.chromium.launch()
        try:
            page = await browser.new_page(
                viewport={"width": RENDER_SIZE + 100, "height": RENDER_SIZE + 100},
                device_scale_factor=DEVICE_SCALE,
            )
            await page.set_content(html_content)
            await page.wait_for_timeout(RENDER_WAIT_MS)

            canvas_box = await page.evaluate(
                """() => {
                    const canvas = document.getElementById('myChart');
                    const rect = canvas.getBoundingClientRect();
                    return { width: rect.width, height: rect.height };
                }"""
            )

            screenshot_bytes = await page.screenshot(
                type="png",
                clip={
                    "x": 0,
                    "y": 0,
                    "width": canvas_box["width"],
                    "height": canvas_box["height"],
                },
            )
        finally:
            await browser.close()

    # Scale up if needed to meet minimum dimensions
    screenshot_bytes = _ensure_minimum_size(screenshot_bytes)

    # Sanitize filename
    safe_filename = "".join(
        c for c in filename if c.isalnum() or c in (" ", "-", "_", ".")
    ).strip()
    safe_filename = safe_filename.replace(" ", "_")
    if not safe_filename.lower().endswith(".png"):
        safe_filename += ".png"

    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, safe_filename)
    filepath = os.path.abspath(filepath)

    with open(filepath, "wb") as f:
        f.write(screenshot_bytes)

    return filepath


def _ensure_minimum_size(screenshot_bytes: bytes) -> bytes:
    """Scale up the image if it's below minimum dimensions.

    Args:
        screenshot_bytes: Raw PNG bytes from the screenshot.

    Returns:
        PNG bytes, possibly resized to meet MIN_WIDTH/MIN_HEIGHT.
    """
    try:
        import io

        from PIL import Image

        img = Image.open(io.BytesIO(screenshot_bytes))
        w, h = img.size

        width_scale = MIN_WIDTH / w if w < MIN_WIDTH else 1.0
        height_scale = MIN_HEIGHT / h if h < MIN_HEIGHT else 1.0
        scale = max(width_scale, height_scale)

        if scale > 1.0:
            img = img.resize(
                (int(w * scale), int(h * scale)), Image.Resampling.LANCZOS
            )
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return buf.getvalue()
    except ImportError:
        pass

    return screenshot_bytes


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Render a Chart.js configuration as a PNG image. "
            "Reads the Chart.js JSON config from stdin."
        )
    )
    parser.add_argument(
        "--filename",
        required=True,
        help="Target filename for the PNG file (e.g. 'sales_chart.png')",
    )
    parser.add_argument(
        "--output-dir",
        default=".",
        help="Directory where the file will be written (default: current directory)",
    )
    args = parser.parse_args()

    try:
        raw = sys.stdin.read()
        if not raw.strip():
            raise ValueError("No JSON data provided on stdin")
        chart_config = json.loads(raw)
        if not isinstance(chart_config, dict):
            raise ValueError("Stdin JSON must be a Chart.js configuration object")
    except json.JSONDecodeError as e:
        print(
            json.dumps({"status": "error", "message": f"Invalid JSON on stdin: {e}"}),
            file=sys.stderr,
        )
        sys.exit(1)
    except ValueError as e:
        print(
            json.dumps({"status": "error", "message": str(e)}),
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        import asyncio

        filepath = asyncio.run(render_chart(chart_config, args.filename, args.output_dir))
        print(json.dumps({"status": "success", "file": filepath}))
    except Exception as e:
        print(
            json.dumps({"status": "error", "message": str(e)}),
            file=sys.stderr,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
