---
name: chart
description: "Display interactive Chart.js charts in chat OR save as PNG images. Use ```chart code blocks for display (default), chart_to_image.py script for files."
display_name: "Génération des graphiques"
metadata:
  config:
    emoji: "📊"
    trigger_patterns:
      - chart
      - graph
      - plot
      - visualization
      - bar chart
      - line chart
      - pie chart
      - doughnut
      - scatter
      - radar
    requires:
      bins:
        - uv
---

## Chart Generation Instructions

You have TWO ways to create charts:
1. **🖥️ Interactive Display** (DEFAULT) - Show chart directly in chat using ```chart code block
2. **💾 Save as Image** - Create PNG file by running the `chart_to_image.py` script via `shell_exec`
3. You can do both.

### ⚡ Quick Decision Guide

```
User wants to see a chart?
├── Just "show me" / "create" / "display" → Use Interactive Display (```chart)
├── "Save as image" / "download" / "PNG" → Use Save as Image script
├── "Put in PDF" / "embed in document" → Use Save as Image script
├── Not sure? → Default to Interactive Display
└── Everytime you create a chart you display it just don't do it if say otherwise
```

**DEFAULT BEHAVIOR**: Always use Interactive Display unless the user explicitly needs a file.

---

## 🖥️ Interactive Display (DEFAULT)

To display a chart directly in the chat, use a fenced code block with the `chart` language identifier.

**Format:**
```chart
{
  "type": "chartjs",
  "chartConfig": {
    "type": "bar",
    "data": { ... },
    "options": { ... }
  }
}
```

**CRITICAL**: The wrapper structure MUST be:
```json
{
  "type": "chartjs",
  "chartConfig": { /* Your Chart.js config here */ }
}
```

### Complete Interactive Display Example

```chart
{
  "type": "chartjs",
  "chartConfig": {
    "type": "bar",
    "data": {
      "labels": ["January", "February", "March", "April", "May"],
      "datasets": [{
        "label": "Sales 2024",
        "data": [65, 59, 80, 81, 56],
        "backgroundColor": "rgba(54, 162, 235, 0.6)",
        "borderColor": "rgba(54, 162, 235, 1)",
        "borderWidth": 1
      }]
    },
    "options": {
      "responsive": true,
      "plugins": {
        "title": {"display": true, "text": "Monthly Sales"},
        "legend": {"display": true}
      },
      "scales": {
        "y": {"beginAtZero": true}
      }
    }
  }
}
```

### More Interactive Display Examples

**Line Chart:**
```chart
{
  "type": "chartjs",
  "chartConfig": {
    "type": "line",
    "data": {
      "labels": ["Week 1", "Week 2", "Week 3", "Week 4"],
      "datasets": [{
        "label": "Revenue",
        "data": [1200, 1900, 1500, 2100],
        "borderColor": "rgba(75, 192, 192, 1)",
        "backgroundColor": "rgba(75, 192, 192, 0.2)",
        "fill": true,
        "tension": 0.4
      }]
    },
    "options": {
      "responsive": true,
      "plugins": {
        "title": {"display": true, "text": "Weekly Revenue Trend"}
      }
    }
  }
}
```

**Pie Chart:**
```chart
{
  "type": "chartjs",
  "chartConfig": {
    "type": "pie",
    "data": {
      "labels": ["Product A", "Product B", "Product C"],
      "datasets": [{
        "data": [300, 150, 100],
        "backgroundColor": [
          "rgba(255, 99, 132, 0.8)",
          "rgba(54, 162, 235, 0.8)",
          "rgba(255, 206, 86, 0.8)"
        ]
      }]
    },
    "options": {
      "responsive": true,
      "plugins": {
        "title": {"display": true, "text": "Product Distribution"},
        "legend": {"display": true, "position": "right"}
      }
    }
  }
}
```

---

## 💾 Save as Image (For PDFs/Downloads ONLY)

**⚠️ WARNING**: Only use the save-as-image script when the user explicitly needs a PNG file.
Do NOT use this script just to show a chart - use Interactive Display instead!

**Use Save as Image ONLY for:**
- Creating a PDF document with embedded chart
- User explicitly asks to "save", "download", or "export" the chart
- Sharing the chart externally (email, etc.)

### Usage

Pipe a Chart.js JSON configuration object to stdin and specify the target filename:

```bash
echo '{"type": "bar", "data": {"labels": ["Jan", "Feb", "Mar"], "datasets": [{"label": "Sales", "data": [65, 59, 80]}]}, "options": {"responsive": true}}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill chart --filename "sales_chart.png" --output-dir "/path/to/output"
```

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Target filename for the PNG file, e.g. `"sales_chart.png"` |
| `--output-dir` | No | Directory where the file will be written (default: current directory) |

### Stdin (JSON)

Provide a Chart.js configuration object on stdin. The object must contain:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `type` | string | Yes | Chart type (`bar`, `line`, `pie`, `doughnut`, `polarArea`, `radar`, `scatter`, `bubble`) |
| `data` | object | Yes | Chart data with `labels` and `datasets` arrays |
| `options` | object | No | Chart.js options (title, legend, scales, etc.) |

### Example

To render a bar chart as a PNG image:

```bash
echo '{
  "type": "bar",
  "data": {
    "labels": ["January", "February", "March", "April", "May"],
    "datasets": [{
      "label": "Sales 2024",
      "data": [65, 59, 80, 81, 56],
      "backgroundColor": "rgba(54, 162, 235, 0.6)",
      "borderColor": "rgba(54, 162, 235, 1)",
      "borderWidth": 1
    }]
  },
  "options": {
    "responsive": true,
    "plugins": {
      "title": {"display": true, "text": "Monthly Sales"},
      "legend": {"display": true}
    },
    "scales": {
      "y": {"beginAtZero": true}
    }
  }
}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill chart --filename "monthly_sales.png"
```

### Output Format (stdout)

On success, the script prints a JSON object to stdout with the download URL:

```json
{"status": "success", "file_id": "uuid", "download_url": "/files/uuid/download", "filename": "monthly_sales.png", "size_bytes": 1234, "mime_type": "image/png", "local_cleaned": true}
```

Use the `download_url` to provide the user with a download link: `[monthly_sales.png](/files/uuid/download)`

### Error Handling (stderr)

On failure, the script prints a JSON error to stderr and exits with a non-zero code:

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | No JSON data provided on stdin | `"No JSON data provided on stdin"` |
| 1 | Invalid JSON on stdin | `"Invalid JSON on stdin: ..."` |
| 1 | Stdin JSON is not a dict | `"Stdin JSON must be a Chart.js configuration object"` |
| 1 | Missing `type` field in config | `"chart_config must include a 'type' field"` |
| 1 | Missing `data` field in config | `"chart_config must include a 'data' field"` |
| 1 | Empty filename | `"Filename cannot be empty"` |
| 1 | Missing dependency | `"Playwright is not installed. Install it with: uv add playwright"` |
| 2 | Missing required arguments | argparse usage message |

---

## Chart Configuration Reference

### Supported Chart Types
- `bar` - Bar charts (vertical)
- `line` - Line charts
- `pie` - Pie charts
- `doughnut` - Doughnut charts
- `polarArea` - Polar area charts
- `radar` - Radar charts
- `scatter` - Scatter plots
- `bubble` - Bubble charts

### CRITICAL: NO JAVASCRIPT FUNCTIONS ALLOWED
The chartConfig must be PURE JSON - NO JavaScript functions or callbacks.
Do NOT use: `function()`, arrow functions `=>`, or any JavaScript code.

### Color Formats
Use RGBA format for colors: `rgba(red, green, blue, alpha)`
- red, green, blue: 0-255
- alpha: 0-1 (transparency)

Common colors:
- Red: `rgba(255, 99, 132, 0.6)`
- Blue: `rgba(54, 162, 235, 0.6)`
- Yellow: `rgba(255, 206, 86, 0.6)`
- Green: `rgba(75, 192, 192, 0.6)`
- Purple: `rgba(153, 102, 255, 0.6)`
- Orange: `rgba(255, 159, 64, 0.6)`

### Best Practices
1. Always include a title in options.plugins.title
2. Use descriptive labels for datasets
3. Choose appropriate chart type for your data
4. Use consistent color schemes
5. Keep data readable - avoid too many data points in pie charts
