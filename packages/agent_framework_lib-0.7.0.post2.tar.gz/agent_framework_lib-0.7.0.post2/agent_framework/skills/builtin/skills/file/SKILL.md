---
name: file
description: "Create, list, and read files from storage"
display_name: "Gestion de fichiers"
metadata:
  config:
    emoji: "📁"
    trigger_patterns:
      - file
      - create file
      - list files
      - read file
      - save file
      - write file
      - text file
      - store file
    requires:
      bins:
        - uv
---

## File Operations

Perform file operations (create, list, read) by running standalone scripts via `shell_exec`.

---

### 1. Create a File

Use `create_file.py` to create a new text file on the filesystem.

#### Command

```bash
uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill file --filename "report.txt" --content "Hello, world!"
```

Content can also be piped via stdin (omit `--content`):

```bash
echo "Hello, world!" | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill file --filename "report.txt" --output-dir "/path/to/output"
```

#### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Target filename, e.g. `"report.txt"`, `"data.json"` |
| `--content` | No | Text content to write. If omitted, content is read from stdin |
| `--output-dir` | No | Directory where the file will be written (default: current directory) |

#### Output Format (stdout)

```json
{"status": "success", "file_id": "uuid", "download_url": "/files/uuid/download", "filename": "report.txt", "size_bytes": 1234, "mime_type": "text/plain", "local_cleaned": true}
```

Use the `download_url` to provide the user with a download link: `[report.txt](/files/uuid/download)`

#### Error Handling (stderr)

On failure, the script prints a JSON error to stderr and exits with a non-zero code:

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | Empty filename | `"Filename cannot be empty"` |
| 1 | Empty content | `"Content cannot be empty"` |
| 1 | No content provided (no `--content` and empty stdin) | `"No content provided (pass --content or pipe via stdin)"` |
| 2 | Missing required arguments | argparse usage message |

---

### 2. List Files in a Directory

Use `list_files.py` to list all files and directories in a given path.

#### Command

```bash
uv run python -m agent_framework.skills.builtin.skills.file.list_files --directory "/path/to/folder"
```

#### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--directory` | No | Directory to list files from (default: current directory) |

#### Output Format (stdout)

```json
{
  "status": "success",
  "results": [
    {"name": "report.txt", "path": "/absolute/path/report.txt", "size": 1234, "is_directory": false},
    {"name": "data", "path": "/absolute/path/data", "size": 0, "is_directory": true}
  ]
}
```

Each entry in `results` contains:

| Field | Type | Description |
|-------|------|-------------|
| `name` | string | File or directory name |
| `path` | string | Absolute path |
| `size` | int | File size in bytes (0 for directories) |
| `is_directory` | bool | `true` if the entry is a directory |

#### Error Handling (stderr)

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | Empty directory path | `"Directory path cannot be empty"` |
| 1 | Directory not found | `"Directory not found: /path/to/missing"` |
| 1 | Path is not a directory | `"Path is not a directory: /path/to/file"` |
| 2 | Invalid arguments | argparse usage message |

---

### 3. Read a File

Use `read_file.py` to read the contents of a file.

#### Command

```bash
uv run python -m agent_framework.skills.builtin.skills.file.read_file --path "/path/to/report.txt"
```

#### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--path` | Yes | Path to the file to read (absolute or relative to current directory) |

#### Output Format (stdout)

```json
{"status": "success", "results": "The file content as a string..."}
```

#### Error Handling (stderr)

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | Empty file path | `"File path cannot be empty"` |
| 1 | File not found | `"File not found: /path/to/missing.txt"` |
| 1 | Path is a directory | `"Path is a directory, not a file: /path/to/dir"` |
| 2 | Missing required arguments | argparse usage message |

---

### Workflow Example

1. **Create a file:**
   ```bash
   uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill file --filename "analysis.md" --content "# Analysis Report"
   ```

2. **List files to find it:**
   ```bash
   uv run python -m agent_framework.skills.builtin.skills.file.list_files --directory "."
   ```

3. **Read the file back:**
   ```bash
   uv run python -m agent_framework.skills.builtin.skills.file.read_file --path "analysis.md"
   ```

### Notes

- All scripts output JSON to stdout on success and JSON to stderr on failure.
- Supported file types for creation: any text-based format (.txt, .json, .md, .csv, etc.).
- Binary files cannot be read via `read_file.py` (UTF-8 encoding is assumed).
