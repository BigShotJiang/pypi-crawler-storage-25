#!/usr/bin/env python3
"""Standalone CLI script for reading file contents.

Reads a file from the filesystem and outputs its content
as a JSON result on stdout.
"""
import argparse
import json
import os
import sys


def read_file(path: str) -> str:
    """Read the contents of a file.

    Args:
        path: Path to the file to read.

    Returns:
        The file content as a string.

    Raises:
        ValueError: If path is empty.
        FileNotFoundError: If the file does not exist.
        IsADirectoryError: If the path points to a directory.
    """
    if not path or not path.strip():
        raise ValueError("File path cannot be empty")

    path = os.path.abspath(path)

    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")

    if os.path.isdir(path):
        raise IsADirectoryError(f"Path is a directory, not a file: {path}")

    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Read a file and output its content as JSON on stdout."
    )
    parser.add_argument(
        "--path",
        required=True,
        help="Path to the file to read (absolute or relative to current directory)",
    )
    args = parser.parse_args()

    try:
        content = read_file(args.path)
        print(json.dumps({"status": "success", "results": content}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
