#!/usr/bin/env python3
"""Standalone CLI script for listing files in a directory.

Lists files in a given directory and outputs a JSON result on stdout
containing file metadata (name, path, size, type).
"""
import argparse
import json
import os
import sys


def list_files(directory: str) -> list[dict]:
    """List all files and directories in the given directory.

    Args:
        directory: Path to the directory to list.

    Returns:
        List of dicts with file metadata (name, path, size, is_directory).

    Raises:
        ValueError: If directory path is empty.
        FileNotFoundError: If directory does not exist.
        NotADirectoryError: If path is not a directory.
    """
    if not directory or not directory.strip():
        raise ValueError("Directory path cannot be empty")

    directory = os.path.abspath(directory)

    if not os.path.exists(directory):
        raise FileNotFoundError(f"Directory not found: {directory}")

    if not os.path.isdir(directory):
        raise NotADirectoryError(f"Path is not a directory: {directory}")

    results = []
    for entry in sorted(os.listdir(directory)):
        entry_path = os.path.join(directory, entry)
        is_dir = os.path.isdir(entry_path)
        try:
            size = os.path.getsize(entry_path) if not is_dir else 0
        except OSError:
            size = 0

        results.append({
            "name": entry,
            "path": entry_path,
            "size": size,
            "is_directory": is_dir,
        })

    return results


def main() -> None:
    parser = argparse.ArgumentParser(
        description="List files in a directory and output JSON metadata."
    )
    parser.add_argument(
        "--directory",
        default=".",
        help="Directory to list files from (default: current directory)",
    )
    args = parser.parse_args()

    try:
        files = list_files(args.directory)
        print(json.dumps({"status": "success", "results": files}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
