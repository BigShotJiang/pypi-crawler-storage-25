#!/usr/bin/env python3
"""Standalone CLI script for creating text files.

Accepts a filename and content (via --content argument or stdin),
writes the file to the filesystem, and outputs a JSON result on stdout.
"""
import argparse
import json
import os
import sys


def create_file(filename: str, content: str, output_dir: str) -> str:
    """Create a text file with the given content.

    Args:
        filename: Target filename for the file.
        content: Text content to write.
        output_dir: Directory where the file will be written.

    Returns:
        Absolute path to the created file.

    Raises:
        ValueError: If filename is empty or content is empty.
    """
    if not filename or not filename.strip():
        raise ValueError("Filename cannot be empty")

    if not content:
        raise ValueError("Content cannot be empty")

    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, filename)
    filepath = os.path.abspath(filepath)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)

    return filepath


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create a text file with the given content."
    )
    parser.add_argument(
        "--filename",
        required=True,
        help="Target filename for the file (e.g. 'report.txt', 'data.json')",
    )
    parser.add_argument(
        "--content",
        default=None,
        help="Text content to write. If omitted, content is read from stdin.",
    )
    parser.add_argument(
        "--output-dir",
        default=".",
        help="Directory where the file will be written (default: current directory)",
    )
    args = parser.parse_args()

    try:
        if args.content is not None:
            content = args.content
        else:
            content = sys.stdin.read()

        if not content:
            raise ValueError("No content provided (pass --content or pipe via stdin)")
    except ValueError as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)

    try:
        filepath = create_file(args.filename, content, args.output_dir)
        print(json.dumps({"status": "success", "file": filepath}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
