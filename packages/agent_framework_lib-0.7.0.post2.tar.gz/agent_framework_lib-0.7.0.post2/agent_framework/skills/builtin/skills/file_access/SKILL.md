---
name: file_access
description: "Get file paths and URLs for embedding files in documents"
display_name: "Accès aux fichiers"
metadata:
  config:
    emoji: "🔗"
    trigger_patterns:
      - file path
      - file access
      - embed file
      - file url
      - embed image
      - image path
      - file reference
    requires:
      bins:
        - uv
---

## File Access Instructions

Resolve absolute file paths by running the `get_file_path.py` script via `shell_exec`.

### Usage

```bash
uv run python -m agent_framework.skills.builtin.skills.file_access.get_file_path --filename "report.xlsx" --directory "/path/to/folder"
```

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Name of the file to resolve, e.g. `"report.xlsx"` |
| `--directory` | No | Directory containing the file (default: current directory) |

### Example

Resolve the absolute path of a chart image in a specific directory:

```bash
uv run python -m agent_framework.skills.builtin.skills.file_access.get_file_path --filename "sales_chart.png" --directory "/tmp/output"
```

### Output Format (stdout)

On success, the script prints a JSON object to stdout:

```json
{"status": "success", "file": "/absolute/path/to/sales_chart.png"}
```

Parse this JSON to retrieve the absolute path of the resolved file.

### Error Handling (stderr)

On failure, the script prints a JSON error to stderr and exits with a non-zero code:

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | Empty filename | `"Filename cannot be empty"` |
| 1 | Directory not found | `"Directory not found: /nonexistent/path"` |
| 1 | Path is not a directory | `"Path is not a directory: /some/file.txt"` |
| 1 | File not found in directory | `"File not found: /path/to/dir/missing.png"` |
| 2 | Missing required arguments | argparse usage message |

### Common Use Cases

#### 1. Embedding Images in HTML

Resolve the path first, then use it in your markup:

```bash
uv run python -m agent_framework.skills.builtin.skills.file_access.get_file_path --filename "chart.png" --directory "/tmp/output"
```

```html
<img src="/absolute/path/to/chart.png" alt="Chart">
```

#### 2. Creating PDFs with Images

When generating PDFs that include stored images:
1. Create the image (chart, diagram, etc.) and note the output directory
2. Resolve the absolute path with `get_file_path.py`
3. Include the resolved path in your HTML for PDF generation

### Notes

- The resolved path is always absolute, regardless of whether `--directory` is relative or absolute.
- The file must exist on disk — the script verifies existence before returning.
