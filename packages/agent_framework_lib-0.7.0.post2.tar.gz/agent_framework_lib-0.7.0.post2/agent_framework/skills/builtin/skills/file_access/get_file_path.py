#!/usr/bin/env python3
"""Standalone CLI script for resolving file paths.

Accepts a filename and an optional directory, resolves the absolute
path of the file within that directory, and outputs a JSON result
on stdout.
"""
import argparse
import json
import os
import sys


def get_file_path(filename: str, directory: str) -> str:
    """Resolve the absolute path of a file within a directory.

    Args:
        filename: Name of the file to resolve.
        directory: Directory containing the file.

    Returns:
        Absolute path to the file.

    Raises:
        ValueError: If filename is empty.
        FileNotFoundError: If the directory does not exist.
        NotADirectoryError: If the directory path is not a directory.
        FileNotFoundError: If the file does not exist in the directory.
    """
    if not filename or not filename.strip():
        raise ValueError("Filename cannot be empty")

    directory = os.path.abspath(directory)

    if not os.path.exists(directory):
        raise FileNotFoundError(f"Directory not found: {directory}")

    if not os.path.isdir(directory):
        raise NotADirectoryError(f"Path is not a directory: {directory}")

    filepath = os.path.join(directory, filename)
    filepath = os.path.abspath(filepath)

    if not os.path.exists(filepath):
        raise FileNotFoundError(f"File not found: {filepath}")

    return filepath


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Resolve the absolute path of a file within a directory."
    )
    parser.add_argument(
        "--filename",
        required=True,
        help="Name of the file to resolve (e.g. 'report.xlsx', 'data.json')",
    )
    parser.add_argument(
        "--directory",
        default=".",
        help="Directory containing the file (default: current directory)",
    )
    args = parser.parse_args()

    try:
        filepath = get_file_path(args.filename, args.directory)
        print(json.dumps({"status": "success", "file": filepath}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
