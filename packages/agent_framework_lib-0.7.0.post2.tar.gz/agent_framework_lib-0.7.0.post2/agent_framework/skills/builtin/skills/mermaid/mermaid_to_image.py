#!/usr/bin/env python3
"""Standalone CLI script for rendering Mermaid diagrams as PNG images.

Reads Mermaid diagram code from stdin and uses Playwright to render
the diagram in a headless browser, then saves a screenshot as a PNG file.
Outputs a JSON result on stdout.
"""
import argparse
import json
import os
import sys

# Mermaid CDN URL (ESM module for v10+)
MERMAID_CDN = "https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs"
VALID_THEMES = ("default", "dark", "forest", "neutral")
DEVICE_SCALE = 2
VIEWPORT_SIZE = 3000
RENDER_WAIT_MS = 1000
SVG_TIMEOUT_MS = 5000
MIN_WIDTH = 1200
MIN_HEIGHT = 800


def _build_html(mermaid_code: str, theme: str, background_color: str = "white") -> str:
    """Build an HTML page embedding Mermaid.js with the given diagram code.

    Args:
        mermaid_code: Raw Mermaid diagram code.
        theme: Mermaid theme name (default, dark, forest, neutral).
        background_color: CSS background color for the page.

    Returns:
        Complete HTML string ready for Playwright rendering.
    """
    return f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <script type="module">
        import mermaid from '{MERMAID_CDN}';
        mermaid.initialize({{
            startOnLoad: true,
            theme: '{theme}',
            securityLevel: 'loose'
        }});
    </script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ margin: 0; padding: 20px; background-color: {background_color}; }}
        #diagram {{ background-color: {background_color}; display: inline-block; }}
    </style>
</head>
<body>
    <div id="diagram" class="mermaid">
{mermaid_code}
    </div>
</body>
</html>"""


def _clean_mermaid_code(raw_code: str) -> str:
    """Strip markdown code fences from Mermaid code if present.

    Args:
        raw_code: Raw Mermaid code, possibly wrapped in code fences.

    Returns:
        Cleaned Mermaid code without code fences.
    """
    code = raw_code.strip()
    if code.startswith("```mermaid"):
        code = code[len("```mermaid"):]
    elif code.startswith("```"):
        code = code[3:]
    if code.endswith("```"):
        code = code[:-3]
    return code.strip()


async def render_mermaid(
    mermaid_code: str,
    filename: str,
    output_dir: str,
    theme: str = "default",
) -> str:
    """Render a Mermaid diagram as a PNG image using Playwright.

    Args:
        mermaid_code: Mermaid diagram code (without code fences).
        filename: Target filename for the PNG file.
        output_dir: Directory where the file will be written.
        theme: Mermaid theme (default, dark, forest, neutral).

    Returns:
        Absolute path to the created PNG file.

    Raises:
        ValueError: If filename is empty or mermaid_code is empty.
        ImportError: If playwright is not installed.
        RuntimeError: If browser rendering fails.
    """
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        raise ImportError(
            "Playwright is not installed. Install it with:\n"
            "  uv add playwright\n"
            "  playwright install chromium"
        )

    if not filename or not filename.strip():
        raise ValueError("Filename cannot be empty")

    if not mermaid_code or not mermaid_code.strip():
        raise ValueError("Mermaid code cannot be empty")

    clean_code = _clean_mermaid_code(mermaid_code)
    html_content = _build_html(clean_code, theme)

    async with async_playwright() as p:
        browser = await p.chromium.launch()
        try:
            page = await browser.new_page(
                viewport={"width": VIEWPORT_SIZE, "height": VIEWPORT_SIZE},
                device_scale_factor=DEVICE_SCALE,
            )
            await page.set_content(html_content)
            await page.wait_for_selector("#diagram svg", timeout=SVG_TIMEOUT_MS)
            await page.wait_for_timeout(RENDER_WAIT_MS)

            diagram_element = await page.query_selector("#diagram")
            if diagram_element:
                screenshot_bytes = await diagram_element.screenshot(type="png")
            else:
                screenshot_bytes = await page.screenshot(type="png")
        finally:
            await browser.close()

    # Scale up if needed to meet minimum dimensions
    screenshot_bytes = _ensure_minimum_size(screenshot_bytes)

    # Sanitize filename
    safe_filename = "".join(
        c for c in filename if c.isalnum() or c in (" ", "-", "_", ".")
    ).strip()
    safe_filename = safe_filename.replace(" ", "_")
    if not safe_filename.lower().endswith(".png"):
        safe_filename += ".png"

    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, safe_filename)
    filepath = os.path.abspath(filepath)

    with open(filepath, "wb") as f:
        f.write(screenshot_bytes)

    return filepath


def _ensure_minimum_size(screenshot_bytes: bytes) -> bytes:
    """Scale up the image if it's below minimum dimensions.

    Args:
        screenshot_bytes: Raw PNG bytes from the screenshot.

    Returns:
        PNG bytes, possibly resized to meet MIN_WIDTH/MIN_HEIGHT.
    """
    try:
        import io

        from PIL import Image

        img = Image.open(io.BytesIO(screenshot_bytes))
        w, h = img.size

        width_scale = MIN_WIDTH / w if w < MIN_WIDTH else 1.0
        height_scale = MIN_HEIGHT / h if h < MIN_HEIGHT else 1.0
        scale = max(width_scale, height_scale)

        if scale > 1.0:
            img = img.resize(
                (int(w * scale), int(h * scale)), Image.Resampling.LANCZOS
            )
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return buf.getvalue()
    except ImportError:
        pass

    return screenshot_bytes


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Render a Mermaid diagram as a PNG image. "
            "Reads the Mermaid diagram code from stdin."
        )
    )
    parser.add_argument(
        "--filename",
        required=True,
        help="Target filename for the PNG file (e.g. 'diagram.png')",
    )
    parser.add_argument(
        "--output-dir",
        default=".",
        help="Directory where the file will be written (default: current directory)",
    )
    parser.add_argument(
        "--theme",
        default="default",
        choices=VALID_THEMES,
        help="Mermaid theme (default: 'default'). Options: default, dark, forest, neutral",
    )
    args = parser.parse_args()

    try:
        raw = sys.stdin.read()
        if not raw.strip():
            raise ValueError("No Mermaid code provided on stdin")
    except ValueError as e:
        print(
            json.dumps({"status": "error", "message": str(e)}),
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        import asyncio

        filepath = asyncio.run(
            render_mermaid(raw, args.filename, args.output_dir, args.theme)
        )
        print(json.dumps({"status": "success", "file": filepath}))
    except Exception as e:
        print(
            json.dumps({"status": "error", "message": str(e)}),
            file=sys.stderr,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
