---
name: mermaid
description: "Display interactive Mermaid diagrams in chat OR save as PNG images. Use ```mermaid code blocks for display (default), mermaid_to_image.py script for files."
display_name: "Génération des diagrammes"
metadata:
  config:
    emoji: "🔀"
    trigger_patterns:
      - mermaid
      - diagram
      - flowchart
      - sequence
      - sequence diagram
      - class diagram
      - state diagram
      - er diagram
      - entity relationship
      - gantt
      - architecture
    requires:
      bins:
        - uv
---

## Mermaid Diagram Instructions

You have TWO ways to create diagrams:
1. **🖥️ Interactive Display** (DEFAULT) - Show diagram directly in chat using ```mermaid code block
2. **💾 Save as Image** - Create PNG file by running the `mermaid_to_image.py` script via `shell_exec`
3. You can do both.

### ⚡ Quick Decision Guide

```
User wants to see a diagram?
├── Just "show me" / "create" / "display" → Use Interactive Display (```mermaid)
├── "Save as image" / "download" / "PNG" → Use Save as Image script
├── "Put in PDF" / "embed in document" → Use Save as Image script
├── Not sure? → Default to Interactive Display
└── Everytime you create a chart you display it just don't do it if say otherwise
```

**DEFAULT BEHAVIOR**: Always use Interactive Display unless the user explicitly needs a file.

---

## 🖥️ Interactive Display (DEFAULT)

To display a diagram directly in the chat, use a fenced code block with the `mermaid` language identifier.
The frontend renders Mermaid diagrams automatically - no tool needed!

**Format:**
```mermaid
graph TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Process]
    B -->|No| D[End]
```

### Complete Interactive Display Examples

**Flowchart:**
```mermaid
graph TD
    A[Start] --> B{Is it working?}
    B -->|Yes| C[Great!]
    B -->|No| D[Debug]
    D --> B
    C --> E[End]
```

**Sequence Diagram:**
```mermaid
sequenceDiagram
    participant U as User
    participant S as Server
    participant D as Database
    U->>S: Request data
    S->>D: Query
    D-->>S: Results
    S-->>U: Response
```

**Class Diagram:**
```mermaid
classDiagram
    class Animal {
        +String name
        +int age
        +makeSound()
    }
    class Dog {
        +String breed
        +bark()
    }
    Animal <|-- Dog
```

---

## 💾 Save as Image (For PDFs/Downloads ONLY)

**⚠️ WARNING**: Only use the save-as-image script when the user explicitly needs a PNG file.
Do NOT use this script just to show a diagram - use Interactive Display instead!

**Use Save as Image ONLY for:**
- Creating a PDF document with embedded diagram
- User explicitly asks to "save", "download", or "export" the diagram
- Sharing the diagram externally (email, etc.)

### Usage

Pipe Mermaid diagram code to stdin and specify the target filename:

```bash
echo 'graph TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Process]
    B -->|No| D[End]' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill mermaid --filename "diagram.png" --output-dir "/path/to/output"
```

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Target filename for the PNG file, e.g. `"diagram.png"` |
| `--output-dir` | No | Directory where the file will be written (default: current directory) |
| `--theme` | No | Mermaid theme: `default`, `dark`, `forest`, `neutral` (default: `default`) |

### Stdin (Mermaid code)

Provide raw Mermaid diagram code on stdin. Code fences (` ```mermaid `) are automatically stripped if present.

### Example

To render a sequence diagram as a PNG image:

```bash
echo 'sequenceDiagram
    participant U as User
    participant S as Server
    U->>S: Request data
    S-->>U: Response' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill mermaid --filename "sequence.png" --theme "forest"
```

### Output Format (stdout)

On success, the script prints a JSON object to stdout with the download URL:

```json
{"status": "success", "file_id": "uuid", "download_url": "/files/uuid/download", "filename": "diagram.png", "size_bytes": 1234, "mime_type": "image/png", "local_cleaned": true}
```

Use the `download_url` to provide the user with a download link: `[diagram.png](/files/uuid/download)`

### Error Handling (stderr)

On failure, the script prints a JSON error to stderr and exits with a non-zero code:

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | No Mermaid code provided on stdin | `"No Mermaid code provided on stdin"` |
| 1 | Empty Mermaid code | `"Mermaid code cannot be empty"` |
| 1 | Empty filename | `"Filename cannot be empty"` |
| 1 | Missing dependency | `"Playwright is not installed. Install it with: uv add playwright"` |
| 1 | Browser rendering failure | `"Timeout ..."` or Playwright error message |
| 2 | Missing required arguments | argparse usage message |

### Using Saved Diagrams in PDFs

After saving a diagram, parse the JSON output to get the file path. To embed in a PDF, use the path with the `create_pdf.py` script.

---

## Diagram Syntax Reference

### Supported Diagram Types
- Flowcharts (`graph` or `flowchart`)
- Sequence diagrams (`sequenceDiagram`)
- Class diagrams (`classDiagram`)
- State diagrams (`stateDiagram-v2`)
- Entity Relationship diagrams (`erDiagram`)
- Gantt charts (`gantt`)
- Pie charts (`pie`)
- User Journey diagrams (`journey`)

### Flowchart Syntax

Direction options:
- `TD` or `TB` - Top to bottom
- `BT` - Bottom to top
- `LR` - Left to right
- `RL` - Right to left

Node shapes:
- `[text]` - Rectangle
- `(text)` - Rounded rectangle
- `{text}` - Diamond (decision)
- `([text])` - Stadium shape
- `[[text]]` - Subroutine
- `[(text)]` - Cylinder (database)
- `((text))` - Circle

### Sequence Diagram Arrow Types
- `->` - Solid line without arrow
- `-->` - Dotted line without arrow
- `->>` - Solid line with arrow
- `-->>` - Dotted line with arrow
- `-x` - Solid line with cross
- `--x` - Dotted line with cross

### Class Diagram Relationships
- `<|--` - Inheritance
- `*--` - Composition
- `o--` - Aggregation
- `-->` - Association
- `--` - Link (solid)
- `..>` - Dependency
- `..|>` - Realization

### State Diagram Syntax
```mermaid
stateDiagram-v2
    [*] --> Idle
    Idle --> Processing: Start
    Processing --> Complete: Success
    Processing --> Error: Failure
    Complete --> [*]
    Error --> Idle: Retry
```

### Entity Relationship Diagram
Cardinality:
- `||` - Exactly one
- `o|` - Zero or one
- `}|` - One or more
- `}o` - Zero or more

### Gantt Chart Syntax
```mermaid
gantt
    title Project Timeline
    dateFormat YYYY-MM-DD
    section Planning
    Research     :a1, 2024-01-01, 30d
    Design       :a2, after a1, 20d
```

### Pie Chart Syntax
```mermaid
pie title Distribution
    "Category A" : 45
    "Category B" : 30
    "Category C" : 25
```

### Best Practices
1. Keep diagrams simple and readable
2. Use meaningful node labels
3. Group related elements together
4. Use appropriate diagram type for your content
5. Add titles where supported
6. Use consistent naming conventions
