#!/usr/bin/env python3
"""Standalone CLI script for performing web searches using DuckDuckGo.

Accepts a search query and optional max results count, performs a web search
via the duckduckgo-search library, and outputs results as JSON on stdout.
"""
import argparse
import json
import sys


def web_search(query: str, max_results: int = 5) -> list[dict]:
    """Perform a web search using DuckDuckGo.

    Args:
        query: The search query string.
        max_results: Maximum number of results to return (capped at 10).

    Returns:
        List of result dicts with title, body, and href keys.

    Raises:
        ImportError: If the ddgs package is not installed.
        RuntimeError: If the search fails.
    """
    try:
        from ddgs import DDGS
    except ImportError:
        raise ImportError("ddgs is not installed. Install it with: uv add ddgs")

    num_results = min(max_results, 10)

    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=num_results))
    except Exception as exc:
        raise RuntimeError(f"DuckDuckGo search failed: {exc}") from exc

    return [
        {
            "title": r.get("title", ""),
            "body": r.get("body", ""),
            "href": r.get("href", ""),
        }
        for r in results
    ]


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Search the web using DuckDuckGo and output results as JSON."
    )
    parser.add_argument(
        "--query",
        required=True,
        help="The search query to look up",
    )
    parser.add_argument(
        "--max-results",
        type=int,
        default=5,
        help="Maximum number of search results to return (default: 5, max: 10)",
    )
    args = parser.parse_args()

    try:
        results = web_search(args.query, args.max_results)
        print(json.dumps({"status": "success", "results": results}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
