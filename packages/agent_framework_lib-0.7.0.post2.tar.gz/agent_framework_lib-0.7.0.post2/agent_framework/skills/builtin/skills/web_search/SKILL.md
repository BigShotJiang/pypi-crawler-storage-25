---
name: web_search
description: "Search the web and news using DuckDuckGo (no API key required)"
display_name: "Recherche sur Internet"
metadata:
  config:
    emoji: "🔍"
    trigger_patterns:
      - search
      - web search
      - news
      - lookup
      - find online
      - search the web
      - google
      - look up
      - current events
      - recent news
    requires:
      bins:
        - uv
---

## Web & News Search

Search the web and recent news using DuckDuckGo via standalone scripts executed through `shell_exec`. No API key is required.

### Web Search

Run the `web_search.py` script to find general information from the internet.

#### Command

```bash
uv run python -m agent_framework.skills.builtin.skills.web_search.web_search --query "Python async programming best practices"
```

#### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--query` | Yes | The search query to look up |
| `--max-results` | No | Maximum number of results to return (default: 5, max: 10) |

#### Example

```bash
uv run python -m agent_framework.skills.builtin.skills.web_search.web_search --query "latest AI developments 2024" --max-results 10
```

#### Output Format (stdout)

On success, the script prints a JSON object to stdout:

```json
{"status": "success", "results": [{"title": "...", "body": "...", "href": "https://..."}]}
```

Each result object contains:

| Field | Type | Description |
|-------|------|-------------|
| `title` | string | Title of the search result |
| `body` | string | Snippet or summary of the result |
| `href` | string | URL of the result page |


### News Search

Run the `web_news_search.py` script to find recent news articles on a topic.

#### Command

```bash
uv run python -m agent_framework.skills.builtin.skills.web_search.web_news_search --query "artificial intelligence regulations"
```

#### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--query` | Yes | The news topic to search for |
| `--max-results` | No | Maximum number of news results to return (default: 5, max: 10) |

#### Example

```bash
uv run python -m agent_framework.skills.builtin.skills.web_search.web_news_search --query "tech industry layoffs" --max-results 8
```

#### Output Format (stdout)

On success, the script prints a JSON object to stdout:

```json
{"status": "success", "results": [{"title": "...", "body": "...", "url": "https://...", "date": "...", "source": "..."}]}
```

Each result object contains:

| Field | Type | Description |
|-------|------|-------------|
| `title` | string | Headline of the news article |
| `body` | string | Summary or excerpt of the article |
| `url` | string | URL of the news article |
| `date` | string | Publication date |
| `source` | string | Name of the news source |

### Error Handling (stderr)

Both scripts share the same error format. On failure, a JSON error is printed to stderr and the process exits with a non-zero code:

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | Search engine failure | `"DuckDuckGo search failed: ..."` |
| 1 | Missing dependency | `"ddgs is not installed. Install it with: uv add ddgs"` |
| 2 | Missing required arguments | argparse usage message |

### Best Practices

1. Use specific search terms for better results.
2. For exact phrases, include them in your query string.
3. Combine multiple relevant keywords.
4. News results include publication dates — verify recency.
5. Cross-reference important information from multiple sources.

### When to Use Each Script

- **web_search.py**: General information, tutorials, documentation, how-to guides.
- **web_news_search.py**: Current events, recent announcements, breaking news, industry updates.

### Notes

- Results are capped at 10 per search.
- Some websites may block scraping.
- News results depend on DuckDuckGo's news index.
- Requires `ddgs` to be installed (`uv add ddgs`).
