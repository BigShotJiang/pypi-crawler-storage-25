#!/usr/bin/env python3
"""Standalone CLI script for creating .drawio diagram files.

Accepts a filename and XML content (via --xml argument or stdin),
writes the .drawio file to the filesystem, and outputs a JSON result on stdout.
"""
import argparse
import json
import os
import sys


def create_drawio(filename: str, xml_content: str, output_dir: str) -> str:
    """Create a .drawio file with the given XML content.

    Args:
        filename: Target filename for the .drawio file.
        xml_content: XML content to write.
        output_dir: Directory where the file will be written.

    Returns:
        Absolute path to the created file.

    Raises:
        ValueError: If filename is empty or xml_content is empty.
    """
    if not filename or not filename.strip():
        raise ValueError("Filename cannot be empty")

    if not xml_content or not xml_content.strip():
        raise ValueError("XML content cannot be empty")

    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, filename)
    filepath = os.path.abspath(filepath)

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(xml_content)

    return filepath


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create a .drawio diagram file from XML content."
    )
    parser.add_argument(
        "--filename",
        required=True,
        help="Target filename for the .drawio file (e.g. 'diagram.drawio')",
    )
    parser.add_argument(
        "--xml",
        default=None,
        help="XML content to write. If omitted, content is read from stdin.",
    )
    parser.add_argument(
        "--output-dir",
        default=".",
        help="Directory where the file will be written (default: current directory)",
    )
    args = parser.parse_args()

    try:
        if args.xml is not None:
            xml_content = args.xml
        else:
            xml_content = sys.stdin.read()

        if not xml_content or not xml_content.strip():
            raise ValueError("No XML content provided (pass --xml or pipe via stdin)")
    except ValueError as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)

    try:
        filepath = create_drawio(args.filename, xml_content, args.output_dir)
        print(json.dumps({"status": "success", "file": filepath}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
