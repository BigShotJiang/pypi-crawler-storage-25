---
name: drawio
description: "Generate .drawio diagram files for flowcharts, architecture diagrams, and more."
display_name: "Génération de diagrammes Draw.io"
metadata:
  config:
    emoji: "🗂️"
    trigger_patterns:
      - drawio
      - diagram
      - flowchart
      - architecture diagram
      - draw.io
    requires:
      bins:
        - uv
---

## Draw.io Diagram Generation

Generate `.drawio` diagram files by running the `create_drawio.py` script via `shell_exec`.

### Usage

Pass Draw.io XML content via the `--xml` argument or pipe it through stdin:

```bash
uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill drawio --filename "architecture.drawio" --xml "<mxfile>...</mxfile>" --output-dir "/path/to/output"
```

Or pipe XML from stdin:

```bash
echo '<mxfile>...</mxfile>' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill drawio --filename "architecture.drawio" --output-dir "/path/to/output"
```

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Target filename, e.g. `"architecture.drawio"` |
| `--xml` | No | XML content to write. If omitted, content is read from stdin |
| `--output-dir` | No | Directory where the file will be written (default: current directory) |

### Example — Flowchart

```bash
uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill drawio --filename "order_flow.drawio" --xml '<mxfile host="app.diagrams.net">
  <diagram name="Order Processing Flow">
    <mxGraphModel>
      <root>
        <mxCell id="0"/>
        <mxCell id="1" parent="0"/>
        <mxCell id="start" value="Start" style="ellipse;" vertex="1" parent="1">
          <mxGeometry x="100" y="50" width="80" height="40" as="geometry"/>
        </mxCell>
        <mxCell id="check" value="Check Stock?" style="rhombus;" vertex="1" parent="1">
          <mxGeometry x="80" y="130" width="120" height="60" as="geometry"/>
        </mxCell>
        <mxCell id="ship" value="Ship Order" style="rounded=0;" vertex="1" parent="1">
          <mxGeometry x="30" y="240" width="100" height="40" as="geometry"/>
        </mxCell>
        <mxCell id="notify" value="Notify Customer" style="rounded=1;" vertex="1" parent="1">
          <mxGeometry x="180" y="240" width="120" height="40" as="geometry"/>
        </mxCell>
        <mxCell id="end" value="End" style="ellipse;" vertex="1" parent="1">
          <mxGeometry x="100" y="330" width="80" height="40" as="geometry"/>
        </mxCell>
        <mxCell id="e1" source="start" target="check" edge="1" parent="1"/>
        <mxCell id="e2" value="In Stock" source="check" target="ship" edge="1" parent="1"/>
        <mxCell id="e3" value="Out of Stock" source="check" target="notify" edge="1" parent="1"/>
        <mxCell id="e4" source="ship" target="end" edge="1" parent="1"/>
        <mxCell id="e5" source="notify" target="end" edge="1" parent="1"/>
      </root>
    </mxGraphModel>
  </diagram>
</mxfile>'
```

### Output Format (stdout)

On success, the script prints a JSON object to stdout with the download URL:

```json
{"status": "success", "file_id": "uuid", "download_url": "/files/uuid/download", "filename": "order_flow.drawio", "size_bytes": 1234, "mime_type": "application/xml", "local_cleaned": true}
```

Use the `download_url` to provide the user with a download link: `[order_flow.drawio](/files/uuid/download)`

### Error Handling (stderr)

On failure, the script prints a JSON error to stderr and exits with a non-zero code:

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | Empty filename | `"Filename cannot be empty"` |
| 1 | Empty XML content | `"XML content cannot be empty"` |
| 1 | No XML provided (no `--xml` and empty stdin) | `"No XML content provided (pass --xml or pipe via stdin)"` |
| 2 | Missing required arguments | argparse usage message |

### Notes

- The script writes raw XML content to the `.drawio` file — you must provide valid Draw.io XML.
- Generated files open directly in Draw.io (https://app.diagrams.net) or diagrams.net.
- For large diagrams, prefer piping XML via stdin rather than using the `--xml` argument.
