---
name: table
description: "Display interactive tables in chat OR save as PNG images. Use ```tabledata code blocks for display (default), table_to_image.py script for files."
display_name: "Génération de tableaux"
metadata:
  config:
    emoji: "📋"
    trigger_patterns:
      - table
      - tabledata
      - grid
      - data table
      - spreadsheet
      - tabular
      - rows and columns
    requires:
      bins:
        - uv
---

## Table Generation Instructions

You have TWO ways to create tables:
1. **🖥️ Interactive Display** (DEFAULT) - Show table directly in chat using ```tabledata code block
2. **💾 Save as Image** - Create PNG file by running the `table_to_image.py` script via `shell_exec`
3. You can do both.

### ⚡ Quick Decision Guide

```
User wants to see a table?
├── Just "show me" / "create" / "display" → Use Interactive Display (```tabledata)
├── "Save as image" / "download" / "PNG" → Use Save as Image script
├── "Put in PDF" / "embed in document" → Use Save as Image script
├── Not sure? → Default to Interactive Display
└── Everytime you create a chart you display it just don't do it if say otherwise
```

**DEFAULT BEHAVIOR**: Always use Interactive Display unless the user explicitly needs a file.

---

## 🖥️ Interactive Display (DEFAULT)

To display a table directly in the chat, use a fenced code block with the `tabledata` language identifier.
The frontend renders tables automatically with professional styling - no tool needed!

**Format:**
```tabledata
{
  "caption": "Table Title",
  "headers": ["Column 1", "Column 2", "Column 3"],
  "rows": [
    ["Row 1 Cell 1", "Row 1 Cell 2", "Row 1 Cell 3"],
    ["Row 2 Cell 1", "Row 2 Cell 2", "Row 2 Cell 3"]
  ]
}
```

### Complete Interactive Display Examples

**Employee Directory:**
```tabledata
{
  "caption": "Employee Directory",
  "headers": ["Name", "Department", "Email"],
  "rows": [
    ["Alice Smith", "Engineering", "alice@example.com"],
    ["Bob Johnson", "Marketing", "bob@example.com"],
    ["Carol Williams", "Sales", "carol@example.com"]
  ]
}
```

**Sales Report:**
```tabledata
{
  "caption": "Quarterly Sales Report",
  "headers": ["Product", "Q1", "Q2", "Q3", "Q4", "Total"],
  "rows": [
    ["Widget A", "1200", "1350", "1100", "1500", "5150"],
    ["Widget B", "800", "950", "1200", "1100", "4050"],
    ["Widget C", "500", "600", "700", "800", "2600"]
  ]
}
```

**Feature Comparison:**
```tabledata
{
  "caption": "Feature Comparison",
  "headers": ["Feature", "Basic Plan", "Pro Plan", "Enterprise"],
  "rows": [
    ["Storage", "5 GB", "50 GB", "Unlimited"],
    ["Users", "1", "10", "Unlimited"],
    ["Support", "Email", "Priority", "24/7 Dedicated"],
    ["Price", "$9/mo", "$29/mo", "Custom"]
  ]
}
```

---

## 💾 Save as Image (For PDFs/Downloads ONLY)

**⚠️ WARNING**: Only use the save-as-image script when the user explicitly needs a PNG file.
Do NOT use this script just to show a table - use Interactive Display instead!

**Use Save as Image ONLY for:**
- Creating a PDF document with embedded table
- User explicitly asks to "save", "download", or "export" the table
- Sharing the table externally (email, etc.)

### Usage

Pipe a JSON object with `headers` and `rows` to stdin and specify the target filename:

```bash
echo '{"headers": ["Name", "Department", "Email"], "rows": [["Alice Smith", "Engineering", "alice@example.com"], ["Bob Johnson", "Marketing", "bob@example.com"]]}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill table --filename "employees.png" --output-dir "/path/to/output"
```

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Target filename for the PNG file, e.g. `"report_table.png"` |
| `--output-dir` | No | Directory where the file will be written (default: current directory) |
| `--theme` | No | Color theme: `default`, `dark`, `blue`, `green`, `minimal` (default: `default`) |
| `--font-size` | No | Base font size in pixels (default: `14`) |

### Stdin (JSON)

Provide a JSON object on stdin with the following fields:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `headers` | list[string] | Yes | Column header labels |
| `rows` | list[list[string]] | Yes | Data rows — each row is a list of cell values |
| `caption` | string | No | Title displayed above the table |

### Example

To render a sales report table as a PNG image:

```bash
echo '{
  "caption": "Quarterly Sales Report",
  "headers": ["Product", "Q1", "Q2", "Q3", "Q4", "Total"],
  "rows": [
    ["Widget A", "1200", "1350", "1100", "1500", "5150"],
    ["Widget B", "800", "950", "1200", "1100", "4050"],
    ["Widget C", "500", "600", "700", "800", "2600"]
  ]
}' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill table --filename "sales_table.png" --theme "blue"
```

### Output Format (stdout)

On success, the script prints a JSON object to stdout with the download URL:

```json
{"status": "success", "file_id": "uuid", "download_url": "/files/uuid/download", "filename": "sales_table.png", "size_bytes": 1234, "mime_type": "image/png", "local_cleaned": true}
```

Use the `download_url` to provide the user with a download link: `[sales_table.png](/files/uuid/download)`

### Error Handling (stderr)

On failure, the script prints a JSON error to stderr and exits with a non-zero code:

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | No JSON data provided on stdin | `"No JSON data provided on stdin"` |
| 1 | Invalid JSON on stdin | `"Invalid JSON on stdin: ..."` |
| 1 | Stdin JSON is not an object | `"Stdin JSON must be an object with 'headers' and 'rows' keys"` |
| 1 | Missing `headers` field | `"table_data must include a 'headers' field"` |
| 1 | Missing `rows` field | `"table_data must include a 'rows' field"` |
| 1 | Empty headers | `"headers cannot be empty"` |
| 1 | Empty rows | `"rows cannot be empty"` |
| 1 | Empty filename | `"Filename cannot be empty"` |
| 1 | Missing dependency | `"Playwright is not installed. Install it with: uv add playwright"` |
| 2 | Missing required arguments | argparse usage message |

### Available Themes

1. **default** — Clean white background with gray headers
2. **dark** — Dark background with light text
3. **blue** — Blue header with light blue alternating rows
4. **green** — Green header with light green alternating rows
5. **minimal** — Simple white design with subtle borders

### Using Saved Tables in PDFs

After saving a table, parse the JSON output to get the file path. To embed in a PDF, use the path with the `create_pdf.py` script.

---

## Table Data Reference

### JSON Structure
- `caption` (optional): Title displayed above the table
- `headers` (required): Array of column header strings
- `rows` (required): Array of row arrays, each containing cell values

### Best Practices
1. **Keep tables readable**: Limit columns to 6-8 for best readability
2. **Use clear headers**: Make column headers descriptive but concise
3. **Consistent data types**: Keep data in each column consistent
4. **Add captions**: Use captions to provide context
5. **Use consistent units**: In numeric columns, use consistent units

### Formatting Tips
- Numbers are displayed as-is (no automatic formatting)
- Long text will wrap within cells
- Empty cells should be represented as empty strings ""
- All cell values should be strings in the JSON
