#!/usr/bin/env python3
"""Standalone CLI script for rendering HTML tables as PNG images.

Reads JSON table data from stdin (with "headers" and "rows" keys) and uses
Playwright to render a styled HTML table in a headless browser, then saves
a screenshot as a PNG file. Outputs a JSON result on stdout.
"""
import argparse
import json
import os
import sys

# Rendering parameters
DEVICE_SCALE = 2
VIEWPORT_SIZE = 3000
RENDER_WAIT_MS = 500
MIN_WIDTH = 800
MIN_HEIGHT = 400

# Theme color palettes
THEMES = {
    "default": {
        "bg": "#ffffff",
        "header_bg": "#f8f9fa",
        "header_color": "#212529",
        "row_bg": "#ffffff",
        "row_alt_bg": "#f8f9fa",
        "border": "#dee2e6",
        "text": "#212529",
    },
    "dark": {
        "bg": "#1a1a1a",
        "header_bg": "#2d2d2d",
        "header_color": "#ffffff",
        "row_bg": "#1a1a1a",
        "row_alt_bg": "#252525",
        "border": "#404040",
        "text": "#e0e0e0",
    },
    "blue": {
        "bg": "#ffffff",
        "header_bg": "#0d6efd",
        "header_color": "#ffffff",
        "row_bg": "#ffffff",
        "row_alt_bg": "#e7f1ff",
        "border": "#0d6efd",
        "text": "#212529",
    },
    "green": {
        "bg": "#ffffff",
        "header_bg": "#198754",
        "header_color": "#ffffff",
        "row_bg": "#ffffff",
        "row_alt_bg": "#d1e7dd",
        "border": "#198754",
        "text": "#212529",
    },
    "minimal": {
        "bg": "#ffffff",
        "header_bg": "#ffffff",
        "header_color": "#212529",
        "row_bg": "#ffffff",
        "row_alt_bg": "#ffffff",
        "border": "#e0e0e0",
        "text": "#212529",
    },
}

VALID_THEMES = tuple(THEMES.keys())


def _escape_html(text: str) -> str:
    """Escape HTML special characters in text.

    Args:
        text: Raw text to escape.

    Returns:
        HTML-safe string.
    """
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _build_html(table_data: dict, theme: str = "default", font_size: int = 14) -> str:
    """Build an HTML page with a styled table from the given data.

    Args:
        table_data: Dictionary with "headers" (list of strings) and "rows"
                    (list of lists). Optional "caption" for a table title.
        theme: Color theme name.
        font_size: Base font size in pixels.

    Returns:
        Complete HTML string ready for Playwright rendering.
    """
    colors = THEMES.get(theme, THEMES["default"])
    headers = table_data["headers"]
    rows = table_data["rows"]
    caption = table_data.get("caption", "")

    parts = ["<table>"]
    if caption:
        parts.append(f"<caption>{_escape_html(caption)}</caption>")

    parts.append("<thead><tr>")
    for header in headers:
        parts.append(f"<th>{_escape_html(header)}</th>")
    parts.append("</tr></thead>")

    parts.append("<tbody>")
    for row in rows:
        parts.append("<tr>")
        for cell in row:
            parts.append(f"<td>{_escape_html(cell)}</td>")
        parts.append("</tr>")
    parts.append("</tbody></table>")

    table_html = "\n".join(parts)

    return f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            margin: 0;
            padding: 30px;
            background-color: {colors['bg']};
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
                         'Helvetica Neue', Arial, sans-serif;
        }}
        #tableContainer {{
            display: inline-block;
            background-color: {colors['bg']};
        }}
        table {{
            border-collapse: collapse;
            font-size: {font_size}px;
            color: {colors['text']};
        }}
        caption {{
            font-size: {font_size + 4}px;
            font-weight: bold;
            margin-bottom: 15px;
            text-align: left;
            color: {colors['header_color']};
        }}
        th {{
            background-color: {colors['header_bg']};
            color: {colors['header_color']};
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            border: 1px solid {colors['border']};
            white-space: nowrap;
        }}
        td {{
            padding: 10px 15px;
            border: 1px solid {colors['border']};
            white-space: nowrap;
        }}
        tbody tr:nth-child(even) {{
            background-color: {colors['row_alt_bg']};
        }}
        tbody tr:nth-child(odd) {{
            background-color: {colors['row_bg']};
        }}
    </style>
</head>
<body>
    <div id="tableContainer">
        {table_html}
    </div>
</body>
</html>"""


async def render_table(
    table_data: dict,
    filename: str,
    output_dir: str,
    theme: str = "default",
    font_size: int = 14,
) -> str:
    """Render table data as a PNG image using Playwright.

    Args:
        table_data: Dictionary with "headers" (list of strings) and "rows"
                    (list of lists). Optional "caption" for a table title.
        filename: Target filename for the PNG file.
        output_dir: Directory where the file will be written.
        theme: Color theme name (default, dark, blue, green, minimal).
        font_size: Base font size in pixels.

    Returns:
        Absolute path to the created PNG file.

    Raises:
        ValueError: If filename is empty or table_data is missing required fields.
        ImportError: If playwright is not installed.
        RuntimeError: If browser rendering fails.
    """
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        raise ImportError(
            "Playwright is not installed. Install it with:\n"
            "  uv add playwright\n"
            "  playwright install chromium"
        )

    if not filename or not filename.strip():
        raise ValueError("Filename cannot be empty")

    if "headers" not in table_data:
        raise ValueError("table_data must include a 'headers' field")
    if "rows" not in table_data:
        raise ValueError("table_data must include a 'rows' field")
    if not table_data["headers"]:
        raise ValueError("headers cannot be empty")
    if not table_data["rows"]:
        raise ValueError("rows cannot be empty")

    html_content = _build_html(table_data, theme, font_size)

    async with async_playwright() as p:
        browser = await p.chromium.launch()
        try:
            page = await browser.new_page(
                viewport={"width": VIEWPORT_SIZE, "height": VIEWPORT_SIZE},
                device_scale_factor=DEVICE_SCALE,
            )
            await page.set_content(html_content)
            await page.wait_for_timeout(RENDER_WAIT_MS)

            table_element = await page.query_selector("#tableContainer")
            if table_element:
                screenshot_bytes = await table_element.screenshot(type="png")
            else:
                screenshot_bytes = await page.screenshot(type="png")
        finally:
            await browser.close()

    screenshot_bytes = _ensure_minimum_size(screenshot_bytes)

    # Sanitize filename
    safe_filename = "".join(
        c for c in filename if c.isalnum() or c in (" ", "-", "_", ".")
    ).strip()
    safe_filename = safe_filename.replace(" ", "_")
    if not safe_filename.lower().endswith(".png"):
        safe_filename += ".png"

    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, safe_filename)
    filepath = os.path.abspath(filepath)

    with open(filepath, "wb") as f:
        f.write(screenshot_bytes)

    return filepath


def _ensure_minimum_size(screenshot_bytes: bytes) -> bytes:
    """Scale up the image if it's below minimum dimensions.

    Args:
        screenshot_bytes: Raw PNG bytes from the screenshot.

    Returns:
        PNG bytes, possibly resized to meet MIN_WIDTH/MIN_HEIGHT.
    """
    try:
        import io

        from PIL import Image

        img = Image.open(io.BytesIO(screenshot_bytes))
        w, h = img.size

        width_scale = MIN_WIDTH / w if w < MIN_WIDTH else 1.0
        height_scale = MIN_HEIGHT / h if h < MIN_HEIGHT else 1.0
        scale = max(width_scale, height_scale)

        if scale > 1.0:
            img = img.resize(
                (int(w * scale), int(h * scale)), Image.Resampling.LANCZOS
            )
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            return buf.getvalue()
    except ImportError:
        pass

    return screenshot_bytes


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Render an HTML table as a PNG image. "
            "Reads JSON table data from stdin with 'headers' and 'rows' keys."
        )
    )
    parser.add_argument(
        "--filename",
        required=True,
        help="Target filename for the PNG file (e.g. 'report_table.png')",
    )
    parser.add_argument(
        "--output-dir",
        default=".",
        help="Directory where the file will be written (default: current directory)",
    )
    parser.add_argument(
        "--theme",
        default="default",
        choices=VALID_THEMES,
        help="Color theme (default: 'default'). Options: default, dark, blue, green, minimal",
    )
    parser.add_argument(
        "--font-size",
        type=int,
        default=14,
        help="Base font size in pixels (default: 14)",
    )
    args = parser.parse_args()

    try:
        raw = sys.stdin.read()
        if not raw.strip():
            raise ValueError("No JSON data provided on stdin")
        table_data = json.loads(raw)
        if not isinstance(table_data, dict):
            raise ValueError("Stdin JSON must be an object with 'headers' and 'rows' keys")
    except json.JSONDecodeError as e:
        print(
            json.dumps({"status": "error", "message": f"Invalid JSON on stdin: {e}"}),
            file=sys.stderr,
        )
        sys.exit(1)
    except ValueError as e:
        print(
            json.dumps({"status": "error", "message": str(e)}),
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        import asyncio

        filepath = asyncio.run(
            render_table(table_data, args.filename, args.output_dir, args.theme, args.font_size)
        )
        print(json.dumps({"status": "success", "file": filepath}))
    except Exception as e:
        print(
            json.dumps({"status": "error", "message": str(e)}),
            file=sys.stderr,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
