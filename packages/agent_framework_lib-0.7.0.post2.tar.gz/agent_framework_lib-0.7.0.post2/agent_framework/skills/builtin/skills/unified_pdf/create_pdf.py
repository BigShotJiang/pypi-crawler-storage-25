#!/usr/bin/env python3
"""Standalone CLI script for generating PDF documents from HTML content.

Reads HTML content from stdin and uses Playwright to render the HTML
in a headless browser, then generates a PDF file.
Outputs a JSON result on stdout.
"""
import argparse
import json
import os
import sys

# Default PDF rendering parameters
VIEWPORT_WIDTH = 1280
VIEWPORT_HEIGHT = 1024


async def render_pdf(html_content: str, filename: str, output_dir: str) -> str:
    """Render HTML content as a PDF document using Playwright.

    Args:
        html_content: HTML string to render. Can be a complete HTML document
                      or a fragment (will be wrapped automatically).
        filename: Target filename for the PDF file.
        output_dir: Directory where the file will be written.

    Returns:
        Absolute path to the created PDF file.

    Raises:
        ValueError: If filename is empty or html_content is empty.
        ImportError: If playwright is not installed.
        RuntimeError: If browser rendering fails.
    """
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        raise ImportError(
            "Playwright is not installed. Install it with:\n"
            "  uv add playwright\n"
            "  playwright install chromium"
        )

    if not filename or not filename.strip():
        raise ValueError("Filename cannot be empty")

    if not html_content or not html_content.strip():
        raise ValueError("HTML content cannot be empty")

    # Wrap fragment in a basic HTML document if needed
    if not _is_complete_html(html_content):
        html_content = _wrap_html_fragment(html_content)

    # Sanitize filename
    safe_filename = "".join(
        c for c in filename if c.isalnum() or c in (" ", "-", "_", ".")
    ).strip()
    safe_filename = safe_filename.replace(" ", "_")
    if not safe_filename.lower().endswith(".pdf"):
        safe_filename += ".pdf"

    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, safe_filename)
    filepath = os.path.abspath(filepath)

    async with async_playwright() as p:
        browser = await p.chromium.launch()
        try:
            page = await browser.new_page(
                viewport={"width": VIEWPORT_WIDTH, "height": VIEWPORT_HEIGHT},
            )
            await page.set_content(html_content, wait_until="networkidle")

            pdf_bytes = await page.pdf(
                format="A4",
                print_background=True,
                margin={
                    "top": "20mm",
                    "bottom": "20mm",
                    "left": "15mm",
                    "right": "15mm",
                },
            )
        finally:
            await browser.close()

    with open(filepath, "wb") as f:
        f.write(pdf_bytes)

    return filepath


def _is_complete_html(content: str) -> bool:
    """Check whether the content is a complete HTML document.

    Args:
        content: HTML string to check.

    Returns:
        True if the content contains <html or <!DOCTYPE tags.
    """
    lower = content.strip().lower()
    return lower.startswith("<!doctype") or "<html" in lower


def _wrap_html_fragment(fragment: str) -> str:
    """Wrap an HTML fragment in a minimal HTML document.

    Args:
        fragment: HTML fragment to wrap.

    Returns:
        Complete HTML document string.
    """
    return f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
                         "Helvetica Neue", Arial, sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
        }}
    </style>
</head>
<body>
{fragment}
</body>
</html>"""


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Generate a PDF document from HTML content. "
            "Reads the HTML from stdin and renders it using Playwright."
        )
    )
    parser.add_argument(
        "--filename",
        required=True,
        help="Target filename for the PDF file (e.g. 'report.pdf')",
    )
    parser.add_argument(
        "--output-dir",
        default=".",
        help="Directory where the file will be written (default: current directory)",
    )
    args = parser.parse_args()

    try:
        raw = sys.stdin.read()
        if not raw.strip():
            raise ValueError("No HTML content provided on stdin")
    except ValueError as e:
        print(
            json.dumps({"status": "error", "message": str(e)}),
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        import asyncio

        filepath = asyncio.run(render_pdf(raw, args.filename, args.output_dir))
        print(json.dumps({"status": "success", "file": filepath}))
    except Exception as e:
        print(
            json.dumps({"status": "error", "message": str(e)}),
            file=sys.stderr,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
