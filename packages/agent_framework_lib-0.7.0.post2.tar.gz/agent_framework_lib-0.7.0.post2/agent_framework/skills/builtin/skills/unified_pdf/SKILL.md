---
name: unified_pdf
description: "Create PDF documents from HTML content with automatic image embedding"
display_name: "Génération de PDF"
metadata:
  config:
    emoji: "📄"
    trigger_patterns:
      - pdf
      - document
      - report
      - create pdf
      - generate pdf
      - html to pdf
      - export pdf
      - pdf with images
      - report with charts
      - pdf with charts
      - embed images
      - pdf report
      - document with images
      - report with images
      - pdf with figures
    requires:
      bins:
        - uv
---

## PDF Document Generation

Generate PDF documents from HTML content by running the `create_pdf.py` script via `shell_exec`.

The script uses Playwright to render HTML in a headless Chromium browser and produce an A4 PDF. HTML fragments are automatically wrapped in a minimal document shell.

### Usage

Pipe HTML content to stdin and specify the target filename:

```bash
echo '<h1>Hello World</h1><p>This is a PDF.</p>' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill unified_pdf --filename "report.pdf" --output-dir "/path/to/output"
```

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Target filename, e.g. `"report.pdf"` |
| `--output-dir` | No | Directory where the file will be written (default: current directory) |

### Stdin (HTML)

Provide raw HTML content on stdin. This can be either:

- A **complete HTML document** (starts with `<!DOCTYPE` or contains `<html`): used as-is.
- An **HTML fragment** (anything else): automatically wrapped in a minimal HTML document with sensible defaults (sans-serif font, neutral colors, 1.6 line-height).

### Recommended HTML Structure

Wrap images in `<figure>` tags to keep image and caption together. Use `break-before` for major section page breaks:

```html
<div class="section">
    <h1>Report Title</h1>
    <p>Introduction paragraph...</p>
</div>

<div class="section break-before">
    <h2>1. First Section</h2>
    <p>Brief intro text...</p>
    <figure>
        <img src="data:image/png;base64,..." alt="Chart">
        <figcaption>Figure 1: Caption here</figcaption>
    </figure>
</div>
```

### Supported HTML Features

- Headers (`h1`–`h6`), paragraphs, text formatting (`strong`, `em`, `u`)
- Ordered and unordered lists
- Tables with headers
- Images (data URIs or accessible URLs)
- Figures with captions
- Blockquotes, code blocks (`pre`, `code`)
- Custom CSS classes (`break-before`, `section`)

### Example

Create a multi-section report:

```bash
echo '<div class="section">
  <h1>Quarterly Sales Report Q4 2024</h1>
  <p>This report presents the quarterly sales analysis.</p>
</div>
<div class="section break-before">
  <h2>1. Revenue Overview</h2>
  <p>Monthly revenue trends for Q4 2024.</p>
  <table>
    <tr><th>Month</th><th>Revenue</th></tr>
    <tr><td>October</td><td>$120K</td></tr>
    <tr><td>November</td><td>$135K</td></tr>
    <tr><td>December</td><td>$150K</td></tr>
  </table>
</div>
<div class="section break-before">
  <h2>2. Conclusions</h2>
  <ul>
    <li>Revenue increased 15% quarter-over-quarter</li>
    <li>Recommend expanding marketing in Southern region</li>
  </ul>
</div>' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill unified_pdf --filename "quarterly_report.pdf"
```

### Simple Example (No Images)

```bash
echo '<h1>Meeting Notes</h1>
<p><strong>Date:</strong> January 15, 2025</p>
<p><strong>Attendees:</strong> Alice, Bob, Charlie</p>
<h2>Action Items</h2>
<table>
  <tr><th>Task</th><th>Owner</th><th>Due Date</th></tr>
  <tr><td>Complete design review</td><td>Alice</td><td>Jan 20</td></tr>
  <tr><td>Update budget forecast</td><td>Bob</td><td>Jan 22</td></tr>
</table>' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill unified_pdf --filename "meeting_notes.pdf"
```

### Output Format (stdout)

On success, the script prints a JSON object to stdout with the download URL:

```json
{"status": "success", "file_id": "uuid", "download_url": "/files/uuid/download", "filename": "report.pdf", "size_bytes": 1234, "mime_type": "application/pdf", "local_cleaned": true}
```

Use the `download_url` to provide the user with a download link: `[report.pdf](/files/uuid/download)`

### Error Handling (stderr)

On failure, the script prints a JSON error to stderr and exits with a non-zero code:

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | Empty HTML content on stdin | `"No HTML content provided on stdin"` |
| 1 | Empty or invalid filename | `"Filename cannot be empty"` |
| 1 | Empty HTML content string | `"HTML content cannot be empty"` |
| 1 | Playwright not installed | `"Playwright is not installed. Install it with: uv add playwright"` |
| 1 | Browser rendering failure | `"RuntimeError: ..."` |
| 2 | Missing required arguments | argparse usage message |

### Page Layout Notes

- Default page size is A4
- Margins: 20 mm top/bottom, 15 mm left/right
- Long content spans multiple pages automatically
- Tables and code blocks handle page breaks gracefully

### Notes

- Filenames are sanitized: only alphanumeric characters, spaces, hyphens, underscores, and dots are kept. Spaces are replaced with underscores. A `.pdf` extension is appended if missing.
- Requires Playwright and Chromium (`uv add playwright && playwright install chromium`).
- For embedding charts, generate chart images first (e.g. via the chart skill), then include them as base64 data URIs in the HTML.
