---
name: excel
description: "Generate .xlsx Excel spreadsheet files with multiple sheets and formatting."
display_name: "Génération de fichiers Excel"
metadata:
  config:
    emoji: "📊"
    trigger_patterns:
      - excel
      - spreadsheet
      - xlsx
      - tableau
    requires:
      bins:
        - uv
---

## Excel Spreadsheet Generation

Generate `.xlsx` spreadsheet files by running the `create_excel.py` script via `shell_exec`.

### Usage

Pipe a JSON array of sheet definitions to stdin and specify the target filename:

```bash
echo '[{"name": "Q1 Sales", "headers": ["Month", "Revenue", "Units"], "rows": [["January", 12500, 250], ["February", 15000, 300], ["March", 11000, 220]], "bold_header": true}]' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill excel --filename "report.xlsx" --output-dir "/path/to/output"
```

### Arguments

| Argument | Required | Description |
|----------|----------|-------------|
| `--filename` | Yes | Target filename, e.g. `"report.xlsx"` |
| `--output-dir` | No | Directory where the file will be written (default: current directory) |

### Stdin (JSON)

Provide a JSON array of sheet definitions on stdin. Each sheet object has:

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | No | Sheet tab name (default: `"Sheet"`) |
| `headers` | list[string] | No | Column header labels |
| `rows` | list[list] | No | Data rows — each row is a list of cell values |
| `bold_header` | bool | No | Apply bold formatting to the header row (default: `false`) |

### Example

To create a workbook with two sheets:

```bash
echo '[
  {
    "name": "Q1 Sales",
    "headers": ["Month", "Revenue", "Units"],
    "rows": [
      ["January", 12500, 250],
      ["February", 15000, 300],
      ["March", 11000, 220]
    ],
    "bold_header": true
  },
  {
    "name": "Summary",
    "headers": ["Metric", "Value"],
    "rows": [
      ["Total Revenue", 38500],
      ["Total Units", 770]
    ]
  }
]' | uv run python -m agent_framework.skills.builtin.scripts.create_and_register --skill excel --filename "sales_report.xlsx"
```

### Output Format (stdout)

On success, the script prints a JSON object to stdout with the download URL:

```json
{"status": "success", "file_id": "uuid", "download_url": "/files/uuid/download", "filename": "sales_report.xlsx", "size_bytes": 1234, "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "local_cleaned": true}
```

Use the `download_url` from this response to provide the user with a download link:

```
[sales_report.xlsx](/files/uuid/download)
```

### Error Handling (stderr)

On failure, the script prints a JSON error to stderr and exits with a non-zero code:

```json
{"status": "error", "message": "Description of the error"}
```

| Exit Code | Cause | Example Message |
|-----------|-------|-----------------|
| 1 | Empty or invalid JSON on stdin | `"Invalid JSON on stdin: ..."` |
| 1 | Stdin JSON is not a list | `"Stdin JSON must be a list of sheet definitions"` |
| 1 | No JSON data provided on stdin | `"No JSON data provided on stdin"` |
| 1 | Empty filename | `"Filename cannot be empty"` |
| 1 | Empty sheets list | `"Sheets list cannot be empty"` |
| 1 | Missing dependency | `"openpyxl is not installed. Install it with: uv add openpyxl"` |
| 2 | Missing required arguments | argparse usage message |

### Notes

- Multiple sheets are supported in a single call.
- Row length does not need to match header count — short rows leave trailing cells empty.
- Requires `openpyxl` to be installed (`uv add openpyxl`).
