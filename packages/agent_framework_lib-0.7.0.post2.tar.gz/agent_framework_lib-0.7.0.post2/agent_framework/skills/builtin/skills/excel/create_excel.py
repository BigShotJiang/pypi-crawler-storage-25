#!/usr/bin/env python3
"""Standalone CLI script for creating Excel .xlsx spreadsheet files.

Reads sheet definitions as JSON from stdin and generates an .xlsx file
using openpyxl. Outputs a JSON result on stdout.
"""
import argparse
import json
import os
import sys


def create_excel(filename: str, sheets: list[dict], output_dir: str) -> str:
    """Create an Excel .xlsx file with one or more sheets.

    Args:
        filename: Target filename for the .xlsx file.
        sheets: List of sheet definitions, each with name, headers, rows,
                and optional bold_header.
        output_dir: Directory where the file will be written.

    Returns:
        Absolute path to the created file.

    Raises:
        ValueError: If filename is empty or sheets list is empty.
        ImportError: If openpyxl is not installed.
    """
    try:
        import openpyxl
        from openpyxl.styles import Font
    except ImportError:
        raise ImportError("openpyxl is not installed. Install it with: uv add openpyxl")

    if not filename or not filename.strip():
        raise ValueError("Filename cannot be empty")

    if not sheets:
        raise ValueError("Sheets list cannot be empty")

    wb = openpyxl.Workbook()
    # Remove the default empty sheet
    wb.remove(wb.active)

    for sheet_def in sheets:
        sheet_name = sheet_def.get("name", "Sheet")
        headers = sheet_def.get("headers", [])
        rows = sheet_def.get("rows", [])
        bold_header = sheet_def.get("bold_header", False)

        ws = wb.create_sheet(title=sheet_name)

        if headers:
            ws.append(headers)
            if bold_header:
                bold_font = Font(bold=True)
                for cell in ws[1]:
                    cell.font = bold_font

        for row in rows:
            ws.append(row)

    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, filename)
    filepath = os.path.abspath(filepath)

    wb.save(filepath)
    return filepath


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create an Excel .xlsx spreadsheet file from JSON sheet definitions."
    )
    parser.add_argument(
        "--filename",
        required=True,
        help="Target filename for the .xlsx file (e.g. 'report.xlsx')",
    )
    parser.add_argument(
        "--output-dir",
        default=".",
        help="Directory where the file will be written (default: current directory)",
    )
    args = parser.parse_args()

    try:
        raw = sys.stdin.read()
        if not raw.strip():
            raise ValueError("No JSON data provided on stdin")
        sheets = json.loads(raw)
        if not isinstance(sheets, list):
            raise ValueError("Stdin JSON must be a list of sheet definitions")
    except json.JSONDecodeError as e:
        print(json.dumps({"status": "error", "message": f"Invalid JSON on stdin: {e}"}), file=sys.stderr)
        sys.exit(1)
    except ValueError as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)

    try:
        filepath = create_excel(args.filename, sheets, args.output_dir)
        print(json.dumps({"status": "success", "file": filepath}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
