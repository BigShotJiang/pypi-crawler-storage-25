#!/usr/bin/env python3
"""Register a local file into the agent's storage via the server HTTP API.

Reads AGENT_USER_ID, AGENT_SESSION_ID, AGENT_HOST, and AGENT_PORT from
environment variables (injected automatically by ShellTool). Uploads the
file to the running server's /files/upload endpoint so it uses the same
FileStorageManager and appears in the session's file list.

Usage (from shell_exec):
    uv run python -m agent_framework.skills.builtin.scripts.register_to_storage --file "/path/to/file"
"""
import json
import mimetypes
import os
import sys
import urllib.error
import urllib.request


MIME_OVERRIDES = {
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".xls": "application/vnd.ms-excel",
    ".pdf": "application/pdf",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".svg": "image/svg+xml",
    ".drawio": "application/xml",
    ".csv": "text/csv",
    ".json": "application/json",
    ".md": "text/markdown",
    ".txt": "text/plain",
    ".html": "text/html",
}


def _guess_mime(filepath: str) -> str:
    ext = os.path.splitext(filepath)[1].lower()
    if ext in MIME_OVERRIDES:
        return MIME_OVERRIDES[ext]
    guessed, _ = mimetypes.guess_type(filepath)
    return guessed or "application/octet-stream"


def _multipart_body(filepath: str, filename: str, mime: str) -> tuple[bytes, str]:
    boundary = "----AgentSkillUploadBoundary"
    with open(filepath, "rb") as f:
        data = f.read()
    parts = [
        f"--{boundary}".encode(),
        f'Content-Disposition: form-data; name="file"; filename="{filename}"'.encode(),
        f"Content-Type: {mime}".encode(),
        b"",
        data,
        f"--{boundary}--".encode(),
        b"",
    ]
    return b"\r\n".join(parts), f"multipart/form-data; boundary={boundary}"


def main() -> None:
    filepath = None
    args = sys.argv[1:]
    for i, arg in enumerate(args):
        if arg == "--file" and i + 1 < len(args):
            filepath = args[i + 1]
            break
    if not filepath and args and not args[0].startswith("-"):
        filepath = args[0]

    if not filepath:
        print(json.dumps({"status": "error", "message": "Usage: register_to_storage --file <path>"}), file=sys.stderr)
        sys.exit(1)

    if not os.path.isfile(filepath):
        print(json.dumps({"status": "error", "message": f"File not found: {filepath}"}), file=sys.stderr)
        sys.exit(1)

    if os.path.getsize(filepath) == 0:
        print(json.dumps({"status": "error", "message": f"File is empty: {filepath}"}), file=sys.stderr)
        sys.exit(1)

    user_id = os.environ.get("AGENT_USER_ID", "default_user")
    session_id = os.environ.get("AGENT_SESSION_ID", "")
    host = os.environ.get("AGENT_HOST", "localhost")
    port = os.environ.get("AGENT_PORT", "8203")

    filename = os.path.basename(filepath)
    mime = _guess_mime(filepath)

    params = f"user_id={user_id}&is_generated=true&tags=agent-created"
    if session_id:
        params += f"&session_id={session_id}"

    url = f"http://{host}:{port}/files/upload?{params}"
    body, content_type = _multipart_body(filepath, filename, mime)

    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", content_type)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            print(json.dumps({"status": "success", **result}))
    except urllib.error.HTTPError as e:
        err = e.read().decode("utf-8", errors="replace")
        print(json.dumps({"status": "error", "message": f"Server {e.code}: {err}"}), file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(json.dumps({"status": "error", "message": f"Cannot connect to server at http://{host}:{port}: {e.reason}"}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
