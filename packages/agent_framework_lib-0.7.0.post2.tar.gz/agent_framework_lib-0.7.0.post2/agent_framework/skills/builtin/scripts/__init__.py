"""Shared scripts for builtin skills."""
