#!/usr/bin/env python3
"""Wrapper that creates a file via a skill script and registers it to storage.

Combines file creation and storage registration into a single CLI invocation.
Runs the underlying skill script as a subprocess, verifies the output file,
uploads it to the Storage API, cleans up the local copy, and emits a single
JSON result with the download URL.

Usage:
    uv run python -m agent_framework.skills.builtin.scripts.create_and_register \
        --skill <skill_name> --filename <name> [--output-dir <dir>] [extra args...]
"""
import json
import os
import subprocess
import sys
import urllib.error
import urllib.request

from agent_framework.skills.builtin.scripts.register_to_storage import (
    _guess_mime,
    _multipart_body,
)

SKILL_MODULE_MAP = {
    "chart": "agent_framework.skills.builtin.skills.chart.chart_to_image",
    "unified_pdf": "agent_framework.skills.builtin.skills.unified_pdf.create_pdf",
    "excel": "agent_framework.skills.builtin.skills.excel.create_excel",
    "file": "agent_framework.skills.builtin.skills.file.create_file",
    "mermaid": "agent_framework.skills.builtin.skills.mermaid.mermaid_to_image",
    "drawio": "agent_framework.skills.builtin.skills.drawio.create_drawio",
    "table": "agent_framework.skills.builtin.skills.table.table_to_image",
}


def _emit_error(message: str, code: int = 1) -> None:
    """Print a JSON error to stderr and exit."""
    print(json.dumps({"status": "error", "message": message}), file=sys.stderr)
    sys.exit(code)


def _parse_args(argv: list[str]) -> tuple[str, str, str | None, list[str]]:
    """Extract --skill, --filename, --output-dir from argv.

    Returns:
        Tuple of (skill, filename, output_dir, remaining_args).
    """
    skill = None
    filename = None
    output_dir = None
    remaining = []
    i = 0
    while i < len(argv):
        if argv[i] == "--skill" and i + 1 < len(argv):
            skill = argv[i + 1]
            i += 2
        elif argv[i] == "--filename" and i + 1 < len(argv):
            filename = argv[i + 1]
            i += 2
        elif argv[i] == "--output-dir" and i + 1 < len(argv):
            output_dir = argv[i + 1]
            i += 2
        else:
            remaining.append(argv[i])
            i += 1

    if not skill:
        _emit_error("Missing required argument: --skill", code=2)
    if not filename:
        _emit_error("Missing required argument: --filename", code=2)

    return skill, filename, output_dir, remaining  # type: ignore[return-value]


def _run_skill(
    module: str,
    filename: str,
    output_dir: str | None,
    extra_args: list[str],
    stdin_data: bytes,
) -> str:
    """Invoke the skill script as a subprocess and return the created file path."""
    cmd = [sys.executable, "-m", module, "--filename", filename]
    if output_dir:
        cmd.extend(["--output-dir", output_dir])
    cmd.extend(extra_args)

    result = subprocess.run(cmd, input=stdin_data, capture_output=True)

    if result.returncode != 0:
        sys.stderr.buffer.write(result.stderr)
        sys.exit(result.returncode)

    try:
        output = json.loads(result.stdout.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        _emit_error(f"Failed to parse skill output: {exc}")

    if "file" not in output:
        _emit_error("Skill output missing 'file' field")

    return output["file"]


def _verify_file(filepath: str) -> None:
    """Check that the created file exists and is non-empty."""
    if not os.path.isfile(filepath):
        _emit_error(f"Created file not found: {filepath}")
    if os.path.getsize(filepath) == 0:
        _emit_error(f"Created file is empty: {filepath}")


def _upload_file(filepath: str) -> dict:
    """Upload the file to the Storage API and return the response dict."""
    user_id = os.environ.get("AGENT_USER_ID", "default_user")
    session_id = os.environ.get("AGENT_SESSION_ID", "")
    host = os.environ.get("AGENT_HOST", "localhost")
    port = os.environ.get("AGENT_PORT", "8203")

    filename = os.path.basename(filepath)
    mime = _guess_mime(filepath)

    params = f"user_id={user_id}&is_generated=true&tags=agent-created"
    if session_id:
        params += f"&session_id={session_id}"

    url = f"http://{host}:{port}/files/upload?{params}"
    body, content_type = _multipart_body(filepath, filename, mime)

    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", content_type)

    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        err = e.read().decode("utf-8", errors="replace")
        _emit_error(f"Server {e.code}: {err}")
    except urllib.error.URLError as e:
        _emit_error(
            f"Cannot connect to server at http://{host}:{port}: {e.reason}"
        )
    return {}  # unreachable, but satisfies type checker


def _cleanup(filepath: str) -> bool:
    """Delete the local file. Returns True on success, False on failure."""
    try:
        os.remove(filepath)
        return True
    except OSError:
        return False


def main() -> None:
    """Entry point for the create-and-register wrapper."""
    stdin_data = sys.stdin.buffer.read()

    skill, filename, output_dir, extra_args = _parse_args(sys.argv[1:])

    module = SKILL_MODULE_MAP.get(skill)
    if module is None:
        _emit_error(f"Unknown skill: {skill}")

    filepath = _run_skill(module, filename, output_dir, extra_args, stdin_data)  # type: ignore[arg-type]

    _verify_file(filepath)

    upload_result = _upload_file(filepath)

    local_cleaned = _cleanup(filepath)

    mime = _guess_mime(filepath)
    size_bytes = upload_result.get("size_bytes", 0)

    output = {
        "status": "success",
        "file_id": upload_result.get("file_id", ""),
        "download_url": upload_result.get("download_url", ""),
        "filename": os.path.basename(filepath),
        "size_bytes": size_bytes,
        "mime_type": mime,
        "local_cleaned": local_cleaned,
    }
    print(json.dumps(output))


if __name__ == "__main__":
    main()
