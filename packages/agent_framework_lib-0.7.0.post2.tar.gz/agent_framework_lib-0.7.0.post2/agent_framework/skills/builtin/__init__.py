"""
Built-in Skills for Agent Framework

This module provides pre-built skills that wrap existing tools with
appropriate instructions and metadata for on-demand loading.

Available Skills:
    Visualization:
        - chart_skill: Chart.js chart generation
        - mermaid_skill: Mermaid diagram generation
        - table_skill: Table image generation

    Document:
        - file_skill: File operations (create, list, read)
        - unified_pdf_skill: Unified PDF generation from HTML (RECOMMENDED)
        - pdf_skill: PDF generation from Markdown/HTML (DEPRECATED - use unified_pdf_skill)
        - pdf_with_images_skill: PDF with embedded images (DEPRECATED - use unified_pdf_skill)
        - file_access_skill: File path and data URI access

    Web:
        - web_search_skill: Web and news search

    Multimodal:
        - multimodal_skill: Image analysis

    UI:
        - form_skill: Form generation
        - optionsblock_skill: Options block generation
        - image_display_skill: Image display

Example:
    from agent_framework.skills.builtin import get_all_builtin_skills

    # Get all built-in skills
    skills = get_all_builtin_skills()

    # Register with an agent's skill registry
    for skill in skills:
        agent.register_skill(skill)
"""

from pathlib import Path
from typing import Literal

from ..base import Skill

# Visualization skills
from .chart_skill import create_chart_skill, CHART_INSTRUCTIONS
from .mermaid_skill import create_mermaid_skill, MERMAID_INSTRUCTIONS
from .table_skill import create_table_skill, TABLE_INSTRUCTIONS

# Document skills
from .file_skill import create_file_skill, FILE_INSTRUCTIONS
# DEPRECATED: Use create_unified_pdf_skill instead - provides unified HTML-based PDF generation
from .pdf_skill import create_pdf_skill, PDF_INSTRUCTIONS
# DEPRECATED: Use create_unified_pdf_skill instead - provides unified HTML-based PDF generation
from .pdf_with_images_skill import create_pdf_with_images_skill, PDF_WITH_IMAGES_INSTRUCTIONS
from .file_access_skill import create_file_access_skill, FILE_ACCESS_INSTRUCTIONS
# Unified PDF skill (replaces pdf_skill and pdf_with_images_skill)
from .unified_pdf_skill import create_unified_pdf_skill, UNIFIED_PDF_INSTRUCTIONS

# Web skills
from .web_search_skill import create_web_search_skill, WEB_SEARCH_INSTRUCTIONS

# Multimodal skills
from .multimodal_skill import create_multimodal_skill, MULTIMODAL_INSTRUCTIONS

# UI skills
from .form_skill import create_form_skill, FORM_INSTRUCTIONS
from .optionsblock_skill import create_optionsblock_skill, OPTIONSBLOCK_INSTRUCTIONS
from .image_display_skill import create_image_display_skill, IMAGE_DISPLAY_INSTRUCTIONS

# Excel and Draw.io skills
from .excel_skill import create_excel_skill, EXCEL_INSTRUCTIONS
from .drawio_skill import create_drawio_skill, DRAWIO_INSTRUCTIONS


_SKILLS_MD_DIR = Path(__file__).parent / "skills"


def _get_builtin_skills_from_python() -> list[Skill]:
    """Load built-in skills from Python factory functions."""
    skills: list[Skill] = []
    skills.append(create_chart_skill())
    skills.append(create_mermaid_skill())
    skills.append(create_table_skill())
    skills.append(create_file_skill())
    skills.append(create_unified_pdf_skill())
    skills.append(create_file_access_skill())
    skills.append(create_web_search_skill())
    skills.append(create_multimodal_skill())
    skills.append(create_form_skill())
    skills.append(create_optionsblock_skill())
    skills.append(create_image_display_skill())
    skills.append(create_excel_skill())
    skills.append(create_drawio_skill())
    return skills


def _get_builtin_skills_from_markdown() -> list[Skill]:
    """Load built-in skills from SKILL.md files with ShellTool and WebFetchTool attached."""
    from ..markdown_loader import MarkdownSkillLoader
    from ...tools.shell_tool import ShellTool
    from ...tools.web_fetch_tool import WebFetchTool

    skills = MarkdownSkillLoader().load_from_dir(_SKILLS_MD_DIR)
    for skill in skills:
        existing_types = {type(t) for t in skill.tools}
        if ShellTool not in existing_types:
            skill.tools.append(ShellTool(default_timeout=60))
        if WebFetchTool not in existing_types:
            skill.tools.append(WebFetchTool())
    return skills


def get_all_builtin_skills(
    source: Literal["python", "markdown"] = "markdown",
) -> list[Skill]:
    """Get all built-in skills.

    Args:
        source: Loading strategy.
            - ``"markdown"`` (default): use SKILL.md files from the ``skills/`` directory.
            - ``"python"``: deprecated, use Python factory functions.

    Returns:
        List of Skill instances for all built-in skills.
    """
    if source == "python":
        import warnings

        warnings.warn(
            "source='python' is deprecated. Use source='markdown' (now default).",
            DeprecationWarning,
            stacklevel=2,
        )
        return _get_builtin_skills_from_python()
    return _get_builtin_skills_from_markdown()


__all__ = [
    # Factory function
    "get_all_builtin_skills",
    # Visualization skill creators
    "create_chart_skill",
    "create_mermaid_skill",
    "create_table_skill",
    # Document skill creators
    "create_file_skill",
    # DEPRECATED: Use create_unified_pdf_skill instead
    "create_pdf_skill",
    # DEPRECATED: Use create_unified_pdf_skill instead
    "create_pdf_with_images_skill",
    "create_file_access_skill",
    # Unified PDF skill (recommended)
    "create_unified_pdf_skill",
    # Web skill creators
    "create_web_search_skill",
    # Multimodal skill creators
    "create_multimodal_skill",
    # UI skill creators
    "create_form_skill",
    "create_optionsblock_skill",
    "create_image_display_skill",
    # Instruction constants
    "CHART_INSTRUCTIONS",
    "MERMAID_INSTRUCTIONS",
    "TABLE_INSTRUCTIONS",
    "FILE_INSTRUCTIONS",
    # DEPRECATED: Use UNIFIED_PDF_INSTRUCTIONS instead
    "PDF_INSTRUCTIONS",
    # DEPRECATED: Use UNIFIED_PDF_INSTRUCTIONS instead
    "PDF_WITH_IMAGES_INSTRUCTIONS",
    "FILE_ACCESS_INSTRUCTIONS",
    # Unified PDF instructions (recommended)
    "UNIFIED_PDF_INSTRUCTIONS",
    "WEB_SEARCH_INSTRUCTIONS",
    "MULTIMODAL_INSTRUCTIONS",
    "FORM_INSTRUCTIONS",
    "OPTIONSBLOCK_INSTRUCTIONS",
    "IMAGE_DISPLAY_INSTRUCTIONS",
    # Excel and Draw.io skill creators
    "create_excel_skill",
    "create_drawio_skill",
    # Excel and Draw.io instruction constants
    "EXCEL_INSTRUCTIONS",
    "DRAWIO_INSTRUCTIONS",
]
