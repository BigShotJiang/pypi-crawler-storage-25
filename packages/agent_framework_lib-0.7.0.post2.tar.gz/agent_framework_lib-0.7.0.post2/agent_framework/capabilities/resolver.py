"""
CapabilitySet and CapabilityResolver — token-based capability resolution.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


logger = logging.getLogger(__name__)


@dataclass
class CapabilitySet:
    """Set of capabilities authorized for a session."""

    skill_ids: list[str] = field(default_factory=list)
    native_tools: list[str] = field(default_factory=list)
    max_subagent_depth: int = 0
    env_overrides: dict[str, str] = field(default_factory=dict)

    @classmethod
    def empty(cls) -> "CapabilitySet":
        """Return an empty CapabilitySet (no capabilities authorized)."""
        return cls()


class CapabilityResolverError(Exception):
    """Raised when the capability source is unreachable or invalid."""


class CapabilityResolver:
    """Resolves authorized capabilities from a token.

    Sources are checked in priority order:
    1. CAPABILITY_MAP environment variable (JSON inline)
    2. Local JSON file (json_path)
    3. HTTP endpoint (http_url)
    """

    def __init__(
        self,
        json_path: Path | None = None,
        http_url: str | None = None,
    ) -> None:
        """Initialize CapabilityResolver.

        Args:
            json_path: Optional path to a local JSON capability map.
            http_url: Optional HTTP URL to fetch capabilities from.
        """
        self._json_path = json_path
        self._http_url = http_url

    def resolve(self, api_token: str) -> CapabilitySet:
        """Return the CapabilitySet authorized for api_token.

        Unknown tokens return CapabilitySet.empty().

        Args:
            api_token: The API token to resolve.

        Returns:
            CapabilitySet for the token.

        Raises:
            CapabilityResolverError: If the configured source is unreachable or invalid.
        """
        capability_map = self._load_map()
        data = capability_map.get(api_token)
        if data is None:
            return CapabilitySet.empty()
        return self._parse_capability_set(data)

    @contextlib.contextmanager
    def apply_env_overrides(self, capability_set: CapabilitySet) -> Iterator[None]:
        """Context manager that injects env_overrides into os.environ.

        Keys that were absent before the block are removed on exit.
        Keys that existed before are restored to their original value.

        Args:
            capability_set: CapabilitySet whose env_overrides to apply.
        """
        overrides = capability_set.env_overrides
        previous: dict[str, str | None] = {}
        for key in overrides:
            previous[key] = os.environ.get(key)
            os.environ[key] = overrides[key]
        try:
            yield
        finally:
            for key, old_value in previous.items():
                if old_value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = old_value

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_map(self) -> dict[str, Any]:
        """Load the capability map from the highest-priority source."""
        env_json = os.environ.get("CAPABILITY_MAP")
        if env_json:
            try:
                data = json.loads(env_json)
                if not isinstance(data, dict):
                    raise CapabilityResolverError(
                        "CAPABILITY_MAP must be a JSON object"
                    )
                return data
            except json.JSONDecodeError as exc:
                raise CapabilityResolverError(
                    f"Invalid JSON in CAPABILITY_MAP: {exc}"
                ) from exc

        if self._json_path is not None:
            try:
                raw = Path(self._json_path).read_text(encoding="utf-8")
                data = json.loads(raw)
                if not isinstance(data, dict):
                    raise CapabilityResolverError(
                        f"JSON file must contain an object: {self._json_path}"
                    )
                return data
            except (OSError, json.JSONDecodeError) as exc:
                raise CapabilityResolverError(
                    f"Cannot load capability map from {self._json_path}: {exc}"
                ) from exc

        if self._http_url is not None:
            try:
                import httpx

                resp = httpx.get(self._http_url, timeout=10)
                resp.raise_for_status()
                data = resp.json()
                if not isinstance(data, dict):
                    raise CapabilityResolverError(
                        f"HTTP response must be a JSON object: {self._http_url}"
                    )
                return data
            except Exception as exc:
                raise CapabilityResolverError(
                    f"Cannot reach capability source at {self._http_url}: {exc}"
                ) from exc

        return {}

    @staticmethod
    def _parse_capability_set(data: Any) -> CapabilitySet:
        if not isinstance(data, dict):
            return CapabilitySet.empty()
        return CapabilitySet(
            skill_ids=list(data.get("skill_ids") or []),
            native_tools=list(data.get("native_tools") or []),
            max_subagent_depth=int(data.get("max_subagent_depth") or 0),
            env_overrides=dict(data.get("env_overrides") or {}),
        )


__all__ = [
    "CapabilitySet",
    "CapabilityResolver",
    "CapabilityResolverError",
]
