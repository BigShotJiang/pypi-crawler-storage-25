"""Capability resolution for token-based access control."""

from .resolver import CapabilityResolverError, CapabilityResolver, CapabilitySet


__all__ = [
    "CapabilitySet",
    "CapabilityResolver",
    "CapabilityResolverError",
]
