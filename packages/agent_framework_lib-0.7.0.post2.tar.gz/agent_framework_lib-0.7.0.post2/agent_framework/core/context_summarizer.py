"""Context summarizer for compressing conversation history.

Provides LLM-based summarization and simple truncation as fallback
for managing conversation context within budget constraints.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, Callable

from llama_index.core.llms import ChatMessage, MessageRole

if TYPE_CHECKING:
    from agent_framework.monitoring.token_counter import TokenCounter

logger = logging.getLogger(__name__)


class ContextSummarizer:
    """Compresse les messages de conversation via résumé LLM ou troncature."""

    # Marge de sécurité pour le prompt système + overhead
    _PROMPT_OVERHEAD_TOKENS = 500
    # Ratio max du context window utilisé pour le contenu à résumer
    _MAX_INPUT_RATIO = 0.80

    def __init__(self, llm_factory: Callable[[str], Any]) -> None:
        self._llm_factory = llm_factory

    async def summarize(
        self,
        messages_to_compress: list[ChatMessage],
        target_token_count: int,
        model_name: str,
    ) -> ChatMessage:
        """Résume les messages en un seul message via appel LLM.

        Si les messages dépassent la capacité du modèle, ils sont découpés
        en chunks résumés individuellement puis fusionnés.

        Args:
            messages_to_compress: Messages à résumer.
            target_token_count: Nombre cible de tokens pour le résumé.
            model_name: Modèle LLM à utiliser pour le résumé.

        Returns:
            Un ChatMessage de rôle SYSTEM contenant le résumé.
        """
        from agent_framework.core.context_budget import ModelContextRegistry
        from agent_framework.monitoring.token_counter import TokenCounter

        llm = self._llm_factory(model_name)
        token_counter = TokenCounter(model_name)
        context_window = ModelContextRegistry.get_context_window(model_name)
        max_input_tokens = int(context_window * self._MAX_INPUT_RATIO) - self._PROMPT_OVERHEAD_TOKENS

        chunks = self._split_into_chunks(messages_to_compress, max_input_tokens, token_counter)

        logger.info(
            "Summarizer: %d messages split into %d chunk(s), "
            "context_window=%d, max_input=%d",
            len(messages_to_compress), len(chunks), context_window, max_input_tokens,
        )

        if len(chunks) == 1:
            return await self._summarize_chunk(llm, chunks[0], target_token_count)

        # Résumer chaque chunk individuellement
        chunk_target = max(500, target_token_count // len(chunks))
        chunk_summaries: list[str] = []
        for i, chunk in enumerate(chunks):
            logger.info("Summarizing chunk %d/%d (%d messages)", i + 1, len(chunks), len(chunk))
            summary_msg = await self._summarize_chunk(llm, chunk, chunk_target)
            chunk_summaries.append(summary_msg.content or "")

        # Fusionner les résumés en un seul
        merged = await self._merge_summaries(llm, chunk_summaries, target_token_count)
        return merged

    async def _summarize_chunk(
        self, llm: Any, messages: list[ChatMessage], target_token_count: int,
    ) -> ChatMessage:
        """Résume un chunk de messages qui rentre dans le context window."""
        conversation_text = "\n".join(
            f"[{m.role.value}]: {m.content or ''}" for m in messages
        )
        summary_prompt = ChatMessage(
            role=MessageRole.USER,
            content=(
                "Résume de manière concise la conversation suivante en conservant "
                "les informations clés, les décisions prises, et les résultats "
                f"d'outils importants. Le résumé doit faire moins de {target_token_count} "
                f"tokens.\n\nConversation :\n{conversation_text}"
            ),
        )
        response = await llm.achat([summary_prompt])
        return ChatMessage(
            role=MessageRole.SYSTEM,
            content=f"[Résumé de la conversation précédente]\n{response.message.content}",
        )

    async def _merge_summaries(
        self, llm: Any, summaries: list[str], target_token_count: int,
    ) -> ChatMessage:
        """Fusionne plusieurs résumés partiels en un résumé final."""
        combined = "\n\n---\n\n".join(
            f"Partie {i+1}:\n{s}" for i, s in enumerate(summaries)
        )
        merge_prompt = ChatMessage(
            role=MessageRole.USER,
            content=(
                "Fusionne les résumés partiels suivants en un seul résumé cohérent "
                "et concis. Conserve les informations clés, décisions, et résultats "
                f"importants. Le résumé final doit faire moins de {target_token_count} "
                f"tokens.\n\n{combined}"
            ),
        )
        response = await llm.achat([merge_prompt])
        return ChatMessage(
            role=MessageRole.SYSTEM,
            content=f"[Résumé de la conversation précédente]\n{response.message.content}",
        )

    @staticmethod
    def _count_msg_tokens(msg: ChatMessage, token_counter: Any) -> int:
        """Compte les tokens d'un message en incluant tous les blocks.

        Args:
            msg: Message à compter.
            token_counter: Compteur de tokens.

        Returns:
            Nombre de tokens du message.
        """
        total = 0
        if hasattr(msg, 'blocks') and msg.blocks:
            for block in msg.blocks:
                block_type = type(block).__name__
                if hasattr(block, 'text'):
                    total += token_counter.count_tokens(block.text or "").count
                elif hasattr(block, 'tool_kwargs'):
                    tool_name = getattr(block, 'tool_name', '') or ''
                    total += token_counter.count_tokens(tool_name).count
                    kwargs = getattr(block, 'tool_kwargs', None)
                    if kwargs:
                        import json
                        try:
                            kwargs_str = json.dumps(kwargs) if isinstance(kwargs, dict) else str(kwargs)
                        except (TypeError, ValueError):
                            kwargs_str = str(kwargs)
                        total += token_counter.count_tokens(kwargs_str).count
                elif hasattr(block, 'tool_output'):
                    output = str(getattr(block, 'tool_output', '') or '')
                    total += token_counter.count_tokens(output).count
                elif block_type == 'ImageBlock':
                    total += 1600
                else:
                    try:
                        block_str = str(block)
                        if len(block_str) > 10:
                            total += token_counter.count_tokens(block_str).count
                    except Exception:
                        total += 100
        else:
            total = token_counter.count_tokens(msg.content or "").count
        return total

    @staticmethod
    def _split_into_chunks(
        messages: list[ChatMessage],
        max_tokens_per_chunk: int,
        token_counter: Any,
    ) -> list[list[ChatMessage]]:
        """Découpe les messages en chunks qui rentrent dans le budget tokens.

        Args:
            messages: Messages à découper.
            max_tokens_per_chunk: Taille max par chunk en tokens.
            token_counter: Compteur de tokens.

        Returns:
            Liste de chunks (chaque chunk = liste de messages).
        """
        if not messages:
            return []

        chunks: list[list[ChatMessage]] = []
        current_chunk: list[ChatMessage] = []
        current_tokens = 0

        for msg in messages:
            msg_tokens = ContextSummarizer._count_msg_tokens(msg, token_counter)
            if current_chunk and current_tokens + msg_tokens > max_tokens_per_chunk:
                chunks.append(current_chunk)
                current_chunk = []
                current_tokens = 0
            current_chunk.append(msg)
            current_tokens += msg_tokens

        if current_chunk:
            chunks.append(current_chunk)

        return chunks

    @staticmethod
    def truncate(
        messages: list[ChatMessage],
        target_token_count: int,
        token_counter: TokenCounter,
    ) -> list[ChatMessage]:
        """Troncature simple : supprime les messages les plus anciens.

        Args:
            messages: Messages à tronquer.
            target_token_count: Budget cible en tokens.
            token_counter: Compteur de tokens.

        Returns:
            Liste de messages dont le total est <= target_token_count.
        """
        total = sum(
            ContextSummarizer._count_msg_tokens(m, token_counter) for m in messages
        )
        result = list(messages)
        while result and total > target_token_count:
            removed = result.pop(0)
            total -= ContextSummarizer._count_msg_tokens(removed, token_counter)
        return result
