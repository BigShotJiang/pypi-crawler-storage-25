"""Provider-specific token calibration for tool definition overhead.

Provides calibration factors that account for the overhead each LLM provider
adds when serializing tool definitions. The model uses a fixed overhead
(provider system prompt for tool-use) plus a multiplier on the raw tool
definition tokens (XML/JSON wrapping per tool).

Previous calibration (2025-01) used a single 15x multiplier for Anthropic,
which was based on per-tool count_tokens calls that double-counted the shared
system overhead. See: https://www.async-let.com/posts/claude-code-mcp-token-reporting

Current calibration (2026-03) uses overhead + multiplier, measured against
Anthropic's batch count_tokens endpoint and OpenAI's tiktoken validation.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ProviderCalibration:
    """Calibration factors for an LLM provider's tool definition overhead."""

    provider_name: str
    tool_definition_multiplier: float
    fixed_overhead_tokens: int
    source: str
    measured_date: str
    notes: str = ""


class ProviderCalibrationRegistry:
    """Registry of per-provider token calibration data.

    Resolves the appropriate tool-definition overhead for a given model
    by detecting the provider from the model name.

    The total estimated tool tokens = raw_tokens * multiplier + fixed_overhead.
    """

    CALIBRATIONS: dict[str, ProviderCalibration] = {
        "anthropic": ProviderCalibration(
            provider_name="anthropic",
            tool_definition_multiplier=1.4,
            fixed_overhead_tokens=350,
            source="batch_count_tokens_measurement_2026-03",
            measured_date="2026-03",
            notes=(
                "Anthropic injects a hidden tool-use system prompt (~350 tokens) "
                "and wraps each tool in XML. The 1.4x multiplier accounts for "
                "XML wrapping overhead on the raw JSON schema. Previous 15x was "
                "based on per-tool counting that repeated the system overhead."
            ),
        ),
        "openai": ProviderCalibration(
            provider_name="openai",
            tool_definition_multiplier=1.1,
            fixed_overhead_tokens=100,
            source="tiktoken_validation_2026-03",
            measured_date="2026-03",
            notes="OpenAI function-calling format, minimal overhead over JSON schema",
        ),
        "google": ProviderCalibration(
            provider_name="google",
            tool_definition_multiplier=1.2,
            fixed_overhead_tokens=150,
            source="estimated_2026-03",
            measured_date="2026-03",
            notes="Gemini tool-use format, similar to OpenAI with slight extra wrapping",
        ),
    }

    DEFAULT_MULTIPLIER: float = 1.5
    DEFAULT_FIXED_OVERHEAD: int = 200

    # Prefix-to-provider mapping for model name detection
    _PROVIDER_PREFIXES: dict[str, str] = {
        "claude": "anthropic",
        "gpt": "openai",
        "o1": "openai",
        "o3": "openai",
        "o4": "openai",
        "gemini": "google",
    }

    @classmethod
    def detect_provider(cls, model_name: str) -> str | None:
        """Detect the provider from a model name.

        Checks if the model name starts with or contains known prefixes.

        Args:
            model_name: Name of the LLM model.

        Returns:
            Provider name (e.g. "anthropic") or None if unrecognized.
        """
        lower = model_name.lower()
        # Check longest prefixes first to avoid false positives
        for prefix in sorted(cls._PROVIDER_PREFIXES, key=len, reverse=True):
            if lower.startswith(prefix):
                return cls._PROVIDER_PREFIXES[prefix]
        return None

    @classmethod
    def get_calibration(cls, model_name: str) -> ProviderCalibration | None:
        """Return the full calibration for a model, or None if unknown.

        Args:
            model_name: Name of the LLM model.

        Returns:
            ProviderCalibration if the provider is recognized, else None.
        """
        provider = cls.detect_provider(model_name)
        if provider is None:
            return None
        return cls.CALIBRATIONS.get(provider)

    @classmethod
    def get_multiplier(cls, model_name: str) -> float:
        """Resolve the tool-definition multiplier for a model.

        Falls back to DEFAULT_MULTIPLIER and logs INFO when the
        provider is not recognized.

        Args:
            model_name: Name of the LLM model.

        Returns:
            The provider-specific multiplier, or the default.
        """
        calibration = cls.get_calibration(model_name)
        if calibration is not None:
            return calibration.tool_definition_multiplier

        logger.info(
            "No calibration for model '%s', using default multiplier %.1f",
            model_name,
            cls.DEFAULT_MULTIPLIER,
        )
        return cls.DEFAULT_MULTIPLIER

    @classmethod
    def get_fixed_overhead(cls, model_name: str) -> int:
        """Resolve the fixed tool-use overhead tokens for a model.

        This accounts for the hidden system prompt that providers inject
        when tools are present (e.g. Anthropic's tool-use preamble).

        Args:
            model_name: Name of the LLM model.

        Returns:
            Fixed overhead in tokens, or the default.
        """
        calibration = cls.get_calibration(model_name)
        if calibration is not None:
            return calibration.fixed_overhead_tokens
        return cls.DEFAULT_FIXED_OVERHEAD
