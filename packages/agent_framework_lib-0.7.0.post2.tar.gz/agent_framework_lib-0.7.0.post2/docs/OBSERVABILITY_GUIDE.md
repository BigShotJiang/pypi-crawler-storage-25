# Guide d'Observabilité - Agent Framework

Ce guide couvre l'architecture d'observabilité complète de l'Agent Framework : métriques Elasticsearch, tracing distribué OpenTelemetry, logging structuré, et monitoring des ressources système.

## Table des Matières

1. [Vue d'Ensemble](#vue-densemble)
2. [Configuration](#configuration)
3. [Composants de Monitoring](#composants-de-monitoring)
4. [Index Unifié de Métriques](#index-unifié-de-métriques)
5. [Spans Disponibles](#spans-disponibles)
6. [Accurate Token Tracking](#accurate-token-tracking)
7. [OpenTelemetry](#opentelemetry)
8. [Streaming Latency Tracer](#streaming-latency-tracer)
9. [Resource Metrics Collector](#resource-metrics-collector)
10. [Dashboards et Visualisation](#dashboards-et-visualisation)
11. [Fichiers de Configuration](#fichiers-de-configuration)
12. [Intégration Docker Compose](#intégration-docker-compose)
13. [Troubleshooting](#troubleshooting)
14. [Liens Connexes](#liens-connexes)

---

## Vue d'Ensemble

L'Agent Framework dispose de deux pipelines d'observabilité complémentaires :

1. **Métriques Elasticsearch** : Index unifié `agent-metrics-*` pour les dashboards Kibana (API timing, tokens LLM, spans détaillés)
2. **OpenTelemetry** : Tracing distribué, métriques et logs exportés vers Jaeger, Prometheus et Grafana

Ces deux pipelines peuvent fonctionner indépendamment ou ensemble.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              AGENT FRAMEWORK                                    │
│                                                                                 │
│  ┌──────────────────────────┐       ┌──────────────────────────┐               │
│  │   ObservabilityManager   │       │    MetricsAggregator     │               │
│  │   (Facade unifiée)       │       │    (1 doc par requête)   │               │
│  │                          │       │                          │               │
│  │  TracingContextManager   │       │  API Timing + LLM Metrics│               │
│  │  OTelMetricsRecorder     │       │  + Span Timings          │               │
│  │  OTelLoggingHandler      │       │                          │               │
│  └────────────┬─────────────┘       └────────────┬─────────────┘               │
│               │                                   │                             │
│               │ OTLP (gRPC/HTTP)                  │ HTTP (bulk API)            │
│               │                                   │                             │
│  ┌────────────┴─────────────┐       ┌────────────┴─────────────┐               │
│  │  StreamingLatencyTracer  │       │ ResourceMetricsCollector  │               │
│  │  (Spans ES + fallback)   │       │ (CPU/RAM via psutil)     │               │
│  └──────────────────────────┘       └──────────────────────────┘               │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
         │                                          │
         ▼                                          ▼
┌─────────────────────┐                ┌────────────────────────────┐
│  OTel Collector      │                │      Elasticsearch         │
│  (Port 4317/4318)    │                │      (Port 9200)           │
│                      │                │                            │
│  → Jaeger (traces)   │                │  Index: agent-metrics-*    │
│  → Prometheus (métr.)│                │                            │
│  → ES (logs)         │                └─────────────┬──────────────┘
└─────────────────────┘                               │
         │                                            ▼
         ▼                                     ┌───────────┐
┌─────────────────────┐                        │  Kibana   │
│  Grafana (3000)     │                        │  (5601)   │
│  Jaeger UI (16686)  │                        └───────────┘
│  Prometheus (9090)  │
└─────────────────────┘
```

---

## Configuration

### Variables d'Environnement — Métriques Elasticsearch

| Variable | Type | Défaut | Description |
|----------|------|--------|-------------|
| `METRICS_ENABLED` | `bool` | `true` | Switch principal pour toute la collecte de métriques |
| `METRICS_ES_LOGGING_ENABLED` | `bool` | `false` | Active l'écriture des métriques dans Elasticsearch via le handler de logging dédié |
| `METRICS_INDEX_PREFIX` | `str` | `agent-metrics` | Préfixe des index Elasticsearch de métriques |
| `METRICS_BATCH_SIZE` | `int` | `50` | Taille du batch pour les opérations bulk ES |
| `METRICS_FLUSH_INTERVAL` | `float` | `5.0` | Intervalle de flush automatique (secondes) |
| `METRICS_MAX_BUFFER_SIZE` | `int` | `1000` | Taille maximale du buffer circulaire |
| `UNIFIED_METRICS_ENABLED` | `bool` | `true` | Active l'agrégateur de métriques unifié (MetricsAggregator) |

### Variables d'Environnement — OpenTelemetry

| Variable | Type | Défaut | Description |
|----------|------|--------|-------------|
| `OTEL_ENABLED` | `bool` | `true` | Switch principal pour OpenTelemetry |
| `OTEL_SERVICE_NAME` | `str` | `agent_framework` | Nom du service dans les traces |
| `OTEL_SERVICE_VERSION` | `str` | `1.0.0` | Version du service |
| `OTEL_ENVIRONMENT` | `str` | `development` | Environnement de déploiement |
| `OTEL_EXPORTER_OTLP_ENDPOINT` | `str` | _(aucun)_ | Endpoint du collecteur OTLP (ex: `http://localhost:4317`) |
| `OTEL_EXPORTER_OTLP_PROTOCOL` | `str` | `grpc` | Protocole OTLP : `grpc` ou `http` |
| `OTEL_METRICS_EXPORTER` | `str` | `otlp` | Type d'exporteur de métriques : `otlp`, `prometheus`, `none` |
| `OTEL_LOGS_EXPORTER` | `str` | `otlp` | Type d'exporteur de logs : `otlp`, `none` |

### Variables d'Environnement — Autres

| Variable | Type | Défaut | Description |
|----------|------|--------|-------------|
| `LLM_AUTO_INSTRUMENTATION_ENABLED` | `bool` | `true` (si `traceloop-sdk` installé) | Active l'auto-instrumentation LLM via OpenLLMetry |
| `RESOURCE_METRICS_ENABLED` | `bool` | `true` | Active la collecte de métriques CPU/RAM via psutil |
| `ELASTICSEARCH_ENABLED` | `bool` | `true` | Active la connexion Elasticsearch |
| `ELASTICSEARCH_URL` | `str` | `http://localhost:9200` | URL du cluster Elasticsearch |
| `ELASTICSEARCH_LOG_INDEX_PATTERN` | `str` | `agent-logs-{date}` | Pattern d'index pour les logs ES |
| `ELASTICSEARCH_LOG_BATCH_SIZE` | `int` | `100` | Taille du batch pour les logs ES |
| `ELASTICSEARCH_LOG_FLUSH_INTERVAL` | `float` | `5.0` | Intervalle de flush des logs ES (secondes) |
| `ELASTICSEARCH_FALLBACK_TO_FILE` | `bool` | `true` | Active le fallback fichier si ES est indisponible |
| `ELASTICSEARCH_FALLBACK_LOG_FILE` | `str` | `logs/elasticsearch_fallback.log` | Chemin du fichier de fallback |

### Exemple de Configuration Minimale

```bash
# .env — Métriques ES uniquement (sans OTel)
ELASTICSEARCH_ENABLED=true
ELASTICSEARCH_URL=http://localhost:9200
METRICS_ENABLED=true
UNIFIED_METRICS_ENABLED=true
```

### Exemple de Configuration Complète (OTel + ES)

```bash
# .env — Stack complète
ELASTICSEARCH_ENABLED=true
ELASTICSEARCH_URL=http://localhost:9200
METRICS_ENABLED=true
METRICS_ES_LOGGING_ENABLED=true
UNIFIED_METRICS_ENABLED=true

OTEL_ENABLED=true
OTEL_SERVICE_NAME=agent_framework
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
OTEL_EXPORTER_OTLP_PROTOCOL=grpc
OTEL_METRICS_EXPORTER=otlp
OTEL_LOGS_EXPORTER=otlp

LLM_AUTO_INSTRUMENTATION_ENABLED=true
RESOURCE_METRICS_ENABLED=true
```

---

## Composants de Monitoring

Le module `agent_framework/monitoring/` contient tous les composants d'observabilité :

| Fichier | Composant | Rôle |
|---------|-----------|------|
| `observability_manager.py` | `ObservabilityManager` | Facade unifiée pour tracing, métriques et logging. Fallback automatique vers ES si OTel indisponible |
| `metrics_aggregator.py` | `MetricsAggregator` | Agrège toutes les métriques d'une requête en un document ES unifié |
| `metrics_config.py` | `MetricsConfig` | Configuration centralisée des métriques (singleton) |
| `otel_setup.py` | `OTelSetup` | Initialisation unifiée d'OpenTelemetry (traces, métriques, logs) |
| `tracing_context.py` | `TracingContextManager` | Gestion de la hiérarchie de spans OTel (API → LLM) |
| `otel_metrics_recorder.py` | `OTelMetricsRecorder` | Enregistrement des métriques via OTel (histogrammes, compteurs) |
| `otel_logging_handler.py` | `OTelLoggingHandler` | Handler Python logging qui envoie les logs via OTel |
| `otel_instrumentor.py` | `OTELInstrumentor` | Instrumentation OTel pour les appels LLM et requêtes API |
| `streaming_latency_tracer.py` | `StreamingLatencyTracer` | Traçage de latence pour le streaming avec écriture ES |
| `resource_metrics_collector.py` | `ResourceMetricsCollector` | Collecte CPU/RAM via psutil |
| `llm_auto_instrumentor.py` | `LLMAutoInstrumentor` | Auto-instrumentation LLM via OpenLLMetry (traceloop-sdk) |
| `llm_metrics_collector.py` | `LLMMetricsCollector` | Collecte et agrégation des métriques LLM par session |
| `llm_metrics_extractor.py` | `LLMMetricsExtractor` | Extraction des métriques depuis les traces OpenLLMetry |
| `llm_metrics.py` | `LLMMetrics` | Modèles de données pour les métriques LLM |
| `api_timing_tracker.py` | `APITimingTracker` | Tracking du timing des requêtes API (preprocessing, LLM, postprocessing) |
| `timing_tracker.py` | `TimingTracker` | Tracker de timing générique |
| `token_counter.py` | `TokenCounter` | Comptage de tokens par session |
| `elasticsearch_logging.py` | `ElasticsearchLoggingHandler` | Handler de logging vers ES avec batching et fallback fichier |
| `elasticsearch_circuit_breaker.py` | `ElasticsearchCircuitBreaker` | Circuit breaker pour les connexions ES (closed → open → half-open) |
| `performance_monitor.py` | `PerformanceMonitor` | Monitoring de performance avec alertes (latence, stockage, système) |
| `progress_tracker.py` | `ProgressTracker` | Suivi de progression des opérations longues |
| `resource_manager.py` | `ResourceManager` | Gestion des ressources système (slots d'opération, limites CPU/RAM/disque) |
| `error_handling.py` | `ErrorHandler` | Gestion structurée des erreurs avec classification et feedback utilisateur |
| `error_logging.py` | — | Logging structuré des erreurs |

---

## Index Unifié de Métriques

### Principe

Chaque requête API génère **un seul document** dans l'index `agent-metrics-{date}`. Cet index consolide API timing, métriques LLM et spans détaillés.

| Aspect | Avant (3 index) | Après (1 index) |
|--------|-----------------|-----------------|
| **Corrélation** | Jointure par request_id | Tout dans un document |
| **Maintenance** | 3 templates, 3 rotations | 1 template, 1 rotation |
| **Dashboards** | Panels pointant vers différents index | Source unique |
| **Requêtes** | Complexes avec jointures | Simples et rapides |

### Structure du Document

```json
{
  "@timestamp": "2024-01-15T10:30:00.000Z",
  "request_id": "req-uuid-123",
  "session_id": "sess-456",
  "user_id": "user-789",
  "agent_id": "support-agent",
  "endpoint": "/stream",
  "method": "POST",
  "model_name": "gpt-4-turbo",

  "total_api_duration_ms": 2500.0,
  "preprocessing_duration_ms": 150.0,
  "llm_duration_ms": 2200.0,
  "postprocessing_duration_ms": 150.0,

  "time_to_first_token_ms": 450.0,
  "input_tokens": 1500,
  "output_tokens": 800,
  "thinking_tokens": 200,
  "total_tokens": 2500,
  "tokens_per_second": 36.4,

  "tool_call_count": 2,
  "tool_call_total_ms": 350.0,

  "span_preprocessing_load_session_ms": 25.0,
  "span_preprocessing_get_history_ms": 45.0,
  "span_preprocessing_model_routing_ms": 10.0,
  "span_agent_load_state_ms": 30.0,
  "span_llamaindex_llm_call_ms": 2200.0,

  "is_streaming": true,
  "status_code": 200
}
```

### Champs Disponibles

| Catégorie | Champs | Description |
|-----------|--------|-------------|
| **Contexte** | `request_id`, `session_id`, `user_id`, `agent_id`, `endpoint`, `method`, `model_name` | Identifiants pour filtrage |
| **API Timing** | `total_api_duration_ms`, `preprocessing_duration_ms`, `llm_duration_ms`, `postprocessing_duration_ms` | Durées des phases principales |
| **LLM Metrics** | `input_tokens`, `output_tokens`, `thinking_tokens`, `total_tokens`, `tokens_per_second`, `time_to_first_token_ms` | Métriques LLM |
| **Tool Calls** | `tool_call_count`, `tool_call_total_ms` | Appels d'outils |
| **Spans** | `span_preprocessing_*_ms`, `span_agent_*_ms`, `span_llamaindex_*_ms` | Timing détaillé par étape |
| **Status** | `is_streaming`, `status_code`, `error_message` | État de la requête |

### Utilisation dans le Code

```python
from agent_framework.monitoring import MetricsAggregator

aggregator = MetricsAggregator(
    request_id="req-123",
    endpoint="/stream",
    method="POST",
)

aggregator.start_request()
aggregator.start_preprocessing()
# ... preprocessing ...
aggregator.end_preprocessing()

aggregator.start_llm()
# ... LLM call ...
aggregator.record_ttft(450.0)
aggregator.end_llm()

aggregator.start_postprocessing()
# ... postprocessing ...
aggregator.end_postprocessing()

aggregator.record_tokens(input_tokens=1500, output_tokens=800, thinking_tokens=200)
await aggregator.finalize()
```

---

## Spans Disponibles

Les spans permettent une analyse fine de chaque étape du pipeline de traitement. Ils sont enregistrés à la fois dans l'index unifié ES (via `MetricsAggregator`) et dans les traces OTel (via `TracingContextManager` et `StreamingLatencyTracer`).

### Spans Preprocessing

| Span | Champ ES | Description |
|------|----------|-------------|
| `preprocessing.load_session` | `span_preprocessing_load_session_ms` | Chargement de la session utilisateur |
| `preprocessing.process_files` | `span_preprocessing_process_files_ms` | Traitement des fichiers uploadés |
| `preprocessing.get_agent` | `span_preprocessing_get_agent_ms` | Récupération de la configuration de l'agent |
| `preprocessing.get_history` | `span_preprocessing_get_history_ms` | Chargement de l'historique de conversation |
| `preprocessing.model_routing` | `span_preprocessing_model_routing_ms` | Sélection du modèle LLM |
| `preprocessing.configure_model` | `span_preprocessing_configure_model_ms` | Configuration du modèle sélectionné |
| `preprocessing.persist_user_message` | `span_preprocessing_persist_user_message_ms` | Persistance du message utilisateur |
| `preprocessing.build_query` | `span_preprocessing_build_query_ms` | Construction de la requête finale |

### Spans Agent

| Span | Champ ES | Description |
|------|----------|-------------|
| `agent.instantiate` | `span_agent_instantiate_ms` | Instanciation de l'agent |
| `agent.inject_storage` | `span_agent_inject_storage_ms` | Injection du backend de stockage |
| `agent.load_config` | `span_agent_load_config_ms` | Chargement de la configuration de l'agent |
| `agent.load_state` | `span_agent_load_state_ms` | Chargement de l'état persisté |
| `agent.configure_session` | `span_agent_configure_session_ms` | Configuration de la session |
| `agent.ensure_built` | `span_agent_ensure_built_ms` | Vérification que l'agent est construit |
| `agent.create_context` | `span_agent_create_context_ms` | Création du contexte d'exécution |
| `agent.build_query` | `span_agent_build_query_ms` | Construction de la requête agent |
| `agent.memory_injection` | `span_agent_memory_injection_ms` | Injection de la mémoire dans le contexte |

### Spans LlamaIndex

| Span | Champ ES | Description |
|------|----------|-------------|
| `llamaindex.load_memory` | `span_llamaindex_load_memory_ms` | Chargement de la mémoire LlamaIndex |
| `llamaindex.sanitize_memory` | `span_llamaindex_sanitize_memory_ms` | Nettoyage de la mémoire |
| `llamaindex.llm_call` | `span_llamaindex_llm_call_ms` | Appel LLM principal |

### Spans OTel (TracingContextManager)

Le `TracingContextManager` crée des spans OTel avec une hiérarchie parent-enfant :

```
POST /stream (api_request_span)
├── llm.chat (llm_call_span) — Call 1
│   ├── gen_ai.request.model: "gpt-4"
│   ├── gen_ai.usage.input_tokens: 1500
│   ├── gen_ai.usage.output_tokens: 200
│   └── gen_ai.usage.thinking_tokens: 0
├── llm.chat (llm_call_span) — Call 2 (tool use)
│   └── ...
└── llm.chat (llm_call_span) — Call 3 (final)
    └── ...
```

Attributs sémantiques utilisés :

| Attribut | Convention | Description |
|----------|-----------|-------------|
| `http.method` | OTel HTTP | Méthode HTTP |
| `http.route` | OTel HTTP | Route de l'endpoint |
| `http.status_code` | OTel HTTP | Code de statut HTTP |
| `session.id` | Custom | ID de session |
| `request.id` | Custom | ID de requête |
| `gen_ai.request.model` | OTel GenAI | Modèle LLM utilisé |
| `gen_ai.usage.input_tokens` | OTel GenAI | Tokens d'entrée |
| `gen_ai.usage.output_tokens` | OTel GenAI | Tokens de sortie |
| `gen_ai.usage.thinking_tokens` | OTel GenAI | Tokens de raisonnement |
| `gen_ai.response.duration_ms` | OTel GenAI | Durée de la réponse LLM |
| `gen_ai.response.time_to_first_token_ms` | OTel GenAI | Time to First Token |
| `gen_ai.operation.name` | OTel GenAI | Type d'opération (chat, etc.) |

---

## Accurate Token Tracking

Le framework capture les vrais comptages de tokens directement depuis les réponses API des providers LLM via OpenLLMetry (`traceloop-sdk`).

### Classification des Tokens

| Type | Description |
|------|-------------|
| `input_tokens` | Contexte initial (query + system prompt + tools + memory) |
| `thinking_tokens` | Raisonnement intermédiaire (décisions d'outils, traitement des résultats) |
| `output_tokens` | Réponse finale à l'utilisateur |

### Exemple avec Agent Loop

```
Call 1 (initial):
  input: 5000 tokens → input_tokens
  output: 200 tokens → thinking_tokens

Call 2 (intermediate):
  input: 1500 tokens  → thinking_tokens
  output: 300 tokens  → thinking_tokens

Call 3 (final):
  input: 2000 tokens  → thinking_tokens
  output: 800 tokens  → output_tokens

Résultat:
  input_tokens = 5000
  thinking_tokens = 4000
  output_tokens = 800
```

---

## OpenTelemetry

### Architecture OTel

L'`OTelSetup` initialise les trois signaux OTel :

- **Traces** : Via `TracerProvider` → exportées vers Jaeger (ou Elastic APM)
- **Métriques** : Via `MeterProvider` → exportées vers Prometheus (ou Elastic APM)
- **Logs** : Via `LoggerProvider` → exportés vers Elasticsearch (via OTel Collector)

### ObservabilityManager

Le `ObservabilityManager` est la facade principale. Il combine `TracingContextManager` et `OTelMetricsRecorder` avec un fallback automatique vers Elasticsearch si OTel n'est pas disponible.

```python
from agent_framework.monitoring import get_observability_manager

manager = get_observability_manager()

# Créer un span pour une requête API
with manager.tracing.api_request_span(
    endpoint="/chat",
    method="POST",
    session_id="sess-123"
) as api_ctx:
    # Créer un span enfant pour l'appel LLM
    with manager.tracing.llm_call_span(
        model_name="gpt-4",
        api_context=api_ctx
    ) as llm_ctx:
        # ... appel LLM ...
        llm_ctx.record_tokens(input_tokens=1500, output_tokens=800)
```

### OTelMetricsRecorder

Enregistre les métriques via les instruments OTel (histogrammes et compteurs) :

- `llm.duration` (histogram) — Durée des appels LLM
- `llm.tokens.input` (counter) — Tokens d'entrée
- `llm.tokens.output` (counter) — Tokens de sortie
- `llm.ttft` (histogram) — Time to First Token
- `api.duration` (histogram) — Durée des requêtes API
- `api.preprocessing.duration` (histogram) — Durée du preprocessing
- `api.llm.duration` (histogram) — Durée LLM dans le contexte API

### LLM Auto-Instrumentation

Le `LLMAutoInstrumentor` utilise `traceloop-sdk` (OpenLLMetry) pour capturer automatiquement les métriques des appels LLM sans modification de code. Il intercepte les appels aux providers (OpenAI, Anthropic, etc.) et extrait les comptages de tokens réels.

Contrôlé par `LLM_AUTO_INSTRUMENTATION_ENABLED` (défaut : `true` si `traceloop-sdk` est installé).

### OTelLoggingHandler

Handler Python `logging` qui envoie les logs via le `LoggerProvider` OTel avec corrélation automatique des traces (trace_id, span_id).

```python
from agent_framework.monitoring import setup_otel_logging

setup_otel_logging(level=logging.INFO)
```

---

## Streaming Latency Tracer

Le `StreamingLatencyTracer` (`streaming_latency_tracer.py`) fournit un traçage de latence spécifique au streaming, avec écriture directe dans Elasticsearch et fallback logging.

### Fonctionnalités

- Création de spans typés : `preprocessing_span`, `agent_span`, `llm_span`
- Attributs de base configurables (`session_id`, `user_id`, `agent_id`, `request_id`)
- Enregistrement du Time to First Token (TTFT) sur les spans
- Batching et intégration avec le circuit breaker ES
- Chaque span produit un document ES avec `span_id`, `span_name`, `span_type`, `duration_ms`, `status`

### Utilisation

```python
from agent_framework.monitoring import (
    get_streaming_latency_tracer,
    initialize_streaming_latency_tracer,
    SpanAttributes,
)

# Initialiser avec le client ES
await initialize_streaming_latency_tracer(es_client=es_client)
tracer = get_streaming_latency_tracer()

# Configurer les attributs de base
tracer.set_base_attributes(SpanAttributes(
    session_id="sess-123",
    agent_id="my-agent",
    request_id="req-456",
))

# Créer des spans
async with tracer.preprocessing_span("load_session") as ctx:
    # ... chargement session ...
    pass

async with tracer.agent_span("load_state") as ctx:
    # ... chargement état ...
    pass

async with tracer.llm_span("llm_call", model_name="gpt-4") as ctx:
    # ... appel LLM ...
    tracer.record_ttft(ctx, ttft_ms=450.0)

# Flush les spans en attente
await tracer.flush()
```

### Types de Spans

| Méthode | Préfixe du span | Type |
|---------|----------------|------|
| `preprocessing_span(name)` | `preprocessing.{name}` | `preprocessing` |
| `agent_span(name)` | `agent.{name}` | `agent` |
| `llm_span(name)` | `llamaindex.{name}` | `llamaindex` |

---

## Resource Metrics Collector

Le `ResourceMetricsCollector` (`resource_metrics_collector.py`) collecte les métriques système (CPU et RAM) via `psutil` de manière non-bloquante.

### Fonctionnalités

- Collecte CPU via `psutil.cpu_percent(interval=None)` (non-bloquant)
- Collecte mémoire via `psutil.virtual_memory()`
- Activation/désactivation via `RESOURCE_METRICS_ENABLED`
- Fallback gracieux si `psutil` n'est pas installé
- Intégration avec les spans OTel et l'agrégation de métriques ES

### Modèle de Données

```python
class ResourceMetrics(BaseModel):
    cpu_percent: float        # Utilisation CPU (0-100)
    memory_used_mb: int       # Mémoire utilisée (MB)
    memory_available_mb: int  # Mémoire disponible (MB)
    memory_percent: float     # Utilisation mémoire (0-100)
```

### Utilisation

```python
from agent_framework.monitoring import ResourceMetricsCollector

collector = ResourceMetricsCollector()

metrics = collector.collect()
if metrics:
    print(f"CPU: {metrics.cpu_percent}%")
    print(f"Memory: {metrics.memory_used_mb}MB used ({metrics.memory_percent}%)")
```

### Prérequis

```bash
uv add psutil
```

Si `psutil` n'est pas installé, le collecteur retourne `None` silencieusement (avec un warning au premier appel).

---

## Dashboards et Visualisation

### Dashboards Kibana

Deux fichiers de dashboard Kibana sont fournis dans `observability/` :

| Fichier | Description |
|---------|-------------|
| `observability/kibana-dashboard.ndjson` | Dashboard général d'observabilité |
| `observability/kibana-llm-dashboard-setup.json` | Dashboard LLM avec métriques de tokens et latence |

#### Visualisations du Dashboard LLM

| Panel | Type | Description |
|-------|------|-------------|
| LLM Tokens Over Time | Timeseries | Input/Output/Thinking tokens |
| LLM Duration Over Time | Timeseries | Durée LLM + TTFT (P50) |
| Total Input/Output/Thinking Tokens | Metric | Compteurs totaux |
| Avg LLM Duration | Metric | Durée moyenne |
| Avg TTFT | Metric | Time to First Token moyen |
| Tokens by Model | Top N | Répartition par modèle |
| Tool Calls Count | Metric | Nombre d'appels d'outils |
| API Duration Over Time | Timeseries | Durée API (P50) |
| Duration by Endpoint | Top N | Durée par endpoint |
| Latency Breakdown | Timeseries | Preprocessing/LLM/Postprocessing |
| Tokens Per Second | Metric | Débit de génération |

#### Import du Dashboard

```bash
# Vérifier que l'index existe
curl -s "http://localhost:9200/_cat/indices/agent-metrics-*?v"

# Créer l'index pattern dans Kibana
# Management > Index Patterns > Create: agent-metrics-*
```

### Dashboards Grafana

Les dashboards Grafana sont provisionnés automatiquement au démarrage :

| Fichier | Description |
|---------|-------------|
| `observability/grafana/dashboards/agent-metrics.json` | Dashboard principal des métriques agent |
| `observability/grafana/provisioning/datasources/datasources.yml` | Configuration des datasources (Prometheus, Jaeger, ES) |
| `observability/grafana/provisioning/dashboards/dashboards.yml` | Configuration du provisioning des dashboards |

#### Datasources Configurées

| Datasource | Type | URL | Description |
|------------|------|-----|-------------|
| Prometheus | `prometheus` | `http://prometheus:9090` | Métriques (datasource par défaut) |
| Jaeger | `jaeger` | `http://jaeger:16686` | Traces distribuées |
| Elasticsearch-Logs | `elasticsearch` | `http://elasticsearch:9200` | Logs OTel (`otel-logs-*`) |
| Elasticsearch-Metrics | `elasticsearch` | `http://elasticsearch:9200` | Métriques OTel (`otel-metrics-*`) |
| Elasticsearch-Sessions | `elasticsearch` | `http://elasticsearch:9200` | Sessions (`agent-sessions-*`) |

### Dashboards Elastic APM (Grafana)

| Fichier | Description |
|---------|-------------|
| `observability/grafana-apm/dashboards/llm-metrics.json` | Dashboard LLM pour la stack Elastic APM |
| `observability/grafana-apm/provisioning/` | Provisioning spécifique à la stack APM |

---

## Fichiers de Configuration

### Structure du Répertoire `observability/`

```
observability/
├── otel-collector-config.yaml          # Configuration OTel Collector
├── prometheus.yml                       # Configuration Prometheus
├── kibana-dashboard.ndjson             # Dashboard Kibana général
├── kibana-llm-dashboard-setup.json     # Dashboard Kibana LLM
├── elastic-apm/
│   └── README.md                       # Guide de la stack Elastic APM
├── grafana/
│   ├── dashboards/
│   │   └── agent-metrics.json          # Dashboard Grafana principal
│   └── provisioning/
│       ├── dashboards/
│       │   └── dashboards.yml          # Config provisioning dashboards
│       └── datasources/
│           └── datasources.yml         # Config datasources (Prometheus, Jaeger, ES)
└── grafana-apm/
    ├── dashboards/
    │   └── llm-metrics.json            # Dashboard LLM pour Elastic APM
    └── provisioning/
        ├── dashboards/
        └── datasources/
```

### OTel Collector (`otel-collector-config.yaml`)

Le collecteur OTel reçoit les signaux via OTLP et les distribue vers les backends :

| Pipeline | Receivers | Processors | Exporters |
|----------|-----------|------------|-----------|
| **Traces** | OTLP (gRPC + HTTP) | memory_limiter, resource, batch | Jaeger (OTLP), debug |
| **Métriques** | OTLP (gRPC + HTTP) | memory_limiter, resource, batch | Prometheus, debug |
| **Logs** | OTLP (gRPC + HTTP) | memory_limiter, resource, batch | Elasticsearch, debug |

Ports exposés :

| Port | Protocole | Description |
|------|-----------|-------------|
| 4317 | gRPC | Receiver OTLP gRPC |
| 4318 | HTTP | Receiver OTLP HTTP |
| 8889 | HTTP | Exporteur Prometheus |
| 13133 | HTTP | Health check |
| 55679 | HTTP | zPages (debug) |

### Prometheus (`prometheus.yml`)

Scrape les métriques depuis l'exporteur Prometheus du collecteur OTel :

| Job | Target | Description |
|-----|--------|-------------|
| `prometheus` | `localhost:9090` | Auto-scrape Prometheus |
| `otel-collector` | `otel-collector:8889` | Métriques agent via OTel Collector |
| `otel-collector-internal` | `otel-collector:8888` | Métriques internes du collecteur |

---

## Intégration Docker Compose

Deux fichiers docker-compose d'observabilité sont disponibles, offrant deux options de stack :

### Option A : `docker-compose.observability.yml` (OTel + Grafana)

Stack open-source complète avec OTel Collector, Prometheus, Jaeger et Grafana.

```bash
# Prérequis : Elasticsearch doit tourner
docker compose -f docker-compose.yml --profile storage up -d elasticsearch

# Démarrer la stack observabilité
docker compose -f docker-compose.observability.yml up -d
```

| Service | Image | Port | Description |
|---------|-------|------|-------------|
| `otel-collector` | `otel/opentelemetry-collector-contrib:0.96.0` | 4317, 4318, 8889 | Hub central de télémétrie |
| `prometheus` | `prom/prometheus:v2.50.1` | 9090 | Stockage et requêtage de métriques |
| `jaeger` | `jaegertracing/all-in-one:1.54` | 16686 | Backend de tracing distribué |
| `grafana` | `grafana/grafana:10.3.3` | 3000 | Visualisation et dashboards |

Configuration de l'agent :

```bash
OTEL_ENABLED=true
OTEL_SERVICE_NAME=agent_framework
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317
OTEL_EXPORTER_OTLP_PROTOCOL=grpc
```

Accès aux UIs :

| UI | URL | Credentials |
|----|-----|-------------|
| Grafana | http://localhost:3000 | admin / admin |
| Jaeger | http://localhost:16686 | _(aucun)_ |
| Prometheus | http://localhost:9090 | _(aucun)_ |

### Option B : `docker-compose.elastic-apm.yml` (Elastic APM natif)

Stack Elastic native avec APM Server, Elasticsearch dédié et Kibana APM.

```bash
docker compose -f docker-compose.elastic-apm.yml up -d
```

| Service | Image | Port | Description |
|---------|-------|------|-------------|
| `elasticsearch-apm` | `docker.elastic.co/elasticsearch/elasticsearch:8.11.0` | 9201 | ES dédié APM (port 9201 pour éviter conflit) |
| `apm-server` | `docker.elastic.co/apm/apm-server:8.11.0` | 8200 | APM Server avec support OTLP natif |
| `kibana-apm` | `docker.elastic.co/kibana/kibana:8.11.0` | 5601 | Kibana avec dashboards APM intégrés |
| `setup` | — | — | Container d'initialisation des mots de passe |

Configuration de l'agent :

```bash
OTEL_ENABLED=true
OTEL_SERVICE_NAME=agent_framework
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:8200
OTEL_EXPORTER_OTLP_PROTOCOL=grpc
```

Accès aux UIs :

| UI | URL | Credentials |
|----|-----|-------------|
| Kibana APM | http://localhost:5601 | elastic / changeme |
| APM Server | http://localhost:8200 | — |
| Elasticsearch | http://localhost:9201 | elastic / changeme |

Kibana APM fournit automatiquement : Service Overview, Transactions, Dependencies, Errors, Metrics, Service Map.

### Comparaison des Deux Options

| Aspect | Option A (Grafana + Prometheus) | Option B (Elastic APM) |
|--------|-------------------------------|----------------------|
| Dashboards | Manuels (JSON provisionnés) | Auto-générés par Kibana APM |
| Requêtes | PromQL | KQL / Lucene |
| Traces | Jaeger (séparé) | Intégré dans Kibana |
| ML | Non | Intégré (anomaly detection) |
| Configuration | Fichiers YAML | UI Kibana |
| Ressources | Plus léger | Plus gourmand (ES dédié) |

---

## Troubleshooting

| Problème | Solution |
|----------|----------|
| Pas de données dans Kibana | Vérifier `ELASTICSEARCH_ENABLED=true` et `METRICS_ENABLED=true` |
| Index non créé | Le template est créé au démarrage du serveur. Vérifier les logs |
| Token counts semblent bas | Vérifier que `traceloop-sdk` est installé et `LLM_AUTO_INSTRUMENTATION_ENABLED=true` |
| Pas de thinking_tokens | Normal pour les appels LLM simples (sans tool calls) |
| OTel ne fonctionne pas | Vérifier `OTEL_ENABLED=true` et `OTEL_EXPORTER_OTLP_ENDPOINT` configuré |
| Pas de métriques CPU/RAM | Vérifier que `psutil` est installé et `RESOURCE_METRICS_ENABLED=true` |
| Circuit breaker ES ouvert | ES est indisponible. Vérifier la connexion ES et les logs du circuit breaker |
| Logs non envoyés à ES | Vérifier `METRICS_ES_LOGGING_ENABLED=true` et la connexion ES |

### Vérifications

```bash
# Vérifier les indices ES
curl -s "http://localhost:9200/_cat/indices/agent-metrics-*?v"

# Vérifier le template
curl -s "http://localhost:9200/_index_template/agent-metrics-unified-template?pretty"

# Voir un document exemple
curl -s "http://localhost:9200/agent-metrics-*/_search?size=1&pretty"

# Vérifier les champs de timing
curl -s "http://localhost:9200/agent-metrics-*/_search?size=1" | \
  jq '.hits.hits[0]._source | {preprocessing: .preprocessing_duration_ms, llm: .llm_duration_ms, postprocessing: .postprocessing_duration_ms}'

# Vérifier le health check OTel Collector
curl -s "http://localhost:13133/"

# Vérifier Prometheus targets
curl -s "http://localhost:9090/api/v1/targets" | jq '.data.activeTargets[] | {job: .labels.job, health: .health}'
```

---

## Liens Connexes

- [Configuration](./configuration.md) — Référence complète des variables d'environnement
- [Docker Setup](./DOCKER_SETUP.md) — Guide de démarrage Docker
- [Elasticsearch Data Structures](./ELASTICSEARCH_DATA_STRUCTURES.md) — Structure des index ES
- [Architecture Diagram](./ARCHITECTURE_DIAGRAM.md) — Diagramme d'architecture global
