# Skills & Subagents — Analyse comparative et vision d'évolution

## 1. Comment OpenClaw charge les skills

### 1.1 Le skill = un fichier Markdown + des tools natifs de l'agent

La clé de compréhension : dans OpenClaw, **le skill ne fournit pas ses propres tools**. L'agent dispose déjà d'un ensemble de tools natifs puissants, et le skill est simplement un **fichier d'instructions** qui lui dit comment les utiliser.

Les tools natifs disponibles pour tout agent OpenClaw :

| Tool | Rôle |
|------|------|
| `read` | Lire un fichier (y compris le SKILL.md lui-même) |
| `write` | Créer/écraser des fichiers |
| `edit` | Éditer précisément des fichiers |
| `exec` | Exécuter des commandes shell (avec PTY pour les CLIs interactifs) |
| `process` | Gérer des sessions exec en arrière-plan |
| `grep` / `find` / `ls` | Navigation filesystem |
| `web_search` / `web_fetch` | Accès web |
| `browser` | Contrôle navigateur |
| `sessions_spawn` | Spawner un sous-agent |
| `subagents` | Lister/piloter/tuer des sous-agents |
| `sessions_send` | Envoyer un message à une autre session |
| `message` | Envoyer des messages sur les canaux (Telegram, Discord…) |
| `cron` | Planifier des tâches |

Quand un skill comme `weather` dit `curl "wttr.in/London?format=3"`, il utilise le tool `exec` natif. Quand `coding-agent` dit `bash pty:true command:"codex exec '...'"`, c'est encore `exec`. **Le skill ne fait qu'injecter des instructions dans le contexte de l'agent.**

### 1.2 Cycle de vie d'un skill dans OpenClaw

```
Démarrage de l'agent
    │
    ▼
loadSkillEntries(workspaceDir)
    │
    ├─ skills/ bundled (livrés avec OpenClaw)
    ├─ ~/.openclaw/skills/ (managed, installés via clawhub)
    ├─ <workspace>/skills/ (workspace-local)
    ├─ ~/.agents/skills/ (personal agents skills)
    ├─ <workspace>/.agents/skills/ (project agents skills)
    └─ config.skills.load.extraDirs (custom paths)
    │
    ▼
Merge par priorité (extra < bundled < managed < personal < project < workspace)
    │
    ▼
buildWorkspaceSkillsPrompt()
    │
    ├─ Lit le frontmatter YAML de chaque SKILL.md
    ├─ Vérifie les conditions d'éligibilité (bins requis, env vars, OS…)
    ├─ Formate la liste en XML compact : <available_skills><skill><name>…</name><location>…</location></skill>…</available_skills>
    └─ Injecte dans le system prompt sous ## Skills
    │
    ▼
L'agent reçoit la liste des skills disponibles avec leur chemin
    │
    ▼
À la demande (lazy loading) :
    L'agent appelle read(path="~/.../skills/weather/SKILL.md")
    → Lit le contenu complet du fichier
    → Suit les instructions
    → Exécute les commandes via exec/web_search/etc.
```

### 1.3 Structure d'un SKILL.md

```yaml
---
name: weather                          # identifiant unique
description: "Get current weather..."  # affiché dans la liste (compact)
homepage: https://wttr.in/:help        # optionnel
metadata:
  openclaw:
    emoji: "☔"
    primaryEnv: "OPENWEATHER_API_KEY"  # clé API principale (activable par config)
    requires:
      bins: ["curl"]                   # binaires requis sur le système
      env: ["API_KEY"]                 # variables d'env requises
    install:                           # instructions d'installation automatique
      - id: brew
        kind: brew
        formula: curl
        bins: ["curl"]
        label: "Install curl (brew)"
---

# Instructions pour l'agent
## Quand utiliser ce skill
## Commandes disponibles
## Exemples
```

### 1.4 Activation par token API (env overrides)

OpenClaw a un mécanisme d'injection d'env vars par skill via la config :

```yaml
# ~/.openclaw/config.yaml
skills:
  entries:
    weather:
      apiKey: "sk-xxx"          # injecté comme primaryEnv (ex: OPENWEATHER_API_KEY)
      env:
        CUSTOM_VAR: "value"     # variables supplémentaires
```

Au démarrage d'une session, `applySkillEnvOverrides()` injecte ces valeurs dans `process.env` pour la durée de la session, puis les retire proprement. C'est le mécanisme qui permet d'**activer un skill via un token API** : sans la clé, le skill est listé mais non fonctionnel.

---

## 2. Comment AgentFramework gère les skills

### 2.1 Architecture actuelle (scripts par défaut)

Depuis la migration skills-to-scripts, AgentFramework utilise par défaut des **skills Markdown** (`source="markdown"`) qui s'appuient sur des **scripts Python autonomes** exécutés via `ShellTool`. L'ancien système basé sur des classes Python (`AgentTool` subclasses) reste disponible mais est **deprecated**.

#### Mode par défaut : Markdown + Scripts

```
SkillRegistry
    └─ Skill (chargé depuis SKILL.md)
         ├─ SkillMetadata (name, description, trigger_patterns, category)
         ├─ instructions: str              ← contenu du SKILL.md (commandes shell)
         ├─ tools: [ShellTool, WebFetchTool]  ← tools natifs attachés automatiquement
         └─ dependencies: list[str]

Flux d'exécution :
    Agent appelle load_skill("excel")
    → SkillRegistry retourne instructions du SKILL.md + ShellTool/WebFetchTool
    → Agent lit les instructions et construit la commande shell
    → Agent appelle shell_exec("uv run python scripts/skills/create_excel.py --filename report.xlsx")
    → Le script écrit le fichier et affiche le résultat JSON sur stdout
```

#### Mode legacy (deprecated) : Python tools

```
SkillRegistry
    └─ Skill (chargé depuis factory Python)
         ├─ SkillMetadata (name, description, trigger_patterns, category)
         ├─ instructions: str | Path
         ├─ tools: list[AgentTool]        ← tools Python (ChartToImageTool, etc.)
         └─ dependencies: list[str]

⚠️ Utiliser source="python" émet un DeprecationWarning.
```

Le `SkillsMixin` injecté dans `BaseAgent` expose 3 tools à l'agent LLM :
- `list_skills()` → catalogue des skills disponibles
- `load_skill(name)` → charge un skill (instructions + tools)
- `unload_skill(name)` → libère un skill

**Changement clé** : les skills builtin n'utilisent plus de tools Python par défaut. L'agent exécute des scripts autonomes via `uv run python scripts/skills/<script>.py` en passant par `ShellTool`. Les scripts utilisent `argparse` pour les paramètres et retournent du JSON sur stdout.

### 2.2 Comparaison des approches de chargement

| Capacité | OpenClaw | AgentFramework | Statut |
|----------|----------|----------------|--------|
| Skills Markdown purs (instructions only) | ✅ natif | ✅ `MarkdownSkillLoader` | ✅ Implémenté |
| Tools shell/exec natifs | ✅ `exec` tool | ✅ `ShellTool` (timeout 60s) | ✅ Implémenté |
| Scripts autonomes par skill | — | ✅ 12 scripts dans `scripts/skills/` | ✅ Implémenté |
| Coexistence legacy/nouveau | — | ✅ `source="python"` (deprecated) | ✅ Implémenté |
| Activation par token API | ✅ `apiKey` + env overrides | ❌ | `CapabilityResolver` à construire |
| Skills depuis dossiers externes | ✅ extraDirs | ❌ | Loader de dossiers à ajouter |
| Subagents | ✅ `sessions_spawn` | ❌ | Architecture à définir |
| Dépendances binaires (bins check) | ✅ frontmatter `requires.bins` | ⚠️ Déclaré dans frontmatter | Validation runtime à ajouter |

---

## 3. Les Subagents dans OpenClaw

### 3.1 Concept

Un subagent est une **session d'agent isolée** spawné par un agent parent pour une tâche spécifique. C'est du vrai parallélisme : chaque subagent a son propre contexte, ses propres tools, et s'exécute indépendamment.

```
Agent principal (session A)
    │
    ├─ sessions_spawn(task="Analyse les logs", runtime="subagent")
    │       └─ Subagent B (session isolée)
    │              ├─ Reçoit un system prompt spécifique (buildSubagentSystemPrompt)
    │              ├─ Exécute sa tâche
    │              └─ Annonce son résultat → auto-deliver à la session A
    │
    ├─ sessions_spawn(task="Cherche les PRs", runtime="acp", agentId="codex")
    │       └─ ACP Harness (Codex/Claude Code/Gemini dans un thread)
    │
    └─ Attend les completion events (push-based, pas de polling)
```

### 3.2 System prompt d'un subagent

`buildSubagentSystemPrompt()` génère un prompt minimaliste qui :
- Définit le rôle ("tu es un subagent, ta tâche est X")
- Interdit les actions hors-scope (pas de heartbeats, pas de messages externes)
- Gère la profondeur de spawn (depth 1 peut spawner, depth 2 = leaf worker)
- Explique le mécanisme push-based (ne pas poller, attendre les completion events)

### 3.3 Mécanisme de completion

```
Subagent termine
    │
    ▼
runSubagentAnnounceFlow()
    │
    ├─ Lit l'output du subagent (readSubagentOutput)
    ├─ Formate les findings (buildChildCompletionFindings)
    └─ Délivre à la session parente via :
         ├─ Queue (maybeQueueSubagentAnnounce) → si parent actif
         └─ Direct (sendSubagentAnnounceDirectly) → sinon
```

### 3.4 Types de runtimes

| Runtime | Description |
|---------|-------------|
| `subagent` | Agent OpenClaw isolé, même stack |
| `acp` | ACP Harness : Codex, Claude Code, Gemini dans un thread Discord/Telegram |

---

## 4. Vision : AgentFramework avec capacités activables par token

### 4.1 Architecture cible

```
Token API
    │
    ▼
CapabilityResolver.resolve(token)
    → ["web_search", "pdf", "chart", "shell", "subagent:spawn"]
    │
    ▼
SessionCapabilityContext
    ├─ Skills autorisés (filtrés par token)
    ├─ Tools natifs autorisés (shell, web, etc.)
    └─ Subagent depth max
    │
    ▼
Agent démarre avec UNIQUEMENT les capacités autorisées
```

### 4.2 Ce qu'il faut construire

#### A. `ShellTool` — ✅ Implémenté

`ShellTool` est maintenant disponible dans `agent_framework/tools/shell_tool.py`. Il est automatiquement attaché à chaque skill chargé via `source="markdown"` avec un timeout par défaut de 60 secondes.

```python
from agent_framework.tools.shell_tool import ShellTool

shell = ShellTool(default_timeout=60)
shell_exec = shell.get_tool_function()

# Exécuter un script de skill
result = shell_exec("uv run python scripts/skills/create_excel.py --filename report.xlsx")
```

#### B. `MarkdownSkillLoader` — ✅ Implémenté

`MarkdownSkillLoader` est disponible dans `agent_framework/skills/markdown_loader.py`. Il charge les fichiers SKILL.md et crée des objets `Skill` avec les instructions Markdown. `ShellTool` et `WebFetchTool` sont attachés automatiquement par `_get_builtin_skills_from_markdown()`.

```python
from agent_framework.skills.markdown_loader import MarkdownSkillLoader

loader = MarkdownSkillLoader()
skills = loader.load_from_dir(skills_dir)
# Chaque skill a : instructions (commandes uv run python), tools=[]
# ShellTool + WebFetchTool sont attachés par le builtin loader
```

#### C. `CapabilityResolver` — activation par token API (à construire)

```python
class CapabilityResolver:
    """Résout les capacités autorisées à partir d'un token API."""
    
    def resolve(self, api_token: str) -> CapabilitySet:
        """
        Retourne les capacités autorisées pour ce token.
        Sources supportées :
        - Fichier JSON local (dev/simple)
        - Variable d'env (CI/CD)
        - Appel HTTP (production)
        """
        ...

@dataclass
class CapabilitySet:
    skill_ids: list[str]           # skills autorisés
    native_tools: list[str]        # tools natifs autorisés (shell, web, etc.)
    max_subagent_depth: int        # profondeur de spawn max
    env_overrides: dict[str, str]  # variables d'env injectées (clés API)
```

#### D. Subagents — architecture à définir

Dans AgentFramework, les subagents peuvent être implémentés comme :

```python
class SubagentSpawnTool(AgentTool):
    """Spawne un sous-agent pour une tâche spécifique."""
    
    def get_tool_function(self) -> Callable:
        async def spawn_subagent(
            task: str,
            agent_id: str | None = None,
            skill_ids: list[str] | None = None,
        ) -> str:
            """
            Crée une session d'agent isolée pour la tâche donnée.
            Retourne un session_id pour suivre la progression.
            """
            ...
```

Le mécanisme de completion peut être push-based (callback) ou poll-based selon le transport (HTTP, WebSocket, queue).

### 4.3 Roadmap suggérée

**Phase 1 — Foundation (unlock les skills Markdown)** ✅ Complète
1. ✅ `ShellTool` avec timeout configurable (60s par défaut pour les skills)
2. ✅ `MarkdownSkillLoader` + parsing frontmatter YAML
3. ✅ Intégration dans `SkillsMixin.register_builtin_skills()` (défaut `source="markdown"`)
4. ✅ 12 scripts autonomes dans `scripts/skills/` (exécutés via `uv run python`)
5. ✅ SKILL.md réécrits pour référencer les scripts
6. ✅ Discovery prompt mis à jour pour le workflow scripts
7. ✅ Système legacy (`source="python"`) conservé avec `DeprecationWarning`

**Phase 2 — Activation par token**
4. `CapabilitySet` dataclass
5. `CapabilityResolver` (JSON local d'abord, HTTP ensuite)
6. `env_overrides` injectés à la session (comme OpenClaw)
7. Filtrage des skills au démarrage selon le token

**Phase 3 — Subagents**
8. `SubagentSpawnTool`
9. `SubagentRegistry` (sessions actives)
10. Mécanisme de completion (push ou poll)
11. System prompt minimaliste pour les subagents (comme `buildSubagentSystemPrompt`)

---

## 5. Résumé des différences architecturales

| Aspect | OpenClaw (TypeScript) | AgentFramework (Python) |
|--------|----------------------|------------------------|
| Skills | Fichiers SKILL.md (Markdown) | SKILL.md par défaut (`source="markdown"`) ; Python tools deprecated (`source="python"`) |
| Tools | Natifs dans l'agent (exec, read, web…) | `ShellTool` + `WebFetchTool` (natifs, attachés auto) ; Python tools legacy disponibles |
| Exécution | `exec` → commandes shell | `shell_exec` → `uv run python scripts/skills/<script>.py` |
| Chargement | Lazy (l'agent lit le SKILL.md à la demande) | Eager (skills chargés au démarrage, `source="markdown"` par défaut) |
| Scripts | N/A (tout passe par `exec`) | 12 scripts autonomes dans `scripts/skills/` (argparse + JSON stdout) |
| Activation | Token API → env overrides → skill éligible | `ENABLE_SKILLS` env var globale (token API à venir) |
| Subagents | `sessions_spawn` → session isolée | Non implémenté |
| Profondeur | Configurable (maxSpawnDepth) | N/A |
| Completion | Push-based (auto-announce) | N/A |

**La leçon principale d'OpenClaw** : les skills ne fournissent pas leurs propres tools — ils s'appuient sur des tools natifs puissants (surtout `exec`). C'est ce qui rend le système extensible sans code : n'importe qui peut écrire un SKILL.md qui utilise n'importe quel CLI.

**Pour AgentFramework**, la Phase 1 est maintenant complète :
1. **Tools natifs** (`ShellTool`, `WebFetchTool`) — attachés automatiquement aux skills markdown
2. **Scripts autonomes** (12 scripts dans `scripts/skills/`) — exécutés via `uv run python`, remplacent les tools Python
3. **Coexistence** — `source="python"` reste fonctionnel avec `DeprecationWarning`

Les prochaines étapes sont l'activation par token API (`CapabilityResolver`) et les subagents.
