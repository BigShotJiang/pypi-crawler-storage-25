"""GistSafe - Secure secret management using GitHub Gists."""

__version__ = "0.3.0"
