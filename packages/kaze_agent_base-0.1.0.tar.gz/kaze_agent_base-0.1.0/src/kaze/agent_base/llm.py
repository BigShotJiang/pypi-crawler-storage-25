"""Single entrypoint for all direct ``litellm.acompletion`` calls.

Why this exists: the ADK ``Agent`` path has its callbacks
(``framework/workflow/callbacks.py::before_model``) that thread the
parent Langfuse ``trace_id`` into every LLM call so all of one
request's calls land under the same trace tree. But the **direct**
``litellm.acompletion`` calls we make from playbook code (intent
classifier, intelligence extractor, composer, etc.) bypass that path —
each one used to start its own root trace, making it impossible to
follow a single user request through Langfuse.

This module fixes that for good. Every direct litellm call from plugin
code MUST go through ``acompletion(...)`` here. It auto-injects:

  - the resolved ``(model, api_base, api_key, extra_headers)`` from the
    tier name, so callsites don't repeat ``resolve_model_kwargs(...)``
  - the parent Langfuse ``trace_id`` from the request-scoped trace
    header, so all calls share one trace tree
  - standard ``metadata`` fields (session_id, agent, namespace) and
    a default tag set, with caller-supplied metadata/tags merged on top

Calling ``litellm.acompletion`` directly anywhere outside this module
is a bug — it breaks trace linkage. Add to your callsite via this
wrapper instead.
"""

from __future__ import annotations

import contextvars
import logging
import os
from typing import Any

import litellm

from .models import _trace_headers, resolve_model_kwargs

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT_S = 60


def ensure_langfuse_callback() -> None:
    """Register LiteLLM's Langfuse callback on first use.

    Called from both the ADK Agent path (``models.get_model``) and the
    direct call path (this module's ``acompletion``), whichever runs
    first. Idempotent: litellm stores callbacks as a list, so adding
    "langfuse" again is a no-op.
    """
    if not os.environ.get("LANGFUSE_PUBLIC_KEY"):
        return
    if "langfuse" not in (litellm.success_callback or []):
        litellm.success_callback = list(litellm.success_callback or []) + ["langfuse"]
    if "langfuse" not in (litellm.failure_callback or []):
        litellm.failure_callback = list(litellm.failure_callback or []) + ["langfuse"]


ensure_langfuse_callback()


# Request-scoped parent Langfuse trace_id. ContextVar auto-propagates
# through async awaits within the same context (e.g., all calls inside
# one router.handle_request invocation inherit the value automatically).
# ContextVar is the right tool here because ``_trace_headers`` was a
# module-global that unsafe under concurrent requests.
_current_trace_id: contextvars.ContextVar[str] = contextvars.ContextVar(
    "kaze_llm_trace_id", default="",
)


def set_trace_id(trace_id: str) -> contextvars.Token:
    """Set the parent trace_id for the current request scope.

    Two side effects, both needed because the Kaze Gateway reads the
    trace id from the ``X-Kaze-Trace-Id`` HTTP header only (see
    ``kaze-gateway/src/auth.ts::resolveIdentity``):

    1. Binds a request-scoped ContextVar, read by direct callers of
       ``acompletion(...)`` (classifier, intelligence extractor,
       composer) — ContextVar auto-propagates through async awaits.

    2. Mutates the module-global ``framework.models._trace_headers``
       dict. The ADK Agent's ``LiteLlm`` instance was constructed with
       ``extra_headers=_trace_headers`` (a shared reference), so
       mutating this dict causes every subsequent Agent LLM call to
       pick up the new header on its next request. Without this side
       effect, the ADK Agent path goes out with an empty trace_id and
       every Agent call is an orphan trace.

    Returns a ``Token`` that the caller passes to ``reset_trace_id``
    when the scope ends — restores the prior ContextVar value AND
    clears the trace_id from ``_trace_headers`` so it doesn't leak to
    subsequent unrelated requests on the same pod.

    Typical callers:
      - ``router.handle_request`` at the top of every user turn, using
        ``tool_context.state["_trace_id"]``
      - ``workflows/digest/workflow.py::_compose_for_background`` at
        entry, using the trace_id passed through build params
      - ``workflow/callbacks.py::before_model`` to cover the ADK Agent
        path, using ``callback_context.state["_trace_id"]``
    """
    _trace_headers["X-Kaze-Trace-Id"] = trace_id
    return _current_trace_id.set(trace_id)


def reset_trace_id(token: contextvars.Token) -> None:
    """Undo a ``set_trace_id`` call. Paired in try/finally at scope exit.

    Restores both side effects: the ContextVar via the token, and clears
    the module-global ``_trace_headers`` entry so a stale id can't leak
    to a later unrelated request handled on the same pod.
    """
    _current_trace_id.reset(token)
    # After reset, the ContextVar holds whatever was there before this
    # set() call (typically "" at the outermost scope). Keep the shared
    # ``_trace_headers`` dict in sync so Agent LLM calls after scope
    # exit don't carry the stale id.
    _trace_headers["X-Kaze-Trace-Id"] = _current_trace_id.get()


def get_trace_id() -> str:
    """Current request's parent trace_id, or empty string if unset."""
    return _current_trace_id.get()


def _request_metadata(extra: dict[str, Any] | None = None) -> dict[str, Any]:
    """Build the standard metadata block injected into every direct LLM call.

    Caller-provided keys win EXCEPT ``trace_id`` — that's framework-owned
    so callers can't accidentally break trace linkage.
    """
    md: dict[str, Any] = {
        "agent": "ops-agent",
        "namespace": os.environ.get("KAZE_MEMORY_NAMESPACE", "ops"),
        "environment_id": os.environ.get("KAZE_ENVIRONMENT_ID", "dev"),
    }
    if extra:
        md.update({k: v for k, v in extra.items() if k != "trace_id"})
    parent_trace_id = get_trace_id()
    if parent_trace_id:
        md["trace_id"] = parent_trace_id
    return md


def _request_tags(extra: list[str] | None = None) -> list[str]:
    base = ["kaze", "ops"]
    if extra:
        return base + [t for t in extra if t not in base]
    return base


async def acompletion(
    *,
    tier: str,
    messages: list[dict],
    metadata: dict[str, Any] | None = None,
    tags: list[str] | None = None,
    timeout: float = DEFAULT_TIMEOUT_S,
    **extra_kwargs: Any,
) -> Any:
    """Call ``litellm.acompletion`` with auto-injected trace + tier resolution.

    Trace linkage works via two channels:

    1. **Client-side Langfuse** (when ``LANGFUSE_PUBLIC_KEY`` is set):
       the LiteLLM Langfuse callback reads ``metadata.trace_id`` from
       the call and groups spans under that trace.

    2. **Server-side Kaze Gateway tracing** (the prod path): the gateway
       reads the ``X-Kaze-Trace-Id`` HTTP header on each request and
       attaches the server-side Langfuse span to that trace id.

    Both channels need the SAME trace_id to be honored. This wrapper
    injects it on both: metadata for LiteLLM, ``extra_headers`` for
    the gateway.

    Args:
        tier: model tier name. Resolved via ``resolve_model_kwargs(tier)``.
        messages: standard OpenAI-format messages.
        metadata: Langfuse metadata. Caller cannot override ``trace_id``.
        tags: Langfuse tags appended to ``["kaze", "ops"]``.
        timeout: per-call timeout in seconds.
        **extra_kwargs: forwarded to ``litellm.acompletion``.
    """
    model, gw_extra = resolve_model_kwargs(tier)

    # Overlay the ContextVar trace_id onto the gateway's HTTP headers.
    # resolve_model_kwargs snapshots ``_trace_headers`` at import time
    # (usually empty), so we stamp the current request's id here.
    #
    # IMPORTANT: the Kaze Gateway (port 4200) is what reads this header
    # and groups LLM calls under a single Langfuse trace. LiteLLM direct
    # (port 4201) ignores the header entirely — if KAZE_GATEWAY_URL
    # points at the wrong port, headers do nothing and every call
    # becomes an orphan trace.
    parent_trace_id = get_trace_id()
    if parent_trace_id and "extra_headers" in gw_extra:
        headers = dict(gw_extra["extra_headers"])
        headers["X-Kaze-Trace-Id"] = parent_trace_id
        gw_extra = {**gw_extra, "extra_headers": headers}

    return await litellm.acompletion(
        model=model,
        messages=messages,
        timeout=timeout,
        metadata=_request_metadata(metadata),
        tags=_request_tags(tags),
        **gw_extra,
        **extra_kwargs,
    )
