"""Persistent configuration backed by SQLite.

Stores all mutable agent config in a single SQLite DB:
  - channel:*   — Channel config (Telegram, Slack, WhatsApp)
  - secret:*    — Credentials (GitHub, Linear, etc.)
  - setting:*   — Agent settings (model_hint, max_steps, etc.)

On first boot, seeds from agent.yaml defaults + environment variables.
Updated at runtime via /config/* API. Persists on PVC across restarts.
"""

import json
import os
import re
import sqlite3
import logging
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

REPO_ROOT = Path(__file__).parent.parent
AGENT_YAML = REPO_ROOT / "agent.yaml"
CONFIG_YAML = REPO_ROOT / "config.yaml"
DB_DIR = Path(os.environ.get("KAZE_DATA_DIR", str(REPO_ROOT / ".adk")))
DB_PATH = DB_DIR / "config.db"


def _get_db() -> sqlite3.Connection:
    DB_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def _init_db(conn: sqlite3.Connection) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS config (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    """)
    conn.commit()


def _seed(conn: sqlite3.Connection) -> None:
    """Seed config from agent.yaml + env vars if DB is empty."""
    row = conn.execute("SELECT COUNT(*) as c FROM config").fetchone()
    if row["c"] > 0:
        return

    if not AGENT_YAML.exists():
        logger.warning("agent.yaml not found, skipping seed")
        return

    agent = yaml.safe_load(AGENT_YAML.read_text())
    kaze = agent.get("kaze", {})

    # Agent identity
    conn.execute("INSERT INTO config (key, value) VALUES (?, ?)",
                 ("agent_name", agent.get("name", "Kazane")))
    conn.execute("INSERT INTO config (key, value) VALUES (?, ?)",
                 ("agent_app_name", os.environ.get("KAZE_APP_NAME", "kaze_app")))
    conn.execute("INSERT INTO config (key, value) VALUES (?, ?)",
                 ("agent_url", f"http://localhost:{os.environ.get('KAZE_A2A_PORT', '8080')}"))

    # Channel config
    for name, conf in kaze.get("channels", {}).items():
        resolved = {}
        for k, v in conf.items():
            if isinstance(v, str) and v.startswith("{{env:") and v.endswith("}}"):
                resolved[k] = os.environ.get(v[6:-2], "")
            else:
                resolved[k] = v
        conn.execute("INSERT INTO config (key, value) VALUES (?, ?)",
                     (f"channel:{name}", json.dumps(resolved)))

    # Secrets — seed from MCP server env vars in config.yaml
    if CONFIG_YAML.exists():
        config = yaml.safe_load(CONFIG_YAML.read_text())
        seen_env_vars: set[str] = set()
        for server_conf in config.get("mcp_servers", {}).values():
            for env_key, env_val in server_conf.get("env", {}).items():
                # Extract env var name from {{VAR}} template
                match = re.match(r"^\{\{(\w+)\}\}$", str(env_val))
                if match:
                    var_name = match.group(1)
                    if var_name not in seen_env_vars:
                        seen_env_vars.add(var_name)
                        conn.execute(
                            "INSERT INTO config (key, value) VALUES (?, ?)",
                            (f"secret:{var_name}", os.environ.get(var_name, "")),
                        )

    # Settings — seed from env vars
    for env_key, setting_key in [
        ("KAZE_MODEL_HINT", "setting:model_hint"),
        ("KAZE_MAX_STEPS", "setting:max_steps"),
        ("KAZE_MAX_TOKENS", "setting:max_tokens"),
    ]:
        val = os.environ.get(env_key)
        if val:
            conn.execute("INSERT INTO config (key, value) VALUES (?, ?)",
                         (setting_key, val))

    conn.commit()
    logger.info("Seeded config from agent.yaml + env vars")


class ConfigStore:
    """Read/write agent configuration from SQLite."""

    def __init__(self):
        self._conn = _get_db()
        _init_db(self._conn)
        _seed(self._conn)

    # ── Generic ────────────────────────────────────────────────

    def get(self, key: str) -> str | None:
        row = self._conn.execute(
            "SELECT value FROM config WHERE key = ?", (key,)
        ).fetchone()
        return row["value"] if row else None

    def set(self, key: str, value: str) -> None:
        self._conn.execute(
            "INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)",
            (key, value),
        )
        self._conn.commit()

    def delete(self, key: str) -> None:
        self._conn.execute("DELETE FROM config WHERE key = ?", (key,))
        self._conn.commit()

    def get_all(self) -> dict[str, str]:
        rows = self._conn.execute("SELECT key, value FROM config").fetchall()
        return {r["key"]: r["value"] for r in rows}

    def get_by_prefix(self, prefix: str) -> dict[str, str]:
        rows = self._conn.execute(
            "SELECT key, value FROM config WHERE key LIKE ?", (f"{prefix}%",)
        ).fetchall()
        return {r["key"]: r["value"] for r in rows}

    # ── Channels ───────────────────────────────────────────────

    def get_channel(self, name: str) -> dict | None:
        raw = self.get(f"channel:{name}")
        return json.loads(raw) if raw else None

    def set_channel(self, name: str, config: dict) -> None:
        self.set(f"channel:{name}", json.dumps(config))

    def delete_channel(self, name: str) -> None:
        self.delete(f"channel:{name}")

    # ── Secrets ────────────────────────────────────────────────

    def get_secret(self, name: str) -> str | None:
        return self.get(f"secret:{name}")

    def set_secret(self, name: str, value: str) -> None:
        self.set(f"secret:{name}", value)

    def get_all_secrets(self) -> dict[str, str]:
        """Returns {VAR_NAME: value} without the secret: prefix."""
        raw = self.get_by_prefix("secret:")
        return {k.removeprefix("secret:"): v for k, v in raw.items()}

    # ── Settings ───────────────────────────────────────────────

    def get_setting(self, name: str) -> str | None:
        return self.get(f"setting:{name}")

    def set_setting(self, name: str, value: str) -> None:
        self.set(f"setting:{name}", value)

    # ── Gateway config (for channel-gateway sidecar) ───────────

    def get_gateway_clients_config(self) -> list[dict[str, Any]]:
        """Build the ClientConfig[] array the channel-gateway expects."""
        agent_url = self.get("agent_url") or f"http://localhost:{os.environ.get('KAZE_A2A_PORT', '8080')}"
        agent_app_name = self.get("agent_app_name") or os.environ.get("KAZE_APP_NAME", "kaze_app")
        client_id = self.get("agent_name") or "kazane"

        channels: dict[str, Any] = {}
        all_config = self.get_all()

        for key, value in all_config.items():
            if not key.startswith("channel:"):
                continue
            channel_name = key.split(":", 1)[1]
            conf = json.loads(value)

            # Shared gating knobs — legacy (allowedGroups + requireMention)
            # plus explicit enums (groupPolicy + groupActivation) and
            # custom nicknames (mentionAliases). The gateway accepts both
            # and prefers the explicit forms when set.
            def _gating(src: dict[str, Any]) -> dict[str, Any]:
                out: dict[str, Any] = {}
                if src.get("groupPolicy"):
                    out["groupPolicy"] = src["groupPolicy"]
                if src.get("groupActivation"):
                    out["groupActivation"] = src["groupActivation"]
                aliases = src.get("mentionAliases")
                if aliases:
                    out["mentionAliases"] = [str(a) for a in aliases]
                return out

            if channel_name == "telegram" and conf.get("enabled", True):
                channels["telegram"] = {
                    "enabled": True,
                    "token": conf.get("botToken", ""),
                    "allowedGroups": [str(g) for g in conf.get("allowFrom", [])],
                    "requireMention": conf.get("requireMention", True),
                    **_gating(conf),
                }
            elif channel_name == "slack" and conf.get("enabled", True):
                channels["slack"] = {
                    "enabled": True,
                    "botToken": conf.get("botToken", ""),
                    "appToken": conf.get("appToken", ""),
                    "allowedChannels": conf.get("allowedChannels", []),
                    "requireMention": conf.get("requireMention", True),
                    **_gating(conf),
                }
            elif channel_name == "whatsapp" and conf.get("enabled", True):
                # Default to the PVC-backed path so creds survive restarts.
                default_auth = os.environ.get("WHATSAPP_AUTH_DIR", "./.whatsapp-auth")
                wa_config: dict[str, Any] = {
                    "enabled": True,
                    "authDir": conf.get("authDir") or default_auth,
                    "allowedGroups": [str(g) for g in conf.get("allowedGroups", [])],
                    "requireMention": conf.get("requireMention", True),
                    **_gating(conf),
                }
                if conf.get("pairingPhone"):
                    wa_config["pairingPhone"] = conf["pairingPhone"]
                channels["whatsapp"] = wa_config

        return [{
            "clientId": client_id.lower().replace(" ", "-"),
            "agentUrl": agent_url,
            "agentAppName": agent_app_name,
            "channels": channels,
        }]
