"""mem0-backed memory service with pgvector + LiteLLM gateway routing.

`Mem0MemoryService` implements ADK's `BaseMemoryService` so existing call
sites (`tool_context.add_memory`, session persistence) keep working while
we swap the backend underneath.

Per-turn flow is wired by the workflow callbacks (`before_agent` /
`after_agent` in `framework.workflow.callbacks`), not here — this file
is purely the storage + retrieval adapter.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Mapping, Sequence
from typing import Any, Optional
from urllib.parse import urlparse

import anyio
from google.adk.memory.base_memory_service import BaseMemoryService, SearchMemoryResponse
from google.adk.memory.memory_entry import MemoryEntry
from google.genai import types
from mem0 import Memory

from ..models import get_gateway_endpoint

logger = logging.getLogger(__name__)


DEFAULT_DB_URL = "postgresql://kaze:kaze@localhost:5432/kaze"
DEFAULT_COLLECTION = "kazane_memories"
DEFAULT_EXTRACT_MODEL = "google/gemini-2.5-flash"
DEFAULT_EMBED_MODEL = "google/gemini-embedding-001"
DEFAULT_EMBED_DIMS = 768
DEFAULT_TOP_K = 20
DEFAULT_SEARCH_TIMEOUT_S = 2.0
DEFAULT_WRITE_TIMEOUT_S = 5.0

# Role strings used on the boundary to/from mem0. mem0 expects OpenAI-
# style "user"/"assistant"; ADK Events sometimes carry role="model".
ROLE_USER = "user"
ROLE_ASSISTANT = "assistant"
_ASSISTANT_ROLES = {"assistant", "model"}


def _parse_db_url(url: str) -> dict[str, Any]:
    """Parse postgresql://user:password@host:port/dbname → dict for mem0."""
    p = urlparse(url)
    if p.scheme not in ("postgresql", "postgres"):
        raise ValueError(f"KAZE_MEM0_DB_URL must be postgresql://, got {url!r}")
    return {
        "host": p.hostname or "localhost",
        "port": p.port or 5432,
        "user": p.username or "kaze",
        "password": p.password or "",
        "dbname": (p.path or "/kaze").lstrip("/"),
    }


def build_mem0_config() -> dict[str, Any]:
    """mem0 config routing LLM + embedder through the Kaze gateway and
    persisting vectors in the kaze Postgres via pgvector.
    """
    gateway, api_key = get_gateway_endpoint()
    db = _parse_db_url(os.environ.get("KAZE_MEM0_DB_URL", DEFAULT_DB_URL))
    collection = os.environ.get("KAZE_MEM0_COLLECTION", DEFAULT_COLLECTION)
    extract_model = os.environ.get("KAZE_MEM0_EXTRACT_MODEL", DEFAULT_EXTRACT_MODEL)
    embed_model = os.environ.get("KAZE_MEM0_EMBED_MODEL", DEFAULT_EMBED_MODEL)
    embed_dims = int(os.environ.get("KAZE_MEM0_EMBED_DIMS", DEFAULT_EMBED_DIMS))

    return {
        "llm": {
            "provider": "openai",
            "config": {
                "model": extract_model,
                "api_key": api_key,
                "openai_base_url": gateway,
            },
        },
        "embedder": {
            "provider": "openai",
            "config": {
                "model": embed_model,
                "api_key": api_key,
                "openai_base_url": gateway,
                "embedding_dims": embed_dims,
            },
        },
        "vector_store": {
            "provider": "pgvector",
            "config": {
                **db,
                "collection_name": collection,
                "embedding_model_dims": embed_dims,
            },
        },
        "version": "v1.1",
    }


def _content_to_text(content: Optional[types.Content]) -> str:
    if not content or not content.parts:
        return ""
    return " ".join(p.text for p in content.parts if p.text)


def _text_to_content(text: str, role: str = ROLE_USER) -> types.Content:
    return types.Content(role=role, parts=[types.Part(text=text)])


def format_preamble(memories: Sequence[MemoryEntry]) -> str:
    """Render memories into the system-prompt block used by `before_agent`."""
    lines = ["## What you know about this user", ""]
    start_len = len(lines)
    for m in memories:
        text = _content_to_text(m.content).strip()
        if text:
            lines.append(f"- {text}")
    return "\n".join(lines) if len(lines) > start_len else ""


class Mem0MemoryService(BaseMemoryService):
    """ADK `BaseMemoryService` adapter for mem0.

    - `add_memory`  → `mem0.add(messages, user_id=...)` (runs extraction LLM)
    - `search_memory` → `mem0.search(query, user_id=...)` (vector search)
    - `add_session_to_memory` → adds the latest (user, assistant) pair
    """

    def __init__(
        self,
        config: Optional[dict[str, Any]] = None,
        *,
        top_k: Optional[int] = None,
        client: Optional[Memory] = None,
        search_timeout_s: float = DEFAULT_SEARCH_TIMEOUT_S,
        write_timeout_s: float = DEFAULT_WRITE_TIMEOUT_S,
    ):
        self._config = config or build_mem0_config()
        self._top_k = top_k if top_k is not None else int(
            os.environ.get("KAZE_MEM0_TOP_K", DEFAULT_TOP_K)
        )
        self._client: Optional[Memory] = client
        self._search_timeout = search_timeout_s
        self._write_timeout = write_timeout_s
        collection = (
            self._config.get("vector_store", {}).get("config", {}).get("collection_name", "?")
        )
        logger.info(
            "Mem0MemoryService configured (collection=%s, top_k=%d)", collection, self._top_k
        )

    @property
    def client(self) -> Memory:
        """Lazy-init so importing this module doesn't require pg to be up."""
        if self._client is None:
            self._client = Memory.from_config(self._config)
        return self._client

    async def _write_messages(
        self,
        messages: list[dict],
        *,
        user_id: str,
        metadata: Optional[Mapping[str, object]] = None,
        log_tag: str = "mem0.add",
    ) -> None:
        """Shared path for `add_memory` and `add_session_to_memory`: push
        messages through mem0's extraction pipeline with a write-side timeout
        and a graceful-failure log. Never raises to the caller.
        """
        if not messages:
            return

        def _write():
            return self.client.add(
                messages,
                user_id=user_id,
                metadata=dict(metadata) if metadata else None,
            )

        try:
            with anyio.move_on_after(self._write_timeout) as scope:
                result = await anyio.to_thread.run_sync(_write)
            if scope.cancelled_caught:
                logger.warning("%s timeout (%ss) for %s", log_tag, self._write_timeout, user_id)
                return
        except Exception as e:
            logger.warning("%s failed for %s: %s", log_tag, user_id, e)
            return

        ops = (result or {}).get("results") or []
        if ops:
            logger.info(
                "%s: %d ops for %s (%s)",
                log_tag,
                len(ops),
                user_id,
                ", ".join(o.get("event", "?") for o in ops),
            )

    async def add_memory(
        self,
        *,
        app_name: str,
        user_id: str,
        memories: Sequence[MemoryEntry],
        custom_metadata: Mapping[str, object] | None = None,
    ) -> None:
        """Persist memories via mem0. Each MemoryEntry becomes a user message
        that mem0's extraction LLM distills into one or more facts.

        `app_name` is currently ignored — multi-app separation isn't needed.
        """
        messages: list[dict] = []
        for entry in memories:
            text = _content_to_text(entry.content).strip()
            if not text:
                continue
            role = (entry.content.role if entry.content else None) or ROLE_USER
            messages.append({"role": role, "content": text})

        await self._write_messages(
            messages,
            user_id=user_id,
            metadata=custom_metadata,
            log_tag="mem0.add",
        )

    async def search_memory(
        self,
        *,
        app_name: str,
        user_id: str,
        query: str,
    ) -> SearchMemoryResponse:
        """Semantic search via mem0 → ADK `SearchMemoryResponse`."""
        if not query or not query.strip():
            return SearchMemoryResponse()

        def _read():
            return self.client.search(
                query,
                filters={"user_id": user_id},
                limit=self._top_k,
            )

        try:
            with anyio.move_on_after(self._search_timeout) as scope:
                result = await anyio.to_thread.run_sync(_read)
            if scope.cancelled_caught:
                logger.warning(
                    "mem0.search timeout (%ss) for %s", self._search_timeout, user_id
                )
                return SearchMemoryResponse()
        except Exception as e:
            logger.warning("mem0.search failed for %s: %s", user_id, e)
            return SearchMemoryResponse()

        hits = (result or {}).get("results") or []
        entries: list[MemoryEntry] = []
        for h in hits:
            text = h.get("memory", "")
            if not text:
                continue
            entries.append(
                MemoryEntry(
                    content=_text_to_content(text),
                    id=h.get("id"),
                    author="mem0",
                    timestamp=h.get("updated_at") or h.get("created_at"),
                )
            )
        return SearchMemoryResponse(memories=entries)

    async def add_session_to_memory(self, session) -> None:
        """Push the latest (user, assistant) pair from the session to mem0."""
        events = getattr(session, "events", None) or []
        if not events:
            return

        last_user_text = ""
        last_asst_text = ""
        for event in reversed(events):
            content = getattr(event, "content", None)
            if not content:
                continue
            text = _content_to_text(content).strip()
            if not text:
                continue
            role = (content.role or "").lower()
            author = (getattr(event, "author", "") or "").lower()
            is_user = role == ROLE_USER or author == ROLE_USER
            is_asst = role in _ASSISTANT_ROLES or (author and author != ROLE_USER)
            if is_user and not last_user_text:
                last_user_text = text
            elif is_asst and not last_asst_text:
                last_asst_text = text
            if last_user_text and last_asst_text:
                break

        messages: list[dict] = []
        if last_user_text:
            messages.append({"role": ROLE_USER, "content": last_user_text})
        if last_asst_text:
            messages.append({"role": ROLE_ASSISTANT, "content": last_asst_text})

        await self._write_messages(
            messages,
            user_id=session.user_id,
            log_tag="mem0 session add",
        )
