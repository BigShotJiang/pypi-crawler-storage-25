"""Tool registry — qualified names: framework:<n> and <plugin>:<n>.

Built once at startup by combining framework's built-in tools with
all tools discovered from plugins/.
"""

from typing import Callable

from .tools.memory import save_memory, load_memory
from .tools.system import get_current_time
from .tools.code import execute_python
from .tools.notify import send_message
from .tools.artifacts import read_artifact
from .tools.background import background
from .tools.bash import run_bash
from .tools.fs import write_file, edit_file
from .plugin import discover_plugins, build_tool_registry

# Framework-provided tools — keyed by short name; plugin loader adds
# the `framework:` namespace prefix when building the final registry.
FRAMEWORK_TOOLS: dict[str, Callable] = {
    "save_memory": save_memory,
    "load_memory": load_memory,
    "get_current_time": get_current_time,
    "execute_python": execute_python,
    "send_message": send_message,
    "read_artifact": read_artifact,
    "background": background,
    "run_bash": run_bash,
    "write_file": write_file,
    "edit_file": edit_file,
}

# Auto-granted to every agent (root + specialists) by the agent builder.
# These are the "global toolbox": shell, file write/edit, and artifact paging.
# Plugins may still list them explicitly without harm — duplicates are dropped.
GLOBAL_TOOLS: list[str] = [
    "framework:run_bash",
    "framework:write_file",
    "framework:edit_file",
    "framework:read_artifact",
]

# Lazily built; call get_tool_registry() to access.
_TOOL_REGISTRY: dict[str, Callable] | None = None


def get_tool_registry() -> dict[str, Callable]:
    """Return the qualified tool registry, building it on first call."""
    global _TOOL_REGISTRY
    if _TOOL_REGISTRY is None:
        discover_plugins()
        _TOOL_REGISTRY = build_tool_registry(FRAMEWORK_TOOLS)
    return _TOOL_REGISTRY


def resolve_tools(tool_refs: list[str]) -> list[Callable]:
    """Resolve a list of qualified tool refs to callables.

    Accepts qualified refs like 'framework:save_memory' or 'github:project_activity'.
    Bare names (no colon) are looked up in framework tools for backwards
    compatibility with the legacy config.yaml format.
    """
    registry = get_tool_registry()
    tools: list[Callable] = []
    for ref in tool_refs:
        # Backwards-compat: bare name → assume framework: prefix
        qualified = ref if ":" in ref else f"framework:{ref}"
        if qualified not in registry:
            raise ValueError(
                f"Unknown tool '{ref}'. Available: {sorted(registry)}"
            )
        tools.append(registry[qualified])
    return tools
