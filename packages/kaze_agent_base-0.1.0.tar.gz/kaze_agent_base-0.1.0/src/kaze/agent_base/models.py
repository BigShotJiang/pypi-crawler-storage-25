"""Model factory — builds LiteLLM clients routed through the Kaze Gateway.

Every LLM call (ADK Agent path and direct ``framework.llm.acompletion``
path alike) goes through the gateway at ``KAZE_GATEWAY_URL``. The gateway
handles provider resolution, Langfuse server-side tracing, and any
policy we add later (rate limits, cost caps, key rotation).

Two callsites consume this module:
  - ``get_model(tier)`` → returns an ADK ``LiteLlm`` bound to the gateway.
  - ``resolve_model_kwargs(tier)`` → returns ``(model, kwargs)`` for
    direct ``litellm.acompletion`` via ``framework.llm.acompletion``.
"""

from __future__ import annotations

import os

from google.adk.models.lite_llm import LiteLlm

DEFAULT_GATEWAY_URL = "http://localhost:4200"
DEFAULT_GATEWAY_API_KEY = "sk-local-dev"  # matches litellm_config.yaml master_key


# Shared mutable header dict: the ADK ``LiteLlm`` instance built in
# ``get_model`` captures this dict by reference as ``extra_headers``,
# so ``framework.llm.set_trace_id`` can mutate it per-request and every
# subsequent Agent LLM call picks up the new ``X-Kaze-Trace-Id`` without
# rebuilding the model.
_trace_headers: dict[str, str] = {
    "X-Kaze-Environment": os.environ.get("KAZE_ENVIRONMENT_ID", "dev"),
    "X-Kaze-Agent": "ops-agent",
    "X-Kaze-Namespace": os.environ.get("KAZE_MEMORY_NAMESPACE", "ops"),
    "X-Kaze-Trace-Id": "",
}


def get_gateway_endpoint() -> tuple[str, str]:
    """Return ``(base_url, api_key)`` for the Kaze Gateway.

    ``base_url`` always ends in ``/v1``. Shared by ``resolve_model_kwargs``
    and the mem0 config so gateway defaults live in one place.
    """
    base = os.environ.get("KAZE_GATEWAY_URL", DEFAULT_GATEWAY_URL).rstrip("/")
    if not base.endswith("/v1"):
        base = f"{base}/v1"
    key = os.environ.get("KAZE_GATEWAY_API_KEY", DEFAULT_GATEWAY_API_KEY)
    return base, key


def resolve_model_kwargs(tier: str) -> tuple[str, dict]:
    """Resolve a tier name into ``(litellm_model, litellm_kwargs)``.

    Use this when calling ``litellm.acompletion`` directly (through
    ``framework.llm.acompletion``, which is the only sanctioned path —
    see that module's docstring).

    Returns ``("openai/<tier>", {api_base, api_key, extra_headers})``.
    The gateway resolves the actual provider from its ``model_list`` and
    handles Langfuse tracing server-side; the client just carries the
    trace id in ``X-Kaze-Trace-Id``.
    """
    base, key = get_gateway_endpoint()
    return f"openai/{tier}", {
        "api_base": base,
        "api_key": key,
        "extra_headers": dict(_trace_headers),  # snapshot current trace id
    }


def get_model(tier: str) -> LiteLlm:
    """Build an ADK ``LiteLlm`` pointing at the gateway for the given tier.

    The returned instance shares ``_trace_headers`` by reference so that
    ``framework.llm.set_trace_id`` propagates to every subsequent Agent
    LLM call without rebuilding the model.
    """
    from .llm import ensure_langfuse_callback

    ensure_langfuse_callback()
    base, key = get_gateway_endpoint()
    return LiteLlm(
        model=f"openai/{tier}",
        api_base=base,
        api_key=key,
        extra_headers=_trace_headers,
    )
