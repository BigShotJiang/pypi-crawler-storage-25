"""Workflow graph — just the root agent with native ADK sub_agents.

The root agent handles chat directly. For domain work it uses ADK's
native ``transfer_to_agent(name)`` to dispatch to a specialist.
Specialists call tools (including parallel tool calls in a single turn).

No custom compile/executor pipeline: ADK's agent loop, session event
persistence, and transfer mechanism cover what we used to hand-roll.
"""

import logging
import os
from pathlib import Path

from google.adk import Workflow

from ..config import load_config
from ..plugin import discover_plugins
from ..tool_registry import get_tool_registry
from .agents import build_agents
from . import callbacks

logger = logging.getLogger(__name__)


def build_workflow(
    *,
    config_store=None,
    config_path: Path | str | None = None,
    plugins_root: Path | str | None = None,
    plugins_package: str | None = None,
    workflow_name: str | None = None,
    workflow_description: str = "",
) -> tuple[Workflow, dict]:
    """Build the workflow: START → root_agent (with sub_agents).

    Args:
        config_store: optional ConfigStore for runtime overrides.
        config_path: where to load ``config.yaml`` from. Falls back to
            ``KAZE_CONFIG_PATH`` env var or ``./config.yaml``.
        plugins_root: filesystem path containing plugin subdirectories.
            Falls back to ``KAZE_PLUGINS_ROOT``.
        plugins_package: import path matching ``plugins_root``. Falls back
            to ``KAZE_PLUGINS_PACKAGE``.
        workflow_name: name on the root ADK Workflow. Falls back to
            ``KAZE_APP_NAME`` or ``"agent"``.
        workflow_description: free-text description on the root Workflow.

    Returns:
        ``(workflow, agents_dict)`` — the agents dict lets callers access
        specialists for MCP refresh operations.
    """
    config = load_config(config_path)
    discover_plugins(plugins_root=plugins_root, plugins_package=plugins_package)
    get_tool_registry()
    root_agent, agents, mcp_toolsets = build_agents(config, config_store)

    specialist_names = sorted(name for name in agents if name != root_agent.name)
    logger.info(f"Root agent: {root_agent.name}, specialists: {specialist_names}")

    for agent in agents.values():
        agent.before_model_callback = callbacks.before_model
        if agent.tools:
            agent.before_tool_callback = callbacks.before_tool
            agent.after_tool_callback = callbacks.after_tool
            agent.on_tool_error_callback = callbacks.on_tool_error
        agent.on_model_error_callback = callbacks.on_model_error

    # Per-turn memory hooks live on the root agent only — it owns the
    # user-facing conversation. Specialists run inside a root turn via
    # transfer_to_agent, so wiring them separately would double-write.
    root_agent.before_agent_callback = callbacks.before_agent
    root_agent.after_agent_callback = callbacks.after_agent

    name = workflow_name or os.environ.get("KAZE_APP_NAME", "agent")
    workflow = Workflow(
        name=name,
        description=workflow_description,
        edges=[("START", root_agent)],
    )

    workflow._kaze_config = config
    workflow._kaze_agents = agents
    workflow._kaze_mcp_toolsets = mcp_toolsets

    return workflow, agents
