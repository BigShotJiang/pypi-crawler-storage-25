"""Callbacks for leaf agents — budget enforcement, rate limiting, error handling.

These are wired onto leaf agents after construction. They intercept
tool calls and model responses to enforce safety limits.
"""

import os
import time
import uuid
import logging

from google.adk.tools.base_tool import BaseTool
from google.adk.models.llm_response import LlmResponse
from google.genai import types

logger = logging.getLogger(__name__)

MAX_STEPS = int(os.environ.get("KAZE_MAX_STEPS", "30"))
MAX_TOKENS = int(os.environ.get("KAZE_MAX_TOKENS", "300000"))
MAX_TOOL_RESULT_CHARS = int(os.environ.get("KAZE_MAX_TOOL_RESULT", "8000"))

_rate_limit_until: float = 0


def _user_message_text(callback_context) -> str:
    """Extract the user's message text for this turn, or '' if none."""
    user_content = getattr(callback_context, "user_content", None)
    if not user_content or not user_content.parts:
        return ""
    return " ".join(p.text for p in user_content.parts if p.text).strip()


async def before_agent(callback_context) -> None:
    """Pre-turn memory preload: semantic search against the user's message,
    stash the top-k as a system-prompt preamble that the agent's
    instruction_provider will splice in.

    Sync + awaited: the LLM must see the preamble before it thinks. Any
    failure degrades to an empty preamble (the agent still runs).
    """
    from ..state.memory import format_preamble

    callback_context.state["memory_preamble"] = ""

    query = _user_message_text(callback_context)
    if not query:
        return None

    try:
        response = await callback_context.search_memory(query)
    except Exception as e:
        logger.warning("memory preload failed: %s", str(e)[:200])
        return None

    memories = getattr(response, "memories", None) or []
    if not memories:
        return None

    callback_context.state["memory_preamble"] = format_preamble(memories)
    logger.info(
        "memory preload: %d memories for %s",
        len(memories),
        getattr(callback_context, "user_id", "?"),
    )
    return None


async def after_agent(callback_context) -> None:
    """Post-turn memory write: push the latest (user, assistant) pair to
    mem0 for extraction. Sync + awaited — the next turn is blocked until
    this completes so follow-ups see freshly-learned facts.

    Skipped when the turn has no user content (framework-internal ticks).
    """
    if not _user_message_text(callback_context):
        return None
    try:
        await callback_context.add_session_to_memory()
    except Exception as e:
        logger.warning("memory write failed: %s", str(e)[:200])
    return None


def before_model(callback_context, llm_request) -> None:
    """Pre-model callback: reset per-invocation budget counters and
    propagate the parent Langfuse trace_id to every LLM call.

    The trace_id propagates two ways so one user request's LLM calls
    all land under a single trace tree:

    1. ``framework.llm.set_trace_id`` mutates the shared
       ``_trace_headers`` dict — the ADK Agent's LiteLlm uses it as
       ``extra_headers`` so the gateway sees ``X-Kaze-Trace-Id`` on
       every outgoing request.
    2. ``agent.model._additional_args["metadata"]`` — for client-side
       Langfuse callback consumers (local dev; the gateway handles
       server-side tracing in prod).
    """
    from .. import llm as fwk_llm

    invocation_ctx = callback_context.get_invocation_context()
    _reset_budgets_if_new_invocation(callback_context, invocation_ctx)

    trace_id = callback_context.state.get("_trace_id") or str(uuid.uuid4())
    callback_context.state["_trace_id"] = trace_id
    fwk_llm.set_trace_id(trace_id)

    if not getattr(llm_request, "model", None):
        return None

    from google.adk.models.lite_llm import LiteLlm

    agent = invocation_ctx.agent if invocation_ctx else None
    if agent and isinstance(getattr(agent, "model", None), LiteLlm):
        _set_client_langfuse_metadata(agent, callback_context, trace_id)

    return None


def _reset_budgets_if_new_invocation(callback_context, invocation_ctx) -> None:
    """Zero step/token counters and mint a fresh trace_id at invocation
    boundaries. ADK invocations are per-user-turn, so budgets scope to
    one turn, not the whole session.
    """
    invocation_id = (
        getattr(invocation_ctx, "invocation_id", None) if invocation_ctx else None
    )
    if invocation_id and callback_context.state.get("_invocation_id") != invocation_id:
        callback_context.state["_invocation_id"] = invocation_id
        callback_context.state["_steps"] = 0
        callback_context.state["_tokens"] = 0
        callback_context.state["_trace_id"] = str(uuid.uuid4())


def _set_client_langfuse_metadata(agent, callback_context, trace_id: str) -> None:
    """Stamp Langfuse trace metadata onto the Agent's LiteLlm additional
    args. Consumed by litellm's client-side Langfuse callback; ignored
    by the gateway, which reads the trace id from the HTTP header.
    """
    session = getattr(callback_context, "session", None)
    agent.model._additional_args["metadata"] = {
        "trace_id": trace_id,
        "trace_name": callback_context.state.get("playbook", "dynamic"),
        "session_id": session.id if session else None,
        "trace_user_id": getattr(callback_context, "user_id", None),
    }


def before_tool(tool: BaseTool, args: dict, **kwargs) -> dict | None:
    """Pre-tool callback: enforce step/token budgets and rate limits."""
    global _rate_limit_until
    ctx = kwargs.get("tool_context") or kwargs.get("ctx")
    tool_name = getattr(tool, "name", str(tool))

    if time.time() < _rate_limit_until:
        remaining = int(_rate_limit_until - time.time())
        return {"error": f"Rate limited. Try again in {remaining}s."}

    steps = ctx.state.get("_steps", 0) + 1
    ctx.state["_steps"] = steps
    tokens = ctx.state.get("_tokens", 0) + len(str(args)) // 4
    ctx.state["_tokens"] = tokens

    trace_id = ctx.state.get("_trace_id", "unknown")
    if steps > MAX_STEPS:
        return {"error": f"Step budget exceeded ({steps}/{MAX_STEPS}). Stop and tell the user this task is too complex. Trace ID: {trace_id}"}
    if tokens > MAX_TOKENS:
        return {"error": f"Token budget exceeded ({tokens}/{MAX_TOKENS}). Stop and tell the user this task is too complex. Trace ID: {trace_id}"}

    logger.info(f"Step {steps}/{MAX_STEPS}: {tool_name}")
    return None


def after_tool(tool: BaseTool, args: dict, **kwargs) -> dict | None:
    """Post-tool callback: track tokens and spill oversized results to an artifact.

    Any tool returning more than MAX_TOOL_RESULT_CHARS of serialized output
    gets its payload written to disk; the LLM sees only a head+tail preview
    plus an ``artifact_path`` it can page through via ``read_artifact``.
    """
    ctx = kwargs.get("tool_context") or kwargs.get("ctx")
    result = kwargs.get("tool_response")
    if not result:
        return None

    result_str = str(result)
    ctx.state["_tokens"] = ctx.state.get("_tokens", 0) + len(result_str) // 4

    if len(result_str) <= MAX_TOOL_RESULT_CHARS:
        return None
    # execute_python already spills itself; don't double-spill.
    if isinstance(result, dict) and result.get("artifact_path"):
        return None

    return _spill_oversized_result(tool, result, result_str)


def _spill_oversized_result(tool: BaseTool, result, result_str: str) -> dict | None:
    """Write an oversized tool result to an artifact and return a
    head+tail preview that points at it.

    String results spill as markdown; dict results spill as pretty JSON
    with long string fields trimmed in-place so the structure stays
    navigable by the LLM. Returns ``None`` for any other type — caller
    already handled the dict-with-artifact_path short-circuit.
    """
    from ..tools.artifacts import spill

    tool_name = getattr(tool, "name", str(tool))
    head_budget = max(MAX_TOOL_RESULT_CHARS - 800, 1000)
    tail_chars = 500

    if isinstance(result, str):
        path = spill(result, ext="md")
        preview = _head_tail_preview(result, head_budget, tail_chars, path)
        logger.info(f"{tool_name} output spilled: {len(result)} chars -> {path}")
        return {"output": preview, "artifact_path": path, "total_chars": len(result)}

    if isinstance(result, dict):
        import json
        path = spill(json.dumps(result, default=str, indent=2), ext="json")
        trimmed = {
            k: (
                _head_tail_preview(v, head_budget, tail_chars, path)
                if isinstance(v, str) and len(v) > head_budget
                else v
            )
            for k, v in result.items()
        }
        trimmed["artifact_path"] = path
        trimmed["total_chars"] = len(result_str)
        logger.info(f"{tool_name} dict output spilled: {len(result_str)} chars -> {path}")
        return trimmed

    return None


def _head_tail_preview(text: str, head_budget: int, tail_chars: int, path: str) -> str:
    """Keep the first ``head_budget`` and last ``tail_chars`` of ``text``
    with a middle marker naming the artifact for pagination.
    """
    omitted = len(text) - head_budget - tail_chars
    return (
        text[:head_budget]
        + f"\n\n[... {omitted} chars truncated; "
        f"call read_artifact('{path}', start=..., limit=...) to page through ...]\n\n"
        + text[-tail_chars:]
    )


def on_tool_error(tool: BaseTool, args: dict, tool_context, error: Exception) -> dict | None:
    """Tool error callback: log and return error message."""
    error_msg = str(error)
    logger.error(f"Tool error: {error_msg[:300]}")
    return {"error": error_msg[:500]}


def on_model_error(callback_context, llm_request, error):
    """Model error callback: handle rate limits and other LLM errors."""
    global _rate_limit_until
    error_msg = str(error)

    if "RateLimit" in error_msg or "rate_limit" in error_msg:
        _rate_limit_until = time.time() + 300
        logger.error("Rate limited! 5min cooldown")
        return LlmResponse(
            content=types.Content(
                role="model",
                parts=[types.Part(text="Rate limited. Please try again in a few minutes.")],
            ),
        )

    logger.error(f"Model error: {error_msg[:300]}")
    return LlmResponse(
        content=types.Content(
            role="model",
            parts=[types.Part(text="Something went wrong with the AI service. Please try again shortly.")],
        ),
    )
