"""MCP toolset builder — creates and refreshes MCP server connections.

Each MCP server is a subprocess (e.g. npx @modelcontextprotocol/server-github).
Tools are auto-discovered from the server's capability list.
"""

import os
import re
import logging

from google.adk.tools.mcp_tool import McpToolset, StdioConnectionParams
from mcp import StdioServerParameters

logger = logging.getLogger(__name__)


def resolve_mcp_env(server_config: dict, config_store=None) -> dict[str, str]:
    """Resolve {{VAR}} templates in MCP server env config."""
    env = {}
    for k, v in server_config.get("env", {}).items():
        val = str(v)
        match = re.match(r"^\{\{(\w+)\}\}$", val)
        if match:
            var_name = match.group(1)
            if config_store:
                stored = config_store.get_secret(var_name)
                if stored:
                    env[k] = stored
                    continue
            env[k] = os.environ.get(var_name, "")
        else:
            env[k] = val
    return env


def build_mcp_toolset(server_name: str, server_config: dict, config_store=None) -> McpToolset:
    """Build a single MCP toolset from server config."""
    env = resolve_mcp_env(server_config, config_store)
    full_env = {**os.environ, **env}
    return McpToolset(
        connection_params=StdioConnectionParams(
            server_params=StdioServerParameters(
                command=server_config["command"],
                args=server_config.get("args", []),
                env=full_env,
            ),
        ),
        tool_filter=server_config.get("tool_filter"),
    )


def refresh_mcp_toolsets(
    config: dict,
    agents: dict,
    toolsets: dict[str, McpToolset],
    config_store=None,
    server_names: list[str] | None = None,
) -> dict:
    """Refresh MCP server toolsets with updated credentials.

    Returns {"refreshed": [...], "errors": [...]}.
    """
    mcp_servers = config.get("mcp_servers", {})
    targets = server_names or list(toolsets.keys())
    refreshed, errors = [], []

    for name in targets:
        if name not in mcp_servers:
            errors.append(f"Unknown MCP server: {name}")
            continue
        old_toolset = toolsets.get(name)
        try:
            new_toolset = build_mcp_toolset(name, mcp_servers[name], config_store)
            toolsets[name] = new_toolset
            # Update any agents that use this MCP server
            for agent_name, spec in config.get("agents", {}).items():
                mcp_refs = spec.get("mcp", [])
                if isinstance(mcp_refs, str):
                    mcp_refs = [mcp_refs]
                if name in mcp_refs and agent_name in agents:
                    agent = agents[agent_name]
                    agent.tools = [
                        new_toolset if t is old_toolset else t
                        for t in agent.tools
                    ]
            refreshed.append(name)
        except Exception as e:
            errors.append(f"{name}: {str(e)[:200]}")

    return {"refreshed": refreshed, "errors": errors}
