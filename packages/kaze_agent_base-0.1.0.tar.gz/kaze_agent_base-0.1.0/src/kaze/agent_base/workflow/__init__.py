"""Workflow assembly — builds the ADK 2.0 Workflow graph."""

from .graph import build_workflow

__all__ = ["build_workflow"]
