"""Agent builder — creates LLM-powered ADK Agents from plugin specs.

Walks the plugin registry, builds a root coordinator with specialist
sub-agents. The root agent routes via ADK's built-in `transfer_to_agent`
mechanism. Specialists carry their own tools (and optional MCP toolsets).
"""

import os
import re
import logging

from google.adk import Agent

from ..models import get_model
from ..plugin import PluginSpec, get_plugins
from ..tool_registry import GLOBAL_TOOLS, resolve_tools
from .mcp import build_mcp_toolset, McpToolset

logger = logging.getLogger(__name__)


# Appended to every agent's instruction so the global toolbox is discoverable
# without each plugin having to repeat itself. `{{KAZE_WORKSPACE_DIR}}` is
# substituted by _load_prompt's env-var expansion (bash.py exports the
# resolved path to os.environ at import time).
GLOBAL_AGENT_INSTRUCTIONS = """
## Workspace & shell tools (available to every agent)

Your shared workspace is `{{KAZE_WORKSPACE_DIR}}`. Drop scripts, reports, and intermediate data there and tell the user the absolute path when you hand off a file. Every subprocess (`run_bash`, `execute_python`) runs with cwd set to this workspace and `$KAZE_WORKSPACE_DIR` available in its env — so a bare `./foo.md` inside a script lands in the workspace.

- `run_bash(command, cwd=None, timeout=120)` — your shell. cwd defaults to the workspace. Use it to read (`cat -n file`), search (`rg pattern path`, `find . -name '*.py'`), list (`ls -la`), and one-off Python (`python3 -c '...'`). Large stdout spills to an `artifact_path`.
- `write_file(path, content)` — create/overwrite a file. Absolute paths only. Prefer this over `cat > file <<EOF` (heredocs break on `$`, backticks, EOF markers).
- `edit_file(path, old_string, new_string, replace_all=False)` — surgical string replace. `old_string` must be unique unless `replace_all=True`. Prefer this over `sed -i` (BSD/GNU divergent + dangerous).
- `read_artifact(path, start, limit)` — page through a spilled artifact when a tool returned `artifact_path` because output was truncated.
"""


def _substitute_env(text: str) -> str:
    """Replace `{{VAR}}` with `os.environ[VAR]`, leaving unknown names as-is."""
    return re.sub(
        r"\{\{(\w+)\}\}",
        lambda m: os.environ.get(m.group(1), m.group(0)),
        text,
    )


def _load_prompt(plugin: PluginSpec) -> str:
    """Load a plugin's prompt.md (without env-var substitution)."""
    prompt_name = plugin.config.get("prompt", "prompt.md")
    full_path = plugin.path / prompt_name
    if not full_path.exists():
        return "You are a project assistant."
    return full_path.read_text()


def _resolve_model_name(
    agent_name: str, model_ref: str, model_tiers: dict, config_store=None
) -> str:
    """Resolve a model tier reference to a concrete model name."""
    env_override = os.environ.get(f"KAZE_MODEL_{agent_name.upper()}")
    if env_override:
        return model_tiers.get(env_override, env_override)
    if config_store:
        hint = config_store.get_setting("model_hint")
        if hint:
            return model_tiers.get(hint, hint)
    global_override = os.environ.get("KAZE_MODEL_HINT")
    if global_override:
        return model_tiers.get(global_override, global_override)
    return model_tiers.get(model_ref, model_ref)


def build_agents(
    config: dict, config_store=None
) -> tuple[Agent, dict[str, Agent], dict[str, McpToolset]]:
    """Build root agent + specialists from discovered plugin specs.

    Returns (root_agent, all_agents_dict, mcp_toolsets_dict).
    """
    model_tiers = config.get("models", {})
    mcp_servers = config.get("mcp_servers", {})
    mcp_toolsets: dict[str, McpToolset] = {}

    plugins = get_plugins()
    agent_plugins = [p for p in plugins.values() if p.has_agent]

    root_plugin = None
    specialist_plugins: list[PluginSpec] = []
    for p in agent_plugins:
        if p.role == "root":
            if root_plugin:
                raise ValueError(
                    f"Multiple root plugins: '{root_plugin.name}' and '{p.name}'"
                )
            root_plugin = p
        else:
            specialist_plugins.append(p)

    if root_plugin is None:
        raise ValueError("No root plugin found (set role: root in plugin.yaml)")

    def _build(plugin: PluginSpec) -> Agent:
        spec = plugin.config
        model_name = _resolve_model_name(
            plugin.name, spec.get("model", "balanced"), model_tiers, config_store
        )

        tools = []

        # Auto-grant the global toolbox; drop dupes if a plugin also lists them.
        plugin_tool_refs = [
            t for t in spec.get("tools", []) if t not in set(GLOBAL_TOOLS)
        ]
        tools.extend(resolve_tools(GLOBAL_TOOLS))
        tools.extend(resolve_tools(plugin_tool_refs))

        if "mcp" in spec:
            mcp_refs = spec["mcp"]
            if isinstance(mcp_refs, str):
                mcp_refs = [mcp_refs]
            for mcp_name in mcp_refs:
                if mcp_name not in mcp_servers:
                    raise ValueError(
                        f"Plugin '{plugin.name}' references unknown mcp server '{mcp_name}'"
                    )
                toolset = build_mcp_toolset(mcp_name, mcp_servers[mcp_name], config_store)
                mcp_toolsets[mcp_name] = toolset
                tools.append(toolset)

        base_instruction = _substitute_env(
            _load_prompt(plugin) + GLOBAL_AGENT_INSTRUCTIONS
        )

        def _instruction_provider(ctx) -> str:
            preamble = (ctx.state.get("memory_preamble") or "").strip()
            if preamble:
                return f"{preamble}\n\n---\n\n{base_instruction}"
            return base_instruction

        return Agent(
            name=plugin.name,
            model=get_model(model_name),
            description=spec.get("description", ""),
            instruction=_instruction_provider,
            tools=tools,
        )

    specialists: dict[str, Agent] = {p.name: _build(p) for p in specialist_plugins}
    root_agent = _build(root_plugin)
    if specialists:
        root_agent.sub_agents = list(specialists.values())

    agents: dict[str, Agent] = {root_plugin.name: root_agent, **specialists}

    logger.info(
        f"Built root '{root_plugin.name}' with specialists: {sorted(specialists)}"
    )

    return root_agent, agents, mcp_toolsets
