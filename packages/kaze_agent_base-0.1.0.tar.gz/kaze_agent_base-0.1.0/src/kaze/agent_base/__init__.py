"""kaze-agent-base — reusable ADK-based agent infrastructure.

A domain-agnostic toolkit for building agents on top of Google ADK 2.0:
  - Plugin loader + tool registry (namespaced tool refs)
  - Background workflow engine (anyio, SQLite-backed job store)
  - FastAPI server factory with config/management routes
  - Mem0-backed memory service + SQLite config store
  - LLM wrapper with trace propagation (Langfuse-aware)

Downstream agent packages provide their own plugins; this package never
imports plugin code.
"""

from .llm import acompletion, set_trace_id, reset_trace_id
from .jobs.tool_agent import ToolAgent
from .jobs.engine import get_engine
from .tools.artifacts import spill
from .plugin import discover_plugins, get_workflow_templates
from .tool_registry import get_tool_registry, resolve_tools
from .server.app import create_app

__all__ = [
    "acompletion",
    "set_trace_id",
    "reset_trace_id",
    "ToolAgent",
    "get_engine",
    "spill",
    "discover_plugins",
    "get_workflow_templates",
    "get_tool_registry",
    "resolve_tools",
    "create_app",
]
