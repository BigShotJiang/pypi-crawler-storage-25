"""Plugin loader — discovers domain plugins at a caller-supplied path.

Each plugin is a directory containing `plugin.yaml` plus optional
`prompt.md`, `tools.py`, and `workflows/<name>/` subdirectories.

The loader:
  1. Walks ``plugins_root`` and parses each plugin.yaml.
  2. Imports ``{plugins_package}.<plugin>.tools`` if present and
     registers each public callable into the global TOOL_REGISTRY
     under the key ``<plugin>:<func_name>``.
  3. Imports each ``{plugins_package}.<plugin>.workflows.<wf>.workflow``
     and registers its ``build`` function under the workflow's ``name``.
  4. Returns a dict so callers can iterate over agent specs to build
     ADK agents.

Downstream packages own their own plugins directory and its Python
import path. Pass both ``plugins_root`` (filesystem) and
``plugins_package`` (import path) to :func:`discover_plugins`.

Naming conventions:
  - Tools: ``framework:<name>`` for built-ins, ``<plugin>:<name>``
    for plugin-defined (the ``framework:`` prefix is a stable tag,
    not tied to the Python module name).
  - Workflows: keyed by the ``name`` field in the workflow's
    plugin.yaml.
"""

from __future__ import annotations

import importlib
import inspect
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import yaml

logger = logging.getLogger(__name__)


@dataclass
class PluginSpec:
    """Parsed plugin definition."""
    name: str
    path: Path
    config: dict
    tools: dict[str, Callable] = field(default_factory=dict)
    workflows: dict[str, Callable] = field(default_factory=dict)

    @property
    def role(self) -> str | None:
        return self.config.get("role")

    @property
    def has_agent(self) -> bool:
        return self.role in ("root", "specialist")


_plugins: dict[str, PluginSpec] = {}
_workflow_templates: dict[str, Callable] = {}


def discover_plugins(
    plugins_root: Path | str | None = None,
    plugins_package: str | None = None,
) -> dict[str, PluginSpec]:
    """Walk plugins_root, load each plugin.yaml, import code.

    Args:
        plugins_root: filesystem path containing ``<plugin>/plugin.yaml``
            subdirectories. Falls back to ``KAZE_PLUGINS_ROOT`` env var.
        plugins_package: Python import path matching ``plugins_root``
            (e.g., ``"kaze_ops.plugins"``). Falls back to
            ``KAZE_PLUGINS_PACKAGE`` env var.

    Populates module-level state and returns the plugin map. Returns an
    empty map (with a warning) if ``plugins_root`` does not exist.
    """
    global _plugins, _workflow_templates
    _plugins = {}
    _workflow_templates = {}

    if plugins_root is None:
        plugins_root = os.environ.get("KAZE_PLUGINS_ROOT")
    if plugins_package is None:
        plugins_package = os.environ.get("KAZE_PLUGINS_PACKAGE")

    if plugins_root is None or plugins_package is None:
        logger.warning(
            "discover_plugins called without plugins_root/plugins_package; "
            "no plugins will be loaded. "
            "Pass arguments or set KAZE_PLUGINS_ROOT + KAZE_PLUGINS_PACKAGE."
        )
        return _plugins

    plugins_root = Path(plugins_root)
    if not plugins_root.exists():
        logger.warning(f"No plugins directory at {plugins_root}")
        return _plugins

    for plugin_dir in sorted(plugins_root.iterdir()):
        if not plugin_dir.is_dir() or plugin_dir.name.startswith("_"):
            continue
        plugin_yaml = plugin_dir / "plugin.yaml"
        if not plugin_yaml.exists():
            continue

        config = yaml.safe_load(plugin_yaml.read_text())
        spec = PluginSpec(name=config["name"], path=plugin_dir, config=config)

        # Import tools.py and register each public callable.
        tools_py = plugin_dir / "tools.py"
        if tools_py.exists():
            mod_name = f"{plugins_package}.{plugin_dir.name}.tools"
            mod = importlib.import_module(mod_name)
            for attr_name, attr in inspect.getmembers(mod):
                if attr_name.startswith("_") or not callable(attr):
                    continue
                if inspect.ismodule(attr) or inspect.isclass(attr):
                    continue
                # Only register functions defined in this module
                if getattr(attr, "__module__", None) != mod_name:
                    continue
                spec.tools[attr_name] = attr

        # Discover workflows/<name>/workflow.py
        workflows_dir = plugin_dir / "workflows"
        if workflows_dir.exists():
            for wf_dir in sorted(workflows_dir.iterdir()):
                if not wf_dir.is_dir():
                    continue
                wf_yaml = wf_dir / "plugin.yaml"
                wf_py = wf_dir / "workflow.py"
                if not (wf_yaml.exists() and wf_py.exists()):
                    continue
                wf_config = yaml.safe_load(wf_yaml.read_text())
                wf_name = wf_config["name"]
                build_ref = wf_config.get("build", "workflow:build")
                mod_part, fn_part = build_ref.split(":")
                mod_name = (
                    f"{plugins_package}.{plugin_dir.name}"
                    f".workflows.{wf_dir.name}.{mod_part}"
                )
                mod = importlib.import_module(mod_name)
                spec.workflows[wf_name] = getattr(mod, fn_part)
                _workflow_templates[wf_name] = spec.workflows[wf_name]

        _plugins[spec.name] = spec
        logger.info(
            f"[plugin] Loaded {spec.name}: tools={list(spec.tools)} "
            f"workflows={list(spec.workflows)} role={spec.role}"
        )

    return _plugins


def get_plugins() -> dict[str, PluginSpec]:
    return _plugins


def get_workflow_templates() -> dict[str, Callable]:
    return _workflow_templates


def build_tool_registry(framework_tools: dict[str, Callable]) -> dict[str, Callable]:
    """Build the qualified tool registry: framework:* + <plugin>:*."""
    registry: dict[str, Callable] = {}
    for name, fn in framework_tools.items():
        registry[f"framework:{name}"] = fn
    for plugin in _plugins.values():
        for tool_name, fn in plugin.tools.items():
            registry[f"{plugin.name}:{tool_name}"] = fn
    return registry
