"""Route handlers for the config/management API.

Each function registers its routes on the given FastAPI app.
Separated from app creation for testability.
"""

import json
import os
from typing import Any

from fastapi import Request, Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import JSONResponse, Response

from .schemas import (
    ChannelConfig,
    SecretInfo,
    SecretSet,
    SecretSetResponse,
    SettingValue,
    SettingResponse,
    McpRefreshRequest,
    McpRefreshResponse,
    WhatsAppPairRequest,
    HealthResponse,
    ErrorResponse,
)

# ── Auth ──────────────────────────────────────────────────────────

_api_key = os.environ.get("AGENT_API_KEY", "")
_security = HTTPBearer(auto_error=False)


async def require_auth(
    credentials: HTTPAuthorizationCredentials | None = Depends(_security),
):
    if not _api_key:
        return
    if not credentials or credentials.credentials != _api_key:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


def _mask(value: str) -> str:
    if len(value) <= 4:
        return "****"
    return "*" * 4 + "..." + value[-4:]


async def _reload_gateway() -> None:
    """Tell the channel-gateway sidecar to re-fetch config and reconcile workers."""
    import httpx

    gateway_url = os.environ.get("KAZE_GATEWAY_URL_INTERNAL", "http://localhost:18789")
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            await client.post(f"{gateway_url}/reload")
    except Exception as e:
        # Non-fatal: gateway may be down or sidecar disabled
        print(f"[routes] gateway reload failed: {e}")


# ── Route registration ────────────────────────────────────────────

def register_routes(app, store, refresh_mcp_fn) -> None:
    """Register all config/management routes on the FastAPI app."""

    # ── Health ─────────────────────────────────────────────
    @app.get(
        "/api/v1/health",
        response_model=HealthResponse,
        tags=["Health"],
    )
    async def health():
        """Health check. Returns build SHA and environment ID."""
        return {
            "status": "ok",
            "build": os.environ.get("BUILD_SHA", "dev"),
            "environment": os.environ.get("KAZE_ENVIRONMENT_ID", "dev"),
        }

    # ── Channels ───────────────────────────────────────────
    @app.get(
        "/api/v1/channels",
        response_model=dict[str, ChannelConfig],
        dependencies=[Depends(require_auth)],
        tags=["Channels"],
    )
    async def list_channels():
        """List all configured channels."""
        raw = store.get_by_prefix("channel:")
        return {k.removeprefix("channel:"): json.loads(v) for k, v in raw.items()}

    @app.get(
        "/api/v1/channels/{name}",
        response_model=ChannelConfig,
        dependencies=[Depends(require_auth)],
        responses={404: {"model": ErrorResponse}},
        tags=["Channels"],
    )
    async def get_channel(name: str):
        """Get a single channel configuration."""
        config = store.get_channel(name)
        if config is None:
            raise HTTPException(status_code=404, detail=f"Channel '{name}' not found")
        return config

    @app.put(
        "/api/v1/channels/{name}",
        response_model=ChannelConfig,
        dependencies=[Depends(require_auth)],
        tags=["Channels"],
    )
    async def replace_channel(name: str, body: ChannelConfig):
        """Create or fully replace a channel configuration."""
        data = body.model_dump(exclude_none=True)
        store.set_channel(name, data)
        await _reload_gateway()
        return data

    @app.patch(
        "/api/v1/channels/{name}",
        response_model=ChannelConfig,
        dependencies=[Depends(require_auth)],
        responses={404: {"model": ErrorResponse}},
        tags=["Channels"],
    )
    async def update_channel(name: str, request: Request):
        """Partially update a channel configuration."""
        existing = store.get_channel(name)
        if existing is None:
            raise HTTPException(status_code=404, detail=f"Channel '{name}' not found")
        body = await request.json()
        existing.update(body)
        store.set_channel(name, existing)
        await _reload_gateway()
        return existing

    @app.delete(
        "/api/v1/channels/{name}",
        status_code=204,
        dependencies=[Depends(require_auth)],
        tags=["Channels"],
    )
    async def delete_channel(name: str):
        """Delete a channel configuration."""
        store.delete_channel(name)
        await _reload_gateway()
        return Response(status_code=204)

    # ── Secrets ────────────────────────────────────────────
    @app.get(
        "/api/v1/secrets",
        response_model=dict[str, SecretInfo],
        dependencies=[Depends(require_auth)],
        tags=["Secrets"],
    )
    async def list_secrets():
        """List all secrets with masked values."""
        secrets = store.get_all_secrets()
        return {k: {"masked": _mask(v), "length": len(v)} for k, v in secrets.items()}

    @app.put(
        "/api/v1/secrets/{name}",
        response_model=SecretSetResponse,
        dependencies=[Depends(require_auth)],
        tags=["Secrets"],
    )
    async def set_secret(name: str, body: SecretSet):
        """Create or replace a secret. Use POST /api/v1/mcp/refresh to apply."""
        store.set_secret(name, body.value)
        return {"name": name, "masked": _mask(body.value)}

    @app.delete(
        "/api/v1/secrets/{name}",
        status_code=204,
        dependencies=[Depends(require_auth)],
        tags=["Secrets"],
    )
    async def delete_secret(name: str):
        """Delete a secret."""
        store.delete(f"secret:{name}")
        return Response(status_code=204)

    # ── Settings ───────────────────────────────────────────
    @app.get(
        "/api/v1/settings",
        response_model=dict[str, str],
        dependencies=[Depends(require_auth)],
        tags=["Settings"],
    )
    async def list_settings():
        """List all agent settings."""
        raw = store.get_by_prefix("setting:")
        return {k.removeprefix("setting:"): v for k, v in raw.items()}

    @app.get(
        "/api/v1/settings/{name}",
        response_model=SettingResponse,
        dependencies=[Depends(require_auth)],
        responses={404: {"model": ErrorResponse}},
        tags=["Settings"],
    )
    async def get_setting(name: str):
        """Get a single setting."""
        value = store.get_setting(name)
        if value is None:
            raise HTTPException(status_code=404, detail=f"Setting '{name}' not found")
        return {"name": name, "value": value}

    @app.put(
        "/api/v1/settings/{name}",
        response_model=SettingResponse,
        dependencies=[Depends(require_auth)],
        tags=["Settings"],
    )
    async def set_setting(name: str, body: SettingValue):
        """Create or replace a setting."""
        store.set_setting(name, str(body.value))
        return {"name": name, "value": str(body.value)}

    @app.delete(
        "/api/v1/settings/{name}",
        status_code=204,
        dependencies=[Depends(require_auth)],
        tags=["Settings"],
    )
    async def delete_setting(name: str):
        """Delete a setting."""
        store.delete(f"setting:{name}")
        return Response(status_code=204)

    # ── MCP ────────────────────────────────────────────────
    @app.post(
        "/api/v1/mcp/refresh",
        response_model=McpRefreshResponse,
        dependencies=[Depends(require_auth)],
        tags=["MCP"],
    )
    async def refresh_mcp_endpoint(body: McpRefreshRequest | None = None):
        """Restart MCP server subprocesses with updated secrets."""
        server_names = body.servers if body else None
        result = refresh_mcp_fn(server_names)
        if result.get("errors"):
            return JSONResponse(result, status_code=207)
        return result

    # ── WhatsApp pairing ───────────────────────────────────
    @app.post(
        "/api/v1/channels/whatsapp/pair",
        dependencies=[Depends(require_auth)],
        tags=["Channels"],
    )
    async def pair_whatsapp():
        """Start WhatsApp pairing. Poll /pair-status for the QR and connection state."""
        import httpx

        gateway_url = os.environ.get(
            "KAZE_GATEWAY_URL_INTERNAL", "http://localhost:18789"
        )
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(f"{gateway_url}/pair/whatsapp", timeout=15)
                if resp.status_code >= 400:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text[:200])
                return resp.json()
        except httpx.TimeoutException:
            raise HTTPException(status_code=504, detail="Pairing start timed out")

    @app.get(
        "/api/v1/channels/whatsapp/groups",
        dependencies=[Depends(require_auth)],
        tags=["Channels"],
    )
    async def whatsapp_groups():
        """List WhatsApp groups the bot is currently participating in."""
        import httpx
        gateway_url = os.environ.get(
            "KAZE_GATEWAY_URL_INTERNAL", "http://localhost:18789"
        )
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{gateway_url}/whatsapp/groups", timeout=15)
                if resp.status_code >= 400:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text[:200])
                return resp.json()
        except httpx.TimeoutException:
            raise HTTPException(status_code=504, detail="Groups fetch timed out")

    @app.get(
        "/api/v1/channels/whatsapp/pair-status",
        dependencies=[Depends(require_auth)],
        tags=["Channels"],
    )
    async def whatsapp_pair_status():
        """Latest WhatsApp QR + connection state for poll-based pairing UIs."""
        import httpx

        gateway_url = os.environ.get(
            "KAZE_GATEWAY_URL_INTERNAL", "http://localhost:18789"
        )
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{gateway_url}/pair/whatsapp/status", timeout=10)
                if resp.status_code >= 400:
                    raise HTTPException(status_code=resp.status_code, detail=resp.text[:200])
                return resp.json()
        except httpx.TimeoutException:
            raise HTTPException(status_code=504, detail="Status fetch timed out")

    # ── Gateway compat ─────────────────────────────────────
    @app.get("/config/channels", include_in_schema=False)
    async def get_gateway_config():
        """Internal endpoint for channel-gateway sidecar. No auth."""
        return store.get_gateway_clients_config()
