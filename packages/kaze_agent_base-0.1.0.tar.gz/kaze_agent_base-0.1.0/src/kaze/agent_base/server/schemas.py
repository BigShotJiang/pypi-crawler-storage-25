"""Pydantic request/response models for the API."""

from pydantic import BaseModel, Field


class ChannelConfig(BaseModel):
    """Channel configuration (Telegram, Slack, WhatsApp)."""

    enabled: bool = True
    botToken: str | None = None
    allowFrom: list[int | str] | None = None
    requireMention: bool | None = None
    allowedGroups: list[str] | None = None
    allowedChannels: list[str] | None = None
    appToken: str | None = None
    authDir: str | None = None
    pairingPhone: str | None = None

    model_config = {"extra": "allow"}


class SecretInfo(BaseModel):
    masked: str = Field(description="Masked value showing only last 4 chars")
    length: int = Field(description="Original value length")


class SecretSet(BaseModel):
    value: str = Field(description="Secret value")


class SecretSetResponse(BaseModel):
    name: str
    masked: str


class SettingValue(BaseModel):
    value: str = Field(description="Setting value")


class SettingResponse(BaseModel):
    name: str
    value: str


class McpRefreshRequest(BaseModel):
    servers: list[str] | None = Field(
        None, description="Server names to refresh. Null = all."
    )


class McpRefreshResponse(BaseModel):
    refreshed: list[str] = []
    errors: list[str] = []


class WhatsAppPairRequest(BaseModel):
    send_to_telegram: bool = Field(False, description="Send QR code to Telegram")


class HealthResponse(BaseModel):
    status: str
    build: str
    environment: str


class ErrorResponse(BaseModel):
    detail: str
