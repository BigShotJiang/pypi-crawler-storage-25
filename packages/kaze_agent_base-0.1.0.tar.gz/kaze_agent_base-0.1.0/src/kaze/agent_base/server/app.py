"""FastAPI application factory.

Creates the ADK-backed FastAPI app and registers config/management routes.

This module is generic: downstream agent packages pass their own
branding, agents_dir, and app module name to :func:`create_app`.
"""

import importlib
import os
from pathlib import Path

from ..state.config_store import ConfigStore
from ..state.memory import Mem0MemoryService
from ..workflow.mcp import refresh_mcp_toolsets
from ..jobs.engine import init_engine
from .routes import register_routes


def _register_memory_service():
    from google.adk.cli.service_registry import get_service_registry
    registry = get_service_registry()
    registry.register_memory_service(
        "mem0",
        lambda uri, **kw: Mem0MemoryService(),
    )


_register_memory_service()


def create_app(
    *,
    app_module: str,
    agents_dir: Path | str,
    title: str = "Agent API",
    description: str = "",
    version: str = "0.0.0",
    memory_service_uri: str = "mem0://kaze",
):
    """Build and return the configured FastAPI application.

    Args:
        app_module: Python import path of the downstream agent package
            (e.g., ``"kaze_ops"``). Must expose ``_workflow_agents``,
            ``_workflow_config``, and ``_workflow_mcp_toolsets`` at
            module level after the package's ``__init__`` runs.
        agents_dir: filesystem directory ADK uses to locate the app
            module. Typically the parent of ``app_module``'s package.
        title / description / version: FastAPI metadata.
        memory_service_uri: URI passed to ADK's memory service factory.

    Returns:
        ``(app, host, port)`` tuple.
    """
    from google.adk.cli.fast_api import get_fast_api_app

    port = int(os.environ.get("KAZE_A2A_PORT", "8080"))
    host = os.environ.get("KAZE_A2A_HOST", "0.0.0.0")

    app = get_fast_api_app(
        agents_dir=str(agents_dir),
        web=False,
        a2a=True,
        host=host,
        port=port,
        memory_service_uri=memory_service_uri,
        extra_plugins=["google.adk.plugins.logging_plugin.LoggingPlugin"],
    )

    # Initialize background workflow engine (started in main via asyncio.create_task)
    init_engine()

    app.title = title
    app.description = description
    app.version = version

    # Config store for channels/secrets/settings
    store = ConfigStore()

    # Grab pre-built workflow refs from the downstream app package. ADK
    # imports that package when resolving agents_dir, so its __init__
    # has already populated these attributes by the time we reach here.
    app_mod = importlib.import_module(app_module)
    workflow_agents = app_mod._workflow_agents
    workflow_config = app_mod._workflow_config
    workflow_mcp_toolsets = app_mod._workflow_mcp_toolsets

    def refresh_mcp_fn(server_names=None):
        return refresh_mcp_toolsets(
            config=workflow_config,
            agents=workflow_agents,
            toolsets=workflow_mcp_toolsets,
            config_store=store,
            server_names=server_names,
        )

    register_routes(app, store, refresh_mcp_fn)

    return app, host, port


def run(app, host: str, port: int):
    """Run the ASGI app with uvicorn alongside the background engine."""
    import asyncio
    import uvicorn

    from ..jobs.engine import get_engine

    engine = get_engine()
    config = uvicorn.Config(app, host=host, port=port)
    server = uvicorn.Server(config)

    async def _run():
        engine_task = asyncio.create_task(engine.run())
        await server.serve()
        engine_task.cancel()

    asyncio.run(_run())
