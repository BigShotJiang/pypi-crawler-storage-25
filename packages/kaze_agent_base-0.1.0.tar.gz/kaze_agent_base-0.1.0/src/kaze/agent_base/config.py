"""Configuration loading — reads config.yaml into a plain dict.

Single responsibility: load and validate the config file.
"""

import os
import yaml
from pathlib import Path


def load_config(path: Path | str | None = None) -> dict:
    """Load config.yaml and return as dict.

    Resolution order:
      1. Explicit ``path`` argument
      2. ``KAZE_CONFIG_PATH`` env var
      3. ``./config.yaml`` in the current working directory

    Raises FileNotFoundError if none resolve to an existing file.
    """
    if path is None:
        path = os.environ.get("KAZE_CONFIG_PATH") or "config.yaml"
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"config.yaml not found at {path}. "
            "Pass load_config(path=...) or set KAZE_CONFIG_PATH."
        )
    config = yaml.safe_load(path.read_text())
    assert "models" in config, f"config.yaml at {path} missing 'models'"
    return config
