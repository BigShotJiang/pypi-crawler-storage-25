"""Workflow engine — runs ADK agent compositions in background anyio tasks.

The engine maintains a long-lived anyio task group (lives for the server's
lifetime via FastAPI lifespan).  Each background workflow gets its own
CancelScope so it can be cancelled independently.
"""

from __future__ import annotations

import logging
import os
import time
from typing import Optional

import anyio
import httpx
from anyio.abc import TaskGroup

from google.adk.agents.base_agent import BaseAgent
from google.adk.runners import Runner
from google.adk.sessions.in_memory_session_service import InMemorySessionService
from google.genai import types

from .store import JobStore

logger = logging.getLogger(__name__)

GATEWAY_URL = os.environ.get("KAZE_GATEWAY_URL_INTERNAL", "http://localhost:18789")
APP_NAME = os.environ.get("KAZE_APP_NAME", "kaze_app")


class WorkflowEngine:
    """Runs composed ADK agents in background anyio tasks."""

    def __init__(self, store: JobStore):
        self.store = store
        self._scopes: dict[str, anyio.CancelScope] = {}
        self._tg: Optional[TaskGroup] = None
        self._session_service = InMemorySessionService()
        self.started = anyio.Event()

    async def run(self):
        """Start the engine.  Call from FastAPI lifespan task group."""
        async with anyio.create_task_group() as tg:
            self._tg = tg
            self.started.set()
            print("[engine] Background workflow engine started")
            await anyio.sleep_forever()

    def start(self, job_id: str, agent: BaseAgent, user_id: str, message: str = ""):
        """Spawn a background workflow.  Returns immediately."""
        if self._tg is None:
            raise RuntimeError("WorkflowEngine not running — call run() first")
        self._tg.start_soon(self._execute, job_id, agent, user_id, message)

    def cancel(self, job_id: str) -> bool:
        """Cancel a running workflow by job_id.  Returns True if found."""
        scope = self._scopes.get(job_id)
        if scope:
            scope.cancel()
            self.store.cancel(job_id)
            logger.info(f"[engine] Cancelled job {job_id}")
            return True
        return False

    def cancel_active(self, user_id: str) -> Optional[str]:
        """Cancel any active job for this user.  Returns cancelled job_id."""
        active = self.store.get_active(user_id)
        if active and active.id in self._scopes:
            self.cancel(active.id)
            return active.id
        return None

    async def _execute(
        self, job_id: str, agent: BaseAgent, user_id: str, message: str
    ):
        scope = anyio.CancelScope()
        self._scopes[job_id] = scope

        try:
            with scope:
                self.store.update_status(job_id, "running")
                session = await self._session_service.create_session(
                    app_name=APP_NAME, user_id=user_id
                )
                runner = Runner(
                    app_name=APP_NAME,
                    agent=agent,
                    session_service=self._session_service,
                )
                final_text = await self._stream_agent_to_final_text(
                    runner=runner,
                    session_id=session.id,
                    user_id=user_id,
                    message=message,
                    scope=scope,
                    job_id=job_id,
                )
                if scope.cancel_called:
                    return
                self.store.complete(job_id, final_text)
                logger.info(f"[engine] Job {job_id} completed ({len(final_text)} chars)")
                await self._push_to_chat(user_id, final_text)

        except Exception as e:
            logger.error(f"[engine] Job {job_id} failed: {e}", exc_info=True)
            self.store.fail(job_id, str(e)[:500])
            await self._push_to_chat(user_id, f"Background workflow failed: {e}")
        finally:
            self._scopes.pop(job_id, None)

    async def _stream_agent_to_final_text(
        self,
        *,
        runner: Runner,
        session_id: str,
        user_id: str,
        message: str,
        scope: anyio.CancelScope,
        job_id: str,
    ) -> str:
        """Drive the ADK runner and return the last text emitted.

        Tracks function calls as user-visible progress, returns early if
        the scope is cancelled. The "last text part wins" contract
        matches how ADK agents emit: tool-calling parts are intermediate,
        the final assistant text is what the caller wants surfaced.
        """
        user_content = types.Content(
            role="user",
            parts=[types.Part(text=message or "Execute the workflow.")],
        )
        final_text = ""
        async for event in runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=user_content,
        ):
            if scope.cancel_called:
                break
            if not event.content or not event.content.parts:
                continue
            for part in event.content.parts:
                if getattr(part, "function_call", None):
                    self.store.update_progress(
                        job_id, f"Running {part.function_call.name}..."
                    )
                if getattr(part, "text", None):
                    final_text = part.text
        return final_text

    async def _push_to_chat(self, user_id: str, text: str):
        """Push a message to the user's chat via the channel gateway."""
        parts = user_id.split(":")
        if len(parts) < 3:
            logger.warning(f"[engine] Cannot push — invalid user_id: {user_id}")
            return

        channel, chat_id = parts[0], parts[2]

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                res = await client.post(
                    f"{GATEWAY_URL}/send",
                    json={"channel": channel, "chatId": chat_id, "text": text},
                )
                if res.status_code == 200:
                    logger.info(f"[engine] Pushed result to {channel}:{chat_id}")
                else:
                    logger.error(f"[engine] Push failed ({res.status_code}): {res.text[:200]}")
        except Exception as e:
            logger.error(f"[engine] Push error: {e}")


# Module-level singleton, initialized at app startup
_engine: Optional[WorkflowEngine] = None


def init_engine(store: Optional[JobStore] = None) -> WorkflowEngine:
    global _engine
    if store is None:
        store = JobStore()
    _engine = WorkflowEngine(store)
    return _engine


def get_engine() -> WorkflowEngine:
    if _engine is None:
        raise RuntimeError("WorkflowEngine not initialized — call init_engine() first")
    return _engine
