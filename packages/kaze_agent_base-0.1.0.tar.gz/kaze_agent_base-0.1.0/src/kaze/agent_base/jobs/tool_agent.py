"""ToolAgent — lightweight BaseAgent that calls a single tool without LLM.

Used as a leaf node in workflow compositions (e.g., inside a ParallelAgent)
to run tool functions in parallel without burning LLM tokens.
"""

from __future__ import annotations

import inspect
import logging
from typing import Any, AsyncGenerator, Callable

import anyio.to_thread
from google.adk.agents.base_agent import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.adk.events.event import Event
from google.genai import types
from pydantic import Field

logger = logging.getLogger(__name__)


class ToolAgent(BaseAgent):
    """Runs a single tool function and yields its result as an event.

    The tool function is called directly — no LLM involved.
    Result is stored in session state under ``state:{self.name}:result``
    so downstream agents (e.g., a compile step) can read it.
    """

    tool_fn: Callable = Field(exclude=True)
    tool_args: dict[str, Any] = Field(default_factory=dict)

    model_config = {"arbitrary_types_allowed": True}

    async def _run_async_impl(
        self, ctx: InvocationContext
    ) -> AsyncGenerator[Event, None]:
        logger.info(f"[ToolAgent:{self.name}] calling {self.tool_fn.__name__}({self.tool_args})")

        try:
            if inspect.iscoroutinefunction(self.tool_fn):
                result = await self.tool_fn(**self.tool_args)
            else:
                # Sync tool_fn may do blocking I/O; offload so the event
                # loop stays responsive to other tasks in the group.
                result = await anyio.to_thread.run_sync(
                    lambda: self.tool_fn(**self.tool_args)
                )

            result_text = str(result) if result is not None else ""

            yield Event(
                invocation_id=ctx.invocation_id,
                author=self.name,
                branch=ctx.branch,
                content=types.Content(
                    role="model",
                    parts=[types.Part(text=result_text)],
                ),
                state={f"state:{self.name}:result": result_text},
            )

        except Exception as e:
            logger.error(f"[ToolAgent:{self.name}] failed: {e}")
            yield Event(
                invocation_id=ctx.invocation_id,
                author=self.name,
                branch=ctx.branch,
                content=types.Content(
                    role="model",
                    parts=[types.Part(text=f"Error: {e}")],
                ),
            )
