"""SQLite-backed job store for background workflows."""

import os
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class Job:
    id: str
    user_id: str
    template: str
    status: str  # pending | running | completed | failed | cancelled
    progress: str = ""
    result: str = ""
    error: str = ""
    created_at: float = 0.0
    updated_at: float = 0.0


class JobStore:
    def __init__(self, db_path: Optional[Path] = None):
        if db_path is None:
            data_dir = Path(os.environ.get("KAZE_DATA_DIR", ".adk"))
            db_path = data_dir / "jobs.db"
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(str(db_path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("""
            CREATE TABLE IF NOT EXISTS workflow_jobs (
                id          TEXT PRIMARY KEY,
                user_id     TEXT NOT NULL,
                template    TEXT NOT NULL,
                status      TEXT NOT NULL DEFAULT 'pending',
                progress    TEXT DEFAULT '',
                result      TEXT DEFAULT '',
                error       TEXT DEFAULT '',
                created_at  REAL NOT NULL,
                updated_at  REAL NOT NULL
            )
        """)
        self._db.commit()

    def create(self, user_id: str, template: str) -> Job:
        now = time.time()
        job = Job(
            id=uuid.uuid4().hex[:12],
            user_id=user_id,
            template=template,
            status="pending",
            created_at=now,
            updated_at=now,
        )
        self._db.execute(
            "INSERT INTO workflow_jobs (id, user_id, template, status, created_at, updated_at) VALUES (?,?,?,?,?,?)",
            (job.id, job.user_id, job.template, job.status, job.created_at, job.updated_at),
        )
        self._db.commit()
        return job

    def get(self, job_id: str) -> Optional[Job]:
        row = self._db.execute(
            "SELECT id, user_id, template, status, progress, result, error, created_at, updated_at FROM workflow_jobs WHERE id=?",
            (job_id,),
        ).fetchone()
        if not row:
            return None
        return Job(*row)

    def get_active(self, user_id: str) -> Optional[Job]:
        row = self._db.execute(
            "SELECT id, user_id, template, status, progress, result, error, created_at, updated_at "
            "FROM workflow_jobs WHERE user_id=? AND status IN ('pending','running') ORDER BY created_at DESC LIMIT 1",
            (user_id,),
        ).fetchone()
        if not row:
            return None
        return Job(*row)

    def get_latest(self, user_id: str) -> Optional[Job]:
        row = self._db.execute(
            "SELECT id, user_id, template, status, progress, result, error, created_at, updated_at "
            "FROM workflow_jobs WHERE user_id=? ORDER BY created_at DESC LIMIT 1",
            (user_id,),
        ).fetchone()
        if not row:
            return None
        return Job(*row)

    def update_status(self, job_id: str, status: str):
        self._db.execute(
            "UPDATE workflow_jobs SET status=?, updated_at=? WHERE id=?",
            (status, time.time(), job_id),
        )
        self._db.commit()

    def update_progress(self, job_id: str, progress: str):
        self._db.execute(
            "UPDATE workflow_jobs SET progress=?, updated_at=? WHERE id=?",
            (progress, time.time(), job_id),
        )
        self._db.commit()

    def complete(self, job_id: str, result: str):
        self._db.execute(
            "UPDATE workflow_jobs SET status='completed', result=?, updated_at=? WHERE id=?",
            (result, time.time(), job_id),
        )
        self._db.commit()

    def fail(self, job_id: str, error: str):
        self._db.execute(
            "UPDATE workflow_jobs SET status='failed', error=?, updated_at=? WHERE id=?",
            (error, time.time(), job_id),
        )
        self._db.commit()

    def cancel(self, job_id: str):
        self._db.execute(
            "UPDATE workflow_jobs SET status='cancelled', updated_at=? WHERE id=?",
            (time.time(), job_id),
        )
        self._db.commit()
