"""Filesystem helpers — the two ops bash struggles with.

Reading and searching are best done via ``run_bash`` (``cat -n``, ``rg``,
``find``). Writing arbitrary content via heredoc breaks on ``$``, backticks
and EOF markers in the payload, and ``sed -i`` is dangerous + BSD/GNU
divergent — so those get dedicated tools.
"""

from __future__ import annotations

from pathlib import Path


def write_file(path: str, content: str) -> dict:
    """Create or overwrite a file with the given content.

    Prefer this over ``cat > file <<EOF`` in bash — heredocs break on ``$``,
    backticks, and EOF markers in the payload. Parent dirs are created
    automatically.

    Args:
        path:    Absolute path to the file.
        content: Full file contents (overwrites any existing file).
    """
    p = Path(path).expanduser()
    if not p.is_absolute():
        return {"error": f"path must be absolute: {path}"}
    p.parent.mkdir(parents=True, exist_ok=True)
    data = content.encode("utf-8")
    p.write_bytes(data)
    return {"path": str(p), "bytes_written": len(data)}


def edit_file(
    path: str,
    old_string: str,
    new_string: str,
    replace_all: bool = False,
) -> dict:
    """Surgical string replace inside an existing file.

    Errors if ``old_string`` is missing, or appears more than once and
    ``replace_all=False`` — pass a longer surrounding context to make it
    unique, or set ``replace_all=True`` to swap every occurrence.

    Prefer this over ``sed -i`` (dangerous regex semantics + BSD/GNU
    divergence).

    Args:
        path:        Absolute path to the file.
        old_string:  Exact text to find.
        new_string:  Replacement text.
        replace_all: Replace every occurrence (default: just one, must be unique).
    """
    p = Path(path).expanduser()
    if not p.is_absolute():
        return {"error": f"path must be absolute: {path}"}
    if not p.is_file():
        return {"error": f"file not found: {path}"}

    text = p.read_text(encoding="utf-8")
    count = text.count(old_string)
    if count == 0:
        return {"error": "old_string not found in file"}
    if count > 1 and not replace_all:
        return {
            "error": (
                f"old_string appears {count} times — pass replace_all=True "
                "or extend old_string with surrounding context to make it unique"
            )
        }

    if replace_all:
        new_text = text.replace(old_string, new_string)
        replacements = count
    else:
        new_text = text.replace(old_string, new_string, 1)
        replacements = 1

    p.write_text(new_text, encoding="utf-8")
    return {"path": str(p), "replacements": replacements}
