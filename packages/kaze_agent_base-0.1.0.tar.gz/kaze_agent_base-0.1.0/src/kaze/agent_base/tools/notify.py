"""Notification tool — push messages to the user's chat via channel gateway.

Used for long-running tasks: agent acknowledges immediately, runs the
task, then pushes the result when done.
"""

import os
import logging

import httpx
from google.adk.tools.tool_context import ToolContext

logger = logging.getLogger(__name__)

GATEWAY_URL = os.environ.get("KAZE_GATEWAY_URL_INTERNAL", "http://localhost:18789")


async def send_message(
    text: str,
    tool_context: ToolContext,
) -> dict:
    """Send a message to the user's current chat channel.

    Use this to push updates or results without waiting for the user
    to ask. The message is delivered via the channel gateway to
    whatever platform the user is on (Telegram, WhatsApp, Slack).

    Args:
        text: The message text to send (markdown supported).
    """
    # Extract channel info from the user_id format: "telegram:dm:356350712"
    invocation_ctx = tool_context.get_invocation_context()
    user_id = invocation_ctx.user_id if invocation_ctx else ""

    if not user_id or ":" not in user_id:
        return {"error": "Cannot determine chat channel from user_id"}

    parts = user_id.split(":")
    if len(parts) < 3:
        return {"error": f"Invalid user_id format: {user_id}"}

    channel = parts[0]  # "telegram", "whatsapp", "slack"
    chat_id = parts[2]  # the actual chat ID

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            res = await client.post(
                f"{GATEWAY_URL}/send",
                json={"channel": channel, "chatId": chat_id, "text": text},
            )

            if res.status_code == 200:
                logger.info(f"Sent message to {channel}:{chat_id}")
                return {"ok": True, "channel": channel}
            else:
                logger.error(f"Send failed ({res.status_code}): {res.text[:200]}")
                return {"error": f"Send failed: {res.status_code}"}

    except Exception as e:
        logger.error(f"Gateway send error: {e}")
        return {"error": str(e)[:200]}
