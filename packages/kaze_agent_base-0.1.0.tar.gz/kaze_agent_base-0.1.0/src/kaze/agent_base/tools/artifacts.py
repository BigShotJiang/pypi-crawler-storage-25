"""Artifact spill + read helpers — keep giant tool outputs out of the LLM context.

When a tool (execute_python, github_digest, crawler, ...) produces more text
than the model can safely chew, we spill the full payload to
`$KAZE_DATA_DIR/artifacts/<uuid>.<ext>` and return only a head+tail preview
plus the artifact path. The agent can then `read_artifact(path, start, limit)`
to page through the rest on demand — same pattern Claude Code uses for Read.
"""

from __future__ import annotations

import os
import uuid
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent.parent
ARTIFACTS_DIR = Path(
    os.environ.get("KAZE_DATA_DIR", str(_REPO_ROOT / ".adk"))
) / "artifacts"

MAX_INLINE_CHARS = int(os.environ.get("KAZE_TOOL_MAX_INLINE", "16000"))
TAIL_CHARS = 500


def _ensure_dir() -> Path:
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)
    return ARTIFACTS_DIR


def spill(content: str, ext: str = "txt") -> str:
    """Persist `content` to a fresh artifact file and return its absolute path."""
    _ensure_dir()
    path = ARTIFACTS_DIR / f"{uuid.uuid4().hex}.{ext}"
    path.write_text(content, encoding="utf-8")
    return str(path)


def truncate_with_spill(
    output: str,
    ext: str = "txt",
    max_inline: int | None = None,
) -> tuple[str, str | None, int]:
    """Cap a tool's text output and spill the full payload to disk if too big.

    Returns ``(inline_output, artifact_path_or_None, original_len)``.
    Callers attach ``artifact_path`` to their response so the agent can page
    through the full content via ``read_artifact``.
    """
    cap = max_inline if max_inline is not None else MAX_INLINE_CHARS
    original_len = len(output)
    if original_len <= cap:
        return output, None, original_len

    artifact_path = spill(output, ext=ext)
    head_budget = cap - TAIL_CHARS - 200
    head = output[:head_budget]
    tail = output[-TAIL_CHARS:]
    omitted = original_len - len(head) - len(tail)
    marker = (
        f"\n\n[... {omitted} chars truncated; "
        f"call read_artifact('{artifact_path}', start=..., limit=...) "
        f"to page through the full output ...]\n\n"
    )
    return head + marker + tail, artifact_path, original_len


def read_artifact(path: str, start: int = 0, limit: int = 4000) -> dict:
    """Read a slice of a spilled artifact file.

    Use this after a tool returned `artifact_path` because its output was
    truncated. Page through the file by calling repeatedly with a larger
    `start`. Returns bytes actually read plus a `next_start` you can feed
    back in.

    Args:
        path:  Absolute path returned as `artifact_path` by another tool.
        start: Character offset to start reading from (default 0).
        limit: Max characters to return (default 4000, hard cap 20000).

    Returns:
        {content, start, end, next_start, total_chars, eof}
    """
    limit = max(1, min(int(limit), 20_000))
    start = max(0, int(start))

    p = Path(path)
    if not p.is_file():
        return {"error": f"artifact not found: {path}"}

    # Safety: only read from the artifacts dir we manage.
    try:
        p.resolve().relative_to(ARTIFACTS_DIR.resolve())
    except ValueError:
        return {"error": "path outside artifacts directory"}

    text = p.read_text(encoding="utf-8", errors="replace")
    total = len(text)
    end = min(start + limit, total)
    chunk = text[start:end]
    return {
        "content": chunk,
        "start": start,
        "end": end,
        "next_start": end,
        "total_chars": total,
        "eof": end >= total,
    }
