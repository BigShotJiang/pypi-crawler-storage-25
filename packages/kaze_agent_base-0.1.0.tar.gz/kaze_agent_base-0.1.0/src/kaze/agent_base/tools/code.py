"""Code execution tool — run Python scripts for data gathering.

Like Claude Code's Bash tool: the agent writes code, the tool runs it,
stdout comes back as the result. Used for data-heavy tasks where direct
API calls are faster than chaining MCP tool calls.

Large outputs are spilled to an artifact file and only a head+tail preview
is returned to the LLM. The agent can then call `read_artifact` to page
through the rest — this prevents the "token limit exceeded, refusing to
process" failure mode when a script dumps a huge blob.

A subprocess-tracking preamble is injected into every script so
non-zero ``subprocess.run`` exits are surfaced as ``subprocess_warnings``
in the return payload — even when the outer script catches the error
and exit-0s. This catches the common LLM anti-pattern of writing a
``run_safe()`` wrapper that silently returns ``None`` on failure.
"""

import os
import subprocess
import logging

from .artifacts import truncate_with_spill
from .bash import _ensure_workspace

logger = logging.getLogger(__name__)

TIMEOUT_SECONDS = int(os.environ.get("KAZE_CODE_TIMEOUT", "30"))
# Honour the legacy code-specific cap if set, else fall back to the shared default.
_CODE_MAX_INLINE_OVERRIDE = os.environ.get("KAZE_CODE_MAX_INLINE")

# Prepended to every user script. Wraps subprocess.run so failures that
# the script handles silently still reach the LLM as a warning on stderr.
# Prefix names with `__kaze_` so they don't collide with user code.
_SUBPROCESS_TRACKER = '''\
import subprocess as __kaze_sp
import sys as __kaze_sys
import atexit as __kaze_atexit

__kaze_failures = []
__kaze_orig_run = __kaze_sp.run

def __kaze_tracked_run(*args, **kwargs):
    result = __kaze_orig_run(*args, **kwargs)
    if getattr(result, "returncode", 0) != 0:
        cmd = args[0] if args else kwargs.get("args", "?")
        cmd_repr = repr(cmd)[:200]
        stderr_val = getattr(result, "stderr", "") or ""
        if isinstance(stderr_val, bytes):
            stderr_val = stderr_val.decode("utf-8", "replace")
        __kaze_failures.append(
            "[subprocess exit=" + str(result.returncode) + "] "
            + cmd_repr + ": " + stderr_val.strip()[-300:]
        )
    return result

__kaze_sp.run = __kaze_tracked_run

def __kaze_emit():
    if __kaze_failures:
        print("--- swallowed subprocess failures ---", file=__kaze_sys.stderr)
        for __kaze_f in __kaze_failures:
            print(__kaze_f, file=__kaze_sys.stderr)

__kaze_atexit.register(__kaze_emit)
'''


def execute_python(code: str) -> dict:
    """Execute a Python script and return its stdout output.

    Use this for data gathering tasks: searching GitHub API, aggregating
    results across repos, formatting reports. Much faster than making
    many individual MCP tool calls.

    The script has access to:
    - GITHUB_TOKEN environment variable for GitHub API calls
    - Standard library (json, urllib.request, os, etc.)

    Large stdout is automatically spilled to an artifact file. When that
    happens the return value includes `artifact_path` and `total_chars`;
    use the `read_artifact` tool to page through the rest.

    Args:
        code: Python code to execute. Use print() for output.
    """
    try:
        result = subprocess.run(
            ["python3", "-c", _SUBPROCESS_TRACKER + code],
            capture_output=True,
            text=True,
            timeout=TIMEOUT_SECONDS,
            cwd=str(_ensure_workspace()),
            env={**os.environ},
        )

        max_inline = int(_CODE_MAX_INLINE_OVERRIDE) if _CODE_MAX_INLINE_OVERRIDE else None
        inline, artifact_path, total = truncate_with_spill(
            result.stdout, max_inline=max_inline
        )

        stderr = result.stderr or ""
        has_swallowed = "--- swallowed subprocess failures ---" in stderr

        if result.returncode != 0:
            error = stderr[-500:] if stderr else "Unknown error"
            logger.warning(f"Code execution failed: {error[:200]}")
            payload = {
                "output": inline,
                "error": error,
                "exit_code": result.returncode,
                "total_chars": total,
            }
            if artifact_path:
                payload["artifact_path"] = artifact_path
            return payload

        payload = {"output": inline, "total_chars": total}
        if has_swallowed:
            # Script exited clean but swallowed one or more subprocess errors.
            # Surface them so the LLM can correct its shell commands on the
            # next ReACT turn instead of trusting zero-result output.
            payload["subprocess_warnings"] = stderr[-1000:]
            logger.warning(
                "execute_python swallowed subprocess failures: %s",
                stderr[-300:],
            )
        if artifact_path:
            payload["artifact_path"] = artifact_path
            logger.info(
                f"execute_python output spilled: {total} chars -> {artifact_path}"
            )
        return payload

    except subprocess.TimeoutExpired:
        return {"error": f"Script timed out after {TIMEOUT_SECONDS}s"}
    except Exception as e:
        return {"error": str(e)[:300]}
