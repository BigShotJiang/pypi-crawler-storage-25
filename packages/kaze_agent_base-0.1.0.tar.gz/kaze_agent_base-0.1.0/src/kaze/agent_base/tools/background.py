"""Background workflow tool — start, check, and cancel long-running workflows.

Single tool with an `action` parameter so the root agent only needs one
tool in its toolbox instead of three.
"""

import time
import logging

from google.adk.tools.tool_context import ToolContext

from ..jobs.engine import get_engine
from ..plugin import get_workflow_templates

logger = logging.getLogger(__name__)


async def background(
    action: str,
    template: str = "",
    params: dict = {},
    tool_context: ToolContext = None,
) -> dict:
    """Manage background workflows — start, check status, or cancel.

    Use this for long-running tasks like org-wide digests or multi-repo analysis.
    The workflow runs in the background and results are pushed to the chat when done.

    Args:
        action: One of "start", "check", or "cancel".
        template: (start only) Workflow template name. Available: "github_digest".
        params: (start only) Template parameters. For github_digest: {"org": "speedrun-labs", "since": "2026-04-08"}.
    """
    engine = get_engine()
    invocation_ctx = tool_context.get_invocation_context()
    user_id = invocation_ctx.user_id if invocation_ctx else ""

    if not user_id:
        return {"error": "Cannot determine user_id"}

    if action == "start":
        if template not in get_workflow_templates():
            return {"error": f"Unknown template '{template}'. Available: {list(get_workflow_templates().keys())}"}

        # Cancel any existing active job for this user
        cancelled = engine.cancel_active(user_id)
        if cancelled:
            logger.info(f"Cancelled previous job {cancelled} for {user_id}")

        try:
            agent = get_workflow_templates()[template](**params)
        except Exception as e:
            return {"error": f"Failed to build workflow: {e}"}

        job = engine.store.create(user_id=user_id, template=template)
        engine.start(job.id, agent, user_id)

        return {
            "job_id": job.id,
            "status": "started",
            "template": template,
            "message": "Workflow started in the background. Results will be sent when complete.",
        }

    elif action == "check":
        job = engine.store.get_latest(user_id)
        if not job:
            return {"status": "none", "message": "No background workflows found."}

        elapsed = time.time() - job.created_at
        result = {
            "job_id": job.id,
            "template": job.template,
            "status": job.status,
            "progress": job.progress,
            "elapsed_seconds": round(elapsed, 1),
        }
        if job.status == "completed":
            result["result"] = job.result[:500]
        elif job.status == "failed":
            result["error"] = job.error
        return result

    elif action == "cancel":
        cancelled = engine.cancel_active(user_id)
        if cancelled:
            return {"status": "cancelled", "job_id": cancelled}
        return {"status": "none", "message": "No active workflow to cancel."}

    else:
        return {"error": f"Unknown action '{action}'. Use 'start', 'check', or 'cancel'."}
