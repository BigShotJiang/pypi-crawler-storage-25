"""Bash execution tool — run arbitrary shell commands.

The workhorse for filesystem ops Kazane needs to do ad-hoc: read with
``cat -n``, search with ``rg``/``find``, list with ``ls``, compose with
pipes. ``write_file``/``edit_file`` cover the two ops bash struggles with
(arbitrary content, surgical edits).

Large stdout is spilled via ``artifacts.truncate_with_spill`` — same shape
as ``execute_python``.
"""

from __future__ import annotations

import logging
import os
import subprocess
from pathlib import Path

from .artifacts import ARTIFACTS_DIR, truncate_with_spill

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT = int(os.environ.get("KAZE_BASH_TIMEOUT", "120"))

# Workspace for ad-hoc files agents create. Sibling of artifacts/.
# Exported to os.environ so subprocesses (execute_python, run_bash) and
# prompt {{VAR}} substitution see the same resolved path.
WORKSPACE_DIR = Path(
    os.environ.get("KAZE_WORKSPACE_DIR", str(ARTIFACTS_DIR.parent / "workspace"))
)
os.environ["KAZE_WORKSPACE_DIR"] = str(WORKSPACE_DIR)


def _ensure_workspace() -> Path:
    WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)
    return WORKSPACE_DIR


def run_bash(command: str, timeout: int = DEFAULT_TIMEOUT, cwd: str | None = None) -> dict:
    """Run a shell command and return its output.

    Use this as the primary filesystem tool: read with ``cat -n``, search
    with ``rg pattern path`` or ``find . -name '*.py'``, list with
    ``ls -la``, chain with pipes. ``write_file`` and ``edit_file`` are
    safer for creating/modifying files.

    cwd defaults to ``$KAZE_WORKSPACE_DIR`` (auto-created), so files dropped
    with relative paths land in the workspace.

    Large stdout is automatically spilled to an artifact and replaced with
    a head+tail preview; ``artifact_path`` will be set so you can call
    ``read_artifact`` to page through.

    Args:
        command: Shell command (run via ``bash -c``).
        timeout: Max seconds before the command is killed (default 120).
        cwd:     Working directory; defaults to the workspace.
    """
    workdir = Path(cwd).expanduser() if cwd else _ensure_workspace()
    env = {**os.environ, "KAZE_WORKSPACE_DIR": str(_ensure_workspace())}

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(workdir),
            env=env,
        )
    except subprocess.TimeoutExpired as e:
        partial_out = (e.stdout or b"").decode("utf-8", errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        partial_err = (e.stderr or b"").decode("utf-8", errors="replace") if isinstance(e.stderr, bytes) else (e.stderr or "")
        return {
            "error": f"timed out after {timeout}s",
            "partial_stdout": partial_out[-2000:],
            "partial_stderr": partial_err[-2000:],
        }
    except Exception as e:
        return {"error": str(e)[:300]}

    inline, artifact_path, total = truncate_with_spill(result.stdout)
    payload: dict = {
        "stdout": inline,
        "stderr": result.stderr[-2000:] if result.stderr else "",
        "exit_code": result.returncode,
        "total_chars": total,
    }
    if artifact_path:
        payload["artifact_path"] = artifact_path
        logger.info(f"run_bash output spilled: {total} chars -> {artifact_path}")
    return payload
