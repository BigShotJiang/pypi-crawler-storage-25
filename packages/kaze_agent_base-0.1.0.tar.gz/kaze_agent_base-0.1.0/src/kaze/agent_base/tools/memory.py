"""Memory tools exposed to LLM agents.

`save_memory(content)` — explicit save escape hatch (rare; auto-extraction
on every turn already handles most cases via the after_agent callback).

`load_memory(query)` — on-demand semantic recall. Supplements the top-k
preload injected into the system prompt each turn with narrower lookups
mid-reasoning (e.g., "what did they say about deploys?").

Both tools go through ADK's `tool_context` → the configured
`BaseMemoryService` (our `Mem0MemoryService`) → mem0.
"""

from google.adk.memory.memory_entry import MemoryEntry
from google.adk.tools.tool_context import ToolContext
from google.genai import types


async def save_memory(content: str, tool_context: ToolContext) -> dict:
    """Explicitly save a fact to long-term memory.

    You usually don't need this — Kazane auto-learns from each turn. Call
    it only when the user tells you to remember something specific (e.g.,
    "remember that our staging URL is …") or when the fact wouldn't be
    obvious from the conversation text alone.

    Args:
        content: A clear, standalone statement. One fact per call.
    """
    entry = MemoryEntry(
        content=types.Content(role="user", parts=[types.Part(text=content)]),
        author="kazane",
    )
    try:
        await tool_context.add_memory(memories=[entry])
        return {"saved": True, "content": content}
    except Exception as e:
        return {"saved": False, "error": f"Memory service unavailable: {str(e)[:200]}"}


async def load_memory(query: str, tool_context: ToolContext) -> dict:
    """Search long-term memory for facts relevant to a query.

    The top-k most relevant memories are already preloaded into your
    system prompt each turn. Call this tool only when you need something
    more specific — e.g., a narrow question like "what is the user's
    preferred tone?" or "what decisions have we made about deploys?".

    Args:
        query: A natural-language question or search phrase.

    Returns:
        {"memories": [{"id", "content"}]} or {"memories": [], "note": ...}
    """
    try:
        response = await tool_context.search_memory(query=query)
    except Exception as e:
        return {"memories": [], "error": f"Memory service unavailable: {str(e)[:200]}"}

    hits = getattr(response, "memories", None) or []
    out = []
    for m in hits:
        parts = (m.content.parts if m.content else None) or []
        text = " ".join(p.text for p in parts if p.text)
        if text:
            out.append({"id": m.id, "content": text})
    if not out:
        return {"memories": [], "note": "No relevant memories found."}
    return {"memories": out}
