"""System utility tools — datetime, timezone, etc.

Simple Python tools that don't need external services.
Available to all specialists that need them.
"""

from datetime import datetime, timezone


def get_current_time(tz: str = "Asia/Bangkok") -> dict:
    """Get the current date and time.

    Returns ISO 8601 formatted datetime. Use this when you need to know
    today's date for API queries, scheduling, or time-based filters.

    Args:
        tz: IANA timezone name (default: Asia/Bangkok). Examples: UTC, America/New_York, Europe/London.
    """
    try:
        from zoneinfo import ZoneInfo
        now = datetime.now(ZoneInfo(tz))
    except Exception:
        now = datetime.now(timezone.utc)

    return {
        "datetime": now.isoformat(),
        "date": now.strftime("%Y-%m-%d"),
        "time": now.strftime("%H:%M:%S"),
        "timezone": tz,
    }
