"""Unit tests for write_file and edit_file."""

from pathlib import Path

from kaze.agent_base.tools.fs import edit_file, write_file


def test_write_file_creates_and_overwrites(tmp_path):
    target = tmp_path / "out.txt"
    result = write_file(str(target), "hello\nworld\n")
    assert result["path"] == str(target)
    assert result["bytes_written"] == len("hello\nworld\n".encode())
    assert target.read_text() == "hello\nworld\n"

    write_file(str(target), "replaced")
    assert target.read_text() == "replaced"


def test_write_file_handles_arbitrary_content(tmp_path):
    """The whole reason write_file exists: bash heredocs choke on this."""
    payload = "$VAR `cmd` <<EOF\nnested EOF\nweird $(stuff) end"
    target = tmp_path / "tricky.txt"
    write_file(str(target), payload)
    assert target.read_text() == payload


def test_write_file_creates_parent_dirs(tmp_path):
    nested = tmp_path / "a" / "b" / "c.txt"
    write_file(str(nested), "x")
    assert nested.read_text() == "x"


def test_write_file_rejects_relative_path():
    result = write_file("relative.txt", "x")
    assert "error" in result


def test_edit_file_replaces_unique_string(tmp_path):
    p = tmp_path / "f.py"
    p.write_text("def foo():\n    return 1\n")
    result = edit_file(str(p), "return 1", "return 2")
    assert result["replacements"] == 1
    assert p.read_text() == "def foo():\n    return 2\n"


def test_edit_file_errors_when_old_string_missing(tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("hello")
    result = edit_file(str(p), "missing", "x")
    assert "error" in result
    assert p.read_text() == "hello"


def test_edit_file_errors_on_nonunique_without_replace_all(tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("foo bar foo baz")
    result = edit_file(str(p), "foo", "FOO")
    assert "error" in result
    assert "2 times" in result["error"]
    assert p.read_text() == "foo bar foo baz"


def test_edit_file_replace_all(tmp_path):
    p = tmp_path / "f.txt"
    p.write_text("foo bar foo baz foo")
    result = edit_file(str(p), "foo", "FOO", replace_all=True)
    assert result["replacements"] == 3
    assert p.read_text() == "FOO bar FOO baz FOO"


def test_edit_file_missing_file(tmp_path):
    result = edit_file(str(tmp_path / "nope.txt"), "a", "b")
    assert "error" in result


def test_edit_file_rejects_relative_path():
    result = edit_file("rel.txt", "a", "b")
    assert "error" in result
