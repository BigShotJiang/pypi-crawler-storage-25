"""Mem0MemoryService adapter — unit + integration.

Unit tests mock mem0.Memory; integration tests (marked `system`) require
a running gateway + pgvector, same as test_system.py.
"""

import os
import uuid
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
from google.adk.memory.memory_entry import MemoryEntry
from google.genai import types

from kaze.agent_base.state.memory import (
    Mem0MemoryService,
    build_mem0_config,
    format_preamble,
    _parse_db_url,
    DEFAULT_EMBED_DIMS,
)


# --------------------------------------------------------------------- unit


def _entry(text: str, role: str = "user", author: str = "kazane") -> MemoryEntry:
    return MemoryEntry(
        content=types.Content(role=role, parts=[types.Part(text=text)]),
        author=author,
    )


@pytest.fixture
def mock_mem0():
    m = MagicMock()
    m.add.return_value = {"results": [{"id": "m1", "memory": "extracted fact", "event": "ADD"}]}
    m.search.return_value = {"results": []}
    return m


@pytest.fixture
def svc(mock_mem0):
    return Mem0MemoryService(config={"dummy": True}, client=mock_mem0)


def test_parse_db_url_full():
    parts = _parse_db_url("postgresql://alice:secret@db.example.com:5433/mydb")
    assert parts == {
        "host": "db.example.com",
        "port": 5433,
        "user": "alice",
        "password": "secret",
        "dbname": "mydb",
    }


def test_parse_db_url_rejects_non_postgres():
    with pytest.raises(ValueError, match="must be postgresql"):
        _parse_db_url("mysql://u:p@h/db")


def test_build_mem0_config_defaults(monkeypatch):
    for var in [
        "KAZE_GATEWAY_URL", "KAZE_GATEWAY_API_KEY", "KAZE_MEM0_DB_URL",
        "KAZE_MEM0_COLLECTION", "KAZE_MEM0_EXTRACT_MODEL",
        "KAZE_MEM0_EMBED_MODEL", "KAZE_MEM0_EMBED_DIMS",
    ]:
        monkeypatch.delenv(var, raising=False)
    cfg = build_mem0_config()
    assert cfg["vector_store"]["provider"] == "pgvector"
    assert cfg["vector_store"]["config"]["embedding_model_dims"] == DEFAULT_EMBED_DIMS
    assert cfg["llm"]["config"]["openai_base_url"].endswith("/v1")
    assert cfg["embedder"]["config"]["embedding_dims"] == DEFAULT_EMBED_DIMS


def test_build_mem0_config_honors_env(monkeypatch):
    monkeypatch.setenv("KAZE_GATEWAY_URL", "http://gw:9000")
    monkeypatch.setenv("KAZE_MEM0_COLLECTION", "test_collection")
    monkeypatch.setenv("KAZE_MEM0_EXTRACT_MODEL", "custom-model")
    cfg = build_mem0_config()
    assert cfg["llm"]["config"]["openai_base_url"] == "http://gw:9000/v1"
    assert cfg["vector_store"]["config"]["collection_name"] == "test_collection"
    assert cfg["llm"]["config"]["model"] == "custom-model"


@pytest.mark.asyncio
async def test_add_memory_calls_mem0_add(svc, mock_mem0):
    await svc.add_memory(
        app_name="kaze",
        user_id="u1",
        memories=[_entry("I prefer terse responses")],
    )
    mock_mem0.add.assert_called_once()
    call = mock_mem0.add.call_args
    messages = call.args[0]
    assert messages == [{"role": "user", "content": "I prefer terse responses"}]
    assert call.kwargs["user_id"] == "u1"


@pytest.mark.asyncio
async def test_add_memory_skips_empty(svc, mock_mem0):
    await svc.add_memory(
        app_name="kaze",
        user_id="u1",
        memories=[_entry("   ")],
    )
    mock_mem0.add.assert_not_called()


@pytest.mark.asyncio
async def test_add_memory_multiple_entries(svc, mock_mem0):
    entries = [_entry("fact one"), _entry("fact two", role="assistant")]
    await svc.add_memory(app_name="kaze", user_id="u1", memories=entries)
    messages = mock_mem0.add.call_args.args[0]
    assert len(messages) == 2
    assert messages[0]["role"] == "user"
    assert messages[1]["role"] == "assistant"


@pytest.mark.asyncio
async def test_add_memory_swallows_backend_errors(svc, mock_mem0, caplog):
    mock_mem0.add.side_effect = RuntimeError("pg down")
    await svc.add_memory(
        app_name="kaze",
        user_id="u1",
        memories=[_entry("hi")],
    )
    assert any("mem0.add failed" in r.message for r in caplog.records)


@pytest.mark.asyncio
async def test_search_memory_returns_entries(svc, mock_mem0):
    mock_mem0.search.return_value = {
        "results": [
            {"id": "a1", "memory": "likes terse replies", "created_at": "2026-04-16"},
            {"id": "a2", "memory": "Linear team is INGEST", "created_at": "2026-04-15"},
        ]
    }
    resp = await svc.search_memory(app_name="kaze", user_id="u1", query="preferences")
    assert len(resp.memories) == 2
    assert resp.memories[0].id == "a1"
    assert resp.memories[0].content.parts[0].text == "likes terse replies"


@pytest.mark.asyncio
async def test_search_memory_empty_query_returns_empty(svc, mock_mem0):
    resp = await svc.search_memory(app_name="kaze", user_id="u1", query="  ")
    assert resp.memories == []
    mock_mem0.search.assert_not_called()


@pytest.mark.asyncio
async def test_search_memory_passes_top_k_and_user_filter(mock_mem0):
    s = Mem0MemoryService(config={"dummy": True}, top_k=5, client=mock_mem0)
    await s.search_memory(app_name="kaze", user_id="u1", query="q")
    kw = mock_mem0.search.call_args.kwargs
    assert kw["limit"] == 5
    assert kw["filters"] == {"user_id": "u1"}


@pytest.mark.asyncio
async def test_add_session_to_memory_pulls_last_pair(svc, mock_mem0):
    session = SimpleNamespace(
        user_id="u1",
        events=[
            SimpleNamespace(
                content=types.Content(role="user", parts=[types.Part(text="hello")]),
                author="user",
            ),
            SimpleNamespace(
                content=types.Content(role="model", parts=[types.Part(text="hi there")]),
                author="kazane",
            ),
        ],
    )
    await svc.add_session_to_memory(session)
    messages = mock_mem0.add.call_args.args[0]
    assert messages == [
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "hi there"},
    ]


@pytest.mark.asyncio
async def test_add_session_to_memory_noop_when_empty(svc, mock_mem0):
    session = SimpleNamespace(user_id="u1", events=[])
    await svc.add_session_to_memory(session)
    mock_mem0.add.assert_not_called()


def test_format_preamble_nonempty():
    memories = [
        MemoryEntry(content=types.Content(role="user", parts=[types.Part(text="likes concise")])),
        MemoryEntry(content=types.Content(role="user", parts=[types.Part(text="based in SF")])),
    ]
    out = format_preamble(memories)
    assert "What you know about this user" in out
    assert "- likes concise" in out
    assert "- based in SF" in out


def test_format_preamble_empty():
    assert format_preamble([]) == ""


# --------------------------------------------------------------------- system


@pytest.mark.system
@pytest.mark.asyncio
async def test_mem0_round_trip_against_real_gateway():
    """End-to-end: real gateway + real pgvector.

    Requires:
      - kaze-dev compose up (postgres + litellm + gateway)
      - Gateway at KAZE_GATEWAY_URL (default http://localhost:4200)
    """
    # Use a unique collection so we don't collide with the live one
    suffix = uuid.uuid4().hex[:8]
    os.environ["KAZE_MEM0_COLLECTION"] = f"test_memories_{suffix}"

    svc = Mem0MemoryService()
    user = f"test_{suffix}"

    try:
        await svc.add_memory(
            app_name="kaze",
            user_id=user,
            memories=[_entry("user is based in Tokyo")],
        )
        resp = await svc.search_memory(
            app_name="kaze",
            user_id=user,
            query="where is the user located",
        )
        texts = [
            " ".join(p.text for p in (m.content.parts or []) if p.text)
            for m in resp.memories
        ]
        assert any("tokyo" in t.lower() for t in texts), f"got: {texts}"
    finally:
        from tests._memhelpers import drop_mem0_collection

        drop_mem0_collection(f"test_memories_{suffix}")
