"""Unit tests for run_bash."""

import importlib

import pytest


@pytest.fixture
def bash_mod(monkeypatch, tmp_path):
    """Reload bash module pointed at a throwaway data dir per test."""
    monkeypatch.setenv("KAZE_DATA_DIR", str(tmp_path))
    monkeypatch.delenv("KAZE_WORKSPACE_DIR", raising=False)

    from kaze.agent_base.tools import artifacts as artifacts_mod
    from kaze.agent_base.tools import bash as bash_mod

    importlib.reload(artifacts_mod)
    importlib.reload(bash_mod)
    return bash_mod


def test_successful_command(bash_mod):
    result = bash_mod.run_bash("echo hi")
    assert result["exit_code"] == 0
    assert result["stdout"].strip() == "hi"
    assert result["stderr"] == ""


def test_failing_command_surfaces_stderr(bash_mod):
    result = bash_mod.run_bash("ls /no/such/path/here_xyz")
    assert result["exit_code"] != 0
    assert result["stderr"]


def test_timeout_returns_error(bash_mod):
    result = bash_mod.run_bash("sleep 5", timeout=1)
    assert "error" in result
    assert "timed out" in result["error"]


def test_large_output_spills_to_artifact(monkeypatch, tmp_path):
    """Output above the inline cap should land in an artifact file."""
    monkeypatch.setenv("KAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("KAZE_TOOL_MAX_INLINE", "2000")

    from kaze.agent_base.tools import artifacts as artifacts_mod
    from kaze.agent_base.tools import bash as bash_mod

    importlib.reload(artifacts_mod)
    importlib.reload(bash_mod)

    # Print ~10k chars — well above the 2000-char inline cap.
    result = bash_mod.run_bash("python3 -c \"print('X' * 10000)\"")
    assert result["exit_code"] == 0
    assert "artifact_path" in result, result
    assert result["total_chars"] >= 10000
    assert len(result["stdout"]) <= 2000 + 300  # cap + marker wiggle room


def test_cwd_defaults_to_workspace(bash_mod):
    result = bash_mod.run_bash("pwd")
    assert result["exit_code"] == 0
    assert result["stdout"].strip() == str(bash_mod.WORKSPACE_DIR)
    assert bash_mod.WORKSPACE_DIR.is_dir()


def test_cwd_override(bash_mod, tmp_path):
    other = tmp_path / "other"
    other.mkdir()
    result = bash_mod.run_bash("pwd", cwd=str(other))
    assert result["stdout"].strip() == str(other)
