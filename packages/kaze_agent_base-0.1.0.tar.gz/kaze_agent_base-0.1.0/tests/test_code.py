"""Tests for execute_python — especially the subprocess error-surfacing guard."""

from kaze.agent_base.tools.code import execute_python


def test_clean_script_has_no_warnings():
    result = execute_python("print('hello')")
    assert result["output"].strip() == "hello"
    assert "subprocess_warnings" not in result
    assert "error" not in result


def test_nonzero_subprocess_surfaces_even_when_script_exits_clean():
    """The anti-pattern: user script catches and swallows a failing subprocess.

    Without the tracker this would return {"output": "0 results"} and the LLM
    would treat it as a real zero. The tracker forces the failure to surface.
    """
    code = """
import subprocess
r = subprocess.run(["false"], capture_output=True, text=True)
# Pretend to be a run_safe() helper — swallow the non-zero exit.
print("0 results" if r.returncode != 0 else r.stdout)
"""
    result = execute_python(code)
    assert result["output"].strip() == "0 results"
    assert "subprocess_warnings" in result
    assert "exit=1" in result["subprocess_warnings"]


def test_unknown_flag_surfaces_as_warning():
    """Regression for the phanhoc audit bug: gh-like CLI rejecting a flag."""
    code = """
import subprocess
# Use python itself as a stand-in for a CLI that rejects an unknown flag.
r = subprocess.run(
    ["python3", "--nonexistent-flag"],
    capture_output=True, text=True,
)
print("activity: 0")  # swallowed — pretends there was no activity
"""
    result = execute_python(code)
    assert result["output"].strip() == "activity: 0"
    assert "subprocess_warnings" in result
    assert "exit=" in result["subprocess_warnings"]


def test_multiple_failures_all_reported():
    code = """
import subprocess
for _ in range(3):
    subprocess.run(["false"], capture_output=True, text=True)
print("done")
"""
    result = execute_python(code)
    assert result["output"].strip() == "done"
    warnings = result["subprocess_warnings"]
    assert warnings.count("exit=1") == 3


def test_successful_subprocess_no_warning():
    code = """
import subprocess
r = subprocess.run(["true"], capture_output=True, text=True)
print("exit:", r.returncode)
"""
    result = execute_python(code)
    assert result["output"].strip() == "exit: 0"
    assert "subprocess_warnings" not in result


def test_script_error_still_surfaced_as_error():
    """Script itself raises — should still hit the old error path, not the warning path."""
    result = execute_python("raise ValueError('boom')")
    assert "error" in result
    assert "ValueError" in result["error"] or "boom" in result["error"]
    assert result["exit_code"] != 0
