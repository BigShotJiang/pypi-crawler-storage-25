"""System tests — requires running Kaze services (Gateway, LiteLLM).

Memory round-trip tests live in tests/test_memory.py (unit + system markers)
and tests/e2e/test_memory_benchmark.py (full benchmark). This file covers
cross-service health + LLM and Langfuse tracing.

Run with: KAZE_TEST_ENV=local pytest tests/test_system.py -v

Environment configs:
  local:  localhost services (default)
  k8s:    cluster services via kaze.tentou.tech
"""

import os
import json
import time
import pytest
import httpx

# ── Environment config ────────────────────────────────────────────────

ENV = os.environ.get("KAZE_TEST_ENV", "local")

CONFIGS = {
    "local": {
        "gateway_url": "http://localhost:4200",
        "control_plane_url": "http://localhost:4100",
        "app_registry_url": "http://localhost:4500",
        "langfuse_url": "https://us.cloud.langfuse.com",
        "langfuse_public_key": os.environ.get("LANGFUSE_PUBLIC_KEY", ""),
        "langfuse_secret_key": os.environ.get("LANGFUSE_SECRET_KEY", ""),
    },
    "k8s": {
        "gateway_url": "https://kaze.tentou.tech/api/gateway",
        "control_plane_url": "https://kaze.tentou.tech/api/environments",
        "app_registry_url": "https://kaze.tentou.tech/api/agents",
        "langfuse_url": "https://us.cloud.langfuse.com",
        "langfuse_public_key": os.environ.get("LANGFUSE_PUBLIC_KEY", ""),
        "langfuse_secret_key": os.environ.get("LANGFUSE_SECRET_KEY", ""),
    },
}

cfg = CONFIGS[ENV]
TEST_NAMESPACE = "system-test"
TEST_USER_ID = "pytest-runner"


# ── Fixtures ──────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def client():
    return httpx.Client(timeout=60)


@pytest.fixture(scope="session")
def langfuse_client():
    if not cfg["langfuse_public_key"]:
        pytest.skip("LANGFUSE_PUBLIC_KEY not set")
    return httpx.Client(
        timeout=15,
        auth=(cfg["langfuse_public_key"], cfg["langfuse_secret_key"]),
    )


# ── Health checks ─────────────────────────────────────────────────────

@pytest.mark.system
class TestHealthChecks:
    def test_gateway_healthy(self, client):
        r = client.get(f"{cfg['gateway_url']}/health")
        assert r.status_code == 200

    @pytest.mark.skipif(ENV == "k8s", reason="Control plane is internal on k8s")
    def test_control_plane_healthy(self, client):
        r = client.get(f"{cfg['control_plane_url']}/health")
        assert r.status_code == 200


# ── LLM round-trip ───────────────────────────────────────────────────

@pytest.mark.system
class TestLLMRoundTrip:
    def test_chat_completion(self, client):
        r = client.post(f"{cfg['gateway_url']}/v1/chat/completions", json={
            "model": "fast",
            "messages": [{"role": "user", "content": "Say 'test ok' in exactly two words"}],
            "max_tokens": 10,
        }, headers={"Authorization": "Bearer sk-local-dev"})
        assert r.status_code == 200
        data = r.json()
        assert "choices" in data
        assert len(data["choices"]) > 0

    def test_chat_completion_has_usage(self, client):
        r = client.post(f"{cfg['gateway_url']}/v1/chat/completions", json={
            "model": "fast",
            "messages": [{"role": "user", "content": "Hi"}],
            "max_tokens": 5,
        }, headers={"Authorization": "Bearer sk-local-dev"})
        data = r.json()
        usage = data.get("usage", {})
        assert usage.get("prompt_tokens", 0) > 0 or usage.get("total_tokens", 0) > 0


# ── Langfuse trace verification ──────────────────────────────────────

@pytest.mark.system
class TestLangfuseTraces:
    def test_llm_call_creates_trace(self, client, langfuse_client):
        # Make an LLM call with metadata
        client.post(f"{cfg['gateway_url']}/v1/chat/completions", json={
            "model": "fast",
            "messages": [{"role": "user", "content": "Langfuse trace test"}],
            "max_tokens": 5,
        }, headers={
            "Authorization": "Bearer sk-local-dev",
            "X-Kaze-Environment": "test-env",
            "X-Kaze-Agent": "pytest",
            "X-Kaze-Namespace": "system-test",
        })

        # Wait for Langfuse flush
        time.sleep(15)

        # Check trace exists — retry up to 3 times (Langfuse flush is async)
        pytest_traces = []
        for attempt in range(3):
            r = langfuse_client.get(f"{cfg['langfuse_url']}/api/public/traces", params={"limit": 10})
            assert r.status_code == 200
            traces = r.json().get("data", [])
            pytest_traces = [t for t in traces
                             if t.get("sessionId") == "test-env"
                             or "pytest" in (t.get("tags") or [])
                             or "system-test" in (t.get("tags") or [])]
            if pytest_traces:
                break
            time.sleep(10)

        assert len(pytest_traces) > 0, "No trace found with session 'test-env' or tag 'pytest'"

        trace = pytest_traces[0]
        assert "kaze" in trace.get("tags", []), f"Missing 'kaze' tag. Tags: {trace.get('tags')}"


# ── Token budget tracking ────────────────────────────────────────────

@pytest.mark.system
class TestTokenBudget:
    """Verify token usage stays within expected bounds."""

    BUDGET = {
        "simple_query": {"max_input": 200, "max_output": 300},  # BytePlus models include reasoning tokens
    }

    def test_simple_query_within_budget(self, client):
        r = client.post(f"{cfg['gateway_url']}/v1/chat/completions", json={
            "model": "fast",
            "messages": [{"role": "user", "content": "Say hello"}],
            "max_tokens": 10,
        }, headers={"Authorization": "Bearer sk-local-dev"})
        data = r.json()
        usage = data.get("usage", {})
        input_tokens = usage.get("prompt_tokens", 0)
        output_tokens = usage.get("completion_tokens", 0)

        budget = self.BUDGET["simple_query"]
        assert input_tokens <= budget["max_input"], \
            f"Input tokens {input_tokens} exceeds budget {budget['max_input']}"
        assert output_tokens <= budget["max_output"], \
            f"Output tokens {output_tokens} exceeds budget {budget['max_output']}"
