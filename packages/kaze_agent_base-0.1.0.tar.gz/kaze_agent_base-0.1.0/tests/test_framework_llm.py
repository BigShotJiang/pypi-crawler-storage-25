"""Unit tests for ``framework/llm.py`` — the single-point wrapper for
direct ``litellm.acompletion`` calls.

Validates:
  - parent Langfuse ``trace_id`` is auto-injected into every call's metadata
  - standard metadata (agent, namespace, environment_id) is always present
  - default tags (kaze, ops) are always present
  - caller-supplied metadata/tags are merged on top
  - caller cannot overwrite ``trace_id`` (would break trace linkage)
  - tier resolution is delegated to ``resolve_model_kwargs``
"""

from __future__ import annotations

import pytest

from kaze.agent_base import llm as fwk_llm


@pytest.fixture(autouse=True)
def _stub_resolver(monkeypatch):
    """Default to a fake gateway so tests don't need a real one."""
    monkeypatch.setattr(
        "kaze.agent_base.llm.resolve_model_kwargs",
        lambda tier: (f"fake:{tier}", {"api_base": "fake://", "api_key": "k"}),
    )


@pytest.fixture
def captured(monkeypatch):
    """Capture every kwarg passed to the underlying litellm.acompletion."""
    box = {}
    async def fake(**kw):
        box.update(kw)
        return {"choices": [{"message": {"content": "ok"}}]}
    monkeypatch.setattr("litellm.acompletion", fake)
    return box


# Note: ContextVar set/reset tokens are context-scoped — we can't reset
# from a fixture teardown because pytest-asyncio runs each test in its
# own context. Tests that need a trace_id call ``set_trace_id`` inline
# inside the async test function and either reset explicitly or rely on
# the ContextVar's per-context isolation to reset automatically.


@pytest.mark.asyncio
async def test_resolves_tier_to_model_string(captured):
    await fwk_llm.acompletion(
        tier="fast", messages=[{"role": "user", "content": "hi"}],
    )
    assert captured["model"] == "fake:fast"
    assert captured["api_base"] == "fake://"
    assert captured["api_key"] == "k"


@pytest.mark.asyncio
async def test_default_metadata_always_present(captured, monkeypatch):
    monkeypatch.setenv("KAZE_MEMORY_NAMESPACE", "ops")
    monkeypatch.setenv("KAZE_ENVIRONMENT_ID", "test-env")
    await fwk_llm.acompletion(
        tier="fast", messages=[{"role": "user", "content": "hi"}],
    )
    md = captured["metadata"]
    assert md["agent"] == "ops-agent"
    assert md["namespace"] == "ops"
    assert md["environment_id"] == "test-env"


def test_set_trace_id_mutates_shared_header_dict():
    """Side effect of set_trace_id: the shared ``_trace_headers`` dict
    used as ``extra_headers`` by the ADK Agent's LiteLlm gets the new
    trace_id, so Agent LLM calls carry the header on the wire."""
    from kaze.agent_base import models
    token = fwk_llm.set_trace_id("adk-path-trace-abc")
    try:
        assert models._trace_headers["X-Kaze-Trace-Id"] == "adk-path-trace-abc"
    finally:
        fwk_llm.reset_trace_id(token)
    # After reset, the ContextVar is back to default ("") — the shared
    # dict stays consistent with that so we don't leak the id.
    assert models._trace_headers["X-Kaze-Trace-Id"] == ""


def test_reset_trace_id_restores_previous_value():
    """Nested scopes restore the outer trace_id, not just clear to ''."""
    from kaze.agent_base import models
    outer = fwk_llm.set_trace_id("outer-trace")
    try:
        inner = fwk_llm.set_trace_id("inner-trace")
        try:
            assert models._trace_headers["X-Kaze-Trace-Id"] == "inner-trace"
        finally:
            fwk_llm.reset_trace_id(inner)
        # Inner scope exited — back to outer.
        assert models._trace_headers["X-Kaze-Trace-Id"] == "outer-trace"
    finally:
        fwk_llm.reset_trace_id(outer)
    assert models._trace_headers["X-Kaze-Trace-Id"] == ""


@pytest.mark.asyncio
async def test_gateway_header_gets_trace_id(captured, monkeypatch):
    """When the resolver returns extra_headers (gateway mode), the
    wrapper stamps X-Kaze-Trace-Id on them so server-side tracing
    links to the same parent trace."""
    monkeypatch.setattr(
        "kaze.agent_base.llm.resolve_model_kwargs",
        lambda tier: (f"openai/{tier}", {
            "api_base": "https://gateway/v1",
            "api_key": "k",
            "extra_headers": {"X-Kaze-Trace-Id": "", "X-Kaze-Agent": "ops-agent"},
        }),
    )
    token = fwk_llm.set_trace_id("parent-trace-abc")
    try:
        await fwk_llm.acompletion(
            tier="fast", messages=[{"role": "user", "content": "hi"}],
        )
    finally:
        fwk_llm.reset_trace_id(token)
    assert captured["extra_headers"]["X-Kaze-Trace-Id"] == "parent-trace-abc"
    # Other headers survive.
    assert captured["extra_headers"]["X-Kaze-Agent"] == "ops-agent"


@pytest.mark.asyncio
async def test_parent_trace_id_injected_when_set(captured):
    token = fwk_llm.set_trace_id("parent-trace-abc123")
    try:
        await fwk_llm.acompletion(
            tier="fast", messages=[{"role": "user", "content": "hi"}],
        )
    finally:
        fwk_llm.reset_trace_id(token)
    assert captured["metadata"]["trace_id"] == "parent-trace-abc123"


@pytest.mark.asyncio
async def test_no_trace_id_when_unset(captured):
    # Default ContextVar value is "" — no injection.
    await fwk_llm.acompletion(
        tier="fast", messages=[{"role": "user", "content": "hi"}],
    )
    assert "trace_id" not in captured["metadata"]


@pytest.mark.asyncio
async def test_caller_metadata_merged_on_top(captured):
    await fwk_llm.acompletion(
        tier="fast",
        messages=[{"role": "user", "content": "hi"}],
        metadata={"router_stage": "compose", "agent": "overridden"},
    )
    md = captured["metadata"]
    # Caller can override non-trace fields like agent.
    assert md["agent"] == "overridden"
    assert md["router_stage"] == "compose"
    # Standard fields still present.
    assert md["namespace"] == "ops"


@pytest.mark.asyncio
async def test_caller_cannot_overwrite_trace_id(captured):
    token = fwk_llm.set_trace_id("real-trace-xyz")
    try:
        await fwk_llm.acompletion(
            tier="fast",
            messages=[{"role": "user", "content": "hi"}],
            metadata={"trace_id": "spoofed-trace"},  # caller tries to override
        )
    finally:
        fwk_llm.reset_trace_id(token)
    # The framework's trace_id wins. Callers cannot break trace linkage.
    assert captured["metadata"]["trace_id"] == "real-trace-xyz"


@pytest.mark.asyncio
async def test_default_tags_always_present(captured):
    await fwk_llm.acompletion(
        tier="fast", messages=[{"role": "user", "content": "hi"}],
    )
    assert "kaze" in captured["tags"]
    assert "ops" in captured["tags"]


@pytest.mark.asyncio
async def test_caller_tags_appended(captured):
    await fwk_llm.acompletion(
        tier="fast",
        messages=[{"role": "user", "content": "hi"}],
        tags=["github", "router"],
    )
    tags = captured["tags"]
    assert "kaze" in tags
    assert "ops" in tags
    assert "github" in tags
    assert "router" in tags


@pytest.mark.asyncio
async def test_caller_tag_dedupe(captured):
    """Caller passing 'kaze' shouldn't duplicate the default."""
    await fwk_llm.acompletion(
        tier="fast",
        messages=[{"role": "user", "content": "hi"}],
        tags=["kaze", "extra"],
    )
    tags = captured["tags"]
    assert tags.count("kaze") == 1
    assert "extra" in tags


@pytest.mark.asyncio
async def test_extra_kwargs_forwarded(captured):
    await fwk_llm.acompletion(
        tier="fast",
        messages=[{"role": "user", "content": "hi"}],
        temperature=0.7,
        max_tokens=100,
    )
    assert captured["temperature"] == 0.7
    assert captured["max_tokens"] == 100


@pytest.mark.asyncio
async def test_default_timeout(captured):
    await fwk_llm.acompletion(
        tier="fast", messages=[{"role": "user", "content": "hi"}],
    )
    assert captured["timeout"] == fwk_llm.DEFAULT_TIMEOUT_S


@pytest.mark.asyncio
async def test_caller_timeout_override(captured):
    await fwk_llm.acompletion(
        tier="fast",
        messages=[{"role": "user", "content": "hi"}],
        timeout=5.0,
    )
    assert captured["timeout"] == 5.0
