"""Shared memory-test helpers (not a test module — prefix `_` keeps pytest
from picking it up). Used by both `test_memory.py` and
`tests/e2e/test_memory_benchmark.py`."""

from __future__ import annotations

import logging
import os

from kaze.agent_base.state.memory import DEFAULT_DB_URL, _parse_db_url

logger = logging.getLogger(__name__)


def drop_mem0_collection(name: str) -> None:
    """Drop a pgvector collection table. Logs (not swallows) failures so
    leaks during CI are visible."""
    try:
        import psycopg2
    except ImportError:
        logger.warning("psycopg2 unavailable; cannot drop collection %s", name)
        return

    try:
        db = _parse_db_url(os.environ.get("KAZE_MEM0_DB_URL", DEFAULT_DB_URL))
        conn = psycopg2.connect(**db)
        try:
            with conn.cursor() as cur:
                cur.execute(f'DROP TABLE IF EXISTS "{name}"')
                conn.commit()
        finally:
            conn.close()
    except Exception as e:
        logger.warning("drop collection %s failed: %s", name, e)
