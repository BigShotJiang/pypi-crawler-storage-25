"""Unit tests for artifact spill + read + execute_python truncation."""

import os
import tempfile

import pytest


@pytest.fixture(autouse=True)
def _tmp_data_dir(monkeypatch):
    """Point artifact storage at a throwaway tmp dir for each test."""
    with tempfile.TemporaryDirectory() as d:
        monkeypatch.setenv("KAZE_DATA_DIR", d)
        # Reload module so ARTIFACTS_DIR picks up the new env var.
        import importlib

        from kaze.agent_base.tools import artifacts as artifacts_mod

        importlib.reload(artifacts_mod)
        yield artifacts_mod


def test_spill_and_read_roundtrip(_tmp_data_dir):
    content = "hello\nworld\n" * 1000
    path = _tmp_data_dir.spill(content)

    head = _tmp_data_dir.read_artifact(path, start=0, limit=20)
    assert head["content"] == content[:20]
    assert head["start"] == 0
    assert head["end"] == 20
    assert head["next_start"] == 20
    assert head["total_chars"] == len(content)
    assert head["eof"] is False

    tail = _tmp_data_dir.read_artifact(path, start=head["total_chars"] - 5, limit=50)
    assert tail["eof"] is True
    assert tail["content"] == content[-5:]


def test_read_artifact_rejects_outside_dir(_tmp_data_dir, tmp_path):
    rogue = tmp_path / "rogue.txt"
    rogue.write_text("secret")
    result = _tmp_data_dir.read_artifact(str(rogue))
    assert "error" in result


def test_read_artifact_missing_file(_tmp_data_dir):
    result = _tmp_data_dir.read_artifact("/no/such/path.txt")
    assert "error" in result


def test_execute_python_truncates_large_output(monkeypatch, tmp_path):
    """Large stdout should spill to artifact and return a capped inline preview."""
    monkeypatch.setenv("KAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("KAZE_CODE_MAX_INLINE", "2000")

    import importlib
    from kaze.agent_base.tools import artifacts as artifacts_mod
    from kaze.agent_base.tools import code as code_mod

    importlib.reload(artifacts_mod)
    importlib.reload(code_mod)

    # Print ~10k chars — well above the 2000-char inline cap.
    result = code_mod.execute_python("print('X' * 10000)")

    assert "output" in result
    assert "artifact_path" in result, result
    assert result["total_chars"] >= 10000
    assert len(result["output"]) <= 2000 + 300  # cap + marker wiggle room
    assert "truncated" in result["output"]

    # And we can page through the spilled file.
    page = artifacts_mod.read_artifact(result["artifact_path"], start=0, limit=50)
    assert page["content"].startswith("X")
    assert page["total_chars"] >= 10000


def test_execute_python_small_output_not_spilled(monkeypatch, tmp_path):
    monkeypatch.setenv("KAZE_DATA_DIR", str(tmp_path))
    monkeypatch.setenv("KAZE_CODE_MAX_INLINE", "16000")

    import importlib
    from kaze.agent_base.tools import artifacts as artifacts_mod
    from kaze.agent_base.tools import code as code_mod

    importlib.reload(artifacts_mod)
    importlib.reload(code_mod)

    result = code_mod.execute_python("print('hi')")
    assert result["output"].strip() == "hi"
    assert "artifact_path" not in result
