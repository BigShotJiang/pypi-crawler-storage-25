from .graphways import *

__doc__ = graphways.__doc__
if hasattr(graphways, "__all__"):
    __all__ = graphways.__all__