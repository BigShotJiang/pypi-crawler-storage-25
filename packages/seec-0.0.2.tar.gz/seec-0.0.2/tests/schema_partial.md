# Extraction Schema

## 1. Metadata
| field | type | description    |
|-------|------|----------------|
| title | str  | Document title |

## 2. Classifications
| field | type | allowed_values | description |
|-------|------|----------------|-------------|

## 3. Entities
| entity_type | description   | example  |
|-------------|---------------|----------|
| tool        | Software tool | "pytest" |

## 4. Relations
| relation_type | from_entity | to_entity | description |
|---------------|-------------|-----------|-------------|
