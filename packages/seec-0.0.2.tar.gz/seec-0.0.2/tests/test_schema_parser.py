"""Tests for pipeline.py schema parser, model builder,
passes, postprocessing, and loader."""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
from seec.pipeline import (
    _format_classification_fields_for_prompt,
    _postprocess_pass3,
    build_pydantic_models,
    load_extractions,
    parse_classification_fields,
    parse_entity_types,
    parse_metadata_fields,
    parse_relation_types,
    run_pass1,
    run_pass2,
    run_pass3,
)

FILLED = Path(__file__).parent / "schema_filled.md"
PARTIAL = Path(__file__).parent / "schema_partial.md"


class TestFilledSchema:
    def test_metadata_returns_two_fields(self):
        result = parse_metadata_fields(FILLED)
        assert len(result) == 2
        assert result[0] == {
            "field": "title",
            "type": "str",
            "description": "Document title",
        }
        assert result[1] == {
            "field": "year",
            "type": "int",
            "description": "Publication year",
        }

    def test_classifications_returns_enum_field(self):
        result = parse_classification_fields(FILLED)
        assert "category" in result
        assert result["category"]["type"] == "enum"
        assert result["category"]["values"] == ["A", "B", "C"]
        # Per-value descriptions should be parsed
        assert result["category"]["value_descriptions"] == {
            "A": "Option A",
            "B": "Option B",
            "C": "Option C",
        }

    def test_entities_returns_two_types(self):
        result = parse_entity_types(FILLED)
        assert len(result) == 2
        assert result[0]["type"] == "tool"
        assert result[1]["type"] == "person"

    def test_relations_returns_one_type(self):
        result = parse_relation_types(FILLED)
        assert len(result) == 1
        assert result[0]["type"] == "used_by"
        assert result[0]["from_entity"] == "tool"
        assert result[0]["to_entity"] == "person"


class TestPartialSchema:
    def test_metadata_not_empty(self):
        result = parse_metadata_fields(PARTIAL)
        assert result is not None
        assert len(result) == 1

    def test_classifications_empty_returns_none(self):
        result = parse_classification_fields(PARTIAL)
        assert result is None

    def test_entities_not_empty(self):
        result = parse_entity_types(PARTIAL)
        assert result is not None
        assert len(result) == 1

    def test_relations_empty_returns_none(self):
        result = parse_relation_types(PARTIAL)
        assert result is None


class TestMissingSection:
    def test_absent_section_returns_none(self, tmp_path):
        schema = tmp_path / "schema.md"
        schema.write_text(
            "# Extraction Schema\n\n## 1. Metadata\n"
            "| field | type | description |\n"
            "|-------|------|-------------|\n"
            "| title | str | Title |\n"
        )
        result = parse_classification_fields(schema)
        assert result is None


class TestPydanticModelBuilder:
    def test_builds_pass1_model_with_metadata_fields(self):
        models = build_pydantic_models(FILLED)
        Pass1Result = models["Pass1Result"]
        assert "title" in Pass1Result.model_fields
        assert "year" in Pass1Result.model_fields

    def test_builds_pass2_model_with_enum_field(self):
        models = build_pydantic_models(FILLED)
        Pass2Result = models["Pass2Result"]
        assert "category" in Pass2Result.model_fields

    def test_builds_pass3_model_with_entity_and_relation_types(self):
        models = build_pydantic_models(FILLED)
        EntityType = models["EntityType"]
        assert "tool" in [e.value for e in EntityType]
        assert "person" in [e.value for e in EntityType]

    def test_empty_classifications_skips_pass2_model(self):
        models = build_pydantic_models(PARTIAL)
        assert models["Pass2Result"] is None

    def test_empty_relations_skips_relation_type_enum(self):
        models = build_pydantic_models(PARTIAL)
        assert models["RelationType"] is None


class TestPassSkipOnNone:
    """Passes return None immediately when their schema section is absent."""

    def test_pass1_returns_none_when_metadata_is_none(self):
        models = {"Pass1Result": None}
        result = run_pass1(
            client=None,
            raw_text="some text",
            model="x",
            temperature=0.2,
            seed=42,
            timeout=30,
            num_ctx=1024,
            prompts_dir=Path("/nonexistent"),
            metadata=None,
            models=models,
            verbose=False,
        )
        assert result is None

    def test_pass2_returns_none_when_classifications_is_none(self):
        models = {"Pass2Result": None}
        result = run_pass2(
            client=None,
            text="some text",
            model="x",
            temperature=0.2,
            seed=42,
            timeout=30,
            num_ctx=1024,
            prompts_dir=Path("/nonexistent"),
            classifications=None,
            models=models,
            verbose=False,
        )
        assert result is None

    def test_pass3_returns_none_when_entity_types_is_none(self):
        models = {"Pass3Result": None}
        result = run_pass3(
            client=None,
            text="some text",
            model="x",
            temperature=0.2,
            seed=42,
            timeout=30,
            num_ctx=1024,
            prompts_dir=Path("/nonexistent"),
            entity_types=None,
            relation_types=None,
            models=models,
            verbose=False,
        )
        assert result is None


class TestPostprocessing:
    """_postprocess_pass3 deduplicates entities and filters orphan relations."""

    def _make_models(self):
        return build_pydantic_models(FILLED)

    def test_deduplicates_entities_by_type_and_normalized_value(self):
        models = self._make_models()
        Entity = models["Entity"]
        Pass3Result = models["Pass3Result"]
        EntityType = models["EntityType"]

        e1 = Entity(
            id="e1",
            type=EntityType.tool,
            value="pytest",
            evidence="used pytest for testing",
        )
        e2 = Entity(
            id="e2", type=EntityType.tool, value="Pytest", evidence="x"
        )  # duplicate (case)
        e3 = Entity(
            id="e3", type=EntityType.person, value="Ada", evidence="Ada wrote the code"
        )

        raw = Pass3Result(entities=[e1, e2, e3], relations=[])
        result = _postprocess_pass3(raw, models)

        assert len(result.entities) == 2
        values = [e.value for e in result.entities]
        assert "pytest" in values
        assert "Ada" in values

    def test_reassigns_sequential_ids_after_dedup(self):
        models = self._make_models()
        Entity = models["Entity"]
        Pass3Result = models["Pass3Result"]
        EntityType = models["EntityType"]

        e1 = Entity(
            id="e1",
            type=EntityType.tool,
            value="tool_a",
            evidence="tool_a evidence here now",
        )
        e2 = Entity(id="e2", type=EntityType.tool, value="tool_a", evidence="x")  # dup
        raw = Pass3Result(entities=[e1, e2], relations=[])
        result = _postprocess_pass3(raw, models)

        assert result.entities[0].id == "e1"

    def test_filters_orphan_relations(self):
        models = self._make_models()
        if models["RelationType"] is None:
            return
        Entity = models["Entity"]
        Relation = models["Relation"]
        Pass3Result = models["Pass3Result"]
        EntityType = models["EntityType"]
        RelationType = models["RelationType"]

        e1 = Entity(
            id="e1", type=EntityType.tool, value="pytest", evidence="used pytest here"
        )
        e2 = Entity(
            id="e2", type=EntityType.person, value="Ada", evidence="Ada wrote this code"
        )
        rel_valid = Relation(
            type=RelationType.used_by, subject_entity_id="e1", object_entity_id="e2"
        )
        rel_orphan = Relation(
            type=RelationType.used_by, subject_entity_id="e99", object_entity_id="e2"
        )

        raw = Pass3Result(entities=[e1, e2], relations=[rel_valid, rel_orphan])
        result = _postprocess_pass3(raw, models)

        assert len(result.relations) == 1
        assert result.relations[0].subject_entity_id == "e1"


class TestLoader:
    def test_load_extractions_returns_three_dataframes(self, tmp_path):
        doc1 = {
            "metadata": {"title": "Doc One"},
            "classifications": {},
            "entities": [
                {
                    "id": "e1",
                    "type": "tool",
                    "value": "pytest",
                    "evidence": "used pytest",
                    "section": None,
                }
            ],
            "relations": [],
            "_pass_status": {"pass1": "ok", "pass3": "ok"},
        }
        doc2 = {
            "metadata": {"title": "Doc Two"},
            "classifications": {},
            "entities": [],
            "relations": [],
            "_pass_status": {"pass1": "ok"},
        }
        (tmp_path / "doc1.json").write_text(json.dumps(doc1))
        (tmp_path / "doc2.json").write_text(json.dumps(doc2))

        docs_df, entities_df, relations_df = load_extractions(tmp_path)

        assert len(docs_df) == 2
        assert "doc_id" in docs_df.columns
        assert "title" in docs_df.columns
        assert len(entities_df) == 1
        assert entities_df.iloc[0]["doc_id"] == "doc1"
        assert entities_df.iloc[0]["value"] == "pytest"
        assert len(relations_df) == 0

    def test_load_extractions_ignores_non_json_files(self, tmp_path):
        (tmp_path / "notes.txt").write_text("ignore me")
        (tmp_path / "doc1.json").write_text(
            json.dumps({"metadata": {}, "entities": [], "relations": []})
        )
        docs_df, entities_df, relations_df = load_extractions(tmp_path)
        assert len(docs_df) == 1

    def test_empty_output_dir_returns_dataframes_with_columns(self, tmp_path):
        docs_df, entities_df, relations_df = load_extractions(tmp_path)
        assert "doc_id" in docs_df.columns
        assert "doc_id" in entities_df.columns
        assert "doc_id" in relations_df.columns


class TestClassificationBackwardCompat:
    def test_plain_values_no_descriptions(self, tmp_path):
        schema = tmp_path / "schema.md"
        schema.write_text(
            "# Extraction Schema\n\n## 2. Classifications\n"
            "| field | type | allowed_values | description |\n"
            "|-------|------|----------------|-------------|\n"
            "| tier | enum | A; B; C | Tier level |\n"
        )
        result = parse_classification_fields(schema)
        assert result["tier"]["values"] == ["A", "B", "C"]
        assert "value_descriptions" not in result["tier"]


class TestClassificationFormatter:
    """_format_classification_fields_for_prompt renders
    field-level and per-value descriptions."""

    def test_enum_with_descriptions_renders_header_and_bullets(self):
        classifications = {
            "category": {
                "type": "enum",
                "values": ["A", "B"],
                "description": "Document type",
                "value_descriptions": {"A": "First option", "B": "Second option"},
            }
        }
        result = _format_classification_fields_for_prompt(classifications)
        assert result == (
            "- category (Document type):\n  - A: First option\n  - B: Second option"
        )

    def test_enum_without_value_descriptions_renders_plain_bullets(self):
        classifications = {
            "tier": {
                "type": "enum",
                "values": ["X", "Y"],
                "description": "Tier level",
            }
        }
        result = _format_classification_fields_for_prompt(classifications)
        assert result == "- tier (Tier level):\n  - X\n  - Y"

    def test_enum_without_field_description_omits_parens(self):
        classifications = {
            "tier": {
                "type": "enum",
                "values": ["X"],
                "description": "",
            }
        }
        result = _format_classification_fields_for_prompt(classifications)
        assert result == "- tier:\n  - X"
