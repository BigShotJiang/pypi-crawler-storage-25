# Extraction Schema

## 1. Metadata
| field  | type | description      |
|--------|------|------------------|
| title  | str  | Document title   |
| year   | int  | Publication year |

## 2. Classifications
| field    | type | allowed_values                    | description   |
|----------|------|-----------------------------------|---------------|
| category | enum | A: Option A; B: Option B; C: Option C | Doc category  |

## 3. Entities
| entity_type | description        | example    |
|-------------|--------------------|------------|
| tool        | Software tool      | "pytest"   |
| person      | Named individual   | "Ada"      |

## 4. Relations
| relation_type | from_entity | to_entity | description          |
|---------------|-------------|-----------|----------------------|
| used_by       | tool        | person    | Tool used by person  |
