# ============================================================
# seec/pipeline.py
# General-purpose extraction pipeline — all internals
# ============================================================
# Sections:
#   1. Helpers (logging, timeout)
#   2. Schema parser (reads extraction_schema.md)
#   3. Pydantic model builder (dynamic models from schema)
#   4. Prompt utilities (load + format helpers)
#   5. LLM client
#   6. Summarizer (optional — used when summarize=True)
#   7. Extraction passes (pass1, pass2, pass3)
#   8. Postprocessing (deduplication, relation filtering)
#   9. Caching (fingerprinting, load/save)
#  10. Loader (load_extractions → DataFrames)
#  11. Document orchestrator (_extract_document)
# ============================================================

from __future__ import annotations

import hashlib
import json
import re
import threading
import time
from enum import Enum, StrEnum
from pathlib import Path

import instructor
import pandas as pd
import requests
from openai import OpenAI
from pydantic import BaseModel, Field, create_model

CHARS_PER_TOKEN = 4  # conservative estimate


# ============================================================
# 1. Helpers
# ============================================================


def _log(msg: str, verbose: bool) -> None:
    """Print msg only when verbose=True."""
    if verbose:
        print(f"  {msg}")


def _call_with_timeout(func, timeout_seconds, *args, **kwargs):
    """Run func in a daemon thread with a hard wall-clock timeout.

    httpx read timeouts reset on each received byte (Ollama streams slowly),
    so this wrapper enforces a real wall-clock limit via threading.
    """
    result_box: list = [None]
    error_box: list = [None]

    def worker():
        try:
            result_box[0] = func(*args, **kwargs)
        except Exception as e:
            error_box[0] = e

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    thread.join(timeout=timeout_seconds)

    if thread.is_alive():
        raise TimeoutError(f"LLM call exceeded {timeout_seconds:.0f}s wall-clock limit")
    if error_box[0] is not None:
        raise error_box[0]
    return result_box[0]


# ============================================================
# 2. Schema Parser
# ============================================================
# New simplified format (not the thesis M1/E1/R1 ID format):
#
# ## 1. Metadata
# | field | type | description |
# |-------|------|-------------|
# | title | str  | Doc title   |
#
# A section is SKIPPED when:
#   - The heading is entirely absent from the file, OR
#   - The heading exists but has no data rows after the |---|---| separator
# In both cases, the parse function returns None.
# ============================================================


def _read_schema_section(section_num: int, schema_path: Path) -> str | None:
    """Return the raw text of section N, or None if absent/empty."""
    text = schema_path.read_text(encoding="utf-8")
    pattern = rf"## {section_num}\."
    match = re.search(pattern, text)
    if not match:
        return None  # section heading absent

    start = match.start()
    next_heading = re.search(r"\n## \d+\.", text[start + 1 :])
    end = (start + 1 + next_heading.start()) if next_heading else len(text)
    return text[start:end]


def _has_data_rows(section_text: str) -> bool:
    """Return True if there is at least one data row after the separator line.

    A separator line matches |---|...| regardless of column count.
    A data row is any table row that is NOT the header and NOT the separator.
    """
    lines = section_text.splitlines()
    past_separator = False
    for line in lines:
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        # Separator: all cells contain only dashes and colons
        cells = [c.strip(" :-") for c in stripped.strip("|").split("|")]
        if all(re.fullmatch(r"-+", c) for c in cells if c):
            past_separator = True
            continue
        if past_separator:
            # This is a data row
            return True
    return False


def parse_metadata_fields(schema_path: Path) -> list[dict] | None:
    """Parse Section 1 metadata fields. Returns None if section is empty/absent."""
    section = _read_schema_section(1, schema_path)
    if not section or not _has_data_rows(section):
        return None
    results = []
    past_separator = False
    for line in section.splitlines():
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        cells = [c.strip(" :-") for c in stripped.strip("|").split("|")]
        if all(re.fullmatch(r"-+", c) for c in cells if c):
            past_separator = True
            continue
        if not past_separator:
            continue
        parts = [c.strip() for c in stripped.strip("|").split("|")]
        if len(parts) >= 3:
            results.append(
                {"field": parts[0], "type": parts[1], "description": parts[2]}
            )
    return results if results else None


def parse_classification_fields(schema_path: Path) -> dict[str, dict] | None:
    """Parse Section 2 classification fields.

    Returns None if section is empty/absent.
    """
    section = _read_schema_section(2, schema_path)
    if not section or not _has_data_rows(section):
        return None
    result = {}
    past_separator = False
    for line in section.splitlines():
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        cells = [c.strip(" :-") for c in stripped.strip("|").split("|")]
        if all(re.fullmatch(r"-+", c) for c in cells if c):
            past_separator = True
            continue
        if not past_separator:
            continue
        parts = [c.strip() for c in stripped.strip("|").split("|")]
        if len(parts) < 4:
            continue
        field, ftype, allowed, desc = parts[0], parts[1], parts[2], parts[3]
        if ftype == "enum":
            values = []
            value_descriptions = {}
            for part in allowed.split(";"):
                part = part.strip()
                if not part:
                    continue
                if ":" in part:
                    val, val_desc = part.split(":", 1)
                    val = val.strip()
                    values.append(val)
                    value_descriptions[val] = val_desc.strip()
                else:
                    values.append(part)
            entry: dict = {"type": "enum", "values": values, "description": desc}
            if value_descriptions:
                entry["value_descriptions"] = value_descriptions
            result[field] = entry
        else:
            result[field] = {"type": "free_text", "description": desc}
    return result if result else None


def parse_entity_types(schema_path: Path) -> list[dict] | None:
    """Parse Section 3 entity types. Returns None if section is empty/absent."""
    section = _read_schema_section(3, schema_path)
    if not section or not _has_data_rows(section):
        return None
    results = []
    past_separator = False
    for line in section.splitlines():
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        cells = [c.strip(" :-") for c in stripped.strip("|").split("|")]
        if all(re.fullmatch(r"-+", c) for c in cells if c):
            past_separator = True
            continue
        if not past_separator:
            continue
        parts = [c.strip() for c in stripped.strip("|").split("|")]
        if len(parts) >= 3:
            results.append(
                {"type": parts[0], "description": parts[1], "example": parts[2]}
            )
    return results if results else None


def parse_relation_types(schema_path: Path) -> list[dict] | None:
    """Parse Section 4 relation types. Returns None if section is empty/absent."""
    section = _read_schema_section(4, schema_path)
    if not section or not _has_data_rows(section):
        return None
    results = []
    past_separator = False
    for line in section.splitlines():
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        cells = [c.strip(" :-") for c in stripped.strip("|").split("|")]
        if all(re.fullmatch(r"-+", c) for c in cells if c):
            past_separator = True
            continue
        if not past_separator:
            continue
        parts = [c.strip() for c in stripped.strip("|").split("|")]
        if len(parts) >= 4:
            results.append(
                {
                    "type": parts[0],
                    "from_entity": parts[1],
                    "to_entity": parts[2],
                    "description": parts[3],
                }
            )
    return results if results else None


# ============================================================
# 3. Pydantic Model Builder
# ============================================================
# All models are built dynamically from the schema at runtime.
# If a schema section is None (empty/absent), the corresponding
# model is also None — the calling code checks for None to skip passes.
# ============================================================


# Section enum for entity provenance
class Section(StrEnum):
    front_matter = "front_matter"
    abstract = "abstract"
    introduction = "introduction"
    methods = "methods"
    results = "results"
    discussion = "discussion"
    conclusion = "conclusion"
    other = "other"


def _sanitize_enum_name(value: str) -> str:
    """Convert a string value to a valid Python identifier for Enum member names."""
    name = re.sub(r"[^\w]+", "_", value).strip("_")
    if name[:1].isdigit():
        name = f"v_{name}"
    return name or "unknown"


def build_pydantic_models(schema_path: Path) -> dict:
    """Build all Pydantic response models dynamically from the schema.

    Returns a dict with keys:
        Pass1Result, Pass2Result, Pass3Result,
        Entity, Relation, EntityType, RelationType,
        classification_enums

    Any model whose schema section is empty returns None for that key.
    The calling code checks for None to decide which passes to skip.
    """
    metadata = parse_metadata_fields(schema_path)
    classifications = parse_classification_fields(schema_path)
    entity_types_raw = parse_entity_types(schema_path)
    relation_types_raw = parse_relation_types(schema_path)

    # --- Pass 1 model (metadata fields) ---
    Pass1Result = None
    if metadata:
        type_map = {"str": str, "int": int, "float": float}
        fields = {}
        for f in metadata:
            py_type = type_map.get(f["type"], str)
            fields[f["field"]] = (
                py_type | None,
                Field(None, description=f["description"]),
            )
        Pass1Result = create_model("Pass1Result", **fields)

    # --- Pass 2 model (classifications) ---
    Pass2Result = None
    classification_enums = {}
    if classifications:
        for name, info in classifications.items():
            if info["type"] == "enum":
                members = {_sanitize_enum_name(v): v for v in info["values"]}
                classification_enums[name] = Enum(name, members, type=str)
        cls_fields = {}
        for name, info in classifications.items():
            if info["type"] == "enum" and name in classification_enums:
                cls_fields[name] = (classification_enums[name] | None, Field(None))
            else:
                desc = info.get("description", f"{name} (free text)")
                cls_fields[name] = (str | None, Field(None, description=desc))
        Pass2Result = create_model("Pass2Result", **cls_fields)

    # --- Pass 3 model (entities + relations) ---
    EntityType = None
    RelationType = None
    Entity = None
    Relation = None
    Pass3Result = None
    if entity_types_raw:
        members = {et["type"]: et["type"] for et in entity_types_raw}
        EntityType = Enum("EntityType", members, type=str)

        if relation_types_raw:
            rel_members = {rt["type"]: rt["type"] for rt in relation_types_raw}
            RelationType = Enum("RelationType", rel_members, type=str)

        # Entity model — always built when entity types exist
        _EntityType = EntityType  # local ref for closure

        class Entity(BaseModel):
            """A single extracted entity."""

            id: str = Field(
                ..., pattern=r"^e\d+$", description="Sequential ID: e1, e2, e3..."
            )
            type: _EntityType = Field(..., description="Entity type from schema")
            value: str | None = Field(
                None, description="Verbatim or near-verbatim span from the text"
            )
            evidence: str | None = Field(
                None, description="Direct quote of 10–30 words supporting this entity"
            )
            section: Section | None = Field(
                None, description="Document section where found (optional)"
            )

        # Relation model — only built when both entity and relation types exist
        if RelationType:
            _RelationType = RelationType  # local ref for closure

            class Relation(BaseModel):
                """A directed relationship between two entities."""

                type: _RelationType = Field(
                    ..., description="Relation type from schema"
                )
                subject_entity_id: str | None = Field(
                    None, description="Entity ID of the subject (e.g. e1)"
                )
                object_entity_id: str | None = Field(
                    None,
                    description="Entity ID of the object (e.g. e2). Always required.",
                )

            class Pass3Result(BaseModel):
                entities: list[Entity] = Field(default_factory=list)
                relations: list[Relation] = Field(default_factory=list)
        else:
            # No relation types defined — extract entities only
            class Pass3Result(BaseModel):
                entities: list[Entity] = Field(default_factory=list)
                relations: list = Field(default_factory=list)

    return {
        "Pass1Result": Pass1Result,
        "Pass2Result": Pass2Result,
        "Pass3Result": Pass3Result,
        "Entity": Entity if entity_types_raw else None,
        "Relation": Relation if (entity_types_raw and relation_types_raw) else None,
        "EntityType": EntityType,
        "RelationType": RelationType,
        "classification_enums": classification_enums,
        # expose parsed schema data so callers don't need to re-parse
        "metadata": metadata,
        "classifications": classifications,
        "entity_types": entity_types_raw,
        "relation_types": relation_types_raw,
    }


# ============================================================
# 4. Prompt Utilities
# ============================================================


def _load_prompt(filename: str, prompts_dir: Path) -> str:
    """Load a prompt file from the prompts directory."""
    path = prompts_dir / filename
    if not path.exists():
        raise FileNotFoundError(f"Prompt file not found: {path}")
    return path.read_text(encoding="utf-8").strip()


def _format_metadata_fields_for_prompt(metadata: list[dict]) -> str:
    return "\n".join(
        f"- {f['field']} ({f['type']}): {f['description']}" for f in metadata
    )


def _format_classification_fields_for_prompt(classifications: dict[str, dict]) -> str:
    lines = []
    for name, info in classifications.items():
        if info["type"] == "enum":
            desc = info.get("description", "")
            header = f"- {name} ({desc}):" if desc else f"- {name}:"
            lines.append(header)
            value_descriptions = info.get("value_descriptions", {})
            for v in info["values"]:
                if v in value_descriptions:
                    lines.append(f"  - {v}: {value_descriptions[v]}")
                else:
                    lines.append(f"  - {v}")
        else:
            lines.append(f"- {name}: {info.get('description', 'free text or null')}")
    return "\n".join(lines)


def _format_entity_types_for_prompt(entity_types: list[dict]) -> str:
    return "\n".join(f"- {et['type']}: {et['description']}" for et in entity_types)


def _format_relation_types_for_prompt(relation_types: list[dict]) -> str:
    return "\n".join(
        f"- {rt['type']}: {rt['from_entity']} → {rt['to_entity']} — {rt['description']}"
        for rt in relation_types
    )


# ============================================================
# 5. LLM Client
# ============================================================


def _create_client(url: str, timeout: float) -> instructor.Instructor:
    """Create an instructor-wrapped Ollama client.

    Creates the OpenAI client directly (with timeout) then wraps with instructor,
    because instructor.from_provider does not forward the timeout kwarg.
    """
    openai_client = OpenAI(
        base_url=url,
        api_key="ollama",
        timeout=timeout,
    )
    return instructor.from_openai(openai_client, mode=instructor.Mode.JSON)


# ============================================================
# 6. Summarizer (optional — used when summarize=True)
# ============================================================


def _ollama_generate(
    prompt: str,
    model: str,
    base_url: str,
    system: str,
    num_ctx: int = 100000,
    temperature: float = 0.2,
    seed: int = 42,
    timeout: float = 600.0,
    think: bool = True,
) -> str:
    """Call the Ollama /api/generate endpoint for plain-text output (no instructor).

    The think parameter controls the model's internal reasoning
    mode (native Ollama API).
    """
    url = base_url.rstrip("/") + "/api/generate"
    payload = {
        "model": model,
        "prompt": prompt,
        "system": system,
        "stream": False,
        "think": think,
        "options": {
            "num_ctx": num_ctx,
            "temperature": temperature,
            "seed": seed,
        },
    }
    response = requests.post(url, json=payload, timeout=timeout)
    response.raise_for_status()
    return response.json()["response"]


def summarize_document(
    text: str,
    model: str,
    url: str,
    temperature: float,
    seed: int,
    timeout: float,
    prompts_dir: Path,
    think: bool = True,
    verbose: bool = False,
) -> str:
    """Summarize a document to a 400–800 word English summary.

    Uses the raw Ollama API (not instructor) — plain text output.
    url must be the Ollama base URL without /v1 (e.g. http://localhost:11434).
    """
    system_prompt = _load_prompt("system_summarize.txt", prompts_dir)
    user_template = _load_prompt("user_summarize.txt", prompts_dir)
    user_prompt = user_template.format(document_text=text)

    _log(
        "Summarize: "
        f"{len(text.split()):,} words → "
        f"~{len(text) // CHARS_PER_TOKEN:,} tokens",
        verbose,
    )

    summary = _call_with_timeout(
        _ollama_generate,
        timeout,
        prompt=user_prompt,
        model=model,
        base_url=url,
        system=system_prompt,
        temperature=temperature,
        seed=seed,
        timeout=timeout + 30,
        think=think,
    )
    _log(f"Summarize: output {len(summary.split()):,} words", verbose)
    return summary


# ============================================================
# 7. Extraction Passes
# ============================================================


def run_pass1(
    client: instructor.Instructor,
    raw_text: str,
    model: str,
    temperature: float,
    seed: int,
    timeout: float,
    num_ctx: int,
    prompts_dir: Path,
    metadata: list[dict],  # pre-parsed from schema; None = skip
    models: dict,
    think: bool = True,
    verbose: bool = False,
) -> object | None:
    """Pass 1: metadata extraction from first 1000 words of the raw document."""
    if not metadata or models["Pass1Result"] is None:
        return None  # section empty — skip

    words = raw_text.split()
    text = " ".join(words[:1000])

    system_prompt = _load_prompt("system_pass1.txt", prompts_dir)
    user_template = _load_prompt("user_pass1.txt", prompts_dir)
    user_prompt = user_template.format(document_text=text)

    _log(f"Pass 1: {len(text.split()):,} words", verbose)

    extra = {"options": {"num_ctx": num_ctx}}
    if not think:
        extra["reasoning_effort"] = "none"  # Disable thinking on /v1 endpoint
    result = _call_with_timeout(
        client.create,
        timeout,
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        response_model=models["Pass1Result"],
        max_retries=2,
        temperature=temperature,
        seed=seed,
        extra_body=extra,
    )
    _log("Pass 1: done", verbose)
    return result


def run_pass2(
    client: instructor.Instructor,
    text: str,  # summary or raw text
    model: str,
    temperature: float,
    seed: int,
    timeout: float,
    num_ctx: int,
    prompts_dir: Path,
    classifications: dict[str, dict] | None,  # pre-parsed; None = skip
    models: dict,
    think: bool = True,
    verbose: bool = False,
) -> object | None:
    """Pass 2: classification extraction from summary.

    Uses raw text if summarize=False.
    """
    if not classifications or models["Pass2Result"] is None:
        return None  # section empty — skip

    system_prompt = _load_prompt("system_pass2.txt", prompts_dir)
    user_template = _load_prompt("user_pass2.txt", prompts_dir)
    classification_fields = _format_classification_fields_for_prompt(classifications)
    user_prompt = user_template.format(
        classification_fields=classification_fields,
        summary_text=text,
    )

    _log(f"Pass 2: {len(text.split()):,} words", verbose)

    extra = {"options": {"num_ctx": num_ctx}}
    if not think:
        extra["reasoning_effort"] = "none"  # Disable thinking on /v1 endpoint
    result = _call_with_timeout(
        client.create,
        timeout,
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        response_model=models["Pass2Result"],
        max_retries=2,
        temperature=temperature,
        seed=seed,
        extra_body=extra,
    )
    _log("Pass 2: done", verbose)
    return result


def run_pass3(
    client: instructor.Instructor,
    text: str,  # summary or raw text
    model: str,
    temperature: float,
    seed: int,
    timeout: float,
    num_ctx: int,
    prompts_dir: Path,
    entity_types: list[dict] | None,  # pre-parsed; None = skip
    relation_types: list[dict] | None,  # pre-parsed; may be None
    models: dict,
    think: bool = True,
    verbose: bool = False,
) -> object | None:
    """Pass 3: entity + relation extraction from summary.

    Uses raw text if summarize=False.
    """
    if not entity_types or models["Pass3Result"] is None:
        return None  # section empty — skip

    system_prompt = _load_prompt("system_pass3.txt", prompts_dir)
    user_template = _load_prompt("user_pass3.txt", prompts_dir)

    entity_str = _format_entity_types_for_prompt(entity_types)
    relation_str = (
        _format_relation_types_for_prompt(relation_types)
        if relation_types
        else "(none)"
    )
    user_prompt = user_template.format(
        entity_types=entity_str,
        relation_types=relation_str,
        summary_text=text,
    )

    _log(f"Pass 3: {len(text.split()):,} words", verbose)

    extra = {"options": {"num_ctx": num_ctx}}
    if not think:
        extra["reasoning_effort"] = "none"  # Disable thinking on /v1 endpoint
    result = _call_with_timeout(
        client.create,
        timeout,
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        response_model=models["Pass3Result"],
        max_retries=2,
        temperature=temperature,
        seed=seed,
        extra_body=extra,
    )

    # Filter entities with no value or evidence
    result.entities = [
        e for e in result.entities if e.value and e.value.strip() and e.evidence
    ]
    _log(
        f"Pass 3: {len(result.entities)} entities, {len(result.relations)} relations",
        verbose,
    )
    return _postprocess_pass3(result, models)


# ============================================================
# 8. Postprocessing
# ============================================================


def _normalize_value(value: str | None) -> str:
    if not value:
        return ""
    return value.lower().strip()


def _postprocess_pass3(result: object, models: dict) -> object:
    """Deduplicate entities, reassign sequential IDs, remap and filter relations."""
    Pass3Result = models["Pass3Result"]
    Entity = models["Entity"]

    # Deduplicate by (type, normalized_value) — keep entity with longer evidence
    seen: dict[tuple, object] = {}
    for entity in result.entities:
        key = (
            entity.type.value if hasattr(entity.type, "value") else entity.type,
            _normalize_value(entity.value),
        )
        if key not in seen or len(entity.evidence or "") > len(
            seen[key].evidence or ""
        ):
            seen[key] = entity

    unique = list(seen.values())

    # Reassign sequential IDs
    old_to_new: dict[str, str] = {}
    new_entities = []
    for i, entity in enumerate(unique):
        new_id = f"e{i + 1}"
        old_to_new[entity.id] = new_id
        new_entities.append(
            Entity(
                id=new_id,
                type=entity.type,
                value=entity.value,
                evidence=entity.evidence,
                section=entity.section,
            )
        )

    # Remap and filter relations (remove orphans and self-references)
    valid_ids = {e.id for e in new_entities}
    new_relations = []
    for rel in result.relations:
        new_subj_id = (
            old_to_new.get(rel.subject_entity_id) if rel.subject_entity_id else None
        )
        new_obj_id = (
            old_to_new.get(rel.object_entity_id) if rel.object_entity_id else None
        )

        if (
            new_subj_id
            and new_subj_id in valid_ids
            and new_obj_id
            and new_obj_id in valid_ids
        ):
            if new_subj_id != new_obj_id:  # no self-references
                new_relations.append(
                    rel.model_copy(
                        update={
                            "subject_entity_id": new_subj_id,
                            "object_entity_id": new_obj_id,
                        }
                    )
                )

    return Pass3Result(entities=new_entities, relations=new_relations)


# ============================================================
# 9. Caching
# ============================================================
# Schema fingerprinting: each pass stores a hash of its schema section.
# On re-run, a pass is skipped if its hash matches the cached hash.
# NOTE: Prompt file edits are NOT fingerprinted. Delete the JSON file
# manually to re-run after prompt changes.
# ============================================================


def _hash(data) -> str:
    """Stable SHA-256 hash of a JSON-serializable object."""
    serialized = json.dumps(data, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(serialized.encode()).hexdigest()[:16]


def _compute_schema_fingerprints(
    metadata: list[dict] | None,
    classifications: dict | None,
    entity_types: list[dict] | None,
    relation_types: list[dict] | None,
) -> dict[str, str | None]:
    """Compute per-pass schema fingerprints for cache comparison."""
    return {
        "pass1": _hash(metadata) if metadata else None,
        "pass2": _hash(classifications) if classifications else None,
        "pass3": _hash({"entities": entity_types, "relations": relation_types})
        if entity_types
        else None,
    }


def _load_cached(doc_id: str, output_dir: Path) -> dict | None:
    """Load existing extraction JSON if present and valid."""
    path = output_dir / f"{doc_id}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _cache_valid_passes(cached: dict, fingerprints: dict) -> dict[str, bool]:
    """Return {pass_name: True} for passes whose schema fingerprint and status match.

    A pass is never considered cached if its fingerprint is None (section absent/empty).
    This prevents a skipped pass (None == None) from being mistaken for a cache hit.
    """
    cached_fp = cached.get("_schema_fingerprints", {})
    cached_status = cached.get("_pass_status", {})
    return {
        p: (
            fingerprints[p] is not None  # section must exist
            and cached_fp.get(p) == fingerprints[p]  # fingerprint must match
            and cached_status.get(p) == "ok"  # prior run must have succeeded
        )
        for p in ["pass1", "pass2", "pass3"]
    }


def _save_result(result: dict, doc_id: str, output_dir: Path) -> None:
    """Save extraction result as pretty-printed JSON."""
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"{doc_id}.json"
    path.write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )


# ============================================================
# 10. Loader — load_extractions → DataFrames
# ============================================================


def load_extractions(
    output_dir: str | Path,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Load all extraction JSONs from output_dir into three DataFrames.

    Returns:
        docs_df      — one row per document; doc_id + all
                       metadata + classification fields
        entities_df  — one row per entity; doc_id,
                       entity_type, value, evidence, section
        relations_df — one row per relation; doc_id,
                       relation_type, subject_entity_id,
                       object_entity_id
    """
    output_dir = Path(output_dir)
    doc_rows = []
    entity_rows = []
    relation_rows = []

    for json_file in sorted(output_dir.glob("*.json")):
        doc_id = json_file.stem
        try:
            data = json.loads(json_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue

        doc_row = {"doc_id": doc_id}
        doc_row.update(data.get("metadata") or {})
        doc_row.update(data.get("classifications") or {})
        doc_rows.append(doc_row)

        for entity in data.get("entities") or []:
            entity_rows.append(
                {
                    "doc_id": doc_id,
                    "entity_id": entity.get("id"),
                    "entity_type": entity.get("type"),
                    "value": entity.get("value"),
                    "evidence": entity.get("evidence"),
                    "section": entity.get("section"),
                }
            )

        for relation in data.get("relations") or []:
            relation_rows.append(
                {
                    "doc_id": doc_id,
                    "relation_type": relation.get("type"),
                    "subject_entity_id": relation.get("subject_entity_id"),
                    "object_entity_id": relation.get("object_entity_id"),
                }
            )

    docs_df = pd.DataFrame(doc_rows) if doc_rows else pd.DataFrame(columns=["doc_id"])
    entities_df = (
        pd.DataFrame(entity_rows)
        if entity_rows
        else pd.DataFrame(
            columns=[
                "doc_id",
                "entity_id",
                "entity_type",
                "value",
                "evidence",
                "section",
            ]
        )
    )
    relations_df = (
        pd.DataFrame(relation_rows)
        if relation_rows
        else pd.DataFrame(
            columns=["doc_id", "relation_type", "subject_entity_id", "object_entity_id"]
        )
    )
    return docs_df, entities_df, relations_df


# ============================================================
# 11. Document Orchestrator
# ============================================================


def _extract_document(
    doc_id: str,
    raw_text: str,
    text_for_passes: str,
    client: instructor.Instructor,
    model: str,
    temperature: float,
    seed: int,
    timeout: float,
    num_ctx: int,
    think: bool,
    prompts_dir: Path,
    output_dir: Path,
    metadata: list[dict] | None,
    classifications: dict | None,
    entity_types: list[dict] | None,
    relation_types: list[dict] | None,
    models: dict,
    verbose: bool,
) -> dict:
    """Run 3-pass extraction for a single document with per-pass caching."""
    total_start = time.time()

    fingerprints = _compute_schema_fingerprints(
        metadata, classifications, entity_types, relation_types
    )
    cached = _load_cached(doc_id, output_dir)
    valid = (
        _cache_valid_passes(cached, fingerprints)
        if cached
        else {"pass1": False, "pass2": False, "pass3": False}
    )
    result = cached if cached else {}
    result["_schema_fingerprints"] = fingerprints
    result.setdefault("_pass_status", {})

    pass_args = dict(
        client=client,
        model=model,
        temperature=temperature,
        seed=seed,
        timeout=timeout,
        num_ctx=num_ctx,
        think=think,
        prompts_dir=prompts_dir,
        models=models,
        verbose=verbose,
    )

    # ---- Pass 1: metadata ----
    if valid["pass1"]:
        _log("Pass 1: cached", verbose)
    elif models["Pass1Result"] is None:
        _log("Pass 1: skipped (no metadata fields in schema)", verbose)
    else:
        start = time.time()
        try:
            r = run_pass1(raw_text=raw_text, metadata=metadata, **pass_args)
            result["metadata"] = r.model_dump() if r else {}
            result["_pass_status"]["pass1"] = "ok"
            _save_result(result, doc_id, output_dir)
            print(f"    Pass 1 (metadata)... OK ({time.time() - start:.1f}s)")
        except Exception as e:
            result["_pass_status"]["pass1"] = "failed"
            print(f"    Pass 1 (metadata)... FAILED ({time.time() - start:.1f}s): {e}")
            _save_result(result, doc_id, output_dir)

    # ---- Pass 2: classifications ----
    if valid["pass2"]:
        _log("Pass 2: cached", verbose)
    elif models["Pass2Result"] is None:
        _log("Pass 2: skipped (no classifications in schema)", verbose)
    else:
        start = time.time()
        try:
            r = run_pass2(
                text=text_for_passes, classifications=classifications, **pass_args
            )
            if r:
                result["classifications"] = r.model_dump(mode="json")
            result["_pass_status"]["pass2"] = "ok"
            _save_result(result, doc_id, output_dir)
            print(f"    Pass 2 (classifications)... OK ({time.time() - start:.1f}s)")
        except Exception as e:
            result["_pass_status"]["pass2"] = "failed"
            print(
                f"    Pass 2 (classifications)... FAILED "
                f"({time.time() - start:.1f}s): {e}"
            )
            _save_result(result, doc_id, output_dir)

    # ---- Pass 3: entities + relations ----
    if valid["pass3"]:
        _log("Pass 3: cached", verbose)
    elif models["Pass3Result"] is None:
        _log("Pass 3: skipped (no entity types in schema)", verbose)
    else:
        start = time.time()
        try:
            r = run_pass3(
                text=text_for_passes,
                entity_types=entity_types,
                relation_types=relation_types,
                **pass_args,
            )
            if r:
                result["entities"] = [e.model_dump(mode="json") for e in r.entities]
                result["relations"] = [
                    rel.model_dump(mode="json") for rel in r.relations
                ]
            result["_pass_status"]["pass3"] = "ok"
            _save_result(result, doc_id, output_dir)
            n_e = len(result.get("entities", []))
            n_r = len(result.get("relations", []))
            print(
                f"    Pass 3 (entities)... OK — {n_e} entities, "
                f"{n_r} relations ({time.time() - start:.1f}s)"
            )
        except Exception as e:
            result["_pass_status"]["pass3"] = "failed"
            print(f"    Pass 3 (entities)... FAILED ({time.time() - start:.1f}s): {e}")
            _save_result(result, doc_id, output_dir)

    total_elapsed = time.time() - total_start
    n_e = len(result.get("entities", []))
    n_r = len(result.get("relations", []))
    print(f"  → {n_e} entities, {n_r} relations ({total_elapsed:.1f}s total)")
    return result
