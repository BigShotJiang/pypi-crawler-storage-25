# ============================================================
# seec/extract.py
# Public API — the only file coworkers need to import from
# ============================================================
# Usage:
#   from seec.extract import extract, load_extractions
#
#   init_project("./my_config")
#   extract(
#       input_dir="data/",
#       output_dir="outputs/",
#       model="qwen3.5:9b",
#       config_dir="./my_config",
#   )
#   docs_df, entities_df, relations_df = load_extractions("outputs/")
# ============================================================

from __future__ import annotations

import shutil
from pathlib import Path

from seec.pipeline import (
    _create_client,
    _extract_document,
    build_pydantic_models,
    load_extractions,  # re-exported for convenience
    summarize_document,
)

__all__ = ["extract", "load_extractions", "init_project"]

# Package directory — used to locate bundled template files
_PACKAGE_DIR = Path(__file__).parent
_SCHEMA_FILENAME = "extraction_schema.md"


def init_project(target_dir: str | Path) -> Path:
    """Copy the template schema and prompts into your project folder.

    Run this once to get starter files you can edit for your domain.
    If the target directory already exists, files that already exist
    are NOT overwritten — only missing files are added.

    Args:
        target_dir: Folder where schema and prompts/ will be created.

    Returns:
        Path to the target directory.

    Example::

        from seec import init_project, extract

        init_project("./my_config")
        # Edit my_config/extraction_schema.md and my_config/prompts/*.txt
        # Then run:
        extract(
            input_dir="data/",
            output_dir="outputs/",
            model="qwen3.5:9b",
            config_dir="./my_config",
        )
    """
    target = Path(target_dir)
    target.mkdir(parents=True, exist_ok=True)

    # Copy schema template
    schema_src = _PACKAGE_DIR / _SCHEMA_FILENAME
    schema_dst = target / _SCHEMA_FILENAME
    if not schema_dst.exists():
        shutil.copy2(schema_src, schema_dst)
        print(f"  Created {schema_dst}")
    else:
        print(f"  Skipped {schema_dst} (already exists)")

    # Copy prompt templates
    prompts_dst = target / "prompts"
    prompts_dst.mkdir(exist_ok=True)
    for prompt_file in sorted((_PACKAGE_DIR / "prompts").glob("*.txt")):
        dst = prompts_dst / prompt_file.name
        if not dst.exists():
            shutil.copy2(prompt_file, dst)
            print(f"  Created {dst}")
        else:
            print(f"  Skipped {dst} (already exists)")

    print(
        f"\nDone! Edit the files in {target}/ then pass"
        f" config_dir='{target}' to extract()."
    )
    return target


def extract(
    input_dir: str | Path,
    output_dir: str | Path,
    model: str,
    config_dir: str | Path | None = None,
    url: str = "http://localhost:11434/v1",
    schema_path: str | Path | None = None,
    prompts_dir: str | Path | None = None,
    summarize: bool = False,
    summarize_model: str = "qwen3.5:4b",
    temperature: float = 0.2,
    seed: int = 42,
    timeout: float = 300.0,
    num_ctx: int = 32768,
    think: bool = True,
    sample_size: int | None = None,
    verbose: bool = True,
) -> dict[str, dict]:
    """Run the 3-pass extraction pipeline on all text files in input_dir.

    Args:
        input_dir:       Folder containing .txt or .md files to extract from.
        output_dir:      Folder where per-document JSON results are saved.
        model:           Ollama model name for extraction (e.g. "qwen3.5:9b").
        config_dir:      Folder created by init_project() containing
                         extraction_schema.md and prompts/. This is the
                         recommended way to point to your config.
                         If not provided, falls back to the bundled package defaults.
        url:             Ollama base URL with /v1 suffix (OpenAI-compatible endpoint).
        schema_path:     Override: path to extraction_schema.md. Takes precedence over
                         config_dir if both are provided.
        prompts_dir:     Override: path to prompts/ folder. Takes precedence over
                         config_dir if both are provided.
        summarize:       If True, summarize each document before extraction passes.
                         Use for long documents (>8000 words). Default: False.
        summarize_model: Ollama model used for summarization
                         (ignored if summarize=False).
        temperature:     LLM temperature (0.0–1.0). Lower = more deterministic.
        seed:            Random seed for reproducibility.
        timeout:         Seconds before a single LLM call is considered hung.
        num_ctx:         Context window size in tokens. Default 32768 (~24k words).
        think:           Enable model thinking/reasoning mode. Thinking models (e.g.
                         Qwen3.5) produce a hidden reasoning trace before answering.
                         Disable (False) for faster inference when deep reasoning
                         isn't needed.
        sample_size:     Process only the first N files (useful for testing).
        verbose:         Print per-pass token estimates and debug info.

    Returns:
        Dict mapping doc_id → extraction result dict (same content as the JSON files).

    Notes:
        - Re-runs skip passes whose schema section is unchanged (per-pass caching).
        - Prompt edits do NOT invalidate the cache. Delete
          JSON files manually to re-run.
        - When summarize=False, raw text is passed directly
          to passes 2 and 3. Ensure your documents fit within
          num_ctx tokens (~24k words at default 32768 context).
    """
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Resolve schema and prompts paths
    # Priority: explicit schema_path/prompts_dir > config_dir > package defaults
    base = Path(config_dir) if config_dir is not None else _PACKAGE_DIR
    schema_path = Path(schema_path) if schema_path else base / _SCHEMA_FILENAME
    prompts_dir = Path(prompts_dir) if prompts_dir else base / "prompts"

    # Discover input files
    files = sorted(input_dir.glob("*.txt")) + sorted(input_dir.glob("*.md"))
    if not files:
        print(f"WARNING: no .txt or .md files found in {input_dir}")
        return {}
    if sample_size is not None:
        files = files[:sample_size]

    print(f"\n{'=' * 60}")
    print(f"seec: {len(files)} documents")
    print(f"  model: {model}  |  summarize: {summarize}")
    print(f"{'=' * 60}")

    client = _create_client(url=url, timeout=timeout)

    # Parse schema ONCE per batch — avoids redundant file reads and Enum rebuilds
    models = build_pydantic_models(schema_path)
    metadata = models["metadata"]
    classifications = models["classifications"]
    entity_types = models["entity_types"]
    relation_types = models["relation_types"]

    # Use Ollama base URL without /v1 for the raw summarizer API
    base_url_raw = url.replace("/v1", "").rstrip("/")

    results: dict[str, dict] = {}

    for i, file in enumerate(files, 1):
        doc_id = file.stem
        print(f"\n[{i}/{len(files)}] {doc_id}")

        try:
            raw_text = file.read_text(encoding="utf-8")

            # Summarize if requested
            if summarize:
                text_for_passes = summarize_document(
                    text=raw_text,
                    model=summarize_model,
                    url=base_url_raw,
                    temperature=temperature,
                    seed=seed,
                    timeout=timeout,
                    prompts_dir=prompts_dir,
                    think=think,
                    verbose=verbose,
                )
            else:
                text_for_passes = raw_text

            result = _extract_document(
                doc_id=doc_id,
                raw_text=raw_text,
                text_for_passes=text_for_passes,
                client=client,
                model=model,
                temperature=temperature,
                seed=seed,
                timeout=timeout,
                num_ctx=num_ctx,
                think=think,
                prompts_dir=prompts_dir,
                output_dir=output_dir,
                metadata=metadata,
                classifications=classifications,
                entity_types=entity_types,
                relation_types=relation_types,
                models=models,
                verbose=verbose,
            )
            results[doc_id] = result

        except Exception as e:
            print(f"  [{i}/{len(files)}] {doc_id} — FAILED: {e}")

    return results
