# Extraction Schema

> Intructions:
> - Fill in the tables below to define what the pipeline should extract.
> - Leave a section empty (keep the header row, delete all data rows) to skip that pass.
> - *Copy-paste* the example row and replace the values to add new entries.
> - Each table uses a **different column set** — see the instructions per section.

- Example rows:
**Metadata:**       | title  | str  | Full document title   |
**Classification:** | classification | enum | A: first option; B: second option; C: third option | High-level document type |
**Entities:**       | task        | A specific task or activity     | "Data Analysis" |
**Relations:**      | used_for      | tool        | task      | Tool is applied to a specific task |

## 1. Metadata
<!-- Fields to extract from the document header or opening text.
     field: snake_case field name
     type: str | int | float
     description: short description to guide the model -->
| field  | type | description           |
|--------|------|-----------------------|
| title  | str  | Full document title   |

## 2. Classifications
<!-- Document-level labels assigned to the whole document.
     field: snake_case field name
     type: enum | free_text
     allowed_values: semicolon-separated list for enum type (leave blank for free_text)
                     Optionally add per-value descriptions: "value: description; value: description"
                     Plain values without descriptions also work: "A; B; C"
     description: short description of the whole field to guide the model -->
| field    | type | allowed_values                                          | description              |
|----------|----- |---------------------------------------------------------|--------------------------|
| category | enum | A: first option; B: second option; C: third option      | High-level document type |

## 3. Entities
<!-- Named things to extract. One row per entity type.
     entity_type: snake_case name used in output JSON
     description: what counts as this entity type
     example: a short example value in quotes -->
| entity_type | description                     | example         |
|-------------|---------------------------------|-----------------|
| task        | A specific task or activity     | "Data Analysis" |
| tool        | Software tool or library named  | "Python 3.11"   |

## 4. Relations
<!-- Directed relationships between two entity types.
     relation_type: snake_case name used in output JSON
     from_entity: entity_type of the subject (must match a row in Section 3)
     to_entity: entity_type of the object (must match a row in Section 3)
     description: what this relation means -->
| relation_type | from_entity | to_entity | description                      |
|---------------|-------------|-----------|----------------------------------|
| used_for      | tool        | task      | Tool is applied to a specific task |
