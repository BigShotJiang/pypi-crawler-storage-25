from __future__ import annotations

import os
from typing import Any

import httpx

from ..core.errors import extract_error_message


DEFAULT_BASE_URL = os.environ.get("AI302_BASE_URL", "https://api.302.ai")


class AI302ApiError(RuntimeError):
    def __init__(self, message: str, *, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


def _auth_header(api_key: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {api_key}"}


def _should_retry(resp: httpx.Response | None, exc: Exception | None) -> bool:
    if resp is not None:
        if resp.status_code == 401:
            return False
        return resp.status_code >= 500 or resp.status_code in (408, 409, 429)
    return isinstance(exc, (httpx.TimeoutException, httpx.NetworkError))


def request_json(
    *,
    method: str,
    url: str,
    api_key: str,
    params: dict[str, Any] | list[tuple[str, str]] | None = None,
    json_body: dict[str, Any] | None = None,
    timeout_s: float = 60.0,
    retries: int = 2,
) -> tuple[dict[str, Any], httpx.Headers]:
    with httpx.Client(timeout=timeout_s, headers=_auth_header(api_key)) as client:
        for attempt in range(retries + 1):
            try:
                resp = client.request(method, url, params=params, json=json_body)
                if 200 <= resp.status_code < 300:
                    data = resp.json()
                    if isinstance(data, dict):
                        return data, resp.headers
                    raise AI302ApiError("unknown error", status_code=resp.status_code)

                payload: Any = None
                try:
                    payload = resp.json()
                except Exception:
                    payload = None

                msg = extract_error_message(payload)
                if attempt < retries and _should_retry(resp, None):
                    continue
                raise AI302ApiError(msg, status_code=resp.status_code)

            except Exception as e:  # noqa: BLE001
                if attempt < retries and _should_retry(None, e):
                    continue
                if isinstance(e, AI302ApiError):
                    raise
                if isinstance(e, httpx.TimeoutException):
                    raise AI302ApiError("request timeout") from e
                if isinstance(e, httpx.NetworkError):
                    raise AI302ApiError("network error") from e
                raise AI302ApiError("unknown error") from e

    raise AI302ApiError("unknown error")
