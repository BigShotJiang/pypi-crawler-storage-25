from __future__ import annotations

from typing import Any

from .http_client import DEFAULT_BASE_URL, request_json


def get_record(*, api_key: str, request_id: str) -> dict[str, Any]:
    data, _headers = request_json(
        method="GET",
        url=f"{DEFAULT_BASE_URL}/dashboard/record/{request_id}",
        api_key=api_key,
        timeout_s=60.0,
        retries=2,
    )
    return data
