from __future__ import annotations

from typing import Any

from .http_client import DEFAULT_BASE_URL, request_json


def create_video_task(
    *,
    api_key: str,
    model: str,
    prompt: str,
    image: str | list[str] | None = None,
    end_image: str | None = None,
    video: str | None = None,
    negative_prompt: str | None = None,
    duration: int | None = None,
    resolution: str | None = None,
    aspect_ratio: str | None = None,
    fps: str | None = None,
    webhook: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"model": model, "prompt": prompt}
    if image is not None:
        body["image"] = image
    if end_image is not None:
        body["end_image"] = end_image
    if video is not None:
        body["video"] = video
    if negative_prompt is not None:
        body["negative_prompt"] = negative_prompt
    if duration is not None:
        body["duration"] = duration
    if resolution is not None:
        body["resolution"] = resolution
    if aspect_ratio is not None:
        body["aspect_ratio"] = aspect_ratio
    if fps is not None:
        body["fps"] = fps
    if extra:
        body.update(extra)

    params = {"webhook": webhook} if webhook else None
    data, headers = request_json(
        method="POST",
        url=f"{DEFAULT_BASE_URL}/302/v2/video/create",
        api_key=api_key,
        params=params,
        json_body=body,
        timeout_s=60.0,
        retries=2,
    )
    request_id = headers.get("request-id")
    if request_id:
        data["request_id"] = request_id
    return data


def fetch_video_task(*, api_key: str, task_id: str) -> dict[str, Any]:
    data, _headers = request_json(
        method="GET",
        url=f"{DEFAULT_BASE_URL}/302/v2/video/fetch/{task_id}",
        api_key=api_key,
        timeout_s=60.0,
        retries=2,
    )
    return data
