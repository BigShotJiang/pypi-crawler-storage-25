from __future__ import annotations

from typing import Any

from .http_client import DEFAULT_BASE_URL, request_json


def get_tts_providers(*, api_key: str, provider: list[str] | None = None) -> dict[str, Any]:
    params: list[tuple[str, str]] | None = None
    if provider:
        params = [("provider", p) for p in provider]
    data, _headers = request_json(
        method="GET",
        url=f"{DEFAULT_BASE_URL}/302/tts/provider",
        api_key=api_key,
        params=params,
        timeout_s=60.0,
        retries=2,
    )
    return data


def create_tts_task(
    *,
    api_key: str,
    text: str,
    provider: str,
    voice: str,
    model: str | None = None,
    speed: float | None = None,
    volume: float | None = None,
    emotion: str | None = None,
    output_format: str | None = None,
    timeout: int | None = None,
    run_async: bool = True,
    webhook: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"text": text, "provider": provider, "voice": voice}
    if model is not None:
        body["model"] = model
    if speed is not None:
        body["speed"] = speed
    if volume is not None:
        body["volume"] = volume
    if emotion is not None:
        body["emotion"] = emotion
    if output_format is not None:
        body["output_format"] = output_format
    if timeout is not None:
        body["timeout"] = timeout
    if extra:
        body.update(extra)

    params: dict[str, Any] = {"run_async": run_async}
    if webhook:
        params["webhook"] = webhook

    data, headers = request_json(
        method="POST",
        url=f"{DEFAULT_BASE_URL}/302/v2/audio/tts",
        api_key=api_key,
        params=params,
        json_body=body,
        timeout_s=60.0,
        retries=2,
    )
    request_id = headers.get("request-id")
    if request_id:
        data["request_id"] = request_id
    return data


def fetch_tts_task(*, api_key: str, task_id: str) -> dict[str, Any]:
    data, _headers = request_json(
        method="GET",
        url=f"{DEFAULT_BASE_URL}/302/v2/audio/fetch/{task_id}",
        api_key=api_key,
        timeout_s=60.0,
        retries=2,
    )
    return data
