from __future__ import annotations

from typing import Any

from .http_client import DEFAULT_BASE_URL, request_json


def generate_image_sync(
    *,
    api_key: str,
    model: str,
    prompt: str,
    height: int | None = None,
    width: int | None = None,
    negative_prompt: str | None = None,
    aspect_ratio: str | None = None,
    output_format: str | None = None,
    image: str | list[str] | None = None,
    mask_image: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"model": model, "prompt": prompt}
    if height is not None:
        body["height"] = height
    if width is not None:
        body["width"] = width
    if negative_prompt is not None:
        body["negative_prompt"] = negative_prompt
    if aspect_ratio is not None:
        body["aspect_ratio"] = aspect_ratio
    if output_format is not None:
        body["output_format"] = output_format
    if image is not None:
        body["image"] = image
    if mask_image is not None:
        body["mask_image"] = mask_image
    if extra:
        body.update(extra)

    data, headers = request_json(
        method="POST",
        url=f"{DEFAULT_BASE_URL}/302/v2/image/generate",
        api_key=api_key,
        json_body=body,
        timeout_s=180.0,
        retries=1,
    )
    request_id = headers.get("request-id")
    if request_id:
        data["request_id"] = request_id
    return data


def create_image_task(
    *,
    api_key: str,
    model: str,
    prompt: str,
    height: int | None = None,
    width: int | None = None,
    negative_prompt: str | None = None,
    aspect_ratio: str | None = None,
    output_format: str | None = None,
    image: str | list[str] | None = None,
    mask_image: str | None = None,
    run_async: bool | None = None,
    webhook: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    body: dict[str, Any] = {"model": model, "prompt": prompt}
    if height is not None:
        body["height"] = height
    if width is not None:
        body["width"] = width
    if negative_prompt is not None:
        body["negative_prompt"] = negative_prompt
    if aspect_ratio is not None:
        body["aspect_ratio"] = aspect_ratio
    if output_format is not None:
        body["output_format"] = output_format
    if image is not None:
        body["image"] = image
    if mask_image is not None:
        body["mask_image"] = mask_image
    if extra:
        body.update(extra)

    params: dict[str, Any] = {}
    if run_async is not None:
        params["run_async"] = run_async
    if webhook:
        params["webhook"] = webhook

    data, headers = request_json(
        method="POST",
        url=f"{DEFAULT_BASE_URL}/302/v2/image/generate",
        api_key=api_key,
        params=params or None,
        json_body=body,
        timeout_s=180.0,
        retries=1,
    )
    request_id = headers.get("request-id")
    if request_id:
        data["request_id"] = request_id
    return data


def fetch_image_task(*, api_key: str, task_id: str) -> dict[str, Any]:
    data, _headers = request_json(
        method="GET",
        url=f"{DEFAULT_BASE_URL}/302/v2/image/fetch/{task_id}",
        api_key=api_key,
        timeout_s=60.0,
        retries=2,
    )
    return data
