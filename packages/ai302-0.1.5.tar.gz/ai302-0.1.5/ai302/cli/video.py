from __future__ import annotations

from typing import Any

import typer

from ..api.http_client import AI302ApiError
from ..api.video import create_video_task, fetch_video_task
from ..api.record import get_record
from ..core.config import load_config
from ..core.history import append_history, build_event_base
from ..core.models import SUPPORTED_MODELS
from ..core.redact import redact_fields
from ..core.task_store import upsert_task_snapshot
from .common import parse_extra, print_json, resolve_api_key


video_app = typer.Typer(no_args_is_help=True, context_settings={"help_option_names": ["-h", "--help"]})


@video_app.command("create")
def video_create(
    prompt: str = typer.Option(..., "--prompt"),
    model: str | None = typer.Option(None, "--model"),
    image: list[str] | None = typer.Option(None, "--image", help="repeatable; URL or base64 data URL"),
    end_image: str | None = typer.Option(None, "--end_image"),
    video: str | None = typer.Option(None, "--video"),
    negative_prompt: str | None = typer.Option(None, "--negative_prompt"),
    duration: int | None = typer.Option(None, "--duration"),
    resolution: str | None = typer.Option(None, "--resolution"),
    aspect_ratio: str | None = typer.Option(None, "--aspect_ratio"),
    fps: str | None = typer.Option(None, "--fps"),
    webhook: str | None = typer.Option(None, "--webhook"),
    extra: str | None = typer.Option(None, "--extra", help="JSON object string for extra vendor fields"),
    api_key: str | None = typer.Option(None, "--api_key"),
):
    key = resolve_api_key(api_key)
    cfg = load_config()

    inferred_kind = "i2v" if (image or end_image) else "t2v"
    if model is None:
        model = cfg.default_i2v_model if inferred_kind == "i2v" else cfg.default_t2v_model
    if not model:
        raise typer.BadParameter("missing model: pass --model or set default via `ai302 model set t2v|i2v <model>`")
    if model not in SUPPORTED_MODELS.get(inferred_kind, []):
        raise typer.BadParameter(
            f"unsupported model for {inferred_kind}: {model}. Use `ai302 model list {inferred_kind}` to see allowed models."
        )

    image_val: str | list[str] | None
    if image is None or len(image) == 0:
        image_val = None
    elif len(image) == 1:
        image_val = image[0]
    else:
        image_val = image

    extra_obj: dict[str, Any] | None = parse_extra(extra)

    request_body: dict[str, Any] = {
        "model": model,
        "prompt": prompt,
        "image": image_val,
        "end_image": end_image,
        "video": video,
        "negative_prompt": negative_prompt,
        "duration": duration,
        "resolution": resolution,
        "aspect_ratio": aspect_ratio,
        "fps": fps,
        **(extra_obj or {}),
    }
    request_body = {k: v for k, v in request_body.items() if v is not None}

    try:
        resp = create_video_task(
            api_key=key,
            model=model,
            prompt=prompt,
            image=image_val,
            end_image=end_image,
            video=video,
            negative_prompt=negative_prompt,
            duration=duration,
            resolution=resolution,
            aspect_ratio=aspect_ratio,
            fps=fps,
            webhook=webhook,
            extra=extra_obj,
        )
    except AI302ApiError as e:
        append_history(
            {
                **build_event_base(kind="video", op="create"),
                "status": "failed",
                "raw_status": None,
                "taskid": None,
                "model": model,
                "prompt": prompt,
                "image": image_val,
                "end_image": end_image,
                "video": video,
                "request": {"has_prompt": True},
                "result": None,
                "error": str(e),
            }
        )
        print_json({
            "status": "failed",
            "taskid": None,
            "error": str(e),
            "request": {
                "method": "POST",
                "url": "/302/v2/video/create",
                "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
                "params": {"webhook": webhook} if webhook else None,
                "body": request_body,
            },
        })
        raise typer.Exit(code=1)

    taskid = resp.get("task_id") or resp.get("taskid")
    status = resp.get("status")
    request_id = resp.get("request_id")
    cost = None
    if request_id:
        try:
            record = get_record(api_key=key, request_id=request_id)
            cost = record.get("data") if isinstance(record, dict) else None
        except AI302ApiError:
            cost = None

    out = {
        "status": status,
        "taskid": taskid,
        "request_id": request_id,
        "cost": cost,
        "created_at": resp.get("created_at"),
        "request": {
            "method": "POST",
            "url": "/302/v2/video/create",
            "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
            "params": {"webhook": webhook} if webhook else None,
            "body": request_body,
        },
        "raw": resp,
    }
    append_history(
        {
            **build_event_base(kind="video", op="create"),
            "status": status,
            "raw_status": status,
            "taskid": taskid,
            "model": model,
            "prompt": prompt,
            "image": image_val,
            "end_image": end_image,
            "video": video,
            "request": {"has_prompt": True, "has_image": bool(image_val), "has_end_image": bool(end_image), "has_video": bool(video)},
            "result": {"created_at": resp.get("created_at")},
            "error": None,
        }
    )
    if taskid:
        upsert_task_snapshot(
            taskid=taskid,
            data={
                **out,
            },
        )
    print_json(out)


@video_app.command("fetch")
def video_fetch(
    taskid: str = typer.Argument(..., help="task id"),
    short: bool = typer.Option(False, "--short", help="only return status/taskid and result_url if ready"),
    api_key: str | None = typer.Option(None, "--api_key"),
):
    key = resolve_api_key(api_key)
    try:
        resp = fetch_video_task(api_key=key, task_id=taskid)
    except AI302ApiError as e:
        append_history(
            {
                **build_event_base(kind="video", op="fetch"),
                "status": "failed",
                "raw_status": None,
                "taskid": taskid,
                "model": None,
                "request": {"taskid": taskid},
                "result": None,
                "error": str(e),
            }
        )
        print_json({"status": "failed", "taskid": taskid, "error": str(e)})
        raise typer.Exit(code=1)

    if taskid:
        upsert_task_snapshot(
            taskid=taskid,
            data={
                "request": {
                    "method": "GET",
                    "url": f"/302/v2/video/fetch/{taskid}",
                    "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
                    "params": None,
                    "body": None,
                },
            },
        )

    out = {
        "status": resp.get("status"),
        "taskid": resp.get("task_id") or taskid,
        "video_url": resp.get("video_url"),
        "model": resp.get("model"),
        "created_at": resp.get("created_at"),
        "completed_at": resp.get("completed_at"),
        "updated_at": resp.get("updated_at"),
        "raw": resp,
    }

    if short:
        result_url = out.get("video_url")
        print_json({"status": out.get("status"), "taskid": out.get("taskid"), **({"result_url": result_url} if result_url else {})})
        return

    append_history(
        {
            **build_event_base(kind="video", op="fetch"),
            "status": out["status"],
            "raw_status": out["status"],
            "taskid": out["taskid"],
            "model": out.get("model"),
            "request": {"taskid": taskid},
            "result": {"video_url": out.get("video_url"), "created_at": out.get("created_at"), "completed_at": out.get("completed_at")},
            "error": None,
        }
    )
    if out.get("taskid"):
        upsert_task_snapshot(
            taskid=out["taskid"],
            data=out,
        )
    print_json(out)
