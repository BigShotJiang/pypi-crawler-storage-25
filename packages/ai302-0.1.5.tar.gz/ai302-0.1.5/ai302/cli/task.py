from __future__ import annotations

from pathlib import Path

import typer

from ..core.yaml_edit import apply_sets, latest_yaml_path, parse_op_arg
from .common import print_json


task_app = typer.Typer(no_args_is_help=True, context_settings={"help_option_names": ["-h", "--help"]})


@task_app.command("edit")
def task_edit(
    set_: list[str] = typer.Option(
        None,
        "--set",
        help="repeatable; key=value. Path supports dotted keys plus list selectors: steps[1].a=... or steps[step=2].a=...; use key@json=<json> for JSON values",
    ),
    add: list[str] = typer.Option(
        None,
        "--add",
        help="repeatable; key=value. Append value to the list at key. (Can also use key+=value syntax)",
    ),
    remove: list[str] = typer.Option(
        None,
        "--remove",
        help="repeatable; key=value. Remove items matching value from the list at key. If value is k=v, matches object fields. (Can also use key-=value syntax)",
    ),
    path: Path = typer.Option(
        None,
        "--path",
        help="Specify the YAML file path to edit. If not provided, the latest file in the default tasks directory will be used.",
    ),
) -> None:
    if not (set_ or add or remove):
        raise typer.BadParameter("missing --set, --add, or --remove")

    try:
        ops = []
        if set_:
            ops.extend([parse_op_arg(s, default_action="set") for s in set_])
        if add:
            ops.extend([parse_op_arg(s, default_action="add") for s in add])
        if remove:
            ops.extend([parse_op_arg(s, default_action="remove") for s in remove])

        target_path = path if path else latest_yaml_path()
        if not target_path.exists():
            raise FileNotFoundError(f"YAML file not found: {target_path}")

        result = apply_sets(path=target_path, sets=ops)
    except Exception as e:  # noqa: BLE001
        print_json({"status": "failed", "error": str(e)})
        raise typer.Exit(code=1)

    print_json({"status": "completed", **result})
