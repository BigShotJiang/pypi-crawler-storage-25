from __future__ import annotations

import typer

from ..core.history import HISTORY_PATH, HistoryFilter, query_history_lines, now_iso


history_app = typer.Typer(no_args_is_help=True, context_settings={"help_option_names": ["-h", "--help"]})


@history_app.command("list")
def history_list(
    kind: str | None = typer.Option(None, "--kind", help="image or video"),
    op: str | None = typer.Option(None, "--op", help="create|fetch|generate"),
    taskid: str | None = typer.Option(None, "--taskid"),
    status: str | None = typer.Option(None, "--status"),
    model: str | None = typer.Option(None, "--model"),
    prompt: str | None = typer.Option(None, "--prompt"),
    since_ts: str | None = typer.Option(None, "--since-ts", help="inclusive; UTC ISO, e.g. 2026-04-27T12:34:56+00:00"),
    until_ts: str | None = typer.Option(None, "--until-ts", help="exclusive; UTC ISO"),
    limit: int = typer.Option(100, "--limit"),
):
    lines = query_history_lines(
        filt=HistoryFilter(
            kind=kind,
            op=op,
            taskid=taskid,
            status=status,
            model=model,
            prompt=prompt,
            since_ts=since_ts,
            until_ts=until_ts,
            limit=limit,
        )
    )
    for line in lines:
        typer.echo(line)


@history_app.command("now")
def history_now() -> None:
    typer.echo(now_iso())


@history_app.command("path")
def history_path() -> None:
    typer.echo(str(HISTORY_PATH))
