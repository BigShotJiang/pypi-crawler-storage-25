from __future__ import annotations

import random

import typer

from ..core.config import save_model
from ..core.models import SUPPORTED_MODELS
from .common import print_json


model_app = typer.Typer(no_args_is_help=True, context_settings={"help_option_names": ["-h", "--help"]})


@model_app.command("set")
def model_set(
    kind: str = typer.Argument(..., help="t2v or i2v or t2i or i2i"),
    model: str = typer.Argument(..., help="model name"),
):
    save_model(kind, model)
    print_json({"status": "completed", "kind": kind.lower(), "model": model})


@model_app.command("list")
def model_list(
    kind: str = typer.Argument(..., help="t2v or i2v or t2i or i2i"),
):
    kind = kind.lower()
    if kind not in SUPPORTED_MODELS:
        raise typer.BadParameter("kind must be t2v or i2v or t2i or i2i")
    print_json({"status": "completed", "kind": kind, "models": SUPPORTED_MODELS[kind]})


@model_app.command("get")
def model_get(
    kind: str = typer.Argument(..., help="t2v or i2v or t2i or i2i"),
    random_: bool = typer.Option(False, "--random", help="randomly pick one supported model"),
):
    kind = kind.lower()
    if kind not in SUPPORTED_MODELS:
        raise typer.BadParameter("kind must be t2v or i2v or t2i or i2i")

    models = SUPPORTED_MODELS[kind]
    model = random.choice(models) if random_ else (models[0] if models else None)
    print_json({"status": "completed", "kind": kind, "model": model})
