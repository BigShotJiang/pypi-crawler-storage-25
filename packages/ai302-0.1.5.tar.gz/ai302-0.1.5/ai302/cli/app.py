from __future__ import annotations

import typer

from .history import history_app
from .image import image_app
from .init_skills import init_skills_app
from .model import model_app
from .task import task_app
from .tts import tts_app
from .video import video_app


app = typer.Typer(no_args_is_help=True, context_settings={"help_option_names": ["-h", "--help"]})
app.add_typer(model_app, name="model")
app.add_typer(video_app, name="video")
app.add_typer(image_app, name="image")
app.add_typer(task_app, name="task")
app.add_typer(history_app, name="history")
app.add_typer(tts_app, name="tts")
app.add_typer(init_skills_app, name="skills")


@app.callback(invoke_without_command=True)
def _root(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", "-v", help="Show version and exit"),
) -> None:
    if version:
        from .. import __version__

        typer.echo(__version__)
        raise typer.Exit()

    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


def main() -> None:
    app()
