from __future__ import annotations

import json
import os
from typing import Any

import typer


_CTX = {"help_option_names": ["-h", "--help"]}


def resolve_api_key(api_key: str | None) -> str:
    key = api_key or os.environ.get("AI302_KEY")
    if key and key.strip():
        return key.strip()
    raise typer.BadParameter("missing api key: set AI302_KEY or pass --api_key")


def print_json(obj: Any) -> None:
    typer.echo(json.dumps(obj, ensure_ascii=False))


def parse_extra(extra: str | None) -> dict[str, Any] | None:
    if not extra:
        return None
    try:
        parsed = json.loads(extra)
    except Exception as e:  # noqa: BLE001
        raise typer.BadParameter("--extra must be valid JSON object") from e
    if not isinstance(parsed, dict):
        raise typer.BadParameter("--extra must be a JSON object")
    return parsed
