from __future__ import annotations

import random
from typing import Any

import typer

from ..api.http_client import AI302ApiError
from ..api.tts import create_tts_task, fetch_tts_task, get_tts_providers
from ..api.record import get_record
from ..core.history import append_history, build_event_base
from ..core.redact import redact_fields
from ..core.task_store import upsert_task_snapshot
from ..core.tts_cache import flatten_providers, flatten_voices, read_providers, write_providers
from .common import parse_extra, print_json, resolve_api_key


tts_app = typer.Typer(no_args_is_help=True, context_settings={"help_option_names": ["-h", "--help"]})


@tts_app.command("refresh")
def tts_refresh(
    provider: list[str] | None = typer.Option(None, "--provider", help="repeatable provider filter"),
    api_key: str | None = typer.Option(None, "--api_key"),
) -> None:
    key = resolve_api_key(api_key)
    try:
        data = get_tts_providers(api_key=key, provider=provider)
    except AI302ApiError as e:
        append_history({**build_event_base(kind="tts", op="refresh"), "status": "failed", "error": str(e)})
        print_json({"status": "failed", "error": str(e)})
        raise typer.Exit(code=1)

    path = write_providers(data)
    providers_count = len(data.get("provider_list")) if isinstance(data.get("provider_list"), list) else None
    append_history({**build_event_base(kind="tts", op="refresh"), "status": "completed", "saved_to": str(path), "providers_count": providers_count})
    print_json({"status": "completed", "saved_to": str(path), "providers_count": providers_count})


@tts_app.command("providers")
def tts_providers(
    provider: str | None = typer.Option(None, "--provider", help="filter by provider"),
) -> None:
    data = read_providers()
    providers = flatten_providers(data)
    if provider:
        providers = [p for p in providers if p.get("provider") == provider]
    print_json({"status": "completed", "providers": providers})


@tts_app.command("providers-get")
def tts_providers_get(
    random_: bool = typer.Option(False, "--random", help="randomly pick one provider"),
) -> None:
    data = read_providers()
    providers = flatten_providers(data)
    picked = random.choice(providers) if (random_ and providers) else (providers[0] if providers else None)
    print_json({"status": "completed", "provider": picked})


@tts_app.command("voices")
def tts_voices(
    provider: str | None = typer.Option(None, "--provider", help="filter by provider"),
) -> None:
    data = read_providers()
    voices = flatten_voices(data, provider=provider)
    print_json({"status": "completed", "provider": provider, "voices": voices})


@tts_app.command("voices-get")
def tts_voices_get(
    provider: str = typer.Argument(..., help="provider"),
    random_: bool = typer.Option(False, "--random", help="randomly pick one voice"),
) -> None:
    data = read_providers()
    voices = flatten_voices(data, provider=provider)
    picked = random.choice(voices) if (random_ and voices) else (voices[0] if voices else None)
    print_json({"status": "completed", "provider": provider, "voice": picked})


@tts_app.command("create")
def tts_create(
    text: str = typer.Option(..., "--text"),
    provider: str = typer.Option("openai", "--provider"),
    voice: str = typer.Option("alloy", "--voice"),
    model: str | None = typer.Option(None, "--model"),
    speed: float | None = typer.Option(None, "--speed"),
    volume: float | None = typer.Option(None, "--volume"),
    emotion: str | None = typer.Option(None, "--emotion"),
    output_format: str | None = typer.Option(None, "--output_format"),
    timeout: int | None = typer.Option(None, "--timeout"),
    webhook: str | None = typer.Option(None, "--webhook"),
    run_async: bool = typer.Option(True, "--run_async/--no-run_async"),
    extra: str | None = typer.Option(None, "--extra", help="JSON object string for extra vendor fields"),
    api_key: str | None = typer.Option(None, "--api_key"),
) -> None:
    key = resolve_api_key(api_key)
    extra_obj = parse_extra(extra)

    request_body: dict[str, Any] = {
        "text": text,
        "provider": provider,
        "voice": voice,
        "model": model,
        "speed": speed,
        "volume": volume,
        "emotion": emotion,
        "output_format": output_format,
        "timeout": timeout,
        **(extra_obj or {}),
    }
    request_body = {k: v for k, v in request_body.items() if v is not None}

    try:
        resp = create_tts_task(
            api_key=key,
            text=text,
            provider=provider,
            voice=voice,
            model=model,
            speed=speed,
            volume=volume,
            emotion=emotion,
            output_format=output_format,
            timeout=timeout,
            run_async=run_async,
            webhook=webhook,
            extra=extra_obj,
        )
    except AI302ApiError as e:
        append_history({**build_event_base(kind="tts", op="create"), "status": "failed", "taskid": None, "provider": provider, "model": model, "voice": voice, "error": str(e)})
        print_json({
            "status": "failed",
            "taskid": None,
            "error": str(e),
            "request": {
                "method": "POST",
                "url": "/302/v2/audio/tts",
                "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
                "params": {"run_async": run_async, **({"webhook": webhook} if webhook else {})},
                "body": request_body,
            },
        })
        raise typer.Exit(code=1)

    taskid = resp.get("task_id") or resp.get("taskid")
    raw_status = resp.get("status")
    request_id = resp.get("request_id")
    cost = None
    if request_id:
        try:
            record = get_record(api_key=key, request_id=request_id)
            cost = record.get("data") if isinstance(record, dict) else None
        except AI302ApiError:
            cost = None

    out = {
        "status": raw_status,
        "taskid": taskid,
        "request_id": request_id,
        "cost": cost,
        "created_at": resp.get("created_at"),
        "request": {
            "method": "POST",
            "url": "/302/v2/audio/tts",
            "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
            "params": {"run_async": run_async, **({"webhook": webhook} if webhook else {})},
            "body": request_body,
        },
        "raw": resp,
    }
    append_history(
        {
            **build_event_base(kind="tts", op="create"),
            "status": out.get("status"),
            "taskid": taskid,
            "prompt": text,
            "provider": provider,
            "model": model,
            "voice": voice,
            "error": None,
        }
    )
    if taskid:
        upsert_task_snapshot(
            taskid=taskid,
            data={
                **out,
            },
        )
    print_json(out)


@tts_app.command("fetch")
def tts_fetch(
    taskid: str = typer.Argument(..., help="task id"),
    short: bool = typer.Option(False, "--short", help="only return status/taskid and result_url if ready"),
    api_key: str | None = typer.Option(None, "--api_key"),
) -> None:
    key = resolve_api_key(api_key)
    try:
        resp = fetch_tts_task(api_key=key, task_id=taskid)
    except AI302ApiError as e:
        append_history({**build_event_base(kind="tts", op="fetch"), "status": "failed", "taskid": taskid, "error": str(e)})
        print_json({"status": "failed", "taskid": taskid, "error": str(e)})
        raise typer.Exit(code=1)

    if taskid:
        upsert_task_snapshot(
            taskid=taskid,
            data={
                "request": {
                    "method": "GET",
                    "url": f"/302/v2/audio/fetch/{taskid}",
                    "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
                    "params": None,
                    "body": None,
                },
            },
        )

    out = {
        "status": resp.get("status"),
        "taskid": resp.get("task_id") or taskid,
        "audio_url": resp.get("audio_url"),
        "provider": resp.get("provider"),
        "model": resp.get("model"),
        "created_at": resp.get("created_at"),
        "completed_at": resp.get("completed_at"),
        "updated_at": resp.get("updated_at"),
        "raw": resp,
    }

    if short:
        result_url = out.get("audio_url")
        print_json({"status": out.get("status"), "taskid": out.get("taskid"), **({"result_url": result_url} if result_url else {})})
        return

    append_history(
        {
            **build_event_base(kind="tts", op="fetch"),
            "status": out.get("status"),
            "taskid": out.get("taskid"),
            "provider": out.get("provider"),
            "model": out.get("model"),
            "error": None,
        }
    )
    if out.get("taskid"):
        upsert_task_snapshot(
            taskid=out["taskid"],
            data=out,
        )
    print_json(out)
