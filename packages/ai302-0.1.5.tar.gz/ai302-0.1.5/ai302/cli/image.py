from __future__ import annotations

from typing import Any

import typer

from ..api.http_client import AI302ApiError
from ..api.image import create_image_task, fetch_image_task, generate_image_sync
from ..api.record import get_record
from ..core.config import load_config
from ..core.history import append_history, build_event_base
from ..core.models import SUPPORTED_MODELS
from ..core.redact import redact_fields
from ..core.task_store import upsert_task_snapshot
from .common import parse_extra, print_json, resolve_api_key


image_app = typer.Typer(no_args_is_help=True, context_settings={"help_option_names": ["-h", "--help"]})


def _resolve_image_model(*, model: str | None, image: list[str] | None) -> tuple[str, str]:
    cfg = load_config()
    inferred_kind = "i2i" if (image and len(image) > 0) else "t2i"
    if model is None:
        model = cfg.default_i2i_model if inferred_kind == "i2i" else cfg.default_t2i_model
    if not model:
        raise typer.BadParameter("missing model: pass --model or set default via `ai302 model set t2i|i2i <model>`")
    if model not in SUPPORTED_MODELS.get(inferred_kind, []):
        raise typer.BadParameter(
            f"unsupported model for {inferred_kind}: {model}. Use `ai302 model list {inferred_kind}` to see allowed models."
        )
    return inferred_kind, model


def _normalize_images(image: list[str] | None) -> str | list[str] | None:
    if image is None or len(image) == 0:
        return None
    if len(image) == 1:
        return image[0]
    return image


@image_app.command("generate")
def image_generate(
    prompt: str = typer.Option(..., "--prompt"),
    model: str | None = typer.Option(None, "--model"),
    height: int | None = typer.Option(None, "--height"),
    width: int | None = typer.Option(None, "--width"),
    negative_prompt: str | None = typer.Option(None, "--negative_prompt"),
    aspect_ratio: str | None = typer.Option(None, "--aspect_ratio"),
    output_format: str | None = typer.Option(None, "--output_format"),
    image: list[str] | None = typer.Option(None, "--image", help="repeatable; URL or base64 data URL"),
    mask_image: str | None = typer.Option(None, "--mask_image"),
    extra: str | None = typer.Option(None, "--extra", help="JSON object string for extra vendor fields"),
    api_key: str | None = typer.Option(None, "--api_key"),
) -> None:
    key = resolve_api_key(api_key)
    _, model = _resolve_image_model(model=model, image=image)

    image_val = _normalize_images(image)

    extra_obj: dict[str, Any] | None = parse_extra(extra)

    request_body: dict[str, Any] = {
        "model": model,
        "prompt": prompt,
        "height": height,
        "width": width,
        "negative_prompt": negative_prompt,
        "aspect_ratio": aspect_ratio,
        "output_format": output_format,
        "image": image_val,
        "mask_image": mask_image,
        **(extra_obj or {}),
    }
    request_body = {k: v for k, v in request_body.items() if v is not None}

    try:
        resp = generate_image_sync(
            api_key=key,
            model=model,
            prompt=prompt,
            height=height,
            width=width,
            negative_prompt=negative_prompt,
            aspect_ratio=aspect_ratio,
            output_format=output_format,
            image=image_val,
            mask_image=mask_image,
            extra=extra_obj,
        )
    except AI302ApiError as e:
        append_history(
            {
                **build_event_base(kind="image", op="generate"),
                "status": "failed",
                "taskid": None,
                "model": model,
                "prompt": prompt,
                "image": image_val,
                "mask_image": mask_image,
                "request": {"has_prompt": True, "has_image": bool(image_val), "has_mask_image": bool(mask_image)},
                "result": None,
                "error": str(e),
            }
        )
        print_json({
            "status": "failed",
            "error": str(e),
            "request": {
                "method": "POST",
                "url": "/302/v2/image/generate",
                "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
                "params": None,
                "body": request_body,
            },
            "raw": None,
        })
        raise typer.Exit(code=1)

    status = resp.get("status")

    request_id = resp.get("request_id")
    cost = None
    if request_id:
        try:
            record = get_record(api_key=key, request_id=request_id)
            cost = record.get("data") if isinstance(record, dict) else None
        except AI302ApiError:
            cost = None

    out = {
        "status": status,
        "taskid": resp.get("task_id"),
        "request_id": request_id,
        "cost": cost,
        "created_at": resp.get("created_at"),
        "completed_at": resp.get("completed_at"),
        "image_url": resp.get("image_url"),
        "image_urls": resp.get("image_urls"),
        "request": {
            "method": "POST",
            "url": "/302/v2/image/generate",
            "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
            "params": None,
            "body": request_body,
        },
        "raw": resp,
    }
    append_history(
        {
            **build_event_base(kind="image", op="generate"),
            "status": status,
            "taskid": out.get("taskid"),
            "model": model,
            "prompt": prompt,
            "image": image_val,
            "mask_image": mask_image,
            "request": {"has_prompt": True, "has_image": bool(image_val), "has_mask_image": bool(mask_image)},
            "result": {"image_url": out.get("image_url"), "image_urls": out.get("image_urls")},
            "error": None,
        }
    )
    print_json(out)


@image_app.command("create")
def image_create(
    prompt: str = typer.Option(..., "--prompt"),
    model: str | None = typer.Option(None, "--model"),
    height: int | None = typer.Option(None, "--height"),
    width: int | None = typer.Option(None, "--width"),
    negative_prompt: str | None = typer.Option(None, "--negative_prompt"),
    aspect_ratio: str | None = typer.Option(None, "--aspect_ratio"),
    output_format: str | None = typer.Option(None, "--output_format"),
    image: list[str] | None = typer.Option(None, "--image", help="repeatable; URL or base64 data URL"),
    mask_image: str | None = typer.Option(None, "--mask_image"),
    run_async: bool | None = typer.Option(True, "--run_async/--no-run_async"),
    webhook: str | None = typer.Option(None, "--webhook"),
    extra: str | None = typer.Option(None, "--extra", help="JSON object string for extra vendor fields"),
    api_key: str | None = typer.Option(None, "--api_key"),
) -> None:
    key = resolve_api_key(api_key)
    _, model = _resolve_image_model(model=model, image=image)

    image_val = _normalize_images(image)

    extra_obj: dict[str, Any] | None = parse_extra(extra)

    request_body: dict[str, Any] = {
        "model": model,
        "prompt": prompt,
        "height": height,
        "width": width,
        "negative_prompt": negative_prompt,
        "aspect_ratio": aspect_ratio,
        "output_format": output_format,
        "image": image_val,
        "mask_image": mask_image,
        **(extra_obj or {}),
    }
    request_body = {k: v for k, v in request_body.items() if v is not None}

    try:
        resp = create_image_task(
            api_key=key,
            model=model,
            prompt=prompt,
            height=height,
            width=width,
            negative_prompt=negative_prompt,
            aspect_ratio=aspect_ratio,
            output_format=output_format,
            image=image_val,
            mask_image=mask_image,
            run_async=run_async,
            webhook=webhook,
            extra=extra_obj,
        )
    except AI302ApiError as e:
        append_history(
            {
                **build_event_base(kind="image", op="create"),
                "status": "failed",
                "taskid": None,
                "model": model,
                "prompt": prompt,
                "image": image_val,
                "mask_image": mask_image,
                "request": {"has_prompt": True, "has_image": bool(image_val), "has_mask_image": bool(mask_image)},
                "result": None,
                "error": str(e),
            }
        )
        print_json(
            {
                "status": "failed",
                "taskid": None,
                "error": str(e),
                "request": {
                    "method": "POST",
                    "url": "/302/v2/image/generate",
                    "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
                    "params": {"run_async": run_async, **({"webhook": webhook} if webhook else {})} if run_async is not None else ({"webhook": webhook} if webhook else None),
                    "body": request_body,
                },
            }
        )
        raise typer.Exit(code=1)

    taskid = resp.get("task_id") or resp.get("taskid")
    status = resp.get("status")
    request_id = resp.get("request_id")
    cost = None
    if request_id:
        try:
            record = get_record(api_key=key, request_id=request_id)
            cost = record.get("data") if isinstance(record, dict) else None
        except AI302ApiError:
            cost = None

    out = {
        "status": status,
        "taskid": taskid,
        "request_id": request_id,
        "cost": cost,
        "created_at": resp.get("created_at"),
        "request": {
            "method": "POST",
            "url": "/302/v2/image/generate",
            "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
            "params": {"run_async": run_async, **({"webhook": webhook} if webhook else {})} if run_async is not None else ({"webhook": webhook} if webhook else None),
            "body": request_body,
        },
        "raw": resp,
    }
    append_history(
        {
            **build_event_base(kind="image", op="create"),
            "status": out.get("status"),
            "taskid": out.get("taskid"),
            "model": model,
            "prompt": prompt,
            "image": image_val,
            "mask_image": mask_image,
            "request": {"has_prompt": True, "has_image": bool(image_val), "has_mask_image": bool(mask_image)},
            "result": {"created_at": out.get("created_at")},
            "error": None,
        }
    )
    if taskid:
        upsert_task_snapshot(taskid=taskid, data=out)
    print_json(out)


@image_app.command("fetch")
def image_fetch(
    taskid: str = typer.Argument(..., help="task id"),
    short: bool = typer.Option(False, "--short", help="only return status/taskid and result_url if ready"),
    api_key: str | None = typer.Option(None, "--api_key"),
) -> None:
    key = resolve_api_key(api_key)

    try:
        resp = fetch_image_task(api_key=key, task_id=taskid)
    except AI302ApiError as e:
        append_history({**build_event_base(kind="image", op="fetch"), "status": "failed", "taskid": taskid, "error": str(e)})
        print_json(
            {
                "status": "failed",
                "taskid": taskid,
                "error": str(e),
                "request": {
                    "method": "GET",
                    "url": f"/302/v2/image/fetch/{taskid}",
                    "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
                    "params": None,
                    "body": None,
                },
            }
        )
        raise typer.Exit(code=1)

    out = {
        "status": resp.get("status"),
        "taskid": resp.get("task_id") or taskid,
        "image_url": resp.get("image_url"),
        "image_urls": resp.get("image_urls"),
        "model": resp.get("model"),
        "created_at": resp.get("created_at"),
        "completed_at": resp.get("completed_at"),
        "updated_at": resp.get("updated_at"),
        "request": {
            "method": "GET",
            "url": f"/302/v2/image/fetch/{taskid}",
            "headers": redact_fields({"Authorization": f"Bearer {key}"}, keys={"Authorization"}),
            "params": None,
            "body": None,
        },
        "raw": resp,
    }

    if short:
        result_url = out.get("image_url")
        print_json({"status": out.get("status"), "taskid": out.get("taskid"), **({"result_url": result_url} if result_url else {})})
        return

    append_history(
        {
            **build_event_base(kind="image", op="fetch"),
            "status": out.get("status"),
            "taskid": out.get("taskid"),
            "model": out.get("model"),
            "error": None,
        }
    )
    if out.get("taskid"):
        upsert_task_snapshot(taskid=out["taskid"], data=out)
    print_json(out)
