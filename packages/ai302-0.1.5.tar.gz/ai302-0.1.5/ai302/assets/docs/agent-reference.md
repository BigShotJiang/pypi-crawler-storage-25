# 302AI Media Studio Agent Reference

> **Target:** Coding agents. **Purpose:** 100% success rate executing skills and commands.
> **Density:** Maximum. No prose. All syntax, rules, patterns.

---

## 1. Skills

### 1.1 `302ai-media-studio-propose`

**Trigger:** User requests media generation (image/video/audio).

**Patterns:**
- EN: "generate image", "create video", "make audio", "generate X then Y"
- CN: "生成图片", "创建视频", "生成音频", "先生成X然后Y"

**Operation Classification:**

| Input Pattern | Operation | Rule |
|---|---|---|
| Text only, no input files | `t2i` | Image generation from text |
| Text + `image` param | `i2i` | Image-to-image transformation |
| Text only, video request | `t2v` | Video generation from text |
| Text + `image` param, video request | `i2v` | Image-to-video animation |
| Text + `video` param | `v2v` | Video-to-video transformation |
| Text, audio request | `tts` | Text-to-speech |

**Required Parameters:**

| Operation | Required | Fallback |
|---|---|---|
| t2i, i2i, t2v, i2v, v2v | `prompt`, `model` | prompt: "生成一只可爱的小猫" / model: `ai302 model get <kind> --random` |
| tts | `text` | text: "你好呀，有什么需要帮忙的吗？" |

**Parameter Extraction:**
- Dimensions: "1920x1080" → `width: 1920, height: 1024`
- Aspect ratio: "16:9" → `aspect_ratio: "16:9"`
- Format: "png" → `output_format: "png"`
- File refs: "~/Desktop/cat.png" → `image: "~/Desktop/cat.png"`
- Duration: "5 seconds" → `duration: 5`

**Multi-step Detection:**
- "Generate X, then Y" → 2 steps, step 2 depends on step 1
- Step 2 uses `${steps.1.result.image_url}` or `${steps.1.result.video_url}`

**YAML Generation:**

```yaml
task_id: "YYYY-MM-DDTHH-MM-SS"
workflow:
  status: pending
  pending_steps: [1]
  running_steps: []
  completed_steps: []
  failed_steps: []
  steps:
    - step: 1
      operation: t2i
      status: pending
      parameters:
        prompt: "..."
        model: "..."
      task_id: null
      result: null
```

**Output Directory:** `302ai-media-studio/tasks/<task_id>.yaml`

**Post-Generation:** MUST immediately invoke `302ai-media-studio-apply` skill with task ID.

**User Response Format:**
- CN: `任务：<summary>\n参数：<params>\n已成功创建...\n任务 ID：<task_id>`
- EN: `Task: <summary>\nParameters: <params>\nCreated successfully...\nTask ID: <task_id>`

---

### 1.2 `302ai-media-studio-apply`

**Trigger:** After propose completes, or user says "execute task", "运行任务", or provides task ID.

**Task Resolution Priority:**
1. Explicit task ID from user → `302ai-media-studio/tasks/<task_id>.yaml`
2. Latest file by mtime in `302ai-media-studio/tasks/`
3. Task ID from conversation context

**Execution Scope:** ONE step per invocation (first `status: pending`).

**CLI Command Mapping:**

| Operation | CLI Command |
|---|---|
| t2i, i2i | `ai302 image create` |
| t2v, i2v, v2v | `ai302 video create` |
| tts | `ai302 tts create` |

**Parameter Construction:**

```yaml
# YAML
parameters:
  prompt: "a cat"
  model: "flux-kontext-max-t2i"
  width: 1024
```

```bash
# CLI
ai302 image create --prompt "a cat" --model "flux-kontext-max-t2i" --width 1024
```

**List Parameters (repeat flag):**

```yaml
image: ["url1", "url2"]
```

```bash
ai302 video create --image url1 --image url2
```

**Step Result References:**

```yaml
# Step 2 references step 1 result
parameters:
  image: "${steps.1.result.image_url}"
```

**Resolution:**
1. Find step 1 in YAML
2. Parse `step.result` JSON
3. Extract `image_url` field
4. Substitute into CLI command

**If `result` is null:** Previous step incomplete. Report to user, exit.

**CLI Response Handling:**

#### Success: `status: "pending"`

**Update YAML (SEQUENTIAL, NOT PARALLEL):**

```bash
# Command 1
ai302 task edit --path "302ai-media-studio/tasks/<task_id>.yaml" \
  --set "workflow.steps[step=N].task_id=<taskid>"

# Command 2
ai302 task edit --path "302ai-media-studio/tasks/<task_id>.yaml" \
  --set "workflow.steps[step=N].status=running"

# Command 3
ai302 task edit --path "302ai-media-studio/tasks/<task_id>.yaml" \
  --add "workflow.running_steps=N"

# Command 4
ai302 task edit --path "302ai-media-studio/tasks/<task_id>.yaml" \
  --remove "workflow.pending_steps=N"
```

**User Response:**
- CN: "任务正在执行中..." / "Step N 已提交，正在处理中..."
- EN: "Task is executing..." / "Step N submitted, now processing..."

**Exit.**

#### Failure: `status: "failed"`

**Error Classification:**

1. **Parameter error** (unrecognized flag):
   - Call `ai302 <video|image|tts> create -h`
   - Fix parameters
   - Retry (max 3 attempts)

2. **Model not supported**:
   - Mark step as failed immediately
   - NO retry
   - Update YAML:

```bash
ai302 task edit --path "302ai-media-studio/tasks/<task_id>.yaml" \
  --set "workflow.steps[step=N].status=failed"

ai302 task edit --path "302ai-media-studio/tasks/<task_id>.yaml" \
  --remove "workflow.pending_steps=N"

ai302 task edit --path "302ai-media-studio/tasks/<task_id>.yaml" \
  --add "workflow.failed_steps=N"
```

3. **Other errors** (API, network):
   - Retry up to 3 times
   - If all fail, mark as failed (same YAML updates as #2)

**User Response:**
- CN: "步骤 N 执行失败：<error>"
- EN: "Step N failed: <error>"

---

### 1.3 `302ai-media-studio-result`

**Trigger:** User asks "check status", "查询任务", "任务完成了吗", or provides task ID.

**Task Resolution Priority:**
1. Explicit task ID from user → `302ai-media-studio/tasks/<task_id>.yaml`
2. Task ID from conversation context
3. Latest incomplete task (scan `302ai-media-studio/tasks/` for `workflow.status: running`)

**Execution Flow:**

#### Step 1: Read YAML, check `workflow.status`

| Status | Action |
|---|---|
| `completed` | Show final results, exit |
| `failed` | Ask if retry, exit |
| `running` | Proceed to step 2 |

#### Step 2: Find running step

Scan `workflow.steps` for `status: running`.

**If no running step:**
- Pending steps exist → suggest run apply
- All completed → set `workflow.status: completed`
- Exit

**If running step has no `task_id`:** Apply didn't submit successfully. Suggest re-run apply. Exit.

#### Step 3: Execute CLI fetch

**Extract from running step:**
- `task_id` (CLI task ID)
- `operation` (t2i, i2i, t2v, i2v, v2v, tts)

**CLI Mapping:**

| Operation | CLI Command |
|---|---|
| t2i, i2i | `ai302 image fetch <task_id> --short` |
| t2v, i2v, v2v | `ai302 video fetch <task_id> --short` |
| tts | `ai302 tts fetch <task_id> --short` |

#### Step 4: Handle CLI Response

##### A. `status: "completed"`

**Update YAML (SEQUENTIAL):**

```bash
# Command 1
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].status=completed"

# Command 2
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].result_url=<result_url>"

# Command 3
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --remove "workflow.running_steps=N"

# Command 4
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --add "workflow.completed_steps=N"
```

**Proceed to Step 5.**

##### B. `status: "failed"`

**Update YAML (SEQUENTIAL):**

```bash
# Command 1
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].status=failed"

# Command 2
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --remove "workflow.running_steps=N"

# Command 3
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --add "workflow.failed_steps=N"
```

**User Response:**
- CN: "步骤 N 执行失败：<error>。是否需要重新生成？"
- EN: "Step N failed: <error>. Would you like to retry?"

**DO NOT auto-retry.** Wait for user confirmation.

**If user confirms retry:**

```bash
# Command 1
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].status=pending"

# Command 2
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].task_id=null"

# Command 3
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --add "workflow.pending_steps=N"

# Command 4
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --remove "workflow.failed_steps=N"
```

**Then invoke `302ai-media-studio-apply`.**

##### C. `status: "pending"` or `status: "processing"`

**User Response:**
- CN: "步骤 N 仍在处理中，请稍后再查询"
- EN: "Step N is still processing, please check again later"

**Exit.**

#### Step 5: Check for next pending step

After step completes successfully:

1. Scan `workflow.pending_steps`
2. If empty → set `workflow.status: completed`, report to user, exit
3. If non-empty → invoke `302ai-media-studio-apply` to execute next step

---

## 2. Commands

### 2.1 `302ai-media-studio:propose`

**Invocation:** User types `/302ai-media-studio:propose <prompt>` or command is triggered by system.

**Behavior:** Identical to skill `302ai-media-studio-propose`. See section 1.1.

---

### 2.2 `302ai-media-studio:apply`

**Invocation:** User types `/302ai-media-studio:apply [task-id]`.

**Behavior:** Identical to skill `302ai-media-studio-apply`. See section 1.2.

---

### 2.3 `302ai-media-studio:result`

**Invocation:** User types `/302ai-media-studio:result [task-id]`.

**Behavior:** Identical to skill `302ai-media-studio-result`. See section 1.3.

---

## 3. CLI Error Handling

**Reference:** `/Users/trashcodemaker/Desktop/302/personal/302AI-Media-Studio-Skills/docs/cli-agent-guide.md`

**Common Failures:**

| Error Pattern | Exit Code | Recovery |
|---|---|---|
| Missing API key | 2 | Set `AI302_KEY` env var or pass `--api_key` |
| Missing model | 2 | Call `ai302 model get <kind> --random` |
| Unsupported model | 2 | NO retry, mark step failed |
| Unrecognized flag | 2 | Call `ai302 <cmd> -h`, fix params, retry (max 3) |
| API error | 1 | Retry up to 3 times |
| Network error | 1 | Retry up to 3 times |

**All CLI output is single-line JSON.** Parse with `json.loads()`.

**Status values:** `pending`, `processing`, `completed`, `failed`.

---

## 4. Execution Patterns

### 4.1 Single-Step Workflow

```
User: "Generate an image of a cat"
  ↓
propose skill
  ↓ (creates YAML)
apply skill
  ↓ (submits to CLI, status: pending)
result skill (polling)
  ↓ (status: completed)
Report to user
```

### 4.2 Multi-Step Workflow

```
User: "Generate cat image, then make video"
  ↓
propose skill (creates 2-step YAML)
  ↓
apply skill (executes step 1)
  ↓ (step 1 status: pending → running)
result skill (polls step 1)
  ↓ (step 1 status: completed)
result skill auto-chains to apply
  ↓
apply skill (executes step 2, uses step 1 result)
  ↓ (step 2 status: pending → running)
result skill (polls step 2)
  ↓ (step 2 status: completed)
Report to user
```

### 4.3 Retry Logic

**Parameter errors:** Max 3 retries.
**Model not supported:** NO retry, immediate failure.
**API/network errors:** Max 3 retries.

**Between retries:** No delay required (CLI handles rate limiting).

### 4.4 Sequential vs Parallel Execution

**CRITICAL:** `ai302 task edit` commands MUST execute sequentially.

**WRONG:**
```python
# Parallel execution (causes data loss)
await asyncio.gather(
    run("ai302 task edit --set ..."),
    run("ai302 task edit --add ..."),
)
```

**CORRECT:**
```python
# Sequential execution
run("ai302 task edit --set ...")
run("ai302 task edit --add ...")
```

**Reason:** No file locking. Parallel writes corrupt YAML.

---

## 5. YAML Update Syntax

**Command:** `ai302 task edit --path <path> <operation>`

**Operations:**

| Operation | Syntax | Example |
|---|---|---|
| Set field | `--set "path=value"` | `--set "workflow.status=completed"` |
| Add to list | `--add "path=value"` | `--add "workflow.completed_steps=1"` |
| Remove from list | `--remove "path=value"` | `--remove "workflow.pending_steps=1"` |

**Array indexing:** `workflow.steps[step=N].status` (matches `step: N` in YAML).

**Value types:**
- String: `--set "field=value"`
- Number: `--set "field=123"`
- null: `--set "field=null"`

**Path is relative to project root:** `302ai-media-studio/tasks/<timestamp>.yaml`

---

## 6. Quick Reference

### 6.1 Skill Invocation

```python
# Propose
Skill("302ai-media-studio-propose")

# Apply
Skill("302ai-media-studio-apply")

# Result
Skill("302ai-media-studio-result")
```

### 6.2 CLI Commands

```bash
# Get random model
ai302 model get t2i --random

# Create image (async)
ai302 image create --prompt "a cat" --model "flux-kontext-max-t2i"

# Create video from image (async)
ai302 video create --image "https://..." --prompt "animate" --model "minimaxi-hailuo-2.3-fast"

# Fetch result
ai302 video fetch <taskid> --short

# Update YAML
ai302 task edit --path "302ai-media-studio/tasks/2026-04-27T10-00-00.yaml" \
  --set "workflow.steps[step=1].status=completed"
```

### 6.3 Error Handling

```python
result = json.loads(cli_output)

if result["status"] == "failed":
    error = result["error"]
    
    if "unrecognized" in error:
        # Parameter error, retry with fixed params
        pass
    elif "not supported" in error:
        # Model error, mark failed, NO retry
        pass
    else:
        # API/network error, retry up to 3 times
        pass
```

---

## 7. File Locations

| Resource | Path |
|---|---|
| Task YAML files | `302ai-media-studio/tasks/<YYYY-MM-DDTHH-MM-SS>.yaml` |
| CLI guide | `/Users/trashcodemaker/Desktop/302/personal/302AI-Media-Studio-Skills/docs/cli-agent-guide.md` |

---

**End of Reference.**
