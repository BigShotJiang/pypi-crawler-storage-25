# ai302 CLI Agent Guide

> Target: coding agent. Purpose: execute CLI commands with near-100% success.
> All CLI output is single-line JSON (`ensure_ascii=False`). Parse with `json.loads`.

---

## 1. Entry Points

| Entry | Command |
|---|---|
| Dev/no-install | `python -m ai302 <subcommand>` |
| Installed | `ai302 <subcommand>` |

All subcommands support `-h` and `--help`.
Root (`ai302` with no args) shows help and exits 0.

---

## 2. Environment & Auth

| Variable | Purpose | Default |
|---|---|---|
| `AI302_KEY` | API key (fallback if `--api_key` omitted) | — |
| `AI302_BASE_URL` | API base URL | `https://api.302.ai` |
| `AI302_CONFIG_DIR` | Local config/storage dir | `~/.ai302` |

**Auth resolution order:**
1. `--api_key <key>`
2. `AI302_KEY` env var

**Failure:** If neither provided, CLI prints `{"status":"failed","error":"missing api key: set AI302_KEY or pass --api_key"}` and exits with code 2 (Typer `BadParameter`).

---

## 3. Status Enum

| Status | Meaning | Applicable To |
|---|---|---|
| `pending` | Queued/preparing | video/tts/image create (async) |
| `processing` | Running | video/tts/image create (async) |
| `completed` | Success | all commands |
| `failed` | Failure | all commands |

**Sync generate** (`image generate`) only returns `completed` or `failed`.

---

## 4. Supported Models (Hardcoded in `ai302/core/models.py`)

| Kind | Models |
|---|---|
| `t2v` | `minimaxi-t2v-01`, `minimaxi-hailuo-2.3-fast` |
| `i2v` | `minimaxi-hailuo-2.3-fast` |
| `t2i` | `flux-kontext-max-t2i`, `flux-2-klein-4b`, `gpt-image-2-plus`, `wanx2.0-t2i-turbo` |
| `i2i` | `wan2.6-image` |

**Kind inference rules:**
- `video create`: if `--image` or `--end_image` provided → `i2v`, else `t2v`
- `image generate` / `image create`: if `--image` provided → `i2i`, else `t2i`

---

## 5. Command Reference

### 5.1 `model`

#### `model set <kind> <model>`
- `kind`: `t2v` | `i2v` | `t2i` | `i2i`
- `model`: any string (no validation against supported list)
- Writes to `$AI302_CONFIG_DIR/config.json` under `models.<kind>`
- Example: `ai302 model set t2v minimaxi-t2v-01`
- Output: `{"status":"completed","kind":"t2v","model":"minimaxi-t2v-01"}`

#### `model list <kind>`
- `kind`: `t2v` | `i2v` | `t2i` | `i2i`
- Validates `kind` against `SUPPORTED_MODELS` keys; invalid → exits 2
- Output: `{"status":"completed","kind":"t2v","models":["minimaxi-t2v-01",...]}`

#### `model get <kind> [--random]`
- `--random`: pick random model from list
- Without `--random`, returns first model in list
- Output: `{"status":"completed","kind":"t2v","model":"minimaxi-t2v-01"}`

---

### 5.2 `video` (async)

#### `video create --prompt <prompt> [OPTIONS]`

| Option | Type | Required | Default | Repeatable | Notes |
|---|---|---|---|---|---|
| `--prompt` | string | yes | — | no | |
| `--model` | string | no | from config | no | Inferred kind `i2v` if image/end_image provided, else `t2v`. Falls back to config `default_i2v_model`/`default_t2v_model`. If still missing → BadParameter exit 2. |
| `--image` | string | no | — | **yes** | URL or base64 data URL. Single value sent as string; multiple sent as list. |
| `--end_image` | string | no | — | no | |
| `--video` | string | no | — | no | |
| `--negative_prompt` | string | no | — | no | |
| `--duration` | int | no | — | no | |
| `--resolution` | string | no | — | no | |
| `--aspect_ratio` | string | no | — | no | |
| `--fps` | string | no | — | no | |
| `--webhook` | string | no | — | no | |
| `--extra` | string | no | — | no | Must be valid JSON **object** string. |
| `--api_key` | string | no | AI302_KEY | no | |

**Error exits:**
- Missing API key → exit 2
- Missing model (no `--model` and no default in config) → exit 2
- Unsupported model for inferred kind → exit 2
- API error → prints `{"status":"failed","taskid":null,"error":"...","request":{...}}` and exits 1

**Success output:**
```json
{
  "status": "pending",
  "taskid": "<id>",
  "request_id": "<req_id>",
  "cost": {...},
  "created_at": "...",
  "request": {"method":"POST","url":"/302/v2/video/create","headers":{...},"params":{...},"body":{...}},
  "raw": {...}
}
```

**Example:**
```bash
ai302 video create --prompt "a cat runs" --model minimaxi-t2v-01 --api_key "sk-xxx"
```

#### `video fetch <taskid> [--short] [--api_key]`

| Arg/Opt | Type | Required | Notes |
|---|---|---|---|
| `taskid` | string | yes | positional |
| `--short` | flag | no | If set, output only `status`, `taskid`, `result_url` (if ready) |
| `--api_key` | string | no | |

**Success output (full):**
```json
{
  "status": "completed",
  "taskid": "<id>",
  "video_url": "https://...",
  "model": "...",
  "created_at": "...",
  "completed_at": "...",
  "updated_at": "...",
  "raw": {...}
}
```

**Example:**
```bash
ai302 video fetch task_abc123 --short --api_key "sk-xxx"
```

---

### 5.3 `image`

#### `image generate --prompt <prompt> [OPTIONS]` (sync)

| Option | Type | Required | Default | Repeatable | Notes |
|---|---|---|---|---|---|
| `--prompt` | string | yes | — | no | |
| `--model` | string | no | from config | no | Inferred kind `i2i` if `--image` provided, else `t2i`. Falls back to `default_i2i_model`/`default_t2i_model`. Missing → exit 2. |
| `--height` | int | no | — | no | |
| `--width` | int | no | — | no | |
| `--negative_prompt` | string | no | — | no | |
| `--aspect_ratio` | string | no | — | no | |
| `--output_format` | string | no | — | no | |
| `--image` | string | no | — | **yes** | URL or base64 data URL. Single→string, multiple→list. |
| `--mask_image` | string | no | — | no | |
| `--extra` | string | no | — | no | JSON object string |
| `--api_key` | string | no | AI302_KEY | no | |

**Success output:**
```json
{
  "status": "completed",
  "taskid": "<id or null>",
  "request_id": "<req_id>",
  "cost": {...},
  "created_at": "...",
  "completed_at": "...",
  "image_url": "https://...",
  "image_urls": ["https://..."],
  "request": {"method":"POST","url":"/302/v2/image/generate","headers":{...},"params":null,"body":{...}},
  "raw": {...}
}
```

**Example:**
```bash
ai302 image generate --prompt "sky city" --model flux-kontext-max-t2i --api_key "sk-xxx"
ai302 image generate --prompt "add sunglasses" --image "https://..." --api_key "sk-xxx"
```

#### `image create --prompt <prompt> [OPTIONS]` (async)

Same options as `image generate`, plus:

| Option | Type | Required | Default | Notes |
|---|---|---|---|---|
| `--run_async` / `--no-run_async` | bool | no | `true` | `--run_async` is default true; use `--no-run_async` for sync behavior |
| `--webhook` | string | no | — | |

**Success output:** same structure as `video create`.

#### `image fetch <taskid> [--short] [--api_key]`

Same structure as `video fetch`. Result field names: `image_url`, `image_urls`.

---

### 5.4 `tts` (async + local cache)

#### `tts refresh [--provider] [--api_key]`

| Option | Type | Required | Repeatable | Notes |
|---|---|---|---|---|
| `--provider` | string | no | **yes** | Filter providers to refresh |
| `--api_key` | string | no | no | |

- Fetches from `/302/tts/provider`
- Writes cache to `$AI302_CONFIG_DIR/tts/providers.json`
- Output: `{"status":"completed","saved_to":"...","providers_count":N}`

**Agent workflow:** Before using `tts providers` / `tts voices`, run `tts refresh` once.

#### `tts providers [--provider]`

- Reads local cache. If empty list, cache may be missing; run `tts refresh`.
- Output: `{"status":"completed","providers":[{"provider":"...","models":["..."],...}]}`

#### `tts providers-get [--random]`

- Returns single provider object (first or random).
- Output: `{"status":"completed","provider":{...}}`

#### `tts voices [--provider]`

| Option | Type | Required | Notes |
|---|---|---|---|
| `--provider` | string | no | Filter voices by provider |

- Output: `{"status":"completed","provider":"...","voices":[{"provider":"...","voice":"...",...}]}`

#### `tts voices-get <provider> [--random]`

| Arg/Opt | Type | Required | Notes |
|---|---|---|---|
| `provider` | string | yes | positional |
| `--random` | flag | no | |

- Output: `{"status":"completed","provider":"...","voice":{...}}`

#### `tts create --text <text> [OPTIONS]`

| Option | Type | Required | Default | Repeatable | Notes |
|---|---|---|---|---|---|
| `--text` | string | yes | — | no | |
| `--provider` | string | no | `openai` | no | |
| `--voice` | string | no | `alloy` | no | |
| `--model` | string | no | — | no | |
| `--speed` | float | no | — | no | |
| `--volume` | float | no | — | no | |
| `--emotion` | string | no | — | no | |
| `--output_format` | string | no | — | no | |
| `--timeout` | int | no | — | no | |
| `--webhook` | string | no | — | no | |
| `--run_async` / `--no-run_async` | bool | no | `true` | no | |
| `--extra` | string | no | — | no | JSON object string |
| `--api_key` | string | no | AI302_KEY | no | |

**Success output:**
```json
{
  "status": "pending",
  "taskid": "<id>",
  "request_id": "<req_id>",
  "cost": {...},
  "created_at": "...",
  "request": {"method":"POST","url":"/302/v2/audio/tts","headers":{...},"params":{...},"body":{...}},
  "raw": {...}
}
```

**Example:**
```bash
ai302 tts create --text "hello world" --provider openai --voice alloy --api_key "sk-xxx"
```

#### `tts fetch <taskid> [--short] [--api_key]`

Same pattern as `video fetch`. Result field: `audio_url`.

---

### 5.5 `task` (local YAML editor)

#### `task edit --set ... [--add ...] [--remove ...] [--path]`

| Option | Type | Required | Repeatable | Notes |
|---|---|---|---|---|
| `--set` | string | at least one of `--set`, `--add`, `--remove` | **yes** | `path=value`, `path+=value`, or `path-=value` |
| `--add` | string | ^ | **yes** | `path=value`. Appends to array. Equivalent to `path+=value`. |
| `--remove` | string | ^ | **yes** | `path=value` or `path=field=value`. Removes from array. Equivalent to `path-=value`. |
| `--path` | string | no | no | Path to specific YAML file. If omitted, uses latest `*.yaml` in `ai302/templates/workspace/tasks` (sorted by filename descending). |

**Path syntax:**
- Dotted keys: `workflow.id=value`
- List index: `steps[0].parameters.prompt=value`
- List field selector: `steps[step=2].parameters.prompt=value`

**Value coercion:**
- `true` / `false` → bool
- `null` → None
- numeric strings → int/float (octal-like strings starting with `0` except `0`/`0.x` stay as strings)
- everything else → string

**JSON values:** Append `@json` to key: `parameters.extra@json={"a":1}` → parsed as JSON, written as YAML flow style (`{a: 1}`).

**Operators:**
- `=` (or `--set`): set/overwrite
- `+=` (or `--add`): append to list
- `-=` (or `--remove`): remove from list. Value matching: exact scalar match or `field=value` for object lists.

**Error exits:**
- No `--set`/`--add`/`--remove` → exit 2 (BadParameter)
- YAML file not found → exit 1, output `{"status":"failed","error":"YAML file not found: ..."}`
- Parse/traverse error → exit 1, output `{"status":"failed","error":"..."}`

**Success output:**
```json
{"status":"completed","path":"...","updated":true,"sets":[{"path":"...","action":"set"}]}
```

**Examples:**
```bash
# Edit latest task file
ai302 task edit --set "workflow.steps[step=2].parameters.prompt=生成一只更可爱的小猫"

# Specify file
ai302 task edit --path "./tasks/my_task.yaml" --set "a=b"

# Add array element
ai302 task edit --add "workflow.running_steps=Node_C"
ai302 task edit --set "workflow.running_steps+=Node_C"

# Remove array element (scalar match)
ai302 task edit --remove "workflow.pending_steps=Node_C"
ai302 task edit --set "workflow.pending_steps-=Node_C"

# Remove array element (object field match)
ai302 task edit --remove "workflow.steps=step=1"
ai302 task edit --set "workflow.steps-=step=1"

# JSON value
ai302 task edit --set "depends_on@json=[1,3]"
ai302 task edit --set "parameters.extra@json={\"a\":1}"
```

---

### 5.6 `history`

#### `history list [OPTIONS]`

| Option | Type | Required | Default | Notes |
|---|---|---|---|---|
| `--kind` | string | no | — | `image` or `video` or `tts` |
| `--op` | string | no | — | `create`, `fetch`, `generate` |
| `--taskid` | string | no | — | |
| `--status` | string | no | — | |
| `--model` | string | no | — | |
| `--since-ts` | string | no | — | Inclusive; UTC ISO, e.g. `2026-04-27T12:34:56+00:00` |
| `--until-ts` | string | no | — | Exclusive; UTC ISO |
| `--limit` | int | no | 100 | |

- Output: raw JSONL lines (one per line), most recent first (but returned in chronological order after internal reverse).
- Each line is a JSON object with fields: `ts`, `kind`, `op`, `status`, `taskid`, `model`, `request`, `result`, `error`.

#### `history now`
- Output: current UTC ISO timestamp string (e.g. `2026-04-27T12:34:56.789012+00:00`)

#### `history path`
- Output: absolute path to `history.jsonl` (e.g. `/Users/.../.ai302/history.jsonl`)

---

## 6. Error Handling Protocol

### 6.1 Exit Codes

| Code | Meaning | Typical Cause |
|---|---|---|
| 0 | Success | |
| 1 | Runtime/API error | `AI302ApiError`, file not found, YAML parse error |
| 2 | Parameter validation | Typer `BadParameter`: missing required arg, invalid enum, invalid JSON |

### 6.2 API Error Retry Behavior

HTTP client (`ai302/api/http_client.py`) retries automatically:
- Retries: 2 for most endpoints, 1 for image generate/create
- Retry on: 5xx, 408, 409, 429, `httpx.TimeoutException`, `httpx.NetworkError`
- **No retry on:** 401 (auth failure)
- Timeout: 60s (video/tts/fetch), 180s (image generate/create)

**Agent action:** Do NOT implement your own retry loop for transient errors. The CLI already retries. If CLI returns `"status":"failed"`, treat as terminal for this invocation.

### 6.3 Error Decision Tree

```
Parse CLI output with json.loads.
If exit code == 2:
  → Read "error" field or stderr.
  → Fix: provide missing required argument, fix invalid enum, pass valid JSON for --extra.
If exit code == 1 and output contains "status":"failed":
  → Read "error" field.
  → If error contains "missing api key": set AI302_KEY or pass --api_key.
  → If error contains "missing model": pass --model or run `ai302 model set <kind> <model>` first.
  → If error contains "unsupported model": run `ai302 model list <kind>` to get valid models.
  → If error contains "network error" / "request timeout": this is after retries exhausted; check connectivity, then retry the exact same command once.
  → If error contains "invalid operation" / "invalid path": fix the task edit path/operator syntax.
If exit code == 1 and no JSON output (rare):
  → Treat as unexpected crash; report the stderr.
```

### 6.4 Common Mistakes & Fixes

| Mistake | Fix |
|---|---|
| `missing api key` | `export AI302_KEY="sk-xxx"` or add `--api_key "sk-xxx"` to every command |
| `missing model` | Add `--model <name>` or set default: `ai302 model set t2v minimaxi-t2v-01` |
| `unsupported model for t2v: foo` | Run `ai302 model list t2v` and pick from returned list |
| `--extra must be valid JSON object` | Ensure `--extra` is a JSON **object** (not array/string), properly shell-escaped: `--extra '{"key":"val"}'` |
| `YAML file not found` | Check `--path` or ensure `ai302/templates/workspace/tasks/*.yaml` exists |
| `tasks dir not found` | Create `ai302/templates/workspace/tasks/` or use `--path` |
| `invalid operation` (task edit) | Ensure argument contains `=`, `+=`, or `-=` |
| `cannot traverse into non-mapping` | The YAML path references a non-dict node; inspect file structure first |
| `path '...' exists but is not a list` | Using `--add`/`--remove` on a non-array field |

---

## 7. Local File System Layout

```
$AI302_CONFIG_DIR/           # default: ~/.ai302
  config.json               # {"models":{"t2v":"...","i2v":"...","t2i":"...","i2i":"..."}}
  history.jsonl             # append-only event log
  tasks/
    <taskid>.json           # per-task snapshot (deep-merged on each fetch)
  tts/
    providers.json          # cache from `tts refresh`

ai302/templates/workspace/tasks/
  *.yaml                    # default target for `task edit` (latest by filename desc)
```

---

## 8. Async Task Polling Protocol

For `video create`, `image create`, `tts create`:

1. Invoke create command.
2. Parse output. Extract `taskid`.
3. If `status == "failed"` → stop, report error.
4. If `status == "completed"` (rare on first call) → extract result URL (`video_url`/`image_url`/`audio_url`).
5. Otherwise (`pending`/`processing`):
   - Wait (agent-defined interval, suggest 5-30s depending on task type).
   - Call `fetch <taskid> --short`.
   - Parse output.
   - Loop until `status` is `completed` or `failed`.
6. `--short` flag on fetch minimizes output size; it omits `raw` and history writes.

**Note:** `image generate` is sync; it blocks until `completed` or `failed`. No polling needed.

---

## 9. Command Quick Reference (Copy-Paste Templates)

```bash
# --- Auth check ---
ai302 history path

# --- Model defaults ---
ai302 model set t2v minimaxi-t2v-01
ai302 model set i2v minimaxi-hailuo-2.3-fast
ai302 model set t2i flux-kontext-max-t2i
ai302 model set i2i wan2.6-image

# --- Video (async) ---
ai302 video create --prompt "a cat runs" --model minimaxi-t2v-01 --api_key "sk-xxx"
ai302 video fetch <taskid> --short --api_key "sk-xxx"

# --- Image (sync) ---
ai302 image generate --prompt "sky city" --model flux-kontext-max-t2i --api_key "sk-xxx"

# --- Image (async) ---
ai302 image create --prompt "sky city" --model flux-kontext-max-t2i --api_key "sk-xxx"
ai302 image fetch <taskid> --short --api_key "sk-xxx"

# --- TTS ---
ai302 tts refresh --api_key "sk-xxx"
ai302 tts providers --provider openai
ai302 tts voices --provider openai
ai302 tts create --text "hello" --provider openai --voice alloy --api_key "sk-xxx"
ai302 tts fetch <taskid> --short --api_key "sk-xxx"

# --- Task edit ---
ai302 task edit --set "workflow.steps[step=2].parameters.prompt=new prompt"
ai302 task edit --path "./custom.yaml" --set "a=b" --add "list+=item"

# --- History ---
ai302 history list --kind video --op create --limit 10
ai302 history list --since-ts "2026-04-27T00:00:00+00:00" --limit 50
```
