# ai302 CLI API

本文档聚焦两件事：
1) CLI 支持哪些命令
2) CLI 的 JSON 输出格式（字段说明）

> 约定：CLI 所有输出均为 **单行 JSON**（`ensure_ascii=False`），便于脚本处理。

## 0. 安装与入口

- 直接运行（开发/最小测试）：
  - `python -m ai302 ...`
- 安装后命令（`pyproject.toml` 的 `project.scripts`）：
  - `ai302 ...`

## 1. 鉴权与环境变量

- API Key 来源（优先级）：
  1) 命令行参数 `--api_key`
  2) 环境变量 `AI302_KEY`

- Base URL：
  - `AI302_BASE_URL`（默认：`https://api.302.ai`）

- 本地配置目录：
  - `AI302_CONFIG_DIR`（默认：`~/.ai302`）
  - 配置文件：`config.json`

## 2. 命令总览

顶层命令：

- `ai302 model ...`（默认模型设置/查询）
- `ai302 video ...`（视频：异步任务）
- `ai302 image ...`（图片：同步生成）
- `ai302 tts ...`（TTS：异步任务 + 本地 providers 缓存）
- `ai302 task ...`（本地 YAML tasks 编辑）

> 所有命令均支持 `--help` 与 `-h`。

## 2.1 状态枚举（CLI 统一约定）

异步任务（video / tts / image create）状态枚举固定为：
- `pending`：准备/排队中
- `processing`：处理中
- `completed`：完成
- `failed`：失败

同步接口（image generate）状态枚举：
- `completed`：完成
- `failed`：失败



`kind` 枚举：
- `t2v` / `i2v`（视频）
- `t2i` / `i2i`（图片）

---

## 3. `ai302 task`

用途：编辑 `ai302/templates/workspace/tasks` 下最新的 `*.yaml`（按文件名倒序取最新），或者通过 `--path` 指定特定文件。

### 3.1 `ai302 task edit [Options]`

- 参数
  - `--set`：可重复；格式：`path=value` 或 `path+=value` 或 `path-=value`
  - `--add`：可重复；格式：`path=value`。等价于 `path+=value`
  - `--remove`：可重复；格式：`path=value` 或 `path=field=value`。等价于 `path-=value`
  - `--path`：可选；指定要编辑的 YAML 文件路径。

- 路径语法
  - dotted：`workflow.id=...`
  - list 下标：`workflow.steps[0].parameters.prompt=...`
  - list 条件筛选（按字段匹配）：`workflow.steps[step=2].parameters.prompt=...`

- 运算符说明
  - `=`：设置/覆盖值（在 `--set` 中默认）
  - `+=`：向目标数组追加一个元素
  - `-=`：从目标数组移除元素
    - 值匹配：`pending_steps-=Node_A`
    - 条件匹配：`steps-=step=1`

- 值解析
  - 默认：自动把 `true/false/null/数字` 转成对应类型，其它当字符串
  - `@json`：把值按 JSON 解析，并且写回 YAML 时强制使用 **flow style**
    - list → `[...]`
    - object → `{...}`

示例：

```bash
# 修改
ai302 task edit --set "workflow.steps[step=2].parameters.prompt=生成一只更可爱的小猫"

# 添加
ai302 task edit --add "workflow.running_steps=Node_A"
ai302 task edit --set "workflow.running_steps+=Node_A"

# 移除
ai302 task edit --remove "workflow.pending_steps=Node_A"
ai302 task edit --remove "workflow.steps=step=1"
```

- 输出 JSON

```json
{"status":"completed","path":"<yaml path>","updated":true,"sets":[{"path":"...","action":"set|add|remove"}]}
```

---

### 4.1 `ai302 model set <kind> <model>`

用途：设置默认模型（写入本地配置）。

- 参数
  - `kind`：见上
  - `model`：模型名称字符串

- 输出 JSON

```json
{"status":"completed","kind":"t2v","model":"minimaxi-t2v-01"}
```

### 3.2 `ai302 model list <kind>`

用途：列出内置支持的模型列表（静态表，来源于 `SUPPORTED_MODELS`）。

- 输出 JSON

```json
{"status":"completed","kind":"t2i","models":["flux-kontext-max-t2i","flux-2-klein-4b","gpt-image-2-plus"]}
```

### 3.3 `ai302 model get <kind> [--random]`

用途：获取一个支持的模型（默认返回列表第一个；传 `--random` 则随机返回一个）。

- 输出 JSON

```json
{"status":"completed","kind":"t2v","model":"minimaxi-t2v-01"}
```

---

## 4. `ai302 video`

### 4.1 `ai302 video create`

用途：创建视频生成任务。

- 关键参数（Options）
  - `--prompt`（必填）：文本提示词
  - `--model`：模型名（可选；不传时会根据输入推断 t2v/i2v 并使用本地默认模型；会校验必须在 `model list` 列表里）
  - `--image`：可重复传入；支持 1 个或多个（URL 或 base64 data URL）。多图示例：`--image "url1" --image "url2"`
  - `--end_image`：可选
  - `--video`：可选（用于 i2v 等）
  - `--negative_prompt`：可选
  - `--duration`：可选（int）
  - `--resolution`：可选（string）
  - `--aspect_ratio`：可选（string）
  - `--fps`：可选（string）
  - `--webhook`：可选（通过 query 参数传给服务端）
  - `--extra`：可选（JSON object 字符串；会 merge 到请求 body 顶层）
  - `--api_key`：可选（优先于环境变量 `AI302_KEY`）

- 成功输出 JSON（字段）

```json
{
  "status": "<status>",
  "taskid": "<taskid>",
  "created_at": "<created_at>",
  "request": {
    "method": "POST",
    "url": "/302/v2/video/create",
    "headers": {"Authorization": "[REDACTED]"},
    "params": {"webhook": "<webhook>"},
    "body": {"prompt": "<prompt>", "model": "<model>", "...": "..."}
  },
  "raw": {}
}
```

- 失败输出 JSON（并以退出码 1 退出）

```json
{
  "status": "failed",
  "taskid": null,
  "error": "<message>",
  "request": {
    "method": "POST",
    "url": "/302/v2/video/create",
    "headers": {"Authorization": "[REDACTED]"},
    "params": {"webhook": "<webhook>"},
    "body": {"prompt": "<prompt>", "model": "<model>", "...": "..."}
  }
}
```
### 4.2 `ai302 video fetch <taskid>`

用途：查询任务状态与结果。

- 参数
  - `--short`：可选；仅返回 status, taskid 和 result_url (若已完成)

- 成功输出 JSON（字段）

```json
{
  "status": "<status>",
  "taskid": "<task_id>",
  "video_url": "<video_url>",
  "model": "<model>",
  "created_at": "<created_at>",
  "completed_at": "<completed_at>",
  "updated_at": "<updated_at>",
  "raw": {"...": "..."}
}
```

- 使用 `--short` 时的输出：

```json
{"status":"completed","taskid":"<taskid>","result_url":"<video_url>"}
```

- 失败输出 JSON（并以退出码 1 退出）

```json
{"status":"failed","taskid":"<taskid>","error":"<message>"}
```

---

## 5. `ai302 image`（同步）

### 5.1 `ai302 image generate`

用途：图片同步生成（302 格式接口）。

### 5.2 `ai302 image create`

用途：图片异步生成（创建任务）。

- 关键参数（Options）
  - `--prompt`（必填）
  - `--model`：可选；不传时推断 `t2i/i2i` 并使用默认模型；会校验必须在 `model list` 列表里
  - `--height` / `--width`
  - `--negative_prompt`
  - `--aspect_ratio`
  - `--output_format`
  - `--image`：可重复传入；支持 1 个或多个（URL 或 base64 data URL）。多图示例：`--image "url1" --image "url2"`
  - `--mask_image`
  - `--run_async/--no-run_async`（默认 true）
  - `--webhook`（可选，通过 query 参数传给服务端）
  - `--extra`：JSON object 字符串；会 merge 到请求 body 顶层
  - `--api_key`

- 成功输出 JSON（字段）

```json
{
  "status": "<status>",
  "taskid": "<taskid>",
  "created_at": "<created_at>",
  "request": {
    "method": "POST",
    "url": "/302/v2/image/generate",
    "headers": {"Authorization": "[REDACTED]"},
    "params": {"run_async": true},
    "body": {"prompt": "<prompt>", "model": "<model>", "...": "..."}
  },
  "raw": {}
}
```

- 失败输出 JSON（并以退出码 1 退出）

```json
{
  "status": "failed",
  "taskid": null,
  "error": "<message>",
  "request": {
    "method": "POST",
    "url": "/302/v2/image/generate",
    "headers": {"Authorization": "[REDACTED]"},
    "params": {"run_async": true},
    "body": {"prompt": "<prompt>", "model": "<model>", "...": "..."}
  }
}
```

### 5.3 `ai302 image fetch <taskid>`

用途：异步获取图片生成结果。

- 参数
  - `--short`：可选；仅返回 status, taskid 和 result_url (若已完成)

- 成功输出 JSON（字段）

```json
{
  "status": "<status>",
  "taskid": "<task_id>",
  "image_url": "<image_url>",
  "image_urls": ["<image_url>", "..."],
  "model": "<model>",
  "created_at": "<created_at>",
  "completed_at": "<completed_at>",
  "updated_at": "<updated_at>",
  "request": {
    "method": "GET",
    "url": "/302/v2/image/fetch/<taskid>",
    "headers": {"Authorization": "[REDACTED]"},
    "params": null,
    "body": null
  },
  "raw": {"...": "..."}
}
```

- 使用 `--short` 时的输出：

```json
{"status":"completed","taskid":"<taskid>","result_url":"<image_url>"}
```

- 失败输出 JSON（并以退出码 1 退出）

```json
{
  "status": "failed",
  "taskid": "<taskid>",
  "error": "<message>",
  "request": {
    "method": "GET",
    "url": "/302/v2/image/fetch/<taskid>",
    "headers": {"Authorization": "[REDACTED]"},
    "params": null,
    "body": null
  }
}
```

- 关键参数（Options）
  - `--prompt`（必填）
  - `--model`：可选；不传时推断 `t2i/i2i` 并使用默认模型；会校验必须在 `model list` 列表里
  - `--height` / `--width`
  - `--negative_prompt`
  - `--aspect_ratio`
  - `--output_format`
  - `--image`：可重复传入；支持 1 个或多个（URL 或 base64 data URL）。多图示例：`--image "url1" --image "url2"`
  - `--mask_image`
  - `--extra`：JSON object 字符串；会 merge 到请求 body 顶层
  - `--api_key`

- 成功输出 JSON（字段）

```json
{
  "status": "completed|failed",
  "taskid": "<task_id>",
  "created_at": "<created_at>",
  "completed_at": "<completed_at>",
  "image_url": "<image_url>",
  "image_urls": ["<image_url>", "..."],
  "request": {
    "method": "POST",
    "url": "/302/v2/image/generate",
    "headers": {"Authorization": "[REDACTED]"},
    "params": null,
    "body": {"prompt": "<prompt>", "model": "<model>", "...": "..."}
  },
  "raw": {"...": "..."}
}
```

- 失败输出 JSON（并以退出码 1 退出）

```json
{
  "status": "failed",
  "error": "<message>",
  "request": {
    "method": "POST",
    "url": "/302/v2/image/generate",
    "headers": {"Authorization": "[REDACTED]"},
    "params": null,
    "body": {"prompt": "<prompt>", "model": "<model>", "...": "..."}
  },
  "raw": null
}
```

---

## 6. `ai302 tts`

> 首次使用建议先执行 `ai302 tts refresh`，将 provider/model/voice 信息缓存到本地 `$AI302_CONFIG_DIR/tts/providers.json`。

### 6.1 `ai302 tts refresh`

用途：从接口拉取 TTS provider 信息并写入本地缓存。

- 参数
  - `--provider`：可重复传入；过滤指定 provider
  - `--api_key`

- 成功输出 JSON

```json
{"status":"completed","saved_to":"<path>","providers_count":13}
```

- 失败输出 JSON（并以退出码 1 退出）

```json
{"status":"failed","error":"<message>"}
```

### 6.2 `ai302 tts providers`

用途：读取本地缓存，列出 provider（扁平化）。

### 6.2.1 `ai302 tts providers-get [--random]`

用途：从本地缓存里获取一个 provider（默认第一个；传 `--random` 则随机）。

- 参数
  - `--provider`：可选；按 provider 名过滤

- 输出 JSON

```json
{"status":"completed","providers":[{"provider":"openai","models":["..."],"output_formats":["..."],"voices_count":12}]}
```

### 6.3 `ai302 tts voices`

用途：读取本地缓存，列出 voices（扁平化数组，便于 jq 过滤）。

### 6.3.1 `ai302 tts voices-get <provider> [--random]`

用途：从本地缓存里获取一个 voice（默认第一个；传 `--random` 则随机）。

- 参数
  - `--provider`：可选；按 provider 名过滤

- 输出 JSON

```json
{"status":"completed","provider":"openai","voices":[{"provider":"openai","voice":"alloy","name":"Alloy"}]}
```

### 6.4 `ai302 tts create`

用途：创建 TTS 任务（异步）。

- 关键参数（Options）
  - `--text`（必填）
  - `--provider`（必填）
  - `--voice`（必填）
  - `--model` / `--speed` / `--volume` / `--emotion` / `--output_format` / `--timeout`
  - `--webhook`（可选，通过 query 参数传给服务端）
  - `--run_async/--no-run_async`（默认 true）
  - `--extra`（可选；JSON object 字符串；会 merge 到请求 body 顶层）
  - `--api_key`

- 成功输出 JSON（字段）

```json
{
  "status": "<status>",
  "taskid": "<taskid>",
  "created_at": "<created_at>",
  "request": {
    "method": "POST",
    "url": "/302/v2/audio/tts",
    "headers": {"Authorization": "[REDACTED]"},
    "params": {"run_async": true},
    "body": {"text": "<text>", "provider": "<provider>", "voice": "<voice>", "...": "..."}
  },
  "raw": {}
}
```

- 失败输出 JSON（并以退出码 1 退出）

```json
{
  "status": "failed",
  "taskid": null,
  "error": "<message>",
  "request": {
    "method": "POST",
    "url": "/302/v2/audio/tts",
    "headers": {"Authorization": "[REDACTED]"},
    "params": {"run_async": true},
    "body": {"text": "<text>", "provider": "<provider>", "voice": "<voice>", "...": "..."}
  }
}
```
### 6.5 `ai302 tts fetch <taskid>`

用途：查询任务状态与结果。

- 参数
  - `--short`：可选；仅返回 status, taskid 和 result_url (若已完成)

- 成功输出 JSON（字段）

```json
{
  "status": "<status>",
  "taskid": "<task_id>",
  "audio_url": "<audio_url>",
  "provider": "<provider>",
  "model": "<model>",
  "created_at": "<created_at>",
  "completed_at": "<completed_at>",
  "updated_at": "<updated_at>",
  "raw": {"...": "..."}
}
```

- 使用 `--short` 时的输出：

```json
{"status":"completed","taskid":"<taskid>","result_url":"<audio_url>"}
```

- 失败输出 JSON（并以退出码 1 退出）

```json
{"status":"failed","taskid":"<taskid>","error":"<message>"}
```

---

## 7. `ai302 history`

- 文件位置：`$AI302_CONFIG_DIR/history.jsonl`
- 查询输出：默认原样输出匹配的 jsonl 行

命令：
- `ai302 history path`
- `ai302 history list [--kind image|video] [--op create|fetch|generate] [--taskid ...] [--status ...] [--model ...] [--limit N]`

---

## 8. 退出码约定

- 0：成功（命令正常返回 JSON）
- 1：请求失败/参数错误等导致提前退出
