from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import CONFIG_DIR


TASKS_DIR = CONFIG_DIR / "tasks"


def _task_path(taskid: str) -> Path:
    return TASKS_DIR / f"{taskid}.json"


def _deep_merge(a: Any, b: Any) -> Any:
    if isinstance(a, dict) and isinstance(b, dict):
        out = dict(a)
        for k, v in b.items():
            out[k] = _deep_merge(out.get(k), v) if k in out else v
        return out
    return b


def upsert_task_snapshot(*, taskid: str, data: dict[str, Any]) -> None:
    TASKS_DIR.mkdir(parents=True, exist_ok=True)
    path = _task_path(taskid)

    merged = data
    if path.exists():
        try:
            existing = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            existing = {}
        if not isinstance(existing, dict):
            existing = {}

        if "request" in data:
            data = dict(data)
            data.pop("request", None)

        if "request" in data:
            existing = dict(existing)
            existing.pop("request", None)

        merged = _deep_merge(existing, data)

    path.write_text(json.dumps(merged, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
