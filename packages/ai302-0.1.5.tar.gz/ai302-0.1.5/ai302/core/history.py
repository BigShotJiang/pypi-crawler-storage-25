from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import CONFIG_DIR


HISTORY_PATH = CONFIG_DIR / "history.jsonl"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def append_history(event: dict[str, Any]) -> None:
    HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(event, ensure_ascii=False)
    with HISTORY_PATH.open("a", encoding="utf-8") as f:
        f.write(line)
        f.write("\n")


@dataclass(frozen=True)
class HistoryFilter:
    kind: str | None = None
    op: str | None = None
    taskid: str | None = None
    status: str | None = None
    model: str | None = None
    prompt: str | None = None
    since_ts: str | None = None
    until_ts: str | None = None
    limit: int = 100


def _match(e: dict[str, Any], f: HistoryFilter) -> bool:
    if f.kind and e.get("kind") != f.kind:
        return False
    if f.op and e.get("op") != f.op:
        return False
    if f.taskid and e.get("taskid") != f.taskid:
        return False
    if f.status and e.get("status") != f.status:
        return False
    if f.model and e.get("model") != f.model:
        return False
    if f.prompt is not None and (e.get("prompt") or "") != f.prompt:
        return False

    ts = e.get("ts")
    if (f.since_ts or f.until_ts) and not isinstance(ts, str):
        return False
    if f.since_ts and ts < f.since_ts:
        return False
    if f.until_ts and ts >= f.until_ts:
        return False

    return True


def query_history_lines(*, filt: HistoryFilter, path: Path = HISTORY_PATH) -> list[str]:
    if not path.exists():
        return []

    out: list[str] = []
    for line in reversed(path.read_text(encoding="utf-8").splitlines()):
        try:
            obj = json.loads(line)
        except Exception:
            continue
        if isinstance(obj, dict) and _match(obj, filt):
            out.append(line)
            if len(out) >= filt.limit:
                break

    out.reverse()
    return out


def build_event_base(*, kind: str, op: str) -> dict[str, Any]:
    return {"ts": now_iso(), "kind": kind, "op": op}
