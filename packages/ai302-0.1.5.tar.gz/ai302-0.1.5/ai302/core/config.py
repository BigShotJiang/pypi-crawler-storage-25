from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any


CONFIG_DIR = Path(os.environ.get("AI302_CONFIG_DIR", Path.home() / ".ai302"))
CONFIG_PATH = CONFIG_DIR / "config.json"


@dataclass(frozen=True)
class Config:
    default_t2v_model: str | None
    default_i2v_model: str | None
    default_t2i_model: str | None
    default_i2i_model: str | None


def _read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def load_config() -> Config:
    data = _read_json(CONFIG_PATH)
    models = data.get("models") or {}
    return Config(
        default_t2v_model=models.get("t2v"),
        default_i2v_model=models.get("i2v"),
        default_t2i_model=models.get("t2i"),
        default_i2i_model=models.get("i2i"),
    )


def save_model(kind: str, model: str) -> None:
    kind = kind.lower()
    if kind not in ("t2v", "i2v", "t2i", "i2i"):
        raise ValueError("kind must be t2v, i2v, t2i, or i2i")

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    data = _read_json(CONFIG_PATH)
    data.setdefault("models", {})
    data["models"][kind] = model
    CONFIG_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
