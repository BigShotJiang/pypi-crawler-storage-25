from __future__ import annotations

from typing import Any


def redact_prompt(_: str) -> str:
    return "[REDACTED]"


def redact_api_key(_: str) -> str:
    return "[REDACTED]"


def redact_fields(obj: dict[str, Any], *, keys: set[str]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in obj.items():
        if k in keys and v is not None:
            out[k] = "[REDACTED]"
        else:
            out[k] = v
    return out
