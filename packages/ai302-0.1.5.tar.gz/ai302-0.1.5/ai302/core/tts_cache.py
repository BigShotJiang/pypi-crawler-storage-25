from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import CONFIG_DIR


TTS_DIR = CONFIG_DIR / "tts"
PROVIDERS_PATH = TTS_DIR / "providers.json"


def write_providers(data: dict[str, Any]) -> Path:
    TTS_DIR.mkdir(parents=True, exist_ok=True)
    PROVIDERS_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return PROVIDERS_PATH


def read_providers() -> dict[str, Any]:
    if not PROVIDERS_PATH.exists():
        raise FileNotFoundError("providers cache not found: run `ai302 tts refresh` first")
    data = json.loads(PROVIDERS_PATH.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("providers cache is invalid")
    return data


def _iter_provider_entries(data: dict[str, Any]) -> list[dict[str, Any]]:
    providers = data.get("provider_list")
    if isinstance(providers, list):
        out: list[dict[str, Any]] = []
        for p in providers:
            if isinstance(p, dict):
                out.append(p)
        return out
    return []


def flatten_providers(data: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for p in _iter_provider_entries(data):
        provider = p.get("provider")
        info = p.get("req_params_info") if isinstance(p.get("req_params_info"), dict) else {}
        model_list = info.get("model_list") if isinstance(info.get("model_list"), list) else []
        output_formats = info.get("output_format_list") if isinstance(info.get("output_format_list"), list) else []
        voice_list = info.get("voice_list") if isinstance(info.get("voice_list"), list) else []
        out.append(
            {
                "provider": provider,
                "models": [m for m in model_list if isinstance(m, str)],
                "output_formats": [f for f in output_formats if isinstance(f, str)],
                "voices_count": sum(1 for v in voice_list if isinstance(v, dict)),
            }
        )
    return out


def flatten_voices(data: dict[str, Any], *, provider: str | None = None) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for p in _iter_provider_entries(data):
        p_name = p.get("provider")
        if provider and p_name != provider:
            continue

        info = p.get("req_params_info") if isinstance(p.get("req_params_info"), dict) else {}
        voices = info.get("voice_list") if isinstance(info.get("voice_list"), list) else []

        for v in voices:
            if not isinstance(v, dict):
                continue
            sample = v.get("sample") if isinstance(v.get("sample"), dict) else {}
            out.append(
                {
                    "provider": p_name,
                    "voice": v.get("voice"),
                    "name": v.get("name"),
                    "gender": v.get("gender"),
                    "emotions": v.get("emotion") if isinstance(v.get("emotion"), list) else [],
                    "supported_models": v.get("supported_models") if isinstance(v.get("supported_models"), list) else [],
                    "sample_zh": sample.get("zh"),
                    "sample_en": sample.get("en"),
                    "sample_ja": sample.get("ja"),
                }
            )
    return out
