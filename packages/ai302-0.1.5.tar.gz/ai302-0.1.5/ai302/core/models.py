from __future__ import annotations

SUPPORTED_MODELS: dict[str, list[str]] = {
  "t2v": [
    "minimaxi-t2v-01",
    "minimaxi-hailuo-2.3-fast"
  ],
  "i2v": [
    "minimaxi-hailuo-2.3-fast",
  ],
  "t2i": [
    "flux-kontext-max-t2i",
    "flux-2-klein-4b",
    "gpt-image-2-plus",
    "wanx2.0-t2i-turbo"
  ],
  "i2i": [
    "wan2.6-image",
  ],
}
