from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap, CommentedSeq


# Determine TASKS_DIR based on the project structure
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
TASKS_DIR = _PROJECT_ROOT / "templates" / "workspace" / "tasks"


@dataclass(frozen=True)
class EditOp:
    path: str
    value: Any
    action: str  # "set", "add", "remove"
    style: str | None


def _coerce_scalar(s: str) -> Any:
    v = s.strip()
    if v.lower() == "null":
        return None
    if v.lower() == "true":
        return True
    if v.lower() == "false":
        return False
    try:
        if v.startswith("0") and v != "0" and not v.startswith("0."):
            raise ValueError
        return int(v)
    except Exception:
        pass
    try:
        return float(v)
    except Exception:
        return s


def parse_op_arg(raw: str, default_action: str = "set") -> EditOp:
    raw = raw.strip()

    # Detect operator and action
    if "+=" in raw:
        action = "add"
        delim = "+="
    elif "-=" in raw:
        action = "remove"
        delim = "-="
    elif "=" in raw:
        action = default_action
        delim = "="
    else:
        raise ValueError(f"invalid operation: {raw} (must contain =, +=, or -=)")

    # Split by the first occurance of delim that is not inside []
    i = raw.find(delim)
    while i != -1:
        key = raw[:i].strip()
        if key and key.count("[") == key.count("]"):
            val = raw[i + len(delim) :]
            break
        i = raw.find(delim, i + 1)
    else:
        raise ValueError(f"invalid operation: {raw}")

    if not key:
        raise ValueError("operation key cannot be empty")

    style: str | None = None
    value: Any
    if key.endswith("@json"):
        key = key[: -len("@json")]
        value = json.loads(val)
        style = "json"
    else:
        value = _coerce_scalar(val)

    return EditOp(path=key, value=value, action=action, style=style)


def parse_set_arg(raw: str) -> EditOp:
    """For backward compatibility."""
    return parse_op_arg(raw, default_action="set")


def latest_yaml_path() -> Path:
    if not TASKS_DIR.exists():
        raise FileNotFoundError(f"tasks dir not found: {TASKS_DIR}")
    candidates = sorted(TASKS_DIR.glob("*.yaml"), key=lambda p: p.name, reverse=True)
    if not candidates:
        raise FileNotFoundError(f"no .yaml files under {TASKS_DIR}")
    return candidates[0]


def _parse_segment(seg: str) -> tuple[str, int | tuple[str, str] | None]:
    if "[" not in seg:
        return seg, None
    if not seg.endswith("]"):
        raise ValueError(f"invalid path segment: {seg}")
    key, bracket = seg.split("[", 1)
    inner = bracket[:-1]
    if inner.isdigit():
        return key, int(inner)
    if "=" in inner:
        k, v = inner.split("=", 1)
        k = k.strip()
        v = v.strip()
        if not k or not v:
            raise ValueError(f"invalid selector in segment: {seg}")
        return key, (k, v)
    raise ValueError(f"invalid list selector in segment: {seg}")


def _ensure_mapping(parent: Any, key: str) -> Any:
    if not isinstance(parent, dict):
        raise TypeError(f"cannot traverse into non-mapping at '{key}'")
    if key not in parent or parent[key] is None:
        parent[key] = {}
    if not isinstance(parent[key], dict):
        raise TypeError(f"path '{key}' exists but is not a mapping")
    return parent[key]


def _ensure_list(parent: Any, key: str) -> list[Any]:
    if not isinstance(parent, dict):
        raise TypeError(f"cannot traverse into non-mapping at '{key}'")
    if key not in parent or parent[key] is None:
        parent[key] = []
    if not isinstance(parent[key], list):
        raise TypeError(f"path '{key}' exists but is not a list")
    return parent[key]


def _select_list_item(items: list[Any], selector: int | tuple[str, str]) -> Any:
    if isinstance(selector, int):
        if selector < 0:
            raise ValueError("list index must be >= 0")
        while len(items) <= selector:
            items.append({})
        return items[selector]

    sel_key, sel_val = selector
    for it in items:
        if isinstance(it, dict) and str(it.get(sel_key)) == sel_val:
            return it

    created: dict[str, Any] = {sel_key: _coerce_scalar(sel_val)}
    items.append(created)
    return created


def _split_path(path: str) -> list[str]:
    out: list[str] = []
    cur: list[str] = []
    depth = 0
    for ch in path:
        if ch == "." and depth == 0:
            seg = "".join(cur).strip()
            if seg:
                out.append(seg)
            cur = []
            continue
        if ch == "[":
            depth += 1
        elif ch == "]" and depth > 0:
            depth -= 1
        cur.append(ch)
    seg = "".join(cur).strip()
    if seg:
        out.append(seg)
    return out


def _apply_op(doc: Any, op: EditOp) -> None:
    parts = _split_path(op.path)
    if not parts:
        raise ValueError("path cannot be empty")

    cur: Any = doc
    for raw in parts[:-1]:
        key, sel = _parse_segment(raw)
        if sel is None:
            cur = _ensure_mapping(cur, key)
            continue

        lst = _ensure_list(cur, key)
        cur = _select_list_item(lst, sel)

    last_key, last_sel = _parse_segment(parts[-1])

    if op.action == "set":
        if last_sel is None:
            if not isinstance(cur, dict):
                raise TypeError("cannot set on non-mapping")
            cur[last_key] = op.value
            return

        lst = _ensure_list(cur, last_key)
        target = _select_list_item(lst, last_sel)
        if isinstance(target, dict):
            raise ValueError("cannot assign to a list element directly; set a field on it instead")
        raise ValueError("invalid assignment target")

    elif op.action == "add":
        if last_sel is not None:
            raise ValueError("cannot use selectors with add operation (path should point to the list)")
        lst = _ensure_list(cur, last_key)
        lst.append(op.value)

    elif op.action == "remove":
        if last_sel is not None:
            lst = _ensure_list(cur, last_key)
            if isinstance(last_sel, int):
                if 0 <= last_sel < len(lst):
                    lst.pop(last_sel)
            else:
                sel_key, sel_val = last_sel
                new_lst = [it for it in lst if not (isinstance(it, dict) and str(it.get(sel_key)) == sel_val)]
                cur[last_key] = new_lst
        else:
            lst = _ensure_list(cur, last_key)
            val_str = str(op.value)
            if "=" in val_str and "[" not in val_str:
                k, v = val_str.split("=", 1)
                k, v = k.strip(), v.strip()
                new_lst = [it for it in lst if not (isinstance(it, dict) and str(it.get(k)) == v)]
            else:
                new_lst = [it for it in lst if it != op.value]
            cur[last_key] = new_lst


def _apply_style(value: Any, style: str | None) -> Any:
    if style != "json":
        return value
    if isinstance(value, list):
        seq = CommentedSeq(value)
        seq.fa.set_flow_style()
        return seq
    if isinstance(value, dict):
        mp = CommentedMap(value)
        mp.fa.set_flow_style()
        return mp
    return value


def apply_sets(*, path: Path, sets: list[EditOp]) -> dict[str, Any]:
    yaml = YAML()
    yaml.preserve_quotes = True
    yaml.width = 4096
    yaml.representer.add_representer(type(None), lambda r, d: r.represent_scalar("tag:yaml.org,2002:null", "null"))

    doc = yaml.load(path.read_text(encoding="utf-8"))
    if doc is None:
        doc = {}
    if not isinstance(doc, dict):
        raise TypeError("root YAML must be a mapping")

    for op in sets:
        _apply_op(doc, EditOp(path=op.path, value=_apply_style(op.value, op.style), action=op.action, style=op.style))

    yaml.dump(doc, path.open("w", encoding="utf-8"))
    return {"path": str(path), "updated": True, "sets": [{"path": s.path, "action": s.action} for s in sets]}
