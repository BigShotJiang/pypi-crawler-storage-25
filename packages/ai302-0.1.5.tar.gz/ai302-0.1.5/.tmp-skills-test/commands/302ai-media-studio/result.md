---
name: 302ai-media-studio:result
description: Query the status or results of a 302.ai Media Studio task
argument-hint: [task-id]
---

# 302AI Media Studio Result Command

This command queries the status of running media generation tasks by fetching results from the ai302 CLI, updating the task YAML file, and chaining to the next step when the current one completes.

## Core Responsibilities

Your job is to:

1. Locate the target task YAML file (by task ID, latest incomplete task, or conversation context)
2. Find the step currently with `status: running`
3. Execute `ai302 {video|image|tts} fetch <taskid> --short` to check the step's progress
4. Update the YAML file based on the CLI response
5. If the step completed, check for and execute the next pending step
6. Report results to the user in their language

## Task File Resolution

**Priority order for finding the task YAML:**

1. **Explicit task ID in user message**: User mentions a timestamp like `2026-04-23T15-30-45` → use `302ai-media-studio/tasks/<timestamp>.yaml`
2. **Task ID from conversation context**: If a task ID was mentioned earlier in this conversation (e.g., after propose/apply), use that
3. **Latest incomplete task**: No ID mentioned → scan `302ai-media-studio/tasks/` for the most recently modified YAML file where `workflow.status` is `running`
4. **No task found**: Ask the user to provide the task ID — do not guess

**Directory:** `302ai-media-studio/tasks/` (relative to project root)

If the user has not provided a task ID and no incomplete tasks can be found, ask them which task they want to check.

## Execution Flow

### Step 1: Read and validate the task YAML

Load the YAML file and check `workflow.status`:

- **`completed`** → Tell the user the task is fully done. Show final results for each step. End command execution.
- **`failed`** → Tell the user the task has failed. Ask if they want to retry. End command execution.
- **`running`** → Proceed to find the running step.

### Step 2: Find the running step

Scan `workflow.steps` for the step with `status: running`.

**If no step is running:**
- There are pending steps → suggest the user run apply to start execution
- All steps completed → set `workflow.status` to `completed`, tell the user
- End command execution

**If the running step has no `task_id` field:**
- This means apply didn't successfully submit the task
- Tell the user, suggest re-running apply for this step
- End command execution

### Step 3: Execute CLI fetch

From the running step, extract:
- `task_id` — the CLI task ID (set by apply after submission)
- `operation` — one of t2i, i2i, t2v, i2v, v2v, tts

Map operation to CLI command:

| Operation            | CLI Command              |
|----------------------|--------------------------|
| `t2i`, `i2i`        | `ai302 image fetch`      |
| `t2v`, `i2v`, `v2v` | `ai302 video fetch`      |
| `tts`               | `ai302 tts fetch`        |

Execute:

```bash
ai302 {video|image|tts} fetch <task_id> --short
```

### Step 4: Handle CLI response

There are three categories of outcomes:

#### A. CLI returned successfully, `status: "completed"`

The generation task succeeded. The response contains result data (e.g., `result_url`, `image_url`, `video_url`).

**Update the YAML using sequential `ai302 task edit` commands:**

```bash
# Command 1: Set step status to completed
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].status=completed"

# Command 2: Store the result_url
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].result_url=<result_url>"

# Command 3: Remove from running_steps
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --remove "workflow.running_steps=N"

# Command 4: Add to completed_steps
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --add "workflow.completed_steps=N"
```

Then proceed to **Step 5**.

#### B. CLI returned successfully, `status: "failed"`

The generation task failed on the server side.

**Update the YAML using sequential `ai302 task edit` commands:**

```bash
# Command 1: Set step status to failed
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].status=failed"

# Command 2: Remove from running_steps
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --remove "workflow.running_steps=N"

# Command 3: Add to failed_steps
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --add "workflow.failed_steps=N"

# Do NOT change workflow.status to "failed" here —
# only mark the step as failed, in case user wants to retry
```

**Reply to user:** Explain that the step failed and include the error message. Ask whether they want to retry:

- Chinese: "步骤 N 执行失败：<error>。是否需要重新生成？"
- English: "Step N failed: <error>. Would you like to retry?"

**IMPORTANT: Do NOT automatically retry.** Wait for the user to confirm. If they say yes:

**Reset the failed step using sequential `ai302 task edit` commands:**

```bash
# Command 1: Reset step status to pending
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].status=pending"

# Command 2: Clear task_id (set to null)
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --set "workflow.steps[step=N].task_id=null"

# Command 3: Add back to pending_steps
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --add "workflow.pending_steps=N"

# Command 4: Remove from failed_steps
ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
  --remove "workflow.failed_steps=N"
```

Then invoke `302ai-media-studio-apply` skill to re-execute the step.

#### C. CLI returned successfully, `status: "pending"` or `"processing"`

The task is still in progress on the server.

Tell the user the step is still processing and suggest checking again later:

- Chinese: "步骤 N 仍在处理中（status: <status>），请稍后再查询。"
- English: "Step N is still processing (status: <status>). Please check again later."

End command execution. Do not modify the YAML.

#### D. CLI command itself failed (network error, timeout, etc.)

The CLI command could not execute — this is a communication failure, not a task failure.

1. Retry the CLI command up to **3 times total**
2. Between retries, briefly wait (a few seconds)
3. If all 3 attempts fail:
   - Mark the step as failed in the YAML (same as case B above)
   - Tell the user about the network/CLI error: "CLI 命令执行失败：<error>"
   - Ask if they want to retry later (same flow as case B — wait for user confirmation)

### Step 5: Check for next pending step

After a step completes successfully, look for the next step with `status: pending`.

**If a pending step exists:**
- Tell the user the current step completed and the next step is starting
- Invoke `302ai-media-studio-apply` skill to execute the next step

**If no pending steps remain:**
- Set `workflow.status` to `completed` using CLI:
  ```bash
  ai302 task edit --path "302ai-media-studio/tasks/<timestamp>.yaml" \
    --set "workflow.status=completed"
  ```
- Tell the user all steps are done
- Summarize results:

```
所有任务已完成！
- 步骤 1 (t2i): <result_url>
- 步骤 2 (i2v): <result_url>
```

## Language Detection

Detect user language from the conversation context:
- Chinese input → Chinese response
- English input → English response
- Mixed/uncertain → Match the language of earlier messages or default to English

## Edge Cases

### Multiple running steps

If more than one step has `status: running` (shouldn't happen with linear execution), process them in step order (lowest number first).

### Workflow already completed/failed

If `workflow.status` is already `completed` or `failed`, do not execute any fetch commands. Just show the user the current state.

## CLI Command Reference

```bash
# Fetch video task status
ai302 video fetch <taskid> --short

# Fetch image task status
ai302 image fetch <taskid> --short

# Fetch TTS task status
ai302 tts fetch <taskid> --short
```

## YAML Update via CLI

### ⚠️ Important: Sequential Execution for Concurrency Safety

All `ai302 task edit` operations must be **split into sequential single-command executions** to avoid data loss from concurrent writes.

### Operators

| Operator | Command | Purpose |
|----------|---------|---------|
| `--set` | `--set "path=value"` | Set/overwrite field value |
| `--add` | `--add "path=value"` | Add element to array |
| `--remove` | `--remove "path=value"` | Remove element from array |

### Path Syntax

```bash
# Update step fields
workflow.steps[step=N].status=completed
workflow.steps[step=N].result_url=https://...

# Update workflow arrays
workflow.running_steps+=N      # Add
workflow.running_steps-=N      # Remove
```

### Value Types

- String: `--set "field=value"`
- Number: `--set "field=123"`
- null: `--set "field=null"`

### Examples

#### Step Completed - Update YAML
```bash
ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --set "workflow.steps[step=1].status=completed"

ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --set "workflow.steps[step=1].result_url=https://example.com/result.mp4"

ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --remove "workflow.running_steps=1"

ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --add "workflow.completed_steps=1"
```

#### Step Failed - Update YAML
```bash
ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --set "workflow.steps[step=1].status=failed"

ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --remove "workflow.running_steps=1"

ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --add "workflow.failed_steps=1"
```

#### Reset Failed Step for Retry
```bash
ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --set "workflow.steps[step=1].status=pending"

ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --set "workflow.steps[step=1].task_id=null"

ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --add "workflow.pending_steps=1"

ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --remove "workflow.failed_steps=1"
```

#### Workflow Completed
```bash
ai302 task edit --path "302ai-media-studio/tasks/2026-04-24T10-30-00.yaml" \
  --set "workflow.status=completed"
```
