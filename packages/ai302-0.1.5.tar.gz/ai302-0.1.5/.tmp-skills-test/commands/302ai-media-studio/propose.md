---
name: 302ai-media-studio:propose
description: Create a media generation task (images, videos, audio) from natural language
argument-hint: <prompt>
---

# 302AI Media Studio Proposal Command

This command helps users create media generation tasks by parsing their intent, extracting parameters, and generating YAML task files for the 302ai-media-studio workflow engine.

## Core Responsibilities

Your job is to:

1. Parse user intent to determine what media they want to create
2. Identify the operation type (t2i, i2i, t2v, i2v, v2v, tts)
3. Extract and validate parameters
4. Handle missing required parameters by auto-filling
5. Generate a properly formatted YAML task file

## User Intent Detection

First, analyze what the user wants to do. Look for these patterns:

**Single-step requests:**

- "Generate an image of a cat" → single t2i task
- "Turn this photo into an anime style" → single i2i task
- "Make a video from this image" → single i2v task
- "Create a video about space exploration" → single t2v task
- "Enhance this video" → single v2v task
- "Generate voiceover for this text" → single tts task

**Multi-step requests (sequential workflow):**

- "Generate an image, then turn it into a video" → t2i → i2v
- "Create a picture of a sunset, make it into video, then add narration" → t2i → i2v → tts
- "Generate a cat image, animate it, enhance the video" → t2i → i2v → v2v

**Language support:** Works for both English and Chinese requests. Common Chinese phrases:

- 生成图片, 创建图片, 画一张图
- 生成视频, 制作视频, 创建视频
- 生成音频, 文字转语音, TTS
- "先生成X，然后用Y做Z" indicates sequential workflow

## Operation Type Classification

### Image Generation

| Kind           | Operation | Detection Rule                                                        |
| -------------- | --------- | --------------------------------------------------------------------- |
| Text-to-Image  | `t2i`     | User wants to generate image from text, no input image provided       |
| Image-to-Image | `i2i`     | User provides input image (`image` or `mask_image` parameter present) |

### Video Generation

| Kind           | Operation | Detection Rule                                                        |
| -------------- | --------- | --------------------------------------------------------------------- |
| Text-to-Video  | `t2v`     | User wants to generate video from text, no input image/video provided |
| Image-to-Video | `i2v`     | User provides input image (`image` parameter present)                 |
| Video-to-Video | `v2v`     | User provides input video (`video` parameter present)                 |

### Audio Generation

| Kind           | Operation | Detection Rule                         |
| -------------- | --------- | -------------------------------------- |
| Text-to-Speech | `tts`     | User wants to generate audio from text |

## Parameter Mapping

### Required Parameters

| Operation     | Required          | Fallback                                                                  |
| ------------- | ----------------- | ------------------------------------------------------------------------- |
| t2i, i2i      | `prompt`, `model` | prompt → "生成一只可爱的小猫" / model → `ai302 model get <kind> --random` |
| t2v, i2v, v2v | `prompt`, `model` | prompt → "生成一只可爱的小猫" / model → `ai302 model get <kind> --random` |
| tts           | `text`            | text → "你好呀，有什么需要帮忙的吗？"                                     |

### Optional Parameters by Operation

**Image (t2i, i2i):**

- `height`, `width` - image dimensions
- `negative_prompt` - what to avoid
- `aspect_ratio` - e.g., "16:9", "1:1"
- `output_format` - e.g., "png", "webp"
- `image` - input image URL/path (i2i)
- `mask_image` - mask for inpainting (i2i)

**Video (t2v, i2v, v2v):**

- `image` - input image URL/path (i2v)
- `end_image` - ending frame for interpolation
- `video` - input video URL/path (v2v)
- `negative_prompt` - what to avoid
- `duration` - video duration in seconds
- `resolution` - e.g., "720p", "1080p"
- `aspect_ratio` - e.g., "16:9"
- `fps` - frames per second

**Audio (tts):**

- `model` - TTS model
- `speed` - playback speed
- `volume` - volume level
- `emotion` - emotional tone
- `output_format` - e.g., "mp3", "wav"

## Parameter Extraction Strategy

1. **Parse user input carefully** - Look for explicit parameter mentions
   - "Create a 1920x1080 image" → `width: 1920`, `height: 1080`
   - "Make it 16:9 aspect ratio" → `aspect_ratio: "16:9"`
   - "Use png format" → `output_format: "png"`

2. **Handle file references** - If user mentions a file path or URL, extract it
   - "Use ~/Desktop/cat.png as input" → `image: "~/Desktop/cat.png"`
   - "From https://example.com/video.mp4" → `video: "https://example.com/video.mp4"`

3. **For multi-step workflows** - Track which parameters apply to which step
   - "Generate a 1024x1024 cat image, then make a 5-second video from it"
     - Step 1 (t2i): `prompt: "cat"`, `width: 1024`, `height: 1024`
     - Step 2 (i2v): `duration: 5` (uses output from step 1 as input)

4. **Handle implicit dependencies** - When user says "use the previous output", the `depends_on` field references the previous step ID

## Handling Missing Required Parameters

### Step 1: Check for missing parameters

After parsing user intent, check if required parameters are missing:

```python
# For t2i/i2i/t2v/i2v/v2v
if "prompt" not in parameters:
    parameters["prompt"] = "生成一只可爱的小猫"
if "model" not in parameters:
    # Call CLI to get random model
    model = run_cli("ai302 model get <kind> --random")
    parameters["model"] = model

# For tts
if "text" not in parameters:
    parameters["text"] = "你好呀，有什么需要帮忙的吗？"
```

### Step 1.5: Validate user-specified model (when present)

When the user explicitly mentions a model (e.g. "用 flux 模型生成", "use gpt-image to draw", "model: sora"), do NOT trust the string blindly — the user may use a nickname, a shortened form, a typo, or reference a model that the platform does not actually support for the detected `kind`. Resolve the model against the live supported list before writing it into the YAML.

**Procedure:**

1. Call the CLI to fetch the supported models for the detected operation kind:

   ```bash
   ai302 model list <kind>
   ```

   Example output:

   ```json
   {
     "status": "completed",
     "kind": "t2i",
     "models": ["flux-kontext-max-t2i", "flux-2-klein-4b", "gpt-image-2-plus"]
   }
   ```

2. Fuzzy-match the user's requested model against the `models` array. Exact string equality is **not** required — be a smart matcher and consider:
   - Case-insensitive comparison
   - Substring containment in either direction (user said "flux", list has "flux-kontext-max-t2i")
   - Common token overlap (user said "gpt image", list has "gpt-image-2-plus")
   - Hyphen/underscore/space normalization
   - Family/version aliases (e.g. "flux 2" → "flux-2-klein-4b")
   - Ignoring trailing kind suffixes like `-t2i`, `-i2v`

   Pick the single best match. If multiple candidates are roughly equivalent, prefer the newer/larger variant (e.g. `-max`, higher version number).

3. **Decision:**
   - **Strong match found** → use the canonical name from the supported list as `parameters.model`. Briefly note in your user-facing summary that you mapped their request to the canonical name (e.g. `model="flux-kontext-max-t2i"（匹配自 "flux"）`).
   - **No reasonable match** → do NOT generate the YAML file. Reply to the user explaining that the requested model is not supported for this kind, and list every entry from the `models` array so they can pick one. Ask them to confirm which model to use and then proceed.

4. **CLI failure** → retry once. If it still fails, fall back to `ai302 model get <kind> --random` (the same fallback used when no model was specified) and mention the fallback in the user-facing summary so the user is not surprised.

**Why this matters:** Users naturally describe models in shorthand. Silently writing an unsupported model name into the YAML guarantees a runtime failure deep in the workflow engine, far from where the user can debug it. Catching the mismatch up front — and surfacing the supported list when we truly can't resolve it — turns a broken run into a one-message clarification.

**Example — strong match:**

User: "用 flux 模型画一张赛博朋克城市"

- Detected kind: `t2i`
- CLI: `ai302 model list t2i` → `{"models":["flux-kontext-max-t2i","flux-2-klein-4b","gpt-image-2-plus"]}`
- "flux" matches two entries; pick `flux-kontext-max-t2i` (the `-max` variant).
- Write `model: "flux-kontext-max-t2i"` into the YAML and tell the user you mapped "flux" → `flux-kontext-max-t2i`.

**Example — no reasonable match:**

User: "Use midjourney to generate a sunset"

- Detected kind: `t2i`
- CLI: `ai302 model list t2i` → `{"models":["flux-kontext-max-t2i","flux-2-klein-4b","gpt-image-2-plus"]}`
- "midjourney" has no overlap with any supported entry.
- Do NOT write the YAML. Reply (in the user's language):
  ```
  抱歉，当前 t2i 不支持 midjourney 模型。可选模型：
  - flux-kontext-max-t2i
  - flux-2-klein-4b
  - gpt-image-2-plus
  请告诉我使用哪一个，我来继续生成任务。
  ```

### Step 2: Show the user what was detected/filled

Before generating the YAML file, show a summary to the user:

```
🎯 Detected Intent: <operation> (<kind>)
📝 Parameters:
   - prompt: "<value>"
   - model: "<value>" (auto-selected)
   - height: <value> (if provided)
   ...

✅ Generating task file...
```

If the user wants to modify anything, let them adjust before proceeding.

## YAML File Generation

### File Structure

Generate a YAML file with this structure:

```yaml
workflow:
  id: "<timestamp>"
  status: running
  running_steps: []
  completed_steps: []
  failed_steps: []
  pending_steps: [1, 2, ...] # All step IDs in FIFO order

  steps:
    - step: 1
      depends_on: null
      operation: <t2i|i2i|t2v|i2v|v2v|tts>
      status: pending
      result: null
      parameters:
        prompt: "<user provided or default>"
        model: "<user provided or auto-selected>"
        # ... other detected parameters

    - step: 2
      depends_on: [1]
      operation: <...>
      status: pending
      result: null
      parameters: { ... }
```

### File Naming and Location

- **Directory:** `302ai-media-studio/tasks/` (relative to project root)
- **Filename:** Current timestamp in ISO format, e.g., `2026-04-23T15-30-45.yaml`
- **Ensure directory exists:** Create the directory if it doesn't exist

### Dependency Rules

- **First step:** `depends_on: null`
- **Subsequent steps:** `depends_on: [previous_step_id]`
- **No parallelism:** Current version only supports linear execution
- **Step IDs:** Sequential integers starting from 1

### Parameter Passing Between Steps

When a step's output becomes the next step's input:

```yaml
- step: 1
  operation: t2i
  parameters:
    prompt: "a beautiful sunset"

- step: 2
  operation: i2v
  parameters:
    # The image parameter references step 1's output
    # At runtime, this will be resolved to the actual image URL
    image: "${steps.1.result.image_url}"
    duration: 5
```

Note: The `${steps.X.result.Y}` syntax is for runtime resolution. The workflow engine will replace these references with actual values from completed steps.

## Example Workflows

### Example 1: Simple Image Generation

**User input:** "Generate a cyberpunk city image"

**Parsed intent:**

- Operation: t2i
- Parameters: `prompt: "cyberpunk city"`

**Generated YAML:**

```yaml
workflow:
  id: "2026-04-23T15-30-45"
  status: running
  running_steps: []
  completed_steps: []
  failed_steps: []
  pending_steps: [1]

  steps:
    - step: 1
      depends_on: null
      operation: t2i
      status: pending
      result: null
      parameters:
        prompt: "cyberpunk city"
        model: "flux-kontext-max-t2i" # auto-selected
```

### Example 2: Image to Video

**User input:** "Take this photo ~/Desktop/sunset.png and turn it into a 5-second video"

**Parsed intent:**

- Step 1: i2v (image provided)
- Parameters: `image: "~/Desktop/sunset.png"`, `duration: 5`

**Generated YAML:**

```yaml
workflow:
  id: "2026-04-23T15-31-20"
  status: running
  running_steps: []
  completed_steps: []
  failed_steps: []
  pending_steps: [1]

  steps:
    - step: 1
      depends_on: null
      operation: i2v
      status: pending
      result: null
      parameters:
        image: "~/Desktop/sunset.png"
        duration: 5
        model: "minimaxi-t2v-01" # auto-selected
        prompt: "生成一只可爱的小猫" # default since not provided
```

### Example 3: Multi-step Pipeline

**User input:** "Generate a cat image, then animate it into a video"

**Parsed intent:**

- Step 1: t2i → Step 2: i2v

**Generated YAML:**

```yaml
workflow:
  id: "2026-04-23T15-32-10"
  status: running
  running_steps: []
  completed_steps: []
  failed_steps: []
  pending_steps: [1, 2]

  steps:
    - step: 1
      depends_on: null
      operation: t2i
      status: pending
      result: null
      parameters:
        prompt: "cat"
        model: "flux-kontext-max-t2i" # auto-selected

    - step: 2
      depends_on: [1]
      operation: i2v
      status: pending
      result: null
      parameters:
        image: "${steps.1.result.image_url}"
        model: "minimaxi-t2v-01" # auto-selected
        prompt: "生成一只可爱的小猫" # default since not provided
```

## CLI Commands Reference

When you need to call the ai302 CLI, use these commands:

```bash
# Get a random model for a specific kind (used when the user did not specify one)
ai302 model get <kind> --random
# Output: {"status":"completed","kind":"t2i","model":"flux-kontext-max-t2i"}

# List all supported models for a specific kind
# (used when the user DID specify a model — to fuzzy-match it against what's actually supported)
ai302 model list <kind>
# Output: {"status":"completed","kind":"t2i","models":["flux-kontext-max-t2i","flux-2-klein-4b","gpt-image-2-plus"]}

# Supported kinds:
# - t2i (text-to-image)
# - i2i (image-to-image)
# - t2v (text-to-video)
# - i2v (image-to-video)
# - v2v (video-to-video)
```

**When to use which:**

- User did NOT mention a model → `ai302 model get <kind> --random`
- User DID mention a model (any form, even shorthand like "flux") → `ai302 model list <kind>`, then fuzzy-match per "Step 1.5: Validate user-specified model"

## Error Handling

If something goes wrong:

1. **CLI command fails:** Retry once, then use a hardcoded fallback model
2. **Invalid parameters:** Ask the user to clarify
3. **Ambiguous intent:** Ask the user to confirm what they want
4. **File not found:** Warn the user but continue (file may exist at runtime)

## Testing Checklist

After generating the YAML:

- [ ] File was created in the correct directory
- [ ] Filename is a valid timestamp
- [ ] All steps have sequential IDs
- [ ] `depends_on` correctly forms a chain
- [ ] `operation` values are valid
- [ ] `parameters` include all required fields
- [ ] Missing required fields were auto-filled
- [ ] YAML syntax is valid

## User Feedback

After generating the file, reply to the user with a short natural-language summary of what was understood and what is happening, then surface the task id (the filename without the `.yaml` extension). Do NOT reveal the full path, directory, or `.yaml` extension.

The summary should:

- Restate the user's intent in their language (Chinese if they wrote Chinese, English if they wrote English)
- List the key parameters that were detected or auto-filled (prompt, model, dimensions, duration, etc.)
- For multi-step workflows, briefly describe the pipeline (e.g., "先生成图片，然后转成视频")
- End by stating the task is created, followed by the id

Example responses:

Chinese input "画一只小猫":

```
任务：画一只小猫
参数：prompt="一只可爱的小猫", model="flux-kontext-max-t2i"（自动选择）
已成功创建...
任务 ID：2026-04-23T15-30-45
```

English input "Generate a 1024x1024 cyberpunk city":

```
Task: generate a cyberpunk city image
Parameters: prompt="cyberpunk city", width=1024, height=1024, model="flux-kontext-max-t2i" (auto-selected)
Created successfully...
Task ID: 2026-04-23T15-30-45
```

Multi-step input "生成一张猫的图片，然后做成视频":

```
任务：先生成猫的图片，再将其转换为视频
步骤 1 (t2i)：prompt="一只猫", model=...（自动选择）
步骤 2 (i2v)：使用步骤 1 的输出图片, model=...（自动选择）
已成功创建...
任务 ID：2026-04-23T15-32-10
```

Never include the directory path (e.g. `302ai-media-studio/tasks/...`) or the `.yaml` extension in the user-facing message. The id alone — paired with the natural-language summary — is what the user needs.

## Post-Generation: Execute the Task

**After generating the YAML file and providing the user summary, you MUST immediately invoke the 302ai-media-studio-apply skill to execute the task.**

Use the Skill tool to call `302ai-media-studio-apply` with the task ID as the context:

```
The task has been created with ID: <timestamp>

Now invoke 302ai-media-studio-apply to execute the first step of the workflow.
```

The apply skill will:
1. Read the task YAML file using the ID
2. Find the first pending step
3. Execute the appropriate ai302 CLI command
4. Update the task status based on the CLI response
5. Report back to the user

**This is mandatory:** Every task creation must be followed by an immediate apply skill invocation. Do not wait for the user to request execution — the workflow is designed to automatically begin execution after proposal.
